package com.medicare.mss.domainobject;

import java.io.Serializable;

import lombok.Data;

@Data
public class EEMAttestationDO implements Serializable {
	
	private static final long serialVersionUID = -6522830320206909872L;
	private String dateRequiredInd;
	private String label;
	private String value;
}
