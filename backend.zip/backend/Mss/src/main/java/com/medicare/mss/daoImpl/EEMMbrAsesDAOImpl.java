package com.medicare.mss.daoImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.medicare.mss.dao.EEMMbrAsesDAO;
import com.medicare.mss.domainobject.EEMMbrAsesDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.vo.EMDatedSegmentVO;

@Repository
public class EEMMbrAsesDAOImpl implements EEMMbrAsesDAO {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<EEMMbrAsesDO> getMbrAses(String customerId, String memberId, String showAll) {
		try {
			String sqlOverride = " AND OVERRIDE_IND = 'N'";
			if ("Y".equals(showAll))
				sqlOverride = "";

			String sql = CommonUtils.buildQuery("SELECT CUSTOMER_ID, MEMBER_ID, EFF_START_DATE, CREATE_TIME,",
					" EFF_END_DATE, OVERRIDE_IND,FAMILY_ID, MBR_SUFFIX, MPI, MEDICARE_IND, PLAN_VERSION,ASES_STATUS,",
					" PLAN_VER_CHG_IND,COST_SHARING_FLAG, MAX_COPY,EXT_FLAG,SPEND_DOWN_FLAG, GROUP_CODE, DECEASED_DATE,",
					" CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID, REGION_CODE FROM EM_MBR_ASES",
					" WHERE CUSTOMER_ID = ? AND MEMBER_ID = ?" + sqlOverride,
					" ORDER BY EFF_START_DATE DESC, EFF_END_DATE DESC");
			return jdbcTemplate.query(sql, new DomainPropertyRowMapper<EEMMbrAsesDO>(EEMMbrAsesDO.class), customerId,
					memberId);
		} catch (DataAccessException e) {
			throw new ApplicationException(e, "Error while getMbrAses");
		}
	}

	@Override
	public List<EEMMbrAsesDO> getDatesFromPlanVersionXWalk(EEMMbrAsesDO newVO) {
		try {
			String sql = CommonUtils.buildQuery("SELECT CUSTOMER_ID, EFF_START_DATE, ",
					" EFF_END_DATE, LAST_UPDT_TIME, LAST_UPDT_USERID FROM EM_ASES_PLNVER_XWALK WHERE CUSTOMER_ID = ? AND PLAN_VERSION= ?");
			return jdbcTemplate.query(sql, new DomainPropertyRowMapper<EEMMbrAsesDO>(EEMMbrAsesDO.class),
					newVO.getCustomerId(), newVO.getPlanVersion());
		} catch (DataAccessException e) {
			throw new ApplicationException(e, "Error while getDatesFromPlanVersionXWalk");
		}
	}

	@Override
	public int setOverride(EMDatedSegmentVO eemMbrAsesDO, String userId) {
		EEMMbrAsesDO asesDO = (EEMMbrAsesDO) eemMbrAsesDO;
		try {
			String sql = CommonUtils.buildQuery("UPDATE EM_MBR_ASES SET OVERRIDE_IND = 'Y',",
					" LAST_UPDT_TIME = ?, LAST_UPDT_USERID = ? WHERE CUSTOMER_ID = ? AND MEMBER_ID = ?",
					" AND EFF_START_DATE = ? AND CREATE_TIME = ? AND OVERRIDE_IND = 'N' AND LAST_UPDT_TIME = ?");

			Object[] parms = new Object[] { DateUtil.getCurrentDatetimeStamp(), userId, asesDO.getCustomerId(),
					asesDO.getMemberId(), asesDO.getEffStartDate(), asesDO.getCreateTime(), asesDO.getLastUpdtTime() };
			return jdbcTemplate.update(sql, parms);
		} catch (DataAccessException e) {
			throw new ApplicationException(e, "Error while setAsesOverride");
		}
	}

	@Override
	public int insertMbr(EMDatedSegmentVO eemMbrAsesDO) {
		EEMMbrAsesDO asesDO = (EEMMbrAsesDO) eemMbrAsesDO;
		CommonUtils.trimObject(asesDO);
		try {
			String sql = CommonUtils.buildQuery(
					"INSERT INTO EM_MBR_ASES(CUSTOMER_ID, MEMBER_ID, EFF_START_DATE, CREATE_TIME,",
					"EFF_END_DATE, OVERRIDE_IND,FAMILY_ID, MBR_SUFFIX, MPI, MEDICARE_IND, PLAN_VERSION,ASES_STATUS,PLAN_VER_CHG_IND,",
					"CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID ,REGION_CODE,COST_SHARING_FLAG, MAX_COPY,EXT_FLAG,SPEND_DOWN_FLAG,",
					" GROUP_CODE, DECEASED_DATE) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

			Object[] parms = new Object[] { asesDO.getCustomerId(), asesDO.getMemberId(), asesDO.getEffStartDate(),
					asesDO.getCreateTime(), asesDO.getEffEndDate(), asesDO.getOverrideInd(), asesDO.getOdsiFamilyId(),
					asesDO.getMbrSuffix(), asesDO.getMpi(), asesDO.getMedicaidInd(), asesDO.getPlanVersion(),
					asesDO.getStatus(), asesDO.getPlanVersionChangeInd(), asesDO.getCreateUserId(),
					asesDO.getLastUpdtTime(), asesDO.getLastUpdtUserId(), asesDO.getRegionCode(),
					asesDO.getCostSharing(), asesDO.getMaxCopy(), asesDO.getExtFlag(), asesDO.getSpendDwnFlg(),
					asesDO.getGrpCd(), asesDO.getDeceasedDt() };

			return jdbcTemplate.update(sql, parms);

		} catch (DataAccessException e) {
			throw new ApplicationException(e, "Error while insertMbrAses");
		}
	}

}
