package com.medicare.mss.vo;

import java.util.List;

import com.medicare.mss.domainobject.EEMAttestationDO;
import com.medicare.mss.domainobject.NamedItem;
import com.medicare.mss.util.LabelValuePair;

import lombok.Data;

@Data
public class MbrCacheVO {

	private String addValidation;
	private String lobValidation;

	private List<LabelValuePair> arrYesNo;
	private List<LabelValuePair> brkInCoverageType;
	private List<LabelValuePair> enrollCancelReasons;
	private List<LabelValuePair> lepNunCmoStstus;
	private List<LabelValuePair> lstOhiInd;
	private List<LabelValuePair> maxReconTypes;
	private List<LabelValuePair> memberAppeal;
	private List<NamedItem> oevCallStatusDrop;
	private List<LabelValuePair> oevCallSubReasonDrop;
	private List<LabelValuePair> ooaDeReasonList;
	private List<LabelValuePair> ooaReasonList;
	private List<LabelValuePair> ooaSourceList;
	private List<LabelValuePair> preSetNoteList;
	private List<LabelValuePair> recvdChannel;
	private List<LabelValuePair> respType;
	private List<LabelValuePair> validAccountType;
	private List<LabelValuePair> validAddressTypes;
	private List<LabelValuePair> validAgentTypes;
	private List<LabelValuePair> validAlternateCorrespondenceMethods;
	private List<LabelValuePair> validBillFrequency;
	private List<LabelValuePair> validBillPayMethod;
	private List<LabelValuePair> validCobTypes;
	private List<LabelValuePair> validCountry;
	private List<LabelValuePair> validDisenrollmentReasons;
	private List<LabelValuePair> validDrugEditClass;
	private List<LabelValuePair> validDsCodes;
	private List<LabelValuePair> validElectionTypes;
	private List<LabelValuePair> validEnrollReasons;
	private List<LabelValuePair> validEnrollSources;
	private List<LabelValuePair> validEnrollStatuses;
	private List<NamedItem> validEnrollStatusReasons;
	private List<LabelValuePair> validGenderCodes;
	private List<LabelValuePair> validLanguages;
	private List<LabelValuePair> validLEPType;
	private List<LabelValuePair> validLiCopays;
	private List<LabelValuePair> validLiPercents;
	private List<LabelValuePair> validMaritalStatuses;
	private List<LabelValuePair> validMemberStatus;
	private List<NamedItem> validOhiInd;
	private List<LabelValuePair> validPlanReasons;
	private List<LabelValuePair> validPlanVersions;
	private List<LabelValuePair> validPrefixes;
	private List<LabelValuePair> validRaceCodes;
	private List<LabelValuePair> validRelations;
	private List<EEMAttestationDO> validSepExceptions;
	private List<LabelValuePair> validSEPReasons;
	private List<LabelValuePair> validStates;
	private List<LabelValuePair> validStatus;
	private List<LabelValuePair> validStatuses;
	private List<LabelValuePair> validSubsidySrce;
	private List<LabelValuePair> validTxnStatus;
	private List<LabelValuePair> validPlanId;

}
