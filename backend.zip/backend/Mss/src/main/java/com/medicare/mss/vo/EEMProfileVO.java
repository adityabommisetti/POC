package com.medicare.mss.vo;

import java.io.Serializable;

import lombok.Data;

@Data
public class EEMProfileVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6162646719623557820L;

	private String customerId;
	private String effectiveEndDate;
	private String effectiveStartDate;
	private String lastUpdatedTime;
	private String lastUpdatedUserId;
	private String overrideInd;
	private String parmCode;
	private String parmDateValue;
	private String parmDescription;
	private String parmIndValue;
	private String parmNumberValue;
	private String parmTextValue;

}
