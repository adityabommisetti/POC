package com.medicare.mss.security.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.vo.EEMMbrCommentVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode(callSuper = false)
public class EEMBillingInvCommentVO extends EEMMbrCommentVO implements Cloneable {

	private static final long serialVersionUID = -8418325901792660327L;

	private String invoiceNbr;

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

}
