package com.medicare.mss.daoImpl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMBillingEntryDAO;
import com.medicare.mss.domainobject.EEMBilPaymentEntryDO;
import com.medicare.mss.domainobject.EEMBilPaymentEntryDtlsDO;
import com.medicare.mss.domainobject.EEMBilPaymentEntryInvDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.NumberFormatter;
import com.medicare.mss.util.PaginationQueryHelper;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.DataBaseField;
import com.medicare.mss.vo.EEMBilPaymentEntryDtlsVO;
import com.medicare.mss.vo.EEMBilPaymentEntryNewVO;
import com.medicare.mss.vo.EEMBilPaymentEntryVO;
import com.medicare.mss.vo.PageableVO;

@Repository
public class EEMBillingEntryDAOImpl implements EEMBillingEntryDAO {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private CacheService cacheService;

	private static final Logger LOG = LoggerFactory.getLogger(EEMBillingEntryDAOImpl.class);

	public PageableVO billPaymentEntrySearch(EEMBilPaymentEntryVO paymentEntrySearchVo, boolean isPagination) {
		List<EEMBilPaymentEntryDO> billingsList = new ArrayList<>();
		List<String> parmList = new ArrayList<>();
		PageableVO response = new PageableVO();

		StringBuilder sql = CommonUtils.buildQueryBuilder(
				"SELECT CUSTOMER_ID, PAY_SOURCE_TYPE, BATCH_DATE, BATCH_SEQ_NBR,",
				"BANK_ACCT_CD, BATCH_BALANCE_AMT, DETAIL_TOTAL_AMT,",
				"BATCH_BALANCE_IND, BATCH_POSTED_IND, BATCH_DETAIL_CNT,",
				"CREATE_TIME, CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID",
				"FROM BBB_PAYMENT_HEADER  WHERE CUSTOMER_ID = ?");

		parmList.add(paymentEntrySearchVo.getCustomerId());
		if (StringUtils.isNotBlank(paymentEntrySearchVo.getPaySource()) && !isPagination) {
			sql.append(" AND PAY_SOURCE_TYPE = ?");
			parmList.add(paymentEntrySearchVo.getPaySource());
		}
		if (StringUtils.isNotBlank(paymentEntrySearchVo.getBatchDate()) && !isPagination) {
			sql.append(" AND BATCH_DATE = ?");
			parmList.add(DateFormatter.reFormat(paymentEntrySearchVo.getBatchDate(), DateFormatter.MM_DD_YYYY,
					DateFormatter.YYYYMMDD));
		}

		if (StringUtils.isNotBlank(paymentEntrySearchVo.getBatchSeqNbr()) && !isPagination) {
			sql.append(" AND BATCH_SEQ_NBR = ?");
			parmList.add(paymentEntrySearchVo.getBatchSeqNbr());
		}
		if (StringUtils.isNotBlank(paymentEntrySearchVo.getBatchBalance())) {
			sql.append(" AND BATCH_BALANCE_IND = ?");
			parmList.add(paymentEntrySearchVo.getBatchBalance());
		}

		if (StringUtils.isNotBlank(paymentEntrySearchVo.getSupplementId())) {
			sql.append(" AND D.MEMBER_ID IN (SELECT E.MEMBER_ID FROM EM_MBR_ENROLLMENT E")
					.append(" WHERE E.CUSTOMER_ID = D.CUSTOMER_ID").append(" AND E.OVERRIDE_IND = 'N'")
					.append(" AND E.SUPPLEMENTAL_ID = ?)");
			parmList.add(paymentEntrySearchVo.getSupplementId());
		}

		try {
			
			if (isPagination) {

				DataBaseField[] conds = new DataBaseField[3];
				for (int i = 0; i < conds.length; i++) {
					conds[i] = new DataBaseField();
				}
				conds[0].setFieldName("BATCH_DATE");
				conds[0].setStringValue(DateFormatter.reFormat(paymentEntrySearchVo.getBatchDate(), DateFormatter.MM_DD_YYYY,
						DateFormatter.YYYYMMDD));
				conds[0].setSign(" <");

				conds[1].setFieldName("BATCH_SEQ_NBR");
				conds[1].setStringValue(paymentEntrySearchVo.getBatchSeqNbr());
				
				conds[2].setFieldName("PAY_SOURCE_TYPE");
				conds[2].setStringValue(paymentEntrySearchVo.getPaySource());

				StringBuilder pageCond = PaginationQueryHelper.pagingElements(conds, parmList);
				sql.append(pageCond);
			}
			
			sql.append(" ORDER BY CUSTOMER_ID, BATCH_DATE DESC, BATCH_SEQ_NBR, PAY_SOURCE_TYPE");
			sql.append(" FETCH FIRST ").append(EEMConstants.DB_MAX_RECORD_FETCH).append(" ROWS ONLY ");
			
			billingsList = jdbcTemplate.query(sql.toString(),
					new DomainPropertyRowMapper<EEMBilPaymentEntryDO>(EEMBilPaymentEntryDO.class), parmList.toArray());
			
			if (!CollectionUtils.isEmpty(billingsList)) {
				if (billingsList.size() > 100) {
					billingsList.remove(billingsList.size() - 1);
					response.setNextPage(true);
				}
			}
			response.setContent(billingsList);
			return response;
			
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public List<EEMBilPaymentEntryDtlsDO> billPaymentEntryDetails(EEMBilPaymentEntryVO eemBilPaymntEntryVo) {
		List<EEMBilPaymentEntryDtlsDO> billingsList = null;
		ArrayList<String> parmList = new ArrayList<>();

		StringBuilder sql = CommonUtils.buildQueryBuilder(
				"SELECT CUSTOMER_ID, PAY_SOURCE_TYPE, BATCH_DATE, BATCH_SEQ_NBR,",
				"ITEM_NBR, INVOICE_ID, INVOICE_DUE_DATE, CHECK_DATE, CHECK_NBR, PAYMENT_AMT,",
				"PAYMENT_POSTED_IND,CREATE_TIME, CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID",
				"FROM BBB_PAYMENT_DETAIL  WHERE CUSTOMER_ID = ? AND PAY_SOURCE_TYPE = ? AND BATCH_DATE = ? AND BATCH_SEQ_NBR = ?");

		parmList.add(eemBilPaymntEntryVo.getCustomerId());
		parmList.add(eemBilPaymntEntryVo.getPaySource());
		parmList.add(DateFormatter.reFormat(eemBilPaymntEntryVo.getBatchDate(), DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD));
		parmList.add(eemBilPaymntEntryVo.getBatchSeqNbr());

		if (StringUtils.isNotBlank(eemBilPaymntEntryVo.getItemNbr())) {
			sql.append(" AND ITEM_NBR = ? ");
			parmList.add(eemBilPaymntEntryVo.getItemNbr());
		}
		if (StringUtils.isNotBlank(eemBilPaymntEntryVo.getMemberId())) {
			sql.append(" AND INVOICE_ID =? ");
			parmList.add(eemBilPaymntEntryVo.getMemberId());
		}
		if (StringUtils.isNotBlank(eemBilPaymntEntryVo.getPaymentPostedInd())) {
			sql.append(" AND PAYMENT_POSTED_IND  = ? ");
			parmList.add(eemBilPaymntEntryVo.getPaymentPostedInd());
		}
		sql.append(" ORDER BY CUSTOMER_ID, PAY_SOURCE_TYPE, BATCH_DATE, BATCH_SEQ_NBR, ITEM_NBR");

		Object[] objPrams = parmList.toArray();
		try {
			billingsList = jdbcTemplate.query(sql.toString(),
					new DomainPropertyRowMapper<EEMBilPaymentEntryDtlsDO>(EEMBilPaymentEntryDtlsDO.class), objPrams);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
		return billingsList;
	}

	@Override
	public void billPaymentEntryAdd(EEMBilPaymentEntryVO paymntEntryHeader) {
		String custId = paymntEntryHeader.getCustomerId();
		paymntEntryHeader = (EEMBilPaymentEntryVO) CommonUtils.trimObject(paymntEntryHeader);

		String batchBalanceInd = "N";
		if (paymntEntryHeader.getBatchBalance().equals(paymntEntryHeader.getDetailAmount())) {
			batchBalanceInd = "Y";
		}

		String sql = CommonUtils.buildQuery(
				"INSERT INTO BBB_PAYMENT_HEADER(CUSTOMER_ID, PAY_SOURCE_TYPE, BATCH_DATE, BATCH_SEQ_NBR,",
				"BANK_ACCT_CD, BATCH_BALANCE_AMT, DETAIL_TOTAL_AMT, BATCH_BALANCE_IND,",
				"BATCH_POSTED_IND, BATCH_DETAIL_CNT, MBR_GRP_IND,",
				"CREATE_TIME, CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID)",
				"VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

		Object[] insertArr = new Object[] { paymntEntryHeader.getCustomerId(), paymntEntryHeader.getPaySource(),
				DateFormatter.reFormat(paymntEntryHeader.getBatchDate(), DateFormatter.MM_DD_YYYY,
						DateFormatter.YYYYMMDD),
				paymntEntryHeader.getBatchSeqNbr(), paymntEntryHeader.getBankAcntCd(),
				paymntEntryHeader.getBatchBalance(), paymntEntryHeader.getDetailAmount(), batchBalanceInd,
				paymntEntryHeader.getBatchPostedInd(), paymntEntryHeader.getBatchDtlCount(), "M",
				DateUtil.getCurrentDatetimeStamp(), cacheService.getUserInfo().getUserId(),
				DateUtil.getCurrentDatetimeStamp(), cacheService.getUserInfo().getUserId() };
		try {
			int ret = jdbcTemplate.update(sql, insertArr);
			if (ret == 0) {
				LOG.info("zero rows effected while billPaymentEntryAdd! for customer: {}", custId);
				throw new ApplicationException("zero rows effected while billPaymentEntryAdd!");
			}

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	public Integer getBatchSeqNum(EEMBilPaymentEntryVO billHeader) {

		String sql = CommonUtils.buildQuery("SELECT MAX(BATCH_SEQ_NBR) AS SEQNBR FROM BBB_PAYMENT_HEADER",
				" WHERE CUSTOMER_ID=? AND PAY_SOURCE_TYPE=? AND BATCH_DATE=?");
		try {
			return jdbcTemplate.queryForObject(sql,
					new Object[] { billHeader.getCustomerId(), billHeader.getPaySource(), DateFormatter
							.reFormat(billHeader.getBatchDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD) },
					Integer.class);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public void billPaymentEntryAddDetails(EEMBilPaymentEntryNewVO bilPaymntEntryNewVo) {
		EEMBilPaymentEntryVO paymentHeader = bilPaymntEntryNewVo.getBillPaymentsHeader();
		List<EEMBilPaymentEntryDtlsVO> dtlsList = bilPaymntEntryNewVo.getBillPaymentsDtlsList();

		String sql = CommonUtils.buildQuery(
				"INSERT INTO BBB_PAYMENT_DETAIL(CUSTOMER_ID, PAY_SOURCE_TYPE, BATCH_DATE, BATCH_SEQ_NBR,",
				"ITEM_NBR, INVOICE_ID, INVOICE_DUE_DATE, CHECK_DATE, CHECK_NBR, PAYMENT_AMT,",
				"PAYMENT_POSTED_IND, CREATE_TIME, CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID)",
				"VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

		Integer itemCount = Integer.parseInt(paymentHeader.getBatchDtlCount());
		try {
			jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
				public void setValues(PreparedStatement ps, int i) throws SQLException {

					EEMBilPaymentEntryDtlsVO tempObj = (EEMBilPaymentEntryDtlsVO) CommonUtils
							.trimObject(dtlsList.get(i));
					ps.setString(1, paymentHeader.getCustomerId());
					ps.setString(2, paymentHeader.getPaySource());
					ps.setString(3, DateFormatter.reFormat(paymentHeader.getBatchDate(), DateFormatter.MM_DD_YYYY,
							DateFormatter.YYYYMMDD));
					ps.setString(4, paymentHeader.getBatchSeqNbr());
					ps.setString(5, String.valueOf(itemCount + i + 1));
					ps.setString(6, tempObj.getMemberId());
					ps.setString(7, tempObj.getInvoiceDueDate());
					ps.setString(8, DateFormatter.reFormat(tempObj.getCheckDate(), DateFormatter.MM_DD_YYYY,
							DateFormatter.YYYYMMDD));
					ps.setString(9, tempObj.getCheckNbr());
					ps.setString(10, tempObj.getPaymentAmt());
					ps.setString(11, "N");
					ps.setString(12, DateUtil.getCurrentDatetimeStamp());
					ps.setString(13, cacheService.getUserInfo().getUserId());
					ps.setString(14, DateUtil.getCurrentDatetimeStamp());
					ps.setString(15, cacheService.getUserInfo().getUserId());

				}

				public int getBatchSize() {
					return dtlsList.size();
				}
			});
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_INSERT);
		}

	}

	@Override
	public void billPaymentEntryHeaderUpdate(EEMBilPaymentEntryVO paymentHeader) {
		String sql = CommonUtils.buildQuery(
				"UPDATE BBB_PAYMENT_HEADER SET DETAIL_TOTAL_AMT=?, BATCH_BALANCE_IND=?, BATCH_DETAIL_CNT=?,",
				"LAST_UPDT_TIME=?, LAST_UPDT_USERID=? WHERE CUSTOMER_ID=? ",
				"AND PAY_SOURCE_TYPE=? AND BATCH_DATE=? AND BATCH_SEQ_NBR=? AND LAST_UPDT_TIME=?");

		String batchBalanceInd = "N";
		if (paymentHeader.getBatchBalance().equals(paymentHeader.getDetailAmount())) {
			batchBalanceInd = "Y";
		}

		Object[] updateArr = new Object[] { paymentHeader.getDetailAmount(), batchBalanceInd,
				paymentHeader.getBatchDtlCount(), DateUtil.getCurrentDatetimeStamp(),
				cacheService.getUserInfo().getUserId(), paymentHeader.getCustomerId(), paymentHeader.getPaySource(),
				DateFormatter.reFormat(paymentHeader.getBatchDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD),
				paymentHeader.getBatchSeqNbr(), paymentHeader.getModifiedTime() };

		try {
			int ret = jdbcTemplate.update(sql, updateArr);
			if (ret == 0) {
				throw new ApplicationException("couldn't update record!");
			}
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}

	}

	@Override
	public Boolean memberIdValidate(String memberId, String customerId) {
		customerId = StringUtil.nonNullTrim(customerId);
		memberId = StringUtil.nonNullTrim(memberId);
		Boolean flag = false;
		String sql = "SELECT DISTINCT MEMBER_ID FROM EM_MBR_ENROLLMENT WHERE CUSTOMER_ID = ? AND MEMBER_ID = ?";
		try {
			String memId = jdbcTemplate.queryForObject(sql, new Object[] { customerId, memberId }, String.class);

			if (StringUtils.isNotBlank(memId)) {
				flag = Boolean.TRUE;
			}
		} catch (EmptyResultDataAccessException emptyExcep) {
			flag = Boolean.FALSE;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
		return flag;
	}

	@Override
	public List<EEMBilPaymentEntryInvDO> getBilEntryInvDetails(EEMBilPaymentEntryVO eemBilPaymntEntryVo) {

		String customerId = StringUtil.nonNullTrim(eemBilPaymntEntryVo.getCustomerId());
		String paySource = StringUtil.nonNullTrim(eemBilPaymntEntryVo.getPaySource());
		String batchDate = StringUtil.nonNullTrim(eemBilPaymntEntryVo.getBatchDate());
		String batchSeqNbr = StringUtil.nonNullTrim(eemBilPaymntEntryVo.getBatchSeqNbr());
		batchDate = DateFormatter.reFormat(batchDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);

		StringBuilder sQuery = CommonUtils.buildQueryBuilder("SELECT BPDI.INVOICE_NBR,BPDI.APPLIED_AMT, BPDI.ITEM_NBR,",
				" BPDI.CREATE_TIME, BPDI.CREATE_USERID, BPDI.LAST_UPDT_TIME, BPDI.LAST_UPDT_USERID ",
				" FROM BBB_PAYMENT_DTL_INVOICE BPDI JOIN BBB_INVOICE_HEADER BIH ON BPDI.INVOICE_NBR = BIH.INVOICE_NBR",
				" WHERE BIH.CUSTOMER_ID = ? AND BPDI.CUSTOMER_ID = ? AND BPDI.PAY_SOURCE_TYPE = ? AND BPDI.BATCH_DATE = ? ",
				"AND BPDI.BATCH_SEQ_NBR = ? ORDER BY BPDI.CREATE_TIME DESC ");

		Object[] parms = new Object[] { customerId, customerId, paySource, batchDate, batchSeqNbr };

		try {
			return jdbcTemplate.query(sQuery.toString(),
					new DomainPropertyRowMapper<EEMBilPaymentEntryInvDO>(EEMBilPaymentEntryInvDO.class), parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}

	}

	@Override
	public void paymentEntryHeaderBatchBalUpdate(EEMBilPaymentEntryVO bilPaymntsEntryVo) {
		String sql = CommonUtils.buildQuery("UPDATE BBB_PAYMENT_HEADER SET BATCH_BALANCE_AMT=?, BATCH_BALANCE_IND=?, ",
				"LAST_UPDT_TIME=?, LAST_UPDT_USERID=? WHERE CUSTOMER_ID=? ",
				"AND PAY_SOURCE_TYPE=? AND BATCH_DATE=? AND BATCH_SEQ_NBR=?");

		String batchBalanceInd = "N";
		if (bilPaymntsEntryVo.getBatchBalance().equals(bilPaymntsEntryVo.getDetailAmount())) {
			batchBalanceInd = "Y";
		}
		String batchDate = DateFormatter.reFormat(bilPaymntsEntryVo.getBatchDate(), DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);

		Object[] updateArr = new Object[] { bilPaymntsEntryVo.getBatchBalance(), batchBalanceInd,
				DateUtil.getCurrentDatetimeStamp(), cacheService.getUserInfo().getUserId(),
				bilPaymntsEntryVo.getCustomerId(), bilPaymntsEntryVo.getPaySource(), batchDate,
				bilPaymntsEntryVo.getBatchSeqNbr() };

		try {
			int ret = jdbcTemplate.update(sql, updateArr);
			if (ret == 0) {
				throw new ApplicationException("couldn't update record!");
			}
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}

	}

	@Override
	public boolean checkInvoiceId(String memberId, String customerId) {
		customerId = StringUtil.nonNullTrim(customerId);
		memberId = StringUtil.nonNullTrim(memberId);
		Boolean flag = null;
		String sql = CommonUtils.buildQuery("SELECT MEMBER_ID FROM EM_MBR_DEMOGRAPHIC WHERE CUSTOMER_ID = ? ",
				"AND MEMBER_ID = ? AND CURRENT_IND = 'Y' AND OVERRIDE_IND = 'N'");
		try {
			String memId = jdbcTemplate.queryForObject(sql, new Object[] { customerId, memberId }, String.class);

			if (StringUtils.isNotBlank(memId)) {
				flag = Boolean.TRUE;
			}
		} catch (EmptyResultDataAccessException emptyExcep) {
			flag = Boolean.FALSE;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
		return flag;
	}

	@Override
	public EEMBilPaymentEntryVO billPaymentEntryDetailsUpdate(EEMBilPaymentEntryDtlsVO bilPaymntsEntryDtlsVo,
			EEMBilPaymentEntryVO bilPaymentEntryVO) {
		String custId = bilPaymntsEntryDtlsVo.getCustomerId();
		String sql = CommonUtils.buildQuery("UPDATE BBB_PAYMENT_DETAIL SET INVOICE_ID=?, INVOICE_DUE_DATE=?, ",
				"CHECK_DATE=?, PAYMENT_AMT=?,LAST_UPDT_TIME=?, LAST_UPDT_USERID=?, CHECK_NBR=?  WHERE CUSTOMER_ID=? ",
				"AND PAY_SOURCE_TYPE=? AND BATCH_DATE=? AND BATCH_SEQ_NBR=? AND ITEM_NBR=? AND LAST_UPDT_TIME=?");

		String dueDate = DateFormatter.reFormat(bilPaymntsEntryDtlsVo.getInvoiceDueDate(), DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
		String checkDate = DateFormatter.reFormat(bilPaymntsEntryDtlsVo.getCheckDate(), DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
		String batchDate = DateFormatter.reFormat(bilPaymntsEntryDtlsVo.getBatchDate(), DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);

		Object[] updateArr = new Object[] { bilPaymntsEntryDtlsVo.getMemberId(), dueDate, checkDate,
				bilPaymntsEntryDtlsVo.getPaymentAmt(), DateUtil.getCurrentDatetimeStamp(),
				cacheService.getUserInfo().getUserId(), bilPaymntsEntryDtlsVo.getCheckNbr(),
				bilPaymntsEntryDtlsVo.getCustomerId(), bilPaymntsEntryDtlsVo.getPaySource(), batchDate,
				bilPaymntsEntryDtlsVo.getBatchSeqNbr(), bilPaymntsEntryDtlsVo.getItemNbr(),
				bilPaymntsEntryDtlsVo.getLastUpdtTime() };

		try {
			int ret = jdbcTemplate.update(sql, updateArr);

			bilPaymentEntryVO = updateDetailsAmountInHeader(bilPaymntsEntryDtlsVo, bilPaymentEntryVO);

			if (ret != 1) {
				LOG.info("zero rows effected while billPaymentEntryDetailsUpdate! for customer: {}", custId);
				throw new ApplicationException("couldn't update record!");
			}
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}
		return bilPaymentEntryVO;

	}

	private EEMBilPaymentEntryVO updateDetailsAmountInHeader(EEMBilPaymentEntryDtlsVO bilPaymntsEntryDtlsVo,
			EEMBilPaymentEntryVO bilPaymentEntryVO) {
		String sql = CommonUtils.buildQuery("UPDATE BBB_PAYMENT_HEADER SET DETAIL_TOTAL_AMT=?, BATCH_BALANCE_IND=?,",
				"LAST_UPDT_TIME=?, LAST_UPDT_USERID=? WHERE CUSTOMER_ID=? ",
				"AND PAY_SOURCE_TYPE=? AND BATCH_DATE=? AND BATCH_SEQ_NBR=?");
		String total = getDetailTotalPayment(bilPaymntsEntryDtlsVo);
		String batchBalanceInd = "N";
		total = NumberFormatter.formatDecimal2Places(total);
		if (total.equals(bilPaymentEntryVO.getBatchBalance())) {
			batchBalanceInd = "Y";
		}
		bilPaymentEntryVO.setBatchBalInd(batchBalanceInd);
		bilPaymentEntryVO.setDetailAmount(total);
		String batchDate = DateFormatter.reFormat(bilPaymntsEntryDtlsVo.getBatchDate(), DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
		Object[] updateArr = new Object[] { total, batchBalanceInd, DateUtil.getCurrentDatetimeStamp(),
				cacheService.getUserInfo().getUserId(), bilPaymntsEntryDtlsVo.getCustomerId(),
				bilPaymntsEntryDtlsVo.getPaySource(), batchDate, bilPaymntsEntryDtlsVo.getBatchSeqNbr() };
		int ret = jdbcTemplate.update(sql, updateArr);
		if (ret != 1) {
			throw new ApplicationException(EEMConstants.ERROR_UPDATE);
		}
		return bilPaymentEntryVO;
	}

	private String getDetailTotalPayment(EEMBilPaymentEntryDtlsVO bilPaymntsEntryDtlsVo) {
		String sql = CommonUtils.buildQuery("SELECT SUM(PAYMENT_AMT) AS TOTAL FROM BBB_PAYMENT_DETAIL",
				" WHERE CUSTOMER_ID=? AND PAY_SOURCE_TYPE=? AND BATCH_DATE=? AND BATCH_SEQ_NBR=?");
		String batchDate = DateFormatter.reFormat(bilPaymntsEntryDtlsVo.getBatchDate(), DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
		Object[] updateArr = new Object[] { bilPaymntsEntryDtlsVo.getCustomerId(), bilPaymntsEntryDtlsVo.getPaySource(),
				batchDate, bilPaymntsEntryDtlsVo.getBatchSeqNbr() };
		try {
			return jdbcTemplate.queryForObject(sql, updateArr, String.class);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}
	
}