package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class BaseDO {
	
	@ColumnMapper(columnName="CREATE_TIME" ,propertyName="createTime")
	private String createTime;
	
	@ColumnMapper(columnName="CREATE_USERID" ,propertyName="createUserId")
	private String createUserId;

	@ColumnMapper(columnName="CUSTOMER_ID" ,propertyName="customerId")
	private String customerId;

	@ColumnMapper(columnName="LAST_UPDT_TIME" ,propertyName="lastUpdtTime")
	private String lastUpdtTime;

	@ColumnMapper(columnName="LAST_UPDT_USERID" ,propertyName="lastUpdtUserId")
	private String lastUpdtUserId;

}