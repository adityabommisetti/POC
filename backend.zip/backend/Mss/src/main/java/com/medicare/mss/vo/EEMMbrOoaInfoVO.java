package com.medicare.mss.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode(callSuper = false)
public class EEMMbrOoaInfoVO extends BaseVO implements EMDatedSegmentVO, Serializable, Cloneable {

	private static final long serialVersionUID = 8118117982377528635L;

	private String deEffectiveDate;
	private String deReason;
	private String deReasonDesc;
	private String endDate;
	private String leaveDate;
	private String memberId;
	private String ooaReason;
	private String ooaSource;
	private String ooaSourceTrr;
	private String overrideInd;
	private String planDesignation;
	private String reasonDesc;
	private String receiveDate;
	private String returnDate;
	private String sourceDesc;
	private String tempPerm;

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	public String getDeEffectiveDateFrmt() {
		return DateFormatter.reFormat(deEffectiveDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	@Override
	public String getEffEndDate() {
		return null;
	}

	@Override
	public String getEffStartDate() {
		return null;
	}

	public String getEndDateFrmt() {
		return DateFormatter.reFormat(endDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getLeaveDateFrmt() {
		return DateFormatter.reFormat(leaveDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getReceiveDateFrmt() {
		return DateFormatter.reFormat(receiveDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getReturnDateFrmt() {
		return DateFormatter.reFormat(returnDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	@Override
	public String getType() {
		return tempPerm;
	}

	@Override
	public boolean isEndDateChange(Object chkVO) {
		return false;
	}

	@Override
	public boolean isForSamePeriod(Object obj) {

		EEMMbrOoaInfoVO chkVO = (EEMMbrOoaInfoVO) obj;
		if (chkVO.getReceiveDate().equals(this.receiveDate) && chkVO.getReturnDate().equals(this.returnDate)
				&& chkVO.getMemberId().equals(this.memberId) && chkVO.getCustomerId().equals(this.getCustomerId())
				&& chkVO.getOverrideInd().equals(this.overrideInd))
			return true;

		return false;
	}

	@Override
	public boolean isSame(Object chkVO) {
		return false;
	}

	public void setDeEffectiveDateFrmt(String deEffectiveDate) {
		this.deEffectiveDate = DateFormatter.reFormat(deEffectiveDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
	}

	@Override
	public void setEffEndDate(String effEndDate) {

	}

	@Override
	public void setEffStartDate(String effStartDate) {

	}

	public void setEndDateFrmt(String endDate) {
		this.endDate = DateFormatter.reFormat(endDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public void setLeaveDateFrmt(String leaveDate) {
		this.leaveDate = DateFormatter.reFormat(leaveDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public void setReceiveDateFrmt(String receiveDate) {
		this.receiveDate = DateFormatter.reFormat(receiveDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public void setReturnDateFrmt(String returnDate) {
		this.returnDate = DateFormatter.reFormat(returnDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

}
