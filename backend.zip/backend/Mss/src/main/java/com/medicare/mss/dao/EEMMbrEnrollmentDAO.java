package com.medicare.mss.dao;

import com.medicare.mss.domainobject.EEMMbrEligibilityDO;
import com.medicare.mss.domainobject.EEMMbrEnrollmentDO;
import com.medicare.mss.domainobject.EMMbrTriggerDO;

public interface EEMMbrEnrollmentDAO extends EEMMbrBaseDAO {

	boolean checkDuplSupplId(String customerId, String supplId, String memberId);

	boolean isUnlawfullyEligible(String reqCovDt, String hicNbr, String mbiNbr, String table);

	boolean isIncarcerated(String reqCovDt, String hicNbr, String mbiNbr, String table);

	boolean isMAOEPElectionTypeAlreadyUsed(String custID, String memberId, String date1, String date2);

	boolean validateBrkInCov(String custID, String memberId, String date, String reqDtOfCov);

	int insertMbrEligibility(EEMMbrEligibilityDO mbrElig);

	int updateTXNFlag(String txnCode, boolean ON, EEMMbrEnrollmentDO newVO);

	String getMbrTriggerCode(String funcType, EEMMbrEnrollmentDO enrollVO);

	int updateFUMTrigger(EMMbrTriggerDO trig);

	double getPartCPremium(EEMMbrEnrollmentDO enrollVO);

	int closeOpenPrintIDCardTrigger(EMMbrTriggerDO trigDO);

	String getClient(EEMMbrEnrollmentDO newVO);

}
