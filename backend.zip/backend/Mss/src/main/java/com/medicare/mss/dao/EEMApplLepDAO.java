package com.medicare.mss.dao;

import java.util.List;
import java.util.Map;

import com.medicare.mss.domainobject.EEMApplTriggerDO;
import com.medicare.mss.domainobject.EEMLepAttestCallDO;
import com.medicare.mss.domainobject.EEMLepAttestCcfDO;
import com.medicare.mss.domainobject.EEMLepAttestInfoDO;
import com.medicare.mss.domainobject.EEMLepPtnlUncovMthsDO;
import com.medicare.mss.domainobject.EEMLepSummaryDO;
import com.medicare.mss.domainobject.EMMbrTriggerDO;
import com.medicare.mss.domainobject.LepHistory;

public interface EEMApplLepDAO {

	EEMLepSummaryDO getApplLepSummaryInfo(String hicNumber, String mbi);

	EEMLepAttestInfoDO getApplLepAttestInfos(String customerId, String applId, String appAttnShowAll);

	List<EEMLepPtnlUncovMthsDO> getPotentialUnCovMonth(String customerId, String applId, String overridInd,
			boolean isMember);

	Map<String, List<EEMLepAttestCallDO>> getAppLepNunCmo(String customerId, String applId, boolean isMember);

	boolean insertMbrLepAttInfo(String customerId, String applId, EEMLepAttestCallDO eemLepAttestCallDO,
			String attestType);

	int invokeTriggerUpdate(String customerId, String applId, String userId, boolean isMember);

	String getApplAttStatus(String customerId, String applId);

	int insertApplLepAttnDetails(EEMLepAttestInfoDO newDo, boolean isMember);

	int closeALLApplTimers(EMMbrTriggerDO triggerDO, boolean isMember, String triggerCodes);

	int overrideApplLepAttnDetails(String customerId, String applId, String userId, boolean isMember);

	int insertAttnDetailsInCCF(EEMLepAttestCcfDO attestDO, boolean isMember);

	int overridePLepApplDetails(String customerId, String userId, String applId, boolean isMember);

	List<EEMLepAttestCcfDO> getApplCcfResp(String customerId, String applId, String sqlOverride, boolean isMember);

	int insertApplPtnlUnCovMnthsDetails(EEMLepPtnlUncovMthsDO applLepPtnlUncovMthsDO, boolean isMember);

	int overrideApplAttnInfo(EEMLepAttestCcfDO tagetDO, boolean isMember);

	String getInterval(String customerId);

	String checkOpenApplTrigger(String customerId, String applId, String TriggerType);


	int updateApplPtnlUnCovMnthsDetails(EEMLepPtnlUncovMthsDO lepPtnlUncovMthsDO, boolean isMember);

	int closeOBCTimer(String customerId, String applId);

	String getApplTriggetr(String customerId, String applId, String triggerType, String triggerCode);

	Map<String, String> getApplTrigger(String customerId, String applId, boolean isMember, String triggerType);

	byte[] displayDocumentFromDB(String applId, Map<String, String> searchParamMap);

	int getApplId(String customerId, String memberId);

	String validateReqDtCov(String customerId, String applId);

	boolean validateHicNbrChanged(String customerId, String mbiHicNbr, String applId);

	List<String> getPrtdRdsCnt(String mbrHicNbr, String srcTable);

	void createApplLEPLetter(EEMApplTriggerDO triggerDo);

	boolean verifyLEPRecord(String customerId, String applId);

	List<LepHistory> getPartDHistory(String mbi, String hicNbrVal, String srcTable);

	List<LepHistory> getRdsHistory(String mbi, String hicNbrVal, String srcTable);

	void getApplLepAttnDetails(String customerId, String id, EEMLepAttestInfoDO attestDO, boolean isMember);

	void checkLepLetters(String customerId, String id, EEMLepAttestInfoDO attestDO, boolean isMember);

	EEMLepAttestInfoDO getTriggerDataForLEPAttestion(EEMLepAttestInfoDO lepAttestInfoDO);

	void getMbrLepAttest90DaysDetails(EEMLepAttestInfoDO lepAttestInfoDO);

	boolean checkMbrTimmerStatus(EMMbrTriggerDO triggerDO);

	boolean checkMbrTriggerStatus(String customerId, String memberId, String triggerCode, String triggerStatus);


	int updateTrigger(String customerId, String primaryId, String userId, boolean isMember);

	void checkAvailabilityOfLetters(String custId, String mbrId, EEMLepAttestInfoDO attestDO);

	EEMLepSummaryDO getApplLepSummaryInfoBEQR(String hicNumber, String mbi);

}
