package com.medicare.mss.vo;

import lombok.Data;

@Data
public class EEMApplErrorVO {

	private int ApplicationId;
	private String CustomerId;
	private String ErrorCd;
	private String ErrorData;
	private String ErrorMsg;
	private String FieldNbr;
	private String FormField;
	private String lastUpdtUserId;
	private String RfiInd;
	private String status;
	 
}
