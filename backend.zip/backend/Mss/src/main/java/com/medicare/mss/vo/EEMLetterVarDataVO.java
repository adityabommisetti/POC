package com.medicare.mss.vo;

import java.io.Serializable;

import lombok.Data;

@Data
public class EEMLetterVarDataVO implements Serializable {

	private static final long serialVersionUID = 2404067105362380229L;

	private int seqNbr;
	private String varId;
	private String description;
	private String fieldType;
	private String fieldLength;
	private String fieldValue;
}
