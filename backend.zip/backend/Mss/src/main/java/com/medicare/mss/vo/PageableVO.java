package com.medicare.mss.vo;

import lombok.Data;

@Data
public class PageableVO {

	private boolean nextPage;
	private Object content;

}
