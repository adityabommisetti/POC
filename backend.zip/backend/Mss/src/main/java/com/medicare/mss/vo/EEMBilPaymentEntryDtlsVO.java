package com.medicare.mss.vo;

import java.util.List;

import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
public class EEMBilPaymentEntryDtlsVO {

	private String customerId;
	private String paySource;
	private String batchDate;
	private String batchSeqNbr;
	private String itemNbr;
	private String memberId;
	private String dueDate;
	private String invoiceDueDate;
	private String checkDate;
	private String checkNbr;
	private String paymentAmt;
	private String paymentPostedInd;
	private String createTime;
	private String createUserId;
	private String lastUpdtTime;
	private String lastUpdtUserId;
	private List<EEMBilPaymentEntryInvVO> billingInvoiceList;
	
	public String getFrmtCreateTime() {
		return DateFormatter.reFormat(createTime, DateFormatter.DB2_TIMESTAMP, DateFormatter.MM_DD_YYYY_HH_MM_SS);

	}

	public String getFrmtLastUpdtTime() {
		return DateFormatter.reFormat(lastUpdtTime, DateFormatter.DB2_TIMESTAMP, DateFormatter.MM_DD_YYYY_HH_MM_SS);

	}

	public String getBatchDate() {
		return DateFormatter.reFormat(batchDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setBatchDate(String batchDate) {
		this.batchDate = DateFormatter.reFormat(batchDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getInvoiceDueDate() {
		return DateFormatter.reFormat(invoiceDueDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setInvoiceDueDate(String invoiceDueDate) {
		this.invoiceDueDate = DateFormatter.reFormat(invoiceDueDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getCheckDate() {
		return DateFormatter.reFormat(checkDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setCheckDate(String checkDate) {
		this.checkDate = DateFormatter.reFormat(checkDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

}
