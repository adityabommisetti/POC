package com.medicare.mss.vo;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class EEMTimersMasterVO implements Serializable {

	private static final long serialVersionUID = -7418920227503032796L;
	
	private List<EEMTimersVO> emmTimersVOs;
	private boolean nextPage;

}