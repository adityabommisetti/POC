package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class BillingMbrPymntDtlInvcDO {

	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;
	
	@ColumnMapper(columnName = "PAY_SOURCE_TYPE", propertyName = "paySourceType")
	private String paySourceType;
	
	@ColumnMapper(columnName = "BATCH_DATE", propertyName = "batchDate")
	private String batchDate;
	
	@ColumnMapper(columnName = "BATCH_SEQ_NBR", propertyName = "batchSeqNbr")
	private int batchSeqNbr;
	
	@ColumnMapper(columnName = "ITEM_NBR", propertyName = "itemNbr")
	private int itemNbr;
	
	@ColumnMapper(columnName = "INVOICE_NBR", propertyName = "invoiceNbr")
	private int invoiceNbr;
	
	@ColumnMapper(columnName = "APPLIED_AMT", propertyName = "appliedAmt")
	private String appliedAmt;
	
	@ColumnMapper(columnName = "INVOICE_TYPE", propertyName = "invoiceType")
	private String invoiceType;
	
	@ColumnMapper(columnName = "DUE_DATE", propertyName = "dueDate")
	private String dueDate;
 	
	@ColumnMapper(columnName = "CREATE_TIME", propertyName = "createTime")
	private String createTime;
	
	@ColumnMapper(columnName = "CREATE_USERID", propertyName = "createUserId")
	private String createUserId;
	
	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;
	
	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserId")
	private String lastUpdtUserId;
	
}
