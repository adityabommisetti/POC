package com.medicare.mss.vo;

import lombok.Data;

@Data
public class EEMApplPlanVO {
	 
	private String  applId;
	private String[] arrPlanDetails; //Holds PLAN_TYPE & PLAN_DESIGNATION from PLANPBP table
	private String  currGrpId;
	private String  currPaymentAmt;
	private String  currPbpId;
	private String  currPbpSegmentId;
	private String  currPlanId;
	private String  currPlanDesignation;
	private String  currProductId;
	private String  customerId;
	private String  effEndDate;
	private String  elcDerivedInd;
	private String  electionType;
	private String  enrollGrpId;
	private String  enrollPymtAmt;
	private String  enrollPbp;
	private String  enrollSegment;
	private String  enrollPlan;
    private String  enrollProduct;
    private String  lastUpdtTime;
	private String  reqDtCov;
	private String  sepElectionDt;
	private String  sepReason;
	
}
