package com.medicare.mss.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMMbrAccretionDAO;
import com.medicare.mss.domainobject.EEMMbrAccretionDO;
import com.medicare.mss.helper.EEMContext;
import com.medicare.mss.vo.EEMMbrAccretionVO;

@Service
public class EEMMbrAccretionService extends EEMMbrBaseService {

	@Autowired
	private EEMMbrAccretionDAO mbrAccretionDAO;

	@Autowired
	private MessageSource messageSource;

	@SuppressWarnings("unchecked")
	public List<EEMMbrAccretionVO> getMbrAccretionList(String memberId, String showAll) {

		List<EEMMbrAccretionVO> mbrAccretionVOList = sessionHelper.getEEMContext().getMbrMasterVO()
				.getMbrAccretionList();

		if (StringUtils.equals(EEMConstants.VALUE_YES, showAll)) {
			List<EEMMbrAccretionVO> allInfos = getMbrAccretionListFromDB(memberId, showAll);
				mbrAccretionVOList = (List<EEMMbrAccretionVO>) getActiveDatedList(allInfos);
				setToContext(mbrAccretionVOList);
			return allInfos;
		} else {
			if (Objects.isNull(mbrAccretionVOList)) {
				mbrAccretionVOList = getMbrAccretionListFromDB(memberId, showAll);
				setToContext(mbrAccretionVOList);
			} else {
				mbrAccretionVOList = (List<EEMMbrAccretionVO>) getActiveDatedList(mbrAccretionVOList);
				setToContext(mbrAccretionVOList);
			}
			return mbrAccretionVOList;
		}
	}

	public List<EEMMbrAccretionVO> getMbrAccretionListFromDB(String memberId, String showAll) {

		List<EEMMbrAccretionVO> mbrAccretionVOList = new ArrayList<>();
		String customerId = sessionHelper.getUserInfo().getCustomerId();

		List<EEMMbrAccretionDO> mbrAccretionDOList = mbrAccretionDAO.getMbrAccretion(customerId, memberId, showAll);
		if (!CollectionUtils.isEmpty(mbrAccretionDOList)) {
			mbrAccretionDOList.forEach(mbrAccretionDO -> {
				EEMMbrAccretionVO eEMMbrAccretionVO = new EEMMbrAccretionVO();
				BeanUtils.copyProperties(mbrAccretionDO, eEMMbrAccretionVO);

				eEMMbrAccretionVO.setTransactionType(eEMMbrAccretionVO.getTransCode());
				eEMMbrAccretionVO.setTransDesc(
						messageSource.getMessage(eEMMbrAccretionVO.getTransCode(), null, Locale.getDefault()));

				mbrAccretionVOList.add(eEMMbrAccretionVO);
			});
		}
		return mbrAccretionVOList;
	}

	private void setToContext(List<EEMMbrAccretionVO> mbrAccretionVOList) {
		EEMContext context = sessionHelper.getEEMContext();
		context.getMbrMasterVO().setMbrAccretionList(mbrAccretionVOList);
		sessionHelper.setEEMContext(context);
	}

}
