package com.medicare.mss.constants;

public final class EEMConstants {

	private EEMConstants() {

	}

	public static final String ACCRETION = "accretion";

	public static final String ACTIVE = "A";

	public static final String ACTIVE_IND = "ACTIVE_IND";
	public static final String AGENT = "agent";
	public static final String AGENTDT = "AGENTDT";
	public static final String AGENTID = "agentId";
	public static final String APPFIELDS = "APPFIELDS";
	public static final String APPL_STATUS_APPROVED = "APPROVED";
	public static final String APPL_STATUS_BEQAPPR = "BEQAPPR";
	public static final String APPL_STATUS_BEQPENDING = "BEQPENDING";
	public static final String APPL_STATUS_CANCELED = "CANCELED";
	public static final String APPL_STATUS_COMPLETED = "COMPLETED";
	public static final String APPL_STATUS_DENIEDELG = "DENIEDELG";
	public static final String APPL_STATUS_DENIEDETYP = "DENIEDETYP";
	public static final String APPL_STATUS_DENIEDOTHR = "DENIEDOTHR";
	public static final String APPL_STATUS_DUPLAPPL = "DUPLAPPL";
	public static final String APPL_STATUS_DUPLENRL = "DUPLENRL";
	public static final String APPL_STATUS_ELGCRITICL = "ELGCRITICL";
	public static final String APPL_STATUS_ELGNOTFND = "ELGNOTFND";
	public static final String APPL_STATUS_ELGWARNING = "ELGWARNING";
	public static final String APPL_STATUS_ERROR = "ERROR";
	public static final String APPL_STATUS_ERRORCRITL = "ERRORCRITL";
	public static final String APPL_STATUS_FORCEDAPPR = "FORCEDAPPR";
	public static final String APPL_STATUS_HOLD = "HOLD";
	public static final String APPL_STATUS_INCOMPLETE = "INCOMPLETE";
	public static final String APPL_STATUS_INCRFIELCT = "INCRFIELCT";
	public static final String APPL_STATUS_INCRFIGEN = "INCRFIGEN";
	public static final String APPL_STATUS_INCRFIREQ = "INCRFIREQ";

	public static final String APPL_STATUS_INCRFITRG = "INCRFITRG";
	public static final String APPL_STATUS_READY = "READY";
	public static final String APPL_STATUS_READYAPPR = "READYAPPR";
	public static final String APPL_STATUS_RETROENRLR = "RETROENRLR";
	public static final String APPL_STATUS_SUPPEND = "SUPPEND";

	public static final String APPLICATION = "APPLICATION";
	public static final String APPLICATION_AGEING = "ApplicationAgeing";
	public static final String APPL_TRACKING_QUEUE_CD = "100";
	public static final String APPNBR = "APPNBR";
	public static final String APPNBR_DERIVED = "D";
	public static final String ASES = "ases";
	public static final String ASSIGNED = "ASSIGNED";
	public static final String ATRISK = "ATRISK";
	public static final String AUTHORIZATION = "Authorization";
	public static final String AUTH_CACHE = "AUTHENTICATION";
	public static final String AUTH_TOKEN = "x-auth-token";
	public static final String AUTOAPPLDT = "AUTOAPPLDT";
	public static final String BEQCHECK = "BEQCHECK";
	public static final String BILL_PAYSOURCE_MANUAL = "M";
	public static final String BILLING = "billing";
	public static final String BLANK = "";
	public static final String BYPASSCOBDATE = "BYPASSCOBDATE";
	public static final String CAMPIDIND = "CAMPIDIND";
	public static final String CCM = "CCM";
	public static final String CMAEMRGIND = "CMAEMRGIND";
	public static final String CMS_STATUS = "CmsStatus";
	public static final String CMS_TRANSACTION_STATUS = "CmsTransactionStatus";
	public static final String COB = "cob";
	public static final String COB_TYPE_SECONDARY = "2";
	public static final String COMMENT_PRESET = "WF_COMMENT";
	public static final String COMMENTS = "comments";
	public static final String CONTRNOIND = "CONTRNOIND";
	public static final String DASHLETCOUNT_SEPARATOR = "_";
	public static final String DATA_CHANGED_BY_ANOTHER_USER = "Data Has Been Changed By another User";
	public static final int DB_MAX_RECORD_FETCH = 101;
	public static final String DEFAULT_INITIAL_TIMESTAMP = "0000-00-00 00:00:00.000000";
	public static final String DEFAULT_TIMESTAMP = "0001-01-01 00:00:00.000000";
	public static final String DEFAULT_TIMESTAMP_FORMAT = "yyyy-MM-dd HH:mm:ss.SSSSSS";
	public static final String DEP = "DEP";
	public static final String DISENROLLED_FOR_THE_GIVEN_DISENROLLMENT_DATE = "Member already disenrolled for the given disenrollment date!";
	public static final String DRAFTDAY = "DRAFTDAY";
	public static final String DSI_STATE_COUNTY = "STC";

	public static final String EEM_ADDRTYPE_AUTH = "AUTH";
	public static final String EEM_ADDRTYPE_MAIL = "MAIL";
	public static final String EEM_ADDRTYPE_PRIMARY = "PRIM";
	public static final String EEM_APPL_ADDRESS_TABLE = "EM_APPL_ADDRESS";
	public static final String EEM_APPL_ADDRESS_VO = "EEMApplAddressVO";
	public static final String EEM_APPL_AGENT_TABLE = "EM_APPL_AGENT";
	public static final String EEM_APPL_AGENT_VO = "EEMApplAgentVO";
	public static final String EEM_APPL_CANCEL_TRIG_FUA_TYPE = "ACAN";
	public static final String EEM_APPL_DENIAL_TRIG_FUN_TYPE = "ADEN";
	public static final String EEM_APPL_ELIGIBILITY_VO = "EEMApplEligibilityVO";
	public static final String EEM_APPL_OTH_COV_TABLE = "EM_APPL_OTHER_COV";
	public static final String EEM_APPL_OTH_PLAN_TABLE = "EM_APPL_OTHER_PLAN";
	public static final String EEM_APPL_OTHER_COV_VO = "EEMApplOtherCovVO";
	public static final String EEM_APPL_OTHER_PLAN_VO = "EEMApplOtherPlanVO";
	public static final String EEM_APPL_PACKAGE_QUALIFIER = "com.medicare.mss.vo.";
	public static final String EEM_APPL_PLAN_TABLE = "EM_APPL_PLAN";
	public static final String EEM_APPL_PLAN_VO = "EEMApplPlanVO";
	public static final String EEM_APPL_TABLE = "EM_APPLICATION";
	public static final String EEM_APPL_VOS = "'EEMApplicationVO', 'EEMApplAddressVO', 'EEMApplAgentVO', 'EEMApplOtherCovVO', 'EEMApplOtherPlanVO', 'EEMApplPlanVO'";
	public static final String EEM_APPLFORM_CLASS = "com.medicare.mss.vo.EEMApplMasterVO";
	public static final String EEM_APPLICATION_VO = "EEMApplicationVO";
	public static final String EEM_BILL_INVOICE_LOCKED = "LK";
	public static final String EEM_BILL_INVOICE_REOPENED = "RO";
	public static final String EEM_CONTEXT = "eemContext";
	public static final String EEM_DEMOGRAPHIC_TABLE = "EM_MBR_DEMOGRAPHIC";
	public static final String EEM_ENROLL_FORM = "eemEnrollForm";
	public static final String EEM_ENROLLMENT_FORM = "'eemEnrollForm'";
	public static final String EEM_GRP_PRODUCT_VO = "EEMGrpProductVO";
	public static final String EEM_LEP_APPL_LTR_FUN_TYPE_1 = "L2A";
	public static final String EEM_LEP_APPL_LTR_FUN_TYPE_2 = "L2B";
	public static final String EEM_MBR_CANCEL_TRIG_FUN_TYPE = "MCAN";
	public static final String EEM_MBR_DEMO_VO = "EEMMbrDemographicVO";
	public static final String EEM_MBR_DSENRL_CANCEL_TRIG_FUN_TYPE = "DCAN";
	public static final String EEM_MBR_OOA = "EM_MBR_OOA";
	public static final String EEM_MEDOFFICE_VO = "EEMMedOfficeVO";
	public static final String EEMCONTEXT = "EEMCONTEXT";
	public static final String EFF_END_DATE = "99999999";
	public static final String ELECTION_TYPE_AEP = "A";
	public static final String ELECTION_TYPE_ICEP = "I";
	public static final String ELECTION_TYPE_IEP = "E";
	public static final String ELECTION_TYPE_IEP2 = "F";
	public static final String ELECTION_TYPE_MA_AUTO = "Z";
	public static final String ELECTION_TYPE_MA_OEP = "M";
	public static final String ELECTION_TYPE_MADP = "D";
	public static final String ELECTION_TYPE_OEPI = "T";
	public static final String ELECTION_TYPE_SEP_5SR = "R";
	public static final String ELECTION_TYPE_SEP_ADMIN = "X";
	public static final String ELECTION_TYPE_SEP_CWK = "Y";
	public static final String ELECTION_TYPE_SEP_DUL = "U";
	public static final String ELECTION_TYPE_SEP_EGH = "W";
	public static final String ELECTION_TYPE_SEP_ELP = "S";
	public static final String ELECTION_TYPE_SEP_LIS = "L";
	public static final String ELECTION_TYPE_SEP_RES = "V";
	public static final String ELGESRD = "ELGESRD";
	public static final String ELGOVERIDE = "ELGOVERIDE";
	public static final String EM_MBR_ADDRESS = "EM_MBR_ADDRESS";
	public static final String EM_MBR_AGENT = "EM_MBR_AGENT";
	public static final String EM_MBR_ASES = "EM_MBR_ASES";
	public static final String EM_MBR_BILLING = "EM_MBR_BILLING";
	public static final String EM_MBR_COB = "EM_MBR_COB";
	public static final String EM_MBR_DSINFO = "EM_MBR_DSINFO";
	public static final String EM_MBR_ENROLLMENT = "EM_MBR_ENROLLMENT";
	public static final String EM_MBR_LEP = "EM_MBR_LEP";
	public static final String EM_MBR_LIS = "EM_MBR_LIS";
	public static final String EM_MBR_LTC = "EM_MBR_LTC";
	public static final String EM_MBR_PCP = "EM_MBR_PCP";
	public static final String EM_TABLE_BEQ = "BEQR";

	public static final String EM_TABLE_MBD = "MBD";
	public static final String ENBCMAQUES = "ENBCMAQUES";
	public static final String ENBQUEST = "ENBQUEST";
	public static final String ENBQUESTVAL = "ENBQUESTVAL";
	public static final String ERROR_ADDING_SEGMENT = "Error Adding Segment";
	public static final String ERROR_ENROLLED_PCP_VALIDATION = "Error during Enrolled PCP Validation check";
	public static final String ERROR_INSERT = "Error occured while insert";
	public static final String ERROR_INSERTING_OOA_DISENROLL_TRANSACTION_TRIGGER = "Error inserting ooa disenroll transaction trigger";
	public static final String ERROR_OCCURED_WHILE_FETCHING_MAX_LASTUPDATED = "Error occured while fetching max last updated time";
	public static final String ERROR_OCCURED_WHILE_FETCHING_SEGMENTS = "Error occured while fetching segments";
	public static final String ERROR_OCCURED_WHILE_INSERTING_NEW_SEGMENT = "Error occured while inserting new segment";
	public static final String ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT = "Error occured while overriding segment";
	public static final String ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_ABOVE = "Error Overriding Segment Above";
	public static final String ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_BELOW = "Error Overriding Segment Below";
	public static final String ERROR_OCCURED_WHILE_VALIDATE_AGENT = "Error during Enrolled Agent Validation check";
	public static final String ERROR_OVERRIDING_SEGMENT = "Error Overriding Segment";
	public static final String ERROR_RETRIEVAL = "Error occured while retrieving";
	public static final String ERROR_SPLITING_SEGMENT_BELOW = "Error Spliting Segment Below";
	public static final String ERROR_STATUS_CLOSED = "CLOSED";
	public static final String ERROR_STATUS_OPEN = "OPEN";
	public static final String ERROR_UPDATE = "Error occured while update";
	public static final String FAILED_TO_DOWNLOAD_PDF = "Failed To Download PDF";
	public static final String FAILED_TO_LOAD_DOWNLOAD_PDF = "PDF Not available";
	public static final String FAILURE = "FAILURE";
	public static final String HOLD = "HOLD";

	public static final String INACTIVE = "I";
	public static final String INBOUND_INCOMPLETE = "INBOUND_INCOMPLETE";
	public static final String INBOUND_INITIAL = "INBOUND_INITIAL";
	public static final String INBOUND_LATE = "INBOUND_LATE";
	public static final String INCMPLTCOB = "INCMPLTCOB";
	public static final String INCOMPLETE = "C";
	public static final String INSERT_UPDATE_ERROR = "Error occured while %s";
	public static final String INVALID_CRED = "INVALID CREDENTIALS";
	public static final String LEP = "lep";
	public static final String LEP_CALCULATION_FLAG = "LEPCALC";
	public static final String LETTERS = "letters";
	public static final String LIS = "lis";

	public static final String LOB_VALD = "LOB_VALD";
	public static final String LTC = "ltc";
	public static final String LTC_QUES = "LTC_QUES";
	public static final int LTR_REVIEW_MAXRECORDCOUNT = 50;
	public static final String MARITAL_STATUS_U = "U";
	public static final String MAX_SESSION_EXPIRED = "This session has been expired (possibly due to multiple concurrent logins being attempted as the same user)";
	public static final String MBD_AGGREMENT = "MBD_DATA_USE";
	public static final String MBI = "MBI";
	public static final String MBR_REASON_127_READY = "127READY";
	public static final String MBR_REASON_127_REJECT = "127REJECT";
	public static final String MBR_REASON_CMS_READY = "CMSREADY";
	public static final String MBR_REASON_CMS_SUBMIT = "CMSSUBMIT";
	public static final String MBR_REASON_DENIEDDIS = "DENIEDDIS";

	public static final String MBR_REASON_DPENDRFI = "DPENDRFI";
	public static final String MBR_REASON_DUPDISENR = "DUPDISENR";
	public static final String MBR_SRCE_APPL = "A";
	public static final String MBR_SRCE_PLAN = "P";
	public static final String MBR_STAT_DAPRV = "DAPRV";

	public static final String MBR_STAT_DPEND = "DPEND";
	public static final String MBR_STAT_EAPRV = "EAPRV";
	public static final String MBR_STAT_EPEND = "EPEND";
	public static final String MBRIDLIT = "MBRIDLIT";
	public static final String MBRNBRFRMT = "MBRNBRFRMT";
	public static final String MED = "MED";
	public static final String MEDICAID = "MEDICAID";
	public static final String MEMBER = "MEMBER";
	public static final String NEXT_APP_ID = "APP";
	public static final String NEXT_SUP_ID = "SUP";
	public static final String NO = "No";

	public static final String NOICD = "NOICD";
	public static final String NON_WF_USER = "N";
	public static final int NOTIFY_BEFORE_PWD_EXPIRY = 10;
	public static final String OOA = "ooa";

	public static final String OPEN = "OPEN";
	public static final String OPTION_APPLNEWMBR_MA = "NMA";

	public static final String OPTION_APPLNEWMBR_PD = "NPD";
	public static final String OPTION_CNTRCHG_MA = "CMA";

	public static final String OPTION_CNTRCHG_PD = "CPD";
	public static final String OUTBOUND_INCOMPLETE = "OUTBOUND_INCOMPLETE";
	public static final String OUTBOUND_INITIAL = "OUTBOUND_INITIAL";
	public static final String OVERRIDE_IND_N = "N";
	public static final String PASS_EXPIRY_NOTIFICATION = "Your password is going to expire!";
	public static final String PCP = "pcp";
	public static final String PCPNBR = "pcpNbr";
	public static final String PLAN_DESGN_CO = "CO";

	public static final String PLAN_DESGN_COPD = "COPD";
	public static final String PLAN_DESGN_MA = "MA";
	public static final String PLAN_DESGN_MAPD = "MAPD";
	public static final String PLAN_DESGN_PDP = "PDP";
	public static final String PLAN_TYPE_COST = "COST";
	public static final String PLAN_TYPE_PFFS = "PFFS";
	public static final String POS = "pos";
	public static final String PRE_ENROLL_STATUS = "PreEnrollStatus";
	public static final String PREVMBROVR = "PREVMBROVR";
	public static final String PRINTIDC = "PRINTIDC";
	public static final String PRINTIDC_TEXT = "PRINTIDC_TEXT";
	public static final String PROCESS_SOURCE_MBR = "MEMBER";
	public static final String PROFILE = "PROFILE";
	public static final String PRTY1VAL = "1";
	public static final String PRTY2VAL = "2";
	public static final String PRTY3VAL = "3";
	public static final String PRTY4VAL = "4";
	public static final String REASSIGN_TYPECD_AW = "AW";
	public static final String REASSIGN_TYPECD_TW = "TW";
	public static final String RECORD_TYPE_APPL = "A";
	public static final String RECORD_TYPE_MBR = "M";
	public static final String RFI_TRACKING_STATUS = "RFITrackingStatus";

	public static final String RXID = "RXID";
	public static final String RXID_CUST_SUPPLIED = "C";

	public static final String RXID_DERIVED = "D";
	public static final String RXID_USE_SUPPLID = "S";
	public static final String SELECT = "Select";
	public static final String SERVICES = "SERVICES";
	public static final String SESSION_EXPIRED = "Session Expired, Please Login Again";
	public static final String SKIP_SUPPLID = "SKPSUPPFIX";
	public static final String SUBSCID = "SUBSCID";
	public static final String SUBSCID_TEXT = "SUBSCID_TEXT";
	public static final String SUCCESS = "SUCCESS";
	public static final String SUPER_USER = "SUPUSER";
	public static final String SUPPFIX = "SUPPFIX";
	public static final String SUPPLDUP = "SUPPLDUP";
	public static final String SUPPLID = "SUPPLID";
	public static final String SUPPLID_CUST_SUPPLIED = "C";
	public static final String SUPPLID_GENERATED = "G";
	public static final String SUPPLID_TEXT = "SUPPLID_TEXT";

	public static final String TC73TRIG = "TC73TRIG";
	public static final String TOKEN = "TOKEN";
	public static final String TRIG_CODE_72 = "72RX";
	public static final String TRIG_CODE_73 = "73NM";
	public static final String TRIG_CODE_75 = "75PW";
	public static final String TRIG_CODE_76 = "76SC";
	public static final String TRIG_CODE_77 = "77SG";
	public static final String TRIG_CODE_78 = "78CA";
	public static final String TRIG_CODE_79 = "79DO";
	public static final String TRIG_CODE_DANOC = "DANOC";
	public static final String TRIG_CODE_DANOC_VAL = "101";
	public static final String TRIG_CODE_DCONF = "DCONF";
	public static final String TRIG_CODE_DCONF_VAL = "100";
	public static final String TRIG_CODE_DDENTAL = "DDENTAL";
	public static final String TRIG_CODE_DDENTAL_VAL = "104";
	public static final String TRIG_CODE_DEOC = "DEOC";

	public static final String TRIG_CODE_DEOC_VAL = "103";

	public static final String TRIG_CODE_DFORM = "DFORM";
	public static final String TRIG_CODE_DFORM_VAL = "105";
	public static final String TRIG_CODE_DISENROLL = "51DI";
	public static final String TRIG_CODE_DISENROLL_OOA = "51OA";
	public static final String TRIG_CODE_DPROV = "DPROV";
	public static final String TRIG_CODE_DPROV_VAL = "102";
	public static final String TRIG_CODE_DVISION = "DVISION";

	public static final String TRIG_CODE_DVISION_VAL = "106";
	public static final String TRIG_CODE_ENROLL = "61ER";
	public static final String TRIG_CODE_IDCARD = "IDCARD";
	public static final String TRIG_CODE_LE21 = "LE21";
	public static final String TRIG_CODE_LEP_MAX_14 = "MCT";
	public static final String TRIG_CODE_LEP_MAX_90 = "MDT";
	public static final String TRIG_CODE_OBC1 = "OBC1";
	public static final String TRIG_CODE_OBC2 = "OBC2";
	public static final String TRIG_CODE_OBC3 = "OBC3";
	public static final String TRIG_CODE_OPRD = "OPRD";
	public static final String TRIG_CODE_POS = "90PO";
	public static final String TRIG_CODE_SO_ENROLL = "61SO";
	public static final String TRIG_FUNC_RFI_ENRL = "RFI";
	public static final String TRIG_PROCESS_SOURCE_WEBENRL = "WENR";
	public static final String TRIG_PROCESS_SOURCE_WEBENRSP = "WENRSP";
	public static final String TRIG_STATUS_CLOSED = "CLOSED";
	public static final String TRIG_STATUS_EXPIRED = "EXPIRED";
	public static final String TRIG_STATUS_OPEN = "OPEN";
	public static final String TRIG_TYPE_FOLLOWUP_APPL = "FUA";
	public static final String TRIG_TYPE_FOLLOWUP_MEMB = "FUM";
	public static final String TRIG_TYPE_ICO = "ICO";
	public static final String TRIG_TYPE_MANUAL_LTR = "LTO";
	public static final String TRIG_TYPE_TXN = "TXN";
	public static final String TRR = "trr";
	public static final String UNASSIGNED = "UNASSIGNED";
	public static final String VALSIGNAGT = "VALSIGNAGT";

	public static final String VALUE_NO = "N";
	public static final String VALUE_YES = "Y";

	public static final String WEBAPPL = "WEBAPPL";

	public static final String WF_ADMIN = "A";
	public static final String WF_NORMAL_USER = "U";
	public static final String WF_SUPERVISOR = "S";

	public static final String WFMXUSRLMT = "WFMXUSRLMT";
	public static final String WFOPTIN = "WFOPTIN";

	public static final String WFSUPDSHLT = "WFSUPDSHLT";
	public static final String WFUSRDSHLT = "WFUSRDSHLT";

	public static final String YES = "Yes";
	public static final String CLOSED = "CLOSED";

	public static final String LEPTRGSKIP = "LEPTRGSKIP";

	public static final String DATA_NOT_FOUND = "Data Not Found";
	public static final String PRIMARY_ADDRESS_DELETE = "Delete of Primary Address in not allowed Please model segment instead";
	public static final String CACHE_REMOVED = "Cache cleared sucessfully";
	public static final String SOMETHING_WENT_WRONG = "Something Went Wrong";

}
