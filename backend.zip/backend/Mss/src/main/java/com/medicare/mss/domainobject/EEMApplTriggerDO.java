package com.medicare.mss.domainobject;

import lombok.Data;

@Data
public class EEMApplTriggerDO {

	private String applicationId;
	private String createTime;
	private String createUserid;
	private String customerId;
	private String effectiveDate;
	private String lastUpdtTime;
	private String lastUpdtUserid;
	private String origEffectiveDate;
	private String origTriggerCode;
	private String origTriggerCreateTime;
	private String origTriggerType;
	private String triggerCode;
	private String triggerStatus;
	private String triggerType;

}
