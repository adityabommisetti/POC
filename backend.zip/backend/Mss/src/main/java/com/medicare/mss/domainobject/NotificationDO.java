package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class NotificationDO {

	@ColumnMapper(columnName = "TITLE", propertyName = "msgTitle")
	private String msgTitle;
	@ColumnMapper(columnName = "DESCRIPTION", propertyName = "msgDesc")
	private String msgDesc;
	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;
	@ColumnMapper(columnName = "CREATE_TIMESTAMP", propertyName = "notifTimeStamp")
	private String notifTimeStamp;

}
