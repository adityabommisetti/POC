package com.medicare.mss.vo;

import java.io.Serializable;

import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
public class BillingMbrPymntDtlInvcVO implements Serializable {

	private static final long serialVersionUID = -3424437214955446712L;
	private String customerId;

	private String paySourceType;

	private String batchDate;

	private int batchSeqNbr;

	private int itemNbr;

	private int invoiceNbr;

	private String appliedAmt;

	private String invoiceType;

	private String dueDate;

	private String createTime;

	private String createUserId;

	private String lastUpdtTime;

	private String lastUpdtUserId;

	public String getBatchDateFrmt() {
		return DateFormatter.reFormat(batchDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getDueDateFrmt() {
		return DateFormatter.reFormat(dueDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

}
