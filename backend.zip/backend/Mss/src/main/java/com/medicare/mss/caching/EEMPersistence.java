
package com.medicare.mss.caching;

import static com.medicare.mss.util.StringUtil.nonNullTrim;
import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.domainobject.BillingBankDetailsDO;
import com.medicare.mss.domainobject.EEMApplFieldErrorDO;
import com.medicare.mss.domainobject.EEMAttestationDO;
import com.medicare.mss.domainobject.EEMBillFuncDO;
import com.medicare.mss.domainobject.EEMBillingFunctionCodeDO;
import com.medicare.mss.domainobject.EEMLtcFacilityDO;
import com.medicare.mss.domainobject.EEMMbrLtcInfoDO;
import com.medicare.mss.domainobject.EEMProfileItemDO;
import com.medicare.mss.domainobject.NamedItem;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.ApplFieldErrorRowMapper;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.vo.CPMDateVO;
import com.medicare.mss.vo.EEMProfileVO;

@Repository
public class EEMPersistence {

	@Autowired
	private CacheManager cacheManager;
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Cacheable(value = "getAllLetterList", key = "#customerId")
	public List<LabelValuePair> getAllLetterList(String customerId) {

		try {
			StringBuilder sQuery = new StringBuilder("SELECT LETTER_NAME, DESCRIPTION  ")
					.append("FROM EM_CORR_CTL WHERE CUSTOMER_ID = '" + customerId + "'");

			String sName = "LETTER_NAME";
			String sValue = "DESCRIPTION";

			return getLabelValuePaired(sQuery.toString(), sName, sValue);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "LETTER DESCRIPTION FETCHING ERROR");
		}
	}

	@Cacheable(value = "getLstPlanId", key = "#customerNbr")
	public List<LabelValuePair> getLstPlanId(String customerNbr) {
		try {
			StringBuilder sQuery = new StringBuilder("SELECT PLAN_ID FROM SECPLAN WHERE CUST_NBR = '" + customerNbr
					+ "' AND ACTIVE_YN != 'N' UNION DISTINCT ")
							.append(" SELECT MMP_PLAN_ID AS PLAN_ID FROM STATEMMP WHERE STATE_CUST_NBR = '"
									+ customerNbr + "' ORDER BY PLAN_ID ");

			String sValue = "PLAN_ID";
			String sName = "PLAN_ID";

			return getLabelValuePair(sQuery.toString(), sName, sValue);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "PLAN ID FETCHING ERROR");
		}
	}

	@Cacheable(value = "getApplicationFieldErrorDetails", key = "#customerId")
	public List<EEMApplFieldErrorDO> getApplicationFieldErrorDetails(String customerId) {
		String query = "SELECT * FROM ("
				+ "SELECT FE.FORM_NAME,FE.TABLE_NAME, FE.ERROR_CD, EM.ERROR_TYPE, EM.ERROR_MESSAGE,"
				+ " FE.FORM_FIELD, FE.REQUIRED_IND, FE.EDIT_RULE_ID, FE.FIELD_NBR,"
				+ " FE.CUSTOMER_ID, ER.EDIT_VALID_VALUE, ER.EXCEPTION_VALUE,"
				+ " ER.EDIT_FROM_VALID_VALUE, ER.EDIT_TO_VALID_VALUE" + " FROM EM_FIELD_EDITS FE"
				+ " JOIN EM_EDITRULES ER" + " ON ER.EDIT_RULE_ID = FE.EDIT_RULE_ID" + " JOIN EM_ERROR_MESSAGE EM"
				+ " ON EM.ERROR_CD = FE.ERROR_CD" + " WHERE FE.CUSTOMER_ID = ?" + " AND FE.FORM_NAME IN ('eemApplForm',"
				+ EEMConstants.EEM_APPL_VOS + ")"
				// + " AND FE.FORM_NAME IN ("+formName+")"
				+ " UNION ALL" + " SELECT FE.FORM_NAME,FE.TABLE_NAME, FE.ERROR_CD, EM.ERROR_TYPE, EM.ERROR_MESSAGE,"
				+ " FE.FORM_FIELD, FE.REQUIRED_IND, FE.EDIT_RULE_ID, FE.FIELD_NBR,"
				+ " FE.CUSTOMER_ID, ER.EDIT_VALID_VALUE, ER.EXCEPTION_VALUE,"
				+ " ER.EDIT_FROM_VALID_VALUE, ER.EDIT_TO_VALID_VALUE" + " FROM EM_FIELD_EDITS FE"
				+ " JOIN EM_EDITRULES ER" + " ON ER.EDIT_RULE_ID = FE.EDIT_RULE_ID" + " JOIN EM_ERROR_MESSAGE EM"
				+ " ON EM.ERROR_CD = FE.ERROR_CD" + " WHERE FE.CUSTOMER_ID = '9999999'"
				+ " AND FE.FORM_NAME IN ('eemApplForm'," + EEMConstants.EEM_APPL_VOS + ") "
				// + " AND FE.FORM_NAME IN ("+formName+") "
				+ " AND NOT EXISTS (SELECT 1 FROM EM_FIELD_EDITS FE2" + " WHERE FE2.CUSTOMER_ID = ?"
				+ " AND FE2.FIELD_NBR = FE.FIELD_NBR)" + ") AS RESULTS ORDER BY RESULTS.FORM_NAME";

		return jdbcTemplate.query(query, new String[] { customerId, customerId }, new ApplFieldErrorRowMapper());
	}

	@Cacheable("getMapCounty")
	public Map<String, List<LabelValuePair>> getMapCounty() {
		String sQuery = " SELECT STATE_CD, COUNTY_CD, COUNTY_NAME FROM COUNTY ORDER BY STATE_CD ";
		String sKey = "STATE_CD";
		String sName = "COUNTY_CD";
		String sValue = "COUNTY_NAME";
		return getMap(sQuery, sKey, sName, sValue);
	}

	@Cacheable("getLstErrorCodes")
	public List<LabelValuePair> getLstErrorCodes() {
		String sQuery = "SELECT ERROR_CD, ERROR_MESSAGE FROM EM_ERROR_MESSAGE";
		String value = "ERROR_CD";
		String label = "ERROR_MESSAGE";
		return this.getLabelValuePairList(sQuery, value, label);
	}

	private List<LabelValuePair> getLabelValuePairList(String sQuery, String value, String label) {
		return jdbcTemplate.query(sQuery, (ResultSet row) -> {
			List<LabelValuePair> labelValuePairList = new ArrayList<>();
			while (row.next())
				labelValuePairList
						.add(new LabelValuePair(nonNullTrim(row.getString(value)), nonNullTrim(row.getString(label))));
			return labelValuePairList;
		});
	}

	private Map<String, String> getMap(String sQuery, String sValue, String sDesc) {

		return jdbcTemplate.query(sQuery, (ResultSet res) -> {
			Map<String, String> map = new HashMap<>();
			while (res.next()) {
				map.put(nonNullTrim(res.getString(sValue)), nonNullTrim(res.getString(sDesc)));
			}
			return map;
		});
	}

	public Map<String, List<LabelValuePair>> getMap(String sQuery, String sKey, String sName, String sValue) {

		return jdbcTemplate.query(sQuery, (ResultSet res) -> {
			String tempKey = "";
			Map<String, List<LabelValuePair>> hmpArr = new HashMap<>();
			while (res.next()) {
				LabelValuePair nvp = new LabelValuePair(nonNullTrim(res.getString(sValue)),
						nonNullTrim(res.getString(sName)));
				tempKey = nonNullTrim(res.getString(sKey));
				if (!hmpArr.containsKey(tempKey)) {
					List<LabelValuePair> tempList = new ArrayList<>();
					tempList.add(nvp);
					hmpArr.put(tempKey, tempList);
				} else {
					List<LabelValuePair> list = hmpArr.get(tempKey);
					list.add(nvp);
					hmpArr.put(tempKey, list);
				}
			}
			return hmpArr;
		});
	}

	public List<LabelValuePair> getLabelValuePair(String sQuery, String sValue, String sDesc) {

		return jdbcTemplate.query(sQuery, (ResultSet res) -> {
			List<LabelValuePair> hmp = new ArrayList<>();
			while (res.next()) {
				String value = nonNullTrim(res.getString(sValue));
				String desc = nonNullTrim(res.getString(sDesc));
				LabelValuePair pair = new LabelValuePair(value, desc);
				hmp.add(pair);
			}
			return hmp;
		});
	}

	private ArrayList<NamedItem> getRelatedListBox(String sQuery, String sKey, String sName, String sValue) {

		return jdbcTemplate.query(sQuery, (ResultSet res) -> {
			String tempKey = "";
			String rdKey;
			ArrayList<NamedItem> lstMaster = new ArrayList<>();
			List<LabelValuePair> tempList = new ArrayList<>();
			while (res.next()) {
				rdKey = nonNullTrim(res.getString(sKey));
				LabelValuePair pair = new LabelValuePair(nonNullTrim(res.getString(sName)),
						nonNullTrim(res.getString(sValue)));
				if (tempKey.equals("")) {
					tempKey = rdKey;
				} else if (!rdKey.equals(tempKey)) {
					NamedItem ni = new NamedItem(tempKey, tempList);
					lstMaster.add(ni);
					tempKey = rdKey;
					tempList = new ArrayList<>();
				}
				tempList.add(pair);
			}
			if (!tempList.isEmpty()) {
				NamedItem ni = new NamedItem(tempKey, tempList);
				lstMaster.add(ni);
			}
			return lstMaster;
		});
	}

	@Cacheable("getStateList")
	public List<LabelValuePair> getLstStates() {
		String sQuery = "SELECT STATE_CD, STATE_ABBR FROM STATE ORDER BY STATE_ABBR";
		String sName = "STATE_CD";
		String sValue = "STATE_ABBR";

		return getLabelValuePair(sQuery, sName, sValue);
	}

	@Cacheable("getLstSepExceptions")
	public List<EEMAttestationDO> getLstSepExceptions() {

		try {
			String sQuery = "SELECT ATTEST_IND, ATTEST_DESC, DATE_REQUIRED_IND FROM EM_ATTESTATION";

			return jdbcTemplate.query(sQuery, new RowMapper<EEMAttestationDO>() {
				@Override
				public EEMAttestationDO mapRow(ResultSet rs, int arg1) throws SQLException {
					EEMAttestationDO attVO = new EEMAttestationDO();
					attVO.setValue(nonNullTrim(rs.getString("ATTEST_IND")));
					attVO.setLabel(nonNullTrim(rs.getString("ATTEST_DESC")));
					attVO.setDateRequiredInd(nonNullTrim(rs.getString("DATE_REQUIRED_IND")));
					return attVO;
				}
			});
		} catch (Exception exp) {
			throw new ApplicationException(exp);
		}
	}

	@Cacheable(value = "getCustProf", key = "#mfId")
	public List<EEMProfileItemDO> getCustProf(String mfId) {

		try {
			String query = CommonUtils.buildQuery(
					"SELECT EFF_START_DATE,EFF_END_DATE,PARM_CD,PARM_TEXT_VALUE,PARM_NBR_VALUE,PARM_IND_VALUE,PARM_DATE_VALUE,PARM_DESC",
					"FROM EM_PROFILE WHERE CUSTOMER_ID = ? UNION ALL",
					"SELECT EFF_START_DATE,EFF_END_DATE,PARM_CD,PARM_TEXT_VALUE,PARM_NBR_VALUE,PARM_IND_VALUE,PARM_DATE_VALUE,PARM_DESC",
					"FROM EM_PROFILE P1 WHERE CUSTOMER_ID = '9999999' ",
					"AND NOT EXISTS (SELECT 1 FROM EM_PROFILE P2 WHERE P2.PARM_CD = P1.PARM_CD AND P2.CUSTOMER_ID = ?)");

			return jdbcTemplate.query(query, new RowMapper<EEMProfileItemDO>() {
				@Override
				public EEMProfileItemDO mapRow(ResultSet rs, int rowNum) throws SQLException {
					EEMProfileItemDO profileDO = new EEMProfileItemDO();
					profileDO.setEffStartDate(nonNullTrim(rs.getString("EFF_START_DATE")));
					profileDO.setEffEndDate(nonNullTrim(rs.getString("EFF_END_DATE")));
					profileDO.setParmCd(nonNullTrim(rs.getString("PARM_CD")));
					profileDO.setParmTextValue(nonNullTrim(rs.getString("PARM_TEXT_VALUE")));
					profileDO.setParmNumberValue(rs.getInt("PARM_NBR_VALUE"));
					profileDO.setParmIndValue(nonNullTrim(rs.getString("PARM_IND_VALUE")));
					profileDO.setParmDateValue(nonNullTrim(rs.getString("PARM_DATE_VALUE")));
					profileDO.setParmDesc(nonNullTrim(rs.getString("PARM_DESC")));

					return profileDO;
				}
			}, mfId, mfId);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp);
		}
	}

	@Cacheable("getLstPrefix")
	public List<LabelValuePair> getLstPrefix() {
		String sQuery = "SELECT PREFIX FROM EM_PREFIX";
		String sName = "PREFIX";
		String sValue = "PREFIX";

		return getLabelValuePair(sQuery, sName, sValue);
	}

	@Cacheable("populateGroupServices")
	public Map<String, List<String>> populateGroupServices() {
		Map<String, List<String>> services = null;
		try {
			StringBuilder sql = new StringBuilder(" SELECT DISTINCT SERVICE_ID ,GROUP_ID FROM SECGROUP_SERVICE WHERE  ")
					.append(" SERVICE_ID IN ('FTS','HII','ERS','BE0','ERP','RXR','RP','ILMR','TXMR','NMMR','R4C','WRO0','EDS',")
					.append("'RAX','RAE','RAD','RAU','IF','RCC', ")
					.append("'QAP','QAM','QAS','QAR','QLP','QLM','QLS','QLR','QCD','OLP', 'BOR','FTE','OEV','ELID','JAS','RESQ',")
					.append("'EEM','EEMU','EEMS','EEMA','EEUA','EEMM','EEUM','EEMB','EEUB','EEML','EEUL','EEMG','EEUG', ")
					.append("'HPE','HPEU','EEMT','EEGW','EESS','EMAO','EMAV','EMAB','EMAR','EMDA','EEMD','EMCB','EEMN','EMCM','EMUC', ")
					.append("'MRA','MRD','MRP','NMA','NMD','NMP','TXA','TXD','TXP','MNMR','MNA','MND','MNP0','MNPP','MNRA','MNRD', ")
					.append("'EMDM','EMDN','EMDD','EMLU','EMBU','EMAU','EMCU','EMPU','EMAD','EMDU','EMPW','EMOU','EMPN','EMSA','EMDI', ")
					.append("'EMDL','EMBR','EMEL','EMLP','EMLR','EMUT','EMNA','EMUL', ")
					.append("'EEWF','EMLL','FLFM' ,'EDSB','VPDF', 'MBIC', 'EEAS'  ,'VLTC', 'DBRD', 'BNSF' )");

			services = jdbcTemplate.query(sql.toString(), new ResultSetExtractor<Map<String, List<String>>>() {

				@Override
				public Map<String, List<String>> extractData(ResultSet res) throws SQLException {
					Map<String, List<String>> serviceMap = new HashMap<>();
					while (res.next()) {
						String groupId = nonNullTrim(res.getString("GROUP_ID"));
						String serviceId = nonNullTrim(res.getString("SERVICE_ID"));
						if (serviceMap.containsKey(groupId)) {
							List<String> list = serviceMap.get(groupId);
							list.add(serviceId);
							serviceMap.put(groupId, list);
						} else {
							List<String> lstArr = new ArrayList<>();
							lstArr.add(serviceId);
							serviceMap.put(groupId, lstArr);
						}
					}
					return serviceMap;
				}
			});
		} catch (Exception exp) {
			throw new ApplicationException(exp);
		}
		return services;
	}

	@Cacheable("populateEEMProfileCache")
	public Map<String, EEMProfileVO> populateEEMProfileCache() {
		Map<String, EEMProfileVO> profileCache = null;
		try {
			String query = "SELECT * FROM EM_PROFILE WHERE OVERRIDE_IND = ? ";

			profileCache = jdbcTemplate.query(query, new Object[] { "N" },
					new ResultSetExtractor<Map<String, EEMProfileVO>>() {
						@Override
						public Map<String, EEMProfileVO> extractData(ResultSet res) throws SQLException {
							Map<String, EEMProfileVO> eemProfiles = new HashMap<>();
							while (res.next()) {
								EEMProfileVO eemProfileVO = new EEMProfileVO();
								eemProfileVO.setCustomerId(nonNullTrim(res.getString("CUSTOMER_ID")));
								eemProfileVO.setEffectiveStartDate(nonNullTrim(res.getString("EFF_START_DATE")));
								eemProfileVO.setEffectiveEndDate(nonNullTrim(res.getString("EFF_END_DATE")));
								eemProfileVO.setParmCode(nonNullTrim(res.getString("PARM_CD")));
								eemProfileVO.setParmTextValue(nonNullTrim(res.getString("PARM_TEXT_VALUE")));
								eemProfileVO.setParmNumberValue(nonNullTrim(res.getString("PARM_NBR_VALUE")));
								eemProfileVO.setParmIndValue(nonNullTrim(res.getString("PARM_IND_VALUE")));
								eemProfileVO.setParmDateValue(nonNullTrim(res.getString("PARM_DATE_VALUE")));
								eemProfileVO.setParmDescription(nonNullTrim(res.getString("PARM_DESC")));
								eemProfileVO.setOverrideInd(nonNullTrim(res.getString("OVERRIDE_IND")));
								eemProfileVO.setLastUpdatedUserId(nonNullTrim(res.getString("LAST_UPDT_USERID")));
								eemProfiles.put(eemProfileVO.getCustomerId() + "_" + eemProfileVO.getParmCode(),
										eemProfileVO);
							}
							return eemProfiles;
						}
					});
		} catch (Exception exp) {
			throw new ApplicationException(exp);
		}
		return profileCache;
	}

	@Cacheable("getLstGrpAddrTypes")
	public List<LabelValuePair> getLstGrpAddrTypes() {
		String sQuery = "SELECT GRPADDRESS_TYPE, GRPADDRESSTYPE_DESC FROM EM_GRPADDRESSTYPE ORDER BY GRPADDRESS_TYPE";
		String sValue = "GRPADDRESS_TYPE";
		String sDesc = "GRPADDRESSTYPE_DESC";

		return getLabelValuePair(sQuery, sValue, sDesc);
	}

	@Cacheable("getLstDsVV")
	public List<LabelValuePair> getLstDsVV() {
		String sQuery = "SELECT DS_CD, DS_VALID_VALUE FROM EM_DSCODE_VV WHERE DS_CD != 'MED' ORDER BY DS_CD";
		String sValue = "DS_CD";
		String sDesc = "DS_VALID_VALUE";

		return getLabelValuePair(sQuery, sValue, sDesc);
	}

	@Cacheable("getLstUserDsCodes")
	public List<LabelValuePair> getLstUserDsCodes() {
		String sQuery = "SELECT DS_CD, DS_DESC FROM EM_DSCODE ORDER BY DS_CD";
		String sValue = "DS_CD";
		String sDesc = "DS_DESC";

		return getLabelValuePaired(sQuery, sValue, sDesc);
	}

	@Cacheable("getLstAddrTypes")
	public List<LabelValuePair> getLstAddrTypes() {
		String sQuery = "SELECT ADDRESS_TYPE, ADDRESSTYPE_DESC FROM EM_ADDRESSTYPE";
		String sValue = "ADDRESS_TYPE";
		String sDesc = "ADDRESSTYPE_DESC";

		return getLabelValuePair(sQuery, sValue, sDesc);
	}

	@Cacheable("getLstMemberStatus")
	public List<LabelValuePair> getLstMemberStatus() {
		String sQuery = "SELECT MEMBER_STATUS, MEMBERSTATUS_DESC FROM EM_MEMBERSTATUS";
		String sName = "MEMBER_STATUS";
		String sValue = "MEMBER_STATUS";

		return getLabelValuePair(sQuery, sValue, sName);
	}

	@Cacheable("getLstLiPercent")
	public List<LabelValuePair> getLstLiPercent() {
		String sQuery = "SELECT LIS_PCT_CD, LIS_PCT_DESC FROM EM_LIS_PCT";
		String sName = "LIS_PCT_DESC";
		String sValue = "LIS_PCT_CD";

		return getLabelValuePair(sQuery, sValue, sName);
	}

	@Cacheable("getLstLiCopay")
	public List<LabelValuePair> getLstLiCopay() {
		String sQuery = "SELECT LI_COPAY_CD, LI_COPAY_DESC FROM EM_LI_COPAY";
		String sName = "LI_COPAY_CD";
		String sValue = "LI_COPAY_DESC";

		return getLabelValuePair(sQuery, sValue, sName);
	}

	@Cacheable("getLstTriggerStatus")
	public List<LabelValuePair> getLstTriggerStatus() {
		String sQuery = "SELECT TRIGGER_STATUS, TRIGGERSTATUS_DESC FROM EM_TRIGGERSTATUS";
		String sName = "TRIGGER_STATUS";
		String sValue = "TRIGGERSTATUS_DESC";

		return getLabelValuePair(sQuery, sName, sValue);
	}

	@Cacheable("getLstTriggerType")
	public List<LabelValuePair> getLstTriggerType() {
		String sQuery = "SELECT TRIGGER_TYPE, TRIGGERTYPE_DESC FROM EM_TRIGGERTYPE";
		String sName = "TRIGGER_TYPE";
		String sValue = "TRIGGERTYPE_DESC";

		return getLabelValuePair(sQuery, sName, sValue);
	}

	@Cacheable("getLstTriggerCodes")
	public List<LabelValuePair> getLstTriggerCodes(String type) {

		StringBuilder sQuery = new StringBuilder("SELECT TRIGGER_CODE, TRIGGER_DESC FROM EM_TRIGGERCODE");
		if (type.equalsIgnoreCase("TimerTypes")) {
			sQuery.append(" WHERE TRIGGER_TYPE IN ('FUA', 'FUM') AND TRIGGER_CODE NOT IN ('LE21','OBC1','OBC2','OBC3')");
		}
		String sName = "TRIGGER_CODE";
		String sValue = "TRIGGER_DESC";

		return getLabelValuePair(sQuery.toString(), sName, sValue);
	}

	@Cacheable("getLstSubsidySrce")
	public List<LabelValuePair> getLstSubsidySrce() {
		String sQuery = "SELECT SUBSIDY_SRCE_CD, SUBSIDYSRCE_DESC FROM EM_SUBSIDY_SRCE";
		String sName = "SUBSIDY_SRCE_CD";
		String sValue = "SUBSIDYSRCE_DESC";

		return getLabelValuePaired(sQuery, sName, sValue);
	}

	@Cacheable("getLstEnrollStatus")
	public List<LabelValuePair> getLstEnrollStatus() {
		String sQuery = "SELECT ENROLL_STATUS FROM EM_ENROLLSTATUS";
		String sName = "ENROLL_STATUS";
		String sValue = "ENROLL_STATUS";

		return getLabelValuePair(sQuery, sName, sValue);
	}

	@Cacheable("getLstDisReasonCodes")
	public List<LabelValuePair> getLstDisReasonCodes() {
		String sQuery = "SELECT DIS_REASON_CD, DISREASON_DESC FROM EM_DISENREASON";
		String sValue = "DIS_REASON_CD";
		String sDesc = "DISREASON_DESC";

		return getLabelValuePair(sQuery, sValue, sDesc);
	}

	@Cacheable("getLstEnrollReasonCodes")
	public List<LabelValuePair> getLstEnrollReasonCodes() {
		String sQuery = "SELECT DISTINCT ENROLL_REASON_CD FROM EM_ENROLLREASON";
		String sName = "ENROLL_REASON_CD";
		String sValue = "ENROLL_REASON_CD";

		return getLabelValuePair(sQuery, sName, sValue);
	}

	@Cacheable("getLstApplStatus")
	public List<LabelValuePair> getLstApplStatus() {
		String sQuery = "SELECT APPLICATION_STATUS FROM EM_APPLICATIONSTATUS " + "ORDER BY SEVERITY_LEVEL DESC";
		String sName = "APPLICATION_STATUS";
		String sValue = "APPLICATION_STATUS";

		return getLabelValuePair(sQuery, sName, sValue);
	}

	@Cacheable("getLstUserApplStatus")
	public List<LabelValuePair> getLstUserApplStatus() {
		String sQuery = "SELECT APPLICATION_STATUS, APPLICATIONSTATUS_DESC FROM EM_APPLICATIONSTATUS "
				+ "WHERE USERSET_IND = 'U' AND APPLICATION_STATUS NOT IN ('CANCELED') ORDER BY SEVERITY_LEVEL DESC";

		String sName = "APPLICATION_STATUS";
		String sValue = "APPLICATIONSTATUS_DESC";

		return getLabelValuePair(sQuery, sName, sValue);
	}

	@Cacheable("getLstMgrApplStatus")
	public List<LabelValuePair> getLstMgrApplStatus() {
		StringBuilder sQuery = new StringBuilder(
				"SELECT APPLICATION_STATUS, APPLICATIONSTATUS_DESC FROM EM_APPLICATIONSTATUS ").append(
						"WHERE USERSET_IND IN ('U','M') AND APPLICATION_STATUS NOT IN ('CANCELED') ORDER BY SEVERITY_LEVEL DESC");

		String sName = "APPLICATION_STATUS";
		String sValue = "APPLICATIONSTATUS_DESC";

		return getLabelValuePair(sQuery.toString(), sName, sValue);
	}

	@Cacheable("getLstApplType")
	public List<LabelValuePair> getLstApplType() {
		String sQuery = "SELECT APPLICATION_TYPE FROM EM_APPLICATIONTYPE ORDER BY APPLICATION_TYPE DESC";
		String sName = "APPLICATION_TYPE";
		String sValue = "APPLICATION_TYPE";

		return getLabelValuePair(sQuery, sName, sValue);
	}

	// @Cacheable("getLstCounty")
	public List<LabelValuePair> getLstCounty(String zip5) {

		String sQuery = "SELECT DISTINCT B.COUNTY_NAME,B.COUNTY_CD FROM EM_ZIPCODE A, COUNTY B WHERE B.STATE_CD = A.SSA_ST AND B.COUNTY_CD = A.SSA_CNTY AND A.ZIP_CD5 = '"
				+ zip5 + "'"; // Prepare query based on the Requirement
		String sValue = "COUNTY_NAME";
		String sName = "COUNTY_CD";

		return getLabelValuePair(sQuery, sName, sValue);
	}

	// @Cacheable("getLstCity")
	public List<LabelValuePair> getLstCity(String zip5, String zip4, String county) {

		String sQuery = "SELECT DISTINCT CITY_NAME,SSA_ST AS VALUE FROM EM_ZIPCODE  WHERE ZIP_CD5 = '" + zip5
				+ "'  UNION SELECT DISTINCT CITY_NAME,SSA_ST_CD AS VALUE FROM EM_ZIPCITY  WHERE ZIP_CODE = '" + zip5
				+ "' AND SSA_CNTY_CD = '" + county + "'";

		String sValue = "CITY_NAME";
		String sName = "CITY_NAME";

		return getLabelValuePair(sQuery, sName, sValue);
	}

	public List<LabelValuePair> getLstCity(String zip5, String county) {

		String sQuery = "SELECT DISTINCT CITY_NAME,SSA_ST AS VALUE FROM EM_ZIPCODE  WHERE ZIP_CD5 = '" + zip5
				+ "'  UNION SELECT DISTINCT CITY_NAME,SSA_ST_CD AS VALUE FROM EM_ZIPCITY  WHERE ZIP_CODE = '" + zip5
				+ "'";
		if (!county.isEmpty())
			sQuery += " AND SSA_CNTY_CD = '" + county + "'";

		String sValue = "CITY_NAME";
		String sName = "CITY_NAME";

		return getLabelValuePair(sQuery, sName, sValue);
	}

	@Cacheable("getLstCountry")
	public List<LabelValuePair> getLstCountry() {
		String sQuery = "SELECT COUNTRY_CD, COUNTRY_NAME FROM COUNTRY ORDER BY COUNTRY_NAME";
		String sName = "COUNTRY_CD";
		String sValue = "COUNTRY_NAME";

		return getLabelValuePair(sQuery, sName, sValue);
	}

	@Cacheable("getMapStateCounty")
	public Map<String, String> getMapStateCounty() {
		String sQuery = "SELECT (STATE_CD || COUNTY_CD) AS STATE_COUNTY, COUNTY_NAME FROM COUNTY "
				+ "ORDER BY STATE_CD";
		String sKey = "STATE_COUNTY";
		String sValue = "COUNTY_NAME";

		return getMap(sQuery, sKey, sValue);
	}

	@Cacheable("getInvGrpTypes")
	public Map<String, List<String>> getInvGrpTypes() {

		String sql = "SELECT INVOICE_GROUP_CD, INVOICE_TYPE FROM BBB_INVOICETYPE GROUP BY INVOICE_GROUP_CD, INVOICE_TYPE ORDER BY INVOICE_GROUP_CD";

		return jdbcTemplate.query(sql, rs -> {
			HashMap<String, List<String>> result = new HashMap<>();
			List<String> invoiceTypes;

			while (rs.next()) {
				String invoiceGroup = rs.getString("INVOICE_GROUP_CD");
				String invoiceType = rs.getString("INVOICE_TYPE");

				if (result.containsKey(invoiceGroup)) {
					result.get(invoiceGroup).add(invoiceType);
				} else {
					invoiceTypes = new ArrayList<>();
					invoiceTypes.add(invoiceType);
					result.put(invoiceGroup, invoiceTypes);
				}
			}
			return result;
		});
	}

	@Cacheable("getLstApplDenialReasons")
	public Map<String, List<LabelValuePair>> getLstApplDenialReasons() {

		StringBuilder sQuery = new StringBuilder(
				"SELECT CUSTOMER_ID,REASON_CD, REASON_DESCRIPTION FROM EM_REQ_REASONS  ")
						.append(" WHERE REASON_TYPE='ADEN' ORDER BY CUSTOMER_ID,REASON_DESCRIPTION");
		String sKey = "CUSTOMER_ID";
		String sName = "REASON_DESCRIPTION";
		String sValue = "REASON_CD";
		return getMap(sQuery.toString(), sKey, sName, sValue);
	}

	@Cacheable("getLstOoaReason")
	public Map<String, List<LabelValuePair>> getLstOoaReason() {
		StringBuilder sQuery = new StringBuilder(
				"SELECT CUSTOMER_ID,OOA_REASON_CD, OOA_REASON_DESC FROM EM_OOA_REASON ")
						.append(" ORDER BY CUSTOMER_ID,OOA_REASON_CD");
		String sKey = "CUSTOMER_ID";
		String sValue = "OOA_REASON_CD";
		String sDesc = "OOA_REASON_DESC";

		return getMap(sQuery.toString(), sKey, sDesc, sValue);
	}

	@Cacheable("getLstOoaSource")
	public Map<String, List<LabelValuePair>> getLstOoaSource() {
		StringBuilder sQuery = new StringBuilder("SELECT CUSTOMER_ID,OOA_SRC_CD, OOA_SRC_DESC FROM EM_OOA_SOURCE ")
				.append("WHERE OOA_SRC_DESC NOT IN('TRR') ORDER BY CUSTOMER_ID,OOA_SRC_CD");
		String sKey = "CUSTOMER_ID";
		String sValue = "OOA_SRC_CD";
		String sDesc = "OOA_SRC_DESC";
		return getMap(sQuery.toString(), sKey, sDesc, sValue);
	}

	@Cacheable("getLstOoaDeReason")
	public Map<String, List<LabelValuePair>> getLstOoaDeReason() {
		StringBuilder sQuery = new StringBuilder(
				"SELECT CUSTOMER_ID,REASON_CD, REASON_DESCRIPTION FROM EM_REQ_REASONS ")
						.append("WHERE  REASON_TYPE = 'OOAD' ORDER BY CUSTOMER_ID,REASON_CD ");
		String sKey = "CUSTOMER_ID";
		String sValue = "REASON_CD";
		String sDesc = "REASON_DESCRIPTION";

		return getMap(sQuery.toString(), sKey, sDesc, sValue);
	}

	@Cacheable("getLstRejectReason")
	public Map<String, List<LabelValuePair>> getLstRejectReason() {

		StringBuilder sQuery = new StringBuilder("SELECT CUSTOMER_ID,REASON_CD,REASON_DESCRIPTION FROM EM_REQ_REASONS ")
				.append("WHERE REASON_TYPE = 'CANC' ORDER BY CUSTOMER_ID");

		String sKey = "CUSTOMER_ID";
		String sName = "REASON_DESCRIPTION";
		String sValue = "REASON_CD";

		return getMap(sQuery.toString(), sKey, sName, sValue);
	}

	@Cacheable("getLstLepNunCmoStatus")
	public List<LabelValuePair> getLstLepNunCmoStatus() {
		StringBuilder sQuery = new StringBuilder(
				"SELECT ATTESTATION_STATUS, ATTATION_STATUS_DESC FROM EM_ATTESTATION_STATUS ")
						.append("ORDER BY ATTESTATION_STATUS DESC");

		String sName = "ATTESTATION_STATUS";
		String sValue = "ATTATION_STATUS_DESC";

		return getLabelValuePair(sQuery.toString(), sName, sValue);
	}

	@Cacheable("getLabelValuePairMaximusType")
	private List<LabelValuePair> getLabelValuePairMaximusType() {

		StringBuilder sQuery = new StringBuilder("SELECT REASON_CD, REASON_DESCRIPTION FROM EM_REQ_REASONS ")
				.append(" WHERE REASON_TYPE='DECS' ORDER BY REASON_CD ASC");

		String sName = "REASON_CD";
		String sValue = "REASON_DESCRIPTION";

		return getLabelValuePair(sQuery.toString(), sName, sValue);
	}

	@Cacheable("getLstAttestStatus")
	public List<LabelValuePair> getLstAttestStatus() {
		StringBuilder sQuery = new StringBuilder("SELECT ATTESTATION_STATUS, ATTATION_STATUS_DESC FROM ")
				.append(" EM_ATTESTATION_STATUS ORDER BY ATTATION_STATUS_DESC DESC");
		String sValue = "ATTESTATION_STATUS";
		String sDesc = "ATTATION_STATUS_DESC";

		return getLabelValuePair(sQuery.toString(), sValue, sDesc);

	}

	@Cacheable("getPreSetNotes")
	public Map<String, List<LabelValuePair>> getPreSetNotes() {

		StringBuilder sQuery = new StringBuilder("SELECT CUSTOMER_ID,PRE_SET_NOTE,LONG_DESCRIPTION FROM ")
				.append(" EM_PRE_SET_NOTES ORDER BY CUSTOMER_ID,PRE_SET_NOTE ASC");

		return jdbcTemplate.query(sQuery.toString(), (ResultSet res) -> {
			Map<String, List<LabelValuePair>> hmpArr = new HashMap<>();
			List<LabelValuePair> lstArr = new ArrayList<>();
			String tempKey = "";
			while (res.next()) {
				LabelValuePair attVO = new LabelValuePair(nonNullTrim(res.getString("LONG_DESCRIPTION")),
						nonNullTrim(res.getString("PRE_SET_NOTE")));
				if (tempKey.equals("")) {
					tempKey = nonNullTrim(res.getString("CUSTOMER_ID"));
				} else if (!nonNullTrim(res.getString("CUSTOMER_ID")).equals(tempKey)) {
					hmpArr.put(tempKey, lstArr);
					tempKey = nonNullTrim(res.getString("CUSTOMER_ID"));
					lstArr = new ArrayList<>();
				}
				lstArr.add(attVO);
			}
			if (!lstArr.isEmpty()) {
				hmpArr.put(tempKey, lstArr);
			}
			return hmpArr;
		});
	}

	@Cacheable("getOevCallSubsetReason")
	public Map<String, List<LabelValuePair>> getOevCallSubsetReason() {
		String sQuery = "SELECT DISTINCT CUSTOMER_ID,CALL_SUBSET_REASON FROM EM_OEV_STATUS_DESC ORDER BY CUSTOMER_ID";
		String sKey = "CUSTOMER_ID";
		String sName = "CALL_SUBSET_REASON";
		String sValue = "CALL_SUBSET_REASON";

		return getMap(sQuery, sKey, sName, sValue);
	}

	@Cacheable("getOevCallStatus")
	public Map<String, List<LabelValuePair>> getOevCallStatus() {
		StringBuilder sQuery = new StringBuilder("SELECT CALL_SUBSET_REASON,CALL_STATUS, CALL_SUBSET_REASON_DESC ")
				.append("  FROM EM_OEV_STATUS_DESC ORDER BY CALL_STATUS, CALL_SUBSET_REASON");
		String sKey = "CALL_STATUS";
		String sValue = "CALL_SUBSET_REASON";
		String sName = "CALL_SUBSET_REASON_DESC";

		return getMap(sQuery.toString(), sKey, sName, sValue);
	}

	@Cacheable("getLstCancellationReasons")
	public Map<String, List<LabelValuePair>> getLstCancellationReasons() {
		StringBuilder sQuery = new StringBuilder(
				"SELECT CUSTOMER_ID,REASON_CD, REASON_DESCRIPTION FROM EM_REQ_REASONS ")
						.append(" WHERE REASON_TYPE='CANC' ORDER BY CUSTOMER_ID,REASON_DESCRIPTION");
		String sKey = "CUSTOMER_ID";
		String sValue = "REASON_CD";
		String sDesc = "REASON_DESCRIPTION";

		return getMap(sQuery.toString(), sKey, sDesc, sValue);
	}

	@Cacheable("getLstPlanReasonCodes")
	public List<LabelValuePair> getLstPlanReasonCodes() {
		StringBuilder sQuery = new StringBuilder("SELECT REASON_CD, REASON_DESCRIPTION FROM EM_REQ_REASONS ")
				.append(" WHERE REASON_TYPE='PRSN' ORDER BY REASON_DESCRIPTION");
		String sValue = "REASON_CD";
		String sDesc = "REASON_DESCRIPTION";

		return getLabelValuePair(sQuery.toString(), sValue, sDesc);
	}

	@Cacheable("getValidTxnStatus")
	public List<LabelValuePair> getValidTxnStatus() {
		String sQuery = " SELECT TXN90_STATUS,TXN90_DESC FROM EM_POS_TXN_STATUS ";

		String sName = "TXN90_STATUS";
		String sValue = "TXN90_DESC";

		return getLabelValuePair(sQuery, sName, sValue);
	}

	@Cacheable("getLstDraftStatus")
	public List<LabelValuePair> getLstDraftStatus() {
		StringBuilder sQuery = new StringBuilder("SELECT DRAFT_PROCESSED_IND, DRAFTPROCESSED_DESC  ")
				.append(" FROM BBB_DRAFTPROCESSED ORDER BY DRAFTPROCESSED_DESC");
		String sName = "DRAFT_PROCESSED_IND";
		String sValue = "DRAFTPROCESSED_DESC";

		return getLabelValuePair(sQuery.toString(), sName, sValue);
	}

	@Cacheable("getLstDrugEditClass")
	public List<LabelValuePair> getLstDrugEditClass() {
		String sQuery = "Select DRUG_EDIT_CLASS, DESCRIPTION FROM EM_DRUGEDITCLASS";
		String sName = "DRUG_EDIT_CLASS";
		String sValue = "DESCRIPTION";

		return getLabelValuePair(sQuery, sName, sValue);
	}

	@Cacheable("getResponseMessages")
	public Map<String, String> getResponseMessages() {

		String sQuery = "SELECT RESPONSE_CODE, RESPONSE_DESC FROM BBB_ACH_RESP_CD";

		return jdbcTemplate.query(sQuery, (ResultSet res) -> {
			Map<String, String> hmMap = new HashMap<>();
			while (res.next()) {
				hmMap.put(nonNullTrim(res.getString(1)), nonNullTrim(res.getString(2)));
			}
			return hmMap;
		});
	}

	@Cacheable("getLstLEPType")
	public List<LabelValuePair> getLstLEPType() {

		List<LabelValuePair> labelValuePairs = new ArrayList<>();
		labelValuePairs.add(new LabelValuePair("LATE ATTESTATION", "LATE ATTESTATION"));
		labelValuePairs.add(new LabelValuePair("PLAN ERROR", "PLAN ERROR"));
		labelValuePairs.add(new LabelValuePair("ADJUST BY PRIOR PLAN", "ADJUST BY PRIOR PLAN"));
		labelValuePairs.add(new LabelValuePair("DISMISS", "DISMISS"));
		labelValuePairs.add(new LabelValuePair("PLAN RESEARCH", "PLAN RESEARCH"));
		labelValuePairs.add(new LabelValuePair("ATTESTATION RECEIVED", "ATTESTATION RECEIVED"));

		return labelValuePairs;
	}

	@Cacheable("getLstLanguages")
	public List<LabelValuePair> getLstLanguages() {
		StringBuilder sQuery = new StringBuilder("SELECT LANGUAGE_CD, LANGUAGE_DESC FROM EM_LANGUAGE");

		String sName = "LANGUAGE_CD";
		String sValue = "LANGUAGE_DESC";

		return getLabelValuePair(sQuery.toString(), sName, sValue);
	}

	@Cacheable("getLstAltCorrespondences")
	public List<LabelValuePair> getLstAltCorrespondences() {

		StringBuilder sQuery = new StringBuilder(
				"SELECT ALT_CORRES_IND, ALT_CORRES_DESC  FROM EM_ALT_CORR_DESC  ORDER BY ALT_CORRES_IND");
		String sName = "ALT_CORRES_IND";
		String sValue = "ALT_CORRES_DESC";

		return getLabelValuePair(sQuery.toString(), sName, sValue);
	}

	@Cacheable("getLstPWOptions")
	public List<LabelValuePair> getLstPWOptions() {
		StringBuilder sQuery = new StringBuilder("SELECT PWO_CD, PWO_DESC FROM EM_PWO");
		String sName = "PWO_CD";
		String sValue = "PWO_DESC";

		return getLabelValuePair(sQuery.toString(), sName, sValue);
	}

	@Cacheable("getLstElectionTypes")
	public List<LabelValuePair> getLstElectionTypes() {
		StringBuilder sQuery = new StringBuilder("SELECT ELECTION_TYPE, ELECTIONTYPE_DESC FROM EM_ELECTIONTYPE");
		String sValue = "ELECTION_TYPE";
		String sDesc = "ELECTIONTYPE_DESC";

		return getLabelValuePair(sQuery.toString(), sValue, sDesc);
	}

	@Cacheable("getLstRelations")
	public List<LabelValuePair> getLstRelations() {
		StringBuilder sQuery = new StringBuilder("SELECT RELATIONSHIP_CD, RELATIONSHIP_DESC FROM EM_RELATIONSHIP");
		String sName = "RELATIONSHIP_CD";
		String sValue = "RELATIONSHIP_DESC";

		return getLabelValuePair(sQuery.toString(), sName, sValue);
	}

	@Cacheable("getLstAgentTypes")
	public List<LabelValuePair> getLstAgentTypes() {
		StringBuilder sQuery = new StringBuilder("SELECT AGENT_TYPE, AGENTTYPE_DESC FROM EM_AGENTTYPE ")
				.append("ORDER BY AGENTTYPE_DESC");
		String sName = "AGENT_TYPE";
		String sValue = "AGENTTYPE_DESC";

		return getLabelValuePair(sQuery.toString(), sName, sValue);
	}

	@Cacheable("getLstAgencyTypes")
	public List<LabelValuePair> getLstAgencyTypes() {
		StringBuilder sQuery = new StringBuilder("SELECT AGENCY_TYPE, AGENCYTYPE_DESC FROM EM_AGENCYTYPE ")
				.append("ORDER BY AGENCYTYPE_DESC");
		String sName = "AGENCY_TYPE";
		String sValue = "AGENCYTYPE_DESC";

		return getLabelValuePair(sQuery.toString(), sName, sValue);
	}

	@Cacheable("getLstEnrollSrcPlan")
	public List<NamedItem> getLstEnrollSrcPlan() {
		StringBuilder sQuery = new StringBuilder(
				"SELECT ENROLL_SRCE_CD, ENROLLSRCE_DESC, CMS_PLAN_IND FROM EM_ENROLLSOURCE ")
						.append("ORDER BY CMS_PLAN_IND, ENROLLSRCE_DESC");
		String sKey = "CMS_PLAN_IND";
		String sName = "ENROLL_SRCE_CD";
		String sValue = "ENROLLSRCE_DESC";

		return getRelatedListBox(sQuery.toString(), sKey, sName, sValue);
	}

	@Cacheable("getLstPCO")
	public List<LabelValuePair> getLstPCO() {
		StringBuilder sQuery = new StringBuilder("SELECT PCO_CD, PCO_DESC FROM EM_PCO");
		String sName = "PCO_CD";
		String sValue = "PCO_DESC";

		return getLabelValuePair(sQuery.toString(), sName, sValue);
	}

	@Cacheable("getLstSEPReasons")
	public List<LabelValuePair> getLstSEPReasons() {
		StringBuilder sQuery = new StringBuilder("SELECT EM_SEP_REASON_CD, EM_SEPREASON_DESC FROM EM_SERC ")
				.append("ORDER BY EM_SEPREASON_DESC");
		String sName = "EM_SEP_REASON_CD";
		String sValue = "EM_SEPREASON_DESC";

		return getLabelValuePair(sQuery.toString(), sName, sValue);
	}

	@Cacheable("getLstAccountType")
	public List<LabelValuePair> getLstAccountType() {
		StringBuilder sQuery = new StringBuilder("SELECT ACCOUNT_TYPE, ACCOUNTTYPE_DESC FROM BBB_ACCOUNTTYPE ")
				.append("ORDER BY ACCOUNTTYPE_DESC");
		String sName = "ACCOUNT_TYPE";
		String sValue = "ACCOUNTTYPE_DESC";

		return getLabelValuePaired(sQuery.toString(), sName, sValue);
	}

	private List<LabelValuePair> getLabelValuePaired(String sQuery, String sValue, String sDesc) {

		return jdbcTemplate.query(sQuery, (ResultSet res) -> {
			List<LabelValuePair> hmp = new ArrayList<>();
			while (res.next()) {
				String value = nonNullTrim(res.getString(sValue));
				String desc = nonNullTrim(res.getString(sDesc));
				desc = value + "-" + desc;
				LabelValuePair pair = new LabelValuePair(value, desc);

				hmp.add(pair);
			}
			return hmp;
		});
	}

	@Cacheable("getLstBillPayMethod")
	public List<LabelValuePair> getLstBillPayMethod() {
		StringBuilder sQuery = new StringBuilder(
				" SELECT BILL_PAY_METHOD_CD, BILLPAYMETHOD_DESC FROM BBB_BILLPAYMETHOD ")
						.append("ORDER BY BILLPAYMETHOD_DESC");
		String sValue = "BILL_PAY_METHOD_CD";
		String sDesc = "BILLPAYMETHOD_DESC";

		return getLabelValuePaired(sQuery.toString(), sValue, sDesc);
	}

	@Cacheable("getLstBillFrequency")
	public List<LabelValuePair> getLstBillFrequency() {

		StringBuilder sQuery = new StringBuilder("SELECT FREQUENCY_CD, FREQUENCY_DESC FROM BBB_FREQUENCY ");
		String sName = "FREQUENCY_CD";
		String sValue = "FREQUENCY_DESC";

		return getLabelValuePaired(sQuery.toString(), sName, sValue);
	}

	@Cacheable("getLstLiPercents")
	public List<LabelValuePair> getLstLiPercents() {
		StringBuilder sQuery = new StringBuilder("SELECT LIS_PCT_CD, LIS_PCT_DESC FROM EM_LIS_PCT");
		String sName = "LIS_PCT_CD";
		String sValue = "LIS_PCT_CD";

		return getLabelValuePair(sQuery.toString(), sName, sValue);
	}

	@Cacheable("getLstLiCopays")
	public List<LabelValuePair> getLstLiCopays() {
		StringBuilder sQuery = new StringBuilder("SELECT LI_COPAY_CD, LI_COPAY_DESC FROM EM_LI_COPAY");
		String sName = "LI_COPAY_DESC";
		String sValue = "LI_COPAY_CD";

		return getLabelValuePaired(sQuery.toString(), sValue, sName);
	}

	@Cacheable("getLstApplCategory")
	public Map<String, List<LabelValuePair>> getLstApplCategory() {
		StringBuilder sQuery = new StringBuilder("SELECT CUSTOMER_ID, APPLICATION_CATEGORY, APPLICATIONCATEGORY_DESC")
				.append(" FROM EM_APPLICATIONCATEGORY ORDER BY APPLICATIONCATEGORY_DESC");

		String sKey = "CUSTOMER_ID";
		String sName = "APPLICATIONCATEGORY_DESC";
		String sValue = "APPLICATION_CATEGORY";

		return getMap(sQuery.toString(), sKey, sName, sValue);
	}

	@Cacheable("getLstGender")
	public List<LabelValuePair> getLstGender() {
		StringBuilder sQuery = new StringBuilder("SELECT Gender_cd, Gender_name FROM GENDER WHERE GENDER_CD NOT IN ('1', '2') ORDER BY Gender_cd");
		String sName = "GENDER_CD";
		String sValue = "GENDER_NAME";
		return getLabelValuePair(sQuery.toString(), sName, sValue);
	}

	public String removeCache() {
		cacheManager.getCacheNames().parallelStream().forEach(name -> cacheManager.getCache(name).clear());
		return EEMConstants.CACHE_REMOVED;
	}

	public void evictSpecificCache(String cacheName) {
		cacheManager.getCache(cacheName).clear();
	}

	@Cacheable("getDsDesc")
	public List<LabelValuePair> getDsDesc() {
		String query = "SELECT DS_CD, DS_DESC FROM EM_DSCODE ORDER BY DS_CD";
		String sName = "DS_CD";
		String sValue = "DS_DESC";
		return getLabelValuePair(query, sName, sValue);
	}

	@Cacheable("getLstPlanReasonCode")
	public List<LabelValuePair> getLstPlanReasonCode(String customerId) {
		StringBuilder sQuery = new StringBuilder("SELECT REASON_CD, REASON_DESCRIPTION FROM EM_REQ_REASONS")
				.append(" WHERE REASON_TYPE='PRSN' AND CUSTOMER_ID ='" + customerId + "' ORDER BY REASON_DESCRIPTION");
		String sName = "REASON_CD";
		String sValue = "REASON_DESCRIPTION";

		return getLabelValuePair(sQuery.toString(), sName, sValue);
	}

	@Cacheable("getLstEnrollSrce")
	public List<LabelValuePair> getLstEnrollSrce() {
		StringBuilder sQuery = new StringBuilder("SELECT ENROLL_SRCE_CD, ENROLLSRCE_DESC FROM EM_ENROLLSOURCE");
		String sName = "ENROLL_SRCE_CD";
		String sValue = "ENROLLSRCE_DESC";

		return getLabelValuePair(sQuery.toString(), sName, sValue);
	}

	@Cacheable("getLstEnrollStatusReason")
	public List<NamedItem> getLstEnrollStatusReason() {
		StringBuilder sQuery = new StringBuilder(
				"SELECT ENROLL_STATUS, ENROLL_REASON_CD, ENROLL_REASON_DESC FROM EM_ENROLLREASON")
						.append(" WHERE USERSET_IND != 'S'" + " ORDER BY ENROLL_STATUS, ENROLL_REASON_CD");
		String sKey = "ENROLL_STATUS";
		String sName = "ENROLL_REASON_CD";

		return getRelatedListBox(sQuery.toString(), sKey, sName, sName);
	}

	@Cacheable("getLstMaritalStatus")
	public List<LabelValuePair> getLstMaritalStatus() {
		StringBuilder sQuery = new StringBuilder("SELECT MARITAL_STATUS, MARITALSTATUS_DESC FROM EM_MARITALSTATUS");
		String sName = "MARITAL_STATUS";
		String sValue = "MARITALSTATUS_DESC";

		List<LabelValuePair> labelValuePair = getLabelValuePair(sQuery.toString(), sName, sValue);
		labelValuePair.forEach(obj -> {

			if (obj.getLabel().equalsIgnoreCase("UNREPORTED")) {
				obj.setValue(EEMConstants.MARITAL_STATUS_U);
			}
		});
		return labelValuePair;
	}

	@Cacheable("getLstRaceCds")
	public List<LabelValuePair> getLstRaceCds() {
		StringBuilder sQuery = new StringBuilder("SELECT RACE_CD, RACE_NAME FROM RACE");
		String sName = "RACE_CD";
		String sValue = "RACE_NAME";

		return getLabelValuePair(sQuery.toString(), sName, sValue);
	}

	@Cacheable("getLstCobTypes")
	public List<LabelValuePair> getLstCobTypes() {
		StringBuilder sQuery = new StringBuilder(
				"SELECT COB_TYPE, COBTYPE_DESC FROM EM_COBTYPE " + "ORDER BY COB_TYPE");
		String sName = "COB_TYPE";
		String sValue = "COBTYPE_DESC";

		return getLabelValuePair(sQuery.toString(), sName, sValue);
	}

	@Cacheable("getLstOhiInd")
	public List<NamedItem> getLstOhiInd() {
		StringBuilder sQuery = new StringBuilder(
				"SELECT COB_TYPE, OHI_IND, OHI_DESC FROM EM_OHI " + "ORDER BY COB_TYPE, OHI_IND");
		String sKey = "COB_TYPE";
		String sName = "OHI_IND";
		String sValue = "OHI_DESC";

		return getRelatedListBox(sQuery.toString(), sKey, sName, sValue);
	}

	@Cacheable("getLstMaximusType")
	public List<LabelValuePair> getLstMaximusType() {
		StringBuilder sQuery = new StringBuilder(
				"SELECT REASON_CD, REASON_DESCRIPTION FROM EM_REQ_REASONS WHERE REASON_TYPE='DECS'")
						.append(" ORDER BY REASON_CD ASC");

		String sName = "REASON_CD";
		String sValue = "REASON_DESCRIPTION";

		return getLabelValuePair(sQuery.toString(), sName, sValue);
	}

	public List<LabelValuePair> getChannelList() {

		return getChannelListValues();
	}

	public List<LabelValuePair> getMemberAppealList() {

		return getArrYesNo();
	}

	public List<LabelValuePair> getBreakInCoverageTypeList() {

		return getArrYesNo();
	}

	public List<LabelValuePair> getRespTypeList() {

		return getChannelListValues();
	}

	@Cacheable("getLstPlanVersions")
	public List<LabelValuePair> getLstPlanVersions() {
		StringBuilder sQuery = new StringBuilder(
				"SELECT DISTINCT PLAN_VERSION FROM EM_ASES_PLNVER_XWALK ORDER BY PLAN_VERSION");
		String sName = "PLAN_VERSION";
		String sValue = "PLAN_VERSION";

		return getLabelValuePair(sQuery.toString(), sName, sValue);
	}

	@Cacheable("getLstStatuses")
	public List<LabelValuePair> getLstStatuses() {
		StringBuilder sQuery = new StringBuilder(
				"SELECT ASES_STATUS, STATUS_DESC FROM EM_ASES_STATUS ORDER BY STATUS_DESC");
		String sName = "ASES_STATUS";
		String sValue = "STATUS_DESC";

		return getLabelValuePair(sQuery.toString(), sName, sValue);
	}

	@Cacheable("getLstOevCallStatus")
	public List<NamedItem> getLstOevCallStatus(String customerId) {

		StringBuilder sQuery = new StringBuilder(
				"SELECT CALL_SUBSET_REASON,CALL_STATUS, CALL_SUBSET_REASON_DESC FROM EM_OEV_STATUS_DESC")
						.append(" WHERE CUSTOMER_ID ='" + customerId + "' ORDER BY CALL_STATUS, CALL_SUBSET_REASON");
		String sKey = "CALL_STATUS";
		String sName = "CALL_SUBSET_REASON";
		String sValue = "CALL_SUBSET_REASON_DESC";

		return getRelatedListBox(sQuery.toString(), sKey, sName, sValue);
	}

	@Cacheable("getTsaLstLanguages")
	public List<LabelValuePair> getTsaLstLanguages(String langCd) {

		StringBuilder sQuery = new StringBuilder(
				"SELECT LANGUAGE_CD, LANGUAGE_DESC FROM EM_LANGUAGE WHERE LANGUAGE_CD = '" + langCd)
						.append("' UNION ALL  SELECT LANGUAGE_CD, LANGUAGE_DESC")
						.append(" FROM EM_LANGUAGE WHERE LANGUAGE_CD <> '" + langCd + "' ");
		String sName = "LANGUAGE_CD";
		String sValue = "LANGUAGE_DESC";

		return getLabelValuePair(sQuery.toString(), sName, sValue);
	}

	@Cacheable("getLstTSACobTypes")
	public List<LabelValuePair> getLstTSACobTypes(String string) {

		StringBuilder sQuery = new StringBuilder(
				"SELECT COB_TYPE, COBTYPE_DESC FROM EM_COBTYPE " + "ORDER BY COB_TYPE");
		String sName = "COB_TYPE";
		String sValue = "COBTYPE_DESC";

		return getLabelValuePair(sQuery.toString(), sName, sValue);
	}

	public List<LabelValuePair> getArrYesNo() {

		List<LabelValuePair> lstArr = new ArrayList<>();

		LabelValuePair lbi0 = new LabelValuePair("Y", "Yes");
		LabelValuePair lbi1 = new LabelValuePair("N", "No");

		lstArr.add(lbi0);
		lstArr.add(lbi1);

		return lstArr;
	}

	@Cacheable("getChannelListValues")
	private List<LabelValuePair> getChannelListValues() {

		List<LabelValuePair> lstArr1 = new ArrayList<>();

		LabelValuePair lbi0 = new LabelValuePair("X", "Fax");
		LabelValuePair lbi1 = new LabelValuePair("T", "Telephonic");
		LabelValuePair lbi2 = new LabelValuePair("F", "Form");
		LabelValuePair lbi3 = new LabelValuePair("O", "Onsite");

		lstArr1.add(lbi0);
		lstArr1.add(lbi1);
		lstArr1.add(lbi2);
		lstArr1.add(lbi3);

		return lstArr1;
	}

	public List<LabelValuePair> getArrSourceTypes() {

		List<LabelValuePair> lstArr = new ArrayList<>();

		LabelValuePair lbi0 = new LabelValuePair("A", "Application");
		LabelValuePair lbi1 = new LabelValuePair("M", "Member");

		lstArr.add(lbi0);
		lstArr.add(lbi1);

		return lstArr;
	}

	@Cacheable(value = "getWFCaseStatuses", key = "#customerId")
	public List<LabelValuePair> getWFCaseStatuses(String customerId) {
		List<LabelValuePair> labelValuePairs = new ArrayList<>();
		String query = CommonUtils.buildQuery("SELECT DISTINCT WF_CODE FROM EM_WF_CASE_CODES WHERE WF_TYPE = 'STATUS'",
				"AND CUSTOMER_ID = ? AND WF_CODE != 'ALL' ORDER BY WF_CODE DESC");
		try {
			List<String> values = jdbcTemplate.query(query, (rs, rowNum) -> nonNullTrim(rs.getString("WF_CODE")),
					customerId);
			if (!CollectionUtils.isEmpty(values)) {
				values.stream().forEach(value -> labelValuePairs.add(new LabelValuePair(value, value)));
			}
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error occured while getWFCaseStatuses");
		}
		return labelValuePairs;
	}

	@Cacheable("getWFCasePriorityList")
	public List<LabelValuePair> getWFCasePriorityList() {

		List<LabelValuePair> labelValuePairs = new ArrayList<>();
		labelValuePairs.add(new LabelValuePair("1", "Critical"));
		labelValuePairs.add(new LabelValuePair("2", "High"));
		labelValuePairs.add(new LabelValuePair("3", "Medium"));
		labelValuePairs.add(new LabelValuePair("4", "Low"));

		return labelValuePairs;
	}

	@Cacheable(value = "fetchDashletConfiguration", key = "#wfCode")
	public String fetchDashletConfiguration(String wfCode, String customerId) {
		String sql = "SELECT WF_DESC FROM EM_WF_CASE_CODES WHERE WF_TYPE = 'DASHLET' AND WF_CODE = ? AND CUSTOMER_ID = ?";
		try {
			return jdbcTemplate.queryForObject(sql, (rs, rowNum) -> rs.getString("WF_DESC"), wfCode, customerId);
		} catch (EmptyResultDataAccessException exp) {
			throw new ApplicationException(exp, "No dashlet configuration found for selected customer!");
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error occured while fetchDashletConfiguration!");
		}
	}

	public List<LabelValuePair> getLabelValuePairList(String sql, Object[] params, String value, String label) {
		return jdbcTemplate.query(sql, rs -> {
			List<LabelValuePair> labelValuePairList = new ArrayList<>();
			while (rs.next())
				labelValuePairList
						.add(new LabelValuePair(nonNullTrim(rs.getString(value)), nonNullTrim(rs.getString(label))));
			return labelValuePairList;
		}, params);
	}

	@Cacheable("getCPMDate")
	public List<CPMDateVO> getCPMDate() {

		String query = "SELECT PYMT_EFF_MONTH, CAL_START_DATE, CAL_END_DATE FROM CMSCUTOFF ORDER BY CAL_START_DATE DESC";
		try {
			return jdbcTemplate.query(query, new DomainPropertyRowMapper<CPMDateVO>(CPMDateVO.class));
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error ocurred while getCPMDate!");
		}
	}

	@Cacheable("billingPaySourceTypes")
	public List<LabelValuePair> loadBillingPaySourceTypes() {
		String sql = "SELECT PAY_SOURCE_TYPE, PAYSOURCE_DESC FROM BBB_PAYSOURCE ORDER BY PAYSOURCE_DESC";
		String label = "PAYSOURCE_DESC";
		String value = "PAY_SOURCE_TYPE";
		try {
			return getLabelValuePaired(sql, value, label);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp,
					"Error ocurred while executing cache service loadBillingPaySourceTypes!");
		}

	}

	@Cacheable("getLstInvoiceStatus")
	public List<LabelValuePair> getLstInvoiceStatus() {
		String sql = CommonUtils.buildQuery("SELECT INVOICE_STATUS, INVOICESTATUS_DESC FROM BBB_INVOICESTATUS",
				"ORDER BY INVOICESTATUS_DESC");
		String sName = "INVOICE_STATUS";
		String sValue = "INVOICESTATUS_DESC";

		return getLabelValuePair(sql, sName, sValue);
	}

	@Cacheable("getSearchLstInvoiceType")
	public List<LabelValuePair> getSearchLstInvoiceType() {
		String sql = "SELECT INVOICE_TYPE, INVOICETYPE_DESC FROM BBB_INVOICETYPE ORDER BY INVOICETYPE_DESC";
		String sName = "INVOICETYPE_DESC";
		String sValue = "INVOICE_TYPE";

		return getLabelValuePair(sql, sName, sValue);
	}

	@Cacheable("getBillRefReasonList")
	public List<LabelValuePair> getBillRefReasonList() {
		String sql = " SELECT REFUND_REASON_CODE, REFUND_REASON_DESC FROM BBB_REFUND_REASONTYPE ORDER BY REFUND_REASON_CODE";
		try {
			String sName = "REFUND_REASON_CODE";
			String sValue = "REFUND_REASON_DESC";
			return getLabelValuePaired(sql, sName, sValue);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error ocurred while getBillRefReasonList!");
		}
	}

	@Cacheable("getLstRelatedInvoiceType")
	public Map<String, List<LabelValuePair>> getLstRelatedInvoiceType() {
		String sql = "SELECT INVOICE_GROUP_CD, INVOICE_TYPE, INVOICETYPE_DESC FROM BBB_INVOICETYPE ORDER BY INVOICE_GROUP_CD";
		String sKey = "INVOICE_GROUP_CD";
		String sName = "INVOICETYPE_DESC";
		String sValue = "INVOICE_TYPE";

		return getMap(sql, sKey, sName, sValue);
	}

	@Cacheable("getLstInvoiceGroup")
	public List<LabelValuePair> getLstInvoiceGroup() {
		List<LabelValuePair> lst = new ArrayList<>();
		lst.add(new LabelValuePair("M", "Member"));
		lst.add(new LabelValuePair("S", "SPAP"));
		lst.add(new LabelValuePair("L", "LIS"));
		lst.add(new LabelValuePair("G", "Group"));
		return lst;
	}

	@Cacheable("getLstMemberGroup")
	public List<LabelValuePair> getLstMemberGroup() {
		String sql = "SELECT MBR_GRP_IND, MBR_GRP_DESC FROM BBB_MBRGRP ORDER BY MBR_GRP_DESC";
		String sName = "MBR_GRP_IND";
		String sValue = "MBR_GRP_DESC";

		return getLabelValuePair(sql, sName, sValue);
	}

	@Cacheable("getLstFrequencyCodes")
	public List<LabelValuePair> getLstFrequencyCodes() {
		String sql = "SELECT FREQUENCY_CD, FREQUENCY_DESC FROM BBB_FREQUENCY ORDER BY FREQUENCY_DESC";
		String sName = "FREQUENCY_CD";
		String sValue = "FREQUENCY_DESC";

		return getLabelValuePair(sql, sName, sValue);
	}

	@Cacheable("getLstLineStatus")
	public List<LabelValuePair> getLstLineStatus() {
		String sql = "SELECT LINE_STATUS, LINESTATUS_DESC FROM BBB_LINESTATUS ORDER BY LINESTATUS_DESC";
		String sName = "LINE_STATUS";
		String sValue = "LINESTATUS_DESC";

		return getLabelValuePair(sql, sName, sValue);
	}

	@Cacheable(value = "getLstPaySource")
	public List<LabelValuePair> getLstPaySource() {
		String sql = "SELECT PAY_SOURCE_TYPE, PAYSOURCE_DESC FROM BBB_PAYSOURCE ORDER BY PAYSOURCE_DESC";
		String sName = "PAY_SOURCE_TYPE";
		String sValue = "PAYSOURCE_DESC";

		return getLabelValuePair(sql, sName, sValue);
	}

	@Cacheable(value = "getBankAcctCd", key = "#customerId")
	public List<BillingBankDetailsDO> getBankAcctCd(String customerId) {
		List<BillingBankDetailsDO> bankDtlsList = null;
		String sql = CommonUtils.buildQuery(
				"SELECT PAY_SOURCE_TYPE, BANK_ACCT_CD, PLAN_ID, EFF_START_DATE, EFF_END_DATE",
				"FROM BBB_ACCT_LOOKUP WHERE CUSTOMER_ID = ?");
		try {

			bankDtlsList = jdbcTemplate.query(sql,
					new DomainPropertyRowMapper<BillingBankDetailsDO>(BillingBankDetailsDO.class), customerId);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error occured while getBankAcctCd!");
		}
		return bankDtlsList;
	}

	@Cacheable(value = "validateGlBankAcctCdForMMO", key = "#customerId")
	public List<BillingBankDetailsDO> validateGlBankAcctCdForMMO(String customerId) {

		String sql = CommonUtils.buildQuery(
				"SELECT BANK_ACCT_CD,EFF_START_DATE,EFF_END_DATE FROM BBB_ACCT_LOOKUP WHERE CUSTOMER_ID = ?");
		try {
			return jdbcTemplate.query(sql,
					new DomainPropertyRowMapper<BillingBankDetailsDO>(BillingBankDetailsDO.class), customerId);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error occured while validateGlBankAcctCdForMMO!");
		}
	}

	@Cacheable(value = "validateGlBankAcctCd", key = "#customerId")
	public List<BillingBankDetailsDO> validateGlBankAcctCd(String customerId) {

		String sql = CommonUtils.buildQuery(
				"SELECT BANK_ACCT_CD,EFF_START_DATE,EFF_END_DATE, PLAN_ID, GL_TRANS_CD FROM BBB_GL_LOOKUP WHERE CUSTOMER_ID = ?");
		try {
			return jdbcTemplate.query(sql,
					new DomainPropertyRowMapper<BillingBankDetailsDO>(BillingBankDetailsDO.class), customerId);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error occured while validateGlBankAcctCd!");
		}
	}

	@Cacheable(value = "getBillFuncList", key = "#customerId")
	public List<EEMBillFuncDO> getBillFuncList(String customerId) {
		String sql = CommonUtils.buildQuery("SELECT FC.FUNCTION_CD, FC.SHORT_DESC, FC.LONG_DESC, FC.GL_TRANS_CD,",
				"FC.USER_SYSTEM_IND, FC.HDR_DTL_TRAN_IND, FC.AMT_SIGN_CD, FC.ACTIVE_IND, GLL.BANK_ACCT_CD",
				"FROM BBB_FUNCTION_CODE FC LEFT OUTER JOIN BBB_GL_LOOKUP GLL",
				"ON GLL.CUSTOMER_ID = FC.CUSTOMER_ID AND GLL.GL_TRANS_CD = FC.GL_TRANS_CD",
				"WHERE FC.CUSTOMER_ID = ? ORDER BY FC.SHORT_DESC");

		try {
			return jdbcTemplate.query(sql, new DomainPropertyRowMapper<EEMBillFuncDO>(EEMBillFuncDO.class), customerId);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error ocurred while getBillFuncList!!");
		}
	}

	@Cacheable(value = "getFunctionCode", key = "#customerId")
	public List<EEMBillingFunctionCodeDO> getFunctionCode(String customerId) {
		String sql = CommonUtils.buildQuery("SELECT CUSTOMER_ID,FUNCTION_CD, SHORT_DESC, LONG_DESC, USER_SYSTEM_IND,",
				"MODIFY_IND,ACTIVE_IND, ADMIN_SECURITY_IND, HDR_DTL_TRAN_IND, AMT_SIGN_CD, MBR_GRP_IND,GL_TRANS_CD,",
				"FUNCTION_TYPE, CREATE_TIME,CREATE_USERID,LAST_UPDT_TIME,LAST_UPDT_USERID",
				"FROM BBB_FUNCTION_CODE WHERE CUSTOMER_ID = ?");

		try {
			return jdbcTemplate.query(sql,
					new DomainPropertyRowMapper<EEMBillingFunctionCodeDO>(EEMBillingFunctionCodeDO.class), customerId);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error occured while getFunctionCode!!");
		}
	}

	@Cacheable(value = "getLtcDetails", key = "#customerId")
	public List<EEMLtcFacilityDO> getLtcDetails(String customerId) {

		List<EEMLtcFacilityDO> ltcFacilityDOList;
		try {
			String sQuery = CommonUtils.buildQuery(" SELECT LTC_FAC_ID, LTC_FAC_NAME, EFFECTIVE_DATE, EFF_END_DATE,",
					" LTC_FAC_PHONE, LTC_FAC_ADDRESS, CREATE_TIME, CREATE_USERID,",
					" LAST_UPDT_TIME, LAST_UPDT_USERID LTC_FAC_CITY, LTC_FAC_STATE, LTC_FAC_ZIPCODE",
					" FROM EM_LTC_FACILITY WHERE CUSTOMER_ID = ?");

			ltcFacilityDOList = jdbcTemplate.query(sQuery,
					new DomainPropertyRowMapper<EEMLtcFacilityDO>(EEMLtcFacilityDO.class), customerId);

			return ltcFacilityDOList;
		} catch (Exception exp) {
			throw new ApplicationException(exp);
		}
	}

	@Cacheable(value = "mbrLtcSearch", key = "#customerId")
	public List<EEMMbrLtcInfoDO> mbrLtcSearch(String customerId) {
		String query = CommonUtils.buildQuery(
				"SELECT LTC_FAC_ID AS LTC_ID, LTC_FAC_NAME, LTC_FAC_ADDRESS, LTC_FAC_CITY,",
				"LTC_FAC_STATE, LTC_FAC_ZIPCODE, EFFECTIVE_DATE AS EFF_START_DATE, EFF_END_DATE FROM EM_LTC_FACILITY",
				"WHERE CUSTOMER_ID = ? ORDER BY EFFECTIVE_DATE DESC");
		try {
			return jdbcTemplate.query(query, new DomainPropertyRowMapper<EEMMbrLtcInfoDO>(EEMMbrLtcInfoDO.class),
					customerId);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error occured while mbrLtcSearch!");
		}
	}

	@Cacheable("sourceTriggerCodeMap")
	public List<LabelValuePair> sourceTriggerCodeMap() {
		List<LabelValuePair> lst = new ArrayList<>();
		lst.add(new LabelValuePair(EEMConstants.TRIG_CODE_DCONF_VAL, EEMConstants.TRIG_CODE_DCONF));
		lst.add(new LabelValuePair(EEMConstants.TRIG_CODE_DANOC_VAL, EEMConstants.TRIG_CODE_DANOC));
		lst.add(new LabelValuePair(EEMConstants.TRIG_CODE_DPROV_VAL, EEMConstants.TRIG_CODE_DPROV));
		lst.add(new LabelValuePair(EEMConstants.TRIG_CODE_DEOC_VAL, EEMConstants.TRIG_CODE_DEOC));
		lst.add(new LabelValuePair(EEMConstants.TRIG_CODE_DDENTAL_VAL, EEMConstants.TRIG_CODE_DDENTAL));
		lst.add(new LabelValuePair(EEMConstants.TRIG_CODE_DFORM_VAL, EEMConstants.TRIG_CODE_DFORM));
		lst.add(new LabelValuePair(EEMConstants.TRIG_CODE_DVISION_VAL, EEMConstants.TRIG_CODE_DVISION));
		return lst;
	}

	@Cacheable("getLstMbrSEPReasons")
	public List<LabelValuePair> getLstMbrSEPReasons() {
		StringBuilder sQuery = new StringBuilder("SELECT EM_SEP_REASON_CD, EM_SEPREASON_DESC FROM EM_SERC ")
				.append("ORDER BY EM_SEPREASON_DESC");
		String sName = "EM_SEP_REASON_CD";
		String sValue = "EM_SEPREASON_DESC";

		return getLabelValuePaired(sQuery.toString(), sName, sValue);
	}

	@Cacheable(value = "getWfOptInValue", key = "#custId")
	public String getWfOptInValue(String custId, String wfoptin) {
		String sql = "SELECT PARM_IND_VALUE FROM EM_PROFILE WHERE PARM_CD = ? AND CUSTOMER_ID = ?";
		try {
			return jdbcTemplate.queryForObject(sql, String.class, wfoptin, custId);
		} catch (EmptyResultDataAccessException exp) {
			return EEMConstants.VALUE_NO;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error occured while getWfOptInValue!!");
		}
	}

	@Cacheable(value = "getDistinctPlansForCustomer", key = "#customerNbr")
	public List<LabelValuePair> getDistinctPlansForCustomer(String customerNbr) {

		try {
			StringBuilder sQuery = new StringBuilder("SELECT DISTINCT PLAN_ID FROM PLANPBP ")
					.append("WHERE CUST_NBR = '" + customerNbr + "'");

			String sName = "PLAN_ID";
			String sValue = "PLAN_ID";

			return getLabelValuePair(sQuery.toString(), sName, sValue);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error occured while getDistinctPlansForCustomer!");
		}
	}

	@Cacheable("getOoaReasonList")
	public List<LabelValuePair> getOoaReasonList(String customerId) {
		StringBuilder sQuery = new StringBuilder("SELECT OOA_REASON_CD, OOA_REASON_DESC FROM EM_OOA_REASON ")
				.append(" WHERE CUSTOMER_ID = '" + customerId + "' ORDER BY OOA_REASON_CD");

		String sName = "OOA_REASON_DESC";
		String sValue = "OOA_REASON_CD";

		return getLabelValuePaire(sQuery.toString(), sName, sValue);
	}

	@Cacheable("getOoaSourceList")
	public List<LabelValuePair> getOoaSourceList(String customerId) {
		StringBuilder sQuery = new StringBuilder("SELECT OOA_SRC_CD, OOA_SRC_DESC FROM EM_OOA_SOURCE ")
				.append("WHERE CUSTOMER_ID = '" + customerId + "' AND OOA_SRC_DESC NOT IN('TRR') ORDER BY OOA_SRC_CD");

		String sName = "OOA_SRC_DESC";
		String sValue = "OOA_SRC_CD";

		return getLabelValuePaire(sQuery.toString(), sName, sValue);
	}

	@Cacheable("getOoaDeReasonsList")
	public List<LabelValuePair> getOoaDeReasonsList(String customerId) {
		StringBuilder sQuery = new StringBuilder("SELECT REASON_CD, REASON_DESCRIPTION FROM EM_REQ_REASONS ")
				.append("WHERE CUSTOMER_ID = '" + customerId + "' AND REASON_TYPE = 'OOAD' ORDER BY REASON_CD ");

		String sName = "REASON_DESCRIPTION";
		String sValue = "REASON_CD";

		return getLabelValuePaire(sQuery.toString(), sName, sValue);
	}
	
	@Cacheable(value = "getManualPopupQueues", key = "#customerId")
	public List<String> getManualPopupQueues(String customerId) {
		String sql = CommonUtils.buildQuery("SELECT TRIM(QUEUE_NAME) FROM EM_WF_CASE_QUEUE WHERE SCN_DISPLAY = 'POPUP'",
				"AND CUSTOMER_ID=? AND OVERIDE_IND = 'N'");
		try {
			return jdbcTemplate.query(sql, rs -> {
				List<String> result = new ArrayList<>();
				while (rs.next()) {
					result.add(rs.getString(1));
				}
				return result;
			}, customerId);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	private List<LabelValuePair> getLabelValuePaire(String sQuery, String sDesc, String sValue) {

		return jdbcTemplate.query(sQuery, (ResultSet res) -> {
			List<LabelValuePair> hmp = new ArrayList<>();
			while (res.next()) {
				String desc = trimToEmpty(res.getString(sDesc));
				String value = trimToEmpty(res.getString(sValue));
				String descValue = desc + "-" + value;
				LabelValuePair pair = new LabelValuePair(value, descValue);
				hmp.add(pair);
			}
			return hmp;
		});
	}

}
