/**
 * 
 */
package com.medicare.mss.domainobject;

import java.io.Serializable;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

/**
 * @author Wipro Ltd.
 *
 */
@Data
public class EEMMbrLtcInfoDO implements Serializable {
	
	private static final long serialVersionUID = -2002851523389793780L;

	@ColumnMapper(columnName = "ASSESSMENT_DATE", propertyName = "assessmentDate")
	private String assessmentDate;
	
	@ColumnMapper(columnName = "CREATE_TIME", propertyName = "createTime")
	private String createTime;
	
	@ColumnMapper(columnName = "CREATE_USERID", propertyName = "createUserId")
	private String createUserId;
	
	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;
	
	@ColumnMapper(columnName = "EFF_END_DATE", propertyName = "effEndDate")
	private String effEndDate;
	
	@ColumnMapper(columnName = "EFF_START_DATE", propertyName = "effStartDate")
	private String effStartDate;
	
	private String errorDescription;
	
	@ColumnMapper(columnName = "LTC_FAC_ADDRESS", propertyName = "facilityAddress")
	private String facilityAddress;
	
	@ColumnMapper(columnName = "LTC_FAC_CITY", propertyName = "facilityCity")
	private String facilityCity;
	
	@ColumnMapper(columnName = "LTC_FAC_NAME", propertyName = "facilityName")
	private String facilityName;
	
	@ColumnMapper(columnName = "LTC_FAC_STATE", propertyName = "facilityState")
	private String facilityState;
	
	@ColumnMapper(columnName = "LTC_FAC_ZIPCODE", propertyName = "facilityZipCode")
	private String facilityZipCode;
	
	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;
	
	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserId")
	private String lastUpdtUserId;
	
	@ColumnMapper(columnName = "LENGTH_OF_STAY", propertyName = "lengthOfStay")
	private String lengthOfStay;
	
	private String ltcChangeInd;
	private String ltcchangeReceiveTime;
	private String ltcChangeSendTime;
	
	@ColumnMapper(columnName = "LTC_ID", propertyName = "ltcId")
	private String ltcId;
	
	@ColumnMapper(columnName = "MEMBER_ID", propertyName = "memberId")
	private String memberId;
	
	@ColumnMapper(columnName = "OVERRIDE_IND", propertyName = "overrideInd")
	private String overrideInd;
	
	@ColumnMapper(columnName = "PPS_INDICATOR", propertyName = "ppsInd")
	private String ppsInd;

}
