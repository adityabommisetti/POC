package com.medicare.mss.daoImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.medicare.mss.dao.EEMDAO;
import com.medicare.mss.exception.ApplicationException;

@Repository
public class EEMDAOImpl implements EEMDAO{
	
	@Autowired
	private JdbcTemplate jdbcTemplate;


	@Override 
	public int getNextSeqNo(String mfId, String type) throws ApplicationException {
		
			int seqNbr = -1;
			int sqlCnt = 0;


			
			StringBuilder selectSql = new StringBuilder("SELECT SEED_NBR FROM EM_ID_SEED WHERE CUSTOMER_ID = ? AND SEED_TYPE = ? FOR UPDATE");
			StringBuilder updtSql = new StringBuilder("UPDATE EM_ID_SEED SET SEED_NBR = ? WHERE CUSTOMER_ID = ? AND SEED_TYPE = ?");
			
			try {
				seqNbr = jdbcTemplate.queryForObject(selectSql.toString(), new Object[] {mfId, type},Integer.class);
			}
			 catch (EmptyResultDataAccessException exp) {
				 throw new ApplicationException("No Seed Value Found [" + mfId + "][" + type + "]");
			}
			
			seqNbr += 1;
			
			sqlCnt = jdbcTemplate.update(updtSql.toString(), seqNbr,mfId, type);
	
			if (sqlCnt != 1)
				throw new ApplicationException("Error Updateing Seed Value [" + mfId + "][" + type + "]");

		return seqNbr;
	}

}
