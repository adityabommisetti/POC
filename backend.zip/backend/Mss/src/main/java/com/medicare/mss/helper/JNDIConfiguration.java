package com.medicare.mss.helper;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;

/**
 * @author Wipro
 * 
 * 
 */
//@Configuration
public class JNDIConfiguration {

	@Value("${datasource.jndi}")
	private String db2JndiName;

	@Value("${oracleArchive.jndi}")
	private String oracleJndiName;
	
	@Bean(name = "db2DS")
	@Primary
	public DataSource dataSource() {
		JndiDataSourceLookup jndiDataSourceLookup = new JndiDataSourceLookup();
		jndiDataSourceLookup.setResourceRef(true);
		return jndiDataSourceLookup.getDataSource(db2JndiName);

	}
	
	@Bean(name = "oracleDS")
	public DataSource getConnectionForArchivalDB() {
		JndiDataSourceLookup jndiDataSourceLookup = new JndiDataSourceLookup();
		jndiDataSourceLookup.setResourceRef(true);
		return jndiDataSourceLookup.getDataSource(oracleJndiName);
	}
	
	/*
	@Bean(name = "db2DS")
	@Primary
	@ConfigurationProperties(prefix = "spring.datasource")
	public DataSource dataSource() {
		return DataSourceBuilder.create().build();
	}
	
	@Bean(name = "oracleDS")
	@ConfigurationProperties(prefix = "oracle.archive")
	public DataSource getConnectionForArchivalDB() {
		return DataSourceBuilder.create().build();
	}
	*/
	
	@Bean
	public JdbcTemplate jdbcTemplate(@Qualifier("db2DS") DataSource ds) throws SQLException {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
		return jdbcTemplate;
	}
	
	@Bean(name = "namedParameterJdbcTemplate")
	public NamedParameterJdbcTemplate namedParameterJdbcTemplate(@Qualifier("db2DS") DataSource ds) throws SQLException {
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(ds);
		return namedParameterJdbcTemplate;
	}
	
	@Bean(name = "oracleJdbcTemplate")
	public JdbcTemplate oracleJdbcTemplate(@Qualifier("oracleDS") DataSource ds) throws SQLException {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
		return jdbcTemplate;
	}
	
}