/**
 * 
 */
package com.medicare.mss.domainobject;

import java.io.Serializable;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

/**
 * @author DU20098149
 *
 */
@Data
public class EEMMbrLepInfoDO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6208669208044062809L;

	@ColumnMapper(columnName = "ATT_REC_CHANNEL", propertyName = "attestationRecChannel")
	private String attestationRecChannel;

	@ColumnMapper(columnName = "ATT_REC_DATE", propertyName = "attestationRecDate")
	private String attestationRecDate;

	@ColumnMapper(columnName = "ATTST_LOCK", propertyName = "attestLock")
	private String attestLock;

	@ColumnMapper(columnName = "ATT_STATUS", propertyName = "attestStatus")
	private String attestStatus;

	private String birthDate;

	@ColumnMapper(columnName = "CASE_FILE_DUE_DATE", propertyName = "caseFileDueDate")
	private String caseFileDueDate;

	@ColumnMapper(columnName = "CASE_FILE_REC_DATE", propertyName = "caseFileRecDate")
	private String caseFileRecDate;

	@ColumnMapper(columnName = "CREATE_TIME", propertyName = "createTime")
	private String createTime;

	@ColumnMapper(columnName = "CREATE_USERID", propertyName = "createUserId")
	private String createUserId;

	@ColumnMapper(columnName = "CREDITABLE_COVERAGE_FLAG", propertyName = "creditableCoverageFlag")
	private String creditableCoverageFlag;

	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;

	@ColumnMapper(columnName = "DECISION_REC_DATE", propertyName = "decisionRecDate")
	private String decisionRecDate;

	@ColumnMapper(columnName = "DECISION_TYPE", propertyName = "decisionType")
	private String decisionType;

	@ColumnMapper(columnName = "EFF_END_DATE", propertyName = "effEndDate")
	private String effEndDate;

	@ColumnMapper(columnName = "EFF_START_DATE", propertyName = "effStartDate")
	private String effStartDate;

	private String enrollEffStartDate;
	private String firstName;
	private String hicNBRVal;
	private String hicn;

	@ColumnMapper(columnName = "INC_ATT_RCVE_DATE", propertyName = "incompAttestLetRecDate")
	private String incompAttestLetRecDate;

	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;

	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserId")
	private String lastUpdtUserId;
	@ColumnMapper(columnName = "LEP_AMT", propertyName = "lepAmt")
	private String lepAmt;

	@ColumnMapper(columnName = "LEP_WAIVED_AMT", propertyName = "lepWaivedAmt")
	private String lepWaivedAmt;

	private String maOnly;
	private String maValue;
	private String mbi;

	@ColumnMapper(columnName = "MEMBER_ID", propertyName = "memberId")
	private String memberId;

	@ColumnMapper(columnName = "NOTIFIED_MEMBER_APPEAL", propertyName = "notifiedMemberAppeal")
	private String notifiedMemberAppeal;
	
	@ColumnMapper(columnName = "NUMUNCOV_TRANS_REASON", propertyName = "numUncocTransReason")
	private String numUncocTransReason;

	@ColumnMapper(columnName = "NBR_UNCOV_MONTHS", propertyName = "nbrUncovMonths")
	private int nbrUncovMonths;

	@ColumnMapper(columnName = "OVERRIDE_IND", propertyName = "overrideInd")
	private String overrideInd;
	
	private String pbpId;
	private String planDesignation;
	private String planId;
	private String tempEnrollEffStartDate;

	@ColumnMapper(columnName = "TRANSACTION_DUE_DATE", propertyName = "transactionDueDate")
	private String transactionDueDate;

	@ColumnMapper(columnName = "UNCOV_MNTH_STRT_DT", propertyName = "uncovStDate")
	private String uncovStDate;


}
