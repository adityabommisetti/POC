package com.medicare.mss.vo;

import com.medicare.mss.domainobject.EEMLepAttestCallDO;

import lombok.Data;

@Data
public class EEMLepAttestCallRequestVO {
	private String customerId;
	private Integer applId;
	private String obc1TimerCheck;
	private String obc2TimerCheck;
	private String le21TimerCheck;
	private String obc3TimerCheck;
	private EEMLepAttestCallDO outBoundInitial;
	private EEMLepAttestCallDO inBoundInitial;
	private EEMLepAttestCallDO outBoundInComplete;
	private EEMLepAttestCallDO inBoundInComplete;
	private EEMLepAttestCallDO inBoundLate;

}
