package com.medicare.mss.dao;

import java.util.List;

import com.medicare.mss.domainobject.EmMbrPosInfoDO;

public interface EEMMbrPOSDAO extends EEMMbrBaseDAO {

	int setPosInfoOverride(EmMbrPosInfoDO delDO, String userId);

	List<EmMbrPosInfoDO> getMbrPos(String customerId, String memberId, String showAll);

	int setMbrPosOverride(EmMbrPosInfoDO overDO, String userId);

	int insertMbrPos(EmMbrPosInfoDO newDO);

}
