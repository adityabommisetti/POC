package com.medicare.mss.caching;

import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.medicare.mss.domainobject.EEMProfileItemDO;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.StringUtil;

@Component
public class EEMProfileSettings {

	@Autowired
	private EEMPersistence eemPer;

	

	public String getCalendarProfileInd(String mfId, String parmCd) {

		return StringUtil.nonNullTrim(getParmInd(mfId, parmCd, DateUtil.getTodaysDate()));
	}

	public String getCalendarProfileText(String mfId, String parmCd) {

		return StringUtil.nonNullTrim(getParmText(mfId, parmCd, DateUtil.getTodaysDate()));
	}

	public String getParmDate(String mfId, String parmCd) {

		EEMProfileItemDO item = getProfileObject(mfId, parmCd);
		if (item != null)
			return item.getParmDateValue();
		return null;
	}

	public String getParmInd(String mfId, String parmCd, String effDate) {

		EEMProfileItemDO item = getProfileObject(mfId, parmCd, effDate);
		if (item != null)
			return item.getParmIndValue();
		return null;
	}

	public int getParmNumber(String mfId, String parmCd) {

		EEMProfileItemDO item = getProfileObject(mfId, parmCd);
		if (item != null)
			return item.getParmNumberValue();
		return 0;
	}

	public EEMProfileItemDO getProfileObject(String mfId, String parmCd) {

		List<EEMProfileItemDO> lst = eemPer.getCustProf(mfId);

		EEMProfileItemDO item;
		Iterator<EEMProfileItemDO> it = lst.iterator();
		while (it.hasNext()) {
			item = it.next();
			if (parmCd.equals(item.getParmCd())) {
				return item;
			}
		}
		return null;
	}

	public EEMProfileItemDO getProfileObject(String mfId, String parmCd, String effDate) {

		List<EEMProfileItemDO> lst = eemPer.getCustProf(mfId);
		EEMProfileItemDO item;
		Iterator<EEMProfileItemDO> it = lst.iterator();
		while (it.hasNext()) {
			item = it.next();
			if (parmCd.equals(item.getParmCd()) && (effDate.compareTo(item.getEffStartDate()) >= 0)
					&& (effDate.compareTo(item.getEffEndDate()) <= 0))
				return item;
		}
		return null;
	}

	public String getParmText(String mfId, String parmCd, String effDate) {

		EEMProfileItemDO item = getProfileObject(mfId, parmCd, effDate);
		if (item != null)
			return item.getParmTextValue();
		return null;
	}

	public String getParmIndWithOutEffDate(String mfId, String parmCd) {

		EEMProfileItemDO item = getProfileObject(mfId, parmCd);
		if (item != null)
			return item.getParmIndValue();
		return null;
	}
	
	public String getCalendarProfileItem(String mfId, String parmCd) {
		return StringUtils.trimToEmpty(getProfileItem(mfId, parmCd, DateUtil.getTodaysDate()));
	}
	
	public String getProfileItem(String mfId, String parmCd, String effDate) {
		EEMProfileItemDO item = getProfileObject(mfId, parmCd, effDate);
		if (item != null)
			return item.getParmIndValue();
		return null;
	}

}
