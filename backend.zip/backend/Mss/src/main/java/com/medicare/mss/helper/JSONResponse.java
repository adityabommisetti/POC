package com.medicare.mss.helper;

import lombok.Data;

/**
 * This class formats JSON details
 * 
 * @author Wipro
 *
 */
@Data
public class JSONResponse {

	private String status;
	private String message;
	private Object data;

}
