/**
 * 
 */
package com.medicare.mss.controller;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.security.vo.EEMBillingInvCommentVO;
import com.medicare.mss.service.EEMBillingInvService;
import com.medicare.mss.vo.BillInvoiceDetailsUpdateVO;
import com.medicare.mss.vo.BillingMbrGrpSearchVO;
import com.medicare.mss.vo.EEMBillingCacheVO;
import com.medicare.mss.vo.EEMBillingInvHeaderDtlsVO;
import com.medicare.mss.vo.EEMBillingInvMasterVO;
import com.medicare.mss.vo.EEMBillingInvTransferVO;
import com.medicare.mss.vo.EEMBillingInvoiceDtlsVO;
import com.medicare.mss.vo.EEMBillingInvoiceSearchVO;
import com.medicare.mss.vo.PageableVO;

/**
 * @author DU20098149
 *
 */
@RestController
@RequestMapping("/billing")
public class EEMBillingInvController {

	@Autowired
	private EEMBillingInvService billingInvoiceService;

	@PostMapping(ReqMappingConstants.BILLING_INVOICE_SEARCH)
	public ResponseEntity<JSONResponse> serachMbrBillingInvoice(@RequestBody EEMBillingInvoiceSearchVO searchVO) {
		EEMBillingInvMasterVO masterVO = billingInvoiceService.searchBillingInvoice(searchVO);
		return sendResponse(masterVO);
	}

	@PostMapping(ReqMappingConstants.BILLING_INVOICE_SEARCH_SELECT)
	public ResponseEntity<JSONResponse> serachMbrBillingInvoice(
			@RequestBody EEMBillingInvHeaderDtlsVO billInvHdrDtlsVO) {
		EEMBillingInvMasterVO masterVO = billingInvoiceService.searchSelectBillingInvoice(billInvHdrDtlsVO);
		return sendResponse(masterVO);
	}

	@PostMapping(ReqMappingConstants.BILLING_INVOICE_TRANSFER)
	public ResponseEntity<JSONResponse> billInvoiceTransfer(@RequestBody EEMBillingInvTransferVO billingInvTransferVO) {
		EEMBillingInvMasterVO masterVO = billingInvoiceService.billInvoiceTransfer(billingInvTransferVO);
		return sendResponse(masterVO);
	}

	@GetMapping(ReqMappingConstants.BILLING_CACHE_DATA)
	public ResponseEntity<JSONResponse> getBillingCacheData() {
		EEMBillingCacheVO cacheVO = billingInvoiceService.getBillingCacheData();
		return sendResponse(cacheVO);
	}

	@PostMapping(ReqMappingConstants.BILLING_INV_SAVE_COMMENT)
	public ResponseEntity<JSONResponse> saveBillInvoiceComment(
			@RequestBody EEMBillingInvCommentVO billingInvCommentVO) {
		List<EEMBillingInvCommentVO> comments = billingInvoiceService.saveBillInvoiceComment(billingInvCommentVO);
		return sendResponse(comments);
	}

	@PostMapping(ReqMappingConstants.BILLING_INV_MBR_GRP_SEARCH)
	public ResponseEntity<JSONResponse> searchBillMbrGrp(@RequestBody BillingMbrGrpSearchVO billingMbrGrpSearchVO) {
		List<EEMBillingInvoiceDtlsVO> billInvDtlsVOs = billingInvoiceService.searchBillMbrGrp(billingMbrGrpSearchVO);
		return sendResponse(billInvDtlsVOs);
	}

	@PostMapping(ReqMappingConstants.BILLING_INVOICE_UPDATE)
	public ResponseEntity<JSONResponse> billInvoiceDetailsUpdate(
			@RequestBody BillInvoiceDetailsUpdateVO billInvoiceDetailsUpdateVO) throws CloneNotSupportedException {
		EEMBillingInvMasterVO masterVO = billingInvoiceService.updateBillInvoiceDetails(billInvoiceDetailsUpdateVO);
		return sendResponse(masterVO);
	}
	
	@PostMapping(ReqMappingConstants.BILLING_GET_TOTAL_INVDTLS_AMT)
	public ResponseEntity<JSONResponse> getTotalInvoiceDetailAmt(
			@RequestBody EEMBillingInvoiceDtlsVO billInvVO) throws CloneNotSupportedException {
		String totalAmt = billingInvoiceService.getTotalInvoiceDetailAmt(billInvVO);
		return sendResponse(totalAmt);
	}
	
	@PostMapping(ReqMappingConstants.BILLING_INVOICE_SEARCH_NEXT)
	public ResponseEntity<JSONResponse> mbrSearchPagination(@RequestBody EEMBillingInvoiceSearchVO searchVO) {
		PageableVO pageableVO = billingInvoiceService.getBillingInvPagination(searchVO);
		return sendResponse(pageableVO);
	}
	
	private ResponseEntity<JSONResponse> sendResponse(Object result) {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;

		if (Objects.isNull(result)) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setData(result);
			jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
			jsonResponse.setMessage(EEMConstants.SUCCESS);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}

}
