package com.medicare.mss.vo;

import java.io.Serializable;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode(callSuper = false)
public class EEMMbrAsesVO extends BaseVO implements EMDatedSegmentVO, Cloneable, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1666794839128357177L;
	private String memberId;
	private String effStartDate;
	private String effEndDate;
	private String overrideInd;
	private String odsiFamilyId;
	private String mbrSuffix;
	private String planVersion;
	private String mpi;
	private String medicaidInd;
	private String planVersionChangeInd;
	private String status;
	private String regionCode;
	private String costSharing;
	private String maxCopy;
	private String extFlag;
	private String spendDwnFlg;
	private String grpCd;
	private String deceasedDt;

	public String getEffEndDateFrmt() {
		return DateFormatter.reFormat(effEndDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getEffStartDateFrmt() {
		return DateFormatter.reFormat(effStartDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setEffEndDateFrmt(String effEndDate) {
		this.effEndDate = DateFormatter.reFormat(effEndDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public void setEffStartDateFrmt(String effStartDate) {
		this.effStartDate = DateFormatter.reFormat(effStartDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	@Override
	public String getType() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isEndDateChange(Object obj) {
		EEMMbrAsesVO chkVO = (EEMMbrAsesVO) obj;
		return StringUtils.equals(chkVO.getEffStartDate(), this.effStartDate)
				&& StringUtils.equals(chkVO.getOdsiFamilyId(), this.odsiFamilyId)
				&& StringUtils.equals(chkVO.getMbrSuffix(), this.mbrSuffix)
				&& StringUtils.equals(chkVO.getPlanVersion(), this.planVersion)
				&& StringUtils.equals(chkVO.getMpi(), this.mpi)
				&& StringUtils.equals(chkVO.getMedicaidInd(), this.medicaidInd)
				&& StringUtils.equals(chkVO.getPlanVersionChangeInd(), this.planVersionChangeInd)
				&& StringUtils.equals(chkVO.getStatus(), this.status)
				&& StringUtils.equals(chkVO.getMemberId(), this.memberId)
				&& StringUtils.equals(chkVO.getCustomerId(), this.customerId)
				&& StringUtils.equals(chkVO.getOverrideInd(), this.overrideInd);

	}

	@Override
	public boolean isForSamePeriod(Object obj) {
		EEMMbrAsesVO chkVO = (EEMMbrAsesVO) obj;
		return StringUtils.equals(chkVO.getEffStartDate(), this.effStartDate)
				&& StringUtils.equals(chkVO.getEffEndDate(), this.effEndDate)
				&& StringUtils.equals(chkVO.getMemberId(), this.memberId)
				&& StringUtils.equals(chkVO.getCustomerId(), this.customerId);
	}

	@Override
	public boolean isSame(Object obj) {
		EEMMbrAsesVO chkVO = (EEMMbrAsesVO) obj;
		return StringUtils.equals(chkVO.getEffStartDate(), this.effStartDate)
				&& StringUtils.equals(chkVO.getEffEndDate(), this.effEndDate)
				&& StringUtils.equals(chkVO.getOdsiFamilyId(), this.odsiFamilyId)
				&& StringUtils.equals(chkVO.getMbrSuffix(), this.mbrSuffix)
				&& StringUtils.equals(chkVO.getPlanVersion(), this.planVersion)
				&& StringUtils.equals(chkVO.getMpi(), this.mpi)
				&& StringUtils.equals(chkVO.getMedicaidInd(), this.medicaidInd)
				&& StringUtils.equals(chkVO.getPlanVersionChangeInd(), this.planVersionChangeInd)
				&& StringUtils.equals(chkVO.getStatus(), this.status)
				&& StringUtils.equals(chkVO.getMemberId(), this.memberId)
				&& StringUtils.equals(chkVO.getCustomerId(), this.customerId)
				&& StringUtils.equals(chkVO.getOverrideInd(), this.overrideInd)
				&& StringUtils.equals(chkVO.getCreateTime(), this.createTime)
				&& StringUtils.equals(chkVO.getCreateUserId(), this.createUserId)
				&& StringUtils.equals(chkVO.getLastUpdtTime(), this.lastUpdtTime)
				&& StringUtils.equals(chkVO.getLastUpdtUserId(), this.lastUpdtUserId);

	}

}
