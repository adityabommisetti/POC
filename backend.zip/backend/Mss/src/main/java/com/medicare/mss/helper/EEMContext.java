package com.medicare.mss.helper;

import java.io.Serializable;
import java.util.Objects;

import com.medicare.mss.vo.EEMBillingInvMasterVO;
import com.medicare.mss.vo.EEMMbrMasterVO;
import com.medicare.mss.vo.EEMWfSearchVO;
import com.medicare.mss.vo.EMWFMasterVO;

import lombok.Data;

@Data
public class EEMContext implements Serializable {

	private static final long serialVersionUID = 9028157859885212840L;

	private EEMMbrMasterVO mbrMasterVO;
	private EMWFMasterVO emWFMasterVO;
	private EEMWfSearchVO emWFSearchVO;
	private EEMBillingInvMasterVO billInvMasterVO;

	public EEMMbrMasterVO getMbrMasterVO() {
		if (Objects.isNull(mbrMasterVO)) {
			this.mbrMasterVO = new EEMMbrMasterVO();
		}
		return mbrMasterVO;
	}

	public EMWFMasterVO getEMWFMasterVO() {
		if (Objects.isNull(emWFMasterVO)) {
			this.emWFMasterVO = new EMWFMasterVO();
		}
		return emWFMasterVO;
	}

	public EEMWfSearchVO getEEMWfSearchVO() {
		if (Objects.isNull(emWFSearchVO)) {
			this.emWFSearchVO = new EEMWfSearchVO();
		}
		return emWFSearchVO;
	}

	public EEMBillingInvMasterVO getBillInvMasterVO() {
		if (Objects.isNull(billInvMasterVO)) {
			this.billInvMasterVO = new EEMBillingInvMasterVO();
		}
		return billInvMasterVO;
	}

}
