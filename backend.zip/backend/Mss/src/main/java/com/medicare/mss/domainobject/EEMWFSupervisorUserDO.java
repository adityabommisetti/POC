package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMWFSupervisorUserDO {

	@ColumnMapper(columnName = "NAME", propertyName = "name")
	private String name;

	@ColumnMapper(columnName = "INACTIVE_END_DATE", propertyName = "inactiveEndDate")
	private String inactiveEndDate;

	@ColumnMapper(columnName = "INACTIVE_START_DATE", propertyName = "inactiveStartDate")
	private String inactiveStartDate;

	@ColumnMapper(columnName = "PRIORITY4", propertyName = "prtyFour")
	private String prtyFour;

	@ColumnMapper(columnName = "PRTY_METHOD", propertyName = "prtyMethod")
	private String prtyMethod;

	@ColumnMapper(columnName = "PRIORITY1", propertyName = "prtyOne")
	private String prtyOne;

	@ColumnMapper(columnName = "PRIORITY3", propertyName = "prtyThree")
	private String prtyThree;

	@ColumnMapper(columnName = "PRIORITY2", propertyName = "prtyTwo")
	private String prtyTwo;

	@ColumnMapper(columnName = "USER_ID", propertyName = "userId")
	private String userId;

	@ColumnMapper(columnName = "USER_STATUS", propertyName = "userStatus")
	private String userStatus;
	
	@ColumnMapper(columnName = "USER_LEVEL", propertyName = "userLevel")
	private String userLevel;

}
