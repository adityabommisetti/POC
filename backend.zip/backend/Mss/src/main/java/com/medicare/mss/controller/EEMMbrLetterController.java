package com.medicare.mss.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.service.EEMMbrLetterServices;
import com.medicare.mss.vo.EEMMbrLetterMasterVO;
import com.medicare.mss.vo.EmCorrMbrVO;
import com.medicare.mss.vo.EmCorrVarDataVO;

@RestController
public class EEMMbrLetterController {

	@Autowired
	private EEMMbrLetterServices mbrLetterServices;

	@GetMapping(ReqMappingConstants.MBR_LETTER_SELECT)
	public ResponseEntity<JSONResponse> getMbrLettersSelect(@PathVariable(name = "mbrId") String memberId) {

		EEMMbrLetterMasterVO mbrLetterMasterVO = new EEMMbrLetterMasterVO();
		List<EmCorrMbrVO> mbrLetterVOList = mbrLetterServices.getMbrLettersList(memberId);

		JSONResponse jsonResponse = new JSONResponse();
		if (mbrLetterVOList == null || mbrLetterVOList.isEmpty()) {

			jsonResponse.setMessage(EEMConstants.DATA_NOT_FOUND);
			jsonResponse.setData(null);
			return new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);

		} 
		else {
			mbrLetterMasterVO.setLstLetterVO(mbrLetterVOList);
			
			Map<String, String> searchParamMap=new HashMap<>();

			searchParamMap.put("fileBatchId", mbrLetterVOList.get(0).getFilebatchid());
			searchParamMap.put("recordType", mbrLetterVOList.get(0).getRecordType());
			searchParamMap.put("primaryId", mbrLetterVOList.get(0).getPrimaryId());
			searchParamMap.put("letterName", mbrLetterVOList.get(0).getLetterName());
				
			List<EmCorrVarDataVO> emCorrMbrVOList = mbrLetterServices.getMbrLetterVarDataList(searchParamMap);
			if (emCorrMbrVOList == null ||  emCorrMbrVOList.isEmpty()) {
				mbrLetterMasterVO.setLstMbrCorrVO(new ArrayList<EmCorrVarDataVO>());
				jsonResponse.setStatus("OK");
				jsonResponse.setMessage("");
				jsonResponse.setData(mbrLetterMasterVO);
			}
			else {
				mbrLetterMasterVO.setLstMbrCorrVO(emCorrMbrVOList);
				jsonResponse.setStatus("OK");
				jsonResponse.setMessage("");
				jsonResponse.setData(mbrLetterMasterVO);
			}
			
		}

		return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
	}


	@PostMapping(ReqMappingConstants.MBR_LETTER_VAR_DATA)
	public ResponseEntity<JSONResponse> getLetterVarData(@RequestBody Map<String, String> searchParamMap) {

		List<EmCorrVarDataVO> emCorrMbrVOList = mbrLetterServices.getMbrLetterVarDataList(searchParamMap);
		return sendResponse(emCorrMbrVOList);
	}

	@PostMapping(ReqMappingConstants.MBR_LETTER_PDF)
	public ResponseEntity<JSONResponse> displayDocumentFromDB(@RequestBody Map<String, String> searchParamMap) {
		byte[] blobByte = mbrLetterServices.getDisplayDocument(searchParamMap);
		return sendResponse(blobByte);
	}

	private ResponseEntity<JSONResponse> sendResponse(Object object) {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;
		jsonResponse.setData(object);
		if (null == object) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
			jsonResponse.setMessage(EEMConstants.BLANK);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}
}
