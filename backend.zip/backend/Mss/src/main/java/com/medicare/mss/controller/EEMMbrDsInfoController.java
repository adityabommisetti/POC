/**
 * 
 */
package com.medicare.mss.controller;

import java.text.ParseException;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.service.EEMMbrDsInfoService;
import com.medicare.mss.vo.EEMMbrDsInfoVO;

/**
 * @author DU20098149
 *
 */
@RestController
@RequestMapping("/mbr")
public class EEMMbrDsInfoController {

	@Autowired
	private EEMMbrDsInfoService eemMbrDsInfoService;

	@GetMapping(ReqMappingConstants.MBR_GET_DSINFO)
	public ResponseEntity<JSONResponse> getMbrDsInfos(@PathVariable(name = "mbrId") String mbrId,
			@PathVariable(name = "showAll") String showAll) {

		List<EEMMbrDsInfoVO> mbrDsInfoList = eemMbrDsInfoService.getMbrDsInfos(mbrId, showAll);
		
		return sendResponse(mbrDsInfoList);
	}

	@PostMapping(ReqMappingConstants.MBR_UPDATE_DSINFO)
	public ResponseEntity<JSONResponse> updateMbrDsInfo(@RequestBody EEMMbrDsInfoVO mbrDsInfoVO) {

		List<EEMMbrDsInfoVO> mbrDsInfoList = null;
		boolean updateSuccess;
		try {
			updateSuccess = eemMbrDsInfoService.mbrDsInfoUpdate(mbrDsInfoVO);
			if (updateSuccess) {
				mbrDsInfoList = eemMbrDsInfoService.getMbrDsInfos(mbrDsInfoVO.getMemberId(),
						mbrDsInfoVO.getShowAll());
			} 
		} catch (ApplicationException | ParseException | CloneNotSupportedException exp) {
			throw new ApplicationException(exp, "something went wrong!");
		}

		
		return sendResponse(mbrDsInfoList);
	}

	@PostMapping(ReqMappingConstants.MBR_DELETE_DSINFO)
	public ResponseEntity<JSONResponse> deleteMbrDsInfo(@RequestBody EEMMbrDsInfoVO mbrDsInfoVO) {

		List<EEMMbrDsInfoVO> mbrDsInfoList = null;
		boolean deleteSuccess;
		try {
			deleteSuccess = eemMbrDsInfoService.deleteMbrDsInfo(mbrDsInfoVO);
			if (deleteSuccess) {
				mbrDsInfoList = eemMbrDsInfoService.getMbrDsInfos(mbrDsInfoVO.getMemberId(),
						mbrDsInfoVO.getShowAll());
			} 
		} catch (CloneNotSupportedException | ParseException exp) {
			throw new ApplicationException(exp, "something went wrong!");
		}

		
		return sendResponse(mbrDsInfoList);
	}
	
	private ResponseEntity<JSONResponse> sendResponse(Object result) {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;

		if (Objects.isNull(result)) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setData(result);
			jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
			jsonResponse.setMessage(EEMConstants.SUCCESS);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}
}
