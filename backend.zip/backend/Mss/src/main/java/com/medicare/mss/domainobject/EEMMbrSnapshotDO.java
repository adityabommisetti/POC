/**
 * 
 */
package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

/**
 * @author dkumar
 *
 */
@Data
public class EEMMbrSnapshotDO {

	@ColumnMapper(columnName = "LI_COPAY_CD", propertyName = "lisCopayCd")
	private String lisCopayCd;
	@ColumnMapper(columnName = "LIS_PCT_CD", propertyName = "lisPctCd")
	private String lisPctCd;
	@ColumnMapper(columnName = "LIS_AMT", propertyName = "lisAmt")
	private String lisAmt;
	
	@ColumnMapper(columnName = "NBR_UNCOV_MONTHS", propertyName = "numUnCovMths")
	private String numUnCovMths;
	@ColumnMapper(columnName = "LEP_AMT", propertyName = "lepAmt")
	private String lepAmt;
	
	@ColumnMapper(columnName = "PCP_NAME", propertyName = "pcpName")
	private String pcpName;
	
	@ColumnMapper(columnName = "BILLING_AMT", propertyName = "billingAmt")
	private String billingAmt;
	
}
