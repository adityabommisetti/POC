package com.medicare.mss.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EEMMbrPrintIDCardVO {

	private String customerId;
	private String memberId;
	private String triggerType;
	private String triggerCode;
	private String planId;
	private String pbpId;
	private String planDesignation;
	private String printCode;
	private String effectiveStartDate;
	private String userId;

}
