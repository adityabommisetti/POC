/**
 * 
 */
package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

/**
 * @author DU20098149
 *
 */
@Data
public class EEMLEPMaximusDO {

	@ColumnMapper(columnName = "CASE_FILE_DUE_DATE", propertyName = "caseFileDueDate")
	private String caseFileDueDate;

	@ColumnMapper(columnName = "CASE_FILE_NUMBER", propertyName = "caseFileNumber")
	private String caseFileNumber;

	@ColumnMapper(columnName = "CASE_FILE_REC_DATE", propertyName = "caseFileRecDate")
	private String caseFileRecDate;

	@ColumnMapper(columnName = "CREATE_TIME", propertyName = "createTime")
	private String createTime;

	@ColumnMapper(columnName = "CREATE_USERID", propertyName = "createUserId")
	private String createUserId;
	
	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;
	
	@ColumnMapper(columnName = "DECISION_REC_DATE", propertyName = "decisionRecDate")
	private String decisionRecDate;
	
	@ColumnMapper(columnName = "DECISION_TYPE", propertyName = "decisionType")
	private String decisionType;
	
	private String isUpdate;
	
	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;
	
	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserId")
	private String lastUpdtUserId;
	
	@ColumnMapper(columnName = "MEMBER_ID", propertyName = "memberId")
	private String memberId;

	private String name;
	
	@ColumnMapper(columnName = "TRANSACTION_DUE_DATE", propertyName = "transactionDueDate")
	private String transactionDueDate;
	
}
