package com.medicare.mss.util;

final public class AddressFormatter {

	/** Creates a new instance of AddressFormatter */
	private AddressFormatter() {
	}

	public static String formatZip(String zip_code) {

		if (zip_code == null)
			return "";

		String frmtZipCode = null;

		int len = zip_code.trim().length();

		if (len == 0)
			return "";

		if (len == 9) {
			frmtZipCode = zip_code.substring(0, 5) + "-" + zip_code.substring(5);
			return frmtZipCode;
		}

		return zip_code;
	}

	public static String getZip5(String zipCd) {

		if (zipCd == null)
			return "";
		int len = zipCd.length();
		if (len > 5)
			len = 5;
		return zipCd.substring(0, len);
	}

	public static String getZip4(String zipCd) {

		if (zipCd == null)
			return "";
		int len = zipCd.length();
		if (len > 5) {
			if (len == 9)
				return zipCd.substring(5);
			return zipCd.substring(6);
		}
		return "";
	}

}
