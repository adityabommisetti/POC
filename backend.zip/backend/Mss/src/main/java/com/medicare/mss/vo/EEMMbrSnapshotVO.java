package com.medicare.mss.vo;

import java.io.Serializable;

import lombok.Data;

@Data
public class EEMMbrSnapshotVO implements Serializable {

	private static final long serialVersionUID = -8823361428770405624L;
	
	private String lisCopayCd;
	private String lisPctCd;
	private String lisAmt;
	private String numUnCovMths;
	private String lepAmt;
	private String pcpName;
	private String billingAmt;
	private String supplementalId;
}