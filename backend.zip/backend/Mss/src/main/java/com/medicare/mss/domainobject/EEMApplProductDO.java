package com.medicare.mss.domainobject;

import lombok.Data;

@Data
public class EEMApplProductDO {

	private String area;
	private String areaId;
	private String county;
	private String countyCd;
	private String customerId;
	private String dsrRebateAmt;
	private String eghpInd;
	private String groupId;
	private String groupName;	
	private String lineOfBusiness;
	private String pbpId;
	private String planDesignation;
	private String planId;
	private String premiumReductionAmt;
	private String productId;
	private String productName;
	private String prtCPremiumAmt;
	private String prtDPremiumAmt;
	private String pymtAmt;
	private String segmentId;
	private String snpInd;
	private String startDt;
	private String state;
	private String stateCd;
	private String supplPremiumAmt;
	private String zipCode4;
	private String zipCode5;
	
}
