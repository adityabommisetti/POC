package com.medicare.mss.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode(callSuper = false)
public class EEMMbrLisInfoVO extends BaseVO implements EMDatedSegmentVO, Cloneable, Serializable {

	private static final long serialVersionUID = -1324752784018998337L;

	private String effEndDate;
	private String effStartDate;
	private String licBaeInd;
	private String liCoPayCd;
	private String liCoPayDesc;
	private String lisAmt;
	private String lisBaeInd;
	private String lisPctCd;
	private String memberId;
	private String overrideInd;
	private String spapAmt;
	private String subsidySourceDesc;
	private String subsidySourceInd;

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	public String getEffEndDateFrmt() {
		return DateFormatter.reFormat(effEndDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getEffStartDateFrmt() {
		return DateFormatter.reFormat(effStartDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	@Override
	public String getType() {
		return liCoPayCd + lisPctCd;
	}

	@Override
	public boolean isEndDateChange(Object obj) {

		EEMMbrLisInfoVO chkVO = (EEMMbrLisInfoVO) obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate) && chkVO.getLiCoPayCd().equals(this.liCoPayCd)
				&& chkVO.getLisPctCd().equals(this.lisPctCd) && chkVO.getLisAmt().equals(this.lisAmt)
				&& chkVO.getSpapAmt().equals(this.spapAmt) && chkVO.getMemberId().equals(this.memberId)
				&& chkVO.getCustomerId().equals(this.getCustomerId())
				&& chkVO.getOverrideInd().equals(this.overrideInd))
			return true;
		return false;
	}

	@Override
	public boolean isForSamePeriod(Object obj) {

		EEMMbrLisInfoVO chkVO = (EEMMbrLisInfoVO) obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate) && chkVO.getEffEndDate().equals(this.effEndDate)
				&& chkVO.getMemberId().equals(this.memberId) && chkVO.getCustomerId().equals(this.getCustomerId())
				&& chkVO.getOverrideInd().equals(this.overrideInd))
			return true;

		return false;
	}

	@Override
	public boolean isSame(Object obj) {

		EEMMbrLisInfoVO chkVO = (EEMMbrLisInfoVO) obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate) && chkVO.getEffEndDate().equals(this.effEndDate)
				&& chkVO.getLiCoPayCd().equals(this.liCoPayCd) && chkVO.getLisPctCd().equals(this.lisPctCd)
				&& chkVO.getLisAmt().equals(this.lisAmt) && chkVO.getSpapAmt().equals(this.spapAmt)
				&& chkVO.getMemberId().equals(this.memberId) && chkVO.getCustomerId().equals(this.getCustomerId())
				&& chkVO.getOverrideInd().equals(this.overrideInd) && chkVO.getCreateTime().equals(this.getCreateTime())
				&& chkVO.getCreateUserId().equals(this.getCreateUserId())
				&& chkVO.getLastUpdtTime().equals(this.getLastUpdtTime())
				&& chkVO.getLastUpdtUserId().equals(this.getLastUpdtUserId()))
			return true;
		return false;
	}

	public void setEffEndDateFrmt(String effEndDate) {
		this.effEndDate = DateFormatter.reFormat(effEndDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public void setEffStartDateFrmt(String effStartDate) {
		this.effStartDate = DateFormatter.reFormat(effStartDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

}
