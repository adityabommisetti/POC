package com.medicare.mss.service;

import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.lang.reflect.Field;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.StringTokenizer;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.caching.EEMPersistence;
import com.medicare.mss.caching.EEMProfileSettings;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMApplDAO;
import com.medicare.mss.daoImpl.MBDPersistence;
import com.medicare.mss.domainobject.EEMApplAgentDO;
import com.medicare.mss.domainobject.EEMApplFieldErrorDO;
import com.medicare.mss.domainobject.EEMApplOtherCovDO;
import com.medicare.mss.domainobject.EEMApplPlanDO;
import com.medicare.mss.domainobject.EEMApplProdSearchDO;
import com.medicare.mss.domainobject.EEMApplProductDO;
import com.medicare.mss.domainobject.EEMApplTriggerDO;
import com.medicare.mss.domainobject.EEMApplicationDO;
import com.medicare.mss.domainobject.EEMProfileItemDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.EEMElection;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.util.NumberFormatter;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EEMApplAddressVO;
import com.medicare.mss.vo.EEMApplAgentVO;
import com.medicare.mss.vo.EEMApplEligibilityVO;
import com.medicare.mss.vo.EEMApplErrorVO;
import com.medicare.mss.vo.EEMApplMasterVO;
import com.medicare.mss.vo.EEMApplOtherCovVO;
import com.medicare.mss.vo.EEMApplOtherPlanVO;
import com.medicare.mss.vo.EEMApplPlanVO;
import com.medicare.mss.vo.EEMApplProductVO;
import com.medicare.mss.vo.EEMApplicationVO;
import com.medicare.mss.vo.EEMElectionVO;
import com.medicare.mss.vo.MBD;

/**
 * This class contains Application validation functionality methods.
 * 
 * @author Ramesh
 *
 */
@Service
public class EEMApplValidationService {

	@Autowired
	private CacheService sessionHelper;

	@Autowired
	EEMPersistence eemPersistence;

	@Autowired
	EEMApplDAO applicationDAO;

	@Autowired
	EEMProfileSettings eemProfileSettings;

	@Autowired
	EEMCodeCache eemCodeCache;

	@Autowired
	EEMElection eemElection;

	@Autowired
	MBDPersistence mbdPersistence;

	private String effStartDate = "00000000";
	private String effEndDate = "99999999";
	private String brokerType = "brokerType";
	private String mbrHicNbr = "mbrHicNbr";

	public EEMApplMasterVO validateApplication(EEMApplMasterVO eemApplMasterVO) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		List<EEMApplFieldErrorDO> fieldErrorList = eemPersistence.getApplicationFieldErrorDetails(customerId);
		if (null != fieldErrorList) {
			this.validateApplicationFields(eemApplMasterVO, fieldErrorList);
			this.validateUpdateFields(eemApplMasterVO, fieldErrorList);
		}
		return eemApplMasterVO;
	}

	private void validateApplicationFields(EEMApplMasterVO eemApplMasterVO, List<EEMApplFieldErrorDO> fieldErrorList) {

		Field field = null;
		Object value = null;
		@SuppressWarnings("rawtypes")
		Class objClass = null;
		String sFormField = "";
		String formFieldClass = "";
		try {
			String customerId = sessionHelper.getUserInfo().getCustomerId();
			int applId = eemApplMasterVO.getApplVO().getApplId();

			String needsRFI = hasRFI(customerId, applId);

			List<EEMApplErrorVO> lstErrors = new ArrayList<>();

			for (EEMApplFieldErrorDO fieldVO : fieldErrorList) {
				String fieldClass = trimToEmpty(fieldVO.getFormFieldClass());

				if (!fieldClass.equals(formFieldClass)) {
					formFieldClass = fieldClass;
					objClass = Class.forName(EEMConstants.EEM_APPL_PACKAGE_QUALIFIER + formFieldClass);
				}
				sFormField = trimToEmpty(fieldVO.getFormField());
				if (sFormField.isEmpty()) {
					continue;
				}
				try {
					field = objClass.getDeclaredField(sFormField);
				} catch (NoSuchFieldException e) {
					continue;
				}
				field.setAccessible(true);
				String retType = field.getType().toString();
				value = this.getApplFieldValue(eemApplMasterVO, field, formFieldClass);
				if (null == value) {
					continue;
				}
				if(StringUtils.equals("mbrSsn", field.getName())) {
					value = CommonUtils.deFormatSsn(value.toString());
				}
				if (retType.equals("class java.lang.String")) {
					EEMApplErrorVO objError = this.validateError(value.toString(), fieldVO, eemApplMasterVO, needsRFI);
					if (objError != null) {
						lstErrors.add(objError);
					}
				}
			}
			eemApplMasterVO.setApplErrList(!lstErrors.isEmpty() ? lstErrors : null);
		} catch (Exception exp) {
			throw new ApplicationException(exp.getMessage());
		}
	}

	private String hasRFI(String customerId, int applId) {
		String needsRFI = "";
		EEMApplTriggerDO eemApplTriggerDO = applicationDAO.getApplTriggerForFunc(applId, customerId);

		if (Objects.nonNull(eemApplTriggerDO)) {
			needsRFI = trimToEmpty(eemApplTriggerDO.getTriggerStatus());
		}
		return needsRFI;
	}

	private Object getApplFieldValue(EEMApplMasterVO eemApplMasterVO, Field field, String formFieldClass)
			throws IllegalAccessException {

		switch (formFieldClass) {
		case EEMConstants.EEM_APPLICATION_VO:
			return field.get(eemApplMasterVO.getApplVO());
		case EEMConstants.EEM_APPL_PLAN_VO:
			return field.get(eemApplMasterVO.getApplPlanVO());
		case EEMConstants.EEM_APPL_ADDRESS_VO:
			return field.get(eemApplMasterVO.getApplAddress());
		case EEMConstants.EEM_APPL_AGENT_VO:
			return field.get(eemApplMasterVO.getApplAgentVO());
		case EEMConstants.EEM_APPL_ELIGIBILITY_VO:
			return field.get(eemApplMasterVO.getApplEligiVO());
		case EEMConstants.EEM_APPL_OTHER_COV_VO:
			return field.get(eemApplMasterVO.getApplOtherCovVO());
		case EEMConstants.EEM_APPL_OTHER_PLAN_VO:
			return field.get(eemApplMasterVO.getApplOtherPlanVO());
		case EEMConstants.EEM_MEDOFFICE_VO:
			return field.get(eemApplMasterVO.getMedOfficeVO());
		case EEMConstants.EEM_GRP_PRODUCT_VO:
			return field.get(eemApplMasterVO.getGrpProdVO());
		default:
			return "";
		}
	}

	private EEMApplErrorVO validateError(String val, EEMApplFieldErrorDO fieldVO, EEMApplMasterVO eemApplMasterVO,
			String needsRFI) {

		String status = "";
		boolean isError = false;
		EEMApplErrorVO objError = null;
		try {
			EEMApplicationVO eemApplicationVO = eemApplMasterVO.getApplVO();
			EEMApplAddressVO applAddressVO = eemApplMasterVO.getApplAddress();
			String reqInd = fieldVO.getRequiredInd();
			String formField = fieldVO.getFormField();

			if (reqInd.isEmpty() || formField.equals("applDate") || formField.equals("electionType"))
				return objError;

			if ("mbrRxId".equals(formField)) {
				if (!validateRxId(eemApplMasterVO))
					return objError;
				String rxIdInd = eemProfileSettings.getParmInd(eemApplicationVO.getCustomerId(), EEMConstants.RXID,
						DateUtil.getTodaysDate());
				if (null != rxIdInd && !rxIdInd.equals(EEMConstants.RXID_CUST_SUPPLIED))
					return objError;
			}
			// Not needed
			else if ("perCounty".equals(formField) && null != applAddressVO
					&& !applAddressVO.getPerCounty().trim().isEmpty()) {
				val = trimToEmpty(
						(applicationDAO.getCounty(applAddressVO.getPerZip5(), applAddressVO.getPerZip4())).trim());
			} else if ("mbrApplNo".equals(formField)) {
				String applNbrInd = eemProfileSettings.getParmInd(eemApplicationVO.getCustomerId(), EEMConstants.APPNBR,
						DateUtil.getTodaysDate());
				if (null != applNbrInd && applNbrInd.equals(EEMConstants.APPNBR_DERIVED)) {
					return objError;
				}
			} else if ("altMbrId".equals(formField)) {
				String supplInd = eemProfileSettings.getParmInd(eemApplicationVO.getCustomerId(), EEMConstants.SUPPLID,
						DateUtil.getTodaysDate());
				if (null != supplInd && !supplInd.equals(EEMConstants.SUPPLID_CUST_SUPPLIED))
					return objError;
			}
			if (val.isEmpty()) {
				if (reqInd.equalsIgnoreCase("R")) {
					isError = true;
					if (needsRFI.isEmpty())
						status = EEMConstants.APPL_STATUS_INCRFIREQ;
					else {
						if (needsRFI.equals(EEMConstants.TRIG_STATUS_CLOSED))
							status = EEMConstants.APPL_STATUS_INCRFIGEN;
						else
							status = EEMConstants.APPL_STATUS_INCRFITRG;
					}
				} else if (reqInd.equalsIgnoreCase("C")) {
					isError = true;
					status = EEMConstants.APPL_STATUS_ERRORCRITL;
				} else if (reqInd.equalsIgnoreCase("Y")) {
					isError = true;
					status = EEMConstants.APPL_STATUS_ERROR;
				}
			} else {
				if (!validateEditRule(val, fieldVO, eemApplMasterVO)) {
					isError = true;
					if (reqInd.equalsIgnoreCase("R"))
						status = EEMConstants.APPL_STATUS_INCRFIREQ;
					else if (reqInd.equalsIgnoreCase("C"))
						status = EEMConstants.APPL_STATUS_ERRORCRITL;
					else if (reqInd.equalsIgnoreCase("Y")) {
						status = EEMConstants.APPL_STATUS_ERRORCRITL;
					} else if (reqInd.equalsIgnoreCase("W")) {
						status = EEMConstants.APPL_STATUS_ERROR;
					}
				}
			}
			String incmpltcob = eemProfileSettings.getParmInd(eemApplicationVO.getCustomerId(), EEMConstants.INCMPLTCOB,
					DateUtil.getTodaysDate());
			if (null != incmpltcob && !incmpltcob.equals("Y")
					&& !checkOtherDrugCoverage(val, fieldVO, eemApplMasterVO)) {
				isError = true;
				status = EEMConstants.APPL_STATUS_ERRORCRITL;
			}

			if (("perCity".equals(formField) || "mailCity".equals(formField) || "authRepCity".equals(formField))
					&& (!isError && !checkValidCity(val, fieldVO, eemApplMasterVO))) {
				isError = true;
				status = EEMConstants.APPL_STATUS_ELGWARNING;
			} else if (("perState".equals(formField) || "mailState".equals(formField)
					|| "authRepState".equals(formField))
					&& (!isError && !checkValidState(val, fieldVO, eemApplMasterVO))) {
				isError = true;
				status = EEMConstants.APPL_STATUS_ELGWARNING;
			}
			if (isError) {
				objError = getErrorVO(fieldVO, eemApplMasterVO, fieldVO.getErrorCd(), status);
				objError.setErrorData(val);
			}
		} catch (Exception exp) {
			throw new ApplicationException(exp);
		}
		return objError;
	}

	private boolean validateRxId(EEMApplMasterVO eemApplMasterVO) {
		String planDesgn = trimToEmpty(eemApplMasterVO.getGrpProdVO().getPlanDesignation());
		if (planDesgn.equals(EEMConstants.PLAN_DESGN_MAPD) || planDesgn.equals(EEMConstants.PLAN_DESGN_COPD)
				|| planDesgn.equals(EEMConstants.PLAN_DESGN_PDP)) {
			return true;
		}
		return false;
	}

	private boolean validateEditRule(String val, EEMApplFieldErrorDO fieldVO, EEMApplMasterVO eemApplMasterVO) {

		boolean result = true;
		try {
			EEMApplicationVO eemApplicationVO = eemApplMasterVO.getApplVO();
			String editRuleId = trimToEmpty(fieldVO.getEditRuleId());

			String formField = trimToEmpty(fieldVO.getFormField());
			if (editRuleId.isEmpty() || formField.isEmpty()) {
				return result;
			}
			result = matchEditRuleId(val, result, editRuleId);

			DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
			if (result && formField.equals("applDate")) {
				LabelValuePair nvp = eemElection.validApplicationDate(eemApplicationVO.getCustomerId(),
						DateFormatter.reFormat(val, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD),
						eemApplMasterVO.getApplPlanVO().getElectionType());
				if (!nvp.getLabel().equals("000"))
					result = false;
			}
			if (result && formField.equals("mbrBirthDt")) {
				Date birthDate = df.parse(val);
				if (!trimToEmpty(eemApplicationVO.getApplDate()).isEmpty()) {
					Date applDate = df.parse(eemApplicationVO.getApplDate().trim());
					if (birthDate.after(applDate)) {
						result = false;
					}
				}
			}
			if ((result && formField.equals("signDt") && !trimToEmpty(eemApplicationVO.getSignOvrrdDt()).equals("Y"))
					&& null != eemApplMasterVO.getApplPlanVO()) {
				result = eemElection.validSignatureDate(
						DateFormatter.reFormat(val, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD),
						DateFormatter.reFormat(eemApplicationVO.getApplDate(), DateFormatter.MM_DD_YYYY,
								DateFormatter.YYYYMMDD),
						eemApplMasterVO.getApplPlanVO().getElectionType(), eemApplicationVO.getEditOverride());
			}
		} catch (Exception exp) {
			throw new ApplicationException(exp);
		}
		return result;
	}

	private boolean matchEditRuleId(String val, boolean result, String editRuleId) {
		if (editRuleId.equals("ALPHAEMAIL")) {
			result = val.matches("[a-zA-Z0-9#\\&\\-_\\.@]*");
		} else if (editRuleId.equals("ALPHANUM")) {
			result = val.matches("[a-zA-Z0-9]*");
		} else if (editRuleId.equals("ALPHAONLY")) {
			result = val.matches("[a-zA-Z]*");
		} else if (editRuleId.equals("ALPHAPLUS")) {
			result = val.matches("[a-zA-Z, -\\._]*");
		} else if (editRuleId.equals("ALPHASUFFX")) {
			result = val.matches("[a-zA-Z\\.]*");
		} else if (editRuleId.equals("CENY")) {
			result = val.matches("(C|E|N|Y)");
		} else if (editRuleId.equals("CHARACTER")) {
			result = val.matches("[^|]*");
		} else if (editRuleId.equals("ENBLANK")) {
			result = val.matches("( |E|N)");
		} else if (editRuleId.equals("HDRTLR")) {
			result = val.matches("(HDR|TLR)");
		} else if (editRuleId.equals("NUMERIC")) {
			result = val.matches("[0-9\\.]*");
		} else if (editRuleId.equals("NUMERPLUS")) {
			result = val.matches("[0-9-]*");
		} else if (editRuleId.equals("VVVEXAMPLE")) {
			if (val.matches("[A-Z]{3}") && !val.matches("(BBB|CCC|DDD)"))
				result = true;
		} else if (editRuleId.equals("YESNO")) {
			result = val.matches("(Y|N)");
		} else if (editRuleId.equals("YESNOBLANK")) {
			result = val.matches("( |Y|N)");
		} else if (editRuleId.equals("DCLEZIP")) {
			boolean checkZip = applicationDAO.checkZip(val);
			if (!checkZip) {
				result = false;
			}
		}
		return result;
	}

	private boolean checkOtherDrugCoverage(String val, EEMApplFieldErrorDO fieldVO, EEMApplMasterVO eemApplMasterVO) {
		String field = fieldVO.getFormField();
		if (field.equals("otherCov") || field.equals("covBin") || field.equals("covId") || field.equals("groupNo")
				|| field.equals("covPcn")) {
			if (trimToEmpty(eemApplMasterVO.getApplOtherCovVO().getSecRxInd()).equals("Y") && val.isEmpty()) {
				return false;
			}
		}
		return true;
	}

	private boolean checkValidCity(String val, EEMApplFieldErrorDO fieldVO, EEMApplMasterVO eemApplMasterVO) {
		String formField = fieldVO.getFormField();
		EEMApplAddressVO objVO = eemApplMasterVO.getApplAddress();
		String[] city = applicationDAO.getCityName(objVO, fieldVO);
		if (city != null) {
			StringTokenizer stk = new StringTokenizer(city[0], "|");
			if ((stk.hasMoreTokens()) && (!val.equalsIgnoreCase(stk.nextToken()))) {
				String zip5 = getZip5(objVO, formField);
				boolean validCity = applicationDAO.getSecondaryCityName(zip5, val);
				if (!validCity) {
					fieldVO.setErrorCd("AP199");
					return false;
				}
			}
		} else if (StringUtils.isNotEmpty(getZip5(objVO, formField))) {
			fieldVO.setErrorCd("AP199");
			return false;
		}
		return true;
	}

	private String getZip5(EEMApplAddressVO objVO, String formField) {
		String zip5 = "";
		if ("perCity".equals(formField)) {
			zip5 = trimToEmpty(objVO.getPerZip5());
		} else if ("mailCity".equals(formField)) {
			zip5 = trimToEmpty(objVO.getMailZip5());
		} else if ("authRepCity".equals(formField)) {
			zip5 = trimToEmpty(objVO.getAuthRepZip5());
		}
		return zip5;
	}

	private boolean checkValidState(String val, EEMApplFieldErrorDO fieldVO, EEMApplMasterVO eemApplMasterVO) {

		String formField = fieldVO.getFormField();
		EEMApplAddressVO objVO = eemApplMasterVO.getApplAddress();
		String[] city = applicationDAO.getCityName(objVO, fieldVO);
		if (city != null) {
			StringTokenizer stk = new StringTokenizer(city[0], "|");
			if (stk.hasMoreTokens()) {
				stk.nextToken();
				if (!val.equalsIgnoreCase(eemCodeCache.getCode(stk.nextToken(), eemPersistence.getLstStates()))) {
					fieldVO.setErrorCd("AP200");
					return false;
				}
			}
		} else if (("perState".equals(formField) && !trimToEmpty(objVO.getPerZip5()).isEmpty())
				|| ("mailState".equals(formField) && !trimToEmpty(objVO.getMailZip5()).isEmpty())
				|| ("authRepState".equals(formField) && !trimToEmpty(objVO.getAuthRepZip5()).isEmpty())) {
			fieldVO.setErrorCd("AP200");
			return false;
		}
		return true;
	}

	private EEMApplErrorVO getErrorVO(EEMApplFieldErrorDO field, EEMApplMasterVO eemApplMasterVO, String errorCode,
			String status) {
		EEMApplicationVO eemApplicationVO = eemApplMasterVO.getApplVO();
		EEMApplErrorVO objError = new EEMApplErrorVO();
		objError.setCustomerId(eemApplicationVO.getCustomerId());
		objError.setApplicationId(eemApplicationVO.getApplId());
		objError.setFieldNbr(field.getFieldNbr());
		objError.setRfiInd(!trimToEmpty(field.getRequiredInd()).equals("N") ? "Y" : "N");
		objError.setErrorCd(errorCode);
		objError.setErrorMsg(this.getDescriptionFromNameValuePairList(errorCode, eemPersistence.getLstErrorCodes()));
		objError.setFormField(field.getFormField());
		objError.setLastUpdtUserId(eemApplMasterVO.getUserId());
		objError.setStatus(status);
		return objError;
	}

	private String getDescriptionFromNameValuePairList(String code, List<LabelValuePair> lst) {
		LabelValuePair lp = null;
		Iterator<LabelValuePair> it = lst.iterator();
		while (it.hasNext()) {
			lp = it.next();
			if (lp.getValue().equals(code)) {
				return lp.getLabel();
			}
		}
		return null;
	}

	private void validateUpdateFields(EEMApplMasterVO eemApplMasterVO, List<EEMApplFieldErrorDO> lstFields) {

		String checkMedicaid = "";
		boolean validProduct = false;

		List<EEMApplProductDO> prodList = getProductList(eemApplMasterVO);
		if (prodList != null && !prodList.isEmpty()) {
			validProduct = true;
		}
		EEMApplPlanVO eemApplPlanVO = eemApplMasterVO.getApplPlanVO();
		EEMApplicationVO eemApplicationVO = eemApplMasterVO.getApplVO();
		String custNbr = sessionHelper.getUserInfo().getCustNbr();
		String customerId = eemApplicationVO.getCustomerId();
		String enrollPlan = eemApplPlanVO.getEnrollPlan();
		String enrollPbp = eemApplPlanVO.getEnrollPbp();

		List<EEMApplErrorVO> lstErrors = new ArrayList<>();
		try {
			EEMProfileItemDO eemProfileItemDO = eemProfileSettings.getProfileObject(customerId, EEMConstants.MEDICAID);
			checkMedicaid = (null == eemProfileItemDO) ? "" : trimToEmpty(eemProfileItemDO.getParmIndValue());
			eemApplPlanVO.setReqDtCov(eemApplPlanVO.getReqDtCov());
			eemApplPlanVO.setArrPlanDetails(applicationDAO.getPlanType(custNbr, enrollPlan, enrollPbp));

			if (!trimToEmpty(eemApplicationVO.getMbrHicNbr()).isEmpty()) {
				validateEligibility(eemApplMasterVO, lstFields, lstErrors);
			}
			EEMApplErrorVO objError = checkReqDtCov(eemApplMasterVO, lstFields, prodList);
			if (objError != null) {
				lstErrors.add(objError);
			}
			checkSupplId(eemApplMasterVO, lstFields, lstErrors);
			objError = checkDuplSupplId(eemApplMasterVO, lstFields);
			if (objError != null) {
				lstErrors.add(objError);
			}
			objError = checkEnrollProduct(eemApplMasterVO, lstFields);
			if (objError != null) {
				lstErrors.add(objError);
			}
			checkRxId(eemApplMasterVO, lstFields, lstErrors);
			checkElectionType(eemApplMasterVO, lstFields, lstErrors);
			checkApplDate(eemApplMasterVO, lstFields, lstErrors);

			if (EEMConstants.OPTION_APPLNEWMBR_MA.equals(eemApplicationVO.getApplType())) {
				checkEsrdInd(eemApplMasterVO, lstFields, validProduct, lstErrors);
				checkEsrdOverrideInd(eemApplMasterVO, lstFields, lstErrors);
			}
			checkElcReasonCd(eemApplMasterVO, lstFields, lstErrors);
			checkLTCFacility(eemApplMasterVO, lstFields, lstErrors);

			if ((!"N".equalsIgnoreCase(checkMedicaid))
					&& (EEMConstants.OPTION_APPLNEWMBR_MA.equals(eemApplicationVO.getApplType())
							|| EEMConstants.OPTION_APPLNEWMBR_PD.equals(eemApplicationVO.getApplType()))) {
				checkMedicaidId(eemApplMasterVO, lstFields, lstErrors);
			}
			List<EEMApplErrorVO> lstPcpErors = this.checkProviderDates(eemApplMasterVO, lstFields);
			if (null != lstPcpErors && !lstPcpErors.isEmpty()) {
				Iterator<EEMApplErrorVO> iter = lstPcpErors.iterator();
				while (iter.hasNext()) {
					lstErrors.add(iter.next());
				}
			}
			List<EEMApplErrorVO> agentErrors = this.validateAgent(eemApplMasterVO, lstFields);
			if (null != agentErrors && !agentErrors.isEmpty()) {
				Iterator<EEMApplErrorVO> iter = agentErrors.iterator();
				while (iter.hasNext()) {
					lstErrors.add(iter.next());
				}
			}
			checkActiveAgent(eemApplMasterVO, lstFields, lstErrors);
			checkInvalidAgency(eemApplMasterVO, lstFields, lstErrors);

			if (!"Y".equalsIgnoreCase(eemApplicationVO.getAppDuplicateCheck())) {

				checkDuplicateApplication(eemApplMasterVO, lstFields, lstErrors);
			}

			checkDuplicateEnrollment(eemApplMasterVO, lstFields, lstErrors, eemApplicationVO.getApplType(),
					eemApplicationVO.getAppDuplicateCheck());
			checkRetroAppl(eemApplMasterVO, lstFields, lstErrors);

			eemApplMasterVO.setApplErrList(
					eemApplMasterVO.getApplErrList() == null ? new ArrayList<>() : eemApplMasterVO.getApplErrList());
			eemApplMasterVO.getApplErrList().addAll(lstErrors);
		} catch (Exception exp) {
			throw new ApplicationException(exp);
		}
	}

	private List<EEMApplProductDO> getProductList(EEMApplMasterVO eemApplMasterVO) {

		EEMApplPlanVO eemApplPlanVO = eemApplMasterVO.getApplPlanVO();
		EEMApplPlanDO eemApplPlanDO = new EEMApplPlanDO();
		BeanUtils.copyProperties(eemApplPlanVO, eemApplPlanDO);

		EEMApplProdSearchDO prodSearchDO = new EEMApplProdSearchDO();
		setProdSerachValue(eemApplMasterVO, prodSearchDO);

		return (applicationDAO.getProducts(prodSearchDO, eemApplPlanDO));
	}

	private void setProdSerachValue(EEMApplMasterVO eemApplMasterVO, EEMApplProdSearchDO prodSearchDO) {

		prodSearchDO.setCustomerId(trimToEmpty(eemApplMasterVO.getApplVO().getCustomerId()));
		prodSearchDO.setApplType(trimToEmpty(eemApplMasterVO.getApplVO().getApplType()));
		prodSearchDO.setSsaSt(trimToEmpty(eemApplMasterVO.getApplAddress().getPerState()));
		prodSearchDO.setSsaCnty(trimToEmpty(eemApplMasterVO.getApplAddress().getPerCounty()));
		prodSearchDO.setZip4(trimToEmpty(eemApplMasterVO.getApplAddress().getPerZip4()));
		prodSearchDO.setZip5(trimToEmpty(eemApplMasterVO.getApplAddress().getPerZip5()));
		prodSearchDO.setEnrollProdName(trimToEmpty(eemApplMasterVO.getGrpProdVO().getEnrollProdName()));
		prodSearchDO.setEnrollGroupName(trimToEmpty(eemApplMasterVO.getGrpProdVO().getEnrollGroupName()));
	}

	public void validateEligibility(EEMApplMasterVO eemApplMasterVO, List<EEMApplFieldErrorDO> lstFields,
			List<EEMApplErrorVO> lstErrors) {

		String status = "";
		String errorCode = "";
		String beqCheck = null;

		EEMApplicationVO objVO = eemApplMasterVO.getApplVO();
		EEMApplPlanVO eemApplPlanVO = eemApplMasterVO.getApplPlanVO();
		EEMApplAddressVO eemApplAddressVO = eemApplMasterVO.getApplAddress();
		try {
			objVO.setIsHicOrMbi("mbi".equalsIgnoreCase(StringUtil.isHicOrMbi(objVO.getMbrHicNbr())) ? "mbi" : "hic");

			if (eemApplMasterVO.getMbd() == null)
				eemApplMasterVO.setMbd(new MBD());
			MBD mbd = eemApplMasterVO.getMbd();
			objVO.setEligibilitySrcTable(mbd.getEligibilitySrcTable());

			EEMProfileItemDO eemProfileItemDO = eemProfileSettings.getProfileObject(objVO.getCustomerId(),
					EEMConstants.BEQCHECK);
			beqCheck = (null == eemProfileItemDO) ? "" : trimToEmpty(eemProfileItemDO.getParmIndValue());

			if ((trimToEmpty(mbd.getHicNbr()).isEmpty())
					|| (trimToEmpty(objVO.getEligibilitySrcTable()).equalsIgnoreCase(""))) {
				mbd = verifyEligibility(objVO.getMbrHicNbr(), objVO.getMbrLastName(), objVO.getMbrBirthDt(), beqCheck,
						objVO.getIsHicOrMbi(), objVO.getMbi());
				if (mbd != null) {
					objVO.setXrefNbr(mbd.getXrefClaimNbr());
					objVO.setNeedMBDUpdate("Y");
					objVO.setEligibilitySrcTable(mbd.getEligibilitySrcTable());
				}
			}
			if (mbd == null) {
				if (StringUtils.equalsIgnoreCase(objVO.getIsHicOrMbi(), "hic")) {
					errorCode = "AP357";
					status = EEMConstants.APPL_STATUS_ELGCRITICL;
				} else {
					errorCode = "AP062";
					status = EEMConstants.APPL_STATUS_ELGNOTFND;
				}
				objVO.setEligibilitySrcTable(EEMConstants.BLANK);
				if (StringUtils.isNotBlank(objVO.getMbrBirthDt())
						&& StringUtil.nonNullTrim(beqCheck).equals(EEMConstants.VALUE_YES)) {
					if (StringUtils.equalsIgnoreCase(objVO.getIsHicOrMbi(), "hic")) {
						errorCode = "AP357";
						status = EEMConstants.APPL_STATUS_ELGCRITICL;
					} else {
						status = EEMConstants.APPL_STATUS_BEQPENDING;
					}
				}
			} else {
				String birthDt = DateUtil.changedDateFormatForMonth(trimToEmpty(objVO.getMbrBirthDt()));
				mbd.setGenderCd(getMBDGender(mbd.getGenderCd()));

				String prtAStDt = DateUtil
						.changedDateFormatForMonth(trimToEmpty(eemApplMasterVO.getApplEligiVO().getPartAEffDate()));
				String prtAEndDt = DateUtil.changedDateFormatForMonth(trimToEmpty(mbd.getPrtAEntitleEndDate()));
				String prtBStDt = DateUtil
						.changedDateFormatForMonth(trimToEmpty(eemApplMasterVO.getApplEligiVO().getPartBEffDate()));
				String prtBEndDt = DateUtil.changedDateFormatForMonth(trimToEmpty(mbd.getPrtBEntitleEndDate()));
				String reqDtCov = DateUtil.changedDateFormatForMonth(trimToEmpty(eemApplPlanVO.getReqDtCov()));
				String deathDate = trimToEmpty(mbd.getDeathDate());
				String planDesig = trimToEmpty(eemApplMasterVO.getGrpProdVO().getPlanDesignation());
				String prtAMbd = DateUtil.changedDateFormatForMonth(trimToEmpty(mbd.getPrtAEntitleDate()));
				String prtBMbd = DateUtil.changedDateFormatForMonth(trimToEmpty(mbd.getPrtBEntitleDate()));
				String prtDMbd = DateUtil.changedDateFormatForMonth(trimToEmpty(mbd.getPrtDEligibleDate()));
				String prtDDate = DateUtil
						.changedDateFormatForMonth(trimToEmpty(eemApplMasterVO.getApplEligiVO().getPartDEffDate()));
				eemApplMasterVO.getApplEligiVO().setPartAEndDate(prtAEndDt);
				eemApplMasterVO.getApplEligiVO().setPartBEndDate(prtBEndDt);
				if (!((trimToEmpty(prtAStDt).equalsIgnoreCase(trimToEmpty(prtAMbd)))
						&& (trimToEmpty(prtBStDt).equalsIgnoreCase(trimToEmpty(prtBMbd)))
						&& (trimToEmpty(prtDDate).equalsIgnoreCase(trimToEmpty(prtDMbd))))
						&& !((trimToEmpty(prtAStDt).isEmpty()) && (trimToEmpty(prtBStDt).isEmpty())
								&& (trimToEmpty(prtDDate).isEmpty()))) {

					if (!trimToEmpty(prtAStDt).equalsIgnoreCase(trimToEmpty(prtAMbd))) {
						eemApplMasterVO.getApplEligiVO().setPartAEndDate(effEndDate);
					}

					if (!trimToEmpty(prtBStDt).equalsIgnoreCase(trimToEmpty(prtBMbd))) {
						eemApplMasterVO.getApplEligiVO().setPartBEndDate(effEndDate);
					}
					eemApplMasterVO.getApplEligiVO().setEligOverInd(EEMConstants.VALUE_YES);
				} else {
					eemApplMasterVO.getApplEligiVO().setEligOverInd(EEMConstants.VALUE_NO);
					if (prtAStDt.trim().isEmpty())
						eemApplMasterVO.getApplEligiVO()
								.setPartAEffDate(DateUtil.formatMmDdYyyy(
										null == mbd.getPrtAEntitleDate() || mbd.getPrtAEntitleDate().trim().isEmpty()
												? effStartDate
												: mbd.getPrtAEntitleDate().trim()));
					if (prtBStDt.trim().isEmpty())
						eemApplMasterVO.getApplEligiVO()
								.setPartBEffDate(DateUtil.formatMmDdYyyy(
										null == mbd.getPrtBEntitleDate() || mbd.getPrtBEntitleDate().trim().isEmpty()
												? effStartDate
												: mbd.getPrtBEntitleDate().trim()));
					if (prtDDate.trim().isEmpty())
						eemApplMasterVO.getApplEligiVO()
								.setPartDEffDate(DateUtil.formatMmDdYyyy(
										null == mbd.getPrtDEligibleDate() || mbd.getPrtDEligibleDate().trim().isEmpty()
												? effStartDate
												: mbd.getPrtDEligibleDate().trim()));
				}
				if (planDesig.isEmpty())
					planDesig = ("NMA".equals(objVO.getApplType()) || "CMA".equals(objVO.getApplType())) ? "MAPD"
							: "PDP";

				LabelValuePair eligRslt = eemElection.isEligible(reqDtCov, prtAMbd, prtAEndDt, prtBMbd, prtBEndDt,
						deathDate, planDesig);

				if (!eligRslt.getLabel().equals("000")) {
					if (eligRslt.getLabel().equals("002"))
						errorCode = "AP201";
					else
						errorCode = "AP064";
					status = EEMConstants.APPL_STATUS_ELGCRITICL;
				}
				if (errorCode.isEmpty()) {
					if (!objVO.getMbrLastName().equals(mbd.getLastName())
							|| !birthDt.equals(DateUtil.changedDateFormatForMonth(mbd.getBirthDate()))) {
						errorCode = "AP063";
						status = EEMConstants.APPL_STATUS_ELGCRITICL;
					} else if (!mbd.getFirstName().equals(objVO.getMbrFirstName())
							|| !mbd.getGenderCd().equals(getMBDGender(objVO.getMbrGender()))
							|| !mbd.getStateCd().equals(eemApplAddressVO.getPerState())
							|| !mbd.getCountyCd().equals(eemApplAddressVO.getPerCounty())) {
						errorCode = "AP063";
						status = EEMConstants.APPL_STATUS_ELGWARNING;
					}
				}
			}
			if (!errorCode.isEmpty()) {
				EEMApplFieldErrorDO field = getField(mbrHicNbr, lstFields);
				EEMApplErrorVO objError = getErrorVO(field, eemApplMasterVO, errorCode, status);
				lstErrors.add(objError);
			}
		} catch (Exception exp) {
			objVO.setMessage("Error Validating Eligibility.");
			throw new ApplicationException(exp);
		}
	}

	/**
	 * @param hicNbr
	 * @param lastName
	 * @param birthDt
	 * @param beqCheck
	 * @param isHicOrMbi
	 * @param MBI
	 * @return
	 * @throws ApplicationException
	 */
	private MBD verifyEligibility(String hicNbr, String lastName, String birthDt, String beqCheck, String isHicOrMbi,
			String mbi) {

		return mbdPersistence.getHicMatch(hicNbr, lastName, birthDt, "Y", isHicOrMbi, mbi);
	}

	private String getMBDGender(String code) {
		if (code != null) {
			if (code.equals("M")) {
				return "1";
			} else if (code.equals("F")) {
				return "2";
			}
		} else {
			code = "";
		}
		return code;
	}

	private EEMApplFieldErrorDO getField(String fieldName, List<EEMApplFieldErrorDO> lstFields) {
		EEMApplFieldErrorDO field = null;
		boolean found = false;
		for (int i = 0; i < lstFields.size(); i++) {
			field = lstFields.get(i);
			if (fieldName.equals(field.getFormField())) {
				found = true;
				break;
			}
		}
		if (!found)
			field = null;
		return field;
	}

	private EEMApplErrorVO checkReqDtCov(EEMApplMasterVO eemApplMasterVO, List<EEMApplFieldErrorDO> lstFields,
			List<EEMApplProductDO> lstProd) {

		String eghpId = "";
		int unLawPrsCnt = 0;
		boolean error = false;
		int incarcerationCnt = 0;
		String errorCode = "AP030";

		EEMApplProductDO eemApplProductDO = null;
		EEMApplErrorVO objError = null;

		String status = EEMConstants.APPL_STATUS_ERRORCRITL;
		EEMApplPlanVO eemApplPlanVO = eemApplMasterVO.getApplPlanVO();
		EEMApplicationVO eemApplicationVO = eemApplMasterVO.getApplVO();
		try {
			EEMApplFieldErrorDO field = this.getField("reqDtCov", lstFields);
			String reqDtCov = trimToEmpty(eemApplPlanVO.getReqDtCov());

			if (reqDtCov.equals("") || field == null || !this.validateEditRule(reqDtCov, field, eemApplMasterVO)) {
				return objError;
			}
			MBD mbd = eemApplMasterVO.getMbd();
			unLawPrsCnt = mbd.getUnLawfulPresCnt();
			incarcerationCnt = mbd.getIncarcerationCnt();

			reqDtCov = DateUtil.changedDateFormatForMonth(reqDtCov);
			String ccmDate = eemProfileSettings.getParmDate(eemApplicationVO.getCustomerId(), EEMConstants.CCM);
			String applDate = DateUtil.changedDateFormatForMonth(trimToEmpty(eemApplicationVO.getApplDate()));
			if (lstProd != null && !lstProd.isEmpty()) {
				eemApplProductDO = lstProd.get(0);
				eghpId = trimToEmpty(eemApplProductDO.getEghpInd());
				if ((eemApplPlanVO.getElectionType().equals("W")) && (!eghpId.isEmpty() && eghpId.equals("Y"))) {
					applDate = DateMath.getFirstOfLastMonth(
							DateUtil.changedDateFormatForMonth(trimToEmpty(eemApplPlanVO.getReqDtCov())));
				}
			} else {
				error = true;
				errorCode = "AP153";
			}
			if (DateMath.isLessThanorEqual(reqDtCov, applDate)) {
				error = true;
				errorCode = "AP203";
			} else if (this.checkRetroApplication(eemApplMasterVO)) {
				error = true;
				errorCode = "AP191";
			} else {
				if (!DateMath.isFDOM(reqDtCov)) {
					error = true;
				} else if (DateMath.monthsBetween(ccmDate, reqDtCov) > 3
						|| DateMath.monthsBetween(ccmDate, reqDtCov) < -3) {
					error = true;
				} else {
					if (!eghpId.isEmpty() && trimToEmpty(eghpId).equals("N")
							&& DateMath.monthsBetween(ccmDate, reqDtCov) < -1)
						error = true;
					else if (!eghpId.isEmpty() && trimToEmpty(eghpId).equals("Y")
							&& DateMath.monthsBetween(ccmDate, reqDtCov) < -3)
						error = true;
				}
			}
			if (unLawPrsCnt > 0) {
				boolean unLawPrsCntFlag = false;
				unLawPrsCntFlag = applicationDAO.isUnlawfullyEligible(reqDtCov, eemApplicationVO.getMbrHicNbr(),
						eemApplicationVO.getMbi());
				if (unLawPrsCntFlag) {
					error = true;
					errorCode = "AP337";
				}
			}
			if (incarcerationCnt > 0) {
				boolean incarcerationCntFlag = false;
				incarcerationCntFlag = applicationDAO.isIncarcerated(reqDtCov, eemApplicationVO.getMbrHicNbr(),
						eemApplicationVO.getMbi());
				if (incarcerationCntFlag) {
					error = true;
					errorCode = "AP338";
				}
			}
			if (error) {
				if (errorCode.equalsIgnoreCase("AP337") || errorCode.equalsIgnoreCase("AP338"))
					status = EEMConstants.APPL_STATUS_ELGWARNING;
				objError = getErrorVO(field, eemApplMasterVO, errorCode, status);
				objError.setErrorData(eemApplPlanVO.getReqDtCov());
			}

		} catch (Exception exp) {
			eemApplicationVO.setMessage("Error during Requested Date of Coverage check.");
			throw new ApplicationException(exp);
		}
		return objError;
	}

	public boolean checkRetroApplication(EEMApplMasterVO eemApplMasterVO) {

		EEMApplPlanVO eemApplPlanVO = eemApplMasterVO.getApplPlanVO();
		EEMApplicationVO eemApplicationVO = eemApplMasterVO.getApplVO();
		try {
			EEMApplPlanDO eemApplPlanDO = new EEMApplPlanDO();
			EEMApplicationDO eemApplicationDO = new EEMApplicationDO();
			EEMApplOtherCovDO eemApplOtherCovDO = new EEMApplOtherCovDO();

			BeanUtils.copyProperties(eemApplMasterVO.getApplVO(), eemApplicationDO);
			BeanUtils.copyProperties(eemApplMasterVO.getApplPlanVO(), eemApplPlanDO);
			BeanUtils.copyProperties(eemApplMasterVO.getApplOtherCovVO(), eemApplOtherCovDO);

			if (applicationDAO.getMemberDetails(eemApplicationDO, eemApplPlanDO, eemApplOtherCovDO, "")) {

				// Bugzilla defect-755 fix -start
				/*
				 * BeanUtils.copyProperties(eemApplicationDO, eemApplMasterVO.getApplVO());
				 * BeanUtils.copyProperties(eemApplPlanDO, eemApplMasterVO.getApplPlanVO());
				 * BeanUtils.copyProperties(eemApplOtherCovDO,
				 * eemApplMasterVO.getApplOtherCovVO());
				 */

				/*
				 * if
				 * (!trimToEmpty(eemApplPlanVO.getEffEndDate()).equals(EEMConstants.EFF_END_DATE
				 * )) { if (eemApplPlanVO.getEnrollPlan() != null &&
				 * eemApplPlanVO.getEnrollPlan().equalsIgnoreCase(eemApplPlanVO.getCurrPlanId())
				 * && eemApplPlanVO.getEnrollPbp() != null &&
				 * eemApplPlanVO.getEnrollPbp().equalsIgnoreCase(eemApplPlanVO.getCurrPbpId()))
				 * return true; }
				 */
				if (!trimToEmpty(eemApplPlanDO.getEffEndDate()).equals(EEMConstants.EFF_END_DATE)) {
					if (eemApplPlanVO.getEnrollPlan() != null
							&& eemApplPlanVO.getEnrollPlan().equalsIgnoreCase(eemApplPlanDO.getCurrPlanId())
							&& eemApplPlanVO.getEnrollPbp() != null
							&& eemApplPlanVO.getEnrollPbp().equalsIgnoreCase(eemApplPlanDO.getCurrPbpId()))
						return true;
				}

				// Bugzilla defect-755 fix -end
			}
		} catch (Exception exp) {
			eemApplicationVO.setMessage("Error during Retro Application check.");
			throw new ApplicationException(exp);
		}
		return false;
	}

	private void checkSupplId(EEMApplMasterVO eemApplMasterVO, List<EEMApplFieldErrorDO> lstFields,
			List<EEMApplErrorVO> lstErrors) {

		EEMApplicationVO eemApplicationVO = eemApplMasterVO.getApplVO();
		EEMApplFieldErrorDO field = getField("altMbrId", lstFields);
		try {
			EEMProfileItemDO eemProfileItemDO = eemProfileSettings.getProfileObject(eemApplicationVO.getCustomerId(),
					EEMConstants.SUPPLID);
			String supplInd = (null == eemProfileItemDO) ? "" : trimToEmpty(eemProfileItemDO.getParmIndValue());
			if (supplInd != null) {
				String supplId = trimToEmpty(eemApplicationVO.getAltMbrId());
				if (supplInd.equals(EEMConstants.SUPPLID_CUST_SUPPLIED) && supplId.isEmpty()) {
					EEMApplErrorVO objError = getErrorVO(field, eemApplMasterVO, "AP146",
							EEMConstants.APPL_STATUS_ERRORCRITL);
					objError.setErrorData(eemApplicationVO.getAltMbrId());
					lstErrors.add(objError);
				}
			}
		} catch (Exception exp) {
			eemApplicationVO.setMessage("Error during Supplemental Id check.");
			throw new ApplicationException(exp);
		}
	}

	private EEMApplErrorVO checkDuplSupplId(EEMApplMasterVO eemApplMasterVO, List<EEMApplFieldErrorDO> lstFields) {

		EEMApplErrorVO objError = null;
		EEMApplicationVO eemApplicationVO = eemApplMasterVO.getApplVO();
		String supplId = trimToEmpty(eemApplicationVO.getAltMbrId());
		String customerId = eemApplicationVO.getCustomerId();
		String mbrId = trimToEmpty(eemApplicationVO.getMbrId());

		EEMApplFieldErrorDO field = getField("altMbrId", lstFields);

		if (supplId.equals("") || field == null || !this.validateEditRule(supplId, field, eemApplMasterVO)) {
			return objError;
		}
		try {
			if (applicationDAO.checkDuplSupplId(customerId, supplId, mbrId)) {
				if (mbrId.isEmpty())
					objError = getErrorVO(field, eemApplMasterVO, "AP202", EEMConstants.APPL_STATUS_ELGWARNING);
				else
					objError = getErrorVO(field, eemApplMasterVO, "AP202", EEMConstants.APPL_STATUS_ERRORCRITL);
				objError.setErrorData(supplId);
			}
		} catch (Exception exp) {
			eemApplicationVO.setMessage("Error during Duplicate Supplemental Id check.");
			throw new ApplicationException(exp);
		}
		return objError;
	}

	private EEMApplErrorVO checkEnrollProduct(EEMApplMasterVO eemApplMasterVO, List<EEMApplFieldErrorDO> lstFields) {

		boolean error = false;
		String errorCode = "";
		EEMApplErrorVO objError = null;

		EEMApplPlanVO eemApplPlanVO = eemApplMasterVO.getApplPlanVO();
		EEMApplicationVO eemApplicationVO = eemApplMasterVO.getApplVO();
		try {
			EEMApplFieldErrorDO field = this.getField("enrollProduct", lstFields);

			if (field == null
					|| !validateEditRule(eemApplMasterVO.getGrpProdVO().getEnrollProdName(), field, eemApplMasterVO)) {
				return objError;
			}
			EEMApplPlanDO eemApplPlanDO = new EEMApplPlanDO();
			EEMApplicationDO eemApplicationDO = new EEMApplicationDO();
			BeanUtils.copyProperties(eemApplicationVO, eemApplicationDO);
			BeanUtils.copyProperties(eemApplPlanVO, eemApplPlanDO);

			eemApplPlanDO.setReqDtCov(eemApplPlanVO.getReqDtCov());
			List<EEMApplProductDO> lstProd = applicationDAO.getProdInGroup(eemApplicationDO, eemApplPlanDO);

			if (lstProd.isEmpty()) {
				error = true;
				errorCode = "AP033";
			} else {
				lstProd = getProductList(eemApplMasterVO);
				if (lstProd == null || lstProd.isEmpty()) {
					error = true;
					errorCode = "AP032";
				} else {
					String enrollPymtAmt = calculateEnrollmentAmt(lstProd.get(0));
					eemApplPlanVO.setEnrollPymtAmt(enrollPymtAmt);
				}
			}
			if (error) {
				objError = getErrorVO(field, eemApplMasterVO, errorCode, EEMConstants.APPL_STATUS_ERRORCRITL);
				objError.setErrorData(eemApplMasterVO.getGrpProdVO().getEnrollProdName());
			}
		} catch (Exception exp) {
			eemApplicationVO.setMessage("Error during Enrolled Product check.");
			throw new ApplicationException(exp);
		}
		return objError;
	}

	private String calculateEnrollmentAmt(EEMApplProductDO eemApplProductDO) {
		double pymtAmt = 0;
		if (!"Y".equals(eemApplProductDO.getSnpInd())) {
			String prtCAmt = eemApplProductDO.getPrtCPremiumAmt();
			String prtDAmt = eemApplProductDO.getPrtDPremiumAmt();
			String supplAmt = eemApplProductDO.getSupplPremiumAmt();
			String premReducAmt = eemApplProductDO.getPremiumReductionAmt();
			String dsrRebateAmt = eemApplProductDO.getDsrRebateAmt();

			pymtAmt = Double.parseDouble(prtCAmt) + Double.parseDouble(prtDAmt) + Double.parseDouble(supplAmt)
					- Double.parseDouble(premReducAmt) - Double.parseDouble(dsrRebateAmt);
		}
		return NumberFormatter.formatDecimal2Places(pymtAmt);
	}

	private void checkRxId(EEMApplMasterVO eemApplMasterVO, List<EEMApplFieldErrorDO> lstFields,
			List<EEMApplErrorVO> lstErrors) {

		String status = "";
		boolean error = false;
		String errorCode = "";

		EEMApplPlanVO eemApplPlanVO = eemApplMasterVO.getApplPlanVO();
		EEMApplicationVO eemApplicationVO = eemApplMasterVO.getApplVO();
		try {
			EEMApplFieldErrorDO field = getField("mbrRxId", lstFields);
			if (field != null) {
				String planDesgn = trimToEmpty(eemApplMasterVO.getGrpProdVO().getPlanDesignation());
				if (planDesgn.equals("MA") && !trimToEmpty(eemApplicationVO.getMbrRxId()).isEmpty()) {
					error = true;
					errorCode = "AP184";
				} else {
					if (validateRxId(eemApplMasterVO)) {
						String reqDtCov = DateUtil.changedDateFormatForMonth(trimToEmpty(eemApplPlanVO.getReqDtCov()));
						if (!reqDtCov.isEmpty()) {
							EEMProfileItemDO eemProfileItemDO = eemProfileSettings
									.getProfileObject(eemApplicationVO.getCustomerId(), EEMConstants.RXID);
							String rxIdInd = (null == eemProfileItemDO) ? ""
									: trimToEmpty(eemProfileItemDO.getParmIndValue());
							EEMProfileItemDO eemProfileItemSupplDO = eemProfileSettings
									.getProfileObject(eemApplicationVO.getCustomerId(), EEMConstants.SUPPLID);
							String supplIdInd = (null == eemProfileItemSupplDO) ? ""
									: trimToEmpty(eemProfileItemSupplDO.getParmIndValue());
							String rxId = trimToEmpty(eemApplicationVO.getMbrRxId());
							String supplId = trimToEmpty(eemApplicationVO.getAltMbrId());

							if (rxIdInd.equals(EEMConstants.RXID_CUST_SUPPLIED)) {
								if (rxId.isEmpty()) {
									error = true;
									errorCode = "AP034";
									status = EEMConstants.APPL_STATUS_ERRORCRITL;
								}
							} else if (rxIdInd.equals(EEMConstants.RXID_DERIVED) && !rxId.isEmpty()) {
								error = true;
								errorCode = "AP036";
							} else if (rxIdInd.equals(EEMConstants.RXID_USE_SUPPLID)
									&& !supplIdInd.equals(EEMConstants.SUPPLID_GENERATED)) {
								if (!rxId.isEmpty() && supplId.isEmpty()) {
									error = true;
									errorCode = "AP036";
								}
								if (!supplId.isEmpty()) {
									eemApplicationVO.setMbrRxId(supplId);
								}
							}
						}
					}
				}
				if (error) {
					EEMApplErrorVO objError = getErrorVO(field, eemApplMasterVO, errorCode, status);
					objError.setErrorData(eemApplicationVO.getMbrRxId());
					lstErrors.add(objError);
				}
			}
		} catch (Exception exp) {
			eemApplicationVO.setMessage("Error during RxID check.");
			throw new ApplicationException(exp);
		}
	}

	private void checkElectionType(EEMApplMasterVO eemApplMasterVO, List<EEMApplFieldErrorDO> lstFields,
			List<EEMApplErrorVO> lstErrors) {

		String status = "";
		String errorCode = "";
		String errorValue = "";
		EEMApplPlanVO eemApplPlanVO = null;
		EEMApplicationVO eemApplicationVO = null;
		EEMApplEligibilityVO eemApplEligibilityVO = null;
		EEMApplOtherCovVO eemApplOtherCovVO = null;
		EEMApplProductVO eemApplProductVO = null;
		try {
			EEMApplFieldErrorDO field = getField("electionType", lstFields);
			if (field != null) {
				MBD mbd = eemApplMasterVO.getMbd();
				eemApplicationVO = eemApplMasterVO.getApplVO();
				eemApplPlanVO = eemApplMasterVO.getApplPlanVO();
				eemApplEligibilityVO = eemApplMasterVO.getApplEligiVO();
				eemApplOtherCovVO = eemApplMasterVO.getApplOtherCovVO();
				eemApplProductVO = eemApplMasterVO.getGrpProdVO();

				EEMElectionVO electionVO = new EEMElectionVO();
				electionVO.setCustomerId(trimToEmpty(eemApplicationVO.getCustomerId()));
				electionVO.setElectionType(trimToEmpty(eemApplPlanVO.getElectionType()));
				electionVO.setPlanDesgn(trimToEmpty(eemApplProductVO.getPlanDesignation()));
				electionVO.setBirthDt(DateFormatter.reFormat(eemApplicationVO.getMbrBirthDt(), DateFormatter.MM_DD_YYYY,
						DateFormatter.YYYYMMDD));
				electionVO.setApplicationDt(DateFormatter.reFormat(eemApplicationVO.getApplDate(),
						DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
				electionVO.setReqDtCov(DateFormatter.reFormat(eemApplPlanVO.getReqDtCov(), DateFormatter.MM_DD_YYYY,
						DateFormatter.YYYYMMDD));
				electionVO.setLongTermFacId(trimToEmpty(eemApplOtherCovVO.getNameInstitute()));
				electionVO.setPartAEntlDt(
						DateUtil.changedDateFormatForMonth(trimToEmpty(eemApplEligibilityVO.getPartAEffDate())));
				electionVO.setPartBEntlDt(
						DateUtil.changedDateFormatForMonth(trimToEmpty(eemApplEligibilityVO.getPartBEffDate())));
				electionVO.setPartDElgDt(
						DateUtil.changedDateFormatForMonth(trimToEmpty(eemApplEligibilityVO.getPartDEffDate())));
				electionVO.setElcDerivedInd(eemApplPlanVO.getElcDerivedInd());
				electionVO.setApplType(trimToEmpty(eemApplicationVO.getApplType()));
				electionVO.setMemberId(eemApplicationVO.getMbrId());
				electionVO.setMemberPresentInM360(
						(null == electionVO.getMemberId() || electionVO.getMemberId().trim().isEmpty()) ? false : true);
				electionVO.setStrApplicationDate(eemApplicationVO.getApplDate());
				electionVO.setDayBeforeRequestedDateOfCoverage(
						this.getApplicationEffectiveDateMinusOne(eemApplPlanVO.getReqDtCov()));
				String planID = trimToEmpty(mbd.getPlanId());
				if (planID.isEmpty()) {
					electionVO.setPlanBlank(true);
				} else if (planID.toUpperCase().startsWith("S")) {
					electionVO.setPlanPDP(true);
				}
				electionVO.setLastUsedSepDate(mbd.getLastUsedSepDate());
				String derivedType = eemElection.validateElectionType(electionVO);
				eemApplPlanVO.setElcDerivedInd(electionVO.getElcDerivedInd());
				eemApplPlanVO.setElectionType(electionVO.getElectionType());
				electionVO.setApplType(trimToEmpty(eemApplicationVO.getApplType()));

				if (!trimToEmpty(derivedType).isEmpty()) {
					if (!(StringUtils.equals(eemApplPlanVO.getElectionType(), "J")
							&& (StringUtils.equals(derivedType, "I") || StringUtils.equals(derivedType, "E")))) {
						errorCode = "AP189";
						status = "";
						errorValue = derivedType;
					} else if (StringUtils.equals(eemApplPlanVO.getElectionType(), "J")
							&& !StringUtils.equals(eemApplicationVO.getEnrollSrceCd(), "B")) {
						errorCode = "AP233";
						status = EEMConstants.APPL_STATUS_ERRORCRITL;
						errorValue = eemApplicationVO.getEnrollSrceCd();
					} else if (eemApplPlanVO.getElectionType().equals("M")
							&& (derivedType.equals("I") || derivedType.equals("F") || derivedType.equals("E"))) {
						errorCode = electionVO.getErrorCode();
						status = EEMConstants.APPL_STATUS_ERRORCRITL;
						errorValue = eemApplPlanVO.getElectionType();
					} else if (eemApplPlanVO.getElectionType().equals("I")
							&& (derivedType.equals("F") || derivedType.equals("E"))) {
						errorCode = electionVO.getErrorCode();
						status = EEMConstants.APPL_STATUS_ERRORCRITL;
						errorValue = eemApplPlanVO.getElectionType();
					}
				} else {
					errorCode = electionVO.getErrorCode();
					status = EEMConstants.APPL_STATUS_ELGWARNING;
					errorValue = eemApplPlanVO.getElectionType();
				}
				String electionErrorCode = "AP052";
				if (electionVO.getElectionType().equals(EEMConstants.ELECTION_TYPE_SEP_LIS)
						&& (electionVO.getErrorCode().equals("AP351") || electionVO.getErrorCode().equals("AP352")
								|| electionVO.getErrorCode().equals(electionErrorCode)
								|| electionVO.getErrorCode().equals("AP355"))) {
					errorCode = electionVO.getErrorCode();
					status = EEMConstants.APPL_STATUS_ERRORCRITL;
					errorValue = eemApplPlanVO.getElectionType();
				}
				if (errorCode != null && !errorCode.equalsIgnoreCase("")) {
					if (errorCode.equalsIgnoreCase(electionErrorCode) || errorCode.equalsIgnoreCase("AP087")
							|| errorCode.equalsIgnoreCase("AP165") || errorCode.equalsIgnoreCase("AP353")
							|| errorCode.equalsIgnoreCase("AP354")) {
						status = EEMConstants.APPL_STATUS_INCRFIELCT;
					} else if (errorCode.equalsIgnoreCase("AP192") || errorCode.equalsIgnoreCase(electionErrorCode)) {
						status = EEMConstants.APPL_STATUS_ERRORCRITL;
					}
				}
				if (!trimToEmpty(errorCode).isEmpty()) {
					EEMApplErrorVO objError = getErrorVO(field, eemApplMasterVO, errorCode, status);
					objError.setErrorData(errorValue);
					lstErrors.add(objError);
				}
			}
		} catch (Exception exp) {
			eemApplicationVO.setMessage("Error during Election Type check.");
		}
	}

	private String getApplicationEffectiveDateMinusOne(String effectiveDate) {
		String oneDayBeforeApplicationEffectiveDate = null;
		String effectiveDateInMMDDYYYYFormat = effectiveDate.replaceAll("/", "");

		int effectiveDateInMMDDYYYYFormatYear = Integer.parseInt(effectiveDateInMMDDYYYYFormat.substring(4, 8));
		int effectiveDateInMMDDYYYYFormatMonth = Integer.parseInt(effectiveDateInMMDDYYYYFormat.substring(0, 2)) - 1;
		int effectiveDateInMMDDYYYYFormatDay = Integer.parseInt(effectiveDateInMMDDYYYYFormat.substring(2, 4));

		java.util.Calendar effectiveDateCalender = new java.util.GregorianCalendar(effectiveDateInMMDDYYYYFormatYear,
				effectiveDateInMMDDYYYYFormatMonth, effectiveDateInMMDDYYYYFormatDay);

		java.util.Calendar oneDayMinusOfEffectiveDateCalender = new java.util.GregorianCalendar(
				effectiveDateCalender.get(java.util.Calendar.YEAR), effectiveDateCalender.get(java.util.Calendar.MONTH),
				effectiveDateCalender.get(java.util.Calendar.DATE) - 1);

		int oneDayMinusOfEffectiveDateCalenderMonth = oneDayMinusOfEffectiveDateCalender.get(java.util.Calendar.MONTH);
		oneDayMinusOfEffectiveDateCalenderMonth = oneDayMinusOfEffectiveDateCalenderMonth + 1;
		return oneDayBeforeApplicationEffectiveDate;
	}

	public void checkApplDate(EEMApplMasterVO eemApplMasterVO, List<EEMApplFieldErrorDO> lstFields,
			List<EEMApplErrorVO> lstErrors) {

		EEMApplicationVO eemApplicationVO = eemApplMasterVO.getApplVO();
		EEMApplFieldErrorDO field = getField("applDate", lstFields);
		if (field != null && !validateEditRule(eemApplicationVO.getApplDate(), field, eemApplMasterVO)) {
			EEMApplErrorVO objError = getErrorVO(field, eemApplMasterVO, field.getErrorCd(),
					EEMConstants.APPL_STATUS_ERRORCRITL);
			objError.setErrorData(eemApplicationVO.getApplDate());
			lstErrors.add(objError);
		}
	}

	public void checkEsrdInd(EEMApplMasterVO eemApplMasterVO, List<EEMApplFieldErrorDO> lstFields, boolean validProduct,
			List<EEMApplErrorVO> lstErrors) {

		String status = "";
		String errorCode = "";
		EEMApplicationVO eemApplicationVO = eemApplMasterVO.getApplVO();
		EEMApplOtherCovVO eemApplOtherCovVO = eemApplMasterVO.getApplOtherCovVO();
		EEMApplFieldErrorDO field = getField("esrd", lstFields);
		try {
			if (field != null) {
				String errorValue = trimToEmpty(eemApplOtherCovVO.getEsrd());
				MBD mbd = eemApplMasterVO.getMbd();

				if (!validProduct) {
					status = EEMConstants.APPL_STATUS_ERRORCRITL;
					errorCode = "AP154";
				} else if (mbd != null) {
					EEMProfileItemDO eemProfileItemDO = eemProfileSettings
							.getProfileObject(eemApplicationVO.getCustomerId(), EEMConstants.ELGESRD);
					String esrdInd = (null == eemProfileItemDO) ? "" : trimToEmpty(eemProfileItemDO.getParmIndValue());
					if (!trimToEmpty(esrdInd).isEmpty()) {
						if (esrdInd.equals("D")) {
							if (trimToEmpty(eemApplOtherCovVO.getEsrd()).equals("Y")
									&& trimToEmpty(mbd.getEsrdInd()).equals("N"))
								eemApplOtherCovVO.setEsrd(mbd.getEsrdInd());

						} else if (esrdInd.equals("U")) {
							if (trimToEmpty(eemApplOtherCovVO.getEsrd()).equals("N")
									&& trimToEmpty(mbd.getEsrdInd()).equals("Y"))
								eemApplOtherCovVO.setEsrd(mbd.getEsrdInd());

						} else if (esrdInd.equals("Y")) {
							if (!trimToEmpty(eemApplOtherCovVO.getEsrd()).equals(trimToEmpty(mbd.getEsrdInd())))
								eemApplOtherCovVO.setEsrd(mbd.getEsrdInd());
							if (trimToEmpty(mbd.getEsrdInd()).isEmpty())
								eemApplOtherCovVO.setEsrd("N");
						}
					}
				}
				if (!trimToEmpty(errorCode).isEmpty()) {
					EEMApplErrorVO objError = getErrorVO(field, eemApplMasterVO, errorCode, status);
					objError.setErrorData(errorValue);
					lstErrors.add(objError);
				}
			}
		} catch (Exception exp) {
			eemApplicationVO.setMessage("Error during ESRD Ind check.");
			throw new ApplicationException(exp);
		}
	}

	public void checkEsrdOverrideInd(EEMApplMasterVO eemApplMasterVO, List<EEMApplFieldErrorDO> lstFields,
			List<EEMApplErrorVO> lstErrors) {

		String status = "";
		String errorCode = "";
		EEMApplicationVO eemApplicationVO = eemApplMasterVO.getApplVO();
		EEMApplOtherCovVO eemApplOtherCovVO = eemApplMasterVO.getApplOtherCovVO();
		try {
			EEMApplFieldErrorDO field = getField("pcoInd", lstFields);
			if (field != null) {
				MBD mbd = eemApplMasterVO.getMbd();
				if (mbd != null) {
					String esrdInd = trimToEmpty(eemApplOtherCovVO.getEsrd());
					String esrdOvrInd = trimToEmpty(eemApplOtherCovVO.getPcoInd());
					if (esrdOvrInd.isEmpty()) {
						esrdOvrInd = "N";
						eemApplOtherCovVO.setPcoInd("N");
					}
					String mbdEsrdInd = trimToEmpty(mbd.getEsrdInd());

					if (esrdInd.equals("Y") && esrdOvrInd.equals("N") && mbdEsrdInd.equals("Y")) {
						status = EEMConstants.APPL_STATUS_ELGCRITICL;
						errorCode = "AP066";
					} else if (esrdInd.equals("Y") && esrdOvrInd.equals("Y") && mbdEsrdInd.equals("N")) {
						status = EEMConstants.APPL_STATUS_ELGWARNING;
						errorCode = "AP065";
					} else if (esrdInd.equals("Y") && esrdOvrInd.equals("N") && mbdEsrdInd.equals("N")) {
						status = EEMConstants.APPL_STATUS_ELGWARNING;
						errorCode = "AP065";
					} else if (esrdInd.equals("N") && esrdOvrInd.equals("Y") && mbdEsrdInd.equals("N")) {
						status = EEMConstants.APPL_STATUS_ERROR;
						errorCode = "AP066";
					} else if (esrdInd.equals("N") && esrdOvrInd.equals("Y") && mbdEsrdInd.equals("Y")) {
						status = EEMConstants.APPL_STATUS_ELGCRITICL;
						errorCode = "AP066";
					} else if (esrdInd.equals("N") && esrdOvrInd.equals("N") && mbdEsrdInd.equals("Y")) {
						status = EEMConstants.APPL_STATUS_ELGCRITICL;
						errorCode = "AP066";
					} else if (esrdInd.isEmpty() && (esrdOvrInd.equals("N") || esrdOvrInd.isEmpty())
							&& mbdEsrdInd.equals("Y")) {
						status = EEMConstants.APPL_STATUS_ELGCRITICL;
						errorCode = "AP066";
					}
				}
				if (!trimToEmpty(errorCode).isEmpty()) {
					EEMApplErrorVO objError = getErrorVO(field, eemApplMasterVO, errorCode, status);
					objError.setErrorData(trimToEmpty(eemApplOtherCovVO.getPcoInd()));
					lstErrors.add(objError);
				}
			}
		} catch (Exception exp) {
			eemApplicationVO.setMessage("Error during ESRD Override Ind check.");
			throw new ApplicationException(exp);
		}
	}

	public void checkElcReasonCd(EEMApplMasterVO eemApplMasterVO, List<EEMApplFieldErrorDO> lstFields,
			List<EEMApplErrorVO> lstErrors) {

		String status = "";
		String errorCode = "";
		EEMApplPlanVO eemApplPlanVO = eemApplMasterVO.getApplPlanVO();
		EEMApplicationVO eemApplicationVO = eemApplMasterVO.getApplVO();
		try {
			EEMApplFieldErrorDO field = getField("sepReason", lstFields);
			if (field != null) {
				if (EEMConstants.ELECTION_TYPE_SEP_ELP.equals(trimToEmpty(eemApplPlanVO.getElectionType()))
						&& trimToEmpty(eemApplPlanVO.getSepReason()).isEmpty()) {
					errorCode = "AP165";
					status = EEMConstants.APPL_STATUS_INCRFIELCT;
				}
				if (!trimToEmpty(errorCode).isEmpty()) {
					EEMApplErrorVO objError = getErrorVO(field, eemApplMasterVO, errorCode, status);
					objError.setErrorData(trimToEmpty(eemApplPlanVO.getSepReason()));
					lstErrors.add(objError);
				}
			}
		} catch (Exception exp) {
			eemApplicationVO.setMessage("Error during Election Reason check.");
			throw new ApplicationException(exp);
		}
	}

	public void checkLTCFacility(EEMApplMasterVO eemApplMasterVO, List<EEMApplFieldErrorDO> lstFields,
			List<EEMApplErrorVO> lstErrors) {

		String status = "";
		String errorCode = "";
		EEMApplPlanVO eemApplPlanVO = eemApplMasterVO.getApplPlanVO();
		EEMApplicationVO eemApplicationVO = eemApplMasterVO.getApplVO();
		EEMApplOtherCovVO eemApplOtherCovVO = eemApplMasterVO.getApplOtherCovVO();
		try {
			EEMApplFieldErrorDO field = getField("nameInstitute", lstFields);
			if (field != null) {
				if (EEMConstants.ELECTION_TYPE_OEPI.equals(trimToEmpty(eemApplPlanVO.getElectionType()))
						&& trimToEmpty(eemApplOtherCovVO.getNameInstitute()).isEmpty()) {
					errorCode = "AP046";
					status = EEMConstants.APPL_STATUS_ERROR;
				}
				if (!trimToEmpty(errorCode).isEmpty()) {
					EEMApplErrorVO objError = getErrorVO(field, eemApplMasterVO, errorCode, status);
					objError.setErrorData(trimToEmpty(eemApplOtherCovVO.getNameInstitute()));
					lstErrors.add(objError);
				}
			}
		} catch (Exception exp) {
			eemApplicationVO.setMessage("Error during LTC Facility check.");
			throw new ApplicationException(exp);
		}
	}

	public void checkMedicaidId(EEMApplMasterVO eemApplMasterVO, List<EEMApplFieldErrorDO> lstFields,
			List<EEMApplErrorVO> lstErrors) {

		String status = "";
		String errorCode = "";
		String errorValue = "";
		EEMApplicationVO eemApplicationVO = eemApplMasterVO.getApplVO();
		EEMApplOtherCovVO eemApplOtherCovVO = eemApplMasterVO.getApplOtherCovVO();
		try {
			EEMApplFieldErrorDO field = getField("medicaidId", lstFields);
			if (field != null) {
				if (trimToEmpty(eemApplOtherCovVO.getStMedicaid()).equals("Y")
						&& trimToEmpty(eemApplOtherCovVO.getMedicaidId()).isEmpty()) {
					errorCode = "AP197";
					errorValue = eemApplOtherCovVO.getMedicaidId();
					status = EEMConstants.APPL_STATUS_ERROR;
				}
				if (!trimToEmpty(errorCode).isEmpty()) {
					EEMApplErrorVO objError = getErrorVO(field, eemApplMasterVO, errorCode, status);
					objError.setErrorData(errorValue);
					lstErrors.add(objError);
				}
			}
		} catch (Exception exp) {
			eemApplicationVO.setMessage("Error during Medicaid ID check.");
			throw new ApplicationException(exp);
		}
	}

	public List<EEMApplErrorVO> checkProviderDates(EEMApplMasterVO eemApplMasterVO,
			List<EEMApplFieldErrorDO> lstFields) {

		Boolean flag = false;
		String errorCode = "";
		EEMApplErrorVO objError = null;
		String acceptNewPatient = null;
		EEMApplPlanVO eemApplPlanVO = eemApplMasterVO.getApplPlanVO();
		EEMApplicationVO eemApplicationVO = eemApplMasterVO.getApplVO();
		List<EEMApplErrorVO> lstPcpErrors = new ArrayList<>();
		EEMApplOtherPlanVO eemApplOtherPlanVO = eemApplMasterVO.getApplOtherPlanVO();
		try {
			EEMApplFieldErrorDO field = getField("pcpName", lstFields);

			if (eemApplOtherPlanVO.getOfficeCd() != null && !eemApplOtherPlanVO.getOfficeCd().equalsIgnoreCase("")) {
				if (eemApplPlanVO.getReqDtCov() != null && !eemApplPlanVO.getReqDtCov().isEmpty()) {

					acceptNewPatient = applicationDAO.validateEnrolledPcp(eemApplicationVO.getCustomerId(),
							eemApplPlanVO.getReqDtCov(), eemApplOtherPlanVO.getOfficeCd(),
							eemApplOtherPlanVO.getLocationId()

					);
					if (!acceptNewPatient.isEmpty()) {
						flag = true;
					}
				}
				if (!flag) {
					errorCode = "AP218";
					String status = EEMConstants.APPL_STATUS_READYAPPR;
					objError = getErrorVO(field, eemApplMasterVO, errorCode, status);
					objError.setErrorData(eemApplOtherPlanVO.getOfficeCd());
					lstPcpErrors.add(objError);
				}
				if (!flag) {
					errorCode = "AP215";
					String status = EEMConstants.APPL_STATUS_READYAPPR;
					objError = getErrorVO(field, eemApplMasterVO, errorCode, status);
					objError.setErrorData(eemApplOtherPlanVO.getOfficeCd());
					lstPcpErrors.add(objError);
				}
				if (trimToEmpty(acceptNewPatient).equalsIgnoreCase("N")
						&& !trimToEmpty(eemApplOtherPlanVO.getCurrentPatientInd()).equalsIgnoreCase("Y")) {
					errorCode = "AP187";
					String status = EEMConstants.APPL_STATUS_READYAPPR;
					objError = getErrorVO(field, eemApplMasterVO, errorCode, status);
					objError.setErrorData(eemApplOtherPlanVO.getOfficeCd());
					lstPcpErrors.add(objError);
				}
			}
		} catch (Exception exp) {
			eemApplicationVO.setMessage("Error during Enrolled PCP check");
			throw new ApplicationException(exp);
		}
		return lstPcpErrors;
	}

	public List<EEMApplErrorVO> validateAgent(EEMApplMasterVO eemApplMasterVO, List<EEMApplFieldErrorDO> lstFields) {

		String errorCode = "";
		EEMApplicationVO eemApplicationVO = eemApplMasterVO.getApplVO();
		EEMApplAgentVO eemApplAgentVO = eemApplMasterVO.getApplAgentVO();
		EEMApplPlanVO eemApplPlanVO = eemApplMasterVO.getApplPlanVO();
		List<EEMApplErrorVO> agentErrors = new ArrayList<>();
		EEMApplFieldErrorDO field = getField(brokerType, lstFields);

		if (!trimToEmpty(eemApplAgentVO.getBrokAgentId()).isEmpty() && null != field) {
			EEMApplPlanDO eemApplPlanDO = new EEMApplPlanDO();
			EEMApplAgentDO eemApplAgentDO = new EEMApplAgentDO();
			EEMApplicationDO eemApplicationDO = new EEMApplicationDO();

			BeanUtils.copyProperties(eemApplicationVO, eemApplicationDO);
			BeanUtils.copyProperties(eemApplPlanVO, eemApplPlanDO);
			BeanUtils.copyProperties(eemApplAgentVO, eemApplAgentDO);

			int checkAgent = applicationDAO.checkInvalidAgent(eemApplicationDO, eemApplPlanDO, eemApplAgentDO);
			if (checkAgent == 0) {
				errorCode = "AP221";
				String status = EEMConstants.APPL_STATUS_READYAPPR;
				EEMApplErrorVO objError = getErrorVO(field, eemApplMasterVO, errorCode, status);
				objError.setErrorData(eemApplAgentVO.getBrokerType());
				agentErrors.add(objError);
			}
		}
		return agentErrors;
	}

	private void checkActiveAgent(EEMApplMasterVO eemApplMasterVO, List<EEMApplFieldErrorDO> lstFields,
			List<EEMApplErrorVO> lstErrors) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String reqDtCov = eemApplMasterVO.getApplPlanVO().getReqDtCov();
		boolean error = false;
		String errorCode = "";
		EEMApplAgentVO eemApplAgentVO = eemApplMasterVO.getApplAgentVO();
		EEMApplFieldErrorDO field = getField(brokerType, lstFields);

		if (field != null) {
			if (!trimToEmpty(eemApplAgentVO.getBrokerType()).isEmpty()
					&& !trimToEmpty(eemApplAgentVO.getCommAgencyId()).isEmpty()) {

				EEMApplAgentDO eemApplAgentDO = new EEMApplAgentDO();
				BeanUtils.copyProperties(eemApplAgentVO, eemApplAgentDO);

				boolean activeAgent = applicationDAO.checkAgent(customerId, reqDtCov, eemApplAgentDO);
				if (!activeAgent) {
					error = true;
					errorCode = "AP224";
				}
			}
			if (error) {
				String status = EEMConstants.APPL_STATUS_READYAPPR;
				EEMApplErrorVO objError = getErrorVO(field, eemApplMasterVO, errorCode, status);
				objError.setErrorData(eemApplAgentVO.getBrokerType());
				lstErrors.add(objError);
			}
		}
	}

	private void checkInvalidAgency(EEMApplMasterVO eemApplMasterVO, List<EEMApplFieldErrorDO> lstFields,
			List<EEMApplErrorVO> lstErrors) {

		boolean error = false;
		String errorCode = "";

		EEMApplPlanVO eemApplPlanVO = eemApplMasterVO.getApplPlanVO();
		EEMApplicationVO eemApplicationVO = eemApplMasterVO.getApplVO();
		EEMApplAgentVO eemApplAgentVO = eemApplMasterVO.getApplAgentVO();

		EEMApplFieldErrorDO field = getField(brokerType, lstFields);
		if (field != null) {
			if (!trimToEmpty(eemApplAgentVO.getCommAgencyId()).isEmpty()) {

				EEMApplPlanDO eemApplPlanDO = new EEMApplPlanDO();
				EEMApplAgentDO eemApplAgentDO = new EEMApplAgentDO();
				EEMApplicationDO eemApplicationDO = new EEMApplicationDO();

				BeanUtils.copyProperties(eemApplicationVO, eemApplicationDO);
				BeanUtils.copyProperties(eemApplPlanVO, eemApplPlanDO);
				BeanUtils.copyProperties(eemApplAgentVO, eemApplAgentDO);

				int count = applicationDAO.checkInvalidAgency(eemApplicationDO, eemApplPlanDO, eemApplAgentDO);
				if (count == 0) {
					error = true;
					errorCode = "AP222";
				}
			}
			if (error) {
				String status = EEMConstants.APPL_STATUS_READYAPPR;
				EEMApplErrorVO objError = getErrorVO(field, eemApplMasterVO, errorCode, status);
				objError.setErrorData(eemApplAgentVO.getCommAgencyId());
				lstErrors.add(objError);
			}
		}
	}

	private void checkDuplicateApplication(EEMApplMasterVO eemApplMasterVO, List<EEMApplFieldErrorDO> lstFields,
			List<EEMApplErrorVO> lstErrors) {

		String custNbr = sessionHelper.getUserInfo().getCustNbr();

		EEMApplicationVO eemApplicationVO = eemApplMasterVO.getApplVO();
		try {
			EEMApplicationDO eemApplicationDO = new EEMApplicationDO();
			BeanUtils.copyProperties(eemApplicationVO, eemApplicationDO);

			List<String[]> lstOrgPlan = applicationDAO.checkDuplicateApplication(eemApplicationDO, custNbr);

			if (!lstOrgPlan.isEmpty() && checkDuplicate(eemApplMasterVO, lstOrgPlan)) {
				EEMApplFieldErrorDO field = getField(mbrHicNbr, lstFields);
				EEMApplErrorVO objError = getErrorVO(field, eemApplMasterVO, "AP057",
						EEMConstants.APPL_STATUS_DUPLAPPL);
				lstErrors.add(objError);
			}
		} catch (Exception exp) {
			eemApplicationVO.setMessage("Error during Duplicate Application check.");
			throw new ApplicationException(exp);
		}
	}

	public boolean checkDuplicate(EEMApplMasterVO eemApplMasterVO, List<String[]> lstOrgPlan) {

		boolean error = true;
		EEMApplPlanVO eemApplPlanVO = eemApplMasterVO.getApplPlanVO();
		EEMApplicationVO eemApplicationVO = eemApplMasterVO.getApplVO();
		String[] arrPlanDetails = eemApplPlanVO.getArrPlanDetails();
		if (arrPlanDetails != null) {
			String currPlanDesgn = arrPlanDetails[1];
			String currPlanType = arrPlanDetails[0];

			if (lstOrgPlan.isEmpty()) {
				error = false;
			}
			for (int i = 0; i < lstOrgPlan.size(); i++) {
				String[] orgPlan = lstOrgPlan.get(i);
				if (orgPlan != null) {
					String orgPlanDesgn = trimToEmpty(orgPlan[1]);
					String orgPlanType = trimToEmpty(orgPlan[0]);

					if (orgPlanDesgn.equals(EEMConstants.PLAN_DESGN_PDP)) {
						if (currPlanDesgn.equals(EEMConstants.PLAN_DESGN_MA)
								&& currPlanType.equals(EEMConstants.PLAN_TYPE_PFFS)) {
							error = false;
						}
					} else if (orgPlanDesgn.equals(EEMConstants.PLAN_DESGN_MA)
							&& orgPlanType.equals(EEMConstants.PLAN_TYPE_PFFS)) {
						if (currPlanDesgn.equals(EEMConstants.PLAN_DESGN_PDP)) {
							error = false;
						}
					} else if (orgPlanDesgn.equals(EEMConstants.PLAN_TYPE_COST)
							&& currPlanDesgn.equals(EEMConstants.PLAN_DESGN_PDP)) {
						error = false;
					}
				}
			}
			if ((!trimToEmpty(eemApplPlanVO.getCurrPlanId()).isEmpty()
					&& !trimToEmpty(eemApplPlanVO.getCurrPbpId()).isEmpty())
					&& (!trimToEmpty(eemApplPlanVO.getCurrPlanId()).equals(eemApplPlanVO.getEnrollPlan())
							|| !trimToEmpty(eemApplPlanVO.getCurrPbpId()).equals(eemApplPlanVO.getEnrollPbp()))) {
				error = false;
			}
			if ((error && (eemApplicationVO.getApplType().equals(EEMConstants.OPTION_CNTRCHG_PD)))
					&& (!eemApplPlanVO.getCurrPlanId().equals(eemApplPlanVO.getEnrollPlan())
							|| !eemApplPlanVO.getCurrPbpId().equals(eemApplPlanVO.getEnrollPbp()))) {
				error = false;
			}
		}
		return error;
	}

	private void checkDuplicateEnrollment(EEMApplMasterVO eemApplMasterVO, List<EEMApplFieldErrorDO> lstFields,
			List<EEMApplErrorVO> lstErrors, String applType, String appDuplicateCheck) {

		boolean error = false;
		String errorCode = "";
		EEMApplicationVO eemApplicationVO = eemApplMasterVO.getApplVO();
		EEMApplPlanVO eemApplPlanVO = eemApplMasterVO.getApplPlanVO();
		try {
			EEMApplicationDO eemApplicationDO = new EEMApplicationDO();
			BeanUtils.copyProperties(eemApplicationVO, eemApplicationDO);

			List<String[]> lstOrgPlan = applicationDAO.checkDuplicateEnrollment(eemApplicationDO);

			if (!lstOrgPlan.isEmpty()) {
				String[] orgPlan = lstOrgPlan.get(0);
				if (null != orgPlan && orgPlan.length > 4) {
					String planId = orgPlan[3];
					String pbpId = orgPlan[4];
					String productId = orgPlan[5];
					String grpId = orgPlan[6];
					String pbpSegmentId = orgPlan[7];
					if (planId.equalsIgnoreCase(eemApplPlanVO.getEnrollPlan())
							&& pbpId.equalsIgnoreCase(eemApplPlanVO.getEnrollPbp())
							&& productId.equalsIgnoreCase(eemApplPlanVO.getEnrollProduct())
							&& grpId.equalsIgnoreCase(eemApplPlanVO.getEnrollGrpId())
							&& pbpSegmentId.equalsIgnoreCase(eemApplPlanVO.getEnrollSegment())) {
						errorCode = "AP061";
						error = this.checkDuplicate(eemApplMasterVO, lstOrgPlan);
					}

					if (!("CMA".equalsIgnoreCase(applType) && "Y".equalsIgnoreCase(appDuplicateCheck))) {
						String reqDtCov = DateFormatter.reFormat(eemApplPlanVO.getReqDtCov(), DateFormatter.MM_DD_YYYY,
								DateFormatter.YYYYMMDD);
						String startDate = orgPlan[2];
						if (error && DateMath.isLessThan(reqDtCov, startDate)) {
							errorCode = "AP193";
						}
					}
				}
			}
			if (error) {
				EEMApplFieldErrorDO field = getField(mbrHicNbr, lstFields);
				EEMApplErrorVO objError = getErrorVO(field, eemApplMasterVO, errorCode,
						EEMConstants.APPL_STATUS_DUPLENRL);
				lstErrors.add(objError);
			}
		} catch (Exception exp) {
			eemApplicationVO.setMessage("Error during Duplicate Enrollment check.");
		}
	}

	private void checkRetroAppl(EEMApplMasterVO eemApplMasterVO, List<EEMApplFieldErrorDO> lstFields,
			List<EEMApplErrorVO> lstErrors) {

		EEMApplicationVO eemApplicationVO = eemApplMasterVO.getApplVO();
		EEMApplPlanVO eemApplPlanVO = eemApplMasterVO.getApplPlanVO();
		try {
			if (this.checkRetroApplication(eemApplMasterVO)) {
				EEMApplFieldErrorDO field = getField("reqDtCov", lstFields);
				EEMApplErrorVO objError = getErrorVO(field, eemApplMasterVO, "AP191",
						EEMConstants.APPL_STATUS_RETROENRLR);
				objError.setErrorData(eemApplPlanVO.getReqDtCov());
				lstErrors.add(objError);
			}
		} catch (Exception exp) {
			eemApplicationVO.setMessage("Error during Duplicate Application check.");
			throw new ApplicationException(exp);
		}
	}

}
