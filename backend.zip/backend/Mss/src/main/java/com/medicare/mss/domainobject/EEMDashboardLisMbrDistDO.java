package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMDashboardLisMbrDistDO {
	@ColumnMapper(columnName = "PLAN_ID", propertyName = "planId")
	private String planId;
	/*@ColumnMapper(columnName = "PBP_ID", propertyName = "pbpId")
	private String pbpId;*/
	@ColumnMapper(columnName = "LOW_INCOME", propertyName = "lowIncomeCount")
	private String lowIncomeCount;
	@ColumnMapper(columnName = "HIGH", propertyName = "highIncomeCount")
	private String highIncomeCount;
	@ColumnMapper(columnName = "LOW", propertyName = "lowCount")
	private String lowCount;
	@ColumnMapper(columnName = "ZERO", propertyName = "zeroCount")
	private String zeroCount;
	@ColumnMapper(columnName = "FIFTEENPER", propertyName = "fifteenPerCount")
	private String fifteenPerCount;

}
