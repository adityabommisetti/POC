/**
 * 
 */
package com.medicare.mss.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;

/**
 * @author DU20098149
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EEMBillingInvoiceDtlsVO implements Cloneable, Serializable {

	private static final long serialVersionUID = 3337563051181618646L;

	private int addNbr;
	private String bankAcctCd;
	private String checkNbr;
	private String createTime;
	private String createUserId;
	private String customerId;
	private String detailAmt;
	private String dispFunctionCdDesc;
	private String functionCd;
	private String functionCdDesc;
	private String groupName;
	private String grpId;
	private String invoiceNbr;
	private String itemAddNbr;
	private String itemDesc;
	private int itemNbr;
	private String lastUpdtTime;
	private String lastUpdtUserId;
	private String lineStatus;
	private String lineStatusDesc;
	private String memberId;
	private String payBatchDate;
	private String payBatchSeqNbr;
	private String payItemNbr;
	private String paySourceDesc;
	private String paySourceType;
	private String productId;
	private String productName;
	private String reasonCd;
	private String reasonCdDesc;
	private String subProductDesc;
	private String subProductId;
	private String xrefInvoiceNbr;

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	
	public String getPayBatchDateFrmt() {
		return DateFormatter.reFormat(payBatchDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

}
