package com.medicare.mss.vo;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EMWFQueAsgnGrpVO implements Serializable {
	
	private static final long serialVersionUID = 6804284872909522767L;

	private String customerId;
	private String loginUserId;
	private String userId;
	private Map<Integer, List<String>> queAsgnNew;
	private int prtyNum;
	private String queueCd;
	private String userConfFlag;
	private String searchUserId;
	private String searchSupAdminId;
}
