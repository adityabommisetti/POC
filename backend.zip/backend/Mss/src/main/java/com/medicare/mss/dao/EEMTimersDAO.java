package com.medicare.mss.dao;

import java.util.Map;

import com.medicare.mss.domainobject.EEMTimersDO;
import com.medicare.mss.vo.PageableVO;

public interface EEMTimersDAO {

	PageableVO getTimersList(Map<String, String> searchParamMap, String customerId, boolean isPagination);

	int updateTimer(EEMTimersDO eemTimersDO, String userId);

}
