package com.medicare.mss.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMMbrDAO;
import com.medicare.mss.dao.EEMMbrOoaDAO;
import com.medicare.mss.domainobject.EEMMbrEnrollmentDO;
import com.medicare.mss.domainobject.EEMMbrOoaInfoDO;
import com.medicare.mss.domainobject.EMMbrTriggerDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.EEMContext;
import com.medicare.mss.helper.EEMEnrollHelper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EEMMbrEnrollmentVO;
import com.medicare.mss.vo.EEMMbrOoaInfoVO;
import com.medicare.mss.vo.EMDatedSegmentVO;

@Service
@Transactional(rollbackFor = ApplicationException.class)
public class EEMMbrOOAService extends EEMMbrBaseService {

	public static final String ERROR_INSERTING_OOA_TRIG = "Error inserting ooa trigger";
	public static final String TEMP = "TEMP";
	public static final String PERM = "PERM";

	@Autowired
	private EEMCodeCache codeCache;

	@Autowired
	private EEMMbrDAO mbrDao;

	@Autowired
	private EEMMbrOoaDAO ooaDao;

	@Autowired
	private EEMEnrollHelper enrollHelper;

	@SuppressWarnings("unchecked")
	public Map<String, Object> updateOoa(EEMMbrOoaInfoVO newVO) throws ParseException {

		String userId = sessionHelper.getUserInfo().getUserId();
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String memberId = newVO.getMemberId();

		List<EEMMbrEnrollmentVO> mbrEnrollVOList = new ArrayList<>();

		EEMMbrEnrollmentVO enrollVO = sessionHelper.getEEMContext().getMbrMasterVO().getMbrEnrollmentList().get(0);

		List<EEMMbrOoaInfoDO> mbrOoaInfosDOLst = new ArrayList<>();
		List<EEMMbrOoaInfoVO> mbrOoaInfoList = getListFromContext(memberId, "N");
		CommonUtils.copyList(mbrOoaInfoList, mbrOoaInfosDOLst, EEMMbrOoaInfoDO.class);

		newVO.setOverrideInd("N");
		newVO.setTempPerm(newVO.getTempPerm().toUpperCase());
		newVO.setCustomerId(customerId);
		EEMMbrOoaInfoDO newDO = new EEMMbrOoaInfoDO();
		BeanUtils.copyProperties(newVO, newDO);

		boolean rslt = mbrOoaInfoUpdate(mbrOoaInfosDOLst, newDO, userId, enrollVO.getPlanId(), enrollVO.getPbpId(),
				enrollVO.getPlanDesignation());

		if (rslt) {
			if (newVO.getTempPerm().equalsIgnoreCase(PERM)) {
				List<EEMMbrEnrollmentDO> enrollDOList = mbrDao.getMbrEnrollments(customerId, memberId, newVO.getShowAll());
				CommonUtils.copyList(enrollDOList, mbrEnrollVOList, EEMMbrEnrollmentVO.class);
			}
			
			mbrOoaInfoList = getMbrOoaListfromDb(memberId, newVO.getShowAll());
			EEMContext context = sessionHelper.getEEMContext();
			if (StringUtils.equals(EEMConstants.VALUE_NO, newVO.getShowAll())) {
				if(newVO.getTempPerm().equalsIgnoreCase(PERM)) {
				context.getMbrMasterVO().setMbrEnrollmentList(mbrEnrollVOList);
				sessionHelper.setEEMContext(context);
				}
				setToContext(mbrOoaInfoList);
			} else {
				List<EEMMbrEnrollmentVO> mbrEnrollActiveVOList = (List<EEMMbrEnrollmentVO>) getActiveDatedList(mbrEnrollVOList);
				List<EEMMbrOoaInfoVO> mbrOoaActiveVOList = (List<EEMMbrOoaInfoVO>) getActiveDatedList(mbrOoaInfoList);
				if(newVO.getTempPerm().equalsIgnoreCase(PERM)) {
				context.getMbrMasterVO().setMbrEnrollmentList(mbrEnrollActiveVOList);
				sessionHelper.setEEMContext(context);
				}
				setToContext(mbrOoaActiveVOList);
			}
			//sessionHelper.setEEMContext(context);
		} else {
			throw new ApplicationException("OOA Update Failed");
		}
		return buildResultMap(mbrOoaInfoList, mbrEnrollVOList);
	}

	public boolean mbrOoaInfoUpdate(List<EEMMbrOoaInfoDO> ooaInfoLst, EEMMbrOoaInfoDO newVO, String userId,
			String planCode, String pbpId, String planDesignation) throws ParseException {

		String ts = DateUtil.getCurrentDatetimeStamp();
		Map<String, String> type = new HashMap<>();
		int sqlCnt = 0;

		newVO.setPlanDesignation(planDesignation);
		String maxLastUpdate = mbrDao.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
				EEMConstants.EEM_MBR_OOA, type);
		if (hasDataChanged(ooaInfoLst, maxLastUpdate)) {
			throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
		}

		EEMMbrOoaInfoDO matchVO = matchDatedSegmentPerm(ooaInfoLst, newVO);
		if (matchVO != null) {
			throw new ApplicationException("A permanent OOA record already exist for the specified period");
		}
		// the update case
		matchVO = (EEMMbrOoaInfoDO) matchDatedSegment(ooaInfoLst, newVO);
		if (matchVO != null) {
			sqlCnt = ooaDao.setOoaInfoOverride(matchVO, userId);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_OVERRIDING_SEGMENT);
			}
			setBasicInfo(newVO, userId, ts);
			sqlCnt = ooaDao.insertMbrOoaInfo(newVO);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
			}

			ooaTrigger(newVO, userId, ts, planCode, pbpId);

			maxLastUpdate = mbrDao.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
					EEMConstants.EEM_MBR_OOA, type);
			if (hasDataChanged(ts, maxLastUpdate)) {
				throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
			}
			return true;
		}
		setBasicInfo(newVO, userId, ts);

		if (ooaInfoLst != null && !ooaInfoLst.isEmpty())
			ooaDao.setOoaInfoOverride(newVO, userId);
		setBasicInfo(newVO, userId, ts);
		sqlCnt = ooaDao.insertMbrOoaInfo(newVO);
		if (sqlCnt != 1) {
			throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
		}
		// INSERTING TRIGGERS
		ooaTrigger(newVO, userId, ts, planCode, pbpId);

		maxLastUpdate = mbrDao.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(), EEMConstants.EEM_MBR_OOA,
				type);
		if (hasDataChanged(ts, maxLastUpdate)) {
			throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
		}
		return true;
	}

	private void setBasicInfo(EEMMbrOoaInfoDO newVO, String userId, String ts) {
		newVO.setCreateTime(ts);
		newVO.setCreateUserId(userId);
		newVO.setLastUpdtTime(ts);
		newVO.setLastUpdtUserId(userId);
	}

	public EEMMbrOoaInfoDO matchDatedSegmentPerm(List<? extends EMDatedSegmentVO> addrLst, EEMMbrOoaInfoDO chkVO) {

		EEMMbrOoaInfoDO item;
		Iterator<? extends EMDatedSegmentVO> it = addrLst.iterator();
		while (it.hasNext()) {
			item = (EEMMbrOoaInfoDO) it.next();
			if (item.permOOAExists(chkVO)) {
				return item;
			}
		}
		return null;
	}

	private void ooaTrigger(EEMMbrOoaInfoDO newVO, String userId, String ts, String planCode, String pbpId)
			throws ApplicationException, ParseException {

		boolean check;
		int sqlCnt = 0;
		String planDesignation = newVO.getPlanDesignation();
		String effDate = null;
		String ltrEffDate = DateUtil.getTodaysDate();

		EMMbrTriggerDO trig = enrollHelper.prepareMbrTriggerDO(newVO.getMemberId(), EEMConstants.TRIG_TYPE_FOLLOWUP_MEMB,
				EEMConstants.TRIG_STATUS_OPEN, "OOAT", newVO.getDeEffectiveDate());
		trig.setProcessSource(EEMConstants.TRIG_PROCESS_SOURCE_WEBENRL);
		trig.setPlanId(planCode);
		trig.setPbpId(pbpId);
		trig.setPlanDesignation(planDesignation);

		if (newVO.getTempPerm().equalsIgnoreCase(TEMP)) {

			if (newVO.getReturnDate().equals("")) {
				if (!(newVO.getOoaReason().equals("04"))) {

					String oldEffDate = mbrDao.checkMbrTrigger(newVO.getCustomerId(), newVO.getMemberId(),
							trig.getTriggerType(), trig.getTriggerCode());

					if (!oldEffDate.isEmpty() && !oldEffDate.equals(effDate)) {
						ooaDao.closeFUMTrigger(trig);
						sqlCnt = mbrDao.insertMbrTrigger(trig);
						if (sqlCnt != 1)
							throw new ApplicationException(ERROR_INSERTING_OOA_TRIG);
					} else {

						sqlCnt = mbrDao.insertMbrTrigger(trig);
						if (sqlCnt != 1)
							throw new ApplicationException(ERROR_INSERTING_OOA_TRIG);
					}

					// letter trigger
					trig.setTriggerType(EEMConstants.TRIG_TYPE_MANUAL_LTR);
					trig.setEffectiveDate(ltrEffDate);
					if (planDesignation.equalsIgnoreCase("MAPD") || planDesignation.equalsIgnoreCase("MA")) {
						trig.setTriggerCode("02034D");
					} else if (planDesignation.equalsIgnoreCase("PDP")) {
						trig.setTriggerCode("03033P");
					}

					oldEffDate = mbrDao.checkMbrTrigger(newVO.getCustomerId(), newVO.getMemberId(),
							trig.getTriggerType(), trig.getTriggerCode());

					if (!(StringUtil.nonNullTrim(oldEffDate).equals(effDate))) {

						sqlCnt = mbrDao.insertMbrTrigger(trig);
						if (sqlCnt != 1)
							throw new ApplicationException(ERROR_INSERTING_OOA_TRIG);
					}
					// Cancellation of timer when return date updated
					
				}

				else if (newVO.getOoaReason().equals("04")) {

					trig.setTriggerType(EEMConstants.TRIG_TYPE_MANUAL_LTR);

					trig.setEffectiveDate(ltrEffDate);

					if (planDesignation.equalsIgnoreCase("MAPD") || planDesignation.equalsIgnoreCase("MA"))
						trig.setTriggerCode("IPLNCGD");
					else if (planDesignation.equalsIgnoreCase("PDP"))
						trig.setTriggerCode("IPLNCGP");

					String oldEffDate = mbrDao.checkMbrTrigger(newVO.getCustomerId(), newVO.getMemberId(),
							trig.getTriggerType(), trig.getTriggerCode());

					if (oldEffDate.isEmpty()) {

						sqlCnt = mbrDao.insertMbrTrigger(trig);
						if (sqlCnt != 1)
							throw new ApplicationException(ERROR_INSERTING_OOA_TRIG);
					}

					trig.setTriggerType(EEMConstants.TRIG_TYPE_FOLLOWUP_MEMB);
					trig.setEffectiveDate(newVO.getDeEffectiveDate());
					trig.setTriggerCode("OOAT");

					oldEffDate = mbrDao.checkMbrTrigger(newVO.getCustomerId(), newVO.getMemberId(),
							trig.getTriggerType(), trig.getTriggerCode());

					if (!oldEffDate.isEmpty() && !oldEffDate.equals(effDate)) {

						ooaDao.closeFUMTrigger(trig);
						sqlCnt = mbrDao.insertMbrTrigger(trig);
						if (sqlCnt != 1)
							throw new ApplicationException(ERROR_INSERTING_OOA_TRIG);
					} else {

						sqlCnt = mbrDao.insertMbrTrigger(trig);
						if (sqlCnt != 1)
							throw new ApplicationException(ERROR_INSERTING_OOA_TRIG);
					}
				}
			}
			// Check for return date
			else if (!(newVO.getReturnDate().equals(""))) {

				ooaDao.closeFUMTrigger(trig);

			}

		}
		if (newVO.getTempPerm().equalsIgnoreCase(PERM)) {

			EEMMbrEnrollmentDO enroll = ooaDao.getOoaDisenroll(newVO, userId);
			if (enroll != null) {
				if (enroll.getEnrollStatus().equalsIgnoreCase("EAPRV")
						&& enroll.getEnrollReasonCd().equalsIgnoreCase("CMSAPRV")) {

					ooaDao.setOoaDisenroll(newVO, enroll, userId);
					trig.setTriggerType(EEMConstants.TRIG_TYPE_TXN);
					trig.setTriggerCode(EEMConstants.TRIG_CODE_DISENROLL_OOA);

					check = mbrDao.checkMbrTrigger(trig);

					if (!check) {
						sqlCnt = mbrDao.insertMbrTrigger(trig);
						if (sqlCnt != 1)
							throw new ApplicationException(EEMConstants.ERROR_INSERTING_OOA_DISENROLL_TRANSACTION_TRIGGER);
					}

				} else {
					throw new ApplicationException(EEMConstants.DISENROLLED_FOR_THE_GIVEN_DISENROLLMENT_DATE);
				}
			} else {
				throw new ApplicationException(EEMConstants.DISENROLLED_FOR_THE_GIVEN_DISENROLLMENT_DATE);
			}

			trig.setTriggerType(EEMConstants.TRIG_TYPE_MANUAL_LTR);

			trig.setEffectiveDate(ltrEffDate);
			if (planDesignation.equalsIgnoreCase("MAPD")) {
				trig.setTriggerCode("02036D");
			} else if (planDesignation.equalsIgnoreCase("MA")) {
				trig.setTriggerCode("02036M");
			} else if (planDesignation.equalsIgnoreCase("PDP")) {
				trig.setTriggerCode("03035P");
			}

			check = mbrDao.checkMbrTrigger(trig);

			if (!check) {
				sqlCnt = mbrDao.insertMbrTrigger(trig);
				if (sqlCnt != 1)
					throw new ApplicationException(ERROR_INSERTING_OOA_TRIG);
			}

		}
	}

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public List<EEMMbrOoaInfoVO> getListFromContext(String memberId, String showAll) {
		EEMContext context = sessionHelper.getEEMContext();
		List<EEMMbrOoaInfoVO> mbrOoaVOList = context.getMbrMasterVO().getMbrOoaInfoList();
		
		if (StringUtils.equals(EEMConstants.VALUE_YES, showAll)) {
			List<EEMMbrOoaInfoVO> allInfos = getMbrOoaListfromDb(memberId, showAll);
				mbrOoaVOList = (List<EEMMbrOoaInfoVO>) getActiveDatedList(allInfos);
				setToContext(mbrOoaVOList);
			return allInfos;
		} else {
			if (Objects.isNull(mbrOoaVOList)) {
				mbrOoaVOList = getMbrOoaListfromDb(memberId, showAll);
				setToContext(mbrOoaVOList);
			} else {
				mbrOoaVOList = (List<EEMMbrOoaInfoVO>) getActiveDatedList(mbrOoaVOList);
				setToContext(mbrOoaVOList);
			}
			return mbrOoaVOList;
		}
	}

	public List<EEMMbrOoaInfoVO> getMbrOoaListfromDb(String memberId, String showAll) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		List<EEMMbrOoaInfoVO> mbrOoaVOList = new ArrayList<>();

		List<EEMMbrOoaInfoDO> mbrOoaDOList = ooaDao.getMbrOoaInfos(customerId, memberId, showAll);

		mbrOoaDOList.forEach(mbrOoaDO -> {
			EEMMbrOoaInfoVO mbrOoaVO = new EEMMbrOoaInfoVO();
			BeanUtils.copyProperties(mbrOoaDO, mbrOoaVO);

			mbrOoaVO.setSourceDesc(codeCache.getOoaSourceDesc(mbrOoaVO.getOoaSource(), customerId));
			mbrOoaVO.setReasonDesc(codeCache.getOoaReasonDesc(mbrOoaVO.getOoaReason(), customerId));
			mbrOoaVO.setDeReasonDesc(codeCache.getDeReasonDesc(mbrOoaVO.getDeReason(), customerId));
			if (mbrOoaVO.getOoaSource().equals("05")) {
				mbrOoaVO.setSourceDesc("05 - TRR");
			}
			mbrOoaVOList.add(mbrOoaVO);
		});

		return mbrOoaVOList;

	}

	public void setToContext(List<EEMMbrOoaInfoVO> mbrOoaInfoList) {
		EEMContext context = sessionHelper.getEEMContext();
		context.getMbrMasterVO().setMbrOoaInfoList(mbrOoaInfoList);
		sessionHelper.setEEMContext(context);
	}

	public Map<String, Object> buildResultMap(List<EEMMbrOoaInfoVO> mbrOoaInfoList,
			List<EEMMbrEnrollmentVO> mbrEnrollVOList) {

		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("mbrOoaList", mbrOoaInfoList);
		resultMap.put("mbrEnrollList", mbrEnrollVOList);

		return resultMap;

	}

}
