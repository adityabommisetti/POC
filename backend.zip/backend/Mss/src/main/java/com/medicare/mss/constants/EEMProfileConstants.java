package com.medicare.mss.constants;

final public class EEMProfileConstants {

	private EEMProfileConstants() {

	}

	public static final String ADRVAL = "ADRVAL";
	public static final String AEP = "AEP";
	public static final String AEPGRACE = "AEPGRACE";
	public static final String AGENTDT = "AGENTDT";
	public static final String APPFIELDS = "APPFIELDS";
	public static final String APPNBR = "APPNBR";
	public static final String APPNBR_DERIVED = "D";
	public static final String APPNBRFRMT = "APPNBRFRMT";
	public static final String BEQCHECK = "BEQCHECK";
	public static final String COBPRIM = "COBPRIM";
	public static final String CORRLANG = "CORRLANG";
	public static final String DEP = "DEP";
	public static final String LOB_VALD = "LOB_VALD";
	public static final String SUPER_USER = "SUPUSER";
	public static final String SUPPEND = "SUPPEND";
	public static final String SUPPLID = "SUPPLID";
	public static final String SUPPFIX = "SUPPFIX";
	public static final String RXID = "RXID";
	public static final String SUPPLID_DERIVED = "D";
	public static final String SUPPLID_GENERATED = "G";
	public static final String SUPPLID_TEXT = "KEEPSUP";
	public static final String RXID_USE_SUPPLID = "S";
	public static final String BANKCDTB = "BANKCDTB";
	public static final String MULTIORG = "MULTIORG";
	public static final String NPIIND = "NPIIND";
	public static final String PRINTIDC = "PRINTIDC";
	public static final String PRINTIDC_TEXT = "PRINTIDC_TEXT";
	public static final String IDUSREFFDT = "IDUSREFFDT";
}
