package com.medicare.mss.domainobject;

import lombok.Data;

@Data
public class EEMMbrEligibilityDO {

	private String customerId;
	private String memberId;
	private String lastCheckedTime;
	private String hicNbr;
	private String mbrHicNbr;
	private String lastName;
	private String firstName;
	private String middleInit;
	private String genderNumCd;
	private String birthDate;
	private String livingStatus;
	private String deathDate;
	private String prtAEntitleStartDate;
	private String prtAEntitleEndDate;
	private String prtBEntitleStartDate;
	private String prtBEntitleEndDate;
	private String prtDEligStartDate;
	private String prtAOption;
	private String prtBOption;
	private String enrollmentStatus;
	private String hospiceInd;
	private String hospiceStartDate;
	private String hospiceEndDate;
	private String instInd;
	private String instStartDate;
	private String instEndDate;
	private String esrdInd;
	private String esrdStartDate;
	private String esrdEndDate;
	private String wrkAgedInd;
	private String wrkAgedStartDate;
	private String wrkAgedEndDate;
	private String medicInd;
	private String medicStartDate;
	private String medicEndDate;
	private String raceCD;
	private String stateCd;
	private String countyCd;
	private String calcUncovMonths;
	private String eligibilitySource;
	private String lastUpdtUserid;
	private String mbiNbr;
	private String isHicOrMbi;
	private String displayHic;
	private String mbi;
	private String lastUsedSepDate;

}
