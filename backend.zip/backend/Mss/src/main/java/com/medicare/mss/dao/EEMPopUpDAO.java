package com.medicare.mss.dao;

import java.util.List;
import java.util.Map;

import com.medicare.mss.domainobject.EEMApplProductDO;

public interface EEMPopUpDAO {
	List<Map<String, String>> getLstSrchAgencies(String customerId, Map<String, String> searchParamMap);

	List<Map<String, String>> getLstPCPNames(String customerId, Map<String, String> searchParamMap);

	List<EEMApplProductDO> getProducts(String customerId, Map<String, String> searchParamMap);

	List<Map<String, String>> getCityNameswithCounty(Map<String, String> searchParamMap);

	List<EEMApplProductDO> getApplProducts(Map<String, String> searchParamMap, String customerId);

}
