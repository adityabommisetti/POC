package com.medicare.mss.exception.handlers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.exception.UnAuthorizedException;
import com.medicare.mss.helper.ApiResponse;
import com.medicare.mss.helper.JSONResponse;

@RestControllerAdvice
public class ExceptionControllerAdvice {
	

	@ExceptionHandler(value = ApplicationException.class)
	public ResponseEntity<?> handleException(ApplicationException exception) {
		JSONResponse jsonResponse = new JSONResponse();
		jsonResponse.setStatus(EEMConstants.FAILURE);
		jsonResponse.setMessage(exception.getMessage());
		jsonResponse.setData(null);
		return new ResponseEntity<>(jsonResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}


	@ExceptionHandler(value = { UnAuthorizedException.class })
	public ResponseEntity<ApiResponse> unAuthorizedException(UnAuthorizedException exception) {
		return ResponseEntity.status(401).body(new ApiResponse(401, exception.getMessage()));
	}

	@ExceptionHandler(value = { Exception.class })
	public ResponseEntity<ApiResponse> commonExp(Exception exception) {
		return ResponseEntity.status(500).body(new ApiResponse(500, exception.getMessage()));
	}

}
