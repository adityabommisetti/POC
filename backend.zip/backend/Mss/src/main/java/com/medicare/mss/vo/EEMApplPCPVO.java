package com.medicare.mss.vo;

import lombok.Data;

@Data
public class EEMApplPCPVO {
	
	private String pcpCurrPatnt="N";
	private String PcpLocationId;
    private String pcpOfficeCd;
	
}
