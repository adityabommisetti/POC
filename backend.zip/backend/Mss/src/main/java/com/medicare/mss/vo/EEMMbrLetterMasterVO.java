package com.medicare.mss.vo;

import java.util.List;

import lombok.Data;

@Data
public class EEMMbrLetterMasterVO {
	private boolean nextPage;
	private List<EmCorrMbrVO> lstLetterVO;
	private List<EmCorrVarDataVO> lstMbrCorrVO;
}
