package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class EEMLepAttestCcfDO extends BaseDO {
	
	
	@ColumnMapper(columnName="APPLICATION_ID,MEMBER_ID" ,propertyName="primaryId")
	private String primaryId;
		
	@ColumnMapper(columnName="COMPT_RESP_RCVD_DATE" ,propertyName="comptRespRecDate")
	private String comptRespRecDate;
	
	@ColumnMapper(columnName="COVERAGE_BREAK_IND" ,propertyName="brkInCoverage")
	private String brkInCoverage;
	
	@ColumnMapper(columnName="SOURCE_OF_CREDIBLE_RX_COV" ,propertyName="credRXCoverage")
	private String credRXCoverage;
	
	@ColumnMapper(columnName="COV_BRK_FROM_DATE" ,propertyName="fromDate")
	private String fromDate;
	
	@ColumnMapper(columnName="COV_BRK_END_DATE" ,propertyName="toDate")
	private String toDate;

	private String lepEffDate;
	
	@ColumnMapper(columnName="CCF_UNCOV_MONTHS" ,propertyName="ccfUncovMnths")
	private Integer ccfUncovMnths;

	@ColumnMapper(columnName="RESPONSE_TYPE" ,propertyName="respType")
	private String respType;
	
	@ColumnMapper(columnName="OVERRIDE_IND" ,propertyName="overRideInd")
	private String overRideInd;
	private String userId;

}
