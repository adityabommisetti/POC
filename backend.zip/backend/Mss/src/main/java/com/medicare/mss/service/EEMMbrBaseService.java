package com.medicare.mss.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMApplDAO;
import com.medicare.mss.dao.EEMMbrBaseDAO;
import com.medicare.mss.dao.EEMMbrErrorDAO;
import com.medicare.mss.domainobject.EEMFieldErrorDO;
import com.medicare.mss.domainobject.EmMbrErrorDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EEMFieldErrorVO;
import com.medicare.mss.vo.EEMMbrEnrollmentVO;
import com.medicare.mss.vo.EMDatedSegmentVO;
import com.medicare.mss.vo.EmMbrErrorVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@Component
public class EEMMbrBaseService {

	private static final String ERROR_OVERRIDING_OLD_SEGMENT = "Error Overriding Old Segment Contained In";
	private static final String ERROR_SPLITTING_ABOVE = "Error Spliting Above";
	private static final Logger LOGGER = LoggerFactory.getLogger(EEMMbrBaseService.class);

	@Autowired
	protected EEMMbrErrorDAO eemMbrErrorDAO;
	
	@Autowired
	protected CacheService sessionHelper;
	
	@Autowired
	EEMApplDAO eEMApplDAO;
	
	public List<EEMFieldErrorVO> getValidatingFormFields(String sFormName) throws ApplicationException {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		List<EEMFieldErrorVO> lstFields = new ArrayList<>();

			List<EEMFieldErrorDO> lstFieldsDOList = eemMbrErrorDAO.getFormFieldErrors(sFormName, customerId);
			CommonUtils.copyList(lstFieldsDOList, lstFields, EEMFieldErrorVO.class);

			return lstFields;
	}

	public String checkDates(EMDatedSegmentVO chkVO) throws ParseException {
		String result = null;
		if (!DateMath.isFDOM(chkVO.getEffStartDate())) {
			result = "Start Date is not first of month";
		}
		if (!chkVO.getEffEndDate().equals(EEMConstants.EFF_END_DATE) && !DateMath.isLDOM(chkVO.getEffEndDate())) {
			result = "End Date is not last of month";
		}
		return result;
	}

	public List<? extends EMDatedSegmentVO> getActiveDatedList(List<? extends EMDatedSegmentVO> lst) {

		List<EMDatedSegmentVO> activeDatedList = new ArrayList<>();
		EMDatedSegmentVO item;

		Iterator<? extends EMDatedSegmentVO> it = lst.iterator();
		while (it.hasNext()) {
			item = it.next();
			if (Objects.nonNull(item.getOverrideInd())
					&& StringUtils.equals(EEMConstants.VALUE_NO, item.getOverrideInd()))
				activeDatedList.add(item);
		}
		return activeDatedList;
	}

	public boolean hasDataChanged(List<? extends EMDatedSegmentVO> lst, String dbMaxUpdate) {
		boolean hasDataChanged = false;
		String usersMaxUpdate = null;

		EMDatedSegmentVO item = getMostReceintUpdateRecord(lst);
		if (Objects.isNull(item)) {
			usersMaxUpdate = EEMConstants.DEFAULT_INITIAL_TIMESTAMP;
		} else {
			usersMaxUpdate = item.getLastUpdtTime();
		}
		hasDataChanged = !DateMath.isEqual(dbMaxUpdate, usersMaxUpdate);
		
		if(hasDataChanged) {
			LOGGER.debug("hasDataChanged(lst, string)");
			LOGGER.debug("dbMaxUpdate::{}, usersMaxUpdate:: {}", dbMaxUpdate, usersMaxUpdate);
		}
		return hasDataChanged;
	}

	public EMDatedSegmentVO getMostReceintUpdateRecord(List<? extends EMDatedSegmentVO> lst) {

		EMDatedSegmentVO retItem = null;
		EMDatedSegmentVO item;
		Iterator<? extends EMDatedSegmentVO> it = lst.iterator();
		while (it.hasNext()) {
			item = it.next();
			if (Objects.nonNull(retItem)) {
				if (DateMath.isGreaterThan(item.getLastUpdtTime(), retItem.getLastUpdtTime())) {
					retItem = item;
				}
			} else {
				retItem = item;
			}
		}
		return retItem;
	}

	public boolean hasDataChanged(String ts, String maxLastUpdate) {
		boolean hasDataChanged = false;

		String dbMaxLastUpdate = DateUtil.appendExtraZerosIfNeeded(maxLastUpdate);
		hasDataChanged = !DateMath.isEqual(ts, dbMaxLastUpdate);
		
		if(hasDataChanged) {
			LOGGER.debug("hasDataChanged(string, string)");
			LOGGER.debug("ts::{}, maxLastUpdate:: {}", ts, dbMaxLastUpdate);
		}
		return hasDataChanged;
	}

	public EMDatedSegmentVO matchDatedSegment(List<? extends EMDatedSegmentVO> itemList, EMDatedSegmentVO chkVO) {
		EMDatedSegmentVO emDatedSegmentVO = null;
		Iterator<? extends EMDatedSegmentVO> it = itemList.iterator();

		while (it.hasNext()) {
			EMDatedSegmentVO item = it.next();
			if (item.isForSamePeriod(chkVO)) {
				emDatedSegmentVO = item;
			}
		}
		return emDatedSegmentVO;
	}

	public EMDatedSegmentVO matchDatedSegmentEndDate(List<? extends EMDatedSegmentVO> itemList,
			EMDatedSegmentVO chkVO) {
		EMDatedSegmentVO emDatedSegmentVO = null;

		Iterator<? extends EMDatedSegmentVO> it = itemList.iterator();
		while (it.hasNext()) {
			EMDatedSegmentVO item = it.next();
			if (item.getEffEndDate().equals(EEMConstants.EFF_END_DATE) && item.isEndDateChange(chkVO)) {
				emDatedSegmentVO = item;
			}
		}
		return emDatedSegmentVO;
	}

	public boolean sameTimePeriod(EMDatedSegmentVO obj1, EMDatedSegmentVO obj2) {
		return (obj1.getEffStartDate().compareTo(obj2.getEffStartDate()) == 0
				&& obj1.getEffEndDate().compareTo(obj2.getEffEndDate()) == 0);
	}

	private boolean containedWithin(EMDatedSegmentVO obj1, EMDatedSegmentVO obj2) {
		int sdc = obj1.getEffStartDate().compareTo(obj2.getEffStartDate());
		int edc = obj1.getEffEndDate().compareTo(obj2.getEffEndDate());

		return (sdc >= 0 && edc <= 0);
	}

	public boolean splitAbove(EMDatedSegmentVO obj1, EMDatedSegmentVO obj2) {
		return DateMath.isBetween(obj2.getEffEndDate(), obj1.getEffStartDate(), obj1.getEffEndDate());
	}

	public boolean splitBelow(EMDatedSegmentVO obj1, EMDatedSegmentVO obj2) {
		return DateMath.isBetween(obj2.getEffStartDate(), obj1.getEffStartDate(), obj1.getEffEndDate());
	}

	public List<? extends EMDatedSegmentVO> getSegmentsAbove(List<? extends EMDatedSegmentVO> itemList,
			String effDate) {
		List<EMDatedSegmentVO> newLst = new ArrayList<>();
		EMDatedSegmentVO item;
		Iterator<? extends EMDatedSegmentVO> it = itemList.iterator();

		while (it.hasNext()) {
			item = it.next();
			if (item.getEffStartDate().compareTo(effDate) >= 0) {
				newLst.add(item);
			}
		}
		return newLst;
	}

	public EMDatedSegmentVO getFirstOverlapSegmentBelow(List<? extends EMDatedSegmentVO> itemList,
			String effStartDate) {

		EMDatedSegmentVO retItem = null;
		EMDatedSegmentVO item;
		Iterator<? extends EMDatedSegmentVO> it = itemList.iterator();
		while (it.hasNext()) {
			item = it.next();

			if (item.getEffStartDate().compareTo(effStartDate) < 0
					&& item.getEffEndDate().compareTo(effStartDate) > 0) {
				if (Objects.nonNull(retItem)) {
					if (retItem.getEffStartDate().compareTo(item.getEffStartDate()) < 0) {
						retItem = item;
					}
				} else {
					retItem = item;
				}
			}
		}
		return retItem;
	}

	public EMDatedSegmentVO getFirstSegmentAbove(List<? extends EMDatedSegmentVO> itemList, String effDate) {

		EMDatedSegmentVO retItem = null;
		EMDatedSegmentVO item;
		Iterator<? extends EMDatedSegmentVO> it = itemList.iterator();
		while (it.hasNext()) {
			item = it.next();
			if (item.getEffStartDate().compareTo(effDate) >= 0) {
				if (retItem != null) {
					if (retItem.getEffStartDate().compareTo(item.getEffStartDate()) > 0) {
						retItem = item;
					}
				} else {
					retItem = item;
				}
			}
		}
		return retItem;
	}

	public EMDatedSegmentVO getFirstSegmentBelow(List<? extends EMDatedSegmentVO> itemList, String effDate) {

		EMDatedSegmentVO retItem = null;
		EMDatedSegmentVO item;
		Iterator<? extends EMDatedSegmentVO> it = itemList.iterator();
		while (it.hasNext()) {
			item = it.next();
			if (item.getEffEndDate().compareTo(effDate) <= 0) {
				if (retItem != null) {
					if (retItem.getEffEndDate().compareTo(item.getEffEndDate()) < 0) {
						retItem = item;
					}
				} else {
					retItem = item;
				}
			}
		}
		return retItem;
	}

	public boolean doDatedSegmentAdjust(List<? extends EMDatedSegmentVO> itemList, EMDatedSegmentVO newVO, String ts,
			String userId, EEMMbrBaseDAO baseDAO)
			throws CloneNotSupportedException, ParseException, ApplicationException {

		int sqlCnt;
		EMDatedSegmentVO insVO;
		EMDatedSegmentVO tempVO;

		Iterator<? extends EMDatedSegmentVO> it = itemList.iterator();
		while (it.hasNext()) {

			tempVO = it.next();
			if (sameTimePeriod(tempVO, newVO)) {
				sqlCnt = baseDAO.setOverride(tempVO, userId);
				if (sqlCnt != 1) {
					throw new ApplicationException("Error Overriding Matched Dated Segment");
				}
				return true;
			}
			if (containedWithin(newVO, tempVO)) {
				sqlCnt = baseDAO.setOverride(tempVO, userId);
				if (sqlCnt != 1) {
					throw new ApplicationException("Error Overriding New Segment Contained In");
				}
				ts = DateUtil.getCurrentDatetimeStamp();
				if (newVO.getEffEndDate().compareTo(tempVO.getEffEndDate()) < 0) {
					insVO = (EMDatedSegmentVO) tempVO.clone();
					insVO.setEffStartDate(DateMath.addOneDay(newVO.getEffEndDate()));
					insVO.setCreateTime(ts);
					insVO.setCreateUserId(userId);
					insVO.setLastUpdtTime(ts);
					insVO.setLastUpdtUserId(userId);
					sqlCnt = baseDAO.insertMbr(insVO);
					if (sqlCnt != 1) {
						throw new ApplicationException("Error Contained Spliting Above");
					}
				}
				if (newVO.getEffStartDate().compareTo(tempVO.getEffStartDate()) > 0) {
					insVO = (EMDatedSegmentVO) tempVO.clone();
					insVO.setEffEndDate(DateMath.minusOneDay(newVO.getEffStartDate()));
					insVO.setCreateTime(ts);
					insVO.setCreateUserId(userId);
					insVO.setLastUpdtTime(ts);
					insVO.setLastUpdtUserId(userId);
					sqlCnt = baseDAO.insertMbr(insVO);
					if (sqlCnt != 1) {
						throw new ApplicationException("Error Contained Spliting Below");
					}
				}
				return true;
			}

			if (containedWithin(tempVO, newVO)) {
				sqlCnt = baseDAO.setOverride(tempVO, userId);
				if (sqlCnt != 1) {
					throw new ApplicationException(ERROR_OVERRIDING_OLD_SEGMENT);
				}
			} else if (splitAbove(tempVO, newVO)) {
				sqlCnt = baseDAO.setOverride(tempVO, userId);
				if (sqlCnt != 1) {
					throw new ApplicationException(ERROR_OVERRIDING_OLD_SEGMENT);
				}
				ts = DateUtil.getCurrentDatetimeStamp();
				insVO = (EMDatedSegmentVO) tempVO.clone();
				insVO.setEffStartDate(DateMath.addOneDay(newVO.getEffEndDate()));
				insVO.setCreateTime(ts);
				insVO.setCreateUserId(userId);
				insVO.setLastUpdtTime(ts);
				insVO.setLastUpdtUserId(userId);
				sqlCnt = baseDAO.insertMbr(insVO);
				if (sqlCnt != 1) {
					throw new ApplicationException(ERROR_SPLITTING_ABOVE);
				}
			} else if (splitBelow(tempVO, newVO)) {
				sqlCnt = baseDAO.setOverride(tempVO, userId);
				if (sqlCnt != 1) {
					throw new ApplicationException(ERROR_OVERRIDING_OLD_SEGMENT);
				}
				ts = DateUtil.getCurrentDatetimeStamp();
				insVO = (EMDatedSegmentVO) tempVO.clone();
				insVO.setEffEndDate(DateMath.minusOneDay(newVO.getEffStartDate()));
				insVO.setCreateTime(ts);
				insVO.setCreateUserId(userId);
				insVO.setLastUpdtTime(ts);
				insVO.setLastUpdtUserId(userId);
				sqlCnt = baseDAO.insertMbr(insVO);
				if (sqlCnt != 1) {
					throw new ApplicationException(ERROR_SPLITTING_ABOVE);
				}
			}
		}
		return true;
	}

	public EMDatedSegmentVO getOpenendedSegment(List<? extends EMDatedSegmentVO> items) {
		EMDatedSegmentVO retItem = null;
		EMDatedSegmentVO item;
		Iterator<? extends EMDatedSegmentVO> it = items.iterator();
		while (it.hasNext()) {
			item = it.next();
			if (item.getEffEndDate().equals(EEMConstants.EFF_END_DATE)) {
				if (retItem != null) {
					if (retItem.getEffStartDate().compareTo(item.getEffStartDate()) > 0) {
						retItem = item;
					}
				} else {
					retItem = item;
				}
			}
		}
		return retItem;
	}

	public EMDatedSegmentVO getSegmentActiveOn(List<? extends EMDatedSegmentVO> items, String effDate) {
		EMDatedSegmentVO item;
		Iterator<? extends EMDatedSegmentVO> it = items.iterator();
		while (it.hasNext()) {
			item = it.next();
			if (DateMath.isBetween(effDate, item.getEffStartDate(), item.getEffEndDate())) {
				return item;
			}

		}
		return null;
	}

	public List<? extends EMDatedSegmentVO> getDatedTypeList(List<? extends EMDatedSegmentVO> lst, String type) {

		List<EMDatedSegmentVO> newLst = new ArrayList<>();
		EMDatedSegmentVO item;

		Iterator<? extends EMDatedSegmentVO> it = lst.iterator();
		while (it.hasNext()) {
			item = it.next();
			if (StringUtils.equals(item.getType(), type)
					&& StringUtils.equals(item.getOverrideInd(), EEMConstants.VALUE_NO)) {
				newLst.add(item);
			}
		}
		return newLst;
	}

	public boolean endsBeforeFirstSegment(List<? extends EMDatedSegmentVO> lst, String effEndDate)
			throws ParseException {

		int idx = lst.size();
		if (idx > 0) {
			String cmpDate = DateMath.addOneDay(effEndDate);
			EMDatedSegmentVO item = lst.get(idx - 1);
			if (item.getEffStartDate().compareTo(cmpDate) > 0)
				return true;
		}
		return false;
	}

	public boolean setErrorDetails(List<EmMbrErrorDO> lstErrors, String memberId, String userId,
			String fieldNbr, String requestScrn, String applDate) throws ApplicationException {

		String ts = DateUtil.getCurrentDatetimeStamp();
		List<EmMbrErrorDO> lstTemp = getMemberErrorsForContext(fieldNbr);
		
		if (!CollectionUtils.isEmpty(lstErrors)) {
			int rslt = 0;

			for (EmMbrErrorDO objError : lstErrors) {
				objError.setMemberId(memberId);
				// Update
				objError.setErrorStatus(EEMConstants.ERROR_STATUS_OPEN);
				objError.setLastUpdtUserId(userId);
				objError.setLastUpdtTime(ts);
				rslt = eemMbrErrorDAO.updateErrorDetails(objError, requestScrn);
				if (rslt == 0) {
					rslt = eemMbrErrorDAO.insertErrorDetails(objError, applDate);
				}
			}

			for (EmMbrErrorDO objTemp : lstTemp) {
				boolean found = false;
				for (EmMbrErrorDO objError : lstErrors) {
					if (StringUtil.nonNullTrim(objTemp.getErrorCd())
							.equals(StringUtil.nonNullTrim(objError.getErrorCd()))
							&& StringUtil.nonNullTrim(objTemp.getFieldNbr())
									.equals(StringUtil.nonNullTrim(objError.getFieldNbr()))
							&& StringUtil.nonNullTrim(objTemp.getErrorData())
									.equals(StringUtil.nonNullTrim(objError.getErrorData()))) {
						found = true;
						break;
					}

				}
				if (!found) {
					objTemp.setErrorStatus(EEMConstants.ERROR_STATUS_CLOSED);
					objTemp.setLastUpdtUserId(userId);
					rslt += eemMbrErrorDAO.updateErrorDetails(objTemp, requestScrn);
				}
			}

			if (rslt == 0) {
				return false;
			}
		} else if (!CollectionUtils.isEmpty(lstTemp)) { // Close Errors
			int rslt = 0;
			for (EmMbrErrorDO objTemp : lstTemp) {
				objTemp.setErrorStatus(EEMConstants.ERROR_STATUS_CLOSED);
				objTemp.setLastUpdtUserId(userId);
				rslt += eemMbrErrorDAO.updateErrorDetails(objTemp, requestScrn);
			}

			if (rslt == 0) {
				return false;
			}
		}
		return true;
	}


	public boolean updateErrorDetails(String userId, String fieldNbr, String requestScrn) throws ApplicationException {
		boolean isUpdated = false;
		List<EmMbrErrorDO> lstTemp = getMemberErrorsForContext(fieldNbr);
		int rslt = 0;

		if (!CollectionUtils.isEmpty(lstTemp)) {
			for (EmMbrErrorDO objTemp : lstTemp) {
				objTemp.setErrorStatus(EEMConstants.ERROR_STATUS_CLOSED);
				objTemp.setLastUpdtUserId(userId);
				rslt += eemMbrErrorDAO.updateErrorDetails(objTemp, requestScrn);
			}
			isUpdated = rslt != 0;
		}
		
		return isUpdated;
	}
	
	private List<EmMbrErrorDO> getMemberErrorsForContext(String fieldNbr) {
		List<EmMbrErrorDO> mbrErrorDOList = new ArrayList<>();

		List<EmMbrErrorVO> mbrErrorVOList = sessionHelper.getEEMContext().getMbrMasterVO().getMbrErrorList();
		if (!CollectionUtils.isEmpty(mbrErrorVOList)) {
			CommonUtils.copyList(mbrErrorVOList, mbrErrorDOList, EmMbrErrorDO.class);
			return mbrErrorDOList.stream().filter(mbrErrorDO -> StringUtils.equals(mbrErrorDO.getFieldNbr(), fieldNbr))
					.collect(Collectors.toList());
		}
		return mbrErrorDOList;

	}
	
	@SuppressWarnings("unchecked")
	protected String getLineOfBusiness(String customerId) {
		String lineOfBusiness = EEMConstants.BLANK;
		EEMMbrEnrollmentVO mbrEnrlVO = null;
		if (Objects.nonNull(sessionHelper.getEEMContext().getMbrMasterVO())
				&& CommonUtils.isNotEmpty(sessionHelper.getEEMContext().getMbrMasterVO().getMbrEnrollmentList())) {
			List<EEMMbrEnrollmentVO> mbrEnrollmentVOList = (List<EEMMbrEnrollmentVO>) getActiveDatedList(sessionHelper.getEEMContext().getMbrMasterVO().getMbrEnrollmentList());
			if (CommonUtils.isNotEmpty(mbrEnrollmentVOList)) {
			mbrEnrlVO = mbrEnrollmentVOList.get(0);
			}
		}

		if (Objects.nonNull(mbrEnrlVO) && Optional.ofNullable(mbrEnrlVO).isPresent()) {
			
			lineOfBusiness = eEMApplDAO.getLineOfBusniess(customerId, mbrEnrlVO.getGrpId(), mbrEnrlVO.getEffStartDate(),
					mbrEnrlVO.getProductId(), mbrEnrlVO.getPlanId(), mbrEnrlVO.getPbpId(), mbrEnrlVO.getPbpSegmentId());
		}

		if (Objects.isNull(lineOfBusiness)) {
			lineOfBusiness = EEMConstants.BLANK;
		}
		return lineOfBusiness;
	}


}
