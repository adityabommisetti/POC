package com.medicare.mss.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.medicare.mss.dao.EEMMbrSOADAO;
import com.medicare.mss.exception.ApplicationException;

@Service
@Transactional(rollbackFor = ApplicationException.class)
public class EEMMbrSOAService extends EEMMbrBaseService {

	@Autowired
	private EEMMbrSOADAO mbrSOADAO;

	public byte[] displayDocumentFromDB(String primaryId) {
		
		byte[] blobByte = null;
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		blobByte = mbrSOADAO.displayDocumentFromDB(primaryId, customerId);

		return blobByte;
	}

}
