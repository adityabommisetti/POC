package com.medicare.mss.daoImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMMbrPOSDAO;
import com.medicare.mss.domainobject.EmMbrPosInfoDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EMDatedSegmentVO;

@Repository
public class EEMMbrPOSDAOImpl implements EEMMbrPOSDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<EmMbrPosInfoDO> getMbrPos(String customerId, String memberId, String showAll) {

		String sqlOverride = " AND OVERRIDE_IND = 'N'";
		if ("Y".equals(showAll))
			sqlOverride = "";

		StringBuilder sQuery = new StringBuilder(
				"SELECT CUSTOMER_ID, MEMBER_ID, NOTIFICATION_DT, CREATE_TIME, OVERRIDE_IND,")
						.append("STATUS_FLAG, DRUG_EDIT_STATUS, DRUG_EDIT_CLASS, DRUG_EDIT_CODE, IMPLEMENTATION_DT,")
						.append("TERMINATION_DT, TXN_STATUS, NOTIFICATION_EDATE, PRESCRIBER_LIMITATION, PHARMACY_LIMITATION,")
						.append(" IMPLEMENTATION_EDATE, CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID")
						.append("  FROM EM_MBR_POS WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? ")
						.append(sqlOverride)
						.append(" ORDER BY LAST_UPDT_TIME DESC");

		try {
			return jdbcTemplate.query(sQuery.toString(),
					new DomainPropertyRowMapper<EmMbrPosInfoDO>(EmMbrPosInfoDO.class), customerId, memberId);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_OCCURED_WHILE_FETCHING_SEGMENTS);
		}

	}

	@Override
	public int setPosInfoOverride(EmMbrPosInfoDO mbrPos, String userId) {

		String currentTime = DateUtil.getCurrentDatetimeStamp();

		StringBuilder sQuery = new StringBuilder("UPDATE EM_MBR_POS")
				.append(" SET OVERRIDE_IND = 'Y', LAST_UPDT_TIME = ?").append(", LAST_UPDT_USERID = ?")
				.append(" WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? AND NOTIFICATION_DT = ? AND CREATE_TIME = ?")
				.append(" AND OVERRIDE_IND = 'N' AND LAST_UPDT_TIME = ?");

		Object[] parms = new Object[] { currentTime, userId, StringUtil.nonNullTrim(mbrPos.getCustomerId()),
				StringUtil.nonNullTrim(mbrPos.getMemberId()), StringUtil.nonNullTrim(mbrPos.getNotificateDate()),
				StringUtil.nonNullTrim(mbrPos.getCreateTime()), StringUtil.nonNullTrim(mbrPos.getLastUpdtTime()) };

		try {

			return jdbcTemplate.update(sQuery.toString(), parms);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT);
		}
	}

	@Override
	public int setMbrPosOverride(EmMbrPosInfoDO overDO, String userId) {

		String currentTime = DateUtil.getCurrentDatetimeStamp();

		StringBuilder sQuery = new StringBuilder("UPDATE EM_MBR_POS")
				.append(" SET OVERRIDE_IND = 'Y', LAST_UPDT_TIME = ?").append(", LAST_UPDT_USERID = ?")
				.append(" WHERE CUSTOMER_ID = ? AND MEMBER_ID = ?")
				.append(" AND OVERRIDE_IND = 'N' AND LAST_UPDT_TIME = ?");

		Object[] parms = new Object[] { currentTime, userId, StringUtil.nonNullTrim(overDO.getCustomerId()),
				StringUtil.nonNullTrim(overDO.getMemberId()), StringUtil.nonNullTrim(overDO.getLastUpdtTime()) };

		try {
			return jdbcTemplate.update(sQuery.toString(), parms);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT);
		}
	}

	@Override
	public int insertMbrPos(EmMbrPosInfoDO newDO) {

		StringBuilder sQuery = new StringBuilder("INSERT INTO EM_MBR_POS( CUSTOMER_ID, MEMBER_ID,  NOTIFICATION_DT, ")
				.append(" CREATE_TIME, OVERRIDE_IND, STATUS_FLAG, ")
				.append(" DRUG_EDIT_STATUS, DRUG_EDIT_CLASS, DRUG_EDIT_CODE,")
				.append(" IMPLEMENTATION_DT, TERMINATION_DT, TXN_STATUS, ")
				.append(" NOTIFICATION_EDATE, PRESCRIBER_LIMITATION, PHARMACY_LIMITATION, IMPLEMENTATION_EDATE,")
				.append(" CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID ) VALUES(?,?,?,?,?,?,?,?,?,")
				.append("?,?,?,?,?,?,?,?,?,?)");

		Object[] parms = new Object[] { StringUtil.nonNullTrim(newDO.getCustomerId()),
				StringUtil.nonNullTrim(newDO.getMemberId()), StringUtil.nonNullTrim(newDO.getNotificateDate()),
				StringUtil.nonNullTrim(newDO.getCreateTime()), StringUtil.nonNullTrim(newDO.getOverrideInd()),
				StringUtil.nonNullTrim(newDO.getStatusFlag()), StringUtil.nonNullTrim(newDO.getDrugEditStatus()),
				StringUtil.nonNullTrim(newDO.getDrugEditClass()), StringUtil.nonNullTrim(newDO.getDrugCode()),
				StringUtil.nonNullTrim(DateUtil.changedDateFormatForMonth(newDO.getImplDate())),
				StringUtil.nonNullTrim(DateUtil.changedDateFormatForMonth(newDO.getTerminationDate())),
				StringUtil.nonNullTrim(newDO.getTxnStatus()),
				StringUtil.nonNullTrim(DateUtil.changedDateFormatForMonth(newDO.getNotificateEndDate())),
				StringUtil.nonNullTrim(newDO.getPrescriberLtStatus()),
				StringUtil.nonNullTrim(newDO.getPharamacyLtStatus()),
				StringUtil.nonNullTrim(DateUtil.changedDateFormatForMonth(newDO.getImplementationEndDate())),
				StringUtil.nonNullTrim(newDO.getCreateUserId()), StringUtil.nonNullTrim(newDO.getLastUpdtTime()),
				StringUtil.nonNullTrim(newDO.getLastUpdtUserId()) };

		try {
			return jdbcTemplate.update(sQuery.toString(), parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_OCCURED_WHILE_INSERTING_NEW_SEGMENT);
		}
	}

	@Override
	public int setOverride(EMDatedSegmentVO emDatedSegmentVO, String userId) {
		return 0;
	}

	@Override
	public int insertMbr(EMDatedSegmentVO emDatedSegmentVO) {
		return 0;
	}

}
