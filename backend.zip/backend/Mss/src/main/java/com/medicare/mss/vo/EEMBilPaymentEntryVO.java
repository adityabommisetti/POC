package com.medicare.mss.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EEMBilPaymentEntryVO {

	private String paySource;
	private String paySourceDesc;
	private String batchDate;
	private String batchSeqNbr;
	private String batchBalance;
	private String detailAmount;
	private String bankAcntCd;
	private String batchBalInd;
	private String batchPostedInd;
	private String supplementId;
	private String createTime;
	private String createUser;
	private String modifiedTime;
	private String modifiedUser;
	private String customerId;
	private String batchDtlCount;
	private String itemNbr;
	private String memberId;
	private String paymentPostedInd;

	public String getFrmtCreateTime() {
		return DateFormatter.reFormat(createTime, DateFormatter.DB2_TIMESTAMP, DateFormatter.MM_DD_YYYY_HH_MM_SS);

	}

	public String getFrmtLastUpdtTime() {
		return DateFormatter.reFormat(modifiedTime, DateFormatter.DB2_TIMESTAMP, DateFormatter.MM_DD_YYYY_HH_MM_SS);

	}

	public String getBatchDate() {
		return DateFormatter.reFormat(batchDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setBatchDate(String batchDate) {
		this.batchDate = DateFormatter.reFormat(batchDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

}
