package com.medicare.mss.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EEMWFCommentVO implements Serializable {

	private static final long serialVersionUID = 8608511685058803616L;

	private String primaryId;
	private String customerId;
	private int commentSeqNbr;
	private String comments;
	private String createTime;
	private String createUserId;
	private Integer caseId;
	private String source;
}
