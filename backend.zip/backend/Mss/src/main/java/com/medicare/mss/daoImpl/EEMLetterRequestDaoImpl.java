package com.medicare.mss.daoImpl;

import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.stereotype.Repository;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMLetterRequestDAO;
import com.medicare.mss.domainobject.EEMLetterReqDO;
import com.medicare.mss.domainobject.EEMLetterVarDataDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.util.PaginationQueryHelper;
import com.medicare.mss.vo.DataBaseField;
import com.medicare.mss.vo.EEMApplTriggerLtrDataVO;
import com.medicare.mss.vo.EEMMbrTriggerLtrDataVO;
import com.medicare.mss.vo.PageableVO;

@Repository
public class EEMLetterRequestDaoImpl implements EEMLetterRequestDAO {

	@Autowired
	CacheService cacheService;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public PageableVO getLetterReqSearchResults(String customerId, Map<String, String> searchParamMap,
			boolean isPagination) {

		PageableVO response = new PageableVO();
		String custNbr = cacheService.getUserInfo().getCustNbr();
		String searchType = trimToEmpty(searchParamMap.get("searchType")).toUpperCase();
		String searchId = trimToEmpty(searchParamMap.get("searchId")).toUpperCase();
		String searchCreateDate = DateFormatter.reFormat(trimToEmpty(searchParamMap.get("searchCreateDate")),
				DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
		String searchStatus = trimToEmpty(searchParamMap.get("searchStatus")).toUpperCase();

		String lastRowPrimaryId = trimToEmpty(searchParamMap.get("lastRowPrimaryId")).toUpperCase();
		String lastRowTriggerType = trimToEmpty(searchParamMap.get("lastRowTriggerType")).toUpperCase();
		String lastRowEffDate = trimToEmpty(searchParamMap.get("lastRowEffDate"));
		String lastRowCreateTime = trimToEmpty(searchParamMap.get("lastRowCreateTime"));
		List<EEMLetterReqDO> letterReqDOList = new ArrayList<>();
		try {
			StringBuilder sql = new StringBuilder();

			sql.append(" SELECT T.CUSTOMER_ID,");
			if (searchType.equals("M")) {
				sql.append(" 'M' AS SOURCE_TYPE, T.MEMBER_ID AS PRIMARY_ID,");
			} else {
				sql.append(" 'A' AS SOURCE_TYPE, T.APPLICATION_ID AS PRIMARY_ID,");
			}
			sql.append(" T.TRIGGER_TYPE, T.EFFECTIVE_DATE, T.CREATE_TIME, T.TRIGGER_CODE, T.TRIGGER_STATUS,")
					.append(" T.CREATE_USERID, T.LAST_UPDT_TIME, T.LAST_UPDT_USERID, CI.CORR_LETTER_NAME,")
					.append(" CI.CORR_SHORT_DESC, Z.LAST_NAME, Z.FIRST_NAME,");
			if (searchType.equals("M")) {
				sql.append(" T.PLAN_ID, T.PBP_ID, T.PLAN_DESIGNATION FROM EM_MBR_TRIGGER T");
			} else {
				sql.append(
						" AP.TO_PLAN_ID AS PLAN_ID, AP.TO_PBP_ID AS PBP_ID, P.PLAN_DESIGNATION FROM EM_APPL_TRIGGER T");
			}
			sql.append(" LEFT JOIN EM_CORR_REASON_INDEX CI ON CI.CUSTOMER_ID in ('9999999',T.CUSTOMER_ID)")
					.append(" AND CI.CORR_REASON_CD = T.TRIGGER_CODE");
			if (searchType.equals("M")) {
				sql.append(" LEFT OUTER JOIN (SELECT * FROM EM_MBR_DEMOGRAPHIC Z1 WHERE Z1.DEMO_SEQ_NBR = (SELECT")
						.append(" MAX(Z2.DEMO_SEQ_NBR) FROM EM_MBR_DEMOGRAPHIC Z2 WHERE Z2.CUSTOMER_ID=Z1.CUSTOMER_ID ")
						.append("AND Z2.MEMBER_ID=Z1.MEMBER_ID AND Z2.OVERRIDE_IND='N') AND Z1.OVERRIDE_IND='N' ")
						.append(") Z ON Z.CUSTOMER_ID = T.CUSTOMER_ID AND Z.MEMBER_ID = T.MEMBER_ID AND Z.OVERRIDE_IND = 'N'");
			} else {
				sql.append(
						" LEFT JOIN EM_APPLICATION Z ON Z.CUSTOMER_ID = T.CUSTOMER_ID AND Z.APPLICATION_ID = T.APPLICATION_ID")
						.append(" LEFT JOIN EM_APPL_PLAN AP ON AP.CUSTOMER_ID = Z.CUSTOMER_ID AND AP.APPLICATION_ID = Z.APPLICATION_ID")
						.append(" LEFT JOIN PLANPBP P ON P.PLAN_ID = AP.TO_PLAN_ID AND P.PBP_ID = AP.TO_PBP_ID");
			}
			sql.append(" WHERE T.CUSTOMER_ID = ? AND T.TRIGGER_TYPE in ('LTO','LTB')");

			ArrayList<String> parmList = new ArrayList<>();
			parmList.add(customerId);
			if (searchType.equals("A")) {
				sql.append(" AND P.CUST_NBR = ?");
				parmList.add(custNbr);
			}
			if (!searchId.equals("")) {
				if (searchType.equals("A")) {
					sql.append(" AND T.APPLICATION_ID = ?");
				} else {
					sql.append(" AND T.MEMBER_ID = ?");
				}
				parmList.add(searchId);
			}
			if (!searchCreateDate.equals("")) {
				String startCreateDate = DateFormatter.reFormat(searchCreateDate, DateFormatter.YYYYMMDD,
						DateFormatter.DB2_TIMESTAMP, DateFormatter.ASSUME_START);
				String endCreateDate = DateFormatter.reFormat(searchCreateDate, DateFormatter.YYYYMMDD,
						DateFormatter.DB2_TIMESTAMP, DateFormatter.ASSUME_END);
				sql.append(" AND T.CREATE_TIME BETWEEN ? AND ?");
				parmList.add(startCreateDate);
				parmList.add(endCreateDate);
			}
			if (!searchStatus.equals("")) {
				sql.append(" AND T.TRIGGER_STATUS = ?");
				parmList.add(searchStatus);
			}
			if (isPagination) {
				DataBaseField[] conds = new DataBaseField[4];
				for (int i = 0; i < 4; i++) {
					conds[i] = new DataBaseField();
				}
				if (searchType.equals("A")) {
					conds[0].setFieldName("T.APPLICATION_ID");
				} else {
					conds[0].setFieldName("T.MEMBER_ID");
				}
				conds[1].setFieldName("T.TRIGGER_TYPE");
				conds[2].setFieldName("T.EFFECTIVE_DATE");
				conds[3].setFieldName("T.CREATE_TIME");

				conds[0].setStringValue(lastRowPrimaryId);
				conds[1].setStringValue(lastRowTriggerType);
				conds[2].setStringValue(lastRowEffDate);
				conds[3].setStringValue(lastRowCreateTime);

				StringBuilder pageCond = PaginationQueryHelper.pagingElements(conds, parmList);
				sql.append(pageCond);
			}
			sql.append(" ORDER BY T.CUSTOMER_ID,");
			if (searchType.equals("A")) {
				sql.append(" T.APPLICATION_ID,");
			} else {
				sql.append(" T.MEMBER_ID,");
			}
			sql.append(" T.TRIGGER_TYPE, T.EFFECTIVE_DATE, T.CREATE_TIME");
			sql.append(" FETCH FIRST ").append(EEMConstants.DB_MAX_RECORD_FETCH).append(" ROWS ONLY");

			Object[] objPrams = parmList.toArray();

			letterReqDOList = jdbcTemplate.query(sql.toString(), objPrams,
					new DomainPropertyRowMapper<EEMLetterReqDO>(EEMLetterReqDO.class));
			if (letterReqDOList != null && !letterReqDOList.isEmpty() && (letterReqDOList.size() > 100)) {
				letterReqDOList.remove(letterReqDOList.size() - 1);
				response.setNextPage(true);
			}
			response.setContent(letterReqDOList);
			return response;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	
	@Override
	public EEMLetterReqDO getletterReqLookup(String customerId, Map<String, String> searchParamMap) {

		String custNbr = cacheService.getUserInfo().getCustNbr();
		String sourceType = trimToEmpty(searchParamMap.get("searchType"));
		String primaryId = trimToEmpty(searchParamMap.get("searchId"));

		EEMLetterReqDO letterReqDO = null;
		try {
			StringBuilder sql = new StringBuilder();

			if (sourceType.equals("M")) {
				sql.append("SELECT E.EFF_START_DATE AS EFFECTIVE_DATE, E.PLAN_ID, E.PBP_ID,")
						.append(" G.FIRST_NAME, G.LAST_NAME, P.PLAN_DESIGNATION FROM EM_MBR_ENROLLMENT E")
						.append(" JOIN EM_MBR_DEMOGRAPHIC G ON G.CUSTOMER_ID = E.CUSTOMER_ID AND G.MEMBER_ID = E.MEMBER_ID")
						.append(" LEFT JOIN PLANPBP P ON P.PLAN_ID = E.PLAN_ID AND P.PBP_ID = E.PBP_ID")
						.append(" WHERE E.CUSTOMER_ID = ? AND E.MEMBER_ID = ? AND E.OVERRIDE_IND = 'N'")
						.append(" AND E.EFF_END_DATE = '99999999' AND P.CUST_NBR = ? FETCH FIRST ROWS ONLY");
			} else {
				sql.append("SELECT AP.EFFECTIVE_DATE, AP.TO_PLAN_ID AS PLAN_ID, AP.TO_PBP_ID AS PBP_ID,")
						.append(" A.FIRST_NAME, A.LAST_NAME, P.PLAN_DESIGNATION FROM EM_APPLICATION A")
						.append(" LEFT JOIN EM_APPL_PLAN AP ON AP.CUSTOMER_ID = A.CUSTOMER_ID AND AP.APPLICATION_ID = A.APPLICATION_ID")
						.append(" JOIN PLANPBP P ON P.PLAN_ID=AP.TO_PLAN_ID AND P.PBP_ID = AP.TO_PBP_ID")
						.append(" WHERE A.CUSTOMER_ID = ? AND A.APPLICATION_ID = ? AND P.CUST_NBR = ? FETCH FIRST ROWS ONLY ");
			}
			Object[] parms = new Object[] { customerId, primaryId, custNbr };

			letterReqDO = jdbcTemplate.queryForObject(sql.toString(), parms,
					new DomainPropertyRowMapper<EEMLetterReqDO>(EEMLetterReqDO.class));
		} catch (EmptyResultDataAccessException exp) {
			throw new ApplicationException("No data found");
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp);
		}
		return letterReqDO;
	}

	@Override
	public List<LabelValuePair> getLetterList(String customerId, String planDesignation, String sourceType) {

		ArrayList<LabelValuePair> lst = new ArrayList<>();
		try {
			StringBuilder sQuery = new StringBuilder("SELECT C.LETTER_NAME, C.DESCRIPTION FROM EM_CORR_CTL C JOIN")
					.append(" EM_CORR_REASON_INDEX R ON R.CUSTOMER_ID = C.CUSTOMER_ID AND R.CORR_LETTER_NAME = C.CORR_LETTER_NAME")
					.append(" WHERE C.CUSTOMER_ID = ? AND C.PLAN_DESIGNATION = ? AND R.APPL_MBRSHIP_IND IN ('B',?)")
					.append(" UNION ALL SELECT C.LETTER_NAME, C.DESCRIPTION FROM EM_CORR_CTL C JOIN EM_CORR_REASON_INDEX R")
					.append(" ON R.CUSTOMER_ID = '9999999' AND R.CORR_LETTER_NAME = C.CORR_LETTER_NAME WHERE C.CUSTOMER_ID = ?")
					.append(" AND C.PLAN_DESIGNATION = ? AND R.APPL_MBRSHIP_IND IN ('B',?) AND NOT EXISTS (SELECT 1 FROM EM_CORR_REASON_INDEX R2")
					.append(" WHERE R2.CUSTOMER_ID = ? AND R2.CORR_LETTER_NAME = R.CORR_LETTER_NAME)");

			Object[] parms = new Object[] { customerId, planDesignation, sourceType, customerId, planDesignation,
					sourceType, customerId };
			jdbcTemplate.query(sQuery.toString(), new RowCallbackHandler() {
				@Override
				public void processRow(ResultSet res) throws SQLException {
					String name = trimToEmpty(res.getString("LETTER_NAME"));
					String desc = trimToEmpty(res.getString("DESCRIPTION"));
					lst.add(new LabelValuePair(name, name + " - " + desc));
				}
			}, parms);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp);
		}
		return lst;
	}

	@Override
	public List<EEMLetterVarDataDO> getLetterDataEntry(String customerId, String letterName) {

		List<EEMLetterVarDataDO> lst = new ArrayList<>();
		try {
			StringBuilder sQuery = new StringBuilder("SELECT CC.VARIABLE_ID, CC.VARIABLE_DESC, CV.FIELD_TYPE,")
					.append(" CV.FIELD_LENGTH FROM EM_CORR_CTL_VAR CC JOIN EM_CORR_VARIABLE CV ON")
					.append(" CV.VARIABLE_ID = CC.VARIABLE_ID WHERE CC.CUSTOMER_ID = ? AND CC.LETTER_NAME = ?")
					.append(" AND CC.UI_ENTRY_IND = 'Y' ORDER BY VARIABLE_SEQ_NBR");

			Object[] parms = new Object[] { customerId, letterName };

			jdbcTemplate.query(sQuery.toString(), new RowCallbackHandler() {
				@Override
				public void processRow(ResultSet res) throws SQLException {
					EEMLetterVarDataDO item = new EEMLetterVarDataDO();
					item.setVarId(trimToEmpty(res.getString("VARIABLE_ID")));
					item.setDescription(trimToEmpty(res.getString("VARIABLE_DESC")));
					item.setFieldType(trimToEmpty(res.getString("FIELD_TYPE")));
					item.setFieldLength(res.getString("FIELD_LENGTH"));
					item.setFieldValue("");
					lst.add(item);
				}
			}, parms);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp);
		}
		return lst;
	}

	@Override
	public String getReasonCode(String customerId, String letterName) {

		String result = null;
		try {
			StringBuilder sql = new StringBuilder("SELECT R.CORR_REASON_CD FROM EM_CORR_CTL C JOIN")
					.append(" EM_CORR_REASON_INDEX R ON R.CORR_LETTER_NAME = C.CORR_LETTER_NAME WHERE")
					.append(" C.CUSTOMER_ID = ? AND C.LETTER_NAME = ? AND R.CUSTOMER_ID IN ('9999999',?)")
					.append(" ORDER BY R.CUSTOMER_ID FETCH FIRST 1 ROWS ONLY");

			Object[] parms = new Object[] { customerId, letterName, customerId };

			result = jdbcTemplate.queryForObject(sql.toString(), parms, String.class);

		} catch (EmptyResultDataAccessException exp) {
			throw new ApplicationException("Reason Cd Not Found for " + letterName);
		}
		return result;
	}

	@Override
	public int insertMbrTriggerLtrData(EEMMbrTriggerLtrDataVO trigData) {

		int sqlCnt = 0;
		try {
			StringBuilder sql = new StringBuilder("INSERT INTO EM_MBR_TRIGGER_LTRDATA( CUSTOMER_ID,")
					.append(" MEMBER_ID, TRIGGER_TYPE, EFFECTIVE_DATE, CREATE_TIME, VARIABLE_SEQ_NBR,")
					.append(" CONTINUE_SEQ_NBR, VARIABLE_ID, VARIABLE_DATA, LAST_UPDT_TIME, LAST_UPDT_USERID)")
					.append(" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

			Object[] parms = new Object[] { trigData.getCustomerId(), trigData.getMemberId(), trigData.getTriggerType(),
					trigData.getEffectiveDate(), trigData.getCreateTime(), trigData.getVariableSeqNbr(),
					trigData.getContinueSeqNbr(), trigData.getVariableId(), trigData.getVariableData(),
					trigData.getLastUpdtTime(), trigData.getLastUpdtUserId() };

			sqlCnt = jdbcTemplate.update(sql.toString(), parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp);
		}
		return sqlCnt;
	}

	@Override
	public int insertApplTriggerLtrData(EEMApplTriggerLtrDataVO trigData) {

		int sqlCnt = 0;
		try {
			StringBuilder sql = new StringBuilder("INSERT INTO EM_APPL_TRIGGER_LTRDATA( CUSTOMER_ID,")
					.append(" APPLICATION_ID, TRIGGER_TYPE, EFFECTIVE_DATE, CREATE_TIME, VARIABLE_SEQ_NBR,")
					.append(" CONTINUE_SEQ_NBR, VARIABLE_ID, VARIABLE_DATA, LAST_UPDT_TIME, LAST_UPDT_USERID)")
					.append(" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

			Object[] parms = new Object[] { trigData.getCustomerId(), trigData.getApplicationId(),
					trigData.getTriggerType(), trigData.getEffectiveDate(), trigData.getCreateTime(),
					trigData.getVariableSeqNbr(), trigData.getContinueSeqNbr(), trigData.getVariableId(),
					trigData.getVariableData(), trigData.getLastUpdtTime(), trigData.getLastUpdtUserId() };

			sqlCnt = jdbcTemplate.update(sql.toString(), parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp);
		}
		return sqlCnt;
	}


	@Override
	public int cancelledLetterReq(EEMLetterReqDO letterReqDO, String userId, String ts) {
		String sourceType = letterReqDO.getSourceType();

		int sqlCnt = 0;
		try {
			StringBuilder query = new StringBuilder();

			query.append(" UPDATE");

			if (sourceType.equals("A")) {
				query.append(" EM_APPL_TRIGGER");
			} else {
				query.append(" EM_MBR_TRIGGER");
			}
			query.append(" SET TRIGGER_STATUS = 'CANCELLED', LAST_UPDT_TIME = ?,")
					.append(" LAST_UPDT_USERID = ? WHERE CUSTOMER_ID = ?");

			if (sourceType.equals("A")) {
				query.append(" AND APPLICATION_ID = ?");
			} else {
				query.append(" AND MEMBER_ID = ?");
			}
			query.append(" AND TRIGGER_TYPE = ? AND EFFECTIVE_DATE = ? AND CREATE_TIME = ?");

			Object[] parms = new Object[] { ts, userId, letterReqDO.getCustomerId(), letterReqDO.getPrimaryId(),
					letterReqDO.getTriggerType(), letterReqDO.getEffDate(), letterReqDO.getCreateTime() };

			sqlCnt = jdbcTemplate.update(query.toString(), parms);

		} catch (Exception exp) {
			throw new ApplicationException(exp);
		}
		return sqlCnt;
	}

}
