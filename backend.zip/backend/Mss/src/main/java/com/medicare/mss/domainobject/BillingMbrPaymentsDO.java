package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class BillingMbrPaymentsDO {

	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;

	@ColumnMapper(columnName = "PAY_SOURCE_TYPE", propertyName = "paySourceType")
	private String paySourceType;

	private String paySourceDesc;

	@ColumnMapper(columnName = "BATCH_DATE", propertyName = "batchDate")
	private String batchDate;

	@ColumnMapper(columnName = "BATCH_SEQ_NBR", propertyName = "batchSeqNbr")
	private int batchSeqNbr;

	@ColumnMapper(columnName = "ITEM_NBR", propertyName = "itemNbr")
	private int itemNbr;

	@ColumnMapper(columnName = "INVOICE_ID", propertyName = "invoiceId")
	private String invoiceId;

	@ColumnMapper(columnName = "INVOICE_DUE_DATE", propertyName = "invoiceDueDate")
	private String invoiceDueDate;

	@ColumnMapper(columnName = "CHECK_DATE", propertyName = "checkDate")
	private String checkDate;

	@ColumnMapper(columnName = "CHECK_NBR", propertyName = "checkNbr")
	private String checkNbr;

	@ColumnMapper(columnName = "PAYMENT_AMT", propertyName = "paymentAmt")
	private String paymentAmt;

	@ColumnMapper(columnName = "PAYMENT_POSTED_IND", propertyName = "paymentPostedInd")
	private String paymentPostedInd;

	@ColumnMapper(columnName = "BANK_ACCT_CD", propertyName = "bankAcctCd")
	private String bankAcctCd;

	@ColumnMapper(columnName = "LAST_NAME", propertyName = "lastName")
	private String lastName;

	@ColumnMapper(columnName = "FIRST_NAME", propertyName = "firstName")
	private String firstName;

	@ColumnMapper(columnName = "DS_VALUE", propertyName = "hicNbr")
	private String hicNbr;

	@ColumnMapper(columnName = "CREATE_TIME", propertyName = "createTime")
	private String createTime;

	@ColumnMapper(columnName = "CREATE_USERID", propertyName = "createUserId")
	private String createUserId;

	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;

	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserId")
	private String lastUpdtUserId;

}
