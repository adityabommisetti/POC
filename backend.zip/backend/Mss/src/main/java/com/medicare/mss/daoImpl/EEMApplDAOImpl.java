package com.medicare.mss.daoImpl;

import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.caching.EEMPersistence;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMApplDAO;
import com.medicare.mss.dao.EEMPopUpDAO;
import com.medicare.mss.dao.EEMWfDAO;
import com.medicare.mss.domainobject.EEMApplAddressDO;
import com.medicare.mss.domainobject.EEMApplAgentDO;
import com.medicare.mss.domainobject.EEMApplAttestationDO;
import com.medicare.mss.domainobject.EEMApplCommentsDO;
import com.medicare.mss.domainobject.EEMApplEligibilityDO;
import com.medicare.mss.domainobject.EEMApplErrorDO;
import com.medicare.mss.domainobject.EEMApplFieldErrorDO;
import com.medicare.mss.domainobject.EEMApplLisDO;
import com.medicare.mss.domainobject.EEMApplOtherCovDO;
import com.medicare.mss.domainobject.EEMApplOtherPlanDO;
import com.medicare.mss.domainobject.EEMApplPlanDO;
import com.medicare.mss.domainobject.EEMApplProdSearchDO;
import com.medicare.mss.domainobject.EEMApplProductDO;
import com.medicare.mss.domainobject.EEMApplSearchDO;
import com.medicare.mss.domainobject.EEMApplStatusTrackDO;
import com.medicare.mss.domainobject.EEMApplTriggerDO;
import com.medicare.mss.domainobject.EEMApplicationDO;
import com.medicare.mss.domainobject.EEMBeqDO;
import com.medicare.mss.domainobject.EEMOriginalApplDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.ApplEligibilityRowMapper;
import com.medicare.mss.rowmappers.ApplLisRowMapper;
import com.medicare.mss.rowmappers.ApplPlanRowMapper;
import com.medicare.mss.rowmappers.ApplTriggerRowMapper;
import com.medicare.mss.rowmappers.ApplicationRowMapper;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.rowmappers.EEMOrigApplRowMapper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.util.PaginationQueryHelper;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.DataBaseField;
import com.medicare.mss.vo.DataBaseFieldVO;
import com.medicare.mss.vo.EEMApplAddressVO;
import com.medicare.mss.vo.EEMApplAgentVO;
import com.medicare.mss.vo.EEMApplCommentsVO;
import com.medicare.mss.vo.EEMApplEligibilityVO;
import com.medicare.mss.vo.EEMApplMasterVO;
import com.medicare.mss.vo.EEMApplOtherCovVO;
import com.medicare.mss.vo.EEMApplOtherPlanVO;
import com.medicare.mss.vo.EEMApplPlanVO;
import com.medicare.mss.vo.EEMApplSearchVO;
import com.medicare.mss.vo.EEMApplicationVO;
import com.medicare.mss.vo.EEMWFCommentVO;
import com.medicare.mss.vo.EmPreSetNoteVO;
import com.medicare.mss.vo.MBD;
import com.medicare.mss.vo.PageableVO;

/**
 * This class contains Application Persistence details.
 * 
 * @author Wipro
 *
 */
@Repository
public class EEMApplDAOImpl implements EEMApplDAO {

	private static final Logger LOGGER = LogManager.getLogger(EEMApplDAOImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	EEMCodeCache eemCodeCache;

	@Autowired
	EEMPersistence eemPer;

	@Autowired
	private EEMPopUpDAO eemPopUpDAO;

	@Autowired
	private EEMWfDAO workFlowDAO;
	
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Override
	public boolean isIncarcerated(String reqCovDt, String hicNbr, String mbi) throws ApplicationException {

		try {
			String sQuery = "SELECT COUNT(HIC_NBR) FROM INCARCERATION WHERE HIC_NBR IN (?,?) AND SDATE <= ? AND (EDATE >=? OR EDATE ='00000000' OR EDATE ='') ";
			String[] params = new String[] { hicNbr, mbi, reqCovDt, reqCovDt };
			int count = jdbcTemplate.queryForObject(sQuery, params, Integer.class);
			if (count > 0)
				return true;
			else
				return false;

		} catch (EmptyResultDataAccessException exp) {
			return false;
		} catch (DataAccessException e) {
			LOGGER.error(" EEMApplDAOImpl : isIncarcerated : {}", e.getMessage());
			throw new ApplicationException(e);
		}
	}

	@Override
	public boolean isUnlawfullyEligible(String reqCovDt, String hicNbr, String mbi) throws ApplicationException {

		try {
			String sQuery = "SELECT COUNT(HIC_NBR) FROM INELIGIBILITY WHERE HIC_NBR IN (?,?) AND SDATE <= ? AND (EDATE >=? OR EDATE ='00000000' OR EDATE ='') ";
			String[] params = new String[] { hicNbr, mbi, reqCovDt, reqCovDt };
			int count = jdbcTemplate.queryForObject(sQuery, params, Integer.class);
			if (count > 0)
				return true;
			else
				return false;

		} catch (EmptyResultDataAccessException exp) {
			return false;
		} catch (DataAccessException e) {
			LOGGER.error(" EEMApplDAOImpl : isUnlawfullyEligible : {}", e.getMessage());
			throw new ApplicationException(e);
		}
	}

	@Override
	public String validateEnrolledPcp(String customerId, String reqDtCov, String officeCd, String locationId)
			throws ApplicationException {

		String activeInd = "";
		try {
			String query = CommonUtils.buildQuery(" SELECT ACCEPT_NEW_PATIENT_IND FROM EM_MED_OFFICE ",
					" WHERE OFFICE_CD = ? AND OFFICE_CATEGORY_CD = 'PCP' AND LOCATION_ID = ? ",
					" AND CUSTOMER_ID = ? AND ? BETWEEN OFFICE_START_DATE AND OFFICE_END_DATE ",
					" ORDER BY OFFICE_START_DATE DESC FETCH FIRST ROW ONLY ");

			Object[] params = new Object[] { trimToEmpty(officeCd), trimToEmpty(locationId), trimToEmpty(customerId),
					DateFormatter.reFormat(reqDtCov, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD) };

			activeInd = jdbcTemplate.queryForObject(query, String.class, params);

		} catch (EmptyResultDataAccessException exp) {
			LOGGER.error(" EEMApplDAOImpl : validateEnrolledPcp : PCP NOT FOUND {}", exp.getMessage());
		} catch (DataAccessException exp) {
			LOGGER.error(" EEMApplDAOImpl : validateEnrolledPcp : {}", exp.getMessage());
			throw new ApplicationException("Error during Enrolled PCP check");
		}
		return activeInd;
	}

	@Override
	public boolean checkAgent(String customerId, String reqDtOfCov, EEMApplAgentDO eemApplAgentDO)
			throws ApplicationException {

		try {
			String query = CommonUtils.buildQuery(
					" SELECT COUNT(AGENT_ID) FROM EM_AGENCY_AGENT WHERE AGENT_ID = ? AND AGENCY_ID = ? ",
					" AND CUSTOMER_ID = ? AND ? BETWEEN EFF_START_DATE AND EFF_END_DATE ");

			String agencyId = eemApplAgentDO.getCommAgencyId() != null
					? trimToEmpty(eemApplAgentDO.getCommAgencyId().split("-")[0])
					: "";
			String[] params = new String[] { trimToEmpty(eemApplAgentDO.getBrokAgentId()), agencyId, customerId,
					DateFormatter.reFormat(reqDtOfCov, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD) };

			int count = jdbcTemplate.queryForObject(query, params, Integer.class);
			if (count > 0)
				return true;
			else
				return false;
		} catch (EmptyResultDataAccessException exp) {
			LOGGER.error(" EEMApplDAOImpl : checkAgent : Agent NOT FOUND {}", exp.getMessage());
			return false;
		} catch (DataAccessException e) {
			LOGGER.error(" EEMApplDAOImpl : checkAgent : {}", e.getMessage());
			throw new ApplicationException("Error during Enrolled Agent check");
		}
	}

	@Override
	public int checkInvalidAgency(EEMApplicationDO eemApplicationDO, EEMApplPlanDO eemApplPlanDO,
			EEMApplAgentDO eemApplAgentDO) throws ApplicationException {

		StringBuilder queryBuilder = null;
		try {
			queryBuilder = new StringBuilder().append(" SELECT COUNT(AGENT_ID) FROM EM_AGENCY_AGENT ")
					.append(" WHERE AGENCY_ID = ? AND CUSTOMER_ID = ? AND ? BETWEEN EFF_START_DATE AND EFF_END_DATE ");

			return jdbcTemplate.queryForObject(queryBuilder.toString(),
					new String[] {
							eemApplAgentDO.getCommAgencyId() != null
									? trimToEmpty(eemApplAgentDO.getCommAgencyId().split("-")[0])
									: "",
							trimToEmpty(eemApplicationDO.getCustomerId()), DateFormatter.reFormat(
									eemApplPlanDO.getReqDtCov(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD) },
					Integer.class);

		} catch (DataAccessException e) {
			LOGGER.error(" EEMApplDAOImpl : checkInvalidAgency : {}", e.getMessage());
			throw new ApplicationException("Error during Enrolled Agent check");
		}
	}

	@Override
	public int checkInvalidAgent(EEMApplicationDO eemApplicationDO, EEMApplPlanDO eemApplPlanDO,
			EEMApplAgentDO eemApplAgentDO) throws ApplicationException {

		StringBuilder queryBuilder = null;
		try {
			queryBuilder = new StringBuilder().append(" SELECT COUNT(AGENT_ID) FROM EM_AGENCY_AGENT ")
					.append(" WHERE AGENT_ID = ? AND CUSTOMER_ID = ? AND ? BETWEEN EFF_START_DATE AND EFF_END_DATE ");

			return jdbcTemplate.queryForObject(queryBuilder.toString(),
					new String[] { trimToEmpty(eemApplAgentDO.getBrokAgentId()),
							trimToEmpty(eemApplicationDO.getCustomerId()), DateFormatter.reFormat(
									eemApplPlanDO.getReqDtCov(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD) },
					Integer.class);

		} catch (DataAccessException e) {
			LOGGER.error(" EEMApplDAOImpl : checkInvalidAgent : {}", e.getMessage());
			throw new ApplicationException("Error during Enrolled Agent check");
		}
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<String[]> checkDuplicateEnrollment(EEMApplicationDO eemApplicationDO) throws ApplicationException {

		List lstAppl = new ArrayList();
		StringBuilder queryBuilder = null;
		List<Map<String, Object>> rows = null;
		try {
			queryBuilder = new StringBuilder()
					.append(" SELECT  A.PLAN_TYPE , A.PLAN_DESIGNATION , A.EFF_START_DATE,A.PLAN_ID,A.PBP_ID, ")
					.append(" A.PRODUCT_ID, A.GRP_ID, A.PBP_SEGMENT_ID FROM EM_MBR_ENROLLMENT A ")
					.append(" WHERE A.CUSTOMER_ID = ? AND A.MEMBER_ID = ( SELECT MEMBER_ID FROM EM_MBR_DSINFO WHERE CUSTOMER_ID  = ? ")
					.append(" AND DS_CD IN ('MED','MBI') AND DS_VALUE IN (?, ?) AND OVERRIDE_IND  = 'N' FETCH FIRST 1 ROW ONLY ) ")
					.append(" AND A.EFF_END_DATE = '99999999' AND A.OVERRIDE_IND = 'N' AND (A.ENROLL_STATUS NOT IN ('DAPRV','EOPOUT') ")
					.append(" OR (A.ENROLL_STATUS IN ('EPEND','EAPRV') AND A.ENROLL_REASON_CD <> 'CMSREJECT') ) ");

			rows = jdbcTemplate.queryForList(queryBuilder.toString(),
					new String[] { trimToEmpty(eemApplicationDO.getCustomerId()),
							trimToEmpty(eemApplicationDO.getCustomerId()),
							trimToEmpty(eemApplicationDO.getDisplayHic()), trimToEmpty(eemApplicationDO.getMbi()) });

			for (Map row : rows) {
				if (!trimToEmpty((String) row.get("PLAN_TYPE")).equals("")
						&& !trimToEmpty((String) row.get("PLAN_DESIGNATION")).equals("")) {
					String[] plan = new String[8];
					plan[0] = trimToEmpty((String) row.get("PLAN_TYPE"));
					plan[1] = trimToEmpty((String) row.get("PLAN_DESIGNATION"));
					plan[2] = trimToEmpty((String) row.get("EFF_START_DATE"));
					plan[3] = trimToEmpty((String) row.get("PLAN_ID"));
					plan[4] = trimToEmpty((String) row.get("PBP_ID"));
					plan[5] = trimToEmpty((String) row.get("PRODUCT_ID"));
					plan[6] = trimToEmpty((String) row.get("GRP_ID"));
					plan[7] = trimToEmpty((String) row.get("PBP_SEGMENT_ID"));
					lstAppl.add(plan);
				}
			}

		} catch (DataAccessException e) {
			LOGGER.error(" EEMApplDAOImpl : checkDuplicateEnrollment : {}", e.getMessage());
			throw new ApplicationException("Error during Duplicate Enrollment check");
		}
		return lstAppl;
	}

	@Override
	public List<EEMApplProductDO> getProdInGroup(EEMApplicationDO eemApplicationDO, EEMApplPlanDO eemApplPlanDO)
			throws ApplicationException {

		StringBuilder queryBuilder = null;
		List<Map<String, Object>> rows = null;
		List<EEMApplProductDO> lstProducts = new ArrayList<>();
		try {
			queryBuilder = new StringBuilder()
					.append(" SELECT CUSTOMER_ID, GRP_ID, PRODUCT_ID, GRP_PROD_START_DATE, PLAN_DESIGNATION ")
					.append(" FROM EM_GRP_PRODUCT WHERE CUSTOMER_ID = ? AND PRODUCT_ID = ? AND PBP_ID = ? AND PBP_SEGMENT_ID = ? AND ")
					.append(" ? BETWEEN GRP_PROD_START_DATE AND GRP_PROD_END_DATE ");

			String applType = trimToEmpty(eemApplicationDO.getApplType());

			if (applType.equals(EEMConstants.OPTION_APPLNEWMBR_MA) || applType.equals(EEMConstants.OPTION_CNTRCHG_MA))
				queryBuilder.append(" AND PLAN_DESIGNATION IN ('MA','CO','MAPD','COPD','PACE','MMP') ");
			else if (applType.equals(EEMConstants.OPTION_APPLNEWMBR_PD)
					|| applType.equals(EEMConstants.OPTION_CNTRCHG_PD))
				queryBuilder.append(" AND PLAN_DESIGNATION = 'PDP' ");

			rows = jdbcTemplate.queryForList(queryBuilder.toString(),
					new String[] { eemApplicationDO.getCustomerId(), eemApplPlanDO.getEnrollProduct(),
							eemApplPlanDO.getEnrollPbp(), eemApplPlanDO.getEnrollSegment(), DateFormatter.reFormat(
									eemApplPlanDO.getReqDtCov(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD) });

			for (Map row : rows) {
				EEMApplProductDO eemApplProductDO = new EEMApplProductDO();
				eemApplProductDO.setCustomerId(trimToEmpty((String) row.get("CUSTOMER_ID")));
				eemApplProductDO.setGroupId(trimToEmpty((String) row.get("GRP_ID")));
				eemApplProductDO.setProductId(trimToEmpty((String) row.get("PRODUCT_ID")));
				eemApplProductDO.setStartDt(trimToEmpty((String) row.get("GRP_PROD_START_DATE")));
				eemApplProductDO.setPlanDesignation(trimToEmpty((String) row.get("PLAN_DESIGNATION")));
				lstProducts.add(eemApplProductDO);
			}

		} catch (DataAccessException e) {
			LOGGER.error(" EEMApplDAOImpl : getProdInGroup : {}", e.getMessage());
			throw new ApplicationException(e);
		}
		return lstProducts;
	}

	@Override
	public boolean checkDuplSupplId(String customerId, String supplId, String memberId) {

		try {

			StringBuilder sql = CommonUtils.buildQueryBuilder("SELECT COUNT(SUPPLEMENTAL_ID) FROM EM_MBR_ENROLLMENT",
					"WHERE CUSTOMER_ID = ? AND SUPPLEMENTAL_ID = ? AND OVERRIDE_IND = 'N' ");
			List<String> params = new ArrayList<>();
			params.add(customerId);
			params.add(supplId);

			if (!trimToEmpty(memberId).equals("")) {
				sql.append(" AND MEMBER_ID != ? ");
				params.add(memberId);
			}
			sql.append(" FETCH FIRST 1 ROWS ONLY ");
			int count = jdbcTemplate.queryForObject(sql.toString(), params.toArray(), Integer.class);
			if (count > 0)
				return true;
			else
				return false;
		} catch (EmptyResultDataAccessException exp) {
			return false;

		} catch (DataAccessException e) {
			LOGGER.error(" EEMApplDAOImpl : checkDuplSupplId : {}", e.getMessage());
			throw new ApplicationException(e);
		}
	}

	@Override
	public List<String[]> checkDuplicateApplication(EEMApplicationDO eemApplicationDO, String customerNumber)
			throws ApplicationException {

		boolean foundDup = false;
		StringBuilder queryBuilder1 = null;
		StringBuilder queryBuilder2 = null;
		List<Map<String, Object>> rows1 = null;
		List<Map<String, Object>> rows2 = null;
		List<String[]> lstAppl = new ArrayList<String[]>();
		try {
			queryBuilder1 = new StringBuilder()
					.append(" SELECT A.APPLICATION_ID, C.PLAN_TYPE, C.PLAN_DESIGNATION, B.TO_PLAN_ID, B.TO_PBP_ID ")
					.append(" FROM EM_APPLICATION A, EM_APPL_PLAN B, PLANPBP C ")
					.append(" WHERE A.CUSTOMER_ID = B.CUSTOMER_ID AND A.APPLICATION_ID = B.APPLICATION_ID AND C.CUST_NBR = ? ")
					.append(" AND C.PLAN_ID = B.TO_PLAN_ID AND C.PBP_ID = B.TO_PBP_ID AND A.CUSTOMER_ID = ? AND A.HIC_NBR = ? ")
					.append(" AND A.APPLICATION_STATUS NOT IN ('COMPLETED','CANCELED','DENIEDELG','DENIEDETYP','DENIEDOTHR','RFINORESP') ")
					.append(" AND A.APPLICATION_TYPE = ? ");

			if (eemApplicationDO.getApplId() > 0) {

				queryBuilder1.append(" AND A.APPLICATION_ID != ? ");
				rows1 = jdbcTemplate.queryForList(queryBuilder1.toString(), new Object[] { trimToEmpty(customerNumber),
						trimToEmpty(eemApplicationDO.getCustomerId()), trimToEmpty(eemApplicationDO.getDisplayHic()),
						trimToEmpty(eemApplicationDO.getApplType()), String.valueOf(eemApplicationDO.getApplId()) });
			} else {
				rows1 = jdbcTemplate.queryForList(queryBuilder1.toString(),
						new Object[] { trimToEmpty(customerNumber), trimToEmpty(eemApplicationDO.getCustomerId()),
								trimToEmpty(eemApplicationDO.getDisplayHic()),
								trimToEmpty(eemApplicationDO.getApplType()) });
			}
			for (Map row1 : rows1) {
				foundDup = true;
				String[] plan = new String[5];
				plan[0] = trimToEmpty((String) row1.get("PLAN_TYPE"));
				plan[1] = trimToEmpty((String) row1.get("PLAN_DESIGNATION"));
				plan[2] = trimToEmpty(String.valueOf(row1.get("APPLICATION_ID")));
				plan[3] = trimToEmpty((String) row1.get("TO_PLAN_ID"));
				plan[4] = trimToEmpty((String) row1.get("TO_PBP_ID"));
				lstAppl.add(plan);
			}

			if (!foundDup && !trimToEmpty(eemApplicationDO.getMbi()).equals("")) {
				queryBuilder2 = new StringBuilder()
						.append(" SELECT A.APPLICATION_ID, C.PLAN_TYPE, C.PLAN_DESIGNATION, B.TO_PLAN_ID, B.TO_PBP_ID ")
						.append("FROM EM_APPLICATION A, EM_APPL_PLAN B, PLANPBP C ")
						.append(" WHERE A.CUSTOMER_ID = B.CUSTOMER_ID AND A.APPLICATION_ID = B.APPLICATION_ID AND C.CUST_NBR = ? ")
						.append(" AND C.PLAN_ID = B.TO_PLAN_ID AND C.PBP_ID = B.TO_PBP_ID AND A.CUSTOMER_ID = ? AND A.MBI = ?  ")
						.append(" AND A.APPLICATION_STATUS NOT IN ('COMPLETED','CANCELED','DENIEDELG','DENIEDETYP','DENIEDOTHR','RFINORESP') ")
						.append(" AND A.APPLICATION_TYPE = ? ");

				if (eemApplicationDO.getApplId() > 0) {

					queryBuilder2.append(" AND A.APPLICATION_ID != ? ");
					rows2 = jdbcTemplate.queryForList(queryBuilder2.toString(),
							new Object[] { trimToEmpty(customerNumber), trimToEmpty(eemApplicationDO.getCustomerId()),
									trimToEmpty(eemApplicationDO.getMbi()), trimToEmpty(eemApplicationDO.getApplType()),
									String.valueOf(eemApplicationDO.getApplId()) });
				} else {
					rows2 = jdbcTemplate.queryForList(queryBuilder2.toString(),
							new Object[] { trimToEmpty(customerNumber), trimToEmpty(eemApplicationDO.getCustomerId()),
									trimToEmpty(eemApplicationDO.getMbi()),
									trimToEmpty(eemApplicationDO.getApplType()) });
				}
				for (Map row2 : rows2) {
					foundDup = true;
					String[] plan = new String[5];
					plan[0] = trimToEmpty((String) row2.get("PLAN_TYPE"));
					plan[1] = trimToEmpty((String) row2.get("PLAN_DESIGNATION"));
					plan[2] = trimToEmpty(String.valueOf(row2.get("APPLICATION_ID")));
					plan[3] = trimToEmpty((String) row2.get("TO_PLAN_ID"));
					plan[4] = trimToEmpty((String) row2.get("TO_PBP_ID"));
					lstAppl.add(plan);
				}
			}

		} catch (DataAccessException e) {
			LOGGER.error(" EEMApplDAOImpl : checkDuplicateApplication : {}", e.getMessage());
			throw new ApplicationException("Error during Duplicate Application check.");
		}
		return lstAppl;
	}

	@Override
	public boolean getMemberDetails(EEMApplicationDO eemApplicationDO, EEMApplPlanDO eemApplPlanDO,
			EEMApplOtherCovDO eemApplOtherCovDO, String planDesgn) throws ApplicationException {

		boolean result = false;
		StringBuilder queryBuilder1 = null;
		StringBuilder queryBuilder2 = null;
		String memberId = "";
		try {

			queryBuilder1 = new StringBuilder().append(
					" SELECT MEMBER_ID FROM EM_MBR_DSINFO where CUSTOMER_ID = ? AND DS_CD IN ('MED','MBI') AND DS_VALUE IN( ?,?) ")
					.append(" AND OVERRIDE_IND = 'N' FETCH FIRST ROW ONLY ");

			queryBuilder2 = new StringBuilder().append(
					" SELECT A.MEMBER_ID, LAST_NAME, FIRST_NAME, MIDDLE_INITIAL, PREFIX, MAIL_LAST_NAME, MAIL_FIRST_NAME, ")
					.append(" MAIL_MIDDLE_INIT, INS_CARD_NAME, SSN, BIRTH_DATE, GENDER_CD, MBR_EMAIL, AUTH_FIRST_NAME, AUTH_MIDDLE_INIT, ")
					.append(" AUTH_LAST_NAME, AUTH_RELATIONSHIP_CD, EMERGCY_NAME, EMERGCY_PHONE, EMERGCY_RELATIONSHIP_CD, EMERGCY_EMAIL, ")
					.append(" LANGUAGE_CD, SPOUSE_WORK_IND, PRODUCT_ID, GRP_ID, SUPPLEMENTAL_ID, PLAN_ID, PBP_ID, PBP_SEGMENT_ID, ")
					.append(" PLAN_DESIGNATION, ELECTION_TYPE_CD, SEP_ELECTION_DATE, RX_ID, SEC_RX_GRP, SEC_RX_NAME, SEC_RX_ID, ")
					.append(" ENROLL_SRCE_CD, SEC_RX_BIN, SEC_RX_PCN, B.EFF_END_DATE, DS_VALUE ")
					.append(" FROM EM_MBR_DEMOGRAPHIC A INNER JOIN EM_MBR_ENROLLMENT B ")
					.append(" ON A.CUSTOMER_ID = B.CUSTOMER_ID AND A.MEMBER_ID = B.MEMBER_ID ")
					.append(" JOIN EM_MBR_DSINFO C ON C.CUSTOMER_ID = B.CUSTOMER_ID AND C.MEMBER_ID = B.MEMBER_ID ")
					.append(" WHERE  A.CUSTOMER_ID = ? AND A.MEMBER_ID = ? AND A.CURRENT_IND = 'Y' AND A.OVERRIDE_IND = 'N' AND ")
					.append(" B.OVERRIDE_IND = 'N' AND B.ENROLL_STATUS NOT IN ('DAPRV ','ECAPRV','EDENY','EOPOUT','EREJT') AND ")
					.append(" B.EFF_END_DATE = '99999999' AND C.OVERRIDE_IND = 'N' AND DS_CD = 'PWO' AND ")
					.append(" C.EFF_END_DATE = '99999999'  ");

			memberId = jdbcTemplate.queryForObject(queryBuilder1.toString(), new Object[] {
					eemApplicationDO.getCustomerId(), eemApplicationDO.getDisplayHic(), eemApplicationDO.getMbi() },
					String.class);
			memberId = trimToEmpty(memberId);
			Object[] params = new Object[] { eemApplicationDO.getCustomerId(), memberId };
			if (null != memberId && !"".equalsIgnoreCase(memberId)) {
				if (!trimToEmpty(planDesgn).equals("")) {
					queryBuilder2.append(" AND B.PLAN_DESIGNATION = ? ");
					params = new Object[] { eemApplicationDO.getCustomerId(), memberId, planDesgn };
				}
				result = jdbcTemplate.query(queryBuilder2.toString(), params, new ResultSetExtractor<Boolean>() {

					@Override
					public Boolean extractData(ResultSet row2) throws SQLException, DataAccessException {
						boolean flag = false;
						if (row2.next()) {
							flag = true;
							eemApplicationDO.setMbrId(trimToEmpty(row2.getString("MEMBER_ID")));
							eemApplicationDO.setMbrLastName(trimToEmpty(row2.getString("LAST_NAME")));
							eemApplicationDO.setMbrFirstName(trimToEmpty(row2.getString("FIRST_NAME")));
							eemApplicationDO.setMbrMiddleName(trimToEmpty(row2.getString("MIDDLE_INITIAL")));
							eemApplicationDO.setMbrPrefix(trimToEmpty(row2.getString("PREFIX")));
							eemApplicationDO.setMailLastName(trimToEmpty(row2.getString("MAIL_LAST_NAME")));
							eemApplicationDO.setMailFirstName(trimToEmpty(row2.getString("MAIL_FIRST_NAME")));
							eemApplicationDO.setMailMiddleName(trimToEmpty(row2.getString("MAIL_MIDDLE_INIT")));
							eemApplicationDO.setInsCardName(trimToEmpty(row2.getString("INS_CARD_NAME")));
							eemApplicationDO.setMbrSsn(trimToEmpty(row2.getString("SSN")));
							eemApplicationDO
									.setMbrBirthDt(DateUtil.formatMmDdYyyy(trimToEmpty(row2.getString("BIRTH_DATE"))));
							eemApplicationDO.setMbrGender(trimToEmpty(row2.getString("GENDER_CD")));
							eemApplicationDO.setMbrEmail(trimToEmpty(row2.getString("MBR_EMAIL")));
							eemApplicationDO.setAuthRepFirstName(trimToEmpty(row2.getString("AUTH_FIRST_NAME")));
							eemApplicationDO.setAuthRepMidName(trimToEmpty(row2.getString("AUTH_MIDDLE_INIT")));
							eemApplicationDO.setAuthRepLastName(trimToEmpty(row2.getString("AUTH_LAST_NAME")));
							eemApplicationDO.setAuthRepRelation(trimToEmpty(row2.getString("AUTH_RELATIONSHIP_CD")));
							eemApplicationDO.setEmergName(trimToEmpty(row2.getString("EMERGCY_NAME")));
							eemApplicationDO.setEmergPhone(trimToEmpty(row2.getString("EMERGCY_PHONE")));
							eemApplicationDO.setEmergRelation(trimToEmpty(row2.getString("EMERGCY_RELATIONSHIP_CD")));
							eemApplicationDO.setEmergEmail(trimToEmpty(row2.getString("EMERGCY_EMAIL")));
							eemApplicationDO.setLanguage(trimToEmpty(row2.getString("LANGUAGE_CD")));
							eemApplOtherCovDO.setSpouseWork(trimToEmpty(row2.getString("SPOUSE_WORK_IND")));
							eemApplPlanDO.setCurrProductId(trimToEmpty(row2.getString("PRODUCT_ID")));
							eemApplPlanDO.setCurrGrpId(trimToEmpty(row2.getString("GRP_ID")));
							eemApplicationDO.setAltMbrId(trimToEmpty(row2.getString("SUPPLEMENTAL_ID")));
							eemApplPlanDO.setCurrPlanId(trimToEmpty(row2.getString("PLAN_ID")));
							eemApplPlanDO.setCurrPbpId(trimToEmpty(row2.getString("PBP_ID")));
							eemApplPlanDO.setCurrPbpSegmentId(trimToEmpty(row2.getString("PBP_SEGMENT_ID")));
							eemApplPlanDO.setCurrPlanDesignation(trimToEmpty(row2.getString("PLAN_DESIGNATION")));
							eemApplPlanDO.setElectionType(trimToEmpty(row2.getString("ELECTION_TYPE_CD")));
							eemApplPlanDO.setSepElectionDt(
									DateUtil.formatMmDdYyyy(trimToEmpty(row2.getString("SEP_ELECTION_DATE"))));
							eemApplicationDO.setMbrRxId(trimToEmpty(row2.getString("RX_ID")));
							eemApplOtherCovDO.setGroupNo(trimToEmpty(row2.getString("SEC_RX_GRP")));
							eemApplOtherCovDO.setOtherCov(trimToEmpty(row2.getString("SEC_RX_NAME")));
							eemApplOtherCovDO.setCovId(trimToEmpty(row2.getString("SEC_RX_ID")));
							eemApplicationDO.setEnrollSrceCd(trimToEmpty(row2.getString("ENROLL_SRCE_CD")));
							eemApplOtherCovDO.setCovBin(trimToEmpty(row2.getString("SEC_RX_BIN")));
							eemApplOtherCovDO.setCovPcn(trimToEmpty(row2.getString("SEC_RX_PCN")));

							eemApplPlanDO.setEffEndDate(trimToEmpty(row2.getString("EFF_END_DATE")));
							eemApplicationDO.setPwOption(trimToEmpty(row2.getString("DS_VALUE")));
						}

						return flag;
					}
				}

				);

			}

		} catch (EmptyResultDataAccessException exp) {
			return result;
		} catch (DataAccessException e) {
			LOGGER.error(" EEMApplDAOImpl : getMemberDetails : {}", e.getMessage());
			throw new ApplicationException(e);
		}
		return result;
	}

	/*
	 * public List<EEMApplProductDO> getProducts( EEMApplicationDO eemApplicationDO,
	 * EEMApplAddressDO eemApplAddressDO, EEMApplPlanDO eemApplPlanDO) throws
	 * ApplicationException {
	 */
	@Override
	public List<EEMApplProductDO> getProducts(EEMApplProdSearchDO prodSearchDO, EEMApplPlanDO eemApplPlanDO)
			throws ApplicationException {

		List<EEMApplProductDO> lstProducts = null;
		Map<String, String> searchParamMap = new HashMap<>();

		try {
			/*
			 * String ssaSt = eemApplAddressDO.getStateCd(); String ssaCnty =
			 * eemApplAddressDO.getCountyCd(); String zip4 = eemApplAddressDO.getZip4Cd();
			 * String zip5 = trimToEmpty(eemApplAddressDO.getZipCd());
			 */
			/*
			 * if (!trimToEmpty(eemApplicationDO.getOutOfArea()).equals("E")) {
			 */

			String zip4 = prodSearchDO.getZip4();
			zip4 = (zip4 == null || zip4.trim().equals("")) ? "0000" : zip4.trim();

			searchParamMap.put("covDt", eemApplPlanDO.getReqDtCov());
			searchParamMap.put("prod", prodSearchDO.getEnrollProdName());
			searchParamMap.put("group", prodSearchDO.getEnrollGroupName());
			searchParamMap.put("groupId", eemApplPlanDO.getEnrollGrpId());
			searchParamMap.put("prodId", eemApplPlanDO.getEnrollProduct());
			searchParamMap.put("zip5", prodSearchDO.getZip5());
			searchParamMap.put("zip4", zip4);
			searchParamMap.put("plan", eemApplPlanDO.getEnrollPlan());
			searchParamMap.put("pbp", eemApplPlanDO.getEnrollPbp());
			searchParamMap.put("segment", eemApplPlanDO.getEnrollSegment());
			searchParamMap.put("PerState", prodSearchDO.getSsaSt());
			searchParamMap.put("PerCounty", prodSearchDO.getSsaCnty());
			searchParamMap.put("applType", prodSearchDO.getApplType());
			// searchParamMap.put("OutOfArea", null);
			searchParamMap.put("OutOfArea", prodSearchDO.getOutOfArea());

			lstProducts = eemPopUpDAO.getApplProducts(searchParamMap, prodSearchDO.getCustomerId());
			// }

		} catch (DataAccessException e) {
			LOGGER.error(" EEMApplDAOImpl : getProducts : {}", e.getMessage());
			throw new ApplicationException(e);
		}
		return lstProducts;
	}

	@Override
	public EEMApplTriggerDO getApplTriggerForFunc(int applId, String customerId) throws ApplicationException {
		StringBuilder queryBuilder = null;
		try {
			queryBuilder = new StringBuilder().append(
					" SELECT AT.CUSTOMER_ID, AT.APPLICATION_ID, AT.TRIGGER_TYPE, AT.EFFECTIVE_DATE, AT.CREATE_TIME,")
					.append(" AT.TRIGGER_STATUS, AT.TRIGGER_CODE, AT.ORIG_TRIGGER_TYPE, AT.ORIG_TRIGGER_CODE, AT.ORIG_EFFECTIVE_DATE, ")
					.append(" AT.ORIG_TRIGGER_CREATE_TIME, AT.CREATE_USERID, AT.LAST_UPDT_TIME, AT.LAST_UPDT_USERID ")
					.append(" FROM EM_APPL_TRIGGER AT JOIN EM_FUNCTION_CORR_INDEX FI ")
					.append(" ON FI.CUSTOMER_ID = AT.CUSTOMER_ID AND FI.FUNCTION_TYPE = ? AND FI.TRIGGER_CODE = AT.TRIGGER_CODE ")
					.append(" WHERE AT.CUSTOMER_ID = ? AND AT.APPLICATION_ID = ? ORDER BY AT.CREATE_TIME DESC FETCH FIRST 1 ROWS ONLY ");

			return jdbcTemplate.queryForObject(queryBuilder.toString(), new ApplTriggerRowMapper(),
					new String[] { EEMConstants.TRIG_FUNC_RFI_ENRL, customerId, Integer.toString(applId) });

		} catch (EmptyResultDataAccessException exp) {
			return null;

		} catch (DataAccessException e) {
			LOGGER.error(" EEMApplDAOImpl : getApplTriggerForFunc : {}", e.getMessage());
			throw new ApplicationException(e);
		}
	}

	@Override
	public String getCounty(String zip5, String zip4) throws ApplicationException {
		// String zip5 = null;
		// String zip4 = null;
		StringBuilder queryBuilder = null;
		try {
			/*
			 * String zip = eemApplAddressVO.getZipCd(); String zip5 =
			 * trimToEmpty(applicationVO.getPerZip5()); String zip4 =
			 * trimToEmpty(applicationVO.getPerZip4()).equals("") ? "0000" :
			 * trimToEmpty(applicationVO.getPerZip4()); if (zip.length() == 9) { zip5 =
			 * zip.substring(0,5); zip4 = zip.substring(5,9); } else { if (zip.length() ==
			 * 5) { zip5 = zip; zip4 = "0000"; } }
			 */
			queryBuilder = new StringBuilder().append(
					" SELECT COUNTY_NAME FROM EM_ZIPCODE A, COUNTY B WHERE B.STATE_CD = A.SSA_ST AND B.COUNTY_CD = A.SSA_CNTY ")
					.append(" AND A.ZIP_CD5 = ? AND A.ZIP_CD4 in ('0000', ?) ORDER BY ZIP_CD4 DESC FETCH FIRST ROW ONLY ");

			String countyName = jdbcTemplate.queryForObject(queryBuilder.toString(),
					new String[] { trimToEmpty(zip5), trimToEmpty(zip4).equals("") ? "0000" : trimToEmpty(zip4) },
					String.class);
			return trimToEmpty(countyName);
		} catch (EmptyResultDataAccessException exp) {
			return "";

		} catch (DataAccessException e) {
			LOGGER.error(" EEMApplDAOImpl : getCounty : {}", e.getMessage());
			throw new ApplicationException(e);
		}
	}

	@Override
	public String[] getCityName(EEMApplAddressVO eemApplAddressVO, EEMApplFieldErrorDO fieldVO)
			throws ApplicationException {

		String zip5 = null;
		String zip4 = null;

		String[] city = null;
		StringBuilder queryBuilder = null;
		List<Map<String, Object>> rows = null;
		HashMap<String, String> hmp = new HashMap<String, String>();

		// String zip5 = trimToEmpty(eemApplAddressVO.getPerZip5());
		// String zip4 = trimToEmpty(eemApplAddressVO.getPerZip4());

		try {
			String formField = fieldVO.getFormField();
			if ("perCity".equals(formField) || "perState".equals(formField)) {
				zip5 = trimToEmpty(eemApplAddressVO.getPerZip5());
				zip4 = trimToEmpty(eemApplAddressVO.getPerZip4());
			} else {
				if ("mailCity".equals(formField) || "mailState".equals(formField)) {
					zip5 = trimToEmpty(eemApplAddressVO.getMailZip5());
					zip4 = trimToEmpty(eemApplAddressVO.getMailZip4());
				} else {
					if ("authRepCity".equals(formField) || "authRepState".equals(formField)) {
						zip5 = trimToEmpty(eemApplAddressVO.getAuthRepZip5());
						zip4 = trimToEmpty(eemApplAddressVO.getAuthRepZip4());
					}
				}
			}
			if (zip5.equals(""))
				return city;

			queryBuilder = new StringBuilder().append(
					" SELECT CITY_NAME, STATE_CD, ZIP_CD5, ZIP_CD4 FROM EM_ZIPCODE WHERE RTRIM(CITY_NAME) != '' AND ZIP_CD5 = ? ")
					.append(zip4.equals("") ? " AND ZIP_CD4 NOT IN ('9999') " : " AND ZIP_CD4 IN (?) ")
					.append(" ORDER BY CITY_NAME ");

			rows = !zip4.equals("") ? jdbcTemplate.queryForList(queryBuilder.toString(), new String[] { zip5, zip4 })
					: jdbcTemplate.queryForList(queryBuilder.toString(), new String[] { zip5 });

			for (Map row : rows)
				hmp.put(trimToEmpty((String) row.get("CITY_NAME")), trimToEmpty((String) row.get("STATE_CD")) + "|"
						+ trimToEmpty((String) row.get("ZIP_CD5")) + "|" + trimToEmpty((String) row.get("ZIP_CD4")));

			if (hmp.size() > 0) {
				city = new String[hmp.size()];
				Set set = hmp.keySet();
				Iterator it = set.iterator();
				int i = 0;
				while (it.hasNext()) {
					String key = (String) it.next();
					city[i++] = key + "|" + hmp.get(key);
				}
			}
		} catch (DataAccessException e) {
			LOGGER.error(" EEMApplDAOImpl : getCityName : {}", e.getMessage());
			throw new ApplicationException(e);
		}
		return city;
	}

	@Override
	public boolean checkZip(String zip) throws ApplicationException {

		try {
			int count = jdbcTemplate.queryForObject(" SELECT COUNT(ZIP_CD5) FROM EM_ZIPCODE WHERE ZIP_CD5 = ? ",
					new String[] { zip }, Integer.class);
			if (count > 0)
				return true;
			else
				return false;

		} catch (DataAccessException e) {
			LOGGER.error(" EEMApplDAOImpl : checkZip : {}", e.getMessage());
			throw new ApplicationException(e);
		}
	}

	@Override
	public boolean isDUALSEPElectionTypeLAlreadyUsed(String custID, String memberId, String electionType,
			String enrollStatus, String date1, String date2) throws ApplicationException {

		StringBuilder queryBuilder = null;
		try {
			if (!trimToEmpty(memberId).equals("")) {

				queryBuilder = new StringBuilder().append(
						" SELECT COUNT(MEMBER_ID) FROM EM_MBR_ENROLLMENT WHERE CUSTOMER_ID = ?  AND OVERRIDE_IND = 'N' ")
						.append(" AND MEMBER_ID = ? AND ELECTION_TYPE_CD = ? AND ENROLL_STATUS = ? AND ")
						.append(" ENROLL_REASON_CD = 'CMSAPRV' AND EFF_START_DATE BETWEEN ? AND ? ");

				int count = jdbcTemplate.queryForObject(queryBuilder.toString(),
						new String[] { custID, memberId, electionType, enrollStatus, date1, date2 }, Integer.class);
				if (count > 0)
					return true;
			}
		} catch (DataAccessException e) {
			LOGGER.error(" EEMApplDAOImpl : isDUALSEPElectionTypeLAlreadyUsed : {}", e.getMessage());
			throw new ApplicationException(e);
		}
		return false;
	}

	@Override
	public String getEarliestEnrlStDt(String custID, String memberId) throws ApplicationException {
		String effDate = "";
		try {
			if (!trimToEmpty(memberId).equals("")) {

				StringBuilder queryBuilder = new StringBuilder().append(
						" SELECT EFF_START_DATE FROM EM_MBR_ENROLLMENT WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? ")
						.append(" AND ENROLL_STATUS = 'EAPRV' AND ENROLL_REASON_CD = 'CMSAPRV' AND OVERRIDE_IND = 'N' ORDER BY EFF_START_DATE FETCH FIRST ROW ONLY ");

				effDate = jdbcTemplate.queryForObject(queryBuilder.toString(), String.class, custID, memberId);

			}
		} catch (EmptyResultDataAccessException exp) {
			LOGGER.error(" EEMApplDAOImpl : getEarliestEnrlStDt : Eff date not Found {}", exp.getMessage());
		} catch (DataAccessException exp) {
			LOGGER.error(" EEMApplDAOImpl : getEarliestEnrlStDt : {}", exp.getMessage());
			throw new ApplicationException(exp);
		}
		return effDate;
	}

	@Override
	public boolean validateBrkInCov(String custID, String memberId, String date, String reqDtOfCov)
			throws ApplicationException {

		StringBuilder queryBuilder = null;
		try {
			if (!trimToEmpty(memberId).equals("")) {

				queryBuilder = new StringBuilder().append(
						" SELECT COUNT(MEMBER_ID) FROM EM_MBR_ENROLLMENT WHERE CUSTOMER_ID = ?  AND OVERRIDE_IND = 'N' ")
						.append(" AND MEMBER_ID = ? AND ENROLL_STATUS = 'DAPRV' AND ENROLL_REASON_CD = 'CMSAPRV' AND EFF_END_DATE > ? AND EFF_START_DATE < ? ");

				int count = jdbcTemplate.queryForObject(queryBuilder.toString(),
						new String[] { custID, memberId, date, reqDtOfCov }, Integer.class);
				if (count > 0)
					return true;
			}

		} catch (DataAccessException e) {
			LOGGER.error(" EEMApplDAOImpl : validateBrkInCov : {}", e.getMessage());
			throw new ApplicationException(e);
		}
		return false;
	}

	@Override
	public boolean isElectionTypeAlreadyUsed(String custID, String memberId, String electionType, String enrollStatus,
			String date1, String date2) throws ApplicationException {

		StringBuilder queryBuilder = null;
		try {
			if (!trimToEmpty(memberId).equals("")) {

				queryBuilder = new StringBuilder().append(
						" SELECT COUNT(MEMBER_ID) FROM EM_MBR_ENROLLMENT WHERE CUSTOMER_ID = ?  AND OVERRIDE_IND = 'N' AND ")
						.append(" MEMBER_ID = ? AND ELECTION_TYPE_CD = ? AND ENROLL_STATUS = ? AND ENROLL_REASON_CD = 'CMSAPRV' ")
						.append(" AND EFF_END_DATE > ? AND EFF_START_DATE < ? ");

				int count = jdbcTemplate.queryForObject(queryBuilder.toString(),
						new String[] { custID, memberId, electionType, enrollStatus, date1, date2 }, Integer.class);
				if (count > 0)
					return true;
			}

		} catch (DataAccessException e) {
			LOGGER.error(" EEMApplDAOImpl : isElectionTypeAlreadyUsed : {}", e.getMessage());
			throw new ApplicationException(e);
		}
		return false;
	}

	@Override
	public boolean isMAOEPElectionTypeAlreadyUsed(String custID, String memberId, String date1, String date2)
			throws ApplicationException {

		StringBuilder queryBuilder = null;
		try {
			if (!trimToEmpty(memberId).equals("")) {

				queryBuilder = new StringBuilder().append(
						" SELECT COUNT(MEMBER_ID) FROM EM_MBR_ENROLLMENT WHERE CUSTOMER_ID = ?  AND OVERRIDE_IND = 'N' ")
						.append(" AND MEMBER_ID = ? AND ELECTION_TYPE_CD = 'M' AND ENROLL_STATUS IN('EAPRV','DAPRV') AND ")
						.append(" ENROLL_REASON_CD = 'CMSAPRV' AND EFF_END_DATE > ? AND EFF_START_DATE < ? ");

				int count = jdbcTemplate.queryForObject(queryBuilder.toString(),
						new String[] { custID, memberId, date1, date2 }, Integer.class);
				if (count > 0)
					return true;
			}

		} catch (DataAccessException e) {
			LOGGER.error(" EEMApplDAOImpl : isMAOEPElectionTypeAlreadyUsed : {}", e.getMessage());
			throw new ApplicationException(e);
		}
		return false;
	}

	/*
	 * public String[] getPlanType(String planId, String pbpId, String
	 * customerNumber) throws ApplicationException {
	 * 
	 * String[] planType = null; List<Map<String, Object>> rows = null; try { rows =
	 * jdbcTemplate.queryForList(
	 * "SELECT PLAN_TYPE, PLAN_DESIGNATION FROM PLANPBP WHERE CUST_NBR = ? AND PLAN_ID = ? AND PBP_ID = ? "
	 * , new String[] { trimToEmpty(customerNumber), trimToEmpty(planId),
	 * trimToEmpty(pbpId) } ); for(Map row : rows) { planType = new String[2];
	 * planType[0] = trimToEmpty((String) row.get("PLAN_TYPE")); planType[1] =
	 * trimToEmpty((String) row.get("PLAN_DESIGNATION")); }
	 * 
	 * } catch (DataAccessException e) {
	 * LOGGER.error(" EEMApplDAOImpl : getPlanType : " + e.getMessage()); throw new
	 * ApplicationException(e); } return planType; }
	 */

	@Override
	public String getEnrollMemberId(String custId, String hicNbr, String mbiNbr) throws ApplicationException {
		/*
		 * PreparedStatement ps = null; ResultSet rs = null; int index = 0; String
		 * mbrIdSQL = "SELECT MEMBER_ID" + " FROM EM_MBR_DSINFO" +
		 * " WHERE CUSTOMER_ID  = ?" +
		 * " AND DS_CD IN ('MED','MBI') AND DS_VALUE IN (?,?)" +
		 * " AND OVERRIDE_IND  = 'N' FETCH FIRST 1 ROW ONLY"; try { ps =
		 * conn.prepareStatement(mbrIdSQL); ps.setString(++index, trimToEmpty(custId));
		 * ps.setString(++index, trimToEmpty(hicNbr)); ps.setString(++index,
		 * trimToEmpty(mbiNbr)); rs = ps.executeQuery(); while (rs.next()) return
		 * trimToEmpty(rs.getString("MEMBER_ID"));
		 * 
		 * } catch (SQLException e) { e.printStackTrace(); }catch (DataAccessException
		 * e){ e.printStackTrace(); }
		 */
		return null;
	}

	private DataBaseFieldVO getField(String value) {
		DataBaseFieldVO dbField = new DataBaseFieldVO();
		dbField.setStringValue(value);
		return dbField;
	}

	public String[] convertToStringArray(Vector lstParams) throws SQLException {
		String[] arrParams = null;
		if (lstParams.size() > 0) {

			arrParams = new String[lstParams.size()];
			for (int i = 0; i < lstParams.size(); i++) {
				DataBaseFieldVO dbField = (DataBaseFieldVO) lstParams.get(i);
				if (dbField.isInteger()) {
					arrParams[i] = String.valueOf(dbField.getIntValue());
				} else if (dbField.isDouble()) {
					arrParams[i] = String.valueOf(dbField.getDoubleValue());
				} else if (dbField.isLong()) {
					arrParams[i] = String.valueOf(dbField.getLongValue());
				} else {
					arrParams[i] = dbField.getStringValue();
				}
			}
		}
		return arrParams;
	}

	// END: Application Validation

	@Override
	public PageableVO getApplSearchDetails(String customerId, Map<String, String> searchParamMap,
			boolean isPagination) {
		try {

			PageableVO response = new PageableVO();
			String searchHic = trimToEmpty(searchParamMap.get("hicNbr"));
			String searchLastName = trimToEmpty(searchParamMap.get("lastName"));
			String searchBirthDate = DateFormatter.reFormat(trimToEmpty(searchParamMap.get("DOB")),
					DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
			String searchApplId = trimToEmpty(searchParamMap.get("applId"));
			String searchStatus = trimToEmpty(searchParamMap.get("searchStatus"));
			String isHicOrMbi = StringUtil.isHicOrMbi(trimToEmpty(searchHic));
			String medIdString = null;
			String searchFirstName = trimToEmpty(searchParamMap.get("firstName"));

			StringBuilder sql = new StringBuilder();

			sql.append("SELECT DISTINCT A.CUSTOMER_ID, A.APPLICATION_ID,")
					.append(" (CASE WHEN A.MBI !='' THEN A.MBI ELSE A.HIC_NBR END) AS MEDICARE_ID, ")
					.append(" (TRIM(A.FIRST_NAME) CONCAT SPACE(1) CONCAT TRIM(A.LAST_NAME)) AS FULL_NAME, A.BIRTH_DATE,")
					.append(" PN.PRODUCT_NAME").append(" FROM EM_APPLICATION A")
					.append(" LEFT JOIN EM_APPL_PLAN  AP  ON  AP.CUSTOMER_ID  = A.CUSTOMER_ID  AND  AP.APPLICATION_ID = A.APPLICATION_ID ")
					.append(" LEFT JOIN EM_PRODUCT_NAME PN ON PN.CUSTOMER_ID = AP.CUSTOMER_ID AND PN.PRODUCT_ID = AP.TO_PRODUCT_ID ")
					.append(" AND AP.EFFECTIVE_DATE BETWEEN PN.PRODNAME_START_DATE AND PN.PRODNAME_END_DATE ")
					.append(" WHERE A.CUSTOMER_ID = ?");

			if (!trimToEmpty(isHicOrMbi).equals("")) {
				if (isHicOrMbi.equalsIgnoreCase("hic"))
					medIdString = "A.HIC_NBR";
				else
					medIdString = "A.MBI";
			}
			ArrayList<String> parmList = new ArrayList<>();
			parmList.add(customerId);

			if (!searchHic.equals("")) {
				if (!trimToEmpty(medIdString).equals(""))
					sql.append(" AND " + medIdString.trim() + " = ?");
				parmList.add(searchHic);
			}
			if (!searchLastName.equals("")) {
				sql.append(" AND A.LAST_NAME like ?");
				parmList.add(searchLastName + "%");
			}
			if (!searchFirstName.equals("")) {
				sql.append(" AND A.FIRST_NAME like ?");
				parmList.add(searchFirstName + "%");
			}
			if (!searchBirthDate.equals("")) {
				sql.append("AND A.BIRTH_DATE = ?");
				parmList.add(DateUtil.changedDateFormatForMonth(searchBirthDate));
			}
			if (!searchApplId.equals("") && !isPagination) {
				sql.append(" AND A.APPLICATION_ID = ?");
				parmList.add(searchApplId);
			}
			if (!searchStatus.equals("")) {
				sql.append(" AND A.APPLICATION_STATUS = ?");
				parmList.add(searchStatus);
			}

			if (isPagination) {
				DataBaseField[] conds = new DataBaseField[1];
				for (int i = 0; i < 1; i++) {
					conds[i] = new DataBaseField();
				}
				conds[0].setFieldName("A.APPLICATION_ID");
				conds[0].setStringValue(String.valueOf(searchApplId));
				StringBuilder pageCond = PaginationQueryHelper.pagingElements(conds, parmList);
				sql.append(pageCond);
			}

			sql.append(" ORDER BY CUSTOMER_ID, APPLICATION_ID ASC");
			sql.append(" FETCH FIRST ").append(EEMConstants.DB_MAX_RECORD_FETCH).append(" ROWS ONLY");

			Object[] objPrams = parmList.toArray();
			List<EEMApplSearchDO> list = jdbcTemplate.query(sql.toString(), objPrams,
					new DomainPropertyRowMapper<EEMApplSearchDO>(EEMApplSearchDO.class));

			List<EEMApplSearchVO> targetList = new ArrayList<EEMApplSearchVO>();

			if (list != null && list.size() > 0) {
				if (list.size() > 100) {
					list.remove(list.size() - 1);
					response.setNextPage(true);
				}
				CommonUtils.copyList(list, targetList, EEMApplSearchVO.class);
			}
			response.setContent(targetList);
			return response;
		} catch (DataAccessException exp) {
			LOGGER.error("Exception in ApplicationDAOImpl->getApplSearchDetails : {}", exp);
			throw new ApplicationException("DataBase Error");
		}

	}

	@Override
	public EEMApplicationDO getMasterDetails(int applId, String customerId) throws ApplicationException {

		try {

			StringBuilder sQuery = new StringBuilder("SELECT CUSTOMER_ID, APPLICATION_ID, APPLICATION_TYPE, ")
					.append("APPLICATION_NBR, APPLICATION_DATE, LAST_NAME, FIRST_NAME, MIDDLE_INIT, ")
					.append("BILL_LAST_NAME, BILL_FIRST_NAME, BILL_MIDDLE_INIT, PREFIX, MAIL_LAST_NAME, ")
					.append("MAIL_FIRST_NAME, MAIL_MIDDLE_INIT, MEMBER_ID, SUPPLEMENTAL_ID, HIC_NBR, ")
					.append("RX_ID, BIRTH_DATE, GENDER_CD, MBR_EMAIL, PREMIUM_WITHHOLD_OPTION, ")
					.append("SGN_ONFILE_IND, SGN_DATE, AUTH_FIRST_NAME, AUTH_LAST_NAME, AUTH_MIDDLE_INIT, ")
					.append("AUTH_RELATIONSHIP_CD, EMERGCY_NAME, ")
					.append("EMERGCY_PHONE, EMERGCY_RELATIONSHIP_CD, EMERGCY_EMAIL, INS_CARD_NAME, SSN, ")
					.append("LANGUAGE_CD, ENROLL_SRCE_CD, OOA_IND, APPLICATION_STATUS, PROCESS_DATE, ")
					.append("FILE_ID, ARCHIVE_IND, LAST_UPDT_TIME, APPLICATION_CATEGORY, ")
					.append("SUFFIX, BILL_SUFFIX, MAIL_SUFFIX,BILL_LAST_NAME, BILL_FIRST_NAME, BILL_MIDDLE_INIT, ")
					.append("CREATE_TIME, CREATE_USERID, LAST_UPDT_USERID, EDIT_OVERRIDE_IND , RECEIPT_DATE,SGN_DATE_OVR_IND,SUBSCRIBER_ID, ")
					.append("LTR_REASON_CD , DENIAL_RCVD_DATE, DENIAL_REASON_CD,")
					.append("NAME_ON_ACCT, ACCOUNT_TYPE, ABA_ROUTING_NBR, BANK_ACCT_NBR, BILL_FREQUENCY,DUPL_APP_OVRD_IND,XREF_CLAIM_NBR ")
					// ACH banking data,// IFOX-00397126
					// Added for SSNRI changes : Start
					.append(",MBI ")
					// Added for SSNRI changes : End
					// IFOX-00406767 -start
					.append(", ALT_CORRES_IND, HEALTH_PLAN_NEWS_EMAIL ")
					// IFOX-00406767 -end
					// Triple S BasePlus Migration/IFOX-00354933 START
					.append(",CAMPAIGN_ID, CONTRACT_ID ")
					// Triple S BasePlus Migration/IFOX-00354933 END
					// Triple S BasePlus Migration/DraftDay/BankName changes on Billing START
					.append(",DRAFT_DAY, BANK_NAME ")
					// Triple S BasePlus Migration/DraftDay/BankName changes on Billing END
					.append("FROM EM_APPLICATION WHERE CUSTOMER_ID = ? AND APPLICATION_ID = ?");

			List<EEMApplicationDO> applList = jdbcTemplate.query(sQuery.toString(), new ApplicationRowMapper(),
					new Object[] { customerId, applId });
			if (applList.size() > 0)
				return applList.get(0);
			return null;
		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->getMasterDetails:{}", e);
			throw new ApplicationException(e);
		}
	}

	@Override
	public List<EEMApplAddressDO> getAddressDetails(int applId, String customerId) throws ApplicationException {

		try {
			StringBuilder sQuery = new StringBuilder(
					"SELECT CUSTOMER_ID, APPLICATION_ID, ADDRESS_TYPE, ADDRESS1, ADDRESS2, ")
							.append("ADDRESS3, CITY, STATE_CD, ZIP_CD, COUNTY_CD, COUNTRY_CD, ")
							.append("HOME_PHONE_NBR, WORK_PHONE_NBR, CELL_PHONE_NBR, FAX_NBR, LAST_UPDT_TIME ")
							.append("FROM EM_APPL_ADDRESS ").append("WHERE CUSTOMER_ID = ? AND APPLICATION_ID = ? ");

			return jdbcTemplate.query(sQuery.toString(),
					new DomainPropertyRowMapper<EEMApplAddressDO>(EEMApplAddressDO.class), customerId, applId);

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->getAddressDetails:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public EEMApplOtherCovDO getOtherCovDetails(int applId, String customerId) throws ApplicationException {
		EEMApplOtherCovDO eemApplOtherCovDO = new EEMApplOtherCovDO();
		try {

			String sQuery = CommonUtils.buildQuery("SELECT ESRD_IND, PCO_IND, DIALYSIS_IND, MEDICAID_IND,",
					" SPOUSE_WORK_IND, SEC_RX_IND, SEC_RX_ID, SEC_RX_NAME, SEC_RX_GRP, LTC_INST_IND, LTC_FAC_ID,",
					" LAST_UPDT_TIME,SEC_RX_BIN, SEC_RX_PCN, MEDICAID_ID",
					" FROM EM_APPL_OTHER_COV WHERE CUSTOMER_ID = ? AND APPLICATION_ID = ?",
					" ORDER BY LAST_UPDT_TIME DESC FETCH FIRST ROW ONLY");

			Object[] parms = new Object[] { customerId, applId };

			eemApplOtherCovDO = jdbcTemplate.queryForObject(sQuery.toString(),
					new DomainPropertyRowMapper<EEMApplOtherCovDO>(EEMApplOtherCovDO.class), parms);

		} catch (EmptyResultDataAccessException exp) {
			LOGGER.info("EEMApplDaoImpl->OtherCovDetails not found");

		} catch (DataAccessException exp) {
			LOGGER.error("Exception in EEMApplDaoImpl->getOtherCovDetails:{}", exp);
			throw new ApplicationException(exp, "Error ocurred while getOtherCovDetails!");
		}
		return eemApplOtherCovDO;
	}

	@Override
	public List<EEMApplAttestationDO> getAttestationDetails(int applId, String customerId) throws ApplicationException {

		try {
			StringBuilder sQuery = new StringBuilder("SELECT ATTEST_IND, ATTEST_DATE, DELETE_IND ").append(
					"FROM EM_APPL_ATTESTATION WHERE CUSTOMER_ID = ? AND APPLICATION_ID = ? AND DELETE_IND !='Y' ");

			List<EEMApplAttestationDO> applAttestationList = jdbcTemplate.query(sQuery.toString(),
					new RowMapper<EEMApplAttestationDO>() {

						@Override
						public EEMApplAttestationDO mapRow(ResultSet rs, int arg1) throws SQLException {
							EEMApplAttestationDO attestVO = new EEMApplAttestationDO();
							attestVO.setAttestInd(trimToEmpty(rs.getString("ATTEST_IND")));
							attestVO.setAttestDate(DateUtil.formatMmDdYyyy(trimToEmpty(rs.getString("ATTEST_DATE"))));
							// attestVO.setDeleteInd(trimToEmpty(rs.getString("DELETE_IND")));
							attestVO.setLogicalInd("");
							return attestVO;
						}
					}, new Object[] { customerId, applId });
			return applAttestationList;

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->getAttestationDetails:{}", e);
			throw new ApplicationException(e);
		}
	}

	@Override
	public EEMApplAgentDO getAgentDetails(int applId, String customerId, String effDt) throws ApplicationException {
		try {
			StringBuilder sQuery = new StringBuilder(
					"SELECT A.AGENCY_ID, A.AGENT_ID, A.AGENT_DATE, B.AGENT_TYPE, A.LAST_UPDT_TIME ")
							.append(", (RTRIM(A.AGENCY_ID) || ' - ' || RTRIM(C.AGENCY_NAME)) AS VALUE ")
							.append(" ,B.AGENT_NAME, C.AGENCY_TYPE,C.AGENCY_NAME ")
							// .append("FROM EM_APPL_AGENT A, EM_AGENCY_AGENT B, EM_AGENCY C WHERE
							// A.CUSTOMER_ID = B.CUSTOMER_ID ")
							.append("FROM EM_APPL_AGENT A, EM_AGENT B, EM_AGENCY C WHERE A.CUSTOMER_ID = B.CUSTOMER_ID ")
							.append("AND A.CUSTOMER_ID = C.CUSTOMER_ID ")
							// .append("AND A.AGENT_ID = B.AGENT_ID AND A.AGENCY_ID = B.AGENCY_ID AND
							// A.AGENCY_ID = C.AGENCY_ID ")
							.append("AND A.AGENT_ID = B.AGENT_ID AND A.AGENCY_ID = C.AGENCY_ID ")
							.append("AND A.CUSTOMER_ID = ? AND A.APPLICATION_ID = ? ");
			// .append("AND ? BETWEEN B.EFF_START_DATE AND B.EFF_END_DATE ");

			List<EEMApplAgentDO> applAgentList = jdbcTemplate.query(sQuery.toString(), new RowMapper<EEMApplAgentDO>() {

				@Override
				public EEMApplAgentDO mapRow(ResultSet rs, int arg1) throws SQLException {
					EEMApplAgentDO agentVO = new EEMApplAgentDO();
					agentVO.setCommAgencyId(trimToEmpty(rs.getString("VALUE")));
					agentVO.setBrokAgentId(trimToEmpty(rs.getString("AGENT_ID")));
					agentVO.setAgentDt(DateUtil.formatMmDdYyyy(trimToEmpty(rs.getString("AGENT_DATE"))));
					// agentVO.setAgentType(trimToEmpty(rs.getString("AGENT_TYPE")));
					agentVO.setBrokerType(trimToEmpty(rs.getString("AGENT_TYPE")));
					agentVO.setAgencyName(trimToEmpty(rs.getString("AGENCY_NAME")));
					agentVO.setAgencyType(trimToEmpty(rs.getString("AGENCY_TYPE")));
					agentVO.setAgentName(trimToEmpty(rs.getString("AGENT_NAME")));
					agentVO.setLastUpdtTime(trimToEmpty(rs.getString("LAST_UPDT_TIME")));
					return agentVO;
				}
				// }, new Object[] { customerId, applId,
				// DateUtil.changedDateFormatForMonth(trimToEmpty(effDt)) });
			}, new Object[] { customerId, applId });
			if (applAgentList.size() > 0)
				return applAgentList.get(0);
			return null;

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->getAgentDetails:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public List<LabelValuePair> getLstBrokAgency(String customerId, String covDt) throws ApplicationException {

		try {
			StringBuilder sQuery = new StringBuilder("SELECT DISTINCT(A.AGENCY_ID), ")
					.append("(RTRIM(A.AGENCY_ID) || ' - ' || RTRIM(B.AGENCY_NAME)) AS VALUE ")
					.append("FROM EM_AGENCY_AGENT A, EM_AGENCY B ").append("WHERE A.CUSTOMER_ID = B.CUSTOMER_ID ")
					.append("AND A.AGENCY_ID = B.AGENCY_ID ").append("AND A.CUSTOMER_ID = ? ")
					.append("AND ? BETWEEN A.EFF_START_DATE AND A.EFF_END_DATE");

			List<LabelValuePair> lstArr = jdbcTemplate.query(sQuery.toString(), new RowMapper<LabelValuePair>() {

				@Override
				public LabelValuePair mapRow(ResultSet rs, int rowNum) throws SQLException {
					LabelValuePair nvp = new LabelValuePair(trimToEmpty(rs.getString("VALUE")),
							trimToEmpty(rs.getString("AGENCY_ID")));
					return nvp;
				}

			}, new Object[] { trimToEmpty(customerId), DateUtil.changedDateFormatForMonth(trimToEmpty(covDt)) });
			return lstArr;

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->getLstAgencies:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public EEMApplPlanDO getPlanDetails(int applId, String customerId) throws ApplicationException {
		try {
			StringBuilder sQuery = new StringBuilder(
					"SELECT EFFECTIVE_DATE, ELECTION_TYPE_CD, SEP_ELECTION_DATE, SEP_REASON_CD, ").append(
							" FROM_PLAN_ID, FROM_PBP_ID, FROM_PBP_SEGMENT_ID, FROM_PRODUCT_ID, FROM_PAYMENT_AMT, ")
							.append(" TO_PLAN_ID, TO_PBP_ID, TO_PBP_SEGMENT_ID, TO_PRODUCT_ID, TO_PAYMENT_AMT, ")
							.append(" TO_GROUP_ID, FROM_GROUP_ID, LAST_UPDT_TIME, ELC_DERIVED_IND ")
							.append(" FROM EM_APPL_PLAN ").append(" WHERE CUSTOMER_ID = ? AND APPLICATION_ID = ? ");

			List<EEMApplPlanDO> applPlanLst = jdbcTemplate.query(sQuery.toString(), new ApplPlanRowMapper(),
					new Object[] { customerId, applId });

			if (applPlanLst.size() > 0)
				return applPlanLst.get(0);
			return null;
		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->getPlanDetails:{}", e);
			throw new ApplicationException(e);
		}
	}

	@Override
	public String getLineOfBusniess(String custId, String grpId, String effDate, String prdId, String planId,
			String pbpId, String segId) throws ApplicationException {
		effDate = DateFormatter.reFormat(trimToEmpty(effDate), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
		try {
			effDate = DateFormatter.reFormat(trimToEmpty(effDate), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
			StringBuilder sQuery = new StringBuilder("SELECT LINE_OF_BIZ FROM EM_GRP_PRODUCT ")
					.append("WHERE CUSTOMER_ID = ? ")
					.append("AND GRP_ID = ? AND PRODUCT_ID = ? AND PLAN_ID = ? AND PBP_ID = ? AND PBP_SEGMENT_ID = ?")
					.append(" AND ? BETWEEN GRP_PROD_START_DATE AND GRP_PROD_END_DATE ORDER BY LAST_UPDT_TIME DESC FETCH FIRST ROW ONLY");

			String lob = jdbcTemplate.queryForObject(sQuery.toString(),
					new Object[] { custId, grpId, prdId, planId, pbpId, segId, effDate }, String.class);
			return trimToEmpty(lob);

		} catch (EmptyResultDataAccessException exp) {
			return "";
		} catch (DataAccessException exp) {
			LOGGER.error("Exception in EEMApplDaoImpl->getLineOfBusniess:{}", exp);
			throw new ApplicationException(exp);
		}

	}

	@Override
	public EEMApplOtherPlanDO getPCPDetails(int applId, String customerId) throws ApplicationException {

		try {
			StringBuilder sQuery = new StringBuilder(
					"SELECT OFFICE_CATEGORY_CD, OFFICE_CD, CURRENT_PATIENT_IND, LAST_UPDT_TIME, ")
							.append("LOCATION_ID ").append("FROM EM_APPL_OTHER_PLAN ").append("WHERE CUSTOMER_ID = ? ")
							.append("AND APPLICATION_ID = ? ");

			List<EEMApplOtherPlanDO> applOtherPlanList = jdbcTemplate.query(sQuery.toString(),
					new RowMapper<EEMApplOtherPlanDO>() {

						@Override
						public EEMApplOtherPlanDO mapRow(ResultSet rs, int arg1) throws SQLException {
							EEMApplOtherPlanDO applOtherPlanVO = new EEMApplOtherPlanDO();
							applOtherPlanVO.setOfficeCategoryCd(trimToEmpty(rs.getString("OFFICE_CATEGORY_CD")));
							applOtherPlanVO.setOfficeCd(trimToEmpty(rs.getString("OFFICE_CD")));
							applOtherPlanVO.setCurrentPatientInd(trimToEmpty(rs.getString("CURRENT_PATIENT_IND")));
							applOtherPlanVO.setLastUpdtTime(trimToEmpty(rs.getString("LAST_UPDT_TIME")));
							applOtherPlanVO.setLocationId(trimToEmpty(rs.getString("LOCATION_ID")));
							return applOtherPlanVO;
						}
					}, new Object[] { customerId, applId });
			if (applOtherPlanList.size() > 0)
				return applOtherPlanList.get(0);
			return null;
		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->getPCPDetails:{}", e);
			throw new ApplicationException(e);
		}
	}

	@Override
	public void getPCPName(String customerId, int applId, String reqDtCov, String lineOfBiz,
			EEMApplOtherPlanVO applOtherPlanVO) throws ApplicationException {
		reqDtCov = DateUtil.changedDateFormatForMonth(trimToEmpty(reqDtCov));
		try {
			StringBuilder sQuery = new StringBuilder("SELECT DOCTOR_NAME,ALTERNATE_OFFICE_CD FROM EM_MED_OFFICE ")
					.append("WHERE CUSTOMER_ID IN ('9999999',?) AND OFFICE_CD = ? ")
					.append("AND ? BETWEEN OFFICE_START_DATE AND OFFICE_END_DATE AND OFFICE_CATEGORY_CD = 'PCP' ");

			if (!trimToEmpty(applOtherPlanVO.getCurrentPatientInd()).equals("Y")) {
				sQuery.append(" AND ACCEPT_NEW_PATIENT_IND = 'Y' ");
			}

			// Added for IFOX-00376908//IFOX-00389053
			// sQuery = sQuery + " AND LOCATION_ID IN (SELECT LOCATION_ID FROM
			// EM_APPL_OTHER_PLAN WHERE CUSTOMER_ID = ? AND APPLICATION_ID = ? AND
			// OFFICE_CATEGORY_CD = 'PCP') ";
			sQuery.append(" AND LOCATION_ID IN (SELECT LOCATION_ID FROM EM_APPL_OTHER_PLAN WHERE CUSTOMER_ID = ? ")
					.append("AND APPLICATION_ID = ? AND OFFICE_CATEGORY_CD = 'PCP') AND LINE_OF_BIZ IN ('', ?) FETCH FIRST ROW ONLY");
			// System.out.println("Query -> " + sQuery);

			jdbcTemplate.query(sQuery.toString(), (ResultSet rs) -> {

				if (rs.next()) {
					applOtherPlanVO.setPcpName(trimToEmpty(rs.getString("DOCTOR_NAME")));
					applOtherPlanVO.setAlternateOfficeCd(trimToEmpty(rs.getString("ALTERNATE_OFFICE_CD")));// Access
				} // Health
					// PCP-CR

				return null;
			}, new Object[] { trimToEmpty(customerId), trimToEmpty(applOtherPlanVO.getOfficeCd()), reqDtCov,
					trimToEmpty(customerId), applId, trimToEmpty(lineOfBiz) });

		} catch (

		Exception e) {
			LOGGER.error("Exception in EEMApplDaoImpl->getPCPName:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public String[] getPlanType(String customerNbr, String plan, String pbp) throws ApplicationException {

		String[] planType = new String[2];
		try {
			StringBuilder sQuery = new StringBuilder("SELECT PLAN_TYPE, PLAN_DESIGNATION FROM PLANPBP ")
					.append(" WHERE CUST_NBR = ? ").append(" AND PLAN_ID = ? AND PBP_ID = ? ");

			planType = (String[]) jdbcTemplate.queryForObject(sQuery.toString(),
					new Object[] { customerNbr, plan, pbp }, new RowMapper<Object>() {

						@Override
						public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
							String[] plan = new String[2];
							plan[0] = trimToEmpty(rs.getString("PLAN_TYPE"));
							plan[1] = trimToEmpty(rs.getString("PLAN_DESIGNATION"));
							return plan;
						}

					});
			return planType;

		} catch (EmptyResultDataAccessException exp) {
			return null;
		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->getPlanType:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public String getGroupName(String customerId, String groupId, String dateOfCov) throws ApplicationException {

		try {
			StringBuilder sQuery = new StringBuilder("SELECT GROUP_NAME FROM EM_GRP_NAME")
					.append(" WHERE CUSTOMER_ID = ? AND GRP_ID = ?")
					.append(" AND ? BETWEEN GRPNAME_START_DATE AND GRPNAME_END_DATE FETCH FIRST ROW ONLY");

			String grpName = jdbcTemplate.queryForObject(sQuery.toString(),
					new Object[] { customerId, groupId, DateUtil.changedDateFormatForMonth(trimToEmpty(dateOfCov)) },
					String.class);
			return trimToEmpty(grpName);

		} catch (EmptyResultDataAccessException exp) {
			return "";
		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->getGroupName:{}", e);
			throw new ApplicationException(e);
		}
	}

	@Override
	public String getProductName(String customerId, String productId, String dateOfCov) throws ApplicationException {

		try {
			StringBuilder sQuery = new StringBuilder("SELECT PRODUCT_NAME FROM EM_PRODUCT_NAME")
					.append(" WHERE CUSTOMER_ID = ? AND PRODUCT_ID = ?")
					.append(" AND ? BETWEEN PRODNAME_START_DATE AND PRODNAME_END_DATE FETCH FIRST ROW ONLY");
			// System.out.println("Query -> " + sQuery);

			String prodName = jdbcTemplate.queryForObject(sQuery.toString(),
					new Object[] { customerId, productId, DateUtil.changedDateFormatForMonth(trimToEmpty(dateOfCov)) },
					String.class);
			return trimToEmpty(prodName);

		} catch (EmptyResultDataAccessException exp) {
			return "";
		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->getProductName:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public List<LabelValuePair> getLstBrokAgents(String customerId, String type, String agencyId, String covDt)
			throws ApplicationException {

		try {
			StringBuilder sQuery = new StringBuilder(
					"SELECT A.AGENT_ID, (RTRIM(A.AGENT_ID) || ' - ' || RTRIM(B.AGENT_NAME)) AS VALUE ")
							.append("FROM EM_AGENCY_AGENT A, EM_AGENT B WHERE A.CUSTOMER_ID = B.CUSTOMER_ID ")
							.append("AND A.AGENT_ID = B.AGENT_ID ")
							.append("AND A.AGENT_TYPE = B.AGENT_TYPE AND A.CUSTOMER_ID = ? ")
							.append("AND A.AGENCY_ID = ? AND A.AGENT_TYPE = ? ")
							.append("AND ? BETWEEN A.EFF_START_DATE AND A.EFF_END_DATE");
			// check for length of the agency ID
			agencyId = agencyId != null ? trimToEmpty(agencyId.split("-")[0]) : "";
			if (agencyId.length() > 15) {
				agencyId = agencyId.substring(0, 15);
			}

			List<LabelValuePair> lstArr = jdbcTemplate.query(sQuery.toString(), new RowMapper<LabelValuePair>() {

				@Override
				public LabelValuePair mapRow(ResultSet rs, int rowNum) throws SQLException {
					LabelValuePair nvp = new LabelValuePair(trimToEmpty(rs.getString("VALUE")),
							trimToEmpty(rs.getString("AGENT_ID")));
					return nvp;
				}

			}, new Object[] { trimToEmpty(customerId), trimToEmpty(agencyId), trimToEmpty(type),
					DateUtil.changedDateFormatForMonth(trimToEmpty(covDt)) });
			return lstArr;

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->getLstBrokAgents:{}", e);
			throw new ApplicationException(e);
		}
	}

	@Override
	public List<EEMApplCommentsDO> getCommentDetails(int applId, String customerId) throws ApplicationException {

		try {
			StringBuilder sQuery = new StringBuilder(
					"SELECT CREATE_TIME, CREATE_USERID, APPL_COMMENTS FROM EM_APPL_COMMENT ")
							.append("WHERE CUSTOMER_ID = ? ").append("AND APPLICATION_ID = ? ")
							.append("ORDER BY COMMENT_SEQ_NBR DESC");

			List<EEMApplCommentsDO> applCommentsList = jdbcTemplate.query(sQuery.toString(),
					new RowMapper<EEMApplCommentsDO>() {

						@Override
						public EEMApplCommentsDO mapRow(ResultSet rs, int arg1) throws SQLException {
							EEMApplCommentsDO applCommentsVO = new EEMApplCommentsDO();
							applCommentsVO.setCreateTime(trimToEmpty(rs.getString("CREATE_TIME")));
							applCommentsVO.setCreateUserId(trimToEmpty(rs.getString("CREATE_USERID")));
							applCommentsVO.setApplComments(trimToEmpty(rs.getString("APPL_COMMENTS")));
							applCommentsVO.setApplicationId(applId);
							applCommentsVO.setCustomerId(customerId);
							return applCommentsVO;
						}
					}, new Object[] { customerId, applId });
			return applCommentsList;

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->getCommentDetails:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public EEMApplEligibilityDO getEligDetails(int applId, String customerId) throws ApplicationException {

		try {
			StringBuilder sQuery = new StringBuilder("SELECT PRTA_ENTITLE_DATE, PRTB_ENTITLE_DATE, PRTD_ELIG_SDATE, ")
					.append(" INST_SDATE, INST_EDATE, ESRD_SDATE, ESRD_EDATE, MEDIC_SDATE, MEDIC_EDATE,ELIG_OVERRIDE_IND, ")
					.append(" LAST_CHECKED_TIME,PRTA_ENTITLE_EDATE, PRTB_ENTITLE_EDATE ")
					.append(" FROM EM_APPL_ELIGIBILITY ").append(" WHERE CUSTOMER_ID = ? ")
					.append(" AND APPLICATION_ID = ? ").append(" ORDER BY LAST_CHECKED_TIME DESC ")
					.append(" FETCH FIRST 1 ROWS ONLY");
			return jdbcTemplate.queryForObject(sQuery.toString(), new Object[] { customerId, applId },
					new ApplEligibilityRowMapper());

		} catch (EmptyResultDataAccessException exp) {
			return null;
		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->getEligDetails:{}", e);
			throw new ApplicationException(e);
		}
	}

	@Override
	public List<EEMApplErrorDO> getErrorDetails(int applId, String customerId) throws ApplicationException {
		try {
			StringBuilder sQuery = new StringBuilder(
					"SELECT AE.CUSTOMER_ID, AE.APPLICATION_ID, AE.FIELD_NBR, AE.ERROR_CD, AE.RFI_IND, AE.ERROR_DATA,")
							.append(" FE.FORM_FIELD, EM.ERROR_MESSAGE")
							.append(" FROM EM_APPL_ERROR AE JOIN EM_FIELD_EDITS FE")
							.append(" ON FE.CUSTOMER_ID = AE.CUSTOMER_ID AND FE.FIELD_NBR = AE.FIELD_NBR")
							.append(" JOIN EM_ERROR_MESSAGE EM ON EM.ERROR_CD = AE.ERROR_CD WHERE AE.CUSTOMER_ID = ?")
							.append(" AND AE.APPLICATION_ID = ? AND AE.ERROR_STATUS != 'CLOSED' UNION ")
							.append(" SELECT AE.CUSTOMER_ID, AE.APPLICATION_ID, AE.FIELD_NBR, AE.ERROR_CD, AE.RFI_IND, AE.ERROR_DATA,")
							.append(" FE.FORM_FIELD, EM.ERROR_MESSAGE FROM EM_APPL_ERROR AE JOIN EM_FIELD_EDITS FE")
							.append(" ON FE.CUSTOMER_ID = '9999999' AND FE.FIELD_NBR = AE.FIELD_NBR")
							.append(" JOIN EM_ERROR_MESSAGE EM ON EM.ERROR_CD = AE.ERROR_CD WHERE AE.CUSTOMER_ID = ?")
							.append(" AND AE.APPLICATION_ID = ? AND AE.ERROR_STATUS != 'CLOSED'")
							.append(" AND NOT EXISTS (SELECT 1 FROM EM_FIELD_EDITS FE2 WHERE FE2.CUSTOMER_ID = ?")
							.append(" AND FE2.FIELD_NBR = FE.FIELD_NBR)");

			return jdbcTemplate.query(sQuery.toString(),
					new DomainPropertyRowMapper<EEMApplErrorDO>(EEMApplErrorDO.class), customerId, applId, customerId,
					applId, customerId);

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->getErrorDetails:{}", e);
			throw new ApplicationException("DataBase Error");
		}

	}

	@Override
	public EEMApplLisDO getLisDetails(int applId, String customerId) throws ApplicationException {

		try {
			StringBuilder sQuery = new StringBuilder(
					"SELECT EFF_START_DATE, EFF_END_DATE, LI_COPAY_CD, LIS_PCT_CD FROM EM_APPL_LIS")
							.append(" WHERE CUSTOMER_ID =? AND APPLICATION_ID =? AND OVERRIDE_IND ='N'");

			return jdbcTemplate.queryForObject(sQuery.toString(), new Object[] { customerId, applId },
					new ApplLisRowMapper());

		} catch (EmptyResultDataAccessException exp) {
			return null;
		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->getLisDetails:{}", e);
			throw new ApplicationException("DataBase Error");
		}

	}

	@Override
	public EEMApplTriggerDO getApplTrigger(String customerId, int applId, String triggerType, String triggerCode)
			throws SQLException, ApplicationException {

		try {
			StringBuilder sQuery = new StringBuilder(
					"SELECT CUSTOMER_ID, APPLICATION_ID, TRIGGER_TYPE, EFFECTIVE_DATE, CREATE_TIME,")
							.append(" TRIGGER_STATUS, TRIGGER_CODE,")
							.append(" ORIG_TRIGGER_TYPE, ORIG_TRIGGER_CODE, ORIG_EFFECTIVE_DATE, ORIG_TRIGGER_CREATE_TIME,")
							.append(" CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID FROM EM_APPL_TRIGGER")
							.append(" WHERE CUSTOMER_ID = ? AND APPLICATION_ID = ? AND TRIGGER_TYPE = ? AND TRIGGER_CODE = ?")
							.append(" ORDER BY CREATE_TIME DESC FETCH FIRST 1 ROWS ONLY");

			return jdbcTemplate.queryForObject(sQuery.toString(),
					new Object[] { customerId, applId, triggerType, triggerCode }, new ApplTriggerRowMapper());

		} catch (EmptyResultDataAccessException exp) {
			return null;
		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->getApplTrigger:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public int insertCommentDetails(String customerId, int applId, EEMApplCommentsDO commentDO) {

		String timeStamp = DateUtil.getCurrentDatetimeStamp();
		String sQuery = "INSERT INTO EM_APPL_COMMENT (CUSTOMER_ID, APPLICATION_ID, "
				+ "COMMENT_SEQ_NBR, CREATE_TIME, CREATE_USERID, APPL_COMMENTS) " + "VALUES (?,?,?,?,?,?)";

		try {
			return jdbcTemplate.update(sQuery, customerId, applId, getCommentSeqNo(customerId, applId), timeStamp,
					commentDO.getCreateUserId(), commentDO.getApplComments());

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->insertCommentDetails:{}", e);
			throw new ApplicationException(e);
		}

	}
	
	@Override
	public int insertBulkCommentDetails(String customerId, int applId, List<EEMApplCommentsDO> applCommentList) {
		int count = 0;
		String sQuery = CommonUtils.buildQuery(
				"INSERT INTO EM_APPL_COMMENT (CUSTOMER_ID, APPLICATION_ID, COMMENT_SEQ_NBR, APPL_COMMENTS, CREATE_TIME,CREATE_USERID) ",
				"VALUES(:cutomerId,:applId,:commentSeqNbr,:applComment,:createTime,:createUserId) ");
		try {
			List<MapSqlParameterSource> batchArgs = new ArrayList<>();
			int seq = getCommentSeqNo(customerId, applId);
			for (EEMApplCommentsDO applComment : applCommentList) {
				MapSqlParameterSource params = new MapSqlParameterSource();
				params.addValue("cutomerId", customerId);
				params.addValue("applId", applId);
				params.addValue("commentSeqNbr", seq++);
				params.addValue("applComment", applComment.getApplComments());
				params.addValue("createTime", DateUtil.getCurrentDatetimeStamp());
				params.addValue("createUserId", applComment.getCreateUserId());

				batchArgs.add(params);
			}

			if (!CollectionUtils.isEmpty(batchArgs)) {
				int[] batchUpdate = namedParameterJdbcTemplate.batchUpdate(sQuery,
						batchArgs.toArray(new MapSqlParameterSource[applCommentList.size()]));
				
				for (int i = 0; i < batchUpdate.length; i++) {
					if (batchUpdate[i] != 0) {
						++count;
					}
				}
			}
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_INSERT);
		}
		return count;
	}

	@Override
	public int getCommentSeqNo(String customerId, int applId) {
		int seqNo = 0;
		try {
			String sQuery = "SELECT COMMENT_SEQ_NBR FROM EM_APPL_COMMENT WHERE CUSTOMER_ID = ?  "
					+ "AND APPLICATION_ID = ? ORDER BY COMMENT_SEQ_NBR DESC FETCH FIRST ROW ONLY";
			seqNo = jdbcTemplate.queryForObject(sQuery, new Object[] { customerId, applId }, Integer.class);

		} catch (EmptyResultDataAccessException exp) {
			return 1;
		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->getCommentSeqNo:{}", e);
		}
		return ++seqNo;
	}

	@Override
	public String getTriggerCode(String mfId, String enrollPlanDesgn, String trigCd) {

		try {
			StringBuilder sql = new StringBuilder(
					"SELECT TRIGGER_CODE FROM EM_FUNCTION_CORR_INDEX WHERE CUSTOMER_ID = ?")
							.append("AND FUNCTION_TYPE=? AND PLAN_DESIGNATION=? ");

			String trrigCode = jdbcTemplate.queryForObject(sql.toString(),
					new Object[] { mfId, trigCd, enrollPlanDesgn }, String.class);
			return trimToEmpty(trrigCode);

		} catch (EmptyResultDataAccessException exp) {
			return "";
		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->getProductName:{}", e);
			// throw new ApplicationException(e);
		}
		return "";

	}

	@Override
	public int insertApplTrigger(EEMApplTriggerDO trig) {

		try {
			String query = CommonUtils.buildQuery(
					" INSERT INTO EM_APPL_TRIGGER(CUSTOMER_ID,APPLICATION_ID,TRIGGER_TYPE,EFFECTIVE_DATE,",
					" CREATE_TIME,TRIGGER_CODE,TRIGGER_STATUS,",
					" ORIG_TRIGGER_TYPE,ORIG_TRIGGER_CODE,ORIG_EFFECTIVE_DATE,",
					" ORIG_TRIGGER_CREATE_TIME,CREATE_USERID,LAST_UPDT_TIME,LAST_UPDT_USERID)",
					" VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

			Object[] parms = new Object[] { trig.getCustomerId(), trig.getApplicationId(),
					trimToEmpty(trig.getTriggerType()), trimToEmpty(trig.getEffectiveDate()),
					trimToEmpty(trig.getCreateTime()), trimToEmpty(trig.getTriggerCode()),
					trimToEmpty(trig.getTriggerStatus()), trimToEmpty(trig.getOrigTriggerType()),
					trimToEmpty(trig.getOrigTriggerCode()), trimToEmpty(trig.getOrigEffectiveDate()),
					trimToEmpty(trig.getOrigTriggerCreateTime()), trig.getCreateUserid(), trig.getLastUpdtTime(),
					trig.getLastUpdtUserid() };

			return jdbcTemplate.update(query, parms);

		} catch (DataAccessException exp) {
			LOGGER.error("Exception in EEMApplDaoImpl->getProductName:{}", exp);
			throw new ApplicationException(exp);
		}
	}

	@Override
	public int updtApplCancel(int applId, String userId, String mfId, String reasonCd) {

		String date = DateUtil.getCurrentDatetimeStamp();

		try {
			String sql = "UPDATE EM_APPLICATION SET LTR_REASON_CD = ?, APPLICATION_STATUS = ? , LAST_UPDT_TIME = ?, LAST_UPDT_USERID = ? "
					+ "WHERE CUSTOMER_ID = ? AND APPLICATION_ID = ? ";
			return jdbcTemplate.update(sql, reasonCd, EEMConstants.APPL_STATUS_CANCELED, date, userId, mfId, applId);

		} catch (EmptyResultDataAccessException exp) {
			return 0;
		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->getProductName:{}", e);
			throw new ApplicationException("Error Message while updating application status to cancel ::::::");
		}
	}

	@Override
	public int closeFUATrigger(String customerId, int applId, String userId, String triggerStatus, String applStatus) {
		try {
			String ts = DateUtil.getCurrentDatetimeStamp();

			String sQuery = "UPDATE EM_APPL_TRIGGER SET TRIGGER_STATUS=?, LAST_UPDT_TIME=?, LAST_UPDT_USERID=? "
					+ "WHERE CUSTOMER_ID=? AND APPLICATION_ID=? AND TRIGGER_TYPE='FUA' AND TRIGGER_STATUS='OPEN'";

			if (applStatus.equals(EEMConstants.APPL_STATUS_FORCEDAPPR)
					|| applStatus.equals(EEMConstants.APPL_STATUS_READYAPPR)
					|| applStatus.equals(EEMConstants.APPL_STATUS_APPROVED)) {
				sQuery = sQuery + "AND TRIGGER_CODE IN ('RFIH','RFIR','ELC8','ELCI','ELCA')";
			}
			return jdbcTemplate.update(sQuery, triggerStatus, ts, userId, customerId, applId);

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->getProductName:{}", e);
			// throw new ApplicationException(e);
		}
		return 0;

	}

	@Override
	public EEMOriginalApplDO getOrigApplDetails(String customerId, int applId) throws ApplicationException {

		EEMOriginalApplDO origApplDo = new EEMOriginalApplDO();
		try {
			StringBuilder sQuery = new StringBuilder("SELECT * FROM EM_ORIG_APPLICATION ")
					.append("WHERE CUSTOMER_ID = ? AND APPLICATION_ID = ? ");

			List<EEMOriginalApplDO> applList = jdbcTemplate.query(sQuery.toString(),
					new EEMOrigApplRowMapper(jdbcTemplate), new Object[] { customerId, applId });

			if (!applList.isEmpty()) {
				return applList.get(0);
			}

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->getOtherCovDetails:{}", e);
			throw new ApplicationException(e);
		}

		return origApplDo;

	}

	@Override
	public List<EEMApplAddressDO> getMbrAddressDetails(EEMApplicationDO eemApplicationDO, EEMApplPlanDO eemApplPlanDO)
			throws ApplicationException {

		List<EEMApplAddressDO> lstAddr = new ArrayList<EEMApplAddressDO>();
		StringBuilder queryBuilder = null;
		List<Map<String, Object>> rows = null;
		try {
			queryBuilder = new StringBuilder().append(
					" SELECT ADDRESS_TYPE, ADDRESS1, ADDRESS2, ADDRESS3, CITY, STATE_CD, ZIP_CD, COUNTY_CD, COUNTRY_CD, HOME_PHONE_NBR, WORK_PHONE_NBR, ")
					.append(" CELL_PHONE_NBR, FAX_NBR FROM EM_MBR_ADDRESS WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? ")
					.append(" AND OVERRIDE_IND = 'N' AND ? BETWEEN EFF_START_DATE AND EFF_END_DATE ");

			rows = jdbcTemplate.queryForList(queryBuilder.toString(),
					new String[] { eemApplicationDO.getCustomerId(), eemApplicationDO.getMbrId(),
							DateUtil.changedDateFormatForMonth(trimToEmpty(eemApplPlanDO.getReqDtCov())) });

			for (Map row : rows) {
				EEMApplAddressDO addrVO = new EEMApplAddressDO();
				addrVO.setAddressType(trimToEmpty((String) row.get("ADDRESS_TYPE")));
				addrVO.setAddress1(trimToEmpty((String) row.get("ADDRESS1")));
				addrVO.setAddress2(trimToEmpty((String) row.get("ADDRESS2")));
				addrVO.setAddress3(trimToEmpty((String) row.get("ADDRESS3")));
				addrVO.setCity(trimToEmpty((String) row.get("CITY")));
				addrVO.setStateCd(trimToEmpty((String) row.get("STATE_CD")));
				addrVO.setZipCd(trimToEmpty((String) row.get("ZIP_CD")));
				addrVO.setCountyCd(trimToEmpty((String) row.get("COUNTY_CD")));
				addrVO.setCountryCd(trimToEmpty((String) row.get("COUNTRY_CD")));
				addrVO.setHomePhoneNbr(trimToEmpty((String) row.get("HOME_PHONE_NBR")));
				addrVO.setWorkPhoneNbr(trimToEmpty((String) row.get("WORK_PHONE_NBR")));
				addrVO.setCellPhoneNbr(trimToEmpty((String) row.get("CELL_PHONE_NBR")));
				addrVO.setFaxNbr(trimToEmpty((String) row.get("FAX_NBR")));
				lstAddr.add(addrVO);
			}

		} catch (DataAccessException e) {
			LOGGER.error(" EEMApplDAOImpl : getMbrAddressDetails : {}", e.getMessage());
			throw new ApplicationException(e);
		}
		return lstAddr;
	}

	@Override
	public boolean getPriorMemberDetails(EEMApplicationDO eemApplicationDO, EEMApplOtherCovDO eemApplOtherCovDO,
			String planDesgn) throws ApplicationException {

		String memberId = null;
		StringBuilder sQuery = null;
		List<Map<String, Object>> rows = null;
		List<Map<String, Object>> rows1 = null;
		try {
			String sQuery1 = "SELECT MEMBER_ID FROM EM_MBR_DSINFO where CUSTOMER_ID = ? AND DS_CD IN ('MED','MBI') AND DS_VALUE IN( ?,?) AND OVERRIDE_IND = 'N' ";

			sQuery = new StringBuilder().append(
					" SELECT A.MEMBER_ID, LAST_NAME, FIRST_NAME, MIDDLE_INITIAL, PREFIX, MAIL_LAST_NAME, MAIL_FIRST_NAME, MAIL_MIDDLE_INIT,")
					.append(" INS_CARD_NAME, SSN, BIRTH_DATE, GENDER_CD, MBR_EMAIL, AUTH_FIRST_NAME, AUTH_MIDDLE_INIT, AUTH_LAST_NAME, AUTH_RELATIONSHIP_CD, EMERGCY_NAME,")
					.append(" EMERGCY_PHONE, EMERGCY_RELATIONSHIP_CD, EMERGCY_EMAIL, LANGUAGE_CD, SPOUSE_WORK_IND, PRODUCT_ID, GRP_ID, SUPPLEMENTAL_ID, PLAN_ID, PBP_ID, ")
					.append(" PBP_SEGMENT_ID, PLAN_DESIGNATION, ELECTION_TYPE_CD, SEP_ELECTION_DATE, RX_ID, SEC_RX_GRP, SEC_RX_NAME, SEC_RX_ID, ENROLL_SRCE_CD, ")
					.append(" SEC_RX_BIN, SEC_RX_PCN, B.EFF_END_DATE FROM EM_MBR_DEMOGRAPHIC A INNER JOIN EM_MBR_ENROLLMENT B ")
					.append(" ON A.CUSTOMER_ID = B.CUSTOMER_ID AND A.MEMBER_ID = B.MEMBER_ID ")
					.append(" WHERE  A.CUSTOMER_ID = ? AND A.MEMBER_ID = ? AND A.CURRENT_IND = 'Y' AND A.OVERRIDE_IND = 'N' AND B.OVERRIDE_IND = 'N' AND B.EFF_END_DATE = '99999999' ");

			if (!trimToEmpty(planDesgn).equals(""))
				sQuery.append(" AND B.PLAN_DESIGNATION = ? ");

			rows1 = jdbcTemplate.queryForList(sQuery1, new String[] { eemApplicationDO.getCustomerId(),
					eemApplicationDO.getDisplayHic(), eemApplicationDO.getMbi() });

			for (Map row1 : rows1) {

				memberId = trimToEmpty((String) row1.get("MEMBER_ID"));

				rows = jdbcTemplate.queryForList(sQuery.toString(),
						!trimToEmpty(planDesgn).equals("")
								? new String[] { eemApplicationDO.getCustomerId(), memberId, planDesgn }
								: new String[] { eemApplicationDO.getCustomerId(), memberId });

				for (Map row : rows) {
					eemApplicationDO.setMbrId(trimToEmpty((String) row.get("MEMBER_ID")));
					eemApplicationDO.setMbrLastName(trimToEmpty((String) row.get("LAST_NAME")));
					eemApplicationDO.setMbrFirstName(trimToEmpty((String) row.get("FIRST_NAME")));
					eemApplicationDO.setMbrMiddleName(trimToEmpty((String) row.get("MIDDLE_INITIAL")));
					eemApplicationDO.setMbrPrefix(trimToEmpty((String) row.get("PREFIX")));
					eemApplicationDO.setMailLastName(trimToEmpty((String) row.get("MAIL_LAST_NAME")));
					eemApplicationDO.setMailFirstName(trimToEmpty((String) row.get("MAIL_FIRST_NAME")));
					eemApplicationDO.setMailMiddleName(trimToEmpty((String) row.get("MAIL_MIDDLE_INIT")));
					eemApplicationDO.setInsCardName(trimToEmpty((String) row.get("INS_CARD_NAME")));
					eemApplicationDO.setMbrSsn(trimToEmpty((String) row.get("SSN")));
					eemApplicationDO
							.setMbrBirthDt(DateUtil.formatMmDdYyyy(trimToEmpty((String) row.get("BIRTH_DATE"))));
					eemApplicationDO.setMbrGender(trimToEmpty((String) row.get("GENDER_CD")));
					eemApplicationDO.setMbrEmail(trimToEmpty((String) row.get("MBR_EMAIL")));
					eemApplicationDO.setAuthRepFirstName(trimToEmpty((String) row.get("AUTH_FIRST_NAME")));
					eemApplicationDO.setAuthRepMidName(trimToEmpty((String) row.get("AUTH_MIDDLE_INIT")));
					eemApplicationDO.setAuthRepLastName(trimToEmpty((String) row.get("AUTH_LAST_NAME")));
					eemApplicationDO.setAuthRepRelation(trimToEmpty((String) row.get("AUTH_RELATIONSHIP_CD")));
					eemApplicationDO.setEmergName(trimToEmpty((String) row.get("EMERGCY_NAME")));
					eemApplicationDO.setEmergPhone(trimToEmpty((String) row.get("EMERGCY_PHONE")));
					eemApplicationDO.setEmergRelation(trimToEmpty((String) row.get("EMERGCY_RELATIONSHIP_CD")));
					eemApplicationDO.setEmergEmail(trimToEmpty((String) row.get("EMERGCY_EMAIL")));
					eemApplicationDO.setLanguage(trimToEmpty((String) row.get("LANGUAGE_CD")));
					eemApplOtherCovDO.setSpouseWork(trimToEmpty((String) row.get("SPOUSE_WORK_IND")));
					eemApplicationDO.setAltMbrId(trimToEmpty((String) row.get("SUPPLEMENTAL_ID")));
					eemApplicationDO.setMbrRxId(trimToEmpty((String) row.get("RX_ID")));
					return true;
				}
			}

		} catch (DataAccessException e) {
			LOGGER.error(" EEMApplDAOImpl : getPriorMemberDetails : {}", e.getMessage());
			throw new ApplicationException(e);
		}
		return false;
	}

	@Override
	public EEMApplAgentDO getMbrAgentDetails(String customerId, String mbrId, String reqDtCov, String currPlan)
			throws ApplicationException {

		EEMApplAgentDO agentDO = null;
		try {
			String sQuery = "SELECT A.AGENT_ID, A.AGENCY_ID, B.AGENT_TYPE "
					+ ", (RTRIM(A.AGENCY_ID) || ' - ' || RTRIM(C.AGENCY_NAME)) AS AGENCYVALUE, (RTRIM(A.AGENT_ID) || ' - ' || RTRIM(D.AGENT_NAME)) AS AGENTVALUE, RTRIM(A.AGENT_ID) AS AGENTID, RTRIM(D.AGENT_NAME) AS AGENTNAME "
					+ "FROM EM_MBR_AGENT A, EM_AGENCY_AGENT B , EM_AGENCY C , EM_AGENT D "
					+ "WHERE A.CUSTOMER_ID = B.CUSTOMER_ID " + "AND A.CUSTOMER_ID = C.CUSTOMER_ID "
					+ "AND A.AGENT_ID = B.AGENT_ID " + "AND A.AGENCY_ID = B.AGENCY_ID "
					+ "AND A.AGENCY_ID = C.AGENCY_ID " + "AND A.AGENT_ID = D.AGENT_ID " + "AND A.CUSTOMER_ID = ? "
					+ "AND A.MEMBER_ID = ? " + "AND A.PLAN_ID = ? "
					+ "AND ? BETWEEN A.EFF_START_DATE AND A.EFF_END_DATE "
					+ "AND ? BETWEEN B.EFF_START_DATE AND B.EFF_END_DATE FETCH FIRST 1 ROWS ONLY";

			reqDtCov = DateUtil.changedDateFormatForMonth(trimToEmpty(reqDtCov));

			Object[] parms = new Object[] { customerId, mbrId, currPlan, reqDtCov, reqDtCov };

			Map<String, Object> rsMap = jdbcTemplate.queryForMap(sQuery, parms);

			if (!rsMap.isEmpty()) {
				agentDO = new EEMApplAgentDO();
				agentDO.setBrokAgentId((String) rsMap.get("AGENTID"));
				agentDO.setCommAgencyId((String) rsMap.get("AGENCYVALUE"));
				// agentDO.setAgentType((String)rsMap.get("AGENT_TYPE"));
				agentDO.setBrokerType((String) rsMap.get("AGENT_TYPE"));
			}
			return agentDO;

		} catch (EmptyResultDataAccessException exp) {
			return null;
		} catch (DataAccessException e) {
			LOGGER.error(" EEMApplService : getMbrAgentDetails : {}", e.getMessage());
			throw new ApplicationException(e.toString());
		}
	}

	/**
	 * 
	 * @param applId
	 *            contains application Id
	 * @param customerId
	 *            contains Customer ID
	 * @return boolean
	 * @throws ApplicationException
	 */
	@Override
	public boolean getOrigAppl(int applId, String customerId) throws ApplicationException {

		boolean checkOrigAppl = false;
		;

		try {
			StringBuilder sQuery = new StringBuilder().append(" SELECT APPLICATION_ID FROM EM_ORIG_APPLICATION ")
					.append("WHERE APPLICATION_ID = ? AND CUSTOMER_ID=? FETCH FIRST ROW ONLY ");
			int count = jdbcTemplate.queryForObject(sQuery.toString(), new Object[] { applId, customerId },
					Integer.class);
			if (count > 0)
				checkOrigAppl = true;

		} catch (EmptyResultDataAccessException exp) {

			LOGGER.info(" Original Application not found");
			// throw new ApplicationException(e);
		}

		return checkOrigAppl;
	}

	@Override
	public synchronized int insertMasterDetails(EEMApplicationDO objDO) throws ApplicationException {

		try {
			String sQuery = "INSERT INTO EM_APPLICATION (CUSTOMER_ID, APPLICATION_ID, APPLICATION_TYPE, "
					+ "APPLICATION_NBR, APPLICATION_DATE, LAST_NAME, FIRST_NAME, MIDDLE_INIT, " + // 8
					"BILL_LAST_NAME, BILL_FIRST_NAME, BILL_MIDDLE_INIT, PREFIX, MAIL_LAST_NAME, " + // 13
					"MAIL_FIRST_NAME, MAIL_MIDDLE_INIT, MEMBER_ID, SUPPLEMENTAL_ID, HIC_NBR, " + // 18
					"RX_ID, BIRTH_DATE, GENDER_CD, MBR_EMAIL, PREMIUM_WITHHOLD_OPTION, "
					+ "SGN_ONFILE_IND, SGN_DATE, AUTH_FIRST_NAME, AUTH_MIDDLE_INIT, AUTH_LAST_NAME, "
					+ "AUTH_RELATIONSHIP_CD, EMERGCY_NAME, "
					+ "EMERGCY_PHONE, EMERGCY_RELATIONSHIP_CD, EMERGCY_EMAIL, INS_CARD_NAME, SSN, " + // 35
					"LANGUAGE_CD, ENROLL_SRCE_CD, OOA_IND, APPLICATION_STATUS, PROCESS_DATE, "
					+ "FILE_ID, ARCHIVE_IND, CREATE_TIME, CREATE_USERID, LAST_UPDT_TIME, "
					+ "LAST_UPDT_USERID, SUFFIX, BILL_SUFFIX, MAIL_SUFFIX, APPLICATION_CATEGORY,"
					+ "EDIT_OVERRIDE_IND,RECEIPT_DATE,SGN_DATE_OVR_IND,SUBSCRIBER_ID,"
					+ "NAME_ON_ACCT, ACCOUNT_TYPE, ABA_ROUTING_NBR, BANK_ACCT_NBR, BILL_FREQUENCY,DUPL_APP_OVRD_IND,XREF_CLAIM_NBR "
					+ " ,MBI, ALT_CORRES_IND, HEALTH_PLAN_NEWS_EMAIL, CAMPAIGN_ID, CONTRACT_ID"
					+ ", DRAFT_DAY, BANK_NAME" + ") "
					+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?," + // 33
					" ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?"// 30
					+ ",?,?,?,?)";

			String hic_nbr = "";
			if (StringUtil.isHicOrMbi(trimToEmpty(objDO.getMbrHicNbr())).equalsIgnoreCase("hic"))
				hic_nbr = trimToEmpty(objDO.getMbrHicNbr());
			else
				hic_nbr = trimToEmpty(objDO.getDisplayHic());

			int draftDay = 0;
			if (objDO.getAchDraftDay() != null && !objDO.getAchDraftDay().equals("")) {
				draftDay = Integer.parseInt(trimToEmpty(objDO.getAchDraftDay()));

			} else {
				objDO.setAchDraftDay("0");
			}

			Object[] parms = new Object[] { trimToEmpty(objDO.getCustomerId()), objDO.getApplId(),
					trimToEmpty(objDO.getApplType()), trimToEmpty(objDO.getMbrApplNo()),
					DateUtil.changedDateFormatForMonth(trimToEmpty(objDO.getApplDate())),
					trimToEmpty(objDO.getMbrLastName()), trimToEmpty(objDO.getMbrFirstName()),
					trimToEmpty(objDO.getMbrMiddleName()), trimToEmpty(objDO.getBillLastName()),
					trimToEmpty(objDO.getBillFirstName()), trimToEmpty(objDO.getBillMiddleName()),
					trimToEmpty(objDO.getMbrPrefix()), trimToEmpty(objDO.getMailLastName()),
					trimToEmpty(objDO.getMailFirstName()), trimToEmpty(objDO.getMailMiddleName()),
					trimToEmpty(objDO.getMbrId()), trimToEmpty(objDO.getAltMbrId()), hic_nbr,
					trimToEmpty(objDO.getMbrRxId()),
					DateUtil.changedDateFormatForMonth(trimToEmpty(objDO.getMbrBirthDt())),
					trimToEmpty(objDO.getMbrGender()), trimToEmpty(objDO.getMbrEmail()),
					trimToEmpty(objDO.getPwOption()), trimToEmpty(objDO.getSignOnFile()),
					DateUtil.changedDateFormatForMonth(trimToEmpty(objDO.getSignDt())),
					trimToEmpty(objDO.getAuthRepFirstName()), trimToEmpty(objDO.getAuthRepMidName()),
					trimToEmpty(objDO.getAuthRepLastName()), trimToEmpty(objDO.getAuthRepRelation()),
					trimToEmpty(objDO.getEmergName()), trimToEmpty(objDO.getEmergPhone()),
					trimToEmpty(objDO.getEmergRelation()), trimToEmpty(objDO.getEmergEmail()),
					trimToEmpty(objDO.getInsCardName()), trimToEmpty(objDO.getMbrSsn()),
					trimToEmpty(objDO.getLanguage()), trimToEmpty(objDO.getEnrollSrceCd()),
					trimToEmpty(objDO.getOutOfArea()), trimToEmpty(objDO.getApplStatus()), "", "", "",
					objDO.getCreateTime(), trimToEmpty(objDO.getCreateUserId()), objDO.getCreateTime(),
					trimToEmpty(objDO.getLstUpdtUserId()), trimToEmpty(objDO.getMbrSuffix()),
					trimToEmpty(objDO.getBillSuffix()), trimToEmpty(objDO.getMailSuffix()),
					trimToEmpty(objDO.getApplCategory()), trimToEmpty(objDO.getEditOverride()),
					DateUtil.changedDateFormatForMonth(trimToEmpty(objDO.getReceiptDate())),
					trimToEmpty(objDO.getSignOvrrdDt()), trimToEmpty(objDO.getSubscriberId()),
					trimToEmpty(objDO.getAchNameOnAct()), trimToEmpty(objDO.getAchAccountType()),
					trimToEmpty(objDO.getAchAbaRoutingNbr()), trimToEmpty(objDO.getAchbankAcctNbr()),
					trimToEmpty(objDO.getAchBillFrequency()), "N", trimToEmpty(objDO.getXrefNbr()),
					trimToEmpty(objDO.getMbi()), trimToEmpty(objDO.getAltCorrespondenceInd()),
					objDO.getHealthPlanNews(), trimToEmpty(objDO.getCompaignId()), trimToEmpty(objDO.getContractorNo()),
					draftDay, trimToEmpty(objDO.getAchBankName()) };
			return jdbcTemplate.update(sQuery.toString(), parms);
		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->insertMasterDetails:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public int updateMasterDetails(EEMApplicationDO objDO) throws ApplicationException {
		String ts = DateUtil.getCurrentDatetimeStamp();

		try {
			String sQuery = "UPDATE EM_APPLICATION SET APPLICATION_TYPE=?, APPLICATION_NBR=?, "
					+ "APPLICATION_DATE=?, LAST_NAME=?, FIRST_NAME=?, MIDDLE_INIT=?, "
					+ "BILL_LAST_NAME=?, BILL_FIRST_NAME=?, BILL_MIDDLE_INIT=?, PREFIX=?, "
					+ "MAIL_LAST_NAME=?, MAIL_FIRST_NAME=?, MAIL_MIDDLE_INIT=?, MEMBER_ID=?, "
					+ "SUPPLEMENTAL_ID=?, HIC_NBR=?, RX_ID=?, BIRTH_DATE=?, GENDER_CD=?, "
					+ "MBR_EMAIL=?, PREMIUM_WITHHOLD_OPTION=?, SGN_ONFILE_IND=?, SGN_DATE=?, "
					+ "AUTH_FIRST_NAME=?, AUTH_MIDDLE_INIT=?, AUTH_LAST_NAME=?, "
					+ "AUTH_RELATIONSHIP_CD=?, EMERGCY_NAME=?, EMERGCY_PHONE=?, "
					+ "EMERGCY_RELATIONSHIP_CD=?, EMERGCY_EMAIL=?, INS_CARD_NAME=?, SSN=?, "
					+ "LANGUAGE_CD=?, ENROLL_SRCE_CD=?, OOA_IND=?, APPLICATION_STATUS=?, "
					+ "PROCESS_DATE=?,ARCHIVE_IND=?, LAST_UPDT_TIME=?, "
					+ "LAST_UPDT_USERID=?, SUFFIX=?, BILL_SUFFIX=?, MAIL_SUFFIX=?, APPLICATION_CATEGORY=?, "
					+ "EDIT_OVERRIDE_IND=?, RECEIPT_DATE =? ,SGN_DATE_OVR_IND =? ,SUBSCRIBER_ID =?, "
					+ "DENIAL_RCVD_DATE=?, DENIAL_REASON_CD=?, "
					+ "NAME_ON_ACCT=?, ACCOUNT_TYPE=?, ABA_ROUTING_NBR=?, BANK_ACCT_NBR=?, BILL_FREQUENCY=?,DUPL_APP_OVRD_IND=?,XREF_CLAIM_NBR=? "
					+ ",MBI =?" + ", ALT_CORRES_IND=?, HEALTH_PLAN_NEWS_EMAIL =?"
					+ ", CAMPAIGN_ID = ?, CONTRACT_ID = ? " + ", DRAFT_DAY = ?, BANK_NAME = ? "
					+ " WHERE CUSTOMER_ID=? AND APPLICATION_ID=?  AND LAST_UPDT_TIME=?";

			String hic_nbr = "";
			if (StringUtil.isHicOrMbi(trimToEmpty(objDO.getMbrHicNbr())).equalsIgnoreCase("hic"))
				hic_nbr = trimToEmpty(objDO.getMbrHicNbr());
			else
				hic_nbr = trimToEmpty(objDO.getDisplayHic());

			int draftDay = 0;
			if (objDO.getAchDraftDay() != null && !objDO.getAchDraftDay().equals("")) {
				draftDay = Integer.parseInt(trimToEmpty(objDO.getAchDraftDay()));
			}

			String denialDt = "";
			if ((objDO.getDenialReasonCd() != null) && !(objDO.getDenialReasonCd().equals("")))
				denialDt = DateUtil.changedDateFormatForMonth(trimToEmpty(objDO.getDenialRcvDt()));

			Object[] parms = new Object[] { trimToEmpty(objDO.getApplType()), trimToEmpty(objDO.getMbrApplNo()),
					DateUtil.changedDateFormatForMonth(trimToEmpty(objDO.getApplDate())),
					trimToEmpty(objDO.getMbrLastName()), trimToEmpty(objDO.getMbrFirstName()),
					trimToEmpty(objDO.getMbrMiddleName()), trimToEmpty(objDO.getBillLastName()),
					trimToEmpty(objDO.getBillFirstName()), trimToEmpty(objDO.getBillMiddleName()),
					trimToEmpty(objDO.getMbrPrefix()), trimToEmpty(objDO.getMailLastName()),
					trimToEmpty(objDO.getMailFirstName()), trimToEmpty(objDO.getMailMiddleName()),
					trimToEmpty(objDO.getMbrId()), trimToEmpty(objDO.getAltMbrId()), hic_nbr,
					trimToEmpty(objDO.getMbrRxId()),
					DateUtil.changedDateFormatForMonth(trimToEmpty(objDO.getMbrBirthDt())),
					trimToEmpty(objDO.getMbrGender()), trimToEmpty(objDO.getMbrEmail()),
					trimToEmpty(objDO.getPwOption()), trimToEmpty(objDO.getSignOnFile()),
					DateUtil.changedDateFormatForMonth(trimToEmpty(objDO.getSignDt())),
					trimToEmpty(objDO.getAuthRepFirstName()), trimToEmpty(objDO.getAuthRepMidName()),
					trimToEmpty(objDO.getAuthRepLastName()), trimToEmpty(objDO.getAuthRepRelation()),
					trimToEmpty(objDO.getEmergName()), trimToEmpty(objDO.getEmergPhone()),
					trimToEmpty(objDO.getEmergRelation()), trimToEmpty(objDO.getEmergEmail()),
					trimToEmpty(objDO.getInsCardName()), trimToEmpty(objDO.getMbrSsn()),
					trimToEmpty(objDO.getLanguage()), trimToEmpty(objDO.getEnrollSrceCd()),
					trimToEmpty(objDO.getOutOfArea()), trimToEmpty(objDO.getApplStatus()), "", "", ts,
					trimToEmpty(objDO.getLstUpdtUserId()), trimToEmpty(objDO.getMbrSuffix()),
					trimToEmpty(objDO.getBillSuffix()), trimToEmpty(objDO.getMailSuffix()),
					trimToEmpty(objDO.getApplCategory()), trimToEmpty(objDO.getEditOverride()),
					DateUtil.changedDateFormatForMonth(trimToEmpty(objDO.getReceiptDate())),
					trimToEmpty(objDO.getEditOverride()), trimToEmpty(objDO.getSubscriberId()), denialDt,
					trimToEmpty(objDO.getDenialReasonCd()), trimToEmpty(objDO.getAchNameOnAct()),
					trimToEmpty(objDO.getAchAccountType()), trimToEmpty(objDO.getAchAbaRoutingNbr()),
					trimToEmpty(objDO.getAchbankAcctNbr()), trimToEmpty(objDO.getAchBillFrequency()),
					trimToEmpty(objDO.getAppDuplicateCheck()), trimToEmpty(objDO.getXrefNbr()),
					trimToEmpty(objDO.getMbi()), trimToEmpty(objDO.getAltCorrespondenceInd()),
					trimToEmpty(objDO.getHealthPlanNews()), trimToEmpty(objDO.getCompaignId()),
					trimToEmpty(objDO.getContractorNo()), draftDay, trimToEmpty(objDO.getAchBankName()),
					trimToEmpty(objDO.getCustomerId()), objDO.getApplId(), trimToEmpty(objDO.getLstUpdtTime()) };
			objDO.setLstUpdtTime(ts);
			return jdbcTemplate.update(sQuery.toString(), parms);

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->updateMasterDetails:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public int updateApplTrigger(EEMApplTriggerDO trig) throws ApplicationException {

		int sqlCnt = 0;

		try {
			// Fix for IFOX-00388790: Start
			// String sql = "UPDATE EM_APPL_TRIGGER SET TRIGGER_STATUS=? WHERE
			// APPLICATION_ID=? AND TRIGGER_TYPE=? AND CUSTOMER_ID = ?";
			String sql = "UPDATE EM_APPL_TRIGGER SET TRIGGER_STATUS=?, LAST_UPDT_TIME=?, LAST_UPDT_USERID=? WHERE APPLICATION_ID=? AND TRIGGER_TYPE=? AND CUSTOMER_ID = ?";

			sqlCnt = jdbcTemplate.update(sql,
					new Object[] { EEMConstants.TRIG_STATUS_EXPIRED, trig.getLastUpdtTime(), trig.getLastUpdtUserid(),
							trig.getApplicationId(), EEMConstants.TRIG_TYPE_FOLLOWUP_APPL, trig.getCustomerId(), });

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->updateApplTrigger:{}", e);
			throw new ApplicationException(e);
		}

		return sqlCnt;
	}

	@Override
	public int insertAddressDetails(EEMApplAddressDO objVO) throws ApplicationException {

		String ts = DateUtil.getCurrentDatetimeStamp();
		try {
			String sQuery = "INSERT INTO EM_APPL_ADDRESS (CUSTOMER_ID, APPLICATION_ID, ADDRESS_TYPE, "
					+ "ADDRESS1, ADDRESS2, ADDRESS3, CITY, STATE_CD, ZIP_CD, COUNTY_CD, COUNTRY_CD, "
					+ "HOME_PHONE_NBR, WORK_PHONE_NBR, CELL_PHONE_NBR, FAX_NBR, CREATE_TIME, "
					+ "CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID) VALUES ("
					+ "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

			Object[] parms = new Object[] { trimToEmpty(objVO.getCustomerId()), objVO.getApplId(),
					trimToEmpty(objVO.getAddressType()), trimToEmpty(objVO.getAddress1()),
					trimToEmpty(objVO.getAddress2()), trimToEmpty(objVO.getAddress3()), trimToEmpty(objVO.getCity()),
					trimToEmpty(objVO.getStateCd()), trimToEmpty(objVO.getZipCd()), trimToEmpty(objVO.getCountyCd()),
					trimToEmpty(objVO.getCountryCd()), trimToEmpty(objVO.getHomePhoneNbr()),
					trimToEmpty(objVO.getWorkPhoneNbr()), trimToEmpty(objVO.getCellPhoneNbr()),
					trimToEmpty(objVO.getFaxNbr()), ts, trimToEmpty(objVO.getCreateUserId()), ts,
					trimToEmpty(objVO.getLastUpdtUserId()), };
			objVO.setCreateTime(ts);
			objVO.setLastUpdtTime(ts);

			return jdbcTemplate.update(sQuery, parms);

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->insertAddressDetails:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public int updateAddressDetails(EEMApplAddressDO objVO) throws ApplicationException {

		String ts = DateUtil.getCurrentDatetimeStamp();
		try {
			String sQuery = "UPDATE EM_APPL_ADDRESS SET ADDRESS1=?, ADDRESS2=?, ADDRESS3=?, CITY=?, "
					+ "STATE_CD=?, ZIP_CD=?, COUNTY_CD=?, COUNTRY_CD=?, HOME_PHONE_NBR=?, "
					+ "WORK_PHONE_NBR=?, CELL_PHONE_NBR=?, FAX_NBR=?, " + "LAST_UPDT_TIME=?, LAST_UPDT_USERID=? "
					+ "WHERE CUSTOMER_ID=? AND APPLICATION_ID=? " + "AND ADDRESS_TYPE=? AND LAST_UPDT_TIME=?";
			Object[] parms = new Object[] { trimToEmpty(objVO.getAddress1()), trimToEmpty(objVO.getAddress2()),
					trimToEmpty(objVO.getAddress3()), trimToEmpty(objVO.getCity()), trimToEmpty(objVO.getStateCd()),
					trimToEmpty(objVO.getZipCd()), trimToEmpty(objVO.getCountyCd()), trimToEmpty(objVO.getCountryCd()),
					trimToEmpty(objVO.getHomePhoneNbr()), trimToEmpty(objVO.getWorkPhoneNbr()),
					trimToEmpty(objVO.getCellPhoneNbr()), trimToEmpty(objVO.getFaxNbr()), ts,
					trimToEmpty(objVO.getLastUpdtUserId()), trimToEmpty(objVO.getCustomerId()), objVO.getApplId(),
					trimToEmpty(objVO.getAddressType()), trimToEmpty(objVO.getLastUpdtTime()) };
			objVO.setLastUpdtTime(ts);
			return jdbcTemplate.update(sQuery, parms);

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->updateAddressDetails:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public int deleteAddressDetails(EEMApplAddressDO objVO) throws ApplicationException {

		try {
			String sQuery = "DELETE FROM EM_APPL_ADDRESS " + "WHERE CUSTOMER_ID=? AND APPLICATION_ID=? "
					+ "AND ADDRESS_TYPE=? AND LAST_UPDT_TIME=?";

			return jdbcTemplate.update(sQuery, new Object[] { trimToEmpty(objVO.getCustomerId()), objVO.getApplId(),
					trimToEmpty(objVO.getAddressType()), trimToEmpty(objVO.getLastUpdtTime()) });

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->deleteAddressDetails:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public int insertOtherCovDetails(EEMApplOtherCovDO objVO, String customerId, int applId, String userId)
			throws ApplicationException {

		String ts = DateUtil.getCurrentDatetimeStamp();
		int seqNo = getOtherCovSeqNo(customerId, applId);
		try {
			String sQuery = "INSERT INTO EM_APPL_OTHER_COV (CUSTOMER_ID, APPLICATION_ID, "
					+ "OTHER_COV_SEQ_NBR, ESRD_IND, PCO_IND, DIALYSIS_IND, MEDICAID_IND, "
					+ "SPOUSE_WORK_IND, SEC_RX_IND, SEC_RX_ID, SEC_RX_NAME, SEC_RX_GRP, "
					+ "LTC_INST_IND, LTC_FAC_ID, CREATE_TIME, CREATE_USERID, "
					+ "LAST_UPDT_TIME, LAST_UPDT_USERID, SEC_RX_BIN, SEC_RX_PCN, " + "MEDICAID_ID) VALUES ("
					+ "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

			Object[] parms = new Object[] { trimToEmpty(customerId), applId, seqNo, trimToEmpty(objVO.getEsrd()),
					trimToEmpty(objVO.getPcoInd()), trimToEmpty(objVO.getDialysis()),
					trimToEmpty(objVO.getStMedicaid()), trimToEmpty(objVO.getSpouseWork()),
					trimToEmpty(objVO.getSecRxInd()), trimToEmpty(objVO.getCovId()), trimToEmpty(objVO.getOtherCov()),
					trimToEmpty(objVO.getGroupNo()), trimToEmpty(objVO.getLtcInstInd()),
					trimToEmpty(objVO.getNameInstitute()), ts, trimToEmpty(userId), ts, trimToEmpty(userId),
					trimToEmpty(objVO.getCovBin()), trimToEmpty(objVO.getCovPcn()),
					trimToEmpty(objVO.getMedicaidId()) };

			objVO.setLastUpdtTime(ts);
			return jdbcTemplate.update(sQuery, parms);

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->insertOtherCovDetails:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public int updateOtherCovDetails(EEMApplOtherCovDO objVO, String customerId, int applId, String userId)
			throws ApplicationException {
		String ts = DateUtil.getCurrentDatetimeStamp();
		try {
			String sQuery = "UPDATE EM_APPL_OTHER_COV SET ESRD_IND=?, PCO_IND=?, DIALYSIS_IND=?, "
					+ "MEDICAID_IND=?, SPOUSE_WORK_IND=?, SEC_RX_IND=?, SEC_RX_ID=?, SEC_RX_NAME=?, "
					+ "SEC_RX_GRP=?, LTC_INST_IND=?, LTC_FAC_ID=?, "
					+ "LAST_UPDT_TIME=?, LAST_UPDT_USERID=?, SEC_RX_BIN=?, SEC_RX_PCN=?," + "MEDICAID_ID=? "
					+ "WHERE CUSTOMER_ID=? AND APPLICATION_ID=? AND LAST_UPDT_TIME=?";

			Object[] parms = new Object[] { trimToEmpty(objVO.getEsrd()), trimToEmpty(objVO.getPcoInd()),
					trimToEmpty(objVO.getDialysis()), trimToEmpty(objVO.getStMedicaid()),
					trimToEmpty(objVO.getSpouseWork()), trimToEmpty(objVO.getSecRxInd()), trimToEmpty(objVO.getCovId()),
					trimToEmpty(objVO.getOtherCov()), trimToEmpty(objVO.getGroupNo()),
					trimToEmpty(objVO.getLtcInstInd()), trimToEmpty(objVO.getNameInstitute()), ts, trimToEmpty(userId),
					trimToEmpty(objVO.getCovBin()), trimToEmpty(objVO.getCovPcn()), trimToEmpty(objVO.getMedicaidId()),
					trimToEmpty(customerId), applId, trimToEmpty(objVO.getLastUpdtTime()), };

			objVO.setLastUpdtTime(ts);
			return jdbcTemplate.update(sQuery, parms);

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->updateOtherCovDetails:{}", e);
			throw new ApplicationException(e);
		}

	}

	private int getOtherCovSeqNo(String customerId, int applId) throws ApplicationException {

		int seqNo = -1;
		try {
			String sQuery = "SELECT OTHER_COV_SEQ_NBR  FROM EM_APPL_OTHER_COV " + "WHERE CUSTOMER_ID = ? "
					+ "AND APPLICATION_ID = ?  ORDER BY OTHER_COV_SEQ_NBR DESC FETCH FIRST ROW ONLY";

			seqNo = jdbcTemplate.queryForObject(sQuery, new Object[] { customerId, applId }, Integer.class);

			return ++seqNo;
		} catch (EmptyResultDataAccessException exp) {
			return 1;
		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->insertOtherCovDetails:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public int insertPCPDetails(EEMApplOtherPlanDO objVO, String userId, String rqDtCov, String lineOfBiz)
			throws ApplicationException {

		String ts = DateUtil.getCurrentDatetimeStamp();
		try {
			String sQuery = "INSERT INTO EM_APPL_OTHER_PLAN (CUSTOMER_ID, APPLICATION_ID, EFF_START_DATE, "
					+ "OFFICE_CATEGORY_CD, EFF_END_DATE, OFFICE_CD, CURRENT_PATIENT_IND, "
					+ "PREMIUM_AMT, CREATE_TIME, CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID, " + "LOCATION_ID) "
					+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";

			String[] dates = getPCPDates(objVO, rqDtCov, lineOfBiz);
			Object[] parms = new Object[] { trimToEmpty(objVO.getCustomerId()), objVO.getApplId(),
					trimToEmpty(dates[0]), trimToEmpty(objVO.getOfficeCategoryCd()), trimToEmpty(dates[1]),
					trimToEmpty(objVO.getOfficeCd()), trimToEmpty(objVO.getCurrentPatientInd()), trimToEmpty("0"), ts,
					trimToEmpty(userId), ts, trimToEmpty(userId), trimToEmpty(objVO.getLocationId()) };
			objVO.setLastUpdtTime(ts);

			return jdbcTemplate.update(sQuery, parms);

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->insertPCPDetails:{}", e);
			throw new ApplicationException(e);
		}

	}

	private String[] getPCPDates(EEMApplOtherPlanDO objVO, String reqDtCov, String lineOfBiz)
			throws ApplicationException {
		String[] dates = new String[2];
		try {
			String sQuery = "SELECT OFFICE_START_DATE, OFFICE_END_DATE " + "FROM EM_MED_OFFICE "
					+ "WHERE CUSTOMER_ID = ? " + "AND OFFICE_CD = ? " + "AND OFFICE_CATEGORY_CD = ? "
					+ "AND ? BETWEEN OFFICE_START_DATE AND OFFICE_END_DATE " + "AND LINE_OF_BIZ IN ('', ?) ";

			List<Map<String, Object>> list = jdbcTemplate.queryForList(sQuery,
					new Object[] { objVO.getCustomerId(), objVO.getOfficeCd(), objVO.getOfficeCategoryCd(),
							DateUtil.changedDateFormatForMonth(reqDtCov), trimToEmpty(lineOfBiz) });

			if (!list.isEmpty()) {
				Map<String, Object> queryForMap = list.get(0);
				dates[0] = trimToEmpty((String) queryForMap.get("OFFICE_START_DATE"));
				dates[1] = trimToEmpty((String) queryForMap.get("OFFICE_END_DATE"));
			}

		} catch (EmptyResultDataAccessException exp) {
			return dates;
		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->getPCPDates:{}", e);
			throw new ApplicationException(e);
		}

		return dates;
	}

	@Override
	public int deletePCPDetails(EEMApplOtherPlanDO objVO) throws ApplicationException {

		try {
			String sQuery = "DELETE FROM EM_APPL_OTHER_PLAN "
					+ "WHERE CUSTOMER_ID=? AND APPLICATION_ID=? AND LAST_UPDT_TIME=?";

			int res = jdbcTemplate.update(sQuery, new Object[] { trimToEmpty(objVO.getCustomerId()), objVO.getApplId(),
					trimToEmpty(objVO.getLastUpdtTime()) });
			if (res > 0) {
				objVO.setLastUpdtUserId("");
				objVO.setOfficeCd("");
				objVO.setLocationId("");
			}
			return res;

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->deletePCPDetails:{}", e);
			throw new ApplicationException(e);
		}
	}

	@Override
	public int updatePCPDetails(EEMApplOtherPlanDO objVO, String rqDtCov, String lineOfBiz, String userId)
			throws ApplicationException {

		String ts = DateUtil.getCurrentDatetimeStamp();
		try {
			String sQuery = "UPDATE EM_APPL_OTHER_PLAN SET EFF_START_DATE=?, OFFICE_CATEGORY_CD=?, "
					+ "EFF_END_DATE=?, OFFICE_CD=?, CURRENT_PATIENT_IND=?, "
					+ "LAST_UPDT_TIME=?, LAST_UPDT_USERID=?, LOCATION_ID=? "
					+ "WHERE CUSTOMER_ID=? AND APPLICATION_ID=? AND LAST_UPDT_TIME=?";

			String[] dates = getPCPDates(objVO, rqDtCov, lineOfBiz);
			Object[] parms = new Object[] { trimToEmpty(dates[0]), trimToEmpty(objVO.getOfficeCategoryCd()),
					trimToEmpty(dates[1]), trimToEmpty(objVO.getOfficeCd()), trimToEmpty(objVO.getCurrentPatientInd()),
					ts, trimToEmpty(userId), trimToEmpty(objVO.getLocationId()), trimToEmpty(objVO.getCustomerId()),
					objVO.getApplId(), trimToEmpty(objVO.getLastUpdtTime()) };
			objVO.setLastUpdtTime(ts);
			return jdbcTemplate.update(sQuery, parms);

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->updatePCPDetails:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public int insertAttestationDetails(String customerId, int applId, String seqNo, String exception, String attestDt,
			String userId) throws ApplicationException {

		try {
			String sQuery = "INSERT INTO EM_APPL_ATTESTATION (CUSTOMER_ID, APPLICATION_ID, "
					+ "ATTESTATION_SEQ_NBR, ATTEST_IND, ATTEST_DATE, DELETE_IND, "
					+ "CREATE_TIME, CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID) " + "VALUES (?,?,?,?,?,?,?,?,?,?)";

			Object[] parms = new Object[] { trimToEmpty(customerId), applId, trimToEmpty(seqNo), trimToEmpty(exception),
					DateUtil.changedDateFormatForMonth(trimToEmpty(attestDt)), trimToEmpty("N"),
					DateUtil.getCurrentDatetimeStamp(), trimToEmpty(userId), DateUtil.getCurrentDatetimeStamp(),
					trimToEmpty(userId) };

			return jdbcTemplate.update(sQuery, parms);

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->insertAttestationDetails:{}", e);
			throw new ApplicationException(e);
		}
	}

	@Override
	public int updateAttestationDetails(String customerId, int applId, String attestInd, String attestDt, String userId)
			throws ApplicationException {

		try {
			String sQuery = "UPDATE EM_APPL_ATTESTATION SET ATTEST_DATE=?, " + "LAST_UPDT_TIME=?, LAST_UPDT_USERID=? "
					+ "WHERE CUSTOMER_ID=? AND APPLICATION_ID=? " + "AND ATTEST_IND=? AND DELETE_IND = 'N' ";

			Object[] parms = new Object[] { DateUtil.changedDateFormatForMonth(trimToEmpty(attestDt)),
					DateUtil.getCurrentDatetimeStamp(), trimToEmpty(userId), trimToEmpty(customerId), applId,
					trimToEmpty(attestInd) };

			return jdbcTemplate.update(sQuery, parms);

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->updateAttestationDetails:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public int deleteAttestationDetails(String customerId, int applId, String attestInd, String attestDt, String userId)
			throws ApplicationException {

		try {
			String sQuery = "UPDATE EM_APPL_ATTESTATION SET DELETE_IND=?, " + "LAST_UPDT_TIME=?, LAST_UPDT_USERID=? "
					+ "WHERE CUSTOMER_ID=? AND APPLICATION_ID=? "
					+ "AND ATTEST_IND=? AND ATTEST_DATE=? AND DELETE_IND = 'N'";

			Object[] parms = new Object[] { trimToEmpty("Y"), DateUtil.getCurrentDatetimeStamp(), trimToEmpty(userId),
					trimToEmpty(customerId), applId, trimToEmpty(attestInd),
					DateUtil.changedDateFormatForMonth(trimToEmpty(attestDt)), };

			return jdbcTemplate.update(sQuery, parms);

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->deleteAttestationDetails:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public boolean checkApplAgent(String customerId, int applId, String lstUpdtTime) throws ApplicationException {

		try {
			String sQuery = "SELECT LAST_UPDT_TIME FROM EM_APPL_AGENT "
					+ " WHERE CUSTOMER_ID = ? AND APPLICATION_ID=? FETCH FIRST ROW ONLY";

			lstUpdtTime = jdbcTemplate.queryForObject(sQuery, new Object[] { customerId, applId }, String.class);

			return true;

			// Begin: Modified for IFOX-00403086
			// Because of below while loop, system pulling last updated time of other
			// agents,
			// causing foriegn key violation on EM_APPL_AGENT during application update.

			// while (rs.next()) {
		} catch (EmptyResultDataAccessException exp) {
			return false;
		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->checkApplAgent:{}", e);
			throw new ApplicationException(e);
		}
	}

	@Override
	public int insertAgentDetails(EEMApplAgentDO objVO, String customerId, int applId, String userId)
			throws ApplicationException {

		String ts = DateUtil.getCurrentDatetimeStamp();
		try {
			String sQuery = "INSERT INTO EM_APPL_AGENT (CUSTOMER_ID, APPLICATION_ID, AGENCY_ID, "
					+ "AGENT_ID, AGENT_DATE, CREATE_TIME, CREATE_USERID, " + "LAST_UPDT_TIME, LAST_UPDT_USERID) "
					+ "VALUES (?,?,?,?,?,?,?,?,?)";

			Object[] parms = new Object[] { trimToEmpty(customerId), applId,
					objVO.getCommAgencyId() != null ? trimToEmpty(objVO.getCommAgencyId().split("-")[0]) : "",
					trimToEmpty(objVO.getBrokAgentId()),
					DateUtil.changedDateFormatForMonth(trimToEmpty(objVO.getAgentDt())), ts, trimToEmpty(userId), ts,
					trimToEmpty(userId) };
			objVO.setLastUpdtTime(ts);
			return jdbcTemplate.update(sQuery, parms);

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->insertAgentDetails:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public int updateAgentDetails(EEMApplAgentDO objVO, String customerId, int applId, String userId)
			throws ApplicationException {

		String ts = DateUtil.getCurrentDatetimeStamp();
		try {
			String sQuery = "UPDATE EM_APPL_AGENT SET AGENCY_ID=?, AGENT_ID=?, "
					+ "AGENT_DATE=?, LAST_UPDT_TIME=?, LAST_UPDT_USERID=? "
					+ "WHERE CUSTOMER_ID=? AND APPLICATION_ID=? AND LAST_UPDT_TIME=?";

			Object[] parms = new Object[] {
					objVO.getCommAgencyId() != null ? trimToEmpty(objVO.getCommAgencyId().split("-")[0]) : "",
					trimToEmpty(objVO.getBrokAgentId()),
					DateUtil.changedDateFormatForMonth(trimToEmpty(objVO.getAgentDt())), ts, userId,
					trimToEmpty(customerId), applId, trimToEmpty(objVO.getLastUpdtTime()) };

			objVO.setLastUpdtTime(ts);
			return jdbcTemplate.update(sQuery, parms);

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->updateAgentDetails:{}", e);
			throw new ApplicationException(e);
		}
	}

	@Override
	public int deleteApplAgentDetails(String customerId, int applId) throws ApplicationException {

		try {
			String sQuery = "DELETE FROM EM_APPL_AGENT where CUSTOMER_ID=? And APPLICATION_ID=?";

			return jdbcTemplate.update(sQuery, new Object[] { customerId, applId });

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->deleteApplAgentDetails:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public int insertEligDetailsNotInMBD(EEMApplEligibilityDO objVO, EEMApplicationDO applDO, String userId)
			throws ApplicationException {

		objVO.setLastChkedTime(DateUtil.getCurrentDatetimeStamp());
		try {
			// BEQ Short term Solution --Start
			String sQuery = "INSERT INTO EM_APPL_ELIGIBILITY (CUSTOMER_ID, APPLICATION_ID, "
					+ "LAST_CHECKED_TIME, HIC_NBR, LAST_NAME, FIRST_NAME, MIDDLE_INIT, "
					+ "GENDER_NUM_CD, BIRTH_DATE, LIVING_STATUS, DEATH_DATE, PRTA_ENTITLE_DATE, "
					+ "PRTB_ENTITLE_DATE, PRTD_ELIG_SDATE, PRTA_OPTION, PRTB_OPTION, "
					+ "ENROLLMENT_STATUS, HOSPICE_IND, HOSPICE_SDATE, HOSPICE_EDATE, "
					+ "INSTITUTIONAL_IND, INST_SDATE, INST_EDATE, ESRD_IND, ESRD_SDATE, "
					+ "ESRD_EDATE, WRKAGED_IND, WRKAGED_SDATE, WRKAGED_EDATE, MEDIC_IND, "
					+ "MEDIC_SDATE, MEDIC_EDATE, RACE_CD, STATE_CD, COUNTY_CD, "
					+ "ELIGIBILITY_SOURCE, LAST_UPDT_USERID, PRTA_ENTITLE_EDATE, PRTB_ENTITLE_EDATE, "
					+ "CALC_UNCOV_MONTHS,ELIG_OVERRIDE_IND) "
					+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?," + "?,?,?,?,?,?,?,?,?,?,?)";
			String prtAStDt = DateUtil.changedDateFormatForMonth(trimToEmpty(objVO.getPartAEffDate()));
			String prtBStDt = DateUtil.changedDateFormatForMonth(trimToEmpty(objVO.getPartBEffDate()));
			String prtDDate = DateUtil.changedDateFormatForMonth(trimToEmpty(objVO.getPartDEffDate()));

			String hic_nbr = "";
			if (StringUtil.isHicOrMbi(applDO.getMbrHicNbr()).equals("hic"))
				hic_nbr = trimToEmpty(applDO.getMbrHicNbr());
			else
				hic_nbr = trimToEmpty(applDO.getDisplayHic());

			Object[] parms = new Object[] { trimToEmpty(applDO.getCustomerId()), applDO.getApplId(),
					trimToEmpty(objVO.getLastChkedTime()), hic_nbr, trimToEmpty(applDO.getMbrLastName()),
					trimToEmpty(applDO.getMbrFirstName()), trimToEmpty(applDO.getMbrMiddleName()),
					trimToEmpty(applDO.getMbrGender()),
					DateUtil.changedDateFormatForMonth(trimToEmpty(applDO.getMbrBirthDt())), "", "",

					DateUtil.changedDateFormatForMonth(trimToEmpty(prtAStDt)),
					DateUtil.changedDateFormatForMonth(trimToEmpty(prtBStDt)),
					DateUtil.changedDateFormatForMonth(trimToEmpty(prtDDate)), "", "", "", "", "", "", "", "", "", "",
					"", "", "", "", "", "", "", "", "", "", "", "APPL", trimToEmpty(userId),

					DateUtil.changedDateFormatForMonth(trimToEmpty("99999999")),
					DateUtil.changedDateFormatForMonth(trimToEmpty("99999999")), "", trimToEmpty("Y") };

			return jdbcTemplate.update(sQuery, parms);

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->insertEligDetailsNotInMBD:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public int insertEligDetails(EEMApplEligibilityDO objVO, MBD mbd, String customerId, int applId, String userId)
			throws ApplicationException {

		try {
			String sQuery = "INSERT INTO EM_APPL_ELIGIBILITY (CUSTOMER_ID, APPLICATION_ID, "
					+ "LAST_CHECKED_TIME, HIC_NBR, LAST_NAME, FIRST_NAME, MIDDLE_INIT, "
					+ "GENDER_NUM_CD, BIRTH_DATE, LIVING_STATUS, DEATH_DATE, PRTA_ENTITLE_DATE, "
					+ "PRTB_ENTITLE_DATE, PRTD_ELIG_SDATE, PRTA_OPTION, PRTB_OPTION, "
					+ "ENROLLMENT_STATUS, HOSPICE_IND, HOSPICE_SDATE, HOSPICE_EDATE, "
					+ "INSTITUTIONAL_IND, INST_SDATE, INST_EDATE, ESRD_IND, ESRD_SDATE, "
					+ "ESRD_EDATE, WRKAGED_IND, WRKAGED_SDATE, WRKAGED_EDATE, MEDIC_IND, "
					+ "MEDIC_SDATE, MEDIC_EDATE, RACE_CD, STATE_CD, COUNTY_CD, "
					+ "ELIGIBILITY_SOURCE, LAST_UPDT_USERID, PRTA_ENTITLE_EDATE, PRTB_ENTITLE_EDATE, "
					+ "CALC_UNCOV_MONTHS,ELIG_OVERRIDE_IND) "
					+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?," + "?,?,?,?,?,?,?,?,?,?,?)";

			// System.out.println("Query -> " + sQuery);

			// Added for SSNRI 2017 : start
			String isHicOrMbi = "";
			String hic_nbr = "";
			if (!trimToEmpty(mbd.getMbi()).equals("")) {
				isHicOrMbi = "mbi";
			} else {
				isHicOrMbi = "hic";
			}
			if (isHicOrMbi.equalsIgnoreCase("mbi") && !trimToEmpty(mbd.getMbi()).equals(""))
				hic_nbr = trimToEmpty(mbd.getMbi());
			else
				hic_nbr = trimToEmpty(mbd.getHicNbr());

			String prtAStDt = DateUtil.changedDateFormatForMonth(trimToEmpty(objVO.getPartAEffDate()));
			String prtBStDt = DateUtil.changedDateFormatForMonth(trimToEmpty(objVO.getPartBEffDate()));
			String prtDDate = DateUtil.changedDateFormatForMonth(trimToEmpty(objVO.getPartDEffDate()));

			String prtAMbd = DateUtil.changedDateFormatForMonth(trimToEmpty(mbd.getPrtAEntitleDate()));
			String prtBMbd = DateUtil.changedDateFormatForMonth(trimToEmpty(mbd.getPrtBEntitleDate()));
			String prtDMbd = DateUtil.changedDateFormatForMonth(trimToEmpty(mbd.getPrtDEligibleDate()));

			String parm12 = "";
			String parm13 = "";
			String parm14 = "";

			String partAEndDate = mbd.getPrtAEntitleEndDate();
			String partBEndDate = mbd.getPrtBEntitleEndDate();
			if (!((trimToEmpty(prtAStDt).equalsIgnoreCase(trimToEmpty(prtAMbd)))
					&& (trimToEmpty(prtBStDt).equalsIgnoreCase(trimToEmpty(prtBMbd)))
					&& (trimToEmpty(prtDDate).equalsIgnoreCase(trimToEmpty(prtDMbd))))) {
				if (!trimToEmpty(prtAStDt).equalsIgnoreCase(trimToEmpty(prtAMbd))) {
					partAEndDate = "99999999";
				}

				if (!trimToEmpty(prtBStDt).equalsIgnoreCase(trimToEmpty(prtBMbd))) {
					partBEndDate = "99999999";
				}
				parm12 = DateUtil.changedDateFormatForMonth(trimToEmpty(objVO.getPartAEffDate()));

				parm13 = DateUtil.changedDateFormatForMonth(trimToEmpty(objVO.getPartBEffDate()));

				parm14 = DateUtil.changedDateFormatForMonth(trimToEmpty(objVO.getPartDEffDate()));

			} else {
				parm12 = DateUtil.changedDateFormatForMonth(trimToEmpty(mbd.getPrtAEntitleDate()));

				parm13 = DateUtil.changedDateFormatForMonth(trimToEmpty(mbd.getPrtBEntitleDate()));

				parm14 = DateUtil.changedDateFormatForMonth(trimToEmpty(mbd.getPrtDEligibleDate()));

			}

			Object[] parms = new Object[] { trimToEmpty(customerId), applId, trimToEmpty(objVO.getLastChkedTime()),
					hic_nbr, trimToEmpty(mbd.getLastName()), trimToEmpty(mbd.getFirstName()),
					trimToEmpty(mbd.getMiddleInit()), trimToEmpty(mbd.getGenderCd()),
					DateUtil.changedDateFormatForMonth(trimToEmpty(mbd.getBirthDate())),
					trimToEmpty(mbd.getLivingStatus()),
					DateUtil.changedDateFormatForMonth(trimToEmpty(mbd.getDeathDate())), parm12, parm13, parm14,
					trimToEmpty(mbd.getPrtAOption()), trimToEmpty(mbd.getPrtBOption()),
					trimToEmpty(mbd.getEnrollmentStatus()), trimToEmpty(mbd.getHospiceInd()),
					DateUtil.changedDateFormatForMonth(trimToEmpty(mbd.getHospiceStartDate())),
					DateUtil.changedDateFormatForMonth(trimToEmpty(mbd.getHospiceEndDate())),
					trimToEmpty(mbd.getInstInd()),
					DateUtil.changedDateFormatForMonth(trimToEmpty(mbd.getInstStartDate())),
					DateUtil.changedDateFormatForMonth(trimToEmpty(mbd.getInstEndDate())),
					trimToEmpty(mbd.getEsrdInd()),
					DateUtil.changedDateFormatForMonth(trimToEmpty(mbd.getEsrdStartDate())),
					DateUtil.changedDateFormatForMonth(trimToEmpty(mbd.getEsrdEndDate())),
					trimToEmpty(mbd.getWrkagedInd()), trimToEmpty(mbd.getWrkagedStartDate()),
					trimToEmpty(mbd.getWrkagedEndDate()), trimToEmpty(mbd.getMedicInd()),
					DateUtil.changedDateFormatForMonth(trimToEmpty(mbd.getMedicStartDate())),
					DateUtil.changedDateFormatForMonth(trimToEmpty(mbd.getMedicEndDate())),
					trimToEmpty(mbd.getRaceCd()), trimToEmpty(mbd.getStateCd()), trimToEmpty(mbd.getCountyCd()),
					trimToEmpty("MBD"), trimToEmpty(userId), DateUtil.changedDateFormatForMonth(partAEndDate),
					DateUtil.changedDateFormatForMonth(partBEndDate), trimToEmpty(mbd.getUncovMonths()),
					trimToEmpty(objVO.getEligOverInd()) };
			return jdbcTemplate.update(sQuery, parms);

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->insertEligDetails:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public EEMBeqDO getBEQDetailsFor(String customerId, int applId, String hicNbr, String dob)
			throws ApplicationException {

		EEMBeqDO beq = null;

		try {
			// only HIC and DOB are used by CMS for matching
			String sQuery = "SELECT CUSTOMER_ID, RECORD_ID, LAST_UPDT_TIME,"
					+ " PLAN_ID, HIC_NBR, LAST_NAME, FIRST_NAME, BIRTH_DATE," + " BEQ_STATUS, LAST_UPDT_USERID"
					+ " FROM EM_BEQ" + " WHERE CUSTOMER_ID = ? AND RECORD_ID = ?"
					+ " AND HIC_NBR = ? AND BIRTH_DATE = ?" + " ORDER BY LAST_UPDT_TIME DESC"
					+ " FETCH FIRST 1 ROWS ONLY";

			Object[] parms = new Object[] { trimToEmpty(customerId), applId, trimToEmpty(hicNbr),
					DateFormatter.reFormat(trimToEmpty(dob), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD) };

			Map<String, Object> rs = jdbcTemplate.queryForMap(sQuery, parms);
			if (!rs.isEmpty()) {
				beq = new EEMBeqDO();
				beq.setCustomerId(trimToEmpty((String) rs.get("CUSTOMER_ID")));
				beq.setRecordId(trimToEmpty((String) rs.get("RECORD_ID")));
				// beq.setLastUpdtTime(trimToEmpty((rs.get("LAST_UPDT_TIME")));
				beq.setPlanId(trimToEmpty((String) rs.get("PLAN_ID")));
				beq.setHicNbr(trimToEmpty((String) rs.get("HIC_NBR")));
				beq.setLastName(trimToEmpty((String) rs.get("LAST_NAME")));
				beq.setFirstName(trimToEmpty((String) rs.get("FIRST_NAME")));
				beq.setLastName(trimToEmpty((String) rs.get("BIRTH_DATE")));
				beq.setBeqStatus(trimToEmpty((String) rs.get("BEQ_STATUS")));
				beq.setLastUpdtUserid(trimToEmpty((String) rs.get("LAST_UPDT_USERID")));
			}

		} catch (EmptyResultDataAccessException exp) {
			return null;
		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->getBEQDetailsFor:{}", e);
			throw new ApplicationException(e);
		}
		return beq;
	}

	@Override
	public int insertBEQDetails(EEMApplicationDO objVO, String planId, String userId) throws ApplicationException {

		try {
			String sQuery = "INSERT INTO EM_BEQ (CUSTOMER_ID, RECORD_ID, CREATE_TIME,"
					+ "PLAN_ID, HIC_NBR, LAST_NAME, FIRST_NAME, BIRTH_DATE, "
					+ "APPL_MBRSHIP_IND, BEQ_STATUS, CREATE_USERID, LAST_UPDT_USERID, LAST_UPDT_TIME) "
					+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";

			String ts = DateUtil.getCurrentDatetimeStamp();

			Object[] parms = new Object[] { trimToEmpty(objVO.getCustomerId()), objVO.getApplId(), ts,
					trimToEmpty(planId), trimToEmpty(objVO.getMbrHicNbr()), trimToEmpty(objVO.getMbrLastName()),
					trimToEmpty(objVO.getMbrFirstName()),
					DateFormatter.reFormat(trimToEmpty(objVO.getMbrBirthDt()), DateFormatter.MM_DD_YYYY,
							DateFormatter.YYYYMMDD),
					"A", trimToEmpty("PEND"), trimToEmpty(userId), trimToEmpty(userId), ts };

			return jdbcTemplate.update(sQuery, parms);

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->insertBEQDetails:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public int insertErrorDetails(EEMApplErrorDO objVO, String userId) throws ApplicationException {

		int rows = 0;
		try {
			String sQuery = CommonUtils.buildQuery("INSERT INTO EM_APPL_ERROR (CUSTOMER_ID, APPLICATION_ID,",
					"ERROR_SEQ_NBR, ERROR_CD, FIELD_NBR, ERROR_DATA, ERROR_STATUS,",
					"RFI_IND, LAST_UPDT_TIME, LAST_UPDT_USERID, CREATE_TIME)",
					"VALUES (?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)");

			Object[] parms = new Object[] { trimToEmpty(objVO.getCustomerId()), objVO.getApplicationId(),
					getErrorSeqNo(objVO.getCustomerId(), objVO.getApplicationId()), trimToEmpty(objVO.getErrorCd()),
					trimToEmpty(objVO.getFieldNbr()), trimToEmpty(objVO.getErrorData()), trimToEmpty("OPEN"),
					trimToEmpty(objVO.getRfiInd()), DateUtil.getCurrentDatetimeStamp(), trimToEmpty(userId) };

			rows = jdbcTemplate.update(sQuery, parms);

			// Workflow change starts
			if (rows != 0) {
				workFlowDAO.insertActivityWhileInsertError(objVO.getCustomerId(), objVO.getErrorCd(),
						Integer.toString(objVO.getApplicationId()), objVO.getErrorMsg(), userId);
			}
			// Workflow change ends

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->insertErrorDetails:{}", e);
			throw new ApplicationException(e);
		}

		return rows;
	}

	private int getErrorSeqNo(String customerId, int applId) throws ApplicationException {

		try {
			String sQuery = CommonUtils.buildQuery("SELECT ERROR_SEQ_NBR  FROM EM_APPL_ERROR WHERE CUSTOMER_ID = ?",
					"AND APPLICATION_ID = ? ORDER BY ERROR_SEQ_NBR DESC FETCH FIRST ROW ONLY");

			try {
				int seqNbr = jdbcTemplate.queryForObject(sQuery, new Object[] { customerId, applId }, Integer.class);
				return ++seqNbr;

			} catch (EmptyResultDataAccessException exp) {
				return 1;
			}

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->getErrorSeqNo:{}", e);
			throw new ApplicationException(e);
		}
	}

	@Override
	public int updateErrorDetails(EEMApplErrorDO errorDO, String userId) throws ApplicationException {

		int rows = 0;
		try {
			String sQuery = CommonUtils.buildQuery("UPDATE EM_APPL_ERROR SET ERROR_DATA=?, ERROR_STATUS=?,",
					"RFI_IND=?, LAST_UPDT_TIME=?, LAST_UPDT_USERID=?",
					"WHERE CUSTOMER_ID=? AND APPLICATION_ID=? AND FIELD_NBR=?",
					"AND ERROR_CD=? AND ERROR_STATUS != 'CLOSED' AND LTRIM(ERROR_DATA)=?");

			Object[] parms = new Object[] { trimToEmpty(errorDO.getErrorData()), trimToEmpty(errorDO.getErrorStatus()),
					trimToEmpty(errorDO.getRfiInd()), DateUtil.getCurrentDatetimeStamp(), trimToEmpty(userId),
					trimToEmpty(errorDO.getCustomerId()), errorDO.getApplicationId(),
					trimToEmpty(errorDO.getFieldNbr()), trimToEmpty(errorDO.getErrorCd()),
					trimToEmpty(errorDO.getErrorData()) };

			rows = jdbcTemplate.update(sQuery, parms);

			/* Workflow change starts */

			if (rows != 0 && null != errorDO.getErrorStatus()
					&& errorDO.getErrorStatus().equalsIgnoreCase(EEMConstants.ERROR_STATUS_CLOSED)) {
				workFlowDAO.updateActivityWhileUpdatingError(errorDO.getCustomerId(), errorDO.getErrorCd(),
						Integer.toString(errorDO.getApplicationId()), errorDO.getErrorMsg(), userId);
			}

			/* Workflow change ends */

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->updateErrorDetails:{}", e);
			throw new ApplicationException(e);
		}

		return rows;
	}

	@Override
	public int insertLisDetails(EEMApplLisDO objVO, String customerId, int applId, String userId)
			throws ApplicationException {

		String ts = DateUtil.getCurrentDatetimeStamp();
		try {
			String sQuery = "INSERT INTO EM_APPL_LIS (CUSTOMER_ID, APPLICATION_ID, EFF_START_DATE, "
					+ "EFF_END_DATE, LI_COPAY_CD, LIS_PCT_CD, CREATE_TIME, CREATE_USERID, "
					+ "LAST_UPDT_TIME, LAST_UPDT_USERID, OVERRIDE_IND) " + "VALUES (?,?,?,?,?,?,?,?,?,?,?)";
			Object[] parms = new Object[] { trimToEmpty(customerId), applId,
					DateFormatter.reFormat(trimToEmpty(objVO.getEffStartDt()), DateFormatter.MM_DD_YYYY,
							DateFormatter.YYYYMMDD),
					DateFormatter.reFormat(trimToEmpty(objVO.getEffEndDt()), DateFormatter.MM_DD_YYYY,
							DateFormatter.YYYYMMDD),
					trimToEmpty(objVO.getLiCoPayCd()), trimToEmpty(objVO.getLisPctCd()), ts, trimToEmpty(userId), ts,
					trimToEmpty(userId), "N" };

			return jdbcTemplate.update(sQuery, parms);

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->insertLisDetails:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public int updateLisDetails(EEMApplLisDO objVO, String customerId, int applId, String userId)
			throws ApplicationException {

		try {
			String sQuery = "UPDATE EM_APPL_LIS SET OVERRIDE_IND ='Y', LAST_UPDT_TIME =?, LAST_UPDT_USERID =? "
					+ "WHERE CUSTOMER_ID =? AND APPLICATION_ID =? AND OVERRIDE_IND ='N' ";

			Object[] parms = new Object[] { DateUtil.getCurrentDatetimeStamp(), userId, trimToEmpty(customerId),
					applId };
			return jdbcTemplate.update(sQuery, parms);

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->insertLisDetails:{}", e);
			throw new ApplicationException(e);
		}
	}

	@Override
	public boolean checkLISStatus(EEMApplLisDO objVO, String customerId, int applId) throws ApplicationException {

		try {
			String sQuery = "SELECT LI_COPAY_CD FROM EM_APPL_LIS"
					+ " WHERE CUSTOMER_ID =? AND APPLICATION_ID =? AND EFF_START_DATE =? AND EFF_END_DATE=? AND  OVERRIDE_IND ='N'";

			Object[] parms = new Object[] { customerId, applId,
					DateFormatter.reFormat(trimToEmpty(objVO.getEffStartDt()), DateFormatter.MM_DD_YYYY,
							DateFormatter.YYYYMMDD),
					DateFormatter.reFormat(trimToEmpty(objVO.getEffEndDt()), DateFormatter.MM_DD_YYYY,
							DateFormatter.YYYYMMDD) };

			jdbcTemplate.queryForObject(sQuery, String.class, parms);

		} catch (EmptyResultDataAccessException exp) {
			return false;
		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->checkLISStatus:{}", e);
			throw new ApplicationException(e);
		}
		return true;
	}

	@Override
	public int updateOverrideData(String customerId, int applId, String hicNbr) throws ApplicationException {

		try {
			if (applId > 0) {
				String sQuery = "UPDATE EM_APPLICATION SET Dupl_app_ovrd_ind ='N',APPLICATION_STATUS='DUPLAPPL' "
						+ " where customer_id =? and hic_nbr=? and Application_id !=? ";

				return jdbcTemplate.update(sQuery,
						new Object[] { trimToEmpty(customerId), trimToEmpty(hicNbr), applId });

			}
			return 0;
		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->updateOverrideData:{}", e);
			throw new ApplicationException(e);
		}
	}

	@Override
	public int updateDuplicateAppError(List<String[]> allApplication, String customerId) throws ApplicationException {

		try {
			String stApplication = " (  APPLICATION_ID =  ";
			String storApplication = "";
			String storConst = " OR  APPLICATION_ID =  ";
			String endStApplication = " ) ";
			String[] plan = new String[3];
			// int recordSize = allApplication.size();

			if (allApplication.size() == 1) {
				plan = allApplication.get(0);
				stApplication = stApplication + plan[2];
				stApplication = stApplication + endStApplication;
			} else {
				for (int i = 0; i < allApplication.size(); i++) {
					plan = allApplication.get(i);
					if (i == 0) {
						stApplication = stApplication + "'" + plan[2] + "'";
					} else {
						storApplication = storApplication + storConst + "'" + plan[2] + "'";
					}
				}
				stApplication = stApplication + storApplication + endStApplication;
			}
			String sQuery = CommonUtils.buildQuery(
					"UPDATE EM_APPL_ERROR SET ERROR_STATUS='CLOSED' WHERE CUSTOMER_ID=?  AND ERROR_CD =? AND",
					stApplication);

			return jdbcTemplate.update(sQuery, new Object[] { trimToEmpty(customerId), trimToEmpty("AP057") });
		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->updateDuplicateAppError:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public int insertPlanDetails(EEMApplPlanDO objVO, String userId) throws ApplicationException {

		String ts = DateUtil.getCurrentDatetimeStamp();
		// int rows = 0;
		try {
			String sQuery = "INSERT INTO EM_APPL_PLAN (CUSTOMER_ID, APPLICATION_ID, EFFECTIVE_DATE, "
					+ "ELECTION_TYPE_CD, SEP_ELECTION_DATE, ELC_DERIVED_IND, FROM_PLAN_ID, "
					+ "FROM_PBP_ID, FROM_PBP_SEGMENT_ID, FROM_PRODUCT_ID, FROM_GROUP_ID, "
					+ "FROM_PAYMENT_AMT, TO_PLAN_ID, TO_PBP_ID, TO_PBP_SEGMENT_ID, TO_PRODUCT_ID, "
					+ "TO_GROUP_ID, TO_PAYMENT_AMT, CREATE_TIME, CREATE_USERID, "
					+ "LAST_UPDT_TIME, LAST_UPDT_USERID, SEP_REASON_CD) VALUES ("
					+ "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

			Object[] parms = new Object[] { trimToEmpty(objVO.getCustomerId()),
					Integer.parseInt(trimToEmpty(objVO.getApplId())),
					DateUtil.changedDateFormatForMonth(trimToEmpty(objVO.getReqDtCov())),
					// trimToEmpty(objVO.getElectionTypeCd()),
					trimToEmpty(objVO.getElectionType()),
					DateUtil.changedDateFormatForMonth(trimToEmpty(objVO.getSepElectionDt())),
					trimToEmpty(objVO.getElcDerivedInd()), trimToEmpty(objVO.getCurrPlanId()),
					trimToEmpty(objVO.getCurrPbpId()), trimToEmpty(objVO.getCurrPbpSegmentId()),
					trimToEmpty(objVO.getCurrProductId()), trimToEmpty(objVO.getCurrGrpId()),
					StringUtil.ensureDouble(objVO.getCurrPaymentAmt()),
					/*
					 * trimToEmpty(objVO.getEnrollPlanId()), trimToEmpty(objVO.getEnrollPbpId()),
					 * trimToEmpty(objVO.getEnrollPbpSegmentId()),
					 * trimToEmpty(objVO.getEnrollProductId()),
					 */
					trimToEmpty(objVO.getEnrollPlan()), trimToEmpty(objVO.getEnrollPbp()),
					trimToEmpty(objVO.getEnrollSegment()), trimToEmpty(objVO.getEnrollProduct()),
					trimToEmpty(objVO.getEnrollGrpId()),
					// StringUtil.ensureDouble(objVO.getEnrollPaymentAmt()),
					StringUtil.ensureDouble(objVO.getEnrollPymtAmt()), ts, trimToEmpty(userId), ts, trimToEmpty(userId),
					// trimToEmpty(objVO.getSepReasonCd())
					trimToEmpty(objVO.getSepReason()) };
			objVO.setLastUpdtTime(ts);
			return jdbcTemplate.update(sQuery, parms);
		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->insertPlanDetails:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public int updatePlanDetails(EEMApplPlanDO applPlanVO, String userId) throws ApplicationException {

		String ts = DateUtil.getCurrentDatetimeStamp();
		// int rows = 0;
		try {
			String sQuery = "UPDATE EM_APPL_PLAN SET EFFECTIVE_DATE=?, ELECTION_TYPE_CD=?, "
					+ "SEP_ELECTION_DATE=?, ELC_DERIVED_IND=?, TO_PLAN_ID=?, TO_PBP_ID=?, "
					+ "TO_PBP_SEGMENT_ID=?, TO_PRODUCT_ID=?, TO_GROUP_ID=?, TO_PAYMENT_AMT=?, "
					+ "LAST_UPDT_TIME=?, LAST_UPDT_USERID=?, SEP_REASON_CD=? "
					+ "WHERE CUSTOMER_ID=? AND APPLICATION_ID=? AND LAST_UPDT_TIME=?";

			Object[] parms = new Object[] { DateUtil.changedDateFormatForMonth(trimToEmpty(applPlanVO.getReqDtCov())),
					// trimToEmpty(applPlanVO.getElectionTypeCd()),
					trimToEmpty(applPlanVO.getElectionType()),
					DateUtil.changedDateFormatForMonth(trimToEmpty(applPlanVO.getSepElectionDt())),
					trimToEmpty(applPlanVO.getElcDerivedInd()), trimToEmpty(applPlanVO.getEnrollPlan()),
					trimToEmpty(applPlanVO.getEnrollPbp()), trimToEmpty(applPlanVO.getEnrollSegment()),
					trimToEmpty(applPlanVO.getEnrollProduct()), trimToEmpty(applPlanVO.getEnrollGrpId()),
					StringUtil.ensureDouble(applPlanVO.getEnrollPymtAmt()), ts, trimToEmpty(userId),
					trimToEmpty(applPlanVO.getSepReason()), trimToEmpty(applPlanVO.getCustomerId()),
					applPlanVO.getApplId(), trimToEmpty(applPlanVO.getLastUpdtTime()) };

			applPlanVO.setLastUpdtTime(ts);

			return jdbcTemplate.update(sQuery, parms);

		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->updatePlanDetails:{}", e);
			throw new ApplicationException(e);
		}

	}

	@Override
	public int setOrigDetails(EEMApplMasterVO eemApplMasterVO, String customerId, String userId)
			throws ApplicationException {

		String ts = DateUtil.getCurrentDatetimeStamp();
		try {
			String sQuery = "INSERT INTO EM_ORIG_APPLICATION (CUSTOMER_ID, APPLICATION_ID, APPLICATION_TYPE, "
					+ "APPLICATION_CATEGORY, APPLICATION_DATE, PREFIX, LAST_NAME, FIRST_NAME, MIDDLE_INIT, "
					+ "SUFFIX, HIC_NBR, SSN, SUPPLEMENTAL_ID, RX_ID, PRIMARY_HOME_PHONE, PRIMARY_WORK_PHONE, "
					+ "PRIMARY_CELL_PHONE, PRIMARY_FAX, PRIMARY_ADDRESS1, PRIMARY_ADDRESS2, PRIMARY_ADDRESS3, "
					+ "PRIMARY_CITY, PRIMARY_STATE, PRIMARY_ZIP, PRIMARY_COUNTY, MAIL_LAST_NAME, MAIL_FIRST_NAME, "
					+ "MAIL_MIDDLE_INIT, MAIL_SUFFIX, MAIL_ADDRESS1, MAIL_ADDRESS2, MAIL_ADDRESS3, MAIL_CITY, "
					+ "MAIL_STATE, MAIL_ZIP, MAIL_CNTY, MAIL_COUNTRY, PRIMARY_EMAIL, BIRTH_DATE, GENDER_CD, "
					+ "ENROLL_GRP, ENROLL_PRDT, ENROLL_PLAN_ID, ENROLL_PBP_ID, ENROLL_SEG, ENROLL_PAY_AMT, "
					+ "ENROLL_SRCE_CD, EFFECTIVE_DATE, LANGUAGE_CD, PCP_CODE, PCP_LOCATION_ID, CURRENT_PATIENT_IND, "
					+ "PREMIUM_WITHHOLD_OPTION, ESRD_IND, DIALYSIS_IND, SEC_RX_NAME, SEC_RX_COV_ID, SEC_RX_GRP, "
					+ "SEC_RX_BIN, SEC_RX_PCN, LTC_FAC_IND, MEDICAID_IND, MEDICAID_ID, SPOUSE_WORK_IND, OOA_IND, "
					+ "ELECTION_TYPE_CD, SEP_REASON_CD, SGN_ONFILE_IND, SGN_DATE, AUTH_LAST_NAME, AUTH_FIRST_NAME, "
					+ "AUTH_MIDDLE_INIT, AUTH_RELATIONSHIP_CD, AUTH_ADDRESS, AUTH_CITY, AUTH_STATE, AUTH_ZIP, "
					+ "AUTH_CNTY, AUTH_PHONE, EMERGCY_NAME, EMERGCY_PHONE, EMERGCY_RELATIONSHIP_CD, EMERGCY_EMAIL, "
					+ "INS_CARD_NAME, EDIT_OVERRIDE_IND, GRP_NUM, PARTA_EFFE_DATE, PARTB_EFFE_DATE, PARTD_EFFE_DATE, "
					+ "PCP_NAME, ELECTION_DATE, SEP_EXC, ATTEST_DATE, PCO_IND, SEC_RX_IND, LTC_FAC_NAME, AGENT_TYPE, "
					+ "AGENT_CREATE_TIME, AGENT_NAME, COMMISSION_AGY_ORG, APPL_COMMENTS, CREATE_TIME, CREATE_USERID, "
					+ "AGENT_ID, RECEIPT_DATE, SGN_DATE_OVR_IND, SUBSCRIBER_ID, NAME_ON_ACCT, ABA_ROUTING_NBR, BANK_ACCT_NBR, "
					+
					// "ACCOUNT_TYPE, BILL_FREQUENCY, BILL_LAST_NAME, BILL_FIRST_NAME,
					// BILL_MIDDLE_INIT, BILL_SUFFIX, XREF_CLAIM_NBR) " + //CMS FEB 2016 Release
					"ACCOUNT_TYPE, BILL_FREQUENCY, BILL_LAST_NAME, BILL_FIRST_NAME, BILL_MIDDLE_INIT, BILL_SUFFIX, XREF_CLAIM_NBR, ALT_CORRES_IND, HEALTH_PLAN_NEWS_EMAIL ) "
					+ // CMS FEB 2016 Release
					"VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, "
					+ // 50
					"?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, "
					+ // 54
						// CMS FEB 2016 Release - Start
						// "?,?,?,?,?,?,?,?,?, ?, ?,?,?)"; //13 50+54+12=117
						// IFOX-00406767 -start
					"?,?,?,?,?,?,?,?,?, ?, ?,?,?, ?,?)"; // 13 50+54+13=118

			EEMApplicationDO applDO = new EEMApplicationDO();
			EEMApplicationVO applVO = eemApplMasterVO.getApplVO();
			BeanUtils.copyProperties(applVO, applDO);
			EEMApplPlanVO planVO = eemApplMasterVO.getApplPlanVO();
			EEMApplOtherPlanVO otherPlanVO = eemApplMasterVO.getApplOtherPlanVO();
			EEMApplOtherCovVO applOtherCovVO = eemApplMasterVO.getApplOtherCovVO();
			EEMApplEligibilityVO applEligiVO = eemApplMasterVO.getApplEligiVO();
			EEMApplAgentVO applAgentVO = eemApplMasterVO.getApplAgentVO();
			EEMApplAddressVO applAddrVO = eemApplMasterVO.getApplAddress();
			List<EEMApplCommentsVO> applCommentsList = eemApplMasterVO.getApplCommentsList();

			String zip5 = "";
			String zip4 = "";
			if (!trimToEmpty(applAddrVO.getPerZip5()).equals("")) {
				zip5 = trimToEmpty(applAddrVO.getPerZip5());
			}
			if (!trimToEmpty(applAddrVO.getPerZip4()).equals("")) {
				zip4 = trimToEmpty(applAddrVO.getPerZip4());
			}
			String perZipCd = zip5 + zip4;

			zip5 = "";
			zip4 = "";

			if (!trimToEmpty(applAddrVO.getMailZip5()).equals("")) {
				zip5 = trimToEmpty(applAddrVO.getMailZip5());
			}
			if (!trimToEmpty(applAddrVO.getMailZip4()).equals("")) {
				zip4 = trimToEmpty(applAddrVO.getMailZip4());
			}
			String mailZipCd = zip5 + zip4;

			zip5 = "";
			zip4 = "";

			if (!trimToEmpty(applAddrVO.getAuthRepZip5()).equals("")) {
				zip5 = trimToEmpty(applAddrVO.getAuthRepZip5());
			}
			if (!trimToEmpty(applAddrVO.getAuthRepZip4()).equals("")) {
				zip4 = trimToEmpty(applAddrVO.getAuthRepZip4());
			}
			String authZipCd = zip5 + zip4;

			String parm11 = "";
			if (trimToEmpty(applDO.getMbrHicNbr()).equals("999999999Z"))
				parm11 = "";
			else if (StringUtil.isHicOrMbi(applDO.getMbrHicNbr()).equalsIgnoreCase("hic")) // SSNRI orig app issue
				parm11 = trimToEmpty(applDO.getDisplayHic());
			else
				parm11 = trimToEmpty(applDO.getMbrHicNbr());

			String parm15 = trimToEmpty(applAddrVO.getPerPhone());
			String parm16 = trimToEmpty(applAddrVO.getPerWorkPhone());
			String parm17 = trimToEmpty(applAddrVO.getPerCell());
			String parm18 = trimToEmpty(applAddrVO.getPerFax());
			String parm19 = trimToEmpty(applAddrVO.getPerAdd1());
			String parm20 = trimToEmpty(applAddrVO.getPerAdd2());
			String parm21 = trimToEmpty(applAddrVO.getPerAdd3());
			String parm22 = trimToEmpty(applAddrVO.getPerCity());
			String parm23 = StringUtil
					.nonNullTrim(eemCodeCache.getDesc(applAddrVO.getPerState(), eemPer.getLstStates()));
			String parm24 = trimToEmpty(perZipCd);
			String parm25 = trimToEmpty(applAddrVO.getPerCounty());
			String parm30 = trimToEmpty(applAddrVO.getMailAdd1());
			String parm31 = trimToEmpty(applAddrVO.getMailAdd2());
			String parm32 = trimToEmpty(applAddrVO.getMailAdd3());
			String parm33 = trimToEmpty(applAddrVO.getMailCity());
			String parm34 = StringUtil
					.nonNullTrim(eemCodeCache.getDesc(applAddrVO.getMailState(), eemPer.getLstStates()));
			String parm35 = trimToEmpty(mailZipCd);
			String parm36 = trimToEmpty(applAddrVO.getMailCounty());
			String parm37 = trimToEmpty(applAddrVO.getMailCountry());

			String parm39 = "";
			if (!trimToEmpty(applDO.getMbrBirthDt()).equals("99/99/9999"))
				parm39 = trimToEmpty(DateUtil.changedDateFormatForMonth(applDO.getMbrBirthDt()));

			String parm74 = trimToEmpty(applAddrVO.getAuthRepStreet());
			String parm75 = trimToEmpty(applAddrVO.getAuthRepCity());
			String parm76 = StringUtil
					.nonNullTrim(eemCodeCache.getDesc(applAddrVO.getAuthRepState(), eemPer.getLstStates()));
			String parm77 = trimToEmpty(authZipCd);
			String parm78 = trimToEmpty("USA");
			String parm79 = trimToEmpty(applAddrVO.getAuthRepPhone());

			String parm100 = applAgentVO.getCommAgencyId() != null
					? trimToEmpty(applAgentVO.getCommAgencyId().split("-")[0])
					: "";
			String parm101 = "";
			String pcpName = otherPlanVO.getPcpName() == null ? "" : otherPlanVO.getPcpName();

			if (applCommentsList != null) {
				for (int i = applCommentsList.size() - 1; i >= 0; i--) {
					EEMApplCommentsVO commentVO = applCommentsList.get(i);
					/* if (commentVO.getInsertInd().equals("Y")) { */

					String comment = trimToEmpty(commentVO.getApplComments());
					if (comment.length() > 255) {
						comment = comment.substring(0, 255);
					}
					parm101 = trimToEmpty(comment);
					// }
				}
			}

			Object[] parms = new Object[] { trimToEmpty(customerId), applDO.getApplId(),
					trimToEmpty(applDO.getApplType()), trimToEmpty(applDO.getApplCategory()),
					trimToEmpty(DateUtil.changedDateFormatForMonth(applDO.getOrigApplDate())),
					trimToEmpty(applDO.getMbrPrefix()), trimToEmpty(applDO.getMbrLastName()),
					trimToEmpty(applDO.getMbrFirstName()), trimToEmpty(applDO.getMbrMiddleName()),
					trimToEmpty(applDO.getMbrSuffix()), parm11, trimToEmpty(CommonUtils.deFormatSsn(applDO.getMbrSsn())),
					trimToEmpty(applDO.getAltMbrId()), trimToEmpty(applDO.getMbrRxId()), parm15, parm16, parm17, parm18,
					parm19, parm20, parm21, parm22, parm23, parm24, parm25, trimToEmpty(applDO.getMailLastName()),
					trimToEmpty(applDO.getMailFirstName()), trimToEmpty(applDO.getMailMiddleName()),
					trimToEmpty(applDO.getMailSuffix()), parm30, parm31, parm32, parm33, parm34, parm35, parm36, parm37,
					trimToEmpty(applDO.getMbrEmail()), parm39, trimToEmpty(applDO.getMbrGender()),
					trimToEmpty(planVO.getEnrollGrpId()), trimToEmpty(planVO.getEnrollProduct()),
					trimToEmpty(planVO.getEnrollPlan()), trimToEmpty(planVO.getEnrollPbp()),
					trimToEmpty(planVO.getEnrollSegment()), StringUtil.ensureDouble(planVO.getEnrollPymtAmt()),
					trimToEmpty(applDO.getEnrollSrceCd()),
					trimToEmpty(DateUtil.changedDateFormatForMonth(planVO.getReqDtCov())),
					trimToEmpty(applDO.getLanguage()), trimToEmpty(otherPlanVO.getOfficeCd()),
					trimToEmpty(otherPlanVO.getLocationId()), trimToEmpty(otherPlanVO.getCurrentPatientInd()),
					trimToEmpty(applDO.getPwOption()),
					/*
					 * trimToEmpty(applOtherCovVO.getEsrdInd()),
					 * trimToEmpty(applOtherCovVO.getDialysisInd()),
					 * trimToEmpty(applOtherCovVO.getSecRxName()), "",
					 * trimToEmpty(applOtherCovVO.getSecRxGrp()),
					 * trimToEmpty(applOtherCovVO.getSecRxBin()),
					 * trimToEmpty(applOtherCovVO.getSecRxPcn()), "",
					 * trimToEmpty(applOtherCovVO.getMedicaidInd()),
					 * trimToEmpty(applOtherCovVO.getMedicaidId()),
					 * trimToEmpty(applOtherCovVO.getSpouseWorkInd()),
					 */
					trimToEmpty(applOtherCovVO.getEsrd()), trimToEmpty(applOtherCovVO.getDialysis()),
					trimToEmpty(applOtherCovVO.getOtherCov()), "", trimToEmpty(applOtherCovVO.getGroupNo()),
					trimToEmpty(applOtherCovVO.getCovBin()), trimToEmpty(applOtherCovVO.getCovPcn()), "",
					trimToEmpty(applOtherCovVO.getStMedicaid()), trimToEmpty(applOtherCovVO.getMedicaidId()),
					trimToEmpty(applOtherCovVO.getSpouseWork()), trimToEmpty(applDO.getOutOfArea()),
					trimToEmpty(planVO.getElectionType()), trimToEmpty(planVO.getSepReason()),
					trimToEmpty(applDO.getSignOnFile()),
					trimToEmpty(DateUtil.changedDateFormatForMonth(applDO.getSignDt())),
					trimToEmpty(applDO.getAuthRepLastName()), trimToEmpty(applDO.getAuthRepFirstName()),
					trimToEmpty(applDO.getAuthRepMidName()), trimToEmpty(applDO.getAuthRepRelation()), // 73
					parm74, parm75, parm76, parm77, parm78, parm79, trimToEmpty(applDO.getEmergName()),
					trimToEmpty(applDO.getEmergPhone()), trimToEmpty(applDO.getEmergRelation()),
					trimToEmpty(applDO.getEmergEmail()), trimToEmpty(applDO.getInsCardName()),
					trimToEmpty(applDO.getEditOverride()), "",
					trimToEmpty(DateUtil.changedDateFormatForMonth(applEligiVO.getPartAEffDate())),
					trimToEmpty(DateUtil.changedDateFormatForMonth(applEligiVO.getPartBEffDate())),
					trimToEmpty(DateUtil.changedDateFormatForMonth(applEligiVO.getPartDEffDate())), pcpName, "", "", "",
					trimToEmpty(applOtherCovVO.getPcoInd()), trimToEmpty(applOtherCovVO.getSecRxInd()), "", "", ts,
					trimToEmpty(applAgentVO.getBrokAgentId()), // 99
					parm100, parm101, ts, trimToEmpty(userId), trimToEmpty(applAgentVO.getBrokerType()), "", "", "",
					trimToEmpty(applDO.getAchNameOnAct()), trimToEmpty(applDO.getAchAbaRoutingNbr()),
					trimToEmpty(applDO.getAchbankAcctNbr()), trimToEmpty(applDO.getAchAccountType()),
					trimToEmpty(applDO.getAchBillFrequency()), trimToEmpty(applDO.getBillLastName()),
					trimToEmpty(applDO.getBillFirstName()), trimToEmpty(applDO.getBillMiddleName()), "",
					trimToEmpty(applDO.getXrefNbr()), trimToEmpty(applDO.getAltCorrespondenceInd()),
					trimToEmpty(applDO.getHealthPlanNews()) };

			return jdbcTemplate.update(sQuery, parms);
		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->setOrigDetails:{}", e);
			throw new ApplicationException(e);
		}
	}

	@Override
	public String getLockInd(String currStatus) throws ApplicationException {

		String lockInd = "";
		try {
			String sQuery = "SELECT LOCK_IND FROM EM_APPLICATIONSTATUS " + "WHERE APPLICATION_STATUS = ?";
			lockInd = jdbcTemplate.queryForObject(sQuery, new Object[] { currStatus }, String.class);
			return trimToEmpty(lockInd);
		} catch (EmptyResultDataAccessException exp) {
			return "";
		} catch (DataAccessException e) {
			LOGGER.error("Exception in EEMApplDaoImpl->getLockInd:{}", e);
			throw new ApplicationException(e);
		}
	}

	@Override
	public List<LabelValuePair> getPreSetNotes(String customerId, EmPreSetNoteVO emPreSetNoteVO)
			throws ApplicationException {

		String squery = "SELECT PRE_SET_NOTE,LONG_DESCRIPTION FROM EM_PRE_SET_NOTES WHERE CUSTOMER_ID = ? ORDER BY PRE_SET_NOTE ASC";

		String sValue = "PRE_SET_NOTE";
		String sName = "LONG_DESCRIPTION";

		return getLabelValuePair(squery, sName, sValue, new Object[] { customerId });
	}

	@Override
	public Boolean insertPreSetNote(String customerId, EmPreSetNoteVO emPreSetNoteVO) throws ApplicationException {

		int sqlCnt = 0;
		StringBuilder sQuery = new StringBuilder("SELECT MAX(INT(PRE_SET_NOTE_ID))AS PRESET FROM EM_PRE_SET_NOTES")
				.append(" WHERE CUSTOMER_ID = ? ");

		Integer preSetNoteId = jdbcTemplate.queryForObject(sQuery.toString(), new Object[] { customerId },
				Integer.class);

		if (preSetNoteId != null) {
			preSetNoteId = preSetNoteId + 1;
		}
		if (preSetNoteId != null) {
			StringBuilder sql = new StringBuilder("INSERT INTO EM_PRE_SET_NOTES(CUSTOMER_ID, PRE_SET_NOTE_ID,")
					.append(" PRE_SET_NOTE, LONG_DESCRIPTION, PRESET_USE_IND) VALUES(?,?,?,?,' ')");
			Object[] params = new Object[] { customerId, preSetNoteId, emPreSetNoteVO.getPreSetNote(),
					emPreSetNoteVO.getPreSetNoteDescr() };

			sqlCnt = jdbcTemplate.update(sql.toString(), params);
		}
		return sqlCnt > 0 ? true : false;
	}

	@Override
	public Boolean modifyPreSetNote(String customerId, EmPreSetNoteVO emPreSetNoteVO) throws ApplicationException {

		int count = 0;
		try {
			StringBuilder sql = new StringBuilder("UPDATE EM_PRE_SET_NOTES SET PRE_SET_NOTE = ?, LONG_DESCRIPTION = ?")
					.append(" WHERE UCASE(PRE_SET_NOTE) = ? AND CUSTOMER_ID = ?");

			Object[] params = new Object[] { emPreSetNoteVO.getPreSetNote(), emPreSetNoteVO.getPreSetNoteDescr(),
					emPreSetNoteVO.getPreSetNote(), customerId, };

			count = jdbcTemplate.update(sql.toString(), params);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp);
		}
		return count > 0 ? true : false;
	}

	@Override
	public Boolean deletePreSetNote(String customerId, EmPreSetNoteVO emPreSetNoteVO) throws ApplicationException {

		int count = 0;
		try {
			StringBuilder sql = new StringBuilder("DELETE FROM EM_PRE_SET_NOTES WHERE UCASE(PRE_SET_NOTE) = ?");
			sql.append(" AND UCASE(LONG_DESCRIPTION) = ? AND CUSTOMER_ID = ? ");

			Object[] params = new Object[] { emPreSetNoteVO.getPreSetNote(), emPreSetNoteVO.getPreSetNoteDescr(),
					customerId };
			count = jdbcTemplate.update(sql.toString(), params);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp);
		}
		return count > 0 ? true : false;
	}

	@Override
	public List<LabelValuePair> getCities(String zip5, String county) {

		/*
		 * StringBuilder sQuery = new
		 * StringBuilder("SELECT DISTINCT CITY_NAME,SSA_ST AS VALUE FROM EM_ZIPCODE ").
		 * append(
		 * " WHERE ZIP_CD5 = ? AND SSA_CNTY = ? UNION SELECT DISTINCT CITY_NAME,SSA_ST_CD AS VALUE FROM EM_ZIPCITY "
		 * ) .append(" WHERE ZIP_CODE = ? AND SSA_CNTY_CD = ? ");
		 */

		StringBuilder sQuery = new StringBuilder(" SELECT DISTINCT CITY_NAME FROM EM_ZIPCITY ")
				.append(" WHERE ZIP_CODE = ? AND SSA_CNTY_CD = ? ");

		String sValue = "CITY_NAME";
		String sName = "CITY_NAME";

		return getLabelValuePair(sQuery.toString(), sName, sValue, new Object[] { zip5, county });
	}

	private List<LabelValuePair> getLabelValuePair(String sQuery, String sValue, String sDesc, Object[] params) {

		return jdbcTemplate.query(sQuery.toString(), (ResultSet res) -> {
			List<LabelValuePair> hmp = new ArrayList<LabelValuePair>();
			while (res.next()) {
				String value = trimToEmpty(res.getString(sValue));
				String desc = trimToEmpty(res.getString(sDesc));

				LabelValuePair pair = new LabelValuePair(value, desc);

				hmp.add(pair);
			}
			return hmp;
		}, params);

	}

	@Override
	public Map<String, Object> populateCountyCityState(String perZip5, String perZip4) {
		Map<String, String> searchParamMap = new HashMap<>();
		Map<String, Object> hmp = new HashMap<String, Object>();
		List<LabelValuePair> countyList = new ArrayList<>();
		List<LabelValuePair> cities = new ArrayList<>();
		String stateCd = EEMConstants.BLANK;

		searchParamMap.put("zip5", perZip5);
		searchParamMap.put("zip4", perZip4);
		List<Map<String, String>> cityNameswithCounty = eemPopUpDAO.getCityNameswithCounty(searchParamMap);

		Set<LabelValuePair> countySet = new HashSet<>();
		Set<LabelValuePair> citySet = new HashSet<>();
		for (Map<String, String> itemMap : cityNameswithCounty) {

			String city = itemMap.get("perCity");
			if (StringUtils.isNotBlank(city)) {
				citySet.add(new LabelValuePair(city, city));
			}

			String county = itemMap.get("perCounty");
			String countyCd = itemMap.get("countyCd");
			if (StringUtils.isNotBlank(county) && StringUtils.isNotBlank(countyCd)) {
				countySet.add(new LabelValuePair(countyCd, county));
			}

			if (StringUtils.isNotBlank(itemMap.get("perStateCd"))) {
				stateCd = itemMap.get("perStateCd");
			}
		}

		if (!CollectionUtils.isEmpty(citySet)) {
			cities.addAll(citySet);
		}
		if (!CollectionUtils.isEmpty(countySet)) {
			countyList.addAll(countySet);
		}

		hmp.put("cityList", cities);
		hmp.put("countyList", countyList);
		hmp.put("stateCd", stateCd);

		return hmp;
	}

	@Override
	public List<LabelValuePair> getCountyList(String zip5) {
		StringBuilder sQuery = new StringBuilder(
				"SELECT DISTINCT B.COUNTY_NAME,B.COUNTY_CD FROM EM_ZIPCODE A, COUNTY B ")
						.append(" WHERE B.STATE_CD = A.SSA_ST AND B.COUNTY_CD = A.SSA_CNTY AND A.ZIP_CD5 = ?");

		String sValue = "COUNTY_NAME";
		String sName = "COUNTY_CD";

		return getLabelValuePair(sQuery.toString(), sName, sValue, new Object[] { zip5 });
	}

	@Override
	public boolean isCARAEligible(String reqCovDt, String MBI, String hicNbr, String table)
			throws ApplicationException {

		String tableSpace = "";
		if (table.equalsIgnoreCase(EEMConstants.EM_TABLE_BEQ))
			tableSpace = "BEQR_CARAHISTORY";
		else
			tableSpace = "MBD_CARAHISTORY";
		try {
			String sQuery = "SELECT HIC_NBR FROM " + tableSpace
					+ " WHERE HIC_NBR IN (?,?) AND ((? between SDATE  AND EDATE) OR (? >= SDATE AND (EDATE in ('00000000','')))) ";

			Object[] parm = new Object[] { hicNbr, MBI, reqCovDt, reqCovDt };
			jdbcTemplate.queryForObject(sQuery, parm, String.class);
			return true;
		} catch (EmptyResultDataAccessException ex) {
			return false;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp);
		}

	}

	@Override
	public List<EEMApplStatusTrackDO> getApplicationStatusTrack(String applicationId, String customerId)
			throws ApplicationException {

		ArrayList<Object> params = new ArrayList<>();

		StringBuilder sQuery = CommonUtils.buildQueryBuilder(
				" SELECT LOG_TIME,LAST_UPDT_USERID,APPL_STATUS_AFTER AS APPL_STATUS ",
				" FROM EM_APPL_STATLOG WHERE APPLICATION_ID = ? ",
				" AND CUSTOMER_ID = ? ORDER BY LAST_UPDT_TIME DESC ");

		params.add(applicationId);
		params.add(customerId);

		Object[] objPrams = params.toArray();
		try {

			return jdbcTemplate.query(sQuery.toString(),
					new DomainPropertyRowMapper<EEMApplStatusTrackDO>(EEMApplStatusTrackDO.class), objPrams);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error occured while fetching the application status track");
		}
	}

	@Override
	public String getApplicationStatusByAppId(String appId, String custId) throws ApplicationException {
		String query = "SELECT APPLICATION_STATUS FROM EM_APPLICATION WHERE APPLICATION_ID = ? and CUSTOMER_ID = ?";
		try {
			return jdbcTemplate.queryForObject(query, String.class, appId, custId);
		} catch (EmptyResultDataAccessException exp) {
			throw new ApplicationException(exp,
					String.format("No application found for appId: %s and custId: %s ", appId, custId));
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, String.format(
					"Error occured while retrieving Application Status for appId: %s and custId: %s", appId, custId));
		}
	}

	@Override
	public boolean getSecondaryCityName(String zip5, String altCity) {
		if (zip5.isEmpty() || altCity.isEmpty()) {
			return false;
		}
		String query = "SELECT COUNT(*) FROM EM_ZIPCITY WHERE ZIP_CODE = ? AND RTRIM(CITY_NAME) = ?";
		try {
			Integer count = jdbcTemplate.queryForObject(query, Integer.class, zip5, altCity);
			return count > 0;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, String.format(
					"Error occured while retrieving getSecondaryCityName for zip5: %s and altCity: %s", zip5, altCity));
		}
	}

	@Override
	public String getGrpProdSpclTpe(String customerId, String enrollGrpId, String reqDtCov, String enrollProduct,
			String enrollPlan, String enrollPbp, String enrollSegment) {
		
		reqDtCov = DateFormatter.reFormat(trimToEmpty(reqDtCov), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
		String specialInd ="";
		Object[] objParms = new Object[] {customerId, enrollGrpId, enrollProduct, enrollPlan, enrollPbp,
				enrollSegment, reqDtCov};
		try {
		String query = CommonUtils.buildQuery(
					"SELECT SPECIAL_TYPE_IND FROM EM_GRP_PRODUCT WHERE CUSTOMER_ID = ? ",
				    "AND GRP_ID = ? AND PRODUCT_ID = ? AND PLAN_ID = ? AND PBP_ID = ? AND PBP_SEGMENT_ID = ?",
					"AND ? BETWEEN GRP_PROD_START_DATE AND GRP_PROD_END_DATE ORDER BY LAST_UPDT_TIME DESC FETCH FIRST ROW ONLY");
		specialInd = jdbcTemplate.queryForObject(query, objParms, String.class);
		}
		catch (EmptyResultDataAccessException exp) {
			specialInd ="";
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
		return specialInd;
	}

}
