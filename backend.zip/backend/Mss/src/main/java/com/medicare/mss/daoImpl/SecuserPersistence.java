package com.medicare.mss.daoImpl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.util.StringUtil;

@Repository
public class SecuserPersistence {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public int logoff(String userId) {

		try {
			String query = "UPDATE secuser set SignOff_time = Current_Timestamp, SignedOn_YN = 'N', Was_Sid = null, RQS_Sid = null WHERE User_id = ?";

			return jdbcTemplate.update(query, new Object[] { userId });
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Failed to logoff");
		}
	}

	public void updateFailedLogin(String userId) {

		String sql = "SELECT Active_yn, Failed_Logon_cnt FROM SECUSER WHERE USER_ID = ?";

		try {

			String[] data = jdbcTemplate.query(sql, new Object[] { userId }, new ResultSetExtractor<String[]>() {

				@Override
				public String[] extractData(ResultSet res) throws SQLException, DataAccessException {
					// TODO Auto-generated method stub

					String str[] = null;

					if (res.next()) {

						str = new String[2];

						str[0] = StringUtil.nonNullTrim(res.getString("Active_yn"));

						str[1] = StringUtil.nonNullTrim(res.getString("Failed_Logon_cnt"));
					}
					return str;
				}
			});

			if (null != data) {

				String query = "UPDATE secuser set Active_yn = ?, Failed_Logon_cnt = ?, Failed_Logon_Date = CURRENT_TIMESTAMP, Was_Sid = null, RQS_Sid = null WHERE User_id = ?";
				int maxFailedLogins = 3;

				String activeYN = data[0];
				Integer failedLogonCnt = Integer.parseInt(data[1]);

				failedLogonCnt += 1;

				if (failedLogonCnt >= maxFailedLogins)
					activeYN = "L";

				jdbcTemplate.update(query, new Object[] { activeYN, failedLogonCnt, userId });
			}

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Failed to login");
		}

	}

	public void updateLogin(String userId, String wasSid) {
		try {
			String query = "UPDATE secuser SET Signon_time = CURRENT_TIMESTAMP, SignedOn_yn = 'Y', was_sid = ?, rqs_sid = null, failed_logon_cnt = 0, failed_logon_date = null, AutoPwd_Status = '', Fail_AutoPwd_cnt = 0, Fail_AutoPwd_Time = null WHERE User_id =?";
			jdbcTemplate.update(query, new Object[] { wasSid, userId });
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Failed to login");
		}

	}
}
