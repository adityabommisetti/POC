package com.medicare.mss.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EEMLEPMaximusVO implements Cloneable, Serializable {

	private static final long serialVersionUID = 8439094181648625963L;

	private String caseFileDueDate;
	private String caseFileNumber;
	private String caseFileRecDate;
	private String createTime;
	private String createUserId;
	private String customerId;
	private String decisionRecDate;
	private String decisionType;
	private String isUpdate;
	private String lastUpdtTime;
	private String lastUpdtUserId;
	private String memberId;
	private String name;
	private String transactionDueDate;

	public String getTransactionDueDateFrmt() {
		return DateFormatter.reFormat(transactionDueDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setTransactionDueDateFrmt(String transactionDueDate) {
		this.transactionDueDate = DateFormatter.reFormat(transactionDueDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
	}

	public String getDecisionRecDateFrmt() {
		return DateFormatter.reFormat(decisionRecDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setDecisionRecDateFrmt(String decisionRecDate) {
		this.decisionRecDate = DateFormatter.reFormat(decisionRecDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
	}

	public String getCaseFileDueDateFrmt() {
		return DateFormatter.reFormat(caseFileDueDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setCaseFileDueDateFrmt(String caseFileDueDate) {
		this.caseFileDueDate = DateFormatter.reFormat(caseFileDueDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
	}

	public String getCaseFileRecDateFrmt() {
		return DateFormatter.reFormat(caseFileRecDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setCaseFileRecDateFrmt(String caseFileRecDate) {
		this.caseFileRecDate = DateFormatter.reFormat(caseFileRecDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

}
