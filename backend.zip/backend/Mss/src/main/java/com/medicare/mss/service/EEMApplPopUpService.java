package com.medicare.mss.service;

import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.medicare.mss.caching.EEMProfileSettings;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.EEMProfileConstants;
import com.medicare.mss.dao.EEMApplDAO;
import com.medicare.mss.daoImpl.EEMPopUpDAOImpl;
import com.medicare.mss.domainobject.EEMApplProductDO;
import com.medicare.mss.domainobject.EEMProfileItemDO;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.NumberFormatter;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EEMMbrEnrollmentVO;
import com.medicare.mss.vo.EEMMbrMasterVO;
import com.medicare.mss.vo.EMDatedSegmentVO;

@Repository
public class EEMApplPopUpService {

	@Autowired
	private EEMApplDAO applDAO;
	
	@Autowired
	private EEMPopUpDAOImpl dao;
	
	@Autowired
	private CacheService sessionHelper;
	
	@Autowired
	EEMProfileSettings eemProfileSettings;
	
	public List<Map<String, String>> eemApplAgencySearch(Map<String, String> searchParamMap) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String lineOfBusiness = EEMConstants.BLANK;
		String recordType = trimToEmpty(searchParamMap.get("recordType"));
		/*
		 * IHP issue for Agent if(null != eemFormAppl.getReqDtCov() &&
		 * !eemFormAppl.getReqDtCov().trim().equals("") )
		 * sessionHelper.getSession().setAttribute("strReqDtCov",
		 * eemFormAppl.getReqDtCov());
		 * 
		 * String strReqDtCov = (String)
		 * sessionHelper.getSession().getAttribute("strReqDtCov"); if( (null ==
		 * eemFormAppl.getReqDtCov() || eemFormAppl.getReqDtCov().trim().equals("")) &&
		 * null != strReqDtCov && !strReqDtCov.trim().equals("") )
		 * eemFormAppl.setReqDtCov(strReqDtCov.trim()); IHP issue for Agent
		 */
		if("Application".equalsIgnoreCase(recordType)){
		 lineOfBusiness = applDAO.getLineOfBusniess(customerId,
				trimToEmpty(searchParamMap.get("enrollGrpId")),
				trimToEmpty(searchParamMap.get("reqDateCov")),
				trimToEmpty(searchParamMap.get("enrollProduct")),
				trimToEmpty(searchParamMap.get("enrollPlan")),
				trimToEmpty(searchParamMap.get("enrollPbp")),
				trimToEmpty(searchParamMap.get("enrollSegment")));
		}
		else {
			
			EEMProfileItemDO eemProfileItemDO = eemProfileSettings.getProfileObject(customerId, EEMProfileConstants.LOB_VALD);
			String lobValid = (null == eemProfileItemDO) ? "" : StringUtil.nonNullTrim(eemProfileItemDO.getParmIndValue());

			if ("Y".equalsIgnoreCase(lobValid)) {
				EEMMbrMasterVO masterVO = sessionHelper.getEEMContext().getMbrMasterVO();
				EEMMbrEnrollmentVO mbrEnrlVO = (EEMMbrEnrollmentVO) getSegmentActiveOn(masterVO.getMbrEnrollmentList(),
						trimToEmpty(searchParamMap.get("reqDateCov")));

				if (Optional.ofNullable(mbrEnrlVO).isPresent()) {
					lineOfBusiness = applDAO.getLineOfBusniess(customerId,
							mbrEnrlVO.getGrpId(),
							mbrEnrlVO.getEffStartDate(),
							mbrEnrlVO.getProductId(),
							mbrEnrlVO.getPlanId(),
							mbrEnrlVO.getPbpId(),
							mbrEnrlVO.getPbpSegmentId());

				}
			}
		}
		searchParamMap.put("searchLob",lineOfBusiness);
		return dao.getLstSrchAgencies(customerId, searchParamMap);
	}

	public List<Map<String, String>> getLstPCPNames(Map<String, String> searchParamMap) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		
		String lineOfBusiness = applDAO.getLineOfBusniess(customerId,
				trimToEmpty(searchParamMap.get("enrollGrpId")),
				trimToEmpty(searchParamMap.get("reqDateCov")),
				trimToEmpty(searchParamMap.get("enrollProduct")),
				trimToEmpty(searchParamMap.get("enrollPlan")),
				trimToEmpty(searchParamMap.get("enrollPbp")),
				trimToEmpty(searchParamMap.get("enrollSegment")));
		
		searchParamMap.put("searchLob",lineOfBusiness);
		
		return dao.getLstPCPNames(customerId, searchParamMap);
	}

	public List<Map<String, String>> eemApplCitySearch(Map<String, String> searchParamMap) {
		return dao.getCityNameswithCounty(searchParamMap);
	}

	public List<EEMApplProductDO> eemApplProdSearch(Map<String, String> searchParamMap) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();

		List<EEMApplProductDO> lstProducts = dao.getProducts(customerId, searchParamMap);

		if (!lstProducts.isEmpty()) {
			EEMApplProductDO productVO = lstProducts.get(0);
			String prodId = trimToEmpty(productVO.getProductId());
			String groupId = trimToEmpty(productVO.getGroupId());
			List<EEMApplProductDO> newList = new ArrayList<>();
			newList.add(productVO);
			for (int i = 0; i < lstProducts.size(); i++) {
				productVO = lstProducts.get(i);
				double pymtAmt = 0;
				if (!"Y".equals(productVO.getSnpInd())) {
					String prtCAmt = trimToEmpty(productVO.getPrtCPremiumAmt());
					String prtDAmt = trimToEmpty(productVO.getPrtDPremiumAmt());
					String supplAmt = trimToEmpty(productVO.getSupplPremiumAmt());
					String premReducAmt = trimToEmpty(productVO.getPremiumReductionAmt());
					String dsrRebateAmt = trimToEmpty(productVO.getDsrRebateAmt());
					pymtAmt = Double.parseDouble(prtCAmt) + Double.parseDouble(prtDAmt) + Double.parseDouble(supplAmt)
							- Double.parseDouble(premReducAmt) - Double.parseDouble(dsrRebateAmt);
				}
				productVO.setPymtAmt(NumberFormatter.formatDecimal2Places(pymtAmt));
				String tmpProdId = trimToEmpty(productVO.getProductId());
				String tmpGroupId = trimToEmpty(productVO.getGroupId());
				
				if (i > 0 && (!prodId.equals(tmpProdId) || !groupId.equals(tmpGroupId))) {
					newList.add(productVO);
					prodId = tmpProdId;
					groupId = tmpGroupId;
				}
			}
			lstProducts = newList;
		}
		return lstProducts;
	}
	
	public EMDatedSegmentVO getSegmentActiveOn(List<? extends EMDatedSegmentVO> items, String effDate) {
		EMDatedSegmentVO item;
		effDate = DateFormatter.reFormat(trimToEmpty(effDate), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
		Iterator<? extends EMDatedSegmentVO> it = items.iterator();
		while (it.hasNext()) {
			item = it.next();
			if (DateMath.isBetween(effDate, item.getEffStartDate(), item.getEffEndDate())) {
				return item;
			}
		}
		return null;
	}

}
