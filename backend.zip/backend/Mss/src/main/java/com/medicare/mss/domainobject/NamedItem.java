package com.medicare.mss.domainobject;

import java.io.Serializable;
import java.util.List;

import com.medicare.mss.util.LabelValuePair;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NamedItem  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 334117086869760475L;
	private String name;
	private List<LabelValuePair> Item;
}