/**
 * 
 */
package com.medicare.mss.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMMbrDAO;
import com.medicare.mss.dao.EEMMbrDsInfoDAO;
import com.medicare.mss.domainobject.EEMMbrDsInfoDO;
import com.medicare.mss.domainobject.EMMbrTriggerDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.EEMContext;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.vo.EEMMbrDsInfoVO;
import com.medicare.mss.vo.EEMMbrEnrollmentVO;
import com.medicare.mss.vo.EEMMbrMasterVO;
import com.medicare.mss.vo.EMDatedSegmentVO;

/**
 * @author Wipro Ltd.
 *
 */
@Service
@Transactional(rollbackFor = ApplicationException.class)
public class EEMMbrDsInfoService extends EEMMbrBaseService {

	@Autowired
	private EEMMbrDsInfoDAO eemMbrDsInfoDAO;

	@Autowired
	private EEMCodeCache eemCodeCache;

	@Autowired
	private EEMMbrDAO eemEnrollDao;
	
	@Autowired
	private EEMMbrDAO eemMbrDAO;

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public List<EEMMbrDsInfoVO> getMbrDsInfos(String memberId, String showAll) {

		List<EEMMbrDsInfoVO> mbrDsInfoVOList = sessionHelper.getEEMContext().getMbrMasterVO().getMbrDsInfoList();
		
		if (StringUtils.equals(EEMConstants.VALUE_YES, showAll)) {
			List<EEMMbrDsInfoVO> allInfos = getMbrDsInfoListFromDB(memberId, showAll);
				mbrDsInfoVOList = (List<EEMMbrDsInfoVO>) getActiveDatedList(allInfos);
				setToContext(mbrDsInfoVOList);
			return allInfos;
		} else {
			if (Objects.isNull(mbrDsInfoVOList)) {
				mbrDsInfoVOList = getMbrDsInfoListFromDB(memberId, showAll);
				setToContext(mbrDsInfoVOList);
			} else {
				mbrDsInfoVOList = (List<EEMMbrDsInfoVO>) getActiveDatedList(mbrDsInfoVOList);
				setToContext(mbrDsInfoVOList);
			}
			return mbrDsInfoVOList;
		}
	}

	@SuppressWarnings("unchecked")
	public boolean deleteMbrDsInfo(EEMMbrDsInfoVO mbrDsInfoVO)
			throws CloneNotSupportedException, ParseException {
		boolean finalRslt = false;
		String userId = sessionHelper.getUserInfo().getUserId();
		if (StringUtils.equals(mbrDsInfoVO.getDsCd(), EEMMbrDsInfoVO.DS_PWO)) {
			return mbrDsInfoMustHaveDelete(mbrDsInfoVO, userId);
		}

		int sqlCnt = eemMbrDsInfoDAO.setOverride(mbrDsInfoVO, userId);
		if (sqlCnt == 1) {
			List<EEMMbrDsInfoVO> updatedMbrDsInfoVOList = getMbrDsInfoListFromDB(mbrDsInfoVO.getMemberId(),
					mbrDsInfoVO.getShowAll());
			if (StringUtils.equals(EEMConstants.VALUE_NO, mbrDsInfoVO.getShowAll())) {
				setToContext(updatedMbrDsInfoVOList);
			} else {
				List<EEMMbrDsInfoVO> mbrDsInfoActiveVOList = (List<EEMMbrDsInfoVO>) getActiveDatedList(
						updatedMbrDsInfoVOList);
				setToContext(mbrDsInfoActiveVOList);
			}
			finalRslt = true;
		}
		return finalRslt;

	}

	@SuppressWarnings("unchecked")
	public boolean mbrDsInfoMustHaveDelete(EEMMbrDsInfoVO delVO, String userId)
			throws CloneNotSupportedException, ParseException {

		String ts = DateUtil.getCurrentDatetimeStamp();

		List<EEMMbrDsInfoVO> eemMbrDsInfoVOs = getMbrDsInfos(delVO.getMemberId(), EEMConstants.VALUE_NO);

		int sqlCnt = 0;
		List<? extends EMDatedSegmentVO> dsInfoLst = getDatedTypeList(eemMbrDsInfoVOs, delVO.getDsCd());

		EEMMbrDsInfoVO aboveVO = (EEMMbrDsInfoVO) getFirstSegmentAbove(dsInfoLst, delVO.getEffEndDate());
		EEMMbrDsInfoVO belowVO = (EEMMbrDsInfoVO) getFirstSegmentBelow(dsInfoLst, delVO.getEffStartDate());

		if (Objects.isNull(belowVO) && Objects.isNull(aboveVO)) {
			throw new ApplicationException(CommonUtils.buildQuery("You must have at least one", delVO.getDsCd(), "Segment"));
		}

		if (Objects.nonNull(belowVO) && Objects.nonNull(aboveVO)) {

			EEMMbrDsInfoVO newAboveVO = (EEMMbrDsInfoVO) aboveVO.clone();

			sqlCnt = eemMbrDsInfoDAO.setOverride(newAboveVO, userId);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_ABOVE);
			}

			newAboveVO.setEffStartDate(DateMath.addOneDay(belowVO.getEffEndDate()));
			addNewSegment(userId, ts, newAboveVO);
			sqlCnt = eemMbrDsInfoDAO.insertMbr(newAboveVO);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_ABOVE);
			}
		}

		if (Objects.isNull(aboveVO)) {

			EEMMbrDsInfoVO newBelowVO = (EEMMbrDsInfoVO) belowVO.clone();

			sqlCnt = eemMbrDsInfoDAO.setOverride(newBelowVO, userId);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_BELOW);
			}

			newBelowVO.setEffEndDate(EEMConstants.EFF_END_DATE);
			addNewSegment(userId, ts, newBelowVO);
			sqlCnt = eemMbrDsInfoDAO.insertMbr(newBelowVO);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_BELOW);
			}
		}

		if (Objects.isNull(belowVO)) {

			EEMMbrDsInfoVO newAboveVO = (EEMMbrDsInfoVO) aboveVO.clone();

			sqlCnt = eemMbrDsInfoDAO.setOverride(newAboveVO, userId);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_BELOW);
			}

			newAboveVO.setEffStartDate(delVO.getEffStartDate());
			addNewSegment(userId, ts, newAboveVO);
			sqlCnt = eemMbrDsInfoDAO.insertMbr(newAboveVO);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_BELOW);
			}
		}

		sqlCnt = eemMbrDsInfoDAO.setOverride(delVO, userId);
		if (sqlCnt != 1) {
			throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT);
		}

		List<EEMMbrDsInfoVO> updatedMbrDsInfoVOList = getMbrDsInfoListFromDB(delVO.getMemberId(),
				delVO.getShowAll());
		if (StringUtils.equals(EEMConstants.VALUE_NO, delVO.getShowAll())) {
			setToContext(updatedMbrDsInfoVOList);
		} else {
			List<EEMMbrDsInfoVO> mbrDsInfoActiveVOList = (List<EEMMbrDsInfoVO>) getActiveDatedList(updatedMbrDsInfoVOList);
			setToContext(mbrDsInfoActiveVOList);
		}
		return true;
	}

	@SuppressWarnings("unchecked")
	public boolean mbrDsInfoUpdate(EEMMbrDsInfoVO newVO)
			throws ParseException, CloneNotSupportedException {

		String ts = DateUtil.getCurrentDatetimeStamp();
		/**
		 * Cambia-PWO-Start
		 */
		newVO.setPlanCode(newVO.getPlanCode());
		/**
		 * Cambia-PWO-End
		 */
		int sqlCnt = 0;
		String msg = null;
		if (!dsInfoExcludeFDOM(newVO.getDsCd())) {
			msg = checkDates(newVO);
			if (msg != null) {
				throw new ApplicationException(msg);
			}
		}

		// CR IFOX-00364596 - CMS mandate Start
		// Super User changes - start
		if (!(newVO.getDsCd().equalsIgnoreCase("HSPC"))) {
			// Super User changes - end
			int tmpRslt = validateDsValue(newVO);
			if (tmpRslt == 1) {
				msg = CommonUtils.buildQuery(newVO.getDsValue(), "is not valid for", newVO.getDsCd());
				throw new ApplicationException(msg);
			}
		}
		// CR IFOX-00364596 - CMS mandate End

		Map<String, String> type = new HashMap<>();
		type.put("DS_CD", newVO.getDsCd());
		String maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(), EEMConstants.EM_MBR_DSINFO, type);

		List<EEMMbrDsInfoVO> eemMbrDsInfoVOs = getMbrDsInfos(newVO.getMemberId(), EEMConstants.VALUE_NO);
		List<? extends EMDatedSegmentVO> dsInfoLst = getDatedTypeList(eemMbrDsInfoVOs, newVO.getDsCd());
		if (hasDataChanged(dsInfoLst, maxLastUpdate)) {
			throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
		}

		EEMMbrDsInfoVO matchVO = null;

		// the update case
		matchVO = (EEMMbrDsInfoVO) matchDatedSegment(dsInfoLst, newVO);
		String userId = sessionHelper.getUserInfo().getUserId();

		if (matchVO != null) {
			sqlCnt = eemMbrDsInfoDAO.setOverride(matchVO, userId);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT);
			}
			buildEEMMbrDsInfoVO(newVO, ts, userId);
			sqlCnt = eemMbrDsInfoDAO.insertMbr(newVO);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
			}
			int rslt = dsInfoTriggerCheck(matchVO, newVO, userId);
			if (rslt > 0) {
				throw new ApplicationException("dsInfoTriggerCheck Failed");
			}
			maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
					EEMConstants.EM_MBR_DSINFO, type);
			if (hasDataChanged(ts, maxLastUpdate)) {
				throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
			}

			List<EEMMbrDsInfoVO> updatedMbrDsInfoVOList = getMbrDsInfoListFromDB(newVO.getMemberId(),
					newVO.getShowAll());
			if (StringUtils.equals(EEMConstants.VALUE_NO, newVO.getShowAll())) {
				setToContext(updatedMbrDsInfoVOList);
			} else {
				List<EEMMbrDsInfoVO> mbrDsInfoActiveVOList = (List<EEMMbrDsInfoVO>) getActiveDatedList(updatedMbrDsInfoVOList);
				setToContext(mbrDsInfoActiveVOList);
			}
			return true;
		}

		// the update end date case - no change in data
		matchVO = (EEMMbrDsInfoVO) matchDatedSegmentEndDate(dsInfoLst, newVO);
		if (Objects.nonNull(matchVO)) {
			sqlCnt = eemMbrDsInfoDAO.setOverride(matchVO, userId);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT);
			}
			buildEEMMbrDsInfoVO(newVO, ts, userId);
			sqlCnt = eemMbrDsInfoDAO.insertMbr(newVO);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
			}

			int rslt = dsInfoTriggerCheck(matchVO, newVO, userId);
			if (rslt > 0) {
				throw new ApplicationException("DsInfoTriggerCheck Failed");
			}
			maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
					EEMConstants.EM_MBR_DSINFO, type);
			if (hasDataChanged(ts, maxLastUpdate)) {
				throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
			}

			List<EEMMbrDsInfoVO> updatedMbrDsInfoVOList = getMbrDsInfoListFromDB(newVO.getMemberId(),
					newVO.getShowAll());
			if (StringUtils.equals(EEMConstants.VALUE_NO, newVO.getShowAll())) {
				setToContext(updatedMbrDsInfoVOList);
			} else {
				List<EEMMbrDsInfoVO> mbrDsInfoActiveVOList = (List<EEMMbrDsInfoVO>) getActiveDatedList(updatedMbrDsInfoVOList);
				setToContext(mbrDsInfoActiveVOList);
			}
			return true;
		}

		if (newVO.getEffEndDate().equals(EEMConstants.EFF_END_DATE)) {

			EEMMbrDsInfoVO oldOpenVO = (EEMMbrDsInfoVO) getOpenendedSegment(dsInfoLst);

			List<? extends EMDatedSegmentVO> lstSegmentsAbove = getSegmentsAbove(dsInfoLst, newVO.getEffStartDate());
			Iterator<? extends EMDatedSegmentVO> it = lstSegmentsAbove.iterator();
			while (it.hasNext()) {
				EEMMbrDsInfoVO itemVO = (EEMMbrDsInfoVO) it.next();
				sqlCnt = eemMbrDsInfoDAO.setOverride(itemVO, userId);
				if (sqlCnt != 1) {
					throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_ABOVE);
				}
			}

			EEMMbrDsInfoVO belowVO = (EEMMbrDsInfoVO) getFirstOverlapSegmentBelow(dsInfoLst, newVO.getEffStartDate());
			if (Objects.nonNull(belowVO)) {

				sqlCnt = eemMbrDsInfoDAO.setOverride(belowVO, userId);
				if (sqlCnt != 1) {
					throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_BELOW);
				}

				// do we need to split the segmment below
				if (belowVO.getEffStartDate().compareTo(newVO.getEffStartDate()) < 0) {
					EEMMbrDsInfoVO tempVO = (EEMMbrDsInfoVO) belowVO.clone();
					tempVO.setEffEndDate(DateMath.minusOneDay(newVO.getEffStartDate()));
					buildEEMMbrDsInfoVO(tempVO, ts, userId);
					sqlCnt = eemMbrDsInfoDAO.insertMbr(tempVO);
					if (sqlCnt != 1) {
						throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_BELOW);
					}
				}
			}

			buildEEMMbrDsInfoVO(newVO, ts, userId);
			sqlCnt = eemMbrDsInfoDAO.insertMbr(newVO);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
			}

			int rslt = dsInfoTriggerCheck(oldOpenVO, newVO, userId);
			if (rslt > 0) {
				throw new ApplicationException("DsInfoTriggerCheck Failed");
			}
			maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
					EEMConstants.EM_MBR_DSINFO, type);
			if (hasDataChanged(ts, maxLastUpdate)) {
				throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
			}

			List<EEMMbrDsInfoVO> updatedMbrDsInfoVOList = getMbrDsInfoListFromDB(newVO.getMemberId(),
					newVO.getShowAll());
			if (StringUtils.equals(EEMConstants.VALUE_NO, newVO.getShowAll())) {
				setToContext(updatedMbrDsInfoVOList);
			} else {
				List<EEMMbrDsInfoVO> mbrDsInfoActiveVOList = (List<EEMMbrDsInfoVO>) getActiveDatedList(updatedMbrDsInfoVOList);
				setToContext(mbrDsInfoActiveVOList);
			}
			return true;

			// end of open ended new segment processing

		}

		// end dated segment
		if (!doDatedSegmentAdjust(dsInfoLst, newVO, ts, userId, eemMbrDsInfoDAO)) {
			return false;
		}

		// add the new segment
		buildEEMMbrDsInfoVO(newVO, ts, userId);
		
		sqlCnt = eemMbrDsInfoDAO.insertMbr(newVO);
		if (sqlCnt != 1) {
			throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
		}
		maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
				EEMConstants.EM_MBR_DSINFO, type);
		if (hasDataChanged(ts, maxLastUpdate)) {
			throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
		}

		List<EEMMbrDsInfoVO> updatedMbrDsInfoVOList = getMbrDsInfoListFromDB(newVO.getMemberId(),
				newVO.getShowAll());
		if (StringUtils.equals(EEMConstants.VALUE_NO, newVO.getShowAll())) {
			setToContext(updatedMbrDsInfoVOList);
		} else {
			List<EEMMbrDsInfoVO> mbrDsInfoActiveVOList = (List<EEMMbrDsInfoVO>) getActiveDatedList(updatedMbrDsInfoVOList);
			setToContext(mbrDsInfoActiveVOList);
		}
		return true;

	}

	// -1 no Ds Code Found
	// 0 matched Ds Code and Value
	// 1 no match on Ds Value
	public int validateDsValue(EEMMbrDsInfoVO newVO) {
		List<LabelValuePair> lst = eemCodeCache.getLstDsVV();
		boolean foundCode = false;

		Iterator<LabelValuePair> it = lst.iterator();
		while (it.hasNext()) {
			LabelValuePair lvp = it.next();
			if (StringUtils.equals(lvp.getValue(), newVO.getDsCd())) {
				foundCode = true;
				if (StringUtils.equals(lvp.getLabel(), newVO.getDsValue())) {
					return 0;
				}
			}
		}

		if (foundCode) {
			return 1;
		}

		return -1;
	}

	public int dsInfoTriggerCheck(EEMMbrDsInfoVO oldVO, EEMMbrDsInfoVO newVO, String userId)
			throws ParseException {

		if (!newVO.getEffEndDate().equals(EEMConstants.EFF_END_DATE))
			return -1;

		String dsCode = newVO.getDsCd();

		String trigCode = getTriggerCode(dsCode);

		if (trigCode == null)
			return -1;

		if (oldVO != null && newVO.getDsValue().equals(oldVO.getDsValue())
				&& newVO.getEffStartDate().equals(oldVO.getEffStartDate())) {
			return -1;
		}

		if (!(StringUtils.trimToEmpty(newVO.getCheckBoxInd()).equalsIgnoreCase(EEMConstants.VALUE_YES))
				&& trigCode.equals(EEMConstants.TRIG_CODE_75)) {
			String cpm = eemCodeCache.getCPMDate();
			if (cpm == null)
				throw new ApplicationException("CPM Not Found");
			cpm = DateFormatter.reFormat(cpm, DateFormatter.MMYYYY, DateFormatter.YYYYMM) + "01";
			String cpm2 = DateMath.addMonth(cpm, 2);
			if (!DateMath.isBetween(newVO.getEffStartDate(), cpm, cpm2)) {
				throw new ApplicationException("Start Date must be between "
						+ DateFormatter.reFormat(cpm, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY) + " and "
						+ DateFormatter.reFormat(cpm2, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
			}
		}

		EEMMbrMasterVO masterVO = sessionHelper.getEEMContext().getMbrMasterVO();
		EEMMbrEnrollmentVO mbrEnrlVO = (EEMMbrEnrollmentVO) getSegmentActiveOn(masterVO.getMbrEnrollmentList(),
				newVO.getEffStartDate());

		if (!Optional.ofNullable(mbrEnrlVO).isPresent()) {
			throw new ApplicationException("Update DsInfo got failed due to no active enrollment available for the given effective date!");
		}

		String ts = DateUtil.getCurrentDatetimeStamp();

		EMMbrTriggerDO trig = populateEMMbrTriggerVO(newVO, userId, trigCode, mbrEnrlVO, ts);

		int sqlCnt = eemEnrollDao.insertMbrTrigger(trig);
		if (sqlCnt != 1) {
			setCMSTxnErrMsg(trigCode);
			return 1;
		}

		return 0;

	}

	private void setCMSTxnErrMsg(String trigCode) {
		if (trigCode.equals(EEMConstants.TRIG_CODE_75))
			throw new ApplicationException("Error Creating CMS Transaction (75) Trigger");
		else if (trigCode.equals(EEMConstants.TRIG_CODE_79))
			throw new ApplicationException("Error Creating CMS Transaction (79) Trigger");
		else
			throw new ApplicationException("Error Creating CMS Transaction Trigger");
	}

	private String getTriggerCode(String dsCode) {
		String trigCode = null;
		if (dsCode.equals(EEMMbrDsInfoVO.DS_PWO)) {
			trigCode = EEMConstants.TRIG_CODE_75;
		} else if (dsCode.equals(EEMMbrDsInfoVO.DS_DOO)) {
			trigCode = EEMConstants.TRIG_CODE_79;
		}
		return trigCode;
	}


	public boolean dsInfoExcludeFDOM(String dsCode) {
		return StringUtils.equals(dsCode, "HSPC") || StringUtils.equals(dsCode, "TRAN")
				|| StringUtils.equals(dsCode, "DIAL");
	}

	public List<EEMMbrDsInfoVO> getMbrDsInfoListFromDB(String mbrId, String showAll) {

		List<EEMMbrDsInfoVO> mbrDsInfoVOList = new ArrayList<>();
		String custId = sessionHelper.getUserInfo().getCustomerId();
		List<EEMMbrDsInfoDO> mbrDsInfoDOList = eemMbrDsInfoDAO.getMbrDsInfos(custId, mbrId, showAll);
		CommonUtils.copyList(mbrDsInfoDOList, mbrDsInfoVOList, EEMMbrDsInfoVO.class);
		return mbrDsInfoVOList;
	}

	public void setToContext(List<EEMMbrDsInfoVO> mbrDsInfoVOList) {
		EEMContext context = sessionHelper.getEEMContext();
		context.getMbrMasterVO().setMbrDsInfoList(mbrDsInfoVOList);
		sessionHelper.setEEMContext(context);
	}

	private void addNewSegment(String userId, String ts, EEMMbrDsInfoVO newAboveVO) {
		newAboveVO.setOverrideInd(EEMConstants.VALUE_NO);
		buildEEMMbrDsInfoVO(newAboveVO, ts, userId);
	}
	
	private void buildEEMMbrDsInfoVO(EEMMbrDsInfoVO newVO, String ts, String userId) {
		newVO.setCreateTime(ts);
		newVO.setCreateUserId(userId);
		newVO.setLastUpdtTime(ts);
		newVO.setLastUpdtUserId(userId);
	}
	
	private EMMbrTriggerDO populateEMMbrTriggerVO(EEMMbrDsInfoVO newVO, String userId, String trigCode,
			EEMMbrEnrollmentVO mbrEnrlVO, String ts) {
		EMMbrTriggerDO trig = new EMMbrTriggerDO();
		trig.setCustomerId(newVO.getCustomerId());
		trig.setMemberId(newVO.getMemberId());
		trig.setTriggerType(EEMConstants.TRIG_TYPE_TXN);
		trig.setEffectiveDate(newVO.getEffStartDate());
		trig.setCreateTime(ts);
		trig.setTriggerCode(trigCode);
		trig.setPlanId(mbrEnrlVO.getPlanId());
		trig.setPbpId(mbrEnrlVO.getPbpId());
		trig.setPlanDesignation(mbrEnrlVO.getPlanDesignation());
		
		if (StringUtils.equals(newVO.getCheckBoxInd(), EEMConstants.VALUE_YES)) {
			trig.setTriggerStatus(EEMConstants.TRIG_STATUS_CLOSED);
			trig.setProcessSource(EEMConstants.TRIG_PROCESS_SOURCE_WEBENRSP);
		} else {
			trig.setTriggerStatus(EEMConstants.TRIG_STATUS_OPEN);
			trig.setProcessSource(EEMConstants.TRIG_PROCESS_SOURCE_WEBENRL);
		}
		trig.setOrigTriggerType(EEMConstants.BLANK);
		trig.setOrigTriggerCode(EEMConstants.BLANK);
		trig.setOrigEffectiveDate(EEMConstants.BLANK);
		trig.setOrigTriggerCreateTime(EEMConstants.BLANK);
		trig.setCreateUserId(userId);
		trig.setLastUpdtUserId(userId);
		trig.setLastUpdtTime(ts);
		return trig;
	}
}
