package com.medicare.mss.rowmappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.RowMapper;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.domainobject.EEMMbrDemographicDO;
import com.medicare.mss.util.StringUtil;

public class MbrDemographicRowMapper implements RowMapper<EEMMbrDemographicDO> {

	@Override
	public EEMMbrDemographicDO mapRow(ResultSet rs, int rowNum) throws SQLException {
		EEMMbrDemographicDO emMbrDemographicDO = new EEMMbrDemographicDO();
		emMbrDemographicDO.setCustomerId(StringUtil.nonNullTrim(rs.getString("CUSTOMER_ID")));
		emMbrDemographicDO.setMemberId(StringUtil.nonNullTrim(rs.getString("MEMBER_ID")));
		emMbrDemographicDO.setCmsEffMonth(StringUtil.nonNullTrim(rs.getString("CMS_EFF_MO")));
		emMbrDemographicDO.setDemoSeqNbr(rs.getInt("DEMO_SEQ_NBR"));
		emMbrDemographicDO.setCurrentInd(StringUtil.nonNullTrim(rs.getString("CURRENT_IND")));
		emMbrDemographicDO.setOverrideInd(StringUtil.nonNullTrim(rs.getString("OVERRIDE_IND")));
		emMbrDemographicDO.setLastName(StringUtil.nonNullTrim(rs.getString("LAST_NAME")));
		emMbrDemographicDO.setFirstName(StringUtil.nonNullTrim(rs.getString("FIRST_NAME")));
		emMbrDemographicDO.setMiddleInitial(StringUtil.nonNullTrim(rs.getString("MIDDLE_INITIAL")));
		emMbrDemographicDO.setPrefix(StringUtil.nonNullTrim(rs.getString("PREFIX")));
		emMbrDemographicDO.setSuffix(StringUtil.nonNullTrim(rs.getString("SUFFIX")));
		emMbrDemographicDO.setMailLastName(StringUtil.nonNullTrim(rs.getString("MAIL_LAST_NAME")));
		emMbrDemographicDO.setMailFirstName(StringUtil.nonNullTrim(rs.getString("MAIL_FIRST_NAME")));
		emMbrDemographicDO.setMailMiddleInit(StringUtil.nonNullTrim(rs.getString("MAIL_MIDDLE_INIT")));
		emMbrDemographicDO.setMailSuffix(StringUtil.nonNullTrim(rs.getString("MAIL_SUFFIX")));
		emMbrDemographicDO.setInsCardName(StringUtil.nonNullTrim(rs.getString("INS_CARD_NAME")));
		emMbrDemographicDO.setSsn(StringUtil.nonNullTrim(rs.getString("SSN")));
		emMbrDemographicDO.setBirthDate(StringUtil.nonNullTrim(rs.getString("BIRTH_DATE")));
		emMbrDemographicDO.setDeathDate(StringUtil.nonNullTrim(rs.getString("DEATH_DATE")));
		if (StringUtils.isNotBlank(rs.getString("MARITAL_STATUS"))) {
			emMbrDemographicDO.setMaritalStatus(StringUtil.nonNullTrim(rs.getString("MARITAL_STATUS")));
		} else {
			emMbrDemographicDO.setMaritalStatus(EEMConstants.MARITAL_STATUS_U);
		}
		emMbrDemographicDO.setGenderCd(StringUtil.nonNullTrim(rs.getString("GENDER_CD")));
		emMbrDemographicDO.setRaceCd(StringUtil.nonNullTrim(rs.getString("RACE_CD")));
		emMbrDemographicDO.setMbrEmail(StringUtil.nonNullTrim(rs.getString("MBR_EMAIL")));
		emMbrDemographicDO.setAuthLastName(StringUtil.nonNullTrim(rs.getString("AUTH_LAST_NAME")));
		emMbrDemographicDO.setAuthFirstName(StringUtil.nonNullTrim(rs.getString("AUTH_FIRST_NAME")));
		emMbrDemographicDO.setAuthMiddleInit(StringUtil.nonNullTrim(rs.getString("AUTH_MIDDLE_INIT")));
		emMbrDemographicDO.setAuthRelationshipCd(StringUtil.nonNullTrim(rs.getString("AUTH_RELATIONSHIP_CD")));
		emMbrDemographicDO.setEmergcyName(StringUtil.nonNullTrim(rs.getString("EMERGCY_NAME")));
		emMbrDemographicDO.setEmergcyPhone(StringUtil.nonNullTrim(rs.getString("EMERGCY_PHONE")));
		emMbrDemographicDO.setEmergcyRelationshipCd(StringUtil.nonNullTrim(rs.getString("EMERGCY_RELATIONSHIP_CD")));
		emMbrDemographicDO.setEmergcyEmail(StringUtil.nonNullTrim(rs.getString("EMERGCY_EMAIL")));
		emMbrDemographicDO.setLanguageCd(StringUtil.nonNullTrim(rs.getString("LANGUAGE_CD")));
		emMbrDemographicDO.setAltCorrespondenceInd(StringUtil.nonNullTrim(rs.getString("ALT_CORRES_IND")));
		emMbrDemographicDO.setSpouseWorkInd(StringUtil.YorN(rs.getString("SPOUSE_WORK_IND")));
		emMbrDemographicDO.setMemberStatus(StringUtil.nonNullTrim(rs.getString("MEMBER_STATUS")));
		emMbrDemographicDO.setFileId(StringUtil.nonNullTrim(rs.getString("FILE_ID")));
		emMbrDemographicDO.setCreateTime(StringUtil.nonNullTrim(rs.getString("CREATE_TIME")));
		emMbrDemographicDO.setCreateUserId(StringUtil.nonNullTrim(rs.getString("CREATE_USERID")));
		emMbrDemographicDO.setLastUpdtTime(StringUtil.nonNullTrim(rs.getString("LAST_UPDT_TIME")));
		emMbrDemographicDO.setLastUpdtUserId(StringUtil.nonNullTrim(rs.getString("LAST_UPDT_USERID")));
		emMbrDemographicDO.setRolloverTime(StringUtil.nonNullTrim(rs.getString("ROLLOVER_TIME")));
		emMbrDemographicDO.setRolloverUserId(StringUtil.nonNullTrim(rs.getString("ROLLOVER_USERID")));

		return emMbrDemographicDO;
	}

}
