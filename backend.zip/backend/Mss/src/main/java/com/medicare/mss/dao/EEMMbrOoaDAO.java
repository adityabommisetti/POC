package com.medicare.mss.dao;

import java.text.ParseException;
import java.util.List;

import com.medicare.mss.domainobject.EEMMbrEnrollmentDO;
import com.medicare.mss.domainobject.EEMMbrOoaInfoDO;
import com.medicare.mss.domainobject.EMMbrTriggerDO;

public interface EEMMbrOoaDAO {

	int closeFUMTrigger(EMMbrTriggerDO trig);

	int setOoaDisenroll(EEMMbrOoaInfoDO mbrOoa, EEMMbrEnrollmentDO enroll, String userId) throws ParseException;

	EEMMbrEnrollmentDO getOoaDisenroll(EEMMbrOoaInfoDO mbrOoa, String userId);

	int insertMbrOoaInfo(EEMMbrOoaInfoDO mbrOoaInfo);

	List<EEMMbrOoaInfoDO> getMbrOoaInfos(String customerId, String memberId, String showAll);

	int setOoaInfoOverride(EEMMbrOoaInfoDO mbrOoa, String userId);

}
