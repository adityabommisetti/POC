/**
 * 
 */
package com.medicare.mss.domainobject;

import java.io.Serializable;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

/**
 * @author dkumar
 *
 */
@Data
public class EEMBillFuncDO implements Serializable {

	private static final long serialVersionUID = 2041029739392880170L;

	@ColumnMapper(columnName = "FUNCTION_CD", propertyName = "functionCd")
	private String functionCd;
	
	@ColumnMapper(columnName = "SHORT_DESC", propertyName = "shortDesc")
	private String shortDesc;
	
	@ColumnMapper(columnName = "LONG_DESC", propertyName = "longDesc")
	private String longDesc;
	
	@ColumnMapper(columnName = "USER_SYSTEM_IND", propertyName = "userSystemInd")
	private String userSystemInd;
	
	@ColumnMapper(columnName = "HDR_DTL_TRAN_IND", propertyName = "hdrDtlTranInd")
	private String hdrDtlTranInd;
	
	@ColumnMapper(columnName = "AMT_SIGN_CD", propertyName = "amtSignCd")
	private String amtSignCd;
	
	@ColumnMapper(columnName = "ACTIVE_IND", propertyName = "activeInd")
	private String activeInd;
	
	@ColumnMapper(columnName = "BANK_ACCT_CD", propertyName = "bankAcctCd")
	private String bankAcctCd;
	
	@ColumnMapper(columnName = "GL_TRANS_CD", propertyName = "glTranCd")
	private String glTranCd;
}
