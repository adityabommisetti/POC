package com.medicare.mss.vo;

import java.io.Serializable;

import lombok.Data;

@Data
public class EEMMbrTriggerLtrDataVO implements Serializable {

	private static final long serialVersionUID = 3469829234634419169L;

	private String customerId;
	private String memberId;
	private String triggerType;
	private String effectiveDate;
	private String createTime;
	private int variableSeqNbr;
	private int continueSeqNbr;
	private String variableId;
	private String variableData;
	private String lastUpdtTime;
	private String lastUpdtUserId;

}
