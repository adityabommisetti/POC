/**
 * 
 */
package com.medicare.mss.vo;

import java.io.Serializable;

import lombok.Data;

/**
 * @author dkumar
 *
 */
@Data
public class EEMBillFuncVO implements Serializable {

	private static final long serialVersionUID = -8229842102828050138L;
	
	private String functionCd;
	private String shortDesc;
	private String longDesc;
	private String userSystemInd;
	private String hdrDtlTranInd;
	private String amtSignCd;
	private String bankAcctCd;
}
