/**
 * 
 */
package com.medicare.mss.dao;

import java.util.List;
import java.util.Map;

import com.medicare.mss.domainobject.EEMLEPMaximusDO;
import com.medicare.mss.domainobject.EEMMbrLepInfoDO;
import com.medicare.mss.domainobject.EMMbrTriggerDO;
import com.medicare.mss.vo.EMDatedSegmentVO;

/**
 * @author DU20098149
 *
 */
public interface EEMLepDAO extends EEMMbrBaseDAO {

	EEMLEPMaximusDO getLepMaximusDetails(String customerId, String mbrId);

	boolean insertOrUpdateLEPMaximus(EEMLEPMaximusDO newDO);

	boolean cancelAnyOpenTriggers(EMMbrTriggerDO eemMbrTrigger);

	List<EEMMbrLepInfoDO> getMbrLepInfos(String customerId, String memberId, String showAll);

	int setOverride(EMDatedSegmentVO emDatedSegmentVO, String userId);

	int insertMbr(EMDatedSegmentVO emDatedSegmentVO);

	byte[] displayDocumentFromDB(Map<String, String> searchParamMap);

}
