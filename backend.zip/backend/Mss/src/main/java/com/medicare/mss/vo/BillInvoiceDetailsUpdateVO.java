/**
 * 
 */
package com.medicare.mss.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.security.vo.EEMBillingInvCommentVO;

import lombok.Data;

/**
 * @author DU20098149
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BillInvoiceDetailsUpdateVO {

	private EEMBillingInvHeaderDtlsVO billHeaderVO;
	private EEMBillingInvoiceDtlsVO billInvVO;
	private EEMBillingInvCommentVO billInvCommentVO;
	private String searchInvoiceGroup;
	private String memberId;

}
