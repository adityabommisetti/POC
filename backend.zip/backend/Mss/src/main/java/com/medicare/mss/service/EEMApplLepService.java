package com.medicare.mss.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.medicare.mss.caching.EEMProfileSettings;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.EEMProfileConstants;
import com.medicare.mss.dao.EEMApplDAO;
import com.medicare.mss.dao.EEMApplLepDAO;
import com.medicare.mss.dao.EEMMbrDAO;
import com.medicare.mss.domainobject.EEMApplTriggerDO;
import com.medicare.mss.domainobject.EEMLepAttestCallDO;
import com.medicare.mss.domainobject.EEMLepAttestCcfDO;
import com.medicare.mss.domainobject.EEMLepAttestInfoDO;
import com.medicare.mss.domainobject.EEMLepPtnlUncovMthsDO;
import com.medicare.mss.domainobject.EEMLepSummaryDO;
import com.medicare.mss.domainobject.EMMbrTriggerDO;
import com.medicare.mss.domainobject.MBDNunCmoDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.helper.EEMApplHelper;
import com.medicare.mss.helper.EEMContext;
import com.medicare.mss.helper.EEMEnrollHelper;
import com.medicare.mss.security.vo.SecuserDetails;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EEMApplLepMasterVO;
import com.medicare.mss.vo.EEMLepAttestCallMasterVO;
import com.medicare.mss.vo.EEMLepAttestCcfVO;
import com.medicare.mss.vo.EEMLepAttestInfoVO;
import com.medicare.mss.vo.EEMLepPtnlUncovMthsVO;
import com.medicare.mss.vo.EEMLepSummaryVO;
import com.medicare.mss.vo.EEMMbrLepInfoVO;
import com.medicare.mss.vo.MBDNunCmoVO;

@Service
@Transactional(rollbackFor = ApplicationException.class)
public class EEMApplLepService {

	private static final Logger LOG = LoggerFactory.getLogger(EEMApplLepService.class);

	@Autowired
	private EEMApplLepDAO lepDao;

	@Autowired
	private CacheService sessionHelper;

	@Autowired
	private EEMProfileSettings eemProfileSettings;

	@Autowired
	private EEMLepAttestService attestService;

	@Autowired
	private EEMApplHelper applHelper;

	@Autowired
	private EEMApplDAO applicationDAO;
	
	@Autowired
	private EEMEnrollHelper enrollHelper;
	
	@Autowired
	private EEMMbrDAO  mbrDAO;

	@Transactional(readOnly = true)
	public boolean getApplLepDetails(EEMApplLepMasterVO masterVO) throws ApplicationException {
		boolean rslt = false;
		int totalPlepMonths = 0;

		String hicNumber = StringUtil.nonNullTrim(masterVO.getHicNbr());
		String mbi = masterVO.getMbi();
		String applId = String.valueOf(masterVO.getPrimaryId());
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();
		EEMLepSummaryDO applLepSummaryInfo = new EEMLepSummaryDO();
		masterVO.setCustomerId(customerId);
		masterVO.setOperatorId(userId);

		String beqCheck = eemProfileSettings.getCalendarProfileInd(customerId, EEMProfileConstants.BEQCHECK);
		
		if(StringUtil.nonNullTrim(beqCheck).equals("Y")){
			applLepSummaryInfo = lepDao.getApplLepSummaryInfoBEQR(hicNumber, mbi);
		}
		if(StringUtil.isNullOrEmptyOrSpace(beqCheck) 
				|| StringUtil.nonNullTrim(beqCheck).equals("N") 
				|| StringUtil.isNullOrEmptyOrSpace(applLepSummaryInfo.getEligibilitySrcTable())){
			applLepSummaryInfo = lepDao.getApplLepSummaryInfo(hicNumber, mbi);
		}
		List<MBDNunCmoVO> nunCMOListVO = new ArrayList<>();
		List<MBDNunCmoDO> nunCMOList = applLepSummaryInfo.getNunCMOList();
		CommonUtils.copyList(nunCMOList, nunCMOListVO, MBDNunCmoVO.class);

		EEMLepSummaryVO lepSummaryVO = new EEMLepSummaryVO();
		

		BeanUtils.copyProperties(applLepSummaryInfo, lepSummaryVO);
		lepSummaryVO.setNunCMOList(nunCMOListVO);
		masterVO.setLepSummaryVO(lepSummaryVO);

		EEMLepAttestInfoDO applLepAttestInfos = lepDao.getApplLepAttestInfos(customerId, applId, EEMConstants.BLANK);
		applLepAttestInfos.setPrimaryId(applId);
		applLepAttestInfos.setUserId(userId);
		EEMLepAttestInfoVO applLepAttestInfosVO = new EEMLepAttestInfoVO();
		List<EEMLepAttestCcfVO> lepAttestListVO = new ArrayList<>();
		CommonUtils.copyList(applLepAttestInfos.getLepAttestList(), lepAttestListVO, EEMLepAttestCcfVO.class);

		BeanUtils.copyProperties(applLepAttestInfos, applLepAttestInfosVO);
		applLepAttestInfosVO.setLepAttestList(lepAttestListVO);

		masterVO.setLepAttestInfoVO(applLepAttestInfosVO);
		EEMLepPtnlUncovMthsVO lepPtnlUncovMthsVO = new EEMLepPtnlUncovMthsVO();
		lepPtnlUncovMthsVO.setCustomerId(customerId);
		lepPtnlUncovMthsVO.setPrimaryId(applId);

		List<EEMLepPtnlUncovMthsVO> applLepPtnlUncovMthsVOs = getPtnlUnCovMnthsApplLep(applId, EEMConstants.VALUE_NO,
				false);

		totalPlepMonths = applLepPtnlUncovMthsVOs.stream().filter(x -> EEMConstants.VALUE_NO.equals(x.getOverRideInd()))
				.mapToInt(EEMLepPtnlUncovMthsVO::getPlepMonths).sum();

		masterVO.setTotalPlepMonths(String.valueOf(totalPlepMonths));
		masterVO.setPotentialUnCovMthsList(applLepPtnlUncovMthsVOs);

		EEMLepAttestCallMasterVO attestCallVO = setAttestationCalls(customerId, applId, masterVO, false);
		masterVO.setAttestCallMasterVO(attestCallVO);
		setApplLEPTimers(masterVO.getAttestCallMasterVO());
		rslt = true;
		return rslt;
	}

	@Transactional(readOnly = true)
	public List<EEMLepPtnlUncovMthsVO> getPtnlUnCovMnthsApplLep(String primaryId, String overrideInd, boolean isMember)
			throws ApplicationException {
		String customerId = sessionHelper.getUserInfo().getCustomerId();

		List<EEMLepPtnlUncovMthsDO> potentialUnCovMthsList = lepDao.getPotentialUnCovMonth(customerId, primaryId,
				overrideInd, isMember);

		List<EEMLepPtnlUncovMthsVO> potentialUnCovMthsListVO = new ArrayList<>();
		CommonUtils.copyList(potentialUnCovMthsList, potentialUnCovMthsListVO, EEMLepPtnlUncovMthsVO.class);
		return potentialUnCovMthsListVO;
	}

	public EEMLepAttestCallMasterVO setAttestationCalls(String customerId, String primary, EEMApplLepMasterVO masterVO,
			boolean isMember) throws ApplicationException {

		Map<String, List<EEMLepAttestCallDO>> appLepNunCmo = lepDao.getAppLepNunCmo(customerId, primary, isMember);
		List<EEMLepAttestCallDO> outBoundInitial = (appLepNunCmo.get("O-I") != null) ? appLepNunCmo.get("O-I")
				: new ArrayList<>();
		List<EEMLepAttestCallDO> inBoundInitial = (appLepNunCmo.get("I-I") != null) ? appLepNunCmo.get("I-I")
				: new ArrayList<>();
		List<EEMLepAttestCallDO> outBoundInComplete = (appLepNunCmo.get("O-C") != null) ? appLepNunCmo.get("O-C")
				: new ArrayList<>();
		List<EEMLepAttestCallDO> inBoundInComplete = (appLepNunCmo.get("I-C") != null) ? appLepNunCmo.get("I-C")
				: new ArrayList<>();
		List<EEMLepAttestCallDO> inBoundLate = (appLepNunCmo.get("I-L") != null) ? appLepNunCmo.get("I-L")
				: new ArrayList<>();

		EEMLepAttestCallMasterVO masterCallDo = new EEMLepAttestCallMasterVO();
		masterCallDo.setPrimaryId(primary);
		masterCallDo.setCustomerId(customerId);
		masterCallDo.setOutBoundInitial(outBoundInitial);
		masterCallDo.setInBoundInitial(inBoundInitial);
		masterCallDo.setOutBoundInComplete(outBoundInComplete);
		masterCallDo.setInBoundInComplete(inBoundInComplete);
		masterCallDo.setInBoundLate(inBoundLate);
		return masterCallDo;

	}

	public void setApplLEPTimers(EEMLepAttestCallMasterVO lepInfoVo) throws ApplicationException {

		Map<String, String> availableTriggers = lepDao.getApplTrigger(lepInfoVo.getCustomerId(),
				lepInfoVo.getPrimaryId(), false, EEMConstants.TRIG_TYPE_FOLLOWUP_APPL);

		String result = getTimerCheck(availableTriggers, EEMConstants.TRIG_CODE_LE21);
		lepInfoVo.setLe21TimerCheck(result);

		result = getTimerCheck(availableTriggers, EEMConstants.TRIG_CODE_OBC1);
		lepInfoVo.setObc1TimerCheck(result);

		result = getTimerCheck(availableTriggers, EEMConstants.TRIG_CODE_OBC2);
		lepInfoVo.setObc2TimerCheck(result);

		result = getTimerCheck(availableTriggers, EEMConstants.TRIG_CODE_OBC3);
		lepInfoVo.setObc3TimerCheck(result);

	}

	private String getTimerCheck(Map<String, String> availableTriggers, String triggerName) {
		String result = "false";
		if (availableTriggers.containsKey(triggerName)) {
			if (availableTriggers.get(triggerName).equals(EEMConstants.TRIG_STATUS_OPEN)) {
				result = "true"; // LE21 timer open
			} else {
				result = "closed";// LE21 timer closed
			}

		}
		return result;
	}

	public EEMLepAttestCallMasterVO updateAttestCall(EEMLepAttestCallMasterVO attestCallMasterVO, boolean isMember)
			throws ApplicationException {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		attestCallMasterVO.setCustomerId(customerId);
		if (!isMember) {
			setApplLEPTimers(attestCallMasterVO);
		}
		return setApplLepNunCmo(attestCallMasterVO, isMember);

	}

	private EEMLepAttestCallMasterVO setApplLepNunCmo(EEMLepAttestCallMasterVO attestCallMasterVO, boolean isMember)
			throws ApplicationException {

		String customerId = attestCallMasterVO.getCustomerId();
		String applId = attestCallMasterVO.getPrimaryId();
		String userId = sessionHelper.getUserInfo().getUserId();

		List<EEMLepAttestCallDO> inBoundInComplete = attestCallMasterVO.getInBoundInComplete();
		List<EEMLepAttestCallDO> inBoundInitial = attestCallMasterVO.getInBoundInitial();
		List<EEMLepAttestCallDO> inBoundLate = attestCallMasterVO.getInBoundLate();
		List<EEMLepAttestCallDO> outBoundInComplete = attestCallMasterVO.getOutBoundInComplete();
		List<EEMLepAttestCallDO> outBoundInitial = attestCallMasterVO.getOutBoundInitial();

		boolean isUpdated = insertApplLepNunCmo(attestCallMasterVO, customerId, applId, userId, outBoundInitial,
				EEMConstants.OUTBOUND_INITIAL, isMember);
		if (!isUpdated) {
			attestCallMasterVO.setOutBoundInitial(null);
		}

		isUpdated = insertApplLepNunCmo(attestCallMasterVO, customerId, applId, userId, inBoundInitial,
				EEMConstants.INBOUND_INITIAL, isMember);
		if (!isUpdated) {
			attestCallMasterVO.setInBoundInitial(null);
		}

		isUpdated = insertApplLepNunCmo(attestCallMasterVO, customerId, applId, userId, outBoundInComplete,
				EEMConstants.OUTBOUND_INCOMPLETE, isMember);
		if (!isUpdated) {
			attestCallMasterVO.setOutBoundInComplete(null);
		}

		isUpdated = insertApplLepNunCmo(attestCallMasterVO, customerId, applId, userId, inBoundInComplete,
				EEMConstants.INBOUND_INCOMPLETE, isMember);
		if (!isUpdated) {
			attestCallMasterVO.setInBoundInComplete(null);
		}

		isUpdated = insertApplLepNunCmo(attestCallMasterVO, customerId, applId, userId, inBoundLate,
				EEMConstants.INBOUND_LATE, isMember);
		if (!isUpdated) {
			attestCallMasterVO.setInBoundLate(null);
		}

		return attestCallMasterVO;

	}

	private boolean insertApplLepNunCmo(EEMLepAttestCallMasterVO masterVo, String customerId, String primaryId,
			String userId, List<EEMLepAttestCallDO> listDo, String attestCallType, boolean isMember)
			throws ApplicationException {
		boolean isUpdated = false;
		if (listDo != null && !listDo.isEmpty()) {
			EEMLepAttestCallDO attestDO = listDo.get(listDo.size() - 1);
			attestDO.setAttempt(String.valueOf(listDo.size()));
			String isChanged = StringUtil.nonNullTrim(attestDO.getIsChange());

			if (EEMConstants.VALUE_YES.equalsIgnoreCase(isChanged)) {

				attestDO.setUserId(userId);
				String ts = DateUtil.getCurrentDatetimeStamp();
				attestDO.setCreateTime(ts);
				isUpdated = lepDao.insertMbrLepAttInfo(customerId, primaryId, attestDO, attestCallType);

				boolean le21Inserted = setApplLepNunCmoTimer(customerId, primaryId, attestDO, attestCallType, isMember);
				if (le21Inserted) {
					masterVo.setLe21TimerCheck("true");

				}

			}
		}

		return isUpdated;
	}

	@SuppressWarnings("deprecation")
	private boolean mbrLepAttestIncTimer(String customerId, String primaryId, String userId, boolean isMember,
			String ts) throws ApplicationException {

		boolean flag = false;

		Integer sqlcnt1 = lepDao.updateTrigger(customerId, primaryId, userId, isMember);

		boolean isExist = lepDao.checkMbrTriggerStatus(customerId, primaryId, EEMConstants.TRIG_CODE_LE21,
				EEMConstants.TRIG_STATUS_OPEN);

		if (!isExist) {
			
			EEMLepAttestInfoVO lepAttestInfoVO = sessionHelper.getEEMContext().getMbrMasterVO().getEemLepMasterVO()
					.getLepAttestInfoVO();
			EEMMbrLepInfoVO eemMbrLepInfoVO = sessionHelper.getEEMContext().getMbrMasterVO().getEemLepMasterVO()
					.getEemMbrLepInfoVOs().get(0);

			int interval = eemProfileSettings.getParmNumber(customerId, EEMConstants.TRIG_CODE_LE21);
			String modifiedDate = StringUtil
					.nonNullTrim(DateFormatter.reFormat(StringUtil.nonNullTrim(lepAttestInfoVO.getAttestationRecDate()),
							DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));

			String trigEffectDate = null;
			Date triggerEffectiveDate = null;
			if (!modifiedDate.isEmpty()) {
				triggerEffectiveDate = new Date(Date
						.parse(DateFormatter.reFormat(modifiedDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY)));
			}
			SimpleDateFormat sdFormat = new SimpleDateFormat("yyyyMMdd");
		
			if (triggerEffectiveDate != null) {
				Date trigEffDate = triggerEffectiveDate;
				trigEffDate.setDate(triggerEffectiveDate.getDate() + interval);
				trigEffectDate = sdFormat.format(trigEffDate);
			}

			String effDateFrmt = DateFormatter.reFormat(trigEffectDate,
					DateFormatter.YYYY_MM_DD, DateFormatter.YYYYMMDD);
			
			EMMbrTriggerDO mbrTriggerDO = enrollHelper.prepareMbrTriggerDO(primaryId, EEMConstants.TRIG_TYPE_FOLLOWUP_MEMB,
					EEMConstants.TRIG_STATUS_OPEN, EEMConstants.TRIG_CODE_LE21, effDateFrmt);

			mbrTriggerDO.setPlanDesignation(StringUtil.nonNullTrim(eemMbrLepInfoVO.getPlanDesignation()));
			mbrTriggerDO.setPbpId(StringUtil.nonNullTrim(eemMbrLepInfoVO.getPbpId()));
			mbrTriggerDO.setPlanId(StringUtil.nonNullTrim(eemMbrLepInfoVO.getPlanId()));
			mbrTriggerDO.setCreateTime(eemMbrLepInfoVO.getCreateTime());
			mbrTriggerDO.setCreateUserId(eemMbrLepInfoVO.getCreateUserId());
			mbrTriggerDO.setProcessSource(EEMConstants.PROCESS_SOURCE_MBR);


			sqlcnt1 = mbrDAO.insertMbrTrigger(mbrTriggerDO);
		}

		if (sqlcnt1 > 0) {
			flag = true;

		}
		return flag;

	}

	public boolean setApplLepNunCmoTimer(String customerId, String primaryId, EEMLepAttestCallDO eemLepAttestCallDO,
			String type, boolean isMember) throws ApplicationException {
		SecuserDetails userInfo = sessionHelper.getUserInfo();
		String userId = userInfo.getUserId();

		if (EEMConstants.VALUE_YES.equalsIgnoreCase(eemLepAttestCallDO.getIsChange())
				&& !(type.equalsIgnoreCase(EEMConstants.INBOUND_INCOMPLETE)
						|| type.equalsIgnoreCase(EEMConstants.OUTBOUND_INCOMPLETE)
						|| type.equalsIgnoreCase(EEMConstants.INBOUND_LATE))
				&& EEMConstants.INCOMPLETE.equalsIgnoreCase(eemLepAttestCallDO.getStatus())) {

			if (isMember) {

				mbrLepAttestIncTimer(customerId, primaryId, userId, isMember, eemLepAttestCallDO.getCreateTime());
			} else {
				Integer sqlcnt1 = lepDao.invokeTriggerUpdate(customerId, primaryId, userId, isMember);
				if (sqlcnt1 > 0) {
					return true;
				}
			}

		}

		return false;
	}

	public EEMLepAttestCcfVO applLepAttestAdd(EEMLepAttestCcfVO attestVO, boolean isMember)
			throws ApplicationException {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();

		String respType = StringUtil.nonNullTrim(attestVO.getRespType());
		String txtBrkInCoverage = StringUtil.nonNullTrim(attestVO.getBrkInCoverage());

		if (EEMConstants.VALUE_YES.equalsIgnoreCase(txtBrkInCoverage)) {
			attestVO.setCcfUncovMnths(0);
		} else if (EEMConstants.VALUE_NO.equalsIgnoreCase(txtBrkInCoverage) || "P".equalsIgnoreCase(txtBrkInCoverage)) {
			String frmDate = DateFormatter.reFormat(StringUtil.nonNullTrim(attestVO.getFromDate()),
					DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
			String toDate = DateFormatter.reFormat(StringUtil.nonNullTrim(attestVO.getToDate()),
					DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
			int uncovMonths = 0;
			try {
				uncovMonths = DateMath.monthsBetween(frmDate, toDate);
			} catch (ParseException exp) {
				LOG.error(exp.getMessage());

			}
			attestVO.setCcfUncovMnths(uncovMonths + 1);
		}

		String ts = DateUtil.getCurrentDatetimeStamp();
		attestVO.setCreateTime(ts);
		attestVO.setLastUpdtTime(ts);
		attestVO.setCustomerId(customerId);
		attestVO.setCreateUserId(userId);
		attestVO.setOverRideInd(EEMConstants.OVERRIDE_IND_N);

		EEMLepAttestCcfDO targetDO = new EEMLepAttestCcfDO();

		BeanUtils.copyProperties(attestVO, targetDO);
		int sqlCnt1 = lepDao.insertAttnDetailsInCCF(targetDO, isMember);
		attestVO.setBrkInCoverage(CommonUtils.getBreakCovType(txtBrkInCoverage));
		attestVO.setRespType(CommonUtils.getRespType(respType));

		return sqlCnt1 > 0 ? attestVO : null;
	}

	public EEMLepPtnlUncovMthsVO lepUnCovPtnlMnthUpdate(EEMLepPtnlUncovMthsVO unCovVo, boolean isMember)
			throws ApplicationException {
		String userId = sessionHelper.getUserInfo().getUserId();
		String customerId = sessionHelper.getUserInfo().getCustomerId();

		boolean res = false;
		int sqlCnt = 0;
		int ptnUnMnths = 0;

		String uncovMthStDt = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(unCovVo.getUncovMthStDt()));
		String uncovMthEndDt = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(unCovVo.getUncovMthEndDt()));

		try {
			ptnUnMnths = DateMath.monthsBetween(uncovMthStDt, uncovMthEndDt);
		} catch (ParseException e) {
			e.printStackTrace();

		}
		unCovVo.setPlepMonths(ptnUnMnths + 1);

		String ts = DateUtil.getCurrentDatetimeStamp();

		unCovVo.setCreateTime(ts);
		unCovVo.setLastUpdtTime(ts);
		unCovVo.setLastUpdtUserId(userId);
		unCovVo.setCustomerId(customerId);
		unCovVo.setCreateUserId(userId);

		EEMLepPtnlUncovMthsDO tagetDO = new EEMLepPtnlUncovMthsDO();
		BeanUtils.copyProperties(unCovVo, tagetDO);
		// insert ptnl LEP UnCovered months values into EM_APPL_LEP
		sqlCnt = lepDao.insertApplPtnlUnCovMnthsDetails(tagetDO, isMember);
		unCovVo.setOverRideInd(EEMConstants.VALUE_NO);

		if (isMember && sqlCnt > 0) {
			res = true;
		} else if (sqlCnt > 0) {

			createOBC1Timer(unCovVo);

			res = true;
		}

		return res ? unCovVo : null;
	}

	private boolean createOBC1Timer(EEMLepPtnlUncovMthsVO tagetVO) throws ApplicationException {


		String customerId = tagetVO.getCustomerId();
		int val = eemProfileSettings.getParmNumber(customerId, EEMConstants.TRIG_CODE_OBC1);

		Calendar calendar = new GregorianCalendar();
		calendar.set(Calendar.DATE, calendar.get(Calendar.DATE) + val);

		String strMonth = String.valueOf(calendar.get(Calendar.MONTH) + 1);
		if (strMonth.length() == 1)
			strMonth = String.join(EEMConstants.BLANK, "0", strMonth);

		String strDate = String.valueOf(calendar.get(Calendar.DATE));
		if (strDate.length() == 1) {
			strDate = String.join(EEMConstants.BLANK, "0", strDate);
		}

		String triggerEffDate = calendar.get(Calendar.YEAR) + strMonth + strDate;
		System.out.println("EEMApplLepService.createOBC1Timer() >> triggerEffDate<< " + triggerEffDate);

		if (!isDenied(tagetVO)) {
			String openTrigger = lepDao.checkOpenApplTrigger(customerId, tagetVO.getPrimaryId(),
					EEMConstants.TRIG_CODE_OBC1);
			if (openTrigger.isEmpty()) {
				
				String effDateFrmt = DateFormatter.reFormat(triggerEffDate,
						DateFormatter.YYYY_MM_DD, DateFormatter.YYYYMMDD);
				EEMApplTriggerDO triggerDO = applHelper.prepareApplTriggerDO(tagetVO.getPrimaryId(), EEMConstants.TRIG_TYPE_FOLLOWUP_APPL, EEMConstants.TRIG_STATUS_OPEN, 
						EEMConstants.TRIG_CODE_OBC1, effDateFrmt);
				Integer rslt1 = applicationDAO.insertApplTrigger(triggerDO);
				if (rslt1 == 1) {
					tagetVO.setObc1TimerCheck("true");
					return true;
				}

			}

		}
		return false;

	}

	private boolean isDenied(EEMLepPtnlUncovMthsVO targetVO) {
		boolean flag = false;
		String applStatus = StringUtil.nonNullTrim(targetVO.getApplStatus());
		if (applStatus.equals(EEMConstants.APPL_STATUS_DENIEDELG)
				|| applStatus.equals(EEMConstants.APPL_STATUS_DENIEDETYP)
				|| applStatus.equals(EEMConstants.APPL_STATUS_DENIEDOTHR)) {
			flag = true;
		}
		return flag;
	}

	public Map<String, String> lepUnCovPtnlMnthDelete(EEMLepPtnlUncovMthsVO unCovVo, boolean isMember)
			throws ApplicationException {
		int sqlCnt = 0;
		String applId = unCovVo.getPrimaryId();

		HashMap<String, String> map = new HashMap<>();

		String ts = DateUtil.getCurrentDatetimeStamp();
		unCovVo.setLastUpdtTime(ts);

		EEMLepPtnlUncovMthsDO lepPtnlUncovMthsDO = new EEMLepPtnlUncovMthsDO();
		BeanUtils.copyProperties(unCovVo, lepPtnlUncovMthsDO);

		sqlCnt = lepDao.updateApplPtnlUnCovMnthsDetails(lepPtnlUncovMthsDO, isMember);

		if (sqlCnt > 0) {
			// improvement Required
			map = new HashMap<String, String>();
			map.put("msg", "DELETED SUCCESSFULLY");
			map.put("closeAllTimer", "false");
			List<EEMLepPtnlUncovMthsDO> ptnlUnCovMnthsApplLep = lepDao.getPotentialUnCovMonth(unCovVo.getCustomerId(),
					String.valueOf(applId), EEMConstants.VALUE_NO, isMember);

			if (ptnlUnCovMnthsApplLep != null && ptnlUnCovMnthsApplLep.isEmpty()) {
				Integer closeOBCTimer = lepDao.closeOBCTimer(unCovVo.getCustomerId(), applId);
				if (closeOBCTimer > 0) {
					map.put("closeAllTimer", "true");
				}
			}

		}

		return map;
	}

	public byte[] getDisplayDocument(Map<String, String> searchParamMap) throws ApplicationException {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String pdf_archival = StringUtil.nonNullTrim(searchParamMap.get("pdf_archival"));
		String primaryId = StringUtil.nonNullTrim(searchParamMap.get("primaryId"));

		if (EEMConstants.VALUE_YES.equalsIgnoreCase(pdf_archival)) {
			// archivalDBConnection = DbConn.getConnectionForArchivalDB();

			Integer applId = lepDao.getApplId(customerId, primaryId);
			if (applId > 0) {

				// lepDao.displayDocumentFromDB(applId, searchParamMap);

			}

		} else {
			// service.displayDocumentFromDB(null, conn, emCorrMbrVO);
		}

		return null;

	}

	public EEMLepAttestCallMasterVO updateMbrAttestCall(EEMLepAttestCallMasterVO lepMasterVO, boolean isMember)
			throws ApplicationException {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		lepMasterVO.setCustomerId(customerId);
		setApplLepNunCmo(lepMasterVO, isMember);

		return lepMasterVO;

	}

	public EEMApplLepMasterVO mbrLepAttestInfoUpdate(EEMLepAttestInfoVO attestInfoVO, boolean isMember)
			throws ApplicationException {

		attestInfoVO = attestService.applLepAttestInfoUpdate(attestInfoVO, isMember);

		EEMContext eemContext = sessionHelper.getEEMContext();
		eemContext.getMbrMasterVO().getEemLepMasterVO().setLepAttestInfoVO(attestInfoVO);

		sessionHelper.setEEMContext(eemContext);
		return eemContext.getMbrMasterVO().getEemLepMasterVO();
	}

}

