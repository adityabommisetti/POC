package com.medicare.mss.vo;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class EEMApplLepMasterVO implements Serializable {
	
	
	private static final long serialVersionUID = -7526789367423850943L;
	private String primaryId;
	private String customerId;
	private String hicNbr;
	private String mbi;
	private String operatorId;
	private String reqDtCov;
	private String applStatus;
	private String totalPlepMonths;

	// SUMMARY
	private EEMLepSummaryVO  lepSummaryVO;// lepInfos;
	// UNCOVERED DATA
	private List<EEMLepPtnlUncovMthsVO> potentialUnCovMthsList;
	// ATTESTATION SECTION
	private EEMLepAttestInfoVO lepAttestInfoVO;

	// ATTESTATION CALLS
	private EEMLepAttestCallMasterVO attestCallMasterVO;
	
	private EEMLEPMaximusVO eemlepMaximusVO;
	
	private List<EEMMbrLepInfoVO> eemMbrLepInfoVOs;

}
