package com.medicare.mss.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BillingDraftFormVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5464427285268699522L;

	private String customerId;
	private String searchInvoiceNbr;
	private String searchInvoiceId;

	private String searchDraftStatus;

	private String searchInvoiceType;
	private String searchInvoiceGroup;
	private String searchLastName;
	private String searchHicNbr;
	private String searchSupplId;
	private String isHicOrMbi;

}
