package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class EEMLepPtnlUncovMthsDO extends BaseDO {

	@ColumnMapper(columnName = "APPLICATION_ID,MEMBER_ID", propertyName = "primaryId")
	private String primaryId;

	@ColumnMapper(columnName = "LEP_EFF_DATE", propertyName = "lepEffDate")
	private String lepEffDate;

	@ColumnMapper(columnName = "UNCOV_MNTH_STRT_DT", propertyName = "uncovMthStDt")
	private String uncovMthStDt;

	@ColumnMapper(columnName = "UNCOV_MNTH_END_DT", propertyName = "uncovMthEndDt")
	private String uncovMthEndDt;

	@ColumnMapper(columnName = "PLEP_MONTHS", propertyName = "plepMonths")
	private Integer plepMonths;

	@ColumnMapper(columnName = "OVERRIDE_IND", propertyName = "overRideInd")
	private String overRideInd;

	private Integer ptnlepUnCovMnths;

	private String showAllPtnl;

	private Integer totalPlepCount;

}
