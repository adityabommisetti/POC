package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMApplSearchDO {

	@ColumnMapper(columnName = "APPLICATION_ID", propertyName = "applId")
	private int applId;

	@ColumnMapper(columnName = "BIRTH_DATE", propertyName = "birthDt")
	private String birthDt;

	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;

	@ColumnMapper(columnName = "PRODUCT_NAME", propertyName = "enrollProdName")
	private String enrollProdName;

	@ColumnMapper(columnName = "FULL_NAME", propertyName = "fullName")
	private String fullName;

	@ColumnMapper(columnName = "MEDICARE_ID", propertyName = "medicareId")
	private String medicareId;

}
