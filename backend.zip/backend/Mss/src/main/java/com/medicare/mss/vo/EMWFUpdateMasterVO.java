package com.medicare.mss.vo;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EMWFUpdateMasterVO implements Serializable {

	private static final long serialVersionUID = -562237241442264786L;

	private EEMWfSearchVO wfSearchVO;
	private List<EEMWFCaseVO> emWFUpdateCaseVO;
	private String caseComment;
	private String updateCaseStatus;

}
