package com.medicare.mss.vo;

import lombok.Data;

@Data
public class EEMWFUserVO {

	private String supervisorId;
	private String supervisorName;
	private String userId;
	private String userLevel;
	private String userName;

}
