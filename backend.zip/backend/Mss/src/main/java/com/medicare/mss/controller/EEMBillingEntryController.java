package com.medicare.mss.controller;

import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.service.EEMBillingEntryService;
import com.medicare.mss.vo.EEMBilPaymentEntryDtlsVO;
import com.medicare.mss.vo.EEMBilPaymentEntryNewVO;
import com.medicare.mss.vo.EEMBilPaymentEntryMasterVO;
import com.medicare.mss.vo.EEMBilPaymentEntryUpdateVO;
import com.medicare.mss.vo.EEMBilPaymentEntryVO;
import com.medicare.mss.vo.EMWFMasterVO;
import com.medicare.mss.vo.PageableVO;

@RestController
public class EEMBillingEntryController {
	@Autowired
	private EEMBillingEntryService billingEntryService;

	@PostMapping(ReqMappingConstants.BILL_PAYMENTENTRY_SEARCH)
	public ResponseEntity<JSONResponse> billPaymentEntrySearch(@RequestBody EEMBilPaymentEntryVO paymentEntrySearchVo) {
		EEMBilPaymentEntryMasterVO paymentEntrySearchRes = billingEntryService
				.billPaymentEntrySearch(paymentEntrySearchVo);
		return sendResponse(paymentEntrySearchRes);
	}

	@PostMapping(ReqMappingConstants.BILL_PAYMENTENTRY_SEARCH_NEXT)
	public ResponseEntity<JSONResponse> billPaymentEntrySearchNext(
			@RequestBody EEMBilPaymentEntryVO paymentEntrySearchVo) {
		PageableVO pageableResult = billingEntryService.billPaymentEntrySearchNext(paymentEntrySearchVo);
		return sendResponse(pageableResult);
	}

	@PostMapping(ReqMappingConstants.BILL_PAYMENTENTRY_DETAILS)
	public ResponseEntity<JSONResponse> billPaymentEntryDetails(@RequestBody EEMBilPaymentEntryVO bilPaymntsENtryVo) {
		List<EEMBilPaymentEntryDtlsVO> paymnyEntryDtlsRes = billingEntryService
				.billPaymentEntryDetails(bilPaymntsENtryVo);
		return sendResponse(paymnyEntryDtlsRes);
	}

	@PostMapping(ReqMappingConstants.BILL_PAYMENTENTRY_ADD)
	public ResponseEntity<JSONResponse> billPaymentEntryAdd(@RequestBody EEMBilPaymentEntryNewVO paymntEntryNewVo) {
		billingEntryService.billPaymentEntryAdd(paymntEntryNewVo);
		return sendResponse(billingEntryService.billPaymentEntrySearch(paymntEntryNewVo.getSearchVO()));
	}

	@PostMapping(ReqMappingConstants.BILL_PAYMENTENTRY_ADD_DETAILS)
	public ResponseEntity<JSONResponse> billPaymentEntryUpdateDetails(
			@RequestBody EEMBilPaymentEntryNewVO paymntEntryUpdateVo) {
		billingEntryService.billPaymentEntryUpdateDetails(paymntEntryUpdateVo);
		return sendResponse(billingEntryService.billPaymentEntrySearch(paymntEntryUpdateVo.getSearchVO()));
	}

	@PostMapping(ReqMappingConstants.BILL_PAYMENTENTRY_HEADER_UPDATE)
	public ResponseEntity<JSONResponse> billPaymentEntryHeaderUpdate(
			@RequestBody EEMBilPaymentEntryVO bilPaymntsEntryVo) {
		EEMBilPaymentEntryVO paymnyEntryRes = billingEntryService.billPaymentEntryHeaderUpdate(bilPaymntsEntryVo);
		return sendResponse(paymnyEntryRes);
	}

	@PostMapping(ReqMappingConstants.BILL_PAYMENTENTRY_DETAILS_UPDATE)
	public ResponseEntity<JSONResponse> billPaymentEntryDetailsUpdate(
			@RequestBody EEMBilPaymentEntryUpdateVO bilPaymntsEntryUpdateVo) {
		EEMBilPaymentEntryNewVO updateResponse = billingEntryService
				.billPaymentEntryDetailsUpdate(bilPaymntsEntryUpdateVo);
		return sendResponse(updateResponse);
	}

	@GetMapping(ReqMappingConstants.EEM_MEMBER_ID_VALIDATE)
	public ResponseEntity<JSONResponse> memberIdValidate(@RequestParam String memberId) {
		Boolean flag = billingEntryService.memberIdValidate(memberId);
		return sendResponse(flag);
	}

	private ResponseEntity<JSONResponse> sendResponse(Object result) {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;

		if (Objects.isNull(result)) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setData(result);
			jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
			jsonResponse.setMessage(getStatusMessage(result));
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}

	private String getStatusMessage(Object result) {
		String msg = EEMConstants.SUCCESS;
		if (result instanceof EMWFMasterVO && StringUtils.isNotBlank(((EMWFMasterVO) result).getMessage())) {
			msg = ((EMWFMasterVO) result).getMessage();
		}
		return msg;
	}
}
