package com.medicare.mss.dao;

import java.util.List;

import com.medicare.mss.domainobject.EEMMbrCobDO;

public interface EEMMbrCobDAO extends EEMMbrBaseDAO {

	/**
	 * This method retrieves member cob info
	 * 
	 * @param customerId customer id
	 * @param memberId member id
	 * @param showAll showAll flag
	 * @return list of member COB domain object
	 * 
	 **/
	 List<EEMMbrCobDO> getMbrCob(String customerId, String memberId, String showAll);

}
