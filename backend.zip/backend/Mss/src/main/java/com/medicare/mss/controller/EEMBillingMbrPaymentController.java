package com.medicare.mss.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.service.EEMBillingMbrPaymentService;
import com.medicare.mss.vo.BillingMbrPaymentMasterVO;
import com.medicare.mss.vo.BillingMbrPaymentsSearchVO;
import com.medicare.mss.vo.BillingMbrPaymentsVO;
import com.medicare.mss.vo.BillingMbrPymntDtlInvcVO;
import com.medicare.mss.vo.PageableVO;

@RestController
@RequestMapping("/billing")
public class EEMBillingMbrPaymentController {

	@Autowired
	private EEMBillingMbrPaymentService billingMbrPaymentService;

	@PostMapping(ReqMappingConstants.GET_BILLING_MEMBER_PAYMENT_SEARCH)
	public ResponseEntity<JSONResponse> getBillMembPaymentsSearchDetail(
			@RequestBody BillingMbrPaymentsSearchVO billMembPaymentsSearchVO) {

		BillingMbrPaymentMasterVO mbrPaymentMasterVO = billingMbrPaymentService
				.mbrBillingPaymentsSearch(billMembPaymentsSearchVO);
		return sendResponse(mbrPaymentMasterVO);
	}
	
	@PostMapping(ReqMappingConstants.GET_BILLING_MEMBER_PAYMENT_SEARCH_NEXT)
	public ResponseEntity<JSONResponse> getBillMembPaymentsSearchDetailNext(
			@RequestBody BillingMbrPaymentsSearchVO billMembPaymentsSearchVO) {
		
		PageableVO pageableResult = billingMbrPaymentService
				.mbrBillingPaymentsSearchNext(billMembPaymentsSearchVO);
		return sendResponse(pageableResult);
	}

	@PostMapping(ReqMappingConstants.GET_BILLING_MEMBER_PAYMENT_DETAIL_INVOICE)
	public ResponseEntity<JSONResponse> getBillPaymentsInvoiceDetail(@RequestBody BillingMbrPaymentsVO mbrPaymentsVO) {

		List<BillingMbrPymntDtlInvcVO> billingMbrPymntDtlInvcVOList = billingMbrPaymentService
				.getBillPaymentsDetailInvoice(mbrPaymentsVO);
		return sendResponse(billingMbrPymntDtlInvcVOList);
	}

	@PostMapping(ReqMappingConstants.UPDATE_BILLING_MEMBER_PAYMENT)
	public ResponseEntity<JSONResponse> updateBillMbrPayment(@RequestBody BillingMbrPaymentsVO mbrPaymentsVO) {

		BillingMbrPaymentsVO updateBillingMbrPaymentVO = billingMbrPaymentService.updateBillMbrPayment(mbrPaymentsVO);
		return sendResponse(updateBillingMbrPaymentVO);
	}

	private ResponseEntity<JSONResponse> sendResponse(Object object) {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;
		jsonResponse.setData(object);
		if (null == object) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
			jsonResponse.setMessage(EEMConstants.BLANK);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}
}
