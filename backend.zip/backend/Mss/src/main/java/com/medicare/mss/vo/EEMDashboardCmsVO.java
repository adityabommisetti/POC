package com.medicare.mss.vo;

import lombok.Data;

@Data
public class EEMDashboardCmsVO {

	private String memberId;
	private String medicareId;
	private String supplementalId;
	private String transactionType;
	private String triggerCode;
	private String enrollReasonCode;
	private String firstName;
	private String lastName;
	private String prodName;
	private String type;

}
