package com.medicare.mss.dao;

import java.util.List;

import com.medicare.mss.domainobject.EMMbrPCPInfoDO;
import com.medicare.mss.domainobject.EMPcpSearchDO;
import com.medicare.mss.domainobject.EmMbrErrorDO;

public interface EEMMbrPCPDAO extends EEMMbrBaseDAO {
	
	List<EMMbrPCPInfoDO> getMbrPCPSelect(String customerId, String memberId, String showAll, String lineOfBusiness);

	int setPcpInfoOverride(EMMbrPCPInfoDO delPCPDO, String userId) ;

	void getMedOffice(String customerId, String pcpNbr, String effStartDate, String lineOfBusiness, String lobValid, String pcpLineOfBusiness) ;

	boolean checkProviderDates(EMMbrPCPInfoDO pcpDO) ;

	String getCurrentPatientIndicator(EMMbrPCPInfoDO pcpDO) ;

	boolean checkProvider(EMMbrPCPInfoDO pcpDO) ;

	List<EmMbrErrorDO> getMemberErrors(String customerId, String memberId, String fieldNbr) ;

	int updateErrorDetails(EmMbrErrorDO objTempDO, String requestScrn) ;

	int insertErrorDetails(EmMbrErrorDO objErrorDO) ;

	int insertMbrPcpInfo(EMMbrPCPInfoDO newEMMbrPCPInfoDO) ;

	List<EMMbrPCPInfoDO> searchPcp(EMPcpSearchDO eMPcpSearchDO, String lineOfBusiness) ;
}
