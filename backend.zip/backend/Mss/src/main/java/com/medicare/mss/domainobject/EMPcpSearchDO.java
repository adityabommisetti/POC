package com.medicare.mss.domainobject;

import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
public class EMPcpSearchDO{
	
	private String customerId;
	private String effDate;
	private String pcpNbr;
	private String locationId;
	private String doctorName;
	private String acceptNewPatient;
	private String address;
	private String city;
	private String state;
	private String zip;
	/*Access health PCP CR- Start*/
	private String pcpNpi;
	//private String lineOfBusiness;
	
	public void setEffDate(String effDate) {
		this.effDate=DateFormatter.reFormat(effDate,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
	}	
}
