package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EMWFCaseQueueDO {

	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;
	
	@ColumnMapper(columnName = "QUEUE_CD", propertyName = "queueCd")
	private String queueCd;
	
	@ColumnMapper(columnName = "CREATE_TIME", propertyName = "createTime")
	private String createTime;
	
	@ColumnMapper(columnName = "QUEUE_NAME", propertyName = "queueName")
	private String queueName;
	
	@ColumnMapper(columnName = "QUEUE_PURPOSE", propertyName = "queuePurpose")
	private String queuePurpose;
	
	@ColumnMapper(columnName = "QUEUE_DESC", propertyName = "queueDesc")
	private String queueDesc;
	
	@ColumnMapper(columnName = "COMP_DAYS", propertyName = "compDays")
	private String compDays;
	
	@ColumnMapper(columnName = "QUEUE_PRTY", propertyName = "queuePrty")
	private String queuePrty;
	
	@ColumnMapper(columnName = "AT_RISK_DAYS", propertyName = "atRiskDays")
	private String atRiskDays;
	
	@ColumnMapper(columnName = "OVERIDE_IND", propertyName = "overideInd")
	private String overideInd;
	
	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserID")
	private String lastUpdtUserID;
	
	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;
	
}
