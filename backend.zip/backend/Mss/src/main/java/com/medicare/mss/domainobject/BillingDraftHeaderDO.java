package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class BillingDraftHeaderDO {

	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;

	@ColumnMapper(columnName = "MEMBER_ID", propertyName = "invoiceId")
	private String invoiceId;

	@ColumnMapper(columnName = "LAST_FIRST_NAME", propertyName = "lastName")
	private String lastName;

	@ColumnMapper(columnName = "INVOICE_NBR", propertyName = "invoiceNbr")
	private String invoiceNbr;

	@ColumnMapper(columnName = "INVOICE_DUE_DATE", propertyName = "dueDate")
	private String dueDate;

	@ColumnMapper(columnName = "SETTLEMENT_DATE", propertyName = "settlementDate")
	private String settlementDate;

	@ColumnMapper(columnName = "RESPONSE_CODE", propertyName = "responseCode")
	private String responseCode;

	@ColumnMapper(columnName = "DRAFT_PROCESSED_IND", propertyName = "invoiceStatus")
	private String invoiceStatus;

	@ColumnMapper(columnName = "DRAFT_AMT", propertyName = "invoiceAmt")
	private String invoiceAmt;

	@ColumnMapper(columnName = "CREATE_TIME", propertyName = "createTime")
	private String createTime;

	@ColumnMapper(columnName = "CREATE_USERID", propertyName = "createUserId")
	private String createUserId;

	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;

	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserId")
	private String lastUpdtUserId;

}
