package com.medicare.mss.util;

import java.io.IOException;
import java.io.InputStream;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Date;
import java.util.function.Function;

import org.springframework.core.io.ClassPathResource;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.exception.ApplicationException;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;

@Service
public class JwtUtils {

	private static PublicKey publicKey;
	
	static {
		try {
			publicKey = publicKeyReader();
		} catch (NoSuchAlgorithmException | InvalidKeySpecException | IOException e) {
			throw new ApplicationException(EEMConstants.SOMETHING_WENT_WRONG);
		}
	}

	private Claims extaractClaims(String token) {
		return Jwts.parser().setSigningKey(publicKey).parseClaimsJws(token).getBody();
	}

	private <T> T extaractClaim(String token, Function<Claims, T> claimResolver) {
		Claims claims = extaractClaims(token);
		return claimResolver.apply(claims);
	}

	private boolean isTokenExpire(String token) {
		return extaractExpireTime(token).before(new Date());
	}

	public Date extaractExpireTime(String token) {
		return extaractClaim(token, Claims::getExpiration);
	}

	public String extaractUserName(String token) {
		return extaractClaim(token, Claims::getSubject);
	}
	
	public Date extaractIssuedAt(String token) {
		return extaractClaim(token, Claims::getIssuedAt);
	}

	public boolean validateToken(String token, UserDetails user) {
		String extaractUserName = extaractUserName(token);
		return (extaractUserName.equals(user.getUsername()) && !isTokenExpire(token));
	}

	private static PublicKey publicKeyReader() throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {
		InputStream inputStream = new ClassPathResource("public_key.der").getInputStream();
		byte[] keyBytes = FileCopyUtils.copyToByteArray(inputStream);
		X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
		KeyFactory kf = KeyFactory.getInstance("RSA");
		return kf.generatePublic(spec);
	}

}