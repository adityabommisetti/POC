package com.medicare.mss.vo;

import java.io.Serializable;
import java.util.Objects;

import javax.servlet.ServletOutputStream;

import org.apache.commons.lang3.StringUtils;

import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
public class EmMbrLepAttestInfoVO implements EMDatedSegmentVO, Cloneable, Serializable {

	private static final long serialVersionUID = 8642270939408186325L;

	private String customerId;
	private String memberId;
	private String effStartDate;
	private String effEndDate;
	private String overrideInd;
	private String creditableCoverageFlag;
	private int nbrUncovMonths;
	private String lepAmt;
	private String lepWaivedAmt;
	private String createTime;
	private String createUserId;
	private String lastUpdtTime;
	private String lastUpdtUserId;
	private String statusCd;
	private String incStatusCd;
	private String dmsID;
	private String attestLetMailDate;
	private String attestLetExpDate;
	private String attestStatus;
	private String incompAttestLetRecDate;
	private String incompAttestLetExpDate;
	private String incompAttestStatus;
	private String brkInCoverage;
	private String credRXCoverage;
	private String fromDate;
	private String toDate;
	private String txtComptRespRecDate;
	private String txtBrkInCoverage;
	private String txtCredRXCoverage;
	private String txtFromDate;
	private String txtToDate;
	private int ccfUncovMnths;
	private String respType;
	private String ccfOverRideInd;
	private String ccfCreateTime;
	private String ccfCreateUserId;
	private String ccfLastUpdtTime;
	private String ccfLastUpdtUserId;
	private String attestLock;
	private String numUncocTransReason;
	private String questionNum;
	private String questionValidInd;
	private String letterUploadedTime;
	private String letterAvailabilityInDB;
	private ServletOutputStream servletOutputStream;
	private String source;
	private String letterName;
	private String decisionType;
	private String caseFileRecDate;
	private String caseFileDueDate;
	private String decisionRecDate;
	private String transactionDueDate;
	private String comptRespRecDate;
	private String attestationRecDate;
	private String attestationRecChannel;
	private String notifiedMemberAppeal;
	private String otherCreateTime;
	private String otherFrmtCreateTime;
	private String otherCreateUserId;
	private String otherLastUpdtTime;
	private String otherFrmtLastUpdtTime;
	private String otherLastUpdtUserId;
	private boolean enableAttestAfter90DaysSection;
	private String uncovStDate;
	private String letPotUnCov;
	private String is73TxnExists;

	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	public String getType() {
		return "LEP";
	}

	/**
	 * @return Returns the createTime.
	 */
	public String getCreateTime() {
		return createTime;
	}

	/**
	 * @param createTime The createTime to set.
	 */
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	/**
	 * @return Returns the createUserId.
	 */
	public String getCreateUserId() {
		return createUserId;
	}

	/**
	 * @param createUserId The createUserId to set.
	 */
	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	/**
	 * @return Returns the customerId.
	 */
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId The customerId to set.
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return Returns the effEndDate.
	 */
	public String getEffEndDate() {
		return effEndDate;
	}

	public String getEffEndDateFrmt() {
		return DateFormatter.reFormat(effEndDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	/**
	 * @param effEndDate The effEndDate to set.
	 */
	public void setEffEndDate(String effEndDate) {
		this.effEndDate = effEndDate;
	}

	public void setEffEndDateFrmt(String effEndDate) {
		this.effEndDate = DateFormatter.reFormat(effEndDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	/**
	 * @return Returns the effStartDate.
	 */
	public String getEffStartDate() {
		return effStartDate;
	}

	public String getEffStartDateFrmt() {
		return DateFormatter.reFormat(effStartDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	/**
	 * @param effStartDate The effStartDate to set.
	 */
	public void setEffStartDate(String effStartDate) {
		this.effStartDate = effStartDate;
	}

	public void setEffStartDateFrmt(String effStartDate) {
		this.effStartDate = DateFormatter.reFormat(effStartDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	/**
	 * @return Returns the lastUpdtTime.
	 */
	public String getLastUpdtTime() {
		return lastUpdtTime;
	}

	/**
	 * @param lastUpdtTime The lastUpdtTime to set.
	 */
	public void setLastUpdtTime(String lastUpdtTime) {
		this.lastUpdtTime = lastUpdtTime;
	}

	/**
	 * @return Returns the lastUpdtUserId.
	 */
	public String getLastUpdtUserId() {
		return lastUpdtUserId;
	}

	/**
	 * @param lastUpdtUserId The lastUpdtUserId to set.
	 */
	public void setLastUpdtUserId(String lastUpdtUserId) {
		this.lastUpdtUserId = lastUpdtUserId;
	}

	/**
	 * @return Returns the memberId.
	 */
	public String getMemberId() {
		return memberId;
	}

	/**
	 * @param memberId The memberId to set.
	 */
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	/**
	 * @return Returns the overrideInd.
	 */
	public String getOverrideInd() {
		return overrideInd;
	}

	/**
	 * @param overrideInd The overrideInd to set.
	 */
	public void setOverrideInd(String overrideInd) {
		this.overrideInd = overrideInd;
	}

	public boolean isEndDateChange(Object obj) {

		EmMbrLepAttestInfoVO chkVO = (EmMbrLepAttestInfoVO) obj;
		return Objects.nonNull(obj) && StringUtils.equals(chkVO.getEffStartDate(), this.effStartDate)
				&& StringUtils.equals(chkVO.getCreditableCoverageFlag(), this.creditableCoverageFlag)
				&& chkVO.getNbrUncovMonths() == this.nbrUncovMonths
				&& StringUtils.equals(chkVO.getLepAmt(), this.lepAmt)
				&& StringUtils.equals(chkVO.getLepWaivedAmt(), this.lepWaivedAmt)
				&& StringUtils.equals(chkVO.getMemberId(), this.memberId)
				&& StringUtils.equals(chkVO.getCustomerId(), this.customerId)
				&& StringUtils.equals(chkVO.getOverrideInd(), this.overrideInd);
	}

	public boolean isForSamePeriod(Object obj) {

		EmMbrLepAttestInfoVO chkVO = (EmMbrLepAttestInfoVO) obj;
		return Objects.nonNull(obj) && StringUtils.equals(chkVO.getEffStartDate(), this.effStartDate)
				&& StringUtils.equals(chkVO.getEffEndDate(), this.effEndDate)
				&& StringUtils.equals(chkVO.getMemberId(), this.memberId)
				&& StringUtils.equals(chkVO.getCustomerId(), this.customerId)
				&& StringUtils.equals(chkVO.getOverrideInd(), this.overrideInd);
	}

	public boolean isSame(Object obj) {

		EmMbrLepAttestInfoVO chkVO = (EmMbrLepAttestInfoVO) obj;
		return Objects.nonNull(obj) && StringUtils.equals(chkVO.getEffStartDate(), this.effStartDate)
				&& StringUtils.equals(chkVO.getEffEndDate(), this.effEndDate)
				&& StringUtils.equals(chkVO.getCreditableCoverageFlag(), this.creditableCoverageFlag)
				&& chkVO.getNbrUncovMonths() == this.nbrUncovMonths
				&& StringUtils.equals(chkVO.getLepAmt(), this.lepAmt)
				&& StringUtils.equals(chkVO.getLepWaivedAmt(), this.lepWaivedAmt)
				&& StringUtils.equals(chkVO.getMemberId(), this.memberId)
				&& StringUtils.equals(chkVO.getCustomerId(), this.customerId)
				&& StringUtils.equals(chkVO.getOverrideInd(), this.overrideInd)
				&& StringUtils.equals(chkVO.getCreateTime(), this.createTime)
				&& StringUtils.equals(chkVO.getCreateUserId(), this.createUserId)
				&& StringUtils.equals(chkVO.getLastUpdtTime(), this.lastUpdtTime)
				&& StringUtils.equals(chkVO.getLastUpdtUserId(), this.lastUpdtUserId);
	}

}
