package com.medicare.mss.domainobject;


import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMMbrCorrDmsDO {
		
		@ColumnMapper(columnName = "LETTER_CREATION_TIME", propertyName = "letterCreationTime")
		private String letterCreationTime; 
		
		@ColumnMapper(columnName = "SOURCE", propertyName = "source")
		private String source;
}
