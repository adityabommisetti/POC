/**
 * 
 */
package com.medicare.mss.domainobject;
import lombok.Data;

/**
 * @author SUSDASH
 *
 */
@Data
public class EEMApplProdSearchDO {
	private String ssaSt; 
	private String ssaCnty;
	private String zip4; 
	private String zip5; 
	private String enrollProdName;
	private String enrollGroupName;
	private String applType;
	private String outOfArea;
	private String customerId;


}
