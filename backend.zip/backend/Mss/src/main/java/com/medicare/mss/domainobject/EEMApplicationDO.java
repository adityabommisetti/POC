package com.medicare.mss.domainobject;

import com.medicare.mss.util.CommonUtils;

import lombok.Data;

@Data 
public class EEMApplicationDO  {


	private String achAbaRoutingNbr;
	private String achAccountType;
	private String achbankAcctNbr;
	private String achBankName;
	private String achBillFrequency;
	private String achDraftDay;
	private String achNameOnAct;
	private String altMbrId;
	private String altCorrespondenceInd;
	private String appDuplicateCheck;
	private String applCategory;
	private String applDate;
	private int applId;
	private String applStatus;
	private String applType;
	private String authRepFirstName;
	private String authRepLastName;
	private String authRepMidName;
	private String authRepRelation;
	private String billFirstName;
	private String billLastName;
	private String billMiddleName;
	private String billSuffix;
	private String compaignId;
	private String cancelReason;
	private String contractorNo;
	private String createTime;
	private String createUserId;
	private String currStatus;
	private String customerId;
	private String denialRcvDt;
	private String denialReasonCd;
	private String displayHic;
	private String editOverride;
	private String emergEmail;
	private String emergName;
	private String emergPhone;
	private String emergRelation;
	private String enrollSrceCd;
	private String healthPlanNews;
	private String insCardName;
	private String isHicOrMbi;
	private String language;
	private String lstUpdtTime;
	private String lstUpdtUserId;
	private String ltrReasonCd;
	private String mailFirstName;
	private String mailLastName;
	private String mailMiddleName;
	private String mailSuffix;
	private String mbi;
	private String mbrApplNo;
	private String mbrEmail;
	private String mbrHicNbr;
	private String mbrId;
	private String mbrSuffix;
	private String mbrBirthDt;
	private String mbrFirstName;
	private String mbrGender;
	private String mbrLastName;
	private String mbrMiddleName;
	private String mbrPrefix; 
	private String mbrRxId;
	private String mbrSsn;
	private String origApplDate;
	private String outOfArea;
	private String pwOption;
	private String receiptDate;
	private String signDt;
	private String signOnFile;
	private String signOvrrdDt;
	private String subscriberId;
	private String xrefNbr;
		
	public String getMbrSsn() {
		return CommonUtils.deFormatSsn(this.mbrSsn);
    }
}
