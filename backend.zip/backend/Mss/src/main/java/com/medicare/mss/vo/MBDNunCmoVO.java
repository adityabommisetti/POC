package com.medicare.mss.vo;

import java.io.Serializable;

import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
public class MBDNunCmoVO  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6967812782686052663L;
	private String nunCmoStartDate;
	private String nunCmoNbrUnCovMths;
	private String nunCmoIndicator;
	private String totNbrUnCovMths;
	private String profileLastUpdt;

	public String getNunCmoStartDateFrmt() {
		return DateFormatter.reFormat(nunCmoStartDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setNunCmoStartDateFrmt(String nunCmoStartDate) {
		this.nunCmoStartDate = DateFormatter.reFormat(nunCmoStartDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
	}

}
