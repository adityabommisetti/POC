package com.medicare.mss.rowmappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.domainobject.EEMApplFieldErrorDO;
import com.medicare.mss.util.StringUtil;

public class ApplFieldErrorRowMapper implements RowMapper<EEMApplFieldErrorDO> {

	public ApplFieldErrorRowMapper() { }

	@Override
	public EEMApplFieldErrorDO mapRow(ResultSet row, int rowNum) throws SQLException {
		
		EEMApplFieldErrorDO eemApplFieldErrorDO = new EEMApplFieldErrorDO();

		eemApplFieldErrorDO.setErrorCd(StringUtil.nonNullTrim(row.getString("ERROR_CD")));
		eemApplFieldErrorDO.setErrorMessage(StringUtil.nonNullTrim(row.getString("ERROR_MESSAGE")));
		eemApplFieldErrorDO.setErrorType(StringUtil.nonNullTrim(row.getString("ERROR_TYPE")));
		eemApplFieldErrorDO.setFormField(StringUtil.nonNullTrim(row.getString("FORM_FIELD")));
		eemApplFieldErrorDO.setRequiredInd(StringUtil.nonNullTrim(row.getString("REQUIRED_IND")));
		eemApplFieldErrorDO.setEditValidVal(StringUtil.nonNullTrim(row.getString("EDIT_VALID_VALUE")));
		eemApplFieldErrorDO.setEditRuleId(StringUtil.nonNullTrim(row.getString("EDIT_RULE_ID")));
		eemApplFieldErrorDO.setFieldNbr(StringUtil.nonNullTrim(row.getString("FIELD_NBR")));
		eemApplFieldErrorDO.setExceptionVal(StringUtil.nonNullTrim(row.getString("EXCEPTION_VALUE")));
		eemApplFieldErrorDO.setCustomerId(StringUtil.nonNullTrim(row.getString("CUSTOMER_ID")));
		eemApplFieldErrorDO.setEditFrom(StringUtil.nonNullTrim(row.getString("EDIT_FROM_VALID_VALUE")));
		eemApplFieldErrorDO.setEditTo(StringUtil.nonNullTrim(row.getString("EDIT_TO_VALID_VALUE")));
		eemApplFieldErrorDO.setFormFieldClass(this.setFieldForm(StringUtil.nonNullTrim(row.getString("TABLE_NAME"))));

		return eemApplFieldErrorDO;
	}

	private String setFieldForm(String formFieldClass) {
		if (EEMConstants.EEM_APPL_TABLE.equalsIgnoreCase(formFieldClass))
			return EEMConstants.EEM_APPLICATION_VO;
		else if (EEMConstants.EEM_APPL_PLAN_TABLE.equalsIgnoreCase(formFieldClass))
			return EEMConstants.EEM_APPL_PLAN_VO;
		else if (EEMConstants.EEM_APPL_ADDRESS_TABLE.equalsIgnoreCase(formFieldClass))
			return EEMConstants.EEM_APPL_ADDRESS_VO;
		else if (EEMConstants.EEM_APPL_AGENT_TABLE.equalsIgnoreCase(formFieldClass))
			return EEMConstants.EEM_APPL_AGENT_VO;
		else if (EEMConstants.EEM_APPL_OTH_COV_TABLE.equalsIgnoreCase(formFieldClass))
			return EEMConstants.EEM_APPL_OTHER_COV_VO;
		else if (EEMConstants.EEM_APPL_OTH_PLAN_TABLE.equalsIgnoreCase(formFieldClass))
			return EEMConstants.EEM_APPL_OTHER_PLAN_VO;
		else if (EEMConstants.EEM_DEMOGRAPHIC_TABLE.equalsIgnoreCase(formFieldClass))
			return EEMConstants.EEM_MBR_DEMO_VO;
		else
			return "";
	}

}
