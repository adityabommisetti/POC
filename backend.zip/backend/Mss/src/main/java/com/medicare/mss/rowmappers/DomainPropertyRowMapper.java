package com.medicare.mss.rowmappers;

import java.lang.reflect.Field;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.PropertyAccessorFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.JdbcUtils;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.annotation.ColumnMapper;

public class DomainPropertyRowMapper<T> implements RowMapper<T> {

	private static final String UNDERSCORE = "_";
	private Class<T> mappedClass;

	public DomainPropertyRowMapper(Class<T> mappedClass) {
		this.mappedClass = mappedClass;
	}

	private static Map<String, String> getPojoPropertyName(Class<?> pojoClass) {
		Map<String, String> mapperObject = new HashMap<>();
		Class<?> superclass = pojoClass.getSuperclass();

		for (Field field : pojoClass.getDeclaredFields()) {

			Class<?> type = field.getType();
			ColumnMapper mapper = field.getAnnotation(ColumnMapper.class);

			if (Objects.nonNull(mapper)) {

				if (StringUtils.equalsIgnoreCase(type.toString(), Datatype.INTEGER.getValue())) {
					mapperObject.put(mapper.columnName(), String.join(UNDERSCORE, "isInteger", mapper.propertyName()));
				} else if (mapper.columnName().contains(",")) {
					String[] split = mapper.columnName().split(",");
					for (String columnName : split) {
						mapperObject.put(columnName, mapper.propertyName());
					}

				} else {
					mapperObject.put(mapper.columnName(), mapper.propertyName());
				}
			}
		}

		if (null != superclass) {
			for (Field field : superclass.getDeclaredFields()) {

				Class<?> type = field.getType();
				ColumnMapper mapper = field.getAnnotation(ColumnMapper.class);

				if (Objects.nonNull(mapper)) {

					if (StringUtils.equalsIgnoreCase(type.toString(), Datatype.INTEGER.getValue())) {
						mapperObject.put(mapper.columnName(),
								String.join(UNDERSCORE, "isInteger", mapper.propertyName()));
					} else {
						mapperObject.put(mapper.columnName(), mapper.propertyName());
					}
				}
			}
		}
		return mapperObject;
	}

	@SuppressWarnings("deprecation")
	@Override
	public T mapRow(ResultSet rs, int rowNum) throws SQLException {

		List<String> unMappedColumns = new ArrayList<>();
		T mappedObject = BeanUtils.instantiate(this.mappedClass);
		BeanWrapper bw = PropertyAccessorFactory.forBeanPropertyAccess(mappedObject);

		Map<String, String> pojoPropertyName = getPojoPropertyName(this.mappedClass);

		ResultSetMetaData rsMetadata = rs.getMetaData();
		int columnCount = rsMetadata.getColumnCount();

		for (int index = 1; index <= columnCount; index++) {

			String columnName = JdbcUtils.lookupColumnName(rsMetadata, index);
			String propertyName = pojoPropertyName.get(columnName);

			if (Objects.isNull(propertyName)) {
				unMappedColumns.add(columnName);
			} else {
				if (StringUtils.startsWith(propertyName, "isInteger")) {
					Integer intValue = rs.getInt(columnName);
					propertyName = StringUtils.split(propertyName, UNDERSCORE)[1];
					bw.setPropertyValue(propertyName, intValue);
				} else {
					String value = StringUtils.trimToEmpty(rs.getString(columnName));
					bw.setPropertyValue(propertyName, value);
				}
			}
		}
		
		if(!CollectionUtils.isEmpty(unMappedColumns)) {
			throw new SQLException(String.format("Un-mapped column(s) found! : %s", unMappedColumns));
		}
		
		return mappedObject;
	}

	enum Datatype {

		INTEGER("java.lang.Integer"), DATE("java.sql.Date"), FLOAT("java.lang.Float"), DOUBLE("java.lang.Double");
		private String value;

		// getter method
		public String getValue() {
			return this.value;
		}

		private Datatype(String value) {
			this.value = value;
		}
	}

}
