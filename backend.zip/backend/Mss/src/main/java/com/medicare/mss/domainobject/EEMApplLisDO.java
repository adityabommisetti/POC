package com.medicare.mss.domainobject;

import lombok.Data;

@Data
public class EEMApplLisDO {

	private String effEndDt;
	private String effStartDt;
	private String liCoPayCd;
	private String lisPctCd;

}
