package com.medicare.mss.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BillingDraftHeaderVO implements Serializable {

	private static final long serialVersionUID = -5829550842720291217L;

	private String customerId;
	private String invoiceNbr;
	private String invoiceId;
	private String lastName;
	private String dueDate;
	private String invoiceStatus;
	private String invoiceAmt;
	private String createTime;
	private String createUserId;
	private String lastUpdtTime;
	private String lastUpdtUserId;
	private String responseCode;
	private String settlementDate;

	public String getDueDateFrmt() {
		return DateFormatter.reFormat(dueDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getCreateDateFrmt() {
		return DateFormatter.reFormat(createTime, DateFormatter.DB2_TIMESTAMP, DateFormatter.MM_DD_YYYY);
	}

	public String getSettlementDateFrmt() {
		return DateFormatter.reFormat(settlementDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

}
