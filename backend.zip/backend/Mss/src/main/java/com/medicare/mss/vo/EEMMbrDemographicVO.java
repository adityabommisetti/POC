package com.medicare.mss.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.DemographicFormatter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode(callSuper = false)
public class EEMMbrDemographicVO extends BaseVO implements Serializable {

	private static final long serialVersionUID = -7253607728395090927L;
	private String altCorrespondenceInd;
	private String authFirstName;
	private String authLastName;
	private String authMiddleInit;
	private String authRelationshipCd;
	private String birthDate;
	private String cmsEffMonth;
	private String currentInd;
	private String deathDate;
	private int demoSeqNbr;
	private String emergcyEmail;
	private String emergcyName;
	private String emergcyPhone;
	private String emergcyRelationshipCd;
	private String fileId;
	private String firstName;
	private String genderCd;
	private String hicNbr;
	private String insCardName;
	private String languageCd;
	private String lastName;
	private String mailFirstName;
	private String mailLastName;
	private String mailMiddleInit;
	private String mailSuffix;
	private String maritalStatus;
	private String mbrEmail;
	private String memberId;
	private String memberStatus;
	private String middleInitial;
	private String overrideInd;
	private String prefix;
	private String raceCd;
	private String rolloverTime;
	private String rolloverUserId;
	private String spouseWorkInd;
	private String ssn;
	private String suffix;

	public String getBirthDateFrmt() {
		return DateFormatter.reFormat(birthDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getCmsEffMonthFrmt() {
		return DateFormatter.reFormat(cmsEffMonth, DateFormatter.YYYYMM, DateFormatter.MM_YYYY);
	}

	public String getDeathDateFrmt() {
		return DateFormatter.reFormat(deathDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getSsnFrmt() {
		return DemographicFormatter.formatSSN(ssn);
	}

	public void setBirthDateFrmt(String birthDate) {
		this.birthDate = DateFormatter.reFormat(birthDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public void setCmsEffMonthFrmt(String cmsEffMonth) {
		this.cmsEffMonth = DateFormatter.reFormat(cmsEffMonth, DateFormatter.MM_YYYY, DateFormatter.YYYYMM);
	}

	public void setDeathDateFrmt(String deathDate) {
		this.deathDate = DateFormatter.reFormat(deathDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public void setSsnFrmt(String ssn) {
		this.ssn = DemographicFormatter.unFormatSSN(ssn);
	}

}