package com.medicare.mss.vo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EEMWFSupervisorUserVO {

	private String name;
	private String inactiveEndDate;
	private String inactiveStartDate;
	private String prtyMethod;
	private List<String> prtyOneList;
	private List<String> prtyTwoList;
	private List<String> prtyThreeList;
	private List<String> prtyFourList;
	private String unAssignedFlag;
	private String userId;
	private String userStatus;
	private String searchUserId;
	private String searchSupAdminId;

	public String getInactiveEndDateFrmt() {
		return DateFormatter.reFormat(inactiveEndDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getInactiveStartDateFrmt() {
		return DateFormatter.reFormat(inactiveStartDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setInactiveEndDateFrmt(String inactiveEndDate) {
		this.inactiveEndDate = DateFormatter.reFormat(inactiveEndDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
	}

	public void setInactiveStartDateFrmt(String inactiveStartDate) {
		this.inactiveStartDate = DateFormatter.reFormat(inactiveStartDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
	}

}
