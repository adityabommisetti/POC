package com.medicare.mss.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BillingMbrPaymentsSearchVO implements Serializable {

	private static final long serialVersionUID = 2566122958643641839L;

	private String customerId;
	private String searchPaySource;
	private String searchInvoiceId;
	private String searchCheckNbr;
	private String searchLastName;
	private String searchHicNbr;
	private String searchSupplId;
	private String isHicOrMbi;
	private String invoiceDueDate;
	private String batchDate;
	private String batchSeqNbr;
	private String itemNbr;
}
