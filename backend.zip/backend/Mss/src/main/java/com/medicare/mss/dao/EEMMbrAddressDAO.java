package com.medicare.mss.dao;

import java.util.List;

import com.medicare.mss.domainobject.EEMMbrAddressDO;

public interface EEMMbrAddressDAO extends EEMMbrBaseDAO {

	List<EEMMbrAddressDO> getMbrAddresses(String customerId, String memberId, String showAll);

}
