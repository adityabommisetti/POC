package com.medicare.mss.vo;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class EEMMbrMasterVO implements Serializable {

	private static final long serialVersionUID = 4365066830435646420L;

	private boolean nextPage;
	private String ccmDate;
	private String cpmDate;
	private String npiInd;
	private String suppLepPlatino;
	private EEMMbrSnapshotVO mbrSnapshot;
	private EEMApplLepMasterVO eemLepMasterVO;
	private List<EEMMbrAccretionVO> mbrAccretionList;
	private List<EEMMbrAddressVO> mbrAddressList;
	private List<EmMbrAgentVO> mbrAgentInfoList;
	private List<EEMMbrBillingVO> mbrBillingList;
	private List<EEMMbrCobVO> mbrCobVOList;
	private List<EEMMbrCommentVO> mbrCommentList;
	private EEMMbrDemographicVO mbrDemographicVO;
	private List<EEMMbrDsInfoVO> mbrDsInfoList;
	private List<EEMMbrEnrollmentVO> mbrEnrollmentList;
	private List<EmMbrErrorVO> mbrErrorList;
	private List<EEMMbrLepInfoVO> mbrLepInfoList;
	private List<EmCorrMbrVO> mbrLetterList;
	private List<EEMMbrLisInfoVO> mbrLisInfoList;
	private List<EEMMbrLtcInfoVO> mbrLtcInfoList;
	private List<EEMMbrOoaInfoVO> mbrOoaInfoList;
	private List<EMMbrPCPInfoVO> mbrPcpInfoList;
	private List<EmMbrPosInfoVO> mbrPosInfoList;
	private List<EEMMbrSearchVO> mbrSearchList;
	private List<EEMMbrTrrLogVO> mbrTrrList;
	private List<EEMMbrAsesVO> mbrAsesList;

}