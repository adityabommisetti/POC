package com.medicare.mss.util;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.Objects;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.filter.OncePerRequestFilter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.ApiResponse;
import com.medicare.mss.helper.CacheService;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.SignatureException;

@Service
public class JwtFilter extends OncePerRequestFilter {
	
	private static final Logger LOG = LoggerFactory.getLogger(JwtFilter.class);

	@Autowired
	private CacheService cacheService;

	@Autowired
	private JwtUtils jwtUtils;

	@Autowired
	private RestTemplate restTemplate;

	@Value("${msslogin.logout.endpoint}")
	private String logoutEndpoint;

	@Value("${jwt.renew.token.endpoint}")
	private String renewTokenEndpoint;

	@Value("${jwt.token.renew.timediff}")
	private int tokenRenewDiff;

	@Value("${jwt.renewed.token.buffer}")
	private long renewedTokenBuffer;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		boolean concReq = false;
		String jwtToken = null;
		String userId = null;
		final String authTokenHeader = request.getHeader(EEMConstants.AUTH_TOKEN);

		if (Objects.nonNull(authTokenHeader) && authTokenHeader.startsWith("Bearer ")) {
			jwtToken = authTokenHeader.substring(7);
			try {
				userId = jwtUtils.extaractUserName(jwtToken);
			} catch (ExpiredJwtException exp) {
				logger.error("Token Expired", exp);
				int statusCode = getSessionStatus(authTokenHeader);
				if (statusCode == 403) {
					sendError(response, EEMConstants.SESSION_EXPIRED);
				} else {
					sendError(response, "UnExpected Response");
				}
				return;
			} catch (SignatureException exp) {
				sendError(response, "UnAuthorized");
				return;
			}
		}

		if (Objects.nonNull(userId) && !Objects.nonNull(SecurityContextHolder.getContext().getAuthentication())) {

			String dbToken = (String) cacheService.getUserCache(userId, EEMConstants.TOKEN, String.class);

			UserDetails userDetails = cacheService.getAuthentication(userId, EEMConstants.AUTH_CACHE);

			if (jwtUtils.validateToken(jwtToken, userDetails)) {

				if (!StringUtils.trimToEmpty(dbToken).equalsIgnoreCase(jwtToken)) {
					concReq = verifyConcurrentReq(dbToken, userId); 
					if(!concReq) {
						sendError(response, EEMConstants.MAX_SESSION_EXPIRED);
						return;	
					}
				}

				if (!StringUtils.contains(request.getRequestURI(), "/notifications") && !concReq) {
					renewTokenIfRequired(response, jwtToken, userId);
				}

				UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
						userDetails, null, userDetails.getAuthorities());
				authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
				SecurityContextHolder.getContext().setAuthentication(authentication);
			}
		}
		filterChain.doFilter(request, response);
	}

	private boolean verifyConcurrentReq(String token, String userId) {
		Date issuedAt = jwtUtils.extaractIssuedAt(token);
		Date currDate = new Date();
		
		Instant issuedTime = issuedAt.toInstant();
		Instant currentTime = currDate.toInstant();
		long timeDiff = Duration.between(issuedTime, currentTime).toMillis();
		
		LOG.info("userId: {}, configured renewedTokenBuffer: {}", userId, renewedTokenBuffer);
		LOG.info("userId: {}, issuedAt: {}", userId, new SimpleDateFormat("MM-dd-yyyy HH:mm:ss.SSSSSS").format(issuedAt));
		LOG.info("userId: {}, currTime: {}", userId, new SimpleDateFormat("MM-dd-yyyy HH:mm:ss.SSSSSS").format(currDate));
		LOG.info("userId: {}, timeDiff: {}", userId, timeDiff);
		
		return timeDiff <= renewedTokenBuffer;
	}

	// Call MssLogin Api and get the new token
	private void renewTokenIfRequired(HttpServletResponse response, String jwtToken, String userId) {
		Date expireTime = jwtUtils.extaractExpireTime(jwtToken);
		Date currentTime = new Date(System.currentTimeMillis());

		int diff = DateUtil.getMinuteDiff(expireTime, currentTime);
		if (diff < tokenRenewDiff) {
			logger.info("Renew Token RestTemplate call started");
			String newToken = invokeRestApi(jwtToken);
			logger.info("Renew Token RestTemplate call Ended");
			cacheService.setUserCache(userId, EEMConstants.TOKEN, newToken);
			response.setHeader(EEMConstants.AUTH_TOKEN, newToken);
		}
	}

	// Call MssLogin Api and clear cache
	private int getSessionStatus(String authTokenHeader) {
		HttpHeaders headers = new HttpHeaders();
		headers.add(EEMConstants.AUTH_TOKEN, authTokenHeader);
		HttpEntity<String> entity = new HttpEntity<>(headers);
		int statusCode;
		logger.info("Logout RestTemplate call started");
		try {
			statusCode = restTemplate.exchange(logoutEndpoint, HttpMethod.GET, entity, String.class)
					.getStatusCodeValue();
		} catch (HttpClientErrorException httpException) {
			statusCode = httpException.getRawStatusCode();
		} catch (Exception exception) {
			logger.error("Error in getSessionStatus:", exception);
			throw new ApplicationException("Failed to connect with MssLogin logout");
		}
		logger.info("Logout RestTemplate call ended");
		return statusCode;
	}

	private String invokeRestApi(String jwtToken) {
		HttpHeaders headers = new HttpHeaders();

		if (Objects.nonNull(jwtToken)) {
			headers.add(EEMConstants.AUTH_TOKEN, CommonUtils.appendStrings("Bearer ", jwtToken));
		}
		try {
			HttpEntity<String> entity = new HttpEntity<>(EEMConstants.BLANK, headers);
			return restTemplate.postForObject(renewTokenEndpoint, entity, String.class);
		} catch (Exception exception) {
			logger.error("Error in invokeRestApi:", exception);
			throw new ApplicationException("Failed to connect with MssLogin renew token");
		}
	}

	private void sendError(HttpServletResponse response, String msg) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		ApiResponse respo = new ApiResponse(403, msg);

		response.setStatus(403);
		PrintWriter writer = response.getWriter();
		writer.write(mapper.writeValueAsString(respo));
	}

}
