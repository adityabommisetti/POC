package com.medicare.mss.vo;

import java.util.List;

import com.medicare.mss.domainobject.EEMAttestationDO;
import com.medicare.mss.util.LabelValuePair;

import lombok.Data;

@Data
public class ApplCacheVO {

	private String electionDesc;

	private List<LabelValuePair> lstAccountType;
	private List<LabelValuePair> lstBillFrequency;
	private List<LabelValuePair> lstBillPayMethod;
	private List<LabelValuePair> applDenialReasons;
	private List<LabelValuePair> lstGender;
	private List<LabelValuePair> lepNunCmoStstus;
	private List<LabelValuePair> lstAgentTypes;
	private List<LabelValuePair> lstAgencyTypes;
	private List<LabelValuePair> lstAltCorrespondences;
	private List<LabelValuePair> lstApplCategory;
	private List<LabelValuePair> lstApplStatus;
	private List<LabelValuePair> lstApplType;
	private List<LabelValuePair> lstCountry;
	private List<LabelValuePair> lstCounty;
	private List<LabelValuePair> lstElectionTypes;
	private List<LabelValuePair> lstEnrollSrce;
	private List<LabelValuePair> lstLanguages;
	private List<LabelValuePair> lstPCO;
	private List<LabelValuePair> lstPrefix;
	private List<LabelValuePair> lstPWOptions;
	private List<LabelValuePair> lstRelations;
	private List<EEMAttestationDO> lstSepExceptions;
	private List<LabelValuePair> lstSepReasons;
	private List<LabelValuePair> lstStates;
	private List<LabelValuePair> lstUsrApplStatus;
	private List<LabelValuePair> oevCallStatusDrop;
	private List<LabelValuePair> oevCallSubReasonDrop;
	private List<LabelValuePair> preSetNoteList;
	private List<LabelValuePair> reasonList;
	private List<LabelValuePair> validLiCopays;
	private List<LabelValuePair> validLiPercents;
	private List<LabelValuePair> validStatus;
	private List<LabelValuePair> recvdChannel;
	private List<LabelValuePair> arrYesNo;

}
