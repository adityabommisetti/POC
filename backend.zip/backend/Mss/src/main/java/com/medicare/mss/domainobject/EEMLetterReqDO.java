package com.medicare.mss.domainobject;

import java.util.List;

import com.medicare.mss.annotation.ColumnMapper;
import com.medicare.mss.util.LabelValuePair;

import lombok.Data;

@Data
public class EEMLetterReqDO {

	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;

	@ColumnMapper(columnName = "SOURCE_TYPE", propertyName = "sourceType")
	private String sourceType;

	@ColumnMapper(columnName = "PRIMARY_ID", propertyName = "primaryId")
	private String primaryId;

	@ColumnMapper(columnName = "EFFECTIVE_DATE", propertyName = "effDate")
	private String effDate;

	@ColumnMapper(columnName = "CREATE_TIME", propertyName = "createTime")
	private String createTime;

	@ColumnMapper(columnName = "TRIGGER_TYPE", propertyName = "triggerType")
	private String triggerType;

	@ColumnMapper(columnName = "TRIGGER_CODE", propertyName = "triggerCode")
	private String triggerCode;

	@ColumnMapper(columnName = "TRIGGER_STATUS", propertyName = "triggerStatus")
	private String triggerStatus;

	@ColumnMapper(columnName = "FIRST_NAME", propertyName = "mbrFName")
	private String mbrFName;

	@ColumnMapper(columnName = "LAST_NAME", propertyName = "mbrLName")
	private String mbrLName;

	@ColumnMapper(columnName = "CREATE_USERID", propertyName = "createUserId")
	private String createUserId;

	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;

	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserId")
	private String lastUpdtUserId;

	@ColumnMapper(columnName = "CORR_LETTER_NAME", propertyName = "letterName")
	private String letterName;

	@ColumnMapper(columnName = "CORR_SHORT_DESC", propertyName = "letterNameDesc")
	private String letterNameDesc;

	@ColumnMapper(columnName = "PLAN_ID", propertyName = "planId")
	private String planId;

	@ColumnMapper(columnName = "PBP_ID", propertyName = "pbpId")
	private String pbpId;

	@ColumnMapper(columnName = "PLAN_DESIGNATION", propertyName = "planDesignation")
	private String planDesignation;

	private String sourceTypeDesc;
	private String triggerTypeDesc;
	private String triggerStatusDesc;
	private String triggerCodeDesc;

	private String[] varDataId;
	private String[] varDataType;
	private String[] varDataLen;
	private String[] varDataDesc;
	private String[] varDataText;

	private List<EEMLetterVarDataDO> lstVarData;
	private List<LabelValuePair> lstLetterName;

}
