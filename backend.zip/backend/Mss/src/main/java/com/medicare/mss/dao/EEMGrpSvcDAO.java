package com.medicare.mss.dao;

import java.util.List;

import com.medicare.mss.domainobject.EEMApplProductDO;
import com.medicare.mss.domainobject.EEMGroupProductSearchDO;
import com.medicare.mss.domainobject.EEMGrpProductDO;
import com.medicare.mss.domainobject.EEMStateCountyZipDO;

public interface EEMGrpSvcDAO {
	void getStateCountyByZip(EEMStateCountyZipDO sczVO);

	EEMGrpProductDO getGroupProduct(String customerId, String groupId, String productId, String effDate);

	List<EEMApplProductDO> searchGrpPrd(EEMGroupProductSearchDO gpSearch);

	String getPlanType(String custNbr, String planId, String pbpId);

}
