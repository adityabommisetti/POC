package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMBilPaymentEntryDtlsDO {

	@ColumnMapper(columnName = "PAY_SOURCE_TYPE", propertyName = "paySource")
	private String paySource;

	@ColumnMapper(columnName = "BATCH_DATE", propertyName = "batchDate")
	private String batchDate;

	@ColumnMapper(columnName = "BATCH_SEQ_NBR", propertyName = "batchSeqNbr")
	private String batchSeqNbr;

	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;

	@ColumnMapper(columnName = "ITEM_NBR", propertyName = "itemNbr")
	private String itemNbr;

	@ColumnMapper(columnName = "INVOICE_ID", propertyName = "memberId")
	private String memberId;

	@ColumnMapper(columnName = "INVOICE_DUE_DATE", propertyName = "invoiceDueDate")
	private String invoiceDueDate;

	@ColumnMapper(columnName = "CHECK_DATE", propertyName = "checkDate")
	private String checkDate;

	@ColumnMapper(columnName = "CHECK_NBR", propertyName = "checkNbr")
	private String checkNbr;

	@ColumnMapper(columnName = "PAYMENT_AMT", propertyName = "paymentAmt")
	private String paymentAmt;

	@ColumnMapper(columnName = "PAYMENT_POSTED_IND", propertyName = "paymentPostedInd")
	private String paymentPostedInd;

	@ColumnMapper(columnName = "CREATE_TIME", propertyName = "createTime")
	private String createTime;

	@ColumnMapper(columnName = "CREATE_USERID", propertyName = "createUserId")
	private String createUserId;

	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;

	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserId")
	private String lastUpdtUserId;
}
