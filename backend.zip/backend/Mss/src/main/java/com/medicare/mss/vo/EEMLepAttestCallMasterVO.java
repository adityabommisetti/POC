package com.medicare.mss.vo;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.domainobject.EEMLepAttestCallDO;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EEMLepAttestCallMasterVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2442118043576614426L;
	private String customerId;
	private String primaryId;
	private String obc1TimerCheck;
	private String obc2TimerCheck;
	private String le21TimerCheck;
	private String obc3TimerCheck;
	private List<EEMLepAttestCallDO> outBoundInitial;
	private List<EEMLepAttestCallDO> inBoundInitial;
	private List<EEMLepAttestCallDO> outBoundInComplete;
	private List<EEMLepAttestCallDO> inBoundInComplete;
	private List<EEMLepAttestCallDO> inBoundLate;
}
