package com.medicare.mss.domainobject;

import java.io.Serializable;

import lombok.Data;

@Data
public class EEMLetterVarDataDO implements Serializable {

	private static final long serialVersionUID = -8689402066653828141L;

	private int seqNbr;
	private String varId;
	private String description;
	private String fieldType;
	private String fieldLength;
	private String fieldValue;

}
