/**
 * 
 */
package com.medicare.mss.daoImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMMbrDsInfoDAO;
import com.medicare.mss.domainobject.EEMMbrDsInfoDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.vo.EEMMbrDsInfoVO;
import com.medicare.mss.vo.EMDatedSegmentVO;

/**
 * @author Wipro Ltd.
 *
 */
@Repository
public class EEMMbrDsInfoDAOImpl implements EEMMbrDsInfoDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;


	@Override
	public List<EEMMbrDsInfoDO> getMbrDsInfos(String custId, String mbrId, String showAll) {

		String sqlOverride = " AND OVERRIDE_IND = 'N'";
		if (EEMConstants.VALUE_YES.equals(showAll))
			sqlOverride = EEMConstants.BLANK;

		String query = CommonUtils.buildQuery("SELECT CUSTOMER_ID, MEMBER_ID, DS_CD, EFF_START_DATE, CREATE_TIME,",
				"EFF_END_DATE, OVERRIDE_IND, DS_VALUE,", "CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID",
				"FROM EM_MBR_DSINFO", "WHERE CUSTOMER_ID = ? AND MEMBER_ID = ?", sqlOverride,
				"ORDER BY DS_CD, EFF_START_DATE DESC, EFF_END_DATE DESC");

		try {
			return jdbcTemplate.query(query, new DomainPropertyRowMapper<EEMMbrDsInfoDO>(EEMMbrDsInfoDO.class), custId, mbrId);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public int setOverride(EMDatedSegmentVO emDatedSegmentVO, String userId) {
		String query = CommonUtils.buildQuery("UPDATE EM_MBR_DSINFO",
				"SET OVERRIDE_IND = 'Y', LAST_UPDT_TIME = CURRENT_TIMESTAMP, LAST_UPDT_USERID = ?",
				"WHERE CUSTOMER_ID = ? AND MEMBER_ID = ?", "AND DS_CD = ? AND EFF_START_DATE = ? AND CREATE_TIME = ?",
				"AND OVERRIDE_IND = 'N' AND LAST_UPDT_TIME = ?");

		EEMMbrDsInfoVO mbrDsInfo = (EEMMbrDsInfoVO) emDatedSegmentVO;
		try {
			return jdbcTemplate.update(query, userId, mbrDsInfo.getCustomerId(), mbrDsInfo.getMemberId(),
					mbrDsInfo.getDsCd(), mbrDsInfo.getEffStartDate(), mbrDsInfo.getCreateTime(),
					mbrDsInfo.getLastUpdtTime());
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}
	}

	@Override
	public int insertMbr(EMDatedSegmentVO emDatedSegmentVO) {
		String query = CommonUtils.buildQuery("INSERT INTO EM_MBR_DSINFO(",
				"CUSTOMER_ID, MEMBER_ID, DS_CD, EFF_START_DATE, CREATE_TIME,", "EFF_END_DATE, OVERRIDE_IND, DS_VALUE,",
				"CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID)", " VALUES(?,?,?,?,?,?,?,?,?,?,?)");

		EEMMbrDsInfoVO mbrDsInfo = (EEMMbrDsInfoVO) emDatedSegmentVO;
		try {
			return jdbcTemplate.update(query, mbrDsInfo.getCustomerId(), mbrDsInfo.getMemberId(), mbrDsInfo.getDsCd(),
					mbrDsInfo.getEffStartDate(), mbrDsInfo.getCreateTime(), mbrDsInfo.getEffEndDate(),
					mbrDsInfo.getOverrideInd(), mbrDsInfo.getDsValue(), mbrDsInfo.getCreateUserId(),
					mbrDsInfo.getLastUpdtTime(), mbrDsInfo.getLastUpdtUserId());
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_INSERT);
		}
	}

}
