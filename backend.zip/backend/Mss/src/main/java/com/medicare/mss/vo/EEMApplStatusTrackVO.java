package com.medicare.mss.vo;

import lombok.Data;

@Data
public class EEMApplStatusTrackVO {

	private String logTime;
	private String lastUpdtUserId;
	private String applStatus;
	
}
