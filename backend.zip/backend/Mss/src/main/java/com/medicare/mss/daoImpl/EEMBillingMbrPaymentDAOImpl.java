package com.medicare.mss.daoImpl;

import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMBillingMbrPaymentDAO;
import com.medicare.mss.domainobject.BillingMbrPaymentHeaderDO;
import com.medicare.mss.domainobject.BillingMbrPaymentsDO;
import com.medicare.mss.domainobject.BillingMbrPymntDtlInvcDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.PaginationQueryHelper;
import com.medicare.mss.vo.BillingMbrPaymentHeaderVO;
import com.medicare.mss.vo.BillingMbrPaymentsSearchVO;
import com.medicare.mss.vo.BillingMbrPaymentsVO;
import com.medicare.mss.vo.DataBaseField;
import com.medicare.mss.vo.PageableVO;

@Repository
public class EEMBillingMbrPaymentDAOImpl implements EEMBillingMbrPaymentDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public PageableVO getBillMbrPaymentsSearchDetail(BillingMbrPaymentsSearchVO billMembPaymentsSearchVO, boolean isPagination) {
		List<BillingMbrPaymentsDO> billPaymentsDOList = new ArrayList<>();
		PageableVO response = new PageableVO();
		
		String customerId = trimToEmpty(billMembPaymentsSearchVO.getCustomerId());
		String paySource = trimToEmpty(billMembPaymentsSearchVO.getSearchPaySource());
		String memberId = trimToEmpty(billMembPaymentsSearchVO.getSearchInvoiceId());
		String checkNbr = trimToEmpty(billMembPaymentsSearchVO.getSearchCheckNbr());
		String lastName = trimToEmpty(billMembPaymentsSearchVO.getSearchLastName());
		String hicNbr = trimToEmpty(billMembPaymentsSearchVO.getSearchHicNbr());
		String searchSupplementId = trimToEmpty(billMembPaymentsSearchVO.getSearchSupplId());

		String medIdString = "";

		String queryMedID = CommonUtils.buildQuery("IFNULL((SELECT DS_VALUE ",
				"FROM EM_MBR_DSINFO WHERE DS_CD = 'MBI' AND ",
				"OVERRIDE_IND = 'N' AND EFF_END_DATE = '99999999' AND MEMBER_ID = INVOICE_ID ",
				"AND CUSTOMER_ID =  B.CUSTOMER_ID  FETCH FIRST ROWS ONLY),",
				"(SELECT DS_VALUE FROM EM_MBR_DSINFO WHERE DS_CD = 'MED' AND ",
				"OVERRIDE_IND = 'N' AND EFF_END_DATE = '99999999' AND MEMBER_ID = INVOICE_ID ",
				"AND CUSTOMER_ID =  B.CUSTOMER_ID FETCH FIRST ROWS ONLY ) ) AS DS_VALUE");

		if (StringUtils.isNotBlank(billMembPaymentsSearchVO.getIsHicOrMbi())) {
			if (billMembPaymentsSearchVO.getIsHicOrMbi().equalsIgnoreCase("hic")) {
				medIdString = "MED";

			} else {
				medIdString = "MBI";
			}
		}

		List<String> params = new ArrayList<>();

		StringBuilder sQuery = CommonUtils.buildQueryBuilder("SELECT distinct B.CUSTOMER_ID, B.PAY_SOURCE_TYPE,",
				"B.BATCH_DATE, B.BATCH_SEQ_NBR, ITEM_NBR, INVOICE_ID, INVOICE_DUE_DATE, CHECK_DATE, CHECK_NBR,",
				"PAYMENT_AMT,PAYMENT_POSTED_IND, BANK_ACCT_CD, FIRST_NAME, LAST_NAME,",
				"B.CREATE_TIME, B.CREATE_USERID, B.LAST_UPDT_TIME, B.LAST_UPDT_USERID, ", queryMedID,
				" FROM BBB_PAYMENT_DETAIL B JOIN BBB_PAYMENT_HEADER A ON A.CUSTOMER_ID = B.CUSTOMER_ID",
				"  AND A.PAY_SOURCE_TYPE = B.PAY_SOURCE_TYPE AND A.BATCH_DATE = B.BATCH_DATE",
				"  AND A.BATCH_SEQ_NBR = B.BATCH_SEQ_NBR JOIN EM_MBR_DEMOGRAPHIC C",
				"   ON C.CUSTOMER_ID = B.CUSTOMER_ID AND C.MEMBER_ID = B.INVOICE_ID WHERE B.CUSTOMER_ID = ?",
				"   AND C.CURRENT_IND = 'Y' AND C.OVERRIDE_IND = 'N'");
		params.add(customerId);

		if (!lastName.isEmpty()) {
			sQuery.append(" AND LAST_NAME = ?");
			params.add(lastName);
		}

		if (!hicNbr.isEmpty()) {
			sQuery.append(" AND INVOICE_ID IN (SELECT DSI.MEMBER_ID FROM EM_MBR_DSINFO DSI")
					.append(" WHERE DSI.CUSTOMER_ID = B.CUSTOMER_ID").append(" AND DSI.OVERRIDE_IND = 'N'")
					.append(" AND DSI.DS_CD = ?").append(" AND DSI.DS_VALUE = ?)");
			params.add(medIdString);
			params.add(hicNbr);
		}

		if (!memberId.isEmpty()  && !isPagination) {
			sQuery.append(" AND INVOICE_ID = ?");
			params.add(memberId);
		}
		if (!paySource.isEmpty()  && !isPagination) {
			sQuery.append(" AND B.PAY_SOURCE_TYPE = ?");
			params.add(paySource);
		}
		if (!checkNbr.isEmpty()) {
			sQuery.append(" AND CHECK_NBR = ?");
			params.add(checkNbr);
		}

		if (!searchSupplementId.isEmpty()) {
			sQuery.append(" AND C.MEMBER_ID IN (SELECT E.MEMBER_ID FROM EM_MBR_ENROLLMENT E")
					.append(" WHERE E.CUSTOMER_ID = C.CUSTOMER_ID AND E.OVERRIDE_IND = 'N'")
					.append(" AND E.SUPPLEMENTAL_ID = ?)");
			params.add(searchSupplementId);
		}

		try {
			
			if (isPagination) {
				
				DataBaseField[] conds = new DataBaseField[6];
				for (int i = 0; i < conds.length; i++) {
					conds[i] = new DataBaseField();
				}
				
				conds[0].setFieldName("INVOICE_DUE_DATE");
				conds[0].setSign(" < ");
				conds[0].setStringValue(billMembPaymentsSearchVO.getInvoiceDueDate());
				
				conds[1].setFieldName("INVOICE_ID");
				conds[1].setStringValue(billMembPaymentsSearchVO.getSearchInvoiceId());
				
				conds[2].setFieldName("B.PAY_SOURCE_TYPE");
				conds[2].setStringValue(billMembPaymentsSearchVO.getSearchPaySource());
				
				conds[3].setFieldName("B.BATCH_DATE");
				conds[3].setStringValue(billMembPaymentsSearchVO.getBatchDate());
				
				conds[4].setFieldName("B.BATCH_SEQ_NBR");
				conds[4].setStringValue(billMembPaymentsSearchVO.getBatchSeqNbr());

				conds[5].setFieldName("ITEM_NBR");
				conds[5].setStringValue(billMembPaymentsSearchVO.getItemNbr());

				StringBuilder pageCond = PaginationQueryHelper.pagingElements(conds, params);
				sQuery.append(pageCond);
			}
			
			sQuery.append(
					" ORDER BY B.CUSTOMER_ID, INVOICE_DUE_DATE DESC, INVOICE_ID, B.PAY_SOURCE_TYPE, B.BATCH_DATE, B.BATCH_SEQ_NBR, ITEM_NBR ");
			sQuery.append(" FETCH FIRST ").append(EEMConstants.DB_MAX_RECORD_FETCH).append(" ROWS ONLY");
			
			billPaymentsDOList = jdbcTemplate.query(sQuery.toString(),
					new DomainPropertyRowMapper<BillingMbrPaymentsDO>(BillingMbrPaymentsDO.class),
					params.toArray());
			
			if (!CollectionUtils.isEmpty(billPaymentsDOList)) {
				if (billPaymentsDOList.size() > 100) {
					billPaymentsDOList.remove(billPaymentsDOList.size() - 1);
					response.setNextPage(true);
				}
			}
			
			response.setContent(billPaymentsDOList);
			return response;

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public List<BillingMbrPymntDtlInvcDO> getBillPaymentsDetailInvoice(BillingMbrPaymentsVO eemBillingMbrPaymentsVO) {

		String customerId = trimToEmpty(eemBillingMbrPaymentsVO.getCustomerId());
		String paySource = trimToEmpty(eemBillingMbrPaymentsVO.getPaySourceType());
		String batchDate = trimToEmpty(eemBillingMbrPaymentsVO.getBatchDate());
		int batchSeqNbr = eemBillingMbrPaymentsVO.getBatchSeqNbr();
		int itemNbr = eemBillingMbrPaymentsVO.getItemNbr();

		StringBuilder sQuery = CommonUtils.buildQueryBuilder(
				"SELECT BPDI.CUSTOMER_ID, BPDI.PAY_SOURCE_TYPE, BPDI.BATCH_DATE, BPDI.BATCH_SEQ_NBR,",
				"  BPDI.ITEM_NBR, BPDI.INVOICE_NBR,BPDI.APPLIED_AMT,BPDI.CREATE_TIME, BPDI.CREATE_USERID,",
				"  BPDI.LAST_UPDT_TIME, BPDI.LAST_UPDT_USERID,BIH.INVOICE_TYPE, BIH.DUE_DATE",
				" FROM BBB_PAYMENT_DTL_INVOICE BPDI JOIN BBB_INVOICE_HEADER BIH ON BPDI.INVOICE_NBR = BIH.INVOICE_NBR",
				" WHERE BIH.CUSTOMER_ID = ? AND BPDI.CUSTOMER_ID = ? AND BPDI.PAY_SOURCE_TYPE = ? AND BPDI.BATCH_DATE = ? ",
				" AND BPDI.BATCH_SEQ_NBR = ? AND BPDI.ITEM_NBR = ? ORDER BY BPDI.CREATE_TIME DESC ");

		Object[] parms = new Object[] { customerId, customerId, paySource, batchDate, batchSeqNbr, itemNbr };

		try {
			return jdbcTemplate.query(sQuery.toString(),
					new DomainPropertyRowMapper<BillingMbrPymntDtlInvcDO>(BillingMbrPymntDtlInvcDO.class), parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}

	}

	@Override
	public BillingMbrPaymentHeaderDO getBillPaymentHeader(String customerId, String paySourceType, String batchDate,
			int batchSeqNbr) {

		StringBuilder sQuery = CommonUtils.buildQueryBuilder(
				"SELECT CUSTOMER_ID, PAY_SOURCE_TYPE, BATCH_DATE, BATCH_SEQ_NBR,",
				" BANK_ACCT_CD, BATCH_BALANCE_AMT, DETAIL_TOTAL_AMT,",
				" BATCH_BALANCE_IND, BATCH_POSTED_IND, BATCH_DETAIL_CNT,",
				" CREATE_TIME, CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID"
						+ " FROM BBB_PAYMENT_HEADER  WHERE CUSTOMER_ID = ? AND PAY_SOURCE_TYPE = ?",
				" AND BATCH_DATE = ?  AND BATCH_SEQ_NBR = ? FETCH FIRST ROWS ONLY");

		Object[] parms = new Object[] { customerId, paySourceType, batchDate, batchSeqNbr };
		try {
			return jdbcTemplate.queryForObject(sQuery.toString(), parms,
					new DomainPropertyRowMapper<BillingMbrPaymentHeaderDO>(BillingMbrPaymentHeaderDO.class));
		} catch (EmptyResultDataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public int updateBillPaymentDetails(BillingMbrPaymentsVO mbrPaymentsVO, String ts, String userId) {

		Object[] parms = new Object[] { trimToEmpty(mbrPaymentsVO.getInvoiceId()),
				trimToEmpty(mbrPaymentsVO.getInvoiceDueDate()), trimToEmpty(mbrPaymentsVO.getCheckDate()),
				mbrPaymentsVO.getPaymentAmt(), ts, userId, trimToEmpty(mbrPaymentsVO.getCheckNbr()),
				trimToEmpty(mbrPaymentsVO.getCustomerId()), trimToEmpty(mbrPaymentsVO.getPaySourceType()),
				trimToEmpty(mbrPaymentsVO.getBatchDate()), mbrPaymentsVO.getBatchSeqNbr(), mbrPaymentsVO.getItemNbr(),
				trimToEmpty(mbrPaymentsVO.getLastUpdtTime()) };
		try {
			StringBuilder sQuery = CommonUtils.buildQueryBuilder(
					"UPDATE BBB_PAYMENT_DETAIL SET INVOICE_ID=?, INVOICE_DUE_DATE=?, CHECK_DATE=?,",
					" PAYMENT_AMT=?, LAST_UPDT_TIME=?, LAST_UPDT_USERID=?, CHECK_NBR=? ",
					" WHERE CUSTOMER_ID=? AND PAY_SOURCE_TYPE=? AND BATCH_DATE=? AND BATCH_SEQ_NBR=? ",
					"AND ITEM_NBR=? AND LAST_UPDT_TIME=?");

			return jdbcTemplate.update(sQuery.toString(), parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}
	}

	@Override
	public Map<String, String> getPaymentDetail(BillingMbrPaymentHeaderVO payHdrDtl) {

		Object[] parms = new Object[] { trimToEmpty(payHdrDtl.getCustomerId()),
				trimToEmpty(payHdrDtl.getPaySourceType()), trimToEmpty(payHdrDtl.getBatchDate()),
				payHdrDtl.getBatchSeqNbr() };

		StringBuilder sQuery = CommonUtils.buildQueryBuilder(
				"SELECT SUM(PAYMENT_AMT) AS TOTAL_PAYMENT_AMT, COUNT(ITEM_NBR) AS ITEM_NBR_COUNT FROM BBB_PAYMENT_DETAIL",
				"  WHERE CUSTOMER_ID=? AND PAY_SOURCE_TYPE=? AND BATCH_DATE=? AND BATCH_SEQ_NBR=?");

		try {
			return jdbcTemplate.query(sQuery.toString(), (ResultSet res) -> {
				Map<String, String> object = new HashMap<>();
				while (res.next()) {

					object.put("TOTAL_PAYMENT_AMT", trimToEmpty(res.getString("TOTAL_PAYMENT_AMT")));
					object.put("ITEM_NBR_COUNT", trimToEmpty(res.getString("ITEM_NBR_COUNT")));
				}
				return object;
			}, parms);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}

	}

	@Override
	public int updateHeaderTotalAmount(String userId, String ts, String totalPaymentAmount, String itemNbrCount,
			String batchBalanceInd, BillingMbrPaymentHeaderVO payHdrDtl) {
		
		Object[] parms = new Object[] { totalPaymentAmount, batchBalanceInd, itemNbrCount,
						ts, userId, trimToEmpty(payHdrDtl.getCustomerId()),trimToEmpty(payHdrDtl.getPaySourceType()),
						trimToEmpty(payHdrDtl.getBatchDate()),payHdrDtl.getBatchSeqNbr(),
						trimToEmpty(payHdrDtl.getLastUpdtTime())};
		try {
			StringBuilder sQuery = CommonUtils.buildQueryBuilder(
					"UPDATE BBB_PAYMENT_HEADER SET DETAIL_TOTAL_AMT=?, BATCH_BALANCE_IND=?, BATCH_DETAIL_CNT=?, ", 
					"LAST_UPDT_TIME=?, LAST_UPDT_USERID=? WHERE CUSTOMER_ID=? AND PAY_SOURCE_TYPE=? ",
					"AND BATCH_DATE=? AND BATCH_SEQ_NBR=? AND LAST_UPDT_TIME=?");

			return jdbcTemplate.update(sQuery.toString(), parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}
	}
	
}
