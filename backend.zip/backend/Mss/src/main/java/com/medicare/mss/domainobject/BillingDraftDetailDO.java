package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class BillingDraftDetailDO {

	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;

	@ColumnMapper(columnName = "INVOICE_NBR", propertyName = "invoiceNbr")
	private String invoiceNbr;

	@ColumnMapper(columnName = "MEMBER_ID", propertyName = "memberId")
	private String memberId;

	@ColumnMapper(columnName = "ABA_ROUTING_NBR", propertyName = "routingNumber")
	private String routingNumber;

	@ColumnMapper(columnName = "LAST_FIRST_NAME", propertyName = "lastName")
	private String lastName;

	@ColumnMapper(columnName = "TRACE_NUM", propertyName = "traceNumber")
	private String traceNumber;

	@ColumnMapper(columnName = "SETTLEMENT_DATE", propertyName = "settlementDate")
	private String settlementDate;

	@ColumnMapper(columnName = "BANK_ACCT_NBR", propertyName = "accountNumber")
	private String accountNumber;

	@ColumnMapper(columnName = "SENT_TIME", propertyName = "sendDate")
	private String sendDate;

	@ColumnMapper(columnName = "ACCOUNTTYPE_DESC", propertyName = "accountType")
	private String accountType;

	private String responseDate;

	@ColumnMapper(columnName = "DRAFT_AMT", propertyName = "draftAmount")
	private String draftAmount;

	@ColumnMapper(columnName = "DRAFTPROCESSED_DESC", propertyName = "draftStatus")
	private String draftStatus;

	@ColumnMapper(columnName = "INVOICE_DUE_DATE", propertyName = "dueDate")
	private String dueDate;

	@ColumnMapper(columnName = "RESPONSE_CODE", propertyName = "responseCode")
	private String responseCode;

	@ColumnMapper(columnName = "RESPONSE_DESC", propertyName = "responseMessage")
	private String responseMessage;

	@ColumnMapper(columnName = "BANK_NAME", propertyName = "bankName")
	private String bankName;

	@ColumnMapper(columnName = "CREATE_TIME", propertyName = "createTime")
	private String createTime;

	@ColumnMapper(columnName = "CREATE_USERID", propertyName = "createUserId")
	private String createUserId;

	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;

	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserId")
	private String lastUpdtUserId;

	@ColumnMapper(columnName = "DRAFT_DAY", propertyName = "draftDay")
	private String draftDay;

	@ColumnMapper(columnName = "RESPONSE_TIME", propertyName = "responseTime")
	private String responseTime;

}
