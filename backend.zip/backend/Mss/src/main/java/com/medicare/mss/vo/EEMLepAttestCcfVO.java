package com.medicare.mss.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode(callSuper = false)
public class EEMLepAttestCcfVO extends BaseVO {

	private static final long serialVersionUID = 8075370536106809052L;
	private String primaryId;
	private String comptRespRecDate;
	private String brkInCoverage;
	private String credRXCoverage;
	private String fromDate;
	private String toDate;
	private Integer ccfUncovMnths;
	private String respType;
	private String overRideInd;

	public String getComptRespRecDateFrmt() {
		return DateFormatter.reFormat(comptRespRecDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setComptRespRecDateFrmt(String comptRespRecDate) {
		this.comptRespRecDate = DateFormatter.reFormat(comptRespRecDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
	}

	public String getFromDateFrmt() {
		return DateFormatter.reFormat(fromDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setFromDateFrmt(String fromDate) {
		this.fromDate = DateFormatter.reFormat(fromDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getToDateFrmt() {
		return DateFormatter.reFormat(toDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setToDateFrmt(String toDate) {
		this.toDate = DateFormatter.reFormat(toDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

}
