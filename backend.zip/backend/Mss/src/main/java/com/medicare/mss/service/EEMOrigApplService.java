package com.medicare.mss.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.caching.EEMPersistence;
import com.medicare.mss.dao.EEMApplDAO;
import com.medicare.mss.domainobject.EEMOriginalApplDO;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EEMApplAddressVO;
import com.medicare.mss.vo.EEMApplAgentVO;
import com.medicare.mss.vo.EEMApplAttestationVO;
import com.medicare.mss.vo.EEMApplCommentsVO;
import com.medicare.mss.vo.EEMApplEligibilityVO;
import com.medicare.mss.vo.EEMApplLisVO;
import com.medicare.mss.vo.EEMApplMasterVO;
import com.medicare.mss.vo.EEMApplOtherCovVO;
import com.medicare.mss.vo.EEMApplOtherPlanVO;
import com.medicare.mss.vo.EEMApplPlanVO;
import com.medicare.mss.vo.EEMApplProductVO;
import com.medicare.mss.vo.EEMApplSearchVO;
import com.medicare.mss.vo.EEMApplicationVO;

/**
 * @author SUSDASH
 *
 */

@Service
public class EEMOrigApplService {

	@Autowired
	private CacheService sessionHelper;

	@Autowired
	EEMCodeCache eemCodeCache;

	@Autowired
	EEMPersistence eemPersistence;

	@Autowired
	EEMApplDAO applicationDAO;

	public EEMApplMasterVO getOrigAppldetails(Map<String, String> searchParamMap) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		EEMApplMasterVO applMasterVO;

		EEMApplSearchVO searchVO = new EEMApplSearchVO();
		searchVO.setApplId(Integer.parseInt(StringUtil.nonNullTrim(searchParamMap.get("applId"))));
		searchVO.setCustomerId(customerId);

		applMasterVO = getOrigApplDetailsDB(searchVO);
		return applMasterVO;
	}

	public EEMApplMasterVO getOrigApplDetailsDB(EEMApplSearchVO searchVO) {

		EEMOriginalApplDO originalApplDO = applicationDAO.getOrigApplDetails(searchVO.getCustomerId(),
				searchVO.getApplId());
		EEMApplMasterVO origMasterVO = new EEMApplMasterVO();
		if (originalApplDO != null) {
			setOrigMasterDetails(origMasterVO, originalApplDO);
		}
		return origMasterVO;
	}

	private void setOrigMasterDetails(EEMApplMasterVO origMasterVO, EEMOriginalApplDO origApplVO) {

		setOrigApplDetails(origMasterVO, origApplVO);
		setOrigAddressDetails(origMasterVO, origApplVO);
		setOrigProductDetails(origMasterVO, origApplVO);
		setOrigOtherCovDetails(origMasterVO, origApplVO);
		setAttestDetails(origMasterVO, origApplVO);
		setOrigApplCommentsList(origMasterVO, origApplVO);
		setOrigAgentDetails(origMasterVO, origApplVO);
		setOrigApplLisVO(origMasterVO, origApplVO);
		setOrigEligDetails(origMasterVO, origApplVO);
		setOrigApplOtherPlanDetails(origMasterVO, origApplVO);
	}

	public void setOrigApplDetails(EEMApplMasterVO origMasterVO, EEMOriginalApplDO origApplVO) {
		EEMApplicationVO applVO = new EEMApplicationVO();
		if (origApplVO != null) {
			BeanUtils.copyProperties(origApplVO, applVO);
		}
		origMasterVO.setApplVO(applVO);
	}

	public void setOrigAddressDetails(EEMApplMasterVO origMasterVO, EEMOriginalApplDO origApplVO) {

		EEMApplAddressVO addrVO = new EEMApplAddressVO();
		if (origApplVO != null) {
			BeanUtils.copyProperties(origApplVO, addrVO);
		}
		addrVO.setPerState(eemCodeCache.getCode(origApplVO.getPerState(), eemPersistence.getLstStates()));
		String zip = origApplVO.getPerZip5();
		if (zip != null && zip.length() == 9) {
			addrVO.setPerZip5(zip.substring(0, 5));
			addrVO.setPerZip4(zip.substring(5, 9));
		} else if (zip != null && zip.length() == 5) {
			addrVO.setPerZip5(zip);
			addrVO.setPerZip4("");
		}
		addrVO.setMailState(eemCodeCache.getCode(origApplVO.getMailState(), eemPersistence.getLstStates()));
		zip = StringUtil.nonNullTrim(origApplVO.getMailZip5());
		if (zip.length() == 9) {
			addrVO.setMailZip5(zip.substring(0, 5));
			addrVO.setMailZip4(zip.substring(5, 9));
		} else if (zip.length() == 5) {
			addrVO.setMailZip5(zip);
			addrVO.setMailZip4("");
		}
		addrVO.setAuthRepState(eemCodeCache.getCode(origApplVO.getAuthRepState(), eemPersistence.getLstStates()));
		zip = StringUtil.nonNullTrim(origApplVO.getAuthRepZip5());
		if (zip.length() == 9) {
			addrVO.setAuthRepZip5(zip.substring(0, 5));
			addrVO.setAuthRepZip4(zip.substring(5, 9));
		} else if (zip.length() == 5) {
			addrVO.setAuthRepZip5(zip);
			addrVO.setAuthRepZip4("");
		}
		addrVO.setApplId((origApplVO.getApplId()));
		addrVO.setCustomerId(origApplVO.getCustomerId());
		origMasterVO.setApplAddress(addrVO);
	}

	public void setOrigProductDetails(EEMApplMasterVO origMasterVO, EEMOriginalApplDO origApplVO) {

		String customerId = origApplVO.getCustomerId();
		EEMApplPlanVO applPlanVO = new EEMApplPlanVO();
		if (origApplVO != null) {
			BeanUtils.copyProperties(origApplVO, applPlanVO);
		}
		EEMApplProductVO grpProdVO = new EEMApplProductVO();
		String currGrpName = applicationDAO.getGroupName(customerId, applPlanVO.getCurrGrpId(),
				applPlanVO.getReqDtCov());
		String enrollGrpName = applicationDAO.getGroupName(customerId, applPlanVO.getEnrollGrpId(),
				applPlanVO.getReqDtCov());
		String currProdName = applicationDAO.getProductName(customerId, applPlanVO.getCurrProductId(),
				applPlanVO.getReqDtCov());
		String enrollProdName = applicationDAO.getProductName(customerId, applPlanVO.getEnrollProduct(),
				applPlanVO.getReqDtCov());

		grpProdVO.setCurrProdName(currProdName);
		grpProdVO.setCurrGroupName(currGrpName);
		grpProdVO.setEnrollGroupName(enrollGrpName);
		grpProdVO.setEnrollProdName(enrollProdName);

		applPlanVO.setApplId(Integer.toString(origApplVO.getApplId()));
		applPlanVO.setCustomerId(origApplVO.getCustomerId());

		origMasterVO.setGrpProdVO(grpProdVO);
		origMasterVO.setApplPlanVO(applPlanVO);
	}

	public void setOrigOtherCovDetails(EEMApplMasterVO origMasterVO, EEMOriginalApplDO origApplVO) {
		EEMApplOtherCovVO othCovVO = new EEMApplOtherCovVO();
		if (origApplVO != null) {
			BeanUtils.copyProperties(origApplVO, othCovVO);
		}
		origMasterVO.setApplOtherCovVO(othCovVO);
	}

	public void setAttestDetails(EEMApplMasterVO origMasterVO, EEMOriginalApplDO origApplVO) {
		List<EEMApplAttestationVO> applAttestVOList = new ArrayList<>();
		EEMApplAttestationVO applAttestVO = new EEMApplAttestationVO();
		if (origApplVO != null)
			BeanUtils.copyProperties(origApplVO, applAttestVO);
		applAttestVOList.add(applAttestVO);
		origMasterVO.setApplAttestationList(applAttestVOList);
	}

	public void setOrigApplCommentsList(EEMApplMasterVO origMasterVO, EEMOriginalApplDO origApplVO) {
		List<EEMApplCommentsVO> applCommentsVOList = new ArrayList<>();
		EEMApplCommentsVO applCommentVO = new EEMApplCommentsVO();
		if (origApplVO != null) {
			BeanUtils.copyProperties(origApplVO, applCommentVO);
		}
		applCommentsVOList.add(applCommentVO);

		origMasterVO.setApplCommentsList(applCommentsVOList);
	}

	public void setOrigAgentDetails(EEMApplMasterVO origMasterVO, EEMOriginalApplDO origApplVO) {
		EEMApplAgentVO applAgentVO = new EEMApplAgentVO();
		if (origApplVO != null) {
			BeanUtils.copyProperties(origApplVO, applAgentVO);
		}
		origMasterVO.setApplAgentVO(applAgentVO);
	}

	public void setOrigApplLisVO(EEMApplMasterVO origMasterVO, EEMOriginalApplDO origApplVO) {
		EEMApplLisVO applLisVO = new EEMApplLisVO();
		/*
		 * if(origApplVO!= null) BeanUtils.copyProperties(origApplVO,applLisVO);
		 */
		origMasterVO.setApplLisVO(applLisVO);
	}

	public void setOrigEligDetails(EEMApplMasterVO origMasterVO, EEMOriginalApplDO origApplVO) {

		EEMApplEligibilityVO eligVO = new EEMApplEligibilityVO();
		if (origApplVO != null) {
			BeanUtils.copyProperties(origApplVO, eligVO);
		}
		origMasterVO.setApplEligiVO(eligVO);
	}

	public void setOrigApplOtherPlanDetails(EEMApplMasterVO origMasterVO, EEMOriginalApplDO origApplVO) {
		EEMApplOtherPlanVO applOtherPlanVO = new EEMApplOtherPlanVO();
		if (origApplVO != null) {
			BeanUtils.copyProperties(origApplVO, applOtherPlanVO);
		}
		origMasterVO.setApplOtherPlanVO(applOtherPlanVO);
	}

}
