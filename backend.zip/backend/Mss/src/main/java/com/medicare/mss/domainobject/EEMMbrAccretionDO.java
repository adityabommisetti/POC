package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMMbrAccretionDO {

	@ColumnMapper(columnName = "RES_ADDR_LINE1", propertyName = "address1")
	private String address1;

	@ColumnMapper(columnName = "RES_ADDR_LINE2", propertyName = "address2")
	private String address2;

	@ColumnMapper(columnName = "BIRTH_DATE", propertyName = "birthDate")
	private String birthDate;

	@ColumnMapper(columnName = "RES_ADDR_CITY", propertyName = "city")
	private String city;

	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "createUserId")
	private String createUserId;

	@ColumnMapper(columnName = "CREDITABLE_COV_IND", propertyName = "credCovflag")
	private String credCovflag;

	@ColumnMapper(columnName = "DISREASON_CD", propertyName = "disEnrollReason")
	private String disEnrollReason;

	@ColumnMapper(columnName = "EFFECTIVE_DATE", propertyName = "effectiveDate")
	private String effectiveDate;

	@ColumnMapper(columnName = "EGHP_IND", propertyName = "eghpInd")
	private String eghpInd;

	@ColumnMapper(columnName = "ELECTION_TYPE", propertyName = "electionType")
	private String electionType;

	@ColumnMapper(columnName = "PBP_ID", propertyName = "pbpId")
	private String pbpId;

	@ColumnMapper(columnName = "PLAN_ID", propertyName = "planId")
	private String planId;

	@ColumnMapper(columnName = "PREMIUM_WHOLD_OPT", propertyName = "premiumHoldOption")
	private String premiumHoldOption;

	@ColumnMapper(columnName = "RX_BIN", propertyName = "primBin")
	private String primBin;

	@ColumnMapper(columnName = "RX_GROUP", propertyName = "primeRxGrp")
	private String primeRxGrp;

	@ColumnMapper(columnName = "RX_PCN", propertyName = "primPcn")
	private String primPcn;

	@ColumnMapper(columnName = "RX_ID", propertyName = "primRxId")
	private String primRxId;

	@ColumnMapper(columnName = "PRIOR_COMM_OVR", propertyName = "priorCommercialOvrInd")
	private String priorCommercialOvrInd;

	@ColumnMapper(columnName = "PRTC_PREMIUM_AMT", propertyName = "prtCAmt")
	private String prtCAmt;

	@ColumnMapper(columnName = "PRTD_PREMIUM_AMT", propertyName = "prtDAmt")
	private String prtDAmt;

	@ColumnMapper(columnName = "PRTD_OPTOUT_IND", propertyName = "prtDOutInd")
	private String prtDOutInd;

	@ColumnMapper(columnName = "SEC_RX_BIN", propertyName = "secBin")
	private String secBin;

	@ColumnMapper(columnName = "SEC_RX_PCN", propertyName = "secPcn")
	private String secPcn;

	@ColumnMapper(columnName = "SEC_RX_ID", propertyName = "secRxId")
	private String secRxId;

	@ColumnMapper(columnName = "APPLICATION_DATE", propertyName = "signdate")
	private String signdate;

	@ColumnMapper(columnName = "RES_ADDR_STATE", propertyName = "state")
	private String state;

	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "time")
	private String time;

	@ColumnMapper(columnName = "TXN_CODE", propertyName = "transCode")
	private String transCode;

	@ColumnMapper(columnName = "TOT_UNCOV_MONTHS", propertyName = "uncoveredMonths")
	private String uncoveredMonths;

	@ColumnMapper(columnName = "RES_ADDR_ZIP4", propertyName = "zip4")
	private String zip4;

	@ColumnMapper(columnName = "RES_ADDR_ZIP", propertyName = "zip5")
	private String zip5;

	private String transactionType;
	private String transDesc;

}
