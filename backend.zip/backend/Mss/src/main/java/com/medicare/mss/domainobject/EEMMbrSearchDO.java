package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMMbrSearchDO {

	@ColumnMapper(columnName = "CMS_EFF_MO", propertyName = "cmsEffMonth")
	private String cmsEffMonth;
	
	@ColumnMapper(columnName = "HIC_NBR", propertyName = "hicNbr")
	private String hicNbr;
	
	@ColumnMapper(columnName = "MBI", propertyName = "mbi")
	private String mbi;
	
	@ColumnMapper(columnName = "MEDICARE_ID", propertyName = "medicareId")
	private String medicareId;
	
	@ColumnMapper(columnName = "MEMBER_ID", propertyName = "memberId")
	private String memberId;
	
	@ColumnMapper(columnName = "NAME", propertyName = "name")
	private String name;
	
	@ColumnMapper(columnName = "SUPPLEMENTAL_ID", propertyName = "supplementalId")
	private String supplementalId;

}