package com.medicare.mss.domainobject;

import com.medicare.mss.vo.BaseVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class EMLEPMaximusDO extends BaseVO implements Cloneable {

	private static final long serialVersionUID = -8104691666848052889L;

	private String decisionType;
	private String caseFileRecDate;
	private String caseFileNumber;
	private String caseFileDueDate;
	private String decisionRecDate;
	private String transactionDueDate;
	private String frmtCreateTime;
	private String frmtLastUpdtTime;
	private String name;
	private String memberId;
	private String isUpdate;
}
