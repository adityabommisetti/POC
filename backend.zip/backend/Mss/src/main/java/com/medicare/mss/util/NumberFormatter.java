/*
 * $Id: NumberFormatter.java,v 1.1 2014/06/26 07:46:51 praveen Exp $
 */
package com.medicare.mss.util;

import java.text.DecimalFormat;

final public class NumberFormatter {

	private static DecimalFormat df2 = new DecimalFormat("########0.00;-########0.00");

	private NumberFormatter() {
	}

	public static String formatDecimal2Places(String decNbr) {
		double d = Double.parseDouble(decNbr);
		return df2.format(d);
	}

	public static String formatDecimal2Places(double decNbr) {
		return df2.format(decNbr);
	}

	public static String formatDecimal2PlacesDelim(double decNbr) {
		return df2.format(decNbr);
	}

}
