package com.medicare.mss.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.EEMContext;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.service.EEMMbrDemographicService;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EEMMbrDemographicVO;

@RestController
@RequestMapping("/member")
public class EEMMbrDemographicController {

	@Autowired
	private EEMMbrDemographicService mbrDemographicService;

	@Autowired
	private CacheService sessionHelper;

	@PostMapping(path = ReqMappingConstants.MBR_DEMOGRAPHIC_GET)
	public ResponseEntity<JSONResponse> getMbrDemographic(@RequestBody Map<String, String> searchParamMap)
			throws ApplicationException {
		EEMContext context = sessionHelper.getEEMContext();
		EEMMbrDemographicVO mbrDemographicVO = context.getMbrMasterVO().getMbrDemographicVO();

		if (null == mbrDemographicVO) {
			String medicareId = StringUtil.nonNullTrim(searchParamMap.get("medicareId")).toUpperCase();
			String memberId = StringUtil.nonNullTrim(searchParamMap.get("memberId"));
			String CmsEffMonth = DateFormatter.reFormat(StringUtil.nonNullTrim(searchParamMap.get("cmsEffMonth")),
					DateFormatter.MM_YYYY, DateFormatter.YYYYMM);
			mbrDemographicVO = mbrDemographicService.getMbrDemographic(medicareId, memberId, CmsEffMonth);
			context.getMbrMasterVO().setMbrDemographicVO(mbrDemographicVO);
			sessionHelper.setEEMContext(context);
		}
		return sendResponse(mbrDemographicVO);

	}

	@PostMapping(ReqMappingConstants.MBR_DEMOGRAPHIC_UPDATE)
	public ResponseEntity<JSONResponse> mbrDemographicUpdate(@RequestBody EEMMbrDemographicVO mbrDemographicVO)
			throws ApplicationException {

		mbrDemographicVO = mbrDemographicService.mbrDemographicUpdate(mbrDemographicVO);
		return sendResponse(mbrDemographicVO);
	}

	private ResponseEntity<JSONResponse> sendResponse(Object object) {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;
		if (null == object) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			jsonResponse.setData(null);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
			jsonResponse.setMessage(EEMConstants.BLANK);
			jsonResponse.setData(object);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}

}
