package com.medicare.mss.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.AddressFormatter;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode(callSuper = false)
public class EEMMbrAddressVO extends BaseVO implements EMDatedSegmentVO, Cloneable, Serializable {

	private static final long serialVersionUID = 8085133371657938236L;

	private String address1;
	private String address2;
	private String address3;
	private String addressType;
	private String addressValidation;
	private String addrTypeDesc;
	private String cellPhoneNbr;
	private String city;
	private String countryCd;
	private String countyCd;
	private String countyName;
	private String editOverrideInd;
	private String effEndDate;
	private String effStartDate;
	private String faxNbr;
	private String homePhoneNbr;
	private String memberId;
	private String overrideInd;
	private String stateAbbr;
	private String stateCd;
	private String workPhoneNbr;
	private String zipCd;

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	public String getAddressValidation() {
		return addressValidation;
	}

	public String getEditOverrideInd() {
		return editOverrideInd;
	}

	public String getEffEndDateFrmt() {
		return DateFormatter.reFormat(effEndDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getEffStartDateFrmt() {
		return DateFormatter.reFormat(effStartDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	@Override
	public String getType() {
		return addressType;
	}

	public String getZipCd4() {

		return AddressFormatter.getZip4(zipCd);
	}

	public String getZipCd5() {

		return AddressFormatter.getZip5(zipCd);
	}

	public String getZipCdFrmt() {
		return AddressFormatter.formatZip(zipCd);
	}

	@Override
	public boolean isEndDateChange(Object obj) {

		EEMMbrAddressVO chkVO = (EEMMbrAddressVO) obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate) && chkVO.getAddressType().equals(this.addressType)
				&& chkVO.getAddress1().equals(this.address1) && chkVO.getAddress2().equals(this.address2)
				&& chkVO.getAddress3().equals(this.address3) && chkVO.getCity().equals(this.city)
				&& chkVO.getStateCd().equals(this.stateCd) && chkVO.getZipCd().equals(this.zipCd)
				&& chkVO.getCountryCd().equals(this.countryCd) && chkVO.getHomePhoneNbr().equals(this.homePhoneNbr)
				&& chkVO.getCellPhoneNbr().equals(this.cellPhoneNbr)
				&& chkVO.getWorkPhoneNbr().equals(this.workPhoneNbr) && chkVO.getFaxNbr().equals(this.faxNbr)
				&& chkVO.getMemberId().equals(this.memberId) && chkVO.getCustomerId().equals(this.getCustomerId())
				&& chkVO.getOverrideInd().equals(this.overrideInd))
			return true;
		return false;
	}

	@Override
	public boolean isForSamePeriod(Object obj) {

		EEMMbrAddressVO chkVO = (EEMMbrAddressVO) obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate) && chkVO.getEffEndDate().equals(this.effEndDate)
				&& chkVO.getAddressType().equals(this.addressType) && chkVO.getMemberId().equals(this.memberId)
				&& chkVO.getCustomerId().equals(this.getCustomerId())
				&& chkVO.getOverrideInd().equals(this.overrideInd))
			return true;
		return false;
	}

	@Override
	public boolean isSame(Object obj) {

		EEMMbrAddressVO chkVO = (EEMMbrAddressVO) obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate) && chkVO.getEffEndDate().equals(this.effEndDate)
				&& chkVO.getAddressType().equals(this.addressType) && chkVO.getMemberId().equals(this.memberId)
				&& chkVO.getCustomerId().equals(this.getCustomerId()) && chkVO.getOverrideInd().equals(this.overrideInd)
				&& chkVO.getCreateTime().equals(this.getCreateTime())
				&& chkVO.getCreateUserId().equals(this.getCreateUserId())
				&& chkVO.getLastUpdtTime().equals(this.getLastUpdtTime())
				&& chkVO.getLastUpdtUserId().equals(this.getLastUpdtUserId()))
			return true;
		return false;
	}

	public void setAddressValidation(String addressValidation) {
		this.addressValidation = addressValidation;
	}

	public void setEditOverrideInd(String editOverrideInd) {
		this.editOverrideInd = editOverrideInd;
	}

	public void setEffEndDateFrmt(String effEndDate) {
		this.effEndDate = DateFormatter.reFormat(effEndDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public void setEffStartDateFrmt(String effStartDate) {
		this.effStartDate = DateFormatter.reFormat(effStartDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

}
