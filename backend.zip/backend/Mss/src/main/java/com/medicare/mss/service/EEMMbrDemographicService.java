package com.medicare.mss.service;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.medicare.mss.dao.EEMMbrDAO;
import com.medicare.mss.domainobject.EEMMbrDemographicDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.EEMContext;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.vo.EEMMbrDemographicVO;

@Service
@Transactional(rollbackFor = ApplicationException.class)
public class EEMMbrDemographicService {

	@Autowired
	private EEMMbrDAO enrollDao;

	@Autowired
	private CacheService sessionHelper;


	public EEMMbrDemographicVO getMbrDemographic(String medicareId, String memberId, String CmsEffMonth)
			throws ApplicationException {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		EEMMbrDemographicVO mbrDemoVO = new EEMMbrDemographicVO();
		EEMMbrDemographicDO mbrDemoDO = enrollDao.getMbrDemographicForEffMth(customerId, memberId, CmsEffMonth);
		BeanUtils.copyProperties(mbrDemoDO, mbrDemoVO);
		mbrDemoVO.setHicNbr(medicareId);

		return mbrDemoVO;
	}

	public EEMMbrDemographicVO mbrDemographicUpdate(EEMMbrDemographicVO newDemoVO) throws ApplicationException {
		EEMContext context = sessionHelper.getEEMContext();
		String userId = sessionHelper.getUserInfo().getUserId();

		EEMMbrDemographicDO oldDemoDO = new EEMMbrDemographicDO();
		BeanUtils.copyProperties(context.getMbrMasterVO().getMbrDemographicVO(), oldDemoDO);

		int sqlCnt = 0;

		sqlCnt = enrollDao.setDemographicOverride(oldDemoDO, userId);
		if (sqlCnt == 1) {
			EEMMbrDemographicDO newDemoDO = new EEMMbrDemographicDO();
			BeanUtils.copyProperties(newDemoVO, newDemoDO);
			String ts = DateUtil.getCurrentDatetimeStamp();
			newDemoDO.setCustomerId(oldDemoDO.getCustomerId());
			newDemoDO.setCreateUserId(userId);
			newDemoDO.setCreateTime(ts);
			newDemoDO.setLastUpdtUserId(userId);
			newDemoDO.setLastUpdtTime(ts);
			newDemoDO.setDemoSeqNbr(oldDemoDO.getDemoSeqNbr() + 1);

			sqlCnt = enrollDao.insertMbrDemographic(newDemoDO);
			if (sqlCnt == 1) {
				BeanUtils.copyProperties(newDemoDO, newDemoVO);
				context.getMbrMasterVO().setMbrDemographicVO(newDemoVO);
				sessionHelper.setEEMContext(context);
				return newDemoVO;
			}
		}
		return null;
	}

}
