package com.medicare.mss.rowmappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.util.StringUtil;

public class PersistGetLstRowMapper implements RowMapper<LabelValuePair> {
	
	
	private String sName ;
	private String sValue ;
	public PersistGetLstRowMapper(String sName, String sValue){
		this.sName = sName;
		this.sValue=sValue;
	}

	

	@Override
	public LabelValuePair mapRow(ResultSet rsts, int arg1) throws SQLException {
		
			LabelValuePair nvp = new LabelValuePair(StringUtil.nonNullTrim(rsts
					.getString(sName)), StringUtil.nonNullTrim(rsts
					.getString(sValue)));
	
		return nvp;
	}

}
