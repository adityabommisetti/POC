package com.medicare.mss.domainobject;

import java.io.Serializable;

import com.medicare.mss.annotation.ColumnMapper;
import com.medicare.mss.util.AddressFormatter;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.vo.EMDatedSegmentVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class EEMMbrAddressDO extends BaseDO implements EMDatedSegmentVO, Cloneable, Serializable {

	private static final long serialVersionUID = 6401294604789862440L;

	@ColumnMapper(columnName = "ADDRESS1", propertyName = "address1")
	private String address1;
	
	@ColumnMapper(columnName = "ADDRESS2", propertyName = "address2")
	private String address2;
	
	@ColumnMapper(columnName = "ADDRESS3", propertyName = "address3")
	private String address3;
	
	@ColumnMapper(columnName = "ADDRESS_TYPE", propertyName = "addressType")
	private String addressType;
	
	private String addressValidation;	
	
	private String addrTypeDesc;
	
	@ColumnMapper(columnName = "CELL_PHONE_NBR", propertyName = "cellPhoneNbr")
	private String cellPhoneNbr;
	
	@ColumnMapper(columnName = "CITY", propertyName = "city")
	private String city;
	
	@ColumnMapper(columnName = "COUNTRY_CD", propertyName = "countryCd")
	private String countryCd;
	
	@ColumnMapper(columnName = "COUNTY_CD", propertyName = "countyCd")
	private String countyCd;
	
	private String countyName;
	private boolean dsInfoChange;	
	private String editOverrideInd;
	
	@ColumnMapper(columnName = "EFF_END_DATE", propertyName = "effEndDate")
	private String effEndDate;
	
	@ColumnMapper(columnName = "EFF_START_DATE", propertyName = "effStartDate")
	private String effStartDate;
	
	@ColumnMapper(columnName = "FAX_NBR", propertyName = "faxNbr")
	private String faxNbr;
	
	@ColumnMapper(columnName = "HOME_PHONE_NBR", propertyName = "homePhoneNbr")
	private String homePhoneNbr;
	
	@ColumnMapper(columnName = "MEMBER_ID", propertyName = "memberId")
	private String memberId;
	
	@ColumnMapper(columnName = "OVERRIDE_IND", propertyName = "overrideInd")
	private String overrideInd;
	
	@ColumnMapper(columnName = "STATE_CD", propertyName = "stateAbbr")
	private String stateAbbr;
	
	private String stateCd;
	
	@ColumnMapper(columnName = "WORK_PHONE_NBR", propertyName = "workPhoneNbr")
	private String workPhoneNbr;
	
	@ColumnMapper(columnName = "ZIP_CD", propertyName = "zipCd")
	private String zipCd;
	
	

    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
 
	public String getEffEndDateFrmt() {
		return DateFormatter.reFormat(effEndDate,DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
	}

	public String getEffStartDateFrmt() {
		return DateFormatter.reFormat(effStartDate,DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
	}

	public String getType() {
		return addressType;
	}
	public String getZipCd4() {
		return AddressFormatter.getZip4(zipCd);
	}
	public String getZipCd5() {
		return AddressFormatter.getZip5(zipCd);
	}
	public String getZipCdFrmt() {
		return AddressFormatter.formatZip(zipCd);
	}

	public boolean isEndDateChange(Object obj) {
		
		EEMMbrAddressDO chkVO = (EEMMbrAddressDO)obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate)
			&& chkVO.getAddressType().equals(this.addressType)
				&& chkVO.getAddress1().equals(this.address1)
					&& chkVO.getAddress2().equals(this.address2)
						&& chkVO.getAddress3().equals(this.address3)
							&& chkVO.getCity().equals(this.city)
								&& chkVO.getStateCd().equals(this.stateCd)
									&& chkVO.getZipCd().equals(this.zipCd)
										&& chkVO.getCountryCd().equals(this.countryCd)
											&& chkVO.getHomePhoneNbr().equals(this.homePhoneNbr)
												&& chkVO.getCellPhoneNbr().equals(this.cellPhoneNbr)
													&& chkVO.getWorkPhoneNbr().equals(this.workPhoneNbr)
														&& chkVO.getFaxNbr().equals(this.faxNbr)
															&& chkVO.getMemberId().equals(this.memberId)
																&& chkVO.getCustomerId().equals(this.getCustomerId())
																	&& chkVO.getOverrideInd().equals(this.overrideInd))
																		return true;
		return false;
	}

	public boolean isForSamePeriod(Object obj) {
		
		EEMMbrAddressDO chkVO = (EEMMbrAddressDO)obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate)
			&& chkVO.getEffEndDate().equals(this.effEndDate)
				&& chkVO.getAddressType().equals(this.addressType)
					&& chkVO.getMemberId().equals(this.memberId)
						&& chkVO.getCustomerId().equals(this.getCustomerId())
							&& chkVO.getOverrideInd().equals(this.overrideInd))
								return true;
		return false;
	}
	
	public boolean isSame(Object obj) {
		
		EEMMbrAddressDO chkVO = (EEMMbrAddressDO)obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate)
			&& chkVO.getEffEndDate().equals(this.effEndDate)
				&& chkVO.getAddressType().equals(this.addressType)
					&& chkVO.getMemberId().equals(this.memberId)
						&& chkVO.getCustomerId().equals(this.getCustomerId())
							&& chkVO.getOverrideInd().equals(this.overrideInd)
								&& chkVO.getCreateTime().equals(this.getCreateTime())
									&& chkVO.getCreateUserId().equals(this.getCreateUserId())
										&& chkVO.getLastUpdtTime().equals(this.getLastUpdtTime())
											&& chkVO.getLastUpdtUserId().equals(this.getLastUpdtUserId()))
												return true;
		return false;
	}
	
	public void setEffEndDateFrmt(String effEndDate) {
		this.effEndDate = DateFormatter.reFormat(effEndDate,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
	}

	public void setEffStartDateFrmt(String effStartDate) {
		this.effStartDate = DateFormatter.reFormat(effStartDate,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
	}

}
