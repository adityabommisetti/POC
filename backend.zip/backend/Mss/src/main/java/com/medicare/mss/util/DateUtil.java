/*
 * $Id: DateUtil.java,v 1.2 2017/03/24 12:07:11 kavitha Exp $
 */

package com.medicare.mss.util;

import java.sql.Timestamp;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.medicare.mss.constants.EEMConstants;

/**
 *
 * @author BNenne
 */
final public class DateUtil {

	public static final String FILE_DATE_TS_FRMT = "Dyymmdd.Thhmmsst";

	private static SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
	
	private static Map<String, String> MONTH_MAP;

	/** Creates a new instance of DateUtil */
	private DateUtil() {
	}

	/**
	 * Setter for property frmtLogTs.
	 * 
	 * @param frmt
	 *            New format value frmt.
	 *
	 */
	public static void setLogTsFrmt(String frmt) {
		DATE_FORMAT = new SimpleDateFormat(frmt);
	}

	public static String getDTS() {
		return getDTS(new Date());
	}

	public static String getDTS(long ts) {
		return getDTS(new Date(ts));
	}

	public static String getTodaysDate() {
		return formatDate(new Date(), "yyyyMMdd");
	}

	public static String getTodaysDate(String formatType) {
		return formatDate(new Date(), formatType);
	}

	public static int getTodaysDateAsInt() {
		return Integer.parseInt(getTodaysDate());
	}

	public static String getDTS(Date dte) {
		return formatDate(dte, "yyyyMMddHHmmssSSS");
	}

	public static String getFileDTS() {
		return formatFileDTS(getDTS());
	}

	public static String getFileDTS(Date dte) {
		return formatFileDTS(getDTS(dte));
	}

	public static String formatFileDTS(String dts) {
		return CommonUtils.buildQuery("D", dts.substring(2, 8), ".T", dts.substring(8, 15));
	}

	public static String getLogTS() {
		return DATE_FORMAT.format(new Date());
	}

	public static String getLogTS(Date dte) {
		return DATE_FORMAT.format(dte);
	}

	public static Date parseLogTS(String dte) throws ParseException {
		return DATE_FORMAT.parse(dte);
	}

	public static String formatDate(Date dte, String frmt) {
		if (frmt.equals(FILE_DATE_TS_FRMT))
			return getFileDTS(dte);
		SimpleDateFormat dteFrmt = new SimpleDateFormat(frmt);
		return dteFrmt.format(dte);
	}

	public static String formatFDOM(String yyyyMM) {
		if (yyyyMM == null)
			return null;
		if (yyyyMM.equals(""))
			return yyyyMM;
		return yyyyMM + "01";
	}

	public static String formatEOM(String yyyyMM) {

		if (yyyyMM == null)
			return null;
		if (yyyyMM.equals(""))
			return yyyyMM;

		String mth = yyyyMM.substring(4, 6);
		String day = null;

		if (mth.equals("04") || mth.equals("06") || mth.equals("09") || mth.equals("11"))
			day = "30";

		if (mth.equals("02")) {
			try {
				int y = Integer.parseInt(yyyyMM.substring(0, 4));
				int m = Integer.parseInt(yyyyMM.substring(4));
				Calendar cal = Calendar.getInstance();
				cal.set(Calendar.YEAR, y);
				cal.set(Calendar.MONTH, m);
				cal.set(Calendar.DAY_OF_MONTH, 1);
				cal.clear(Calendar.HOUR_OF_DAY);
				cal.clear(Calendar.MINUTE);
				cal.clear(Calendar.SECOND);
				cal.clear(Calendar.MILLISECOND);
				cal.add(Calendar.DAY_OF_MONTH, -1);
				day = Integer.toString(cal.get(Calendar.DAY_OF_MONTH));
			} catch (Exception e) {
				day = "28";
			}
		}

		if (day == null)
			day = "31";

		return yyyyMM + day;

	}

	/**
	 * Added on nov,29,2007 by deepak This function ruturns month name for month
	 * index (Example it will retrun january for 01 )
	 * 
	 * @param month
	 * @return
	 */
	public static String getMonthName(String month) {
		return (new DateFormatSymbols().getMonths()[Integer.parseInt(month) - 1]);
	}

	/**
	 * Added on nov,29,2007 by deepak This function change date format (Example it
	 * change date 10/2007 to 200712 )
	 * 
	 * @param date
	 * @return
	 */
	public static String changedDateFormat(String date) {
		if (date != null && date.indexOf('/') != -1) {
			return date.substring(3, 7) + date.substring(0, 2);
		}
		return date;
	}

	/**
	 * Added on nov,29,2007 by Rakesh This function change date format (Example it
	 * change date 04/24/2007 to 20070424 )
	 * 
	 * @param date
	 * @return
	 */
	public static String changedDateFormatForMonth(String date) {
		if (!StringUtil.isNullOrEmpty(date) && date.length() > 7) {

			if (date.indexOf('/') != -1) {
				if (date.length() == 10)
					return date.substring(6, 10) + date.substring(0, 2) + date.substring(3, 5);
				else
					return date.replaceAll("/", "");
			}

		}

		return date;
	}

	/**
	 * This method will format the date from "20060113" to "01/13/2006"
	 * 
	 * @param dateStr
	 * @return
	 */
	public static String formatMmDdYyyy(String dateStr) {
		if (null == dateStr)
			return "";

		if (dateStr.startsWith("0")) {
			dateStr = "";
		} else if (dateStr != null && dateStr.length() == 8)
			return dateStr.substring(4, 6) + "/" + dateStr.substring(6, 8) + "/" + dateStr.substring(0, 4);

		return dateStr;
	}

	/**
	 * Added on nov,29,2007 by deepak This function add '/' sign into date
	 * 
	 * @param date
	 * @return
	 */
	public static String addSlashIntoDate(String date) {
		if (date != null) {
			if (date.indexOf('/') == -1 && date.length() >= 6) {
				if ("".equals(date)) {
					return date;
				} else {
					return date.substring(4, 6) + "/" + date.substring(0, 4);
				}
			} else
				return date;
		}
		return date;
	}

	/**
	 * returns date in MM/dd/yyyy format
	 * 
	 * @author hemant
	 * @param date
	 * @return
	 */
	public static String getFirstOrLastDayOfMonth(String date, boolean isFirstDay) {
		if (date != null && (!"".equals(date))) {
			date = changedDateFormat(date);
			if (isFirstDay)
				date = formatFDOM(date);
			else
				date = formatEOM(date);

			date = date.substring(4, 6) + "/" + date.substring(6) + "/" + date.substring(0, 4);
		}
		return date;
	}

	/**
	 * 
	 * Added on nov,29,2007 by deepak This function convet month name into its index
	 * 
	 * @param name
	 */
	public static String convetMonthToNumericValue(String month) {
		String value = month;

		MONTH_MAP = new HashMap<>();

		MONTH_MAP.put("January", "01");
		MONTH_MAP.put("February", "02");
		MONTH_MAP.put("March", "03");
		MONTH_MAP.put("April", "04");
		MONTH_MAP.put("May", "05");
		MONTH_MAP.put("June", "06");
		MONTH_MAP.put("July", "07");
		MONTH_MAP.put("August", "08");
		MONTH_MAP.put("September", "09");
		MONTH_MAP.put("October", "10");
		MONTH_MAP.put("November", "11");
		MONTH_MAP.put("December", "12");

		if (MONTH_MAP.containsKey(month)) {
			value = MONTH_MAP.get(month);
		}
		return value;
	}

	public static boolean isGoodDate(String temp) {
		if (temp.length() != 10 && temp.length() != 7)
			return false;
		String validChars = "0123456789/";
		for (int i = 0; i < temp.length(); i++) {
			char j = temp.charAt(i);
			if (validChars.indexOf(j) < 0)
				return false;
		}
		return true;
	}

	/*----------------------------------------*/

	public static int getYYYYMMDD(String pwdExpireDate) {
		pwdExpireDate = pwdExpireDate.substring(0, 10).replace("-", "");

		return Integer.parseInt(pwdExpireDate);
	}

	public static String getCurrentDatetimeStamp() {
		Date currentDate = Calendar.getInstance().getTime();
		return getDatetimeStampFor(currentDate);
	}

	public static String getDatetimeStampFor(Date date) {
		return formatDate(date, EEMConstants.DEFAULT_TIMESTAMP_FORMAT);
	}
	
	public static Date parseDate(String date, String format) throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		return dateFormat.parse(date);
	}
	
	public static String getEffDateForIDC(String oldDate, String oldFormat, String newFormat, boolean isUserEffDate)
			throws ParseException {

		SimpleDateFormat sdfOld = new SimpleDateFormat(oldFormat);
		Date date = sdfOld.parse(oldDate);
		if (!isUserEffDate) {
			Date today = new Date();
			if (date.compareTo(today) < 0) {
				date = today;
			}
		}
		SimpleDateFormat sdfnew = new SimpleDateFormat(newFormat);
		return (sdfnew.format(date));
	}

	public static int getMinuteDiff(Date toDate, Date fromDate) {
		return (int) ((toDate.getTime() - fromDate.getTime()) / (1000 * 60));
	}
	
	/**
	 * This method adds number of milliseconds provided to the current timestamp
	 * 
	 * @param millisecondToBeAdded
	 * @return later timestamp
	 */
	public static String getCurrentDatetimeStampPlus(int millisecondToBeAdded) {
		long lastUpdtTime = System.currentTimeMillis();
		Timestamp original = new Timestamp(lastUpdtTime);
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(original.getTime());
		cal.add(Calendar.MILLISECOND, millisecondToBeAdded);
		Timestamp later = new Timestamp(cal.getTime().getTime());
		return insertExtraZerosIfNeeded(later.toString());
	}
	
	public static String appendExtraZerosIfNeeded(String maxLastUpdate) {
		int totalMillis = 6;
		StringBuilder dbMaxLastUpdate = new StringBuilder(maxLastUpdate);
		
		if (StringUtils.isNotBlank(maxLastUpdate) && maxLastUpdate.lastIndexOf('.') != -1) {
			String millis = maxLastUpdate.substring(maxLastUpdate.lastIndexOf('.') + 1);
			int count = totalMillis - millis.length();

			for (int i = 0; i < count; i++) {
				dbMaxLastUpdate.append('0');
			}
		}
		return dbMaxLastUpdate.toString();
	}
	
	public static String insertExtraZerosIfNeeded(String maxLastUpdate) {
		int totalMillis = 6;
		StringBuilder dbMaxLastUpdate = new StringBuilder(maxLastUpdate);
		StringBuilder extraZeros = new StringBuilder();

		if (StringUtils.isNotBlank(maxLastUpdate) && maxLastUpdate.lastIndexOf('.') != -1) {
			String millis = maxLastUpdate.substring(maxLastUpdate.lastIndexOf('.') + 1);
			int count = totalMillis - millis.length();

			for (int i = 0; i < count; i++) {
				extraZeros.append('0');
			}
			dbMaxLastUpdate.insert(maxLastUpdate.lastIndexOf('.') + 1, extraZeros);
		}
		return dbMaxLastUpdate.toString();
	}
	
}
