package com.medicare.mss.vo;

import java.io.Serializable;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode(callSuper = false)
public class EMMbrPCPInfoVO extends BaseVO implements EMDatedSegmentVO, Cloneable, Serializable {

	private static final long serialVersionUID = 635732456960310841L;
	private String memberId;
	private String pcpNbr;
	private String locationId;
	private String effStartDate;
	private String effEndDate;
	private String overrideInd;
	private String currentPatientInd;
	private String clinicName;
	private String doctorName;
	private String doctorAddress;
	private String doctorCity;
	private String doctorState;
	private String doctorZip;
	private String acceptNewPatient;

	// IFOX-414925 Network ID CR - Start
	private String lineOfBusiness;
	// IFOX-414925 Network ID CR - End
	/**
	 * pcpStatus holds pcpStatus
	 */
	private String pcpStatus;
	/**
	 * pcpChangeInd holds pcpChangeInd
	 */
	private String pcpChangeInd;
	/**
	 * errorDescription holds errorDescription
	 */
	private String errorDescription;
	/**
	 * pcpChangeSendTime holds pcpChangeSendTime
	 */
	private String pcpChangeSendTime;
	/**
	 * pcpchangeReceiveTime holds pcpchangeReceiveTime
	 */
	private String pcpchangeReceiveTime;
	/**
	 * pcpName holds pcpName
	 */
	private String pcpName;

	/* Access health PCP CR- Start */
	private String pcpNpi;

	/* Access health PCP CR- END */

	// Begin : Added for IFOX-00396582
	private String disEnrollApprvStartDateMinusOne;
	private String officeCategoryCodeColumnInDB = "N";
	private String officeCategoryCode;
	private String currentDateTime;
	private String message;

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	public String getEffEndDateFrmt() {
		return DateFormatter.reFormat(effEndDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setEffEndDateFrmt(String effEndDate) {
		this.effEndDate = DateFormatter.reFormat(effEndDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getEffStartDateFrmt() {
		return DateFormatter.reFormat(effStartDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setEffStartDateFrmt(String effStartDate) {
		this.effStartDate = DateFormatter.reFormat(effStartDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	@Override
	public boolean isEndDateChange(Object obj) {

		EMMbrPCPInfoVO chkVO = (EMMbrPCPInfoVO) obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate))
			if (chkVO.getPcpNbr().equals(this.pcpNbr))
				if (chkVO.getMemberId().equals(this.memberId))
					if (chkVO.getCustomerId().equals(this.customerId))
						if (chkVO.getOverrideInd().equals(this.overrideInd))
							return true;
		return false;
	}

	@Override
	public boolean isForSamePeriod(Object obj) {

		EMMbrPCPInfoVO chkVO = (EMMbrPCPInfoVO) obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate))
			if (chkVO.getEffEndDate().equals(this.effEndDate))
				if (chkVO.getPcpNbr().equals(this.pcpNbr))
					if (chkVO.getMemberId().equals(this.memberId))
						if (chkVO.getCustomerId().equals(this.customerId))
							if (chkVO.getOverrideInd().equals(this.overrideInd))
								return true;
		return false;
	}

	@Override
	public boolean isSame(Object obj) {

		EMMbrPCPInfoVO chkVO = (EMMbrPCPInfoVO) obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate))
			if (chkVO.getEffEndDate().equals(this.effEndDate))
				if (chkVO.getPcpNbr().equals(this.pcpNbr))
					if (chkVO.getMemberId().equals(this.memberId))
						if (chkVO.getCustomerId().equals(this.customerId))
							if (chkVO.getOverrideInd().equals(this.overrideInd))
								if (chkVO.getCreateTime().equals(this.createTime))
									if (chkVO.getCreateUserId().equals(this.createUserId))
										if (chkVO.getLastUpdtTime().equals(this.lastUpdtTime))
											if (chkVO.getLastUpdtUserId().equals(this.lastUpdtUserId))
												return true;
		return false;
	}

	@Override
	public String getType() {
		return "PCP";
	}

	public String getDoctorZip() {
		String formattedDoctorZip = null;
		if (Objects.isNull(doctorZip)) {
			formattedDoctorZip = EEMConstants.BLANK;
		} else if (doctorZip.length() == 9) {
			formattedDoctorZip = new StringBuilder(doctorZip.substring(0, 5)).append('-').append(doctorZip.substring(5))
					.toString();
		} else if (doctorZip.length() == 5 || doctorZip.length() == 10) {
			formattedDoctorZip = doctorZip;
		} else {
			formattedDoctorZip = doctorZip.substring(0, 5);
		}
		return formattedDoctorZip;
	}

}
