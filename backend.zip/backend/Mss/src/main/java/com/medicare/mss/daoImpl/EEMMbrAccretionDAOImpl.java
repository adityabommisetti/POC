package com.medicare.mss.daoImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.medicare.mss.dao.EEMMbrAccretionDAO;
import com.medicare.mss.domainobject.EEMMbrAccretionDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;

@Repository
public class EEMMbrAccretionDAOImpl implements EEMMbrAccretionDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<EEMMbrAccretionDO> getMbrAccretion(String customerId, String memberId, String showAll) {

		List<EEMMbrAccretionDO> list;

		try {
			StringBuilder squery = new StringBuilder("SELECT RX_GROUP, TXN_CODE, EFFECTIVE_DATE, LAST_UPDT_TIME,")
					.append(" APPLICATION_DATE, RES_ADDR_LINE1, RES_ADDR_LINE2,RES_ADDR_CITY,RES_ADDR_STATE,")
					.append(" RES_ADDR_ZIP,RES_ADDR_ZIP4, EGHP_IND, PBP_ID, PLAN_ID, TOT_UNCOV_MONTHS, PREMIUM_WHOLD_OPT,")
					.append(" CREDITABLE_COV_IND,PRTD_OPTOUT_IND,ELECTION_TYPE,PRIOR_COMM_OVR, DISREASON_CD,SEC_RX_ID,")
					.append(" SEC_RX_BIN,SEC_RX_PCN,BIRTH_DATE,PRTC_PREMIUM_AMT,PRTD_PREMIUM_AMT,RX_BIN,RX_PCN,")
					.append(" RX_ID,LAST_UPDT_USERID FROM EM_TRANSACTION WHERE HIC_NBR IN")
					.append(" (SELECT DISTINCT DS_VALUE FROM EM_MBR_DSINFO WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? ")
					.append(" AND DS_CD IN ('MED','MBI')) AND PLAN_ID IN (SELECT DISTINCT PLAN_ID FROM SECPLAN WHERE MF_ID = ?)");

			Object[] parms = new Object[] { customerId, memberId, customerId };

			list = jdbcTemplate.query(squery.toString(), parms,
					new DomainPropertyRowMapper<EEMMbrAccretionDO>(EEMMbrAccretionDO.class));

		} catch (Exception exp) {
			throw new ApplicationException(exp);
		}
		return list;
	}

}
