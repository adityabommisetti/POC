package com.medicare.mss.dao;

import java.util.List;
import java.util.Map;

import com.medicare.mss.domainobject.EEMLetterReqDO;
import com.medicare.mss.domainobject.EEMLetterVarDataDO;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.vo.EEMApplTriggerLtrDataVO;
import com.medicare.mss.vo.EEMMbrTriggerLtrDataVO;
import com.medicare.mss.vo.PageableVO;

public interface EEMLetterRequestDAO {

	public PageableVO getLetterReqSearchResults(String customerId, Map<String, String> searchParamMap, boolean isPagination);

	public EEMLetterReqDO getletterReqLookup(String customerId, Map<String, String> searchParamMap);

	public List<LabelValuePair> getLetterList(String customerId, String planDesignation, String sourceType);

	public List<EEMLetterVarDataDO> getLetterDataEntry(String customerId, String letterName);

	public String getReasonCode(String customerId, String letterName);

	public int insertMbrTriggerLtrData(EEMMbrTriggerLtrDataVO trigData);

	public int insertApplTriggerLtrData(EEMApplTriggerLtrDataVO trigData);

	public int cancelledLetterReq(EEMLetterReqDO letterReqDO, String userId, String ts);

}
