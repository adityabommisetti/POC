package com.medicare.mss.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.caching.EEMPersistence;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMMbrDAO;
import com.medicare.mss.dao.EEMMbrLisDAO;
import com.medicare.mss.domainobject.EEMMbrLisInfoDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.EEMContext;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.NumberFormatter;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EEMMbrLisInfoVO;
import com.medicare.mss.vo.EMDatedSegmentVO;

@Service
public class EEMMbrLisService extends EEMMbrBaseService {

	@Autowired
	private EEMMbrLisDAO mbrLisDao;
	
	@Autowired
	private EEMMbrDAO mbrDao;
	
	@Autowired
	private EEMCodeCache codeCache;
	
	@Autowired
	private EEMPersistence eemPer;
	
	@SuppressWarnings("unchecked")
	@Transactional(rollbackOn = ApplicationException.class)
	public List<EEMMbrLisInfoVO> mbrLisInfoUpdate(EEMMbrLisInfoVO mbrLisVO)
			throws ApplicationException, ParseException, CloneNotSupportedException {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();
		
		List<EEMMbrLisInfoVO> mbrLisVOList = this.getListFromContext(mbrLisVO.getMemberId(), "N");

		List<EEMMbrLisInfoDO> mbrLisDOList = new ArrayList<>();
		mbrLisVOList.forEach(lisVO -> {
			EEMMbrLisInfoDO lisDO = new EEMMbrLisInfoDO();
			BeanUtils.copyProperties(lisVO, lisDO);
			mbrLisDOList.add(lisDO);
		});

		EEMMbrLisInfoDO newVO = new EEMMbrLisInfoDO();
		BeanUtils.copyProperties(mbrLisVO, newVO);

		newVO.setCustomerId(customerId);
		newVO.setLicBaeInd(StringUtil.YorN(newVO.getLicBaeInd()));
		newVO.setLisBaeInd(StringUtil.YorN(newVO.getLisBaeInd()));
		newVO.setOverrideInd("N");
		newVO.setLisAmt(NumberFormatter.formatDecimal2Places(newVO.getLisAmt()));
		newVO.setSpapAmt(NumberFormatter.formatDecimal2Places(newVO.getSpapAmt()));

		boolean rslt = this.mbrLisInfoUpdate(mbrLisDOList, newVO, userId);// TO -do

		if (rslt) {
			mbrLisVOList = getLisInfosLst(mbrLisVO.getMemberId(), mbrLisVO.getShowAll());
			if (StringUtils.equals(EEMConstants.VALUE_NO, mbrLisVO.getShowAll())) {
				setToContext(mbrLisVOList);
			} else {
				List<EEMMbrLisInfoVO> mbrLisActiveVOList = (List<EEMMbrLisInfoVO>) getActiveDatedList(mbrLisVOList);
				setToContext(mbrLisActiveVOList);
			}
		} else {
			throw new ApplicationException("LIS Update Failed");
		}

		return mbrLisVOList;

	}

	public void setToContext(List<EEMMbrLisInfoVO> mbrLisVOList) {
		EEMContext context = sessionHelper.getEEMContext();
		context.getMbrMasterVO().setMbrLisInfoList(mbrLisVOList);
		sessionHelper.setEEMContext(context);
	}

	public boolean mbrLisInfoUpdate(List<EEMMbrLisInfoDO> lisInfoLst, EEMMbrLisInfoDO newVO, String userId) throws ApplicationException, ParseException, CloneNotSupportedException{

		String ts = DateUtil.getCurrentDatetimeStamp();
		int sqlCnt = 0;
		Map<String, String> type = new HashMap<>();

		String message = checkDates(newVO);
		if (message != null) {
			throw new ApplicationException(message);
		}

		String maxLastUpdate = mbrDao.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
				EEMConstants.EM_MBR_LIS, type);
		if (hasDataChanged(lisInfoLst, maxLastUpdate)) {
			throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
		}

		EEMMbrLisInfoDO matchVO = null;

		// the update case
		matchVO = (EEMMbrLisInfoDO) matchDatedSegment(lisInfoLst, newVO);
		if (matchVO != null) {
			sqlCnt = mbrLisDao.setOverride(matchVO, userId);
			if (sqlCnt != 1) {
				throw new ApplicationException("Error Overriding Segment");
			}
			newVO.setCreateTime(ts);
			newVO.setCreateUserId(userId);
			newVO.setLastUpdtTime(ts);
			newVO.setLastUpdtUserId(userId);
			sqlCnt = mbrLisDao.insertMbr(newVO);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
			}
			maxLastUpdate = mbrDao.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(), EEMConstants.EM_MBR_LIS,
					type);
			if (hasDataChanged(ts, maxLastUpdate)) {
				throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
			}
			return true;
		}

		// the update end date case - no change in data
		matchVO = (EEMMbrLisInfoDO) matchDatedSegmentEndDate(lisInfoLst, newVO);
		if (matchVO != null) {
			sqlCnt = mbrLisDao.setOverride(matchVO, userId);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_OVERRIDING_SEGMENT);
			}
			newVO.setCreateTime(ts);
			newVO.setCreateUserId(userId);
			newVO.setLastUpdtTime(ts);
			newVO.setLastUpdtUserId(userId);
			sqlCnt = mbrLisDao.insertMbr(newVO);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
			}
			maxLastUpdate = mbrDao.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(), EEMConstants.EM_MBR_LIS,
					type);
			if (hasDataChanged(ts, maxLastUpdate)) {
				throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
			}
			return true;
		}

		if (newVO.getEffEndDate().equals("99999999")) {

			// logicly delete all above
			List<? extends EMDatedSegmentVO> lstSegmentsAbove = getSegmentsAbove(lisInfoLst, newVO.getEffStartDate());
			Iterator<? extends EMDatedSegmentVO> it = lstSegmentsAbove.iterator();
			while (it.hasNext()) {
				EEMMbrLisInfoDO itemVO = (EEMMbrLisInfoDO) it.next();
				sqlCnt = mbrLisDao.setOverride(itemVO, userId);
				if (sqlCnt != 1) {
					throw new ApplicationException("Error Overriding Segment Above");
				}
			}

			EEMMbrLisInfoDO belowVO = (EEMMbrLisInfoDO) getFirstOverlapSegmentBelow(lisInfoLst,
					newVO.getEffStartDate());
			if (belowVO != null) {

				sqlCnt = mbrLisDao.setOverride(belowVO, userId);
				if (sqlCnt != 1) {
					throw new ApplicationException("Error Overriding Segment Below");
				}
				// do we need to split the segmment below
				if (belowVO.getEffStartDate().compareTo(newVO.getEffStartDate()) < 0) {
					EEMMbrLisInfoDO tempVO = (EEMMbrLisInfoDO) belowVO.clone();
					tempVO.setEffEndDate(DateMath.minusOneDay(newVO.getEffStartDate()));
					tempVO.setCreateTime(ts);
					tempVO.setCreateUserId(userId);
					tempVO.setLastUpdtTime(ts);
					tempVO.setLastUpdtUserId(userId);
					sqlCnt = mbrLisDao.insertMbr(tempVO);
					if (sqlCnt != 1) {
						throw new ApplicationException("Error Spliting Segment Below");
					}
				}
			}

			// add the new segment
			newVO.setCreateTime(ts);
			newVO.setCreateUserId(userId);
			newVO.setLastUpdtTime(ts);
			newVO.setLastUpdtUserId(userId);
			sqlCnt = mbrLisDao.insertMbr(newVO);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
			}
			maxLastUpdate = mbrDao.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(), EEMConstants.EM_MBR_LIS,
					type);
			if (hasDataChanged(ts, maxLastUpdate)) {
				throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
			}
			return true;
			// end of open ended new segment processing
		}

		// end dated segment
		doDatedSegmentAdjust(lisInfoLst, newVO, ts, userId, mbrLisDao);

		// add the new segment
		newVO.setCreateTime(ts);
		newVO.setCreateUserId(userId);
		newVO.setLastUpdtTime(ts);
		newVO.setLastUpdtUserId(userId);
		sqlCnt = mbrLisDao.insertMbr(newVO);
		if (sqlCnt != 1) {
			throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
		}
		maxLastUpdate = mbrDao.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(), EEMConstants.EM_MBR_LIS,
				type);
		if (hasDataChanged(ts, maxLastUpdate)) {
			throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
		}
		return true;

	}

	@SuppressWarnings("unchecked")
	public List<EEMMbrLisInfoVO> mbrLisInfoDelete(EEMMbrLisInfoVO delVO) throws ApplicationException {
		String userId = sessionHelper.getUserInfo().getUserId();
		int sqlCnt = 0;
		List<EEMMbrLisInfoVO> mbrLisVOList = null;
		EEMMbrLisInfoDO lisDO = new EEMMbrLisInfoDO();
		BeanUtils.copyProperties(delVO, lisDO);
		sqlCnt = mbrLisDao.setOverride(lisDO, userId);
		if (sqlCnt == 1) {
			mbrLisVOList = getLisInfosLst(delVO.getMemberId(), delVO.getShowAll());
			if (StringUtils.equals(EEMConstants.VALUE_NO, delVO.getShowAll())) {
				setToContext(mbrLisVOList);
			} else {
				List<EEMMbrLisInfoVO> mbrLisActiveVOList = (List<EEMMbrLisInfoVO>) getActiveDatedList(mbrLisVOList);
				setToContext(mbrLisActiveVOList);
			}
		} else {
			throw new ApplicationException("LIS Delete Failed");
		}
		return mbrLisVOList;
	}

	public List<EEMMbrLisInfoVO> getLisInfosLst(String memberId, String showAll) throws ApplicationException {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		List<EEMMbrLisInfoDO> mbrLisDOList = mbrLisDao.getMbrLisInfos(customerId, memberId, showAll);
		List<EEMMbrLisInfoVO> mbrLisVOList = new ArrayList<>();
		mbrLisDOList.forEach(mbrLisDO -> {
			EEMMbrLisInfoVO mbrLisVO = new EEMMbrLisInfoVO();
			BeanUtils.copyProperties(mbrLisDO, mbrLisVO);
			try {
				mbrLisVO.setSubsidySourceDesc(StringUtil.nonNullTrim(
						codeCache.getDesc(mbrLisVO.getSubsidySourceInd(), eemPer.getLstSubsidySrce())));
				mbrLisVO.setLiCoPayDesc(StringUtil
						.nonNullTrim(codeCache.getDesc(mbrLisVO.getLiCoPayCd(), eemPer.getLstLiCopays())));
				}catch (ApplicationException e) {
					
				}
			mbrLisVOList.add(mbrLisVO);
		});

		return mbrLisVOList;
	}

	@SuppressWarnings("unchecked")
	public List<EEMMbrLisInfoVO> getListFromContext(String memberId, String showAll) throws ApplicationException {
		
		EEMContext context = sessionHelper.getEEMContext();
		List<EEMMbrLisInfoVO> mbrLisVOList = context.getMbrMasterVO().getMbrLisInfoList();
		
		if (StringUtils.equals(EEMConstants.VALUE_YES, showAll)) {
			List<EEMMbrLisInfoVO> allInfos = getLisInfosLst(memberId, showAll);
				mbrLisVOList = (List<EEMMbrLisInfoVO>) getActiveDatedList(allInfos);
				setToContext(mbrLisVOList);
			return allInfos;
		} else {
			if (Objects.isNull(mbrLisVOList)) {
				mbrLisVOList = getLisInfosLst(memberId, showAll);
				setToContext(mbrLisVOList);
			} else {
				mbrLisVOList = (List<EEMMbrLisInfoVO>) getActiveDatedList(mbrLisVOList);
				setToContext(mbrLisVOList);
			}
			return mbrLisVOList;
		}
	}

}
