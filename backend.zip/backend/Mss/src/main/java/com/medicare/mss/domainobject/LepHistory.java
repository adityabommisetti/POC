package com.medicare.mss.domainobject;

import java.io.Serializable;

import lombok.Data;

@Data
public class LepHistory implements Serializable {
	
	private static final long serialVersionUID = -7116162070124534910L;
	private String hicNbr;
	private String seqNbr;
	private String startDate;
	private String endDate;

}