package com.medicare.mss.vo;

import java.io.Serializable;

import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
public class EEMMbrAccretionVO implements Serializable, EMDatedSegmentVO {

	private static final long serialVersionUID = -3605181914533249269L;
	
	private String address1;
	private String address2;
	private String birthDate;
	private String city;
	private String createUserId;
	private String credCovflag;
	private String disEnrollReason;
	private String effectiveDate;
	private String eghpInd;
	private String electionType;
	private String pbpId;
	private String planId;
	private String premiumHoldOption;
	private String primBin;
	private String primeRxGrp;
	private String primPcn;
	private String primRxId;
	private String priorCommercialOvrInd;
	private String prtCAmt;
	private String prtDAmt;
	private String prtDOutInd;
	private String secBin;
	private String secPcn;
	private String secRxId;
	private String signdate;
	private String state;
	private String time;
	private String transactionType;
	private  String transCode;
	private String transDesc;
	private String uncoveredMonths;
	private String zip4;
	private String zip5;
	
	
	public String getBirthDateFrmt() {
		return DateFormatter.reFormat(birthDate,DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
	}
	public String getEffectiveDateFrmt() {
		return DateFormatter.reFormat(effectiveDate,DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
	}
	public String getSigndateFrmt() {
		return DateFormatter.reFormat(signdate,DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
	}
	@Override
	public String getEffEndDate() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getEffStartDate() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getLastUpdtTime() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getOverrideInd() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getType() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public boolean isEndDateChange(Object chkVO) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean isForSamePeriod(Object chkVO) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean isSame(Object chkVO) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public void setCreateTime(String ts) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void setEffEndDate(String effEndDate) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void setEffStartDate(String effStartDate) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void setLastUpdtTime(String ts) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void setLastUpdtUserId(String userId) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void setOverrideInd(String overrideInd) {
		// TODO Auto-generated method stub
		
	}
	
	public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
	
}
