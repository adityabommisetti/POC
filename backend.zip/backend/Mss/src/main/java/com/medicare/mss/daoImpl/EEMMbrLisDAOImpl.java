package com.medicare.mss.daoImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.medicare.mss.dao.EEMMbrLisDAO;
import com.medicare.mss.domainobject.EEMMbrLisInfoDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EMDatedSegmentVO;

@Repository
public class EEMMbrLisDAOImpl implements EEMMbrLisDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public int insertMbr(EMDatedSegmentVO mbrLisInfoVO) throws ApplicationException {

		EEMMbrLisInfoDO mbrLisInfo = (EEMMbrLisInfoDO) mbrLisInfoVO;

		try {
			String sql = CommonUtils.buildQuery("INSERT INTO EM_MBR_LIS(",
					"CUSTOMER_ID, MEMBER_ID, EFF_START_DATE, CREATE_TIME,", "EFF_END_DATE, OVERRIDE_IND,",
					"SUBSIDY_SOURCE_IND, LI_COPAY_CD, LIC_BAE_IND, LIS_PCT_CD, LIS_BAE_IND," + "LIS_AMT, SPAP_AMT,",
					"CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID", ") VALUES(", "?,?,?,?,?,?,?,?,?,?,",
					"?,?,?,?,?,?", ")");

			Object[] parms = new Object[] { mbrLisInfo.getCustomerId(), mbrLisInfo.getMemberId(),
					mbrLisInfo.getEffStartDate(), mbrLisInfo.getCreateTime(), mbrLisInfo.getEffEndDate(),
					mbrLisInfo.getOverrideInd(), mbrLisInfo.getSubsidySourceInd(), mbrLisInfo.getLiCoPayCd(),
					mbrLisInfo.getLicBaeInd(), mbrLisInfo.getLisPctCd(), mbrLisInfo.getLisBaeInd(),
					StringUtil.ensureDouble(mbrLisInfo.getLisAmt()), StringUtil.ensureDouble(mbrLisInfo.getSpapAmt()),
					mbrLisInfo.getCreateUserId(), mbrLisInfo.getLastUpdtTime(), mbrLisInfo.getLastUpdtUserId() };

			return jdbcTemplate.update(sql, parms);

		} catch (DataAccessException e) {
			throw new ApplicationException(e, "Error while insertMbrLisInfo");
		}
	}

	@Override
	public int setOverride(EMDatedSegmentVO mbrLisVO, String userId) throws ApplicationException {

		EEMMbrLisInfoDO mbrLis = (EEMMbrLisInfoDO) mbrLisVO;

		try {
			String sql = CommonUtils.buildQuery("UPDATE EM_MBR_LIS",
					" SET OVERRIDE_IND = 'Y', LAST_UPDT_TIME = ?, LAST_UPDT_USERID = ?",
					" WHERE CUSTOMER_ID = ? AND MEMBER_ID = ?", " AND EFF_START_DATE = ? AND CREATE_TIME = ?",
					" AND OVERRIDE_IND = 'N' AND LAST_UPDT_TIME = ?");

			Object[] parms = new Object[] { DateUtil.getCurrentDatetimeStamp(), userId, mbrLis.getCustomerId(),
					mbrLis.getMemberId(), mbrLis.getEffStartDate(), mbrLis.getCreateTime(), mbrLis.getLastUpdtTime() };
			return jdbcTemplate.update(sql, parms);
		} catch (DataAccessException e) {
			throw new ApplicationException(e, "Error while setLisInfoOverride");
		}

	}

	@Override
	public List<EEMMbrLisInfoDO> getMbrLisInfos(String customerId, String memberId, String showAll)
			throws ApplicationException {

		try {
			String sqlOverride = " AND OVERRIDE_IND = 'N'";
			if ("Y".equals(showAll))
				sqlOverride = "";

			String sql = CommonUtils.buildQuery("SELECT CUSTOMER_ID, MEMBER_ID, EFF_START_DATE, CREATE_TIME,",
					" EFF_END_DATE, OVERRIDE_IND,",
					" SUBSIDY_SOURCE_IND, LI_COPAY_CD, LIC_BAE_IND, LIS_PCT_CD, LIS_BAE_IND, LIS_AMT, SPAP_AMT,",
					" CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID" + " FROM EM_MBR_LIS",
					" WHERE CUSTOMER_ID = ? AND MEMBER_ID = ?" + sqlOverride,
					" ORDER BY EFF_START_DATE DESC, EFF_END_DATE DESC");
			return jdbcTemplate.query(sql, new DomainPropertyRowMapper<EEMMbrLisInfoDO>(EEMMbrLisInfoDO.class),
					customerId, memberId);
		} catch (DataAccessException e) {
			throw new ApplicationException(e, "Error while getMbrLisInfos");
		}

	}

}
