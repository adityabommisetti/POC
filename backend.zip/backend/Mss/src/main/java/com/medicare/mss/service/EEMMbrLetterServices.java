package com.medicare.mss.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.mss.dao.EEMMbrLetterDAO;
import com.medicare.mss.domainobject.EmCorrMbrDO;
import com.medicare.mss.domainobject.EmCorrVarDataDO;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EmCorrMbrVO;
import com.medicare.mss.vo.EmCorrVarDataVO;

@Service
public class EEMMbrLetterServices {

	@Autowired
	private EEMMbrLetterDAO mbrLetterDao;

	@Autowired
	private CacheService sessionHelper;

	public List<EmCorrVarDataVO> getMbrLetterVarDataList(Map<String, String> searchParamMap) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		searchParamMap.put("customerId", customerId);

		List<EmCorrVarDataVO> mbrLetterVarDataVOList = new ArrayList<>();

		List<EmCorrVarDataDO> mbrLetterVarDataList = mbrLetterDao.getMbrLetterData(searchParamMap);

		mbrLetterVarDataList.forEach(mbrLetterVarData -> {
			EmCorrVarDataVO emCorrMbrVO = new EmCorrVarDataVO();
			
			if (StringUtil.nonNullTrim(mbrLetterVarData.getVariableDesc()).isEmpty()) {
				mbrLetterVarData.setVariableDesc(mbrLetterVarData.getVariableId());
			}
			
			BeanUtils.copyProperties(mbrLetterVarData, emCorrMbrVO);
			mbrLetterVarDataVOList.add(emCorrMbrVO);
		});

		return mbrLetterVarDataVOList;

	}

	public List<EmCorrMbrVO> getMbrLettersList(String primaryId) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();

		List<EmCorrMbrVO> mbrLetterVOList = new ArrayList<>();

		List<EmCorrMbrDO> mbrLetterDOList = mbrLetterDao.getMbrLetterSelect(customerId, primaryId);
		mbrLetterDOList.forEach(mbrLetterSelect -> {
			EmCorrMbrVO mbrLetterVO = new EmCorrMbrVO();

			if (StringUtil.nonNullTrim(mbrLetterSelect.getDescription()).isEmpty()) {
				mbrLetterSelect.setDescription(mbrLetterSelect.getLetterName());
			}
			
			BeanUtils.copyProperties(mbrLetterSelect, mbrLetterVO);
			mbrLetterVOList.add(mbrLetterVO);
		});

		return mbrLetterVOList;
	}

	public byte[] getDisplayDocument(Map<String, String> searchParamMap) {

		byte[] blobByte = null;

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		searchParamMap.put("customerId", customerId);

		blobByte = mbrLetterDao.getDisplayDocumentFromDB(searchParamMap);

		return blobByte;
	}

}
