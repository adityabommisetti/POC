package com.medicare.mss.vo;

import lombok.Data;

@Data
public class DataBaseField {
	private String fieldName;
	private String stringValue;
	private String sign;
	
}