package com.medicare.mss.vo;

import lombok.Data;

@Data
public class EEMApplAddressVO {

	private int applId;
	private String authRepCity;
    private String authRepPhone;
    private String authRepState;
    private String authRepStreet;
    private String authRepZip4;
    private String authRepZip5;
    private String customerId;
    private String lstUpdtAuthAddr;
    private String lstUpdtMailAddr;
    private String lstUpdtPrimAddr;
    private String mailAdd1;
    private String mailAdd2;
    private String mailAdd3;
    private String mailCity;
    private String mailCountry;
    private String mailCounty;
    private String mailState;
    private String mailSuffix;
    private String mailZip4;
    private String mailZip5;
    private String perAdd1;
    private String perAdd2;
    private String perAdd3;
    private String perCell;
    private String perCity;
    private String perCounty;
    private String perFax;
    private String perPhone;
    private String perState;   
    private String perWorkPhone;
	private String perZip4;
	private String perZip5;
}
