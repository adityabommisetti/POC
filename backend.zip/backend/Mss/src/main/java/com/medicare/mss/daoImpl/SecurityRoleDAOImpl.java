package com.medicare.mss.daoImpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.medicare.mss.dao.SecurityRoleDAO;
import com.medicare.mss.domainobject.SecurityRoleDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.StringUtil;

@Repository
public class SecurityRoleDAOImpl implements SecurityRoleDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<SecurityRoleDO> getRolesList(String customerId) {

		List<SecurityRoleDO> userRolesList = null;

		String sql = CommonUtils.buildQuery("SELECT GROUP_ID, GROUP_NAME FROM SECGROUP JOIN CUSTOMER CUS ON ",
				" CUS.CUST_NBR = SECGROUP.CUST_NBR  WHERE MF_ID=?");

		try {
			userRolesList = jdbcTemplate.query(sql, new DomainPropertyRowMapper<SecurityRoleDO>(SecurityRoleDO.class),
					customerId);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp);
		}

		return userRolesList;

	}

	@Override
	public List<SecurityRoleDO> getUserDetails(String customerId, String userId) {
		List<SecurityRoleDO> userDetails = null;
		String query = CommonUtils.buildQuery(
				"SELECT USER_ID, SECGROUP.GROUP_ID,SECGROUP.GROUP_NAME FROM ",
				"SECUSER JOIN SECGROUP ON SECGROUP.GROUP_ID=SECUSER.GROUP_ID ",
				"WHERE SECGROUP.MF_ID=? AND SECUSER.USER_ID<>? order by USER_ID");

		try {
			userDetails = jdbcTemplate.query(query, new DomainPropertyRowMapper<SecurityRoleDO>(SecurityRoleDO.class)
					, customerId, userId);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp);
		}
		return userDetails;

	}

	@Override
	public int getUpdateRole(String userId, String roleId) {
		int updatedInt = 0;
		String sqlRoleUpdate = "UPDATE SECUSER SET GROUP_ID=? WHERE USER_ID=?";
		try {
			updatedInt = jdbcTemplate.update(sqlRoleUpdate, roleId, userId);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp);
		}
		return updatedInt;
	}

	@Override
	public List<SecurityRoleDO> getRoleServices(String roleId, String customerNbr) {

		List<SecurityRoleDO> roleServicesList = null;

		String sql = CommonUtils.buildQuery(
				"SELECT SERVICE.SERVICE_ID,SERVICE.SERVICE_NAME FROM SECGROUP RIGHT OUTER JOIN SECGROUP_SERVICE ",
				" ON SECGROUP_SERVICE.GROUP_ID=SECGROUP.GROUP_ID RIGHT OUTER JOIN SERVICE ON SECGROUP_SERVICE.SERVICE_ID=SERVICE.SERVICE_ID ",
				" WHERE SECGROUP.GROUP_ID=? AND SERVICE.SERVICE_ID NOT IN (SELECT SERVICE_ID FROM SERVICE_CONTACT WHERE CUST_NBR=?)");

		try {
			roleServicesList = jdbcTemplate.query(sql, new DomainPropertyRowMapper<SecurityRoleDO>(SecurityRoleDO.class)
					, roleId, customerNbr);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp,"Error in fecthing the services");
		}
		return roleServicesList;

	}

	@Override
	public List<SecurityRoleDO> getEnabledServicesList(String roleId, String customerNbr) {

		List<SecurityRoleDO> enabledServicesList = null;

		String sql = CommonUtils.buildQuery("SELECT SERVICE.SERVICE_ID,SERVICE.SERVICE_NAME FROM ",
				"SECGROUP RIGHT OUTER JOIN SECGROUP_SERVICE ON SECGROUP_SERVICE.GROUP_ID=SECGROUP.GROUP_ID",
				"RIGHT OUTER JOIN SERVICE_CONTACT ON SERVICE_CONTACT.CUST_NBR=SECGROUP.CUST_NBR AND ",
				"SERVICE_CONTACT.SERVICE_ID=SECGROUP_SERVICE.SERVICE_ID RIGHT OUTER JOIN SERVICE ON",
				" SERVICE_CONTACT.SERVICE_ID=SERVICE.SERVICE_ID WHERE SECGROUP.GROUP_ID=? AND SECGROUP.CUST_NBR=?");

		try {

			enabledServicesList = jdbcTemplate.query(sql, new RowMapper<SecurityRoleDO>() {

				@Override
				public SecurityRoleDO mapRow(ResultSet resultSet, int rowNum) throws SQLException {
					SecurityRoleDO securityRoleDO = new SecurityRoleDO();
					securityRoleDO.setServiceId(StringUtil.nonNullTrim(resultSet.getString("SERVICE_ID")));
					securityRoleDO.setServiceName(StringUtil.nonNullTrim(resultSet.getString("SERVICE_NAME")));

					return securityRoleDO;

				}

			}, roleId, customerNbr);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp,"Error in fecthing the enabled services");
		}
		return enabledServicesList;

	}

	@Override
	public boolean addService(List<String> serviceId, String customerNbr, String userId) {

		int[] batchUpdate = null;
		boolean result = false;
		String sql = "INSERT INTO SERVICE_CONTACT(SERVICE_ID,CUST_NBR,CONTACT_USER_ID,CONTACT_USER_IND,TOORCC) values(?,?,?,'U','T')";

		try {
			batchUpdate = jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {

				public void setValues(PreparedStatement ps, int i) throws SQLException {
					ps.setString(1, serviceId.get(i));
					ps.setString(2, customerNbr);
					ps.setString(3, userId);
				}

				public int getBatchSize() {
					return serviceId.size();
				}

			});
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp,"error in adding the services");
		}

		if (serviceId.size() == batchUpdate.length) {
			result = true;
		}
		return result;
	}

	@Override
	public boolean removeService(List<String> serviceId, String customerNbr,String userId) {

		String sql = "DELETE FROM SERVICE_CONTACT WHERE SERVICE_ID=? AND CUST_NBR=? AND CONTACT_USER_ID =?";
		boolean result = false;
		int[] batchUpdate = null;

		try {
			batchUpdate = jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {

				public void setValues(PreparedStatement ps, int i) throws SQLException {
					ps.setString(1, serviceId.get(i));
					ps.setString(2, customerNbr);
					ps.setString(3, userId);
				}

				public int getBatchSize() {
					return serviceId.size();
				}

			});
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp,"error in Deleting the services");
		}
		if (serviceId.size() == batchUpdate.length) {
			result = true;
		}

		return result;
	}

}