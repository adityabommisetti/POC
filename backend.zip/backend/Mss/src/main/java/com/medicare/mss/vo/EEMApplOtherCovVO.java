package com.medicare.mss.vo;

import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
public class EEMApplOtherCovVO {

	private String esrd;
	private String pcoInd;
	private String dialysis;
	private String stMedicaid;
	private String spouseWork;
	private String secRxInd;
	private String covId;
	private String otherCov;
	private String groupNo;
	private String ltcInstInd;
	private String nameInstitute;
	private String nameInstituteDes;
	private String ltcFacPhone;
	private String ltcFacAddress;
	private String lastUpdtTime;
	private String covBin;
	private String covPcn;
	private String medicaidId;
	// private String drugCov;//secRxInd
	private String customerId;
	private int applicationId;
	private String effStartDate;
	private String effEndDate;

	public String getEffStartDateFrmt() {
		return DateFormatter.reFormat(effStartDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setEffStartDateFrmt(String effStartDate) {
		this.effStartDate = DateFormatter.reFormat(effStartDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getEffEndDateFrmt() {
		return DateFormatter.reFormat(effEndDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setEffEndDateFrmt(String effEndDate) {
		this.effEndDate = DateFormatter.reFormat(effEndDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

}
