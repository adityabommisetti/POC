package com.medicare.mss.vo;

import java.io.Serializable;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode(callSuper = false)
public class EEMMbrBillingVO extends BaseVO implements EMDatedSegmentVO, Cloneable, Serializable {

	private static final long serialVersionUID = 2106312218499613792L;

	private String memberId;
	private String billLastName;
	private String billFirstName;
	private String billMiddleInit;
	private String billSuffix;
	private String billPayMethod;
	private String billPayMethodDesc;
	private String abaRoutingNbr;
	private String bankAcctNbr;
	private String bankName;
	private String accountType;
	private String accountTypeDesc;
	private String nameOnAct;
	private String draftDay;
	private String draftOverrideAmt;
	private String billFrequency;
	private String billFrequencyDesc;

	private String overrideInd;
	private String effStartDate;
	private String effEndDate;

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	@Override
	public String getType() {
		return "";
	}

	public String getEffEndDateFrmt() {
		return DateFormatter.reFormat(effEndDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setEffEndDateFrmt(String effEndDate) {
		this.effEndDate = DateFormatter.reFormat(effEndDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getEffStartDateFrmt() {
		return DateFormatter.reFormat(effStartDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setEffStartDateFrmt(String effStartDate) {
		this.effStartDate = DateFormatter.reFormat(effStartDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	@Override
	public boolean isEndDateChange(Object obj) {

		EEMMbrBillingVO chkVO = (EEMMbrBillingVO) obj;

		return StringUtils.equals(chkVO.getEffStartDate(), this.effStartDate)
				&& StringUtils.equals(chkVO.getMemberId(), this.memberId)
				&& StringUtils.equals(chkVO.getCustomerId(), this.customerId)
				&& StringUtils.equals(chkVO.getOverrideInd(), this.overrideInd);
	}

	@Override
	public boolean isForSamePeriod(Object obj) {

		EEMMbrBillingVO chkVO = (EEMMbrBillingVO) obj;

		return StringUtils.equals(chkVO.getEffStartDate(), this.effStartDate)
				&& StringUtils.equals(chkVO.getEffEndDate(), this.effEndDate)
				&& StringUtils.equals(chkVO.getMemberId(), this.memberId)
				&& StringUtils.equals(chkVO.getCustomerId(), this.customerId)
				&& StringUtils.equals(chkVO.getOverrideInd(), this.overrideInd);
	}

	@Override
	public boolean isSame(Object obj) {

		EEMMbrBillingVO chkVO = (EEMMbrBillingVO) obj;

		return StringUtils.equals(chkVO.getBillPayMethod(), this.billPayMethod)
				&& StringUtils.equals(chkVO.getBillFirstName(), this.billFirstName)
				&& StringUtils.equals(chkVO.getBillLastName(), this.billLastName)
				&& StringUtils.equals(chkVO.getBillMiddleInit(), this.billMiddleInit)
				&& StringUtils.equals(chkVO.getEffStartDate(), this.effStartDate)
				&& StringUtils.equals(chkVO.getDraftDay(), this.draftDay)
				&& StringUtils.equals(chkVO.getDraftOverrideAmt(), this.draftOverrideAmt)
				&& StringUtils.equals(chkVO.getNameOnAct(), this.nameOnAct)
				&& StringUtils.equals(chkVO.getAccountType(), this.accountType)
				&& StringUtils.equals(chkVO.getAbaRoutingNbr(), this.abaRoutingNbr)
				&& StringUtils.equals(chkVO.getBankAcctNbr(), this.bankAcctNbr)
				&& StringUtils.equals(chkVO.getEffEndDate(), this.effEndDate)
				&& StringUtils.equals(chkVO.getMemberId(), this.memberId)
				&& StringUtils.equals(chkVO.getCustomerId(), this.customerId)
				&& StringUtils.equals(chkVO.getOverrideInd(), this.overrideInd)
				&& StringUtils.equals(chkVO.getCreateTime(), this.createTime)
				&& StringUtils.equals(chkVO.getCreateUserId(), this.createUserId)
				&& StringUtils.equals(chkVO.getLastUpdtTime(), this.lastUpdtTime)
				&& StringUtils.equals(chkVO.getLastUpdtUserId(), this.lastUpdtUserId);
	}

}
