package com.medicare.mss.domainobject;

import java.io.Serializable;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMApplOtherCovDO implements Serializable {

	private static final long serialVersionUID = 1921355766869496673L;

	@ColumnMapper(columnName = "ESRD_IND", propertyName = "esrd")
	private String esrd;

	@ColumnMapper(columnName = "PCO_IND", propertyName = "pcoInd")
	private String pcoInd;

	@ColumnMapper(columnName = "DIALYSIS_IND", propertyName = "dialysis")
	private String dialysis;

	@ColumnMapper(columnName = "MEDICAID_IND", propertyName = "stMedicaid")
	private String stMedicaid;

	@ColumnMapper(columnName = "SPOUSE_WORK_IND", propertyName = "spouseWork")
	private String spouseWork;

	@ColumnMapper(columnName = "SEC_RX_IND", propertyName = "secRxInd")
	private String secRxInd;

	@ColumnMapper(columnName = "SEC_RX_ID", propertyName = "covId")
	private String covId;

	@ColumnMapper(columnName = "SEC_RX_NAME", propertyName = "otherCov")
	private String otherCov;

	@ColumnMapper(columnName = "SEC_RX_GRP", propertyName = "groupNo")
	private String groupNo;

	@ColumnMapper(columnName = "LTC_INST_IND", propertyName = "ltcInstInd")
	private String ltcInstInd;

	@ColumnMapper(columnName = "LTC_FAC_ID", propertyName = "nameInstitute")
	private String nameInstitute;

	@ColumnMapper(columnName = "LTC_FAC_NAME", propertyName = "nameInstituteDes")
	private String nameInstituteDes;

	@ColumnMapper(columnName = "LTC_FAC_PHONE", propertyName = "ltcFacPhone")
	private String ltcFacPhone;

	@ColumnMapper(columnName = "LTC_FAC_ADDRESS", propertyName = "ltcFacAddress")
	private String ltcFacAddress;

	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;

	@ColumnMapper(columnName = "SEC_RX_BIN", propertyName = "covBin")
	private String covBin;

	@ColumnMapper(columnName = "SEC_RX_PCN", propertyName = "covPcn")
	private String covPcn;

	@ColumnMapper(columnName = "MEDICAID_ID", propertyName = "medicaidId")
	private String medicaidId;

	@ColumnMapper(columnName = "EFFECTIVE_DATE", propertyName = "effStartDate")
	private String effStartDate;

	@ColumnMapper(columnName = "EFF_END_DATE", propertyName = "effEndDate")
	private String effEndDate;

	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;

	@ColumnMapper(columnName = "APPLICATION_ID", propertyName = "applicationId")
	private int applicationId;

}
