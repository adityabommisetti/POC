package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMDashboardSpclStatDisDO {
	@ColumnMapper(columnName = "NAME", propertyName = "statusName")
	private String statusName;
	@ColumnMapper(columnName = "COUNT", propertyName = "count")
	private String count;
}
