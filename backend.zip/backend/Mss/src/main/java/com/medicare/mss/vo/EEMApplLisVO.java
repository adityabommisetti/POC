package com.medicare.mss.vo;

import lombok.Data;

@Data
public class EEMApplLisVO {

	private String effEndDt;
	private String effStartDt;
	private String liCoPayCd;
	private String lisPctCd;

}
