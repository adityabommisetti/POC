
package com.medicare.mss.util;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;

final public class DateFormatter {

	private static final String CANNOT_BE_EARLIER_THAN_THE_CURRENT_DATE = " cannot be earlier than the current date";
	public static final int MM_YYYY = 1;
	public static final int YYYYMM = 2;
	public static final int YYYYMMDD = 3;
	public static final int MM_DD_YYYY = 4;
	public static final int DB2_TIMESTAMP = 5;
	public static final int SQL_TIMESTAMP = 6;
	public static final int MMYYYY = 7;

	public static final int YYYY_MM_DD_HH_MM_SS = 8;
	public static final int YYYYMMDDHHMMSSFF = 9;
	public static final int MM_DD_YYYY_HH_MM_SS = 10;
	public static final int YYMMDD = 11;
	public static final int DDMMMYYYY = 12;
	public static final int YYYY_MM_DD = 13;
	public static final int YYYY_MM_DD_HH_MM = 14;
	public static final int MM_DD_YYYY_HH_MM = 15;
	public static final int MMYYYYDD = 16;
	public static final int MM_DD_YYYY_HH_MM_SS_FF = 17;

	public static final int ASSUME_END = 1;
	public static final int ASSUME_START = 2;
	
	public static final Map<String, String> MONTH_NAMES = new HashMap<>();
	
	static {
		MONTH_NAMES.put("1", "Jan");
		MONTH_NAMES.put("2", "Feb");
		MONTH_NAMES.put("3", "Mar");
		MONTH_NAMES.put("4", "Apr");
		MONTH_NAMES.put("5", "May");
		MONTH_NAMES.put("6", "Jun");
		MONTH_NAMES.put("7", "Jul");
		MONTH_NAMES.put("8", "Aug");
		MONTH_NAMES.put("9", "Sep");
		MONTH_NAMES.put("10", "Oct");
		MONTH_NAMES.put("11", "Nov");
		MONTH_NAMES.put("12", "Dec");
	}

	/** Creates a new instance of DateFormatter */
	private DateFormatter() {
	}

	public static String dateFilter(String dte) {
		if (dte != null && (dte.equals("00000000") || dte.equals("XXXXXXXX") || dte.equals("99999999"))) {
			return "";
		}
		return dte;
	}

	public static String reFormatFiltered(String dte, int inFrmt, int outFrmt) {
		return reFormat(dateFilter(dte), inFrmt, outFrmt, ASSUME_START);
	}

	public static String reFormat(String dte, int inFrmt, int outFrmt) {
		return reFormat(dte, inFrmt, outFrmt, ASSUME_START);
	}

	public static String reFormat(String dte, int inFrmt, int outFrmt, int startOrEnd) {
		String outDte = null;
		String y = null;
		String m = null;
		String d = null;
		String hh = null;
		String mm = null;
		String ss = null;
		String ff = null;
		
		try {
			if(StringUtils.isBlank(dte)) {
				return dte;
			}

			switch (inFrmt) {
			
			case MM_YYYY:
				m = dte.substring(0, 2);
				y = dte.substring(3, 7);
				break;
			case YYYYMM:
				y = dte.substring(0, 4);
				m = dte.substring(4, 6);
				break;
			case MMYYYY:
				m = dte.substring(0, 2);
				y = dte.substring(2, 6);
				break;
			case MM_DD_YYYY:
				m = dte.substring(0, 2);
				d = dte.substring(3, 5);
				y = dte.substring(6, 10);
				break;
			case YYYYMMDD:
				y = dte.substring(0, 4);
				m = dte.substring(4, 6);
				d = dte.substring(6, 8);
				break;
			case DB2_TIMESTAMP:
			case SQL_TIMESTAMP:
				y = dte.substring(0, 4);
				m = dte.substring(5, 7);
				d = dte.substring(8, 10);
				hh = dte.substring(11, 13);
				mm = dte.substring(14, 16);
				ss = dte.substring(17, 19);
				ff = dte.substring(20);
				break;
			case YYYY_MM_DD_HH_MM_SS:
				y = dte.substring(0, 4);
				m = dte.substring(5, 7);
				d = dte.substring(8, 10);
				hh = dte.substring(11, 13);
				mm = dte.substring(14, 16);
				ss = dte.substring(17, 19);
				break;
			case YYYYMMDDHHMMSSFF:
				y = dte.substring(0, 4);
				m = dte.substring(4, 6);
				d = dte.substring(6, 8);
				hh = dte.substring(8, 10);
				mm = dte.substring(10, 12);
				ss = dte.substring(12, 14);
				ff = dte.substring(14);
				break;
			case MM_DD_YYYY_HH_MM_SS:
				m = dte.substring(0, 2);
				d = dte.substring(3, 5);
				y = dte.substring(6, 10);
				hh = dte.substring(11, 13);
				mm = dte.substring(14, 16);
				ss = dte.substring(17, 19);
				break;
			case YYMMDD:
				y = "20" + dte.substring(0, 2);
				m = dte.substring(2, 4);
				d = dte.substring(4, 6);
				break;
			case YYYY_MM_DD:
				y = dte.substring(0, 4);
				m = dte.substring(5, 7);
				d = dte.substring(8, 10);
				break;
			case YYYY_MM_DD_HH_MM:
				y = dte.substring(0, 4);
				m = dte.substring(5, 7);
				d = dte.substring(8, 10);
				hh = dte.substring(11, 13);
				mm = dte.substring(14, 16);
				break;
			case MM_DD_YYYY_HH_MM:
				m = dte.substring(0, 2);
				d = dte.substring(3, 5);
				y = dte.substring(6, 10);
				hh = dte.substring(11, 13);
				mm = dte.substring(14, 16);
				break;
			case MMYYYYDD:
				m = dte.substring(0, 2);
				y = dte.substring(2, 6);
				d = dte.substring(6, 8);
				break;
			case MM_DD_YYYY_HH_MM_SS_FF:
				m = dte.substring(0, 2);
				d = dte.substring(3, 5);
				y = dte.substring(6, 10);
				hh = dte.substring(11, 13);
				mm = dte.substring(14, 16);
				ss = dte.substring(17, 19);
				ff = dte.substring(20);
				break;
			default:
				if (startOrEnd == ASSUME_START) {
					d = "01";
					hh = "00";
					mm = "00";
					ss = "00";
					ff = "000000";
				} else {
					d = lastDOM(m, y);
					hh = "23";
					mm = "59";
					ss = "59";
					ff = "999999";
				}
			}
			
			if (!(outFrmt == MM_YYYY || outFrmt == YYYYMM || outFrmt == MMYYYY)) {

				if (startOrEnd == ASSUME_START) {
	                if (d == null) d = "01";
	                if (hh == null) hh = "00";
	                if (mm == null) mm = "00";
	                if (ss == null) ss = "00";
	                if (ff == null) ff = "000000";
	            } else {
	                if (d == null) d = lastDOM(m,y);
	                if (hh == null) hh = "23";
	                if (mm == null) mm = "59";
	                if (ss == null) ss = "59";
	                if (ff == null) ff = "999999";
	            }
			}
			switch (outFrmt) {
			
			case MM_YYYY:
				outDte = m + "/" + y;
				break;
			case YYYYMM:
				outDte = y + m;
				break;
			case MMYYYY:
				outDte = m + y;
				break;
			case MM_DD_YYYY:
				outDte = m + "/" + d + "/" + y;
				break;
			case YYYYMMDD:
				outDte = y + m + d;
				break;
			case DB2_TIMESTAMP:
				outDte = y + "-" + m + "-" + d + "-" + hh + "." + mm + "." + ss + "." + ff;
				break;
			case SQL_TIMESTAMP:
				outDte = y + "-" + m + "-" + d + " " + hh + ":" + mm + ":" + ss + "." + ff;
				break;
			case YYYY_MM_DD_HH_MM_SS:
				outDte = y + "-" + m + "-" + d + " " + hh + ":" + mm + ":" + ss;
				break;
			case YYYYMMDDHHMMSSFF:
				outDte = y + m + d + hh + mm + ss + ff;
				break;
			case MM_DD_YYYY_HH_MM_SS:
				outDte = m + "-" + d + "-" + y + " " + hh + ":" + mm + ":" + ss;
				break;
			case YYMMDD:
				if (Objects.nonNull(y)) {
					outDte = y.substring(2) + m + d;
				}
				break;
			case YYYY_MM_DD:
				outDte = y + "/" + m + "/" + d;
				break;
			case YYYY_MM_DD_HH_MM:
				outDte = y + "-" + m + "-" + d + " " + hh + ":" + mm;
				break;
			case MM_DD_YYYY_HH_MM:
				outDte = m + "-" + d + "-" + y + " " + hh + ":" + mm;
				break;
			case DDMMMYYYY:
				m = MONTH_NAMES.get(m);
				outDte = d + " " + m + " " + y;
				break;
			// fix for IFOX-00401383 start
			case MM_DD_YYYY_HH_MM_SS_FF:
				outDte = m + "-" + d + "-" + y + " " + hh + ":" + mm + ":" + ss + "." + ff;
				break;
			// fix for IFOX-00401383 end
			default:
				return outDte;
			}
			return outDte;
		} catch (Exception e) {
			return dte;
		}
	}

	public static String lastDOM(String mth, String yr) {

		int m = Integer.parseInt(mth, 10);
		if ((m == 4) || (m == 6) || (m == 9) || (m == 11))
			return "30";
		if (m == 2) {
			int y = Integer.parseInt(yr);
			if ((((y % 4) == 0) && ((y % 100) != 0)) || ((y % 400) == 0))
				return "29";
			return "28";
		}
		return "31";
	}

	public static String checkPastDate(String activeDate, String currentDate) {
		int mthActiveDate;
		int mthCurrentDate;
		int dayActiveDate;
		int dayCurrentDate;
		int yearActiveDate;
		int yearCurrentDate;
		String msg = "Activation Date";

		mthActiveDate = Integer.parseInt(activeDate.substring(4, 6));
		mthCurrentDate = Integer.parseInt(currentDate.substring(4, 6));
		dayActiveDate = Integer.parseInt(activeDate.substring(6, 8));
		dayCurrentDate = Integer.parseInt(currentDate.substring(6, 8));
		yearActiveDate = Integer.parseInt(activeDate.substring(0, 4));
		yearCurrentDate = Integer.parseInt(currentDate.substring(0, 4));

		if (yearActiveDate < yearCurrentDate) {
			return CommonUtils.appendStrings(msg, CANNOT_BE_EARLIER_THAN_THE_CURRENT_DATE);

		} else {
			if (yearActiveDate == yearCurrentDate) {
				if (mthActiveDate < mthCurrentDate) {
					return CommonUtils.appendStrings(msg, CANNOT_BE_EARLIER_THAN_THE_CURRENT_DATE);

				}

				else {
					if (mthActiveDate == mthCurrentDate) {
						if (dayActiveDate < dayCurrentDate) {
							return CommonUtils.appendStrings(msg, CANNOT_BE_EARLIER_THAN_THE_CURRENT_DATE);
						} else {
							return " ";
						}
					}
				}
			}
		}
		return " ";
	}

}
