package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMApplAddressDO {

	@ColumnMapper(columnName = "ADDRESS1", propertyName = "address1")
	private String address1;
	
	@ColumnMapper(columnName = "ADDRESS2", propertyName = "address2")
	private String address2;
	
	@ColumnMapper(columnName = "ADDRESS3", propertyName = "address3")
	private String address3;
	
	@ColumnMapper(columnName = "ADDRESS_TYPE", propertyName = "addressType")
	private String addressType;
	
	@ColumnMapper(columnName = "APPLICATION_ID", propertyName = "applId")
	private int applId;
	
	@ColumnMapper(columnName = "CELL_PHONE_NBR", propertyName = "cellPhoneNbr")
	private String cellPhoneNbr;
	
	@ColumnMapper(columnName = "CITY", propertyName = "city")
	private String city;
	
	@ColumnMapper(columnName = "COUNTRY_CD", propertyName = "countryCd")
	private String countryCd;
	
	@ColumnMapper(columnName = "COUNTY_CD", propertyName = "countyCd")
	private String countyCd;
	
	private String createTime;
		
	private String createUserId;
	
	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;
	
	@ColumnMapper(columnName = "FAX_NBR", propertyName = "faxNbr")
	private String faxNbr;
	
	@ColumnMapper(columnName = "HOME_PHONE_NBR", propertyName = "homePhoneNbr")
	private String homePhoneNbr;
	
	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;
	
	private String lastUpdtUserId;
	
	@ColumnMapper(columnName = "STATE_CD", propertyName = "stateCd")
	private String stateCd;
	
	@ColumnMapper(columnName = "WORK_PHONE_NBR", propertyName = "workPhoneNbr")
	private String workPhoneNbr;
	
	private String zip4Cd;
	
	@ColumnMapper(columnName = "ZIP_CD", propertyName = "zipCd")
	private String zipCd;
}
