package com.medicare.mss.controller;

import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.service.EEMLetterRequestService;
import com.medicare.mss.vo.EEMLetterReqCloseReqVO;
import com.medicare.mss.vo.EEMLetterReqMasterVO;
import com.medicare.mss.vo.EEMLetterReqVO;
import com.medicare.mss.vo.PageableVO;

@RestController
@RequestMapping("/letter")
public class EEMLetterRequestController {

	@Autowired
	EEMLetterRequestService letterRequestService;

	@PostMapping(ReqMappingConstants.LETTER_REQ_SEARCH)
	public ResponseEntity<JSONResponse> letterSearch(@RequestBody Map<String, String> searchParamMap) {

		EEMLetterReqMasterVO letterReqMasterVO = letterRequestService.getLetterSearchDetails(searchParamMap, false);
		return sendResponse(letterReqMasterVO);
	}

	@PostMapping(ReqMappingConstants.LETTER_REQ_SEARCH_NEXT)
	public ResponseEntity<JSONResponse> letterSearchPagination(@RequestBody Map<String, String> searchParamMap) {
		PageableVO pageableVO = letterRequestService.getLetterSearchDetailsPagination(searchParamMap, true);
		return sendResponse(pageableVO);
	}

	@PostMapping(ReqMappingConstants.LETTER_REQ_LOOKUP)
	public ResponseEntity<JSONResponse> letterReqLookup(@RequestBody Map<String, String> searchParamMap) {

		EEMLetterReqVO letterReqVO = letterRequestService.letterReqLookup(searchParamMap);
		return sendResponse(letterReqVO);
	}

	@PostMapping(ReqMappingConstants.LETTER_REQ_SELECT)
	public ResponseEntity<JSONResponse> letterSelect(@RequestBody Map<String, String> searchParamMap) {

		EEMLetterReqVO letterReqVO = letterRequestService.letterReqSelectLetter(searchParamMap);
		return sendResponse(letterReqVO);
	}

	@PostMapping(ReqMappingConstants.LETTER_REQ_CREATE)
	public ResponseEntity<JSONResponse> letterReqCreate(@RequestBody EEMLetterReqVO letterReqVO) {

		EEMLetterReqVO eemletterReqVO = letterRequestService.letterReqCreateLetter(letterReqVO);

		return sendResponse(eemletterReqVO);
	}

	@PostMapping(ReqMappingConstants.LETTER_REQ_CLOSE)
	public ResponseEntity<JSONResponse> closeLetters(@RequestBody EEMLetterReqCloseReqVO letterReqCloseReqVO) {

		EEMLetterReqMasterVO letterReqMasterVO = new EEMLetterReqMasterVO();
		Boolean result = letterRequestService.closeLetters(letterReqCloseReqVO.getLetterReqVOs());

		if (result) {
			Map<String, String> searchParamMap = new HashMap<>();
			searchParamMap.put("searchType", trimToEmpty(letterReqCloseReqVO.getSearchType()));
			searchParamMap.put("searchId", trimToEmpty(letterReqCloseReqVO.getSearchId()));
			searchParamMap.put("searchCreateDate", trimToEmpty(letterReqCloseReqVO.getSearchCreateDate()));
			searchParamMap.put("searchStatus", trimToEmpty(letterReqCloseReqVO.getSearchStatus()));
			letterReqMasterVO = letterRequestService.getLetterSearchDetails(searchParamMap, false);
		}
		return sendResponse(letterReqMasterVO);
	}

	private ResponseEntity<JSONResponse> sendResponse(Object object) {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;
		if (null == object) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			jsonResponse.setData(null);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
			jsonResponse.setMessage(EEMConstants.BLANK);
			jsonResponse.setData(object);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}

}
