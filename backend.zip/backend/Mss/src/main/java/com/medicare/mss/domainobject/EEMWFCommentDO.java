package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMWFCommentDO {

	
	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;
	
	@ColumnMapper(columnName = "COMMENT_SEQ_NBR", propertyName = "commentSeqNbr")
	private int commentSeqNbr;
	
	@ColumnMapper(columnName = "MBR_COMMENTS,APPL_COMMENTS", propertyName = "comments")
	private String comments;
	
	@ColumnMapper(columnName = "CREATE_TIME", propertyName = "createTime")
	private String createTime;
	
	@ColumnMapper(columnName = "CREATE_USERID", propertyName = "createUserId")
	private String createUserId;

	@ColumnMapper(columnName = "MEMBER_ID,APPLICATION_ID", propertyName = "primaryId")
	private String primaryId;
	
}
