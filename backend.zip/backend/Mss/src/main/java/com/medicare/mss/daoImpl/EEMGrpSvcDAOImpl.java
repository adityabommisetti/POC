package com.medicare.mss.daoImpl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMGrpSvcDAO;
import com.medicare.mss.domainobject.EEMApplProductDO;
import com.medicare.mss.domainobject.EEMGroupProductSearchDO;
import com.medicare.mss.domainobject.EEMGrpProductDO;
import com.medicare.mss.domainobject.EEMStateCountyZipDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.ApplProductRowMapper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.StringUtil;

@Repository
public class EEMGrpSvcDAOImpl implements EEMGrpSvcDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private EEMCodeCache codeCache;

	public void getStateCountyByZip(EEMStateCountyZipDO sczVO) throws ApplicationException {

		sczVO.setStateCd(null);
		sczVO.setCountyCd(null);
		sczVO.setStateAbbr(null);
		sczVO.setCountyName(null);

		try {

			Map<String, Object> queryForMap = getStateCountyResultSet(sczVO.getZip5(), sczVO.getZip4());
			sczVO.setStateCd(StringUtil.nonNullTrim((String) queryForMap.get("SSA_ST")));
			sczVO.setCountyCd(StringUtil.nonNullTrim((String) queryForMap.get("SSA_CNTY")));

		} catch (EmptyResultDataAccessException exp) {
			exp.getMessage();
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error getStateCountyByZip");
		}

	}

	@Override
	public EEMGrpProductDO getGroupProduct(String customerId, String groupId, String productId, String effDate)
			throws ApplicationException {
		try {
			String sql = CommonUtils.buildQuery(
					"SELECT CUSTOMER_ID, GRP_ID, PRODUCT_ID, GRP_PROD_START_DATE, GRP_PROD_END_DATE,",
					" PLAN_ID, PBP_ID, PBP_SEGMENT_ID, PLAN_DESIGNATION, RX_BIN, RX_PCN, RX_GROUP,",
					" PRTC_PREMIUM_AMT, PRTD_PREMIUM_AMT, SUPPL_PREMIUM_AMT, PREMIUM_REDUCTION_AMT,",
					" CSRREBATE_AMT, MSBREBATE_AMT, BPRREBATE_AMT, DSBREBATE_AMT, GROUPPROD_STATUS, OPT_OUT_IND,",
					" SPLIT_LIS_IND, RDS_WAIVER_IND, ESRD_WAIVER_IND, SNP_IND, EGHP_IND,",
					" EXTEND_MONTHS_CNT, DEFAULT_GRPPROD_IND, BILL_IND,",
					" FORGIVE_AMT, LAST_UPDT_TIME, LAST_UPDT_USERID FROM EM_GRP_PRODUCT",
					" WHERE CUSTOMER_ID = ? AND GRP_ID = ? AND PRODUCT_ID = ?");
			if (effDate != null)
				sql = CommonUtils.buildQuery(sql, " AND ? BETWEEN GRP_PROD_START_DATE AND GRP_PROD_END_DATE");
			sql = CommonUtils.buildQuery(sql, " ORDER BY GRP_PROD_START_DATE DESC FETCH FIRST 1 ROWS ONLY");

			Object[] parms = null;
			if (effDate != null)
				parms = new Object[] { customerId, groupId, productId, effDate };
			else
				parms = new Object[] { customerId, groupId, productId };

			return jdbcTemplate.query(sql, new ResultSetExtractor<EEMGrpProductDO>() {

				@Override
				public EEMGrpProductDO extractData(ResultSet rs) throws SQLException {
					EEMGrpProductDO grpPrdVO = new EEMGrpProductDO();
					if (rs.next()) {
						grpPrdVO.setCustomerId(StringUtil.nonNullTrim(rs.getString("CUSTOMER_ID")));
						grpPrdVO.setGrpId(StringUtil.nonNullTrim(rs.getString("GRP_ID")));
						grpPrdVO.setProductId(StringUtil.nonNullTrim(rs.getString("PRODUCT_ID")));
						grpPrdVO.setGrpProdStartDate(StringUtil.nonNullTrim(rs.getString("GRP_PROD_START_DATE")));
						grpPrdVO.setGrpProdEndDate(StringUtil.nonNullTrim(rs.getString("GRP_PROD_END_DATE")));
						grpPrdVO.setPlanId(StringUtil.nonNullTrim(rs.getString("PLAN_ID")));
						grpPrdVO.setPbpId(StringUtil.nonNullTrim(rs.getString("PBP_ID")));
						grpPrdVO.setPbpSegmentId(StringUtil.nonNullTrim(rs.getString("PBP_SEGMENT_ID")));
						grpPrdVO.setPlanDesignation(StringUtil.nonNullTrim(rs.getString("PLAN_DESIGNATION")));
						grpPrdVO.setRxBin(StringUtil.nonNullTrim(rs.getString("RX_BIN")));
						grpPrdVO.setRxPcn(StringUtil.nonNullTrim(rs.getString("RX_PCN")));
						grpPrdVO.setRxGroup(StringUtil.nonNullTrim(rs.getString("RX_GROUP")));
						grpPrdVO.setPrtCPremiumAmt(rs.getDouble("PRTC_PREMIUM_AMT"));
						grpPrdVO.setPrtDPremiumAmt(rs.getDouble("PRTD_PREMIUM_AMT"));
						grpPrdVO.setSupplPremiumAmt(rs.getDouble("SUPPL_PREMIUM_AMT"));
						grpPrdVO.setPremiumReductionAmt(rs.getDouble("PREMIUM_REDUCTION_AMT"));
						grpPrdVO.setCsrRebateAmt(rs.getDouble("CSRREBATE_AMT"));
						grpPrdVO.setMsbRebateAmt(rs.getDouble("MSBREBATE_AMT"));
						grpPrdVO.setBprRebateAmt(rs.getDouble("BPRREBATE_AMT"));
						grpPrdVO.setDsbRebateAmt(rs.getDouble("DSBREBATE_AMT"));
						grpPrdVO.setGroupProudStatus(StringUtil.nonNullTrim(rs.getString("GROUPPROD_STATUS")));
						grpPrdVO.setOptOutInd(StringUtil.nonNullTrim(rs.getString("OPT_OUT_IND")));
						grpPrdVO.setSplitLisInd(StringUtil.nonNullTrim(rs.getString("SPLIT_LIS_IND")));
						grpPrdVO.setRdsWaiverInd(StringUtil.nonNullTrim(rs.getString("RDS_WAIVER_IND")));
						grpPrdVO.setEsrdWaiverInd(StringUtil.nonNullTrim(rs.getString("ESRD_WAIVER_IND")));
						grpPrdVO.setSnpInd(StringUtil.nonNullTrim(rs.getString("SNP_IND")));
						grpPrdVO.setEghpInd(StringUtil.nonNullTrim(rs.getString("EGHP_IND")));
						grpPrdVO.setExtendMonthsCnt(rs.getInt("EXTEND_MONTHS_CNT"));
						grpPrdVO.setDefaultGrpProdInd(StringUtil.nonNullTrim(rs.getString("DEFAULT_GRPPROD_IND")));
						grpPrdVO.setBillInd(StringUtil.nonNullTrim(rs.getString("BILL_IND")));
						grpPrdVO.setForgiveAmt(rs.getDouble("FORGIVE_AMT"));
						grpPrdVO.setLastUpdtTime(StringUtil.nonNullTrim(rs.getString("LAST_UPDT_TIME")));
						grpPrdVO.setLastUpdtUserid(StringUtil.nonNullTrim(rs.getString("LAST_UPDT_USERID")));
					}
					return grpPrdVO;
				}
			}, parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error getGroupProduct");
		}
	}

	public String getPlanType(String custNbr, String planId, String pbpId) throws ApplicationException {
		String type;
		try {
			String sql = CommonUtils.buildQuery("SELECT PLAN_TYPE FROM PLANPBP",
					" WHERE CUST_NBR = ? AND PLAN_ID = ? AND PBP_ID = ? FETCH FIRST ROWS ONLY");

			type = jdbcTemplate.queryForObject(sql, new Object[] { custNbr, planId, pbpId }, String.class);

		} catch (EmptyResultDataAccessException exp) {
			type="";
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error getPlanType");
		}
		return StringUtil.nonNullTrim(type);
	}

	public List<EEMApplProductDO> searchGrpPrd(EEMGroupProductSearchDO gpSearch) throws ApplicationException {
		List<EEMApplProductDO> data = null;
		StringBuilder sql = new StringBuilder("");
		try {

			if (!gpSearch.getOutOfArea().equals("Y")) {

				if (gpSearch.getZipCd4().equals(""))
					gpSearch.setZipCd4("0000");

				if (!gpSearch.getZipCd5().isEmpty()
						&& (gpSearch.getSsaCnty().isEmpty() || gpSearch.getSsaState().isEmpty())) {
					getStateCounty(gpSearch);
				}
			}

			List<String> parms = new ArrayList<>();
			sql = new StringBuilder("SELECT DISTINCT GP.GRP_ID, GN.GROUP_NAME, GP.PRODUCT_ID, PN.PRODUCT_NAME,")
					.append(" GP.PLAN_ID, GP.PBP_ID, GP.PBP_SEGMENT_ID, GP.EGHP_IND, GP.PLAN_DESIGNATION,")
					.append(" SA.SRVC_AREA_ID, SA.SRVC_AREA_NAME, SAZ.SSA_ST, SAZ.SSA_CNTY,")
					.append(" SAZ.ZIP_CD5_LOW, SAZ.ZIP_CD4_LOW, SAZ.ZIP_CD5, SAZ.ZIP_CD4,")
					.append(" GP.PRTC_PREMIUM_AMT, GP.PRTD_PREMIUM_AMT, GP.SUPPL_PREMIUM_AMT,")
					.append(" GP.PREMIUM_REDUCTION_AMT, GP.DSBREBATE_AMT, GP.SNP_IND,GP.LINE_OF_BIZ")
					.append(" FROM EM_SVC_AREA_ZIP SAZ JOIN EM_GRP_PRODUCT_SVC_AREA GPSA")
					.append(" ON GPSA.CUSTOMER_ID = SAZ.CUSTOMER_ID")
					.append(" AND GPSA.SRVC_AREA_ID = SAZ.SRVC_AREA_ID JOIN EM_GRP_PRODUCT GP")
					.append(" ON GP.CUSTOMER_ID = GPSA.CUSTOMER_ID AND GP.GRP_ID = GPSA.GRP_ID")
					.append(" AND GP.PRODUCT_ID = GPSA.PRODUCT_ID JOIN EM_SVC_AREA SA")
					.append(" ON SA.CUSTOMER_ID = GPSA.CUSTOMER_ID AND SA.SRVC_AREA_ID = GPSA.SRVC_AREA_ID")
					.append(" JOIN EM_PRODUCT_NAME PN ON PN.CUSTOMER_ID = GP.CUSTOMER_ID")
					.append(" AND PN.PRODUCT_ID = GP.PRODUCT_ID JOIN EM_GRP_NAME GN")
					.append(" ON GN.CUSTOMER_ID = GP.CUSTOMER_ID AND GN.GRP_ID = GP.GRP_ID")
					.append(" WHERE SAZ.CUSTOMER_ID = ?")
					.append(" AND ? BETWEEN SAZ.ZIP_START_DATE AND SAZ.ZIP_END_DATE")
					.append(" AND ? BETWEEN GPSA.GPSVCAREA_START_DATE AND GPSA.GPSVCAREA_END_DATE")
					.append(" AND ? BETWEEN GP.GRP_PROD_START_DATE AND GP.GRP_PROD_END_DATE")
					.append(" AND ? BETWEEN SA.SVC_START_DATE AND SA.SVC_END_DATE")
					.append(" AND ? BETWEEN PN.PRODNAME_START_DATE AND PN.PRODNAME_END_DATE")
					.append(" AND ? BETWEEN GN.GRPNAME_START_DATE AND GN.GRPNAME_END_DATE");

			String effDate = gpSearch.getEffDate();

			parms.add(gpSearch.getCustomerId());
			parms.add(effDate);
			parms.add(effDate);
			parms.add(effDate);
			parms.add(effDate);
			parms.add(effDate);
			parms.add(effDate);

			if (!gpSearch.getZipCd5().isEmpty()) {
				sql.append(" AND (").append(" (SAZ.SSA_ST = ? AND SAZ.SSA_CNTY = 'XXX')").append(" OR")
						.append(" (SAZ.SSA_ST = ? AND SAZ.SSA_CNTY = ? AND SAZ.ZIP_CD5='XXXXX')").append(" OR")
						.append(" (? BETWEEN SAZ.ZIP_CD5_LOW AND SAZ.ZIP_CD5 AND ? BETWEEN SAZ.ZIP_CD4_LOW AND SAZ.ZIP_CD4)")
						.append(")");
				parms.add(gpSearch.getSsaState());
				parms.add(gpSearch.getSsaState());
				parms.add(gpSearch.getSsaCnty());
				parms.add(gpSearch.getZipCd5());
				parms.add(gpSearch.getZipCd4());
			}

			if (!gpSearch.getGroupName().isEmpty()) {
				sql.append(" AND GN.GROUP_NAME LIKE ?");
				parms.add(StringUtil.appendWildCardCharacter(gpSearch.getGroupName(), false, true));
			}
			if (!gpSearch.getGrpId().isEmpty()) {
				sql.append(" AND GP.GRP_ID = ? ");
				parms.add(gpSearch.getGrpId());
			}
			if (!gpSearch.getProductId().isEmpty()) {
				sql.append(" AND GP.PRODUCT_ID = ?");
				parms.add(gpSearch.getProductId());
			}

			if (!gpSearch.getProductName().isEmpty()) {
				sql.append(" AND PN.PRODUCT_NAME LIKE ?");
				parms.add(StringUtil.appendWildCardCharacter(gpSearch.getProductName(), false, true));
			}

			if (!gpSearch.getPbpId().isEmpty()) {
				sql.append(" AND GP.PLAN_ID = ?");
				parms.add(gpSearch.getPlanId());
			}

			if (!gpSearch.getPbpId().isEmpty()) {
				sql.append(" AND GP.PBP_ID = ?");
				parms.add(gpSearch.getPbpId());
			}

			if (!gpSearch.getPbpSegmentId().isEmpty()) {
				sql.append(" AND GP.PBP_SEGMENT_ID = ?");
				parms.add(gpSearch.getPbpSegmentId());
			}

			if (gpSearch.getApplType().equals(EEMConstants.OPTION_APPLNEWMBR_MA)
					|| gpSearch.getApplType().equals(EEMConstants.OPTION_CNTRCHG_MA)) {
				sql.append(" AND GP.PLAN_DESIGNATION IN ('MA','CO','MAPD','COPD','PACE','MMP')");
			} else if (gpSearch.getApplType().equals(EEMConstants.OPTION_APPLNEWMBR_PD)
					|| gpSearch.getApplType().equals(EEMConstants.OPTION_CNTRCHG_PD)) {
				sql.append(" AND GP.PLAN_DESIGNATION = 'PDP'");
			}

			data = jdbcTemplate.query(sql.toString(), new ApplProductRowMapper(codeCache), parms.toArray());
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp);
		}

		return data;
	}

	private void getStateCounty(EEMGroupProductSearchDO gpSearch) {
		try {
			Map<String, Object> queryForMap = getStateCountyResultSet(gpSearch.getZipCd5(), gpSearch.getZipCd4());
			gpSearch.setSsaState(StringUtil.nonNullTrim((String) queryForMap.get("SSA_ST")));
			gpSearch.setSsaCnty(StringUtil.nonNullTrim((String) queryForMap.get("SSA_CNTY")));
		} catch (EmptyResultDataAccessException exp) {
			exp.getMessage();
		}
	}

	private Map<String, Object> getStateCountyResultSet(String zip5, String zip4) {
		StringBuilder sql = new StringBuilder(" SELECT SSA_ST, SSA_CNTY ").append(" FROM EM_ZIPCODE")
				.append(" WHERE ZIP_CD5 = ? AND ZIP_CD4 in ('0000',?)")
				.append(" ORDER BY ZIP_CD4 DESC FETCH FIRST 1 ROWS ONLY");
		return jdbcTemplate.queryForMap(sql.toString(), zip5, zip4);
	}

}
