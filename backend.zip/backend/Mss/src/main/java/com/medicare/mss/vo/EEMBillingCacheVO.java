package com.medicare.mss.vo;

import java.util.List;
import java.util.Map;

import com.medicare.mss.util.LabelValuePair;

import lombok.Data;

@Data
public class EEMBillingCacheVO {
	
	//invoice cache
	private List<LabelValuePair> lstInvoiceStatus;
	private List<LabelValuePair> lstInvoiceGroup;
	private List<LabelValuePair> lstInvoiceType;
	private Map<String, List<LabelValuePair>> lstRelatedInvoiceType;
	
	//payment entry and member payment cache
	private List<LabelValuePair> payTypesList;
	
	//payment entry cache
	private String bankAcctCd;

	//draft cache
	List<LabelValuePair> draftStatusLst;
}
