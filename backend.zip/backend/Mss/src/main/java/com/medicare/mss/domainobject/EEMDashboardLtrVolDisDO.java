package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMDashboardLtrVolDisDO {
	@ColumnMapper(columnName = "CORR_LETTER_NAME", propertyName = "letterName")
	private String letterName;
	@ColumnMapper(columnName = "COUNT", propertyName = "count")
	private String count;
}
