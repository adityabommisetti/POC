/**
 * 
 */
package com.medicare.mss.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;

/**
 * @author DU20098149
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EEMBillingInvHeaderDtlsVO implements Serializable {

	private static final long serialVersionUID = -4280521360369087266L;

	private String adjustmentAmt;
	private String billThruDate;
	private String createTime;
	private String createUserId;
	private String customerId;
	private String displayInvType;
	private String dueDate;
	private String firstName;
	private String frequencyCd;
	private String frequencyDesc;
	private String glProcessedInd;
	private String hicNbr;
	private String invoiceAmt;
	private String invoiceId;
	private String invoiceNbr;
	private String invoiceStatus;
	private String invoiceStatusDesc;
	private String invoiceType;
	private String invoiceTypeDesc;
	private String lastItemNbr;
	private String lastName;
	private String lastUpdtTime;
	private String lastUpdtUserId;
	private String mbrGrpDesc;
	private String mbrGrpInd;
	private String memberCnt;
	private String name;
	private String paymentAmt;
	private String totalAmt;
	private String wipTime;
	private String wipUserId;

	public String getBillThruDateFrmt() {
		return DateFormatter.reFormat(billThruDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getDueDateFrmt() {
		return DateFormatter.reFormat(dueDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setBillThruDateFrmt(String billThruDate) {
		this.billThruDate = DateFormatter.reFormat(billThruDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public void setDueDateFrmt(String dueDate) {
		this.dueDate = DateFormatter.reFormat(dueDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}
}
