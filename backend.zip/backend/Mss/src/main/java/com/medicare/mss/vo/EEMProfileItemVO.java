package com.medicare.mss.vo;

import lombok.Data;

@Data
public class EEMProfileItemVO {

	private String effEndDate;
	private String effStartDate;
	private String profileCd;
	private double profileNumeric;
	private String profileText;
	private String profileValue;
	
	
}
