/**
 * 
 */
package com.medicare.mss.rowmappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.medicare.mss.domainobject.EEMOriginalApplDO;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.StringUtil;

/**
 * @author SUSDASH
 *
 */
public class EEMOrigApplRowMapper implements RowMapper<EEMOriginalApplDO> {

	private JdbcTemplate jdbcTemplate;
	
	public EEMOrigApplRowMapper(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate =jdbcTemplate;
	}

	@Override
	public EEMOriginalApplDO mapRow(ResultSet rs, int rowNum) throws SQLException {

		EEMOriginalApplDO applDO = new EEMOriginalApplDO();
		applDO.setApplId(rs.getInt("APPLICATION_ID"));
		applDO.setApplType(rs.getString("APPLICATION_TYPE"));
		applDO.setApplCategory(StringUtil.nonNullTrim(rs.getString("APPLICATION_CATEGORY")));
		applDO.setApplDate(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("APPLICATION_DATE"))));
		applDO.setMbrPrefix(StringUtil.nonNullTrim(rs.getString("PREFIX")));
		applDO.setMbrLastName(StringUtil.nonNullTrim(rs.getString("LAST_NAME")));
		applDO.setMbrFirstName(StringUtil.nonNullTrim(rs.getString("FIRST_NAME")));
		applDO.setMbrMiddleName(StringUtil.nonNullTrim(rs.getString("MIDDLE_INIT")));
		applDO.setMbrSuffix(StringUtil.nonNullTrim(rs.getString("SUFFIX")));
		applDO.setMbrHicNbr(StringUtil.nonNullTrim(rs.getString("HIC_NBR")));
		applDO.setMbrSsn(StringUtil.nonNullTrim(rs.getString("SSN")));
		applDO.setAltMbrId(StringUtil.nonNullTrim(rs.getString("SUPPLEMENTAL_ID")));
		applDO.setMbrRxId(StringUtil.nonNullTrim(rs.getString("RX_ID")));
		applDO.setPerPhone(StringUtil.nonNullTrim(rs.getString("PRIMARY_HOME_PHONE")));
		applDO.setPerWorkPhone(StringUtil.nonNullTrim(rs.getString("PRIMARY_WORK_PHONE")));
		applDO.setPerCell(StringUtil.nonNullTrim(rs.getString("PRIMARY_CELL_PHONE")));
		applDO.setPerFax(StringUtil.nonNullTrim(rs.getString("PRIMARY_FAX")));
		applDO.setPerAdd1(StringUtil.nonNullTrim(rs.getString("PRIMARY_ADDRESS1")));
		applDO.setPerAdd2(StringUtil.nonNullTrim(rs.getString("PRIMARY_ADDRESS2")));
		applDO.setPerAdd3(StringUtil.nonNullTrim(rs.getString("PRIMARY_ADDRESS3")));
		applDO.setPerCity(StringUtil.nonNullTrim(rs.getString("PRIMARY_CITY")));
		applDO.setPerState(StringUtil.nonNullTrim(rs.getString("PRIMARY_STATE")));
		applDO.setPerZip5(StringUtil.nonNullTrim(rs.getString("PRIMARY_ZIP")));
		applDO.setPerCounty(StringUtil.nonNullTrim(rs.getString("PRIMARY_COUNTY")));
		applDO.setMailLastName(StringUtil.nonNullTrim(rs.getString("MAIL_LAST_NAME")));
		applDO.setMailFirstName(StringUtil.nonNullTrim(rs.getString("MAIL_FIRST_NAME")));
		applDO.setMailMiddleName(StringUtil.nonNullTrim(rs.getString("MAIL_MIDDLE_INIT")));
		applDO.setMailSuffix(StringUtil.nonNullTrim(rs.getString("MAIL_SUFFIX")));
		applDO.setMailAdd1(StringUtil.nonNullTrim(rs.getString("MAIL_ADDRESS1")));
		applDO.setMailAdd2(StringUtil.nonNullTrim(rs.getString("MAIL_ADDRESS2")));
		applDO.setMailAdd3(StringUtil.nonNullTrim(rs.getString("MAIL_ADDRESS3")));
		applDO.setMailCity(StringUtil.nonNullTrim(rs.getString("MAIL_CITY")));
		applDO.setMailState(StringUtil.nonNullTrim(rs.getString("MAIL_STATE")));
		applDO.setMailZip5(StringUtil.nonNullTrim(rs.getString("MAIL_ZIP")));
		applDO.setReqDtCov(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("EFFECTIVE_DATE"))));
		applDO.setMailCounty(StringUtil.nonNullTrim(rs.getString("MAIL_CNTY")));
		applDO.setMailCountry(StringUtil.nonNullTrim(rs.getString("MAIL_COUNTRY")));
		applDO.setMbrEmail(StringUtil.nonNullTrim(rs.getString("PRIMARY_EMAIL")));
		applDO.setMbrBirthDt(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("BIRTH_DATE"))));
		applDO.setMbrGender(StringUtil.nonNullTrim(rs.getString("GENDER_CD")));
		
		applDO.setEnrollGrpId(StringUtil.nonNullTrim(rs.getString("ENROLL_GRP")));
		applDO.setEnrollProduct(StringUtil.nonNullTrim(rs.getString("ENROLL_PRDT")));
		applDO.setEnrollPlan(StringUtil.nonNullTrim(rs.getString("ENROLL_PLAN_ID")));
		applDO.setEnrollPbp(StringUtil.nonNullTrim(rs.getString("ENROLL_PBP_ID")));
		applDO.setEnrollSegment(StringUtil.nonNullTrim(rs.getString("ENROLL_SEG")));
		applDO.setEnrollPymtAmt(StringUtil.nonNullTrim(rs.getString("ENROLL_PAY_AMT")));
		applDO.setEnrollSrceCd(StringUtil.nonNullTrim(rs.getString("ENROLL_SRCE_CD")));
		
		applDO.setLanguage(StringUtil.nonNullTrim(rs.getString("LANGUAGE_CD")));
		applDO.setAltCorrespondenceInd(StringUtil.nonNullTrim(rs.getString("ALT_CORRES_IND")));
		
		applDO.setOfficeCd(StringUtil.nonNullTrim(rs.getString("PCP_CODE")));
		applDO.setLocationId(StringUtil.nonNullTrim(rs.getString("PCP_LOCATION_ID")));
		applDO.setCurrentPatientInd(StringUtil.nonNullTrim(rs.getString("CURRENT_PATIENT_IND")));
		applDO.setPwOption(StringUtil.nonNullTrim(rs.getString("PREMIUM_WITHHOLD_OPTION")));
		applDO.setEsrdInd(StringUtil.nonNullTrim(rs.getString("ESRD_IND")));
		applDO.setDialysisInd(StringUtil.nonNullTrim(rs.getString("DIALYSIS_IND")));
		applDO.setOtherCov(StringUtil.nonNullTrim(rs.getString("SEC_RX_NAME")));
		applDO.setCovId(StringUtil.nonNullTrim(rs.getString("SEC_RX_COV_ID")));
		applDO.setGroupNo(StringUtil.nonNullTrim(rs.getString("SEC_RX_GRP")));
		applDO.setCovBin(StringUtil.nonNullTrim(rs.getString("SEC_RX_BIN")));
		applDO.setCovPcn(StringUtil.nonNullTrim(rs.getString("SEC_RX_PCN")));
		applDO.setMedicaidInd(StringUtil.nonNullTrim(rs.getString("MEDICAID_IND")));
		applDO.setMedicaidId(StringUtil.nonNullTrim(rs.getString("MEDICAID_ID")));
		applDO.setSpouseWorkInd(StringUtil.nonNullTrim(rs.getString("SPOUSE_WORK_IND")));
		applDO.setOutOfArea(StringUtil.nonNullTrim(rs.getString("OOA_IND")));
		applDO.setElectionType(StringUtil.nonNullTrim(rs.getString("ELECTION_TYPE_CD")));
		applDO.setSepReason(StringUtil.nonNullTrim(rs.getString("SEP_REASON_CD")));
		applDO.setSignOnFile(StringUtil.nonNullTrim(rs.getString("SGN_ONFILE_IND")));
		applDO.setSignDt(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("SGN_DATE"))));
		applDO.setAuthRepLastName(StringUtil.nonNullTrim(rs.getString("AUTH_LAST_NAME")));
		applDO.setAuthRepFirstName(StringUtil.nonNullTrim(rs.getString("AUTH_FIRST_NAME")));
		applDO.setAuthRepMidName(StringUtil.nonNullTrim(rs.getString("AUTH_MIDDLE_INIT")));
		applDO.setAuthRepRelation(StringUtil.nonNullTrim(rs.getString("AUTH_RELATIONSHIP_CD")));
		applDO.setAuthRepStreet(StringUtil.nonNullTrim(rs.getString("AUTH_ADDRESS")));
		applDO.setAuthRepCity(StringUtil.nonNullTrim(rs.getString("AUTH_CITY")));
		applDO.setAuthRepState(StringUtil.nonNullTrim(rs.getString("AUTH_STATE")));
		applDO.setAuthRepZip5(StringUtil.nonNullTrim(rs.getString("AUTH_ZIP")));
		applDO.setAuthRepPhone(StringUtil.nonNullTrim(rs.getString("AUTH_PHONE")));
		applDO.setEmergName(StringUtil.nonNullTrim(rs.getString("EMERGCY_NAME")));
		applDO.setEmergPhone(StringUtil.nonNullTrim(rs.getString("EMERGCY_PHONE")));
		applDO.setEmergRelation(StringUtil.nonNullTrim(rs.getString("EMERGCY_RELATIONSHIP_CD")));
		applDO.setEmail(StringUtil.nonNullTrim(rs.getString("EMERGCY_EMAIL")));
		applDO.setInsCardName(StringUtil.nonNullTrim(rs.getString("INS_CARD_NAME")));
		applDO.setEditOverride(StringUtil.nonNullTrim(rs.getString("EDIT_OVERRIDE_IND")));
		applDO.setPartAEffDate(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("PARTA_EFFE_DATE"))));
		applDO.setPartBEffDate(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("PARTB_EFFE_DATE"))));
		applDO.setPartDEffDate(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("PARTD_EFFE_DATE"))));
		applDO.setPcpName(StringUtil.nonNullTrim(rs.getString("PCP_NAME")));
		applDO.setSepElectionDt(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("ELECTION_DATE"))));
		applDO.setPcoInd(StringUtil.nonNullTrim(rs.getString("PCO_IND")));
		applDO.setDrugCov(StringUtil.nonNullTrim(rs.getString("SEC_RX_IND")));
		applDO.setSecRxInd(StringUtil.nonNullTrim(rs.getString("SEC_RX_IND")));
		// System.out.println(rs.getString("AGENT_TYPE")+" "+rs.getString("AGENT_ID").trim()+" "+rs.getString("AGENT_NAME")+" "+rs.getString("AGENT_CREATE_TIME")+" "+rs.getString("COMMISSION_AGY_ORG"));
		applDO.setBrokerType(StringUtil.nonNullTrim(rs.getString("AGENT_TYPE")));
		//applDO.setAgentType(StringUtil.nonNullTrim(rs.getString("AGENT_TYPE")));
		String agentId=rs.getString("AGENT_ID").trim();
		/** Triple S BasePlus Migration START **/
		//applDO.setBrokAgentId(StringUtil.nonNullTrim(agentId.trim()+" - "+rs.getString("AGENT_NAME")));
		//applDO.setBrokerName(StringUtil.nonNullTrim(agentId.trim()+"-"+rs.getString("AGENT_NAME")));
		if(!StringUtil.nonNullTrim(agentId).equals("")){
			applDO.setBrokAgentId(StringUtil.nonNullTrim(agentId.trim()+" - "+rs.getString("AGENT_NAME")));
			//applDO.setBrokerName(StringUtil.nonNullTrim(agentId.trim()+" - "+rs.getString("AGENT_NAME")));				
		}
		else {
			applDO.setBrokAgentId(StringUtil.nonNullTrim(agentId.trim()+rs.getString("AGENT_NAME")));
			//applDO.setBrokerName(StringUtil.nonNullTrim(agentId.trim()+rs.getString("AGENT_NAME")));
		}
		/**  Triple S BasePlus Migration END **/
		applDO.setAgentDt(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("AGENT_CREATE_TIME"))));
		applDO.setCommAgencyId(StringUtil.nonNullTrim(rs.getString("COMMISSION_AGY_ORG")));
		//agencyId=rs.getString("COMMISSION_AGY_ORG").trim();
		applDO.setApplComments(StringUtil.nonNullTrim(rs.getString("APPL_COMMENTS")));	
		applDO.setCustomerId((StringUtil.nonNullTrim(rs.getString("CUSTOMER_ID"))));
		applDO.setAgentDt("");
			
		//ACH Banking fields  -START.
		applDO.setBillLastName(StringUtil.nonNullTrim(rs.getString("BILL_LAST_NAME")));
		applDO.setBillFirstName(StringUtil.nonNullTrim(rs.getString("BILL_FIRST_NAME")));
		applDO.setBillMiddleName(StringUtil.nonNullTrim(rs.getString("BILL_MIDDLE_INIT")));				
		applDO.setAchNameOnAct(StringUtil.nonNullTrim(rs.getString("NAME_ON_ACCT")));
		applDO.setAchAccountType(StringUtil.nonNullTrim(rs.getString("ACCOUNT_TYPE")));
		applDO.setAchAbaRoutingNbr(StringUtil.nonNullTrim(rs.getString("ABA_ROUTING_NBR")));
		applDO.setAchbankAcctNbr(StringUtil.nonNullTrim(rs.getString("BANK_ACCT_NBR")));
		applDO.setAchBillFrequency(StringUtil.nonNullTrim(rs.getString("BILL_FREQUENCY")));
		//ACH Banking fields - END.
		
		
		applDO.setCreateTime(StringUtil.nonNullTrim(rs.getString("CREATE_TIME")));
		applDO.setCreateUserId(StringUtil.nonNullTrim(rs.getString("CREATE_USERID")));
		applDO.setXrefNbr(StringUtil.nonNullTrim(rs.getString("XREF_CLAIM_NBR"))); // IFOX-00397126
		applDO.setHealthPlanNews(StringUtil.nonNullTrim(rs.getString("HEALTH_PLAN_NEWS_EMAIL")));
		
		String agencyId = "";
		try {
			agencyId = jdbcTemplate.queryForObject("SELECT AGENCY_ID FROM EM_AGENCY_AGENT WHERE CUSTOMER_ID= ? AND AGENT_ID= ?",
					new Object[] {applDO.getCustomerId(),agentId} ,String.class);
			
			if(!StringUtil.nonNullTrim(agencyId).equalsIgnoreCase("")) {
				String agent = jdbcTemplate.queryForObject("SELECT AGENCY_NAME FROM EM_AGENCY WHERE CUSTOMER_ID=? AND AGENCY_ID=?",
						new Object[] {applDO.getCustomerId(),agencyId} ,String.class);
				
				if(!StringUtil.nonNullTrim(agent).equalsIgnoreCase("")) {
					if(StringUtil.isNotNullNotEmptyNotWhiteSpace(applDO.getCommAgencyId()) && applDO.getCommAgencyId().equalsIgnoreCase(agencyId.trim())){
				    	applDO.setCommAgencyId(StringUtil.nonNullTrim(agencyId.trim()+" - "+agent.trim()));
			    	}
				}
			}
			
			if(!applDO.getBrokerType().equalsIgnoreCase("")) {
				String agentDesc = jdbcTemplate.queryForObject("SELECT AGENTTYPE_DESC FROM EM_AGENTTYPE WHERE AGENT_TYPE=?",
						new Object[] {applDO.getBrokerType()} ,String.class);
					applDO.setBrokerType(StringUtil.nonNullTrim(agentDesc));
			}
   		 
		} catch(EmptyResultDataAccessException exp) {
			agencyId = "";
		}

		return applDO;
		
	}

}
