/**
 * 
 */
package com.medicare.mss.vo;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

/**
 * @author DU20098149
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EEMWFTransferVO implements Serializable {

	private static final long serialVersionUID = -5474492386490180256L;

	private List<EEMWFCaseVO> caseData;
	private String fromUserId;
	private String toUserId;
	private String comment;
	private String message;
}
