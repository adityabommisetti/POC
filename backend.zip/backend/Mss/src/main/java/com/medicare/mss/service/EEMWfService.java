package com.medicare.mss.service;

import static com.medicare.mss.util.StringUtil.nonNullTrim;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.caching.EEMPersistence;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMApplDAO;
import com.medicare.mss.dao.EEMWfDAO;
import com.medicare.mss.domainobject.EEMAtRiskDO;
import com.medicare.mss.domainobject.EEMWFActivityDO;
import com.medicare.mss.domainobject.EEMWFCaseDO;
import com.medicare.mss.domainobject.EEMWFCommentDO;
import com.medicare.mss.domainobject.EEMWFSupervisorUserDO;
import com.medicare.mss.domainobject.EEMWFUserDO;
import com.medicare.mss.domainobject.EEMWfAssignOrTransDO;
import com.medicare.mss.domainobject.EMWFCaseQueueDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.helper.EEMContext;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.LabelValueKeyPair;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EEMApplMasterVO;
import com.medicare.mss.vo.EEMApplicationVO;
import com.medicare.mss.vo.EEMAtRiskVO;
import com.medicare.mss.vo.EEMWFActivityVO;
import com.medicare.mss.vo.EEMWFCaseVO;
import com.medicare.mss.vo.EEMWFCommentVO;
import com.medicare.mss.vo.EEMWFSupervisorUserVO;
import com.medicare.mss.vo.EEMWFTransferVO;
import com.medicare.mss.vo.EEMWFUserVO;
import com.medicare.mss.vo.EEMWfCacheVO;
import com.medicare.mss.vo.EEMWfSearchVO;
import com.medicare.mss.vo.EMWFCaseQueueVO;
import com.medicare.mss.vo.EMWFMasterVO;
import com.medicare.mss.vo.EMWFQueAsgnGrpVO;
import com.medicare.mss.vo.EMWFUpdateMasterVO;
import com.medicare.mss.vo.PageableVO;
import com.medicare.mss.vo.WorkFlowDashletVO;

@Service
@Transactional(rollbackFor = ApplicationException.class)
public class EEMWfService {

	private static final Logger LOG = LoggerFactory.getLogger(EEMWfService.class);

	@Autowired
	private EEMWfDAO wfDao;

	@Autowired
	private EEMApplDAO applDao;

	@Autowired
	private EEMPersistence eemPersistance;

	@Autowired
	private CacheService sessionHelper;

	@Autowired
	private EEMCodeCache eemCodeCache;

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public EMWFMasterVO searchWorkflow(EEMWfSearchVO wfSearchVO) {

		EMWFMasterVO emWfmasterVO = new EMWFMasterVO();
		List<EEMWFCaseVO> caseVOList = new ArrayList<>();

		String custId = sessionHelper.getUserInfo().getCustomerId();
		String searchUserId = EEMConstants.BLANK;
		String assignedToUserId = wfSearchVO.getAssignedToUser();

		if (StringUtils.isNotBlank(assignedToUserId)) {
			searchUserId = assignedToUserId;
		}

		PageableVO pageableVO = wfDao.searchWorkflow(wfSearchVO, custId, false);
		List<EEMWFCaseDO> caseDOList = (List<EEMWFCaseDO>) pageableVO.getContent();
		populateEMWFMasterVO(emWfmasterVO, caseVOList, caseDOList, searchUserId);
		emWfmasterVO.setNextPage(pageableVO.isNextPage());

		setToContext(wfSearchVO);
		return emWfmasterVO;
	}

	@Transactional(readOnly = true)
	public List<EEMWFActivityVO> getActivities(int caseId) {

		List<EEMWFActivityVO> activityVOList = new ArrayList<>();
		String custId = sessionHelper.getUserInfo().getCustomerId();

		if (Objects.nonNull(caseId)) {
			List<EEMWFActivityDO> activityDOList = wfDao.fetchUserActivityList(caseId, custId);
			if (!CollectionUtils.isEmpty(activityDOList)) {
				CommonUtils.copyList(activityDOList, activityVOList, EEMWFActivityVO.class);
			}
		}
		return activityVOList;
	}

	public EMWFMasterVO assignWork(int originalFetchSize) {

		List<EEMWFCaseVO> assignableList = null;
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String toUserId = sessionHelper.getUserInfo().getUserId();
		String fromUserId = "UNASSIGNED";
		String msg = "Workflow Assign work done successfully..";
		String toUserName = getUserNameByUserId(toUserId);

		List<EEMWFCaseDO> totalUnAssignedCases = wfDao.getTotalUnAssignedCases(customerId);

		if (CollectionUtils.isEmpty(totalUnAssignedCases)) {
			throw new ApplicationException("There are no UNASSIGNED cases to be assigned!");
		}

		List<EEMWFCaseVO> tempCaseVOList = new ArrayList<>();
		CommonUtils.copyList(totalUnAssignedCases, tempCaseVOList, EEMWFCaseVO.class);
		List<EEMWFCaseVO> resultList = new ArrayList<>();
		List<String> assignedQueueCodeList = wfDao.fetchQueueCdsBasedOnPriority(customerId, toUserId);
		int calculatedFetchSize = calculateActualFetchSize(originalFetchSize, toUserId);

		if (!CollectionUtils.isEmpty(assignedQueueCodeList)) {
			assignedQueueCodeList.stream()
					.forEach(assignedQueueCd -> resultList.addAll(tempCaseVOList.stream()
							.filter(caseVO -> StringUtils.equals(caseVO.getQueueCode(), assignedQueueCd))
							.collect(Collectors.toList())));
		}

		if (!CollectionUtils.isEmpty(resultList)) {
			if (resultList.size() > calculatedFetchSize) {
				assignableList = resultList.subList(0, calculatedFetchSize);
			} else {
				assignableList = resultList;
			}
		}

		if (CollectionUtils.isEmpty(assignableList)) {
			throw new ApplicationException(String.format("No Cases found to be assigned to userId: %s with size: %d",
					toUserName, calculatedFetchSize));
		} else {
			List<EEMWFCaseDO> finalAssignableList = new ArrayList<>();
			CommonUtils.copyList(assignableList, finalAssignableList, EEMWFCaseDO.class);

			EEMWfAssignOrTransDO assignOrTransDO = new EEMWfAssignOrTransDO();
			assignOrTransDO.setCustomerId(customerId);
			assignOrTransDO.setFromUserId(fromUserId);
			assignOrTransDO.setToUserId(toUserId);
			assignOrTransDO.setCaseList(finalAssignableList);
			assignOrTransDO.setReassignTypeCd(EEMConstants.REASSIGN_TYPECD_AW);
			int totalAssigned = wfDao.assignOrTransferCase(assignOrTransDO);

			if (totalAssigned == 0) {
				LOG.info("Unable to Assign Work for userId: {}", toUserId);
				msg = "Unable to Assign Work!";
			} else if (totalAssigned < originalFetchSize) {
				msg = String.format(
						CommonUtils.appendStrings("Few of the available cases couldn't be assigned to %s, ",
								"this is possibly due to either few of the available cases ",
								"are not configured/assignable to the user or user doesn't have enough capacity"),
						toUserName);
			}
		}

		EEMWfSearchVO eemWfSearchVO = sessionHelper.getEEMContext().getEmWFSearchVO();
		EMWFMasterVO emWfMasterVO = searchWorkflow(eemWfSearchVO);
		emWfMasterVO.setMessage(msg);

		return emWfMasterVO;
	}

	@Transactional(readOnly = true)
	public List<WorkFlowDashletVO> loadDashlets(String searchUserId, boolean isSupervisorTab) {

		String loggedInUserId = sessionHelper.getUserInfo().getUserId();

		List<WorkFlowDashletVO> dashletData = new ArrayList<>();
		String custId = sessionHelper.getUserInfo().getCustomerId();

		// Detailed Count Based on Status
		Map<String, List<String>> result = wfDao.getDashletData(custId, searchUserId);
		buildSubDashlets(dashletData, result);

		// mapping OPEN/HOLD subItems to OPEN/HOLD cases
		Map<String, Integer> caseStatusMap = wfDao.getCountBasedOnStatus(custId, searchUserId);
		Set<Entry<String, Integer>> statusEntry = caseStatusMap.entrySet();
		WorkFlowDashletVO statusDashletVO;
		for (Entry<String, Integer> entry : statusEntry) {
			statusDashletVO = new WorkFlowDashletVO();
			statusDashletVO.setStatus(entry.getKey());
			statusDashletVO.setCount(entry.getValue());
			List<WorkFlowDashletVO> subItems = dashletData.stream()
					.filter(vo -> StringUtils.equals(vo.getType(), entry.getKey())).collect(Collectors.toList());
			statusDashletVO.setSubItems(subItems);
			dashletData.add(statusDashletVO);
		}

		// mapping ATRISK subItems to ATRISK cases
		int atRiskCount = getTotalCount(EEMConstants.ATRISK, result);
		mapSubItemsToParentItems(dashletData, EEMConstants.ATRISK, atRiskCount);

		// mapping ASSIGNED subItems to ASSIGNED cases
		int assignedCount = getTotalCount(EEMConstants.ASSIGNED, result);
		mapSubItemsToParentItems(dashletData, EEMConstants.ASSIGNED, assignedCount);

		// mapping UNASSIGNED subItems to UNASSIGNED cases
		int unAssignedCount = getTotalCount(EEMConstants.UNASSIGNED, result);
		mapSubItemsToParentItems(dashletData, EEMConstants.UNASSIGNED, unAssignedCount);

		String userAccess = getUserLevel(loggedInUserId);

		if (isSupervisorTab) {
			userAccess = EEMConstants.WF_NORMAL_USER;
		}

		addZeroCountDashletData(custId, dashletData, userAccess);
		return filterAndSortDashletDataByConfigDashlets(custId, dashletData, userAccess);
	}

	private int getTotalCount(String status, Map<String, List<String>> result) {
		int count = 0;
		List<String> values = result.get(status);
		if (!CollectionUtils.isEmpty(values)) {
			for (String value : values) {
				count += Integer.parseInt(value.substring(value.indexOf(EEMConstants.DASHLETCOUNT_SEPARATOR) + 1,
						value.lastIndexOf(EEMConstants.DASHLETCOUNT_SEPARATOR)));
			}
		}
		return count;
	}

	/**
	 * @param userId
	 * @param dashletData
	 * @param custId
	 */
	private void mapSubItemsToParentItems(List<WorkFlowDashletVO> dashletData, String status, int count) {
		WorkFlowDashletVO atRiskDashletDataVO = new WorkFlowDashletVO();
		atRiskDashletDataVO.setStatus(status);
		atRiskDashletDataVO.setCount(count);
		List<WorkFlowDashletVO> result = dashletData.stream()
				.filter(vo -> StringUtils.equals(vo.getType(), atRiskDashletDataVO.getStatus()))
				.collect(Collectors.toList());
		atRiskDashletDataVO.setSubItems(result);
		dashletData.add(atRiskDashletDataVO);
	}

	/**
	 * @param dashletData
	 * @param detailedCountBasedOnStatus
	 */
	private void buildSubDashlets(List<WorkFlowDashletVO> dashletData,
			Map<String, List<String>> detailedCountBasedOnStatus) {
		Set<String> statusSubItemsSet = detailedCountBasedOnStatus.keySet();
		WorkFlowDashletVO statusSubItemDashletVO;
		for (String key : statusSubItemsSet) {
			List<String> values = detailedCountBasedOnStatus.get(key);
			for (String value : values) {
				statusSubItemDashletVO = new WorkFlowDashletVO();
				String[] tokens = value.split(EEMConstants.DASHLETCOUNT_SEPARATOR);
				String status;
				int count;
				String queueName;
				if (tokens.length == 3) {
					status = tokens[0];
					count = Integer.parseInt(tokens[1]);
					queueName = tokens[2];
				} else if (tokens.length == 2) {
					status = EEMConstants.BLANK;
					count = Integer.parseInt(tokens[1]);
					queueName = EEMConstants.BLANK;
				} else {
					status = EEMConstants.BLANK;
					count = 0;
					queueName = EEMConstants.BLANK;
				}
				statusSubItemDashletVO.setStatus(status);
				statusSubItemDashletVO.setCount(count);
				statusSubItemDashletVO.setType(key);
				statusSubItemDashletVO.setQueueName(queueName);
				dashletData.add(statusSubItemDashletVO);
			}
		}
	}

	private void addZeroCountDashletData(String custId, List<WorkFlowDashletVO> dashletData, String userAccess) {
		List<String> zeroCountDashletName;
		List<String> dashletNames = dashletData.stream().map(WorkFlowDashletVO::getStatus).distinct()
				.collect(Collectors.toList());

		if (StringUtils.equals(userAccess, EEMConstants.WF_SUPERVISOR)
				|| StringUtils.equals(userAccess, EEMConstants.WF_ADMIN)) {
			zeroCountDashletName = fetchDashletConfiguration(EEMConstants.WFSUPDSHLT, custId).stream()
					.filter(name -> !dashletNames.contains(name)).collect(Collectors.toList());
		} else {
			zeroCountDashletName = fetchDashletConfiguration(EEMConstants.WFUSRDSHLT, custId).stream()
					.filter(name -> !dashletNames.contains(name)).collect(Collectors.toList());
		}

		zeroCountDashletName.stream().forEach(status -> {
			WorkFlowDashletVO zeroCountDashletData = new WorkFlowDashletVO();
			zeroCountDashletData.setStatus(status);
			zeroCountDashletData.setCount(0);
			dashletData.add(zeroCountDashletData);
		});
	}

	/**
	 * @param custId
	 * @param isSupervisor
	 * @return list of configured dashletnames for provided wf user/supervisor
	 */
	private List<String> fetchDashletConfiguration(String wfCode, String custId) {
		List<String> dashletNames = Arrays
				.asList(eemPersistance.fetchDashletConfiguration(wfCode, custId).split(",\\s*"));
		return dashletNames.stream().map(StringUtils::upperCase).collect(Collectors.toList());
	}

	private List<WorkFlowDashletVO> filterAndSortDashletDataByConfigDashlets(String custId,
			List<WorkFlowDashletVO> dashletData, String userAccess) {
		List<WorkFlowDashletVO> filteredDashletData;
		if (StringUtils.equals(userAccess, EEMConstants.WF_SUPERVISOR)
				|| StringUtils.equals(userAccess, EEMConstants.WF_ADMIN)) {
			List<String> supervisorDashletNames = fetchDashletConfiguration(EEMConstants.WFSUPDSHLT, custId);
			filteredDashletData = dashletData.stream()
					.filter(dashletVO -> supervisorDashletNames.contains(dashletVO.getStatus()))
					.collect(Collectors.toList());
			return sortDashletData(filteredDashletData, supervisorDashletNames);
		} else {
			List<String> userDashletNames = fetchDashletConfiguration(EEMConstants.WFUSRDSHLT, custId);
			filteredDashletData = dashletData.stream()
					.filter(dashletVO -> userDashletNames.contains(dashletVO.getStatus())).collect(Collectors.toList());
			return sortDashletData(filteredDashletData, userDashletNames);
		}

	}

	private List<WorkFlowDashletVO> sortDashletData(List<WorkFlowDashletVO> filteredDashletData,
			List<String> sortedDashletNames) {
		List<WorkFlowDashletVO> sortedDashletData = new ArrayList<>();
		for (String status : sortedDashletNames) {
			sortedDashletData.addAll(filteredDashletData.stream()
					.filter(dashlet -> StringUtils.equals(status, dashlet.getStatus())).collect(Collectors.toList()));
		}
		return sortedDashletData;
	}

	@Transactional(readOnly = true)
	public Integer calculateActualFetchSize(Integer originalAssignOrTransferSize, String toUserId) {

		int actualAssignOrTransferSize = 0;

		if (StringUtils.equalsAnyIgnoreCase(EEMConstants.UNASSIGNED, toUserId)) {
			return originalAssignOrTransferSize;
		}

		String custId = sessionHelper.getUserInfo().getCustomerId();
		int countOfAssignedCases = wfDao.getCountOfAssignedCases(custId, toUserId, EEMConstants.OPEN);
		int maxAssignableWork = wfDao.getWFUserMaxAssignableWorkLimit(custId, EEMConstants.WFMXUSRLMT);
		int capacity = maxAssignableWork - countOfAssignedCases;

		if (capacity == 0) {
			throw new ApplicationException(
					String.format("User has reached the maximum assignable work capacity of %d!", maxAssignableWork));
		} else if (originalAssignOrTransferSize > maxAssignableWork) {
			actualAssignOrTransferSize = capacity;
			LOG.info("transfer/assign size {} is greater than maximum assignable work capacity of {}!",
					originalAssignOrTransferSize, maxAssignableWork);
		} else {
			if (originalAssignOrTransferSize > capacity) {
				actualAssignOrTransferSize = capacity;
			} else {
				actualAssignOrTransferSize = originalAssignOrTransferSize;
			}
		}
		return actualAssignOrTransferSize;
	}

	/**
	 * @param emWfmasterVO
	 * @param caseVOList
	 * @param caseDOList
	 */
	private void populateEMWFMasterVO(EMWFMasterVO emWfmasterVO, List<EEMWFCaseVO> caseVOList,
			List<EEMWFCaseDO> caseDOList, String userId) {

		if (!CollectionUtils.isEmpty(caseDOList)) {
			CommonUtils.copyList(caseDOList, caseVOList, EEMWFCaseVO.class);
			setOtherRequiredFields(caseVOList);
			List<EEMWFActivityVO> activityVOList = getActivities(caseVOList.get(0).getCaseId());
			emWfmasterVO.setCaseData(caseVOList);
			emWfmasterVO.setActivityData(activityVOList);
		} else {
			emWfmasterVO.setCaseData(new ArrayList<>());
			emWfmasterVO.setActivityData(new ArrayList<>());
		}
		List<WorkFlowDashletVO> dashletData = loadDashlets(userId, false);
		setOtherDashletProps(userId, dashletData);
		emWfmasterVO.setDashletData(dashletData);
	}

	public void setOtherDashletProps(String userId, List<WorkFlowDashletVO> dashletData) {
		String custId = sessionHelper.getUserInfo().getCustomerId();
		setHasAccessData(userId, custId, dashletData);
		setManualPopupData(custId, dashletData);
	}

	@Transactional(readOnly = true)
	public void setOtherRequiredFields(List<EEMWFCaseVO> caseVOList) {
		String custId = sessionHelper.getUserInfo().getCustomerId();
		List<String> userIds = new ArrayList<>();
		List<String> applIdList = new ArrayList<>();
		List<String> mbrIdList = new ArrayList<>();

		for (EEMWFCaseVO caseVO : caseVOList) {
			if (StringUtils.isNotBlank(caseVO.getMbrId())) {
				caseVO.setSource(EEMConstants.MEMBER);
				caseVO.setApplicationStatus(EEMConstants.BLANK);
				mbrIdList.add(caseVO.getMbrId());
			} else {
				if (StringUtils.isNotBlank(caseVO.getAppId())) {
					caseVO.setSource(EEMConstants.APPLICATION);
					caseVO.setApplicationStatus(applDao.getApplicationStatusByAppId(caseVO.getAppId(), custId).trim());
					applIdList.add(caseVO.getAppId());
				}
			}

			if (StringUtils.isNotBlank(caseVO.getCurrentUserId())
					&& StringUtils.equals(EEMConstants.UNASSIGNED, caseVO.getCurrentUserId())) {
				caseVO.setFirstName(EEMConstants.UNASSIGNED);
				caseVO.setLastName(EEMConstants.UNASSIGNED);
			}

			// setting case desc based upon queue name
			String queueName = caseVO.getCaseDesc();
			Map<String, String> caseDescMap = wfDao.getCaseDescMap(custId);
			if (!CollectionUtils.isEmpty(caseDescMap) && Objects.nonNull(caseDescMap.get(queueName))) {
				caseVO.setCaseDesc(caseDescMap.get(queueName));
			}
			caseVO.setQueueName(queueName);
			if (!userIds.contains(caseVO.getCurrentUserId())) {
				userIds.add(caseVO.getCurrentUserId());
			}
		}

		// setting the firstname and lastname
		setFirstNameLastName(caseVOList, userIds);

		// setting comments indicators
		setCommentIndicator(caseVOList, custId, applIdList, mbrIdList);
	}

	private void setFirstNameLastName(List<EEMWFCaseVO> caseVOList, List<String> userIds) {
		String firstName = EEMConstants.BLANK;
		String lastName = EEMConstants.BLANK;
		Map<String, String> userMap = wfDao.getUserNamesByUserIds(userIds);
		if (!CollectionUtils.isEmpty(userMap)) {
			for (EEMWFCaseVO caseVO : caseVOList) {
				String name = userMap.get(caseVO.getCurrentUserId());
				if (StringUtils.isNotBlank(name)) {
					String[] nameToken = name.split("_");
					if (Objects.nonNull(nameToken)) {
						if (nameToken.length == 2) {
							firstName = nameToken[0];
							lastName = nameToken[1];
						} else if (nameToken.length == 1) {
							firstName = nameToken[0];
						}
					}
					caseVO.setFirstName(StringUtils.upperCase(firstName));
					caseVO.setLastName(StringUtils.upperCase(lastName));
				}
			}
		}
	}

	private void setCommentIndicator(List<EEMWFCaseVO> caseVOList, String custId, List<String> applIdList,
			List<String> mbrIdList) {
		Map<String, Integer> mbrCommentsIndMap = wfDao.getMbrCommentIndicators(custId, mbrIdList);
		Map<String, Integer> applCommentsIndMap = wfDao.getApplCommentIndicators(custId, applIdList);
		for (EEMWFCaseVO caseVO : caseVOList) {
			if (StringUtils.equalsIgnoreCase(caseVO.getSource(), EEMConstants.MEMBER)) {
				caseVO.setCommentIndicator(mbrCommentsIndMap.containsKey(caseVO.getMbrId()));
			} else {
				caseVO.setCommentIndicator(applCommentsIndMap.containsKey(caseVO.getAppId()));
			}
		}
	}

	@Transactional(readOnly = true)
	public EEMWfCacheVO getWfCacheData() {
		EEMWfCacheVO eemWfCacheVO = new EEMWfCacheVO();
		String custId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();
		int maxAssignableWorkLimit = wfDao.getWFUserMaxAssignableWorkLimit(custId, EEMConstants.WFMXUSRLMT);
		eemWfCacheVO.setWfCaseStatuses(CommonUtils.addSelectToLabelValuePair(eemPersistance.getWFCaseStatuses(custId)));
		List<LabelValueKeyPair> wfAssignedToUsers = wfDao.getWFAssignedToUsers(userId, custId);
		wfAssignedToUsers
				.sort((LabelValueKeyPair p1, LabelValueKeyPair p2) -> p1.getKey().compareToIgnoreCase(p2.getKey()));
		eemWfCacheVO.setWfAssignedToUsers(CommonUtils.addSelectToLabelValueKeyPair(wfAssignedToUsers));
		eemWfCacheVO.setWfCaseDesc(CommonUtils.addSelectToLabelValuePair(wfDao.getWFCaseDesc(custId)));
		eemWfCacheVO.setQueueList(wfDao.getQueueList(custId));
		eemWfCacheVO.setWfCasePriority(eemPersistance.getWFCasePriorityList());
		eemWfCacheVO.setMaxAssignableWork(maxAssignableWorkLimit);
		eemWfCacheVO.setSupervisor(getUserLevel(userId));
		eemWfCacheVO.setWfOptIn(eemPersistance.getWfOptInValue(custId, EEMConstants.WFOPTIN));
		return eemWfCacheVO;
	}

	public EMWFMasterVO updateCaseState(EMWFUpdateMasterVO emwfUpdateVO) {

		String fromUserId = sessionHelper.getUserInfo().getUserId();
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String msg = "Status updated successfully";

		List<EEMWFCaseVO> selectedCaseVOs = emwfUpdateVO.getEmWFUpdateCaseVO();

		String userLevel = wfDao.getUserLevel(fromUserId, customerId);
		List<EEMWFCaseVO> updateEligibleCaseList = selectedCaseVOs.stream()
				.filter(caseVO -> StringUtils.equalsIgnoreCase(fromUserId, caseVO.getCurrentUserId())
						|| StringUtils.equalsIgnoreCase(userLevel, EEMConstants.WF_ADMIN)
						|| StringUtils.equalsIgnoreCase(fromUserId,
								wfDao.getSupervisorId(customerId, caseVO.getCurrentUserId())))
				.collect(Collectors.toList());

		if (CollectionUtils.isEmpty(updateEligibleCaseList)) {
			throw new ApplicationException("Selected case(s) is not eligible for status change");
		}

		List<EEMWFCaseDO> caseList = new ArrayList<>();
		CommonUtils.copyList(updateEligibleCaseList, caseList, EEMWFCaseDO.class);
		caseList.forEach(caseDO -> caseDO.setCaseStatus(emwfUpdateVO.getUpdateCaseStatus()));
		EEMWfAssignOrTransDO caseStatusUpdtDO = new EEMWfAssignOrTransDO();
		caseStatusUpdtDO.setCustomerId(customerId);
		caseStatusUpdtDO.setFromUserId(fromUserId);
		caseStatusUpdtDO.setToUserId(fromUserId);
		caseStatusUpdtDO.setCaseList(caseList);
		caseStatusUpdtDO.setManualTransfer(true);
		caseStatusUpdtDO.setCaseStateUpdate(true);
		int count = wfDao.updateCaseState(caseStatusUpdtDO);

		if (count > 0) {
			if (!StringUtils.equalsIgnoreCase(EEMConstants.OPEN, emwfUpdateVO.getUpdateCaseStatus())) {
				List<EEMWFCommentVO> eemwfCommentList = buildWFCommentList(updateEligibleCaseList,
						emwfUpdateVO.getCaseComment());
				addWFCommentList(eemwfCommentList);
			}
		} else {
			msg = "Unable to update case status!";
		}
		EMWFMasterVO emWFMasterVO = searchWorkflow(emwfUpdateVO.getWfSearchVO());

		if (updateEligibleCaseList.size() != selectedCaseVOs.size()) {
			msg = "Few of the selected cases couldn't be updated, this is possibly due to either few of the selected cases are not configured to the user or user doesn't have enough capacity";
		}

		emWFMasterVO.setMessage(msg);
		return emWFMasterVO;
	}

	private List<EEMWFCommentVO> buildWFCommentList(List<EEMWFCaseVO> emWFCaseVOList, String comment) {
		List<EEMWFCommentVO> eemwfCommentList = new ArrayList<>();
		for (EEMWFCaseVO emWFCaseVO : emWFCaseVOList) {
			EEMWFCommentVO wfCommentVo = new EEMWFCommentVO();

			if (StringUtils.equals(EEMConstants.MEMBER, emWFCaseVO.getSource())) {
				wfCommentVo.setPrimaryId(emWFCaseVO.getMbrId());
			} else {
				wfCommentVo.setPrimaryId(emWFCaseVO.getAppId());
			}

			wfCommentVo.setComments(comment);
			wfCommentVo.setCaseId(emWFCaseVO.getCaseId());
			wfCommentVo.setSource(emWFCaseVO.getSource());
			wfCommentVo.setCustomerId(sessionHelper.getUserInfo().getCustomerId());
			wfCommentVo.setCommentSeqNbr(1);

			wfCommentVo.setCreateUserId(sessionHelper.getUserInfo().getUserId());
			wfCommentVo.setCreateTime(DateUtil.getCurrentDatetimeStamp());

			eemwfCommentList.add(wfCommentVo);
		}
		return eemwfCommentList;
	}

	private void addWFCommentList(List<EEMWFCommentVO> eemWfCommentList) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		List<EEMWFCommentVO> eemWfMbrCommentList = new ArrayList<>();
		List<EEMWFCommentVO> eemWfApplCommentList = new ArrayList<>();

		eemWfCommentList.forEach(eemwfCommentVO -> {
			if (StringUtils.equals(EEMConstants.MEMBER, eemwfCommentVO.getSource())) {
				eemWfMbrCommentList.add(eemwfCommentVO);
			} else {
				eemWfApplCommentList.add(eemwfCommentVO);
			}
		});

		if (CommonUtils.isNotEmpty(eemWfMbrCommentList)) {
			List<String> mbrIdList = eemWfMbrCommentList.stream().map(EEMWFCommentVO::getPrimaryId).distinct()
					.collect(Collectors.toList());
			List<Map<String, Object>> mbrIdSeqNoListMap = wfDao.getNextMbrCommentSeqNumbers(customerId, mbrIdList);

			for (Map<String, Object> map : mbrIdSeqNoListMap) {
				for (EEMWFCommentVO commentVO : eemWfMbrCommentList) {
					if (Objects.nonNull(map.get(commentVO.getPrimaryId()))) {
						commentVO.setCommentSeqNbr(Integer.parseInt((String) map.get(commentVO.getPrimaryId())));
						break;
					}
				}
			}
			wfDao.addWFMbrCommentList(eemWfMbrCommentList);
		}

		if (CommonUtils.isNotEmpty(eemWfApplCommentList)) {
			List<String> applIdList = eemWfApplCommentList.stream().map(EEMWFCommentVO::getPrimaryId).distinct()
					.collect(Collectors.toList());
			List<Map<String, Object>> appIdSeqNoListMap = wfDao.getNextApplCommentSeqNumbers(customerId, applIdList);

			for (Map<String, Object> map : appIdSeqNoListMap) {
				for (EEMWFCommentVO commentVO : eemWfApplCommentList) {
					if (Objects.nonNull(map.get(commentVO.getPrimaryId()))) {
						commentVO.setCommentSeqNbr(Integer.parseInt((String) map.get(commentVO.getPrimaryId())));
						break;
					}
				}
			}
			wfDao.addWFAppCommentList(eemWfApplCommentList);
		}

	}

	@Transactional(readOnly = true)
	public List<EEMWFCommentVO> getWFComments(EEMWFCaseVO emwfCaseVO) {

		List<EEMWFCommentVO> eemwfCommentList = new ArrayList<>();
		emwfCaseVO.setCustomerId(sessionHelper.getUserInfo().getCustomerId());
		List<EEMWFCommentDO> eemwfCommentDOList = wfDao.fetchWFCommentList(emwfCaseVO);

		for (EEMWFCommentDO eemwfCommentDO : eemwfCommentDOList) {
			EEMWFCommentVO eemwfCommentVO = new EEMWFCommentVO();
			BeanUtils.copyProperties(eemwfCommentDO, eemwfCommentVO);
			eemwfCommentVO.setCaseId(emwfCaseVO.getCaseId());
			eemwfCommentVO.setSource(emwfCaseVO.getSource());
			eemwfCommentVO.setComments(StringUtils.upperCase(eemwfCommentVO.getComments()).replaceAll("(WF_COMMENT).*:",
					EEMConstants.BLANK));
			eemwfCommentList.add(eemwfCommentVO);
		}

		return eemwfCommentList;
	}

	public String getUserLevel(String userId) {
		if (StringUtils.equalsAnyIgnoreCase(EEMConstants.ASSIGNED, userId)) {
			return EEMConstants.WF_SUPERVISOR;
		}

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		return wfDao.getUserLevel(userId, customerId);
	}

	public List<EEMWFCommentVO> addAndGetWFComments(EEMWFCommentVO wfCommentVo) {

		addWFComments(wfCommentVo);
		EEMWFCaseVO emwfCaseVO = new EEMWFCaseVO();
		emwfCaseVO.setCaseId(wfCommentVo.getCaseId());
		emwfCaseVO.setCustomerId(sessionHelper.getUserInfo().getCustomerId());
		emwfCaseVO.setCaseId(wfCommentVo.getCaseId());
		if (StringUtils.equals(EEMConstants.MEMBER, wfCommentVo.getSource())) {
			emwfCaseVO.setMbrId(wfCommentVo.getPrimaryId());
		} else {
			emwfCaseVO.setAppId(wfCommentVo.getPrimaryId());
		}
		emwfCaseVO.setSource(wfCommentVo.getSource());
		return getWFComments(emwfCaseVO);
	}

	public void addWFComments(EEMWFCommentVO wfCommentVo) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		wfCommentVo.setCustomerId(customerId);
		wfCommentVo.setCreateUserId(sessionHelper.getUserInfo().getUserId());

		wfCommentVo.setCommentSeqNbr(
				wfDao.getNextCommentSeqNumber(customerId, wfCommentVo.getPrimaryId(), wfCommentVo.getSource()));
		wfCommentVo.setCreateTime(DateUtil.getCurrentDatetimeStamp());
		wfDao.addWFComment(wfCommentVo);
	}

	@Transactional(readOnly = true)
	public List<EMWFCaseQueueVO> getWFCaseQueue() {

		List<LabelValuePair> lstQueuePrty = eemPersistance.getWFCasePriorityList();

		List<EMWFCaseQueueVO> eemwfCaseQueueList = new ArrayList<>();
		List<EMWFCaseQueueDO> eemwfCaseQueueDOList = wfDao
				.fetchWFCaseQueueList(sessionHelper.getUserInfo().getCustomerId());

		eemwfCaseQueueDOList.forEach(eemwfCaseQueueDO -> {
			EMWFCaseQueueVO eemwfCaseQueueVO = new EMWFCaseQueueVO();
			BeanUtils.copyProperties(eemwfCaseQueueDO, eemwfCaseQueueVO);
			eemwfCaseQueueVO.setQueuePrty(
					StringUtil.nonNullTrim(eemCodeCache.getDesc(eemwfCaseQueueVO.getQueuePrty(), lstQueuePrty)));
			eemwfCaseQueueVO.setLastUpdtUserName(getUserNameByUserId(eemwfCaseQueueVO.getLastUpdtUserID()));
			eemwfCaseQueueList.add(eemwfCaseQueueVO);
		});
		return eemwfCaseQueueList;
	}

	public List<EMWFCaseQueueVO> updateWFCaseQueue(EMWFCaseQueueVO eemwfCaseQueueVO) {

		eemwfCaseQueueVO.setLastUpdtUserID(sessionHelper.getUserInfo().getUserId());
		eemwfCaseQueueVO.setLastUpdtTime(DateUtil.getCurrentDatetimeStamp());
		wfDao.updateWFCaseQueue(eemwfCaseQueueVO);
		return getWFCaseQueue();
	}

	public EMWFMasterVO transferCase(EEMWFTransferVO eemWFTransferVO) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		List<EEMWFCaseVO> assignableList = null;
		EEMWfAssignOrTransDO assignOrTransDO = new EEMWfAssignOrTransDO();

		List<EEMWFCaseVO> selectedCaseVOs = eemWFTransferVO.getCaseData();
		Assert.notEmpty(selectedCaseVOs, "You must select at least a case for transfer!");

		String fromUserId = eemWFTransferVO.getFromUserId();
		Assert.notNull(StringUtils.isBlank(eemWFTransferVO.getFromUserId()) ? null : eemWFTransferVO.getFromUserId(),
				"Please select From User to transfer a case!");

		String toUserId = eemWFTransferVO.getToUserId();
		Assert.notNull(StringUtils.isBlank(eemWFTransferVO.getToUserId()) ? null : eemWFTransferVO.getToUserId(),
				"Please select To User to transfer a case!");

		String toUserName;
		if (!StringUtils.equalsIgnoreCase(EEMConstants.UNASSIGNED, toUserId)) {
			toUserName = getUserNameByUserId(toUserId);
		} else {
			toUserName = EEMConstants.UNASSIGNED;
		}

		String userLevel = wfDao.getUserLevel(fromUserId, customerId);
		List<EEMWFCaseVO> transferEligibleList = selectedCaseVOs.stream()
				.filter(caseVO -> StringUtils.equalsIgnoreCase(fromUserId, caseVO.getCurrentUserId())
						|| StringUtils.equalsIgnoreCase(userLevel, EEMConstants.WF_ADMIN)
						|| (StringUtils.equalsIgnoreCase(EEMConstants.UNASSIGNED, caseVO.getCurrentUserId())
								&& StringUtils.equalsIgnoreCase(userLevel, EEMConstants.WF_SUPERVISOR))
						|| StringUtils.equalsIgnoreCase(fromUserId,
								wfDao.getSupervisorId(customerId, caseVO.getCurrentUserId())))
				.collect(Collectors.toList());

		if (CollectionUtils.isEmpty(transferEligibleList)) {
			throw new ApplicationException(
					String.format("Selected case(s) is not eligible for transfer to %s!", toUserName));
		}

		String comment = eemWFTransferVO.getComment();
		Assert.notNull(StringUtils.isBlank(eemWFTransferVO.getComment()) ? null : eemWFTransferVO.getComment(),
				"You must enter a comment to transfer a case!");

		String msg = "Transfer work completed successfully..";
		int totalAssigned = 0;
		List<EEMWFCaseVO> resultList = new ArrayList<>();
		List<String> assignedQueueCodeList = wfDao.fetchQueueCdsBasedOnPriority(customerId, toUserId);
		int actualAssignOrTransferSize = calculateActualFetchSize(transferEligibleList.size(), toUserId);

		if (!CollectionUtils.isEmpty(assignedQueueCodeList)) {
			assignedQueueCodeList.stream()
					.forEach(assignedQueueCd -> resultList.addAll(transferEligibleList.stream()
							.filter(caseVO -> StringUtils.equals(caseVO.getQueueCode(), assignedQueueCd))
							.collect(Collectors.toList())));
		}

		if (CollectionUtils.isEmpty(resultList)) {
			throw new ApplicationException(String.format("Selected cases are not configured to the %s!", toUserName));
		} else {
			if (resultList.size() > actualAssignOrTransferSize) {
				assignableList = resultList.subList(0, actualAssignOrTransferSize);
			} else {
				assignableList = resultList;
			}
		}

		if (CollectionUtils.isEmpty(assignableList)) {
			throw new ApplicationException(
					String.format("None of the selected cases are assignable to the %s!", toUserName));
		} else {
			if (transferEligibleList.size() != assignableList.size()) {
				msg = String.format(
						"Few of the selected cases couldn't be transferred to %s, this is possibly due to either few of the selected cases are not configured/assignable to the user or user doesn't have enough capacity",
						toUserName);
			}

			List<EEMWFCaseDO> casesToBeTransferred = new ArrayList<>();
			CommonUtils.copyList(assignableList, casesToBeTransferred, EEMWFCaseDO.class);

			assignOrTransDO.setCustomerId(customerId);
			assignOrTransDO.setFromUserId(fromUserId);
			assignOrTransDO.setToUserId(toUserId);
			assignOrTransDO.setCaseList(casesToBeTransferred);
			assignOrTransDO.setReassignTypeCd(EEMConstants.REASSIGN_TYPECD_TW);
			assignOrTransDO.setManualTransfer(true);
			totalAssigned = wfDao.assignOrTransferCase(assignOrTransDO);

			if (totalAssigned > 0) {
				addWFCommentList(buildWFCommentList(assignableList, comment));
			} else {
				msg = "Unable to transfer work!";
			}
		}

		EEMWfSearchVO eemWfSearchVO = sessionHelper.getEEMContext().getEmWFSearchVO();
		EMWFMasterVO emWfMasterVO = searchWorkflow(eemWfSearchVO);
		emWfMasterVO.setMessage(msg);

		return emWfMasterVO;
	}

	private String getUserNameByUserId(String toUserId) {
		String name = wfDao.getUserNameByUserId(toUserId);
		String firstName;
		String lastName;
		String userName = EEMConstants.BLANK;

		if (StringUtils.isNotBlank(name)) {
			String[] nameToken = name.split("_");
			if (Objects.nonNull(nameToken)) {
				if (nameToken.length == 2) {
					firstName = nameToken[0];
					lastName = nameToken[1];
					userName = new StringBuilder(lastName).append(" ").append(firstName).toString();
				} else if (nameToken.length == 1) {
					firstName = nameToken[0];
					userName = firstName;
				}
			}
		}
		return userName;
	}

	public int updateWFUserMaxAssignableWorkLimit(int newWFUserMaxAssignableWorkLimit) {

		String custId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();

		if (wfDao.updateWFUserMaxAssignableWorkLimit(custId, userId, EEMConstants.WFMXUSRLMT,
				newWFUserMaxAssignableWorkLimit) == 1) {
			return newWFUserMaxAssignableWorkLimit;
		} else {
			throw new ApplicationException("Update got failed!");
		}
	}

	public int getWFUserMaxAssignableWorkLimit() {
		String custId = sessionHelper.getUserInfo().getCustomerId();
		return wfDao.getWFUserMaxAssignableWorkLimit(custId, EEMConstants.WFMXUSRLMT);
	}

	public List<EEMWFSupervisorUserVO> updatePriority(EMWFQueAsgnGrpVO eMWFQueAsgnVO) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String loggedInUserId = sessionHelper.getUserInfo().getUserId();
		String userId = eMWFQueAsgnVO.getUserId();

		eMWFQueAsgnVO.setCustomerId(customerId);
		eMWFQueAsgnVO.setLoginUserId(loggedInUserId);

		Set<String> oldQueueCodes = new HashSet<>();
		Set<String> newQueueCodes = new HashSet<>();
		Map<Integer, List<String>> queAsgnOld = wfDao.fetchOldQueAssnFor(customerId, userId);
		Map<Integer, List<String>> queAsgnNew = eMWFQueAsgnVO.getQueAsgnNew();

		List<EMWFQueAsgnGrpVO> insertList = new ArrayList<>();
		List<EMWFQueAsgnGrpVO> updateList = new ArrayList<>();

		for (Entry<Integer, List<String>> queAsgnNewEntry : queAsgnNew.entrySet()) {

			List<String> oldAsgnCdList = CommonUtils.isNotEmpty(queAsgnOld.get(queAsgnNewEntry.getKey()))
					? queAsgnOld.get(queAsgnNewEntry.getKey())
					: new ArrayList<>();
			List<String> newAsgnCdList = CommonUtils.isNotEmpty(queAsgnNewEntry.getValue()) ? queAsgnNewEntry.getValue()
					: new ArrayList<>();
			List<String> newAsgnCdListCopy = new ArrayList<>(newAsgnCdList);

			oldQueueCodes.addAll(oldAsgnCdList);
			newQueueCodes.addAll(newAsgnCdList);

			if (Objects.nonNull(newAsgnCdList) && !newAsgnCdList.equals(oldAsgnCdList)) {
				newAsgnCdList.removeAll(oldAsgnCdList); // insert
				newAsgnCdList.forEach(newAsgnCd -> insertList.add(prepareAddVo(queAsgnNewEntry.getKey(), newAsgnCd)));

				oldAsgnCdList.removeAll(newAsgnCdListCopy); // delete
				oldAsgnCdList.forEach(oldAsgnCd -> updateList.add(prepareAddVo(queAsgnNewEntry.getKey(), oldAsgnCd)));
			}
		}

		oldQueueCodes.removeAll(newQueueCodes);

		if (CommonUtils.isNotEmpty(updateList)) {
			wfDao.updatePriority(eMWFQueAsgnVO, updateList);
		}
		if (CommonUtils.isNotEmpty(insertList)) {
			wfDao.insertPriority(eMWFQueAsgnVO, insertList);
		}

		if (StringUtils.equalsIgnoreCase(eMWFQueAsgnVO.getUserConfFlag(), EEMConstants.VALUE_YES)
				&& !CollectionUtils.isEmpty(oldQueueCodes)) {

			List<EEMWFCaseDO> casesToBeUnAssigned = wfDao.getCasesForQueueCds(oldQueueCodes,
					eMWFQueAsgnVO.getCustomerId(), eMWFQueAsgnVO.getUserId());

			if (!CollectionUtils.isEmpty(casesToBeUnAssigned)) {
				EEMWfAssignOrTransDO assignOrTransDO = new EEMWfAssignOrTransDO();
				assignOrTransDO.setCustomerId(eMWFQueAsgnVO.getCustomerId());
				assignOrTransDO.setFromUserId(eMWFQueAsgnVO.getUserId());
				assignOrTransDO.setToUserId(EEMConstants.UNASSIGNED);
				assignOrTransDO.setCaseList(casesToBeUnAssigned);
				assignOrTransDO.setReassignTypeCd(EEMConstants.REASSIGN_TYPECD_TW);
				wfDao.assignOrTransferCase(assignOrTransDO);
			}
		}

		return getSupervisorDetail(eMWFQueAsgnVO.getSearchSupAdminId(), eMWFQueAsgnVO.getSearchUserId());
	}

	private EMWFQueAsgnGrpVO prepareAddVo(int prtyNum, String prtyQueueCd) {
		EMWFQueAsgnGrpVO asgnGrpVO = new EMWFQueAsgnGrpVO();
		asgnGrpVO.setPrtyNum(prtyNum);
		asgnGrpVO.setQueueCd(prtyQueueCd);
		return asgnGrpVO;
	}

	@Transactional(readOnly = true)
	public List<EEMAtRiskVO> getAtRiskSummary() {

		List<LabelValuePair> lstQueuePrty = eemPersistance.getWFCasePriorityList();

		List<EEMAtRiskVO> getRiskSummaryVOList = new ArrayList<>();
		List<EEMAtRiskDO> getRiskSummaryDOList = wfDao.getAtRiskSummary(sessionHelper.getUserInfo().getCustomerId());

		getRiskSummaryDOList.forEach(atRiskSummaryDO -> {
			EEMAtRiskVO atRiskSummaryVO = new EEMAtRiskVO();
			BeanUtils.copyProperties(atRiskSummaryDO, atRiskSummaryVO);

			atRiskSummaryVO.setQueuePrtyFrmt(StringUtil.nonNullTrim(atRiskSummaryVO.getQueuePrty()) + "-"
					+ StringUtil.nonNullTrim(eemCodeCache.getDesc(atRiskSummaryVO.getQueuePrty(), lstQueuePrty)));
			atRiskSummaryVO.setMemberName(StringUtils.upperCase(atRiskSummaryDO.getMemberName()));
			atRiskSummaryVO.setUserName(StringUtils.upperCase(atRiskSummaryDO.getUserName()));
			atRiskSummaryVO.setSupervisorName(StringUtils.upperCase(atRiskSummaryDO.getSupervisorName()));
			getRiskSummaryVOList.add(atRiskSummaryVO);
		});

		return getRiskSummaryVOList;
	}

	@Transactional(readOnly = true)
	public List<EEMAtRiskVO> getAtRiskDetails(EEMAtRiskVO eemAtRiskVO) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		eemAtRiskVO.setCustomerId(customerId);
		List<EEMAtRiskVO> getRiskDetailsVOList = new ArrayList<>();
		List<EEMAtRiskDO> getRiskDetailsDOList = wfDao.getAtRiskDetails(eemAtRiskVO);
		Map<String, String> caseDescMap = wfDao.getCaseDescMap(customerId);
		getRiskDetailsDOList.forEach(atRiskDetailsDO -> {
			EEMAtRiskVO atRiskDetailsVO = new EEMAtRiskVO();
			BeanUtils.copyProperties(atRiskDetailsDO, atRiskDetailsVO);
			atRiskDetailsVO.setQueuePrtyFrmt(eemAtRiskVO.getQueuePrtyFrmt());
			String caseDesc = atRiskDetailsDO.getCaseDesc();
			atRiskDetailsVO.setCaseDesc(
					StringUtils.isNotBlank(caseDescMap.get(caseDesc)) ? caseDescMap.get(caseDesc) : caseDesc);
			getRiskDetailsVOList.add(atRiskDetailsVO);
		});

		return getRiskDetailsVOList;
	}

	public Boolean updateUserStatus(EEMWFSupervisorUserVO emWFSupervisorUserVO) {
		int sqlCnt = 0;
		String inactiveStartDate = "00010101";
		String inactiveEndDate = "99999999";

		String managerId = sessionHelper.getUserInfo().getUserId();
		String customerId = sessionHelper.getUserInfo().getCustomerId();

		if (Objects.nonNull(emWFSupervisorUserVO)) {
			if (StringUtils.isBlank(emWFSupervisorUserVO.getUserStatus())) {
				emWFSupervisorUserVO.setUserStatus(EEMConstants.ACTIVE);
			}
			if (StringUtils.isBlank(emWFSupervisorUserVO.getInactiveStartDate())) {
				emWFSupervisorUserVO.setInactiveStartDate(inactiveStartDate);
			} else {
				emWFSupervisorUserVO.setInactiveStartDate(
						DateUtil.changedDateFormatForMonth(emWFSupervisorUserVO.getInactiveStartDate()));
			}
			if (StringUtils.isBlank(emWFSupervisorUserVO.getInactiveEndDate())) {
				emWFSupervisorUserVO.setInactiveEndDate(inactiveEndDate);
			} else {
				emWFSupervisorUserVO.setInactiveEndDate(
						DateUtil.changedDateFormatForMonth(emWFSupervisorUserVO.getInactiveEndDate()));
			}
			if (StringUtils.isBlank(emWFSupervisorUserVO.getPrtyMethod())) {
				emWFSupervisorUserVO.setPrtyMethod("U");
			}
			if (StringUtils.equals(emWFSupervisorUserVO.getUserStatus(), EEMConstants.ACTIVE)) {
				emWFSupervisorUserVO.setInactiveStartDate(inactiveStartDate);
				emWFSupervisorUserVO.setInactiveEndDate(inactiveEndDate);
			}
			sqlCnt = wfDao.updateUserStatus(emWFSupervisorUserVO, managerId, customerId);

			if (sqlCnt > 0 && StringUtils.equals(emWFSupervisorUserVO.getUserStatus(), EEMConstants.INACTIVE)
					&& StringUtils.equals(emWFSupervisorUserVO.getUnAssignedFlag(), EEMConstants.VALUE_YES)) {

				String userId = nonNullTrim(emWFSupervisorUserVO.getUserId());
				List<EEMWFCaseDO> casesToBeUnAssigned = wfDao.getCasesByUserId(userId, customerId);

				if (!CollectionUtils.isEmpty(casesToBeUnAssigned)) {
					EEMWfAssignOrTransDO assignOrTransDO = new EEMWfAssignOrTransDO();
					assignOrTransDO.setCustomerId(customerId);
					assignOrTransDO.setFromUserId(managerId);
					assignOrTransDO.setToUserId(EEMConstants.UNASSIGNED);
					assignOrTransDO.setCaseList(casesToBeUnAssigned);
					assignOrTransDO.setReassignTypeCd(EEMConstants.REASSIGN_TYPECD_TW);
					wfDao.assignOrTransferCase(assignOrTransDO);
				}
			}
		}
		return sqlCnt > 0;
	}

	@Transactional(readOnly = true)
	public Map<String, Object> getSupervisorTabDetail() {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String loggedInUsrId = sessionHelper.getUserInfo().getUserId();

		List<LabelValuePair> supervisorList = new ArrayList<>();
		Map<String, Object> resultMap = new HashMap<>();

		LabelValuePair loggedInUserLVPair = new LabelValuePair(loggedInUsrId, getUserNameByUserId(loggedInUsrId));
		List<EEMWFSupervisorUserVO> supervisorUserVOList = getSupervisorDetail(loggedInUsrId, null);
		supervisorList.add(loggedInUserLVPair);

		String userLevel = wfDao.getUserLevel(loggedInUsrId, customerId);
		if (StringUtils.equals(EEMConstants.WF_ADMIN, userLevel)) {
			Map<String, List<LabelValuePair>> existingUsersMap = wfDao.getWfUsersList(customerId);
			List<LabelValuePair> adminList = existingUsersMap.get("1");
			List<LabelValuePair> newAdminList = adminList.stream()
					.filter(pair -> !StringUtils.equals(pair.getValue(), loggedInUsrId)).collect(Collectors.toList());
			List<LabelValuePair> otherSupervisorList = existingUsersMap.get("2");
			supervisorList.addAll(newAdminList);
			supervisorList.addAll(otherSupervisorList);
		}

		List<LabelValuePair> userList = fetchAssignedNormalWfUsers(loggedInUsrId);

		resultMap.put("supervisorList", supervisorList);
		resultMap.put("userList", userList);
		resultMap.put("supervisorUserVOList", supervisorUserVOList);

		return resultMap;
	}

	@Transactional(readOnly = true)
	public List<LabelValuePair> fetchAssignedNormalWfUsers(String adminOrSupervisorId) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();

		List<LabelValuePair> userList = new ArrayList<>();
		List<LabelValuePair> assignedNormalWfUsers = wfDao.fetchAssignedWfUsers(customerId, adminOrSupervisorId, 3);
		if (CommonUtils.isNotEmpty(assignedNormalWfUsers)) {
			userList.addAll(assignedNormalWfUsers);
		}
		return userList;
	}

	@Transactional(readOnly = true)
	public List<EEMWFSupervisorUserVO> getSupervisorDetail(String supOrAdminId, String userId) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();

		supOrAdminId = getSupervisorId(supOrAdminId, userId, customerId);

		List<EEMWFSupervisorUserVO> supervisorUserTempList = new ArrayList<>();
		EEMWFSupervisorUserVO supUserVO;
		List<EEMWFSupervisorUserDO> supervisorUserDOList = wfDao.getSupervisorUsers(customerId, supOrAdminId, userId);
		Map<String, List<EEMWFSupervisorUserDO>> usrDOsPerUser = supervisorUserDOList.stream()
				.collect(Collectors.groupingBy(EEMWFSupervisorUserDO::getUserId));
		for (Entry<String, List<EEMWFSupervisorUserDO>> usrDOEntry : usrDOsPerUser.entrySet()) {
			List<String> p1List = new ArrayList<>();
			List<String> p2List = new ArrayList<>();
			List<String> p3List = new ArrayList<>();
			List<String> p4List = new ArrayList<>();
			List<EEMWFSupervisorUserDO> supUserDOList = usrDOEntry.getValue();
			if (CommonUtils.isNotEmpty(supUserDOList)) {
				for (EEMWFSupervisorUserDO supUserDO : supUserDOList) {
					if (StringUtils.isNotBlank(supUserDO.getPrtyOne())) {
						p1List.add(supUserDO.getPrtyOne());
					} else if (StringUtils.isNotBlank(supUserDO.getPrtyTwo())) {
						p2List.add(supUserDO.getPrtyTwo());
					} else if (StringUtils.isNotBlank(supUserDO.getPrtyThree())) {
						p3List.add(supUserDO.getPrtyThree());
					} else if (StringUtils.isNotBlank(supUserDO.getPrtyFour())) {
						p4List.add(supUserDO.getPrtyFour());
					}
				}
				supUserVO = new EEMWFSupervisorUserVO();
				BeanUtils.copyProperties(supUserDOList.get(0), supUserVO);
				supUserVO.setPrtyOneList(p1List);
				supUserVO.setPrtyTwoList(p2List);
				supUserVO.setPrtyThreeList(p3List);
				supUserVO.setPrtyFourList(p4List);
				supervisorUserTempList.add(supUserVO);
			}
		}

		return supervisorUserTempList.stream().sorted(Comparator.comparing(EEMWFSupervisorUserVO::getName))
				.collect(Collectors.toList());
	}

	private String getSupervisorId(String supOrAdminId, String userId, String customerId) {
		if (Objects.isNull(supOrAdminId)) {
			supOrAdminId = sessionHelper.getUserInfo().getUserId();
		}

		if (StringUtils.equals(userId, supOrAdminId)) {
			supOrAdminId = userId;
		} else if (StringUtils.isNotBlank(userId)) {
			supOrAdminId = wfDao.getSupervisorId(customerId, userId);
		}
		return supOrAdminId;
	}

	@Transactional(readOnly = true)
	public List<EEMWFSupervisorUserVO> getSupervisorUserDetail(String supOrAdminId, String userId) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();

		List<EEMWFSupervisorUserDO> supervisorUserDOList = wfDao.getSupervisorUsers(customerId, supOrAdminId, userId);
		List<EEMWFSupervisorUserVO> supervisorUserVOList = new ArrayList<>();
		if (!CollectionUtils.isEmpty(supervisorUserDOList)) {
			CommonUtils.copyList(supervisorUserDOList, supervisorUserVOList, EEMWFSupervisorUserVO.class);
		}
		return supervisorUserVOList;
	}

	@Transactional(readOnly = true)
	public List<WorkFlowDashletVO> fetchDashletsByUser(String userId) {
		List<WorkFlowDashletVO> dashletData = loadDashlets(userId, true);
		setOtherDashletProps(userId, dashletData);
		WorkFlowDashletVO manualPopupDashlet = buildManualPopupDashlet(fetchManualPopupQueues());
		dashletData.add(manualPopupDashlet);
		return dashletData;
	}

	@Transactional(readOnly = true)
	public Map<String, List<LabelValuePair>> getAddOrShowUserData() {
		String customerId = sessionHelper.getUserInfo().getCustomerId();

		Map<String, List<LabelValuePair>> usersMap = wfDao.getNewUserList(customerId);
		List<LabelValuePair> newSupervisorList = usersMap.get("SUPERVISOR");
		List<LabelValuePair> newUserList = usersMap.get("USER");

		if (CollectionUtils.isEmpty(newUserList)) {
			newUserList = new ArrayList<>();
		}

		if (!CollectionUtils.isEmpty(newSupervisorList)) {
			newUserList.addAll(newSupervisorList);
			newUserList
					.sort((LabelValuePair s1, LabelValuePair s2) -> s1.getLabel().compareToIgnoreCase(s2.getLabel()));
		}

		Map<String, List<LabelValuePair>> existingUsersMap = wfDao.getWfUsersList(customerId);
		List<LabelValuePair> adminList = existingUsersMap.get("1");
		List<LabelValuePair> supervisorList = existingUsersMap.get("2");

		if (!CollectionUtils.isEmpty(supervisorList)) {
			if (!CollectionUtils.isEmpty(adminList)) {
				supervisorList.addAll(0, adminList);
			}
		} else {
			supervisorList = new ArrayList<>();
			if (!CollectionUtils.isEmpty(adminList)) {
				supervisorList.addAll(adminList);
			}
		}

		Map<String, List<LabelValuePair>> resultMap = new HashMap<>();
		resultMap.put("newUserList", newUserList);
		resultMap.put("newSupervisorList", newSupervisorList);
		resultMap.put("supervisorList", supervisorList);
		resultMap.put("adminList", adminList);

		return resultMap;
	}

	public Map<String, List<LabelValuePair>> addUser(String role, String userId, String supervisorId) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String loggedInUserId = sessionHelper.getUserInfo().getUserId();
		wfDao.addNewUser(role, userId, supervisorId, loggedInUserId, customerId);
		return getAddOrShowUserData();
	}

	public List<EEMWFUserVO> searchUser(String name, String supervisorId) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		List<EEMWFUserDO> userDOList = wfDao.searchUser(customerId, name, supervisorId);
		List<EEMWFUserVO> userVOList = new ArrayList<>();
		if (!CollectionUtils.isEmpty(userDOList)) {
			CommonUtils.copyList(userDOList, userVOList, EEMWFUserVO.class);
		}
		return userVOList;
	}

	public Map<String, Object> updateUser(String role, String userId, String supervisorId, String name,
			String searchSupervisorId) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String loggedInUserId = sessionHelper.getUserInfo().getUserId();
		wfDao.updateUser(role, userId, supervisorId, loggedInUserId, customerId);
		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("search", searchUser(name, searchSupervisorId));
		resultMap.put("initial", getAddOrShowUserData());
		return resultMap;
	}

	private void setToContext(EEMWfSearchVO emWFSearchVO) {
		EEMContext context = sessionHelper.getEEMContext();
		context.setEmWFSearchVO(emWFSearchVO);
		sessionHelper.setEEMContext(context);
	}

	@SuppressWarnings("unchecked")
	public PageableVO getWorkflowPagination(EEMWfSearchVO wfSearchVO) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		PageableVO pageableResult = wfDao.searchWorkflow(wfSearchVO, customerId, true);
		List<EEMWFCaseDO> caseDOList = (List<EEMWFCaseDO>) pageableResult.getContent();
		List<EEMWFCaseVO> caseVOList = new ArrayList<>();

		if (!CollectionUtils.isEmpty(caseDOList)) {
			CommonUtils.copyList(caseDOList, caseVOList, EEMWFCaseVO.class);
			setOtherRequiredFields(caseVOList);
		}
		pageableResult.setContent(caseVOList);
		return pageableResult;
	}

	public boolean isCaseExists(String customerId, int applId) {
		return wfDao.isCaseExists(customerId, applId);
	}

	public int createCase(EEMApplMasterVO applMasterVO) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();
		EEMApplicationVO applVO = applMasterVO.getApplVO();
		boolean isCreated = false;
		int caseId = 0;

		// checking if application is eligible for case creation..
		Map<String, String> caseQueueCharsMap = wfDao.checkAndGetQueueChars(customerId, applVO.getApplId(),
				EEMConstants.APPL_TRACKING_QUEUE_CD);

		if (CommonUtils.isNotEmpty(caseQueueCharsMap)) {
			EEMWFCaseDO caseDO = populateEEMWFCaseDO(caseQueueCharsMap, applVO, customerId);
			if (caseDO.getCaseId() > 0) {
				isCreated = wfDao.createCase(caseDO);
				if (isCreated) {
					caseId = caseDO.getCaseId();
				}
			}
		}
		if (!isCreated) {
			LOG.error("Unable to create case for customerId: {}, applId: {}", customerId, applVO.getApplId());
		}

		addCaseCreationComment(caseId, customerId, applVO.getApplId(), userId);
		return caseId;
	}

	private EEMWFCaseDO populateEEMWFCaseDO(Map<String, String> caseQueueCharsMap, EEMApplicationVO applVO,
			String customerId) {
		String userId = sessionHelper.getUserInfo().getUserId();
		String ts = DateUtil.getCurrentDatetimeStamp();
		String todaysDate = DateUtil.getTodaysDate();
		String initialUserId = EEMConstants.BLANK;

		EEMWFCaseDO caseDO = new EEMWFCaseDO();
		String daysRemaining = caseQueueCharsMap.get("COMP_DAYS");
		String hicOrMbi;
		if (applVO.getIsHicOrMbi().equals("mbi")) {
			hicOrMbi = applVO.getMbi();
		} else {
			hicOrMbi = applVO.getMbrHicNbr();
		}

		// setting case properties
		caseDO.setCustomerId(customerId);
		caseDO.setCaseId(getNextCaseId(customerId));
		if (wfDao.checkUserQueueAccess(userId, customerId, EEMConstants.APPL_TRACKING_QUEUE_CD)) {
			caseDO.setCurrentUserId(userId);
			initialUserId = userId;
		} else {
			caseDO.setCurrentUserId(EEMConstants.UNASSIGNED);
		}
		caseDO.setLastUpdtTime(ts);
		caseDO.setCaseTimeStamp(ts);
		caseDO.setAppId(String.valueOf(applVO.getApplId()));
		caseDO.setMedicareId(hicOrMbi);
		caseDO.setMbrId(EEMConstants.BLANK);
		caseDO.setSupplementalId(applVO.getAltMbrId());
		caseDO.setQueueCode(EEMConstants.APPL_TRACKING_QUEUE_CD);
		caseDO.setCaseDate(todaysDate);
		caseDO.setCaseDueDate(calculateCaseDueDate(todaysDate, daysRemaining));
		caseDO.setDaysRemaining(daysRemaining);
		caseDO.setCaseDesc(caseQueueCharsMap.get("QUEUE_NAME"));
		caseDO.setCaseStatus(EEMConstants.OPEN);
		caseDO.setRiskInd(EEMConstants.VALUE_NO);
		caseDO.setMbrName(CommonUtils.buildQuery(applVO.getMbrLastName(), applVO.getMbrFirstName()));
		caseDO.setCaseReassignDate(EEMConstants.BLANK);
		caseDO.setInitialUserId(initialUserId);
		caseDO.setReAssignTypeCode(EEMConstants.BLANK);
		caseDO.setOverrideInd(EEMConstants.VALUE_NO);
		caseDO.setLastUpdtUserId(userId);
		return caseDO;
	}

	private String calculateCaseDueDate(String todaysDate, String daysRemaining) {
		int compDays = Integer.parseInt(daysRemaining);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Calendar calendar = Calendar.getInstance();
		try {
			calendar.setTime(sdf.parse(todaysDate));
		} catch (ParseException e) {
			LOG.error("Error occured while parsing {}", e.getMessage());
		}
		calendar.add(Calendar.DAY_OF_MONTH, compDays);
		return sdf.format(calendar.getTime());
	}

	private synchronized int getNextCaseId(String customerId) {
		return wfDao.getNextCaseId(customerId) > 0 ? wfDao.getNextCaseId(customerId) : 0;
	}

	private boolean addCaseCreationComment(int caseId, String customerId, int applId, String userId) {
		EEMWFCommentVO wfCommentVo = buildComment(customerId, applId, userId);
		wfCommentVo.setCaseId(caseId);
		if (wfCommentVo.getCaseId() > 0) {
			wfCommentVo.setComments(
					String.format("Case got created successfully with caseId: %d", wfCommentVo.getCaseId()));
		} else {
			wfCommentVo.setComments("Could not create the case");
		}
		return wfDao.addWFApplComment(wfCommentVo);
	}

	private EEMWFCommentVO buildComment(String customerId, int applId, String userId) {
		EEMWFCommentVO wfCommentVo = new EEMWFCommentVO();
		wfCommentVo.setCustomerId(customerId);
		wfCommentVo.setPrimaryId(String.valueOf(applId));
		wfCommentVo.setCreateTime(DateUtil.getCurrentDatetimeStamp());
		wfCommentVo.setCreateUserId(userId);
		wfCommentVo.setSource(EEMConstants.APPLICATION);
		wfCommentVo.setCommentSeqNbr(
				wfDao.getNextCommentSeqNumber(customerId, String.valueOf(applId), EEMConstants.APPLICATION));
		return wfCommentVo;
	}

	public boolean createActivities(String customerId, String userId, int caseId, List<String> errorCds,
			List<String> errorMsgs, int applId) {
		boolean isCreated = wfDao.createActivities(customerId, userId, caseId, errorCds, errorMsgs);
		addActivityCreationComment(customerId, applId, userId, isCreated);
		return isCreated;
	}

	private boolean addActivityCreationComment(String customerId, int applId, String userId, boolean isCreated) {
		EEMWFCommentVO wfCommentVo = buildComment(customerId, applId, userId);
		if (isCreated) {
			wfCommentVo.setComments("Activities got created successfully");
		} else {
			wfCommentVo.setComments("Could not create the activities");
		}
		return wfDao.addWFApplComment(wfCommentVo);
	}

	public List<WorkFlowDashletVO> deleteManualPopupQueues(Map<String, String> requestMap) {
		List<String> userIdList = new ArrayList<>();
		String custId = sessionHelper.getUserInfo().getCustomerId();
		String loggedInUserId = sessionHelper.getUserInfo().getUserId();

		String userId = requestMap.get("userId");
		String queueName = requestMap.get("queueName");
		String deleteAll = requestMap.get("deleteAll");
		String dashletUserId = requestMap.get("dashletUserId");

		String userLevel = wfDao.getUserLevel(loggedInUserId, custId);
		if (StringUtils.equals(EEMConstants.WF_SUPERVISOR, userLevel)) {
			userIdList.add(loggedInUserId);
			List<LabelValuePair> normalUserList = fetchAssignedNormalWfUsers(userId);
			if (CommonUtils.isNotEmpty(normalUserList)) {
				userIdList.addAll(normalUserList.stream().map(LabelValuePair::getValue).collect(Collectors.toList()));
			}
		}

		boolean isDeleted = wfDao.deleteManualPopupQueues(custId, userId, queueName, deleteAll, userIdList,
				loggedInUserId);
		if (!isDeleted) {
			LOG.error("Unable to delete manual popup queues, requestMap: {}", requestMap);
			throw new ApplicationException("Unable to delete manual popup queues!");
		}
		return fetchDashletsByUser(dashletUserId);
	}

	public Map<String, String> fetchManualPopupQueues() {
		List<String> userIdList = new ArrayList<>();
		String custId = sessionHelper.getUserInfo().getCustomerId();
		String loggedInUserId = sessionHelper.getUserInfo().getUserId();

		String userLevel = wfDao.getUserLevel(loggedInUserId, custId);
		if (StringUtils.equals(EEMConstants.WF_SUPERVISOR, userLevel)) {
			userIdList.add(loggedInUserId);
			List<LabelValuePair> normalUserList = fetchAssignedNormalWfUsers(loggedInUserId);
			if (CommonUtils.isNotEmpty(normalUserList)) {
				userIdList.addAll(normalUserList.stream().map(LabelValuePair::getValue).collect(Collectors.toList()));
			}
		}
		return wfDao.fetchManualPopupQueues(custId, userIdList);
	}

	public WorkFlowDashletVO buildManualPopupDashlet(Map<String, String> result) {
		int count = 0;
		int totalCount = 0;
		WorkFlowDashletVO manualPopupDashlet = new WorkFlowDashletVO();
		List<WorkFlowDashletVO> subItems = new ArrayList<>();
		manualPopupDashlet.setQueueName(EEMConstants.BLANK);
		manualPopupDashlet.setStatus("MANUAL POPUP");

		for (Entry<String, String> entry : result.entrySet()) {
			count = Integer.parseInt(entry.getValue().substring(entry.getValue().indexOf('_') + 1));
			WorkFlowDashletVO subItem = new WorkFlowDashletVO();
			subItem.setStatus(entry.getKey());
			subItem.setQueueName(entry.getValue().substring(0, entry.getValue().indexOf('_')));
			subItem.setCount(count);
			subItem.setManualPopup(true);
			subItems.add(subItem);
			totalCount += count;
		}
		manualPopupDashlet.setSubItems(subItems);
		manualPopupDashlet.setCount(totalCount);
		return manualPopupDashlet;
	}

	private void setHasAccessData(String userId, String custId, List<WorkFlowDashletVO> dashletData) {
		Map<String, Integer> userQueueAccess = wfDao.checkAccess(userId, custId);

		if (CommonUtils.isNotEmpty(userQueueAccess)) {
			for (WorkFlowDashletVO dashlet : dashletData) {
				if (isDashletOpenHoldOrAtRisk(dashlet) && CommonUtils.isNotEmpty(dashlet.getSubItems())) {
					for (WorkFlowDashletVO subItem : dashlet.getSubItems()) {
						subItem.setHasAccess(Objects.nonNull(userQueueAccess.get(subItem.getQueueName())));
					}
				}
			}
		}
	}

	private void setManualPopupData(String custId, List<WorkFlowDashletVO> dashletData) {
		List<String> manualPopupQueues = eemPersistance.getManualPopupQueues(custId);
		if (CommonUtils.isNotEmpty(manualPopupQueues)) {
			for (WorkFlowDashletVO dashlet : dashletData) {
				if (isDashletOpenHoldOrAtRisk(dashlet) && CommonUtils.isNotEmpty(dashlet.getSubItems())) {
					for (WorkFlowDashletVO subItem : dashlet.getSubItems()) {
						setManualPopupFlag(manualPopupQueues, subItem);
					}
				}
			}
		}
	}

	private void setManualPopupFlag(List<String> manualPopupQueues, WorkFlowDashletVO subItem) {
		if (manualPopupQueues.contains(subItem.getQueueName())) {
			subItem.setManualPopup(true);
		}
	}

	private boolean isDashletOpenHoldOrAtRisk(WorkFlowDashletVO dashlet) {
		return StringUtils.equals(dashlet.getStatus(), EEMConstants.OPEN)
				|| StringUtils.equals(dashlet.getStatus(), EEMConstants.ATRISK)
				|| StringUtils.equals(dashlet.getStatus(), EEMConstants.HOLD);
	}

}
