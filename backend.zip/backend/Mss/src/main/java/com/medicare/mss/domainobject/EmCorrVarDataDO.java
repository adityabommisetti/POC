package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EmCorrVarDataDO implements Cloneable {

	
	/*
	
	
	
	private String recordTypeDesc;
	
	
	private String letterDesc;
	private String requestDate;
	private String origMailDate;
	private String lastMailDate;
	private String deleteInd;
	private String recordStatus;
	private String createTime;
	private String createUserId;
	
	
	private String supplementalId;
	
	
		private String ltrNameWithDesc;
		private String dmsId;
		private String letterUploadedTime;
		private String letterAvailabilityInDB;
		private String source;
		
		private String rePrintType;
		
		
		private String printRequestDate;
		private String letterCreationTime;
		private ServletOutputStream servletOutputStream;
		private String printDate;
		private String responseDueDate;
		private String responseDate;
		private String reprintDate;	
		
		@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
		private String customerId;
	
		@ColumnMapper(columnName = "FILE_BATCH_ID", propertyName = "fileBatchId")
		private String fileBatchId;
		
		@ColumnMapper(columnName = "RECORD_TYPE", propertyName = "recordType")
		private String recordType;
		
		@ColumnMapper(columnName = "PRIMARY_ID", propertyName = "primaryId")
		private String primaryId;
		
		@ColumnMapper(columnName = "LETTER_NAME", propertyName = "letterName")
		private String letterName;
		
		
		
		@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
		private String lastUpdtTime;
		
		@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserId")
		private String lastUpdtUserId;
	*/	
		
		@ColumnMapper(columnName = "VARIABLE_ID", propertyName = "variableId")
		private String variableId;
	
		@ColumnMapper(columnName = "VARIABLE_SEQ_NBR", propertyName = "variableSeqNbr")
		private String    variableSeqNbr;
	
		@ColumnMapper(columnName = "VARIABLE_DESC", propertyName = "variableDesc")
		private String variableDesc;
		
		@ColumnMapper(columnName = "VARIABLE_DATA", propertyName = "variableData")
		private String variableData;
		
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
    

}
