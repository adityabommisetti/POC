/**
 * 
 */
package com.medicare.mss.daoImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMBillingInvDAO;
import com.medicare.mss.domainobject.EEMBillingInvCommentDO;
import com.medicare.mss.domainobject.EEMBillingInvHeaderDtlsDO;
import com.medicare.mss.domainobject.EEMBillingInvoiceDtlsDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.security.vo.EEMBillingInvCommentVO;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.PaginationQueryHelper;
import com.medicare.mss.util.SQLHelper;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.DataBaseField;
import com.medicare.mss.vo.EEMBillingInvHeaderDtlsVO;
import com.medicare.mss.vo.EEMBillingInvSummaryVO;
import com.medicare.mss.vo.EEMBillingInvoiceDtlsVO;
import com.medicare.mss.vo.EEMBillingInvoiceSearchVO;
import com.medicare.mss.vo.PageableVO;

/**
 * @author DU20098149
 *
 */
@Repository
public class EEMBillingInvDAOImpl implements EEMBillingInvDAO {

	@Autowired
	private EEMCodeCache cache;

	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public PageableVO searchBillingInvoice(EEMBillingInvoiceSearchVO searchVO, String custId, boolean isPagination) {
		List<EEMBillingInvHeaderDtlsDO> billingInvHeaderDtlsDOs = new ArrayList<>();
		Map<String, Object> params = new HashMap<>();
		PageableVO response = new PageableVO();
		StringBuilder query = buildBillingInvoiceSearchQuery(searchVO, custId, params, isPagination);

		try {
			if (isPagination) {
				DataBaseField[] conds = new DataBaseField[3];
				for (int i = 0; i < conds.length; i++) {
					conds[i] = new DataBaseField();
				}
				conds[0].setFieldName("IH.DUE_DATE");
				conds[0].setStringValue(searchVO.getDueDate());
				conds[0].setSign(" <");

				conds[1].setFieldName("IH.INVOICE_ID");
				conds[1].setStringValue(searchVO.getSearchInvoiceId());

				conds[2].setFieldName("IH.INVOICE_NBR");
				conds[2].setStringValue(searchVO.getSearchInvoiceNbr());

				StringBuilder pageCond = PaginationQueryHelper.pagingElements(conds, params);
				query.append(pageCond);
			}

			query.append(" ORDER BY IH.CUSTOMER_ID, IH.DUE_DATE DESC, IH.INVOICE_ID, IH.INVOICE_NBR ");
			query.append(" FETCH FIRST ").append(EEMConstants.DB_MAX_RECORD_FETCH).append(" ROWS ONLY ");

			billingInvHeaderDtlsDOs = namedParameterJdbcTemplate.query(
					query.toString(), params,
					new DomainPropertyRowMapper<EEMBillingInvHeaderDtlsDO>(EEMBillingInvHeaderDtlsDO.class));
			
			if (!CollectionUtils.isEmpty(billingInvHeaderDtlsDOs)) {
				if (billingInvHeaderDtlsDOs.size() > 100) {
					billingInvHeaderDtlsDOs.remove(billingInvHeaderDtlsDOs.size() - 1);
					response.setNextPage(true);
				}
			}
			response.setContent(billingInvHeaderDtlsDOs);
			return response;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}

	}

	private StringBuilder buildBillingInvoiceSearchQuery(EEMBillingInvoiceSearchVO searchVO, String custId,
			Map<String, Object> params, boolean isPagination) {
		StringBuilder query;

		if (StringUtils.equalsIgnoreCase("G", searchVO.getSearchInvoiceGroup())) {
			query = CommonUtils.buildQueryBuilder(
					"SELECT IH.CUSTOMER_ID, IH.INVOICE_NBR, IH.INVOICE_TYPE, IH.INVOICE_ID, D.GROUP_NAME,",
					"IH.MBR_GRP_IND, IH.DUE_DATE, IH.GL_PROCESSED_IND, IH.BILL_THRU_DATE, IH.INVOICE_STATUS,",
					"IH.MEMBER_CNT, IH.FREQUENCY_CD, IH.INVOICE_AMT, IH.PAYMENT_AMT, IH.ADJUSTMENT_AMT,",
					"IH.LAST_ITEM_NBR, IH.WIP_TIME, IH.WIP_USERID,",
					"IH.CREATE_TIME, IH.CREATE_USERID, IH.LAST_UPDT_TIME, IH.LAST_UPDT_USERID",
					"FROM BBB_INVOICE_HEADER IH JOIN EM_GRP_NAME D ON D.CUSTOMER_ID = IH.CUSTOMER_ID",
					"AND D.GRP_ID = IH.INVOICE_ID");
		} else {
			query = CommonUtils.buildQueryBuilder(
					"SELECT IH.CUSTOMER_ID, IH.INVOICE_NBR, IH.INVOICE_TYPE, IH.INVOICE_ID, D.LAST_NAME, D.FIRST_NAME,",
					" IH.MBR_GRP_IND, IH.DUE_DATE, IH.GL_PROCESSED_IND, IH.BILL_THRU_DATE, IH.INVOICE_STATUS,",
					"IH.MEMBER_CNT, IH.FREQUENCY_CD, IH.INVOICE_AMT, IH.PAYMENT_AMT, IH.ADJUSTMENT_AMT,",
					"IH.LAST_ITEM_NBR, IH.WIP_TIME, IH.WIP_USERID,",
					"IH.CREATE_TIME, IH.CREATE_USERID, IH.LAST_UPDT_TIME, IH.LAST_UPDT_USERID",
					"FROM BBB_INVOICE_HEADER IH JOIN EM_MBR_DEMOGRAPHIC D ON D.CUSTOMER_ID = IH.CUSTOMER_ID",
					"AND D.MEMBER_ID = IH.INVOICE_ID AND D.CURRENT_IND = 'Y' AND D.OVERRIDE_IND = 'N'");
		}

		query.append(" WHERE IH.CUSTOMER_ID = :customerId");
		params.put("customerId", custId);

		if (StringUtils.isNotBlank(searchVO.getSearchInvoiceNbr()) && !isPagination) {
			query.append(" AND IH.INVOICE_NBR = :invoiceNbr");
			params.put("invoiceNbr", searchVO.getSearchInvoiceNbr());
		}
		if (StringUtils.isNotBlank(searchVO.getSearchMemberId()) && !isPagination) {
			query.append(" AND IH.INVOICE_ID = :memberId");
			params.put("memberId", searchVO.getSearchMemberId());
		}
		if (StringUtils.isNotBlank(searchVO.getSearchInvoiceStatus())) {
			query.append(" AND IH.INVOICE_STATUS = :invoiceStatus");
			params.put("invoiceStatus", searchVO.getSearchInvoiceStatus());
		}
		if (StringUtils.isNotBlank(searchVO.getSearchInvoiceGroup())) {
			query.append(" AND IH.INVOICE_TYPE in (:invoiceTypes) ");
			params.put("invoiceTypes", cache.getInvTypeList(searchVO.getSearchInvoiceGroup()));
		}
		if (StringUtils.isNotBlank(searchVO.getSearchInvoiceType())) {
			query.append(" AND IH.INVOICE_TYPE = :invoiceType");
			params.put("invoiceType", searchVO.getSearchInvoiceType());
		}

		if (StringUtils.isNotBlank(searchVO.getSearchSupplementalId())) {
			query.append(" AND D.MEMBER_ID IN (SELECT E.MEMBER_ID FROM EM_MBR_ENROLLMENT E")
					.append(" WHERE E.CUSTOMER_ID = D.CUSTOMER_ID").append(" AND E.OVERRIDE_IND = 'N'")
					.append(" AND E.SUPPLEMENTAL_ID = :searchSupplementId)");
			params.put("searchSupplementId", searchVO.getSearchSupplementalId());
		}

		if (StringUtils.isNotBlank(searchVO.getSearchLastName())) {

			if (StringUtils.equalsIgnoreCase("G", searchVO.getSearchInvoiceGroup())) {
				query.append(" AND D.GROUP_NAME = :grpName");
			} else {
				query.append(" AND D.LAST_NAME = :grpName");
			}
			params.put("grpName", searchVO.getSearchLastName());
		}

		if (StringUtils.isNotBlank(searchVO.getSearchMedicareId())) {
			query.append(" AND IH.INVOICE_ID IN (SELECT DSI.MEMBER_ID FROM EM_MBR_DSINFO DSI")
					.append(" WHERE DSI.CUSTOMER_ID = IH.CUSTOMER_ID").append(" AND DSI.OVERRIDE_IND = 'N'")
					.append(" AND UPPER(DSI.DS_CD) = :dsCd").append(" AND DSI.DS_VALUE = :dsValue)");

			params.put("dsCd", StringUtils.upperCase(StringUtil.isHicOrMbi(searchVO.getSearchMedicareId())));
			params.put("dsValue", searchVO.getSearchMedicareId());
		}

		return query;

	}

	@Override
	public EEMBillingInvSummaryVO getInvSummary(String customerId, String memberId) {
		String searchInvoiceGroup = "M";
		Map<String, Object> params = new HashMap<>();
		try {
			String sql = CommonUtils.buildQuery(
					"SELECT SUM(INVOICE_AMT) AS INVOICE_AMT, SUM(PAYMENT_AMT) AS PAYMENT_AMT,",
					"SUM(ADJUSTMENT_AMT) AS ADJUSTMENT_AMT FROM BBB_INVOICE_HEADER WHERE",
					"CUSTOMER_ID = :customerId AND INVOICE_ID = :memberId",
					"AND (INVOICE_AMT + ADJUSTMENT_AMT + PAYMENT_AMT) != 0 AND INVOICE_TYPE in (:invTypeList)");

			List<String> invTypeList = cache.getInvTypeList(searchInvoiceGroup);
			params.put("customerId", customerId);
			params.put("memberId", memberId);
			params.put("invTypeList", invTypeList);

			return namedParameterJdbcTemplate.query(sql, params, rs -> {
				EEMBillingInvSummaryVO billingInvSummaryVO = new EEMBillingInvSummaryVO();
				if (rs.next()) {
					billingInvSummaryVO.setInvoiceAmt(rs.getDouble("INVOICE_AMT"));
					billingInvSummaryVO.setAdjustmentAmt(rs.getDouble("ADJUSTMENT_AMT"));
					billingInvSummaryVO.setPaymentAmt(rs.getDouble("PAYMENT_AMT"));
				}
				return billingInvSummaryVO;
			});

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public List<EEMBillingInvoiceDtlsDO> getBillInvoiceDetails(String customerId, String invoiceNbr,
			String billThrDate) {
		Map<String, String> params = new HashMap<>();

		String sql = CommonUtils.buildQuery("SELECT DET.CUSTOMER_ID, DET.INVOICE_NBR, DET.ITEM_NBR, DET.ADD_NBR,",
				"DET.CHECK_NBR, DET.ITEM_DESC, DET.LINE_STATUS, DET.GRP_ID, GN.GROUP_NAME,",
				"DET.MEMBER_ID, DET.PRODUCT_ID, PN.PRODUCT_NAME,",
				"DET.SUBPRODUCT_ID, SP.SUBPRODUCT_DESC, DET.FUNCTION_CD, DET.BANK_ACCT_CD, FC.LONG_DESC,",
				"DET.DETAIL_AMT, DET.XREF_INVOICE_NBR,",
				"DET.PAY_SOURCE_TYPE, DET.PAY_BATCH_DATE, DET.PAY_BATCH_SEQ_NBR, DET.PAY_ITEM_NBR,",
				"DET.CREATE_TIME, DET.CREATE_USERID, DET.LAST_UPDT_TIME, DET.LAST_UPDT_USERID",
				"FROM BBB_INVOICE_DETAIL DET LEFT OUTER JOIN BBB_FUNCTION_CODE FC",
				"ON DET.CUSTOMER_ID = FC.CUSTOMER_ID AND DET.FUNCTION_CD = FC.FUNCTION_CD",
				"LEFT OUTER JOIN EM_GRP_NAME GN ON DET.CUSTOMER_ID = GN.CUSTOMER_ID AND DET.GRP_ID = GN.GRP_ID",
				"AND :effDate BETWEEN GN.GRPNAME_START_DATE AND GN.GRPNAME_END_DATE LEFT OUTER JOIN EM_PRODUCT_NAME PN",
				"ON DET.CUSTOMER_ID = PN.CUSTOMER_ID AND DET.PRODUCT_ID = PN.PRODUCT_ID",
				"AND :effDate BETWEEN PN.PRODNAME_START_DATE AND PN.PRODNAME_END_DATE LEFT OUTER JOIN BBB_SUB_PRODUCT SP",
				"ON DET.CUSTOMER_ID = SP.CUSTOMER_ID AND DET.PRODUCT_ID = SP.PRODUCT_ID",
				"AND DET.SUBPRODUCT_ID = SP.SUBPRODUCT_ID",
				"AND :effDate BETWEEN SP.SUBPRODUCT_START_DATE AND SP.SUBPRODUCT_END_DATE",
				"WHERE DET.CUSTOMER_ID = :custId AND DET.INVOICE_NBR = :invNbr");

		params.put("custId", StringUtils.trimToEmpty(customerId));
		params.put("invNbr", StringUtils.trimToEmpty(invoiceNbr));
		params.put("effDate", StringUtils.trimToEmpty(billThrDate));

		try {
			return namedParameterJdbcTemplate.query(sql, params,
					new DomainPropertyRowMapper<EEMBillingInvoiceDtlsDO>(EEMBillingInvoiceDtlsDO.class));
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}

	}

	public String getBillThruDt(String customerId, String invoiceNbr) {
		String sql = CommonUtils.buildQuery("SELECT BILL_THRU_DATE FROM BBB_INVOICE_HEADER",
				"WHERE CUSTOMER_ID = ? AND INVOICE_NBR = ? FETCH FIRST ROW ONLY");
		try {
			return jdbcTemplate.queryForObject(sql, String.class, customerId, invoiceNbr);
		} catch (EmptyResultDataAccessException exp) {
			throw new ApplicationException(exp, "No billThru date found for provided customer and invoiceNbr!");
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	public String getPlanId(String customerId, String memberId) {
		String sql = CommonUtils.buildQuery("SELECT PLAN_ID FROM EM_MBR_ENROLLMENT WHERE CUSTOMER_ID = ?",
				"AND MEMBER_ID = ? AND OVERRIDE_IND = 'N' AND ? BETWEEN EFF_START_DATE AND EFF_END_DATE",
				"FETCH FIRST ROW ONLY");
		String todayDate = DateUtil.getTodaysDate("yyyyMMdd");
		try {
			return jdbcTemplate.queryForObject(sql, String.class, customerId, memberId, todayDate);
		} catch (EmptyResultDataAccessException exp) {
			return EEMConstants.BLANK;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public List<EEMBillingInvCommentDO> getBillInvoiceComments(String custId, String invNbr) {
		String sql = CommonUtils.buildQuery("SELECT CUSTOMER_ID, INVOICE_NBR, COMMENT_SEQ_NBR,",
				"COMMENT AS MBR_COMMENTS, CREATE_TIME, CREATE_USERID FROM BBB_INVOICE_COMMENT",
				"WHERE CUSTOMER_ID = ? AND INVOICE_NBR = ? ORDER BY COMMENT_SEQ_NBR DESC");
		try {
			return jdbcTemplate.query(sql,
					new DomainPropertyRowMapper<EEMBillingInvCommentDO>(EEMBillingInvCommentDO.class), custId, invNbr);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public String getMedicareIdFromDSInfo(String customerId, String memberId, String dsCode) {
		String medicareId;
		String query = CommonUtils.buildQuery("SELECT TRIM(DS_VALUE) FROM EM_MBR_DSINFO",
				"WHERE DS_CD = ? AND OVERRIDE_IND = 'N' AND EFF_END_DATE = '99999999'",
				"AND MEMBER_ID = ? AND CUSTOMER_ID = ?");
		try {
			medicareId = jdbcTemplate.queryForObject(query, String.class, dsCode, memberId, customerId);
		} catch (EmptyResultDataAccessException exp) {
			medicareId = null;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}

		return medicareId;
	}

	@Override
	public boolean getNextMbrComment(EEMBillingInvCommentVO newCommentVO) {
		boolean success = false;
		String sql = CommonUtils.buildQuery(
				"SELECT MAX(COMMENT_SEQ_NBR)+1 AS SEQ_NBR, CURRENT_TIMESTAMP AS CURRENT_TIME",
				"FROM BBB_INVOICE_COMMENT WHERE CUSTOMER_ID = ? AND INVOICE_NBR = ?");

		try {
			jdbcTemplate.query(sql, rs -> {
				if (Objects.nonNull(rs.getInt("SEQ_NBR"))) {
					newCommentVO.setCommentSeqNbr(rs.getInt("SEQ_NBR"));
					newCommentVO.setCreateTime(rs.getString("CURRENT_TIME"));
				} else {
					newCommentVO.setCommentSeqNbr(1);
					newCommentVO.setCreateTime(DateUtil.getCurrentDatetimeStamp());
				}
			}, newCommentVO.getCustomerId(), newCommentVO.getInvoiceNbr());
			success = true;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
		return success;
	}

	@Override
	public int insertBillInvoiceComment(EEMBillingInvCommentVO newCommentVO) {
		int cnt = 0;
		String sql = CommonUtils.buildQuery(
				"INSERT INTO BBB_INVOICE_COMMENT(CUSTOMER_ID, INVOICE_NBR, COMMENT_SEQ_NBR,",
				"COMMENT, CREATE_TIME, CREATE_USERID) VALUES(?,?,?,?,?,?)");

		try {
			cnt = jdbcTemplate.update(sql, newCommentVO.getCustomerId(), newCommentVO.getInvoiceNbr(),
					newCommentVO.getCommentSeqNbr(), newCommentVO.getMbrComments(), newCommentVO.getCreateTime(),
					newCommentVO.getCreateUserId());
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_INSERT);
		}
		return cnt;
	}

	@Override
	public String getEligibleLineAmount(String customerId, String invoiceNbr, String itemNumber) {
		String sql = CommonUtils.buildQuery("SELECT SUM(DETAIL_AMT) FROM BBB_INVOICE_DETAIL WHERE",
				"ITEM_NBR = ? AND INVOICE_NBR= ? AND  CUSTOMER_ID = ?");
		try {
			return jdbcTemplate.query(sql, rs -> {
				String totalAmt = EEMConstants.BLANK;
				if (rs.next()) {
					totalAmt = rs.getString(1);
				}
				return totalAmt;
			}, itemNumber, invoiceNbr, customerId);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public int insertBillInvoiceDetail(EEMBillingInvoiceDtlsVO detailVO) {
		int cnt = 0;
		String sql = CommonUtils.buildQuery(
				"INSERT INTO BBB_INVOICE_DETAIL(CUSTOMER_ID, INVOICE_NBR, ITEM_NBR, ADD_NBR,",
				"CHECK_NBR, ITEM_DESC, LINE_STATUS, GRP_ID, MEMBER_ID, PRODUCT_ID, SUBPRODUCT_ID,",
				"FUNCTION_CD, BANK_ACCT_CD, DETAIL_AMT, XREF_INVOICE_NBR, PAY_SOURCE_TYPE, PAY_BATCH_DATE,",
				"PAY_BATCH_SEQ_NBR, PAY_ITEM_NBR, CREATE_TIME, CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID",
				") VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

		try {
			String paySourceDescription = cache.getCode(StringUtils.trimToEmpty(detailVO.getPaySourceDesc()),
					cache.getLstPaySource());
			cnt = jdbcTemplate.update(sql, detailVO.getCustomerId(), detailVO.getInvoiceNbr(), detailVO.getItemNbr(),
					detailVO.getAddNbr(), detailVO.getCheckNbr(), detailVO.getItemDesc(), detailVO.getLineStatus(),
					detailVO.getGrpId(), detailVO.getMemberId(), detailVO.getProductId(), detailVO.getSubProductId(),
					detailVO.getFunctionCd(), detailVO.getBankAcctCd(), detailVO.getDetailAmt(),
					SQLHelper.ensureInteger(detailVO.getXrefInvoiceNbr()),
					StringUtils.trimToEmpty(paySourceDescription), StringUtils.trimToEmpty(detailVO.getPayBatchDate()),
					SQLHelper.ensureInteger(StringUtils.trimToEmpty(detailVO.getPayBatchSeqNbr())),
					SQLHelper.ensureInteger(StringUtils.trimToEmpty(detailVO.getPayItemNbr())),
					detailVO.getCreateTime(), detailVO.getCreateUserId(), detailVO.getLastUpdtTime(),
					detailVO.getLastUpdtUserId());
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_INSERT);
		}
		return cnt;
	}

	@Override
	public int getNextAddNbr(String customerId, String invoiceNbr, int itemNbr) {
		String sql = CommonUtils.buildQuery("SELECT MAX(ADD_NBR) AS ADD_NBR FROM BBB_INVOICE_DETAIL",
				"WHERE CUSTOMER_ID = ? AND INVOICE_NBR = ? AND ITEM_NBR = ?");
		try {
			return jdbcTemplate.query(sql, rs -> {
				int addNbr = -1;
				if (rs.next()) {
					addNbr = rs.getInt("ADD_NBR");
					addNbr += 1;
				}
				return addNbr;
			}, customerId, invoiceNbr, itemNbr);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public int updateBillInvoiceTransferHeader(EEMBillingInvHeaderDtlsVO headerVO) {
		int sqlCnt = 0;
		StringBuilder sql = CommonUtils.buildQueryBuilder(
				"UPDATE BBB_INVOICE_HEADER SET PAYMENT_AMT = ?, GL_PROCESSED_IND = ?,",
				"LAST_UPDT_USERID = ?, LAST_UPDT_TIME = ?");

		List<Object> params = new ArrayList<>();
		params.add(SQLHelper.ensureDouble(headerVO.getPaymentAmt()));
		params.add(headerVO.getGlProcessedInd());
		params.add(headerVO.getLastUpdtUserId());
		params.add(headerVO.getLastUpdtTime());

		if (StringUtils.trimToEmpty(headerVO.getInvoiceStatus()).equals(EEMConstants.EEM_BILL_INVOICE_LOCKED)) {
			sql.append(", INVOICE_STATUS = ?");
			params.add(EEMConstants.EEM_BILL_INVOICE_REOPENED);
		}

		sql.append(" WHERE CUSTOMER_ID = ? AND INVOICE_NBR = ?");
		params.add(headerVO.getCustomerId());
		params.add(headerVO.getInvoiceNbr());

		try {
			sqlCnt = jdbcTemplate.update(sql.toString(), params.toArray());
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}
		return sqlCnt;
	}

	@Override
	public int insertBillPaymentDtlInvoice(EEMBillingInvoiceDtlsVO detailVO) {
		int cnt = 0;
		String sql = CommonUtils.buildQuery(
				"INSERT INTO BBB_PAYMENT_DTL_INVOICE(CUSTOMER_ID, PAY_SOURCE_TYPE, BATCH_DATE, BATCH_SEQ_NBR,",
				"ITEM_NBR, INVOICE_NBR, APPLIED_AMT, CREATE_TIME, CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID)",
				"VALUES(?,?,?,?,?,?,?,?,?,?,?)");

		String paySourceDescription = cache.getCode(StringUtils.trimToEmpty(detailVO.getPaySourceDesc()),
				cache.getLstPaySource());
		double appliedAmt = Double.parseDouble(StringUtils.trimToEmpty(detailVO.getDetailAmt())) * -1;

		try {
			cnt = jdbcTemplate.update(sql, StringUtils.trimToEmpty(detailVO.getCustomerId()),
					StringUtils.trimToEmpty(paySourceDescription), StringUtils.trimToEmpty(detailVO.getPayBatchDate()),
					StringUtils.trimToEmpty(detailVO.getPayBatchSeqNbr()), detailVO.getPayItemNbr(),
					StringUtils.trimToEmpty(detailVO.getInvoiceNbr()), String.valueOf(appliedAmt),
					StringUtils.trimToEmpty(detailVO.getCreateTime()),
					StringUtils.trimToEmpty(detailVO.getCreateUserId()),
					StringUtils.trimToEmpty(detailVO.getLastUpdtTime()),
					StringUtils.trimToEmpty(detailVO.getLastUpdtUserId()));
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_INSERT);
		}
		return cnt;
	}

	@Override
	public int getRecordsCount(String customerId, String invoiceNumber, String itemNumber) {
		String sql = CommonUtils.buildQuery("SELECT COUNT(*) FROM BBB_INVOICE_DETAIL WHERE ITEM_NBR = ? AND",
				"INVOICE_NBR= ? AND  CUSTOMER_ID = ?");
		try {
			return jdbcTemplate.query(sql, rs -> {
				int count = 0;
				if (rs.next()) {
					count = rs.getInt(1);
				}
				return count;
			}, itemNumber, invoiceNumber, customerId);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public List<EEMBillingInvoiceDtlsDO> getBillMbrGrpList(String customerId, String id, String firstName,
			String lastName) {
		List<String> params = new ArrayList<>();
		StringBuilder sql = CommonUtils.buildQueryBuilder(
				"SELECT TRIM(MEMBER_ID), TRIM(FIRST_NAME), TRIM(LAST_NAME) FROM EM_MBR_DEMOGRAPHIC",
				"WHERE CUSTOMER_ID = ? AND OVERRIDE_IND = 'N' AND CURRENT_IND = 'Y'");

		params.add(customerId);

		if (StringUtils.isNotBlank(id)) {
			sql.append(" AND MEMBER_ID = ?");
			params.add(StringUtils.trimToEmpty(id));
		}
		if (StringUtils.isNotBlank(firstName)) {
			sql.append(" AND FIRST_NAME LIKE ").append("?%");
			params.add(firstName);
		}
		if (StringUtils.isNotBlank(lastName)) {
			sql.append(" AND LAST_NAME LIKE ").append("?%");
			params.add(lastName);
		}
		sql.append(" ORDER BY MEMBER_ID");

		try {
			List<EEMBillingInvoiceDtlsDO> billInvDelsDOs = new ArrayList<>();
			if (params.size() > 1) {
				return jdbcTemplate.query(sql.toString(), params.toArray(), rs -> {
					EEMBillingInvoiceDtlsDO billInvDelsVO;
					while (rs.next()) {
						billInvDelsVO = new EEMBillingInvoiceDtlsDO();
						billInvDelsVO.setGrpId(rs.getString(1));
						billInvDelsVO.setGroupName(
								new StringBuilder(rs.getString(2)).append(" ").append(rs.getString(3)).toString());
						billInvDelsDOs.add(billInvDelsVO);
					}
					return billInvDelsDOs;
				});
			} else {
				return billInvDelsDOs;
			}
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public int insertBillInvoiceHeader(EEMBillingInvHeaderDtlsVO headerVO) {
		int cnt = 0;
		String sql = CommonUtils.buildQuery(
				"INSERT INTO BBB_INVOICE_HEADER(CUSTOMER_ID, INVOICE_NBR, INVOICE_TYPE, INVOICE_ID, MBR_GRP_IND, DUE_DATE, GL_PROCESSED_IND,",
				"BILL_THRU_DATE, INVOICE_STATUS, MEMBER_CNT, FREQUENCY_CD, INVOICE_AMT, PAYMENT_AMT, ADJUSTMENT_AMT, LAST_ITEM_NBR,",
				"WIP_TIME, WIP_USERID, CREATE_TIME, CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID)",
				"VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		try {
			cnt = jdbcTemplate.update(sql, StringUtils.trimToEmpty(headerVO.getCustomerId()), headerVO.getInvoiceNbr(),
					StringUtils.trimToEmpty(headerVO.getInvoiceType()),
					StringUtils.trimToEmpty(headerVO.getInvoiceId()), StringUtils.trimToEmpty(headerVO.getMbrGrpInd()),
					DateUtil.changedDateFormatForMonth(StringUtils.trimToEmpty(headerVO.getDueDate())),
					StringUtils.trimToEmpty(headerVO.getGlProcessedInd()),
					DateUtil.changedDateFormatForMonth(StringUtils.trimToEmpty(headerVO.getBillThruDate())),
					StringUtils.trimToEmpty(headerVO.getInvoiceStatus()),
					StringUtils.trimToEmpty(headerVO.getMemberCnt()),
					StringUtils.trimToEmpty(headerVO.getFrequencyCd()),
					StringUtils.trimToEmpty(headerVO.getInvoiceAmt()),
					StringUtils.trimToEmpty(headerVO.getPaymentAmt()),
					StringUtils.trimToEmpty(headerVO.getAdjustmentAmt()),
					StringUtils.trimToEmpty(headerVO.getLastItemNbr()), StringUtils.trimToEmpty(headerVO.getWipTime()),
					StringUtils.trimToEmpty(headerVO.getWipUserId()), StringUtils.trimToEmpty(headerVO.getCreateTime()),
					StringUtils.trimToEmpty(headerVO.getCreateUserId()),
					StringUtils.trimToEmpty(headerVO.getLastUpdtTime()),
					StringUtils.trimToEmpty(headerVO.getLastUpdtUserId()));
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_INSERT);
		}
		return cnt;
	}

	@Override
	public int getNextItemNbr(String customerId, String invoiceNbr) {
		String sql = CommonUtils.buildQuery("SELECT MAX(ITEM_NBR) AS ITEM_NBR FROM BBB_INVOICE_DETAIL",
				"WHERE CUSTOMER_ID = ? AND INVOICE_NBR = ?");
		try {
			return jdbcTemplate.query(sql, rs -> {
				int itemNbr = -1;
				if (rs.next()) {
					itemNbr = rs.getInt("ITEM_NBR");
					itemNbr += 1;
				}
				return itemNbr;
			}, customerId, invoiceNbr);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public int updateBillInvoiceHeader(EEMBillingInvoiceDtlsVO detailVO, int itemNbr, String invoiceStatus) {
		List<String> params = new ArrayList<>();
		StringBuilder sql = CommonUtils.buildQueryBuilder(
				"UPDATE BBB_INVOICE_HEADER SET ADJUSTMENT_AMT = ADJUSTMENT_AMT + ?,",
				"WIP_USERID = ?, WIP_TIME = ?, LAST_UPDT_USERID = ?, LAST_UPDT_TIME = ?");

		params.add(String.valueOf(SQLHelper.ensureDouble(detailVO.getDetailAmt())));
		params.add(detailVO.getLastUpdtUserId());
		params.add(detailVO.getLastUpdtTime());
		params.add(detailVO.getLastUpdtUserId());
		params.add(detailVO.getLastUpdtTime());

		if (itemNbr != -1) {
			sql.append(", LAST_ITEM_NBR = ?");
			params.add(String.valueOf(itemNbr));
		}
		if (StringUtil.nonNullTrim(invoiceStatus).equals(EEMConstants.EEM_BILL_INVOICE_LOCKED)) {
			sql.append(", INVOICE_STATUS = ?");
			params.add(EEMConstants.EEM_BILL_INVOICE_REOPENED);
		}

		sql.append(" WHERE CUSTOMER_ID = ? AND INVOICE_NBR = ?");
		params.add(detailVO.getCustomerId());
		params.add(detailVO.getInvoiceNbr());

		try {
			return jdbcTemplate.update(sql.toString(), params.toArray());
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}
	}

	@Override
	public EEMBillingInvHeaderDtlsDO getBillInvoiceHeader(String customerId, String invoiceNbr,
			String searchInvoiceGroup) {

		Map<String, String> params = new HashMap<>();

		String sql = CommonUtils.buildQuery(
				"SELECT IH.CUSTOMER_ID, IH.INVOICE_NBR, IH.INVOICE_TYPE, IH.INVOICE_ID, D.LAST_NAME, D.FIRST_NAME,",
				"IH.MBR_GRP_IND, IH.DUE_DATE, IH.GL_PROCESSED_IND, IH.BILL_THRU_DATE, IH.INVOICE_STATUS,",
				"IH.MEMBER_CNT, IH.FREQUENCY_CD, IH.INVOICE_AMT, IH.PAYMENT_AMT, IH.ADJUSTMENT_AMT,",
				"IH.LAST_ITEM_NBR, IH.WIP_TIME, IH.WIP_USERID, IH.CREATE_TIME, IH.CREATE_USERID, IH.LAST_UPDT_TIME, IH.LAST_UPDT_USERID",
				"FROM BBB_INVOICE_HEADER IH JOIN EM_MBR_DEMOGRAPHIC D ON D.CUSTOMER_ID = IH.CUSTOMER_ID",
				"AND D.MEMBER_ID = IH.INVOICE_ID AND D.CURRENT_IND = 'Y' AND D.OVERRIDE_IND = 'N'",
				"WHERE IH.CUSTOMER_ID = :customerId AND IH.INVOICE_NBR = :invoiceNbr");

		params.put("customerId", customerId);
		params.put("invoiceNbr", invoiceNbr);

		try {
			return namedParameterJdbcTemplate.queryForObject(sql, params,
					new DomainPropertyRowMapper<EEMBillingInvHeaderDtlsDO>(EEMBillingInvHeaderDtlsDO.class));
		} catch (EmptyResultDataAccessException exp) {
			throw new ApplicationException(exp, "Invoice data not found!");
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

}
