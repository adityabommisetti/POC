package com.medicare.mss.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.caching.EEMPersistence;
import com.medicare.mss.caching.EEMProfileSettings;
import com.medicare.mss.constants.EEMProfileConstants;
import com.medicare.mss.dao.EEMBillingEntryDAO;
import com.medicare.mss.domainobject.EEMBilPaymentEntryDO;
import com.medicare.mss.domainobject.EEMBilPaymentEntryDtlsDO;
import com.medicare.mss.domainobject.EEMBilPaymentEntryInvDO;
import com.medicare.mss.domainobject.EEMProfileItemDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.util.NumberFormatter;
import com.medicare.mss.vo.EEMBilPaymentEntryDtlsVO;
import com.medicare.mss.vo.EEMBilPaymentEntryInvVO;
import com.medicare.mss.vo.EEMBilPaymentEntryMasterVO;
import com.medicare.mss.vo.EEMBilPaymentEntryNewVO;
import com.medicare.mss.vo.EEMBilPaymentEntryUpdateVO;
import com.medicare.mss.vo.EEMBilPaymentEntryVO;
import com.medicare.mss.vo.PageableVO;

@Service
@Transactional(rollbackFor = ApplicationException.class)
public class EEMBillingEntryService {

	@Autowired
	private EEMBillingEntryDAO billingEntryDao;

	@Autowired
	private CacheService sessionHelper;

	@Autowired
	EEMProfileSettings eemProfileSettings;

	@Autowired
	private EEMPersistence eemPer;

	@Autowired
	private EEMCodeCache codeCache;

	@Autowired
	EEMBillingMbrPaymentService paymentService;

	private static final Logger LOG = LoggerFactory.getLogger(EEMBillingEntryService.class);

	@SuppressWarnings("unchecked")
	public EEMBilPaymentEntryMasterVO billPaymentEntrySearch(EEMBilPaymentEntryVO paymentEntrySearchVo) {
		paymentEntrySearchVo.setCustomerId(sessionHelper.getUserInfo().getCustomerId());
		EEMBilPaymentEntryMasterVO paymntEntryMasterVO = initializePaymentEntryResVO();
		
		List<EEMBilPaymentEntryVO> paymentsList = new ArrayList<>();
		paymentEntrySearchVo = (EEMBilPaymentEntryVO) CommonUtils.trimObject(paymentEntrySearchVo);
		PageableVO pageableResult = billingEntryDao.billPaymentEntrySearch(paymentEntrySearchVo, false);
		List<EEMBilPaymentEntryVO> billPmntEntrySearchList = (List<EEMBilPaymentEntryVO>) pageableResult
				.getContent();
		CommonUtils.copyList(billPmntEntrySearchList, paymentsList, EEMBilPaymentEntryVO.class);
		List<LabelValuePair> payTypesList = new ArrayList<>();
		/* To debug in preprod*/
		try {
			payTypesList = eemPer.loadBillingPaySourceTypes();
		} catch (Exception exp) {
			LOG.error("Failed to load BillingPaySourceTypes");
			LOG.error("An exception occurred in billPaymentEntrySearch->BillingPaySourceTypes:", exp);
		}
		Map<String, String> payTypesMap = new HashMap<>();
		payTypesList.forEach(ref -> payTypesMap.put(ref.getValue(), ref.getLabel()));
		paymentsList.forEach(ref -> ref.setPaySourceDesc(payTypesMap.get(ref.getPaySource())));
		paymntEntryMasterVO.getBillingPaymentslist().addAll(paymentsList);
		if (!CollectionUtils.isEmpty(paymentsList)) {
			List<EEMBilPaymentEntryDtlsVO> paymntEntryDetailsList = billPaymentEntryDetails(paymentsList.get(0));
			paymntEntryMasterVO.getBillingPaymentDtlsList().addAll(paymntEntryDetailsList);
		}
		paymntEntryMasterVO.setNextPage(pageableResult.isNextPage());
		return paymntEntryMasterVO;
	}

	public List<EEMBilPaymentEntryDtlsVO> billPaymentEntryDetails(EEMBilPaymentEntryVO eemBilPaymntEntryVo) {
		eemBilPaymntEntryVo.setCustomerId(sessionHelper.getUserInfo().getCustomerId());
		List<EEMBilPaymentEntryDtlsVO> paymntEntryDtlsListVO = new ArrayList<>();
		eemBilPaymntEntryVo = (EEMBilPaymentEntryVO) CommonUtils.trimObject(eemBilPaymntEntryVo);
		List<EEMBilPaymentEntryDtlsDO> pmntEntryDtlsList = billingEntryDao.billPaymentEntryDetails(eemBilPaymntEntryVo);
		CommonUtils.copyList(pmntEntryDtlsList, paymntEntryDtlsListVO, EEMBilPaymentEntryDtlsVO.class);
		if (!paymntEntryDtlsListVO.isEmpty()) {
			List<EEMBilPaymentEntryInvDO> billEntryInvList = billingEntryDao.getBilEntryInvDetails(eemBilPaymntEntryVo);
			List<EEMBilPaymentEntryInvVO> billEntryInvListVO = new ArrayList<>();
			CommonUtils.copyList(billEntryInvList, billEntryInvListVO, EEMBilPaymentEntryInvVO.class);
			Map<String, List<EEMBilPaymentEntryInvVO>> invItemMap = new HashMap<>();
			billEntryInvListVO.forEach(ref -> {
				String key = ref.getItemNumber();
				if (invItemMap.containsKey(key)) {
					List<EEMBilPaymentEntryInvVO> list = invItemMap.get(key);
					list.add(ref);
					invItemMap.put(key, list);
				} else {
					List<EEMBilPaymentEntryInvVO> list = new ArrayList<>();
					list.add(ref);
					invItemMap.put(key, list);

				}
			});
			paymntEntryDtlsListVO.forEach(ref -> ref.setBillingInvoiceList(invItemMap.get(ref.getItemNbr())));

		}

		return paymntEntryDtlsListVO;
	}

	public void billPaymentEntryAdd(EEMBilPaymentEntryNewVO paymntEntryNewVo) {
		EEMBilPaymentEntryVO paymntEntryHeader = paymntEntryNewVo.getBillPaymentsHeader();
		List<EEMBilPaymentEntryDtlsVO> paymntEntrydtlsList = paymntEntryNewVo.getBillPaymentsDtlsList();
		paymntEntryHeader.setCustomerId(sessionHelper.getUserInfo().getCustomerId());

		EEMProfileItemDO profileItemDo = eemProfileSettings.getProfileObject(
				sessionHelper.getUserInfo().getCustomerId(), EEMProfileConstants.BANKCDTB, DateUtil.getTodaysDate());

		String fetchBCIndicator = null;
		if (profileItemDo != null) {
			fetchBCIndicator = profileItemDo.getParmIndValue();
		}
		Boolean rslt;

		String effDate = DateFormatter.reFormat(paymntEntryHeader.getBatchDate(), DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);

		if ("Y".equalsIgnoreCase(fetchBCIndicator)) {
			rslt = codeCache.validateGlBankAcctCdForMMO(sessionHelper.getUserInfo().getCustomerId(),
					paymntEntryHeader.getBankAcntCd(), effDate);
		} else {
			rslt = codeCache.validateGlBankAcctCd(sessionHelper.getUserInfo().getCustomerId(),
					paymntEntryHeader.getBankAcntCd(), effDate);
		}
		if (!rslt) {
			throw new ApplicationException("Invalid Bank Account Cd");
		}
		paymntEntryHeader.setBatchBalance(NumberFormatter.formatDecimal2Places(paymntEntryHeader.getBatchBalance()));

		paymntEntryHeader.setDetailAmount("0");

		paymntEntryHeader.setBatchDtlCount("0");
		if (paymntEntrydtlsList != null && !paymntEntrydtlsList.isEmpty()) {

			Double dtlAmnt = 0.0;
			for (EEMBilPaymentEntryDtlsVO dtlsVo : paymntEntrydtlsList) {
				dtlAmnt += Double.parseDouble(dtlsVo.getPaymentAmt());
			}
			paymntEntryHeader.setDetailAmount(NumberFormatter.formatDecimal2Places(dtlAmnt));
			paymntEntryHeader.setBatchDtlCount(String.valueOf(paymntEntrydtlsList.size()));
			paymntEntryNewVo.setBillPaymentsHeader(paymntEntryHeader);

		}

		synchronized (this) {
			Integer seqNum = billingEntryDao.getBatchSeqNum(paymntEntryHeader);
			if (seqNum == null) {
				seqNum = 1;
			} else {
				seqNum = seqNum + 1;
			}
			paymntEntryHeader.setBatchSeqNbr(seqNum.toString());
			billingEntryDao.billPaymentEntryAdd(paymntEntryHeader);

		}
		paymntEntryHeader.setBatchDtlCount("0");
		paymntEntryNewVo.setBillPaymentsHeader(paymntEntryHeader);
		if (paymntEntrydtlsList != null && !paymntEntrydtlsList.isEmpty()) {
			billPaymentEntryAddDetails(paymntEntryNewVo);
		}

	}

	private void billPaymentEntryAddDetails(EEMBilPaymentEntryNewVO bilPaymntEntryNewVo) {
		billingEntryDao.billPaymentEntryAddDetails(bilPaymntEntryNewVo);

	}

	public void billPaymentEntryUpdateDetails(EEMBilPaymentEntryNewVO paymntEntryUpdateVo) {
		billPaymentEntryAddDetails(paymntEntryUpdateVo);
		List<EEMBilPaymentEntryDtlsVO> dtlsList = paymntEntryUpdateVo.getBillPaymentsDtlsList();
		EEMBilPaymentEntryVO paymentHeader = paymntEntryUpdateVo.getBillPaymentsHeader();
		paymentHeader.setCustomerId(sessionHelper.getUserInfo().getCustomerId());
		Double dtlNewAmnt = 0.0;
		for (EEMBilPaymentEntryDtlsVO dtlsVo : dtlsList) {
			dtlNewAmnt += Double.parseDouble(dtlsVo.getPaymentAmt());
		}
		Double prevDetailAmnt = Double.parseDouble(paymentHeader.getDetailAmount());
		prevDetailAmnt = prevDetailAmnt + dtlNewAmnt;
		Integer dtlCount = Integer.parseInt(paymentHeader.getBatchDtlCount()) + dtlsList.size();
		paymentHeader.setDetailAmount(NumberFormatter.formatDecimal2Places(prevDetailAmnt));
		paymentHeader.setBatchDtlCount(dtlCount.toString());
		billingEntryDao.billPaymentEntryHeaderUpdate(paymentHeader);

	}

	public Boolean memberIdValidate(String memberId) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();

		return billingEntryDao.memberIdValidate(memberId, customerId);

	}

	public EEMBilPaymentEntryVO billPaymentEntryHeaderUpdate(EEMBilPaymentEntryVO bilPaymntsEntryVo) {
		bilPaymntsEntryVo = (EEMBilPaymentEntryVO) CommonUtils.trimObject(bilPaymntsEntryVo);
		bilPaymntsEntryVo.setBatchBalance(NumberFormatter.formatDecimal2Places(bilPaymntsEntryVo.getBatchBalance()));
		bilPaymntsEntryVo.setDetailAmount(NumberFormatter.formatDecimal2Places(bilPaymntsEntryVo.getDetailAmount()));
		String batchBalanceInd = "N";
		if (bilPaymntsEntryVo.getBatchBalance().equals(bilPaymntsEntryVo.getDetailAmount())) {
			batchBalanceInd = "Y";
		}
		bilPaymntsEntryVo.setBatchBalInd(batchBalanceInd);
		billingEntryDao.paymentEntryHeaderBatchBalUpdate(bilPaymntsEntryVo);

		return bilPaymntsEntryVo;
	}

	public EEMBilPaymentEntryNewVO billPaymentEntryDetailsUpdate(EEMBilPaymentEntryUpdateVO bilPaymntsEntryUpdateVo) {
		EEMBilPaymentEntryDtlsVO bilPaymntsEntryDtlsVo = (EEMBilPaymentEntryDtlsVO) CommonUtils
				.trimObject(bilPaymntsEntryUpdateVo.getBilPaymentEntryDtlsVO());
		EEMBilPaymentEntryVO bilPaymentEntryVO = bilPaymntsEntryUpdateVo.getBillPaymentsHeader();
		bilPaymentEntryVO = (EEMBilPaymentEntryVO) CommonUtils.trimObject(bilPaymentEntryVO);
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		if (!billingEntryDao.checkInvoiceId(bilPaymntsEntryDtlsVo.getMemberId(), customerId)) {
			throw new ApplicationException("Invalid Invoice Id in Payment Details Update.");
		}
		String paymentAmnt = NumberFormatter.formatDecimal2Places(bilPaymntsEntryDtlsVo.getPaymentAmt());
		String batchbalAmnt = bilPaymentEntryVO.getBatchBalance();
		batchbalAmnt = NumberFormatter.formatDecimal2Places(batchbalAmnt);
		bilPaymntsEntryDtlsVo.setPaymentAmt(paymentAmnt);
		bilPaymentEntryVO.setBatchBalance(batchbalAmnt);
		bilPaymentEntryVO = billingEntryDao.billPaymentEntryDetailsUpdate(bilPaymntsEntryDtlsVo, bilPaymentEntryVO);
		EEMBilPaymentEntryNewVO updateResponse = new EEMBilPaymentEntryNewVO();
		updateResponse.setBillPaymentsHeader(bilPaymentEntryVO);
		updateResponse.setBillPaymentsDtlsList(billPaymentEntryDetails(bilPaymentEntryVO));
		return updateResponse;
	}

	@SuppressWarnings("unchecked")
	public PageableVO billPaymentEntrySearchNext(EEMBilPaymentEntryVO paymentEntrySearchVo) {
		paymentEntrySearchVo.setCustomerId(sessionHelper.getUserInfo().getCustomerId());
		PageableVO pagableResult = billingEntryDao.billPaymentEntrySearch(paymentEntrySearchVo, true);
		List<EEMBilPaymentEntryDO> billingsDOList = (List<EEMBilPaymentEntryDO>) pagableResult.getContent();
		List<EEMBilPaymentEntryVO> billingsVOList = new ArrayList<>();
		CommonUtils.copyList(billingsDOList, billingsVOList, EEMBilPaymentEntryVO.class);
		List<LabelValuePair> payTypesList = eemPer.loadBillingPaySourceTypes();
		Map<String, String> payTypesMap = new HashMap<>();
		payTypesList.forEach(paySrcType -> payTypesMap.put(paySrcType.getValue(), paySrcType.getLabel()));
		billingsVOList.forEach(billingVO -> billingVO.setPaySourceDesc(payTypesMap.get(billingVO.getPaySource())));
		pagableResult.setContent(billingsVOList);
		return pagableResult;
	}
	
	private EEMBilPaymentEntryMasterVO initializePaymentEntryResVO() {
		EEMBilPaymentEntryMasterVO paymntEntryMasterVO = new EEMBilPaymentEntryMasterVO();
		paymntEntryMasterVO.setBillingPaymentDtlsList(new ArrayList<EEMBilPaymentEntryDtlsVO>());
		paymntEntryMasterVO.setBillingPaymentslist(new ArrayList<EEMBilPaymentEntryVO>());
		return paymntEntryMasterVO;
	}

}
