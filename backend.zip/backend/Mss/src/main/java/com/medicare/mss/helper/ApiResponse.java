package com.medicare.mss.helper;

import java.util.List;

import com.medicare.mss.util.LabelValuePair;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class ApiResponse {

	private int statusCode;
	private String message;
	private Object object;
	private List<?> listObject;
	private String token;

	private List<LabelValuePair> profiles;

	public ApiResponse(int statusCode) {
		super();
		this.statusCode = statusCode;
	}

	public ApiResponse(int statusCode, String message) {
		super();
		this.statusCode = statusCode;
		this.message = message;
	}

}
