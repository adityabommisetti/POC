package com.medicare.mss.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.caching.EEMPersistence;
import com.medicare.mss.caching.EEMProfileSettings;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMApplDAO;
import com.medicare.mss.dao.EEMMbrAgentDAO;
import com.medicare.mss.dao.EEMMbrDAO;
import com.medicare.mss.dao.EEMMbrErrorDAO;
import com.medicare.mss.domainobject.EmMbrAgentDO;
import com.medicare.mss.domainobject.EmMbrErrorDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.EEMContext;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EEMFieldErrorVO;
import com.medicare.mss.vo.EEMMbrEnrollmentVO;
import com.medicare.mss.vo.EMDatedSegmentVO;
import com.medicare.mss.vo.EmMbrAgentVO;
import com.medicare.mss.vo.EmMbrErrorVO;

@Service
@Transactional(rollbackFor = ApplicationException.class)
public class EEMMbrAgentServices extends EEMMbrBaseService {


	@Autowired
	private EEMMbrAgentDAO mbrAgentDao;

	@Autowired
	EEMProfileSettings eemProfileSettings;

	@Autowired
	EEMApplDAO applicationDAO;

	@Autowired
	private EEMCodeCache eemCodeCache;

	@Autowired
	private EEMMbrErrorDAO mbrErrorDAO;

	@Autowired
	private MessageSource messageSource;

	@Autowired
	private EEMPersistence eemPer;

	@Autowired
	private EEMMbrDAO eemMbrDAO;

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public List<EmMbrAgentVO> getMbrAgents(String memberId, String showAll) {

		List<EmMbrAgentVO> mbrAgentVOList = sessionHelper.getEEMContext().getMbrMasterVO().getMbrAgentInfoList();
		if (StringUtils.equals(EEMConstants.VALUE_YES, showAll)) {
			List<EmMbrAgentVO> allInfos = getMbrAgentsFromDB(memberId, showAll);
				mbrAgentVOList = (List<EmMbrAgentVO>) getActiveDatedList(allInfos);
				setToContext(mbrAgentVOList);
			return allInfos;
		} else {
			if (Objects.isNull(mbrAgentVOList)) {
				mbrAgentVOList = getMbrAgentsFromDB(memberId, showAll);
				setToContext(mbrAgentVOList);
			} else {
				mbrAgentVOList = (List<EmMbrAgentVO>) getActiveDatedList(mbrAgentVOList);
				setToContext(mbrAgentVOList);
			}
			return mbrAgentVOList;
		}
	}

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public List<EmMbrAgentVO> getMbrAgentsFromDB(String memberId, String showAll) {

		List<LabelValuePair> lstAgent = eemPer.getLstAgentTypes();
		List<LabelValuePair> lstAgency = eemPer.getLstAgencyTypes();

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String lineOfBusiness = getLineOfBusiness(customerId);
		
		List<EmMbrAgentVO> mbrAgentVOList = new ArrayList<>();

		List<EmMbrAgentDO> mbrAgentDOList = mbrAgentDao.getMbrAgents(customerId, memberId, showAll, lineOfBusiness);
		mbrAgentDOList.forEach(mbrAgentSelect -> {
			EmMbrAgentVO mbrAgentVO = new EmMbrAgentVO();
			BeanUtils.copyProperties(mbrAgentSelect, mbrAgentVO);

			mbrAgentVO.setAgencyTypeDesc(
					StringUtil.nonNullTrim(eemCodeCache.getDesc(mbrAgentVO.getAgencyType(), lstAgency)));
			mbrAgentVO.setAgentTypeDesc(
					StringUtil.nonNullTrim(eemCodeCache.getDesc(mbrAgentVO.getAgentType(), lstAgent)));

			mbrAgentVOList.add(mbrAgentVO);
		});

		/*
		 * if (!"Y".equals(showAll)) { setToContext(mbrAgentVOList); }
		 */
		if(StringUtils.equals(EEMConstants.VALUE_NO, showAll)) {
			setToContext(mbrAgentVOList);
		} else {
			List<EmMbrAgentVO> activeDatedList = (List<EmMbrAgentVO>) getActiveDatedList(mbrAgentVOList);
			setToContext(activeDatedList);
		}

		return mbrAgentVOList;
	}

	private void setToContext(List<EmMbrAgentVO> mbrAgentVOList) {
		EEMContext context = sessionHelper.getEEMContext();
		context.getMbrMasterVO().setMbrAgentInfoList(mbrAgentVOList);
		sessionHelper.setEEMContext(context);
	}

	public boolean mbrAgentDelete(EmMbrAgentVO delVO) {
		String userId = sessionHelper.getUserInfo().getUserId();
		boolean finalRslt = false;
		int sqlCnt = 0;
		try {
			EmMbrAgentDO delDO = new EmMbrAgentDO();
			BeanUtils.copyProperties(delVO, delDO);
			sqlCnt = mbrAgentDao.setMbrAgentOverride(delDO, userId);
			if (sqlCnt == 1) {
				return true;
			}
		} catch (Exception exp) {
			throw new ApplicationException(exp.getMessage());
		}
		return finalRslt;
	}

	public List<EmMbrAgentVO> mbrAgentUpdate(EmMbrAgentVO newVO, List<EEMFieldErrorVO> lstFields) {

		String userId = sessionHelper.getUserInfo().getUserId();
		String ts = DateUtil.getCurrentDatetimeStamp();
		String fieldNbr = null;
		String fieldNbrUpdate = "419001";
		String requestScrn = "agent";
		String applDate = " ";

		newVO.setCustomerId(sessionHelper.getUserInfo().getCustomerId());

		try {
			List<EmMbrErrorVO> lstErrors = validateEnrolledAgent(newVO, lstFields, userId);

			if (!lstErrors.isEmpty()) {
				for (int i = 0; i < 1; i++) {
					EmMbrErrorVO objError = null;
					objError = lstErrors.get(i);
					fieldNbr = objError.getFieldNbr();
				}

				List<EmMbrErrorDO> lstErrorsDO = new ArrayList<>();

				lstErrors.forEach(lstErrorVO -> {
					EmMbrErrorDO lstErrorDO = new EmMbrErrorDO();
					BeanUtils.copyProperties(lstErrorVO, lstErrorDO);
					lstErrorsDO.add(lstErrorDO);
				});

				setErrorDetails(lstErrorsDO, newVO.getMemberId(), userId, fieldNbr, requestScrn, applDate);
			} else {
				updateErrorDetails(userId, fieldNbrUpdate, requestScrn);
			}

			List<EmMbrErrorDO> mbrErrorDOList = mbrErrorDAO.getMbrErrors(newVO.getCustomerId(), newVO.getMemberId());
			List<EmMbrErrorVO> mbrErrorVOList = new ArrayList<>();
			if (!CollectionUtils.isEmpty(mbrErrorDOList)) {
				mbrErrorDOList.forEach(mbrErrorDO -> {
					EmMbrErrorVO mbrErrorVO = new EmMbrErrorVO();
					BeanUtils.copyProperties(mbrErrorDO, mbrErrorVO);
					mbrErrorVO.setFieldDispName(
							messageSource.getMessage(mbrErrorDO.getFieldNbr(), null, Locale.getDefault()));
					mbrErrorVOList.add(mbrErrorVO);
				});
			}

			EEMContext context = sessionHelper.getEEMContext();
			context.getMbrMasterVO().setMbrErrorList(mbrErrorVOList);
			sessionHelper.setEEMContext(context);

			if (!checkPlanId(newVO.getPlanId(), newVO.getEffStartDate())) {
				throw new ApplicationException("Plan Id does not exist for given criteria.");
			}

			String msg = checkDates(newVO);
			if (msg != null) {
				throw new ApplicationException(msg);
			}

			EmMbrAgentDO newDO = new EmMbrAgentDO();
			BeanUtils.copyProperties(newVO, newDO);

			List<? extends EMDatedSegmentVO> lstAgent = getMbrAgents(newVO.getMemberId(), "N");

			EmMbrAgentVO matchVO = null;

			// the update case
			matchVO = (EmMbrAgentVO) matchDatedSegment(lstAgent, newVO);
			if (matchVO != null) {
				return updateAgent(newVO, userId, ts, matchVO);
			}

			// the update case
			matchVO = (EmMbrAgentVO) matchDatedSegmentEndDate(lstAgent, newVO);
			if (matchVO != null) {
				return updateAgent(newVO, userId, ts, matchVO);
			}

			if (newVO.getEffEndDate().equals("99999999")) {

				return updateAgentForEndDate(newVO, userId, ts, lstAgent);
			} // end of open ended new segment processing

			// End dated segment
			if (!doDatedSegmentAdjust(lstAgent, newVO, ts, userId, mbrAgentDao)) {
				throw new ApplicationException("Error during segmentation");
			}

			// add the new agent
			return addNewAgent(newVO, userId, ts);

		} catch (Exception exp) {
			throw new ApplicationException(exp.getMessage());
		}
	}

	private List<EmMbrAgentVO> updateAgentForEndDate(EmMbrAgentVO newVO, String userId, String ts,
			List<? extends EMDatedSegmentVO> lstAgent) throws CloneNotSupportedException, ParseException {
		int sqlCnt = 0;
		EmMbrAgentDO tempDO = new EmMbrAgentDO();
		// logicly delete all above
		List<? extends EMDatedSegmentVO> lstSegmentsAbove = getSegmentsAbove(lstAgent, newVO.getEffStartDate());
		Iterator<? extends EMDatedSegmentVO> it = lstSegmentsAbove.iterator();
		while (it.hasNext()) {
			EmMbrAgentVO itemVO = (EmMbrAgentVO) it.next();
			BeanUtils.copyProperties(itemVO, tempDO);
			sqlCnt = mbrAgentDao.setMbrAgentOverride(tempDO, userId);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_ABOVE);
			}
		}

		EmMbrAgentVO belowVO = (EmMbrAgentVO) getFirstOverlapSegmentBelow(lstAgent, newVO.getEffStartDate());
		if (belowVO != null) {
			BeanUtils.copyProperties(belowVO, tempDO);
			sqlCnt = mbrAgentDao.setMbrAgentOverride(tempDO, userId);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_BELOW);
			}

			// do we need to split the segmment below
			if (belowVO.getEffStartDate().compareTo(newVO.getEffStartDate()) < 0) {
				EmMbrAgentVO tempVO = (EmMbrAgentVO) belowVO.clone();
				tempVO.setEffEndDate(DateMath.minusOneDay(newVO.getEffStartDate()));
				tempVO.setCreateTime(ts);
				tempVO.setCreateUserId(userId);
				tempVO.setLastUpdtTime(ts);
				tempVO.setLastUpdtUserId(userId);

				BeanUtils.copyProperties(tempVO, tempDO);
				sqlCnt = mbrAgentDao.insertMbrAgent(tempDO);
				if (sqlCnt != 1) {
					throw new ApplicationException(EEMConstants.ERROR_SPLITING_SEGMENT_BELOW);
				}
			}
		}

		// add the new agent
		return addNewAgent(newVO, userId, ts);
	}

	private List<EmMbrAgentVO> updateAgent(EmMbrAgentVO newVO, String userId, String ts, EmMbrAgentVO matchVO) {
		int sqlCnt = 0;
		EmMbrAgentDO matchDO = new EmMbrAgentDO();
		BeanUtils.copyProperties(matchVO, matchDO);
		sqlCnt = mbrAgentDao.setMbrAgentOverride(matchDO, userId);
		if (sqlCnt != 1) {
			throw new ApplicationException(EEMConstants.ERROR_OVERRIDING_SEGMENT);
		}
		// add the new agent
		return addNewAgent(newVO, userId, ts);
	}

	private boolean checkPlanId(String planId, String effStartDate) {

		List<EEMMbrEnrollmentVO> mbrEnrollmentList = sessionHelper.getEEMContext().getMbrMasterVO()
				.getMbrEnrollmentList();

		if (!CollectionUtils.isEmpty(mbrEnrollmentList)) {
			Iterator<EEMMbrEnrollmentVO> it = mbrEnrollmentList.iterator();
			EEMMbrEnrollmentVO mbrEnrollmentItem;
			while (it.hasNext()) {
				mbrEnrollmentItem = it.next();
				if (((mbrEnrollmentItem.getEffStartDate().compareTo(effStartDate) <= 0)
						&& (mbrEnrollmentItem.getEffEndDate().compareTo(effStartDate) >= 0)) &&
					 ((("EAPRV").equalsIgnoreCase(mbrEnrollmentItem.getEnrollStatus())
							|| ("EPEND").equalsIgnoreCase(mbrEnrollmentItem.getEnrollStatus()))
							&& (mbrEnrollmentItem.getPlanId().equalsIgnoreCase(planId)))) {
						return true;
					} 
			}
		}
		return false;
	}

	private List<EmMbrAgentVO> addNewAgent(EmMbrAgentVO newVO, String userId, String ts) {
		newVO.setCreateTime(ts);
		newVO.setCreateUserId(userId);
		newVO.setLastUpdtTime(ts);
		newVO.setLastUpdtUserId(userId);

		EmMbrAgentDO newDO = new EmMbrAgentDO();
		BeanUtils.copyProperties(newVO, newDO);

		int sqlCnt = mbrAgentDao.insertMbrAgent(newDO);
		if (sqlCnt != 1) {
			throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
		}
		Map<String, String> type = new HashMap<>();
		String maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newDO.getCustomerId(), newDO.getMemberId(), EEMConstants.EM_MBR_AGENT, type);
		if (hasDataChanged(ts, maxLastUpdate)) {
			throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);

		}

		return getMbrAgentsFromDB(newVO.getMemberId(), newVO.getShowAll());
	}

	private List<EmMbrErrorVO> validateEnrolledAgent(EmMbrAgentVO agentVO, List<EEMFieldErrorVO> lstFields,
			String userId) {
		List<EmMbrErrorVO> lstErrors = new ArrayList<>();

		EmMbrErrorVO objError = checkActiveAgent(agentVO, lstFields, userId);
		if (objError != null) {
			lstErrors.add(objError);
		}
		objError = checkInvalidAgent(agentVO, lstFields, userId);
		if (objError != null) {
			lstErrors.add(objError);
		}
		objError = checkInvaildAgency(agentVO, lstFields, userId);
		if (objError != null) {
			lstErrors.add(objError);
		}

		return lstErrors;
	}

	private EmMbrErrorVO checkInvaildAgency(EmMbrAgentVO agentVO, List<EEMFieldErrorVO> lstFields, String userId) {
		EmMbrErrorVO objError = null;

		EmMbrAgentDO agentDO = new EmMbrAgentDO();
		BeanUtils.copyProperties(agentVO, agentDO);

		EEMFieldErrorVO field = getField(EEMConstants.AGENTID, lstFields);
		if (field == null) {
			return objError;
		}

		try {
			boolean error = false;
			String errorCode = "";
			if ((agentVO.getAgencyId() != null && !(agentVO.getAgencyId().equalsIgnoreCase("")))) {
				int checkAgency = mbrAgentDao.checkInvalidAgency(agentDO);
				if (checkAgency == 0) {
					error = true;
					errorCode = "MB153";
				}
			}
			if (error) {
				objError = new EmMbrErrorVO();
				objError.setCustomerId(agentVO.getCustomerId());
				objError.setMemberId(agentVO.getMemberId());
				objError.setFieldNbr(field.getFieldNbr());
				if (!StringUtil.nonNullTrim(field.getRequiredInd()).equals("N")) {
					objError.setRfiInd("Y");
				} else {
					objError.setRfiInd("N");
				}
				objError.setErrorCd(errorCode);
				objError.setErrorMsg(eemCodeCache.getDesc(errorCode, eemCodeCache.getLstErrorCodes()));
				objError.setFieldNbr(field.getFieldNbr());
				objError.setLastUpdtUserId(userId);
				objError.setErrorData(agentVO.getAgencyId());
			}
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_OCCURED_WHILE_VALIDATE_AGENT);
		}
		return objError;

	}

	private EmMbrErrorVO checkInvalidAgent(EmMbrAgentVO agentVO, List<EEMFieldErrorVO> lstFields, String userId) {
		EmMbrErrorVO objError = null;

		EmMbrAgentDO agentDO = new EmMbrAgentDO();
		BeanUtils.copyProperties(agentVO, agentDO);

		EEMFieldErrorVO field = getField(EEMConstants.AGENTID, lstFields);
		if (field == null) {
			return objError;
		}

		try {
			boolean error = false;
			String errorCode = "";
			if ((agentVO.getAgentId() != null && !(agentVO.getAgentId().equalsIgnoreCase("")))) {
				int checkAgent = mbrAgentDao.checkInvalidAgent(agentDO);
				if (checkAgent == 0) {
					error = true;
					errorCode = "MB032";
				}
			}
			if (error) {
				objError = new EmMbrErrorVO();
				objError.setCustomerId(agentVO.getCustomerId());
				objError.setMemberId(agentVO.getMemberId());
				objError.setFieldNbr(field.getFieldNbr());
				if (!StringUtil.nonNullTrim(field.getRequiredInd()).equals("N")) {
					objError.setRfiInd("Y");
				} else {
					objError.setRfiInd("N");
				}
				objError.setErrorCd(errorCode);
				objError.setErrorMsg(eemCodeCache.getDesc(errorCode, eemCodeCache.getLstErrorCodes()));
				objError.setFieldNbr(field.getFieldNbr());
				objError.setLastUpdtUserId(userId);
				objError.setErrorData(agentVO.getAgentId());
			}
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_OCCURED_WHILE_VALIDATE_AGENT);
		}
		return objError;
	}

	private EmMbrErrorVO checkActiveAgent(EmMbrAgentVO agentVO, List<EEMFieldErrorVO> lstFields, String userId) {
		EmMbrErrorVO objError = null;

		EmMbrAgentDO agentDO = new EmMbrAgentDO();
		BeanUtils.copyProperties(agentVO, agentDO);

		EEMFieldErrorVO field = getField(EEMConstants.AGENTID, lstFields);
		if (field == null) {
			return objError;
		}

		try {
			boolean error = false;
			String errorCode = "";
			if ((agentVO.getAgentId() != null && !(agentVO.getAgentId().equalsIgnoreCase("")))
					&& (agentVO.getAgencyId() != null && !(agentVO.getAgencyId().equalsIgnoreCase("")))) {
				boolean activeAgent = mbrAgentDao.getActiveAgent(agentDO);
				if (!activeAgent) {
					error = true;
					errorCode = "MB155";
				}
			}
			if (error) {
				objError = new EmMbrErrorVO();
				objError.setCustomerId(agentVO.getCustomerId());
				objError.setMemberId(agentVO.getMemberId());
				objError.setFieldNbr(field.getFieldNbr());
				if (!StringUtil.nonNullTrim(field.getRequiredInd()).equals("N")) {
					objError.setRfiInd("Y");
				} else {
					objError.setRfiInd("N");
				}
				objError.setErrorCd(errorCode);
				objError.setErrorMsg(eemCodeCache.getDesc(errorCode, eemCodeCache.getLstErrorCodes()));
				objError.setFieldNbr(field.getFieldNbr());
				objError.setLastUpdtUserId(userId);
				objError.setErrorData(agentVO.getAgentId());
			}
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_OCCURED_WHILE_VALIDATE_AGENT);
		}

		return objError;

	}

	public EEMFieldErrorVO getField(String fieldName, List<EEMFieldErrorVO> lstFields) {

		EEMFieldErrorVO field = null;
		boolean found = false;
		for (int i = 0; i < lstFields.size(); i++) {
			field = lstFields.get(i);
			if (fieldName.equals(field.getFormField())) {
				found = true;
				break;
			}
		}

		if (!found) {
			field = null;
		}
		return field;
	}

	public List<EmMbrAgentVO> mbrAgentInfoDelete(EmMbrAgentVO delVO) {
		boolean sqlCnt = false;
		sqlCnt = mbrAgentDelete(delVO);

		if (sqlCnt) {
			return getMbrAgentsFromDB(StringUtil.nonNullTrim(delVO.getMemberId()), delVO.getShowAll());
		} else {
			throw new ApplicationException("Agent Delete Failed");
		}
	}

	public List<EmMbrAgentVO> mbrAgentInfoUpdate(EmMbrAgentVO insertVO) {

		insertVO.setOverrideInd("N");
		List<EEMFieldErrorVO> lstFields = getValidatingFormFields(EEMConstants.EEM_ENROLL_FORM);

		return mbrAgentUpdate(insertVO, lstFields);

	}

}
