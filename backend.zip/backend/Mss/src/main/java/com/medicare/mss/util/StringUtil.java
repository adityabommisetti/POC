package com.medicare.mss.util;

final public class StringUtil {

	private StringUtil() {
	}

	public static String nonNullTrim(String s) {
		if (s == null)
			return "";
		return s.trim();
	}



	public static String YorN(String s) {
		if (s != null)
			if (s.length() > 0)
				if (s.substring(0, 1).toUpperCase().equals("Y"))
					return "Y";
		return "N";
	}

	public static String YorBlank(String s) {
		if (s != null)
			if (s.length() > 0)
				if (s.substring(0, 1).toUpperCase().equals("Y"))
					return "Y";
		return " ";
	}

	public static String appendWildCardCharacter(String value, boolean beginAppend, boolean endAppend) {
		StringBuffer buffer = new StringBuffer();
		if (null != value) {
			buffer.append(value);
			if (beginAppend) {
				buffer.insert(0, "%");
			}
			if (endAppend) {
				buffer.append("%");
			}
		}
		return buffer.toString();
	}

	public static String isHicOrMbi(String medId) {
		String flag = "mbi";
		if (medId.length() == 11) {
			if (!Character.isDigit(medId.charAt(0))) {
				flag = "hic";
			} else if (!(Character.isLetter(medId.charAt(1)) && !lookUpForExceptions(medId.charAt(1)))) {
				flag = "hic";
			} else if (!(Character.isLetterOrDigit(medId.charAt(2)) && !lookUpForExceptions(medId.charAt(2)))) {
				flag = "hic";
			} else if (!Character.isDigit(medId.charAt(3))) {
				flag = "hic";
			} else if (!(Character.isLetter(medId.charAt(4)) && !lookUpForExceptions(medId.charAt(4)))) {
				flag = "hic";
			} else if (!(Character.isLetterOrDigit(medId.charAt(5)) && !lookUpForExceptions(medId.charAt(5)))) {
				flag = "hic";
			} else if (!Character.isDigit(medId.charAt(6))) {
				flag = "hic";
			} else if (!(Character.isLetter(medId.charAt(7)) && !lookUpForExceptions(medId.charAt(7)))) {
				flag = "hic";
			} else if (!(Character.isLetter(medId.charAt(8)) && !lookUpForExceptions(medId.charAt(8)))) {
				flag = "hic";
			} else if (!Character.isDigit(medId.charAt(9))) {
				flag = "hic";
			} else if (!Character.isDigit(medId.charAt(10))) {
				flag = "hic";
			}
		} else {
			flag = "hic";
		}
		return flag;
	}

	private static boolean lookUpForExceptions(char ch) {
		char[] exclusions = { 'S', 'L', 'O', 'I', 'B', 'Z' };
		for (char c : exclusions) {
			if (ch == c) {
				return true;
			}
		}
		return false;
	}
	
	public static double ensureDouble(String s) {
		s = nonNullTrim(s);
		if (!s.isEmpty())
			return Double.parseDouble(s);
		return 0;
	}

	public static boolean isNotNullNotEmptyNotWhiteSpace(final String string) {
		return string != null && !string.trim().isEmpty();
	}

	public static boolean isNullOrEmptyOrSpace(String testString) {
		if (testString == null)
			return true;
		if (testString.trim().isEmpty())
			return true;
		return false;
	}

	public static boolean isNullOrEmpty(String testString) {
		return testString == null || "".equals(testString.trim());
	}

	public static String zeroTrim(String s) {
		if (s.trim().equalsIgnoreCase("00000000")) {
			return "";
		}
		return s.trim();
	}

}
