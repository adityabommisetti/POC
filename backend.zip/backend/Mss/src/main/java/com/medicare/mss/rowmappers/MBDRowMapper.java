/**
 * 
 */
package com.medicare.mss.rowmappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.domainobject.MbdDO;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.StringUtil;

/**
 * @author SUSDASH
 *
 */
public class MBDRowMapper implements RowMapper<MbdDO> {
	
private final Logger LOGGER = LogManager.getLogger(this.getClass());
private String table= "";

public MBDRowMapper(String table) {
	this.table = table;
}
	@Override
	public MbdDO mapRow(ResultSet rs, int rowNum) throws SQLException {

		MbdDO mbdDO = new MbdDO();
		mbdDO.setHicNbr(StringUtil.nonNullTrim(rs.getString("Hic_nbr")));
        mbdDO.setLastName(StringUtil.nonNullTrim(rs.getString("Last_name")));
        mbdDO.setFirstName(StringUtil.nonNullTrim(rs.getString("First_name")));
        mbdDO.setMiddleInit(StringUtil.nonNullTrim(rs.getString("Middle_init")));
        mbdDO.setGenderCd(StringUtil.nonNullTrim(rs.getString("Gender_num_cd")));
        mbdDO.setBirthDate(StringUtil.nonNullTrim(rs.getString("Birth_date")));
        mbdDO.setLivingStatus(StringUtil.nonNullTrim(rs.getString("Living_Status")));
        mbdDO.setDeathDate(StringUtil.nonNullTrim(rs.getString("Death_date")));
        mbdDO.setPrtAEntitleDate((StringUtil.nonNullTrim(rs.getString("PrtA_Entitle_date"))));
        mbdDO.setPrtAEntitleEndDate((StringUtil.nonNullTrim(rs.getString("PrtA_Entitle_EDate"))));
        mbdDO.setPrtBEntitleDate((StringUtil.nonNullTrim(rs.getString("PrtB_Entitle_date"))));
        mbdDO.setPrtBEntitleEndDate((StringUtil.nonNullTrim(rs.getString("PrtB_Entitle_EDate"))));
        mbdDO.setPrtAOption(StringUtil.nonNullTrim(rs.getString("PrtA_Option")));
        mbdDO.setPrtBOption(StringUtil.nonNullTrim(rs.getString("PrtB_Option")));
        mbdDO.setEnrollmentStatus(StringUtil.nonNullTrim(rs.getString("Enrollment_status")));
        mbdDO.setHospiceInd(StringUtil.nonNullTrim(rs.getString("Hospice_ind")));
        mbdDO.setHospiceStartDate((StringUtil.nonNullTrim(rs.getString("Hospice_sdate"))));
        mbdDO.setHospiceEndDate((StringUtil.nonNullTrim(rs.getString("Hospice_edate"))));
        mbdDO.setInstInd(StringUtil.nonNullTrim(rs.getString("Institutional_ind")));
        mbdDO.setInstStartDate((StringUtil.nonNullTrim(rs.getString("Inst_sdate"))));
        mbdDO.setInstEndDate((StringUtil.nonNullTrim(rs.getString("Inst_edate"))));
        mbdDO.setEsrdInd(StringUtil.nonNullTrim(rs.getString("ESRD_ind")));
        mbdDO.setEsrdStartDate((StringUtil.nonNullTrim(rs.getString("ESRD_sdate"))));
        mbdDO.setEsrdEndDate((StringUtil.nonNullTrim(rs.getString("ESRD_edate"))));
        mbdDO.setWrkagedInd(StringUtil.nonNullTrim(rs.getString("Wrkaged_ind")));
        mbdDO.setWrkagedStartDate(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("Wrkaged_sdate"))));
        mbdDO.setWrkagedEndDate(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("Wrkaged_edate"))));
        mbdDO.setMedicInd(StringUtil.nonNullTrim(rs.getString("Medic_ind")));
        mbdDO.setMedicStartDate((StringUtil.nonNullTrim(rs.getString("Medic_sdate"))));
        mbdDO.setMedicEndDate((StringUtil.nonNullTrim(rs.getString("Medic_edate"))));
        mbdDO.setRaceCd(StringUtil.nonNullTrim(rs.getString("Race_cd")));
        mbdDO.setStateCd(StringUtil.nonNullTrim(rs.getString("State_cd")));
        mbdDO.setCountyCd(StringUtil.nonNullTrim(rs.getString("County_cd")));
        mbdDO.setZipCd(StringUtil.nonNullTrim(rs.getString("Zip_cd")));
        mbdDO.setEghpInd(StringUtil.nonNullTrim(rs.getString("EGHP_ind")));
        mbdDO.setPlanId(StringUtil.nonNullTrim(rs.getString("Plan_id")));
        mbdDO.setElectionType(StringUtil.nonNullTrim(rs.getString("Election_type")));
        mbdDO.setPbpId(StringUtil.nonNullTrim(rs.getString("PBP_id")));
        mbdDO.setSegmentId(StringUtil.nonNullTrim(rs.getString("Segment_id")));
        mbdDO.setPbpStartDate(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("PBP_sdate"))));
        mbdDO.setPbpEndDate(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("PBP_edate"))));
        mbdDO.setPlanEnrollDate(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("Plan_Enroll_date"))));
        mbdDO.setPlanDisenrollDate(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("Plan_Disenrol_date"))));
        mbdDO.setPlanDrugInd(StringUtil.nonNullTrim(rs.getString("Plan_Drug_Ind")));
        mbdDO.setPriorBIC(StringUtil.nonNullTrim(rs.getString("Prior_bic")));
        mbdDO.setGhpClaimNbr(StringUtil.nonNullTrim(rs.getString("GHP_Claim_nbr")));
        mbdDO.setXrefClaimNbr(StringUtil.nonNullTrim(rs.getString("Xref_claim_nbr")));
        mbdDO.setPrtDEligibleDate((StringUtil.nonNullTrim(rs.getString("PrtD_elig_sdate"))));
        mbdDO.setSubsidyStartDate1((StringUtil.nonNullTrim(rs.getString("Subsidy_sdate1"))));
        mbdDO.setSubsidyStartDate2(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("Subsidy_sdate2"))));
        mbdDO.setSubsidyEndDate1((StringUtil.nonNullTrim(rs.getString("Subsidy_edate1"))));
        mbdDO.setSubsidyEndDate2(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("Subsidy_edate2"))));
        mbdDO.setCopayLevelId1(StringUtil.nonNullTrim(rs.getString("Copay_level_id1")));
        mbdDO.setCopayLevelId2(StringUtil.nonNullTrim(rs.getString("Copay_level_id2")));
        mbdDO.setPartDPremsubsPct1(StringUtil.nonNullTrim(rs.getString("PrtD_premsubs_pct1")));
        mbdDO.setPartDPremsubsPct2(StringUtil.nonNullTrim(rs.getString("PrtD_premsubs_pct2")));
        mbdDO.setUncovMonths(StringUtil.nonNullTrim(rs.getString("Calc_uncov_months")));
        mbdDO.setCoPlanId(StringUtil.nonNullTrim(rs.getString("CoPlan_id")));
        mbdDO.setCoPlanEnrollDate(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("CoPlan_Enroll_Dt"))));
        mbdDO.setCoPlanDisEnrollDate(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("CoPlan_Disenrl_dt"))));
        mbdDO.setCoPlanDrugInd(StringUtil.nonNullTrim(rs.getString("CoPlan_Drug_Ind")));
        mbdDO.setCoEghpId(StringUtil.nonNullTrim(rs.getString("COPLAN_EGHP_IND")));
        mbdDO.setCoPbpId(StringUtil.nonNullTrim(rs.getString("COPLAN_PBP")));        
        mbdDO.setPlanTypeCode(StringUtil.nonNullTrim(rs.getString("PLAN_TYPE_CODE")));
        mbdDO.setCoPlanTypeCode(StringUtil.nonNullTrim(rs.getString("COPLAN_TYPE_CODE")));
     
        mbdDO.setUnLawfulPresCnt(rs.getInt("UNLAWFUL_PRES_RECCNT"));
        mbdDO.setIncarcerationCnt(rs.getInt("INCARCERATION_RECCNT"));
      
        try {
        	mbdDO.setEnrollSourceCode(StringUtil.nonNullTrim(rs.getString("ENROLL_SRC_CD")));
        	mbdDO.setCoEnrollSourceCode(StringUtil.nonNullTrim(rs.getString("COPLAN_ENROLL_SRC_CD")));
        	mbdDO.setPrior1DrugPlanInd(StringUtil.nonNullTrim(rs.getString("PRIOR1_PLAN_DRUG_IND")));
        	mbdDO.setPrior1EghpInd(StringUtil.nonNullTrim(rs.getString("PRIOR1_PLAN_EGHP_IND")));
        	mbdDO.setPrior1EnrollSourceCode(StringUtil.nonNullTrim(rs.getString("PRIOR1_ENROLL_SRC_CD")));
        	mbdDO.setPrior1PbpId(StringUtil.nonNullTrim(rs.getString("PRIOR1_PLAN_PBP")));
        	mbdDO.setPrior1PlanEnrollmentDate(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("PRIOR1_PLAN_ENROLL_DT"))));
        	mbdDO.setPrior1PlanEnrollmentEndDate(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("PRIOR1_PLAN_DISENROL_DT"))));
        	mbdDO.setPrior1PlanId(StringUtil.nonNullTrim(rs.getString("PRIOR1_PLAN_ID")));
        	mbdDO.setPrior1PlanType(StringUtil.nonNullTrim(rs.getString("PRIOR1_PLAN_TYPE_CODE")));

        	mbdDO.setPrior2DrugPlanInd(StringUtil.nonNullTrim(rs.getString("PRIOR2_PLAN_DRUG_IND")));
        	mbdDO.setPrior2EghpInd(StringUtil.nonNullTrim(rs.getString("PRIOR2_PLAN_EGHP_IND")));
        	mbdDO.setPrior2EnrollSourceCode(StringUtil.nonNullTrim(rs.getString("PRIOR2_ENROLL_SRC_CD")));
        	mbdDO.setPrior2PbpId(StringUtil.nonNullTrim(rs.getString("PRIOR2_PLAN_PBP")));
        	mbdDO.setPrior2PlanEnrollmentDate(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("PRIOR2_PLAN_ENROLL_DT"))));
        	mbdDO.setPrior2PlanEnrollmentEndDate(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("PRIOR2_PLAN_DISENROL_DT"))));
        	mbdDO.setPrior2PlanId(StringUtil.nonNullTrim(rs.getString("PRIOR2_PLAN_ID")));
        	mbdDO.setPrior2PlanType(StringUtil.nonNullTrim(rs.getString("PRIOR2_PLAN_TYPE_CODE")));

        	String caraReccnt = StringUtil.nonNullTrim(rs.getString("CARA_RECCNT"));
        	if(caraReccnt.isEmpty())
        		mbdDO.setCara_Reccnt(0);
        	else
        		mbdDO.setCara_Reccnt(Integer.parseInt(caraReccnt));

        	String lstUsedSepDt = StringUtil.nonNullTrim(rs.getString("LAST_DUALSEP_DATE"));
        	mbdDO.setLastUsedSepDate(lstUsedSepDt.equals("00000000")?"":lstUsedSepDt);
        	if(this.table.equalsIgnoreCase(EEMConstants.EM_TABLE_MBD)) {
        		mbdDO.setEligibilitySrcTable(EEMConstants.EM_TABLE_MBD);
    			mbdDO.setMbi(StringUtil.nonNullTrim(rs.getString("MBI")));
    			mbdDO.setInactiveMBI(StringUtil.nonNullTrim(rs.getString("INACTIVE_MBI")));
        		
        	} else {
        		mbdDO.setEligibilitySrcTable(EEMConstants.EM_TABLE_BEQ);
    			mbdDO.setMbi(StringUtil.nonNullTrim(rs.getString("MBI")));
    			mbdDO.setInactiveMBI("");
        	}
        } catch (Exception e) {
        	LOGGER.error(e.toString());
		}
    
		return mbdDO;
	}




}
