/**
 * 
 */
package com.medicare.mss.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;

/**
 * @author DU20098149
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EEMMbrLtcSearchVO {

	private String customerId;
	private String effDate;
	private String ltcFacId;
	private String facilityName;
	private String facilityAddress;
	private String facilityCity;
	private String facilityState;
	private String facilityZipCode;

	public String getEffDateFrmt() {
		return DateFormatter.reFormat(effDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setEffDateFrmt(String effDate) {
		this.effDate = DateFormatter.reFormat(effDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}
}
