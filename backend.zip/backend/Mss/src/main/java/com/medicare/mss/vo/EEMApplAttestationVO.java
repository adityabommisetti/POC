package com.medicare.mss.vo;

import lombok.Data;

@Data
public class EEMApplAttestationVO {
	private String applId;
	private String attestaionSeqNbr;
	private String attestDate;
	private String attestInd;
	private String customerId;
	private String deleteInd;
	private String index;
	private String logicalInd;
	
}
