package com.medicare.mss.domainobject;

import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class EEMLepAttestInfoDO  extends BaseDO {
	private String customerId;
	private String primaryId;
	private String userId;
	private String is73TxnExists;
	private String obc1TimerCheck;
	private String obc2TimerCheck;
	private String le21TimerCheck;
	private String obc3TimerCheck;
	private String attestLetMailDate;
	private String attestLetExpDate;
	private String attestStatus;
	private String oldAttestStatus;
	private String appIncAttLetExpDt;
	private String appIncAttRcDt;
	private String pdf_archival;
	private String dmsID;
	private String letterAvailabilityInDB = "N";
	private String letterUploadedTime;
	private String letterName;
	private String attestationRecChannel;
	private String attestationRecDate;
	private String notifiedMemberAppeal;
	private String attestLock;
	
	
	private String otherLastUpdtUserId;
	private String otherLastUpdtTime;
	private String otherCreateTime;
	private String otherCreateUserId;
	private boolean enableAttestAfter90DaysSection;

	
	
	
	
	private List<EEMLepAttestCcfDO> lepAttestList;

}
