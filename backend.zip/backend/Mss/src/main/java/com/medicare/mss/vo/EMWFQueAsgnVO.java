package com.medicare.mss.vo;

import java.io.Serializable;

import lombok.Data;

@Data
public class EMWFQueAsgnVO implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4656942020715855928L;
	
	
	private String prty1QueCd;
	private String prty2QueCd;
	private String prty3QueCd;
	private String prty4QueCd;

}
