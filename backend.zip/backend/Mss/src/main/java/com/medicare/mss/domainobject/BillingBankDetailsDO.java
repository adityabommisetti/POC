package com.medicare.mss.domainobject;

import java.io.Serializable;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class BillingBankDetailsDO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6861762671092251016L;
	
	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;
	@ColumnMapper(columnName = "PAY_SOURCE_TYPE", propertyName = "paySourceType")
	private String paySourceType;
	@ColumnMapper(columnName = "BANK_ACCT_CD", propertyName = "bankAcntCd")
	private String bankAcntCd;
	@ColumnMapper(columnName = "EFF_START_DATE", propertyName = "effStartDate")
	private String effStartDate;
	@ColumnMapper(columnName = "EFF_END_DATE", propertyName = "effEndDate")
	private String effEndDate;
	@ColumnMapper(columnName = "PLAN_ID", propertyName = "planId")
	private String planId;
	@ColumnMapper(columnName = "GL_TRANS_CD", propertyName = "glTranCd")
	private String glTranCd;

}
