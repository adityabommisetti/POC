package com.medicare.mss.rowmappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.medicare.mss.domainobject.EEMApplLisDO;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.StringUtil;

public class ApplLisRowMapper implements RowMapper<EEMApplLisDO> {

	@Override
	public EEMApplLisDO mapRow(ResultSet rs, int rowNum) throws SQLException {
		EEMApplLisDO lisVO = new EEMApplLisDO();
		lisVO.setEffStartDt(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("EFF_START_DATE"))));
		lisVO.setEffEndDt(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("EFF_END_DATE"))));
		lisVO.setLiCoPayCd(StringUtil.nonNullTrim(rs
				.getString("LI_COPAY_CD")));
		lisVO.setLisPctCd(StringUtil.nonNullTrim(rs
				.getString("LIS_PCT_CD")));
		return lisVO;
	}

}
