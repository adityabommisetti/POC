package com.medicare.mss.vo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.LabelValuePair;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EEMApplMasterVO {

	private boolean nextPage;

	private EEMApplAddressVO applAddress;
	private EEMApplAgentVO applAgentVO;
	private List<EEMApplAttestationVO> applAttestationList;
	private List<EEMApplCommentsVO> applCommentsList;
	private EEMApplEligibilityVO applEligiVO;
	private List<EEMApplErrorVO> applErrList;
	private EEMApplLisVO applLisVO;
	private EEMApplOtherCovVO applOtherCovVO;
	private EEMApplOtherPlanVO applOtherPlanVO;
	private EEMApplPlanVO applPlanVO;
	private List<EEMApplSearchVO> applSearchList;
	private EEMApplicationVO applVO;
	private EEMApplProductVO grpProdVO;
	private List<LabelValuePair> lstBrokAgencyIds;
	private List<LabelValuePair> lstBrokAgentIds;
	private List<LabelValuePair> lstInstitutes;
	private MBD mbd;
	private EEMMedOfficeVO medOfficeVO;
	private boolean hasOrigAppl;
	private String userId;
	private String beqCheck;
	private String npiInd;
	// Dynamic values
	private List<LabelValuePair> lstCounty;
	private List<LabelValuePair> lstCity;
	private String suppLepPlatino;

}
