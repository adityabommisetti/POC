package com.medicare.mss.vo;

import lombok.Data;

@Data
public class DataBaseFieldVO {
	
	private double doubleValue;
	private String fieldName;
	private int intValue;
	private boolean isDouble;
	private boolean isInteger;
	private boolean isLong;
	private long longValue;
	private String stringValue;

}
