package com.medicare.mss.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BillingMbrPaymentsVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6134443974983139170L;
	// member variables for columns
	private String customerId;
	private String paySourceType;
	private String paySourceDesc;
	private String batchDate;
	private int batchSeqNbr;
	private int itemNbr;
	private String invoiceId;
	private String invoiceDueDate;
	private String checkDate;
	private String checkNbr;
	private String paymentAmt;
	private String paymentPostedInd;
	private String bankAcctCd;
	private String lastName;
	private String firstName;
	private String hicNbr;

	private String createTime;
	private String createUserId;
	private String lastUpdtTime;
	private String lastUpdtUserId;

	public String getBatchDateFrmt() {
		return DateFormatter.reFormat(batchDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getInvoiceDueDateFrmt() {
		return DateFormatter.reFormat(invoiceDueDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getCheckDateFrmt() {
		return DateFormatter.reFormat(checkDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setInvoiceDueDateFrmt(String invoiceDueDate) {
		this.invoiceDueDate = DateFormatter.reFormat(invoiceDueDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public void setCheckDateFrmt(String checkDate) {
		this.checkDate = DateFormatter.reFormat(checkDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getNameFrmt() {
		return lastName + ", " + firstName;
	}

	public String getBatchInfoFrmt() {
		return getBatchDateFrmt() + "-" + batchSeqNbr;
	}

}
