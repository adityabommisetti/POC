package com.medicare.mss.controller;

import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.service.EEMMbrLisService;
import com.medicare.mss.vo.EEMMbrLisInfoVO;

@RestController
@RequestMapping(ReqMappingConstants.MEMBER)
public class EEMMbrLisController {
	
	@Autowired
	private EEMMbrLisService mbrLisService;
	
	@GetMapping(path = ReqMappingConstants.MBR_LIS_SEARCH)
	public ResponseEntity<JSONResponse> getMbrLisInfos(@PathVariable(name = "mbrId") String memberId,
			@PathVariable(name = "showAll") String showAll) throws ApplicationException {
		
		List<EEMMbrLisInfoVO> mbrLisInfoList = mbrLisService.getListFromContext(memberId, showAll);
		
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;

		if (CollectionUtils.isEmpty(mbrLisInfoList)) {
			response = buildFailureResponse(jsonResponse, HttpStatus.NO_CONTENT.getReasonPhrase());
		} else {
			response = buildSucccessResponse(jsonResponse, mbrLisInfoList);
		}
		return response;
		
	}
	private ResponseEntity<JSONResponse> buildSucccessResponse(JSONResponse jsonResponse, List<EEMMbrLisInfoVO> mbrLisInfoList) {
		jsonResponse.setMessage(EEMConstants.SUCCESS);
		jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
		jsonResponse.setData(mbrLisInfoList);
		return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
	}

	private ResponseEntity<JSONResponse> buildFailureResponse(JSONResponse jsonResponse, String message) {
		jsonResponse.setStatus(EEMConstants.FAILURE);
		jsonResponse.setMessage(message);	
		jsonResponse.setData(null);
		return new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
	}
	
	@PostMapping(path = ReqMappingConstants.MBR_LIS_UPDATE)
	public ResponseEntity<JSONResponse> mbrLisUpdate(@RequestBody EEMMbrLisInfoVO mbrLisInfoVO) throws ApplicationException, ParseException, CloneNotSupportedException {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response = null;
		List<EEMMbrLisInfoVO> lisInfoList = mbrLisService.mbrLisInfoUpdate(mbrLisInfoVO);
		if(!CollectionUtils.isEmpty(lisInfoList)) {
			response = buildSucccessResponse(jsonResponse, lisInfoList);
		}else {
			buildFailureResponse(jsonResponse,"Lis Update Failed");
		}
		return response;
	}

	@PostMapping(path = ReqMappingConstants.MBR_LIS_DELETE)
	public ResponseEntity<JSONResponse> mbrLisInfoDelete(@RequestBody EEMMbrLisInfoVO mbrLisInfoVO) throws ApplicationException{
		JSONResponse jsonResponse = new JSONResponse();
		List<EEMMbrLisInfoVO> lisInfoList = mbrLisService.mbrLisInfoDelete(mbrLisInfoVO);
		return buildSucccessResponse(jsonResponse, lisInfoList);
	}

}
