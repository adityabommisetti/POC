package com.medicare.mss.service;

import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.apache.commons.lang3.StringUtils.isNotBlank;
import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.caching.EEMPersistence;
import com.medicare.mss.caching.EEMProfileSettings;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.EEMProfileConstants;
import com.medicare.mss.dao.EEMApplDAO;
import com.medicare.mss.dao.EEMApplLepDAO;
import com.medicare.mss.dao.EEMDAO;
import com.medicare.mss.domainobject.EEMApplAddressDO;
import com.medicare.mss.domainobject.EEMApplAgentDO;
import com.medicare.mss.domainobject.EEMApplAttestationDO;
import com.medicare.mss.domainobject.EEMApplCommentsDO;
import com.medicare.mss.domainobject.EEMApplEligibilityDO;
import com.medicare.mss.domainobject.EEMApplErrorDO;
import com.medicare.mss.domainobject.EEMApplLisDO;
import com.medicare.mss.domainobject.EEMApplOtherCovDO;
import com.medicare.mss.domainobject.EEMApplOtherPlanDO;
import com.medicare.mss.domainobject.EEMApplPlanDO;
import com.medicare.mss.domainobject.EEMApplProdSearchDO;
import com.medicare.mss.domainobject.EEMApplProductDO;
import com.medicare.mss.domainobject.EEMApplStatusTrackDO;
import com.medicare.mss.domainobject.EEMApplTriggerDO;
import com.medicare.mss.domainobject.EEMApplicationDO;
import com.medicare.mss.domainobject.EEMBeqDO;
import com.medicare.mss.domainobject.EEMLepPtnlUncovMthsDO;
import com.medicare.mss.domainobject.EEMLtcFacilityDO;
import com.medicare.mss.domainobject.EEMProfileItemDO;
import com.medicare.mss.domainobject.LepHistory;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.helper.EEMApplHelper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.ApplCacheVO;
import com.medicare.mss.vo.EEMApplAddressVO;
import com.medicare.mss.vo.EEMApplAgentVO;
import com.medicare.mss.vo.EEMApplAttestationVO;
import com.medicare.mss.vo.EEMApplCancelRequestVO;
import com.medicare.mss.vo.EEMApplCommentsVO;
import com.medicare.mss.vo.EEMApplEligibilityVO;
import com.medicare.mss.vo.EEMApplErrorVO;
import com.medicare.mss.vo.EEMApplLisVO;
import com.medicare.mss.vo.EEMApplMasterVO;
import com.medicare.mss.vo.EEMApplOtherCovVO;
import com.medicare.mss.vo.EEMApplOtherPlanVO;
import com.medicare.mss.vo.EEMApplPlanVO;
import com.medicare.mss.vo.EEMApplProductVO;
import com.medicare.mss.vo.EEMApplSearchVO;
import com.medicare.mss.vo.EEMApplStatusTrackVO;
import com.medicare.mss.vo.EEMApplicationVO;
import com.medicare.mss.vo.EEMLtcFacilityVO;
import com.medicare.mss.vo.EmPreSetNoteVO;
import com.medicare.mss.vo.MBD;
import com.medicare.mss.vo.PageableVO;

/**
 * This class contains Application functionality methods.
 * 
 * @author Wipro
 *
 */
@Service
@Transactional(rollbackFor = ApplicationException.class)
public class EEMApplService {

	@Autowired
	private EEMApplDAO applicationDAO;

	@Autowired
	private EEMApplLepDAO applLepDAO;

	@Autowired
	private EEMCodeCache eemCodeCache;

	@Autowired
	private EEMProfileSettings eemProfileSettings;

	@Autowired
	private EEMPersistence eemPersistence;

	@Autowired
	private CacheService sessionHelper;

	@Autowired
	private EEMDAO eemDao;

	@Autowired
	private EEMApplHelper applHelper;

	@Autowired
	private EEMApplValidationService applValidationService;

	@Autowired
	private EEMApplMemberCheckService applMemberCheckService;

	@Autowired 
	private EEMWfService wfService;
	 
	private String effStartDate = "00000000";
	private String partEffDate = "00/00/0000";

	@SuppressWarnings("unchecked")
	public EEMApplMasterVO getApplSearchDetails(Map<String, String> searchParamMap) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();

		EEMApplMasterVO applMasterVO = new EEMApplMasterVO();
		PageableVO pageableVO = applicationDAO.getApplSearchDetails(customerId, searchParamMap, false);
		if (!CollectionUtils.isEmpty((List<EEMApplSearchVO>) pageableVO.getContent())) {
			applMasterVO.setApplSearchList((List<EEMApplSearchVO>) pageableVO.getContent());
			applMasterVO.setNextPage(pageableVO.isNextPage());

			if (!CollectionUtils.isEmpty(applMasterVO.getApplSearchList())) {
				getApplDetails(customerId, applMasterVO);
				boolean isEEMSupervisor = sessionHelper.isEEMSupervisor();
				applHelper.setApplicationStatus(applMasterVO, isEEMSupervisor);
				applMasterVO.setHasOrigAppl(checkOrigApplRecords(customerId, applMasterVO.getApplVO().getApplId()));
				applMasterVO.getApplVO().setUpdateRec("Y");

				String npiInd = eemProfileSettings.getCalendarProfileItem(customerId, EEMProfileConstants.NPIIND);
				applMasterVO.setNpiInd(npiInd);
			}
		}
		return applMasterVO;
	}

	/*
	 * public PageableVO getApplSearchDetailsDB(String customerId, Map<String,
	 * String> searchParamMap) {
	 * 
	 * return applicationDAO.getApplSearchDetails(customerId, searchParamMap,
	 * false); }
	 */

	public EEMApplMasterVO getApplSearchSelect(String applId) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();

		EEMApplMasterVO applMasterVO = new EEMApplMasterVO();

		List<EEMApplSearchVO> applSearchVOList = new ArrayList<>();
		EEMApplSearchVO searchVO = new EEMApplSearchVO();
		searchVO.setApplId(Integer.parseInt(applId));
		searchVO.setCustomerId(customerId);
		applSearchVOList.add(searchVO);
		applMasterVO.setApplSearchList(applSearchVOList);

		getApplDetails(customerId, applMasterVO);

		boolean isEEMSupervisor = sessionHelper.isEEMSupervisor();
		applHelper.setApplicationStatus(applMasterVO, isEEMSupervisor);

		// Bugzilla defcet -830 fix -start
		applMasterVO.setHasOrigAppl(checkOrigApplRecords(customerId, Integer.parseInt(applId)));

		// Bugzilla defcet -830 fix -end
		applMasterVO.getApplVO().setUpdateRec("Y");

		String npiInd = eemProfileSettings.getCalendarProfileItem(customerId, EEMProfileConstants.NPIIND);
		applMasterVO.setNpiInd(npiInd);

		return applMasterVO;
	}

	public void getApplDetails(String customerId, EEMApplMasterVO applMasterVO) {

		EEMApplSearchVO applSearchVO = applMasterVO.getApplSearchList().get(0);
		int applId = applSearchVO.getApplId();

		EEMApplicationDO applDO = applicationDAO.getMasterDetails(applId, customerId);
		EEMApplicationVO applVO = new EEMApplicationVO();
		BeanUtils.copyProperties(applDO, applVO);
		applMasterVO.setApplVO(applVO);

		applMemberCheckService.getAddressDetails(customerId, applMasterVO, true);

		getProductDetails(customerId, applMasterVO);
		getOtherCovDetails(applMasterVO, applId, customerId);
		getAttestDetails(applMasterVO, applId, customerId);

		List<EEMApplCommentsDO> applCommentsDOList = applicationDAO.getCommentDetails(applId, customerId);
		List<EEMApplCommentsVO> applCommentsVOList = new ArrayList<>();

		CommonUtils.copyList(applCommentsDOList, applCommentsVOList, EEMApplCommentsVO.class);

		applMasterVO.setApplCommentsList(applCommentsVOList);

		List<EEMApplErrorDO> applErrorDOList = applicationDAO.getErrorDetails(applId, customerId);
		List<EEMApplErrorVO> applErrorVOList = new ArrayList<>();

		CommonUtils.copyList(applErrorDOList, applErrorVOList, EEMApplErrorVO.class);

		applMasterVO.setApplErrList(applErrorVOList);

		getAgentDetails(customerId, applMasterVO);

		EEMApplLisDO applLisDO = applicationDAO.getLisDetails(applId, customerId);
		EEMApplLisVO applLisVO = new EEMApplLisVO();
		if (applLisDO != null) {
			BeanUtils.copyProperties(applLisDO, applLisVO);
		}
		applMasterVO.setApplLisVO(applLisVO);
		getEligDetails(customerId, applMasterVO);

		String perZip5 = "";
		String perZip4 = "";
		String perCounty = "";

		if (null != applMasterVO.getApplAddress()) {
			perZip5 = applMasterVO.getApplAddress().getPerZip5();
			perZip4 = applMasterVO.getApplAddress().getPerZip4();
			perCounty = applMasterVO.getApplAddress().getPerCounty();
		}
		applMasterVO.setLstCity(eemPersistence.getLstCity(perZip5, perZip4, perCounty));
		applMasterVO.setLstCounty(eemPersistence.getLstCounty(perZip5));
		
		boolean lepTrgSkip = getLepPlatinoFlag(customerId, applMasterVO);
		if(lepTrgSkip)
			applMasterVO.setSuppLepPlatino("true");
		else
			applMasterVO.setSuppLepPlatino("false");
	}

	private boolean getLepPlatinoFlag(String customerId, EEMApplMasterVO applMasterVO) {

		String parmInd = "";
		String parmText = "";
		boolean lepTrgSkip = false;
		String specialInd = "";
		
		EEMProfileItemDO profile = eemProfileSettings.getProfileObject(customerId, EEMConstants.LEPTRGSKIP);
		if (profile != null) {
			parmInd=profile.getParmIndValue();
			parmText=profile.getParmTextValue();
		}
		EEMApplPlanVO applPlanVO = applMasterVO.getApplPlanVO();
		
		specialInd = applicationDAO.getGrpProdSpclTpe(customerId, applPlanVO.getEnrollGrpId(),
				applPlanVO.getReqDtCov(), applPlanVO.getEnrollProduct(), applPlanVO.getEnrollPlan(),
				applPlanVO.getEnrollPbp(), applPlanVO.getEnrollSegment());
		
		if(parmInd.equals("Y") && parmText.equals(specialInd) && specialInd.equals("A"))
			lepTrgSkip = true;
		
		return lepTrgSkip;
	}

	private void getEligDetails(String customerId, EEMApplMasterVO applMasterVO) {

		EEMApplSearchVO applSearchVO = applMasterVO.getApplSearchList().get(0);
		int applId = applSearchVO.getApplId();

		EEMApplEligibilityDO applEligiDO = applicationDAO.getEligDetails(applId, customerId);
		EEMApplEligibilityVO applEligiVO = new EEMApplEligibilityVO();
		if (applEligiDO != null) {
			BeanUtils.copyProperties(applEligiDO, applEligiVO);
		}
		applMasterVO.setApplEligiVO(applEligiVO);
	}

	private void getAgentDetails(String customerId, EEMApplMasterVO applMasterVO) {

		EEMApplSearchVO applSearchVO = applMasterVO.getApplSearchList().get(0);
		int applId = applSearchVO.getApplId();
		String effDate = applMasterVO.getApplVO().getSignDt();

		EEMProfileItemDO item = eemProfileSettings.getProfileObject(customerId, EEMProfileConstants.AGENTDT);
		if ("R".equalsIgnoreCase(item.getParmIndValue())) {
			effDate = applMasterVO.getApplPlanVO().getReqDtCov();
		}

		EEMApplAgentDO applAgentDO = applicationDAO.getAgentDetails(applId, customerId, effDate);
		EEMApplAgentVO applAgentVO = new EEMApplAgentVO();
		if (applAgentDO != null) {
			BeanUtils.copyProperties(applAgentDO, applAgentVO);
		}
		applMasterVO.setApplAgentVO(applAgentVO);
		/*
		 * applMasterVO.setLstBrokAgencyIds(applicationDAO.getLstBrokAgency(customerId,
		 * effDate)); if (applAgentDO != null) {
		 * applMasterVO.setLstBrokAgentIds(applicationDAO.getLstBrokAgents(customerId,
		 * applAgentDO.getBrokerType(), applAgentDO.getCommAgencyId(), effDate)); }
		 */
	}

	private void getAttestDetails(EEMApplMasterVO applMasterVO, int applId, String customerId) {

		List<EEMApplAttestationDO> applAttestDOList = applicationDAO.getAttestationDetails(applId, customerId);
		List<EEMApplAttestationVO> applAttestVOList = new ArrayList<>();
		int[] index = { 0 };
		applAttestDOList.forEach(applAttestDO -> {
			EEMApplAttestationVO applAttestVO = new EEMApplAttestationVO();
			BeanUtils.copyProperties(applAttestDO, applAttestVO);

			applAttestVO.setIndex("" + index[0]++);
			applAttestVOList.add(applAttestVO);
		});
		applMasterVO.setApplAttestationList(applAttestVOList);
	}

	public void getOtherCovDetails(EEMApplMasterVO applMasterVO, int applId, String customerId) {

		EEMApplOtherCovVO applOtherCovVO = getOtherCov(customerId, applId);

		applMasterVO.setApplOtherCovVO(applOtherCovVO);

		List<LabelValuePair> list = new ArrayList<>();

		if (StringUtils.isNotBlank(applMasterVO.getApplPlanVO().getReqDtCov())) {
			String reqDtCov = DateFormatter.reFormat(applMasterVO.getApplPlanVO().getReqDtCov(),
					DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
			list = eemCodeCache.getInstLookUp(customerId, reqDtCov);
		}
		/*
		 * String reqDtCov =
		 * DateFormatter.reFormat(applMasterVO.getApplPlanVO().getReqDtCov(),
		 * DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD); List<LabelValuePair> list
		 * = eemCodeCache.getInstLookUp(customerId, reqDtCov);
		 */
		applMasterVO.setLstInstitutes(list);
	}

	public EEMApplOtherCovVO getOtherCov(String customerId, int applId) {

		EEMApplOtherCovDO eemApplOtherCovDO = applicationDAO.getOtherCovDetails(applId, customerId);
		String ltcFacId = null;

		EEMApplOtherCovVO eemApplOtherCovVO = new EEMApplOtherCovVO();
		if (eemApplOtherCovDO != null) {
			ltcFacId = eemApplOtherCovDO.getNameInstitute();
			BeanUtils.copyProperties(eemApplOtherCovDO, eemApplOtherCovVO);
		}
		if (StringUtils.isNoneBlank(ltcFacId)) {
			List<EEMLtcFacilityDO> eemLtcFacilityDODOList = eemPersistence.getLtcDetails(customerId);
			for (EEMLtcFacilityDO eemLtcFacilityDO : eemLtcFacilityDODOList) {
				String facId = eemLtcFacilityDO.getNameInstitute();
				if (StringUtils.equals(ltcFacId, facId)) {
					eemApplOtherCovVO.setNameInstituteDes(eemLtcFacilityDO.getNameInstituteDes());
					eemApplOtherCovVO.setLtcFacPhone(eemLtcFacilityDO.getLtcFacilityPhone());
					eemApplOtherCovVO.setLtcFacAddress(eemLtcFacilityDO.getLtcFacilityAddress());
					eemApplOtherCovVO.setEffStartDate(eemLtcFacilityDO.getEffStartDate());
					eemApplOtherCovVO.setEffEndDate(eemLtcFacilityDO.getEffEndDate());
					return eemApplOtherCovVO;
				}
			}
		}
		return eemApplOtherCovVO;
	}

	private void getProductDetails(String customerId, EEMApplMasterVO applMasterVO) {

		EEMApplSearchVO applSearchVO = applMasterVO.getApplSearchList().get(0);
		int applId = applSearchVO.getApplId();

		EEMApplPlanDO applPlanDO = applicationDAO.getPlanDetails(applId, customerId);
		EEMApplPlanVO applPlanVO = new EEMApplPlanVO();
		if (applPlanDO != null) {
			BeanUtils.copyProperties(applPlanDO, applPlanVO);
		}
		applMasterVO.setApplPlanVO(applPlanVO);

		EEMApplProductVO grpProdVO = new EEMApplProductVO();
		String lineOfBiz = applicationDAO.getLineOfBusniess(customerId, applPlanVO.getEnrollGrpId(),
				applPlanVO.getReqDtCov(), applPlanVO.getEnrollProduct(), applPlanVO.getEnrollPlan(),
				applPlanVO.getEnrollPbp(), applPlanVO.getEnrollSegment());
		grpProdVO.setLineOfBusiness(lineOfBiz);

		EEMApplOtherPlanDO applOtherPlanDO = applicationDAO.getPCPDetails(applId, customerId);
		EEMApplOtherPlanVO applOtherPlanVO = new EEMApplOtherPlanVO();
		if (applOtherPlanDO != null) {
			BeanUtils.copyProperties(applOtherPlanDO, applOtherPlanVO);
		}
		applMasterVO.setApplOtherPlanVO(applOtherPlanVO);

		applicationDAO.getPCPName(customerId, applId, applPlanVO.getReqDtCov(), lineOfBiz, applOtherPlanVO);

		String customerNbr = sessionHelper.getUserInfo().getCustNbr();
		String[] arr = applicationDAO.getPlanType(customerNbr, applPlanVO.getEnrollPlan(), applPlanVO.getEnrollPbp());
		if (arr != null) {
			grpProdVO.setPlanDesignation(arr[1]);
		}
		String currGrpName = applicationDAO.getGroupName(customerId, applPlanVO.getCurrGrpId(),
				applPlanVO.getReqDtCov());
		String enrollGrpName = applicationDAO.getGroupName(customerId, applPlanVO.getEnrollGrpId(),
				applPlanVO.getReqDtCov());
		String currProdName = applicationDAO.getProductName(customerId, applPlanVO.getCurrProductId(),
				applPlanVO.getReqDtCov());
		String enrollProdName = applicationDAO.getProductName(customerId, applPlanVO.getEnrollProduct(),
				applPlanVO.getReqDtCov());
		grpProdVO.setCurrGroupName(currGrpName);
		grpProdVO.setEnrollGroupName(enrollGrpName);
		grpProdVO.setEnrollProdName(enrollProdName);
		grpProdVO.setCurrProdName(currProdName);

		applMasterVO.setGrpProdVO(grpProdVO);
	}

	public MBD getEligibilityDetails(Map<String, String> searchParamMap) {

		MBD mbd = null;
		String beqCheck = "";

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String searchHic = trimToEmpty(searchParamMap.get("medicareId"));
		String searchLastName = trimToEmpty(searchParamMap.get("lastName"));
		String searchBirthDate = DateFormatter.reFormat(trimToEmpty(searchParamMap.get("DOB")),
				DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
		String isHicOrMbi = StringUtil.isHicOrMbi(searchHic);

		EEMProfileItemDO item = eemProfileSettings.getProfileObject(customerId, EEMConstants.BEQCHECK);
		if (item != null) {
			beqCheck = trimToEmpty(item.getParmIndValue());
		}
		beqCheck = beqCheck.equalsIgnoreCase("") ? "N" : "Y";

		String hicNum = isHicOrMbi.equalsIgnoreCase("mbi") ? "" : searchHic;
		String mbi = isHicOrMbi.equalsIgnoreCase("mbi") ? searchHic : "";

		mbd = applMemberCheckService.verifyEligibility(hicNum, searchLastName, searchBirthDate, beqCheck, isHicOrMbi,
				mbi);
		if (mbd != null) {
			mbd = formatMBD(mbd);
		} else {
			mbd = new MBD();
		}
		return mbd;
	}

	public MBD formatMBD(MBD mbd) {

		mbd.setBirthDate(DateFormatter.reFormat(DateFormatter.dateFilter(mbd.getBirthDate()), DateFormatter.YYYYMMDD,
				DateFormatter.MM_DD_YYYY));
		mbd.setGenderCd(eemCodeCache.getShortGenderNumDesc(mbd.getGenderCd()));
		mbd.setCountyCd(eemCodeCache.getCountyNameByCd(mbd.getStateCd(), mbd.getCountyCd()));
		mbd.setEsrdInd(trimToEmpty(mbd.getEsrdInd()).equalsIgnoreCase("") ? " N " : mbd.getEsrdInd());
		mbd.setEsrdStartDate(DateFormatter.reFormat(DateFormatter.dateFilter(mbd.getEsrdStartDate()),
				DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		mbd.setEsrdEndDate(DateFormatter.reFormat(DateFormatter.dateFilter(mbd.getEsrdEndDate()),
				DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		mbd.setInstInd(trimToEmpty(mbd.getInstInd()).equalsIgnoreCase("") ? " N " : mbd.getInstInd());
		mbd.setInstStartDate(DateFormatter.reFormat(DateFormatter.dateFilter(mbd.getInstStartDate()),
				DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		mbd.setInstEndDate(DateFormatter.reFormat(DateFormatter.dateFilter(mbd.getInstEndDate()),
				DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		mbd.setMedicInd(trimToEmpty(mbd.getMedicInd()).equalsIgnoreCase("") ? " N " : mbd.getMedicInd());
		mbd.setMedicStartDate(DateFormatter.reFormat(DateFormatter.dateFilter(mbd.getMedicStartDate()),
				DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		mbd.setMedicEndDate(DateFormatter.reFormat(DateFormatter.dateFilter(mbd.getMedicEndDate()),
				DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		mbd.setHospiceInd(trimToEmpty(mbd.getHospiceInd()).equalsIgnoreCase("") ? " N " : mbd.getHospiceInd());
		mbd.setHospiceStartDate(DateFormatter.reFormat(DateFormatter.dateFilter(mbd.getHospiceStartDate()),
				DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		mbd.setHospiceEndDate(DateFormatter.reFormat(DateFormatter.dateFilter(mbd.getHospiceEndDate()),
				DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		mbd.setPrtAEntitleDate(DateFormatter.reFormatFiltered(mbd.getPrtAEntitleDate(), DateFormatter.YYYYMMDD,
				DateFormatter.MM_DD_YYYY));
		mbd.setPrtAEntitleEndDate(DateFormatter.reFormatFiltered(mbd.getPrtAEntitleEndDate(), DateFormatter.YYYYMMDD,
				DateFormatter.MM_DD_YYYY));
		mbd.setPrtBEntitleDate(DateFormatter.reFormatFiltered(mbd.getPrtBEntitleDate(), DateFormatter.YYYYMMDD,
				DateFormatter.MM_DD_YYYY));
		mbd.setPrtBEntitleEndDate(DateFormatter.reFormatFiltered(mbd.getPrtBEntitleEndDate(), DateFormatter.YYYYMMDD,
				DateFormatter.MM_DD_YYYY));
		mbd.setPrtDEligibleDate(DateFormatter.reFormatFiltered(mbd.getPrtDEligibleDate(), DateFormatter.YYYYMMDD,
				DateFormatter.MM_DD_YYYY));
		mbd.setSubsidyStartDate1(DateFormatter.reFormatFiltered(mbd.getSubsidyStartDate1(), DateFormatter.YYYYMMDD,
				DateFormatter.MM_DD_YYYY));
		mbd.setSubsidyEndDate1(DateFormatter.reFormatFiltered(mbd.getSubsidyEndDate1(), DateFormatter.YYYYMMDD,
				DateFormatter.MM_DD_YYYY));
		mbd.setDeathDate(
				DateFormatter.reFormatFiltered(mbd.getDeathDate(), DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));

		return mbd;
	}

	public boolean eemApplCancellation(EEMApplCancelRequestVO applCancReq) {

		boolean cancAppl = false;
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String userId = applCancReq.getUserId();
		int count = 0;
		int applId = applCancReq.getApplId();
		String reasonPDP = applCancReq.getLtrReasonCd();
		String enrollPlanDesgn = applCancReq.getPlanDesg();
		String date = applCancReq.getDate();

		if (applCancReq.getApplCommentsList() != null) {
			updateApplComments(applCancReq.getApplCommentsList(), applId);
		}

		count = applCancelLtrReg(userId, customerId, applId, reasonPDP, enrollPlanDesgn, date);

		if (count >= 1) {
			cancAppl = true;
			String applStatus = EEMConstants.APPL_STATUS_CANCELED;
			cancelTimers(userId, customerId, applId, applStatus);
			List<EEMApplErrorDO> lstTemp = applicationDAO.getErrorDetails(applId, customerId);
			if (!CollectionUtils.isEmpty(lstTemp)) {
				int rslt = closeApplErrors(date, userId, lstTemp);
				cancAppl = rslt > 0;
			}
		}
		return cancAppl;
	}

	public int applCancelLtrReg(String userId, String mfId, int applId, String reasonCd, String enrollPlanDesgn,
			String date) {

		int sqlCnt = 0;
		String applicationId = String.valueOf(applId);

		if (!(reasonCd.equals("10005") || reasonCd.equals("10006") || reasonCd.equals("10007"))) {
			String triggerCode = applicationDAO.getTriggerCode(mfId, enrollPlanDesgn,
					EEMConstants.EEM_APPL_CANCEL_TRIG_FUA_TYPE);
			if (triggerCode != null) {
				String trigEffDate = DateFormatter.reFormat(date, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);

				EEMApplTriggerDO trig = applHelper.prepareApplTriggerDO(applicationId,
						EEMConstants.TRIG_TYPE_MANUAL_LTR, EEMConstants.TRIG_STATUS_OPEN, triggerCode, trigEffDate);

				sqlCnt = applicationDAO.insertApplTrigger(trig);

				if (sqlCnt != 1) {
					throw new ApplicationException("Invalid SQL Update Count [" + sqlCnt + "]");
				}
			}
		}
		sqlCnt = applicationDAO.updtApplCancel(applId, userId, mfId, reasonCd);
		if (sqlCnt != 1)
			throw new ApplicationException("Could not update Application table for reject reason: [" + reasonCd + "]");
		return sqlCnt;
	}

	public void cancelTimers(String userId, String mfId, int applId, String applStatus) {
		applicationDAO.closeFUATrigger(mfId, applId, userId, EEMConstants.TRIG_STATUS_CLOSED, applStatus);
	}

	public EEMApplicationVO getApplicationDetails(String customerId, int applId) {

		EEMApplicationDO applDO = applicationDAO.getMasterDetails(applId, customerId);
		EEMApplicationVO applVO = new EEMApplicationVO();
		if (applDO != null) {
			BeanUtils.copyProperties(applDO, applVO);
		}
		return applVO;
	}

	public EEMApplMasterVO getApplUpdate(EEMApplMasterVO applMasterVO) {
		String custId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();
		applMasterVO.getApplVO().setCustomerId(custId);
		applMasterVO.getApplVO().setMessage("");
		if (!trimToEmpty(applMasterVO.getApplVO().getMbrHicNbr()).equals("")) {
			String flag = StringUtil.isHicOrMbi(applMasterVO.getApplVO().getMbrHicNbr());
			applMasterVO.getApplVO().setIsHicOrMbi(flag);
			if (applMasterVO.getApplVO().getIsHicOrMbi().equals("mbi"))
				applMasterVO.getApplVO().setMbi(applMasterVO.getApplVO().getMbrHicNbr());
		}
		boolean incomplete = applHelper.isIncomplete(applMasterVO);
		if (checkLockInd(applMasterVO, sessionHelper)) {
			if (!incomplete) {
				boolean memberDetails = applMemberCheckService.getMemberDetailsDB(applMasterVO, true);
				if (memberDetails) {
					applMasterVO.getApplVO().setMessage("");
				}
				applMasterVO = applValidationService.validateApplication(applMasterVO);
			}
			String msg = trimToEmpty(applMasterVO.getApplVO().getMessage());
			if (msg.equals("")) {
				applMasterVO.setBeqCheck(trimToEmpty(eemProfileSettings.getCalendarProfileInd(
						applMasterVO.getApplVO().getCustomerId(), EEMProfileConstants.BEQCHECK)));
				String resetLstUpdtTime = applMasterVO.getApplVO().getLstUpdtTime();
				String resetLstUpdtUserId = applMasterVO.getApplVO().getLstUpdtUserId();
				try {
					setApplDetails(applMasterVO);
				} catch (Exception e) {
					if (applMasterVO.getApplVO().getMessage()
							.equalsIgnoreCase("No Override Duplicate Application found. \n")
							|| applMasterVO.getApplVO().getMessage()
									.equalsIgnoreCase("Exsisting Duplicate Application Found. \n")) {
						applMasterVO.getApplVO().setAppDuplicateCheck("N");
					}
					String updateRec = applMasterVO.getApplVO().getUpdateRec();
					if ("N".equalsIgnoreCase(updateRec)) {
						applMasterVO.getApplVO().setLstUpdtTime("");
						applMasterVO.getApplVO().setCreateTime("");
						applMasterVO.getApplVO().setCreateUserId("");
						applMasterVO.getApplVO().setLstUpdtUserId("");
					} else {
						applMasterVO.getApplVO().setLstUpdtTime(resetLstUpdtTime);
						applMasterVO.getApplVO().setLstUpdtUserId(resetLstUpdtUserId);
					}
					throw new ApplicationException(e, "Update Failed ");
				}
			}
		} else {
			getErrorDetails(applMasterVO);
		}
		applHelper.setApplicationStatus(applMasterVO, sessionHelper.isEEMSupervisor());
		
		int applId = applMasterVO.getApplVO().getApplId();
		
		if (!wfService.isCaseExists(custId, applId)) {
			int caseId = wfService.createCase(applMasterVO);
			if (caseId > 0) {
				List<EEMApplErrorDO> lstError = applicationDAO.getErrorDetails(applId, custId);
				if (CommonUtils.isNotEmpty(lstError)) {
					List<String> errorCds = lstError.stream().map(errDO -> errDO.getErrorCd())
							.collect(Collectors.toList());
					List<String> errorMsgs = lstError.stream().map(errDO -> errDO.getErrorMsg())
							.collect(Collectors.toList());
					wfService.createActivities(custId, userId, caseId, errorCds, errorMsgs, applId);
				}
			}
		}

		boolean lepTrgSkip = getLepPlatinoFlag(custId, applMasterVO);
		if(lepTrgSkip)
			applMasterVO.setSuppLepPlatino("true");
		else
			applMasterVO.setSuppLepPlatino("false");
		
		return applMasterVO;
	}

	public boolean checkOrigApplRecords(String customerId, int applId) {
		return applicationDAO.getOrigAppl(applId, customerId);
	}

	public boolean setApplDetails(EEMApplMasterVO eemApplMasterVO) throws ParseException {

		String message = "";
		try {
			String customerId = sessionHelper.getUserInfo().getCustomerId();
			String userId = sessionHelper.getUserInfo().getUserId();
			String updateRecInd = eemApplMasterVO.getApplVO().getUpdateRec();

			List<EEMApplErrorVO> lstErrors = eemApplMasterVO.getApplErrList();
			EEMApplicationDO applDO = new EEMApplicationDO();
			EEMApplPlanVO applPlanVO = eemApplMasterVO.getApplPlanVO();

			String applStatus = trimToEmpty(eemApplMasterVO.getApplVO().getApplStatus());
			String currStatus = trimToEmpty(eemApplMasterVO.getApplVO().getCurrStatus());
			if (!applStatus.equals(EEMConstants.APPL_STATUS_HOLD)
					&& !(applStatus.equals(EEMConstants.APPL_STATUS_FORCEDAPPR)
							&& (currStatus.equals(EEMConstants.APPL_STATUS_ELGWARNING)
									|| currStatus.equals(EEMConstants.APPL_STATUS_ELGNOTFND)
									|| (currStatus.equals(EEMConstants.APPL_STATUS_BEQPENDING)
											&& eemApplMasterVO.getApplEligiVO().getEligOverInd().equals("Y"))))
					&& !isCancelOrDenied(applStatus) && lstErrors != null && !lstErrors.isEmpty()) {
				String evalStatus = evalErrorStatus(lstErrors);
				if (!evalStatus.equals("")) {
					eemApplMasterVO.getApplVO().setApplStatus(evalStatus);
				}
			}
			boolean bypassUpdateduplicate = false;
			if (eemApplMasterVO.getApplVO().getAppDuplicateCheck() != null
					&& eemApplMasterVO.getApplVO().getAppDuplicateCheck().equalsIgnoreCase("Y")
					&& applStatus.equals(EEMConstants.APPL_STATUS_HOLD)) {
				message = "Please select other Status for Override Duplicate Application. \n";
				eemApplMasterVO.getApplVO().setAppDuplicateCheck("N");
			} else {
				if (eemApplMasterVO.getApplVO().getAppDuplicateCheck() != null
						&& eemApplMasterVO.getApplVO().getAppDuplicateCheck().equalsIgnoreCase("Y")) {
					BeanUtils.copyProperties(eemApplMasterVO.getApplVO(), applDO);
					List<String[]> lstOrgPlan = applicationDAO.checkDuplicateApplication(applDO,
							sessionHelper.getUserInfo().getCustNbr());
					List<String[]> lstOrgPlanExsisting = applicationDAO.checkDuplicateEnrollment(applDO);
					if (lstOrgPlan.isEmpty()) {
						message = "No Override Duplicate Application found. \n";
						eemApplMasterVO.getApplVO().setAppDuplicateCheck("N");
						bypassUpdateduplicate = true;
					}
					if (!lstOrgPlanExsisting.isEmpty()) {
						message = "";
						int orgPlanSize = lstOrgPlanExsisting.size();
						String reqDtCov = DateFormatter.reFormat(eemApplMasterVO.getApplPlanVO().getReqDtCov(),
								DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
						for (int i = 0; i < orgPlanSize; i++) {
							String[] orgPlan = lstOrgPlanExsisting.get(i);
							String planId = trimToEmpty(orgPlan[3]);
							String pbpId = trimToEmpty(orgPlan[4]);
							String productId = trimToEmpty(orgPlan[5]);
							String grpId = trimToEmpty(orgPlan[6]);
							String pbpSegmentId = trimToEmpty(orgPlan[7]);
							String startDate = orgPlan[2];

							if (DateMath.isGreaterThanOrEqual(reqDtCov, startDate)
									&& applPlanVO.getEnrollPlan().equalsIgnoreCase(planId)
									&& applPlanVO.getEnrollPbp().equalsIgnoreCase(pbpId)
									&& applPlanVO.getEnrollProduct().equalsIgnoreCase(productId)
									&& applPlanVO.getEnrollGrpId().equalsIgnoreCase(grpId)
									&& applPlanVO.getEnrollSegment().equalsIgnoreCase(pbpSegmentId)) {
								message = "Processed application found, can't override duplicate application. \n";
								eemApplMasterVO.getApplVO().setAppDuplicateCheck("N");
								bypassUpdateduplicate = true;
							}
						}
					}
					if (message.length() == 0 && !lstOrgPlan.isEmpty()
							&& ("CMA".equalsIgnoreCase(eemApplMasterVO.getApplVO().getApplType())
									|| applValidationService.checkDuplicate(eemApplMasterVO, lstOrgPlan))) {
						int count = applicationDAO.updateOverrideData(customerId,
								eemApplMasterVO.getApplVO().getApplId(), eemApplMasterVO.getApplVO().getMbrHicNbr());
						if (count > 0) {
							applicationDAO.updateDuplicateAppError(lstOrgPlan, customerId);
							insertErrorApplError(lstOrgPlan, customerId, eemApplMasterVO.getApplVO().getApplId(),
									userId);
							message = "Override Duplicate Application Successful. \n";
							bypassUpdateduplicate = true;
							if ((lstErrors != null && lstErrors.isEmpty()) || lstErrors == null) {
								eemApplMasterVO.getApplVO().setApplStatus("READY");
							}
						}
					}
				}
			}
			if (!setMasterDetails(eemApplMasterVO)) {
				message = "Application Master Update failed.\n";
			}
			int applId = eemApplMasterVO.getApplVO().getApplId();

			if (!setAddressDetails(eemApplMasterVO.getApplAddress(), updateRecInd, applId)) {
				message += "Address Update failed.\n";
			}
			if (!setProductDetails(eemApplMasterVO.getApplPlanVO(), eemApplMasterVO.getApplOtherPlanVO(), updateRecInd,
					eemApplMasterVO.getGrpProdVO().getLineOfBusiness(), applId)) {
				message += "Product details Update failed.\n";
			}
			if (!setOtherCovDetails(eemApplMasterVO.getApplOtherCovVO(), updateRecInd, applId)) {
				message += "Other Coverage Update failed.\n";
			}
			if (!setAttestDetails(eemApplMasterVO.getApplAttestationList(), updateRecInd, applId)) {
				message += "Attestation details Update failed.\n";
			}
			if (!setAgentDetails(eemApplMasterVO.getApplAgentVO(), updateRecInd, applId)) {
				message += "Agent details Update failed.\n";
			}
			if (!updateApplComments(eemApplMasterVO.getApplCommentsList(), applId)) {
				message += "Comments Update failed.\n";
			}
			if (!setEligDetails(eemApplMasterVO.getApplEligiVO(), eemApplMasterVO.getApplVO(),
					eemApplMasterVO.getMbd())) {
				message += "Eligibility details Update failed.\n";
			}
			if (!setBEQDetails(eemApplMasterVO)) {
				message += "BEQ details Update failed.\n";
			}
			if (!setErrorDetails(eemApplMasterVO.getApplErrList(), eemApplMasterVO.getApplVO().getApplId(),
					eemApplMasterVO.getApplVO().getApplDate(), eemApplMasterVO.getApplVO().getApplStatus())) {
				message += "Error details Update failed.\n";
			}
			if ((!isCancelOrDenied(eemApplMasterVO.getApplVO().getApplStatus()))
					&& (!setLEPUncovMnthCalC(customerId, userId, eemApplMasterVO))) {
				message += "Application Trigger Update failed.\n";
			}
			if (!setLisDetails(eemApplMasterVO.getApplLisVO(), updateRecInd, applId,
					eemApplMasterVO.getApplVO().isLisChanged())) {
				message += "LIS Information Update failed.\n";
			}
			if (updateRecInd.equals("N")) {
				int count = applicationDAO.setOrigDetails(eemApplMasterVO, customerId, userId);
				if (count > 0) {
					eemApplMasterVO.setHasOrigAppl(true);
				}
			}
			if (message.equals("") || bypassUpdateduplicate) {
				if (updateRecInd.equals("Y")) {
					Boolean checkOrig = checkOrigApplRecords(customerId, applId);
					if (checkOrig) {
						eemApplMasterVO.setHasOrigAppl(true);
					}
				}
				eemApplMasterVO.getApplVO().setUpdateRec("Y");
				if (bypassUpdateduplicate) {
					message += "Updated Successfully";
					eemApplMasterVO.getApplVO().setMessage(message);
				} else {
					eemApplMasterVO.getApplVO().setMessage("Updated Successfully");
				}
				return true;
			} else {
				eemApplMasterVO.getApplVO().setMessage(message);
				throw new ApplicationException(message);
			}
		} catch (ApplicationException exp) {
			eemApplMasterVO.getApplVO().setMessage(message);
			throw new ApplicationException(exp);
		}
	}

	private boolean setLEPUncovMnthCalC(String customerId, String userId, EEMApplMasterVO objVO) throws ParseException {

		boolean lepCalFlag = false;
		String applId = String.valueOf(objVO.getApplVO().getApplId());
		String updateRecInd = objVO.getApplVO().getUpdateRec();
		String applStatus = trimToEmpty(objVO.getApplVO().getApplStatus());
		String reqDateCov = trimToEmpty(objVO.getApplPlanVO().getReqDtCov());
		String mbrHicNbr = trimToEmpty(objVO.getApplVO().getMbrHicNbr());
		String hicNbr = trimToEmpty(objVO.getApplVO().getDisplayHic());
		String enrollPlanDesgn = trimToEmpty(objVO.getApplVO().getEnrollPlanDesgn());
		SimpleDateFormat dateformat = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

		if ("F".equalsIgnoreCase(trimToEmpty(objVO.getApplPlanVO().getElectionType()))) {
			applLepDAO.overridePLepApplDetails(customerId, EEMConstants.WEBAPPL, applId, false);
			applLepDAO.closeOBCTimer(customerId, applId);
			return true;
		}
		MBD mbd = objVO.getMbd();
		if (null == mbd) {
			mbd = applMemberCheckService.verifyEligibility(hicNbr, trimToEmpty(objVO.getApplVO().getMbrLastName()),
					trimToEmpty(objVO.getApplVO().getMbrBirthDt()), "", StringUtil.isHicOrMbi(mbrHicNbr), mbrHicNbr);
		}
		if (mbd != null && "D".equalsIgnoreCase(trimToEmpty(mbd.getLivingStatus()))) {
			return true;
		}
		String lepFlag = eemProfileSettings.getParmIndWithOutEffDate(customerId, EEMConstants.LEP_CALCULATION_FLAG);

		objVO.getApplVO().setLepCalcFlag(lepFlag);

		boolean isReqDtCovChanged = true;
		boolean isHicNbrChanged = true;

		if (!"N".equals(updateRecInd)) {
			String lefEffDate = applLepDAO.validateReqDtCov(customerId, applId);
			if (isEmpty(lefEffDate)) {
				isReqDtCovChanged = true;
			} else {
				Date oldReqDtCov = dateformat.parse(lefEffDate);
				Date newReqDtCov = formatter.parse(reqDateCov);
				if (oldReqDtCov.compareTo(newReqDtCov) != 0) {
					isReqDtCovChanged = true;
				} else {
					isReqDtCovChanged = false;
				}
			}
			isHicNbrChanged = applLepDAO.validateHicNbrChanged(customerId, mbrHicNbr, applId);
		}
		boolean lepTrgSkip = getLepPlatinoFlag(customerId, objVO);
		if ((isReqDtCovChanged || isHicNbrChanged) && lepFlag != null && "C".equalsIgnoreCase(lepFlag) && !lepTrgSkip) {
			String lisEDate1 = "";
			String partDCovDate2 = "";
			String rdsEDate3 = "";
			String birthDate4 = "";
			String partDEligibilityDate5 = "";
			String lepInceptionDate6 = "";
			Date reqDtCov = null;
			Date rdsSDate = null;
			Date prtdSDate = null;
			String reqDtCovinString = "";
			if ("MAPD".equalsIgnoreCase(enrollPlanDesgn) || "PDP".equalsIgnoreCase(enrollPlanDesgn)) {
				int copayLevelId1 = 0;
				EEMLepPtnlUncovMthsDO lepDO = new EEMLepPtnlUncovMthsDO();

				List<LepHistory> prtDHistoryVO = applLepDAO.getPartDHistory(hicNbr, mbrHicNbr,trimToEmpty(objVO.getApplVO().getEligibilitySrcTable()));
				List<LepHistory> rdsHistoryVO = applLepDAO.getRdsHistory(hicNbr, mbrHicNbr,trimToEmpty(objVO.getApplVO().getEligibilitySrcTable()));

				LepHistory firstRowPartDhistoryVO = null;
				LepHistory firstRowRdsHistoryVO = null;
				if (!rdsHistoryVO.isEmpty()) {
					firstRowPartDhistoryVO = prtDHistoryVO.get(0);
					firstRowRdsHistoryVO = rdsHistoryVO.get(0);
				}
				if (!isEmpty(reqDateCov)) {
					reqDtCov = formatter.parse(reqDateCov);
					reqDtCovinString = dateformat.format(reqDtCov);
				}
				if (!isEmpty(mbd.getCopayLevelId1())) {
					copayLevelId1 = Integer.parseInt(mbd.getCopayLevelId1());
				}
				if (null != firstRowPartDhistoryVO) {
					String partDhistoryEndDate = "";
					String partDhistoryStartDate = "";
					if (StringUtil.isNotNullNotEmptyNotWhiteSpace(firstRowPartDhistoryVO.getEndDate())) {
					partDhistoryEndDate = DateFormatter.reFormat(firstRowPartDhistoryVO.getEndDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
					}
					if (StringUtil.isNotNullNotEmptyNotWhiteSpace(firstRowPartDhistoryVO.getStartDate())) {
					partDhistoryStartDate = DateFormatter.reFormat(firstRowPartDhistoryVO.getStartDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
					}
					
					if (StringUtil.isNotNullNotEmptyNotWhiteSpace(firstRowPartDhistoryVO.getEndDate())) {
						if ((effStartDate).equalsIgnoreCase(partDhistoryEndDate)
								&& dateformat.parse(partDhistoryStartDate).compareTo(reqDtCov) < 0) {
							lepCalFlag = true;
						}
					}
					if (StringUtil.isNotNullNotEmptyNotWhiteSpace(firstRowPartDhistoryVO.getEndDate())) {
						if (!(effStartDate).equalsIgnoreCase(partDhistoryEndDate)) {
							partDCovDate2 = DateMath.addOneDay(partDhistoryEndDate);
						} else {
							if (StringUtil.isNotNullNotEmptyNotWhiteSpace(firstRowPartDhistoryVO.getStartDate())) {
								prtdSDate = dateformat.parse(partDhistoryStartDate);
								if (reqDtCov.compareTo(prtdSDate) > 0) {
									String prtDEndDate = "";
									if (prtDHistoryVO.size() > 1) {
										prtDEndDate = prtDHistoryVO.get(1).getEndDate();
									}
									firstRowPartDhistoryVO.setEndDate(prtDEndDate);
										if (StringUtil.isNotNullNotEmptyNotWhiteSpace(firstRowPartDhistoryVO.getEndDate())) {
										partDhistoryEndDate = DateFormatter.reFormat(firstRowPartDhistoryVO.getEndDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
										}
									if (StringUtil
											.isNotNullNotEmptyNotWhiteSpace(firstRowPartDhistoryVO.getEndDate())) {
										partDCovDate2 = DateMath.addOneDay(partDhistoryEndDate);
									} else {
										partDCovDate2 = effStartDate;
									}
								} else {
									lepCalFlag = true;
								}
							} else {
								partDCovDate2 = effStartDate;
							}
						}
					} else {
						partDCovDate2 = effStartDate;
					}
				}
				if (null != firstRowRdsHistoryVO) {
					
					String rdsHistoryEndDate = "";
					String rdsHistoryStartDate = "";
					if (StringUtil.isNotNullNotEmptyNotWhiteSpace(firstRowRdsHistoryVO.getEndDate())) {
						rdsHistoryEndDate = DateFormatter.reFormat(firstRowRdsHistoryVO.getEndDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
					}
					if (StringUtil.isNotNullNotEmptyNotWhiteSpace(firstRowRdsHistoryVO.getStartDate())) {
						rdsHistoryStartDate = DateFormatter.reFormat(firstRowRdsHistoryVO.getStartDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
					}
					
					if (StringUtil.isNotNullNotEmptyNotWhiteSpace(firstRowRdsHistoryVO.getEndDate())) {
						if ((effStartDate).equalsIgnoreCase(rdsHistoryEndDate)
								&& dateformat.parse(rdsHistoryStartDate).compareTo(reqDtCov) < 0) {
							lepCalFlag = true;
						}
					}
					if (StringUtil.isNotNullNotEmptyNotWhiteSpace(firstRowRdsHistoryVO.getEndDate())) {
						if (!(effStartDate).equalsIgnoreCase(rdsHistoryEndDate)) {
							rdsEDate3 = DateMath.addOneDay(rdsHistoryEndDate);
						} else {
							if (StringUtil.isNotNullNotEmptyNotWhiteSpace(firstRowRdsHistoryVO.getStartDate())) {
								rdsSDate = dateformat.parse(rdsHistoryStartDate);
								if (reqDtCov.compareTo(rdsSDate) > 0) {
									String rdsEndDate = "";
									if (rdsHistoryVO.size() > 1) {
										rdsEndDate = rdsHistoryVO.get(1).getEndDate();
									}
									firstRowRdsHistoryVO.setEndDate(rdsEndDate);
									if (StringUtil.isNotNullNotEmptyNotWhiteSpace(firstRowRdsHistoryVO.getEndDate())) {
										rdsHistoryEndDate = DateFormatter.reFormat(firstRowRdsHistoryVO.getEndDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
									}
									if (StringUtil.isNotNullNotEmptyNotWhiteSpace(firstRowRdsHistoryVO.getEndDate())) {
										rdsEDate3 = DateMath.addOneDay(rdsHistoryEndDate);
									} else {
										rdsEDate3 = effStartDate;
									}
								} else {
									lepCalFlag = true;
								}
							} else {
								rdsEDate3 = effStartDate;
							}
						}
					} else {
						rdsEDate3 = effStartDate;
					}
				}
				if (StringUtil.isNotNullNotEmptyNotWhiteSpace(mbd.getSubsidyEndDate1())) {
					if (((effStartDate).equalsIgnoreCase(mbd.getSubsidyEndDate1())
							|| mbd.getSubsidyEndDate1().compareTo(reqDtCovinString) > 0) && copayLevelId1 > 0) {
						lepCalFlag = true;
					} else if (mbd.getSubsidyEndDate1().compareTo(reqDtCovinString) < 0 && copayLevelId1 > 0) {
						if (!(effStartDate).equalsIgnoreCase(mbd.getSubsidyEndDate1())) {
							lisEDate1 = DateMath.addOneDay(mbd.getSubsidyEndDate1());
						}
					} else {
						lisEDate1 = effStartDate;
					}
				}
				String sdob780m = DateMath.addMonth(mbd.getBirthDate(), 780);
				Date ddob780m = dateformat.parse(sdob780m);
				String sdob783m = DateMath.addMonth(mbd.getBirthDate(), 783);
				Date ddob783m = dateformat.parse(sdob783m);
				String sdob777m = DateMath.addMonth(mbd.getBirthDate(), 777);
				Date ddob777m = dateformat.parse(sdob777m);

				if (reqDtCov.compareTo(ddob777m) >= 0 && reqDtCov.compareTo(ddob783m) <= 0) {
					lepCalFlag = true;
				} else {
					if (reqDtCov.compareTo(ddob780m) < 0) {
						birthDate4 = effStartDate;
					} else {
						String tempDate4 = DateMath.addMonth(mbd.getBirthDate(), 784);
						birthDate4 = DateMath.getFirstOfMonth(tempDate4);
					}
				}
				String sPrtDEligibleDate = mbd.getPrtDEligibleDate();
				Date dPrtDEligibleDat = dateformat.parse(mbd.getPrtDEligibleDate());
				if (reqDtCov.compareTo(dPrtDEligibleDat) >= 0) {
					partDEligibilityDate5 = DateMath.addMonth(sPrtDEligibleDate, 4);
				} else {
					partDEligibilityDate5 = effStartDate;
				}
				lepInceptionDate6 = "20060601";
				if (!lepCalFlag) {
					SortedSet<Date> dateSet = new TreeSet<>();
					if (StringUtil.isNotNullNotEmptyNotWhiteSpace(lisEDate1)) {
						dateSet.add(dateformat.parse(lisEDate1));
					}
					if (StringUtil.isNotNullNotEmptyNotWhiteSpace(partDCovDate2)) {
						dateSet.add(dateformat.parse(partDCovDate2));
					}
					if (StringUtil.isNotNullNotEmptyNotWhiteSpace(rdsEDate3)) {
						dateSet.add(dateformat.parse(rdsEDate3));
					}
					if (reqDtCov.compareTo(ddob780m) > 0) {
						if (StringUtil.isNotNullNotEmptyNotWhiteSpace(birthDate4)) {
							dateSet.add(dateformat.parse(birthDate4));
						}
					}
					if (isNotBlank(partDEligibilityDate5)) {
						dateSet.add(dateformat.parse(partDEligibilityDate5));
					}
					if (StringUtil.isNotNullNotEmptyNotWhiteSpace(lepInceptionDate6)) {
						dateSet.add(dateformat.parse(lepInceptionDate6));
					}
					Date maxDate = dateSet.last();
					Date reqDateOfCov = null;
					if (StringUtil.isNotNullNotEmptyNotWhiteSpace(reqDateCov)) {
						reqDateOfCov = dateformat
								.parse(DateMath.minusOneDay(dateformat.format(formatter.parse(reqDateCov))));
					}
					Calendar cal1 = Calendar.getInstance();
					Calendar cal2 = Calendar.getInstance();
					cal1.setTime(reqDateOfCov);
					cal2.setTime(maxDate);

					int days = DateMath.daysBetween(cal1.getTime(), cal2.getTime());
					String maxDateString = dateformat.format(maxDate);
					String firstDayOfMaxDate = DateMath.getFirstOfMonth(maxDateString);

					lepDO.setUncovMthStDt(firstDayOfMaxDate);
					double dMonths = (days / 30.4);
					Long round = Math.round(dMonths);
					int uncoverMnths = round.intValue();
					String firstDdayOfUnCovEndDt = DateMath.addMonth(firstDayOfMaxDate, uncoverMnths);
					String lastDayOfunCovEndDt = DateMath.minusOneDay(firstDdayOfUnCovEndDt);
					lepDO.setUncovMthEndDt(lastDayOfunCovEndDt);
					boolean isLEPRecordExist = false;
					isLEPRecordExist = applLepDAO.verifyLEPRecord(customerId, applId);
					if (uncoverMnths > 3) {
						lepDO.setPlepMonths(uncoverMnths);
						lepDO.setLastUpdtUserId(EEMConstants.WEBAPPL);
						lepDO.setCreateUserId(EEMConstants.WEBAPPL);
						lepDO.setPrimaryId(applId);
						lepDO.setCustomerId(customerId);
						String ts = DateUtil.getCurrentDatetimeStamp();
						lepDO.setLastUpdtTime(ts);
						lepDO.setCreateTime(ts);
						String lepEffDate = DateFormatter.reFormat(StringUtil.nonNullTrim(reqDateCov), DateFormatter.MM_DD_YYYY,
								DateFormatter.YYYYMMDD);
						lepDO.setLepEffDate(lepEffDate);
						if (isLEPRecordExist) {
							applLepDAO.overridePLepApplDetails(customerId, EEMConstants.WEBAPPL, applId, false);
						}
						applLepDAO.insertApplPtnlUnCovMnthsDetails(lepDO, false);
						int val = eemProfileSettings.getParmNumber(customerId, EEMConstants.TRIG_CODE_OBC1);
						Calendar calendar = new GregorianCalendar();
						calendar.set(Calendar.DATE, calendar.get(Calendar.DATE) + val);

						if (!isDenied(applStatus)) {
							String isExist = applLepDAO.checkOpenApplTrigger(customerId, applId,
									EEMConstants.TRIG_CODE_OBC1);
							if (!isExist.isEmpty()) {
								String strMonth = String.valueOf(calendar.get(Calendar.MONTH) + 1);
								if (strMonth.length() == 1) {
									strMonth = "0" + strMonth;
								}
								String strDate = String.valueOf(calendar.get(Calendar.DATE));
								if (strDate.length() == 1) {
									strDate = "0" + strDate;
								}

								String effDateFrmt = DateFormatter.reFormat(StringUtil.nonNullTrim(strMonth + strDate),
										DateFormatter.YYYY_MM_DD, DateFormatter.YYYYMMDD);

								EEMApplTriggerDO triggerDo = applHelper.prepareApplTriggerDO(applId,
										EEMConstants.TRIG_TYPE_FOLLOWUP_APPL, EEMConstants.TRIG_STATUS_OPEN,
										EEMConstants.TRIG_CODE_OBC1, effDateFrmt);

								Integer rslt1 = applicationDAO.insertApplTrigger(triggerDo);
								if (rslt1 != 1) {
									return false;
								}
							}
						}
						String prtdCnt = "";
						String rdsCnt = "";

						List<String> data = applLepDAO.getPrtdRdsCnt(mbrHicNbr, trimToEmpty(objVO.getApplVO().getEligibilitySrcTable()));
						if (null != data) {
							rdsCnt = data.get(0);
							prtdCnt = data.get(1);
						}
						String triggerFunType = null;
						String effDateFrmt = DateFormatter.reFormat(StringUtil.nonNullTrim(reqDateCov),
								DateFormatter.YYYY_MM_DD, DateFormatter.YYYYMMDD);
						EEMApplTriggerDO triggerDo = applHelper.prepareApplTriggerDO(applId,
								EEMConstants.TRIG_TYPE_MANUAL_LTR, EEMConstants.TRIG_STATUS_OPEN, "", effDateFrmt);

						if (Integer.parseInt(rdsCnt) > 1 || Integer.parseInt(prtdCnt) > 1) {
							triggerFunType = EEMConstants.EEM_LEP_APPL_LTR_FUN_TYPE_1;
						} else if (Integer.parseInt(rdsCnt) == 1) {
							if (effStartDate.equalsIgnoreCase(firstRowPartDhistoryVO.getEndDate())
									&& (effStartDate.equalsIgnoreCase(firstRowRdsHistoryVO.getEndDate()))) {
								triggerFunType = EEMConstants.EEM_LEP_APPL_LTR_FUN_TYPE_2;
							} else {
								triggerFunType = EEMConstants.EEM_LEP_APPL_LTR_FUN_TYPE_1;
							}
						} else {
							if (Integer.parseInt(rdsCnt) == 0 || Integer.parseInt(prtdCnt) == 0) {
								triggerFunType = EEMConstants.EEM_LEP_APPL_LTR_FUN_TYPE_1;
							}
						}
						if (null != triggerFunType) {
							createLepLetter(customerId, enrollPlanDesgn, triggerFunType, triggerDo);
						}
					} else {
						applLepDAO.overridePLepApplDetails(customerId, EEMConstants.WEBAPPL, applId, false);
						applLepDAO.closeOBCTimer(customerId, applId);
					}
				} else if (isHicNbrChanged || isReqDtCovChanged) {
					applLepDAO.overridePLepApplDetails(customerId, EEMConstants.WEBAPPL, applId, false);
					applLepDAO.closeOBCTimer(customerId, applId);
				}
			}
		}
		return true;
	}

	private void createLepLetter(String customerId, String enrollPlanDesgn, String funType,
			EEMApplTriggerDO triggerDo) {
		String trigCode = applicationDAO.getTriggerCode(customerId, enrollPlanDesgn, funType);
		if (!isEmpty(trigCode)) {
			triggerDo.setTriggerCode(trigCode);
			applLepDAO.createApplLEPLetter(triggerDo);
		}
	}

	private boolean isDenied(String applStatus) {
		return applStatus.equals(EEMConstants.APPL_STATUS_DENIEDELG)
				|| applStatus.equals(EEMConstants.APPL_STATUS_DENIEDETYP)
				|| applStatus.equals(EEMConstants.APPL_STATUS_DENIEDOTHR);
	}

	private boolean setAttestDetails(List<EEMApplAttestationVO> applAttestationList, String updateRecInd, int applId) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();

		int rslt = 0;
		int cnt = 0;
		if (updateRecInd.equals("N")) {
			if (applAttestationList != null) {
				for (int i = 0; i < applAttestationList.size(); i++) {
					EEMApplAttestationVO attesVO = applAttestationList.get(i);
					cnt += 1;
					rslt += applicationDAO.insertAttestationDetails(customerId, applId, "" + (i + 1),
							attesVO.getAttestInd(), attesVO.getAttestDate(), userId);
				}
				if (rslt != cnt)
					return false;
			}
		} else if (updateRecInd.equals("Y")) {
			List<EEMApplAttestationDO> lstExceptions = applicationDAO.getAttestationDetails(applId, customerId);
			int seqNo = lstExceptions.size();
			for (EEMApplAttestationVO attestVO : applAttestationList) {
				if ("U".equalsIgnoreCase(attestVO.getLogicalInd()) && checkException(attestVO, lstExceptions)) {
					cnt += 1;
					rslt += applicationDAO.updateAttestationDetails(customerId, applId, attestVO.getAttestInd(),
							attestVO.getAttestDate(), userId);
				} else if (attestVO.getLogicalInd().equals("D")) {
					cnt += 1;
					rslt += applicationDAO.deleteAttestationDetails(customerId, applId, attestVO.getAttestInd(),
							attestVO.getAttestDate(), userId);
				} else if (attestVO.getLogicalInd().equals("I")) {
					cnt += 1;
					rslt += applicationDAO.insertAttestationDetails(customerId, applId, "" + (++seqNo),
							attestVO.getAttestInd(), attestVO.getAttestDate(), userId);
				}
			}
			if (rslt != cnt)
				return false;
		}
		return true;
	}

	private boolean checkException(EEMApplAttestationVO value, List<EEMApplAttestationDO> lstExceptions) {

		boolean blnCheck = false;
		for (int i = 0; i < lstExceptions.size(); i++) {
			EEMApplAttestationDO attestVO = lstExceptions.get(i);
			if (value.getAttestInd().equals(attestVO.getAttestInd())) {
				blnCheck = true;
			}
		}
		return blnCheck;
	}

	private boolean setMasterDetails(EEMApplMasterVO eemApplMasterVO) throws ParseException {

		List<EEMApplErrorVO> lstErrors = eemApplMasterVO.getApplErrList();

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();
		String ts = DateUtil.getCurrentDatetimeStamp();

		int rslt = 0;
		if (trimToEmpty(eemApplMasterVO.getApplVO().getOutOfArea()).equals("")) {
			eemApplMasterVO.getApplVO().setOutOfArea("N");
		}
		String beqCheck = eemProfileSettings.getCalendarProfileInd(customerId, EEMProfileConstants.BEQCHECK);

		String subsInd = eemProfileSettings.getCalendarProfileInd(customerId, EEMProfileConstants.SUPPEND);
		String applStatus = "";
		if (eemApplMasterVO.getApplVO().getApplStatus().equals(EEMConstants.APPL_STATUS_READY)
				|| eemApplMasterVO.getApplVO().getApplStatus().equals(EEMConstants.APPL_STATUS_READYAPPR)) {
			if (trimToEmpty(eemApplMasterVO.getApplVO().getEligibilitySrcTable()).equals(EEMConstants.EM_TABLE_BEQ)) {
				if (subsInd.equals("Y") && (trimToEmpty(eemApplMasterVO.getApplVO().getAltMbrId()).equals(""))) {
					applStatus = validatePartABDDates(eemApplMasterVO.getApplEligiVO(), eemApplMasterVO.getMbd(),
							beqCheck);
					eemApplMasterVO.getApplVO().setApplStatus(applStatus);
				} else {
					eemApplMasterVO.getApplVO().setApplStatus(EEMConstants.APPL_STATUS_BEQAPPR);
				}
			} else {
				if (subsInd.equals("Y") && (trimToEmpty(eemApplMasterVO.getApplVO().getAltMbrId()).equals(""))) {
					applStatus = validatePartABDDates(eemApplMasterVO.getApplEligiVO(), eemApplMasterVO.getMbd(),
							beqCheck);
					eemApplMasterVO.getApplVO().setApplStatus(applStatus);
				} else {
					eemApplMasterVO.getApplVO().setApplStatus(EEMConstants.APPL_STATUS_READYAPPR);
				}
			}
		} else if (eemApplMasterVO.getApplVO().getApplStatus().equals(EEMConstants.APPL_STATUS_BEQAPPR) && StringUtil
				.nonNullTrim(eemApplMasterVO.getApplVO().getEligibilitySrcTable()).equals(EEMConstants.EM_TABLE_MBD)) {
			if (subsInd.equals("Y") && trimToEmpty(eemApplMasterVO.getApplVO().getAltMbrId()).equals("")) {
				applStatus = validatePartABDDates(eemApplMasterVO.getApplEligiVO(), eemApplMasterVO.getMbd(), beqCheck);
				eemApplMasterVO.getApplVO().setApplStatus(applStatus);
			} else {
				eemApplMasterVO.getApplVO().setApplStatus(EEMConstants.APPL_STATUS_READYAPPR);
			}
		} else if ((eemApplMasterVO.getApplVO().getApplStatus().equals(EEMConstants.APPL_STATUS_FORCEDAPPR)
				|| eemApplMasterVO.getApplVO().getApplStatus().equals(EEMConstants.APPL_STATUS_ELGWARNING))
				&& subsInd.equals("Y") && trimToEmpty(eemApplMasterVO.getApplVO().getAltMbrId()).equals("")) {
			applStatus = validatePartABDDates(eemApplMasterVO.getApplEligiVO(), eemApplMasterVO.getMbd(), beqCheck);
			eemApplMasterVO.getApplVO().setApplStatus(applStatus);
		} else if (eemApplMasterVO.getApplVO().getCurrStatus().equals(EEMConstants.APPL_STATUS_SUPPEND)
				&& eemApplMasterVO.getApplVO().getApplStatus().equals(EEMConstants.APPL_STATUS_READY)
				&& (subsInd.equals("N") || !(trimToEmpty(eemApplMasterVO.getApplVO().getAltMbrId()).equals("")))) {
			EEMApplErrorVO errorVO = null;

			for (int i = 0; i < lstErrors.size(); i++) {
				errorVO = lstErrors.get(i);
				String errorCode = errorVO.getErrorCd();
				if (errorCode.equalsIgnoreCase("AP337") || errorCode.equalsIgnoreCase("AP338")) {
					eemApplMasterVO.getApplVO().setApplStatus(EEMConstants.APPL_STATUS_ELGWARNING);
				} else {
					eemApplMasterVO.getApplVO().setApplStatus(EEMConstants.APPL_STATUS_READYAPPR);
				}
			}
		}
		boolean checForExistingEnrollment = false;
		if (checForExistingEnrollment) {
			eemApplMasterVO.getApplVO().setApplStatus(EEMConstants.APPL_STATUS_DUPLENRL);
		}
		if ("Y".equals(beqCheck)) {
			if (null == lstErrors || lstErrors.isEmpty()) {
				if (EEMConstants.APPL_STATUS_BEQPENDING.equals(eemApplMasterVO.getApplVO().getCurrStatus())
						|| EEMConstants.APPL_STATUS_SUPPEND.equals(eemApplMasterVO.getApplVO().getCurrStatus())) {
					if (subsInd != null && subsInd.equalsIgnoreCase(EEMConstants.VALUE_YES)) {
						if (trimToEmpty(eemApplMasterVO.getApplVO().getAltMbrId())
								.equalsIgnoreCase(EEMConstants.BLANK)) {
							if (EEMConstants.EM_TABLE_BEQ
									.equals(eemApplMasterVO.getApplVO().getEligibilitySrcTable())) {
								applStatus = validatePartABDDates(eemApplMasterVO.getApplEligiVO(),
										eemApplMasterVO.getMbd(), beqCheck);
								eemApplMasterVO.getApplVO().setApplStatus(applStatus);
							} else if (EEMConstants.EM_TABLE_MBD
									.equals(eemApplMasterVO.getApplVO().getEligibilitySrcTable())) {
								applStatus = validatePartABDDates(eemApplMasterVO.getApplEligiVO(),
										eemApplMasterVO.getMbd(), beqCheck);
								eemApplMasterVO.getApplVO().setApplStatus(applStatus);
							} else {
								eemApplMasterVO.getApplVO().setApplStatus(EEMConstants.APPL_STATUS_BEQPENDING);
							}
						} else {
							if (EEMConstants.EM_TABLE_BEQ.equals(eemApplMasterVO.getApplVO().getEligibilitySrcTable()))
								eemApplMasterVO.getApplVO().setApplStatus(EEMConstants.APPL_STATUS_BEQAPPR);
							else if (EEMConstants.EM_TABLE_MBD
									.equals(eemApplMasterVO.getApplVO().getEligibilitySrcTable()))
								eemApplMasterVO.getApplVO().setApplStatus(EEMConstants.APPL_STATUS_READYAPPR);
							else {
								eemApplMasterVO.getApplVO().setApplStatus(EEMConstants.APPL_STATUS_BEQPENDING);
							}
						}
					} else {
						if (EEMConstants.EM_TABLE_BEQ.equals(eemApplMasterVO.getApplVO().getEligibilitySrcTable()))
							eemApplMasterVO.getApplVO().setApplStatus(EEMConstants.APPL_STATUS_BEQAPPR);
						else if (EEMConstants.EM_TABLE_MBD.equals(eemApplMasterVO.getApplVO().getEligibilitySrcTable()))
							eemApplMasterVO.getApplVO().setApplStatus(EEMConstants.APPL_STATUS_READYAPPR);
						else {
							eemApplMasterVO.getApplVO().setApplStatus(EEMConstants.APPL_STATUS_BEQPENDING);
						}
					}
				}
			}
		}
		if (eemApplMasterVO.getApplPlanVO().getElectionType().equals("W")) {
			EEMApplPlanDO eemApplPlanDO = new EEMApplPlanDO();
			BeanUtils.copyProperties(eemApplMasterVO.getApplPlanVO(), eemApplPlanDO);

			EEMApplProdSearchDO prodSerachDO = new EEMApplProdSearchDO();
			setProdSerachValue(eemApplMasterVO, prodSerachDO);

			EEMApplProductDO prodDO = null;
			String eghpId = "";
			String applDate;
			List<EEMApplProductDO> lstProd = applicationDAO.getProducts(prodSerachDO, eemApplPlanDO);
			if (lstProd != null && !lstProd.isEmpty()) {
				prodDO = lstProd.get(0);
				eghpId = prodDO.getEghpInd();
				if (!trimToEmpty(eghpId).equals("") && trimToEmpty(eghpId).equals("Y")) {
					applDate = DateUtil.formatMmDdYyyy(DateMath.getFirstOfLastMonth(DateUtil
							.changedDateFormatForMonth(trimToEmpty(eemApplMasterVO.getApplPlanVO().getReqDtCov()))));
					eemApplMasterVO.getApplVO().setApplDate(applDate);
				}
			}
		}
		if (!"Y".equalsIgnoreCase(eemApplMasterVO.getApplVO().getHealthPlanNews())) {
			eemApplMasterVO.getApplVO().setHealthPlanNews("N");
		}
		eemApplMasterVO.getApplVO().setLstUpdtUserId(userId);
		if (eemApplMasterVO.getApplVO().getUpdateRec().equals("N")) {
			synchronized (this) {
				eemApplMasterVO.getApplVO().setApplId(eemDao.getNextSeqNo(customerId, EEMConstants.NEXT_APP_ID));
			}
			checkApplicationNbr(eemApplMasterVO.getApplVO(), customerId);
			setSupplId(eemApplMasterVO.getApplVO(), eemApplMasterVO.getApplPlanVO(), customerId);
			eemApplMasterVO.getApplVO().setLstUpdtTime(ts);
			eemApplMasterVO.getApplVO().setCreateTime(ts);
			eemApplMasterVO.getApplVO().setCreateUserId(userId);
			EEMApplicationDO applDo = new EEMApplicationDO();
			BeanUtils.copyProperties(eemApplMasterVO.getApplVO(), applDo);

			rslt = applicationDAO.insertMasterDetails(applDo);
		} else if (eemApplMasterVO.getApplVO().getUpdateRec().equals("Y")) {
			checkApplicationNbr(eemApplMasterVO.getApplVO(), customerId);
			setSupplId(eemApplMasterVO.getApplVO(), eemApplMasterVO.getApplPlanVO(), customerId);
			EEMApplicationDO applDo = new EEMApplicationDO();
			BeanUtils.copyProperties(eemApplMasterVO.getApplVO(), applDo);
			rslt = applicationDAO.updateMasterDetails(applDo);
			if (rslt == 1) {
				eemApplMasterVO.getApplVO().setLstUpdtTime(applDo.getLstUpdtTime());
			}
		}
		if (rslt == 1) {
			if (isDenied(eemApplMasterVO.getApplVO().getApplStatus())) {
				String planDesig = eemApplMasterVO.getGrpProdVO().getPlanDesignation();
				Boolean trigResult = insertApplDeniedTrigger(eemApplMasterVO.getApplVO(), userId,
						eemApplMasterVO.getApplPlanVO().getReqDtCov(), planDesig);
				if (!trigResult) {
					return false;
				}
			}
			eemApplMasterVO.getApplVO().setCurrStatus(eemApplMasterVO.getApplVO().getApplStatus());
			return true;
		}
		return false;
	}

	private String validatePartABDDates(EEMApplEligibilityVO applEligiVO, MBD mbd, String beqCheck) {
		String partAEffDt = trimToEmpty(applEligiVO.getPartAEffDate());
		String partBEffDt = trimToEmpty(applEligiVO.getPartBEffDate());
		String partDEffDt = trimToEmpty(applEligiVO.getPartDEffDate());

		String prtAMbd = trimToEmpty(DateUtil.formatMmDdYyyy(mbd.getPrtAEntitleDate()));
		String prtBMbd = trimToEmpty(DateUtil.formatMmDdYyyy(mbd.getPrtBEntitleDate()));
		String prtDMbd = trimToEmpty(DateUtil.formatMmDdYyyy(mbd.getPrtDEligibleDate()));

		if (!(partAEffDt.equalsIgnoreCase(prtAMbd) && partBEffDt.equalsIgnoreCase(prtBMbd)
				&& partDEffDt.equalsIgnoreCase(prtDMbd))) {
			partAEffDt = checkNullZeroDateField(partAEffDt, prtAMbd);
			partBEffDt = checkNullZeroDateField(partBEffDt, prtBMbd);
			partDEffDt = checkNullZeroDateField(partDEffDt, prtDMbd);
		}

		if ("Y".equalsIgnoreCase(beqCheck)
				&& (partAEffDt.equals(partEffDate) || partBEffDt.equals(partEffDate) || partDEffDt.equals(partEffDate)))
			return EEMConstants.APPL_STATUS_BEQPENDING;
		else
			return EEMConstants.APPL_STATUS_SUPPEND;

	}

	private String checkNullZeroDateField(String partEffDt, String prtMbd) {
		if (partEffDt.equals(effStartDate) || partEffDt.equals(partEffDate)) {
			return prtMbd;
		}
		return partEffDt;
	}

	private void setProdSerachValue(EEMApplMasterVO eemApplMasterVO, EEMApplProdSearchDO prodSearchDO) {

		prodSearchDO.setCustomerId(trimToEmpty(eemApplMasterVO.getApplVO().getCustomerId()));
		prodSearchDO.setApplType(trimToEmpty(eemApplMasterVO.getApplVO().getApplType()));
		prodSearchDO.setSsaSt(trimToEmpty(eemApplMasterVO.getApplAddress().getPerState()));
		prodSearchDO.setSsaCnty(trimToEmpty(eemApplMasterVO.getApplAddress().getPerCounty()));
		prodSearchDO.setZip4(trimToEmpty(eemApplMasterVO.getApplAddress().getPerZip4()));
		prodSearchDO.setZip5(trimToEmpty(eemApplMasterVO.getApplAddress().getPerZip5()));
		prodSearchDO.setEnrollProdName(trimToEmpty(eemApplMasterVO.getGrpProdVO().getEnrollProdName()));
		prodSearchDO.setEnrollGroupName(trimToEmpty(eemApplMasterVO.getGrpProdVO().getEnrollGroupName()));
	}

	private boolean insertApplDeniedTrigger(EEMApplicationVO objVO, String userId, String reqDtCov, String planDesig) {
		int trigger = 0;
		if (!(objVO.getCurrStatus().equals(EEMConstants.APPL_STATUS_COMPLETED)
				|| objVO.getCurrStatus().equals(EEMConstants.APPL_STATUS_APPROVED))) {
			if (isDenied(objVO.getApplStatus())) {
				String effectiveDate = DateFormatter.reFormat(reqDtCov, DateFormatter.MM_DD_YYYY,
						DateFormatter.YYYYMMDD);
				String trigCode = applicationDAO.getTriggerCode(objVO.getCustomerId(), planDesig,
						EEMConstants.EEM_APPL_DENIAL_TRIG_FUN_TYPE);
				if (StringUtils.isNotBlank(trigCode)) {

					EEMApplTriggerDO triggerDo = applHelper.prepareApplTriggerDO(String.valueOf(objVO.getApplId()),
							EEMConstants.TRIG_TYPE_MANUAL_LTR, EEMConstants.TRIG_STATUS_OPEN, trigCode, effectiveDate);

					applicationDAO.updateApplTrigger(triggerDo);
					trigger = applicationDAO.insertApplTrigger(triggerDo);
					if (trigger == 0) {
						return false;
					}
				}

			}
		}
		return true;
	}

	public void checkApplicationNbr(EEMApplicationVO objVO, String customerId) {

		String applNbrInd = eemProfileSettings.getCalendarProfileInd(customerId, EEMProfileConstants.APPNBR);
		if ((objVO.getMbrApplNo() == null || objVO.getMbrApplNo().trim().isEmpty()) && applNbrInd != null
				&& applNbrInd.equals(EEMProfileConstants.APPNBR_DERIVED)) {
			int applNbr = objVO.getApplId();
			if (applNbr > 0) {
				EEMProfileItemDO item = eemProfileSettings.getProfileObject(customerId, EEMProfileConstants.APPNBRFRMT);
				String format = item.getParmTextValue();
				NumberFormat nf = new DecimalFormat(format);
				double dApplNbr = Double.valueOf(applNbr).doubleValue();
				objVO.setMbrApplNo(nf.format(dApplNbr));
			}
		}
	}

	public void setSupplId(EEMApplicationVO objVO, EEMApplPlanVO applPlanVO, String customerId) {

		try {
			String supplInd = eemProfileSettings.getCalendarProfileInd(customerId, EEMProfileConstants.SUPPLID);
			String rxIdInd = eemProfileSettings.getCalendarProfileInd(customerId, EEMProfileConstants.RXID);
			if (supplInd != null) {
				if (supplInd.equals(EEMProfileConstants.SUPPLID_DERIVED)) {
					if (objVO.getApplType().equals(EEMConstants.OPTION_APPLNEWMBR_MA)
							|| objVO.getApplType().equals(EEMConstants.OPTION_APPLNEWMBR_PD)) {
						objVO.setAltMbrId(objVO.getMbrId());
					}
				} else if (supplInd.equals(EEMProfileConstants.SUPPLID_GENERATED)) {
					if (objVO.getApplType().equals(EEMConstants.OPTION_APPLNEWMBR_MA)
							|| objVO.getApplType().equals(EEMConstants.OPTION_APPLNEWMBR_PD)) {
						if (trimToEmpty(objVO.getUpdateRec()).equals("N")) {
							if (rxIdInd.equals(EEMProfileConstants.RXID_USE_SUPPLID)) {
								objVO.setAltMbrId(objVO.getMbrRxId());
							} else {
								objVO.setAltMbrId("");
							}
						}
					} else if (objVO.getApplType().equals(EEMConstants.OPTION_CNTRCHG_MA)
							|| objVO.getApplType().equals(EEMConstants.OPTION_CNTRCHG_PD)) {
						if (!trimToEmpty(applPlanVO.getCurrProductId())
								.equals(trimToEmpty(applPlanVO.getEnrollProduct()))
								|| !trimToEmpty(applPlanVO.getCurrPbpId())
										.equals(trimToEmpty(applPlanVO.getEnrollPbp()))
								|| !trimToEmpty(applPlanVO.getCurrPbpSegmentId())
										.equals(trimToEmpty(applPlanVO.getEnrollSegment()))
										&& trimToEmpty(objVO.getAltMbrId()).equals("")) {
							if (rxIdInd.equals(EEMProfileConstants.RXID_USE_SUPPLID)) {
								objVO.setAltMbrId(objVO.getMbrRxId());
							} else {
								objVO.setAltMbrId("");
							}
						}
					}
				}
			}

		} catch (Exception e) {
			objVO.setMessage("Error during Supplemental Id check.");
			throw new ApplicationException(e);
		}
	}

	private boolean setAddressDetails(EEMApplAddressVO objVO, String updateRecInd, int applId) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();

		EEMApplAddressDO addrDO = new EEMApplAddressDO();
		addrDO.setApplId(applId);
		addrDO.setCustomerId(customerId);

		String zip5 = "";
		String zip4 = "";
		boolean result = true;
		boolean empty = false;
		if (trimToEmpty(objVO.getPerAdd1()).equals("") && trimToEmpty(objVO.getPerAdd2()).equals("")
				&& trimToEmpty(objVO.getPerAdd3()).equals("") && trimToEmpty(objVO.getPerCity()).equals("")
				&& trimToEmpty(objVO.getPerState()).equals("") && trimToEmpty(objVO.getPerZip5()).equals("")
				&& trimToEmpty(objVO.getPerZip4()).equals("") && trimToEmpty(objVO.getPerCounty()).equals("")
				&& trimToEmpty(objVO.getPerPhone()).equals("") && trimToEmpty(objVO.getPerCell()).equals("")
				&& trimToEmpty(objVO.getPerWorkPhone()).equals("") && trimToEmpty(objVO.getPerFax()).equals("")) {
			empty = true;
		}
		if (!empty) {
			addrDO.setAddressType(EEMConstants.EEM_ADDRTYPE_PRIMARY);
			addrDO.setAddress1(objVO.getPerAdd1());
			addrDO.setAddress2(objVO.getPerAdd2());
			addrDO.setAddress3(objVO.getPerAdd3());
			addrDO.setCity(objVO.getPerCity());
			addrDO.setStateCd(eemCodeCache.getDesc(objVO.getPerState(), eemPersistence.getLstStates()));
			if (!trimToEmpty(objVO.getPerZip5()).equals("")) {
				zip5 = trimToEmpty(objVO.getPerZip5());
			}
			if (!trimToEmpty(objVO.getPerZip4()).equals("")) {
				zip4 = trimToEmpty(objVO.getPerZip4());
			}
			addrDO.setZipCd(zip5 + zip4);
			if (trimToEmpty(objVO.getPerCounty()).equals("")) {
				if (!trimToEmpty(addrDO.getZipCd()).equals("")) {
					objVO.setPerCounty(applicationDAO.getCounty(zip5, zip4));
				}
				List<LabelValuePair> lstCounty = eemPersistence.getMapCounty().get(objVO.getPerState());
				if (lstCounty != null) {
					addrDO.setCountyCd(eemCodeCache.getCountyCode(trimToEmpty(objVO.getPerCounty()), lstCounty));
					objVO.setPerCounty(addrDO.getCountyCd());
				}
			} else {
				addrDO.setCountyCd(objVO.getPerCounty());
			}
			addrDO.setCountryCd("USA");
			addrDO.setHomePhoneNbr(objVO.getPerPhone());
			addrDO.setCellPhoneNbr(objVO.getPerCell());
			addrDO.setWorkPhoneNbr(objVO.getPerWorkPhone());
			addrDO.setFaxNbr(objVO.getPerFax());
			addrDO.setCreateUserId(userId);
			addrDO.setLastUpdtUserId(userId);
			if (updateRecInd.equals("N") || trimToEmpty(objVO.getLstUpdtPrimAddr()).equals("")) {
				if (applicationDAO.insertAddressDetails(addrDO) == 0) {
					result = false;
				}
				objVO.setLstUpdtPrimAddr(addrDO.getLastUpdtTime());
			} else if (updateRecInd.equals("Y")) {
				addrDO.setLastUpdtTime(objVO.getLstUpdtPrimAddr());
				if (applicationDAO.updateAddressDetails(addrDO) == 0) {
					result = false;
				} else {
					objVO.setLstUpdtPrimAddr(addrDO.getLastUpdtTime());
				}
			}
		} else if (empty && !trimToEmpty(objVO.getLstUpdtPrimAddr()).equals("")) {
			addrDO.setCustomerId(objVO.getCustomerId());
			addrDO.setApplId(objVO.getApplId());
			addrDO.setAddressType(EEMConstants.EEM_ADDRTYPE_PRIMARY);
			addrDO.setLastUpdtTime(objVO.getLstUpdtPrimAddr());

			if (applicationDAO.deleteAddressDetails(addrDO) == 0) {
				result = false;
			} else {
				objVO.setLstUpdtPrimAddr(null);
			}
		}
		empty = false;
		zip5 = "";
		zip4 = "";
		if (trimToEmpty(objVO.getMailAdd1()).equals("") && trimToEmpty(objVO.getMailAdd2()).equals("")
				&& trimToEmpty(objVO.getMailAdd3()).equals("") && trimToEmpty(objVO.getMailCity()).equals("")
				&& trimToEmpty(objVO.getMailState()).equals("") && trimToEmpty(objVO.getMailZip5()).equals("")
				&& trimToEmpty(objVO.getMailCountry()).equals("")) {
			if (!trimToEmpty(objVO.getMailZip4()).equals("")) {
				objVO.setMailZip4("");
			}
			empty = true;
		}
		if (!empty) {
			addrDO.setAddressType(EEMConstants.EEM_ADDRTYPE_MAIL);
			addrDO.setAddress1(objVO.getMailAdd1());
			addrDO.setAddress2(objVO.getMailAdd2());
			addrDO.setAddress3(objVO.getMailAdd3());
			addrDO.setCity(objVO.getMailCity());
			addrDO.setStateCd(eemCodeCache.getDesc(objVO.getMailState(), eemPersistence.getLstStates()));
			if (!trimToEmpty(objVO.getMailZip5()).equals("")) {
				zip5 = trimToEmpty(objVO.getMailZip5());
			}
			if (!trimToEmpty(objVO.getMailZip4()).equals("")) {
				zip4 = trimToEmpty(objVO.getMailZip4());
			}
			addrDO.setZipCd(zip5 + zip4);
			addrDO.setCountryCd(objVO.getMailCountry());
			addrDO.setHomePhoneNbr("");
			addrDO.setCellPhoneNbr("");
			addrDO.setWorkPhoneNbr("");
			addrDO.setFaxNbr("");
			addrDO.setCountyCd("");
			if (updateRecInd.equals("N") || trimToEmpty(objVO.getLstUpdtMailAddr()).equals("")) {
				if (applicationDAO.insertAddressDetails(addrDO) == 0)
					result = false;
				objVO.setLstUpdtMailAddr(addrDO.getLastUpdtTime());
			} else if (updateRecInd.equals("Y")) {
				addrDO.setLastUpdtTime(objVO.getLstUpdtMailAddr());
				if (applicationDAO.updateAddressDetails(addrDO) == 0) {
					result = false;
				} else {
					objVO.setLstUpdtMailAddr(addrDO.getLastUpdtTime());
				}
			}
		} else if (empty && !trimToEmpty(objVO.getLstUpdtMailAddr()).equals("")) {
			addrDO.setCustomerId(customerId);
			addrDO.setApplId(applId);
			addrDO.setAddressType(EEMConstants.EEM_ADDRTYPE_MAIL);
			addrDO.setLastUpdtTime(objVO.getLstUpdtMailAddr());
			if (applicationDAO.deleteAddressDetails(addrDO) == 0) {
				result = false;
			} else {
				objVO.setLstUpdtMailAddr(null);
			}
		}
		empty = false;
		zip5 = "";
		zip4 = "";
		if (trimToEmpty(objVO.getAuthRepStreet()).equals("") && trimToEmpty(objVO.getAuthRepCity()).equals("")
				&& trimToEmpty(objVO.getAuthRepState()).equals("") && trimToEmpty(objVO.getAuthRepPhone()).equals("")) {
			empty = true;
		}
		if (!empty) {
			addrDO.setAddressType(EEMConstants.EEM_ADDRTYPE_AUTH);
			addrDO.setAddress1(objVO.getAuthRepStreet());
			addrDO.setAddress2("");
			addrDO.setAddress3("");
			addrDO.setCity(objVO.getAuthRepCity());
			addrDO.setStateCd(eemCodeCache.getDesc(objVO.getAuthRepState(), eemPersistence.getLstStates()));
			if (!trimToEmpty(objVO.getAuthRepZip5()).equals("")) {
				zip5 = trimToEmpty(objVO.getAuthRepZip5());
			}
			if (!trimToEmpty(objVO.getAuthRepZip4()).equals("")) {
				zip4 = trimToEmpty(objVO.getAuthRepZip4());
			}
			addrDO.setZipCd(zip5 + zip4);
			addrDO.setCountryCd("USA");
			addrDO.setHomePhoneNbr("");
			addrDO.setCellPhoneNbr("");
			addrDO.setWorkPhoneNbr(objVO.getAuthRepPhone());
			addrDO.setFaxNbr("");
			addrDO.setCountyCd("");
			if (updateRecInd.equals("N") || trimToEmpty(objVO.getLstUpdtAuthAddr()).equals("")) {
				if (applicationDAO.insertAddressDetails(addrDO) == 0)
					result = false;
				objVO.setLstUpdtAuthAddr(addrDO.getLastUpdtTime());
			} else if (updateRecInd.equals("Y")) {
				addrDO.setLastUpdtTime(objVO.getLstUpdtAuthAddr());
				if (applicationDAO.updateAddressDetails(addrDO) == 0) {
					result = false;
				} else {
					objVO.setLstUpdtAuthAddr(addrDO.getLastUpdtTime());
				}
			}
		} else if (empty && !trimToEmpty(objVO.getLstUpdtAuthAddr()).equals("")) {
			addrDO.setCustomerId(objVO.getCustomerId());
			addrDO.setApplId(objVO.getApplId());
			addrDO.setAddressType(EEMConstants.EEM_ADDRTYPE_AUTH);
			addrDO.setLastUpdtTime(objVO.getLstUpdtAuthAddr());

			if (applicationDAO.deleteAddressDetails(addrDO) == 0) {
				result = false;
			} else {
				objVO.setLstUpdtAuthAddr(null);
			}
		}
		return result;
	}

	private boolean setLisDetails(EEMApplLisVO applLisVO, String updateRecInd, int applId, boolean isLisChanged) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();

		EEMApplLisDO applLisDO = new EEMApplLisDO();
		BeanUtils.copyProperties(applLisVO, applLisDO);

		int rslt = 0;
		if (updateRecInd.equals("N")) {
			if (!(trimToEmpty(applLisVO.getEffStartDt()).equals(""))) {
				rslt = applicationDAO.insertLisDetails(applLisDO, customerId, applId, userId);
			} else {
				rslt = 1;
			}
		} else if (updateRecInd.equals("Y")) {
			if (applicationDAO.checkLISStatus(applLisDO, customerId, applId) || isLisChanged) {
				applicationDAO.updateLisDetails(applLisDO, customerId, applId, userId);
				if (!(trimToEmpty(applLisDO.getEffStartDt()).equals(""))) {
					rslt = applicationDAO.insertLisDetails(applLisDO, customerId, applId, userId);
				} else {
					rslt = 1;
				}
			} else {
				rslt = 1;
			}
		}
		if (rslt == 1) {
			return true;
		}
		return false;
	}

	private boolean setErrorDetails(List<EEMApplErrorVO> lstErrors, int applId, String applDate, String applStatus) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();

		List<EEMApplErrorDO> lstTemp = applicationDAO.getErrorDetails(applId, customerId);

		List<EEMApplErrorDO> lstErrorsDO = new ArrayList<>();

		if (StringUtils.isNotBlank(applStatus) && isDenied(applStatus) && !CollectionUtils.isEmpty(lstTemp)) {
			int rslt = closeApplErrors(applDate, userId, lstTemp);
			return rslt > 0;
		}

		lstErrors.forEach(errorVO -> {
			EEMApplErrorDO errorDO = new EEMApplErrorDO();
			BeanUtils.copyProperties(errorVO, errorDO);
			lstErrorsDO.add(errorDO);
		});
		if (lstErrors != null && !lstErrors.isEmpty()) {
			EEMApplErrorDO objError = null;
			int rslt = 0;
			for (int i = 0; i < lstErrorsDO.size(); i++) {
				objError = lstErrorsDO.get(i);
				objError.setApplicationId(applId);
				objError.setApplDate(applDate);
				objError.setErrorStatus(EEMConstants.ERROR_STATUS_OPEN);
				rslt = applicationDAO.updateErrorDetails(objError, userId);
				if (rslt == 0) {
					applicationDAO.insertErrorDetails(objError, userId);
					rslt = 1;
				}
			}
			for (int i = 0; i < lstTemp.size(); i++) {
				EEMApplErrorDO objTemp = lstTemp.get(i);
				boolean found = false;

				for (int j = 0; j < lstErrorsDO.size(); j++) {
					objError = lstErrorsDO.get(j);
					if (trimToEmpty(objTemp.getErrorCd()).equals(trimToEmpty(objError.getErrorCd()))
							&& trimToEmpty(objTemp.getFieldNbr()).equals(trimToEmpty(objError.getFieldNbr()))
							&& trimToEmpty(objTemp.getErrorData()).equals(trimToEmpty(objError.getErrorData()))) {
						found = true;
						break;
					}
				}
				if (!found) {
					objTemp.setApplDate(applDate);
					objTemp.setErrorStatus(EEMConstants.ERROR_STATUS_CLOSED);
					rslt += applicationDAO.updateErrorDetails(objTemp, userId);
				}
			}
			if (rslt == 0) {
				return false;
			}
		} else if (!lstTemp.isEmpty()) {
			int rslt = 0;
			rslt = closeApplErrors(applDate, userId, lstTemp);
			if (rslt == 0) {
				return false;
			}
		}
		return true;
	}

	private int closeApplErrors(String applDate, String userId, List<EEMApplErrorDO> lstTemp) {
		int rslt = 0;
		for (int i = 0; i < lstTemp.size(); i++) {
			EEMApplErrorDO objTemp = lstTemp.get(i);
			objTemp.setErrorStatus(EEMConstants.ERROR_STATUS_CLOSED);
			objTemp.setApplDate(applDate);
			rslt += applicationDAO.updateErrorDetails(objTemp, userId);
		}
		return rslt;
	}

	private boolean setBEQDetails(EEMApplMasterVO applMasterVO) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();
		String planId = applMasterVO.getApplPlanVO().getEnrollPlan();

		EEMApplicationDO applDO = new EEMApplicationDO();
		BeanUtils.copyProperties(applMasterVO.getApplVO(), applDO);

		if (applDO.getApplStatus().equals(EEMConstants.APPL_STATUS_BEQPENDING)) {
			EEMBeqDO beq = applicationDAO.getBEQDetailsFor(customerId, applDO.getApplId(), applDO.getMbrHicNbr(),
					applDO.getMbrBirthDt());
			if (beq == null)
				applicationDAO.insertBEQDetails(applDO, planId, userId);
		}
		return true;
	}

	private boolean setEligDetails(EEMApplEligibilityVO eligVO, EEMApplicationVO applVO, MBD mbd) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();

		EEMApplEligibilityDO eligDO = new EEMApplEligibilityDO();
		EEMApplicationDO applDO = new EEMApplicationDO();

		BeanUtils.copyProperties(eligVO, eligDO);
		BeanUtils.copyProperties(applVO, applDO);

		if (mbd == null || mbd.getHicNbr() == null) {
			applicationDAO.insertEligDetailsNotInMBD(eligDO, applDO, userId);
			applVO.setNeedMBDUpdate("N");
		} else if (mbd.getHicNbr() != null && !mbd.getHicNbr().equals("")) {
			if ("Y".equals(applVO.getNeedMBDUpdate()))
				applicationDAO.insertEligDetails(eligDO, mbd, customerId, applVO.getApplId(), userId);
			applVO.setNeedMBDUpdate("N");
		}
		return true;
	}

	private boolean setAgentDetails(EEMApplAgentVO agentVO, String updateRecInd, int applId) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();

		int rslt = 0;
		EEMApplAgentDO agentDO = new EEMApplAgentDO();
		BeanUtils.copyProperties(agentVO, agentDO);

		boolean applAgentFlag = applicationDAO.checkApplAgent(customerId, applId, agentVO.getLastUpdtTime());
		if (updateRecInd.equals("N") || !applAgentFlag) {
			if (trimToEmpty(agentVO.getBrokAgentId()).equals("")) {
				return true;
			} else {
				rslt = applicationDAO.insertAgentDetails(agentDO, customerId, applId, userId);
			}
		} else if (updateRecInd.equals("Y")) {
			if (trimToEmpty(agentVO.getBrokAgentId()).equals("") && true == applAgentFlag) {
				rslt = applicationDAO.deleteApplAgentDetails(customerId, applId);
			} else {
				rslt = applicationDAO.updateAgentDetails(agentDO, customerId, applId, userId);
			}
		}
		if (rslt == 1) {
			BeanUtils.copyProperties(agentDO, agentVO);
			return true;
		}
		return false;
	}

	private boolean setOtherCovDetails(EEMApplOtherCovVO applOtherCovVO, String updateRecInd, int applId) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();

		EEMApplOtherCovDO applOtherCovDO = new EEMApplOtherCovDO();
		BeanUtils.copyProperties(applOtherCovVO, applOtherCovDO);

		int rslt = 0;
		if (updateRecInd.equals("N") || trimToEmpty(applOtherCovVO.getLastUpdtTime()).equals("")) {
			rslt = applicationDAO.insertOtherCovDetails(applOtherCovDO, customerId, applId, userId);
		} else if (updateRecInd.equals("Y")) {
			rslt = applicationDAO.updateOtherCovDetails(applOtherCovDO, customerId, applId, userId);
		}
		if (rslt == 1) {
			BeanUtils.copyProperties(applOtherCovDO, applOtherCovVO);
			return true;
		}
		return false;
	}

	private boolean setProductDetails(EEMApplPlanVO applPlanVO, EEMApplOtherPlanVO otherPlanVO, String updateRecInd,
			String lineOfBiz, int applId) {
		int rslt = 0;
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();
		EEMApplPlanDO applPlanDO = new EEMApplPlanDO();
		EEMApplOtherPlanDO otherPlanDO = new EEMApplOtherPlanDO();

		BeanUtils.copyProperties(applPlanVO, applPlanDO);
		BeanUtils.copyProperties(otherPlanVO, otherPlanDO);

		applPlanDO.setApplId(String.valueOf(applId));
		applPlanDO.setCustomerId(customerId);

		otherPlanDO.setApplId(applId);
		otherPlanDO.setCustomerId(customerId);

		if (updateRecInd.equals("N") || trimToEmpty(applPlanVO.getLastUpdtTime()).equals("")) {
			rslt += applicationDAO.insertPlanDetails(applPlanDO, userId);
		}
		if ((updateRecInd.equals("N") || trimToEmpty(otherPlanVO.getLastUpdtTime()).equals(""))
				&& !trimToEmpty(otherPlanDO.getPcpName()).equals("")) {
			rslt += applicationDAO.insertPCPDetails(otherPlanDO, userId, applPlanVO.getReqDtCov(), lineOfBiz);
		}
		if (updateRecInd.equals("Y") && !trimToEmpty(applPlanVO.getLastUpdtTime()).equals("")) {
			rslt += applicationDAO.updatePlanDetails(applPlanDO, userId);
		}
		if (updateRecInd.equals("Y") && !trimToEmpty(otherPlanVO.getLastUpdtTime()).equals("")) {
			if (trimToEmpty(otherPlanDO.getPcpName()).equals("")) {
				rslt += applicationDAO.deletePCPDetails(otherPlanDO);
			} else {
				rslt += applicationDAO.updatePCPDetails(otherPlanDO, applPlanVO.getReqDtCov(), lineOfBiz, userId);
			}
		}
		if (rslt > 0) {
			BeanUtils.copyProperties(applPlanDO, applPlanVO);
			BeanUtils.copyProperties(otherPlanDO, otherPlanVO);
			return true;
		}
		return false;
	}

	public int insertErrorApplError(List<String[]> allApplication, String customerId, int applId, String userId) {
		int rowsInserted = 0;
		String[] plan = new String[3];
		EEMApplErrorDO eemErrorDO = null;

		for (int i = 0; i < allApplication.size(); i++) {
			plan = allApplication.get(i);
			if (!plan[2].equalsIgnoreCase(String.valueOf(applId))) {
				eemErrorDO = new EEMApplErrorDO();
				eemErrorDO.setCustomerId(customerId);
				eemErrorDO.setApplicationId(Integer.parseInt(plan[2]));
				eemErrorDO.setErrorCd("AP057");
				eemErrorDO.setFieldNbr("100010");
				eemErrorDO.setRfiInd("N");
				eemErrorDO.setErrorData("");
				rowsInserted += applicationDAO.insertErrorDetails(eemErrorDO, userId);
			}
		}
		return rowsInserted;
	}

	private String evalErrorStatus(List<EEMApplErrorVO> lstErrors) {

		List<LabelValuePair> lstStatus = eemPersistence.getLstApplStatus();
		List<String> lstPrior = new ArrayList<>();
		LabelValuePair nvp = null;
		for (int i = 0; i < lstStatus.size(); i++) {
			nvp = lstStatus.get(i);
			lstPrior.add(nvp.getValue());
		}
		EEMApplErrorVO errorVO = lstErrors.get(0);
		String status = errorVO.getStatus();
		int prevPrior = lstPrior.indexOf(status);
		for (int i = 1; i < lstErrors.size(); i++) {
			errorVO = lstErrors.get(i);
			int newPrior = lstPrior.indexOf(errorVO.getStatus());
			if ((newPrior != -1 && newPrior < prevPrior) || prevPrior == -1) {
				prevPrior = newPrior;
				status = errorVO.getStatus();
			}
		}
		return trimToEmpty(status);
	}

	public boolean isCancelOrDenied(String applStatus) {
		return applStatus.equals(EEMConstants.APPL_STATUS_CANCELED)
				|| applStatus.equals(EEMConstants.APPL_STATUS_DENIEDELG)
				|| applStatus.equals(EEMConstants.APPL_STATUS_DENIEDETYP)
				|| applStatus.equals(EEMConstants.APPL_STATUS_DENIEDOTHR);
	}

	public Boolean updateApplComments(List<EEMApplCommentsVO> applCommentsVOList, int applId) {
		List<EEMApplCommentsDO> applCommentsDOList = new ArrayList<>();
		int count = 0;
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();

		if (applCommentsVOList.isEmpty()) {
			return true;
		} else {
			for (EEMApplCommentsVO eemApplCommentsVO : applCommentsVOList) {
				if (StringUtils.equals(EEMConstants.VALUE_YES, eemApplCommentsVO.getInsert())) {
					EEMApplCommentsDO eEMApplCommentsDO = new EEMApplCommentsDO();
					BeanUtils.copyProperties(eemApplCommentsVO, eEMApplCommentsDO);
					eEMApplCommentsDO.setCreateUserId(userId);
					applCommentsDOList.add(eEMApplCommentsDO);
				}
			}
			
			if(CommonUtils.isNotEmpty(applCommentsDOList)) {
				count = applicationDAO.insertBulkCommentDetails(customerId, applId, applCommentsDOList);
			}
		}
		return count > 0;
	}

	public boolean checkLockInd(EEMApplMasterVO applMasterVO, CacheService sessionHelper) {
		boolean valid = false;

		String lockInd = this.getLockInd(applMasterVO.getApplVO().getCurrStatus());
		boolean isEEMSupervisor = sessionHelper.isEEMSupervisor();

		if (isEEMSupervisor) {
			if (lockInd.equals("M") || lockInd.equals("L") || lockInd.equals("I") || lockInd.equals("")) {
				valid = true;
			}
		} else {
			if (!lockInd.equals("M")) {
				valid = true;
			}
		}
		if (!valid) {
			applMasterVO.getApplVO().setMessage("User doesnot have permission to Update when status is "
					+ applMasterVO.getApplVO().getCurrStatus());
		}
		valid = true;
		return valid;
	}

	private String getLockInd(String currStatus) {

		return applicationDAO.getLockInd(currStatus);
	}

	public List<LabelValuePair> getCounty(Map<String, String> searchParamMap) {

		String perZip5 = trimToEmpty(searchParamMap.get("perZip5"));

		return (eemPersistence.getLstCounty(perZip5));
	}

	public List<LabelValuePair> getCity(Map<String, String> searchParamMap) {

		String perZip5 = trimToEmpty(searchParamMap.get("perZip5"));

		return (eemPersistence.getLstCity(perZip5, ""));
	}

	public void getErrorDetails(EEMApplMasterVO applMasterVO) {

		List<EEMApplErrorDO> applErrorDOList = applicationDAO.getErrorDetails(applMasterVO.getApplVO().getApplId(),
				sessionHelper.getUserInfo().getCustomerId());

		List<EEMApplErrorVO> applErrorVOList = new ArrayList<>();
		CommonUtils.copyList(applErrorDOList, applErrorVOList, EEMApplErrorVO.class);
		applMasterVO.setApplErrList(applErrorVOList);
	}

	public List<LabelValuePair> getPreSetNoteList(EmPreSetNoteVO emPreSetNoteVO) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();

		return (applicationDAO.getPreSetNotes(customerId, emPreSetNoteVO));
	}

	public Boolean addorUpdatePreSetNote(EmPreSetNoteVO emPreSetNoteVO) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		boolean flag = false;

		String radioCheck = emPreSetNoteVO.getRadioCheck();
		if ("A".equalsIgnoreCase(radioCheck)) {

			flag = applicationDAO.insertPreSetNote(customerId, emPreSetNoteVO);

		} else if ("M".equalsIgnoreCase(radioCheck)) {

			flag = applicationDAO.modifyPreSetNote(customerId, emPreSetNoteVO);

		} else if ("D".equalsIgnoreCase(radioCheck)) {

			flag = applicationDAO.deletePreSetNote(customerId, emPreSetNoteVO);
		}

		if (flag) {
			eemPersistence.evictSpecificCache("getPreSetNotes");
		}
		return flag;
	}

	public List<LabelValuePair> getCountyList(Map<String, String> searchParamMap) {

		String perZip5 = trimToEmpty(searchParamMap.get("perZip5"));

		return applicationDAO.getCountyList(perZip5);
	}

	public Map<String, Object> populateCountyCityState(String perZip5, String perZip4) {

		return applicationDAO.populateCountyCityState(perZip5, perZip4);
	}

	public List<LabelValuePair> getCities(String perZip5, String county) {

		return applicationDAO.getCities(perZip5, county);
	}

	public List<EEMApplStatusTrackVO> applicationStatusTrack(String applicationId) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();

		List<EEMApplStatusTrackVO> applStatusVOList = new ArrayList<>();

		List<EEMApplStatusTrackDO> applStatusDOList = applicationDAO.getApplicationStatusTrack(applicationId,
				customerId);
		CommonUtils.copyList(applStatusDOList, applStatusVOList, EEMApplStatusTrackVO.class);
		return applStatusVOList;
	}

	public ApplCacheVO getApplInitialData() {

		String customerId = sessionHelper.getUserInfo().getCustomerId();

		return applHelper.setApplFormList(customerId, sessionHelper);
	}

	/*
	 * public EEMApplOtherCovVO getInstDetails(String instId, String dateOfCov) {
	 * 
	 * String customerId = sessionHelper.getUserInfo().getCustomerId();
	 * 
	 * List<EEMApplOtherCovDO> eemApplOtherCovDOList =
	 * eemPersistence.getOtherCovDetails(customerId);
	 * 
	 * EEMApplOtherCovVO eemApplOtherCovVO = new EEMApplOtherCovVO(); for
	 * (EEMApplOtherCovDO eemApplOtherCovDO : eemApplOtherCovDOList) { String
	 * nameInstitute = eemApplOtherCovDO.getNameInstitute(); String effStartDate =
	 * eemApplOtherCovDO.getEffStartDate(); String effEndDate =
	 * eemApplOtherCovDO.getEffEndDate(); String reqDtCov =
	 * DateFormatter.reFormat(dateOfCov, DateFormatter.MM_DD_YYYY,
	 * DateFormatter.YYYYMMDD); if ((StringUtils.equals(instId, nameInstitute)) &&
	 * (DateMath.isBetween(reqDtCov, effStartDate, effEndDate))) {
	 * BeanUtils.copyProperties(eemApplOtherCovDO, eemApplOtherCovVO); break; } }
	 * return eemApplOtherCovVO; }
	 */

	public EEMLtcFacilityVO getLtcDetails(String instId, String dateOfCov) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();

		List<EEMLtcFacilityDO> eemLtcFacilityDODOList = eemPersistence.getLtcDetails(customerId);

		EEMLtcFacilityVO eemLtcFacilityVO = new EEMLtcFacilityVO();
		for (EEMLtcFacilityDO eemLtcFacilityDO : eemLtcFacilityDODOList) {
			String nameInstitute = eemLtcFacilityDO.getNameInstitute();
			String effStartDate = eemLtcFacilityDO.getEffStartDate();
			String effEndDate = eemLtcFacilityDO.getEffEndDate();
			String reqDtCov = DateFormatter.reFormat(dateOfCov, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
			if ((StringUtils.equals(instId, nameInstitute))
					&& (DateMath.isBetween(reqDtCov, effStartDate, effEndDate))) {
				BeanUtils.copyProperties(eemLtcFacilityDO, eemLtcFacilityVO);
				break;
			}
		}
		return eemLtcFacilityVO;
	}

	public PageableVO getApplPagination(Map<String, String> searchParamMap) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		return applicationDAO.getApplSearchDetails(customerId, searchParamMap, true);
	}

}
