package com.medicare.mss.helper;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.exception.UnAuthorizedException;
import com.medicare.mss.helper.EEMContext;
import com.medicare.mss.security.vo.SecuserDetails;

/**
 * The Class CacheService.
 * 
 * @author PRAVEEN KUMAR $ONI
 */
@Service
public class CacheService {

	private static final String ERR_MSG = "Invalid Credentials";

	/** The template. */
	@Autowired
	RedisTemplate<String, Object> template;

	/**
	 * Sets the authentication.
	 *
	 * @param secuserDetails
	 *            the new authentication
	 */
	public void setAuthentication(String userId, UserDetails secuserDetails, String cacheName) {
		ObjectMapper mapper = new ObjectMapper();
		String jsonString = null;
		try {
			jsonString = mapper.writeValueAsString(secuserDetails);
		} catch (JsonProcessingException exp) {
			exp.printStackTrace();
		}
		synchronized (this) {
			template.opsForHash().put(userId, cacheName, jsonString);
		}
	}

	/**
	 * Gets the authentication.
	 *
	 * @param userId
	 *            the user id
	 * @return the authentication
	 */
	public SecuserDetails getAuthentication(String userId, String cacheName) {

		ObjectMapper mapper = new ObjectMapper();
		mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

		Object cache = template.opsForHash().get(userId, cacheName);
		SecuserDetails auth = null;
		if (null != cache) {
			String cacheData = cache.toString();
			try {
				auth = mapper.readValue(cacheData, SecuserDetails.class);
			} catch (JsonProcessingException exp) {
				exp.printStackTrace();
			}

		}
		return auth;
	}

	public void setUserCache(String userId, String cacheName, Object data) {

		ObjectMapper mapper = new ObjectMapper();
		mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		String cacheData = null;
		try {
			cacheData = mapper.writeValueAsString(data);
		} catch (JsonProcessingException exp) {
			exp.printStackTrace();
		}
		synchronized (this) {
			template.opsForHash().put(userId, cacheName, cacheData);
		}

	}

	public <T> Object getUserCache(String userId, String cacheName, Class<T> clazzzz) {

		ObjectMapper mapper = new ObjectMapper();
		mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

		Object cache = template.opsForHash().get(userId, cacheName);
		Object data = null;
		if (null != cache) {
			String cacheData = cache.toString();
			try {
				data = mapper.readValue(cacheData, clazzzz);
			} catch (JsonProcessingException exp) {
				exp.printStackTrace();
			}

		}
		return data;

	}

	public void removeUserCache(String userId) {
		template.delete(userId);

	}

	public SecuserDetails getUserInfo() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication.getPrincipal() instanceof SecuserDetails) {
			return (SecuserDetails) authentication.getPrincipal();
		} else {
			throw new UnAuthorizedException(ERR_MSG);
		}
	}

	public EEMContext getEEMContext() {

		String userId = getUserInfo().getUserId();
		EEMContext context = (EEMContext) getUserCache(userId, EEMConstants.EEMCONTEXT, EEMContext.class);

		if (null == context) {
			context = new EEMContext();
		}

		return context;
	}

	public void setEEMContext(EEMContext context) {
		String userId = getUserInfo().getUserId();
		setUserCache(userId, EEMConstants.EEMCONTEXT, context);

	}

	@SuppressWarnings("unchecked")
	public boolean isEEMSupervisor() {
		String userId = getUserInfo().getUserId();

		List<String> services = (List<String>) getUserCache(userId, EEMConstants.SERVICES, List.class);

		return services.contains("EEMS");
	}

	public void setAttribute(String attrName, String attrValue) {
		String userId = getUserInfo().getUserId();
		setUserCache(userId, attrName, attrValue);

	}

	public String getAttribute(String attrName) {
		String userId = getUserInfo().getUserId();
		return (String)getUserCache(userId, attrName, String.class);

	}
}
