package com.medicare.mss.daoImpl;

import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.rowset.serial.SerialBlob;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMLetterReviewDAO;
import com.medicare.mss.domainobject.EEMLetterUploadFormDO;
import com.medicare.mss.domainobject.EmCorrMbrDO;
import com.medicare.mss.domainobject.EmCorrVarDataDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.util.PaginationQueryHelper;
import com.medicare.mss.vo.DataBaseField;
import com.medicare.mss.vo.EEMLetterReviewQCMasterVO;
import com.medicare.mss.vo.EEMLetterReviewVO;
import com.medicare.mss.vo.EmCorrMbrVO;
import com.medicare.mss.vo.PageableVO;

@Repository
public class EEMLetterReviewDAOImpl implements EEMLetterReviewDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Override
	public List<EmCorrVarDataDO> getMbrLetterData(Map<String, String> searchParamMap) {

		String customerId = trimToEmpty(searchParamMap.get("customerId"));
		String fileBatchId = trimToEmpty(searchParamMap.get("fileBatchId"));
		String recordType = trimToEmpty(searchParamMap.get("recordType"));
		String primaryId = trimToEmpty(searchParamMap.get("primaryId"));
		String letterName = trimToEmpty(searchParamMap.get("letterName"));

		ArrayList<Object> params = new ArrayList<>();

		StringBuilder sQuery = CommonUtils.buildQueryBuilder("SELECT CVD.VARIABLE_SEQ_NBR, ",
				"CVD.VARIABLE_ID, CCV.VARIABLE_DESC, CVD.VARIABLE_DATA FROM EM_CORR_VAR_DATA CVD ",
				"LEFT OUTER JOIN EM_CORR_CTL_VAR CCV ON CCV.CUSTOMER_ID = CVD.CUSTOMER_ID ",
				"AND CCV.LETTER_NAME = CVD.LETTER_NAME AND CCV.VARIABLE_ID = CVD.VARIABLE_ID ",
				"AND CCV.VARIABLE_SEQ_NBR = CVD.VARIABLE_SEQ_NBR ",
				"WHERE CVD.CUSTOMER_ID = ? AND CVD.PRIMARY_ID = ? ");

		params.add(customerId);
		params.add(primaryId);

		if (!trimToEmpty(fileBatchId).isEmpty()) {
			sQuery = sQuery.append(" AND CVD.FILE_BATCH_ID = ?  ");
			params.add(fileBatchId);
		}

		if (!trimToEmpty(recordType).isEmpty()) {
			sQuery = sQuery.append(" AND CVD.RECORD_TYPE = ?  ");
			params.add(recordType);
		}

		if (!trimToEmpty(letterName).isEmpty()) {
			sQuery = sQuery.append(" AND CVD.LETTER_NAME = ?  ");
			params.add(letterName);
		}
		sQuery = sQuery.append(" ORDER BY CVD.VARIABLE_SEQ_NBR ");

		Object[] objPrams = params.toArray();
		try {
			return jdbcTemplate.query(sQuery.toString(),
					new DomainPropertyRowMapper<EmCorrVarDataDO>(EmCorrVarDataDO.class), objPrams);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error occured while letter fetching");
		}

	}

	@Override
	public PageableVO getLetterReviewSearchResults(EEMLetterReviewVO letterReviewVO,boolean isPagination) {

		PageableVO response = new PageableVO();
		
		String customerId = trimToEmpty(letterReviewVO.getCustomerId());
		String searchType = trimToEmpty(letterReviewVO.getSearchType());
		String searchId = trimToEmpty(letterReviewVO.getSearchId()).toUpperCase();
		String searchReqFromDate = trimToEmpty(letterReviewVO.getSearchReqFromDate());
		String searchReqToDate = trimToEmpty(letterReviewVO.getSearchReqToDate());
		String searchStatus = trimToEmpty(letterReviewVO.getSearchStatus());
		String searchBatchId = trimToEmpty(letterReviewVO.getSearchBatchId());
		String searchLetterName = trimToEmpty(letterReviewVO.getSearchLetterName());
		String searchDeleteInd = trimToEmpty(letterReviewVO.getSearchDeleteInd());
		
		String lastRowPrimaryId = trimToEmpty(letterReviewVO.getLastRowPrimaryId());
		String lastRowFileBatchId = trimToEmpty(letterReviewVO.getLastRowFileBatchId());
		String lastRowLetterName = trimToEmpty(letterReviewVO.getLastRowLetterName());
		String lastRowRecordType = trimToEmpty(letterReviewVO.getLastRowRecordType());
		
		ArrayList<String> params = new ArrayList<>();

		StringBuilder sQuery = CommonUtils.buildQueryBuilder(
				"SELECT CM.CUSTOMER_ID,CM.PDF_ARCHIVAL, CM.FILE_BATCH_ID, CM.RECORD_TYPE, CM.PRIMARY_ID,",
				" CM.LETTER_NAME, CC.DESCRIPTION, CM.REQUEST_DATE, CM.ORIG_MAIL_DATE, CM.LAST_MAIL_DATE,",
				" CM.SUPPLEMENTAL_ID, CM.DELETE_IND, CM.RECORD_STATUS,",
				" CM.CREATE_TIME, CM.CREATE_USERID, CM.LAST_UPDT_TIME, CM.LAST_UPDT_USERID",
				", CM.PRINT_DATE, CM.REPRINT_DATE, CM.RESPONSE_DUE_DATE, CM.RESPONSE_DATE ",
				", (SELECT MAX(LETTER_CREATION_TIME) FROM EM_CORR_DMS ", " WHERE CUSTOMER_ID = CM.CUSTOMER_ID ",
				" AND PRIMARY_ID = CM.PRIMARY_ID ", " AND CUSTOMER_LETTER_NAME = CM.LETTER_NAME ",
				" AND FILE_BATCH_ID = CM.FILE_BATCH_ID ", ") AS LETTER_UPLOADED_TIME ", " FROM EM_CORR_MBR CM",
				" LEFT OUTER JOIN EM_CORR_CTL CC", " ON CC.CUSTOMER_ID = CM.CUSTOMER_ID",
				" AND CC.LETTER_NAME = CM.LETTER_NAME", " WHERE CM.CUSTOMER_ID = ?");

		params.add(customerId);

		if (!searchBatchId.isEmpty()) {
			sQuery.append(" AND CM.FILE_BATCH_ID = ?");
			params.add(searchBatchId);
		}

		if (!searchType.isEmpty()) {
			sQuery.append(" AND CM.RECORD_TYPE = ?");
			params.add(searchType);
		}
		if (!searchId.isEmpty()) {
			sQuery.append(" AND CM.PRIMARY_ID = ?");
			params.add(searchId);
		}
		if (!searchLetterName.isEmpty()) {
			sQuery.append(" AND CM.LETTER_NAME = ?");
			params.add(searchLetterName);
		}
		if (!searchDeleteInd.isEmpty()) {
			sQuery.append(" AND CM.DELETE_IND = 'Y'");
		}
		if ((!searchReqFromDate.isEmpty()) || (!searchReqToDate.isEmpty())) {
			if (searchReqFromDate.equals(""))
				searchReqFromDate = "00000000";
			if (searchReqToDate.equals(""))
				searchReqFromDate = "99999999";
			sQuery.append(" AND CM.REQUEST_DATE BETWEEN ? AND ?");
			params.add(searchReqFromDate);
			params.add(searchReqToDate);
		}
		if (!searchStatus.isEmpty()) {
			if (searchStatus.equals("LDAPP")) {
				sQuery.append(" AND CM.RECORD_STATUS in ('LOADED','APPLIED')");
			} else {
				sQuery.append(" AND CM.RECORD_STATUS = ?");
				params.add(searchStatus);
			}
		}

		if (isPagination) {

			DataBaseField[] conds = new DataBaseField[4];
			for (int i = 0; i < 4; i++) {
				conds[i] = new DataBaseField();
			}
			conds[0].setFieldName("CM.FILE_BATCH_ID");
			conds[1].setFieldName("CM.RECORD_TYPE");
			conds[2].setFieldName("CM.PRIMARY_ID");			
			conds[3].setFieldName("CM.LETTER_NAME");
			
			
			conds[0].setStringValue(lastRowFileBatchId);
			conds[1].setStringValue(lastRowRecordType);
			conds[2].setStringValue(lastRowPrimaryId);
			conds[3].setStringValue(lastRowLetterName);
			

			StringBuilder pageCond = PaginationQueryHelper.pagingElements(conds, params);
			sQuery.append(pageCond);
		}
		
		sQuery.append(" ORDER BY CM.CUSTOMER_ID, CM.FILE_BATCH_ID, CM.RECORD_TYPE, CM.PRIMARY_ID, CM.LETTER_NAME");
		sQuery.append(" FETCH FIRST ").append(EEMConstants.DB_MAX_RECORD_FETCH).append(" ROWS ONLY");

		Object[] objPrams = params.toArray();
		List<EmCorrMbrDO> mbrLetterDOList = new ArrayList<>();
		try {
			mbrLetterDOList = jdbcTemplate.query(sQuery.toString(), new DomainPropertyRowMapper<EmCorrMbrDO>(EmCorrMbrDO.class),
					objPrams);

			if (mbrLetterDOList != null && !mbrLetterDOList.isEmpty() && (mbrLetterDOList.size()>100)) {
					mbrLetterDOList.remove(mbrLetterDOList.size()-1);
					response.setNextPage(true);
				}
			response.setContent(mbrLetterDOList);
			return response;

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error occured during letter review search");
		}
	}

	@Override
	public byte[] displayDocumentFromDB(Map<String, String> searchParamMap) {
		String customerId = trimToEmpty(searchParamMap.get("customerId"));
		String primaryId = trimToEmpty(searchParamMap.get("primaryId"));
		String letterName = trimToEmpty(searchParamMap.get("letterName"));
		String letterUploadedTime = trimToEmpty(searchParamMap.get("letterUploadedTime"));

		String fileBatchId = trimToEmpty(searchParamMap.get("filebatchid"));

		byte[] blobByte = null;
		java.sql.Blob blob = null;
		try {

			StringBuilder sQuery = CommonUtils.buildQueryBuilder("SELECT LETTER_PDF FROM EM_CORR_DMS ",
					"WHERE CUSTOMER_ID = ? AND PRIMARY_ID = ? AND ",
					"CUSTOMER_LETTER_NAME = ? AND FILE_BATCH_ID= ? AND LETTER_CREATION_TIME = ?  ");

			blob = jdbcTemplate.queryForObject(sQuery.toString(),
					new Object[] { customerId, primaryId, letterName, fileBatchId, letterUploadedTime },
					java.sql.Blob.class);

			blobByte = blob.getBytes(1, (int) blob.length());

		} catch (EmptyResultDataAccessException exp) {
			throw new ApplicationException(exp, "PDF file is not available");
		} catch (SQLException exp) {
			throw new ApplicationException(exp, "Error occured while fetching the letter");
		}
		return blobByte;

	}

	@Override
	public void updateCorrMbr(EmCorrMbrDO newDO, String userId, String lastUpdtTime) {

		StringBuilder sQuery = CommonUtils.buildQueryBuilder("UPDATE EM_CORR_MBR SET DELETE_IND = ?,",
				" RECORD_STATUS = ?, LAST_UPDT_TIME = ?, LAST_UPDT_USERID = ?,",
				" REQUEST_DATE = ?, ORIG_MAIL_DATE = ?, LAST_MAIL_DATE = ?, PRINT_DATE = ?, REPRINT_DATE = ?,",
				" RESPONSE_DUE_DATE = ?, RESPONSE_DATE = ?", " WHERE CUSTOMER_ID = ? AND FILE_BATCH_ID = ?",
				" AND RECORD_TYPE = ? AND PRIMARY_ID = ? AND LETTER_NAME = ?", " AND LAST_UPDT_TIME = ?");

		Object[] parms = new Object[] { trimToEmpty(newDO.getDeleteInd()), trimToEmpty(newDO.getRecordStatus()),
				trimToEmpty(newDO.getLastUpdtTime()), userId, trimToEmpty(newDO.getRequestDate()),
				trimToEmpty(newDO.getOrigMailDate()), trimToEmpty(newDO.getLastMailDate()),
				trimToEmpty(newDO.getPrintDate()), trimToEmpty(newDO.getReprintDate()),
				trimToEmpty(newDO.getResponseDueDate()), trimToEmpty(newDO.getResponseDate()),
				trimToEmpty(newDO.getCustomerId()), trimToEmpty(newDO.getFilebatchid()),
				trimToEmpty(newDO.getRecordType()), trimToEmpty(newDO.getPrimaryId()),
				trimToEmpty(newDO.getLetterName()), trimToEmpty(lastUpdtTime) };

		try {
			jdbcTemplate.update(sQuery.toString(), parms);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error occured during update operation");
		}
	}

	@Override
	public void updateCorrInputJournal(String customerId, String filebatchid, String deleteAdj, String holdAdj,
			String userId) {

		StringBuilder sQuery = CommonUtils.buildQueryBuilder(
				"UPDATE EM_INPUT_JOURNAL SET UI_DELETED_CNT = UI_DELETED_CNT + ?,",
				" UI_HOLD_CNT = UI_HOLD_CNT + ?,  LAST_UPDT_TIME = CURRENT_TIMESTAMP,", " LAST_UPDT_USERID = ?",
				" WHERE CUSTOMER_ID = ? AND FILE_ID = ? AND JOURNAL_TYPE = 'COR'");

		Object[] parms = new Object[] { deleteAdj, holdAdj, userId, customerId, filebatchid };

		try {
			jdbcTemplate.update(sQuery.toString(), parms);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error occured while update the Journal table");
		}
	}

	@Override
	public void uploadLettersToDataBase(EEMLetterUploadFormDO eemLetterUploadForm, String strDateTimeStamp) {

		try {
			Blob blob = new SerialBlob(eemLetterUploadForm.getFile());

			Object[] parms = new Object[] { trimToEmpty(eemLetterUploadForm.getCustomerId()),
					trimToEmpty(eemLetterUploadForm.getMemberId()), strDateTimeStamp,
					trimToEmpty(eemLetterUploadForm.getFileName()), blob, "0",
					trimToEmpty(eemLetterUploadForm.getUserId()), strDateTimeStamp, "N",
					trimToEmpty(eemLetterUploadForm.getFileBatchId()) };

			StringBuilder sQuery = CommonUtils.buildQueryBuilder(
					" INSERT INTO EM_CORR_DMS ( CUSTOMER_ID, PRIMARY_ID, LETTER_CREATION_TIME, CUSTOMER_LETTER_NAME, LETTER_PDF, SOURCE,",
					" LAST_UPDT_USERID, LAST_UPDT_TIME, OVERRIDE_IND, FILE_BATCH_ID) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )");

			jdbcTemplate.update(sQuery.toString(), parms);

		} catch (SQLException exp) {
			throw new ApplicationException(exp, "Error occured during upload the letter");
		}
	}

	@Override
	public boolean validateSourceAndPrimaryId(String customerId, String primaryId, String recordType) {
		boolean validCombination = false;
		try {
			if (!recordType.equals("")) {

				if (recordType.equals("A")) {

					StringBuilder sQuery = CommonUtils.buildQueryBuilder(
							"SELECT APPLICATION_ID FROM EM_APPLICATION WHERE CUSTOMER_ID = ? AND APPLICATION_ID = ? FETCH FIRST ROW ONLY ");

					jdbcTemplate.queryForObject(sQuery.toString(), new Object[] { customerId, primaryId },
							String.class);

					validCombination = true;
				} else if (recordType.equals("M")) {

					StringBuilder sQuery = CommonUtils.buildQueryBuilder(
							"SELECT MEMBER_ID FROM EM_MBR_DEMOGRAPHIC WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? AND OVERRIDE_IND = ? FETCH FIRST ROW ONLY ");

					jdbcTemplate.queryForObject(sQuery.toString(),
							new Object[] { trimToEmpty(customerId), trimToEmpty(primaryId), "N" }, String.class);

					validCombination = true;
				}

			}
		} catch (EmptyResultDataAccessException exp) {
			return validCombination;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error occured while fetching the application id");
		}
		return validCombination;
	}

	@Override
	public String getMaxFileBatchId(String customerId, String memberId, String letterName) {

		String fileBatchId = "";
		try {
			StringBuilder sQuery = CommonUtils.buildQueryBuilder(
					" SELECT MAX(FILE_BATCH_ID) AS FILE_BATCH_ID FROM EM_CORR_MBR WHERE CUSTOMER_ID = ? AND PRIMARY_ID = ? AND ",
					"  LETTER_NAME = ? AND FILE_BATCH_ID LIKE 'ONL%' ");

			fileBatchId = jdbcTemplate.queryForObject(sQuery.toString(),
					new Object[] { customerId, memberId, letterName }, String.class);

			if (!trimToEmpty(fileBatchId).isEmpty()) {
				return fileBatchId;
			} else {
				return "ONL0000000";
			}

		} catch (EmptyResultDataAccessException exp) {
			return "ONL0000000";
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error occured while fetching the maximum file batch id");
		}
	}

	@Override
	public void insertMemberAndApplicationLetters(EEMLetterUploadFormDO eemLetterUploadFormDO,
			String strDateTimeStamp) {

		String printRequestDate = "";
		if (!trimToEmpty(eemLetterUploadFormDO.getPrintRequestDate()).isEmpty()) {
			printRequestDate = trimToEmpty(eemLetterUploadFormDO.getPrintRequestDate());
		}

		String origMailDate = "";
		if (!trimToEmpty(eemLetterUploadFormDO.getOrigMailDate()).isEmpty()) {
			origMailDate = trimToEmpty(eemLetterUploadFormDO.getOrigMailDate());
		}

		String lastMailDate = "";
		if (!trimToEmpty(eemLetterUploadFormDO.getLastMailDate()).isEmpty()) {
			lastMailDate = trimToEmpty(eemLetterUploadFormDO.getLastMailDate());
		}

		String datePrinted = "";
		if (!trimToEmpty(eemLetterUploadFormDO.getPrintDate()).isEmpty()) {
			datePrinted = trimToEmpty(eemLetterUploadFormDO.getPrintDate());
		}

		String reprintDate = "";
		if (!trimToEmpty(eemLetterUploadFormDO.getReprintDate()).isEmpty()) {
			reprintDate = trimToEmpty(eemLetterUploadFormDO.getReprintDate());
		}

		String responseDueDate = "";
		if (!trimToEmpty(eemLetterUploadFormDO.getResponseDueDate()).isEmpty()) {
			responseDueDate = trimToEmpty(eemLetterUploadFormDO.getResponseDueDate());
		}

		String responseDate = "";
		if (!trimToEmpty(eemLetterUploadFormDO.getResponseDate()).isEmpty()) {
			responseDate = trimToEmpty(eemLetterUploadFormDO.getResponseDate());
		}

		Object[] parms = new Object[] { trimToEmpty(eemLetterUploadFormDO.getCustomerId()),
				trimToEmpty(eemLetterUploadFormDO.getFileBatchId()), trimToEmpty(eemLetterUploadFormDO.getRecordType()),
				trimToEmpty(eemLetterUploadFormDO.getMemberId()), trimToEmpty(eemLetterUploadFormDO.getFileName()),
				printRequestDate, origMailDate, lastMailDate, "", "UPLOADED", strDateTimeStamp,
				trimToEmpty(eemLetterUploadFormDO.getUserId()), strDateTimeStamp, "", "", responseDate, "", datePrinted,
				responseDueDate, reprintDate };

		try {
			StringBuilder sQuery = CommonUtils.buildQueryBuilder(
					"INSERT INTO EM_CORR_MBR ( CUSTOMER_ID, FILE_BATCH_ID, RECORD_TYPE,PRIMARY_ID, LETTER_NAME, ",
					" REQUEST_DATE, ORIG_MAIL_DATE, LAST_MAIL_DATE, DELETE_IND, RECORD_STATUS, CREATE_TIME, CREATE_USERID, LAST_UPDT_TIME, ",
					" LAST_UPDT_USERID, SUPPLEMENTAL_ID, RESPONSE_DATE, DMS_ID, PRINT_DATE, RESPONSE_DUE_DATE, REPRINT_DATE ) ",
					" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");

			jdbcTemplate.update(sQuery.toString(), parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error occured during insertion");
		}

	}

	@Override
	public List<LabelValuePair> getLetterReviewQcBatchId(EEMLetterReviewVO letterReviewVO, String customerId) {

		try {

			StringBuilder sQuery = CommonUtils.buildQueryBuilder("SELECT DISTINCT FILE_BATCH_ID FROM EM_CORR_MBR ",
					"WHERE CUSTOMER_ID = '" + customerId + "' AND date(CREATE_TIME) >= '"
							+ letterReviewVO.getSearchReqFromDateFrmt() + "' AND date(CREATE_TIME) <= '"
							+ letterReviewVO.getSearchReqToDateFrmt() + "' AND RECORD_STATUS = 'EXTRACTED'");

			String sValue = "FILE_BATCH_ID";
			String sName = "FILE_BATCH_ID";

			return getLabelValuePair(sQuery.toString(), sName, sValue);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error occured while fetching the batch id");
		}
	}

	@Override
	public List<LabelValuePair> getLetterReviewQcDescription(String batchId, String customerId) {
		try {

			StringBuilder sQuery = CommonUtils.buildQueryBuilder("SELECT DISTINCT LETTER_NAME FROM EM_CORR_MBR ",
					"WHERE FILE_BATCH_ID = '" + batchId + "'  AND CUSTOMER_ID = '" + customerId
							+ "'  AND RECORD_STATUS = 'EXTRACTED'");

			String sValue = "LETTER_NAME";
			String sName = "LETTER_NAME";

			return getLabelValuePair(sQuery.toString(), sName, sValue);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error occured while fetching the letter name");
		}
	}

	private List<LabelValuePair> getLabelValuePair(String sQuery, String sValue, String sDesc) {

		return jdbcTemplate.query(sQuery, (ResultSet res) -> {
			List<LabelValuePair> hmp = new ArrayList<>();
			while (res.next()) {
				String value = trimToEmpty(res.getString(sValue));
				String desc = trimToEmpty(res.getString(sDesc));

				LabelValuePair pair = new LabelValuePair(value, desc);

				hmp.add(pair);
			}
			return hmp;
		});

	}

	@Override
	public List<EmCorrMbrDO> getLetterReviewQCSearchResults(EEMLetterReviewVO letterReviewSearch, String customerId,
			String ts) {

		String recordStatus = trimToEmpty(letterReviewSearch.getLtrStatus());
		String frmDate = trimToEmpty(letterReviewSearch.getSearchReqFromDateFrmt());
		String toDate = trimToEmpty(letterReviewSearch.getSearchReqToDateFrmt());
		String batchId = trimToEmpty(letterReviewSearch.getSearchBatchId());
		String letterName = trimToEmpty(letterReviewSearch.getSearchLetterName());

		ArrayList<Object> params = new ArrayList<>();

		StringBuilder sQuery = CommonUtils.buildQueryBuilder(
				"SELECT CM.CUSTOMER_ID, CM.FILE_BATCH_ID,CM.PDF_ARCHIVAL, CM.RECORD_TYPE, CM.PRIMARY_ID, CM.REQUEST_DATE,",
				" CM.LETTER_NAME, CM.LAST_UPDT_TIME, CM.LAST_UPDT_USERID, CM.RECORD_STATUS, MAX(CC.LETTER_CREATION_TIME) AS LETTER_UPLOADED_TIME",
				" FROM EM_CORR_DMS CC", " RIGHT OUTER JOIN EM_CORR_MBR CM ON CC.PRIMARY_ID = CM.PRIMARY_ID",
				" AND CM.CUSTOMER_ID = CC.CUSTOMER_ID", " AND CC.CUSTOMER_LETTER_NAME = CM.LETTER_NAME",
				"  AND CC.FILE_BATCH_ID = CM.FILE_BATCH_ID ",
				"  WHERE CM.RECORD_STATUS = ?  AND date(CREATE_TIME) >= ? AND date(CREATE_TIME) <= ? ");

		params.add(recordStatus);
		params.add(frmDate);
		params.add(toDate);

		if (!batchId.isEmpty()) {
			sQuery.append(" AND CM.FILE_BATCH_ID = ?");
			params.add(batchId);
		}
		if (!letterName.isEmpty()) {
			sQuery.append(" AND CM.LETTER_NAME = ?");
			params.add(letterName);
		}
		if (!recordStatus.equals("EXTRACTED")) {
			sQuery.append(" AND CM.LAST_UPDT_TIME = ?");
			params.add(ts);
		}
		sQuery.append(" AND CM.CUSTOMER_ID = ?");
		params.add(customerId);

		sQuery.append(
				" GROUP BY CM.CUSTOMER_ID,CM.PDF_ARCHIVAL,CM.FILE_BATCH_ID, CM.RECORD_TYPE, CM.PRIMARY_ID, CM.REQUEST_DATE, CM.LETTER_NAME, CM.RECORD_STATUS, CM.LAST_UPDT_TIME, CM.LAST_UPDT_USERID");

		Object[] objPrams = params.toArray();
		try {

			return jdbcTemplate.query(sQuery.toString(), new DomainPropertyRowMapper<EmCorrMbrDO>(EmCorrMbrDO.class),
					objPrams);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error occured while fetching the letters");
		}
	}

	@Override
	public void getLetterReviewQCUpdate(EEMLetterReviewQCMasterVO letterReviewQCSearchVO, String userId,
			String customerId, String ts) {

		String recordStatus = trimToEmpty(letterReviewQCSearchVO.getLetterReviewSearch().getLtrStatus());
		String frmDate = trimToEmpty(letterReviewQCSearchVO.getLetterReviewSearch().getSearchReqFromDateFrmt());
		String toDate = trimToEmpty(letterReviewQCSearchVO.getLetterReviewSearch().getSearchReqToDateFrmt());

		List<EmCorrMbrVO> lstLetterVO = letterReviewQCSearchVO.getLstLetterVO();

		String sQuery = CommonUtils.buildQuery(
				"UPDATE EM_CORR_MBR SET RECORD_STATUS = :recordStatus, LAST_UPDT_USERID = :lastUpdtUserId, ",
				"LAST_UPDT_TIME = :lastUpdtTime WHERE FILE_BATCH_ID = :fileBatchId AND ",
				"LETTER_NAME = :letterName  AND RECORD_STATUS = 'EXTRACTED' AND ",
				"CUSTOMER_ID = :customerId AND RECORD_STATUS != 'COMPLETED' AND PRIMARY_ID = :primaryId",
				"AND date(CREATE_TIME) >= :fromCreateDate AND date(CREATE_TIME) <= :toCreateDate ");

		try {
			List<MapSqlParameterSource> batchArgs = new ArrayList<>();
			for (EmCorrMbrVO letterVO : lstLetterVO) {

				MapSqlParameterSource params = new MapSqlParameterSource();

				params.addValue("recordStatus", recordStatus);
				params.addValue("lastUpdtUserId", userId);
				params.addValue("lastUpdtTime", ts);
				params.addValue("fileBatchId", trimToEmpty(letterVO.getFilebatchid()));
				params.addValue("letterName", trimToEmpty(letterVO.getLetterName()));
				params.addValue("customerId", trimToEmpty(letterVO.getCustomerId()));
				params.addValue("primaryId", trimToEmpty(letterVO.getPrimaryId()));
				params.addValue("fromCreateDate", frmDate);
				params.addValue("toCreateDate", toDate);

				batchArgs.add(params);
			}

			if (!CollectionUtils.isEmpty(batchArgs)) {
				namedParameterJdbcTemplate.batchUpdate(sQuery,
						batchArgs.toArray(new MapSqlParameterSource[lstLetterVO.size()]));
			}

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error occured while update the letter QC");
		}
	}

}
