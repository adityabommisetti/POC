package com.medicare.mss.vo;

import java.io.Serializable;

import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
public class EEMMbrTrrLogVO implements Serializable {

	private static final long serialVersionUID = 8617185478567325447L;

	private String customerId;
	private String memberId;
	private String logTime;
	private String processDate;
	private String effectiveDate;
	private String transactionCode;
	private String transReplyCd;
	private String transReplyDesc;
	private String updateYN;
	private String updateType;
	private String fieldName;
	private String relatedFieldBefore;
	private String relatedFieldAfter;
	private String sourceId;
	private String accRejInd;
	private String lastUpdtUserId;
	private String transReplyDefinition;
	private Boolean isTrrVarDataPresent;

	public String getProcessDateFrmt() {
		return DateFormatter.reFormat(processDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getLogTimeFrmt() {
		return DateFormatter.reFormat(logTime, DateFormatter.DB2_TIMESTAMP, DateFormatter.MM_DD_YYYY_HH_MM_SS);
	}

	public String getEffectiveDateFrmt() {
		return DateFormatter.reFormat(effectiveDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getLogDateFrmt() {
		return DateFormatter.reFormat(logTime, DateFormatter.DB2_TIMESTAMP, DateFormatter.MM_DD_YYYY);
	}

}
