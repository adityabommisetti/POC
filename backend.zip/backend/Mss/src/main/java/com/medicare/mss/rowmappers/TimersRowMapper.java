package com.medicare.mss.rowmappers;

import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.medicare.mss.domainobject.EEMTimersDO;

public class TimersRowMapper implements RowMapper<EEMTimersDO> {

	@Override
	public EEMTimersDO mapRow(ResultSet res, int rowNum) throws SQLException {

		EEMTimersDO timersSearchDO = new EEMTimersDO();

		timersSearchDO.setCustomerId(trimToEmpty(res.getString("CUSTOMER_ID")));
		timersSearchDO.setTriggerCode(trimToEmpty(res.getString("TRIGGER_CODE")));
		timersSearchDO.setTriggerType(trimToEmpty(res.getString("TRIGGER_TYPE")));
		timersSearchDO.setSourceType(trimToEmpty(res.getString("SOURCE_TYPE")));
		timersSearchDO.setPrimaryId(trimToEmpty(res.getString("PRIMARY_ID")));
		timersSearchDO.setTimerType(trimToEmpty(res.getString("TRIGGER_DESC")));

		if ("A".equals(timersSearchDO.getSourceType())) {
			timersSearchDO.setTrgSource("A");
		} else {
			timersSearchDO.setTrgSource("M");
			timersSearchDO.setPlanId(trimToEmpty(res.getString("PLAN_ID")));
			timersSearchDO.setPbpId(trimToEmpty(res.getString("PBP_ID")));
			timersSearchDO.setPlanDesignation(trimToEmpty(res.getString("PLAN_DESIGNATION")));
		}
		timersSearchDO.setLastUpdtTime(trimToEmpty(res.getString("LAST_UPDT_TIME")));
		timersSearchDO.setLastUpdtUserId(trimToEmpty(res.getString("LAST_UPDT_USERID")));

		if (trimToEmpty(res.getString("TRIGGER_STATUS")).equalsIgnoreCase("EXPIRED")) {
			timersSearchDO.setStatus("CLOSED");
		} else if (trimToEmpty(res.getString("TRIGGER_STATUS")).equalsIgnoreCase("OPEN")) {
			timersSearchDO.setStatus("ACTIVE");
		} else {
			timersSearchDO.setStatus(trimToEmpty(res.getString("TRIGGER_STATUS")));
		}
		timersSearchDO.setCreationTime(trimToEmpty(res.getString("CREATE_TIME")));
		timersSearchDO.setActivationTime((trimToEmpty(res.getString("EFFECTIVE_DATE"))));

		return timersSearchDO;
	}

}
