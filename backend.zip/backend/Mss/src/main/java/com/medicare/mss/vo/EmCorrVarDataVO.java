package com.medicare.mss.vo;


import lombok.Data;

@Data
public class EmCorrVarDataVO implements Cloneable {

	/*
		private String customerId;
		private String fileBatchId;
		private String recordType;
		private String recordTypeDesc;
		private String primaryId;
		private String letterName;
		private String letterDesc;
		private String requestDate;
		private String origMailDate;
		private String lastMailDate;
		private String deleteInd;
		private String recordStatus;
		private String createTime;
		private String createUserId;
		private String lastUpdtTime;
		private String lastUpdtUserId;
		private String supplementalId;
		
		
			private String ltrNameWithDesc;
			private String dmsId;
			private String letterUploadedTime;
			private String letterAvailabilityInDB;
			private String source;
			
			private String rePrintType;
			
			
			private String printRequestDate;
			private String letterCreationTime;
			private ServletOutputStream servletOutputStream;
			private String printDate;
			private String responseDueDate;
			private String responseDate;
			private String reprintDate;
			private String variableId;
			private String    variableSeqNbr;
			
			
*/			
			
			private String variableDesc;
			private String variableData;
		
	}

