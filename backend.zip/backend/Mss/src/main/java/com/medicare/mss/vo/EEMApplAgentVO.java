package com.medicare.mss.vo;

import lombok.Data;

@Data
public class EEMApplAgentVO {

	private String agentDt;
	private String agentName;
	private String brokerType;
	private String brokAgentId;
	private String brokAgencyId;
	private String agencyType;
	private String commAgencyId;
	private String lastUpdtTime;
	private String agencyName;
	private String reqDtCov;
	private String customerId;

}
