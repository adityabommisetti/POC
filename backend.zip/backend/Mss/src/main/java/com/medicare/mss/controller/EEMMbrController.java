package com.medicare.mss.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.service.EEMMbrCommentsService;
import com.medicare.mss.service.EEMMbrService;
import com.medicare.mss.vo.EEMMbrCommentVO;
import com.medicare.mss.vo.EEMMbrMasterVO;
import com.medicare.mss.vo.EEMMbrTrrDataVO;
import com.medicare.mss.vo.EEMMbrTrrLogVO;
import com.medicare.mss.vo.MbrCacheVO;
import com.medicare.mss.vo.PageableVO;

@RestController
@RequestMapping("/member")
public class EEMMbrController {

	@Autowired
	EEMMbrCommentsService mbrCommentsService;

	@Autowired
	private EEMMbrService mbrService;

	@PostMapping(ReqMappingConstants.MBR_SEARCH)
	public ResponseEntity<JSONResponse> mbrSearch(@RequestBody Map<String, String> searchParamMap) {

		EEMMbrMasterVO mbrMasterVO = mbrService.getMemberSearchDetails(searchParamMap);
		return sendResponse(mbrMasterVO);
	}

	@PostMapping(ReqMappingConstants.MBR_SEARCH_NEXT)
	public ResponseEntity<JSONResponse> mbrSearchPagination(@RequestBody Map<String, String> searchParamMap) {

		PageableVO pageableVO = mbrService.getMbrPagination(searchParamMap);
		return sendResponse(pageableVO);
	}

	@PostMapping(ReqMappingConstants.MBR_SEARCH_SELECT)
	public ResponseEntity<JSONResponse> mbrSearchSelect(@RequestBody Map<String, String> searchParamMap) {
		EEMMbrMasterVO mbrMasterVO = mbrService.getMemberSearchSelect(searchParamMap);
		return sendResponse(mbrMasterVO);
	}

	@GetMapping(ReqMappingConstants.GET_MBR_COMMENTS)
	public ResponseEntity<JSONResponse> getMbrComments(@PathVariable("mbrId") String memberId) {

		List<EEMMbrCommentVO> mbrCommentsList = mbrCommentsService.getMbrCommentList(memberId);

		return sendResponse(mbrCommentsList);
	}

	@PostMapping(ReqMappingConstants.ADD_MBR_COMMENTS)
	public ResponseEntity<JSONResponse> addMbrComments(@RequestBody EEMMbrCommentVO mbrCommentsVo) {
		JSONResponse jsonResponse = new JSONResponse();
		String response = mbrCommentsService.addMbrComments(mbrCommentsVo);

		if (EEMConstants.SUCCESS.equalsIgnoreCase(response)) {
			List<EEMMbrCommentVO> mbrCommentsList = mbrCommentsService.getMbrCommentListDB(mbrCommentsVo.getMemberId());
			jsonResponse.setMessage(EEMConstants.SUCCESS);
			jsonResponse.setStatus("OK");
			jsonResponse.setData(mbrCommentsList);
		} else {
			jsonResponse.setMessage(EEMConstants.FAILURE);
			jsonResponse.setStatus(response);
			jsonResponse.setData(null);
		}
		return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
	}

	@GetMapping(path = ReqMappingConstants.GET_MBR_TRR)
	public ResponseEntity<JSONResponse> getMbrTRR(@PathVariable("mbrId") String memberId) {

		List<EEMMbrTrrLogVO> mbrTrrList = mbrCommentsService.getMbrTrrList(memberId);

		return sendResponse(mbrTrrList);
	}

	@GetMapping(path = ReqMappingConstants.GET_MBR_TRR_DATA)
	public ResponseEntity<JSONResponse> getMbrTRRData(@PathVariable("mbrId") String memberId,
			@PathVariable("logTime") String logTime) {

		List<EEMMbrTrrDataVO> mbrTrrList = mbrCommentsService.getMbrTrrDataList(memberId, logTime);

		return sendResponse(mbrTrrList);
	}

	@GetMapping(ReqMappingConstants.MBR_INITIAL)
	public ResponseEntity<JSONResponse> getMbrInitailData() {

		MbrCacheVO mbrCacheVO = mbrService.getMbrInitialData();

		return sendResponse(mbrCacheVO);
	}

	private ResponseEntity<JSONResponse> sendResponse(Object object) {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;
		if (null == object) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			jsonResponse.setData(null);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
			jsonResponse.setMessage(EEMConstants.BLANK);
			jsonResponse.setData(object);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}
}
