/**
 * 
 */
package com.medicare.mss.daoImpl;

import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMLepDAO;
import com.medicare.mss.domainobject.EEMLEPMaximusDO;
import com.medicare.mss.domainobject.EEMMbrLepInfoDO;
import com.medicare.mss.domainobject.EMMbrTriggerDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.vo.EEMMbrLepInfoVO;
import com.medicare.mss.vo.EMDatedSegmentVO;

/**
 * @author DU20098149
 *
 */
@Repository
public class EEMLepDAOImpl implements EEMLepDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public EEMLEPMaximusDO getLepMaximusDetails(String customerId, String mbrId) throws ApplicationException {
		EEMLEPMaximusDO eemLEPMaximusDO;

		String query = CommonUtils.buildQuery("SELECT * FROM EM_MBR_MAXIMUS_REC",
				"WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? ORDER BY LAST_UPDT_TIME DESC FETCH FIRST ROW ONLY");

		try {
			eemLEPMaximusDO = jdbcTemplate.queryForObject(query,
					new DomainPropertyRowMapper<EEMLEPMaximusDO>(EEMLEPMaximusDO.class), customerId, mbrId);

			if (!Optional.ofNullable(eemLEPMaximusDO).isPresent()) {
				eemLEPMaximusDO = buildEEMLEPMaximusListWithIsUpdateNo();
			} else {
				eemLEPMaximusDO.setIsUpdate(EEMConstants.VALUE_YES);
			}

		} catch (EmptyResultDataAccessException exp) {
			eemLEPMaximusDO = buildEEMLEPMaximusListWithIsUpdateNo();
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}

		return eemLEPMaximusDO;
	}

	@Override
	public boolean insertOrUpdateLEPMaximus(EEMLEPMaximusDO newDO) throws ApplicationException {
		String message;
		int sqlCnt = 0;
		String param;

		String query = CommonUtils.buildQuery("UPDATE EM_MBR_MAXIMUS_REC SET CASE_FILE_REC_DATE = ? ,",
				"DECISION_REC_DATE = ? , DECISION_TYPE = ? , LAST_UPDT_TIME = CURRENT_TIMESTAMP , LAST_UPDT_USERID = ? ,",
				"TRANSACTION_DUE_DATE = ? , CASE_FILE_NUMBER = ? , CASE_FILE_DUE_DATE = ? ",
				"WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? AND CREATE_TIME = ?");

		if (!StringUtils.equals(EEMConstants.VALUE_YES, newDO.getIsUpdate())) {
			query = CommonUtils.buildQuery("INSERT INTO  EM_MBR_MAXIMUS_REC ( CASE_FILE_REC_DATE ,",
					"DECISION_REC_DATE , DECISION_TYPE , LAST_UPDT_TIME , LAST_UPDT_USERID ,",
					"TRANSACTION_DUE_DATE , CASE_FILE_NUMBER,CASE_FILE_DUE_DATE, CUSTOMER_ID, ",
					"MEMBER_ID,CREATE_USERID, CREATE_TIME ) VALUES (?,?,?,CURRENT_TIMESTAMP,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)");
		}

		if (!StringUtils.equals(EEMConstants.VALUE_YES, newDO.getIsUpdate())) {
			param = newDO.getCreateUserId();
			message = "inserting";
		} else {
			param = newDO.getCreateTime();
			message = "updating";
		}

		try {
			sqlCnt = jdbcTemplate.update(query, newDO.getCaseFileRecDate(), newDO.getDecisionRecDate(),
					newDO.getDecisionType(), newDO.getLastUpdtUserId(), newDO.getTransactionDueDate(),
					newDO.getCaseFileNumber(), newDO.getCaseFileDueDate(), newDO.getCustomerId(), newDO.getMemberId(),
					param);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, String.format(EEMConstants.INSERT_UPDATE_ERROR, message));
		}
		return sqlCnt == 1;
	}

	private EEMLEPMaximusDO buildEEMLEPMaximusListWithIsUpdateNo() {
		EEMLEPMaximusDO eemLEPMaximusDO = new EEMLEPMaximusDO();
		eemLEPMaximusDO.setIsUpdate(EEMConstants.VALUE_NO);

		return eemLEPMaximusDO;
	}

	@Override
	public boolean cancelAnyOpenTriggers(EMMbrTriggerDO eemMbrTrigger) throws ApplicationException {
		int sqlCnt = 0;
		String query = CommonUtils.buildQuery(
				"UPDATE EM_MBR_TRIGGER SET TRIGGER_STATUS = 'CANCELLED', LAST_UPDT_TIME=?, LAST_UPDT_USERID=?",
				"WHERE TRIGGER_STATUS = 'OPEN' AND CUSTOMER_ID = ? AND MEMBER_ID = ? AND TRIGGER_CODE = ?");

		try {
			sqlCnt = jdbcTemplate.update(query, eemMbrTrigger.getLastUpdtTime(), eemMbrTrigger.getLastUpdtUserId(),
					eemMbrTrigger.getCustomerId(), eemMbrTrigger.getMemberId(), eemMbrTrigger.getTriggerCode());
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}

		return sqlCnt == 1;
	}

	@Override
	public List<EEMMbrLepInfoDO> getMbrLepInfos(String customerId, String mbrId, String showAll)
			throws ApplicationException {
		try {
			String sqlOverride = " AND OVERRIDE_IND = 'N'";
			if (EEMConstants.VALUE_YES.equals(showAll)) {
				sqlOverride = EEMConstants.BLANK;
			}
			String query = CommonUtils.buildQuery("SELECT CUSTOMER_ID, MEMBER_ID, EFF_START_DATE, CREATE_TIME,",
					"EFF_END_DATE, OVERRIDE_IND,ATTST_LOCK,",
					"CREDITABLE_COVERAGE_FLAG, NBR_UNCOV_MONTHS, LEP_AMT, LEP_WAIVED_AMT,",
					"CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID,NUMUNCOV_TRANS_REASON,",
					"ATT_STATUS, INC_ATT_RCVE_DATE, UNCOV_MNTH_STRT_DT", "FROM EM_MBR_LEP",
					"WHERE CUSTOMER_ID = ? AND MEMBER_ID = ?", sqlOverride,
					"ORDER BY EFF_START_DATE DESC, EFF_END_DATE DESC");

			return jdbcTemplate.query(query,
					new DomainPropertyRowMapper<EEMMbrLepInfoDO>(EEMMbrLepInfoDO.class), customerId, mbrId);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public int setOverride(EMDatedSegmentVO emDatedSegmentVO, String userId) throws ApplicationException {
		String query = CommonUtils.buildQuery("UPDATE EM_MBR_LEP",
				"SET OVERRIDE_IND = 'Y', LAST_UPDT_TIME = CURRENT_TIMESTAMP, LAST_UPDT_USERID = ?",
				"WHERE CUSTOMER_ID = ? AND MEMBER_ID = ?", "AND EFF_START_DATE = ? AND CREATE_TIME = ?",
				"AND OVERRIDE_IND = 'N' AND LAST_UPDT_TIME = ?");
		EEMMbrLepInfoVO eemMbrLepInfoVO = (EEMMbrLepInfoVO) emDatedSegmentVO;
		try {
			return jdbcTemplate.update(query, userId, eemMbrLepInfoVO.getCustomerId(), eemMbrLepInfoVO.getMemberId(),
					eemMbrLepInfoVO.getEffStartDate(), eemMbrLepInfoVO.getCreateTime(),
					eemMbrLepInfoVO.getLastUpdtTime());
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}
	}

	@Override
	public int insertMbr(EMDatedSegmentVO emDatedSegmentVO) throws ApplicationException {

		EEMMbrLepInfoVO eemMbrLepInfoVO = (EEMMbrLepInfoVO) emDatedSegmentVO;

		if (EEMConstants.VALUE_YES.equalsIgnoreCase(eemMbrLepInfoVO.getEditOverrideInd())) {
			eemMbrLepInfoVO.setEditOverrideInd(EEMConstants.VALUE_YES);
		} else {
			eemMbrLepInfoVO.setEditOverrideInd(EEMConstants.VALUE_NO);
		}

		if (EEMConstants.VALUE_YES.equalsIgnoreCase(eemMbrLepInfoVO.getTrg73Ind())) {
			eemMbrLepInfoVO.setTrg73Ind(EEMConstants.VALUE_YES);
		} else {
			eemMbrLepInfoVO.setTrg73Ind(EEMConstants.VALUE_NO);
		}

		String query = CommonUtils.buildQuery("INSERT INTO EM_MBR_LEP(",
				"CUSTOMER_ID, MEMBER_ID, EFF_START_DATE, CREATE_TIME,", "EFF_END_DATE, OVERRIDE_IND,",
				"CREDITABLE_COVERAGE_FLAG, NBR_UNCOV_MONTHS, LEP_AMT, LEP_WAIVED_AMT,",
				"CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID,NUMUNCOV_TRANS_REASON,ATTST_LOCK, ",
				"ATT_STATUS, INC_ATT_RCVE_DATE,", "CASE_FILE_REC_DATE,CASE_FILE_DUE_DATE,DECISION_REC_DATE,",
				"DECISION_TYPE,TRANSACTION_DUE_DATE,ATT_REC_DATE,ATT_REC_CHANNEL,NOTIFIED_MEMBER_APPEAL,UNCOV_MNTH_STRT_DT) "
						+ " VALUES(",
				"?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?", ")");

		if (eemMbrLepInfoVO.getNbrUncovMonths() == 0) {
			eemMbrLepInfoVO.setCreditableCoverageFlag(EEMConstants.VALUE_YES);
			eemMbrLepInfoVO.setLepAmt("0.00");
		} else {
			eemMbrLepInfoVO.setCreditableCoverageFlag(EEMConstants.VALUE_NO);
		}

		try {
			return jdbcTemplate.update(query, StringUtils.trimToEmpty(eemMbrLepInfoVO.getCustomerId()), // 1
					StringUtils.trimToEmpty(eemMbrLepInfoVO.getMemberId()), // 2
					StringUtils.trimToEmpty(eemMbrLepInfoVO.getEffStartDate()), // 3
					StringUtils.trimToEmpty(eemMbrLepInfoVO.getCreateTime()), // 4
					StringUtils.trimToEmpty(eemMbrLepInfoVO.getEffEndDate()), // 5
					StringUtils.trimToEmpty(eemMbrLepInfoVO.getOverrideInd()), // 6
					StringUtils.trimToEmpty(eemMbrLepInfoVO.getCreditableCoverageFlag()), // 7
					eemMbrLepInfoVO.getNbrUncovMonths(), // 8
					CommonUtils.ensureDouble(eemMbrLepInfoVO.getLepAmt()), // 9
					CommonUtils.ensureDouble(eemMbrLepInfoVO.getLepWaivedAmt()), // 10
					StringUtils.trimToEmpty(eemMbrLepInfoVO.getCreateUserId()), // 11
					StringUtils.trimToEmpty(eemMbrLepInfoVO.getLastUpdtTime()), // 12
					StringUtils.trimToEmpty(eemMbrLepInfoVO.getLastUpdtUserId()), // 13
					StringUtils.trimToEmpty(eemMbrLepInfoVO.getNumUncocTransReason()), // 14
					StringUtils.trimToEmpty(eemMbrLepInfoVO.getAttstLockInd()), // 15

					StringUtils.trimToEmpty(
							isEffEndDateOpenDate(eemMbrLepInfoVO.getEffEndDate()) ? eemMbrLepInfoVO.getAttestStatus()
									: EEMConstants.BLANK), // 16
					StringUtils.trimToEmpty(isEffEndDateOpenDate(eemMbrLepInfoVO.getIncompAttestLetRecDate())
							? eemMbrLepInfoVO.getIncompAttestLetRecDate()
							: EEMConstants.BLANK), // 17
					EEMConstants.BLANK, // 18
					EEMConstants.BLANK, // 19
					EEMConstants.BLANK, // 20
					EEMConstants.BLANK, // 21
					EEMConstants.BLANK, // 22

					StringUtils.trimToEmpty(isEffEndDateOpenDate(eemMbrLepInfoVO.getAttestationRecDate())
							? eemMbrLepInfoVO.getAttestationRecDate()
							: EEMConstants.BLANK), // 23
					StringUtils.trimToEmpty(isEffEndDateOpenDate(eemMbrLepInfoVO.getAttestationRecChannel())
							? eemMbrLepInfoVO.getAttestationRecChannel()
							: EEMConstants.BLANK), // 24
					StringUtils.trimToEmpty(isEffEndDateOpenDate(eemMbrLepInfoVO.getNotifiedMemberAppeal())
							? eemMbrLepInfoVO.getNotifiedMemberAppeal()
							: EEMConstants.BLANK), // 25
					StringUtils.trimToEmpty(Objects.isNull(eemMbrLepInfoVO.getEnrollEffStartDate())
							? eemMbrLepInfoVO.getTempEnrollEffStartDate()
							: eemMbrLepInfoVO.getEnrollEffStartDate())// 26
			);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_INSERT);
		}

	}

	private boolean isEffEndDateOpenDate(String effEndDate) {
		return EEMConstants.EFF_END_DATE.equalsIgnoreCase(effEndDate);
	}

	@Override
	public byte[] displayDocumentFromDB(Map<String, String> searchParamMap) {
		String customerId = trimToEmpty(searchParamMap.get("customerId"));
		String primaryId = trimToEmpty(searchParamMap.get("primaryId"));
		String letterName = trimToEmpty(searchParamMap.get("letterName"));
		String letterUploadedTime = trimToEmpty(searchParamMap.get("letterUploadedTime"));

		byte[] blobByte = null;
		java.sql.Blob blob = null;
		try {

			StringBuilder sQuery = CommonUtils.buildQueryBuilder("SELECT LETTER_PDF FROM EM_CORR_DMS ",
					"WHERE CUSTOMER_ID = ? AND PRIMARY_ID = ? AND CUSTOMER_LETTER_NAME = ? AND ",
					"LETTER_CREATION_TIME = ?  FETCH FIRST ROW ONLY");

			blob = jdbcTemplate.queryForObject(sQuery.toString(),
					new Object[] { customerId, primaryId, letterName, letterUploadedTime },
					java.sql.Blob.class);

			blobByte = blob.getBytes(1, (int) blob.length());

		} catch (EmptyResultDataAccessException exp) {
			throw new ApplicationException(exp, "PDF file is not available");
		} catch (SQLException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
		return blobByte;
	}

}
