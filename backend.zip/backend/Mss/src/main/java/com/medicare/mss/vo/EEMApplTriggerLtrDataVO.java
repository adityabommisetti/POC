package com.medicare.mss.vo;

import java.io.Serializable;

import lombok.Data;

@Data
public class EEMApplTriggerLtrDataVO implements Serializable {

	private static final long serialVersionUID = 4490111443325026482L;

	private String customerId;
	private int applicationId;
	private String triggerType;
	private String effectiveDate;
	private String createTime;
	private int variableSeqNbr;
	private int continueSeqNbr;
	private String variableId;
	private String variableData;
	private String lastUpdtTime;
	private String lastUpdtUserId;
	
}
