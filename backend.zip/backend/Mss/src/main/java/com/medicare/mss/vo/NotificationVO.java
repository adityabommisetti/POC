package com.medicare.mss.vo;

import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
public class NotificationVO {

	private String msgTitle;
	private String msgDesc;
	private String notifTimeStamp;

	public String getNotifTimeStamp() {
		return DateFormatter.reFormat(notifTimeStamp, DateFormatter.DB2_TIMESTAMP, DateFormatter.MM_DD_YYYY_HH_MM_SS)
				.replace("-", "/");
	}

	public void setNotifTimeStamp(String notifTime) {
		this.notifTimeStamp = notifTime;
	}

}
