package com.medicare.mss.vo;

import java.util.List;

import lombok.Data;

@Data
public class EEMBilPaymentEntryMasterVO {

	private List<EEMBilPaymentEntryVO> billingPaymentslist;
	private List<EEMBilPaymentEntryDtlsVO> billingPaymentDtlsList;
	private boolean nextPage;
	

}
