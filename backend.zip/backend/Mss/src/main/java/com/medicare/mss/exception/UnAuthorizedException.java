package com.medicare.mss.exception;

public class UnAuthorizedException extends ApplicationException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8174891524421982209L;

	public UnAuthorizedException() {
		super();
	}

	public UnAuthorizedException(String message) {
		super(message);
	}

	public UnAuthorizedException(String message, Throwable cause) {
		super(message);
	}

	public UnAuthorizedException(Throwable cause) {
		super(cause);
	}
}
