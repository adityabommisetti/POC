/**
 * 
 */
package com.medicare.mss.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.mss.caching.EEMPersistence;

/**
 * @author DU20098149
 *
 */
@Service
public class EEMCacheService {
	
	@Autowired
	private EEMPersistence eemPersistence;

	public String removeCache() {
		return eemPersistence.removeCache();
	}

}
