package com.medicare.mss.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode(callSuper = false)
public class EmMbrPosInfoVO extends BaseVO implements EMDatedSegmentVO, Cloneable, Serializable {

	private static final long serialVersionUID = -674640238685287989L;

	private String memberId;
	private String notificateDate;
	private String statusFlag;
	private String drugEditStatus;
	private String drugEditClass;
	private String implDate;
	private String txnStatus;
	private String drugCode;
	private String terminationDate;
	private String overrideInd;
	private String groupId;
	private String productId;
	private String planId;
	private String pbpId;
	private String planDesignation;
	private String posEditOrDeleteOrModifyStatus;
	private String posCurrDate;
	private String ccmDate;
	private String enrollStartDate;
	private String enrollEndDate;
	private String notificateEndDate;
	private String implementationEndDate;
	private String prescriberLtStatus;
	private String pharamacyLtStatus;
	private String message;

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	@Override
	public String getType() {
		return "";
	}

	public String getCreateTimeFrmt() {
		return DateFormatter.reFormat(createTime, DateFormatter.DB2_TIMESTAMP, DateFormatter.MM_DD_YYYY_HH_MM_SS);
	}

	public String getLastUpdtTimeFrmt() {
		return DateFormatter.reFormat(lastUpdtTime, DateFormatter.DB2_TIMESTAMP, DateFormatter.MM_DD_YYYY_HH_MM_SS);
	}

	@Override
	public boolean isForSamePeriod(Object chkVO) {
		return false;
	}

	@Override
	public boolean isEndDateChange(Object chkVO) {
		return false;
	}

	@Override
	public boolean isSame(Object obj) {
		EmMbrPosInfoVO chkVO = (EmMbrPosInfoVO) obj;
		if (chkVO.getCustomerId().equals(this.customerId))
			if (chkVO.getMemberId().equals(this.memberId))
				if (chkVO.getOverrideInd().equals(this.overrideInd))
					if (chkVO.getNotificateDate().equals(this.notificateDate))
						if (chkVO.getStatusFlag().equals(this.statusFlag))
							if (chkVO.getDrugEditStatus().equals(this.drugEditStatus))
								if (chkVO.getDrugEditClass().equals(this.drugEditClass))
									if (chkVO.getImplDate().equals(this.implDate))
										if (chkVO.getTxnStatus().equals(this.txnStatus))
											if (chkVO.getDrugCode().equals(this.drugCode))
												if (chkVO.getTerminationDate().equals(this.terminationDate))
													if (chkVO.getCreateTime().equals(this.createTime))
														if (chkVO.getCreateUserId().equals(this.createUserId))
															if (chkVO.getLastUpdtTime().equals(this.lastUpdtTime))
																if (chkVO.getLastUpdtUserId()
																		.equals(this.lastUpdtUserId))
																	return true;
		return false;
	}

	public String getImplDateFrmt() {
		return DateFormatter.reFormat(implDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setImplDateFrmt(String implDate) {
		this.implDate = DateFormatter.reFormat(implDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getNotificateDateFrmt() {
		return DateFormatter.reFormat(notificateDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setNotificateDateFrmt(String notificateDate) {
		this.notificateDate = DateFormatter.reFormat(notificateDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getTerminationDateFrmt() {
		return DateFormatter.reFormat(terminationDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setTerminationDateFrmt(String terminationDate) {
		this.terminationDate = DateFormatter.reFormat(terminationDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
	}

	public String getNotificateEndDateFrmt() {
		return DateFormatter.reFormat(notificateEndDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setNotificateEndDateFrmt(String notificateEndDate) {
		this.notificateEndDate = DateFormatter.reFormat(notificateEndDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
	}

	public String getImplementationEndDateFrmt() {
		return DateFormatter.reFormat(implementationEndDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setImplementationEndDateFrmt(String implementationEndDate) {
		this.implementationEndDate = DateFormatter.reFormat(implementationEndDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
	}

	@Override
	public String getEffEndDate() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getEffStartDate() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setEffEndDate(String effEndDate) {
		// TODO Auto-generated method stub

	}

	@Override
	public void setEffStartDate(String effStartDate) {
		// TODO Auto-generated method stub

	}

}
