package com.medicare.mss.dao;

import java.util.List;
import java.util.Map;

import com.medicare.mss.domainobject.EEMMbrDemographicDO;
import com.medicare.mss.domainobject.EEMMbrEnrollmentDO;
import com.medicare.mss.domainobject.EEMMbrSnapshotDO;
import com.medicare.mss.domainobject.EMMbrTriggerDO;
import com.medicare.mss.vo.PageableVO;

public interface EEMMbrDAO {

	int insertMbrTrigger(EMMbrTriggerDO trig);

	public EEMMbrDemographicDO getMbrDemographicForEffMth(String customerId, String memberId, String cmsEffMonth);

	public List<EEMMbrEnrollmentDO> getMbrEnrollments(String customerId, String memberId, String showAll);

	int setDemographicOverride(EEMMbrDemographicDO oldDemoDO, String userId);

	int insertMbrDemographic(EEMMbrDemographicDO newDemoDO);

	boolean checkMbrTrigger(EMMbrTriggerDO trig);

	String checkMbrTrigger(String customerId, String memberId, String triggerType, String triggerCode);

	PageableVO getMbrSearchDetails(String customerId, Map<String, String> searchParamMap, boolean isPagination);

	EEMMbrSnapshotDO mbrSnapshot(String customerId, String memberId);

	String getMaxLastUpdate(String customerId, String memberId, String table, Map<String, String> type);

	String getLepPlatinoFlag(String customerId, String memberId);

}
