package com.medicare.mss.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.service.EEMMbrOOAService;
import com.medicare.mss.vo.EEMMbrOoaInfoVO;
@RestController
@RequestMapping("/mbr")
public class EEMMbrOOAController {
	
	@Autowired
	private EEMMbrOOAService ooaService;
	
	@GetMapping(path = ReqMappingConstants.MBR_OOA_SEARCH)
	public ResponseEntity<JSONResponse> getMbrOoa(@PathVariable(name = "mbrId") String memberId,
			@PathVariable(name = "showAll") String showAll) throws ApplicationException {
		List<EEMMbrOoaInfoVO> mbrOoaInfoList = ooaService.getListFromContext(memberId, showAll);
		
		if (CollectionUtils.isEmpty(mbrOoaInfoList)) {
			return buildFailureResponse("NO RECORDS AVAILABILE");
		}
		 else {
			return buildSuccessResponse(mbrOoaInfoList);
		 }
	}
	
	@PostMapping(path = ReqMappingConstants.MBR_OOA_UPDATE)
	public ResponseEntity<JSONResponse> updateMbrOoa(@RequestBody EEMMbrOoaInfoVO mbrOoaInfoVO) throws ApplicationException, ParseException {
		
		Map<String, Object> resultMap = ooaService.updateOoa(mbrOoaInfoVO);		
		return buildSuccessResponse(resultMap);
		
	}

	private ResponseEntity<JSONResponse> buildFailureResponse(String message) {
		JSONResponse jsonResponse = new JSONResponse();
		jsonResponse.setStatus(HttpStatus.NO_CONTENT.getReasonPhrase());
		jsonResponse.setMessage(message);	
		jsonResponse.setData(new ArrayList<>());
		return new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
	}
	
	private ResponseEntity<JSONResponse> buildSuccessResponse( Object responseData) {
		JSONResponse jsonResponse = new JSONResponse();
		jsonResponse.setMessage(EEMConstants.SUCCESS);
		jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
		jsonResponse.setData(responseData);
		return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
	}

}
