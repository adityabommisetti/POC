package com.medicare.mss.daoImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMMbrPCPDAO;
import com.medicare.mss.domainobject.EMMbrPCPInfoDO;
import com.medicare.mss.domainobject.EMPcpSearchDO;
import com.medicare.mss.domainobject.EmMbrErrorDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EMDatedSegmentVO;
import com.medicare.mss.vo.EMMbrPCPInfoVO;

@Repository
public class EEMMbrPCPDAOImpl implements EEMMbrPCPDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;


	@Override
	public List<EMMbrPCPInfoDO> searchPcp(EMPcpSearchDO eMPcpSearchDO, String lineOfBusiness) {
		try {
			List<String> params = new ArrayList<>();

			StringBuilder sQuery = new StringBuilder(
					"SELECT DISTINCT OFFICE_CD, LOCATION_ID, CLINIC_NAME, DOCTOR_NAME,")
							.append(" LINE_OF_BIZ, DOCTOR_ADDRESS, DOCTOR_CITY, DOCTOR_STATE, DOCTOR_ZIP_CD,")
							.append(" ACCEPT_NEW_PATIENT_IND, OFFICE_START_DATE, ALTERNATE_OFFICE_CD")
							.append(" FROM EM_MED_OFFICE")
							.append(" WHERE CUSTOMER_ID = ? AND OFFICE_CATEGORY_CD = 'PCP'")
							.append(" AND ? BETWEEN OFFICE_START_DATE AND OFFICE_END_DATE");
							

			params.add(eMPcpSearchDO.getCustomerId());
			params.add(eMPcpSearchDO.getEffDate());
			
			if (!StringUtil.nonNullTrim(lineOfBusiness).equals("")) {
				sQuery.append(" AND LINE_OF_BIZ IN ('', ?) ");
				params.add(StringUtil.nonNullTrim(lineOfBusiness));
			} 

			if (!StringUtil.nonNullTrim(eMPcpSearchDO.getPcpNbr()).equals("")) {
				sQuery.append(" AND OFFICE_CD = ? ");
				params.add(StringUtil.nonNullTrim(eMPcpSearchDO.getPcpNbr()));
			}
			if (!StringUtil.nonNullTrim(eMPcpSearchDO.getLocationId()).equals("")) {
				sQuery.append(" AND LOCATION_ID = ? ");
				params.add(StringUtil.nonNullTrim(eMPcpSearchDO.getLocationId()));
			}
			if (!StringUtil.nonNullTrim(eMPcpSearchDO.getDoctorName()).equals("")) {
				sQuery.append(" AND DOCTOR_NAME LIKE ? ");
				params.add(StringUtil.appendWildCardCharacter(eMPcpSearchDO.getDoctorName(), true, true));
			}
			if (StringUtil.nonNullTrim(eMPcpSearchDO.getAcceptNewPatient()).equals("Y")) {
				sQuery.append(" AND ACCEPT_NEW_PATIENT_IND = 'Y' ");
			}
			if (!StringUtil.nonNullTrim(eMPcpSearchDO.getPcpNpi()).equals("")) {
				sQuery.append(" AND ALTERNATE_OFFICE_CD = ? ");
				params.add(StringUtil.nonNullTrim(eMPcpSearchDO.getPcpNpi()));
			}
			sQuery.append(" ORDER BY OFFICE_CD, OFFICE_START_DATE DESC");

			Object[] objPrams = params.toArray();
			
			return jdbcTemplate.query(sQuery.toString(),
					new DomainPropertyRowMapper<EMMbrPCPInfoDO>(EMMbrPCPInfoDO.class), objPrams);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public List<EMMbrPCPInfoDO> getMbrPCPSelect(String customerId, String memberId, String showAll,
			String lineOfBusiness) {

		String sqlOverride = "AND PCP.OVERRIDE_IND = 'N'";
		if ("Y".equals(showAll)) {
			sqlOverride = "";
		}
		String query = CommonUtils.buildQuery(
				"SELECT DISTINCT PCP.CUSTOMER_ID, PCP.MEMBER_ID, PCP.PCP_NBR, PCP.LOCATION_ID,",
				"PCP.EFF_START_DATE, PCP.CREATE_TIME, PCP.EFF_END_DATE,", "PCP.OVERRIDE_IND, PCP.CURRENT_PATIENT_IND,",
				"PCP.CREATE_USERID, PCP.LAST_UPDT_TIME, PCP.LAST_UPDT_USERID,",
				"MO.CLINIC_NAME, MO.DOCTOR_NAME, PCP.LINE_OF_BIZ,",
				"MO.DOCTOR_ADDRESS, MO.DOCTOR_CITY, MO.DOCTOR_STATE, MO.DOCTOR_ZIP_CD,",
				"MO.ACCEPT_NEW_PATIENT_IND, MO.ALTERNATE_OFFICE_CD FROM EM_MBR_PCP PCP LEFT OUTER JOIN EM_MED_OFFICE MO",
				"ON MO.CUSTOMER_ID = PCP.CUSTOMER_ID  AND MO.OFFICE_CD = PCP.PCP_NBR",
				"AND MO.LINE_OF_BIZ = PCP.LINE_OF_BIZ AND MO.LOCATION_ID = PCP.LOCATION_ID  AND MO.OFFICE_CATEGORY_CD = 'PCP'",
				"AND PCP.EFF_END_DATE BETWEEN MO.OFFICE_START_DATE AND MO.OFFICE_END_DATE",
				"WHERE PCP.CUSTOMER_ID = ? AND PCP.MEMBER_ID = ?", sqlOverride,
				"AND PCP.LINE_OF_BIZ IN ('', ?) ORDER BY EFF_START_DATE DESC, EFF_END_DATE DESC");

		try {
			return jdbcTemplate.query(query, new DomainPropertyRowMapper<EMMbrPCPInfoDO>(EMMbrPCPInfoDO.class),
					customerId, memberId, lineOfBusiness);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public int setPcpInfoOverride(EMMbrPCPInfoDO delPCPDO, String userId) {

		String lastUpdtUserId = userId;

		String customerId = delPCPDO.getCustomerId();
		String memberId = delPCPDO.getMemberId();
		String pcpNbr = delPCPDO.getPcpNbr();
		String locationId = delPCPDO.getLocationId();
		String effStartDate = delPCPDO.getEffStartDate();
		String createTime = delPCPDO.getCreateTime();
		String lastUpdtTime = delPCPDO.getLastUpdtTime();

		String ts = DateUtil.getCurrentDatetimeStamp();
		
		Object[] parms = new Object[] {ts, lastUpdtUserId, customerId, memberId, pcpNbr, locationId, effStartDate,
				createTime, lastUpdtTime};
		try {
			String query = CommonUtils.buildQuery(
					"UPDATE EM_MBR_PCP SET OVERRIDE_IND = 'Y', LAST_UPDT_TIME = ?",
					" , LAST_UPDT_USERID = ? WHERE CUSTOMER_ID = ? AND MEMBER_ID = ?",
					" AND PCP_NBR = ? AND LOCATION_ID = ? AND EFF_START_DATE = ? AND CREATE_TIME = ?",
					" AND OVERRIDE_IND = 'N' AND LAST_UPDT_TIME = ?");

			return jdbcTemplate.update(query, parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "UPDATE_ERROR");
		}
	}

	@Override
	public void getMedOffice(String customerId, String pcpNbr, String effStartDate, String lineOfBusiness, String lobValid, String pcpLineOfBusiness) {

		List<String> params = new ArrayList<>();
		
		StringBuilder sQuery = new StringBuilder("SELECT OFFICE_CD, CLINIC_NAME, DOCTOR_NAME,")
				.append("DOCTOR_ADDRESS, DOCTOR_CITY, DOCTOR_STATE, DOCTOR_ZIP_CD, ")
				.append("ACCEPT_NEW_PATIENT_IND, LINE_OF_BIZ FROM EM_MED_OFFICE ")
				.append(" WHERE CUSTOMER_ID = ? AND OFFICE_CD = ? AND OFFICE_CATEGORY_CD = 'PCP' ")
				.append(" AND ? BETWEEN OFFICE_START_DATE AND OFFICE_END_DATE ");
		
		params.add(customerId);
		params.add(pcpNbr);
		params.add(effStartDate);
		
		if ("Y".equalsIgnoreCase(lobValid) && !pcpLineOfBusiness.isEmpty()) {
			sQuery.append(" AND LINE_OF_BIZ = ? ");
			params.add(StringUtil.nonNullTrim(lineOfBusiness));
			}
		sQuery.append(" ORDER BY OFFICE_START_DATE DESC FETCH FIRST 1 ROWS ONLY ");
		Object[] objPrams = params.toArray();
		try {
			List<EMMbrPCPInfoDO> mbrPCPInfoDO = jdbcTemplate.query(sQuery.toString(),
					new DomainPropertyRowMapper<EMMbrPCPInfoDO>(EMMbrPCPInfoDO.class), objPrams);

			if (mbrPCPInfoDO.isEmpty()) {
				throw new ApplicationException("Please validate the PCP");
			} 
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public boolean checkProviderDates(EMMbrPCPInfoDO pcpDO) {

		String pcpNbr = StringUtil.nonNullTrim(pcpDO.getPcpNbr());
		String locationId = StringUtil.nonNullTrim(pcpDO.getLocationId());
		String customerId = StringUtil.nonNullTrim(pcpDO.getCustomerId());
		String effStartDate = StringUtil.nonNullTrim(pcpDO.getEffStartDate());

		try {
			StringBuilder sQuery = new StringBuilder("SELECT OFFICE_CD FROM EM_MED_OFFICE ")
					.append(" WHERE OFFICE_CD = ? AND OFFICE_CATEGORY_CD = 'PCP' AND LOCATION_ID = ?")
					.append(" AND CUSTOMER_ID = ? AND ? BETWEEN OFFICE_START_DATE AND OFFICE_END_DATE ")
					.append(" ORDER BY OFFICE_START_DATE DESC FETCH FIRST ROW ONLY");

			jdbcTemplate.queryForObject(sQuery.toString(),
					new Object[] { pcpNbr, locationId, customerId, effStartDate }, String.class);
			return true;
			
		} catch (EmptyResultDataAccessException exp) {
			return false;
		}
		catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
		
		

	}

	@Override
	public String getCurrentPatientIndicator(EMMbrPCPInfoDO pcpDO) {
		String acceptNewPatient = "N";

		String acceptNewPatientInd = "";
		try {
			StringBuilder sQuery = new StringBuilder("SELECT ACCEPT_NEW_PATIENT_IND FROM EM_MED_OFFICE ")
					.append(" WHERE OFFICE_CD = ? AND OFFICE_CATEGORY_CD = 'PCP' AND LOCATION_ID = ? AND CUSTOMER_ID = ?")
					.append(" ORDER BY OFFICE_START_DATE DESC  FETCH FIRST ROW ONLY ");

			acceptNewPatientInd = jdbcTemplate.queryForObject(sQuery.toString(),
					new Object[] { StringUtil.nonNullTrim(pcpDO.getPcpNbr()),
							StringUtil.nonNullTrim(pcpDO.getLocationId()),
							StringUtil.nonNullTrim(pcpDO.getCustomerId()) },
					String.class);
			return acceptNewPatientInd;
			
		} catch (EmptyResultDataAccessException exp) {
			return acceptNewPatient;
		}
		catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
		

	}

	@Override
	public boolean checkProvider(EMMbrPCPInfoDO pcpDO) {


		String pcpNbr = StringUtil.nonNullTrim(pcpDO.getPcpNbr());
		String customerId = StringUtil.nonNullTrim(pcpDO.getCustomerId());
		String effStartDate = StringUtil.nonNullTrim(pcpDO.getEffStartDate());
		try {

			StringBuilder sQuery = new StringBuilder("SELECT OFFICE_CD FROM EM_MED_OFFICE ")
					.append(" WHERE OFFICE_CD = ? AND OFFICE_CATEGORY_CD = 'PCP' ")
					.append(" AND CUSTOMER_ID = ? AND ? BETWEEN OFFICE_START_DATE AND OFFICE_END_DATE ")
					.append(" ORDER BY OFFICE_START_DATE DESC FETCH FIRST ROW ONLY");

			jdbcTemplate.queryForObject(sQuery.toString(), new Object[] { pcpNbr, customerId, effStartDate },
					String.class);
			return true;
		} catch (EmptyResultDataAccessException exp) {
			return false;
		}
		catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
		

	}

	@Override
	public List<EmMbrErrorDO> getMemberErrors(String customerId, String memberId, String fieldNbr) {
		try {

			StringBuilder sQuery = new StringBuilder("SELECT E.CUSTOMER_ID, E.MEMBER_ID, E.ERROR_SEQ_NBR,")
					.append(" E.ERROR_CD, M.ERROR_MESSAGE, E.FIELD_NBR, E.ERROR_DATA, E.ERROR_STATUS, E.RFI_IND,")
					.append(" E.LAST_UPDT_TIME, E.LAST_UPDT_USERID FROM EM_MBR_ERROR E")
					.append(" LEFT OUTER JOIN EM_ERROR_MESSAGE M ON M.ERROR_CD = E.ERROR_CD")
					.append(" WHERE E.CUSTOMER_ID = ? AND E.MEMBER_ID = ? AND E.FIELD_NBR = ?")
					.append(" ORDER BY E.ERROR_SEQ_NBR DESC");

			return jdbcTemplate.query(sQuery.toString(),
					new DomainPropertyRowMapper<EmMbrErrorDO>(EmMbrErrorDO.class), customerId, memberId, fieldNbr);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}

	}

	@Override
	public int updateErrorDetails(EmMbrErrorDO objDO, String requestScrn) {

		Object[] parms = new Object[] {StringUtil.nonNullTrim(objDO.getErrorData()),
				StringUtil.nonNullTrim(objDO.getErrorStatus()), StringUtil.nonNullTrim(objDO.getRfiInd()),
				StringUtil.nonNullTrim(objDO.getLastUpdtTime()), StringUtil.nonNullTrim(objDO.getLastUpdtUserId()),
				StringUtil.nonNullTrim(objDO.getCustomerId()), StringUtil.nonNullTrim(objDO.getMemberId()),
				StringUtil.nonNullTrim(objDO.getFieldNbr()), StringUtil.nonNullTrim(objDO.getErrorCd()),
				StringUtil.nonNullTrim(objDO.getErrorData())};
		try {
			String query = CommonUtils.buildQuery(
					"UPDATE EM_MBR_ERROR SET ERROR_DATA=?, ERROR_STATUS=?, ",
					" RFI_IND=?, LAST_UPDT_TIME=?, LAST_UPDT_USERID=? ",
					" WHERE CUSTOMER_ID=? AND MEMBER_ID=? AND FIELD_NBR=? ",
					" AND ERROR_CD=? AND ERROR_STATUS != 'CLOSED' AND ERROR_DATA=?");


			return jdbcTemplate.update(query, parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "UPDATE_ERROR");
		}
	}

	@Override
	public int insertErrorDetails(EmMbrErrorDO objDO) {

		Object[] parms = new Object[] {StringUtil.nonNullTrim(objDO.getCustomerId()),
				StringUtil.nonNullTrim(objDO.getMemberId()), getErrorSeqNo(objDO),
				StringUtil.nonNullTrim(objDO.getErrorCd()), StringUtil.nonNullTrim(objDO.getFieldNbr()),
				StringUtil.nonNullTrim(objDO.getErrorData()), StringUtil.nonNullTrim(objDO.getErrorStatus()),
				StringUtil.nonNullTrim(objDO.getRfiInd()), StringUtil.nonNullTrim(objDO.getLastUpdtTime()),
				StringUtil.nonNullTrim(objDO.getLastUpdtUserId())};
		
		String query = CommonUtils.buildQuery(
				"INSERT INTO EM_MBR_ERROR (CUSTOMER_ID, MEMBER_ID, ",
				" ERROR_SEQ_NBR, ERROR_CD, FIELD_NBR, ERROR_DATA, ERROR_STATUS, ",
				" RFI_IND, LAST_UPDT_TIME, LAST_UPDT_USERID, CREATE_TIME) ",
				" VALUES (?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)");
		try {
			return jdbcTemplate.update(query, parms);

			
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "INSERT_ERROR");
		}
	}

	public String getErrorSeqNo(EmMbrErrorDO objDO) {
		String seqNo = "1";
		try {
			String sQuery = "SELECT MAX(ERROR_SEQ_NBR) AS SEQ_NBR FROM EM_MBR_ERROR WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? ";

			seqNo = StringUtil.nonNullTrim(jdbcTemplate.queryForObject(sQuery,
					new Object[] { objDO.getCustomerId(), objDO.getMemberId() }, String.class));

			if (!StringUtil.nonNullTrim(seqNo).isEmpty()) {
				seqNo = "" + (Integer.parseInt(seqNo) + 1);
			}
			return seqNo;
		} catch (EmptyResultDataAccessException exp) {
			return seqNo;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
		
	}


	@Override
	public int insertMbrPcpInfo(EMMbrPCPInfoDO mbrPcpInfo) {

		if (StringUtil.nonNullTrim(mbrPcpInfo.getOverrideInd()).equals("")) {
			mbrPcpInfo.setOverrideInd("N");
		}

		Object[] parms = new Object[]{mbrPcpInfo.getCustomerId(), mbrPcpInfo.getMemberId(),
			mbrPcpInfo.getPcpNbr(), mbrPcpInfo.getLocationId(), mbrPcpInfo.getEffStartDate(),
			mbrPcpInfo.getCreateTime(), mbrPcpInfo.getEffEndDate(), mbrPcpInfo.getOverrideInd(),
			mbrPcpInfo.getCurrentPatientInd(), mbrPcpInfo.getCreateUserId(), mbrPcpInfo.getLastUpdtTime(),
			mbrPcpInfo.getLastUpdtUserId(), StringUtil.nonNullTrim(mbrPcpInfo.getLineOfBusiness()),
			mbrPcpInfo.getDoctorName()};
		
		try {
			String query = CommonUtils.buildQuery(
					"INSERT INTO EM_MBR_PCP(",
					" CUSTOMER_ID, MEMBER_ID, PCP_NBR, LOCATION_ID, EFF_START_DATE, CREATE_TIME,",
					" EFF_END_DATE, OVERRIDE_IND, CURRENT_PATIENT_IND,",
					" CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID, LINE_OF_BIZ, PCP_NAME ) VALUES(",
					"?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

			return jdbcTemplate.update(query, parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "INSERT_ERROR");
		}
	}

	@Override
	public int setOverride(EMDatedSegmentVO emDatedSegmentVO, String userId) {
		EMMbrPCPInfoVO tempVO = (EMMbrPCPInfoVO) emDatedSegmentVO;

		EMMbrPCPInfoDO tempDO = new EMMbrPCPInfoDO();
		BeanUtils.copyProperties(tempVO, tempDO);
		return setPcpInfoOverride(tempDO, userId);
	}

	@Override
	public int insertMbr(EMDatedSegmentVO emDatedSegmentVO) {
		EMMbrPCPInfoVO insVO = (EMMbrPCPInfoVO) emDatedSegmentVO;

		EMMbrPCPInfoDO newEMMbrPCPInfoDO = new EMMbrPCPInfoDO();
		BeanUtils.copyProperties(insVO, newEMMbrPCPInfoDO);
		return insertMbrPcpInfo(newEMMbrPCPInfoDO);
	}

}
