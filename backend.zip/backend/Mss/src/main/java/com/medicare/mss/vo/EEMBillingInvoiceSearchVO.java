/**
 * 
 */
package com.medicare.mss.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

/**
 * @author DU20098149
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EEMBillingInvoiceSearchVO {

	private String searchLastName;
	private String searchMemberId;
	private String searchInvoiceNbr;
	private String searchMedicareId;
	private String searchInvoiceGroup;
	private String searchInvoiceType;
	private String searchSupplementalId;
	private String searchInvoiceStatus;
	private String dueDate;
	private String searchInvoiceId;

}
