package com.medicare.mss.domainobject;

import java.io.Serializable;

import com.medicare.mss.annotation.ColumnMapper;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.vo.EMDatedSegmentVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class EEMMbrLisInfoDO extends BaseDO implements EMDatedSegmentVO, Cloneable ,Serializable{

	private static final long serialVersionUID = -1324752784018998339L;
	
	@ColumnMapper(columnName = "EFF_END_DATE", propertyName = "effEndDate")
	private String effEndDate;
	
	@ColumnMapper(columnName = "EFF_START_DATE", propertyName = "effStartDate")
	private String effStartDate;
	
	@ColumnMapper(columnName = "LIC_BAE_IND", propertyName = "licBaeInd")
	private String licBaeInd;
	
	@ColumnMapper(columnName = "LI_COPAY_CD", propertyName = "liCoPayCd")
	private String liCoPayCd;
	
	
	private String liCoPayDesc;
	
	@ColumnMapper(columnName = "LIS_AMT", propertyName = "lisAmt")
	private String lisAmt;
	
	@ColumnMapper(columnName = "LIS_BAE_IND", propertyName = "lisBaeInd")
	private String lisBaeInd;
	
	@ColumnMapper(columnName = "LIS_PCT_CD", propertyName = "lisPctCd")
	private String lisPctCd;
	
	@ColumnMapper(columnName = "MEMBER_ID", propertyName = "memberId")
	private String memberId;
	
	@ColumnMapper(columnName = "OVERRIDE_IND", propertyName = "overrideInd")
	private String overrideInd;
	
	@ColumnMapper(columnName = "SPAP_AMT", propertyName = "spapAmt")
	private String spapAmt;
	

	private String subsidySourceDesc;
	
	@ColumnMapper(columnName = "SUBSIDY_SOURCE_IND", propertyName = "subsidySourceInd")
	private String subsidySourceInd;
	
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	
	
	public String getEffEndDateFrmt() {
		return DateFormatter.reFormat(effEndDate,DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
	}
	public String getEffStartDateFrmt() {
		return DateFormatter.reFormat(effStartDate,DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
	}
	@Override
	public String getType() {
		return liCoPayCd + lisPctCd;
	}
	@Override
	public boolean isEndDateChange(Object obj) {

		EEMMbrLisInfoDO chkVO = (EEMMbrLisInfoDO) obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate)
			&& chkVO.getLiCoPayCd().equals(this.liCoPayCd)
				&& chkVO.getLisPctCd().equals(this.lisPctCd)
					&& chkVO.getLisAmt().equals(this.lisAmt)
						&& chkVO.getSpapAmt().equals(this.spapAmt)
							&& chkVO.getMemberId().equals(this.memberId)
								&& chkVO.getCustomerId().equals(this.getCustomerId())
									&& chkVO.getOverrideInd().equals(this.overrideInd))
										return true;
		return false;
	}
	
	
	@Override
	public boolean isForSamePeriod(Object obj) {

		EEMMbrLisInfoDO chkVO = (EEMMbrLisInfoDO) obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate)
			&& chkVO.getEffEndDate().equals(this.effEndDate)
				&& chkVO.getMemberId().equals(this.memberId)
					&& chkVO.getCustomerId().equals(this.getCustomerId())
						&& chkVO.getOverrideInd().equals(this.overrideInd))
							return true;

		return false;
	}

	@Override
	public boolean isSame(Object obj) {

		EEMMbrLisInfoDO chkVO = (EEMMbrLisInfoDO) obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate)
			&& chkVO.getEffEndDate().equals(this.effEndDate)
				&& chkVO.getLiCoPayCd().equals(this.liCoPayCd)
					&& chkVO.getLisPctCd().equals(this.lisPctCd)
						&& chkVO.getLisAmt().equals(this.lisAmt)
							&& chkVO.getSpapAmt().equals(this.spapAmt)
								&& chkVO.getMemberId().equals(this.memberId)
									&& chkVO.getCustomerId().equals(this.getCustomerId())
										&& chkVO.getOverrideInd().equals(this.overrideInd)
											&& chkVO.getCreateTime().equals(this.getCreateTime())
												&& chkVO.getCreateUserId().equals(this.getCreateUserId())
													&& chkVO.getLastUpdtTime().equals(this.getLastUpdtTime())
														&& chkVO.getLastUpdtUserId().equals(this.getLastUpdtUserId()))
															return true;
		return false;
	}

	public void setEffEndDateFrmt(String effEndDate) {
		this.effEndDate = DateFormatter.reFormat(effEndDate,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
	}

	public void setEffStartDateFrmt(String effStartDate) {
		this.effStartDate = DateFormatter.reFormat(effStartDate,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
	}

}
