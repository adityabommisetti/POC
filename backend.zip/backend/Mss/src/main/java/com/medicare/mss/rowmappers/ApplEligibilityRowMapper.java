package com.medicare.mss.rowmappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.medicare.mss.domainobject.EEMApplEligibilityDO;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.StringUtil;

public class ApplEligibilityRowMapper implements RowMapper<EEMApplEligibilityDO> {

	@Override
	public EEMApplEligibilityDO mapRow(ResultSet rs, int rowNum) throws SQLException {
		EEMApplEligibilityDO applEligibilityVO = new EEMApplEligibilityDO();
		applEligibilityVO.setPartAEffDate(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("PRTA_ENTITLE_DATE"))));
		applEligibilityVO.setPartBEffDate(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("PRTB_ENTITLE_DATE"))));
		applEligibilityVO.setPartAEndDate(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("PRTA_ENTITLE_EDATE"))));
		applEligibilityVO.setPartBEndDate(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("PRTB_ENTITLE_EDATE"))));
		applEligibilityVO.setPartDEffDate(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("PRTD_ELIG_SDATE"))));
		applEligibilityVO.setInstStartDt(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("INST_SDATE"))));
		applEligibilityVO.setInstEndDt(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("INST_EDATE"))));
		applEligibilityVO.setEsrdStartDt(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("ESRD_SDATE"))));
		applEligibilityVO.setEsrdEndDt(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("ESRD_EDATE"))));
		applEligibilityVO.setMedicStartDt(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("MEDIC_SDATE"))));
		applEligibilityVO.setMedicEndDt(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("MEDIC_EDATE"))));
		applEligibilityVO.setLastChkedTime(StringUtil.nonNullTrim(rs.getString("LAST_CHECKED_TIME")));
		  //BEQ Short term solution --Start
		applEligibilityVO.setEligOverInd(StringUtil.nonNullTrim(rs.getString("ELIG_OVERRIDE_IND")));
		return applEligibilityVO;
	}

}
