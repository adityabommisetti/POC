package com.medicare.mss.vo;

import java.io.Serializable;

import lombok.Data;

@Data
public class BaseVO implements Serializable {

	private static final long serialVersionUID = 6747619828536834392L;
	protected String createTime;
	protected String createUserId;
	protected String customerId;
	protected String lastUpdtTime;
	protected String lastUpdtUserId;
	protected String showAll;
}