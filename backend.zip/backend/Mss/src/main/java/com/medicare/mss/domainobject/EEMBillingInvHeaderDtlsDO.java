/**
 * 
 */
package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

/**
 * @author DU20098149
 *
 */
@Data
public class EEMBillingInvHeaderDtlsDO {

	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;
	
	@ColumnMapper(columnName = "INVOICE_NBR", propertyName = "invoiceNbr")
	private String invoiceNbr;
	
	@ColumnMapper(columnName = "INVOICE_TYPE", propertyName = "invoiceType")
	private String invoiceType;
	
	@ColumnMapper(columnName = "INVOICE_ID", propertyName = "invoiceId")
	private String invoiceId;
	
	@ColumnMapper(columnName = "LAST_NAME", propertyName = "lastName")
	private String lastName;
	
	@ColumnMapper(columnName = "FIRST_NAME", propertyName = "firstName")
	private String firstName;
	
	@ColumnMapper(columnName = "GROUP_NAME", propertyName = "grpName")
	private String grpName;
	
	@ColumnMapper(columnName = "MBR_GRP_IND", propertyName = "mbrGrpInd")
	private String mbrGrpInd;
	
	@ColumnMapper(columnName = "DUE_DATE", propertyName = "dueDate")
	private String dueDate;
	
	@ColumnMapper(columnName = "GL_PROCESSED_IND", propertyName = "glProcessedInd")
	private String glProcessedInd;
	
	@ColumnMapper(columnName = "BILL_THRU_DATE", propertyName = "billThruDate")
	private String billThruDate;
	
	@ColumnMapper(columnName = "INVOICE_STATUS", propertyName = "invoiceStatus")
	private String invoiceStatus;

	@ColumnMapper(columnName = "MEMBER_CNT", propertyName = "memberCnt")
	private String memberCnt;
	
	@ColumnMapper(columnName = "FREQUENCY_CD", propertyName = "frequencyCd")
	private String frequencyCd;
	
	@ColumnMapper(columnName = "INVOICE_AMT", propertyName = "invoiceAmt")
	private double invoiceAmt;
	
	@ColumnMapper(columnName = "PAYMENT_AMT", propertyName = "paymentAmt")
	private double paymentAmt;
	
	@ColumnMapper(columnName = "ADJUSTMENT_AMT", propertyName = "adjustmentAmt")
	private double adjustmentAmt;
	
	@ColumnMapper(columnName = "LAST_ITEM_NBR", propertyName = "lastItemNbr")
	private String lastItemNbr;
	
	@ColumnMapper(columnName = "WIP_TIME", propertyName = "wipTime")
	private String wipTime;
	
	@ColumnMapper(columnName = "WIP_USERID", propertyName = "wipUserId")
	private String wipUserId;
	
	@ColumnMapper(columnName = "CREATE_TIME", propertyName = "createTime")
	private String createTime;
	
	@ColumnMapper(columnName = "CREATE_USERID", propertyName = "createUserId")
	private String createUserId;
	
	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;
	
	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserId")
	private String lastUpdtUserId;
}
