package com.medicare.mss.daoImpl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.medicare.mss.dao.NotificationsDAO;
import com.medicare.mss.domainobject.NotificationDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.util.CommonUtils;

@Repository
public class NotificationsDAOImpl implements NotificationsDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<NotificationDO> getNotifications(String customerId, String lastNotifTime, String signOffTime) {

		ArrayList<String> parmList = new ArrayList<>();

		StringBuilder sQuery = CommonUtils.buildQueryBuilder("SELECT CUSTOMER_ID,TITLE,DESCRIPTION,CREATE_TIMESTAMP",
				" FROM NOTIFICATIONS WHERE CUSTOMER_ID=? AND CREATE_TIMESTAMP>?");
		parmList.add(customerId);
		if (StringUtils.isNotBlank(lastNotifTime)) {
			parmList.add(lastNotifTime);
		} else {
			parmList.add(signOffTime);
		}

		sQuery.append(" ORDER BY CREATE_TIMESTAMP DESC");

		Object[] parms = parmList.toArray();

		try {
			return jdbcTemplate.query(sQuery.toString(),
					new DomainPropertyRowMapper<NotificationDO>(NotificationDO.class), parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error occured while getNotifications");
		}

	}

	/*
	 * @Override public Boolean userLoggedInStatus(String userId) { String sql =
	 * "SELECT SignedOn_YN FROM SECUSER WHERE USER_ID=?"; String signedOn_YN =
	 * jdbcTemplate.queryForObject(sql, new Object[] { userId }, String.class);
	 * return signedOn_YN.equals("Y"); }
	 */

}
