package com.medicare.mss.dao;

import java.util.List;
import java.util.Map;

import com.medicare.mss.domainobject.EmCorrMbrDO;
import com.medicare.mss.domainobject.EmCorrVarDataDO;

public interface EEMMbrLetterDAO {

	List<EmCorrVarDataDO> getMbrLetterData(Map<String, String> searchParams);

	List<EmCorrMbrDO> getMbrLetterSelect(String customerId, String primaryId);

	byte[] getDisplayDocumentFromDB(Map<String, String> searchParams);
}
