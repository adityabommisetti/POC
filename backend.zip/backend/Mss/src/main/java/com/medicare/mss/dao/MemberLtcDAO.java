package com.medicare.mss.dao;

import java.util.List;

import com.medicare.mss.domainobject.EEMMbrLtcInfoDO;

/**
 * DAO class for member LTC info related DB operations
 * 
 * @author Wipro Ltd.
 *
 */
public interface MemberLtcDAO extends EEMMbrBaseDAO {

	/**
	 * This method retrieves member ltc info
	 * 
	 * @param customerId
	 *            customer id
	 * @param memberId
	 *            member id
	 * @param showAll
	 *            showAll flag
	 * @return list of member LTC domain object @
	 */
	List<EEMMbrLtcInfoDO> getMbrLtcInfos(String customerId, String memberId, String showAll);

	/**
	 * Method to check the LTC Facility Details.
	 * 
	 * @param customerId
	 *            customer Id
	 * @param ltcId
	 *            ltc Id
	 * @param effStartDate
	 *            effective StartDate
	 * @return EEMMbrLtcInfoVO object @
	 */
	List<EEMMbrLtcInfoDO> getLTCFacility(String customerId, String ltcId, String effStartDate);

	/**
	 * Method to check the LTC dates.
	 * 
	 * @param eemMbrLtcInfoDO
	 * @return true if LTC facility is available for provided dates @
	 */
	boolean checkLTCDates(EEMMbrLtcInfoDO eemMbrLtcInfoDO);
}
