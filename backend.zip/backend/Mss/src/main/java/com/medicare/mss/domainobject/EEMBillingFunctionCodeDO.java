/**
 * 
 */
package com.medicare.mss.domainobject;

import java.io.Serializable;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

/**
 * @author dkumar
 *
 */
@Data
public class EEMBillingFunctionCodeDO implements Serializable {
	
	private static final long serialVersionUID = -5543133025596768803L;

	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;
	
	@ColumnMapper(columnName = "FUNCTION_CD", propertyName = "functionCd")
	private String functionCd;
	
	@ColumnMapper(columnName = "SHORT_DESC", propertyName = "shortDesc")
	private String shortDesc;
	
	@ColumnMapper(columnName = "LONG_DESC", propertyName = "longDesc")
	private String longDesc;
	
	@ColumnMapper(columnName = "USER_SYSTEM_IND", propertyName = "userSystemInd")
	private String userSystemInd;
	
	@ColumnMapper(columnName = "MODIFY_IND", propertyName = "modifyInd")
	private String modifyInd;
	
	@ColumnMapper(columnName = "ACTIVE_IND", propertyName = "activeInd")
	private String activeInd;
	
	@ColumnMapper(columnName = "ADMIN_SECURITY_IND", propertyName = "adminSecurityInd")
	private String adminSecurityInd;
	
	@ColumnMapper(columnName = "HDR_DTL_TRAN_IND", propertyName = "hdrDtlTranInd")
	private String hdrDtlTranInd;
	
	@ColumnMapper(columnName = "AMT_SIGN_CD", propertyName = "amtSignCd")
	private String amtSignCd;
	
	@ColumnMapper(columnName = "MBR_GRP_IND", propertyName = "mbrGrpInd")
	private String mbrGrpInd;
	
	@ColumnMapper(columnName = "GL_TRANS_CD", propertyName = "glTransCd")
	private String glTransCd;
	
	@ColumnMapper(columnName = "FUNCTION_TYPE", propertyName = "functionType")
	private String functionType;
	
	@ColumnMapper(columnName = "CREATE_TIME", propertyName = "createTime")
	private String createTime;
	
	@ColumnMapper(columnName = "CREATE_USERID", propertyName = "createUserId")
	private String createUserId;
	
	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;
	
	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserId")
	private String lastUpdtUserId;

}
