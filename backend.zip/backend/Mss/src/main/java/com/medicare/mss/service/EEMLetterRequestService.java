package com.medicare.mss.service;

import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMApplDAO;
import com.medicare.mss.dao.EEMLetterRequestDAO;
import com.medicare.mss.dao.EEMMbrDAO;
import com.medicare.mss.domainobject.EEMApplTriggerDO;
import com.medicare.mss.domainobject.EEMLetterReqDO;
import com.medicare.mss.domainobject.EEMLetterVarDataDO;
import com.medicare.mss.domainobject.EMMbrTriggerDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EEMApplTriggerLtrDataVO;
import com.medicare.mss.vo.EEMLetterReqMasterVO;
import com.medicare.mss.vo.EEMLetterReqVO;
import com.medicare.mss.vo.EEMLetterVarDataVO;
import com.medicare.mss.vo.EEMMbrTriggerLtrDataVO;
import com.medicare.mss.vo.PageableVO;

@Service
@Transactional(rollbackFor = ApplicationException.class)
public class EEMLetterRequestService {

	@Autowired
	CacheService sessionHelper;

	@Autowired
	EEMLetterRequestDAO letterRequestDao;

	@Autowired
	private EEMCodeCache eemCodeCache;

	@Autowired
	EEMMbrDAO emMbrDAO;

	@Autowired
	EEMApplDAO emApplDAO;
	
	@Autowired
	EEMTimersService eemTimersService;

	@SuppressWarnings("unchecked")
	public EEMLetterReqMasterVO getLetterSearchDetails(Map<String, String> searchParamMap, boolean isPagination) {
		
		EEMLetterReqMasterVO letterReqMasterVO = new EEMLetterReqMasterVO();

		String customerId = sessionHelper.getUserInfo().getCustomerId();

		List<EEMLetterReqVO> letterReqVOList = new ArrayList<>();
		try {
			PageableVO letterReqDetails = letterRequestDao.getLetterReqSearchResults(customerId,
					searchParamMap, isPagination);
			if (!CollectionUtils.isEmpty((List<EEMLetterReqDO>) letterReqDetails.getContent())) {
			List<EEMLetterReqDO> letterReqDOList = (List<EEMLetterReqDO>) letterReqDetails.getContent();
			
				for (EEMLetterReqDO letterReqDO : letterReqDOList) {
					EEMLetterReqVO emletterReqVO = new EEMLetterReqVO();

					letterReqDO.setSourceTypeDesc(
							eemCodeCache.getDesc(letterReqDO.getSourceType(), eemCodeCache.getArrSourceTypes()));
					letterReqDO.setTriggerTypeDesc(
							eemCodeCache.getDesc(letterReqDO.getTriggerType(), eemCodeCache.getLstTriggerType()));
					letterReqDO.setTriggerStatusDesc(
							eemCodeCache.getDesc(letterReqDO.getTriggerStatus(), eemCodeCache.getLstTriggerStatus()));
					String type = "";
					String desc = eemCodeCache.getDesc(letterReqDO.getTriggerCode(), eemCodeCache.getLstTriggerCodes(type));
					if (desc != null) {
						letterReqDO.setTriggerCodeDesc(desc);
					} else {
						letterReqDO.setTriggerCodeDesc(letterReqDO.getTriggerCode());
					}
					if (trimToEmpty(letterReqDO.getLetterNameDesc()).isEmpty()) {
						letterReqDO.setLetterNameDesc(letterReqDO.getTriggerCodeDesc());
					}
					BeanUtils.copyProperties(letterReqDO, emletterReqVO);
					letterReqVOList.add(emletterReqVO);
				}
				letterReqMasterVO.setNextPage(letterReqDetails.isNextPage());
			}
			letterReqMasterVO.setLetterReqVOs(letterReqVOList);
		} catch (Exception exp) {
			throw new ApplicationException(exp);
		}
		return letterReqMasterVO;
	}

	public EEMLetterReqVO letterReqLookup(Map<String, String> searchParamMap) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();

		String sourceType = StringUtil.nonNullTrim(searchParamMap.get("searchType"));
		String primaryId = StringUtil.nonNullTrim(searchParamMap.get("searchId"));

		EEMLetterReqVO letterReqVO = new EEMLetterReqVO();

		EEMLetterReqDO letterReqDO = letterRequestDao.getletterReqLookup(customerId, searchParamMap);
		if (letterReqDO != null) {
			String planDesignation = trimToEmpty(letterReqDO.getPlanDesignation());
			letterReqDO.setSourceTypeDesc(eemCodeCache.getDesc(sourceType, eemCodeCache.getArrSourceTypes()));

			List<LabelValuePair> lst = letterRequestDao.getLetterList(customerId, planDesignation, sourceType);
			if (lst == null) {
				throw new ApplicationException("No Letters Found");
			}
			BeanUtils.copyProperties(letterReqDO, letterReqVO);
			letterReqVO.setLstLetterName(lst);
		} else {
			throw new ApplicationException("Missing Required Product Information");
		}
		letterReqVO.setSourceType(sourceType);
		letterReqVO.setPrimaryId(primaryId);
		return letterReqVO;
	}

	public EEMLetterReqVO letterReqSelectLetter(Map<String, String> searchParamMap) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();

		String sourceType = StringUtil.nonNullTrim(searchParamMap.get("searchType"));
		String primaryId = StringUtil.nonNullTrim(searchParamMap.get("searchId"));
		String letterName = StringUtil.nonNullTrim(searchParamMap.get("letterName"));

		EEMLetterReqVO letterReqVO = new EEMLetterReqVO();
		letterReqVO.setSourceType(sourceType);
		letterReqVO.setPrimaryId(primaryId);
		letterReqVO.setLetterName(letterName);

		List<EEMLetterVarDataDO> eemLetterVarDataDOs = letterRequestDao.getLetterDataEntry(customerId, letterName);

		List<EEMLetterVarDataVO> eemLetterVarDataVOs = new ArrayList<>();
		CommonUtils.copyList(eemLetterVarDataDOs, eemLetterVarDataVOs, EEMLetterVarDataVO.class);
		letterReqVO.setLstVarData(eemLetterVarDataVOs);

		return letterReqVO;
	}

	public EEMLetterReqVO letterReqCreateLetter(EEMLetterReqVO letterReqVO) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();
		String ts = DateUtil.getCurrentDatetimeStamp();

		String sourceType = StringUtil.nonNullTrim(letterReqVO.getSourceType());
		String primaryId = StringUtil.nonNullTrim(letterReqVO.getPrimaryId());
		String letterName = StringUtil.nonNullTrim(letterReqVO.getLetterName());
		List<EEMLetterVarDataVO> lst = letterReqVO.getLstVarData();

		if (filteredBinaryData(lst)) {
			throw new ApplicationException("Carraige Returns and tabs have been removed Please Verify and resubmit");
		}
		String reasonCd = letterRequestDao.getReasonCode(customerId, letterName);
		int sqlCnt = 0;
		try {
			if ("M".equals(sourceType)) {
				EMMbrTriggerDO trig = new EMMbrTriggerDO();
				trig.setCustomerId(customerId);
				trig.setMemberId(primaryId);
				trig.setTriggerType(EEMConstants.TRIG_TYPE_MANUAL_LTR);
				trig.setEffectiveDate(letterReqVO.getEffDate());
				trig.setTriggerCode(reasonCd);
				trig.setPlanId(letterReqVO.getPlanId());
				trig.setPbpId(letterReqVO.getPbpId());
				trig.setPlanDesignation(letterReqVO.getPlanDesignation());
				trig.setTriggerStatus(EEMConstants.TRIG_STATUS_OPEN);
				trig.setProcessSource(EEMConstants.PROCESS_SOURCE_MBR);
				trig.setOrigTriggerType("");
				trig.setOrigTriggerCode("");
				trig.setOrigEffectiveDate("");
				trig.setOrigTriggerCreateTime("");
				trig.setCreateUserId(userId);
				trig.setCreateTime(ts);
				trig.setLastUpdtUserId(userId);
				trig.setLastUpdtTime(ts);
				if (trig.getFileBatchId() == null) {
					trig.setFileBatchId("");
				}
				if (trig.getLetterName() == null) {
					trig.setLetterName("");
				}
				if (trig.getRecordType() == null) {
					trig.setRecordType("");
				}
				sqlCnt = emMbrDAO.insertMbrTrigger(trig);
				if (sqlCnt != 1) {
					throw new ApplicationException("Invalid SQL Update Count [" + sqlCnt + "]");
				}
				if (lst != null && !lst.isEmpty()) {
					EEMMbrTriggerLtrDataVO trigData = new EEMMbrTriggerLtrDataVO();
					trigData.setCustomerId(trig.getCustomerId());
					trigData.setMemberId(trig.getMemberId());
					trigData.setTriggerType(trig.getTriggerType());
					trigData.setEffectiveDate(trig.getEffectiveDate());
					trigData.setCreateTime(trig.getCreateTime());
					trigData.setLastUpdtUserId(trig.getCreateUserId());
					trigData.setLastUpdtTime(ts);
					
					EEMLetterVarDataVO varData = null;
					Iterator<EEMLetterVarDataVO> it = lst.iterator();
					int seqNbr = 1;
					while (it.hasNext()) {
						varData = it.next();
						trigData.setVariableSeqNbr(seqNbr);
						trigData.setVariableId(varData.getVarId());
						if (varData.getFieldType().equals("D")) {
							trigData.setContinueSeqNbr(1);
							trigData.setVariableData(DateFormatter.reFormat(varData.getFieldValue(),
									DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
							sqlCnt = letterRequestDao.insertMbrTriggerLtrData(trigData);
							if (sqlCnt != 1) {
								throw new ApplicationException("Invalid SQL Update Count [" + sqlCnt + "]");
							}
						} else {
							if(! StringUtil.nonNullTrim(varData.getFieldValue()).isEmpty()) {
							String[] chunks = CommonUtils.getChunks(varData.getFieldValue());
							for (int i = 0; i < chunks.length; i++) {
								trigData.setContinueSeqNbr(i + 1);
								trigData.setVariableData(chunks[i]);
								sqlCnt = letterRequestDao.insertMbrTriggerLtrData(trigData);
								if (sqlCnt != 1) {
									throw new ApplicationException("Invalid SQL Update Count [" + sqlCnt + "]");
								}
							}
						  }
						}
						seqNbr += 1;
					}
				}
			} else if ("A".equals(letterReqVO.getSourceType())) {
				EEMApplTriggerDO trig = new EEMApplTriggerDO();
				trig.setCustomerId(customerId);
				trig.setApplicationId(letterReqVO.getPrimaryId());
				trig.setTriggerType(EEMConstants.TRIG_TYPE_MANUAL_LTR);
				trig.setEffectiveDate(letterReqVO.getEffDate());
				trig.setTriggerStatus(EEMConstants.TRIG_STATUS_OPEN);
				trig.setTriggerCode(reasonCd);
				trig.setOrigTriggerType("");
				trig.setOrigTriggerCode("");
				trig.setOrigEffectiveDate("");
				trig.setOrigTriggerCreateTime("");
				trig.setCreateUserid(userId);
				trig.setCreateTime(ts);
				trig.setLastUpdtUserid(userId);
				trig.setLastUpdtTime(ts);

				sqlCnt = emApplDAO.insertApplTrigger(trig);
				if (sqlCnt != 1) {
					throw new ApplicationException("Invalid SQL Update Count [" + sqlCnt + "]");
				}
				if (lst != null && !lst.isEmpty()) {
					EEMApplTriggerLtrDataVO trigData = new EEMApplTriggerLtrDataVO();
					trigData.setCustomerId(trig.getCustomerId());
					trigData.setApplicationId(Integer.parseInt(trig.getApplicationId()));
					trigData.setTriggerType(trig.getTriggerType());
					trigData.setEffectiveDate(trig.getEffectiveDate());
					trigData.setCreateTime(trig.getCreateTime());
					trigData.setLastUpdtUserId(trig.getCreateUserid());
					trigData.setLastUpdtTime(ts);

					EEMLetterVarDataVO varData = null;

					Iterator<EEMLetterVarDataVO> it = lst.iterator();
					int seqNbr = 1;
					while (it.hasNext()) {
						varData = it.next();
						trigData.setVariableSeqNbr(seqNbr);
						trigData.setVariableId(varData.getVarId());

						if (varData.getFieldType().equals("D")) {
							trigData.setContinueSeqNbr(1);
							trigData.setVariableData(DateFormatter.reFormat(varData.getFieldValue(),
									DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
							sqlCnt = letterRequestDao.insertApplTriggerLtrData(trigData);
							if (sqlCnt != 1) {
								throw new ApplicationException("Invalid SQL Update Count [" + sqlCnt + "]");
							}
						} else {
							if(! StringUtil.nonNullTrim(varData.getFieldValue()).isEmpty()) {
							String[] chunks = CommonUtils.getChunks(varData.getFieldValue());
							for (int i = 0; i < chunks.length; i++) {
								trigData.setContinueSeqNbr(i + 1);
								trigData.setVariableData(chunks[i]);
								sqlCnt = letterRequestDao.insertApplTriggerLtrData(trigData);
								if (sqlCnt != 1) {
									throw new ApplicationException("Invalid SQL Update Count [" + sqlCnt + "]");
								}
							}
						  }
						}
						seqNbr += 1;
					}
				}
			}
			letterReqVO.setSourceTypeDesc(
					eemCodeCache.getDesc(letterReqVO.getSourceType(), eemCodeCache.getArrSourceTypes()));
			letterReqVO.setTriggerType(EEMConstants.TRIG_TYPE_MANUAL_LTR);
			letterReqVO.setTriggerTypeDesc(
					eemCodeCache.getDesc(letterReqVO.getTriggerType(), eemCodeCache.getLstTriggerType()));
			letterReqVO.setTriggerStatus(EEMConstants.TRIG_STATUS_OPEN);
			letterReqVO.setTriggerStatusDesc(
					eemCodeCache.getDesc(letterReqVO.getTriggerStatus(), eemCodeCache.getLstTriggerStatus()));
			letterReqVO.setTriggerCode(letterReqVO.getLetterName());
			letterReqVO.setCreateTime(ts);
			letterReqVO.setCreateUserId(userId);
			letterReqVO.setLastUpdtTime(ts);
			letterReqVO.setLastUpdtUserId(userId);
		} catch (Exception e) {
			throw new ApplicationException("Update Failed");
		}
		return letterReqVO;
	}

	public boolean filteredBinaryData(List<EEMLetterVarDataVO> lst) {

		if (lst == null) {
			return false;
		}
		EEMLetterVarDataVO varData = null;

		boolean rslt = false;
		StringBuilder sb;
		String txt;
		int len;
		Iterator<EEMLetterVarDataVO> it = lst.iterator();
		while (it.hasNext()) {
			varData = it.next();
			sb = new StringBuilder();
			txt = trimToEmpty(varData.getFieldValue());
			len = txt.length();
			char c;
			boolean thisRslt = false;
			for (int i = 0; i < len; i++) {
				c = txt.charAt(i);
				if (Character.isISOControl(c)) {
					sb.append(' ');
					thisRslt = true;
				} else {
					sb.append(c);
				}
			}
			if (thisRslt) {
				varData.setFieldValue(sb.toString());
				rslt = thisRslt;
			}
		}
		return rslt;
	}

	@SuppressWarnings("unchecked")
	public PageableVO getLetterSearchDetailsPagination(Map<String, String> searchParamMap, boolean isPagination) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();

		List<EEMLetterReqVO> letterReqVOList = new ArrayList<>();
		try {
			PageableVO letterReqDetails = letterRequestDao.getLetterReqSearchResults(customerId,
					searchParamMap, isPagination);
			List<EEMLetterReqDO> letterReqDOList = (List<EEMLetterReqDO>) letterReqDetails.getContent();
			
			if (!letterReqDOList.isEmpty()) {
				for (EEMLetterReqDO letterReqDO : letterReqDOList) {
					EEMLetterReqVO emletterReqVO = new EEMLetterReqVO();

					letterReqDO.setSourceTypeDesc(
							eemCodeCache.getDesc(letterReqDO.getSourceType(), eemCodeCache.getArrSourceTypes()));
					letterReqDO.setTriggerTypeDesc(
							eemCodeCache.getDesc(letterReqDO.getTriggerType(), eemCodeCache.getLstTriggerType()));
					letterReqDO.setTriggerStatusDesc(
							eemCodeCache.getDesc(letterReqDO.getTriggerStatus(), eemCodeCache.getLstTriggerStatus()));
					String type = "";
					String desc = eemCodeCache.getDesc(letterReqDO.getTriggerCode(), eemCodeCache.getLstTriggerCodes(type));
					if (desc != null) {
						letterReqDO.setTriggerCodeDesc(desc);
					} else {
						letterReqDO.setTriggerCodeDesc(letterReqDO.getTriggerCode());
					}
					if (trimToEmpty(letterReqDO.getLetterNameDesc()).isEmpty()) {
						letterReqDO.setLetterNameDesc(letterReqDO.getTriggerCodeDesc());
					}
					BeanUtils.copyProperties(letterReqDO, emletterReqVO);
					letterReqVOList.add(emletterReqVO);
				}
				letterReqDetails.setContent(letterReqVOList);
			}
			return letterReqDetails;
		} catch (Exception exp) {
			throw new ApplicationException(exp);
		}
		
	}

	public Boolean closeLetters(List<EEMLetterReqVO> letterReqVOList) {
		String userId = sessionHelper.getUserInfo().getUserId();
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String ts = DateUtil.getCurrentDatetimeStamp();
		int sqlCnt = 0;
		try {
		for (EEMLetterReqVO letterReqVO : letterReqVOList) {
			EEMLetterReqDO letterReqDO = new EEMLetterReqDO();
			BeanUtils.copyProperties(letterReqVO, letterReqDO);
			sqlCnt = letterRequestDao.cancelledLetterReq(letterReqDO, userId, ts);

			if (sqlCnt == 1) {
				if (letterReqVO.getSourceType().equals("A")) {
					EEMApplTriggerDO eemApplTriggerDO = getApplTriggerDO(userId, customerId, ts, letterReqVO);
					sqlCnt = emApplDAO.insertApplTrigger(eemApplTriggerDO);
				} else {
					EMMbrTriggerDO emMbrTriggerDO = getMbrTriggerDO(userId, customerId, ts, letterReqVO);
					sqlCnt = emMbrDAO.insertMbrTrigger(emMbrTriggerDO);
				}
				if (sqlCnt != 1) {
					throw new ApplicationException("Invalid Data");
				}
			}
		}
		} catch (Exception exp) {
			throw new ApplicationException(exp.getMessage());
		}
		return sqlCnt > 0;
	}

	private EMMbrTriggerDO getMbrTriggerDO(String userId, String customerId, String ts, EEMLetterReqVO letterReqVO) {
		EMMbrTriggerDO emMbrTriggerDO = new EMMbrTriggerDO();
		emMbrTriggerDO.setCustomerId(customerId);
		emMbrTriggerDO.setMemberId(letterReqVO.getPrimaryId());
		emMbrTriggerDO.setTriggerType(letterReqVO.getTriggerType());
		emMbrTriggerDO.setEffectiveDate(letterReqVO.getEffDate());
		emMbrTriggerDO.setCreateTime(ts);
		emMbrTriggerDO.setTriggerCode(letterReqVO.getTriggerCode());
		emMbrTriggerDO.setPlanId(letterReqVO.getPlanId());
		emMbrTriggerDO.setPbpId(letterReqVO.getPbpId());
		emMbrTriggerDO.setPlanDesignation(letterReqVO.getPlanDesignation());
		eemTimersService.getBasicMbrTriggerDO(userId, ts, emMbrTriggerDO);
		emMbrTriggerDO.setTriggerStatus(EEMConstants.TRIG_STATUS_CLOSED);
		return emMbrTriggerDO;
	}

	private EEMApplTriggerDO getApplTriggerDO(String userId, String customerId, String ts, EEMLetterReqVO letterReqVO) {
		EEMApplTriggerDO eemApplTriggerDO = new EEMApplTriggerDO();
		eemApplTriggerDO.setCustomerId(customerId);
		eemApplTriggerDO.setApplicationId(letterReqVO.getPrimaryId());
		eemApplTriggerDO.setTriggerType(letterReqVO.getTriggerType());
		eemApplTriggerDO.setEffectiveDate(letterReqVO.getEffDate());
		eemApplTriggerDO.setCreateTime(ts);
		eemApplTriggerDO.setTriggerCode(letterReqVO.getTriggerCode());
		eemApplTriggerDO.setOrigTriggerType("");
		eemApplTriggerDO.setOrigTriggerCode("");
		eemApplTriggerDO.setOrigEffectiveDate("");
		eemApplTriggerDO.setOrigTriggerCreateTime("");
		eemApplTriggerDO.setCreateUserid(userId);
		eemApplTriggerDO.setLastUpdtUserid(userId);
		eemApplTriggerDO.setLastUpdtTime(ts);
		eemApplTriggerDO.setTriggerStatus(EEMConstants.TRIG_STATUS_CLOSED);
		return eemApplTriggerDO;
	}

}
