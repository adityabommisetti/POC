package com.medicare.mss.vo;

import com.medicare.mss.util.DateFormatter;

public class EmMbrCobVO implements EMDatedSegmentVO, Cloneable {

	private String customerId;
	private String memberId;

	private String cobType;
	private String cobDesc;
	private String ohiInd;
	private String ohiDesc;
	
	private String rxGrp;
	private String rxName;
	private String rxId;
	private String rxBin;
	private String rxPcn;
	
	private String overrideInd;
	private String effStartDate;
	private String effEndDate;
	private String createTime;
	private String createUserId;
	private String lastUpdtTime;
	private String lastUpdtUserId;
	
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
	
	public String getCreateTime() {
		return createTime;
	}
	
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public String getCreateUserId() {
		return createUserId;
	}
	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getEffEndDate() {
		return effEndDate;
	}
	public String getEffEndDateFrmt() {
		return DateFormatter.reFormat(effEndDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}
	public void setEffEndDate(String effEndDate) {
		this.effEndDate = effEndDate;
	}
	public void setEffEndDateFrmt(String effEndDate) {
		this.effEndDate = DateFormatter.reFormat(effEndDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);;
	}
	public String getEffStartDate() {
		return effStartDate;
	}
	public String getEffStartDateFrmt() {
		return DateFormatter.reFormat(effStartDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}
	public void setEffStartDate(String effStartDate) {
		this.effStartDate = effStartDate;
	}
	public void setEffStartDateFrmt(String effStartDate) {
		this.effStartDate = DateFormatter.reFormat(effStartDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}
	public String getLastUpdtTime() {
		return lastUpdtTime;
	}
	
	public void setLastUpdtTime(String lastUpdtTime) {
		this.lastUpdtTime = lastUpdtTime;
	}
	public String getLastUpdtUserId() {
		return lastUpdtUserId;
	}
	public void setLastUpdtUserId(String lastUpdtUserId) {
		this.lastUpdtUserId = lastUpdtUserId;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getOverrideInd() {
		return overrideInd;
	}
	public void setOverrideInd(String overrideInd) {
		this.overrideInd = overrideInd;
	}
	public String getCobType() {
		return cobType;
	}
	public void setCobType(String cobType) {
		this.cobType = cobType;
	}
	public String getOhiDesc() {
		return ohiDesc;
	}
	public void setOhiDesc(String ohiDesc) {
		this.ohiDesc = ohiDesc;
	}
	public String getOhiInd() {
		return ohiInd;
	}
	public void setOhiInd(String ohiInd) {
		this.ohiInd = ohiInd;
	}
	public String getType() {
		return cobType;
	}
	public String getCobDesc() {
		return cobDesc;
	}
	public void setCobDesc(String cobDesc) {
		this.cobDesc = cobDesc;
	}
	public String getRxBin() {
		return rxBin;
	}
	public void setRxBin(String rxBin) {
		this.rxBin = rxBin;
	}
	public String getRxGrp() {
		return rxGrp;
	}
	public void setRxGrp(String rxGrp) {
		this.rxGrp = rxGrp;
	}
	public String getRxId() {
		return rxId;
	}
	public void setRxId(String rxId) {
		this.rxId = rxId;
	}
	public String getRxName() {
		return rxName;
	}
	public void setRxName(String rxName) {
		this.rxName = rxName;
	}
	public String getRxPcn() {
		return rxPcn;
	}
	public void setRxPcn(String rxPcn) {
		this.rxPcn = rxPcn;
	}
	
	public boolean isSameCobType(Object obj) {
		
		EmMbrCobVO chkVO = (EmMbrCobVO)obj;
		if (chkVO.getCobType().equals(this.cobType))
			if (chkVO.getMemberId().equals(this.memberId))
				if (chkVO.getCustomerId().equals(this.customerId))
					return true;
  
		return false;
	}

public boolean isEndDateChange(Object obj) {
		
		EmMbrCobVO chkVO = (EmMbrCobVO)obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate))
			if (chkVO.getCobType().equals(this.cobType))
				if (chkVO.getOhiInd().equals(this.ohiInd))
					if (chkVO.getRxGrp().equals(this.rxGrp))
						if (chkVO.getRxName().equals(this.rxName))
							if (chkVO.getRxId().equals(this.rxId))
								if (chkVO.getRxBin().equals(this.rxBin))
									if (chkVO.getRxPcn().equals(this.rxPcn))
										if (chkVO.getMemberId().equals(this.memberId))
											if (chkVO.getCustomerId().equals(this.customerId))
												if (chkVO.getOverrideInd().equals(this.overrideInd))
													return true;
		return false;
	}
	public boolean isForSamePeriod(Object obj) {
		
		EmMbrCobVO chkVO = (EmMbrCobVO)obj;
		if (chkVO.getCobType().equals(this.cobType))
			if (chkVO.getEffStartDate().equals(this.effStartDate))
				if (chkVO.getEffEndDate().equals(this.effEndDate))
					if (chkVO.getMemberId().equals(this.memberId))
						if (chkVO.getCustomerId().equals(this.customerId))
							if (chkVO.getOverrideInd().equals(this.overrideInd))
								return true;
		return false;
	}
	public boolean isSame(Object obj) {
		
		EmMbrCobVO chkVO = (EmMbrCobVO)obj;
		if (chkVO.getCobType().equals(this.cobType))
			if (chkVO.getOhiInd().equals(this.ohiInd))
				if (chkVO.getRxGrp().equals(this.rxGrp))
					if (chkVO.getRxName().equals(this.rxName))
						if (chkVO.getRxId().equals(this.rxId))
							if (chkVO.getRxBin().equals(this.rxBin))
								if (chkVO.getRxPcn().equals(this.rxPcn))
				if (chkVO.getEffStartDate().equals(this.effStartDate))
					if (chkVO.getEffEndDate().equals(this.effEndDate))
						if (chkVO.getMemberId().equals(this.memberId))
							if (chkVO.getCustomerId().equals(this.customerId))
								if (chkVO.getOverrideInd().equals(this.overrideInd))
									if (chkVO.getCreateTime().equals(this.createTime))
										if (chkVO.getCreateUserId().equals(this.createUserId))
											if (chkVO.getLastUpdtTime().equals(this.lastUpdtTime))
												if (chkVO.getLastUpdtUserId().equals(this.lastUpdtUserId))								
													return true;
		return false;
	}

		
}
