package com.medicare.mss.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EMPcpSearchVO {

	private String customerId;
	private String effDate;
	private String pcpNbr;
	private String locationId;
	private String doctorName;
	private String acceptNewPatient;
	private String address;
	private String city;
	private String state;
	private String zip;
	/* Access health PCP CR- Start */
	private String pcpNpi;
	// private String lineOfBusiness;

	public void setEffDate(String effDate) {
		this.effDate = DateFormatter.reFormat(effDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

}
