package com.medicare.mss.vo;

import lombok.Data;

@Data
public class EEMMbrTrrDataVO {

	private String variableDesc;
	private String variableData;
	private String variableDataDesc;

}
