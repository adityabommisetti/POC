/**
 * 
 */
package com.medicare.mss.dao;

import java.util.List;

import com.medicare.mss.domainobject.EEMBillingInvCommentDO;
import com.medicare.mss.domainobject.EEMBillingInvHeaderDtlsDO;
import com.medicare.mss.domainobject.EEMBillingInvoiceDtlsDO;
import com.medicare.mss.security.vo.EEMBillingInvCommentVO;
import com.medicare.mss.vo.EEMBillingInvHeaderDtlsVO;
import com.medicare.mss.vo.EEMBillingInvSummaryVO;
import com.medicare.mss.vo.EEMBillingInvoiceDtlsVO;
import com.medicare.mss.vo.EEMBillingInvoiceSearchVO;
import com.medicare.mss.vo.PageableVO;

/**
 * @author DU20098149
 *
 */
public interface EEMBillingInvDAO {

	PageableVO searchBillingInvoice(EEMBillingInvoiceSearchVO searchVO, String custId, boolean isPagination);

	EEMBillingInvSummaryVO getInvSummary(String customerId, String memberId);

	List<EEMBillingInvoiceDtlsDO> getBillInvoiceDetails(String customerId, String invoiceNbr, String billThrDate);

	List<EEMBillingInvCommentDO> getBillInvoiceComments(String custId, String invNbr);

	String getMedicareIdFromDSInfo(String customerId, String memberId, String dsCode);

	boolean getNextMbrComment(EEMBillingInvCommentVO newCommentVO);

	int insertBillInvoiceComment(EEMBillingInvCommentVO newCommentVO);

	String getEligibleLineAmount(String customerId, String invoiceNbr, String itemNumber);

	int insertBillInvoiceDetail(EEMBillingInvoiceDtlsVO detailVO);

	int getNextAddNbr(String customerId, String invoiceNbr, int itemNbr);

	int updateBillInvoiceTransferHeader(EEMBillingInvHeaderDtlsVO prevHeaderVO);

	int insertBillPaymentDtlInvoice(EEMBillingInvoiceDtlsVO detailVO);

	int getRecordsCount(String customerId, String invoiceNumber, String itemNumber);

	List<EEMBillingInvoiceDtlsDO> getBillMbrGrpList(String customerId, String id, String firstName, String lastName);

	int insertBillInvoiceHeader(EEMBillingInvHeaderDtlsVO headerVO);

	int getNextItemNbr(String customerId, String invoiceNbr);

	int updateBillInvoiceHeader(EEMBillingInvoiceDtlsVO wrkInvDetail, int itemNbr, String invoiceStatus);

	EEMBillingInvHeaderDtlsDO getBillInvoiceHeader(String customerId, String invoiceNbr, String searchInvoiceGroup);

	String getPlanId(String custId, String mbrId);

	String getBillThruDt(String custId, String invNbr);

}
