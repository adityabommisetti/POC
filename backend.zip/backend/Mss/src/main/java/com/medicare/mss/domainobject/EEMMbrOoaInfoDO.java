package com.medicare.mss.domainobject;

import java.io.Serializable;

import com.medicare.mss.annotation.ColumnMapper;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.vo.EMDatedSegmentVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class EEMMbrOoaInfoDO extends BaseDO implements EMDatedSegmentVO, Serializable, Cloneable{
	

	private static final long serialVersionUID = -5273928198203899662L;
	
	@ColumnMapper(columnName="OOA_DISEN_EFF_DT" ,propertyName="deEffectiveDate")
	private String deEffectiveDate;
	
	@ColumnMapper(columnName="OOA_DISEN_REASON" ,propertyName="deReason")
	private String deReason;
	
	private String deReasonDesc;
	
	@ColumnMapper(columnName="OOA_END_DT" ,propertyName="endDate")
	private String endDate;
	
	@ColumnMapper(columnName="OOA_LEAVE_DT" ,propertyName="leaveDate")
	private String leaveDate;
	
	@ColumnMapper(columnName="MEMBER_ID" ,propertyName="memberId")
	private String memberId;
	
	@ColumnMapper(columnName="OOA_REASON_CD" ,propertyName="ooaReason")
	private String ooaReason;
	
	@ColumnMapper(columnName="OOA_SRC_CD" ,propertyName="ooaSource")
	private String ooaSource;
	
	
	private String ooaSourceTrr;
	
	@ColumnMapper(columnName="OVERRIDE_IND" ,propertyName="overrideInd")
	private String overrideInd;
	
	
	private String planDesignation;	
	private String reasonDesc;
	
	@ColumnMapper(columnName="OOA_RCVD_DT" ,propertyName="receiveDate")
	private String receiveDate;
	
	@ColumnMapper(columnName="OOA_RETURN_DT" ,propertyName="returnDate")
	private String returnDate;
	
	private String sourceDesc;
	
	@ColumnMapper(columnName="OOA_TYPE" ,propertyName="tempPerm")
	private String tempPerm;
	

	public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }	
	
	public String getDeEffectiveDateFrmt() {
		return DateFormatter.reFormat(deEffectiveDate,DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
	}
	
	@Override
	public String getEffEndDate() {
		return null;
	}	
	
	@Override
	public String getEffStartDate() {
		return null;
	}
	
	public String getEndDateFrmt() {
		return DateFormatter.reFormat(endDate,DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
	}	

	public String getLeaveDateFrmt() {
		return DateFormatter.reFormat(leaveDate,DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
	}
	
	public String getReceiveDateFrmt() {
		return DateFormatter.reFormat(receiveDate,DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
	}	
	
	public String getReturnDateFrmt() {
		return DateFormatter.reFormat(returnDate,DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
	}
	
	@Override
	public String getType() {
		return tempPerm;
	}
	
	@Override
	public boolean isEndDateChange(Object chkVO) {	
		return false;
	}

	@Override
	public boolean isForSamePeriod(Object obj) {
		
		EEMMbrOoaInfoDO chkVO = (EEMMbrOoaInfoDO)obj;
		if (chkVO.getReceiveDate().equals(this.receiveDate)
			&& chkVO.getReturnDate().equals(this.returnDate)
				&& chkVO.getMemberId().equals(this.memberId)
					&& chkVO.getCustomerId().equals(this.getCustomerId())
						&& chkVO.getOverrideInd().equals(this.overrideInd))
							return true;
		return false;
	}

	@Override
	public boolean isSame(Object chkVO) {
		return false;
	}

	public boolean permOOAExists(Object obj) {
		
		EEMMbrOoaInfoDO chkVO = (EEMMbrOoaInfoDO)obj;
		if ("TEMP".equalsIgnoreCase(chkVO.getType())
			&& "PERM".equalsIgnoreCase(this.getType())
				&& chkVO.getMemberId().equals(this.memberId)
					&& chkVO.getCustomerId().equals(this.getCustomerId())
						&& chkVO.getOverrideInd().equals(this.overrideInd)
							&& ((chkVO.getLeaveDate().compareTo(this.getLeaveDate())>0) || (chkVO.getReturnDate().compareTo(this.getLeaveDate())>0))) 
								return true;

						
		return false;
	}

	public void setDeEffectiveDateFrmt(String deEffectiveDate) {
		this.deEffectiveDate = DateFormatter.reFormat(deEffectiveDate,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
	}

	@Override
	public void setEffEndDate(String effEndDate) {
		
	}


	@Override
	public void setEffStartDate(String effStartDate) {
		
	}

	public void setEndDateFrmt(String endDate) {
		this.endDate = DateFormatter.reFormat(endDate,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
	}	
	public void setLeaveDateFrmt(String leaveDate) {
		this.leaveDate = DateFormatter.reFormat(leaveDate,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
	}


	public void setReceiveDateFrmt(String receiveDate) {
		this.receiveDate = DateFormatter.reFormat(receiveDate,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
	}
	
	public void setReturnDateFrmt(String returnDate) {
		this.returnDate = DateFormatter.reFormat(returnDate,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
	}


}
