package com.medicare.mss.aop;

import org.aspectj.lang.annotation.Pointcut;

/**
 * This class is used to define fully qualified execution end points.
 * 
 * @author Wipro
 *
 */
public class CommonJoinPointConfig {

	@Pointcut("execution(* com.medicare.mss.controller.*.*(..))")
	public void controllerExecution() {
		//joinpoint for controllerExecution
	}

	@Pointcut("execution(* com.medicare.mss.service.*.*(..))")
	public void businessLayerExecution() {
		//joinpoint for businessLayerExecution
	}

	@Pointcut("execution(* com.medicare.mss.daoImpl.*.*(..))")
	public void dataLayerExecution() {
		//joinpoint for dataLayerExecution
	}

	@Pointcut("execution(* com.medicare.mss.controller.*.*(..)) || execution(* com.medicare.mss.service.*.*(..)) || execution(* com.medicare.mss.daoImpl.*.*(..))")
	public void allLayerExecution() {
		//joinpoint for allLayerExecution
	}
	
}