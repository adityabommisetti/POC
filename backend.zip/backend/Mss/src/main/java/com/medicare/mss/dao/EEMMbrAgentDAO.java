package com.medicare.mss.dao;

import java.util.List;

import com.medicare.mss.domainobject.EmMbrAgentDO;

public interface EEMMbrAgentDAO extends EEMMbrBaseDAO {

	List<EmMbrAgentDO> getMbrAgents(String customerId, String memberId, String showAll, String lineOfBusiness);

	int setMbrAgentOverride(EmMbrAgentDO delDO, String userId);

	boolean getActiveAgent(EmMbrAgentDO agentDO);

	int checkInvalidAgent(EmMbrAgentDO agentDO);

	int checkInvalidAgency(EmMbrAgentDO agentDO);

	int insertMbrAgent(EmMbrAgentDO newDO);

}
