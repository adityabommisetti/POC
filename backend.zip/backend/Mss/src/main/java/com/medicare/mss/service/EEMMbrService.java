package com.medicare.mss.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.caching.EEMProfileSettings;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.EEMProfileConstants;
import com.medicare.mss.dao.EEMMbrDAO;
import com.medicare.mss.dao.EEMMbrErrorDAO;
import com.medicare.mss.domainobject.EEMMbrSnapshotDO;
import com.medicare.mss.domainobject.EmMbrErrorDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.helper.EEMContext;
import com.medicare.mss.helper.EEMEnrollHelper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EEMMbrMasterVO;
import com.medicare.mss.vo.EEMMbrSearchVO;
import com.medicare.mss.vo.EEMMbrSnapshotVO;
import com.medicare.mss.vo.EmMbrErrorVO;
import com.medicare.mss.vo.MbrCacheVO;
import com.medicare.mss.vo.PageableVO;

@Service
public class EEMMbrService {

	@Autowired
	private EEMMbrDAO enrollDao;

	@Autowired
	private CacheService sessionHelper;

	@Autowired
	private EEMMbrOOAService mbrOoaService;

	@Autowired
	private EEMMbrLisService mbrLisService;

	@Autowired
	private EEMMbrAddressServices mbrAddressService;

	@Autowired
	private EEMMbrDsInfoService eemMbrDsInfoService;

	@Autowired
	private EEMMbrEnrollmentService mbrEnrollService;

	@Autowired
	private EEMMbrDemographicService mbrDemographicService;

	@Autowired
	EEMMbrCommentsService mbrCommentsService;

	@Autowired
	private EEMMbrPOSServices mbrPOSService;

	@Autowired
	private EEMMbrLtcService mbrLtcService;

	@Autowired
	private EEMEnrollHelper emEnrollHelper;

	@Autowired
	private EEMMbrLetterServices mbrLetterService;

	@Autowired
	private EEMMbrPCPServices mbrPCPServices;

	@Autowired
	private EEMMbrErrorDAO mbrErrorDAO;

	@Autowired
	private EEMProfileSettings eemProfileSettings;

	@Autowired
	private MessageSource messageSource;

	@Autowired
	private EEMMbrCobService mbrCobService;

	@Autowired
	private EEMMbrBillingService mbrBillingService;

	@Autowired
	private EEMMbrAccretionService mbrAccretionService;

	@Autowired
	private EEMMbrAgentServices mbrAgentService;

	@Autowired
	private EEMMbrLepInfoService eemMbrLepInfoService;

	@Autowired
	private EEMMbrAsesService eemMbrAsesService;

	@Autowired
	private EEMCodeCache eemCodeCache;

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public EEMMbrMasterVO getMemberSearchDetails(Map<String, String> searchParamMap) throws ApplicationException {

		String customerId = sessionHelper.getUserInfo().getCustomerId();

		EEMMbrMasterVO mbrMasterVO = null;
		PageableVO mbrSearchDetails = enrollDao.getMbrSearchDetails(customerId, searchParamMap, false);
		List<EEMMbrSearchVO> mbrSearchVOList = (List<EEMMbrSearchVO>) mbrSearchDetails.getContent();

		if (!CollectionUtils.isEmpty(mbrSearchVOList)) {
			mbrMasterVO = new EEMMbrMasterVO();
			mbrMasterVO.setNextPage(mbrSearchDetails.isNextPage());
			mbrMasterVO.setMbrSearchList(mbrSearchVOList);
			String medicareId = mbrSearchVOList.get(0).getMedicareId();
			String memberId = mbrSearchVOList.get(0).getMemberId();
			String cmsEffMonth = mbrSearchVOList.get(0).getCmsEffMonth();

			cmsEffMonth = DateFormatter.reFormat(cmsEffMonth, DateFormatter.MM_YYYY, DateFormatter.YYYYMM);
			String showAll = StringUtil.nonNullTrim(searchParamMap.get("showAll"));
			if (!CollectionUtils.isEmpty(mbrMasterVO.getMbrSearchList())) {
				getMemberDetails(customerId, mbrMasterVO, medicareId, memberId, cmsEffMonth, "", showAll);
			}
		}
		return mbrMasterVO;
	}

	public EEMMbrMasterVO getMemberSearchSelect(Map<String, String> searchParamMap) throws ApplicationException {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		EEMMbrMasterVO mbrMasterVO = new EEMMbrMasterVO();

		String medicareId = StringUtil.nonNullTrim(searchParamMap.get("medicareId")).toUpperCase();
		String memberId = StringUtil.nonNullTrim(searchParamMap.get("memberId"));
		String cmsEffMonth = DateFormatter.reFormat(StringUtil.nonNullTrim(searchParamMap.get("cmsEffMonth")),
				DateFormatter.MM_YYYY, DateFormatter.YYYYMM);
		String selectedTab = StringUtil.nonNullTrim(searchParamMap.get("selectedTab"));
		String showAll = StringUtil.nonNullTrim(searchParamMap.get("showAll"));
		getMemberDetails(customerId, mbrMasterVO, medicareId, memberId, cmsEffMonth, selectedTab, showAll);

		return mbrMasterVO;
	}

	private void getMemberDetails(String customerId, EEMMbrMasterVO mbrMasterVO, String medicareId, String memberId,
			String cmsEffMonth, String selectedTab, String showAll) throws ApplicationException {
		if (showAll == null) {
			showAll = "N";
		}
		mbrMasterVO.setMbrDemographicVO(mbrDemographicService.getMbrDemographic(medicareId, memberId, cmsEffMonth));
		mbrMasterVO.setMbrEnrollmentList(mbrEnrollService.getEnrollListFromDB(memberId, showAll));
		mbrMasterVO.setMbrDsInfoList(eemMbrDsInfoService.getMbrDsInfoListFromDB(memberId, showAll));
		mbrMasterVO.setMbrAddressList(mbrAddressService.getMbrAddressList(memberId, showAll));

		String cpmDate = eemCodeCache.getCPMDate();
		if (cpmDate == null || cpmDate.equals(""))
			throw new ApplicationException("CPM Not Found");
		if (cpmDate.length() == 6) {
			cpmDate = DateFormatter.reFormat(cpmDate, DateFormatter.MMYYYY, DateFormatter.YYYYMM) + "01";
		} else if (cpmDate.length() == 5) {
			cpmDate = "0" + DateFormatter.reFormat(cpmDate, DateFormatter.MMYYYY, DateFormatter.YYYYMM) + "01";
		}

		cpmDate = DateFormatter.reFormat(cpmDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
		mbrMasterVO.setCpmDate(cpmDate);

		String ccmDate = eemProfileSettings.getParmDate(customerId, EEMConstants.CCM);
		if (!ccmDate.equals("")) {
			ccmDate = DateFormatter.reFormat(ccmDate + "01", DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
		}
		mbrMasterVO.setCcmDate(ccmDate);

		String npiInd = eemProfileSettings.getCalendarProfileItem(customerId, EEMProfileConstants.NPIIND);
		mbrMasterVO.setNpiInd(npiInd);

		EEMContext context = sessionHelper.getEEMContext();
		context.setMbrMasterVO(mbrMasterVO);
		sessionHelper.setEEMContext(context);
		
		switch (selectedTab) {

		case EEMConstants.LIS:
			mbrMasterVO.setMbrLisInfoList(mbrLisService.getLisInfosLst(memberId, showAll));
			break;
		case EEMConstants.LEP:
			mbrMasterVO.setEemLepMasterVO(eemMbrLepInfoService.getMbrLepInfo(memberId, showAll));
			break;
		case EEMConstants.LETTERS:
			mbrMasterVO.setMbrLetterList(mbrLetterService.getMbrLettersList(memberId));
			break;
		case EEMConstants.PCP:
			mbrMasterVO.setMbrPcpInfoList(mbrPCPServices.getMbrPCPInfoListFromDB(memberId, showAll));
			break;
		case EEMConstants.LTC:
			mbrMasterVO.setMbrLtcInfoList(mbrLtcService.getMbrLtcInfoListFromDB(memberId, showAll));
			break;
		case EEMConstants.COMMENTS:
			mbrMasterVO.setMbrCommentList(mbrCommentsService.getMbrCommentListDB(memberId));
			break;
		case EEMConstants.TRR:
			mbrMasterVO.setMbrTrrList(mbrCommentsService.getMbrTrrListDB(memberId));
			break;
		case EEMConstants.AGENT:
			mbrMasterVO.setMbrAgentInfoList(mbrAgentService.getMbrAgentsFromDB(memberId, showAll));
			break;
		case EEMConstants.COB:
			mbrMasterVO.setMbrCobVOList(mbrCobService.getMbrCobListFromDB(memberId, showAll));
			break;
		case EEMConstants.BILLING:
			mbrMasterVO.setMbrBillingList(mbrBillingService.getMbrBillingListFromDB(memberId, showAll));
			break;
		case EEMConstants.ACCRETION:
			mbrMasterVO.setMbrAccretionList(mbrAccretionService.getMbrAccretionListFromDB(memberId, showAll));
			break;
		case EEMConstants.ASES:
			mbrMasterVO.setMbrAsesList(eemMbrAsesService.getAsesLst(memberId, showAll));
			break;
		case EEMConstants.OOA:
			mbrMasterVO.setMbrOoaInfoList(mbrOoaService.getMbrOoaListfromDb(memberId, showAll));
			break;
		case EEMConstants.POS:
			mbrMasterVO.setMbrPosInfoList(mbrPOSService.getMbrPOSInfoListFromDB(memberId, showAll));
			break;
		default:
			break;
		}
		
		EEMMbrSnapshotVO mbrSnapshot = getMbrSnapshotData(customerId, mbrMasterVO, memberId);
		mbrMasterVO.setMbrSnapshot(mbrSnapshot);

		String lepPlatinoFlag = enrollDao.getLepPlatinoFlag(customerId, memberId);
		mbrMasterVO.setSuppLepPlatino(lepPlatinoFlag);
		
		List<EmMbrErrorDO> mbrErrorDOList = mbrErrorDAO.getMbrErrors(customerId, memberId);
		List<EmMbrErrorVO> mbrErrorVOList = new ArrayList<>();

		if (!CollectionUtils.isEmpty(mbrErrorDOList)) {
			mbrErrorDOList.forEach(mbrErrorDO -> {
				EmMbrErrorVO mbrErrorVO = new EmMbrErrorVO();
				BeanUtils.copyProperties(mbrErrorDO, mbrErrorVO);
				mbrErrorVO.setFieldDispName(
						messageSource.getMessage(mbrErrorVO.getFieldNbr(), null, Locale.getDefault()));
				mbrErrorVOList.add(mbrErrorVO);
			});
		}

		mbrMasterVO.setMbrErrorList(mbrErrorVOList);

		context.setMbrMasterVO(mbrMasterVO);
		sessionHelper.setEEMContext(context);
	}

	private EEMMbrSnapshotVO getMbrSnapshotData(String customerId, EEMMbrMasterVO mbrMasterVO, String memberId) {
		EEMMbrSnapshotDO mbrSnapshotDO = enrollDao.mbrSnapshot(customerId, memberId);
		EEMMbrSnapshotVO mbrSnapshot = new EEMMbrSnapshotVO();
		BeanUtils.copyProperties(mbrSnapshotDO, mbrSnapshot);
		if (CommonUtils.isNotEmpty(mbrMasterVO.getMbrEnrollmentList())) {
			mbrSnapshot.setSupplementalId(mbrMasterVO.getMbrEnrollmentList().get(0).getSupplementalId());
		}
		return mbrSnapshot;
	}

	public MbrCacheVO getMbrInitialData() throws ApplicationException {

		return emEnrollHelper.setEnrollFormList();
	}

	public PageableVO getMbrPagination(Map<String, String> searchParamMap) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		return enrollDao.getMbrSearchDetails(customerId, searchParamMap, true);
	}

}
