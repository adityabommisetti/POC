package com.medicare.mss.domainobject;

import java.io.Serializable;

import com.medicare.mss.annotation.ColumnMapper;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.vo.EMDatedSegmentVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class EEMMbrEnrollmentDO extends BaseDO implements EMDatedSegmentVO,Cloneable, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5377465318095845631L;
	
	
	@ColumnMapper(columnName = "APPLICATION_DATE", propertyName = "applicationDate")
	private String applicationDate;
	@ColumnMapper(columnName = "APPLICATION_ID", propertyName = "applicationId")
	private int applicationId;
	private String buttonClicked;
	@ColumnMapper(columnName = "REQ_REASON_CD", propertyName = "cancellationReason")
	private String cancellationReason;
	@ColumnMapper(columnName = "DIS_REASON_CD", propertyName = "disReasonCd")
	private String disReasonCd;
	@ColumnMapper(columnName = "EDIT_OVERRIDE_IND", propertyName = "editOverrideInd")
	private String editOverrideInd;
	@ColumnMapper(columnName = "EFF_END_DATE", propertyName = "effEndDate")
	private String effEndDate;
	@ColumnMapper(columnName = "EFF_START_DATE", propertyName = "effStartDate")
	private String effStartDate;
	@ColumnMapper(columnName = "ELC_DERIVED_IND", propertyName = "elcDerivedInd")
	private String elcDerivedInd;
	@ColumnMapper(columnName = "ELECTION_TYPE_CD", propertyName = "electionTypeCd")
	private String electionTypeCd;
	@ColumnMapper(columnName = "ENROLL_REASON_CD", propertyName = "enrollReasonCd")
	private String enrollReasonCd;
	@ColumnMapper(columnName = "ENROLL_SRCE_CD", propertyName = "enrollSrceCd")
	private String enrollSrceCd;
	@ColumnMapper(columnName = "ENROLL_STATUS", propertyName = "enrollStatus")
	private String enrollStatus;
	@ColumnMapper(columnName = "GROUP_NAME", propertyName = "groupName")
	private String groupName;
	@ColumnMapper(columnName = "GRP_ID", propertyName = "grpId")
	private String grpId;
	private String lastUsedSepDate;
	@ColumnMapper(columnName = "MEMBER_ID", propertyName = "memberId")
	private String memberId;
	@ColumnMapper(columnName = "OVERRIDE_IND", propertyName = "overrideInd")
	private String overrideInd;
	@ColumnMapper(columnName = "PBP_ID", propertyName = "pbpId")
	private String pbpId;
	@ColumnMapper(columnName = "PBP_SEGMENT_ID", propertyName = "pbpSegmentId")
	private String pbpSegmentId;
	@ColumnMapper(columnName = "PLAN_DESIGNATION", propertyName = "planDesignation")
	private String planDesignation;
	@ColumnMapper(columnName = "PLAN_ID", propertyName = "planId")
	private String planId;
	@ColumnMapper(columnName = "PLAN_REASON_CD", propertyName = "planReasonCd")
	private String planReasonCd;
	@ColumnMapper(columnName = "PLAN_TYPE", propertyName = "planType")
	private String planType;
	@ColumnMapper(columnName = "PRODUCT_ID", propertyName = "productId")
	private String productId;
	@ColumnMapper(columnName = "PRODUCT_NAME", propertyName = "productName")
	private String productName;
	@ColumnMapper(columnName = "RECEIPT_DATE", propertyName = "receiptDate")
	private String receiptDate;
	@ColumnMapper(columnName = "RECIEVE_DATE", propertyName = "receivedDate")
	private String receivedDate;
	@ColumnMapper(columnName = "RX_ID", propertyName = "rxId")
	private String rxId;
	@ColumnMapper(columnName = "SEP_ELECTION_DATE", propertyName = "sepElectionDate")
	private String sepElectionDate;
	@ColumnMapper(columnName = "SEP_REASON_CD", propertyName = "sepReasonCd")
	private String sepReasonCd;
	@ColumnMapper(columnName = "SIGNATURE_DATE", propertyName = "signatureDate")
	private String signatureDate;
	@ColumnMapper(columnName = "SUPPLEMENTAL_ID", propertyName = "supplementalId")
	private String supplementalId;
	@ColumnMapper(columnName = "TRG72_IND", propertyName = "trg72Ind")
	private String trg72Ind;
	
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	public String getApplicationDateFrmt() {
		return DateFormatter.reFormat(applicationDate,DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
	}
	public String getEffEndDateFrmt() {
		return DateFormatter.reFormat(effEndDate,DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
	}
	public String getEffStartDateFrmt() {
		return DateFormatter.reFormat(effStartDate,DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
	}
	public String getReceiptDateFrmt() {
		return DateFormatter.reFormat(receiptDate,DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
	}
	public String getReceivedDateFrmt() {
		return DateFormatter.reFormat(receivedDate,DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
	}
	public String getSepElectionDateFrmt() {
		return DateFormatter.reFormat(sepElectionDate,DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
	}
	public String getSignatureDateFrmt() {
		return DateFormatter.reFormat(signatureDate,DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
	}
	@Override
	public String getType() {
		return grpId + productId;
	}
	public boolean isDisenrollment() {
		
		if (EEMConstants.MBR_STAT_DPEND.equals(enrollStatus) || EEMConstants.MBR_STAT_DAPRV.equals(enrollStatus))
			return true;

		return false;
	}
	@Override
	public boolean isEndDateChange(Object chkVO) {
		return false;
	}
	public boolean isEnrolled() {
			
			if (enrollStatus.equals(EEMConstants.MBR_STAT_EAPRV))
				return true;
	
			return false;
		}
	@Override
	public boolean isForSamePeriod(Object obj) {
		EEMMbrEnrollmentDO chkVO = (EEMMbrEnrollmentDO)obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate)
			&& chkVO.getEffEndDate().equals(this.effEndDate)
				&& chkVO.getGrpId().equals(this.grpId)
					&& chkVO.getProductId().equals(this.productId)
						&& chkVO.getMemberId().equals(this.memberId)
							&& chkVO.getCustomerId().equals(this.getCustomerId())
								&& chkVO.getOverrideInd().equals(this.overrideInd))
									return true;
		return false;
	}
	@Override
	public boolean isSame(Object obj) {
		
		EEMMbrEnrollmentDO chkVO = (EEMMbrEnrollmentDO)obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate)
			&& chkVO.getEffEndDate().equals(this.effEndDate)
				&& chkVO.getGrpId().equals(this.grpId)
					&& chkVO.getProductId().equals(this.productId)
						&& chkVO.getMemberId().equals(this.memberId)
							&& chkVO.getCustomerId().equals(this.getCustomerId())
								&& chkVO.getOverrideInd().equals(this.overrideInd)
									&& chkVO.getCreateTime().equals(this.getCreateTime())
										&& chkVO.getCreateUserId().equals(this.getCreateUserId())
											&& chkVO.getLastUpdtTime().equals(this.getLastUpdtTime())
												&& chkVO.getLastUpdtUserId().equals(this.getLastUpdtUserId()))								
													return true;
		return false;
	}
	
	
	public void setApplicationDateFrmt(String applicationDate) {
		this.applicationDate = DateFormatter.reFormat(applicationDate,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
	}

	public void setEffEndDateFrmt(String effEndDate) {
		this.effEndDate = DateFormatter.reFormat(effEndDate,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
	}

	public void setEffStartDateFrmt(String effStartDate) {
		this.effStartDate = DateFormatter.reFormat(effStartDate,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
	}

	public void setReceiptDateFrmt(String receiptDate) {
		this.receiptDate = DateFormatter.reFormat(receiptDate,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD); ;
	}

	public void setReceivedDateFrmt(String receivedDate) {
		this.receivedDate = DateFormatter.reFormat(receivedDate,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
	}
	public void setSepElectionDateFrmt(String sepElectionDate) {
		this.sepElectionDate = DateFormatter.reFormat(sepElectionDate,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
	}
	public void setSignatureDateFrmt(String signatureDate) {
		this.signatureDate = DateFormatter.reFormat(signatureDate,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
	}
}
