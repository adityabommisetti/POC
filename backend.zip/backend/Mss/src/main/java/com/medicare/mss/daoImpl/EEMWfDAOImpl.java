package com.medicare.mss.daoImpl;

import static com.medicare.mss.util.StringUtil.nonNullTrim;

import java.lang.reflect.Field;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.caching.EEMPersistence;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMWfDAO;
import com.medicare.mss.domainobject.EEMAtRiskDO;
import com.medicare.mss.domainobject.EEMWFActivityDO;
import com.medicare.mss.domainobject.EEMWFCaseDO;
import com.medicare.mss.domainobject.EEMWFCommentDO;
import com.medicare.mss.domainobject.EEMWFSupervisorUserDO;
import com.medicare.mss.domainobject.EEMWFUserDO;
import com.medicare.mss.domainobject.EEMWfAssignOrTransDO;
import com.medicare.mss.domainobject.EMWFCaseQueueDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.LabelValueKeyPair;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.util.PaginationQueryHelper;
import com.medicare.mss.vo.DataBaseField;
import com.medicare.mss.vo.EEMAtRiskVO;
import com.medicare.mss.vo.EEMWFCaseVO;
import com.medicare.mss.vo.EEMWFCommentVO;
import com.medicare.mss.vo.EEMWFSupervisorUserVO;
import com.medicare.mss.vo.EEMWfSearchVO;
import com.medicare.mss.vo.EMWFCaseQueueVO;
import com.medicare.mss.vo.EMWFQueAsgnGrpVO;
import com.medicare.mss.vo.PageableVO;

@Repository
public class EEMWfDAOImpl implements EEMWfDAO {

	private static final String USER_ID_COL = "USER_ID";

	private static final String QUEUE_CD = "QUEUE_CD";

	private static final String USER_LEVEL = "USER_LEVEL";

	private static final String CASE_ID = "caseId";

	private static final String CUST_ID = "custId";

	private static final String CUSTOMER_ID = "customerId";

	private static final String LAST_UPDT_TIME = "lastUpdtTime";

	private static final String OVERRIDE_IND = "overrideInd";

	private static final String USER_ID = "userId";

	private static final String USER_ID_LIST = "userIdList";

	private static final Logger LOG = LoggerFactory.getLogger(EEMWfDAOImpl.class);

	private static final String UNION = " UNION ";

	private static final String CASE_STATUS = "CASE_STATUS";

	private static final String COUNT = "COUNT";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Autowired
	private EEMPersistence eemPersistence;

	@Override
	public PageableVO searchWorkflow(EEMWfSearchVO searchVO, String customerId, boolean isPagination) {
		List<EEMWFCaseDO> eemWFCaseDOs = new ArrayList<>();
		List<String> params = new ArrayList<>();
		PageableVO response = new PageableVO();
		String caseStatus = searchVO.getCaseStatus();
		String mbrName = null;

		StringBuilder query = buildWorkflowSearchQuery(searchVO, customerId, params, caseStatus, mbrName, isPagination);
		try {
			if (isPagination) {
				DataBaseField[] conds = new DataBaseField[2];
				for (int i = 0; i < conds.length; i++) {
					conds[i] = new DataBaseField();
				}
				conds[0].setFieldName("DAYS_REMAINING");
				conds[0].setStringValue(searchVO.getDaysRemaining());

				conds[1].setFieldName("CASE_ID");
				conds[1].setStringValue(searchVO.getCaseId());

				StringBuilder pageCond = PaginationQueryHelper.pagingElements(conds, params);
				query.append(pageCond);
			}

			query.append(" ORDER BY DAYS_REMAINING, CASE_ID ");
			query.append(" FETCH FIRST ").append(EEMConstants.DB_MAX_RECORD_FETCH).append(" ROWS ONLY ");

			eemWFCaseDOs = jdbcTemplate.query(query.toString(),
					new DomainPropertyRowMapper<EEMWFCaseDO>(EEMWFCaseDO.class), params.toArray());

			if (!CollectionUtils.isEmpty(eemWFCaseDOs) && eemWFCaseDOs.size() > 100) {
				eemWFCaseDOs.remove(eemWFCaseDOs.size() - 1);
				response.setNextPage(true);
			}

			response.setContent(eemWFCaseDOs);
			return response;

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}

	}

	private StringBuilder buildWorkflowSearchQuery(EEMWfSearchVO searchVO, String customerId, List<String> params,
			String caseStatus, String mbrName, boolean isPagination) {

		String conditionUserId = " AND CURRENT_USER_ID = ? ";
		String userIdNotEqualsTo = " AND CURRENT_USER_ID != ? ";
		String statusNotClosed = " AND CASE_STATUS != 'CLOSED' ";
		String conditionStatus = " AND CASE_STATUS = ? ";

		StringBuilder query = CommonUtils.buildQueryBuilder("SELECT CUSTOMER_ID, CASE_ID, CURRENT_USER_ID,",
				"LAST_UPDT_TIME, CASE_TIMESTAMP, APPLICATION_ID, MEMBER_ID,",
				"SUPPLEMENTAL_ID, MEDICARE_ID, QUEUE_CD, CASE_DATE, CASE_DUE_DATE,",
				"DAYS_REMAINING, CASE_DESC, CASE_STATUS, RISK_IND, UPPER(MEMBER_NAME) AS MEMBER_NAME,",
				"CASE_REASSIGN_DATE, INITIAL_USER_ID, REASSIGN_TYPE_CD,",
				"OVERRIDE_IND, LAST_UPDT_USERID FROM EM_WF_CASE", "WHERE CUSTOMER_ID = ? AND OVERRIDE_IND = 'N'");

		params.add(customerId);

		if (!isBlankSearch(searchVO)) {
			if (StringUtils.isNotBlank(searchVO.getAssignedToUser())) {

				String assignedToUser = searchVO.getAssignedToUser().trim();

				if (StringUtils.equalsIgnoreCase(EEMConstants.ASSIGNED, searchVO.getAssignedToUser())) {
					assignedToUser = EEMConstants.UNASSIGNED;
					query.append(userIdNotEqualsTo);

					if (StringUtils.isNotBlank(caseStatus)) {
						query.append(conditionStatus);
					} else {
						query.append(statusNotClosed);
					}

				} else if (StringUtils.equals(EEMConstants.UNASSIGNED, searchVO.getAssignedToUser())) {
					query.append(conditionUserId);

					if (StringUtils.isNotBlank(caseStatus)) {
						query.append(conditionStatus);
					} else {
						query.append(statusNotClosed);
					}

				} else if (StringUtils.equals(EEMConstants.VALUE_YES, searchVO.getRiskInd())) {
					caseStatus = null;
					query.append(conditionUserId);
					query.append(statusNotClosed);
				} else if (StringUtils.isNotBlank(caseStatus)) {
					query.append(conditionUserId);
					query.append(conditionStatus);
				} else {
					query.append(conditionUserId);
				}
				params.add(assignedToUser);
			}

			if (StringUtils.isNotBlank(searchVO.getCaseStatus())) {
				caseStatus = searchVO.getCaseStatus();
			}

			if (StringUtils.isNotBlank(caseStatus)) {
				if (!StringUtils.contains(query, conditionStatus)) {
					query.append(conditionStatus);
				}
				params.add(caseStatus.trim());
			}

			if (StringUtils.isNotBlank(searchVO.getMbrName())) {
				mbrName = CommonUtils.appendStrings("%", searchVO.getMbrName().trim().toUpperCase(), "%");
			}
			if (Objects.nonNull(mbrName)) {
				query.append(" AND MEMBER_NAME LIKE ?");
				params.add(mbrName);
			}

			if (StringUtils.isNotBlank(searchVO.getMedicareId())) {
				query.append(" AND MEDICARE_ID = ?");
				params.add(searchVO.getMedicareId().trim());
			}
			if (StringUtils.isNotBlank(searchVO.getMemberId())) {
				query.append(" AND MEMBER_ID = ?");
				params.add(searchVO.getMemberId().trim());
			}
			if (StringUtils.isNotBlank(searchVO.getRiskInd())
					&& StringUtils.equals(EEMConstants.VALUE_YES, searchVO.getRiskInd())) {
				query.append(" AND RISK_IND = ?");
				params.add(searchVO.getRiskInd().trim());
				if (!StringUtils.contains(query, statusNotClosed)) {
					query.append(statusNotClosed);
				}
			}
			if (StringUtils.isNotBlank(searchVO.getApplId())) {
				query.append(" AND APPLICATION_ID = ?");
				params.add(searchVO.getApplId().trim());
			}
			if (StringUtils.isNotBlank(searchVO.getSupplementalId())) {
				query.append(" AND SUPPLEMENTAL_ID = ?");
				params.add(searchVO.getSupplementalId().trim());
			}
			if (StringUtils.isNotBlank(searchVO.getCaseId()) && !isPagination) {
				query.append(" AND CASE_ID = ?");
				params.add(searchVO.getCaseId());
			}
			if (StringUtils.isNotBlank(searchVO.getCaseDesc())) {
				query.append(" AND CASE_DESC = ?");
				params.add(searchVO.getCaseDesc().trim());
			}
		}

		return query;
	}

	private boolean isBlankSearch(EEMWfSearchVO searchVO) {
		for (Field field : searchVO.getClass().getDeclaredFields()) {
			if (!StringUtils.equalsIgnoreCase("serialVersionUID", field.getName())) {
				field.setAccessible(true);
				try {
					if (StringUtils.isNotBlank((String) field.get(searchVO))) {
						return false;
					}
				} catch (IllegalArgumentException | IllegalAccessException e) {
					LOG.error("Error occured while blankSearch! {}", e.getMessage());
				}
			}
		}
		return true;
	}

	@Override
	public List<EEMWFActivityDO> fetchUserActivityList(Integer caseId, String customerId) {

		String query = CommonUtils.buildQuery("SELECT ERROR_ID, ACTIVITY_DESC, ACTIVITY_STATUS",
				"FROM EM_WF_ACTIVITY WHERE CASE_ID = ? AND CUSTOMER_ID = ? AND ACTIVITY_STATUS != 'CLOSED'",
				"ORDER BY CUSTOMER_ID, ERROR_ID, LAST_UPDT_TIME DESC");

		try {
			return jdbcTemplate.query(query, new DomainPropertyRowMapper<EEMWFActivityDO>(EEMWFActivityDO.class),
					caseId, customerId);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public List<EEMWFCaseDO> getTotalUnAssignedCases(String customerId) {
		StringBuilder sql = CommonUtils.buildQueryBuilder(
				"SELECT * FROM EM_WF_CASE WHERE CUSTOMER_ID = ? AND CURRENT_USER_ID='UNASSIGNED'",
				"AND OVERRIDE_IND = 'N' AND CASE_STATUS != 'CLOSED' ORDER BY DAYS_REMAINING, QUEUE_CD");
		try {
			String query = sql.toString();
			return jdbcTemplate.query(query, new DomainPropertyRowMapper<EEMWFCaseDO>(EEMWFCaseDO.class), customerId);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public int assignOrTransferCase(EEMWfAssignOrTransDO assignOrTransDO) {
		int count = updateWfCase(assignOrTransDO);
		if (count != 0) {
			count = insertWfCase(assignOrTransDO);
		}
		return count;
	}

	@Override
	public Map<String, Integer> getCountBasedOnStatus(String custId, String searchUserId) {
		List<String> params = new ArrayList<>();
		String conditionUserId = " AND CURRENT_USER_ID = ? ";
		StringBuilder query = CommonUtils.buildQueryBuilder(
				"SELECT CASE_STATUS, count(DISTINCT CASE_ID) as COUNT FROM EM_WF_CASE WHERE",
				"OVERRIDE_IND = 'N' AND CUSTOMER_ID = ?");

		params.add(custId);
		if (StringUtils.equalsIgnoreCase(EEMConstants.ASSIGNED, searchUserId)) {
			searchUserId = EEMConstants.UNASSIGNED;
			conditionUserId = " AND CURRENT_USER_ID != ? ";
		}

		if (StringUtils.isNotBlank(searchUserId)) {
			query.append(conditionUserId);
			params.add(searchUserId);
		}
		query.append("GROUP BY CASE_STATUS");

		try {
			return jdbcTemplate.query(query.toString(), rs -> {

				Map<String, Integer> result = new HashMap<>();
				while (rs.next()) {
					String caseStatus = rs.getString(CASE_STATUS).trim();
					Integer count = rs.getInt(COUNT);
					result.put(caseStatus, count);
				}
				return result;
			}, params.toArray());
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public int getCountOfAssignedCases(String custId) {
		String sql = CommonUtils.buildQuery(
				"SELECT COUNT(DISTINCT CASE_ID) FROM EM_WF_CASE WHERE CUSTOMER_ID=? AND OVERRIDE_IND = 'N' AND CASE_STATUS != 'CLOSED' AND CURRENT_USER_ID != 'UNASSIGNED' ");
		try {
			return jdbcTemplate.queryForObject(sql, new Object[] { custId }, Integer.class);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public int getCountOfAssignedCases(String custId, String userId, String status) {
		String sql = CommonUtils.buildQuery(
				"SELECT COUNT(DISTINCT CASE_ID) FROM EM_WF_CASE WHERE CUSTOMER_ID=? AND OVERRIDE_IND = 'N' AND CURRENT_USER_ID = ? AND CASE_STATUS = ?");
		try {
			return jdbcTemplate.queryForObject(sql, new Object[] { custId, userId, status }, Integer.class);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public int getCountOfUnAssignedCases(String custId) {
		String sql = CommonUtils.buildQuery(
				"SELECT COUNT(DISTINCT CASE_ID) FROM EM_WF_CASE WHERE CUSTOMER_ID=? AND OVERRIDE_IND = 'N' AND CASE_STATUS != 'CLOSED' AND CURRENT_USER_ID = 'UNASSIGNED' ");
		try {
			return jdbcTemplate.queryForObject(sql, new Object[] { custId }, Integer.class);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public int updateCaseState(EEMWfAssignOrTransDO caseStatusUpdtDO) {
		int count = updateWfCase(caseStatusUpdtDO);
		if (count != 0) {
			count = insertWfCase(caseStatusUpdtDO);
		}
		return count;
	}

	@Override
	public void insertActivityWhileInsertError(String customerId, String errorCd, String applOrMbrId, String errorMsg,
			String userId) {
		EEMWFCaseDO caseDO = null;
		try {
			// pull from cache
			String query = CommonUtils.buildQuery(
					"SELECT QUEUE_CD, SUB_QUEUE_CD FROM EM_WF_CASE_SUBQUEUE WHERE ERROR_ID=? AND CUSTOMER_ID=?");

			LabelValuePair labelValuePair = jdbcTemplate.query(query, (ResultSet res) -> {
				LabelValuePair pair = new LabelValuePair();
				while (res.next()) {
					pair.setLabel(nonNullTrim(res.getString(QUEUE_CD)));
					pair.setValue(nonNullTrim(res.getString("SUB_QUEUE_CD")));
				}
				return pair;
			}, errorCd, customerId);

			caseDO = this.getOpenAgreement(customerId, applOrMbrId);
			if (null != caseDO && caseDO.getCaseId() > 0 && StringUtils.isNotBlank(labelValuePair.getLabel())
					&& !isActivityExists(customerId, caseDO.getCaseId(), errorCd)) {
				insertOpenActivity(customerId, caseDO.getCaseId(), errorCd, labelValuePair.getLabel(),
						labelValuePair.getValue(), errorMsg, userId);
			}
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	public void updateActivityWhileUpdatingError(String customerId, String errorCd, String applOrMbrId, String errorMsg,
			String userId) {
		int rows = 0;
		EEMWFCaseDO caseDO = this.getOpenAgreement(customerId, applOrMbrId);
		if (null != caseDO && caseDO.getCaseId() > 0) {
			try {
				EEMWFActivityDO activityDO = this.getOpenActivityForError(customerId, caseDO.getCaseId(), errorCd);
				if (null != activityDO && activityDO.getCaseId() != 0) {
					rows = this.closeActivity(activityDO, userId);
					if (rows != 0) {
						long count = getOpenActivitiesCount(activityDO);
						if (count == 0) {
							this.overrideAgreement(caseDO, userId);
							this.insertClosedAgreement(caseDO, userId);
						}
					}
				}
			} catch (DataAccessException exp) {
				throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
			}
		}
	}

	public EEMWFCaseDO getOpenAgreement(String customerId, String applOrMbrId) {

		try {

			StringBuilder query = CommonUtils.buildQueryBuilder(
					"SELECT CUSTOMER_ID,CASE_ID,CURRENT_USER_ID,LAST_UPDT_TIME,CASE_TIMESTAMP,APPLICATION_ID,MEMBER_ID,",
					"MEDICARE_ID,SUPPLEMENTAL_ID,QUEUE_CD,CASE_DATE,CASE_DUE_DATE,DAYS_REMAINING,CASE_DESC,CASE_STATUS,",
					"RISK_IND,MEMBER_NAME,CASE_REASSIGN_DATE,INITIAL_USER_ID,REASSIGN_TYPE_CD,OVERRIDE_IND,LAST_UPDT_USERID ",
					"FROM EM_WF_CASE WHERE CUSTOMER_ID=:customerId AND OVERRIDE_IND=:overrideInd AND CASE_STATUS != 'CLOSED'",
					"AND ( APPLICATION_ID=:applOrMbrId OR MEMBER_ID=:applOrMbrId )");

			Map<String, Object> params = new HashMap<>();
			params.put(CUSTOMER_ID, customerId);
			params.put("applOrMbrId", applOrMbrId);
			params.put(OVERRIDE_IND, "N");

			List<EEMWFCaseDO> caseDOList = namedParameterJdbcTemplate.query(query.toString(), params,
					new DomainPropertyRowMapper<EEMWFCaseDO>(EEMWFCaseDO.class));

			if (caseDOList.isEmpty()) {
				return null;
			} else if (caseDOList.size() == 1) {
				return caseDOList.get(0);
			} else {
				throw new ApplicationException("Found more than one Open Agreement!");
			}

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	public EEMWFActivityDO getOpenActivityForError(String customerId, int caseId, String errorCd) {
		try {
			StringBuilder query = CommonUtils.buildQueryBuilder(
					" SELECT CUSTOMER_ID, CASE_ID, ERROR_ID, ACTIVITY_CREATION_TIME, QUEUE_CD, SUB_QUEUE_CD, ACTIVITY_DESC,",
					" ACTIVITY_STATUS, LAST_UPDT_USER, LAST_UPDT_TIME ",
					" FROM EM_WF_ACTIVITY WHERE CUSTOMER_ID=:customerId AND CASE_ID =:caseId ",
					" AND ERROR_ID=:errorCd AND ACTIVITY_STATUS != 'CLOSED'");

			Map<String, Object> params = new HashMap<>();
			params.put(CUSTOMER_ID, customerId);
			params.put(CASE_ID, caseId);
			params.put("errorCd", errorCd);

			List<EEMWFActivityDO> activityDOList = namedParameterJdbcTemplate.query(query.toString(), params,
					new DomainPropertyRowMapper<EEMWFActivityDO>(EEMWFActivityDO.class));
			if (activityDOList.isEmpty()) {
				return null;
			} else if (activityDOList.size() == 1) {
				return activityDOList.get(0);
			} else {
				throw new ApplicationException("Found more than one Open Activity for the same Error!");
			}

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	public int closeActivity(EEMWFActivityDO activityDO, String userId) {

		StringBuilder query = CommonUtils.buildQueryBuilder(
				"UPDATE EM_WF_ACTIVITY SET ACTIVITY_STATUS=?, LAST_UPDT_USER=?, ",
				"LAST_UPDT_TIME=? WHERE CUSTOMER_ID=? AND CASE_ID=? ",
				"AND ERROR_ID=? AND ACTIVITY_STATUS != 'CLOSED'");
		try {
			return jdbcTemplate.update(query.toString(), "CLOSED", userId, DateUtil.getCurrentDatetimeStamp(),
					activityDO.getCustomerId(), activityDO.getCaseId(), activityDO.getErrorId());

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}

	}

	public int overrideAgreement(EEMWFCaseDO caseDO, String userId) {
		try {
			StringBuilder query = CommonUtils.buildQueryBuilder(
					"UPDATE EM_WF_CASE SET OVERRIDE_IND=?, LAST_UPDT_USERID=?, LAST_UPDT_TIME=? ",
					"WHERE CUSTOMER_ID=? AND APPLICATION_ID=? AND OVERRIDE_IND=? AND CASE_STATUS != 'CLOSED'");

			return jdbcTemplate.update(query.toString(), "Y", userId, DateUtil.getCurrentDatetimeStamp(),
					caseDO.getCustomerId(), caseDO.getAppId(), "N");

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}

	}

	public int insertClosedAgreement(EEMWFCaseDO caseDO, String userId) {
		try {
			StringBuilder query = CommonUtils.buildQueryBuilder("INSERT INTO EM_WF_CASE ",
					"(CUSTOMER_ID,CASE_ID,CURRENT_USER_ID,LAST_UPDT_TIME,CASE_TIMESTAMP,APPLICATION_ID,MEMBER_ID,",
					"SUPPLEMENTAL_ID,MEDICARE_ID,QUEUE_CD,CASE_DATE,CASE_DUE_DATE,DAYS_REMAINING,CASE_DESC,CASE_STATUS,",
					"RISK_IND,MEMBER_NAME,CASE_REASSIGN_DATE,INITIAL_USER_ID,REASSIGN_TYPE_CD,OVERRIDE_IND,LAST_UPDT_USERID)",
					"VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			Object[] parms = new Object[] { caseDO.getCustomerId(), caseDO.getCaseId(), caseDO.getCurrentUserId(),
					DateUtil.getCurrentDatetimeStampPlus(200), DateUtil.getCurrentDatetimeStamp(), caseDO.getAppId(),
					caseDO.getMbrId(), caseDO.getSupplementalId(), caseDO.getMedicareId(), caseDO.getQueueCode(),
					caseDO.getCaseDate(), caseDO.getCaseDueDate(), caseDO.getDaysRemaining(), caseDO.getCaseDesc(),
					"CLOSED", caseDO.getRiskInd(), caseDO.getMbrName(), caseDO.getCaseReassignDate(),
					caseDO.getInitialUserId(), caseDO.getReAssignTypeCode(), "N", userId };

			return jdbcTemplate.update(query.toString(), parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_INSERT);
		}
	}

	public int insertOpenActivity(String customerId, int caseId, String errorId, String queueCd, String subQueueCd,
			String errorMsg, String userId) {

		try {

			String query = buildActivityInsertQuery();

			Object[] parms = new Object[] { customerId, caseId, errorId, DateUtil.getCurrentDatetimeStamp(), queueCd,
					subQueueCd, errorMsg, "OPEN", userId, DateUtil.getCurrentDatetimeStamp() };

			return jdbcTemplate.update(query, parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_INSERT);
		}
	}

	private String buildActivityInsertQuery() {
		return CommonUtils.buildQuery(
				"INSERT INTO EM_WF_ACTIVITY (CUSTOMER_ID, CASE_ID, ERROR_ID, ACTIVITY_CREATION_TIME, QUEUE_CD, SUB_QUEUE_CD,",
				"ACTIVITY_DESC, ACTIVITY_STATUS, LAST_UPDT_USER, LAST_UPDT_TIME) VALUES (?,?,?,?,?,?,?,?,?,?)");
	}

	public int getOpenActivitiesCount(EEMWFActivityDO activityDO) {
		try {

			StringBuilder query = CommonUtils.buildQueryBuilder("SELECT COUNT(*) AS RECORDS ",
					"FROM EM_WF_ACTIVITY WHERE CUSTOMER_ID=? AND CASE_ID=? AND ACTIVITY_STATUS != 'CLOSED'");

			return jdbcTemplate.queryForObject(query.toString(),
					new Object[] { activityDO.getCustomerId(), activityDO.getCaseId() }, Integer.class);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public List<EEMWFCommentDO> fetchWFCommentList(EEMWFCaseVO emwfCaseVO) {

		ArrayList<Object> params = new ArrayList<>();

		StringBuilder sQuery = null;

		if (StringUtils.equals(EEMConstants.MEMBER, emwfCaseVO.getSource())) {

			sQuery = CommonUtils.buildQueryBuilder(
					" SELECT CUSTOMER_ID,MEMBER_ID,COMMENT_SEQ_NBR,MBR_COMMENTS,CREATE_TIME,CREATE_USERID ",
					" FROM EM_MBR_COMMENTS WHERE MEMBER_ID = ? ",
					" AND CUSTOMER_ID = ? AND UPPER(MBR_COMMENTS) LIKE ? ORDER BY COMMENT_SEQ_NBR DESC");

			params.add(emwfCaseVO.getMbrId());
			params.add(emwfCaseVO.getCustomerId());
			params.add(CommonUtils.appendStrings(EEMConstants.COMMENT_PRESET, "%"));

		} else {

			sQuery = CommonUtils.buildQueryBuilder(
					" SELECT CUSTOMER_ID,APPLICATION_ID,COMMENT_SEQ_NBR,APPL_COMMENTS,CREATE_TIME,CREATE_USERID ",
					" FROM EM_APPL_COMMENT WHERE APPLICATION_ID = ? ",
					" AND CUSTOMER_ID = ? AND UPPER(APPL_COMMENTS) LIKE ? ORDER BY COMMENT_SEQ_NBR DESC");

			params.add(emwfCaseVO.getAppId());
			params.add(emwfCaseVO.getCustomerId());
			params.add(CommonUtils.appendStrings(EEMConstants.COMMENT_PRESET, "%"));

		}
		Object[] objPrams = params.toArray();

		try {
			return jdbcTemplate.query(sQuery.toString(),
					new DomainPropertyRowMapper<EEMWFCommentDO>(EEMWFCommentDO.class), objPrams);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public List<LabelValueKeyPair> getWFAssignedToUsers(String userId, String customerId) {
		String sql;
		List<LabelValueKeyPair> pairs = new ArrayList<>();
		List<Object> params = new ArrayList<>();
		try {
			String userAcess = getUserLevel(userId, customerId);
			String fromClause = "FROM EM_WF_USER wf, SECUSER su WHERE su.USER_ID = wf.USER_ID";
			String selectClause = "SELECT UPPER(su.LAST_NAME) || SPACE(1) || UPPER(su.FIRST_NAME) AS NAME, wf.USER_ID, wf.USER_LEVEL";
			if (StringUtils.equals(EEMConstants.WF_SUPERVISOR, userAcess)) {
				sql = CommonUtils.buildQuery(
						"SELECT UPPER(su.LAST_NAME) || SPACE(1) || UPPER(su.FIRST_NAME) AS NAME, usr.USER_ID, usr.USER_LEVEL",
						"FROM SECUSER su, EM_WF_USER mgr, EM_WF_USER usr WHERE",
						"mgr.USER_ID = usr.MANAGER_ID AND su.USER_ID = usr.USER_ID",
						"AND usr.OVERIDE_IND = 'N' AND usr.USER_STATUS = 'A'",
						"AND usr.CUSTOMER_ID = ? AND mgr.USER_ID = ? UNION", selectClause, fromClause,
						"AND wf.OVERIDE_IND = 'N' AND wf.USER_STATUS = 'A' AND wf.CUSTOMER_ID = ?",
						"AND wf.USER_LEVEL = '2' ORDER BY USER_LEVEL");
				params.add(customerId);
				params.add(userId);
				params.add(customerId);
			} else if (StringUtils.equals(EEMConstants.WF_ADMIN, userAcess)) {
				sql = CommonUtils.buildQuery(selectClause, fromClause,
						"AND wf.OVERIDE_IND = 'N' AND wf.USER_STATUS = 'A' AND wf.CUSTOMER_ID = ? AND wf.USER_LEVEL in ('1','2','3')");
				params.add(customerId);

			} else {
				sql = CommonUtils.buildQuery(selectClause, fromClause,
						"AND wf.OVERIDE_IND = 'N' AND wf.USER_STATUS = 'A' AND wf.CUSTOMER_ID = ? AND wf.USER_LEVEL = '3'");
				params.add(customerId);
			}

			pairs = jdbcTemplate.query(sql, rs -> {
				List<LabelValueKeyPair> labelValueKeyPairs = new ArrayList<>();
				LabelValueKeyPair pair;

				while (rs.next()) {
					pair = new LabelValueKeyPair();
					pair.setLabel(nonNullTrim(rs.getString("NAME")));
					pair.setValue(nonNullTrim(rs.getString(USER_ID_COL)));
					pair.setKey(nonNullTrim(rs.getString(USER_LEVEL)));
					labelValueKeyPairs.add(pair);
				}
				return labelValueKeyPairs;
			}, params.toArray());

			LabelValueKeyPair unAssignedUser = new LabelValueKeyPair(EEMConstants.UNASSIGNED, EEMConstants.UNASSIGNED,
					"0");
			pairs.add(unAssignedUser);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
		return pairs;
	}

	@Override
	public String getUserLevel(String userId, String customerId) {
		String isSupervisor = EEMConstants.NON_WF_USER;
		String query = "SELECT USER_LEVEL FROM EM_WF_USER WHERE OVERIDE_IND = 'N' AND USER_ID = ? AND CUSTOMER_ID = ?";
		try {
			String userLevel = jdbcTemplate.queryForObject(query, (rs, rowNum) -> nonNullTrim(rs.getString(USER_LEVEL)),
					userId, customerId);

			if (Integer.parseInt(userLevel) == 1) {
				isSupervisor = EEMConstants.WF_ADMIN;
			} else if (Integer.parseInt(userLevel) == 2) {
				isSupervisor = EEMConstants.WF_SUPERVISOR;
			} else if (Integer.parseInt(userLevel) == 3) {
				isSupervisor = EEMConstants.WF_NORMAL_USER;
			}
		} catch (EmptyResultDataAccessException exp) {
			isSupervisor = EEMConstants.NON_WF_USER;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
		return isSupervisor;
	}

	@Override
	public int getNextCommentSeqNumber(String custId, String primaryId, String source) {
		StringBuilder sQuery = null;
		String seqNum;
		try {
			if (StringUtils.equals(EEMConstants.MEMBER, source)) {

				sQuery = CommonUtils.buildQueryBuilder("SELECT MAX(COMMENT_SEQ_NBR)+1 AS SEQ_NBR ",
						"FROM EM_MBR_COMMENTS WHERE CUSTOMER_ID = ? AND MEMBER_ID = ?");

				seqNum = jdbcTemplate.queryForObject(sQuery.toString(),
						new Object[] { nonNullTrim(custId), nonNullTrim(primaryId) }, String.class);
			} else {

				sQuery = CommonUtils.buildQueryBuilder("SELECT MAX(COMMENT_SEQ_NBR)+1 AS SEQ_NBR ",
						"FROM EM_APPL_COMMENT WHERE CUSTOMER_ID = ? AND APPLICATION_ID = ?");

				seqNum = jdbcTemplate.queryForObject(sQuery.toString(),
						new Object[] { nonNullTrim(custId), nonNullTrim(primaryId) }, String.class);
			}

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}

		if (StringUtils.isNotBlank(seqNum)) {
			return Integer.parseInt(seqNum);
		} else {
			return 1;
		}
	}

	@Override
	public boolean addWFComment(EEMWFCommentVO wfCommentVo) {
		int count = 0;
		StringBuilder query;
		ArrayList<Object> params = new ArrayList<>();

		if (StringUtils.equals(EEMConstants.MEMBER, wfCommentVo.getSource())) {

			query = CommonUtils.buildQueryBuilder("INSERT INTO EM_MBR_COMMENTS ",
					"(CUSTOMER_ID, MEMBER_ID, COMMENT_SEQ_NBR, MBR_COMMENTS, CREATE_USERID,",
					"CREATE_TIME) VALUES(?,?,?,?,?,?)");

			params.add(wfCommentVo.getCustomerId());
			params.add(wfCommentVo.getPrimaryId());
			params.add(wfCommentVo.getCommentSeqNbr());
			params.add(CommonUtils.buildCommentWithPresetNote(wfCommentVo.getCaseId(), wfCommentVo.getComments()));
			params.add(wfCommentVo.getCreateUserId());
			params.add(wfCommentVo.getCreateTime());

		} else {

			query = CommonUtils.buildQueryBuilder("INSERT INTO EM_APPL_COMMENT ",
					"(CUSTOMER_ID, APPLICATION_ID, COMMENT_SEQ_NBR, APPL_COMMENTS, CREATE_TIME,",
					"CREATE_USERID) VALUES(?,?,?,?,?,?)");

			params.add(wfCommentVo.getCustomerId());
			params.add(wfCommentVo.getPrimaryId());
			params.add(wfCommentVo.getCommentSeqNbr());
			params.add(CommonUtils.buildCommentWithPresetNote(wfCommentVo.getCaseId(), wfCommentVo.getComments()));
			params.add(wfCommentVo.getCreateTime());
			params.add(wfCommentVo.getCreateUserId());

		}
		Object[] objPrams = params.toArray();

		try {
			count = jdbcTemplate.update(query.toString(), objPrams);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_INSERT);
		}

		return count > 0;

	}

	@Override
	public List<EMWFCaseQueueDO> fetchWFCaseQueueList(String customerId) {

		ArrayList<Object> params = new ArrayList<>();
		StringBuilder sQuery = CommonUtils.buildQueryBuilder(
				"SELECT CUSTOMER_ID,QUEUE_CD,CREATE_TIME,QUEUE_NAME,QUEUE_PURPOSE,",
				"QUEUE_DESC,COMP_DAYS,QUEUE_PRTY,AT_RISK_DAYS,OVERIDE_IND,LAST_UPDT_TIME,LAST_UPDT_USERID",
				"FROM EM_WF_CASE_QUEUE WHERE CUSTOMER_ID = ? AND OVERIDE_IND = 'N' ORDER BY QUEUE_NAME");

		params.add(customerId);

		Object[] objPrams = params.toArray();

		try {
			return jdbcTemplate.query(sQuery.toString(),
					new DomainPropertyRowMapper<EMWFCaseQueueDO>(EMWFCaseQueueDO.class), objPrams);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public void updateWFCaseQueue(EMWFCaseQueueVO eemwfCaseQueueVO) {

		String lastUpdtTime = nonNullTrim(eemwfCaseQueueVO.getLastUpdtTime());
		String lastUpdtUserID = nonNullTrim(eemwfCaseQueueVO.getLastUpdtUserID());
		String queuePrty = nonNullTrim(eemwfCaseQueueVO.getQueuePrty());
		String compDays = nonNullTrim(eemwfCaseQueueVO.getCompDays());
		String atRiskDays = nonNullTrim(eemwfCaseQueueVO.getAtRiskDays());
		String queueDesc = nonNullTrim(eemwfCaseQueueVO.getQueueDesc());
		String customerId = nonNullTrim(eemwfCaseQueueVO.getCustomerId());
		String queueCd = nonNullTrim(eemwfCaseQueueVO.getQueueCd());
		String createTime = nonNullTrim(eemwfCaseQueueVO.getCreateTime());

		Object[] parms = new Object[] { lastUpdtTime, lastUpdtUserID, queuePrty, compDays, atRiskDays, queueDesc,
				customerId, queueCd, createTime };

		try {
			StringBuilder sQuery = CommonUtils.buildQueryBuilder(
					" UPDATE EM_WF_CASE_QUEUE SET LAST_UPDT_TIME = ? , LAST_UPDT_USERID = ? , QUEUE_PRTY = ? ,",
					" COMP_DAYS = ? , AT_RISK_DAYS = ? , QUEUE_DESC = ? ",
					" WHERE CUSTOMER_ID= ? AND QUEUE_CD = ? AND CREATE_TIME = ? AND OVERIDE_IND = 'N'");

			jdbcTemplate.update(sQuery.toString(), parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}

	}

	@Override
	public List<String> fetchQueueCdsBasedOnPriority(String customerId, String toUserId) {
		Map<String, Object> params = new HashMap<>();
		List<String> queueCodeList;
		StringBuilder query = CommonUtils.buildQueryBuilder(
				"SELECT DISTINCT QUEUE_CD, PRTY_NBR FROM EM_WF_USERQ_PRIORITY WHERE",
				"CUSTOMER_ID = :customerId AND ACTIVE_IND = 'A' AND OVERIDE_IND = 'N'");

		if (!StringUtils.equalsAnyIgnoreCase(EEMConstants.UNASSIGNED, toUserId)) {
			query.append(" AND USER_ID = :toUserId ");
			params.put("toUserId", toUserId);
		}

		query.append("ORDER BY PRTY_NBR, QUEUE_CD");
		params.put(CUSTOMER_ID, customerId);

		try {
			queueCodeList = namedParameterJdbcTemplate.query(query.toString(), params,
					(rs, rowNum) -> rs.getString(QUEUE_CD));
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}

		return queueCodeList;
	}

	@Override
	public int getWFUserMaxAssignableWorkLimit(String customerId, String paramCode) {
		String sql = "SELECT PARM_NBR_VALUE FROM EM_PROFILE WHERE CUSTOMER_ID = ? AND PARM_CD = ? AND OVERRIDE_IND = 'N'";
		try {
			return jdbcTemplate.queryForObject(sql, (rs, rowNum) -> rs.getInt("PARM_NBR_VALUE"), customerId, paramCode);
		} catch (EmptyResultDataAccessException exp) {
			return 0;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public int updateWFUserMaxAssignableWorkLimit(String customerId, String userId, String paramCode,
			int maxAssignableWorkLimit) {
		String sql = CommonUtils.buildQuery("UPDATE EM_PROFILE SET PARM_NBR_VALUE = ?, LAST_UPDT_USERID = ?,",
				"LAST_UPDT_TIME = ? WHERE CUSTOMER_ID = ? AND PARM_CD = ? AND OVERRIDE_IND = 'N'");
		try {
			String ts = DateUtil.getCurrentDatetimeStamp();
			Object[] params = new Object[] { maxAssignableWorkLimit, userId, ts, customerId, paramCode };
			return jdbcTemplate.update(sql, params);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public List<EEMAtRiskDO> getAtRiskSummary(String customerId) {

		ArrayList<Object> params = new ArrayList<>();

		StringBuilder sQuery = CommonUtils.buildQueryBuilder(
				" SELECT * FROM ( SELECT CHAR(QUEUE_CD) AS QUEUE_CD, CHAR(DAYS_REMAINING) AS DAYS_REMAINING, ",
				"CHAR(QUEUE_PRTY) AS QUEUE_PRTY, CHAR(QUEUE_NAME) AS QUEUE_NAME, COUNT(*) AS COUNT FROM ",
				"(SELECT WFUSER.QUEUE_CD, WFUSER.DAYS_REMAINING,WFQC.QUEUE_PRTY, WFQC.QUEUE_DESC AS QUEUE_NAME ",
				"FROM EM_WF_CASE WFUSER LEFT OUTER JOIN EM_WF_CASE_QUEUE WFQC ON WFQC.QUEUE_CD = WFUSER.QUEUE_CD",
				"AND WFQC.CUSTOMER_ID = WFUSER.CUSTOMER_ID AND WFQC.QUEUE_PRTY IN (1,2) AND WFQC.OVERIDE_IND= 'N' WHERE WFUSER.DAYS_REMAINING ",
				"IN (-4,-3,-2,-1,0,1,2,3,4,5) AND WFQC.QUEUE_PRTY IN (1,2) AND WFUSER.CUSTOMER_ID = ? AND WFUSER.OVERRIDE_IND = 'N' ",
				"AND WFUSER.RISK_IND = 'Y' AND WFUSER.CASE_STATUS != 'CLOSED' ) Q1 GROUP BY QUEUE_CD, DAYS_REMAINING,",
				"QUEUE_PRTY, QUEUE_NAME UNION ALL SELECT CHAR(QUEUE_CD) AS QUEUE_CD, CHAR(MAX(DAYS_REMAINING)) AS DAYS_REMAINING, ",
				"CHAR(QUEUE_PRTY) AS QUEUE_PRTY, CHAR(QUEUE_NAME) AS QUEUE_NAME, COUNT(*) AS COUNT FROM ",
				"(SELECT WFUSER.QUEUE_CD, WFUSER.DAYS_REMAINING,WFQC.QUEUE_PRTY, WFQC.QUEUE_DESC AS QUEUE_NAME",
				"FROM EM_WF_CASE WFUSER LEFT OUTER JOIN EM_WF_CASE_QUEUE WFQC ON WFQC.QUEUE_CD = WFUSER.QUEUE_CD ",
				"AND WFQC.CUSTOMER_ID = WFUSER.CUSTOMER_ID AND WFQC.QUEUE_PRTY IN (1,2) AND WFQC.OVERIDE_IND= 'N' WHERE WFUSER.DAYS_REMAINING<=-5 ",
				"AND WFQC.QUEUE_PRTY IN (1,2) AND WFUSER.CUSTOMER_ID = ? AND WFUSER.OVERRIDE_IND = 'N' AND WFUSER.RISK_IND = 'Y' AND ",
				"WFUSER.CASE_STATUS != 'CLOSED' ) Q2 GROUP BY QUEUE_CD, QUEUE_PRTY, QUEUE_NAME ) MAIN_Q",
				"ORDER BY ABS(DAYS_REMAINING) DESC, QUEUE_PRTY, QUEUE_CD");

		params.add(customerId);
		params.add(customerId);

		Object[] objPrams = params.toArray();

		try {
			return jdbcTemplate.query(sQuery.toString(), new DomainPropertyRowMapper<EEMAtRiskDO>(EEMAtRiskDO.class),
					objPrams);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public List<EEMAtRiskDO> getAtRiskDetails(EEMAtRiskVO eemAtRiskVO) {

		int daysRemaining = eemAtRiskVO.getDaysRemaining();
		ArrayList<Object> params = new ArrayList<>();

		StringBuilder sQuery = CommonUtils.buildQueryBuilder(" SELECT",
				" WFUSER.CASE_ID,WFUSER.QUEUE_CD, WFUSER.DAYS_REMAINING,WFUSER.CASE_DUE_DATE,",
				" WFUSER.CASE_DESC, WFUSER.MEMBER_NAME,WFUSER.MEDICARE_ID,",
				"  (SELECT DISTINCT UPPER(LAST_NAME) || SPACE(1) || UPPER(FIRST_NAME) FROM SECUSER SU WHERE SU.USER_ID = WFUSER.CURRENT_USER_ID) AS USER_NAME,",
				" (SELECT DISTINCT QUEUE_NAME FROM EM_WF_CASE_QUEUE WFQC", " WHERE WFQC.QUEUE_CD = WFUSER.QUEUE_CD",
				" AND WFQC.CUSTOMER_ID = WFUSER.CUSTOMER_ID", " ) AS QUEUE_NAME ,",
				" (SELECT DISTINCT UPPER(LAST_NAME) || SPACE(1) || UPPER(FIRST_NAME) FROM SECUSER SU WHERE SU.USER_ID = ",
				"	(SELECT DISTINCT WU.MANAGER_ID FROM EM_WF_USER WU WHERE WU.USER_ID = WFUSER.CURRENT_USER_ID AND WU.OVERIDE_IND='N')",
				" ) AS SUPERVISOR_NAME FROM EM_WF_CASE WFUSER",
				" WHERE WFUSER.RISK_IND = 'Y' AND WFUSER.CUSTOMER_ID = ?  AND WFUSER.OVERRIDE_IND = 'N' AND WFUSER.CASE_STATUS != 'CLOSED'",
				" AND WFUSER.QUEUE_CD = ?");

		params.add(nonNullTrim(eemAtRiskVO.getCustomerId()));
		params.add(nonNullTrim(eemAtRiskVO.getQueueCd()));

		if (daysRemaining <= -5) {
			sQuery.append("AND WFUSER.DAYS_REMAINING <= ?");
			params.add("-5");
		} else {
			sQuery.append("AND WFUSER.DAYS_REMAINING = ?");
			params.add(daysRemaining);
		}
		sQuery.append(" ORDER BY USER_NAME, SUPERVISOR_NAME ");

		Object[] objPrams = params.toArray();

		try {
			return jdbcTemplate.query(sQuery.toString(), new DomainPropertyRowMapper<EEMAtRiskDO>(EEMAtRiskDO.class),
					objPrams);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public int updateUserStatus(EEMWFSupervisorUserVO emWFSupervisorUserVO, String managerId, String customerId) {

		List<String> params = new ArrayList<>();
		String ts = DateUtil.getCurrentDatetimeStamp();
		String userStatus = nonNullTrim(emWFSupervisorUserVO.getUserStatus());
		String partyMethod = nonNullTrim(emWFSupervisorUserVO.getPrtyMethod());
		String userId = nonNullTrim(emWFSupervisorUserVO.getUserId());
		String inactiveStartDate = nonNullTrim(emWFSupervisorUserVO.getInactiveStartDate());
		String inactiveEndDate = nonNullTrim(emWFSupervisorUserVO.getInactiveEndDate());

		StringBuilder query = CommonUtils.buildQueryBuilder(
				"UPDATE EM_WF_USER SET USER_STATUS = ?, INACTIVE_START_DATE = ?,",
				"INACTIVE_END_DATE = ?, PRTY_METHOD = ?, LAST_UPDT_USERID = ?, LAST_UPDT_TIME = ? WHERE USER_ID = ? AND",
				"CUSTOMER_ID = ? AND OVERIDE_IND = 'N'");

		params.add(userStatus);
		params.add(inactiveStartDate);
		params.add(inactiveEndDate);
		params.add(partyMethod);
		params.add(managerId);
		params.add(ts);
		params.add(userId);
		params.add(customerId);

		String userLevel = getUserLevel(managerId, customerId);
		if (!StringUtils.equals(userId, managerId) && !StringUtils.equals(EEMConstants.WF_ADMIN, userLevel)) {
			query.append(" AND MANAGER_ID = ?");
			params.add(managerId);
		}

		try {
			return jdbcTemplate.update(query.toString(), params.toArray());
		} catch (Exception exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}
	}

	@Override
	public List<Map<String, Object>> getNextMbrCommentSeqNumbers(String custId, List<String> mbrIdList) {

		Map<String, Object> params = new HashMap<>();

		try {
			StringBuilder sQuery = CommonUtils.buildQueryBuilder("SELECT MEMBER_ID, MAX(COMMENT_SEQ_NBR)+1 AS SEQ_NBR",
					"FROM EM_MBR_COMMENTS WHERE CUSTOMER_ID = :customerId AND MEMBER_ID IN (:mbrIdList) GROUP BY MEMBER_ID ORDER BY MEMBER_ID");

			params.put("mbrIdList", mbrIdList);
			params.put(CUSTOMER_ID, custId);

			List<Map<String, Object>> result = new ArrayList<>();
			return namedParameterJdbcTemplate.query(sQuery.toString(), params, (ResultSet res) -> {
				Map<String, Object> map;
				while (res.next()) {
					map = new HashMap<>();
					map.put(nonNullTrim(res.getString("MEMBER_ID")), res.getString("SEQ_NBR"));
					result.add(map);
				}
				return result;
			});
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}

	}

	@Override
	public List<Map<String, Object>> getNextApplCommentSeqNumbers(String custId, List<String> applIdList) {
		Map<String, Object> params = new HashMap<>();

		try {
			StringBuilder sQuery = CommonUtils.buildQueryBuilder(
					"SELECT APPLICATION_ID, MAX(COMMENT_SEQ_NBR)+1 AS SEQ_NBR",
					"FROM EM_APPL_COMMENT WHERE CUSTOMER_ID = :customerId AND APPLICATION_ID IN (:applIdList) GROUP BY APPLICATION_ID ORDER BY APPLICATION_ID");

			params.put("applIdList", applIdList);
			params.put(CUSTOMER_ID, custId);

			List<Map<String, Object>> result = new ArrayList<>();
			return namedParameterJdbcTemplate.query(sQuery.toString(), params, (ResultSet res) -> {
				Map<String, Object> map;
				while (res.next()) {
					map = new HashMap<>();
					map.put(nonNullTrim(res.getString("APPLICATION_ID")), res.getString("SEQ_NBR"));
					result.add(map);
				}
				return result;
			});
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}

	}

	@Override
	public void addWFMbrCommentList(List<EEMWFCommentVO> eemwfMemberCommentList) {

		String sQuery = CommonUtils.buildQuery(
				"INSERT INTO EM_MBR_COMMENTS (CUSTOMER_ID, MEMBER_ID, COMMENT_SEQ_NBR, MBR_COMMENTS, CREATE_TIME,CREATE_USERID) ",
				"VALUES(:cutomerId,:memberId,:commentSeqNbr,:mbrComment,:createTime,:createUserId) ");
		try {
			List<MapSqlParameterSource> batchArgs = new ArrayList<>();
			for (EEMWFCommentVO wfCommentVo : eemwfMemberCommentList) {

				MapSqlParameterSource params = new MapSqlParameterSource();

				params.addValue("cutomerId", wfCommentVo.getCustomerId());
				params.addValue("memberId", wfCommentVo.getPrimaryId());
				params.addValue("commentSeqNbr", wfCommentVo.getCommentSeqNbr());
				params.addValue("mbrComment",
						CommonUtils.buildCommentWithPresetNote(wfCommentVo.getCaseId(), wfCommentVo.getComments()));
				params.addValue("createTime", wfCommentVo.getCreateTime());
				params.addValue("createUserId", wfCommentVo.getCreateUserId());

				batchArgs.add(params);
			}

			if (!CollectionUtils.isEmpty(batchArgs)) {
				namedParameterJdbcTemplate.batchUpdate(sQuery,
						batchArgs.toArray(new MapSqlParameterSource[eemwfMemberCommentList.size()]));
			}
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_INSERT);
		}

	}

	@Override
	public void addWFAppCommentList(List<EEMWFCommentVO> eemwfApplicationCommentList) {
		String sQuery = CommonUtils.buildQuery(
				"INSERT INTO EM_APPL_COMMENT (CUSTOMER_ID, APPLICATION_ID, COMMENT_SEQ_NBR, APPL_COMMENTS, CREATE_TIME,CREATE_USERID) ",
				"VALUES(:cutomerId,:applId,:commentSeqNbr,:applComment,:createTime,:createUserId) ");
		try {
			List<MapSqlParameterSource> batchArgs = new ArrayList<>();
			for (EEMWFCommentVO wfCommentVo : eemwfApplicationCommentList) {

				MapSqlParameterSource params = new MapSqlParameterSource();

				params.addValue("cutomerId", wfCommentVo.getCustomerId());
				params.addValue("applId", wfCommentVo.getPrimaryId());
				params.addValue("commentSeqNbr", wfCommentVo.getCommentSeqNbr());
				params.addValue("applComment",
						CommonUtils.buildCommentWithPresetNote(wfCommentVo.getCaseId(), wfCommentVo.getComments()));
				params.addValue("createTime", wfCommentVo.getCreateTime());
				params.addValue("createUserId", wfCommentVo.getCreateUserId());

				batchArgs.add(params);
			}

			if (!CollectionUtils.isEmpty(batchArgs)) {
				namedParameterJdbcTemplate.batchUpdate(sQuery,
						batchArgs.toArray(new MapSqlParameterSource[eemwfApplicationCommentList.size()]));
			}
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_INSERT);
		}

	}

	@Override
	public Map<String, List<String>> getDetailedAssignedOrUnAssignedCounts(String custId, String userId,
			boolean isAssignedCases) {

		StringBuilder queryBuilder = CommonUtils.buildQueryBuilder(
				"SELECT CASE_DESC, COUNT(DISTINCT CASE_ID) AS COUNT FROM EM_WF_CASE",
				"WHERE CUSTOMER_ID = ? AND OVERRIDE_IND = 'N' AND CASE_STATUS != 'CLOSED'");

		if (isAssignedCases) {
			queryBuilder.append("AND CURRENT_USER_ID != ?");
		} else {
			queryBuilder.append("AND CURRENT_USER_ID = ?");
		}
		queryBuilder.append("GROUP BY CASE_DESC");

		try {
			return jdbcTemplate.query(queryBuilder.toString(), rs -> {
				Map<String, List<String>> result = new HashMap<>();
				String key;
				List<String> value;
				while (rs.next()) {
					if (isAssignedCases) {
						key = EEMConstants.ASSIGNED;
					} else {
						key = EEMConstants.UNASSIGNED;
					}
					String caseDesc = rs.getString("CASE_DESC").trim();
					Integer count = rs.getInt(COUNT);
					if (result.containsKey(key)) {
						result.get(key).add(new StringBuilder(caseDesc).append('_').append(count).toString());
					} else {
						value = new ArrayList<>();
						value.add(new StringBuilder(caseDesc).append('_').append(count).toString());
						result.put(key, value);
					}
				}
				return result;

			}, custId, userId);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}

	}

	@Override
	public List<EEMWFSupervisorUserDO> getSupervisorUsers(String customerId, String supOrAdminId, String userId) {

		String userCond;
		String supvisorCond;

		if (StringUtils.isNotBlank(userId)) {
			userCond = "AND U.USER_ID = :userId";
		} else {
			userCond = EEMConstants.BLANK;
		}

		if (StringUtils.isNotBlank(supOrAdminId)) {
			supvisorCond = "AND (U.MANAGER_ID =:supOrAdminId OR U.USER_ID =:supOrAdminId)";
		} else {
			supvisorCond = EEMConstants.BLANK;
		}

		StringBuilder query = CommonUtils.buildQueryBuilder(
				"SELECT USER_ID, USER_LEVEL, UPPER(TRIM(LAST_NAME)) || SPACE(1) || UPPER(TRIM(FIRST_NAME)) AS NAME, USER_STATUS,",
				"INACTIVE_START_DATE, INACTIVE_END_DATE, PRTY_METHOD, P1 AS PRIORITY1, P2 AS PRIORITY2,",
				"P3 AS PRIORITY3, P4 AS PRIORITY4 FROM (SELECT DISTINCT S.USER_ID, S.FIRST_NAME,",
				"S.LAST_NAME, U.USER_STATUS, U.INACTIVE_START_DATE, U.INACTIVE_END_DATE, U.PRTY_METHOD,",
				"C.QUEUE_NAME, U.USER_LEVEL, CASE WHEN P.PRTY_NBR = 1 THEN C.QUEUE_DESC ELSE ' ' END AS P1,",
				"CASE WHEN P.PRTY_NBR = 2 THEN C.QUEUE_DESC ELSE ' ' END AS P2,",
				"CASE WHEN P.PRTY_NBR = 3 THEN C.QUEUE_DESC ELSE ' ' END AS P3,",
				"CASE WHEN P.PRTY_NBR = 4 THEN C.QUEUE_DESC ELSE ' ' END AS P4",
				"FROM SECUSER S JOIN EM_WF_USER U ON S.USER_ID= U.USER_ID",
				"LEFT OUTER JOIN EM_WF_USERQ_PRIORITY P ON U.CUSTOMER_ID=P.CUSTOMER_ID AND U.OVERIDE_IND= P.OVERIDE_IND AND U.USER_ID= P.USER_ID",
				"LEFT OUTER JOIN EM_WF_CASE_QUEUE C ON U.CUSTOMER_ID=C.CUSTOMER_ID AND U.OVERIDE_IND= C.OVERIDE_IND AND C.QUEUE_CD = P. QUEUE_CD",
				"WHERE S.ACTIVE_YN != 'N'", supvisorCond, "AND U.CUSTOMER_ID =:customerId AND U.OVERIDE_IND = 'N'",
				userCond, ") MQ ORDER BY USER_LEVEL, LAST_NAME");

		Map<String, Object> params = new HashMap<>();
		params.put("supOrAdminId", supOrAdminId);
		params.put(USER_ID, userId);
		params.put(CUSTOMER_ID, customerId);

		try {
			return namedParameterJdbcTemplate.query(query.toString(), params,
					new DomainPropertyRowMapper<EEMWFSupervisorUserDO>(EEMWFSupervisorUserDO.class));
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public Map<String, List<String>> getDashletData(String custId, String searchUserId) {
		Map<String, String> paramMap = new HashMap<>();
		paramMap.put(CUST_ID, custId);

		String query = buildDashletQuery(searchUserId, paramMap);

		try {

			Map<String, String> caseDescMap = getCaseDescMap(custId);
			return namedParameterJdbcTemplate.query(query, paramMap, rs -> {

				Map<String, List<String>> result = new HashMap<>();
				List<String> value;

				while (rs.next()) {
					String count = EEMConstants.BLANK;
					String queueName = EEMConstants.BLANK;
					String caseDesc;
					String caseStatus = rs.getString(CASE_STATUS).trim();
					String queueNameWithCount = rs.getString("CASE_DESC").trim();

					if (StringUtils.isNotBlank(queueNameWithCount)) {
						String[] tokens = queueNameWithCount.split(EEMConstants.DASHLETCOUNT_SEPARATOR);
						queueName = tokens[0];
						count = tokens[1];
					}

					if (!CollectionUtils.isEmpty(caseDescMap) && Objects.nonNull(caseDescMap.get(queueName))) {
						caseDesc = caseDescMap.get(queueName);
						caseDesc = new StringBuilder(caseDesc).append(EEMConstants.DASHLETCOUNT_SEPARATOR).append(count)
								.append(EEMConstants.DASHLETCOUNT_SEPARATOR).append(queueName).toString();
					} else {
						caseDesc = new StringBuilder(queueNameWithCount).append(EEMConstants.DASHLETCOUNT_SEPARATOR)
								.append(queueName).toString();
					}

					if (result.containsKey(caseStatus)) {
						result.get(caseStatus).add(caseDesc);
					} else {
						value = new ArrayList<>();
						value.add(caseDesc);
						result.put(caseStatus, value);
					}
				}
				return result;
			});

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	private String buildDashletQuery(String searchUserId, Map<String, String> paramMap) {
		StringBuilder query;
		String from = " AS CASE_DESC FROM EM_WF_CASE WHERE ";
		String condition1 = " OVERRIDE_IND = 'N' AND CASE_STATUS != 'CLOSED' AND CUSTOMER_ID = :custId ";
		String conditionUserId = " AND CURRENT_USER_ID = :userId ";

		if (StringUtils.equalsIgnoreCase(EEMConstants.ASSIGNED, searchUserId)) {
			searchUserId = EEMConstants.UNASSIGNED;
			conditionUserId = " AND CURRENT_USER_ID != :userId ";
		}

		String riskInd = " AND RISK_IND ='Y' ";
		String groupBy1 = " GROUP BY CASE_DESC, CASE_STATUS ";
		String groupBy2 = " GROUP BY CASE_DESC ";

		if (StringUtils.isNotBlank(searchUserId)) {
			query = CommonUtils.buildQueryBuilder("SELECT CASE_STATUS, CASE_DESC FROM (",
					"SELECT CASE_STATUS, TRIM(CASE_DESC) ||'_' || COUNT(DISTINCT CASE_ID) AS CASE_DESC",
					"FROM EM_WF_CASE WHERE", condition1, conditionUserId, groupBy1);
			paramMap.put(USER_ID, searchUserId);
		} else {
			query = CommonUtils.buildQueryBuilder("SELECT CASE_STATUS, CASE_DESC FROM (",
					"SELECT CASE_STATUS, TRIM(CASE_DESC) ||'_' || COUNT(DISTINCT CASE_ID) AS CASE_DESC",
					"FROM EM_WF_CASE WHERE", condition1, groupBy1);
		}
		query.append(UNION);
		query.append("SELECT 'ATRISK' AS CASE_STATUS, TRIM(CASE_DESC) ||'_' || COUNT(DISTINCT CASE_ID)");
		query.append(from).append(condition1);

		if (StringUtils.isNotBlank(searchUserId)) {
			query.append(conditionUserId);
		}
		query.append(riskInd).append(groupBy2);
		query.append(UNION);
		query.append("SELECT 'ASSIGNED' AS CASE_STATUS, TRIM(CASE_DESC) ||'_' || COUNT(DISTINCT CASE_ID)");
		query.append(from).append(condition1).append(" AND CURRENT_USER_ID != 'UNASSIGNED' ").append(groupBy2);
		query.append(UNION);
		query.append("SELECT 'UNASSIGNED' AS CASE_STATUS, TRIM(CASE_DESC) ||'_' || COUNT(DISTINCT CASE_ID)");
		query.append(from).append(condition1).append(" AND CURRENT_USER_ID = 'UNASSIGNED' ").append(groupBy2)
				.append(") datatable");
		return query.toString();
	}

	@Override
	public void updatePriority(EMWFQueAsgnGrpVO eMWFQueAsgnVO, List<EMWFQueAsgnGrpVO> updateList) {
		String sql = CommonUtils.buildQuery(
				"UPDATE EM_WF_USERQ_PRIORITY SET OVERIDE_IND = ?, LAST_UPDT_TIME = ? WHERE CUSTOMER_ID = ?",
				"AND USER_ID = ? AND OVERIDE_IND = ? AND ACTIVE_IND = ? AND QUEUE_CD = ? AND PRTY_NBR = ?");
		try {
			jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					ps.setString(1, EEMConstants.VALUE_YES);
					ps.setString(2, DateUtil.getCurrentDatetimeStamp());
					ps.setString(3, eMWFQueAsgnVO.getCustomerId());
					ps.setString(4, eMWFQueAsgnVO.getUserId());
					ps.setString(5, EEMConstants.VALUE_NO);
					ps.setString(6, "A");
					ps.setString(7, updateList.get(i).getQueueCd());
					ps.setInt(8, updateList.get(i).getPrtyNum());
				}

				public int getBatchSize() {
					return updateList.size();
				}
			});
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}

	}

	@Override
	public void insertPriority(EMWFQueAsgnGrpVO eMWFQueAsgnVO, List<EMWFQueAsgnGrpVO> insertList) {

		String sql = "INSERT INTO EM_WF_USERQ_PRIORITY VALUES(?,?,?,?,?,?,?,?,?,?)";

		try {
			jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					ps.setString(1, eMWFQueAsgnVO.getCustomerId());
					ps.setString(2, eMWFQueAsgnVO.getUserId());
					ps.setString(3, DateUtil.getCurrentDatetimeStamp());
					ps.setString(4, insertList.get(i).getQueueCd());
					ps.setInt(5, insertList.get(i).getPrtyNum());
					ps.setString(6, "A");
					ps.setString(7, EEMConstants.VALUE_NO);
					ps.setString(8, eMWFQueAsgnVO.getLoginUserId());
					ps.setString(9, DateUtil.getCurrentDatetimeStamp());
					ps.setString(10, eMWFQueAsgnVO.getLoginUserId());
					try {
						Thread.sleep(1);
					} catch (Exception e) {
						LOG.error("exception occured", e);
					}
				}

				public int getBatchSize() {
					return insertList.size();
				}
			});
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_INSERT);
		}
	}

	@Override
	public Map<String, List<LabelValuePair>> getNewUserList(String customerId) {
		StringBuilder query = CommonUtils.buildQueryBuilder(
				"SELECT DISTINCT SU.USER_ID, UPPER(TRIM(SU.LAST_NAME)) || SPACE(1) || UPPER(TRIM(SU.FIRST_NAME)) AS USERNAME, ",
				" CASE WHEN SG.GROUP_NAME IN ('Business Analyst Admin','Enrollment Supervisor','Enrollment Principal','Enrollment Representative') THEN 'SUPERVISOR' ELSE 'USER' END AS ROLE",
				" FROM SECUSER SU JOIN SECGROUP SG ON SU.GROUP_ID = SG.GROUP_ID",
				" WHERE SU.USER_ID NOT IN(SELECT USER_ID FROM EM_WF_USER) AND SU.ACTIVE_YN != 'N' AND SG.MF_ID='"
						+ customerId + "' ",
				" AND GROUP_NAME != 'Read Only' ORDER BY USERNAME ");

		String sKey = "ROLE";
		String sName = "USERNAME";
		String sValue = USER_ID_COL;

		return eemPersistence.getMap(query.toString(), sKey, sName, sValue);
	}

	@Override
	public Map<String, List<LabelValuePair>> getWfUsersList(String customerId) {
		StringBuilder query = CommonUtils.buildQueryBuilder(
				"SELECT DISTINCT WF.USER_ID USER_ID, UPPER(SU.LAST_NAME) || SPACE(1) || UPPER(SU.FIRST_NAME) AS NAME, WF.USER_LEVEL FROM SECUSER SU, ",
				"EM_WF_USER WF WHERE WF.USER_STATUS='A' AND WF.CUSTOMER_ID= '" + customerId + "' ",
				"AND SU.USER_ID = WF.USER_ID AND WF.OVERIDE_IND = 'N' AND WF.USER_LEVEL IN('1','2') AND SU.ACTIVE_YN != 'N' ORDER BY USER_LEVEL,NAME");

		String sKey = USER_LEVEL;
		String sName = "NAME";
		String sValue = USER_ID_COL;

		return eemPersistence.getMap(query.toString(), sKey, sName, sValue);
	}

	@Override
	public int addNewUser(String userLevel, String userId, String managerId, String loggedInUserId, String customerId) {
		List<Object> params = new ArrayList<>();
		try {
			StringBuilder query = CommonUtils.buildQueryBuilder(
					"INSERT INTO EM_WF_USER (CUSTOMER_ID, USER_ID, MANAGER_ID, CREATE_TIME, USER_STATUS, USER_LEVEL, ",
					"INACTIVE_START_DATE, INACTIVE_END_DATE, PRTY_METHOD, OVERIDE_IND, CREATE_USERID, LAST_UPDT_USERID, LAST_UPDT_TIME) VALUES ",
					"(?, ?, ?, ?, 'A', ?, '', '', 'Q', 'N', ?, ?, ?)");

			params.add(customerId);
			params.add(userId);
			params.add(managerId);
			params.add(DateUtil.getCurrentDatetimeStamp());
			params.add(userLevel);
			params.add(loggedInUserId);
			params.add(loggedInUserId);
			params.add(DateUtil.getCurrentDatetimeStamp());

			Object[] objPrams = params.toArray();

			return jdbcTemplate.update(query.toString(), objPrams);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_INSERT);
		}
	}

	@Override
	public List<EEMWFUserDO> searchUser(String customerId, String name, String managerId) {
		Map<String, Object> params = new HashMap<>();
		try {
			StringBuilder query = CommonUtils.buildQueryBuilder(
					"SELECT WF.MANAGER_ID, WF.USER_ID, CASE WHEN WF.USER_LEVEL = '1' THEN 'ADMIN' ",
					"ELSE (CASE WHEN WF.USER_LEVEL = '2' THEN 'SUPERVISOR'",
					"ELSE (CASE WHEN WF.USER_LEVEL = '3' THEN 'USER' ELSE 'NO ACCESS' END) END) END AS USER_LEVEL,",
					"MAX(CASE WHEN WF.USER_ID = SU.USER_ID THEN SU.LAST_NAME || SPACE(1) || SU.FIRST_NAME ELSE ' ' END ) AS USERNAME,",
					"MAX(CASE WHEN WF.MANAGER_ID = SM.USER_ID THEN SM.LAST_NAME || SPACE(1) || SM.FIRST_NAME END ) AS SUPERVISORNAME",
					"FROM EM_WF_USER WF JOIN SECUSER SU ON WF.USER_ID = SU.USER_ID",
					"JOIN SECUSER SM ON WF.MANAGER_ID = SM.USER_ID",
					"WHERE WF.CUSTOMER_ID= :customerId AND WF.OVERIDE_IND = 'N'");

			params.put(CUSTOMER_ID, customerId);

			if (StringUtils.isNotBlank(name)) {
				name = StringUtils.trim(name);
				String[] nameTokens = name.split("\\s+");
				if (Objects.nonNull(nameTokens) && nameTokens.length >= 2) {
					String firstname = StringUtils.upperCase(nameTokens[0]);
					String lastname = StringUtils.upperCase(nameTokens[1]);
					query.append("AND (UPPER(SU.FIRST_NAME) LIKE :firstname AND UPPER(SU.LAST_NAME) LIKE :lastname) ");
					query.append("OR (UPPER(SU.FIRST_NAME) LIKE :lastname  AND UPPER(SU.LAST_NAME) LIKE :firstname) ");
					params.put("firstname", new StringBuilder(firstname).append("%").toString());
					params.put("lastname", new StringBuilder(lastname).append("%").toString());
				} else {
					query.append("AND UPPER(SU.FIRST_NAME) LIKE :firstname OR UPPER(SU.LAST_NAME) LIKE :lastname ");
					name = new StringBuilder(StringUtils.upperCase(name)).append("%").toString();
					params.put("firstname", name);
					params.put("lastname", name);
				}
			}

			if (StringUtils.isNotBlank(managerId)) {
				query.append(" AND WF.MANAGER_ID = :managerId");
				params.put("managerId", managerId);
			}

			query.append(" GROUP BY WF.MANAGER_ID, WF.USER_ID, USER_LEVEL ORDER BY USERNAME");

			return namedParameterJdbcTemplate.query(query.toString(), params,
					new DomainPropertyRowMapper<EEMWFUserDO>(EEMWFUserDO.class));

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public int updateUser(String userLevel, String userId, String managerId, String loggedInUserId, String customerId) {
		int sqlCnt = 0;
		try {
			StringBuilder query = CommonUtils.buildQueryBuilder("UPDATE EM_WF_USER ",
					" SET OVERIDE_IND = 'Y', LAST_UPDT_TIME = ? , LAST_UPDT_USERID = ?",
					" WHERE CUSTOMER_ID = ? AND USER_ID = ? AND OVERIDE_IND = 'N'");

			Object[] parms = new Object[] { DateUtil.getCurrentDatetimeStamp(), loggedInUserId, customerId, userId };

			sqlCnt = jdbcTemplate.update(query.toString(), parms);

			if (sqlCnt == 1) {
				sqlCnt = addNewUser(userLevel, userId, managerId, loggedInUserId, customerId);
			} else {
				throw new ApplicationException("More than one user found!");
			}
			return sqlCnt;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}
	}

	@Override
	public String getSupervisorId(String customerId, String currentUserId) {
		String sql = CommonUtils.buildQuery("SELECT MANAGER_ID FROM EM_WF_USER WHERE USER_ID = ?",
				"AND CUSTOMER_ID = ? AND OVERIDE_IND = 'N'");
		try {
			return jdbcTemplate.queryForObject(sql, new Object[] { currentUserId, customerId }, String.class);
		} catch (EmptyResultDataAccessException exp) {
			throw new ApplicationException(exp, String.format("No supervisor configured for %s !", currentUserId));
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public String getUserNameByUserId(String userId) {
		String sql = "SELECT UPPER(TRIM(FIRST_NAME)) || '_' || UPPER(TRIM(LAST_NAME)) AS NAME FROM SECUSER WHERE USER_ID = ?";
		try {
			return jdbcTemplate.queryForObject(sql, new Object[] { userId }, String.class);
		} catch (EmptyResultDataAccessException exp) {
			return userId;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public Map<String, String> getUserNamesByUserIds(List<String> userIds) {
		Map<String, Object> paramMap = new HashMap<>();
		Map<String, String> userNames = new HashMap<>();

		String sql = "SELECT TRIM(USER_ID), UPPER(TRIM(FIRST_NAME)) || '_' || UPPER(TRIM(LAST_NAME)) FROM SECUSER WHERE USER_ID in (:userIds)";

		paramMap.put("userIds", userIds);
		try {
			return namedParameterJdbcTemplate.query(sql, paramMap, rs -> {
				while (rs.next()) {
					String userId = rs.getString(1);
					String userName = rs.getString(2);
					userNames.put(userId, userName);
				}
				return userNames;
			});
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public List<LabelValuePair> getWFCaseDesc(String customerId) {
		String sql = "SELECT TRIM(QUEUE_NAME), TRIM(QUEUE_DESC) FROM EM_WF_CASE_QUEUE WHERE OVERIDE_IND = 'N' AND CUSTOMER_ID = ?";
		try {
			return jdbcTemplate.query(sql, rs -> {
				List<LabelValuePair> labelValuePairs = new ArrayList<>();
				while (rs.next()) {
					String value = rs.getString(1);
					String label = rs.getString(2);
					labelValuePairs.add(new LabelValuePair(value, label));
				}
				return labelValuePairs;
			}, customerId);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public Map<String, String> getCaseDescMap(String customerId) {
		String sql = "SELECT TRIM(QUEUE_NAME), TRIM(QUEUE_DESC) FROM EM_WF_CASE_QUEUE WHERE OVERIDE_IND = 'N' AND CUSTOMER_ID = ?";
		try {
			return jdbcTemplate.query(sql, rs -> {
				Map<String, String> result = new HashMap<>();
				while (rs.next()) {
					String queueName = rs.getString(1);
					String caseDesc = rs.getString(2);
					result.put(queueName, caseDesc);
				}
				return result;
			}, customerId);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public List<EEMWFCaseDO> getCasesForQueueCds(Set<String> queueCds, String custId, String userId) {
		String sql = CommonUtils.buildQuery("SELECT * FROM EM_WF_CASE WHERE QUEUE_CD IN (:queueCds)",
				"AND CUSTOMER_ID = :custId AND CURRENT_USER_ID = :userId AND CASE_STATUS != 'CLOSED' AND OVERRIDE_IND = 'N'");
		try {
			Map<String, Object> paramMap = new HashMap<>();
			paramMap.put("queueCds", queueCds);
			paramMap.put(CUST_ID, custId);
			paramMap.put(USER_ID, userId);
			return namedParameterJdbcTemplate.query(sql, paramMap,
					new DomainPropertyRowMapper<EEMWFCaseDO>(EEMWFCaseDO.class));
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public List<LabelValuePair> getQueueList(String customerId) {
		try {
			List<String> param = new ArrayList<>();
			String query = "SELECT QUEUE_CD, QUEUE_DESC FROM EM_WF_CASE_QUEUE WHERE CUSTOMER_ID= ? AND OVERIDE_IND ='N'";
			String value = QUEUE_CD;
			String label = "QUEUE_DESC";
			param.add(customerId);
			return eemPersistence.getLabelValuePairList(query, param.toArray(), value, label);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	private int updateWfCase(EEMWfAssignOrTransDO assignOrTransDO) {
		String ts = DateUtil.getCurrentDatetimeStamp();
		int count = 0;
		StringBuilder sql = CommonUtils.buildQueryBuilder("UPDATE EM_WF_CASE SET OVERRIDE_IND = 'Y',",
				"LAST_UPDT_USERID= :lastUpdtUsrId, LAST_UPDT_TIME = :lastUpdtTime",
				"WHERE CUSTOMER_ID = :customerId AND CASE_ID = :caseId",
				"AND QUEUE_CD = :queueCd AND OVERRIDE_IND = :overrideInd", "AND MEDICARE_ID = :medicareId");

		if (!assignOrTransDO.isCaseStateUpdate()) {
			sql.append(" AND CASE_STATUS != 'CLOSED'");
		}

		try {
			List<MapSqlParameterSource> batchArgs = new ArrayList<>();
			for (EEMWFCaseDO caseDO : assignOrTransDO.getCaseList()) {
				MapSqlParameterSource params = new MapSqlParameterSource();

				params.addValue("lastUpdtUsrId", assignOrTransDO.getFromUserId());
				params.addValue(LAST_UPDT_TIME, ts);
				params.addValue(CUSTOMER_ID, assignOrTransDO.getCustomerId());
				params.addValue(CASE_ID, caseDO.getCaseId());
				params.addValue("queueCd", caseDO.getQueueCode());
				params.addValue("currentUserId", assignOrTransDO.getFromUserId());
				params.addValue(OVERRIDE_IND, EEMConstants.VALUE_NO);
				params.addValue("medicareId", caseDO.getMedicareId());

				batchArgs.add(params);
			}

			if (!CollectionUtils.isEmpty(batchArgs)) {
				int[] batchUpdates = namedParameterJdbcTemplate.batchUpdate(sql.toString(),
						batchArgs.toArray(new MapSqlParameterSource[assignOrTransDO.getCaseList().size()]));

				for (int i = 0; i < batchUpdates.length; i++) {
					if (batchUpdates[i] != 0) {
						++count;
					}
				}
			}
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}
		return count;
	}

	private int insertWfCase(EEMWfAssignOrTransDO assignOrTransDO) {
		String ts = DateUtil.getCurrentDatetimeStamp();
		String todaysDate = DateUtil.getTodaysDate("yyyyMMdd");
		int count = 0;
		String sql = CommonUtils.buildQuery(
				"INSERT INTO EM_WF_CASE(CUSTOMER_ID, CASE_ID, CURRENT_USER_ID, LAST_UPDT_TIME,",
				"CASE_TIMESTAMP, APPLICATION_ID, MEMBER_ID, SUPPLEMENTAL_ID, MEDICARE_ID, QUEUE_CD,",
				"CASE_DATE, CASE_DUE_DATE, DAYS_REMAINING, CASE_DESC, CASE_STATUS, RISK_IND,",
				"MEMBER_NAME, CASE_REASSIGN_DATE, INITIAL_USER_ID, REASSIGN_TYPE_CD, OVERRIDE_IND, LAST_UPDT_USERID)",
				"VALUES(:customerId, :caseId, :currentUserId, :lastUpdtTime, :caseTimeStamp,",
				":appId, :mbrId, :supplId, :medicareId, :queueCd, :caseDate, :caseDueDate, :daysRemaining, :caseDesc,",
				":caseStatus, :riskInd, :mbrName, :caseRessignDate, :initialUsrId, :reAsssignTypeCd, :overrideInd, :lastUpdtUsrId)");

		try {
			List<MapSqlParameterSource> batchArgs = new ArrayList<>();
			for (EEMWFCaseDO caseDO : assignOrTransDO.getCaseList()) {
				MapSqlParameterSource params = new MapSqlParameterSource();

				params.addValue(CUSTOMER_ID, assignOrTransDO.getCustomerId());
				params.addValue(CASE_ID, caseDO.getCaseId());
				params.addValue("currentUserId", assignOrTransDO.getToUserId());
				if (assignOrTransDO.isCaseStateUpdate()) {
					params.addValue(LAST_UPDT_TIME, DateUtil.getCurrentDatetimeStampPlus(200));
					params.addValue("reAsssignTypeCd", caseDO.getReAssignTypeCode());
				} else {
					params.addValue(LAST_UPDT_TIME, ts);
					params.addValue("reAsssignTypeCd", assignOrTransDO.getReassignTypeCd());
				}
				params.addValue("caseTimeStamp", caseDO.getCaseTimeStamp());
				params.addValue("appId", caseDO.getAppId());
				params.addValue("mbrId", caseDO.getMbrId());
				params.addValue("supplId", caseDO.getSupplementalId());
				params.addValue("medicareId", caseDO.getMedicareId());
				params.addValue("queueCd", caseDO.getQueueCode());
				params.addValue("caseDate", caseDO.getCaseDate());
				params.addValue("caseDueDate", caseDO.getCaseDueDate());
				params.addValue("daysRemaining", caseDO.getDaysRemaining());
				if (assignOrTransDO.isManualTransfer()) {
					params.addValue("caseDesc", caseDO.getQueueName());
				} else {
					params.addValue("caseDesc", caseDO.getCaseDesc());
				}
				params.addValue("caseStatus", caseDO.getCaseStatus());
				params.addValue("riskInd", caseDO.getRiskInd());
				params.addValue("mbrName", caseDO.getMbrName());
				params.addValue("caseRessignDate", todaysDate);
				params.addValue("initialUsrId", caseDO.getInitialUserId());
				params.addValue(OVERRIDE_IND, EEMConstants.VALUE_NO);
				params.addValue("lastUpdtUsrId", assignOrTransDO.getFromUserId());

				batchArgs.add(params);
			}

			if (!CollectionUtils.isEmpty(batchArgs)) {
				int[] batchUpdates = namedParameterJdbcTemplate.batchUpdate(sql,
						batchArgs.toArray(new MapSqlParameterSource[assignOrTransDO.getCaseList().size()]));

				for (int i = 0; i < batchUpdates.length; i++) {
					if (batchUpdates[i] != 0) {
						++count;
					}
				}
			}
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_INSERT);
		}
		return count;
	}

	@Override
	public List<EEMWFCaseDO> getCasesByUserId(String userId, String customerId) {
		String sql = CommonUtils.buildQuery("SELECT * FROM EM_WF_CASE WHERE CURRENT_USER_ID = ? AND OVERRIDE_IND = 'N'",
				"AND CUSTOMER_ID = ? AND CASE_STATUS != 'CLOSED'");
		try {
			return jdbcTemplate.query(sql, new DomainPropertyRowMapper<EEMWFCaseDO>(EEMWFCaseDO.class), userId,
					customerId);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public int getNextCaseId(String customerId) {
		String sql = "SELECT MAX(CASE_ID)+1 FROM EM_WF_CASE WHERE CUSTOMER_ID = ?";
		try {
			return jdbcTemplate.queryForObject(sql, Integer.class, customerId);
		} catch (DataAccessException exp) {
			LOG.error("Error occured while EEMWfDAOImpl::getNextCaseId, full stack trace follows:", exp);
			return 0;
		}
	}

	@Override
	public Map<String, String> checkAndGetQueueChars(String customerId, int applId, String queueCd) {
		Map<String, String> result = new HashMap<>();
		String sql = CommonUtils.buildQuery("SELECT C.QUEUE_NAME, C.COMP_DAYS",
				"FROM EM_APPL_ERROR E, EM_APPLICATION A, EM_WF_CASE_SUBQUEUE Q,",
				"EM_WF_CASE_QUEUE C WHERE E.CUSTOMER_ID = A.CUSTOMER_ID AND E.CUSTOMER_ID = Q.CUSTOMER_ID",
				"AND C.CUSTOMER_ID = E.CUSTOMER_ID AND C.QUEUE_CD = Q.QUEUE_CD",
				"AND E.APPLICATION_ID = A.APPLICATION_ID AND E.ERROR_CD = Q.ERROR_ID",
				"AND E.CUSTOMER_ID = ? AND E.ERROR_STATUS = 'OPEN'",
				"AND A.APPLICATION_ID = ? AND A.APPLICATION_STATUS NOT IN",
				"('DUPLAPPL', 'COMPLETED', 'DENIEDELG', 'DENIEDETYP', 'DENIEDOTHR',",
				"'CANCELED','DUPLENRL') AND C.OVERIDE_IND = 'N' AND Q.QUEUE_CD = ? FETCH FIRST ROW ONLY");

		try {
			return jdbcTemplate.query(sql, rs -> {
				if (rs.next()) {
					int compDays = rs.getInt("COMP_DAYS");
					result.put("QUEUE_NAME", rs.getString("QUEUE_NAME"));
					result.put("COMP_DAYS", String.valueOf(compDays));
				}
				return result;
			}, customerId, applId, queueCd);
		} catch (DataAccessException exp) {
			LOG.error("Error occured while EEMWfDAOImpl::checkAndGetQueueChars, full stack trace follows:", exp);
			return result;
		}
	}

	@Override
	public boolean isCaseExists(String customerId, int applId) {
		int count = 0;
		String sql = CommonUtils.buildQuery("SELECT COUNT(*) FROM EM_WF_CASE WHERE CUSTOMER_ID = ?",
				"AND APPLICATION_ID = ? AND OVERRIDE_IND = 'N'");
		try {
			count = jdbcTemplate.queryForObject(sql, new Object[] { customerId, applId }, Integer.class);
		} catch (DataAccessException exp) {
			LOG.error("Error occured while EEMWfDAOImpl::isCaseExists, full stack trace follows:", exp);
			return false;
		}
		return count > 0;
	}

	@Override
	public boolean createCase(EEMWFCaseDO caseDO) {
		int count = 0;
		List<String> params = new ArrayList<>();
		params.add(caseDO.getCustomerId());
		params.add(String.valueOf(caseDO.getCaseId()));
		params.add(caseDO.getCurrentUserId());
		params.add(caseDO.getLastUpdtTime());
		params.add(caseDO.getCaseTimeStamp());
		params.add(caseDO.getAppId());
		params.add(caseDO.getMbrId());
		params.add(caseDO.getSupplementalId());
		params.add(caseDO.getMedicareId());
		params.add(caseDO.getQueueCode());
		params.add(caseDO.getCaseDate());
		params.add(caseDO.getCaseDueDate());
		params.add(caseDO.getDaysRemaining());
		params.add(caseDO.getCaseDesc());
		params.add(caseDO.getCaseStatus());
		params.add(caseDO.getRiskInd());
		params.add(caseDO.getMbrName());
		params.add(caseDO.getCaseReassignDate());
		params.add(caseDO.getInitialUserId());
		params.add(caseDO.getReAssignTypeCode());
		params.add(EEMConstants.VALUE_NO);
		params.add(caseDO.getLastUpdtUserId());
		String sql = CommonUtils.buildQuery(
				"INSERT INTO EM_WF_CASE(CUSTOMER_ID, CASE_ID, CURRENT_USER_ID, LAST_UPDT_TIME,",
				"CASE_TIMESTAMP, APPLICATION_ID, MEMBER_ID, SUPPLEMENTAL_ID, MEDICARE_ID, QUEUE_CD,",
				"CASE_DATE, CASE_DUE_DATE, DAYS_REMAINING, CASE_DESC, CASE_STATUS, RISK_IND,",
				"MEMBER_NAME, CASE_REASSIGN_DATE, INITIAL_USER_ID, REASSIGN_TYPE_CD, OVERRIDE_IND, LAST_UPDT_USERID)",
				"VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
		try {
			count = jdbcTemplate.update(sql, params.toArray());
		} catch (DataAccessException exp) {
			LOG.error("Error occured while EEMWfDAOImpl::createCase, full stack trace follows:", exp);
			return false;
		}
		return count > 0;
	}

	@Override
	public boolean isActivityExists(String customerId, int caseId, String errorCd) {
		int count = 0;
		String sql = CommonUtils.buildQuery("SELECT COUNT(*) FROM EM_WF_ACTIVITY WHERE CUSTOMER_ID = ?",
				"AND CASE_ID = ? AND ERROR_ID = ?");
		try {
			count = jdbcTemplate.queryForObject(sql, new Object[] { customerId, caseId, errorCd }, Integer.class);
		} catch (DataAccessException exp) {
			LOG.error("Error occured while EEMWfDAOImpl::isActivityExists, full stack trace follows:", exp);
			return false;
		}
		return count > 0;
	}

	@Override
	public Map<String, Integer> getApplCommentIndicators(String custId, List<String> applIdList) {
		Map<String, Integer> resultMap = new HashMap<>();
		if (CollectionUtils.isEmpty(applIdList)) {
			return resultMap;
		}

		try {
			String sql = CommonUtils.buildQuery(
					"SELECT TRIM(APPLICATION_ID), COUNT (APPL_COMMENTS) FROM EM_APPL_COMMENT",
					"WHERE CUSTOMER_ID = :custId AND APPLICATION_ID IN (:applIdList) AND UPPER(APPL_COMMENTS)",
					"LIKE :applCommentPrefix GROUP BY APPLICATION_ID");
			Map<String, Object> paramMap = new HashMap<>();
			paramMap.put(CUST_ID, custId);
			paramMap.put("applIdList", applIdList);
			paramMap.put("applCommentPrefix", CommonUtils.appendStrings(EEMConstants.COMMENT_PRESET, "%"));
			return namedParameterJdbcTemplate.query(sql, paramMap, rs -> {
				while (rs.next()) {
					resultMap.put(rs.getString(1), rs.getInt(2));
				}
				return resultMap;
			});
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public Map<String, Integer> getMbrCommentIndicators(String custId, List<String> mbrIdList) {
		Map<String, Integer> resultMap = new HashMap<>();
		if (CollectionUtils.isEmpty(mbrIdList)) {
			return resultMap;
		}

		try {
			String sql = CommonUtils.buildQuery("SELECT TRIM(MEMBER_ID), COUNT (MBR_COMMENTS) FROM EM_MBR_COMMENTS",
					"WHERE CUSTOMER_ID = :custId AND MEMBER_ID IN (:mbrIdList) AND UPPER(MBR_COMMENTS)",
					"LIKE :mbrCommentPrefix GROUP BY MEMBER_ID");
			Map<String, Object> paramMap = new HashMap<>();
			paramMap.put(CUST_ID, custId);
			paramMap.put("mbrIdList", mbrIdList);
			paramMap.put("mbrCommentPrefix", CommonUtils.appendStrings(EEMConstants.COMMENT_PRESET, "%"));
			return namedParameterJdbcTemplate.query(sql, paramMap, rs -> {
				while (rs.next()) {
					resultMap.put(rs.getString(1), rs.getInt(2));
				}
				return resultMap;
			});
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public boolean addWFApplComment(EEMWFCommentVO wfCommentVo) {
		int count = 0;
		ArrayList<Object> params = new ArrayList<>();
		String sql = CommonUtils.buildQuery("INSERT INTO EM_APPL_COMMENT ",
				"(CUSTOMER_ID, APPLICATION_ID, COMMENT_SEQ_NBR, APPL_COMMENTS, CREATE_TIME,",
				"CREATE_USERID) VALUES(?,?,?,?,?,?)");

		params.add(wfCommentVo.getCustomerId());
		params.add(wfCommentVo.getPrimaryId());
		params.add(wfCommentVo.getCommentSeqNbr());
		params.add(wfCommentVo.getComments());
		params.add(wfCommentVo.getCreateTime());
		params.add(wfCommentVo.getCreateUserId());

		try {
			count = jdbcTemplate.update(sql, params.toArray());
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_INSERT);
		}
		return count > 0;
	}

	@Override
	public boolean checkUserQueueAccess(String userId, String customerId, String queueCd) {
		int count = 0;
		String sql = CommonUtils.buildQuery("SELECT COUNT(*) FROM EM_WF_USERQ_PRIORITY WHERE CUSTOMER_ID = ?",
				"AND OVERIDE_IND = 'N' AND USER_ID = ? AND QUEUE_CD = ?");
		try {
			count = jdbcTemplate.queryForObject(sql, new Object[] { customerId, userId, queueCd }, Integer.class);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
		return count > 0;
	}

	@Override
	public boolean createActivities(String customerId, String userId, int caseId, List<String> errorCds,
			List<String> errorMsgs) {
		int count = 0;
		Map<String, Object> paramMap = new HashMap<>();
		List<LabelValueKeyPair> pairs = new ArrayList<>();

		try {
			String sql = CommonUtils.buildQuery("SELECT QUEUE_CD, SUB_QUEUE_CD, ERROR_ID FROM EM_WF_CASE_SUBQUEUE",
					"WHERE ERROR_ID IN (:errorCds) AND CUSTOMER_ID= :customerId");

			paramMap.put("errorCds", errorCds);
			paramMap.put(CUSTOMER_ID, customerId);

			List<LabelValueKeyPair> labelValueKeyPairs = namedParameterJdbcTemplate.query(sql, paramMap, rs -> {
				while (rs.next()) {
					pairs.add(new LabelValueKeyPair(nonNullTrim(rs.getString("SUB_QUEUE_CD")),
							nonNullTrim(rs.getString(QUEUE_CD)), nonNullTrim(rs.getString("ERROR_ID"))));
				}
				return pairs;
			});

			if (CommonUtils.isNotEmpty(labelValueKeyPairs)) {
				String insertQuery = buildActivityInsertQuery();

				int[] batchUpdates = jdbcTemplate.batchUpdate(insertQuery, new BatchPreparedStatementSetter() {
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						ps.setString(1, customerId);
						ps.setInt(2, caseId);
						ps.setString(3, labelValueKeyPairs.get(i).getKey());
						ps.setString(4, DateUtil.getCurrentDatetimeStamp());
						ps.setString(5, labelValueKeyPairs.get(i).getLabel());
						ps.setString(6, labelValueKeyPairs.get(i).getValue());
						ps.setString(7, errorMsgs.get(i));
						ps.setString(8, EEMConstants.OPEN);
						ps.setString(9, userId);
						ps.setString(10, DateUtil.getCurrentDatetimeStamp());
					}

					public int getBatchSize() {
						return labelValueKeyPairs.size();
					}
				});

				for (int i = 0; i < batchUpdates.length; i++) {
					if (batchUpdates[i] != 0) {
						++count;
					}
				}
			}
		} catch (DataAccessException exp) {
			LOG.error("Error occured while EEMWfDAOImpl::createActivity, full stack trace follows:", exp);
			return false;
		}
		return count > 0;
	}

	@Override
	public List<LabelValuePair> fetchAssignedWfUsers(String customerId, String loggedInUsrId, int userLevel) {
		List<LabelValuePair> labelValuePairs = new ArrayList<>();
		String sql = CommonUtils.buildQuery(
				"SELECT UPPER(TRIM(s.FIRST_NAME)) || SPACE(1) || UPPER(TRIM(s.LAST_NAME)) AS USER_NAME,",
				"TRIM(u.USER_ID) AS USER_ID FROM EM_WF_USER u JOIN SECUSER s ON u.USER_ID = s.USER_ID WHERE",
				"CUSTOMER_ID = ? AND u.OVERIDE_IND = 'N' AND u.MANAGER_ID = ? AND u.USER_LEVEL = ? ORDER BY USER_NAME");
		try {
			return jdbcTemplate.query(sql, new Object[] { customerId, loggedInUsrId, userLevel }, rs -> {
				while (rs.next()) {
					labelValuePairs.add(new LabelValuePair(rs.getString(USER_ID_COL), rs.getString("USER_NAME")));
				}
				return labelValuePairs;
			});
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public boolean deleteManualPopupQueues(String custId, String userId, String queueName, String deleteAll,
			List<String> userIdList, String loggedInUserId) {
		int count = 0;
		Map<String, Object> paramMap = new HashMap<>();
		StringBuilder sql = CommonUtils.buildQueryBuilder(
				"SELECT c.* FROM EM_WF_CASE c JOIN EM_WF_CASE_QUEUE q ON c.CUSTOMER_ID = q.CUSTOMER_ID",
				"AND c.QUEUE_CD = q.QUEUE_CD AND c.OVERRIDE_IND = q.OVERIDE_IND WHERE c.OVERRIDE_IND = 'N'",
				"AND q.SCN_DISPLAY = 'POPUP' AND c.CASE_STATUS != 'CLOSED' AND c.CUSTOMER_ID = :custId");

		paramMap.put(CUST_ID, custId);

		if (StringUtils.equals(EEMConstants.VALUE_NO, deleteAll)) {
			if (StringUtils.isNotBlank(userId)) {
				sql.append(" AND c.CURRENT_USER_ID = :userId");
				paramMap.put(USER_ID, userId);
			}
			if (StringUtils.isNotBlank(queueName)) {
				sql.append(" AND c.CASE_DESC = :queueName");
				paramMap.put("queueName", queueName);

				if (StringUtils.isBlank(userId) && CommonUtils.isNotEmpty(userIdList)) {
					sql.append(" AND c.CURRENT_USER_ID IN (:userIdList)");
					paramMap.put(USER_ID_LIST, userIdList);
				}
			}
		} else {
			if (CommonUtils.isNotEmpty(userIdList)) {
				sql.append(" AND c.CURRENT_USER_ID IN (:userIdList)");
				paramMap.put(USER_ID_LIST, userIdList);
			}
		}

		List<EEMWFCaseDO> casesToBeDeleted = namedParameterJdbcTemplate.query(sql.toString(), paramMap,
				new DomainPropertyRowMapper<EEMWFCaseDO>(EEMWFCaseDO.class));

		if (!CollectionUtils.isEmpty(casesToBeDeleted)) {
			count = overrideCases(casesToBeDeleted, loggedInUserId);
			if (count != 0) {
				count = insertClosedCases(casesToBeDeleted, loggedInUserId);
			}
		}
		return count > 0;
	}

	@Override
	public Map<String, String> fetchManualPopupQueues(String custId, List<String> userIdList) {
		Map<String, Object> paramMap = new HashMap<>();
		String userIdCond = EEMConstants.BLANK;

		paramMap.put(CUST_ID, custId);
		if (CommonUtils.isNotEmpty(userIdList)) {
			userIdCond = "AND c.CURRENT_USER_ID IN (:userIdList)";
			paramMap.put(USER_ID_LIST, userIdList);
		}

		String sql = CommonUtils.buildQuery(
				"SELECT DISTINCT TRIM(q.QUEUE_DESC), TRIM(q.QUEUE_NAME), COUNT (q.QUEUE_NAME) FROM EM_WF_CASE c",
				"JOIN EM_WF_CASE_QUEUE q ON c.CUSTOMER_ID = q.CUSTOMER_ID AND c.QUEUE_CD = q.QUEUE_CD AND",
				"c.OVERRIDE_IND = q.OVERIDE_IND WHERE c.OVERRIDE_IND = 'N' AND q.SCN_DISPLAY = 'POPUP'",
				"AND c.CASE_STATUS != 'CLOSED' AND c.CUSTOMER_ID = :custId", userIdCond,
				"GROUP BY q.QUEUE_DESC, q.QUEUE_NAME");
		try {
			return namedParameterJdbcTemplate.query(sql, paramMap, rs -> {
				Map<String, String> result = new HashMap<>();
				while (rs.next()) {
					String queueDesc = rs.getString(1);
					String queueName = rs.getString(2);
					Integer count = rs.getInt(3);
					String value = new StringBuilder(queueName).append('_').append(count).toString();
					result.put(queueDesc, value);
				}
				return result;
			});
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}

	}

	@Override
	public int overrideCases(List<EEMWFCaseDO> casesToBeDeleted, String userId) {
		int count = 0;
		try {
			String sql = CommonUtils.buildQuery(
					"UPDATE EM_WF_CASE SET OVERRIDE_IND = ?, LAST_UPDT_USERID = ?, LAST_UPDT_TIME = ?",
					"WHERE CUSTOMER_ID = ? AND CASE_ID = ? AND OVERRIDE_IND = ? AND CASE_STATUS != 'CLOSED'");

			int[] batchUpdates = jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					ps.setString(1, EEMConstants.VALUE_YES);
					ps.setString(2, userId);
					ps.setString(3, DateUtil.getCurrentDatetimeStamp());
					ps.setString(4, casesToBeDeleted.get(i).getCustomerId());
					ps.setInt(5, casesToBeDeleted.get(i).getCaseId());
					ps.setString(6, EEMConstants.VALUE_NO);
				}

				public int getBatchSize() {
					return casesToBeDeleted.size();
				}
			});

			for (int i = 0; i < batchUpdates.length; i++) {
				if (batchUpdates[i] != 0) {
					++count;
				}
			}
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}
		return count;
	}

	@Override
	public int insertClosedCases(List<EEMWFCaseDO> casesToBeDeleted, String userId) {
		int count = 0;
		try {
			String sql = CommonUtils.buildQuery("INSERT INTO EM_WF_CASE ",
					"(CUSTOMER_ID,CASE_ID,CURRENT_USER_ID,LAST_UPDT_TIME,CASE_TIMESTAMP,APPLICATION_ID,MEMBER_ID,",
					"SUPPLEMENTAL_ID,MEDICARE_ID,QUEUE_CD,CASE_DATE,CASE_DUE_DATE,DAYS_REMAINING,CASE_DESC,CASE_STATUS,",
					"RISK_IND,MEMBER_NAME,CASE_REASSIGN_DATE,INITIAL_USER_ID,REASSIGN_TYPE_CD,OVERRIDE_IND,LAST_UPDT_USERID)",
					"VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

			int[] batchUpdates = jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					ps.setString(1, casesToBeDeleted.get(i).getCustomerId());
					ps.setInt(2, casesToBeDeleted.get(i).getCaseId());
					ps.setString(3, casesToBeDeleted.get(i).getCurrentUserId());
					ps.setString(4, DateUtil.getCurrentDatetimeStampPlus(i * 200));
					ps.setString(5, DateUtil.getCurrentDatetimeStampPlus(i * 200));
					ps.setString(6, casesToBeDeleted.get(i).getAppId());
					ps.setString(7, casesToBeDeleted.get(i).getMbrId());
					ps.setString(8, casesToBeDeleted.get(i).getSupplementalId());
					ps.setString(9, casesToBeDeleted.get(i).getMedicareId());
					ps.setString(10, casesToBeDeleted.get(i).getQueueCode());
					ps.setString(11, casesToBeDeleted.get(i).getCaseDate());
					ps.setString(12, casesToBeDeleted.get(i).getCaseDueDate());
					ps.setString(13, casesToBeDeleted.get(i).getDaysRemaining());
					ps.setString(14, casesToBeDeleted.get(i).getCaseDesc());
					ps.setString(15, EEMConstants.CLOSED);
					ps.setString(16, casesToBeDeleted.get(i).getRiskInd());
					ps.setString(17, casesToBeDeleted.get(i).getMbrName());
					ps.setString(18, casesToBeDeleted.get(i).getCaseReassignDate());
					ps.setString(19, casesToBeDeleted.get(i).getInitialUserId());
					ps.setString(20, casesToBeDeleted.get(i).getReAssignTypeCode());
					ps.setString(21, EEMConstants.VALUE_NO);
					ps.setString(22, userId);
				}

				public int getBatchSize() {
					return casesToBeDeleted.size();
				}
			});

			for (int i = 0; i < batchUpdates.length; i++) {
				if (batchUpdates[i] != 0) {
					++count;
				}
			}
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_INSERT);
		}
		return count;
	}

	@Override
	public Map<String, Integer> checkAccess(String userId, String custId) {
		Map<String, Integer> result = new HashMap<>();
		String sql = CommonUtils.buildQuery(
				"SELECT TRIM(q.QUEUE_NAME), p.PRTY_NBR FROM EM_WF_USERQ_PRIORITY p, EM_WF_CASE_QUEUE q",
				"WHERE p.CUSTOMER_ID = q.CUSTOMER_ID AND p.QUEUE_CD = q.QUEUE_CD AND p.OVERIDE_IND = q.OVERIDE_IND",
				"AND p.USER_ID = ? AND p.CUSTOMER_ID = ? AND p.OVERIDE_IND = 'N' ORDER BY QUEUE_NAME");
		try {
			return jdbcTemplate.query(sql, new Object[] { userId, custId }, rs -> {
				while (rs.next()) {
					result.put(rs.getString(1), rs.getInt(2));
				}
				return result;
			});
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public Map<Integer, List<String>> fetchOldQueAssnFor(String customerId, String userId) {
		String sql = CommonUtils.buildQuery(
				"SELECT PRTY_NBR, QUEUE_CD FROM EM_WF_USERQ_PRIORITY WHERE CUSTOMER_ID = ? ",
				"AND ACTIVE_IND = 'A' AND USER_ID = ? AND OVERIDE_IND = 'N' ORDER BY PRTY_NBR, QUEUE_CD");
		try {
			return jdbcTemplate.query(sql, rs -> {
				Map<Integer, List<String>> oldQueAssignmentMap = new HashMap<>();
				List<String> value;

				while (rs.next()) {
					int prtyNbr = rs.getInt("PRTY_NBR");
					String queueCd = rs.getString(QUEUE_CD).trim();

					if (oldQueAssignmentMap.containsKey(prtyNbr)) {
						oldQueAssignmentMap.get(prtyNbr).add(queueCd);
					} else {
						value = new ArrayList<>();
						value.add(queueCd);
						oldQueAssignmentMap.put(prtyNbr, value);
					}
				}
				return oldQueAssignmentMap;
			}, customerId, userId);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error occured while fetchOldQueAssnFor!");
		}
	}
}
