package com.medicare.mss.service;

import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.caching.EEMPersistence;
import com.medicare.mss.caching.EEMProfileSettings;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.EEMProfileConstants;
import com.medicare.mss.dao.EEMDAO;
import com.medicare.mss.dao.EEMGrpSvcDAO;
import com.medicare.mss.dao.EEMMbrDAO;
import com.medicare.mss.dao.EEMMbrEnrollmentDAO;
import com.medicare.mss.daoImpl.MBDPersistence;
import com.medicare.mss.domainobject.EEMApplProductDO;
import com.medicare.mss.domainobject.EEMGroupProductSearchDO;
import com.medicare.mss.domainobject.EEMGrpProductDO;
import com.medicare.mss.domainobject.EEMMbrDsInfoDO;
import com.medicare.mss.domainobject.EEMMbrEligibilityDO;
import com.medicare.mss.domainobject.EEMMbrEnrollmentDO;
import com.medicare.mss.domainobject.EMMbrTriggerDO;
import com.medicare.mss.domainobject.MbdDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.EEMContext;
import com.medicare.mss.util.AddressFormatter;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.EEMElection;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EEMElectionVO;
import com.medicare.mss.vo.EEMMbrAddressVO;
import com.medicare.mss.vo.EEMMbrDemographicVO;
import com.medicare.mss.vo.EEMMbrDsInfoVO;
import com.medicare.mss.vo.EEMMbrEnrollmentVO;
import com.medicare.mss.vo.EEMMbrPrintIDCardVO;
import com.medicare.mss.vo.EMDatedSegmentVO;
import com.medicare.mss.vo.EMMbrTriggerVO;
import com.medicare.mss.vo.MBD;

@Service
public class EEMMbrEnrollmentService extends EEMMbrBaseService {

	public static final String CANCEL_ENROLLMENT = "cancelEnrollment";

	@Autowired
	private EEMCodeCache codeCache;

	@Autowired
	private EEMMbrEnrollmentDAO enrollDao;

	@Autowired
	private EEMElection eemElection;

	@Autowired
	private EEMProfileSettings eemProfileSett;

	@Autowired
	private MBDPersistence mbdPersistence;

	@Autowired
	private EEMMbrDAO mbrDao;

	@Autowired
	private EEMGrpSvcDAO grpSvcDao;

	@Autowired
	private EEMDAO eemDao;

	@Autowired
	private EEMPersistence eemPer;

	public boolean mbrEnrollmentUpdate(List<? extends EMDatedSegmentVO> dsInfoList,
			List<? extends EMDatedSegmentVO> enrollLst, EEMMbrDemographicVO demoVO, EEMMbrEnrollmentDO newVO,
			String userId) throws ApplicationException, ParseException, CloneNotSupportedException {
		boolean skipProductValidation = false;
		String customerId = newVO.getCustomerId();
		String custNbr = sessionHelper.getUserInfo().getCustNbr();

		if (EEMConstants.MBR_STAT_DPEND.equals(newVO.getEnrollStatus())
				|| EEMConstants.MBR_STAT_DAPRV.equals(newVO.getEnrollStatus()))
			skipProductValidation = true;
		String btnClicked = StringUtil.nonNullTrim(newVO.getButtonClicked());

		/*
		 * if (btnClicked.equals("cancelEnrollment")) { if
		 * (newVO.getEnrollStatus().equals(EEMConstants.MBR_STAT_DAPRV))
		 * newVO.setEnrollStatus(EEMConstants.MBR_STAT_EPEND); else if
		 * (newVO.getEnrollStatus().equals(EEMConstants.MBR_STAT_EAPRV))
		 * newVO.setEnrollStatus(EEMConstants.MBR_STAT_DPEND); else if
		 * (newVO.getEnrollStatus().equals(EEMConstants.MBR_STAT_DPEND))
		 * newVO.setEnrollStatus(EEMConstants.MBR_STAT_EAPRV); else throw new
		 * ApplicationException("Cancellation Submission not allowed for current Status"
		 * ); }
		 */

		Map<String, String> type = new HashMap<>();
		int sqlCnt = 0;

		String msg = checkDates(newVO);
		if (msg != null) {
			throw new ApplicationException(msg);
		}

		// Check for duplicate supplemental Id
		String value = eemProfileSett.getCalendarProfileInd(newVO.getCustomerId(), EEMConstants.SUPPLDUP);
		if (value.equals(EEMConstants.VALUE_YES)) {
			value = eemProfileSett.getCalendarProfileInd(newVO.getCustomerId(), EEMConstants.SUPPLID);
			if (value.equals(EEMConstants.SUPPLID_CUST_SUPPLIED) && (enrollDao.checkDuplSupplId(newVO.getCustomerId(),
					newVO.getSupplementalId(), newVO.getMemberId()))) {
				throw new ApplicationException("Duplicate Supplemental Id");
			}
		}

		String suppFixValue = eemProfileSett.getCalendarProfileInd(newVO.getCustomerId(), EEMConstants.SUPPFIX);
		String skipSupId = eemProfileSett.getParmText(newVO.getCustomerId(), EEMConstants.SUPPFIX,
				newVO.getEffStartDate());
		String mbrPrefix = eemProfileSett.getParmText(newVO.getCustomerId(), EEMConstants.MBRNBRFRMT,
				newVO.getEffStartDate());
		String validProduct;
		String mcCustNbr = sessionHelper.getUserInfo().getCustNbr();
		validProduct = validateGroupProduct(mcCustNbr, newVO);

		EEMMbrEnrollmentDO enrollVO = null;
		enrollVO = (EEMMbrEnrollmentDO) matchDatedSegment(enrollLst, newVO);

		if (suppFixValue.equals(EEMConstants.VALUE_YES)) {
			if (validProduct == null) {
				String suppFix = trimToEmpty(enrollDao.getClient(newVO).toUpperCase());
				String newSuppId = newVO.getSupplementalId().toUpperCase();
				String oldSuppFix = "";
				String oldSuppId = "";

				if (enrollVO != null) {
					oldSuppFix = trimToEmpty(enrollDao.getClient(enrollVO).toUpperCase());
					oldSuppId = enrollVO.getSupplementalId().toUpperCase();
				}
				if (skipSupId.equals(EEMConstants.SKIP_SUPPLID) && oldSuppId.startsWith(mbrPrefix.substring(0, 3))) {
					newVO.setSupplementalId(oldSuppId);
				} else if (!suppFix.isEmpty()) {
					if (newSuppId.equals(oldSuppId) && newSuppId.contains(oldSuppFix)) {
						String newPrefixSuppId = newSuppId.replace(oldSuppFix, "");
						newPrefixSuppId = suppFix + newPrefixSuppId;
						newVO.setSupplementalId(newPrefixSuppId);
					} else if ((newSuppId.length() > suppFix.length()) && (newSuppId.startsWith(suppFix))) {
						newVO.setSupplementalId(newSuppId);
					} else {
						throw new ApplicationException("Please enter Supplemental id with plan prefix : " + suppFix);
					}
				} else {
					throw new ApplicationException("Client ID Not found for Prefix");
				}
			} else {
				throw new ApplicationException(validProduct);
			}
		}

		if (!btnClicked.equals(CANCEL_ENROLLMENT) && !skipProductValidation) {
			msg = validateGroupProduct(custNbr, newVO);
			if (msg != null) {
				throw new ApplicationException(msg);
			}
		}

		String maxLastUpdate = mbrDao.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
				EEMConstants.EM_MBR_ENROLLMENT, type);
		if (hasDataChanged(enrollLst, maxLastUpdate)) {
			throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
		}

		if (hasPendingCMSTXN(enrollLst)) {
			throw new ApplicationException("There is a Pending CMS Transaction - Enrollments are locked");
		}
		// look at logicly deletes as well????
		if (EEMConstants.MBR_REASON_127_READY.equals(newVO.getEnrollReasonCd())
				&& !has127RejectForSamePlanPbpDate(newVO, enrollLst)) {
			throw new ApplicationException("No Previous 127 Reject Found");
		}

		MbdDO mbd = null;

		if ((EEMConstants.MBR_STAT_EPEND.equals(newVO.getEnrollStatus())
				|| EEMConstants.MBR_STAT_DPEND.equals(newVO.getEnrollStatus()))
				&& (EEMConstants.MBR_REASON_CMS_READY.equals(newVO.getEnrollReasonCd())
						|| EEMConstants.MBR_REASON_127_READY.equals(newVO.getEnrollReasonCd()))) {

			if (!btnClicked.equals(CANCEL_ENROLLMENT) && EEMConstants.MBR_STAT_EPEND.equals(newVO.getEnrollStatus())) {
				msg = checkEnrollmentDates(newVO);
				if (msg != null) {
					throw new ApplicationException(msg);

				}
				msg = checkEnrollmentOverrideableDates(newVO);
				if (msg != null) {
					throw new ApplicationException(msg);
				}
			}

			EEMGrpProductDO grpPrdVO = grpSvcDao.getGroupProduct(newVO.getCustomerId(), newVO.getGrpId(),
					newVO.getProductId(), newVO.getEffStartDate());
			if (!btnClicked.equals(CANCEL_ENROLLMENT) && grpPrdVO == null) {
				if (EEMConstants.MBR_STAT_DPEND.equals(newVO.getEnrollStatus())
						|| EEMConstants.MBR_STAT_DAPRV.equals(newVO.getEnrollStatus()))
					grpPrdVO = grpSvcDao.getGroupProduct(newVO.getCustomerId(), newVO.getGrpId(), newVO.getProductId(),
							null);
				if (grpPrdVO == null) {
					throw new ApplicationException("Group Product Lookup Failure");
				}
			}

			String ccm = getCCM(customerId);

			mbd = mbdPersistence.get(demoVO.getHicNbr(), "", StringUtil.isHicOrMbi(demoVO.getHicNbr()),
					demoVO.getHicNbr());
			if (Objects.isNull(mbd)) {
				throw new ApplicationException(String.format("No mbd data found for %s:%s",
						StringUtil.isHicOrMbi(demoVO.getHicNbr()), demoVO.getHicNbr()));
			}

			if (!btnClicked.equals(CANCEL_ENROLLMENT)
					&& !(EEMConstants.MBR_STAT_EPEND.equals(newVO.getEnrollStatus()))) {
				// Check for the disenrollment
				newVO.setLastUsedSepDate(StringUtil.nonNullTrim(mbd.getLastUsedSepDate()));
				LabelValuePair rslt = eemElection.validateDisenrollment(ccm, newVO, mbd, enrollDao);
				if (!rslt.getLabel().equals("000")) {
					throw new ApplicationException(rslt.getValue());
				}
			}

			if (!inCCMRange(newVO.getEffStartDate(), grpPrdVO.getEghpInd(), ccm, newVO.getElectionTypeCd(),
					newVO.getEnrollSrceCd())) {
				throw new ApplicationException("Transaction outside of CCM Range");
			}

		}

		if (newVO.getEffEndDate().equals(EEMConstants.EFF_END_DATE)
				&& (EEMConstants.MBR_STAT_EPEND.equals(newVO.getEnrollStatus()))
				&& !"Y".equals(newVO.getEditOverrideInd())) {
			if (null == mbd) {
				mbd = mbdPersistence.get(demoVO.getHicNbr(), "", StringUtil.isHicOrMbi(demoVO.getHicNbr()),
						demoVO.getHicNbr());
			}
			if (null != mbd) {
				if (mbd.getUnLawfulPresCnt() > 0) {
					boolean unLawPrsCntFlag = false;
					unLawPrsCntFlag = enrollDao.isUnlawfullyEligible(newVO.getEffStartDate(), demoVO.getHicNbr(),
							mbd.getMbi(), mbd.getEligibilitySrcTable());

					if (unLawPrsCntFlag) {
						throw new ApplicationException("Ineligible due to Unlawful Presence For Effective Date");
					}
				}
				if (mbd.getIncarcerationCnt() > 0) {
					boolean incarcerationCntFlag = false;
					incarcerationCntFlag = enrollDao.isIncarcerated(newVO.getEffStartDate(), demoVO.getHicNbr(),
							mbd.getMbi(), mbd.getEligibilitySrcTable());
					if (incarcerationCntFlag) {
						throw new ApplicationException("Ineligible due to Incarceration during Effective Date");
					}
				}
			}

		}

		if (!btnClicked.equals(CANCEL_ENROLLMENT) && (EEMConstants.MBR_STAT_EAPRV.equals(newVO.getEnrollStatus())
				|| EEMConstants.MBR_STAT_EPEND.equals(newVO.getEnrollStatus()))) {
			EEMMbrEligibilityDO mbrElig = getNewMbrEligibility(demoVO, userId);
			if (null == mbrElig) {
				if (!"Y".equals(newVO.getEditOverrideInd())) {
					throw new ApplicationException("Member Eligibility Not Found - Edit Override Required");
				}
			} else {

				if (EEMConstants.MBR_STAT_EPEND.equals(newVO.getEnrollStatus())
						&& (EEMConstants.MBR_REASON_CMS_READY.equals(newVO.getEnrollReasonCd())
								|| EEMConstants.MBR_REASON_127_READY.equals(newVO.getEnrollReasonCd()))) {

					EEMElectionVO elcVO = new EEMElectionVO();
					elcVO.setCustomerId(newVO.getCustomerId());
					elcVO.setElectionType(newVO.getElectionTypeCd());
					elcVO.setApplicationDt(newVO.getApplicationDate());
					elcVO.setReqDtCov(newVO.getEffStartDate());
					elcVO.setPlanDesgn(newVO.getPlanDesignation());
					elcVO.setPartAEntlDt(mbrElig.getPrtAEntitleStartDate());
					elcVO.setPartBEntlDt(mbrElig.getPrtBEntitleStartDate());
					elcVO.setPartDElgDt(mbrElig.getPrtDEligStartDate());
					elcVO.setBirthDt(demoVO.getBirthDate());
					elcVO.setLongTermFacId("");
					elcVO.setErrorCode("");
					elcVO.setElcDerivedInd("N");
					this.populateEEMElectionVO(elcVO);
					elcVO.setLastUsedSepDate(mbrElig.getLastUsedSepDate());

					eemElection.validateElectionType(elcVO);
					if (!elcVO.getErrorCode().equals("") && !"Y".equals(newVO.getEditOverrideInd())) {
						msg = codeCache.getErrorMsg(elcVO.getErrorCode());
						if (msg == null)
							msg = "Election Type Validation Error: " + elcVO.getErrorCode();
						throw new ApplicationException(msg);
					}
				}

				LabelValuePair eligRslt = eemElection.isEligible(newVO.getEffStartDate(),
						mbrElig.getPrtAEntitleStartDate(), mbrElig.getPrtAEntitleEndDate(),
						mbrElig.getPrtBEntitleStartDate(), mbrElig.getPrtBEntitleEndDate(), mbrElig.getDeathDate(),
						newVO.getPlanDesignation());
				if (!eligRslt.getLabel().equals("000") && !"Y".equals(newVO.getEditOverrideInd())) {
					throw new ApplicationException(eligRslt.getValue());
				}

			}

		}

		EEMMbrEnrollmentDO matchVO = null;

		// the update case
		matchVO = (EEMMbrEnrollmentDO) matchDatedSegment(enrollLst, newVO);

		if (matchVO != null) {

			sqlCnt = enrollDao.setOverride(matchVO, userId);
			if (sqlCnt != 1) {
				throw new ApplicationException("Error Overriding Segment");
			}
			msg = checkForSupplementalId(matchVO, newVO); // ???
			if (msg != null) {
				throw new ApplicationException(msg);
			}

			msg = checkForRxId(newVO);
			if (msg != null) {
				throw new ApplicationException(msg);
			}
			String ts = DateUtil.getCurrentDatetimeStampPlus(200);
			newVO.setCreateTime(ts);
			newVO.setCreateUserId(userId);
			newVO.setLastUpdtTime(ts);
			newVO.setLastUpdtUserId(userId);
			sqlCnt = enrollDao.insertMbr(newVO);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
			}

			int rslt = enrollmentTriggerCheck(dsInfoList, matchVO, newVO, userId);
			if (rslt > 0) {
				return false;
			}
			maxLastUpdate = mbrDao.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
					EEMConstants.EM_MBR_ENROLLMENT, type);
			if (hasDataChanged(ts, maxLastUpdate)) {
				throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
			}
			return true;
		}

		if (newVO.getEffEndDate().equals(EEMConstants.EFF_END_DATE)) {

			EEMMbrEnrollmentDO oldOpenVO = (EEMMbrEnrollmentDO) getOpenendedSegment(enrollLst);

			// logicly delete all above
			List<? extends EMDatedSegmentVO> lstSegmentsAbove = getSegmentsAbove(enrollLst, newVO.getEffStartDate());
			Iterator<? extends EMDatedSegmentVO> it = lstSegmentsAbove.iterator();
			while (it.hasNext()) {
				EEMMbrEnrollmentDO itemVO = (EEMMbrEnrollmentDO) it.next();
				sqlCnt = enrollDao.setOverride(itemVO, userId);
				if (sqlCnt != 1) {
					throw new ApplicationException("Error Overriding Segment Above");
				}
			}

			EEMMbrEnrollmentDO belowVO = (EEMMbrEnrollmentDO) getFirstOverlapSegmentBelow(enrollLst,
					newVO.getEffStartDate());

			if (belowVO != null) {

				sqlCnt = enrollDao.setOverride(belowVO, userId);
				if (sqlCnt != 1) {
					throw new ApplicationException("Error Overriding Segment Below");
				}

				// do we need to split the segmment below
				if (belowVO.getEffStartDate().compareTo(newVO.getEffStartDate()) < 0) {
					String ts = DateUtil.getCurrentDatetimeStampPlus(200);
					EEMMbrEnrollmentDO tempVO = (EEMMbrEnrollmentDO) belowVO.clone();
					tempVO.setEffEndDate(DateMath.minusOneDay(newVO.getEffStartDate()));
					tempVO.setCreateTime(ts);
					tempVO.setCreateUserId(userId);
					tempVO.setLastUpdtTime(ts);
					tempVO.setLastUpdtUserId(userId);
					sqlCnt = enrollDao.insertMbr(tempVO);
					if (sqlCnt != 1) {
						throw new ApplicationException("Error Spliting Segment Below");
					}
				}
			}

			msg = checkForSupplementalId(oldOpenVO, newVO); // ???
			if (msg != null) {
				throw new ApplicationException(msg);
			}

			msg = checkForRxId(newVO);
			if (msg != null) {
				throw new ApplicationException(msg);
			}

			// add the new segment
			String ts = DateUtil.getCurrentDatetimeStampPlus(200);
			newVO.setCreateTime(ts);
			newVO.setCreateUserId(userId);
			newVO.setLastUpdtTime(ts);
			newVO.setLastUpdtUserId(userId);

			sqlCnt = enrollDao.insertMbr(newVO);
			if (sqlCnt != 1) {
				throw new ApplicationException("Error Adding Segment");
			}

			int rslt = enrollmentTriggerCheck(dsInfoList, oldOpenVO, newVO, userId);
			if (rslt > 0) {
				return false;
			}
			maxLastUpdate = mbrDao.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
					EEMConstants.EM_MBR_ENROLLMENT, type);
			if (hasDataChanged(ts, maxLastUpdate)) {
				throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
			}
			return true;
			// end of open ended new segment processing
		}

		// end dated segment
		if (endsBeforeFirstSegment(enrollLst, newVO.getEffEndDate())) {
			throw new ApplicationException("End Date before first segment, Gaps are not allowed");
		}
		String ts = DateUtil.getCurrentDatetimeStampPlus(200);
		doDatedSegmentAdjust(enrollLst, newVO, ts, userId, enrollDao);
		msg = checkForRxId(newVO);
		if (msg != null) {
			throw new ApplicationException(msg);
		}

		// add the new segment
		newVO.setCreateTime(ts);
		newVO.setCreateUserId(userId);
		newVO.setLastUpdtTime(ts);
		newVO.setLastUpdtUserId(userId);
		sqlCnt = enrollDao.insertMbr(newVO);
		if (sqlCnt != 1) {
			throw new ApplicationException("Error Adding Segment");
		}
		maxLastUpdate = mbrDao.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
				EEMConstants.EM_MBR_ENROLLMENT, type);
		if (hasDataChanged(ts, maxLastUpdate)) {
			throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
		}
		return true;
	}

	public String checkEnrollmentDates(EEMMbrEnrollmentDO newVO) {

		if (DateMath.isGreaterThanOrEqual(newVO.getApplicationDate(), newVO.getEffStartDate())) {
			return "Application Date Must Be Before The Effective Date";
		}
		if (!eemElection.validSignatureDate(newVO.getSignatureDate(), newVO.getApplicationDate(),
				newVO.getElectionTypeCd(), newVO.getEditOverrideInd())) {
			return "Signature Date Must Be On or Before The Application Date";
		}
		return null;
	}

	public String checkEnrollmentOverrideableDates(EEMMbrEnrollmentDO newVO)
			throws ApplicationException, ParseException {

		if (!"Y".equals(newVO.getEditOverrideInd())) {
			LabelValuePair nvp = eemElection.validApplicationDate(newVO.getCustomerId(), newVO.getApplicationDate(),
					newVO.getElectionTypeCd());
			if (!nvp.getLabel().equals("000"))
				return nvp.getValue();
		}

		return null;
	}

	public boolean hasPendingCMSTXN(List<? extends EMDatedSegmentVO> enrollLst) {

		EEMMbrEnrollmentDO enrlVO = null;
		Iterator<? extends EMDatedSegmentVO> it = enrollLst.iterator();
		while (it.hasNext()) {
			enrlVO = (EEMMbrEnrollmentDO) it.next();
			if (EEMConstants.MBR_REASON_CMS_SUBMIT.equals(enrlVO.getEnrollReasonCd()))
				return true;
		}
		return false;
	}

	public boolean has127RejectForSamePlanPbpDate(EEMMbrEnrollmentDO newVO,
			List<? extends EMDatedSegmentVO> enrollLst) {

		EEMMbrEnrollmentDO enrlVO = null;
		Iterator<? extends EMDatedSegmentVO> it = enrollLst.iterator();
		while (it.hasNext()) {
			enrlVO = (EEMMbrEnrollmentDO) it.next();
			if (enrlVO.getEffStartDate().equals(newVO.getEffStartDate()) && enrlVO.getPlanId().equals(newVO.getPlanId())
					&& enrlVO.getPbpId().equals(newVO.getPbpId())
					&& EEMConstants.MBR_REASON_127_REJECT.equals(enrlVO.getEnrollReasonCd()))
				return true;
		}
		return false;
	}

	public String getCCM(String customerId) throws ApplicationException {
		String ccmDate = eemProfileSett.getParmDate(customerId, EEMConstants.CCM);
		// String ccm = applDao.getCCMDate( customerId);//p
		ccmDate = ccmDate + "01";
		return ccmDate;
	}

	public EEMMbrEligibilityDO getNewMbrEligibility(EEMMbrDemographicVO mbrDemo, String userId)
			throws ApplicationException {

		EEMMbrEligibilityDO mbrElig = null;
		MBD mbd = mbdPersistence.getHicMatch(mbrDemo.getHicNbr(), mbrDemo.getLastName(), mbrDemo.getBirthDate(), "Y",
				StringUtil.isHicOrMbi(mbrDemo.getHicNbr()), mbrDemo.getHicNbr());
		if (mbd != null) {

			String ts = DateUtil.getCurrentDatetimeStamp();

			mbrElig = new EEMMbrEligibilityDO();

			mbrElig.setCustomerId(mbrDemo.getCustomerId());
			mbrElig.setMemberId(mbrDemo.getMemberId());
			mbrElig.setLastCheckedTime(ts);
			if (StringUtil.nonNullTrim(mbrDemo.getHicNbr()).equals(mbd.getHicNbr()))
				mbrElig.setHicNbr(mbd.getHicNbr());
			else if (StringUtil.nonNullTrim(mbrDemo.getHicNbr()).equals(mbd.getMbi()))
				mbrElig.setHicNbr(mbd.getMbi());
			mbrElig.setLastName(mbd.getLastName());
			mbrElig.setFirstName(mbd.getFirstName());
			mbrElig.setMiddleInit(mbd.getMiddleInit());
			mbrElig.setGenderNumCd(mbd.getGenderCd());
			mbrElig.setBirthDate(mbd.getBirthDate());
			mbrElig.setLivingStatus(mbd.getLivingStatus());
			mbrElig.setDeathDate(mbd.getDeathDate());
			mbrElig.setPrtAEntitleStartDate(mbd.getPrtAEntitleDate());
			mbrElig.setPrtAEntitleEndDate(mbd.getPrtAEntitleEndDate());
			mbrElig.setPrtBEntitleStartDate(mbd.getPrtBEntitleDate());
			mbrElig.setPrtBEntitleEndDate(mbd.getPrtBEntitleEndDate());
			mbrElig.setPrtDEligStartDate(mbd.getPrtDEligibleDate());
			mbrElig.setPrtAOption(mbd.getPrtAOption());
			mbrElig.setPrtBOption(mbd.getPrtBOption());
			mbrElig.setEnrollmentStatus(mbd.getEnrollmentStatus());
			mbrElig.setHospiceInd(mbd.getHospiceInd());
			mbrElig.setHospiceStartDate(mbd.getHospiceStartDate());
			mbrElig.setHospiceEndDate(mbd.getHospiceEndDate());
			mbrElig.setInstInd(mbd.getInstInd());
			mbrElig.setInstStartDate(mbd.getInstStartDate());
			mbrElig.setInstEndDate(mbd.getInstEndDate());
			mbrElig.setEsrdInd(mbd.getEsrdInd());
			mbrElig.setEsrdStartDate(mbd.getEsrdStartDate());
			mbrElig.setEsrdEndDate(mbd.getEsrdEndDate());
			mbrElig.setWrkAgedInd(mbd.getWrkagedInd());
			mbrElig.setWrkAgedStartDate(mbd.getWrkagedStartDate());
			mbrElig.setWrkAgedEndDate(mbd.getWrkagedEndDate());
			mbrElig.setMedicInd(mbd.getMedicInd());
			mbrElig.setMedicStartDate(mbd.getMedicStartDate());
			mbrElig.setMedicEndDate(mbd.getMedicEndDate());
			mbrElig.setRaceCD(mbd.getRaceCd());
			mbrElig.setStateCd(mbd.getStateCd());
			mbrElig.setCountyCd(mbd.getCountyCd());
			mbrElig.setCalcUncovMonths("0");
			mbrElig.setEligibilitySource("MBD");
			mbrElig.setLastUpdtUserid(userId);
			mbrElig.setLastUsedSepDate(StringUtil.nonNullTrim(mbd.getLastUsedSepDate()));

			enrollDao.insertMbrEligibility(mbrElig);
		}

		return mbrElig;
	}

	private void populateEEMElectionVO(EEMElectionVO eemElectionVO) throws ParseException {
		eemElectionVO.setMemberPresentInM360(true);
		eemElectionVO.setStrApplicationDate(eemElectionVO.getApplicationDt());
		String effectiveDateInMMDDYYYYFormat = eemElectionVO.getReqDtCov().replaceAll("/", "");
		eemElectionVO.setDayBeforeRequestedDateOfCoverage(DateMath.minusOneDay(effectiveDateInMMDDYYYYFormat));// TODO
	}

	public String checkForSupplementalId(EEMMbrEnrollmentDO oldVO, EEMMbrEnrollmentDO newVO)
			throws ApplicationException {

		String supIdParm = eemProfileSett.getParmInd(newVO.getCustomerId(), EEMProfileConstants.SUPPLID,
				newVO.getEffStartDate());
		String supIdText = eemProfileSett.getParmText(newVO.getCustomerId(), EEMProfileConstants.SUPPLID,
				newVO.getEffStartDate());

		if (EEMProfileConstants.SUPPLID_DERIVED.equals(supIdParm)) {
			newVO.setSupplementalId(newVO.getMemberId());
			return null;
		}

		if (EEMConstants.SUPPLID_CUST_SUPPLIED.equals(supIdParm)) {
			if (!StringUtil.nonNullTrim(newVO.getSupplementalId()).equals(""))
				return null;
			return "Supplemental Id is Required";
		}

		if (EEMProfileConstants.SUPPLID_GENERATED.equals(supIdParm)
				&& !supIdText.equals(EEMProfileConstants.SUPPLID_TEXT)) {

			if (!newVO.getEffEndDate().equals("99999999"))
				return null;

			if (!newVO.getEnrollStatus().equals(EEMConstants.MBR_STAT_EPEND))
				return null;

			if ((oldVO.getEnrollStatus().equals(EEMConstants.MBR_STAT_DPEND)
					|| oldVO.getEnrollStatus().equals(EEMConstants.MBR_STAT_DAPRV))
					&& (!StringUtil.nonNullTrim(oldVO.getGrpId()).equals(newVO.getGrpId()))) {
				newVO.setSupplementalId(
						Integer.toString(eemDao.getNextSeqNo(newVO.getCustomerId(), EEMConstants.NEXT_SUP_ID)));
			} else {
				newVO.setSupplementalId(oldVO.getSupplementalId());
			}

		}

		return null;
	}

	public String checkForRxId(EEMMbrEnrollmentDO newVO) throws ApplicationException {

		if (newVO.getPlanDesignation().equals("MA")) {
			if (StringUtil.nonNullTrim(newVO.getRxId()).equals(""))
				return null;
			return "RX Id Not Valid for MA Plan";
		}

		String rxIdParm = eemProfileSett.getParmInd(newVO.getCustomerId(), EEMConstants.RXID, newVO.getEffStartDate());
		if (EEMConstants.RXID_CUST_SUPPLIED.equals(rxIdParm)) {
			if (!StringUtil.nonNullTrim(newVO.getRxId()).equals(""))
				return null;
			return "RX Id is Required";
		}
		if (EEMConstants.RXID_DERIVED.equals(rxIdParm)) {
			newVO.setRxId(newVO.getMemberId());
			return null;
		}
		if (EEMConstants.RXID_USE_SUPPLID.equals(rxIdParm)) {
			newVO.setRxId(newVO.getSupplementalId());
			return null;
		}

		return null;
	}

	public int enrollmentTriggerCheck(List<? extends EMDatedSegmentVO> dsInfoList, EEMMbrEnrollmentDO oldVO,
			EEMMbrEnrollmentDO newVO, String userId) throws ApplicationException {

		String ts;
		int rslt = -1;
		EMMbrTriggerDO trig = new EMMbrTriggerDO();
		trig.setCustomerId(newVO.getCustomerId());
		trig.setMemberId(newVO.getMemberId());
		trig.setTriggerType(EEMConstants.TRIG_TYPE_TXN);
		trig.setPlanId(newVO.getPlanId());
		trig.setPbpId(newVO.getPbpId());
		trig.setPlanDesignation(newVO.getPlanDesignation());
		trig.setTriggerStatus(EEMConstants.TRIG_STATUS_OPEN);
		trig.setProcessSource(EEMConstants.TRIG_PROCESS_SOURCE_WEBENRL);
		trig.setOrigTriggerType("");
		trig.setOrigTriggerCode("");
		trig.setOrigEffectiveDate("");
		trig.setOrigTriggerCreateTime("");
		trig.setCreateUserId(userId);
		trig.setLastUpdtUserId(userId);

		String status = newVO.getEnrollStatus();
		String reasonCd = newVO.getEnrollReasonCd();
		ts = DateUtil.getCurrentDatetimeStamp();

		if ("Y".equalsIgnoreCase(newVO.getTrg72Ind())) {
			ts = ts.substring(0, 25) + "1";
			trig.setCreateTime(ts);
			trig.setLastUpdtTime(ts);
			trig.setEffectiveDate(newVO.getEffStartDate());
			trig.setTriggerCode(EEMConstants.TRIG_CODE_72);

			// Check whether trigger already inserted
			boolean check = mbrDao.checkMbrTrigger(trig);

			if (!check) {
				int sqlCnt = mbrDao.insertMbrTrigger(trig);
				if (sqlCnt != 1) {
					throw new ApplicationException("Error Creating CMS Transaction (72) Trigger");
				}
				rslt = 0;
			} else {
				// throw new ApplicationException("Warning : 72 TXN is not triggered as the
				// member already have an OPEN 72 TXN");//TODO
				newVO.setTrg72Ind("N");
				enrollDao.updateTXNFlag("72", false, newVO);
				rslt = 0;
			}
		}

		// Is this an Enrollment / Disenrollment
		if (status.equals(EEMConstants.MBR_STAT_DPEND) || status.equals(EEMConstants.MBR_STAT_EPEND)
				|| status.equals(EEMConstants.MBR_STAT_EAPRV)) {
			// if its ready send it
			if (StringUtil.nonNullTrim(newVO.getButtonClicked()).equals(CANCEL_ENROLLMENT)) {

				String trigCode = "";
				if (status.equals(EEMConstants.MBR_STAT_DPEND))
					trigCode = StringUtil
							.nonNullTrim(enrollDao.getMbrTriggerCode(EEMConstants.EEM_MBR_CANCEL_TRIG_FUN_TYPE, newVO));
				else if (status.equals(EEMConstants.MBR_STAT_EPEND) || status.equals(EEMConstants.MBR_STAT_EAPRV))
					trigCode = StringUtil.nonNullTrim(
							enrollDao.getMbrTriggerCode(EEMConstants.EEM_MBR_DSENRL_CANCEL_TRIG_FUN_TYPE, newVO));

				if (!trigCode.equals("")) {

					trig.setTriggerType(EEMConstants.TRIG_TYPE_MANUAL_LTR);
					ts = ts.substring(0, 25) + "4";
					trig.setCreateTime(ts);
					trig.setLastUpdtTime(ts);
					trig.setEffectiveDate(newVO.getEffStartDate());
					trig.setTriggerCode(trigCode);
					Boolean check = mbrDao.checkMbrTrigger(trig);
					if (!check && mbrDao.insertMbrTrigger(trig) != 1)
						throw new ApplicationException("Error Creating Cancellation Letter");

					trig.setTriggerType(EEMConstants.TRIG_TYPE_TXN);
				}

			}
			if (reasonCd.equals(EEMConstants.MBR_REASON_CMS_READY)
					|| reasonCd.equals(EEMConstants.MBR_REASON_127_READY)) {

				String triggerCode = null;
				if (status.equals(EEMConstants.MBR_STAT_EPEND)) {

					String srcePlan = StringUtil.nonNullTrim(codeCache.getEnrollSrcePlan(newVO.getEnrollSrceCd()));
					if (!srcePlan.equals(EEMConstants.MBR_SRCE_APPL) && !srcePlan.equals(EEMConstants.MBR_SRCE_PLAN)) {
						throw new ApplicationException("Invalid Source for Creating CMS Transaction (61) Trigger");
					}

					if (reasonCd.equals(EEMConstants.MBR_REASON_127_READY))
						triggerCode = EEMConstants.TRIG_CODE_SO_ENROLL;
					else
						triggerCode = EEMConstants.TRIG_CODE_ENROLL;
				} else {
					triggerCode = EEMConstants.TRIG_CODE_DISENROLL;
				}

				ts = DateUtil.getCurrentDatetimeStamp();
				trig.setCreateTime(ts);
				trig.setLastUpdtTime(ts);
				trig.setEffectiveDate(newVO.getEffStartDate());
				trig.setTriggerCode(triggerCode);
				int sqlCnt = mbrDao.insertMbrTrigger(trig);
				if (sqlCnt != 1) {
					if (EEMConstants.TRIG_CODE_DISENROLL.equals(triggerCode))
						throw new ApplicationException("Error Creating CMS Transaction (51) Trigger");
					else
						throw new ApplicationException("Error Creating CMS Transaction (61) Trigger");
				}
				// Close FUM and OPRD trigger
				if (enrollDao.updateFUMTrigger(trig) > 1) {
					throw new ApplicationException("Error Updating FollowUp Member trigger status");
				}

				return 0;
			}

		}

		ts = DateUtil.getCurrentDatetimeStamp();

		if (is77SegmentChange(oldVO, newVO)) {

			ts = ts.substring(0, 25) + "2";
			trig.setCreateTime(ts);
			trig.setLastUpdtTime(ts);
			trig.setEffectiveDate(newVO.getEffStartDate());
			trig.setTriggerCode(EEMConstants.TRIG_CODE_77);

			int sqlCnt = mbrDao.insertMbrTrigger(trig);
			if (sqlCnt != 1) {
				throw new ApplicationException("Error Creating CMS Transaction (77) Trigger");
			}

			rslt = 0;
		}

		// do we have a 78 change

		if (!(status.equals(EEMConstants.MBR_STAT_DPEND) && reasonCd.equals(EEMConstants.MBR_REASON_DPENDRFI)
				|| reasonCd.equals(EEMConstants.MBR_REASON_DENIEDDIS)
				|| reasonCd.equals(EEMConstants.MBR_REASON_DUPDISENR)) && is78Change(oldVO, newVO)) {

			ts = ts.substring(0, 25) + "3";
			trig.setCreateTime(ts);
			trig.setLastUpdtTime(ts);
			trig.setEffectiveDate(newVO.getEffStartDate());
			trig.setTriggerCode(EEMConstants.TRIG_CODE_78);

			int sqlCnt = mbrDao.insertMbrTrigger(trig);
			if (sqlCnt != 1) {
				throw new ApplicationException("Error Creating CMS Transaction (78) Trigger");
			}
			/** IFOX-00423912 Changes START */
			/*
			 * if (need75with78(dsInfoList)) {
			 * 
			 * ts = ts.substring(0, 25) + "4"; trig.setCreateTime(ts);
			 * trig.setLastUpdtTime(ts); trig.setTriggerCode(EEMConstants.TRIG_CODE_75);
			 * 
			 * sqlCnt = mbrDao.insertMbrTrigger(trig); if (sqlCnt != 1) { throw new
			 * ApplicationException("Error Creating CMS Transaction (75) Trigger"); }
			 * 
			 * rslt = 0; }
			 */
			/** IFOX-00423912 Changes END */
		}

		return rslt;
	}

	public boolean is77SegmentChange(EEMMbrEnrollmentDO oldVO, EEMMbrEnrollmentDO newVO) {

		if (!oldVO.getPlanId().equals(newVO.getPlanId()))
			return false;
		if (!oldVO.getPbpId().equals(newVO.getPbpId()))
			return false;

		if (!oldVO.getPbpSegmentId().equals(newVO.getPbpSegmentId()))
			return true;

		return false;
	}

	public boolean is78Change(EEMMbrEnrollmentDO oldVO, EEMMbrEnrollmentDO newVO) throws ApplicationException {

		double oldPartC = enrollDao.getPartCPremium(oldVO);
		double newPartC = enrollDao.getPartCPremium(newVO);
		if (oldPartC != newPartC)
			return true;

		return false;
	}

	/** IFOX-00423912 Changes START */
	/*
	 * public boolean need75with78(List<? extends EMDatedSegmentVO> dsInfos) {
	 * 
	 * if (dsInfos != null) { List<? extends EMDatedSegmentVO> pwoSegments =
	 * getDatedTypeList(dsInfos, EEMMbrDsInfoVO.DS_PWO); if (pwoSegments != null) {
	 * EEMMbrDsInfoVO pwoVO = (EEMMbrDsInfoVO) getOpenendedSegment(pwoSegments); if
	 * (pwoVO != null && "S".equals(pwoVO.getDsValue())) return true; } } return
	 * false; }
	 */
	/** IFOX-00423912 Changes START */

	public boolean inCCMRange(String effDate, String eghpInd, String ccm, String electionTypeCd, String enrollSrceCd)
			throws ParseException {

		String ccmStart;
		if ("Y".equals(eghpInd))
			ccmStart = DateMath.addMonth(ccm, -3);
		else {
			if ("Z".equals(electionTypeCd) && "E".equals(enrollSrceCd)) {
				ccmStart = DateMath.addMonth(ccm, -24);
			} else {
				ccmStart = DateMath.addMonth(ccm, -1);
			}
		}

		String ccmEnd = DateMath.minusOneDay(DateMath.addMonth(ccm, 4));

		if (DateMath.isBetween(effDate, ccmStart, ccmEnd))
			return true;

		return false;
	}

	public String validateGroupProduct(String mcCustNbr, EEMMbrEnrollmentDO newVO) throws ApplicationException {

		EEMGroupProductSearchDO gpSearch = new EEMGroupProductSearchDO();
		gpSearch.setCustomerId(newVO.getCustomerId());
		gpSearch.setMemberId(newVO.getMemberId());
		gpSearch.setGrpId(newVO.getGrpId());
		gpSearch.setProductId(newVO.getProductId());
		gpSearch.setEffDate(newVO.getEffStartDate());
		getMbrOutOfAreaOn(gpSearch);
		if (!getMbrPrimaryZipOn(gpSearch)) {
			return "Error Validating Group / Product - No Address found for Effective Date";
		}

		gpSearch.setMcCustNbr(mcCustNbr);
		List<EEMApplProductDO> lst = grpSvcDao.searchGrpPrd(gpSearch);

		if (!CollectionUtils.isEmpty(lst)) {
			return null;
		}
		return "Product Not valid for the Effective Date / Service Area";
	}

	public boolean getMbrPrimaryZipOn(EEMGroupProductSearchDO gpSearch) {

		List<EEMMbrAddressVO> addressVOList = sessionHelper.getEEMContext().getMbrMasterVO().getMbrAddressList();

		EEMMbrAddressVO addr = getMbrAddressOn(addressVOList, gpSearch.getEffDate());
		if (addr == null) {
			return false;
		}

		gpSearch.setZipCd5(AddressFormatter.getZip5(addr.getZipCd()));
		gpSearch.setZipCd4(AddressFormatter.getZip4(addr.getZipCd()));
		gpSearch.setSsaState(addr.getStateCd());
		gpSearch.setSsaCnty(addr.getCountyCd());

		return true;
	}

	private EEMMbrAddressVO getMbrAddressOn(List<EEMMbrAddressVO> addressVOList, String effDate) {

		Iterator<EEMMbrAddressVO> itr = addressVOList.iterator();
		while (itr.hasNext()) {
			EEMMbrAddressVO addressVO = itr.next();
			if (EEMConstants.EEM_ADDRTYPE_PRIMARY.equalsIgnoreCase(addressVO.getAddressType())
					&& DateMath.isBetween(effDate, addressVO.getEffStartDate(), addressVO.getEffEndDate())
					&& "N".equalsIgnoreCase(addressVO.getOverrideInd()))
				return addressVO;
		}

		return null;
	}

	public void getMbrOutOfAreaOn(EEMGroupProductSearchDO gpSearch) {

		List<EEMMbrDsInfoVO> dsinfoVOlist = sessionHelper.getEEMContext().getMbrMasterVO().getMbrDsInfoList();
		boolean ooaFlag = getMbrDsInfoOn(dsinfoVOlist, gpSearch.getEffDate());
		if (!ooaFlag) {
			gpSearch.setOutOfArea("N");
		} else {
			gpSearch.setOutOfArea("Y");
		}

	}

	private boolean getMbrDsInfoOn(List<EEMMbrDsInfoVO> dsinfoVOlist, String effDate) {

		Iterator<EEMMbrDsInfoVO> itr = dsinfoVOlist.iterator();
		while (itr.hasNext()) {
			EEMMbrDsInfoVO dsInfoVO = itr.next();
			if (dsInfoVO.getDsCd().equalsIgnoreCase(EEMMbrDsInfoDO.DS_OOA)
					&& DateMath.isBetween(effDate, dsInfoVO.getEffStartDate(), dsInfoVO.getEffEndDate())
					&& "N".equalsIgnoreCase(dsInfoVO.getOverrideInd()))
				return true;
		}
		return false;
	}

	@SuppressWarnings("unchecked")
	@Transactional(rollbackOn = ApplicationException.class)
	public Map<String, Object> mbrEnrollmentUpdate(EEMMbrEnrollmentVO newVO)
			throws ApplicationException, ParseException, CloneNotSupportedException {

		List<EEMMbrEnrollmentVO> enrollVOList = getListFromContext(newVO.getMemberId(), "N");
		List<EEMMbrDsInfoVO> dsinfoVOlist = sessionHelper.getEEMContext().getMbrMasterVO().getMbrDsInfoList();
		EEMMbrDemographicVO oldDemoVO = sessionHelper.getEEMContext().getMbrMasterVO().getMbrDemographicVO();
		String userId = sessionHelper.getUserInfo().getUserId();
		String lepPlatinoFlag = "";

		List<EEMMbrEnrollmentDO> enrollDOList = new ArrayList<>();
		enrollVOList.forEach(enrollVO -> {
			EEMMbrEnrollmentDO enrollDO = new EEMMbrEnrollmentDO();
			BeanUtils.copyProperties(enrollVO, enrollDO);
			enrollDOList.add(enrollDO);
		});

		newVO.setCustomerId(sessionHelper.getUserInfo().getCustomerId());
		newVO.setEditOverrideInd(StringUtil.YorBlank(newVO.getEditOverrideInd()));
		newVO.setOverrideInd("N");

		EEMMbrEnrollmentDO wrkVO = new EEMMbrEnrollmentDO();
		BeanUtils.copyProperties(newVO, wrkVO);

		boolean result = mbrEnrollmentUpdate(dsinfoVOlist, enrollDOList, oldDemoVO, wrkVO, userId);
		if (result) {
			enrollVOList = getEnrollListFromDB(newVO.getMemberId(), newVO.getShowAll());
			if (StringUtils.equals(EEMConstants.VALUE_NO, newVO.getShowAll())) {
				setToContext(enrollVOList);
			} else {
				List<EEMMbrEnrollmentVO> mbrEnrollActiveVOList = (List<EEMMbrEnrollmentVO>) getActiveDatedList(
						enrollVOList);
				setToContext(mbrEnrollActiveVOList);
			}
			
			lepPlatinoFlag = mbrDao.getLepPlatinoFlag(sessionHelper.getUserInfo().getCustomerId(), newVO.getMemberId());
			EEMContext context = sessionHelper.getEEMContext();
			context.getMbrMasterVO().setSuppLepPlatino(lepPlatinoFlag);
			sessionHelper.setEEMContext(context);

		} else {
			throw new ApplicationException("Enrollment Update Failed");
		}
		return buildResultMap(enrollVOList, lepPlatinoFlag);
	}

	private Map<String, Object> buildResultMap(List<EEMMbrEnrollmentVO> enrollVOList, String lepPlatinoFlag) {
		
		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("enrollVOList", enrollVOList);
		resultMap.put("suppLepPlatino", lepPlatinoFlag);

		return resultMap;
	}

	@SuppressWarnings("unchecked")
	public List<EEMMbrEnrollmentVO> getListFromContext(String memberId, String showAll) throws ApplicationException {

		EEMContext context = sessionHelper.getEEMContext();
		List<EEMMbrEnrollmentVO> mbrEnrollVOList = context.getMbrMasterVO().getMbrEnrollmentList();

		if (StringUtils.equals(EEMConstants.VALUE_YES, showAll)) {
			List<EEMMbrEnrollmentVO> allInfos = getEnrollListFromDB(memberId, showAll);
			mbrEnrollVOList = (List<EEMMbrEnrollmentVO>) getActiveDatedList(allInfos);
			setToContext(mbrEnrollVOList);
			return allInfos;
		} else {
			if (Objects.isNull(mbrEnrollVOList)) {
				mbrEnrollVOList = getEnrollListFromDB(memberId, showAll);
				setToContext(mbrEnrollVOList);
			} else {
				mbrEnrollVOList = (List<EEMMbrEnrollmentVO>) getActiveDatedList(mbrEnrollVOList);
				setToContext(mbrEnrollVOList);
			}
			return mbrEnrollVOList;
		}
	}

	private void setToContext(List<EEMMbrEnrollmentVO> mbrEnrollVOList) {

		EEMContext context = sessionHelper.getEEMContext();
		context.getMbrMasterVO().setMbrEnrollmentList(mbrEnrollVOList);
		sessionHelper.setEEMContext(context);

	}

	public List<EEMMbrEnrollmentVO> getEnrollListFromDB(String memberId, String showAll) throws ApplicationException {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		List<EEMMbrEnrollmentVO> enrollVOList = new ArrayList<>();
		List<EEMMbrEnrollmentDO> enrollDOList = mbrDao.getMbrEnrollments(customerId, memberId, showAll);
		enrollDOList.forEach(enrollDO -> {
			EEMMbrEnrollmentVO enrollVO = new EEMMbrEnrollmentVO();
			BeanUtils.copyProperties(enrollDO, enrollVO);
			enrollVOList.add(enrollVO);
		});
		return enrollVOList;
	}

	public String getPlanType(String planId, String pbpId) throws ApplicationException {
		String custNbr = sessionHelper.getUserInfo().getCustNbr();
		return grpSvcDao.getPlanType(custNbr, planId, pbpId);
	}

	public List<EEMApplProductDO> memberGrpPrdSearch(EEMGroupProductSearchDO gpSearch) throws ApplicationException {

		String mcCustNbr = sessionHelper.getUserInfo().getCustNbr();
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		gpSearch.setCustomerId(customerId);
		gpSearch.setMcCustNbr(mcCustNbr);

		if (gpSearch.getOutOfArea() == null || "".equalsIgnoreCase(gpSearch.getOutOfArea()))
			gpSearch.setOutOfArea("N");

		if ("lookup".equals(gpSearch.getOutOfArea())) {
			getMbrOutOfAreaOn(gpSearch);
		}

		String zipCd5 = StringUtil.nonNullTrim(gpSearch.getZipCd5());
		String formatedEffDate = DateFormatter.reFormat(gpSearch.getEffDate(), DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
		gpSearch.setEffDate(formatedEffDate);

		if (zipCd5.equals("")) {
			getMbrPrimaryZipOn(gpSearch);
		}

		return grpSvcDao.searchGrpPrd(gpSearch);

	}

	@Transactional(rollbackOn = ApplicationException.class)
	public String insertPrintIDCardMbrTrigger(EEMMbrPrintIDCardVO mbrPrintIDCardVO) {

		mbrPrintIDCardVO.setCustomerId(sessionHelper.getUserInfo().getCustomerId());
		mbrPrintIDCardVO.setUserId(sessionHelper.getUserInfo().getUserId());
		mbrPrintIDCardVO.setTriggerType(EEMConstants.TRIG_TYPE_ICO);
		mbrPrintIDCardVO.setTriggerCode(EEMConstants.TRIG_CODE_IDCARD);
		EMMbrTriggerVO trigVO = null;
		EMMbrTriggerDO trigDO = new EMMbrTriggerDO();
		try {
			trigVO = getMbrTriggerVO(mbrPrintIDCardVO);
		} catch (ParseException exp) {
			throw new ApplicationException("INVALID DATE FORMAT");
		}

		BeanUtils.copyProperties(trigVO, trigDO);
		trigDO.setCreateUserId(mbrPrintIDCardVO.getUserId());
		trigDO.setLastUpdtUserId(mbrPrintIDCardVO.getUserId());

		String ts = DateUtil.getCurrentDatetimeStamp();
		trigDO.setOrigTriggerType("");
		trigDO.setOrigTriggerCode("");
		trigDO.setOrigEffectiveDate(trigVO.getEffectiveDate());
		trigDO.setOrigTriggerCreateTime(ts);
		trigDO.setCreateTime(ts);
		trigDO.setLastUpdtTime(ts);

		try {
			enrollDao.closeOpenPrintIDCardTrigger(trigDO);
			int count = mbrDao.insertMbrTrigger(trigDO);

			if (count > 0) {
				return "PRINT MATERIAL REQUEST SUBMITTED.";
			} else {
				throw new ApplicationException("PRINT MATERIAL REQUEST COULD'NT BE SUBMITTED.");
			}
		} catch (Exception exp) {
			throw new ApplicationException("PRINT MATERIAL REQUEST COULD'NT BE SUBMITTED.");
		}
	}

	private EMMbrTriggerVO getMbrTriggerVO(EEMMbrPrintIDCardVO mbrPrintIDCardVO) throws ParseException {

		List<LabelValuePair> sourceTriggerCodeMap = eemPer.sourceTriggerCodeMap();
		EMMbrTriggerVO trigVO = new EMMbrTriggerVO();
		trigVO.setCustomerId(mbrPrintIDCardVO.getCustomerId());
		trigVO.setMemberId(StringUtil.nonNullTrim(mbrPrintIDCardVO.getMemberId()));
		trigVO.setTriggerType(mbrPrintIDCardVO.getTriggerType());
		trigVO.setTriggerCode(mbrPrintIDCardVO.getTriggerCode());
		trigVO.setTriggerStatus("OPEN");

		trigVO.setPlanId(StringUtil.nonNullTrim(mbrPrintIDCardVO.getPlanId()));
		trigVO.setPbpId(StringUtil.nonNullTrim(mbrPrintIDCardVO.getPbpId()));
		trigVO.setPlanDesignation(StringUtil.nonNullTrim(mbrPrintIDCardVO.getPlanDesignation()));

		String printCode = StringUtil.nonNullTrim(mbrPrintIDCardVO.getPrintCode());

		if (codeCache.getDesc(printCode, sourceTriggerCodeMap) != null
				&& !codeCache.getDesc(printCode, sourceTriggerCodeMap).equals("")) {
			trigVO.setTriggerCode(codeCache.getDesc(printCode, sourceTriggerCodeMap));
		}
		trigVO.setProcessSource(printCode);
		boolean isUserEnteredEffDt = false;
		isUserEnteredEffDt = "Y".equalsIgnoreCase(eemProfileSett
				.getCalendarProfileItem(mbrPrintIDCardVO.getCustomerId(), EEMProfileConstants.IDUSREFFDT));

		trigVO.setEffectiveDate(DateUtil.getEffDateForIDC(mbrPrintIDCardVO.getEffectiveStartDate(), "MM/dd/yyyy",
				"yyyyMMdd", isUserEnteredEffDt));
		return trigVO;
	}

}
