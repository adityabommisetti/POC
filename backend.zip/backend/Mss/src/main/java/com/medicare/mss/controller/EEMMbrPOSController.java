package com.medicare.mss.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.service.EEMMbrPOSServices;
import com.medicare.mss.vo.EmMbrPosInfoVO;

@RestController
@RequestMapping("/member")
public class EEMMbrPOSController {

	@Autowired
	private EEMMbrPOSServices mbrPOSServices;

	@GetMapping(ReqMappingConstants.MBR_POS_SEARCH)
	public ResponseEntity<JSONResponse> getMemberPOSList(@PathVariable(name = "mbrId") String memberId,
			@PathVariable(name = "showAll") String showAll) {
		List<EmMbrPosInfoVO> mbrPOSVOList = mbrPOSServices.getMbrPOSInfoList(memberId, showAll);
		return sendResponse(mbrPOSVOList);
	}

	@PostMapping(ReqMappingConstants.MBR_POS_INFO_UPDATE)
	public ResponseEntity<JSONResponse> mbrPosInfoUpdate(@RequestBody EmMbrPosInfoVO wrkVO) {

		List<EmMbrPosInfoVO> mbrPOSVOList = mbrPOSServices.mbrPosUpdate(wrkVO);
		return sendResponse(mbrPOSVOList);
	}

	@PostMapping(ReqMappingConstants.MBR_POS_INFO_DELETE)
	public ResponseEntity<JSONResponse> mbrPosInfoDelete(@RequestBody EmMbrPosInfoVO delVO) {

		List<EmMbrPosInfoVO> mbrPOSVOList = mbrPOSServices.mbrPosInfoDelete(delVO);
		return sendResponse(mbrPOSVOList);
	}

	private ResponseEntity<JSONResponse> sendResponse(Object object) {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;
		jsonResponse.setData(object);
		if (null == object) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
			jsonResponse.setMessage(EEMConstants.BLANK);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}

}