package com.medicare.mss.rowmappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.medicare.mss.domainobject.EEMApplicationDO;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.StringUtil;

public class ApplicationRowMapper implements RowMapper<EEMApplicationDO> {
	private final Logger LOGGER = LogManager.getLogger(this.getClass());

	@Override
	public EEMApplicationDO mapRow(ResultSet rs, int rowNum) throws SQLException {

		EEMApplicationDO applDO = new EEMApplicationDO();

		applDO.setCustomerId(rs.getString("CUSTOMER_ID"));
		applDO.setApplId(rs.getInt("APPLICATION_ID"));
		applDO.setApplType(rs.getString("APPLICATION_TYPE"));
		applDO.setMbrApplNo(StringUtil.nonNullTrim(rs.getString("APPLICATION_NBR")));
		applDO.setApplDate(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("APPLICATION_DATE"))));
		applDO.setMbrLastName(StringUtil.nonNullTrim(rs.getString("LAST_NAME")));
		applDO.setMbrFirstName(StringUtil.nonNullTrim(rs.getString("FIRST_NAME")));
		applDO.setMbrMiddleName(StringUtil.nonNullTrim(rs.getString("MIDDLE_INIT")));
		applDO.setMbrPrefix(StringUtil.nonNullTrim(rs.getString("PREFIX")));
		applDO.setMailLastName(StringUtil.nonNullTrim(rs.getString("MAIL_LAST_NAME")));
		applDO.setMailFirstName(StringUtil.nonNullTrim(rs.getString("MAIL_FIRST_NAME")));
		applDO.setMailMiddleName(StringUtil.nonNullTrim(rs.getString("MAIL_MIDDLE_INIT")));
		applDO.setMbrId(StringUtil.nonNullTrim(rs.getString("MEMBER_ID")));
		applDO.setAltMbrId(StringUtil.nonNullTrim(rs.getString("SUPPLEMENTAL_ID")));

		String mbiNum = StringUtil.nonNullTrim(rs.getString("MBI"));
		applDO.setMbi(mbiNum);
		if (!mbiNum.equals("")) {
			applDO.setMbrHicNbr(StringUtil.nonNullTrim(rs.getString("MBI")));
			applDO.setDisplayHic(StringUtil.nonNullTrim(rs.getString("HIC_NBR")));
		} else {
			applDO.setMbrHicNbr(StringUtil.nonNullTrim(rs.getString("HIC_NBR")));
			applDO.setDisplayHic(StringUtil.nonNullTrim(rs.getString("HIC_NBR")));
		}

		applDO.setMbrRxId(StringUtil.nonNullTrim(rs.getString("RX_ID")));
		applDO.setMbrBirthDt(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("BIRTH_DATE"))));
		applDO.setMbrGender(StringUtil.nonNullTrim(rs.getString("GENDER_CD")));
		applDO.setMbrEmail(StringUtil.nonNullTrim(rs.getString("MBR_EMAIL")));
		applDO.setPwOption(StringUtil.nonNullTrim(rs.getString("PREMIUM_WITHHOLD_OPTION")));
		applDO.setSignOnFile(StringUtil.nonNullTrim(rs.getString("SGN_ONFILE_IND")));
		applDO.setSignDt(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("SGN_DATE"))));
		applDO.setAuthRepFirstName(StringUtil.nonNullTrim(rs.getString("AUTH_FIRST_NAME")));
		applDO.setAuthRepMidName(StringUtil.nonNullTrim(rs.getString("AUTH_MIDDLE_INIT")));
		applDO.setAuthRepLastName(StringUtil.nonNullTrim(rs.getString("AUTH_LAST_NAME")));
		applDO.setAuthRepRelation(StringUtil.nonNullTrim(rs.getString("AUTH_RELATIONSHIP_CD")));
		applDO.setEmergName(StringUtil.nonNullTrim(rs.getString("EMERGCY_NAME")));
		applDO.setEmergPhone(StringUtil.nonNullTrim(rs.getString("EMERGCY_PHONE")));
		applDO.setEmergRelation(StringUtil.nonNullTrim(rs.getString("EMERGCY_RELATIONSHIP_CD")));
		applDO.setEmergEmail(StringUtil.nonNullTrim(rs.getString("EMERGCY_EMAIL")));
		applDO.setInsCardName(StringUtil.nonNullTrim(rs.getString("INS_CARD_NAME")));
		applDO.setMbrSsn(StringUtil.nonNullTrim(rs.getString("SSN")));
		applDO.setLanguage(StringUtil.nonNullTrim(rs.getString("LANGUAGE_CD")));
		applDO.setEnrollSrceCd(StringUtil.nonNullTrim(rs.getString("ENROLL_SRCE_CD")));
		applDO.setOutOfArea(StringUtil.nonNullTrim(rs.getString("OOA_IND")));
		applDO.setCurrStatus(StringUtil.nonNullTrim(rs.getString("APPLICATION_STATUS")));
		applDO.setLstUpdtTime(StringUtil.nonNullTrim(rs.getString("LAST_UPDT_TIME")));
		applDO.setMbrSuffix(StringUtil.nonNullTrim(rs.getString("SUFFIX")));
		applDO.setMailSuffix(StringUtil.nonNullTrim(rs.getString("MAIL_SUFFIX")));
		applDO.setBillSuffix(StringUtil.nonNullTrim(rs.getString("BILL_SUFFIX")));
		applDO.setBillLastName(StringUtil.nonNullTrim(rs.getString("BILL_LAST_NAME")));
		applDO.setBillFirstName(StringUtil.nonNullTrim(rs.getString("BILL_FIRST_NAME")));
		applDO.setBillMiddleName(StringUtil.nonNullTrim(rs.getString("BILL_MIDDLE_INIT")));
		applDO.setApplCategory(StringUtil.nonNullTrim(rs.getString("APPLICATION_CATEGORY")));
		applDO.setCreateTime(StringUtil.nonNullTrim(rs.getString("CREATE_TIME")));
		applDO.setCreateUserId(StringUtil.nonNullTrim(rs.getString("CREATE_USERID")));
		applDO.setLstUpdtUserId(StringUtil.nonNullTrim(rs.getString("LAST_UPDT_USERID")));
		applDO.setEditOverride(StringUtil.nonNullTrim(rs.getString("EDIT_OVERRIDE_IND")));
		applDO.setReceiptDate(
				DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(StringUtil.nonNullTrim(rs.getString("RECEIPT_DATE")))));
		applDO.setSignOvrrdDt(StringUtil.nonNullTrim(rs.getString("SGN_DATE_OVR_IND")));
		applDO.setSubscriberId(StringUtil.nonNullTrim(rs.getString("SUBSCRIBER_ID")));
		/**
		 * Cambia_pplication Cancellation-Start
		 */
		applDO.setCancelReason(StringUtil.nonNullTrim(rs.getString("LTR_REASON_CD")));
		/**
		 * Cambia_pplication Cancellation-End
		 *//*
		*//**UseCaseName 015_Highmark_SUC_Denials-Start */
		applDO.setDenialRcvDt(DateFormatter.reFormatFiltered(StringUtil.nonNullTrim(rs.getString("DENIAL_RCVD_DATE")),
				DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		applDO.setDenialReasonCd(StringUtil.nonNullTrim(rs.getString("DENIAL_REASON_CD")));
		//applDO.setDenialDateFrmt(DateFormatter.reFormatFiltered(applDO.getDenialRcvDt(), DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		/**UseCaseName 015_Highmark_SUC_Denials- End */

		/**ACH Billing Properties For Cambia = 4 and Excellus = 6 */
		applDO.setAchNameOnAct(StringUtil.nonNullTrim(rs.getString("NAME_ON_ACCT")));
		applDO.setAchAccountType(StringUtil.nonNullTrim(rs.getString("ACCOUNT_TYPE")));
		applDO.setAchAbaRoutingNbr(StringUtil.nonNullTrim(rs.getString("ABA_ROUTING_NBR")));
		applDO.setAchbankAcctNbr(StringUtil.nonNullTrim(rs.getString("BANK_ACCT_NBR")));
		applDO.setAchBillFrequency(StringUtil.nonNullTrim(rs.getString("BILL_FREQUENCY")));
		/**ACH Billing Properties */
		applDO.setAppDuplicateCheck(StringUtil.nonNullTrim(rs.getString("DUPL_APP_OVRD_IND")));
		applDO.setXrefNbr(StringUtil.nonNullTrim(rs.getString("XREF_CLAIM_NBR"))); // IFOX-00397126
		
		
		applDO.setAltCorrespondenceInd(StringUtil.nonNullTrim(rs.getString("ALT_CORRES_IND")));
		//IFOX-00406767 -start
		applDO.setHealthPlanNews(StringUtil.nonNullTrim(rs.getString("HEALTH_PLAN_NEWS_EMAIL")));
		//IFOX-00406767 -end
		//Triple S BasePlus Migration/IFOX-00354933 START				
		applDO.setCompaignId(StringUtil.nonNullTrim(rs.getString("CAMPAIGN_ID")));
		applDO.setContractorNo(StringUtil.nonNullTrim(rs.getString("CONTRACT_ID")));
		//Triple S BasePlus Migration/IFOX-00354933 END
		// Triple S BasePlus Migration/DraftDay/BankName changes on Billing START
		applDO.setAchDraftDay(StringUtil.nonNullTrim(rs.getString("DRAFT_DAY")));
		applDO.setAchBankName(StringUtil.nonNullTrim(rs.getString("BANK_NAME")));
		// Triple S BasePlus Migration/DraftDay/BankName changes on Billing END
		LOGGER.debug("applDO.setAltCorrespondenceInd : "+applDO.getAltCorrespondenceInd());
		return applDO;
	}

}
