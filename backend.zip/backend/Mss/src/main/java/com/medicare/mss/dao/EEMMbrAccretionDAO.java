package com.medicare.mss.dao;

import java.util.List;

import com.medicare.mss.domainobject.EEMMbrAccretionDO;

public interface EEMMbrAccretionDAO {

	/**
	 * This method retrieves member accretion info
	 * 
	 * @param customerId customer id
	 * @param memberId member id
	 * @param showAll showAll flag
	 * @return list of member Accretion domain object
	 * 
	 **/
	List<EEMMbrAccretionDO> getMbrAccretion(String customerId, String memberId, String showAll);

}
