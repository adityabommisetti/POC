/**
 * 
 */
package com.medicare.mss.controller;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.service.EEMApplLepService;
import com.medicare.mss.service.EEMLepAttestService;
import com.medicare.mss.service.EEMLepMaximusService;
import com.medicare.mss.service.EEMMbrLepInfoService;
import com.medicare.mss.vo.EEMLepAttestCopyVO;
import com.medicare.mss.vo.EEMLepAttestInfoVO;
import com.medicare.mss.vo.EEMApplLepMasterVO;
import com.medicare.mss.vo.EEMLepPtnlUncovMthsVO;
import com.medicare.mss.vo.EEMLEPMaximusVO;
import com.medicare.mss.vo.EEMLepAttestCallMasterVO;
import com.medicare.mss.vo.EEMLepAttestCcfVO;
import com.medicare.mss.vo.EEMMbrLepInfoVO;

/**
 * @author DU20098149
 *
 */
@RestController
@RequestMapping("/mbr")
public class EEMMbrLepController {

	@Autowired
	private EEMLepMaximusService eemLepService;

	@Autowired
	private EEMApplLepService eemApplLepService;

	@Autowired
	private EEMMbrLepInfoService eemMbrLepInfoService;

	@Autowired
	private EEMLepAttestService attestService;

	@PostMapping(value = ReqMappingConstants.MBR_LEP_UPDATE_ATTEST_CALL)
	public ResponseEntity<JSONResponse> updateAttestCall(@RequestBody EEMLepAttestCallMasterVO lepMasterVO)
			throws ApplicationException {

		EEMLepAttestCallMasterVO masterVo = eemApplLepService.updateMbrAttestCall(lepMasterVO, true);
		return sendResponse(masterVo);

	}

	@PostMapping(value = ReqMappingConstants.MBR_LEP_UPDATE_ATTEST)
	public ResponseEntity<JSONResponse> updateCcfAttestation(@RequestBody EEMLepAttestInfoVO attestInfoVO)
			throws ApplicationException {

		EEMApplLepMasterVO lepMasterVo = eemApplLepService.mbrLepAttestInfoUpdate(attestInfoVO, true);

		return sendResponse(lepMasterVo);

	}

	@PostMapping(value = ReqMappingConstants.MBR_LEP_DELETE_CCF)
	public ResponseEntity<String> deleteCCfDetails(@RequestBody EEMLepAttestCcfVO ccfAttestVo) throws ApplicationException {

		boolean isUpdated = attestService.applAttnInfoDelete(ccfAttestVo, true);
		if (isUpdated) {
			return ResponseEntity.status(200).body("DELETED SUCCESSFULLY");
		}
		return ResponseEntity.status(204).body(null);

	}

	@PostMapping(value = ReqMappingConstants.MBR_LEP_COPY_ATTEST)
	public ResponseEntity<JSONResponse> copyCcfToUnCovMonth(@RequestBody EEMLepAttestCopyVO copyVo) throws ApplicationException {

		EEMLepAttestCopyVO response = attestService.applLepAttestCopy(copyVo, true);
		return sendResponse(response);

	}

	@PostMapping(value = ReqMappingConstants.MBR_LEP_ADD_CCF)
	public ResponseEntity<JSONResponse> addCcfDetails(@RequestBody EEMLepAttestCcfVO attestVO) throws ApplicationException {

		EEMLepAttestCcfVO attestCcfVO = attestService.applLepAttestAdd(attestVO, true);

		return sendResponse(attestCcfVO);

	}

	@GetMapping(value = ReqMappingConstants.MBR_LEP_GET_CCF)
	public ResponseEntity<JSONResponse> getCcfDetails(@PathVariable("mbrId") String mbrId,
			@PathVariable("showAll") String overrideInd) throws ApplicationException {

		List<EEMLepAttestCcfVO> ccfList = attestService.getCCfDetails(mbrId, overrideInd, true);

		return sendResponse(ccfList);
	}

	@PostMapping(value = ReqMappingConstants.MBR_LEP_DELETE_UNCOV)
	public ResponseEntity<JSONResponse> deleteUnCovMonth(@RequestBody EEMLepPtnlUncovMthsVO unCovVo) throws ApplicationException {

		Map<String, String> response = eemApplLepService.lepUnCovPtnlMnthDelete(unCovVo, true);

		return sendResponse(response);

	}

	@PostMapping(value = ReqMappingConstants.MBR_LEP_ADD_UNCOV)
	public ResponseEntity<JSONResponse> addUnCovMonth(@RequestBody EEMLepPtnlUncovMthsVO unCovVo) throws ApplicationException {

		EEMLepPtnlUncovMthsVO lepPtnlUncovMthsVO = eemApplLepService.lepUnCovPtnlMnthUpdate(unCovVo, true);

		return sendResponse(lepPtnlUncovMthsVO);

	}

	@GetMapping(value = ReqMappingConstants.MBR_LEP_GET_UNCOV)
	public ResponseEntity<JSONResponse> getUnCovMonths(@PathVariable("mbrId") String mbrId,
			@PathVariable("showAll") String overrideInd) throws ApplicationException {

		List<EEMLepPtnlUncovMthsVO> unCovMonthList = eemApplLepService.getPtnlUnCovMnthsApplLep(mbrId, overrideInd,
				true);
		boolean isEmpty = CollectionUtils.isEmpty(unCovMonthList);

		return sendResponse(!isEmpty ? unCovMonthList : null);

	}

	@PostMapping(ReqMappingConstants.MAXIMUS_UPDATE)
	public ResponseEntity<JSONResponse> updateEEMLepMaximus(@RequestBody EEMLEPMaximusVO eemLEPMaximusVO)
			throws ApplicationException, ParseException {

		EEMLEPMaximusVO updatedVO = eemLepService.updateEEMLepMaximus(eemLEPMaximusVO);

		return sendResponse(updatedVO);

	}

	@GetMapping(ReqMappingConstants.GET_MBR_LEP)
	public ResponseEntity<JSONResponse> getMbrLepInfo(@PathVariable(name = "mbrId") String mbrId,
			@PathVariable(name = "showAll") String showAll) throws ApplicationException {

		EEMApplLepMasterVO mbrLepDetails = eemMbrLepInfoService.getMbrLepInfo(mbrId,showAll);

		return sendResponse(mbrLepDetails);

	}

	@GetMapping(ReqMappingConstants.MBR_LEP_GET_SHOWALL)
	public ResponseEntity<JSONResponse> getMbrLepInfoShowAll(@PathVariable(name = "mbrId") String mbrId) throws ApplicationException {

		List<EEMMbrLepInfoVO> mbrLepInfoVOList = eemMbrLepInfoService.getMbrLepInfos(mbrId, "Y");
		return sendResponse(mbrLepInfoVOList);

	}

	@PostMapping(ReqMappingConstants.UPDATE_MBR_LEP)
	public ResponseEntity<JSONResponse> updateMbrLepInfo(@RequestBody EEMMbrLepInfoVO eemMbrLepInfoVO)
			throws ApplicationException {

		boolean updateSuccess = eemMbrLepInfoService.mbrLepInfoUpdate(eemMbrLepInfoVO, true);

		if (updateSuccess) {
			List<EEMMbrLepInfoVO> mbrLepInfoVOList = eemMbrLepInfoService.getMbrLepInfos(eemMbrLepInfoVO.getMemberId(),
					eemMbrLepInfoVO.getShowAll());
			return sendResponse(mbrLepInfoVOList);
		} else {
			return sendResponse(null);
		}

	}

	@PostMapping(ReqMappingConstants.DELETE_MBR_LEP)
	public ResponseEntity<JSONResponse> deleteMbrLtcInfo(@RequestBody EEMMbrLepInfoVO eemMbrLepInfoVO)
			throws ApplicationException {

		boolean isDeleted = eemMbrLepInfoService.mbrLepInfoDelete(eemMbrLepInfoVO);

		if (isDeleted) {
			List<EEMMbrLepInfoVO> mbrLepInfoVOList = eemMbrLepInfoService.getMbrLepInfos(eemMbrLepInfoVO.getMemberId(),
					eemMbrLepInfoVO.getShowAll());
			return sendResponse(mbrLepInfoVOList);
		} else {
			return sendResponse(null);
		}

	}
	
	@PostMapping(ReqMappingConstants.MBR_LEP_ATTEST_LETTER)
	public ResponseEntity<JSONResponse> displayDocumentFromDB(@RequestBody Map<String, String> searchParamMap) {

		byte[] blobByte = attestService.displayDocumentFromDB(searchParamMap);
		return sendResponse(blobByte);

	}

	private ResponseEntity<JSONResponse> sendResponse(Object object) {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;
		if (null == object) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			jsonResponse.setData(null);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
			jsonResponse.setMessage(EEMConstants.BLANK);
			jsonResponse.setData(object);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}

}
