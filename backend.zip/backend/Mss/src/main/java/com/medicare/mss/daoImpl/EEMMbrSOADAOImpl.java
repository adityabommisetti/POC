package com.medicare.mss.daoImpl;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.medicare.mss.dao.EEMMbrSOADAO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.vo.EMDatedSegmentVO;

@Repository
public class EEMMbrSOADAOImpl implements EEMMbrSOADAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public byte[] displayDocumentFromDB(String primaryId, String customerId) {
		byte[] blobByte = null;
		java.sql.Blob blob = null;
		try {

			StringBuilder sQuery = CommonUtils.buildQueryBuilder("SELECT LETTER_PDF FROM EM_CORR_DMS ",
					"WHERE CUSTOMER_ID = ? AND PRIMARY_ID = ? AND CUSTOMER_LETTER_NAME = 'SOA' ",
					"ORDER BY LETTER_CREATION_TIME DESC FETCH FIRST ROW ONLY");

			blob = jdbcTemplate.queryForObject(sQuery.toString(), new Object[] { customerId, primaryId },
					java.sql.Blob.class);

			blobByte = blob.getBytes(1, (int) blob.length());

		} catch (EmptyResultDataAccessException exp) {
			throw new ApplicationException(exp, "PDF file is not available");
		} catch (SQLException exp) {
			throw new ApplicationException(exp, "Error occured while fetching the letter");
		}
		return blobByte;
	}

	@Override
	public int setOverride(EMDatedSegmentVO emDatedSegmentVO, String userId) {
		return 0;
	}

	@Override
	public int insertMbr(EMDatedSegmentVO emDatedSegmentVO) {
		return 0;
	}

}
