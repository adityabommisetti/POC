package com.medicare.mss.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.caching.EEMProfileSettings;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMApplLepDAO;
import com.medicare.mss.dao.EEMLepDAO;
import com.medicare.mss.dao.EEMMbrDAO;
import com.medicare.mss.domainobject.EEMLepAttestCcfDO;
import com.medicare.mss.domainobject.EEMLepAttestInfoDO;
import com.medicare.mss.domainobject.EEMLepPtnlUncovMthsDO;
import com.medicare.mss.domainobject.EMMbrTriggerDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.helper.EEMEnrollHelper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EEMApplLepMasterVO;
import com.medicare.mss.vo.EEMLepAttestCcfVO;
import com.medicare.mss.vo.EEMLepAttestCopyVO;
import com.medicare.mss.vo.EEMLepAttestInfoVO;
import com.medicare.mss.vo.EEMLepPtnlUncovMthsVO;
import com.medicare.mss.vo.EEMMbrLepInfoVO;

@Service
public class EEMLepAttestService {

	private static final Logger LOG = LoggerFactory.getLogger(EEMLepAttestService.class);

	@Autowired
	private CacheService sessionHelper;

	@Autowired
	private EEMApplLepDAO lepDao;

	@Autowired
	private EEMMbrLepInfoService eemMbrLepInfoService;

	@Autowired
	private EEMProfileSettings eemProfileSettings;

	@Autowired
	private EEMEnrollHelper enrollHelper;

	@Autowired
	private EEMMbrDAO mbrDAO;
	
	@Autowired
	private EEMLepDAO eemLepDAO;

	@Transactional(readOnly = true)
	public List<EEMLepAttestCcfVO> getCCfDetails(String primaryId, String overrideInd, boolean isMember)
			throws ApplicationException {
		String customerId = sessionHelper.getUserInfo().getCustomerId();

		List<EEMLepAttestCcfDO> applCcfResp = lepDao.getApplCcfResp(customerId, primaryId, overrideInd, isMember);
		List<EEMLepAttestCcfVO> applLepCCFResp = new ArrayList<>();

		CommonUtils.copyList(applCcfResp, applLepCCFResp, EEMLepAttestCcfVO.class);
		return applLepCCFResp;
	}

	public boolean applAttnInfoDelete(EEMLepAttestCcfVO ccfAttestVo, boolean isMember) throws ApplicationException {
		String userId = sessionHelper.getUserInfo().getUserId();
		String ts = DateUtil.getCurrentDatetimeStamp();
		ccfAttestVo.setLastUpdtTime(ts);

		EEMLepAttestCcfDO tagetDO = new EEMLepAttestCcfDO();
		BeanUtils.copyProperties(ccfAttestVo, tagetDO);
		tagetDO.setUserId(userId);

		Integer res = lepDao.overrideApplAttnInfo(tagetDO, isMember);

		return res > 0 ? true : false;
	}

	public EEMLepAttestInfoVO applLepAttestInfoUpdate(EEMLepAttestInfoVO attestInfoVO, boolean isMember)
			throws ApplicationException {
		Integer sqlCnt = 0;
		boolean res = false;
		String userId = sessionHelper.getUserInfo().getUserId();
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String primaryId = attestInfoVO.getPrimaryId();
		int totalPotUnCovMonth = 0;

		String oldStatus = StringUtil.nonNullTrim(attestInfoVO.getOldAttestStatus());

		String ts = DateUtil.getCurrentDatetimeStamp();
		String applIncAttRCDT = StringUtil.nonNullTrim(attestInfoVO.getAppIncAttRcDt());
		String appIncAttLetExpDt = EEMConstants.BLANK;

		if (!applIncAttRCDT.isEmpty()) {
			applIncAttRCDT = DateFormatter.reFormat(applIncAttRCDT, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
			/** Adding 28 days in application incomplete received date. */
			try {
				appIncAttLetExpDt = DateMath.addDay(applIncAttRCDT, 28);
			} catch (ParseException exp) {
				exp.printStackTrace();
			}
		}

		attestInfoVO.setCreateTime(ts);
		attestInfoVO.setCustomerId(customerId);
		attestInfoVO.setUserId(userId);
		attestInfoVO.setAppIncAttRcDt(applIncAttRCDT);
		attestInfoVO.setAppIncAttLetExpDt(appIncAttLetExpDt);
		EEMLepAttestInfoDO newDo = new EEMLepAttestInfoDO();
		BeanUtils.copyProperties(attestInfoVO, newDo);

		EMMbrTriggerDO triggerDO = new EMMbrTriggerDO();
		triggerDO.setCustomerId(customerId);
		triggerDO.setMemberId(primaryId);
		triggerDO.setCreateTime(ts);
		triggerDO.setCustomerId(customerId);
		triggerDO.setCreateUserId(userId);
		triggerDO.setPrimaryId(primaryId);

		if ("C".equalsIgnoreCase(attestInfoVO.getAttestStatus())) {

			if (!oldStatus.isEmpty()) {
				lepDao.overrideApplLepAttnDetails(customerId, primaryId, userId, isMember);
			}
			sqlCnt = lepDao.insertApplLepAttnDetails(newDo, isMember);

			if (sqlCnt == 1) {
				/** Close all timer related to the current application. **/

				if (!isMember) {
					res = true;
					Integer sqlCnt1 = lepDao.closeALLApplTimers(triggerDO, isMember, EEMConstants.BLANK);
					if (sqlCnt1 > 0) {
						attestInfoVO.setLe21TimerCheck("closed");
						attestInfoVO.setObc1TimerCheck("closed");
						attestInfoVO.setObc2TimerCheck("closed");
						attestInfoVO.setObc3TimerCheck("closed");
					}
				} else {
					res = updateMbrLepData(isMember, userId, customerId, primaryId, totalPotUnCovMonth, ts, newDo,
							triggerDO);
					res = true;

				}

			}

			/** If Attestation status is IN-COMPLETE */
		} else if ("I".equalsIgnoreCase(attestInfoVO.getAttestStatus())) {

			if (!oldStatus.isEmpty()) {
				/** Update the 'EM_APPL_CCF_RESP' table with override 'Y' **/
				lepDao.overrideApplLepAttnDetails(customerId, primaryId, userId, isMember);
			}
			/** Insert the record in 'EM_APPL_CCF_RESP' table' */
			sqlCnt = lepDao.insertApplLepAttnDetails(newDo, isMember);

			if (sqlCnt == 1) {
				res = true;

				if (!isMember) {
					/** LE21 timer trigger code */
					int sqlCnt1 = lepDao.invokeTriggerUpdate(customerId, primaryId, userId, isMember);
					if (sqlCnt1 > 0) {

						attestInfoVO.setLe21TimerCheck("true");
					}
				} else {

					/** LE21 timer trigger code */

					triggerLEIncompleteTimer(newDo, triggerDO, isMember, "'OBC1','OBC2','OBC3'");

					res = true;
				}
				/** If Attestation status is MISSING */
			}
		} else if ("M".equalsIgnoreCase(attestInfoVO.getAttestStatus())) {

			if (!oldStatus.isEmpty()) {
				/** Update the 'EM_APPL_CCF_RESP' table with override 'Y' **/
				lepDao.overrideApplLepAttnDetails(customerId, primaryId, userId, isMember);
			}
			/** Insert the record in 'EM_APPL_CCF_RESP' table' */
			sqlCnt = lepDao.insertApplLepAttnDetails(newDo, isMember);

			if (sqlCnt > 0) {
				res = true;
			}
		}

		return res ? attestInfoVO : null;
	}

	private int triggerLEIncompleteTimer(EEMLepAttestInfoDO newDo, EMMbrTriggerDO triggerDO, boolean isMember,
			String triggerCodes) throws ApplicationException {

		Integer sqlCnt1 = lepDao.closeALLApplTimers(triggerDO, isMember, triggerCodes);

		boolean le21Check = lepDao.checkMbrTriggerStatus(triggerDO.getCustomerId(), triggerDO.getPrimaryId(),
				EEMConstants.TRIG_CODE_LE21, EEMConstants.TRIG_STATUS_OPEN);
		triggerDO.setTriggerCode(EEMConstants.TRIG_CODE_LE21);
		triggerDO.setTriggerStatus(EEMConstants.TRIG_STATUS_OPEN);

		if (!le21Check) {
			int le21Exist = insertMbrTimer(newDo, triggerDO, le21Check);

			if (le21Exist > 0) {
				newDo.setLe21TimerCheck("true");
			}
		}
		return sqlCnt1;
	}

	private int insertMbrTimer(EEMLepAttestInfoDO newDo, EMMbrTriggerDO triggerDO, boolean le21Check)
			throws ApplicationException {

		String trigEffectDate = EEMConstants.BLANK;

		String customerId = newDo.getCustomerId();

		int interval = eemProfileSettings.getParmNumber(customerId, EEMConstants.TRIG_CODE_LE21);

		String attestRecDate = StringUtil.nonNullTrim(newDo.getAttestationRecDate());
		if (!attestRecDate.isEmpty()) {
			String modifiedDate = StringUtil.nonNullTrim(
					DateFormatter.reFormat(attestRecDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));

			if (StringUtils.isNotBlank(modifiedDate)) {
				SimpleDateFormat sdFormat = new SimpleDateFormat("yyyyMMdd");
				Calendar calendar = Calendar.getInstance();
				try {
					calendar.setTime(sdFormat.parse(modifiedDate));
				} catch (ParseException e) {
					e.printStackTrace();
				}
				calendar.add(Calendar.DAY_OF_MONTH, interval);
				trigEffectDate = sdFormat.format(calendar.getTime());
			}
		}

		EEMApplLepMasterVO eemLepMasterVO = sessionHelper.getEEMContext().getMbrMasterVO().getEemLepMasterVO();
		List<EEMMbrLepInfoVO> eemMbrLepInfoVOs = eemLepMasterVO.getEemMbrLepInfoVOs();

		String effStartDate = sessionHelper.getEEMContext().getMbrMasterVO().getMbrEnrollmentList().get(0)
				.getEffStartDate();

		if (trigEffectDate.isEmpty()) {
			trigEffectDate = effStartDate;
		}

		String pbpId = EEMConstants.BLANK;
		String planId = EEMConstants.BLANK;
		String planDesig = EEMConstants.BLANK;

		if (!CollectionUtils.isEmpty(eemMbrLepInfoVOs)) {
			EEMMbrLepInfoVO eemMbrLepInfoVO = eemMbrLepInfoVOs.get(0);
			pbpId = eemMbrLepInfoVO.getPbpId();
			planId = eemMbrLepInfoVO.getPlanId();
			planDesig = eemMbrLepInfoVO.getPlanDesignation();

		}

		String effDateFrmt = DateFormatter.reFormat(trigEffectDate, DateFormatter.YYYY_MM_DD, DateFormatter.YYYYMMDD);
		
		EMMbrTriggerDO trig = enrollHelper.prepareMbrTriggerDO(newDo.getPrimaryId(), EEMConstants.TRIG_TYPE_FOLLOWUP_MEMB,
				EEMConstants.TRIG_STATUS_OPEN, EEMConstants.TRIG_CODE_LE21, effDateFrmt);
		trig.setPlanId(planId);
		trig.setPbpId(pbpId);
		trig.setPlanDesignation(planDesig);
		trig.setCreateUserId(newDo.getCreateUserId());
		trig.setLastUpdtUserId(newDo.getCreateUserId());
		trig.setProcessSource(EEMConstants.PROCESS_SOURCE_MBR);
		trig.setCustomerId(customerId);
		return mbrDAO.insertMbrTrigger(trig);

	}

	private boolean updateMbrLepData(boolean isMember, String userId, String customerId, String primaryId,
			int totalPotUnCovMonth, String ts, EEMLepAttestInfoDO newDo, EMMbrTriggerDO mbrTriggerDO)
			throws ApplicationException {
		
		boolean res = false;
		List<EEMLepPtnlUncovMthsVO> potentialUnCovMthsList = sessionHelper.getEEMContext().getMbrMasterVO()
				.getEemLepMasterVO().getPotentialUnCovMthsList();

		String potentiallepEffDate = EEMConstants.BLANK;

		if (!potentialUnCovMthsList.isEmpty()) {
			totalPotUnCovMonth = potentialUnCovMthsList.stream()
					.filter(x -> EEMConstants.VALUE_NO.equals(x.getOverRideInd()))
					.mapToInt(EEMLepPtnlUncovMthsVO::getPlepMonths).sum();
			potentiallepEffDate = potentialUnCovMthsList.get(potentialUnCovMthsList.size() - 1).getLepEffDate();
		}
		if (totalPotUnCovMonth > 0) {

			List<EEMMbrLepInfoVO> eemMbrLepInfoVOs = sessionHelper.getEEMContext().getMbrMasterVO().getEemLepMasterVO()
					.getEemMbrLepInfoVOs();

			String effStartDate = sessionHelper.getEEMContext().getMbrMasterVO().getMbrEnrollmentList().get(0)
					.getEffStartDate();

			if (!CollectionUtils.isEmpty(eemMbrLepInfoVOs)) {
				EEMMbrLepInfoVO eemMbrLepInfoVO = eemMbrLepInfoVOs.get(0);

				boolean is73Triggered = lepDao.checkMbrTriggerStatus(customerId, primaryId, EEMConstants.TRIG_CODE_73,
						EEMConstants.TRIG_STATUS_OPEN);
				boolean isOBC2Expired = lepDao.checkMbrTriggerStatus(customerId, primaryId, EEMConstants.TRIG_CODE_OBC2,
						EEMConstants.TRIG_STATUS_EXPIRED);

				if (!(eemMbrLepInfoVO.getNbrUncovMonths() == totalPotUnCovMonth
						&& eemMbrLepInfoVO.getEffStartDate().equalsIgnoreCase(potentiallepEffDate) && is73Triggered
						&& isOBC2Expired)) {

					insertLepDataWithTrigger(userId, customerId, primaryId, totalPotUnCovMonth, ts, effStartDate,
							eemMbrLepInfoVO, potentiallepEffDate);

				}
			} else {

				EEMMbrLepInfoVO eemMbrLepInfoVO = new EEMMbrLepInfoVO();
				eemMbrLepInfoVO.setMemberId(newDo.getPrimaryId());
				insertLepDataWithTrigger(userId, customerId, primaryId, totalPotUnCovMonth, ts, effStartDate,
						eemMbrLepInfoVO, potentiallepEffDate);

			}
		}

		lepDao.closeALLApplTimers(mbrTriggerDO, isMember, EEMConstants.BLANK);
		res = true;

		return res;

	}

	private void insertLepDataWithTrigger(String userId, String customerId, String primaryId, int totalPotUnCovMonth,
			String ts, String effStartDate, EEMMbrLepInfoVO eemMbrLepInfoVO, String potentiallepEffDate)
			throws ApplicationException {
		eemMbrLepInfoVO.setNbrUncovMonths(totalPotUnCovMonth);
		eemMbrLepInfoVO.setEffStartDate(potentiallepEffDate);
		eemMbrLepInfoVO.setEnrollEffStartDate(potentiallepEffDate);
		eemMbrLepInfoVO.setEffEndDate(EEMConstants.EFF_END_DATE);
		eemMbrLepInfoVO.setCreditableCoverageFlag(EEMConstants.VALUE_NO);
		eemMbrLepInfoVO.setTrg73Ind(EEMConstants.VALUE_YES);
		eemMbrLepInfoVO.setLepAmt("0.00");
		eemMbrLepInfoVO.setLepWaivedAmt("0.00");
		eemMbrLepInfoVO.setLepType(EEMConstants.BLANK);
		eemMbrLepInfoVO.setAttstLockInd(EEMConstants.BLANK);
		eemMbrLepInfoVO.setAttestStatus(EEMConstants.BLANK);
		eemMbrLepInfoVO.setIncompAttestLetRecDate(EEMConstants.BLANK);
		eemMbrLepInfoVO.setAttestationRecDate(EEMConstants.BLANK);
		eemMbrLepInfoVO.setAttestationRecChannel(EEMConstants.BLANK);
		eemMbrLepInfoVO.setNotifiedMemberAppeal(EEMConstants.BLANK);
		eemMbrLepInfoVO.setEditOverrideInd(EEMConstants.BLANK);

		eemMbrLepInfoService.mbrLepInfoUpdate(eemMbrLepInfoVO, false);

		EMMbrTriggerDO trig = enrollHelper.prepareMbrTriggerDO(primaryId, EEMConstants.TRIG_TYPE_TXN,
				EEMConstants.TRIG_STATUS_OPEN, EEMConstants.TRIG_CODE_LE21, EEMConstants.BLANK);
		trig.setPlanId(eemMbrLepInfoVO.getPlanId());
		trig.setPbpId(eemMbrLepInfoVO.getPbpId());
		trig.setPlanDesignation(eemMbrLepInfoVO.getPlanDesignation());
		trig.setTriggerStatus(EEMConstants.TRIG_STATUS_OPEN);
		trig.setProcessSource(EEMConstants.TRIG_PROCESS_SOURCE_WEBENRL);

		String effDate = StringUtils.trimToEmpty(eemMbrLepInfoVO.getEffStartDate());
		if (effDate.isEmpty()) {
			effDate = effStartDate;

		}
		trig.setEffectiveDate(DateFormatter.reFormat(effDate, DateFormatter.YYYY_MM_DD, DateFormatter.YYYYMMDD));
		trig.setTriggerCode(EEMConstants.TRIG_CODE_73);

		mbrDAO.insertMbrTrigger(trig);
	}

	public EEMLepAttestCcfVO applLepAttestAdd(EEMLepAttestCcfVO attestVO, boolean isMember)
			throws ApplicationException {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();

		String respType = StringUtil.nonNullTrim(attestVO.getRespType());
		String txtBrkInCoverage = StringUtil.nonNullTrim(attestVO.getBrkInCoverage());

		if (EEMConstants.VALUE_YES.equalsIgnoreCase(txtBrkInCoverage)) {
			attestVO.setCcfUncovMnths(0);
		} else if (EEMConstants.VALUE_NO.equalsIgnoreCase(txtBrkInCoverage) || "P".equalsIgnoreCase(txtBrkInCoverage)) {
			String frmDate = DateFormatter.reFormat(StringUtil.nonNullTrim(attestVO.getFromDate()),
					DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
			String toDate = DateFormatter.reFormat(StringUtil.nonNullTrim(attestVO.getToDate()),
					DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
			int uncovMonths = 0;
			try {
				uncovMonths = DateMath.monthsBetween(frmDate, toDate);
			} catch (ParseException exp) {
				LOG.error(exp.getMessage());

			}
			attestVO.setCcfUncovMnths(uncovMonths + 1);
		}

		String ts = DateUtil.getCurrentDatetimeStamp();
		attestVO.setCreateTime(ts);
		attestVO.setLastUpdtTime(ts);
		attestVO.setCustomerId(customerId);
		attestVO.setCreateUserId(userId);
		attestVO.setOverRideInd(EEMConstants.OVERRIDE_IND_N);

		EEMLepAttestCcfDO targetDO = new EEMLepAttestCcfDO();

		BeanUtils.copyProperties(attestVO, targetDO);
		int sqlCnt1 = lepDao.insertAttnDetailsInCCF(targetDO, isMember);
		attestVO.setBrkInCoverage(CommonUtils.getBreakCovType(txtBrkInCoverage));
		attestVO.setRespType(CommonUtils.getRespType(respType));

		return sqlCnt1 > 0 ? attestVO : null;
	}

	public EEMLepAttestCopyVO applLepAttestCopy(EEMLepAttestCopyVO copyVO, boolean isMember)
			throws ApplicationException {
		Integer res = 0;
		Integer totalPlepMonths = 0;
		Integer plepMonths = 0;

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();
		String primaryId = copyVO.getPrimaryId();
		String reqDateCov = copyVO.getReqDateCov();

		lepDao.overridePLepApplDetails(customerId, userId, primaryId, isMember);

		List<EEMLepAttestCcfVO> ccfList = copyVO.getLepAttestListReq();

		for (EEMLepAttestCcfVO eemLepAttestVO : ccfList) {

			EEMLepPtnlUncovMthsDO lepPtnlUncovMthsDO = new EEMLepPtnlUncovMthsDO();
			lepPtnlUncovMthsDO.setLastUpdtUserId(userId);

			lepPtnlUncovMthsDO.setCustomerId(customerId);
			lepPtnlUncovMthsDO.setPrimaryId(primaryId);

			String lepEffDate = DateFormatter.reFormat(StringUtil.nonNullTrim(reqDateCov), DateFormatter.MM_DD_YYYY,
					DateFormatter.YYYYMMDD);
			lepPtnlUncovMthsDO.setLepEffDate(lepEffDate);
			lepPtnlUncovMthsDO.setCreateUserId(userId);
			String frmDate = DateFormatter.reFormat(StringUtil.nonNullTrim(eemLepAttestVO.getFromDate()),
					DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
			String toDate = DateFormatter.reFormat(StringUtil.nonNullTrim(eemLepAttestVO.getToDate()),
					DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);

			try {
				plepMonths = DateMath.monthsBetween(frmDate, toDate) + 1;
			} catch (ParseException exp) {
				LOG.error("EEMApplLepService.applLepAttestCopy() - {}", exp);
			}
			totalPlepMonths = totalPlepMonths + plepMonths;
			lepPtnlUncovMthsDO.setUncovMthStDt(StringUtil.nonNullTrim(eemLepAttestVO.getFromDate()));
			lepPtnlUncovMthsDO.setUncovMthEndDt(StringUtil.nonNullTrim(eemLepAttestVO.getToDate()));
			lepPtnlUncovMthsDO.setPlepMonths(plepMonths);

			String ts = DateUtil.getCurrentDatetimeStamp();

			lepPtnlUncovMthsDO.setCreateTime(ts);
			lepPtnlUncovMthsDO.setLastUpdtTime(ts);

			res = lepDao.insertApplPtnlUnCovMnthsDetails(lepPtnlUncovMthsDO, isMember);
			lepPtnlUncovMthsDO.setOverRideInd(EEMConstants.VALUE_NO);

		}

		List<EEMLepPtnlUncovMthsDO> ptnlUnCovMnthsApplLep = lepDao.getPotentialUnCovMonth(customerId, primaryId,
				EEMConstants.VALUE_NO, isMember);
		copyVO.setTotalPlepMonths(totalPlepMonths);
		copyVO.setLepAttestListReq(null);
		List<EEMLepPtnlUncovMthsVO> volist = new ArrayList<EEMLepPtnlUncovMthsVO>();

		CommonUtils.copyList(ptnlUnCovMnthsApplLep, volist, EEMLepPtnlUncovMthsVO.class);

		copyVO.setLepAttestListResp(volist);

		return res > 0 ? copyVO : null;

	}

	public byte[] displayDocumentFromDB(Map<String, String> searchParamMap) {
		byte[] blobByte = null;

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		searchParamMap.put("customerId", customerId);

		blobByte = eemLepDAO.displayDocumentFromDB(searchParamMap);

		return blobByte;
	}

}
