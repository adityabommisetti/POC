package com.medicare.mss.rowmappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.medicare.mss.domainobject.EEMApplPlanDO;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.StringUtil;

public class ApplPlanRowMapper implements  RowMapper<EEMApplPlanDO>{

	@Override
	public EEMApplPlanDO mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		EEMApplPlanDO applPlanVO = new EEMApplPlanDO();
		
		applPlanVO.setReqDtCov(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("EFFECTIVE_DATE"))));
		//applPlanVO.setElectionTypeCd(StringUtil.nonNullTrim(rs.getString("ELECTION_TYPE_CD")));
		applPlanVO.setElectionType(StringUtil.nonNullTrim(rs.getString("ELECTION_TYPE_CD")));
		applPlanVO.setSepElectionDt(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("SEP_ELECTION_DATE"))));
		//applPlanVO.setSepReasonCd(StringUtil.nonNullTrim(rs.getString("SEP_REASON_CD")));
		applPlanVO.setSepReason(StringUtil.nonNullTrim(rs.getString("SEP_REASON_CD")));
		applPlanVO.setCurrPlanId(StringUtil.nonNullTrim(rs.getString("FROM_PLAN_ID")));
		applPlanVO.setCurrPbpId(StringUtil.nonNullTrim(rs.getString("FROM_PBP_ID")));
		applPlanVO.setCurrPbpSegmentId(StringUtil.nonNullTrim(rs.getString("FROM_PBP_SEGMENT_ID")));
		applPlanVO.setCurrProductId(StringUtil.nonNullTrim(rs.getString("FROM_PRODUCT_ID")));
		applPlanVO.setCurrPaymentAmt(StringUtil.nonNullTrim(rs.getString("FROM_PAYMENT_AMT")));
		applPlanVO.setCurrGrpId(StringUtil.nonNullTrim(rs.getString("FROM_GROUP_ID")));
		//applPlanVO.setEnrollPlanId(StringUtil.nonNullTrim(rs.getString("TO_PLAN_ID")));
		applPlanVO.setEnrollPlan(StringUtil.nonNullTrim(rs.getString("TO_PLAN_ID")));
		//applPlanVO.setEnrollPbpId(StringUtil.nonNullTrim(rs.getString("TO_PBP_ID")));
		applPlanVO.setEnrollPbp(StringUtil.nonNullTrim(rs.getString("TO_PBP_ID")));
		//applPlanVO.setEnrollPbpSegmentId(StringUtil.nonNullTrim(rs.getString("TO_PBP_SEGMENT_ID")));
		applPlanVO.setEnrollSegment(StringUtil.nonNullTrim(rs.getString("TO_PBP_SEGMENT_ID")));
		//applPlanVO.setEnrollProductId(StringUtil.nonNullTrim(rs.getString("TO_PRODUCT_ID")));
		applPlanVO.setEnrollProduct(StringUtil.nonNullTrim(rs.getString("TO_PRODUCT_ID")));
		//applPlanVO.setEnrollPaymentAmt(StringUtil.nonNullTrim(rs.getString("TO_PAYMENT_AMT")));
		applPlanVO.setEnrollPymtAmt(StringUtil.nonNullTrim(rs.getString("TO_PAYMENT_AMT")));
		applPlanVO.setEnrollGrpId(StringUtil.nonNullTrim(rs.getString("TO_GROUP_ID")));
		applPlanVO.setLastUpdtTime(StringUtil.nonNullTrim(rs.getString("LAST_UPDT_TIME")));
		applPlanVO.setElcDerivedInd(StringUtil.nonNullTrim(rs.getString("ELC_DERIVED_IND")));
		
		return applPlanVO;
	}

}
