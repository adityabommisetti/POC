package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMBilPaymentEntryDO {

	@ColumnMapper(columnName = "PAY_SOURCE_TYPE", propertyName = "paySource")
	private String paySource;

	@ColumnMapper(columnName = "BATCH_DATE", propertyName = "batchDate")
	private String batchDate;

	@ColumnMapper(columnName = "BATCH_SEQ_NBR", propertyName = "batchSeqNbr")
	private String batchSeqNbr;

	@ColumnMapper(columnName = "BATCH_BALANCE_AMT", propertyName = "batchBalance")
	private String batchBalance;

	@ColumnMapper(columnName = "DETAIL_TOTAL_AMT", propertyName = "detailAmount")
	private String detailAmount;

	@ColumnMapper(columnName = "BANK_ACCT_CD", propertyName = "bankAcntCd")
	private String bankAcntCd;

	@ColumnMapper(columnName = "BATCH_BALANCE_IND", propertyName = "batchBalInd")
	private String batchBalInd;

	@ColumnMapper(columnName = "BATCH_POSTED_IND", propertyName = "batchPostedInd")
	private String batchPostedInd;

	@ColumnMapper(columnName = "CREATE_TIME", propertyName = "createTime")
	private String createTime;

	@ColumnMapper(columnName = "CREATE_USERID", propertyName = "createUser")
	private String createUser;

	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "modifiedTime")
	private String modifiedTime;

	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "modifiedUser")
	private String modifiedUser;
	
	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;
	
	@ColumnMapper(columnName = "BATCH_DETAIL_CNT", propertyName = "batchDtlCount")
	private String batchDtlCount;

}
