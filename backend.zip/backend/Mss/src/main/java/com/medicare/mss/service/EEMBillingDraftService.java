package com.medicare.mss.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.dao.EEMBillingDraftDAO;
import com.medicare.mss.domainobject.BillingDraftDetailDO;
import com.medicare.mss.domainobject.BillingDraftHeaderDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.BillingDraftDetailVO;
import com.medicare.mss.vo.BillingDraftFormVO;
import com.medicare.mss.vo.BillingDraftHeaderVO;
import com.medicare.mss.vo.BillingDraftMasterVO;
import com.medicare.mss.vo.PageableVO;

@Service
@Transactional(rollbackFor = ApplicationException.class)
public class EEMBillingDraftService {

	@Autowired
	private EEMBillingDraftDAO billingDraftDao;

	@Autowired
	private CacheService sessionHelper;

	public BillingDraftMasterVO mbrBillingPaymentsSearch(BillingDraftFormVO billingDraftFormVO) {

		String mediCareID = StringUtil.nonNullTrim(billingDraftFormVO.getSearchHicNbr());
		String flag = "";
		if (!mediCareID.isEmpty())
			flag = StringUtil.isHicOrMbi(mediCareID);

		return billDraftSearch(billingDraftFormVO, flag);
	}

	@SuppressWarnings("unchecked")
	private BillingDraftMasterVO billDraftSearch(BillingDraftFormVO billingDraftFormVO, String flag) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		billingDraftFormVO.setCustomerId(customerId);
		billingDraftFormVO.setIsHicOrMbi(flag);

		BillingDraftMasterVO billingDraftMasterVO = initializeBillingDraftMasterVO();
		PageableVO pageableResult = billingDraftDao.getBillingDraftSearchResults(billingDraftFormVO, false);

		List<BillingDraftHeaderDO> billingDraftHeaderDOList = (List<BillingDraftHeaderDO>) pageableResult
				.getContent();
		if (!CollectionUtils.isEmpty(billingDraftHeaderDOList)) {
			List<BillingDraftHeaderVO> billingDraftHeaderVOList = new ArrayList<>();
			CommonUtils.copyList(billingDraftHeaderDOList, billingDraftHeaderVOList, BillingDraftHeaderVO.class);
			billingDraftMasterVO.getBillingDraftHeaderVOList().addAll(billingDraftHeaderVOList);

			List<BillingDraftDetailVO> billingDraftDetailVOList = getBillDraftDetail(
					billingDraftHeaderVOList.get(0));
			billingDraftMasterVO.getBillingDraftDetailVOList().addAll(billingDraftDetailVOList);
			billingDraftMasterVO.setNextPage(pageableResult.isNextPage());
		}
		return billingDraftMasterVO;
	}

	public List<BillingDraftDetailVO> getBillDraftDetail(BillingDraftHeaderVO billingDraftHeaderVO) {

		List<BillingDraftDetailVO> billingDraftDetailVOList = new ArrayList<>();

		List<BillingDraftDetailDO> billingDraftDetailDOList = billingDraftDao.getBillDraftDetail(billingDraftHeaderVO);

		if (!CollectionUtils.isEmpty(billingDraftDetailDOList)) {
			billingDraftDetailDOList.forEach(billingDraftDetailDO -> {
				BillingDraftDetailVO billingDraftDetailVO = new BillingDraftDetailVO();
				BeanUtils.copyProperties(billingDraftDetailDO, billingDraftDetailVO);
				billingDraftDetailVO.setResponseDate(billingDraftDetailVO.getSendDate());
				if ("0001-01-01-00.00.00.000000".equals(billingDraftDetailVO.getSendDate())) {
					billingDraftDetailVO.setSendDate("");
					billingDraftDetailVO.setResponseDate("");
				}
				double draftValue = Double.parseDouble(billingDraftDetailVO.getDraftAmount());

				if (draftValue <= 0) {
					billingDraftDetailVO.setDraftAmount(
							String.valueOf(billingDraftDao.getDraftAmountForInvoice(billingDraftHeaderVO)));
				}
				billingDraftDetailVOList.add(billingDraftDetailVO);
			});
		}
		return billingDraftDetailVOList;
	}

	@SuppressWarnings("unchecked")
	public PageableVO mbrBillingPaymentsSearchNext(BillingDraftFormVO billingDraftFormVO) {
		billingDraftFormVO.setCustomerId(sessionHelper.getUserInfo().getCustomerId());
		PageableVO pageableResult = billingDraftDao.getBillingDraftSearchResults(billingDraftFormVO, true);
		List<BillingDraftHeaderDO> billingDraftHeaderDOList = (List<BillingDraftHeaderDO>) pageableResult.getContent();
		List<BillingDraftHeaderVO> billingDraftHeaderVOList = new ArrayList<>();
		CommonUtils.copyList(billingDraftHeaderDOList, billingDraftHeaderVOList, BillingDraftHeaderVO.class);
		pageableResult.setContent(billingDraftHeaderVOList);

		return pageableResult;
	}
	
	private BillingDraftMasterVO initializeBillingDraftMasterVO() {
		BillingDraftMasterVO masterVO = new BillingDraftMasterVO();
		masterVO.setBillingDraftDetailVOList(new ArrayList<BillingDraftDetailVO>());
		masterVO.setBillingDraftHeaderVOList(new ArrayList<BillingDraftHeaderVO>());
		return masterVO;
	}

}
