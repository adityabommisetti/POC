/**
 * 
 */
package com.medicare.mss.daoImpl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMMbrErrorDAO;
import com.medicare.mss.dao.EEMWfDAO;
import com.medicare.mss.domainobject.EEMFieldErrorDO;
import com.medicare.mss.domainobject.EmMbrErrorDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.util.CommonUtils;

/**
 * @author DU20098149
 *
 */
@Repository
public class EEMMbrErrorDAOImpl implements EEMMbrErrorDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private EEMWfDAO workFlowDAO;
	@Override
	public List<EEMFieldErrorDO> getFormFieldErrors(String formName, String customerId) throws ApplicationException {

		try {
			String query = new StringBuilder("SELECT FE.ERROR_CD, EM.ERROR_TYPE, EM.ERROR_MESSAGE, ")
					.append("FE.FORM_FIELD, FE.REQUIRED_IND, FE.EDIT_RULE_ID, FE.FIELD_NBR, ")
					.append("FE.CUSTOMER_ID, ER.EDIT_VALID_VALUE, ER.EXCEPTION_VALUE, ")
					.append("ER.EDIT_FROM_VALID_VALUE, ER.EDIT_TO_VALID_VALUE ").append(" FROM EM_FIELD_EDITS FE ")
					.append(" JOIN EM_EDITRULES ER ").append(" ON ER.EDIT_RULE_ID = FE.EDIT_RULE_ID ")
					.append(" JOIN EM_ERROR_MESSAGE EM ").append(" ON EM.ERROR_CD = FE.ERROR_CD ")
					.append(" WHERE FE.CUSTOMER_ID = ? ").append(" AND FE.FORM_NAME = ? ").append(" UNION ALL")
					.append(" SELECT FE.ERROR_CD, EM.ERROR_TYPE, EM.ERROR_MESSAGE,")
					.append(" FE.FORM_FIELD, FE.REQUIRED_IND, FE.EDIT_RULE_ID, FE.FIELD_NBR,")
					.append(" FE.CUSTOMER_ID, ER.EDIT_VALID_VALUE, ER.EXCEPTION_VALUE,")
					.append(" ER.EDIT_FROM_VALID_VALUE, ER.EDIT_TO_VALID_VALUE").append(" FROM EM_FIELD_EDITS FE")
					.append(" JOIN EM_EDITRULES ER").append(" ON ER.EDIT_RULE_ID = FE.EDIT_RULE_ID")
					.append(" JOIN EM_ERROR_MESSAGE EM").append(" ON EM.ERROR_CD = FE.ERROR_CD")
					.append(" WHERE FE.CUSTOMER_ID = '9999999'").append(" AND FE.FORM_NAME = ?")
					.append(" AND NOT EXISTS (SELECT 1 FROM EM_FIELD_EDITS FE2").append(" WHERE FE2.CUSTOMER_ID = ?")
					.append(" AND FE2.FIELD_NBR = FE.FIELD_NBR )").toString();

			return jdbcTemplate.query(query, new DomainPropertyRowMapper<EEMFieldErrorDO>(EEMFieldErrorDO.class), customerId, formName, formName, customerId);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error Ocuured while fetching Form Field Errors");
		}
	}

	@Override
	public List<EmMbrErrorDO> getMbrErrors(String customerId, String memberId) throws ApplicationException {

		try {
			String query = CommonUtils.buildQuery("SELECT E.CUSTOMER_ID, E.MEMBER_ID, E.ERROR_SEQ_NBR,",
					" E.ERROR_CD, M.ERROR_MESSAGE, E.FIELD_NBR, E.ERROR_DATA, E.ERROR_STATUS, E.RFI_IND,",
					" E.LAST_UPDT_TIME, E.LAST_UPDT_USERID  FROM EM_MBR_ERROR E",
					" LEFT OUTER JOIN EM_ERROR_MESSAGE M ON M.ERROR_CD = E.ERROR_CD",
					" WHERE E.CUSTOMER_ID = ? AND E.MEMBER_ID = ? AND E.ERROR_STATUS='OPEN' ORDER BY E.ERROR_SEQ_NBR DESC");

			return jdbcTemplate.query(query, new DomainPropertyRowMapper<EmMbrErrorDO>(EmMbrErrorDO.class), customerId,
					memberId);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp);
		}
	}

	@Override
	public int updateErrorDetails(EmMbrErrorDO eemMbrErrorDO, String requestScrn) throws ApplicationException {
		int rows = 0;
		String query = CommonUtils.buildQuery("UPDATE EM_MBR_ERROR SET ERROR_DATA=?, ERROR_STATUS=?,",
				"RFI_IND=?, LAST_UPDT_TIME=?, LAST_UPDT_USERID=?",
				"WHERE CUSTOMER_ID=? AND MEMBER_ID=? AND FIELD_NBR=?",
				"AND ERROR_CD=? AND ERROR_STATUS != 'CLOSED' AND ERROR_DATA=?");
		try {
			rows = jdbcTemplate.update(query, StringUtils.trimToEmpty(eemMbrErrorDO.getErrorData()),
					StringUtils.trimToEmpty(eemMbrErrorDO.getErrorStatus()),
					StringUtils.trimToEmpty(eemMbrErrorDO.getRfiInd()),
					StringUtils.trimToEmpty(eemMbrErrorDO.getLastUpdtTime()),
					StringUtils.trimToEmpty(eemMbrErrorDO.getLastUpdtUserId()),
					StringUtils.trimToEmpty(eemMbrErrorDO.getCustomerId()),
					StringUtils.trimToEmpty(eemMbrErrorDO.getMemberId()),
					StringUtils.trimToEmpty(eemMbrErrorDO.getFieldNbr()),
					StringUtils.trimToEmpty(eemMbrErrorDO.getErrorCd()),
					StringUtils.trimToEmpty(eemMbrErrorDO.getErrorData()));

			/* Workflow change starts */

			if (rows != 0 && null != eemMbrErrorDO.getErrorStatus()
					&& eemMbrErrorDO.getErrorStatus().equalsIgnoreCase(EEMConstants.ERROR_STATUS_CLOSED)) {
				workFlowDAO.updateActivityWhileUpdatingError(eemMbrErrorDO.getCustomerId(), eemMbrErrorDO.getErrorCd(),
						eemMbrErrorDO.getMemberId(), eemMbrErrorDO.getErrorMsg(), eemMbrErrorDO.getLastUpdtUserId());
			}
			return rows;
			/* Workflow change ends */

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp);
		}
	}

	@Override
	public int insertErrorDetails(EmMbrErrorDO eemMbrErrorDO, String applDate) throws ApplicationException {
		int rows = 0;
		String query = CommonUtils.buildQuery("INSERT INTO EM_MBR_ERROR (CUSTOMER_ID, MEMBER_ID,",
				"ERROR_SEQ_NBR, ERROR_CD, FIELD_NBR, ERROR_DATA, ERROR_STATUS,",
				"RFI_IND, LAST_UPDT_TIME, LAST_UPDT_USERID, CREATE_TIME)",
				"VALUES (?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)");

		try {
			rows = jdbcTemplate.update(query, StringUtils.trimToEmpty(eemMbrErrorDO.getCustomerId()),
					StringUtils.trimToEmpty(eemMbrErrorDO.getMemberId()), getErrorSeqNo(eemMbrErrorDO),
					StringUtils.trimToEmpty(eemMbrErrorDO.getErrorCd()),
					StringUtils.trimToEmpty(eemMbrErrorDO.getFieldNbr()),
					StringUtils.trimToEmpty(eemMbrErrorDO.getErrorData()),
					StringUtils.trimToEmpty(eemMbrErrorDO.getErrorStatus()),
					StringUtils.trimToEmpty(eemMbrErrorDO.getRfiInd()),
					StringUtils.trimToEmpty(eemMbrErrorDO.getLastUpdtTime()),
					StringUtils.trimToEmpty(eemMbrErrorDO.getLastUpdtUserId()));

			// Workflow change starts
			if (rows != 0) {
				workFlowDAO.insertActivityWhileInsertError(eemMbrErrorDO.getCustomerId(),
						eemMbrErrorDO.getErrorCd(), eemMbrErrorDO.getMemberId(), eemMbrErrorDO.getErrorMsg(),
						eemMbrErrorDO.getLastUpdtUserId());
			}
			// Workflow change ends
			return rows;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp);
		}
	}

	private String getErrorSeqNo(EmMbrErrorDO eemMbrErrorDO) {

		String query = CommonUtils.buildQuery("SELECT MAX(ERROR_SEQ_NBR) FROM EM_MBR_ERROR",
				"WHERE CUSTOMER_ID = ? AND MEMBER_ID = ?");
		String seqNo = jdbcTemplate.queryForObject(query, String.class, eemMbrErrorDO.getCustomerId(),
				eemMbrErrorDO.getMemberId());

		if (!StringUtils.trimToEmpty(seqNo).equals(EEMConstants.BLANK)) {
			seqNo = String.valueOf(Integer.parseInt(seqNo) + 1);
		} else {
			seqNo = "1";
		}
		return seqNo;
	}
	
}
