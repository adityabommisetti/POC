/**
 * 
 */
package com.medicare.mss.vo;

import java.util.List;

import lombok.Data;

/**
 * @author SUSDASH
 *
 */

@Data
public class EEMOriginalApplMasterVO {

	private EEMApplicationVO applVO;
	private EEMApplAddressVO applAddress;	
	private EEMApplPlanVO applPlanVO;
	private EEMApplProductVO grpProdVO;	
	private EEMApplEligibilityVO applEligiVO;
	private EEMApplOtherCovVO applOtherCovVO;
	private EEMApplOtherPlanVO applOtherPlanVO;	
	private EEMApplAgentVO applAgentVO;
	private List<EEMApplAttestationVO> applAttestationList; 
	private List<EEMApplCommentsVO> applCommentsList;
	private EEMApplLisVO applLisVO;
	
	
}
