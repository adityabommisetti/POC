package com.medicare.mss.util;

import java.io.Serializable;

import lombok.Data;

@Data
public class LabelValuePair implements Serializable {

	private static final long serialVersionUID = -3007858655361034346L;

	public LabelValuePair(){
		
	}
	public LabelValuePair(String value, String label) {
		super();
		this.label = label;
		this.value = value;
	}

	private String label;

	private String value;

}