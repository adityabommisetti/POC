package com.medicare.mss.rowmappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.domainobject.EEMApplProductDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.util.StringUtil;

public class ApplProductRowMapper implements RowMapper<EEMApplProductDO> {
	
	private EEMCodeCache codeCache;

	public ApplProductRowMapper(EEMCodeCache codeCache) {
		this.codeCache = codeCache;
	}


	@Override
	public EEMApplProductDO mapRow(ResultSet rs, int rowNum) throws SQLException {
		EEMApplProductDO productVO = new EEMApplProductDO();
		productVO.setGroupId(StringUtil.nonNullTrim(rs.getString("GRP_ID")));
		productVO.setGroupName(StringUtil.nonNullTrim(rs.getString("GROUP_NAME")));
		productVO.setProductId(StringUtil.nonNullTrim(rs.getString("PRODUCT_ID")));
		productVO.setProductName(StringUtil.nonNullTrim(rs.getString("PRODUCT_NAME")));
		productVO.setPlanId(StringUtil.nonNullTrim(rs.getString("PLAN_ID")));
		productVO.setPbpId(StringUtil.nonNullTrim(rs.getString("PBP_ID")));
		productVO.setSegmentId(StringUtil.nonNullTrim(rs.getString("PBP_SEGMENT_ID")));
		if (StringUtil.nonNullTrim(rs.getString("ZIP_CD5")).indexOf("X") == -1) {
			productVO.setZipCode5(StringUtil.nonNullTrim(rs.getString("ZIP_CD5")));
		}
		if (StringUtil.nonNullTrim(rs.getString("ZIP_CD4")).indexOf("X") == -1) {
			productVO.setZipCode4(StringUtil.nonNullTrim(rs.getString("ZIP_CD4")));	
		}
		productVO.setAreaId(StringUtil.nonNullTrim(rs.getString("SRVC_AREA_ID")));
		productVO.setArea(StringUtil.nonNullTrim(rs.getString("SRVC_AREA_NAME")));
		productVO.setStateCd(StringUtil.nonNullTrim(rs.getString("SSA_ST")));
		productVO.setCountyCd(StringUtil.nonNullTrim(rs.getString("SSA_CNTY")));
		productVO.setEghpInd(StringUtil.nonNullTrim(rs.getString("EGHP_IND")));
		productVO.setPlanDesignation(StringUtil.nonNullTrim(rs.getString("PLAN_DESIGNATION")));

		try {
			productVO.setState(StringUtil.nonNullTrim(codeCache.getStateAbbr(productVO.getStateCd())));
			productVO.setCounty(StringUtil.nonNullTrim(codeCache.getCountyNameByCd(productVO.getStateCd(),productVO.getCountyCd())));
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		productVO.setPrtCPremiumAmt(StringUtil.nonNullTrim(rs.getString("PRTC_PREMIUM_AMT")));
		productVO.setPrtDPremiumAmt(StringUtil.nonNullTrim(rs.getString("PRTD_PREMIUM_AMT")));
		productVO.setSupplPremiumAmt(StringUtil.nonNullTrim(rs.getString("SUPPL_PREMIUM_AMT")));
		productVO.setPremiumReductionAmt(StringUtil.nonNullTrim(rs.getString("PREMIUM_REDUCTION_AMT")));
		productVO.setDsrRebateAmt(StringUtil.nonNullTrim(rs.getString("DSBREBATE_AMT")));
		productVO.setSnpInd(StringUtil.nonNullTrim(rs.getString("SNP_IND")));
		productVO.setLineOfBusiness(StringUtil.nonNullTrim(rs.getString("LINE_OF_BIZ")));//IFOX-00389053 	
		return productVO;
	}

}
