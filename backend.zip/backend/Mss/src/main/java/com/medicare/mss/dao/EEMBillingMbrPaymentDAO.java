package com.medicare.mss.dao;

import java.util.List;
import java.util.Map;

import com.medicare.mss.domainobject.BillingMbrPaymentHeaderDO;
import com.medicare.mss.domainobject.BillingMbrPymntDtlInvcDO;
import com.medicare.mss.vo.BillingMbrPaymentHeaderVO;
import com.medicare.mss.vo.BillingMbrPaymentsSearchVO;
import com.medicare.mss.vo.BillingMbrPaymentsVO;
import com.medicare.mss.vo.PageableVO;

public interface EEMBillingMbrPaymentDAO {

	PageableVO getBillMbrPaymentsSearchDetail(BillingMbrPaymentsSearchVO billMembPaymentsSearchVO, boolean isPagination);

	List<BillingMbrPymntDtlInvcDO> getBillPaymentsDetailInvoice(BillingMbrPaymentsVO eemBillingMbrPaymentsVO);

	BillingMbrPaymentHeaderDO getBillPaymentHeader(String customerId, String paySourceType, String batchDate,
			int batchSeqNbr);

	int updateBillPaymentDetails(BillingMbrPaymentsVO mbrPaymentsVO, String ts, String userId);

	Map<String, String> getPaymentDetail(BillingMbrPaymentHeaderVO payHdrDtl);

	int updateHeaderTotalAmount(String userId, String ts, String totalPaymentAmount, String itemNbrCount,
			String batchBalanceInd, BillingMbrPaymentHeaderVO payHdrDtl);

}
