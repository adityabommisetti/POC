package com.medicare.mss.vo;

import java.io.Serializable;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class CPMDateVO implements Serializable {

	private static final long serialVersionUID = -4413654334145363299L;

	@ColumnMapper(columnName = "PYMT_EFF_MONTH", propertyName = "pymtEffMonth")
	private String pymtEffMonth;
	@ColumnMapper(columnName = "CAL_START_DATE", propertyName = "calStartDate")
	private String calStartDate;
	@ColumnMapper(columnName = "CAL_END_DATE", propertyName = "calEndDate")
	private String calEndDate;

}