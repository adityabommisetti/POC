package com.medicare.mss.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.service.EEMMbrAgentServices;
import com.medicare.mss.vo.EmMbrAgentVO;
import com.medicare.mss.vo.EmMbrErrorVO;

@RestController
@RequestMapping("/member")
public class EEMMbrAgentController {

	@Autowired
	private EEMMbrAgentServices mbrAgentServices;

	@Autowired
	private CacheService sessionHelper;

	@GetMapping(ReqMappingConstants.MBR_AGENT_LIST)
	public ResponseEntity<JSONResponse> getMemberAGENTList(@PathVariable(name = "mbrId") String memberId,
			@PathVariable(name = "showAll") String showAll) {

		List<EmMbrAgentVO> mbrAgentInfoList = mbrAgentServices.getMbrAgents(memberId, showAll);
		return sendResponse(mbrAgentInfoList);
	}

	@PostMapping(ReqMappingConstants.MBR_AGENT_INFO_UPDATE)
	public ResponseEntity<JSONResponse> mbrAgentUpdate(@RequestBody EmMbrAgentVO insertVO) {

		Map<String, Object> resultMap = new HashMap<>();
		List<EmMbrAgentVO> mbrAgentInfoList = mbrAgentServices.mbrAgentInfoUpdate(insertVO);
		List<EmMbrErrorVO> errorList = sessionHelper.getEEMContext().getMbrMasterVO().getMbrErrorList();

		resultMap.put("agent", mbrAgentInfoList);
		resultMap.put("error", errorList);

		return sendResponse(resultMap);
	}

	@PostMapping(ReqMappingConstants.MBR_AGENT_INFO_DELETE)
	public ResponseEntity<JSONResponse> mbrAgentInfoDelete(@RequestBody EmMbrAgentVO delVO) {

		List<EmMbrAgentVO> mbrAgentInfoList = mbrAgentServices.mbrAgentInfoDelete(delVO);
		return sendResponse(mbrAgentInfoList);

	}

	private ResponseEntity<JSONResponse> sendResponse(Object object) {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;
		jsonResponse.setData(object);
		if (null == object) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
			jsonResponse.setMessage(EEMConstants.BLANK);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}

}
