/**
 * 
 */
package com.medicare.mss.vo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

/**
 * @author SUSDASH
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EEMApplCancelRequestVO {

	private int applId;
	private String ltrReasonCd;
	private String date;
	private String planDesg;
	private String userId;

	private List<EEMApplCommentsVO> applCommentsList;

}
