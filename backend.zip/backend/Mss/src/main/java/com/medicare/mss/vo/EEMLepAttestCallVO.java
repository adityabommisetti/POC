package com.medicare.mss.vo;

import com.medicare.mss.util.DateFormatter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class EEMLepAttestCallVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7813259489832784165L;
	private Integer index;
	private String attempt;
	private String date;
	private String status;
	private String userId;
	private String applId;
	
	public String getDateFrmt() {
		return DateFormatter.reFormat(date, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setDateFrmt(String date) {
		this.date = DateFormatter.reFormat(date, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}
}