/**
 * 
 */
package com.medicare.mss.dao;

import java.util.List;

import com.medicare.mss.domainobject.EEMMbrDsInfoDO;

/**
 * @author Wipro Ltd.
 *
 */
public interface EEMMbrDsInfoDAO extends EEMMbrBaseDAO {

	List<EEMMbrDsInfoDO> getMbrDsInfos(String custId, String mbrId, String showAll);

}
