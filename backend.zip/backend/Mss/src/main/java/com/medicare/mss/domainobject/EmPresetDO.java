package com.medicare.mss.domainobject;

import java.io.Serializable;

import lombok.Data;

@Data
public class EmPresetDO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2811955348077114012L;
	private String indFlag;
	private String longDescription;
	private String maxId;
	private String preSetNote1;

}
