package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EmCorrMbrDO implements Cloneable{
	

	
	@ColumnMapper(columnName = "DMS_ID", propertyName = "dmsId")
	private String dmsId;
	
	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;//custId
	
	@ColumnMapper(columnName = "PDF_ARCHIVAL", propertyName = "pdfArchival")
	private String pdfArchival;
	
	@ColumnMapper(columnName = "FILE_BATCH_ID", propertyName = "filebatchid")
	private String filebatchid;
	
	@ColumnMapper(columnName = "RECORD_TYPE", propertyName = "recordType")
	private String recordType;
	
	@ColumnMapper(columnName = "PRIMARY_ID", propertyName = "primaryId")
	private String primaryId;//mbrId
	
	@ColumnMapper(columnName = "LETTER_NAME", propertyName = "letterName")
	private String letterName;
	
	@ColumnMapper(columnName = "DESCRIPTION", propertyName = "description")
	private String description;
	
	@ColumnMapper(columnName = "REQUEST_DATE", propertyName = "requestDate")
	private String requestDate;
	
	@ColumnMapper(columnName = "ORIG_MAIL_DATE", propertyName = "origMailDate")
	private String origMailDate;
	
	@ColumnMapper(columnName = "LAST_MAIL_DATE", propertyName = "lastMailDate")
	private String lastMailDate;
	
	@ColumnMapper(columnName = "DELETE_IND", propertyName = "deleteInd")
	private String deleteInd;
	
	@ColumnMapper(columnName = "RECORD_STATUS", propertyName = "recordStatus")
	private String recordStatus;

	
	@ColumnMapper(columnName = "SUPPLEMENTAL_ID", propertyName = "supplementalId")
	private String supplementalId;
	
	@ColumnMapper(columnName = "CREATE_TIME", propertyName = "createTime")
	private String createTime;
	
	@ColumnMapper(columnName = "CREATE_USERID", propertyName = "createUserId")
	private String createUserId;
	
	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;
	
	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserId")
	private String lastUpdtUserId;
	
	@ColumnMapper(columnName = "PRINT_DATE", propertyName = "printDate")
	private String printDate;
	
	@ColumnMapper(columnName = "RESPONSE_DUE_DATE", propertyName = "responseDueDate")
	private String responseDueDate;
	
	@ColumnMapper(columnName = "REPRINT_DATE", propertyName = "reprintDate")
	private String reprintDate;
	
	@ColumnMapper(columnName = "RESPONSE_DATE", propertyName = "responseDate")
	private String responseDate;
	
	@ColumnMapper(columnName = "LETTER_UPLOADED_TIME", propertyName = "letterUploadedTime")
	private String letterUploadedTime;
	
	private String source;
	
	private String letterAvailabilityInDB;
	
}
