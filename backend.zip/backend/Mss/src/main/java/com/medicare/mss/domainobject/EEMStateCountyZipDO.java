package com.medicare.mss.domainobject;

import lombok.Data;

@Data
public class EEMStateCountyZipDO {
	
	private String countyCd;
	private String countyName;
	private String stateAbbr;
	private String stateCd;
	private String zip4;
	private String zip5;
	
	
	
}
