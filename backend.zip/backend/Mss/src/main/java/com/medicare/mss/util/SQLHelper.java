package com.medicare.mss.util;

import org.apache.commons.lang3.StringUtils;

final public class SQLHelper {


	private SQLHelper() {
	}

	public static int ensureInteger(String value) {
		value = StringUtils.trimToNull(value);
		try {
			if (value != null)
				return Integer.parseInt(value, 10);
		} catch (Exception exp) {
		}
		return 0;
	}

	public static double ensureDouble(String value) {
		value = StringUtils.trimToNull(value);
		if (value != null)
			return Double.parseDouble(value);
		return 0;
	}
}
