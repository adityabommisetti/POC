package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMWFActivityDO {

	@ColumnMapper(columnName = "ACTIVITY_CREATION_TIME", propertyName = "activityCreationTime")
	private String activityCreationTime;

	@ColumnMapper(columnName = "ACTIVITY_DESC", propertyName = "activityDesc")
	private String activityDesc;

	@ColumnMapper(columnName = "ACTIVITY_SCREEN", propertyName = "activityScreen")
	private String activityScreen;

	@ColumnMapper(columnName = "ACTIVITY_STATUS", propertyName = "activityStatus")
	private String activityStatus;

	@ColumnMapper(columnName = "CASE_ID", propertyName = "caseId")
	private int caseId;

	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;

	@ColumnMapper(columnName = "ERROR_ID", propertyName = "errorId")
	private String errorId;

	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;

	@ColumnMapper(columnName = "LAST_UPDT_USER", propertyName = "lastUpdtUserId")
	private String lastUpdtUserId;

	@ColumnMapper(columnName = "QUEUE_CD", propertyName = "queueCode")
	private String queueCode;

	@ColumnMapper(columnName = "SUB_QUEUE_CD", propertyName = "subQueueCode")
	private String subQueueCode;

}
