package com.medicare.mss.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode(callSuper = false)
public class EmMbrAgentVO extends BaseVO implements EMDatedSegmentVO, Cloneable, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6783479991085956874L;

	private String memberId;

	private String agentId;
	private String agentType;
	private String agentTypeDesc;
	private String agentTIN;
	private String agentName;
	private String agentPhone;
	private String agentEmail;

	private String agencyId;
	private String agencyType;
	private String agencyTypeDesc;
	private String agencyTIN;
	private String agencyName;
	private String agencyPhone;
	private String agencyEmail;

	private String overrideInd;
	private String planId;
	private String effStartDate;
	private String effEndDate;
	private String selAgencyId;
	/** Triple S BasePlus Migration START **/
	// Begin: Added for IFOX-IFOX-00389914
	private String disEnrollApprvStartDateMinusOne;
	private String currentDateTime;

	/** Triple S BasePlus Migration END **/

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	public String getCreateTimeFrmt() {
		return DateFormatter.reFormat(createTime, DateFormatter.DB2_TIMESTAMP, DateFormatter.MM_DD_YYYY_HH_MM_SS);
	}

	public String getEffEndDateFrmt() {
		return DateFormatter.reFormat(effEndDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setEffEndDateFrmt(String effEndDate) {
		this.effEndDate = DateFormatter.reFormat(effEndDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getEffStartDateFrmt() {
		return DateFormatter.reFormat(effStartDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setEffStartDateFrmt(String effStartDate) {
		this.effStartDate = DateFormatter.reFormat(effStartDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getLastUpdtTimeFrmt() {
		return DateFormatter.reFormat(lastUpdtTime, DateFormatter.DB2_TIMESTAMP, DateFormatter.MM_DD_YYYY_HH_MM_SS);
	}

	@Override
	public boolean isEndDateChange(Object obj) {
		// return true;// earlier false. True allows the user to terminate Agent by end
		// date. No new record is created with end date 99/99/9999.
		// The above code is commented as it is not allowing to split records. updated
		// as per "Defect #9 Hometown"
		EmMbrAgentVO chkVO = (EmMbrAgentVO) obj;
		return !(chkVO.getEffEndDate().equalsIgnoreCase(this.effEndDate));
	}

	@Override
	public boolean isForSamePeriod(Object obj) {

		EmMbrAgentVO chkVO = (EmMbrAgentVO) obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate))
			if (chkVO.getEffEndDate().equals(this.effEndDate))
				if (chkVO.getPlanId().equals(this.planId))
					if (chkVO.getMemberId().equals(this.memberId))
						if (chkVO.getCustomerId().equals(this.customerId))
							if (chkVO.getOverrideInd().equals(this.overrideInd))
								return true;
		return false;
	}

	public boolean isSamePlan(Object obj) {

		EmMbrAgentVO chkVO = (EmMbrAgentVO) obj;
		if (chkVO.getPlanId().equals(this.planId))
			if (chkVO.getMemberId().equals(this.memberId))
				if (chkVO.getCustomerId().equals(this.customerId))
					return true;
		return false;
	}

	public int compareTo(Object anotherEmMbrAgentVO) throws ClassCastException {
		if (!(anotherEmMbrAgentVO instanceof EmMbrAgentVO))
			throw new ClassCastException("A EmMbrAgentVO object expected.");
		String firstAgencyID = this.agencyId;
		String secondAgencyID = ((EmMbrAgentVO) anotherEmMbrAgentVO).getAgencyId();
		return secondAgencyID.compareTo(firstAgencyID);
	}

	public boolean isSameAgentPlan(Object obj) {

		EmMbrAgentVO chkVO = (EmMbrAgentVO) obj;
		if (chkVO.getPlanId().equals(this.planId))
			if (chkVO.getAgentId().equals(this.agentId))// Can have different agents for same plan!
				if (chkVO.getMemberId().equals(this.memberId))
					if (chkVO.getCustomerId().equals(this.customerId))
						return true;
		return false;
	}

	@Override
	public boolean isSame(Object obj) {

		EmMbrAgentVO chkVO = (EmMbrAgentVO) obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate))
			if (chkVO.getEffEndDate().equals(this.effEndDate))
				if (chkVO.getAgentId().equals(this.agentId))
					if (chkVO.getAgencyId().equals(this.agencyId))
						if (chkVO.getPlanId().equals(this.planId))
							if (chkVO.getMemberId().equals(this.memberId))
								if (chkVO.getCustomerId().equals(this.customerId))
									if (chkVO.getOverrideInd().equals(this.overrideInd))
										if (chkVO.getCreateTime().equals(this.createTime))
											if (chkVO.getCreateUserId().equals(this.createUserId))
												if (chkVO.getLastUpdtTime().equals(this.lastUpdtTime))
													if (chkVO.getLastUpdtUserId().equals(this.lastUpdtUserId))
														return true;
		return false;
	}

	@Override
	public String getType() {
		return planId;
	}

}
