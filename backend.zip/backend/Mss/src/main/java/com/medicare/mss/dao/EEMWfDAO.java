package com.medicare.mss.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.medicare.mss.domainobject.EEMAtRiskDO;
import com.medicare.mss.domainobject.EEMWFActivityDO;
import com.medicare.mss.domainobject.EEMWFCaseDO;
import com.medicare.mss.domainobject.EEMWFCommentDO;
import com.medicare.mss.domainobject.EEMWFSupervisorUserDO;
import com.medicare.mss.domainobject.EEMWFUserDO;
import com.medicare.mss.domainobject.EEMWfAssignOrTransDO;
import com.medicare.mss.domainobject.EMWFCaseQueueDO;
import com.medicare.mss.util.LabelValueKeyPair;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.vo.EEMAtRiskVO;
import com.medicare.mss.vo.EEMWFCaseVO;
import com.medicare.mss.vo.EEMWFCommentVO;
import com.medicare.mss.vo.EEMWFSupervisorUserVO;
import com.medicare.mss.vo.EEMWfSearchVO;
import com.medicare.mss.vo.EMWFCaseQueueVO;
import com.medicare.mss.vo.EMWFQueAsgnGrpVO;
import com.medicare.mss.vo.PageableVO;

public interface EEMWfDAO {

	PageableVO searchWorkflow(EEMWfSearchVO searchVO, String customerId, boolean isPagination);

	List<EEMWFCaseDO> getTotalUnAssignedCases(String custId);

	List<EEMWFActivityDO> fetchUserActivityList(Integer caseId, String customerId);

	Map<String, Integer> getCountBasedOnStatus(String custId, String userId);

	int getCountOfAssignedCases(String custId);

	int getCountOfUnAssignedCases(String custId);

	int updateCaseState(EEMWfAssignOrTransDO caseStatusUpdtDO);

	void updateActivityWhileUpdatingError(String customerId, String errorCd, String applOrMbrId, String errorMsg,
			String userId);

	void insertActivityWhileInsertError(String customerId, String errorCd, String applOrMbrId, String errorMsg,
			String userId);

	List<EEMWFCommentDO> fetchWFCommentList(EEMWFCaseVO emwfCaseVO);

	List<LabelValueKeyPair> getWFAssignedToUsers(String userId, String customerId);

	String getUserLevel(String userId, String customerId);

	int getNextCommentSeqNumber(String custId, String primaryId, String source);

	boolean addWFComment(EEMWFCommentVO wfCommentVo);

	List<EMWFCaseQueueDO> fetchWFCaseQueueList(String customerId);

	void updateWFCaseQueue(EMWFCaseQueueVO eemwfCaseQueueVO);

	List<String> fetchQueueCdsBasedOnPriority(String customerId, String toUserId);

	int getWFUserMaxAssignableWorkLimit(String customerId, String paramCode);

	int updateWFUserMaxAssignableWorkLimit(String customerId, String userId, String paramCode,
			int maxAssignableWorkLimit);

	List<EEMAtRiskDO> getAtRiskSummary(String customerId);

	List<EEMAtRiskDO> getAtRiskDetails(EEMAtRiskVO eemAtRiskVO);

	int updateUserStatus(EEMWFSupervisorUserVO emWFSupervisorUserVO, String managerId, String customerId);

	int getCountOfAssignedCases(String custId, String userId, String status);

	List<Map<String, Object>> getNextMbrCommentSeqNumbers(String custId, List<String> mbrIdList);

	List<Map<String, Object>> getNextApplCommentSeqNumbers(String custId, List<String> applIdList);

	void addWFMbrCommentList(List<EEMWFCommentVO> eemwfMemberCommentList);

	void addWFAppCommentList(List<EEMWFCommentVO> eemwfApplicationCommentList);

	Map<String, List<String>> getDetailedAssignedOrUnAssignedCounts(String custId, String userId,
			boolean isAssignedCases);

	List<EEMWFSupervisorUserDO> getSupervisorUsers(String customerId, String managerId, String userId);

	Map<String, List<String>> getDashletData(String custId, String userId);

	void updatePriority(EMWFQueAsgnGrpVO eMWFQueAsgnVO, List<EMWFQueAsgnGrpVO> updateList);

	void insertPriority(EMWFQueAsgnGrpVO eMWFQueAsgnVO, List<EMWFQueAsgnGrpVO> insertList);

	Map<String, List<LabelValuePair>> getNewUserList(String customerId);

	Map<String, List<LabelValuePair>> getWfUsersList(String customerId);

	int addNewUser(String userLevel, String userId, String managerId, String loggedInUserId, String customerId);

	List<EEMWFUserDO> searchUser(String customerId, String name, String managerId);

	int updateUser(String userLevel, String userId, String managerId, String loggedInUserId, String customerId);

	String getSupervisorId(String customerId, String currentUserId);

	String getUserNameByUserId(String userId);

	Map<String, String> getUserNamesByUserIds(List<String> userIds);

	List<LabelValuePair> getWFCaseDesc(String custId);

	Map<String, String> getCaseDescMap(String customerId);

	List<EEMWFCaseDO> getCasesForQueueCds(Set<String> queueCds, String custId, String userId);

	List<LabelValuePair> getQueueList(String customerId);

	int assignOrTransferCase(EEMWfAssignOrTransDO assignOrTransDO);

	List<EEMWFCaseDO> getCasesByUserId(String userId, String customerId);

	boolean createCase(EEMWFCaseDO caseDO);

	boolean createActivities(String customerId, String userId, int caseId, List<String> errorCds,
			List<String> errorMsgs);

	int getNextCaseId(String customerId);

	Map<String, String> checkAndGetQueueChars(String customerId, int applId, String queueCd);

	boolean isCaseExists(String customerId, int applId);

	boolean isActivityExists(String customerId, int caseId, String errorCd);

	boolean checkUserQueueAccess(String userId, String customerId, String applicationTracking);

	boolean addWFApplComment(EEMWFCommentVO wfCommentVo);

	Map<String, Integer> getApplCommentIndicators(String custId, List<String> applIdList);

	Map<String, Integer> getMbrCommentIndicators(String custId, List<String> mbrIdList);

	List<LabelValuePair> fetchAssignedWfUsers(String customerId, String loggedInUsrId, int userLevel);

	Map<String, String> fetchManualPopupQueues(String custId, List<String> userIdList);
	
	boolean deleteManualPopupQueues(String custId, String userId, String queueName, String deleteAll,
			List<String> userIdList, String loggedInUserId);
	
	int overrideCases(List<EEMWFCaseDO> casesToBeDeleted, String userId);
	
	int insertClosedCases(List<EEMWFCaseDO> casesToBeDeleted, String userId);

	Map<String, Integer> checkAccess(String userId, String custId);
	
	Map<Integer, List<String>> fetchOldQueAssnFor(String customerId, String userId);
}
