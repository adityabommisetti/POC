package com.medicare.mss.vo;

import lombok.Data;

@Data
public class EEMMedOfficeVO {
	
	private String  alternateOfficeCd;

}
