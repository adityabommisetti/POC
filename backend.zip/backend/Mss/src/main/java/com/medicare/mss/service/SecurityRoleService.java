package com.medicare.mss.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.mss.dao.SecurityRoleDAO;
import com.medicare.mss.domainobject.SecurityRoleDO;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.security.vo.SecuserDetails;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.SecurityRoleVO;

@Service
public class SecurityRoleService {

	@Autowired
	private SecurityRoleDAO securityRoleDAO;

	@Autowired
	private CacheService sessionHelper;

	public Map<String, Object> getSecurityCache() {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();

		List<SecurityRoleDO> secRolesDOList = securityRoleDAO.getUserDetails(customerId, userId);

		List<LabelValuePair> roleList = new ArrayList<>();
		List<LabelValuePair> userList = new ArrayList<>();

		Map<String, String> roleMap = new HashMap<>();

		for (SecurityRoleDO role : secRolesDOList) {
			roleMap.put(role.getGroupId(), role.getGroupName());
			userList.add(new LabelValuePair(role.getGroupId(), role.getUserId()));
		}

		Set<String> keySet = roleMap.keySet();

		for (String key : keySet) {
			roleList.add(new LabelValuePair(key, roleMap.get(key)));
		}

		Map<String, Object> data = new HashMap<>();
		data.put("roleList", roleList);
		data.put("userList", userList);

		return data;

	}

	public int getUpdateRole(Map<String, String> request) {
		String userId = StringUtil.nonNullTrim(request.get("userId"));
		String roleId = StringUtil.nonNullTrim(request.get("groupId"));
		return securityRoleDAO.getUpdateRole(userId, roleId);

	}

	public Map<String, List<SecurityRoleVO>> getRoleServices(String groupId) {

		SecuserDetails userInfo = sessionHelper.getUserInfo();
		String customerNbr = userInfo.getCustNbr();
		List<SecurityRoleDO> availableServicesDOs = securityRoleDAO.getRoleServices(groupId, customerNbr);
		List<SecurityRoleDO> enabledServicesDOs = securityRoleDAO.getEnabledServicesList(groupId, customerNbr);

		List<SecurityRoleVO> availableServices = new ArrayList<>();
		List<SecurityRoleVO> enabledServices = new ArrayList<>();

		CommonUtils.copyList(availableServicesDOs, availableServices, SecurityRoleVO.class);
		CommonUtils.copyList(enabledServicesDOs, enabledServices, SecurityRoleVO.class);

		Map<String, List<SecurityRoleVO>> services = new HashMap<>();

		services.put("enabledServices", enabledServices);
		services.put("availableServices", availableServices);
		return services;
	}

	@SuppressWarnings("unchecked")
	public boolean addService(Map<String, Object> request) {

		String customerNbr = sessionHelper.getUserInfo().getCustNbr();
		List<String> serviceId = (List<String>) request.get("serviceId");
		String userId = (String) request.get("userId");

		return securityRoleDAO.addService(serviceId, customerNbr, userId);

	}

	public boolean removeService(Map<String, Object> request) {
		@SuppressWarnings("unchecked")
		List<String> serviceId = (List<String>) request.get("serviceId");
		String userId = (String) request.get("userId");
		String customerNbr = sessionHelper.getUserInfo().getCustNbr();

		return securityRoleDAO.removeService(serviceId, customerNbr,userId);

	}

}