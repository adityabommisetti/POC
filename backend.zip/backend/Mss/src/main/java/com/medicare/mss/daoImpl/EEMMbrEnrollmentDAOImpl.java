package com.medicare.mss.daoImpl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMMbrEnrollmentDAO;
import com.medicare.mss.domainobject.EEMMbrEligibilityDO;
import com.medicare.mss.domainobject.EEMMbrEnrollmentDO;
import com.medicare.mss.domainobject.EMMbrTriggerDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EMDatedSegmentVO;


@Repository
public class EEMMbrEnrollmentDAOImpl implements EEMMbrEnrollmentDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public int setOverride(EMDatedSegmentVO emDatedSegmentVO, String userId) throws ApplicationException {
		
		String timeStamp = DateUtil.getCurrentDatetimeStamp();
		EEMMbrEnrollmentDO mbrEnroll = (EEMMbrEnrollmentDO) emDatedSegmentVO;

		try {
			String sql = CommonUtils.buildQuery("UPDATE EM_MBR_ENROLLMENT",
					" SET OVERRIDE_IND = 'Y', LAST_UPDT_TIME = ?, LAST_UPDT_USERID = ?",
					" WHERE CUSTOMER_ID = ? AND MEMBER_ID = ?", " AND EFF_START_DATE = ? AND CREATE_TIME = ?",
					" AND OVERRIDE_IND = 'N' AND LAST_UPDT_TIME = ?");

			Object[] parms = new Object[] { timeStamp,userId, mbrEnroll.getCustomerId(), mbrEnroll.getMemberId(),
					mbrEnroll.getEffStartDate(), mbrEnroll.getCreateTime(), mbrEnroll.getLastUpdtTime() };
			return jdbcTemplate.update(sql, parms);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Exception in setOverride Enrollment");
		}
	}

	@Override
	public int insertMbr(EMDatedSegmentVO emDatedSegmentVO) throws ApplicationException {

		EEMMbrEnrollmentDO mbrEnroll = (EEMMbrEnrollmentDO) emDatedSegmentVO;
		try {
			String sql = CommonUtils.buildQuery(
					"INSERT INTO EM_MBR_ENROLLMENT(CUSTOMER_ID, MEMBER_ID, EFF_START_DATE, CREATE_TIME,",
					"EFF_END_DATE, OVERRIDE_IND,GRP_ID, PRODUCT_ID, SUPPLEMENTAL_ID,",
					"ENROLL_STATUS, ENROLL_REASON_CD,", "PLAN_ID, PBP_ID, PBP_SEGMENT_ID, PLAN_TYPE, PLAN_DESIGNATION,",
					"ELECTION_TYPE_CD, SEP_ELECTION_DATE, SEP_REASON_CD, ELC_DERIVED_IND,",
					"RX_ID, SEC_RX_GRP, SEC_RX_NAME, SEC_RX_ID, SEC_RX_BIN, SEC_RX_PCN,",
					"DIS_REASON_CD, ENROLL_SRCE_CD, APPLICATION_ID, APPLICATION_DATE, SIGNATURE_DATE,",
					"RECEIPT_DATE,EDIT_OVERRIDE_IND,", "CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID,",
					"REQ_REASON_CD, RECIEVE_DATE, PLAN_REASON_CD,TRG72_IND)",
					" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,",
					"?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

			String parm35 = "";
			String parm36 = "";
			String parm37 = "";
			String parm38 = "";

			if (!(StringUtil.nonNullTrim(mbrEnroll.getButtonClicked()).equals("cancelEnrollment"))
					|| !StringUtil.nonNullTrim(mbrEnroll.getCancellationReason()).equals(""))
				parm35 = StringUtil.nonNullTrim(mbrEnroll.getCancellationReason());
			else
				parm35 = " ";
			if (!StringUtil.nonNullTrim(mbrEnroll.getReceivedDate()).equals(""))
				parm36 = StringUtil.nonNullTrim(mbrEnroll.getReceivedDate());
			else
				parm36 = " ";
			if (!StringUtil.nonNullTrim(mbrEnroll.getPlanReasonCd()).equals(""))
				parm37 = StringUtil.nonNullTrim(mbrEnroll.getPlanReasonCd());
			else
				parm37 = " ";
			if ("Y".equalsIgnoreCase(mbrEnroll.getTrg72Ind()))
				mbrEnroll.setTrg72Ind("Y");
			else
				mbrEnroll.setTrg72Ind("N");

			parm38 = StringUtil.nonNullTrim(mbrEnroll.getTrg72Ind());

			Object[] parms = new Object[] { mbrEnroll.getCustomerId(), mbrEnroll.getMemberId(),
					mbrEnroll.getEffStartDate(), mbrEnroll.getCreateTime(), mbrEnroll.getEffEndDate(), mbrEnroll.getOverrideInd(),
					mbrEnroll.getGrpId(), mbrEnroll.getProductId(), mbrEnroll.getSupplementalId(),
					mbrEnroll.getEnrollStatus(), mbrEnroll.getEnrollReasonCd(), mbrEnroll.getPlanId(),
					mbrEnroll.getPbpId(), mbrEnroll.getPbpSegmentId(), mbrEnroll.getPlanType(),
					mbrEnroll.getPlanDesignation(), mbrEnroll.getElectionTypeCd(), mbrEnroll.getSepElectionDate(),
					mbrEnroll.getSepReasonCd(), mbrEnroll.getElcDerivedInd(),
					StringUtil.nonNullTrim(mbrEnroll.getRxId()), "", "", "", "", "", mbrEnroll.getDisReasonCd(),
					mbrEnroll.getEnrollSrceCd(), mbrEnroll.getApplicationId(), mbrEnroll.getApplicationDate(),
					mbrEnroll.getSignatureDate(), StringUtil.nonNullTrim(mbrEnroll.getReceiptDate()),
					mbrEnroll.getEditOverrideInd(), mbrEnroll.getCreateUserId(),mbrEnroll.getLastUpdtTime() ,mbrEnroll.getLastUpdtUserId(), parm35,
					parm36, parm37, parm38 };

			return jdbcTemplate.update(sql, parms);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error in Enrollment insertMbr");
		}
	}

	@Override
	public boolean checkDuplSupplId(String customerId, String supplId, String memberId) throws ApplicationException {

		try {
			String sql = CommonUtils.buildQuery("SELECT SUPPLEMENTAL_ID  FROM EM_MBR_ENROLLMENT",
					" WHERE CUSTOMER_ID = ?", "AND SUPPLEMENTAL_ID = ?  AND OVERRIDE_IND = 'N'");

			ArrayList<Object> parms = new ArrayList<>();
			parms.add(customerId);
			parms.add(supplId);

			if (!StringUtil.nonNullTrim(memberId).equals("")) {
				sql = sql + "   AND MEMBER_ID != ?";
				parms.add(memberId);
			}
			sql = sql + " FETCH FIRST 1 ROWS ONLY";
			
				jdbcTemplate.queryForObject(sql, parms.toArray(), String.class);
			
			return true;
		} catch (EmptyResultDataAccessException exp) {
			return false;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error in Enrollment checkDuplSupplId");
		}
	}

	@Override
	public boolean isUnlawfullyEligible(String reqCovDt, String hicNbr, String mbiNbr, String table)
			throws ApplicationException {

		String tableName = "";
		try {
			if (table.equals(EEMConstants.EM_TABLE_BEQ)) {
				tableName = "BEQR_INELIGIBILITY";
			} else {
				tableName = "INELIGIBILITY";
			}
			String sQuery = CommonUtils.buildQuery("SELECT HIC_NBR FROM ", tableName, " WHERE HIC_NBR in (?,?) ",
					"AND SDATE <= ? AND (EDATE >=? OR EDATE ='00000000' OR EDATE ='') FETCH FIRST 1 ROWS ONLY");

				jdbcTemplate.queryForObject(sQuery, new Object[] { hicNbr, mbiNbr, reqCovDt, reqCovDt }, String.class);
			return true;

		} 
		catch (EmptyResultDataAccessException exp) {
			return false;
		}catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error in Enrollment isUnlawfullyEligible");
		}

	}

	@Override
	public boolean isIncarcerated(String reqCovDt, String hicNbr, String mbiNbr, String table)
			throws ApplicationException {

		String tableName = "";
		try {
			if (table.equals(EEMConstants.EM_TABLE_BEQ)) {
				tableName = "BEQR_INCARCERATION";
			} else {
				tableName = "INCARCERATION";
			}

			String sQuery = CommonUtils.buildQuery("SELECT HIC_NBR FROM ", tableName, " WHERE HIC_NBR in (?,?) ",
					"AND SDATE <= ? AND (EDATE >=? OR EDATE ='00000000' OR EDATE ='') FETCH FIRST 1 ROWS ONLY");

		
				jdbcTemplate.queryForObject(sQuery, new Object[] { hicNbr, mbiNbr, reqCovDt, reqCovDt },
						String.class);
				return true;
			
		}catch (EmptyResultDataAccessException exp) {
			return false;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error in Enrollment isIncarcerated");
		}

	}

	/**
	 * Method to check if the MA-OEP Election Type is already used?
	 * 
	 * @param conn
	 * @param memberId
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public boolean isMAOEPElectionTypeAlreadyUsed(String custID, String memberId, String date1, String date2)
			throws ApplicationException {

		try {
			if (!StringUtil.isNullOrEmptyOrSpace(memberId)) {

				String enrollmentSQL = CommonUtils.buildQuery("SELECT MEMBER_ID FROM EM_MBR_ENROLLMENT",
						" WHERE CUSTOMER_ID = ?  AND OVERRIDE_IND = 'N'",
						" AND MEMBER_ID = ? AND ELECTION_TYPE_CD = 'M'",
						" AND ENROLL_STATUS IN('EAPRV','DAPRV') AND ENROLL_REASON_CD = 'CMSAPRV'",
						" AND EFF_START_DATE BETWEEN ? AND ? FETCH FIRST ROW ONLY");
				
					jdbcTemplate.queryForObject(enrollmentSQL,
							new Object[] { custID, memberId, date1, date2 }, String.class);				
					return true;
			

			}
		} catch (EmptyResultDataAccessException exp) {
			return false;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "isMAOEPElectionTypeAlreadyUsed");
		}
		return false;
	}

	/**
	 * Method to check if the member has any break in coverage ?
	 * 
	 * @param conn
	 * @param memberId
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public boolean validateBrkInCov(String custID, String memberId, String date, String reqDtOfCov)
			throws ApplicationException {

		try {
			if (!StringUtil.isNullOrEmptyOrSpace(memberId)) {

				String enrollmentSQL = CommonUtils.buildQuery("SELECT MEMBER_ID FROM EM_MBR_ENROLLMENT",
						" WHERE CUSTOMER_ID = ?  AND OVERRIDE_IND = 'N'" + " AND MEMBER_ID = ?",
						" AND ENROLL_STATUS = 'DAPRV' AND ENROLL_REASON_CD = 'CMSAPRV'",
						" AND EFF_START_DATE BETWEEN ? AND ? FETCH FIRST ROW ONLY ");
				
						jdbcTemplate.queryForObject(enrollmentSQL,
							new Object[] { custID, memberId, date, reqDtOfCov }, String.class);
						return true;		
				

			}
		} catch (EmptyResultDataAccessException exp) {
			return false;
		}catch (DataAccessException exp) {
			throw new ApplicationException(exp, "validateBrkInCov");
		}
		return false;
	}
	@Override
	public int insertMbrEligibility(EEMMbrEligibilityDO mbrElig) throws ApplicationException {

		try {
			String sql = CommonUtils.buildQuery(
					"INSERT INTO EM_MBR_ELIGIBILITY(" + " CUSTOMER_ID, MEMBER_ID, LAST_CHECKED_TIME,",
					" HIC_NBR, LAST_NAME, FIRST_NAME, MIDDLE_INIT,",
					" GENDER_NUM_CD, BIRTH_DATE, LIVING_STATUS, DEATH_DATE,",
					" PRTA_ENTITLE_DATE, PRTA_ENTITLE_EDATE, PRTB_ENTITLE_DATE, PRTB_ENTITLE_EDATE,",
					" PRTD_ELIG_SDATE, PRTA_OPTION, PRTB_OPTION, ENROLLMENT_STATUS,",
					" HOSPICE_IND, HOSPICE_SDATE, HOSPICE_EDATE,", " INSTITUTIONAL_IND, INST_SDATE, INST_EDATE,",
					" ESRD_IND, ESRD_SDATE, ESRD_EDATE,", " WRKAGED_IND, WRKAGED_SDATE, WRKAGED_EDATE,",
					" MEDIC_IND, MEDIC_SDATE, MEDIC_EDATE,", " RACE_CD, STATE_CD, COUNTY_CD,",
					" CALC_UNCOV_MONTHS, ELIGIBILITY_SOURCE, LAST_UPDT_USERID) VALUES (?,?,?,?,?,?,?,?,?,?,",
					"?,?,?,?,?,?,?,?,?,?,", "?,?,?,?,?,?,?,?,?,?,", "?,?,?,?,?,?,?,?,?,?)");

			Object[] parms = new Object[] { mbrElig.getCustomerId(), mbrElig.getMemberId(),
					mbrElig.getLastCheckedTime(), mbrElig.getHicNbr(), mbrElig.getLastName(), mbrElig.getFirstName(),
					mbrElig.getMiddleInit(), mbrElig.getGenderNumCd(), mbrElig.getBirthDate(),
					mbrElig.getLivingStatus(), mbrElig.getDeathDate(), mbrElig.getPrtAEntitleStartDate(),
					mbrElig.getPrtAEntitleEndDate(), mbrElig.getPrtBEntitleStartDate(), mbrElig.getPrtBEntitleEndDate(),
					mbrElig.getPrtDEligStartDate(), mbrElig.getPrtAOption(), mbrElig.getPrtBOption(),
					mbrElig.getEnrollmentStatus(), mbrElig.getHospiceInd(), mbrElig.getHospiceStartDate(),
					mbrElig.getHospiceEndDate(), mbrElig.getInstInd(), mbrElig.getInstStartDate(),
					mbrElig.getInstEndDate(), mbrElig.getEsrdInd(), mbrElig.getEsrdStartDate(),
					mbrElig.getEsrdEndDate(), mbrElig.getWrkAgedInd(), mbrElig.getWrkAgedStartDate(),
					mbrElig.getWrkAgedEndDate(), mbrElig.getMedicInd(), mbrElig.getMedicStartDate(),
					mbrElig.getMedicEndDate(), mbrElig.getRaceCD(), mbrElig.getStateCd(), mbrElig.getCountyCd(),
					mbrElig.getCalcUncovMonths(), mbrElig.getEligibilitySource(), mbrElig.getLastUpdtUserid() };
			return jdbcTemplate.update(sql, parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Exception in insertMbrEligibility");
		}
	}
	@Override
	public int updateTXNFlag(String txnCode, boolean flag,EEMMbrEnrollmentDO newVO) throws ApplicationException {

		try {
			String sql = CommonUtils.buildQuery("UPDATE EM_MBR_ENROLLMENT SET TRG72_IND = ? ",
					 " WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? AND LAST_UPDT_TIME = ? AND LAST_UPDT_USERID = ? ",
					 "AND CREATE_TIME = ? AND CREATE_USERID = ? AND OVERRIDE_IND = ? AND TRG72_IND = ?");

			
			Object[] parms = new Object[] {
					flag ? "Y" : "N",
								newVO.getCustomerId(),
								newVO.getMemberId(),
								newVO.getLastUpdtTime(),
								newVO.getLastUpdtUserId(),
								newVO.getCreateTime(),
								newVO.getCreateUserId(),
								newVO.getOverrideInd(),
								!flag ? "Y" : "N"	
			};
			return jdbcTemplate.update(sql, parms);
			

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Exception in updateTXNFlag");
		}
	}
	@Override
	public String getMbrTriggerCode(String funcType, EEMMbrEnrollmentDO enrollVO)
			throws ApplicationException {
		
		try {
			String sql = "SELECT TRIGGER_CODE FROM EM_FUNCTION_CORR_INDEX WHERE CUSTOMER_ID=? AND FUNCTION_TYPE = ? AND PLAN_DESIGNATION = ?";
			
			String code = jdbcTemplate.queryForObject(sql,
					new Object[] { StringUtil.nonNullTrim(enrollVO.getCustomerId()), funcType, StringUtil.nonNullTrim(enrollVO.getPlanDesignation())}, String.class);
			return StringUtil.nonNullTrim(code);
		}catch (EmptyResultDataAccessException exp) {
			return null;
		}		
		catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Exception in getMbrTriggerCode");
		}
	}
	@Override
	public int updateFUMTrigger(EMMbrTriggerDO trig) throws ApplicationException {

		try {
			String sql = CommonUtils.buildQuery("UPDATE EM_MBR_TRIGGER SET TRIGGER_STATUS = ?, LAST_UPDT_TIME = ?, LAST_UPDT_USERID = ?",
					 " WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? AND TRIGGER_TYPE = ? ",
					 "   AND TRIGGER_CODE = ? AND TRIGGER_STATUS = ?");

			
			Object[] parms = new Object[] {
			EEMConstants.TRIG_STATUS_CLOSED,
			trig.getLastUpdtTime(),
			trig.getLastUpdtUserId(),
			trig.getCustomerId(),
			trig.getMemberId(),
			EEMConstants.TRIG_TYPE_FOLLOWUP_MEMB,
			EEMConstants.TRIG_CODE_OPRD,
			EEMConstants.TRIG_STATUS_OPEN
			};

			return jdbcTemplate.update(sql, parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error Updating FollowUp Member trigger status");
		}
	}
	@Override
	public double getPartCPremium(EEMMbrEnrollmentDO enrollVO)
			throws  ApplicationException {

		try {
			String sql = CommonUtils.buildQuery("SELECT PRTC_PREMIUM_AMT FROM EM_GRP_PRODUCT WHERE CUSTOMER_ID = ?",
					 "   AND GRP_ID = ? AND PRODUCT_ID = ?",
					 "   AND ? BETWEEN GRP_PROD_START_DATE AND GRP_PROD_END_DATE AND PLAN_ID = ?",
					 "   AND PBP_ID = ? FETCH FIRST 1 ROWS ONLY");
			Object[] parms = new Object[] {
			enrollVO.getCustomerId(),
			enrollVO.getGrpId(),
			enrollVO.getProductId(),
			enrollVO.getEffStartDate(),
			enrollVO.getPlanId(),
			enrollVO.getPbpId()
			};
			return jdbcTemplate.queryForObject(sql,parms,Double.class);
		}
		catch (EmptyResultDataAccessException exp) {
			return 0;
		}
		catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error getPartCPremium");
		}
	}

	@Override
	public int closeOpenPrintIDCardTrigger(EMMbrTriggerDO trigDO) {
		
		Object[] parms = new Object[] {"CLOSED", trigDO.getCustomerId(), trigDO.getMemberId(),
				trigDO.getTriggerType(), trigDO.getEffectiveDate(), trigDO.getTriggerCode(),
				trigDO.getPlanId(), trigDO.getPbpId(), trigDO.getPlanDesignation(),
				"OPEN", trigDO.getProcessSource()};
		
		try {
			StringBuilder sQuery = CommonUtils.buildQueryBuilder(
							" UPDATE EM_MBR_TRIGGER SET TRIGGER_STATUS=? WHERE CUSTOMER_ID=?",
							" AND MEMBER_ID=? AND TRIGGER_TYPE=? AND EFFECTIVE_DATE=?",
							" AND TRIGGER_CODE=? AND PLAN_ID=? AND	PBP_ID=?",
							" AND PLAN_DESIGNATION=? AND TRIGGER_STATUS=? AND PROCESS_SOURCE=?");

			return jdbcTemplate.update(sQuery.toString(), parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error Updating Trigger table");
		}
	}

	@Override
	public String getClient(EEMMbrEnrollmentDO newVO) {
		try {
			String sql = CommonUtils.buildQuery(
					"SELECT CLIENT_ID FROM EM_GRP_PRODUCT WHERE CUSTOMER_ID = ?",
					" AND GRP_ID = ? AND PRODUCT_ID = ? AND PLAN_ID = ?",
					" AND PBP_ID = ? AND PBP_SEGMENT_ID = ?" +
					" AND ? BETWEEN GRP_PROD_START_DATE AND GRP_PROD_END_DATE" +
					" AND CLIENT_ID NOT IN ('', '0') FETCH FIRST 1 ROW ONLY");
			Object[] parms = new Object[] {
					newVO.getCustomerId(),newVO.getGrpId(),newVO.getProductId(),newVO.getPlanId(),
					newVO.getPbpId(),newVO.getPbpSegmentId(),newVO.getEffStartDate()};
			return jdbcTemplate.queryForObject(sql,parms,String.class);
		}
		catch (EmptyResultDataAccessException exp) {
			return "";
		}
		catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error getClient");
		}
	}

}
