package com.medicare.mss.daoImpl;

import static com.medicare.mss.util.StringUtil.nonNullTrim;

import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMMbrOoaDAO;
import com.medicare.mss.domainobject.EEMMbrEnrollmentDO;
import com.medicare.mss.domainobject.EEMMbrOoaInfoDO;
import com.medicare.mss.domainobject.EMMbrTriggerDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.DateUtil;

@Repository
public class EEMMbrOoaDAOImpl implements EEMMbrOoaDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<EEMMbrOoaInfoDO> getMbrOoaInfos(String customerId, String memberId, String showAll)
			throws ApplicationException {

		try {

			String sqlOverride = " AND OVERRIDE_IND IN ('N') ORDER BY CREATE_TIME DESC";

			if ("Y".equals(showAll))
				sqlOverride = " ORDER BY CREATE_TIME DESC ";

			String sQuery = CommonUtils.buildQuery("SELECT CUSTOMER_ID, MEMBER_ID, OOA_RCVD_DT, OOA_TYPE, OOA_SRC_CD,",
					"OOA_REASON_CD, OOA_LEAVE_DT, OOA_RETURN_DT,",
					"LAST_UPDT_TIME, LAST_UPDT_USERID,OVERRIDE_IND, CREATE_USERID, ",
					"OOA_DISEN_EFF_DT, OOA_END_DT, OOA_DISEN_REASON,CREATE_TIME FROM EM_MBR_OOA ",
					"WHERE CUSTOMER_ID = ? AND MEMBER_ID = ?", sqlOverride);

			return jdbcTemplate.query(sQuery, new DomainPropertyRowMapper<EEMMbrOoaInfoDO>(EEMMbrOoaInfoDO.class),
					customerId, memberId);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public int insertMbrOoaInfo(EEMMbrOoaInfoDO mbrOoaInfo) {

		try {
			String sql = CommonUtils.buildQuery("INSERT INTO EM_MBR_OOA(CUSTOMER_ID,",
					" MEMBER_ID, OOA_RCVD_DT, OOA_TYPE, OOA_SRC_CD,OOA_REASON_CD, ",
					" OVERRIDE_IND, OOA_LEAVE_DT,OOA_RETURN_DT, OOA_DISEN_EFF_DT, OOA_END_DT, OOA_DISEN_REASON,",
					" LAST_UPDT_TIME, LAST_UPDT_USERID, CREATE_TIME,CREATE_USERID) ",
					"VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

			String trrSource = nonNullTrim(mbrOoaInfo.getOoaSourceTrr());

			if (trrSource.equals("05-TRR")) {
				mbrOoaInfo.setOoaSource("05");
			}

			String ooaReason = nonNullTrim(mbrOoaInfo.getOoaReason());
			String deReason = nonNullTrim(mbrOoaInfo.getDeReason());

			if (mbrOoaInfo.getTempPerm().equalsIgnoreCase("Temp")) {
				deReason = "";
			} else if (mbrOoaInfo.getTempPerm().equalsIgnoreCase("Perm")) {
				ooaReason = "";
			}
			Object[] parms = new Object[] { mbrOoaInfo.getCustomerId(), mbrOoaInfo.getMemberId(),
					mbrOoaInfo.getReceiveDate(), mbrOoaInfo.getTempPerm(), mbrOoaInfo.getOoaSource(), ooaReason,
					mbrOoaInfo.getOverrideInd(), mbrOoaInfo.getLeaveDate(), mbrOoaInfo.getReturnDate(),
					mbrOoaInfo.getDeEffectiveDate(), mbrOoaInfo.getEndDate(), deReason, mbrOoaInfo.getLastUpdtTime(),
					mbrOoaInfo.getLastUpdtUserId(), mbrOoaInfo.getCreateTime(), mbrOoaInfo.getCreateUserId() };

			return jdbcTemplate.update(sql, parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}

	}

	@Override
	public int setOoaInfoOverride(EEMMbrOoaInfoDO mbrOoa, String userId) {

		try {
			String sql = CommonUtils.buildQuery("UPDATE EM_MBR_OOA",
					" SET OVERRIDE_IND = 'Y', LAST_UPDT_TIME = ?, LAST_UPDT_USERID = ?",
					" WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? ", " AND OOA_TYPE = ? AND OVERRIDE_IND = 'N' ");

			return jdbcTemplate.update(sql, DateUtil.getCurrentDatetimeStamp(), userId, mbrOoa.getCustomerId(),
					mbrOoa.getMemberId(), mbrOoa.getTempPerm());
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}
	}

	@Override
	public EEMMbrEnrollmentDO getOoaDisenroll(EEMMbrOoaInfoDO mbrOoa, String userId) {

		try {
			String sql = CommonUtils.buildQuery(
					" SELECT CUSTOMER_ID,MEMBER_ID,EFF_START_DATE,CREATE_TIME,EFF_END_DATE,OVERRIDE_IND,GRP_ID,PRODUCT_ID, ",
					" PBP_ID,SUPPLEMENTAL_ID,ENROLL_STATUS,ENROLL_REASON_CD,PLAN_ID,",
					" PBP_SEGMENT_ID,PLAN_TYPE,PLAN_DESIGNATION,ELECTION_TYPE_CD,",
					" SEP_ELECTION_DATE,SEP_REASON_CD,ELC_DERIVED_IND,DIS_REASON_CD,PLAN_REASON_CD,ENROLL_SRCE_CD,",
					" APPLICATION_ID,APPLICATION_DATE,SIGNATURE_DATE,",
					" EDIT_OVERRIDE_IND,CREATE_USERID,LAST_UPDT_TIME,REQ_REASON_CD,RECIEVE_DATE ",
					" FROM EM_MBR_ENROLLMENT ",
					" WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? AND  ? BETWEEN EFF_START_DATE AND EFF_END_DATE",
					" AND OVERRIDE_IND = 'N' ");

			return jdbcTemplate.queryForObject(sql,
					new DomainPropertyRowMapper<EEMMbrEnrollmentDO>(EEMMbrEnrollmentDO.class), mbrOoa.getCustomerId(),
					mbrOoa.getMemberId(), mbrOoa.getDeEffectiveDate());

		} catch (EmptyResultDataAccessException exp) {

			return null;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}

	}

	@Override
	public int setOoaDisenroll(EEMMbrOoaInfoDO mbrOoa, EEMMbrEnrollmentDO enroll, String userId)
			throws ApplicationException, ParseException {

		int sqlCnt = 0;

		try {

			String effDate = enroll.getEffStartDate();
			String deEffDate = mbrOoa.getDeEffectiveDate();
			String dt = DateMath.minusOneDay(deEffDate);
			String enrollStatus = nonNullTrim(enroll.getEnrollStatus());
			String enrollReasonCd = nonNullTrim(enroll.getEnrollReasonCd());

			sqlCnt = updateMbrEnrollement(mbrOoa.getCustomerId(), mbrOoa.getMemberId(), userId, "");

			updateMbrEnrollement(mbrOoa.getCustomerId(), mbrOoa.getMemberId(), userId, mbrOoa.getDeEffectiveDate());

			String sql2 = CommonUtils.buildQuery("INSERT INTO EM_MBR_ENROLLMENT(",
					"CUSTOMER_ID, MEMBER_ID, EFF_START_DATE, CREATE_TIME,", "EFF_END_DATE, OVERRIDE_IND,",
					"GRP_ID, PRODUCT_ID, SUPPLEMENTAL_ID,", "ENROLL_STATUS, ENROLL_REASON_CD,",
					"PLAN_ID, PBP_ID, PBP_SEGMENT_ID, PLAN_TYPE, PLAN_DESIGNATION,",
					"ELECTION_TYPE_CD, SEP_ELECTION_DATE, SEP_REASON_CD, ELC_DERIVED_IND,",
					"SEC_RX_NAME, SEC_RX_ID,",
					"DIS_REASON_CD, ENROLL_SRCE_CD, APPLICATION_ID, APPLICATION_DATE, SIGNATURE_DATE,",
					"EDIT_OVERRIDE_IND,", "CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID,",
					"REQ_REASON_CD, RECIEVE_DATE,RX_ID, SEC_RX_GRP, SEC_RX_BIN, SEC_RX_PCN,RECEIPT_DATE",
					") VALUES(?,?,?,?,?,?,?,?,?,?,", "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,",
					"?,?,?,?,?,?,?,?)");
			

			Object[] parms = new Object[] { nonNullTrim(mbrOoa.getCustomerId()), nonNullTrim(mbrOoa.getMemberId()),
					effDate, nonNullTrim(mbrOoa.getCreateTime()), nonNullTrim(dt), nonNullTrim(mbrOoa.getOverrideInd()),
					nonNullTrim(enroll.getGrpId()), nonNullTrim(enroll.getProductId()),
					nonNullTrim(enroll.getSupplementalId()), enrollStatus, enrollReasonCd,
					nonNullTrim(enroll.getPlanId()), nonNullTrim(enroll.getPbpId()),
					nonNullTrim(enroll.getPbpSegmentId()), nonNullTrim(enroll.getPlanType()),
					nonNullTrim(mbrOoa.getPlanDesignation()), "V", nonNullTrim(enroll.getSepElectionDate()),
					nonNullTrim(enroll.getSepReasonCd()), nonNullTrim(enroll.getElcDerivedInd()), " ", " ",
					nonNullTrim("92"), nonNullTrim(enroll.getEnrollSrceCd()), enroll.getApplicationId(),
					nonNullTrim(enroll.getApplicationDate()), nonNullTrim(mbrOoa.getReceiveDate()),
					nonNullTrim(enroll.getEditOverrideInd()), nonNullTrim(mbrOoa.getCreateUserId()),
					nonNullTrim(mbrOoa.getLastUpdtTime()), nonNullTrim(mbrOoa.getLastUpdtUserId()),
					nonNullTrim(enroll.getCancellationReason()), nonNullTrim(mbrOoa.getReceiveDate()), " ", " ", " ", " ", " " };

			if (DateMath.isGreaterThan(deEffDate, effDate)) {
				jdbcTemplate.update(sql2, parms);
			}
			if (sqlCnt > 0) {

				parms[2] = nonNullTrim(mbrOoa.getDeEffectiveDate());
				parms[4] = "99999999";
				parms[9] = EEMConstants.MBR_STAT_DPEND;
				parms[10] = EEMConstants.MBR_REASON_CMS_READY;
				jdbcTemplate.update(sql2, parms);

			}

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}

		return sqlCnt;
	}

	private int updateMbrEnrollement(String customerId, String memberId, String userId, String effDate) {
		StringBuilder updateSql = CommonUtils.buildQueryBuilder("UPDATE EM_MBR_ENROLLMENT",
				" SET OVERRIDE_IND = 'Y', LAST_UPDT_TIME = CURRENT_TIMESTAMP, LAST_UPDT_USERID = ?",
				" WHERE CUSTOMER_ID = ? AND MEMBER_ID = ?  AND OVERRIDE_IND = 'N' ");

		if (effDate.isEmpty()) {
			updateSql.append("  AND EFF_END_DATE = ? ");
			effDate = EEMConstants.EFF_END_DATE;
		} else {
			updateSql.append(" AND ? BETWEEN EFF_START_DATE AND EFF_END_DATE");
		}

		return jdbcTemplate.update(updateSql.toString(), userId, customerId, memberId, effDate);
	}

	@Override
	public int closeFUMTrigger(EMMbrTriggerDO trig) {

		try {
			String sql = CommonUtils.buildQuery(
					"UPDATE EM_MBR_TRIGGER SET TRIGGER_STATUS = ?, LAST_UPDT_TIME = ?, LAST_UPDT_USERID = ?",
					" WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? AND TRIGGER_TYPE = ? ",
					"   AND TRIGGER_CODE = ? AND TRIGGER_STATUS = ?");

			Object[] parms = new Object[] { EEMConstants.TRIG_STATUS_CLOSED, trig.getLastUpdtTime(),
					trig.getLastUpdtUserId(), trig.getCustomerId(), trig.getMemberId(),
					EEMConstants.TRIG_TYPE_FOLLOWUP_MEMB, trig.getTriggerCode(), EEMConstants.TRIG_STATUS_OPEN };

			return jdbcTemplate.update(sql, parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}

	}

}
