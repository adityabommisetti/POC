package com.medicare.mss.rowmappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.medicare.mss.domainobject.EEMApplTriggerDO;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.StringUtil;

public class ApplTriggerRowMapper implements RowMapper<EEMApplTriggerDO> {

	@Override
	public EEMApplTriggerDO mapRow(ResultSet rs, int rowNum) throws SQLException {
		EEMApplTriggerDO trig = new EEMApplTriggerDO();
		trig.setCustomerId(StringUtil.nonNullTrim(rs.getString("CUSTOMER_ID")));
		trig.setApplicationId(rs.getString("APPLICATION_ID"));
		trig.setTriggerType(StringUtil.nonNullTrim(rs.getString("TRIGGER_TYPE")));
		trig.setEffectiveDate(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("EFFECTIVE_DATE"))));
		trig.setCreateTime(StringUtil.nonNullTrim(rs.getString("CREATE_TIME")));
		trig.setTriggerStatus(StringUtil.nonNullTrim(rs.getString("TRIGGER_STATUS")));
		trig.setTriggerCode(StringUtil.nonNullTrim(rs.getString("TRIGGER_CODE")));
		trig.setOrigTriggerType(StringUtil.nonNullTrim(rs.getString("ORIG_TRIGGER_TYPE")));
		trig.setOrigTriggerCode(StringUtil.nonNullTrim(rs.getString("ORIG_TRIGGER_CODE")));
		trig.setOrigEffectiveDate(DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(rs.getString("ORIG_EFFECTIVE_DATE"))));
		trig.setOrigTriggerCreateTime(StringUtil.nonNullTrim(rs.getString("ORIG_TRIGGER_CREATE_TIME")));				
		trig.setCreateUserid(StringUtil.nonNullTrim(rs.getString("CREATE_USERID")));
		trig.setLastUpdtTime(StringUtil.nonNullTrim(rs.getString("LAST_UPDT_TIME")));
		trig.setLastUpdtUserid(StringUtil.nonNullTrim(rs.getString("LAST_UPDT_USERID")));
		return trig;
	}

}
