package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class SecurityRoleDO {

	@ColumnMapper(columnName = "USER_ID", propertyName = "userId")
	private String userId;

	@ColumnMapper(columnName = "GROUP_ID", propertyName = "groupId")
	private String groupId;

	@ColumnMapper(columnName = "GROUP_NAME", propertyName = "groupName")
	private String groupName;
	
	@ColumnMapper(columnName = "SERVICE_ID", propertyName = "serviceId")
	private String serviceId;

	@ColumnMapper(columnName = "SERVICE_NAME", propertyName = "serviceName")
	private String serviceName;

}
