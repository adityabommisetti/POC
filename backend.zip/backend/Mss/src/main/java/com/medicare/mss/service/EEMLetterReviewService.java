package com.medicare.mss.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.caching.EEMPersistence;
import com.medicare.mss.dao.EEMLetterReviewDAO;
import com.medicare.mss.domainobject.EEMLetterUploadFormDO;
import com.medicare.mss.domainobject.EmCorrMbrDO;
import com.medicare.mss.domainobject.EmCorrVarDataDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EEMLetterReviewQCMasterVO;
import com.medicare.mss.vo.EEMLetterReviewVO;
import com.medicare.mss.vo.EEMLetterUploadFormVO;
import com.medicare.mss.vo.EEMMbrLetterMasterVO;
import com.medicare.mss.vo.EmCorrMbrVO;
import com.medicare.mss.vo.EmCorrVarDataVO;
import com.medicare.mss.vo.LetterCacheVO;
import com.medicare.mss.vo.PageableVO;

@Service
@Transactional(rollbackFor = ApplicationException.class)
public class EEMLetterReviewService {

	@Autowired
	private EEMLetterReviewDAO eemLetterReviewDao;

	@Autowired
	private EEMPersistence eemPer;

	@Autowired
	private CacheService sessionHelper;

	public List<EmCorrVarDataVO> getMbrLetterVarDataList(Map<String, String> searchParamMap) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		searchParamMap.put("customerId", customerId);

		List<EmCorrVarDataVO> mbrLetterVarDataVOList = new ArrayList<>();

		List<EmCorrVarDataDO> mbrLetterVarDataList = eemLetterReviewDao.getMbrLetterData(searchParamMap);

		mbrLetterVarDataList.forEach(mbrLetterVarData -> {
			EmCorrVarDataVO emCorrMbrVO = new EmCorrVarDataVO();

			if (StringUtil.nonNullTrim(mbrLetterVarData.getVariableDesc()).isEmpty()) {
				mbrLetterVarData.setVariableDesc(mbrLetterVarData.getVariableId());
			}

			BeanUtils.copyProperties(mbrLetterVarData, emCorrMbrVO);
			mbrLetterVarDataVOList.add(emCorrMbrVO);
		});

		return mbrLetterVarDataVOList;

	}

	public PageableVO letterReviewSearchPage(EEMLetterReviewVO letterReviewVO,boolean isPagination) {

		letterReviewVO.setCustomerId(sessionHelper.getUserInfo().getCustomerId());
		return eemLetterReviewDao.getLetterReviewSearchResults(letterReviewVO,isPagination);
	}

	public byte[] displayDocumentFromDB(Map<String, String> searchParamMap) {

		byte[] blobByte = null;

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		searchParamMap.put("customerId", customerId);

		blobByte = eemLetterReviewDao.displayDocumentFromDB(searchParamMap);

		return blobByte;
	}

	@SuppressWarnings("unchecked")
	public Object letterReviewSearch(EEMLetterReviewVO letterReviewVO,boolean isPagination) {
		EEMMbrLetterMasterVO mbrLetterMasterVO = new EEMMbrLetterMasterVO();
		List<EmCorrMbrVO> mbrLetterVOList = new ArrayList<>();
		
		PageableVO mbrLetterDetails = letterReviewSearchPage(letterReviewVO,isPagination);
		
		if (!CollectionUtils.isEmpty((List<EmCorrMbrDO>) mbrLetterDetails.getContent())) {
		List<EmCorrMbrDO> mbrLetterDOList = (List<EmCorrMbrDO>) mbrLetterDetails.getContent();
		
		mbrLetterDOList.forEach(mbrLetterSelect -> {
			EmCorrMbrVO mbrLetterVO = new EmCorrMbrVO();

			if (!StringUtil.nonNullTrim(mbrLetterSelect.getLetterUploadedTime()).equals("")) {
				mbrLetterSelect.setLetterAvailabilityInDB("Y");
			} else {
				mbrLetterSelect.setLetterAvailabilityInDB("N");
			}

			BeanUtils.copyProperties(mbrLetterSelect, mbrLetterVO);
			mbrLetterVOList.add(mbrLetterVO);
		}); 
		
		if (mbrLetterVOList.isEmpty()) {
			return mbrLetterVOList;
		} else {
			mbrLetterMasterVO.setNextPage(mbrLetterDetails.isNextPage());
			mbrLetterMasterVO.setLstLetterVO(mbrLetterVOList);

			Map<String, String> searchParamMap = new HashMap<>();

			searchParamMap.put("fileBatchId", mbrLetterVOList.get(0).getFilebatchid());
			searchParamMap.put("recordType", mbrLetterVOList.get(0).getRecordType());
			searchParamMap.put("primaryId", mbrLetterVOList.get(0).getPrimaryId());
			searchParamMap.put("letterName", mbrLetterVOList.get(0).getLetterName());

			List<EmCorrVarDataVO> emCorrMbrVOList = getMbrLetterVarDataList(searchParamMap);
			if (emCorrMbrVOList == null || emCorrMbrVOList.isEmpty()) {
				mbrLetterMasterVO.setLstMbrCorrVO(new ArrayList<EmCorrVarDataVO>());
				return mbrLetterMasterVO;
			} else {
				mbrLetterMasterVO.setLstMbrCorrVO(emCorrMbrVOList);
				return mbrLetterMasterVO;
			}
		}
		}
		else {
			return mbrLetterVOList;
		}
	}

	public EmCorrMbrVO letterCorrMbrUpdate(EmCorrMbrVO letterNewVO) {

		String userId = sessionHelper.getUserInfo().getUserId();
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String ts = DateUtil.getCurrentDatetimeStamp();
		String lastUpdtTime = letterNewVO.getLastUpdtTime();

		letterNewVO.setCustomerId(customerId);
		letterNewVO.setLastUpdtTime(ts);
		letterNewVO.setLastUpdtUserId(userId);

		if (letterNewVO.getDeleteInd() == null)
			letterNewVO.setDeleteInd("");

		if (letterNewVO.getDeleteInd().equals("Y"))
			letterNewVO.setRecordStatus("DELETED");
		
		corrMbrUpdate(letterNewVO, userId, lastUpdtTime);
		return letterNewVO;

	}

	private void corrMbrUpdate(EmCorrMbrVO newVO, String userId, String lastUpdtTime) {

		EmCorrMbrDO newDO = new EmCorrMbrDO();
		BeanUtils.copyProperties(newVO, newDO);
		eemLetterReviewDao.updateCorrMbr(newDO, userId, lastUpdtTime);

		if (!(StringUtil.nonNullTrim(newVO.getDeleteAdj()).equalsIgnoreCase("0"))
				|| !(StringUtil.nonNullTrim(newVO.getHoldAdj()).equalsIgnoreCase("0"))) {

			eemLetterReviewDao.updateCorrInputJournal(StringUtil.nonNullTrim(newVO.getCustomerId()),
					StringUtil.nonNullTrim(newVO.getFilebatchid()), StringUtil.nonNullTrim(newVO.getDeleteAdj()),
					StringUtil.nonNullTrim(newVO.getHoldAdj()), userId);

		}

	}

	public String uploadLetterReviewLetters(EEMLetterUploadFormVO eemLetterUploadForm) {

		eemLetterUploadForm.setCustomerId(sessionHelper.getUserInfo().getCustomerId());
		eemLetterUploadForm.setUserId(sessionHelper.getUserInfo().getUserId());
		String strDateTimeStamp = DateUtil.getCurrentDatetimeStamp();

		if (eemLetterReviewDao.validateSourceAndPrimaryId(StringUtil.nonNullTrim(eemLetterUploadForm.getCustomerId()),
				StringUtil.nonNullTrim(eemLetterUploadForm.getMemberId()),
				StringUtil.nonNullTrim(eemLetterUploadForm.getRecordType()))) {
			uploadLettersToDataBase(eemLetterUploadForm, strDateTimeStamp);
			return "Letter Uploaded Successfully";
		} else {
			throw new ApplicationException(
					"Invalid Source and Primary id OR Give Appropriate file name with Date and try again");
		}

	}

	private void uploadLettersToDataBase(EEMLetterUploadFormVO eemLetterUploadForm, String strDateTimeStamp) {

		String fileBatchId = eemLetterReviewDao.getMaxFileBatchId(
				StringUtil.nonNullTrim(eemLetterUploadForm.getCustomerId()),
				StringUtil.nonNullTrim(eemLetterUploadForm.getMemberId()),
				StringUtil.nonNullTrim(eemLetterUploadForm.getFileName()));
		fileBatchId = getIncrementedFileBatchId(fileBatchId);
		eemLetterUploadForm.setFileBatchId(fileBatchId);

		EEMLetterUploadFormDO eemLetterUploadFormDO = new EEMLetterUploadFormDO();
		BeanUtils.copyProperties(eemLetterUploadForm, eemLetterUploadFormDO);

		eemLetterReviewDao.insertMemberAndApplicationLetters(eemLetterUploadFormDO, strDateTimeStamp);

		eemLetterReviewDao.uploadLettersToDataBase(eemLetterUploadFormDO, strDateTimeStamp);

	}

	private String getIncrementedFileBatchId(String fileBatchId) {

		StringBuilder updatedFileBatchId = new StringBuilder("ONL");
		String batchSequence = fileBatchId.substring(3, fileBatchId.length());
		int batchSequenceLength = batchSequence.length();
		String sequenceIncrement = String.valueOf(Integer.parseInt(batchSequence) + 1);

		for (int index = 0; index < (batchSequenceLength - sequenceIncrement.length()); index++) {
			updatedFileBatchId.append("0");
		}
		return updatedFileBatchId.toString() + String.valueOf(sequenceIncrement);
	}

	public List<LabelValuePair> letterReviewQCsearchbatchId(EEMLetterReviewVO letterReviewVO) {
		return eemLetterReviewDao.getLetterReviewQcBatchId(letterReviewVO, sessionHelper.getUserInfo().getCustomerId());
	}

	public List<LabelValuePair> letterReviewQCsearchDescription(String batchId) {
		return eemLetterReviewDao.getLetterReviewQcDescription(batchId, sessionHelper.getUserInfo().getCustomerId());
	}

	public List<EmCorrMbrVO> letterReviewQCSearchPage(EEMLetterReviewQCMasterVO letterReviewQCSearchVO) {

		String ltrStatus = StringUtil.nonNullTrim(letterReviewQCSearchVO.getLetterReviewSearch().getLtrStatus());

		String userId = sessionHelper.getUserInfo().getUserId();
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String ts = DateUtil.getCurrentDatetimeStamp();

		if (ltrStatus.equals("APPROVED") || ltrStatus.equals("REJECTED") || ltrStatus.equals("HOLD")) {
			eemLetterReviewDao.getLetterReviewQCUpdate(letterReviewQCSearchVO, userId, customerId, ts);
		}

		List<EmCorrMbrVO> mbrLetterVOList = new ArrayList<>();

		List<EmCorrMbrDO> mbrLetterDOList = eemLetterReviewDao
				.getLetterReviewQCSearchResults(letterReviewQCSearchVO.getLetterReviewSearch(), customerId, ts);

		mbrLetterDOList.forEach(mbrLetterSelect -> {
			EmCorrMbrVO mbrLetterVO = new EmCorrMbrVO();

			if (!StringUtil.nonNullTrim(mbrLetterSelect.getLetterUploadedTime()).equals("")) {
				mbrLetterSelect.setLetterAvailabilityInDB("Y");
			} else {
				mbrLetterSelect.setLetterAvailabilityInDB("N");
			}
			BeanUtils.copyProperties(mbrLetterSelect, mbrLetterVO);
			mbrLetterVOList.add(mbrLetterVO);
		});

		return mbrLetterVOList;

	}

	public LetterCacheVO getLetterFormList() {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		LetterCacheVO letterCacheVO = new LetterCacheVO();
		letterCacheVO.setAllLetterList(eemPer.getAllLetterList(customerId));
		return letterCacheVO;
	}

	@SuppressWarnings("unchecked")
	public PageableVO letterReviewSearchPagination(EEMLetterReviewVO letterReviewVO, boolean isPagination) {
		
		PageableVO mbrLetterDetails = letterReviewSearchPage(letterReviewVO,isPagination);
		List<EmCorrMbrDO> mbrLetterDOList = (List<EmCorrMbrDO>) mbrLetterDetails.getContent();
		
		List<EmCorrMbrVO> mbrLetterVOList = new ArrayList<>();
		
		if(! mbrLetterDOList.isEmpty()) {
		mbrLetterDOList.forEach(mbrLetterSelect -> {
			EmCorrMbrVO mbrLetterVO = new EmCorrMbrVO();

			if (!StringUtil.nonNullTrim(mbrLetterSelect.getLetterUploadedTime()).equals("")) {
				mbrLetterSelect.setLetterAvailabilityInDB("Y");
			} else {
				mbrLetterSelect.setLetterAvailabilityInDB("N");
			}

			BeanUtils.copyProperties(mbrLetterSelect, mbrLetterVO);
			mbrLetterVOList.add(mbrLetterVO);
		});}
		
		mbrLetterDetails.setContent(mbrLetterVOList);
		return mbrLetterDetails;
	}

}
