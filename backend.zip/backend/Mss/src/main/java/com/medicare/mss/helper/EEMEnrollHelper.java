package com.medicare.mss.helper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.caching.EEMPersistence;
import com.medicare.mss.caching.EEMProfileSettings;
import com.medicare.mss.constants.EEMProfileConstants;
import com.medicare.mss.domainobject.EMMbrTriggerDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.vo.MbrCacheVO;

@Component
public class EEMEnrollHelper {

	@Autowired
	private EEMPersistence eemPer;

	@Autowired
	private EEMCodeCache codecahe;

	@Autowired
	CacheService sessionHelper;

	@Autowired
	EEMProfileSettings eemProfileSettings;

	public MbrCacheVO setEnrollFormList() throws ApplicationException {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String customerNbr = sessionHelper.getUserInfo().getCustNbr();
		MbrCacheVO mbrCacheVO = new MbrCacheVO();

		initializeEEM(customerId);

		mbrCacheVO.setValidAddressTypes(eemPer.getLstAddrTypes());
		mbrCacheVO.setValidAgentTypes(eemPer.getLstAgentTypes());
		mbrCacheVO.setValidDisenrollmentReasons(eemPer.getLstDisReasonCodes());
		mbrCacheVO.setValidPlanReasons(eemPer.getLstPlanReasonCode(customerId));
		mbrCacheVO.setValidElectionTypes(eemPer.getLstElectionTypes());
		mbrCacheVO.setValidEnrollSources(eemPer.getLstEnrollSrce());
		mbrCacheVO.setValidEnrollStatuses(eemPer.getLstEnrollStatus());
		mbrCacheVO.setValidEnrollReasons(eemPer.getLstEnrollReasonCodes());
		mbrCacheVO.setValidEnrollStatusReasons(eemPer.getLstEnrollStatusReason());
		mbrCacheVO.setValidGenderCodes(eemPer.getLstGender());
		mbrCacheVO.setValidLanguages(eemPer.getLstLanguages());
		mbrCacheVO.setValidAlternateCorrespondenceMethods(eemPer.getLstAltCorrespondences());
		mbrCacheVO.setValidMaritalStatuses(eemPer.getLstMaritalStatus());
		mbrCacheVO.setValidPrefixes(eemPer.getLstPrefix());
		mbrCacheVO.setValidRaceCodes(eemPer.getLstRaceCds());
		mbrCacheVO.setValidRelations(eemPer.getLstRelations());
		mbrCacheVO.setValidSepExceptions(eemPer.getLstSepExceptions());
		mbrCacheVO.setValidStates(eemPer.getLstStates());
		mbrCacheVO.setArrYesNo(codecahe.getArrYesNo());
		mbrCacheVO.setValidDsCodes(eemPer.getLstUserDsCodes());
		mbrCacheVO.setValidMemberStatus(eemPer.getLstMemberStatus());
		mbrCacheVO.setValidLiPercents(eemPer.getLstLiPercents());
		mbrCacheVO.setValidLiCopays(eemPer.getLstLiCopays());
		mbrCacheVO.setValidCountry(eemPer.getLstCountry());
		mbrCacheVO.setValidSEPReasons(eemPer.getLstMbrSEPReasons());
		mbrCacheVO.setValidSubsidySrce(eemPer.getLstSubsidySrce());
		mbrCacheVO.setValidCobTypes(eemPer.getLstCobTypes());
		mbrCacheVO.setValidOhiInd(eemPer.getLstOhiInd());
		mbrCacheVO.setValidAccountType(eemPer.getLstAccountType());
		mbrCacheVO.setValidBillPayMethod(eemPer.getLstBillPayMethod());
		mbrCacheVO.setValidBillFrequency(eemPer.getLstBillFrequency());

		String corrLang = sessionHelper.getAttribute("CORRLANG") == null ? "" : sessionHelper.getAttribute("CORRLANG");
		if ("SPA".equalsIgnoreCase(corrLang))
			mbrCacheVO.setValidLanguages(eemPer.getTsaLstLanguages("SPA"));
		else
			mbrCacheVO.setValidLanguages(eemPer.getLstLanguages());
		String cobType = sessionHelper.getAttribute("COBPRIM") == null ? "" : sessionHelper.getAttribute("COBPRIM");
		if ("PRIM".equalsIgnoreCase(cobType))
			mbrCacheVO.setValidCobTypes(eemPer.getLstTSACobTypes("Primary"));
		else
			mbrCacheVO.setValidCobTypes(eemPer.getLstCobTypes());

		String addrVal = sessionHelper.getAttribute("ADRVAL") == null ? "" : sessionHelper.getAttribute("ADRVAL");
		if ("VALID".equalsIgnoreCase(addrVal))
			mbrCacheVO.setAddValidation("true");

		mbrCacheVO.setValidDrugEditClass(eemPer.getLstDrugEditClass());
		mbrCacheVO.setValidStatus(eemPer.getLstAttestStatus());
		mbrCacheVO.setValidLEPType(eemPer.getLstLEPType());
		mbrCacheVO.setLepNunCmoStstus(eemPer.getLstLepNunCmoStatus());
		mbrCacheVO.setMaxReconTypes(eemPer.getLstMaximusType());
		mbrCacheVO.setRecvdChannel(eemPer.getChannelList());
		mbrCacheVO.setMemberAppeal(eemPer.getMemberAppealList());
		mbrCacheVO.setBrkInCoverageType(eemPer.getBreakInCoverageTypeList());
		mbrCacheVO.setRespType(eemPer.getRespTypeList());
		mbrCacheVO.setPreSetNoteList(codecahe.getPreSetNotesList(customerId));
		mbrCacheVO.setOevCallStatusDrop(eemPer.getLstOevCallStatus(customerId));
		mbrCacheVO.setOevCallSubReasonDrop(codecahe.getLstOevCallSubsetReason(customerId));
		mbrCacheVO.setOoaReasonList(eemPer.getOoaReasonList(customerId));
		mbrCacheVO.setOoaSourceList(eemPer.getOoaSourceList(customerId));
		mbrCacheVO.setOoaDeReasonList(eemPer.getOoaDeReasonsList(customerId));
		mbrCacheVO.setEnrollCancelReasons(codecahe.getLstCancellationReasons(customerId));
		mbrCacheVO.setValidTxnStatus(eemPer.getValidTxnStatus());
		mbrCacheVO.setValidPlanVersions(eemPer.getLstPlanVersions());
		mbrCacheVO.setValidStatuses(eemPer.getLstStatuses());

		mbrCacheVO.setValidPlanId(eemPer.getLstPlanId(customerNbr));

		if (sessionHelper.getAttribute(EEMProfileConstants.LOB_VALD) != null) {
			mbrCacheVO.setLobValidation(sessionHelper.getAttribute(EEMProfileConstants.LOB_VALD).toString());
		}
		return mbrCacheVO;
	}

	public void initializeEEM(String customerId) throws ApplicationException {

		String corrLabel = eemProfileSettings.getCalendarProfileText(customerId, EEMProfileConstants.CORRLANG);
		sessionHelper.setAttribute("CORRLANG", corrLabel);

		String cobType = eemProfileSettings.getCalendarProfileText(customerId, EEMProfileConstants.COBPRIM);
		sessionHelper.setAttribute("COBPRIM", cobType);

		String addrValid = eemProfileSettings.getCalendarProfileText(customerId, EEMProfileConstants.ADRVAL);
		sessionHelper.setAttribute("ADRVAL", addrValid);
	}

	public EMMbrTriggerDO prepareMbrTriggerDO(String memberId, String triggerType, String triggerStatus,
			String triggerCode, String effDateFrmt) {
		String ts = DateUtil.getCurrentDatetimeStamp();
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();

		EMMbrTriggerDO trig = new EMMbrTriggerDO();
		trig.setCustomerId(customerId);
		trig.setMemberId(memberId);
		trig.setTriggerType(triggerType);
		trig.setEffectiveDate(effDateFrmt);
		trig.setTriggerStatus(triggerStatus);
		trig.setTriggerCode(triggerCode);
		trig.setCreateUserId(userId);
		trig.setCreateTime(ts);
		trig.setLastUpdtUserId(userId);
		trig.setLastUpdtTime(ts);
		return trig;
	}
}
