/**
 * 
 */
package com.medicare.mss.domainobject;

import java.util.List;

import lombok.Data;

/**
 * @author dkumar
 *
 */
@Data
public class EEMWfAssignOrTransDO {
	private String customerId;
	private String fromUserId;
	private String toUserId;
	private String reassignTypeCd;
	private List<EEMWFCaseDO> caseList;
	private boolean isManualTransfer;
	private boolean isCaseStateUpdate;
}
