package com.medicare.mss.domainobject;

import java.io.Serializable;

import com.medicare.mss.annotation.ColumnMapper;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.vo.EMDatedSegmentVO;

import lombok.Data;

@Data
public class EMMbrPCPInfoDO implements EMDatedSegmentVO, Cloneable, Serializable{
	
	private static final long serialVersionUID = 6420781862754419945L;
	
	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;
	
	@ColumnMapper(columnName = "MEMBER_ID", propertyName = "memberId")
	private String memberId;
	
	@ColumnMapper(columnName = "PCP_NBR,OFFICE_CD", propertyName = "pcpNbr")
	private String pcpNbr;
	
	@ColumnMapper(columnName = "LOCATION_ID", propertyName = "locationId")
	private String locationId;
	
	@ColumnMapper(columnName = "EFF_START_DATE", propertyName = "effStartDate")
	private String effStartDate;
	
	@ColumnMapper(columnName = "OFFICE_START_DATE", propertyName = "officeStartDate")
	private String officeStartDate;
	
	@ColumnMapper(columnName = "CREATE_TIME", propertyName = "createTime")
	private String createTime;
	
	@ColumnMapper(columnName = "EFF_END_DATE", propertyName = "effEndDate")
	private String effEndDate;
	
	@ColumnMapper(columnName = "OVERRIDE_IND", propertyName = "overrideInd")
	private String overrideInd;
	
	@ColumnMapper(columnName = "CURRENT_PATIENT_IND", propertyName = "currentPatientInd")
	private String currentPatientInd;
	
	@ColumnMapper(columnName = "CREATE_USERID", propertyName = "createUserId")
	private String createUserId;
	
	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;
	
	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserId")
	private String lastUpdtUserId;
	
	@ColumnMapper(columnName = "CLINIC_NAME", propertyName = "clinicName")
	private String clinicName;
	
	@ColumnMapper(columnName = "DOCTOR_NAME", propertyName = "doctorName")
	private String doctorName;
	
	@ColumnMapper(columnName = "DOCTOR_ADDRESS", propertyName = "doctorAddress")
	private String doctorAddress;
	
	@ColumnMapper(columnName = "DOCTOR_CITY", propertyName = "doctorCity")
	private String doctorCity;
	
	@ColumnMapper(columnName = "DOCTOR_STATE", propertyName = "doctorState")
	private String doctorState;
	
	@ColumnMapper(columnName = "DOCTOR_ZIP_CD", propertyName = "doctorZip")
	private String doctorZip;
	
	
	@ColumnMapper(columnName = "ACCEPT_NEW_PATIENT_IND", propertyName = "acceptNewPatient")
	private String acceptNewPatient;
	
	//IFOX-414925 Network ID CR - Start
	@ColumnMapper(columnName = "LINE_OF_BIZ", propertyName = "lineOfBusiness")
	private String lineOfBusiness;
	//IFOX-414925 Network ID CR - End
	/**
	 * pcpStatus holds pcpStatus
	 */
	private String pcpStatus;
	/**
	 * pcpChangeInd holds pcpChangeInd
	 */
	private String pcpChangeInd;
	/**
	 * errorDescription holds errorDescription
	 */
	private String errorDescription;
	/**
	 * pcpChangeSendTime holds pcpChangeSendTime
	 */
	private String pcpChangeSendTime;
	/**
	 * pcpchangeReceiveTime holds pcpchangeReceiveTime
	 */
	private String pcpchangeReceiveTime;
	/**
	 * pcpName holds pcpName
	 */
	private String pcpName;
	
	/*Access health PCP CR- Start*/
	@ColumnMapper(columnName = "ALTERNATE_OFFICE_CD", propertyName = "pcpNpi")
	private String pcpNpi;
	
	/*Access health PCP CR- END*/
	
	//Begin : Added for IFOX-00396582
	private String disEnrollApprvStartDateMinusOne;
	private String officeCategoryCodeColumnInDB = "N";
	private String officeCategoryCode;
	private String currentDateTime;
	
	private String message;
	
	public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
	
	public String getEffEndDateFrmt() {
		return DateFormatter.reFormat(effEndDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}
	
	public void setEffEndDateFrmt(String effEndDate) {
		this.effEndDate = DateFormatter.reFormat(effEndDate,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
	}

	public String getEffStartDateFrmt() {
		return DateFormatter.reFormat(effStartDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}
	
	public void setEffStartDateFrmt(String effStartDate) {
		this.effStartDate = DateFormatter.reFormat(effStartDate,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
	}
	
	public String getFrmtLastUpdtTime() {
		return DateFormatter.reFormat(lastUpdtTime,DateFormatter.DB2_TIMESTAMP,DateFormatter.MM_DD_YYYY_HH_MM_SS);
	}
	
	public String getFrmtCreateTime() {
		return DateFormatter.reFormat(createTime,DateFormatter.DB2_TIMESTAMP,DateFormatter.MM_DD_YYYY_HH_MM_SS);
	}
	
	public boolean isEndDateChange(Object obj) {
		
		EMMbrPCPInfoDO chkVO = (EMMbrPCPInfoDO)obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate))
			if (chkVO.getPcpNbr().equals(this.pcpNbr))
				if (chkVO.getMemberId().equals(this.memberId))
					if (chkVO.getCustomerId().equals(this.customerId))
						if (chkVO.getOverrideInd().equals(this.overrideInd))
							return true;
		return false;
	}

	public boolean isForSamePeriod(Object obj) {
		
		EMMbrPCPInfoDO chkVO = (EMMbrPCPInfoDO)obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate))
			if (chkVO.getEffEndDate().equals(this.effEndDate))
				if (chkVO.getPcpNbr().equals(this.pcpNbr))
					if (chkVO.getMemberId().equals(this.memberId))
						if (chkVO.getCustomerId().equals(this.customerId))
							if (chkVO.getOverrideInd().equals(this.overrideInd))
								return true;
		return false;
	}

	public boolean isSame(Object obj) {
		
		EMMbrPCPInfoDO chkVO = (EMMbrPCPInfoDO)obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate))
			if (chkVO.getEffEndDate().equals(this.effEndDate))
				if (chkVO.getPcpNbr().equals(this.pcpNbr))
					if (chkVO.getMemberId().equals(this.memberId))
						if (chkVO.getCustomerId().equals(this.customerId))
							if (chkVO.getOverrideInd().equals(this.overrideInd))
								if (chkVO.getCreateTime().equals(this.createTime))
									if (chkVO.getCreateUserId().equals(this.createUserId))
										if (chkVO.getLastUpdtTime().equals(this.lastUpdtTime))
											if (chkVO.getLastUpdtUserId().equals(this.lastUpdtUserId))								
												return true;
		return false;
	}
	
	
	

	public String getType() {
		return "PCP";
	}

}
