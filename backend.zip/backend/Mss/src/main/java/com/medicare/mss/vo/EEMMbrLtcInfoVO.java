/**
 * 
 */
package com.medicare.mss.vo;

import java.io.Serializable;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author Wipro Ltd.
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode(callSuper = false)
public class EEMMbrLtcInfoVO extends BaseVO implements EMDatedSegmentVO, Cloneable, Serializable {

	private static final long serialVersionUID = 5299965835822304886L;
	private String assessmentDate;
	private String effEndDate;
	private String effStartDate;
	private String errorDescription;
	private String facilityAddress;
	private String facilityCity;

	private String facilityName;
	private String facilityState;
	private String facilityZipCode;

	private String lengthOfStay;
	private String ltcChangeInd;
	private String ltcchangeReceiveTime;
	private String ltcChangeSendTime;

	private String ltcId;
	private String memberId;
	private String overrideInd;
	private String ppsInd;

	public EEMMbrLtcInfoVO() {
		ppsInd = "N";
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	public String getEffStartDateFrmt() {
		return DateFormatter.reFormat(effStartDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setEffStartDateFrmt(String effStartDate) {
		this.effStartDate = DateFormatter.reFormat(effStartDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getAssessmentDateFrmt() {
		return DateFormatter.reFormat(assessmentDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setAssessmentDateFrmt(String assessmentDate) {
		this.assessmentDate = DateFormatter.reFormat(assessmentDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getEffEndDateFrmt() {
		return DateFormatter.reFormat(effEndDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setEffEndDateFrmt(String effEndDate) {
		this.effEndDate = DateFormatter.reFormat(effEndDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	@Override
	public String getType() {
		return "LTC";
	}

	@Override
	public boolean isEndDateChange(Object obj) {
		EEMMbrLtcInfoVO chkVO = (EEMMbrLtcInfoVO) obj;
		return StringUtils.equals(chkVO.getEffStartDate(), this.effStartDate)
				&& StringUtils.equals(chkVO.getLtcId(), this.ltcId)
				&& StringUtils.equals(chkVO.getMemberId(), this.memberId)
				&& StringUtils.equals(chkVO.getCustomerId(), this.customerId)
				&& StringUtils.equals(chkVO.getOverrideInd(), this.overrideInd);
	}

	@Override
	public boolean isForSamePeriod(Object obj) {
		EEMMbrLtcInfoVO chkVO = (EEMMbrLtcInfoVO) obj;
		return isEndDateChange(obj) && StringUtils.equals(chkVO.getEffEndDate(), this.effEndDate);
	}

	@Override
	public boolean isSame(Object obj) {
		EEMMbrLtcInfoVO chkVO = (EEMMbrLtcInfoVO) obj;
		return isForSamePeriod(obj) && StringUtils.equals(chkVO.getPpsInd(), this.ppsInd)
				&& StringUtils.equals(chkVO.getAssessmentDate(), this.assessmentDate)
				&& chkVO.getLengthOfStay() == this.lengthOfStay
				&& StringUtils.equals(chkVO.getCreateTime(), this.createTime)
				&& StringUtils.equals(chkVO.getCreateUserId(), this.createUserId)
				&& StringUtils.equals(chkVO.getLastUpdtTime(), this.lastUpdtTime)
				&& StringUtils.equals(chkVO.getLastUpdtUserId(), this.lastUpdtUserId);
	}

	public String getPpsInd() {
		if (StringUtils.isNotBlank(this.ppsInd) && StringUtils.equals(this.ppsInd, "1")) {
			this.ppsInd = EEMConstants.VALUE_YES;
		} else {
			this.ppsInd = EEMConstants.VALUE_NO;
		}
		return this.ppsInd;
	}

}
