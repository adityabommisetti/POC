package com.medicare.mss.dao;

import java.util.List;
import java.util.Map;

import com.medicare.mss.domainobject.EEMDashboardAppDistDO;
import com.medicare.mss.domainobject.EEMDashboardApplStatusDO;
import com.medicare.mss.domainobject.EEMDashboardCmsDO;
import com.medicare.mss.domainobject.EEMDashboardFileLoadErrDisDO;
import com.medicare.mss.domainobject.EEMDashboardLisMbrDistDO;
import com.medicare.mss.domainobject.EEMDashboardLtrVolDisDO;
import com.medicare.mss.domainobject.EEMDashboardMbrShipDO;
import com.medicare.mss.domainobject.EEMDashboardSpclStatDisDO;
import com.medicare.mss.vo.EEMDashboardLisMbrDistVO;

public interface EEMDashboardDAO {

	List<EEMDashboardApplStatusDO> getApplStatus(String customerId, String status, Map<String, String> searchParamMap);

	List<EEMDashboardMbrShipDO> mbrShipDistribution(List<String> planIds, String customerId, String customerNbr);

	List<EEMDashboardAppDistDO> appDistribution(List<String> planIds, String customerId, String customerNbr);

	List<EEMDashboardLisMbrDistDO> lisMbrDistribution(EEMDashboardLisMbrDistVO lisDistVo, String customerId,
			String customerNbr);

	List<EEMDashboardLtrVolDisDO> letterVolumeDistribution(String customerId, String todayDate);

	List<EEMDashboardCmsDO> getCmsStatus(String customerId, String status);

	List<EEMDashboardSpclStatDisDO> specialStatusDistribution(String customerId);

	List<EEMDashboardFileLoadErrDisDO> fileLoadErrDist(String customerId, Map<String, String> searchParamMap);

}
