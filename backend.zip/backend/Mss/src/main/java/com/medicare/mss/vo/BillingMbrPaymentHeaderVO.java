package com.medicare.mss.vo;

import java.io.Serializable;

import lombok.Data;

@Data
public class BillingMbrPaymentHeaderVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8268807388827783886L;
	private String customerId;
	private String paySourceType;
	private String paySourceDesc;
	private String batchDate;
	private int batchSeqNbr;
	private String bankAcctCd;
	private String batchBalanceAmt;
	private String detailTotalAmt;
	private String batchBalanceInd;
	private String batchPostedInd;
	private String batchDetailCnt;
	
	private String createTime;
	private String createUserId;
	private String lastUpdtTime;
	private String lastUpdtUserId;
	
	private String itemNumber;
	private String memberId;
	private String posted;

}
