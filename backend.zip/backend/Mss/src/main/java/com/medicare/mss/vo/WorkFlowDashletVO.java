/**
 * 
 */
package com.medicare.mss.vo;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

/**
 * @author DU20098149
 *
 */
@Data
public class WorkFlowDashletVO implements Serializable {

	private static final long serialVersionUID = 3719514186819635146L;
	
	private String status;
	private int count;
	private String type;
	private List<WorkFlowDashletVO> subItems;
	private String queueName;
	boolean hasAccess = true;
	boolean isManualPopup;
}
