package com.medicare.mss.daoImpl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.dao.MemberCommentsDAO;
import com.medicare.mss.domainobject.EEMMbrCommentDO;
import com.medicare.mss.domainobject.EEMMbrTrrDataDO;
import com.medicare.mss.domainobject.EEMMbrTrrLogDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EEMMbrCommentVO;

@Repository
public class MemberCommentsDAOImpl implements MemberCommentsDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	EEMCodeCache eemCodeCache;

	@Override
	public List<EEMMbrCommentDO> getMbrComments(String customerId, String memberId) {

		List<EEMMbrCommentDO> list;
		try {
			StringBuilder squery = new StringBuilder("SELECT CUSTOMER_ID, MEMBER_ID, COMMENT_SEQ_NBR,")
					.append(" MBR_COMMENTS,CREATE_TIME, CREATE_USERID")
					.append(" FROM EM_MBR_COMMENTS WHERE CUSTOMER_ID = ? AND MEMBER_ID = ?")
					.append(" ORDER BY COMMENT_SEQ_NBR DESC");

			Object[] parms = new Object[] { customerId, memberId };

			list = jdbcTemplate.query(squery.toString(), parms,
					new DomainPropertyRowMapper<EEMMbrCommentDO>(EEMMbrCommentDO.class));
		} catch (Exception exp) {
			throw new ApplicationException(exp);
		}
		return list;
	}

	@Override
	public boolean getNextMbrComment(EEMMbrCommentVO mbrCommentsVo) {

		StringBuilder squery = new StringBuilder("SELECT MAX(COMMENT_SEQ_NBR) AS SEQ_NBR,")
				.append(" CURRENT_TIMESTAMP AS CURRENT_TIME FROM EM_MBR_COMMENTS")
				.append(" WHERE CUSTOMER_ID = ? AND MEMBER_ID = ?");

		Object[] parms = new Object[] { mbrCommentsVo.getCustomerId(), mbrCommentsVo.getMemberId() };

		List<EEMMbrCommentVO> list = jdbcTemplate.query(squery.toString(), new RowMapper<EEMMbrCommentVO>() {

			@Override
			public EEMMbrCommentVO mapRow(ResultSet rs, int rowNum) throws SQLException {
				EEMMbrCommentVO emMbrCommentVo = new EEMMbrCommentVO();
				emMbrCommentVo.setCommentSeqNbr(rs.getInt("SEQ_NBR"));
				emMbrCommentVo.setCreateTime(StringUtil.nonNullTrim(rs.getString("CURRENT_TIME")));
				return emMbrCommentVo;
			}
		}, parms);

		EEMMbrCommentVO mbrCommentsVos = list.get(0);
		int seqNo = mbrCommentsVos.getCommentSeqNbr();
		mbrCommentsVo.setCommentSeqNbr(++seqNo);

		return true;
	}

	@Override
	public int addMbrComments(EEMMbrCommentVO mbrCommentsVo) {

		String timeStamp = DateUtil.getCurrentDatetimeStamp();

		StringBuilder squery = new StringBuilder("INSERT INTO EM_MBR_COMMENTS (")
				.append(" CUSTOMER_ID, MEMBER_ID, COMMENT_SEQ_NBR, MBR_COMMENTS, CREATE_TIME,")
				.append(" CREATE_USERID) VALUES(?,?,?,?,?,?)");

		Object[] parms = new Object[] { mbrCommentsVo.getCustomerId(), mbrCommentsVo.getMemberId(),
				mbrCommentsVo.getCommentSeqNbr(), mbrCommentsVo.getMbrComments(), timeStamp,
				mbrCommentsVo.getCreateUserId() };

		return jdbcTemplate.update(squery.toString(), parms);
	}

	@Override
	public List<EEMMbrTrrLogDO> getMbrTrr(String customerId, String memberId) {

		List<EEMMbrTrrLogDO> list;
		try {
			StringBuilder squery = new StringBuilder("SELECT DISTINCT TL.CUSTOMER_ID, TL.MEMBER_ID,")
					.append(" TL.LOG_TIME, TL.PROCESS_DATE, TL.EFFECTIVE_DATE, TL.TRANSACTION_CODE,")
					.append(" TL.TRANS_REPLY_CD, TC.TRANS_REPLY_SDESC, TL.UPDATE_YN, TL.UPDATE_TYPE,")
					.append(" TL.FIELD_NAME, TL.RELATED_FIELD_BEFORE, TL.RELATED_FIELD_AFTER,")
					.append(" TL.SOURCE_ID, TL.ACC_REJ_IND, TL.LAST_UPDT_USERID,TC.TRANS_REPLY_DEFINITION,")
					.append(" CASE WHEN TL.LOG_TIME=TV.LOG_TIME THEN 'TRUE' ELSE 'FALSE' END TRR_VAR_DATA_PRESENT FROM EM_MBR_TRR_LOG TL")
					.append(" LEFT OUTER JOIN CMSTRR_CODE TC ON TC.TRANS_REPLY_CD = TL.TRANS_REPLY_CD")
					.append(" AND TL.PROCESS_DATE BETWEEN TC.EFFECTIVE_START_DT AND TC.EFFECTIVE_END_DATE")
					.append(" LEFT OUTER JOIN EM_MBR_TRR_VARDATA TV ON TL.CUSTOMER_ID = TV.CUSTOMER_ID AND TL.MEMBER_ID = TV.MEMBER_ID")
					.append(" AND TL.LOG_TIME = TV.LOG_TIME WHERE TL.CUSTOMER_ID = ? AND TL.MEMBER_ID = ? ORDER BY TL.LOG_TIME DESC");

			Object[] parms = new Object[] { customerId, memberId };

			list = jdbcTemplate.query(squery.toString(), parms,
					new DomainPropertyRowMapper<EEMMbrTrrLogDO>(EEMMbrTrrLogDO.class));
		} catch (Exception exp) {
			throw new ApplicationException(exp);
		}
		return list;
	}

	@Override
	public List<EEMMbrTrrDataDO> getMbrTrrData(String customerId, String memberId, String logTime) {

		List<EEMMbrTrrDataDO> list;
		try {
			StringBuilder squery = CommonUtils.appendStringsBuilder("SELECT C.TRR_VARIABLE_DESC, A.TRR_VARIABLE_DATA,",
					" B.TRR_VARIABLE_DATA_DESC FROM EM_MBR_TRR_VARDATA A LEFT OUTER JOIN EM_TRR_VARDATA_DESC B",
					" ON A.TRR_VARIABLE_ID = B.TRR_VARIABLE_ID AND A.TRR_VARIABLE_DATA = B.TRR_VARIABLE_DATA",
					" JOIN EM_TRR_VAR_DESC C ON A.TRR_VARIABLE_ID = C.TRR_VARIABLE_ID AND C.CUSTOMER_ID IN ('9999999',?)",
					" WHERE A.CUSTOMER_ID IN ('9999999',?) AND A. MEMBER_ID = ? AND A.LOG_TIME=?");

			Object[] parms = new Object[] { customerId, customerId, memberId, logTime };

			list = jdbcTemplate.query(squery.toString(), parms,
					new DomainPropertyRowMapper<EEMMbrTrrDataDO>(EEMMbrTrrDataDO.class));
		} catch (Exception exp) {
			throw new ApplicationException(exp);
		}
		return list;
	}

}
