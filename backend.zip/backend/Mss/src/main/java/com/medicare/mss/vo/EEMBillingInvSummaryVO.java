/**
 * 
 */
package com.medicare.mss.vo;

import java.io.Serializable;

import com.medicare.mss.util.NumberFormatter;

import lombok.Data;

/**
 * @author DU20098149
 *
 */
@Data
public class EEMBillingInvSummaryVO implements Serializable {
	
	private static final long serialVersionUID = 2807127800341667159L;
	
	private double adjustmentAmt;
	private String firstName;
	private String hicNbr;
	private double invoiceAmt;
	private String lastName;
	private String memberId;
	private String name;
	private double paymentAmt;
	
	public String getInvoiceAmt() {
		return NumberFormatter.formatDecimal2PlacesDelim(invoiceAmt);
	}
	
	public String getAdjustmentAmt() {
		return NumberFormatter.formatDecimal2PlacesDelim(adjustmentAmt);
	}
	public String getPaymentAmt() {
		return NumberFormatter.formatDecimal2PlacesDelim(paymentAmt);
	}
	
	public String getTotalAmt() {
		return NumberFormatter.formatDecimal2PlacesDelim(invoiceAmt + adjustmentAmt + paymentAmt);
	}
	
}
