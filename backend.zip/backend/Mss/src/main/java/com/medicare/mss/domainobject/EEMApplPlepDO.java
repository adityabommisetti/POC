package com.medicare.mss.domainobject;

import lombok.Data;

@Data	
public class EEMApplPlepDO {
	private String customerId;
	private int applicationId;
	private String lepEffDate;
	private String uncovMthStDt;
	private String uncovMthEndDt;
	private int plepMonths;
	private String overRideInd;
	private String createTime;
	private String createUserId;
	private String lastUpdtTime;
	private String lastUpdtUserId;
	private int ptnlepUnCovMnths;
	private String tuncovMthStDt;
	private String tuncovMthEndDt;
	private String showAllPtnl;
	private String txtUncovMthStDt;
	private String txtUncovMthEndDt;
	private int totalPlepCount;
	private String totalPlepMonths;

}
