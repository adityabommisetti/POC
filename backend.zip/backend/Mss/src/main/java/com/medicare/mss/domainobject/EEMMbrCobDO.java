package com.medicare.mss.domainobject;

import org.apache.commons.lang3.StringUtils;

import com.medicare.mss.annotation.ColumnMapper;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.vo.EMDatedSegmentVO;

import lombok.Data;

@Data
public class EEMMbrCobDO implements EMDatedSegmentVO, Cloneable {

	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;

	@ColumnMapper(columnName = "MEMBER_ID", propertyName = "memberId")
	private String memberId;

	@ColumnMapper(columnName = "COB_TYPE", propertyName = "cobType")
	private String cobType;

	@ColumnMapper(columnName = "OHI_IND", propertyName = "ohiInd")
	private String ohiInd;

	@ColumnMapper(columnName = "RX_GRP", propertyName = "rxGrp")
	private String rxGrp;

	@ColumnMapper(columnName = "RX_NAME", propertyName = "rxName")
	private String rxName;

	@ColumnMapper(columnName = "RX_ID", propertyName = "rxId")
	private String rxId;

	@ColumnMapper(columnName = "RX_BIN", propertyName = "rxBin")
	private String rxBin;

	@ColumnMapper(columnName = "RX_PCN", propertyName = "rxPcn")
	private String rxPcn;

	@ColumnMapper(columnName = "OVERRIDE_IND", propertyName = "overrideInd")
	private String overrideInd;

	@ColumnMapper(columnName = "EFF_START_DATE", propertyName = "effStartDate")
	private String effStartDate;

	@ColumnMapper(columnName = "EFF_END_DATE", propertyName = "effEndDate")
	private String effEndDate;

	@ColumnMapper(columnName = "CREATE_TIME", propertyName = "createTime")
	private String createTime;

	@ColumnMapper(columnName = "CREATE_USERID", propertyName = "createUserId")
	private String createUserId;

	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;

	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserId")
	private String lastUpdtUserId;

	private String cobDesc;
	private String ohiDesc;
	private String cobValidation;

	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	public String getEffEndDateFrmt() {
		return DateFormatter.reFormat(effEndDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setEffEndDateFrmt(String effEndDate) {
		this.effEndDate = DateFormatter.reFormat(effEndDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getEffStartDateFrmt() {
		return DateFormatter.reFormat(effStartDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setEffStartDateFrmt(String effStartDate) {
		this.effStartDate = DateFormatter.reFormat(effStartDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getType() {
		return cobType;
	}

	public boolean isSameCobType(Object obj) {

		EEMMbrCobDO chkVO = (EEMMbrCobDO) obj;

		return StringUtils.equals(chkVO.getEffStartDate(), this.effStartDate)
				&& StringUtils.equals(chkVO.getMemberId(), this.memberId)
				&& StringUtils.equals(chkVO.getCustomerId(), this.customerId);
	}

	public boolean isEndDateChange(Object obj) {

		EEMMbrCobDO chkVO = (EEMMbrCobDO) obj;

		return StringUtils.equals(chkVO.getEffStartDate(), this.effStartDate)
				&& StringUtils.equals(chkVO.getCobType(), this.cobType)
				&& StringUtils.equals(chkVO.getOhiInd(), this.ohiInd)
				&& StringUtils.equals(chkVO.getRxGrp(), this.rxGrp)
				&& StringUtils.equals(chkVO.getRxName(), this.rxName) && StringUtils.equals(chkVO.getRxId(), this.rxId)
				&& StringUtils.equals(chkVO.getRxBin(), this.rxBin) && StringUtils.equals(chkVO.getRxPcn(), this.rxPcn)
				&& StringUtils.equals(chkVO.getMemberId(), this.memberId)
				&& StringUtils.equals(chkVO.getCustomerId(), this.customerId)
				&& StringUtils.equals(chkVO.getOverrideInd(), this.overrideInd);
	}

	public boolean isForSamePeriod(Object obj) {

		EEMMbrCobDO chkVO = (EEMMbrCobDO) obj;

		return StringUtils.equals(chkVO.getCobType(), this.cobType)
				&& StringUtils.equals(chkVO.getEffStartDate(), this.effStartDate)
				&& StringUtils.equals(chkVO.getEffEndDate(), this.effEndDate)
				&& StringUtils.equals(chkVO.getMemberId(), this.memberId)
				&& StringUtils.equals(chkVO.getCustomerId(), this.customerId)
				&& StringUtils.equals(chkVO.getOverrideInd(), this.overrideInd);
	}

	public boolean isSame(Object obj) {

		EEMMbrCobDO chkVO = (EEMMbrCobDO) obj;

		return StringUtils.equals(chkVO.getCobType(), this.cobType)
				&& StringUtils.equals(chkVO.getOhiInd(), this.ohiInd)
				&& StringUtils.equals(chkVO.getRxGrp(), this.rxGrp)
				&& StringUtils.equals(chkVO.getRxName(), this.rxName) && StringUtils.equals(chkVO.getRxId(), this.rxId)
				&& StringUtils.equals(chkVO.getRxBin(), this.rxBin) && StringUtils.equals(chkVO.getRxPcn(), this.rxPcn)
				&& StringUtils.equals(chkVO.getEffStartDate(), this.effStartDate)
				&& StringUtils.equals(chkVO.getEffEndDate(), this.effEndDate)
				&& StringUtils.equals(chkVO.getMemberId(), this.memberId)
				&& StringUtils.equals(chkVO.getCustomerId(), this.customerId)
				&& StringUtils.equals(chkVO.getOverrideInd(), this.overrideInd)
				&& StringUtils.equals(chkVO.getCreateUserId(), this.createTime)
				&& StringUtils.equals(chkVO.getCreateUserId(), this.createUserId)
				&& StringUtils.equals(chkVO.getLastUpdtTime(), this.lastUpdtTime)
				&& StringUtils.equals(chkVO.getLastUpdtUserId(), this.lastUpdtUserId);
	}

}
