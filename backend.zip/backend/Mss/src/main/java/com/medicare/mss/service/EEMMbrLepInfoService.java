/**
 * 
 */
package com.medicare.mss.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMApplLepDAO;
import com.medicare.mss.dao.EEMLepDAO;
import com.medicare.mss.dao.EEMMbrDAO;
import com.medicare.mss.domainobject.EEMLepAttestCcfDO;
import com.medicare.mss.domainobject.EEMLepAttestInfoDO;
import com.medicare.mss.domainobject.EEMLepPtnlUncovMthsDO;
import com.medicare.mss.domainobject.EEMLepSummaryDO;
import com.medicare.mss.domainobject.EEMMbrLepInfoDO;
import com.medicare.mss.domainobject.EMMbrTriggerDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.EEMContext;
import com.medicare.mss.helper.EEMEnrollHelper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EEMApplLepMasterVO;
import com.medicare.mss.vo.EEMLepAttestCallMasterVO;
import com.medicare.mss.vo.EEMLepAttestCcfVO;
import com.medicare.mss.vo.EEMLepAttestInfoVO;
import com.medicare.mss.vo.EEMLepPtnlUncovMthsVO;
import com.medicare.mss.vo.EEMLepSummaryVO;
import com.medicare.mss.vo.EEMMbrDemographicVO;
import com.medicare.mss.vo.EEMMbrDsInfoVO;
import com.medicare.mss.vo.EEMMbrEnrollmentVO;
import com.medicare.mss.vo.EEMMbrLepInfoVO;
import com.medicare.mss.vo.EEMMbrMasterVO;
import com.medicare.mss.vo.EMDatedSegmentVO;
import com.medicare.mss.vo.MBDNunCmoVO;

/**
 * @author DU20098149
 *
 */
@Service
@Transactional(rollbackFor = ApplicationException.class)
public class EEMMbrLepInfoService extends EEMMbrBaseService {

	@Autowired
	private EEMLepDAO eemLepDAO;

	@Autowired
	private EEMApplLepDAO lepDao;

	@Autowired
	private EEMMbrDAO eemMbrDAO;

	@Autowired
	private EEMApplLepService applLepService;

	@Autowired
	private EEMEnrollHelper eemEnrollHelper;

	@Autowired
	private EEMLepMaximusService eemLepService;

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public List<EEMMbrLepInfoVO> getMbrLepInfos(String memberId, String showAll) throws ApplicationException {

		List<EEMMbrLepInfoVO> mbrLepInfoVOList = new ArrayList<>();
		if (Objects.nonNull(sessionHelper.getEEMContext())
				&& Objects.nonNull(sessionHelper.getEEMContext().getMbrMasterVO())
				&& Objects.nonNull(sessionHelper.getEEMContext().getMbrMasterVO().getEemLepMasterVO())) {
			mbrLepInfoVOList = sessionHelper.getEEMContext().getMbrMasterVO().getEemLepMasterVO().getEemMbrLepInfoVOs();
		}

		if (StringUtils.equals(EEMConstants.VALUE_YES, showAll)) {
			List<EEMMbrLepInfoVO> allInfos = getMbrLepInfoListFromDB(memberId, showAll);
				mbrLepInfoVOList = (List<EEMMbrLepInfoVO>) getActiveDatedList(allInfos);
				setToContext(mbrLepInfoVOList);
			return allInfos;
		} else {
			if (Objects.isNull(mbrLepInfoVOList)) {
				mbrLepInfoVOList = getMbrLepInfoListFromDB(memberId, showAll);
				setToContext(mbrLepInfoVOList);
			} else {
				mbrLepInfoVOList = (List<EEMMbrLepInfoVO>) getActiveDatedList(mbrLepInfoVOList);
				setToContext(mbrLepInfoVOList);
			}
			return mbrLepInfoVOList;
		}
	}

	public boolean mbrLepInfoDelete(EEMMbrLepInfoVO delVO) throws ApplicationException {
		String userId = sessionHelper.getUserInfo().getUserId();
		int sqlCnt = eemLepDAO.setOverride(delVO, userId);
		return sqlCnt == 1;
	}

	@SuppressWarnings("unchecked")
	public boolean mbrLepInfoUpdate(EEMMbrLepInfoVO newVO, boolean isOnlineUpdate) throws ApplicationException {

		String userId = sessionHelper.getUserInfo().getUserId();
		String custId = sessionHelper.getUserInfo().getCustomerId();

		newVO.setOverrideInd(EEMConstants.VALUE_NO);
		newVO.setCustomerId(custId);
		Map<String, String> type = new HashMap<>();
		int sqlCnt = 0;
		try {
			String msg = checkDates(newVO);
			if (Objects.nonNull(msg)) {
				newVO.setMessage(msg);
				throw new ApplicationException(msg);
			}

			String maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
					EEMConstants.EM_MBR_LEP, type);
			List<EEMMbrLepInfoVO> mbrLepInfoVOList = getMbrLepInfos(newVO.getMemberId(), EEMConstants.VALUE_YES);

			List<? extends EMDatedSegmentVO> activeMbrLepInfoLst = getActiveDatedList(mbrLepInfoVOList);
			if (hasDataChanged(activeMbrLepInfoLst, maxLastUpdate)) {
				throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
			}

			EEMMbrLepInfoVO matchVO = null;
			if (isOnlineUpdate) {
				int rslt = lepTriggerCheck(matchVO, newVO, userId);
				if (rslt > 0) {
					throw new ApplicationException(newVO.getMessage());
				}
			}

			matchVO = (EEMMbrLepInfoVO) matchDatedSegment(activeMbrLepInfoLst, newVO);
			String ts = DateUtil.getCurrentDatetimeStamp();

			if (Objects.nonNull(matchVO)) {

				sqlCnt = eemLepDAO.setOverride(matchVO, userId);
				if (sqlCnt != 1) {
					throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT);
				}

				sqlCnt = addNewSegment(newVO, userId, ts);
				if (sqlCnt != 1) {
					throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
				}

				maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
						EEMConstants.EM_MBR_LEP, type);
				if (hasDataChanged(ts, maxLastUpdate)) {
					throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
				}

				List<EEMMbrLepInfoVO> updatedMbrLepInfoVOList = getMbrLepInfoListFromDB(newVO.getMemberId(),
						newVO.getShowAll());
				if (StringUtils.equals(EEMConstants.VALUE_NO, newVO.getShowAll())) {
					setToContext(updatedMbrLepInfoVOList);
				} else {
					List<EEMMbrLepInfoVO> mbrLepInfoActiveVOList = (List<EEMMbrLepInfoVO>) getActiveDatedList(updatedMbrLepInfoVOList);
					setToContext(mbrLepInfoActiveVOList);
				}
				return true;
			}

			matchVO = (EEMMbrLepInfoVO) matchDatedSegmentEndDate(activeMbrLepInfoLst, newVO);
			if (Objects.nonNull(matchVO)) {
				sqlCnt = eemLepDAO.setOverride(matchVO, userId);
				if (sqlCnt != 1) {
					throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT);
				}
				sqlCnt = addNewSegment(newVO, userId, ts);
				if (sqlCnt != 1) {
					throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
				}

				maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
						EEMConstants.EM_MBR_LEP, type);
				if (hasDataChanged(ts, maxLastUpdate)) {
					throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
				}

				List<EEMMbrLepInfoVO> updatedMbrLepInfoVOList = getMbrLepInfoListFromDB(newVO.getMemberId(),
						newVO.getShowAll());
				if (StringUtils.equals(EEMConstants.VALUE_NO, newVO.getShowAll())) {
					setToContext(updatedMbrLepInfoVOList);
				} else {
					List<EEMMbrLepInfoVO> mbrLepInfoActiveVOList = (List<EEMMbrLepInfoVO>) getActiveDatedList(updatedMbrLepInfoVOList);
					setToContext(mbrLepInfoActiveVOList);
				}
				return true;
			}

			if (newVO.getEffEndDate().equals(EEMConstants.EFF_END_DATE)) {
				List<? extends EMDatedSegmentVO> lstSegmentsAbove = getSegmentsAbove(activeMbrLepInfoLst,
						newVO.getEffStartDate());
				Iterator<? extends EMDatedSegmentVO> it = lstSegmentsAbove.iterator();

				while (it.hasNext()) {

					EEMMbrLepInfoVO itemVO = (EEMMbrLepInfoVO) it.next();
					sqlCnt = eemLepDAO.setOverride(itemVO, userId);

					if (sqlCnt != 1) {
						throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_ABOVE);
					}
				}

				EEMMbrLepInfoVO belowVO = (EEMMbrLepInfoVO) getFirstOverlapSegmentBelow(activeMbrLepInfoLst,
						newVO.getEffStartDate());
				if (Objects.nonNull(belowVO)) {

					sqlCnt = eemLepDAO.setOverride(belowVO, userId);

					if (sqlCnt != 1) {
						throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_BELOW);
					}

					if (belowVO.getEffStartDate().compareTo(newVO.getEffStartDate()) < 0) {
						EEMMbrLepInfoVO tempVO = (EEMMbrLepInfoVO) belowVO.clone();
						tempVO.setEffEndDate(DateMath.minusOneDay(newVO.getEffStartDate()));

						sqlCnt = addNewSegment(tempVO, userId, ts);

						if (sqlCnt != 1) {
							throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_BELOW);
						}
					}
				}

				sqlCnt = addNewSegment(newVO, userId, ts);

				if (sqlCnt != 1) {
					throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
				}

				maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
						EEMConstants.EM_MBR_LEP, type);
				if (hasDataChanged(ts, maxLastUpdate)) {
					throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
				}

				List<EEMMbrLepInfoVO> updatedMbrLepInfoVOList = getMbrLepInfoListFromDB(newVO.getMemberId(),
						newVO.getShowAll());
				if (StringUtils.equals(EEMConstants.VALUE_NO, newVO.getShowAll())) {
					setToContext(updatedMbrLepInfoVOList);
				} else {
					List<EEMMbrLepInfoVO> mbrLepInfoActiveVOList = (List<EEMMbrLepInfoVO>) getActiveDatedList(updatedMbrLepInfoVOList);
					setToContext(mbrLepInfoActiveVOList);
				}
				return true;
			}

			// end dated segment
			if (!doDatedSegmentAdjust(activeMbrLepInfoLst, newVO, ts, userId, eemLepDAO)) {
				return false;
			}

			// add the new segment
			sqlCnt = addNewSegment(newVO, userId, ts);

			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
			}

			maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
					EEMConstants.EM_MBR_LEP, type);
			if (hasDataChanged(ts, maxLastUpdate)) {
				throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
			}

			List<EEMMbrLepInfoVO> updatedMbrLepInfoVOList = getMbrLepInfoListFromDB(newVO.getMemberId(),
					newVO.getShowAll());
			if (StringUtils.equals(EEMConstants.VALUE_NO, newVO.getShowAll())) {
				setToContext(updatedMbrLepInfoVOList);
			} else {
				List<EEMMbrLepInfoVO> mbrLepInfoActiveVOList = (List<EEMMbrLepInfoVO>) getActiveDatedList(updatedMbrLepInfoVOList);
				setToContext(mbrLepInfoActiveVOList);
			}
			return true;

		} catch (Exception exp) {
			throw new ApplicationException(exp);
		}

	}

	private int addNewSegment(EEMMbrLepInfoVO newVO, String userId, String ts) throws ApplicationException {

		buildEEMMbrLepInfoVO(newVO, userId, ts);

		int sqlCnt = eemLepDAO.insertMbr(newVO);
		return sqlCnt;
	}

	private void buildEEMMbrLepInfoVO(EEMMbrLepInfoVO newVO, String userId, String ts) {
		newVO.setCreateTime(ts);
		newVO.setCreateUserId(userId);
		newVO.setLastUpdtTime(ts);
		newVO.setLastUpdtUserId(userId);
	}

	private void setToContext(List<EEMMbrLepInfoVO> mbrLepInfoVOList) {
		EEMContext context = sessionHelper.getEEMContext();
		if (Objects.nonNull(context) && Objects.nonNull(context.getMbrMasterVO())
				&& Objects.nonNull(context.getMbrMasterVO().getEemLepMasterVO())) {
			context.getMbrMasterVO().getEemLepMasterVO().setEemMbrLepInfoVOs(mbrLepInfoVOList);
		}
		sessionHelper.setEEMContext(context);
	}

	private List<EEMMbrLepInfoVO> getMbrLepInfoListFromDB(String mbrId, String showAll) throws ApplicationException {
		String custId = sessionHelper.getUserInfo().getCustomerId();

		List<EEMMbrLepInfoDO> mbrLepInfoDOList = eemLepDAO.getMbrLepInfos(custId, mbrId, showAll);
		List<EEMMbrLepInfoVO> mbrLepInfoVOList = new ArrayList<>();
		CommonUtils.copyList(mbrLepInfoDOList, mbrLepInfoVOList, EEMMbrLepInfoVO.class);

		return mbrLepInfoVOList;
	}

	@SuppressWarnings("unchecked")
	public EEMApplLepMasterVO getMbrLepInfo(String mbrId, String showAll) throws ApplicationException {
		EEMContext context = sessionHelper.getEEMContext();
		EEMMbrEnrollmentVO eemMbrEnrollmentVO = null;
		String mbi = EEMConstants.BLANK;
		String hicNumber = EEMConstants.BLANK;
		String custId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();

		EEMApplLepMasterVO masterVO = new EEMApplLepMasterVO();
		masterVO.setCustomerId(custId);
		masterVO.setPrimaryId(mbrId);
		masterVO.setOperatorId(userId);

		List<EEMMbrLepInfoVO> mbrLepInfoVOList = new ArrayList<>();
		List<EEMMbrLepInfoDO> mbrLepInfoDOList = eemLepDAO.getMbrLepInfos(custId, mbrId, showAll);
		List<EEMMbrDsInfoVO> mbrDsInfoList = context.getMbrMasterVO().getMbrDsInfoList();
		if (CommonUtils.isNotEmpty(mbrDsInfoList)) {
			mbrDsInfoList = (List<EEMMbrDsInfoVO>) getActiveDatedList(mbrDsInfoList);
		}
		for(EEMMbrDsInfoVO mbrDsInfo : mbrDsInfoList) {
			if(StringUtils.equalsIgnoreCase(mbrDsInfo.getDsCd(), EEMConstants.MBI)) {
				mbi = mbrDsInfo.getDsValue();
			}
			
			if(StringUtils.equalsIgnoreCase(mbrDsInfo.getDsCd(), EEMConstants.MED)) {
				hicNumber = mbrDsInfo.getDsValue();
			}
		}

		EEMMbrDemographicVO mbrDemographicVO = context.getMbrMasterVO().getMbrDemographicVO();

		List<EEMMbrEnrollmentVO> mbrEnrollmentList = context.getMbrMasterVO().getMbrEnrollmentList();
		if (CommonUtils.isNotEmpty(mbrEnrollmentList)) {
			mbrEnrollmentList = (List<EEMMbrEnrollmentVO>) getActiveDatedList(mbrEnrollmentList);
		}
		List<EEMMbrEnrollmentVO> filteredList = mbrEnrollmentList.stream().filter(
				enrollVO -> StringUtils.equalsIgnoreCase(enrollVO.getEnrollStatus(), EEMConstants.MBR_STAT_EAPRV)
						|| StringUtils.equalsIgnoreCase(enrollVO.getEnrollStatus(), EEMConstants.MBR_STAT_EPEND))
				.collect(Collectors.toList());
		List<EEMMbrEnrollmentVO> sortedList = filteredList.stream()
				.sorted(Comparator.comparing(EEMMbrEnrollmentVO::getEffStartDate).reversed())
				.collect(Collectors.toList());

		if (!CollectionUtils.isEmpty(sortedList)) {
			eemMbrEnrollmentVO = sortedList.get(0);
		}

		if (Objects.nonNull(mbrDemographicVO) && Objects.nonNull(eemMbrEnrollmentVO)) {
			for (EEMMbrLepInfoDO eemMbrLepInfoDO : mbrLepInfoDOList) {
				if (StringUtils.isNotBlank(mbi)) {
					eemMbrLepInfoDO.setHicNBRVal(StringUtils.trimToEmpty(mbi));
				} else {
					eemMbrLepInfoDO.setHicNBRVal(StringUtils.trimToEmpty(hicNumber));
				}

				eemMbrLepInfoDO.setMaOnly(eemMbrEnrollmentVO.getPlanDesignation());
				eemMbrLepInfoDO.setEnrollEffStartDate(eemMbrEnrollmentVO.getEffStartDate());
				eemMbrLepInfoDO.setTempEnrollEffStartDate(eemMbrEnrollmentVO.getEffStartDate());

				if (StringUtils.equalsIgnoreCase(eemMbrLepInfoDO.getMaOnly(), "MAPD")
						|| StringUtils.equalsIgnoreCase(eemMbrLepInfoDO.getMaOnly(), "PDP")) {
					eemMbrLepInfoDO.setMaValue(EEMConstants.NO);
				} else {
					eemMbrLepInfoDO.setMaValue(EEMConstants.YES);
				}

				eemMbrLepInfoDO.setHicn(StringUtils.trimToEmpty(hicNumber));
				eemMbrLepInfoDO.setMbi(StringUtils.trimToEmpty(mbi));
				eemMbrLepInfoDO.setBirthDate(mbrDemographicVO.getBirthDate());
				eemMbrLepInfoDO.setFirstName(mbrDemographicVO.getFirstName());
				eemMbrLepInfoDO.setPlanId(eemMbrEnrollmentVO.getPlanId());
				eemMbrLepInfoDO.setPlanDesignation(eemMbrEnrollmentVO.getPlanDesignation());
				eemMbrLepInfoDO.setPbpId(eemMbrEnrollmentVO.getPbpId());
			}
		}

		CommonUtils.copyList(mbrLepInfoDOList, mbrLepInfoVOList, EEMMbrLepInfoVO.class);
		masterVO.setEemMbrLepInfoVOs(mbrLepInfoVOList);

		EEMLepSummaryDO lepSummaryDO = lepDao.getApplLepSummaryInfo(hicNumber, mbi);
		EEMLepSummaryVO lepSummaryVO = new EEMLepSummaryVO();
		List<MBDNunCmoVO> nunCmoVOList = new ArrayList<>();
		BeanUtils.copyProperties(lepSummaryDO, lepSummaryVO, "nunCMOList");
		CommonUtils.copyList(lepSummaryDO.getNunCMOList(), nunCmoVOList, MBDNunCmoVO.class);
		lepSummaryVO.setNunCMOList(nunCmoVOList);
		masterVO.setLepSummaryVO(lepSummaryVO);

		// Potential -Start
		List<EEMLepPtnlUncovMthsDO> potentialDOs = lepDao.getPotentialUnCovMonth(custId, mbrId, EEMConstants.VALUE_NO,
				true);

		Integer totalPlepMonths = potentialDOs.stream().filter(x -> EEMConstants.VALUE_NO.equals(x.getOverRideInd()))
				.mapToInt(EEMLepPtnlUncovMthsDO::getPlepMonths).sum();

		List<EEMLepPtnlUncovMthsVO> potentialList = new ArrayList<>();

		CommonUtils.copyList(potentialDOs, potentialList, EEMLepPtnlUncovMthsVO.class);
		masterVO.setTotalPlepMonths(String.valueOf(totalPlepMonths));
		masterVO.setPotentialUnCovMthsList(potentialList);

		// Potential -END

		// ATTESTATION -START
		EEMLepAttestInfoDO attestDO = new EEMLepAttestInfoDO();
		attestDO.setCustomerId(custId);
		attestDO.setPrimaryId(mbrId);

		lepDao.getApplLepAttnDetails(custId, mbrId, attestDO, true);
		lepDao.checkLepLetters(custId, mbrId, attestDO, true);
		// setLetterPotUnCovMonths = need to check VARIABLE_ID,VARIABLE_DATA FROM
		// EM_CORR_VAR_DATA WHERE

		String planId = EEMConstants.BLANK;
		String pbpId = EEMConstants.BLANK;

		if (null != mbrEnrollmentList) {
			EEMMbrEnrollmentVO enrollVO = mbrEnrollmentList.get(0);

			if (Objects.nonNull(enrollVO)) {
				planId = enrollVO.getPlanId();
				pbpId = enrollVO.getPbpId();
			}
		}

		lepDao.getTriggerDataForLEPAttestion(attestDO);

		List<EEMLepAttestCcfDO> lepAttestDoList = lepDao.getApplCcfResp(custId, mbrId, EEMConstants.VALUE_NO, true);

		if ("Y".equals(attestDO.getPdf_archival()) || (!StringUtil.nonNullTrim(attestDO.getLetterName()).isEmpty()
				&& !"Y".equals(StringUtil.nonNullTrim(attestDO.getPdf_archival()))
				&& !attestDO.getLastUpdtTime().isEmpty())) {
			lepDao.checkAvailabilityOfLetters(custId, mbrId, attestDO);
		}
		else {
			attestDO.setLetterAvailabilityInDB(EEMConstants.VALUE_NO);
		}

		lepDao.getMbrLepAttest90DaysDetails(attestDO);

		EMMbrTriggerDO triggerDO = new EMMbrTriggerDO();
		triggerDO.setMemberId(mbrId);
		triggerDO.setCustomerId(custId);
		triggerDO.setTriggerCode(EEMConstants.TRIG_CODE_OBC3);
		triggerDO.setTriggerStatus(EEMConstants.TRIG_STATUS_EXPIRED);
		triggerDO.setPlanId(planId);
		triggerDO.setPbpId(pbpId);

		boolean isTriggerExist = lepDao.checkMbrTimmerStatus(triggerDO);

		if (isTriggerExist) {
			attestDO.setEnableAttestAfter90DaysSection(true);
		} else {
			attestDO.setEnableAttestAfter90DaysSection(false);
		}

		EEMLepAttestInfoVO applLepAttestInfosVO = new EEMLepAttestInfoVO();
		List<EEMLepAttestCcfVO> lepAttestList = new ArrayList<>();

		CommonUtils.copyList(lepAttestDoList, lepAttestList, EEMLepAttestCcfVO.class);
		BeanUtils.copyProperties(attestDO, applLepAttestInfosVO);

		applLepAttestInfosVO.setLepAttestList(lepAttestList);
		masterVO.setLepAttestInfoVO(applLepAttestInfosVO);

		// ATTESTATION -END

		// ATTESTATION CALL -START
		EEMLepAttestCallMasterVO attestCallVO = applLepService.setAttestationCalls(custId, mbrId, masterVO, true);

		masterVO.setAttestCallMasterVO(attestCallVO);

		// ATTESTATION -END

		// MAXIMUS -START
		masterVO.setEemlepMaximusVO(eemLepService.getLepMaximusDetails(custId, mbrId));
		// MAXIMUS -END
		setMBRLEPTimers(masterVO.getAttestCallMasterVO());

		context.getMbrMasterVO().setEemLepMasterVO(masterVO);
		sessionHelper.setEEMContext(context);
		return masterVO;
	}

	public void setMBRLEPTimers(EEMLepAttestCallMasterVO lepInfoVo) throws ApplicationException {

		Map<String, String> availableTriggers = lepDao.getApplTrigger(lepInfoVo.getCustomerId(),
				lepInfoVo.getPrimaryId(), true, EEMConstants.TRIG_TYPE_FOLLOWUP_APPL);

		String result = getTimerCheck(availableTriggers, EEMConstants.TRIG_CODE_LE21);
		lepInfoVo.setLe21TimerCheck(result);

		result = getTimerCheck(availableTriggers, EEMConstants.TRIG_CODE_OBC1);
		lepInfoVo.setObc1TimerCheck(result);

		result = getTimerCheck(availableTriggers, EEMConstants.TRIG_CODE_OBC2);
		lepInfoVo.setObc2TimerCheck(result);

		result = getTimerCheck(availableTriggers, EEMConstants.TRIG_CODE_OBC3);
		lepInfoVo.setObc3TimerCheck(result);

	}

	private String getTimerCheck(Map<String, String> availableTriggers, String triggerName) {
		String result = "false";
		if (availableTriggers.containsKey(triggerName)) {
			if (availableTriggers.get(triggerName).equals(EEMConstants.TRIG_STATUS_OPEN)) {
				result = "true"; // LE21 timer open
			} else {
				result = "closed";// LE21 timer closed
			}

		}
		return result;
	}

	public int lepTriggerCheck(EEMMbrLepInfoVO oldVO, EEMMbrLepInfoVO newVO, String userId)
			throws ApplicationException {

		if (!StringUtils.equals(EEMConstants.EFF_END_DATE, newVO.getEffEndDate()))
			return -1;

		if (Objects.isNull(oldVO)) {
			if (StringUtils.equals(EEMConstants.VALUE_YES, newVO.getCreditableCoverageFlag())
					&& newVO.getNbrUncovMonths() == 0) {
				return -1;
			}
		} else {
			if (oldVO.getCreditableCoverageFlag().equals(newVO.getCreditableCoverageFlag())
					&& oldVO.getNbrUncovMonths() == newVO.getNbrUncovMonths()
					&& DateMath.isGreaterThanOrEqual(newVO.getEffStartDate(), oldVO.getEffStartDate())
					&& StringUtils.equals(EEMConstants.EFF_END_DATE, oldVO.getEffEndDate())) {
				return -1;

			}
		}

		EEMMbrMasterVO masterVO = sessionHelper.getEEMContext().getMbrMasterVO();
		EEMMbrEnrollmentVO mbrEnrlVO = (EEMMbrEnrollmentVO) getSegmentActiveOn(masterVO.getMbrEnrollmentList(),
				newVO.getEffStartDate());

		if (!Optional.ofNullable(mbrEnrlVO).isPresent()) {
			newVO.setMessage("Update LEP got failed due to no active enrollment available for the given effective date!");
			return 1;
		}

		EMMbrTriggerDO trig = eemEnrollHelper.prepareMbrTriggerDO(newVO.getMemberId(), EEMConstants.TRIG_TYPE_TXN, "",
				EEMConstants.TRIG_CODE_73, newVO.getEffStartDate());
		trig.setPlanId(mbrEnrlVO.getPlanId());
		trig.setPbpId(mbrEnrlVO.getPbpId());
		trig.setPlanDesignation(mbrEnrlVO.getPlanDesignation());

		if (newVO.getEditOverrideInd() != null && newVO.getEditOverrideInd().equals(EEMConstants.VALUE_YES)) {
			trig.setTriggerStatus(EEMConstants.TRIG_STATUS_CLOSED);
			trig.setProcessSource(EEMConstants.TRIG_PROCESS_SOURCE_WEBENRSP);
		} else {
			trig.setTriggerStatus(EEMConstants.TRIG_STATUS_OPEN);
			trig.setProcessSource(EEMConstants.TRIG_PROCESS_SOURCE_WEBENRL);
		}
		int sqlCnt = eemMbrDAO.insertMbrTrigger(trig);
		if (sqlCnt != 1) {
			newVO.setMessage("Error Creating CMS Transaction (73) Trigger");
			return 1;
		}

		return 0;
	}

}
