package com.medicare.mss.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.caching.EEMProfileSettings;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.EEMProfileConstants;
import com.medicare.mss.dao.EEMApplDAO;
import com.medicare.mss.dao.EEMMbrDAO;
import com.medicare.mss.dao.EEMMbrErrorDAO;
import com.medicare.mss.dao.EEMMbrPCPDAO;
import com.medicare.mss.domainobject.EEMProfileItemDO;
import com.medicare.mss.domainobject.EMMbrPCPInfoDO;
import com.medicare.mss.domainobject.EMPcpSearchDO;
import com.medicare.mss.domainobject.EmMbrErrorDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.EEMContext;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EEMFieldErrorVO;
import com.medicare.mss.vo.EEMMbrEnrollmentVO;
import com.medicare.mss.vo.EEMMbrMasterVO;
import com.medicare.mss.vo.EMDatedSegmentVO;
import com.medicare.mss.vo.EMMbrPCPInfoVO;
import com.medicare.mss.vo.EMPcpSearchVO;
import com.medicare.mss.vo.EmMbrErrorVO;
@Service
@Transactional(rollbackFor = ApplicationException.class)
public class EEMMbrPCPServices extends EEMMbrBaseService {

	@Autowired
	private EEMMbrPCPDAO mbrPCPDao;

	@Autowired
	private EEMCodeCache eemCodeCache;

	@Autowired
	EEMProfileSettings eemProfileSettings;

	@Autowired
	EEMApplDAO applicationDAO;

	@Autowired
	private EEMMbrErrorDAO mbrErrorDAO;

	@Autowired
	private MessageSource messageSource;

	@Autowired
	private EEMMbrDAO eemMbrDAO;

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public List<EMMbrPCPInfoVO> getMbrPCPInfoList(String memberId, String showAll) {

		List<EMMbrPCPInfoVO> mbrPCPVOList = sessionHelper.getEEMContext().getMbrMasterVO().getMbrPcpInfoList();
		
		if (StringUtils.equals(EEMConstants.VALUE_YES, showAll)) {
			List<EMMbrPCPInfoVO> allInfos = getMbrPCPInfoListFromDB(memberId, showAll);
				mbrPCPVOList = (List<EMMbrPCPInfoVO>) getActiveDatedList(allInfos);
				setToContext(mbrPCPVOList);
			return allInfos;
		} else {
			if (Objects.isNull(mbrPCPVOList)) {
				mbrPCPVOList = getMbrPCPInfoListFromDB(memberId, showAll);
				setToContext(mbrPCPVOList);
			} else {
				mbrPCPVOList = (List<EMMbrPCPInfoVO>) getActiveDatedList(mbrPCPVOList);
				setToContext(mbrPCPVOList);
			}
			return mbrPCPVOList;
		}
	}

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public List<EMMbrPCPInfoVO> getMbrPCPInfoListFromDB(String memberId, String showAll) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String lineOfBusiness = getLineOfBusiness(customerId);

		List<EMMbrPCPInfoVO> mbrPCPVOList = new ArrayList<>();
		List<EMMbrPCPInfoDO> mbrPCPDOList = mbrPCPDao.getMbrPCPSelect(customerId, memberId, showAll, lineOfBusiness);
		mbrPCPDOList.forEach(mbrPCPSelect -> {
			EMMbrPCPInfoVO mbrPCPVO = new EMMbrPCPInfoVO();
			BeanUtils.copyProperties(mbrPCPSelect, mbrPCPVO);
			mbrPCPVOList.add(mbrPCPVO);
		});
		/*
		 * if (!"Y".equals(showAll)) { setToContext(mbrPCPVOList); }
		 */
		if(StringUtils.equals(EEMConstants.VALUE_NO, showAll)) {
			setToContext(mbrPCPVOList);
		} else {
			List<EMMbrPCPInfoVO> activeDatedList = (List<EMMbrPCPInfoVO>) getActiveDatedList(mbrPCPVOList);
			setToContext(activeDatedList);
		}
		return mbrPCPVOList;
	}

	private void setToContext(List<EMMbrPCPInfoVO> mbrPCPVOList) {
		EEMContext context = sessionHelper.getEEMContext();
		context.getMbrMasterVO().setMbrPcpInfoList(mbrPCPVOList);
		sessionHelper.setEEMContext(context);
	}

	public List<EMMbrPCPInfoVO> setPcpInfoOverride(EMMbrPCPInfoVO delPCPVO) {

		int sqlCnt = 0;
		String userId = sessionHelper.getUserInfo().getUserId();
		delPCPVO.setCustomerId(sessionHelper.getUserInfo().getCustomerId());

		EMMbrPCPInfoDO delPCPDO = new EMMbrPCPInfoDO();
		BeanUtils.copyProperties(delPCPVO, delPCPDO);
		sqlCnt = mbrPCPDao.setPcpInfoOverride(delPCPDO, userId);

		if (sqlCnt == 1) {
			return getMbrPCPInfoListFromDB(delPCPVO.getMemberId(), delPCPVO.getShowAll());
		} else {
			throw new ApplicationException("Delete operation has been failed");
		}
	}

	public void checkPcp(EMMbrPCPInfoVO wrkVO, String lineOfBusiness, String lobValid) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		mbrPCPDao.getMedOffice(customerId, wrkVO.getPcpNbr(), wrkVO.getEffStartDate(), lineOfBusiness, lobValid, wrkVO.getLineOfBusiness());

	}

	public boolean mbrPcpInfoUpdate(EMMbrPCPInfoVO newVO, List<EEMFieldErrorVO> lstFields) {

		EMMbrPCPInfoDO newEMMbrPCPInfoDO = new EMMbrPCPInfoDO();

		String userId = sessionHelper.getUserInfo().getUserId();
		boolean finalRslt = false;
		String ts = DateUtil.getCurrentDatetimeStamp();
		String fieldNbr = null;
		String fieldUpdate = "423003";
		String requestScrn = "pcp";
		String applDate = " ";

		List<EmMbrErrorVO> lstErrors = validateEnrolledPCP(newVO, lstFields, userId);
		
		newVO.setPcpStatus("N");
		newVO.setPcpchangeReceiveTime(EEMConstants.DEFAULT_TIMESTAMP);
		newVO.setPcpChangeSendTime(EEMConstants.DEFAULT_TIMESTAMP);

		if (lstErrors != null && !lstErrors.isEmpty()) {
			for (int i = 0; i < 1; i++) {
				EmMbrErrorVO objError = null;
				objError = lstErrors.get(i);
				fieldNbr = objError.getFieldNbr();
			}

			List<EmMbrErrorDO> lstErrorsDO = new ArrayList<>();

			lstErrors.forEach(lstErrorVO -> {
				EmMbrErrorDO lstErrorDO = new EmMbrErrorDO();
				BeanUtils.copyProperties(lstErrorVO, lstErrorDO);
				lstErrorsDO.add(lstErrorDO);
			});

			setErrorDetails(lstErrorsDO, newVO.getMemberId(), userId, fieldNbr, requestScrn, applDate);
			newVO.setPcpChangeInd("N");
			newVO.setErrorDescription(" ");

		} else {
			updateErrorDetails(userId, fieldUpdate, requestScrn);
			newVO.setPcpChangeInd("Y");			
			newVO.setErrorDescription("Not Set to HM PCP service");

		}

		List<EmMbrErrorDO> mbrErrorDOList = mbrErrorDAO.getMbrErrors(newVO.getCustomerId(), newVO.getMemberId());
		List<EmMbrErrorVO> mbrErrorVOList = new ArrayList<>();
		if (!CollectionUtils.isEmpty(mbrErrorDOList)) {
			mbrErrorDOList.forEach(mbrErrorDO -> {
				EmMbrErrorVO mbrErrorVO = new EmMbrErrorVO();
				BeanUtils.copyProperties(mbrErrorDO, mbrErrorVO);
				mbrErrorVO.setFieldDispName(
						messageSource.getMessage(mbrErrorDO.getFieldNbr(), null, Locale.getDefault()));
				mbrErrorVOList.add(mbrErrorVO);
			});
		}

		EEMContext context = sessionHelper.getEEMContext();
		context.getMbrMasterVO().setMbrErrorList(mbrErrorVOList);
		sessionHelper.setEEMContext(context);
		Map<String, String> type = new HashMap<>();

		int sqlCnt = 0;
		try {

			String msg = checkDates(newVO);
			if (msg != null) {
				throw new ApplicationException(msg);
			}

			String maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
					EEMConstants.EM_MBR_PCP, type);
			List<EMMbrPCPInfoVO> pcpInfoLst = getMbrPCPInfoList(newVO.getMemberId(), "N");

			if (hasDataChanged(pcpInfoLst, maxLastUpdate)) {
				throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
			}

			EMMbrPCPInfoVO matchVO = null;
			matchVO = (EMMbrPCPInfoVO) matchDatedSegment(pcpInfoLst, newVO);

			if (matchVO != null) {

				return updatePCPInfo(newVO, newEMMbrPCPInfoDO, userId, ts, matchVO, type);
			}

			matchVO = (EMMbrPCPInfoVO) matchDatedSegmentEndDate(pcpInfoLst, newVO);
			if (matchVO != null) {
				return updatePCPInfo(newVO, newEMMbrPCPInfoDO, userId, ts, matchVO, type);
			}

			if (newVO.getEffEndDate().equals("99999999")) {

				return updatePCPInfoForSegmentAll(newVO, newEMMbrPCPInfoDO, userId, ts, pcpInfoLst, type);

			}

			if (!doDatedSegmentAdjust(pcpInfoLst, newVO, ts, userId, mbrPCPDao)) {
				return false;
			}
			newVO.setCreateTime(ts);
			newVO.setCreateUserId(userId);
			newVO.setLastUpdtTime(ts);
			newVO.setLastUpdtUserId(userId);

			BeanUtils.copyProperties(newVO, newEMMbrPCPInfoDO);
			sqlCnt = mbrPCPDao.insertMbrPcpInfo(newEMMbrPCPInfoDO);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
			}

			maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
					EEMConstants.EM_MBR_PCP, type);
			if (hasDataChanged(ts, maxLastUpdate)) {
				throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
			}

			finalRslt = true;

		} catch (Exception exp) {
			throw new ApplicationException(exp.getMessage());
		}
		return finalRslt;
	}

	private boolean updatePCPInfoForSegmentAll(EMMbrPCPInfoVO newVO, EMMbrPCPInfoDO newEMMbrPCPInfoDO, String userId,
			String ts, List<EMMbrPCPInfoVO> pcpInfoLst, Map<String, String> type) throws CloneNotSupportedException, ParseException {
		int sqlCnt;
		String maxLastUpdate;
		EMMbrPCPInfoDO tempDO = new EMMbrPCPInfoDO();

		List<? extends EMDatedSegmentVO> lstSegmentsAbove = getSegmentsAbove(pcpInfoLst,
				newVO.getEffStartDate());
		Iterator<? extends EMDatedSegmentVO> it = lstSegmentsAbove.iterator();
		while (it.hasNext()) {
			EMMbrPCPInfoVO itemVO = (EMMbrPCPInfoVO) it.next();
			BeanUtils.copyProperties(itemVO, tempDO);
			sqlCnt = mbrPCPDao.setPcpInfoOverride(tempDO, userId);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_ABOVE);
			}
		}

		EMMbrPCPInfoVO belowVO = (EMMbrPCPInfoVO) getFirstOverlapSegmentBelow(pcpInfoLst,
				newVO.getEffStartDate());

		if (belowVO != null) {
			BeanUtils.copyProperties(belowVO, tempDO);
			sqlCnt = mbrPCPDao.setPcpInfoOverride(tempDO, userId);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_BELOW);
			}

			if (belowVO.getEffStartDate().compareTo(newVO.getEffStartDate()) < 0) {
				EMMbrPCPInfoVO tempVO = (EMMbrPCPInfoVO) belowVO.clone();
				tempVO.setEffEndDate(DateMath.minusOneDay(newVO.getEffStartDate()));
				tempVO.setCreateTime(ts);
				tempVO.setCreateUserId(userId);
				tempVO.setLastUpdtTime(ts);
				tempVO.setLastUpdtUserId(userId);

				BeanUtils.copyProperties(tempVO, newEMMbrPCPInfoDO);
				sqlCnt = mbrPCPDao.insertMbrPcpInfo(newEMMbrPCPInfoDO);
				if (sqlCnt != 1) {
					throw new ApplicationException(EEMConstants.ERROR_SPLITING_SEGMENT_BELOW);
				}
			}
		}

		newVO.setCreateTime(ts);
		newVO.setCreateUserId(userId);
		newVO.setLastUpdtTime(ts);
		newVO.setLastUpdtUserId(userId);

		BeanUtils.copyProperties(newVO, newEMMbrPCPInfoDO);
		sqlCnt = mbrPCPDao.insertMbrPcpInfo(newEMMbrPCPInfoDO);
		if (sqlCnt != 1) {
			throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
		}

		maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(), EEMConstants.EM_MBR_PCP,
				type);
		if (hasDataChanged(ts, maxLastUpdate)) {
			throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
		}

		return true;
	}

	private boolean updatePCPInfo(EMMbrPCPInfoVO newVO, EMMbrPCPInfoDO newEMMbrPCPInfoDO, String userId, String ts,
			EMMbrPCPInfoVO matchVO, Map<String, String> type) {
		int sqlCnt;
		String maxLastUpdate;
		EMMbrPCPInfoDO matchDO = new EMMbrPCPInfoDO();
		BeanUtils.copyProperties(matchVO, matchDO);

		sqlCnt = mbrPCPDao.setPcpInfoOverride(matchDO, userId);
		if (sqlCnt != 1) {
			throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT);
		}
		newVO.setCreateTime(ts);
		newVO.setCreateUserId(userId);
		newVO.setLastUpdtTime(ts);
		newVO.setLastUpdtUserId(userId);

		BeanUtils.copyProperties(newVO, newEMMbrPCPInfoDO);
		sqlCnt = mbrPCPDao.insertMbrPcpInfo(newEMMbrPCPInfoDO);
		if (sqlCnt != 1) {
			throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
		}

		maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(), EEMConstants.EM_MBR_PCP,
				type);
		if (hasDataChanged(ts, maxLastUpdate)) {
			throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
		}

		return true;
	}

	public boolean splitBelow(EMMbrPCPInfoVO obj1, EMMbrPCPInfoVO obj2) {
		return DateMath.isBetween(obj2.getEffStartDate(), obj1.getEffStartDate(), obj1.getEffEndDate());
	}

	public List<EmMbrErrorVO> validateEnrolledPCP(EMMbrPCPInfoVO newVO, List<EEMFieldErrorVO> lstFields,
			String userId) {

		List<EmMbrErrorVO> lstErrors = new ArrayList<>();

		EmMbrErrorVO objError = checkProviderDates(newVO, lstFields, userId);
		if (objError != null) {
			lstErrors.add(objError);
		}
		objError = checkProviderAcceptNewPatient(newVO, lstFields, userId);
		if (objError != null) {
			lstErrors.add(objError);
		}
		objError = checkProvider(newVO, lstFields, userId);
		if (objError != null) {
			lstErrors.add(objError);
		}

		return lstErrors;

	}

	public EmMbrErrorVO checkProvider(EMMbrPCPInfoVO pcpVO, List<EEMFieldErrorVO> lstFields, String userId) {

		EmMbrErrorVO objError = null;
		EMMbrPCPInfoDO pcpDO = new EMMbrPCPInfoDO();
		BeanUtils.copyProperties(pcpVO, pcpDO);

		EEMFieldErrorVO field = getField(EEMConstants.PCPNBR, lstFields);
		if (field == null) {
			return objError;
		}
		boolean checkProvider = false;

		try {
			boolean error = false;
			String errorCode = "";
			if (pcpVO.getPcpNbr() != null && !pcpVO.getPcpNbr().equalsIgnoreCase("")) {
				checkProvider = mbrPCPDao.checkProvider(pcpDO);
			}
			if (!checkProvider) {
				error = true;
				errorCode = "MB146";
			}
			if (error) {
				objError = new EmMbrErrorVO();
				objError.setCustomerId(pcpVO.getCustomerId());
				objError.setMemberId(pcpVO.getMemberId());
				objError.setFieldNbr(field.getFieldNbr());
				if (!StringUtil.nonNullTrim(field.getRequiredInd()).equals("N")) {
					objError.setRfiInd("Y");
				} else {
					objError.setRfiInd("N");
				}
				objError.setErrorCd(errorCode);
				objError.setErrorMsg(eemCodeCache.getDesc(errorCode, eemCodeCache.getLstErrorCodes()));
				objError.setFieldNbr(field.getFieldNbr());
				objError.setLastUpdtUserId(userId);
				objError.setErrorData(pcpVO.getPcpNbr());
			}
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_ENROLLED_PCP_VALIDATION);
		}
		return objError;
	}

	public EmMbrErrorVO checkProviderAcceptNewPatient(EMMbrPCPInfoVO pcpVO, List<EEMFieldErrorVO> lstFields,
			String userId) {

		EmMbrErrorVO objError = null;
		EMMbrPCPInfoDO pcpDO = new EMMbrPCPInfoDO();
		BeanUtils.copyProperties(pcpVO, pcpDO);

		EEMFieldErrorVO field = getField(EEMConstants.PCPNBR, lstFields);
		if (field == null) {
			return null;
		}

		try {
			boolean error = false;
			String errorCode = "";
			if (pcpVO.getPcpNbr() != null && !pcpVO.getPcpNbr().equalsIgnoreCase("")) {
				String acceptPatient = mbrPCPDao.getCurrentPatientIndicator(pcpDO);
				if ((acceptPatient != null && !acceptPatient.equals("")) && (acceptPatient.equalsIgnoreCase("N"))) {
						error = true;
						errorCode = "MB151";
				}
			}
			if (error) {
				objError = new EmMbrErrorVO();
				objError.setCustomerId(pcpVO.getCustomerId());
				objError.setMemberId(pcpVO.getMemberId());
				objError.setFieldNbr(field.getFieldNbr());
				if (!StringUtil.nonNullTrim(field.getRequiredInd()).equals("N")) {
					objError.setRfiInd("Y");
				} else {
					objError.setRfiInd("N");
				}
				objError.setErrorCd(errorCode);
				objError.setErrorMsg(eemCodeCache.getDesc(errorCode, eemCodeCache.getLstErrorCodes()));
				objError.setFieldNbr(field.getFieldNbr());
				objError.setLastUpdtUserId(userId);
				objError.setErrorData(pcpVO.getPcpNbr());
			}
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_ENROLLED_PCP_VALIDATION);
		}
		return objError;
	}

	public EmMbrErrorVO checkProviderDates(EMMbrPCPInfoVO pcpVO, List<EEMFieldErrorVO> lstFields, String userId) {

		EmMbrErrorVO objError = null;

		EMMbrPCPInfoDO pcpDO = new EMMbrPCPInfoDO();
		BeanUtils.copyProperties(pcpVO, pcpDO);

		EEMFieldErrorVO field = getField(EEMConstants.PCPNBR, lstFields);
		if (field == null) {
			return null;
		}
		boolean checkProviderDate = false;

		try {
			boolean error = false;
			String errorCode = "";
			if (pcpVO.getPcpNbr() != null && !pcpVO.getPcpNbr().equalsIgnoreCase("")) {
				checkProviderDate = mbrPCPDao.checkProviderDates(pcpDO);
			}
			if (!checkProviderDate) {
				error = true;
				errorCode = "MB149";
			}
			if (error) {
				objError = new EmMbrErrorVO();
				objError.setCustomerId(pcpVO.getCustomerId());
				objError.setMemberId(pcpVO.getMemberId());
				objError.setFieldNbr(field.getFieldNbr());
				if (!StringUtil.nonNullTrim(field.getRequiredInd()).equals("N")) {
					objError.setRfiInd("Y");
				} else {
					objError.setRfiInd("N");
				}
				objError.setErrorCd(errorCode);

				objError.setErrorMsg(eemCodeCache.getDesc(errorCode, eemCodeCache.getLstErrorCodes()));
				objError.setFieldNbr(field.getFieldNbr());
				objError.setLastUpdtUserId(userId);
				objError.setErrorData(pcpVO.getPcpNbr());
			}
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_ENROLLED_PCP_VALIDATION);
		}
		return objError;

	}

	public EEMFieldErrorVO getField(String fieldName, List<EEMFieldErrorVO> lstFields) {

		EEMFieldErrorVO field = null;
		boolean found = false;
		for (int i = 0; i < lstFields.size(); i++) {
			field = lstFields.get(i);
			if (fieldName.equals(field.getFormField())) {
				found = true;
				break;
			}
		}

		if (!found) {
			field = null;
		}
		return field;
	}

	public List<EMMbrPCPInfoVO> getPcpList(EMPcpSearchVO eMPcpSearchVO) {
		String lobValid = EEMConstants.BLANK;
		String lineOfBusiness = EEMConstants.BLANK;
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		eMPcpSearchVO.setCustomerId(customerId);
		EMPcpSearchDO emPcpSearchDO = new EMPcpSearchDO();
		BeanUtils.copyProperties(eMPcpSearchVO, emPcpSearchDO);
		try {
			List<EMMbrPCPInfoVO> mbrPCPVOList = new ArrayList<>();

			EEMProfileItemDO eemProfileItemDO = eemProfileSettings.getProfileObject(customerId, EEMProfileConstants.LOB_VALD);
			lobValid = (null == eemProfileItemDO) ? "" : StringUtil.nonNullTrim(eemProfileItemDO.getParmIndValue());

			if ("Y".equalsIgnoreCase(lobValid)) {
				
				EEMMbrMasterVO masterVO = sessionHelper.getEEMContext().getMbrMasterVO();
				EEMMbrEnrollmentVO mbrEnrlVO = (EEMMbrEnrollmentVO) getSegmentActiveOn(masterVO.getMbrEnrollmentList(),
						emPcpSearchDO.getEffDate());

				if (Optional.ofNullable(mbrEnrlVO).isPresent()) {
					lineOfBusiness = eEMApplDAO.getLineOfBusniess(customerId,
							mbrEnrlVO.getGrpId(),
							mbrEnrlVO.getEffStartDate(),
							mbrEnrlVO.getProductId(),
							mbrEnrlVO.getPlanId(),
							mbrEnrlVO.getPbpId(),
							mbrEnrlVO.getPbpSegmentId());

				}
			} else {
				lineOfBusiness = "";
			}

			List<EMMbrPCPInfoDO> mbrPCPDOList = mbrPCPDao.searchPcp(emPcpSearchDO, lineOfBusiness);
			mbrPCPDOList.forEach(mbrPCPSelect -> {
				EMMbrPCPInfoVO mbrPCPVO = new EMMbrPCPInfoVO();
				BeanUtils.copyProperties(mbrPCPSelect, mbrPCPVO);
				mbrPCPVOList.add(mbrPCPVO);
			});
			return mbrPCPVOList;
		} catch (Exception exp) {
			throw new ApplicationException(exp.getMessage());
		}

	}

	public List<EMMbrPCPInfoVO> mbrPcpUpdate(EMMbrPCPInfoVO wrkVO) {

		boolean rslt = false;
		wrkVO.setOverrideInd("N");
		wrkVO.setCustomerId(sessionHelper.getUserInfo().getCustomerId());

		String lineOfBusiness = EEMConstants.BLANK;
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		EEMProfileItemDO eemProfileItemDO = eemProfileSettings.getProfileObject(customerId, EEMProfileConstants.LOB_VALD);
		String	lobValid = (null == eemProfileItemDO) ? "" : StringUtil.nonNullTrim(eemProfileItemDO.getParmIndValue());

			if ("Y".equalsIgnoreCase(lobValid)) {
				
				EEMMbrMasterVO masterVO = sessionHelper.getEEMContext().getMbrMasterVO();
				EEMMbrEnrollmentVO mbrEnrlVO = (EEMMbrEnrollmentVO) getSegmentActiveOn(masterVO.getMbrEnrollmentList(),
						wrkVO.getEffStartDate());

				if (Optional.ofNullable(mbrEnrlVO).isPresent()) {
					lineOfBusiness = eEMApplDAO.getLineOfBusniess(customerId,
							mbrEnrlVO.getGrpId(),
							mbrEnrlVO.getEffStartDate(),
							mbrEnrlVO.getProductId(),
							mbrEnrlVO.getPlanId(),
							mbrEnrlVO.getPbpId(),
							mbrEnrlVO.getPbpSegmentId());

				}
			} 
			checkPcp(wrkVO, lineOfBusiness, lobValid);
			List<EEMFieldErrorVO> lstFields = getValidatingFormFields(EEMConstants.EEM_ENROLL_FORM);

			rslt = mbrPcpInfoUpdate(wrkVO, lstFields);

			if (rslt) {
				return getMbrPCPInfoListFromDB(wrkVO.getMemberId(), wrkVO.getShowAll());
			} else {
				throw new ApplicationException("Pcp Update Failed");
			}

	}

}
