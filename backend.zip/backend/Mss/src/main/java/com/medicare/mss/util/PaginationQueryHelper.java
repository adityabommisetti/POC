package com.medicare.mss.util;

import java.util.List;
import java.util.Map;

import com.medicare.mss.vo.DataBaseField;

final public class PaginationQueryHelper {

	private PaginationQueryHelper() {
	}

	public static StringBuilder pagingElements(DataBaseField[] condList, List<String> params) {
		StringBuilder s = new StringBuilder(" AND (");
		int size = condList.length;
		DataBaseField field = null;
		for (int i = 0; i < size; i++) {
			s.append("(");
			for (int j = 0; j <= i; j++) {
				field = condList[j];
				String sign = field.getSign();
				if (StringUtil.isNullOrEmpty(sign)) {
					sign = " > ";
				}

				if (i == j) {
					s.append(condList[j].getFieldName()).append(sign).append(" ?");
				} else {
					s.append(condList[j].getFieldName()).append("= ?");
				}
				params.add(field.getStringValue());

				if (j < i)
					s.append(" AND ");
			}
			s.append(")");
			if (i < (size - 1))
				s.append(" OR ");
		}

		return s.append(")");
	}

	public static StringBuilder pagingElements(DataBaseField[] conditions, Map<String, Object> params) {
		StringBuilder queryBuilder = new StringBuilder(" AND (");
		int size = conditions.length;
		DataBaseField field = null;
		for (int i = 0; i < size; i++) {
			queryBuilder.append("(");
			for (int j = 0; j <= i; j++) {
				field = conditions[j];
				String sign = field.getSign();
				if (StringUtil.isNullOrEmpty(sign)) {
					sign = " >";
				}

				if (i == j) {
					queryBuilder.append(conditions[j].getFieldName()).append(sign).append(" :")
							.append(conditions[j].getFieldName());
				} else {
					queryBuilder.append(conditions[j].getFieldName()).append("= :")
							.append(conditions[j].getFieldName());
				}
				params.put(conditions[j].getFieldName(), field.getStringValue());

				if (j < i) {
					queryBuilder.append(" AND ");
				}
			}
			queryBuilder.append(") ");
			if (i < (size - 1))
				queryBuilder.append(" OR ");
		}

		return queryBuilder.append(")");
	}
}