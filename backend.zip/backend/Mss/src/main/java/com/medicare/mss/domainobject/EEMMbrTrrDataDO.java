package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMMbrTrrDataDO {

	@ColumnMapper(columnName = "TRR_VARIABLE_DESC", propertyName = "variableDesc")
	private String variableDesc;

	@ColumnMapper(columnName = "TRR_VARIABLE_DATA", propertyName = "variableData")
	private String variableData;

	@ColumnMapper(columnName = "TRR_VARIABLE_DATA_DESC", propertyName = "variableDataDesc")
	private String variableDataDesc;

}
