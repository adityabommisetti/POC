/**
 * 
 */
package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

/**
 * @author DU20098149
 *
 */
@Data
public class EEMBillingInvoiceDtlsDO {
	
	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;
	
	@ColumnMapper(columnName = "INVOICE_NBR", propertyName = "invoiceNbr")
	private String invoiceNbr;
	
	@ColumnMapper(columnName = "ITEM_NBR", propertyName = "itemNbr")
	private int itemNbr;
	
	@ColumnMapper(columnName = "ADD_NBR", propertyName = "addNbr")
	private int addNbr;
	
	@ColumnMapper(columnName = "CHECK_NBR", propertyName = "checkNbr")
	private String checkNbr;
	
	@ColumnMapper(columnName = "ITEM_DESC", propertyName = "itemDesc")
	private String itemDesc;
	
	@ColumnMapper(columnName = "LINE_STATUS", propertyName = "lineStatus")
	private String lineStatus;
	
	@ColumnMapper(columnName = "GRP_ID", propertyName = "grpId")
	private String grpId;

	@ColumnMapper(columnName = "MEMBER_ID", propertyName = "memberId")
	private String memberId;
	
	@ColumnMapper(columnName = "GROUP_NAME", propertyName = "groupName")
	private String groupName;
	
	@ColumnMapper(columnName = "PRODUCT_ID", propertyName = "productId")
	private String productId;
	
	@ColumnMapper(columnName = "PRODUCT_NAME", propertyName = "productName")
	private String productName;
	
	@ColumnMapper(columnName = "SUBPRODUCT_ID", propertyName = "subProductId")
	private String subProductId;
	
	@ColumnMapper(columnName = "SUBPRODUCT_DESC", propertyName = "subProductDesc")
	private String subProductDesc;
	
	@ColumnMapper(columnName = "FUNCTION_CD", propertyName = "functionCd")
	private String functionCd;
	
	@ColumnMapper(columnName = "LONG_DESC", propertyName = "functionCdDesc")
	private String functionCdDesc;
	
	@ColumnMapper(columnName = "BANK_ACCT_CD", propertyName = "bankAcctCd")
	private String bankAcctCd;
	
	@ColumnMapper(columnName = "DETAIL_AMT", propertyName = "detailAmt")
	private double detailAmt;
	
	@ColumnMapper(columnName = "XREF_INVOICE_NBR", propertyName = "xrefInvoiceNbr")
	private String xrefInvoiceNbr;
	
	@ColumnMapper(columnName = "PAY_SOURCE_TYPE", propertyName = "paySourceType")
	private String paySourceType;
	
	@ColumnMapper(columnName = "PAY_BATCH_DATE", propertyName = "payBatchDate")
	private String payBatchDate;
	
	@ColumnMapper(columnName = "PAY_BATCH_SEQ_NBR", propertyName = "payBatchSeqNbr")
	private String payBatchSeqNbr;
	
	@ColumnMapper(columnName = "PAY_ITEM_NBR", propertyName = "payItemNbr")
	private String payItemNbr;
	
	@ColumnMapper(columnName = "CREATE_TIME", propertyName = "createTime")
	private String createTime;
	
	@ColumnMapper(columnName = "CREATE_USERID", propertyName = "createUserId")
	private String createUserId;
	
	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;
	
	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserId")
	private String lastUpdtUserId;
	
}
