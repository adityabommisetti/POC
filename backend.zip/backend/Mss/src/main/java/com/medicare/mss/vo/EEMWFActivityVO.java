package com.medicare.mss.vo;

import java.io.Serializable;

import lombok.Data;

@Data
public class EEMWFActivityVO implements Serializable {

	private static final long serialVersionUID = 7120308209544475598L;

	private String activityDesc;

	private String activityScreen;

	private String activityStatus;

	private int caseId;

	private String customerId;

	private String errorId;

	private String queueCode;

	private String subQueueCode;

}
