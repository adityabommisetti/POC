package com.medicare.mss.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.service.EEMBillingDraftService;
import com.medicare.mss.vo.BillingDraftDetailVO;
import com.medicare.mss.vo.BillingDraftFormVO;
import com.medicare.mss.vo.BillingDraftHeaderVO;
import com.medicare.mss.vo.BillingDraftMasterVO;
import com.medicare.mss.vo.PageableVO;

@RestController
@RequestMapping("/billing")
public class EEMBillingDraftController {

	@Autowired
	private EEMBillingDraftService billingDraftService;

	@PostMapping(ReqMappingConstants.GET_BILLING_DRAFT_HEADER_SEARCH)
	public ResponseEntity<JSONResponse> getBillingDraftSearch(@RequestBody BillingDraftFormVO billingDraftFormVO) {

		BillingDraftMasterVO billingDraftMasterVO = billingDraftService.mbrBillingPaymentsSearch(billingDraftFormVO);
		return sendResponse(billingDraftMasterVO);
	}
	
	@PostMapping(ReqMappingConstants.GET_BILLING_DRAFT_HEADER_SEARCH_NEXT)
	public ResponseEntity<JSONResponse> getBillingDraftSearchNext(@RequestBody BillingDraftFormVO billingDraftFormVO) {
		
		PageableVO pageableResult = billingDraftService.mbrBillingPaymentsSearchNext(billingDraftFormVO);
		return sendResponse(pageableResult);
	}

	@PostMapping(ReqMappingConstants.GET_BILLING_DRAFT_DETAIL_SEARCH)
	public ResponseEntity<JSONResponse> getbillingDraftDetailSearch(
			@RequestBody BillingDraftHeaderVO billingDraftHeaderVO) {

		List<BillingDraftDetailVO> billingDraftDetailVOList = billingDraftService
				.getBillDraftDetail(billingDraftHeaderVO);
		return sendResponse(billingDraftDetailVOList);
	}

	private ResponseEntity<JSONResponse> sendResponse(Object object) {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;
		jsonResponse.setData(object);
		if (null == object) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
			jsonResponse.setMessage(EEMConstants.BLANK);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}
}
