package com.medicare.mss.dao;

import java.util.List;

import com.medicare.mss.domainobject.EEMMbrBillingDO;

public interface EEMMbrBillingDAO extends EEMMbrBaseDAO {

	/**
	 * This method retrieves member billing info
	 * 
	 * @param customerId customer id
	 * @param memberId member id
	 * @param showAll showAll flag
	 * @return list of member Billing domain object
	 * 
	 **/
	 List<EEMMbrBillingDO> getMbrBilling(String customerId, String memberId, String showAll);

}
