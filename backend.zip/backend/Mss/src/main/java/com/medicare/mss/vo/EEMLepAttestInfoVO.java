package com.medicare.mss.vo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode(callSuper = false)
public class EEMLepAttestInfoVO extends BaseVO {

	private static final long serialVersionUID = 7813469696197894698L;
	private String userId;
	private String primaryId;
	private String attestLetMailDate;
	private String attestLetExpDate;
	private String attestStatus;
	private String oldAttestStatus;
	private String appIncAttLetExpDt;
	private String appIncAttRcDt;
	private String pdf_archival;
	private String obc1TimerCheck;
	private String obc2TimerCheck;
	private String le21TimerCheck;
	private String obc3TimerCheck;
	private String is73TxnExists;
	private String dmsID;
	private String letterAvailabilityInDB = "N";
	private String letterUploadedTime;
	private String letterName;
	private String attestLock;
	private String attestationRecChannel;
	private String attestationRecDate;
	private String notifiedMemberAppeal;

	private String otherLastUpdtUserId;
	private String otherLastUpdtTime;
	private String otherCreateTime;
	private String otherCreateUserId;
	private boolean enableAttestAfter90DaysSection;

	private String totalPotentialUncovMonth;

	private List<EEMLepAttestCcfVO> lepAttestList;

	public String getAttestationRecDateFrmt() {
		return DateFormatter.reFormat(attestationRecDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setAttestationRecDateFrmt(String attestationRecDate) {
		this.attestationRecDate = DateFormatter.reFormat(attestationRecDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
	}

	public String getAppIncAttRcDtFrmt() {
		return DateFormatter.reFormat(appIncAttRcDt, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setAppIncAttRcDtFrmt(String appIncAttRcDt) {
		this.appIncAttRcDt = DateFormatter.reFormat(appIncAttRcDt, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getAttestLetMailDateFrmt() {
		return DateFormatter.reFormat(attestLetMailDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setAttestLetMailDateFrmt(String attestLetMailDate) {
		this.attestLetMailDate = DateFormatter.reFormat(attestLetMailDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
	}

	public String getAttestLetExpDateFrmt() {
		return DateFormatter.reFormat(attestLetExpDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setAttestLetExpDateFrmt(String attestLetExpDate) {
		this.attestLetExpDate = DateFormatter.reFormat(attestLetExpDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
	}

	public String getAppIncAttLetExpDtFrmt() {
		return DateFormatter.reFormat(appIncAttLetExpDt, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setAppIncAttLetExpDtFrmt(String appIncAttLetExpDt) {
		this.appIncAttLetExpDt = DateFormatter.reFormat(appIncAttLetExpDt, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
	}

}
