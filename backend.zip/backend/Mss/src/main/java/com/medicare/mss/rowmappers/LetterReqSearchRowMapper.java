package com.medicare.mss.rowmappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.domainobject.EEMLetterReqDO;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.StringUtil;

public class LetterReqSearchRowMapper implements RowMapper<EEMLetterReqDO> {

	@Autowired
	EEMCodeCache eemCodeCache;

	@Override
	public EEMLetterReqDO mapRow(ResultSet res, int rowNum) throws SQLException {

		EEMLetterReqDO searchDO = new EEMLetterReqDO();

		searchDO.setCustomerId(StringUtil.nonNullTrim(res.getString("CUSTOMER_ID")));
		searchDO.setSourceType(StringUtil.nonNullTrim(res.getString("SOURCE_TYPE")));
		searchDO.setPrimaryId(StringUtil.nonNullTrim(res.getString("PRIMARY_ID")));
		searchDO.setEffDate(DateUtil.formatMmDdYyyy((StringUtil.nonNullTrim(res.getString("EFFECTIVE_DATE")))));
		searchDO.setCreateTime(StringUtil.nonNullTrim(res.getString("CREATE_TIME")));
		searchDO.setTriggerType(StringUtil.nonNullTrim(res.getString("TRIGGER_TYPE")));
		searchDO.setTriggerCode(StringUtil.nonNullTrim(res.getString("TRIGGER_CODE")));
		searchDO.setTriggerStatus(StringUtil.nonNullTrim(res.getString("TRIGGER_STATUS")));
		searchDO.setCreateUserId(StringUtil.nonNullTrim(res.getString("CREATE_USERID")));
		searchDO.setLastUpdtTime(StringUtil.nonNullTrim(res.getString("LAST_UPDT_TIME")));
		searchDO.setLastUpdtUserId(StringUtil.nonNullTrim(res.getString("LAST_UPDT_USERID")));
		searchDO.setCreateTime(DateFormatter.reFormat(searchDO.getCreateTime(), DateFormatter.DB2_TIMESTAMP,
				DateFormatter.DB2_TIMESTAMP));
		searchDO.setLastUpdtTime(DateFormatter.reFormat(searchDO.getLastUpdtTime(), DateFormatter.DB2_TIMESTAMP,
				DateFormatter.DB2_TIMESTAMP));
		searchDO.setMbrFName(StringUtil.nonNullTrim(res.getString("FIRST_NAME")));
		searchDO.setMbrLName(StringUtil.nonNullTrim(res.getString("LAST_NAME")));
		searchDO.setLetterName(StringUtil.nonNullTrim(res.getString("CORR_LETTER_NAME")));
		searchDO.setLetterNameDesc(StringUtil.nonNullTrim(res.getString("CORR_SHORT_DESC")));
		
		searchDO.setPlanId(StringUtil.nonNullTrim(res.getString("PLAN_ID")));
		searchDO.setPbpId(StringUtil.nonNullTrim(res.getString("PBP_ID")));
		searchDO.setPlanDesignation(StringUtil.nonNullTrim(res.getString("PLAN_DESIGNATION")));

		/*if ("M".equals(searchDO.getSourceType())) {
			searchDO.setPlanId(StringUtil.nonNullTrim(res.getString("PLAN_ID")));
			searchDO.setPbpId(StringUtil.nonNullTrim(res.getString("PBP_ID")));
			searchDO.setPlanDesignation(StringUtil.nonNullTrim(res.getString("PLAN_DESIGNATION")));
		} else {
			searchDO.setPlanId(StringUtil.nonNullTrim(res.getString("TO_PLAN_ID")));
			searchDO.setPbpId(StringUtil.nonNullTrim(res.getString("TO_PBP_ID")));
			searchDO.setPlanDesignation(StringUtil.nonNullTrim(res.getString("PLAN_DESIGNATION")));
		}*/
		return searchDO;
	}

}
