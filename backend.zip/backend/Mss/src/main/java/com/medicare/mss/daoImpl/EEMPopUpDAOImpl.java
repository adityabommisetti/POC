package com.medicare.mss.daoImpl;

import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.caching.EEMPersistence;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMPopUpDAO;
import com.medicare.mss.domainobject.EEMApplProductDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.ApplProductRowMapper;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.util.StringUtil;

@Repository
public class EEMPopUpDAOImpl implements EEMPopUpDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private EEMCodeCache codeCache;

	@Autowired
	private EEMPersistence eemPer;

	private List<LabelValuePair> lstAgent;
	private List<LabelValuePair> lstAgency;

	@Override
	public List<Map<String, String>> getLstSrchAgencies(String customerId, Map<String, String> searchParamMap) {

		List<Map<String, String>> data = null;
		try {
			lstAgent = eemPer.getLstAgentTypes();
			lstAgency = eemPer.getLstAgencyTypes();
			
			String searchLob = trimToEmpty(searchParamMap.get("searchLob"));
			String agentId = trimToEmpty(searchParamMap.get("agentId"));
			String agentName = trimToEmpty(searchParamMap.get("agentName"));
			String agentType = trimToEmpty(searchParamMap.get("agentType"));
			String agenyId = trimToEmpty(searchParamMap.get("agencyId"));
			String agencyName = trimToEmpty(searchParamMap.get("agencyName"));
			String agencyType = trimToEmpty(searchParamMap.get("agencyType"));
			String reqDateCov = trimToEmpty(searchParamMap.get("reqDateCov"));

			StringBuilder sQuery = new StringBuilder();

			List<String> params = new ArrayList<>();

			sQuery.append("SELECT  B.AGENT_ID, B.AGENT_TYPE,B.AGENT_TIN, B.AGENT_NAME,B.AGENT_PHONE, B.AGENT_EMAIL,")
					.append("C.AGENCY_ID,C.AGENCY_TYPE,C.AGENCY_TIN,	C.AGENCY_NAME, C.AGENCY_PHONE, C.AGENCY_EMAIL")
					.append(" FROM EM_AGENCY_AGENT A JOIN EM_AGENT B ON A.AGENT_ID = B.AGENT_ID ")
					.append(" JOIN EM_AGENCY C ON A.AGENCY_ID = C.AGENCY_ID")
					.append(" WHERE A.CUSTOMER_ID = B.CUSTOMER_ID AND A.CUSTOMER_ID = C.CUSTOMER_ID ")
					.append(" AND A.AGENT_TYPE = B.AGENT_TYPE  AND A.CUSTOMER_ID = ? ");

			params.add(customerId);

			if (!searchLob.isEmpty()) {
				sQuery.append(" AND A.LINE_OF_BIZ IN ('', ?) ");
				params.add(searchLob);
			}
			
			if (!agenyId.isEmpty()) {
				sQuery.append(" AND A.AGENCY_ID LIKE ? ");
				params.add(StringUtil.appendWildCardCharacter(agenyId, true, true));
			}
			if (!agencyName.isEmpty()) {
				sQuery.append(" AND C.AGENCY_NAME LIKE ?");
				params.add(StringUtil.appendWildCardCharacter(agencyName, true, true));
			}
			if (!agencyType.isEmpty()) {
				sQuery.append(" AND C.AGENCY_TYPE LIKE ?");
				params.add(StringUtil.appendWildCardCharacter(agencyType, true, true));
			}
			if (!agentId.isEmpty()) {
				sQuery.append(" AND A.AGENT_ID LIKE ?");
				params.add(StringUtil.appendWildCardCharacter(agentId, true, true));
			}
			if (!agentName.isEmpty()) {
				sQuery.append(" AND B.AGENT_NAME LIKE ?");
				params.add(StringUtil.appendWildCardCharacter(agentName, true, true));
			}
			if (!agentType.isEmpty()) {
				sQuery.append(" AND B.AGENT_TYPE LIKE ?");
				params.add(StringUtil.appendWildCardCharacter(agentType, true, true));
			}
			if (!reqDateCov.isEmpty()) {
				sQuery.append(" AND ? BETWEEN A.EFF_START_DATE AND A.EFF_END_DATE");
				params.add(DateUtil.changedDateFormatForMonth(reqDateCov));
			}
			sQuery.append(" ORDER BY A.EFF_START_DATE DESC");

			data = jdbcTemplate.query(sQuery.toString(), params.toArray(), new RowMapper<Map<String, String>>() {

				@Override
				public Map<String, String> mapRow(ResultSet res, int arg1) throws SQLException {

					Map<String, String> object = new HashMap<>();

					object.put("agentId", trimToEmpty(res.getString("AGENT_ID")));
					object.put("agentType", trimToEmpty(res.getString("AGENT_TYPE")));
					object.put("agentTin", trimToEmpty(res.getString("AGENT_TIN")));
					object.put("agentName", trimToEmpty(res.getString("AGENT_NAME")));
					object.put("agentPhone", trimToEmpty(res.getString("AGENT_PHONE")));
					object.put("agentEmail", trimToEmpty(res.getString("AGENT_EMAIL")));

					object.put("agencyId", trimToEmpty(res.getString("AGENCY_ID")));
					object.put("agencyType", trimToEmpty(res.getString("AGENCY_TYPE")));
					object.put("agencyTin", trimToEmpty(res.getString("AGENCY_TIN")));
					object.put("agencyName", trimToEmpty(res.getString("AGENCY_NAME")));
					object.put("agencyPhone", trimToEmpty(res.getString("AGENCY_PHONE")));
					object.put("agencyEmail", trimToEmpty(res.getString("AGENCY_EMAIL")));

					object.put("agencyTypeDesc", (trimToEmpty(codeCache.getDesc(object.get("agencyType"), lstAgency))));
					object.put("agentTypeDesc", (trimToEmpty(codeCache.getDesc(object.get("agentType"), lstAgent))));

					return object;
				}
			});
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp);
		}
		return data;
	}

	@Override
	public List<Map<String, String>> getLstPCPNames(String customerId, Map<String, String> searchParamMap) {

		List<Map<String, String>> data = null;
		try {
			String searchLob = trimToEmpty(searchParamMap.get("searchLob"));
			String reqDateCov = trimToEmpty(searchParamMap.get("reqDateCov"));
			String searchDocName = trimToEmpty(searchParamMap.get("searchDocName"));
			String searchOfficeCd = trimToEmpty(searchParamMap.get("searchOfficeCd"));
			String searchLocationId = trimToEmpty(searchParamMap.get("searchLocationId"));
			String searchCurrPatient = trimToEmpty(searchParamMap.get("searchCurrPatient"));
			String searchNpiId = trimToEmpty(searchParamMap.get("searchNpiId"));

			List<String> params = new ArrayList<>();

			StringBuilder sQuery = new StringBuilder("SELECT OFFICE_CD, DOCTOR_NAME, DOCTOR_ADDRESS, DOCTOR_CITY,")
					.append(" DOCTOR_STATE,DOCTOR_ZIP_CD, LOCATION_ID, OFFICE_CATEGORY_CD, ACCEPT_NEW_PATIENT_IND, ")
					.append(" ALTERNATE_OFFICE_CD FROM EM_MED_OFFICE WHERE CUSTOMER_ID IN ('9999999', ?)")
					.append(" AND OFFICE_CATEGORY_CD = 'PCP'");
			

			params.add(customerId);
			
			if (!searchLob.isEmpty()) {
				sQuery.append(" AND LINE_OF_BIZ IN ('', ?) ");
				params.add(searchLob);
			}
			
			if (!reqDateCov.isEmpty()) {
				sQuery.append(" AND ? BETWEEN OFFICE_START_DATE AND OFFICE_END_DATE ");
				params.add(DateUtil.changedDateFormatForMonth(reqDateCov));
			}
			if (!searchDocName.isEmpty()) {
				sQuery.append(" AND DOCTOR_NAME LIKE ?");
				params.add(StringUtil.appendWildCardCharacter(searchDocName, true, true));
			}
			if (!searchCurrPatient.equals("Y")) {
				sQuery.append(" AND ACCEPT_NEW_PATIENT_IND = 'Y' ");
			}
			if (!searchOfficeCd.isEmpty()) {
				sQuery.append(" AND OFFICE_CD = ? ");
				params.add(searchOfficeCd);
			}
			if (!searchLocationId.isEmpty()) {
				sQuery.append(" AND LOCATION_ID = ? ");
				params.add(searchLocationId);
			}
			
			if (!searchNpiId.isEmpty()) {
				sQuery.append(" AND ALTERNATE_OFFICE_CD = ? ");
				params.add(searchNpiId);
			}
			
			sQuery.append(" ORDER BY OFFICE_CD, DOCTOR_NAME");

			data = jdbcTemplate.query(sQuery.toString(), params.toArray(), new RowMapper<Map<String, String>>() {

				@Override
				public Map<String, String> mapRow(ResultSet res, int arg1) throws SQLException {
					Map<String, String> object = new HashMap<>();

					object.put("pcpCurrPatnt", trimToEmpty(res.getString("ACCEPT_NEW_PATIENT_IND")));
					object.put("PcpLocationId", trimToEmpty(res.getString("LOCATION_ID")));
					object.put("pcpOfficeCd", trimToEmpty(res.getString("OFFICE_CD")));
					String pcpName = trimToEmpty(res.getString("DOCTOR_NAME"));

					if (!trimToEmpty(pcpName).equals("")) {
						pcpName = pcpName.replaceAll("\'", "");
					}
					object.put("pcpName", pcpName);
					object.put("pcpOffCatCd", trimToEmpty(res.getString("OFFICE_CATEGORY_CD")));
					object.put("pcpAddress", trimToEmpty(res.getString("DOCTOR_ADDRESS")));
					object.put("pcpCity", trimToEmpty(res.getString("DOCTOR_CITY")));
					object.put("pcpState", trimToEmpty(res.getString("DOCTOR_STATE")));
					object.put("pcpZip", trimToEmpty(res.getString("DOCTOR_ZIP_CD")));
					object.put("pcpNpiId", trimToEmpty(res.getString("ALTERNATE_OFFICE_CD")));

					return object;
				}
			});
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp);
		}
		return data;
	}

	@Override
	public List<Map<String, String>> getCityNameswithCounty(Map<String, String> searchParamMap) {

		List<Map<String, String>> data = null;
		try {
			String zip5 = trimToEmpty(searchParamMap.get("zip5"));
			final String zip4 = trimToEmpty(searchParamMap.get("zip4"));

			List<String> parms = new ArrayList<>();
			StringBuilder sql;

			if (!zip4.isEmpty()) {
				sql = new StringBuilder("SELECT DISTINCT Z.CITY_NAME,Z.STATE_CD As Value,")
						.append(" Z.ZIP_CD5 As Zip,Z.ZIP_CD4  As Zip4,C.COUNTY_NAME,Z.SSA_CNTY AS CNTY_CD ")
						.append(" FROM EM_ZIPCODE Z, COUNTY C WHERE Z.ZIP_CD5 = ? AND Z.ZIP_CD4 = ?")
						.append(" AND C.STATE_CD = Z.SSA_ST AND Z.SSA_CNTY=C.COUNTY_CD ")
						.append(" UNION SELECT DISTINCT CITY_NAME,STATE_CODE AS Value,ZIP_CODE As Zip,'' As Zip4,")
						.append(" COUNTY_NAME,SSA_CNTY_CD AS CNTY_CD FROM EM_ZIPCITY WHERE ZIP_CODE =? ORDER BY CITY_NAME");

				parms.add(zip5);
				parms.add(zip4);
				parms.add(zip5);
			} else {
				sql = new StringBuilder("SELECT DISTINCT Z.CITY_NAME,Z.STATE_CD As Value,Z.ZIP_CD5 As Zip, ")
						.append(" C.COUNTY_NAME,Z.SSA_CNTY AS CNTY_CD FROM EM_ZIPCODE Z, COUNTY C")
						.append(" WHERE Z.ZIP_CD5 = ? AND C.STATE_CD = Z.SSA_ST AND Z.SSA_CNTY=C.COUNTY_CD ")
						.append(" UNION SELECT DISTINCT CITY_NAME,STATE_CODE AS Value,ZIP_CODE As Zip,COUNTY_NAME,SSA_CNTY_CD AS CNTY_CD ")
						.append(" FROM EM_ZIPCITY WHERE ZIP_CODE =? ORDER BY CITY_NAME");

				parms.add(zip5);
				parms.add(zip5);
			}
			data = jdbcTemplate.query(sql.toString(), (ResultSet res) -> {

				List<Map<String, String>> mapList = new ArrayList<>();
				while (res.next()) {
					Map<String, String> map = new HashMap<>();
					map.put("perCity", trimToEmpty(res.getString("CITY_NAME")));
					map.put("perState", trimToEmpty(res.getString("Value")));
					try {
						map.put("perStateCd", codeCache.getStateCd(map.get("perState")));
					} catch (ApplicationException exp) {
						throw new ApplicationException(exp);
					}
					map.put("perZip5", trimToEmpty(res.getString("Zip")));
					if (!zip4.isEmpty()) {
						map.put("perZip4", trimToEmpty(res.getString("Zip4")));
					} else {
						map.put("perZip4", "");
					}
					map.put("perCounty", trimToEmpty(res.getString("COUNTY_NAME")));
					map.put("countyCd", trimToEmpty(res.getString("CNTY_CD")));
					mapList.add(map);
				}
				return mapList;
			}, parms.toArray());
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp);
		}
		return data;
	}

	@Override
	public List<EEMApplProductDO> getProducts(String customerId, Map<String, String> searchParamMap) {

		List<EEMApplProductDO> data = null;
		try {
			data = getApplProducts(searchParamMap, customerId);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp);
		}
		return data;
	}

	@Override
	public List<EEMApplProductDO> getApplProducts(Map<String, String> searchParamMap, String customerId) {

		String effDate = DateFormatter.reFormat(searchParamMap.get("covDt"), DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
		String searchProd = trimToEmpty(searchParamMap.get("prod"));

		if (searchProd.equals("")) {
			searchProd = searchProd.replace("^", "+");
		}
		String searchGroup = trimToEmpty(searchParamMap.get("group"));
		String searchGroupId = trimToEmpty(searchParamMap.get("groupId"));
		String searchProdId = trimToEmpty(searchParamMap.get("prodId"));
		String zip5 = trimToEmpty(searchParamMap.get("zip5"));
		String zip4 = trimToEmpty(searchParamMap.get("zip4"));
		String searchPlan = trimToEmpty(searchParamMap.get("plan"));
		String searchPbp = trimToEmpty(searchParamMap.get("pbp"));
		String searchSegment = trimToEmpty(searchParamMap.get("segment"));
		String ssaSt = trimToEmpty(searchParamMap.get("PerState"));
		String ssaCnty = trimToEmpty(searchParamMap.get("PerCounty"));
		String applType = trimToEmpty(searchParamMap.get("applType"));
		String ooa = trimToEmpty(searchParamMap.get("OutOfArea"));
		StringBuilder sql = null;
		if (!ooa.equals("E")) {
			if (zip4.equals(""))
				zip4 = "0000";

			if (!zip5.isEmpty() && (ssaCnty.isEmpty() || ssaSt.isEmpty())) {

				sql = new StringBuilder(" SELECT SSA_ST, SSA_CNTY ").append(" FROM EM_ZIPCODE")
						.append(" WHERE ZIP_CD5 = ? AND ZIP_CD4 in ('0000',?)")
						.append(" ORDER BY ZIP_CD4 DESC FETCH FIRST 1 ROWS ONLY");

				try {
					Map<String, Object> queryForMap = jdbcTemplate.queryForMap(sql.toString(), zip5, zip4);
					ssaSt = trimToEmpty((String) queryForMap.get("SSA_ST"));
					ssaCnty = trimToEmpty((String) queryForMap.get("SSA_CNTY"));
				} catch (EmptyResultDataAccessException exp) {
					exp.getMessage();
				}
			}
		}
		List<String> parms = new ArrayList<>();

		sql = getProdQuery();

		parms.add(customerId);
		parms.add(effDate);
		parms.add(effDate);
		parms.add(effDate);
		parms.add(effDate);
		parms.add(effDate);
		parms.add(effDate);

		if (!zip5.isEmpty()) {
			sql.append(" AND (").append(" (SAZ.SSA_ST = ? AND SAZ.SSA_CNTY = 'XXX')").append(" OR")
					.append(" (SAZ.SSA_ST = ? AND SAZ.SSA_CNTY = ? AND SAZ.ZIP_CD5='XXXXX')").append(" OR")
					.append(" (? BETWEEN SAZ.ZIP_CD5_LOW AND SAZ.ZIP_CD5 AND ? BETWEEN SAZ.ZIP_CD4_LOW AND SAZ.ZIP_CD4)")
					.append(")");
			parms.add(ssaSt);
			parms.add(ssaSt);
			parms.add(ssaCnty);
			parms.add(zip5);
			parms.add(zip4);
		}
		if (!searchGroup.isEmpty()) {
			sql.append(" AND GN.GROUP_NAME LIKE ?");
			parms.add(StringUtil.appendWildCardCharacter(searchGroup, false, true));
		}
		if (!searchGroupId.isEmpty()) {
			sql.append(" AND GP.GRP_ID = ? ");
			parms.add(searchGroupId);
		}
		if (!searchProdId.isEmpty()) {
			sql.append(" AND GP.PRODUCT_ID = ?");
			parms.add(searchProdId);
		}
		if (!searchProd.isEmpty()) {
			sql.append(" AND PN.PRODUCT_NAME LIKE ?");
			parms.add(StringUtil.appendWildCardCharacter(searchProd, false, true));
		}
		if (!searchPlan.isEmpty()) {
			sql.append(" AND GP.PLAN_ID = ?");
			parms.add(searchPlan);
		}
		if (!searchPbp.isEmpty()) {
			sql.append(" AND GP.PBP_ID = ?");
			parms.add(searchPbp);
		}
		if (!searchSegment.isEmpty()) {
			sql.append(" AND GP.PBP_SEGMENT_ID = ?");
			parms.add(searchSegment);
		}
		if (applType.equals(EEMConstants.OPTION_APPLNEWMBR_MA) || applType.equals(EEMConstants.OPTION_CNTRCHG_MA)) {
			sql.append(" AND GP.PLAN_DESIGNATION IN ('MA','CO','MAPD','COPD','PACE','MMP')");
		} else if (applType.equals(EEMConstants.OPTION_APPLNEWMBR_PD)
				|| applType.equals(EEMConstants.OPTION_CNTRCHG_PD)) {
			sql.append(" AND GP.PLAN_DESIGNATION = 'PDP'");
		}
		return jdbcTemplate.query(sql.toString(), new ApplProductRowMapper(codeCache), parms.toArray());
	}

	private StringBuilder getProdQuery() {
		return new StringBuilder("SELECT DISTINCT GP.GRP_ID, GN.GROUP_NAME, GP.PRODUCT_ID, PN.PRODUCT_NAME,")
				.append(" GP.PLAN_ID, GP.PBP_ID, GP.PBP_SEGMENT_ID, GP.EGHP_IND, GP.PLAN_DESIGNATION,")
				.append(" SA.SRVC_AREA_ID, SA.SRVC_AREA_NAME, SAZ.SSA_ST, SAZ.SSA_CNTY,")
				.append(" SAZ.ZIP_CD5_LOW, SAZ.ZIP_CD4_LOW, SAZ.ZIP_CD5, SAZ.ZIP_CD4,")
				.append(" GP.PRTC_PREMIUM_AMT, GP.PRTD_PREMIUM_AMT, GP.SUPPL_PREMIUM_AMT,")
				.append(" GP.PREMIUM_REDUCTION_AMT, GP.DSBREBATE_AMT, GP.SNP_IND,GP.LINE_OF_BIZ")
				.append(" FROM EM_SVC_AREA_ZIP SAZ JOIN EM_GRP_PRODUCT_SVC_AREA GPSA")
				.append(" ON GPSA.CUSTOMER_ID = SAZ.CUSTOMER_ID")
				.append(" AND GPSA.SRVC_AREA_ID = SAZ.SRVC_AREA_ID JOIN EM_GRP_PRODUCT GP")
				.append(" ON GP.CUSTOMER_ID = GPSA.CUSTOMER_ID AND GP.GRP_ID = GPSA.GRP_ID")
				.append(" AND GP.PRODUCT_ID = GPSA.PRODUCT_ID JOIN EM_SVC_AREA SA")
				.append(" ON SA.CUSTOMER_ID = GPSA.CUSTOMER_ID AND SA.SRVC_AREA_ID = GPSA.SRVC_AREA_ID")
				.append(" JOIN EM_PRODUCT_NAME PN ON PN.CUSTOMER_ID = GP.CUSTOMER_ID")
				.append(" AND PN.PRODUCT_ID = GP.PRODUCT_ID JOIN EM_GRP_NAME GN")
				.append(" ON GN.CUSTOMER_ID = GP.CUSTOMER_ID AND GN.GRP_ID = GP.GRP_ID")
				.append(" WHERE SAZ.CUSTOMER_ID = ?").append(" AND ? BETWEEN SAZ.ZIP_START_DATE AND SAZ.ZIP_END_DATE")
				.append(" AND ? BETWEEN GPSA.GPSVCAREA_START_DATE AND GPSA.GPSVCAREA_END_DATE")
				.append(" AND ? BETWEEN GP.GRP_PROD_START_DATE AND GP.GRP_PROD_END_DATE")
				.append(" AND ? BETWEEN SA.SVC_START_DATE AND SA.SVC_END_DATE")
				.append(" AND ? BETWEEN PN.PRODNAME_START_DATE AND PN.PRODNAME_END_DATE")
				.append(" AND ? BETWEEN GN.GRPNAME_START_DATE AND GN.GRPNAME_END_DATE");
	}

}
