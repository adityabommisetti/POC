package com.medicare.mss.domainobject;

import lombok.Data;

@Data
public class EEMGrpProductDO {
	
	private String customerId;
	private String grpId;
	private String productId;
	private String grpProdStartDate;
	private String grpProdEndDate;
	private String planId;
	private String pbpId;
	private String pbpSegmentId;
	private String planDesignation;
	private String rxBin;
	private String rxPcn;
	private String rxGroup;
	private double prtCPremiumAmt;
	private double prtDPremiumAmt;
	private double supplPremiumAmt;
	private double premiumReductionAmt;
	private double csrRebateAmt;
	private double msbRebateAmt;
	private double bprRebateAmt;
	private double dsbRebateAmt;
	private String groupProudStatus;
	private String optOutInd;
	private String splitLisInd;
	private String rdsWaiverInd;
	private String esrdWaiverInd;
	private String snpInd;
	private String eghpInd;
	private int extendMonthsCnt;
	private String defaultGrpProdInd;
	private String billInd;
	private double forgiveAmt;
	private String lastUpdtTime;
	private String lastUpdtUserid;


}
