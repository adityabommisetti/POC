/**
 * 
 */
package com.medicare.mss.vo;

import lombok.Data;

/**
 * @author SUSDASH
 *
 */
@Data
public class MBD {
	
	private String birthDate;
    private int cara_Reccnt;
    private String coEghpId;
    private String coEnrollSourceCode;
    private String copayLevelId1;
    private String copayLevelId2;
    private String coPbpId;
    private String coPlanDisEnrollDate;
    private String coPlanDrugInd;
    private String coPlanEnrollDate;
    private String coPlanId;
    private String coPlanTypeCode;
    private String countyCd;
    private String deathDate;
    private String eghpInd;
    private String electionType;
    private String eligibilitySrcTable;
    private String enrollmentStatus;
    private String enrollSourceCode;
    private String esrdEndDate;
    private String esrdInd;
    private String esrdStartDate;
    private String firstName;
    private String genderCd;
    private String ghpClaimNbr;
    private String hicNbr;
    private String hospiceEndDate;
    private String hospiceInd;
    private String hospiceStartDate;
    private String inactiveMBI;
    private int incarcerationCnt;
    private String instEndDate;
    private String instInd;
    private String instStartDate;
    private boolean ishicxref;
    private String lastName;
    private String lastUsedSepDate;
    private String livingStatus;   
    private String mbi;
    private String medicEndDate;
    private String medicInd;
    private String medicStartDate;
    private String middleInit;
    private String partDPremsubsPct1;
    private String partDPremsubsPct2;
    private String pbpEndDate;
    private String pbpId;
    private String pbpStartDate;
    private String planDisenrollDate;
    private String planDrugInd;
    private String planEnrollDate;
    private String planId;
    private String planTypeCode;
    private String prior1DrugPlanInd;
    private String prior1EghpInd;
    private String prior1EnrollSourceCode;
    private String prior1PbpId;
    private String prior1PlanEnrollmentDate;
    private String prior1PlanEnrollmentEndDate;
    /** PRIOR 1 **/
	private String prior1PlanId;
    private String prior1PlanType;
	private String prior2DrugPlanInd;
	
    private String prior2EghpInd;
    private String prior2EnrollSourceCode;
    private String prior2PbpId;
    private String prior2PlanEnrollmentDate;

    private String prior2PlanEnrollmentEndDate;
    /** PRIOR 2 **/
	private String prior2PlanId;

    private String prior2PlanType;
	private String priorBIC;

	private String prtAEntitleDate;
	private String prtAEntitleEndDate;
	
	private String prtAOption;
	private String prtBEntitleDate;
	private String prtBEntitleEndDate;
	private String prtBOption;
	private String prtDEligibleDate;
	private String raceCd;
	private String segmentId;
	private String stateCd;
	
	private String subsidyEndDate1;
	private String subsidyEndDate2;
	private String subsidyStartDate1;
	private String subsidyStartDate2;
	private String uncovMonths;
	private int unLawfulPresCnt;
	private String wrkagedEndDate;
	private String wrkagedInd;
	
	private String wrkagedStartDate;
	private String xrefClaimNbr;
	
	private String zipCd;


}
