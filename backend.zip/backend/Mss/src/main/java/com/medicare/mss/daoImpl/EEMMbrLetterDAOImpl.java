package com.medicare.mss.daoImpl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMMbrLetterDAO;
import com.medicare.mss.domainobject.EEMMbrCorrDmsDO;
import com.medicare.mss.domainobject.EmCorrMbrDO;
import com.medicare.mss.domainobject.EmCorrVarDataDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.util.StringUtil;

@Repository
public class EEMMbrLetterDAOImpl implements EEMMbrLetterDAO {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private JdbcTemplate oracleJdbcTemplate;
	
	@Override
	public List<EmCorrVarDataDO> getMbrLetterData(Map<String, String> searchParamMap) {

		String customerId = StringUtil.nonNullTrim(searchParamMap.get("customerId"));
		String fileBatchId = StringUtil.nonNullTrim(searchParamMap.get("fileBatchId"));
		String recordType = StringUtil.nonNullTrim(searchParamMap.get("recordType"));
		String primaryId = StringUtil.nonNullTrim(searchParamMap.get("primaryId"));
		String letterName = StringUtil.nonNullTrim(searchParamMap.get("letterName"));

		List<String> params = new ArrayList<>();

		StringBuilder sQuery = new StringBuilder("SELECT CVD.VARIABLE_SEQ_NBR, ")
				.append("CVD.VARIABLE_ID,CCV.VARIABLE_DESC, CVD.VARIABLE_DATA FROM EM_CORR_VAR_DATA CVD ")
				.append("LEFT OUTER JOIN EM_CORR_CTL_VAR CCV ON CCV.CUSTOMER_ID = CVD.CUSTOMER_ID ")
				.append("AND CCV.LETTER_NAME = CVD.LETTER_NAME AND CCV.VARIABLE_ID = CVD.VARIABLE_ID ")
				.append("AND CCV.VARIABLE_SEQ_NBR = CVD.VARIABLE_SEQ_NBR ")
				.append("WHERE CVD.CUSTOMER_ID = ? AND CVD.PRIMARY_ID = ? ");

		params.add(customerId);
		params.add(primaryId);

		if (!fileBatchId.isEmpty()) {
			sQuery.append(" AND CVD.FILE_BATCH_ID = ?  ");
			params.add(fileBatchId);
		}

		if (!recordType.isEmpty()) {
			sQuery.append(" AND CVD.RECORD_TYPE = ?  ");
			params.add(recordType);
		}

		if (!letterName.isEmpty()) {
			sQuery.append(" AND CVD.LETTER_NAME = ?  ");
			params.add(letterName);
		}
		sQuery.append(" ORDER BY CVD.VARIABLE_SEQ_NBR ");

		Object[] objPrams = params.toArray();
		try {
			return jdbcTemplate.query(sQuery.toString(),
					new DomainPropertyRowMapper<EmCorrVarDataDO>(EmCorrVarDataDO.class), objPrams);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}

	}

	@Override
	public List<EmCorrMbrDO> getMbrLetterSelect(String customerId, String primaryId) {

		StringBuilder sQuery = new StringBuilder(
				"SELECT CM.DMS_ID, CM.CUSTOMER_ID, CM.PDF_ARCHIVAL, CM.FILE_BATCH_ID, CM.RECORD_TYPE, CM.PRIMARY_ID, CM.LETTER_NAME, ")
						.append("CTL.DESCRIPTION, CM.REQUEST_DATE, CM.ORIG_MAIL_DATE, ")
						.append("CM.LAST_MAIL_DATE, CM.DELETE_IND, CM.RECORD_STATUS, CM.SUPPLEMENTAL_ID,CM.CREATE_TIME, CM.CREATE_USERID, CM.LAST_UPDT_TIME, CM.LAST_UPDT_USERID, ")
						.append("CM.PRINT_DATE,CM.RESPONSE_DUE_DATE,CM.REPRINT_DATE, CM.RESPONSE_DATE ")
						.append("FROM EM_CORR_MBR CM LEFT OUTER JOIN EM_CORR_CTL CTL ON CTL.CUSTOMER_ID = CM.CUSTOMER_ID AND CTL.LETTER_NAME = CM.LETTER_NAME ")
						.append("WHERE CM.CUSTOMER_ID = ? ")
						.append("AND CM.PRIMARY_ID =? ORDER BY CM.REQUEST_DATE DESC, CM.FILE_BATCH_ID DESC, CM.RECORD_TYPE, CM.PRIMARY_ID, CM.LETTER_NAME ");

		try {
			List<EmCorrMbrDO> mbrLetterDOList = jdbcTemplate.query(sQuery.toString(),
					new DomainPropertyRowMapper<EmCorrMbrDO>(EmCorrMbrDO.class), customerId, primaryId);
			return checkAvailabilityOfLetters(mbrLetterDOList);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	private List<EmCorrMbrDO> checkAvailabilityOfLetters(List<EmCorrMbrDO> lettersList) {

		for (int index = 0, listLen = lettersList.size(); index < listLen; index++) {
			EmCorrMbrDO mbrLetterDO = lettersList.get(index);

			if ("Y".equalsIgnoreCase(mbrLetterDO.getPdfArchival())) {
				mbrLetterDO.setLetterAvailabilityInDB("Y");
			} else {

				StringBuilder sQuery = new StringBuilder(
						"SELECT LETTER_CREATION_TIME, SOURCE FROM EM_CORR_DMS WHERE CUSTOMER_ID = ? AND PRIMARY_ID = ? AND ")
								.append(" CUSTOMER_LETTER_NAME = ? AND FILE_BATCH_ID = ? ORDER BY LETTER_CREATION_TIME DESC ");

				Object[] objPrams = new Object[] {mbrLetterDO.getCustomerId(), mbrLetterDO.getPrimaryId()
						, mbrLetterDO.getLetterName(), mbrLetterDO.getFilebatchid()};

				try {

					List<EEMMbrCorrDmsDO> mbrLetterEmCorrDmsDOList = jdbcTemplate.query(sQuery.toString(),
							new DomainPropertyRowMapper<EEMMbrCorrDmsDO>(EEMMbrCorrDmsDO.class), objPrams);

					if (CollectionUtils.isEmpty(mbrLetterEmCorrDmsDOList)) {
						mbrLetterDO.setSource("");
						mbrLetterDO.setLetterUploadedTime("");
						mbrLetterDO.setLetterAvailabilityInDB("N");
					} else {
						mbrLetterDO.setLetterUploadedTime(mbrLetterEmCorrDmsDOList.get(0).getLetterCreationTime());
						mbrLetterDO.setSource(mbrLetterEmCorrDmsDOList.get(0).getSource());
						mbrLetterDO.setLetterAvailabilityInDB("Y");
					}

				} catch (DataAccessException exp) {
					throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
				}
			}
		}
		return lettersList;

	}

	@Override
	public byte[] getDisplayDocumentFromDB(Map<String, String> searchParamMap) {
		String customerId = StringUtil.nonNullTrim(searchParamMap.get("customerId"));
		String primaryId = StringUtil.nonNullTrim(searchParamMap.get("primaryId"));
		String letterName = StringUtil.nonNullTrim(searchParamMap.get("letterName"));
		String letterUploadedTime = StringUtil.nonNullTrim(searchParamMap.get("letterUploadedTime"));
		String pdfArchival = StringUtil.nonNullTrim(searchParamMap.get("pdfArchival"));
		java.sql.Blob blob = null;		
			
		List<Object> params = new ArrayList<Object>();
		params.add(customerId);
		params.add(primaryId);
		params.add(letterName);
		
		byte[] blobByte = null;
		StringBuilder sQuery = new StringBuilder("SELECT LETTER_PDF FROM EM_CORR_DMS WHERE TRIM(CUSTOMER_ID) = ? ")
				.append("AND TRIM(PRIMARY_ID) = ? AND TRIM(CUSTOMER_LETTER_NAME) = ?");
		try {
			if ("Y".equalsIgnoreCase(pdfArchival)) {
				sQuery.append("ORDER BY LETTER_CREATION_TIME DESC FETCH FIRST ROW ONLY");
				blob = oracleJdbcTemplate.queryForObject(sQuery.toString(), params.toArray(), java.sql.Blob.class);

			} else {
				params.add(letterUploadedTime);
				sQuery.append("AND LETTER_CREATION_TIME = ?  FETCH FIRST ROW ONLY");
				blob = jdbcTemplate.queryForObject(sQuery.toString(), params.toArray(), java.sql.Blob.class);
			}

			blobByte = blob.getBytes(1, (int) blob.length());

		} catch (EmptyResultDataAccessException exp) {
			throw new ApplicationException(exp, "PDF file is not available");
		} catch (SQLException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
		return blobByte;

	}
}
