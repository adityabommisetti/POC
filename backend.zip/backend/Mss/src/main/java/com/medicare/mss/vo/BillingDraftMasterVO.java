package com.medicare.mss.vo;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class BillingDraftMasterVO implements Serializable {

	private static final long serialVersionUID = -3898108343227772781L;
	
	private List<BillingDraftHeaderVO> billingDraftHeaderVOList;
	private List<BillingDraftDetailVO> billingDraftDetailVOList;
	private boolean nextPage;
}
