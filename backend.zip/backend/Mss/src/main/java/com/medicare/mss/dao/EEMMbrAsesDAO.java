package com.medicare.mss.dao;

import java.util.List;

import com.medicare.mss.domainobject.EEMMbrAsesDO;

public interface EEMMbrAsesDAO extends EEMMbrBaseDAO {

	List<EEMMbrAsesDO> getMbrAses(String customerId, String memberId, String showAll);

	List<EEMMbrAsesDO> getDatesFromPlanVersionXWalk(EEMMbrAsesDO newVO);

}
