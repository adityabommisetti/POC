package com.medicare.mss.vo;

import lombok.Data;

@Data
public class CARAHistoryVO {
	
	private String endDate;
	private String hic_mbi_nbr;
	private int sec_nbr;
	private String startDate;

}