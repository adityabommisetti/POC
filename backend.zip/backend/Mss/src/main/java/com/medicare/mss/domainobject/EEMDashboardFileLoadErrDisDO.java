package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMDashboardFileLoadErrDisDO {
	public EEMDashboardFileLoadErrDisDO(String appType) {
		this.appType = appType;
		this.loaded = "0";
		this.errored = "0";
		this.rejected = "0";
	}

	public EEMDashboardFileLoadErrDisDO() {

	}

	@ColumnMapper(columnName = "APPLICATION_TYPE", propertyName = "appType")
	private String appType;
	@ColumnMapper(columnName = "LOADED", propertyName = "loaded")
	private String loaded;
	@ColumnMapper(columnName = "ERRORED", propertyName = "errored")
	private String errored;
	@ColumnMapper(columnName = "REJECTED", propertyName = "rejected")
	private String rejected;
}
