package com.medicare.mss.dao;

public interface EEMMbrSOADAO extends EEMMbrBaseDAO {


	byte[] displayDocumentFromDB(String primaryId, String customerId);

}
