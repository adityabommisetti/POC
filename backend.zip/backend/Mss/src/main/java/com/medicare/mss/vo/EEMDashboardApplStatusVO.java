package com.medicare.mss.vo;

import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
public class EEMDashboardApplStatusVO {

	private int applId;
	private String medicareId;
	private String applStatus;
	private String applType;
	private String recieveDate;
	private String activationDate;
	private String firstName;
	private String lastName;
	private String birthDate;
	private String prodName;
	private String assignedToUser;
	private int ageingDays;

	public void setRecieveDate(String recieveDate) {
		this.recieveDate = DateFormatter.reFormat(recieveDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = DateFormatter.reFormat(birthDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setActivationDate(String activationDate) {
		this.activationDate = DateFormatter.reFormat(activationDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

}
