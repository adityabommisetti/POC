package com.medicare.mss.vo;

import lombok.Data;

@Data
public class EEMFieldErrorVO {
	
private String errorCd;
	
	private String errorData;
	
	private String errorType;
	
	private String errorMessage;
	
	private String formField;
	
	private String fieldNbr;
	
	private String editValidVal;
	
	private String editRuleId;
	
	private String exceptionVal;
	
	private String requiredInd;
	
	private String customerId;
	
	private String editFrom;
	
	private String editTo;
	
}
