package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMWFUserDO {

	@ColumnMapper(columnName = "MANAGER_ID", propertyName = "supervisorId")
	private String supervisorId;
	@ColumnMapper(columnName = "SUPERVISORNAME", propertyName = "supervisorName")
	private String supervisorName;
	@ColumnMapper(columnName = "USER_ID", propertyName = "userId")
	private String userId;
	@ColumnMapper(columnName = "USER_LEVEL", propertyName = "userLevel")
	private String userLevel;
	@ColumnMapper(columnName = "USERNAME", propertyName = "userName")
	private String userName;

}
