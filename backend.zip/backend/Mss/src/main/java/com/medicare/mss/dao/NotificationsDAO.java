package com.medicare.mss.dao;

import java.util.List;

import com.medicare.mss.domainobject.NotificationDO;

public interface NotificationsDAO {

	List<NotificationDO> getNotifications(String customerId, String lastNotifTime, String signOffTime);

}
