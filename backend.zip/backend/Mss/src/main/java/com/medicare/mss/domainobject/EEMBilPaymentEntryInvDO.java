package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMBilPaymentEntryInvDO {

	@ColumnMapper(columnName = "INVOICE_NBR", propertyName = "invoiceNbr")
	private String invoiceNbr;
	@ColumnMapper(columnName = "ITEM_NBR", propertyName = "itemNumber")
	private String itemNumber;
	@ColumnMapper(columnName = "APPLIED_AMT", propertyName = "appliedAmount")
	private String appliedAmount;
	@ColumnMapper(columnName = "CREATE_TIME", propertyName = "createTime")
	private String createTime;
	@ColumnMapper(columnName = "CREATE_USERID", propertyName = "createUserId")
	private String createUserId;
	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;
	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserId")
	private String lastUpdtUserId;
}
