package com.medicare.mss.controller;

import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.service.NotificationsService;
import com.medicare.mss.vo.EMWFMasterVO;
import com.medicare.mss.vo.NotificationVO;

@RestController
@RequestMapping(path = "/notifications")
public class NotificationsController {
	@Autowired
	private NotificationsService notificationsService;

	@GetMapping(ReqMappingConstants.MEDICARE_NOTIFICATIONS_STREAM)
	public ResponseEntity<JSONResponse> medicareNotifStream() throws ApplicationException {
		List<NotificationVO> notifList = notificationsService.getNotifications();
		return sendResponse(notifList);
	}

	/*
	 * @GetMapping(ReqMappingConstants.MEDICARE_NOTIFICATIONS_STREAM) public void
	 * medicareNotifStream(HttpServletRequest request, HttpServletResponse response)
	 * throws IOException { // content type must be set to text/event-stream
	 * response.setContentType("text/event-stream;charset=UTF-8"); // cache must be
	 * set to no-cache response.setHeader("Cache-Control", "no-cache"); // encoding
	 * is set to UTF-8 // response.setCharacterEncoding("UTF-8");
	 * response.setHeader("Access-Control-Allow-Origin", "*"); PrintWriter writer =
	 * response.getWriter();
	 * sessionHelper.getSession().setAttribute("pwdExpNotified", false); while
	 * (sessionHelper.getUserInfo() != null) {
	 * 
	 * String lastNotifId = (String)
	 * sessionHelper.getSession().getAttribute("lastNotifId");
	 * LOG.info("Notif:Before invoking"); List<NotificationVO> notifList =
	 * notificationsService.getNotifications(lastNotifId);
	 * LOG.info("Notif:Before Sending :" + notifList); String json = new
	 * Gson().toJson(notifList); writer.write("data:message:" + json + "\n\n");
	 * LOG.info("Notif:Sending :" + json + writer.checkError()); if
	 * (writer.checkError()) { break; } writer.flush(); LOG.info("Notif:Flusing :" +
	 * json + writer.checkError()); if (notifList.size() > 0) { String id =
	 * notifList.get(0).getNotifId(); if (!id.equals("0")) {
	 * sessionHelper.getSession().setAttribute("lastNotifId",
	 * notifList.get(0).getNotifId()); } } try { Thread.sleep(10000); } catch
	 * (InterruptedException e) { // e.printStackTrace(); }
	 * LOG.info("Notif:End of loop :"); } LOG.info("Notif:closing:");
	 * writer.close(); }
	 */

	private ResponseEntity<JSONResponse> sendResponse(Object result) {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;

		if (Objects.isNull(result)) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setData(result);
			jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
			jsonResponse.setMessage(getStatusMessage(result));
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}

	private String getStatusMessage(Object result) {
		String msg = EEMConstants.SUCCESS;
		if (result instanceof EMWFMasterVO && StringUtils.isNotBlank(((EMWFMasterVO) result).getMessage())) {
			msg = ((EMWFMasterVO) result).getMessage();
		}
		return msg;
	}

}
