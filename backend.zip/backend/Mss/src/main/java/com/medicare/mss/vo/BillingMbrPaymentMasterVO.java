package com.medicare.mss.vo;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class BillingMbrPaymentMasterVO implements Serializable {

	private static final long serialVersionUID = 7043530271899925569L;
	
	private List<BillingMbrPaymentsVO> mbrPaymentsVO;
	private List<BillingMbrPymntDtlInvcVO> mbrPymntDtlInvcVO;
	private boolean nextPage;
}
