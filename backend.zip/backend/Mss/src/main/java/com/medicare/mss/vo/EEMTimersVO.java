package com.medicare.mss.vo;

import java.io.Serializable;

import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
public class EEMTimersVO implements Serializable {

	private static final long serialVersionUID = 3839425243157549788L;

	private String customerId;
	private String primaryId;
	private String triggerType;
	private String activationTime;
	private String creationTime;
	private String editActivationDateStatus;
	private String sourceType;
	private String triggerCode;
	private String timerType;
	private String status;
	private String trgSource;
	private String lastUpdtTime;
	private String lastUpdtUserId;
	private String planId;
	private String pbpId;
	private String planDesignation;
	private String checkStatus;
	

	public String getActivationTimeFrmt() {
		return DateFormatter.reFormat(activationTime, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setActivationTimeFrmt(String activationTime) {
		this.activationTime = DateFormatter.reFormat(activationTime, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getEditActivationDateStatusFrmt() {
		return DateFormatter.reFormat(editActivationDateStatus, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}
	public void setEditActivationDateStatusFrmt(String editActivationDateStatus) {
		this.editActivationDateStatus = DateFormatter.reFormat(editActivationDateStatus, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
	}

}
