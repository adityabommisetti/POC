package com.medicare.mss.daoImpl;

import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMTimersDAO;
import com.medicare.mss.domainobject.EEMTimersDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.TimersRowMapper;
import com.medicare.mss.util.PaginationQueryHelper;
import com.medicare.mss.vo.DataBaseField;
import com.medicare.mss.vo.PageableVO;

@Repository
public class EEMTimersDAOImpl implements EEMTimersDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public PageableVO getTimersList(Map<String, String> searchParamMap, String customerId, boolean isPagination) {
		
		String searchType = trimToEmpty(searchParamMap.get("searchType"));
		//pagination related fields
		String primaryId = trimToEmpty(searchParamMap.get("primaryId"));
		String triggerType = trimToEmpty(searchParamMap.get("triggerType"));
		String effDate = trimToEmpty(searchParamMap.get("activationTime"));
		String createTime = trimToEmpty(searchParamMap.get("creationTime"));
		
		ArrayList<String> parmList = new ArrayList<>();
		PageableVO response = new PageableVO();
		EEMTimersDO eMTimersDO = new EEMTimersDO();
		eMTimersDO.setSourceType(searchType);
		
		StringBuilder query = buildTimersQuery(searchParamMap, customerId, parmList);

		try {
			
			if (isPagination) {
				DataBaseField[] conds = new DataBaseField[4];
				for (int i = 0; i < conds.length; i++) {
					conds[i] = new DataBaseField();
				}
				
				if (searchType.equals("A")) {
					conds[0].setFieldName("Z.APPLICATION_ID");
				} else {
					conds[0].setFieldName("Z.MEMBER_ID");
				}
				conds[0].setStringValue(primaryId);
				
				conds[1].setFieldName("Z.TRIGGER_TYPE");
				conds[1].setStringValue(triggerType);

				conds[2].setFieldName("Z.EFFECTIVE_DATE");
				conds[2].setStringValue(effDate);
				
				conds[3].setFieldName("Z.CREATE_TIME");
				conds[3].setStringValue(createTime);
				
				StringBuilder pageCond = PaginationQueryHelper.pagingElements(conds, parmList);
				query.append(pageCond);
			}
			
			query.append(" ORDER BY Z.CUSTOMER_ID,");
			if (searchType.equals("A")) {
				query.append(" Z.APPLICATION_ID,");
			} else {
				query.append(" Z.MEMBER_ID,");
			}
			query.append(" Z.TRIGGER_TYPE, Z.EFFECTIVE_DATE, Z.CREATE_TIME ");
			query.append(" FETCH FIRST ").append(EEMConstants.DB_MAX_RECORD_FETCH).append(" ROWS ONLY ");
			
			List<EEMTimersDO> eemTimerDOList = jdbcTemplate.query(query.toString(), parmList.toArray(), new TimersRowMapper());
			
			if (!CollectionUtils.isEmpty(eemTimerDOList)) {
				if (eemTimerDOList.size() > 100) {
					eemTimerDOList.remove(eemTimerDOList.size() - 1);
					response.setNextPage(true);
				}
			}
			response.setContent(eemTimerDOList);
			return response;
			
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error ocurred while getTimersList!");
		}
	}

	private StringBuilder buildTimersQuery(Map<String, String> searchParamMap, String customerId, List<String> parmList) {

		String searchType = trimToEmpty(searchParamMap.get("searchType"));
		String searchId = trimToEmpty(searchParamMap.get("searchId"));
		String status = trimToEmpty(searchParamMap.get("status"));
		String triggerCode = trimToEmpty(searchParamMap.get("triggerCode"));
		
		StringBuilder query = new StringBuilder();
		query.append("SELECT Z.CUSTOMER_ID,");

		if (searchType.equals("A")) {
			query.append(" 'A' AS SOURCE_TYPE, Z.APPLICATION_ID AS PRIMARY_ID,");
		} else {
			query.append(" 'M' AS SOURCE_TYPE, Z.MEMBER_ID AS PRIMARY_ID,");
		}
		query.append(" Z.TRIGGER_TYPE, Z.TRIGGER_STATUS, Z.EFFECTIVE_DATE,")
				.append(" Z.CREATE_TIME, Z.TRIGGER_CODE, T.TRIGGER_DESC, Z.LAST_UPDT_TIME, Z.LAST_UPDT_USERID");
		if (searchType.equals("A")) {
			query.append(" FROM EM_APPL_TRIGGER Z");
		} else {
			query.append(", Z.PLAN_ID, Z.PBP_ID, Z.PLAN_DESIGNATION FROM EM_MBR_TRIGGER Z");
		}
		query.append(" LEFT JOIN EM_TRIGGERCODE T ON T.TRIGGER_CODE = Z.TRIGGER_CODE AND T.TRIGGER_TYPE =")
				.append(" Z.TRIGGER_TYPE WHERE Z.TRIGGER_TYPE IN ('FUA','FUM') AND Z.CUSTOMER_ID = ?");

		
		parmList.add(customerId);

		if (!searchId.equals("")) {
			if (searchType.equals("A")) {
				query.append(" AND Z.APPLICATION_ID = ?");
				parmList.add(searchId);
			} else {
				query.append(" AND Z.MEMBER_ID = ?");
				parmList.add(searchId);
			}
		}
		if (status.equalsIgnoreCase("A")) {
			query.append(" AND Z.TRIGGER_STATUS IN ('OPEN', 'CLOSED', 'EXPIRED', 'ACTIVE')");
		} else if (status.equalsIgnoreCase("O")) {
			query.append(" AND Z.TRIGGER_STATUS IN ( 'OPEN', 'ACTIVE')");
		} else if (status.equalsIgnoreCase("C")) {
			query.append(" AND Z.TRIGGER_STATUS IN ('CLOSED', 'EXPIRED')");
		}
		if (!triggerCode.equalsIgnoreCase("")) {
			query.append(" AND T.TRIGGER_CODE = ?");
			parmList.add(triggerCode);
		}
		return query;
	}

	@Override
	public int updateTimer(EEMTimersDO eemTimersDO, String userId) {

		String searchType = eemTimersDO.getSourceType();

		int sqlCnt = 0;
		try {
			StringBuilder query = new StringBuilder();

			query.append(" UPDATE");

			if (searchType.equals("A")) {
				query.append(" EM_APPL_TRIGGER");
			} else {
				query.append(" EM_MBR_TRIGGER");
			}
			query.append(" SET TRIGGER_STATUS = 'CANCELLED', LAST_UPDT_TIME = CURRENT_TIMESTAMP,")
					.append(" LAST_UPDT_USERID = ? WHERE CUSTOMER_ID = ?");

			if (searchType.equals("A")) {
				query.append(" AND APPLICATION_ID = ?");
			} else {
				query.append(" AND MEMBER_ID = ?");
			}
			query.append(" AND TRIGGER_TYPE = ? AND EFFECTIVE_DATE = ? AND CREATE_TIME = ?");

			Object[] parms = new Object[] { userId, eemTimersDO.getCustomerId(), eemTimersDO.getPrimaryId(),
					eemTimersDO.getTriggerType(), eemTimersDO.getActivationTime(), eemTimersDO.getCreationTime() };

			sqlCnt = jdbcTemplate.update(query.toString(), parms);

		} catch (Exception exp) {
			throw new ApplicationException(exp);
		}
		return sqlCnt;
	}

}
