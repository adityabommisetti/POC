package com.medicare.mss.controller;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.service.EEMMbrAddressServices;
import com.medicare.mss.vo.EEMMbrAddressVO;

@RestController
@RequestMapping(ReqMappingConstants.MEMBER)
public class EEMMbrAddressController {
	@Autowired
	private EEMMbrAddressServices mbrAddressService;
	
	@GetMapping(path = ReqMappingConstants.MBR_ADDRESS_SEARCH)
	public ResponseEntity<JSONResponse> getMbrAddressInfos(@PathVariable(name = "mbrId") String memberId,
			@PathVariable(name = "showAll") String showAll) throws ApplicationException {
		List<EEMMbrAddressVO> mbrAddressInfoList = mbrAddressService.getListFromContext(memberId, showAll);
		
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;

		if (CollectionUtils.isEmpty(mbrAddressInfoList)) {
			response = buildFailureResponse(jsonResponse, "No Records Found");
		} else {
			response = buildSuccessResponse(jsonResponse, mbrAddressInfoList);
		}
		return response;
		
	}

	private ResponseEntity<JSONResponse> buildSuccessResponse(JSONResponse jsonResponse, Object responseData) {
		jsonResponse.setMessage(EEMConstants.SUCCESS);
		jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
		jsonResponse.setData(responseData);
		return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
	}
	private ResponseEntity<JSONResponse> buildFailureResponse(JSONResponse jsonResponse, String message) {
		jsonResponse.setStatus(HttpStatus.NO_CONTENT.getReasonPhrase());
		jsonResponse.setMessage(message);	
		jsonResponse.setData(null);
		return new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
	}
	
	@PostMapping(path = ReqMappingConstants.MBR_ADDRESS_UPDATE)
	public ResponseEntity<JSONResponse> mbrAddressUpdate(@RequestBody EEMMbrAddressVO mbrAddressInfoVO) throws ApplicationException, ParseException, CloneNotSupportedException {
		JSONResponse jsonResponse = new JSONResponse();
			
		Map<String, Object>  resultMap = mbrAddressService.updtMbrAddress(mbrAddressInfoVO);
	
		return buildSuccessResponse(jsonResponse, resultMap);		
	}
	@PostMapping(path = ReqMappingConstants.MBR_ADDRESS_DELETE)
	public ResponseEntity<JSONResponse> mbrAddressDelete(@RequestBody EEMMbrAddressVO mbrAddressInfoVO) throws ApplicationException{
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response = null;
		
		List<EEMMbrAddressVO> mbrAddressInfoList =mbrAddressService.mbrAddressDelete(mbrAddressInfoVO);
		if(!CollectionUtils.isEmpty(mbrAddressInfoList)) {
			response = buildSuccessResponse(jsonResponse, mbrAddressInfoList);
		}else {
			buildFailureResponse(jsonResponse,"No Records Found");
		}
		return response;
	}
}
