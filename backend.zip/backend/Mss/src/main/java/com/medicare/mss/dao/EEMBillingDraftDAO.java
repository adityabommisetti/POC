package com.medicare.mss.dao;

import java.util.List;

import com.medicare.mss.domainobject.BillingDraftDetailDO;
import com.medicare.mss.vo.BillingDraftFormVO;
import com.medicare.mss.vo.BillingDraftHeaderVO;
import com.medicare.mss.vo.PageableVO;

public interface EEMBillingDraftDAO {

	PageableVO getBillingDraftSearchResults(BillingDraftFormVO billingDraftFormVO, boolean isPagination);

	List<BillingDraftDetailDO> getBillDraftDetail(BillingDraftHeaderVO billingDraftHeaderVO);

	double getDraftAmountForInvoice(BillingDraftHeaderVO billingDraftHeaderVO);

}
