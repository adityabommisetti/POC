package com.medicare.mss.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.caching.EEMProfileSettings;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMMbrCobDAO;
import com.medicare.mss.dao.EEMMbrDAO;
import com.medicare.mss.domainobject.EEMMbrCobDO;
import com.medicare.mss.domainobject.EEMMbrEnrollmentDO;
import com.medicare.mss.domainobject.EMMbrTriggerDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.EEMContext;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.vo.EEMMbrCobVO;
import com.medicare.mss.vo.EEMMbrEnrollmentVO;
import com.medicare.mss.vo.EMDatedSegmentVO;

@Service
public class EEMMbrCobService extends EEMMbrBaseService {

	@Autowired
	private EEMMbrCobDAO memberCobDAO;

	@Autowired
	private EEMMbrDAO eemEnrollDao;

	@Autowired
	EEMProfileSettings eemProfileSettings;

	@Autowired
	private EEMCodeCache eemCodeCache;
	
	@Autowired
	private EEMMbrDAO eemMbrDAO;

	@SuppressWarnings("unchecked")
	public List<EEMMbrCobVO> getMbrCobList(String memberId, String showAll) {

		List<EEMMbrCobVO> mbrCobVOList = sessionHelper.getEEMContext().getMbrMasterVO().getMbrCobVOList();
		
		if (StringUtils.equals(EEMConstants.VALUE_YES, showAll)) {
			List<EEMMbrCobVO> allInfos = getMbrCobListFromDB(memberId, showAll);
				mbrCobVOList = (List<EEMMbrCobVO>) getActiveDatedList(allInfos);
				setToContext(mbrCobVOList);
			return allInfos;
		} else {
			if (Objects.isNull(mbrCobVOList)) {
				mbrCobVOList = getMbrCobListFromDB(memberId, showAll);
				setToContext(mbrCobVOList);
			} else {
				mbrCobVOList = (List<EEMMbrCobVO>) getActiveDatedList(mbrCobVOList);
				setToContext(mbrCobVOList);
			}
			return mbrCobVOList;
		}
	}

	public List<EEMMbrCobVO> getMbrCobListFromDB(String memberId, String showAll) {

		List<EEMMbrCobVO> mbrCobVOList = new ArrayList<>();
		String customerId = sessionHelper.getUserInfo().getCustomerId();

		List<EEMMbrCobDO> mbrCobDOList = memberCobDAO.getMbrCob(customerId, memberId, showAll);
		if (!CollectionUtils.isEmpty(mbrCobDOList)) {
			mbrCobDOList.forEach(mbrCobDO -> {
				EEMMbrCobVO eEEMMbrCobVO = new EEMMbrCobVO();
				try {
					String cobDesc = eemCodeCache.getDesc(mbrCobDO.getCobType(), eemCodeCache.getLstCobTypes());
					if (cobDesc == null)
						mbrCobDO.setCobDesc(mbrCobDO.getCobType());
					else
						mbrCobDO.setCobDesc(cobDesc);

					String ohiDesc = eemCodeCache.getRelatedListValue(mbrCobDO.getCobType(), mbrCobDO.getOhiInd(),
							eemCodeCache.getLstOhiInd());
					if (ohiDesc == null)
						mbrCobDO.setOhiDesc(mbrCobDO.getOhiInd());
					else
						mbrCobDO.setOhiDesc(ohiDesc);
				} catch (Exception exp) {
					throw new ApplicationException(exp);
				}
				BeanUtils.copyProperties(mbrCobDO, eEEMMbrCobVO);
				mbrCobVOList.add(eEEMMbrCobVO);
			});
		}
		return mbrCobVOList;
	}

	@SuppressWarnings("unchecked")
	@Transactional(rollbackOn = ApplicationException.class)
	public List<EEMMbrCobVO> updateMbrCob(EEMMbrCobVO emMbrCobVO) {

		String userId = sessionHelper.getUserInfo().getUserId();
		String customerId = sessionHelper.getUserInfo().getCustomerId();

		EEMMbrCobDO wrkVO = new EEMMbrCobDO();
		BeanUtils.copyProperties(emMbrCobVO, wrkVO);

		List<EEMMbrCobVO> mbrCobVOList = getListFromContext(emMbrCobVO.getMemberId(), "N");
		List<EEMMbrCobDO> mbrCobDOLst = new ArrayList<>();
		CommonUtils.copyList(mbrCobVOList, mbrCobDOLst, EEMMbrCobDO.class);
		wrkVO.setCustomerId(customerId);
		wrkVO.setOverrideInd("N");
		wrkVO.setCobValidation(eemProfileSettings.getParmInd(wrkVO.getCustomerId(), EEMConstants.BYPASSCOBDATE,
				DateUtil.getTodaysDate()));
		boolean rslt = mbrCobUpdate(mbrCobDOLst, wrkVO, userId);
		if (rslt) {
			mbrCobVOList = getMbrCobListFromDB(emMbrCobVO.getMemberId(), emMbrCobVO.getShowAll());
			if (StringUtils.equals(EEMConstants.VALUE_NO, emMbrCobVO.getShowAll())) {
				setToContext(mbrCobVOList);
			} else {
				List<EEMMbrCobVO> mbrCobActiveVOList = (List<EEMMbrCobVO>) getActiveDatedList(mbrCobVOList);
				setToContext(mbrCobActiveVOList);
			}
		} else {
			throw new ApplicationException("Cob Update Failed");
		}
		return mbrCobVOList;
	}

	public boolean mbrCobUpdate(List<EEMMbrCobDO> mbrCobDOLst, EEMMbrCobDO newVO, String userId) {

		String ts = DateUtil.getCurrentDatetimeStamp();
		String bypassCOBDates = newVO.getCobValidation();
		Map<String, String> type = new HashMap<>();
		type.put("COB_TYPE", newVO.getCobType());
		int sqlCnt = 0;
		boolean result = false;
		try {
			String message = null;

			if (!"Y".equalsIgnoreCase(bypassCOBDates)) {
				message = checkDates(newVO);
			}
			if (message != null) {
				throw new ApplicationException(message);
			}
			String maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
					EEMConstants.EM_MBR_COB, type);
			List<? extends EMDatedSegmentVO> cobInfoLst = getDatedTypeList(mbrCobDOLst, newVO.getCobType());
			if (hasDataChanged(cobInfoLst, maxLastUpdate)) {
				throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
			}
			EEMMbrCobDO matchVO = null;

			matchVO = (EEMMbrCobDO) matchDatedSegment(cobInfoLst, newVO);
			if (matchVO != null) {
				return overrideDatedSegment(newVO, userId, ts, matchVO, type);
			}
			matchVO = (EEMMbrCobDO) matchDatedSegmentEndDate(cobInfoLst, newVO);
			if (matchVO != null) {
				return overrideDatedSegment(newVO, userId, ts, matchVO, type);
			}
			if (newVO.getEffEndDate().equals("99999999")) {

				EEMMbrCobDO oldOpenVO = (EEMMbrCobDO) getOpenendedSegment(cobInfoLst);

				List<? extends EMDatedSegmentVO> lstSegmentsAbove = getSegmentsAbove(cobInfoLst,
						newVO.getEffStartDate());
				Iterator<? extends EMDatedSegmentVO> it = lstSegmentsAbove.iterator();
				while (it.hasNext()) {
					EEMMbrCobDO itemVO = (EEMMbrCobDO) it.next();
					sqlCnt = memberCobDAO.setOverride(itemVO, userId);
					if (sqlCnt != 1) {
						throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_ABOVE);
					}
				}
				EEMMbrCobDO belowVO = (EEMMbrCobDO) getFirstOverlapSegmentBelow(cobInfoLst, newVO.getEffStartDate());
				if (belowVO != null) {
					sqlCnt = memberCobDAO.setOverride(belowVO, userId);
					if (sqlCnt != 1) {
						throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_BELOW);
					}
					if (belowVO.getEffStartDate().compareTo(newVO.getEffStartDate()) < 0) {
						EEMMbrCobDO tempVO = (EEMMbrCobDO) belowVO.clone();
						tempVO.setEffEndDate(DateMath.minusOneDay(newVO.getEffStartDate()));
						tempVO.setCreateTime(ts);
						tempVO.setCreateUserId(userId);
						tempVO.setLastUpdtTime(ts);
						tempVO.setLastUpdtUserId(userId);
						sqlCnt = memberCobDAO.insertMbr(tempVO);
						if (sqlCnt != 1) {
							throw new ApplicationException(EEMConstants.ERROR_SPLITING_SEGMENT_BELOW);
						}
					}
				}
				sqlCnt = addSegment(newVO, userId, ts);
				if (sqlCnt != 1) {
					throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
				}
				int rslt = cobTriggerCheck(oldOpenVO, newVO, userId);
				if (rslt > 0) {
					return false;
				}
				maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
						EEMConstants.EM_MBR_COB, type);
				if (hasDataChanged(ts, maxLastUpdate)) {
					throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
				}
				return true;
			}
			if (!doDatedSegmentAdjust(cobInfoLst, newVO, ts, userId, memberCobDAO)) {
				return false;
			}
			sqlCnt = addSegment(newVO, userId, ts);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
			}
			maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
					EEMConstants.EM_MBR_COB, type);
			if (hasDataChanged(ts, maxLastUpdate)) {
				throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
			}
			result = true;
		} catch (Exception exp) {
			throw new ApplicationException(exp.getMessage());
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	public List<EEMMbrCobVO> mbrcobDelete(EEMMbrCobVO emMbrCobVO) {

		String userId = sessionHelper.getUserInfo().getUserId();
		try {
			EEMMbrCobDO emMbrCobDO = new EEMMbrCobDO();
			BeanUtils.copyProperties(emMbrCobVO, emMbrCobDO);

			int sqlCnt = memberCobDAO.setOverride(emMbrCobDO, userId);
			if (sqlCnt == 1) {
				List<EEMMbrCobVO> mbrCobVOList = getMbrCobListFromDB(emMbrCobVO.getMemberId(), emMbrCobVO.getShowAll());
				if (StringUtils.equals(EEMConstants.VALUE_NO, emMbrCobVO.getShowAll())) {
					setToContext(mbrCobVOList);
				} else {
					List<EEMMbrCobVO> mbrCobActiveVOList = (List<EEMMbrCobVO>) getActiveDatedList(mbrCobVOList);
					setToContext(mbrCobActiveVOList);
				}
				return mbrCobVOList;
			}
			else {
				throw new ApplicationException("COB Delete Failed");
			}
		} catch (Exception exp) {
			throw new ApplicationException(exp.getMessage());
		}
	}

	@SuppressWarnings("unchecked")
	public List<EEMMbrCobVO> getListFromContext(String memberId, String showAll) {

		EEMContext context = sessionHelper.getEEMContext();
		List<EEMMbrCobVO> mbrCobVOList = context.getMbrMasterVO().getMbrCobVOList();

		if ("Y".equalsIgnoreCase(showAll)) {
			List<EEMMbrCobVO> allInfos = getMbrCobListFromDB(memberId, showAll);

			if (null == mbrCobVOList || CollectionUtils.isEmpty(mbrCobVOList)) {
				mbrCobVOList = (List<EEMMbrCobVO>) getActiveDatedList(allInfos);
				setToContext(mbrCobVOList);
			}
			return allInfos;
		} else {
			if (null == mbrCobVOList || CollectionUtils.isEmpty(mbrCobVOList)) {
				mbrCobVOList = getMbrCobListFromDB(memberId, showAll);
				setToContext(mbrCobVOList);
			}
			return mbrCobVOList;
		}
	}

	private boolean overrideDatedSegment(EEMMbrCobDO newVO, String userId, String ts, EEMMbrCobDO matchVO, Map<String, String> type) {
		int sqlCnt;
		String maxLastUpdate;
		sqlCnt = memberCobDAO.setOverride(matchVO, userId);
		if (sqlCnt != 1) {
			throw new ApplicationException(EEMConstants.ERROR_OVERRIDING_SEGMENT);
		}
		sqlCnt = addSegment(newVO, userId, ts);
		if (sqlCnt != 1) {
			throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
		}
		int rslt = cobTriggerCheck(matchVO, newVO, userId);
		if (rslt > 0) {
			return false;
		}
		maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(), EEMConstants.EM_MBR_COB,
				type);
		if (hasDataChanged(ts, maxLastUpdate)) {
			throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
		}
		return true;
	}

	private int addSegment(EEMMbrCobDO newVO, String userId, String ts) {
		int sqlCnt;
		newVO.setCreateTime(ts);
		newVO.setCreateUserId(userId);
		newVO.setLastUpdtTime(ts);
		newVO.setLastUpdtUserId(userId);
		sqlCnt = memberCobDAO.insertMbr(newVO);
		return sqlCnt;
	}

	private int cobTriggerCheck(EEMMbrCobDO oldVO, EEMMbrCobDO newVO, String userId) {

		if (!newVO.getEffEndDate().equals("99999999")) {
			return -1;
		}
		if (!newVO.getCobType().equals(EEMConstants.COB_TYPE_SECONDARY)) {
			return -1;
		}
		List<EEMMbrEnrollmentDO> mbrEnroll = eemEnrollDao.getMbrEnrollments(newVO.getCustomerId(), newVO.getMemberId(),
				"N");
		if (mbrEnroll == null) {
			throw new ApplicationException("Enrollment does not exist for the date " + newVO.getEffStartDateFrmt());
		}
		if (!is72SecRxChange(oldVO, newVO)) {
			return -1;
		}
		String ts = DateUtil.getCurrentDatetimeStamp();
		EEMMbrEnrollmentVO enrollVO = new EEMMbrEnrollmentVO();

		EMMbrTriggerDO trig = new EMMbrTriggerDO();
		trig.setCustomerId(newVO.getCustomerId());
		trig.setMemberId(newVO.getMemberId());
		trig.setTriggerType(EEMConstants.TRIG_TYPE_TXN);
		trig.setPlanId(enrollVO.getPlanId());
		trig.setPbpId(enrollVO.getPbpId());
		trig.setPlanDesignation(enrollVO.getPlanDesignation());
		trig.setTriggerStatus(EEMConstants.TRIG_STATUS_CLOSED);
		trig.setProcessSource(EEMConstants.TRIG_PROCESS_SOURCE_WEBENRL);
		trig.setOrigTriggerType("");
		trig.setOrigTriggerCode("");
		trig.setOrigEffectiveDate("");
		trig.setOrigTriggerCreateTime("");
		trig.setCreateUserId(userId);
		trig.setLastUpdtUserId(userId);
		trig.setCreateTime(ts);
		trig.setLastUpdtTime(ts);
		trig.setEffectiveDate(newVO.getEffStartDate());
		trig.setTriggerCode(EEMConstants.TRIG_CODE_72);

		int sqlCnt = eemEnrollDao.insertMbrTrigger(trig);
		if (sqlCnt != 1) {
			throw new ApplicationException("Error Creating CMS Transaction (72) Trigger");
		}
		return 0;
	}

	private boolean is72SecRxChange(EEMMbrCobDO oldVO, EEMMbrCobDO newVO) {

		if (oldVO == null)
			return true;
		if (!oldVO.getRxId().equals(newVO.getRxId()))
			return true;
		if (!oldVO.getRxGrp().equals(newVO.getRxGrp()))
			return true;
		if (!oldVO.getRxBin().equals(newVO.getRxBin()))
			return true;
		if (!oldVO.getRxPcn().equals(newVO.getRxPcn()))
			return true;

		return false;
	}

	private void setToContext(List<EEMMbrCobVO> mbrCobVOList) {
		EEMContext context = sessionHelper.getEEMContext();
		context.getMbrMasterVO().setMbrCobVOList(mbrCobVOList);
		sessionHelper.setEEMContext(context);
	}
}
