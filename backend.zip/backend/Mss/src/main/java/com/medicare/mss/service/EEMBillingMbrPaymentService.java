package com.medicare.mss.service;

import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.dao.EEMBillingMbrPaymentDAO;
import com.medicare.mss.domainobject.BillingMbrPaymentHeaderDO;
import com.medicare.mss.domainobject.BillingMbrPaymentsDO;
import com.medicare.mss.domainobject.BillingMbrPymntDtlInvcDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.BillingMbrPaymentHeaderVO;
import com.medicare.mss.vo.BillingMbrPaymentMasterVO;
import com.medicare.mss.vo.BillingMbrPaymentsSearchVO;
import com.medicare.mss.vo.BillingMbrPaymentsVO;
import com.medicare.mss.vo.BillingMbrPymntDtlInvcVO;
import com.medicare.mss.vo.PageableVO;

@Service
@Transactional(rollbackFor = ApplicationException.class)
public class EEMBillingMbrPaymentService {

	@Autowired
	private EEMBillingMbrPaymentDAO billingMbrPaymentDao;

	@Autowired
	private EEMCodeCache codeCache;

	@Autowired
	private CacheService sessionHelper;

	@Transactional(readOnly = true)
	public BillingMbrPaymentMasterVO mbrBillingPaymentsSearch(BillingMbrPaymentsSearchVO billMbrPaymentsSearchVO) {

		String mediCareID = StringUtil.nonNullTrim(billMbrPaymentsSearchVO.getSearchHicNbr());
		String flag = "";
		if (!mediCareID.isEmpty())
			flag = StringUtil.isHicOrMbi(mediCareID);
		
		return billMbrPaymentsSearch(billMbrPaymentsSearchVO, flag);
	}

	@SuppressWarnings("unchecked")
	private BillingMbrPaymentMasterVO billMbrPaymentsSearch(BillingMbrPaymentsSearchVO billMbrPaymentsSearchVO,
			String flag) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		billMbrPaymentsSearchVO.setCustomerId(customerId);

		BillingMbrPaymentMasterVO mbrPaymentMasterVO = initializeBillingMbrPaymentMasterVO();
		billMbrPaymentsSearchVO.setIsHicOrMbi(flag);
		PageableVO pageableResult = billingMbrPaymentDao.getBillMbrPaymentsSearchDetail(billMbrPaymentsSearchVO, false);

		List<BillingMbrPaymentsDO> mbrPaymentsDOList = (List<BillingMbrPaymentsDO>) pageableResult.getContent();

		if (!CollectionUtils.isEmpty(mbrPaymentsDOList)) {
			List<LabelValuePair> lstPaySource = codeCache.getLstPaySource();
			List<BillingMbrPaymentsVO> mbrPaymentsVOList = new ArrayList<>();

			mbrPaymentsDOList.forEach(mbrPaymentsDO -> {
				BillingMbrPaymentsVO mbrPaymentsVO = new BillingMbrPaymentsVO();
				BeanUtils.copyProperties(mbrPaymentsDO, mbrPaymentsVO);
				mbrPaymentsVO.setPaySourceDesc(codeCache.getDesc(mbrPaymentsVO.getPaySourceType(), lstPaySource));
				mbrPaymentsVOList.add(mbrPaymentsVO);
			});
			mbrPaymentMasterVO.getMbrPaymentsVO().addAll(mbrPaymentsVOList);

			List<BillingMbrPymntDtlInvcVO> billingMbrPymntDtlInvcVOList = getBillPaymentsDetailInvoice(
					mbrPaymentsVOList.get(0));
			mbrPaymentMasterVO.getMbrPymntDtlInvcVO().addAll(billingMbrPymntDtlInvcVOList);
			mbrPaymentMasterVO.setNextPage(pageableResult.isNextPage());
		}
		return mbrPaymentMasterVO;
	}

	@Transactional(readOnly = true)
	public List<BillingMbrPymntDtlInvcVO> getBillPaymentsDetailInvoice(BillingMbrPaymentsVO eemBillingMbrPaymentsVO) {

		List<BillingMbrPymntDtlInvcVO> billingMbrPymntDtlInvcVOList = new ArrayList<>();

		List<BillingMbrPymntDtlInvcDO> billingMbrPymntDtlInvcDOList = billingMbrPaymentDao
				.getBillPaymentsDetailInvoice(eemBillingMbrPaymentsVO);

		if (!CollectionUtils.isEmpty(billingMbrPymntDtlInvcDOList)) {
			CommonUtils.copyList(billingMbrPymntDtlInvcDOList, billingMbrPymntDtlInvcVOList,
					BillingMbrPymntDtlInvcVO.class);
		}
		return billingMbrPymntDtlInvcVOList;
	}

	public BillingMbrPaymentsVO updateBillMbrPayment(BillingMbrPaymentsVO mbrPaymentsVO) {

		String customerId = trimToEmpty(mbrPaymentsVO.getCustomerId());
		String paySourceType = trimToEmpty(mbrPaymentsVO.getPaySourceType());
		String batchDate = trimToEmpty(mbrPaymentsVO.getBatchDate());
		int batchSeqNbr = mbrPaymentsVO.getBatchSeqNbr();
		BillingMbrPaymentHeaderVO payHdrDtl = getBillPaymentHeader(customerId, paySourceType, batchDate, batchSeqNbr);
		String userId = sessionHelper.getUserInfo().getUserId();
		String ts = DateUtil.getCurrentDatetimeStamp();

		updateBillPaymentDetails(mbrPaymentsVO, payHdrDtl, ts, userId);

		mbrPaymentsVO.setLastUpdtTime(ts);
		mbrPaymentsVO.setLastUpdtUserId(userId);

		return mbrPaymentsVO;
	}

	private void updateBillPaymentDetails(BillingMbrPaymentsVO mbrPaymentsVO, BillingMbrPaymentHeaderVO payHdrDtl,
			String ts, String userId) {

		if (billingMbrPaymentDao.updateBillPaymentDetails(mbrPaymentsVO, ts, userId) == 1) {

			String batchBalanceInd = "N";
			Map<String, String> paymentDetail = billingMbrPaymentDao.getPaymentDetail(payHdrDtl);
			String totalPaymentAmount = paymentDetail.get("TOTAL_PAYMENT_AMT");
			String itemNbrCount = paymentDetail.get("ITEM_NBR_COUNT");

			if (totalPaymentAmount.equals(payHdrDtl.getBatchBalanceAmt())) {
				batchBalanceInd = "Y";
			}
			if (billingMbrPaymentDao.updateHeaderTotalAmount(userId, ts, totalPaymentAmount, itemNbrCount,
					batchBalanceInd, payHdrDtl) == 0) {
				throw new ApplicationException("Payment Details Update Failed.");
			}
		} else {
			throw new ApplicationException("Payment Details Update Failed.");
		}
	}

	private BillingMbrPaymentHeaderVO getBillPaymentHeader(String customerId, String paySourceType, String batchDate,
			int batchSeqNbr) {

		BillingMbrPaymentHeaderVO billingMbrPaymentHeaderVO = new BillingMbrPaymentHeaderVO();
		BillingMbrPaymentHeaderDO billingMbrPaymentHeaderDO = billingMbrPaymentDao.getBillPaymentHeader(customerId,
				paySourceType, batchDate, batchSeqNbr);
		List<LabelValuePair> lstPaySource = codeCache.getLstPaySource();
		BeanUtils.copyProperties(billingMbrPaymentHeaderDO, billingMbrPaymentHeaderVO);
		billingMbrPaymentHeaderVO
				.setPaySourceDesc(codeCache.getDesc(billingMbrPaymentHeaderVO.getPaySourceType(), lstPaySource));
		return billingMbrPaymentHeaderVO;
	}

	@SuppressWarnings("unchecked")
	public PageableVO mbrBillingPaymentsSearchNext(BillingMbrPaymentsSearchVO billMembPaymentsSearchVO) {
		billMembPaymentsSearchVO.setCustomerId(sessionHelper.getUserInfo().getCustomerId());
		PageableVO pageableResult = billingMbrPaymentDao
				.getBillMbrPaymentsSearchDetail(billMembPaymentsSearchVO, true);
		
		List<LabelValuePair> lstPaySource = codeCache.getLstPaySource();
		List<BillingMbrPaymentsVO> mbrPaymentsVOList = new ArrayList<>();

		List<BillingMbrPaymentsDO> mbrPaymentsDOList = (List<BillingMbrPaymentsDO>) pageableResult.getContent();
		mbrPaymentsDOList.forEach(mbrPaymentsDO -> {
			BillingMbrPaymentsVO mbrPaymentsVO = new BillingMbrPaymentsVO();
			BeanUtils.copyProperties(mbrPaymentsDO, mbrPaymentsVO);
			mbrPaymentsVO.setPaySourceDesc(codeCache.getDesc(mbrPaymentsVO.getPaySourceType(), lstPaySource));
			mbrPaymentsVOList.add(mbrPaymentsVO);
		});
		pageableResult.setContent(mbrPaymentsVOList);
		return pageableResult;
	}
	
	private BillingMbrPaymentMasterVO initializeBillingMbrPaymentMasterVO() {
		BillingMbrPaymentMasterVO mbrPaymentMasterVO = new BillingMbrPaymentMasterVO();
		mbrPaymentMasterVO.setMbrPaymentsVO(new ArrayList<BillingMbrPaymentsVO>());
		mbrPaymentMasterVO.setMbrPymntDtlInvcVO(new ArrayList<BillingMbrPymntDtlInvcVO>());
		return mbrPaymentMasterVO;
	}

}
