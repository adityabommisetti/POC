package com.medicare.mss.daoImpl;

import static com.medicare.mss.util.StringUtil.nonNullTrim;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.medicare.mss.caching.EEMProfileSettings;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMApplDAO;
import com.medicare.mss.dao.EEMApplLepDAO;
import com.medicare.mss.domainobject.EEMApplTriggerDO;
import com.medicare.mss.domainobject.EEMLepAttestCallDO;
import com.medicare.mss.domainobject.EEMLepAttestCcfDO;
import com.medicare.mss.domainobject.EEMLepAttestInfoDO;
import com.medicare.mss.domainobject.EEMLepPtnlUncovMthsDO;
import com.medicare.mss.domainobject.EEMLepSummaryDO;
import com.medicare.mss.domainobject.EMMbrTriggerDO;
import com.medicare.mss.domainobject.LepHistory;
import com.medicare.mss.domainobject.MBDNunCmoDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.EEMApplHelper;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.StringUtil;

/**
 * @author PR323088
 *
 */
@Repository
public class EEMApplLepDAOImpl implements EEMApplLepDAO {

	private static final Logger LOG = LoggerFactory.getLogger(EEMApplLepDAOImpl.class);

	@Autowired
	EEMProfileSettings eemProfileSettings;

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	JdbcTemplate oracleJdbcTemplate;

	@Autowired
	EEMApplDAO applicationDAO;

	@Autowired
	EEMApplHelper applHelper;

	@Override
	public EEMLepAttestInfoDO getApplLepAttestInfos(String customerId, String applId, String overrideInd)
			throws ApplicationException {

		EEMLepAttestInfoDO attestDO = new EEMLepAttestInfoDO();

		getApplLepAttnDetails(customerId, applId, attestDO, false);

		List<EEMLepAttestCcfDO> lepAttestDoList = getApplCcfResp(customerId, applId, overrideInd, false);

		attestDO.setLepAttestList(lepAttestDoList);

		checkLepLetters(customerId, applId, attestDO, false);

		if ("Y".equals(attestDO.getPdf_archival()) || (!nonNullTrim(attestDO.getLetterName()).isEmpty()
				&& !"Y".equals(nonNullTrim(attestDO.getPdf_archival()))
				&& !attestDO.getLastUpdtTime().isEmpty())) {
			checkAvailabilityOfLetters(customerId, applId, attestDO);
		}
		else {
			attestDO.setLetterAvailabilityInDB(EEMConstants.VALUE_NO);
		}
		
		return attestDO;
	}

	public void getApplLepAttnDetails(String customerId, String primaryId, EEMLepAttestInfoDO attestDO,
			boolean isMember) throws ApplicationException {

		try {

			String query = CommonUtils.buildQuery(
					"SELECT CUSTOMER_ID, APPLICATION_ID, CREATE_TIME, ATT_STATUS, OVERRIDE_IND, INC_ATT_RCVE_DATE,",
					" INC_ATT_RCVE_DATE_EXP, CREATE_USERID, LAST_UPDT_USERID, LAST_UPDT_TIME ",
					"FROM EM_APPL_LEP_ATTN  WHERE CUSTOMER_ID = ? AND APPLICATION_ID = ? AND OVERRIDE_IND = 'N' ORDER BY CREATE_TIME DESC FETCH FIRST ROWS ONLY");

			if (isMember) {
				query = CommonUtils.buildQuery(
						"SELECT CUSTOMER_ID, CREATE_TIME, ATT_STATUS, OVERRIDE_IND, INC_ATT_RCVE_DATE,",
						" INC_ATT_RCVE_DATE_EXP, CREATE_USERID, LAST_UPDT_USERID, LAST_UPDT_TIME ",
						"FROM EM_MBR_LEP_ATTN  WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? AND OVERRIDE_IND = 'N' ORDER BY CREATE_TIME DESC FETCH FIRST ROWS ONLY");

			}

			jdbcTemplate.query(query, new ResultSetExtractor<EEMLepAttestInfoDO>() {

				@Override
				public EEMLepAttestInfoDO extractData(ResultSet rs) throws SQLException {
					if (rs.next()) {
						attestDO.setCustomerId(nonNullTrim(rs.getString("CUSTOMER_ID")));
						attestDO.setPrimaryId(primaryId);
						attestDO.setAttestStatus(nonNullTrim(rs.getString("ATT_STATUS")));
						attestDO.setOldAttestStatus(attestDO.getAttestStatus());
						attestDO.setAppIncAttRcDt(nonNullTrim(rs.getString("INC_ATT_RCVE_DATE")));
						attestDO.setAppIncAttLetExpDt(nonNullTrim(rs.getString("INC_ATT_RCVE_DATE_EXP")));
						attestDO.setLastUpdtTime(nonNullTrim(rs.getString("LAST_UPDT_TIME")));
					}
					return null;
				}

			}, customerId, primaryId);
		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public void checkLepLetters(String customerId, String primaryId, EEMLepAttestInfoDO attestDO, boolean isMember)
			throws ApplicationException {
		String applicationLEPLetterCheckQuery = CommonUtils.buildQuery(
				"SELECT X.CUSTOMER_ID, X.PRIMARY_ID, X.FILE_BATCH_ID, X.ORIG_MAIL_DATE, X.DMS_ID,",
				"X.LETTER_NAME, X.PDF_ARCHIVAL, X.LAST_UPDT_TIME FROM EM_CORR_MBR X WHERE X.CUSTOMER_ID = ?",
				"AND X.RECORD_TYPE = ? AND X.PRIMARY_ID = ? AND X.LETTER_NAME IN (SELECT C.LETTER_NAME",
				"FROM EM_CORR_REASON_INDEX A, EM_FUNCTION_CORR_INDEX B,",
				"EM_CORR_CTL C WHERE A.CUSTOMER_ID = X.CUSTOMER_ID",
				"AND B.CUSTOMER_ID = X.CUSTOMER_ID AND C.CUSTOMER_ID = X.CUSTOMER_ID",
				"AND B.FUNCTION_TYPE IN ('L2A','L2B') AND A.CORR_REASON_CD = B.TRIGGER_CODE",
				"AND C.CORR_LETTER_NAME = A.CORR_LETTER_NAME) ORDER BY LAST_UPDT_TIME DESC FETCH FIRST ROWS ONLY");
		try {
			Object[] params = new Object[] { customerId,
					isMember ? EEMConstants.RECORD_TYPE_MBR : EEMConstants.RECORD_TYPE_APPL, primaryId };
			jdbcTemplate.query(applicationLEPLetterCheckQuery,

					new ResultSetExtractor<EEMLepAttestInfoDO>() {

						@Override
						public EEMLepAttestInfoDO extractData(ResultSet res) throws SQLException {
							if (res.next()) {

								attestDO.setPdf_archival(nonNullTrim(res.getString("PDF_ARCHIVAL"))); // IFOX-00412749
								attestDO.setLetterName(nonNullTrim(res.getString("LETTER_NAME")));
								String origMailDate = nonNullTrim(res.getString("ORIG_MAIL_DATE"));
								attestDO.setAttestLetMailDate(origMailDate);
								int interval = 30;

								if (StringUtils.isNotBlank(origMailDate)) {
									SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
									Calendar calendar = Calendar.getInstance();
									try {
										calendar.setTime(sdf.parse(origMailDate));
									} catch (ParseException e) {
										e.printStackTrace();
									}
									calendar.add(Calendar.DAY_OF_MONTH, interval);
									String attestLetExpDate = sdf.format(calendar.getTime());
									attestDO.setAttestLetExpDate(attestLetExpDate);
								}
								attestDO.setLastUpdtTime(nonNullTrim(res.getString("LAST_UPDT_TIME")));
								attestDO.setDmsID(nonNullTrim(res.getString("DMS_ID")));
							}
							return null;
						}

					}, params);
		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public List<EEMLepAttestCcfDO> getApplCcfResp(String customerId, String primaryId, String overInd, boolean isMember)
			throws ApplicationException {
		List<EEMLepAttestCcfDO> lepAttestList = null;

		try {

			String sqlOverride = " AND OVERRIDE_IND = 'N'";
			if ("Y".equals(overInd))
				sqlOverride = "";

			String query = CommonUtils.buildQuery(
					"SELECT CUSTOMER_ID, APPLICATION_ID, COV_BRK_FROM_DATE, CREATE_TIME, COMPT_RESP_RCVD_DATE,",
					" COVERAGE_BREAK_IND, SOURCE_OF_CREDIBLE_RX_COV, COV_BRK_END_DATE, CCF_UNCOV_MONTHS, RESPONSE_TYPE,",
					" OVERRIDE_IND, CREATE_USERID, LAST_UPDT_USERID, ",
					"LAST_UPDT_TIME FROM EM_APPL_CCF_RESP WHERE CUSTOMER_ID = ? AND APPLICATION_ID = ?", sqlOverride,
					" ORDER BY CREATE_TIME DESC");

			if (isMember) {

				query = CommonUtils.buildQuery(
						"SELECT CUSTOMER_ID, MEMBER_ID, COV_BRK_FROM_DATE, CREATE_TIME, COMPT_RESP_RCVD_DATE,",
						" COVERAGE_BREAK_IND, SOURCE_OF_CREDIBLE_RX_COV,COV_BRK_END_DATE,CCF_UNCOV_MONTHS,",
						" RESPONSE_TYPE, OVERRIDE_IND, CREATE_USERID, LAST_UPDT_USERID,LAST_UPDT_TIME",
						" FROM EM_MBR_CCF_RESP WHERE CUSTOMER_ID = ? AND MEMBER_ID = ?", sqlOverride,
						" ORDER BY COV_BRK_FROM_DATE DESC, COV_BRK_END_DATE DESC");

			}

			lepAttestList = jdbcTemplate.query(query,

					new DomainPropertyRowMapper<EEMLepAttestCcfDO>(EEMLepAttestCcfDO.class), customerId, primaryId);
			if (null != lepAttestList) {

				lepAttestList.stream().forEach(
						object -> object.setBrkInCoverage(CommonUtils.getBreakCovType(object.getBrkInCoverage())));
				lepAttestList.stream()
						.forEach(object -> object.setRespType(CommonUtils.getRespType(object.getRespType())));

			}
		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_RETRIEVAL);
		}
		return lepAttestList;
	}

	@Override
	public List<EEMLepPtnlUncovMthsDO> getPotentialUnCovMonth(String customerId, String primaryId, String showAllPtnl,
			boolean isMember) throws ApplicationException {
		List<EEMLepPtnlUncovMthsDO> data = null;
		String sqlOverride1 = " AND OVERRIDE_IND = 'N'";
		if ("Y".equals(showAllPtnl))
			sqlOverride1 = "";
		try {

			String query = CommonUtils.buildQuery("SELECT CUSTOMER_ID, APPLICATION_ID, LEP_EFF_DATE, ",
					" UNCOV_MNTH_STRT_DT, UNCOV_MNTH_END_DT, PLEP_MONTHS, OVERRIDE_IND, ",
					" CREATE_TIME, CREATE_USERID, LAST_UPDT_TIME,LAST_UPDT_USERID  FROM  EM_APPL_PLEP ",
					" WHERE CUSTOMER_ID = ? AND APPLICATION_ID = ? ", sqlOverride1,
					"ORDER BY UNCOV_MNTH_STRT_DT DESC, UNCOV_MNTH_END_DT DESC ");

			if (isMember) {

				query = CommonUtils.buildQuery("SELECT CUSTOMER_ID,  MEMBER_ID, LEP_EFF_DATE, ",
						" UNCOV_MNTH_STRT_DT, UNCOV_MNTH_END_DT, PLEP_MONTHS, OVERRIDE_IND, ",
						" CREATE_TIME, CREATE_USERID, LAST_UPDT_TIME,LAST_UPDT_USERID  FROM  EM_MBR_PLEP ",
						" WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? ", sqlOverride1,
						"ORDER BY UNCOV_MNTH_STRT_DT DESC, UNCOV_MNTH_END_DT DESC ");
			}

			data = jdbcTemplate.query(query, new Object[] { customerId, primaryId },
					new DomainPropertyRowMapper<EEMLepPtnlUncovMthsDO>(EEMLepPtnlUncovMthsDO.class));

		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_RETRIEVAL);
		}
		return data;

	}

	public Map<String, List<EEMLepAttestCallDO>> getAppLepNunCmo(String customerId, String primaryId, boolean isMember)
			throws ApplicationException {
		Map<String, List<EEMLepAttestCallDO>> attestCallMap = new HashMap<>();
		try {

			String cond = "AND APPLICATION_ID=? ";
			if (isMember) {
				cond = " AND MEMBER_ID = ? ";

			}
			String query = CommonUtils.buildQuery(
					"SELECT CUSTOMER_ID, APPLICATION_ID, ATTESTATION_TYPE, IN_OUT_BND_STATUS, NUM_CALL_ATTEMPT, ",
					"ATTESTATION_STATUS, CALL_UPD_DATE, LAST_UPDT_TIME, LAST_UPDT_USERID,CREATE_TIME,CREATE_USERID ",
					"FROM EM_MBR_LEP_ATT_INFO  WHERE CUSTOMER_ID=?  ", cond);

			Object[] parms = new Object[] { customerId, primaryId };

			jdbcTemplate.query(query, new RowMapper<EEMLepAttestCallDO>() {

				@Override
				public EEMLepAttestCallDO mapRow(ResultSet rs, int rowNum) throws SQLException {

					EEMLepAttestCallDO attestCallDO = new EEMLepAttestCallDO();

					String attestType = nonNullTrim(rs.getString("ATTESTATION_TYPE"));
					String inOutBoundstatue = nonNullTrim(rs.getString("IN_OUT_BND_STATUS"));

					String key = String.join("-", inOutBoundstatue, attestType);
					if (!attestCallMap.containsKey(key)) {
						List<EEMLepAttestCallDO> list = new ArrayList<>();

						setMbrLepAttInfoData(attestCallMap, rs, rowNum, attestCallDO, key, list);

					} else {
						List<EEMLepAttestCallDO> list = attestCallMap.get(key);

						setMbrLepAttInfoData(attestCallMap, rs, rowNum, attestCallDO, key, list);

					}

					return attestCallDO;
				}

			}, parms);
		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_RETRIEVAL);
		}
		return attestCallMap;

	}

	private void setMbrLepAttInfoData(Map<String, List<EEMLepAttestCallDO>> attestCallMap, ResultSet rs, int rowNum,
			EEMLepAttestCallDO attestCallDO, String key, List<EEMLepAttestCallDO> list) throws SQLException {
		attestCallDO.setIndex(rowNum + 1);
		attestCallDO.setAttempt(nonNullTrim(rs.getString("NUM_CALL_ATTEMPT")));
		attestCallDO.setDate(nonNullTrim(rs.getString("CALL_UPD_DATE")));

		String attatsCall = nonNullTrim(rs.getString("ATTESTATION_STATUS"));
		String lepAttestCallStatus = CommonUtils.getLepAttestCallStatus(attatsCall);
		attestCallDO.setStatus(lepAttestCallStatus);
		attestCallDO.setUserId(nonNullTrim(rs.getString("LAST_UPDT_USERID")));
		attestCallDO.setCreateTime(nonNullTrim(rs.getString("CREATE_TIME")));
		attestCallDO.setCreateUserId(nonNullTrim(rs.getString("CREATE_USERID")));
		list.add(attestCallDO);
		attestCallMap.put(key, list);
	}

	@Override
	public EEMLepSummaryDO getApplLepSummaryInfo(String hicNbr, String mbi) throws ApplicationException {

		EEMLepSummaryDO lepSumDO = new EEMLepSummaryDO();
		lepSumDO.setHicNBRVal(hicNbr);

		boolean hicFound = getEligbilityInfoHic(hicNbr, lepSumDO);
		if (!hicFound && StringUtils.isNotBlank(mbi)) {
			getEligbilityInfoMbi(mbi, lepSumDO);
		}

		String hicNBRVal = lepSumDO.getHicNBRVal();
		List<LepHistory> rdsHistory = getRdsHistory(mbi, hicNBRVal, EEMConstants.BLANK);
		lepSumDO.setRdsList(rdsHistory);
		List<LepHistory> partDHistory = getPartDHistory(mbi, hicNBRVal, EEMConstants.BLANK);
		lepSumDO.setPartDList(partDHistory);
		String maxUpdatedTimeProfile = getMaxUpdatedTimeProfile();
		List<MBDNunCmoDO> mbdNunCmo = getMbdNunCmo(mbi, maxUpdatedTimeProfile, hicNBRVal);
		lepSumDO.setNunCMOList(mbdNunCmo);

		return lepSumDO;
	}

	private String getMaxUpdatedTimeProfile() {

		String lastUpdtTime = "";
		try {

			String profileQuery = CommonUtils.buildQuery(
					"SELECT MAX(LAST_UPDT_TIME) AS RECORD_ADD_DT  FROM PROFILE WHERE plan_id = '99999' AND parm_cd = 'HIMASTER'");

			lastUpdtTime = nonNullTrim(jdbcTemplate.queryForObject(profileQuery, String.class));

		} catch (EmptyResultDataAccessException exp) {
			LOG.info("EEMApplLepDaoImpl.getMaxUpdatedTimeProfile()  >> NO ROW FOUND <<");
		}

		return lastUpdtTime;

	}

	private List<MBDNunCmoDO> getMbdNunCmo(String mbi, String profileLastUpdtTime, String hicNbrVal)
			throws ApplicationException {
		String nunCMOQuery = CommonUtils.buildQuery("SELECT START_DATE,NUNCMO_IND,NBR_UNCOV_MONTHS,TOT_NUNCMO ",
				" FROM MBDNUNCMO WHERE HIC_NBR IN (?,?) Fetch First 3 rows only");
		List<MBDNunCmoDO> data = null;
		try {
			data = jdbcTemplate.query(nunCMOQuery, new DomainPropertyRowMapper<MBDNunCmoDO>(MBDNunCmoDO.class),
					hicNbrVal, mbi);

			if (null != data) {
				data.stream().forEach(object -> object.setProfileLastUpdt(profileLastUpdtTime));
			}
		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_RETRIEVAL);
		}

		return data;

	}

	@Override
	public List<LepHistory> getPartDHistory(String mbi, String hicNbrVal, String srcTable) throws ApplicationException {
		List<LepHistory> data = new ArrayList<>();
		try {
			
			if (srcTable.equals(EEMConstants.EM_TABLE_BEQ)) {
				String partDHistoryQuery = CommonUtils.buildQuery(
						"SELECT PRTD_SDATE, PRTD_EDATE,SEQ_NBR FROM BEQR_PRTDHISTORY WHERE HIC_NBR IN (?,?) ORDER BY SEQ_NBR ASC FETCH FIRST 3 ROWS ONLY ");

				data = jdbcTemplate.query(partDHistoryQuery, (rs, rowNum) -> {

					LepHistory lepHistoryVO = new LepHistory();
					lepHistoryVO.setEndDate(DateFormatter.reFormat(StringUtil.zeroTrim((rs.getString("PRTD_EDATE"))),
							DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
					lepHistoryVO.setStartDate(DateFormatter.reFormat(StringUtil.zeroTrim((rs.getString("PRTD_SDATE"))),
							DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
					lepHistoryVO.setSeqNbr(StringUtil.zeroTrim((rs.getString("SEQ_NBR"))));

					return lepHistoryVO;
				}, new Object[] { hicNbrVal, mbi });
			}

			if (data.isEmpty()) {
				String partDHistoryQuery = CommonUtils.buildQuery(
						"SELECT PRTD_SDATE, PRTD_EDATE,SEQ_NBR FROM PRTDHISTORY WHERE HIC_NBR IN (?,?) ORDER BY SEQ_NBR ASC FETCH FIRST 3 ROWS ONLY ");

				data = jdbcTemplate.query(partDHistoryQuery, (rs, rowNum) -> {

					LepHistory lepHistoryVO = new LepHistory();
					lepHistoryVO.setEndDate(DateFormatter.reFormat(StringUtil.zeroTrim((rs.getString("PRTD_EDATE"))),
							DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
					lepHistoryVO.setStartDate(DateFormatter.reFormat(StringUtil.zeroTrim((rs.getString("PRTD_SDATE"))),
							DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
					lepHistoryVO.setSeqNbr(StringUtil.zeroTrim((rs.getString("SEQ_NBR"))));

					return lepHistoryVO;
				}, new Object[] { hicNbrVal, mbi });
			}
		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_RETRIEVAL);
		}

		return data;
	}

	@Override
	public List<LepHistory> getRdsHistory(String mbi, String hicNbrVal, String srcTable) throws ApplicationException {

		List<LepHistory> data = new ArrayList<>();
		try {
			if (srcTable.equals(EEMConstants.EM_TABLE_BEQ)) {
				String rdsHistoryQuery = CommonUtils.buildQuery(
						"SELECT SEQ_NBR,RDS_SDATE, RDS_EDATE FROM BEQR_RDSHISTORY WHERE HIC_NBR IN (?,?)  ORDER BY SEQ_NBR ASC Fetch FIRST 3 ROWS ONLY ");

				data = jdbcTemplate.query(rdsHistoryQuery, (rs, rowNum) -> {

					LepHistory lepHistoryVO = new LepHistory();
					lepHistoryVO.setEndDate(DateFormatter.reFormat(StringUtil.zeroTrim((rs.getString("RDS_EDATE"))),
							DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
					lepHistoryVO.setStartDate(DateFormatter.reFormat(StringUtil.zeroTrim((rs.getString("RDS_SDATE"))),
							DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
					lepHistoryVO.setSeqNbr(StringUtil.zeroTrim((rs.getString("SEQ_NBR"))));

					return lepHistoryVO;

				}, new Object[] { hicNbrVal, mbi });
			}

			if (data.isEmpty()) {
				String rdsHistoryQuery = CommonUtils.buildQuery(
						"SELECT SEQ_NBR,RDS_SDATE, RDS_EDATE FROM RDSHISTORY WHERE HIC_NBR IN (?,?)  ORDER BY SEQ_NBR ASC Fetch FIRST 3 ROWS ONLY ");

				data = jdbcTemplate.query(rdsHistoryQuery, (rs, rowNum) -> {

					LepHistory lepHistoryVO = new LepHistory();
					lepHistoryVO.setEndDate(DateFormatter.reFormat(StringUtil.zeroTrim((rs.getString("RDS_EDATE"))),
							DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
					lepHistoryVO.setStartDate(DateFormatter.reFormat(StringUtil.zeroTrim((rs.getString("RDS_SDATE"))),
							DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
					lepHistoryVO.setSeqNbr(StringUtil.zeroTrim((rs.getString("SEQ_NBR"))));

					return lepHistoryVO;

				}, new Object[] { hicNbrVal, mbi });
			}
		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_RETRIEVAL);
		}
		return data;
	}

	private void getEligbilityInfoMbi(String mbi, EEMLepSummaryDO lepSumDO) throws ApplicationException {

		try {
			String eligbilityInfoQueryMbi = CommonUtils.buildQuery(
					"SELECT COPAY_LEVEL_ID1, COPAY_LEVEL_ID2, PRTD_PREMSUBS_PCT1, PRTD_PREMSUBS_PCT2,",
					"PRTA_ENTITLE_DATE, PRTA_ENTITLE_EDATE, PRTB_ENTITLE_DATE, BIRTH_DATE, ",
					"PRTB_ENTITLE_EDATE,PRTD_ELIG_SDATE,SUBSIDY_SDATE1, SUBSIDY_EDATE1, SUBSIDY_SDATE2, SUBSIDY_EDATE2 ",
					"FROM MBD WHERE MBI=? FETCH FIRST ROWS ONLY");

			jdbcTemplate.query(eligbilityInfoQueryMbi, new ResultSetExtractor<EEMLepSummaryDO>() {

				@Override
				public EEMLepSummaryDO extractData(ResultSet rs) throws SQLException {

					if (rs.next()) {
						lepSumDO.setCopayLEVELID1(StringUtil.zeroTrim(rs.getString("COPAY_LEVEL_ID1")));
						lepSumDO.setCopayLEVELID2(StringUtil.zeroTrim(rs.getString("COPAY_LEVEL_ID2")));
						lepSumDO.setPrtdPREMSUBSPCT1(StringUtil.zeroTrim(rs.getString("PRTD_PREMSUBS_PCT1")));
						lepSumDO.setPrtdPREMSUBSPCT2(StringUtil.zeroTrim(rs.getString("PRTD_PREMSUBS_PCT2")));
						lepSumDO.setMbrBirthDt(StringUtil.zeroTrim(rs.getString("BIRTH_DATE")));
						lepSumDO.setPartAEntitleSDate(StringUtil.zeroTrim(rs.getString("PRTA_ENTITLE_DATE")));
						lepSumDO.setPartAEntitleEDate(StringUtil.zeroTrim(rs.getString("PRTA_ENTITLE_EDATE")));
						lepSumDO.setPartBEntitleSDate(StringUtil.zeroTrim(rs.getString("PRTB_ENTITLE_DATE")));
						lepSumDO.setPartBEntitleEDate(StringUtil.zeroTrim(rs.getString("PRTB_ENTITLE_EDATE")));
						lepSumDO.setPartDEntitleSDate(StringUtil.zeroTrim(rs.getString("PRTD_ELIG_SDATE")));
						lepSumDO.setSubsidySDate1(StringUtil.zeroTrim(rs.getString("SUBSIDY_SDATE1")));
						lepSumDO.setSubsidyEDate1(StringUtil.zeroTrim(rs.getString("SUBSIDY_EDATE1")));
						lepSumDO.setSubsidySDate2(StringUtil.zeroTrim(rs.getString("SUBSIDY_SDATE2")));
						lepSumDO.setSubsidyEDate2(StringUtil.zeroTrim(rs.getString("SUBSIDY_EDATE2")));
					}

					return null;
				}
			}, mbi);
		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_RETRIEVAL);
		}

	}

	private boolean getEligbilityInfoHic(String hicNbr, EEMLepSummaryDO lepSumDO) throws ApplicationException {

		boolean hicFound = false;
		String eligbilityInfoQuery = CommonUtils.buildQuery(
				"SELECT COPAY_LEVEL_ID1, COPAY_LEVEL_ID2, PRTD_PREMSUBS_PCT1, PRTD_PREMSUBS_PCT2,",
				"PRTA_ENTITLE_DATE, PRTA_ENTITLE_EDATE, PRTB_ENTITLE_DATE,BIRTH_DATE, ",
				"PRTB_ENTITLE_EDATE,PRTD_ELIG_SDATE,SUBSIDY_SDATE1, SUBSIDY_EDATE1, SUBSIDY_SDATE2, SUBSIDY_EDATE2 ",
				"FROM MBD WHERE HIC_NBR=? FETCH FIRST ROWS ONLY");
		try {
			hicFound = jdbcTemplate.query(eligbilityInfoQuery, new ResultSetExtractor<Boolean>() {

				@Override
				public Boolean extractData(ResultSet rs) throws SQLException {

					if (rs.next()) {
						lepSumDO.setCopayLEVELID1(StringUtil.zeroTrim(rs.getString("COPAY_LEVEL_ID1")));
						lepSumDO.setCopayLEVELID2(StringUtil.zeroTrim(rs.getString("COPAY_LEVEL_ID2")));
						lepSumDO.setPrtdPREMSUBSPCT1(StringUtil.zeroTrim(rs.getString("PRTD_PREMSUBS_PCT1")));
						lepSumDO.setPrtdPREMSUBSPCT2(StringUtil.zeroTrim(rs.getString("PRTD_PREMSUBS_PCT2")));
						lepSumDO.setMbrBirthDt(StringUtil.zeroTrim(rs.getString("BIRTH_DATE")));
						lepSumDO.setPartAEntitleSDate(StringUtil.zeroTrim(rs.getString("PRTA_ENTITLE_DATE")));
						lepSumDO.setPartAEntitleEDate(StringUtil.zeroTrim(rs.getString("PRTA_ENTITLE_EDATE")));
						lepSumDO.setPartBEntitleSDate(StringUtil.zeroTrim(rs.getString("PRTB_ENTITLE_DATE")));
						lepSumDO.setPartBEntitleEDate(StringUtil.zeroTrim(rs.getString("PRTB_ENTITLE_EDATE")));
						lepSumDO.setPartDEntitleSDate(StringUtil.zeroTrim(rs.getString("PRTD_ELIG_SDATE")));
						lepSumDO.setSubsidySDate1(StringUtil.zeroTrim(rs.getString("SUBSIDY_SDATE1")));
						lepSumDO.setSubsidyEDate1(StringUtil.zeroTrim(rs.getString("SUBSIDY_EDATE1")));
						lepSumDO.setSubsidySDate2(StringUtil.zeroTrim(rs.getString("SUBSIDY_SDATE2")));
						lepSumDO.setSubsidyEDate2(StringUtil.zeroTrim(rs.getString("SUBSIDY_EDATE2")));

						return true;
					}
					return false;
				}
			}, hicNbr);
		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_RETRIEVAL);
		}
		return hicFound;

	}

	@Override
	public boolean insertMbrLepAttInfo(String customerId, String primaryId, EEMLepAttestCallDO eemLepAttestCallDO,
			String attestType) throws ApplicationException {

		int update = 0;
		try {
			String[] types = attestType.split("_");
			Integer applId = 0;
			String memberId = primaryId;
			String sql = CommonUtils.buildQuery(
					"INSERT INTO EM_MBR_LEP_ATT_INFO (CUSTOMER_ID, MEMBER_ID, ATTESTATION_TYPE, IN_OUT_BND_STATUS, NUM_CALL_ATTEMPT, ",
					" ATTESTATION_STATUS, CALL_UPD_DATE, LAST_UPDT_TIME, LAST_UPDT_USERID,CREATE_TIME,CREATE_USERID,APPLICATION_ID) ",
					" VALUES (?,?,?,?,?,?,?,?,?,?,?,?);");

			String attType = types[1].trim().substring(2, 3).equalsIgnoreCase("T") ? "L"
					: types[1].trim().substring(2, 3);
			String inBoundStatus = types[0].trim().substring(0, 1);

			if (!primaryId.startsWith("C")) {
				applId = Integer.parseInt(primaryId);

				memberId = "";
			}

			Object[] params = new Object[] { customerId, memberId, attType, inBoundStatus,
					nonNullTrim(eemLepAttestCallDO.getAttempt()),
					nonNullTrim(eemLepAttestCallDO.getStatus()),
					nonNullTrim(eemLepAttestCallDO.getDate()), eemLepAttestCallDO.getCreateTime(),
					eemLepAttestCallDO.getUserId(), eemLepAttestCallDO.getCreateTime(), eemLepAttestCallDO.getUserId(),
					applId };

			update = jdbcTemplate.update(sql, params);
		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_INSERT);
		}
		return update > 0 ? true : false;
	}

	@Override
	public int invokeTriggerUpdate(String customerId, String primaryId, String userId, boolean isMember)
			throws ApplicationException {
		int sqlCnt = 0;

		try {
			sqlCnt = updateTrigger(customerId, primaryId, userId, isMember);

			String openTriggerExist = checkOpenApplTrigger(customerId, primaryId, EEMConstants.TRIG_CODE_LE21);
			if (null != openTriggerExist) {
				int interval = eemProfileSettings.getParmNumber(customerId, EEMConstants.TRIG_CODE_LE21);

				String trigEffectDate = DateMath.addDay(DateUtil.getTodaysDate(), interval);

				String effDateFrmt = DateFormatter.reFormat(trigEffectDate, DateFormatter.YYYY_MM_DD,
						DateFormatter.YYYYMMDD);

				EEMApplTriggerDO triggerDo = applHelper.prepareApplTriggerDO(primaryId, EEMConstants.TRIG_TYPE_FOLLOWUP_APPL,
						EEMConstants.TRIG_STATUS_OPEN, EEMConstants.TRIG_CODE_LE21, effDateFrmt);

				sqlCnt = applicationDAO.insertApplTrigger(triggerDo);

			}
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);

		} catch (ParseException e) {
			e.printStackTrace();
		}

		return sqlCnt;
	}

	@Override
	public int updateTrigger(String customerId, String primaryId, String userId, boolean isMember) {
		int sqlCnt;
		String updateSQL = "";

		String ts = DateUtil.getCurrentDatetimeStamp();

		try {
			if (isMember) {
				updateSQL = CommonUtils.buildQuery(
						"UPDATE EM_MBR_TRIGGER SET TRIGGER_STATUS=?, LAST_UPDT_TIME=?, LAST_UPDT_USERID=? WHERE CUSTOMER_ID = ? ",
						"AND MEMBER_ID =? AND TRIGGER_CODE IN('OBC1','OBC2','OBC3') AND TRIGGER_TYPE = ? AND TRIGGER_STATUS='OPEN' ");
			}

			else {
				updateSQL = CommonUtils.buildQuery(
						"UPDATE EM_APPL_TRIGGER SET TRIGGER_STATUS=?, LAST_UPDT_TIME=?, LAST_UPDT_USERID=? WHERE CUSTOMER_ID = ? ",
						"AND APPLICATION_ID =? AND TRIGGER_CODE IN('OBC1','OBC2','OBC3') AND TRIGGER_TYPE = ? AND  TRIGGER_STATUS='OPEN'");
			}

			sqlCnt = jdbcTemplate.update(updateSQL, EEMConstants.TRIG_STATUS_EXPIRED, ts, userId, customerId,
					primaryId, EEMConstants.TRIG_TYPE_FOLLOWUP_APPL);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);

		}
		return sqlCnt;

	}

	@Override
	public String checkOpenApplTrigger(String customerId, String applId, String triggerType) {
		String openTriggerExist = "";

		try {
			String check73 = CommonUtils.buildQuery(
					"SELECT TRIGGER_CODE FROM EM_APPL_TRIGGER WHERE CUSTOMER_ID = ? AND APPLICATION_ID = ? ",
					" AND TRIGGER_CODE = ? AND TRIGGER_STATUS= 'OPEN'");

			Object[] params = new Object[] { customerId, applId, triggerType };
			openTriggerExist = nonNullTrim(jdbcTemplate.queryForObject(check73, params, String.class));

		} catch (EmptyResultDataAccessException exp) {
			LOG.info("EEMApplLepDaoImpl.checkOpenApplTrigger()  >> NO ROW FOUND <<");

		}
		return openTriggerExist;
	}

	@Override
	public String getApplAttStatus(String customerId, String applId) {

		String attStatus = "";

		try {
			String query = CommonUtils.buildQuery(
					"Select ATT_STATUS from EM_APPL_LEP_ATTN WHERE CUSTOMER_ID = ? AND  APPLICATION_ID = ? AND OVERRIDE_IND = 'N'");

			attStatus = StringUtil
					.nonNullTrim(jdbcTemplate.queryForObject(query, new Object[] { customerId, applId }, String.class));
		} catch (EmptyResultDataAccessException exp) {

			LOG.info("EEMApplLepDaoImpl.getApplLepAttnDetails()  >> NO ROW FOUND <<");
		}

		return attStatus;
	}

	@Override
	public String getApplTriggetr(String customerId, String applId, String triggerType, String triggerCode)
			throws ApplicationException {

		String trrigerStatus = "";
		try {
			String query = CommonUtils.buildQuery("SELECT TRIGGER_STATUS FROM EM_APPL_TRIGGER",
					" WHERE CUSTOMER_ID = ? AND APPLICATION_ID = ? AND TRIGGER_TYPE = ? AND TRIGGER_CODE = ?",
					" ORDER BY CREATE_TIME DESC FETCH FIRST 1 ROWS ONLY");

			trrigerStatus = nonNullTrim(jdbcTemplate.queryForObject(query,
					new Object[] { customerId, applId, triggerType, triggerCode }, String.class));

		} catch (EmptyResultDataAccessException exp) {
			LOG.info("EEMApplLepDaoImpl.getApplTriggetr()  >> NO ROW FOUND <<");
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
		return trrigerStatus;

	}

	@Override
	public Map<String, String> getApplTrigger(String customerId, String primaryId, boolean isMember, String triggerType)
			throws ApplicationException {

		Map<String, String> data = new HashMap<>();
		try {
			String query = CommonUtils.buildQuery(
					"SELECT TRIGGER_CODE, MAX(CREATE_TIME), TRIGGER_STATUS FROM EM_APPL_TRIGGER ",
					" WHERE CUSTOMER_ID = ? AND APPLICATION_ID = ? AND TRIGGER_TYPE = ? AND TRIGGER_CODE IN ('OBC2','OBC1','OBC3','LE21')",
					" GROUP BY TRIGGER_CODE,TRIGGER_STATUS ORDER BY MAX(CREATE_TIME)  DESC ");

			if (isMember) {
				query = CommonUtils.buildQuery(
						"SELECT TRIGGER_CODE, MAX(CREATE_TIME), TRIGGER_STATUS FROM EM_MBR_TRIGGER ",
						" WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? AND TRIGGER_TYPE = ? AND TRIGGER_CODE IN ('OBC2','OBC1','OBC3','LE21')",
						" GROUP BY TRIGGER_CODE,TRIGGER_STATUS ORDER BY MAX(CREATE_TIME)  DESC ");

			}
			Object[] params = new Object[] { customerId, primaryId, triggerType };
			jdbcTemplate.query(query, params, new RowCallbackHandler() {

				@Override
				public void processRow(ResultSet res) throws SQLException {

					String triggerCode = nonNullTrim(res.getString("TRIGGER_CODE"));
					if (!data.containsKey(triggerCode)) {
						data.put(triggerCode, nonNullTrim(res.getString("TRIGGER_STATUS")));
					}
				}
			});

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
		return data;

	}

	@Override
	public int insertApplLepAttnDetails(EEMLepAttestInfoDO newDo, boolean isMember) throws ApplicationException {

		int sqlCnt = 0;
		try {
			String query = "";
			Object[] params = null;
			if (!isMember) {
				query = CommonUtils.buildQuery(
						"INSERT INTO  EM_APPL_LEP_ATTN (CUSTOMER_ID, APPLICATION_ID, CREATE_TIME, ATT_STATUS, ",
						"OVERRIDE_IND, INC_ATT_RCVE_DATE, INC_ATT_RCVE_DATE_EXP, CREATE_USERID,",
						" LAST_UPDT_USERID, LAST_UPDT_TIME) ", "VALUES(?,?,?,?,?,?,?,?,?,?)");
				params = new Object[] { nonNullTrim(newDo.getCustomerId()), newDo.getPrimaryId(),
						newDo.getCreateTime(), nonNullTrim(newDo.getAttestStatus()), "N",
						nonNullTrim(newDo.getAppIncAttRcDt()),
						nonNullTrim(newDo.getAppIncAttLetExpDt()), newDo.getUserId(), newDo.getUserId(),
						newDo.getCreateTime() };
			} else {

				query = CommonUtils.buildQuery(
						"INSERT INTO  EM_MBR_LEP_ATTN (CUSTOMER_ID, MEMBER_ID, CREATE_TIME, ATT_STATUS, ",
						"OVERRIDE_IND, INC_ATT_RCVE_DATE, INC_ATT_RCVE_DATE_EXP, CREATE_USERID,",
						" LAST_UPDT_USERID, LAST_UPDT_TIME,ATTST_LOCK) ", "VALUES(?,?,?,?,?,?,?,?,?,?,?)");
				params = new Object[] { nonNullTrim(newDo.getCustomerId()), newDo.getPrimaryId(),
						newDo.getCreateTime(), nonNullTrim(newDo.getAttestStatus()), "N",
						nonNullTrim(newDo.getAppIncAttRcDt()),
						nonNullTrim(newDo.getAppIncAttLetExpDt()), newDo.getUserId(), newDo.getUserId(),
						newDo.getCreateTime(), nonNullTrim(newDo.getAttestLock()) };

			}

			sqlCnt = jdbcTemplate.update(query, params);
		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_INSERT);

		}
		return sqlCnt;

	}

	@Override
	public int closeALLApplTimers(EMMbrTriggerDO newDo, boolean isMember, String triggerCode)
			throws ApplicationException {

		String ts = DateUtil.getCurrentDatetimeStamp();
		int sqlCnt = 0;
		try {

			String triggerCodes = "'OBC1','OBC2','OBC3','LE21'";
			if (!triggerCode.isEmpty())
				triggerCodes = triggerCode;

			String updateSQL;
			if (!isMember) {
				updateSQL = CommonUtils.buildQuery(
						"UPDATE EM_APPL_TRIGGER SET TRIGGER_STATUS=?, LAST_UPDT_TIME=?, LAST_UPDT_USERID=? WHERE CUSTOMER_ID = ? ",
						"AND APPLICATION_ID =? AND TRIGGER_CODE IN('OBC1','OBC2','OBC3','LE21') AND TRIGGER_TYPE = ? AND TRIGGER_STATUS='OPEN' ");

			} else {
				updateSQL = CommonUtils.buildQuery(
						"UPDATE EM_MBR_TRIGGER SET TRIGGER_STATUS=?, LAST_UPDT_TIME=?, LAST_UPDT_USERID=? WHERE CUSTOMER_ID = ? ",
						"AND MEMBER_ID =? AND TRIGGER_CODE IN(", triggerCodes,
						") AND TRIGGER_TYPE = ? AND TRIGGER_STATUS='OPEN' ");

			}

			Object[] params = new Object[] { EEMConstants.TRIG_STATUS_EXPIRED, ts, newDo.getCreateUserId(),
					newDo.getCustomerId(), newDo.getPrimaryId(), isMember ? EEMConstants.TRIG_TYPE_FOLLOWUP_MEMB : EEMConstants.TRIG_TYPE_FOLLOWUP_APPL };

			sqlCnt = jdbcTemplate.update(updateSQL, params);
		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_UPDATE);

		}
		return sqlCnt;

	}

	@Override
	public int overrideApplLepAttnDetails(String customerId, String primaryId, String userId, boolean isMember)
			throws ApplicationException {
		int sqlCnt = 0;
		try {
			String query = "";
			if (!isMember) {
				query = CommonUtils.buildQuery(
						" UPDATE EM_APPL_LEP_ATTN SET OVERRIDE_IND = ?, LAST_UPDT_TIME = CURRENT_TIMESTAMP , LAST_UPDT_USERID = ?",
						" WHERE CUSTOMER_ID = ? AND APPLICATION_ID = ? AND OVERRIDE_IND = 'N'");
			} else {

				query = CommonUtils.buildQuery(
						" UPDATE EM_MBR_LEP_ATTN SET OVERRIDE_IND = ?, LAST_UPDT_TIME = CURRENT_TIMESTAMP , LAST_UPDT_USERID = ?",
						" WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? AND OVERRIDE_IND = 'N'");

			}
			Object[] params = new Object[] { "Y", userId, customerId, primaryId };

			sqlCnt = jdbcTemplate.update(query, params);

		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_UPDATE);

		}
		return sqlCnt;

	}

	@Override
	public int insertAttnDetailsInCCF(EEMLepAttestCcfDO attestDO, boolean isMember) throws ApplicationException {

		int sqlCnt = 0;
		try {
			String query = "";
			if (!isMember) {
				query = CommonUtils.buildQuery(
						"INSERT INTO  EM_APPL_CCF_RESP ( CUSTOMER_ID, APPLICATION_ID, COV_BRK_FROM_DATE, CREATE_TIME,",
						" COMPT_RESP_RCVD_DATE, COVERAGE_BREAK_IND, SOURCE_OF_CREDIBLE_RX_COV, ",
						"COV_BRK_END_DATE, CCF_UNCOV_MONTHS, RESPONSE_TYPE, OVERRIDE_IND,",
						" CREATE_USERID, LAST_UPDT_USERID, LAST_UPDT_TIME ) ",
						"VALUES (?,?,?,?,?,?,?,?,?,?,'N',?,?,?)");
			} else {
				query = CommonUtils.buildQuery(
						"INSERT INTO  EM_MBR_CCF_RESP ( CUSTOMER_ID, MEMBER_ID, COV_BRK_FROM_DATE, CREATE_TIME,",
						" COMPT_RESP_RCVD_DATE, COVERAGE_BREAK_IND, SOURCE_OF_CREDIBLE_RX_COV, ",
						"COV_BRK_END_DATE, CCF_UNCOV_MONTHS, RESPONSE_TYPE, OVERRIDE_IND,",
						" CREATE_USERID, LAST_UPDT_USERID, LAST_UPDT_TIME ) ",
						"VALUES (?,?,?,?,?,?,?,?,?,?,'N',?,?,?)");
			}

			Object[] params = new Object[] { attestDO.getCustomerId(), attestDO.getPrimaryId(),
					nonNullTrim(attestDO.getFromDate()), attestDO.getCreateTime(),
					nonNullTrim(attestDO.getComptRespRecDate()),

					nonNullTrim(attestDO.getBrkInCoverage()),
					nonNullTrim(attestDO.getCredRXCoverage()), nonNullTrim(attestDO.getToDate()),
					attestDO.getCcfUncovMnths(), nonNullTrim(attestDO.getRespType()),
					attestDO.getCreateUserId(), attestDO.getCreateUserId(), attestDO.getLastUpdtTime() };

			sqlCnt = jdbcTemplate.update(query, params);

		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_INSERT);

		}
		return sqlCnt;
	}

	@Override
	public int overridePLepApplDetails(String customerId, String userId, String primaryId, boolean isMember)
			throws ApplicationException {
		int sqlCnt = 0;

		try {
			String query = "";
			if (!isMember) {
				query = CommonUtils.buildQuery(
						"UPDATE EM_APPL_PLEP Set OVERRIDE_IND = 'Y', LAST_UPDT_USERID=?, LAST_UPDT_TIME=CURRENT_TIMESTAMP",
						" WHERE CUSTOMER_ID=? And APPLICATION_ID=? AND OVERRIDE_IND ='N'");
			} else {
				query = CommonUtils.buildQuery(
						"UPDATE EM_MBR_PLEP Set OVERRIDE_IND = 'Y', LAST_UPDT_USERID=?, LAST_UPDT_TIME=CURRENT_TIMESTAMP",
						" WHERE CUSTOMER_ID=? And MEMBER_ID=? AND OVERRIDE_IND ='N'");
			}
			Object[] params = new Object[] { userId, customerId, primaryId };

			sqlCnt = jdbcTemplate.update(query, params);

		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_UPDATE);

		}
		return sqlCnt;
	}

	@Override
	public int insertApplPtnlUnCovMnthsDetails(EEMLepPtnlUncovMthsDO objVO, boolean isMember)
			throws ApplicationException {
		int sqlCnt = 0;
		try {

			String query = CommonUtils.buildQuery(
					"INSERT INTO EM_APPL_PLEP (CUSTOMER_ID, APPLICATION_ID, CREATE_TIME, LEP_EFF_DATE,",
					" UNCOV_MNTH_STRT_DT, UNCOV_MNTH_END_DT, PLEP_MONTHS, CREATE_USERID, LAST_UPDT_USERID, ",
					"LAST_UPDT_TIME, OVERRIDE_IND) VALUES (?,?,?,?,?,?,?,?,?,?,'N')");

			if (isMember) {
				query = CommonUtils.buildQuery(
						"INSERT INTO EM_MBR_PLEP (CUSTOMER_ID, MEMBER_ID, CREATE_TIME, LEP_EFF_DATE,",
						" UNCOV_MNTH_STRT_DT, UNCOV_MNTH_END_DT, PLEP_MONTHS, CREATE_USERID, LAST_UPDT_USERID, ",
						"LAST_UPDT_TIME, OVERRIDE_IND) VALUES (?,?,?,?,?,?,?,?,?,?,'N')");

			}

			Object[] params = new Object[] { objVO.getCustomerId(), objVO.getPrimaryId(), objVO.getCreateTime(),
					nonNullTrim(objVO.getLepEffDate()), nonNullTrim(objVO.getUncovMthStDt()),
					nonNullTrim(objVO.getUncovMthEndDt()), objVO.getPlepMonths(), objVO.getCreateUserId(),
					objVO.getCreateUserId(), objVO.getLastUpdtTime() };
			sqlCnt = jdbcTemplate.update(query, params);
		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_INSERT);

		}
		return sqlCnt;
	}

	@Override
	public int overrideApplAttnInfo(EEMLepAttestCcfDO ccfAttestDo, boolean isMember) throws ApplicationException {
		int sqlCnt = 0;

		try {
			String query = "";
			if (!isMember) {
				query = CommonUtils.buildQuery(
						" UPDATE EM_APPL_CCF_RESP SET OVERRIDE_IND = 'Y', LAST_UPDT_TIME = ? , LAST_UPDT_USERID = ?",
						"WHERE CUSTOMER_ID = ? AND  APPLICATION_ID = ? AND  CREATE_TIME = ? AND OVERRIDE_IND = 'N' AND CREATE_USERID = ?");

			} else {
				query = CommonUtils.buildQuery(
						" UPDATE EM_MBR_CCF_RESP SET OVERRIDE_IND = 'Y', LAST_UPDT_TIME = ? , LAST_UPDT_USERID = ?",
						"WHERE CUSTOMER_ID = ? AND  MEMBER_ID = ? AND  CREATE_TIME = ? AND OVERRIDE_IND = 'N' AND CREATE_USERID = ?");
			}
			Object[] parmas = new Object[] { ccfAttestDo.getLastUpdtTime(), ccfAttestDo.getUserId(),
					ccfAttestDo.getCustomerId(), ccfAttestDo.getPrimaryId(), ccfAttestDo.getCreateTime(),
					ccfAttestDo.getCreateUserId() };
			sqlCnt = jdbcTemplate.update(query, parmas);

		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_UPDATE);

		}
		return sqlCnt;

	}

	@Override
	public String getInterval(String customerId) throws ApplicationException {
		String subsInd = "";
		try {
			String sQuery = "SELECT PARM_NBR_VALUE FROM EM_PROFILE WHERE CUSTOMER_ID= ? AND PARM_CD = ? AND OVERRIDE_IND='N'";

			Object[] parmas = new Object[] { customerId, EEMConstants.TRIG_CODE_OBC1 };
			subsInd = nonNullTrim(jdbcTemplate.queryForObject(sQuery, String.class, parmas));

		} catch (EmptyResultDataAccessException exp) {
			LOG.info("EEMApplLepDaoImpl.getInterval()  >> NO ROW FOUND <<");
		} catch (Exception exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_RETRIEVAL);
		}
		return subsInd;

	}

	@Override
	public int updateApplPtnlUnCovMnthsDetails(EEMLepPtnlUncovMthsDO unCovDo, boolean isMember)
			throws ApplicationException {
		int sqlCnt = 0;

		try {
			String query = CommonUtils.buildQuery(
					"UPDATE EM_APPL_PLEP SET OVERRIDE_IND = 'Y' , LAST_UPDT_TIME = ? , LAST_UPDT_USERID = ?",
					" WHERE CUSTOMER_ID = ? AND APPLICATION_ID = ? AND  CREATE_TIME = ? AND OVERRIDE_IND = 'N' AND CREATE_USERID = ?");

			if (isMember) {
				query = CommonUtils.buildQuery(
						"UPDATE EM_MBR_PLEP SET OVERRIDE_IND = 'Y' , LAST_UPDT_TIME = ? , LAST_UPDT_USERID = ?",
						" WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? AND  CREATE_TIME = ? AND OVERRIDE_IND = 'N' AND CREATE_USERID = ?");

			}

			Object[] params = new Object[] { unCovDo.getLastUpdtTime(), unCovDo.getCreateUserId(),
					unCovDo.getCustomerId(), unCovDo.getPrimaryId(), unCovDo.getCreateTime(),
					unCovDo.getCreateUserId() };
			sqlCnt = jdbcTemplate.update(query, params);

		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_UPDATE);

		}
		return sqlCnt;
	}

	@Override
	public int closeOBCTimer(String customerId, String applId) throws ApplicationException {
		String query = CommonUtils.buildQuery(
				" UPDATE EM_APPL_TRIGGER SET TRIGGER_STATUS=? WHERE TRIGGER_CODE IN ('OBC1','OBC2','OBC3','LE21')  ",
				"AND TRIGGER_STATUS= 'OPEN' AND APPLICATION_ID=? AND CUSTOMER_ID = ? ");
		int sqlCnt = 0;
		try {

			Object[] params = new Object[] { EEMConstants.TRIG_STATUS_CLOSED, applId, customerId };
			sqlCnt = jdbcTemplate.update(query, params);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}
		return sqlCnt;

	}

	@Override
	public byte[] displayDocumentFromDB(String applId, Map<String, String> searchParamMap) throws ApplicationException {
		byte[] blobByte = null;
		try {
			String customerId = nonNullTrim(searchParamMap.get("customerId"));
			String primaryId = nonNullTrim(searchParamMap.get("primaryId"));
			String letterName = nonNullTrim(searchParamMap.get("letterName"));
			String letterUploadedTime = nonNullTrim(searchParamMap.get("letterUploadedTime"));
			String pdf_archival = nonNullTrim(searchParamMap.get("pdf_archival"));

			StringBuilder query = new StringBuilder("SELECT LETTER_PDF FROM EM_CORR_DMS ");

			if ("Y".equalsIgnoreCase(pdf_archival)) {
				query.append(
						" WHERE TRIM(CUSTOMER_ID) = ? AND TRIM(PRIMARY_ID) = ? AND TRIM(CUSTOMER_LETTER_NAME) = ? ORDER BY LETTER_CREATION_TIME DESC ");
			} else {
				query.append(
						" WHERE CUSTOMER_ID = ? AND PRIMARY_ID = ? AND CUSTOMER_LETTER_NAME = ? AND LETTER_CREATION_TIME = ? ");
			}

			blobByte = getPdfBlob(primaryId, customerId, letterName, letterUploadedTime, pdf_archival, query);

			if (null == blobByte) {
				blobByte = getPdfBlob(String.valueOf(applId), customerId, letterName, letterUploadedTime, pdf_archival,
						query);
			}

		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_RETRIEVAL);
		}
		return blobByte;
	}

	private byte[] getPdfBlob(String memberOrApplId, String customerId, String letterName, String letterUploadedTime,
			String pdf_archival, StringBuilder query) throws ApplicationException {

		java.sql.Blob blob = null;
		byte[] blobByte = null;
		try {
			List<Object> params = new ArrayList<Object>();
			params.add(customerId);
			params.add(memberOrApplId);
			params.add(letterName);
			if (!"Y".equalsIgnoreCase(pdf_archival)) {
				params.add(letterUploadedTime);

			}
			if ("Y".equalsIgnoreCase(pdf_archival)) {
				blob = (java.sql.Blob) oracleJdbcTemplate.queryForObject(query.toString(), params.toArray(),
						java.sql.Blob.class);
			} else {
				blob = (java.sql.Blob) jdbcTemplate.queryForObject(query.toString(), params.toArray(),
						java.sql.Blob.class);
			}

			if (null != blob) {

				blobByte = blob.getBytes(1, (int) blob.length());
			}

		}
		catch (EmptyResultDataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.FAILED_TO_LOAD_DOWNLOAD_PDF);
		} 
		catch (SQLException exp) {
			exp.printStackTrace();
			throw new ApplicationException(exp, EEMConstants.FAILED_TO_DOWNLOAD_PDF);
		}
		return blobByte;
	}

	@Override
	public int getApplId(String customerId, String memberId) throws ApplicationException {
		Integer subsInd = 0;
		try {
			String query = CommonUtils.buildQuery("SELECT DISTINCT APPLICATION_ID FROM EM_MBR_ENROLLMENT ",
					" WHERE CUSTOMER_ID = ?  AND MEMBER_ID = ?   AND OVERRIDE_IND = 'N'",
					"  AND ENROLL_STATUS IN ('EPEND','EAPRV') FETCH FIRST ROW ONLY");

			subsInd = jdbcTemplate.queryForObject(query, Integer.class, new Object[] { customerId, memberId });

		} catch (EmptyResultDataAccessException exp) {
			LOG.info("EEMApplLepDaoImpl.getApplId()  >> NO ROW FOUND <<");
			return 0;
		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_RETRIEVAL);
		}
		return subsInd;
	}

	@Override
	public String validateReqDtCov(String customerId, String applId) throws ApplicationException {
		String lefEffDate = "";
		try {
			String query = CommonUtils.buildQuery(
					" SELECT LEP_EFF_DATE FROM EM_APPL_PLEP WHERE CUSTOMER_ID=? AND APPLICATION_ID=? AND OVERRIDE_IND='N' ORDER BY LAST_UPDT_TIME DESC FETCH FIRST ROW ONLY");

			lefEffDate = StringUtil
					.nonNullTrim(jdbcTemplate.queryForObject(query, String.class, new Object[] { customerId, applId }));

		} catch (EmptyResultDataAccessException exp) {
			LOG.info("EEMApplLepDaoImpl.getApplId()  >> NO ROW FOUND <<");

		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_RETRIEVAL);
		}
		return lefEffDate;
	}

	@Override
	public boolean validateHicNbrChanged(String customerId, String mbiHicNbr, String applId)
			throws ApplicationException {
		boolean result = false;
		try {
			String query = CommonUtils
					.buildQuery("SELECT HIC_NBR, MBI FROM EM_APPLICATION WHERE CUSTOMER_ID=? AND APPLICATION_ID=?");

			result = jdbcTemplate.query(query, new Object[] { customerId, applId }, new ResultSetExtractor<Boolean>() {

				@Override
				public Boolean extractData(ResultSet rs) throws SQLException, DataAccessException {
					String oldHicNbr = "";
					String mbiNumber = "";
					if (rs.next()) {
						oldHicNbr = nonNullTrim(rs.getString("HIC_NBR"));
						mbiNumber = nonNullTrim(rs.getString("MBI"));
					}

					if (!oldHicNbr.equalsIgnoreCase(mbiHicNbr) && !mbiNumber.equalsIgnoreCase(mbiHicNbr)) {
						return true;
					}
					return false;
				}

			});
		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_RETRIEVAL);
		}
		return result;
	}

	@Override
	public List<String> getPrtdRdsCnt(String mbrHicNbr, String srcTable) throws ApplicationException {

		List<String> list = new ArrayList<>();
		String sQuery = "";
		try {
			if (srcTable.equals(EEMConstants.EM_TABLE_BEQ)) {
				sQuery = "SELECT PRTDHIST_RECCNT,RDSHIST_RECCNT FROM BEQR WHERE ACTIVE_MBI = ?";

				list = jdbcTemplate.query(sQuery, new ResultSetExtractor<List<String>>() {

					@Override
					public List<String> extractData(ResultSet rs) throws SQLException {

						List<String> list = new LinkedList<String>();
						if (rs.next()) {
							String rdsHistoryCount = nonNullTrim(rs.getString("RDSHIST_RECCNT"));
							String partDHistoryCount = nonNullTrim(rs.getString("PRTDHIST_RECCNT"));
							list.add(rdsHistoryCount);
							list.add(partDHistoryCount);
						}

						return list;
					}

				}, mbrHicNbr);
			}

			if (list.isEmpty()) {
				if ("hic".equalsIgnoreCase(StringUtil.isHicOrMbi(mbrHicNbr))) {
					sQuery = "SELECT PRTDHIST_RECCNT,RDSHIST_RECCNT FROM MBD WHERE HIC_NBR=?";
				} else {
					sQuery = "SELECT PRTDHIST_RECCNT,RDSHIST_RECCNT FROM MBD WHERE MBI=?";
				}

				list = jdbcTemplate.query(sQuery, new ResultSetExtractor<List<String>>() {

					@Override
					public List<String> extractData(ResultSet rs) throws SQLException, DataAccessException {

						List<String> list = new LinkedList<String>();
						if (rs.next()) {
							String rdsHistoryCount = nonNullTrim(rs.getString("RDSHIST_RECCNT"));
							String partDHistoryCount = nonNullTrim(rs.getString("PRTDHIST_RECCNT"));
							list.add(rdsHistoryCount);
							list.add(partDHistoryCount);

						}

						return list;
					}

				}, mbrHicNbr);

			}
		}

		catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_RETRIEVAL);
		}
		return list;

	}

	@Override
	public void createApplLEPLetter(EEMApplTriggerDO triggerDo) throws ApplicationException {

		String openTriggerExist = "";
		boolean check = false;
		String ts = DateUtil.getCurrentDatetimeStamp();

		try {
			String check73 = CommonUtils.buildQuery(
					"SELECT TRIGGER_CODE FROM EM_APPL_TRIGGER WHERE CUSTOMER_ID = ? AND APPLICATION_ID = ? ",
					" AND TRIGGER_CODE IN ('0401AD','0401AP','0401BD','0401BP') AND TRIGGER_STATUS= 'OPEN' FETCH FIRST ROW ONLY ");

			Object[] params = new Object[] { triggerDo.getCustomerId(), triggerDo.getApplicationId() };
			openTriggerExist = nonNullTrim(jdbcTemplate.queryForObject(check73, params, String.class));

		} catch (EmptyResultDataAccessException exp) {
			LOG.info("EEMApplLepDaoImpl.checkOpenApplTrigger()  >> NO ROW FOUND <<");

		}

		try {

			if (!openTriggerExist.isEmpty()) {

				String updateSQL = CommonUtils.buildQuery(
						"UPDATE EM_APPL_TRIGGER SET EFFECTIVE_DATE =?, LAST_UPDT_TIME=?, LAST_UPDT_USERID=? WHERE CUSTOMER_ID = ? ",
						"AND APPLICATION_ID =? AND  TRIGGER_CODE IN ('0401AD','0401AP','0401BD','0401BP') ");

				Object[] params = new Object[] {
						nonNullTrim(triggerDo.getEffectiveDate()),
						ts, triggerDo.getCreateUserid(), triggerDo.getCustomerId(), triggerDo.getApplicationId()

				};
				int update = jdbcTemplate.update(updateSQL, params);
				if (update > 0) {
					check = true;
				}

			}

			if (!check) {
				
				applicationDAO.insertApplTrigger(triggerDo);

			}
		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_UPDATE);
		}

	}

	@Override
	public boolean verifyLEPRecord(String customerId, String applId) throws ApplicationException {
		String plepExist = validateReqDtCov(customerId, applId);
		return StringUtils.isBlank(plepExist) ? false : true;
	}

	@Override
	public EEMLepAttestInfoDO getTriggerDataForLEPAttestion(EEMLepAttestInfoDO lepAttestInfoDO)
			throws ApplicationException {

		try {
			String check73 = CommonUtils.buildQuery(
					" SELECT  TRIGGER_CODE , TRIGGER_STATUS , CREATE_TIME  FROM EM_MBR_TRIGGER WHERE CUSTOMER_ID = ?",
					"AND MEMBER_ID=? AND TRIGGER_CODE IN ('OBC3','73NM') FETCH FIRST ROW ONLY");

			lepAttestInfoDO.setObc3TimerCheck("no");
			if (StringUtils.isNotBlank(lepAttestInfoDO.getAttestStatus())) {
				lepAttestInfoDO.setIs73TxnExists("N");
			}

			jdbcTemplate.query(check73, new ResultSetExtractor<EEMLepAttestInfoDO>() {

				@Override
				public EEMLepAttestInfoDO extractData(ResultSet rs) throws SQLException, DataAccessException {

					if (rs.next()) {
						String trigCode = nonNullTrim(rs.getString("TRIGGER_CODE"));
						String trigStatus = nonNullTrim(rs.getString("TRIGGER_STATUS"));
						String createTime = DateFormatter.reFormat(nonNullTrim(rs.getString("CREATE_TIME")),
								DateFormatter.DB2_TIMESTAMP, DateFormatter.DB2_TIMESTAMP);
						if ("OBC3".equalsIgnoreCase(trigCode) && "EXPIRED".equalsIgnoreCase(trigStatus)) {
							lepAttestInfoDO.setObc3TimerCheck("yes");
						} else if ("C".equalsIgnoreCase(lepAttestInfoDO.getAttestStatus())
								&& "73NM".equalsIgnoreCase(trigCode)
								&& createTime.equals(lepAttestInfoDO.getCreateTime())) {
							lepAttestInfoDO.setIs73TxnExists("Y");
						}
					}
					return null;
				}

			}, lepAttestInfoDO.getCustomerId(), lepAttestInfoDO.getPrimaryId());

		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_RETRIEVAL);
		}
		return lepAttestInfoDO;

	}

	@Override
	public void getMbrLepAttest90DaysDetails(EEMLepAttestInfoDO lepAttestInfoDO) throws ApplicationException {

		try {
			String query = CommonUtils.buildQuery(
					" SELECT AFT90_RCVE_DATE,LAST_UPDT_USERID,AFT90_RESP_TYPE,AFT90_NOTIFI_IND,CREATE_TIME,CREATE_USERID,LAST_UPDT_TIME FROM EM_MBR_LEP_ATTN_OTHER WHERE CUSTOMER_ID = ? AND  MEMBER_ID = ? FETCH FIRST ROW ONLY");

			jdbcTemplate.query(query, new ResultSetExtractor<EEMLepAttestInfoDO>() {

				@Override
				public EEMLepAttestInfoDO extractData(ResultSet rs) throws SQLException, DataAccessException {

					if (rs.next()) {

						lepAttestInfoDO.setAttestationRecDate(nonNullTrim(rs.getString("AFT90_RCVE_DATE")));
						lepAttestInfoDO
								.setAttestationRecChannel(nonNullTrim(rs.getString("AFT90_RESP_TYPE")));
						lepAttestInfoDO
								.setNotifiedMemberAppeal(nonNullTrim(rs.getString("AFT90_NOTIFI_IND")));
						lepAttestInfoDO.setOtherCreateTime(nonNullTrim(rs.getString("CREATE_TIME")));
						lepAttestInfoDO.setOtherCreateUserId(nonNullTrim(rs.getString("CREATE_USERID")));
						lepAttestInfoDO.setOtherLastUpdtTime(nonNullTrim(rs.getString("LAST_UPDT_TIME")));
						lepAttestInfoDO
								.setOtherLastUpdtUserId(nonNullTrim(rs.getString("LAST_UPDT_USERID")));

					}
					return null;
				}

			}, lepAttestInfoDO.getCustomerId(), lepAttestInfoDO.getPrimaryId());

		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_RETRIEVAL);
		}

	}

	@Override
	public boolean checkMbrTimmerStatus(EMMbrTriggerDO triggerDO) throws ApplicationException {
		String timmerStatus = "";
		boolean check = false;
		List<String> params = new ArrayList<>();
		
		params.add(triggerDO.getCustomerId());
		params.add(triggerDO.getMemberId());
		params.add(triggerDO.getTriggerCode());
		params.add(triggerDO.getPlanId());
		params.add(triggerDO.getPbpId());
		
		if (StringUtil.isNotNullNotEmptyNotWhiteSpace(triggerDO.getTriggerStatus())) {
			timmerStatus = "AND TRIGGER_STATUS = ?";
			params.add(triggerDO.getTriggerStatus());
		}
		String query = CommonUtils.buildQuery("SELECT TRIGGER_CODE FROM EM_MBR_TRIGGER WHERE CUSTOMER_ID = ? ",
				"AND MEMBER_ID = ? AND TRIGGER_CODE = ?  AND PLAN_ID = ? AND PBP_ID= ? ", timmerStatus);
		try {

			jdbcTemplate.queryForObject(query, String.class, params.toArray());
			check = true;

		} catch (EmptyResultDataAccessException exp) {
			LOG.info("EEMApplLepDaoImpl.checkMbrTimmerStatus()  >> NO ROW FOUND <<");

		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_RETRIEVAL);
		}
		return check;
	}

	@Override
	public boolean checkMbrTriggerStatus(String customerId, String memberId, String triggerCode, String triggerStatus)
			throws ApplicationException {
		String timmerStatus = "";
		boolean check = false;
		try {

			if (StringUtil.isNotNullNotEmptyNotWhiteSpace(triggerStatus))
				timmerStatus = " AND TRIGGER_STATUS = '" + triggerStatus + "'";

			String query = CommonUtils.buildQuery("SELECT TRIGGER_CODE FROM EM_MBR_TRIGGER WHERE CUSTOMER_ID = ? ",
					"AND MEMBER_ID = ? AND TRIGGER_CODE = ? ", timmerStatus, " FETCH FIRST ROW ONLY ");
			Object[] params = new Object[] { customerId, memberId, triggerCode };

			jdbcTemplate.queryForObject(query, String.class, params);
			check = true;

		} catch (EmptyResultDataAccessException exp) {
			LOG.info("EEMApplLepDaoImpl.checkMbrTimmerStatus()  >> NO ROW FOUND <<");

		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_RETRIEVAL);
		}
		return check;

	}

	@Override
	public void checkAvailabilityOfLetters(String custId, String mbrId, EEMLepAttestInfoDO attestDO) {
		String letterUplodedTime = "";
		try {
			if("Y".equals(attestDO.getPdf_archival()))
			{
				attestDO.setLetterAvailabilityInDB(EEMConstants.VALUE_YES);
			}
			else {
				StringBuilder query = CommonUtils.buildQueryBuilder(
						"SELECT LETTER_CREATION_TIME FROM EM_CORR_DMS WHERE CUSTOMER_ID = ? AND PRIMARY_ID = ? AND",
						"CUSTOMER_LETTER_NAME = ? AND OVERRIDE_IND = ? ORDER BY LETTER_CREATION_TIME DESC FETCH FIRST ROW ONLY");
				List<String> parmList = new ArrayList<>();
				parmList.add(custId);
				parmList.add(mbrId);
				parmList.add(attestDO.getLetterName());
				parmList.add("N");

				
				Object[] objParms = parmList.toArray();
				letterUplodedTime = jdbcTemplate.queryForObject(query.toString(), String.class, objParms);
				if (letterUplodedTime.isEmpty()) {
					attestDO.setLetterUploadedTime("");
					attestDO.setLetterAvailabilityInDB(EEMConstants.VALUE_NO);
				}
				else {
					attestDO.setLetterUploadedTime(letterUplodedTime);
					attestDO.setLetterAvailabilityInDB(EEMConstants.VALUE_YES);
				}
			}
		}
		catch (EmptyResultDataAccessException exp) {
			attestDO.setLetterUploadedTime("");
			attestDO.setLetterAvailabilityInDB(EEMConstants.VALUE_NO);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public EEMLepSummaryDO getApplLepSummaryInfoBEQR(String hicNumber, String mbi) {
		EEMLepSummaryDO lepSumDO = new EEMLepSummaryDO();
		lepSumDO.setHicNBRVal(hicNumber);

		boolean hicFound = getEligbilityInfoHicBEQR(hicNumber, lepSumDO);
		if (!hicFound && StringUtils.isNotBlank(mbi)) {
			getEligbilityInfoMbiBEQR(mbi, lepSumDO);
		}

		String hicNBRVal = lepSumDO.getHicNBRVal();
		List<LepHistory> rdsHistory = getRdsHistoryBEQR(mbi, hicNBRVal);
		lepSumDO.setRdsList(rdsHistory);
		List<LepHistory> partDHistory = getPartDHistoryBEQR(mbi, hicNBRVal);
		lepSumDO.setPartDList(partDHistory);
		String maxUpdatedTimeProfile = getMaxUpdatedTimeProfile();
		List<MBDNunCmoDO> mbdNunCmo = getMbdNunCmo(mbi, maxUpdatedTimeProfile, hicNBRVal);
		lepSumDO.setNunCMOList(mbdNunCmo);

		return lepSumDO;
	}

	private List<LepHistory> getPartDHistoryBEQR(String mbi, String hicNBRVal) {
		List<LepHistory> data = null;
		try {

			String partDHistoryQuery = CommonUtils.buildQuery(
					"SELECT PRTD_SDATE, PRTD_EDATE,SEQ_NBR FROM BEQR_PRTDHISTORY WHERE HIC_NBR IN (?,?) ORDER BY SEQ_NBR ASC FETCH FIRST 3 ROWS ONLY ");

			data = jdbcTemplate.query(partDHistoryQuery, (rs, rowNum) -> {

				LepHistory lepHistoryVO = new LepHistory();
				lepHistoryVO.setEndDate(DateFormatter.reFormat(StringUtil.zeroTrim((rs.getString("PRTD_EDATE"))),
						DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
				lepHistoryVO.setStartDate(DateFormatter.reFormat(StringUtil.zeroTrim((rs.getString("PRTD_SDATE"))),
						DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
				lepHistoryVO.setSeqNbr(StringUtil.zeroTrim((rs.getString("SEQ_NBR"))));

				return lepHistoryVO;
			}, new Object[] { hicNBRVal, mbi });

		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_RETRIEVAL);
		}

		return data;
	}

	private List<LepHistory> getRdsHistoryBEQR(String mbi, String hicNBRVal) {
		List<LepHistory> data = null;
		try {
			String rdsHistoryQuery = CommonUtils.buildQuery(
					"SELECT SEQ_NBR,RDS_SDATE, RDS_EDATE FROM BEQR_RDSHISTORY WHERE HIC_NBR IN (?,?)  ORDER BY SEQ_NBR ASC Fetch FIRST 3 ROWS ONLY ");

			data = jdbcTemplate.query(rdsHistoryQuery, (rs, rowNum) -> {

				LepHistory lepHistoryVO = new LepHistory();
				lepHistoryVO.setEndDate(DateFormatter.reFormat(StringUtil.zeroTrim((rs.getString("RDS_EDATE"))),
						DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
				lepHistoryVO.setStartDate(DateFormatter.reFormat(StringUtil.zeroTrim((rs.getString("RDS_SDATE"))),
						DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
				lepHistoryVO.setSeqNbr(StringUtil.zeroTrim((rs.getString("SEQ_NBR"))));

				return lepHistoryVO;

			}, new Object[] { hicNBRVal, mbi });

		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_RETRIEVAL);
		}
		return data;
	}

	private void getEligbilityInfoMbiBEQR(String mbi, EEMLepSummaryDO lepSumDO) {
		try {
			String eligbilityInfoQueryMbi = CommonUtils.buildQuery(
					"SELECT COPAY_LEVEL_ID1, COPAY_LEVEL_ID2, PRTD_PREMSUBS_PCT1, PRTD_PREMSUBS_PCT2,",
					"PRTA_ENTITLE_DATE, PRTA_ENTITLE_EDATE, PRTB_ENTITLE_DATE, BIRTH_DATE, ",
					"PRTB_ENTITLE_EDATE,PRTD_ELIG_SDATE,SUBSIDY_SDATE1, SUBSIDY_EDATE1, SUBSIDY_SDATE2, SUBSIDY_EDATE2 ",
					"FROM BEQR WHERE ACTIVE_MBI=? FETCH FIRST ROWS ONLY");

			jdbcTemplate.query(eligbilityInfoQueryMbi, new ResultSetExtractor<EEMLepSummaryDO>() {

				@Override
				public EEMLepSummaryDO extractData(ResultSet rs) throws SQLException {

					if (rs.next()) {
						lepSumDO.setCopayLEVELID1(StringUtil.zeroTrim(rs.getString("COPAY_LEVEL_ID1")));
						lepSumDO.setCopayLEVELID2(StringUtil.zeroTrim(rs.getString("COPAY_LEVEL_ID2")));
						lepSumDO.setPrtdPREMSUBSPCT1(StringUtil.zeroTrim(rs.getString("PRTD_PREMSUBS_PCT1")));
						lepSumDO.setPrtdPREMSUBSPCT2(StringUtil.zeroTrim(rs.getString("PRTD_PREMSUBS_PCT2")));
						lepSumDO.setMbrBirthDt(StringUtil.zeroTrim(rs.getString("BIRTH_DATE")));
						lepSumDO.setPartAEntitleSDate(StringUtil.zeroTrim(rs.getString("PRTA_ENTITLE_DATE")));
						lepSumDO.setPartAEntitleEDate(StringUtil.zeroTrim(rs.getString("PRTA_ENTITLE_EDATE")));
						lepSumDO.setPartBEntitleSDate(StringUtil.zeroTrim(rs.getString("PRTB_ENTITLE_DATE")));
						lepSumDO.setPartBEntitleEDate(StringUtil.zeroTrim(rs.getString("PRTB_ENTITLE_EDATE")));
						lepSumDO.setPartDEntitleSDate(StringUtil.zeroTrim(rs.getString("PRTD_ELIG_SDATE")));
						lepSumDO.setSubsidySDate1(StringUtil.zeroTrim(rs.getString("SUBSIDY_SDATE1")));
						lepSumDO.setSubsidyEDate1(StringUtil.zeroTrim(rs.getString("SUBSIDY_EDATE1")));
						lepSumDO.setSubsidySDate2(StringUtil.zeroTrim(rs.getString("SUBSIDY_SDATE2")));
						lepSumDO.setSubsidyEDate2(StringUtil.zeroTrim(rs.getString("SUBSIDY_EDATE2")));
						lepSumDO.setEligibilitySrcTable(EEMConstants.EM_TABLE_BEQ);
					}

					return null;
				}
			}, mbi);
		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_RETRIEVAL);
		}
		
	}

	private boolean getEligbilityInfoHicBEQR(String hicNumber, EEMLepSummaryDO lepSumDO) {
		boolean hicFound = false;
		String eligbilityInfoQuery = CommonUtils.buildQuery(
				"SELECT COPAY_LEVEL_ID1, COPAY_LEVEL_ID2, PRTD_PREMSUBS_PCT1, PRTD_PREMSUBS_PCT2,",
				"PRTA_ENTITLE_DATE, PRTA_ENTITLE_EDATE, PRTB_ENTITLE_DATE,BIRTH_DATE, ",
				"PRTB_ENTITLE_EDATE,PRTD_ELIG_SDATE,SUBSIDY_SDATE1, SUBSIDY_EDATE1, SUBSIDY_SDATE2, SUBSIDY_EDATE2 ",
				"FROM BEQR WHERE HIC_NBR=? FETCH FIRST ROWS ONLY");
		try {
			hicFound = jdbcTemplate.query(eligbilityInfoQuery, new ResultSetExtractor<Boolean>() {

				@Override
				public Boolean extractData(ResultSet rs) throws SQLException {

					if (rs.next()) {
						lepSumDO.setCopayLEVELID1(StringUtil.zeroTrim(rs.getString("COPAY_LEVEL_ID1")));
						lepSumDO.setCopayLEVELID2(StringUtil.zeroTrim(rs.getString("COPAY_LEVEL_ID2")));
						lepSumDO.setPrtdPREMSUBSPCT1(StringUtil.zeroTrim(rs.getString("PRTD_PREMSUBS_PCT1")));
						lepSumDO.setPrtdPREMSUBSPCT2(StringUtil.zeroTrim(rs.getString("PRTD_PREMSUBS_PCT2")));
						lepSumDO.setMbrBirthDt(StringUtil.zeroTrim(rs.getString("BIRTH_DATE")));
						lepSumDO.setPartAEntitleSDate(StringUtil.zeroTrim(rs.getString("PRTA_ENTITLE_DATE")));
						lepSumDO.setPartAEntitleEDate(StringUtil.zeroTrim(rs.getString("PRTA_ENTITLE_EDATE")));
						lepSumDO.setPartBEntitleSDate(StringUtil.zeroTrim(rs.getString("PRTB_ENTITLE_DATE")));
						lepSumDO.setPartBEntitleEDate(StringUtil.zeroTrim(rs.getString("PRTB_ENTITLE_EDATE")));
						lepSumDO.setPartDEntitleSDate(StringUtil.zeroTrim(rs.getString("PRTD_ELIG_SDATE")));
						lepSumDO.setSubsidySDate1(StringUtil.zeroTrim(rs.getString("SUBSIDY_SDATE1")));
						lepSumDO.setSubsidyEDate1(StringUtil.zeroTrim(rs.getString("SUBSIDY_EDATE1")));
						lepSumDO.setSubsidySDate2(StringUtil.zeroTrim(rs.getString("SUBSIDY_SDATE2")));
						lepSumDO.setSubsidyEDate2(StringUtil.zeroTrim(rs.getString("SUBSIDY_EDATE2")));
						lepSumDO.setEligibilitySrcTable(EEMConstants.EM_TABLE_BEQ);

						return true;
					}
					return false;
				}
			}, hicNumber);
		} catch (DataAccessException exception) {
			throw new ApplicationException(exception, EEMConstants.ERROR_RETRIEVAL);
		}
		return hicFound;
	}

	

}
