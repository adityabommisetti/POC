package com.medicare.mss.vo;

import java.util.List;

import com.medicare.mss.util.LabelValuePair;

import lombok.Data;

@Data
public class EEMBilPaymentEntryCacheVO {
	private List<LabelValuePair> payTypesList;
	private String bankAcctCd;
}
