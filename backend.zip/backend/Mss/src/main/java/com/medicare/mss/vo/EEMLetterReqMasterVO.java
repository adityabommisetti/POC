package com.medicare.mss.vo;

import java.util.List;

import lombok.Data;

@Data
public class EEMLetterReqMasterVO {
	private boolean nextPage;
	private List<EEMLetterReqVO> letterReqVOs;
}