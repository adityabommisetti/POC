package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class EEMBillingInvCommentDO extends EEMMbrCommentDO {

	@ColumnMapper(columnName = "INVOICE_NBR", propertyName = "invoiceNbr")
	private String invoiceNbr;
	
}
