/**
 * 
 */
package com.medicare.mss.aop;

import java.time.Duration;
import java.time.Instant;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

/**
 * @author DU20098149
 *
 */
@Aspect
@Configuration
public class LogExecutionTimeAspect {
	
	private static final Logger LOG = LoggerFactory.getLogger(LogExecutionTimeAspect.class);
	
	@Around("@annotation(com.medicare.mss.aop.LogExecutionTime)")
	public Object controllerAround(ProceedingJoinPoint joinPoint) throws Throwable {
		LOG.info("method {} Started..", joinPoint.getSignature());
		
		Instant start = Instant.now();
		Object object = joinPoint.proceed();
		Instant finish = Instant.now();
		
		long timeTaken = Duration.between(start, finish).toMillis();

		LOG.info("method {} finished Successfully..", joinPoint.getSignature());
		LOG.info("Time Taken by method {} is {} milliseconds", joinPoint.getSignature(), timeTaken);

		return object;
	}

}
