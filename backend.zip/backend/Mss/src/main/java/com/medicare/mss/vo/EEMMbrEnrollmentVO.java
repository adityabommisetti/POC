package com.medicare.mss.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode(callSuper = false)
public class EEMMbrEnrollmentVO extends BaseVO implements EMDatedSegmentVO, Cloneable, Serializable {

	public static final String MBR_STAT_DAPRV = "DAPRV";

	public static final String MBR_STAT_DPEND = "DPEND";
	public static final String MBR_STAT_EAPRV = "EAPRV";
	public static final String MBR_STAT_EPEND = "EPEND";
	/**
	 * 
	 */
	private static final long serialVersionUID = 6054394168314137907L;

	private String applicationDate;
	private int applicationId;
	private String buttonClicked;
	private String cancellationReason;
	private String disReasonCd;
	private String editOverrideInd;
	private String effEndDate;
	private String effStartDate;
	private String elcDerivedInd;
	private String electionTypeCd;
	private String enrollReasonCd;
	private String enrollSrceCd;
	private String enrollStatus;
	private String groupName;
	private String grpId;
	private String lastUsedSepDate;
	private String memberId;
	private String overrideInd;
	private String pbpId;
	private String pbpSegmentId;
	private String planDesignation;
	private String planId;
	private String planReasonCd;
	private String planType;
	private String productId;
	private String productName;
	private String receiptDate;
	private String receivedDate;
	private String rxId;
	private String sepElectionDate;
	private String sepReasonCd;
	private String signatureDate;
	private String supplementalId;
	private String trg72Ind;

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	public String getApplicationDateFrmt() {
		return DateFormatter.reFormat(applicationDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getEffEndDateFrmt() {
		return DateFormatter.reFormat(effEndDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getEffStartDateFrmt() {
		return DateFormatter.reFormat(effStartDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getReceiptDateFrmt() {
		return DateFormatter.reFormat(receiptDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getReceivedDateFrmt() {
		return DateFormatter.reFormat(receivedDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getSepElectionDateFrmt() {
		return DateFormatter.reFormat(sepElectionDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getSignatureDateFrmt() {
		return DateFormatter.reFormat(signatureDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	@Override
	public String getType() {
		return grpId + productId;
	}

	public boolean isDisenrollment() {

		if (MBR_STAT_DPEND.equals(enrollStatus) || MBR_STAT_DAPRV.equals(enrollStatus))
			return true;

		return false;
	}

	@Override
	public boolean isEndDateChange(Object chkVO) {
		return false;
	}

	public boolean isEnrolled() {

		if (enrollStatus.equals(MBR_STAT_EAPRV))
			return true;

		return false;
	}

	@Override
	public boolean isForSamePeriod(Object obj) {
		EEMMbrEnrollmentVO chkVO = (EEMMbrEnrollmentVO) obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate) && chkVO.getEffEndDate().equals(this.effEndDate)
				&& chkVO.getGrpId().equals(this.grpId) && chkVO.getProductId().equals(this.productId)
				&& chkVO.getMemberId().equals(this.memberId) && chkVO.getCustomerId().equals(this.getCustomerId())
				&& chkVO.getOverrideInd().equals(this.overrideInd))
			return true;
		return false;
	}

	@Override
	public boolean isSame(Object obj) {

		EEMMbrEnrollmentVO chkVO = (EEMMbrEnrollmentVO) obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate) && chkVO.getEffEndDate().equals(this.effEndDate)
				&& chkVO.getGrpId().equals(this.grpId) && chkVO.getProductId().equals(this.productId)
				&& chkVO.getMemberId().equals(this.memberId) && chkVO.getCustomerId().equals(this.getCustomerId())
				&& chkVO.getOverrideInd().equals(this.overrideInd) && chkVO.getCreateTime().equals(this.getCreateTime())
				&& chkVO.getCreateUserId().equals(this.getCreateUserId())
				&& chkVO.getLastUpdtTime().equals(this.getLastUpdtTime())
				&& chkVO.getLastUpdtUserId().equals(this.getLastUpdtUserId()))
			return true;
		return false;
	}

	public void setApplicationDateFrmt(String applicationDate) {
		this.applicationDate = DateFormatter.reFormat(applicationDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
	}

	public void setEffEndDateFrmt(String effEndDate) {
		this.effEndDate = DateFormatter.reFormat(effEndDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public void setEffStartDateFrmt(String effStartDate) {
		this.effStartDate = DateFormatter.reFormat(effStartDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public void setReceiptDateFrmt(String receiptDate) {
		this.receiptDate = DateFormatter.reFormat(receiptDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
		;
	}

	public void setReceivedDateFrmt(String receivedDate) {
		this.receivedDate = DateFormatter.reFormat(receivedDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public void setSepElectionDateFrmt(String sepElectionDate) {
		this.sepElectionDate = DateFormatter.reFormat(sepElectionDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
	}

	public void setSignatureDateFrmt(String signatureDate) {
		this.signatureDate = DateFormatter.reFormat(signatureDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}
}
