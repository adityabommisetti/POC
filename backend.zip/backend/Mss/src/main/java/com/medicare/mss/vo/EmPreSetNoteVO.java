package com.medicare.mss.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EmPreSetNoteVO implements Serializable {

	private static final long serialVersionUID = -5197176077583085162L;

	private String radioCheck;
	private String preSetNote;
	private String preSetNoteDescr;
	private String preSetKey;

}
