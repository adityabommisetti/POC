package com.medicare.mss.domainobject;

import java.io.Serializable;

import com.medicare.mss.annotation.ColumnMapper;
import com.medicare.mss.vo.EMDatedSegmentVO;

import lombok.Data;

@Data
public class EmMbrPosInfoDO implements EMDatedSegmentVO, Cloneable, Serializable{
	
	private static final long serialVersionUID = -7262253414514823026L;

	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;	
	
	@ColumnMapper(columnName = "MEMBER_ID", propertyName = "memberId")
	private String memberId;
	
	@ColumnMapper(columnName = "NOTIFICATION_DT", propertyName = "notificateDate")
	private String notificateDate;
	
	@ColumnMapper(columnName = "STATUS_FLAG", propertyName = "statusFlag")
	private String statusFlag;
	
	@ColumnMapper(columnName = "DRUG_EDIT_STATUS", propertyName = "drugEditStatus")
	private String drugEditStatus;
	
	@ColumnMapper(columnName = "DRUG_EDIT_CLASS", propertyName = "drugEditClass")
	private String drugEditClass;
	
	@ColumnMapper(columnName = "IMPLEMENTATION_DT", propertyName = "implDate")
	private String implDate;
	
	@ColumnMapper(columnName = "TXN_STATUS", propertyName = "txnStatus")
	private String txnStatus;
	
	@ColumnMapper(columnName = "DRUG_EDIT_CODE", propertyName = "drugCode")
	private String drugCode;
	
	@ColumnMapper(columnName = "TERMINATION_DT", propertyName = "terminationDate")
	private String terminationDate;
	
	@ColumnMapper(columnName = "OVERRIDE_IND", propertyName = "overrideInd")
	private String overrideInd;
	
	@ColumnMapper(columnName = "CREATE_TIME", propertyName = "createTime")
	private String createTime;
	
	@ColumnMapper(columnName = "CREATE_USERID", propertyName = "createUserId")
	private String createUserId;
	
	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;
	
	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserId")
	private String lastUpdtUserId;
	
	private String groupId;	
	private String productId;	
	private String planId;	
	private String pbpId;	
	private String planDesignation;	
	private String posEditOrDeleteOrModifyStatus;
	private String posCurrDate;
	private String ccmDate;
	private String enrollStartDate;
	private String enrollEndDate;
	
	@ColumnMapper(columnName = "NOTIFICATION_EDATE", propertyName = "notificateEndDate")
	private String notificateEndDate;
	
	@ColumnMapper(columnName = "IMPLEMENTATION_EDATE", propertyName = "implementationEndDate")
	private String implementationEndDate;
	
	@ColumnMapper(columnName = "PRESCRIBER_LIMITATION", propertyName = "prescriberLtStatus")
	private String prescriberLtStatus;
	
	@ColumnMapper(columnName = "PHARMACY_LIMITATION", propertyName = "pharamacyLtStatus")
	private String pharamacyLtStatus;
	
	private String message;

	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	public String getType() {
		return "";
	}


	public boolean isForSamePeriod(Object chkVO) {
		return false;
	}

	public boolean isEndDateChange(Object chkVO) {
		return false;
	}


	@Override
	public String getEffEndDate() {
		return null;
	}

	@Override
	public String getEffStartDate() {
		return null;
	}

	@Override
	public void setEffEndDate(String effEndDate) {
		// Auto-generated method stub
	}

	@Override
	public void setEffStartDate(String effStartDate) {
		// Auto-generated method stub
	}

	@Override
	public boolean isSame(Object chkVO) {
		// Auto-generated method stub
		return false;
	}
	
}
