package com.medicare.mss.vo;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.LabelValuePair;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EEMLetterReqVO implements Serializable {

	private static final long serialVersionUID = 5752720518754925861L;

	private String customerId;
	private String sourceType;
	private String sourceTypeDesc;
	private String primaryId;
	private String effDate;
	private String createTime;
	private String triggerType;
	private String triggerTypeDesc;
	private String triggerCode;
	private String triggerCodeDesc;
	private String triggerStatus;
	private String triggerStatusDesc;
	private String mbrFName;
	private String mbrLName;
	private String createUserId;
	private String lastUpdtTime;
	private String lastUpdtUserId;
	private String letterName;
	private String letterNameDesc;
	private String planId;
	private String pbpId;
	private String planDesignation;

	private String[] varDataId;
	private String[] varDataType;
	private String[] varDataLen;
	private String[] varDataDesc;
	private String[] varDataText;

	private List<EEMLetterVarDataVO> lstVarData;
	private List<LabelValuePair> lstLetterName;

	public String getEffDateFrmt() {
		return DateFormatter.reFormat(effDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setEffDateFrmt(String effDate) {
		this.effDate = DateFormatter.reFormat(effDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getCreateTimeFrmt() {
		return DateFormatter.reFormat(createTime, DateFormatter.DB2_TIMESTAMP, DateFormatter.MM_DD_YYYY_HH_MM_SS);
	}

}
