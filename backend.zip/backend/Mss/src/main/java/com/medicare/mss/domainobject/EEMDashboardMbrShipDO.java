package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMDashboardMbrShipDO {
	@ColumnMapper(columnName = "PLAN_ID", propertyName = "planId")
	private String planId;
	@ColumnMapper(columnName = "PBP_ID", propertyName = "pbpId")
	private String pbpId;
	@ColumnMapper(columnName = "ENROLL_COUNT", propertyName = "enrollCount")
	private String enrollCount;
	@ColumnMapper(columnName = "DISENROLL_COUNT", propertyName = "disEnrollCount")
	private String disEnrollCount;
}
