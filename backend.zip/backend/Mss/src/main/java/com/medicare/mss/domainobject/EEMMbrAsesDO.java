package com.medicare.mss.domainobject;

import java.io.Serializable;

import com.medicare.mss.annotation.ColumnMapper;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.vo.EMDatedSegmentVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class EEMMbrAsesDO extends BaseDO implements EMDatedSegmentVO, Cloneable, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4234114067016832374L;

	@ColumnMapper(columnName = "MEMBER_ID", propertyName = "memberId")
	private String memberId;

	@ColumnMapper(columnName = "EFF_START_DATE", propertyName = "effStartDate")
	private String effStartDate;

	@ColumnMapper(columnName = "EFF_END_DATE", propertyName = "effEndDate")
	private String effEndDate;

	@ColumnMapper(columnName = "OVERRIDE_IND", propertyName = "overrideInd")
	private String overrideInd;

	@ColumnMapper(columnName = "FAMILY_ID", propertyName = "odsiFamilyId")
	private String odsiFamilyId;

	@ColumnMapper(columnName = "MBR_SUFFIX", propertyName = "mbrSuffix")
	private String mbrSuffix;

	@ColumnMapper(columnName = "PLAN_VERSION", propertyName = "planVersion")
	private String planVersion;

	@ColumnMapper(columnName = "MPI", propertyName = "mpi")
	private String mpi;

	@ColumnMapper(columnName = "MEDICARE_IND", propertyName = "medicaidInd")
	private String medicaidInd;

	@ColumnMapper(columnName = "PLAN_VER_CHG_IND", propertyName = "planVersionChangeInd")
	private String planVersionChangeInd;

	@ColumnMapper(columnName = "ASES_STATUS", propertyName = "status")
	private String status;

	@ColumnMapper(columnName = "REGION_CODE", propertyName = "regionCode")
	private String regionCode;

	@ColumnMapper(columnName = "COST_SHARING_FLAG", propertyName = "costSharing")
	private String costSharing;

	@ColumnMapper(columnName = "MAX_COPY", propertyName = "maxCopy")
	private String maxCopy;

	@ColumnMapper(columnName = "EXT_FLAG", propertyName = "extFlag")
	private String extFlag;

	@ColumnMapper(columnName = "SPEND_DOWN_FLAG", propertyName = "spendDwnFlg")
	private String spendDwnFlg;

	@ColumnMapper(columnName = "GROUP_CODE", propertyName = "grpCd")
	private String grpCd;

	@ColumnMapper(columnName = "DECEASED_DATE", propertyName = "deceasedDt")
	private String deceasedDt;

	public String getEffEndDateFrmt() {
		return DateFormatter.reFormat(effEndDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getEffStartDateFrmt() {
		return DateFormatter.reFormat(effStartDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setEffEndDateFrmt(String effEndDate) {
		this.effEndDate = DateFormatter.reFormat(effEndDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public void setEffStartDateFrmt(String effStartDate) {
		this.effStartDate = DateFormatter.reFormat(effStartDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	@Override
	public String getType() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isEndDateChange(Object chkVO) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isForSamePeriod(Object chkVO) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSame(Object chkVO) {
		// TODO Auto-generated method stub
		return false;
	}

}
