package com.medicare.mss.vo;

public interface EMDatedSegmentVO {

	public Object clone() throws CloneNotSupportedException;

	public String getEffEndDate();

	public String getEffStartDate();

	public String getLastUpdtTime();

	public String getOverrideInd();

	public String getType();

	public boolean isEndDateChange(Object chkVO);

	public boolean isForSamePeriod(Object chkVO);

	public boolean isSame(Object chkVO);

	public void setCreateTime(String ts);

	public void setCreateUserId(String userId);

	public void setEffEndDate(String effEndDate);

	public void setEffStartDate(String effStartDate);

	public void setLastUpdtTime(String ts);

	public void setLastUpdtUserId(String userId);

	public void setOverrideInd(String overrideInd);
	

}
