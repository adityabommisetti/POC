/**
 * 
 */
package com.medicare.mss.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;

/**
 * @author DU20098149
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EEMWFCaseVO implements Serializable {

	private static final long serialVersionUID = -7781164455130400688L;

	private String appId;
	private String applicationStatus;
	private String caseDate;
	private String caseDesc;
	private String caseDueDate;
	private Integer caseId;
	private String caseStatus;
	private String currentUserId;
	private String customerId;
	private String daysRemaining;
	private String firstName;
	private String lastName;
	private String mbrId;
	private String mbrName;
	private String medicareId;
	private String overrideInd;
	private String queueCode;
	private String riskInd;
	private String source;
	private String caseTimeStamp;
	private String supplementalId;
	private String reAssignTypeCode;
	private String caseReassignDate;
	private String initialUserId;
	private String queueName;
	private boolean commentIndicator;

	public String getCaseDateFrmt() {
		return DateFormatter.reFormat(caseDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getCaseDueDateFrmt() {
		return DateFormatter.reFormat(caseDueDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setCaseDateFrmt(String caseDate) {
		this.caseDate = DateFormatter.reFormat(caseDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public void setCaseDueDateFrmt(String caseDueDate) {
		this.caseDueDate = DateFormatter.reFormat(caseDueDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

}
