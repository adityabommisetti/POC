package com.medicare.mss.domainobject;

import lombok.Data;

@Data
public class EEMApplCommentsDO {

	private String customerId;
	private int applicationId;
	private String applComments;
	private String createTime;
	private String createUserId;
	private String insertInd = "N";
	
	private int commentSeqNbr;
	
}
