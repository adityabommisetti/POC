package com.medicare.mss.service;

import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.caching.EEMProfileSettings;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMApplDAO;
import com.medicare.mss.dao.EEMMbrDAO;
import com.medicare.mss.dao.EEMTimersDAO;
import com.medicare.mss.domainobject.EEMApplTriggerDO;
import com.medicare.mss.domainobject.EEMTimersDO;
import com.medicare.mss.domainobject.EMMbrTriggerDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.vo.EEMTimersMasterVO;
import com.medicare.mss.vo.EEMTimersVO;
import com.medicare.mss.vo.PageableVO;

@Service
@Transactional(rollbackFor = ApplicationException.class)
public class EEMTimersService {

	@Autowired
	CacheService sessionHelper;

	@Autowired
	EEMTimersDAO eeMTimersDAO;

	@Autowired
	EEMCodeCache eemCodeCache;

	@Autowired
	EEMApplDAO eemApplDAO;

	@Autowired
	EEMMbrDAO eemMbrDAO;
	
	@Autowired
	EEMProfileSettings eemProfileSettings;

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public EEMTimersMasterVO getSearchList(Map<String, String> searchParamMap) {
		
		EEMTimersMasterVO masterVO = new EEMTimersMasterVO();
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String OBC1Desc = eemProfileSettings.getCalendarProfileText(customerId, EEMConstants.TRIG_CODE_OBC1);
		String OBC2Desc = eemProfileSettings.getCalendarProfileText(customerId, EEMConstants.TRIG_CODE_OBC2);
		String OBC3Desc = eemProfileSettings.getCalendarProfileText(customerId, EEMConstants.TRIG_CODE_OBC3);
		String LE21Desc = eemProfileSettings.getCalendarProfileText(customerId, EEMConstants.TRIG_CODE_LE21);
		List<EEMTimersVO> timersSearchVOList = new ArrayList<>();
		PageableVO pageableVO = eeMTimersDAO.getTimersList(searchParamMap, customerId, false);
		List<EEMTimersDO> timersSearchDOList = (List<EEMTimersDO>) pageableVO.getContent();
		
		for (EEMTimersDO timersDO : timersSearchDOList) {
			EEMTimersVO timersVO = new EEMTimersVO();
			
			if(timersDO.getTriggerCode().equals(EEMConstants.TRIG_CODE_OBC1)) {
				timersDO.setTimerType(OBC1Desc);	
			}
			else if(timersDO.getTriggerCode().equals(EEMConstants.TRIG_CODE_OBC2)) {
				timersDO.setTimerType(OBC2Desc);	
			}
			else if(timersDO.getTriggerCode().equals(EEMConstants.TRIG_CODE_OBC3)) {
				timersDO.setTimerType(OBC3Desc);	
			}
			else if(timersDO.getTriggerCode().equals(EEMConstants.TRIG_CODE_LE21)) {
				timersDO.setTimerType(LE21Desc);	
			}
			
			BeanUtils.copyProperties(timersDO, timersVO);
			timersSearchVOList.add(timersVO);
		}
		
		masterVO.setEmmTimersVOs(timersSearchVOList);
		masterVO.setNextPage(pageableVO.isNextPage());
		return masterVO;
	}

	public Boolean holdTimersUpdate(List<EEMTimersVO> eemTimersVOList) {

		String userId = sessionHelper.getUserInfo().getUserId();
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String ts = DateUtil.getCurrentDatetimeStamp();
		int sqlCnt = 0;

		try {
			if (eemTimersVOList.size() == 1) {
				EEMTimersVO eemTimersVO = eemTimersVOList.get(0);
				String activationTime = eemTimersVO.getActivationTime();
				String changedActivationTime = eemTimersVO.getEditActivationDateStatus();
				if (activationTime.equals(changedActivationTime)) {
					eemTimersVO.setCheckStatus("Y");
				}
			}
			for (EEMTimersVO eemTimersVO : eemTimersVOList) {

				String activationTime = eemTimersVO.getActivationTime();
				String changedActivationTime = eemTimersVO.getEditActivationDateStatus();
				eemTimersVO.setCustomerId(customerId);

				EEMTimersDO eemTimersDO = new EEMTimersDO();
				BeanUtils.copyProperties(eemTimersVO, eemTimersDO);
				EMMbrTriggerDO emMbrTriggerDO = getMbrTriggerDO(userId, customerId, ts, eemTimersDO);
				EEMApplTriggerDO eemApplTriggerDO = getApplTriggerDO(userId, customerId, ts, eemTimersDO);

				String checkStatus = trimToEmpty(eemTimersVO.getCheckStatus());
				String searchType = eemTimersDO.getSourceType();

				if ("Y".equals(checkStatus)) {
					sqlCnt = eeMTimersDAO.updateTimer(eemTimersDO, userId);
					if (sqlCnt == 1) {
						if (searchType.equals("A")) {
							eemApplTriggerDO.setTriggerStatus(EEMConstants.TRIG_STATUS_CLOSED);
							sqlCnt = eemApplDAO.insertApplTrigger(eemApplTriggerDO);
						} else {
							emMbrTriggerDO.setTriggerStatus(EEMConstants.TRIG_STATUS_CLOSED);
							sqlCnt = eemMbrDAO.insertMbrTrigger(emMbrTriggerDO);
						}
						if (sqlCnt != 1) {
							throw new ApplicationException("Invalid Data");
						}
					}
				} else if (!activationTime.equals(changedActivationTime)) {
					String currentDate = DateUtil.getTodaysDate();
					String msg = DateFormatter.checkPastDate(changedActivationTime, currentDate);
					if (msg != " ") {
						throw new ApplicationException(msg);
					} else {
						sqlCnt = eeMTimersDAO.updateTimer(eemTimersDO, userId);
						if (sqlCnt == 1) {
							if (searchType.equals("A")) {
								eemApplTriggerDO.setTriggerStatus(EEMConstants.TRIG_STATUS_OPEN);
								eemApplTriggerDO.setEffectiveDate(eemTimersDO.getEditActivationDateStatus());
								sqlCnt = eemApplDAO.insertApplTrigger(eemApplTriggerDO);
							} else {
								emMbrTriggerDO.setTriggerStatus(EEMConstants.TRIG_STATUS_OPEN);
								emMbrTriggerDO.setEffectiveDate(eemTimersDO.getEditActivationDateStatus());
								sqlCnt = eemMbrDAO.insertMbrTrigger(emMbrTriggerDO);
							}
							if (sqlCnt != 1) {
								throw new ApplicationException("Invalid Data");
							}
						}
					}
				}
			}
		} catch (Exception exp) {
			throw new ApplicationException(exp.getMessage());
		}
		return sqlCnt > 0;
	}

	private EEMApplTriggerDO getApplTriggerDO(String userId, String customerId, String ts, EEMTimersDO eemTimersDO) {
		EEMApplTriggerDO eemApplTriggerDO = new EEMApplTriggerDO();
		eemApplTriggerDO.setCustomerId(customerId);
		eemApplTriggerDO.setApplicationId(eemTimersDO.getPrimaryId());
		eemApplTriggerDO.setTriggerType(eemTimersDO.getTriggerType());
		eemApplTriggerDO.setEffectiveDate(eemTimersDO.getActivationTime());
		eemApplTriggerDO.setCreateTime(ts);
		eemApplTriggerDO.setTriggerCode(eemTimersDO.getTriggerCode());
		eemApplTriggerDO.setOrigTriggerType("");
		eemApplTriggerDO.setOrigTriggerCode("");
		eemApplTriggerDO.setOrigEffectiveDate("");
		eemApplTriggerDO.setOrigTriggerCreateTime("");
		eemApplTriggerDO.setCreateUserid(userId);
		eemApplTriggerDO.setLastUpdtUserid(userId);
		eemApplTriggerDO.setLastUpdtTime(ts);
		return eemApplTriggerDO;
	}

	private EMMbrTriggerDO getMbrTriggerDO(String userId, String customerId, String ts, EEMTimersDO eemTimersDO) {
		EMMbrTriggerDO emMbrTriggerDO = new EMMbrTriggerDO();
		emMbrTriggerDO.setCustomerId(customerId);
		emMbrTriggerDO.setMemberId(eemTimersDO.getPrimaryId());
		emMbrTriggerDO.setTriggerType(eemTimersDO.getTriggerType());
		emMbrTriggerDO.setEffectiveDate(eemTimersDO.getActivationTime());
		emMbrTriggerDO.setCreateTime(ts);
		emMbrTriggerDO.setTriggerCode(eemTimersDO.getTriggerCode());
		emMbrTriggerDO.setPlanId(eemTimersDO.getPlanId());
		emMbrTriggerDO.setPbpId(eemTimersDO.getPbpId());
		emMbrTriggerDO.setPlanDesignation(eemTimersDO.getPlanDesignation());
		getBasicMbrTriggerDO(userId, ts, emMbrTriggerDO);
		return emMbrTriggerDO;
	}

	public void getBasicMbrTriggerDO(String userId, String ts, EMMbrTriggerDO emMbrTriggerDO) {
		emMbrTriggerDO.setProcessSource("");
		emMbrTriggerDO.setOrigTriggerType("");
		emMbrTriggerDO.setOrigTriggerCode("");
		emMbrTriggerDO.setOrigEffectiveDate("");
		emMbrTriggerDO.setOrigTriggerCreateTime("");
		emMbrTriggerDO.setCreateUserId(userId);
		emMbrTriggerDO.setLastUpdtUserId(userId);
		emMbrTriggerDO.setLastUpdtTime(ts);
		emMbrTriggerDO.setFileBatchId("");
		emMbrTriggerDO.setLetterName("");
		emMbrTriggerDO.setRecordType("");
	}

	public List<LabelValuePair> getTimersType() {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String type = "TimerTypes";
		List<LabelValuePair> timerTypePair = eemCodeCache.getLstTriggerCodes(type);
		String OBC1Desc = eemProfileSettings.getCalendarProfileText(customerId, EEMConstants.TRIG_CODE_OBC1);
		String OBC2Desc = eemProfileSettings.getCalendarProfileText(customerId, EEMConstants.TRIG_CODE_OBC2);
		String OBC3Desc = eemProfileSettings.getCalendarProfileText(customerId, EEMConstants.TRIG_CODE_OBC3);
		String LE21Desc = eemProfileSettings.getCalendarProfileText(customerId, EEMConstants.TRIG_CODE_LE21);
		
		timerTypePair.add(new LabelValuePair(EEMConstants.TRIG_CODE_OBC1, OBC1Desc));
		timerTypePair.add(new LabelValuePair(EEMConstants.TRIG_CODE_OBC2, OBC2Desc));
		timerTypePair.add(new LabelValuePair(EEMConstants.TRIG_CODE_OBC3, OBC3Desc));
		timerTypePair.add(new LabelValuePair(EEMConstants.TRIG_CODE_LE21, LE21Desc));
		
		return timerTypePair;
	}

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public PageableVO getSearchListPagination(Map<String, String> searchParamMap) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		List<EEMTimersVO> timersSearchVOList = new ArrayList<>();
		PageableVO pageableVO = eeMTimersDAO.getTimersList(searchParamMap, customerId, true);
		List<EEMTimersDO> timersSearchDOList = (List<EEMTimersDO>) pageableVO.getContent();
		CommonUtils.copyList(timersSearchDOList, timersSearchVOList, EEMTimersVO.class);
		pageableVO.setContent(timersSearchVOList);
		return pageableVO;
	}

}
