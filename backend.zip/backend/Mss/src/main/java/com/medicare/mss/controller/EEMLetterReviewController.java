package com.medicare.mss.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.service.EEMLetterReviewService;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.vo.EEMLetterReviewQCMasterVO;
import com.medicare.mss.vo.EEMLetterReviewVO;
import com.medicare.mss.vo.EEMLetterUploadFormVO;
import com.medicare.mss.vo.EmCorrMbrVO;
import com.medicare.mss.vo.EmCorrVarDataVO;
import com.medicare.mss.vo.LetterCacheVO;
import com.medicare.mss.vo.PageableVO;

@RestController
@RequestMapping("/letter")
public class EEMLetterReviewController {

	@Autowired
	private EEMLetterReviewService letterReviewService;

	@GetMapping(ReqMappingConstants.LETTER_INITIAL)
	public ResponseEntity<JSONResponse> getMbrInitailData() {

		LetterCacheVO letterCacheVO = letterReviewService.getLetterFormList();
		return sendResponse(letterCacheVO);
	}

	@PostMapping(ReqMappingConstants.LETTER_REVIEW_SEARCH)
	public ResponseEntity<JSONResponse> eemLetterReviewSearchPage(@RequestBody EEMLetterReviewVO letterReviewVO) {

		return sendResponse(letterReviewService.letterReviewSearch(letterReviewVO, false));

	}

	@PostMapping(ReqMappingConstants.LETTER_REVIEW_SEARCH_NEXT)
	public ResponseEntity<JSONResponse> eemLetterReviewSearchPagination(@RequestBody EEMLetterReviewVO letterReviewVO) {
		PageableVO pageableVO = letterReviewService.letterReviewSearchPagination(letterReviewVO, true);
		return sendResponse(pageableVO);
	}

	@PostMapping(ReqMappingConstants.LETTER_REVIEW_VAR_DATA)
	public ResponseEntity<JSONResponse> getLetterVarData(@RequestBody Map<String, String> searchParamMap) {

		List<EmCorrVarDataVO> emCorrVarDataList = letterReviewService.getMbrLetterVarDataList(searchParamMap);
		return sendResponse(emCorrVarDataList);

	}

	@PostMapping(ReqMappingConstants.LETTER_REVIEW_PDF)
	public ResponseEntity<JSONResponse> displayDocumentFromDB(@RequestBody Map<String, String> searchParamMap) {

		byte[] blobByte = letterReviewService.displayDocumentFromDB(searchParamMap);
		return sendResponse(blobByte);

	}

	@PostMapping(ReqMappingConstants.LETTER_CORR_MBR_UPDATE)
	public ResponseEntity<JSONResponse> letterCorrMbrUpdate(@RequestBody EmCorrMbrVO letterNewVO) {

		EmCorrMbrVO mbrLetterVO = letterReviewService.letterCorrMbrUpdate(letterNewVO);
		return sendResponse(mbrLetterVO);

	}

	@PostMapping(ReqMappingConstants.LETTER_REVIEW_UPLOAD)
	public ResponseEntity<JSONResponse> uploadLetterReviewLetters(
			@RequestBody EEMLetterUploadFormVO eemLetterUploadFormVO) {
		String result = letterReviewService.uploadLetterReviewLetters(eemLetterUploadFormVO);
		return sendResponse(result);

	}

	@PostMapping(ReqMappingConstants.LETTER_REVIEW_QCSEARCH_BATCHID)
	public ResponseEntity<JSONResponse> letterReviewQCsearchbatchId(@RequestBody EEMLetterReviewVO letterReviewVO) {
		List<LabelValuePair> letterQCBatchIdList = letterReviewService.letterReviewQCsearchbatchId(letterReviewVO);
		return sendResponse(letterQCBatchIdList);
	}

	@GetMapping(ReqMappingConstants.LETTER_REVIEW_QCSEARCH_DESCRIPTION)
	public ResponseEntity<JSONResponse> letterReviewQCsearchDescription(
			@PathVariable(name = "batchId") String batchId) {
		List<LabelValuePair> letterQCDescriptionList = letterReviewService.letterReviewQCsearchDescription(batchId);
		return sendResponse(letterQCDescriptionList);
	}

	@PostMapping(ReqMappingConstants.LETTER_REVIEW_QC_SEARCH)
	public ResponseEntity<JSONResponse> letterReviewQCSearch(
			@RequestBody EEMLetterReviewQCMasterVO letterReviewQCSearchVO) {

		return sendResponse(letterReviewService.letterReviewQCSearchPage(letterReviewQCSearchVO));

	}

	private ResponseEntity<JSONResponse> sendResponse(Object object) {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;
		jsonResponse.setData(object);
		if (null == object) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
			jsonResponse.setMessage(EEMConstants.BLANK);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}
}
