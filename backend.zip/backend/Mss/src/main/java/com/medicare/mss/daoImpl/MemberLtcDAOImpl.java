package com.medicare.mss.daoImpl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.MemberLtcDAO;
import com.medicare.mss.domainobject.EEMMbrLtcInfoDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EEMMbrLtcInfoVO;
import com.medicare.mss.vo.EMDatedSegmentVO;

@Repository
public class MemberLtcDAOImpl implements MemberLtcDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<EEMMbrLtcInfoDO> getMbrLtcInfos(String customerId, String memberId, String showAll) {

		String sqlOverride = " AND LTC.OVERRIDE_IND = 'N'";
		if (EEMConstants.VALUE_YES.equals(showAll))
			sqlOverride = EEMConstants.BLANK;

		String query = CommonUtils.buildQuery("SELECT DISTINCT LTC.CUSTOMER_ID, LTC.MEMBER_ID,",
				"LTC.LTC_ID, LTC.EFF_START_DATE,",
				"LTC.CREATE_TIME, LTC.EFF_END_DATE, LTC.OVERRIDE_IND, LTC.LENGTH_OF_STAY,",
				"LTC.ASSESSMENT_DATE, LTC.PPS_INDICATOR, LTC.CREATE_USERID, LTC.LAST_UPDT_TIME, LTC.LAST_UPDT_USERID,",
				"FAC.LTC_FAC_NAME, FAC.LTC_FAC_ADDRESS, FAC.LTC_FAC_CITY, FAC.LTC_FAC_STATE, FAC.LTC_FAC_ZIPCODE",
				"FROM EM_MBR_LTC LTC JOIN EM_LTC_FACILITY FAC  ON FAC.CUSTOMER_ID = LTC.CUSTOMER_ID",
				"AND FAC.LTC_FAC_ID = LTC.LTC_ID",
				"AND LTC.EFF_START_DATE BETWEEN FAC.EFFECTIVE_DATE AND FAC.EFF_END_DATE",
				"WHERE LTC.CUSTOMER_ID = ? AND LTC.MEMBER_ID = ?", sqlOverride,
				"ORDER BY EFF_START_DATE DESC, EFF_END_DATE DESC, LTC.LAST_UPDT_TIME DESC");

		try {
			return jdbcTemplate.query(query, new DomainPropertyRowMapper<EEMMbrLtcInfoDO>(EEMMbrLtcInfoDO.class), customerId, memberId);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public int setOverride(EMDatedSegmentVO emDatedSegmentVO, String userId) {

		EEMMbrLtcInfoVO eemMbrLtcInfoVO = (EEMMbrLtcInfoVO) emDatedSegmentVO;
		try {
			String query = CommonUtils.buildQuery("UPDATE EM_MBR_LTC",
					"SET OVERRIDE_IND = 'Y', LAST_UPDT_TIME = CURRENT_TIMESTAMP, LAST_UPDT_USERID = ?",
					"WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? AND LTC_ID = ?",
					"AND EFF_START_DATE = ? AND CREATE_TIME = ? AND OVERRIDE_IND = 'N' AND LAST_UPDT_TIME = ?");

			Object[] parms = new Object[] { userId, eemMbrLtcInfoVO.getCustomerId(), eemMbrLtcInfoVO.getMemberId(),
					eemMbrLtcInfoVO.getLtcId(), eemMbrLtcInfoVO.getEffStartDate(), eemMbrLtcInfoVO.getCreateTime(),
					eemMbrLtcInfoVO.getLastUpdtTime() };

			return jdbcTemplate.update(query, parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}
	}

	@Override
	public int insertMbr(EMDatedSegmentVO emDatedSegmentVO) {
		String ppsInd = "0";
		EEMMbrLtcInfoVO eemMbrLtcInfoVO = (EEMMbrLtcInfoVO) emDatedSegmentVO;
		if (StringUtils.isNotBlank(eemMbrLtcInfoVO.getPpsInd())
				&& StringUtils.equalsIgnoreCase(eemMbrLtcInfoVO.getPpsInd(), EEMConstants.VALUE_YES)) {
			ppsInd = "1";
		}
		String query = CommonUtils.buildQuery("INSERT INTO EM_MBR_LTC(",
				"CUSTOMER_ID, MEMBER_ID, LTC_ID, EFF_START_DATE, CREATE_TIME,",
				"EFF_END_DATE, OVERRIDE_IND, LENGTH_OF_STAY, ASSESSMENT_DATE,PPS_INDICATOR,",
				"CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID)", " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)");

		try {
			return jdbcTemplate.update(query, eemMbrLtcInfoVO.getCustomerId(), eemMbrLtcInfoVO.getMemberId(),
					eemMbrLtcInfoVO.getLtcId(), eemMbrLtcInfoVO.getEffStartDate(), eemMbrLtcInfoVO.getCreateTime(),
					eemMbrLtcInfoVO.getEffEndDate(), eemMbrLtcInfoVO.getOverrideInd(),
					eemMbrLtcInfoVO.getLengthOfStay(), eemMbrLtcInfoVO.getAssessmentDate(), ppsInd,
					eemMbrLtcInfoVO.getCreateUserId(), eemMbrLtcInfoVO.getLastUpdtTime(),
					eemMbrLtcInfoVO.getLastUpdtUserId());
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_INSERT);
		}
	}

	@Override
	public List<EEMMbrLtcInfoDO> getLTCFacility(String customerId, String ltcId, String effStartDate)
			{
		String query = CommonUtils.buildQuery("SELECT LTC_FAC_NAME, LTC_FAC_ADDRESS, ",
				"LTC_FAC_CITY, LTC_FAC_STATE, LTC_FAC_ZIPCODE", "FROM EM_LTC_FACILITY",
				"WHERE CUSTOMER_ID = ? AND LTC_FAC_ID = ?", "AND ? BETWEEN EFFECTIVE_DATE AND EFF_END_DATE",
				"ORDER BY EFFECTIVE_DATE DESC", "FETCH FIRST 1 ROWS ONLY");
		try {
			return jdbcTemplate.query(query, new DomainPropertyRowMapper<EEMMbrLtcInfoDO>(EEMMbrLtcInfoDO.class), customerId, ltcId,
					effStartDate);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}

	}

	@Override
	public boolean checkLTCDates(EEMMbrLtcInfoDO eemMbrLtcInfoDO) {
		String query = CommonUtils.buildQuery("SELECT LTC_FAC_NAME FROM EM_LTC_FACILITY ", "WHERE LTC_FAC_ID = ?",
				"AND CUSTOMER_ID = ? AND ? BETWEEN EFFECTIVE_DATE AND EFF_END_DATE ",
				"ORDER BY EFFECTIVE_DATE DESC FETCH FIRST ROW ONLY");
		List<String> ltcFacNames;
		ltcFacNames = jdbcTemplate.query(query, (rs, rowNum) -> rs.getString("LTC_FAC_NAME"),
				StringUtil.nonNullTrim(eemMbrLtcInfoDO.getLtcId()),
				StringUtil.nonNullTrim(eemMbrLtcInfoDO.getCustomerId()), DateFormatter
						.reFormat(eemMbrLtcInfoDO.getEffStartDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
		try {
			return !CollectionUtils.isEmpty(ltcFacNames);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

}
