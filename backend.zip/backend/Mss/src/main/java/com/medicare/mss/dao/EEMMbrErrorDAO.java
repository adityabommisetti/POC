/**
 * 
 */
package com.medicare.mss.dao;

import java.util.List;

import com.medicare.mss.domainobject.EEMFieldErrorDO;
import com.medicare.mss.domainobject.EmMbrErrorDO;

/**
 * @author DU20098149
 *
 */
public interface EEMMbrErrorDAO {

	List<EEMFieldErrorDO> getFormFieldErrors(String sFormName, String customerId);

	int updateErrorDetails(EmMbrErrorDO objError, String requestScrn);

	int insertErrorDetails(EmMbrErrorDO objError, String applDate);

	List<EmMbrErrorDO> getMbrErrors(String customerId, String memberId);

}
