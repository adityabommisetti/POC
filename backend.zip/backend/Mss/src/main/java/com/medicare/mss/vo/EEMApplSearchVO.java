package com.medicare.mss.vo;

import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
public class EEMApplSearchVO {
	

    private int  applId;
    private String birthDt;
    private String customerId;
    private String enrollProdName;
    private String fullName;
    private String medicareId;
    
	public String getBirthDtFrmt() {
		return DateFormatter.reFormat(birthDt, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}


}
