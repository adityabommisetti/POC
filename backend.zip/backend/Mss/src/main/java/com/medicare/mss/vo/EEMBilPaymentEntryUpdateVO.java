package com.medicare.mss.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EEMBilPaymentEntryUpdateVO {
	private EEMBilPaymentEntryVO billPaymentsHeader;
	private EEMBilPaymentEntryDtlsVO bilPaymentEntryDtlsVO;
}
