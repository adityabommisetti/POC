
package com.medicare.mss.caching;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.domainobject.BillingBankDetailsDO;
import com.medicare.mss.domainobject.EEMBillFuncDO;
import com.medicare.mss.domainobject.EEMBillingFunctionCodeDO;
import com.medicare.mss.domainobject.EEMLtcFacilityDO;
import com.medicare.mss.domainobject.EEMMbrLtcInfoDO;
import com.medicare.mss.domainobject.NamedItem;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.vo.CPMDateVO;
import com.medicare.mss.vo.EEMMbrLtcSearchVO;
import com.medicare.mss.vo.EEMProfileVO;

@Component
public class EEMCodeCache {

	@Autowired
	private EEMPersistence eemPer;

	private List<LabelValuePair> lstDsVV;

	public String getStateAbbr(String stateCd) {
		return getDesc(stateCd, eemPer.getLstStates());
	}

	public String getDesc(String code, List<LabelValuePair> lst) {
		LabelValuePair np = null;
		Iterator<LabelValuePair> it = lst.iterator();
		while (it.hasNext()) {
			np = it.next();
			if (np.getValue().equals(code))
				return np.getLabel();
		}
		return null;
	}

	public String getStateCd(String stateAbbr) {
		return getCode(stateAbbr, eemPer.getLstStates());
	}

	public String getAddrTypeDesc(String addressType) {

		return getDesc(addressType, eemPer.getLstAddrTypes());
	}

	public String getCountyNameByCd(String stateCd, String countyCd) {

		String key = stateCd + countyCd;
		return eemPer.getMapStateCounty().get(key);
	}

	public Map<String, EEMProfileVO> populateEEMProfileCache() {

		return eemPer.populateEEMProfileCache();
	}

	public Map<String, List<String>> populateGroupServices() {

		return eemPer.populateGroupServices();
	}

	public String getCode(String value, List<LabelValuePair> lst) {

		LabelValuePair np = null;
		Iterator<LabelValuePair> it = lst.iterator();
		while (it.hasNext()) {
			np = it.next();
			if (np.getLabel().equals(value))
				return np.getValue();
		}
		return null;
	}

	public String getCountyCode(String value, List<LabelValuePair> lst) {

		LabelValuePair np = null;
		Iterator<LabelValuePair> it = lst.iterator();
		while (it.hasNext()) {
			np = it.next();
			if (np.getValue().equals(value))
				return np.getLabel();
		}
		return null;
	}

	public String getShortGenderNumDesc(String code) {
		if (code != null) {
			if (code.equals("1"))
				return "M";
			if (code.equals("2"))
				return "F";
		}
		return "";
	}

	public List<LabelValuePair> getEnrollSrceListForPlan(String plan) {
		List<LabelValuePair> pairs = new ArrayList<>();
		List<NamedItem> lstSrce = eemPer.getLstEnrollSrcPlan();
		NamedItem ni;
		Iterator<NamedItem> it = lstSrce.iterator();
		while (it.hasNext()) {
			ni = it.next();
			if (ni.getName().equals(plan))
				pairs = ni.getItem();
		}
		return pairs;
	}

	public List<LabelValuePair> getLstApplCategory(String customerId) {
		List<LabelValuePair> list = eemPer.getLstApplCategory().get(customerId);
		if (list == null || list.isEmpty())
			return eemPer.getLstApplCategory().get("9999999");
		else {
			list.addAll(eemPer.getLstApplCategory().get("9999999"));
		}
		return list;
	}

	public List<LabelValuePair> getRejectReasonList(String customerId) {
		return eemPer.getLstRejectReason().get(customerId);

	}

	public List<LabelValuePair> getPreSetNotesList(String customerId) {

		List<LabelValuePair> list = eemPer.getPreSetNotes().get(customerId);
		return nullToEmpty(list);
	}

	private List<LabelValuePair> nullToEmpty(List<LabelValuePair> list) {
		if (null == list) {
			list = new ArrayList<>();
		}
		return list;
	}

	public List<LabelValuePair> getLstOevCallStatus(String customerId) {
		return nullToEmpty(eemPer.getOevCallStatus().get(customerId));
	}

	public List<LabelValuePair> getLstOevCallSubsetReason(String customerId) {

		return nullToEmpty(eemPer.getOevCallSubsetReason().get(customerId));

	}

	public List<LabelValuePair> getLstApplDenialReasons(String customerId) {
		return nullToEmpty(eemPer.getLstApplDenialReasons().get(customerId));
	}

	public List<LabelValuePair> getLstCobTypes() {

		return eemPer.getLstCobTypes();
	}

	public List<NamedItem> getLstOhiInd() {

		return eemPer.getLstOhiInd();
	}

	public String getListValueLabel(String code, List<LabelValuePair> lst) {
		LabelValuePair lbi = null;
		Iterator<LabelValuePair> it = lst.iterator();
		while (it.hasNext()) {
			lbi = it.next();
			if (lbi.getValue().equals(code))
				return lbi.getLabel();
		}
		return null;
	}

	public List<LabelValuePair> getLstErrorCodes() {
		return eemPer.getLstErrorCodes();
	}

	public List<LabelValuePair> getArrYesNo() {

		return eemPer.getArrYesNo();
	}

	public List<LabelValuePair> getLstAccountType() {
		return eemPer.getLstAccountType();
	}

	public List<LabelValuePair> getLstCancellationReasons(String customerId) {

		return nullToEmpty(eemPer.getLstCancellationReasons().get(customerId));
	}

	public String getDsDesc(String dsCd) {
		List<LabelValuePair> lstDsCodes = eemPer.getDsDesc();
		return getListBoxValueDesc(dsCd, lstDsCodes);
	}

	public String getListBoxValueDesc(String code, List<LabelValuePair> lst) {
		String valueDesc = null;
		LabelValuePair item = null;
		Iterator<LabelValuePair> it = lst.iterator();
		while (it.hasNext()) {
			item = it.next();
			if (item.getValue().equals(code)) {
				valueDesc = item.getValue();
				break;
			}
		}
		return valueDesc;
	}

	public List<LabelValuePair> getLstDsVV() {
		if (CollectionUtils.isEmpty(lstDsVV)) {
			lstDsVV = eemPer.getLstDsVV();
		}
		return lstDsVV;
	}

	public String getErrorMsg(String errCd) {
		return getDesc(errCd, eemPer.getLstErrorCodes());
	}

	public String getEnrollSrcePlan(String enrollSrceCd) {

		List<NamedItem> lstSrce = eemPer.getLstEnrollSrcPlan();
		NamedItem ni;
		Iterator<NamedItem> it = lstSrce.iterator();
		while (it.hasNext()) {
			ni = it.next();
			List<LabelValuePair> lstItem = ni.getItem();
			for (int i = 0; i < lstItem.size(); i++) {
				LabelValuePair item = lstItem.get(i);
				if (item.getValue().equals(enrollSrceCd))
					return ni.getName();
			}
		}
		return null;
	}

	public String getRelatedListValue(String key, String code, List<NamedItem> lst) {
		NamedItem ni = null;
		LabelValuePair li = null;
		List<LabelValuePair> lstTemp = null;
		for (int i = 0; i < lst.size(); i++) {
			ni = lst.get(i);
			if (ni.getName().equals(key)) {
				lstTemp = ni.getItem();
				for (int j = 0; j < lstTemp.size(); j++) {
					li = lstTemp.get(j);
					if (li.getValue().equals(code))
						return li.getLabel();
				}
			}
		}
		return null;
	}

	public String getOoaSourceDesc(String ooaSource, String customerId) {

		List<LabelValuePair> ooaSourceList = eemPer.getLstOoaSource().get(customerId);
		return getLableValuePairValueDesc(ooaSource, ooaSourceList);
	}

	public String getOoaReasonDesc(String ooaReason, String customerId) {
		List<LabelValuePair> ooaReasonList = eemPer.getLstOoaReason().get(customerId);
		return getLableValuePairValueDesc(ooaReason, ooaReasonList);
	}

	public String getDeReasonDesc(String deReason, String customerId) {
		List<LabelValuePair> ooaDeReasonList = eemPer.getLstOoaDeReason().get(customerId);
		return getLableValuePairValueDesc(deReason, ooaDeReasonList);
	}

	public String getLableValuePairValueDesc(String code, List<LabelValuePair> lst) {
		LabelValuePair lbi = null;
		Iterator<LabelValuePair> it = lst.iterator();
		while (it.hasNext()) {
			lbi = it.next();
			if (lbi.getValue().equals(code))
				return lbi.getLabel() + "-" + lbi.getValue();
		}
		return null;
	}

	public String getBillPayMethodDesc(String code) {
		List<LabelValuePair> labelValuePaired = eemPer.getLstBillPayMethod();
		return getDescfromLabelValuePaired(code, labelValuePaired);
	}

	public String getAccountTypeDesc(String code) {
		List<LabelValuePair> labelValuePaired = eemPer.getLstAccountType();
		return getDescfromLabelValuePaired(code, labelValuePaired);
	}

	public String getBillFrequencyDesc(String code) {
		List<LabelValuePair> labelValuePaired = eemPer.getLstBillFrequency();
		return getDescfromLabelValuePaired(code, labelValuePaired);
	}

	public String getDescfromLabelValuePaired(String code, List<LabelValuePair> labelValuePaired) {
		LabelValuePair lbi = null;
		Iterator<LabelValuePair> it = labelValuePaired.iterator();
		while (it.hasNext()) {
			lbi = it.next();
			if (lbi.getValue().equals(code)) {
				String[] str = lbi.getLabel().split("-");
				return str[1];
			}
		}
		return null;
	}

	public List<LabelValuePair> getLstTriggerCodes(String type) {

		return eemPer.getLstTriggerCodes(type);
	}

	public List<LabelValuePair> getArrSourceTypes() {

		return eemPer.getArrSourceTypes();
	}

	public List<LabelValuePair> getLstTriggerType() {

		return eemPer.getLstTriggerType();
	}

	public List<LabelValuePair> getLstTriggerStatus() {

		return eemPer.getLstTriggerStatus();
	}

	public List<String> getInvTypeList(String searchInvoiceGroup) {
		try {
			Map<String, List<String>> invGrpTypes = eemPer.getInvGrpTypes();
			return invGrpTypes.get(searchInvoiceGroup);
		} catch (DataAccessException exp) {
			throw new ApplicationException("Error occured while getInvTypeList!");
		}
	}

	public String getCPMDate() {
		List<CPMDateVO> cpmDateVOList = eemPer.getCPMDate();
		List<CPMDateVO> collect = cpmDateVOList.stream().filter(cpmDateVO -> DateMath
				.isBetween(DateUtil.getTodaysDate(), cpmDateVO.getCalStartDate(), cpmDateVO.getCalEndDate()))
				.collect(Collectors.toList());
		if (collect.isEmpty()) {
			throw new ApplicationException("Error occured while getCPMDate!");
		}
		return collect.get(0).getPymtEffMonth();

	}

	public List<LabelValuePair> getLstPaySource() {

		return eemPer.getLstPaySource();
	}

	public List<LabelValuePair> getLstDraftStatus() {

		return eemPer.getLstDraftStatus();
	}

	public String getBankAcctCd(String customerId, String paySourceType) {
		List<BillingBankDetailsDO> bankDtlsList = eemPer.getBankAcctCd(customerId);
		String bankAcntCode = null;
		for (BillingBankDetailsDO bankDetailsDO : bankDtlsList) {
			String payType = bankDetailsDO.getPaySourceType();
			if (StringUtils.isNotBlank(payType) && payType.equals(paySourceType)) {
				bankAcntCode = bankDetailsDO.getBankAcntCd();
				break;
			}

		}
		return bankAcntCode;
	}

	public String getBankAcctCd(String customerId, String paySourceType, String mbrPlanId, String billThruDate) {
		List<BillingBankDetailsDO> bankDtlsList = eemPer.getBankAcctCd(customerId);
		String bankAcntCode = null;
		for (BillingBankDetailsDO bankDetailsDO : bankDtlsList) {
			String payType = bankDetailsDO.getPaySourceType();
			String plnId = bankDetailsDO.getPlanId();

			String startDate = bankDetailsDO.getEffStartDate();
			String endDate = bankDetailsDO.getEffEndDate();

			if (StringUtils.equals(payType, paySourceType) && StringUtils.equals(plnId, mbrPlanId)
					&& DateMath.isBetween(billThruDate, startDate, endDate)) {
				bankAcntCode = bankDetailsDO.getBankAcntCd();
				break;
			}
		}
		return bankAcntCode;
	}

	public Boolean validateGlBankAcctCdForMMO(String customerId, String bankAcntCd, String effDate) {
		Boolean flag = false;

		List<BillingBankDetailsDO> bankDtlsList = eemPer.validateGlBankAcctCdForMMO(customerId);

		for (BillingBankDetailsDO bankDetailsDO : bankDtlsList) {
			String bankAcntCode = bankDetailsDO.getBankAcntCd();
			String startDate = bankDetailsDO.getEffStartDate();
			String endDate = bankDetailsDO.getEffEndDate();
			if (bankAcntCode.equals(bankAcntCd) && DateMath.isBetween(effDate, startDate, endDate)) {
				flag = true;
				break;
			}

		}
		return flag;
	}

	public Boolean validateGlBankAcctCd(String customerId, String bankAcntCd, String effDate) {
		Boolean flag = false;

		List<BillingBankDetailsDO> bankDtlsList = eemPer.validateGlBankAcctCd(customerId);
		for (BillingBankDetailsDO bankDetailsDO : bankDtlsList) {
			String bankAcntCode = bankDetailsDO.getBankAcntCd();
			String startDate = bankDetailsDO.getEffStartDate();
			String endDate = bankDetailsDO.getEffEndDate();
			if (bankAcntCode.equals(bankAcntCd) && DateMath.isBetween(effDate, startDate, endDate)) {
				flag = true;
				break;
			}

		}
		return flag;
	}

	public EEMBillFuncDO getBillFunction(String customerId, String functionCd) {
		List<EEMBillFuncDO> billFuncList = eemPer.getBillFuncList(customerId);
		for (EEMBillFuncDO billFunCdDO : billFuncList) {
			if (StringUtils.equals(billFunCdDO.getFunctionCd(), functionCd)) {
				return billFunCdDO;
			}
		}
		return null;
	}

	public List<EEMBillFuncDO> getBillFuncList(String customerId, String usrSystemInd, String detBankCd) {
		List<String> bankAcctCds = new ArrayList<>();
		List<EEMBillFuncDO> billFuncDOList = new ArrayList<>();
		List<EEMBillFuncDO> filteredList = new ArrayList<>();
		List<EEMBillFuncDO> billFuncListFromCache = eemPer.getBillFuncList(customerId);

		for (EEMBillFuncDO billFunCdDO : billFuncListFromCache) {
			if (StringUtils.equals(billFunCdDO.getActiveInd(), EEMConstants.VALUE_YES)
					&& StringUtils.equals(billFunCdDO.getUserSystemInd(), usrSystemInd)) {
				filteredList.add(billFunCdDO);
			}
		}

		List<String> glTranCds = filteredList.stream().map(EEMBillFuncDO::getGlTranCd).distinct()
				.collect(Collectors.toList());

		List<BillingBankDetailsDO> billingBankDetailsList = eemPer.validateGlBankAcctCd(customerId);

		List<String> tempBankAcctCds = new ArrayList<>();
		for (BillingBankDetailsDO bankDetail : billingBankDetailsList) {
			if (CollectionUtils.contains(glTranCds.iterator(), bankDetail.getGlTranCd())
					&& !tempBankAcctCds.contains(bankDetail.getBankAcntCd())) {
				tempBankAcctCds.add(bankDetail.getBankAcntCd());
			}
		}
		
		bankAcctCds.add("NA");
		if(tempBankAcctCds.contains(detBankCd)) {
			bankAcctCds.add(detBankCd);
		}
		
		for (EEMBillFuncDO billFunCdDO : filteredList) {
			if (CollectionUtils.contains(bankAcctCds.iterator(), billFunCdDO.getBankAcctCd())) {
				billFuncDOList.add(billFunCdDO);
			}
		}

		return billFuncDOList;
	}

	public boolean validateGlBankAcctCdForPlanId(String customerId, String bankAcctCd, String billThruDate,
			String planId) {
		Boolean flag = false;

		List<BillingBankDetailsDO> bankDtlsList = eemPer.validateGlBankAcctCd(customerId);
		for (BillingBankDetailsDO bankDetailsDO : bankDtlsList) {
			String startDate = bankDetailsDO.getEffStartDate();
			String endDate = bankDetailsDO.getEffEndDate();

			if (StringUtils.equals(bankDetailsDO.getBankAcntCd(), bankAcctCd)
					&& DateMath.isBetween(billThruDate, startDate, endDate)
					&& StringUtils.equals(bankDetailsDO.getPlanId(), planId)) {
				flag = true;
				break;
			}

		}
		return flag;
	}

	public EEMBillingFunctionCodeDO getFunctionCode(String customerId, String functionCd) {
		List<EEMBillingFunctionCodeDO> functionCodeList = eemPer.getFunctionCode(customerId);

		for (EEMBillingFunctionCodeDO funcCodeDO : functionCodeList) {
			if (StringUtils.equals(funcCodeDO.getFunctionCd(), functionCd)) {
				return funcCodeDO;
			}
		}
		return null;
	}

	public List<EEMMbrLtcInfoDO> mbrLtcSearch(EEMMbrLtcSearchVO mbrLtcSearchVO) {
		List<EEMMbrLtcInfoDO> mbrLtcSearchList = eemPer.mbrLtcSearch(mbrLtcSearchVO.getCustomerId());
		List<EEMMbrLtcInfoDO> resultList = new ArrayList<>();
		
		for (EEMMbrLtcInfoDO ltcInfo : mbrLtcSearchList) {
			
			String effDate = mbrLtcSearchVO.getEffDate();
			String ltcFacId = mbrLtcSearchVO.getLtcFacId();
			String ltcFacName = mbrLtcSearchVO.getFacilityName();

			if (DateMath.isBetween(effDate, ltcInfo.getEffStartDate(), ltcInfo.getEffEndDate())) {
				
				if (StringUtils.isNotBlank(ltcFacId) && StringUtils.isNotBlank(ltcFacName)) {
					matchLtcFacIdNameAndAdd(resultList, ltcInfo, ltcFacId, ltcFacName);
				} else if (StringUtils.isNotBlank(ltcFacId) && StringUtils.isBlank(ltcFacName)) {
					matchLtcFacIdAndAdd(resultList, ltcInfo, ltcFacId);
				} else if (StringUtils.isBlank(ltcFacId) && StringUtils.isNotBlank(ltcFacName)) {
					matchLtcFacNameAndAdd(resultList, ltcInfo, ltcFacName);
				} else {
					resultList.add(ltcInfo);
				}
			}
		}
		return resultList;
	}

	private void matchLtcFacNameAndAdd(List<EEMMbrLtcInfoDO> resultList, EEMMbrLtcInfoDO ltcInfo, String ltcFacName) {
		if (isLtcFacNameMatched(ltcInfo, ltcFacName)) {
			resultList.add(ltcInfo);
		}
	}

	private void matchLtcFacIdAndAdd(List<EEMMbrLtcInfoDO> resultList, EEMMbrLtcInfoDO ltcInfo, String ltcFacId) {
		if (isLtcFacIdMatched(ltcInfo, ltcFacId)) {
			resultList.add(ltcInfo);
		}
	}

	private void matchLtcFacIdNameAndAdd(List<EEMMbrLtcInfoDO> resultList, EEMMbrLtcInfoDO ltcInfo, String ltcFacId,
			String ltcFacName) {
		if (isLtcFacIdMatched(ltcInfo, ltcFacId) && isLtcFacNameMatched(ltcInfo, ltcFacName)) {
			resultList.add(ltcInfo);
		}
	}
	
	private boolean isLtcFacIdMatched(EEMMbrLtcInfoDO ltcInfo, String ltcFacId) {
		return StringUtils.equals(ltcFacId, ltcInfo.getLtcId());
	}
	
	private boolean isLtcFacNameMatched(EEMMbrLtcInfoDO ltcInfo, String ltcFacName) {
		return ltcInfo.getFacilityName().matches(
				CommonUtils.appendStrings("(.*)", ltcFacName, "(.*)"));
	}
	
	public List<LabelValuePair> getInstLookUp(String customerId, String reqDtCov) {

		List<EEMLtcFacilityDO> lstOtherCov = eemPer.getLtcDetails(customerId);

		List<LabelValuePair> lst = new ArrayList<>();

		for (EEMLtcFacilityDO eemLtcFacilityDO : lstOtherCov) {
			String effStartDate = eemLtcFacilityDO.getEffStartDate();
			String effEndDate = eemLtcFacilityDO.getEffEndDate();
			if (DateMath.isBetween(reqDtCov, effStartDate, effEndDate)) {
				String facId = eemLtcFacilityDO.getNameInstitute();
				String facName = eemLtcFacilityDO.getNameInstituteDes();
				lst.add(new LabelValuePair(facId, facName));
			}
		}
		return lst;
	}

}
