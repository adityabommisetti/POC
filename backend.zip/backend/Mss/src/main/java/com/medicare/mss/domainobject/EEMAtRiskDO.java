package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMAtRiskDO {

	@ColumnMapper(columnName = "CASE_ID", propertyName = "caseId")
	private String caseId;
	
	@ColumnMapper(columnName = "QUEUE_CD", propertyName = "queueCd")
	private String queueCd;
	
	@ColumnMapper(columnName = "DAYS_REMAINING", propertyName = "daysRemaining")
	private Integer daysRemaining;
	
	@ColumnMapper(columnName = "CASE_DUE_DATE", propertyName = "caseDueDate")
	private String caseDueDate;
	
	@ColumnMapper(columnName = "CASE_DESC", propertyName = "caseDesc")
	private String caseDesc;
	
	@ColumnMapper(columnName = "MEMBER_NAME", propertyName = "memberName")
	private String memberName;
	
	@ColumnMapper(columnName = "MEDICARE_ID", propertyName = "medicareId")
	private String medicareId;
	
	@ColumnMapper(columnName = "USER_NAME", propertyName = "userName")
	private String userName;
	
	@ColumnMapper(columnName = "QUEUE_NAME", propertyName = "queueName")
	private String queueName;
	
	@ColumnMapper(columnName = "SUPERVISOR_NAME", propertyName = "supervisorName")
	private String supervisorName;
	
	@ColumnMapper(columnName = "QUEUE_PRTY", propertyName = "queuePrty")
	private String queuePrty;
	
	@ColumnMapper(columnName = "COUNT", propertyName = "count")
	private Integer count;
}
