package com.medicare.mss.domainobject;

import lombok.Data;

@Data
public class EEMApplPlanDO {
	 
	private String  applId;
	private String  currGrpId;
	private String  currPaymentAmt;
	private String  currPbpId;
	private String  currPbpSegmentId;
	private String  currPlanId;
	private String  currProductId;
	private String  currPlanDesignation;
	private String  customerId;
	private String  effEndDate;
	private String  elcDerivedInd;
	private String  electionType;
	private String  enrollPymtAmt;
	private String  enrollPbp;
	private String  enrollSegment;
	private String  enrollPlan;
    private String  enrollProduct;
	private String  sepReason;
	private String  enrollGroupName;
	private String  enrollGrpId;
	private String  enrollProdName;
	private String  lastUpdtTime;
    private String  reqDtCov;
    private String  sepElectionDt;
	
	
}

