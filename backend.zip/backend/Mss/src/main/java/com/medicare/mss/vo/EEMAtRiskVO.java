package com.medicare.mss.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EEMAtRiskVO implements Serializable {

	private static final long serialVersionUID = 8893218826577617635L;

	private String customerId;
	private String caseId;
	private String queueCd;
	private Integer daysRemaining;
	private String caseDueDate;
	private String caseDesc;
	private String memberName;
	private String medicareId;
	private String userName;
	private String queueName;
	private String supervisorName;
	private String queuePrty;
	private Integer count;
	private String queuePrtyFrmt;

	public String getCaseDueDateFrmt() {
		return DateFormatter.reFormat(caseDueDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

}
