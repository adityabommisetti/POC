package com.medicare.mss.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMMbrAsesDAO;
import com.medicare.mss.dao.EEMMbrDAO;
import com.medicare.mss.domainobject.EEMMbrAsesDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.EEMContext;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.vo.EEMMbrAsesVO;
import com.medicare.mss.vo.EMDatedSegmentVO;

@Service
@Transactional
public class EEMMbrAsesService extends EEMMbrBaseService {

	@Autowired
	private EEMMbrAsesDAO mbrAsesDao;

	@Autowired
	private EEMMbrDAO mbrDao;

	@SuppressWarnings("unchecked")
	public List<EEMMbrAsesVO> getListFromContext(String memberId, String showAll) {
		EEMContext context = sessionHelper.getEEMContext();
		List<EEMMbrAsesVO> mbrAsesVOList = context.getMbrMasterVO().getMbrAsesList();

		if (StringUtils.equals(EEMConstants.VALUE_YES, showAll)) {
			List<EEMMbrAsesVO> allInfos = getAsesLst(memberId, showAll);
			mbrAsesVOList = (List<EEMMbrAsesVO>) getActiveDatedList(allInfos);
			setToContext(mbrAsesVOList);
			return allInfos;
		} else {
			if (Objects.isNull(mbrAsesVOList)) {
				mbrAsesVOList = getAsesLst(memberId, showAll);
				setToContext(mbrAsesVOList);
			} else {
				mbrAsesVOList = (List<EEMMbrAsesVO>) getActiveDatedList(mbrAsesVOList);
				setToContext(mbrAsesVOList);
			}
			return mbrAsesVOList;
		}
	}

	public List<EEMMbrAsesVO> getAsesLst(String memberId, String showAll) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		List<EEMMbrAsesDO> mbrAsesDOList = mbrAsesDao.getMbrAses(customerId, memberId, showAll);
		List<EEMMbrAsesVO> mbrAsesVOList = new ArrayList<>();
		CommonUtils.copyList(mbrAsesDOList, mbrAsesVOList, EEMMbrAsesVO.class);
		return mbrAsesVOList;
	}

	public void setToContext(List<EEMMbrAsesVO> mbrAsesVOList) {
		EEMContext context = sessionHelper.getEEMContext();
		context.getMbrMasterVO().setMbrAsesList(mbrAsesVOList);
		sessionHelper.setEEMContext(context);
	}

	@SuppressWarnings("unchecked")
	public List<EEMMbrAsesVO> mbrAsesDelete(EEMMbrAsesVO delVO) {
		String userId = sessionHelper.getUserInfo().getUserId();
		int sqlCnt = 0;
		List<EEMMbrAsesVO> mbrAsesVOList = null;
		EEMMbrAsesDO asesDO = new EEMMbrAsesDO();
		BeanUtils.copyProperties(delVO, asesDO);
		sqlCnt = mbrAsesDao.setOverride(asesDO, userId);
		if (sqlCnt == 1) {
			mbrAsesVOList = getAsesLst(delVO.getMemberId(), delVO.getShowAll());
			if (StringUtils.equals(EEMConstants.VALUE_NO, delVO.getShowAll())) {
				setToContext(mbrAsesVOList);
			} else {
				List<EEMMbrAsesVO> mbrAsesActiveVOList = (List<EEMMbrAsesVO>) getActiveDatedList(mbrAsesVOList);
				setToContext(mbrAsesActiveVOList);
			}
		} else {
			throw new ApplicationException("Ases Delete Failed");
		}
		return mbrAsesVOList;
	}

	@SuppressWarnings("unchecked")
	public List<EEMMbrAsesVO> mbrAsesUpdate(EEMMbrAsesVO mbrAsesVO) throws ParseException, CloneNotSupportedException {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();

		List<EEMMbrAsesVO> mbrAsesVOList = this.getListFromContext(mbrAsesVO.getMemberId(), "N");

		List<EEMMbrAsesDO> mbrAsesDOList = new ArrayList<>();
		CommonUtils.copyList(mbrAsesVOList, mbrAsesDOList, EEMMbrAsesDO.class);

		EEMMbrAsesDO newDO = new EEMMbrAsesDO();
		BeanUtils.copyProperties(mbrAsesVO, newDO);

		newDO.setCustomerId(customerId);
		newDO.setOverrideInd("N");

		boolean rslt = this.mbrAsesUpdate(mbrAsesDOList, newDO, userId);

		if (rslt) {
			mbrAsesVOList = getAsesLst(mbrAsesVO.getMemberId(), mbrAsesVO.getShowAll());
			if (StringUtils.equals(EEMConstants.VALUE_NO, mbrAsesVO.getShowAll())) {
				setToContext(mbrAsesVOList);
			} else {
				List<EEMMbrAsesVO> mbrAsesActiveVOList = (List<EEMMbrAsesVO>) getActiveDatedList(mbrAsesVOList);
				setToContext(mbrAsesActiveVOList);
			}
		} else {
			throw new ApplicationException("ASES Update Failed");
		}

		return mbrAsesVOList;

	}

	public boolean mbrAsesUpdate(List<EEMMbrAsesDO> asesLst, EEMMbrAsesDO newDO, String userId)
			throws ParseException, CloneNotSupportedException {
		String ts = DateUtil.getCurrentDatetimeStamp();
		int sqlCnt = 0;
		Map<String, String> type = new HashMap<>();
		String message = checkDates(newDO);
		if (message != null) {
			throw new ApplicationException(message);
		}
		String maxLastUpdate = mbrDao.getMaxLastUpdate(newDO.getCustomerId(), newDO.getMemberId(),
				EEMConstants.EM_MBR_ASES, type);
		if (hasDataChanged(asesLst, maxLastUpdate)) {
			throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
		}
		datesCheck(newDO);
		EEMMbrAsesDO matchDO = null;

		// the update case
		matchDO = (EEMMbrAsesDO) matchDatedSegment(asesLst, newDO);
		if (matchDO != null) {
			sqlCnt = mbrAsesDao.setOverride(matchDO, userId);
			checkUpdateError(sqlCnt, EEMConstants.ERROR_OVERRIDING_SEGMENT);
			sqlCnt = insertMbrAses(newDO, userId, ts);
			checkUpdateError(sqlCnt, EEMConstants.ERROR_ADDING_SEGMENT);
			checkDataChangedByOthers(newDO, type, ts);
			return true;
		}

		// the update end date case - no change in data
		matchDO = (EEMMbrAsesDO) matchDatedSegmentEndDate(asesLst, newDO);
		if (matchDO != null) {
			sqlCnt = mbrAsesDao.setOverride(matchDO, userId);
			checkUpdateError(sqlCnt, EEMConstants.ERROR_OVERRIDING_SEGMENT);
			sqlCnt = insertMbrAses(newDO, userId, ts);
			checkUpdateError(sqlCnt, EEMConstants.ERROR_ADDING_SEGMENT);
			checkDataChangedByOthers(newDO, type, ts);
		}

		if (newDO.getEffEndDate().equals("99999999")) {
			// logicly delete all above
			List<? extends EMDatedSegmentVO> lstSegmentsAbove = getSegmentsAbove(asesLst, newDO.getEffStartDate());
			Iterator<? extends EMDatedSegmentVO> it = lstSegmentsAbove.iterator();
			while (it.hasNext()) {
				EEMMbrAsesDO itemVO = (EEMMbrAsesDO) it.next();
				sqlCnt = mbrAsesDao.setOverride(itemVO, userId);
				checkUpdateError(sqlCnt, "Error Overriding Segment Above");
			}
			EEMMbrAsesDO belowVO = (EEMMbrAsesDO) getFirstOverlapSegmentBelow(asesLst, newDO.getEffStartDate());
			if (belowVO != null) {
				sqlCnt = mbrAsesDao.setOverride(belowVO, userId);
				checkUpdateError(sqlCnt, "Error Overriding Segment Below");
				// do we need to split the segmment below
				if (belowVO.getEffStartDate().compareTo(newDO.getEffStartDate()) < 0) {
					EEMMbrAsesDO tempVO = (EEMMbrAsesDO) belowVO.clone();
					tempVO.setEffEndDate(DateMath.minusOneDay(newDO.getEffStartDate()));
					sqlCnt = insertMbrAses(tempVO, userId, ts);
					checkUpdateError(sqlCnt, "Error Spliting Segment Below");
				}
			}
			// add the new segment
			sqlCnt = insertMbrAses(newDO, userId, ts);
			checkUpdateError(sqlCnt, EEMConstants.ERROR_ADDING_SEGMENT);
			checkDataChangedByOthers(newDO, type, ts);
			return true;
			// end of open ended new segment processing
		}

		// end dated segment
		doDatedSegmentAdjust(asesLst, newDO, ts, userId, mbrAsesDao);

		// add the new segment
		sqlCnt = insertMbrAses(newDO, userId, ts);
		checkUpdateError(sqlCnt, EEMConstants.ERROR_ADDING_SEGMENT);
		checkDataChangedByOthers(newDO, type, ts);
		return true;
	}

	public int insertMbrAses(EEMMbrAsesDO newDO, String userId, String ts) {
		newDO.setCreateTime(ts);
		newDO.setCreateUserId(userId);
		newDO.setLastUpdtTime(ts);
		newDO.setLastUpdtUserId(userId);
		return mbrAsesDao.insertMbr(newDO);
	}

	public void datesCheck(EEMMbrAsesDO newDO) {
		List<EEMMbrAsesDO> mbrAsesDoList = mbrAsesDao.getDatesFromPlanVersionXWalk(newDO);
		EEMMbrAsesDO mbrAsesDO = mbrAsesDoList.get(mbrAsesDoList.size() - 1);
		if (!DateMath.isBetween(newDO.getEffStartDate(), mbrAsesDO.getEffStartDate(), mbrAsesDO.getEffEndDate())) {
			throw new ApplicationException("Plan version not valid for the Effective date");
		}
	}

	public void checkDataChangedByOthers(EEMMbrAsesDO newDO, Map<String, String> type, String ts) {
		String maxLastUpdate = mbrDao.getMaxLastUpdate(newDO.getCustomerId(), newDO.getMemberId(),
				EEMConstants.EM_MBR_ASES, type);
		if (hasDataChanged(ts, maxLastUpdate)) {
			throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
		}
	}

	public void checkUpdateError(int sqlCnt, String message) {
		if (sqlCnt != 1) {
			throw new ApplicationException(message);
		}
	}
}
