package com.medicare.mss.vo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EEMTimersUpdateReqVO {

	private String searchType;
	private String searchId;
	private String status;
	private String timerType;

	private List<EEMTimersVO> emmTimersVOs;

}