package com.medicare.mss.vo;

import java.io.Serializable;
import java.util.List;

import com.medicare.mss.domainobject.LepHistory;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.DateUtil;

import lombok.Data;

@Data
public class EEMLepSummaryVO implements Serializable {

	private static final long serialVersionUID = -934547123096915189L;

	private String partAEntitleSDate;

	private String partAEntitleEDate;
	private String partBEntitleSDate;
	private String partBEntitleEDate;
	private String partDEntitleSDate;
	private String subsidySDate1;
	private String subsidyEDate1;
	private String subsidySDate2;
	private String subsidyEDate2;
	private List<LepHistory> rdsList;

	private List<LepHistory> partDList;
	private List<MBDNunCmoVO> nunCMOList;
	private String customerId;
	private String primaryId;
	private String hicNBRVal;

	private String copayLEVELID1;
	private String prtdPREMSUBSPCT1;
	private String copayLEVELID2;
	private String prtdPREMSUBSPCT2;
	private String mbrBirthDt;
	private String mbr65BirthDt;
	private String eligibilitySrcTable;

	
	public String getMbrBirthDt() {

		return DateFormatter.reFormat(mbrBirthDt, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getPartAEntitleSDate() {

		return DateFormatter.reFormat(partAEntitleSDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setPartAEntitleSDate(String partAEntitleSDate) {
		this.partAEntitleSDate = DateFormatter.reFormat(partAEntitleSDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);

	}

	public String getPartAEntitleEDate() {

		return DateFormatter.reFormat(partAEntitleEDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setPartAEntitleEDate(String partAEntitleEDate) {
		this.partAEntitleEDate = DateFormatter.reFormat(partAEntitleEDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);

	}

	public String getPartBEntitleSDate() {
		return DateFormatter.reFormat(partBEntitleSDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setPartBEntitleSDate(String partBEntitleSDate) {
		this.partBEntitleSDate = DateFormatter.reFormat(partBEntitleSDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);

	}

	public String getPartBEntitleEDate() {
		return DateFormatter.reFormat(partBEntitleEDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setPartBEntitleEDate(String partBEntitleEDate) {
		this.partBEntitleEDate = DateFormatter.reFormat(partBEntitleEDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);

	}

	public String getPartDEntitleSDate() {
		return DateFormatter.reFormat(partDEntitleSDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setPartDEntitleSDate(String partDEntitleSDate) {
		this.partDEntitleSDate = DateFormatter.reFormat(partDEntitleSDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);

	}

	public String getSubsidySDate1() {
		return DateFormatter.reFormat(subsidySDate1, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setSubsidySDate1(String subsidySDate1) {
		this.subsidySDate1 = DateFormatter.reFormat(subsidySDate1, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);

	}

	public String getSubsidyEDate1() {
		return DateFormatter.reFormat(subsidyEDate1, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setSubsidyEDate1(String subsidyEDate1) {
		this.subsidyEDate1 = DateFormatter.reFormat(subsidyEDate1, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);

	}

	public String getSubsidySDate2() {
		return DateFormatter.reFormat(subsidySDate2, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setSubsidySDate2(String subsidySDate2) {
		this.subsidySDate2 = DateFormatter.reFormat(subsidySDate2, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);

	}

	public String getSubsidyEDate2() {
		return DateFormatter.reFormat(subsidyEDate2, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setSubsidyEDate2(String subsidyEDate2) {

		this.subsidyEDate2 = DateFormatter.reFormat(subsidyEDate2, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}
	
	public void setMbrBirthDt(String mbrBirthDt) {
		if (mbrBirthDt != null && !mbrBirthDt.isEmpty()) {
			try {
				this.mbr65BirthDt = DateMath.addYear(DateUtil.changedDateFormatForMonth(mbrBirthDt), 65);
				this.mbr65BirthDt = DateFormatter.reFormat(DateFormatter.dateFilter(this.mbr65BirthDt),
						DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		this.mbrBirthDt = DateFormatter.reFormat(mbrBirthDt, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getMbr65BirthDt() {
		return mbr65BirthDt;
	}

}
