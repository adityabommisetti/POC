package com.medicare.mss.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.service.EEMMbrCobService;
import com.medicare.mss.vo.EEMMbrCobVO;

@RestController
@RequestMapping("/member")
public class EEMMbrCobController {

	@Autowired
	EEMMbrCobService eEMMbrCobService;

	@GetMapping(ReqMappingConstants.GET_MBR_COB)
	public ResponseEntity<JSONResponse> getMbrCobList(@PathVariable("mbrId") String memberId,
			@PathVariable(name = "showAll") String showAll) {

		List<EEMMbrCobVO> emMbrCobVOList = eEMMbrCobService.getMbrCobList(memberId, showAll);

		return sendResponse(emMbrCobVOList);
	}

	@PostMapping(ReqMappingConstants.UPDT_MBR_COB)
	public ResponseEntity<JSONResponse> mbrCobUpdate(@RequestBody EEMMbrCobVO emMbrCobVO) {

		List<EEMMbrCobVO> emMbrCobVOlist = eEMMbrCobService.updateMbrCob(emMbrCobVO);

		return sendResponse(emMbrCobVOlist);
	}

	@PostMapping(path = ReqMappingConstants.DELETE_MBR_COB)
	public ResponseEntity<JSONResponse> mbrCobInfoDelete(@RequestBody EEMMbrCobVO emMbrCobVO) {

		List<EEMMbrCobVO> cobInfoList = eEMMbrCobService.mbrcobDelete(emMbrCobVO);

		return sendResponse(cobInfoList);
	}

	private ResponseEntity<JSONResponse> sendResponse(Object object) {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;
		if (null == object) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			jsonResponse.setData(null);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
			jsonResponse.setMessage(EEMConstants.BLANK);
			jsonResponse.setData(object);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}
}
