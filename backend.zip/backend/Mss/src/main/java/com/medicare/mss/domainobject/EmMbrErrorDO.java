/**
 * 
 */
package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

/**
 * @author Wipro Ltd.
 *
 */
@Data
public class EmMbrErrorDO {

	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;
	
	@ColumnMapper(columnName = "ERROR_CD", propertyName = "errorCd")
	private String errorCd;

	@ColumnMapper(columnName = "ERROR_DATA", propertyName = "errorData")
	private String errorData;
	
	@ColumnMapper(columnName = "ERROR_MESSAGE", propertyName = "errorMsg")
	private String errorMsg;
	
	@ColumnMapper(columnName = "ERROR_SEQ_NBR", propertyName = "errorSeqNbr")
	private int errorSeqNbr;
	
	@ColumnMapper(columnName = "ERROR_STATUS", propertyName = "errorStatus")
	private String errorStatus;
	
	private String fieldDispName;
	
	@ColumnMapper(columnName = "FIELD_NBR", propertyName = "fieldNbr")
	private String fieldNbr;
	
	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;
	
	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserId")
	private String lastUpdtUserId;
	
	@ColumnMapper(columnName = "MEMBER_ID", propertyName = "memberId")
	private String memberId;
	
	@ColumnMapper(columnName = "RFI_IND", propertyName = "rfiInd")
	private String rfiInd;

	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	
}
