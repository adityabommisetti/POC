package com.medicare.mss.constants;

public class ReqMappingConstants {
	public static final String ADD_MBR_COMMENTS = "/addMbrComments";
	public static final String ADD_PRESETNOTES = "/addpresetNotes";
	public static final String APPL_CANCEL = "/applCancel";
	public static final String APPL_INITIAL = "/initial";
	public static final String APPL_LEP = "/lep";
	public static final String APPL_LEP_ADD_CCF = "/add/attest";
	public static final String APPL_LEP_ADD_UNCOV = "/add/uncov";
	public static final String APPL_LEP_COPY_ATTEST = "/copy/attest";
	public static final String APPL_LEP_DELETE_CCF = "/delete/attest";
	public static final String APPL_LEP_DELETE_UNCOV = "/delete/uncov";
	public static final String APPL_LEP_GET_CCF_DETAILS = "/ccfDetails/showAll/{applId}/{overrideInd}";
	public static final String APPL_LEP_GET_PDF = "/get/attest/pdf";
	public static final String APPL_LEP_GET_UNCOV = "/unCovMonths/showAll/{applId}/{overrideInd}";
	public static final String APPL_LEP_UPDATE_ATTEST_CALL = "/update/attest/call";
	public static final String APPL_LEP_UPDATE_CCF = "/update/attest";
	public static final String APPL_MEMBER_CHECK = "/applMemberCheck";
	public static final String APPL_ORIG_SEARCH = "/origApplication";
	public static final String APPL_SEARCH = "/search";
	public static final String APPL_SEARCH_NEXT = "/search/next";
	public static final String APPL_SEARCH_SELECT = "/searchSelect/{applId}";
	public static final String APPL_INST_DTLS = "/getInstDetails";
	public static final String APPL_UPDATE = "/update";
	public static final String APPL_VALIDATE = "/validate";
	public static final String APPL_STATUS_TRACK = "/statusTrack/{applId}";
	public static final String MBR_DELETE_DSINFO = "/dsinfo/delete";
	public static final String MBR_DELETE_LTC = "/ltc/delete";
	public static final String ELIG_SEARCH = "/eligSearch";
	public static final String GET_CITIES = "/getCities";
	public static final String GET_CITY_COUNTY_STATE = "/populateCityCounty";
	public static final String GET_CITY_NAME = "/getCityName/{zip4}/{zip5}";
	public static final String GET_COUNTY = "/getCounty";
	public static final String GET_COUNTY_NAME = "/getCountyName/{zip4}/{zip5}";
	public static final String GET_MBR_COMMENTS = "/comments/get/{mbrId}";
	public static final String MBR_GET_DSINFO = "/dsinfo/get/{mbrId}/{showAll}";
	public static final String MBR_GET_LTC = "/ltc/get/{mbrId}/{showAll}";
	public static final String GET_MBR_TRR = "/trr/get/{mbrId}";
	public static final String GET_MBR_TRR_DATA = "/trrData/get/{mbrId}/{logTime}";
	public static final String GRP_PROD_PLAN_TYPE_GET = "/plantype/get";
	public static final String GRP_PROD_SEARCH_MBR = "/grpProdSearch";
	public static final String PRINT_ID_CARD_MBR_ENROLLMENT = "/printIDCardEnrollment";

	public static final String MAXIMUS_UPDATE = "/lep/maximus/update";
	public static final String MBR_ADDRESS_DELETE = "/address/delete";
	public static final String MBR_ADDRESS_SEARCH = "/address/get/{mbrId}/{showAll}";
	public static final String MBR_ADDRESS_UPDATE = "/address/update";
	public static final String MBR_DEMOGRAPHIC_GET = "/demographic/get";
	public static final String MBR_DEMOGRAPHIC_UPDATE = "/demographic/update";
	public static final String MBR_ENROLL_SEARCH = "/enroll/get/{mbrId}/{showAll}";
	public static final String MBR_ENROLL_UPDATE = "/enroll/update";
	public static final String MBR_INITIAL = "/initial";
	public static final String MBR_LEP = "/mbr/lep";
	public static final String MBR_LETTER_SELECT = "/mbr/get/letters/{mbrId}";
	public static final String MBR_LETTER_VAR_DATA = "/mbr/post/letterVarData";
	public static final String MBR_LETTER_PDF = "/mbr/post/letterpdf";
	public static final String MBR_LIS_DELETE = "/lis/delete";
	public static final String MBR_LIS_SEARCH = "/lis/get/{mbrId}/{showAll}";
	public static final String MBR_LIS_UPDATE = "/lis/update";
	public static final String MBR_LTC_SEARCH = "/ltc/search";
	public static final String MBR_PCP_INFO_DELETE = "/pcp/delete";
	public static final String MBR_PCP_SEARCH = "/pcp/get/{mbrId}/{showAll}";
	public static final String MBR_PCP_UPDATE = "/pcp/update";
	public static final String MBR_PCP_POP_UP = "/pcp/pcpSearch";
	public static final String MBR_POS_INFO_DELETE = "/pos/delete";
	public static final String MBR_POS_INFO_UPDATE = "/pos/update";
	public static final String MBR_POS_SEARCH = "/pos/get/{mbrId}/{showAll}";
	public static final String MBR_SEARCH = "/search";
	public static final String MBR_SEARCH_NEXT = "/search/next";
	public static final String MBR_SEARCH_SELECT = "/searchSelect";
	public static final String MEMBER = "/member";
	public static final String POP_UP_AGENCY = "/agencySearch";
	public static final String POP_UP_CITY_ZIP = "/cityZipSearch";

	public static final String POP_UP_GRP_PROD = "/prodSearch";
	public static final String POP_UP_PCP = "/pcpSearch";
	public static final String REMOVE_CACHE = "/delete";

	public static final String MBR_UPDATE_DSINFO = "/dsinfo/update";
	public static final String MBR_UPDATE_LTC = "/ltc/update";
	public static final String UPDT_APPL_COMMENTS = "/updtApplComments";

	public static final String GET_MBR_COB = "/cob/get/{mbrId}/{showAll}";
	public static final String UPDT_MBR_COB = "/cob/update";
	public static final String DELETE_MBR_COB = "/cob/delete";

	public static final String GET_MBR_BILLING = "/billing/get/{mbrId}/{showAll}";
	public static final String UPDT_MBR_BILLING = "/billing/update";
	public static final String DELETE_MBR_BILLING = "/billing/delete";

	public static final String MBR_AGENT_LIST = "/agent/get/{mbrId}/{showAll}";
	public static final String MBR_AGENT_INFO_DELETE = "/agent/delete";
	public static final String MBR_AGENT_INFO_UPDATE = "/agent/update";

	public static final String UPDATE_MBR_LEP = "/lep/update";
	public static final String DELETE_MBR_LEP = "/lep/delete";
	public static final String GET_MBR_LEP = "/lep/get/{mbrId}/{showAll}";

	public static final String MBR_OOA_SEARCH = "/ooa/get/{mbrId}/{showAll}";
	public static final String MBR_OOA_UPDATE = "/ooa/update";

	public static final String GET_MBR_ACCRETION = "/accretion/get/{mbrId}/{showAll}";

	public static final String MBR_ASES_SEARCH = "/ases/get/{mbrId}/{showAll}";
	public static final String MBR_ASES_DELETE = "/ases/delete";
	public static final String MBR_ASES_UPDATE = "/ases/update";

	public static final String MBR_LEP_GET_SHOWALL = "/lep/get/{mbrId}";
	public static final String MBR_LEP_GET_UNCOV = "/lep/uncov/get/{mbrId}/{showAll}";

	public static final String MBR_LEP_GET_CCF = "/lep/ccf/get/{mbrId}/{showAll}";
	public static final String MBR_LEP_ADD_UNCOV = "/lep/add/uncov";
	public static final String MBR_LEP_DELETE_UNCOV = "/lep/delete/uncov";
	public static final String MBR_LEP_ADD_CCF = "/lep/add/ccf";
	public static final String MBR_LEP_COPY_ATTEST = "/lep/copy/attest";
	public static final String MBR_LEP_ATTEST_LETTER = "/lep/attest/letter";
	public static final String MBR_LEP_DELETE_CCF = "/lep/delete/ccf";
	public static final String MBR_LEP_UPDATE_ATTEST_CALL = "/update/attest/call";
	public static final String MBR_LEP_UPDATE_ATTEST = "/lep/update/attest";

	public static final String LETTER_REQ_SEARCH = "/req/search";
	public static final String LETTER_REQ_SEARCH_NEXT = "/req/search/next";
	public static final String LETTER_REQ_LOOKUP = "/req/lookUp";
	public static final String LETTER_REQ_SELECT = "/req/select";
	public static final String LETTER_REQ_CREATE = "/req/create";
	public static final String LETTER_REQ_CLOSE = "/req/close";

	public static final String WF_SEARCH = "/search";
	public static final String WF_FETCH_USR_QUEUE = "/fetchUsrQueue";
	public static final String WF_FETCH_USR_ACTIVITIES = "/userActivities/get/{queueId}";
	public static final String WF_ASSIGN_WORK = "/assignWork/{fetchSize}";
	public static final String WF_GET_CACHE_DATA = "/wfCacheData/get";
	public static final String WF_CASE_STATE_UPDATE = "/caseState/update";
	public static final String WF_GET_COMMENTS = "/getWFComments";
	public static final String WF_ADD_COMMENTS = "/addWFComments";
	public static final String WF_GET_CASE_QUEUE = "/getWFCaseQueue";
	public static final String WF_UPDATE_CASE_QUEUE = "/updateWFCaseQueue";
	public static final String WF_GET_ATRISK_SUMMARY = "/getWFAtRiskSummary";
	public static final String WF_GET_ATRISK_DETAILS = "/getWFAtRiskDetails";
	public static final String WF_REFRESH_DASHLETS = "/refresh/dashlets/{userId}/{isSupervisorTab}";
	public static final String WF_GET_ACTIVITIES = "userActivities/get/{caseId}";
	public static final String WF_TRANSFER_CASE = "/transferCase";
	public static final String WF_UPDATE_MAX_USER_WORK = "/updateMaxUserWork/{maxUserWork}";
	public static final String WF_GET_MAX_USER_WORK = "/getMaxUserWork";
	public static final String UPDATE_PRIORITY = "/updatePriority";
	public static final String UPDATE_WF_USER_STATUS = "/wfUserStatus/update";
	public static final String WF_FETCH_DASHLETS = "/fetchDashlets/{userId}";
	public static final String WF_SEARCH_NEXT = "/search/next";

	public static final String WF_GET_SUPERVISOR_DETAILS = "/getSupervisorDetails";
	public static final String WF_SUPERVISOR_TAB_DETAILS = "/supervisorTabDetails";
	public static final String WF_ADDSHOW_USER_INITIAL_DATA = "/addOrShowUser/initial";
	public static final String WF_USER_ADD = "/user/add";
	public static final String WF_USER_SEARCH = "/user/search";
	public static final String WF_USER_UPDATE = "/user/update";
	public static final String LETTER_REVIEW_SEARCH = "/review/search";
	public static final String LETTER_REVIEW_SEARCH_NEXT = "/review/search/next";
	public static final String LETTER_REVIEW_VAR_DATA = "/review/letterData";
	public static final String LETTER_REVIEW_PDF = "/review/letterpdf";
	public static final String LETTER_CORR_MBR_UPDATE = "/review/corrmbr/update";
	public static final String LETTER_REVIEW_UPLOAD = "/review/upload";
	public static final String LETTER_REVIEW_QCSEARCH_BATCHID = "/review/qc/search/batchid";
	public static final String LETTER_REVIEW_QCSEARCH_DESCRIPTION = "/review/qc/search/description/{batchId}";
	public static final String LETTER_REVIEW_QC_SEARCH = "/review/qc/search";
	public static final String LETTER_INITIAL = "/initial";

	public static final String SEARCH_TIMERS = "/timers/search";
	public static final String SEARCH_TIMERS_NEXT = "/timers/search/next";
	public static final String GET_TIMERS_TYPE = "/timers/type";
	public static final String UPDATE_TIMERS = "/timers/update";

	public static final String GET_SECURITY_CACHE = "/get/cache";
	public static final String UPDATE_SECURITY_ROLE = "/update/role";
	public static final String GET_SERVICES = "/get/services/{groupId}";
	public static final String GET_ENABLED_SERVICES_LIST = "/getEnabledServicesList";
	public static final String ADD_SERVICE = "/add/services";
	public static final String REMOVE_SERVICE = "/remove/services";

	// Billing payment entry
	public static final String BILL_PAYMENTENTRY_SEARCH = "/billing/paymentEntry/search";
	public static final String BILL_PAYMENTENTRY_SEARCH_NEXT = "/billing/paymentEntry/search/next";
	public static final String BILL_PAYMENTENTRY_DETAILS = "/billing/paymentEntry/details";
	public static final String BILL_PAYMENTENTRY_CACHE_DATA = "/billing/paymentEntry/cacheData";
	public static final String BILL_PAYMENTENTRY_ADD = "/billing/paymentEntry/add";
	public static final String BILL_PAYMENTENTRY_ADD_DETAILS = "/billing/paymentEntry/addDetails";
	public static final String BILL_PAYMENTENTRY_HEADER_UPDATE = "/billing/paymentEntry/headerUpdate";
	public static final String BILL_PAYMENTENTRY_DETAILS_UPDATE = "/billing/paymentEntry/detailsUpdate";
	public static final String EEM_MEMBER_ID_VALIDATE = "/eem/memberIdValidate";

	public static final String BILLING_INVOICE_SEARCH = "/invoiceSearch";
	public static final String BILLING_INVOICE_SEARCH_SELECT = "/invoiceSearchSelect";
	public static final String BILLING_INVOICE_CACHE_DATA = "/getBillingInvoiceCacheData";
	public static final String BILLING_INV_SAVE_COMMENT = "/saveComment";
	public static final String BILLING_INVOICE_TRANSFER = "/invoiceTransfer";
	public static final String BILLING_INV_MBR_GRP_SEARCH = "/billMbrGrpSearch";
	public static final String BILLING_INVOICE_UPDATE = "/billInvDetailsUpdate";
	public static final String BILLING_CACHE_DATA = "/getBillingCacheData";
	public static final String BILLING_GET_TOTAL_INVDTLS_AMT = "/getTotalInvoiceDetailAmt";
	public static final String BILLING_INVOICE_SEARCH_NEXT = "/invoiceSearch/next";

	public static final String GET_BILLING_MEMBER_PAYMENT_SEARCH = "/member/getBillingPaymentSearch";
	public static final String GET_BILLING_MEMBER_PAYMENT_SEARCH_NEXT = "/member/getBillingPaymentSearch/next";
	public static final String GET_BILLING_MEMBER_PAYMENT_DETAIL_INVOICE = "/member/getBillingPaymentDetailInvoice";
	public static final String UPDATE_BILLING_MEMBER_PAYMENT = "/member/updateBillingMbrPayment";

	public static final String GET_BILLING_DRAFT_HEADER_SEARCH = "/getBillingDraftHeaderSearch";
	public static final String GET_BILLING_DRAFT_HEADER_SEARCH_NEXT = "/getBillingDraftHeaderSearch/next";
	public static final String GET_BILLING_DRAFT_DETAIL_SEARCH = "/getBillingDraftDetailSearch";

	public static final String BILL_MBR_PAYMENT_CACHE_DATA = "/mbrPayment/cacheData";
	public static final String BILL_DRAFT_CACHE_DATA = "/draft/cacheData";
	public static final String MEDICARE_NOTIFICATIONS_STREAM = "/stream";

	public static final String DASHBOARD_MBR_SHP_DIS = "/mbrShipDistribution";
	public static final String DASHBOARD_PRE_ENROLL_STATUS = "/preEnrollStatus";
	public static final String DASHBOARD_APPL_AGEING = "/applAgeing";
	public static final String DASHBOARD_RFI_TRACKING = "/rfiTracking";
	public static final String DASHBOARD_CMS_STATUS = "/cmsStatus";
	public static final String DASHBOARD_CMS_TRANSACTION = "/cmsTransaction";
	public static final String DASHBOARD_APP_DIS = "/appDistribution";
	public static final String DASHBOARD_LIS_MBR_DIS = "/lisMbrDistribution";
	public static final String DASHBOARD_LTR_VOL_DIS = "/letVolDistribution";
	public static final String DASHBOARD_SPCL_STATUS_DIS = "/spclStatDistribution";
	public static final String DASHBOARD_FILE_LOAD_ERR_DIS = "/fileLoadErrDistribution";
	public static final String DASHBOARD_DIS_PLAN_IDS = "/customerPlanIds";

	public static final String MBR_SOA_LETTER = "/soa/letter/{primaryId}";

	public static final String WF_GET_ASSGND_NORMAL_USERS = "/fetchAssignedNormalWfUsers/{adminOrSupervisorId}";
	public static final String WF_DELETE_MANUAL_POPUP_QUEUES = "/deleteManualPopupQueues";
}
