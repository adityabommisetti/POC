package com.medicare.mss.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EmCorrMbrVO implements Cloneable, Serializable {

	private static final long serialVersionUID = 2332549591328395795L;
	private String dmsId;
	private String customerId;// custId
	private String pdfArchival;
	private String filebatchid;
	private String recordType;
	private String primaryId;// mbrId
	private String letterName;
	private String description;
	private String requestDate;
	private String origMailDate;
	private String lastMailDate;
	private String deleteInd;
	private String recordStatus;
	private String supplementalId;
	private String createTime;
	private String createUserId;
	private String lastUpdtTime;
	private String lastUpdtUserId;
	private String printDate;
	private String responseDueDate;
	private String reprintDate;
	private String responseDate;
	private String letterUploadedTime;
	private String source;
	private String letterAvailabilityInDB;
	private String deleteAdj;
	private String holdAdj;

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	public String getCreateTimeFrmt() {
		return DateFormatter.reFormat(createTime, DateFormatter.DB2_TIMESTAMP, DateFormatter.MM_DD_YYYY_HH_MM_SS);
	}

	public String getLastUpdtTimeFrmt() {
		return DateFormatter.reFormat(lastUpdtTime, DateFormatter.DB2_TIMESTAMP, DateFormatter.MM_DD_YYYY_HH_MM_SS);
	}

	public String getRequestDateFrmt() {
		return DateFormatter.reFormat(requestDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setRequestDateFrmt(String requestDate) {
		this.requestDate = DateFormatter.reFormat(requestDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getOrigMailDateFrmt() {
		return DateFormatter.reFormat(origMailDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setOrigMailDateFrmt(String origMailDate) {
		this.origMailDate = DateFormatter.reFormat(origMailDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getLastMailDateFrmt() {
		return DateFormatter.reFormat(lastMailDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setLastMailDateFrmt(String lastMailDate) {
		this.lastMailDate = DateFormatter.reFormat(lastMailDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getPrintDateFrmt() {
		return DateFormatter.reFormat(printDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setPrintDateFrmt(String printDate) {
		this.printDate = DateFormatter.reFormat(printDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getResponseDueDateFrmt() {
		return DateFormatter.reFormat(responseDueDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setResponseDueDateFrmt(String responseDueDate) {
		this.responseDueDate = DateFormatter.reFormat(responseDueDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
	}

	public String getReprintDateFrmt() {
		return DateFormatter.reFormat(reprintDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setReprintDateFrmt(String reprintDate) {
		this.reprintDate = DateFormatter.reFormat(reprintDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getResponseDateFrmt() {
		return DateFormatter.reFormat(responseDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setResponseDateFrmt(String responseDate) {
		this.responseDate = DateFormatter.reFormat(responseDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

}
