package com.medicare.mss.vo;

import java.io.Serializable;

import lombok.Data;

@Data
public class EEMLtcFacilityVO implements Serializable{

	private static final long serialVersionUID = -2715758219376322848L;
	
	private String customerId;
	private String nameInstitute;
	private String nameInstituteDes;
	private String effStartDate;
	private String effEndDate;
	private String ltcFacilityPhone;
	private String ltcFacilityAddress;
	private String createTime;
	private String createUserId;
	private String lastUpdtTime;
	private String lastUpdtUserId;
	private String ltcFacilityCity;
	private String ltcFacilityState;
	private String ltcFacilityZipCode;

}
