package com.medicare.mss.domainobject;

import lombok.Data;

@Data
public class EEMApplAgentDO {

	private String agentDt;
	private String agentName;
	//private String agentType;
	private String brokAgentId;
	private String brokAgencyId;
	private String agencyType;
	private String commAgencyId;
	private String lastUpdtTime;
	private String agencyName;
	private String reqDtCov;
	private String customerId;
	
	private String brokerType;
	
}
