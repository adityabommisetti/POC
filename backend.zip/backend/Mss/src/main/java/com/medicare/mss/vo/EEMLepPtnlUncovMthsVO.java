package com.medicare.mss.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode(callSuper = false)
public class EEMLepPtnlUncovMthsVO extends BaseVO {

	private static final long serialVersionUID = -4741959253324357667L;
	private String applStatus;
	private String primaryId;
	private String lepEffDate;
	private String uncovMthStDt;
	private String uncovMthEndDt;
	private Integer plepMonths;
	private String overRideInd;
	private String obc1TimerCheck;

	public String getLepEffDateFrmt() {
		return DateFormatter.reFormat(lepEffDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setLepEffDateFrmt(String lepEffDate) {
		this.lepEffDate = DateFormatter.reFormat(lepEffDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getUncovMthStDtFrmt() {
		return DateFormatter.reFormat(uncovMthStDt, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setUncovMthStDtFrmt(String uncovMthStDt) {
		this.uncovMthStDt = DateFormatter.reFormat(uncovMthStDt, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getUncovMthEndDtFrmt() {
		return DateFormatter.reFormat(uncovMthEndDt, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setUncovMthEndDtFrmt(String uncovMthEndDt) {
		this.uncovMthEndDt = DateFormatter.reFormat(uncovMthEndDt, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

}
