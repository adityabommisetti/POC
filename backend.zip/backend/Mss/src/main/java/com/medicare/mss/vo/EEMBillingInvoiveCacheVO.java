package com.medicare.mss.vo;

import java.util.List;
import java.util.Map;

import com.medicare.mss.util.LabelValuePair;

import lombok.Data;

@Data
public class EEMBillingInvoiveCacheVO {
	
	private List<LabelValuePair> lstInvoiceStatus;
	private List<LabelValuePair> lstInvoiceGroup;
	private List<LabelValuePair> allInvoiceType;
	private List<LabelValuePair> lstInvoiceType;
	private Map<String, List<LabelValuePair>> lstRelatedInvoiceType;
}
