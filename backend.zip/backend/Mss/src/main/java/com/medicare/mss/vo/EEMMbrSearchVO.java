package com.medicare.mss.vo;

import java.io.Serializable;

import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
public class EEMMbrSearchVO implements Serializable {

	private static final long serialVersionUID = -708841638519882196L;
	private String cmsEffMonth;
	private String hicNbr;
	private String mbi;
	private String medicareId;
	private String memberId;
	private String name;
	private String supplementalId;

	public String getCmsEffMonth() {
		return DateFormatter.reFormat(cmsEffMonth, DateFormatter.YYYYMM, DateFormatter.MM_YYYY);
	}
}