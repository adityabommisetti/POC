package com.medicare.mss.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.medicare.mss.domainobject.EEMApplAddressDO;
import com.medicare.mss.domainobject.EEMApplAgentDO;
import com.medicare.mss.domainobject.EEMApplAttestationDO;
import com.medicare.mss.domainobject.EEMApplCommentsDO;
import com.medicare.mss.domainobject.EEMApplEligibilityDO;
import com.medicare.mss.domainobject.EEMApplErrorDO;
import com.medicare.mss.domainobject.EEMApplFieldErrorDO;
import com.medicare.mss.domainobject.EEMApplLisDO;
import com.medicare.mss.domainobject.EEMApplOtherCovDO;
import com.medicare.mss.domainobject.EEMApplOtherPlanDO;
import com.medicare.mss.domainobject.EEMApplPlanDO;
import com.medicare.mss.domainobject.EEMApplProdSearchDO;
import com.medicare.mss.domainobject.EEMApplProductDO;
import com.medicare.mss.domainobject.EEMApplStatusTrackDO;
import com.medicare.mss.domainobject.EEMApplTriggerDO;
import com.medicare.mss.domainobject.EEMApplicationDO;
import com.medicare.mss.domainobject.EEMBeqDO;
import com.medicare.mss.domainobject.EEMOriginalApplDO;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.vo.EEMApplAddressVO;
import com.medicare.mss.vo.EEMApplMasterVO;
import com.medicare.mss.vo.EEMApplOtherPlanVO;
import com.medicare.mss.vo.EmPreSetNoteVO;
import com.medicare.mss.vo.MBD;
import com.medicare.mss.vo.PageableVO;

/**
 * This class abstracts Application Persistence details.
 * 
 * @author Wipro
 *
 */
public interface EEMApplDAO {

	// Begin: Application Validation

	EEMApplTriggerDO getApplTriggerForFunc(int applId, String customerId);

	String getCounty(String zip5, String zip4);

	String[] getCityName(EEMApplAddressVO eemApplAddressVO, EEMApplFieldErrorDO fieldVO);

	boolean checkZip(String zip);

	boolean isDUALSEPElectionTypeLAlreadyUsed(String custID, String memberId, String electionType, String enrollStatus,
			String date1, String date2);

	String getEarliestEnrlStDt(String custID, String memberId);

	boolean isElectionTypeAlreadyUsed(String custID, String memberId, String electionType, String enrollStatus,
			String date1, String date2);

	boolean validateBrkInCov(String custID, String memberId, String date, String reqDtOfCov);

	boolean isMAOEPElectionTypeAlreadyUsed(String custID, String memberId, String date1, String date2);

	boolean getMemberDetails(EEMApplicationDO eemApplicationDO, EEMApplPlanDO eemApplPlanDO,
			EEMApplOtherCovDO eemApplOtherCovDO, String planDesgn);

	boolean isUnlawfullyEligible(String reqCovDt, String hicNbr, String mbi);

	boolean isIncarcerated(String reqCovDt, String hicNbr, String mbi);

	String getEnrollMemberId(String custId, String hicNbr, String mbiNbr);

	String validateEnrolledPcp(String custId, String reqDtCov, String officeCd, String locationId);

	int checkInvalidAgent(EEMApplicationDO eemApplicationDO, EEMApplPlanDO eemApplPlanDO,
			EEMApplAgentDO eemApplAgentDO);

	boolean checkAgent(String customerId, String reqDateOfCov, EEMApplAgentDO eemApplAgentDO);

	int checkInvalidAgency(EEMApplicationDO eemApplicationDO, EEMApplPlanDO eemApplPlanDO,
			EEMApplAgentDO eemApplAgentDO);

	List<String[]> checkDuplicateApplication(EEMApplicationDO eemApplicationDO, String customerNumber);

	List<String[]> checkDuplicateEnrollment(EEMApplicationDO eemApplicationDO);

	List<EEMApplProductDO> getProdInGroup(EEMApplicationDO eemApplicationDO, EEMApplPlanDO eemApplPlanDO);

	boolean checkDuplSupplId(String customerId, String supplId, String memberId);

	// END: Application Validation

	PageableVO getApplSearchDetails(String customerId, Map<String, String> searchParamMap, boolean isPagination);

	EEMApplicationDO getMasterDetails(int applId, String customerId);

	List<EEMApplAddressDO> getAddressDetails(int applId, String customerId);

	EEMApplOtherCovDO getOtherCovDetails(int applId, String customerId);

	List<EEMApplAttestationDO> getAttestationDetails(int applId, String customerId);

	EEMApplAgentDO getAgentDetails(int applId, String customerId, String effDt);

	EEMApplPlanDO getPlanDetails(int applId, String customerId);

	String getLineOfBusniess(String custId, String grpId, String effDate, String prdId, String planId, String pbpId,
			String segId);

	EEMApplOtherPlanDO getPCPDetails(int applId, String customerId);

	String[] getPlanType(String customerId, String plan, String pbp);

	void getPCPName(String customerId, int applId, String reqDtCov, String lineOfBiz,
			EEMApplOtherPlanVO applOtherPlanVO);

	String getProductName(String customerId, String productId, String dateOfCov);

	String getGroupName(String customerId, String groupId, String dateOfCov);

	EEMApplEligibilityDO getEligDetails(int applId, String customerId);

	List<EEMApplCommentsDO> getCommentDetails(int applId, String customerId);
	
	int getCommentSeqNo(String customerId, int applId);

	List<LabelValuePair> getLstBrokAgents(String customerId, String type, String agencyId, String covDt);

	List<EEMApplErrorDO> getErrorDetails(int applId, String customerId);

	EEMApplLisDO getLisDetails(int applId, String customerId);

	EEMApplTriggerDO getApplTrigger(String customerId, int applId, String triggerType, String triggerCode)
			throws SQLException;

	List<LabelValuePair> getLstBrokAgency(String customerId, String covDt);

	int insertCommentDetails(String customerId, int applId, EEMApplCommentsDO commentDO);
	
	int insertBulkCommentDetails(String customerId, int applId, List<EEMApplCommentsDO> applCommentList);

	String getTriggerCode(String mfId, String enrollPlanDesgn, String trigCd);

	int insertApplTrigger(EEMApplTriggerDO trig);

	int updtApplCancel(int applId, String userId, String mfId, String reasonCd);

	public int closeFUATrigger(String customerId, int applId, String userId, String triggerStatus, String applStatus);

	EEMOriginalApplDO getOrigApplDetails(String customerId, int applId);

	List<EEMApplAddressDO> getMbrAddressDetails(EEMApplicationDO eemApplicationDO, EEMApplPlanDO eemApplPlanDO);

	boolean getPriorMemberDetails(EEMApplicationDO eemApplicationDO, EEMApplOtherCovDO eemApplOtherCovDO,
			String planDesgn);

	EEMApplAgentDO getMbrAgentDetails(String customerId, String mbrId, String reqDtCov, String currPlan);

	boolean getOrigAppl(int applId, String customerId);

	int updateOverrideData(String customerId, int applId, String hicNbr);

	int updateDuplicateAppError(List<String[]> lstOrgPlan, String customerId);

	int insertErrorDetails(EEMApplErrorDO eemErrorDO, String userId);

	int insertAddressDetails(EEMApplAddressDO addrDO);

	int updateAddressDetails(EEMApplAddressDO addrDO);

	int deleteAddressDetails(EEMApplAddressDO addrDO);

	int updatePlanDetails(EEMApplPlanDO applPlanVO, String userId);

	int insertPCPDetails(EEMApplOtherPlanDO otherPlanDO, String userId, String rqDtCov, String lineOfBiz);

	int deletePCPDetails(EEMApplOtherPlanDO otherPlanDO);

	int updatePCPDetails(EEMApplOtherPlanDO otherPlanDO, String rqDtCov, String lineOfBiz, String userId);

	int insertPlanDetails(EEMApplPlanDO objVO, String userId);

	boolean checkApplAgent(String customerId, int applId, String lstUpdtTime);

	int insertEligDetailsNotInMBD(EEMApplEligibilityDO eligDO, EEMApplicationDO applDO, String userId);

	EEMBeqDO getBEQDetailsFor(String customerId, int applId, String hicNbr, String birthDt);

	int insertBEQDetails(EEMApplicationDO applDO, String planId, String userId);

	int updateErrorDetails(EEMApplErrorDO objError, String userId);

	int updateMasterDetails(EEMApplicationDO objVO);

	int insertMasterDetails(EEMApplicationDO objVO);

	int updateApplTrigger(EEMApplTriggerDO trig);

	int insertOtherCovDetails(EEMApplOtherCovDO applOtherCovDO, String customerId, int applId, String userId);

	int updateOtherCovDetails(EEMApplOtherCovDO applOtherCovDO, String customerId, int applId, String userId);

	int insertEligDetails(EEMApplEligibilityDO eligDO, MBD mbd, String customerId, int applId, String userId);

	int insertAgentDetails(EEMApplAgentDO agentDO, String customerId, int applId, String userId);

	int deleteApplAgentDetails(String customerId, int applId);

	int updateAgentDetails(EEMApplAgentDO agentDO, String customerId, int applId, String userId);

	int insertLisDetails(EEMApplLisDO applLisDO, String customerId, int applId, String userId);

	int updateLisDetails(EEMApplLisDO applLisDO, String customerId, int applId, String userId);

	boolean checkLISStatus(EEMApplLisDO applLisDO, String customerId, int applId);

	int insertAttestationDetails(String customerId, int applId, String seqNo, String exception, String attestDt,
			String userId);

	int updateAttestationDetails(String customerId, int applId, String attestInd, String attestDt, String userId);

	int deleteAttestationDetails(String customerId, int applId, String attestInd, String attestDt, String userId);

	int setOrigDetails(EEMApplMasterVO eemApplMasterVO, String customerId, String userId);

	String getLockInd(String currStatus);

	List<LabelValuePair> getPreSetNotes(String customerId, EmPreSetNoteVO emPreSetNoteVO);

	Boolean insertPreSetNote(String customerId, EmPreSetNoteVO emPreSetNoteVO);

	Boolean modifyPreSetNote(String customerId, EmPreSetNoteVO emPreSetNoteVO);

	Boolean deletePreSetNote(String customerId, EmPreSetNoteVO emPreSetNoteVO);

	List<LabelValuePair> getCities(String zip5, String county);

	Map<String, Object> populateCountyCityState(String perZip5, String perZip4);

	List<LabelValuePair> getCountyList(String perZip5);

	boolean isCARAEligible(String reqCovDt, String mbi, String hicNbr, String table);

	List<EEMApplStatusTrackDO> getApplicationStatusTrack(String applicationId, String customerId);

	String getApplicationStatusByAppId(String appId, String custId);

	List<EEMApplProductDO> getProducts(EEMApplProdSearchDO prodSerachDO, EEMApplPlanDO eemApplPlanDO);

	boolean getSecondaryCityName(String zip5, String altCity);

	String getGrpProdSpclTpe(String customerId, String enrollGrpId, String reqDtCov, String enrollProduct,
			String enrollPlan, String enrollPbp, String enrollSegment);

}
