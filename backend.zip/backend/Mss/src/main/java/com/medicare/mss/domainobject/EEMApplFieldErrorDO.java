package com.medicare.mss.domainobject;

import java.io.Serializable;

import lombok.Data;

@Data
public class EEMApplFieldErrorDO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3350615009207049493L;
	private String customerId;
	private String editFrom;
	private String editRuleId;
	private String editTo;
	private String editValidVal;
	private String errorCd;
	private String errorMessage;
	private String errorType;
	private String exceptionVal;
	private String fieldNbr;
	private String formField;
	private String formFieldClass;
	private String requiredInd;
	
}

