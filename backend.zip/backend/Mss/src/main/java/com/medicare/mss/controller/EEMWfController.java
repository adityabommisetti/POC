package com.medicare.mss.controller;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.service.EEMWfService;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.vo.EEMAtRiskVO;
import com.medicare.mss.vo.EEMWFActivityVO;
import com.medicare.mss.vo.EEMWFCaseVO;
import com.medicare.mss.vo.EEMWFCommentVO;
import com.medicare.mss.vo.EEMWFSupervisorUserVO;
import com.medicare.mss.vo.EEMWFTransferVO;
import com.medicare.mss.vo.EEMWfCacheVO;
import com.medicare.mss.vo.EEMWfSearchVO;
import com.medicare.mss.vo.EMWFCaseQueueVO;
import com.medicare.mss.vo.EMWFMasterVO;
import com.medicare.mss.vo.EMWFQueAsgnGrpVO;
import com.medicare.mss.vo.EMWFUpdateMasterVO;
import com.medicare.mss.vo.PageableVO;
import com.medicare.mss.vo.WorkFlowDashletVO;

@RestController
@RequestMapping("/workflow")
public class EEMWfController {

	@Autowired
	private EEMWfService wfService;

	@PostMapping(ReqMappingConstants.WF_SEARCH)
	public ResponseEntity<JSONResponse> searchWorkflow(@RequestBody EEMWfSearchVO wfSearchVO) {
		EMWFMasterVO response = wfService.searchWorkflow(wfSearchVO);
		return sendResponse(response);
	}

	@GetMapping(path = ReqMappingConstants.WF_GET_ACTIVITIES)
	public ResponseEntity<JSONResponse> getActivities(@PathVariable("caseId") int caseId) {
		List<EEMWFActivityVO> response = wfService.getActivities(caseId);
		return sendResponse(response);
	}

	@GetMapping(path = ReqMappingConstants.WF_ASSIGN_WORK)
	public ResponseEntity<JSONResponse> assignWork(@PathVariable("fetchSize") int fetchSize) {
		EMWFMasterVO response = wfService.assignWork(fetchSize);
		return sendResponse(response);
	}

	@GetMapping(path = ReqMappingConstants.WF_REFRESH_DASHLETS)
	public ResponseEntity<JSONResponse> loadDashlets(@PathVariable("userId") String userId,
			@PathVariable("isSupervisorTab") boolean isSupervisorTab) {
		List<WorkFlowDashletVO> response = wfService.loadDashlets(userId, isSupervisorTab);
		wfService.setOtherDashletProps(userId, response);

		if (CommonUtils.isNotEmpty(response) && isSupervisorTab) {
			WorkFlowDashletVO manualPopupDashlet = wfService
					.buildManualPopupDashlet(wfService.fetchManualPopupQueues());
			response.add(manualPopupDashlet);
		}
		return sendResponse(response);
	}

	@GetMapping(path = ReqMappingConstants.WF_FETCH_DASHLETS)
	public ResponseEntity<JSONResponse> fetchDashlets(@PathVariable("userId") String userId) {
		List<WorkFlowDashletVO> response = wfService.fetchDashletsByUser(userId);
		return sendResponse(response);
	}

	@GetMapping(path = ReqMappingConstants.WF_GET_CACHE_DATA)
	public ResponseEntity<JSONResponse> getWfCacheData() {
		EEMWfCacheVO response = wfService.getWfCacheData();
		return sendResponse(response);
	}

	@PostMapping(ReqMappingConstants.WF_CASE_STATE_UPDATE)
	public ResponseEntity<JSONResponse> updateCaseState(@RequestBody EMWFUpdateMasterVO emwfUpdateVO) {
		return sendResponse(wfService.updateCaseState(emwfUpdateVO));
	}

	@PostMapping(ReqMappingConstants.WF_GET_COMMENTS)
	public ResponseEntity<JSONResponse> getWFComments(@RequestBody EEMWFCaseVO emwfCaseVO) {
		return sendResponse(wfService.getWFComments(emwfCaseVO));
	}

	@PostMapping(ReqMappingConstants.WF_ADD_COMMENTS)
	public ResponseEntity<JSONResponse> addWFComments(@RequestBody EEMWFCommentVO wfCommentVo) {
		return sendResponse(wfService.addAndGetWFComments(wfCommentVo));
	}

	@GetMapping(ReqMappingConstants.WF_GET_CASE_QUEUE)
	public ResponseEntity<JSONResponse> getWFCaseQueue() {
		return sendResponse(wfService.getWFCaseQueue());
	}

	@PostMapping(ReqMappingConstants.WF_UPDATE_CASE_QUEUE)
	public ResponseEntity<JSONResponse> updateWFCaseQueue(@RequestBody EMWFCaseQueueVO eemwfCaseQueueVO) {
		return sendResponse(wfService.updateWFCaseQueue(eemwfCaseQueueVO));
	}

	@PostMapping(ReqMappingConstants.WF_TRANSFER_CASE)
	public ResponseEntity<JSONResponse> transferCase(@RequestBody EEMWFTransferVO eemWFTransferVO) {
		EMWFMasterVO response = wfService.transferCase(eemWFTransferVO);
		return sendResponse(response);
	}

	@PostMapping(ReqMappingConstants.WF_UPDATE_MAX_USER_WORK)
	public ResponseEntity<JSONResponse> updateWFUserMaxAssignableWorkLimit(
			@PathVariable("maxUserWork") int maxUserWork) {
		int maxAssignableWorkLimit = wfService.updateWFUserMaxAssignableWorkLimit(maxUserWork);
		return sendResponse(maxAssignableWorkLimit);
	}

	@GetMapping(ReqMappingConstants.WF_GET_MAX_USER_WORK)
	public ResponseEntity<JSONResponse> getWFUserMaxAssignableWorkLimit() {
		int maxAssignableWorkLimit = wfService.getWFUserMaxAssignableWorkLimit();
		return sendResponse(maxAssignableWorkLimit);
	}

	@PostMapping(ReqMappingConstants.UPDATE_PRIORITY)
	public ResponseEntity<JSONResponse> updatePriority(@RequestBody EMWFQueAsgnGrpVO eMWFQueAsgnVO) {
		return sendResponse(wfService.updatePriority(eMWFQueAsgnVO));
	}

	@GetMapping(ReqMappingConstants.WF_GET_ATRISK_SUMMARY)
	public ResponseEntity<JSONResponse> getWFAtRiskSummary() {
		return sendResponse(wfService.getAtRiskSummary());
	}

	@PostMapping(ReqMappingConstants.WF_GET_ATRISK_DETAILS)
	public ResponseEntity<JSONResponse> getAtRiskDetails(@RequestBody EEMAtRiskVO eemAtRiskVO) {
		return sendResponse(wfService.getAtRiskDetails(eemAtRiskVO));
	}

	@PostMapping(ReqMappingConstants.UPDATE_WF_USER_STATUS)
	public ResponseEntity<JSONResponse> updateUserStatus(@RequestBody EEMWFSupervisorUserVO emWFSupervisorUserVO) {
		List<EEMWFSupervisorUserVO> supervisorUserVOList = null;
		Boolean result = wfService.updateUserStatus(emWFSupervisorUserVO);
		if (result) {
			supervisorUserVOList = wfService.getSupervisorDetail(emWFSupervisorUserVO.getSearchSupAdminId(),
					emWFSupervisorUserVO.getSearchUserId());
		}
		return sendResponse(supervisorUserVOList);
	}

	@GetMapping(value = ReqMappingConstants.WF_SUPERVISOR_TAB_DETAILS)
	public ResponseEntity<JSONResponse> supervisorTabDetail() {
		return sendResponse(wfService.getSupervisorTabDetail());
	}

	@GetMapping(value = ReqMappingConstants.WF_GET_SUPERVISOR_DETAILS)
	public ResponseEntity<JSONResponse> getSupervisorDetail(@RequestParam("userId") String userId,
			@RequestParam("supOrAdminId") String supOrAdminId) {
		return sendResponse(wfService.getSupervisorDetail(supOrAdminId, userId));
	}

	@GetMapping(value = ReqMappingConstants.WF_GET_ASSGND_NORMAL_USERS)
	public ResponseEntity<JSONResponse> fetchAssignedNormalWfUsers(
			@PathVariable("adminOrSupervisorId") String adminOrSupervisorId) {
		return sendResponse(wfService.fetchAssignedNormalWfUsers(adminOrSupervisorId));
	}

	@GetMapping(ReqMappingConstants.WF_ADDSHOW_USER_INITIAL_DATA)
	public ResponseEntity<JSONResponse> getAddOrShowUserData() {
		return sendResponse(wfService.getAddOrShowUserData());
	}

	@PostMapping(ReqMappingConstants.WF_USER_ADD)
	public ResponseEntity<JSONResponse> addUser(@RequestBody Map<String, String> addParamMap) {
		String role = addParamMap.get("role");
		String userId = addParamMap.get("userId");
		String supervisorId = addParamMap.get("supervisorId");
		return sendResponse(wfService.addUser(role, userId, supervisorId));
	}

	@PostMapping(ReqMappingConstants.WF_USER_SEARCH)
	public ResponseEntity<JSONResponse> searchUser(@RequestBody Map<String, String> searchParamMap) {
		String name = searchParamMap.get("name");
		String searchSupervisorId = searchParamMap.get("searchSupervisorId");
		return sendResponse(wfService.searchUser(name, searchSupervisorId));
	}

	@PostMapping(path = ReqMappingConstants.WF_USER_UPDATE)
	public ResponseEntity<JSONResponse> updateUser(@RequestBody Map<String, String> updateParamMap) {
		String role = updateParamMap.get("role");
		String userId = updateParamMap.get("userId");
		String supervisorId = updateParamMap.get("supervisorId");
		String name = updateParamMap.get("name");
		String searchSupervisorId = updateParamMap.get("searchSupervisorId");

		return sendResponse(wfService.updateUser(role, userId, supervisorId, name, searchSupervisorId));
	}

	@PostMapping(ReqMappingConstants.WF_SEARCH_NEXT)
	public ResponseEntity<JSONResponse> wfSearchPagination(@RequestBody EEMWfSearchVO wfSearchVO) {
		PageableVO pageableVO = wfService.getWorkflowPagination(wfSearchVO);
		return sendResponse(pageableVO);
	}

	@PostMapping(ReqMappingConstants.WF_DELETE_MANUAL_POPUP_QUEUES)
	public ResponseEntity<JSONResponse> deleteManualPopupQueues(@RequestBody Map<String, String> requestMap) {
		return sendResponse(wfService.deleteManualPopupQueues(requestMap));
	}

	private ResponseEntity<JSONResponse> sendResponse(Object result) {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;

		if (Objects.isNull(result)) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setData(result);
			jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
			jsonResponse.setMessage(getStatusMessage(result));
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}

	private String getStatusMessage(Object result) {
		String msg = EEMConstants.SUCCESS;
		if (result instanceof EMWFMasterVO && StringUtils.isNotBlank(((EMWFMasterVO) result).getMessage())) {
			msg = ((EMWFMasterVO) result).getMessage();
		}
		return msg;
	}

}
