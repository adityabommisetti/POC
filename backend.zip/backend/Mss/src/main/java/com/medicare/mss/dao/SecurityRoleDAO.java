package com.medicare.mss.dao;

import java.util.List;

import com.medicare.mss.domainobject.SecurityRoleDO;

public interface SecurityRoleDAO {

	List<SecurityRoleDO> getRolesList(String customerId);

	List<SecurityRoleDO> getUserDetails(String customerId, String userId);

	int getUpdateRole(String userId, String roleId);

	List<SecurityRoleDO> getRoleServices(String roleId, String customerNbr);

	List<SecurityRoleDO> getEnabledServicesList(String roleId, String customerNbr);

	boolean addService(List<String> serviceId, String customerNbr, String userId);

	boolean removeService(List<String> serviceId, String customerNbr, String userId);

}
