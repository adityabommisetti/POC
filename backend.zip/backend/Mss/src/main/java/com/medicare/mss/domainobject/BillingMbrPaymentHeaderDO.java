package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class BillingMbrPaymentHeaderDO {

	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;
	
	@ColumnMapper(columnName = "PAY_SOURCE_TYPE", propertyName = "paySourceType")
	private String paySourceType;
	
	private String paySourceDesc;
	
	@ColumnMapper(columnName = "BATCH_DATE", propertyName = "batchDate")
	private String batchDate;
	
	@ColumnMapper(columnName = "BATCH_SEQ_NBR", propertyName = "batchSeqNbr")
	private int batchSeqNbr;
	
	@ColumnMapper(columnName = "BANK_ACCT_CD", propertyName = "bankAcctCd")
	private String bankAcctCd;
	
	@ColumnMapper(columnName = "BATCH_BALANCE_AMT", propertyName = "batchBalanceAmt")
	private String batchBalanceAmt;
	
	@ColumnMapper(columnName = "DETAIL_TOTAL_AMT", propertyName = "detailTotalAmt")
	private String detailTotalAmt;
	
	@ColumnMapper(columnName = "BATCH_BALANCE_IND", propertyName = "batchBalanceInd")
	private String batchBalanceInd;
	
	@ColumnMapper(columnName = "BATCH_POSTED_IND", propertyName = "batchPostedInd")
	private String batchPostedInd;
	
	@ColumnMapper(columnName = "BATCH_DETAIL_CNT", propertyName = "batchDetailCnt")
	private String batchDetailCnt;
	
	@ColumnMapper(columnName = "CREATE_TIME", propertyName = "createTime")
	private String createTime;
	
	@ColumnMapper(columnName = "CREATE_USERID", propertyName = "createUserId")
	private String createUserId;
	
	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;
	
	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserId")
	private String lastUpdtUserId;
	
	private String itemNumber;
	private String memberId;
	private String posted;
	
	
}
