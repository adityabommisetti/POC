package com.medicare.mss.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

final public class DateMath {

	private static SimpleDateFormat dteFrmt = new SimpleDateFormat("yyyyMMdd");

	private DateMath() {
	}

	

	public static String addOneDay(String dte) throws ParseException {
		return addDay(dte, 1);
	}

	public static String minusOneDay(String dte) throws ParseException {
		return addDay(dte, -1);
	}

	// IFOX - 381884 LEP redesign CR -start
	public static String minusOneDay(String dte, String frmt) throws ParseException {
		return addDay(dte, -1, frmt);
	}

	// IFOX - 381884 LEP redesign CR -End
	public static String addDay(String dte, int units) throws ParseException {

		Calendar cal = convertToCalendar(dte);
		cal.add(Calendar.DAY_OF_YEAR, units);

		return dteFrmt.format(cal.getTime());

	}

	public static boolean isApplicationRecievedInQ1(String MMDDFromApplicationDate) {

		if (Integer.parseInt(MMDDFromApplicationDate) >= Integer.parseInt("0101")
				&& Integer.parseInt(MMDDFromApplicationDate) <= Integer.parseInt("0331"))
			return true;

		return false;
	}

	public static boolean isApplicationRecievedInQ2(String MMDDFromApplicationDate) {

		if (Integer.parseInt(MMDDFromApplicationDate) >= Integer.parseInt("0401")
				&& Integer.parseInt(MMDDFromApplicationDate) <= Integer.parseInt("0630"))
			return true;

		return false;
	}

	public static boolean isApplicationRecievedInQ3(String MMDDFromApplicationDate) {

		if (Integer.parseInt(MMDDFromApplicationDate) >= Integer.parseInt("0701")
				&& Integer.parseInt(MMDDFromApplicationDate) <= Integer.parseInt("0930"))
			return true;

		return false;
	}

	// IFOX - 381884 LEP redesign CR -start
	public static String addDay(String dte, int units, String frmt) throws ParseException {
		SimpleDateFormat dteFrmt = new SimpleDateFormat(frmt);

		Calendar cal = Calendar.getInstance();
		cal.setTime(dteFrmt.parse(dte));
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		cal.add(Calendar.DAY_OF_YEAR, units);
		return dteFrmt.format(cal.getTime());

	}

	// IFOX - 381884 LEP redesign CR -End
	public static String addMonth(String dte, int units) throws ParseException {

		Calendar cal = convertToCalendar(dte);
		cal.add(Calendar.MONTH, units);

		return dteFrmt.format(cal.getTime());

	}

	public static String addYear(String dte, int units) throws ParseException {

		Calendar cal = convertToCalendar(dte);
		cal.add(Calendar.YEAR, units);

		return dteFrmt.format(cal.getTime());

	}

	public static boolean isBetween(String effDate, String startDate, String endDate) {

		if (startDate.compareTo(effDate) <= 0)
			if (endDate.compareTo(effDate) >= 0)
				return true;
		return false;
	}

	public static boolean isFDOM(String dte) throws ParseException {

		if (dte != null) {
			if (dte.length() == 8) {
				if (dte.substring(6).equals("01"))
					return true;
			}
		}
		return false;
	}

	public static boolean isLDOM(String dte) throws ParseException {

		Calendar cal = convertToCalendar(dte);

		int curMth = cal.get(Calendar.MONTH);
		cal.add(Calendar.DAY_OF_YEAR, 1);
		int newMth = cal.get(Calendar.MONTH);

		if (curMth != newMth)
			return true;

		return false;

	}

	public static int monthsBetween(String startDate, String endDate) throws ParseException {

		if ((startDate == null) || (startDate.length() < 6))
			throw new ParseException("Invalid Start Date", 0);
		if ((endDate == null) || (endDate.length() < 6))
			throw new ParseException("Invalid End Date", 0);

		int startYYYY = Integer.parseInt(startDate.substring(0, 4), 10);
		int endYYYY = Integer.parseInt(endDate.substring(0, 4), 10);

		int startMM = Integer.parseInt(startDate.substring(4, 6), 10);
		int endMM = Integer.parseInt(endDate.substring(4, 6), 10);

		int numEnd = (endYYYY * 12) + endMM;
		int numStart = (startYYYY * 12) + startMM;
		int numM;
		if (numEnd < numStart) {
			numM = 0 - (numStart - numEnd);
		} else {
			numM = (numEnd - numStart);
		}

		return numM;
	}

	// IFOX - 381884 LEP redesign CR -start
	public static int monthsBetweenMMddyyyy(String startDate, String endDate) throws ParseException {
		startDate = DateFormatter.reFormat(startDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
		endDate = DateFormatter.reFormat(endDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);

		if ((startDate == null) || (startDate.length() < 6))
			throw new ParseException("Invalid Start Date", 0);
		if ((endDate == null) || (endDate.length() < 6))
			throw new ParseException("Invalid End Date", 0);

		int startYYYY = Integer.parseInt(startDate.substring(0, 4), 10);
		int endYYYY = Integer.parseInt(endDate.substring(0, 4), 10);

		int startMM = Integer.parseInt(startDate.substring(4, 6), 10);
		int endMM = Integer.parseInt(endDate.substring(4, 6), 10);

		int numEnd = (endYYYY * 12) + endMM;
		int numStart = (startYYYY * 12) + startMM;
		int numM;
		if (numEnd < numStart) {
			numM = 0 - (numStart - numEnd);
		} else {
			numM = (numEnd - numStart);
		}

		return numM + 1;
	}

	// IFOX - 381884 LEP redesign CR -End
	public static Calendar convertToCalendar(String dte) throws ParseException {

		Calendar cal = Calendar.getInstance();

		cal.setTime(dteFrmt.parse(dte));

		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);

		return cal;
	}

	public static String getFirstOfNextMonth(String dte) throws ParseException {

		Calendar cal = convertToCalendar(dte);
		cal.set(Calendar.DAY_OF_MONTH, 1);
		cal.add(Calendar.MONTH, 1);
		return dteFrmt.format(cal.getTime());
	}

	public static boolean isEqual(String d1, String d2) {
		if (d1.compareTo(d2) == 0)
			return true;
		return false;
	}

	public static String max(String d1, String d2) {
		if (d1.compareTo(d2) > 0)
			return d1;
		return d2;
	}

	public static String min(String d1, String d2) {
		if (d1.compareTo(d2) <= 0)
			return d1;
		return d2;
	}

	public static boolean isGreaterThan(String d1, String d2) {
		if (d1.compareTo(d2) > 0)
			return true;
		return false;
	}

	public static boolean isGreaterThanOrEqual(String d1, String d2) {
		if (d1.compareTo(d2) >= 0)
			return true;
		return false;
	}

	public static boolean isLessThan(String d1, String d2) {
		if (d1.compareTo(d2) < 0)
			return true;
		return false;
	}

	public static boolean isLessThanorEqual(String d1, String d2) {
		if (d1.compareTo(d2) <= 0)
			return true;
		return false;
	}

	/**
	 * 031_Highmark_SUC_OEVprocess-Start
	 */
	/**
	 * Calaculates the effective date for OEv timers
	 * 
	 * @param d1
	 * @param diff
	 * @return date
	 */
	public static String calculateTimerDate(String d1, int diff) {
		// UAT Iteration 3 fix-start
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date;
		String timerDate = "";
		try {
			date = dateFormat.parse(d1);
			Calendar c = Calendar.getInstance();
			c.setTime(date);
			c.add(Calendar.DATE, diff);
			timerDate = dateFormat.format(c.getTime());
			timerDate = DateFormatter.reFormat(timerDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return timerDate;

	}

	public static int calculateDiff(String d1, String d2) {

		Calendar cal1 = new GregorianCalendar();
		Calendar cal2 = new GregorianCalendar();
		d1 = DateFormatter.reFormat(d1, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
		// d2= DateFormatter.reFormat(d2, DateFormatter.YYYYMMDD,
		// DateFormatter.MM_DD_YYYY);
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		// System.out.println("d1=="+d1+" d2="+d2);
		Date date;
		try {
			date = sdf.parse(d1);
			cal1.setTime(date);
			// System.out.println("1"+date);
			date = sdf.parse(d2);
			cal2.setTime(date);
			// System.out.println("2"+date);
		} catch (ParseException e) {

		}

		int days = daysBetween(cal1.getTime(), cal2.getTime());

		return days;

	}

	public static int daysBetween(Date d1, Date d2) {
		// //System.out.println("dates"+d1.toString()+" "+d2.toString());
		return (int) ((d1.getTime() - d2.getTime()) / (1000 * 60 * 60 * 24));
	}

	public static String getFirstOfLastMonth(String dte) throws ParseException {

		Calendar cal = convertToCalendar(dte);
		cal.set(Calendar.DAY_OF_MONTH, 1);
		cal.add(Calendar.MONTH, -1);
		return dteFrmt.format(cal.getTime());
	}

	public static boolean isBetweenQ4(String date) throws ParseException {
		Calendar octMnth = convertToCalendar(date);
		octMnth.set(Calendar.DAY_OF_MONTH, 1);
		octMnth.set(Calendar.MONTH, 9);

		Calendar decMnth = convertToCalendar(date);
		decMnth.set(Calendar.DAY_OF_MONTH, 31);
		decMnth.set(Calendar.MONTH, 11);
		return isBetween(date, dteFrmt.format(octMnth.getTime()).toString(),
				dteFrmt.format(decMnth.getTime()).toString());
	}

	public static String getFDOJanFromYear(String date) throws ParseException {
		if (StringUtil.isNullOrEmpty(date))
			return null;
		Calendar calDate1 = convertToCalendar(date);
		calDate1.set(Calendar.DAY_OF_MONTH, 1);
		calDate1.set(Calendar.MONTH, 0);
		return dteFrmt.format(calDate1.getTime());
	}

	public static boolean isBetweenQ1(String date) throws ParseException {
		Calendar calDate1 = convertToCalendar(date);
		calDate1.set(Calendar.DAY_OF_MONTH, 1);
		calDate1.set(Calendar.MONTH, 0);

		Calendar calDate2 = convertToCalendar(date);
		calDate2.set(Calendar.DAY_OF_MONTH, 31);
		calDate2.set(Calendar.MONTH, 2);

		return isBetween(date, dteFrmt.format(calDate1.getTime()).toString(),
				dteFrmt.format(calDate2.getTime()).toString());
	}

	public static int getYearFromDate(String date) throws ParseException {
		if (StringUtil.isNullOrEmpty(date))
			return 0;
		Calendar cal = Calendar.getInstance();
		cal.setTime(dteFrmt.parse(date));
		return cal.get(Calendar.YEAR);
	}

	public static boolean isBetweenDARV_Q1(String date, String disEnrollEffDate) throws ParseException {
		Calendar calDate1 = convertToCalendar(date);
		calDate1.set(Calendar.DAY_OF_MONTH, 1);
		calDate1.set(Calendar.MONTH, 1);

		Calendar calDate2 = convertToCalendar(date);
		calDate2.set(Calendar.DAY_OF_MONTH, 30);
		calDate2.set(Calendar.MONTH, 3);

		return isBetween(disEnrollEffDate, dteFrmt.format(calDate1.getTime()).toString(),
				dteFrmt.format(calDate2.getTime()).toString());
	}

	public static String getFirstOfMonth(String dte1) throws ParseException {

		Calendar cal = convertToCalendar(dte1);
		cal.set(Calendar.DAY_OF_MONTH, 1);
		return dteFrmt.format(cal.getTime());
	}
}
