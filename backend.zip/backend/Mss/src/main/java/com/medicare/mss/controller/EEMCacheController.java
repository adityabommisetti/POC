/**
 * 
 */
package com.medicare.mss.controller;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.service.EEMCacheService;

/**
 * @author DU20098149
 *
 */
@RestController
@RequestMapping("/cache")
public class EEMCacheController {

	@Autowired
	private EEMCacheService cacheService;

	@GetMapping(ReqMappingConstants.REMOVE_CACHE)
	public ResponseEntity<JSONResponse> deleteEntireCache() {
		String deleteResponse = cacheService.removeCache();
		return sendResponse(deleteResponse);
	}

	private ResponseEntity<JSONResponse> sendResponse(String deleteResponse) {
		JSONResponse jsonResponse = new JSONResponse();
		if(Objects.nonNull(deleteResponse)) {
			jsonResponse .setMessage(EEMConstants.CACHE_REMOVED);
			jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
			return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		} else {
			jsonResponse.setStatus(EEMConstants.FAILURE);
			return new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		}
	}

}
