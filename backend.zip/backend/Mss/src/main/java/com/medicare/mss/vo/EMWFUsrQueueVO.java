package com.medicare.mss.vo;

import java.io.Serializable;

import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
public class EMWFUsrQueueVO implements Serializable {
	
	private String activityType;
	
	private String lstUpdtTime;

	/**
	 * 
	 */
	private static final long serialVersionUID = -4066529756126415330L;

	private String customerId;

	private Integer applId;

	private String memberId;

	private String hicNum;

	private Integer agreementID;

	private Integer queueID;

	private String currQueReg;

	private String screenId;

	private Integer daysLeft;

	private String activityDate;

	private String dueDate;

	private String completedDate;

	private String priority;

	private String qName;

	private String queueDesc;

	private String queueType;

	private String status;

	private String subStatus;

	private Integer activityCnt;

	private Integer remainActCnt;

	public String getActivityDateFrmt() {
		return DateFormatter.reFormat(activityDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setActivityDateFrmt(String activityDate) {
		this.activityDate = DateFormatter.reFormat(activityDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getDueDateFrmt() {
		return DateFormatter.reFormat(dueDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setDueDateFrmt(String dueDate) {
		this.dueDate = DateFormatter.reFormat(dueDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getCompletedDateFrmt() {
		return DateFormatter.reFormat(completedDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setCompletedDateFrmt(String completedDate) {
		this.completedDate = DateFormatter.reFormat(completedDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

}
