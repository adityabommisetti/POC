package com.medicare.mss.service;

import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.caching.EEMPersistence;
import com.medicare.mss.caching.EEMProfileSettings;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMApplDAO;
import com.medicare.mss.daoImpl.MBDPersistence;
import com.medicare.mss.domainobject.EEMApplAddressDO;
import com.medicare.mss.domainobject.EEMApplAgentDO;
import com.medicare.mss.domainobject.EEMApplOtherCovDO;
import com.medicare.mss.domainobject.EEMApplOtherPlanDO;
import com.medicare.mss.domainobject.EEMApplPlanDO;
import com.medicare.mss.domainobject.EEMApplicationDO;
import com.medicare.mss.domainobject.EEMProfileItemDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EEMApplAddressVO;
import com.medicare.mss.vo.EEMApplAgentVO;
import com.medicare.mss.vo.EEMApplEligibilityVO;
import com.medicare.mss.vo.EEMApplLisVO;
import com.medicare.mss.vo.EEMApplMasterVO;
import com.medicare.mss.vo.EEMApplOtherCovVO;
import com.medicare.mss.vo.EEMApplOtherPlanVO;
import com.medicare.mss.vo.EEMApplPlanVO;
import com.medicare.mss.vo.EEMApplProductVO;
import com.medicare.mss.vo.EEMApplSearchVO;
import com.medicare.mss.vo.EEMApplicationVO;
import com.medicare.mss.vo.MBD;

/**
 * @author
 *
 */
@Service
public class EEMApplMemberCheckService {

	@Autowired
	private CacheService sessionHelper;

	@Autowired
	EEMApplDAO applicationDAO;

	@Autowired
	EEMCodeCache eemCodeCache;

	@Autowired
	MBDPersistence mbdPersistence;

	@Autowired
	EEMPersistence eemPersistence;

	@Autowired
	EEMProfileSettings eemProfileSettings;
	
	private String effStartDate = "00000000";
	private String effEndDate = "99999999";

	public EEMApplMasterVO getMemberDetails(EEMApplMasterVO eemApplMasterVO) {

		EEMApplicationVO eemApplicationVO = eemApplMasterVO.getApplVO();
		if (!trimToEmpty(eemApplicationVO.getMbrHicNbr()).equals("")) {
			String flag = StringUtil.isHicOrMbi(eemApplicationVO.getMbrHicNbr());
			eemApplicationVO.setIsHicOrMbi(flag);
			if (eemApplicationVO.getIsHicOrMbi().equals("mbi")) {
				eemApplicationVO.setMbi(eemApplicationVO.getMbrHicNbr());
			}
		}
		getMemberDetailsDB(eemApplMasterVO, false);
		return eemApplMasterVO;
	}

	public boolean getMemberDetailsDB(EEMApplMasterVO eemApplMasterVO, boolean isUpdate) {

		String plan = "";
		String membOvr = null;
		boolean check = false;
		boolean isNewApp = true;
		String elgOveride = null;
		String beqCheck = null;

		EEMApplPlanVO eemApplPlanVO = null;
		EEMApplicationVO eemApplicationVO = null;
		EEMApplOtherCovVO eemApplOtherCovVO = null;
		EEMApplEligibilityVO eemApplEligibilityVO = null;
		EEMApplAddressVO eemApplAddressVO = null;
		EEMApplProductVO eemApplProductVO = null;
		EEMApplAgentVO eemApplAgentVO = null;
		EEMApplOtherPlanVO eemApplOtherPlanVO = null;

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String updtRec = eemApplMasterVO.getApplVO().getUpdateRec();
		//EEMApplSearchVO applSearchVO = eemApplMasterVO.getApplSearchList().get(0);
		//int applId = applSearchVO.getApplId();

		try {
			this.instantiateApplObjects(eemApplMasterVO);

			eemApplicationVO = eemApplMasterVO.getApplVO();
			eemApplPlanVO = eemApplMasterVO.getApplPlanVO();
			eemApplOtherCovVO = eemApplMasterVO.getApplOtherCovVO();
			eemApplEligibilityVO = eemApplMasterVO.getApplEligiVO();
			eemApplAddressVO = eemApplMasterVO.getApplAddress();
			eemApplProductVO = eemApplMasterVO.getGrpProdVO();
			eemApplAgentVO = eemApplMasterVO.getApplAgentVO();
			eemApplOtherPlanVO = eemApplMasterVO.getApplOtherPlanVO();
			eemApplicationVO.setCustomerId(sessionHelper.getUserInfo().getCustomerId());
			eemApplicationVO.setIsHicOrMbi(
					StringUtil.isHicOrMbi(trimToEmpty(eemApplicationVO.getMbrHicNbr())).equalsIgnoreCase("mbi") ? "mbi"
							: "hic");

			EEMProfileItemDO eemProfileItemDO = eemProfileSettings.getProfileObject(eemApplicationVO.getCustomerId(),
					EEMConstants.ELGOVERIDE);
			if (null != eemProfileItemDO)
				elgOveride = eemProfileItemDO.getParmIndValue();

			eemProfileItemDO = eemProfileSettings.getProfileObject(eemApplicationVO.getCustomerId(),
					EEMConstants.BEQCHECK);
			if (null != eemProfileItemDO)
				beqCheck = eemProfileItemDO.getParmIndValue();

			if ("Y".equals(elgOveride)) {
				MBD mbd = verifyEligibility(eemApplicationVO.getMbrHicNbr(), eemApplicationVO.getMbrLastName(),
						DateUtil.changedDateFormatForMonth(trimToEmpty(eemApplicationVO.getMbrBirthDt())),
						trimToEmpty(beqCheck), eemApplicationVO.getIsHicOrMbi(), eemApplicationVO.getMbi());

				if (mbd != null) {
					String prtAStDt = DateUtil
							.changedDateFormatForMonth(trimToEmpty(eemApplEligibilityVO.getPartAEffDate()));
					String prtBStDt = DateUtil
							.changedDateFormatForMonth(trimToEmpty(eemApplEligibilityVO.getPartBEffDate()));
					String prtDDate = DateUtil
							.changedDateFormatForMonth(trimToEmpty(eemApplEligibilityVO.getPartDEffDate()));
					String prtAMbd = DateUtil.changedDateFormatForMonth(trimToEmpty(mbd.getPrtAEntitleDate()));
					String prtBMbd = DateUtil.changedDateFormatForMonth(trimToEmpty(mbd.getPrtBEntitleDate()));
					String prtDMbd = DateUtil.changedDateFormatForMonth(trimToEmpty(mbd.getPrtDEligibleDate()));

					if (!((trimToEmpty(prtAStDt).equalsIgnoreCase(trimToEmpty(prtAMbd)))
							&& (trimToEmpty(prtBStDt).equalsIgnoreCase(trimToEmpty(prtBMbd)))
							&& (trimToEmpty(prtDDate).equalsIgnoreCase(trimToEmpty(prtDMbd))))
							&& !(trimToEmpty(prtAStDt).equals("") && trimToEmpty(prtBStDt).equals("")
									&& trimToEmpty(prtDDate).equals(""))) {
						eemApplMasterVO.getApplEligiVO().setEligOverInd(EEMConstants.VALUE_YES);
					} else {
						eemApplMasterVO.getApplEligiVO().setEligOverInd(EEMConstants.VALUE_NO);
					}
					
					mbd.setGenderCd(eemCodeCache.getShortGenderNumDesc(mbd.getGenderCd()));
					eemApplMasterVO.setMbd(mbd);
					eemApplEligibilityVO.setLastChkedTime(DateUtil.getCurrentDatetimeStamp());
					if (!isUpdate)
						this.setMBDValues(mbd, eemApplMasterVO);

					eemApplicationVO.setXrefNbr(eemApplMasterVO.getMbd().getXrefClaimNbr());
					eemApplicationVO.setNeedMBDUpdate("Y");

				} else {
					eemApplicationVO.setXrefNbr("");
					eemApplicationVO.setDisplayHic(eemApplicationVO.getMbrHicNbr());
					eemApplMasterVO.setMbd(new MBD());
					eemApplEligibilityVO.setLastChkedTime(DateUtil.getCurrentDatetimeStamp());
					if (!isUpdate)
						this.resetMBDValues(eemApplMasterVO);
					eemApplicationVO.setNeedMBDUpdate("N");
					eemApplicationVO.setMessage("Eligibility not found.");
					check = true;
				}
			}
			EEMApplAgentDO eemApplAgentDO = null;
			EEMApplPlanDO eemApplPlanDO = new EEMApplPlanDO();
			EEMApplicationDO eemApplicationDO = new EEMApplicationDO();
			EEMApplOtherCovDO eemApplOtherCovDO = new EEMApplOtherCovDO();
			EEMApplOtherPlanDO eemApplOtherPlanDO = new EEMApplOtherPlanDO();

			BeanUtils.copyProperties(eemApplicationVO, eemApplicationDO);
			BeanUtils.copyProperties(eemApplPlanVO, eemApplPlanDO);
			BeanUtils.copyProperties(eemApplOtherCovVO, eemApplOtherCovDO);

			if (applicationDAO.getMemberDetails(eemApplicationDO, eemApplPlanDO, eemApplOtherCovDO, plan)) {
				if (eemApplPlanVO.getEnrollPlan() == null || eemApplPlanVO.getEnrollPlan().equals("")
						|| eemApplPlanVO.getEnrollPlan().equalsIgnoreCase(eemApplPlanDO.getCurrPlanId()))
					isNewApp = false;

				EEMApplMasterVO masterVO = new EEMApplMasterVO();
				if (trimToEmpty(eemApplicationVO.getMbrId()).equals("")
						&& !trimToEmpty(eemApplicationVO.getMbrId()).equals(trimToEmpty(eemApplicationDO.getMbrId()))) {

					EEMProfileItemDO eemProfileItem = eemProfileSettings
							.getProfileObject(eemApplicationVO.getCustomerId(), EEMConstants.PREVMBROVR);
					if (null != eemProfileItem)
						membOvr = eemProfileItem.getParmIndValue();

					eemApplProductVO.setCurrProdName(applicationDAO.getProductName(eemApplicationDO.getCustomerId(),
							eemApplPlanDO.getCurrProductId(), eemApplPlanDO.getReqDtCov()));

					eemApplProductVO.setCurrGroupName(applicationDAO.getGroupName(eemApplicationDO.getCustomerId(),
							eemApplPlanDO.getCurrGrpId(), eemApplPlanDO.getReqDtCov()));

					if (trimToEmpty(membOvr).equals("Y")) {
						eemApplAgentDO = applicationDAO.getMbrAgentDetails(eemApplicationDO.getCustomerId(),
								eemApplicationDO.getMbrId(), eemApplPlanDO.getReqDtCov(),
								eemApplPlanDO.getCurrPlanId());
						masterVO.setApplVO(new EEMApplicationVO());
						masterVO.setApplPlanVO(new EEMApplPlanVO());
						BeanUtils.copyProperties(eemApplicationDO, masterVO.getApplVO());
						BeanUtils.copyProperties(eemApplPlanDO, masterVO.getApplPlanVO());

						this.getAddressDetails(eemApplicationVO.getCustomerId(), masterVO, false);

						BeanUtils.copyProperties(masterVO.getApplAddress(), eemApplAddressVO);
						this.populateVOSFromDOS(eemApplicationDO, eemApplPlanDO, eemApplOtherCovDO, eemApplAgentDO,
								eemApplOtherPlanDO, eemApplicationVO, eemApplPlanVO, eemApplOtherCovVO, eemApplAgentVO,
								eemApplOtherPlanVO);
						if (null != eemApplAddressVO) {
							eemApplMasterVO.setLstCity(eemPersistence.getLstCity(eemApplAddressVO.getPerZip5(),
									eemApplAddressVO.getPerZip4(), eemApplAddressVO.getPerCounty()));
							eemApplMasterVO.setLstCounty(eemPersistence.getLstCounty(eemApplAddressVO.getPerZip5()));
						}
					} else if (trimToEmpty(membOvr).equals("N")) {
						eemApplPlanVO.setCurrGrpId(eemApplPlanDO.getCurrGrpId());
						eemApplPlanVO.setCurrPbpId(eemApplPlanDO.getCurrPbpId());
						eemApplPlanVO.setCurrPlanId(eemApplPlanDO.getCurrPlanId());
						eemApplPlanVO.setCurrPlanDesignation(eemApplPlanDO.getCurrPlanDesignation());
						eemApplPlanVO.setCurrProductId(eemApplPlanDO.getCurrProductId());
						eemApplPlanVO.setCurrPaymentAmt(eemApplPlanDO.getCurrPaymentAmt());
						eemApplPlanVO.setCurrPbpSegmentId(eemApplPlanDO.getCurrPbpSegmentId());
					}
				}
				String planDesgn = trimToEmpty(eemApplPlanVO.getCurrPlanDesignation());
				if (!planDesgn.isEmpty())
					eemApplicationVO.setApplType(
							planDesgn.equals("PDP") ? EEMConstants.OPTION_CNTRCHG_PD : EEMConstants.OPTION_CNTRCHG_MA);
				String enrollplanDesgn = trimToEmpty(eemApplProductVO.getPlanDesignation());
				if (!enrollplanDesgn.isEmpty() && !planDesgn.equals(enrollplanDesgn))
					eemApplicationVO.setApplType(enrollplanDesgn.equals("PDP") ? EEMConstants.OPTION_CNTRCHG_PD
							: EEMConstants.OPTION_CNTRCHG_MA);
			}
			if (isNewApp) {
				if (EEMConstants.OPTION_CNTRCHG_MA.equals(eemApplicationVO.getApplType()))
					eemApplicationVO.setApplType(EEMConstants.OPTION_APPLNEWMBR_MA);
				else if (EEMConstants.OPTION_CNTRCHG_PD.equals(eemApplicationVO.getApplType()))
					eemApplicationVO.setApplType(EEMConstants.OPTION_APPLNEWMBR_PD);

				if (applicationDAO.getPriorMemberDetails(eemApplicationDO, eemApplOtherCovDO, plan)) {
					if (!trimToEmpty(eemApplicationVO.getMbrId()).equals(trimToEmpty(eemApplicationDO.getMbrId()))) {
						eemApplicationVO.setAltMbrId(eemApplicationDO.getAltMbrId());
						eemApplicationVO.setMbrRxId(eemApplicationDO.getMbrRxId());
						eemApplicationVO.setMbrId(eemApplicationDO.getMbrId());
					}
				} else {
					if (!trimToEmpty(eemApplicationVO.getMbrId()).equals(trimToEmpty(eemApplicationDO.getMbrId()))) {
						this.resetAddressValues(eemApplAddressVO);
						this.resetPriorMembValues(eemApplicationVO, eemApplOtherCovVO);
					}
				}
			}
			if (trimToEmpty(eemApplicationVO.getMessage()).equals("")) {
				check = true;
				eemApplicationVO.setMessage("Member Check done.");
			}
			eemApplMasterVO.getApplVO().setUpdateRec(updtRec);
			String reqDtCov = DateFormatter.reFormat(eemApplPlanVO.getReqDtCov(), DateFormatter.MM_DD_YYYY,
					DateFormatter.YYYYMMDD);
			List<LabelValuePair> list = eemCodeCache.getInstLookUp(customerId, reqDtCov);
			eemApplMasterVO.setLstInstitutes(list);
		} catch (Exception exp) {
			eemApplicationVO.setMessage("Error during Member Retrieval.");
			throw new ApplicationException(exp,exp.toString());
		}
		return check;
	}

	private void instantiateApplObjects(EEMApplMasterVO eemApplMasterVO) {
		eemApplMasterVO
				.setApplVO(eemApplMasterVO.getApplVO() == null ? new EEMApplicationVO() : eemApplMasterVO.getApplVO());
		eemApplMasterVO.setApplPlanVO(
				eemApplMasterVO.getApplPlanVO() == null ? new EEMApplPlanVO() : eemApplMasterVO.getApplPlanVO());
		eemApplMasterVO.setApplEligiVO(eemApplMasterVO.getApplEligiVO() == null ? new EEMApplEligibilityVO()
				: eemApplMasterVO.getApplEligiVO());
		eemApplMasterVO.setApplOtherCovVO(eemApplMasterVO.getApplOtherCovVO() == null ? new EEMApplOtherCovVO()
				: eemApplMasterVO.getApplOtherCovVO());
		eemApplMasterVO.setGrpProdVO(
				eemApplMasterVO.getGrpProdVO() == null ? new EEMApplProductVO() : eemApplMasterVO.getGrpProdVO());
		eemApplMasterVO.setApplAgentVO(
				eemApplMasterVO.getApplAgentVO() == null ? new EEMApplAgentVO() : eemApplMasterVO.getApplAgentVO());
		eemApplMasterVO.setApplOtherPlanVO(eemApplMasterVO.getApplOtherPlanVO() == null ? new EEMApplOtherPlanVO()
				: eemApplMasterVO.getApplOtherPlanVO());
		eemApplMasterVO.setApplLisVO(
				eemApplMasterVO.getApplLisVO() == null ? new EEMApplLisVO() : eemApplMasterVO.getApplLisVO());
	}

	public MBD verifyEligibility(String hicNbr, String lastName, String birthDt, String beqCheck, String isHicOrMbi,
			String mbi) {

		return mbdPersistence.getHicMatch(hicNbr, lastName, birthDt, "Y", isHicOrMbi, mbi);
	}

	private void setMBDValues(MBD mbd, EEMApplMasterVO eemApplMasterVO) {

		EEMApplLisVO eemApplLisVO = eemApplMasterVO.getApplLisVO();
		EEMApplicationVO objVO = eemApplMasterVO.getApplVO();
		EEMApplEligibilityVO eemApplEligibilityVO = eemApplMasterVO.getApplEligiVO();
		EEMApplOtherCovVO eemApplOtherCovVO = eemApplMasterVO.getApplOtherCovVO();
		EEMApplPlanVO eemApplPlanVO = eemApplMasterVO.getApplPlanVO();

		if (!trimToEmpty(mbd.getMbi()).isEmpty()) {
			objVO.setMbrHicNbr(trimToEmpty(mbd.getMbi()));
		}
		objVO.setDisplayHic(trimToEmpty(mbd.getHicNbr()));

		if (trimToEmpty(objVO.getIsHicOrMbi()).isEmpty())
			objVO.setMbrHicNbr(trimToEmpty(mbd.getHicNbr()));

		if (eemApplEligibilityVO.getEligOverInd().equalsIgnoreCase("N")) {
			eemApplEligibilityVO.setPartAEffDate(
					DateFormatter.reFormat(mbd.getPrtAEntitleDate(), DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
			eemApplEligibilityVO.setPartBEffDate(
					DateFormatter.reFormat(mbd.getPrtBEntitleDate(), DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
			eemApplEligibilityVO.setPartDEffDate(DateFormatter.reFormat(mbd.getPrtDEligibleDate(),
					DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		}
		if (trimToEmpty(objVO.getMbrFirstName()).equals(""))
			objVO.setMbrFirstName(mbd.getFirstName());

		if (trimToEmpty(objVO.getMbrLastName()).equals(""))
			objVO.setMbrLastName(mbd.getLastName());

		if (trimToEmpty(objVO.getMbrMiddleName()).equals(""))
			objVO.setMbrMiddleName(mbd.getMiddleInit());

		if (mbd.isIshicxref()) {
			if (trimToEmpty(objVO.getXrefNbr()).equals(""))
				objVO.setXrefNbr(mbd.getXrefClaimNbr());

			objVO.setMbrHicNbr(mbd.getHicNbr());
		} else {
			if (trimToEmpty(objVO.getXrefNbr()).equals(""))
				objVO.setXrefNbr(mbd.getXrefClaimNbr());
		}
		if (trimToEmpty(objVO.getMbrBirthDt()).equals("")) {
			objVO.setMbrBirthDt(
					DateFormatter.reFormat(mbd.getBirthDate(), DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		}
		if (trimToEmpty(objVO.getMbrGender()).equals("")) {
			objVO.setMbrGender(mbd.getGenderCd());
			eemApplOtherCovVO.setEsrd(this.getInd(mbd.getEsrdInd()));
		}
		if (trimToEmpty(eemApplOtherCovVO.getEsrd()).equals("Y")) {
			eemApplEligibilityVO.setEsrdStartDt(
					DateFormatter.reFormat(mbd.getEsrdStartDate(), DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
			eemApplEligibilityVO.setEsrdEndDt(
					DateFormatter.reFormat(mbd.getEsrdEndDate(), DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		} else {
			eemApplOtherCovVO.setPcoInd("N");
			eemApplEligibilityVO.setEsrdStartDt("");
			eemApplEligibilityVO.setEsrdEndDt("");
		}
		eemApplOtherCovVO.setNameInstitute(getInd(mbd.getInstInd()));
		if (trimToEmpty(eemApplOtherCovVO.getNameInstitute()).equals("Y")) {
			eemApplEligibilityVO.setInstStartDt(
					DateFormatter.reFormat(mbd.getInstStartDate(), DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
			eemApplEligibilityVO.setInstEndDt(
					DateFormatter.reFormat(mbd.getInstEndDate(), DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		} else {
			eemApplOtherCovVO.setNameInstitute("");
			eemApplOtherCovVO.setLtcFacAddress("");
			eemApplOtherCovVO.setLtcFacPhone("");
			eemApplEligibilityVO.setInstStartDt("");
			eemApplEligibilityVO.setInstEndDt("");
		}
		eemApplOtherCovVO.setStMedicaid(this.getInd(mbd.getMedicInd()));
		if (trimToEmpty(eemApplOtherCovVO.getStMedicaid()).equals("Y")) {
			eemApplEligibilityVO.setMedicStartDt(
					DateFormatter.reFormat(mbd.getMedicStartDate(), DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
			eemApplEligibilityVO.setMedicEndDt(
					DateFormatter.reFormat(mbd.getMedicEndDate(), DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		} else {
			eemApplEligibilityVO.setMedicStartDt("");
			eemApplEligibilityVO.setMedicEndDt("");
			eemApplOtherCovVO.setMedicaidId("");
		}
		if ((!(trimToEmpty(mbd.getSubsidyStartDate1()).equals(effStartDate)))
				&& DateMath.isBetween(
						DateFormatter.reFormat((eemApplPlanVO.getReqDtCov()), DateFormatter.MM_DD_YYYY,
								DateFormatter.YYYYMMDD),
						trimToEmpty(mbd.getSubsidyStartDate1()),
						trimToEmpty(mbd.getSubsidyEndDate1()).equals(effStartDate) ? effEndDate
								: trimToEmpty(mbd.getSubsidyEndDate1()))) {
			eemApplLisVO.setEffStartDt(DateFormatter.reFormat(mbd.getSubsidyStartDate1(), DateFormatter.YYYYMMDD,
					DateFormatter.MM_DD_YYYY));
			eemApplLisVO.setEffEndDt(trimToEmpty(mbd.getSubsidyEndDate1()).equals(effStartDate) ? "99/99/9999"
					: DateFormatter.reFormat(mbd.getSubsidyEndDate1(), DateFormatter.YYYYMMDD,
							DateFormatter.MM_DD_YYYY));
			eemApplLisVO.setLiCoPayCd(mbd.getCopayLevelId1());
			eemApplLisVO.setLisPctCd(mbd.getPartDPremsubsPct1());
		} else if ((!(trimToEmpty(mbd.getSubsidyStartDate2()).equals(effStartDate)))
				&& DateMath.isBetween(
						DateFormatter.reFormat((eemApplPlanVO.getReqDtCov()), DateFormatter.MM_DD_YYYY,
								DateFormatter.YYYYMMDD),
						trimToEmpty(mbd.getSubsidyStartDate2()),
						trimToEmpty(mbd.getSubsidyEndDate2()).equals(effStartDate) ? effEndDate
								: trimToEmpty(mbd.getSubsidyEndDate2()))) {
			eemApplLisVO.setEffStartDt(DateFormatter.reFormat(mbd.getSubsidyStartDate2(), DateFormatter.YYYYMMDD,
					DateFormatter.MM_DD_YYYY));
			eemApplLisVO.setEffEndDt(trimToEmpty(mbd.getSubsidyEndDate2()).equals(effStartDate) ? "99/99/9999"
					: DateFormatter.reFormat(mbd.getSubsidyEndDate2(), DateFormatter.YYYYMMDD,
							DateFormatter.MM_DD_YYYY));
			eemApplLisVO.setLiCoPayCd(mbd.getCopayLevelId2());
			eemApplLisVO.setLisPctCd(mbd.getPartDPremsubsPct2());
		} else {
			eemApplLisVO.setEffStartDt("");
			eemApplLisVO.setEffEndDt("");
			eemApplLisVO.setLiCoPayCd("");
			eemApplLisVO.setLisPctCd("");
		}
	}

	private void resetMBDValues(EEMApplMasterVO eemApplMasterVO) {

		EEMApplEligibilityVO eemApplEligibilityVO = eemApplMasterVO.getApplEligiVO();
		EEMApplLisVO eemApplLisVO = eemApplMasterVO.getApplLisVO();

		eemApplEligibilityVO.setPartAEffDate("");
		eemApplEligibilityVO.setPartBEffDate("");
		eemApplEligibilityVO.setPartDEffDate("");
		eemApplEligibilityVO.setEsrdStartDt("");
		eemApplEligibilityVO.setEsrdEndDt("");
		eemApplEligibilityVO.setInstStartDt("");
		eemApplEligibilityVO.setInstEndDt("");
		eemApplEligibilityVO.setMedicStartDt("");
		eemApplEligibilityVO.setMedicEndDt("");
		eemApplLisVO.setEffStartDt("");
		eemApplLisVO.setEffEndDt("");
		eemApplLisVO.setLiCoPayCd("");
		eemApplLisVO.setLisPctCd("");
	}

	public void getAddressDetails(String customerId, EEMApplMasterVO applMasterVO, boolean isNew) {

		int applId = 0;
		List<EEMApplAddressDO> addressDoList = null;
		EEMApplAddressVO applAddVO = new EEMApplAddressVO();
		List<EEMApplSearchVO> applSearchList = applMasterVO.getApplSearchList();
		if (null != applSearchList && !applSearchList.isEmpty()) {
			EEMApplSearchVO applSearchVO = applMasterVO.getApplSearchList().get(0);
			applId = applSearchVO.getApplId();
		}
		if (isNew) {
			addressDoList = applicationDAO.getAddressDetails(applId, customerId);
		} else {
			EEMApplicationDO eemApplicationDO = new EEMApplicationDO();
			EEMApplPlanDO eemApplPlanDO = new EEMApplPlanDO();
			BeanUtils.copyProperties(applMasterVO.getApplVO(), eemApplicationDO);
			BeanUtils.copyProperties(applMasterVO.getApplPlanVO(), eemApplPlanDO);
			eemApplicationDO.setCustomerId(customerId);

			addressDoList = applicationDAO.getMbrAddressDetails(eemApplicationDO, eemApplPlanDO);
		}

		if (null != addressDoList && !addressDoList.isEmpty()) {
			addressDoList.forEach(addressDO -> {
				if (addressDO.getAddressType().equals(EEMConstants.EEM_ADDRTYPE_PRIMARY)) {
					applAddVO.setPerAdd1(addressDO.getAddress1());
					applAddVO.setPerAdd2(addressDO.getAddress2());
					applAddVO.setPerAdd3(addressDO.getAddress3());
					applAddVO.setPerCity(addressDO.getCity());
					applAddVO.setPerState(eemCodeCache.getCode(addressDO.getStateCd(), eemPersistence.getLstStates()));
					String zip = addressDO.getZipCd();
					if (zip.length() == 9) {
						applAddVO.setPerZip5(zip.substring(0, 5));
						applAddVO.setPerZip4(zip.substring(5, 9));
					} else if (zip.length() == 5) {
						applAddVO.setPerZip5(zip);
						applAddVO.setPerZip4("");
					}
					applAddVO.setPerCounty(addressDO.getCountyCd());
					applAddVO.setPerPhone(addressDO.getHomePhoneNbr());
					applAddVO.setPerCell(addressDO.getCellPhoneNbr());
					applAddVO.setPerWorkPhone(addressDO.getWorkPhoneNbr());
					applAddVO.setPerFax(addressDO.getFaxNbr());
					applAddVO.setLstUpdtPrimAddr(addressDO.getLastUpdtTime());
				} else if (addressDO.getAddressType().equals(EEMConstants.EEM_ADDRTYPE_MAIL)) {
					applAddVO.setMailAdd1(addressDO.getAddress1());
					applAddVO.setMailAdd2(addressDO.getAddress2());
					applAddVO.setMailAdd3(addressDO.getAddress3());
					applAddVO.setMailCity(addressDO.getCity());
					applAddVO.setMailState(eemCodeCache.getCode(addressDO.getStateCd(), eemPersistence.getLstStates()));
					String zip = addressDO.getZipCd();
					if (zip.length() == 9) {
						applAddVO.setMailZip5(zip.substring(0, 5));
						applAddVO.setMailZip4(zip.substring(5, 9));
					} else if (zip.length() == 5) {
						applAddVO.setMailZip5(zip);
						applAddVO.setMailZip4("");
					}
					applAddVO.setMailCountry(addressDO.getCountryCd());
					applAddVO.setLstUpdtMailAddr(addressDO.getLastUpdtTime());
				} else if (addressDO.getAddressType().equals(EEMConstants.EEM_ADDRTYPE_AUTH)) {
					applAddVO.setAuthRepStreet(addressDO.getAddress1());
					applAddVO.setAuthRepCity(addressDO.getCity());
					applAddVO.setAuthRepState(
							eemCodeCache.getCode(addressDO.getStateCd(), eemPersistence.getLstStates()));
					String zip = addressDO.getZipCd();
					if (zip.length() == 9) {
						applAddVO.setAuthRepZip5(zip.substring(0, 5));
						applAddVO.setAuthRepZip4(zip.substring(5, 9));
					} else if (zip.length() == 5) {
						applAddVO.setAuthRepZip5(zip);
						applAddVO.setAuthRepZip4("");
					}
					applAddVO.setAuthRepPhone(addressDO.getWorkPhoneNbr());
					applAddVO.setLstUpdtAuthAddr(addressDO.getLastUpdtTime());
				}
			});
		}
		applMasterVO.setApplAddress(applAddVO);
	}

	private void populateVOSFromDOS(EEMApplicationDO eemApplicationDO, EEMApplPlanDO eemApplPlanDO,
			EEMApplOtherCovDO eemApplOtherCovDO, EEMApplAgentDO eemApplAgentDO, EEMApplOtherPlanDO eemApplOtherPlanDO,
			EEMApplicationVO eemApplicationVO1, EEMApplPlanVO eemApplPlanVO1, EEMApplOtherCovVO eemApplOtherCovVO1,
			EEMApplAgentVO eemApplAgentVO1, EEMApplOtherPlanVO eemApplOtherPlanVO1) {

		BeanUtils.copyProperties(eemApplicationDO, eemApplicationVO1);

		String electionType = eemApplPlanVO1.getElectionType();
		BeanUtils.copyProperties(eemApplPlanDO, eemApplPlanVO1);
		eemApplPlanVO1.setElectionType(electionType);

		BeanUtils.copyProperties(eemApplOtherCovDO, eemApplOtherCovVO1);
		if (null != eemApplAgentDO) {
			BeanUtils.copyProperties(eemApplAgentDO, eemApplAgentVO1);
		}
		BeanUtils.copyProperties(eemApplOtherPlanDO, eemApplOtherPlanVO1);
	}

	private void resetAddressValues(EEMApplAddressVO objVO) {

		objVO.setPerAdd1("");
		objVO.setPerAdd2("");
		objVO.setPerAdd3("");
		objVO.setPerCity("");
		objVO.setPerState("");
		objVO.setPerZip5("");
		objVO.setPerZip4("");
		objVO.setPerCounty("");
		objVO.setPerPhone("");
		objVO.setPerCell("");
		objVO.setPerWorkPhone("");
		objVO.setPerFax("");
		objVO.setMailAdd1("");
		objVO.setMailAdd2("");
		objVO.setMailAdd3("");
		objVO.setMailCity("");
		objVO.setMailState("");
		objVO.setMailZip5("");
		objVO.setMailZip4("");
		objVO.setMailCountry("");
		objVO.setAuthRepStreet("");
		objVO.setAuthRepCity("");
		objVO.setAuthRepState("");
		objVO.setAuthRepZip5("");
		objVO.setAuthRepZip4("");
		objVO.setAuthRepPhone("");
		objVO.setLstUpdtAuthAddr("");
	}

	private void resetPriorMembValues(EEMApplicationVO objVO, EEMApplOtherCovVO eemApplOtherCovVO) {

		objVO.setMbrId("");
		objVO.setAltMbrId("");
		objVO.setMbrLastName("");
		objVO.setMbrFirstName("");
		objVO.setMbrMiddleName("");
		objVO.setMbrPrefix("");
		objVO.setMailLastName("");
		objVO.setMailFirstName("");
		objVO.setMailMiddleName("");
		objVO.setInsCardName("");
		objVO.setMbrSsn("");
		objVO.setMbrBirthDt(DateUtil.formatMmDdYyyy(""));
		objVO.setMbrGender("");
		objVO.setAuthRepFirstName("");
		objVO.setAuthRepMidName("");
		objVO.setAuthRepLastName("");
		objVO.setAuthRepRelation("");
		objVO.setEmergName("");
		objVO.setEmergPhone("");
		objVO.setEmergRelation("");
		objVO.setEmergEmail("");
		objVO.setMbrEmail("");
		objVO.setLanguage("");
		eemApplOtherCovVO.setSpouseWork("");
	}

	private String getInd(String value) {

		return trimToEmpty(value).equals("") || trimToEmpty(value).equals("1") ? "N" : "Y";
	}

}
