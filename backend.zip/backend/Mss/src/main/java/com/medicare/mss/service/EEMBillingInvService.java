/**
 * 
 */
package com.medicare.mss.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.caching.EEMPersistence;
import com.medicare.mss.caching.EEMProfileSettings;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.EEMProfileConstants;
import com.medicare.mss.dao.EEMBillingInvDAO;
import com.medicare.mss.dao.EEMDAO;
import com.medicare.mss.domainobject.EEMBillFuncDO;
import com.medicare.mss.domainobject.EEMBillingFunctionCodeDO;
import com.medicare.mss.domainobject.EEMBillingInvCommentDO;
import com.medicare.mss.domainobject.EEMBillingInvHeaderDtlsDO;
import com.medicare.mss.domainobject.EEMBillingInvoiceDtlsDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.helper.EEMContext;
import com.medicare.mss.security.vo.EEMBillingInvCommentVO;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.util.NumberFormatter;
import com.medicare.mss.vo.BillInvoiceDetailsUpdateVO;
import com.medicare.mss.vo.BillingMbrGrpSearchVO;
import com.medicare.mss.vo.EEMBillFuncVO;
import com.medicare.mss.vo.EEMBillingCacheVO;
import com.medicare.mss.vo.EEMBillingInvHeaderDtlsVO;
import com.medicare.mss.vo.EEMBillingInvMasterVO;
import com.medicare.mss.vo.EEMBillingInvSummaryVO;
import com.medicare.mss.vo.EEMBillingInvTransferVO;
import com.medicare.mss.vo.EEMBillingInvoiceDtlsVO;
import com.medicare.mss.vo.EEMBillingInvoiceSearchVO;
import com.medicare.mss.vo.PageableVO;

/**
 * @author DU20098149
 *
 */
@Service
@Transactional(rollbackFor = ApplicationException.class)
public class EEMBillingInvService {

	private static final Logger LOG = LoggerFactory.getLogger(EEMBillingInvService.class);

	private static final String NEXT_INV_ID = "INV";

	private static final String DEFAULT_WIP_TIME = "0001-01-01 00:00:00.000000";

	@Autowired
	private EEMBillingInvDAO billingInvoiceDAO;

	@Autowired
	private EEMPersistence eemPersistence;

	@Autowired
	private CacheService sessionHelper;

	@Autowired
	private EEMCodeCache codeCache;

	@Autowired
	private EEMDAO eemDao;

	@Autowired
	EEMProfileSettings eemProfileSettings;

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public EEMBillingInvMasterVO searchBillingInvoice(EEMBillingInvoiceSearchVO searchVO) {

		EEMBillingInvMasterVO masterVO = initializeMasterVO();
		String custId = sessionHelper.getUserInfo().getCustomerId();

		PageableVO pageableSearchResult = billingInvoiceDAO.searchBillingInvoice(searchVO, custId, false);
		List<EEMBillingInvHeaderDtlsDO> billingInvHeaderDtlsDOs = (List<EEMBillingInvHeaderDtlsDO>) pageableSearchResult
				.getContent();
		if (!CollectionUtils.isEmpty(billingInvHeaderDtlsDOs)) {
			// copying EEMBillingInvHeaderDtlsDO to EEMBillingInvHeaderDtlsVO
			copyBillingInvHdrDtlsDOsToVOs(billingInvHeaderDtlsDOs, searchVO, masterVO);
			// populating billing invoice masterVO
			populateBillingInvMasterVO(masterVO, masterVO.getBillingInvHeaderDtlsVOs().get(0));
			masterVO.setNextPage(pageableSearchResult.isNextPage());
		}
		
		setToContext(masterVO);
		return masterVO;
	}

	public EEMBillingInvMasterVO searchSelectBillingInvoice(EEMBillingInvHeaderDtlsVO billInvHdrDtlsVO) {
		EEMBillingInvMasterVO masterVO = initializeMasterVO();
		// populating billing invoice master VO
		populateBillingInvMasterVO(masterVO, billInvHdrDtlsVO);
		//setting billing invoice header
		masterVO.getBillingInvHeaderDtlsVOs().add(billInvHdrDtlsVO);
		setToContext(masterVO);
		return masterVO;
	}

	public synchronized List<EEMBillingInvCommentVO> saveBillInvoiceComment(
			EEMBillingInvCommentVO billingInvCommentVO) {
		EEMBillingInvCommentVO newCommentVO;
		List<EEMBillingInvCommentVO> commentsVO = new ArrayList<>();
		String userId = sessionHelper.getUserInfo().getUserId();
		String custId = sessionHelper.getUserInfo().getCustomerId();

		try {
			newCommentVO = (EEMBillingInvCommentVO) billingInvCommentVO.clone();
			newCommentVO.setCustomerId(custId);
			newCommentVO.setCreateUserId(userId);

			boolean success = billingInvoiceDAO.getNextMbrComment(newCommentVO);
			if (success) {
				int cnt = billingInvoiceDAO.insertBillInvoiceComment(newCommentVO);
				if (cnt == 1) {
					List<EEMBillingInvCommentDO> commentsDO = billingInvoiceDAO
							.getBillInvoiceComments(newCommentVO.getCustomerId(), newCommentVO.getInvoiceNbr());
					CommonUtils.copyList(commentsDO, commentsVO, EEMBillingInvCommentVO.class);
				}
			}

		} catch (CloneNotSupportedException e) {
			LOG.error("error occured while cloning comment!");
		}
		return commentsVO;
	}

	public EEMBillingInvMasterVO billInvoiceTransfer(EEMBillingInvTransferVO billingInvTransferVO) {

		EEMBillingInvMasterVO initialMasterVO = initializeMasterVO();
		int cntRec = 0;
		EEMBillingInvHeaderDtlsVO selectedHdrDtls = billingInvTransferVO.getBillHeaderVO();
		EEMBillingInvoiceDtlsVO selectedInvDtls = billingInvTransferVO.getBillInvVO();

		EEMBillingInvHeaderDtlsVO headerVO = new EEMBillingInvHeaderDtlsVO();
		EEMBillingInvoiceDtlsVO detailVO = new EEMBillingInvoiceDtlsVO();
		EEMBillingInvHeaderDtlsVO prevHeaderVO = new EEMBillingInvHeaderDtlsVO();
		EEMBillingInvoiceDtlsVO prevDetailVO = new EEMBillingInvoiceDtlsVO();

		BeanUtils.copyProperties(selectedHdrDtls, headerVO);
		BeanUtils.copyProperties(selectedHdrDtls, prevHeaderVO);
		BeanUtils.copyProperties(selectedInvDtls, detailVO);
		BeanUtils.copyProperties(selectedInvDtls, prevDetailVO);

		boolean lineItemHistoryExists = checkExistingAdjustmentsForLineItem(headerVO, detailVO);
		boolean isValidForTransfer = false;

		String adjustableAmount = billingInvoiceDAO.getEligibleLineAmount(detailVO.getCustomerId(),
				headerVO.getInvoiceNbr(), String.valueOf(detailVO.getItemNbr()));

		if (Objects.isNull(adjustableAmount)) {
			adjustableAmount = "0";
		}

		if (lineItemHistoryExists) {
			isValidForTransfer = validateAmtForTransOrRefundWithHist(adjustableAmount,
					billingInvTransferVO.getTransAmt());
		} else {
			isValidForTransfer = validateAmtForTransOrRefundWithoutHist(adjustableAmount,
					billingInvTransferVO.getTransAmt());
		}

		if (!isValidForTransfer) {
			throw new ApplicationException("Invalid Transfer Adjustment");
		}

		String inputStatus = hasValidTransferInput(billingInvTransferVO, headerVO.getCustomerId());
		if (StringUtils.isNotBlank(inputStatus)) {
			throw new ApplicationException(inputStatus);
		}

		// Insert Transfer To Invoice Header
		String userId = sessionHelper.getUserInfo().getUserId();
		String ts = DateUtil.getCurrentDatetimeStamp();
		headerVO.setInvoiceType("UM");
		headerVO.setInvoiceId(billingInvTransferVO.getTransGrpId());
		headerVO.setGlProcessedInd("N");
		headerVO.setInvoiceStatus("NL");
		headerVO.setInvoiceAmt("0");
		headerVO.setPaymentAmt(String.valueOf(Double.parseDouble(billingInvTransferVO.getTransAmt()) * -1));
		headerVO.setAdjustmentAmt("0");
		headerVO.setLastItemNbr("1");
		headerVO.setWipTime(DEFAULT_WIP_TIME);
		headerVO.setWipUserId("");
		headerVO.setCreateUserId(userId);
		headerVO.setLastUpdtUserId(userId);
		headerVO.setCreateTime(ts);
		headerVO.setLastUpdtTime(ts);

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		headerVO.setInvoiceNbr(String.valueOf(eemDao.getNextSeqNo(customerId, NEXT_INV_ID)));
		cntRec = billingInvoiceDAO.insertBillInvoiceHeader(headerVO);

		// Insert Transfer To Invoice Detail
		if (cntRec > 0) {
			detailVO.setInvoiceNbr(headerVO.getInvoiceNbr());
			detailVO.setItemNbr(1);
			detailVO.setAddNbr(0);
			detailVO.setFunctionCd("TTM");
			detailVO.setMemberId(billingInvTransferVO.getTransGrpId());
			detailVO.setGrpId(EEMConstants.BLANK);
			detailVO.setCheckNbr(EEMConstants.BLANK);

			EEMBillingFunctionCodeDO billFuncCode = codeCache.getFunctionCode(detailVO.getCustomerId(),
					detailVO.getFunctionCd());

			if (Objects.nonNull(billFuncCode)) {
				detailVO.setItemDesc(StringUtils.trimToEmpty(billFuncCode.getShortDesc()));
			}
			detailVO.setDetailAmt(headerVO.getPaymentAmt());
			detailVO.setXrefInvoiceNbr(prevDetailVO.getInvoiceNbr());
			detailVO.setCreateUserId(userId);
			detailVO.setLastUpdtUserId(userId);
			detailVO.setCreateTime(ts);
			detailVO.setLastUpdtTime(ts);

			cntRec = billingInvoiceDAO.insertBillInvoiceDetail(detailVO);
		}

		// Insert Transfer From Invoice Detail
		if (cntRec > 0) {
			prevDetailVO.setAddNbr(billingInvoiceDAO.getNextAddNbr(prevDetailVO.getCustomerId(),
					prevDetailVO.getInvoiceNbr(), prevDetailVO.getItemNbr()));

			prevDetailVO.setFunctionCd("TFM");
			EEMBillingFunctionCodeDO billFuncCode = codeCache.getFunctionCode(prevDetailVO.getCustomerId(),
					prevDetailVO.getFunctionCd());

			if (Objects.nonNull(billFuncCode)) {
				prevDetailVO.setItemDesc(StringUtils.trimToEmpty(billFuncCode.getShortDesc()));
			}
			prevDetailVO.setDetailAmt(billingInvTransferVO.getTransAmt());
			prevDetailVO.setXrefInvoiceNbr(headerVO.getInvoiceNbr());
			prevDetailVO.setCreateUserId(userId);
			prevDetailVO.setLastUpdtUserId(userId);
			prevDetailVO.setCreateTime(ts);
			prevDetailVO.setLastUpdtTime(ts);
			prevDetailVO.setCheckNbr(EEMConstants.BLANK);

			cntRec = billingInvoiceDAO.insertBillInvoiceDetail(prevDetailVO);
		}

		// Update Transfer From Invoice Header
		if (cntRec > 0) {
			double pymtAmt = Double.parseDouble(prevHeaderVO.getPaymentAmt())
					+ Double.parseDouble(billingInvTransferVO.getTransAmt());
			prevHeaderVO.setPaymentAmt(String.valueOf(pymtAmt));
			prevHeaderVO.setGlProcessedInd("N");

			prevHeaderVO.setLastUpdtUserId(userId);
			prevHeaderVO.setLastUpdtTime(ts);

			cntRec = billingInvoiceDAO.updateBillInvoiceTransferHeader(prevHeaderVO);
		}

		// Insert Transfer To Payment Detail Invoice
		if (cntRec > 0) {
			detailVO.setCreateUserId(userId);
			detailVO.setLastUpdtUserId(userId);
			detailVO.setCreateTime(ts);
			detailVO.setLastUpdtTime(ts);

			cntRec = billingInvoiceDAO.insertBillPaymentDtlInvoice(detailVO);
		}

		// Insert Transfer From Payment Detail Invoice
		if (cntRec > 0) {
			prevDetailVO.setCreateUserId(userId);
			prevDetailVO.setLastUpdtUserId(userId);
			prevDetailVO.setCreateTime(ts);
			prevDetailVO.setLastUpdtTime(ts);

			cntRec = billingInvoiceDAO.insertBillPaymentDtlInvoice(prevDetailVO);
		}

		if (cntRec > 0) {
			EEMBillingInvMasterVO masterVO = searchSelectBillingInvoice(selectedHdrDtls);
			return masterVO;
		} else {
			return initialMasterVO;
		}
	}

	public EEMBillingInvMasterVO updateBillInvoiceDetails(BillInvoiceDetailsUpdateVO billInvoiceDetailsUpdateVO)
			throws CloneNotSupportedException {

		EEMBillingInvMasterVO initialMasterVO = initializeMasterVO();
		EEMBillingInvHeaderDtlsVO dispInvHdr = billInvoiceDetailsUpdateVO.getBillHeaderVO();
		EEMBillingInvoiceDtlsVO dispInvDtl = billInvoiceDetailsUpdateVO.getBillInvVO();
		dispInvDtl.setCustomerId(dispInvHdr.getCustomerId());
		dispInvDtl.setInvoiceNbr(dispInvHdr.getInvoiceNbr());

		String userId = sessionHelper.getUserInfo().getUserId();
		String ts = DateUtil.getCurrentDatetimeStamp();

		// Check for WIP User
		if (!isEligibleToUpdate(dispInvHdr, userId)) {
			throw new ApplicationException(
					String.format("Can only be updated by %s or a supervisor", dispInvHdr.getWipUserId()));
		}

		EEMBillingInvoiceDtlsVO wrkInvDetail = (EEMBillingInvoiceDtlsVO) dispInvDtl.clone();
		wrkInvDetail.setCreateUserId(userId);
		wrkInvDetail.setCreateTime(ts);
		wrkInvDetail.setLastUpdtUserId(userId);
		wrkInvDetail.setLastUpdtTime(ts);

		String adjustableAmount = EEMConstants.BLANK;
		boolean isValidNumberForProcessing = false;
		boolean isLisPaymentType = false;
		boolean isValidFunction = false;
		boolean isREFORNSF = false;
		boolean isNotValidAmountForRefundOrNSF = false;

		EEMBillingInvoiceDtlsVO comparisonInvDetail = getSelectedBillingInvDtls(sessionHelper.getEEMContext().getBillInvMasterVO(), dispInvDtl);

		if (Objects.nonNull(comparisonInvDetail)) {
			if (!StringUtils.equalsAnyIgnoreCase("LSC", wrkInvDetail.getSubProductId())) {
				String paySourceType = comparisonInvDetail.getPaySourceType();
				if ((StringUtils.equalsAnyIgnoreCase("NSF", wrkInvDetail.getFunctionCd())
						|| StringUtils.equalsIgnoreCase("REF", wrkInvDetail.getFunctionCd()))
						&& !StringUtils.equalsAnyIgnoreCase("W", paySourceType) && StringUtils.isNotBlank(paySourceType)
						&& !StringUtils.equalsAnyIgnoreCase("S", paySourceType)) {

					adjustableAmount = billingInvoiceDAO.getEligibleLineAmount(dispInvHdr.getCustomerId(),
							dispInvHdr.getInvoiceNbr(), String.valueOf(dispInvDtl.getItemNbr()));
					isValidNumberForProcessing = validateAmtForTransOrRefundWithHist(adjustableAmount,
							dispInvDtl.getDetailAmt());

					isValidFunction = true;
					isREFORNSF = true;
					double workInvoiceAmount = Double.parseDouble(dispInvDtl.getDetailAmt());

					if (workInvoiceAmount < 0) {
						isNotValidAmountForRefundOrNSF = true;
					}

				} else if ((StringUtils.equalsAnyIgnoreCase("MCR", wrkInvDetail.getFunctionCd())
						|| StringUtils.equalsAnyIgnoreCase("MDR", wrkInvDetail.getFunctionCd())
						|| StringUtils.equalsAnyIgnoreCase("WTO", wrkInvDetail.getFunctionCd()))
						&& StringUtils.isBlank(paySourceType) || StringUtils.equalsAnyIgnoreCase("M", paySourceType)
						|| StringUtils.equalsAnyIgnoreCase("A", paySourceType) || StringUtils.equalsAnyIgnoreCase("L", paySourceType)
						|| StringUtils.equalsAnyIgnoreCase("E", paySourceType) || StringUtils.equalsAnyIgnoreCase("C", paySourceType)) {

					if (StringUtils.equalsAnyIgnoreCase("WTO", wrkInvDetail.getFunctionCd())) {
						adjustableAmount = billingInvoiceDAO.getEligibleLineAmount(dispInvHdr.getCustomerId(),
								dispInvHdr.getInvoiceNbr(), String.valueOf(dispInvDtl.getItemNbr()));
						isValidNumberForProcessing = validateAmtForTransOrRefundWithHist(adjustableAmount,
								dispInvDtl.getDetailAmt());
					} else {
						isValidNumberForProcessing = validateNumberForDebitAndCreditAdjustment(
								dispInvDtl.getDetailAmt(), comparisonInvDetail.getDetailAmt(),
								wrkInvDetail.getFunctionCd());
					}
					isValidFunction = true;

				} else if (StringUtils.equalsIgnoreCase("RER", wrkInvDetail.getFunctionCd())
						&& StringUtils.equalsIgnoreCase("REF", comparisonInvDetail.getFunctionCd())) {
					isValidNumberForProcessing = validateNumberForOtherAdjustment(dispInvDtl.getDetailAmt(),
							comparisonInvDetail.getDetailAmt());
					isValidFunction = true;
				} else {
					isValidFunction = false;
				}

			} else {
				isLisPaymentType = true;
			}
			EEMBillFuncDO billFunc = codeCache.getBillFunction(wrkInvDetail.getCustomerId(),
					wrkInvDetail.getFunctionCd());
			if (Objects.isNull(billFunc)) {
				throw new ApplicationException("Billing Function Lookup Error");
			} else if (!isValidFunction || !isValidNumberForProcessing || isNotValidAmountForRefundOrNSF
					|| (StringUtils.equalsIgnoreCase("REF", wrkInvDetail.getFunctionCd())
							&& ((StringUtils.equalsIgnoreCase("S", comparisonInvDetail.getPaySourceType()))
									|| (StringUtils.isBlank(comparisonInvDetail.getPaySourceType()))))) {

				if (isLisPaymentType) {
					throw new ApplicationException("Adjustments are not allowed for LIS Payments");
				} else if (!isValidFunction) {
					throw new ApplicationException("Invalid Adjustment");
				} else if (!isValidNumberForProcessing) {
					throw new ApplicationException("Invalid Transaction amount for this line item");
				} else if (isREFORNSF && isNotValidAmountForRefundOrNSF) {
					throw new ApplicationException("NSF and Refund adjustments value cannot be Negative");
				}

			} else {
				String fetchBCIndicator = eemProfileSettings.getCalendarProfileItem(
						sessionHelper.getUserInfo().getCustomerId(), EEMProfileConstants.BANKCDTB);
				boolean rslt;

				if (StringUtils.equalsIgnoreCase(EEMConstants.VALUE_YES, fetchBCIndicator)) {
					if (StringUtils.equalsIgnoreCase("MCR", wrkInvDetail.getFunctionCd())
							|| StringUtils.equalsIgnoreCase("MDR", wrkInvDetail.getFunctionCd())
							|| StringUtils.equalsIgnoreCase("WTO", wrkInvDetail.getFunctionCd())) {
						rslt = true;
					} else {
						rslt = codeCache.validateGlBankAcctCdForMMO(wrkInvDetail.getCustomerId(),
								wrkInvDetail.getBankAcctCd(), dispInvHdr.getBillThruDate());
					}
				} else {
					String multiORG = eemProfileSettings.getCalendarProfileItem(
							sessionHelper.getUserInfo().getCustomerId(), EEMProfileConstants.MULTIORG);
					if (StringUtils.equalsIgnoreCase(EEMConstants.VALUE_YES, multiORG)) {
						String planId = billingInvoiceDAO.getPlanId(wrkInvDetail.getCustomerId(),
								billInvoiceDetailsUpdateVO.getMemberId());
						rslt = codeCache.validateGlBankAcctCdForPlanId(wrkInvDetail.getCustomerId(),
								wrkInvDetail.getBankAcctCd(), dispInvHdr.getBillThruDate(), planId);
					} else {
						rslt = codeCache.validateGlBankAcctCd(wrkInvDetail.getCustomerId(),
								wrkInvDetail.getBankAcctCd(), dispInvHdr.getBillThruDate());
					}
				}

				if (!rslt) {
					throw new ApplicationException("Invalid Bank Account Cd");
				} else {
					synchronized(this) {

						int itemNbr = -1;
						int nbr = -1;

						if (StringUtils.equals("H", billFunc.getHdrDtlTranInd())) {
							nbr = billingInvoiceDAO.getNextItemNbr(wrkInvDetail.getCustomerId(),
									wrkInvDetail.getInvoiceNbr());
							if (nbr == -1) {
								throw new ApplicationException("Error Getting Item Number");
							} else {
								itemNbr = nbr;
								wrkInvDetail.setItemNbr(nbr);
								wrkInvDetail.setAddNbr(0);
							}
						} else {
							nbr = billingInvoiceDAO.getNextAddNbr(wrkInvDetail.getCustomerId(),
									wrkInvDetail.getInvoiceNbr(), wrkInvDetail.getItemNbr());
							if (nbr == -1) {
								throw new ApplicationException("Error Getting Adjustment Number");
							} else {
								wrkInvDetail.setAddNbr(nbr);
							}
						}
						if (nbr != -1) {
							wrkInvDetail.setLineStatus("A");
							wrkInvDetail.setItemDesc(billFunc.getShortDesc());
							wrkInvDetail.setPayBatchDate(EEMConstants.BLANK);
							wrkInvDetail.setPayBatchSeqNbr(EEMConstants.BLANK);
							wrkInvDetail.setPayItemNbr(EEMConstants.BLANK);

							if (StringUtils.isNotBlank(dispInvDtl.getPaySourceDesc())
									&& StringUtils.isNotBlank(dispInvDtl.getPayBatchDate())
									&& StringUtils.isNotBlank(dispInvDtl.getPayBatchSeqNbr())
									&& StringUtils.isNotBlank(dispInvDtl.getPayItemNbr())
									&& StringUtils.equalsIgnoreCase("PAY", comparisonInvDetail.getFunctionCd())) {

								wrkInvDetail.setPaySourceDesc(dispInvDtl.getPaySourceDesc());
								wrkInvDetail.setPayBatchDate(dispInvDtl.getPayBatchDate());
								wrkInvDetail.setPayBatchSeqNbr(dispInvDtl.getPayBatchSeqNbr());
								wrkInvDetail.setPayItemNbr(dispInvDtl.getPayItemNbr());
							}

							if (Objects.isNull(wrkInvDetail.getCheckNbr())) {
								wrkInvDetail.setCheckNbr(EEMConstants.BLANK);
							}

							if (Objects.isNull(wrkInvDetail.getReasonCdDesc())) {
								wrkInvDetail.setReasonCdDesc(EEMConstants.BLANK);
							}

							int cnt = billingInvoiceDAO.insertBillInvoiceDetail(wrkInvDetail);
							if ("PAY".equalsIgnoreCase(comparisonInvDetail.getFunctionCd()) && cnt == 1) {
								cnt = billingInvoiceDAO.insertBillPaymentDtlInvoice(wrkInvDetail);
							}

							if (cnt == 1) {
								cnt = billingInvoiceDAO.updateBillInvoiceHeader(wrkInvDetail, itemNbr,
										dispInvHdr.getInvoiceStatus());

								if (cnt == 1) {
									saveBillInvoiceComment(billInvoiceDetailsUpdateVO.getBillInvCommentVO());
									EEMBillingInvMasterVO masterVO = searchSelectBillingInvoice(dispInvHdr);
									setBillFunCodeList(masterVO, dispInvHdr, dispInvDtl.getBankAcctCd());
									LOG.info("Billing Invoice updated successfully..");
									return masterVO;
								}
								throw new ApplicationException("Invoice Header Update Failed.");
							} else {
								LOG.error("Error in updateBillInvoiceDetails, count:: {}", cnt);
								throw new ApplicationException("Invoice Details Update Failed.");
							}
						}
					}
				}
			} 
		} else {
			LOG.error("selected invoice details not found in session");
			throw new ApplicationException("unable to process adjustment!");
		}
		return initialMasterVO;
	}

	public String getTotalInvoiceDetailAmt(EEMBillingInvoiceDtlsVO billInvVO) {
		return billingInvoiceDAO.getEligibleLineAmount(billInvVO.getCustomerId(), billInvVO.getInvoiceNbr(),
				String.valueOf(billInvVO.getItemNbr()));
	}

	private boolean validateAmtForTransOrRefundWithoutHist(String adjustableAmount, String transAmt) {
		return validateAmtForTransOrRefundWithHist(adjustableAmount, transAmt);
	}

	private boolean checkExistingAdjustmentsForLineItem(EEMBillingInvHeaderDtlsVO headerVO,
			EEMBillingInvoiceDtlsVO detailVO) {
		String invoiceNumber = headerVO.getInvoiceNbr();
		String itemNumber = String.valueOf(detailVO.getItemNbr());
		int existingRecords = billingInvoiceDAO.getRecordsCount(detailVO.getCustomerId(), invoiceNumber, itemNumber);
		return existingRecords > 1;
	}

	private boolean validateAmtForTransOrRefundWithHist(String adjustableAmount, String transferAmount) {
		double adjAmount = Double.parseDouble(adjustableAmount);
		double transAmount = Double.parseDouble(transferAmount);
		return validateAmountsWithSigns(adjAmount, transAmount);
	}

	private boolean validateAmountsWithSigns(double adjAmount, double transAmount) {

		if (adjAmount < 0 && Math.abs(transAmount) <= Math.abs(adjAmount)) {
			return true;
		} else {
			return adjAmount > 0 && Math.abs(transAmount) <= adjAmount;
		}
	}

	private String hasValidTransferInput(EEMBillingInvTransferVO billingInvTransferVO, String customerId) {

		String transGrpId = StringUtils.trimToEmpty(billingInvTransferVO.getTransGrpId());
		String transAmt = StringUtils.trimToEmpty(billingInvTransferVO.getTransAmt());
		if (StringUtils.isBlank(transGrpId)) {
			return "Invalid Member/Group Id";
		} else if (StringUtils.isBlank(transAmt) || Double.parseDouble(transAmt) <= 0) {
			return "Invalid transfer Amount";
		} else {
			List<EEMBillingInvoiceDtlsVO> billInvDtlsVOs = fetchBillMbrGrp(customerId, transGrpId, EEMConstants.BLANK,
					EEMConstants.BLANK);

			if (!CollectionUtils.isEmpty(billInvDtlsVOs)) {
				billingInvTransferVO.setTransName((billInvDtlsVOs.get(0)).getGroupName());
			} else {
				return "Invalid Member/Group Id";
			}
		}
		return EEMConstants.BLANK;
	}

	public List<EEMBillingInvoiceDtlsVO> searchBillMbrGrp(BillingMbrGrpSearchVO billingMbrGrpSearchVO) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		return fetchBillMbrGrp(customerId, billingMbrGrpSearchVO.getSearchTransGrp(),
				billingMbrGrpSearchVO.getSearchTransName(), billingMbrGrpSearchVO.getSearchTransLastName());
	}

	private List<EEMBillingInvoiceDtlsVO> fetchBillMbrGrp(String customerId, String searchTransGrp,
			String searchTransName, String searchTransLastName) {
		List<EEMBillingInvoiceDtlsDO> billInvDtlsDOs = billingInvoiceDAO.getBillMbrGrpList(customerId, searchTransGrp,
				searchTransName, searchTransLastName);

		List<EEMBillingInvoiceDtlsVO> billInvDtlsVOs = new ArrayList<>();
		CommonUtils.copyList(billInvDtlsDOs, billInvDtlsVOs, EEMBillingInvoiceDtlsVO.class);
		return billInvDtlsVOs;
	}

	private void populateBillingInvMasterVO(EEMBillingInvMasterVO masterVO,
			EEMBillingInvHeaderDtlsVO billingInvHeaderDtlsVO) {
		
		//setting billing invoice summary
		setBillingInvSummary(masterVO, billingInvHeaderDtlsVO);
		
		//setting billing invoice details
		setBillingInvDetails(masterVO, billingInvHeaderDtlsVO);
		
		//setting func codes and ref reason codes
		EEMBillingInvoiceDtlsVO dispInvDtlsVO = masterVO.getBillingInvDetails().get(0);
		setOtherDetails(masterVO, billingInvHeaderDtlsVO, dispInvDtlsVO.getMemberId(),
				dispInvDtlsVO.getCustomerId(), dispInvDtlsVO.getInvoiceNbr());
		
		//setting billing invoice comment
		setBillingInvoiveComment(masterVO, billingInvHeaderDtlsVO.getCustomerId(),
				billingInvHeaderDtlsVO.getInvoiceNbr());
	}

	private void setBillingInvSummary(EEMBillingInvMasterVO masterVO,
			EEMBillingInvHeaderDtlsVO billingInvHeaderDtlsVO) {
		EEMBillingInvSummaryVO selectedBillingInvSummary = fetchSelectedBillingInvSummary(billingInvHeaderDtlsVO);
		masterVO.setBillingInvSummary(selectedBillingInvSummary);
	}

	private void setBillingInvoiveComment(EEMBillingInvMasterVO masterVO, String custId, String invNbr) {

		List<EEMBillingInvCommentDO> commentsDOList = billingInvoiceDAO.getBillInvoiceComments(custId, invNbr);

		List<EEMBillingInvCommentVO> commentsVOList = masterVO.getCommentList();
		CommonUtils.copyList(commentsDOList, commentsVOList, EEMBillingInvCommentVO.class);
	}

	private void setOtherDetails(EEMBillingInvMasterVO masterVO, EEMBillingInvHeaderDtlsVO dispInvHdr,
			String mbrId, String custId, String invNbr) {

		String planId = billingInvoiceDAO.getPlanId(custId, mbrId);
		String billThruDate = billingInvoiceDAO.getBillThruDt(custId, invNbr);

		String detBankCd = codeCache.getBankAcctCd(custId, "M", planId, billThruDate);
		setBillFunCodeList(masterVO, dispInvHdr, detBankCd);

		List<LabelValuePair> billRefReasonList = eemPersistence.getBillRefReasonList();
		masterVO.setLstRefReasonCode(billRefReasonList);
	}

	private void setBillFunCodeList(EEMBillingInvMasterVO masterVO, EEMBillingInvHeaderDtlsVO dispInvHdr,
			String detBankCd) {
		List<EEMBillFuncDO> billFuncDOList = codeCache.getBillFuncList(dispInvHdr.getCustomerId(), "U", detBankCd);
		List<EEMBillFuncVO> billFuncVOList = new ArrayList<>();
		CommonUtils.copyList(billFuncDOList, billFuncVOList, EEMBillFuncVO.class);
		masterVO.setLstFunctionCode(billFuncVOList);
	}

	private void setBillingInvDetails(EEMBillingInvMasterVO masterVO,
			EEMBillingInvHeaderDtlsVO eemBillingInvHeaderDtlsVO) {

		List<EEMBillingInvoiceDtlsDO> billInvoiceDetailDOs = billingInvoiceDAO.getBillInvoiceDetails(
				eemBillingInvHeaderDtlsVO.getCustomerId(), eemBillingInvHeaderDtlsVO.getInvoiceNbr(),
				eemBillingInvHeaderDtlsVO.getBillThruDate());

		for (EEMBillingInvoiceDtlsDO invoiceDtlsDO : billInvoiceDetailDOs) {
			EEMBillingInvoiceDtlsVO invoiceDtlsVO = new EEMBillingInvoiceDtlsVO();
			BeanUtils.copyProperties(invoiceDtlsDO, invoiceDtlsVO);

			// additional property setting
			invoiceDtlsVO.setDetailAmt(NumberFormatter.formatDecimal2PlacesDelim(invoiceDtlsDO.getDetailAmt()));
			invoiceDtlsVO.setCreateTime(DateFormatter.reFormat(invoiceDtlsDO.getCreateTime(),
					DateFormatter.DB2_TIMESTAMP, DateFormatter.DB2_TIMESTAMP));
			invoiceDtlsVO.setLastUpdtTime(DateFormatter.reFormat(invoiceDtlsDO.getLastUpdtTime(),
					DateFormatter.DB2_TIMESTAMP, DateFormatter.DB2_TIMESTAMP));
			invoiceDtlsVO.setLineStatusDesc(
					codeCache.getDesc(invoiceDtlsDO.getLineStatus(), eemPersistence.getLstLineStatus()));
			invoiceDtlsVO.setPaySourceDesc(StringUtils.trimToEmpty(
					codeCache.getDesc(invoiceDtlsDO.getPaySourceType(), eemPersistence.getLstPaySource())));

			if (invoiceDtlsVO.getXrefInvoiceNbr().equals("0"))
				invoiceDtlsVO.setXrefInvoiceNbr(EEMConstants.BLANK);
			if (invoiceDtlsVO.getPayBatchDate().equals("00000000"))
				invoiceDtlsVO.setPayBatchDate(EEMConstants.BLANK);
			if (invoiceDtlsVO.getPayBatchSeqNbr().equals("0"))
				invoiceDtlsVO.setPayBatchSeqNbr(EEMConstants.BLANK);
			if (invoiceDtlsVO.getPayItemNbr().equals("0"))
				invoiceDtlsVO.setPayItemNbr(EEMConstants.BLANK);

			if (invoiceDtlsVO.getPaySourceDesc().equals(EEMConstants.BLANK))
				invoiceDtlsVO.setPaySourceDesc(invoiceDtlsDO.getPaySourceType());
			if (invoiceDtlsVO.getGroupName().equals(EEMConstants.BLANK))
				invoiceDtlsVO.setGroupName(invoiceDtlsDO.getGrpId());
			if (invoiceDtlsVO.getProductName().equals(EEMConstants.BLANK))
				invoiceDtlsVO.setProductName(invoiceDtlsDO.getProductId());
			if (invoiceDtlsVO.getSubProductDesc().equals(EEMConstants.BLANK))
				invoiceDtlsVO.setSubProductDesc(invoiceDtlsDO.getSubProductId());

			invoiceDtlsVO.setItemAddNbr(new StringBuilder(String.valueOf(invoiceDtlsVO.getItemNbr())).append("-")
					.append(String.valueOf(invoiceDtlsVO.getAddNbr())).toString());
			invoiceDtlsVO.setDispFunctionCdDesc(new StringBuilder(invoiceDtlsVO.getFunctionCd()).append("-")
					.append(invoiceDtlsVO.getFunctionCdDesc()).toString());

			masterVO.getBillingInvDetails().add(invoiceDtlsVO);
		}
	}

	private EEMBillingInvSummaryVO fetchSelectedBillingInvSummary(EEMBillingInvHeaderDtlsVO billingInvHeaderDtlsVO) {

		EEMBillingInvSummaryVO summaryVO = billingInvoiceDAO.getInvSummary(billingInvHeaderDtlsVO.getCustomerId(),
				billingInvHeaderDtlsVO.getInvoiceId());
		summaryVO.setMemberId(billingInvHeaderDtlsVO.getInvoiceId());
		summaryVO.setHicNbr(billingInvHeaderDtlsVO.getHicNbr());
		summaryVO.setLastName(billingInvHeaderDtlsVO.getLastName());
		summaryVO.setFirstName(billingInvHeaderDtlsVO.getFirstName());
		summaryVO.setName(new StringBuilder(billingInvHeaderDtlsVO.getFirstName()).append(" ")
				.append(billingInvHeaderDtlsVO.getLastName()).toString());

		return summaryVO;
	}

	private void copyBillingInvHdrDtlsDOsToVOs(List<EEMBillingInvHeaderDtlsDO> eemBillingInvHeaderDtlsDOList,
			EEMBillingInvoiceSearchVO searchVO, EEMBillingInvMasterVO masterVO) {

		for (EEMBillingInvHeaderDtlsDO billingInvHeaderDtlsDO : eemBillingInvHeaderDtlsDOList) {
			EEMBillingInvHeaderDtlsVO billingInvHeaderDtlsVO = new EEMBillingInvHeaderDtlsVO();
			BeanUtils.copyProperties(billingInvHeaderDtlsDO, billingInvHeaderDtlsVO);

			// additional property setting
			setAdditionalPropsToHdrDtlsVO(searchVO.getSearchInvoiceGroup(), billingInvHeaderDtlsDO,
					billingInvHeaderDtlsVO);
			masterVO.getBillingInvHeaderDtlsVOs().add(billingInvHeaderDtlsVO);
		}
	}
	
	private void copyBillingInvHdrDtlsDOsToVOs(List<EEMBillingInvHeaderDtlsDO> eemBillingInvHeaderDtlsDOs,
			List<EEMBillingInvHeaderDtlsVO> eemBillingInvHeaderDtlsVOs, EEMBillingInvoiceSearchVO searchVO) {

		for (EEMBillingInvHeaderDtlsDO billingInvHeaderDtlsDO : eemBillingInvHeaderDtlsDOs) {
			EEMBillingInvHeaderDtlsVO billingInvHeaderDtlsVO = new EEMBillingInvHeaderDtlsVO();
			BeanUtils.copyProperties(billingInvHeaderDtlsDO, billingInvHeaderDtlsVO);

			// additional property setting
			setAdditionalPropsToHdrDtlsVO(searchVO.getSearchInvoiceGroup(), billingInvHeaderDtlsDO,
					billingInvHeaderDtlsVO);
			eemBillingInvHeaderDtlsVOs.add(billingInvHeaderDtlsVO);
		}
	}

	private void setAdditionalPropsToHdrDtlsVO(String searchInvoiceGroup,
			EEMBillingInvHeaderDtlsDO billingInvHeaderDtlsDO, EEMBillingInvHeaderDtlsVO billingInvHeaderDtlsVO) {
		billingInvHeaderDtlsVO.setInvoiceTypeDesc(
				codeCache.getCode(billingInvHeaderDtlsVO.getInvoiceType(), eemPersistence.getSearchLstInvoiceType()));

		if (StringUtils.equals(searchInvoiceGroup, "G")) {
			billingInvHeaderDtlsVO.setLastName(StringUtils.trimToEmpty(billingInvHeaderDtlsDO.getGrpName()));
			billingInvHeaderDtlsVO.setFirstName(EEMConstants.BLANK);
			billingInvHeaderDtlsVO.setHicNbr(EEMConstants.BLANK);

		} else {
			billingInvHeaderDtlsVO.setLastName(StringUtils.trimToEmpty(billingInvHeaderDtlsDO.getLastName()));
			billingInvHeaderDtlsVO.setFirstName(StringUtils.trimToEmpty(billingInvHeaderDtlsDO.getFirstName()));
		}

		billingInvHeaderDtlsVO.setMbrGrpDesc(
				codeCache.getDesc(billingInvHeaderDtlsVO.getMbrGrpInd(), eemPersistence.getLstMemberGroup()));
		billingInvHeaderDtlsVO.setInvoiceStatusDesc(
				codeCache.getDesc(billingInvHeaderDtlsVO.getInvoiceStatus(), eemPersistence.getLstInvoiceStatus()));
		billingInvHeaderDtlsVO.setFrequencyDesc(
				codeCache.getDesc(billingInvHeaderDtlsVO.getFrequencyCd(), eemPersistence.getLstFrequencyCodes()));

		billingInvHeaderDtlsVO
				.setInvoiceAmt(NumberFormatter.formatDecimal2PlacesDelim(billingInvHeaderDtlsDO.getInvoiceAmt()));
		billingInvHeaderDtlsVO
				.setPaymentAmt(NumberFormatter.formatDecimal2PlacesDelim(billingInvHeaderDtlsDO.getPaymentAmt()));
		billingInvHeaderDtlsVO
				.setAdjustmentAmt(NumberFormatter.formatDecimal2PlacesDelim(billingInvHeaderDtlsDO.getAdjustmentAmt()));

		double totalDueAmt = calculateTotalDueAmt(billingInvHeaderDtlsVO.getInvoiceAmt(),
				billingInvHeaderDtlsVO.getAdjustmentAmt(), billingInvHeaderDtlsVO.getPaymentAmt());
		billingInvHeaderDtlsVO.setTotalAmt(NumberFormatter.formatDecimal2Places(totalDueAmt));

		String wipTime = getWipTime(billingInvHeaderDtlsVO.getWipTime());
		if (StringUtils.equals(wipTime, DEFAULT_WIP_TIME)) {
			billingInvHeaderDtlsVO.setWipTime(EEMConstants.BLANK);
		}

		String medicareId = billingInvoiceDAO.getMedicareIdFromDSInfo(
				billingInvHeaderDtlsVO.getCustomerId().toUpperCase(),
				billingInvHeaderDtlsVO.getInvoiceId().toUpperCase(), "MBI");

		if (Objects.isNull(medicareId)) {
			medicareId = billingInvoiceDAO.getMedicareIdFromDSInfo(billingInvHeaderDtlsVO.getCustomerId().toUpperCase(),
					billingInvHeaderDtlsVO.getInvoiceId().toUpperCase(), "MED");
		}

		billingInvHeaderDtlsVO.setHicNbr(medicareId);
		billingInvHeaderDtlsVO.setName(new StringBuilder(billingInvHeaderDtlsVO.getLastName()).append(", ")
				.append(billingInvHeaderDtlsVO.getFirstName()).toString());
		billingInvHeaderDtlsVO.setDisplayInvType(new StringBuilder(billingInvHeaderDtlsVO.getInvoiceType()).append("-")
				.append(billingInvHeaderDtlsVO.getInvoiceTypeDesc()).toString());
	}

	private String getWipTime(String dbWipTime) {
		StringBuilder wipTime = new StringBuilder(dbWipTime);
		int totalMillis = 6;

		if (StringUtils.isNotBlank(dbWipTime) && dbWipTime.lastIndexOf('.') != -1) {
			String millis = dbWipTime.substring(dbWipTime.lastIndexOf('.') + 1);
			int count = totalMillis - millis.length();

			for (int i = 0; i < count; i++) {
				wipTime.append('0');
			}
		}
		return wipTime.toString();
	}

	private double calculateTotalDueAmt(String invoiceAmt, String adjustmentAmt, String paymentAmt) {
		return Double.parseDouble(invoiceAmt) + Double.parseDouble(adjustmentAmt) + Double.parseDouble(paymentAmt);
	}

	private boolean isEligibleToUpdate(EEMBillingInvHeaderDtlsVO headerVO, String userId) {
		boolean flag = true;
		String wipUser = headerVO.getWipUserId();
		if (StringUtils.isNotBlank(wipUser)
				&& (!sessionHelper.isEEMSupervisor() && !StringUtils.equals(userId, wipUser))) {
			flag = false;
		}
		return flag;
	}

	private boolean validateNumberForDebitAndCreditAdjustment(String valueToBeCompared, String valueLimit,
			String functionCode) {
		double valueToBeComparedD = Double.parseDouble(valueToBeCompared);
		double valueLimitD = Double.parseDouble(valueLimit);
		if (StringUtils.equalsIgnoreCase("MCR", functionCode)) {
			return valueLimitD > 0 && Math.abs(valueToBeComparedD) <= valueLimitD;
		} else if (StringUtils.equalsIgnoreCase("MDR", functionCode)) {
			return valueLimitD < 0 && valueToBeComparedD <= Math.abs(valueLimitD);
		} else {
			return true;
		}
	}

	private boolean validateNumberForOtherAdjustment(String valueToBeCompared, String valueLimit) {
		double valueToBeComparedD = Double.parseDouble(valueToBeCompared);
		double valueLimitD = Double.parseDouble(valueLimit);

		if (valueLimitD < 0) {
			if (valueToBeComparedD < 0) {
				return Math.abs(valueToBeComparedD) <= valueLimitD;
			} else {
				return valueToBeComparedD <= Math.abs(valueLimitD);
			}
		} else {
			if (valueToBeComparedD < 0) {
				return Math.abs(valueToBeComparedD) <= valueLimitD;

			} else {
				return false;
			}
		}
	}

	public EEMBillingCacheVO getBillingCacheData() {
		EEMBillingCacheVO billingCacheVO = new EEMBillingCacheVO();

		// setting invoice cache
		billingCacheVO.setLstInvoiceStatus(eemPersistence.getLstInvoiceStatus());
		billingCacheVO.setLstInvoiceGroup(eemPersistence.getLstInvoiceGroup());
		billingCacheVO.setLstInvoiceType(eemPersistence.getLstRelatedInvoiceType().get("M"));
		billingCacheVO.setLstRelatedInvoiceType(eemPersistence.getLstRelatedInvoiceType());

		// setting payment entry and member payment cache
		billingCacheVO.setPayTypesList(codeCache.getLstPaySource());

		// setting draft cache
		billingCacheVO.setDraftStatusLst(codeCache.getLstDraftStatus());

		// setting payment entry cache
		billingCacheVO.setBankAcctCd(codeCache.getBankAcctCd(sessionHelper.getUserInfo().getCustomerId(),
				EEMConstants.BILL_PAYSOURCE_MANUAL));

		return billingCacheVO;
	}

	private EEMBillingInvMasterVO initializeMasterVO() {
		EEMBillingInvMasterVO masterVO = new EEMBillingInvMasterVO();
		masterVO.setBillingInvHeaderDtlsVOs(new ArrayList<EEMBillingInvHeaderDtlsVO>());
		masterVO.setBillingInvDetails(new ArrayList<EEMBillingInvoiceDtlsVO>());
		masterVO.setLstFunctionCode(new ArrayList<EEMBillFuncVO>());
		masterVO.setLstRefReasonCode(new ArrayList<LabelValuePair>());
		masterVO.setCommentList(new ArrayList<EEMBillingInvCommentVO>());
		return masterVO;
	}
	
	private void setToContext(EEMBillingInvMasterVO masterVO) {
		EEMContext context = sessionHelper.getEEMContext();
		context.setBillInvMasterVO(masterVO);
		sessionHelper.setEEMContext(context);
	}
	
	private EEMBillingInvoiceDtlsVO getSelectedBillingInvDtls(EEMBillingInvMasterVO billInvMasterVO, EEMBillingInvoiceDtlsVO dispInvDtl) {
		EEMBillingInvoiceDtlsVO selectedBillInvVO = null;
		String custId = sessionHelper.getUserInfo().getCustomerId();
		for (EEMBillingInvoiceDtlsVO billInvVO : billInvMasterVO.getBillingInvDetails()) {
			if (StringUtils.equals(custId, billInvVO.getCustomerId())
					&& StringUtils.equals(dispInvDtl.getInvoiceNbr(), billInvVO.getInvoiceNbr())
					&& dispInvDtl.getItemNbr() == billInvVO.getItemNbr()
					&& dispInvDtl.getAddNbr() == billInvVO.getAddNbr()) {
				selectedBillInvVO = billInvVO;
				break;
			}
		}
		return selectedBillInvVO;

	}
	
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public PageableVO getBillingInvPagination(EEMBillingInvoiceSearchVO searchVO) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		PageableVO pagableResult = billingInvoiceDAO.searchBillingInvoice(searchVO, customerId, true);
		List<EEMBillingInvHeaderDtlsDO> billingInvHeaderDtlsDOs = (List<EEMBillingInvHeaderDtlsDO>) pagableResult.getContent();
		List<EEMBillingInvHeaderDtlsVO> billingInvHeaderDtlsVOs = new ArrayList<>();
		copyBillingInvHdrDtlsDOsToVOs(billingInvHeaderDtlsDOs, billingInvHeaderDtlsVOs, searchVO);
		pagableResult.setContent(billingInvHeaderDtlsVOs);
		return pagableResult;
	}

}
