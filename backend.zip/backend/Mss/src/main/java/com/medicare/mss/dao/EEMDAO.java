package com.medicare.mss.dao;

import com.medicare.mss.exception.ApplicationException;

public interface EEMDAO {

	int getNextSeqNo(String mfId, String type) throws ApplicationException;

}
