package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class MBDNunCmoDO {

	@ColumnMapper(columnName = "START_DATE", propertyName = "nunCmoStartDate")
	private String nunCmoStartDate;

	@ColumnMapper(columnName = "NBR_UNCOV_MONTHS", propertyName = "nunCmoNbrUnCovMths")
	private String nunCmoNbrUnCovMths;

	@ColumnMapper(columnName = "NUNCMO_IND", propertyName = "nunCmoIndicator")
	private String nunCmoIndicator;

	@ColumnMapper(columnName = "TOT_NUNCMO", propertyName = "totNbrUnCovMths")
	private String totNbrUnCovMths;

	private String profileLastUpdt;

}
