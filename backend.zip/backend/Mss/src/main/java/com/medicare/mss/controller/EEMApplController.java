package com.medicare.mss.controller;

import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.service.EEMApplMemberCheckService;
import com.medicare.mss.service.EEMApplService;
import com.medicare.mss.service.EEMApplValidationService;
import com.medicare.mss.service.EEMOrigApplService;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.vo.ApplCacheVO;
import com.medicare.mss.vo.EEMApplCancelRequestVO;
import com.medicare.mss.vo.EEMApplCommentsVO;
import com.medicare.mss.vo.EEMApplMasterVO;
import com.medicare.mss.vo.EEMApplStatusTrackVO;
import com.medicare.mss.vo.EEMApplicationVO;
import com.medicare.mss.vo.EEMLtcFacilityVO;
import com.medicare.mss.vo.EmPreSetNoteVO;
import com.medicare.mss.vo.MBD;
import com.medicare.mss.vo.PageableVO;

/**
 * This class is Controller for Application Functionality.
 * 
 * @author Wipro
 *
 */
@RestController
@RequestMapping("/appl")
public class EEMApplController {

	@Autowired
	private EEMApplService applicationService;

	@Autowired
	EEMApplValidationService applValidationService;

	@Autowired
	EEMOrigApplService origApplService;

	@Autowired
	EEMApplMemberCheckService applMemberCheckService;

	@PostMapping(path = ReqMappingConstants.APPL_SEARCH)
	public ResponseEntity<JSONResponse> getApplSearchDetails(@RequestBody Map<String, String> searchParamMap) {

		EEMApplMasterVO applMasterVO = applicationService.getApplSearchDetails(searchParamMap);

		return sendResponse(applMasterVO);
	}
	
	@PostMapping(path = ReqMappingConstants.APPL_SEARCH_NEXT)
	public ResponseEntity<JSONResponse> getApplPaginationNext(@RequestBody Map<String, String> searchParamMap) {

		PageableVO pageVo = applicationService.getApplPagination(searchParamMap);

		return sendResponse(pageVo);
	}

	@GetMapping(path = ReqMappingConstants.APPL_SEARCH_SELECT)
	public ResponseEntity<JSONResponse> getApplSearchSelect(@PathVariable("applId") String applId) {

		EEMApplMasterVO applMasterVO = applicationService.getApplSearchSelect(applId);

		return sendResponse(applMasterVO);
	}

	@PostMapping(path = ReqMappingConstants.ELIG_SEARCH)
	public ResponseEntity<JSONResponse> getEligDetails(@RequestBody Map<String, String> searchParamMap) {

		MBD mbd = applicationService.getEligibilityDetails(searchParamMap);

		return sendResponse(mbd);
	}

	@PostMapping(path = ReqMappingConstants.APPL_VALIDATE)
	public ResponseEntity<JSONResponse> validateApplication(@RequestBody EEMApplMasterVO eemApplMasterVO) {

		eemApplMasterVO = applValidationService.validateApplication(eemApplMasterVO);
		EEMApplicationVO eemApplicationVO = eemApplMasterVO.getApplVO();
		String applicationStatus = trimToEmpty(eemApplicationVO.getApplStatus());
		String eligibilitySrcTable = trimToEmpty(eemApplicationVO.getEligibilitySrcTable());

		if (EEMConstants.APPL_STATUS_READYAPPR.equals(applicationStatus)
				&& eligibilitySrcTable.equals(EEMConstants.EM_TABLE_BEQ)) {
			eemApplicationVO.setApplStatus(EEMConstants.APPL_STATUS_BEQAPPR);
		} else if (EEMConstants.APPL_STATUS_BEQAPPR.equals(applicationStatus)
				&& eligibilitySrcTable.equals(EEMConstants.EM_TABLE_MBD)) {
			eemApplicationVO.setApplStatus(EEMConstants.APPL_STATUS_READYAPPR);
		}
		return sendResponse(eemApplMasterVO);
	}

	@PostMapping(path = ReqMappingConstants.APPL_CANCEL)
	public ResponseEntity<JSONResponse> getApplCancel(@RequestBody EEMApplCancelRequestVO applCanReq) {

		applicationService.eemApplCancellation(applCanReq);
		EEMApplMasterVO applMasterVO = applicationService.getApplSearchSelect(Integer.toString(applCanReq.getApplId()));
		return sendResponse(applMasterVO);
	}

	@PostMapping(path = ReqMappingConstants.APPL_ORIG_SEARCH)
	public ResponseEntity<JSONResponse> getOrigAppl(@RequestBody Map<String, String> searchParamMap) {

		EEMApplMasterVO origApplMasterVO = origApplService.getOrigAppldetails(searchParamMap);

		return sendResponse(origApplMasterVO);
	}

	@PostMapping(path = ReqMappingConstants.APPL_UPDATE)
	public ResponseEntity<JSONResponse> applUpdate(@RequestBody EEMApplMasterVO eemApplMasterVO) {

		eemApplMasterVO = applicationService.getApplUpdate(eemApplMasterVO);

		return sendResponse(eemApplMasterVO);
	}

	@PostMapping(path = ReqMappingConstants.APPL_MEMBER_CHECK)
	public ResponseEntity<JSONResponse> eemApplMemberCheck(@RequestBody EEMApplMasterVO eemApplMasterVO) {

		eemApplMasterVO = applMemberCheckService.getMemberDetails(eemApplMasterVO);

		return sendResponse(eemApplMasterVO);
	}

	@PostMapping(path = ReqMappingConstants.UPDT_APPL_COMMENTS)
	public ResponseEntity<JSONResponse> updateApplComments(@RequestBody List<EEMApplCommentsVO> applCommentsVOList) {
		Boolean flag = false;
		if (CommonUtils.isNotEmpty(applCommentsVOList)) {
			flag = applicationService.updateApplComments(applCommentsVOList,
					applCommentsVOList.get(0).getApplicationId());
		}
		return sendResponse(flag);
	}

	@PostMapping(path = ReqMappingConstants.ADD_PRESETNOTES)
	public ResponseEntity<JSONResponse> addPreSetNote(@RequestBody EmPreSetNoteVO emPreSetNoteVO) {

		JSONResponse jsonResponse = new JSONResponse();
		Boolean flag = applicationService.addorUpdatePreSetNote(emPreSetNoteVO);
		if (flag) {
			List<LabelValuePair> presetNoteList = applicationService.getPreSetNoteList(emPreSetNoteVO);
			jsonResponse.setMessage(EEMConstants.SUCCESS);
			jsonResponse.setStatus("OK");
			jsonResponse.setData(presetNoteList);
		} else {
			jsonResponse.setStatus(EEMConstants.FAILURE);
			jsonResponse.setData(null);
		}
		return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
	}

	@GetMapping(path = ReqMappingConstants.APPL_INITIAL)
	public ResponseEntity<JSONResponse> getApplInitailData() {

		ApplCacheVO applCacheVO = applicationService.getApplInitialData();

		return sendResponse(applCacheVO);
	}

	@PostMapping(path = ReqMappingConstants.GET_COUNTY)
	public ResponseEntity<JSONResponse> getCountyList(@RequestBody Map<String, String> searchParamMap) {

		List<LabelValuePair> data = applicationService.getCountyList(searchParamMap);

		return sendResponse(data);
	}

	@PostMapping(ReqMappingConstants.GET_CITY_COUNTY_STATE)
	public ResponseEntity<JSONResponse> populateCountyCityState(@RequestBody Map<String, String> searchParamMap) {

		String perZip5 = trimToEmpty(searchParamMap.get("perZip5"));
		String perZip4 = trimToEmpty(searchParamMap.get("perZip4"));

		Map<String, Object> data = applicationService.populateCountyCityState(perZip5, perZip4);

		return sendResponse(data);
	}

	@PostMapping(ReqMappingConstants.GET_CITIES)
	public ResponseEntity<JSONResponse> getCities(@RequestBody Map<String, String> searchParamMap) {

		String perZip5 = trimToEmpty(searchParamMap.get("perZip5"));
		String county = trimToEmpty(searchParamMap.get("county"));

		List<LabelValuePair> data = applicationService.getCities(perZip5, county);

		return sendResponse(data);
	}

	@GetMapping(ReqMappingConstants.APPL_STATUS_TRACK)
	public ResponseEntity<JSONResponse> letterReviewQCsearchDescription(
			@PathVariable(name = "applId") String applicationId) {

		List<EEMApplStatusTrackVO> applStatusTrackVOList = applicationService.applicationStatusTrack(applicationId);

		return sendResponse(applStatusTrackVOList);
	}

	@PostMapping(ReqMappingConstants.APPL_INST_DTLS)
	public ResponseEntity<JSONResponse> getInstDetails(@RequestBody Map<String, String> searchParamMap) {

		String instId = trimToEmpty(searchParamMap.get("nameInstitute"));
		String dateOfCov = trimToEmpty(searchParamMap.get("reqDtCov"));

		EEMLtcFacilityVO eemLtcFacilityVO = applicationService.getLtcDetails(instId, dateOfCov);

		return sendResponse(eemLtcFacilityVO);
	}

	private ResponseEntity<JSONResponse> sendResponse(Object object) {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;
		jsonResponse.setData(object);
		if (null == object) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
			jsonResponse.setMessage(EEMConstants.BLANK);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}

}
