package com.medicare.mss.util;

import java.io.Serializable;

import lombok.Data;

@Data
public class LabelValueKeyPair implements Serializable {

	private static final long serialVersionUID = -3007858655361034346L;
	
	private String label;
	private String value;
	private String key;

	public LabelValueKeyPair() {

	}

	public LabelValueKeyPair(String value, String label, String key) {
		super();
		this.label = label;
		this.value = value;
		this.key = key;
	}

}