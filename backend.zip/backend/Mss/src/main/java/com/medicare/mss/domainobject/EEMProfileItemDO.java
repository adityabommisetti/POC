package com.medicare.mss.domainobject;

import java.io.Serializable;

import lombok.Data;

@Data
public class EEMProfileItemDO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8577220629792049259L;
	private String effStartDate;
	private String effEndDate;
	private String parmCd;
	private String parmIndValue;
	private String parmTextValue;
	private int parmNumberValue;
	private String parmDateValue;
	private String parmDesc;

}
