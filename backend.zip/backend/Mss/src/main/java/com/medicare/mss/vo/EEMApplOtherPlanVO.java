package com.medicare.mss.vo;

import lombok.Data;

@Data
public class EEMApplOtherPlanVO {
	
	
	private String currentPatientInd;
	private String lastUpdtTime;
	private String locationId;
	private String officeCategoryCd;
	private String officeCd;
	private String  pcpName;
	private String  premiumAmt;
	private String alternateOfficeCd;
	

}
