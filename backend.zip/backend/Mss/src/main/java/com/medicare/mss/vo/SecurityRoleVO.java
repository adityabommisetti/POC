package com.medicare.mss.vo;

import java.io.Serializable;

import lombok.Data;

@Data
public class SecurityRoleVO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4100309749365828833L;
	private String userId;
	private String groupId;
	private String groupName;
	private String serviceId;
	private String serviceName;

}
