package com.medicare.mss.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.caching.EEMProfileSettings;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMApplDAO;
import com.medicare.mss.dao.EEMMbrDAO;
import com.medicare.mss.dao.EEMMbrPOSDAO;
import com.medicare.mss.domainobject.EMMbrTriggerDO;
import com.medicare.mss.domainobject.EmMbrPosInfoDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.EEMContext;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.vo.EEMMbrEnrollmentVO;
import com.medicare.mss.vo.EmMbrPosInfoVO;

@Service
@Transactional(rollbackFor = ApplicationException.class)
public class EEMMbrPOSServices extends EEMMbrBaseService {

	@Autowired
	private EEMMbrPOSDAO eEMMbrPOSDao;

	@Autowired
	EEMProfileSettings eemProfileSettings;

	@Autowired
	EEMApplDAO applicationDAO;
	
	@Autowired
	private EEMMbrDAO mbrDao;

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public List<EmMbrPosInfoVO> getMbrPOSInfoList(String memberId, String showAll) {

		List<EmMbrPosInfoVO> mbrPOSEditVOList = sessionHelper.getEEMContext().getMbrMasterVO().getMbrPosInfoList();

		if (StringUtils.equals(EEMConstants.VALUE_YES, showAll)) {
			List<EmMbrPosInfoVO> allInfos = getMbrPOSInfoListFromDB(memberId, showAll);
				mbrPOSEditVOList = (List<EmMbrPosInfoVO>) getActiveDatedList(allInfos);
				setToContext(mbrPOSEditVOList);
			return allInfos;
		} else {
			if (Objects.isNull(mbrPOSEditVOList)) {
				mbrPOSEditVOList = getMbrPOSInfoListFromDB(memberId, showAll);
				setToContext(mbrPOSEditVOList);
			} else {
				mbrPOSEditVOList = (List<EmMbrPosInfoVO>) getActiveDatedList(mbrPOSEditVOList);
				setToContext(mbrPOSEditVOList);
			}
			return mbrPOSEditVOList;
		}
	}

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public List<EmMbrPosInfoVO> getMbrPOSInfoListFromDB(String memberId, String showAll) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		List<EmMbrPosInfoVO> mbrPOSEditVOList = new ArrayList<>();

		List<EmMbrPosInfoDO> mbrPOSEditDOList = eEMMbrPOSDao.getMbrPos(customerId, memberId, showAll);
		mbrPOSEditDOList.forEach(mbrPOSSelect -> {
			EmMbrPosInfoVO mbrPOSEditVO = new EmMbrPosInfoVO();
			BeanUtils.copyProperties(mbrPOSSelect, mbrPOSEditVO);
			mbrPOSEditVOList.add(mbrPOSEditVO);
		});

		/*
		 * if (!"Y".equals(showAll)) { setToContext(mbrPOSEditVOList); }
		 */
		if(StringUtils.equals(EEMConstants.VALUE_NO, showAll)) {
			setToContext(mbrPOSEditVOList);
		} else {
			List<EmMbrPosInfoVO> activeDatedList = (List<EmMbrPosInfoVO>) getActiveDatedList(mbrPOSEditVOList);
			setToContext(activeDatedList);
		}
		return mbrPOSEditVOList;
	}

	public void setToContext(List<EmMbrPosInfoVO> mbrPOSEditVOList) {
		EEMContext context = sessionHelper.getEEMContext();
		context.getMbrMasterVO().setMbrPosInfoList(mbrPOSEditVOList);
		sessionHelper.setEEMContext(context);
	}

	public List<EmMbrPosInfoVO> mbrPosInfoDelete(EmMbrPosInfoVO delVO) {
		String userId = sessionHelper.getUserInfo().getUserId();
		int sqlCnt = 0;
		try {
			EmMbrPosInfoDO delDO = new EmMbrPosInfoDO();
			BeanUtils.copyProperties(delVO, delDO);
			sqlCnt = eEMMbrPOSDao.setPosInfoOverride(delDO, userId);
			if (sqlCnt == 1) {
				return getMbrPOSInfoListFromDB(delVO.getMemberId(), delVO.getShowAll());
			} else {
				throw new ApplicationException(" POS delete operation failed ");
			}
		} catch (Exception exp) {
			throw new ApplicationException(exp.getMessage());
		}
	}

	public List<EmMbrPosInfoVO> mbrPosUpdate(EmMbrPosInfoVO newVO) {
		String userId = sessionHelper.getUserInfo().getUserId();
		newVO.setOverrideInd("N");
		newVO.setCustomerId(sessionHelper.getUserInfo().getCustomerId());
		String ts = DateUtil.getCurrentDatetimeStamp();

		int sqlCnt = 0;

		try {
			List<EmMbrPosInfoVO> posInfos = getMbrPOSInfoList(newVO.getMemberId(), "");

			if (!CollectionUtils.isEmpty(posInfos)) {
				for (int i = 0; i < posInfos.size(); i++) {
					EmMbrPosInfoVO overVO = posInfos.get(i);
					EmMbrPosInfoDO overDO = new EmMbrPosInfoDO();
					BeanUtils.copyProperties(overVO, overDO);
					sqlCnt = eEMMbrPOSDao.setMbrPosOverride(overDO, userId);
				}
				if (sqlCnt != 1) {
					throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT);
				}
			}
			newVO.setCreateTime(ts);
			newVO.setCreateUserId(userId);
			newVO.setLastUpdtTime(ts);
			newVO.setLastUpdtUserId(userId);

			EmMbrPosInfoDO newDO = new EmMbrPosInfoDO();
			BeanUtils.copyProperties(newVO, newDO);

			sqlCnt = eEMMbrPOSDao.insertMbrPos(newDO);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_INSERTING_NEW_SEGMENT);
			}
			creatDataInMBRTrigger(newVO);
			return getMbrPOSInfoListFromDB(newVO.getMemberId(), newVO.getShowAll());
		} catch (Exception exp) {
			throw new ApplicationException(exp.getMessage());
		}
	}

	private boolean creatDataInMBRTrigger(EmMbrPosInfoVO newVO) {

		boolean insertInMbrTrigger = false;
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		int sqlCnt = 0;

		List<EEMMbrEnrollmentVO> mbrEnrollmentList = sessionHelper.getEEMContext().getMbrMasterVO()
				.getMbrEnrollmentList();

		if (!CollectionUtils.isEmpty(mbrEnrollmentList)
				&& (("EAPRV").equalsIgnoreCase(mbrEnrollmentList.get(0).getEnrollStatus())
						&& ("CMSAPRV").equalsIgnoreCase(mbrEnrollmentList.get(0).getEnrollReasonCd())
						&& mbrEnrollmentList.get(0).getCustomerId().equalsIgnoreCase(newVO.getCustomerId())
						&& mbrEnrollmentList.get(0).getMemberId().equalsIgnoreCase(newVO.getMemberId())
						&& ("N").equalsIgnoreCase(mbrEnrollmentList.get(0).getOverrideInd()))) {
			newVO.setPlanId(mbrEnrollmentList.get(0).getPlanId());
			newVO.setPbpId(mbrEnrollmentList.get(0).getPbpId());
			newVO.setGroupId(mbrEnrollmentList.get(0).getGrpId());
			newVO.setProductId(mbrEnrollmentList.get(0).getProductId());

			if (newVO.getGroupId() != null && newVO.getProductId() != null) {
				newVO.setPlanDesignation(mbrEnrollmentList.get(0).getPlanDesignation());
			}
		}

		EMMbrTriggerDO trigDO = new EMMbrTriggerDO();
		trigDO.setCustomerId(customerId);
		trigDO.setMemberId(newVO.getMemberId());
		trigDO.setTriggerType(EEMConstants.TRIG_TYPE_TXN);
		trigDO.setEffectiveDate(newVO.getNotificateDate());
		trigDO.setCreateTime(newVO.getCreateTime());
		trigDO.setTriggerCode(EEMConstants.TRIG_CODE_POS); 	
		trigDO.setPlanId(newVO.getPlanId());
		trigDO.setPbpId(newVO.getPbpId());
		trigDO.setPlanDesignation(newVO.getPlanDesignation());
		trigDO.setTriggerStatus(EEMConstants.TRIG_STATUS_OPEN);
		trigDO.setProcessSource(EEMConstants.PROCESS_SOURCE_MBR);
		trigDO.setOrigTriggerType("");
		trigDO.setOrigTriggerCode("");
		trigDO.setOrigEffectiveDate("");
		trigDO.setOrigTriggerCreateTime("");
		trigDO.setCreateUserId(newVO.getCreateUserId());
		trigDO.setLastUpdtTime(newVO.getLastUpdtTime());
		trigDO.setLastUpdtUserId(newVO.getLastUpdtUserId());
		
		sqlCnt = mbrDao.insertMbrTrigger(trigDO);
		if (sqlCnt > 0) {
			return true;
		}
		return insertInMbrTrigger;
	}

}
