package com.medicare.mss.domainobject;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class EEMLepAttestCallDO extends BaseDO {

	private Integer index;
	private String attempt;
	private String date;
	private String status;
	private String userId;
	private String isChange;



}
