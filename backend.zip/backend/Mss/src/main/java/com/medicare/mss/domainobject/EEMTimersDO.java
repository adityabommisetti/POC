package com.medicare.mss.domainobject;

import lombok.Data;

@Data
public class EEMTimersDO {

	private String customerId;
	private String sourceType;
	private String primaryId;
	private String triggerCode;
	private String timerType;
	private String status;
	private String creationTime;
	private String activationTime;
	private String trgSource;
	private String lastUpdtTime;
	private String lastUpdtUserId;
	private String planId;
	private String pbpId;
	private String planDesignation;
	private String editActivationDateStatus;
	private String triggerType;
	
}
