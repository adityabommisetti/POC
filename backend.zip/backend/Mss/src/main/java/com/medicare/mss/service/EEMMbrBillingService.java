package com.medicare.mss.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMMbrBillingDAO;
import com.medicare.mss.dao.EEMMbrDAO;
import com.medicare.mss.domainobject.EEMMbrBillingDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.EEMContext;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.vo.EEMMbrBillingVO;
import com.medicare.mss.vo.EMDatedSegmentVO;

@Service
public class EEMMbrBillingService extends EEMMbrBaseService {

	@Autowired
	private EEMMbrBillingDAO mbrBillingDAO;

	@Autowired
	private EEMMbrDAO eemMbrDao;

	@Autowired
	private EEMCodeCache eemCodeCache;

	@SuppressWarnings("unchecked")
	public List<EEMMbrBillingVO> getMbrBillingList(String memberId, String showAll) {

		List<EEMMbrBillingVO> mbrBillingVOList = sessionHelper.getEEMContext().getMbrMasterVO().getMbrBillingList();
		
		if (StringUtils.equals(EEMConstants.VALUE_YES, showAll)) {
			List<EEMMbrBillingVO> allInfos = getMbrBillingListFromDB(memberId, showAll);
				mbrBillingVOList = (List<EEMMbrBillingVO>) getActiveDatedList(allInfos);
				setToContext(mbrBillingVOList);
			return allInfos;
		} else {
			if (Objects.isNull(mbrBillingVOList)) {
				mbrBillingVOList = getMbrBillingListFromDB(memberId, showAll);
				setToContext(mbrBillingVOList);
			} else {
				mbrBillingVOList = (List<EEMMbrBillingVO>) getActiveDatedList(mbrBillingVOList);
				setToContext(mbrBillingVOList);
			}
			return mbrBillingVOList;
		}
	}

	public List<EEMMbrBillingVO> getMbrBillingListFromDB(String memberId, String showAll) {

		List<EEMMbrBillingVO> mbrBillingVOList = new ArrayList<>();
		String customerId = sessionHelper.getUserInfo().getCustomerId();

		List<EEMMbrBillingDO> mbrBillingDOList = mbrBillingDAO.getMbrBilling(customerId, memberId, showAll);
		if (!CollectionUtils.isEmpty(mbrBillingDOList)) {
			mbrBillingDOList.forEach(mbrBillingDO -> {
				EEMMbrBillingVO eEMMbrBillingVO = new EEMMbrBillingVO();
				try {
					mbrBillingDO.setBillPayMethodDesc(mbrBillingDO.getBillPayMethod() + "-"
							+ eemCodeCache.getBillPayMethodDesc(mbrBillingDO.getBillPayMethod()));
					mbrBillingDO.setAccountTypeDesc(mbrBillingDO.getAccountType() + "-"
							+ eemCodeCache.getAccountTypeDesc(mbrBillingDO.getAccountType()));
					mbrBillingDO.setBillFrequencyDesc(mbrBillingDO.getBillFrequency() + "-"
							+ eemCodeCache.getBillFrequencyDesc(mbrBillingDO.getBillFrequency()));
				} catch (ApplicationException exp) {
					throw new ApplicationException(exp);
				}
				BeanUtils.copyProperties(mbrBillingDO, eEMMbrBillingVO);
				mbrBillingVOList.add(eEMMbrBillingVO);
			});
		}
		return mbrBillingVOList;
	}

	@SuppressWarnings("unchecked")
	@Transactional(rollbackOn = ApplicationException.class)
	public List<EEMMbrBillingVO> updateMbrBilling(EEMMbrBillingVO emMbrBillingVO) {

		String userId = sessionHelper.getUserInfo().getUserId();
		String customerId = sessionHelper.getUserInfo().getCustomerId();

		EEMMbrBillingDO wrkVO = new EEMMbrBillingDO();
		BeanUtils.copyProperties(emMbrBillingVO, wrkVO);

		List<EEMMbrBillingVO> mbrBillingVOList = getListFromContext(emMbrBillingVO.getMemberId(), "N");
		List<EEMMbrBillingDO> mbrBillingDOLst = new ArrayList<>();
		CommonUtils.copyList(mbrBillingVOList, mbrBillingDOLst, EEMMbrBillingDO.class);
		wrkVO.setCustomerId(customerId);
		wrkVO.setOverrideInd("N");

		boolean rslt = mbrBillingUpdate(mbrBillingDOLst, wrkVO, userId);
		if (rslt) {
			mbrBillingVOList = getMbrBillingListFromDB(emMbrBillingVO.getMemberId(), emMbrBillingVO.getShowAll());
			if (StringUtils.equals(EEMConstants.VALUE_NO, emMbrBillingVO.getShowAll())) {
				setToContext(mbrBillingVOList);
			} else {
				List<EEMMbrBillingVO> mbrBillingActiveVOList = (List<EEMMbrBillingVO>) getActiveDatedList(mbrBillingVOList);
				setToContext(mbrBillingActiveVOList);
			}
		} else {
			throw new ApplicationException("Billing Update Failed");
		}
		return mbrBillingVOList;
	}

	public boolean mbrBillingUpdate(List<EEMMbrBillingDO> billingLst, EEMMbrBillingDO newVO, String userId) {

		String ts = DateUtil.getCurrentDatetimeStamp();
		Map<String, String> type = new HashMap<>();
		int sqlCnt = 0;
		boolean result = false;
		try {
			String message = checkDates(newVO);
			if (message != null) {
				throw new ApplicationException(message);
			}
			String maxLastUpdate = eemMbrDao.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
					EEMConstants.EM_MBR_BILLING, type);
			if (hasDataChanged(billingLst, maxLastUpdate)) {
				throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
			}
			EEMMbrBillingDO matchVO = null;

			matchVO = (EEMMbrBillingDO) matchDatedSegment(billingLst, newVO);
			if (matchVO != null) {
				sqlCnt = mbrBillingDAO.setOverride(matchVO, userId);
				if (sqlCnt != 1) {
					throw new ApplicationException(EEMConstants.ERROR_OVERRIDING_SEGMENT);
				}
				sqlCnt = addSegment(newVO, userId, ts);
				if (sqlCnt != 1) {
					throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
				}
				maxLastUpdate = eemMbrDao.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
						EEMConstants.EM_MBR_BILLING, type);
				if (hasDataChanged(ts, maxLastUpdate)) {
					throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
				}
				return true;
			}
			matchVO = (EEMMbrBillingDO) matchDatedSegmentEndDate(billingLst, newVO);
			if (matchVO != null) {
				sqlCnt = mbrBillingDAO.setOverride(matchVO, userId);
				if (sqlCnt != 1) {
					throw new ApplicationException(EEMConstants.ERROR_OVERRIDING_SEGMENT);
				}
				sqlCnt = addSegment(newVO, userId, ts);
				if (sqlCnt != 1) {
					throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
				}
				maxLastUpdate = eemMbrDao.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
						EEMConstants.EM_MBR_BILLING, type);
				if (hasDataChanged(ts, maxLastUpdate)) {
					throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
				}
				return true;
			}
			if (newVO.getEffEndDate().equals("99999999")) {

				List<? extends EMDatedSegmentVO> lstSegmentsAbove = getSegmentsAbove(billingLst,
						newVO.getEffStartDate());
				Iterator<? extends EMDatedSegmentVO> it = lstSegmentsAbove.iterator();
				while (it.hasNext()) {
					EEMMbrBillingDO itemVO = (EEMMbrBillingDO) it.next();
					sqlCnt = mbrBillingDAO.setOverride(itemVO, userId);
					if (sqlCnt != 1) {
						throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_ABOVE);
					}
				}
				EEMMbrBillingDO belowVO = (EEMMbrBillingDO) getFirstOverlapSegmentBelow(billingLst,
						newVO.getEffStartDate());
				if (belowVO != null) {

					sqlCnt = mbrBillingDAO.setOverride(belowVO, userId);
					if (sqlCnt != 1) {
						throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_BELOW);
					}
					if (belowVO.getEffStartDate().compareTo(newVO.getEffStartDate()) < 0) {
						EEMMbrBillingDO tempVO = (EEMMbrBillingDO) belowVO.clone();
						tempVO.setEffEndDate(DateMath.minusOneDay(newVO.getEffStartDate()));
						tempVO.setCreateTime(ts);
						tempVO.setCreateUserId(userId);
						tempVO.setLastUpdtTime(ts);
						tempVO.setLastUpdtUserId(userId);
						sqlCnt = mbrBillingDAO.insertMbr(tempVO);
						if (sqlCnt != 1) {
							throw new ApplicationException(EEMConstants.ERROR_SPLITING_SEGMENT_BELOW);
						}
					}
				}
				sqlCnt = addSegment(newVO, userId, ts);
				if (sqlCnt != 1) {
					throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
				}
				maxLastUpdate = eemMbrDao.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
						EEMConstants.EM_MBR_BILLING, type);
				if (hasDataChanged(ts, maxLastUpdate)) {
					throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
				}
				return true;
			}
			if (!doDatedSegmentAdjust(billingLst, newVO, ts, userId, mbrBillingDAO)) {
				return false;
			}
			sqlCnt = addSegment(newVO, userId, ts);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
			}
			maxLastUpdate = eemMbrDao.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
					EEMConstants.EM_MBR_BILLING, type);
			if (hasDataChanged(ts, maxLastUpdate)) {
				throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
			}
			result = true;
		} catch (Exception exp) {
			throw new ApplicationException(exp);
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	public List<EEMMbrBillingVO> mbrbillingDelete(EEMMbrBillingVO emMbrBillingVO) {

		String userId = sessionHelper.getUserInfo().getUserId();
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		emMbrBillingVO.setCustomerId(customerId);

		List<EEMMbrBillingVO> mbrBillingVOList = new ArrayList<>();
		try {
			EEMMbrBillingDO emMbrBillingDO = new EEMMbrBillingDO();
			BeanUtils.copyProperties(emMbrBillingVO, emMbrBillingDO);

			int sqlCnt = mbrBillingDAO.setOverride(emMbrBillingDO, userId);
			if (sqlCnt == 1) {
				mbrBillingVOList = getMbrBillingListFromDB(emMbrBillingVO.getMemberId(), emMbrBillingVO.getShowAll());
				if (StringUtils.equals(EEMConstants.VALUE_NO, emMbrBillingVO.getShowAll())) {
					setToContext(mbrBillingVOList);
				} else {
					List<EEMMbrBillingVO> mbrBillingActiveVOList = (List<EEMMbrBillingVO>) getActiveDatedList(mbrBillingVOList);
					setToContext(mbrBillingActiveVOList);
				}
				return mbrBillingVOList;
			}
		} catch (Exception exp) {
			throw new ApplicationException(exp);
		}
		return mbrBillingVOList;
	}

	@SuppressWarnings("unchecked")
	private List<EEMMbrBillingVO> getListFromContext(String memberId, String showAll) {

		EEMContext context = sessionHelper.getEEMContext();
		List<EEMMbrBillingVO> mbrBillingVOList = context.getMbrMasterVO().getMbrBillingList();

		if ("Y".equalsIgnoreCase(showAll)) {
			List<EEMMbrBillingVO> allInfos = getMbrBillingListFromDB(memberId, showAll);

			if (null == mbrBillingVOList || CollectionUtils.isEmpty(mbrBillingVOList)) {
				mbrBillingVOList = (List<EEMMbrBillingVO>) getActiveDatedList(allInfos);
				setToContext(mbrBillingVOList);
			}
			return allInfos;
		} else {
			if (null == mbrBillingVOList || CollectionUtils.isEmpty(mbrBillingVOList)) {
				mbrBillingVOList = getMbrBillingListFromDB(memberId, showAll);
				setToContext(mbrBillingVOList);
			}
			return mbrBillingVOList;
		}
	}

	private int addSegment(EEMMbrBillingDO newVO, String userId, String ts) {
		int sqlCnt;
		newVO.setCreateTime(ts);
		newVO.setCreateUserId(userId);
		newVO.setLastUpdtTime(ts);
		newVO.setLastUpdtUserId(userId);
		sqlCnt = mbrBillingDAO.insertMbr(newVO);
		return sqlCnt;
	}

	private void setToContext(List<EEMMbrBillingVO> mbrBillingVOList) {
		EEMContext context = sessionHelper.getEEMContext();
		context.getMbrMasterVO().setMbrBillingList(mbrBillingVOList);
		sessionHelper.setEEMContext(context);
	}

}
