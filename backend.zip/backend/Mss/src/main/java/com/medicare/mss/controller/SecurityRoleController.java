package com.medicare.mss.controller;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.service.SecurityRoleService;
import com.medicare.mss.vo.SecurityRoleVO;

@RestController
@RequestMapping("/security")
public class SecurityRoleController {

	@Autowired
	private SecurityRoleService service;

	@GetMapping(path = ReqMappingConstants.GET_SECURITY_CACHE)
	public ResponseEntity<JSONResponse> getRolesList() {

		Map<String, Object> userRoleList = service.getSecurityCache();
		return sendResponse(userRoleList);

	}

	@PostMapping(path = ReqMappingConstants.UPDATE_SECURITY_ROLE)
	public ResponseEntity<JSONResponse> getUpdateRole(@RequestBody Map<String, String> queryParamMap) {

		int value = service.getUpdateRole(queryParamMap);
		String result = "Failed to update";
		if (value > 0) {
			result = "Updated Successfully";
		}

		return sendResponse(result);

	}

	@PostMapping(path = ReqMappingConstants.GET_SERVICES)
	public ResponseEntity<JSONResponse> getRoleServices(@PathVariable("groupId") String groupId) {
		Map<String, List<SecurityRoleVO>> userServices = service.getRoleServices(groupId);

		return sendResponse(userServices);

	}


	@PostMapping(path = ReqMappingConstants.ADD_SERVICE)
	public ResponseEntity<String> updateService(@RequestBody Map<String, Object> queryParamMap) {

		boolean response = service.addService(queryParamMap);
		if (response) {
			return ResponseEntity.status(200).body("ADDED SUCCESSFULLY");
		}
		return ResponseEntity.status(204).body(null);
	

	}

	@PostMapping(path = ReqMappingConstants.REMOVE_SERVICE)
	public ResponseEntity<String> removeService(@RequestBody Map<String, Object> queryParamMap) {

		boolean response = service.removeService(queryParamMap);
		if (response) {
			return ResponseEntity.status(200).body("DELETED SUCCESSFULLY");
		}
		return ResponseEntity.status(204).body(null);
	}

	private ResponseEntity<JSONResponse> sendResponse(Object result) {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;

		if (Objects.isNull(result)) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setData(result);
			jsonResponse.setMessage(EEMConstants.SUCCESS);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}

}
