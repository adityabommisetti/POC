package com.medicare.mss.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMGrpSvcDAO;
import com.medicare.mss.dao.EEMMbrAddressDAO;
import com.medicare.mss.dao.EEMMbrDAO;
import com.medicare.mss.domainobject.EEMMbrAddressDO;
import com.medicare.mss.domainobject.EEMStateCountyZipDO;
import com.medicare.mss.domainobject.EMMbrTriggerDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.EEMContext;
import com.medicare.mss.util.AddressFormatter;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EEMMbrAddressVO;
import com.medicare.mss.vo.EEMMbrDsInfoVO;
import com.medicare.mss.vo.EEMMbrEnrollmentVO;
import com.medicare.mss.vo.EMDatedSegmentVO;

@Service
public class EEMMbrAddressServices extends EEMMbrBaseService {

	@Autowired
	private EEMMbrAddressDAO mbrAddressDao;

	@Autowired
	private EEMGrpSvcDAO eemGrpSvcDao;

	@Autowired
	private EEMMbrDsInfoService mbrDsInfoService;

	@Autowired
	private EEMMbrDAO eemMbrDAO;

	@Autowired
	private EEMCodeCache codeCache;

	@SuppressWarnings("unchecked")
	@Transactional(rollbackFor = ApplicationException.class)
	public Map<String, Object> updtMbrAddress(EEMMbrAddressVO mbrAddressVO)
			throws ApplicationException, ParseException, CloneNotSupportedException {

		String userId = sessionHelper.getUserInfo().getUserId();
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		// Triple-S Migration - Address tab - allow any day of the month - Start
		mbrAddressVO.setAddressValidation((String) sessionHelper.getAttribute("ADRVAL"));
		// Triple-S Migration - Address tab - allow any day of the month - End
		EEMMbrAddressDO wrkVO = new EEMMbrAddressDO();
		BeanUtils.copyProperties(mbrAddressVO, wrkVO);

		List<EEMMbrDsInfoVO> mbrDsInfoVOList = new ArrayList<>();
		List<EEMMbrAddressVO> mbrAddressVOList = getListFromContext(mbrAddressVO.getMemberId(), "N");
		List<EEMMbrAddressDO> mbrAddressDOLst = new ArrayList<>();
		mbrAddressVOList.forEach(eemMbrAddressVO -> {
			EEMMbrAddressDO tempAddressVO = new EEMMbrAddressDO();
			BeanUtils.copyProperties(eemMbrAddressVO, tempAddressVO);
			mbrAddressDOLst.add(tempAddressVO);
		});
		wrkVO.setCustomerId(customerId);
		wrkVO.setOverrideInd("N");

		boolean rslt = this.checkStateZip(wrkVO);
		if (!rslt) {
			throw new ApplicationException("State code " + wrkVO.getStateAbbr() + "is not in Zip Code");
		} else {
			wrkVO.setDsInfoChange(false);
			rslt = mbrAddressUpdate(mbrAddressDOLst, wrkVO, userId);
			if (rslt) {
				mbrAddressVOList = getMbrAddressList(mbrAddressVO.getMemberId(), mbrAddressVO.getShowAll());
				if (StringUtils.equals(EEMConstants.VALUE_NO, mbrAddressVO.getShowAll())) {
					setToContext(mbrAddressVOList);
				} else {
					List<EEMMbrAddressVO> mbrAddressActiveVOList = (List<EEMMbrAddressVO>) getActiveDatedList(mbrAddressVOList);
					setToContext(mbrAddressActiveVOList);
				}
				if (wrkVO.isDsInfoChange()) {
					mbrDsInfoVOList = mbrDsInfoService.getMbrDsInfoListFromDB(mbrAddressVO.getMemberId(), mbrAddressVO.getShowAll());
					if (StringUtils.equals(EEMConstants.VALUE_NO, mbrAddressVO.getShowAll())) {
						mbrDsInfoService.setToContext(mbrDsInfoVOList);
					} else {
						List<EEMMbrDsInfoVO> mbrDsInfoActiveVOList = (List<EEMMbrDsInfoVO>) getActiveDatedList(mbrDsInfoVOList);
						mbrDsInfoService.setToContext(mbrDsInfoActiveVOList);
					}
				}
			} else {
				throw new ApplicationException("Address Update Failed");
			}
		}
		return buildResultMap(mbrAddressVOList, mbrDsInfoVOList);
	}

	public boolean mbrAddressUpdate(List<EEMMbrAddressDO> mbrAddressDOLst, EEMMbrAddressDO newVO, String userId)
			throws ApplicationException, ParseException, CloneNotSupportedException {

		Map<String, String> type = new HashMap<>();
		type.put("ADDRESS_TYPE", newVO.getAddressType());

		if (!"VALID".equalsIgnoreCase(newVO.getAddressValidation())) {
			String msg = checkDates(newVO);
			if (msg != null) {
				throw new ApplicationException(msg);
			}
		}
		if (EEMConstants.EEM_ADDRTYPE_PRIMARY.equals(newVO.getAddressType())) {
			return mbrPrimaryAddressUpdate(mbrAddressDOLst, newVO, userId, type);
		}
		String timeStamp = DateUtil.getCurrentDatetimeStamp();
		int sqlCnt = 0;

		String maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
				EEMConstants.EM_MBR_ADDRESS, type);
		List<? extends EMDatedSegmentVO> addressLst = getDatedTypeList(mbrAddressDOLst, newVO.getAddressType());
		if (hasDataChanged(addressLst, maxLastUpdate)) {
			throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
		}
		EEMMbrAddressDO matchVO = null;
		matchVO = (EEMMbrAddressDO) matchDatedSegment(addressLst, newVO);
		if (matchVO != null) {
			sqlCnt = mbrAddressDao.setOverride(matchVO, userId);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_OVERRIDING_SEGMENT);
			}
			newVO.setCreateTime(timeStamp);
			newVO.setCreateUserId(userId);
			newVO.setLastUpdtTime(timeStamp);
			newVO.setLastUpdtUserId(userId);
			sqlCnt = mbrAddressDao.insertMbr(newVO);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
			}
			maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
					EEMConstants.EM_MBR_ADDRESS, type);
			if (hasDataChanged(timeStamp, maxLastUpdate)) {
				throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
			}
			return true;
		}
		matchVO = (EEMMbrAddressDO) matchDatedSegmentEndDate(addressLst, newVO);
		if (matchVO != null) {
			sqlCnt = mbrAddressDao.setOverride(matchVO, userId);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_OVERRIDING_SEGMENT);
			}
			newVO.setCreateTime(timeStamp);
			newVO.setCreateUserId(userId);
			newVO.setLastUpdtTime(timeStamp);
			newVO.setLastUpdtUserId(userId);
			sqlCnt = mbrAddressDao.insertMbr(newVO);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
			}
			maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
					EEMConstants.EM_MBR_ADDRESS, type);
			if (hasDataChanged(timeStamp, maxLastUpdate)) {
				throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
			}
			return true;
		}
		if (newVO.getEffEndDate().equals("99999999")) {
			List<? extends EMDatedSegmentVO> lstSegmentsAbove = getSegmentsAbove(addressLst, newVO.getEffStartDate());
			Iterator<? extends EMDatedSegmentVO> it = lstSegmentsAbove.iterator();
			while (it.hasNext()) {
				EEMMbrAddressDO itemVO = (EEMMbrAddressDO) it.next();
				sqlCnt = mbrAddressDao.setOverride(itemVO, userId);
				if (sqlCnt != 1) {
					throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_ABOVE);
				}
			}
			EEMMbrAddressDO belowVO = (EEMMbrAddressDO) getFirstOverlapSegmentBelow(addressLst,
					newVO.getEffStartDate());
			if (belowVO != null) {

				sqlCnt = mbrAddressDao.setOverride(belowVO, userId);
				if (sqlCnt != 1) {
					throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_BELOW);
				}
				if (belowVO.getEffStartDate().compareTo(newVO.getEffStartDate()) < 0) {
					EEMMbrAddressDO tempVO = new EEMMbrAddressDO();
					BeanUtils.copyProperties(belowVO, tempVO);
					tempVO.setEffEndDate(DateMath.minusOneDay(newVO.getEffStartDate()));
					tempVO.setCreateTime(timeStamp);
					tempVO.setCreateUserId(userId);
					tempVO.setLastUpdtTime(timeStamp);
					tempVO.setLastUpdtUserId(userId);
					sqlCnt = mbrAddressDao.insertMbr(tempVO);

					if (sqlCnt != 1) {
						throw new ApplicationException(EEMConstants.ERROR_SPLITING_SEGMENT_BELOW);
					}
				}
			}
			newVO.setCreateTime(timeStamp);
			newVO.setCreateUserId(userId);
			newVO.setLastUpdtTime(timeStamp);
			newVO.setLastUpdtUserId(userId);

			sqlCnt = mbrAddressDao.insertMbr(newVO);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
			}
			maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
					EEMConstants.EM_MBR_ADDRESS, type);
			if (hasDataChanged(timeStamp, maxLastUpdate)) {
				throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
			}
			return true;
		}
		doDatedSegmentAdjust(addressLst, newVO, timeStamp, userId, mbrAddressDao);

		newVO.setCreateTime(timeStamp);
		newVO.setCreateUserId(userId);
		newVO.setLastUpdtTime(timeStamp);
		newVO.setLastUpdtUserId(userId);
		sqlCnt = mbrAddressDao.insertMbr(newVO);
		if (sqlCnt != 1) {
			throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
		}
		maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
				EEMConstants.EM_MBR_ADDRESS, type);
		if (hasDataChanged(timeStamp, maxLastUpdate)) {
			throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
		}
		return true;
	}

	public boolean mbrPrimaryAddressUpdate(List<EEMMbrAddressDO> mbrAddressDOLst, EEMMbrAddressDO newVO, String userId, Map<String, String> type)
			throws ParseException, ApplicationException, CloneNotSupportedException {

		String timeStamp = DateUtil.getCurrentDatetimeStamp();
		int sqlCnt = 0;
		int retVal = mbrStateCountyCheck(newVO, userId, timeStamp);
		if (retVal < 0)
			throw new ApplicationException("MemberStateCountyCheck Failed");

		String maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
				EEMConstants.EM_MBR_ADDRESS, type);
		List<? extends EMDatedSegmentVO> addressLst = getDatedTypeList(mbrAddressDOLst, newVO.getAddressType());
		if (hasDataChanged(addressLst, maxLastUpdate)) {
			throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
		}
		EEMMbrAddressDO matchVO = null;

		// the update case
		matchVO = (EEMMbrAddressDO) matchDatedSegment(addressLst, newVO);
		if (matchVO != null) {
			sqlCnt = mbrAddressDao.setOverride(matchVO, userId);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_OVERRIDING_SEGMENT);
			}
			newVO.setCreateTime(timeStamp);
			newVO.setCreateUserId(userId);
			newVO.setLastUpdtTime(timeStamp);
			newVO.setLastUpdtUserId(userId);
			sqlCnt = mbrAddressDao.insertMbr(newVO);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
			}
			maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
					EEMConstants.EM_MBR_ADDRESS, type);
			if (hasDataChanged(timeStamp, maxLastUpdate)) {
				throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
			}
			return true;
		}
		if (newVO.getEffEndDate().equals("99999999")) {
			List<? extends EMDatedSegmentVO> lstSegmentsAbove = getSegmentsAbove(addressLst, newVO.getEffStartDate());
			Iterator<? extends EMDatedSegmentVO> it = lstSegmentsAbove.iterator();
			while (it.hasNext()) {
				EEMMbrAddressDO itemVO = (EEMMbrAddressDO) it.next();
				sqlCnt = mbrAddressDao.setOverride(itemVO, userId);
				if (sqlCnt != 1) {
					throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_ABOVE);
				}
			}
			EEMMbrAddressDO belowVO = (EEMMbrAddressDO) getFirstOverlapSegmentBelow(addressLst,
					newVO.getEffStartDate());
			if (belowVO != null) {
				sqlCnt = mbrAddressDao.setOverride(belowVO, userId);
				if (sqlCnt != 1) {
					throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_BELOW);
				}
				if (belowVO.getEffStartDate().compareTo(newVO.getEffStartDate()) < 0) {
					EEMMbrAddressDO tempVO = new EEMMbrAddressDO();
					BeanUtils.copyProperties(belowVO, tempVO);
					tempVO.setEffEndDate(DateMath.minusOneDay(newVO.getEffStartDate()));
					tempVO.setCreateTime(timeStamp);
					tempVO.setCreateUserId(userId);
					tempVO.setLastUpdtTime(timeStamp);
					tempVO.setLastUpdtUserId(userId);

					sqlCnt = mbrAddressDao.insertMbr(tempVO);
					if (sqlCnt != 1) {
						throw new ApplicationException(EEMConstants.ERROR_SPLITING_SEGMENT_BELOW);
					}
				}
			}
			newVO.setCreateTime(timeStamp);
			newVO.setCreateUserId(userId);
			newVO.setLastUpdtTime(timeStamp);
			newVO.setLastUpdtUserId(userId);
			sqlCnt = mbrAddressDao.insertMbr(newVO);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
			}
			maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
					EEMConstants.EM_MBR_ADDRESS, type);
			if (hasDataChanged(timeStamp, maxLastUpdate)) {
				throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
			}
			return true;
		}
		if (endsBeforeFirstSegment(addressLst, newVO.getEffEndDate())) {
			throw new ApplicationException("End Date before first segment, Gaps are not allowed");
		}
		doDatedSegmentAdjust(addressLst, newVO, timeStamp, userId, mbrAddressDao);
		newVO.setCreateTime(timeStamp);
		newVO.setCreateUserId(userId);
		newVO.setLastUpdtTime(timeStamp);
		newVO.setLastUpdtUserId(userId);
		sqlCnt = mbrAddressDao.insertMbr(newVO);
		if (sqlCnt != 1) {
			throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
		}
		maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
				EEMConstants.EM_MBR_ADDRESS, type);
		if (hasDataChanged(timeStamp, maxLastUpdate)) {
			throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
		}
		return true;
	}

	public boolean checkStateZip(EEMMbrAddressDO wrkVO) throws ApplicationException {

		wrkVO.setStateAbbr(codeCache.getStateAbbr(wrkVO.getStateCd()));
		wrkVO.setZipCd(wrkVO.getZipCd5() + wrkVO.getZipCd4());
		EEMStateCountyZipDO chkVO = new EEMStateCountyZipDO();

		chkVO.setZip5(AddressFormatter.getZip5(wrkVO.getZipCd()));
		chkVO.setZip4(AddressFormatter.getZip4(wrkVO.getZipCd()));
		if (chkVO.getZip4().equals(""))
			chkVO.setZip4("0000");
		eemGrpSvcDao.getStateCountyByZip(chkVO);
		if (!wrkVO.getStateCd().equals(chkVO.getStateCd())) {
			return false;
		}
		if (wrkVO.getCountyCd() == null || wrkVO.getCountyCd().equals("")) {
			wrkVO.setCountyCd(chkVO.getCountyCd());
		}
		wrkVO.setCountyName(codeCache.getCountyNameByCd(wrkVO.getStateCd(), wrkVO.getCountyCd()));
		wrkVO.setZipCd(wrkVO.getZipCd5() + wrkVO.getZipCd4());
		return true;
	}

	public List<EEMMbrAddressVO> getMbrAddressList(String mbrId, String showAll) throws ApplicationException {

		String custId = sessionHelper.getUserInfo().getCustomerId();
		List<EEMMbrAddressVO> eemMbrAddressVOList = new ArrayList<>();
		List<EEMMbrAddressDO> mbrAddressList = mbrAddressDao.getMbrAddresses(custId, mbrId, showAll);
		mbrAddressList.forEach(mbrAddress -> {
			EEMMbrAddressVO eemMbrAddressVO = new EEMMbrAddressVO();
			BeanUtils.copyProperties(mbrAddress, eemMbrAddressVO);
			try {
				eemMbrAddressVO
						.setStateCd(StringUtil.nonNullTrim(codeCache.getStateCd(eemMbrAddressVO.getStateAbbr())));
				eemMbrAddressVO.setCountyName(StringUtil.nonNullTrim(
						codeCache.getCountyNameByCd(eemMbrAddressVO.getStateCd(), eemMbrAddressVO.getCountyCd())));
				eemMbrAddressVO.setAddrTypeDesc(
						StringUtil.nonNullTrim(codeCache.getAddrTypeDesc(eemMbrAddressVO.getAddressType())));
			} catch (ApplicationException exp) {
				throw new RuntimeException(exp);
			}
			eemMbrAddressVOList.add(eemMbrAddressVO);
		});
		return eemMbrAddressVOList;
	}

	@SuppressWarnings("unchecked")
	public List<EEMMbrAddressVO> mbrAddressDelete(EEMMbrAddressVO mbrAddressVO) throws ApplicationException {

		String userId = sessionHelper.getUserInfo().getUserId();
		if (EEMConstants.EEM_ADDRTYPE_PRIMARY.equals(mbrAddressVO.getAddressType())) {
			throw new ApplicationException(EEMConstants.PRIMARY_ADDRESS_DELETE);
		}
		List<EEMMbrAddressVO> mbrAddressVOList = new ArrayList<>();
		EEMMbrAddressDO mbrAddressDO = new EEMMbrAddressDO();
		BeanUtils.copyProperties(mbrAddressVO, mbrAddressDO);
		int sqlCnt = 0;
		sqlCnt = mbrAddressDao.setOverride(mbrAddressDO, userId);
		if (sqlCnt == 1) {
			mbrAddressVOList = getMbrAddressList(mbrAddressVO.getMemberId(), mbrAddressVO.getShowAll());
			if (StringUtils.equals(EEMConstants.VALUE_NO, mbrAddressVO.getShowAll())) {
				setToContext(mbrAddressVOList);
			} else {
				List<EEMMbrAddressVO> mbrAddressActiveVOList = (List<EEMMbrAddressVO>) getActiveDatedList(mbrAddressVOList);
				setToContext(mbrAddressActiveVOList);
			}
			return mbrAddressVOList;
		}
		return mbrAddressVOList;
	}

	public int mbrStateCountyCheck(EEMMbrAddressDO newVO, String userId, String ts)
			throws ApplicationException, ParseException, CloneNotSupportedException {

		List<EEMMbrDsInfoVO> mbrDsInfoVOList = sessionHelper.getEEMContext().getMbrMasterVO().getMbrDsInfoList();
		List<? extends EMDatedSegmentVO> mbrEnrollmentList = sessionHelper.getEEMContext().getMbrMasterVO()
				.getMbrEnrollmentList();
		boolean rslt = hasDSIStateCountyChange(newVO, getDatedTypeList(mbrDsInfoVOList, EEMConstants.DSI_STATE_COUNTY));
		if (!rslt)
			return 0;

		EEMMbrDsInfoVO stcItem = new EEMMbrDsInfoVO();
		stcItem.setCustomerId(newVO.getCustomerId());
		stcItem.setMemberId(newVO.getMemberId());
		stcItem.setEffStartDate(newVO.getEffStartDate());
		stcItem.setEffEndDate(newVO.getEffEndDate());
		stcItem.setDsCd(EEMConstants.DSI_STATE_COUNTY);
		stcItem.setDsValue(newVO.getStateCd() + newVO.getCountyCd());
		stcItem.setOverrideInd("N");
		stcItem.setCreateTime(ts);
		stcItem.setCreateUserId(userId);
		stcItem.setLastUpdtTime(ts);
		stcItem.setLastUpdtUserId(userId);
		rslt = mbrDsInfoService.mbrDsInfoUpdate(stcItem);
		if (!rslt) {
			throw new ApplicationException("DSInfo STC Update Failure: ");
		}
		newVO.setDsInfoChange(true);

		EEMMbrEnrollmentVO mbrEnrlVO = (EEMMbrEnrollmentVO) getOpenendedSegment(mbrEnrollmentList);
		if (!mbrEnrlVO.isEnrolled()) {
			return 0;
		}
		EMMbrTriggerDO trig = new EMMbrTriggerDO();
		trig.setCustomerId(newVO.getCustomerId());
		trig.setMemberId(newVO.getMemberId());
		trig.setTriggerType(EEMConstants.TRIG_TYPE_TXN);
		trig.setEffectiveDate(newVO.getEffStartDate());
		trig.setCreateTime(ts);
		trig.setTriggerCode(EEMConstants.TRIG_CODE_76);
		trig.setPlanId(mbrEnrlVO.getPlanId());
		trig.setPbpId(mbrEnrlVO.getPbpId());
		trig.setPlanDesignation(mbrEnrlVO.getPlanDesignation());
		if (newVO.getEditOverrideInd() != null && newVO.getEditOverrideInd().equals("Y")) {
			trig.setTriggerStatus(EEMConstants.TRIG_STATUS_CLOSED);
			trig.setProcessSource(EEMConstants.TRIG_PROCESS_SOURCE_WEBENRSP);
		} else {
			trig.setTriggerStatus(EEMConstants.TRIG_STATUS_OPEN);
			trig.setProcessSource(EEMConstants.TRIG_PROCESS_SOURCE_WEBENRL);
		}
		trig.setOrigTriggerType("");
		trig.setOrigTriggerCode("");
		trig.setOrigEffectiveDate("");
		trig.setOrigTriggerCreateTime("");
		trig.setCreateUserId(userId);
		trig.setLastUpdtUserId(userId);
		trig.setLastUpdtTime(ts);

		int sqlCnt = eemMbrDAO.insertMbrTrigger(trig);
		if (sqlCnt != 1) {
			throw new ApplicationException("Error Creating CMS Transaction (76) Trigger");
		}
		return 2;
	}

	public boolean hasDSIStateCountyChange(EEMMbrAddressDO newVO, List<? extends EMDatedSegmentVO> list) {

		if (list == null)
			return true;

		EEMMbrDsInfoVO lastItem = null;
		String stateCd = "";
		String countyCd = "";
		Iterator<? extends EMDatedSegmentVO> it = list.iterator();
		while (it.hasNext()) {
			EEMMbrDsInfoVO stcItem = (EEMMbrDsInfoVO) it.next();
			if (DateMath.isBetween(newVO.getEffStartDate(), stcItem.getEffStartDate(), stcItem.getEffEndDate())
					|| DateMath.isBetween(newVO.getEffEndDate(), stcItem.getEffStartDate(), stcItem.getEffEndDate())
					|| DateMath.isBetween(stcItem.getEffStartDate(), newVO.getEffStartDate(), newVO.getEffEndDate())
					|| DateMath.isBetween(stcItem.getEffEndDate(), newVO.getEffStartDate(), newVO.getEffEndDate())) {

				String dsValue = stcItem.getDsValue();
				if (!dsValue.trim().equals("")) {
					stateCd = dsValue.substring(0, 2);
					countyCd = dsValue.substring(2, 5);
				}
				if (!stateCd.equals(newVO.getStateCd())) {
					return true;
				}
				if (!countyCd.equals(newVO.getCountyCd())) {
					return true;
				}
			}
			lastItem = stcItem;
		}
		if (lastItem == null || DateMath.isLessThan(newVO.getEffStartDate(), lastItem.getEffStartDate()))
			return true;

		return false;
	}

	@SuppressWarnings("unchecked")
	public List<EEMMbrAddressVO> getListFromContext(String memberId, String showAll) throws ApplicationException {
		EEMContext context = sessionHelper.getEEMContext();
		List<EEMMbrAddressVO> mbrAddressVOList = context.getMbrMasterVO().getMbrAddressList();
		
		if (StringUtils.equals(EEMConstants.VALUE_YES, showAll)) {
			List<EEMMbrAddressVO> allInfos = getMbrAddressList(memberId, showAll);
				mbrAddressVOList = (List<EEMMbrAddressVO>) getActiveDatedList(allInfos);
				setToContext(mbrAddressVOList);
			return allInfos;
		} else {
			if (Objects.isNull(mbrAddressVOList)) {
				mbrAddressVOList = getMbrAddressList(memberId, showAll);
				setToContext(mbrAddressVOList);
			} else {
				mbrAddressVOList = (List<EEMMbrAddressVO>) getActiveDatedList(mbrAddressVOList);
				setToContext(mbrAddressVOList);
			}
			return mbrAddressVOList;
		}
	}

	public void setToContext(List<EEMMbrAddressVO> mbrAddressVOList) {
		EEMContext context = sessionHelper.getEEMContext();
		context.getMbrMasterVO().setMbrAddressList(mbrAddressVOList);
		sessionHelper.setEEMContext(context);
	}

	public Map<String, Object> buildResultMap(List<EEMMbrAddressVO> mbrAddressInfoList,
			List<EEMMbrDsInfoVO> mbrDsInfoVOList) {

		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("mbrAddressList", mbrAddressInfoList);
		resultMap.put("mbrDsInfoList", mbrDsInfoVOList);

		return resultMap;
	}

}
