package com.medicare.mss.domainobject;

import org.apache.commons.lang3.StringUtils;

import com.medicare.mss.annotation.ColumnMapper;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.vo.EMDatedSegmentVO;

import lombok.Data;

@Data
public class EEMMbrBillingDO implements EMDatedSegmentVO, Cloneable {

	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;
	
	@ColumnMapper(columnName = "MEMBER_ID", propertyName = "memberId")
	private String memberId;
	
	@ColumnMapper(columnName = "BILL_LAST_NAME", propertyName = "billLastName")
	private String billLastName;
	
	@ColumnMapper(columnName = "BILL_FIRST_NAME", propertyName = "billFirstName")
	private String billFirstName;
	
	@ColumnMapper(columnName = "BILL_MIDDLE_INIT", propertyName = "billMiddleInit")
	private String billMiddleInit;
	
	@ColumnMapper(columnName = "BILL_SUFFIX", propertyName = "billSuffix")
	private String billSuffix;
	
	@ColumnMapper(columnName = "BILL_PAY_METHOD_CD", propertyName = "billPayMethod")
	private String billPayMethod;
	
	@ColumnMapper(columnName = "ABA_ROUTING_NBR", propertyName = "abaRoutingNbr")
	private String abaRoutingNbr;
	
	@ColumnMapper(columnName = "BANK_ACCT_NBR", propertyName = "bankAcctNbr")
	private String bankAcctNbr;
	
	@ColumnMapper(columnName = "BANK_NAME", propertyName = "bankName")
	private String bankName;
	
	@ColumnMapper(columnName = "ACCOUNT_TYPE", propertyName = "accountType")
	private String accountType;
	
	@ColumnMapper(columnName = "NAME_ON_ACCT", propertyName = "nameOnAct")
	private String nameOnAct;
	
	@ColumnMapper(columnName = "DRAFT_DAY", propertyName = "draftDay")
	private String draftDay;
	
	@ColumnMapper(columnName = "DRAFT_OVERRIDE_AMT", propertyName = "draftOverrideAmt")
	private String draftOverrideAmt;
	
	@ColumnMapper(columnName = "BILL_FREQUENCY", propertyName = "billFrequency")
	private String billFrequency;
	
	@ColumnMapper(columnName = "OVERRIDE_IND", propertyName = "overrideInd")
	private String overrideInd;
	
	@ColumnMapper(columnName = "EFF_START_DATE", propertyName = "effStartDate")
	private String effStartDate;
	
	@ColumnMapper(columnName = "EFF_END_DATE", propertyName = "effEndDate")
	private String effEndDate;
	
	@ColumnMapper(columnName = "CREATE_TIME", propertyName = "createTime")
	private String createTime;
	
	@ColumnMapper(columnName = "CREATE_USERID", propertyName = "createUserId")
	private String createUserId;
	
	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;
	
	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserId")
	private String lastUpdtUserId;
	
	private String billPayMethodDesc;
	private String accountTypeDesc;
	private String billFrequencyDesc;

	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	public String getType() {
		return "";
	}

	public String getEffEndDateFrmt() {
		return DateFormatter.reFormat(effEndDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setEffEndDateFrmt(String effEndDate) {
		this.effEndDate = DateFormatter.reFormat(effEndDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getEffStartDateFrmt() {
		return DateFormatter.reFormat(effStartDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setEffStartDateFrmt(String effStartDate) {
		this.effStartDate = DateFormatter.reFormat(effStartDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public boolean isEndDateChange(Object obj) {

		EEMMbrBillingDO chkVO = (EEMMbrBillingDO) obj;

		return StringUtils.equals(chkVO.getEffStartDate(), this.effStartDate)
				&& StringUtils.equals(chkVO.getMemberId(), this.memberId)
				&& StringUtils.equals(chkVO.getCustomerId(), this.customerId)
				&& StringUtils.equals(chkVO.getOverrideInd(), this.overrideInd);
	}

	public boolean isForSamePeriod(Object obj) {

		EEMMbrBillingDO chkVO = (EEMMbrBillingDO) obj;

		return StringUtils.equals(chkVO.getEffStartDate(), this.effStartDate)
				&& StringUtils.equals(chkVO.getEffEndDate(), this.effEndDate)
				&& StringUtils.equals(chkVO.getMemberId(), this.memberId)
				&& StringUtils.equals(chkVO.getCustomerId(), this.customerId)
				&& StringUtils.equals(chkVO.getOverrideInd(), this.overrideInd);
	}

	public boolean isSame(Object obj) {

		EEMMbrBillingDO chkVO = (EEMMbrBillingDO) obj;

		return StringUtils.equals(chkVO.getBillPayMethod(), this.billPayMethod)
				&& StringUtils.equals(chkVO.getBillFirstName(), this.billFirstName)
				&& StringUtils.equals(chkVO.getBillLastName(), this.billLastName)
				&& StringUtils.equals(chkVO.getBillMiddleInit(), this.billMiddleInit)
				&& StringUtils.equals(chkVO.getEffStartDate(), this.effStartDate)
				&& StringUtils.equals(chkVO.getDraftDay(), this.draftDay)
				&& StringUtils.equals(chkVO.getDraftOverrideAmt(), this.draftOverrideAmt)
				&& StringUtils.equals(chkVO.getNameOnAct(), this.nameOnAct)
				&& StringUtils.equals(chkVO.getAccountType(), this.accountType)
				&& StringUtils.equals(chkVO.getAbaRoutingNbr(), this.abaRoutingNbr)
				&& StringUtils.equals(chkVO.getBankAcctNbr(), this.bankAcctNbr)
				&& StringUtils.equals(chkVO.getEffEndDate(), this.effEndDate)
				&& StringUtils.equals(chkVO.getMemberId(), this.memberId)
				&& StringUtils.equals(chkVO.getCustomerId(), this.customerId)
				&& StringUtils.equals(chkVO.getOverrideInd(), this.overrideInd)
				&& StringUtils.equals(chkVO.getCreateTime(), this.createTime)
				&& StringUtils.equals(chkVO.getCreateUserId(), this.createUserId)
				&& StringUtils.equals(chkVO.getLastUpdtTime(), this.lastUpdtTime)
				&& StringUtils.equals(chkVO.getLastUpdtUserId(), this.lastUpdtUserId);
	}

}
