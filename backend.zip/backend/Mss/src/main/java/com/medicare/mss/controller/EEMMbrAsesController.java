package com.medicare.mss.controller;

import java.text.ParseException;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.service.EEMMbrAsesService;
import com.medicare.mss.vo.EEMMbrAsesVO;

@RestController
@RequestMapping(ReqMappingConstants.MEMBER)
public class EEMMbrAsesController {

	@Autowired
	private EEMMbrAsesService mbrAsesService;

	@GetMapping(path = ReqMappingConstants.MBR_ASES_SEARCH)
	public ResponseEntity<JSONResponse> getMbrAses(@PathVariable(name = "mbrId") String memberId,
			@PathVariable(name = "showAll") String showAll) {
		List<EEMMbrAsesVO> mbrLisInfoList = mbrAsesService.getListFromContext(memberId, showAll);
		return sendResponse(mbrLisInfoList);
	}

	private ResponseEntity<JSONResponse> sendResponse(Object result) {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;

		if (Objects.isNull(result)) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
			jsonResponse.setData(result);
			jsonResponse.setMessage(EEMConstants.SUCCESS);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}

	@PostMapping(path = ReqMappingConstants.MBR_ASES_DELETE)
	public ResponseEntity<JSONResponse> mbrAsesDelete(@RequestBody EEMMbrAsesVO mbrAsesVO) {
		List<EEMMbrAsesVO> asesList = mbrAsesService.mbrAsesDelete(mbrAsesVO);
		return sendResponse(asesList);
	}

	@PostMapping(path = ReqMappingConstants.MBR_ASES_UPDATE)
	public ResponseEntity<JSONResponse> mbrAsesUpdate(@RequestBody EEMMbrAsesVO mbrAsesVO)
			throws ParseException, CloneNotSupportedException {
		List<EEMMbrAsesVO> asesList = mbrAsesService.mbrAsesUpdate(mbrAsesVO);
		return sendResponse(asesList);
	}

}
