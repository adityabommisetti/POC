package com.medicare.mss.aop;

import java.time.Duration;
import java.time.Instant;
import java.util.Objects;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.CacheService;

/**
 * This class methods gets executed before execution of application methods.
 * 
 * @author Wipro
 *
 */
@Aspect
@Configuration
public class EEMAspect {

	private static final Logger LOG = LoggerFactory.getLogger(EEMAspect.class);
	
	@Autowired
	private CacheService cacheService; 
	
	/**
	 * This method executes if the method exits.
	 * 
	 * @param joinPoint Holds method name
	 * 
	 * @param result    return value
	 * @throws ApplicationException 
	 */
	/*@AfterReturning(value = "com.medicare.mss.aop.CommonJoinPointConfig.allLayerExecution()", returning = "result")
	public void afterReturning(JoinPoint joinPoint, Object result) throws ApplicationException {
		LOG.info("CustomerId: {} and UserId: {}: method {} returned with value {}", sessionHelper.getUserInfo().getCustomerId(), sessionHelper.getUserInfo().getUserId(), joinPoint.getSignature(), Objects.nonNull(result) ? result.toString() : result);
	}*/

	/**
	 * This method executes if the method throws any exception.
	 * 
	 * @param joinPoint Holds method name
	 * 
	 * @param result    exception thrown
	 * @throws ApplicationException 
	 */
	@AfterThrowing(value = "com.medicare.mss.aop.CommonJoinPointConfig.allLayerExecution()", throwing = "exception")
	public void afterThrowing(JoinPoint joinPoint, Throwable exception) throws ApplicationException {
		Signature signature = joinPoint.getSignature();
		LOG.error("CustomerId: {} and UserId: {}: method {} exited with throwing {}",  cacheService.getUserInfo().getCustomerId(), cacheService.getUserInfo().getUserId(), signature, exception);
		
		if (LOG.isDebugEnabled()) {
			LOG.error("An exception occurred.", exception);
		}
		//exception.printStackTrace();
	}

	/**
	 * This methods executes before and after method executes
	 * 
	 * @param joinPoint Holds method name
	 * @return result of the method
	 * @throws Throwable
	 */
	@Around("com.medicare.mss.aop.CommonJoinPointConfig.allLayerExecution()")
	public Object logExecutionTime(ProceedingJoinPoint joinPoint) throws Throwable {
		LOG.info("CustomerId: {} and UserId: {}: method {} Started..", cacheService.getUserInfo().getCustomerId(), cacheService.getUserInfo().getUserId(), joinPoint.getSignature());

		Instant start = Instant.now();
		Object object = joinPoint.proceed();
		Instant finish = Instant.now();

		long timeTaken = Duration.between(start, finish).toMillis();

		LOG.info("CustomerId: {} and UserId: {}: method {} Finished Successfully in {} milliseconds..",  cacheService.getUserInfo().getCustomerId(), cacheService.getUserInfo().getUserId(), joinPoint.getSignature(),timeTaken);

		return object;
	}
	
}
