package com.medicare.mss.vo;

import java.io.Serializable;

import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
public class BillingDraftDetailVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3579454525846102277L;

	private String invoiceNbr;
	private int itemNbr;
	private int addNbr;
	private String memberId;
	private String lastName;
	private String sendDate;
	private String draftAmount;
	private String traceNumber;
	private String accountType;
	private String draftStatus;
	private String dueDate;
	private String settlementDate;
	private String responseDate;
	private String responseCode;
	private String responseMessage;
	private String routingNumber;
	private String accountNumber;
	private String bankName;
	private String responseTime;
	private String draftDay;
	private String createTime;
	private String createUserId;
	private String lastUpdtTime;
	private String lastUpdtUserId;

	public String getSendDateFrmt() {
		return DateFormatter.reFormat(sendDate, DateFormatter.DB2_TIMESTAMP, DateFormatter.MM_DD_YYYY);
	}

	public String getDueDateFrmt() {
		return DateFormatter.reFormat(dueDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getSettlementDateFrmt() {
		return DateFormatter.reFormat(settlementDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getResponseDateFrmt() {
		return DateFormatter.reFormat(responseDate, DateFormatter.DB2_TIMESTAMP, DateFormatter.MM_DD_YYYY);
	}

}
