package com.medicare.mss.domainobject;

import lombok.Data;

@Data
public class EEMApplEligibilityDO {
	
	private String partAEffDate;
	private String partBEffDate;
	private String partAEndDate;
	private String partBEndDate;
	private String partDEffDate;
	private String instStartDt;
	private String instEndDt;
	private String esrdStartDt;
	private String esrdEndDt;
	private String medicStartDt;
	private String medicEndDt;
	private String lastChkedTime;
	private String eligOverInd;
	
	private String customerId;
	private int applicationId;
	
}
