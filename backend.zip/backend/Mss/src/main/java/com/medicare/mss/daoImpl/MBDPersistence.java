package com.medicare.mss.daoImpl;

import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.domainobject.MbdDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.MBDRowMapper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.vo.MBD;

@Repository
public class MBDPersistence {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public MBD getHicMatch(String hicNbr, String lastName, String birthDt, String beqCheck, String isHicOrMbi,
			String mbi) {

		MbdDO mbdDO = get(hicNbr, beqCheck, isHicOrMbi, mbi);
		if (mbdDO != null) {
			MBD mbd = new MBD();
			BeanUtils.copyProperties(mbdDO, mbd);
			if (matches(mbd.getLastName(), lastName) || mbd.getBirthDate().equalsIgnoreCase(birthDt)) {
				return mbd;
			}
		}
		return null;

	}

	public MbdDO get(String hicNbr, String beqCheck, String isHicOrMbi, String mBI) {
		MbdDO mbdDO = null;
		List<MbdDO> mbdlst = null;
		String medId = isHicOrMbi.equalsIgnoreCase("mbi") ? mBI : hicNbr;
		beqCheck = trimToEmpty(beqCheck);
		try {

			StringBuilder sqlMBD = getSelectString(EEMConstants.EM_TABLE_MBD);
			String hicMbi = isHicOrMbi.equalsIgnoreCase("mbi") ? " MBI = ? " : " HIC_NBR = ? ";
			sqlMBD = sqlMBD.append(hicMbi);

			if (beqCheck.equalsIgnoreCase("") || beqCheck.equalsIgnoreCase("N")) {

				mbdlst = jdbcTemplate.query(sqlMBD.toString(), new MBDRowMapper(EEMConstants.EM_TABLE_MBD),
						trimToEmpty(medId));

			} else if (beqCheck.equals("Y")) {

				StringBuilder sqlBEQ = getSelectString(EEMConstants.EM_TABLE_BEQ);
				hicMbi = isHicOrMbi.equalsIgnoreCase("mbi") ? " ACTIVE_MBI = ? " : " HIC_NBR = ? ";
				sqlBEQ = sqlBEQ.append(hicMbi);

				mbdlst = jdbcTemplate.query(sqlBEQ.toString(), new MBDRowMapper(EEMConstants.EM_TABLE_BEQ),
						trimToEmpty(medId));

				if (mbdlst.isEmpty()) {
					mbdlst = jdbcTemplate.query(sqlMBD.toString(), new MBDRowMapper(EEMConstants.EM_TABLE_MBD),
							trimToEmpty(medId));
				}
			}

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "MBD Search failed");
		}

		if (!CollectionUtils.isEmpty(mbdlst)) {
			mbdDO = mbdlst.get(0);
		}
		return mbdDO;
	}

	public boolean matches(String mbdLastName, String lastName) {

		if (mbdLastName.length() > 6 && lastName.length() > 6) {
			mbdLastName = mbdLastName.substring(0, 6);
			lastName = lastName.substring(0, 6);

			if (lastName.equalsIgnoreCase(mbdLastName)) {
				return true;
			}

		} else if (mbdLastName.equalsIgnoreCase(lastName)) {
			return true;
		}

		return false;
	}

	public StringBuilder getSelectString(String table) {
		if (table.equalsIgnoreCase(EEMConstants.EM_TABLE_BEQ)) {
			return getBEQRTableQuery();
		} else {
			return getSelectString();
		}

	}

	public StringBuilder getSelectString() {
		return CommonUtils.buildQueryBuilder("SELECT Hic_nbr, Last_name, First_name, Middle_init,",
				" Gender_num_cd, Birth_date, Living_Status, Death_date,", " PrtA_Entitle_date, PrtA_Entitle_EDate,",
				" PrtB_Entitle_date, PrtB_Entitle_EDate,", " PrtA_Option, PrtB_Option, Enrollment_status,",
				" Hospice_ind, Hospice_sdate, Hospice_edate,", " Institutional_ind, Inst_sdate, Inst_edate,",
				" ESRD_ind, ESRD_sdate, ESRD_edate,", " Wrkaged_ind, Wrkaged_sdate, Wrkaged_edate,",
				" Medic_ind, Medic_sdate, Medic_edate,", " Race_cd, State_cd, County_cd, Zip_cd,",
				" EGHP_ind, Plan_id, Election_type,", " PBP_id, Segment_id, PBP_sdate, PBP_edate,",
				" Plan_Enroll_date, Plan_Disenrol_date, Plan_Drug_Ind,",
				" Prior_bic, GHP_Claim_nbr, Xref_claim_nbr, PrtD_elig_sdate,",
				" Subsidy_sdate1, Subsidy_edate1, Copay_level_id1, PrtD_premsubs_pct1,",
				" Subsidy_sdate2, Subsidy_edate2, Copay_level_id2, PrtD_premsubs_pct2,", " Calc_uncov_months,",
				" CoPlan_id, CoPlan_Enroll_dt, CoPlan_Disenrl_dt, CoPlan_Drug_Ind,",
				" PLAN_TYPE_CODE, COPLAN_PBP, COPLAN_TYPE_CODE, COPLAN_EGHP_IND",
				" ,UNLAWFUL_PRES_RECCNT, INCARCERATION_RECCNT,", " ENROLL_SRC_CD, COPLAN_ENROLL_SRC_CD,",
				" PRIOR1_PLAN_ID,PRIOR1_PLAN_ENROLL_DT,PRIOR1_PLAN_DISENROL_DT,",
				" PRIOR1_PLAN_DRUG_IND,PRIOR1_PLAN_PBP,PRIOR1_PLAN_TYPE_CODE,",
				" PRIOR1_PLAN_EGHP_IND,PRIOR1_ENROLL_SRC_CD, PRIOR2_PLAN_ID,",
				" PRIOR2_PLAN_ENROLL_DT,PRIOR2_PLAN_DISENROL_DT, PRIOR2_PLAN_DRUG_IND,",
				" PRIOR2_PLAN_PBP,PRIOR2_PLAN_TYPE_CODE,PRIOR2_PLAN_EGHP_IND,PRIOR2_ENROLL_SRC_CD,",
				" MBI,INACTIVE_MBI,CARA_RECCNT ,LAST_DUALSEP_DATE FROM MBD WHERE ");

	}

	private StringBuilder getBEQRTableQuery() {
		return CommonUtils.buildQueryBuilder("SELECT Hic_nbr, Last_name, First_name, Middle_init,",
				" Gender_num_cd, Birth_date, Living_Status, Death_date,", " PrtA_Entitle_date, PrtA_Entitle_EDate,",
				" PrtB_Entitle_date, PrtB_Entitle_EDate,", " PrtA_Option, PrtB_Option, Enrollment_status,",
				" Hospice_ind, Hospice_sdate, Hospice_edate,", " Institutional_ind, Inst_sdate, Inst_edate,",
				" ESRD_ind, ESRD_sdate, ESRD_edate,", " Wrkaged_ind, Wrkaged_sdate, Wrkaged_edate,",
				" Medic_ind, Medic_sdate, Medic_edate,", " Race_cd, State_cd, County_cd, Zip_cd,",
				" EGHP_ind, Plan_id, Election_type,", " PBP_id, Segment_id, PBP_sdate, PBP_edate,",
				" Plan_Enroll_date, Plan_Disenrol_date, Plan_Drug_Ind,",
				" Prior_bic, GHP_Claim_nbr, Xref_claim_nbr, PrtD_elig_sdate,",
				" Subsidy_sdate1, Subsidy_edate1, Copay_level_id1, PrtD_premsubs_pct1,",
				" Subsidy_sdate2, Subsidy_edate2, Copay_level_id2, PrtD_premsubs_pct2,", " Calc_uncov_months,",
				" CoPlan_id, CoPlan_Enroll_dt, CoPlan_Disenrl_dt, CoPlan_Drug_Ind,",
				" PLAN_TYPE_CODE, COPLAN_PBP, COPLAN_TYPE_CODE, COPLAN_EGHP_IND,",
				" UNLAWFUL_PRES_RECCNT, INCARCERATION_RECCNT,",
				" PLAN_ENROL_SRCE_CD AS ENROLL_SRC_CD, COPLAN_ENROL_SRCE_CD AS COPLAN_ENROLL_SRC_CD,",
				" PRIOR_PLAN_ID1 AS PRIOR1_PLAN_ID, PRIOR_ENROLL_DATE1 AS PRIOR1_PLAN_ENROLL_DT,",
				" PRIOR_DISENROL_DATE1 AS PRIOR1_PLAN_DISENROL_DT, PRIOR_PARTD_IND1 AS PRIOR1_PLAN_DRUG_IND,",
				" PRIOR_PBP1 AS PRIOR1_PLAN_PBP, PRIOR_PLAN_TYPE_CODE1 AS PRIOR1_PLAN_TYPE_CODE,",
				" PRIOR_EGHP1 AS PRIOR1_PLAN_EGHP_IND, PRIOR_ENROLL_SRCE_CD1 AS PRIOR1_ENROLL_SRC_CD,",
				" PRIOR_PLAN_ID2 AS PRIOR2_PLAN_ID, PRIOR_ENROLL_DATE2 AS PRIOR2_PLAN_ENROLL_DT,",
				" PRIOR_DISENROL_DATE2 AS PRIOR2_PLAN_DISENROL_DT, PRIOR_PARTD_IND2 AS PRIOR2_PLAN_DRUG_IND,",
				" PRIOR_PBP2 AS PRIOR2_PLAN_PBP, PRIOR_PLAN_TYPE_CODE2 AS PRIOR2_PLAN_TYPE_CODE,",
				" PRIOR_EGHP2 AS PRIOR2_PLAN_EGHP_IND, PRIOR_ENROLL_SRCE_CD2 AS PRIOR2_ENROLL_SRC_CD",
				" ,ACTIVE_MBI AS MBI ,CARA_RECCNT", // Modified for BEQR SSNRI CHANGES
				",DUALS_SEP_DATE AS LAST_DUALSEP_DATE FROM BEQR WHERE ");
	}

	public boolean checkDemoAccount(String custNbr) {
		custNbr = trimToEmpty(custNbr);
		if (custNbr.equals("110000") || custNbr.startsWith("99"))
			return true;
		return false;
	}

}
