package com.medicare.mss.controller;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.service.EEMApplLepService;
import com.medicare.mss.service.EEMLepAttestService;
import com.medicare.mss.vo.EEMApplLepMasterVO;
import com.medicare.mss.vo.EEMLepAttestCallMasterVO;
import com.medicare.mss.vo.EEMLepAttestCcfVO;
import com.medicare.mss.vo.EEMLepAttestCopyVO;
import com.medicare.mss.vo.EEMLepAttestInfoVO;
import com.medicare.mss.vo.EEMLepPtnlUncovMthsVO;

@RestController
@RequestMapping("/appl")
public class EEMApplLepController {

	@Autowired
	private EEMApplLepService lepService;
	
	@Autowired
	private EEMLepAttestService attestService;

	@PostMapping(value = ReqMappingConstants.APPL_LEP)
	public ResponseEntity<JSONResponse> getApplLepDetails(@RequestBody Map<String, String> searchMap) throws ApplicationException {

		EEMApplLepMasterVO lepInfoVo = new EEMApplLepMasterVO();
		lepInfoVo.setPrimaryId((StringUtils.trimToEmpty(searchMap.get("applId"))));
		lepInfoVo.setHicNbr(StringUtils.trimToEmpty(searchMap.get("hic_Nbr")));
		lepInfoVo.setMbi(StringUtils.trimToEmpty(searchMap.get("mbi")));
		lepInfoVo.setApplStatus(StringUtils.trimToEmpty(searchMap.get("applStatus")));
		lepInfoVo.setReqDtCov(StringUtils.trimToEmpty(searchMap.get("reqDtCov")));

		boolean lepFound = lepService.getApplLepDetails(lepInfoVo);

		return sendResponse(lepFound ? lepInfoVo : null);

	}

	@GetMapping(value = ReqMappingConstants.APPL_LEP_GET_UNCOV)
	public ResponseEntity<JSONResponse> getUnCovMonths(@PathVariable("applId") String applId,
			@PathVariable("overrideInd") String overrideInd) throws ApplicationException {

		List<EEMLepPtnlUncovMthsVO> unCovMonthList = lepService.getPtnlUnCovMnthsApplLep(applId ,overrideInd ,false);
		boolean isEmpty = CollectionUtils.isEmpty(unCovMonthList);

		return sendResponse(!isEmpty ? unCovMonthList : null);

	}

	@PostMapping(value = ReqMappingConstants.APPL_LEP_ADD_UNCOV)
	public ResponseEntity<JSONResponse> addUnCovMonth(@RequestBody EEMLepPtnlUncovMthsVO unCovVo) throws ApplicationException {

		EEMLepPtnlUncovMthsVO lepPtnlUncovMthsVO = lepService.lepUnCovPtnlMnthUpdate(unCovVo,false);

		return sendResponse(lepPtnlUncovMthsVO);

	}

	@PostMapping(value = ReqMappingConstants.APPL_LEP_DELETE_UNCOV)
	public ResponseEntity<JSONResponse> deleteUnCovMonth(@RequestBody EEMLepPtnlUncovMthsVO unCovVo)
			throws ApplicationException {

		Map<String, String> response = lepService.lepUnCovPtnlMnthDelete(unCovVo,false);

		return sendResponse(response);

	}

	@GetMapping(value = ReqMappingConstants.APPL_LEP_GET_CCF_DETAILS)
	public ResponseEntity<JSONResponse> getCcfDetails(@PathVariable("applId") String applId,
			@PathVariable("overrideInd") String overrideInd) throws ApplicationException {

		List<EEMLepAttestCcfVO> ccfList = attestService.getCCfDetails(overrideInd, applId,false);

		return sendResponse(ccfList);
	}

	@PostMapping(value = ReqMappingConstants.APPL_LEP_DELETE_CCF)
	public ResponseEntity<String> deleteCCfDetails(@RequestBody EEMLepAttestCcfVO ccfAttestVo) throws ApplicationException {

		boolean isUpdated = attestService.applAttnInfoDelete(ccfAttestVo,false);
		if (isUpdated) {
			return ResponseEntity.status(200).body("DELETED SUCCESSFULLY");
		}
		return ResponseEntity.status(204).body(null);

	}

	@PostMapping(value = ReqMappingConstants.APPL_LEP_UPDATE_CCF)
	public ResponseEntity<JSONResponse> updateCcfAttestation(@RequestBody EEMLepAttestInfoVO attestInfoVO)
			throws ApplicationException {

		EEMLepAttestInfoVO applLepAttestInfoVO = attestService.applLepAttestInfoUpdate(attestInfoVO,false);

		return sendResponse(applLepAttestInfoVO);
	}

	@PostMapping(value = ReqMappingConstants.APPL_LEP_ADD_CCF)
	public ResponseEntity<JSONResponse> addCcfDetails(@RequestBody EEMLepAttestCcfVO attestVO) throws ApplicationException {

		EEMLepAttestCcfVO attestCcfVO = attestService.applLepAttestAdd(attestVO,false);

		return sendResponse(attestCcfVO);

	}

	@PostMapping(value = ReqMappingConstants.APPL_LEP_COPY_ATTEST)
	public ResponseEntity<JSONResponse> copyCcfToUnCovMonth(@RequestBody EEMLepAttestCopyVO copyVo)
			throws ApplicationException {

		EEMLepAttestCopyVO response = attestService.applLepAttestCopy(copyVo,false);
		return sendResponse(response);

	}

	@PostMapping(value = ReqMappingConstants.APPL_LEP_UPDATE_ATTEST_CALL)
	public ResponseEntity<JSONResponse> updateAttestCall(@RequestBody EEMLepAttestCallMasterVO attestCallMasterVO)
			throws ApplicationException {

		EEMLepAttestCallMasterVO callMasterVO = lepService.updateAttestCall(attestCallMasterVO,false);
		return sendResponse(callMasterVO);

	}

	private ResponseEntity<JSONResponse> sendResponse(Object object) {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;
		if (null == object) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			jsonResponse.setData(null);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
			jsonResponse.setMessage(EEMConstants.BLANK);
			jsonResponse.setData(object);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}

	@PostMapping(value = ReqMappingConstants.APPL_LEP_GET_PDF)
	public ResponseEntity<JSONResponse> displayDocumentFromDB(@RequestBody Map<String, String> searchParamMap) {
		JSONResponse jsonResponse = new JSONResponse();

		try {
			byte[] blobByte = lepService.getDisplayDocument(searchParamMap);

			if (null != blobByte) {
				/*
				 * //Below commented code can be use for create the pdf file from byte[] in our
				 * local drive to verify
				 * 
				 * 
				 */
				jsonResponse.setStatus("OK");
				jsonResponse.setMessage("");
				jsonResponse.setData(blobByte);

				return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
			} else {
				jsonResponse.setMessage(EEMConstants.DATA_NOT_FOUND);
				jsonResponse.setData(null);
				return new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
			}
		} catch (Exception exp) {

			exp.printStackTrace();
		}

		jsonResponse.setMessage(EEMConstants.DATA_NOT_FOUND);
		jsonResponse.setData(null);
		return new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);

	}
}
