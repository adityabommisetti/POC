package com.medicare.mss.dao;

import com.medicare.mss.vo.EMDatedSegmentVO;

public interface EEMMbrBaseDAO {

	/**
	 * This method overrides the old LTC record.
	 * 
	 * @param eemMbrLtcInfoDO
	 *            member LTC domain object
	 * @param userId
	 *            user id
	 * @return true if override success otherwise false @
	 */
	int setOverride(EMDatedSegmentVO emDatedSegmentVO, String userId);

	/**
	 * this method is to insert the Member LTC Info.
	 * 
	 * @param eemMbrLtcInfoDO
	 *            member LTC domain object
	 * @return true if insert success otherwise false @
	 */
	int insertMbr(EMDatedSegmentVO emDatedSegmentVO);

}
