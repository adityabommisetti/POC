/*
 * $Id: DemographicFormatter.java,v 1.1 2014/06/26 07:46:51 praveen Exp $
 */
package com.medicare.mss.util;

public class DemographicFormatter {

	public static String formatSSN(String ssn) {
		
		if (ssn != null) {
			if (ssn.length() == 9) {
				String newSSN = ssn.substring(0,3) + "-" + ssn.substring(3,5) + "-" + ssn.substring(5);
				return newSSN;
			}
		}
		return ssn;
	}
	
	public static String unFormatSSN(String ssn) {
		
		if (ssn != null) {
			StringBuffer sb = new StringBuffer();
			int len = ssn.length();
			char c;
			for (int i = 0; i < len; i++) {
				c = ssn.charAt(i);
				if (Character.isDigit(c))
					sb.append(c);
			}
			return sb.toString();
		}
		return ssn;
	}
}
