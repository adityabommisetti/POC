package com.medicare.mss.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EMWFCaseQueueVO implements Serializable {

	private static final long serialVersionUID = -639486089574548713L;

	private String customerId;
	private String queueCd;
	private String createTime;
	private String queueName;
	private String queuePurpose;
	private String queueDesc;
	private String compDays;
	private String queuePrty;
	private String atRiskDays;
	private String overideInd;
	private String lastUpdtUserID;
	private String lastUpdtTime;
	private String lastUpdtUserName;

}
