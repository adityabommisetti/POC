package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMMbrTrrLogDO {

	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;

	@ColumnMapper(columnName = "MEMBER_ID", propertyName = "memberId")
	private String memberId;

	@ColumnMapper(columnName = "LOG_TIME", propertyName = "logTime")
	private String logTime;

	@ColumnMapper(columnName = "PROCESS_DATE", propertyName = "processDate")
	private String processDate;

	@ColumnMapper(columnName = "EFFECTIVE_DATE", propertyName = "effectiveDate")
	private String effectiveDate;

	@ColumnMapper(columnName = "TRANSACTION_CODE", propertyName = "transactionCode")
	private String transactionCode;

	@ColumnMapper(columnName = "TRANS_REPLY_CD", propertyName = "transReplyCd")
	private String transReplyCd;

	@ColumnMapper(columnName = "TRANS_REPLY_SDESC", propertyName = "transReplyDesc")
	private String transReplyDesc;

	@ColumnMapper(columnName = "UPDATE_YN", propertyName = "updateYN")
	private String updateYN;

	@ColumnMapper(columnName = "UPDATE_TYPE", propertyName = "updateType")
	private String updateType;

	@ColumnMapper(columnName = "FIELD_NAME", propertyName = "fieldName")
	private String fieldName;

	@ColumnMapper(columnName = "RELATED_FIELD_BEFORE", propertyName = "relatedFieldBefore")
	private String relatedFieldBefore;

	@ColumnMapper(columnName = "RELATED_FIELD_AFTER", propertyName = "relatedFieldAfter")
	private String relatedFieldAfter;

	@ColumnMapper(columnName = "SOURCE_ID", propertyName = "sourceId")
	private String sourceId;

	@ColumnMapper(columnName = "ACC_REJ_IND", propertyName = "accRejInd")
	private String accRejInd;

	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserId")
	private String lastUpdtUserId;

	@ColumnMapper(columnName = "TRANS_REPLY_DEFINITION", propertyName = "transReplyDefinition")
	private String transReplyDefinition;

	@ColumnMapper(columnName = "TRR_VAR_DATA_PRESENT", propertyName = "isTrrVarDataPresent")
	private Boolean isTrrVarDataPresent;

}
