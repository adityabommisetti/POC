package com.medicare.mss.vo;

import java.io.Serializable;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode(callSuper = false)
public class EEMMbrCobVO extends BaseVO implements EMDatedSegmentVO, Cloneable, Serializable {

	private static final long serialVersionUID = -5564808759924910226L;

	private String memberId;
	private String cobType;
	private String cobDesc;
	private String ohiInd;
	private String ohiDesc;
	private String rxGrp;
	private String rxName;
	private String rxId;
	private String rxBin;
	private String rxPcn;
	private String overrideInd;
	private String effStartDate;
	private String effEndDate;
	private String cobValidation;

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	public String getEffEndDateFrmt() {
		return DateFormatter.reFormat(effEndDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setEffEndDateFrmt(String effEndDate) {
		this.effEndDate = DateFormatter.reFormat(effEndDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getEffStartDateFrmt() {
		return DateFormatter.reFormat(effStartDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setEffStartDateFrmt(String effStartDate) {
		this.effStartDate = DateFormatter.reFormat(effStartDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	@Override
	public String getType() {
		return cobType;
	}

	public boolean isSameCobType(Object obj) {

		EEMMbrCobVO chkVO = (EEMMbrCobVO) obj;

		return StringUtils.equals(chkVO.getEffStartDate(), this.effStartDate)
				&& StringUtils.equals(chkVO.getMemberId(), this.memberId)
				&& StringUtils.equals(chkVO.getCustomerId(), this.customerId);
	}

	@Override
	public boolean isEndDateChange(Object obj) {

		EEMMbrCobVO chkVO = (EEMMbrCobVO) obj;

		return StringUtils.equals(chkVO.getEffStartDate(), this.effStartDate)
				&& StringUtils.equals(chkVO.getCobType(), this.cobType)
				&& StringUtils.equals(chkVO.getOhiInd(), this.ohiInd)
				&& StringUtils.equals(chkVO.getRxGrp(), this.rxGrp)
				&& StringUtils.equals(chkVO.getRxName(), this.rxName) && StringUtils.equals(chkVO.getRxId(), this.rxId)
				&& StringUtils.equals(chkVO.getRxBin(), this.rxBin) && StringUtils.equals(chkVO.getRxPcn(), this.rxPcn)
				&& StringUtils.equals(chkVO.getMemberId(), this.memberId)
				&& StringUtils.equals(chkVO.getCustomerId(), this.customerId)
				&& StringUtils.equals(chkVO.getOverrideInd(), this.overrideInd);
	}

	@Override
	public boolean isForSamePeriod(Object obj) {

		EEMMbrCobVO chkVO = (EEMMbrCobVO) obj;

		return StringUtils.equals(chkVO.getCobType(), this.cobType)
				&& StringUtils.equals(chkVO.getEffStartDate(), this.effStartDate)
				&& StringUtils.equals(chkVO.getEffEndDate(), this.effEndDate)
				&& StringUtils.equals(chkVO.getMemberId(), this.memberId)
				&& StringUtils.equals(chkVO.getCustomerId(), this.customerId)
				&& StringUtils.equals(chkVO.getOverrideInd(), this.overrideInd);
	}

	@Override
	public boolean isSame(Object obj) {

		EEMMbrCobVO chkVO = (EEMMbrCobVO) obj;

		return StringUtils.equals(chkVO.getCobType(), this.cobType)
				&& StringUtils.equals(chkVO.getOhiInd(), this.ohiInd)
				&& StringUtils.equals(chkVO.getRxGrp(), this.rxGrp)
				&& StringUtils.equals(chkVO.getRxName(), this.rxName) && StringUtils.equals(chkVO.getRxId(), this.rxId)
				&& StringUtils.equals(chkVO.getRxBin(), this.rxBin) && StringUtils.equals(chkVO.getRxPcn(), this.rxPcn)
				&& StringUtils.equals(chkVO.getEffStartDate(), this.effStartDate)
				&& StringUtils.equals(chkVO.getEffEndDate(), this.effEndDate)
				&& StringUtils.equals(chkVO.getMemberId(), this.memberId)
				&& StringUtils.equals(chkVO.getCustomerId(), this.customerId)
				&& StringUtils.equals(chkVO.getOverrideInd(), this.overrideInd)
				&& StringUtils.equals(chkVO.getCreateUserId(), this.createTime)
				&& StringUtils.equals(chkVO.getCreateUserId(), this.createUserId)
				&& StringUtils.equals(chkVO.getLastUpdtTime(), this.lastUpdtTime)
				&& StringUtils.equals(chkVO.getLastUpdtUserId(), this.lastUpdtUserId);
	}

}
