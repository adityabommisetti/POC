/**
 * 
 */
package com.medicare.mss.vo;

import java.io.Serializable;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.DateUtil;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author DU20098149
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode(callSuper = false)
public class EEMMbrLepInfoVO extends BaseVO implements EMDatedSegmentVO, Cloneable, Serializable {

	private static final long serialVersionUID = -7713403706397782110L;

	private String attestationRecChannel;
	private String attestationRecDate;
	private String attestLock;
	private String attestStatus;
	private String attstLockInd;
	private String birthDate;
	private String mbr65BirthDt;
	private String creditableCoverageFlag;
	private String editOverrideInd;
	private String effEndDate;
	private String effStartDate;
	private String enrollEffStartDate;
	private String firstName;
	private String hicn;
	private String hicNBRVal;
	private String incompAttestLetRecDate;
	private String lepAmt;
	private String lepType;
	private String lepWaivedAmt;
	private String maOnly;
	private String maValue;
	private String mbi;
	private String memberId;
	private String message;
	private int nbrUncovMonths;
	private String notifiedMemberAppeal;
	private String numUncocTransReason;
	private String overrideInd;
	private String pbpId;
	private String planDesignation;
	private String planId;
	private String tempEnrollEffStartDate;
	private String transactionDueDate;
	private String trg73Ind;
	private String uncovStDate;

	public EEMMbrLepInfoVO() {
		effStartDate = "";
		effEndDate = "";
		lepAmt = "";
		lepWaivedAmt = "";
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	public String getEffEndDateFrmt() {
		return DateFormatter.reFormat(effEndDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public String getEffStartDateFrmt() {
		return DateFormatter.reFormat(effStartDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	@Override
	public String getType() {
		return "LEP";
	}

	@Override
	public boolean isEndDateChange(Object obj) {

		EEMMbrLepInfoVO chkVO = (EEMMbrLepInfoVO) obj;
		return StringUtils.equalsIgnoreCase(chkVO.getEffStartDate(), this.effStartDate)
				&& (StringUtils.equalsIgnoreCase(chkVO.getCreditableCoverageFlag(), this.creditableCoverageFlag))
				&& (chkVO.getNbrUncovMonths() == this.nbrUncovMonths)
				&& (StringUtils.equalsIgnoreCase(chkVO.getLepAmt(), this.lepAmt))
				&& (StringUtils.equalsIgnoreCase(chkVO.getLepWaivedAmt(), this.lepWaivedAmt))
				&& (StringUtils.equalsIgnoreCase(chkVO.getMemberId(), this.memberId))
				&& (StringUtils.equalsIgnoreCase(chkVO.getCustomerId(), this.customerId))
				&& (StringUtils.equalsIgnoreCase(chkVO.getOverrideInd(), this.overrideInd));
	}

	@Override
	public boolean isForSamePeriod(Object obj) {

		EEMMbrLepInfoVO chkVO = (EEMMbrLepInfoVO) obj;
		return StringUtils.equals(chkVO.getEffStartDate(), this.effStartDate)
				&& StringUtils.equals(chkVO.getEffEndDate(), (this.effEndDate))
				&& StringUtils.equals(chkVO.getMemberId(), this.memberId)
				&& StringUtils.equals(chkVO.getCustomerId(), this.customerId)
				&& StringUtils.equals(chkVO.getOverrideInd(), this.overrideInd);
	}

	@Override
	public boolean isSame(Object obj) {

		EEMMbrLepInfoVO chkVO = (EEMMbrLepInfoVO) obj;
		return StringUtils.equals(chkVO.getEffStartDate(), this.effStartDate)
				&& StringUtils.equals(chkVO.getEffEndDate(), this.effEndDate)
				&& (chkVO.getNbrUncovMonths() == this.nbrUncovMonths)
				&& StringUtils.equals(chkVO.getLepAmt(), this.lepAmt)
				&& StringUtils.equals(chkVO.getLepWaivedAmt(), this.lepWaivedAmt)
				&& StringUtils.equals(chkVO.getMemberId(), this.memberId)
				&& StringUtils.equals(chkVO.getCustomerId(), this.customerId)
				&& StringUtils.equals(chkVO.getOverrideInd(), this.overrideInd)
				&& StringUtils.equals(chkVO.getCreateTime(), this.createTime)
				&& StringUtils.equals(chkVO.getCreateUserId(), this.createUserId)
				&& StringUtils.equals(chkVO.getLastUpdtTime(), this.lastUpdtTime)
				&& StringUtils.equals(chkVO.getLastUpdtUserId(), this.lastUpdtUserId);
	}

	public void setEffEndDateFrmt(String effEndDate) {
		this.effEndDate = DateFormatter.reFormat(effEndDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public void setEffStartDateFrmt(String effStartDate) {
		this.effStartDate = DateFormatter.reFormat(effStartDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public void setBirthDate(String birthDate) {
		if (birthDate != null && !birthDate.isEmpty()) {
			try {
				this.mbr65BirthDt = DateMath.addYear(DateUtil.changedDateFormatForMonth(birthDate), 65);
				this.mbr65BirthDt = DateFormatter.reFormat(DateFormatter.dateFilter(this.mbr65BirthDt),
						DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		this.birthDate = DateFormatter.reFormat(birthDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public String getMbr65BirthDt() {
		return mbr65BirthDt;
	}

}
