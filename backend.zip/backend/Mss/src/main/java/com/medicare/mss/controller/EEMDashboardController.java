package com.medicare.mss.controller;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.service.EEMDashboardService;
import com.medicare.mss.vo.EEMDashboardApplStatusVO;
import com.medicare.mss.vo.EEMDashboardCmsVO;
import com.medicare.mss.vo.EEMDashboardLisMbrDistVO;
import com.medicare.mss.vo.EMWFMasterVO;

@RestController
@RequestMapping("/dashboard")
public class EEMDashboardController {

	@Autowired
	private EEMDashboardService dashboardService;

	@PostMapping(ReqMappingConstants.DASHBOARD_PRE_ENROLL_STATUS)
	public ResponseEntity<JSONResponse> getPreEnrollStatus(@RequestBody Map<String, String> searchParamMap) {
		Map<String, List<EEMDashboardApplStatusVO>> preEnrollStatus = dashboardService
				.getPreEnrollStatus(searchParamMap);
		return sendResponse(preEnrollStatus);
	}

	@GetMapping(ReqMappingConstants.DASHBOARD_APPL_AGEING)
	public ResponseEntity<JSONResponse> getApplAgeing() {
		Map<String, List<EEMDashboardApplStatusVO>> applicationAgeing = dashboardService.getApplicationAgeing();
		return sendResponse(applicationAgeing);
	}

	@GetMapping(ReqMappingConstants.DASHBOARD_RFI_TRACKING)
	public ResponseEntity<JSONResponse> getRFITrackingStatus() {
		Map<String, List<EEMDashboardApplStatusVO>> rfiTrackingStatus = dashboardService.getRFITrackingStatus();
		return sendResponse(rfiTrackingStatus);
	}

	@GetMapping(ReqMappingConstants.DASHBOARD_CMS_STATUS)
	public ResponseEntity<JSONResponse> getCmsStatus() {
		Map<String, List<EEMDashboardCmsVO>> cmsStatus = dashboardService.getCmsStatus();
		return sendResponse(cmsStatus);
	}

	@GetMapping(ReqMappingConstants.DASHBOARD_CMS_TRANSACTION)
	public ResponseEntity<JSONResponse> getCmsTransactin() {
		Map<String, List<EEMDashboardCmsVO>> cmsTransaction = dashboardService.getCmsTransactionStatus();
		return sendResponse(cmsTransaction);
	}

	@PostMapping(ReqMappingConstants.DASHBOARD_MBR_SHP_DIS)
	public ResponseEntity<JSONResponse> mbrShipDistribution(@RequestBody List<String> planIds) {
		return sendResponse(dashboardService.mbrShipDistribution(planIds));
	}

	@PostMapping(ReqMappingConstants.DASHBOARD_APP_DIS)
	public ResponseEntity<JSONResponse> appDistribution(@RequestBody List<String> planIds) {
		return sendResponse(dashboardService.appDistribution(planIds));
	}

	@PostMapping(ReqMappingConstants.DASHBOARD_LIS_MBR_DIS)
	public ResponseEntity<JSONResponse> lisMbrDistribution(@RequestBody EEMDashboardLisMbrDistVO lisDistVo) {
		return sendResponse(dashboardService.lisMbrDistribution(lisDistVo));
	}

	@GetMapping(ReqMappingConstants.DASHBOARD_LTR_VOL_DIS)
	public ResponseEntity<JSONResponse> letterVolumeDistribution() {
		return sendResponse(dashboardService.letterVolumeDistribution());
	}

	@GetMapping(ReqMappingConstants.DASHBOARD_SPCL_STATUS_DIS)
	public ResponseEntity<JSONResponse> specialStatusDistribution() {
		return sendResponse(dashboardService.specialStatusDistribution());
	}

	@PostMapping(ReqMappingConstants.DASHBOARD_FILE_LOAD_ERR_DIS)
	public ResponseEntity<JSONResponse> fileLoadErrDistribution(@RequestBody Map<String, String> searchParamMap) {
		return sendResponse(dashboardService.fileLoadErrDistribution(searchParamMap));
	}

	@GetMapping(ReqMappingConstants.DASHBOARD_DIS_PLAN_IDS)
	public ResponseEntity<JSONResponse> getDistinctPlansForCustomer() {
		return sendResponse(dashboardService.getDistinctPlansForCustomer());
	}

	private ResponseEntity<JSONResponse> sendResponse(Object result) {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;

		if (Objects.isNull(result)) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setData(result);
			jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
			jsonResponse.setMessage(getStatusMessage(result));
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}

	private String getStatusMessage(Object result) {
		String msg = EEMConstants.SUCCESS;
		if (result instanceof EMWFMasterVO && StringUtils.isNotBlank(((EMWFMasterVO) result).getMessage())) {
			msg = ((EMWFMasterVO) result).getMessage();
		}
		return msg;
	}

}
