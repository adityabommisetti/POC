package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMApplErrorDO {

	@ColumnMapper(columnName = "FORM_FIELD", propertyName = "formField")
	private String formField;
	
	@ColumnMapper(columnName = "ERROR_CD", propertyName = "errorCd")
	private String errorCd;
	
	@ColumnMapper(columnName = "ERROR_MESSAGE", propertyName = "errorMsg")
	private String errorMsg;
	
	@ColumnMapper(columnName = "ERROR_DATA", propertyName = "errorData")
	private String errorData;
	
	@ColumnMapper(columnName = "FIELD_NBR", propertyName = "fieldNbr")
	private String fieldNbr;
	
	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;
	
	@ColumnMapper(columnName = "APPLICATION_ID", propertyName = "applicationId")
	private int applicationId;
	
	@ColumnMapper(columnName = "RFI_IND", propertyName = "rfiInd")
	private String rfiInd;
	
	private String errorStatus;
	private String applDate;

}
