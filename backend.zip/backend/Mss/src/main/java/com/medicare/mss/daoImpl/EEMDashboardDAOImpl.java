package com.medicare.mss.daoImpl;

import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMDashboardDAO;
import com.medicare.mss.domainobject.EEMDashboardAppDistDO;
import com.medicare.mss.domainobject.EEMDashboardApplStatusDO;
import com.medicare.mss.domainobject.EEMDashboardCmsDO;
import com.medicare.mss.domainobject.EEMDashboardFileLoadErrDisDO;
import com.medicare.mss.domainobject.EEMDashboardLisMbrDistDO;
import com.medicare.mss.domainobject.EEMDashboardLtrVolDisDO;
import com.medicare.mss.domainobject.EEMDashboardMbrShipDO;
import com.medicare.mss.domainobject.EEMDashboardSpclStatDisDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.vo.EEMDashboardLisMbrDistVO;

@Repository
public class EEMDashboardDAOImpl implements EEMDashboardDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Override
	public List<EEMDashboardApplStatusDO> getApplStatus(String customerId, String status,
			Map<String, String> searchParamMap) {

		String startDate = DateFormatter.reFormat(trimToEmpty(searchParamMap.get("startDate")),
				DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
		String endDate = DateFormatter.reFormat(trimToEmpty(searchParamMap.get("endDate")), DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);

		List<EEMDashboardApplStatusDO> preEnrollStatus;
		try {
			StringBuilder sql = CommonUtils.buildQueryBuilder("SELECT DISTINCT A.APPLICATION_ID,",
					" (CASE WHEN A.MBI !='' THEN A.MBI ELSE A.HIC_NBR END) AS MEDICARE_ID, A.APPLICATION_TYPE, A.APPLICATION_STATUS,",
					" A.FIRST_NAME, A.LAST_NAME, A.BIRTH_DATE, A.APPLICATION_DATE, P.PRODUCT_NAME, W.CURRENT_USER_ID");
			if (status.equalsIgnoreCase(EEMConstants.RFI_TRACKING_STATUS)) {
				sql.append(", T.EFFECTIVE_DATE");
			}
			sql.append(" FROM EM_APPLICATION A");
			if (status.equalsIgnoreCase(EEMConstants.PRE_ENROLL_STATUS)) {
				sql.append(" LEFT JOIN EM_APPLICATIONSTATUS AST ON AST.APPLICATION_STATUS = A.APPLICATION_STATUS");
			}
			if (status.equalsIgnoreCase(EEMConstants.RFI_TRACKING_STATUS)) {
				sql.append(" LEFT JOIN EM_APPL_TRIGGER T ON T.CUSTOMER_ID = A.CUSTOMER_ID AND");
				sql.append(" T.APPLICATION_ID = A.APPLICATION_ID AND T.TRIGGER_TYPE = 'FUA' AND");
				sql.append(" T.TRIGGER_CODE = 'RFI' AND T.TRIGGER_STATUS IN ('OPEN','ACTIVE')");
			}
			sql.append(
					" LEFT JOIN EM_APPL_PLAN AP ON AP.CUSTOMER_ID = A.CUSTOMER_ID AND AP.APPLICATION_ID = A.APPLICATION_ID"
							+ " LEFT JOIN EM_PRODUCT_NAME P ON P.CUSTOMER_ID = AP.CUSTOMER_ID AND P.PRODUCT_ID = AP.TO_PRODUCT_ID"
							+ " AND AP.EFFECTIVE_DATE BETWEEN P.PRODNAME_START_DATE AND P.PRODNAME_END_DATE"
							+ " LEFT JOIN EM_WF_CASE W ON W.CUSTOMER_ID = A.CUSTOMER_ID AND W.APPLICATION_ID = A.APPLICATION_ID AND"
							+ " W.OVERRIDE_IND = 'N' AND W.CASE_STATUS = 'OPEN' WHERE A.CUSTOMER_ID = ?");

			ArrayList<String> parmList = new ArrayList<>();
			parmList.add(customerId);
			if (status.equalsIgnoreCase(EEMConstants.APPLICATION_AGEING)) {
				sql.append(" AND A.APPLICATION_DATE >= VARCHAR_FORMAT(CURRENT_DATE-10 DAY, 'YYYYMMDD')");
			}
			if (status.equalsIgnoreCase(EEMConstants.RFI_TRACKING_STATUS)) {
				sql.append(" AND A.APPLICATION_STATUS IN ('INCRFIELCT', 'INCRFIGEN', 'INCRFIREQ', 'INCRFITRG',");
				sql.append(" 'RFINORESP', 'HOLD', 'INCOMPLETE')");
			}
			if (StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
				sql.append(" AND A.APPLICATION_DATE BETWEEN ? AND ?");
				parmList.add(startDate);
				parmList.add(endDate);
			}
			sql.append(" ORDER BY A.APPLICATION_ID, A.APPLICATION_DATE, A.APPLICATION_STATUS ASC");
			Object[] objParms = parmList.toArray();

			preEnrollStatus = jdbcTemplate.query(sql.toString(), objParms,
					new DomainPropertyRowMapper<EEMDashboardApplStatusDO>(EEMDashboardApplStatusDO.class));
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error ocurred while getApplStatus!");
		}
		return preEnrollStatus;
	}

	@Override
	public List<EEMDashboardCmsDO> getCmsStatus(String customerId, String status) {

		List<EEMDashboardCmsDO> cmsStatusList;
		try {
			StringBuilder sql = CommonUtils.buildQueryBuilder("SELECT DISTINCT Z.MEMBER_ID, Z.SUPPLEMENTAL_ID,",
					" COALESCE(Z.MBI, Z.HIC_NBR, '') AS MEDICARE_ID, Z.TRANSACTION_TYPE, Z.TYPE, Z.FIRST_NAME, Z.LAST_NAME,");
			if (status.equals(EEMConstants.CMS_STATUS)) {
				sql.append(" Z.ENROLL_REASON_CD,");
			}
			if (status.equals(EEMConstants.CMS_TRANSACTION_STATUS)) {
				sql.append(" Z.TRIGGER_CODE,");
			}
			sql.append(" Z.PRODUCT_NAME FROM ( SELECT DISTINCT E.MEMBER_ID, MAX(CASE WHEN I.DS_CD = 'MED' THEN"
					+ " I.DS_VALUE ELSE '' END) AS HIC_NBR, MAX(CASE WHEN I.DS_CD = 'MBI' THEN I.DS_VALUE ELSE '' END) AS MBI,"
					+ " E.SUPPLEMENTAL_ID, E.ENROLL_STATUS AS TYPE, P.PRODUCT_NAME, T.TRIGGER_TYPE AS TRANSACTION_TYPE,"
					+ " (TRIM(D.FIRST_NAME) CONCAT SPACE(1) CONCAT TRIM(D.MIDDLE_INITIAL)) AS FIRST_NAME,"
					+ " (TRIM(D.LAST_NAME)) AS LAST_NAME,");
			if (status.equals(EEMConstants.CMS_STATUS)) {
				sql.append(" E.ENROLL_REASON_CD");
			}
			if (status.equals(EEMConstants.CMS_TRANSACTION_STATUS)) {
				sql.append(" T.TRIGGER_CODE");
			}
			sql.append(" FROM EM_MBR_ENROLLMENT E");
			sql.append(" LEFT JOIN EM_MBR_TRIGGER T ON T.CUSTOMER_ID = E.CUSTOMER_ID AND T.MEMBER_ID = E.MEMBER_ID");
			sql.append(" LEFT JOIN ( SELECT * FROM EM_MBR_DEMOGRAPHIC D1 WHERE D1.DEMO_SEQ_NBR = (SELECT");
			sql.append(" MAX(D2.DEMO_SEQ_NBR) FROM EM_MBR_DEMOGRAPHIC D2 WHERE D2.CUSTOMER_ID = D1.CUSTOMER_ID");
			sql.append(" AND D2.MEMBER_ID = D1.MEMBER_ID AND D2.OVERRIDE_IND='N') AND D1.OVERRIDE_IND='N' ) D ON");
			sql.append(" D.CUSTOMER_ID = T.CUSTOMER_ID AND D.MEMBER_ID = T.MEMBER_ID AND");
			sql.append(" D.OVERRIDE_IND = E.OVERRIDE_IND");
			sql.append(" LEFT JOIN EM_MBR_DSINFO I ON (I.CUSTOMER_ID = E.CUSTOMER_ID AND I.MEMBER_ID = E.MEMBER_ID");
			sql.append(" AND I.OVERRIDE_IND =  E.OVERRIDE_IND AND I.EFF_END_DATE = E.EFF_END_DATE)");
			sql.append(" LEFT JOIN EM_PRODUCT_NAME P ON P.CUSTOMER_ID = E.CUSTOMER_ID AND P.PRODUCT_ID = E.PRODUCT_ID");
			sql.append(" AND P.PRODNAME_END_DATE = E.EFF_END_DATE");
			sql.append(" WHERE E.CUSTOMER_ID = ? AND I.DS_CD IN ('MBI', 'MED') AND E.EFF_END_DATE = '99999999' AND");
			sql.append(" E.OVERRIDE_IND = 'N' AND D.CURRENT_IND = 'Y' AND T.TRIGGER_TYPE = 'TXN' AND T.TRIGGER_STATUS = 'OPEN' AND");
			if (status.equals(EEMConstants.CMS_STATUS)) {
				sql.append(" E.ENROLL_REASON_CD IN ('CMSREADY', 'MCAREERR', 'CMSSUBMIT', '127REJECT', 'CMSREJECT')");
			}
			if (status.equals(EEMConstants.CMS_TRANSACTION_STATUS)) {
				sql.append(" T.TRIGGER_CODE IN ('51DI', '51OA', '61ER', '61CW', '61SO','72RX') AND");
				sql.append(" ((T.TRIGGER_CODE IN ('51DI', '51OA') AND E.ENROLL_STATUS = 'DPEND') OR");
				sql.append(" (T.TRIGGER_CODE IN ('61ER', '61CW', '61SO') AND E.ENROLL_STATUS = 'EPEND') OR");
				sql.append(" T.TRIGGER_CODE = '72RX')");
			}
			sql.append(" GROUP BY E.CUSTOMER_ID, E.MEMBER_ID, E.SUPPLEMENTAL_ID, E.ENROLL_STATUS, T.TRIGGER_TYPE,");
			if (status.equals(EEMConstants.CMS_STATUS)) {
				sql.append(" E.ENROLL_REASON_CD,");
			}
			if (status.equals(EEMConstants.CMS_TRANSACTION_STATUS)) {
				sql.append(" T.TRIGGER_CODE,");
			}
			sql.append(" T.TRIGGER_CODE, D.FIRST_NAME, D.MIDDLE_INITIAL, D.LAST_NAME, P.PRODUCT_NAME");
			sql.append(" ORDER BY E.MEMBER_ID, E.SUPPLEMENTAL_ID) Z");

			Object[] parms = new Object[] { customerId };
			cmsStatusList = jdbcTemplate.query(sql.toString(), parms,
					new DomainPropertyRowMapper<EEMDashboardCmsDO>(EEMDashboardCmsDO.class));
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error ocurred while getCmsStatus!");
		}
		return cmsStatusList;
	}

	@Override
	public List<EEMDashboardMbrShipDO> mbrShipDistribution(List<String> planIds, String custId, String custNbr) {
		List<EEMDashboardMbrShipDO> mbrDistList = null;
		Map<String, Object> params = new HashMap<>();
		try {
			StringBuilder sql = CommonUtils.buildQueryBuilder(
					"SELECT PP.PLAN_ID,PP.PBP_ID,sum(case when ME.ENROLL_STATUS = 'DAPRV' then 1 else 0 end) AS DISENROLL_COUNT,",
					"sum(case when ME.ENROLL_STATUS = 'EAPRV' then 1 else 0 end) AS ENROLL_COUNT FROM PLANPBP PP",
					"LEFT  JOIN EM_MBR_ENROLLMENT ME ON ME.PLAN_ID=PP.PLAN_ID AND ME.PBP_ID=PP.PBP_ID AND ME.CUSTOMER_ID=(:CUSTOMER_ID) AND",
					"ME.ENROLL_STATUS IN ('EAPRV','DAPRV') AND  ME.OVERRIDE_IND='N' AND ME.EFF_END_DATE='99999999' ",
					"WHERE PP.CUST_NBR=(:CUSTOMER_NBR) ");
			params.put("CUSTOMER_ID", custId);
			params.put("CUSTOMER_NBR", custNbr);
			if (planIds != null && !planIds.isEmpty()) {
				sql.append(" AND PP.PLAN_ID IN (:PLAN_IDS)");
				params.put("PLAN_IDS", planIds);

			}
			sql.append("GROUP BY PP.PLAN_ID,PP.PBP_ID");
			mbrDistList = namedParameterJdbcTemplate.query(sql.toString(), params,
					new DomainPropertyRowMapper<EEMDashboardMbrShipDO>(EEMDashboardMbrShipDO.class));

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error ocurred while mbrShipDistribution!");
		}
		return mbrDistList;
	}

	@Override
	public List<EEMDashboardAppDistDO> appDistribution(List<String> planIds, String customerId, String customerNbr) {
		List<EEMDashboardAppDistDO> appDistList = null;
		Map<String, Object> params = new HashMap<>();
		String[] stringArray = { "APPROVED", "BEQAPPR", "COMPLETED", "FORCEDAPPR", "READYAPPR", "READY" };

		try {
			StringBuilder sql = CommonUtils.buildQueryBuilder(
					"SELECT PP.PLAN_ID,PP.PBP_ID,sum(case when EA.APPLICATION_STATUS IN (:APP_STATUSLIST)",
					"then 1 else 0 end) AS ENROLL_COUNT FROM PLANPBP PP LEFT JOIN  (EM_APPL_PLAN EP",
					"JOIN EM_APPLICATION EA ON EP.APPLICATION_ID=EA.APPLICATION_ID AND EP.CUSTOMER_ID=EA.CUSTOMER_ID AND",
					"EA.APPLICATION_STATUS IN (:APP_STATUSLIST) AND EP.CUSTOMER_ID=(:CUSTOMER_ID)) ON  PP.PLAN_ID=EP.TO_PLAN_ID ",
					"AND PP.PBP_ID=EP.TO_PBP_ID WHERE PP.CUST_NBR=(:CUST_NBR)  ");
			params.put("CUSTOMER_ID", customerId);
			params.put("CUST_NBR", customerNbr);
			params.put("APP_STATUSLIST", Arrays.asList(stringArray));

			if (planIds != null && !planIds.isEmpty()) {
				sql.append(" AND TO_PLAN_ID IN(:PLAN_IDS)");
				params.put("PLAN_IDS", planIds);

			}
			sql.append("GROUP BY PP.PLAN_ID,PP.PBP_ID ");
			appDistList = namedParameterJdbcTemplate.query(sql.toString(), params,
					new DomainPropertyRowMapper<EEMDashboardAppDistDO>(EEMDashboardAppDistDO.class));

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error ocurred while appDistribution!");
		}
		return appDistList;
	}

	@Override
	public List<EEMDashboardLisMbrDistDO> lisMbrDistribution(EEMDashboardLisMbrDistVO lisDistVo, String cusId,
			String custNbr) {
		List<EEMDashboardLisMbrDistDO> lisDistList = null;
		List<String> planIds = lisDistVo.getContractsList();
		Map<String, Object> params = new HashMap<>();

		try {
			StringBuilder sql = CommonUtils.buildQueryBuilder(
					"SELECT PP.PLAN_ID,sum(case when ML.LI_COPAY_CD = '0' then 1 else 0 end) AS LOW_INCOME,",
					"sum(case when ML.LI_COPAY_CD= '1' then 1 else 0 end) AS HIGH,",
					"sum(case when ML.LI_COPAY_CD = '2' then 1 else 0 end) AS LOW,",
					"sum(case when ML.LI_COPAY_CD = '3' then 1 else 0 end) AS ZERO,",
					"sum(case when ML.LI_COPAY_CD = '4' then 1 else 0 end) AS FIFTEENPER",
					"FROM PLANPBP PP LEFT JOIN ( EM_MBR_LIS ML",
					"JOIN EM_MBR_ENROLLMENT ME ON ML.MEMBER_ID=ME.MEMBER_ID JOIN EM_LI_COPAY LC ",
					"ON LC.LI_COPAY_CD=ML.LI_COPAY_CD");
			if (StringUtils.isNotBlank(lisDistVo.getDate())) {
				sql.append(" AND ML.CREATE_TIME>=(:FROM_DATE) AND ML.CREATE_TIME<(:TO_DATE)");
				String fromDate = DateFormatter.reFormat(lisDistVo.getDate(), DateFormatter.MM_DD_YYYY,
						DateFormatter.YYYY_MM_DD_HH_MM_SS);
				String todate = DateFormatter.reFormat(lisDistVo.getDate(), DateFormatter.MM_DD_YYYY,
						DateFormatter.YYYYMMDD);
				todate = DateMath.addOneDay(todate);
				todate = DateFormatter.reFormat(todate, DateFormatter.YYYYMMDD, DateFormatter.YYYY_MM_DD_HH_MM_SS);
				params.put("FROM_DATE", fromDate);
				params.put("TO_DATE", todate);
			}
			sql.append(")");
			sql.append(" ON PP.PLAN_ID=ME.PLAN_ID");
			sql.append(" AND  ME.OVERRIDE_IND='N' AND ME.CUSTOMER_ID=(:CUSTOMER_ID) AND ME.EFF_END_DATE='99999999'");
			sql.append(" AND ML.OVERRIDE_IND='N' WHERE PP.CUST_NBR=(:CUST_NBR)");
			params.put("CUSTOMER_ID", cusId);
			params.put("CUST_NBR", custNbr);

			if (planIds != null && !planIds.isEmpty()) {
				sql.append(" AND PP.PLAN_ID IN(:PLAN_IDS)");
				params.put("PLAN_IDS", planIds);

			}
			sql.append("  GROUP BY PP.PLAN_ID");

			lisDistList = namedParameterJdbcTemplate.query(sql.toString(), params,
					new DomainPropertyRowMapper<EEMDashboardLisMbrDistDO>(EEMDashboardLisMbrDistDO.class));

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error ocurred while lisMbrDistribution!");
		} catch (ParseException e) {
			throw new ApplicationException(e, "Error ocurred while parsing date in lisMbrDistribution!");
		}
		return lisDistList;
	}

	@Override
	public List<EEMDashboardLtrVolDisDO> letterVolumeDistribution(String customerId, String todayDate) {

		List<EEMDashboardLtrVolDisDO> ltrDistList = null;
		Map<String, Object> params = new HashMap<>();
		try {
			StringBuilder sql = CommonUtils.buildQueryBuilder(
					"SELECT LM.CORR_LETTER_NAME,count(*) AS COUNT FROM EM_CORR_CTL LM JOIN EM_CORR_MBR LT",
					"ON LM.LETTER_NAME=LT.LETTER_NAME AND LM.CUSTOMER_ID=LT.CUSTOMER_ID",
					"WHERE  LM.CUSTOMER_ID=(:CUSTOMER_ID) AND LT.REQUEST_DATE=(:REQUEST_DATE)  GROUP BY LM.CORR_LETTER_NAME;");
			params.put("CUSTOMER_ID", customerId);
			params.put("REQUEST_DATE", todayDate);

			ltrDistList = namedParameterJdbcTemplate.query(sql.toString(), params,
					new DomainPropertyRowMapper<EEMDashboardLtrVolDisDO>(EEMDashboardLtrVolDisDO.class));
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error ocurred while letterVolumeDistribution!");
		}

		return ltrDistList;
	}

	@Override
	public List<EEMDashboardSpclStatDisDO> specialStatusDistribution(String customerId) {
		List<EEMDashboardSpclStatDisDO> spclDistList = null;
		Map<String, Object> params = new HashMap<>();
		String todayDate = DateUtil.getTodaysDate();
		try {
			StringBuilder sql = CommonUtils.buildQueryBuilder(
					"SELECT 'LIS' AS NAME,count(DISTINCT MEMBER_ID) AS COUNT FROM em_mbr_lis WHERE CUSTOMER_ID=(:CUSTOMER_ID) AND OVERRIDE_IND='N'",
					" AND (:TODAY_DATE) BETWEEN EFF_START_DATE AND EFF_END_DATE ", "UNION ALL",
					"SELECT 'LEP' AS NAME,count(DISTINCT MEMBER_ID) AS COUNT FROM em_mbr_lep WHERE CUSTOMER_ID=(:CUSTOMER_ID) AND OVERRIDE_IND='N'",
					" AND (:TODAY_DATE) BETWEEN EFF_START_DATE AND EFF_END_DATE ", "UNION ALL",
					"SELECT 'OOA' AS NAME,count(DISTINCT MEMBER_ID) AS COUNT FROM em_mbr_ooa WHERE CUSTOMER_ID=(:CUSTOMER_ID) AND OVERRIDE_IND='N' AND OOA_TYPE='PERM'",
					"UNION ALL",
					"SELECT DS_CD AS NAME,count(*) AS COUNT FROM EM_MBR_DSINFO WHERE CUSTOMER_ID=(:CUSTOMER_ID) AND OVERRIDE_IND='N' AND DS_CD IN",
					"('ESRD','MDID','HSPC') AND  (:TODAY_DATE) BETWEEN EFF_START_DATE AND EFF_END_DATE GROUP BY DS_CD;");
			params.put("CUSTOMER_ID", customerId);
			params.put("TODAY_DATE", todayDate);

			spclDistList = namedParameterJdbcTemplate.query(sql.toString(), params,
					new DomainPropertyRowMapper<EEMDashboardSpclStatDisDO>(EEMDashboardSpclStatDisDO.class));
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error ocurred while specialStatusDistribution!");
		}

		return spclDistList;
	}

	@Override
	public List<EEMDashboardFileLoadErrDisDO> fileLoadErrDist(String customerId, Map<String, String> searchParamMap) {
		String startDate = searchParamMap.get("startDate");
		String endDate = searchParamMap.get("endDate");
		if (StringUtils.isNotBlank(startDate)) {
			startDate = startDate.trim();
			startDate = DateFormatter.reFormat(startDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
		}
		if (StringUtils.isNotBlank(endDate)) {
			endDate = endDate.trim();
			endDate = DateFormatter.reFormat(endDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
		}
		String[] loaded = { "APPROVED", "BEQAPPR", "BEQPENDING", "COMPLETED", "FORCEDAPPR", "READY", "READYAPPR" };
		String[] errored = { "ELGCRITICL", "ELGNOTFND", "ELGWARNING", "ERROR", "ERRORCRITL", "HOLD", "INCRFIELCT",
				"INCRFIGEN", "INCRFIREQ", "INCRFITRG", "INCOMPLETE", "SUPPEND" };
		String[] rejected = { "CANCELED", "DENIEDELG", "DENIEDETYP", "DENIEDOTHR", "DUPLAPPL", "DUPLENRL", "OPOUTGEN",
				"OPOUTNO", "OPOUTNORSP", "OPOUTPEND", "OPOUTYES", "RFINORESP" };
		List<EEMDashboardFileLoadErrDisDO> fileDistList = null;
		Map<String, Object> params = new HashMap<>();
		try {
			StringBuilder sql = CommonUtils.buildQueryBuilder(
					"SELECT EA.APPLICATION_TYPE,sum(case when EA.APPLICATION_STATUS IN(:LOADED)  then 1 else 0 end) AS LOADED,",
					"sum(case when EA.APPLICATION_STATUS IN(:ERRORED)  then 1 else 0 end) AS ERRORED,",
					"sum(case when EA.APPLICATION_STATUS IN(:REJECTED)  then 1 else 0 end) AS REJECTED",
					"FROM EM_APPLICATION EA JOIN EM_INPUT_JOURNAL EJ ON EA.FILE_ID=EJ.FILE_ID ",
					"AND EA.CUSTOMER_ID=EJ.CUSTOMER_ID AND EJ.JOURNAL_TYPE='APL' WHERE EA.CUSTOMER_ID=(:CUSTOMER_ID)",
					"AND EJ.FILE_DATE BETWEEN (:STARTDATE) AND (:ENDDATE) GROUP BY EA.APPLICATION_TYPE;");
			params.put("CUSTOMER_ID", customerId);
			params.put("LOADED", Arrays.asList(loaded));
			params.put("ERRORED", Arrays.asList(errored));
			params.put("REJECTED", Arrays.asList(rejected));
			params.put("STARTDATE", startDate);
			params.put("ENDDATE", endDate);

			fileDistList = namedParameterJdbcTemplate.query(sql.toString(), params,
					new DomainPropertyRowMapper<EEMDashboardFileLoadErrDisDO>(EEMDashboardFileLoadErrDisDO.class));
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error ocurred while fileLoadErrDist!");
		}
		return fileDistList;
	}

}
