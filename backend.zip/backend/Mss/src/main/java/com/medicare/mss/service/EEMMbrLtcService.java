/**
 * 
 */
package com.medicare.mss.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMMbrDAO;
import com.medicare.mss.dao.EEMMbrErrorDAO;
import com.medicare.mss.dao.MemberLtcDAO;
import com.medicare.mss.domainobject.EEMMbrLtcInfoDO;
import com.medicare.mss.domainobject.EmMbrErrorDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.EEMContext;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EEMFieldErrorVO;
import com.medicare.mss.vo.EEMMbrLtcInfoVO;
import com.medicare.mss.vo.EEMMbrLtcSearchVO;
import com.medicare.mss.vo.EMDatedSegmentVO;
import com.medicare.mss.vo.EmMbrErrorVO;

/**
 * @author Wipro Ltd.
 *
 */
@Service
@Transactional(rollbackFor = ApplicationException.class)
public class EEMMbrLtcService extends EEMMbrBaseService {

	@Autowired
	private MemberLtcDAO memberLtcDAO;
	
	@Autowired
	private EEMMbrDAO eemMbrDAO;

	@Autowired
	private EEMCodeCache eemCodeCache;
	
	@Autowired
	private EEMMbrErrorDAO mbrErrorDAO;
	
	@Autowired
	private MessageSource messageSource;

	public List<EEMMbrLtcInfoVO> mbrLtcSearch(EEMMbrLtcSearchVO mbrLtcSearchVO) {
		
		List<EEMMbrLtcInfoDO> mbrLtcInfoDOList = eemCodeCache.mbrLtcSearch(mbrLtcSearchVO);
		
		List<EEMMbrLtcInfoVO> mbrLtcInfoVOList = new ArrayList<>();
		CommonUtils.copyList(mbrLtcInfoDOList, mbrLtcInfoVOList, EEMMbrLtcInfoVO.class);
		return mbrLtcInfoVOList;
	}

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public List<EEMMbrLtcInfoVO> getMbrLtcInfoList(String memberId, String showAll) {

		List<EEMMbrLtcInfoVO> mbrLtcInfoVOList = sessionHelper.getEEMContext().getMbrMasterVO().getMbrLtcInfoList();

		if (StringUtils.equals(EEMConstants.VALUE_YES, showAll)) {
			List<EEMMbrLtcInfoVO> allInfos = getMbrLtcInfoListFromDB(memberId, showAll);
				mbrLtcInfoVOList = (List<EEMMbrLtcInfoVO>) getActiveDatedList(allInfos);
				setToContext(mbrLtcInfoVOList);
			return allInfos;
		} else {
			if (Objects.isNull(mbrLtcInfoVOList)) {
				mbrLtcInfoVOList = getMbrLtcInfoListFromDB(memberId, showAll);
				setToContext(mbrLtcInfoVOList);
			} else {
				mbrLtcInfoVOList = (List<EEMMbrLtcInfoVO>) getActiveDatedList(mbrLtcInfoVOList);
				setToContext(mbrLtcInfoVOList);
			}
			return mbrLtcInfoVOList;
		}
	}

	@SuppressWarnings("unchecked")
	public boolean updateMbrLtcInfo(EEMMbrLtcInfoVO newVO) {

		String applDate = EEMConstants.BLANK;
		String ts = DateUtil.getCurrentDatetimeStamp();
		String fieldNbr = null;
		String fieldUpdate = "423003";
		String requestScrn = "ltc";
		String userId = sessionHelper.getUserInfo().getUserId();
		newVO.setCustomerId(sessionHelper.getUserInfo().getCustomerId());
		newVO.setOverrideInd(EEMConstants.VALUE_NO);

		List<EEMFieldErrorVO> lstFields = getValidatingFormFields(EEMConstants.EEM_ENROLLMENT_FORM);
		List<EmMbrErrorDO> lstErrors = validateLTC(newVO, userId, lstFields);

		handleErrorDetails(newVO, applDate, fieldNbr, fieldUpdate, requestScrn, userId, lstErrors);
		
		String lengthOfStay = newVO.getLengthOfStay();
		if (lengthOfStay == null || StringUtils.isEmpty(lengthOfStay)) {
			newVO.setLengthOfStay("0");
		}
		Map<String, String> type = new HashMap<>();
		int sqlCnt = 0;
		try {
			String msg = checkDates(newVO);
			if (Objects.nonNull(msg)) {
				throw new ApplicationException(msg);
			}

			String maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
					EEMConstants.EM_MBR_LTC, type);
			List<EEMMbrLtcInfoVO> activeMbrLtcInfoLst = getMbrLtcInfoList(newVO.getMemberId(), EEMConstants.VALUE_NO);

			if (hasDataChanged(activeMbrLtcInfoLst, maxLastUpdate)) {
				throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
			}

			// the update case
			EEMMbrLtcInfoVO matchVO = (EEMMbrLtcInfoVO) matchDatedSegment(activeMbrLtcInfoLst, newVO);
			if (Objects.nonNull(matchVO)) {
				return overrideAndInsertMbrLtcInfo(newVO, ts, userId, matchVO, type);
			}

			// the update end date case - no change in data
			matchVO = (EEMMbrLtcInfoVO) matchDatedSegmentEndDate(activeMbrLtcInfoLst, newVO);
			if (Objects.nonNull(matchVO)) {
				return overrideAndInsertMbrLtcInfo(newVO, ts, userId, matchVO, type);
			}

			if (StringUtils.equals(newVO.getEffEndDate(), EEMConstants.EFF_END_DATE)) {
				return overrideAndInsertBelowAndAboveSegment(newVO, ts, userId, activeMbrLtcInfoLst, type);

			}

			// end dated segment
			if (!doDatedSegmentAdjust(activeMbrLtcInfoLst, newVO, ts, userId, memberLtcDAO)) {
				return false;
			}

			sqlCnt = addNewSegment(newVO, ts, userId);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
			}
			maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(),
					EEMConstants.EM_MBR_LTC, type);
			if (hasDataChanged(ts, maxLastUpdate)) {
				throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
			}

			List<EEMMbrLtcInfoVO> updatedMbrLtcInfoVOList = getMbrLtcInfoListFromDB(newVO.getMemberId(),
					newVO.getShowAll());
			if (StringUtils.equals(EEMConstants.VALUE_NO, newVO.getShowAll())) {
				setToContext(updatedMbrLtcInfoVOList);
			} else {
				List<EEMMbrLtcInfoVO> mbrLtcActiveVOList = (List<EEMMbrLtcInfoVO>) getActiveDatedList(updatedMbrLtcInfoVOList);
				setToContext(mbrLtcActiveVOList);
			}
			return true;

		} catch (Exception exp) {
			throw new ApplicationException(exp.getMessage());
		}

	}

	public List<EmMbrErrorDO> validateLTC(EEMMbrLtcInfoVO eemMbrLtcInfoVO, String userId,
			List<EEMFieldErrorVO> lstFields) {
		List<EmMbrErrorDO> lstErrors = new ArrayList<>();

		EmMbrErrorDO objError = checkLTCDates(eemMbrLtcInfoVO, lstFields, userId);
		if (Objects.nonNull(objError)) {
			lstErrors.add(objError);
		}
		return lstErrors;
	}

	public EmMbrErrorDO checkLTCDates(EEMMbrLtcInfoVO ltcVO, List<EEMFieldErrorVO> lstFields, String userId) {
		EmMbrErrorDO objError = null;
		boolean checkProviderDate = false;
		boolean error = false;
		String errorCode = EEMConstants.BLANK;

		EEMFieldErrorVO fieldError = getField("ltcId", lstFields);
		if (Objects.isNull(fieldError)) {
			return objError;
		}

		if (StringUtils.isNotBlank(ltcVO.getLtcId())) {
			EEMMbrLtcInfoDO eemMbrLtcInfoDO = new EEMMbrLtcInfoDO();
			BeanUtils.copyProperties(ltcVO, eemMbrLtcInfoDO);
			checkProviderDate = memberLtcDAO.checkLTCDates(eemMbrLtcInfoDO);
		}
		if (!checkProviderDate) {
			error = true;
			errorCode = "MB149";
		}
		if (error) {
			objError = new EmMbrErrorDO();
			objError.setCustomerId(ltcVO.getCustomerId());
			objError.setMemberId(ltcVO.getMemberId());
			objError.setFieldNbr(fieldError.getFieldNbr());
			if (!StringUtil.nonNullTrim(fieldError.getRequiredInd()).equals(EEMConstants.VALUE_NO)) {
				objError.setRfiInd(EEMConstants.VALUE_YES);
			} else {
				objError.setRfiInd(EEMConstants.VALUE_NO);
			}
			objError.setErrorCd(errorCode);
			objError.setErrorMsg(eemCodeCache.getDesc(errorCode, eemCodeCache.getLstErrorCodes()));
			objError.setFieldNbr(fieldError.getFieldNbr());
			objError.setLastUpdtUserId(userId);
			objError.setErrorData(ltcVO.getLtcId());
		}

		return objError;
	}

	@SuppressWarnings("unchecked")
	public boolean deleteMbrLtcInfo(EEMMbrLtcInfoVO mbrLtcInfoVO) {

		String userId = sessionHelper.getUserInfo().getUserId();
		int sqlCnt = memberLtcDAO.setOverride(mbrLtcInfoVO, userId);
		if (sqlCnt == 1) {
			List<EEMMbrLtcInfoVO> updatedMbrLtcInfoVOList = getMbrLtcInfoListFromDB(mbrLtcInfoVO.getMemberId(),
					mbrLtcInfoVO.getShowAll());
			if (StringUtils.equals(EEMConstants.VALUE_NO, mbrLtcInfoVO.getShowAll())) {
				setToContext(updatedMbrLtcInfoVOList);
			} else {
				List<EEMMbrLtcInfoVO> mbrLtcActiveVOList = (List<EEMMbrLtcInfoVO>) getActiveDatedList(updatedMbrLtcInfoVOList);
				setToContext(mbrLtcActiveVOList);
			}
			return true;
		}
		
		return false;
	}

	public boolean checkLtcFacility(EEMMbrLtcInfoVO mbrLtcInfo) {
		String customerId= sessionHelper.getUserInfo().getCustomerId();
		List<EEMMbrLtcInfoDO> eemMbrLtcInfoDOs = memberLtcDAO.getLTCFacility(customerId,
				mbrLtcInfo.getLtcId(), mbrLtcInfo.getEffStartDate());
		return !CollectionUtils.isEmpty(eemMbrLtcInfoDOs);

	}

	public List<EEMMbrLtcInfoVO> getMbrLtcInfoListFromDB(String mbrId, String showAll) {

		List<EEMMbrLtcInfoVO> mbrLtcInfoVOList = new ArrayList<>();
		String custId = sessionHelper.getUserInfo().getCustomerId();

		List<EEMMbrLtcInfoDO> mbrLtcInfoDOList = memberLtcDAO.getMbrLtcInfos(custId, mbrId, showAll);
		CommonUtils.copyList(mbrLtcInfoDOList, mbrLtcInfoVOList, EEMMbrLtcInfoVO.class);
		return mbrLtcInfoVOList;
	}

	private void setToContext(List<EEMMbrLtcInfoVO> mbrLtcInfoVOList) {
		EEMContext context = sessionHelper.getEEMContext();
		context.getMbrMasterVO().setMbrLtcInfoList(mbrLtcInfoVOList);
		sessionHelper.setEEMContext(context);
	}

	private EEMFieldErrorVO getField(String fieldName, List<EEMFieldErrorVO> lstFields) {
		EEMFieldErrorVO fieldErrorVO = null;
		for (EEMFieldErrorVO field : lstFields) {
			if (fieldName.equals(field.getFormField())) {
				fieldErrorVO = field;
				break;
			}
		}
		return fieldErrorVO;
	}

	@SuppressWarnings("unchecked")
	private boolean overrideAndInsertBelowAndAboveSegment(EEMMbrLtcInfoVO newVO, String ts, String userId,
			List<? extends EMDatedSegmentVO> activeMbrLtcInfoLst, Map<String, String> type)
			throws CloneNotSupportedException, ParseException {

		int sqlCnt;
		String maxLastUpdate;
		List<? extends EMDatedSegmentVO> lstSegmentsAbove = getSegmentsAbove(activeMbrLtcInfoLst,
				newVO.getEffStartDate());
		Iterator<? extends EMDatedSegmentVO> it = lstSegmentsAbove.iterator();

		while (it.hasNext()) {
			EEMMbrLtcInfoVO itemVO = (EEMMbrLtcInfoVO) it.next();
			sqlCnt = memberLtcDAO.setOverride(itemVO, userId);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_ABOVE);
			}
		}

		EEMMbrLtcInfoVO belowVO = (EEMMbrLtcInfoVO) getFirstOverlapSegmentBelow(activeMbrLtcInfoLst,
				newVO.getEffStartDate());

		if (Objects.nonNull(belowVO)) {
			sqlCnt = memberLtcDAO.setOverride(belowVO, userId);
			if (sqlCnt != 1) {
				throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_ABOVE);
			}

			// do we need to split the segment below
			if (belowVO.getEffStartDate().compareTo(newVO.getEffStartDate()) < 0) {
				EEMMbrLtcInfoVO tempVO = (EEMMbrLtcInfoVO) belowVO.clone();
				tempVO.setEffEndDate(DateMath.minusOneDay(newVO.getEffStartDate()));
				sqlCnt = addNewSegment(tempVO, ts, userId);
				if (sqlCnt != 1) {
					throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT_BELOW);
				}
			}
		}

		sqlCnt = addNewSegment(newVO, ts, userId);
		if (sqlCnt != 1) {
			throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
		}
		maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(), EEMConstants.EM_MBR_LTC,
				type);
		if (hasDataChanged(ts, maxLastUpdate)) {
			throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
		}

		List<EEMMbrLtcInfoVO> updatedMbrLtcInfoVOList = getMbrLtcInfoListFromDB(newVO.getMemberId(),
				newVO.getShowAll());
		if (StringUtils.equals(EEMConstants.VALUE_NO, newVO.getShowAll())) {
			setToContext(updatedMbrLtcInfoVOList);
		} else {
			List<EEMMbrLtcInfoVO> mbrLtcInfoActiveVOList = (List<EEMMbrLtcInfoVO>) getActiveDatedList(updatedMbrLtcInfoVOList);
			setToContext(mbrLtcInfoActiveVOList);
		}
		return true;

		// end of open ended new segment processing
	}

	private int addNewSegment(EEMMbrLtcInfoVO newVO, String ts, String userId) {
		// add the new segment
		newVO.setCreateTime(ts);
		newVO.setCreateUserId(userId);
		newVO.setLastUpdtTime(ts);
		newVO.setLastUpdtUserId(userId);

		return memberLtcDAO.insertMbr(newVO);
	}

	@SuppressWarnings("unchecked")
	private boolean overrideAndInsertMbrLtcInfo(EEMMbrLtcInfoVO newVO, String ts, String userId,
			EEMMbrLtcInfoVO matchVO, Map<String, String> type) {
		int sqlCnt;
		String maxLastUpdate;
		sqlCnt = memberLtcDAO.setOverride(matchVO, userId);

		if (sqlCnt != 1) {
			throw new ApplicationException(EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT);
		}

		sqlCnt = addNewSegment(newVO, ts, userId);

		if (sqlCnt != 1) {
			throw new ApplicationException(EEMConstants.ERROR_ADDING_SEGMENT);
		}
		maxLastUpdate = eemMbrDAO.getMaxLastUpdate(newVO.getCustomerId(), newVO.getMemberId(), EEMConstants.EM_MBR_LTC,
				type);
		if (hasDataChanged(ts, maxLastUpdate)) {
			throw new ApplicationException(EEMConstants.DATA_CHANGED_BY_ANOTHER_USER);
		}
		List<EEMMbrLtcInfoVO> updatedMbrLtcInfoVOList = getMbrLtcInfoListFromDB(newVO.getMemberId(),
				newVO.getShowAll());
		if (StringUtils.equals(EEMConstants.VALUE_NO, newVO.getShowAll())) {
			setToContext(updatedMbrLtcInfoVOList);
		} else {
			List<EEMMbrLtcInfoVO> mbrLtcInfoActiveVOList = (List<EEMMbrLtcInfoVO>) getActiveDatedList(updatedMbrLtcInfoVOList);
			setToContext(mbrLtcInfoActiveVOList);
		}
		return true;
	}

	private void handleErrorDetails(EEMMbrLtcInfoVO newVO, String applDate, String fieldNbr, String fieldUpdate,
			String requestScrn, String userId, List<EmMbrErrorDO> lstErrors) {

		if (!CollectionUtils.isEmpty(lstErrors)) {
			for (EmMbrErrorDO objError : lstErrors) {
				fieldNbr = objError.getFieldNbr();
			}
			setErrorDetails(lstErrors, newVO.getMemberId(), userId, fieldNbr, requestScrn,
					applDate);
			newVO.setLtcChangeInd(EEMConstants.VALUE_NO);
			newVO.setLtcchangeReceiveTime(EEMConstants.DEFAULT_TIMESTAMP);
			newVO.setLtcChangeSendTime(EEMConstants.DEFAULT_TIMESTAMP);
			newVO.setErrorDescription(EEMConstants.BLANK);
		} else {
			updateErrorDetails(userId, fieldUpdate, requestScrn);
			newVO.setLtcChangeInd(EEMConstants.VALUE_YES);
			newVO.setLtcchangeReceiveTime(EEMConstants.DEFAULT_TIMESTAMP);
			newVO.setLtcChangeSendTime(EEMConstants.DEFAULT_TIMESTAMP);
			newVO.setErrorDescription("Not Set to HM LTC service");
		}
		
		List<EmMbrErrorDO> mbrErrorDOList = mbrErrorDAO.getMbrErrors(newVO.getCustomerId(), newVO.getMemberId());
		List<EmMbrErrorVO> mbrErrorVOList = new ArrayList<>();
		if (!CollectionUtils.isEmpty(mbrErrorDOList)) {
			mbrErrorDOList.forEach(mbrErrorDO -> {
				EmMbrErrorVO emMbrErrorVO = new EmMbrErrorVO();
				BeanUtils.copyProperties(mbrErrorDO, emMbrErrorVO);
				emMbrErrorVO.setFieldDispName(messageSource.getMessage(mbrErrorDO.getFieldNbr(), null, Locale.getDefault()));
				mbrErrorVOList.add(emMbrErrorVO);
			});
		}
		
		EEMContext context = sessionHelper.getEEMContext();
		context.getMbrMasterVO().setMbrErrorList(mbrErrorVOList);
		sessionHelper.setEEMContext(context);
	}

	public Map<String, Object> buildResultMap(EEMMbrLtcInfoVO mbrLtcInfo, boolean updateSuccess) {
		List<EEMMbrLtcInfoVO> mbrLtcInfoList = new ArrayList<>();
		List<EmMbrErrorVO> errorList = new ArrayList<>();
		Map<String, Object> resultMap = new HashMap<>();
		
		if (updateSuccess) {
			mbrLtcInfoList = getMbrLtcInfoList(mbrLtcInfo.getMemberId(), mbrLtcInfo.getShowAll());
			errorList = sessionHelper.getEEMContext().getMbrMasterVO().getMbrErrorList();
		}
		
		resultMap.put("mbrLtcInfoList", mbrLtcInfoList);
		resultMap.put("errorList", errorList);
		
		return resultMap;
		
	}

}
