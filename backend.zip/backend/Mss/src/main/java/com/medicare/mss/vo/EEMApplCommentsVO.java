package com.medicare.mss.vo;

import java.io.Serializable;

import com.medicare.mss.constants.EEMConstants;

import lombok.Data;

@Data
public class EEMApplCommentsVO implements Serializable{

	private static final long serialVersionUID = 2884827370676349766L;
	
	private String customerId;
	private int applicationId;
	private String applComments;
	private String createTime;
	private String createUserId;
	private String insert = EEMConstants.VALUE_NO;
	
	private int commentSeqNbr;

}
