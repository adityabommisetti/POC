package com.medicare.mss.daoImpl;

import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.caching.EEMProfileSettings;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMMbrDAO;
import com.medicare.mss.domainobject.EEMMbrDemographicDO;
import com.medicare.mss.domainobject.EEMMbrEnrollmentDO;
import com.medicare.mss.domainobject.EEMMbrSearchDO;
import com.medicare.mss.domainobject.EEMMbrSnapshotDO;
import com.medicare.mss.domainobject.EEMProfileItemDO;
import com.medicare.mss.domainobject.EMMbrTriggerDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.rowmappers.MbrDemographicRowMapper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.PaginationQueryHelper;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.DataBaseField;
import com.medicare.mss.vo.EEMMbrSearchVO;
import com.medicare.mss.vo.PageableVO;

@Repository
public class EEMMbrDAOImpl implements EEMMbrDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Autowired
	private EEMProfileSettings eemProfileSettings;

	@Override
	public EEMMbrDemographicDO getMbrDemographicForEffMth(String customerId, String memberId, String cmsEffMonth)
			throws ApplicationException {

		try {

			String query = CommonUtils.buildQuery(
					"SELECT CUSTOMER_ID, MEMBER_ID, CMS_EFF_MO, DEMO_SEQ_NBR, CURRENT_IND, OVERRIDE_IND,",
					" LAST_NAME, FIRST_NAME, MIDDLE_INITIAL, PREFIX, SUFFIX,",
					" MAIL_LAST_NAME, MAIL_FIRST_NAME, MAIL_MIDDLE_INIT, MAIL_SUFFIX, INS_CARD_NAME, SSN,",
					" BIRTH_DATE, DEATH_DATE, MARITAL_STATUS, GENDER_CD, RACE_CD,",
					" MBR_EMAIL, AUTH_LAST_NAME, AUTH_FIRST_NAME, AUTH_MIDDLE_INIT, AUTH_RELATIONSHIP_CD,",
					" EMERGCY_NAME, EMERGCY_PHONE, EMERGCY_RELATIONSHIP_CD, EMERGCY_EMAIL,",
					" LANGUAGE_CD, SPOUSE_WORK_IND, MEMBER_STATUS, FILE_ID,",
					" CREATE_TIME, CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID,",
					" ROLLOVER_TIME, ROLLOVER_USERID, ALT_CORRES_IND FROM EM_MBR_DEMOGRAPHIC",
					" WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? AND CMS_EFF_MO = ? AND OVERRIDE_IND = 'N' FETCH FIRST 1 ROWS ONLY");

			return jdbcTemplate.queryForObject(query.toString(), new Object[] { customerId, memberId, cmsEffMonth },
					new MbrDemographicRowMapper());

		} catch (EmptyResultDataAccessException exp) {
			throw new ApplicationException(exp, "No Data Found For Demographics");
		} catch (Exception exp) {
			throw new ApplicationException(exp, "Exception in getMbrDemographicForEffMth:");
		}
	}

	@Override
	public int insertMbrTrigger(EMMbrTriggerDO trig) throws ApplicationException {
		String query = CommonUtils.buildQuery("INSERT INTO EM_MBR_TRIGGER(",
				"CUSTOMER_ID, MEMBER_ID, TRIGGER_TYPE, EFFECTIVE_DATE, CREATE_TIME,",
				"TRIGGER_CODE, PLAN_ID, PBP_ID, PLAN_DESIGNATION, TRIGGER_STATUS, PROCESS_SOURCE,",
				"ORIG_TRIGGER_TYPE, ORIG_TRIGGER_CODE, ORIG_EFFECTIVE_DATE, ORIG_TRIGGER_CREATE_TIME,",
				"CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID, FILE_BATCH_ID, LETTER_NAME, RECORD_TYPE)",
				"VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

		try {
			return jdbcTemplate.update(query, trimToEmpty(trig.getCustomerId()), trimToEmpty(trig.getMemberId()),
					trig.getTriggerType(), trimToEmpty(trig.getEffectiveDate()), trimToEmpty(trig.getCreateTime()),
					trimToEmpty(trig.getTriggerCode()), trimToEmpty(trig.getPlanId()), trimToEmpty(trig.getPbpId()),
					trimToEmpty(trig.getPlanDesignation()), trimToEmpty(trig.getTriggerStatus()),
					trimToEmpty(trig.getProcessSource()), trimToEmpty(trig.getOrigTriggerType()),
					trimToEmpty(trig.getOrigTriggerCode()), trimToEmpty(trig.getOrigEffectiveDate()),
					trimToEmpty(trig.getOrigTriggerCreateTime()), trimToEmpty(trig.getCreateUserId()),
					trimToEmpty(trig.getLastUpdtTime()), trimToEmpty(trig.getLastUpdtUserId()),
					trimToEmpty(trig.getFileBatchId()), trimToEmpty(trig.getLetterName()),
					trimToEmpty(trig.getRecordType()));
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp);
		}
	}

	@Override
	public PageableVO getMbrSearchDetails(String customerId, Map<String, String> searchParamMap, boolean isPagination)
			throws ApplicationException {
		try {
			PageableVO response = new PageableVO();

			String searchMemberId = trimToEmpty(searchParamMap.get("memberId"));
			String searchMedicareId = trimToEmpty(searchParamMap.get("medicareId"));
			String searchFirstName = trimToEmpty(searchParamMap.get("firstName"));
			String searchLastName = trimToEmpty(searchParamMap.get("lastName"));
			String searchEffMonth = DateFormatter.reFormat(trimToEmpty(searchParamMap.get("cmsEffMonth")),
					DateFormatter.MM_YYYY, DateFormatter.YYYYMM);
			String dob = DateFormatter.reFormat(trimToEmpty(searchParamMap.get("dob")), DateFormatter.MM_DD_YYYY,
					DateFormatter.YYYYMMDD);
			String searchSupplementalId = trimToEmpty(searchParamMap.get("supplementalId"));

			StringBuilder sql = new StringBuilder();

			sql.append(
					" SELECT Z.MEMBER_ID,COALESCE(Z.HIC_NBR, '') AS HIC_NBR, COALESCE(Z.MBI, '') AS MBI, COALESCE(Z.MBI, Z.HIC_NBR, '') AS MEDICARE_ID,")
					.append(" Z.SUPPLEMENTAL_ID,Z.CMS_EFF_MO,Z.NAME FROM ").append(" ( SELECT DISTINCT D.MEMBER_ID,")
					.append(" (CASE WHEN D.MEMBER_ID>'' THEN (SELECT DS_VALUE FROM EM_MBR_DSINFO WHERE")
					.append(" CUSTOMER_ID = D.CUSTOMER_ID AND MEMBER_ID = D.MEMBER_ID AND DS_CD = 'MED' AND EFF_END_DATE = '99999999' AND OVERRIDE_IND = 'N') END) AS HIC_NBR,")
					.append(" (CASE WHEN D.MEMBER_ID>'' THEN (SELECT DS_VALUE FROM EM_MBR_DSINFO WHERE ")
					.append(" CUSTOMER_ID = D.CUSTOMER_ID AND MEMBER_ID = D.MEMBER_ID AND DS_CD = 'MBI' AND EFF_END_DATE = '99999999' AND OVERRIDE_IND = 'N') END) AS MBI,")
					.append(" E.SUPPLEMENTAL_ID, D.CMS_EFF_MO,")
					.append(" (TRIM(D.LAST_NAME) CONCAT ', ' CONCAT TRIM(D.PREFIX) CONCAT SPACE(1) CONCAT TRIM(D.FIRST_NAME) CONCAT SPACE(1) CONCAT TRIM(D.MIDDLE_INITIAL)) AS NAME ")
					.append(" FROM EM_MBR_DEMOGRAPHIC D JOIN EM_MBR_ENROLLMENT E  ON ")
					.append(" (D.CUSTOMER_ID = E.CUSTOMER_ID AND D.MEMBER_ID =  E.MEMBER_ID AND D.OVERRIDE_IND =  E.OVERRIDE_IND)")
					.append(" JOIN EM_MBR_DSINFO I ON ")
					.append(" (D.CUSTOMER_ID = I.CUSTOMER_ID AND D.MEMBER_ID =  I.MEMBER_ID AND D.OVERRIDE_IND =  I.OVERRIDE_IND AND E.EFF_END_DATE = I.EFF_END_DATE)")
					.append(" WHERE D.CUSTOMER_ID = ? AND D.OVERRIDE_IND = 'N'  AND I.DS_CD IN ('MBI', 'MED') AND E.EFF_END_DATE = '99999999'");

			ArrayList<String> parmList = new ArrayList<>();
			parmList.add(customerId);
			if (!searchMemberId.equals("") && !isPagination) {
				sql.append(" AND D.MEMBER_ID = ?");
				parmList.add(searchMemberId);
			}
			if (!searchMedicareId.equals("")) {
				sql.append(" AND I.DS_VALUE = ?");
				parmList.add(searchMedicareId);
			}
			if (!searchFirstName.equals("")) {
				sql.append(" AND D.FIRST_NAME LIKE ?");
				parmList.add(searchFirstName + "%");
			}
			if (!searchLastName.equals("")) {
				sql.append(" AND D.LAST_NAME LIKE ?");
				parmList.add(searchLastName + "%");
			}
			if (!searchEffMonth.equals("") && !isPagination) {
				sql.append(" AND D.CMS_EFF_MO = ?");
				parmList.add(searchEffMonth);
			} else {
				sql.append(" AND D.CURRENT_IND = 'Y'");
			}
			if (!dob.equals("") && !isPagination) {
				sql.append(" AND D.BIRTH_DATE = ?");
				parmList.add(dob);
			}
			if (!searchSupplementalId.equals("")) {
				// IFOX-00424860 - New member search fields -performance issues:start
				String isSuppCheck = isSuppIdProfile(customerId);
				if (isSuppCheck.equals("Y") && !isSuppPrefix(searchSupplementalId, customerId)) {
					sql.append(" AND SUBSTR(E.SUPPLEMENTAL_ID,4) LIKE ? ");
					parmList.add(searchSupplementalId + "%");
				}
				// IFOX-00424860 - New member search fields -performance issues:end
				else {
					sql.append(" AND E.SUPPLEMENTAL_ID = ? ");
					parmList.add(searchSupplementalId);
				}
			}

			if (isPagination) {

				DataBaseField[] conds = new DataBaseField[2];
				for (int i = 0; i < 2; i++) {
					conds[i] = new DataBaseField();
				}
				conds[0].setFieldName("D.MEMBER_ID");
				conds[1].setFieldName("D.CMS_EFF_MO");
				conds[0].setStringValue(searchMemberId);
				conds[1].setStringValue(searchEffMonth);

				StringBuilder pageCond = PaginationQueryHelper.pagingElements(conds, parmList);
				sql.append(pageCond);
			}

			sql.append(
					" GROUP BY D.CUSTOMER_ID, D.MEMBER_ID, E.SUPPLEMENTAL_ID, D.CMS_EFF_MO, D.LAST_NAME, D.PREFIX, D.FIRST_NAME, D.MIDDLE_INITIAL")
					.append(" ORDER BY D.MEMBER_ID, D.CMS_EFF_MO ").append(" FETCH FIRST  ")
					.append(EEMConstants.DB_MAX_RECORD_FETCH).append(" ROWS ONLY ) Z");

			Object[] objPrams = parmList.toArray();
			List<EEMMbrSearchDO> list = jdbcTemplate.query(sql.toString(), objPrams,
					new DomainPropertyRowMapper<EEMMbrSearchDO>(EEMMbrSearchDO.class));

			List<EEMMbrSearchVO> targetList = new ArrayList<>();

			if (list != null && !list.isEmpty()) {
				if (list.size() > 100) {
					list.remove(list.size() - 1);
					response.setNextPage(true);
				}
				CommonUtils.copyList(list, targetList, EEMMbrSearchVO.class);
			}
			response.setContent(targetList);

			return response;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp);
		}

	}

	// IFOX-00424860 - New member search fields -performance issues:start
	private String isSuppIdProfile(String customerId) {
		EEMProfileItemDO profile = eemProfileSettings.getProfileObject(customerId, "SUPPSRCH");
		if (profile != null) {
			return profile.getParmIndValue();
		}
		return "";
	}

	private boolean isSuppPrefix(String searchSupplementalId, String customerId) {
		try {
			String query = "SELECT DISTINCT(CLIENT_ID) AS PREFIX FROM EM_GRP_PRODUCT WHERE CUSTOMER_ID = ?";
			List<String> prefix = jdbcTemplate.queryForList(query, new Object[] { customerId }, String.class);
			return !prefix.isEmpty() && searchSupplementalId.length() >= 3
					&& searchSupplementalId.substring(0, 3).equals(trimToEmpty(prefix.get(prefix.size() - 1)));
		} catch (DataAccessException e) {
			throw new ApplicationException(e, "Error while checking isSuppPrefix");
		}
	}
	// IFOX-00424860 - New member search fields -performance issues:end

	@Override
	public List<EEMMbrEnrollmentDO> getMbrEnrollments(String customerId, String memberId, String showAll)
			throws ApplicationException {

		String sqlOverride = " AND E.OVERRIDE_IND = 'N'";
		if ("Y".equals(showAll))
			sqlOverride = "";
		String today = DateUtil.getTodaysDate();

		StringBuilder query = CommonUtils.buildQueryBuilder(
				"SELECT DISTINCT * FROM ( SELECT E.CUSTOMER_ID, MEMBER_ID, EFF_START_DATE, CREATE_TIME, EFF_END_DATE, OVERRIDE_IND, ",
				"E.GRP_ID, E.PRODUCT_ID, SUPPLEMENTAL_ID, ENROLL_STATUS, ENROLL_REASON_CD, PLAN_ID, PBP_ID, PBP_SEGMENT_ID, PLAN_TYPE, PLAN_DESIGNATION,",
				"ELECTION_TYPE_CD, SEP_ELECTION_DATE, SEP_REASON_CD, ELC_DERIVED_IND, RX_ID,",
				"DIS_REASON_CD, PLAN_REASON_CD, REQ_REASON_CD,",
				"ENROLL_SRCE_CD, APPLICATION_ID, APPLICATION_DATE, SIGNATURE_DATE, EDIT_OVERRIDE_IND,",
				"CREATE_USERID, E.LAST_UPDT_TIME, E.LAST_UPDT_USERID, RECEIPT_DATE, RECIEVE_DATE, TRG72_IND,",
				"(CASE WHEN (CASE WHEN TRIM(E.ENROLL_STATUS) IN ('EAPRV','EPEND')",
				"THEN CASE WHEN E.EFF_START_DATE > " + today + " THEN E.EFF_START_DATE",
				"WHEN E.EFF_END_DATE < " + today + " THEN E.EFF_END_DATE", "ELSE " + today + " END",
				"ELSE E.EFF_START_DATE END)",
				"BETWEEN G.GRPNAME_START_DATE AND G.GRPNAME_END_DATE THEN G.GROUP_NAME ELSE (SELECT E1.GROUP_NAME FROM EM_GRP_NAME E1",
				"WHERE E1.CUSTOMER_ID = E.CUSTOMER_ID AND E1.GRP_ID = E.GRP_ID ORDER BY E1.GRPNAME_START_DATE DESC  "
						+ "FETCH FIRST 1 ROWS ONLY) END) AS GROUP_NAME,",
				"(CASE WHEN (CASE WHEN TRIM(E.ENROLL_STATUS) IN ('EAPRV','EPEND')",
				"THEN CASE WHEN E.EFF_START_DATE > " + today + " THEN E.EFF_START_DATE",
				"WHEN E.EFF_END_DATE < " + today + " THEN E.EFF_END_DATE", "ELSE " + today + " END",
				"ELSE E.EFF_START_DATE END)",
				"BETWEEN P.PRODNAME_START_DATE AND P.PRODNAME_END_DATE THEN P.PRODUCT_NAME ELSE (SELECT P1.PRODUCT_NAME FROM EM_PRODUCT_NAME P1 ",
				"WHERE P1.CUSTOMER_ID = P.CUSTOMER_ID AND P1.PRODUCT_ID = P.PRODUCT_ID  ",
				"ORDER BY P1.PRODNAME_START_DATE DESC FETCH FIRST 1 ROWS ONLY) END) AS PRODUCT_NAME",
				"FROM EM_MBR_ENROLLMENT E ",
				"JOIN EM_GRP_NAME G ON (G.CUSTOMER_ID = E.CUSTOMER_ID AND G.GRP_ID =  E.GRP_ID AND E.EFF_START_DATE BETWEEN G.GRPNAME_START_DATE AND G.GRPNAME_END_DATE)",
				"JOIN EM_PRODUCT_NAME P ON (P.CUSTOMER_ID = E.CUSTOMER_ID AND P.PRODUCT_ID = E.PRODUCT_ID AND E.EFF_START_DATE BETWEEN PRODNAME_START_DATE AND "
						+ "P.PRODNAME_END_DATE)",
				"WHERE E.CUSTOMER_ID = ? AND MEMBER_ID=?" + sqlOverride + " ",
				") MAINQUERY ORDER BY LAST_UPDT_TIME DESC, EFF_START_DATE DESC, EFF_END_DATE DESC");

		try {
			return jdbcTemplate.query(query.toString(), new Object[] { customerId, memberId },
					new DomainPropertyRowMapper<EEMMbrEnrollmentDO>(EEMMbrEnrollmentDO.class));
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp);
		}

	}

	@Override
	public int setDemographicOverride(EEMMbrDemographicDO oldDemoDO, String userId) throws ApplicationException {
		try {
			String query = CommonUtils.buildQuery(
					"UPDATE EM_MBR_DEMOGRAPHIC" + " SET OVERRIDE_IND = 'Y', LAST_UPDT_TIME = ?, LAST_UPDT_USERID = ?"
							+ " WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? AND CMS_EFF_MO = ? AND DEMO_SEQ_NBR = ?"
							+ " AND OVERRIDE_IND = 'N' AND LAST_UPDT_TIME = ?");

			Object[] parms = new Object[] { DateUtil.getCurrentDatetimeStamp(), userId, oldDemoDO.getCustomerId(),
					oldDemoDO.getMemberId(), oldDemoDO.getCmsEffMonth(), oldDemoDO.getDemoSeqNbr(),
					oldDemoDO.getLastUpdtTime() };
			return jdbcTemplate.update(query, parms);
		} catch (DataAccessException e) {
			throw new ApplicationException(e, "Error while Overriding Demographic");
		}

	}

	@Override
	public int insertMbrDemographic(EEMMbrDemographicDO newDemoDO) throws ApplicationException {
		try {

			String sql = CommonUtils.buildQuery("INSERT INTO EM_MBR_DEMOGRAPHIC(",
					"CUSTOMER_ID, MEMBER_ID, CMS_EFF_MO, DEMO_SEQ_NBR, CURRENT_IND, OVERRIDE_IND,",
					"LAST_NAME, FIRST_NAME, MIDDLE_INITIAL, PREFIX, SUFFIX,",
					"MAIL_LAST_NAME, MAIL_FIRST_NAME, MAIL_MIDDLE_INIT, MAIL_SUFFIX, INS_CARD_NAME, SSN,HIC_NBR,",
					"BIRTH_DATE, DEATH_DATE, MARITAL_STATUS, GENDER_CD, RACE_CD,",
					"MBR_EMAIL, AUTH_LAST_NAME, AUTH_FIRST_NAME, AUTH_MIDDLE_INIT, AUTH_RELATIONSHIP_CD,",
					"EMERGCY_NAME, EMERGCY_PHONE, EMERGCY_RELATIONSHIP_CD, EMERGCY_EMAIL,",
					"LANGUAGE_CD, SPOUSE_WORK_IND, MEMBER_STATUS, FILE_ID,",
					"CREATE_TIME, CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID, ROLLOVER_TIME, ROLLOVER_USERID",
					" , ALT_CORRES_IND ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,",
					"?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,? )");

			String maritalStatus = StringUtil.nonNullTrim(newDemoDO.getMaritalStatus());
			if (maritalStatus.equalsIgnoreCase("U")) {
				maritalStatus = "";
			}
			Object[] parms = new Object[] { newDemoDO.getCustomerId(), newDemoDO.getMemberId(),
					newDemoDO.getCmsEffMonth(), newDemoDO.getDemoSeqNbr(), newDemoDO.getCurrentInd(),
					newDemoDO.getOverrideInd(), newDemoDO.getLastName(), newDemoDO.getFirstName(),
					newDemoDO.getMiddleInitial(), newDemoDO.getPrefix(), newDemoDO.getSuffix(),
					newDemoDO.getMailLastName(), newDemoDO.getMailFirstName(), newDemoDO.getMailMiddleInit(),
					newDemoDO.getMailSuffix(), newDemoDO.getInsCardName(), newDemoDO.getSsn(), "",
					newDemoDO.getBirthDate(), newDemoDO.getDeathDate(), maritalStatus, newDemoDO.getGenderCd(),
					newDemoDO.getRaceCd(), newDemoDO.getMbrEmail(), newDemoDO.getAuthLastName(),
					newDemoDO.getAuthFirstName(), newDemoDO.getAuthMiddleInit(), newDemoDO.getAuthRelationshipCd(),
					newDemoDO.getEmergcyName(), newDemoDO.getEmergcyPhone(), newDemoDO.getEmergcyRelationshipCd(),
					newDemoDO.getEmergcyEmail(), newDemoDO.getLanguageCd(), newDemoDO.getSpouseWorkInd(),
					newDemoDO.getMemberStatus(), newDemoDO.getFileId(), newDemoDO.getCreateTime(),
					newDemoDO.getCreateUserId(), newDemoDO.getLastUpdtTime(), newDemoDO.getLastUpdtUserId(),
					newDemoDO.getRolloverTime(), newDemoDO.getRolloverUserId(), newDemoDO.getAltCorrespondenceInd() };

			return jdbcTemplate.update(sql, parms);

		} catch (DataAccessException e) {
			throw new ApplicationException(e, "Error while inserting Demographics");
		}
	}

	@Override
	public boolean checkMbrTrigger(EMMbrTriggerDO trig) throws ApplicationException {

		try {

			String sql = CommonUtils.buildQuery(
					"SELECT MEMBER_ID FROM EM_MBR_TRIGGER WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? AND TRIGGER_TYPE = ? AND EFFECTIVE_DATE =? ",
					" AND TRIGGER_CODE=? AND TRIGGER_STATUS=? FETCH FIRST 1 ROWS ONLY");

			Object[] parms = new Object[] { trig.getCustomerId(), trig.getMemberId(), trig.getTriggerType(),
					trig.getEffectiveDate(), trig.getTriggerCode(), EEMConstants.TRIG_STATUS_OPEN };
			jdbcTemplate.queryForObject(sql, parms, String.class);
			return true;
		} catch (EmptyResultDataAccessException exp) {
			return false;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error while checkMbrTrigger");
		}

	}

	@Override
	public String getMaxLastUpdate(String customerId, String memberId, String table, Map<String, String> type) {

		String maxLastUpdate = EEMConstants.DEFAULT_INITIAL_TIMESTAMP;
		String columnValue = EEMConstants.BLANK;
		try {
			StringBuilder query = CommonUtils.buildQueryBuilder("SELECT MAX(LAST_UPDT_TIME) FROM", table,
					"WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? AND OVERRIDE_IND = 'N'");
			List<String> parmList = new ArrayList<>();
			parmList.add(customerId);
			parmList.add(memberId);

			if (!CollectionUtils.isEmpty(type)) {
				for (Map.Entry<String, String> entry : type.entrySet()) {
					String columnName = entry.getKey();
					columnValue = entry.getValue();
					query.append(" AND ").append(columnName).append(" = ?");
					parmList.add(columnValue);
				}
			}
			Object[] objParms = parmList.toArray();
			maxLastUpdate = jdbcTemplate.queryForObject(query.toString(), String.class, objParms);
			if (Objects.isNull(maxLastUpdate)) {
				maxLastUpdate = EEMConstants.DEFAULT_INITIAL_TIMESTAMP;
			}
		} catch (EmptyResultDataAccessException exp) {
			maxLastUpdate = EEMConstants.DEFAULT_INITIAL_TIMESTAMP;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_OCCURED_WHILE_FETCHING_MAX_LASTUPDATED);
		}
		return maxLastUpdate;
	}

	@Override
	public String checkMbrTrigger(String customerId, String memberId, String triggerType, String triggerCode)
			throws ApplicationException {

		try {

			String sql = CommonUtils.buildQuery("SELECT EFFECTIVE_DATE FROM EM_MBR_TRIGGER",
					" WHERE CUSTOMER_ID = ? AND MEMBER_ID = ?",
					" AND TRIGGER_TYPE = ? AND TRIGGER_CODE =? AND TRIGGER_STATUS = 'OPEN' ORDER BY LAST_UPDT_TIME DESC FETCH FIRST ROW ONLY");

			return StringUtil.nonNullTrim(jdbcTemplate.queryForObject(sql,
					new Object[] { customerId, memberId, triggerType, triggerCode }, String.class));

		} catch (EmptyResultDataAccessException exp) {
			return "";
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error while checkMbrTrigger");
		}

	}

	@Override
	public EEMMbrSnapshotDO mbrSnapshot(String customerId, String memberId) throws ApplicationException {
		try {
			String whereCondition = CommonUtils.buildQuery("WHERE CUSTOMER_ID=:customerId AND MEMBER_ID=:memberId AND OVERRIDE_IND='N'",
					"AND ( :todayDate BETWEEN EFF_START_DATE AND EFF_END_DATE OR EFF_START_DATE >=:todayDate )");

			MapSqlParameterSource params = new MapSqlParameterSource();
			params.addValue("customerId", customerId);
			params.addValue("memberId", memberId);
			params.addValue("todayDate", DateUtil.getTodaysDate());
			
			EEMMbrSnapshotDO snapshotDO = new EEMMbrSnapshotDO();
			setLISData(whereCondition, params, snapshotDO);
			setLEPData(whereCondition, params, snapshotDO);
			setPCPData(whereCondition, params, snapshotDO);
			setBillingData(params, snapshotDO);

			return snapshotDO;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error while mbrSnapshot");
		}
	}

	private void setLISData(String whereCondition, SqlParameterSource paramSource, EEMMbrSnapshotDO snapshotDO) {
		String sql = CommonUtils.buildQuery("SELECT LI_COPAY_CD, LIS_PCT_CD, LIS_AMT FROM EM_MBR_LIS", whereCondition);
		namedParameterJdbcTemplate.query(sql, paramSource, rs -> {
			snapshotDO.setLisCopayCd(rs.getString(1));
			snapshotDO.setLisPctCd(rs.getString(2));
			snapshotDO.setLisAmt(rs.getString(3));
		});
	}

	private void setLEPData(String whereCondition, SqlParameterSource paramSource, EEMMbrSnapshotDO snapshotDO) {
		String sql = CommonUtils.buildQuery("SELECT NBR_UNCOV_MONTHS, LEP_AMT FROM EM_MBR_LEP", whereCondition);
		namedParameterJdbcTemplate.query(sql, paramSource, rs -> {
			snapshotDO.setNumUnCovMths(rs.getString(1));
			snapshotDO.setLepAmt(rs.getString(2));
		});
	}

	private void setPCPData(String whereCondition, MapSqlParameterSource paramSource, EEMMbrSnapshotDO snapshotDO) {
		String sql = CommonUtils.buildQuery("SELECT PCP_NAME FROM EM_MBR_PCP", whereCondition);
		namedParameterJdbcTemplate.query(sql, paramSource, rs -> {
			snapshotDO.setPcpName(rs.getString(1));
		});
	}

	private void setBillingData(MapSqlParameterSource paramSource, EEMMbrSnapshotDO snapshotDO) {
		String sql = CommonUtils.buildQuery(
				"SELECT VARCHAR_FORMAT(SUM(INVOICE_AMT)+SUM(PAYMENT_AMT)+SUM(ADJUSTMENT_AMT))",
				"AS BILLING_AMT FROM BBB_INVOICE_HEADER WHERE CUSTOMER_ID=:customerId AND INVOICE_ID=:memberId");
		namedParameterJdbcTemplate.query(sql, paramSource, rs -> {
			snapshotDO.setBillingAmt(rs.getString("BILLING_AMT"));
		});
	}

	@Override
	public String getLepPlatinoFlag(String customerId, String memberId) {

		String parmInd = "";
		String parmText = "";
		String lepTrgSkip = "false";
		String specialInd = "";
		
		EEMProfileItemDO profile = eemProfileSettings.getProfileObject(customerId, EEMConstants.LEPTRGSKIP);
		if (profile != null) {
			parmInd=profile.getParmIndValue();
			parmText=profile.getParmTextValue();
		}
		
		String query1 = CommonUtils.buildQuery(
					"SELECT GRP_ID, PRODUCT_ID, PLAN_ID, PBP_ID, PBP_SEGMENT_ID, EFF_START_DATE FROM EM_MBR_ENROLLMENT",
					"WHERE CUSTOMER_ID = ? AND ENROLL_STATUS = 'EAPRV' AND MEMBER_ID = ?",
					"AND OVERRIDE_IND = 'N' ORDER BY EFF_START_DATE DESC, EFF_END_DATE DESC FETCH FIRST 1 ROW ONLY");
		
		Object[] objParms1 = new Object[] {customerId, memberId};
		
		List<EEMMbrEnrollmentDO> mbrEnrollmentDO = new ArrayList<>();
		try {
			mbrEnrollmentDO = jdbcTemplate.query(query1,
					new DomainPropertyRowMapper<EEMMbrEnrollmentDO>(EEMMbrEnrollmentDO.class), objParms1);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
		
		if (! mbrEnrollmentDO.isEmpty()) {
			Object[] objParms2 = new Object[] {customerId, mbrEnrollmentDO.get(0).getGrpId(),
					mbrEnrollmentDO.get(0).getProductId(), mbrEnrollmentDO.get(0).getPlanId(),
					mbrEnrollmentDO.get(0).getPbpId(), mbrEnrollmentDO.get(0).getPbpSegmentId(),
					mbrEnrollmentDO.get(0).getEffStartDate()};
			try {
			String query2 = CommonUtils.buildQuery(
						"SELECT SPECIAL_TYPE_IND FROM EM_GRP_PRODUCT WHERE CUSTOMER_ID = ? ",
					    "AND GRP_ID = ? AND PRODUCT_ID = ? AND PLAN_ID = ? AND PBP_ID = ? AND PBP_SEGMENT_ID = ?",
						"AND ? BETWEEN GRP_PROD_START_DATE AND GRP_PROD_END_DATE ORDER BY LAST_UPDT_TIME DESC FETCH FIRST ROW ONLY");
			specialInd = jdbcTemplate.queryForObject(query2, objParms2, String.class);
			}
			catch (EmptyResultDataAccessException exp) {
				specialInd ="";
			} catch (DataAccessException exp) {
				throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
			}
			
			if(parmInd.equals("Y") && parmText.equals(specialInd) && specialInd.equals("A"))
					lepTrgSkip = "true";
		} 
		return lepTrgSkip;
	}
}
