package com.medicare.mss.daoImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMMbrCobDAO;
import com.medicare.mss.domainobject.EEMMbrCobDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.vo.EMDatedSegmentVO;

@Repository
public class EEMMbrCobDAOImpl implements EEMMbrCobDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<EEMMbrCobDO> getMbrCob(String customerId, String memberId, String showAll) {

		List<EEMMbrCobDO> mbrCobDOList = new ArrayList<>();
		try {
			String sqlOverride = " AND OVERRIDE_IND = 'N'";
			if (EEMConstants.VALUE_YES.equals(showAll))
				sqlOverride = EEMConstants.BLANK;

			StringBuilder sQuery = new StringBuilder("SELECT CUSTOMER_ID, MEMBER_ID, EFF_START_DATE, EFF_END_DATE,")
					.append(" OVERRIDE_IND, COB_TYPE, OHI_IND, RX_GRP, RX_NAME, RX_ID, RX_BIN, RX_PCN,")
					.append(" CREATE_TIME, CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID FROM EM_MBR_COB")
					.append(" WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? " + sqlOverride)
					.append(" ORDER BY COB_TYPE ASC, EFF_START_DATE DESC");

			Object[] parms = new Object[] { customerId, memberId };

			mbrCobDOList = jdbcTemplate.query(sQuery.toString(), parms,
					new DomainPropertyRowMapper<EEMMbrCobDO>(EEMMbrCobDO.class));

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_OCCURED_WHILE_FETCHING_SEGMENTS);
		}
		return mbrCobDOList;
	}

	@Override
	public int insertMbr(EMDatedSegmentVO emDatedSegmentVO) {

		EEMMbrCobDO eemMbrCobVO = (EEMMbrCobDO) emDatedSegmentVO;

		try {
			StringBuilder sQuery = new StringBuilder("INSERT INTO EM_MBR_COB( CUSTOMER_ID, MEMBER_ID, COB_TYPE,")
					.append(" OHI_IND, EFF_START_DATE, EFF_END_DATE, OVERRIDE_IND,")
					.append(" CREATE_TIME, CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID,")
					.append(" RX_GRP, RX_NAME, RX_ID, RX_BIN, RX_PCN)")
					.append(" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

			Object[] parms = new Object[] { eemMbrCobVO.getCustomerId(), eemMbrCobVO.getMemberId(),
					eemMbrCobVO.getCobType(), eemMbrCobVO.getOhiInd(), eemMbrCobVO.getEffStartDate(),
					eemMbrCobVO.getEffEndDate(), eemMbrCobVO.getOverrideInd(), eemMbrCobVO.getCreateTime(),
					eemMbrCobVO.getCreateUserId(), eemMbrCobVO.getLastUpdtTime(), eemMbrCobVO.getLastUpdtUserId(),
					eemMbrCobVO.getRxGrp(), eemMbrCobVO.getRxName(), eemMbrCobVO.getRxId(), eemMbrCobVO.getRxBin(),
					eemMbrCobVO.getRxPcn() };

			return jdbcTemplate.update(sQuery.toString(), parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_OCCURED_WHILE_INSERTING_NEW_SEGMENT);
		}
	}

	@Override
	public int setOverride(EMDatedSegmentVO emDatedSegmentVO, String userId) {

		EEMMbrCobDO eemMbrCobVO = (EEMMbrCobDO) emDatedSegmentVO;

		try {
			StringBuilder sQuery = new StringBuilder("UPDATE EM_MBR_COB SET OVERRIDE_IND = 'Y', LAST_UPDT_TIME = CURRENT_TIMESTAMP,")
					.append(" LAST_UPDT_USERID = ? WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? AND COB_TYPE = ? AND OHI_IND = ?")
					.append(" AND EFF_START_DATE = ? AND CREATE_TIME = ? AND OVERRIDE_IND = 'N' AND LAST_UPDT_TIME = ?");

			Object[] parms = new Object[] { userId, eemMbrCobVO.getCustomerId(), eemMbrCobVO.getMemberId(),
					eemMbrCobVO.getCobType(), eemMbrCobVO.getOhiInd(), eemMbrCobVO.getEffStartDate(),
					eemMbrCobVO.getCreateTime(), eemMbrCobVO.getLastUpdtTime() };

			return jdbcTemplate.update(sQuery.toString(), parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_OCCURED_WHILE_OVERRIDING_SEGMENT);
		}
	}

}
