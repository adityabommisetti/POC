/**
 * 
 */
package com.medicare.mss.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

/**
 * @author dkumar
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EEMBillingInvTransferVO {

	private EEMBillingInvHeaderDtlsVO billHeaderVO;
	private EEMBillingInvoiceDtlsVO billInvVO;
	private String transGrpId;
	private String transName;
	private String transAmt;
}
