package com.medicare.mss.domainobject;

import lombok.Data;

@Data
public class EEMApplOtherPlanDO {

	private String currentPatientInd;
	private String lastUpdtTime;
	private String locationId;
	private String officeCategoryCd;
	private String officeCd;
	private String pcpName;
	private String premiumAmt;
	private String alternateOfficeCd;
	private String customerId;
	private String lastUpdtUserId;
	private int applId;
	

}
