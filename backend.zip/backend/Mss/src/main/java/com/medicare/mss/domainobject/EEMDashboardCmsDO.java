package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMDashboardCmsDO {

	@ColumnMapper(columnName = "MEMBER_ID", propertyName = "memberId")
	private String memberId;

	@ColumnMapper(columnName = "MEDICARE_ID", propertyName = "medicareId")
	private String medicareId;

	@ColumnMapper(columnName = "SUPPLEMENTAL_ID", propertyName = "supplementalId")
	private String supplementalId;

	@ColumnMapper(columnName = "TRANSACTION_TYPE", propertyName = "transactionType")
	private String transactionType;

	@ColumnMapper(columnName = "TRIGGER_CODE", propertyName = "triggerCode")
	private String triggerCode;

	@ColumnMapper(columnName = "ENROLL_REASON_CD", propertyName = "enrollReasonCode")
	private String enrollReasonCode;

	@ColumnMapper(columnName = "FIRST_NAME", propertyName = "firstName")
	private String firstName;

	@ColumnMapper(columnName = "LAST_NAME", propertyName = "lastName")
	private String lastName;

	@ColumnMapper(columnName = "PRODUCT_NAME", propertyName = "prodName")
	private String prodName;

	@ColumnMapper(columnName = "TYPE", propertyName = "type")
	private String type;

}
