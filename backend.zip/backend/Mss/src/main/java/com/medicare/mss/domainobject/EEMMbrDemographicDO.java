package com.medicare.mss.domainobject;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class EEMMbrDemographicDO extends BaseDO {

	private String altCorrespondenceInd;
	private String authFirstName;
	private String authLastName;
	private String authMiddleInit;
	private String authRelationshipCd;
	private String birthDate;
	private String cmsEffMonth;
	private String currentInd;
	private String deathDate;
	private int demoSeqNbr;
	private String emergcyEmail;
	private String emergcyName;
	private String emergcyPhone;
	private String emergcyRelationshipCd;
	private String fileId;
	private String firstName;
	private String genderCd;
	private String hicNbr;
	private String insCardName;
	private String languageCd;
	private String lastName;
	private String mailFirstName;
	private String mailLastName;
	private String mailMiddleInit;
	private String mailSuffix;
	private String maritalStatus;
	private String mbrEmail;
	private String memberId;
	private String memberStatus;
	private String middleInitial;
	private String overrideInd;
	private String prefix;
	private String raceCd;
	private String rolloverTime;
	private String rolloverUserId;
	private String spouseWorkInd;
	private String ssn;
	private String suffix;

}
