package com.medicare.mss.vo;

import com.medicare.mss.vo.BaseVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class EMMbrTriggerVO extends BaseVO {
	
	private static final long serialVersionUID = 3581411515131310906L;

	private String memberId;
	private String triggerType;
	private String effectiveDate;
	private String triggerCode;
	private String planId;
	private String pbpId;
	private String mbrFName;
	private String mbrLName;
	private String planDesignation;
	private String triggerStatus;
	private String processSource;
	private String origTriggerType;
	private String origTriggerCode;
	private String origEffectiveDate;
	private String origTriggerCreateTime;
	private String fileBatchId;
	private String letterName;
	private String recordType;
	
	
}