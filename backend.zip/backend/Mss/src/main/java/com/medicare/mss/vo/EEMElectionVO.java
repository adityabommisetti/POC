package com.medicare.mss.vo;

import lombok.Data;

@Data
public class EEMElectionVO {
	
	private String applicationDt;
	private String applType;
	private String birthDt;
	private String customerId;
	private String dayBeforeRequestedDateOfCoverage;
	private String earliestEnrlStartDt;
	private String effectiveStartDate;
	private String elcDerivedInd="N";
	private String electionType;
	private String errorCode;
	private boolean ICEP_Flag;
	private boolean IEP_Flag;
	private boolean IEP2_Flag;
	private boolean isPlanBlank;
	private boolean isPlanPDP;
	private String lastUsedSepDate;
	private String longTermFacId;
	private String matchedQuarterDetails;
    private String memberId;
    private boolean memberPresentInM360;
   	private String partAEntlDt;
	private String partBEntlDt;
	private String partDElgDt;
	private String planDesgn;
	private String reqDtCov;
	private String strApplicationDate;
	
}
