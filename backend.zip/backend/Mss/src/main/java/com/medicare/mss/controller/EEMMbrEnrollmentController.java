package com.medicare.mss.controller;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.domainobject.EEMApplProductDO;
import com.medicare.mss.domainobject.EEMGroupProductSearchDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.service.EEMMbrEnrollmentService;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EEMMbrEnrollmentVO;
import com.medicare.mss.vo.EEMMbrPrintIDCardVO;
@RestController
@RequestMapping("/member")
public class EEMMbrEnrollmentController {
	
	@Autowired
	private EEMMbrEnrollmentService enrollService;
	
	
	@PostMapping(path = ReqMappingConstants.MBR_ENROLL_UPDATE)
	public ResponseEntity<JSONResponse> mbrEnrollmentUpdate(@RequestBody EEMMbrEnrollmentVO mbrenrollmentVO) throws ApplicationException, ParseException, CloneNotSupportedException {
		
		Map<String, Object> resultMap = enrollService.mbrEnrollmentUpdate(mbrenrollmentVO);
		return sendResponse(resultMap);
		
	}
	
	
	@GetMapping(path = ReqMappingConstants.MBR_ENROLL_SEARCH)
	public ResponseEntity<JSONResponse> getMbrEnrollment(@PathVariable(name = "mbrId") String memberId,
			@PathVariable(name = "showAll") String showAll) throws ApplicationException {
		
		List<EEMMbrEnrollmentVO> enrollVOList = enrollService.getListFromContext(memberId, showAll);
		return sendResponse(enrollVOList);
		
	}
	

	@PostMapping(path = ReqMappingConstants.GRP_PROD_PLAN_TYPE_GET)
	public ResponseEntity<JSONResponse> getPlanType(@RequestBody Map<String, String> searchParamMap) throws ApplicationException {
		String planId=StringUtil.nonNullTrim(searchParamMap.get("planId"));
		String pbpId=StringUtil.nonNullTrim(searchParamMap.get("pbpId"));
		String planType = enrollService.getPlanType(planId,pbpId);
		return sendResponse(planType);
		
	}
	
	@PostMapping(path = ReqMappingConstants.GRP_PROD_SEARCH_MBR)
	public ResponseEntity<JSONResponse> grpProdSearch(@RequestBody EEMGroupProductSearchDO gpSearch) throws ApplicationException {
		
		List<EEMApplProductDO> data = enrollService.memberGrpPrdSearch(gpSearch);
		return sendResponse(data);
		
	}
	
	@PostMapping(path = ReqMappingConstants.PRINT_ID_CARD_MBR_ENROLLMENT)
	public ResponseEntity<JSONResponse> printIDCard(@RequestBody EEMMbrPrintIDCardVO mbrPrintIDCardVO) {
		
		String msg = enrollService.insertPrintIDCardMbrTrigger(mbrPrintIDCardVO);
		return sendResponse(msg);
		
	}

	private ResponseEntity<JSONResponse> sendResponse(Object object) {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;
		if (null == object) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			jsonResponse.setData(null);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
			jsonResponse.setMessage(EEMConstants.BLANK);
			jsonResponse.setData(object);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}

}
