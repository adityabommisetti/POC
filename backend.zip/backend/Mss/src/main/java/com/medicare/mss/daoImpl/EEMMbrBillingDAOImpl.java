package com.medicare.mss.daoImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMMbrBillingDAO;
import com.medicare.mss.domainobject.EEMMbrBillingDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.vo.EMDatedSegmentVO;

@Repository
public class EEMMbrBillingDAOImpl implements EEMMbrBillingDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<EEMMbrBillingDO> getMbrBilling(String customerId, String memberId, String showAll) {

		List<EEMMbrBillingDO> mbrBillingDOList = new ArrayList<>();
		try {
			String sqlOverride = " AND OVERRIDE_IND = 'N'";
			if (EEMConstants.VALUE_YES.equals(showAll))
				sqlOverride = EEMConstants.BLANK;

			StringBuilder sQuery = new StringBuilder("SELECT CUSTOMER_ID, MEMBER_ID, EFF_START_DATE, EFF_END_DATE,")
					.append(" OVERRIDE_IND, BILL_LAST_NAME, BILL_FIRST_NAME, BILL_MIDDLE_INIT,")
					.append(" BILL_SUFFIX, BILL_PAY_METHOD_CD, ABA_ROUTING_NBR, BANK_ACCT_NBR,")
					.append(" BANK_NAME, ACCOUNT_TYPE, NAME_ON_ACCT, DRAFT_DAY, DRAFT_OVERRIDE_AMT,")
					.append(" BILL_FREQUENCY, CREATE_TIME, CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID")
					.append(" FROM EM_MBR_BILLING WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? " + sqlOverride)
					.append(" ORDER BY EFF_START_DATE DESC");

			Object[] parms = new Object[] { customerId, memberId };

			mbrBillingDOList = jdbcTemplate.query(sQuery.toString(), parms,
					new DomainPropertyRowMapper<EEMMbrBillingDO>(EEMMbrBillingDO.class));

		} catch (Exception exp) {
			throw new ApplicationException(exp);
		}
		return mbrBillingDOList;
	}

	@Override
	public int insertMbr(EMDatedSegmentVO emDatedSegmentVO) {

		EEMMbrBillingDO emMbrBillingVO = (EEMMbrBillingDO) emDatedSegmentVO;
		try {
			StringBuilder sQuery = new StringBuilder("INSERT INTO EM_MBR_BILLING( CUSTOMER_ID, MEMBER_ID,")
					.append(" EFF_START_DATE, EFF_END_DATE, OVERRIDE_IND,")
					.append(" CREATE_TIME, CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID,")
					.append(" BILL_LAST_NAME, BILL_FIRST_NAME, BILL_MIDDLE_INIT, BILL_SUFFIX,")
					.append(" BILL_PAY_METHOD_CD, ABA_ROUTING_NBR, BANK_ACCT_NBR, BANK_NAME,")
					.append(" ACCOUNT_TYPE, NAME_ON_ACCT, DRAFT_DAY, DRAFT_OVERRIDE_AMT, BILL_FREQUENCY)")
					.append(" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,? )");

			Object[] parms = new Object[] { emMbrBillingVO.getCustomerId(), emMbrBillingVO.getMemberId(),
					emMbrBillingVO.getEffStartDate(), emMbrBillingVO.getEffEndDate(), emMbrBillingVO.getOverrideInd(),
					emMbrBillingVO.getCreateTime(), emMbrBillingVO.getCreateUserId(), emMbrBillingVO.getLastUpdtTime(),
					emMbrBillingVO.getLastUpdtUserId(), emMbrBillingVO.getBillLastName(),
					emMbrBillingVO.getBillFirstName(), emMbrBillingVO.getBillMiddleInit(),
					emMbrBillingVO.getBillSuffix(), emMbrBillingVO.getBillPayMethod(),
					emMbrBillingVO.getAbaRoutingNbr(), emMbrBillingVO.getBankAcctNbr(), emMbrBillingVO.getBankName(),
					emMbrBillingVO.getAccountType(), emMbrBillingVO.getNameOnAct(), emMbrBillingVO.getDraftDay(),
					emMbrBillingVO.getDraftOverrideAmt(), emMbrBillingVO.getBillFrequency() };

			return jdbcTemplate.update(sQuery.toString(), parms);

		} catch (Exception exp) {
			throw new ApplicationException(exp);
		}
	}

	@Override
	public int setOverride(EMDatedSegmentVO emDatedSegmentVO, String userId) {

		EEMMbrBillingDO emMbrBillingVO = (EEMMbrBillingDO) emDatedSegmentVO;
		try {
			StringBuilder sQuery = new StringBuilder("UPDATE EM_MBR_BILLING SET OVERRIDE_IND = 'Y',")
					.append(" LAST_UPDT_TIME = CURRENT_TIMESTAMP, LAST_UPDT_USERID = ?")
					.append(" WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? AND EFF_START_DATE = ?")
					.append(" AND CREATE_TIME = ? AND OVERRIDE_IND = 'N' AND LAST_UPDT_TIME = ?");

			Object[] parms = new Object[] { userId, emMbrBillingVO.getCustomerId(), emMbrBillingVO.getMemberId(),
					emMbrBillingVO.getEffStartDate(), emMbrBillingVO.getCreateTime(),
					emMbrBillingVO.getLastUpdtTime() };

			return jdbcTemplate.update(sQuery.toString(), parms);

		} catch (Exception exp) {
			throw new ApplicationException(exp);
		}
	}

}
