package com.medicare.mss.vo;

public class EEMAgentVo {

}
