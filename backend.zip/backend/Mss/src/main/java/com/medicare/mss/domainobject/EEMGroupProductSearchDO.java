package com.medicare.mss.domainobject;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EEMGroupProductSearchDO {

	private String customerId;
	private String memberId;
	private String grpId;
	private String groupName;
	private String productId;
	private String productName;
	private String effDate;
	private String outOfArea;
	private String zipCd5;
	private String zipCd4;
	private String planId;
	private String pbpId;
	private String pbpSegmentId;
	private String mcCustNbr;
	private String ssaState;
	private String ssaCnty;
	private String flag;
	private String applType;

	public EEMGroupProductSearchDO() {
		this.customerId = "";
		this.memberId = "";
		this.grpId = "";
		this.groupName = "";
		this.productId = "";
		this.productName = "";
		this.effDate = "";
		this.outOfArea = "";
		this.zipCd5 = "";
		this.zipCd4 = "";
		this.planId = "";
		this.pbpId = "";
		this.pbpSegmentId = "";
		this.mcCustNbr = "";
		this.ssaState = "";
		this.ssaCnty = "";
		this.flag = "";
		this.applType = "";
	}

}
