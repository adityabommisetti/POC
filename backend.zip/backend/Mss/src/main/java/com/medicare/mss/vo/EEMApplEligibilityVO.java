package com.medicare.mss.vo;

import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
public class EEMApplEligibilityVO {
	
	
	private String PartAEffDate;
	private String PartBEffDate;
	private String PartAEndDate;
	private String PartBEndDate;
	private String PartDEffDate;
	private String InstStartDt;
	private String InstEndDt;
	private String EsrdStartDt;
	private String EsrdEndDt;
	private String MedicStartDt;
	private String MedicEndDt;
	private String LastChkedTime;
	private String EligOverInd;
	
	private String customerId;
	private int applicationId;
	
	public String getLastChkedTimeFrmt() {
		return DateFormatter.reFormat(LastChkedTime, DateFormatter.DB2_TIMESTAMP, DateFormatter.MM_DD_YYYY_HH_MM_SS);
	}
}
