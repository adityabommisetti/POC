package com.medicare.mss.domainobject;
import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMFieldErrorDO {
	
	@ColumnMapper(columnName = "ERROR_CD", propertyName = "errorCd")
	private String errorCd;
	
	private String errorData;
	
	@ColumnMapper(columnName = "ERROR_TYPE", propertyName = "errorType")
	private String errorType;
	
	@ColumnMapper(columnName = "ERROR_MESSAGE", propertyName = "errorMessage")
	private String errorMessage;
	
	@ColumnMapper(columnName = "FORM_FIELD", propertyName = "formField")
	private String formField;
	
	@ColumnMapper(columnName = "FIELD_NBR", propertyName = "fieldNbr")
	private String fieldNbr;
	
	@ColumnMapper(columnName = "EDIT_VALID_VALUE", propertyName = "editValidVal")
	private String editValidVal;
	
	@ColumnMapper(columnName = "EDIT_RULE_ID", propertyName = "editRuleId")
	private String editRuleId;
	
	@ColumnMapper(columnName = "EXCEPTION_VALUE", propertyName = "exceptionVal")
	private String exceptionVal;
	
	@ColumnMapper(columnName = "REQUIRED_IND", propertyName = "requiredInd")
	private String requiredInd;
	
	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;
	
	@ColumnMapper(columnName = "EDIT_FROM_VALID_VALUE", propertyName = "editFrom")
	private String editFrom;
	
	@ColumnMapper(columnName = "EDIT_TO_VALID_VALUE", propertyName = "editTo")
	private String editTo;
	
}
