/*
 * $Id: EmMbrErrorVO.java,v 1.1 2014/06/26 07:41:48 praveen Exp $
 */

package com.medicare.mss.vo;

import java.io.Serializable;

import lombok.Data;

/**
 * @author Wipro Ltd.
 */
@Data
public class EmMbrErrorVO implements Cloneable, Serializable {

	/**
	 * generated serial version ID
	 */
	private static final long serialVersionUID = -7516151375754210200L;
	private String customerId;
	private String errorCd;
	private String errorData;
	private String errorMsg;
	private int errorSeqNbr;
	private String errorStatus;
	private String fieldNbr;
	private String fieldDispName;
	private String lastUpdtTime;
	private String lastUpdtUserId;
	private String memberId;
	private String rfiInd;

	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	
	
}
