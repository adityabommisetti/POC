/**
 * 
 */
package com.medicare.mss.controller;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.service.EEMMbrLtcService;
import com.medicare.mss.vo.EEMMbrLtcInfoVO;
import com.medicare.mss.vo.EEMMbrLtcSearchVO;

/**
 * @author Wipro Ltd.
 *
 */

@RestController
@RequestMapping("/mbr")
public class EEMMbrLtcController {

	private static final String LTC_NOT_VALID_FOR_EFFECTIVE_DATE = "LTC is Not Valid for the Effective Date";

	@Autowired
	private EEMMbrLtcService eemMbrLtcService;

	@PostMapping(ReqMappingConstants.MBR_LTC_SEARCH)
	public ResponseEntity<JSONResponse> mbrLtcSearch(@RequestBody EEMMbrLtcSearchVO mbrLtcSearchVO) {
		List<EEMMbrLtcInfoVO> mbrLtcInfoList = eemMbrLtcService.mbrLtcSearch(mbrLtcSearchVO);
		return sendResponse(mbrLtcInfoList);
	}
	
	@GetMapping(ReqMappingConstants.MBR_GET_LTC)
	public ResponseEntity<JSONResponse> getMbrLtcInfoList(@PathVariable(name = "mbrId") String mbrId,
			@PathVariable(name = "showAll") String showAll) {
		List<EEMMbrLtcInfoVO> mbrLtcInfoList = eemMbrLtcService.getMbrLtcInfoList(mbrId, showAll);
		return sendResponse(mbrLtcInfoList);
	}

	@PostMapping(ReqMappingConstants.MBR_UPDATE_LTC)
	public ResponseEntity<JSONResponse> updateMbrLtcInfo(@RequestBody EEMMbrLtcInfoVO mbrLtcInfo) {

		boolean ltcFacilityFound = eemMbrLtcService.checkLtcFacility(mbrLtcInfo);
		boolean updateSuccess = false;
		
		if (ltcFacilityFound) {
			updateSuccess = eemMbrLtcService.updateMbrLtcInfo(mbrLtcInfo);
		} else {
			throw new ApplicationException(LTC_NOT_VALID_FOR_EFFECTIVE_DATE);
		}

		Map<String, Object> resultMap =	eemMbrLtcService.buildResultMap(mbrLtcInfo, updateSuccess);

		return sendResponse(resultMap);
	}

	@PostMapping(ReqMappingConstants.MBR_DELETE_LTC)
	public ResponseEntity<JSONResponse> deleteMbrLtcInfo(@RequestBody EEMMbrLtcInfoVO mbrLtcInfoVO) {
		
		List<EEMMbrLtcInfoVO> mbrLtcInfoList = null;
		boolean deleteSuccess = eemMbrLtcService.deleteMbrLtcInfo(mbrLtcInfoVO);

		if (deleteSuccess) {
			mbrLtcInfoList = eemMbrLtcService.getMbrLtcInfoList(mbrLtcInfoVO.getMemberId(),
					mbrLtcInfoVO.getShowAll());
		} 
		
		return sendResponse(mbrLtcInfoList);
	}

	private ResponseEntity<JSONResponse> sendResponse(Object result) {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;

		if (Objects.isNull(result)) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setData(result);
			jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
			jsonResponse.setMessage(EEMConstants.SUCCESS);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}
	
}
