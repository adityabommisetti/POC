package com.medicare.mss.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.service.EEMApplPopUpService;

@RestController
@RequestMapping("/appl")
public class EEMPopUpController {

	@Autowired
	private EEMApplPopUpService popUpService;

	@PostMapping(path = ReqMappingConstants.POP_UP_AGENCY)
	public ResponseEntity<JSONResponse> eemApplAgencySearch(@RequestBody Map<String, String> searchParamMap) {

		return sendResponse(popUpService.eemApplAgencySearch(searchParamMap));
	}

	@PostMapping(path = ReqMappingConstants.POP_UP_PCP)
	public ResponseEntity<JSONResponse> eemApplPcpSearch(@RequestBody Map<String, String> searchParamMap) {
		/*
		 * String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
		 * 
		 * //Access health PCP CR- Start String npiInd = (String)
		 * sessionHelper.getAttribute("NPIIND"); if(null == npiInd ||
		 * npiInd.trim().equals("")) { npiInd =
		 * EEMProfileSettings.getCalendarProfileItem(eemDb, sessionHelper.getMfId(),
		 * "NPIIND"); sessionHelper.setAttribute("NPIIND", npiInd); }
		 */
		// Access health PCP CR- End

		return sendResponse(popUpService.getLstPCPNames(searchParamMap));
	}

	@PostMapping(path = ReqMappingConstants.POP_UP_CITY_ZIP)
	public ResponseEntity<JSONResponse> eemApplCitySearch(@RequestBody Map<String, String> searchParamMap) {

		return sendResponse(popUpService.eemApplCitySearch(searchParamMap));
	}

	@PostMapping(path = ReqMappingConstants.POP_UP_GRP_PROD)
	public ResponseEntity<JSONResponse> eemApplProdSearch(@RequestBody Map<String, String> searchParamMap) {

		return sendResponse(popUpService.eemApplProdSearch(searchParamMap));
	}

	private ResponseEntity<JSONResponse> sendResponse(Object object) {

		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;
		jsonResponse.setData(object);
		if (null == object) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setMessage(HttpStatus.OK.getReasonPhrase());
			jsonResponse.setData(object);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}

}
