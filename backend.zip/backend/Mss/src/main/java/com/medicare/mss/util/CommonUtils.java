/**
 * 
 */
package com.medicare.mss.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.exception.ApplicationException;

/**
 * @author Wipro Ltd.
 *
 */
public final class CommonUtils {

	private CommonUtils() {
		// private constructor to resolve sonar violation
	}

	public static String buildQuery(String... queryStr) {
		return buildQueryBuilder(queryStr).toString();
	}

	public static StringBuilder buildQueryBuilder(String... queryStr) {
		StringBuilder queryBuilder = new StringBuilder();
		Arrays.asList(queryStr).forEach(qstr -> queryBuilder.append(qstr).append(StringUtils.SPACE));
		return queryBuilder;
	}

	public static String getLepAttestCallStatus(String status) {

		if ("C".equalsIgnoreCase(status)) {
			status = "COMPLETED";
		} else if ("M".equalsIgnoreCase(status)) {
			status = "MISSING";
		} else if ("I".equalsIgnoreCase(status)) {
			status = "INCOMPLETE";
		}
		return status;
	}

	public static String getBreakCovType(String brkCovg) {

		if ("Y".equalsIgnoreCase(brkCovg)) {
			brkCovg = "Yes";

		} else if ("N".equalsIgnoreCase(brkCovg)) {
			brkCovg = "No";

		} else if ("P".equalsIgnoreCase(brkCovg)) {
			brkCovg = "Partial";

		}
		return brkCovg;
	}

	public static String getRespType(String status) {

		if ("X".equalsIgnoreCase(status)) {
			status = "Fax";
		} else if ("F".equalsIgnoreCase(status)) {
			status = "Form";
		} else if ("T".equalsIgnoreCase(status)) {
			status = "Telephonic";
		} else if ("O".equalsIgnoreCase(status)) {
			status = "Onsite";
		}
		return status;
	}

	/**
	 * Copy the source list into the target list.
	 * 
	 * @param <T>
	 *            Type of source bean
	 * @param <U>
	 *            Type of target bean
	 * @param srcList
	 *            the source list
	 * @param targetList
	 *            the target list
	 * @param targetClass
	 *            class of target
	 */
	public static <T, U> void copyList(List<T> srcList, List<U> targetList, Class<U> targetClass) {

		Assert.notNull(srcList, "Source list must not be null");
		Assert.notNull(targetList, "Target list must not be null");
		Assert.notNull(targetClass, "Target class must not be null");

		srcList.forEach(src -> {
			U target = BeanUtils.instantiateClass(targetClass);
			BeanUtils.copyProperties(src, target);
			targetList.add(target);
		});
	}

	public static double ensureDouble(String s) {
		s = StringUtil.nonNullTrim(s);
		if (!s.isEmpty())
			return Double.parseDouble(s);
		return 0;
	}

	public static String[] getChunks(String fieldValue) {

		fieldValue = StringUtils.trimToNull(fieldValue);
		int len = fieldValue.length();
		int numChunks = len / 55;
		if ((numChunks * 55) < len)
			numChunks += 1;
		String[] chunks = new String[numChunks];
		int idx = 0;
		int pos = 0;
		int endPos;
		while (pos < len) {
			endPos = pos + 55;
			if (endPos > len)
				endPos = len;
			chunks[idx] = fieldValue.substring(pos, endPos);
			idx += 1;
			pos += 55;
		}
		return chunks;
	}

	public static Object trimObject(Object obj) {
		for (Field field : obj.getClass().getDeclaredFields()) {
			try {
				field.setAccessible(true);
				Object value = field.get(obj);
				if (value != null) {
					if (value instanceof String) {
						String trimmed = (String) value;
						field.set(obj, trimmed.trim());
					}
				} else {
					if (field.getType().equals(String.class)) {
						field.set(obj, "");
					}

				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return obj;
	}

	public static String buildCommentWithPresetNote(int caseId, String comment) {
		return appendStrings(EEMConstants.COMMENT_PRESET, "_", String.valueOf(caseId), ":", comment);
	}

	public static List<LabelValuePair> addSelectToLabelValuePair(List<LabelValuePair> pairs) {
		LabelValuePair select = new LabelValuePair(EEMConstants.BLANK, EEMConstants.SELECT);
		if (CollectionUtils.isEmpty(pairs)) {
			pairs = new ArrayList<>();
			pairs.add(select);
		} else {
			pairs.add(0, select);
		}
		return pairs;
	}

	public static List<LabelValueKeyPair> addSelectToLabelValueKeyPair(List<LabelValueKeyPair> pairs) {
		LabelValueKeyPair select = new LabelValueKeyPair(EEMConstants.BLANK, EEMConstants.SELECT, EEMConstants.BLANK);
		if (CollectionUtils.isEmpty(pairs)) {
			pairs = new ArrayList<>();
			pairs.add(select);
		} else {
			pairs.add(0, select);
		}
		return pairs;
	}

	public static String appendStrings(String... value) {
		return appendStringsBuilder(value).toString();
	}

	public static StringBuilder appendStringsBuilder(String... value) {
		StringBuilder sb = new StringBuilder();
		Arrays.asList(value).forEach(sb :: append);
		return sb;
	}

	public static boolean isEmpty(Collection<?> collection) {
		return CollectionUtils.isEmpty(collection);
	}

	public static boolean isEmpty(Map<?, ?> map) {
		return CollectionUtils.isEmpty(map);
	}

	public static boolean isNotEmpty(Collection<?> collection) {
		return !CollectionUtils.isEmpty(collection);
	}

	public static boolean isNotEmpty(Map<?, ?> map) {
		return !CollectionUtils.isEmpty(map);
	}

	public static String deFormatSsn(String number) {
		if (StringUtils.isNotBlank(number) && StringUtils.contains(number, "-")) {
			if (!isValidSSN(number)) {
				throw new ApplicationException("SSN is NOT valid!");
			}
			return number.replaceAll("[\\s\\-()]", "");
		}
		return number;
	}

	public static String formatSsn(String ssn) {
		if (StringUtils.isNotBlank(ssn) && !StringUtils.contains(ssn, "-")) {
			if (ssn.length() != 9) {
				throw new ApplicationException("SSN must be of length 9! ");
			}
			return appendStrings(ssn.substring(0, 3), "-", ssn.substring(3, 5), "-", ssn.substring(5));
		}
		return ssn;
	}

	/**
	 * Function to validate SSN (Social Security Number). The valid SSN (Social
	 * Security Number) must satisfy the following conditions: 1. It should have 9
	 * digits. 2. It should be divided into 3 parts by hyphen (-). 3. The first part
	 * (area number) should have 3 digits and should not be 000, 666, or between 900
	 * and 999. 4. The second part (group number) should have 2 digits and it should
	 * be from 01 to 99. 5. The third part (serial number) should have 4 digits and
	 * it should be from 0001 to 9999.
	 * 
	 * @param ssn
	 * @return true if valid otherwise false
	 */
	public static boolean isValidSSN(String ssn) {
		// regex to check SSN (Social Security Number).
		String regex = "^(?!666|000|9\\d{2})\\d{3}-(?!00)\\d{2}-(?!0{4})\\d{4}$";

		// Compile the regex
		Pattern pattern = Pattern.compile(regex);

		// If the string is empty, return false
		if (StringUtils.isBlank(ssn)) {
			return false;
		}

		// Pattern class contains matcher() method
		// to find matching between given string
		// and regular expression.
		Matcher matcher = pattern.matcher(ssn);

		// Return if the string matched the regex
		return matcher.matches();
	}

}
