package com.medicare.mss.dao;

import java.util.List;

import com.medicare.mss.domainobject.EEMMbrLisInfoDO;

public interface EEMMbrLisDAO extends EEMMbrBaseDAO {

	List<EEMMbrLisInfoDO> getMbrLisInfos(String customerId, String memberId, String showAll);

}
