package com.medicare.mss.daoImpl;

import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMBillingDraftDAO;
import com.medicare.mss.domainobject.BillingDraftDetailDO;
import com.medicare.mss.domainobject.BillingDraftHeaderDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.PaginationQueryHelper;
import com.medicare.mss.vo.BillingDraftFormVO;
import com.medicare.mss.vo.BillingDraftHeaderVO;
import com.medicare.mss.vo.DataBaseField;
import com.medicare.mss.vo.PageableVO;

@Repository
public class EEMBillingDraftDAOImpl implements EEMBillingDraftDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public PageableVO getBillingDraftSearchResults(BillingDraftFormVO billingDraftFormVO, boolean isPagination) {
		List<BillingDraftHeaderDO> billingDraftDOList = new ArrayList<>();
		PageableVO response = new PageableVO();
		
		String customerId = trimToEmpty(billingDraftFormVO.getCustomerId());
		String searchInvoiceNbr = trimToEmpty(billingDraftFormVO.getSearchInvoiceNbr());
		String searchInvoiceId = trimToEmpty(billingDraftFormVO.getSearchInvoiceId());
		String searchHicNbr = trimToEmpty(billingDraftFormVO.getSearchHicNbr());
		String searchLastName = trimToEmpty(billingDraftFormVO.getSearchLastName());
		String searchInvoiceStatus = trimToEmpty(billingDraftFormVO.getSearchDraftStatus());
		String searchSupplementId = trimToEmpty(billingDraftFormVO.getSearchSupplId());

		String medIdString = "";
		if (!trimToEmpty(billingDraftFormVO.getIsHicOrMbi()).equals("")) {
			if (billingDraftFormVO.getIsHicOrMbi().equalsIgnoreCase("hic"))
				medIdString = "MED";
			else
				medIdString = "MBI";
		}

		List<String> params = new ArrayList<>();

		StringBuilder sQuery = CommonUtils.buildQueryBuilder(
				"SELECT BDD.CUSTOMER_ID,BDD.MEMBER_ID,LAST_FIRST_NAME,INVOICE_NBR,",
				" INVOICE_DUE_DATE,SETTLEMENT_DATE,RESPONSE_CODE,DRAFT_PROCESSED_IND,DRAFT_AMT,",
				" BDD.CREATE_TIME,BDD.CREATE_USERID,BDD.LAST_UPDT_TIME,BDD.LAST_UPDT_USERID",
				" FROM BBB_DRAFT_DETAIL BDD JOIN EM_MBR_DEMOGRAPHIC D",
				" ON D.CUSTOMER_ID = BDD.CUSTOMER_ID AND D.MEMBER_ID = BDD.MEMBER_ID",
				" AND D.CURRENT_IND = 'Y' AND D.OVERRIDE_IND = 'N'", " WHERE BDD.CUSTOMER_ID = ?");

		params.add(customerId);

		if (!searchInvoiceNbr.isEmpty()  && !isPagination) {
			sQuery.append(" AND INVOICE_NBR = ?");
			params.add(searchInvoiceNbr);
		}
		if (!searchInvoiceId.isEmpty()) {
			sQuery.append(" AND BDD.MEMBER_ID = ?");
			params.add(searchInvoiceId);
		}
		if (!searchInvoiceStatus.isEmpty()) {
			sQuery.append(" AND DRAFT_PROCESSED_IND = ?");
			params.add(searchInvoiceStatus);
		}
		if (!searchLastName.equals("")) {
			sQuery.append(" AND BDD.LAST_FIRST_NAME LIKE ? ");
			params.add("%" + searchLastName + "%");
		}

		if (!searchHicNbr.isEmpty()) {
			sQuery.append(" AND BDD.MEMBER_ID IN (SELECT DSI.MEMBER_ID FROM EM_MBR_DSINFO DSI")
					.append(" WHERE DSI.CUSTOMER_ID = BDD.CUSTOMER_ID").append(" AND DSI.OVERRIDE_IND = 'N'")
					.append("AND DSI.DS_CD = '" + medIdString.trim() + "'").append(" AND DSI.DS_VALUE = ?)");

			params.add(searchHicNbr);
		}

		if (!searchSupplementId.equals("")) {
			sQuery.append(" AND D.MEMBER_ID IN (SELECT E.MEMBER_ID FROM EM_MBR_ENROLLMENT E")
					.append(" WHERE E.CUSTOMER_ID = D.CUSTOMER_ID").append(" AND E.OVERRIDE_IND = 'N'")
					.append(" AND E.SUPPLEMENTAL_ID = ?)");
			params.add(searchSupplementId);
		}

		try {
			if (isPagination) {
				DataBaseField[] conds = new DataBaseField[1];
				for (int i = 0; i < conds.length; i++) {
					conds[i] = new DataBaseField();
				}

				conds[0].setFieldName("BDD.INVOICE_NBR");
				conds[0].setStringValue(billingDraftFormVO.getSearchInvoiceNbr());
				
				StringBuilder pageCond = PaginationQueryHelper.pagingElements(conds, params);
				sQuery.append(pageCond);
			}
			
			sQuery.append(" ORDER BY BDD.INVOICE_NBR");
			sQuery.append(" FETCH FIRST ").append(EEMConstants.DB_MAX_RECORD_FETCH).append(" ROWS ONLY");
			
			billingDraftDOList = jdbcTemplate.query(sQuery.toString(),
					new DomainPropertyRowMapper<BillingDraftHeaderDO>(BillingDraftHeaderDO.class),
					params.toArray());
			
			if (!CollectionUtils.isEmpty(billingDraftDOList)) {
				if (billingDraftDOList.size() > 100) {
					billingDraftDOList.remove(billingDraftDOList.size() - 1);
					response.setNextPage(true);
				}
			}
			response.setContent(billingDraftDOList);
			return response;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

	@Override
	public List<BillingDraftDetailDO> getBillDraftDetail(BillingDraftHeaderVO billingDraftHeaderVO) {

		String draftStatus = trimToEmpty(billingDraftHeaderVO.getInvoiceStatus());
		String customerId = trimToEmpty(billingDraftHeaderVO.getCustomerId());
		String invoiceNbr = trimToEmpty(billingDraftHeaderVO.getInvoiceNbr());
		try {

			if ("P".equalsIgnoreCase(draftStatus) || "U".equalsIgnoreCase(draftStatus)
					|| "X".equalsIgnoreCase(draftStatus) || "Y".equalsIgnoreCase(draftStatus)) {
				StringBuilder sQuery = CommonUtils.buildQueryBuilder(
						"SELECT D.DRAFT_DAY,A.MEMBER_ID,A.LAST_FIRST_NAME,A.SENT_TIME,A.DRAFT_AMT,A.INVOICE_NBR,",
						"A.TRACE_NUM,B.ACCOUNTTYPE_DESC,C.DRAFTPROCESSED_DESC,A.INVOICE_DUE_DATE,",
						"A.SETTLEMENT_DATE,A.RESPONSE_TIME,A.RESPONSE_CODE, E.RESPONSE_DESC ,",
						"A.ABA_ROUTING_NBR,A.BANK_ACCT_NBR, D.BANK_NAME, A.CREATE_TIME,A.CREATE_USERID,",
						"A.LAST_UPDT_TIME,A.LAST_UPDT_USERID FROM BBB_DRAFT_DETAIL A, BBB_ACCOUNTTYPE B,",
						"BBB_DRAFTPROCESSED C, EM_MBR_BILLING D , BBB_ACH_RESP_CD E ",
						"WHERE A.CUSTOMER_ID = D.CUSTOMER_ID AND A.ACCOUNT_TYPE = B.ACCOUNT_TYPE ",
						"AND A.DRAFT_PROCESSED_IND = C.DRAFT_PROCESSED_IND AND A.MEMBER_ID = D.MEMBER_ID ",
						"AND A.RESPONSE_CODE = E.RESPONSE_CODE AND D.OVERRIDE_IND = 'N' ",
						"AND A.CUSTOMER_ID = ? AND A.INVOICE_NBR = ? ORDER BY A.INVOICE_NBR FETCH FIRST ",
						String.valueOf(EEMConstants.DB_MAX_RECORD_FETCH), "ROWS ONLY");

				Object[] parms = new Object[] { customerId, invoiceNbr };
				return jdbcTemplate.query(sQuery.toString(),
						new DomainPropertyRowMapper<BillingDraftDetailDO>(BillingDraftDetailDO.class), parms);

			} else {
				StringBuilder sQuery = CommonUtils.buildQueryBuilder(
						"SELECT D.DRAFT_DAY,A.MEMBER_ID,D.NAME_ON_ACCT AS LAST_FIRST_NAME,A.SENT_TIME,D.DRAFT_OVERRIDE_AMT AS DRAFT_AMT,",
						"A.INVOICE_NBR,A.TRACE_NUM,B.ACCOUNTTYPE_DESC,C.DRAFTPROCESSED_DESC,A.INVOICE_DUE_DATE,",
						"A.SETTLEMENT_DATE,A.RESPONSE_TIME,A.RESPONSE_CODE, E.RESPONSE_DESC, D.ABA_ROUTING_NBR,",
						"D.BANK_ACCT_NBR, D.BANK_NAME, D.CREATE_TIME,D.CREATE_USERID,D.LAST_UPDT_TIME,D.LAST_UPDT_USERID",
						"FROM BBB_DRAFT_DETAIL A, BBB_ACCOUNTTYPE B, BBB_DRAFTPROCESSED C,",
						"EM_MBR_BILLING D , BBB_ACH_RESP_CD E WHERE A.CUSTOMER_ID = D.CUSTOMER_ID ",
						"AND A.ACCOUNT_TYPE = B.ACCOUNT_TYPE AND A.DRAFT_PROCESSED_IND = C.DRAFT_PROCESSED_IND",
						"AND A.MEMBER_ID = D.MEMBER_ID AND A.RESPONSE_CODE = E.RESPONSE_CODE ",
						"AND D.OVERRIDE_IND = 'N' AND A.CUSTOMER_ID = ?",
						"AND A.INVOICE_NBR = ? ORDER BY A.INVOICE_NBR FETCH FIRST",
						String.valueOf(EEMConstants.DB_MAX_RECORD_FETCH), "ROWS ONLY");

				Object[] parms = new Object[] { customerId, invoiceNbr };
				return jdbcTemplate.query(sQuery.toString(),
						new DomainPropertyRowMapper<BillingDraftDetailDO>(BillingDraftDetailDO.class), parms);

			}
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}

	}

	@Override
	public double getDraftAmountForInvoice(BillingDraftHeaderVO billingDraftHeaderVO) {
		try {
			StringBuilder sQuery = CommonUtils.buildQueryBuilder(
					"SELECT DRAFT_AMT FROM BBB_DRAFT_DETAIL WHERE CUSTOMER_ID = ? ",
					"AND MEMBER_ID = ? AND INVOICE_NBR = ? AND DRAFT_PROCESSED_IND = ? ");

			Object[] parms = new Object[] { trimToEmpty(billingDraftHeaderVO.getCustomerId()),
					trimToEmpty(billingDraftHeaderVO.getInvoiceId()), trimToEmpty(billingDraftHeaderVO.getInvoiceNbr()),
					trimToEmpty(billingDraftHeaderVO.getInvoiceStatus()) };

			return jdbcTemplate.queryForObject(sQuery.toString(), parms, Double.class);
		} catch (EmptyResultDataAccessException exp) {
			return 0;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
	}

}
