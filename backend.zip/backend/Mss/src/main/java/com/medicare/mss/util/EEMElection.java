package com.medicare.mss.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.medicare.mss.caching.EEMProfileSettings;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.EEMProfileConstants;
import com.medicare.mss.dao.EEMApplDAO;
import com.medicare.mss.dao.EEMMbrEnrollmentDAO;
import com.medicare.mss.domainobject.EEMMbrEnrollmentDO;
import com.medicare.mss.domainobject.EEMProfileItemDO;
import com.medicare.mss.domainobject.MbdDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.vo.EEMApplMasterVO;
import com.medicare.mss.vo.EEMApplOtherCovVO;
import com.medicare.mss.vo.EEMApplPlanVO;
import com.medicare.mss.vo.EEMApplicationVO;
import com.medicare.mss.vo.EEMElectionVO;

@Component
public class EEMElection {

	private final Logger LOGGER = LogManager.getLogger(this.getClass());

	@Autowired
	private EEMProfileSettings eemProfileSettings;

	@Autowired
	EEMApplDAO eemApplDAO;

	public String validateElectionType(EEMElectionVO objVO) throws ApplicationException, ParseException {
		String derived = "";

		String electionType = StringUtil.nonNullTrim(objVO.getElectionType());
		if (electionType.equals(EEMConstants.ELECTION_TYPE_SEP_5SR)
				|| electionType.equals(EEMConstants.ELECTION_TYPE_SEP_CWK)
				|| electionType.equals(EEMConstants.ELECTION_TYPE_SEP_DUL)
				|| electionType.equals(EEMConstants.ELECTION_TYPE_SEP_EGH)
				|| electionType.equals(EEMConstants.ELECTION_TYPE_SEP_ELP)
				|| electionType.equals(EEMConstants.ELECTION_TYPE_SEP_RES)
				|| electionType.equals(EEMConstants.ELECTION_TYPE_SEP_ADMIN)
				|| electionType.equals(EEMConstants.ELECTION_TYPE_MA_AUTO)) {
			return derived;
		}
		// Utility change to set the Election Type flags.
		if (!(StringUtil.nonNullTrim(objVO.getPartAEntlDt()).equals("")
				&& StringUtil.nonNullTrim(objVO.getPartBEntlDt()).equals("")
				&& StringUtil.nonNullTrim(objVO.getPartDElgDt()).equals(""))) {
			calculateElecTypeFlags(objVO);
		} else {
			objVO.setErrorCode("AP087");
		}
		if (objVO.isMemberPresentInM360())
			objVO.setEarliestEnrlStartDt(eemApplDAO.getEarliestEnrlStDt(objVO.getCustomerId(), objVO.getMemberId()));

		if (electionType.equals("")) {

			if (!(StringUtil.nonNullTrim(objVO.getPartAEntlDt()).equals("")
					&& StringUtil.nonNullTrim(objVO.getPartBEntlDt()).equals("")
					&& StringUtil.nonNullTrim(objVO.getPartDElgDt()).equals(""))) {

				objVO.setElectionType(deriveElectionType(objVO));
				if (!StringUtil.nonNullTrim(objVO.getElectionType()).equals("")) {
					objVO.setElcDerivedInd("Y");
				} else {
					objVO.setErrorCode("AP087");
					objVO.setElcDerivedInd("N");
				}
			} else {
				objVO.setErrorCode("AP087");
			}

		} else {

			if (!(StringUtil.nonNullTrim(objVO.getPartAEntlDt()).equals("")
					&& StringUtil.nonNullTrim(objVO.getPartBEntlDt()).equals("")
					&& StringUtil.nonNullTrim(objVO.getPartDElgDt()).equals(""))) {

				checkElectionTypes(objVO);

			} else {
				objVO.setErrorCode("AP087");
			}
		}

		if (!electionType.equals("") && StringUtil.nonNullTrim(objVO.getErrorCode()).equals("")) {
			String derivedType = deriveElectionType(objVO);
			objVO.setErrorCode("");
			if (!electionType.equals(derivedType)) {
				derived = derivedType;
			}
		}

		return derived;
	}

	/**
	 * Method to set the IEP/IEP2/ICEP election type flag.
	 * 
	 * @param conn
	 * @param eemDb
	 * @param objVO
	 * @throws ParseException
	 * @throws ApplicationException
	 * @throws Exception
	 */
	private void calculateElecTypeFlags(EEMElectionVO objVO) throws ParseException, ApplicationException {
		DateFormat df = new SimpleDateFormat("yyyyMMdd");

		String planDesgn = StringUtil.nonNullTrim(objVO.getPlanDesgn());
		String partADt = StringUtil.nonNullTrim(objVO.getPartAEntlDt());
		String partBDt = StringUtil.nonNullTrim(objVO.getPartBEntlDt());
		String partDDt = StringUtil.nonNullTrim(objVO.getPartDElgDt());
		String dob = StringUtil.nonNullTrim(objVO.getBirthDt());
		String applDate = StringUtil.nonNullTrim(objVO.getApplicationDt());
		String reqDtCov = StringUtil.nonNullTrim(objVO.getReqDtCov());

		objVO.setICEP_Flag(false);
		objVO.setIEP_Flag(false);
		objVO.setIEP2_Flag(false);
		// Set Start Date for Part A and B
		String startABDt = "";
		if (df.parse(partADt).after(df.parse(partBDt))) {
			startABDt = partADt;
		} else {
			startABDt = partBDt;
		}

		// get First day of month by sending yyyyMM string
		startABDt = DateUtil.formatFDOM(startABDt.substring(0, 6));
		startABDt = DateMath.addMonth(startABDt, -3);
		// Set End Date for Part A and B
		String endABDt = "";
		endABDt = DateMath.addMonth(startABDt, 7);
		endABDt = DateMath.minusOneDay(endABDt);

		// Set Start Date for Part D
		String startDDt = DateMath.addMonth(partDDt, -3);
		// get First day of month by sending yyyyMM string
		startDDt = DateUtil.formatFDOM(startDDt.substring(0, 6));
		// Set End Date for Part D
		String endDDt = "";
		endDDt = DateMath.addMonth(startDDt, 7);
		endDDt = DateMath.minusOneDay(endDDt);

		// Set Start Date for Birth date
		String startBDDt = DateMath.addYear(dob, 65);
		// get First day of month by sending yyyyMM string
		startBDDt = DateUtil.formatFDOM(startBDDt.substring(0, 6));
		startBDDt = DateMath.addMonth(startBDDt, -3);
		// Set End Date for Birth date
		String endBDDt = "";
		endBDDt = DateMath.addMonth(startBDDt, 7);
		endBDDt = DateMath.minusOneDay(endBDDt);

		// Validate
		boolean validAB = false;
		boolean validD = false;
		boolean validBD = false;
		if (DateMath.isBetween(applDate, startABDt, endABDt)) {
			validAB = true;
		}
		if (DateMath.isBetween(applDate, startDDt, endDDt)) {
			validD = true;
		}
		if (DateMath.isBetween(applDate, startBDDt, endBDDt)) {
			validBD = true;
		}

		int year = Calendar.getInstance().get(Calendar.YEAR);
		String currYear = Integer.toString(year);
		EEMProfileItemDO itemAEP = eemProfileSettings.getProfileObject(objVO.getCustomerId(), EEMProfileConstants.AEP);
		String enrollStDt = currYear + itemAEP.getEffStartDate().substring(4);
		String enrollEndDt = currYear + itemAEP.getEffEndDate().substring(4);
		String jan1AEP = Integer.toString(year + 1) + "0101";

		// Derive Election type
		if (planDesgn.equals(EEMConstants.PLAN_DESGN_MA) || planDesgn.equals(EEMConstants.PLAN_DESGN_CO)) {
			// Check for Application date
			if (DateMath.isBetween(applDate, startABDt, endABDt)) {
				objVO.setICEP_Flag(true);
			} else if (DateMath.isBetween(applDate, enrollStDt, enrollEndDt) && reqDtCov.equals(jan1AEP)) {
				// set AEP flag True if required.;
			}
		} else if (planDesgn.equals(EEMConstants.PLAN_DESGN_MAPD) || planDesgn.equals(EEMConstants.PLAN_DESGN_COPD)) {

			// Check for the conditions to derive election type
			if (validAB && !validD && !validBD) {
				if (DateMath.isLessThan(partADt, partBDt)) {
					if (DateMath.isBetween(applDate, DateMath.addMonth(partBDt, -3), partBDt)
							&& reqDtCov.equals(partBDt)) {
						objVO.setICEP_Flag(true);
					}
				} else {
					objVO.setICEP_Flag(true);
				}
			}

			else if (!validAB && validD && !validBD) {
				objVO.setIEP_Flag(true);
			} else if (!validAB && !validD && validBD) {
				objVO.setIEP2_Flag(true);
			} else if (validAB && validD && validBD) {
				objVO.setIEP_Flag(true);
			} else if (validAB && validD && !validBD) {
				objVO.setIEP_Flag(true);
			} else if (validAB && !validD && validBD) {
				objVO.setIEP2_Flag(true);
			} else if (validD && validBD) {
				objVO.setIEP_Flag(true);
			} else if (DateMath.isBetween(applDate, enrollStDt, enrollEndDt) && reqDtCov.equals(jan1AEP)) {
				// set AEP flag True if required.;
			}
		}
	}

	public void checkElectionTypes(EEMElectionVO objVO) throws ApplicationException, ParseException {

		String electionType = StringUtil.nonNullTrim(objVO.getElectionType());

		String planDesgn = StringUtil.nonNullTrim(objVO.getPlanDesgn());
		String partADt = StringUtil.nonNullTrim(objVO.getPartAEntlDt());
		String partBDt = StringUtil.nonNullTrim(objVO.getPartBEntlDt());
		String partDDt = StringUtil.nonNullTrim(objVO.getPartDElgDt());
		String dob = StringUtil.nonNullTrim(objVO.getBirthDt());
		String applDate = StringUtil.nonNullTrim(objVO.getApplicationDt());
		String reqDtCov = StringUtil.nonNullTrim(objVO.getReqDtCov());
		String longTermFacId = StringUtil.nonNullTrim(objVO.getLongTermFacId());

		// Set Start Date for Part A and B
		String startABDt = "";
		if (DateMath.isGreaterThan(partADt, partBDt)) {
			startABDt = partADt;
		} else {
			startABDt = partBDt;
		}
		String entitleDt = startABDt;

		startABDt = DateUtil.formatFDOM(startABDt.substring(0, 6));
		startABDt = DateMath.addMonth(startABDt, -3);
		// Set End Date for Part A and B
		String endABDt = "";
		endABDt = DateMath.addMonth(startABDt, 7);
		endABDt = DateMath.minusOneDay(endABDt);

		// Set Start Date for Part D
		String startDDt = DateMath.addMonth(partDDt, -3);
		// get First day of month by sending yyyyMM string
		startDDt = DateUtil.formatFDOM(startDDt.substring(0, 6));
		// Set End Date for Part D
		String endDDt = "";
		endDDt = DateMath.addMonth(startDDt, 7);
		endDDt = DateMath.minusOneDay(endDDt);

		// Set Start Date for Birth date
		String startBDDt = DateMath.addYear(dob, 65);
		// get First day of month by sending yyyyMM string
		startBDDt = DateUtil.formatFDOM(startBDDt.substring(0, 6));
		startBDDt = DateMath.addMonth(startBDDt, -3);
		// Set End Date for Birth date
		String endBDDt = "";
		endBDDt = DateMath.addMonth(startBDDt, 7);
		endBDDt = DateMath.minusOneDay(endBDDt);

		// Validate
		boolean validAB = false;
		boolean validD = false;
		boolean validBD = false;
		if (DateMath.isBetween(applDate, startABDt, endABDt)) {
			validAB = true;
		}
		if (DateMath.isBetween(applDate, startDDt, endDDt)) {
			validD = true;
		}
		if (DateMath.isBetween(applDate, startBDDt, endBDDt)) {
			validBD = true;
		}

		int year = Integer.parseInt(applDate.substring(0, 4));

		String currYear = Integer.toString(year);
		EEMProfileItemDO itemAEP = eemProfileSettings.getProfileObject(objVO.getCustomerId(), EEMProfileConstants.AEP);
		EEMProfileItemDO itemDEP = eemProfileSettings.getProfileObject(objVO.getCustomerId(), EEMProfileConstants.DEP);
		String enrollStDt = currYear + itemAEP.getEffStartDate().substring(4);
		String enrollEndDt = currYear + itemAEP.getEffEndDate().substring(4);
		String disEnrollStDt = currYear + itemDEP.getEffStartDate().substring(4);
		String disEnrollEndDt = currYear + itemDEP.getEffEndDate().substring(4);
		String jan1AEP = Integer.toString(year + 1) + "0101";

		if (electionType.equals(EEMConstants.ELECTION_TYPE_AEP)) {
			if (!reqDtCov.equals(jan1AEP)) {
				objVO.setErrorCode("AP192");
			} else if (!DateMath.isBetween(applDate, enrollStDt, enrollEndDt)) {
				objVO.setErrorCode("AP052");
			}
		} else if (electionType.equals(EEMConstants.ELECTION_TYPE_MADP)) {
			if (!planDesgn.equals(EEMConstants.PLAN_DESGN_PDP)) {
				objVO.setErrorCode("AP047");
			} else {
				if (!DateMath.isBetween(applDate, disEnrollStDt, disEnrollEndDt)) {
					objVO.setErrorCode("AP052");
				}
			}
		} else if (electionType.equals(EEMConstants.ELECTION_TYPE_OEPI)) {
			if (longTermFacId.equals("")) {
				objVO.setErrorCode("AP053");
			}
		} else if (electionType.equals(EEMConstants.ELECTION_TYPE_ICEP)) {
			if (DateMath.isLessThan(partADt, partBDt)
					&& (!DateMath.isBetween(applDate, DateMath.addMonth(partBDt, -3), partBDt)
							|| !reqDtCov.equals(partBDt))) {
				objVO.setErrorCode("AP047");
			}
			// retro-fitted from base for IFOX-00397076 start
			if (DateMath.isGreaterThan(partADt, partBDt) && DateMath.isBetween(entitleDt, startDDt, endDDt)) {
				if (!DateMath.isBetween(applDate, DateMath.addMonth(partBDt, -3), DateMath.addMonth(partBDt, 3)))
					objVO.setErrorCode("AP047");
			}
			// retro-fitted from base for IFOX-00397076 end
			if ((planDesgn.equals(EEMConstants.PLAN_DESGN_MA) || planDesgn.equals(EEMConstants.PLAN_DESGN_CO))
					&& !DateMath.isBetween(applDate, startABDt, endABDt)) {
				objVO.setErrorCode("AP052");
			}

			if ((planDesgn.equals(EEMConstants.PLAN_DESGN_MAPD) || planDesgn.equals(EEMConstants.PLAN_DESGN_COPD))
					&& (!validAB && !validD && !validBD)) {
				objVO.setErrorCode("AP047");
			}

		} else if (electionType.equals(EEMConstants.ELECTION_TYPE_IEP)) {
			if (!validD) {
				objVO.setErrorCode("AP047");
			}
			if (!isEffDateValidForIEP(applDate, entitleDt, reqDtCov)) {
				objVO.setErrorCode("AP047");
			}
		} else if (electionType.equals(EEMConstants.ELECTION_TYPE_IEP2)) {
			if (!validBD || validD) {
				objVO.setErrorCode("AP047");
			}
		}
		/** CMS 2019 January Release- Requirement-2b: MA OEP - M. START **/
		else if (electionType.equals(EEMConstants.ELECTION_TYPE_MA_OEP)) {
			objVO.setErrorCode(validateMAOEPElectionType(objVO, electionType, true));
		}
		/** CMS 2019 January Release- Requirement-2b: MA OEP - M. END **/
		/** CMS 2019 January Release- Requirement-3 : DUAL/LIS SEP � L and U. START **/
		else if (electionType.equals(EEMConstants.ELECTION_TYPE_SEP_LIS)) {
			objVO.setErrorCode(validateLISSEPElectionType(objVO, electionType, true));
		}
		/** CMS 2019 January Release- Requirement-3 : DUAL/LIS SEP � L and U. END **/

	}

	public String deriveElectionType(EEMElectionVO objVO) throws ApplicationException, ParseException {
		String electionType = "";

		DateFormat df = new SimpleDateFormat("yyyyMMdd");

		String planDesgn = StringUtil.nonNullTrim(objVO.getPlanDesgn());
		String partADt = StringUtil.nonNullTrim(objVO.getPartAEntlDt());
		String partBDt = StringUtil.nonNullTrim(objVO.getPartBEntlDt());
		String partDDt = StringUtil.nonNullTrim(objVO.getPartDElgDt());
		String dob = StringUtil.nonNullTrim(objVO.getBirthDt());
		String applDate = StringUtil.nonNullTrim(objVO.getApplicationDt());
		String reqDtCov = StringUtil.nonNullTrim(objVO.getReqDtCov());

		// Set Start Date for Part A and B
		String startABDt = "";
		if (df.parse(partADt).after(df.parse(partBDt))) {
			startABDt = partADt;
		} else {
			startABDt = partBDt;
		}
		String entitleDt = startABDt;

		// get First day of month by sending yyyyMM string
		startABDt = DateUtil.formatFDOM(startABDt.substring(0, 6));
		startABDt = DateMath.addMonth(startABDt, -3);
		// Set End Date for Part A and B
		String endABDt = "";
		endABDt = DateMath.addMonth(startABDt, 7);
		endABDt = DateMath.minusOneDay(endABDt);

		// Set Start Date for Part D
		String startDDt = DateMath.addMonth(partDDt, -3);
		// get First day of month by sending yyyyMM string
		startDDt = DateUtil.formatFDOM(startDDt.substring(0, 6));
		// Set End Date for Part D
		String endDDt = "";
		endDDt = DateMath.addMonth(startDDt, 7);
		endDDt = DateMath.minusOneDay(endDDt);

		// Set Start Date for Birth date
		String startBDDt = DateMath.addYear(dob, 65);
		// get First day of month by sending yyyyMM string
		startBDDt = DateUtil.formatFDOM(startBDDt.substring(0, 6));
		startBDDt = DateMath.addMonth(startBDDt, -3);
		// Set End Date for Birth date
		String endBDDt = "";
		endBDDt = DateMath.addMonth(startBDDt, 7);
		endBDDt = DateMath.minusOneDay(endBDDt);

		// Validate
		boolean validAB = false;
		boolean validD = false;
		boolean validBD = false;
		if (DateMath.isBetween(applDate, startABDt, endABDt)) {
			validAB = true;
		}
		if (DateMath.isBetween(applDate, startDDt, endDDt)) {
			validD = true;
		}
		if (DateMath.isBetween(applDate, startBDDt, endBDDt)) {
			validBD = true;
		}

		/** IFOX-00399101 Changed the current year logic to application year. START **/
		// int year = Calendar.getInstance().get(Calendar.YEAR);
		int year = Integer.parseInt(applDate.substring(0, 4));
		/** IFOX-00399101 Changed the current year logic to application year. END **/
		String currYear = Integer.toString(year);
		EEMProfileItemDO itemAEP = eemProfileSettings.getProfileObject(objVO.getCustomerId(), EEMProfileConstants.AEP);
		String enrollStDt = currYear + itemAEP.getEffStartDate().substring(4);
		String enrollEndDt = currYear + itemAEP.getEffEndDate().substring(4);
		String jan1AEP = Integer.toString(year + 1) + "0101";

		// Derive Election type
		if (planDesgn.equals(EEMConstants.PLAN_DESGN_MA) || planDesgn.equals(EEMConstants.PLAN_DESGN_CO)) {
			// Check for Application date
			if (DateMath.isBetween(applDate, enrollStDt, enrollEndDt) && reqDtCov.equals(jan1AEP)) {
				electionType = EEMConstants.ELECTION_TYPE_AEP;
			} else if (DateMath.isBetween(applDate, startABDt, endABDt)) {
				electionType = EEMConstants.ELECTION_TYPE_ICEP;
			} else {
				objVO.setErrorCode("AP087");
			}

		} else if (planDesgn.equals(EEMConstants.PLAN_DESGN_MAPD) || planDesgn.equals(EEMConstants.PLAN_DESGN_COPD)) {

			// Check for the conditions to derive election type
			if (validAB && !validD && !validBD) {
				if (DateMath.isLessThan(partADt, partBDt)) {
					if (DateMath.isBetween(applDate, DateMath.addMonth(partBDt, -3), partBDt)
							&& reqDtCov.equals(partBDt))
						return EEMConstants.ELECTION_TYPE_ICEP;
				} else {
					return EEMConstants.ELECTION_TYPE_ICEP;// check this
				}
			}

			if (DateMath.isBetween(applDate, enrollStDt, enrollEndDt) && reqDtCov.equals(jan1AEP)) {
				electionType = EEMConstants.ELECTION_TYPE_AEP;
			} else if (!validAB && validD && !validBD) {
				electionType = EEMConstants.ELECTION_TYPE_IEP;
			} else if (!validAB && !validD && validBD) {
				electionType = EEMConstants.ELECTION_TYPE_IEP2;
			} else if (validAB && validD && validBD) {
				electionType = EEMConstants.ELECTION_TYPE_IEP;
			} else if (validAB && validD && !validBD) {
				electionType = EEMConstants.ELECTION_TYPE_IEP;
			} else if (validAB && !validD && validBD) {
				electionType = EEMConstants.ELECTION_TYPE_IEP2;
			} else if (validD && validBD) {
				electionType = EEMConstants.ELECTION_TYPE_IEP;
			} else {
				objVO.setErrorCode("AP087");
			}

		} else if (planDesgn.equals(EEMConstants.PLAN_DESGN_PDP)) {
			if (DateMath.isBetween(applDate, enrollStDt, enrollEndDt) && reqDtCov.equals(jan1AEP)) {
				electionType = EEMConstants.ELECTION_TYPE_AEP;
			} else if (validD && validBD) {
				electionType = EEMConstants.ELECTION_TYPE_IEP;
			} else if (validD) {
				electionType = EEMConstants.ELECTION_TYPE_IEP;
			} else if (validBD) {
				electionType = EEMConstants.ELECTION_TYPE_IEP2;
			} else {
				objVO.setErrorCode("AP087");
			}
		}

		if (electionType.equals("") || electionType.equals(EEMConstants.ELECTION_TYPE_IEP)) {

			if (objVO.getApplType() == null || (objVO.getApplType().equals(EEMConstants.OPTION_APPLNEWMBR_MA)
					|| objVO.getApplType().equals(EEMConstants.OPTION_APPLNEWMBR_PD))) {
				if ((DateMath.isGreaterThan(partBDt, partDDt) && isEffDateValidForIEP(applDate, partBDt, reqDtCov))) {
					if (DateMath.isBetween(applDate, DateMath.addMonth(partBDt, -3), DateMath.addMonth(partBDt, 3))) {
						electionType = EEMConstants.ELECTION_TYPE_ICEP;
					}
				}
			}
		}

		if (electionType.equals(EEMConstants.ELECTION_TYPE_IEP) || electionType.equals(EEMConstants.ELECTION_TYPE_ICEP)
				|| electionType.equals(EEMConstants.ELECTION_TYPE_IEP2)) {
			if (!isEffDateValidForIEP(applDate, entitleDt, reqDtCov)) {
				electionType = "";
				objVO.setErrorCode("AP087");
			}
		}

		electionType = validateMAOEPElectionType(objVO, electionType, false);

		if (electionType.equals(EEMConstants.ELECTION_TYPE_SEP_LIS)) {
			electionType = validateLISSEPElectionType(objVO, electionType, false);
		}

		return electionType;
	}

	/**
	 * Derive and validate Election Type MA-OEP 'M'
	 * 
	 * @param conn
	 * @param elecVO
	 * @return
	 * @throws ParseException
	 * @throws ApplicationException
	 * @throws Exception
	 */
	private String validateMAOEPElectionType(EEMElectionVO elecVO, String electionType, boolean validation)
			throws ParseException, ApplicationException {
		char iepFlag = 'N';
		char iep2Flag = 'N';
		char icepFlag = 'N';
		char maOEP1Flag = 'N';
		char maOEP2Flag = 'N';
		String maOEPStartABDt = "";
		String maOEPEndABDt = "";
		String planDesgn = StringUtil.nonNullTrim(elecVO.getPlanDesgn());
		String partADt = StringUtil.nonNullTrim(elecVO.getPartAEntlDt());
		String partBDt = StringUtil.nonNullTrim(elecVO.getPartBEntlDt());
		String partDDt = StringUtil.nonNullTrim(elecVO.getPartDElgDt());
		String applDate = StringUtil.nonNullTrim(elecVO.getApplicationDt());
		String reqDtCov = StringUtil.nonNullTrim(elecVO.getReqDtCov());
		String birthday65 = "";
		String birthday65Plus3Mnths = "";
		boolean isReqDtCovValid = DateMath.isEqual(DateMath.getFirstOfNextMonth(applDate), reqDtCov);
		String earliestEnrlStDt = StringUtil.nonNullTrim(elecVO.getEarliestEnrlStartDt());

		// EEMEnrollDao enrollDao = DaoFactory.getInstance().getEEMEnrollDao();
		if (null != elecVO.getBirthDt() && !elecVO.getBirthDt().trim().equals("")) {
			birthday65 = DateMath.addYear(elecVO.getBirthDt(), 65);
			birthday65 = DateMath.getFirstOfNextMonth(birthday65);
			birthday65Plus3Mnths = DateMath.addMonth(birthday65, 3);
		}
		if (DateMath.isGreaterThan(partADt, partBDt))
			maOEPStartABDt = partADt;
		else
			maOEPStartABDt = partBDt;

		maOEPStartABDt = DateUtil.formatFDOM(maOEPStartABDt.substring(0, 6));
		maOEPEndABDt = DateMath.addMonth(maOEPStartABDt, 3);
		maOEPEndABDt = DateMath.minusOneDay(maOEPEndABDt);

		// If IEP flag is �True�, Check if IEP is already used.
		if (elecVO.isIEP_Flag()) {
			iepFlag = 'Y';
			// If application date is between Part D Date and Part D date + 3 months.
			if (DateMath.isBetween(applDate, partDDt, DateMath.addMonth(partDDt, 3))) {
				// If member already exist in M360.
				if (elecVO.isMemberPresentInM360()) {
					// Check if the member already used election type "E (IEP)".
					if (eemApplDAO.isElectionTypeAlreadyUsed(elecVO.getCustomerId(), elecVO.getMemberId(),
							EEMConstants.ELECTION_TYPE_IEP, "EAPRV", partDDt, reqDtCov))
						iepFlag = 'N';
					// Compare the earliestEnrlStDt with PartD date
					else if (DateMath.isGreaterThan(earliestEnrlStDt, partDDt))
						iepFlag = 'M';
					// Check if the member has any break in coverage.
					else if (eemApplDAO.validateBrkInCov(elecVO.getCustomerId(), elecVO.getMemberId(), partDDt,
							reqDtCov))
						iepFlag = 'M';
				} // If member is not already exist in M360 (New Member).
				else
					iepFlag = 'M';
			}
		}

		// If IEP2 flag is �True�, Check if IEP2 is already used.
		if (elecVO.isIEP2_Flag()) {
			iep2Flag = 'Y';
			// If application date is between 65th Birth Date and 65th Birth Date + 3 months
			if (DateMath.isBetween(applDate, birthday65, birthday65Plus3Mnths)) {
				// If member already exist in M360.
				if (elecVO.isMemberPresentInM360()) {
					// Check if the member already used election type "F (IEP2)".
					if (eemApplDAO.isElectionTypeAlreadyUsed(elecVO.getCustomerId(), elecVO.getMemberId(),
							EEMConstants.ELECTION_TYPE_IEP2, "EAPRV", birthday65, reqDtCov))
						iep2Flag = 'N';
					// Compare the earliestEnrlStDt with birthday65 date
					else if (DateMath.isGreaterThan(earliestEnrlStDt, birthday65))
						iep2Flag = 'M';
					// Check if the member has any break in coverage.
					else if (eemApplDAO.validateBrkInCov(elecVO.getCustomerId(), elecVO.getMemberId(), birthday65,
							reqDtCov))
						iep2Flag = 'M';
				} // If member is not already exist in M360 (New Member).
				else
					iep2Flag = 'M';
			}
		}

		// If ICEP flag is �True�, Check if ICEP is already used.
		if (elecVO.isICEP_Flag()) {
			icepFlag = 'Y';
			// If application date is between Entitlement Date and Entitlement Date + 3
			// months
			// Here Entitlement Date is Greater of Part A or Part B date.
			if (DateMath.isBetween(applDate, maOEPStartABDt, maOEPEndABDt)) {
				// If member already exist in M360.
				if (elecVO.isMemberPresentInM360()) {
					// Check if the member already used election type "I (ICEP)".
					if (eemApplDAO.isElectionTypeAlreadyUsed(elecVO.getCustomerId(), elecVO.getMemberId(),
							EEMConstants.ELECTION_TYPE_ICEP, "EAPRV", maOEPStartABDt, reqDtCov))
						icepFlag = 'N';
					// Compare the earliestEnrlStDt with Entitlement date
					else if (DateMath.isGreaterThan(earliestEnrlStDt, maOEPStartABDt))
						icepFlag = 'M';
					else if (eemApplDAO.validateBrkInCov(elecVO.getCustomerId(), elecVO.getMemberId(), maOEPStartABDt,
							reqDtCov))
						icepFlag = 'M';
				} // If member is not already exist in M360 (New Member).
				else
					icepFlag = 'M';
			}
		}

		// Set MA-OEP1 election period flag.
		if (DateMath.isBetweenQ1(applDate) && isReqDtCovValid)
			maOEP1Flag = 'Y';

		// Set MA-OEP2 election period flag
		if (DateMath.isBetween(applDate, maOEPStartABDt, maOEPEndABDt) && isReqDtCovValid)
			maOEP2Flag = 'Y';

		// If MA-OEP1 flag is �Yes�, Check if the Member already used MA-OEP election
		if (maOEP1Flag == 'Y') {
			// If member exist in M360
			if (elecVO.isMemberPresentInM360()) {
				// check if the member already used election type �M�.
				if (eemApplDAO.isMAOEPElectionTypeAlreadyUsed(elecVO.getCustomerId(), elecVO.getMemberId(),
						DateMath.getFDOJanFromYear(applDate), reqDtCov))
					maOEP1Flag = 'N';
				// Compare the earliestEnrlStDt with 01/01/applDate
				else if (DateMath.isGreaterThan(earliestEnrlStDt, DateMath.getFDOJanFromYear(applDate)))
					maOEP1Flag = 'M';
				// Check if the member has any break in coverage.
				else if (eemApplDAO.validateBrkInCov(elecVO.getCustomerId(), elecVO.getMemberId(),
						DateMath.getFDOJanFromYear(applDate), reqDtCov))
					maOEP1Flag = 'M';
			} else
				maOEP1Flag = 'M';
		}
		// Greater of Part A, Part B or 1/1/<Application Date Year> Date.
		String maOEPEntitleDate = DateMath.isGreaterThan(maOEPStartABDt, DateMath.getFDOJanFromYear(applDate))
				? maOEPStartABDt
				: DateMath.getFDOJanFromYear(applDate);

		// If MA-OEP2 flag is �Yes�, Check if the Member already used MA-OEP election
		if (maOEP2Flag == 'Y') {
			// If member exist in M360
			if (elecVO.isMemberPresentInM360()) {
				// check if the member already used election type �M�.
				if (eemApplDAO.isMAOEPElectionTypeAlreadyUsed(elecVO.getCustomerId(), elecVO.getMemberId(),
						maOEPEntitleDate, reqDtCov))
					maOEP2Flag = 'N';
				// Compare the earliestEnrlStDt with maOEPEntitleDate
				else if (DateMath.isGreaterThan(earliestEnrlStDt, maOEPEntitleDate))
					maOEP2Flag = 'M';
				// Check if the member has any break in coverage.
				else if (eemApplDAO.validateBrkInCov(elecVO.getCustomerId(), elecVO.getMemberId(), maOEPEntitleDate,
						reqDtCov))
					maOEP2Flag = 'M';
			} else
				maOEP2Flag = 'M';
		}

		// Derive Election Type MA-OEP 'M'.
		if (!validation) {
			if (planDesgn.equals(EEMConstants.PLAN_DESGN_MA)) {
				if (icepFlag == 'M' || maOEP2Flag == 'M')
					electionType = "";// Set AP087 error.
				else if (icepFlag == 'Y')
					electionType = EEMConstants.ELECTION_TYPE_ICEP;
				// CMS Changes 2018-MA OEP Additional Check :00411704 :start
				else if ((maOEP2Flag == 'Y' || maOEP1Flag == 'Y') && elecVO.isPlanPDP() == false
						&& elecVO.isPlanBlank() == false)
					electionType = EEMConstants.ELECTION_TYPE_MA_OEP;
				// CMS Changes 2018-MA OEP Additional Check :00411704 :end
				else if (maOEP2Flag == 'Y' || maOEP1Flag == 'Y')
					electionType = EEMConstants.ELECTION_TYPE_MA_OEP;
				else if (maOEP1Flag == 'M')
					electionType = "";// Set AP087 error.

			} else if (planDesgn.equals(EEMConstants.PLAN_DESGN_MAPD)) {
				if (iepFlag == 'M' || iep2Flag == 'M' || icepFlag == 'M' || maOEP2Flag == 'M')
					electionType = "";// Set AP087 error.
				else if (iepFlag == 'Y')
					electionType = EEMConstants.ELECTION_TYPE_IEP;
				else if (iep2Flag == 'Y')
					electionType = EEMConstants.ELECTION_TYPE_IEP2;
				else if (icepFlag == 'Y')
					electionType = EEMConstants.ELECTION_TYPE_ICEP;
				// CMS Changes 2018-MA OEP Additional Check :00411704 :start
				else if ((maOEP2Flag == 'Y' || maOEP1Flag == 'Y') && elecVO.isPlanPDP() == false
						&& elecVO.isPlanBlank() == false)
					electionType = EEMConstants.ELECTION_TYPE_MA_OEP;
				// CMS Changes 2018-MA OEP Additional Check :00411704 :end
				else if (maOEP2Flag == 'Y' || maOEP1Flag == 'Y')
					electionType = EEMConstants.ELECTION_TYPE_MA_OEP;
				else if (maOEP1Flag == 'M')
					electionType = "";// Set AP087 error.
			} else if (planDesgn.equals(EEMConstants.PLAN_DESGN_PDP)) {
				/*
				 * if(iepFlag == 'M' || iep2Flag == 'M') electionType = "";//Set AP087 error.
				 */

				if (iepFlag == 'M' || iep2Flag == 'M' || maOEP2Flag == 'M')
					electionType = "";// Set AP087 error.
				else if (iepFlag == 'Y' && iep2Flag == 'Y')
					electionType = EEMConstants.ELECTION_TYPE_IEP;
				else if (iepFlag == 'Y')
					electionType = EEMConstants.ELECTION_TYPE_IEP;
				else if (iep2Flag == 'Y')
					electionType = EEMConstants.ELECTION_TYPE_IEP2;
				else if ((maOEP2Flag == 'Y' || maOEP1Flag == 'Y') && elecVO.isPlanPDP() == false
						&& elecVO.isPlanBlank() == false)
					electionType = EEMConstants.ELECTION_TYPE_MA_OEP;
				else if (maOEP2Flag == 'Y' || maOEP1Flag == 'Y')
					electionType = EEMConstants.ELECTION_TYPE_MA_OEP;
				else if (maOEP1Flag == 'M')
					electionType = "";// Set AP087 error.
				// CMS Changes 2018-MA OEP Additional Check for PDP apps :00411704 :end

			}

			if (null != electionType && !electionType.trim().equals(""))
				elecVO.setErrorCode("");
			// CMS Changes 2018-MA OEP Additional Check :00411704 :start
			if ((elecVO.isPlanPDP() == true || elecVO.isPlanBlank() == true) && electionType.equals("M")) {
				electionType = "";
			}
			// CMS Changes 2018-MA OEP Additional Check :00411704 :end

			return electionType;
		} // Validate Election Type MA-OEP 'M'.
		else {
			if (planDesgn.equals(EEMConstants.PLAN_DESGN_MA)) {
				if (maOEP1Flag == 'N' && maOEP2Flag == 'N')
					elecVO.setErrorCode("AP052");
				// CMS Changes 2018-MA OEP Additional Check :00411704 :start
				else if (elecVO.isPlanPDP() == true)
					elecVO.setErrorCode("AP354");
				else if (elecVO.isPlanBlank() == true)
					elecVO.setErrorCode("AP353");
				// CMS Changes 2018-MA OEP Additional Check :00411704 :end
			} else if (planDesgn.equals(EEMConstants.PLAN_DESGN_MAPD)) {
				if (maOEP1Flag == 'N' && maOEP2Flag == 'N')
					elecVO.setErrorCode("AP052");
				// CMS Changes 2018-MA OEP Additional Check :00411704 :start
				else if (elecVO.isPlanPDP() == true)
					elecVO.setErrorCode("AP354");
				else if (elecVO.isPlanBlank() == true)
					elecVO.setErrorCode("AP353");
				// CMS Changes 2018-MA OEP Additional Check :00411704 :end
			} else if (planDesgn.equals(EEMConstants.PLAN_DESGN_PDP))
				// CMS Changes 2019-MA OEP Additional Check for PDP apps :00411704 :start
				// elecVO.setErrorCode("AP052");
				if (maOEP1Flag == 'N' && maOEP2Flag == 'N')
					elecVO.setErrorCode("AP052");
				else if (elecVO.isPlanPDP() == true)
					elecVO.setErrorCode("AP354");
				else if (elecVO.isPlanBlank() == true)
					elecVO.setErrorCode("AP353");
			// CMS Changes 2018-MA OEP Additional Check for PDP apps :00411704 :end

			return elecVO.getErrorCode();
		}
	}

	/**
	 * CMS 2019 January Release- Requirement-2b: MA OEP - M. END.
	 * 
	 * @throws ParseException
	 **/
	public static boolean isEffDateValidForIEP(String applDate, String partABDate, String effDate)
			throws ParseException {

		if (DateMath.isLessThan(applDate, partABDate)) {
			if (!DateMath.isEqual(effDate, partABDate))
				return false;

		} else if (DateMath.isGreaterThanOrEqual(applDate, partABDate)) { // Ticket 347374
			String correctDate = DateMath.getFirstOfNextMonth(applDate);
			if (!DateMath.isEqual(effDate, correctDate))
				return false;
		}

		return true;
	}

	public LabelValuePair isEligible(String effDate, String prtAStart, String prtAEnd, String prtBStart, String prtBEnd,
			String deathDate, String planDesignation) {

		if (!deathDate.equals("")) {
			if (!deathDate.equals("00000000"))
				if (DateMath.isGreaterThanOrEqual(effDate, deathDate)) {
					return new LabelValuePair("Not Eligible - Member Deceased", "002");
				}
		}

		boolean prtAActive = false;
		boolean prtBActive = false;

		if (prtAStart.equals(""))
			prtAStart = "00000000";
		if (prtAEnd.equals(""))
			prtAEnd = "00000000";
		if (!prtAStart.equals("00000000"))
			if (prtAEnd.equals("00000000"))
				prtAEnd = "99999999";

		if (prtBStart.equals(""))
			prtBStart = "00000000";
		if (prtBEnd.equals(""))
			prtBEnd = "00000000";
		if (!prtBStart.equals("00000000"))
			if (prtBEnd.equals("00000000"))
				prtBEnd = "99999999";

		if (DateMath.isBetween(effDate, prtAStart, prtAEnd))
			prtAActive = true;

		if (DateMath.isBetween(effDate, prtBStart, prtBEnd))
			prtBActive = true;

		if (planDesignation.equals("MA") || planDesignation.equals("MAPD")) {
			// Both PartA and PartB should be active
			if (!(prtAActive && prtBActive)) {
				LabelValuePair nvp = new LabelValuePair("Not Eligible - Part A / Part B Eligibility Dates", "001");
				return nvp;
			}
		} else if (planDesignation.equals("PDP")) {
			// Either PartA and PartB are active
			if (!(prtAActive || prtBActive)) {
				return new LabelValuePair("Not Eligible - Part A / Part B Eligibility Dates", "001");
			}
		}

		return new LabelValuePair("", "000");
	}

	public LabelValuePair validApplicationDate(String customerId, String applDate, String electionType)
			throws ApplicationException, ParseException {

		String curDate = DateUtil.getTodaysDate();

		if (DateMath.isGreaterThan(applDate, curDate)) {
			if (!"A".equals(electionType) && !"W".equals(electionType))
				return new LabelValuePair("Application Date Greater Than Today", "001");

			EEMProfileItemDO itemAEP = eemProfileSettings.getProfileObject(customerId, EEMProfileConstants.AEP);

			int aepGrace = eemProfileSettings.getProfileObject(customerId, EEMProfileConstants.AEPGRACE, curDate)
					.getParmNumberValue();
			int aepGraceVal = 0 - (aepGrace - 1);

			String currYear = curDate.substring(0, 4);
			String enrtyWaivedEndDate = currYear + itemAEP.getEffStartDate().substring(4);
			String enrtyWaivedStartDate = DateMath.addDay(enrtyWaivedEndDate, aepGraceVal);

			if (DateMath.isBetween(curDate, enrtyWaivedStartDate, enrtyWaivedEndDate)) {
				if (!applDate.equals(enrtyWaivedEndDate)) {
					return new LabelValuePair("Grace Period Application Date is Not AEP Start Date", "002");
				}
			}
		}

		return new LabelValuePair("", "000");
	}

	public boolean validSignatureDate(String signDate, String applDate, String electionType, String editOverride) {

		// Check for SEP EGHP election
		// CMS requires that we use the first day of the month preceding the effective
		// date of the enrollment as the application date.
		if (!EEMConstants.ELECTION_TYPE_SEP_EGH.equals(electionType)) {

			// Check ICEP and editOverride check
			if (!(EEMConstants.ELECTION_TYPE_ICEP.equals(electionType)
					&& EEMConstants.VALUE_YES.equals(editOverride))) {
				if (DateMath.isGreaterThan(signDate, applDate))
					return false;
			}
		}
		return true;
	}

	private boolean isMemberAlreadyUsedElectionTypeL(EEMMbrEnrollmentDO emMbrEnrollmentVO, String enrollmentStatus)
			throws NumberFormatException, ApplicationException, ParseException {
		String executionBlock = null;

		String strApplicationDate = emMbrEnrollmentVO.getApplicationDate().replaceAll("/", "");
		String YYYYFromApplicationDate = strApplicationDate.substring(4, 8);
		String MMDDFromApplicationDate = strApplicationDate.substring(0, 4);
		String dayBeforeEffectiveSatrtDate = DateMath.minusOneDay(emMbrEnrollmentVO.getEffStartDate());

		// Quarter - 1
		if (DateMath.isApplicationRecievedInQ1(MMDDFromApplicationDate)) {
			if (eemApplDAO.isElectionTypeAlreadyUsed(emMbrEnrollmentVO.getCustomerId(), emMbrEnrollmentVO.getMemberId(),
					"L", "EAPRV", dayBeforeEffectiveSatrtDate, YYYYFromApplicationDate + "0201")) {
				executionBlock = "Q1 (EPARV)";
				return true;
			} else {
				if (eemApplDAO.isElectionTypeAlreadyUsed(emMbrEnrollmentVO.getCustomerId(),
						emMbrEnrollmentVO.getMemberId(), "L", "DAPRV", dayBeforeEffectiveSatrtDate,
						YYYYFromApplicationDate + "0101")) {
					executionBlock = "Q1 (EPARV-DAPRV)";
					return true;
				} else {
					String earliestEnrollmentDate = eemApplDAO.getEarliestEnrlStDt(emMbrEnrollmentVO.getCustomerId(),
							emMbrEnrollmentVO.getMemberId());
					if (!StringUtil.nonNullTrim(earliestEnrollmentDate).equals("")) {
						if (Integer.parseInt(earliestEnrollmentDate) > Integer
								.parseInt(YYYYFromApplicationDate + "0201")) {
							executionBlock = "Q1 (EarliestEnrollmentCheck)";
							return true;
						}
					} else {
						// Check if the member has any break in coverage (DAPRV/CMSAPRV)
						if (eemApplDAO.isElectionTypeAlreadyUsed(emMbrEnrollmentVO.getCustomerId(),
								emMbrEnrollmentVO.getMemberId(), "L", "DAPRV", dayBeforeEffectiveSatrtDate,
								YYYYFromApplicationDate + "0801")) {
							executionBlock = "Q1 (DAPRV)";
							return true;
						}
					}
				}
			}
		} else {
			// Quarter -2
			if (DateMath.isApplicationRecievedInQ2(MMDDFromApplicationDate)) {
				if (eemApplDAO.isElectionTypeAlreadyUsed(emMbrEnrollmentVO.getCustomerId(),
						emMbrEnrollmentVO.getMemberId(), "L", "EAPRV", dayBeforeEffectiveSatrtDate,
						YYYYFromApplicationDate + "0501")) {
					executionBlock = "Q2 (EPARV)";
					return true;
				} else {
					if (eemApplDAO.isElectionTypeAlreadyUsed(emMbrEnrollmentVO.getCustomerId(),
							emMbrEnrollmentVO.getMemberId(), "L", "DAPRV", dayBeforeEffectiveSatrtDate,
							YYYYFromApplicationDate + "0401")) {
						executionBlock = "Q2 (EPARV-DAPRV)";
						return true;
					} else {
						String earliestEnrollmentDate = eemApplDAO.getEarliestEnrlStDt(
								emMbrEnrollmentVO.getCustomerId(), emMbrEnrollmentVO.getMemberId());
						if (!StringUtil.nonNullTrim(earliestEnrollmentDate).equals("")) {
							if (Integer.parseInt(earliestEnrollmentDate) > Integer
									.parseInt(YYYYFromApplicationDate + "0501")) {
								executionBlock = "Q2 (EarliestEnrollmentCheck)";
								return true;
							}
						} else {
							// Check if the member has any break in coverage(DAPRV/CMSAPRV)
							if (eemApplDAO.isElectionTypeAlreadyUsed(emMbrEnrollmentVO.getCustomerId(),
									emMbrEnrollmentVO.getMemberId(), "L", "DAPRV", dayBeforeEffectiveSatrtDate,
									YYYYFromApplicationDate + "0701")) {
								executionBlock = "Q2 (DAPRV)";
								return true;
							}
						}
					}
				}
			} else {
				// Quarter-3
				if (DateMath.isApplicationRecievedInQ3(MMDDFromApplicationDate)) {
					if (eemApplDAO.isElectionTypeAlreadyUsed(emMbrEnrollmentVO.getCustomerId(),
							emMbrEnrollmentVO.getMemberId(), "L", "EAPRV", dayBeforeEffectiveSatrtDate,
							YYYYFromApplicationDate + "0201")) {
						executionBlock = "Q3 (EPARV)";
						return true;
					} else {
						if (eemApplDAO.isElectionTypeAlreadyUsed(emMbrEnrollmentVO.getCustomerId(),
								emMbrEnrollmentVO.getMemberId(), "L", "DAPRV", dayBeforeEffectiveSatrtDate,
								YYYYFromApplicationDate + "0501")) {
							executionBlock = "Q3 (EPARV-DAPRV)";
							return true;
						} else {
							String earliestEnrollmentDate = eemApplDAO.getEarliestEnrlStDt(
									emMbrEnrollmentVO.getCustomerId(), emMbrEnrollmentVO.getMemberId());
							if (!StringUtil.nonNullTrim(earliestEnrollmentDate).equals("")) {
								if (Integer.parseInt(earliestEnrollmentDate) > Integer
										.parseInt(YYYYFromApplicationDate + "0201")) {
									executionBlock = "Q3 (EarliestEnrollmentCheck)";
									return true;
								}
							} else {
								// Check if the member has any break in coverage (DAPRV/CMSAPRV)
								if (eemApplDAO.isElectionTypeAlreadyUsed(emMbrEnrollmentVO.getCustomerId(),
										emMbrEnrollmentVO.getMemberId(), "L", "DAPRV", dayBeforeEffectiveSatrtDate,
										YYYYFromApplicationDate + "0801")) {
									executionBlock = "Q3 (DAPRV)";
									return true;
								}
							}
						}
					}
				}
			}
		}

		return false;
	}

	public boolean validateSEP(String electionType) {
		if (electionType.equals(EEMConstants.ELECTION_TYPE_SEP_5SR)
				|| electionType.equals(EEMConstants.ELECTION_TYPE_SEP_CWK)
				|| electionType.equals(EEMConstants.ELECTION_TYPE_SEP_DUL)
				|| electionType.equals(EEMConstants.ELECTION_TYPE_SEP_EGH)
				|| electionType.equals(EEMConstants.ELECTION_TYPE_SEP_ELP)
				|| electionType.equals(EEMConstants.ELECTION_TYPE_SEP_RES)
				|| electionType.equals(EEMConstants.ELECTION_TYPE_SEP_ADMIN))
			return true;

		return false;
	}

	/**
	 * Cambia_ElectionLogic-Start
	 */
	/**
	 * 
	 * @param objVO
	 * @param errorCode
	 * @param dates
	 * @return
	 * @throws ParseException
	 */
	public String getElectionType(EEMApplMasterVO eemApplMasterVO, String errorCode, String[] dates)
			throws ParseException {
		String applDate;
		String month;
		int year = 0;
		int aepYear = 0;

		EEMApplicationVO eemApplicationVO = eemApplMasterVO.getApplVO();
		EEMApplPlanVO eemApplPlanVO = eemApplMasterVO.getApplPlanVO();
		// EEMApplOtherPlanVO eemMApplOtherPlanVO =
		// eemApplMasterVO.getApplOtherPlanVO();
		EEMApplOtherCovVO eemApplOtherCovVO = eemApplMasterVO.getApplOtherCovVO();

		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		applDate = eemApplicationVO.getApplDate();
		// I2 UAT --- Start
		aepYear = Calendar.getInstance().get(Calendar.YEAR);
		String strDt = dates[0] != null ? dates[0].substring(0, 6) : "0";
		String endDt = dates[1] != null ? dates[1].substring(0, 6) : "0";
		strDt = (strDt + (aepYear)).toString();
		endDt = (endDt + (aepYear)).toString();
		Date startDate = null;
		Date endDate = null;
		Date applicationDate = null;
		try {
			startDate = sdf.parse(strDt);
			endDate = sdf.parse(endDt);
			applicationDate = sdf.parse(applDate);
		} catch (Exception e) {
			LOGGER.error(
					"Parse exception thrown in EEMElection:getElectionType()::startDate :{} endDate :{} applicationDate ::{}",
					startDate, endDate, applicationDate);
		}
		if (!(applDate.equalsIgnoreCase("") || applDate == null)) {
			month = applDate.substring(0, 2);
			year = Integer.parseInt(applDate.substring(6, 10));

			if (Integer.parseInt(month) == 12) {
				month = "01";
				year += 1;
			} else {
				month = Integer.toString((Integer.parseInt(month) + 1));
			}
			if (month.length() == 1) {
				month = "0" + month;
			}
			applDate = month + "/" + "01" + "/" + Integer.toString(year);
		}

		if (eemApplPlanVO.getEnrollPbp() != null && !(eemApplPlanVO.getEnrollPbp().equalsIgnoreCase(""))
				&& Integer.parseInt(eemApplPlanVO.getEnrollPbp()) > 799) {
			eemApplPlanVO.setElectionType("W");
			eemApplPlanVO.setSepElectionDt(applDate);
		}

		else if (applicationDate.compareTo(startDate) == 1) {
			if (applicationDate.compareTo(endDate) == -1) {
				applDate = "01" + "/" + "01" + "/" + (Integer.toString(aepYear + 1));
				// objVO.setElectionType("A");
				eemApplPlanVO.setElectionType("A");
				eemApplPlanVO.setSepElectionDt(applDate);
			}
		} else
		// if(eemApplOtherCovVO.getMedicaidInd().equals("Y")){
		if (eemApplOtherCovVO.getStMedicaid().equals("Y")) {
			// objVO.setElectionType("U");
			eemApplPlanVO.setElectionType("U");
			eemApplPlanVO.setSepElectionDt(applDate);
		}

		else if (eemApplOtherCovVO.getNameInstitute() != null
				&& !eemApplOtherCovVO.getNameInstitute().trim().equals("")) {
			// if(eemApplOtherCovVO.getLtcFacId() != null &&
			// !eemApplOtherCovVO.getLtcFacId().trim().equals("")){
			// objVO.setElectionType("T");
			eemApplPlanVO.setElectionType("T");
			eemApplPlanVO.setSepElectionDt(applDate);
		}

		// if(objVO.getElectionType() == null || objVO.getElectionType().equals("")){
		if (eemApplPlanVO.getElectionType() == null || eemApplPlanVO.getElectionType().equals("")) {
			errorCode = "AP087";
		}
		return errorCode;
	}

	private String validateLISSEPElectionType(EEMElectionVO objVO, String electionType, boolean validation)
			throws ParseException {
		String applDate = objVO.getApplicationDt();
		/** DUAL/LIS SEP is not applicable for MA Plan. **/
		String planDesgn = StringUtil.nonNullTrim(objVO.getPlanDesgn());
		if (planDesgn.equals(EEMConstants.PLAN_DESGN_MA)) {
			if (validation)
				return "AP087";
			else
				return "";
		}

		if (DateMath.isBetweenQ4(applDate)) {

			if (validation)
				return "AP351";
			else
				return "";
		}
		/*
		 * if(mbd!= null && mbd.getCara_Reccnt()> 0){
		 * 
		 * if(eemApplDAO.isCARAEligible(disEnrollEffDate,mbd.getHicNbr(),mbd.getMbi(),
		 * mbd.getEligibilitySrcTable())){ return new
		 * LabelValuePair("BENEFICIARY HAS CARA STATUS - CAN NOT USE SEP ELECT(L)","014"
		 * ); } }
		 */

		// TODO: Need to change below code
		/*
		 * List<CARAHistoryVO> caraHistoryList = eemApplMasterVO.getCaraHistoryList();
		 * if (DateMath.isBetweenQ4(applDate))
		 * 
		 * if (null != caraHistoryList && caraHistoryList.size() > 0) { for
		 * (CARAHistoryVO caraHist : caraHistoryList) { if (DateMath.isBetween(applDate,
		 * caraHist.getStartDate(), caraHist.getEndDate())) if(validation) return
		 * "AP352"; else return ""; } }
		 */

		// CMS Changes for SEP Dual LIS -IFOX-00415122: start

		if (!StringUtil.nonNullTrim(objVO.getLastUsedSepDate()).equals("")) {
			String lastUsedSepDate = objVO.getLastUsedSepDate();
			String strUsedSepDate = lastUsedSepDate.replaceAll("/", "");
			String YYYYUsedSepDate = strUsedSepDate.substring(0, 4);
			String MMDDUsedSepDate = strUsedSepDate.substring(4, 8);
			try {
				if (DateMath.isApplicationRecievedInQ1(MMDDUsedSepDate)) {
					if (DateMath.isBetween(objVO.getApplicationDt(), YYYYUsedSepDate + "0101",
							YYYYUsedSepDate + "0331")) {
						if (validation)
							return "AP355";
						else
							return "";
					}

				}
				if (DateMath.isApplicationRecievedInQ2(MMDDUsedSepDate)) {
					if (DateMath.isBetween(objVO.getApplicationDt(), YYYYUsedSepDate + "0401",
							YYYYUsedSepDate + "0630")) {
						if (validation)
							return "AP355";
						else
							return "";
					}

				}
				if (DateMath.isApplicationRecievedInQ3(MMDDUsedSepDate)) {
					if (DateMath.isBetween(objVO.getApplicationDt(), YYYYUsedSepDate + "0701",
							YYYYUsedSepDate + "0930")) {
						if (validation)
							return "AP355";
						else
							return "";
					}

				}

			} catch (Exception e) {
				LOGGER.error(" EEMElection : validateLISSEPElectionType : Exception : " + e.getMessage());
			}
		}
		// CMS Changes for SEP Dual LIS -IFOX-00415122: end

		// Begin : CMS 2019 January Release- Requirement-3 : DUAL/LIS SEP � L and U.
		try {
			String executionBlock = null;

			if (objVO.isMemberPresentInM360()) {
				String strApplicationDate = objVO.getStrApplicationDate().replaceAll("/", "");
				String YYYYFromApplicationDate = strApplicationDate.substring(4, 8);
				String MMDDFromApplicationDate = strApplicationDate.substring(0, 4);

				// Quarter - 1
				if (DateMath.isApplicationRecievedInQ1(MMDDFromApplicationDate)) {
					if (eemApplDAO.isDUALSEPElectionTypeLAlreadyUsed(objVO.getCustomerId(), objVO.getMemberId(), "L",
							"EAPRV", YYYYFromApplicationDate + "0201", YYYYFromApplicationDate + "0401")) {
						objVO.setErrorCode("AP052");
						executionBlock = "Q1 (EPARV)";

					} else {
						if (eemApplDAO.isDUALSEPElectionTypeLAlreadyUsed(objVO.getCustomerId(), objVO.getMemberId(),
								"L", "DAPRV", YYYYFromApplicationDate + "0101", YYYYFromApplicationDate + "0301")) {
							objVO.setErrorCode("AP052");
							executionBlock = "Q1 (EPARV-DAPRV)";

						} else {

							String earliestEnrollmentDate = eemApplDAO.getEarliestEnrlStDt(objVO.getCustomerId(),
									objVO.getMemberId());
							if (!StringUtil.nonNullTrim(earliestEnrollmentDate).equals("")) {
								if (Integer.parseInt(earliestEnrollmentDate) > Integer
										.parseInt(YYYYFromApplicationDate + "0201")) {
									objVO.setErrorCode("AP052");
									executionBlock = "Q1 (EarliestEnrollmentCheck)";
								}

							} else {
								// Check if the member has any break in coverage (DAPRV/CMSAPRV)
								if (eemApplDAO.isDUALSEPElectionTypeLAlreadyUsed(objVO.getCustomerId(),
										objVO.getMemberId(), "L", "DAPRV", YYYYFromApplicationDate + "0201",
										YYYYFromApplicationDate + "0401")) {
									objVO.setErrorCode("AP052");
									executionBlock = "Q1 (DAPRV)";
								} else {
									electionType = EEMConstants.ELECTION_TYPE_SEP_LIS;
									executionBlock = "Q1 (L)";
								}
							}
						}
					}

				} else {
					if (DateMath.isApplicationRecievedInQ2(MMDDFromApplicationDate)) // Quarter - 2
					{
						if (eemApplDAO.isDUALSEPElectionTypeLAlreadyUsed(objVO.getCustomerId(), objVO.getMemberId(),
								"L", "EAPRV", YYYYFromApplicationDate + "0501", YYYYFromApplicationDate + "0701")) {
							objVO.setErrorCode("AP052");
							executionBlock = "Q2 (EPARV)";

						} else {
							if (eemApplDAO.isDUALSEPElectionTypeLAlreadyUsed(objVO.getCustomerId(), objVO.getMemberId(),
									"L", "DAPRV", YYYYFromApplicationDate + "0401", YYYYFromApplicationDate + "0601")) {
								objVO.setErrorCode("AP052");
								executionBlock = "Q2 (EPARV-DAPRV)";

							} else {

								String earliestEnrollmentDate = eemApplDAO.getEarliestEnrlStDt(objVO.getCustomerId(),
										objVO.getMemberId());
								if (!StringUtil.nonNullTrim(earliestEnrollmentDate).equals("")) {
									if (Integer.parseInt(earliestEnrollmentDate) > Integer
											.parseInt(YYYYFromApplicationDate + "0501")) {
										objVO.setErrorCode("AP052");
										executionBlock = "Q2 (EarliestEnrollmentCheck)";
									}

								} else {
									// Check if the member has any break in coverage (DAPRV/CMSAPRV)
									if (eemApplDAO.isDUALSEPElectionTypeLAlreadyUsed(objVO.getCustomerId(),
											objVO.getMemberId(), "L", "DAPRV", YYYYFromApplicationDate + "0501",
											YYYYFromApplicationDate + "0701")) {
										objVO.setErrorCode("AP052");
										executionBlock = "Q2 (DAPRV)";
									} else {
										electionType = EEMConstants.ELECTION_TYPE_SEP_LIS;
										executionBlock = "Q2 (L)";
									}
								}
							}
						}

					} else {
						if (DateMath.isApplicationRecievedInQ3(MMDDFromApplicationDate)) // Quarter - 3
						{
							if (eemApplDAO.isDUALSEPElectionTypeLAlreadyUsed(objVO.getCustomerId(), objVO.getMemberId(),
									"L", "EAPRV", YYYYFromApplicationDate + "0801", YYYYFromApplicationDate + "1001")) {
								objVO.setErrorCode("AP052");
								executionBlock = "Q3 (EPARV)";

							} else {
								if (eemApplDAO.isDUALSEPElectionTypeLAlreadyUsed(objVO.getCustomerId(),
										objVO.getMemberId(), "L", "DAPRV", YYYYFromApplicationDate + "0701",
										YYYYFromApplicationDate + "0901")) {
									objVO.setErrorCode("AP052");
									executionBlock = "Q3 (EPARV-DAPRV)";

								} else {

									String earliestEnrollmentDate = eemApplDAO
											.getEarliestEnrlStDt(objVO.getCustomerId(), objVO.getMemberId());
									if (!StringUtil.nonNullTrim(earliestEnrollmentDate).equals("")) {
										if (Integer.parseInt(earliestEnrollmentDate) > Integer
												.parseInt(YYYYFromApplicationDate + "0801")) {
											objVO.setErrorCode("AP052");
											executionBlock = "Q3 (EarliestEnrollmentCheck)";
										}

									} else {
										// Check if the member has any break in coverage (DAPRV/CMSAPRV)
										if (eemApplDAO.isDUALSEPElectionTypeLAlreadyUsed(objVO.getCustomerId(),
												objVO.getMemberId(), "L", "DAPRV", YYYYFromApplicationDate + "0801",
												YYYYFromApplicationDate + "1001")) {
											objVO.setErrorCode("AP052");
											executionBlock = "Q3 (DAPRV)";
										} else {
											electionType = EEMConstants.ELECTION_TYPE_SEP_LIS;
											executionBlock = "Q3 (L)";
										}
									}
								}

							}
						} else {
							electionType = EEMConstants.ELECTION_TYPE_SEP_LIS;
							executionBlock = "NOT FALL BETWEEN ANY QUARTERS";
						}
					}
				}

			}
			// Commented because the member might have used 'L' during his previous
			// enrollment
			// with other plans hence we should allow member to use the Election Type 'L'
			// and shouldn't show election type error incase of 'L'.
			/*
			 * else { //If member not present in M360 objVO.setErrorCode("AP052");
			 * executionBlock = "MEMBER NOT PRESENT IN M360"; }
			 */
			LOGGER.info(" EEMElection : validateLISSEPElectionType : ExecutionBlock : " + executionBlock + " : ");
			// executionBlock = null;

		} catch (Exception e) {
			LOGGER.error(" EEMElection : validateLISSEPElectionType : Exception : " + e);
		}

		if (validation)
			return objVO.getErrorCode();
		else
			return electionType;

	}

	public LabelValuePair validateDisenrollment(String ccm, EEMMbrEnrollmentDO newVO, MbdDO mbd,
			EEMMbrEnrollmentDAO enrollmentDao) throws ParseException, ApplicationException {
		String customerId = newVO.getCustomerId();
		String effDate = newVO.getEffStartDate();
		String applDate = newVO.getApplicationDate();
		String electionType = StringUtil.nonNullTrim(newVO.getElectionTypeCd());
		String planDesgn = newVO.getPlanDesignation();
		String editOverrideInd = newVO.getEditOverrideInd();
		String curEnrollStatus = newVO.getEnrollStatus();
		String partADt = StringUtil.nonNullTrim(mbd.getPrtAEntitleDate());
		String partBDt = StringUtil.nonNullTrim(mbd.getPrtBEntitleDate());
		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		String entitleDt = "";

		if (electionType.equals("") || StringUtil.nonNullTrim(effDate).equals("")
				|| StringUtil.nonNullTrim(applDate).equals(""))
			return new LabelValuePair("Election Type, Effective Date and Application date must be populated", "001");

		String dtMonthDay = effDate.substring(4);
		if (electionType.equals(EEMConstants.ELECTION_TYPE_AEP)) {
			if (dtMonthDay.equals("0101"))
				return new LabelValuePair("", "000");
			return new LabelValuePair("AEP Election Type only valid on 01/01 Effective Date", "002");
		}

		String fdomApplDate = applDate.substring(0, 6) + "01";
		String chkApplDate = DateMath.addMonth(fdomApplDate, 1);

		if (electionType.equals(EEMConstants.ELECTION_TYPE_MADP)) {
			if (planDesgn.equals(EEMConstants.PLAN_DESGN_PDP))
				return new LabelValuePair("MADP Election Type Not valid for PDP plans", "003");

			if (!DateMath.isEqual(effDate, chkApplDate))
				return new LabelValuePair(
						"For MADP Election Type Effective date must be 1 month greater than Application date", "004");

			if (!(dtMonthDay.equals("0201") || dtMonthDay.equals("0301")))
				return new LabelValuePair("For MADP Election Type Effective date must be 02/01 or 03/01", "005");

			EEMProfileItemDO itemDEP = eemProfileSettings.getProfileObject(customerId, EEMConstants.DEP);

			String curDate = DateUtil.getTodaysDate();

			String curYear = ccm.substring(0, 4);
			String startDEP = curYear + itemDEP.getEffStartDate().substring(4);
			String endDEP = curYear + itemDEP.getEffEndDate().substring(4);

			if (!DateMath.isBetween(curDate, startDEP, endDEP))
				return new LabelValuePair("MADP Election Type only valid from "
						+ DateFormatter.reFormat(startDEP, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY) + " thru "
						+ DateFormatter.reFormat(endDEP, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY), "006");

			if (DateMath.isGreaterThan(ccm, fdomApplDate)) {
				if (!editOverrideInd.equals("Y"))
					return new LabelValuePair(
							"CCM is Greater than Application Date, Please use Bypass Edits to Override", "007");
			}
			return new LabelValuePair("", "000");
		}

		if (validateSEP(electionType)) {
			if (!(curEnrollStatus.equals(EEMConstants.MBR_STAT_DPEND)
					|| curEnrollStatus.equals(EEMConstants.MBR_STAT_DAPRV))) {
				if (!DateMath.isEqual(effDate, chkApplDate))
					return new LabelValuePair(
							"For SEP Election Type Effective date must be 1 month greater than Application date",
							"008");
			}
			return new LabelValuePair("", "000");
		}

		if (electionType.equals(EEMConstants.ELECTION_TYPE_OEPI)) {
			if (!DateMath.isEqual(effDate, chkApplDate))
				return new LabelValuePair("Election Type Effective date must be 1 month greater than Application date",
						"010");
			return new LabelValuePair("", "000");
		}

		String currentDate = new SimpleDateFormat("yyyyMMdd").format(new Date()).toString();
		String disEnrollEffDate = effDate;
		int effectiveYear = DateMath.getYearFromDate(disEnrollEffDate);

		if (electionType.equals(EEMConstants.ELECTION_TYPE_MA_OEP)) {

			if (!"".equals(StringUtil.nonNullTrim(partADt)) && !"".equals(StringUtil.nonNullTrim(partBDt))) {
				if (df.parse(partADt).after(df.parse(partBDt))) {
					entitleDt = partADt;
				} else {
					entitleDt = partBDt;
				}
			}

			boolean isReqDtCovValid = DateMath.isEqual(DateMath.getFirstOfNextMonth(currentDate), disEnrollEffDate);
			if (!isReqDtCovValid && !DateMath.isBetweenDARV_Q1(currentDate, disEnrollEffDate)
					&& !"".equals(StringUtil.nonNullTrim(entitleDt)) && !DateMath.isBetween(disEnrollEffDate,
							DateMath.addMonth(entitleDt, 1), DateMath.addMonth(entitleDt, 4))) {
				int year = DateMath.getYearFromDate(currentDate);
				return new LabelValuePair(
						"For MA OEP Election Type, the Disenrollment Effective date must be 1st of the next month from current date and within 2/1/"
								+ year + " to 4/1/" + year + " and between first 3 months of Entitlement date",
						"012");
			}

			else {
				if (enrollmentDao.isMAOEPElectionTypeAlreadyUsed(newVO.getCustomerId(), newVO.getMemberId(),
						effectiveYear + "0201", disEnrollEffDate))
					return new LabelValuePair("Member already used MA OEP election for the current year", "013");
				else if (enrollmentDao.validateBrkInCov(newVO.getCustomerId(), newVO.getMemberId(),
						effectiveYear + "0201", effectiveYear + "0501")
						&& !newVO.getEditOverrideInd().equalsIgnoreCase("Y"))
					return new LabelValuePair(
							"Could not determine whether member already used MA OEP. If still, you want to submit the MA OEP, check the BypassEdit and update again.",
							"014");
				else
					return new LabelValuePair("", "000");
			}

		}

		if (newVO.getElectionTypeCd().equals(EEMConstants.ELECTION_TYPE_SEP_LIS)) {

			if (planDesgn.equals(EEMConstants.PLAN_DESGN_MA)) {
				return new LabelValuePair("SEP DUAL /LIS ELECTION(L) CANNOT BE USED FOR MA ONLY MEMBER", "014");
			}
			String dayBeforeEffectiveSatrtDate = DateMath.minusOneDay(disEnrollEffDate);

			if (DateMath.isBetweenQ4(dayBeforeEffectiveSatrtDate)) {

				return new LabelValuePair("SEP DUAL /LIS ELECTION(L) CANNOT BE USED FOR LAST QUARTER", "014");
			}
			if (mbd != null && mbd.getCara_Reccnt() > 0) {

				if (eemApplDAO.isCARAEligible(disEnrollEffDate, mbd.getHicNbr(), mbd.getMbi(),
						mbd.getEligibilitySrcTable())) {
					return new LabelValuePair("BENEFICIARY HAS CARA STATUS - CAN NOT USE SEP ELECT(L)", "014");
				}
			}

			if (!StringUtil.nonNullTrim(newVO.getLastUsedSepDate()).equals("")) {
				String lastUsedSepDate = newVO.getLastUsedSepDate();
				String strUsedSepDate = lastUsedSepDate.replaceAll("/", "");
				String YYYYUsedSepDate = strUsedSepDate.substring(0, 4);
				String MMDDUsedSepDate = strUsedSepDate.substring(4, 8);
				try {
					if (DateMath.isApplicationRecievedInQ1(MMDDUsedSepDate)) {
						if (DateMath.isBetween(disEnrollEffDate, YYYYUsedSepDate + "0101", YYYYUsedSepDate + "0331")) {
							return new LabelValuePair("SEP DUAL/LIS ELECTION(L) ALREADY USED FOR THE QUARTER", "014");
						}

					}
					if (DateMath.isApplicationRecievedInQ2(MMDDUsedSepDate)) {
						if (DateMath.isBetween(disEnrollEffDate, YYYYUsedSepDate + "0401", YYYYUsedSepDate + "0630")) {
							return new LabelValuePair("SEP DUAL/LIS ELECTION(L) ALREADY USED FOR THE QUARTER", "014");
						}

					}
					if (DateMath.isApplicationRecievedInQ3(MMDDUsedSepDate)) {
						if (DateMath.isBetween(disEnrollEffDate, YYYYUsedSepDate + "0701", YYYYUsedSepDate + "0930")) {
							return new LabelValuePair("SEP DUAL/LIS ELECTION(L) ALREADY USED FOR THE QUARTER", "014");
						}

					}

				} catch (Exception e) {
					e.printStackTrace();
				}
			}

			if (isMemberAlreadyUsedElectionTypeL(newVO, null))
				return new LabelValuePair("Beneficiary has already used DUAL/LIS SEP election type code 'L' )", "014");
			else
				return new LabelValuePair("", "000");

		}

		return new LabelValuePair("Invalid Disenrollment Election Type", "009");
	}

}
