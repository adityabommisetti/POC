/**
 * 
 */
package com.medicare.mss.vo;

import java.io.Serializable;
import java.util.List;

import com.medicare.mss.util.LabelValueKeyPair;
import com.medicare.mss.util.LabelValuePair;

import lombok.Data;

/**
 * @author DU20098149
 *
 */
@Data
public class EEMWfCacheVO implements Serializable {

	private static final long serialVersionUID = -4670907262750680667L;
	
	private List<LabelValuePair> wfCaseStatuses;
	private List<LabelValueKeyPair> wfAssignedToUsers;
	private List<LabelValuePair> wfCaseDesc;
	private List<LabelValuePair> queueList;
	private List<LabelValuePair> wfCasePriority;
	private int maxAssignableWork;
	private String supervisor;
	private String wfOptIn;
}
