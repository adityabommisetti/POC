package com.medicare.mss.daoImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class CustomerPersistence {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public void updateSignOnCnt(String customerNo, int relCnt) {

		String sql = "UPDATE customer set SignOn_cnt = SignOn_cnt + ? WHERE Cust_nbr = ?";

		jdbcTemplate.update(sql, new Object[] { relCnt, customerNo });
	}

}
