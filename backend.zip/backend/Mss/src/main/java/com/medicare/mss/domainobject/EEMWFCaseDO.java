package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMWFCaseDO {
	
	@ColumnMapper(columnName = "APPLICATION_ID", propertyName = "appId")
	private String appId;
	
	@ColumnMapper(columnName = "CASE_DATE", propertyName = "caseDate")
	private String caseDate;

	@ColumnMapper(columnName = "CASE_DESC", propertyName = "caseDesc")
	private String caseDesc;

	@ColumnMapper(columnName = "CASE_DUE_DATE", propertyName = "caseDueDate")
	private String caseDueDate;

	@ColumnMapper(columnName = "CASE_ID", propertyName = "caseId")
	private int caseId;

	@ColumnMapper(columnName = "CASE_REASSIGN_DATE", propertyName = "caseReassignDate")
	private String caseReassignDate;

	@ColumnMapper(columnName = "CASE_STATUS", propertyName = "caseStatus")
	private String caseStatus;

	@ColumnMapper(columnName = "CASE_TIMESTAMP", propertyName = "caseTimeStamp")
	private String caseTimeStamp;

	@ColumnMapper(columnName = "CURRENT_USER_ID", propertyName = "currentUserId")
	private String currentUserId;

	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;

	@ColumnMapper(columnName = "DAYS_REMAINING", propertyName = "daysRemaining")
	private String daysRemaining;

	@ColumnMapper(columnName = "INITIAL_USER_ID", propertyName = "initialUserId")
	private String initialUserId;

	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;

	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserId")
	private String lastUpdtUserId;

	@ColumnMapper(columnName = "MEMBER_ID", propertyName = "mbrId")
	private String mbrId;

	@ColumnMapper(columnName = "MEMBER_NAME", propertyName = "mbrName")
	private String mbrName;

	@ColumnMapper(columnName = "MEDICARE_ID", propertyName = "medicareId")
	private String medicareId;

	@ColumnMapper(columnName = "OVERRIDE_IND", propertyName = "overrideInd")
	private String overrideInd;

	@ColumnMapper(columnName = "QUEUE_CD", propertyName = "queueCode")
	private String queueCode;

	@ColumnMapper(columnName = "REASSIGN_TYPE_CD", propertyName = "reAssignTypeCode")
	private String reAssignTypeCode;

	@ColumnMapper(columnName = "RISK_IND", propertyName = "riskInd")
	private String riskInd;

	@ColumnMapper(columnName = "SUPPLEMENTAL_ID", propertyName = "supplementalId")
	private String supplementalId;
	
	@ColumnMapper(columnName = "PRTY_NBR", propertyName = "prtyNbr")
	private String prtyNbr;
	
	private String queueName;
}
