package com.medicare.mss.domainobject;

import java.io.Serializable;

import com.medicare.mss.annotation.ColumnMapper;
import com.medicare.mss.vo.EMDatedSegmentVO;

import lombok.Data;

@Data
public class EmMbrAgentDO implements EMDatedSegmentVO, Cloneable, Serializable{
	
	
	private static final long serialVersionUID = 9175564029419713645L;
	
	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;
	
	@ColumnMapper(columnName = "MEMBER_ID", propertyName = "memberId")
	private String memberId;

	@ColumnMapper(columnName = "AGENT_ID", propertyName = "agentId")
	private String agentId;
	
	@ColumnMapper(columnName = "AGENT_TYPE", propertyName = "agentType")
	private String agentType;
	
	private String agentTypeDesc;
	
	@ColumnMapper(columnName = "AGENT_TIN", propertyName = "agentTIN")
	private String agentTIN;
	
	@ColumnMapper(columnName = "AGENT_NAME", propertyName = "agentName")
	private String agentName;
	
	@ColumnMapper(columnName = "AGENT_PHONE", propertyName = "agentPhone")
	private String agentPhone;
	
	@ColumnMapper(columnName = "AGENT_EMAIL", propertyName = "agentEmail")
	private String agentEmail;

	@ColumnMapper(columnName = "AGENCY_ID", propertyName = "agencyId")
	private String agencyId;
	
	@ColumnMapper(columnName = "AGENCY_TYPE", propertyName = "agencyType")
	private String agencyType;
	
	private String agencyTypeDesc;
	
	@ColumnMapper(columnName = "AGENCY_TIN", propertyName = "agencyTIN")
	private String agencyTIN;
	
	@ColumnMapper(columnName = "AGENCY_NAME", propertyName = "agencyName")
	private String agencyName;
	
	@ColumnMapper(columnName = "AGENCY_PHONE", propertyName = "agencyPhone")
	private String agencyPhone;
	
	@ColumnMapper(columnName = "AGENCY_EMAIL", propertyName = "agencyEmail")
	private String agencyEmail;

	@ColumnMapper(columnName = "OVERRIDE_IND", propertyName = "overrideInd")
	private String overrideInd;
	
	@ColumnMapper(columnName = "PLAN_ID", propertyName = "planId")
	private String planId;
	
	@ColumnMapper(columnName = "EFF_START_DATE", propertyName = "effStartDate")
	private String effStartDate;
	
	@ColumnMapper(columnName = "EFF_END_DATE", propertyName = "effEndDate")
	private String effEndDate;
	
	@ColumnMapper(columnName = "CREATE_TIME", propertyName = "createTime")
	private String createTime;
	
	@ColumnMapper(columnName = "CREATE_USERID", propertyName = "createUserId")
	private String createUserId;
	
	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;
	
	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserId")
	private String lastUpdtUserId;
	
	private String selAgencyId;
	/** Triple S BasePlus Migration START **/
	// Begin: Added for IFOX-IFOX-00389914
	private String disEnrollApprvStartDateMinusOne;
	private String currentDateTime;
	/** Triple S BasePlus Migration END **/

	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	
	public boolean isEndDateChange(Object obj) {
		// return true;// earlier false. True allows the user to terminate Agent by end
		// date. No new record is created with end date 99/99/9999.
		// The above code is commented as it is not allowing to split records. updated
		// as per "Defect #9 Hometown"
		EmMbrAgentDO chkVO = (EmMbrAgentDO) obj;
		return !(chkVO.getEffEndDate().equalsIgnoreCase(this.effEndDate));
	}

	public boolean isForSamePeriod(Object obj) {

		EmMbrAgentDO chkVO = (EmMbrAgentDO) obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate))
			if (chkVO.getEffEndDate().equals(this.effEndDate))
				if (chkVO.getPlanId().equals(this.planId))
					if (chkVO.getMemberId().equals(this.memberId))
						if (chkVO.getCustomerId().equals(this.customerId))
							if (chkVO.getOverrideInd().equals(this.overrideInd))
								return true;
		return false;
	}

	public boolean isSamePlan(Object obj) {

		EmMbrAgentDO chkVO = (EmMbrAgentDO) obj;
		if (chkVO.getPlanId().equals(this.planId))
			if (chkVO.getMemberId().equals(this.memberId))
				if (chkVO.getCustomerId().equals(this.customerId))
					return true;
		return false;
	}

	public int compareTo(Object anotherEmMbrAgentVO) throws ClassCastException {
		if (!(anotherEmMbrAgentVO instanceof EmMbrAgentDO))
			throw new ClassCastException("A EmMbrAgentVO object expected.");
		String firstAgencyID = this.agencyId;
		String secondAgencyID = ((EmMbrAgentDO) anotherEmMbrAgentVO).getAgencyId();
		return secondAgencyID.compareTo(firstAgencyID);
	}

	public boolean isSameAgentPlan(Object obj) {

		EmMbrAgentDO chkVO = (EmMbrAgentDO) obj;
		if (chkVO.getPlanId().equals(this.planId))
			if (chkVO.getAgentId().equals(this.agentId))// Can have different agents for same plan!
				if (chkVO.getMemberId().equals(this.memberId))
					if (chkVO.getCustomerId().equals(this.customerId))
						return true;
		return false;
	}

	public boolean isSame(Object obj) {

		EmMbrAgentDO chkVO = (EmMbrAgentDO) obj;
		if (chkVO.getEffStartDate().equals(this.effStartDate))
			if (chkVO.getEffEndDate().equals(this.effEndDate))
				if (chkVO.getAgentId().equals(this.agentId))
					if (chkVO.getAgencyId().equals(this.agencyId))
						if (chkVO.getPlanId().equals(this.planId))
							if (chkVO.getMemberId().equals(this.memberId))
								if (chkVO.getCustomerId().equals(this.customerId))
									if (chkVO.getOverrideInd().equals(this.overrideInd))
										if (chkVO.getCreateTime().equals(this.createTime))
											if (chkVO.getCreateUserId().equals(this.createUserId))
												if (chkVO.getLastUpdtTime().equals(this.lastUpdtTime))
													if (chkVO.getLastUpdtUserId().equals(this.lastUpdtUserId))
														return true;
		return false;
	}


	public String getType() {
		return planId;
	}
	
}
