package com.medicare.mss.vo;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class EMWFMasterVO implements Serializable {

	private static final long serialVersionUID = 7721619513273981199L;
	
	private List<WorkFlowDashletVO> dashletData;
	private List<EEMWFCaseVO> caseData;
	private List<EEMWFActivityVO> activityData;
	private String message;
	private boolean nextPage;

}
