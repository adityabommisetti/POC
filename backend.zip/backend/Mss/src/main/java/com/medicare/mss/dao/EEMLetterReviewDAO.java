package com.medicare.mss.dao;

import java.util.List;
import java.util.Map;

import com.medicare.mss.domainobject.EEMLetterUploadFormDO;
import com.medicare.mss.domainobject.EmCorrMbrDO;
import com.medicare.mss.domainobject.EmCorrVarDataDO;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.vo.EEMLetterReviewQCMasterVO;
import com.medicare.mss.vo.EEMLetterReviewVO;
import com.medicare.mss.vo.PageableVO;

public interface EEMLetterReviewDAO {

	List<EmCorrVarDataDO> getMbrLetterData(Map<String, String> searchParams);

	byte[] displayDocumentFromDB(Map<String, String> searchParams);

	PageableVO getLetterReviewSearchResults(EEMLetterReviewVO letterReviewVO, boolean isPagination);

	void updateCorrMbr(EmCorrMbrDO newDO, String userId, String lastUpdtTime);

	void updateCorrInputJournal(String customerId, String filebatchid, String deleteAdj, String holdAdj, String userId);

	void uploadLettersToDataBase(EEMLetterUploadFormDO eemLetterUploadForm, String strDateTimeStamp);

	boolean validateSourceAndPrimaryId(String customerId, String memberId, String recordType);

	String getMaxFileBatchId(String customerId, String memberId, String letterName);

	void insertMemberAndApplicationLetters(EEMLetterUploadFormDO eemLetterUploadFormDO, String strDateTimeStamp);

	List<LabelValuePair> getLetterReviewQcBatchId(EEMLetterReviewVO letterReviewVO, String customerId);

	List<LabelValuePair> getLetterReviewQcDescription(String batchId, String customerId);

	List<EmCorrMbrDO> getLetterReviewQCSearchResults(EEMLetterReviewVO letterReviewSearch, String customerId,
			String ts);

	void getLetterReviewQCUpdate(EEMLetterReviewQCMasterVO letterReviewQCSearchVO, String userId, String customerId,
			String ts);
}
