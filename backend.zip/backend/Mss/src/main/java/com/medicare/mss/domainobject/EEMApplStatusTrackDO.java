package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMApplStatusTrackDO {
	
	@ColumnMapper(columnName = "LOG_TIME", propertyName = "logTime")
	private String logTime;
	
	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserId")
	private String lastUpdtUserId;
	
	@ColumnMapper(columnName = "APPL_STATUS", propertyName = "applStatus")
	private String applStatus;
	
}
