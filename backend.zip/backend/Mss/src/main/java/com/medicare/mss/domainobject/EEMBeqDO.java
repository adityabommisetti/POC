package com.medicare.mss.domainobject;

import lombok.Data;

@Data
public class EEMBeqDO {
	
	private String customerId;
	private String recordId;
	private String lastUpdtTime;
	private String planId;
	private String hicNbr;
	private String lastName;
	private String firstName;
	private String birthDate;
	private String beqStatus;
	private String lastUpdtUserid;

}
