package com.medicare.mss.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.medicare.mss.caching.EEMPersistence;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMDashboardDAO;
import com.medicare.mss.domainobject.EEMDashboardAppDistDO;
import com.medicare.mss.domainobject.EEMDashboardApplStatusDO;
import com.medicare.mss.domainobject.EEMDashboardCmsDO;
import com.medicare.mss.domainobject.EEMDashboardFileLoadErrDisDO;
import com.medicare.mss.domainobject.EEMDashboardLisMbrDistDO;
import com.medicare.mss.domainobject.EEMDashboardLtrVolDisDO;
import com.medicare.mss.domainobject.EEMDashboardMbrShipDO;
import com.medicare.mss.domainobject.EEMDashboardSpclStatDisDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.vo.EEMDashboardApplStatusVO;
import com.medicare.mss.vo.EEMDashboardCmsVO;
import com.medicare.mss.vo.EEMDashboardLisMbrDistVO;

@Service
@Transactional(rollbackFor = ApplicationException.class)
public class EEMDashboardService {

	@Autowired
	private EEMDashboardDAO dashboardDAO;

	@Autowired
	private CacheService sessionHelper;

	@Autowired
	private EEMPersistence eemPer;

	public Map<String, List<EEMDashboardApplStatusVO>> getPreEnrollStatus(Map<String, String> searchParamMap) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String status = EEMConstants.PRE_ENROLL_STATUS;
		List<EEMDashboardApplStatusVO> preEnrollStatusVOList = new ArrayList<>();
		List<EEMDashboardApplStatusDO> preEnrollStatusDOList = dashboardDAO.getApplStatus(customerId, status,
				searchParamMap);
		CommonUtils.copyList(preEnrollStatusDOList, preEnrollStatusVOList, EEMDashboardApplStatusVO.class);
		Map<String, List<EEMDashboardApplStatusVO>> preEnrollStatus = preEnrollStatusVOList.stream()
				.sorted(Comparator.comparing(EEMDashboardApplStatusVO::getApplStatus)).collect(Collectors
						.groupingBy(EEMDashboardApplStatusVO::getApplStatus, LinkedHashMap::new, Collectors.toList()));

		return preEnrollStatus;
	}

	public Map<String, List<EEMDashboardApplStatusVO>> getApplicationAgeing() {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String status = EEMConstants.APPLICATION_AGEING;
		Map<String, List<EEMDashboardApplStatusVO>> applicationAgeing = new TreeMap<>();
		Map<String, String> searchParamMap = new HashMap<>();
		List<EEMDashboardApplStatusVO> onetoTwodaysList = new ArrayList<>();
		List<EEMDashboardApplStatusVO> threetoFivedaysList = new ArrayList<>();
		List<EEMDashboardApplStatusVO> sixToTendaysList = new ArrayList<>();
		List<EEMDashboardApplStatusDO> applicationAgeingList = dashboardDAO.getApplStatus(customerId, status,
				searchParamMap);
		applicationAgeingList.forEach(eemDashboardApplStatusDO -> {
			String todayDate = DateUtil.getTodaysDate("yyyyMMdd");
			EEMDashboardApplStatusVO eemDashboardApplStatusVO = new EEMDashboardApplStatusVO();
			BeanUtils.copyProperties(eemDashboardApplStatusDO, eemDashboardApplStatusVO);
			String applDate = eemDashboardApplStatusVO.getRecieveDate();
			int count = DateMath.calculateDiff(todayDate, applDate);
			if (count <= 2) {
				eemDashboardApplStatusVO.setAgeingDays(count);
				onetoTwodaysList.add(eemDashboardApplStatusVO);
			} else if (count >= 3 && count <= 5) {
				eemDashboardApplStatusVO.setAgeingDays(count);
				threetoFivedaysList.add(eemDashboardApplStatusVO);
			} else if (count >= 6 && count <= 10) {
				eemDashboardApplStatusVO.setAgeingDays(count);
				sixToTendaysList.add(eemDashboardApplStatusVO);
			}
		});
		applicationAgeing.put("1-2 Days", onetoTwodaysList);
		applicationAgeing.put("3-5 Days", threetoFivedaysList);
		applicationAgeing.put("6-10 Days", sixToTendaysList);

		return applicationAgeing;
	}

	public Map<String, List<EEMDashboardApplStatusVO>> getRFITrackingStatus() {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String status = EEMConstants.RFI_TRACKING_STATUS;
		Map<String, List<EEMDashboardApplStatusVO>> rfiTracking = new TreeMap<>();
		Map<String, String> searchParamMap = new HashMap<>();
		List<EEMDashboardApplStatusVO> inProgressStatusList = new ArrayList<>();
		List<EEMDashboardApplStatusVO> noResponseStatusList = new ArrayList<>();
		List<EEMDashboardApplStatusVO> onHoldStatusList = new ArrayList<>();
		List<EEMDashboardApplStatusVO> incompleteStatusList = new ArrayList<>();
		List<EEMDashboardApplStatusDO> rfiTrackingList = dashboardDAO.getApplStatus(customerId, status, searchParamMap);
		rfiTrackingList.forEach(eemDashboardApplStatusDO -> {
			String rfiStatus = eemDashboardApplStatusDO.getApplStatus();
			EEMDashboardApplStatusVO eemDashboardApplStatusVO = new EEMDashboardApplStatusVO();
			BeanUtils.copyProperties(eemDashboardApplStatusDO, eemDashboardApplStatusVO);
			if ((rfiStatus.equalsIgnoreCase("INCRFIELCT")) || (rfiStatus.equalsIgnoreCase("INCRFIGEN"))
					|| (rfiStatus.equalsIgnoreCase("INCRFIREQ")) || (rfiStatus.equalsIgnoreCase("INCRFITRG"))) {
				inProgressStatusList.add(eemDashboardApplStatusVO);
			} else if (rfiStatus.equalsIgnoreCase("RFINORESP")) {
				noResponseStatusList.add(eemDashboardApplStatusVO);
			} else if (rfiStatus.equalsIgnoreCase("HOLD")) {
				onHoldStatusList.add(eemDashboardApplStatusVO);
			} else if (rfiStatus.equalsIgnoreCase("INCOMPLETE")) {
				incompleteStatusList.add(eemDashboardApplStatusVO);
			}
		});
		rfiTracking.put("In Progress", inProgressStatusList);
		rfiTracking.put("No Response", noResponseStatusList);
		rfiTracking.put("On Hold", onHoldStatusList);
		rfiTracking.put("InComplete", incompleteStatusList);

		return rfiTracking;
	}

	public Map<String, List<EEMDashboardCmsVO>> getCmsStatus() {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String status = EEMConstants.CMS_STATUS;
		Map<String, List<EEMDashboardCmsVO>> cmsStatusMap = new TreeMap<>();
		List<EEMDashboardCmsVO> cmsReadyStatusList = new ArrayList<>();
		List<EEMDashboardCmsVO> mcareerStatusList = new ArrayList<>();
		List<EEMDashboardCmsVO> cmsSubmitStatusList = new ArrayList<>();
		List<EEMDashboardCmsVO> oneTwoSevenRejectStatusList = new ArrayList<>();
		List<EEMDashboardCmsVO> cmsRejectStatusList = new ArrayList<>();
		List<EEMDashboardCmsDO> cmsStatusList = dashboardDAO.getCmsStatus(customerId, status);
		cmsStatusList.forEach(eemDashboardCmsDO -> {
			String cmsStatus = eemDashboardCmsDO.getEnrollReasonCode();
			EEMDashboardCmsVO eemDashboardCmsVO = new EEMDashboardCmsVO();
			BeanUtils.copyProperties(eemDashboardCmsDO, eemDashboardCmsVO);
			if (cmsStatus.equalsIgnoreCase("CMSREADY")) {
				cmsReadyStatusList.add(eemDashboardCmsVO);
			} else if (cmsStatus.equalsIgnoreCase("MCAREERR")) {
				mcareerStatusList.add(eemDashboardCmsVO);
			} else if (cmsStatus.equalsIgnoreCase("CMSSUBMIT")) {
				cmsSubmitStatusList.add(eemDashboardCmsVO);
			} else if (cmsStatus.equalsIgnoreCase("127REJECT")) {
				oneTwoSevenRejectStatusList.add(eemDashboardCmsVO);
			} else if (cmsStatus.equalsIgnoreCase("CMSREJECT")) {
				cmsRejectStatusList.add(eemDashboardCmsVO);
			}
		});
		cmsStatusMap.put("CMS READY", cmsReadyStatusList);
		cmsStatusMap.put("MCAREER", mcareerStatusList);
		cmsStatusMap.put("CMS SUBMIT", cmsSubmitStatusList);
		cmsStatusMap.put("RDS REJECT", oneTwoSevenRejectStatusList);
		cmsStatusMap.put("CMS REJECT", cmsRejectStatusList);

		return cmsStatusMap;
	}

	public Map<String, List<EEMDashboardCmsVO>> getCmsTransactionStatus() {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String status = EEMConstants.CMS_TRANSACTION_STATUS;
		Map<String, List<EEMDashboardCmsVO>> cmsTransactionMap = new TreeMap<>();
		List<EEMDashboardCmsVO> cmsTXN51StatusList = new ArrayList<>();
		List<EEMDashboardCmsVO> cmsTXN61StatusList = new ArrayList<>();
		List<EEMDashboardCmsVO> cmsTXN72StatusList = new ArrayList<>();
		List<EEMDashboardCmsDO> cmsTransactionStatusList = dashboardDAO.getCmsStatus(customerId, status);
		cmsTransactionStatusList.forEach(eemDashboardCmsDO -> {
			String transactionStatus = eemDashboardCmsDO.getTriggerCode();
			EEMDashboardCmsVO eemDashboardCmsVO = new EEMDashboardCmsVO();
			BeanUtils.copyProperties(eemDashboardCmsDO, eemDashboardCmsVO);
			if (transactionStatus.equalsIgnoreCase("51DI") || transactionStatus.equalsIgnoreCase("51OA")) {
				cmsTXN51StatusList.add(eemDashboardCmsVO);
			} else if (transactionStatus.equalsIgnoreCase("61ER") || transactionStatus.equalsIgnoreCase("61SO")
					|| transactionStatus.equalsIgnoreCase("61CW")) {
				cmsTXN61StatusList.add(eemDashboardCmsVO);
			} else if (transactionStatus.equalsIgnoreCase("72RX")) {
				cmsTXN72StatusList.add(eemDashboardCmsVO);
			}
		});
		cmsTransactionMap.put("TXN 51", cmsTXN51StatusList);
		cmsTransactionMap.put("TXN 61", cmsTXN61StatusList);
		cmsTransactionMap.put("TXN 72", cmsTXN72StatusList);

		return cmsTransactionMap;
	}

	public Map<String, List<EEMDashboardMbrShipDO>> mbrShipDistribution(List<String> planIds) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String customerNbr = sessionHelper.getUserInfo().getCustNbr();
		List<EEMDashboardMbrShipDO> mbrShipDOList = dashboardDAO.mbrShipDistribution(planIds, customerId, customerNbr);
		Map<String, List<EEMDashboardMbrShipDO>> mbrDistMap = mbrShipDOList.stream()
				.collect(Collectors.groupingBy(EEMDashboardMbrShipDO::getPlanId, Collectors.toList()));
		return mbrDistMap;
	}

	public Map<String, List<EEMDashboardAppDistDO>> appDistribution(List<String> planIds) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String customerNbr = sessionHelper.getUserInfo().getCustNbr();
		List<EEMDashboardAppDistDO> appDistList = dashboardDAO.appDistribution(planIds, customerId, customerNbr);
		Map<String, List<EEMDashboardAppDistDO>> appDistMap = appDistList.stream()
				.collect(Collectors.groupingBy(EEMDashboardAppDistDO::getPlanId, Collectors.toList()));
		return appDistMap;
	}

	public List<EEMDashboardLisMbrDistDO> lisMbrDistribution(EEMDashboardLisMbrDistVO lisDistVo) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String customerNbr = sessionHelper.getUserInfo().getCustNbr();
		List<EEMDashboardLisMbrDistDO> lisDistList = dashboardDAO.lisMbrDistribution(lisDistVo, customerId,
				customerNbr);
		
		return lisDistList;
	}

	public Map<String, String> letterVolumeDistribution() {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String todayDate = DateUtil.getTodaysDate();
		List<EEMDashboardLtrVolDisDO> letVolDoList = dashboardDAO.letterVolumeDistribution(customerId, todayDate);
		Map<String, String> ltrDistMap = letVolDoList.stream()
				.collect(Collectors.toMap(EEMDashboardLtrVolDisDO::getLetterName, EEMDashboardLtrVolDisDO::getCount));
		return ltrDistMap;
	}

	public Object specialStatusDistribution() {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		List<EEMDashboardSpclStatDisDO> splDistList = dashboardDAO.specialStatusDistribution(customerId);
		Map<String, String> spclDistMap = splDistList.stream().collect(
				Collectors.toMap(EEMDashboardSpclStatDisDO::getStatusName, EEMDashboardSpclStatDisDO::getCount));
		return spclDistMap;
	}

	public Object fileLoadErrDistribution(Map<String, String> searchParamMap) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		List<EEMDashboardFileLoadErrDisDO> fileDistList = dashboardDAO.fileLoadErrDist(customerId, searchParamMap);
		Map<String, EEMDashboardFileLoadErrDisDO> fileDistMap = fileDistList.stream()
				.collect(Collectors.toMap(EEMDashboardFileLoadErrDisDO::getAppType, ref -> ref));
		List<String> distValues = Arrays.asList("NPD", "CPD", "NMA", "CMA");
		distValues.forEach(ref -> {
			if (!fileDistMap.containsKey(ref)) {
				fileDistMap.put(ref, new EEMDashboardFileLoadErrDisDO(ref));
			}
		});
		return fileDistMap;
	}

	public List<LabelValuePair> getDistinctPlansForCustomer() {
		String customerNbr = sessionHelper.getUserInfo().getCustNbr();
		return eemPer.getDistinctPlansForCustomer(customerNbr);
	}

}
