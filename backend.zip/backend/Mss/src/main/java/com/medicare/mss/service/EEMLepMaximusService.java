/**
 * 
 */
package com.medicare.mss.service;

import java.text.ParseException;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMLepDAO;
import com.medicare.mss.dao.EEMMbrDAO;
import com.medicare.mss.domainobject.EEMLEPMaximusDO;
import com.medicare.mss.domainobject.EMMbrTriggerDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.helper.EEMEnrollHelper;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.vo.EEMLEPMaximusVO;

/**
 * @author DU20098149
 *
 */
@Service
@Transactional(rollbackFor = ApplicationException.class)
public class EEMLepMaximusService {

	@Autowired
	private EEMLepDAO eemLepDAO;

	@Autowired
	private EEMMbrDAO mbrDao;

	@Autowired
	private CacheService sessionHelper;
	
	@Autowired
	private EEMEnrollHelper eemEnrollHelper;

	@Transactional(readOnly = true)
	public EEMLEPMaximusVO getLepMaximusDetails(String customerId, String mbrId) throws ApplicationException {

		EEMLEPMaximusDO eemLEPMaximusDO = eemLepDAO.getLepMaximusDetails(customerId, mbrId);
		EEMLEPMaximusVO eemLEPMaximusVO = new EEMLEPMaximusVO();
		BeanUtils.copyProperties(eemLEPMaximusDO, eemLEPMaximusVO);

		return eemLEPMaximusVO;
	}

	public EEMLEPMaximusVO updateEEMLepMaximus(EEMLEPMaximusVO eemLEPMaximusVO)
			throws ApplicationException, ParseException {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();
		String currentTime = DateUtil.getCurrentDatetimeStamp();

		String tXN73DueDate = StringUtils.isBlank(eemLEPMaximusVO.getDecisionRecDate()) ? EEMConstants.BLANK
				: DateMath.addDay(eemLEPMaximusVO.getDecisionRecDate(), 14);
		String caseFileDueDate = StringUtils.isEmpty(eemLEPMaximusVO.getCaseFileRecDate()) ? EEMConstants.BLANK
				: DateMath.addDay(eemLEPMaximusVO.getCaseFileRecDate(), 14);
		
		eemLEPMaximusVO.setCreateUserId(userId);
		eemLEPMaximusVO.setCustomerId(customerId);
		eemLEPMaximusVO.setTransactionDueDate(tXN73DueDate);
		if (!StringUtils.equals(EEMConstants.VALUE_YES, eemLEPMaximusVO.getIsUpdate())) {
			eemLEPMaximusVO.setCreateTime(currentTime);
		}
		eemLEPMaximusVO.setLastUpdtUserId(userId);
		eemLEPMaximusVO.setLastUpdtTime(currentTime);
		eemLEPMaximusVO.setCaseFileDueDate(caseFileDueDate);
		if (Objects.isNull(eemLEPMaximusVO.getDecisionRecDate())) {
			eemLEPMaximusVO.setDecisionRecDate(EEMConstants.BLANK);
			eemLEPMaximusVO.setDecisionType(EEMConstants.BLANK);
		}

		EEMLEPMaximusDO eemLEPMaximusDO = new EEMLEPMaximusDO();
		BeanUtils.copyProperties(eemLEPMaximusVO, eemLEPMaximusDO);
		eemLepDAO.insertOrUpdateLEPMaximus(eemLEPMaximusDO);

		int result = processLepMaxTimer(eemLEPMaximusVO, EEMConstants.TRIG_CODE_LEP_MAX_90);
		if (result == 0) {
			processLepMaxTimer(eemLEPMaximusVO, EEMConstants.TRIG_CODE_LEP_MAX_14);
		}

		EEMLEPMaximusDO finalResult = eemLepDAO.getLepMaximusDetails(eemLEPMaximusVO.getCustomerId(),
				eemLEPMaximusVO.getMemberId());

		EEMLEPMaximusVO finalVO = new EEMLEPMaximusVO();
		BeanUtils.copyProperties(finalResult, finalVO);

		return finalVO;
	}

	private int processLepMaxTimer(EEMLEPMaximusVO eemLEPMaximusVO, String triggerCode)
			throws ApplicationException, ParseException {

		int result = 0;
		String todaysDate = DateUtil.getTodaysDate();

		EMMbrTriggerDO eemMbrTrigger = eemEnrollHelper.prepareMbrTriggerDO(eemLEPMaximusVO.getMemberId(), EEMConstants.TRIG_TYPE_FOLLOWUP_MEMB, EEMConstants.TRIG_STATUS_OPEN,
				triggerCode, "");

		eemMbrTrigger.setTriggerType(EEMConstants.TRIG_TYPE_FOLLOWUP_MEMB);
		eemMbrTrigger.setTriggerStatus(EEMConstants.TRIG_STATUS_OPEN);
		eemMbrTrigger.setProcessSource(EEMConstants.TRIG_PROCESS_SOURCE_WEBENRL);
		
		

		if (EEMConstants.TRIG_CODE_LEP_MAX_14.equalsIgnoreCase(triggerCode)) {
			if (StringUtils.isEmpty(eemLEPMaximusVO.getCaseFileDueDate())) {
				eemLepDAO.cancelAnyOpenTriggers(eemMbrTrigger);
				return 0;
			}
			if (DateMath.isLessThan(eemLEPMaximusVO.getCaseFileDueDate(), todaysDate)) {
				return 0;
			}
			eemMbrTrigger.setEffectiveDate(eemLEPMaximusVO.getCaseFileDueDate());
		} else {
			if (StringUtils.isEmpty(eemLEPMaximusVO.getDecisionRecDate())) {
				eemLepDAO.cancelAnyOpenTriggers(eemMbrTrigger);
				return 0;
			}
			String duedate = DateMath.addDay(eemLEPMaximusVO.getDecisionRecDate(), 14);
			if (DateMath.isLessThan(duedate, todaysDate)) {
				return 0;
			}
			eemMbrTrigger.setEffectiveDate(duedate);
		}

		boolean mbrTriggerPresent = mbrDao.checkMbrTrigger(eemMbrTrigger);

		if (!mbrTriggerPresent) {
			eemLepDAO.cancelAnyOpenTriggers(eemMbrTrigger);
			result = mbrDao.insertMbrTrigger(eemMbrTrigger);
		}

		return result;
	}


}
