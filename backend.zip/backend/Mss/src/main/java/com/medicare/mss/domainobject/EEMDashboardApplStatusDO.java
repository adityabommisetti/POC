package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMDashboardApplStatusDO {

	@ColumnMapper(columnName = "APPLICATION_ID", propertyName = "applId")
	private int applId;

	@ColumnMapper(columnName = "MEDICARE_ID", propertyName = "medicareId")
	private String medicareId;

	@ColumnMapper(columnName = "APPLICATION_STATUS", propertyName = "applStatus")
	private String applStatus;

	@ColumnMapper(columnName = "APPLICATION_TYPE", propertyName = "applType")
	private String applType;

	@ColumnMapper(columnName = "APPLICATION_DATE", propertyName = "recieveDate")
	private String recieveDate;

	@ColumnMapper(columnName = "EFFECTIVE_DATE", propertyName = "activationDate")
	private String activationDate;

	@ColumnMapper(columnName = "FIRST_NAME", propertyName = "firstName")
	private String firstName;

	@ColumnMapper(columnName = "LAST_NAME", propertyName = "lastName")
	private String lastName;

	@ColumnMapper(columnName = "BIRTH_DATE", propertyName = "birthDate")
	private String birthDate;

	@ColumnMapper(columnName = "PRODUCT_NAME", propertyName = "prodName")
	private String prodName;

	@ColumnMapper(columnName = "CURRENT_USER_ID", propertyName = "assignedToUser")
	private String assignedToUser;

}
