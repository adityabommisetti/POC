package com.medicare.mss.controller;

import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.constants.ReqMappingConstants;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.service.EEMTimersService;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.vo.EEMTimersMasterVO;
import com.medicare.mss.vo.EEMTimersUpdateReqVO;
import com.medicare.mss.vo.PageableVO;

@RestController
public class EEMTimersController {

	@Autowired
	EEMTimersService timersService;

	@PostMapping(ReqMappingConstants.SEARCH_TIMERS)
	public ResponseEntity<JSONResponse> getTimersList(@RequestBody Map<String, String> searchParamMap) {

		EEMTimersMasterVO masterVO = timersService.getSearchList(searchParamMap);
		return sendResponse(masterVO);
	}

	@GetMapping(ReqMappingConstants.GET_TIMERS_TYPE)
	public ResponseEntity<JSONResponse> getTimersType() {

		List<LabelValuePair> lst = timersService.getTimersType();
		return sendResponse(lst);
	}

	@PostMapping(ReqMappingConstants.UPDATE_TIMERS)
	public ResponseEntity<JSONResponse> updateTimers(@RequestBody EEMTimersUpdateReqVO eemTimersUpdateReqVO) {

		EEMTimersMasterVO masterVO = new EEMTimersMasterVO();
		Boolean result = timersService.holdTimersUpdate(eemTimersUpdateReqVO.getEmmTimersVOs());

		if (result) {
			Map<String, String> searchParamMap = new HashMap<>();
			searchParamMap.put("searchType", trimToEmpty(eemTimersUpdateReqVO.getSearchType()));
			searchParamMap.put("searchId", trimToEmpty(eemTimersUpdateReqVO.getSearchId()));
			searchParamMap.put("status", trimToEmpty(eemTimersUpdateReqVO.getStatus()));
			searchParamMap.put("timerType", trimToEmpty(eemTimersUpdateReqVO.getTimerType()));
			masterVO = timersService.getSearchList(searchParamMap);
		}
		return sendResponse(masterVO);
	}
	
	@PostMapping(ReqMappingConstants.SEARCH_TIMERS_NEXT)
	public ResponseEntity<JSONResponse> getTimersListNext(@RequestBody Map<String, String> searchParamMap) {
		PageableVO pageableVO = timersService.getSearchListPagination(searchParamMap);
		return sendResponse(pageableVO);
	}

	private ResponseEntity<JSONResponse> sendResponse(Object object) {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;
		if (null == object) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			jsonResponse.setData(null);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
			jsonResponse.setMessage(EEMConstants.BLANK);
			jsonResponse.setData(object);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}
}
