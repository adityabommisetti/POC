package com.medicare.mss.vo;

import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
public class EEMBilPaymentEntryInvVO {
	private String invoiceNbr;
	private String itemNumber;
	private String appliedAmount;
	private String createTime;
	private String createUserId;
	private String lastUpdtTime;
	private String lastUpdtUserId;
	
	public String getFrmtCreateTime() {
		return DateFormatter.reFormat(createTime, DateFormatter.DB2_TIMESTAMP, DateFormatter.MM_DD_YYYY_HH_MM_SS);

	}

	public String getFrmtLastUpdtTime() {
		return DateFormatter.reFormat(lastUpdtTime, DateFormatter.DB2_TIMESTAMP, DateFormatter.MM_DD_YYYY_HH_MM_SS);

	}
}
