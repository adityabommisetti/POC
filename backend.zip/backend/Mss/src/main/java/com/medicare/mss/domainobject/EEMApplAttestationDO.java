package com.medicare.mss.domainobject;

import lombok.Data;

@Data
public class EEMApplAttestationDO {
	private String applId;
	private String attestaionSeqNbr;
	private String attestDate;
	private String attestInd;
	private String customerId;
	//private String deleteInd;	
	private String logicalInd;
	
	
}
