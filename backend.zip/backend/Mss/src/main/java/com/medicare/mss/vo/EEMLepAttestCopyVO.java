package com.medicare.mss.vo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EEMLepAttestCopyVO {

	private String primaryId;
	private Integer totalPlepMonths;
	private String reqDateCov;
	List<EEMLepAttestCcfVO> lepAttestListReq;
	List<EEMLepPtnlUncovMthsVO> lepAttestListResp;

}
