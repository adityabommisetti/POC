package com.medicare.mss.domainobject;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMMbrCommentDO {

	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;

	@ColumnMapper(columnName = "MEMBER_ID", propertyName = "memberId")
	private String memberId;

	@ColumnMapper(columnName = "COMMENT_SEQ_NBR", propertyName = "commentSeqNbr")
	private int commentSeqNbr;

	@ColumnMapper(columnName = "MBR_COMMENTS", propertyName = "mbrComments")
	private String mbrComments;

	@ColumnMapper(columnName = "CREATE_TIME", propertyName = "createTime")
	private String createTime;

	@ColumnMapper(columnName = "CREATE_USERID", propertyName = "createUserId")
	private String createUserId;

}
