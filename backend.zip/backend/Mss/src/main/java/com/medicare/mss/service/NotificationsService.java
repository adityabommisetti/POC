package com.medicare.mss.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.NotificationsDAO;
import com.medicare.mss.domainobject.NotificationDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.security.vo.SecuserDetails;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateFormatter;
import com.medicare.mss.util.DateMath;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.vo.NotificationVO;

@Service
@Transactional(rollbackFor = ApplicationException.class)
public class NotificationsService {
	@Autowired
	private NotificationsDAO notificationsDao;

	@Autowired
	private CacheService cacheService;

	public List<NotificationVO> getNotifications() {
		String lastNotifTime = (String) cacheService.getAttribute("lastNotifTime");
		String pwdExpNotified = (String) cacheService.getAttribute("pwdExpNotified");
		Boolean expNotif = false;
		List<NotificationVO> notifList = new ArrayList<>();
		SecuserDetails secUserDetails = cacheService.getUserInfo();
		String customerId = secUserDetails.getCustomerId();
		String pwdExpDateStr = secUserDetails.getPwdExpireDate();
		String signOffTime = secUserDetails.getSignOffTime();
		NotificationVO notificationVO = null;

		try {
			if (StringUtils.isBlank(pwdExpNotified)) {
				Date pwdExpDate = DateUtil.parseDate(pwdExpDateStr, EEMConstants.DEFAULT_TIMESTAMP_FORMAT);
				String currentDateStr = DateUtil.getCurrentDatetimeStamp();
				Date currentDate = DateUtil.parseDate(currentDateStr, EEMConstants.DEFAULT_TIMESTAMP_FORMAT);
				int diff = DateMath.daysBetween(pwdExpDate, currentDate);

				if (diff <= EEMConstants.NOTIFY_BEFORE_PWD_EXPIRY) {
					expNotif = true;
					cacheService.setAttribute("pwdExpNotified", "true");
					notificationVO = new NotificationVO();
					notificationVO.setMsgTitle(EEMConstants.PASS_EXPIRY_NOTIFICATION);
					notificationVO.setMsgDesc(CommonUtils.appendStrings("Your password is expiring in ", String.valueOf(diff), " days, please change it"));
					notificationVO.setNotifTimeStamp(DateFormatter.reFormat(DateUtil.getCurrentDatetimeStamp(),
							DateFormatter.DB2_TIMESTAMP, DateFormatter.MM_DD_YYYY_HH_MM_SS).replace("-", "/"));

				}
			}
			List<NotificationDO> notifListDo = notificationsDao.getNotifications(customerId, lastNotifTime,
					signOffTime);
			if (notifListDo.size() > 0) {
				cacheService.setAttribute("lastNotifTime", notifListDo.get(0).getNotifTimeStamp());
			}
			CommonUtils.copyList(notifListDo, notifList, NotificationVO.class);

			if (expNotif)
				notifList.add(notificationVO);

		} catch (Exception exp) {
			throw new ApplicationException(exp, "Error occured while getNotifications!");
		}

		return notifList;
	}

	/*
	 * public boolean userLoggedInStatus() { Boolean status = null; try { String
	 * userId = sessionHelper.getUserInfo().getUserId(); status =
	 * notificationsDao.userLoggedInStatus(userId); } catch (Exception e) { status =
	 * false; } return status; }
	 */

}
