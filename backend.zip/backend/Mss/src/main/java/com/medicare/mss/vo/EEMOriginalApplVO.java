/**
 * 
 */
package com.medicare.mss.vo;

import lombok.Data;

/**
 * @author SUSDASH
 *
 */
@Data
public class EEMOriginalApplVO {
	
	private String abaRoutingNbr;
	private String accountType;
	private String altCorrespondenceInd;
    private String appDuplicateCheck;
	private String applCategory;
	private String applDate;
	private int applId;
	private String applStatus;
	private String applType;
	private String authRepFirstName;
	private String authRepLastName;
	private String authRepMidName;
	private String authRepRelation;
	private String bankAcctNbr;
	private String bankName;
	private String billFirstName;
	private String billFrequency;
	private String billLastName;
	private String billMiddleName;
	private String billSuffix;
	private String birthDt;
	private String cancelDt;
	private String cancelReason;
	private String compaignId;
	private String contractorNo;
	private String createTime;
	private String createUserId;
	private String currStatus;
	private String customerId;
	private String customerNbr;
	private String denialRcvDt;
	private String denialReasonCd;
	private String draftDay;
	private String editOverride;
	private String effectiveDate;
	private String eligibilitySrcTable;
	private String eligOverrideInd;
	private String email;
	private String emergName;
	private String emergPhone;
	private String emergRelation;
	private String enrollSrceCd;
	private String firstName;
	private String gender;
	private String healthPlanNews;
	private String hicNbr;
	private String insCardName;
	private String languageCd;
	private String lastName;
	/*private String lstUpdtTime;
	private String lstUpdtUserId;*/
	private String ltrReasonCd;
	private String mailFirstName;
	private String mailLastName;
	private String mailMiddleName;
	private String mailSuffix;
	private boolean mbdUpdateRequired;
	private String mbi;
	private String mbrApplNo;
	private String mbrEmail;
	private String mbrId;
	private String mbrSuffix;
	private String message;
	private String middleName;
	private String nameOnAct;
	private String ooaInd;
	private String prefix;
	private String pwOption;
	private String receiptDate;
	private String rxId;
	private String signDt;
	private String signOnFile;
	private String signOvrrdDt;
	private String ssn;
	private String subscriberId;
	private String supplmentId; 
    private String xrefNbr;
    //private String enrollPlanDesgn;
    //private String lastUpdtUserID;


    //Address details:
    
	private String authRepCity;
    private String authRepPhone;
    private String authRepState;
    private String authRepStreet;
    private String authRepZip4;
    private String authRepZip5;
    private String lstUpdtAuthAddr;
    private String lstUpdtMailAddr;
    private String lstUpdtPrimAddr;
    private String mailAdd1;
    private String mailAdd2;
    private String mailAdd3;
    private String mailCity;
    private String mailCountry;
    private String mailCounty;
    private String mailState;
    private String mailZip4;
    private String mailZip5;
    private String perAdd1;
    private String perAdd2;
    private String perAdd3;
    private String perCell;
    private String perCity;
    private String perCounty;
    private String perFax;
    private String perPhone;
    private String perState;   
    private String perWorkPhone;
	private String perZip4;
	private String perZip5;
	
	//Agent details:
	private String agentDt;
	private String agentType;
	private String brokAgentId;
	private String brokerType;
	private String commAgencyId;
	
	//Attestation details:
	
	private String attestaionSeqNbr;
	private String attestDate;
	private String attestInd;
	private String deleteInd;
	private String index;
	//Added  parameters which are not belongs to the table
	//Added  parameters which are not belongs to the table
	private String logicalDel;
	private String sepException;
	
	//Comment Details:
	
	private String commentSeqNbr;
	private String applComments;
	
	//Eligibility details:
	
	 private String  birthDate;
	 private String  calUncovMont;
	 private String  countyCd;
	 private String  deathDate;
	 private String  eligOverInd;
	 private String  eligSrc;
	 private String  enrollStatus;
	 private String  esrdEndDt;
	 //private String  esrdInd;
	 private String  esrdStartDt;
	 //private String  firstName;
	 private String  genderNumCd;
	 //private String  hicNbr;
	 private String  hospiceEndDt;
	 private String  hospiceInd;
	 private String  hospiceStartDt;
	 private String  instEndDt;
	 private String  institutionalInd;
	 private String  instStartDt;
	 private String  lastChkedTime;
	 //private String  lastName;
	 //private String  lastUpdtUserId;
	 private String  livingStatus;
	 private String  medicEndDt;
	 private String  medicInd;
	 private String  medicStartDt;
	 private String  middleInit;
	 private String  partAEffDate;
	 private String  partAEndDate;
	 private String  partAOption;
	 private String  partBEffDate;
	 private String  partBEndDate;
	 private String  partBOption;
	 private String  partDEffDate;
	 private String  raceCd;
	 private String  stateCd;
	 private String  wrkagedEndDt;
	 private String  wrkagedInd;
	 private String  wrkagedStartDt;

	 //LIS info:
	 private String  effEndDt;
	 private String  effStartDt;
	 private String  liCoPayCd;
	 private String  lisPctCd;
	 
	 //other cov details:
	 private String applicationId;
	 private String covBin;
	 private String covId;
	 private String covPcn;
	 private String dialysisInd;
	 private String drugCov = "N";
	 private String esrdInd;
	 private String groupNo;
	 
	 private String ltcFacAddress;
	 private String ltcFacId;
	 //Added two parameters which are not belongs to the table
	 private String ltcFacPhone;
	 private String ltcInstInd;
	 private String medicaidId;
	 private String medicaidInd;
	 private String othCovSeqNbr;
	 private String otherCov;
	 private String pcoInd;
	 private String secRxBin;
     private String secRxGrp;
     private String secRxId;
     private String secRxInd;
     private String secRxName;
	 private String secRxPcn;
	 private String spouseWorkInd;

	 //PCP Details:
	 private String  alternateOfficeCd;
	 private String currentPatientInd;
	 private String locationId;
	 private String nameInstitute;
	 private String officeCategoryCd;
	 private String officeCd;
	 private String pcpName;
	 private String premiumAmt;
	private String stMedicaid = "N";
	
	//Appl Plan details:
	private String[] currentPlan;
	private String currGrpId;
	private String currPaymentAmt;
	private String currPbpId;
	private String currPbpSegmentId;
	private String currPlanId;
	private String currProductId;
	private String eff_date;
	private String elcDerivedInd;
	private String electionDt;
	private String electionTypeCd; 
	private String enrollEndDate;
	private String enrollGroupName;
    private String enrollGrpId;
    private String enrollPaymentAmt;
    private String enrollPbpId;
    private String enrollPbpSegmentId;
    private String enrollPlanDesgn;
    private String enrollPlanId;
    private String enrollProdName;
	private String enrollProductId;
	private String enrollPymtAmt;
	//private String lastUpdtTime;
    private String reqDtCov;
    private String sepElectionDt;
    private String sepReasonCd;

		

}
