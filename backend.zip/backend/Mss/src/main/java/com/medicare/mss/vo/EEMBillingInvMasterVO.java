/**
 * 
 */
package com.medicare.mss.vo;

import java.io.Serializable;
import java.util.List;

import com.medicare.mss.security.vo.EEMBillingInvCommentVO;
import com.medicare.mss.util.LabelValuePair;

import lombok.Data;

/**
 * @author DU20098149
 *
 */
@Data
public class EEMBillingInvMasterVO implements Serializable {
	
	private static final long serialVersionUID = 6387944222740072422L;
	
	private EEMBillingInvSummaryVO billingInvSummary;
	private List<EEMBillingInvHeaderDtlsVO> billingInvHeaderDtlsVOs;
	private List<EEMBillingInvoiceDtlsVO> billingInvDetails;
	private List<EEMBillFuncVO> lstFunctionCode;
	private List<LabelValuePair> lstRefReasonCode;
	private List<EEMBillingInvCommentVO> commentList;
	private boolean nextPage;
}
