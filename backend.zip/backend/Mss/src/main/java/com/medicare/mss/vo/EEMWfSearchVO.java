package com.medicare.mss.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EEMWfSearchVO implements Serializable {

	private static final long serialVersionUID = 5968887026638250415L;

	private String applId;
	private String assignedToUser;
	private String caseId;
	private String mbrName;
	private String medicareId;
	private String memberId;
	private String caseDesc;
	private String caseStatus;
	private String supplementalId;
	private String riskInd;
	private String daysRemaining;

}
