package com.medicare.mss.daoImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.dao.EEMMbrAgentDAO;
import com.medicare.mss.domainobject.EmMbrAgentDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EMDatedSegmentVO;
import com.medicare.mss.vo.EmMbrAgentVO;

@Repository
public class EEMMbrAgentDAOImpl implements EEMMbrAgentDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<EmMbrAgentDO> getMbrAgents(String customerId, String memberId, String showAll, String lineOfBusiness) {

		try {
			String sqlOverride = " AND MA.OVERRIDE_IND = 'N'";
			if ("Y".equals(showAll))
				sqlOverride = "";

			StringBuilder sQuery = new StringBuilder(
					"SELECT MA.CUSTOMER_ID, MA.MEMBER_ID, MA.PLAN_ID, MA.EFF_START_DATE, MA.EFF_END_DATE, MA.OVERRIDE_IND,")
							.append(" MA.AGENT_ID, AT.AGENT_TYPE, AT.AGENT_TIN, AT.AGENT_NAME, AT.AGENT_PHONE, AT.AGENT_EMAIL,")
							.append(" MA.AGENCY_ID, AY.AGENCY_TYPE, AY.AGENCY_TIN, AY.AGENCY_NAME, AY.AGENCY_PHONE, AY.AGENCY_EMAIL,")
							.append(" MA.CREATE_TIME, MA.CREATE_USERID, MA.LAST_UPDT_TIME, MA.LAST_UPDT_USERID")
							.append(" FROM EM_MBR_AGENT MA JOIN EM_AGENCY_AGENT AA ON AA.CUSTOMER_ID = MA.CUSTOMER_ID")
							.append(" AND AA.AGENCY_ID = MA.AGENCY_ID AND AA.AGENT_ID = MA.AGENT_ID")
							.append(" AND MA.EFF_START_DATE BETWEEN AA.EFF_START_DATE AND AA.EFF_END_DATE JOIN EM_AGENCY AY")
							.append(" ON AY.CUSTOMER_ID = AA.CUSTOMER_ID AND AY.AGENCY_ID = AA.AGENCY_ID JOIN EM_AGENT AT")
							.append(" ON AT.CUSTOMER_ID = AA.CUSTOMER_ID AND AT.AGENT_ID = AA.AGENT_ID")
							.append(" AND AT.AGENT_TYPE = AA.AGENT_TYPE WHERE MA.CUSTOMER_ID = ? AND MA.MEMBER_ID = ? ")
							.append(sqlOverride)
							.append(" AND AA.LINE_OF_BIZ IN ('',?)")
							.append(" ORDER BY MA.EFF_START_DATE DESC, MA.EFF_END_DATE DESC, MA.PLAN_ID, MA.AGENCY_ID, MA.AGENT_ID");

			return jdbcTemplate.query(sQuery.toString(), new DomainPropertyRowMapper<EmMbrAgentDO>(EmMbrAgentDO.class),
					customerId, memberId, lineOfBusiness);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}

	}

	@Override
	public int setMbrAgentOverride(EmMbrAgentDO mbrAgent, String userId) {

		String currentTime = DateUtil.getCurrentDatetimeStamp();

		Object[] parms = new Object[] { currentTime, userId, StringUtil.nonNullTrim(mbrAgent.getCustomerId()),
				StringUtil.nonNullTrim(mbrAgent.getMemberId()), StringUtil.nonNullTrim(mbrAgent.getAgentId()),
				StringUtil.nonNullTrim(mbrAgent.getAgencyId()), StringUtil.nonNullTrim(mbrAgent.getPlanId()),
				StringUtil.nonNullTrim(mbrAgent.getEffStartDate()), StringUtil.nonNullTrim(mbrAgent.getCreateTime()),
				StringUtil.nonNullTrim(mbrAgent.getLastUpdtTime()) };

		StringBuilder sQuery = new StringBuilder("UPDATE EM_MBR_AGENT")
				.append(" SET OVERRIDE_IND = 'Y', LAST_UPDT_TIME = ?").append(", LAST_UPDT_USERID = ?")
				.append(" WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? AND AGENT_ID = ? AND AGENCY_ID = ? AND PLAN_ID = ?")
				.append(" AND EFF_START_DATE = ? AND CREATE_TIME = ? AND OVERRIDE_IND = 'N' AND LAST_UPDT_TIME = ?");
		try {
			return jdbcTemplate.update(sQuery.toString(), parms);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}
	}

	@Override
	public boolean getActiveAgent(EmMbrAgentDO agentDO) {

		try {

			StringBuilder sQuery = new StringBuilder(
					"SELECT AGENT_ID FROM EM_AGENCY_AGENT WHERE AGENT_ID = ? AND AGENCY_ID = ? AND CUSTOMER_ID = ? ")
							.append(" AND ? BETWEEN EFF_START_DATE AND EFF_END_DATE FETCH FIRST ROW ONLY");

			jdbcTemplate.queryForObject(sQuery.toString(), new Object[] { StringUtil.nonNullTrim(agentDO.getAgentId()),
					StringUtil.nonNullTrim(agentDO.getAgencyId()), StringUtil.nonNullTrim(agentDO.getCustomerId()),
					StringUtil.nonNullTrim(agentDO.getEffStartDate()) }, String.class);

		} catch (EmptyResultDataAccessException exp) {
			return false;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
		return true;
	}

	@Override
	public int checkInvalidAgent(EmMbrAgentDO agentDO) {
		int flag = 0;
		try {

			StringBuilder sQuery = new StringBuilder("SELECT AGENT_ID FROM EM_AGENCY_AGENT WHERE AGENT_ID = ? ")
					.append(" AND CUSTOMER_ID = ? AND ? BETWEEN EFF_START_DATE AND EFF_END_DATE FETCH FIRST ROW ONLY");

			jdbcTemplate.queryForObject(sQuery.toString(),
					new Object[] { StringUtil.nonNullTrim(agentDO.getAgentId()),
							StringUtil.nonNullTrim(agentDO.getCustomerId()),
							StringUtil.nonNullTrim(agentDO.getEffStartDate()) },
					String.class);

		} catch (EmptyResultDataAccessException exp) {
			return flag;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}

		flag += 1;
		return flag;
	}

	@Override
	public int checkInvalidAgency(EmMbrAgentDO agentDO) {
		int flag = 0;
		try {

			StringBuilder sQuery = new StringBuilder(" SELECT AGENCY_ID FROM EM_AGENCY_AGENT WHERE AGENCY_ID = ? ")
					.append(" AND CUSTOMER_ID = ? AND ? BETWEEN EFF_START_DATE AND EFF_END_DATE FETCH FIRST ROW ONLY");

			jdbcTemplate.queryForObject(sQuery.toString(),
					new Object[] { StringUtil.nonNullTrim(agentDO.getAgencyId()),
							StringUtil.nonNullTrim(agentDO.getCustomerId()),
							StringUtil.nonNullTrim(agentDO.getEffStartDate()) },
					String.class);

		} catch (EmptyResultDataAccessException exp) {
			return flag;
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_RETRIEVAL);
		}
		flag += 1;
		return flag;
	}

	@Override
	public int insertMbrAgent(EmMbrAgentDO mbrAgent) {

		Object[] parms = new Object[] { StringUtil.nonNullTrim(mbrAgent.getCustomerId()),
				StringUtil.nonNullTrim(mbrAgent.getMemberId()), StringUtil.nonNullTrim(mbrAgent.getAgentId()),
				StringUtil.nonNullTrim(mbrAgent.getAgencyId()), StringUtil.nonNullTrim(mbrAgent.getPlanId()),
				StringUtil.nonNullTrim(mbrAgent.getEffStartDate()), StringUtil.nonNullTrim(mbrAgent.getEffEndDate()),
				StringUtil.nonNullTrim(mbrAgent.getOverrideInd()), StringUtil.nonNullTrim(mbrAgent.getCreateTime()),
				StringUtil.nonNullTrim(mbrAgent.getCreateUserId()), StringUtil.nonNullTrim(mbrAgent.getLastUpdtTime()),
				StringUtil.nonNullTrim(mbrAgent.getLastUpdtUserId()) };

		StringBuilder sQuery = new StringBuilder(
				"INSERT INTO EM_MBR_AGENT(CUSTOMER_ID, MEMBER_ID, AGENT_ID, AGENCY_ID, PLAN_ID, ")
						.append("EFF_START_DATE, EFF_END_DATE, OVERRIDE_IND, ")
						.append("CREATE_TIME, CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID) VALUES(?,?,?,?,?,")
						.append("?,?,?,?,?,?,?)");

		try {
			return jdbcTemplate.update(sQuery.toString(), parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_INSERT);
		}
	}

	public int setMbrAgentOverride(EmMbrAgentVO mbrAgent, String userId) {

		String currentTime = DateUtil.getCurrentDatetimeStamp();

		Object[] parms = new Object[] { currentTime, userId, mbrAgent.getCustomerId(),
				StringUtil.nonNullTrim(mbrAgent.getMemberId()), StringUtil.nonNullTrim(mbrAgent.getAgentId()),
				StringUtil.nonNullTrim(mbrAgent.getAgencyId()), StringUtil.nonNullTrim(mbrAgent.getPlanId()),
				StringUtil.nonNullTrim(mbrAgent.getEffStartDate()), StringUtil.nonNullTrim(mbrAgent.getCreateTime()),
				StringUtil.nonNullTrim(mbrAgent.getLastUpdtTime()) };

		StringBuilder sQuery = new StringBuilder("UPDATE EM_MBR_AGENT")
				.append(" SET OVERRIDE_IND = 'Y', LAST_UPDT_TIME = ?").append(" , LAST_UPDT_USERID = ?")
				.append(" WHERE CUSTOMER_ID = ? AND MEMBER_ID = ? AND AGENT_ID = ? AND AGENCY_ID = ? AND PLAN_ID = ?")
				.append(" AND EFF_START_DATE = ? AND CREATE_TIME = ? AND OVERRIDE_IND = 'N' AND LAST_UPDT_TIME = ?");
		try {
			return jdbcTemplate.update(sQuery.toString(), parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_UPDATE);
		}
	}

	public int insertMbrAgent(EmMbrAgentVO mbrAgent) {

		Object[] parms = new Object[] { mbrAgent.getCustomerId(), StringUtil.nonNullTrim(mbrAgent.getMemberId()),
				StringUtil.nonNullTrim(mbrAgent.getAgentId()), StringUtil.nonNullTrim(mbrAgent.getAgencyId()),
				StringUtil.nonNullTrim(mbrAgent.getPlanId()), StringUtil.nonNullTrim(mbrAgent.getEffStartDate()),
				StringUtil.nonNullTrim(mbrAgent.getEffEndDate()), StringUtil.nonNullTrim(mbrAgent.getOverrideInd()),
				StringUtil.nonNullTrim(mbrAgent.getCreateTime()), StringUtil.nonNullTrim(mbrAgent.getCreateUserId()),
				StringUtil.nonNullTrim(mbrAgent.getLastUpdtTime()),
				StringUtil.nonNullTrim(mbrAgent.getLastUpdtUserId()) };

		StringBuilder sQuery = new StringBuilder(
				"INSERT INTO EM_MBR_AGENT(CUSTOMER_ID, MEMBER_ID, AGENT_ID, AGENCY_ID, PLAN_ID, ")
						.append("EFF_START_DATE, EFF_END_DATE, OVERRIDE_IND, ")
						.append("CREATE_TIME, CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID) VALUES(?,?,?,?,?,")
						.append("?,?,?,?,?,?,?)");
		try {
			return jdbcTemplate.update(sQuery.toString(), parms);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.ERROR_INSERT);
		}

	}

	@Override
	public int setOverride(EMDatedSegmentVO emDatedSegmentVO, String userId) {
		return setMbrAgentOverride((EmMbrAgentVO) emDatedSegmentVO, userId);
	}

	@Override
	public int insertMbr(EMDatedSegmentVO emDatedSegmentVO) {
		return insertMbrAgent((EmMbrAgentVO) emDatedSegmentVO);
	}

}
