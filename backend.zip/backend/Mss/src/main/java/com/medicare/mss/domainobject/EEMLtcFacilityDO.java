package com.medicare.mss.domainobject;

import java.io.Serializable;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class EEMLtcFacilityDO implements Serializable {

	private static final long serialVersionUID = -6823311268460707415L;

	@ColumnMapper(columnName = "CUSTOMER_ID", propertyName = "customerId")
	private String customerId;

	@ColumnMapper(columnName = "LTC_FAC_ID", propertyName = "nameInstitute")
	private String nameInstitute;

	@ColumnMapper(columnName = "LTC_FAC_NAME", propertyName = "nameInstituteDes")
	private String nameInstituteDes;

	@ColumnMapper(columnName = "EFFECTIVE_DATE", propertyName = "effStartDate")
	private String effStartDate;

	@ColumnMapper(columnName = "EFF_END_DATE", propertyName = "effEndDate")
	private String effEndDate;

	@ColumnMapper(columnName = "LTC_FAC_PHONE", propertyName = "ltcFacilityPhone")
	private String ltcFacilityPhone;

	@ColumnMapper(columnName = "LTC_FAC_ADDRESS", propertyName = "ltcFacilityAddress")
	private String ltcFacilityAddress;

	@ColumnMapper(columnName = "CREATE_TIME", propertyName = "createTime")
	private String createTime;

	@ColumnMapper(columnName = "CREATE_USERID", propertyName = "createUserId")
	private String createUserId;

	@ColumnMapper(columnName = "LAST_UPDT_TIME", propertyName = "lastUpdtTime")
	private String lastUpdtTime;

	@ColumnMapper(columnName = "LAST_UPDT_USERID", propertyName = "lastUpdtUserId")
	private String lastUpdtUserId;

	@ColumnMapper(columnName = "LTC_FAC_CITY", propertyName = "ltcFacilityCity")
	private String ltcFacilityCity;

	@ColumnMapper(columnName = "LTC_FAC_STATE", propertyName = "ltcFacilityState")
	private String ltcFacilityState;

	@ColumnMapper(columnName = "LTC_FAC_ZIPCODE", propertyName = "ltcFacilityZipCode")
	private String ltcFacilityZipCode;

}
