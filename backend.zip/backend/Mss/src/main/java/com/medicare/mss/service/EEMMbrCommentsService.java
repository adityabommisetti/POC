package com.medicare.mss.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.medicare.mss.dao.MemberCommentsDAO;
import com.medicare.mss.domainobject.EEMMbrCommentDO;
import com.medicare.mss.domainobject.EEMMbrTrrDataDO;
import com.medicare.mss.domainobject.EEMMbrTrrLogDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.CacheService;
import com.medicare.mss.helper.EEMContext;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.vo.EEMMbrCommentVO;
import com.medicare.mss.vo.EEMMbrTrrDataVO;
import com.medicare.mss.vo.EEMMbrTrrLogVO;

@Service
public class EEMMbrCommentsService {

	@Autowired
	private MemberCommentsDAO memberCommentsDAO;

	@Autowired
	CacheService sessionHelper;

	@Transactional(readOnly = true)
	public List<EEMMbrCommentVO> getMbrCommentList(String memberId) {

		List<EEMMbrCommentVO> mbrCommentList = sessionHelper.getEEMContext().getMbrMasterVO().getMbrCommentList();
		if (CollectionUtils.isEmpty(mbrCommentList)) {
			mbrCommentList = getMbrCommentListDB(memberId);
			setToContext(mbrCommentList);
		}
		return mbrCommentList;
	}

	public List<EEMMbrCommentVO> getMbrCommentListDB(String memberId) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		List<EEMMbrCommentVO> emMbrCommentsVOList = new ArrayList<>();

		List<EEMMbrCommentDO> mbrCommentsList = memberCommentsDAO.getMbrComments(customerId, memberId);
		mbrCommentsList.forEach(mbrComments -> {
			EEMMbrCommentVO emMbrCommentVO = new EEMMbrCommentVO();
			BeanUtils.copyProperties(mbrComments, emMbrCommentVO);
			emMbrCommentsVOList.add(emMbrCommentVO);
		});
		return emMbrCommentsVOList;
	}

	@Transactional(rollbackFor = ApplicationException.class)
	public String addMbrComments(EEMMbrCommentVO mbrCommentsVo) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		List<EEMMbrCommentDO> mbrCommentsDOList = new ArrayList<>();
		mbrCommentsVo.setCustomerId(customerId);

		boolean rslt = memberCommentsDAO.getNextMbrComment(mbrCommentsVo);
		if (rslt) {
			int emMbrCommentDo = memberCommentsDAO.addMbrComments(mbrCommentsVo);

			if ("NEW".equalsIgnoreCase(mbrCommentsVo.getCreateUserId())) {
				BeanUtils.copyProperties(mbrCommentsVo, emMbrCommentDo);
			} else {
				EEMMbrCommentDO tempCommentsDo = new EEMMbrCommentDO();
				BeanUtils.copyProperties(mbrCommentsVo, tempCommentsDo);
				mbrCommentsDOList.add(tempCommentsDo);
			}
			return "SUCCESS";
		}
		return "SUCCESS";
	}

	public List<EEMMbrTrrLogVO> getMbrTrrList(String memberId) {

		List<EEMMbrTrrLogVO> mbrTrrList = sessionHelper.getEEMContext().getMbrMasterVO().getMbrTrrList();
		if (CollectionUtils.isEmpty(mbrTrrList)) {
			mbrTrrList = getMbrTrrListDB(memberId);
			setToContext1(mbrTrrList);
		}
		return mbrTrrList;
	}

	public List<EEMMbrTrrLogVO> getMbrTrrListDB(String memberId) {

		String customerId = sessionHelper.getUserInfo().getCustomerId();
		List<EEMMbrTrrLogVO> mbrTrrVOList = new ArrayList<>();
		try {
			List<EEMMbrTrrLogDO> mbrTrrList = memberCommentsDAO.getMbrTrr(customerId, memberId);
			mbrTrrList.forEach(mbrTrr -> {
				EEMMbrTrrLogVO emMbrTrr = new EEMMbrTrrLogVO();
				BeanUtils.copyProperties(mbrTrr, emMbrTrr);
				mbrTrrVOList.add(emMbrTrr);
			});
		} catch (Exception exp) {
			throw new ApplicationException(exp);
		}
		return mbrTrrVOList;
	}

	public List<EEMMbrTrrDataVO> getMbrTrrDataList(String memberId, String logTime) {
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		List<EEMMbrTrrDataDO> mbrTrrDataListDO = memberCommentsDAO.getMbrTrrData(customerId, memberId, logTime);
		List<EEMMbrTrrDataVO> mbrTrrDataListVO = new ArrayList<>();
		CommonUtils.copyList(mbrTrrDataListDO, mbrTrrDataListVO, EEMMbrTrrDataVO.class);
		return mbrTrrDataListVO;
	}

	private void setToContext(List<EEMMbrCommentVO> mbrCommentList) {
		EEMContext context = sessionHelper.getEEMContext();
		context.getMbrMasterVO().setMbrCommentList(mbrCommentList);
		sessionHelper.setEEMContext(context);
	}

	private void setToContext1(List<EEMMbrTrrLogVO> mbrTrrList) {
		EEMContext context = sessionHelper.getEEMContext();
		context.getMbrMasterVO().setMbrTrrList(mbrTrrList);
		sessionHelper.setEEMContext(context);
	}

}
