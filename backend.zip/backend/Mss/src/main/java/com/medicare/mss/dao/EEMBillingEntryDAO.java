package com.medicare.mss.dao;

import java.util.List;

import com.medicare.mss.domainobject.EEMBilPaymentEntryDtlsDO;
import com.medicare.mss.domainobject.EEMBilPaymentEntryInvDO;
import com.medicare.mss.vo.EEMBilPaymentEntryDtlsVO;
import com.medicare.mss.vo.EEMBilPaymentEntryNewVO;
import com.medicare.mss.vo.EEMBilPaymentEntryVO;
import com.medicare.mss.vo.PageableVO;

public interface EEMBillingEntryDAO {

	PageableVO billPaymentEntrySearch(EEMBilPaymentEntryVO paymentEntrySearchVo, boolean isPagination);

	List<EEMBilPaymentEntryDtlsDO> billPaymentEntryDetails(EEMBilPaymentEntryVO eemBilPaymntEntryVo);


	void billPaymentEntryAdd(EEMBilPaymentEntryVO paymntEntryHeader);

	void billPaymentEntryAddDetails(EEMBilPaymentEntryNewVO bilPaymntEntryNewVo);

	Integer getBatchSeqNum(EEMBilPaymentEntryVO billHeader);

	void billPaymentEntryHeaderUpdate(EEMBilPaymentEntryVO paymentHeader);

	Boolean memberIdValidate(String memberId, String customerId);

	List<EEMBilPaymentEntryInvDO> getBilEntryInvDetails(EEMBilPaymentEntryVO eemBilPaymntEntryVo);

	void paymentEntryHeaderBatchBalUpdate(EEMBilPaymentEntryVO bilPaymntsEntryVo);

	boolean checkInvoiceId(String memberId, String customerId);

	EEMBilPaymentEntryVO billPaymentEntryDetailsUpdate(EEMBilPaymentEntryDtlsVO bilPaymntsEntryDtlsVo,EEMBilPaymentEntryVO bilPaymentEntryVO);

}
