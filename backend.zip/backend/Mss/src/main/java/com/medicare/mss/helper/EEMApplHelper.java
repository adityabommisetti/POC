package com.medicare.mss.helper;

import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.lang.reflect.Field;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.caching.EEMPersistence;
import com.medicare.mss.constants.EEMConstants;
import com.medicare.mss.domainobject.EEMApplTriggerDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.vo.ApplCacheVO;
import com.medicare.mss.vo.EEMApplMasterVO;

@Component
public class EEMApplHelper {

	@Autowired
	private EEMPersistence eemPer;

	@Autowired
	private EEMCodeCache codecahe;

	@Autowired
	private CacheService sessionHelper;

	public ApplCacheVO setApplFormList(String customerId, CacheService sessionHelper) {

		ApplCacheVO applCacheVO = new ApplCacheVO();
		applCacheVO.setLstApplType(eemPer.getLstApplType());
		applCacheVO.setLstPrefix(eemPer.getLstPrefix());
		applCacheVO.setLstStates(eemPer.getLstStates());
		applCacheVO.setLstCountry(eemPer.getLstCountry());
		applCacheVO.setLstLanguages(eemPer.getLstLanguages());
		applCacheVO.setLstAltCorrespondences(eemPer.getLstAltCorrespondences());
		applCacheVO.setLstPWOptions(eemPer.getLstPWOptions());
		applCacheVO.setLstElectionTypes(eemPer.getLstElectionTypes());
		applCacheVO.setLstSepExceptions(eemPer.getLstSepExceptions());
		applCacheVO.setLstRelations(eemPer.getLstRelations());
		applCacheVO.setLstAgentTypes(eemPer.getLstAgentTypes());
		applCacheVO.setLstAgencyTypes(eemPer.getLstAgencyTypes());
		applCacheVO.setLstEnrollSrce(codecahe.getEnrollSrceListForPlan(EEMConstants.MBR_SRCE_APPL));
		applCacheVO.setLstPCO(eemPer.getLstPCO());
		applCacheVO.setLstSepReasons(eemPer.getLstSEPReasons());
		applCacheVO.setLstApplStatus(eemPer.getLstApplStatus());

		applCacheVO.setLstApplCategory(codecahe.getLstApplCategory(customerId));
		applCacheVO.setReasonList(codecahe.getRejectReasonList(customerId));
		applCacheVO.setPreSetNoteList(codecahe.getPreSetNotesList(customerId));
		applCacheVO.setOevCallStatusDrop(codecahe.getLstOevCallStatus(customerId));
		applCacheVO.setOevCallSubReasonDrop(codecahe.getLstOevCallSubsetReason(customerId));

		applCacheVO.setValidStatus(eemPer.getLstAttestStatus());
		applCacheVO.setLepNunCmoStstus(eemPer.getLstLepNunCmoStatus());
		boolean isEEMSupervisor = sessionHelper.isEEMSupervisor();
		if (isEEMSupervisor) {
			applCacheVO.setLstUsrApplStatus(eemPer.getLstMgrApplStatus());
		} else {
			applCacheVO.setLstUsrApplStatus(eemPer.getLstUserApplStatus());
		}
		applCacheVO.setLstGender(eemPer.getLstGender());
		applCacheVO.setElectionDesc(codecahe.getListValueLabel("", eemPer.getLstElectionTypes()));
		applCacheVO.setApplDenialReasons(codecahe.getLstApplDenialReasons(customerId));
		applCacheVO.setLstAccountType(eemPer.getLstAccountType());
		applCacheVO.setLstBillPayMethod(eemPer.getLstBillPayMethod());
		applCacheVO.setLstBillFrequency(eemPer.getLstBillFrequency());
		applCacheVO.setValidLiPercents(eemPer.getLstLiPercents());
		applCacheVO.setValidLiCopays(eemPer.getLstLiCopays());
		applCacheVO.setRecvdChannel(eemPer.getChannelList());
		applCacheVO.setArrYesNo(eemPer.getArrYesNo());

		return applCacheVO;
	}

	public static void convertToUpper(ApplCacheVO applMasterVO) {

		try {
			Class<?> objClass = Class.forName(EEMConstants.EEM_APPLFORM_CLASS);

			Field[] arrField = objClass.getDeclaredFields();
			for (int i = 0; i < arrField.length; i++) {
				Field field = arrField[i];
				field.setAccessible(true);
				if (field.getType().toString().equals("class java.lang.String")) {
					Object val = field.get(applMasterVO);
					if (val != null) {
						field.set(applMasterVO, trimToEmpty(val.toString()).toUpperCase());
					}
				}
			}
		} catch (Exception exp) {
			throw new ApplicationException(exp);
		}
	}

	public void setApplicationStatus(EEMApplMasterVO applMasterVO, boolean isEEMSupervisor) {
		String currStatus = trimToEmpty(applMasterVO.getApplVO().getCurrStatus());

		if (!currStatus.isEmpty()) {
			List<LabelValuePair> lstStatus = null;
			if (isEEMSupervisor) {
				lstStatus = eemPer.getLstMgrApplStatus();
			} else {
				lstStatus = eemPer.getLstUserApplStatus();
			}
			boolean found = false;
			for (int i = 0; i < lstStatus.size(); i++) {
				LabelValuePair nvp = (LabelValuePair) lstStatus.get(i);
				if (currStatus.equals(nvp.getValue())) {
					found = true;
					applMasterVO.getApplVO().setApplStatus(currStatus);
					break;
				}
			}
			if (!found)
				applMasterVO.getApplVO().setApplStatus("READY");
		}
	}

	public boolean isIncomplete(EEMApplMasterVO applMasterVO) {

		String applStatus = trimToEmpty(applMasterVO.getApplVO().getApplStatus());
		if (applStatus.equals(EEMConstants.APPL_STATUS_DENIEDELG)
				|| applStatus.equals(EEMConstants.APPL_STATUS_DENIEDETYP)
				|| applStatus.equals(EEMConstants.APPL_STATUS_DENIEDOTHR)) {
			return false;
		}

		if ((applMasterVO.getApplVO().getCurrStatus().equals(EEMConstants.APPL_STATUS_READY)
				|| applMasterVO.getApplVO().getCurrStatus().equals(EEMConstants.APPL_STATUS_INCOMPLETE))
				&& applMasterVO.getApplVO().getApplStatus().equals(EEMConstants.APPL_STATUS_INCOMPLETE)) {
			return true;
		}
		if (trimToEmpty(applMasterVO.getApplVO().getMbrHicNbr()).isEmpty()
				|| trimToEmpty(applMasterVO.getApplVO().getMbrLastName()).isEmpty()
				|| trimToEmpty(applMasterVO.getApplVO().getMbrFirstName()).isEmpty()
				|| trimToEmpty(applMasterVO.getApplPlanVO().getReqDtCov()).isEmpty()
				|| trimToEmpty(applMasterVO.getApplPlanVO().getEnrollProduct()).isEmpty()
				|| trimToEmpty(applMasterVO.getApplAddress().getPerAdd1()).isEmpty()
				|| trimToEmpty(applMasterVO.getApplAddress().getPerCity()).isEmpty()
				|| trimToEmpty(applMasterVO.getApplAddress().getPerState()).isEmpty()
				|| trimToEmpty(applMasterVO.getApplAddress().getPerZip5()).isEmpty()) {

			applMasterVO.getApplVO().setApplStatus(EEMConstants.APPL_STATUS_INCOMPLETE);
			return true;
		}
		return false;
	}
	
	
	public EEMApplTriggerDO prepareApplTriggerDO( String applId,String triggerType,String triggerStatus,String triggerCode,String effDateFrmt) {
		String ts = DateUtil.getCurrentDatetimeStamp();
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();

		EEMApplTriggerDO trig = new EEMApplTriggerDO();
		trig.setCustomerId(customerId);
		trig.setApplicationId(applId);
		trig.setTriggerType(triggerType);
		trig.setEffectiveDate(effDateFrmt);
		trig.setTriggerStatus(triggerStatus);
		trig.setTriggerCode(triggerCode);
		trig.setCreateUserid(userId);
		trig.setCreateTime(ts);
		trig.setLastUpdtUserid(userId);
		trig.setLastUpdtTime(ts);
		return trig;
	}

}
