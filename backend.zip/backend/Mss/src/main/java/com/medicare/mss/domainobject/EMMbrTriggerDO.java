package com.medicare.mss.domainobject;

import com.medicare.mss.vo.BaseVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class EMMbrTriggerDO extends BaseVO {
	
	private static final long serialVersionUID = 8818889346306968702L;
	private String memberId;
	private String primaryId;
	private String triggerType;
	private String effectiveDate;
	private String triggerCode;
	private String planId;
	private String pbpId;
	private String mbrFName;
	private String mbrLName;
	private String planDesignation;
	private String triggerStatus;
	private String processSource;
	private String origTriggerType;
	private String origTriggerCode;
	private String origEffectiveDate;
	private String origTriggerCreateTime;
	private String fileBatchId;
	private String letterName;
	private String recordType;
}
