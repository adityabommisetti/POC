package com.medicare.mss.daoImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.dao.EEMMbrAddressDAO;
import com.medicare.mss.domainobject.EEMMbrAddressDO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.rowmappers.DomainPropertyRowMapper;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateUtil;
import com.medicare.mss.util.StringUtil;
import com.medicare.mss.vo.EMDatedSegmentVO;

@Repository
public class EEMMbrAddressDAOImpl implements EEMMbrAddressDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private EEMCodeCache codeCache;

	@Override
	public int setOverride(EMDatedSegmentVO emDatedSegmentVO, String userId) throws ApplicationException {

		String timeStamp = DateUtil.getCurrentDatetimeStamp();
		EEMMbrAddressDO mbrAddr = (EEMMbrAddressDO) emDatedSegmentVO;
		try {
			String sql = CommonUtils.buildQuery("UPDATE EM_MBR_ADDRESS",
					" SET OVERRIDE_IND = 'Y', LAST_UPDT_TIME = ?, LAST_UPDT_USERID = ?",
					" WHERE CUSTOMER_ID = ? AND MEMBER_ID = ?",
					" AND ADDRESS_TYPE = ? AND EFF_START_DATE = ? AND CREATE_TIME = ?",
					" AND OVERRIDE_IND = 'N' AND LAST_UPDT_TIME = ?");

			return jdbcTemplate.update(sql,
					 timeStamp, userId, mbrAddr.getCustomerId(), mbrAddr.getMemberId(),
							mbrAddr.getAddressType(), mbrAddr.getEffStartDate(), mbrAddr.getCreateTime(),
							mbrAddr.getLastUpdtTime());
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error in Address setOverride");
		}
	}

	@Override
	public int insertMbr(EMDatedSegmentVO emDatedSegmentVO) throws ApplicationException {

		try {
			EEMMbrAddressDO mbrAddr = (EEMMbrAddressDO) emDatedSegmentVO;
			String cityName = mbrAddr.getCity();
			String sql = CommonUtils.buildQuery("INSERT INTO EM_MBR_ADDRESS(",
					"CUSTOMER_ID, MEMBER_ID, ADDRESS_TYPE, EFF_START_DATE, CREATE_TIME,", "EFF_END_DATE, OVERRIDE_IND,",
					"ADDRESS1, ADDRESS2, ADDRESS3, CITY, STATE_CD, ZIP_CD,", "COUNTY_CD, COUNTRY_CD,",
					"HOME_PHONE_NBR, WORK_PHONE_NBR, CELL_PHONE_NBR, FAX_NBR,",
					"CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID) VALUES(?,?,?,?,?,?,?,?,?,?,",
					"?,?,?,?,?,?,?,?,?,?,?,?)");

			String stAbbr = StringUtil.nonNullTrim(codeCache.getStateAbbr(mbrAddr.getStateCd()));

			if (null != cityName && StringUtil.nonNullTrim(cityName).length() > 20)
				cityName = cityName.substring(0, 20);

			Object[] parms = new Object[] { mbrAddr.getCustomerId(), mbrAddr.getMemberId(), mbrAddr.getAddressType(),
					mbrAddr.getEffStartDate(), mbrAddr.getCreateTime(), mbrAddr.getEffEndDate(),
					mbrAddr.getOverrideInd(), mbrAddr.getAddress1(), mbrAddr.getAddress2(), mbrAddr.getAddress3(),
					cityName, stAbbr, mbrAddr.getZipCd(), mbrAddr.getCountyCd(), mbrAddr.getCountryCd(),
					mbrAddr.getHomePhoneNbr(), mbrAddr.getWorkPhoneNbr(), mbrAddr.getCellPhoneNbr(),
					mbrAddr.getFaxNbr(), mbrAddr.getCreateUserId(), mbrAddr.getLastUpdtTime(),
					mbrAddr.getLastUpdtUserId() };

			return jdbcTemplate.update(sql, parms);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error in Address insertMbr");
		}
	}

	@Override
	public List<EEMMbrAddressDO> getMbrAddresses(String customerId, String memberId, String showAll)
			throws ApplicationException {
		try {
			String sqlOverride = " AND OVERRIDE_IND = 'N'";
			if ("Y".equals(showAll)) {
				sqlOverride = "";
			}

			String sql = CommonUtils.buildQuery(
					"SELECT CUSTOMER_ID, MEMBER_ID, ADDRESS_TYPE, EFF_START_DATE, CREATE_TIME,",
					" EFF_END_DATE, OVERRIDE_IND,", " ADDRESS1, ADDRESS2, ADDRESS3, CITY, STATE_CD, ZIP_CD,",
					" COUNTY_CD, COUNTRY_CD,", " HOME_PHONE_NBR, WORK_PHONE_NBR, CELL_PHONE_NBR, FAX_NBR,",
					" CREATE_USERID, LAST_UPDT_TIME, LAST_UPDT_USERID", " FROM EM_MBR_ADDRESS",
					" WHERE CUSTOMER_ID = ? AND MEMBER_ID = ?", sqlOverride,
					" ORDER BY ADDRESS_TYPE, EFF_START_DATE DESC, EFF_END_DATE DESC");

			return jdbcTemplate.query(sql, new DomainPropertyRowMapper<EEMMbrAddressDO>(EEMMbrAddressDO.class),
					customerId, memberId );

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error in Address getMbrAddresses");
		}
	}

}
