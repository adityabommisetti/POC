package com.medicare.mss.dao;

import java.util.List;

import com.medicare.mss.domainobject.EEMMbrCommentDO;
import com.medicare.mss.domainobject.EEMMbrTrrDataDO;
import com.medicare.mss.domainobject.EEMMbrTrrLogDO;
import com.medicare.mss.vo.EEMMbrCommentVO;

public interface MemberCommentsDAO {

	List<EEMMbrCommentDO> getMbrComments(String customerId, String memberId);

	boolean getNextMbrComment(EEMMbrCommentVO mbrCommentsVo);

	int addMbrComments(EEMMbrCommentVO mbrCommentsVo);

	List<EEMMbrTrrLogDO> getMbrTrr(String customerId, String memberId);

	List<EEMMbrTrrDataDO> getMbrTrrData(String customerId, String memberId, String logTime);

}
