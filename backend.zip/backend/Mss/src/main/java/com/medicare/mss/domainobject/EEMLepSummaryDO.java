package com.medicare.mss.domainobject;

import java.util.List;

import lombok.Data;

@Data
public class EEMLepSummaryDO {

	private String partAEntitleSDate;
	private String partAEntitleEDate;
	private String partBEntitleSDate;
	private String partBEntitleEDate;
	private String partDEntitleSDate;
	private String subsidySDate1;
	private String subsidyEDate1;
	private String subsidySDate2;
	private String subsidyEDate2;

	/**
	 * rdsList holds rdsList
	 */
	private List<LepHistory> rdsList;
	/**
	 * partDList holds partDList
	 */
	private List<LepHistory> partDList;
	/**
	 * nunCMOList holds nunCMOList
	 */
	private List<MBDNunCmoDO> nunCMOList;

	/**
	 * customerId holds customerId
	 */
	private String customerId;
	/**
	 * applId holds applId
	 */
	private String applId;
	/**
	 * hicNBRVal holds hicNBRVal
	 */
	private String hicNBRVal;

	private String copayLEVELID1;
	private String prtdPREMSUBSPCT1;
	private String copayLEVELID2;
	private String prtdPREMSUBSPCT2;
	private String mbrBirthDt;
	private String mbr65BirthDt;
	private String eligibilitySrcTable;

}
