package com.medicare.mss.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EEMLetterUploadFormVO {

	private String customerId;
	private String memberId;
	private String userId;
	private String fileName;
	private byte[] file;
	private String recordType;
	private String fileBatchId;

	private String printRequestDate;
	private String origMailDate;
	private String lastMailDate;
	private String printDate;
	private String reprintDate;
	private String responseDueDate;
	private String responseDate;

	private String uploadedFilePath;

	public void setPrintRequestDateFrmt(String printRequestDate) {
		this.printRequestDate = DateFormatter.reFormat(printRequestDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
	}

	public void setOrigMailDateFrmt(String origMailDate) {
		this.origMailDate = DateFormatter.reFormat(origMailDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public void setLastMailDateFrmt(String lastMailDate) {
		this.lastMailDate = DateFormatter.reFormat(lastMailDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public void setPrintDateFrmt(String printDate) {
		this.printDate = DateFormatter.reFormat(printDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public void setReprintDateFrmt(String reprintDate) {
		this.reprintDate = DateFormatter.reFormat(reprintDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

	public void setResponseDueDateFrmt(String responseDueDate) {
		this.responseDueDate = DateFormatter.reFormat(responseDueDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
	}

	public void setResponseDateFrmt(String responseDate) {
		this.responseDate = DateFormatter.reFormat(responseDate, DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}

}
