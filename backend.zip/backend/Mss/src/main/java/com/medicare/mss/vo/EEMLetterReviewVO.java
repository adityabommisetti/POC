package com.medicare.mss.vo;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medicare.mss.util.DateFormatter;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EEMLetterReviewVO implements Cloneable, Serializable {

	private static final long serialVersionUID = 2332549591328395795L;
	// Mainframe ID
	private String customerId;

	// Search criteria
	private String searchType;
	private String searchId;
	private String searchReqFromDate;
	private String searchReqToDate;
	private String searchStatus;
	private String searchBatchId;
	private String searchLetterName;
	private String searchDeleteInd;
	private String ltrStatus;
	private String checkBoxAll;

	private String message;

	private String lastRowPrimaryId;
	private String lastRowFileBatchId;
	private String lastRowLetterName;
	private String lastRowRecordType;

	// Search results
	private List<String> listSearchResults;

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	public String getSearchReqFromDateFrmt() {
		return DateFormatter.reFormat(searchReqFromDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setSearchReqFromDateFrmt(String searchReqFromDate) {
		this.searchReqFromDate = DateFormatter.reFormat(searchReqFromDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
	}

	public String getSearchReqToDateFrmt() {
		return DateFormatter.reFormat(searchReqToDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
	}

	public void setSearchReqToDateFrmt(String searchReqToDate) {
		this.searchReqToDate = DateFormatter.reFormat(searchReqToDate, DateFormatter.MM_DD_YYYY,
				DateFormatter.YYYYMMDD);
	}

}
