package com.medicare.mss.security.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.view.RedirectView;

import com.medicare.mss.constant.ReqMappingConstants;
import com.medicare.mss.exception.SsoSamlResponseException;
import com.medicare.mss.facadeImpl.UserFacadeImpl;
import com.medicare.mss.helper.ApiResponse;
import com.medicare.mss.util.SsoValidationUtil;
import com.medicare.mss.vo.SamlReq;
import com.medicare.mss.vo.SecuserVO;

@RestController
@RequestMapping(path = "/sso")
public class SsoUserController {

	private final Logger logger = LogManager.getLogger(this.getClass());

	@Autowired
	private UserFacadeImpl userFacade;

	@Value("${sso.redirect.url}")
	private String ssoRedirectUrl;

	@PostMapping(value = ReqMappingConstants.SAML_VALIDATION)
	public RedirectView samlValidation(SamlReq samlReq) throws SsoSamlResponseException {
		String samlResponse = samlReq.getSamlResp();
		StringBuilder destUrl = new StringBuilder(ssoRedirectUrl);
		String ssoUserId = "";
		try {
			if (null != samlResponse && !samlResponse.isEmpty()) {
				// need to verify authentication object in case of sso
				SecuserVO secuserVO = SsoValidationUtil.getSsoUser(samlResponse);
				if (null != secuserVO) {
					ssoUserId = secuserVO.getUserId();
					String token = userFacade.createSsoToken(secuserVO.getUserId());
					if (!token.isEmpty()) {
						destUrl.append("/sso/").append(token);
					} else {
						throw new SsoSamlResponseException("You Are Not Authorized");
					}
				} else {
					throw new SsoSamlResponseException("Cannot Extract UserId From Saml");
				}

			} else {
				throw new SsoSamlResponseException("No SAML response received");
			}
		} catch (SsoSamlResponseException exception) {
			logger.error("Sso User Id:{}", ssoUserId, exception);
			destUrl.append("/ssoMessage/Sso Failure");
		}
		return new RedirectView(destUrl.toString());
	}

	@GetMapping(value = ReqMappingConstants.SSO_AUTH)
	public ResponseEntity<ApiResponse> getSsoUserInfo(@RequestHeader("X-Auth-Token") String token) {
		return userFacade.authenticateSsoUser(token.substring(7));
	}

}
