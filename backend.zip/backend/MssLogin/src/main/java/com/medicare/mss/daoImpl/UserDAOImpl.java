package com.medicare.mss.daoImpl;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.medicare.mss.constant.EEMConstants;
import com.medicare.mss.dao.UserDAO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.util.DateUtil;

@Repository
public class UserDAOImpl implements UserDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public String getDefaultPlan(String custNbr) {
		String planId;
		try {
			String now = DateUtil.getTodaysDate();

			String sql = CommonUtils.buildQuery(" SELECT PLAN_ID FROM SECPLAN WHERE CUST_NBR = ? AND ACTIVE_YN != 'N' ",
					" AND (EFF_END_DATE = '' OR EFF_END_DATE >= ?)  UNION ALL SELECT MMP_PLAN_ID AS PLAN_ID FROM STATEMMP MMP ",
					" WHERE STATE_CUST_NBR = ? AND ? BETWEEN EFF_START_DATE AND EFF_END_DATE ",
					" ORDER BY PLAN_ID FETCH FIRST 1 ROW ONLY");

			Object[] params = new Object[] { custNbr, now, custNbr, now };
			planId = jdbcTemplate.queryForObject(sql, params, String.class);

		} catch (EmptyResultDataAccessException exp) {
			planId = "";
		}
		return planId;
	}

	@Override
	public boolean getMbdAggrement(String userId, String mbdDataUse) {

		boolean result = false;
		try {
			String query = "SELECT Value FROM secuser_setting WHERE User_id = ? and Setting_id = ?";

			jdbcTemplate.queryForObject(query, new Object[] { userId, mbdDataUse }, String.class);
		} catch (EmptyResultDataAccessException exp) {
			result = true;
		}
		return result;
	}

	@Override
	public int logoff(String userId) {

		try {
			String query = "UPDATE secuser set SignOff_time = Current_Timestamp, SignedOn_YN = 'N' WHERE User_id = ?";

			return jdbcTemplate.update(query, userId);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.SOMETHING_WENT_WRONG);
		}
	}

	@Override
	public void updateLoginInfo(String userId) {

		try {
			String query = CommonUtils.buildQuery(
					"UPDATE secuser SET Signon_time = CURRENT_TIMESTAMP, SignedOn_yn = 'Y', ",
					" failed_logon_cnt = 0, failed_logon_date = null, AutoPwd_Status = '', Fail_AutoPwd_cnt = 0, ",
					" Fail_AutoPwd_Time = null WHERE User_id =?");

			jdbcTemplate.update(query, userId);
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.SOMETHING_WENT_WRONG);
		}
	}

	@Override
	public void updateFailedInfo(String userId) {

		try {

			String currentDatetimeStamp = DateUtil.getCurrentDatetimeStamp();
			String[] data = getUserStatus(userId);

			if (null != data) {

				String query = "UPDATE secuser set Active_yn = ?, Failed_Logon_cnt = ?, Failed_Logon_Date = ? WHERE User_id = ?";
				String activeYN = data[0];
				int maxFailedLogins = 3;

				Integer failedLogonCnt = Integer.parseInt(data[1]);

				failedLogonCnt += 1;
				if (failedLogonCnt >= maxFailedLogins) {
					activeYN = "L";
				}

				jdbcTemplate.update(query, activeYN, failedLogonCnt, currentDatetimeStamp, userId);

			}
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.SOMETHING_WENT_WRONG);
		}
	}

	private String[] getUserStatus(String userId) {
		String sql = "SELECT Active_yn, Failed_Logon_cnt FROM SECUSER WHERE USER_ID = ?";

		return jdbcTemplate.query(sql, res -> {
			String[] str = null;
			if (res.next()) {
				str = new String[2];
				str[0] = StringUtils.trimToEmpty(res.getString("Active_yn"));
				str[1] = StringUtils.trimToEmpty(res.getString("Failed_Logon_cnt"));
			}
			return str;
		}, userId);

	}

	@Override
	public int insertMbdAggrement(String userId, String settingId) {
		try {

			String sql = "INSERT INTO SECUSER_SETTING (USER_ID,SETTING_ID,VALUE) VALUES(?,?,?) ";
			return jdbcTemplate.update(sql, userId, settingId, DateUtil.getCurrentDatetimeStamp());

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.SOMETHING_WENT_WRONG);
		}
	}
}
