package com.medicare.mss.helper;

import java.io.Serializable;

import lombok.Data;

@Data
public class EEMContext implements Serializable {
	private static final long serialVersionUID = 9028157859885212840L;

}