package com.medicare.mss.security.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constant.EEMConstants;
import com.medicare.mss.constant.ReqMappingConstants;
import com.medicare.mss.facadeImpl.UserFacadeImpl;
import com.medicare.mss.helper.ApiResponse;
import com.medicare.mss.util.CacheService;

@RestController
@RequestMapping(path = "/auth")
public class UserController {

	@Autowired
	private UserFacadeImpl facade;

	@Autowired
	private CacheService cacheService;

	@PostMapping(path = ReqMappingConstants.LOGIN)
	public ResponseEntity<ApiResponse> loginPage(HttpServletRequest request) {

		return facade.authenticate(request);
	}

	@GetMapping(value = ReqMappingConstants.LOGOUT)
	public ResponseEntity<ApiResponse> logoutPage(HttpServletRequest request, HttpServletResponse response) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();

		if (auth != null) {
			facade.logout(cacheService.getUserInfo().getUserId());
			new SecurityContextLogoutHandler().logout(request, response, auth);

		}
		return ResponseEntity.ok(new ApiResponse(200, EEMConstants.LOG_OUT));
	}

	@GetMapping(value = ReqMappingConstants.GET_USER_INFO)
	public ResponseEntity<ApiResponse> getUserInfo() {

		ApiResponse userInfo = facade.getUserInfo();
		return ResponseEntity.status(userInfo.getStatusCode()).body(userInfo);
	}

}
