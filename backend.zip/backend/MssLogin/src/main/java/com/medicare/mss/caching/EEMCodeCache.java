package com.medicare.mss.caching;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.medicare.mss.vo.EEMProfileVO;

@Component
public class EEMCodeCache {

	@Autowired
	private EEMPersistence eemPer;

	public Map<String, List<String>> populateGroupServices() {
		return eemPer.populateGroupServices();
	}

	public Map<String, EEMProfileVO> populateEEMProfileCache() {

		return eemPer.populateEEMProfileCache();
	}

	public String getHintQuestion(String hintId) {

		Map<String, String> hintQuestions = eemPer.getHintQuestion();

		return hintQuestions.get(hintId);
	}

}
