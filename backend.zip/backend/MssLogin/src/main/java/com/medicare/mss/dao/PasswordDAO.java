package com.medicare.mss.dao;

import java.util.List;

import com.medicare.mss.security.domain.SecuserDO;
import com.medicare.mss.security.domain.UserInfoDO;

public interface PasswordDAO {

	SecuserDO getUserData(final String userId);

	void updateEmailNotice(String userId, String autoPwdStatus, String emailTS);

	int updatePassword(String query, List<String> params);

	String getPasswordExpireDate();

	int updateUserInfo(SecuserDO secuserDO, String dbPhoneNo, String dbEmail);

	UserInfoDO getOldPasswords(String userId);

}
