package com.medicare.mss.exception.handlers;

import org.bouncycastle.openssl.PasswordException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailSendException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.medicare.mss.constant.EEMConstants;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.exception.SimpleMessageException;
import com.medicare.mss.exception.UnAuthorizedException;
import com.medicare.mss.helper.ApiResponse;
import com.medicare.mss.helper.JSONResponse;

@RestControllerAdvice
public class ExceptionControllerAdvice {

	@ExceptionHandler(value = { ApplicationException.class, PasswordException.class })
	public ResponseEntity<JSONResponse> handleApplicationException(Exception exception) {
		JSONResponse jsonResponse = new JSONResponse();
		jsonResponse.setStatus(EEMConstants.FAILURE);
		jsonResponse.setMessage(exception.getMessage());
		return new ResponseEntity<>(jsonResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(value = { MailSendException.class })
	public ResponseEntity<JSONResponse> maleServerConnectionException(Exception exception) {
		JSONResponse jsonResponse = new JSONResponse();
		jsonResponse.setStatus(EEMConstants.FAILURE);
		jsonResponse.setMessage(EEMConstants.EMAIL_SENT_FAILURE);
		return new ResponseEntity<>(jsonResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(value = { UnAuthorizedException.class })
	public ResponseEntity<ApiResponse> unAuthorizedException(UnAuthorizedException exception) {
		return ResponseEntity.status(401).body(new ApiResponse(401, exception.getMessage()));
	}

	@ExceptionHandler(value = SimpleMessageException.class)
	public ResponseEntity<String> handleSimpleMsgException(SimpleMessageException exception) {
		return new ResponseEntity<>(exception.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(value = { Exception.class })
	public ResponseEntity<JSONResponse> handleException(Exception exception) {
		JSONResponse jsonResponse = new JSONResponse();
		jsonResponse.setStatus(EEMConstants.FAILURE);
		jsonResponse.setMessage(EEMConstants.SOMETHING_WENT_WRONG);
		return new ResponseEntity<>(jsonResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
