package com.medicare.mss.exception;

public class SsoSamlResponseException extends Exception{

	private static final long serialVersionUID = -1325953103366451676L;

	public SsoSamlResponseException() {
		super();
	
	}

	public SsoSamlResponseException(String message, Throwable cause) {
		super(message, cause);
	}

	public SsoSamlResponseException(String message) {
		super(message);
	}

	public SsoSamlResponseException(Throwable cause) {
		super(cause);
	}
	
	

}
