package com.medicare.mss.security.domain;

import java.io.Serializable;
import java.util.Collection;
import java.util.Collections;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class SecuserDetails implements UserDetails, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4721951237133644292L;

	private String userId;

	@ColumnMapper(columnName = "USER_PWD", propertyName = "password")
	private String password;

	@ColumnMapper(columnName = "FIRST_NAME", propertyName = "firstName")
	private String firstName;

	@ColumnMapper(columnName = "LAST_NAME", propertyName = "lastName")
	private String lastName;

	@ColumnMapper(columnName = "ACTIVE_YN", propertyName = "activeInd")
	private String activeInd;

	@ColumnMapper(columnName = "GROUP_ID", propertyName = "groupId")
	private String groupId;

	@ColumnMapper(columnName = "SIGNEDON_YN", propertyName = "signOnY")
	private String signOnY;

	@ColumnMapper(columnName = "PWDEXPIRE_DATE", propertyName = "pwdExpireDate")
	private String pwdExpireDate;

	@ColumnMapper(columnName = "FAILED_LOGON_CNT", propertyName = "failedLogonCnt")
	private Integer failedLogonCnt;

	@ColumnMapper(columnName = "CUST_NBR", propertyName = "custNbr")
	private String custNbr;

	@ColumnMapper(columnName = "MF_ID", propertyName = "customerId")
	private String customerId;

	@ColumnMapper(columnName = "CUST_NAME", propertyName = "customerName")
	private String customerName;

	@ColumnMapper(columnName = "CUST_TYPE", propertyName = "customerType")
	private String customerType;

	@ColumnMapper(columnName = "PHONE", propertyName = "phoneNo")
	private String phoneNo;

	@ColumnMapper(columnName = "EMAIL", propertyName = "emailId")
	private String emailId;
	private String token;

	@ColumnMapper(columnName = "HINT_ID", propertyName = "hintId")
	private String hintId;

	@ColumnMapper(columnName = "HINT2_ID", propertyName = "hintId2")
	private String hintId2;

	@ColumnMapper(columnName = "HINT3_ID", propertyName = "hintId3")
	private String hintId3;

	@ColumnMapper(columnName = "HINTANSWER", propertyName = "hintAnswer")
	private String hintAnswer;

	@ColumnMapper(columnName = "HINT2_ANSWER", propertyName = "hintAnswer2")
	private String hintAnswer2;

	@ColumnMapper(columnName = "HINT3_ANSWER", propertyName = "hintAnswer3")
	private String hintAnswer3;

	@ColumnMapper(columnName = "SIGNOFF_TIME", propertyName = "signOffTime")
	private String signOffTime;

	private boolean isMbdAggRequired;
	private boolean isPwdExpired;
	private boolean isSsoUser;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {

		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SecuserDetails other = (SecuserDetails) obj;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} 
		else if (!userId.equals(other.userId))
			return false;
		return true;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {

		return Collections.emptyList();
	}

	@Override
	public String getPassword() {
		return password;
	}

	@Override
	public String getUsername() {

		return userId;
	}

	@Override
	public boolean isAccountNonExpired() {

		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return !"L".equalsIgnoreCase(activeInd);
	}

	@Override
	public boolean isCredentialsNonExpired() {

		return true;
	}

	@Override
	public boolean isEnabled() {
		return !"N".equalsIgnoreCase(activeInd);
	}

}
