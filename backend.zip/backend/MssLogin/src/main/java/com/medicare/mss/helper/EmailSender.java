package com.medicare.mss.helper;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

@Component
public class EmailSender {

	@Value("${mail.from}")
	private String fromEmailId;
	@Autowired
	private JavaMailSender javaMailSender;

	public boolean htmlEmailSender(String toAddress, String subject, String message) throws MessagingException {
		MimeMessage mimeMessage = javaMailSender.createMimeMessage();

		MimeMessageHelper helper;
		helper = new MimeMessageHelper(mimeMessage, true);

		helper.setFrom(fromEmailId);
		helper.setTo(toAddress);

		helper.setSubject(subject);
		helper.setText(message, true);

		javaMailSender.send(mimeMessage);
		return true;

	}

}
