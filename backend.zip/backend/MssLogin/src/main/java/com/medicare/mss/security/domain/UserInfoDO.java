package com.medicare.mss.security.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;

@Data
public class UserInfoDO {

	@ColumnMapper(columnName = "HINT_ID", propertyName = "hintId")
	private String hintId;

	@ColumnMapper(columnName = "HINT2_ID", propertyName = "hintId2")
	private String hintId2;

	@ColumnMapper(columnName = "HINT3_ID", propertyName = "hintId3")
	private String hintId3;

	@ColumnMapper(columnName = "HINTANSWER", propertyName = "hintAnswer")
	private String hintAnswer;

	@ColumnMapper(columnName = "HINT2_ANSWER", propertyName = "hintAnswer2")
	private String hintAnswer2;

	@ColumnMapper(columnName = "HINT3_ANSWER", propertyName = "hintAnswer3")
	private String hintAnswer3;

	@ColumnMapper(columnName = "AUTOPWD_STATUS", propertyName = "autoPwdStatus")
	@JsonIgnore
	private String autoPwdStatus;
	@JsonIgnore
	@ColumnMapper(columnName = "AUTOPWD_EMAIL_TIME", propertyName = "autoPwdEmailTime")
	private String autoPwdEmailTime;

	@ColumnMapper(columnName = "OLDPWD1", propertyName = "oldPwd1")
	@JsonIgnore
	private String oldPwd1;
	@ColumnMapper(columnName = "OLDPWD2", propertyName = "oldPwd2")
	@JsonIgnore
	private String oldPwd2;

	@ColumnMapper(columnName = "OLDPWD3", propertyName = "oldPwd3")
	@JsonIgnore
	private String oldPwd3;
	@ColumnMapper(columnName = "OLDPWD4", propertyName = "oldPwd4")
	@JsonIgnore
	private String oldPwd4;
	@ColumnMapper(columnName = "OLDPWD5", propertyName = "oldPwd5")
	private String oldPwd5;
	@ColumnMapper(columnName = "OLDPWD6", propertyName = "oldPwd6")
	private String oldPwd6;

	@ColumnMapper(columnName = "OLDPWD7", propertyName = "oldPwd7")
	@JsonIgnore
	private String oldPwd7;
	@ColumnMapper(columnName = "OLDPWD8", propertyName = "oldPwd8")
	@JsonIgnore
	private String oldPwd8;

	@ColumnMapper(columnName = "OLDPWD9", propertyName = "oldPwd9")
	@JsonIgnore
	private String oldPwd9;
	@ColumnMapper(columnName = "OLDPWD10", propertyName = "oldPwd10")
	@JsonIgnore
	private String oldPwd10;

	@JsonIgnore
	@ColumnMapper(columnName = "OLDPWD11", propertyName = "oldPwd11")
	private String oldPwd11;

	@JsonIgnore
	@ColumnMapper(columnName = "OLDPWD12", propertyName = "oldPwd12")
	private String oldPwd12;

	@ColumnMapper(columnName = "OLDPWD13", propertyName = "oldPwd13")
	@JsonIgnore
	private String oldPwd13;
	@ColumnMapper(columnName = "OLDPWD14", propertyName = "oldPwd14")
	@JsonIgnore
	private String oldPwd14;

	@ColumnMapper(columnName = "OLDPWD15", propertyName = "oldPwd15")
	@JsonIgnore
	private String oldPwd15;
	
}
