package com.medicare.mss.dao;

public interface UserDAO {

	String getDefaultPlan(String custNbr);

	boolean getMbdAggrement(String userId, String mbdDataUse);

	int logoff(String userId);

	void updateFailedInfo(String userId);

	void updateLoginInfo(String userId);

	int insertMbdAggrement(String userId, String settingId);

}
