package com.medicare.mss.security;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.medicare.mss.security.service.UserDetailsServiceImpl;
import com.medicare.mss.util.CustomePasswordEncoder;
import com.medicare.mss.util.JwtFilter;

/**
 * @author PR323088
 *
 */
@Configuration
@EnableWebSecurity

public class SecurityConfig extends WebSecurityConfigurerAdapter {

	private static final String[] UNSECURED_PATH = { "/auth/login", "/password/forget/**", "/password/reset",
			"/forgotpassword/sendMail", "/forgotpasswordvalidation", "/selfServicePassword", "/parmvalidation",
			"/sso/samlValidation", "/index.html" };

	@Autowired
	private UserDetailsServiceImpl authService;

	@Autowired
	private JwtFilter jwtFilter;

	@Override
	protected void configure(final AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(authService).passwordEncoder(passwordEncoder());
	}

	@Override
	protected void configure(final HttpSecurity http) throws Exception {

		http.cors().disable();
		http.httpBasic();
		http.csrf().disable();

		// HTML5: Missing Framing Protection
		http.headers().frameOptions().deny();

		// HTML5: Missing Content Security Policy
		http.headers().contentSecurityPolicy("default-src 'self'");

		http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()
				.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class).authorizeRequests()
				.antMatchers(UNSECURED_PATH).permitAll().antMatchers("/**").authenticated().and().formLogin().disable();
	}

	@Override
	public void configure(WebSecurity web) {
		web.ignoring().antMatchers(UNSECURED_PATH);

	}

	@Bean
	public AuthenticationEntryPoint unauthorizedEntryPoint() {
		return (request, response, authException) -> response.sendError(HttpServletResponse.SC_UNAUTHORIZED);
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new CustomePasswordEncoder();
	}

	@Bean
	public AuthenticationManager customAuthenticationManager() throws Exception {
		return authenticationManager();
	}
}
