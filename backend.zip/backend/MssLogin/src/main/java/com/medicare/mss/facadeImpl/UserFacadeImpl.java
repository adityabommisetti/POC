package com.medicare.mss.facadeImpl;

import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.time.LocalDate;
import java.time.Period;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.medicare.mss.constant.EEMConstants;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.ApiResponse;
import com.medicare.mss.security.domain.SecuserDetails;
import com.medicare.mss.security.service.LoginService;
import com.medicare.mss.security.service.UserDetailsServiceImpl;
import com.medicare.mss.util.CacheService;
import com.medicare.mss.util.JwtUtils;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.vo.SecuserVO;

@Service
public class UserFacadeImpl {

	private static final String LOG_USERID = "userid- {}";

	/** The logger. */
	private final Logger logger = LogManager.getLogger(this.getClass());

	/** The login service. */
	@Autowired
	private LoginService loginService;

	@Autowired
	private JwtUtils jwtUtils;

	@Autowired
	private CacheService cacheService;

	@Autowired
	private UserDetailsServiceImpl userDetailsService;

	@Value("${jwt.sso.token.timeout}")
	private int ssoTokenExpiryTime;

	public ResponseEntity<ApiResponse> authenticate(HttpServletRequest request) {
		ApiResponse response = new ApiResponse();
		Authentication authentication;
		SecuserDetails secuserDetails = null;
		String userId = "";
		String pass = "";
		String token = "";
		try {
			String authorization = request.getHeader(EEMConstants.AUTHORIZATION);
			authorization = authorization.substring(6);
			String decoded = new String(Base64.getDecoder().decode(authorization));
			String[] arrOfStr = decoded.split(":");
			userId = arrOfStr[0];
			pass = arrOfStr[1];

			authentication = loginService.authenticate(userId, pass);

			if (null != authentication && authentication.isAuthenticated()) {

				secuserDetails = (SecuserDetails) authentication.getPrincipal();

				if (StringUtils.isBlank(secuserDetails.getCustNbr())
						|| StringUtils.isBlank(secuserDetails.getCustomerId())
						|| StringUtils.isBlank(secuserDetails.getCustomerType())) {
					throw new ApplicationException("INVALID CUSTOMER DATA");
				}

				SecurityContextHolder.getContext().setAuthentication(authentication);

				String customerNo = secuserDetails.getCustNbr();
				userId = secuserDetails.getUserId();

				String planId = loginService.getDefaultPlan(customerNo);

				if (planId.isEmpty()) {
					throw new ApplicationException("Plan Id Not Found");
				}

				List<String> services = loginService.getUserServices(secuserDetails.getGroupId());
				List<LabelValuePair> profiles = loginService.validateUserData(secuserDetails);

				SecuserVO secuserVo = new SecuserVO();

				String pwdExpireDate = secuserDetails.getPwdExpireDate();

				boolean isPwdExipred = checkPwdExpired(pwdExpireDate);
				secuserDetails.setPwdExpired(isPwdExipred);

				loginService.updateLoginInfo(userId);

				boolean mbdAggStatus = loginService.getUserSetting(userId);
				secuserDetails.setMbdAggRequired(mbdAggStatus);
				BeanUtils.copyProperties(secuserDetails, secuserVo);

				token = jwtUtils.createToken(userId);
				response = new ApiResponse(200);
				response.setListObject(services);
				response.setObject(secuserVo);
				response.setProfiles(profiles);

				cacheService.setAuthentication(userId, secuserDetails, EEMConstants.AUTH_CACHE);
				cacheService.setUserCache(userId, EEMConstants.TOKEN, token);
				cacheService.setUserCache(userId, EEMConstants.SERVICES, services);
				cacheService.setUserCache(userId, EEMConstants.PROFILE, profiles);

				logger.info("CustomerId: {} and UserId: {} - Login Successful",
						cacheService.getUserInfo().getCustomerId(), cacheService.getUserInfo().getUserId());

			}
		} catch (BadCredentialsException exp) {
			logger.error(LOG_USERID, userId, exp);
			loginService.updateFailedInfo(userId);
			response = new ApiResponse(404, EEMConstants.INVALID_CRED);

		} catch (LockedException | DisabledException exp) {
			logger.error(LOG_USERID, userId, exp);
			loginService.updateFailedInfo(userId);
			response = new ApiResponse(401, EEMConstants.USER_ACCOUNT_LOCKED);

		} catch (Exception exp) {
			logger.error(LOG_USERID, userId, exp);
			response = new ApiResponse(500, EEMConstants.SOMETHING_WENT_WRONG);
		}

		if (response.getStatusCode() == 200) {
			return ResponseEntity.status(response.getStatusCode()).header(EEMConstants.AUTH_TOKEN, token)
					.body(response);
		}
		return ResponseEntity.status(response.getStatusCode()).body(response);

	}

	private boolean checkPwdExpired(String pwdExpireDate) {

		LocalDate expireDate = LocalDate.parse(pwdExpireDate.substring(0, 10));
		LocalDate currentDate = LocalDate.now();
		Period intervalPeriod = Period.between(currentDate, expireDate);
		return (intervalPeriod.isZero() || intervalPeriod.isNegative());

	}

	@SuppressWarnings("unchecked")
	public ApiResponse getUserInfo() {
		ApiResponse response = null;
		SecuserDetails secuserDO = cacheService.getUserInfo();
		String userId = trimToEmpty(secuserDO.getUserId());

		List<String> services = (List<String>) cacheService.getUserCache(userId, EEMConstants.SERVICES, List.class);
		List<LabelValuePair> profileList = (List<LabelValuePair>) cacheService.getUserCache(userId,
				EEMConstants.PROFILE, List.class);

		if (Objects.nonNull(services)) {
			SecuserVO secuserVO = new SecuserVO();
			BeanUtils.copyProperties(secuserDO, secuserVO);
			response = new ApiResponse(200, "Login Success ");
			response.setObject(secuserVO);
			response.setListObject(services);
			response.setProfiles(profileList);
		} else {
			response = new ApiResponse(401, "Login is Required");
		}

		return response;
	}

	public void logout(String userId) {
		loginService.logout(userId);
		cacheService.removeUserCache(userId);
		logger.info("userid: {} - Logout Successful", userId);
	}

	public String createSsoToken(String ssoUserId) {
		try {
			SecuserDetails secuserDetails = (SecuserDetails) userDetailsService.loadUserByUsername(ssoUserId);
			String token = jwtUtils.createToken(ssoUserId);
			secuserDetails.setSsoUser(true);
			cacheService.setUserCache(ssoUserId, EEMConstants.TOKEN, token);
			cacheService.setAuthentication(ssoUserId, secuserDetails, EEMConstants.AUTH_CACHE);
			return token;
		} catch (UsernameNotFoundException exception) {
			logger.error(LOG_USERID, ssoUserId, exception);
			return "";
		}
	}

	public ResponseEntity<ApiResponse> authenticateSsoUser(String token) {
		ApiResponse response = new ApiResponse();
		String ssoUserId = jwtUtils.extractClaims(token).getSubject();
		try {
			if (isTokenExpired(token)) {
				cacheService.removeUserCache(ssoUserId);
				response = new ApiResponse(403, "Token TimedOut");
				return ResponseEntity.status(response.getStatusCode()).body(response);
			}

			SecuserDetails secuserDetails = cacheService.getUserInfo();

			loginService.updateLoginInfo(ssoUserId);

			boolean mbdAggStatus = loginService.getUserSetting(ssoUserId);
			secuserDetails.setMbdAggRequired(mbdAggStatus);

			List<String> services = loginService.getUserServices(secuserDetails.getGroupId());
			List<LabelValuePair> profiles = loginService.validateUserData(secuserDetails);

			String planId = loginService.getDefaultPlan(secuserDetails.getCustNbr());

			if (planId.isEmpty()) {
				throw new ApplicationException("Plan Id Not Found");
			}

			SecuserVO secuserVo = new SecuserVO();
			BeanUtils.copyProperties(secuserDetails, secuserVo);

			token = jwtUtils.createToken(ssoUserId);
			response = new ApiResponse(200);
			response.setListObject(services);
			response.setObject(secuserVo);
			response.setProfiles(profiles);

			cacheService.setUserCache(ssoUserId, EEMConstants.SERVICES, services);
			cacheService.setUserCache(ssoUserId, EEMConstants.PROFILE, profiles);
			cacheService.setUserCache(ssoUserId, EEMConstants.TOKEN, token);

			logger.info("CustomerId: {} and UserId: {} - Sso Login Successful",
					cacheService.getUserInfo().getCustomerId(), cacheService.getUserInfo().getUserId());
		} catch (ApplicationException exp) {
			logger.error("Sso Userid- {}", ssoUserId, exp);
			response = new ApiResponse(500, EEMConstants.SOMETHING_WENT_WRONG);
		}
		return ResponseEntity.status(response.getStatusCode()).header(EEMConstants.AUTH_TOKEN, token).body(response);
	}

	private boolean isTokenExpired(String token) {
		Date issueTime = jwtUtils.extractClaims(token).getIssuedAt();
		Calendar expiryTime = Calendar.getInstance();
		expiryTime.setTime(issueTime);
		expiryTime.add(Calendar.MINUTE, ssoTokenExpiryTime);
		Calendar now = Calendar.getInstance();
		return now.after(expiryTime);
	}

}
