package com.medicare.mss.helper;

import java.io.Serializable;

import lombok.Data;

@Data
public class EdpsContext implements Serializable{

	private static final long serialVersionUID = -211212689526756707L;
	

}
