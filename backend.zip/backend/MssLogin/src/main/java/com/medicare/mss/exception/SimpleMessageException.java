package com.medicare.mss.exception;

public class SimpleMessageException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SimpleMessageException() {
		super();
	}

	public SimpleMessageException(String message) {
		super(message);
	}

	public SimpleMessageException(Throwable cause, String message) {
		super(message, cause);
	}

	public SimpleMessageException(Throwable cause) {
		super(cause);
	}

}
