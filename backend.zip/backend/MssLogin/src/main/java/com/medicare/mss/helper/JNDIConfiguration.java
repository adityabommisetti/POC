package com.medicare.mss.helper;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;

/**
 * @author Wipro
 * 
 * 
 *///
//@Configuration
public class JNDIConfiguration {

	@Value("${datasource.jndi}")
	private String jndiName;

	@Bean
	@Primary
	public DataSource dataSource() {

		JndiDataSourceLookup jndiDataSourceLookup = new JndiDataSourceLookup();
		jndiDataSourceLookup.setResourceRef(true);
		return jndiDataSourceLookup.getDataSource(jndiName);

	}

	@Bean
	public JdbcTemplate jdbcTemplate() {
		return new JdbcTemplate(dataSource());
	}

}