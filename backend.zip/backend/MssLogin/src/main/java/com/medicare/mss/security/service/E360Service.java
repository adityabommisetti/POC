package com.medicare.mss.security.service;

import java.net.URI;
import java.net.URISyntaxException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.medicare.mss.constant.EEMConstants;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.util.CacheService;
import com.medicare.mss.vo.E360VO;

@Service
public class E360Service {

	@Autowired
	private CacheService sessionHelper;

	@Value("${E360AuthenticateUrl}")
	private String e360AuthenticateUrl;

	private int resqRequestId = 0;

	public E360VO authenticate() {

		E360VO e360VO = new E360VO();
		e360VO.setUserId(sessionHelper.getUserInfo().getUserId());
		e360VO.setCustomerId(sessionHelper.getUserInfo().getCustNbr());
		e360VO.setCustomerName(sessionHelper.getUserInfo().getCustomerName());
		e360VO.setToken(sessionHelper
				.getUserCache(sessionHelper.getUserInfo().getUserId(), EEMConstants.TOKEN, String.class).toString());
		String requestId = getResqRequestId();
		e360VO.setRequestId(requestId);
		try {
			login(e360VO);

		} catch (Exception exp) {
			throw new ApplicationException(exp);
		}
		return e360VO;
	}

	private String getResqRequestId() {

		if (this.resqRequestId > Integer.MAX_VALUE) {
			this.resqRequestId = 0;
		}
		int requestId = this.resqRequestId;
		this.resqRequestId++;
		return ("" + requestId);
	}

	private void login(E360VO e360VO) throws URISyntaxException {
		try {
			RestTemplate restTemplate = new RestTemplate();
			URI secondUri = new URI(e360AuthenticateUrl);
			HttpHeaders headers = new HttpHeaders();
			HttpEntity<E360VO> requestEntity = new HttpEntity<>(e360VO, headers);
			restTemplate.postForEntity(secondUri, requestEntity, String.class);
		} catch (Exception exp) {
			throw new ApplicationException(exp);
		}
	}

}
