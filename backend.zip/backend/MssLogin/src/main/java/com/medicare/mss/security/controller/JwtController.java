/**
 * 
 */
package com.medicare.mss.security.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constant.EEMConstants;
import com.medicare.mss.constant.ReqMappingConstants;
import com.medicare.mss.util.JwtUtils;

/**
 * @author dkumar
 *
 */
@RestController
@RequestMapping(path = "/jwt")
public class JwtController {

	@Autowired
	private JwtUtils jwtUtils;

	@PostMapping(path = ReqMappingConstants.RENEW_TOKEN)
	public String renewToken(@RequestHeader(name = EEMConstants.AUTH_TOKEN, required = true) String authTokenHeader) {
		String jwtToken = authTokenHeader.substring(7);
		String userId = jwtUtils.extaractUserName(jwtToken);
		return jwtUtils.renewTokenIfRequired(jwtToken, userId);
	}

}
