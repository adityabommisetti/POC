package com.medicare.mss.security.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import com.medicare.mss.caching.EEMCodeCache;
import com.medicare.mss.constant.EEMConstants;
import com.medicare.mss.daoImpl.UserDAOImpl;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.security.domain.SecuserDetails;
import com.medicare.mss.util.LabelValuePair;
import com.medicare.mss.vo.EEMProfileVO;

@Service
public class LoginService {

	@Autowired
	private AuthenticationManager authenticationManager;
	@Autowired
	private UserDAOImpl userDAO;
	@Autowired
	private EEMCodeCache cache;

	public Authentication authenticate(String userId, String pwd) {
		String password = userId + "/" + pwd;

		return authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(userId, password));
	}

	public List<LabelValuePair> validateUserData(SecuserDetails principal) {

		String customerNo = principal.getCustNbr();
		String custId = principal.getCustomerId();
		String groupId = principal.getGroupId();
		List<LabelValuePair> profiles = new ArrayList<>();

		String planId = userDAO.getDefaultPlan(customerNo);

		if (StringUtils.isBlank(planId)) {
			throw new ApplicationException("Plan Id Not Found");
		}

		Map<String, EEMProfileVO> eemProfileCacheData = cache.populateEEMProfileCache();
		EEMProfileVO eemProfileVO = eemProfileCacheData
				.get(new StringBuilder(custId).append('_').append(EEMConstants.LOB_VALD).toString());

		if (null != eemProfileVO && EEMConstants.VALUE_YES.equalsIgnoreCase(eemProfileVO.getParmIndValue())) {
			profiles.add(new LabelValuePair(EEMConstants.VALUE_YES, EEMConstants.LOB_VALD));
		} else {
			profiles.add(new LabelValuePair(EEMConstants.VALUE_NO, EEMConstants.LOB_VALD));
		}

		eemProfileVO = eemProfileCacheData
				.get(new StringBuilder(custId).append('_').append(EEMConstants.PRINTIDC).toString());

		if (null != eemProfileVO && "Y".equalsIgnoreCase(eemProfileVO.getParmIndValue())) {
			profiles.add(new LabelValuePair(EEMConstants.VALUE_YES, EEMConstants.PRINTIDC));
			profiles.add(new LabelValuePair(StringUtils.trimToEmpty((eemProfileVO.getParmTextValue())),
					EEMConstants.PRINTIDC_TEXT));
		} else {
			profiles.add(new LabelValuePair(EEMConstants.VALUE_NO, EEMConstants.PRINTIDC));
			profiles.add(new LabelValuePair("", EEMConstants.PRINTIDC_TEXT));
		}

		eemProfileVO = eemProfileCacheData
				.get(new StringBuilder(custId).append('_').append(EEMConstants.SUPER_USER).toString());

		if (Objects.nonNull(eemProfileVO) && StringUtils.equals(eemProfileVO.getParmTextValue(), groupId.trim())
				&& StringUtils.equalsIgnoreCase(EEMConstants.VALUE_YES, eemProfileVO.getParmIndValue())) {
			profiles.add(new LabelValuePair(EEMConstants.VALUE_YES, EEMConstants.SUPER_USER));
		} else {
			profiles.add(new LabelValuePair(EEMConstants.VALUE_NO, EEMConstants.SUPER_USER));
		}

		eemProfileVO = eemProfileCacheData
				.get(new StringBuilder(custId).append('_').append(EEMConstants.APPFIELDS).toString());
		if (null != eemProfileVO && EEMConstants.VALUE_YES.equalsIgnoreCase(eemProfileVO.getParmIndValue())) {
			profiles.add(new LabelValuePair(EEMConstants.VALUE_YES, EEMConstants.APPFIELDS));
		} else {
			profiles.add(new LabelValuePair(EEMConstants.VALUE_NO, EEMConstants.APPFIELDS));
		}
		eemProfileVO = eemProfileCacheData
				.get(new StringBuilder(custId).append('_').append(EEMConstants.AGENTDT).toString());
		String signDateProfileOpt = null == eemProfileVO ? "" : eemProfileVO.getParmIndValue();
		profiles.add(new LabelValuePair(signDateProfileOpt, EEMConstants.AGENTDT));

		eemProfileVO = eemProfileCacheData
				.get(new StringBuilder(custId).append('_').append(EEMConstants.DRAFTDAY).toString());
		String draftDay = (eemProfileVO != null) ? eemProfileVO.getParmIndValue() : "1";
		profiles.add(new LabelValuePair(draftDay, EEMConstants.DRAFTDAY));

		setProfileParmTextValue(EEMConstants.MBRIDLIT, custId, profiles, eemProfileCacheData);
		setProfileParmTextValue(EEMConstants.ENBQUEST, custId, profiles, eemProfileCacheData);
		setProfileParmTextValue(EEMConstants.TC73TRIG, custId, profiles, eemProfileCacheData);
		setProfileParmTextValue(EEMConstants.SUBSCID, custId, profiles, eemProfileCacheData);
		setProfileParmTextValue(EEMConstants.SUPPLID, custId, profiles, eemProfileCacheData);

		setProfileParmIndValue(EEMConstants.SUBSCID, custId, profiles, eemProfileCacheData);
		setProfileParmIndValue(EEMConstants.CAMPIDIND, custId, profiles, eemProfileCacheData);
		setProfileParmIndValue(EEMConstants.CONTRNOIND, custId, profiles, eemProfileCacheData);
		setProfileParmIndValue(EEMConstants.SUPPLID, custId, profiles, eemProfileCacheData);
		setProfileParmIndValue(EEMConstants.ENBCMAQUES, custId, profiles, eemProfileCacheData);
		setProfileParmIndValue(EEMConstants.AUTOAPPLDT, custId, profiles, eemProfileCacheData);
		setProfileParmIndValue(EEMConstants.LTC_QUES, custId, profiles, eemProfileCacheData);
		setProfileParmIndValue(EEMConstants.NOICD, custId, profiles, eemProfileCacheData);
		setProfileParmIndValue(EEMConstants.CMAEMRGIND, custId, profiles, eemProfileCacheData);
		setProfileParmIndValue(EEMConstants.VALSIGNAGT, custId, profiles, eemProfileCacheData);

		Collections.sort(profiles, (LabelValuePair p1, LabelValuePair p2) -> p1.getLabel().compareTo(p2.getLabel()));
		return profiles;
	}

	private void setProfileParmTextValue(String profileName, String custId, List<LabelValuePair> profiles,
			Map<String, EEMProfileVO> eemProfileCacheData) {

		EEMProfileVO eemProfileVO = eemProfileCacheData
				.get(new StringBuilder(custId).append('_').append(profileName).toString());
		String value = (Objects.nonNull(eemProfileVO) && StringUtils.isNotBlank(eemProfileVO.getParmTextValue()))
				? eemProfileVO.getParmTextValue()
				: EEMConstants.BLANK;

		if (StringUtils.equals(profileName, EEMConstants.ENBQUEST)) {
			profiles.add(new LabelValuePair(value, EEMConstants.ENBQUEST));
			profiles.add(new LabelValuePair(value, EEMConstants.ENBQUESTVAL));
		} else if (StringUtils.equals(profileName, EEMConstants.SUBSCID)) {
			profiles.add(new LabelValuePair(value, EEMConstants.SUBSCID_TEXT));
		} else if (StringUtils.equals(profileName, EEMConstants.SUPPLID)) {
			profiles.add(new LabelValuePair(value, EEMConstants.SUPPLID_TEXT));
		} else {
			profiles.add(new LabelValuePair(value, profileName));
		}
	}

	private void setProfileParmIndValue(String profileName, String custId, List<LabelValuePair> profiles,
			Map<String, EEMProfileVO> eemProfileCacheData) {

		EEMProfileVO eemProfileVO = eemProfileCacheData
				.get(new StringBuilder(custId).append('_').append(profileName).toString());
		String value = (Objects.nonNull(eemProfileVO) && StringUtils.isNotBlank(eemProfileVO.getParmIndValue()))
				? eemProfileVO.getParmIndValue()
				: EEMConstants.VALUE_NO;
		profiles.add(new LabelValuePair(value, profileName));
	}

	public List<String> getUserServices(String groupId) {
		Map<String, List<String>> secGrpServices = cache.populateGroupServices();
		return secGrpServices.get(groupId);
	}

	public void updateFailedInfo(String userId) {
		userDAO.updateFailedInfo(userId);

	}

	public void logout(String userId) {
		userDAO.logoff(userId);

	}

	public String getDefaultPlan(String customerNo) {
		return userDAO.getDefaultPlan(customerNo);
	}

	public void updateLoginInfo(String userId) {
		userDAO.updateLoginInfo(userId);
	}

	public boolean getUserSetting(String userId) {
		return userDAO.getMbdAggrement(userId, EEMConstants.MBD_AGGREMENT);
	}

	public int insertMbdAggrement(String userId) {
		return userDAO.insertMbdAggrement(userId, EEMConstants.MBD_AGGREMENT);
	}
}
