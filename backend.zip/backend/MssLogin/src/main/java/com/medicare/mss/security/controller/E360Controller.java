package com.medicare.mss.security.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mss.constant.EEMConstants;
import com.medicare.mss.constant.ReqMappingConstants;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.security.service.E360Service;
import com.medicare.mss.vo.E360VO;

@RestController
public class E360Controller {

	@Autowired
	private E360Service e360Service;

	@Value("${E360FinalUrl}")
	private String e360FinalUrl;

	@GetMapping(ReqMappingConstants.E360)
	public ResponseEntity<JSONResponse> getE360Url() {
		try {
			E360VO e360VO = e360Service.authenticate();
			return sendResponse(e360FinalUrl + e360VO.getUserId() + e360VO.getToken());
		} catch (Exception exp) {
			throw new ApplicationException(exp);
		}
	}

	private ResponseEntity<JSONResponse> sendResponse(Object object) {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;
		jsonResponse.setData(object);
		if (null == object) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
			jsonResponse.setMessage(EEMConstants.BLANK);
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}

}
