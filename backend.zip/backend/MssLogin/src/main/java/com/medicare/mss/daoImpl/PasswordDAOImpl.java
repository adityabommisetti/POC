package com.medicare.mss.daoImpl;

import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Repository;

import com.medicare.mss.annotation.DomainPropertyRowMapper;
import com.medicare.mss.constant.EEMConstants;
import com.medicare.mss.dao.PasswordDAO;
import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.security.domain.SecuserDO;
import com.medicare.mss.security.domain.UserInfoDO;
import com.medicare.mss.util.CommonUtils;

@Repository
public class PasswordDAOImpl implements PasswordDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public SecuserDO getUserData(String searchId) {

		String userID = trimToEmpty(searchId);
		SecuserDO userVo = null;
		try {
			final String query = new StringBuilder(
					"SELECT  USER_PWD,PHONE,EMAIL, GROUP_ID, HINT_ID,HINTANSWER, SIGNEDON_YN, ACTIVE_YN, PWDEXPIRE_DATE,  ")
							.append("	HINT2_ID,HINT2_ANSWER,HINT3_ID, HINT3_ANSWER,AUTOPWD_STATUS,AUTOPWD_EMAIL_TIME from SECUSER WHERE SECUSER.USER_ID = ? ")
							.toString();
			userVo = jdbcTemplate.queryForObject(query, new DomainPropertyRowMapper<SecuserDO>(SecuserDO.class),
					userID);

		} catch (EmptyResultDataAccessException exp) {
			// Privacy Violation -removed user id from exception message
			throw new ApplicationException("No User Found ");
		}
		userVo.setUserId(userID);

		return userVo;
	}

	@Override
	public void updateEmailNotice(String userId, String autoPwdStatus, String emailTS) {
		try {
			String sql = "UPDATE secuser set AUTOPWD_STATUS = ?, AUTOPWD_EMAIL_TIME = ? WHERE User_id = ?";
			jdbcTemplate.update(sql, autoPwdStatus, emailTS, userId);

		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.EMAIL_SENT_FAILURE);
		}
	}

	@Override
	public int updatePassword(String updsql, List<String> params) {
		int res = 0;
		try {
			String sql = CommonUtils.buildQuery("UPDATE secuser set ", updsql,
					",FAILED_LOGON_DATE = NULL, FAILED_LOGON_CNT = 0,AUTOPWD_STATUS = '', ",
					" AUTOPWD_EMAIL_TIME = NULL,FAIL_AUTOPWD_TIME = NULL, FAIL_AUTOPWD_CNT = 0 where USER_ID=? ");

			res = jdbcTemplate.update(sql, params.toArray());
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, EEMConstants.PASS_FAILED);
		}
		return res;

	}

	@Override
	public String getPasswordExpireDate() {
		String query = "SELECT pwdexpiredays FROM systemparms";

		int pwdExpireDays = jdbcTemplate.queryForObject(query, Integer.class);

		LocalDateTime expireDate = LocalDateTime.now().plusDays(pwdExpireDays);

		return expireDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.000000"));

	}

	@Override
	public int updateUserInfo(SecuserDO secuserDO, String dbPHoneNo, String dbEmail) {
		int res = 0;
		try {
			StringBuilder query = CommonUtils.buildQueryBuilder("UPDATE secuser set ");

			List<String> params = new ArrayList<>();

			String phoneNo = trimToEmpty(secuserDO.getPhoneNo());
			String emailId = trimToEmpty(secuserDO.getEmailId());
			String hintId1 = trimToEmpty(secuserDO.getHintId());
			String hintAns1 = trimToEmpty(secuserDO.getHintAnswer());
			String hintId2 = trimToEmpty(secuserDO.getHintId2());
			String hintAns2 = trimToEmpty(secuserDO.getHintAnswer2());
			String hintId3 = trimToEmpty(secuserDO.getHintId3());
			String hintAns3 = trimToEmpty(secuserDO.getHintAnswer3());
			String userId = trimToEmpty(secuserDO.getUserId());

			String groupId = trimToEmpty(secuserDO.getGroupId());

			if (!trimToEmpty(dbPHoneNo).equalsIgnoreCase(phoneNo)) {
				query.append(" PHONE = ? ,");
				params.add(phoneNo);
			}
			if (!trimToEmpty(dbEmail).equalsIgnoreCase(emailId)) {
				query.append(" EMAIL = ? ,");
				params.add(emailId);
			}

			if (hintAns1.length() > 0) {
				query.append(" Hint_id = ? , HintAnswer = ? , ");
				params.add(hintId1);
				params.add(hintAns1);
			}

			if (hintAns2.length() > 0) {
				query.append(" Hint2_id = ? , Hint2_Answer = ? ,");
				params.add(hintId2);
				params.add(hintAns2);
			}

			if (hintAns3.length() > 0) {
				query.append(" Hint3_id = ? , Hint3_Answer = ? ");
				params.add(hintId3);
				params.add(hintAns3);
			}
			params.add(userId);
			params.add(groupId);
			query.append(" where user_id =?  and  group_id =? ");
			res = jdbcTemplate.update(query.toString(), params.toArray());
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Failed to update");
		}
		return res;
	}

	@Override
	public UserInfoDO getOldPasswords(String userId) {

		UserInfoDO userVo = null;
		try {
			final String query = new StringBuilder("SELECT  OLDPWD1,OLDPWD2,OLDPWD3,OLDPWD4,OLDPWD5, OLDPWD6, ").append(
					"OLDPWD7,OLDPWD8,OLDPWD9,OLDPWD10,OLDPWD11, OLDPWD12,OLDPWD13,OLDPWD14,OLDPWD15 from SECUSER WHERE SECUSER.USER_ID = ? ")
					.toString();
			userVo = jdbcTemplate.queryForObject(query, new DomainPropertyRowMapper<UserInfoDO>(UserInfoDO.class),
					userId);

		} catch (EmptyResultDataAccessException exp) {
			throw new UsernameNotFoundException("No User Found " + userId);
		}

		return userVo;
	}

}
