package com.medicare.mss.caching;

import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.medicare.mss.exception.ApplicationException;
import com.medicare.mss.vo.EEMProfileVO;

@Repository
public class EEMPersistence {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Cacheable("populateGroupServices")
	public Map<String, List<String>> populateGroupServices() {
		Map<String, List<String>> services = null;

		try {
			String sql = new StringBuilder(" SELECT DISTINCT SERVICE_ID ,Group_id FROM secgroup_service WHERE  ")
					.append(" SERVICE_ID IN ('FTS','HII','ERS','BE0','ERP','RXR','RP','ILMR','TXMR','NMMR','R4C','WRO0','EDS',")
					.append("'RAX','RAE','RAD','RAU','IF','RCC', ")
					.append("'QAP','QAM','QAS','QAR','QLP','QLM','QLS','QLR','QCD','OLP', 'BOR','FTE','OEV','ELID','JAS','RESQ',")
					.append("'EEM','EEMU','EEMS','EEMA','EEUA','EEMM','EEUM','EEMB','EEUB','EEML','EEUL','EEMG','EEUG', ")
					.append("'HPE','HPEU','EEMT','EEGW','EESS','EMAO','EMAV','EMAB','EMAR','EMDA','EEMD','EMCB','EEMN','EMCM','EMUC', ")
					.append("'MRA','MRD','MRP','NMA','NMD','NMP','TXA','TXD','TXP','MNMR','MNA','MND','MNP0','MNPP','MNRA','MNRD', ")
					.append("'EMDM','EMDN','EMDD','EMLU','EMBU','EMAU','EMCU','EMPU','EMAD','EMDU','EMPW','EMOU','EMPN','EMSA','EMDI','EMDL','EMBR','EMEL','EMLP','EMLR','EMUT','EMNA','EMUL', ")
					.append("'EEWF','EMLL','FLFM' ,'EDSB','VPDF', 'MBIC', 'EEAS', 'VLTC', 'DBRD', 'BNSF','SOA')")
					.toString();

			services = jdbcTemplate.query(sql, new ResultSetExtractor<Map<String, List<String>>>() {

				Map<String, List<String>> serviceMap = new HashMap<>();

				@Override
				public Map<String, List<String>> extractData(ResultSet resultSet) throws SQLException {

					while (resultSet.next()) {
						String groupId = trimToEmpty(resultSet.getString("GROUP_ID"));
						String serviceId = trimToEmpty(resultSet.getString("SERVICE_ID"));

						if (serviceMap.containsKey(groupId)) {
							List<String> list = serviceMap.get(groupId);
							list.add(serviceId);
							serviceMap.put(groupId, list);
						} else {
							List<String> lista = new ArrayList<>();
							lista.add(serviceId);
							serviceMap.put(groupId, lista);
						}
					}

					return serviceMap;
				}

			});
		} catch (DataAccessException exception) {
			throw new ApplicationException("Services are not loaded");
		}
		return services;
	}

	@Cacheable(value = "hintQuestions")
	public Map<String, String> getHintQuestion() {
		String sql = "SELECT Hint_Id, HintQuest FROM Hint ORDER BY Hint_id";

		return jdbcTemplate.query(sql, result -> {
			Map<String, String> questionMap = new HashMap<>();

			while (result.next()) {
				String name = trimToEmpty(result.getString("Hint_id"));
				String value = trimToEmpty(result.getString("HintQuest"));
				questionMap.put(name, value);
			}
			return questionMap;

		});

	}

	@Cacheable("populateEEMProfileCache")
	public Map<String, EEMProfileVO> populateEEMProfileCache() {
		Map<String, EEMProfileVO> profileCache = null;
		try {
			String query = "SELECT * FROM EM_PROFILE WHERE OVERRIDE_IND = ? ";

			profileCache = jdbcTemplate.query(query,

					res -> {

						Map<String, EEMProfileVO> eemProfiles = new HashMap<>();

						while (res.next()) {
							EEMProfileVO eemProfileVO = new EEMProfileVO();
							eemProfileVO.setCustomerId(trimToEmpty(res.getString("CUSTOMER_ID")));
							eemProfileVO.setEffectiveStartDate(trimToEmpty(res.getString("EFF_START_DATE")));
							eemProfileVO.setEffectiveEndDate(trimToEmpty(res.getString("EFF_END_DATE")));
							eemProfileVO.setParmCode(trimToEmpty(res.getString("PARM_CD")));
							eemProfileVO.setParmTextValue(trimToEmpty(res.getString("PARM_TEXT_VALUE")));
							eemProfileVO.setParmNumberValue(trimToEmpty(res.getString("PARM_NBR_VALUE")));
							eemProfileVO.setParmIndValue(trimToEmpty(res.getString("PARM_IND_VALUE")));
							eemProfileVO.setParmDateValue(trimToEmpty(res.getString("PARM_DATE_VALUE")));
							eemProfileVO.setParmDescription(trimToEmpty(res.getString("PARM_DESC")));
							eemProfiles.put(eemProfileVO.getCustomerId() + "_" + eemProfileVO.getParmCode(),
									eemProfileVO);
						}
						return eemProfiles;

					}, "N");
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp);

		}

		return profileCache;
	}

}
