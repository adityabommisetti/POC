package com.medicare.mss.caching;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.medicare.mss.exception.ApplicationException;

@Repository("sysParms")
public class SysParmsPersistence {

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Cacheable(value = "getSysParmsValue", key = "#paramName")
	public String getSysParmsValue(String paramName) {

		String paramValue;
		try {
			String sql = "SELECT PARM_VALUE FROM SYS_PARMS WHERE PARM_NAME = ?";

			Object[] parms = new Object[] { paramName };

			paramValue = jdbcTemplate.queryForObject(sql, parms, String.class);

		} catch (EmptyResultDataAccessException exp) {
			paramValue = "";
		} catch (DataAccessException exp) {
			throw new ApplicationException(exp, "Error occured while getSysParmsValue!!");
		}
		return paramValue;
	}

}
