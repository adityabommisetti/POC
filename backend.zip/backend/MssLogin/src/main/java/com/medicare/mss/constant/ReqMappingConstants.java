package com.medicare.mss.constant;

public class ReqMappingConstants {

	private ReqMappingConstants() {

	}

	public static final String LOGIN = "/login";
	public static final String LOGOUT = "/logout";
	public static final String GET_USER_INFO = "/get/login/info";
	public static final String MAX_SEESION = "/maxSessionExceed";

	public static final String CHANGE_PASS = "/password/change";
	public static final String UPDATE_USER_INFO = "/update/user";

	public static final String FORGOT_PASS = "/password/forget";
	public static final String RESET_PASS = "/password/reset";

	public static final String SEND_MAIL = "/forgotpassword/sendMail";
	public static final String SELF_SERVICE_PASS = "/selfServicePassword";
	public static final String PARM_VALIDATION = "/parmvalidation";
	public static final String USER_SETTING_UPDATE = "/update/user/setting/{userId}";

	/** Start SSO constants */
	public static final String SAML_VALIDATION = "/samlValidation";
	public static final String SSO_AUTH = "/getSsoUserInfo";
	/** End SSO constants */
	public static final String PASS_EXPIRED = "/password/expired";

	public static final String E360 = "/E360";

	public static final String CREATE_TOKEN = "/createToken";
	public static final String RENEW_TOKEN = "/renewToken";

	public static final String JASPER = "/getJasper";

}
