package com.medicare.mss.security.controller;

import java.util.Map;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.bouncycastle.openssl.PasswordException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.medicare.mss.constant.EEMConstants;
import com.medicare.mss.constant.ReqMappingConstants;
import com.medicare.mss.exception.SimpleMessageException;
import com.medicare.mss.helper.JSONResponse;
import com.medicare.mss.security.service.PasswordService;
import com.medicare.mss.vo.QsnAnsVO;
import com.medicare.mss.vo.SecuserVO;

@RestController
public class PasswordController {

	private static final String NEW_PASS = "newpwd";

	@Autowired
	private PasswordService passwordService;

	@Value("${app.redirect.url}")
	private String redirectUrl;

	@PostMapping(value = ReqMappingConstants.CHANGE_PASS)
	public ResponseEntity<JSONResponse> changePassword(@RequestBody Map<String, String> request)
			throws PasswordException {

		int result = passwordService.changePassword(request.get("userId"), request.get(NEW_PASS), request.get("pwd"));
		return sendResponse(result, EEMConstants.PASS_CHANGED_SUCCESS);

	}

	@PostMapping(value = ReqMappingConstants.UPDATE_USER_INFO)
	public ResponseEntity<JSONResponse> updateUser(@RequestBody SecuserVO secuserVO) {

		int result = passwordService.updateUserInfo(secuserVO);
		JSONResponse jsonResponse = new JSONResponse();

		if (result > 0) {
			jsonResponse.setData(secuserVO);
			jsonResponse.setMessage("Updated SuccessFully");
			return ResponseEntity.status(200).body(jsonResponse);

		}
		jsonResponse.setMessage("Failed to update");
		return ResponseEntity.status(500).body(jsonResponse);

	}

	@PostMapping(value = ReqMappingConstants.SELF_SERVICE_PASS)
	public ResponseEntity<JSONResponse> selfServicePassword(@RequestBody Map<String, String> request)
			throws PasswordException {
		String userId = passwordService.checkParams(request.get("token"));
		int result = passwordService.changePassword(userId, request.get(NEW_PASS), "");

		return sendResponse(result, EEMConstants.PASS_CHANGED_SUCCESS);
	}

	@PostMapping(value = ReqMappingConstants.PASS_EXPIRED)
	public ResponseEntity<JSONResponse> passwordExpired(@RequestBody Map<String, String> request)
			throws PasswordException {
		int result = passwordService.changePassword(request.get("userId"), request.get(NEW_PASS), request.get("pwd"));

		return sendResponse(result, EEMConstants.PASS_CHANGED_SUCCESS);
	}

	@PostMapping(value = ReqMappingConstants.FORGOT_PASS)
	public ResponseEntity<JSONResponse> forgotPassword(@RequestBody QsnAnsVO qsnAnsVo, HttpServletRequest request) {
		QsnAnsVO userData = passwordService.getUserData(qsnAnsVo, request);

		JSONResponse jsonResponse = new JSONResponse();

		if (StringUtils.isNotBlank(userData.getMessage())) {
			jsonResponse.setMessage(EEMConstants.EMAIL_SENT);
		} else {
			jsonResponse.setData(userData);
			jsonResponse.setMessage("success");
		}

		return ResponseEntity.status(200).body(jsonResponse);

	}

	@GetMapping(value = ReqMappingConstants.PARM_VALIDATION)
	public ModelAndView parmValidation(@RequestParam("token") String token) throws PasswordException {
		try {
			String userId = passwordService.checkParams(token);

			String redirectUrlFinal = redirectUrl + userId + "/" + token;
			return new ModelAndView(redirectUrlFinal);
		} catch (Exception e) {
			throw new SimpleMessageException(e.getMessage());
		}

	}

	@PostMapping(value = ReqMappingConstants.USER_SETTING_UPDATE)
	public ResponseEntity<JSONResponse> updateUserSetting(@PathVariable("userId") String userId) {
		int userData = passwordService.updateUserSetting(userId);

		JSONResponse jsonResponse = new JSONResponse();

		if (Objects.nonNull(userData)) {
			jsonResponse.setData(userData);
			jsonResponse.setMessage("success");
			return ResponseEntity.status(200).body(jsonResponse);

		}
		return new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);

	}

	private ResponseEntity<JSONResponse> sendResponse(int result, String message) {
		JSONResponse jsonResponse = new JSONResponse();
		if (result > 0) {
			jsonResponse.setMessage(message);
			return new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}

		return new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
	}

}
