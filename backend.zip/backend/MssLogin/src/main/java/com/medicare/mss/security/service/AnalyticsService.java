package com.medicare.mss.security.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.medicare.mss.constant.EEMConstants;
import com.medicare.mss.util.CacheService;
import com.medicare.mss.util.CipherUtilService;
import com.medicare.mss.util.CommonUtils;
import com.medicare.mss.vo.AnalyticsVO;

@Service
public class AnalyticsService {

	@Autowired
	private CacheService sessionHelper;

	@Autowired
	public CipherUtilService cipherUtil;

	@Value("${spring.profiles.active}")
	private String profile;

	public AnalyticsVO getJasperToken(String orgId) {
		String localOrgId = null;
		String customerId = sessionHelper.getUserInfo().getCustomerId();
		String userId = sessionHelper.getUserInfo().getUserId();
		if ("dev".equals(profile)) {
			localOrgId = "Recon_Dev";
		} else if ("prod".equals(profile)) {
			if (orgId != null)
				localOrgId = CommonUtils.appendStrings(orgId, EEMConstants.UNDERSCORE, customerId,
						EEMConstants.UNDERSCORE, EEMConstants.JAS_PROD);
			else
				localOrgId = CommonUtils.appendStrings(EEMConstants.JAS_BASEPLUS, EEMConstants.UNDERSCORE, customerId,
						EEMConstants.UNDERSCORE, EEMConstants.JAS_PROD);

		} else {
			if (orgId != null)
				localOrgId = CommonUtils.appendStrings(orgId, EEMConstants.UNDERSCORE, customerId,
						EEMConstants.UNDERSCORE, EEMConstants.JAS_QA);
			else
				localOrgId = CommonUtils.appendStrings(EEMConstants.JAS_BASEPLUS, EEMConstants.UNDERSCORE, customerId,
						EEMConstants.UNDERSCORE, EEMConstants.JAS_QA);
		}

		return cipherUtil.getEncryptedToken(userId, localOrgId);
	}

}
