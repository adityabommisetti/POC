package com.medicare.mss.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

import com.medicare.mss.exception.ApplicationException;

/**
 * This class methods gets executed before execution of application methods.
 * 
 * @author Wipro
 *
 */
@Aspect
@Configuration
public class EEMAspect {

	private static final Logger LOG = LoggerFactory.getLogger(EEMAspect.class);

	/**
	 * This method executes if the method throws any exception.
	 * 
	 * @param joinPoint
	 *            Holds method name
	 * 
	 * @param result
	 *            exception thrown
	 * @throws ApplicationException
	 */
	@AfterThrowing(value = "com.medicare.mss.aop.CommonJoinPointConfig.allLayerExecution()", throwing = "exception")
	public void afterThrowing(JoinPoint joinPoint, Throwable exception) {
		Signature signature = joinPoint.getSignature();
		LOG.error(" method {} exited with throwing {}", signature, exception);

		if (LOG.isDebugEnabled()) {
			LOG.error("An exception occurred.", exception);
		}
	}

}
