package com.medicare.mss.security.domain;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class JasperTokenMasterDO {
	
		private String userName;

		private String tokenexpiryTimeStampFormat = "yyyyMMddHHmmZ";

		private List<String> roles = new ArrayList<>();

		private List<String> orgIDs = new ArrayList<>();

		private List<String> pa1List = new ArrayList<>();

		private List<String> pa2List = new ArrayList<>();

		private boolean isTokenExpiryTimeSet;

		public JasperTokenMasterDO() {
			super();
		}

		public JasperTokenMasterDO(String userName, String tokenexpiryTimeStampFormat, List<String> roles,
				List<String> orgIDs, List<String> pa1List, List<String> pa2List, boolean isTokenExpiryTimeSet) {
			super();
			this.userName = userName;
			this.tokenexpiryTimeStampFormat = tokenexpiryTimeStampFormat;
			this.roles = roles;
			this.orgIDs = orgIDs;
			this.pa1List = pa1List;
			this.pa2List = pa2List;
			this.isTokenExpiryTimeSet = isTokenExpiryTimeSet;
		}

		public String getUserName() {
			return userName;
		}

		public void setUserName(String userName) {
			this.userName = userName;
		}

		public String getTokenexpiryTimeStampFormat() {
			return tokenexpiryTimeStampFormat;
		}

		public void setTokenexpiryTimeStampFormat(String tokenexpiryTimeStampFormat) {
			this.tokenexpiryTimeStampFormat = tokenexpiryTimeStampFormat;
		}

		public List<String> getRoles() {
			return roles;
		}

		public void setRoles(List<String> roles) {
			this.roles = roles;
		}

		public List<String> getOrgIDs() {
			return orgIDs;
		}

		public void setOrgIDs(List<String> orgIDs) {
			this.orgIDs = orgIDs;
		}

		public List<String> getPa1List() {
			return pa1List;
		}

		public void setPa1List(List<String> pa1List) {
			this.pa1List = pa1List;
		}

		public List<String> getPa2List() {
			return pa2List;
		}

		public void setPa2List(List<String> pa2List) {
			this.pa2List = pa2List;
		}

		public boolean isTokenExpiryTimeSet() {
			return isTokenExpiryTimeSet;
		}

		public void setTokenExpiryTimeSet(boolean isTokenExpiryTimeSet) {
			this.isTokenExpiryTimeSet = isTokenExpiryTimeSet;
		}

		@Override
		public String toString() {
			return "JasperTokenMasterDO [userName=" + userName + ", tokenexpiryTimeStampFormat=" + tokenexpiryTimeStampFormat
					+ ", roles=" + roles + ", orgIDs=" + orgIDs + ", pa1List=" + pa1List + ", pa2List=" + pa2List
					+ ", isTokenExpiryTimeSet=" + isTokenExpiryTimeSet + "]";
		}

	}

