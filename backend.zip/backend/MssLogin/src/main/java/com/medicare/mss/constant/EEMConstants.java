package com.medicare.mss.constant;

/**
 * @author dkumar
 *
 */
public class EEMConstants {

	// private constructor to hide the implicit public one.
	private EEMConstants() {

	}

	// EEM Profile
	public static final String LOB_VALD = "LOB_VALD";
	public static final String PRINTIDC = "PRINTIDC";
	public static final String PRINTIDC_TEXT = "PRINTIDC_TEXT";
	public static final String SUPER_USER = "SUPUSER";
	public static final String AGENTDT = "AGENTDT";
	public static final String APPFIELDS = "APPFIELDS";
	public static final String DRAFTDAY = "DRAFTDAY";

	public static final String MBRIDLIT = "MBRIDLIT";
	public static final String ENBQUEST = "ENBQUEST";
	public static final String ENBQUESTVAL = "ENBQUESTVAL";
	public static final String TC73TRIG = "TC73TRIG";
	public static final String SUBSCID = "SUBSCID";
	public static final String SUBSCID_TEXT = "SUBSCID_TEXT";
	public static final String CAMPIDIND = "CAMPIDIND";
	public static final String CONTRNOIND = "CONTRNOIND";
	public static final String CMAEMRGIND = "CMAEMRGIND";
	public static final String SUPPLID = "SUPPLID";
	public static final String SUPPLID_TEXT = "SUPPLID_TEXT";
	public static final String LTC_QUES = "LTC_QUES";
	public static final String NOICD = "NOICD";
	public static final String ENBCMAQUES = "ENBCMAQUES";
	public static final String AUTOAPPLDT = "AUTOAPPLDT";
	public static final String VALSIGNAGT = "VALSIGNAGT";

	public static final String VALUE_YES = "Y";
	public static final String VALUE_NO = "N";
	public static final String BLANK = "";
	public static final String MBD_AGGREMENT = "MBD_DATA_USE";
	public static final String DEFAULT_TIMESTAMP_FORMAT = "yyyy-MM-dd HH:mm:ss.SSSSSS";

	public static final String MAX_SESSION_EXPIRED = "This session has been expired (possibly due to multiple concurrent logins being attempted as the same user)";
	public static final String LOG_OUT = "You have logged out Successfully";
	public static final String INVALID_CRED = "INVALID CREDENTIALS";
	public static final String FAILURE = "FAILURE";
	public static final String EMAIL_SENT = "Password Reset Link sent to your email address";
	public static final String EMAIL_SENT_FAILURE = "Email Sending failed!!!Please Try Again";

	/** Start SSO constants */
	public static final String INVALID_SSO_AUTHENTICATION = "Invalid SSO Authentication";
	public static final String INVALID_SAML_RESPONSE = "Invalid Saml Response";
	public static final String INVALID_SIGNATURE = "Invalid Signature";
	public static final String INVALID_ISSUER = "Invalid Issuer";
	public static final String SAML_RESP_ASSERTION_EXPIRED = "Saml Response Assertion Expired";
	public static final String CERTIFICATE_KEY_EXCEPTION = "Unauthorized Issuer";

	public static final String IDP_METADATA_FILE = "saml/GoogleIDPMetadata-devoted.com.xml";
	public static final String IDP_METADATA_X509CERTIFICATE = "ds:X509Certificate";
	public static final String SAML_CORE_SCHEMA_VALIDATOR = "saml2-core-schema-validator";
	public static final String SAML_CORE_SPEC_VALIDATOR = "saml2-core-spec-validator";
	public static final String METADATA_ENTITY_ID = "http://www.okta.com/exk18w5mteT9J3LAm357";
	public static final int MAX_CLOCK_SKEW_IN_MINUTES = 0;
	public static final String SAML_FIRST_NAME = "FirstName";
	public static final String SAML_LAST_NAME = "LastName";
	public static final String SAML_USER_ID = "UserId";
	public static final String SAML_EMAIL_ID = "EmailId";
	/** End SSO constants */
	public static final String PASS_CHANGED_SUCCESS = "Password Changed Successfully";
	public static final String PASS_FAILED = "Failed to update Password";

	public static final String AUTH_CACHE = "AUTHENTICATION";
	public static final String TOKEN = "TOKEN";
	public static final String SERVICES = "SERVICES";

	public static final String AUTH_TOKEN = "x-auth-token";
	public static final String AUTHORIZATION = "Authorization";
	public static final String PROFILE = "PROFILE";
	public static final String SESSION_EXPIRED = "Session Expired,Please Login Again";

	public static final String SOMETHING_WENT_WRONG = "Something Went Wrong!";
	public static final String SSO_USER_NOT_AUTHORIZED = "Sso User Not Authorized For This Service";
	public static final String INVALID_OLD_PASS = "Old password is incorrect";
	public static final String WRONG_ANSWER = "Wrong answer!";
	public static final String AUTH_SEC_QSNS_FAILED = "Authentication failed!";
	public static final String USER_ACCOUNT_LOCKED = "User Account is Locked!";
	public static final String INVALID_USER_ACCOUNT = "User Account is invalid!";

	public static final String MEDICARE_CIPHER_KEY = "ABCDEFGHIJKLMNOPQRSTUVWX";
	public static final String JAS_BASEPLUS = "Baseplus";
	public static final String UNDERSCORE = "_";
	public static final String JASDASH = "#/adhoc/Reports/Dashboard_Reports/New_Dashboard";
	public static final String JAS_QA = "QA";
	public static final String JAS_PROD = "Prod";

}
