package com.medicare.mss.aop;

import org.aspectj.lang.annotation.Pointcut;

/**
 * This class is used to define fully qualified execution end points.
 * 
 * @author Wipro
 *
 */
public class CommonJoinPointConfig {

	@Pointcut("within(com.medicare.mss..*) && !execution(* com.medicare.mss.util.JwtFilter.*(..)) && !execution(* com.medicare.mss.security.service.LoginService.*(..))")
	public void allLayerExecution() {
		// joinpoint for allLayerExecution
	}

}