package com.medicare.mss.security.domain;

import java.io.Serializable;

import com.medicare.mss.annotation.ColumnMapper;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class SecuserDO extends UserInfoDO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4721951237133644292L;

	private String userId;

	@ColumnMapper(columnName = "FIRST_NAME", propertyName = "firstName")
	private String firstName;

	@ColumnMapper(columnName = "ACTIVE_YN", propertyName = "activeInd")
	private String activeInd;

	@ColumnMapper(columnName = "GROUP_ID", propertyName = "groupId")
	private String groupId;

	@ColumnMapper(columnName = "SIGNEDON_YN", propertyName = "signOnY")
	private String signOnY;

	@ColumnMapper(columnName = "PWDEXPIRE_DATE", propertyName = "pwdExpireDate")
	private String pwdExpireDate;

	@ColumnMapper(columnName = "USER_PWD", propertyName = "password")
	private String password;

	@ColumnMapper(columnName = "LAST_NAME", propertyName = "lastName")
	private String lastName;

	@ColumnMapper(columnName = "PHONE", propertyName = "phoneNo")
	private String phoneNo;

	@ColumnMapper(columnName = "EMAIL", propertyName = "emailId")
	private String emailId;



}
