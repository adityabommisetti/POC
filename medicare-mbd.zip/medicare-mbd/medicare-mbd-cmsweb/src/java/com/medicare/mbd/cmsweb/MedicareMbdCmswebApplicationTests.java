package com.medicare.mbd.cmsweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicareMbdCmswebApplicationTests {

	@Test
	void contextLoads() {
	}

}
