package com.medicare.mbd.cmsweb.vo;

import java.math.BigDecimal;

import com.googlecode.jmapper.annotations.JMap;

import lombok.Data;

@Data
public class LowIncomeSubsidy {

	@JMap
	private String startDate = null;
	@JMap
	private String stopDate = null;
	@JMap
	private BigDecimal copaymentLevel = null;
	@JMap
	private BigDecimal premiumSubsidyPercent = null;

}
