package com.medicare.mbd.cmsweb.constants;

public class ReqMappingConstants {
	private ReqMappingConstants() {

	}

	public static final String BEQINFO = "/beneficiaryInfo";
}
