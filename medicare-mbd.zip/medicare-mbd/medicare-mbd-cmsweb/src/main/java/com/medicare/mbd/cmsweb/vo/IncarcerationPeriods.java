package com.medicare.mbd.cmsweb.vo;

import com.googlecode.jmapper.annotations.JMap;

import lombok.Data;

@Data
public class IncarcerationPeriods {

	@JMap
	private String startDate;

	@JMap
	private String stopDate;
}
