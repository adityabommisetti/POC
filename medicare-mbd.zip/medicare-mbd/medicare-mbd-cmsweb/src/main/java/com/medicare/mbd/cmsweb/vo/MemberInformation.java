package com.medicare.mbd.cmsweb.vo;

import lombok.Data;

@Data
public class MemberInformation {

	private String memberId = null;

	private String firstName = null;

	private String middleInitial = null;

	private String lastName = null;

	private String birthDate = null;

	private String deathDate = null;

	private String gender = null;

	private String race = null;

	private String county = null;

	private String state = null;

	private String zipCode = null;

	private String partAEntitleStartDate = null;
	private String partAEntitleStopDate = null;
	private String partBEntitleStartDate = null;
	private String partBEntitleStopDate = null;
	private String partDEligbilityStartDate = null;

	private String planEnrollDate = null;
	private String coplanEnrollDate = null;
	private String planDisenrollDate = null;
	private String coplanDisenrollDate = null;
	private String planID = null;
	private String coplanID = null;
	private String planPBPID = null;
	private String coplanPBPID = null;
	private String planDrugID = null;
	private String coplanDrugID = null;
	private String planTypeCode = null;
	private String coplanTypeCode = null;
	private String planEnrollSrcID = null;
	private String coplanEnrollSrcID = null;
	private Boolean planEGHPIND;
	private Boolean coplanEGHPIND;

	private String prior1PlanEnrollDt = null;
	private String prior2PlanEnrollDt = null;
	private String prior1PlanDisenrollDt = null;
	private String prior2PlanDisenrollDt = null;
	private String prior1PlanID = null;
	private String prior2PlanID = null;
	private String prior1PlanPBP = null;
	private String prior2PlanPBP = null;
	private String prior1PlanDrugID = null;
	private String prior2PlanDrugID = null;
	private String prior1PlanTypeCode = null;
	private String prior2PlanTypeCode = null;
	private String prior1PlanEnrollSrcID = null;
	private String prior2PlanEnrollSrcID = null;
	private Boolean prior1PlanEGHPIND;
	private Boolean prior2PlanEGHPIND;

	private Boolean hasMedicaid;

	private String hospiceStartDate = null;
	private String hospiceStopDate = null;

	private String esrdIndicator = null;
	private String esrdStartDate = null;
	private String esrdStopDate = null;

	private String medicaidStartDate = null;
	private String medicaidStopDate = null;

	private String institutionStartDate = null;
	private String institutionStopDate = null;

}
