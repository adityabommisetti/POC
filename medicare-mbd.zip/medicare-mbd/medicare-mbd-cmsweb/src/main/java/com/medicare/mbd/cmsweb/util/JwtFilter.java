package com.medicare.mbd.cmsweb.util;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Objects;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Service;
import org.springframework.web.filter.OncePerRequestFilter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.medicare.mbd.cmsweb.constants.GlobalConstants;
import com.medicare.mbd.cmsweb.helper.ApiError;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.SignatureException;

@Service
public class JwtFilter extends OncePerRequestFilter {

	@Autowired
	private JwtUtil jwtUtils;

	@Autowired
	private MyUserDetailsService userDetailsService;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		String jwtToken = null;
		String userId = null;
		final String authTokenHeader = request.getHeader(GlobalConstants.AUTH_TOKEN);

		if (Objects.nonNull(authTokenHeader) && authTokenHeader.startsWith("Bearer ")) {
			jwtToken = authTokenHeader.substring(7);
			try {
				userId = jwtUtils.extaractUserName(jwtToken);
			} catch (ExpiredJwtException exp) {
				logger.error("Token Expired", exp);
				sendError(response, GlobalConstants.TOKEN_EXPIRED);
				return;
			} catch (SignatureException exp) {
				sendError(response, "UnAuthorized");
				return;
			}
		}

		if (Objects.nonNull(userId) && !Objects.nonNull(SecurityContextHolder.getContext().getAuthentication()))

		{
			Boolean tokenValidatorFlag = jwtUtils.validateToken(jwtToken);
			if (Boolean.TRUE.equals(tokenValidatorFlag)) {

				UserDetails userDetails = userDetailsService.loadUserByUsername(userId);

				UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(
						userDetails, null, userDetails.getAuthorities());
				usernamePasswordAuthenticationToken
						.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
				SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
			}

		}
		filterChain.doFilter(request, response);

	}

	private void sendError(HttpServletResponse response, String msg) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		ApiError apiResponse = new ApiError("403", HttpStatus.FORBIDDEN, msg);
		response.setStatus(403);
		PrintWriter writer = response.getWriter();
		writer.write(mapper.writeValueAsString(apiResponse));
	}

}
