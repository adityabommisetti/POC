package com.medicare.mbd.cmsweb.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.mbd.cmsweb.constants.GlobalConstants;
import com.medicare.mbd.cmsweb.util.CommonUtils;
import com.medicare.mbd.cmsweb.util.DateValidatorUtil;
import com.medicare.mbd.cmsweb.vo.BeqRequestVO;
import com.medicare.mbd.cmsweb.vo.BeqResponseVO;
import com.medicare.mbd.cmsweb.vo.MemberInformation;
import com.medicare.mbd.cmsweb.vo.ResponseStatus;
import com.medicare.mbd.cmswrapper.client.ApiException;
import com.medicare.mbd.cmswrapper.client.model.BEQRequest;
import com.medicare.mbd.cmswrapper.client.model.BEQRequest.BeneficiaryGenderEnum;
import com.medicare.mbd.cmswrapper.client.model.BEQResponse;
import com.medicare.mbd.cmswrapper.service.MbdService;

/*
 * BeqService class 
 * It validates the request and transacts the request to cms wrapper service, 
 * then maps the cms response to the local response object.
 * 
 */
@Service
public class BeqService {

	@Autowired
	private MbdService mbdService;

	@Autowired
	private BeanMapperService beanMapper;

	/*
	 * requestValidation - The following function validates the request parameters.
	 * 
	 * @param BeqRequestVO the request object
	 * 
	 * @return BeqResponseVO the response Object
	 * 
	 * 
	 * 
	 */

	public BeqResponseVO requestValidation(BeqRequestVO beqRequestVO) {

		List<ResponseStatus> statusList = new ArrayList<>();
		BeqResponseVO beqResponseVO = new BeqResponseVO();
		boolean validationFlag = false;
		DateValidatorUtil dateFormat = new DateValidatorUtil();
		dateFormat.setDateFormat(GlobalConstants.DATE_FORMAT);
		if (beqRequestVO.getBeneficiaryIdentifier().contains("-")) {
			ResponseStatus respStatus = new ResponseStatus();
			respStatus.setCodeName(GlobalConstants.INVALID_IDENTIFIER_CODE);
			respStatus.setCode(GlobalConstants.INVALID_IDENTIFIER_CODE);
			respStatus.setDescription(GlobalConstants.INVALID_IDENTIFIER_DESCRIPTION);
			statusList.add(respStatus);
			beqResponseVO.setStatus(statusList);
			validationFlag = true;
		}

		if (Boolean.FALSE.equals(dateFormat.isValid(beqRequestVO.getBeneficiaryBirthDate()))) {
			ResponseStatus respStatus = new ResponseStatus();
			respStatus.setCodeName(GlobalConstants.INVALID_BIRTHDATEFORMAT_CODENAME);
			respStatus.setCode(GlobalConstants.INVALID_BIRTHDATEFORMAT_CODE);
			respStatus.setDescription(GlobalConstants.INVALID_BIRTHDATEFORMAT_DESCRIPTION);
			statusList.add(respStatus);
			beqResponseVO.setStatus(statusList);
			validationFlag = true;
		}

		if (Objects.nonNull(beqRequestVO.getCoverageEffectiveDate())
				&& Boolean.FALSE.equals(dateFormat.isValid(beqRequestVO.getCoverageEffectiveDate()))) {
			ResponseStatus respStatus = new ResponseStatus();
			respStatus.setCodeName(GlobalConstants.INVALID_COVERAGEDATE_CODENAME);
			respStatus.setCode(GlobalConstants.INVALID_COVERAGEDATE_CODE);
			respStatus.setDescription(GlobalConstants.INVALID_COVERAGEDATE_DESCRIPTION);
			statusList.add(respStatus);
			beqResponseVO.setStatus(statusList);
			validationFlag = true;
		}

		if (Objects.nonNull(beqRequestVO.getRequestorTransactionId())
				&& beqRequestVO.getRequestorTransactionId().length() > 50) {
			ResponseStatus respStatus = new ResponseStatus();
			respStatus.setCodeName(GlobalConstants.INVALID_REQ_TRANSACTION_CODENAME);
			respStatus.setCode(GlobalConstants.INVALID_REQ_TRANSACTION_CODE);
			respStatus.setDescription(GlobalConstants.INVALID_REQ_TRANSACTION_DESCRIPTION);
			statusList.add(respStatus);
			beqResponseVO.setStatus(statusList);
			validationFlag = true;
		}

		if (beqRequestVO.getGender() != null && !(beqRequestVO.getGender().equals("M")
				|| beqRequestVO.getGender().equals("F") || beqRequestVO.getGender().equals("U"))) {
			ResponseStatus respStatus = new ResponseStatus();
			respStatus.setCodeName(GlobalConstants.INVALID_GENDER_CODENAME);
			respStatus.setCode(GlobalConstants.INVALID_GENDER_CODE);
			respStatus.setDescription(GlobalConstants.INVALID_GENDER_DESCRIPTION);
			statusList.add(respStatus);
			beqResponseVO.setStatus(statusList);
			validationFlag = true;

		}

		if (validationFlag) {
			beqResponseVO.setRequest(beqRequestVO);
			return beqResponseVO;
		} else {
			return null;
		}
	}

	/*
	 * The following function calls the cmsWrapper module service.
	 * 
	 * @param BeqRequestVO the request object
	 * 
	 * @return BeqResponseVO the response Object
	 * 
	 * @throws ApiException If fail to call the API
	 * 
	 * 
	 */
	public BeqResponseVO cmsServiceCall(BeqRequestVO beqRequestMember) throws ApiException {
		BEQResponse beqResponse;
		BEQRequest beqRequestObj = new BEQRequest();
		BeqResponseVO beqResponseVO = new BeqResponseVO();

		beqRequestObj.setRequestorTransactionId(beqRequestMember.getRequestorTransactionId());
		
		beqRequestObj.setBeneficiaryBirthDate(beqRequestMember.getBeneficiaryBirthDate());

		beqRequestObj.setBeneficiaryIdentifier(beqRequestMember.getBeneficiaryIdentifier());

		BeneficiaryGenderEnum memberGender = null;
		if (Objects.nonNull(beqRequestMember.getGender())) {
			if (beqRequestMember.getGender().equals("M"))
				memberGender = BeneficiaryGenderEnum.valueOf("_1_M");
			else if (beqRequestMember.getGender().equals("F"))
				memberGender = BeneficiaryGenderEnum.valueOf("_2_F");
			else if (beqRequestMember.getGender().equals("U"))
				memberGender = BeneficiaryGenderEnum.valueOf("_0_U");
			beqRequestObj.setBeneficiaryGender(memberGender);
		}

		beqRequestObj.setCoverageEffectiveDate(beqRequestMember.getCoverageEffectiveDate());

		beqRequestObj.setSenderContractNumber(beqRequestMember.getSenderContractNumber());

		beqResponse = mbdService.fetchCmsBeqData(beqRequestObj);

		if (beqResponse.getRequest() != null)
			beqResponseVO.setRequest(beanMapper.requestBeanMapper(beqResponse.getRequest()));

		if (CommonUtils.isNotNullAndNotEmpty(beqResponse.getResponseCodes()))
			beqResponseVO.setStatus(beanMapper.responseStatusMapper(beqResponse.getResponseCodes()));

		beqResponseVO.setMemberInformation(memberInfoMapper(beqResponse));

		if (CommonUtils.isNotNullAndNotEmpty(beqResponse.getPartDEnrollmentPeriods()))
			beqResponseVO.setPartDEnrollment(beanMapper.partDEnrollmentMapper(beqResponse.getPartDEnrollmentPeriods()));

		if (CommonUtils.isNotNullAndNotEmpty(beqResponse.getRetireeDrugCoverage()))
			beqResponseVO
					.setRetireeDrugCoverage(beanMapper.retireeDrugCoverageMapper(beqResponse.getRetireeDrugCoverage()));

		if (CommonUtils.isNotNullAndNotEmpty(beqResponse.getLowIncomeSubsidyPeriods()))
			beqResponseVO
					.setLowIncomeSubsidy(beanMapper.lowIncomeSubsidyMapper(beqResponse.getLowIncomeSubsidyPeriods()));

		if (CommonUtils.isNotNullAndNotEmpty(beqResponse.getUncoveredMonths()))
			beqResponseVO.setUncoveredMonths(beanMapper.uncoveredMonthsMapper(beqResponse.getUncoveredMonths()));

		if (CommonUtils.isNotNullAndNotEmpty(beqResponse.getIncarcerationPeriods()))
			beqResponseVO.setIncarcerationPeriods(
					beanMapper.incarcerationPeriodsMapper(beqResponse.getIncarcerationPeriods()));

		if (CommonUtils.isNotNullAndNotEmpty(beqResponse.getNotLawfulPresencePeriods()))
			beqResponseVO.setNotLawfulPresencePeriods(
					beanMapper.notLawfulPresencePeriodsMapper(beqResponse.getNotLawfulPresencePeriods()));

		if (CommonUtils.isNotNullAndNotEmpty(beqResponse.getCaraPeriods()))
			beqResponseVO.setCaraPeriods(null);

		if (CommonUtils.isNotNullAndNotEmpty(beqResponse.getInactiveMBI()))
			beqResponseVO.setInactiveMBI(beanMapper.inactiveMBIMapper(beqResponse.getInactiveMBI()));

		return beqResponseVO;
	}

	/*
	 * The following function validates the request before call.
	 * 
	 * @param BeqRequestVO the request object
	 * 
	 * @return BeqResponseVO the response Object
	 * 
	 * @throws ApiException If fail to call the API
	 * 
	 * 
	 */

	public BeqResponseVO validateBeforeServiceCall(BeqRequestVO beqRequestVO) throws ApiException {

		BeqResponseVO beqResponse = requestValidation(beqRequestVO);
		if (Objects.nonNull(beqResponse)) {
			return beqResponse;

		} else {
			return cmsServiceCall(beqRequestVO);

		}

	}

	/**
	 * Member InfoMapper - Maps the MemberInformation Objects from CMS response
	 * 
	 * @param BEQResponse
	 * @return MemberInformation;
	 * 
	 */
	public MemberInformation memberInfoMapper(BEQResponse beqResponse) {
		MemberInformation memberInfo = new MemberInformation();
		if (Objects.nonNull(beqResponse.getBeneficiaryInformation())) {
			memberInfo.setMemberId(beqResponse.getBeneficiaryInformation().getBeneficiaryIdentificationCode());
			memberInfo.setFirstName(beqResponse.getBeneficiaryInformation().getFirstName());
			memberInfo.setLastName(beqResponse.getBeneficiaryInformation().getLastName());
			memberInfo.setMiddleInitial(beqResponse.getBeneficiaryInformation().getMiddleInitial());
			memberInfo.setBirthDate(beqResponse.getBeneficiaryInformation().getBirthDate());
			memberInfo.setDeathDate(beqResponse.getBeneficiaryInformation().getDeathDate());
			memberInfo.setGender(beqResponse.getBeneficiaryInformation().getGender());
			memberInfo.setRace(beqResponse.getBeneficiaryInformation().getRace());
		}
		if (Objects.nonNull(beqResponse.getMailingAddress())) {
			memberInfo.setCounty(beqResponse.getMailingAddress().getCity());
			memberInfo.setState(beqResponse.getMailingAddress().getPostalStateCode());
			memberInfo.setZipCode(beqResponse.getMailingAddress().getZipCode());
		}
		if (CommonUtils.isNotNullAndNotEmpty(beqResponse.getPartAEntitlementPeriods())) {
			memberInfo.setPartAEntitleStartDate(beqResponse.getPartAEntitlementPeriods().get(0).getStartDate());
			memberInfo.setPartAEntitleStopDate(beqResponse.getPartAEntitlementPeriods().get(0).getStopDate());
		}
		if (CommonUtils.isNotNullAndNotEmpty(beqResponse.getPartBEntitlementPeriods())) {
			memberInfo.setPartBEntitleStartDate(beqResponse.getPartBEntitlementPeriods().get(0).getStartDate());
			memberInfo.setPartBEntitleStopDate(beqResponse.getPartBEntitlementPeriods().get(0).getStopDate());

		}
		if (CommonUtils.isNotNullAndNotEmpty(beqResponse.getPartDEligibilityPeriods())) {
			memberInfo.setPartDEligbilityStartDate(beqResponse.getPartDEligibilityPeriods().get(0).getStartDate());
		}

		if (CommonUtils.isNotNullAndNotEmpty(beqResponse.getCurrentEnrollmentPeriods())) {
			memberInfo.setPlanEnrollDate(beqResponse.getCurrentEnrollmentPeriods().get(0).getEnrollmentDate());
			memberInfo.setPlanDisenrollDate(beqResponse.getCurrentEnrollmentPeriods().get(0).getDisenrollmentDate());
			memberInfo.setPlanID(beqResponse.getCurrentEnrollmentPeriods().get(0).getContractNumber());
			memberInfo.setPlanPBPID(beqResponse.getCurrentEnrollmentPeriods().get(0).getPlanBenefitPackageNumber());
			memberInfo.setPlanDrugID(beqResponse.getCurrentEnrollmentPeriods().get(0).getProgramType());
			memberInfo.setPlanTypeCode(beqResponse.getCurrentEnrollmentPeriods().get(0).getPlanType());
			memberInfo.setPlanEnrollSrcID(beqResponse.getCurrentEnrollmentPeriods().get(0).getSourceType());
			memberInfo.setPlanEGHPIND(beqResponse.getCurrentEnrollmentPeriods().get(0).isIsEmployerGroupHealthPlan());

			if (beqResponse.getCurrentEnrollmentPeriods().size() > 1) {
				memberInfo.setCoplanEnrollDate(beqResponse.getCurrentEnrollmentPeriods().get(1).getEnrollmentDate());
				memberInfo.setCoplanDisenrollDate(
						beqResponse.getCurrentEnrollmentPeriods().get(1).getDisenrollmentDate());
				memberInfo.setCoplanID(beqResponse.getCurrentEnrollmentPeriods().get(1).getContractNumber());
				memberInfo
						.setCoplanPBPID(beqResponse.getCurrentEnrollmentPeriods().get(1).getPlanBenefitPackageNumber());
				memberInfo.setCoplanDrugID(beqResponse.getCurrentEnrollmentPeriods().get(1).getProgramType());
				memberInfo.setCoplanTypeCode(beqResponse.getCurrentEnrollmentPeriods().get(1).getPlanType());
				memberInfo.setCoplanEnrollSrcID(beqResponse.getCurrentEnrollmentPeriods().get(1).getSourceType());
				memberInfo.setCoplanEGHPIND(
						beqResponse.getCurrentEnrollmentPeriods().get(1).isIsEmployerGroupHealthPlan());
			}
		}

		if (CommonUtils.isNotNullAndNotEmpty(beqResponse.getPriorEnrollmentPeriods())) {
			memberInfo.setPrior1PlanEnrollDt(beqResponse.getPriorEnrollmentPeriods().get(0).getEnrollmentDate());
			memberInfo.setPrior1PlanDisenrollDt(beqResponse.getPriorEnrollmentPeriods().get(0).getDisenrollmentDate());
			memberInfo.setPrior1PlanID(beqResponse.getPriorEnrollmentPeriods().get(0).getContractNumber());
			memberInfo.setPrior1PlanPBP(beqResponse.getPriorEnrollmentPeriods().get(0).getPlanBenefitPackageNumber());
			memberInfo.setPrior1PlanDrugID(beqResponse.getPriorEnrollmentPeriods().get(0).getProgramType());
			memberInfo.setPrior1PlanTypeCode(beqResponse.getPriorEnrollmentPeriods().get(0).getPlanType());
			memberInfo.setPrior1PlanEnrollSrcID(beqResponse.getPriorEnrollmentPeriods().get(0).getSourceType());
			memberInfo
					.setPrior1PlanEGHPIND(beqResponse.getPriorEnrollmentPeriods().get(0).isIsEmployerGroupHealthPlan());

			if (beqResponse.getPriorEnrollmentPeriods().size() > 1) {
				memberInfo.setPrior2PlanEnrollDt(beqResponse.getPriorEnrollmentPeriods().get(1).getEnrollmentDate());
				memberInfo.setPrior2PlanDisenrollDt(
						beqResponse.getPriorEnrollmentPeriods().get(1).getDisenrollmentDate());
				memberInfo.setPrior2PlanID(beqResponse.getPriorEnrollmentPeriods().get(1).getContractNumber());
				memberInfo
						.setPrior2PlanPBP(beqResponse.getPriorEnrollmentPeriods().get(1).getPlanBenefitPackageNumber());
				memberInfo.setPrior2PlanDrugID(beqResponse.getPriorEnrollmentPeriods().get(1).getProgramType());
				memberInfo.setPrior2PlanTypeCode(beqResponse.getPriorEnrollmentPeriods().get(1).getPlanType());
				memberInfo.setPrior2PlanEnrollSrcID(beqResponse.getPriorEnrollmentPeriods().get(1).getSourceType());
				memberInfo.setPrior2PlanEGHPIND(
						beqResponse.getPriorEnrollmentPeriods().get(1).isIsEmployerGroupHealthPlan());
			}
		}

		medicaidMapper(memberInfo, beqResponse);

		if (CommonUtils.isNotNullAndNotEmpty(beqResponse.getHospicePeriods())) {
			memberInfo.setHospiceStartDate(beqResponse.getHospicePeriods().get(0).getStartDate());
			memberInfo.setHospiceStopDate(beqResponse.getHospicePeriods().get(0).getStopDate());
		}

		if (CommonUtils.isNotNullAndNotEmpty(beqResponse.getEsrdCoveragePeriods())) {
			memberInfo.setEsrdIndicator(beqResponse.getEsrdCoveragePeriods().get(0).getEsrdIndicator());
			memberInfo.setEsrdStartDate(beqResponse.getEsrdCoveragePeriods().get(0).getStartDate());
			memberInfo.setEsrdStopDate(beqResponse.getEsrdCoveragePeriods().get(0).getStopDate());

		}

		if (CommonUtils.isNotNullAndNotEmpty(beqResponse.getMedicaidPeriods())) {
			memberInfo.setMedicaidStartDate(beqResponse.getMedicaidPeriods().get(0).getStartDate());
			memberInfo.setMedicaidStopDate(beqResponse.getMedicaidPeriods().get(0).getStopDate());
		}

		if (CommonUtils.isNotNullAndNotEmpty(beqResponse.getInstitutionalPeriods())) {
			memberInfo.setInstitutionStartDate(beqResponse.getInstitutionalPeriods().get(0).getStartDate());
			memberInfo.setInstitutionStopDate(beqResponse.getInstitutionalPeriods().get(0).getStopDate());
		}

		return memberInfo;
	}

	/*
	 * The following method is used to set the medicaid id details of the
	 * beneficiary member It is separated from its parent function to reduce the
	 * cognitive complexity
	 * 
	 * @param MemberInformation, BEQResponse
	 * 
	 */
	public void medicaidMapper(MemberInformation localmemberInfo, BEQResponse resp) {
		if (Objects.nonNull(resp.isHasMedicaid())) {
			localmemberInfo.setHasMedicaid(resp.isHasMedicaid());
		}

	}
}
