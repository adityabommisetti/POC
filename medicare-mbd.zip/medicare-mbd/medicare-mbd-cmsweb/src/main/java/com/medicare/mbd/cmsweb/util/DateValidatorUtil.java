package com.medicare.mbd.cmsweb.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/*
 * Date Validation Helper Class
 * 
 */
public class DateValidatorUtil {

	private String dateFormat;

	public String getDateFormat() {
		return dateFormat;
	}

	public void setDateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}

	/*
	 * To check if the date Format is valid or not.
	 * 
	 * @param String date
	 * 
	 * @return boolean
	 * 
	 */
	public boolean isValid(String dateStr) {
		DateFormat sdf = new SimpleDateFormat(this.dateFormat);
		sdf.setLenient(false);
		try {
			sdf.parse(dateStr);
		} catch (ParseException e) {
			return false;
		}
		return true;
	}
}
