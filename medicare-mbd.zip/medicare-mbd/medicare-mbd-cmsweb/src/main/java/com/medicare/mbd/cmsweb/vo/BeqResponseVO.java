package com.medicare.mbd.cmsweb.vo;

import java.util.List;

import lombok.Data;

@Data
public class BeqResponseVO {

	private BeqRequestVO request = null;

	private List<ResponseStatus> status = null;

	private MemberInformation memberInformation = null;

	private List<PartDEnrollment> partDEnrollment = null;

	private List<RetireeDrugCoverage> retireeDrugCoverage = null;

	private List<LowIncomeSubsidy> lowIncomeSubsidy = null;

	private List<UncoveredMonths> uncoveredMonths = null;

	private List<IncarcerationPeriods> incarcerationPeriods = null;

	private List<NotLawfulPresencePeriods> notLawfulPresencePeriods = null;

	private List<CaraPeriods> caraPeriods = null;

	private List<InactiveMBI> inactiveMBI = null;

}
