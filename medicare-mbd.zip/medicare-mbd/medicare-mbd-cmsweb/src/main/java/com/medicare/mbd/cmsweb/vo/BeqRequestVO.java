package com.medicare.mbd.cmsweb.vo;

import javax.validation.constraints.NotBlank;

import com.googlecode.jmapper.annotations.JMap;
import com.medicare.mbd.cmsweb.constants.GlobalConstants;

import lombok.Data;

@Data
public class BeqRequestVO {

	private String appName;

	@JMap
	private String requestorTransactionId;

	@JMap
	@NotBlank(message = GlobalConstants.NO_IDENTIFIER_MESSAGE)
	private String beneficiaryIdentifier;

	@JMap
	@NotBlank(message = GlobalConstants.NO_BIRTHDATE_MESSAGE)
	private String beneficiaryBirthDate;

	@JMap
	private String coverageEffectiveDate;

	@JMap
	private String senderContractNumber;

	private String gender;

}
