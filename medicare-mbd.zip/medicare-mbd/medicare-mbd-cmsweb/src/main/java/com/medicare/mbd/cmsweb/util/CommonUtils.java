package com.medicare.mbd.cmsweb.util;

import java.util.List;

public class CommonUtils {

	private CommonUtils() {
	}

	/*
	 * The following method checks if a Collection is not null and not empty.
	 * 
	 * @param List<?>
	 * 
	 * @return boolean
	 */

	public static boolean isNotNullAndNotEmpty(List<?> collection) {

		return (collection != null && !collection.isEmpty());
	}
}
