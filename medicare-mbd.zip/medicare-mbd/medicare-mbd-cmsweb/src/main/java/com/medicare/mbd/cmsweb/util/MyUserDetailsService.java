package com.medicare.mbd.cmsweb.util;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class MyUserDetailsService implements UserDetailsService {

	private String userIdInstance = "";

	public String getUserIdInstance() {
		return userIdInstance;
	}

	public void setUserIdInstance(String userIdInstance) {
		this.userIdInstance = userIdInstance;
	}

	@Override
	public UserDetails loadUserByUsername(String userId) {
		this.setUserIdInstance(userId);
		// userId is fetched from jwt token.
		return new User(userId, "password", new ArrayList<>());
	}
}
