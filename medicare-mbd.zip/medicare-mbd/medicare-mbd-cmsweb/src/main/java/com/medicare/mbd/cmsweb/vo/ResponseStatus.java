package com.medicare.mbd.cmsweb.vo;

import com.googlecode.jmapper.annotations.JMap;

import lombok.Data;

@Data
public class ResponseStatus {

	@JMap
	private String codeName = null;

	@JMap
	private String code = null;

	@JMap
	private String description = null;
}
