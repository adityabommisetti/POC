package com.medicare.mbd.cmsweb.vo;

import com.googlecode.jmapper.annotations.JMap;

import lombok.Data;

@Data
public class InactiveMBI {

	@JMap
	private String effectiveDate = null;

	@JMap
	private String terminationDate = null;

	@JMap("medicareBeneficiaryIdentifier")
	private String medicareId = null;
}
