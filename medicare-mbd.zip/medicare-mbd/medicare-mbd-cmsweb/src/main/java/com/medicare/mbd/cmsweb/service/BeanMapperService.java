package com.medicare.mbd.cmsweb.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.googlecode.jmapper.JMapper;
import com.medicare.mbd.cmsweb.vo.BeqRequestVO;
import com.medicare.mbd.cmsweb.vo.InactiveMBI;
import com.medicare.mbd.cmsweb.vo.IncarcerationPeriods;
import com.medicare.mbd.cmsweb.vo.LowIncomeSubsidy;
import com.medicare.mbd.cmsweb.vo.NotLawfulPresencePeriods;
import com.medicare.mbd.cmsweb.vo.PartDEnrollment;
import com.medicare.mbd.cmsweb.vo.ResponseStatus;
import com.medicare.mbd.cmsweb.vo.RetireeDrugCoverage;
import com.medicare.mbd.cmsweb.vo.UncoveredMonths;
import com.medicare.mbd.cmswrapper.client.model.BEQInactiveMbi;
import com.medicare.mbd.cmswrapper.client.model.BEQLowIncomeSubsidy;
import com.medicare.mbd.cmswrapper.client.model.BEQPeriod;
import com.medicare.mbd.cmswrapper.client.model.BEQRequest;
import com.medicare.mbd.cmswrapper.client.model.BEQResponseCode;
import com.medicare.mbd.cmswrapper.client.model.BEQUncoveredMonths;

/*
 * BeanMapperService 
 * The following class is used to map the wrapper response object to the local response objects 
 * Jmapper is used here for mapping the objects.
 * 
 * 
 */
@Service
public class BeanMapperService {

	/*
	 * InactiveMBIMapper
	 * 
	 * @param List<BEQInactiveMBI> cms wrapper response object
	 * 
	 * @return List<InactiveMBI> webmodule response object
	 * 
	 */

	public List<InactiveMBI> inactiveMBIMapper(List<BEQInactiveMbi> beqInactiveMbiDTOList) {

		JMapper<InactiveMBI, BEQInactiveMbi> beanMapper = new JMapper<>(InactiveMBI.class, BEQInactiveMbi.class);

		List<InactiveMBI> inactiveMbiVO = new ArrayList<>();
		for (BEQInactiveMbi inactiveMbiDTOElement : beqInactiveMbiDTOList) {
			inactiveMbiVO.add(beanMapper.getDestination(inactiveMbiDTOElement));
		}
		return inactiveMbiVO;

	}

	/*
	 * PartDEnrollment
	 * 
	 * @param List<BEQPeriod> cms wrapper response object
	 * 
	 * @return List<PartDEnrollment> web module response object
	 * 
	 */
	public List<PartDEnrollment> partDEnrollmentMapper(List<BEQPeriod> partDEnrollmentPeriods) {

		JMapper<PartDEnrollment, BEQPeriod> beanMapper = new JMapper<>(PartDEnrollment.class, BEQPeriod.class);

		List<PartDEnrollment> partDEnrollmentVO = new ArrayList<>();
		for (BEQPeriod partDEnrollmentDTOElement : partDEnrollmentPeriods) {
			partDEnrollmentVO.add(beanMapper.getDestination(partDEnrollmentDTOElement));
		}
		return partDEnrollmentVO;

	}

	/*
	 * retireeDrugCoverageMapper
	 * 
	 * @param List<BEQPeriod> cms wrapper response object
	 * 
	 * @return List<RetireeDrugCoverage> web module response object
	 * 
	 */
	public List<RetireeDrugCoverage> retireeDrugCoverageMapper(List<BEQPeriod> retireeDrugCoverage) {
		JMapper<RetireeDrugCoverage, BEQPeriod> beanMapper = new JMapper<>(RetireeDrugCoverage.class, BEQPeriod.class);

		List<RetireeDrugCoverage> retireeDrugCoverageVO = new ArrayList<>();
		for (BEQPeriod retireeDrugCoverageDTOElement : retireeDrugCoverage) {
			retireeDrugCoverageVO.add(beanMapper.getDestination(retireeDrugCoverageDTOElement));
		}
		return retireeDrugCoverageVO;
	}

	/*
	 * lowIncomeSubsidyMapper
	 * 
	 * @param List<BEQLowIncomeSubsidy> cms wrapper response object
	 * 
	 * @return List<LowIncomeSubsidy> web module response object
	 * 
	 */
	public List<LowIncomeSubsidy> lowIncomeSubsidyMapper(List<BEQLowIncomeSubsidy> lowIncomeSubsidyPeriods) {
		JMapper<LowIncomeSubsidy, BEQLowIncomeSubsidy> beanMapper = new JMapper<>(LowIncomeSubsidy.class,
				BEQLowIncomeSubsidy.class);

		List<LowIncomeSubsidy> lowIncomeSubsidyPeriodsVO = new ArrayList<>();
		for (BEQLowIncomeSubsidy lowIncomeSubsidyPeriodsDTOElement : lowIncomeSubsidyPeriods) {
			lowIncomeSubsidyPeriodsVO.add(beanMapper.getDestination(lowIncomeSubsidyPeriodsDTOElement));
		}
		return lowIncomeSubsidyPeriodsVO;
	}

	/*
	 * notLawfulPresencePeriodsMapper
	 * 
	 * @param List<BEQPeriod> cms wrapper response object
	 * 
	 * @return List<NotLawfulPresencePeriods> web module response object
	 * 
	 */
	public List<NotLawfulPresencePeriods> notLawfulPresencePeriodsMapper(List<BEQPeriod> notLawfulPresencePeriods) {
		JMapper<NotLawfulPresencePeriods, BEQPeriod> beanMapper = new JMapper<>(NotLawfulPresencePeriods.class,
				BEQPeriod.class);

		List<NotLawfulPresencePeriods> notLawfulPresencePeriodsVO = new ArrayList<>();
		for (BEQPeriod notLawfulPresencePeriodsDTOElement : notLawfulPresencePeriods) {
			notLawfulPresencePeriodsVO.add(beanMapper.getDestination(notLawfulPresencePeriodsDTOElement));
		}

		return notLawfulPresencePeriodsVO;
	}

	/*
	 * incarcerationPeriodsMapper
	 * 
	 * @param List<BEQPeriod> cms wrapper response object
	 * 
	 * @return List<IncarcerationPeriods> webmodule response object
	 * 
	 */

	public List<IncarcerationPeriods> incarcerationPeriodsMapper(List<BEQPeriod> incarcerationPeriods) {
		JMapper<IncarcerationPeriods, BEQPeriod> beanMapper = new JMapper<>(IncarcerationPeriods.class,
				BEQPeriod.class);

		List<IncarcerationPeriods> incarcerationPeriodsVO = new ArrayList<>();
		for (BEQPeriod incarcerationPeriodsDTOElement : incarcerationPeriods) {
			incarcerationPeriodsVO.add(beanMapper.getDestination(incarcerationPeriodsDTOElement));
		}
		return incarcerationPeriodsVO;
	}

	/*
	 * uncoveredMonthsMapper
	 * 
	 * @param List<EQUncoveredMonths> cms wrapper response object
	 * 
	 * @return List<UncoveredMonths> webmodule response object
	 * 
	 */
	public List<UncoveredMonths> uncoveredMonthsMapper(List<BEQUncoveredMonths> uncoveredMonths) {
		JMapper<UncoveredMonths, BEQUncoveredMonths> beanMapper = new JMapper<>(UncoveredMonths.class,
				BEQUncoveredMonths.class);

		List<UncoveredMonths> uncoveredMonthsVO = new ArrayList<>();
		for (BEQUncoveredMonths uncoveredMonthsDTOElement : uncoveredMonths) {
			uncoveredMonthsVO.add(beanMapper.getDestination(uncoveredMonthsDTOElement));
		}
		return uncoveredMonthsVO;
	}

	/*
	 * requestBeanMapper
	 * 
	 * @param BEQRequest cms wrapper response object
	 * 
	 * @return BeqRequestVO webmodule response object
	 * 
	 */
	public BeqRequestVO requestBeanMapper(BEQRequest beqRequest) {
		JMapper<BeqRequestVO, BEQRequest> beanMapper = new JMapper<>(BeqRequestVO.class, BEQRequest.class);
		BeqRequestVO obj = beanMapper.getDestination(beqRequest);

		// for Gender, since it is an enum we are extracting it without Jmapper
		if (beqRequest.getBeneficiaryGender() != null) {
			obj.setGender(beqRequest.getBeneficiaryGender().getValue());
		}
		return obj;

	}

	/*
	 * responseStatusMapper
	 * 
	 * @param List<BEQResponseCode> cms wrapper response object
	 * 
	 * @return List<ResponseStatus> webmodule response object
	 * 
	 */

	public List<ResponseStatus> responseStatusMapper(List<BEQResponseCode> responseCodes) {
		JMapper<ResponseStatus, BEQResponseCode> beanMapper = new JMapper<>(ResponseStatus.class,
				BEQResponseCode.class);

		List<ResponseStatus> responseCodesVO = new ArrayList<>();
		for (BEQResponseCode responseCodesDTOElement : responseCodes) {
			responseCodesVO.add(beanMapper.getDestination(responseCodesDTOElement));
		}
		return responseCodesVO;
	}

}
