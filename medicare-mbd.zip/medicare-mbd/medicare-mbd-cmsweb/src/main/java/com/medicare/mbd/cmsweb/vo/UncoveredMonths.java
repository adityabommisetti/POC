package com.medicare.mbd.cmsweb.vo;

import java.math.BigDecimal;

import com.googlecode.jmapper.annotations.JMap;

import lombok.Data;

@Data
public class UncoveredMonths {

	@JMap
	private String startDate = null;
	@JMap
	private BigDecimal monthsCount = null;
	@JMap
	private String status = null;
}
