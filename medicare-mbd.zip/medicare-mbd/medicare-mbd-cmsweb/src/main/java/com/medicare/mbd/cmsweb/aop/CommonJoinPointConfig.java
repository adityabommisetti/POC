package com.medicare.mbd.cmsweb.aop;

import org.aspectj.lang.annotation.Pointcut;

public class CommonJoinPointConfig {

	@Pointcut("execution(* com.medicare.mbd.cmsweb.controller.*.*(..)) || execution(* com.medicare.mbd.cmsweb.service.*.*(..)) || execution(* com.medicare.mbd.cmswrapper.service.*.*(..))|| execution(* com.medicare.mbd.cmswrapper.api.*.*(..)) || execution(* com.medicare.mbd.cmswrapper.client.*.*(..)) ")
	public void allLayerExecution() {
		// joinpoint for allLayerExecution
	}

}
