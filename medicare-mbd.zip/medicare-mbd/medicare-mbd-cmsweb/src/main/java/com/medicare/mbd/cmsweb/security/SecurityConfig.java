package com.medicare.mbd.cmsweb.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.medicare.mbd.cmsweb.util.JwtFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	private JwtFilter jwtFilter;

	@Override
	protected void configure(final HttpSecurity http) throws Exception {

		http.cors().disable();
		http.httpBasic();
		http.csrf().disable();

		// HTML5: Missing Framing Protection
		http.headers().frameOptions().deny();

		// HTML5: Missing Content Security Policy
		http.headers().contentSecurityPolicy("default-src 'self'");
		// .addFilterBefore(jwtFilter).authorizeRequests()
		http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()
				.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class).authorizeRequests()
				.antMatchers("/**").authenticated().and().formLogin().disable();
	}

}
