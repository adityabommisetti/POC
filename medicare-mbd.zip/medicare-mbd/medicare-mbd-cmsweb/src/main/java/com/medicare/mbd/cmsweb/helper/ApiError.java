package com.medicare.mbd.cmsweb.helper;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class ApiError {

	private String statusCode;
	private HttpStatus status;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
	private LocalDateTime timestamp;
	private String message;
	private List<String> debugMessage;

	private ApiError() {
		timestamp = LocalDateTime.now();
	}

	public ApiError(String statusCode, HttpStatus status) {
		this();
		this.statusCode = statusCode;
		this.status = status;
	}

	public ApiError(String statusCode, HttpStatus status, String message) {
		this();
		this.statusCode = statusCode;
		this.timestamp = null;
		this.status = status;
		this.message = message;
	}

	public ApiError(String statusCode, HttpStatus status, Throwable ex) {
		this();
		this.statusCode = statusCode;
		this.status = status;
		this.message = "Unexpected error";
		this.debugMessage = new ArrayList<>();
		this.debugMessage.add(ex.getLocalizedMessage());

	}

	public ApiError(String statusCode, HttpStatus status, String message, Throwable ex) {
		this();
		this.statusCode = statusCode;
		this.status = status;
		this.message = message;
		this.debugMessage = new ArrayList<>();
		this.debugMessage.add(ex.getLocalizedMessage());
	}

	public ApiError(String statusCode, HttpStatus status, String message, List<String> debugMessage) {
		this();
		this.statusCode = statusCode;
		this.status = status;
		this.message = message;
		this.debugMessage = debugMessage;

	}
}
