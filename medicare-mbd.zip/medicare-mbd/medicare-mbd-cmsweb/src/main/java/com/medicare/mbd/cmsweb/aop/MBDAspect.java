package com.medicare.mbd.cmsweb.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.medicare.mbd.cmsweb.util.MyUserDetailsService;

import java.time.Duration;
import java.time.Instant;

@Aspect
@Configuration
public class MBDAspect {

	@Autowired
	private MyUserDetailsService userDetailsService;

	private static final Logger LOG = LoggerFactory.getLogger(MBDAspect.class);

	@AfterThrowing(value = "com.medicare.mbd.cmsweb.aop.CommonJoinPointConfig.allLayerExecution()", throwing = "exception")
	public void afterThrowing(JoinPoint joinPoint, Throwable exception) {
		Signature signature = joinPoint.getSignature();
		LOG.error(" method {} exited with throwing {}", signature, exception);

		if (LOG.isDebugEnabled()) {
			LOG.error("An exception occurred.", exception);
		}
	}

	/**
	 * This methods executes before and after method executes
	 * 
	 * @param joinPoint Holds method name
	 * @return result of the method
	 * @throws Throwable
	 */
	@Around("com.medicare.mbd.cmsweb.aop.CommonJoinPointConfig.allLayerExecution()")
	public Object logExecutionTime(ProceedingJoinPoint joinPoint) throws Throwable {
		LOG.info("UserId: {}: method {} Started..", userDetailsService.getUserIdInstance(), joinPoint.getSignature());

		Instant start = Instant.now();
		Object object = joinPoint.proceed();
		Instant finish = Instant.now();

		long timeTaken = Duration.between(start, finish).toMillis();

		LOG.info("UserId: {}: method {} Finished Successfully in {} milliseconds..",
				userDetailsService.getUserIdInstance(), joinPoint.getSignature(), timeTaken);

		return object;
	}
}
