package com.medicare.mbd.cmsweb.helper;

import lombok.Data;

@Data
public class JSONResponse {

	private String status;
	private String message;
	private Object data;

}