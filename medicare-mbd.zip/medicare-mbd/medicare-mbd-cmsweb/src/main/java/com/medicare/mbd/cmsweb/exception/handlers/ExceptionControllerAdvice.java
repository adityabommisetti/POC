package com.medicare.mbd.cmsweb.exception.handlers;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.medicare.mbd.cmsweb.exceptions.ApplicationException;
import com.medicare.mbd.cmsweb.helper.ApiError;
import com.medicare.mbd.cmsweb.helper.JSONResponse;
import com.medicare.mbd.cmswrapper.client.ApiException;

@RestControllerAdvice
public class ExceptionControllerAdvice extends ResponseEntityExceptionHandler {

	@ExceptionHandler(value = { ApiException.class, ApplicationException.class })
	public ResponseEntity<JSONResponse> handleApplicationException(Exception exception) {
		JSONResponse jsonResponse = new JSONResponse();
		jsonResponse.setStatus("FAILURE");
		jsonResponse.setMessage(exception.getMessage());
		return new ResponseEntity<>(jsonResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	/*
	 * handleHttpMessageNotReadable To handle the http invalid json request and send
	 * specific exception msg.
	 * 
	 */

	@Override
	protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		String errorMessage = "Malformed JSON request";
		return buildResponseEntity(
				new ApiError(HttpStatus.BAD_REQUEST.getReasonPhrase(), HttpStatus.BAD_REQUEST, errorMessage, ex));
	}

	private ResponseEntity<Object> buildResponseEntity(ApiError apiError) {
		return new ResponseEntity<>(apiError, apiError.getStatus());
	}

	/*
	 * handleMethodArgumentNotValid To handle the exception if the valid parameters
	 * are missing in the requestBody and send specific exception msg.
	 * 
	 */
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		String errorMessage = "REQUIRED PARAMETERS MISSING IN REQUEST";
		List<String> errors = ex.getBindingResult().getFieldErrors().stream().map(FieldError::getDefaultMessage)
				.collect(Collectors.toList());

		return buildResponseEntity(
				new ApiError(HttpStatus.BAD_REQUEST.getReasonPhrase(), HttpStatus.BAD_REQUEST, errorMessage, errors));
	}

}
