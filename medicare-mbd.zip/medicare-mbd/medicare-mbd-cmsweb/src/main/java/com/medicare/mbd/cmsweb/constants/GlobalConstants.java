package com.medicare.mbd.cmsweb.constants;

public class GlobalConstants {

	private GlobalConstants() {

	}

	public static final String AUTH_TOKEN = "x-auth-token";
	public static final String SUCCESSFUL = "SUCCESSFUL";
	public static final String SOMETHING_WENT_WRONG = "Something Went Wrong";
	public static final String TOKEN_EXPIRED = "Token Expired,Please Login Again";
	public static final String DATE_FORMAT = "yyyy-MM-dd";

	public static final String NO_IDENTIFIER_CODENAME = "MISSING BENEFICIARY IDENTIFIER";
	public static final String NO_IDENTIFIER_CODE = "3201";
	public static final String NO_IDENTIFIER_DESCRIPTION = "missing beneficiary identifier";
	public static final String NO_IDENTIFIER_MESSAGE = "3201:MISSING BENEFICIARY IDENTIFIER ";

	public static final String NO_BIRTHDATE_CODENAME = "MISSING BIRTHDATE";
	public static final String NO_BIRTHDATE_CODE = "3202";
	public static final String NO_BIRTHDATE_DESCRIPTION = "missing beneficiary birthdate";
	public static final String NO_BIRTHDATE_MESSAGE = "3202:MISSING BENEFICIARY BIRTHDATE ";

	public static final String INVALID_BIRTHDATEFORMAT_CODE = "3207";
	public static final String INVALID_BIRTHDATEFORMAT_DESCRIPTION = "Check the format YYYY-MM-DD";
	public static final String INVALID_BIRTHDATEFORMAT_CODENAME = "INVALID_BIRTH_DT_FORMAT ";

	public static final String INVALID_COVERAGEDATE_CODE = "3208";
	public static final String INVALID_COVERAGEDATE_DESCRIPTION = "Check the format YYYY-MM-DD";
	public static final String INVALID_COVERAGEDATE_CODENAME = "INVALID_COVERAGE_EFFECTIVE_DT ";

	public static final String INVALID_IDENTIFIER_CODE = "3205";
	public static final String INVALID_IDENTIFIER_DESCRIPTION = "invalid beneficiary Identifier";
	public static final String INVALID_IDENTIFIERE_CODENAME = "INVALID BENEFICIARY IDENTIFIER";

	public static final String INVALID_REQ_TRANSACTION_CODE = "3204";
	public static final String INVALID_REQ_TRANSACTION_DESCRIPTION = "Not more than 50 characters";
	public static final String INVALID_REQ_TRANSACTION_CODENAME = "INVALID_TRANS_ID";

	public static final String INVALID_GENDER_CODE = "3206";
	public static final String INVALID_GENDER_DESCRIPTION = "Give Only Either M or F or U ";
	public static final String INVALID_GENDER_CODENAME = "INVALID_GENDER";

}
