package com.medicare.mbd.cmsweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.medicare.mbd")
public class MedicareMbdCmswebApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedicareMbdCmswebApplication.class, args);
	}

}
