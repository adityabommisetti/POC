package com.medicare.mbd.cmsweb.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mbd.cmsweb.constants.ReqMappingConstants;
import com.medicare.mbd.cmsweb.helper.JSONResponse;
import com.medicare.mbd.cmsweb.service.BeqService;
import com.medicare.mbd.cmsweb.vo.BeqRequestVO;
import com.medicare.mbd.cmsweb.vo.BeqResponseVO;
import com.medicare.mbd.cmswrapper.client.ApiException;

@RestController
@RequestMapping("/beq")
public class BeqController {

	@Autowired
	private BeqService beqService;

	/*
	 * getBeneficiaryInfo
	 * 
	 * @param RequestBody
	 * 
	 * @return ResponseEntity<JSONResponse>
	 * 
	 */
	@PostMapping(ReqMappingConstants.BEQINFO)
	public ResponseEntity<JSONResponse> getBeneficiaryInfo(@Valid @RequestBody BeqRequestVO beqRequestMember)
			throws ApiException {
		BeqResponseVO beqResponse = beqService.validateBeforeServiceCall(beqRequestMember);
		return sendResponse(beqResponse);
	}

	private ResponseEntity<JSONResponse> sendResponse(Object object) {
		JSONResponse jsonResponse = new JSONResponse();
		ResponseEntity<JSONResponse> response;
		jsonResponse.setData(object);
		if (null == object) {
			jsonResponse.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			response = new ResponseEntity<>(jsonResponse, HttpStatus.NO_CONTENT);
		} else {
			jsonResponse.setStatus(HttpStatus.OK.getReasonPhrase());
			jsonResponse.setMessage("SUCCESSFUL");
			response = new ResponseEntity<>(jsonResponse, HttpStatus.OK);
		}
		return response;
	}

}
