package com.medicare.mbd.cmsweb.util;

import java.io.IOException;
import java.io.InputStream;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Date;
import java.util.Objects;
import java.util.function.Function;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;

import com.medicare.mbd.cmsweb.constants.GlobalConstants;
import com.medicare.mbd.cmsweb.exceptions.ApplicationException;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;

@Service
public class JwtUtil {

	private PublicKey publicKey;

	public String extaractUserName(String token) {
		return extractClaim(token, Claims::getSubject);
	}

	public Date extractExpiration(String token) {
		return extractClaim(token, Claims::getExpiration);
	}

	public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
		final Claims claims = extractAllClaims(token);
		return claimsResolver.apply(claims);
	}

	private Claims extractAllClaims(String token) {
		try {
			if (Objects.isNull(publicKey)) {
				publicKey = publicKeyReader();
			}
			return Jwts.parser().setSigningKey(publicKey).parseClaimsJws(token).getBody();
		} catch (NoSuchAlgorithmException | InvalidKeySpecException | IOException e) {
			throw new ApplicationException(GlobalConstants.SOMETHING_WENT_WRONG);
		}
	}

	private Boolean isTokenExpired(String token) {
		return extractExpiration(token).before(new Date());
	}

	public Boolean validateToken(String token) {

		return (!isTokenExpired(token));
	}

	private PublicKey publicKeyReader() throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {
		InputStream inputStream = new ClassPathResource("public_key.der").getInputStream();
		byte[] keyBytes = FileCopyUtils.copyToByteArray(inputStream);
		X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
		KeyFactory kf = KeyFactory.getInstance("RSA");
		return kf.generatePublic(spec);
	}
}
