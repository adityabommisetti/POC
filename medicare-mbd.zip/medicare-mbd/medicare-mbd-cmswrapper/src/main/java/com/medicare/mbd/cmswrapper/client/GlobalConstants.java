package com.medicare.mbd.cmswrapper.client;

public class GlobalConstants {
	
private GlobalConstants() {
		
	}
	
	
	public static final String SOMETHING_WENT_WRONG = "Something Went Wrong";
	public static final String CONTENT_TYPE_JSON = "application/json";
	public static final String CONTENT_DISPOSITION_HEADER= "Content-Disposition";

}
