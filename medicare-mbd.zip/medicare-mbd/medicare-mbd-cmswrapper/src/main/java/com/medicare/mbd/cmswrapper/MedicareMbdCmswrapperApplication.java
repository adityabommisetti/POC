package com.medicare.mbd.cmswrapper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedicareMbdCmswrapperApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedicareMbdCmswrapperApplication.class, args);
	}

}
