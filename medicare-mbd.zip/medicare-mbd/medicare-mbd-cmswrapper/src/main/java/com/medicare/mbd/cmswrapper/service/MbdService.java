package com.medicare.mbd.cmswrapper.service;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Service;

import com.medicare.mbd.cmswrapper.api.BeqApi;
import com.medicare.mbd.cmswrapper.client.ApiClient;
import com.medicare.mbd.cmswrapper.client.ApiException;
import com.medicare.mbd.cmswrapper.client.model.ApiResponseDataBeneficiaryProfile;
import com.medicare.mbd.cmswrapper.client.model.BEQRequest;
import com.medicare.mbd.cmswrapper.client.model.BEQResponse;
import com.medicare.mbd.cmswrapper.client.model.BeqRequests;
import com.medicare.mbd.cmswrapper.client.model.ModelApiResponse;

/*
 * 
 * The following class is the service class to parent modules. This class is responsible for contacting the CMS server and fetch the required response.
 * To use this service, add this project jar in your dependencies and also define the properties which are declared in com.medicare.mbd.service.MbdServiceProperties class,
 * in your application.properties file of the parent module 
 *  
 *
 */
@Service("mbdService")
@EnableConfigurationProperties(MbdServiceProperties.class)
public class MbdService {

	@Autowired
	private MbdServiceProperties serviceProperties;

	@Autowired
	private BeqApi beqApi;

	private static final Logger LOG = LoggerFactory.getLogger(MbdService.class);

	/*
	 * 
	 * The following function is related to singleInstance CMS calls
	 * 
	 * @param BEQRequest
	 * 
	 * @return BEQResponse
	 * 
	 * @throws ApiException If fail to call the API
	 * 
	 * 
	 */
	public BEQResponse fetchCmsBeqData(BEQRequest requestObj) throws ApiException {

		BeqRequests requestObjList = new BeqRequests();
		requestObjList.addBeqRequestsItem(requestObj);
		LOG.debug("Request Object is {} ", requestObj);
		ModelApiResponse responseObject = beqApi.beneficiaryProfile(requestObjList);

		if (!responseObject.getData().getBeneficiaryProfile().getBEQ().isEmpty()) {
			LOG.debug("Response Object is {} ", responseObject.getData().getBeneficiaryProfile().getBEQ());
			return responseObject.getData().getBeneficiaryProfile().getBEQ().get(0);
		} else
			throw new ApiException("Something Went Wrong");

	}

	/*
	 * 
	 * The following function is related to MultipleInstance CMS calls.
	 * 
	 * @param BeqRequests which is List<BEQRequest>
	 * 
	 * @return ApiResponseDataBeneficiaryProfile; which contains the list of
	 * responses containing beneficiary information related to the requests
	 * 
	 * @throws ApiException If fail to call the API
	 * 
	 */
	public ApiResponseDataBeneficiaryProfile fetchCmsBeqData(BeqRequests beqRequests) throws ApiException {
		LOG.debug("Request Object is {} ", beqRequests);
		ModelApiResponse apiResponse = beqApi.beneficiaryProfile(beqRequests);
		LOG.debug("Response Object is {} ", apiResponse.getData().getBeneficiaryProfile());
		return apiResponse.getData().getBeneficiaryProfile();
	}

	/*
	 * This function below is used to define the connection related properties.
	 * 
	 */

	@PostConstruct
	public void apiInit() throws ApiException {

		int proxyPort = serviceProperties.getProxyPort();
		String proxyHost = serviceProperties.getProxyHost();
		String varPath = serviceProperties.getServiceURI();
		String apiKey = serviceProperties.getApiKey();
		String basePath = serviceProperties.getBasePath();

		beqApi.setLocalVarPath(varPath);
		ApiClient client = beqApi.getApiClient();
		client.setApiKey(apiKey);
		client.setBasePath(basePath);
		client.setProxy(proxyHost, proxyPort, java.net.Proxy.Type.HTTP);

	}
}
