package com.medicare.mbd.cmswrapper.service;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Data;
/*
 * MbdServiceProperties
 * 
 */
@Data
@ConfigurationProperties("service")
public class MbdServiceProperties {

	private String serviceURI = "";
	private String proxyHost = "";
	private int proxyPort;
	private String apiKey = "";
	private String basePath = "";

}