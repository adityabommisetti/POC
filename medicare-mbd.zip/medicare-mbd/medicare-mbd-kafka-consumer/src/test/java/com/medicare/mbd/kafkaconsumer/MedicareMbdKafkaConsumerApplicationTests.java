package com.medicare.mbd.kafkaconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicareMbdKafkaConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
