package com.medicare.mbd.kafkaconsumer.aop;

import java.time.Duration;
import java.time.Instant;
import java.util.Objects;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

@Configuration
@Aspect
public class AspectConfiguration {

	private static final Logger Log = LoggerFactory.getLogger(AspectConfiguration.class);

	@Around("com.medicare.mbd.kafkaconsumer.aop.CommonJoinPointConfig.allLayerExecution()")
	public Object logExecutionTime(ProceedingJoinPoint jp) throws Throwable {

		Log.info(" Method {} Started", jp.getSignature());

		Instant start = Instant.now();
		Object obj = jp.proceed();
		Instant end = Instant.now();

		long timeTaken = Duration.between(start, end).toMillis();

		Log.info(" Method {} Finished Successfully", jp.getSignature());
		Log.info(" Time Taken By Method {} is {}", jp.getSignature(), timeTaken);

		return obj;

	}

	@AfterReturning(value = "com.medicare.mbd.kafkaconsumer.aop.CommonJoinPointConfig.allLayerExecution()", returning = "result")
	public void afterReturning(JoinPoint jp, Object result) {

		Log.info(" Method {} is returning {}", jp.getSignature(), Objects.nonNull(result) ? result.toString() : result);
	}

	@AfterThrowing(value = "com.medicare.mbd.kafkaconsumer.aop.CommonJoinPointConfig.allLayerExecution()", throwing = "exception")
	public void afterThrowing(JoinPoint jp, Throwable exception) {

		Log.info(" Method {} is throwing {}", jp.getSignature(), exception);

		if (Log.isDebugEnabled()) {
			Log.error("Exception raised", exception);
		}
	}

}
