package com.medicare.mbd.kafkaconsumer.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.medicare.mbd.kafkaconsumer.entities.MbiEntity;


@Repository
public interface Db2MbiRepository extends CrudRepository<MbiEntity, Long> {
  
  
}