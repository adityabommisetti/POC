package com.medicare.mbd.kafkaconsumer.service;

import java.util.List;

import com.medicare.mbd.kafkaconsumer.vo.MbdVO;

public interface MbiService {

	void updateFailedMbi(List<MbdVO> inputList, String message);

}
