package com.medicare.mbd.kafkaconsumer.serviceImpl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.mbd.kafkaconsumer.dao.MbiDao;
import com.medicare.mbd.kafkaconsumer.entities.MbiCompositeEntity;
import com.medicare.mbd.kafkaconsumer.entities.MbiEntity;
import com.medicare.mbd.kafkaconsumer.service.MbiService;
import com.medicare.mbd.kafkaconsumer.util.CommonUtils;
import com.medicare.mbd.kafkaconsumer.vo.MbdVO;

@Service

public class MbiServiceImpl implements MbiService {
	@Autowired
	private MbiDao mbiDao;

	@Override
	public void updateFailedMbi(List<MbdVO> inputList, String message) {
		List<MbiEntity> entityList = new ArrayList<>();

		for (MbdVO mbdVO : inputList) {
			MbiEntity entity = new MbiEntity();
			MbiCompositeEntity compositeEntity = new MbiCompositeEntity();
			compositeEntity.setDob(mbdVO.getBeneficiaryBirthDate());
			compositeEntity.setJobInsName(removeDobAndMbrId(mbdVO.getRequestorTransactionId(),
					mbdVO.getBeneficiaryIdentifier(), mbdVO.getBeneficiaryBirthDate()));
			compositeEntity.setMemberId(mbdVO.getBeneficiaryIdentifier());
			entity.setStatus("FAILED");
			entity.setErrorMsg(message);
			CommonUtils.trimObject(compositeEntity);
			entity.setId(compositeEntity);
			Calendar calendar = Calendar.getInstance();
			java.util.Date now = calendar.getTime();
			entity.setLastUpdated(new java.sql.Timestamp(now.getTime()));
			CommonUtils.trimObject(entity);
			entityList.add(entity);
		}
		mbiDao.updateFailedMbi(entityList);

	}

	private String removeDobAndMbrId(String requestorTransactionId,String memberId,String dob) {
		
		if(StringUtils.isBlank(requestorTransactionId)) {
			requestorTransactionId="";
		}else {
			requestorTransactionId=requestorTransactionId.replace(memberId, "");
			requestorTransactionId=requestorTransactionId.replace(dob, "");
		}
		
		return requestorTransactionId;
	}
}
