package com.medicare.mbd.kafkaconsumer.kafkaservice;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.medicare.mbd.cmswrapper.client.ApiException;
import com.medicare.mbd.cmswrapper.client.model.ApiResponseDataBeneficiaryProfile;
import com.medicare.mbd.cmswrapper.client.model.BEQRequest;
import com.medicare.mbd.cmswrapper.client.model.BeqRequests;
import com.medicare.mbd.cmswrapper.service.MbdService;
import com.medicare.mbd.kafkaconsumer.service.MbiService;
import com.medicare.mbd.kafkaconsumer.util.CommonUtils;
import com.medicare.mbd.kafkaconsumer.vo.MbdVO;

@Service
public class CmsInvoker {
	private static final Logger logger = LoggerFactory.getLogger(CmsInvoker.class);

	@Autowired
	private Producer producer;

	@Autowired
	@Qualifier("mbdService")
	private MbdService mbdService;

	@Autowired
	private MbiService mbiService;

	ObjectMapper objectMapper = new ObjectMapper();

	int contFailedCount = 0;

	public void invokeCmsConsumer(List<MbdVO> inputList, Acknowledgment ack)
			throws ApiException, JsonProcessingException {
		BeqRequests beqRequests = new BeqRequests();
		List<BEQRequest> beqReqList = new ArrayList<>();
		CommonUtils.copyList(inputList, beqReqList, BEQRequest.class);

		beqReqList.forEach(ref -> {
			CommonUtils.trimObject(ref);
			ref.setRequestorTransactionId(ref.getRequestorTransactionId()
					.concat(ref.getBeneficiaryIdentifier().concat(ref.getBeneficiaryBirthDate())));
		});
		beqRequests.setBeqRequests(beqReqList);
		logger.info("calling cms beq api");
		try {
			ApiResponseDataBeneficiaryProfile response = mbdService.fetchCmsBeqData(beqRequests);
			contFailedCount = 0;
			ack.acknowledge();
			String jsonInString = objectMapper.writeValueAsString(response);
			logger.info("cms response received");
			producer.sendCmsResponse(jsonInString);
		} catch (ApiException apiException) {
			contFailedCount++;
			if (contFailedCount > 2) {
				logger.info("After 2 continuous attempts stopping service due to:{} ", apiException.getMessage());
				System.exit(0);
			}
			invokeCmsConsumer(inputList, ack);

		} catch (Exception exp) {
			logger.error("failed to call cms");
			// mbiService.updateFailedMbi(inputList, exp.getMessage());
		}

	}

}
