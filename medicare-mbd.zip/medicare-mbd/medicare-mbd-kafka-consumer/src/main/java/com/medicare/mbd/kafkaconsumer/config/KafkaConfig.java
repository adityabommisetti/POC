package com.medicare.mbd.kafkaconsumer.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class KafkaConfig {

	@Value("${cms_response_topic_name}")
	private String cmsResTopicName;
	@Value("${cms_response_topic_partitions}")
	private Integer cmsResTopicPartitions;
	@Value("${cms_response_topic_instances}")
	private short cmsResTopicInstances;

	@Value("${mbd_topic_name}")
	private String mbdTopicName;
	@Value("${mbd_topic_partitions}")
	private Integer mbdTopicPartitions;
	@Value("${mbd_topic_instances}")
	private short mbdTopicInstances;

	/*@Bean
	NewTopic cmsResponseTopic() {
		return new NewTopic(cmsResTopicName, cmsResTopicPartitions, cmsResTopicInstances);
	}

	@Bean
	NewTopic mbiTopic() {
		return new NewTopic(mbdTopicName, mbdTopicPartitions, mbdTopicInstances);
	}*/
}
