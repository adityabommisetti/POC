package com.medicare.mbd.kafkaconsumer.kafkaservice;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.medicare.mbd.cmswrapper.client.ApiException;
import com.medicare.mbd.kafkaconsumer.vo.MbdVO;

@Service
public class Consumer {
	private static final Logger logger = LoggerFactory.getLogger(Consumer.class);

	@Autowired
	private CmsInvoker cmsInvoker;

	ObjectMapper objectMapper = new ObjectMapper();

	@KafkaListener(topics = "${mbd_topic_name}", groupId = "${spring.kafka.consumer.group-id}")
	public void consumeMbiDate(String message,Acknowledgment ack) throws JsonProcessingException, ApiException {
		logger.info("Mbi data :{} receieved to call CMS and process response to m360 database tables", message);
		List<MbdVO> list = objectMapper.readValue("[" + message + "]", new TypeReference<List<MbdVO>>() {
		});
		System.out.println("batch recieved:"+list.size());
		cmsInvoker.invokeCmsConsumer(list,ack);
		

	}

}