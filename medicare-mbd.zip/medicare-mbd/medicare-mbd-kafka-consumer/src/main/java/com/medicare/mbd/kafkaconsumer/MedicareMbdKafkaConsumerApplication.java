package com.medicare.mbd.kafkaconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication(scanBasePackages = "com.medicare.mbd")
@EnableTransactionManagement
@EntityScan(basePackages= {"com.medicare.mbd.kafkaconsumer.entities"})
public class MedicareMbdKafkaConsumerApplication {
	 // kafka start commands
		// start zookeeper: .\bin\windows\zookeeper-server-start.bat
		// .\.\config\zookeeper.properties
		// start kafka : .\bin\windows\kafka-server-start.bat
		// .\.\config\server.properties
		// start kafka connector: connect-standalone.bat
		// ..\..\config\connect-standalone.properties
		// ..\..\config\source-mbidata-oracle.properties
		// get topic content: connect-standalone.bat
		// ..\..\config\connect-standalone.properties
		// ..\..\config\source-mbidata-oracle.properties
		// get all topics: kafka-topics.bat --list -zookeeper localhost:2181
		//delete topic: kafka-topics.bat --zookeeper localhost:2181 --delete --topic ''
	public static void main(String[] args) {
		SpringApplication.run(MedicareMbdKafkaConsumerApplication.class, args);
	}

}
