package com.medicare.mbd.kafkaconsumer;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.mbd.kafkaconsumer.entities.MbiCompositeEntity;
import com.medicare.mbd.kafkaconsumer.entities.MbiEntity;
import com.medicare.mbd.kafkaconsumer.repo.Db2MbiRepository;

@RestController
public class TestController {
	
	@Autowired
	private Db2MbiRepository repo;

	@GetMapping("/addData")
	public void add(@RequestParam("number") String number) throws IOException, InvalidFormatException {
		FileInputStream fis = new FileInputStream(new File("D:\\MBD\\TESTDATA.xls.xlsx"));
		//HSSFWorkbook wb = new HSSFWorkbook(fis);
		XSSFWorkbook wb = new XSSFWorkbook(new File("D:\\MBD\\TESTDATA.xls.xlsx"));

		Boolean flag = false;
		int numberInt = Integer.parseInt(number);
		int totalRecProcessed = 0;
		List<MbiEntity> entityList=new ArrayList<>();
		for (int i = 0; i < wb.getNumberOfSheets(); i++) {
			XSSFSheet sheet = wb.getSheetAt(i);
			if (flag)
				break;
			for (int j = 1; j < sheet.getLastRowNum(); j++) {
				Row row = sheet.getRow(j);
				Cell cell = row.getCell(0);
				String value = cell.getStringCellValue();
				value=value.replace(":", "");
				value=value.replace("beneficiaryIdentifier", "");
				value=value.replace("beneficiaryBirthDate", "");
				value=value.replace("}", "");
				value=value.replace("{", "");
				value=value.replaceAll("\"", "");
				MbiEntity entity=new MbiEntity();
				MbiCompositeEntity compositeEntity=new MbiCompositeEntity();
				compositeEntity.setDob(value.split(",")[1].trim());
				compositeEntity.setJobInsName("TEST");
				compositeEntity.setMemberId(value.split(",")[0].trim());
				entity.setStatus("NA");
				entity.setErrorMsg("NA");
				entity.setId(compositeEntity);
				Calendar calendar = Calendar.getInstance();
				java.util.Date now = calendar.getTime();
				entity.setLastUpdated(new java.sql.Timestamp(now.getTime()));
				entityList.add(entity);
				 totalRecProcessed++;
				if (totalRecProcessed == numberInt) {
					flag = true;
					break;
				}
			}
		}
		repo.saveAll(entityList);

	}

}
