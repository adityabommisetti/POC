package com.medicare.mbd.kafkaconsumer.dao;

import java.util.List;

import com.medicare.mbd.kafkaconsumer.entities.MbiEntity;

public interface MbiDao {

	void updateFailedMbi(List<MbiEntity> entityList);

}
