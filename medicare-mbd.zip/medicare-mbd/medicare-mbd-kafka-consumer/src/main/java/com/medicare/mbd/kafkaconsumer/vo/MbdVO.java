package com.medicare.mbd.kafkaconsumer.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonSetter;

import lombok.Data;
@Data
@JsonIgnoreProperties(ignoreUnknown=true)
public class MbdVO {
	@JsonSetter("MEMBER_ID")
	private String beneficiaryIdentifier;
	@JsonSetter("DATE_OF_BIRTH")
	private String beneficiaryBirthDate;
	@JsonSetter("JOB_INS_NAME")
	private String requestorTransactionId;
	@JsonSetter("LAST_UPDATED")
	private String lastUpdated;
	@JsonSetter("STATUS")
	private String status;
	@JsonSetter("ERROR_MSG")
	private String errorMsg;

	

}
