package com.medicare.mbd.kafkaconsumer.daoImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.medicare.mbd.kafkaconsumer.dao.MbiDao;
import com.medicare.mbd.kafkaconsumer.entities.MbiEntity;
import com.medicare.mbd.kafkaconsumer.repo.Db2MbiRepository;

@Repository
@Transactional
public class MbiDaoImpl implements MbiDao {
	@Autowired
	private Db2MbiRepository repo;

	@Override
	public void updateFailedMbi(List<MbiEntity> entityList) {
		 repo.saveAll(entityList);
		

	}

}
