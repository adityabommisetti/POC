package com.medicare.mbd.kafkaresponse.oracle.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.medicare.mbd.kafkaresponse.oracle.entities.BicMbdEntity;

@Repository
public interface OracleMbdRepository extends JpaRepository<BicMbdEntity, Long> {

}