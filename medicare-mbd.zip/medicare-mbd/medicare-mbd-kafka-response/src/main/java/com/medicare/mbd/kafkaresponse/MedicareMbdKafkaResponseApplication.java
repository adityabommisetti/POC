package com.medicare.mbd.kafkaresponse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class MedicareMbdKafkaResponseApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedicareMbdKafkaResponseApplication.class, args);
	}

}
