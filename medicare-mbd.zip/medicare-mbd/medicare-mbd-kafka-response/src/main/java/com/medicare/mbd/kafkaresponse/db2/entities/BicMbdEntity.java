package com.medicare.mbd.kafkaresponse.db2.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "BIC_MBR_DATA")
public class BicMbdEntity {
	@Id
	@Column(name = "MBI")
	private String mbi;
	@Column(name = "FIRST_NAME")
	private String firstName;
	@Column(name = "MIDDLE_INIT")
	private String middleInitial;
	@Column(name = "LAST_NAME")
	private String lastName;
	@Column(name = "BIRTH_DATE")
	private String birthDate;
	@Column(name = "DEATH_DATE")
	private String deathDate;
	@Column(name = "LIVING_STATUS")
	private String livingStatus;
	@Column(name = "ENROLLMENT_STATUS")
	private String enrolStatus;
	@Column(name = "CALC_UNCOV_MONTHS")
	private String calcUncovMonths;
	@Column(name = "GENDER_NUM_CD")
	private String gender;
	@Column(name = "RACE_CD")
	private String race;
	@Column(name = "COUNTY_CD")
	private String ssaCounty;
	@Column(name = "STATE_CD")
	private String ssaState;
	@Column(name = "ZIP_CD")
	private String zipCode;
	@Column(name = "PRTA_ENTITLE_DATE")
	private String partAStartDate;
	@Column(name = "PRTA_ENTITLE_EDATE")
	private String partAStopDate;
	@Column(name = "PRTB_ENTITLE_DATE")
	private String partBStartDate;
	@Column(name = "PRTB_ENTITLE_EDATE")
	private String partBStopDate;
	@Column(name = "PRTD_ELIG_SDATE")
	private String partDEligStartDate;
	/*
	 * @Column(name = "") private String partDEligStopDate;
	 */
	@Column(name = "SUBSIDY_SDATE1")
	private String lowIncomeStartDate1;
	@Column(name = "SUBSIDY_SDATE2")
	private String lowIncomeStartDate2;
	@Column(name = "SUBSIDY_EDATE1")
	private String lowIncomeStopDate1;
	@Column(name = "SUBSIDY_EDATE2")
	private String lowIncomeStopDate2;
	@Column(name = "COPAY_LEVEL_ID1")
	private String copaymentLevel1;
	@Column(name = "COPAY_LEVEL_ID2")
	private String copaymentLevel2;
	@Column(name = "PRTD_PREMSUBS_PCT1")
	private String premiumSubsidyPercent1;
	@Column(name = "PRTD_PREMSUBS_PCT2")
	private String premiumSubsidyPercent2;
	@Column(name = "PLAN_ENROL_DATE")
	private String currEnrollDate;
	@Column(name = "COPLAN_ENROLL_DT")
	private String currCoEnrollDate;
	@Column(name = "PLAN_DISENROL_DATE")
	private String currDisEnrollDate;
	@Column(name = "COPLAN_DISENRL_DT")
	private String currCoDisEnrollDate;
	@Column(name = "PLAN_ID")
	private String contractNumber;
	@Column(name = "COPLAN_ID")
	private String coContractNumber;
	@Column(name = "PBP_ID")
	private String currEnrollPlanBenefitPackageNumber;
	@Column(name = "COPLAN_PBP")
	private String currCoEnrollPlanBenefitPackageNumber;
	@Column(name = "PLAN_DRUG_IND")
	private String currEnrollProgramType;
	@Column(name = "COPLAN_DRUG_IND")
	private String currCoEnrollProgramType;
	@Column(name = "PLAN_TYPE_CODE")
	private String currEnrollPlanType;
	@Column(name = "COPLAN_TYPE_CODE")
	private String currCoEnrollPlanType;
	@Column(name = "ENROLL_SRC_CD")
	private String currEnrollSourceType;
	@Column(name = "COPLAN_ENROLL_SRC_CD")
	private String currCoEnrollSourceType;
	@Column(name = "EGHP_IND")
	private String currEnrollIsEmpGrpHlthPlan;
	@Column(name = "COPLAN_EGHP_IND")
	private String currCoEnrollIsEmpGrpHlthPlan;
	@Column(name = "PRIOR1_PLAN_ENROLL_DT")
	private String priorEnrollDate1;
	@Column(name = "PRIOR2_PLAN_ENROLL_DT")
	private String priorEnrollDate2;
	@Column(name = "PRIOR1_PLAN_DISENROL_DT")
	private String priorDisEnrollDate1;
	@Column(name = "PRIOR2_PLAN_DISENROL_DT")
	private String priorDisEnrollDate2;
	@Column(name = "PRIOR1_PLAN_ID")
	private String priorContractNumber1;
	@Column(name = "PRIOR2_PLAN_ID")
	private String priorContractNumber2;
	@Column(name = "PRIOR1_PLAN_PBP")
	private String priorEnrollPlanBenefitPackageNumber1;
	@Column(name = "PRIOR2_PLAN_PBP")
	private String priorEnrollPlanBenefitPackageNumber2;
	@Column(name = "PRIOR1_PLAN_DRUG_IND")
	private String priorEnrollProgramType1;
	@Column(name = "PRIOR2_PLAN_DRUG_IND")
	private String priorEnrollProgramType2;
	@Column(name = "PRIOR1_PLAN_TYPE_CODE")
	private String priorEnrollPlanType1;
	@Column(name = "PRIOR2_PLAN_TYPE_CODE")
	private String priorEnrollPlanType2;
	@Column(name = "PRIOR1_ENROLL_SRC_CD")
	private String priorEnrollSourceType1;
	@Column(name = "PRIOR2_ENROLL_SRC_CD")
	private String priorEnrollSourceType2;
	@Column(name = "PRIOR1_PLAN_EGHP_IND")
	private String priorEnrollIsEmpGrpHlthPlan1;
	@Column(name = "PRIOR2_PLAN_EGHP_IND")
	private String priorEnrollIsEmpGrpHlthPlan2;
	@Column(name = "MEDIC_IND")
	private String hasMedicaid;
	@Column(name = "HOSPICE_SDATE")
	private String hospiceStartDate;
	@Column(name = "HOSPICE_EDATE")
	private String hospiceStopDate;
	@Column(name = "HOSPICE_IND")
	private String hospiceInd;
	@Column(name = "ESRD_IND")
	private String esrdInd;
	@Column(name = "ESRD_SDATE")
	private String esrdStartDate;
	@Column(name = "ESRD_EDATE")
	private String esrdStopDate;
	@Column(name = "MEDIC_SDATE")
	private String medicaidStartDate;
	@Column(name = "MEDIC_EDATE")
	private String medicaidStopDate;
	@Column(name = "INST_SDATE")
	private String insStartDate;
	@Column(name = "INST_EDATE")
	private String insStopDate;
	@Column(name = "INSTITUTIONAL_IND")
	private String insInd;
	@Column(name = "INACTIVE_MBI_1")
	private String inactiveMbi1;
	@Column(name = "INACTIVE_MBI_2")
	private String inactiveMbi2;
	@Column(name = "INACTIVE_MBI_1_EDATE")
	private String inactiveTermDate1;
	@Column(name = "INACTIVE_MBI_2_EDATE")
	private String inactiveTermDate2;
	@Column(name = "INACTIVE_MBI_1_SDATE")
	private String inactiveEffDate1;
	@Column(name = " INACTIVE_MBI_2_SDATE")
	private String inactiveEffDate2;

	@OneToMany(targetEntity = BicCaraPeriodsEntity.class, mappedBy = "bicMbd", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<BicCaraPeriodsEntity> caraPerList;

	@OneToMany(targetEntity = BicIncarcationEntity.class, mappedBy = "bicMbd", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<BicIncarcationEntity> incarcList;

	@OneToMany(targetEntity = BicNotlawfulEntity.class, mappedBy = "bicMbd", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<BicNotlawfulEntity> lawfullList;

	@OneToMany(targetEntity = BicPartDHistoryEntity.class, mappedBy = "bicMbd", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<BicPartDHistoryEntity> partDList;

	@OneToMany(targetEntity = BicRDSHistoryEntity.class, mappedBy = "bicMbd", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<BicRDSHistoryEntity> rdsList;

	@OneToMany(targetEntity = BicUnCovMonthEntity.class, mappedBy = "bicMbd", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<BicUnCovMonthEntity> uncovList;

	public String getMbi() {
		return mbi;
	}

	public void setMbi(String mbi) {
		this.mbi = mbi;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleInitial() {
		return middleInitial;
	}

	public void setMiddleInitial(String middleInitial) {
		this.middleInitial = middleInitial;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public String getDeathDate() {
		return deathDate;
	}

	public void setDeathDate(String deathDate) {
		this.deathDate = deathDate;
	}

	public String getLivingStatus() {
		return livingStatus;
	}

	public void setLivingStatus(String livingStatus) {
		this.livingStatus = livingStatus;
	}

	public String getEnrolStatus() {
		return enrolStatus;
	}

	public void setEnrolStatus(String enrolStatus) {
		this.enrolStatus = enrolStatus;
	}

	public String getCalcUncovMonths() {
		return calcUncovMonths;
	}

	public void setCalcUncovMonths(String calcUncovMonths) {
		this.calcUncovMonths = calcUncovMonths;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getRace() {
		return race;
	}

	public void setRace(String race) {
		this.race = race;
	}

	public String getSsaCounty() {
		return ssaCounty;
	}

	public void setSsaCounty(String ssaCounty) {
		this.ssaCounty = ssaCounty;
	}

	public String getSsaState() {
		return ssaState;
	}

	public void setSsaState(String ssaState) {
		this.ssaState = ssaState;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getPartAStartDate() {
		return partAStartDate;
	}

	public void setPartAStartDate(String partAStartDate) {
		this.partAStartDate = partAStartDate;
	}

	public String getPartAStopDate() {
		return partAStopDate;
	}

	public void setPartAStopDate(String partAStopDate) {
		this.partAStopDate = partAStopDate;
	}

	public String getPartBStartDate() {
		return partBStartDate;
	}

	public void setPartBStartDate(String partBStartDate) {
		this.partBStartDate = partBStartDate;
	}

	public String getPartBStopDate() {
		return partBStopDate;
	}

	public void setPartBStopDate(String partBStopDate) {
		this.partBStopDate = partBStopDate;
	}

	public String getPartDEligStartDate() {
		return partDEligStartDate;
	}

	public void setPartDEligStartDate(String partDEligStartDate) {
		this.partDEligStartDate = partDEligStartDate;
	}

	public String getLowIncomeStartDate1() {
		return lowIncomeStartDate1;
	}

	public void setLowIncomeStartDate1(String lowIncomeStartDate1) {
		this.lowIncomeStartDate1 = lowIncomeStartDate1;
	}

	public String getLowIncomeStartDate2() {
		return lowIncomeStartDate2;
	}

	public void setLowIncomeStartDate2(String lowIncomeStartDate2) {
		this.lowIncomeStartDate2 = lowIncomeStartDate2;
	}

	public String getLowIncomeStopDate1() {
		return lowIncomeStopDate1;
	}

	public void setLowIncomeStopDate1(String lowIncomeStopDate1) {
		this.lowIncomeStopDate1 = lowIncomeStopDate1;
	}

	public String getLowIncomeStopDate2() {
		return lowIncomeStopDate2;
	}

	public void setLowIncomeStopDate2(String lowIncomeStopDate2) {
		this.lowIncomeStopDate2 = lowIncomeStopDate2;
	}

	public String getCopaymentLevel1() {
		return copaymentLevel1;
	}

	public void setCopaymentLevel1(String copaymentLevel1) {
		this.copaymentLevel1 = copaymentLevel1;
	}

	public String getCopaymentLevel2() {
		return copaymentLevel2;
	}

	public void setCopaymentLevel2(String copaymentLevel2) {
		this.copaymentLevel2 = copaymentLevel2;
	}

	public String getPremiumSubsidyPercent1() {
		return premiumSubsidyPercent1;
	}

	public void setPremiumSubsidyPercent1(String premiumSubsidyPercent1) {
		this.premiumSubsidyPercent1 = premiumSubsidyPercent1;
	}

	public String getPremiumSubsidyPercent2() {
		return premiumSubsidyPercent2;
	}

	public void setPremiumSubsidyPercent2(String premiumSubsidyPercent2) {
		this.premiumSubsidyPercent2 = premiumSubsidyPercent2;
	}

	public String getCurrEnrollDate() {
		return currEnrollDate;
	}

	public void setCurrEnrollDate(String currEnrollDate) {
		this.currEnrollDate = currEnrollDate;
	}

	public String getCurrCoEnrollDate() {
		return currCoEnrollDate;
	}

	public void setCurrCoEnrollDate(String currCoEnrollDate) {
		this.currCoEnrollDate = currCoEnrollDate;
	}

	public String getCurrDisEnrollDate() {
		return currDisEnrollDate;
	}

	public void setCurrDisEnrollDate(String currDisEnrollDate) {
		this.currDisEnrollDate = currDisEnrollDate;
	}

	public String getCurrCoDisEnrollDate() {
		return currCoDisEnrollDate;
	}

	public void setCurrCoDisEnrollDate(String currCoDisEnrollDate) {
		this.currCoDisEnrollDate = currCoDisEnrollDate;
	}

	public String getContractNumber() {
		return contractNumber;
	}

	public void setContractNumber(String contractNumber) {
		this.contractNumber = contractNumber;
	}

	public String getCoContractNumber() {
		return coContractNumber;
	}

	public void setCoContractNumber(String coContractNumber) {
		this.coContractNumber = coContractNumber;
	}

	public String getCurrEnrollPlanBenefitPackageNumber() {
		return currEnrollPlanBenefitPackageNumber;
	}

	public void setCurrEnrollPlanBenefitPackageNumber(String currEnrollPlanBenefitPackageNumber) {
		this.currEnrollPlanBenefitPackageNumber = currEnrollPlanBenefitPackageNumber;
	}

	public String getCurrCoEnrollPlanBenefitPackageNumber() {
		return currCoEnrollPlanBenefitPackageNumber;
	}

	public void setCurrCoEnrollPlanBenefitPackageNumber(String currCoEnrollPlanBenefitPackageNumber) {
		this.currCoEnrollPlanBenefitPackageNumber = currCoEnrollPlanBenefitPackageNumber;
	}

	public String getCurrEnrollProgramType() {
		return currEnrollProgramType;
	}

	public void setCurrEnrollProgramType(String currEnrollProgramType) {
		this.currEnrollProgramType = currEnrollProgramType;
	}

	public String getCurrCoEnrollProgramType() {
		return currCoEnrollProgramType;
	}

	public void setCurrCoEnrollProgramType(String currCoEnrollProgramType) {
		this.currCoEnrollProgramType = currCoEnrollProgramType;
	}

	public String getCurrEnrollPlanType() {
		return currEnrollPlanType;
	}

	public void setCurrEnrollPlanType(String currEnrollPlanType) {
		this.currEnrollPlanType = currEnrollPlanType;
	}

	public String getCurrCoEnrollPlanType() {
		return currCoEnrollPlanType;
	}

	public void setCurrCoEnrollPlanType(String currCoEnrollPlanType) {
		this.currCoEnrollPlanType = currCoEnrollPlanType;
	}

	public String getCurrEnrollSourceType() {
		return currEnrollSourceType;
	}

	public void setCurrEnrollSourceType(String currEnrollSourceType) {
		this.currEnrollSourceType = currEnrollSourceType;
	}

	public String getCurrCoEnrollSourceType() {
		return currCoEnrollSourceType;
	}

	public void setCurrCoEnrollSourceType(String currCoEnrollSourceType) {
		this.currCoEnrollSourceType = currCoEnrollSourceType;
	}

	public String getCurrEnrollIsEmpGrpHlthPlan() {
		return currEnrollIsEmpGrpHlthPlan;
	}

	public void setCurrEnrollIsEmpGrpHlthPlan(String currEnrollIsEmpGrpHlthPlan) {
		this.currEnrollIsEmpGrpHlthPlan = currEnrollIsEmpGrpHlthPlan;
	}

	public String getCurrCoEnrollIsEmpGrpHlthPlan() {
		return currCoEnrollIsEmpGrpHlthPlan;
	}

	public void setCurrCoEnrollIsEmpGrpHlthPlan(String currCoEnrollIsEmpGrpHlthPlan) {
		this.currCoEnrollIsEmpGrpHlthPlan = currCoEnrollIsEmpGrpHlthPlan;
	}

	public String getPriorEnrollDate1() {
		return priorEnrollDate1;
	}

	public void setPriorEnrollDate1(String priorEnrollDate1) {
		this.priorEnrollDate1 = priorEnrollDate1;
	}

	public String getPriorEnrollDate2() {
		return priorEnrollDate2;
	}

	public void setPriorEnrollDate2(String priorEnrollDate2) {
		this.priorEnrollDate2 = priorEnrollDate2;
	}

	public String getPriorDisEnrollDate1() {
		return priorDisEnrollDate1;
	}

	public void setPriorDisEnrollDate1(String priorDisEnrollDate1) {
		this.priorDisEnrollDate1 = priorDisEnrollDate1;
	}

	public String getPriorDisEnrollDate2() {
		return priorDisEnrollDate2;
	}

	public void setPriorDisEnrollDate2(String priorDisEnrollDate2) {
		this.priorDisEnrollDate2 = priorDisEnrollDate2;
	}

	public String getPriorContractNumber1() {
		return priorContractNumber1;
	}

	public void setPriorContractNumber1(String priorContractNumber1) {
		this.priorContractNumber1 = priorContractNumber1;
	}

	public String getPriorContractNumber2() {
		return priorContractNumber2;
	}

	public void setPriorContractNumber2(String priorContractNumber2) {
		this.priorContractNumber2 = priorContractNumber2;
	}

	public String getPriorEnrollPlanBenefitPackageNumber1() {
		return priorEnrollPlanBenefitPackageNumber1;
	}

	public void setPriorEnrollPlanBenefitPackageNumber1(String priorEnrollPlanBenefitPackageNumber1) {
		this.priorEnrollPlanBenefitPackageNumber1 = priorEnrollPlanBenefitPackageNumber1;
	}

	public String getPriorEnrollPlanBenefitPackageNumber2() {
		return priorEnrollPlanBenefitPackageNumber2;
	}

	public void setPriorEnrollPlanBenefitPackageNumber2(String priorEnrollPlanBenefitPackageNumber2) {
		this.priorEnrollPlanBenefitPackageNumber2 = priorEnrollPlanBenefitPackageNumber2;
	}

	public String getPriorEnrollProgramType1() {
		return priorEnrollProgramType1;
	}

	public void setPriorEnrollProgramType1(String priorEnrollProgramType1) {
		this.priorEnrollProgramType1 = priorEnrollProgramType1;
	}

	public String getPriorEnrollProgramType2() {
		return priorEnrollProgramType2;
	}

	public void setPriorEnrollProgramType2(String priorEnrollProgramType2) {
		this.priorEnrollProgramType2 = priorEnrollProgramType2;
	}

	public String getPriorEnrollPlanType1() {
		return priorEnrollPlanType1;
	}

	public void setPriorEnrollPlanType1(String priorEnrollPlanType1) {
		this.priorEnrollPlanType1 = priorEnrollPlanType1;
	}

	public String getPriorEnrollPlanType2() {
		return priorEnrollPlanType2;
	}

	public void setPriorEnrollPlanType2(String priorEnrollPlanType2) {
		this.priorEnrollPlanType2 = priorEnrollPlanType2;
	}

	public String getPriorEnrollSourceType1() {
		return priorEnrollSourceType1;
	}

	public void setPriorEnrollSourceType1(String priorEnrollSourceType1) {
		this.priorEnrollSourceType1 = priorEnrollSourceType1;
	}

	public String getPriorEnrollSourceType2() {
		return priorEnrollSourceType2;
	}

	public void setPriorEnrollSourceType2(String priorEnrollSourceType2) {
		this.priorEnrollSourceType2 = priorEnrollSourceType2;
	}

	public String getPriorEnrollIsEmpGrpHlthPlan1() {
		return priorEnrollIsEmpGrpHlthPlan1;
	}

	public void setPriorEnrollIsEmpGrpHlthPlan1(String priorEnrollIsEmpGrpHlthPlan1) {
		this.priorEnrollIsEmpGrpHlthPlan1 = priorEnrollIsEmpGrpHlthPlan1;
	}

	public String getPriorEnrollIsEmpGrpHlthPlan2() {
		return priorEnrollIsEmpGrpHlthPlan2;
	}

	public void setPriorEnrollIsEmpGrpHlthPlan2(String priorEnrollIsEmpGrpHlthPlan2) {
		this.priorEnrollIsEmpGrpHlthPlan2 = priorEnrollIsEmpGrpHlthPlan2;
	}

	public String getHasMedicaid() {
		return hasMedicaid;
	}

	public void setHasMedicaid(String hasMedicaid) {
		this.hasMedicaid = hasMedicaid;
	}

	public String getHospiceStartDate() {
		return hospiceStartDate;
	}

	public void setHospiceStartDate(String hospiceStartDate) {
		this.hospiceStartDate = hospiceStartDate;
	}

	public String getHospiceStopDate() {
		return hospiceStopDate;
	}

	public void setHospiceStopDate(String hospiceStopDate) {
		this.hospiceStopDate = hospiceStopDate;
	}

	public String getHospiceInd() {
		return hospiceInd;
	}

	public void setHospiceInd(String hospiceInd) {
		this.hospiceInd = hospiceInd;
	}

	public String getEsrdInd() {
		return esrdInd;
	}

	public void setEsrdInd(String esrdInd) {
		this.esrdInd = esrdInd;
	}

	public String getEsrdStartDate() {
		return esrdStartDate;
	}

	public void setEsrdStartDate(String esrdStartDate) {
		this.esrdStartDate = esrdStartDate;
	}

	public String getEsrdStopDate() {
		return esrdStopDate;
	}

	public void setEsrdStopDate(String esrdStopDate) {
		this.esrdStopDate = esrdStopDate;
	}

	public String getMedicaidStartDate() {
		return medicaidStartDate;
	}

	public void setMedicaidStartDate(String medicaidStartDate) {
		this.medicaidStartDate = medicaidStartDate;
	}

	public String getMedicaidStopDate() {
		return medicaidStopDate;
	}

	public void setMedicaidStopDate(String medicaidStopDate) {
		this.medicaidStopDate = medicaidStopDate;
	}

	public String getInsStartDate() {
		return insStartDate;
	}

	public void setInsStartDate(String insStartDate) {
		this.insStartDate = insStartDate;
	}

	public String getInsStopDate() {
		return insStopDate;
	}

	public void setInsStopDate(String insStopDate) {
		this.insStopDate = insStopDate;
	}

	public String getInsInd() {
		return insInd;
	}

	public void setInsInd(String insInd) {
		this.insInd = insInd;
	}

	public String getInactiveMbi1() {
		return inactiveMbi1;
	}

	public void setInactiveMbi1(String inactiveMbi1) {
		this.inactiveMbi1 = inactiveMbi1;
	}

	public String getInactiveMbi2() {
		return inactiveMbi2;
	}

	public void setInactiveMbi2(String inactiveMbi2) {
		this.inactiveMbi2 = inactiveMbi2;
	}

	public String getInactiveTermDate1() {
		return inactiveTermDate1;
	}

	public void setInactiveTermDate1(String inactiveTermDate1) {
		this.inactiveTermDate1 = inactiveTermDate1;
	}

	public String getInactiveTermDate2() {
		return inactiveTermDate2;
	}

	public void setInactiveTermDate2(String inactiveTermDate2) {
		this.inactiveTermDate2 = inactiveTermDate2;
	}

	public String getInactiveEffDate1() {
		return inactiveEffDate1;
	}

	public void setInactiveEffDate1(String inactiveEffDate1) {
		this.inactiveEffDate1 = inactiveEffDate1;
	}

	public String getInactiveEffDate2() {
		return inactiveEffDate2;
	}

	public void setInactiveEffDate2(String inactiveEffDate2) {
		this.inactiveEffDate2 = inactiveEffDate2;
	}

	public List<BicCaraPeriodsEntity> getCaraPerList() {
		return caraPerList;
	}

	public void setCaraPerList(List<BicCaraPeriodsEntity> caraPerList) {
		this.caraPerList = caraPerList;
	}

	public List<BicIncarcationEntity> getIncarcList() {
		return incarcList;
	}

	public void setIncarcList(List<BicIncarcationEntity> incarcList) {
		this.incarcList = incarcList;
	}

	public List<BicNotlawfulEntity> getLawfullList() {
		return lawfullList;
	}

	public void setLawfullList(List<BicNotlawfulEntity> lawfullList) {
		this.lawfullList = lawfullList;
	}

	public List<BicPartDHistoryEntity> getPartDList() {
		return partDList;
	}

	public void setPartDList(List<BicPartDHistoryEntity> partDList) {
		this.partDList = partDList;
	}

	public List<BicRDSHistoryEntity> getRdsList() {
		return rdsList;
	}

	public void setRdsList(List<BicRDSHistoryEntity> rdsList) {
		this.rdsList = rdsList;
	}

	public List<BicUnCovMonthEntity> getUncovList() {
		return uncovList;
	}

	public void setUncovList(List<BicUnCovMonthEntity> uncovList) {
		this.uncovList = uncovList;
	}

}
