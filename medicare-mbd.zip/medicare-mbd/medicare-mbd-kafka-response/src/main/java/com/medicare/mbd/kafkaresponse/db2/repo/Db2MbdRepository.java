package com.medicare.mbd.kafkaresponse.db2.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.medicare.mbd.kafkaresponse.db2.entities.BicMbdEntity;

@Repository
public interface Db2MbdRepository extends CrudRepository<BicMbdEntity, Long> {
  
  
}