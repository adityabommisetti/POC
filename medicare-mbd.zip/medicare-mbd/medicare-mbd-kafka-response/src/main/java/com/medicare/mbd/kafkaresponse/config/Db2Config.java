package com.medicare.mbd.kafkaresponse.config;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(entityManagerFactoryRef = "entityManagerFactoryDb2", transactionManagerRef = "transactionManagerDb2", basePackages = {
		"com.medicare.mbd.kafkaresponse.db2.entities", "com.medicare.mbd.kafkaresponse.db2.repo" })
public class Db2Config {

	@Primary
	@Bean(name = "dataSourceDb2")
	@ConfigurationProperties(prefix = "db2.datasource")
	public DataSource dataSource() {
		return DataSourceBuilder.create().build();
	}

	@Primary
	@Bean(name = "entityManagerFactoryDb2")
	public LocalContainerEntityManagerFactoryBean entityManagerFactory(EntityManagerFactoryBuilder builder,
			@Qualifier("dataSourceDb2") DataSource dataSource) {
		Map<String, Object> properties = new HashMap<>();

		properties.put("hibernate.dialect", "org.hibernate.dialect.DB2400Dialect");
		properties.put("hibernate.show_sql", "true");
		return builder.dataSource(dataSource).packages("com.medicare.mbd.kafkaresponse.db2.entities")
				.persistenceUnit("db2").properties(properties).build();
	}

	@Primary
	@Bean(name = "transactionManagerDb2")
	public PlatformTransactionManager transactionManager(
			@Qualifier("entityManagerFactoryDb2") EntityManagerFactory entityManagerFactory) {
		return new JpaTransactionManager(entityManagerFactory);
	}
}