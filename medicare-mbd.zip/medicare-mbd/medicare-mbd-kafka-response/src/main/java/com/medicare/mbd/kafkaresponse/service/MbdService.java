package com.medicare.mbd.kafkaresponse.service;

import com.medicare.mbd.cmswrapper.client.model.ApiResponseDataBeneficiaryProfile;

public interface MbdService {

	void processResponse(ApiResponseDataBeneficiaryProfile response);

}
