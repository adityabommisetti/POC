package com.medicare.mbd.kafkaresponse.aop;

import org.aspectj.lang.annotation.Pointcut;

public class CommonJoinPointConfig {

	@Pointcut("execution(* com.medicare.mbd.kafkaresponse.service.*.*(..)) || execution(* com.medicare.mbd.kafkaresponse.dao.*.*(..)) || execution(* com.medicare.mbd.kafkaresponse.kafkaservice.*.*(..))")
	public void allLayerExecution() {
		// name of point cut
	}

}
