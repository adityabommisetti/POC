package com.medicare.mbd.kafkaresponse.db2.entities;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "BIC_UNCOVMO")
public class BicUnCovMonthEntity {
	@Column(name = "START_DATE")
	private String startDate;
	@Column(name = "UNCOV_MONTH_COUNT")
	private String monthsCount;
	@Column(name = "UNCOV_MONTH_IND")
	private String status;
	@EmbeddedId
    private MbdCompositeEntity id;
	@ManyToOne()
	@JoinColumn(name = "MBI")
	private BicMbdEntity bicMbd;
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getMonthsCount() {
		return monthsCount;
	}
	public void setMonthsCount(String monthsCount) {
		this.monthsCount = monthsCount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public MbdCompositeEntity getId() {
		return id;
	}
	public void setId(MbdCompositeEntity id) {
		this.id = id;
	}
	public BicMbdEntity getBicMbd() {
		return bicMbd;
	}
	public void setBicMbd(BicMbdEntity bicMbd) {
		this.bicMbd = bicMbd;
	}
	
}
