package com.medicare.mbd.kafkaresponse.domain;

import lombok.Data;

@Data
public class BicNotlawfulDO {
	private String startDate;
	private String stopDate;
	private String mbi;
	private int suqNum;
}
