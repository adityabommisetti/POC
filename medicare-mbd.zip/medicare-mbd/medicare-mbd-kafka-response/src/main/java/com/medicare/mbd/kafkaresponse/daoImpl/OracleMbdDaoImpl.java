package com.medicare.mbd.kafkaresponse.daoImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.medicare.mbd.kafkaresponse.dao.OracleMbdDao;
import com.medicare.mbd.kafkaresponse.oracle.entities.BicCaraPeriodsEntity;
import com.medicare.mbd.kafkaresponse.oracle.entities.BicIncarcationEntity;
import com.medicare.mbd.kafkaresponse.oracle.entities.BicMbdEntity;
import com.medicare.mbd.kafkaresponse.oracle.entities.BicNotlawfulEntity;
import com.medicare.mbd.kafkaresponse.oracle.entities.BicPartDHistoryEntity;
import com.medicare.mbd.kafkaresponse.oracle.entities.BicRDSHistoryEntity;
import com.medicare.mbd.kafkaresponse.oracle.entities.BicUnCovMonthEntity;
import com.medicare.mbd.kafkaresponse.oracle.entities.MbdCompositeEntity;
import com.medicare.mbd.kafkaresponse.oracle.repo.OracleMbdRepository;
import com.medicare.mbd.kafkaresponse.util.CommonUtils;

@Repository("oracleDao")
@Transactional("transactionManagerOracle")
public class OracleMbdDaoImpl implements OracleMbdDao {
	@Autowired
	OracleMbdRepository repo;

	@Override
	public void cloneAndSaveMbdEntityListOracle(
			List<com.medicare.mbd.kafkaresponse.db2.entities.BicMbdEntity> mbdEntityList) {
		List<BicMbdEntity> oracleMbdList = new ArrayList<>();
		
		BicMbdEntity oracleMbdEntity = null;
		for (com.medicare.mbd.kafkaresponse.db2.entities.BicMbdEntity db2Entity : mbdEntityList) {
			oracleMbdEntity = new BicMbdEntity();
			List<BicCaraPeriodsEntity> caraPerList = new ArrayList<>();
			List<BicIncarcationEntity> incarcList = new ArrayList<>();
			List<BicNotlawfulEntity> lawfullList = new ArrayList<>();
			List<BicPartDHistoryEntity> partDList = new ArrayList<>();
			List<BicRDSHistoryEntity> rdsList = new ArrayList<>();
			List<BicUnCovMonthEntity> uncovList = new ArrayList<>();
			BeanUtils.copyProperties(db2Entity, oracleMbdEntity);

			CommonUtils.copyList(db2Entity.getCaraPerList(), caraPerList, BicCaraPeriodsEntity.class);
			int i = 0;
			MbdCompositeEntity comp = null;
			for (BicCaraPeriodsEntity entity : caraPerList) {
				comp = new MbdCompositeEntity();
				BeanUtils.copyProperties(db2Entity.getCaraPerList().get(i).getId(), comp);
				entity.setId(comp);
				entity.setBicMbd(oracleMbdEntity);
				i++;
			}
			i = 0;
			CommonUtils.copyList(db2Entity.getIncarcList(), incarcList, BicIncarcationEntity.class);
			for (BicIncarcationEntity entity : incarcList) {
				comp = new MbdCompositeEntity();
				BeanUtils.copyProperties(db2Entity.getIncarcList().get(i).getId(), comp);
				entity.setId(comp);
				entity.setBicMbd(oracleMbdEntity);
				i++;
			}
			i=0;
			CommonUtils.copyList(db2Entity.getLawfullList(), lawfullList, BicNotlawfulEntity.class);
			for (BicNotlawfulEntity entity : lawfullList) {
				comp = new MbdCompositeEntity();
				BeanUtils.copyProperties(db2Entity.getLawfullList().get(i).getId(), comp);
				entity.setId(comp);
				entity.setBicMbd(oracleMbdEntity);
				i++;
			}
			i = 0;
			CommonUtils.copyList(db2Entity.getPartDList(), partDList, BicPartDHistoryEntity.class);
			for (BicPartDHistoryEntity entity : partDList) {
				comp = new MbdCompositeEntity();
				BeanUtils.copyProperties(db2Entity.getPartDList().get(i).getId(), comp);
				entity.setId(comp);
				entity.setBicMbd(oracleMbdEntity);
				i++;
			}
			i = 0;
			CommonUtils.copyList(db2Entity.getRdsList(), rdsList, BicRDSHistoryEntity.class);
			for (BicRDSHistoryEntity entity : rdsList) {
				comp = new MbdCompositeEntity();
				BeanUtils.copyProperties(db2Entity.getRdsList().get(i).getId(), comp);
				entity.setId(comp);
				entity.setBicMbd(oracleMbdEntity);
				i++;
			}
			i = 0;

			CommonUtils.copyList(db2Entity.getUncovList(), uncovList, BicUnCovMonthEntity.class);
			for (BicUnCovMonthEntity entity : uncovList) {
				comp = new MbdCompositeEntity();
				BeanUtils.copyProperties(db2Entity.getUncovList().get(i).getId(), comp);
				entity.setId(comp);
				entity.setBicMbd(oracleMbdEntity);
				i++;
			}

			oracleMbdEntity.setCaraPerList(caraPerList);
			oracleMbdEntity.setIncarcList(incarcList);
			oracleMbdEntity.setLawfullList(lawfullList);
			oracleMbdEntity.setPartDList(partDList);
			oracleMbdEntity.setRdsList(rdsList);
			oracleMbdEntity.setUncovList(uncovList);
			oracleMbdList.add(oracleMbdEntity);
		}

		repo.saveAll(oracleMbdList);

	}

}
