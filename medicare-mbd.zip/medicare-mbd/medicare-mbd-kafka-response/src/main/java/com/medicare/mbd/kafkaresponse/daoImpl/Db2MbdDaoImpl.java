package com.medicare.mbd.kafkaresponse.daoImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.medicare.mbd.kafkaresponse.dao.Db2MbdDao;
import com.medicare.mbd.kafkaresponse.db2.entities.BicMbdEntity;
import com.medicare.mbd.kafkaresponse.db2.entities.MbiEntity;
import com.medicare.mbd.kafkaresponse.db2.repo.Db2MbdRepository;
import com.medicare.mbd.kafkaresponse.db2.repo.Db2MbiRepository;

@Repository("db2Dao")
@Transactional("transactionManagerDb2")
public class Db2MbdDaoImpl implements Db2MbdDao {
	@Autowired
	Db2MbdRepository repo;
	
	@Autowired
	Db2MbiRepository mbiRepo;

	/*
	 * @Autowired private JdbcTemplate jdbcTemplate=null;
	 * 
	 * 
	 * 
	 * public void saveOrUpdateBicMbd() { try { String sql = CommonUtils.buildQuery(
	 * 
	 * "MERGE INTO BIC_MBD md USING (SELECT ? MBI,? FIRST_NAME,? MIDDLE_INIT,? LAST_NAME,"
	 * ,
	 * "? BIRTH_DATE,? DEATH_DATE,? GENDER_NUM_CD,? RACE_CD,? COUNTY_CD,? STATE_CD,? ZIP_CD,"
	 * ,
	 * "? PRTA_ENTITLE_DATE, ? PRTA_ENTITLE_EDATE,? PRTB_ENTITLE_DATE,? PRTB_ENTITLE_EDATE,"
	 * ,
	 * "? PRTD_ELIG_SDATE,? SUBSIDY_SDATE1,? SUBSIDY_SDATE2,? SUBSIDY_EDATE1,? SUBSIDY_EDATE2,"
	 * ,
	 * "? COPAY_LEVEL_ID1,? COPAY_LEVEL_ID2,? PRTD_PREMSUBS_PCT1,? PRTD_PREMSUBS_PCT2,"
	 * ,
	 * "? PLAN_ENROLL_DATE,? COPLAN_ENROLL_DT,? PLAN_DISENROL_DATE, ? COPLAN_DISENRL_DT,"
	 * ,
	 * "? PLAN_ID, ? COPLAN_ID,? PBP_ID,? COPLAN_PBP,? PLAN_DRUG_IND,? COPLAN_DRUG_IND,"
	 * ,
	 * "? PLAN_TYPE_CODE,? COPLAN_TYPE_CODE,? ENROLL_SRC_CD,? COPLAN_ENROLL_SRC_CD,"
	 * ,
	 * "? EGHP_IND, ? COPLAN_EGHP_IND,? PRIOR1_PLAN_ENROLL_DT ,? PRIOR2_PLAN_ENROLL_DT,"
	 * ,
	 * "? PRIOR1_PLAN_DISENROL_DT ,? PRIOR2_PLAN_DISENROL_DT,? PRIOR1_PLAN_ID ,? PRIOR2_PLAN_ID,"
	 * ,
	 * "? PRIOR1_PLAN_PBP ,? PRIOR2_PLAN_PBP,? PRIOR1_PLAN_DRUG_IND ,? PRIOR2_PLAN_DRUG_IND,"
	 * ,
	 * "? PRIOR1_PLAN_TYPE_CODE ,? PRIOR2_PLAN_TYPE_CODE,? PRIOR1_ENROLL_SRC_CD ,? PRIOR2_ENROLL_SRC_CD,"
	 * ,
	 * "? PRIOR1_PLAN_EGHP_IND ,? PRIOR2_PLAN_EGHP_IND,? MEDIC_IND,? HOSPICE_SDATE,? HOSPICE_EDATE,"
	 * ,
	 * "? ESRD_IND,? ESRD_SDATE,? ESRD_EDATE,? MEDIC_SDATE,? MEDIC_EDATE,? INST_SDATE,? INST_EDATE,"
	 * ,
	 * "? INACTIVE_MBI_1,? INACTIVE_MBI_2,? INACTIVE_MBI_1_SDATE,? INACTIVE_MBI_2_SDATE,"
	 * , "? INACTIVE_MBI_1_EDATE,? INACTIVE_MBI_2_EDATE FROM dual) newrec",
	 * "ON ( md.MBI = newrec.MBI)",
	 * "WHEN NOT MATCHED THEN INSERT (md.MBI,md.FIRST_NAME,md.MIDDLE_INIT,md.LAST_NAME,"
	 * ,
	 * "md.BIRTH_DATE,md.DEATH_DATE,md.GENDER_NUM_CD,md.RACE_CD,md.COUNTY_CD,md.STATE_CD,md.ZIP_CD,",
	 * "md.PRTA_ENTITLE_DATE,md.PRTA_ENTITLE_EDATE,md.PRTB_ENTITLE_DATE,md.PRTB_ENTITLE_EDATE,",
	 * "md.PRTD_ELIG_SDATE,md.SUBSIDY_SDATE1,md.SUBSIDY_SDATE2,md.SUBSIDY_EDATE1,md.SUBSIDY_EDATE2,",
	 * "md.COPAY_LEVEL_ID1,md.COPAY_LEVEL_ID2,md.PRTD_PREMSUBS_PCT1,md.PRTD_PREMSUBS_PCT2,",
	 * "md.PLAN_ENROLL_DATE,md.COPLAN_ENROLL_DT,md.PLAN_DISENROL_DATE,md.COPLAN_DISENRL_DT,",
	 * "md.PLAN_ID,md.COPLAN_ID,md.PBP_ID,md.COPLAN_PBP,md.PLAN_DRUG_IND,md.COPLAN_DRUG_IND,",
	 * "md.PLAN_TYPE_CODE,md.COPLAN_TYPE_CODE,md.ENROLL_SRC_CD,md.COPLAN_ENROLL_SRC_CD,",
	 * "md.EGHP_IND,md.COPLAN_EGHP_IND,md.PRIOR1_PLAN_ENROLL_DT,md.PRIOR2_PLAN_ENROLL_DT,",
	 * "md.PRIOR1_PLAN_DISENROL_DT,md.PRIOR2_PLAN_DISENROL_DT,md.PRIOR1_PLAN_ID,md.PRIOR2_PLAN_ID,",
	 * "md.PRIOR1_PLAN_PBP,md.PRIOR2_PLAN_PBP,md.PRIOR1_PLAN_DRUG_IND,md.PRIOR2_PLAN_DRUG_IND,",
	 * "md.PRIOR1_PLAN_TYPE_CODE,md.PRIOR2_PLAN_TYPE_CODE,md.PRIOR1_ENROLL_SRC_CD,md.PRIOR2_ENROLL_SRC_CD,",
	 * "md.PRIOR1_PLAN_EGHP_IND,md.PRIOR2_PLAN_EGHP_IND,md.MEDIC_IND,md.HOSPICE_SDATE,md.HOSPICE_EDATE,",
	 * "md.ESRD_IND,md.ESRD_SDATE,md.ESRD_EDATE,md.MEDIC_SDATE,md.MEDIC_EDATE,md.INST_SDATE,md.INST_EDATE,",
	 * "md.INACTIVE_MBI_1,md.INACTIVE_MBI_2,md.INACTIVE_MBI_1_SDATE,md.INACTIVE_MBI_2_SDATE,",
	 * "md.INACTIVE_MBI_1_EDATE,md.INACTIVE_MBI_2_EDATE) VALUES (newrec.MBI,newrec.FIRST_NAME,newrec.MIDDLE_INIT,"
	 * ,
	 * "newrec.LAST_NAME,newrec.BIRTH_DATE,newrec.DEATH_DATE,newrec.GENDER_NUM_CD,newrec.RACE_CD,newrec.COUNTY_CD,",
	 * "newrec.STATE_CD,newrec.ZIP_CD,newrec.PRTA_ENTITLE_DATE,newrec.PRTA_ENTITLE_EDATE,newrec.PRTB_ENTITLE_DATE,",
	 * "newrec.PRTB_ENTITLE_EDATE,newrec.PRTD_ELIG_SDATE,",
	 * "newrec.SUBSIDY_SDATE1,newrec.SUBSIDY_SDATE2,newrec.SUBSIDY_EDATE1,newrec.SUBSIDY_EDATE2,",
	 * "newrec.COPAY_LEVEL_ID1,newrec.COPAY_LEVEL_ID2,newrec.PRTD_PREMSUBS_PCT1,newrec.PRTD_PREMSUBS_PCT2,",
	 * "newrec.PLAN_ENROLL_DATE,newrec.COPLAN_ENROLL_DT,newrec.PLAN_DISENROL_DATE,newrec.COPLAN_DISENRL_DT,",
	 * "newrec.PLAN_ID,newrec.COPLAN_ID,newrec.PBP_ID,newrec.COPLAN_PBP,newrec.PLAN_DRUG_IND,newrec.COPLAN_DRUG_IND,",
	 * "newrec.PLAN_TYPE_CODE,newrec.COPLAN_TYPE_CODE,newrec.ENROLL_SRC_CD,newrec.COPLAN_ENROLL_SRC_CD,",
	 * "newrec.EGHP_IND,newrec.COPLAN_EGHP_IND,newrec.PRIOR1_PLAN_ENROLL_DT,newrec.PRIOR2_PLAN_ENROLL_DT,",
	 * "newrec.PRIOR1_PLAN_DISENROL_DT,newrec.PRIOR2_PLAN_DISENROL_DT,newrec.PRIOR1_PLAN_ID,newrec.PRIOR2_PLAN_ID,",
	 * "newrec.PRIOR1_PLAN_PBP,newrec.PRIOR2_PLAN_PBP,newrec.PRIOR1_PLAN_DRUG_IND,newrec.PRIOR2_PLAN_DRUG_IND,",
	 * "newrec.PRIOR1_PLAN_TYPE_CODE,newrec.PRIOR2_PLAN_TYPE_CODE,newrec.PRIOR1_ENROLL_SRC_CD,newrec.PRIOR2_ENROLL_SRC_CD,",
	 * "newrec.PRIOR1_PLAN_EGHP_IND,newrec.PRIOR2_PLAN_EGHP_IND,newrec.MEDIC_IND,newrec.HOSPICE_SDATE,newrec.HOSPICE_EDATE,",
	 * "newrec.ESRD_IND,newrec.ESRD_SDATE,newrec.ESRD_EDATE,newrec.MEDIC_SDATE,newrec.MEDIC_EDATE,newrec.INST_SDATE,newrec.INST_EDATE,",
	 * "newrec.INACTIVE_MBI_1,newrec.INACTIVE_MBI_2,newrec.INACTIVE_MBI_1_SDATE,newrec.INACTIVE_MBI_2_SDATE,",
	 * "newrec.INACTIVE_MBI_1_EDATE,newrec.INACTIVE_MBI_2_EDATE)",
	 * "WHEN MATCHED THEN UPDATE SET ",
	 * "md.MBI=newrec.MBI,md.FIRST_NAME=newrec.FIRST_NAME,md.MIDDLE_INIT=newrec.MIDDLE_INIT,md.LAST_NAME=newrec.LAST_NAME,",
	 * "md.BIRTH_DATE=newrec.BIRTH_DATE,md.DEATH_DATE=newrec.DEATH_DATE,md.GENDER_NUM_CD=newrec.GENDER_NUM_CD,md.RACE_CD=newrec.RACE_CD,",
	 * "md.COUNTY_CD=newrec.COUNTY_CD,md.STATE_CD=newrec.STATE_CD,md.ZIP_CD=newrec.ZIP_CD,",
	 * "md.PRTA_ENTITLE_DATE=newrec.PRTA_ENTITLE_DATE,md.PRTA_ENTITLE_EDATE=newrec.PRTA_ENTITLE_EDATE,md.PRTB_ENTITLE_DATE=newrec.PRTB_ENTITLE_DATE",
	 * ",md.PRTB_ENTITLE_EDATE=newrec.PRTB_ENTITLE_EDATE,md.PRTD_ELIG_SDATE=newrec.PRTD_ELIG_SDATE,md.SUBSIDY_SDATE1=newrec.SUBSIDY_SDATE1,",
	 * "md.SUBSIDY_SDATE2=newrec.SUBSIDY_SDATE2,md.SUBSIDY_EDATE1=newrec.SUBSIDY_EDATE1,md.SUBSIDY_EDATE2=newrec.SUBSIDY_EDATE2,",
	 * "md.COPAY_LEVEL_ID1=newrec.COPAY_LEVEL_ID1,md.COPAY_LEVEL_ID2=newrec.COPAY_LEVEL_ID2,md.PRTD_PREMSUBS_PCT1=newrec.PRTD_PREMSUBS_PCT1,",
	 * "md.PRTD_PREMSUBS_PCT2=newrec.PRTD_PREMSUBS_PCT2,md.PLAN_ENROLL_DATE=newrec.PLAN_ENROLL_DATE,md.COPLAN_ENROLL_DT=newrec.COPLAN_ENROLL_DT,",
	 * ",md.PLAN_DISENROL_DATE=newrec.PLAN_DISENROL_DATE,md.COPLAN_DISENRL_DT=newrec.COPLAN_DISENRL_DT,",
	 * "md.PLAN_ID=newrec.PLAN_ID,md.COPLAN_ID=newrec.COPLAN_ID,md.PBP_ID=newrec.PBP_ID,md.COPLAN_PBP=newrec.COPLAN_PBP,",
	 * "md.PLAN_DRUG_IND=newrec.PLAN_DRUG_IND,md.COPLAN_DRUG_IND=newrec.COPLAN_DRUG_IND,",
	 * "md.PLAN_TYPE_CODE=newrec.PLAN_TYPE_CODE,md.COPLAN_TYPE_CODE=newrec.COPLAN_TYPE_CODE,md.ENROLL_SRC_CD=newrec.ENROLL_SRC_CD,",
	 * "md.COPLAN_ENROLL_SRC_CD=newrec.COPLAN_ENROLL_SRC_CD,md.EGHP_IND=newrec.EGHP_IND,md.COPLAN_EGHP_IND=newrec.COPLAN_EGHP_IND,",
	 * "md.PRIOR1_PLAN_ENROLL_DT=newrec.PRIOR1_PLAN_ENROLL_DT,md.PRIOR2_PLAN_ENROLL_DT=newrec.PRIOR2_PLAN_ENROLL_DT,",
	 * "md.PRIOR1_PLAN_DISENROL_DT=newrec.PRIOR1_PLAN_DISENROL_DT,md.PRIOR2_PLAN_DISENROL_DT=newrec.PRIOR2_PLAN_DISENROL_DT,",
	 * "md.PRIOR1_PLAN_ID=newrec.PRIOR1_PLAN_ID,md.PRIOR2_PLAN_ID=newrec.PRIOR2_PLAN_ID,",
	 * "md.PRIOR1_PLAN_PBP=newrec.PRIOR1_PLAN_PBP,md.PRIOR2_PLAN_PBP=newrec.PRIOR2_PLAN_PBP,md.PRIOR1_PLAN_DRUG_IND=newrec.PRIOR1_PLAN_DRUG_IND,",
	 * "md.PRIOR2_PLAN_DRUG_IND=newrec.PRIOR2_PLAN_DRUG_IND,md.PRIOR1_PLAN_TYPE_CODE=newrec.PRIOR1_PLAN_TYPE_CODE,md.PRIOR2_PLAN_TYPE_CODE=newrec.PRIOR2_PLAN_TYPE_CODE,",
	 * "md.PRIOR1_ENROLL_SRC_CD=newrec.PRIOR1_ENROLL_SRC_CD,md.PRIOR2_ENROLL_SRC_CD=newrec.PRIOR2_ENROLL_SRC_CD,",
	 * "md.PRIOR1_PLAN_EGHP_IND=newrec.PRIOR1_PLAN_EGHP_IND,md.PRIOR2_PLAN_EGHP_IND=newrec.PRIOR2_PLAN_EGHP_IND,",
	 * "md.MEDIC_IND=newrec.MEDIC_IND,md.HOSPICE_SDATE=newrec.HOSPICE_SDATE,md.HOSPICE_EDATE=newrec.HOSPICE_EDATE,",
	 * "md.ESRD_IND=newrec.ESRD_IND,md.ESRD_SDATE=newrec.ESRD_SDATE,md.ESRD_EDATE=newrec.ESRD_EDATE,md.MEDIC_SDATE=newrec.MEDIC_SDATE,",
	 * "md.MEDIC_EDATE=newrec.MEDIC_EDATE,md.INST_SDATE=newrec.INST_SDATE,md.INST_EDATE=newrec.INST_EDATE,",
	 * "md.INACTIVE_MBI_1=newrec.INACTIVE_MBI_1,md.INACTIVE_MBI_2=newrec.INACTIVE_MBI_2,md.INACTIVE_MBI_1_SDATE=newrec.INACTIVE_MBI_1_SDATE,",
	 * "md.INACTIVE_MBI_2_SDATE=newrec.INACTIVE_MBI_2_SDATE,md.INACTIVE_MBI_1_EDATE=newrec.INACTIVE_MBI_1_EDATE,md.INACTIVE_MBI_2_EDATE=newrec.INACTIVE_MBI_2_EDATE"
	 * ); jdbcTemplate.update(sql, new Object[] { "test", "test1" });
	 * 
	 * } catch (DataAccessException exp) { throw new ApplicationException(exp,
	 * "error occured while saveOrUpdateBicMbd!!"); } }
	 * 
	 * public void saveOrUpdatePartDHistory() { try { String sql =
	 * CommonUtils.buildQuery(
	 * "MERGE INTO BIC_PARTDHISTORY md USING (SELECT ?  PARTD_SDATE,? PARTD_EDATE,? SEQ_NUM FROM dual) newrec"
	 * ,
	 * "ON ( md.MBI = newrec.MBI AND md.SEQ_NUM = newrec.SEQ_NUM ) WHEN NOT MATCHED THEN"
	 * ,
	 * "INSERT (md.MBI,md.SEQ_NUM,md.PARTD_SDATE, md.PARTD_EDATE) VALUES (newrec.MBI, newrec.SEQ_NUM, newrec.PARTD_SDATE,newrec.PARTD_EDATE)"
	 * ,
	 * "WHEN MATCHED THEN UPDATE SET md.MBI=newrec.MBI,md.SEQ_NUM=newrec.SEQ_NUM,md.PARTD_SDATE=newrec.PARTD_SDATE, md.PARTD_EDATE=newrec.PARTD_EDATE"
	 * ); jdbcTemplate.update(sql, new Object[] { "test", "test1" }); } catch
	 * (DataAccessException exp) { throw new ApplicationException(exp,
	 * "error occured while saveOrUpdateBicMbd!!"); } }
	 * 
	 * public void saveOrUpdateRdsHostory() { try { String sql =
	 * CommonUtils.buildQuery(
	 * "MERGE INTO BIC_RDSHISTORY md USING (SELECT ?  RDS_SDATE,? RDS_EDATE,? SEQ_NUM FROM dual) newrec"
	 * ,
	 * "ON ( md.MBI = newrec.MBI AND md.SEQ_NUM = newrec.SEQ_NUM ) WHEN NOT MATCHED THEN"
	 * ,
	 * "INSERT (md.MBI,md.SEQ_NUM,md.RDS_SDATE, md.RDS_EDATE) VALUES (newrec.MBI, newrec.SEQ_NUM, newrec.RDS_SDATE,newrec.RDS_EDATE)"
	 * ,
	 * "WHEN MATCHED THEN UPDATE SET md.MBI=newrec.MBI,md.SEQ_NUM=newrec.SEQ_NUM,md.RDS_SDATE=newrec.RDS_SDATE, md.RDS_EDATE=newrec.RDS_EDATE"
	 * ); jdbcTemplate.update(sql, new Object[] { "test", "test1" }); } catch
	 * (DataAccessException exp) { throw new ApplicationException(exp,
	 * "error occured while saveOrUpdateBicMbd!!"); } }
	 * 
	 * public void saveOrUpdateUnCovMonths() { try { String sql =
	 * CommonUtils.buildQuery(
	 * "MERGE INTO BIC_UNCOVMO md USING (SELECT ?  START_DATE,? UNCOV_MONTH_COUNT,? UNCOV_MONTH_IND,? SEQ_NUM FROM dual) newrec"
	 * ,
	 * "ON ( md.MBI = newrec.MBI AND md.SEQ_NUM = newrec.SEQ_NUM ) WHEN NOT MATCHED THEN"
	 * ,
	 * "INSERT (md.MBI,md.SEQ_NUM,md.START_DATE, md.UNCOV_MONTH_COUNT,md.UNCOV_MONTH_IND) VALUES (newrec.MBI,newrec.SEQ_NUM,newrec.START_DATE, newrec.UNCOV_MONTH_COUNT,newrec.UNCOV_MONTH_IND)"
	 * ,
	 * "WHEN MATCHED THEN UPDATE SET md.MBI=newrec.MBI,md.SEQ_NUM=newrec.SEQ_NUM,md.START_DATE=newrec.START_DATE, md.UNCOV_MONTH_COUNT=newrec.UNCOV_MONTH_COUNT,md.UNCOV_MONTH_IND=newrec.UNCOV_MONTH_IND"
	 * ); jdbcTemplate.update(sql, new Object[] { "test", "test1" }); } catch
	 * (DataAccessException exp) { throw new ApplicationException(exp,
	 * "error occured while saveOrUpdateBicMbd!!"); } }
	 * 
	 * public void saveOrUpdateNotLawFul() { try { String sql =
	 * CommonUtils.buildQuery(
	 * "MERGE INTO BIC_PARTDHISTORY md USING (SELECT ?  NLFP_SDATE,? NLFP_EDATE,? SEQ_NUM FROM dual) newrec"
	 * ,
	 * "ON ( md.MBI = newrec.MBI AND md.SEQ_NUM = newrec.SEQ_NUM ) WHEN NOT MATCHED THEN"
	 * ,
	 * "INSERT (md.MBI,md.SEQ_NUM,md.NLFP_SDATE, md.NLFP_EDATE) VALUES (newrec.MBI, newrec.SEQ_NUM, newrec.NLFP_SDATE,newrec.NLFP_EDATE)"
	 * ,
	 * "WHEN MATCHED THEN UPDATE SET md.MBI=newrec.MBI,md.SEQ_NUM=newrec.SEQ_NUM,md.NLFP_SDATE=newrec.NLFP_SDATE, md.NLFP_EDATE=newrec.PARTNLFP_EDATED_EDATE"
	 * ); jdbcTemplate.update(sql, new Object[] { "test", "test1" }); } catch
	 * (DataAccessException exp) { throw new ApplicationException(exp,
	 * "error occured while saveOrUpdateBicMbd!!"); } }
	 * 
	 * public void saveOrUpdateBicCaraPeriods() { try { String sql =
	 * CommonUtils.buildQuery(
	 * "MERGE INTO BIC_PARTDHISTORY md USING (SELECT ?  CARA_SDATE,? CARA_EDATE,? SEQ_NUM FROM dual) newrec"
	 * ,
	 * "ON ( md.MBI = newrec.MBI AND md.SEQ_NUM = newrec.SEQ_NUM ) WHEN NOT MATCHED THEN"
	 * ,
	 * "INSERT (md.MBI,md.SEQ_NUM,md.CARA_SDATE, md.CARA_EDATE) VALUES (newrec.MBI, newrec.SEQ_NUM, newrec.CARA_SDATE,newrec.CARA_EDATE)"
	 * ,
	 * "WHEN MATCHED THEN UPDATE SET md.MBI=newrec.MBI,md.SEQ_NUM=newrec.SEQ_NUM,md.CARA_SDATE=newrec.CARA_SDATE, md.CARA_EDATE=newrec.CARA_EDATE"
	 * ); jdbcTemplate.update(sql, new Object[] { "test", "test1" }); } catch
	 * (DataAccessException exp) { throw new ApplicationException(exp,
	 * "error occured while saveOrUpdateBicMbd!!"); } }
	 * 
	 * public void saveOrUpdateBicIncarcation() { try { String sql =
	 * CommonUtils.buildQuery(
	 * "MERGE INTO BIC_PARTDHISTORY md USING (SELECT ?  SDATE,? EDATE,? SEQ_NUM FROM dual) newrec"
	 * ,
	 * "ON ( md.MBI = newrec.MBI AND md.SEQ_NUM = newrec.SEQ_NUM ) WHEN NOT MATCHED THEN"
	 * ,
	 * "INSERT (md.MBI,md.SEQ_NUM,md.SDATE, md.EDATE) VALUES (newrec.MBI, newrec.SEQ_NUM, newrec.SDATE,newrec.EDATE)"
	 * ,
	 * "WHEN MATCHED THEN UPDATE SET md.MBI=newrec.MBI,md.SEQ_NUM=newrec.SEQ_NUM,md.SDATE=newrec.SDATE, md.EDATE=newrec.EDATE"
	 * ); jdbcTemplate.update(sql, new Object[] { "test", "test1" }); } catch
	 * (DataAccessException exp) { throw new ApplicationException(exp,
	 * "error occured while saveOrUpdateBicMbd!!"); } }
	 */

	@Override
	public void saveMbdEntityListDb2(List<BicMbdEntity> mbdEntityList) {
		repo.saveAll(mbdEntityList);

	}

	@Override
	public void updateMbiStatusList(List<MbiEntity> mbiEntityList) {
		mbiRepo.saveAll(mbiEntityList);
		
	}
}
