package com.medicare.mbd.kafkaresponse.domain;

import lombok.Data;

@Data
public class BicCaraPeriodsDO {
	private String startDate;
	private String stopDate;
	private String mbi;
	private int suqNum;
}
