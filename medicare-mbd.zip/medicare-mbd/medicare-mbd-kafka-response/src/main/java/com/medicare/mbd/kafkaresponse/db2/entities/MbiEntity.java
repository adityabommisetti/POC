package com.medicare.mbd.kafkaresponse.db2.entities;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "BIC_MBI")
public class MbiEntity {
	@EmbeddedId
	private MbiCompositeEntity id;
	@Column(name="LAST_UPDATED",updatable=false)
	private Timestamp lastUpdated;
	@Column(name="STATUS")
	private String status;
	@Column(name="ERROR_MSG")
	private String errorMsg;
	public MbiCompositeEntity getId() {
		return id;
	}
	public void setId(MbiCompositeEntity id) {
		this.id = id;
	}
	public Timestamp getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(Timestamp lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	
}
