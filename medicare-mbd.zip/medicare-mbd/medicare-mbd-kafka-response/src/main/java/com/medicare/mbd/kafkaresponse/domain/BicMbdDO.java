package com.medicare.mbd.kafkaresponse.domain;

import lombok.Data;

@Data
public class BicMbdDO {
	private String mbi;
	private String firstName;
	private String middleInitial;
	private String lastName;
	private String birthDate;
	private String deathDate;
	private String gender;
	private String race;
	private String ssaCounty;
	private String zipCode;
	private String partAStartDate;
	private String partAStopDate;
	private String partBStartDate;
	private String partBStopDate;
	private String partDEligStartDate;
	private String partDEligStopDate;
	private String lowIncomeStartDate;
	private String lowIncomeStopDate;
	private String copaymentLevel;
	private String premiumSubsidyPercent;
	private String currEnrollDate;
	private String currDisEnrollDate;
	private String currEnrollPlanBenefitPackageNumber;
	private String currEnrollProgramType;
	private String currEnrollPlanType;
	private String currEnrollSourceType;
	private String currEnrollIsEmpGrpHlthPlan;
	private String priorEnrollDate;
	private String priorDisEnrollDate;
	private String priorEnrollPlanBenefitPackageNumber;
	private String priorEnrollProgramType;
	private String priorEnrollPlanType;
	private String priorEnrollSourceType;
	private String priorEnrollIsEmpGrpHlthPlan;
	private String hasMedicaid;
	private String hospiceStartDate;
	private String hospiceStopDate;
	private String esrdInd;
	private String esrdStartDate;
	private String esrdStopDate;
	private String medicaidStartDate;
	private String medicaidStopDate;
	private String insStartDate;
	private String insStopDate;
	private String inactiveMbi;
	private String inactiveTermDate;
	private String inactiveEffDate;

}
