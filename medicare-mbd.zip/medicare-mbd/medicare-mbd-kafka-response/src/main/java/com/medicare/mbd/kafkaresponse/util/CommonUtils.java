package com.medicare.mbd.kafkaresponse.util;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.util.Assert;

/**
 * @author Wipro Ltd.
 *
 */
public final class CommonUtils {

	private CommonUtils() {
		// private constructor to resolve sonar violation
	}

	public static String buildQuery(String... queryStr) {
		return buildQueryBuilder(queryStr).toString();
	}
	public static Object trimObject(Object obj) {
		for (Field field : obj.getClass().getDeclaredFields()) {
			try {
				field.setAccessible(true);
				Object value = field.get(obj);
				if (value != null) {
					if (value instanceof String) {
						String trimmed = (String) value;
						field.set(obj, trimmed.trim());
					}
				} else {
					if (field.getType().equals(String.class)) {
						field.set(obj, "");
					}

				}
			} catch (Exception e) {
			}
		}
		return obj;
	}
	public static StringBuilder buildQueryBuilder(String... queryStr) {
		StringBuilder queryBuilder = new StringBuilder();
		Arrays.asList(queryStr).forEach(qstr -> queryBuilder.append(qstr).append(StringUtils.SPACE));
		return queryBuilder;
	}
	@SuppressWarnings("deprecation")
	public static <T, U> void copyList(List<T> srcList, List<U> targetList, Class<U> targetClass) {

		Assert.notNull(srcList, "Source list must not be null");
		Assert.notNull(targetList, "Target list must not be null");
		Assert.notNull(targetClass, "Target class must not be null");

		srcList.forEach(src -> {
			U target = BeanUtils.instantiate(targetClass);
			BeanUtils.copyProperties(src, target);
			targetList.add(target);
		});
	}

}
