package com.medicare.mbd.kafkaresponse.kafkaservice;

import java.time.Duration;
import java.time.Instant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.medicare.mbd.cmswrapper.client.model.ApiResponseDataBeneficiaryProfile;
import com.medicare.mbd.kafkaresponse.service.MbdService;

@Service
public class Consumer {
	private static final Logger logger = LoggerFactory.getLogger(Consumer.class);

	@Autowired
	private MbdService mbdService;

	ObjectMapper objectMapper = new ObjectMapper();

	@KafkaListener(topics = "${cms_response_topic_name}", groupId = "${spring.kafka.consumer.group-id}")
	public void consumeCmsResponse(String message,Acknowledgment acknowledgment) throws JsonProcessingException {
		System.out.println(message);
		Instant start = Instant.now();
		logger.info("Kafka response topic message received to process to database");
		ApiResponseDataBeneficiaryProfile response = objectMapper.readValue(message,
				ApiResponseDataBeneficiaryProfile.class);
	    acknowledgment.acknowledge();

		mbdService.processResponse(response);
		
		Instant finish = Instant.now();
		 
	    long timeElapsed = Duration.between(start, finish).toMillis();  //in millis
	    System.out.println("Time taken for batch:"+response.getBEQ().size()+"execution is:"+timeElapsed);
	}

}