package com.medicare.mbd.kafkaresponse.db2.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Id;

import lombok.Data;

@Embeddable
public class MbdCompositeEntity implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7835430065452757642L;

	// @Column(name="MBI")
	// private String mbi;
	@Column(name = "SEQ_NBR")
	private int seqNum;

	public int getSeqNum() {
		return seqNum;
	}

	public void setSeqNum(int seqNum) {
		this.seqNum = seqNum;
	}

}