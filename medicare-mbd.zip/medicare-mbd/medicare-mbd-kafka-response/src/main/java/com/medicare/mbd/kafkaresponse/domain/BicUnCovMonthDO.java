package com.medicare.mbd.kafkaresponse.domain;

import lombok.Data;

@Data
public class BicUnCovMonthDO {
	private String startDate;
	private String monthsCount;
	private String status;
	private String mbi;
	private int suqNum;
}
