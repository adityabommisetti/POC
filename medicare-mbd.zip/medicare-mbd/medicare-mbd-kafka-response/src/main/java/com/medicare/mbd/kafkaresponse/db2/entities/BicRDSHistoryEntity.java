package com.medicare.mbd.kafkaresponse.db2.entities;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "BIC_RDSHISTORY")
public class BicRDSHistoryEntity {
	@Column(name = "RDS_SDATE")
	private String startDate;
	@Column(name = "RDS_EDATE")
	private String stopDate;
	@EmbeddedId
    private MbdCompositeEntity id;
	@ManyToOne()
	@JoinColumn(name = "MBI")
	private BicMbdEntity bicMbd;
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getStopDate() {
		return stopDate;
	}
	public void setStopDate(String stopDate) {
		this.stopDate = stopDate;
	}
	public MbdCompositeEntity getId() {
		return id;
	}
	public void setId(MbdCompositeEntity id) {
		this.id = id;
	}
	public BicMbdEntity getBicMbd() {
		return bicMbd;
	}
	public void setBicMbd(BicMbdEntity bicMbd) {
		this.bicMbd = bicMbd;
	}
	
}
