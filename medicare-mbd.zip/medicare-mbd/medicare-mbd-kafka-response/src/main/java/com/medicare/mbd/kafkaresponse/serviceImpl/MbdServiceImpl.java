package com.medicare.mbd.kafkaresponse.serviceImpl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Objects;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.medicare.mbd.cmswrapper.client.model.ApiResponseDataBeneficiaryProfile;
import com.medicare.mbd.cmswrapper.client.model.BEQBeneficiary;
import com.medicare.mbd.cmswrapper.client.model.BEQEnrollment;
import com.medicare.mbd.cmswrapper.client.model.BEQEsrdCov;
import com.medicare.mbd.cmswrapper.client.model.BEQInactiveMbi;
import com.medicare.mbd.cmswrapper.client.model.BEQLowIncomeSubsidy;
import com.medicare.mbd.cmswrapper.client.model.BEQPeriod;
import com.medicare.mbd.cmswrapper.client.model.BEQRequest;
import com.medicare.mbd.cmswrapper.client.model.BEQResponse;
import com.medicare.mbd.cmswrapper.client.model.BEQResponseCode;
import com.medicare.mbd.cmswrapper.client.model.BEQStateCounty;
import com.medicare.mbd.cmswrapper.client.model.BEQUncoveredMonths;
import com.medicare.mbd.kafkaresponse.dao.Db2MbdDao;
import com.medicare.mbd.kafkaresponse.dao.OracleMbdDao;
import com.medicare.mbd.kafkaresponse.db2.entities.BicCaraPeriodsEntity;
import com.medicare.mbd.kafkaresponse.db2.entities.BicIncarcationEntity;
import com.medicare.mbd.kafkaresponse.db2.entities.BicMbdEntity;
import com.medicare.mbd.kafkaresponse.db2.entities.BicNotlawfulEntity;
import com.medicare.mbd.kafkaresponse.db2.entities.BicPartDHistoryEntity;
import com.medicare.mbd.kafkaresponse.db2.entities.BicRDSHistoryEntity;
import com.medicare.mbd.kafkaresponse.db2.entities.BicUnCovMonthEntity;
import com.medicare.mbd.kafkaresponse.db2.entities.MbdCompositeEntity;
import com.medicare.mbd.kafkaresponse.db2.entities.MbiCompositeEntity;
import com.medicare.mbd.kafkaresponse.db2.entities.MbiEntity;
import com.medicare.mbd.kafkaresponse.service.MbdService;
import com.medicare.mbd.kafkaresponse.util.CommonUtils;

@Service
public class MbdServiceImpl implements MbdService {
	private static final Logger logger = LoggerFactory.getLogger(MbdServiceImpl.class);

	@Autowired
	@Qualifier("db2Dao")
	Db2MbdDao db2Dao;

	@Autowired
	@Qualifier("oracleDao")
	OracleMbdDao oracleDao;

	@Override
	public void processResponse(ApiResponseDataBeneficiaryProfile response) {
		List<BicMbdEntity> mbdEntityList = new ArrayList<>();
		List<BEQResponse> resList = response.getBEQ();
		BicMbdEntity bicMbdEntity = null;
		List<MbiEntity> mbiEntityList = new ArrayList<>();
		MbiEntity mbiEntity = null;
		for (BEQResponse res : resList) {
			bicMbdEntity = new BicMbdEntity();
			mbiEntity = new MbiEntity();
			MbiCompositeEntity mbiCompEntity = new MbiCompositeEntity();
			List<BEQResponseCode> resCodes = res.getResponseCodes();
			BEQRequest request = res.getRequest();
			mbiCompEntity.setDob(request.getBeneficiaryBirthDate());
			mbiCompEntity.setJobInsName(removeDobAndMbrId(request.getRequestorTransactionId(),
					request.getBeneficiaryIdentifier(), request.getBeneficiaryBirthDate()));
			mbiCompEntity.setMemberId(request.getBeneficiaryIdentifier());
			Calendar calendar = Calendar.getInstance();
			java.util.Date now = calendar.getTime();
			mbiEntity.setLastUpdated(new java.sql.Timestamp(now.getTime()));
			if (Objects.isNull(resCodes) || resCodes.isEmpty() || !resCodes.get(0).getCode().equals("000")) {
				mbiEntity.setStatus("FAILED");
				if (!Objects.isNull(resCodes) && !resCodes.isEmpty()) {
					mbiEntity.setErrorMsg(resCodes.get(0).getCode());
				}
				mbiEntity.setId(mbiCompEntity);
				mbiEntityList.add(mbiEntity);
				continue;
			} else {
				mbiEntity.setStatus("SUCCESS");
				mbiEntity.setErrorMsg("NA");
				mbiEntity.setId(mbiCompEntity);
				mbiEntityList.add(mbiEntity);
			}

			bicMbdEntity = prepareBicMbd(bicMbdEntity, res);
			bicMbdEntity.setCaraPerList(prepareBicCaraPeriodsEntity(res, bicMbdEntity));
			bicMbdEntity.setIncarcList(prepareBicIncarcationEntity(res, bicMbdEntity));
			bicMbdEntity.setLawfullList(prepareBicNotlawfulEntity(res, bicMbdEntity));
			bicMbdEntity.setPartDList(prepareBicPartDHistoryEntity(res, bicMbdEntity));
			bicMbdEntity.setRdsList(prepareBicRDSHistoryEntity(res, bicMbdEntity));
			bicMbdEntity.setUncovList(prepareBicUnCovMonthEntity(res, bicMbdEntity));
			CommonUtils.trimObject(bicMbdEntity);
			mbdEntityList.add(bicMbdEntity);
		}
		try {
			logger.info("Saving cms response to m360 db2 database tables.");

			db2Dao.saveMbdEntityListDb2(mbdEntityList);
			logger.info("Saving cms response to m360 oracle database tables.");
			oracleDao.cloneAndSaveMbdEntityListOracle(mbdEntityList);
		} catch (Exception exp) {
			logger.error("Failed to process cms response to database tables");
			mbiEntityList.forEach(ref -> {
				ref.setStatus("FAILED");
				ref.setErrorMsg(exp.getMessage());
			});

		}
		logger.info("Updating Mbi status list");
		db2Dao.updateMbiStatusList(mbiEntityList);

	}

	private List<BicUnCovMonthEntity> prepareBicUnCovMonthEntity(BEQResponse res, BicMbdEntity bicMbdEntity) {
		BicUnCovMonthEntity entity = null;
		List<BicUnCovMonthEntity> entityList = new ArrayList<>();
		MbdCompositeEntity compositeEntity = null;
		List<BEQUncoveredMonths> resList = res.getUncoveredMonths();
		int seq = 0;
		for (BEQUncoveredMonths ref : resList) {
			seq++;
			compositeEntity = new MbdCompositeEntity();
			compositeEntity.setSeqNum(seq);
			entity = new BicUnCovMonthEntity();
			entity.setBicMbd(bicMbdEntity);
			entity.setId(compositeEntity);
			entity.setStartDate(formatDate(ref.getStartDate()));
			entity.setMonthsCount(formatDate(ref.getMonthsCount().toString()));
			entity.setStatus(entity.getStatus());
			CommonUtils.trimObject(entity);
			entityList.add(entity);
		}
		return entityList;
	}

	private List<BicRDSHistoryEntity> prepareBicRDSHistoryEntity(BEQResponse res, BicMbdEntity bicMbdEntity) {
		BicRDSHistoryEntity entity = null;
		List<BicRDSHistoryEntity> entityList = new ArrayList<>();
		MbdCompositeEntity compositeEntity = null;
		List<BEQPeriod> resList = res.getRetireeDrugCoverage();
		int seq = 0;
		for (BEQPeriod ref : resList) {
			seq++;
			compositeEntity = new MbdCompositeEntity();
			compositeEntity.setSeqNum(seq);
			entity = new BicRDSHistoryEntity();
			entity.setBicMbd(bicMbdEntity);
			entity.setId(compositeEntity);
			entity.setStartDate(formatDate(ref.getStartDate()));
			entity.setStopDate(formatDate(ref.getStopDate()));
			CommonUtils.trimObject(entity);
			entityList.add(entity);
		}
		return entityList;
	}

	private List<BicPartDHistoryEntity> prepareBicPartDHistoryEntity(BEQResponse res, BicMbdEntity bicMbdEntity) {
		BicPartDHistoryEntity entity = null;
		List<BicPartDHistoryEntity> entityList = new ArrayList<>();
		MbdCompositeEntity compositeEntity = null;
		List<BEQPeriod> resList = res.getPartDEnrollmentPeriods();
		int seq = 0;
		for (BEQPeriod ref : resList) {
			seq++;
			compositeEntity = new MbdCompositeEntity();
			compositeEntity.setSeqNum(seq);
			entity = new BicPartDHistoryEntity();
			entity.setBicMbd(bicMbdEntity);
			entity.setId(compositeEntity);
			entity.setStartDate(formatDate(ref.getStartDate()));
			entity.setStopDate(formatDate(ref.getStopDate()));
			CommonUtils.trimObject(entity);
			entityList.add(entity);
		}
		return entityList;
	}

	private List<BicNotlawfulEntity> prepareBicNotlawfulEntity(BEQResponse res, BicMbdEntity bicMbdEntity) {
		BicNotlawfulEntity entity = null;
		List<BicNotlawfulEntity> entityList = new ArrayList<>();
		MbdCompositeEntity compositeEntity = null;
		List<BEQPeriod> resList = res.getNotLawfulPresencePeriods();
		int seq = 0;
		for (BEQPeriod ref : resList) {
			seq++;
			compositeEntity = new MbdCompositeEntity();
			compositeEntity.setSeqNum(seq);
			entity = new BicNotlawfulEntity();
			entity.setBicMbd(bicMbdEntity);
			entity.setId(compositeEntity);
			entity.setStartDate(formatDate(ref.getStartDate()));
			entity.setStopDate(formatDate(ref.getStopDate()));
			CommonUtils.trimObject(entity);
			entityList.add(entity);
		}
		return entityList;
	}

	private List<BicIncarcationEntity> prepareBicIncarcationEntity(BEQResponse res, BicMbdEntity bicMbdEntity) {
		BicIncarcationEntity entity = null;
		List<BicIncarcationEntity> entityList = new ArrayList<>();
		MbdCompositeEntity compositeEntity = null;
		List<BEQPeriod> resList = res.getIncarcerationPeriods();
		int seq = 0;
		for (BEQPeriod ref : resList) {
			seq++;
			compositeEntity = new MbdCompositeEntity();

			compositeEntity.setSeqNum(seq);
			entity = new BicIncarcationEntity();
			entity.setBicMbd(bicMbdEntity);
			entity.setId(compositeEntity);
			entity.setStartDate(formatDate(ref.getStartDate()));
			entity.setStopDate(formatDate(ref.getStopDate()));
			CommonUtils.trimObject(entity);
			entityList.add(entity);
		}
		return entityList;
	}

	private List<BicCaraPeriodsEntity> prepareBicCaraPeriodsEntity(BEQResponse res, BicMbdEntity bicMbdEntity) {
		BicCaraPeriodsEntity caraPeriodsEntity = null;
		List<BicCaraPeriodsEntity> caraEntityList = new ArrayList<>();
		MbdCompositeEntity compositeEntity = null;
		List<BEQPeriod> caraperiods = res.getCaraPeriods();
		int seq = 0;
		for (BEQPeriod ref : caraperiods) {
			seq++;
			compositeEntity = new MbdCompositeEntity();
			compositeEntity.setSeqNum(seq);
			caraPeriodsEntity = new BicCaraPeriodsEntity();
			caraPeriodsEntity.setId(compositeEntity);
			caraPeriodsEntity.setBicMbd(bicMbdEntity);
			caraPeriodsEntity.setStartDate(formatDate(ref.getStartDate()));
			caraPeriodsEntity.setStopDate(formatDate(ref.getStopDate()));
			CommonUtils.trimObject(caraPeriodsEntity);
			caraEntityList.add(caraPeriodsEntity);
		}
		return caraEntityList;
	}

	private BicMbdEntity prepareBicMbd(BicMbdEntity bicMbdEntity, BEQResponse res) {
		BEQBeneficiary beneficiary = res.getBeneficiaryInformation();
		bicMbdEntity.setMbi(beneficiary.getMedicareBeneficiaryIdentifier());
		bicMbdEntity.setFirstName(beneficiary.getFirstName());
		bicMbdEntity.setMiddleInitial(beneficiary.getMiddleInitial());
		bicMbdEntity.setLastName(beneficiary.getLastName());
		bicMbdEntity.setBirthDate(formatDate(beneficiary.getBirthDate()));
		bicMbdEntity.setDeathDate(formatDate(beneficiary.getDeathDate()));
		if (StringUtils.isNotBlank(beneficiary.getDeathDate())) {
			bicMbdEntity.setLivingStatus("Y");
		}
		bicMbdEntity.setGender(beneficiary.getGender());
		bicMbdEntity.setRace("");// race is not available in cms res needs to discuss with chandra
		List<BEQStateCounty> countyList = res.getStateCounty();
		if (!CollectionUtils.isEmpty(countyList)) {
			bicMbdEntity.setSsaCounty(countyList.get(0).getSsaCounty());
			bicMbdEntity.setSsaState(countyList.get(0).getSsaState());
			// bicMbdEntity.setZipCode(countyList.get(0).getZipCode()); data issue
		}
		List<BEQPeriod> partAPerList = res.getPartAEntitlementPeriods();
		if (!CollectionUtils.isEmpty(partAPerList)) {
			bicMbdEntity.setPartAStartDate(formatDate(partAPerList.get(0).getStartDate()));
			bicMbdEntity.setPartAStopDate(formatDate(partAPerList.get(0).getStopDate()));
		}
		List<BEQPeriod> partBPerList = res.getPartBEntitlementPeriods();
		if (!CollectionUtils.isEmpty(partBPerList)) {
			bicMbdEntity.setPartBStartDate(formatDate(partBPerList.get(0).getStartDate()));
			bicMbdEntity.setPartBStopDate(formatDate(partBPerList.get(0).getStopDate()));
		}
		List<BEQPeriod> partDPerList = res.getPartDEligibilityPeriods();
		if (!CollectionUtils.isEmpty(partDPerList)) {
			bicMbdEntity.setPartDEligStartDate(formatDate(partDPerList.get(0).getStartDate()));
		}
		List<BEQLowIncomeSubsidy> lowIncomeSubsidyList = res.getLowIncomeSubsidyPeriods();
		if (!CollectionUtils.isEmpty(lowIncomeSubsidyList)) {
			bicMbdEntity.setLowIncomeStartDate1(formatDate(lowIncomeSubsidyList.get(0).getStartDate()));
			bicMbdEntity.setLowIncomeStopDate1(formatDate(lowIncomeSubsidyList.get(0).getStopDate()));
			bicMbdEntity.setCopaymentLevel1(lowIncomeSubsidyList.get(0).getCopaymentLevel().toString());
			bicMbdEntity.setPremiumSubsidyPercent1(lowIncomeSubsidyList.get(0).getPremiumSubsidyPercent().toString());
			if (lowIncomeSubsidyList.size() > 1) {
				bicMbdEntity.setLowIncomeStartDate2(formatDate(lowIncomeSubsidyList.get(1).getStartDate()));
				bicMbdEntity.setLowIncomeStopDate2(formatDate(lowIncomeSubsidyList.get(1).getStopDate()));
				bicMbdEntity.setCopaymentLevel2(lowIncomeSubsidyList.get(1).getCopaymentLevel().toString());
				bicMbdEntity
						.setPremiumSubsidyPercent2(lowIncomeSubsidyList.get(1).getPremiumSubsidyPercent().toString());
			}
		}
		List<BEQEnrollment> currEnrolPeriods = res.getCurrentEnrollmentPeriods();
		if (!CollectionUtils.isEmpty(currEnrolPeriods)) {
			bicMbdEntity.setCurrEnrollDate(formatDate(currEnrolPeriods.get(0).getEnrollmentDate()));
			bicMbdEntity.setCurrDisEnrollDate(formatDate(currEnrolPeriods.get(0).getDisenrollmentDate()));
			bicMbdEntity.setContractNumber(currEnrolPeriods.get(0).getContractNumber());
			bicMbdEntity.setCurrEnrollPlanBenefitPackageNumber(currEnrolPeriods.get(0).getPlanBenefitPackageNumber());
			bicMbdEntity.setCurrEnrollProgramType(currEnrolPeriods.get(0).getProgramType());
			bicMbdEntity.setCurrEnrollPlanType(currEnrolPeriods.get(0).getPlanType());
			bicMbdEntity.setCurrEnrollSourceType(currEnrolPeriods.get(0).getSourceType());
			bicMbdEntity.setCurrEnrollIsEmpGrpHlthPlan(
					Boolean.TRUE.equals(currEnrolPeriods.get(0).isIsEmployerGroupHealthPlan()) ? "Y" : "N");

			if (currEnrolPeriods.size() > 1) {
				bicMbdEntity.setCurrCoEnrollDate(formatDate(currEnrolPeriods.get(1).getEnrollmentDate()));
				bicMbdEntity.setCurrCoDisEnrollDate(formatDate(currEnrolPeriods.get(1).getDisenrollmentDate()));
				bicMbdEntity.setCoContractNumber(currEnrolPeriods.get(1).getContractNumber());
				bicMbdEntity
						.setCurrCoEnrollPlanBenefitPackageNumber(currEnrolPeriods.get(1).getPlanBenefitPackageNumber());
				bicMbdEntity.setCurrCoEnrollProgramType(currEnrolPeriods.get(1).getProgramType());
				bicMbdEntity.setCurrCoEnrollPlanType(currEnrolPeriods.get(1).getPlanType());
				bicMbdEntity.setCurrCoEnrollSourceType(currEnrolPeriods.get(1).getSourceType());
				bicMbdEntity.setCurrCoEnrollIsEmpGrpHlthPlan(
						currEnrolPeriods.get(1).isIsEmployerGroupHealthPlan().toString());
			}
		}
		List<BEQEnrollment> priorEnrolPeriods = res.getCurrentEnrollmentPeriods();
		if (!CollectionUtils.isEmpty(priorEnrolPeriods)) {
			bicMbdEntity.setPriorEnrollDate1(formatDate(priorEnrolPeriods.get(0).getEnrollmentDate()));
			bicMbdEntity.setPriorDisEnrollDate1(formatDate(priorEnrolPeriods.get(0).getDisenrollmentDate()));
			bicMbdEntity.setPriorContractNumber1(priorEnrolPeriods.get(0).getContractNumber());
			bicMbdEntity
					.setPriorEnrollPlanBenefitPackageNumber1(priorEnrolPeriods.get(0).getPlanBenefitPackageNumber());
			bicMbdEntity.setPriorEnrollProgramType1(priorEnrolPeriods.get(0).getProgramType());
			bicMbdEntity.setPriorEnrollPlanType1(priorEnrolPeriods.get(0).getPlanType());
			bicMbdEntity.setPriorEnrollSourceType1(priorEnrolPeriods.get(0).getSourceType());
			bicMbdEntity.setPriorEnrollIsEmpGrpHlthPlan1(
					Boolean.TRUE.equals(priorEnrolPeriods.get(0).isIsEmployerGroupHealthPlan()) ? "Y" : "N");

			if (priorEnrolPeriods.size() > 1) {
				bicMbdEntity.setPriorEnrollDate2(formatDate(priorEnrolPeriods.get(1).getEnrollmentDate()));
				bicMbdEntity.setPriorDisEnrollDate2(formatDate(priorEnrolPeriods.get(1).getDisenrollmentDate()));
				bicMbdEntity.setPriorContractNumber2(priorEnrolPeriods.get(1).getContractNumber());
				bicMbdEntity.setPriorEnrollPlanBenefitPackageNumber2(
						priorEnrolPeriods.get(1).getPlanBenefitPackageNumber());
				bicMbdEntity.setPriorEnrollProgramType2(priorEnrolPeriods.get(1).getProgramType());
				bicMbdEntity.setPriorEnrollPlanType2(priorEnrolPeriods.get(1).getPlanType());
				bicMbdEntity.setPriorEnrollSourceType2(priorEnrolPeriods.get(1).getSourceType());
				bicMbdEntity.setPriorEnrollIsEmpGrpHlthPlan2(
						Boolean.TRUE.equals(Boolean.TRUE.equals(priorEnrolPeriods.get(1).isIsEmployerGroupHealthPlan()))
								? "Y"
								: "N");

			}
			bicMbdEntity.setHasMedicaid(Boolean.TRUE.equals(res.isHasMedicaid()) ? "Y" : "N");
			List<BEQPeriod> hospiceList = res.getHospicePeriods();

			if (!CollectionUtils.isEmpty(hospiceList)) {
				bicMbdEntity.setHospiceStartDate(formatDate(hospiceList.get(0).getStartDate()));
				bicMbdEntity.setHospiceStopDate(formatDate(hospiceList.get(0).getStopDate()));
			}
			List<BEQEsrdCov> esrdCovList = res.getEsrdCoveragePeriods();
			if (!CollectionUtils.isEmpty(esrdCovList)) {
				bicMbdEntity.setEsrdInd(esrdCovList.get(0).getEsrdIndicator());
				bicMbdEntity.setEsrdStartDate(formatDate(esrdCovList.get(0).getStartDate()));
				bicMbdEntity.setEsrdStopDate(formatDate(esrdCovList.get(0).getStopDate()));
			}
			List<BEQPeriod> medicaidList = res.getMedicaidPeriods();
			if (!CollectionUtils.isEmpty(medicaidList)) {
				bicMbdEntity.setMedicaidStartDate(formatDate(medicaidList.get(0).getStartDate()));
				bicMbdEntity.setMedicaidStopDate(formatDate(medicaidList.get(0).getStopDate()));
			}
			List<BEQPeriod> instPerList = res.getInstitutionalPeriods();
			if (!CollectionUtils.isEmpty(instPerList)) {
				bicMbdEntity.setInsStartDate(formatDate(instPerList.get(0).getStartDate()));
				bicMbdEntity.setInsStopDate(formatDate(instPerList.get(0).getStopDate()));

			}
			List<BEQInactiveMbi> inactMbiList = res.getInactiveMBI();
			if (!CollectionUtils.isEmpty(inactMbiList)) {
				bicMbdEntity.setInactiveMbi1(inactMbiList.get(0).getMedicareBeneficiaryIdentifier());
				bicMbdEntity.setInactiveEffDate1(formatDate(inactMbiList.get(0).getEffectiveDate()));
				bicMbdEntity.setInactiveTermDate1(formatDate(inactMbiList.get(0).getTerminationDate()));
				if (inactMbiList.size() > 1) {
					bicMbdEntity.setInactiveMbi2(inactMbiList.get(1).getMedicareBeneficiaryIdentifier());
					bicMbdEntity.setInactiveEffDate2(formatDate(inactMbiList.get(1).getEffectiveDate()));
					bicMbdEntity.setInactiveTermDate2(formatDate(inactMbiList.get(1).getTerminationDate()));
				}
			}
		}
		CommonUtils.trimObject(bicMbdEntity);
		return bicMbdEntity;
	}

	private String formatDate(String date) {
		if (StringUtils.isNotBlank(date)) {
			return date.replace("-", "");
		}
		return null;
	}

	private String removeDobAndMbrId(String requestorTransactionId, String memberId, String dob) {

		if (StringUtils.isBlank(requestorTransactionId)) {
			requestorTransactionId = "";
		} else {
			requestorTransactionId = requestorTransactionId.replace(memberId, "");
			requestorTransactionId = requestorTransactionId.replace(dob, "");
		}
		return requestorTransactionId;
	}
}
