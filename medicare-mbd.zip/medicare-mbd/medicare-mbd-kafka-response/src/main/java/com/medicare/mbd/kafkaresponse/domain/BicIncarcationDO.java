package com.medicare.mbd.kafkaresponse.domain;

import lombok.Data;

@Data
public class BicIncarcationDO {
	private String startDate;
	private String stopDate;
	private String mbi;
	private int suqNum;
}
