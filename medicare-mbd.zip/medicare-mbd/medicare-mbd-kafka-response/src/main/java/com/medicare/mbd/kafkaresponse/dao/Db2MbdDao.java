package com.medicare.mbd.kafkaresponse.dao;

import java.util.List;

import com.medicare.mbd.kafkaresponse.db2.entities.BicMbdEntity;
import com.medicare.mbd.kafkaresponse.db2.entities.MbiEntity;

public interface Db2MbdDao {

	void saveMbdEntityListDb2(List<BicMbdEntity> mbdEntityList);

	void updateMbiStatusList(List<MbiEntity> mbiEntityList);

}
