package com.medicare.mbd.kafkaresponse.db2.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class MbiCompositeEntity implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2597808309148287049L;
	@Column(name = "MEMBER_ID")
	private String memberId;
	@Column(name = "DATE_OF_BIRTH")
	private String dob;
	@Column(name = "JOB_INS_NAME")
	private String jobInsName;

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getJobInsName() {
		return jobInsName;
	}

	public void setJobInsName(String jobInsName) {
		this.jobInsName = jobInsName;
	}

}
