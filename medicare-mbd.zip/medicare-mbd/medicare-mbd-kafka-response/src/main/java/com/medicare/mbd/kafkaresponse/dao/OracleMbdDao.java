package com.medicare.mbd.kafkaresponse.dao;

import java.util.List;

import com.medicare.mbd.kafkaresponse.db2.entities.BicMbdEntity;

public interface OracleMbdDao {

	void cloneAndSaveMbdEntityListOracle(List<BicMbdEntity> mbdEntityList);

}
