package com.medicare.mbd.kafkaresponse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicareMbdKafkaResponseApplicationTests {

	@Test
	void contextLoads() {
	}

}
