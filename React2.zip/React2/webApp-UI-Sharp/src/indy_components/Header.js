import React, { Component } from "react";

export default class Header extends Component {
  constructor(props) {
    super(props);

    this.state = {};
  }

  render() {
    const { classes, children } = this.props;
    return (
      <React.Fragment>
        <div id="page" class="site">
          <div class="overlay"></div>
          <a
            class="skip-link screen-reader-text"
            href="http://indyhealthinc.com/#content"
          >
            Skip to content
          </a>
          <header id="masthead" class="site-header">
            <div class="site-branding container">
              <a
                href="http://indyhealthinc.com/"
                class="custom-logo-link"
                rel="home"
              >
                <img
                  src={require("../assests/images/IH-InsuranceCo-logo.png")}
                  width="125"
                  height="60"
                  class="custom-logo"
                  alt="Indy Insurance Co Logo"
                />
              </a>
              <a href="http://indyhealthinc.com/#" class="mobile-menu">
                <div class="hamburger">
                  <div class="inner"></div>
                </div>
                <span></span>
              </a>
              <nav id="site-navigation" class="main-navigation sidenav">
                {" "}
                <a href="http://indyhealthinc.com/#" class="closebtn">
                  ×
                </a>
                <div class="menu-primary-container">
                  <ul id="primary-menu" class="menu">
                    <li
                      id="menu-item-139"
                      class="current-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-home page_item page-item-2 current_page_item menu-item-139"
                    >
                      <a href="http://indyhealthinc.com/" aria-current="page">
                        HOME
                      </a>
                    </li>
                    <li
                      id="menu-item-140"
                      class="current-menu-item menu-item menu-item-type-custom menu-item-object-custom current_page_item menu-item-home menu-item-140"
                    >
                      <a
                        href="http://indyhealthinc.com/#goals"
                        aria-current="page"
                      >
                        GOALS
                      </a>
                    </li>
                    <li
                      id="menu-item-142"
                      class="current-menu-item menu-item menu-item-type-custom menu-item-object-custom current_page_item menu-item-home menu-item-142"
                    >
                      <a
                        href="http://indyhealthinc.com/#advantages"
                        aria-current="page"
                      >
                        ADVANTAGES
                      </a>
                    </li>
                    <li
                      id="menu-item-175"
                      class="current-menu-item menu-item menu-item-type-custom menu-item-object-custom menu-item-175"
                    >
                      <a href="http://indyhealthinc.com/news">NEWS</a>
                    </li>
                    <li
                      id="menu-item-141"
                      class="current-menu-item menu-item menu-item-type-custom menu-item-object-custom current_page_item menu-item-home menu-item-141"
                    >
                      <a
                        href="http://indyhealthinc.com/#opportunity"
                        aria-current="page"
                      >
                        OPPORTUNITY
                      </a>
                    </li>
                    <li
                      id="menu-item-143"
                      class="current-menu-item menu-item menu-item-type-custom menu-item-object-custom current_page_item menu-item-home menu-item-143"
                    >
                      <a
                        href="http://indyhealthinc.com/#contact"
                        aria-current="page"
                      >
                        CONTACT US
                      </a>
                    </li>
                  </ul>
                </div>
              </nav>
            </div>
          </header>
          {children}
        </div>
      </React.Fragment>
    );
  }
}
