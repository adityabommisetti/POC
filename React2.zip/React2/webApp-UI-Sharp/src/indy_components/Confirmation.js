import React, { Component } from "react";

import { connect } from "react-redux";

class Confirmation extends Component {
  constructor(props) {
    super(props);
    this.state = {
      count: this.props.count,
    };
  }

  componentDidMount() {
    window.scroll(0, 0);
  }
  downloadPDF = () => {};

  render() {
    const { count } = this.state.count;
    return (
      <React.Fragment>
        <div id="content" class="site-content">
          <div id="primary" class="content-area">
            <main id="main" class="site-main">
              <article
                id="post-2"
                class="post-2 page type-page status-publish hentry"
              >
                <header id="home" class="entry-header hide">
                  <h1 class="entry-title">Home</h1>
                </header>

                <div class="entry-content margin-top7">
                  <div class="wp-block-editor-blocks-wrapper alignfull page-section bg-gray">
                    <div class="wrapper-inner">
                      <div class="wrapper-inner-blocks">
                        <h2 id="home" class="text-center mb-2">
                          2021 Health Plan Enrollment Form
                        </h2>
                        <p class="text-center mb-0">
                          Thank you for choosing Indy Health Health Plan. Your
                          Medicare enrollment form has been submitted
                          successully and confirmation number is:{" "}
                          {this.state.count}, if there are any questions we will
                          contact you. Click below to download and print a
                          complete version of your form to keep for your
                          records.
                        </p>
                        <div class="text-center mt-4">
                          <a
                            class="button margin-right1"
                            id="downloadPdf"
                            href={
                              process.env.NODE_ENV === "development"
                                ? "https://techrefresh.medadvantage360.com/webapp-api/sharp/individual/Download"
                                : "/webapp-api/sharp/individual/Download"
                            }
                          >
                            DOWNLOAD PDF VERSION
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </article>
            </main>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    count: state.webApp.count,
  };
};
const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(Confirmation);
