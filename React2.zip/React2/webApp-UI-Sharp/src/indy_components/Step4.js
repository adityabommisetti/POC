import React, { Component } from "react";
import history from "../utils/History";

export default class Step4 extends Component {
  constructor(props) {
    super(props);

    this.state = {
      stepVal: "btn-step1",
    };
  }

  handleSteps = async (event) => {
    let value = event.target ? event.target.id : event.id;
    await this.setState({ stepVal: value });
  };

  render() {
    return (
      <React.Fragment>
        <div class="container tab-pane active">
          <h3 class="tab-headingindy">STEP 4: READ AND SIGN</h3>
          <br />
          <ul class="read-n-sign-list">
            <li>
              I must keep Hospital (Part A) or Medical (Part B) to stay in Indy
              Health Insurance Company.
            </li>
            <li>
              By joining this Medicare Advantage Plan or Medicare Prescription
              Drug Plan, I acknowledge that Indy Health Insurance Company will
              share my information with Medicare, who may use it to track my
              enrollment, to make payments, and for other purposes allowed by
              Federal law that authorize the collection of this information (see
              Privacy Act Statement below).
            </li>
            <li>
              Your response to this form is voluntary. However, failure to
              respond may affect enrollment in the plan.
            </li>
            <li>
              The information on this enrollment form is correct to the best of
              my knowledge. I understand that if I intentionally provide false
              information on this form, I will be disenrolled from the plan.
            </li>
            <li>
              I understand that people with Medicare are generally not covered
              under Medicare while out of the country, except for limited
              coverage near the U.S. border.
            </li>
            <li>
              I understand that my signature (or the signature of the person
              legally authorized to act on my behalf) on this application means
              that I have read and understand the contents of this application.
              If signed by an authorized representative (as described above),
              this signature certifies that:
              <ol>
                <li>
                  This person is authorized under State law to complete this
                  enrollment, and
                </li>
                <li>
                  Documentation of this authority is available upon request by
                  Medicare.
                </li>
              </ol>
            </li>
          </ul>

          <div class="row">
            <div class="col-xs-12 col-md-4 col-lg-4">
              <label class="control-label" for="printName">
                Print Name*
              </label>
              <input
                type="text"
                class="form-control"
                id="printName"
                name="printName"
                required=""
              />
            </div>
            <div class="col-xs-12 col-md-4 col-lg-4">
              <label class="control-label" for="digitalSignature">
                Digital Signature
              </label>
              <input
                type="text"
                class="form-control"
                id="digitalSignature"
                name="digitalSignature"
              />
            </div>
            <div class="col-xs-12 col-md-4 col-lg-4">
              <label class="control-label" for="todaysDate">
                Today's Date
              </label>
              <input
                type="text"
                class="form-control"
                name="todaysDate"
                id="todaysDate"
              />
            </div>
          </div>

          <div id="authorizedrep" class="mt-5">
            <p>
              <strong>
                If you're the authorized representative, sign above and fill out
                these fields:
              </strong>
            </p>
            <div class="row mt-3">
              <div class="col-md-4">
                <label class="control-label" for="authorizedrepname">
                  Name*
                </label>
                <input
                  type="text"
                  class="form-control"
                  name="authorizedrepname"
                  id="authorizedrepname"
                  required=""
                />
              </div>
              <div class="col-md-8">
                <label class="control-label" for="authorizedRepAddr">
                  Address*
                </label>
                <input
                  type="text"
                  class="form-control"
                  id="authorizedRepAddr"
                  name="authorizedRepAddr"
                  required=""
                />
              </div>
            </div>
            <div class="row mt-3">
              <div class="col-md-4">
                <label class="control-label" for="authorizedrepphone">
                  Phone Number*
                </label>
                <input
                  type="text"
                  name="authorizedrepphone"
                  id="authorizedrepphone"
                  class="form-control"
                  placeholder="(   )   -"
                  required=""
                  maxlength="14"
                />
              </div>
              <div class="col-md-8">
                <label class="control-label" for="authorizedreprelationship">
                  Relationship to Enrollee*
                </label>
                <input
                  type="text"
                  class="form-control"
                  name="authorizedreprelationship"
                  id="authorizedreprelationship"
                  required=""
                />
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}
