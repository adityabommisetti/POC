import React, { Component } from "react";
import history from "../Utils/History";
import PlanSelection from "./PlanSelection";
import moment from "moment";
const ie =
  navigator.userAgent.indexOf("MSIE") > -1 ||
  navigator.userAgent.indexOf("rv:") > -1;

export default class Step1 extends Component {
  constructor(props) {
    super(props);

    this.state = {
      stepVal: "btn-step1",
    };
  }

  handleSelectChange = async (event) => {
    const value = event.target.value;

    await this.setState({
      value: value,
    });
  };

  render() {
    const { data, value } = this.props;
    return (
      <React.Fragment>
        <div id="step1" class="container tab-pane active">
          <h3 class="tab-headingindy">
            STEP 1: Select the plan you want to join:
          </h3>
          <p>All fields on this page are required (unless marked optional)</p>
          <div class="wp-block-columns has-2-columns market-box">
            <div class="wp-block-column">
              <div class="wp-block-column-content">
                <h3>Indy Health SaverRx</h3>
                <p>
                  <label class="label-container">
                    Arkansas $25.30 per month
                    <input
                      type="radio"
                      name="plans"
                      value="INDY_SAVER_ARK"
                      checked={value === "INDY_SAVER_ARK"}
                      onChange={this.props.handleSelectChange}
                    />
                    <span class="checkmark"></span>
                  </label>
                </p>
                <p>
                  <label class="label-container">
                    Georgia $26.20 per month
                    <input
                      type="radio"
                      name="plans"
                      value="INDY_SAVER_GEORG"
                      checked={value === "INDY_SAVER_GEORG"}
                      onChange={this.props.handleSelectChange}
                    />
                    <span class="checkmark"></span>
                  </label>
                </p>
                <p>
                  <label class="label-container">
                    Illinois $24.50 per month
                    <input
                      type="radio"
                      name="plans"
                      value="INDY_SAVER_ILLINOIS"
                      checked={value === "INDY_SAVER_ILLINOIS"}
                      onChange={this.props.handleSelectChange}
                    />
                    <span class="checkmark"></span>
                  </label>
                </p>
                <p>
                  <label class="label-container">
                    Pennsylvania $34.00 per month
                    <input
                      type="radio"
                      name="plans"
                      value="INDY_SAVER_PENSYL"
                      checked={value === "INDY_SAVER_PENSYL"}
                      onChange={this.props.handleSelectChange}
                    />
                    <span class="checkmark"></span>
                  </label>
                </p>
                <p>
                  <label class="label-container">
                    West Virginia $34.00 per month
                    <input
                      type="radio"
                      name="plans"
                      value="INDY_SAVER_WESTVIR"
                      checked={value === "INDY_SAVER_WESTVIR"}
                      onChange={this.props.handleSelectChange}
                    />
                    <span class="checkmark"></span>
                  </label>
                </p>
              </div>
            </div>
            <div class="wp-block-column left-vertical-bar">
              <div class="wp-block-column-content">
                <h3>Indy Health EliteRx</h3>
                <p>
                  <label class="label-container">
                    Arkansas $44.40 per month
                    <input
                      type="radio"
                      name="plans"
                      value="INDY_ELITE_ARK"
                      checked={value === "INDY_ELITE_ARK"}
                      onChange={this.props.handleSelectChange}
                    />
                    <span class="checkmark"></span>
                  </label>
                </p>
                <p>
                  <label class="label-container">
                    Georgia $47.00 per month
                    <input
                      type="radio"
                      name="plans"
                      value="INDY_ELITE_GEORG"
                      checked={value === "INDY_ELITE_GEORG"}
                      onChange={this.props.handleSelectChange}
                    />
                    <span class="checkmark"></span>
                  </label>
                </p>
                <p>
                  <label class="label-container">
                    Illinois $43.30 per month
                    <input
                      type="radio"
                      name="plans"
                      value="INDY_ELITE_ILLINOIS"
                      checked={value === "INDY_ELITE_ILLINOIS"}
                      onChange={this.props.handleSelectChange}
                    />
                    <span class="checkmark"></span>
                  </label>
                </p>
                <p>
                  <label class="label-container">
                    Pennsylvania $47.10 per month
                    <input
                      type="radio"
                      name="plans"
                      value="INDY_ELITE_PENSYL"
                      checked={value === "INDY_ELITE_PENSYL"}
                      onChange={this.props.handleSelectChange}
                    />
                    <span class="checkmark"></span>
                  </label>
                </p>
                <p>
                  <label class="label-container">
                    West Virginia $47.10 per month
                    <input
                      type="radio"
                      name="plans"
                      value="INDY_ELITE_WESTVIR"
                      checked={value === "INDY_ELITE_WESTVIR"}
                      onChange={this.props.handleSelectChange}
                    />
                    <span class="checkmark"></span>
                  </label>
                </p>
              </div>
            </div>
          </div>
          <hr />
          <div class="form-panel">
            <div class="form-group row">
              <div class="col-md-4">
                <label for="firstName" class="control-label">
                  FIRST Name * :
                </label>
                <input
                  type="text"
                  id="firstName"
                  name="firstName"
                  class={data.firstName === "" ? "error-input" : "form-control"}
                  required=""
                  value={data.firstName}
                  onChange={(e) => {
                    this.props.handleChange(e);
                  }}
                />
              </div>
              <div class="col-md-4">
                <label for="lastName" class="control-label">
                  LAST Name * :
                </label>
                <input
                  type="text"
                  id="lastName"
                  class={data.lastName === "" ? "error-input" : "form-control"}
                  name="lastName"
                  required=""
                  value={data.lastName}
                  onChange={(e) => {
                    this.props.handleChange(e);
                  }}
                />
              </div>
              <div class="col-md-4">
                <label for="middleInitial" class="control-label">
                  [Optional: Middle Initial]:
                </label>
                <input
                  type="text"
                  class="form-control"
                  id="middleInitial"
                  name="middleInitial"
                  value={data.middleInitial}
                  onChange={(e) => {
                    this.props.handleChange(e);
                  }}
                />
              </div>
            </div>
            <div class="form-group row">
              <div class="col-md-3">
                <label for="birthDate" class="control-label">
                  Birth date * : (MM/DD/YYYY)
                </label>
                <input
                  name="birthDate"
                  id="birthDate"
                  placeholder="MM/DD/YYYY"
                  label="From"
                  value={data.birthDate}
                  onClick={(e) => this.props.handleDates("birthDate")}
                  maxLength="10"
                  class={
                    data.birthDate === "" ||
                    !moment(data.birthDate, "MM/DD/YYYY", true).isValid()
                      ? "error-input"
                      : "form-control"
                  }
                  onChange={(e) => {
                    this.props.handleChange(e);
                  }}
                />
                {/* <input
                  type="date"
                  class={data.birthDate === "" ? "error-input" : "form-control"}
                  name="birthDate"
                  id="birthDate"
                  pattern="\d{1,2}/\d{1,2}/\d{4}"
                  placeholder="MM/DD/YYYY"
                  required=""
                  value={data.birthDate}
                  onClick={(e) =>this.props.handleDates("#birthDate", e.target.value)}
                   onChange={(e)=>{this.props.handleChange(e)}}
                /> */}
              </div>
              <div class="col-md-3">
                {/* <fieldset
                  class="radio radio-tab "
                  style={{ marginTop: "40px !important" }}
                >
                  <legend>
                   {/* class={
                      data.sex === "" ? "error-label" : "control-labelindy"
                    }
                  > 
                    Sex * :
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      value="M"
                      name="sex"
                      id="male"
                      class={
                        data.sex === "" ? "error-input" : "custom-control-input"
                      }
                      // checked={data.sex === "M"}
                      onChange={(e)=>{this.props.handleChange(e)}}
                     // style={{ marginTop: "10px" }}
                    />
                    <label for="male" class="radio-inline custom-control-label">
                      Male
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      value="F"
                      name="sex"
                      id="female"
                      class={
                        data.sex === "" ? "error-input" : "custom-control-input"
                      }
                       onChange={(e)=>{this.props.handleChange(e)}}
                     // style={{ marginTop: "10px" }}
                      // checked={data.sex === "F"}
                    />
                    <label
                      for="female"
                      class="radio-inline custom-control-label"
                    >
                      Female
                    </label>
                  </div>
                    </fieldset> */}
                <fieldset
                  class={
                    ie
                      ? "radio radio-tab radioBtnSex iemargin"
                      : "radio radio-tab radioBtnSex"
                  }
                >
                  <legend
                      class= "control-label"
                    >
                    {/*<span style={ data.sex === "" ? { color:"red"} : {}}>Sex * :</span> */}
                    <span>Sex * :</span>
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline mt-1">
                    <input
                      type="radio"
                      name="sex"
                      id="male"
                      class="custom-control-input"
                      value="M"
                      style={data.sex === "" ? { borderColor: "red" } : {}}
                      checked={data.sex === "M"}
                      onChange={(e) => {
                        this.props.handleChange(e);
                      }}
                    />
                    <label for="male" class="radio-inline custom-control-label">
                      Male
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline mt-1">
                    <input
                      type="radio"
                      name="sex"
                      id="female"
                      class="custom-control-input"
                      value="F"
                      style={data.sex === "" ? { borderColor: "red" } : {}}
                      checked={data.sex === "F"}
                      onChange={(e) => {
                        this.props.handleChange(e);
                      }}
                    />
                    <label
                      for="female"
                      class="radio-inline custom-control-label"
                    >
                      Female
                    </label>
                  </div>
                </fieldset>
              </div>
              <div class="col-md-3">
                <label for="primaryPhone" class="control-label">
                  Phone Number * :
                </label>
                <input
                  type="text"
                  id="primaryPhone"
                  name="primaryPhone"
                  class={
                    data.primaryPhone === "" || data.primaryPhone.length != 14
                      ? "error-input"
                      : "form-control"
                  }
                  placeholder="(   )"
                  required=""
                  maxlength="14"
                  value={data.primaryPhone}
                  onChange={(e) => {
                    this.props.handleChange(e);
                  }}
                />
              </div>
            </div>
            <div class="form-group row">
              <div class="col-md-12">
                <label for="permanentAddr" class="control-label">
                  Permanent Residence street address *{" "}
                  <strong>(Don't enter a PO Box)</strong>:
                </label>
                <input
                  type="text"
                  name="permanentAddrStreet"
                  id="permanentAddr"
                  class={
                    data.permanentAddrStreet === ""
                      ? "error-input"
                      : "form-control"
                  }
                  required=""
                  value={data.permanentAddrStreet}
                  onChange={(e) => {
                    this.props.handleChange(e);
                  }}
                />
              </div>
            </div>
            <div class="form-group row">
              <div class="col-md-3">
                <label for="permanentCity" class="control-label">
                  City * :
                </label>
                <input
                  type="text"
                  class={
                    data.permanentCity === "" ? "error-input" : "form-control"
                  }
                  name="permanentCity"
                  id="permanentCity"
                  required=""
                  value={data.permanentCity}
                  onChange={(e) => {
                    this.props.handleChange(e);
                  }}
                />
              </div>
              <div class="col-md-3">
                <label for="permanentCounty" class="control-label">
                  [Optional: County]:
                </label>
                <input
                  type="text"
                  class="form-control"
                  name="permanentCounty"
                  id="permanentCounty"
                  value={data.permanentCounty}
                  onChange={(e) => {
                    this.props.handleChange(e);
                  }}
                />
              </div>
              <div class="col-md-3">
                <label for="permanentState" class="control-label">
                  State * :
                </label>
                <select
                  type="text"
                  class={
                    data.permanentState === "" ? "error-input" : "form-control"
                  }
                  name="permanentState"
                  id="permanentState"
                  value={data.permanentState}
                  onChange={(e) => {
                    this.props.handleChange(e);
                  }}

                >
                  <option>Select</option>
                  <option>AA</option>
                  <option>AE</option>
                  <option>AF</option>
                  <option>AI</option>
                  <option>AK</option>
                  <option>AL</option>
                  <option>AP</option>
                  <option>AR</option>
                  <option>AS</option>
                  <option>AW</option>
                  <option>AZ</option>
                  <option>CA</option>
                  <option>CN</option>
                  <option>CO</option>
                  <option>CT</option>
                  <option>CW</option>
                  <option>DC</option>
                  <option>DE</option>
                  <option>EU</option>
                  <option>FL</option>
                  <option>GA</option>
                  <option>GU</option>
                  <option>HI</option>
                  <option>IA</option>
                  <option>ID</option>
                  <option>IL</option>
                  <option>IN</option>
                  <option>KS</option>
                  <option>KY</option>
                  <option>LA</option>
                  <option>MA</option>
                  <option>MD</option>
                  <option>ME</option>
                  <option>MI</option>
                  <option>MN</option>
                  <option>MO</option>
                  <option>MP</option>
                  <option>MS</option>
                  <option>MT</option>
                  <option>MX</option>
                  <option>NC</option>
                  <option>ND</option>
                  <option>NE</option>
                  <option>NH</option>
                  <option>NJ</option>
                  <option>NM</option>
                  <option>NV</option>
                  <option>NY</option>
                  <option>OC</option>
                  <option>OH</option>
                  <option>OK</option>
                  <option>OR</option>
                  <option>PA</option>
                  <option>PH</option>
                  <option>PR</option>
                  <option>RI</option>
                  <option>SA</option>
                  <option>SC</option>
                  <option>SD</option>
                  <option>SP</option>
                  <option>TN</option>
                  <option>TX</option>
                  <option>US</option>
                  <option>UT</option>
                  <option>VA</option>
                  <option>VI</option>
                  <option>VT</option>
                  <option>WA</option>
                  <option>WI</option>
                  <option>WV</option>
                  <option>WY</option>
                  <option>ZZ</option>
                </select>
              </div>

              <div class="col-md-3">
                <label for="permanentZip" class="control-label">
                  ZIP Code * :
                </label>
                <input
                  type="text"
                  class={
                    data.permanentZip === "" ||
                    (data.permanentZip && data.permanentZip.length < 5)
                      ? "error-input"
                      : "form-control"
                  }
                  name="permanentZip"
                  id="permanentZip"
                  minlength="5"
                  maxlength="5"
                  required=""
                  value={data.permanentZip}
                  onChange={this.props.handleNumberChange}
                />
              </div>
            </div>
            <div class="form-group row">
              <div class="col-md-12">
                Mailing address, if different from your permanent address (PO
                Box allowed): &nbsp;&nbsp;
                <div class="custom-control custom-checkbox custom-control-inline iedisplay">
                  <input
                    type="checkbox"
                    name="mailingAddressRequired"
                    id="mailingAddressRequired"
                    class="custom-control-input"
                    value={data.mailingAddressRequired}
                    checked={
                      data.mailingAddressRequired === "YES" ? true : false
                    }
                    onChange={this.props.handleCheckbox}
                  />
                  <label
                    for="mailingAddressRequired"
                    class="custom-control-label"
                  >
                    <strong>YES</strong>
                  </label>
                </div>
              </div>
            </div>
            {data.mailingAddressRequired === "YES" ? (
              <React.Fragment>
                <div class="form-group row">
                  <div class="col-md-12">
                    <label for="mailingAddr" class="control-label">
                      Street address * :
                    </label>
                    <input
                      type="text"
                      class={
                        data.mailingAddr === "" ? "error-input" : "form-control"
                      }
                      name="mailingAddr"
                      id="mailingAddr"
                      required=""
                      value={data.mailingAddr}
                      onChange={(e) => {
                        this.props.handleChange(e);
                      }}
                    />
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-md-3">
                    <label for="mailingCity" class="control-label">
                      City * :
                    </label>
                    <input
                      type="text"
                      class={
                        data.mailingCity === "" ? "error-input" : "form-control"
                      }
                      name="mailingCity"
                      id="mailingCity"
                      required=""
                      value={data.mailingCity}
                      onChange={(e) => {
                        this.props.handleChange(e);
                      }}
                    />
                  </div>
                  <div class="col-md-3">
                    <label for="mailingState" class="control-label">
                      State * :
                    </label>
                    <select
                      type="text"
                      class={
                        data.mailingState === ""
                          ? "error-input"
                          : "form-control"
                      }
                      name="mailingState"
                      id="mailingState"
                      value={data.mailingState}
                      onChange={(e) => {
                        this.props.handleChange(e);
                      }}
                    > 
                    <option>Select</option>
                    <option>AA</option>
                    <option>AE</option>
                    <option>AF</option>
                    <option>AI</option>
                    <option>AK</option>
                    <option>AL</option>
                    <option>AP</option>
                    <option>AR</option>
                    <option>AS</option>
                    <option>AW</option>
                    <option>AZ</option>
                    <option>CA</option>
                    <option>CN</option>
                    <option>CO</option>
                    <option>CT</option>
                    <option>CW</option>
                    <option>DC</option>
                    <option>DE</option>
                    <option>EU</option>
                    <option>FL</option>
                    <option>GA</option>
                    <option>GU</option>
                    <option>HI</option>
                    <option>IA</option>
                    <option>ID</option>
                    <option>IL</option>
                    <option>IN</option>
                    <option>KS</option>
                    <option>KY</option>
                    <option>LA</option>
                    <option>MA</option>
                    <option>MD</option>
                    <option>ME</option>
                    <option>MI</option>
                    <option>MN</option>
                    <option>MO</option>
                    <option>MP</option>
                    <option>MS</option>
                    <option>MT</option>
                    <option>MX</option>
                    <option>NC</option>
                    <option>ND</option>
                    <option>NE</option>
                    <option>NH</option>
                    <option>NJ</option>
                    <option>NM</option>
                    <option>NV</option>
                    <option>NY</option>
                    <option>OC</option>
                    <option>OH</option>
                    <option>OK</option>
                    <option>OR</option>
                    <option>PA</option>
                    <option>PH</option>
                    <option>PR</option>
                    <option>RI</option>
                    <option>SA</option>
                    <option>SC</option>
                    <option>SD</option>
                    <option>SP</option>
                    <option>TN</option>
                    <option>TX</option>
                    <option>US</option>
                    <option>UT</option>
                    <option>VA</option>
                    <option>VI</option>
                    <option>VT</option>
                    <option>WA</option>
                    <option>WI</option>
                    <option>WV</option>
                    <option>WY</option>
                    <option>ZZ</option>
                  </select>
                  </div>
                  <div class="col-md-3">
                    <label for="mailingzip" class="control-label">
                      Zip Code * :
                    </label>
                    <input
                      type="text"
                      class={
                        data.mailingzip === "" ? "error-input" : "form-control"
                      }
                      name="mailingzip"
                      id="mailingzip"
                      minlength="5"
                      maxlength="5"
                      required=""
                      value={data.mailingzip}
                      onChange={(e) => {
                        this.props.handleChange(e);
                      }}
                    />
                  </div>
                </div>
              </React.Fragment>
            ) : null}

            <h4 class="sub-heading mt-4">
              <strong>Your Medicare information:</strong>
            </h4>
            <div class="form-group row">
              <div class="col-md-6">
                <p>
                  <label for="medicareClaim" class="control-label">
                    Medicare Number*
                  </label>
                  <input
                    type="text"
                    pattern="/[a-zA-Z0-9]{10,11}/"
                    placeholder="XXXXXXXXXXX"
                    name="medicareClaim"
                    id="medicareClaim"
                    minlength="10"
                    maxlength="12"
                    class={
                      data.medicareClaim === "" ||
                      (data.medicareClaim && data.medicareClaim.length < 10)
                        ? "error-input"
                        : "form-control"
                    }
                    value={data.medicareClaim}
                    onChange={(e) => {
                      this.props.handleChange(e);
                    }}
                    required=""
                  />
                </p>
              </div>
            </div>

            <h4 class="sub-heading mt-2">
              <strong>Answer these important questions:</strong>
            </h4>
            <div class="form-group">
              <fieldset
                class="radio radio-tab mt-3"
                id="c_qns1"
                name="c_qns1"
                onChange={(e) => {
                  this.props.handleChange(e);
                }}
                value={data.c_qns1}
              >
                <legend>
                  Will you have other prescription drug coverage (like VA,
                  TRICARE) in addition to Indy Health Insurance Company?{" "}
                </legend>

                <div class="custom-control custom-radio custom-control-inline">
                  <input
                    type="radio"
                    name="vaBenefits"
                    id="c_q2_yes"
                    class="custom-control-input"
                    value="Y"
                    checked={data.vaBenefits === "Y"}
                    onChange={(e) => {}}
                  />
                  <label
                    for="c_q2_yes"
                    class="radio-inline custom-control-label"
                  >
                    Yes
                  </label>
                </div>
                <div class="custom-control custom-radio custom-control-inline">
                  <input
                    type="radio"
                    name="vaBenefits"
                    id="c_q2_no"
                    class="custom-control-input"
                    value="N"
                    checked={data.vaBenefits === "N"}
                    onChange={(e) => {
                      this.props.handleChange(e);
                    }}
                  />
                  <label
                    for="c_q2_no"
                    class="radio-inline custom-control-label"
                  >
                    No
                  </label>
                </div>
              </fieldset>
              {data.vaBenefits === "Y" ? (
                <div id="c_q1_fields">
                  <div class="row mt-3 ml-1">
                    <div class="col-md-4">
                      <label for="nameOfCov" class="control-label">
                        Name of other coverage * :
                      </label>
                      <input
                        type="text"
                        class={
                          data.nameOfCov === "" ? "error-input" : "form-control"
                        }
                        id="nameOfCov"
                        name="nameOfCov"
                        value={data.nameOfCov}
                        onChange={(e) => {
                          this.props.handleChange(e);
                        }}
                      />
                    </div>
                    <div class="col-md-4">
                      <label for="idOfCov" class="control-label">
                        Member number for this coverage * :
                      </label>
                      <input
                        type="text"
                        class={
                          data.idOfCov === "" ? "error-input" : "form-control"
                        }
                        id="idOfCov"
                        name="idOfCov"
                        value={data.idOfCov}
                        onChange={(e) => {
                          this.props.handleChange(e);
                        }}
                      />
                    </div>
                    <div class="col-md-4">
                      <label for="groupOfCov" class="control-label">
                        Group number for this coverage * :
                      </label>
                      <input
                        type="text"
                        class={
                          data.groupOfCov === ""
                            ? "error-input"
                            : "form-control"
                        }
                        id="groupOfCov"
                        name="groupOfCov"
                        value={data.groupOfCov}
                        onChange={(e) => {
                          this.props.handleChange(e);
                        }}
                      />
                    </div>
                  </div>
                </div>
              ) : null}
            </div>
            <hr />
            <ul class="read-n-sign-list">
              <li>
                I must keep Hospital (Part A) or Medical (Part B) to stay in
                Indy Health Insurance Company.
              </li>
              <li>
                By joining this Medicare Advantage Plan or Medicare Prescription
                Drug Plan, I acknowledge that Indy Health Insurance Company will
                share my information with Medicare, who may use it to track my
                enrollment, to make payments, and for other purposes allowed by
                Federal law that authorize the collection of this information
                (see Privacy Act Statement below).
              </li>
              <li>
                Your response to this form is voluntary. However, failure to
                respond may affect enrollment in the plan.
              </li>
              <li>
                The information on this enrollment form is correct to the best
                of my knowledge. I understand that if I intentionally provide
                false information on this form, I will be disenrolled from the
                plan.
              </li>
              <li>
                I understand that people with Medicare are generally not covered
                under Medicare while out of the country, except for limited
                coverage near the U.S. border.
              </li>
              <li>
                I understand that my signature (or the signature of the person
                legally authorized to act on my behalf) on this application
                means that I have read and understand the contents of this
                application. If signed by an authorized representative (as
                described above), this signature certifies that:
                <ol>
                  <li>
                    This person is authorized under State law to complete this
                    enrollment, and
                  </li>
                  <li>
                    Documentation of this authority is available upon request by
                    Medicare.
                  </li>
                </ol>
              </li>
            </ul>

            <div class="row">
              <div class="col-4">
                <label class="control-label" for="printName">
                  Print Name * :
                </label>
                <input
                  type="text"
                  class={
                    this.props.data.nameSignature === ""
                      ? "error-input"
                      : "form-control"
                  }
                  id="printName"
                  name="nameSignature"
                  value={data.nameSignature}
                  onChange={(e) => {
                    this.props.handleChange(e);
                  }}
                />
              </div>
              <div class="col-4">
                <label class="control-label" for="digitalSignature">
                  Digital Signature * :
                </label>
                <input
                  type="text"
                  class="form-control"
                  id="digitalSignature"
                  name="digitalSignature"
                  disabled="disabled"
                  //  onChange={(e)=>{this.props.handleChange(e)}}
                  value={data.nameSignature}
                />
              </div>
              <div class="col-4">
                <label class="control-label" for="todaysDate">
                  Today's Date * :
                </label>
                <input
                  type="text"
                  class={
                    this.props.data.todaysDate === ""
                      ? "error-input"
                      : "form-control"
                  }
                  name="todaysDate"
                  id="todaysDate"
                  placeholder="mm/dd/yyyy"
                  value={data.todaysDate}
                  onChange={(e) => {
                    this.props.handleChange(e);
                  }}
                />
              </div>
            </div>

            <div id="authorizedrep" class="mt-5 mb-4">
              <p>
                <strong>
                  If you're the authorized representative, sign above and fill
                  out these fields:
                </strong>
              </p>
              <div class="row mt-3">
                <div class="col-md-4">
                  <label class="control-label" for="authorizedrepname">
                    Name :
                  </label>
                  <input
                    type="text"
                    class="form-control"
                    name="authorizedrepname"
                    id="authorizedrepname"
                    value={data.authorizedrepname}
                    onChange={(e) => {
                      this.props.handleChange(e);
                    }}
                  />
                </div>
                <div class="col-md-8">
                  <label class="control-label" for="authorizedrepaddress">
                    Address :
                  </label>
                  <input
                    type="text"
                    class="form-control"
                    id="authorizedrepaddress"
                    name="authorizedrepaddress"
                    value={data.authorizedrepaddress}
                    onChange={(e) => {
                      this.props.handleChange(e);
                    }}
                  />
                </div>
              </div>
              <div class="row mt-3">
                <div class="col-md-4">
                  <label class="control-label" for="authorizedrepphone">
                    Phone number :
                  </label>
                  <input
                    type="text"
                    name="authorizedrepphone"
                    id="authorizedrepphone"
                    class="form-control"
                    placeholder="(   )"
                    maxlength="14"
                    value={data.authorizedrepphone}
                    onChange={(e) => {
                      this.props.handleChange(e);
                    }}
                  />
                </div>
                <div class="col-md-8">
                {/*  <label class="control-label" for="authorizedreprelationship">
                    Relationship to enrollee :
                  </label>
                  <input
                    type="text"
                    class="form-control"
                    name="authorizedreprelationship"
                    id="authorizedreprelationship"
                    value={data.authorizedreprelationship}
                    onChange={(e) => {
                      this.props.handleChange(e);
                    }}
                  />*/}
                  {console.log(this.props.authorizedrelations)}
                  <label class="control-label" for="authorizedreprelationship">
                    Relationship to enrollee :
                  </label>
                  <select
                  style={{
                    borderRadius: "0",
                    paddingTop: "4px",
                    paddingBottom: "4px",
                    height: "37px",
                  }}
                  class="form-control "
                  id="authorizedreprelationship"
                  name="authorizedreprelationship"
                  value={data.authorizedreprelationship}
                  onChange={(e) => {
                    this.props.handleChange(e);
                  }}
                >               {
                    this.props.authorizedrelations &&
                    this.props.authorizedrelations.map((item, i) => {
                      return (
                        <option
                          class="select-option"
                          value={item.value}
                          key={i}
                        >
                          {item.label}
                        </option>
                      );
                    })}
                    </select> 
                </div>
              </div>
            </div>

            <button
              class="button btn-save-n-continue"
              id="save-n-continue1"
              onClick={this.props.redirect}
            >
              Save and Continue
            </button>
          </div>
        </div>
      </React.Fragment>
    );
  }
}
