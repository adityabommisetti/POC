import React, { Component } from "react";
import history from "../Utils/History";

export default class PlanSelection extends Component {
  constructor(props) {
    super(props);

    this.state = {
      planValue: "",
    };
  }
  handleRadioChange = async (e) => {
    await this.setState({ planValue: e.target.value });

    history.push("/webapp/IndyHealth/enrollOnline");
  };

  render() {
    return (
      <React.Fragment>
        <div id="content" class="site-content">
          <div id="primary" class="content-area">
            <main id="main" class="site-main">
              <article
                id="post-2"
                class="post-2 page type-page status-publish hentry"
              >
                <header id="home" class="entry-header hide">
                  <h1 class="entry-title">Home</h1>
                </header>

                <div class="entry-content margin-top7">
                  <div
                    class="wp-block-editor-blocks-wrapper alignfull page-section bg-gray"
                    // style={{ BackgroundColor: "#f6f6f6" }}
                  >
                    <div class="wrapper-inner">
                      <div class="wrapper-inner-blocks">
                        <h2 id="home" class="text-center section-title">
                          Indy Health Insurance Company
                        </h2>
                        <p class="text-center">
                          Medicare Prescription Drug Plan Individual Enrollment
                          Form. Please contact Indy Health Insurance Company if
                          you need information in another language or format
                          (Braille).
                        </p>
                      </div>
                    </div>
                  </div>
                  <div class="wp-block-editor-blocks-wrapper alignfull page-section">
                    <div class="wrapper-inner">
                      <div class="wrapper-inner-blocks">
                        <h3 class="text-center">
                          To Enroll in Indy Health Insurance Company, Please
                          Provide the Following Information:
                        </h3>
                        <h4 class="text-center">
                          <strong>
                            Please check which plan you want to enroll in
                          </strong>
                        </h4>
                        <div class="wp-block-columns has-2-columns market-box">
                          <div class="wp-block-column">
                            <div class="wp-block-column-content">
                              <h3>Indy Health SaverRx</h3>
                              <p>
                                <label class="label-container">
                                  Arkansas $ per month{" "}
                                  <input
                                    type="radio"
                                    name="plans"
                                    value={this.state.planValue}
                                    onChange={this.handleRadioChange}
                                  />
                                  <span class="checkmark"></span>
                                </label>
                              </p>
                              <p>
                                <label class="label-container">
                                  Georgia $ per month{" "}
                                  <input
                                    type="radio"
                                    name="plans"
                                    value={this.state.planValue}
                                    onChange={this.handleRadioChange}
                                  />
                                  <span class="checkmark"></span>
                                </label>
                              </p>
                              <p>
                                <label class="label-container">
                                  Illinois $ per month{" "}
                                  <input
                                    type="radio"
                                    name="plans"
                                    value={this.state.planValue}
                                    onChange={this.handleRadioChange}
                                  />
                                  <span class="checkmark"></span>
                                </label>
                              </p>
                              <p>
                                <label class="label-container">
                                  Pennsylvania $ per month{" "}
                                  <input type="radio" name="plans" />
                                  <span class="checkmark"></span>
                                </label>
                              </p>
                              <p>
                                <label class="label-container">
                                  West Virginia $ per month{" "}
                                  <input type="radio" name="plans" />
                                  <span class="checkmark"></span>
                                </label>
                              </p>
                            </div>
                          </div>
                          <div class="wp-block-column left-vertical-bar">
                            <div class="wp-block-column-content">
                              <h3>Indy Health EliteRx</h3>
                              <p>
                                <label class="label-container">
                                  Arkansas $ per month{" "}
                                  <input type="radio" name="plans" />
                                  <span class="checkmark"></span>
                                </label>
                              </p>
                              <p>
                                <label class="label-container">
                                  Georgia $ per month{" "}
                                  <input type="radio" name="plans" />
                                  <span class="checkmark"></span>
                                </label>
                              </p>
                              <p>
                                <label class="label-container">
                                  Illinois $ per month{" "}
                                  <input type="radio" name="plans" />
                                  <span class="checkmark"></span>
                                </label>
                              </p>
                              <p>
                                <label class="label-container">
                                  Pennsylvania $ per month{" "}
                                  <input type="radio" name="plans" />
                                  <span class="checkmark"></span>
                                </label>
                              </p>
                              <p>
                                <label class="label-container">
                                  West Virginia $ per month{" "}
                                  <input type="radio" name="plans" />
                                  <span class="checkmark"></span>
                                </label>
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="text-center">
                        <a class="button" href="enrollment-form.html">
                          Continue
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </article>
            </main>
          </div>
        </div>
      </React.Fragment>
    );
  }
}
