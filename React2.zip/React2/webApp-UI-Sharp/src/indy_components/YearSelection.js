import React, { Component } from "react";
import history from "../Utils/History";
import { connect } from "react-redux";
import { yearSelection } from "../Redux/Actions/webAppActions";

class YearSelection extends Component {
  constructor(props) {
    super(props);

    this.state = {
      year: "",
    };
  }
  handleChangeSelect = async (e) => {
    await this.setState({ year: e.target.value });
  };

  continue = async (event) => {
    event.preventDefault();
    if (this.state.year === "") {
      alert(" Please select the required year !!");
      return;
    } else {
      let payload = {
        planYear: this.state.year,
      };
      await this.props.yearSelection(payload);
      history.push("/webapp/IndyHealth/exhibit");
    }
  };

  render() {
    return (
      <React.Fragment>
        <div id="content" class="site-content">
          <div id="primary" class="content-area">
            <main id="main" class="site-main">
              <article
                id="post-2"
                class="post-2 page type-page status-publish hentry"
              >
                <header id="home" class="entry-header hide">
                  <h1 class="entry-title">Home</h1>
                </header>

                <div class="entry-content margin-top7">
                  <div class="wp-block-editor-blocks-wrapper alignfull page-section bg-gray">
                    <div class="wrapper-inner">
                      <div class="wrapper-inner-blocks">
                        <h2 id="home" class="text-center mb-2">
                          Health Plan Medicare Plan
                        </h2>
                        <p class="text-center mb-0">
                          Congratulations on successfully creating an account.
                          <br />
                          Let's get started! Please contact Health Plan if you
                          need information in another language or format.
                          <br />
                          <a href="">CONTACT US &gt;</a>
                        </p>
                      </div>
                    </div>
                  </div>
                  <div class="wp-block-editor-blocks-wrapper alignfull page-section2">
                    <div class="wrapper-inner">
                      <div class="tab-contentindy">
                        <div class="container form-panel">
                          <div class="form-group row">
                            <div class="col-md-12 text-center">
                              <label
                                class="control-label"
                                for="year-id"
                                style={{
                                  fontWeight: "800px !important",
                                  color: "#333",
                                  fontSize: "1rem",
                                }}
                              >
                                Select the plan year you would like to enroll
                                in:{" "}
                              </label>
                              <br />
                              <div class="">
                                <select
                                  class="form-control form-control-width20 "
                                  name="year"
                                  id="year-id"
                                  value={this.state.year}
                                  onChange={this.handleChangeSelect}
                                >
                                  <option class="select-option-tab" value="">
                                    Choose Year
                                  </option>
                                  <option class="select-option-tab">
                                    2021
                                  </option>
                                </select>
                              </div>
                            </div>
                          </div>
                          <div class="text-center">
                            <button
                              class="button margin-right1"
                              onClick={this.continue}
                            >
                              Continue
                            </button>
                            <div class="margin-top1">
                              <p>
                                Not sure?{" "}
                                <a href="select-the-plan.html">
                                  Look at Our Plans.
                                </a>
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </article>
            </main>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {};
};
const mapDispatchToProps = {
  yearSelection,
};

export default connect(mapStateToProps, mapDispatchToProps)(YearSelection);
