import React, { Component } from "react";

export default class Footer extends Component {
  constructor(props) {
    super(props);

    this.state = {};
  }

  render() {
    return (
      <React.Fragment>
        <footer id="colophon" class="site-footer">
          <div class="row site-info container">
            <div class="col-3"></div>
            <div class="col-6">
              <p class="copyright">
                &copy; 2020{" "}
                <a href="http://indyhealthinc.com/#">
                  INDY HEALTH INCORPORATED
                </a>
                . ALL RIGHTS RESERVED
              </p>
            </div>
            <div class="col-3 text-right">
              <p class="righttext">S3535_C3_1_web_C</p>
            </div>
          </div>
        </footer>
      </React.Fragment>
    );
  }
}
