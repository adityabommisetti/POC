import React, { Component } from "react";
import history from "../Utils/History";
import { login } from "../Redux/Actions/webAppActions";
import { connect } from "react-redux";
import RemoveRedEyeIcon from "@material-ui/icons/RemoveRedEye";

class LoginForm extends Component {
  constructor(props) {
    super(props);

    this.state = {
      email: "",
      password: "",
      showPassword: false,
      passwordEye: false,
      emailError: false,
      passwordError: false,
    };
  }

  componentDidMount() {
    window.scroll(0, 0);
  }

  handleChange = (event) => {
    const name = event.target.name;
    const value = event.target.value;
    const emailError = name === "email" && value === "";
    const passwordError = name === "password" && value === "";

    this.setState({
      [name]: value,
      emailError: emailError,
      passwordError: passwordError,
    });
  };

  handleFocus = (name) => (event) => {
    event.preventDefault();

    this.setState({
      passwordEye: true,
    });
  };

  handleOnBlur = (name) => (event) => {
    event.preventDefault();
    const { email, password, showPassword } = this.state;
    const emailError = name === "email" && email === "";
    const passwordError = name === "password" && password === "";

    this.setState({
      emailError: emailError,
      passwordError: passwordError,
      passwordEye: showPassword,
    });
  };

  showPassword = (name, toggle) => (event) => {
    document.getElementById(name).focus();

    this.setState({
      passwordEye: true,
      showPassword: toggle,
    });
  };

  login = async (e) => {
    e.preventDefault();
    const { email, password } = this.state;

    const emailError = email === "";

    const passwordError = password === "";

    if (emailError) {
      alert("Email cannot be empty");
      return;
    }
    if (passwordError) {
      alert("Password cannot be empty");
      return;
    }

    let body = {
      emailAddress: email,
      password: password,
    };
    body = { ...body, customerId: "HCF0245" };
    const login = await this.props.login(body);
    if (login.message === "SUCCESS")
      history.push("/webapp/IndyHealth/yearSelection");
    else alert(login.message);
  };

  render() {
    const {
      email,
      password,
      showPassword,
      passwordEye,
      emailError,
      passwordError,
    } = this.state;
    return (
      <React.Fragment>
        <div id="content" class="site-content">
          <div id="primary" class="content-area">
            <main id="main" class="site-main">
              <article
                id="post-2"
                class="post-2 page type-page status-publish hentry"
              >
                <header id="home" class="entry-header hide">
                  <h1 class="entry-title">Home</h1>
                </header>

                <div class="entry-content margin-top7">
                  <div class="wp-block-editor-blocks-wrapper alignfull page-section bg-gray">
                    <div class="wrapper-inner">
                      <div class="wrapper-inner-blocks">
                        <h2 id="home" class="text-center">
                          Create a Health Plan Medicare Account
                        </h2>
                        <p class="text-center">
                          Health Plan provides you with access to expert care
                          and award-winning facilities and programs that help
                          you make the most of your health care. We're here to
                          make finding and enrolling in the right plan simple.
                          Whether you have never purchased Medicare health
                          coverage before or are considering switching from your
                          current plan, we are committed to making your health
                          care experience affordable, simple, accessible and
                          personal. At Health plan, we offer Medicare plans to
                          feel good about.
                        </p>
                      </div>
                    </div>
                  </div>
                  <div class="wp-block-editor-blocks-wrapper alignfull page-section2">
                    <div class="wrapper-inner">
                      <div class="tab-contentindy">
                        <div class="container form-panel">
                          <div class="form-group row">
                            <div class="col-md-12">
                              <label
                                for="email-address"
                                class={
                                  emailError ? "error-label" : "control-label"
                                }
                                style={{ padding: "0px !important" }}
                              >
                                Email Address*
                              </label>
                              <input
                                type="email"
                                name="email"
                                placeholder="john.smith@mail.com"
                                class={
                                  emailError ? "error-input" : "form-control"
                                }
                                value={email}
                                onChange={this.handleChange}
                                onBlur={this.handleOnBlur("email")}
                              />
                              <br />
                              <label
                                for="password"
                                class={
                                  passwordError
                                    ? "error-label"
                                    : "control-label"
                                }
                              >
                                Password*
                              </label>
                              <input
                                type={showPassword ? "text" : "password"}
                                id="password"
                                name="password"
                                class={
                                  passwordError ? "error-input" : "form-control"
                                }
                                value={password}
                                onFocus={this.handleFocus("password")}
                                onBlur={this.handleOnBlur("password")}
                                onChange={this.handleChange}
                              />
                              {passwordEye ? (
                                <div
                                  class="eyeIcon-password"
                                  onMouseUp={this.showPassword(
                                    "password",
                                    false
                                  )}
                                  onMouseDown={this.showPassword(
                                    "password",
                                    true
                                  )}
                                  onMouseOut={this.showPassword(
                                    "password",
                                    false
                                  )}
                                >
                                  <RemoveRedEyeIcon />
                                </div>
                              ) : null}
                              <br />
                            </div>
                          </div>
                          <div class="button-container-login-page">
                            <button
                              class="button2 mr-3"
                              id="continue-as-a-guest"
                              onClick={this.login}
                            >
                              Submit
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </article>
            </main>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {};
};
const mapDispatchToProps = {
  login,
};
export default connect(mapStateToProps, mapDispatchToProps)(LoginForm);
