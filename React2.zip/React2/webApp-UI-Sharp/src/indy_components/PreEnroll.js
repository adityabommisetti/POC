import React, { Component } from "react";
import history from "../Utils/History";
import Step1 from "./Step1";
import Step2 from "./Step2";
import Step3 from "./Step3";
import { INITIAL_STATE } from "./InitialState";
import { connect } from "react-redux";
import SimpleReactValidator from "simple-react-validator";
import {
  saveLogout,
  submitForm,
  getClinicalName,
} from "../Redux/Actions/webAppActions";
import { withStyles } from "@material-ui/core/styles";
import { planSelectionContinue } from "../Redux/Actions/webAppActions";
import LinearProgress from "@material-ui/core/LinearProgress";
import * as DateUtil from "../Utils/DatePicker";
import $ from "jquery";
import moment from "moment";
const styles = (props) => ({
  progressComplete: {
    backgroundColor: "#00695C",
  },
  root: {
    height: "20px",
  },
  progressIncomplete: {
    backgroundColor: "#b8880c",
  },
});

class PreEnroll extends Component {
  constructor(props) {
    super(props);

    this.state = {
      formData: [
        { lastName: 0 },
        { firstName: 0 },
        { birthDate: 0 },
        { primaryPhone: 0 },
        { permanentAddrStreet: 0 },
        { permanentCity: 0 },
        { permanentState: 0 },
        { medicareClaim: 0 },
        { nameSignature: 0 },
        // { emailAddr: 0 },
        { permanentZip: 0 },
        { sex: 0 },
      ],

      formRadio: [
        {
          mailingAddressRequired: 4,
          fields: [
            { mailingAddr: 0 },
            { mailingCity: 0 },
            { mailingState: 0 },
            { mailingzip: 0 },
          ],
        },
        {
          vaBenefits: 3,
          fields: [{ nameOfCov: 0 }, { idOfCov: 0 }, { groupOfCov: 0 }],
        },
        //         c2
        // c3
        // c4
        // c22
        // c7
        // c10
        // c11    attestation11

        { c2: 1, fields: [{ attestation2: 0 }] },
        { c3: 1, fields: [{ attestation3: 0 }] },
        { c4: 1, fields: [{ attestation4: 0 }] },
        { c22: 1, fields: [{ attestation22: 0 }] },
        { c7: 1, fields: [{ attestation7: 0 }] },
        { c10: 1, fields: [{ attestation10: 0 }] },
        { c11: 1, fields: [{ attestation11: 0 }] },
        // { outLngTermFcSeeChBox: 1, fields: [{ outLongTermFacility: 0 }] },
      ],
      count: 11,

      stepVal: "btn-step1",
      data:
        Object.keys(this.props.preEnrollInfo).length === 0
          ? { ...INITIAL_STATE }
          : this.props.preEnrollInfo,
      disableCheck: false,
      value: "",
      checkedQuestion: "",
      attestionDt: "",
      checkedCount: [],
    };
    this.validator = new SimpleReactValidator();
  }

  handleSelectChange = async (event) => {
   
   
    
    await this.setState({
      value: event.target.value,
    });

    if (this.state.value === "") {
      alert(" Please select plan !!");
      return;
    } else {
      let payload = {
        strPlanId: this.state.value,
      };
      await this.props.planSelectionContinue(payload);
      
     /* await this.setState({
        data:
          this.props.preEnrollInfo &&
          Object.keys(this.props.preEnrollInfo).length === 0
            ? { ...INITIAL_STATE }
            : this.props.preEnrollInfo,
      });*/

      if (
        this.props.preEnrollInfo &&
        Object.keys(this.props.preEnrollInfo).length !== 0
      ) {
        if (this.props.checkQsnNumInAttes != "") {
          await this.setState({ disableCheck: true });
        }
      }
    }
  };

  // async componentDidMount() {
  //   window.scroll(0, 0);
  //   let data = this.state.data;
  //   if (data) {
  //     if (
  //       data.c1 !== "" ||
  //       data.c2 !== "" ||
  //       data.c3 !== "" ||
  //       data.c4 !== "" ||
  //       data.c5 !== "" ||
  //       data.c6 !== "" ||
  //       data.c7 !== "" ||
  //       data.c8 !== "" ||
  //       data.c9 !== "" ||
  //       data.c10 !== "" ||
  //       data.c11 !== "" ||
  //       data.c12 !== "" ||
  //       data.c13 !== "" ||
  //       data.c14 !== "" ||
  //       data.c15 !== "" ||
  //       data.c16 !== "" ||
  //       data.c22 !== "" ||
  //       data.c21 !== "" ||
  //       data.c25 !== "" ||
  //       data.c24 !== ""
  //     ) {
  //       await this.setState({ disableCheck: true });
  //     }
  //   }
  // }

  redirect = async (event) => {
    let id = event.target.id;

    if (id === "save-n-continue1") {
      await this.setState({ stepVal: "btn-step2" });
    }
    if (id === "save-n-continue2") {
      await this.setState({ stepVal: "btn-step3" });
    }
    if (id === "save-n-continue3") {
      await this.setState({ stepVal: "btn-step1" });
    }
  };

  // async componentWillReceiveProps(nextProps) {
  //   console.log(nextProps);
  //   if (
  //     nextProps.preEnrollInfo &&
  //     Object.keys(nextProps.preEnrollInfo).length != 0
  //   ) {
  //     await this.setState({ data: nextProps.preEnrollInfo });
  //   }
  // }

  handleCheckbox1 = async (event) => {
    let name = event.target.name;
    let value = event.target.checked;
    this.formProgress(name, value);
    this.state.formRadio.map((d) => {
      if (name === Object.keys(d)[0] && value === true) {
        this.setState((prevState) => ({
          count: prevState.count + d[Object.keys(d)[0]],
          formData: [...prevState.formData, ...d[Object.keys(d)[1]]],
        }));
      } else if (name === Object.keys(d)[0] && value === false) {
        let index = -1;
        let subArray = d[Object.keys(d)[1]];
        let removedata = this.state.formData;
        subArray.map((c) => {
          index = removedata.findIndex(
            (p) => Object.keys(p)[0] === Object.keys(c)[0]
          );
          removedata.splice(index, 1);
        });

        this.setState((prevState) => ({
          count: prevState.count - d[Object.keys(d)[0]],
          formData: removedata,
        }));
      }
    });
    if (name === "Formulary") {
      value = event.target.checked ? "Y" : "N";
    }
    if (name === "pharmacy") {
      value = event.target.checked ? "Y" : "N";
    }
    if (name === "eoc") {
      value = event.target.checked ? "Y" : "N";
    }

    if (name === "mailingAddressRequired") {
      value = event.target.checked ? "YES" : "";
    }
    await this.setState({
      data: { ...this.state.data, [name]: value },
    });
  };

  handleCheckbox = async (event) => {
    let name = event.target.name;
    let value = event.target.checked;
    console.clear();
    console.log(name + "    c   " + value);
    this.formProgress(name, value);
    this.state.formRadio.map((d) => {
      if (name === Object.keys(d)[0] && value === true) {
        this.setState((prevState) => ({
          count: prevState.count + d[Object.keys(d)[0]],
          formData: [...prevState.formData, ...d[Object.keys(d)[1]]],
        }));
      } else if (name === Object.keys(d)[0] && value === false) {
        let index = -1;
        let subArray = d[Object.keys(d)[1]];
        let removedata = this.state.formData;
        subArray.map((c) => {
          index = removedata.findIndex(
            (p) => Object.keys(p)[0] === Object.keys(c)[0]
          );
          removedata.splice(index, 1);
        });

        this.setState((prevState) => ({
          count: prevState.count - d[Object.keys(d)[0]],
          formData: removedata,
        }));
      }
    });
    if (name === "aep") {
      value = event.target.checked ? "AEP" : "";
    }
    if (name === "c1") {
      value = event.target.checked ? "NEW" : "";
    }
    if (name === "c2") {
      value = event.target.checked ? "MOV" : "";

      if (value === "") {
        await this.setState({ data: { ...this.state.data, attestation2: "" } });
      }
    }
    if (name === "c3") {
      value = event.target.checked ? "INC" : "";
      if (value === "") {
        await this.setState({ data: { ...this.state.data, attestation3: "" } });
      }
    }
    if (name === "c4") {
      value = event.target.checked ? "RUS" : "";
      if (value === "") {
        await this.setState({ data: { ...this.state.data, attestation4: "" } });
      }
    }
    if (name === "c5") {
      value = event.target.checked ? "LAW" : "";
      if (value === "") {
        await this.setState({ data: { ...this.state.data, attestation5: "" } });
      }
    }
    if (name === "c6") {
      value = event.target.checked ? "MDE" : "";
    }

    if (name === "c7") {
      value = event.target.checked ? "HLP" : "";
    }
    if (name === "c21") {
      value = event.target.checked ? "OEP" : "";
    }
    if (name === "c22") {
      value = event.target.checked ? "MCD" : "";
    }
    if (name === "c24") {
      value = event.target.checked ? "DIF" : "";
    }

    if (name === "c25") {
      value = event.target.checked ? "DST" : "";
    }

    if (name === "c8") {
      value = event.target.checked ? "NLS" : "";
      if (value === "") {
        await this.setState({ data: { ...this.state.data, attestation8: "" } });
      }
    }
    if (name === "c9") {
      value = event.target.checked ? "LTC" : "";
      if (value === "") {
        await this.setState({ data: { ...this.state.data, attestation9: "" } });
      }
    }
    if (name === "c10") {
      value = event.target.checked ? "PAC" : "";
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, attestation10: "" },
        });
      }
    }
    if (name === "c11") {
      value = event.target.checked ? "LCC" : "";
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, attestation11: "" },
        });
      }
    }
    if (name === "c12") {
      value = event.target.checked ? "LEC" : "";
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, attestation12: "" },
        });
      }
    }
    if (name === "c13") {
      value = event.target.checked ? "PAP" : "";
    }
    if (name === "c14") {
      value = event.target.checked ? "EOC" : "";
    }
    if (name === "c15") {
      value = event.target.checked ? "SNP" : "";
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, attestation15: "" },
        });
      }
    }
    if (name === "c16") {
      value = event.target.checked ? "OTH" : "";
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, c16Attestation: "", attestation16: "" },
        });
      }
    }

    await this.setState({
      data: { ...this.state.data, [name]: value },
    });

    if (name && value != "") {
      await this.setState({ checkedCount: [...this.state.checkedCount, name] });
    }

    if (name && value === "") {
      if (this.state.checkedCount.length > 0) {
        let items = this.state.checkedCount.filter((item) => item != name);
        await this.setState({ checkedCount: items });
      }
    }

    if (this.state.checkedCount && this.state.checkedCount.length < 5) {
      await this.setState({ disableCheck: false });
    } else {
      await this.setState({ disableCheck: true });
    }
    console.log(this.state.data);

    name = name.substring(1);
    await this.setState({ checkedQuestion: name });
  };

  saveData = async () => {
    const response = await this.props.saveLogout(this.state.data);

    if (response.data === "Enrollment form saved successfully") {
      history.push("/webapp/IndyHealth/userCreation");
    } else {
      alert("Save Failed");
    }
  };

  handleSteps = async (event) => {
    let value = event.target ? event.target.id : event.id;
    if (value) {
      await this.setState({ stepVal: value });
    }
  };

  handleDates = (fieldId) => {
    var self = this;
    DateUtil.getDatePicker("#" + fieldId).datepicker("show");
    DateUtil.getDatePicker("#" + fieldId).on("change", (e) => {
      this.setDates(fieldId, e.target.value);
    });
  };

  setDates = async (fieldId, value) => {
    await this.setState({ data: { ...this.state.data, [fieldId]: value } });
    console.log(this.state.data[fieldId]);
    console.clear();
    this.formProgress(fieldId, value);
    console.log(fieldId + "    setDates   " + value);
  };

  formProgress = (name, value) => {
    // !moment(data.birthDate, "MM/DD/YYYY", true).isValid()
    //     var n = name.toLowerCase().includes("date");
    //     if(n){
    //       if( !moment(value, "MM/DD/YYYY", true).isValid()){

    //  //  return
    //       }
    //     }
    let formData = this.state.formData.map((d) => {
      if (d[name] == 0 && value.trim().length > 0) {
        return { [name]: 1 };
      } else if (d[name] == 1 && value.trim().length == 0) {
        return { [name]: 0 };
      }
      return d;
    });
    this.setState({ formData: formData });
  };

  handleChange = async (e) => {
    //e.preventDefault()
    let name = e.target.name;

    let value = e.target ? e.target.value : e.value;
   //  alert(value + '   '+name)
    this.formProgress(name, value);

    this.state.formRadio.map((d) => {
      if (name === Object.keys(d)[0] && value === "Y") {
        this.setState((prevState) => ({
          count: prevState.count + d[Object.keys(d)[0]],
          formData: [...prevState.formData, ...d[Object.keys(d)[1]]],
        }));
      } else if (name === Object.keys(d)[0] && value === "N") {
        let index = -1;
        let subArray = d[Object.keys(d)[1]];
        let removedata = this.state.formData;
        subArray.map((c) => {
          index = removedata.findIndex(
            (p) => Object.keys(p)[0] === Object.keys(c)[0]
          );
          removedata.splice(index, 1);
        });

        this.setState((prevState) => ({
          count: prevState.count - d[Object.keys(d)[0]],
          formData: removedata,
        }));
      }
    });
    // var jobsUnique = this.state.formData.filter((v,i,a)=>a.findIndex(t=>(JSON.stringify(t) === JSON.stringify(v)))===i)
    // console.log(jobsUnique);
    //console.clear();
    //console.log(name +'    handleChange  '+value)
    if (name.toLowerCase().includes("phone")) {
      value = this.formatPhoneNumber(value.replace(/[^0-9]/g, ""));
    }

    if (name.toLowerCase().includes("attestation")) {
      await this.setState({ attestionDt: value });
    }
    await this.setState({ data: { ...this.state.data, [name]: value } });
    console.log(this.state.data);
    console.log(this.state.data.emailAddr)
  };

  formatPhoneNumber = (phoneNumberString) => {
    var match = phoneNumberString.match(/^(\d{3})(\d{3})(\d{4})$/);
    if (match) {
      return "(" + match[1] + ") " + match[2] + "-" + match[3];
    }
    return phoneNumberString;
  };
  handleNumberChange = (event) => {
    let name = event.target.name;
    let value = event.target.value;
    console.log(value);
    value = value.replace(/[^0-9]/g, "");
    if (value.length === 5) {
      this.formProgress(name, value);
    } else {
      this.formProgress(name, "");
    }
    this.setState({ data: { ...this.state.data, [name]: value } });
  };

  submitData = async () => {
    let productId = "";
    let pbpId = "";
    let fullPlanName;

    let selectedPlan = this.state.value;
    if (selectedPlan === "INDY_SAVER_ARK") {
      fullPlanName = "Arkansas $25.30 per month";
      productId = "012";
      pbpId = "012";
    } else if (selectedPlan === "INDY_SAVER_GEORG") {
      fullPlanName = "Georgia $26.20 per month";
      productId = "010";
      pbpId = "010";
    } else if (selectedPlan === "INDY_SAVER_ILLINOIS") {
      fullPlanName = "Illinois $24.50 per month";
      productId = "011";
      pbpId = "011";
    } else if (selectedPlan === "INDY_SAVER_PENSYL") {
      fullPlanName = "Pennsylvania $34.00 per month";
      productId = "009";
      pbpId = "009";
    } else if (selectedPlan === "INDY_SAVER_WESTVIR") {
      fullPlanName = "West Virginia $34.00 per month";
      productId = "009";
      pbpId = "009";
    } else if (selectedPlan === "INDY_ELITE_GEORG") {
      fullPlanName = "Georgia $47.00 per month";
      productId = "006";
      pbpId = "006";
    } else if (selectedPlan === "INDY_ELITE_ARK") {
      fullPlanName = "Arkansas $44.40 per month";
      productId = "008";
      pbpId = "008";
    } else if (selectedPlan === "INDY_ELITE_ILLINOIS") {
      fullPlanName = "Illinois $43.30 per month";
      productId = "007";
      pbpId = "007";
    } else if (selectedPlan === "INDY_ELITE_PENSYL") {
      fullPlanName = "Pennsylvania $47.10 per month";
      productId = "005";
      pbpId = "005";
    } else {
      fullPlanName = "West Virginia $47.10 per month";
      productId = "005";
      pbpId = "005";
    }
    if(this.state.data.emailAddr !== ""){      
     await  this.setState({ data: { ...this.state.data, emailAlert: "Y"} })
    }
    let payload = {
      ...this.state.data,
      productId: productId,
      pbpId: pbpId,
      fullPlanName: fullPlanName,
      checkQsnNumInAttes: this.state.checkedQuestion,
      attestationDate: this.state.attestionDt,
    };

    console.log(payload);

    if(this.state.data.emailAddr === "" || this.validator.check(this.state.data.emailAddr, "email") ){
     const response = await this.props.submitForm(payload);

      if (response.message === "SUCCESS") {
        history.push("/webapp/IndyHealth/Confirmation");
      } else {
        alert("Submission Failed");
      }
    }
    else{
      alert("Please Enter valid Email address")
    }
  
  };
 

  render() {
   
    const { data, selectedPlan } = this.state;
    let count = 0; //11;
    count = this.state.formData
      .map((item) => {
        return Object.values(item)[0];
      })
      .reduce((prev, next) => prev + next);

    const progress = (count / this.state.count) * 100;
    //console.clear()
    //console.log(this.props.guestLogin)
   // console.log(count);
    // let count = 19;
    // const progress1 = data.firstName === "" ? 0 : 1;
    // const progress2 = data.lastName === "" ? 0 : 1;
    // const progress3 = (data.birthDate === "" &&
    // !moment(data.birthDate, "MM/DD/YYYY", true).isValid()) === "" ? 0 : 1;
    // const progress4 = data.primaryPhone === "" ? 0 : 1;
    // const progress5 = data.permanentAddrStreet === "" ? 0 : 1;
    // const progress6 = data.permanentCity === "" ? 0 : 1;
    // const progress7 = data.emailAddr === "" ? 0 : 1;
    // const progress8 = data.permanentZip === "" ? 0 : 1;
    // const progress9 = data.sex === "" ? 0 : 1;
    // const progress10 = data.medicareClaim === "" ? 0 : 1;
    // // const progress11 = data.pcpName === "" ? 0 : 1;
    // const progress11 = data.nameSignature === "" ? 0 : 1;
    // // const progress12 = data.authorizedrepname !== "" ? 1 : 0;

    // // const progress13 = data.authorizedreprelationship !== "" ? 1 : 0;
    // // const progress14 = data.authorizedrepaddress !== "" ? 1 : 0;
    // // const progress15 = data.authorizedrepphone !== "" ? 1 : 0;
    // // const progress16 = data.digitalSignature === "" ? 0 : 1;

    // const progress12 = data.vaBenefits === "Y" && data.nameOfCov !== "" ? 1 : 0;
    // const progress13 = data.vaBenefits === "Y" && data.idOfCov !== "" ? 1 : 0;
    // const progress14 =
    //   data.vaBenefits === "Y" && data.groupOfCov !== "" ? 1 : 0;

    // const progress15 =
    //   data.mailingAddressRequired === "YES" && data.mailingAddr !== "" ? 1 : 0;
    // const progress16 =
    //   data.mailingAddressRequired === "YES" && data.mailingCity !== "" ? 1 : 0;
    // const progress17 =
    //   data.mailingAddressRequired === "YES" && data.mailingState !== "" ? 1 : 0;
    // const progress18 =
    //   data.mailingAddressRequired === "YES" && data.mailingZip !== "" ? 1 : 0;

    // const progress19 = data.todaysDate === "" ? 0 : 1;

    // console.log("progress1" + progress1);

    // if (data.vaBenefits !== "Y") count -= 3;
    // if (data.mailingAddressRequired !== "YES") count -= 4;
    // const progress =
    //   ((progress1 +
    //     progress2 +
    //     progress3 +
    //     progress4 +
    //     progress5 +
    //     progress6 +
    //     progress7 +
    //     progress8 +
    //     progress9 +
    //     progress10 +
    //     progress11 +
    //     progress12 +
    //     progress13 +
    //     progress14 +
    //     progress15 +
    //     progress16 +
    //     progress17 +
    //     progress18 +
    //     progress19) /
    //     count) *
    //   100;

    return (
      <React.Fragment>
        <div id="content" class="site-content">
          <div id="primary" class="content-area">
            <main id="main" class="site-main">
              <article
                id="post-2"
                class="post-2 page type-page status-publish hentry"
              >
                <header id="home" class="entry-header hide">
                  <h1 class="entry-title">Enrollment Form</h1>
                </header>
                <div class="entry-content margin-top7">
                  <div class="wp-block-editor-blocks-wrapper alignfull page-section bg-gray">
                    <div class="wrapper-inner">
                      <div class="wrapper-inner">
                        <div class="wrapper-inner-blocks">
                          <div class="row">
                            <div class="col-md-9">
                              <h2
                                id="home"
                                class="text-center "
                                style={{ marginLeft: "20rem !important" }}
                              >
                                2021 Indy Health Plan{" "}
                              </h2>
                              <p class="text-center mb-0">
                                Please contact Health Plan if you need
                                information in another language or form.
                                <br />
                                <a href="">CONTACT US &gt;</a>
                              </p>
                            </div>
                            <div class="col-md-3 text-right">
                              <span>
                                OMB No. 0938-1378
                                <br />
                                Expires:7/31/2023
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="wp-block-editor-blocks-wrapper alignfull page-section">
                    <div class="container mt-3">
                      <div class="progress-bar">
                        <LinearProgress
                          variant="determinate"
                          value={progress}
                          color="primary"
                          classes={{
                            root: this.props.classes.root,
                            barColorPrimary:
                              progress === 100
                                ? this.props.classes.progressComplete
                                : this.props.classes.progressIncomplete,
                          }}
                        />
                      </div>
                    </div>
                    <br />

                    <div class="wrapper-inner">
                      <ul
                        class="nav nav-pills nav-justified"
                        value={this.state.stepVal}
                        onClick={this.handleSteps}
                      >
                        <li class="nav-item">
                          <a
                            class={
                              this.state.stepVal === "btn-step1"
                                ? "nav-link active"
                                : "nav-link"
                            }
                            data-toggle="tab"
                            id="btn-step1"
                          >
                            Step 1
                          </a>
                        </li>
                        <li class="nav-item">
                          <a
                            class={
                              this.state.stepVal === "btn-step2"
                                ? "nav-link active"
                                : "nav-link"
                            }
                            data-toggle="tab"
                            id="btn-step2"
                          >
                            Step 2
                          </a>
                        </li>
                        <li class="nav-item">
                          <a
                            class={
                              this.state.stepVal === "btn-step3"
                                ? "nav-link active"
                                : "nav-link"
                            }
                            data-toggle="tab"
                            id="btn-step3"
                          >
                            Step 3
                          </a>
                        </li>
                      </ul>
                      <div class="tab-contentindy">
                        {this.state.stepVal === "btn-step1" && (
                          <Step1
                            data={this.state.data}
                            handleChange={this.handleChange}
                            handleDates={this.handleDates}
                            redirect={this.redirect}
                            value={this.state.value}
                            handleSelectChange={this.handleSelectChange}
                            handleNumberChange={this.handleNumberChange}
                            handleCheckbox={this.handleCheckbox1}
                            authorizedrelations={this.props.authorizedrelations}
                          />
                        )}
                        {this.state.stepVal === "btn-step2" && (
                          <Step2
                            data={this.state.data}
                            handleChange={(e) => {
                              this.handleChange(e);
                            }}
                            handleDates={this.handleDates}
                            redirect={this.redirect}
                            handleCheckbox={this.handleCheckbox1}
                          />
                        )}
                        {this.state.stepVal === "btn-step3" && (
                          <Step3
                            data={this.state.data}
                            submitForm={progress === 100 ? true : false}
                            handleChange={(e) => {
                              this.handleChange(e);
                            }}
                            handleDates={this.handleDates}
                            disableCheck={this.state.disableCheck}
                            handleCheckbox={this.handleCheckbox}
                            redirect={this.redirect}
                            submitData={this.submitData}
                            progress={progress}
                          />
                        )}
                      </div>
                      <div class="row" style={{ marginTop: "0.9rem" }}></div>
                      <div class="row mt-2">
                        {!this.props.guestLogin ? (
                          <div class="col-md-5 col-sm-12 mt-2">
                            <button
                              class="button2 float-left"
                              onClick={this.saveData}
                            >
                              Save and Logout
                            </button>
                          </div>
                        ) : null}
                      </div>
                    </div>
                  </div>
                </div>
              </article>
            </main>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    preEnrollInfo: state.webApp.preEnrollInfo,
    guestLogin: state.webApp.guestLogin,
    physicians: state.webApp.physicians,
    authorizedrelations: state.webApp.authorizedrelations,
  };
};
const mapDispatchToProps = {
  saveLogout,
  submitForm,
  getClinicalName,
  planSelectionContinue,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(PreEnroll));
