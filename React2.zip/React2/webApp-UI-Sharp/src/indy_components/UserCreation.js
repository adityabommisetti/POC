import React, { Component } from "react";
import history from "../Utils/History";
import { signUp, guestLogin } from "../Redux/Actions/webAppActions";
import RemoveRedEyeIcon from "@material-ui/icons/RemoveRedEye";
import SimpleReactValidator from "simple-react-validator";
import { connect } from "react-redux";
import { INITIAL_STATE } from "./InitialState";
import { ListItemText } from "@material-ui/core";

class UserCreation extends Component {
  constructor(props) {
    super(props);

    this.state = {
      // email: "",

      // password: "",
      // reenterpassword: "",
      email: "",
      password: "",
      confirmPassword: "",
      showPassword: false,
      passwordEye: false,
      showConfirmPassword: false,
      confirmPasswordEye: false,
      emailError: false,
      passwordError: false,
      confirmPasswordError: false,
      modified: false,
    };
    this.validator = new SimpleReactValidator();
  }
  selectYear = () => {
    history.push("/webapp/IndyHealth/yearSelectionGuest");
  };
  componentDidMount() {
    window.scroll(0, 0);
  }
  handleChange = (event) => {
    const { password } = this.state;
    const name = event.target.name;
    const value = event.target.value;
    const emailError =
      name === "email" &&
      (!this.validator.check(value, "email") || value === "");
    const passwordError = name === "password" && value === "";
    const confirmPasswordError =
      name === "confirmPassword" && (value === "" || password !== value);

    this.setState({
      [name]: value,
      emailError: emailError,
      passwordError: passwordError,
      confirmPasswordError: confirmPasswordError,
      modified: true,
    });
  };

  handleFocus = (name) => (event) => {
    event.preventDefault();
    const showPasswordEye = name === "password";
    const showConfirmPasswordEye = name === "confirmPassword";
    this.setState({
      passwordEye: showPasswordEye,
      confirmPasswordEye: showConfirmPasswordEye,
    });
  };

  handleOnBlur = (name) => (event) => {
    event.preventDefault();
    const {
      showConfirmPassword,
      showPassword,
      email,
      password,
      confirmPassword,
    } = this.state;
    const showPasswordEye = name === "password" && showPassword;
    const showConfirmPasswordEye =
      name === "confirmPassword" && showConfirmPassword;
    const emailError =
      name === "email" &&
      (!this.validator.check(email, "email") || email === "");
    const passwordError = password === "";
    const confirmPasswordError =
      confirmPassword === "" || password !== confirmPassword;
    this.setState({
      passwordEye: showPasswordEye,
      confirmPasswordEye: showConfirmPasswordEye,
      emailError: emailError,
      passwordError: passwordError,
      confirmPasswordError: confirmPasswordError,
    });
  };

  showPassword = (name, toggle) => (event) => {
    document.getElementById(name).focus();
    const eyeIcon = name === "password" ? "passwordEye" : "confirmPasswordEye";
    const show = name === "password" ? "showPassword" : "showConfirmPassword";
    this.setState({
      [eyeIcon]: true,
      [show]: toggle,
    });
  };

  signUp = async () => {
    const { email, password, confirmPassword } = this.state;

    const emailError = !this.validator.check(email, "email") || email === "";

    const confirmPasswordError =
      confirmPassword === "" || password !== confirmPassword;

    if (emailError) {
      alert("Email format is incorrect");
      return;
    }
    if (!password) {
      alert("Please enter Password");
      return;
    }
    if (confirmPasswordError) {
      alert("Passwords do not match - Please Re-enter");
      return;
    }
    let body = {
      emailAddress: email,
      password: password,
      reconfirmPwd: confirmPassword,
    };

    body = { ...body, customerId: INITIAL_STATE.customerId };

    const signup = await this.props.signUp(body);
    if (signup.message === "SUCCESS")
      history.push("/webapp/IndyHealth/yearSelection");
    else alert(signup.message);
  };
  continueAsGuest = async (e) => {
    // e.preventDefault();
    const guestLogin = await this.props.guestLogin(INITIAL_STATE.customerId);
    if (guestLogin.data === "Logged in as guest")
      history.push("/webapp/IndyHealth/yearSelectionGuest");
    else alert("Login Failed");
  };
  login = (e) => {
    e.preventDefault();
    history.push("/webapp/IndyHealth/userLogin");
  };

  render() {
    const {
      password,
      confirmPassword,
      email,
      showPassword,
      showConfirmPassword,
      passwordEye,
      confirmPasswordEye,
      emailError,
      passwordError,
      confirmPasswordError,
    } = this.state;
    return (
      <React.Fragment>
        <div id="content" class="site-content">
          <div id="primary" class="content-area">
            <main id="main" class="site-main">
              <article
                id="post-2"
                class="post-2 page type-page status-publish hentry"
              >
                <header id="home" class="entry-header hide">
                  <h1 class="entry-title">Home</h1>
                </header>

                <div class="entry-content margin-top7">
                  <div class="wp-block-editor-blocks-wrapper alignfull page-section bg-gray">
                    <div class="wrapper-inner">
                      <div class="wrapper-inner-blocks">
                        <h2 id="home" class="text-center">
                          Create a Health Plan Medicare Account
                        </h2>
                        <p class="text-center">
                          Health Plan provides you with access to expert care
                          and award-winning facilities and programs that help
                          you make the most of your health care. We're here to
                          make finding and enrolling in the right plan simple.
                          Whether you have never purchased Medicare health
                          coverage before or are considering switching from your
                          current plan, we are committed to making your health
                          care experience affordable, simple, accessible and
                          personal. At Health plan, we offer Medicare plans to
                          feel good about.
                        </p>
                      </div>
                    </div>
                  </div>
                  <div class="wp-block-editor-blocks-wrapper alignfull page-section2">
                    <div class="wrapper-inner">
                      <div class="tab-contentindy">
                        <div class="container form-panel">
                          <div class="form-group row">
                            <div class="col-md-12">
                              <label
                                for="email-address"
                                class="control-label"
                                style={{ padding: "0px !important" }}
                              >
                                Email Address*
                              </label>
                              <input
                                type="text"
                                id="email-address"
                                name="email"
                                class={
                                  this.state.email === "" || emailError
                                    ? "error-input"
                                    : "form-control"
                                }
                                required=""
                                value={this.state.email}
                                onChange={this.handleChange}
                                onBlur={this.handleOnBlur("email")}
                              />
                              <br />
                              <label for="password" class="control-label">
                                Password*
                              </label>
                              <input
                                type={showPassword ? "text" : "password"}
                                id="password"
                                class={
                                  this.state.password === "" || passwordError
                                    ? "error-input"
                                    : "form-control"
                                }
                                name="password"
                                required=""
                                value={this.state.password}
                                onFocus={this.handleFocus("password")}
                                onBlur={this.handleOnBlur("password")}
                                onChange={this.handleChange}
                              />
                              {passwordEye ? (
                                <div
                                  class="eyeIcon-password"
                                  onMouseUp={this.showPassword(
                                    "password",
                                    false
                                  )}
                                  onMouseDown={this.showPassword(
                                    "password",
                                    true
                                  )}
                                  onMouseOut={this.showPassword(
                                    "password",
                                    false
                                  )}
                                >
                                  <RemoveRedEyeIcon />
                                </div>
                              ) : null}

                              <br />
                              <label
                                for="re-enter-password"
                                class="control-label"
                              >
                                Re-enter Password*
                              </label>
                              <input
                                type={showConfirmPassword ? "text" : "password"}
                                id="confirmPassword"
                                class={
                                  this.state.confirmPassword === "" ||
                                  confirmPasswordError
                                    ? "error-input"
                                    : "form-control"
                                }
                                autoFocus
                                name="confirmPassword"
                                required=""
                                value={this.state.confirmPassword}
                                onFocus={this.handleFocus("confirmPassword")}
                                onBlur={this.handleOnBlur("confirmPassword")}
                                onChange={this.handleChange}
                              />
                              {confirmPasswordEye ? (
                                <div
                                  class="eyeIcon-confirm-password"
                                  onMouseUp={this.showPassword(
                                    "confirmPassword",
                                    false
                                  )}
                                  onMouseDown={this.showPassword(
                                    "confirmPassword",
                                    true
                                  )}
                                  onMouseOut={this.showPassword(
                                    "confirmPassword",
                                    false
                                  )}
                                >
                                  <RemoveRedEyeIcon
                                    onClick={this.showPassword}
                                  />
                                </div>
                              ) : null}
                            </div>
                          </div>
                          <div class="button-container-login-pageindy">
                            <button
                              class="button2 mr-3"
                              id="continue-as-a-guest"
                              onClick={this.continueAsGuest}
                            >
                              Continue as Guest
                            </button>
                            <button
                              class={
                                this.state.modified
                                  ? "button btn-save-n-continue"
                                  : "btn btn-secondary"
                              }
                              id="signup"
                              onClick={this.signUp}
                              style={{
                                padding: "9px 34px",
                                borderRadius: "50px",
                              }}
                            >
                              Sign-up
                            </button>
                            <div class="already-have-account">
                              <p>
                                Already have an account? <br />
                                <a href="# " onClick={this.login}>
                                  Log in here
                                </a>
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </article>
            </main>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {};
};
const mapDispatchToProps = {
  signUp,
  guestLogin,
};

export default connect(mapStateToProps, mapDispatchToProps)(UserCreation);
