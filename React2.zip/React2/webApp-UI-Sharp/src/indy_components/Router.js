import React from "react";
import { Router, Redirect, Route, Switch } from "react-router-dom";

import UserCreation from "./UserCreation";
import YearSelection from "../components/YearSelection";
import UserLogin from "../components/LoginForm";
import PlanSelection from "../components/PlanSelection";
import history from "../Utils/History";
import PreEnroll from "../components/PreEnroll";
import Exhibit from "./exhibit";
import Confirmation from "./Confirmation";

import "../assets/css/style.css";

const webappRouter = () => {
  return (
    <React.Fragment>
      <Router history={history} forceRefresh={true}>
        <Switch>
          <Route
            path="/webapp/IndyHealth/userCreation"
            render={() => <UserCreation />}
            component={UserCreation}
          />

          <Route
            path="/webapp/IndyHealth/yearSelectionGuest"
            render={() => <YearSelection />}
          />
          <Route
            path="/webapp/IndyHealth/yearSelection"
            render={() => <YearSelection />}
          />
          <Route path="/webapp/IndyHealth/exhibit" render={() => <Exhibit />} />
          <Route
            path="/webapp/IndyHealth/selectedPlans"
            render={() => <PlanSelection />}
          />
          <Route
            path="/webapp/IndyHealth/enrollOnline"
            render={() => <PreEnroll />}
            component={PreEnroll}
          />
          <Route
            path="/webapp/IndyHealth/userLogin"
            render={() => <UserLogin />}
          />

          <Route
            path="/webapp/IndyHealth/Confirmation"
            render={() => <Confirmation />}
            component={Confirmation}
          />

          {/* <Route
            path="/webapp/Sharp/userCreation"
            render={() => <UserCreation />}
            component={UserCreation}
          />
      
          <Route
            path="/webapp/Sharp/Individual/yearSelection"
            render={() => <YearSelection />}
          />
          <Route
            path="/webapp/Sharp/Individual/userLogin"
            render={() => <UserLogin />}
          />
      
          <Route
            path="/webapp/Sharp/Individual/enrollOnline"
            render={() => <PreEnrollForm />}
            component={PreEnrollForm}
          />
          <Route
            path="/webapp/Sharp/Individual/Confirmation"
            render={() => <Confirmation />}
            component={Confirmation}
          />
 */}
          <Redirect from="/" to="/webapp/IndyHealth/userCreation" />
        </Switch>
      </Router>
    </React.Fragment>
  );
};
export default webappRouter;
