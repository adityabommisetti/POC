import React, { Component } from "react";
import history from "../Utils/History";

export default class Exhibit extends Component {
  constructor(props) {
    super(props);
  }

  async componentDidMount() {
    window.scroll(0, 0);
  }

  enrollOnline = () => {
    history.push("/webapp/IndyHealth/enrollOnline");
  };
  render() {
    return (
      <React.Fragment>
        <div id="content" class="site-content">
          <div id="primary" class="content-area">
            <main id="main" class="site-main">
              <article
                id="post-2"
                class="post-2 page type-page status-publish hentry"
              >
                <header id="home" class="entry-header hide">
                  <h1 class="entry-title">Home</h1>
                </header>
                <div class="entry-content margin-top7">
                  <div class="wp-block-editor-blocks-wrapper alignfull page-section bg-gray">
                    <div class="wrapper-inner">
                      <div class="wrapper-inner-blocks">
                        <div class="row">
                          <div class="col-md-9">
                            <h3 id="home" class="text-center">
                              INDIVIDUAL ENROLLMENT REQUEST FORM TO ENROLL IN A
                              MEDICARE PRESCRIPTION DRUG PLAN (PART D)
                            </h3>
                          </div>
                          <div class="col-md-3 text-right">
                            <span>
                              OMB No. 0938-1378
                              <br />
                              Expires:7/31/2023
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="wp-block-editor-blocks-wrapper alignfull page-section2">
                    <div class="wrapper-inner">
                      <div class="wp-block-columns has-2-columns">
                        <div class="wp-block-column">
                          <div>
                            <h4>Who can use this form?</h4>
                            <p>
                              People with Medicare who want to join a Medicare
                              Prescription Drug Plan
                            </p>
                            <p class="">
                              <strong>To join a plan, you must:</strong>
                            </p>
                            <ul>
                              <li>
                                Be a United States citizen or be lawfully
                                present in the U.S.
                              </li>
                              <li>Live in the plan's service area</li>
                            </ul>
                          </div>
                          <div class="mt-5">
                            <h4>When do I use this form?</h4>
                            <p>
                              <strong>You can join a plan:</strong>
                            </p>
                            <ul>
                              <li>
                                Between October 15–December 7 each year (for
                                coverage starting January1)
                              </li>
                              <li>Within 3 months of first getting Medicare</li>
                              <li>
                                In certain situations where you're allowed to
                                join or switch plans
                              </li>
                            </ul>
                            <p>
                              Visit Medicare.gov to learn more about when you
                              can sign up for a plan.
                            </p>
                          </div>

                          <div class="mt-5">
                            <h4>What do I need to complete this form?</h4>
                            <ul>
                              <li>
                                Your Medicare Number (the number on your red,
                                white, and blue Medicare card)
                              </li>
                              <li>Your permanent address and phone number</li>
                            </ul>
                            <p>
                              <strong>Note:</strong> You must complete all items
                              in Section 1. The items in Section 2 are optional
                              — you can't be denied coverage because you don't
                              fill them out.
                            </p>
                          </div>
                        </div>

                        <div class="wp-block-column">
                          <div>
                            <h4>Reminders:</h4>
                            <ul>
                              <li>
                                If you want to join a plan during fall open
                                enrollment (October 15–December 7), the plan
                                must get your completed form by December 7.
                              </li>
                              <li>
                                Your plan will send you a bill for the plan's
                                premium. You can choose to sign up to have your
                                premium payments deducted from your bank account
                                or your monthly Social Security (or Railroad
                                Retirement Board) benefit.
                              </li>
                            </ul>
                          </div>
                          <div class="mt-5">
                            <h4>What happens next?</h4>
                            <p>Send your completed and signed form to:</p>
                            <p>
                              Indy Health Insurance Company
                              <br />
                              7401 Metro Blvd.
                              <br />
                              Suite 625
                              <br />
                              Edina, MN 55439
                            </p>
                            <p>
                              Once they process your request to join, they'll
                              contact you.
                            </p>
                          </div>

                          <div class="mt-5">
                            <h4>How do I get help with this form?</h4>
                            <p>
                              Call Indy Health Insurance Company at
                              1-800-799-0927. TTY users can call 711.
                            </p>
                            <p>
                              Or, call Medicare at 1-800-MEDICARE
                              (1-800-633-4227). TTY users can call
                              1-877-486-2048.
                            </p>
                            <p>
                              <strong>En español:</strong> En español: Llame a
                              Indy Health Insurance Company al
                              1-800-799-0927/711 o a Medicare gratis al
                              <br />
                              1-800-633-4227 y oprima el 2 para asistencia en
                              español y un representante estará disponible para
                              asistirle.
                            </p>
                          </div>
                        </div>
                      </div>
                      <div class="text-center">
                        <a class="button" onClick={this.enrollOnline}>
                          Continue
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
                \
              </article>
            </main>
          </div>
        </div>
        <div class="footer-top">
          <div class="container">
            <section class="widget widget_media_image mb-3">
              <img
                // src={require("../assets/images/IH-InsuranceCo-logo-gray.png")}
                src={require("../assests/images/IH-InsuranceCo-logo.png")}
                class="custom-logo"
                alt="Indy Insurance Co Logo"
              />
            </section>
            <section class="widget widget_text">
              <div class="textwidget">
                <p>
                  According to the Paperwork Reduction Act of 1995, no persons
                  are required to respond to a collection of information unless
                  it displays a valid OMB control number. The valid OMB control
                  number for this information collection is 0938-NEW. The time
                  required to complete this information is estimated to average
                  20 minutes per response, including the time to review
                  instructions, search existing data resources, gather the data
                  needed, and complete and review the information collection. If
                  you have any comments concerning the accuracy of the time
                  estimate(s) or suggestions for improving this form, please
                  write to: CMS, 7500 Security Boulevard, Attn: PRA Reports
                  Clearance Officer, Mail Stop C4-26-05, Baltimore, Maryland
                  21244-1850.
                </p>
              </div>
            </section>
            <section class="widget widget_text">
              <div class="textwidget">
                <p>
                  <strong>IMPORTANT</strong>
                </p>
                <p>
                  Do not send this form or any items with your personal
                  information (such as claims, payments, medical records, etc.)
                  to the PRA Reports Clearance Office. Any items we get that
                  aren’t about how to improve this form or its collection burden
                  (outlined in OMB 0938-1378) will be destroyed. It will not be
                  kept, reviewed, or forwarded to the plan. See “What happens
                  next?” on this page to send your completed form to the plan.
                </p>
              </div>
            </section>
          </div>
        </div>
      </React.Fragment>
    );
  }
}
