import React from "react";
import { Text } from "react-internationalization";

export const header = <Text id="header.sharpHealthPlan"/>;
export const Body = (props) => {
  return (
    <React.Fragment>
    <div>
      <p>
        <Text id="header.sharpHealthPlanPara"/>{" "}
        <a
          href="https://www.sharpmedicareadvantage.com/enroll/pre-enrollment-checklist/"
          class="enroll-subheader-content"
        >
         <Text id="header.checklist" />
        </a>
        <Text id="header.sharpHealthPlanPara1"/>{" "}
        <a href="https://www.medicare.gov/" class="enroll-subheader-content">
          http://www.medicare.gov
        </a>
        .{" "}
      </p>
      <p align="center">
        <a
          href="https://www.sharpmedicareadvantage.com/contact-us/"
          class="enroll-header-content"
        >
          <strong><Text id="header.contactUs"/>-&gt;</strong>
        </a>
      </p>
    
    </div>
</React.Fragment>
  );
};
