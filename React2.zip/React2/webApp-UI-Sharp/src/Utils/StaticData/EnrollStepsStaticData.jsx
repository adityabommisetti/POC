import React from "react";
import { Text } from "react-internationalization";
export const header = <Text id="header.enrollmentSteps" />
export const Body = (props) => {
  return (
    <p>
     <Text id="header.enrollmentStepsPare"/>
    </p>
  );
};
