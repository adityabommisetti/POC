import React from "react";
import { Text } from "react-internationalization";
export const header =  <Text id="user.foghead"/>
export const Body = (props) => {
  return (
    <p>
      <Text id="user.fogsub"/>.
    </p>
  );
};
