import React from "react";
import history from "../../Utils/History";
import { connect } from "react-redux";
import { Text } from "react-internationalization";
const subHeader = (header) => {
  let subHedar = "";
  subHedar = (
    <React.Fragment>
      <div class="jumbotron" style={{ paddingBottom: "0vh" }}>
        <div class="container">
          <div class="enroll-header-content enroll-header-bg">
            <h2>
              {header.substring(0, 4)} <Text id="header.stepHeader"/>
            </h2>
            <p>
              <Text id="header.stepeHeaderPara"/>
              
            </p>
          </div>
          <div style={{ textAlign: "left" }}>
            <div>
              <div class="plan-title pull-left">
                <span style={{ padding: "10px" }}>{header}</span>
                <a
                  class="teal pull-left change-plan"
                  href="none"
                  onClick={(e) => {
                    e.preventDefault();

                    if (localStorage.getItem("guestLogin") === "true")
                      history.push(
                        "/webapp/Sharp/Individual/yearSelectionGuest"
                      );
                    else history.push("/webapp/Sharp/Individual/yearSelection");
                  }}
                >
                 <Text id="header.changeMyPlane"/>
                </a>
              </div>
            </div>
            {/* <div>
              This plan is open to all Medicare-eligible City of San Diego
              retirees, sponsored by San Diego Public Employee Benefit
              Association (SDPEBA). SDPEBA membership is not required to join
              this plan.
            </div>
            <br />{" "}
            <div>
              <strong>Important Information</strong>
            </div>
            <br />
            <div>
              The Medicare application is intended for individual coverage only.
              If you and your spouse/ dependent are both applying for coverage,
              then each of you will need to complete a separate enrollment form.
              <p>
                Note – If your spouse/dependent is not eligible for Medicare,
                then he/she will need to complete the Non-Medicare / Early
                Retiree, enrollment form. Please contact SDPEBA at
                1-888-315-8027 or visit www.sdpeba.org to download the
                enrollment form
              </p>
            </div> */}
            <div>
            <Text id="header.contactPara"/>&nbsp;&nbsp;
              <a
                class="contact-us"
                href="https://www.sharpmedicareadvantage.com/contact-us/contact-information"
              >
                <strong><Text id="header.contactUs"/></strong>
              </a>
            </div>
          </div>{" "}
        </div>
      </div>
    </React.Fragment>
  );
  if (
    header === "2020 Sharp Direct Advantage Gold Card (HMO)" ||
    header === "2020 Sharp Direct Advantage Gold Card (HMO) With Dental" ||
    header === "2020 Sharp Direct Advantage Platinum Card (HMO) With Dental" ||
    header === "2021 Sharp Direct Advantage Gold Card (HMO)" ||
    header === "2021 Sharp Direct Advantage Gold Card (HMO) With Dental" ||
    header === "2021 Sharp Direct Advantage Platinum Card (HMO) With Dental"
  ) {
    return subHedar;
  } else if (
    header === "2019-20 Sharp Direct Advantage (HMO)" ||
    header === "2020-21 Sharp Direct Advantage (HMO)" ||
    header === "2020-21 Sharp Direct Advantage (HMO)" ||
    header === "2020-21 Sharp Direct Advantage (HMO)"
  ) {
    console.log("else if" + header);
    return (
      <React.Fragment>
        <div class="jumbotron" style={{ paddingBottom: "0vh" }}>
          <div class="container">
            <div class="enroll-header-content enroll-header-bg">
              <h2><Text id="header.planSDPEBA"/></h2>
              <p>
              <Text id="header.planSDPEBAPara"/>
               
              </p>
            </div>
            <div style={{ textAlign: "left" }}>
              <div class="plan-title pull-left">
                <span style={{ padding: "10px" }}>
                <Text id="header.planName"/>
                </span>
                <a
                  class="teal pull-left change-plan"
                  href="none"
                  onClick={(e) => {
                    e.preventDefault();

                    localStorage.getItem("guestLogin") === "true"
                      ? history.push(
                          "/webapp/Sharp/Individual/yearSelectionGuest"
                        )
                      : history.push("/webapp/Sharp/Individual/yearSelection");
                  }}
                >
                  <Text id="header.changeMyPlane"/>
                </a>
              </div>
            </div>
            <div style={{ textAlign: "left" }}>
            <Text id="header.planSDPEBASubPara"/>
              
            </div>
            <br />{" "}
            <div style={{ textAlign: "left" }}>
              <strong><Text id="header.importantInstruction"/></strong>
            </div>
            <br />
            <div style={{ textAlign: "left" }}>
            <Text id="header.importantInstructionPara"/>
              
              <br />
              <br />
              <p style={{ textAlign: "left" }}>
              <Text id="header.importantInstructionNote"/>
              </p>
              <br />
            </div>
            <div style={{ textAlign: "left" }}>
            <Text id="header.contactPara"/>
              &nbsp;&nbsp;
              <a
                class="contact-us"
                href="https://www.sharpmedicareadvantage.com/contact-us/contact-information"
              >
                <strong><Text id="header.contactUs"/></strong>
              </a>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  } else {
    return (
      <React.Fragment>
        <div class="jumbotron" style={{ paddingBottom: "0vh" }}>
          <div class="container">
            <div class="enroll-header-content enroll-header-bg">
              <h2>
                {header.substring(0, 4)} <Text id="header.planHealthCareOnly"/>
              </h2>
              {header ===
              "2020 Sharp Direct Advantage Gold Card (HMO) with Dental" ? (
                <p>
                  This plan is open to all Medicare-eligible residents of San
                  Diego County.
                </p>
              ) : header ===
                "2021 Sharp Direct Advantage Gold Card (HMO) with Dental" ? (
                <p>
                  <Text id="header.stepeHeaderPara"/>
                </p>
              ) : (
                <p>
                  <Text id="header.planHealthCareOnlyPara"/>
                </p>
              )}
            </div>
            <div style={{ textAlign: "left" }}>
              <div class="plan-title pull-left">
                <span style={{ padding: "10px" }}>{header}</span>
                <a
                  class="teal pull-left change-plan"
                  href="none"
                  onClick={(e) => {
                    e.preventDefault();

                    localStorage.getItem("guestLogin") === "true"
                      ? history.push(
                          "/webapp/Sharp/Individual/yearSelectionGuest"
                        )
                      : history.push("/webapp/Sharp/Individual/yearSelection");
                  }}
                >
                 <Text id="header.changeMyPlane"/>
                </a>
              </div>
            </div>
            <div style={{ textAlign: "left" }}>
            <Text id="header.contactPara"/>
              <a
                class="contact-us"
                href="https://www.sharpmedicareadvantage.com/contact-us/contact-information"
              >
                <strong><Text id="header.contactUs"/></strong>
              </a>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
};
const CUSTOMER_LOGO1 = {
  SDAGC20: subHeader("2020 Sharp Direct Advantage Gold Card (HMO)"),
  SDAGCWD20: subHeader(
    "2020 Sharp Direct Advantage Gold Card (HMO) with Dental"
  ),
  SDAPC20: subHeader(
    "2020 Sharp Direct Advantage Platinum Card (HMO) With Dental"
  ),
  SDAB20: subHeader("2020 Sharp Direct Advantage Basic (HMO)"),
  SDABWD20: subHeader("2020 Sharp Direct Advantage Basic (HMO) with Dental"),
  SDAP20: subHeader("2020 Sharp Direct Advantage Premium (HMO)"),
  SDAPWD20: subHeader("2020 Sharp Direct Advantage Premium (HMO) with Dental"),
  SDAHMO1: subHeader("2019-20 Sharp Direct Advantage (HMO)"),
  SDAHMO20: subHeader("2020-21 Sharp Direct Advantage (HMO)"),
};
const CUSTOMER_LOGO2 = {
  SDAGC20: subHeader("2021 Sharp Direct Advantage Gold Card (HMO)"),
  SDAGCWD20: subHeader(
    "2021 Sharp Direct Advantage Gold Card (HMO) with Dental"
  ),
  SDAPC20: subHeader(
    "2021 Sharp Direct Advantage Platinum Card (HMO) With Dental"
  ),
  SDAB20: subHeader("2021 Sharp Direct Advantage Basic (HMO)"),
  SDABWD20: subHeader("2021 Sharp Direct Advantage Basic (HMO) with Dental"),
  SDAP20: subHeader("2021 Sharp Direct Advantage Premium (HMO)"),
  SDAPWD20: subHeader("2021 Sharp Direct Advantage Premium (HMO) With Dental"),

  SDAHMO1: subHeader("2019-20 Sharp Direct Advantage (HMO)"),
  SDAHMO20: subHeader("2020-21 Sharp Direct Advantage (HMO)"),
};
const CUSTOMER_LOGO2Spanish = {
  SDAGC20: subHeader("2021 Ventaja directa de Sharp Tarjeta Gold (HMO)"),
  SDAGCWD20: subHeader(
    "2021 Ventaja directa de Sharp Tarjeta Gold (HMO) con servicio dental"
  ),
  SDAPC20: subHeader(
    "2021 Ventaja directa de Sharp Tarjeta Platinum (HMO) con Dental"
  ),
  SDAB20: subHeader("2021 Aguda Directa Ventaja Básica (HMO)"),
  SDABWD20: subHeader("2021 Aguda Directa Ventaja Básica (HMO) con dental"),
  SDAP20: subHeader("2021 Aguda Directa Ventaja Premium (HMO)"),
  SDAPWD20: subHeader("2021 Aguda Directa Ventaja  Premium (HMO) con dental"),

  SDAHMO1: subHeader("2019-20 Sharp Direct Advantage (HMO)"),
  SDAHMO20: subHeader("2020-21 Sharp Direct Advantage (HMO)"),
  }
const CUSTOMER_LOGO = (props) => {
  return (
    <React.Fragment>
      {props.year === "2020"
        ? CUSTOMER_LOGO1[props.selectedPlan]
        :props.lang==="es" ?CUSTOMER_LOGO2Spanish[props.selectedPlan] : CUSTOMER_LOGO2[props.selectedPlan]}
    </React.Fragment>
  );
};

const mapStateToProps = (state) => {
  return {
    selectedPlan: state.webApp.selectedPlan,
    year: state.webApp.year,
    lang: state.webApp.language
  };
};
export default connect(mapStateToProps)(CUSTOMER_LOGO);
