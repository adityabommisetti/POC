import React from "react";
import { Text } from "react-internationalization";
export const header = <Text id="user.loghead"/>
export const Body = (props) => {
  return (
    <p>
      <Text id="user.logsub"/>.
    </p>
  );
};
