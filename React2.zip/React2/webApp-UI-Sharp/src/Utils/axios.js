import axios from "axios";

axios.defaults.headers.post["Content-Type"] =
  "application/x-www-form-urlencoded";

axios.defaults.withCredentials = true;

axios.defaults.headers.common = {
  ...axios.defaults.headers.common,
  "Content-Type": "application/json",
};

axios.defaults.preflightContinue = true;

const http = axios.create({
  baseURL: "/webapp-api",
  headers: {
    "Access-Control-Allow-Origin": "*",
    "Content-Type": "application/json",
    "Access-Control-Allow-Headers": "*",
  },
});

export default http;
