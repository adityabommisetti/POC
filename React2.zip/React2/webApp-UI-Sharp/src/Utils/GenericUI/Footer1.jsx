import React from "react";
import {Text} from "react-internationalization";

const Footer1 = (props) => {
  return (
    <footer class="pt-4 pt-md-5 border-top">
      <div class="container">
        <div class="footer">
          <div class="footer-img"></div>
          <div class="footer-lower footer-lower-tab">
            <div class="row">
              <div class="col-xs-3 col-sm-3 col-md-3 footer-white-line">
                &nbsp;
              </div>
              <div class="col-xs-6 col-sm-6 col-md-6 footer-center-text text-center">
                <strong>
                <Text id="footer.madewith"/> &nbsp;
                  <span class="footer-lower--heart footer-lower--heart-tab">
                    ♥
                  </span>
                  &nbsp; <Text id="footer.by" />
                </strong>
              </div>
              <div class="col-xs-3 col-sm-3 col-md-3 footer-white-line">
                &nbsp;
              </div>
            </div>
            <div class="row footer-lower--links mt-4">
              <div class="col-sm-3 mb-3">
                <div class="footer-lower--links-heading">
                  <span class="helpful-links-tab"><Text id="footer.HL"/></span>
                </div>
                <ul class="footer-list">
                  <li>
                    <a
                      href="https://www.sharpmedicareadvantage.com/login"
                      class="lang-tooltip"
                    >
                      <Text id="footer.login"/>
                    </a>
                  </li>
                  <li>
                    <a
                      rel="noopener noreferrer"
                      href="https://www.sharphealthplanpayment.com/PP"
                      target="_blank"
                      class="lang-tooltip"
                    >
                      <Text id="footer.pay"/>
                    </a>
                  </li>
                  <li>
                    <a
                      rel="noopener noreferrer"
                      href="https://content.sharphealthplan.com/members/manage-your-plan"
                      target="_blank"
                      class="lang-tooltip"
                    >
                      <Text id="footer.manage"/>
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://www.sharpmedicareadvantage.com/appeals-grievances"
                      class="lang-tooltip"
                    >
                      <Text id="footer.appeals"/>
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://www.sharpmedicareadvantage.com/faqs"
                      class="lang-tooltip"
                    >
                      <Text id="footer.faq"/>
                    </a>
                  </li>
                </ul>
              </div>

              <div class="col-sm-3 mb-3">
                <div class="footer-lower--links-heading"><Text id="footer.gc" /></div>
                <ul class="footer-list">
                  <li>
                    <a
                      href=" https://www.sharpmedicareadvantage.com/find-a-doctor-or-pharmacy"
                      class="lang-tooltip"
                    >
                      <Text id="footer.finddoc"/>
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://www.sharpmedicareadvantage.com/members/get-care/sharp-advantage-providers"
                      class="lang-tooltip"
                    >
                      <Text id="footer.search" />
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://www.sharpmedicareadvantage.com/members/get-care/sharp-advantage-providers"
                      class="lang-tooltip"
                    >
                      <Text id="footer.findcare"/>
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://www.sharpmedicareadvantage.com/members/get-care/sharp-advantage-providers"
                      class="lang-tooltip"
                    >
                      <Text id="footer.findhosp"/>
                    </a>
                  </li>
                </ul>
              </div>

              <div class="col-sm-3 mb-3">
                <div class="footer-lower--links-heading">
                  <span class="helpful-links-tab"><Text id="footer.oc"/></span>
                </div>
                <ul class="footer-list">
                  <li>
                    <a
                      href="https://www.sharpmedicareadvantage.com/contact-us"
                      class="lang-tooltip"
                    >
                      <Text id="footer.Cus"/>
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://www.sharpmedicareadvantage.com/about-us"
                      class="lang-tooltip"
                    >
                      <Text id="footer.Aus"/>
                    </a>
                  </li>
                </ul>
              </div>

              <div class="col-sm-3 mb-3">
                <div class="footer-lower--links-heading">
                  <span><Text id="footer.Cus"/></span>
                </div>
                <p class="contact-para-tab">
                  <strong>
                    <Text id="footer.call"/> &nbsp;
                    <a
                      href="tel:1-855-562-8853"
                      title="Call 1-855-562-8853 (TTY/TDD 711)"
                      class="lang-tooltip"
                    >
                      1-855-562-8853
                    </a>
                    (TTY/TDD 711)
                  </strong>
                  <br />
                  <Text id="footer.hrsofOp1"/><Text id="footer.hrsofOp2"/><Text id="footer.hrsofOp3"/><Text id="footer.hrsofOp4"/><Text id="footer.hrsofOp5"/>&nbsp;
                </p>
              </div>
            </div>

            <div class="row">
              <div class="col-xs-12 col-sm-3 col-md-3 footer-white-line">
                &nbsp;
              </div>
              <div class="col-xs-12 col-sm-6 col-md-6 footer-center-text text-center">
                <strong><Text id="footer.helpinLang"/></strong>
              </div>
              <div class="col-xs-12 col-sm-3 col-md-3 footer-white-line">
                &nbsp;
              </div>
            </div>

            <div class="row footer-lower--help mt-4">
              <div class="col-sm-3 language-blocks">
                <ul class="footer-list">
                  <li>
                    <a
                      href="none"
                      onClick={(e) => {
                        e.preventDefault();
                      }}
                      class="lang-tooltip"
                      data-animation="true"
                      data-content="Si usted, o alguien a quien usted está ayudando, tiene preguntas acerca de Sharp Health Plan, tiene derecho a obtener ayuda e información en su idioma sin costo alguno. Para hablar con un intérprete, llame al (855) 562-8853."
                      data-placement="auto top"
                      data-toggle="popover"
                      data-trigger="focus"
                      lang="es"
                      role="button"
                      tabindex="80"
                      data-original-title=""
                      title=""
                    >
                      Español
                    </a>
                  </li>
                  <li>
                    <a
                      href="none"
                      onClick={(e) => {
                        e.preventDefault();
                      }}
                      class="lang-tooltip"
                      data-animation="true"
                      data-content="如果您，或是您正在協助的對象，有關 Sharp Health Plan 代碼及範圍方面有疑問，您有權利免費以您的母語得到幫助和訊息。洽詢一位翻譯員，請撥電話 (855) 562-8853。"
                      data-placement="auto top"
                      data-toggle="popover"
                      data-trigger="focus"
                      lang="zh"
                      role="button"
                      tabindex="81"
                      data-original-title=""
                      title=""
                    >
                      繁體中文
                    </a>
                  </li>
                  <li>
                    <a
                      href="none"
                      onClick={(e) => {
                        e.preventDefault();
                      }}
                      class="lang-tooltip"
                      data-animation="true"
                      data-content="Nếu quý vị, hay người mà quý vị đang giúp đỡ, có câu hỏi về Sharp Health Plan, quý vị sẽ có quyền được giúp và có thêm thông tin bằng ngôn ngữ của mình miễn phí. Để nói chuyện với một thông dịch viên, xin gọi (855) 562-8853."
                      data-placement="auto top"
                      data-toggle="popover"
                      data-trigger="focus"
                      lang="vi"
                      role="button"
                      tabindex="82"
                      data-original-title=""
                      title=""
                    >
                      Tiếng Việt
                    </a>
                  </li>
                  <li>
                    <a
                      href="none"
                      onClick={(e) => {
                        e.preventDefault();
                      }}
                      class="lang-tooltip"
                      data-animation="true"
                      data-content="Kung ikaw, o ang iyong tinutulangan, ay may mga katanungan tungkol sa Sharp Health Plan, may karapatan ka na makakuha ng tulong at impormasyon sa iyong wika ng walang gastos. Upang makausap ang isang tagasalin, tumawag sa (855) 562-8853."
                      data-placement="auto top"
                      data-toggle="popover"
                      data-trigger="focus"
                      lang="tl"
                      role="button"
                      tabindex="83"
                      data-original-title=""
                      title=""
                    >
                      Tagalog
                    </a>
                  </li>
                </ul>
              </div>
              <div class="col-sm-3 language-blocks">
                <ul class="footer-list">
                  <li>
                    <a
                      href="none"
                      onClick={(e) => {
                        e.preventDefault();
                      }}
                      class="lang-tooltip"
                      data-animation="true"
                      data-content="만약 귀하 또는 귀하가 돕고 있는 어떤 사람이 Sharp Health Plan에 관해서 질문이 있다면 귀하는 그러한 도움과 정보를 귀하의 언어로 비용 부담없이 얻을 수 있는 권리가 있습니다. 그렇게 통역사와 얘기하기 위해서는 (855) 562-8853로 전화하십시오."
                      data-placement="auto top"
                      data-toggle="popover"
                      data-trigger="focus"
                      lang="ko"
                      role="button"
                      tabindex="84"
                      data-original-title=""
                      title=""
                    >
                      한국어
                    </a>
                  </li>
                  <li>
                    <a
                      href="none"
                      onClick={(e) => {
                        e.preventDefault();
                      }}
                      class="lang-tooltip"
                      data-animation="true"
                      data-content="Եթե Դուք կամ Ձեր կողմից օգնություն ստացող անձը հարցեր ունի Sharp Health Plan մասին, Դուք իրավունք ունեք անվճար օգնություն և տեղեկություններ ստանալու Ձեր նախընտրած լեզվով։ Թարգմանչի հետ խոսելու համար զանգահարե՛ք (855) 562-8853։"
                      data-placement="auto top"
                      data-toggle="popover"
                      data-trigger="focus"
                      lang="hy"
                      role="button"
                      tabindex="85"
                      data-original-title=""
                      title=""
                    >
                      հայերեն
                    </a>
                  </li>
                  <li>
                    <a
                      href="none"
                      onClick={(e) => {
                        e.preventDefault();
                      }}
                      class="lang-tooltip"
                      data-animation="true"
                      data-content="اگر شما، يا کسی کە شما بە او کمک ميکنيد ، سوال در مورد Sharp Health Plan ، داشتە باشيد حق اين را داريد کە کمک و اطلاعات بە زبان خود را بە طور رايگان دريافت نماييد (855) 562-8853. تماس حاصل نماييد ."
                      data-placement="auto top"
                      data-toggle="popover"
                      data-trigger="focus"
                      lang="fa"
                      role="button"
                      tabindex="86"
                      data-original-title=""
                      title=""
                    >
                      فارسی
                    </a>
                  </li>
                  <li>
                    <a
                      href="none"
                      onClick={(e) => {
                        e.preventDefault();
                      }}
                      class="lang-tooltip"
                      data-animation="true"
                      data-content="Если у вас или лица, которому вы помогаете, имеются вопросы по поводу Sharp Health Plan, то вы имеете право на бесплатное получение помощи и информации на вашем языке. Для разговора с переводчиком позвоните по телефону (855) 562-8853."
                      data-placement="auto top"
                      data-toggle="popover"
                      data-trigger="focus"
                      lang="ru"
                      role="button"
                      tabindex="87"
                      data-original-title=""
                      title=""
                    >
                      русский
                    </a>
                  </li>
                </ul>
              </div>
              <div class="col-sm-3 language-blocks">
                <ul class="footer-list">
                  <li>
                    <a
                      href="none"
                      onClick={(e) => {
                        e.preventDefault();
                      }}
                      class="lang-tooltip"
                      data-animation="true"
                      data-content="ご本人様、またはお客様の身の回りの方でも、Sharp Health Planについてご質問がございましたら、ご希望の言語でサポートを受けたり、情報を入手したりすることができます。料金はかかりません。通訳とお話される場合、(855) 562-8853までお電話ください。"
                      data-placement="auto top"
                      data-toggle="popover"
                      data-trigger="focus"
                      lang="ja"
                      role="button"
                      tabindex="88"
                      data-original-title=""
                      title=""
                    >
                      日本語
                    </a>
                  </li>
                  <li>
                    <a
                      href="none"
                      onClick={(e) => {
                        e.preventDefault();
                      }}
                      class="lang-tooltip"
                      data-animation="true"
                      data-content="إن كان لديك أو لدى شخص تساعده أسئلة بخصوص Sharp Health Plan ، فلديك الحق في الحصول على المساعدة والمعلومات الضرورية بلغتك من دون اية تكلفة. للتحدث مع مترجم اتصل ب ) (855) 562-8853."
                      data-placement="auto top"
                      data-toggle="popover"
                      data-trigger="focus"
                      lang="ar"
                      role="button"
                      tabindex="89"
                      data-original-title=""
                      title=""
                    >
                      العربية
                    </a>
                  </li>
                  <li>
                    <a
                      href="none"
                      onClick={(e) => {
                        e.preventDefault();
                      }}
                      class="lang-tooltip"
                      data-animation="true"
                      data-content="ਜੇ ਤੁਹਾਨੂੰ , ਜਾਂ ਤੁਸੀ ਜਿਸ ਦੀ ਮਦਦ ਕਰ ਰਹੇ ਹੋ , Sharp Health Plan ਕੋਈ ਸਵਾਲ ਹੈ ਤਾਂ, ਤੁਹਾਨੂੰ ਬਿਨਾ ਕਿਸੇ ਕੀਮਤ 'ਤੇ ਆਪਣੀ ਭਾਸ਼ਾ ਵਿੱਚ ਮਦਦ ਅਤੇ ਜਾਣਕਾਰੀ ਪ੍ਰਾਪਤ ਕਰਨ ਦਾ ਅਧਿਕਾਰ ਹੈ . ਦੁਭਾਸ਼ੀਏ ਨਾਲ ਗੱਲ ਕਰਨ ਲਈ, (855) 562-8853 ਤੇ ਕਾਲ ਕਰੋ ."
                      data-placement="auto top"
                      data-toggle="popover"
                      data-trigger="focus"
                      lang="pa"
                      role="button"
                      tabindex="90"
                      data-original-title=""
                      title=""
                    >
                      ਪੰਜਾਬੀ
                    </a>
                  </li>
                  <li>
                    <a
                      href="none"
                      onClick={(e) => {
                        e.preventDefault();
                      }}
                      class="lang-tooltip"
                      data-animation="true"
                      data-content="ប្រសិនបរើអ្នក ឬនរណាម្ននក់ដែលអ្នកកំពុងដែជួយ ម្ននសំណួរអ្ំពី Sharp Health Plan បេ, អ្នកម្ននសិេធិេេួលជំនួយនិងព័ែ៌ម្នន បៅកនុងភាសា ររស់អ្នក បោយមិនអ្ស់ប្ាក់ ។ បែើមបីនិយាយជាមួយអ្នករកដប្រ សូម (855) 562-8853 ។"
                      data-placement="auto top"
                      data-toggle="popover"
                      data-trigger="focus"
                      lang="km"
                      role="button"
                      tabindex="91"
                      data-original-title=""
                      title=""
                    >
                      មនខ្មែរ កម្ពុជា
                    </a>
                  </li>
                </ul>
              </div>
              <div class="col-sm-3 language-blocks">
                <ul class="footer-list">
                  <li>
                    <a
                      href="none"
                      onClick={(e) => {
                        e.preventDefault();
                      }}
                      class="lang-tooltip"
                      data-animation="true"
                      data-content="Yog koj, los yog tej tus neeg uas koj pab ntawd, muaj lus nug txog Sharp Health Plan, koj muaj cai kom lawv muab cov ntshiab lus qhia uas tau muab sau ua koj hom lus pub dawb rau koj. Yog koj xav nrog ib tug neeg txhais lus tham, hu rau (855) 562-8853."
                      data-placement="auto top"
                      data-toggle="popover"
                      data-trigger="focus"
                      role="button"
                      tabindex="92"
                      data-original-title=""
                      title=""
                    >
                      Hmong
                    </a>
                  </li>
                  <li>
                    <a
                      href="none"
                      onClick={(e) => {
                        e.preventDefault();
                      }}
                      class="lang-tooltip"
                      data-animation="true"
                      data-content="यदि आपके, या आप द्वारा सहायता किए जा रहे किसी व्यक्ति के Sharp Health Plan के बारे में प्रश्न हैं, तो आपके पास अपनी भाषा में मुफ्त में सहायता और सूचना प्राप्त करने का अधिकार है। किसी दुभाषिए से बात करने के लिए ,(855) 562-8853 पर कॉल करें।"
                      data-placement="auto top"
                      data-toggle="popover"
                      data-trigger="focus"
                      lang="hi"
                      role="button"
                      tabindex="93"
                      data-original-title=""
                      title=""
                    >
                      हिंदी
                    </a>
                  </li>
                  <li>
                    <a
                      href="none"
                      onClick={(e) => {
                        e.preventDefault();
                      }}
                      class="lang-tooltip"
                      data-animation="true"
                      data-content="หากคุณ หรือคนที่คุณกาลังช่วยเหลือมีคาถามเกี่ยวกับ Sharp Health Plan คุณมีสิทธิที่จะได้รับความช่วยเหลือและข้อมูลในภาษาของคุณได้โดยไม่มีค่าใช้จ่าย พูดคุยกับล่าม โทร (855) 562-8853"
                      data-placement="auto top"
                      data-toggle="popover"
                      data-trigger="focus"
                      lang="th"
                      role="button"
                      tabindex="94"
                      data-original-title=""
                      title=""
                    >
                      ไทย
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <div class="footer-lower-bottom">
          <div class="row footer-lower--help">
            <div class="col-md-6 footer-lower--help-privacy-policy">
              <a
                href="https://www.sharpmedicareadvantage.com/privacy-policy"
                class="lang-tooltip"
              >
                <Text id="footer.pp"/>
              </a>
              |
              <a
                href="https://www.sharpmedicareadvantage.com/terms-and-conditions-of-use-agreement"
                class="lang-tooltip"
              >
                <Text id="footer.terms"/>
              </a>
              |
              <a
                href="https://www.sharpmedicareadvantage.com/sitemap"
                class="lang-tooltip"
              >
                <Text id="footer.sitemap"/>
              </a>
              <p class="lang-tooltip">&copy;2016 Sharp Health Plan</p>
            </div>
            <div class="col-md-3 footer-lower--help-address">
              <p class="lang-tooltip">
                Sharp Health Plan
                <br />
                8520 Tech Way, Suite 201
                <br />
                San Diego, CA 92123
              </p>
            </div>
            <div class="col-md-3 medicare-note">
              <p class="lang-tooltip">
                <Text id="footer.need"/>? <br />
                <a
                  href="https://www.sharpmedicareadvantage.com/contact-us"
                  class="lang-tooltip"
                >
                  <Text id="footer.Cus" />
                </a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};
export default Footer1;
