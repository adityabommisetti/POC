import * as ActionTypes from "../ActionTypes";

const initialState = {
  guestLogin: false,
  preEnrollInfo: {},
  physicians: [{ label: "---Select---", value: "" }],
  authorizedrelations: [{ label: "---Select---", value: "" }],
  count: 0,
  year: "",
  selectedPlan: "",
  language:"",
};

export default function webAppReducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.LOGIN:
      return {
        ...state,
        guestLogin: false,
        selectedPlan: "",
      };

    case ActionTypes.GUEST_LOGIN:
      return {
        ...state,
        guestLogin: true,
        selectedPlan: "",
      };

    case ActionTypes.PRE_ENROLL_INFO:
      return {
        ...state,
        preEnrollInfo: action.payload.data,
      };

    case ActionTypes.SUBMIT_FORM:
      return {
        ...state,
        count: action.payload.data,
        preEnrollInfo: action.value,
      };

      case ActionTypes.YEAR_SELECTION:
        console.log(action.body.planYear)
      return {
        ...state,
        year: action.body.planYear,
      };

    case ActionTypes.PLAN_SELECTION_CONTINUE:
      return {
        ...state,
        selectedPlan: action.body.strPlanId,
        preEnrollInfo: action.payload.data.enrollmentVO
          ? action.payload.data.enrollmentVO
          : {},
        physicians: action.payload.data.physicians
          ? [
              ...initialState.physicians,
              ...Object.keys(action.payload.data.physicians).map((value, i) => {
                const label = Object.values(action.payload.data.physicians)[i];
                return { label: label, value: value };
              }),
            ]
          : initialState.physicians,
        authorizedrelations: action.payload.data.authorizedrelations
          ? [
              ...initialState.authorizedrelations,
              ...Object.keys(action.payload.data.authorizedrelations).map(
                (value, i) => {
                  const label = Object.values(
                    action.payload.data.authorizedrelations
                  )[i];
                  return { label: label, value: value };
                }
              ),
            ]
          : initialState.authorizedrelations,
      };
        case ActionTypes.REMOVEPLAN:{
         return{ 
           ...state,
          selectedPlan: "",
        }
      };
      case ActionTypes.SAVE_LANGUAGE:{
        return{ 
          ...state,
         language:action.payload,
       }
      }
    default:
      return state;
  }
}
