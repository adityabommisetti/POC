import { combineReducers } from "redux";
import webAppReducer from "./webAppReducer";
import spinnerReducer from "./SpinnerReducer";
const appReducer = combineReducers({
  webApp: webAppReducer,
  spinner: spinnerReducer,
});

const rootReducer = (state, action) => {
  return appReducer(state, action);
};

export default rootReducer;
