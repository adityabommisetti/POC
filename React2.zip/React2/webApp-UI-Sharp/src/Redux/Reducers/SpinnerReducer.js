const initialState = { isLoading: false };
const spinnerReducer = (state = initialState, action) => {
  switch (action.type) {
    case "SET_SPINNER":
      return {
        isLoading: action.payload,
      };
    default:
      return state;
  }
};
export default spinnerReducer;
