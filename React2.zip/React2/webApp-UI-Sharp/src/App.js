import React from "react";
import Router from "./Routers/Router";
import "./App.css";
import "./assests/css/spinner.css";
import { connect } from "react-redux";
import Header from "./components/Header";
import history from "./Utils/History";
import HeaderIndy from "./indy_components/Header";
import Footer from "./indy_components/Footer";
import logo from "../src/assests/images/IH-InsuranceCo-logo.png";
import {
  InternationalizationProvider,
  
} from "react-internationalization";
import * as languages from "./components/translations";
import {savelang} from "./Redux/Actions/webAppActions";
let set=1
const App = (props) => {
  // console.log(window.location.href.toString().includes("Sharp"));
  // console.log(window.location.href.indexOf("Sharp") > -1);
  let value = window.location.href.toString().indexOf("Sharp");
  let url=window.location.href
  let  num=window.location.href.toString().indexOf("lang");
  let val;

  if(num>-1){
        val=url.substring(num).substring(5) 
        sessionStorage.setItem("lang", val);
  }
  if(val){   
      props.savelang(val);
      set=0;
   }
   else if(!val && set){    
    let resl=sessionStorage.getItem("lang")
    if(resl){      
      props.savelang(resl)
      val=resl
    }else{
      props.savelang("en")
      val="en"
    }
   
  }

  return value > -1 ? (

    <InternationalizationProvider
      defaultLanguage={val}
      languages={languages}
      dynamicImports
    >
    
      <React.Fragment>
        <title> WebApp Sharp Health Plan</title>

        <div className="App">
          {props.isLoading ? <div id="cover-spin" /> : null}
          <Header />
         
          <Router  />
        </div>
      </React.Fragment>
    </InternationalizationProvider>
  ) : (
    <React.Fragment>
      <title> WebApp Indy Health Plan</title>
      {props.isLoading ? <div id="cover-spin" /> : null}
      <HeaderIndy />

      <Router />
      <Footer />
    </React.Fragment>
  );
};
const mapStateToProps = (state) => {
  return {
    isLoading: state.spinner.isLoading,
    lang:state.webApp.language
  };
};
const mapDispatchToProps = {
  savelang,
};
export default connect(mapStateToProps,mapDispatchToProps)(App);
