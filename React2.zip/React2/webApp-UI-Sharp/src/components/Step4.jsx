import React, { Component } from "react";
import { Text } from "react-internationalization";
export default class Step4 extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const { data,selectedPlan } = this.props;
    return (
      <React.Fragment>
         <div class="tab-content tab-contentSharp">
          <div id="step4" class="container tab-pane active">
            {/* <div id="step4" class="container tab-pane fade"> */}
            <h3 class="tab-heading"><Text id="step4.STEP4"/>: <Text id="step4.READ_SIGN"/></h3>
            <h4 class="mb-3 text-center">
              <Text id="step4.subHead"/>
            </h4>
            {selectedPlan === "SDAHMO1" ||
            selectedPlan ===  "SDAHMO20" ?
            <span>
            <p>
            <Text id="step4.subHead1"/>.
            </p>
            <p>
            <Text id="step4.Para1"/>.
            </p>
            <p>
            <Text id="step4.Para2"/>.
            </p>
            <p>
              <strong>
              <Text id="step4.Para3"/> 
                <br />
                <Text id="step4.Para4"/>:
              </strong>
            </p>
            <p>
            <Text id="step4.Para5"/>.
            </p>
            <p>
            <Text id="step4.Para6"/>.
            </p>
            <p>
            <Text id="step4.Para7"/>,
              <strong>
              <Text id="step4.Para8"/>.
              </strong>
            </p>
            <p>
            <Text id="step4.Para9"/>.
            </p>
            <p>
              <strong><Text id="step4.Para10"/>:</strong><Text id="step4.Para13"/>.
            </p>
            <p>
            <Text id="step4.Para12"/>.
            </p>
            </span>
            :
            <span>
             <p>
             <Text id="step4.Para14"/>.
            </p>
            <p>
            <Text id="step4.Para1"/>  .
            </p>
            <p>
            <Text id="step4.Para15"/>.
            </p>
            <p>
              <strong>
              <Text id="step4.READ_SIGN"/> 
                <br />
                <Text id="step4.subHead"/>:
              </strong>
            </p>
            <p>
            <Text id="step4.Para16"/>.
            </p>
            <p>
            <Text id="step4.Para17"/>.
            </p>
            <p>
            <Text id="step4.Para18"/>  ,
              <strong>
              <Text id="step4.Para19"/>.
              </strong>
            </p>
            <p>
            <Text id="step4.Para20"/>.
            </p>
            <p>
              <strong><Text id="step4.Para1"/>:</strong> <Text id="step4.Para11"/>.
            </p>
            <p>
             <Text id="step4.Para12"/>.
            </p></span>}

            <h4 class="mb-3 text-center">
              <Text id="step4.accept"/>
            </h4>
            <div class="row">
              <div class="col-xs-12 col-md-4 col-lg-4">
                <label class="control-label" for="nameSignature">
                  <Text id="step4.Name"/>*
                </label>
                <input
                  type="text"
                  class={
                    this.props.data.nameSignature === ""
                      ? "error-input"
                      : "form-control"
                  }
                  id="nameSignature"
                  name="nameSignature"
                  required=""
                  value={data.nameSignature}
                  onChange={this.props.handleChange}
                />
              </div>
              <div class="col-xs-12 col-md-4 col-lg-4">
                <label class="control-label" for="digitalSignature">
                  <Text id="step4.Digital"/>
                </label>
                <input
                  type="text"
                  class="form-control"
                  id="digitalSignature"
                  disabled="disabled"
                  name="digisignature"
                  value={data.nameSignature}
                />
              </div>
              <div class="col-xs-12 col-md-4 col-lg-4">
                <label class="control-label" for="todaysDate">
                  <Text id="step4.TodayDate"/>
                </label>
                <input
                  type="text"
                  class="form-control"
                  name="todaysDate"
                  id="todaysDate"
                  disabled="disabled"
                  value={data.nameSignature!==""?data.todaysDate:null}
                />
              </div>
            </div>
            <div class="row">
              <div class="col-xs-12 col-md-12 col-lg-12">
                <fieldset class="radio radio-tab mt-3" id="authorizedrep_radio">
                  <legend><Text id="step4.authorized"/> </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="AuthorizedRep"
                      id="authorizedRepresentative_Y"
                      class="custom-control-input"
                      value="Y"
                      onChange={this.props.handleChange}
                      checked={data.AuthorizedRep === "Y" ? true : false}
                    />
                    <label
                      for="authorizedRepresentative_Y"
                      class="radio-inline custom-control-label"
                    >
                      <Text id="app.Yes" />
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="AuthorizedRep"
                      id="authorizedRepresentative_no"
                      class="custom-control-input"
                      value="N"
                      onChange={this.props.handleChange}
                    />
                    <label
                      for="authorizedRepresentative_no"
                      class="radio-inline custom-control-label"
                      checked={data.AuthorizedRep === "N" ? true : false}
                    >
                      No
                    </label>
                  </div>
                </fieldset>
              </div>
            </div>

            <p style={{marginTop:"1.5rem"}}>
             <b> <Text id="step4.authorPart"/>:</b>
            </p>
            {data.AuthorizedRep === "Y" ? (
              <React.Fragment>
                <div class="row mt-3">
                  <div class="col-md-6">
                    <label class="control-label" for="authorizedrepname">
                      <Text id="app.Name"/>*
                    </label>
                    <input
                      type="text"
                      class={
                        this.props.data.authorizedrepname === ""
                          ? "error-input"
                          : "form-control"
                      }
                      name="authorizedrepname"
                      id="authorizedrepname"
                      required=""
                      value={data.authorizedrepname}
                      onChange={this.props.handleChange}
                    />
                  </div>
                  <div class="col-md-6">
                    <label
                      class="control-label"
                      for="authorizedreprelationship"
                    >
                      <Text id="step4.Enrollee"/>*
                    </label>
                    <select
                      name="authorizedreprelationship"
                      id="authorizedreprelationship"
                      class={
                        this.props.data.authorizedreprelationship === ""
                          ? "error-input"
                          : "form-control"
                      }
                      value={data.authorizedreprelationship}
                      onChange={this.props.handleChange}
                    >
                      {this.props.authorizedrelations.map((item, i) => {
                        return (
                          <option
                            class="select-option"
                            value={item.value}
                            key={i}
                          >
                            {item.label}
                          </option>
                        );
                      })}
                    </select>
                  </div>
                </div>
                <div class="row mt-3">
                  <div class="col-md-8">
                    <label class="control-label" for="authorizedRepAddr">
                      <Text id="step4.Address"/>*
                    </label>
                    <input
                      type="text"
                      class={
                        this.props.data.authorizedrepaddress === ""
                          ? "error-input"
                          : "form-control"
                      }
                      id="authorizedRepAddr"
                      name="authorizedrepaddress"
                      value={data.authorizedrepaddress}
                      onChange={this.props.handleChange}
                      required=""
                    />
                  </div>
                  <div class="col-md-4">
                    <label class="control-label" for="authorizedrepphone">
                      <Text id="step4.PhoneNumber"/>*
                    </label>
                    <input
                      type="text"
                      name="authorizedrepphone"
                      id="authorizedrepphone"
                      class={
                        this.props.data.authorizedrepphone === ""
                          ? "error-input"
                          : "form-control"
                      }
                      placeholder="(   )   -"
                      required=""
                      maxlength="14"
                      value={data.authorizedrepphone}
                      onChange={this.props.handleChange}
                    />
                  </div>
                </div>
              </React.Fragment>
            ) : null}
            <div class="row mt-3">
              <div class="col-xs-12 col-md-12 col-lg-12">
                <fieldset
                  class="radio radio-tab mt-3"
                  id="licensed_sales_representative_radio"
                >
                  <legend style={{fontWeight:"bold"}}>
                    <Text id="step4.Licensed"/>
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="AgentAssistingEnrollment"
                      id="licensedSalesRepresentative_Y"
                      class="custom-control-input"
                      value="Y"
                      onChange={this.props.handleChange}
                      checked={
                        data.AgentAssistingEnrollment === "Y" ? true : false
                      }
                    />
                    <label
                      for="licensedSalesRepresentative_Y"
                      class="radio-inline custom-control-label"
                    >
                      <Text id="app.Yes" />
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="AgentAssistingEnrollment"
                      id="licensedSalesRepresentative_no"
                      class="custom-control-input"
                      value="N"
                      onChange={this.props.handleChange}
                    />
                    <label
                      for="licensedSalesRepresentative_no"
                      class="radio-inline custom-control-label"
                    >
                      No
                    </label>
                  </div>
                </fieldset>
              </div>
            </div>
            {data.AgentAssistingEnrollment === "Y" ? (
              <React.Fragment>
                <div class="row">
                  <div class="col-md-6">
                    <label class="control-label" for="salesRepresentativeName">
                      <Text id="step4.sale"/>*
                    </label>
                    <input
                      type="text"
                      class={
                        this.props.data.nameAgent === ""
                          ? "error-input"
                          : "form-control"
                      }
                      name="nameAgent"
                      id="salesRepresentativeName"
                      required=""
                      onChange={this.props.handleChange}
                      value={data.nameAgent}
                    />
                  </div>
                  <div class="col-md-6">
                    <label
                      class="control-label"
                      for="salesRepresentativeLicenseNumber"
                    >
                      <Text id="step4.LicenseNo"/>
                    </label>
                    <input
                      type="text"
                      class="form-control"
                      name="agentLicense"
                      id="salesRepresentativeLicenseNumber"
                      required=""
                      onChange={this.props.handleChange}
                      value={data.agentLicense}
                    />
                  </div>
                </div>
              </React.Fragment>
            ) : null}

            <p class="mt-3">
              <strong><Text id="step4.NOTE"/>:</strong> <Text id="step4.notepart"/>.
            </p>
            <button
              class="btn btn-saveNext"
              id="next4"
              onClick={this.props.redirect}
              style={{backgroundColor:"#603167"}}
            >
              <Text id="app.Save_Next"/>
            </button>
          </div>
        </div>
      </React.Fragment>
    );
  }
}
