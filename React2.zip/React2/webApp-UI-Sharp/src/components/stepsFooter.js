import React from "react";
import { connect } from "react-redux";
import { Text } from "react-internationalization";
const StepsFooter = (props) => {
  return (
    <div class="non-discrimination-notice">
      <br />
     
      
      {props.year==="2020"?
      <div>
       
      <h3>NON-DISCRIMINATION NOTICE</h3>
     <p>
        Sharp Health Plan complies with applicable Federal civil rights laws and
        does not discriminate on the basis of race, color, national origin, age,
        disability, or sex. Sharp Health Plan does not exclude people or treat
        them differently because of race, color, national origin, age,
        disability, or sex.
      </p>
      <p class="mt-1">
        <strong>Sharp Health Plan:</strong>
      </p>
      <ul>
        <li>
          Provides free aids and services to people with disabilities to
          communicate effectively with us, such as:
          <ul>
            <li>Qualified sign language interpreters </li>
            <li>
              {" "}
              Written information in other formats (large print, audio,
              accessible electronic formats, other formats)
            </li>
          </ul>
        </li>
      </ul>
      <br />
      <ul>
        <li>
          Provides free language services to people whose primary language is
          not English, such as:
          <ul>
            <li>Qualified interpreters </li>
            <li> Information written in other languages</li>
          </ul>
        </li>
      </ul>
      <p>
        If you need these services, contact Customer Care at 1-855-562-8853.
      </p>
      <p>
        If you believe that Sharp Health Plan has failed to provide these
        services or discriminated in another way on the basis of race, color,
        national origin, age, disability, or sex, you can file a grievance with
        our Civil Rights Coordinator at:
      </p>
      <p>
        Address: Sharp Health Plan Appeal/Grievance Department{"\n"}
        8520 Tech Way, Suite 201{"\n"}
        San Diego, CA 92123-1450
      </p>
      <p>Telephone: 1-855-562-8853 (TTY/TDD:711) Fax:(858) 636-2256</p>
      <p>
        You can file a grievance in person or by mail, fax, or you can also
        complete the online Grievance/Appeal form on the Plan's website
        sharphealthplan.com. Please call our Customer Care team at
        1-855-562-8853 if you need help filing a grievance. You can also file a
        civil rights complaint with the U.S. Department of Health and Human
        Services, Office for Civil Rights electronically through the Office of
        Civil Rights Complaint Portal, available at
        https://ocrportal.hhs.gov/ocr/portal/lobby.jsf, or by mail or phone at:
        U.S. Department of Health and Human Services, 200 Independence Avenue
        SW., Room 509F, HHH Building, Washington, DC 20201, 1-800-368-1019,
        800-537-7697 (TDD).
      </p>
      <p>
        According to the Paperwork Reduction Act of 1995, no persons are
        required to respond to a collection of information unless it displays a
        valid OMB control number. The valid OMB control number for this
        information collection is 0938-NEW. The time required to complete this
        information is estimated to average 20 minutes per response, including
        the time to review instructions, search existing data resources, gather
        the data needed, and complete and review the information collection. If
        you have any comments concerning the accuracy of the time estimate(s) or
        suggestions for improving this form, please write to: CMS, 7500 Security
        Boulevard, Attn: PRA Reports Clearance Officer, Mail Stop C4-26-05,
        Baltimore, Maryland 21244-1850.
      </p>
      <p>
        Complaint forms are available at
        http://www.hhs.gov/ocr/office/file/index.html.
              </p> 
      <h4 class="mt-4">
        <strong>Multi-language Interpreter Services</strong>
      </h4>
      <p>
        <strong>English</strong> ATTENTION: If you do not speak English,
        language assistance services, free of charge, are available to you. Call
        1-855-562-8853 (TTY/TDD:711).
      </p>
      <p>
        <strong>Español(Spanish)</strong> ATENCIÓN: si habla español, tiene a su
        disposición servicios gratuitos de asistencia lingüística. Llame al
        1-855-562-8853 (TTY/TDD:711).
      </p>
      <p>
        <strong>繁體中文(Chinese)</strong> 注意 :
        如果您使用繁體中文，您可以免費獲得語言援助服務。請致電 1-855-562-8853
        (TTY/TDD:711).。
      </p>
      <p>
        <strong>Tiếng Việt(Vietnamese)</strong> CHÚ Ý: Nếu bạn nói Tiếng Việt,
        có các dịch vụ hỗ trợ ngôn ngữ miễn phí dành cho bạn. Gọi số
        1-855-562-8853 (TTY/TDD:711).
      </p>
      <p>
        <strong>Tagalog(Tagalog – Filipino)</strong> PAUNAWA: Kung nagsasalita
        ka ng Tagalog, maaari kang gumamit ng mga serbisyo ng tulong sa wika
        nang walang bayad. Tumawag sa 1-855-562-8853 (TTY/TDD:711).
      </p>
      <p>
        <strong>한국어 (Korean)</strong> 주의: 한국어를 사용하시는 경우, 언어
        지원 서비스를 무료로 이용하실 수 있습니다. 1-855-562-8853 (TTY/TDD:711)
        번으로 전화해 주십시오.
      </p>
      <p>
        <strong>Armenian:</strong> ՈՒՇԱԴՐՈՒԹՅՈՒՆ՝ Եթե խոսում եք հայերեն, ապա ձեզ
        անվճար կարող են տրամադրվել լեզվական աջակցության ծառայություններ:
        Զանգահարեք 1-855-562-8853 (TTY/TDD (հեռատիպ)՝ 711).
      </p>
      <p>
        <strong>فارسیPersian:</strong> توجه: اگر به زبان فارسی گفتگو می کنید،
        تسهیلات زبانی بصورت رایگان برای شما تماس بگیرید1-855-562-8853(TTY/TDD:
        .فراهم می باشد. با ( 711
      </p>
      <p>
        <strong>Русский(Russian)</strong> ВНИМАНИЕ: Если вы говорите на русском
        языке, то вам доступны бесплатные услуги перевода.Звоните 1-855-562-8853
        (телетайп: 711).
      </p>
      <p>
        <strong>日本語(Japanese)</strong>{" "}
        注意事項：日本語を話される場合、無料の言語支援をご利用いただけます。1-855-562-8853
        (TTY/TDD:711) まで、お電話にてご連絡ください。
      </p>
      <p>
        <strong>ةيبرعلا(Arabic):</strong>ملحوظة: إذا كنت تتحدث اذكر اللغة، فإن
        خدمات المساعدة اللغوية تتوافر لك بالمجان. اتصل برقم 1-8853-562-855)رقم
        هاتف الصم والبكم : 711
      </p>
      <p>
        <strong> ਪੰਜਾਬੀ (Punjabi)</strong> ਧਿਆਨ ਦਿਓ: ਜੇ ਤੁਸੀਂ ਪੰਜਾਬੀ ਬੋਲਦੇ ਹੋ,
        ਤਾਂ ਭਾਸ਼ਾ ਵਿੱਚ ਸਹਾਇਤਾ ਸੇਵਾ ਤੁਹਾਡੇ ਲਈ ਮੁਫਤ ਉਪਲਬਧ ਹੈ। 1-855-562-8853
        (TTY/TDD 711) ‘ਤੇ ਕਾਲ ਕਰੋ।
      </p>
      <p>
        <strong>ខ្មែរ(Mon-Khmer, Combodian):</strong> ប្រយ័ត្ន៖ បើសិនជាអ្នកនិយាយ
        ភាសាខ្មែរ, សេវាជំនួយផ្នែកភាសា ដោយមិនគិតឈ្នួល គឺអាចមានសំរាប់បំរើអ្នក។ ចូរ
        ទូរស័ព្ទ 1-855-562-8853 (TTY/TDD 711)
      </p>
      <p>
        <strong>Hmoob(Hmong):</strong> LUS CEEV: Yog tias koj hais lus Hmoob,
        cov kev pab txog lus, muaj kev pab dawb rau koj. Hu rau 1-855-562-8853
        (TTY/TDD 711).
      </p>
      <p>
        <strong>हिंदी(Hindi):</strong> ध्यान दें: यदि आप हिंदी बोलते हैं तो आपके
        लिए मुफ्त में भाषा सहायता सेवाएं उपलब्ध हैं। 1-855-562-8853
        (TTY/TDD:711) पर कॉल करें।
      </p>
      <p>
        <strong>ภาษาไทย(Thai):</strong> เรียน:
        ถ้าคุณพูดภาษาไทยคุณสามารถใช้บริการช่วยเหลือทางภาษาได้ฟรี โทร
        1-855-562-8853 (TTY/TDD 711).
        </p>
        </div>
        :null}

      <div class="row">
        {props.selectedPlan==="SDAHMO1"
        ?<div class="col-md-3"></div>:null}
        {/**/}
        <div class="col-md-8">
          <p class="mt-4">
            <Text id="app.foot1"/>.{" "}
            <u>
              <a href="https://www.sharpmedicareadvantage.com/sharp-advantage-disclaimer">
              <Text id="app.foot2"/>
              </a>
            </u>
            .
          </p>
          <p>H5386_{props.year}  <Text id="app.foot3"/></p>
          <p> <Text id="app.foot4"/>: 10/17/20</p>
        </div>
        <div class="col-md-3"></div>
      </div>
     
    </div>
  );
};


const mapStateToProps = (state) => {
  return {
    year: state.webApp.year,
    selectedPlan: state.webApp.selectedPlan,
  };
};


export default connect(
  mapStateToProps,
  null
)(StepsFooter);


