import React, { Component } from "react";
import html2pdf from "html2pdf.js";
import { Text } from "react-internationalization";
import "../assests/css/styles12.css";
import { connect } from "react-redux";
import axios from "../Utils/axios";
//import * as ActionTypes from "../ActionTypes";
import * as URL from "../Redux/API_URL";
import {
	uploadPDF,
	
  } from "../Redux/Actions/webAppActions";

class Form1 extends Component{
    constructor(props) {
        super()
	}
	

	async componentDidMount(){
 
		var element = document.getElementById('pdfbody');		
    var opt = {
      margin:       0.2,
      filename:     'myfile.pdf',
      image:        { type: 'jpeg', quality: 0.99 },
      html2canvas:  { scale: 2 },
      jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' }
	}; 
	
	//html2pdf().from(element).set(opt).save()
	
	// let blob = new Blob([html2pdf().from(element).set(opt)], {type: 'application/pdf'});
    // //let bloba = new Blob([view], { type: "application/pdf" });
    
    // console.log("value1 == "+blob);
 
    // var url = window.URL.createObjectURL(blob);
    //     if (navigator.msSaveBlob) {
    //       return navigator.msSaveOrOpenBlob(blob, "download.pdf");
    //     } else {
    //       window.open(
    //         url,
    //         "popUpWindow",
    //         "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=900" +
    //           ", height=900" +
    //           ", top=10" +
    //           ", left=10"
    //       );
    //     }
      
    html2pdf().from(element).set(opt).save()


	// var element = document.getElementById('element-to-print');
	// var formData = new FormData();
	

	
	
	

	html2pdf().from(element).outputPdf().then(async function(pdf) {
//Convert to base 64
	 const newpdf =btoa(pdf);

	 const formData = new FormData();
	 console.log(newpdf)
	 formData.append("pdfSave", newpdf);
	//  formData.append("appNumber", this.props.count)
	  console.log(formData)


	  axios.post(URL.PDF_UPLOAD, formData)
	  .then((response) => {
	console.log(response)
	  })
	  .catch((error) => {
		console.log(error)
	  })

	  
	//   await this.props.uploadPDF(formData);
	})  
    }
   
  
	
    
   /* toPdf() { 
		
		alert("child")   
		var element = document.getElementById('pdfbody');
		console.log(element)
    var opt = {
      margin:       0.2,
      filename:     'myfile.pdf',
      image:        { type: 'jpeg', quality: 0.99 },
      html2canvas:  { scale: 2 },
      jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' }
	}; 
	
	html2pdf().from(element).set(opt).save()
    // var file=html2pdf().from(element).set(opt)
    
    // file.save();
    
    
  }*/

render(){
	const 	{data}=this.props

 return(
        <>
        <div id="pdfbody">
      <table class="page">
			<tr>
				<td>
				 <img src={require("../assests/images/sharp-bnw-logo.png")} class="sharp-bnw-logo"/>
				</td>
			</tr>
			<tr>
				<td>
				 <h1 class="h1new"><Text id="pdf.head1"/><br/><Text id="pdf.subHead1"/> </h1>
				</td>
			</tr>
			<tr>
			<td>
				<table class="page1-table">
					<tr>
						<td>
							<h2><Text id="inst.i1"/></h2>
							<Text id="inst.i2"/>
							<strong><Text id="inst.i3"/></strong>
								<ul>
									<li><Text id="inst.i4"/></li>
									<li><Text id="inst.i5"/></li>
								</ul>
							<strong><Text id="inst.i6"/></strong> <Text id="inst.i7"/>:
							<ul>
								<li><Text id="inst.i8"/></li>
								<li><Text id="inst.i9"/></li>
							</ul>
							<h2><Text id="inst.i10"/></h2>
							<Text id="inst.i11"/>
							<ul>
								<li><Text id="inst.i12"/></li>
								<li><Text id="inst.i13"/></li>
								<li><Text id="inst.i14"/></li>
							</ul>
							<p>Visit Medicare.gov to learn more about when you
							can sign up for a plan.</p>
							<h2><Text id="inst.i18"/></h2>
							<ul>
								<li><Text id="inst.i19"/></li>
								<li><Text id="inst.i20"/></li>
							</ul>
							<p><strong><Text id="inst.i22"/></strong> <Text id="inst.i21"/></p>
						</td>
						<td>						
							<h2><Text id="inst.i15"/></h2>
							
								<ul>
								<li><Text id="inst.i16"/>.
								</li>
								<li><Text id="inst.i17"/>.
								</li>
								</ul>
                                <h2><Text id="inst.i29"/></h2>
							<p><Text id="pdf.pdfi1"/></p>
							<p><blockquote><Text id="pdf.pdfi2"/><br/>
							<Text id="pdf.pdfi3"/><br/>
							<Text id="pdf.pdfi4"/></blockquote></p>
							<p><Text id="pdf.pdfi5"/></p>
							<h2><Text id="pdf.pdfi6"/></h2>
							<p><Text id="pdf.pdfi7"/></p>
							<p><Text id="pdf.pdfi8"/>
							<Text id="pdf.pdfi9"/></p>
							<p>En español: Llame a Sharp Health Plan al
							1-855-562-8853 &nbsp;&nbsp;(TTY/TDD: 711) o a Medicare
							gratis al 1-800-633-4227 y oprima el 2 para
							asistencia en español y un representante estará
							disponible para asistirle.</p>
						</td>
					</tr>
				</table>
			</td>
		 </tr>
      </table>

      {/* <div class="html2pdf__page-break"></div> */}

      <div class="page">
			<table class="page2-table">
				<tr><td colspan="6" class="gray-bg strong"><Text id="pdf.Section1"/> </td></tr>
				<tr>
					<td colspan="6"><Text id="pdf.tojoin"/>:
						<ul class="list-style-none">
							
							<li><label class="radio_container"><input name="select-plan" type="radio"
							checked={this.props.selectedPlan === "SDAGC20" || this.props.selectedPlan === "SDAGCWD20" 
							|| this.props.selectedPlan === "SDAPC20"} />
							 <span class="checkmark"></span> <Text id="pdf.plan1"/></label></li>
							<li><label class="radio_container"><input name="select-plan" type="radio"
							 checked={this.props.selectedPlan === "SDAB20" || this.props.selectedPlan === "SDABWD20" 
							|| this.props.selectedPlan === "SDAP20" || this.props.selectedPlan === "SDAPWD20"}/> <span class="checkmark"></span> <Text id="pdf.plan2"/></label></li>
							<li><label class="radio_container"><input name="select-plan" type="radio" 
							checked={this.props.selectedPlan === "SDAHMO1" || this.props.selectedPlan === "SDAHMO20" 
							}/> <span class="checkmark"></span> <Text id="pdf.plan3"/></label></li>
						</ul>
					<Text id="pdf.head3"/>
					</td>
				</tr>
				<tr>					
					<td colspan="2"><Text id="app.Prefix"/>: <br/> <input type="text" class="prephone inputFieldnew" value={data.prefix}/></td>
                    </tr>
				<tr><td colspan="6">
						<span class="name-fields"><Text id="pdf.FirstName"/><br/><input type="text"
						 value={data.firstName} name="firstName"
						class="full-width inputFieldnew"  />
						</span>
						 <span class="name-fields"><Text id="pdf.LastName"/><br/><input type="text" 
						class="full-width inputFieldnew"  value={data.lastName} name="lastName"/></span>
						 <span class="name-fields"><Text id="pdf.Middle"/>:<br/><input type="text" class="full-width inputFieldnew" value={data.middleInitial}/></span>
				</td></tr>
				<tr>
					<td colspan="2"><Text id="pdf.DOB"/> <br/> <input type="text" name="birthDate" value={data.birthDate} class="inputFieldnew"/> </td>
					<td><Text id="pdf.Sex"/> <br/><label class="radio_container label-gap"><input type="radio" name="sex"  checked={data.sex === "M"} /> <span class="checkmark"></span><Text id="app.Male"/></label> <label class="radio_container"><input type="radio" name="sex" checked={data.sex === "F"}/> <span class="checkmark"></span> <Text id="app.Female"/></label></td>
					<td colspan="2"><Text id="app.phno"/>: <br/><input type="text" class="width75per inputFieldnew"    value={data.primaryPhone}/></td>
					<td colspan="2"><Text id="app.MI"/> <br/> <input type="text" class="inputFieldnew"  /> </td>
                    </tr>
				<tr><td colspan="6"><Text id="app.PermanentAddress"/>(<Text id="app.POBox"/>): <br/><input type="text" class="full-width inputFieldnew"  value={data.permanentAddrStreet}/></td></tr>
				<tr><td colspan="2"><Text id="app.City"/>:<br/> <input type="text" class="full-width inputFieldnew"  value={data.permanentCity} /></td><td><Text id="app.County"/>:<br/> <input type="text" value={data.permanentCounty} class="full-width inputFieldnew"/></td><td><Text id="app.State"/>:<br/> <input type="text"   value="CA" class="full-width inputFieldnew"/></td><td colspan="2"><Text id="app.ZIPCode"/>:<br/> <input type="text" class="full-width inputFieldnew"  value={data.permanentZip}/></td></tr>
				{/* <tr><td colspan="6"><Text id="app.maillingAdd"/>:<br/>
				<Text id="pdf.Streetaddress"/>: <input type="text" class="width85per" value={data.mailingAddr}/>
				</td></tr>
				<tr><td colspan="3"><Text id="app.City"/><br/> <input type="text" class="full-width"  value={data.mailingCity}/></td><td><Text id="app.State"/>:<br/> <input type="text" class="full-width"  value={data.state}/></td><td colspan="2"><Text id="app.ZIPCode"/>:<br/> <input type="text" class="full-width" value={data.mailingzip}/></td></tr> */}
				<tr><td colspan="6" class="gray-bg strong"><Text id="pdf.MediInfo"/>:</td></tr>
				<tr><td colspan="6"><Text id="app.MedicareNo"/>: <input type="text" value={data.medicareClaim} class="inputFieldnew"/> </td></tr>
				<tr><td colspan="6" class="gray-bg strong"><Text id="pdf.label1"/>:</td></tr>
				<tr><td colspan="6"><Text id="pdf.label2"/><br/><label class="radio_container label-gap"><input type="radio" name="yes_no"/> <span class="checkmark" checked={data.vaBenefits === "Y"}></span> Yes</label> <label class="radio_container"><input type="radio" name="yes_no" checked={data.vaBenefits === "N"}/> <span class="checkmark"></span> No</label>
				<br/><br/>
				<span class="name-fields"><Text id="app.coverage"/>:<br/><input type="text" class="full-width inputFieldnew" value={data.nameOfCov}/></span> <span class="name-fields"><Text id="app.mebernumber"/>:<br/><input type="text" class="full-width inputFieldnew" value={data.idOfCov}/></span> <span class="name-fields"><Text id="app.groupNo"/>:<br/><input type="text" class="full-width inputFieldnew" value={data.groupOfCov}/></span>
				
				</td></tr>
			</table>
			<div class="html2pdf__page-break"></div>
	
	  </div>

     

      <div class="page">
			<table class="page2-table">
			<tr><td colspan="6" class="gray-bg strong"><Text id="app.imp"/>: <Text id="app.impsub"/>:</td></tr>
			<tr>
				<td colspan="6">
				<Text id="app.imp1"/>.
				<ul>
					<li><Text id="app.imp2"/>.</li>
					<li><Text id="app.imp3"/>.</li>
					<li><Text id="app.imp4"/>.</li>
					<li><Text id="app.imp6"/>.</li>
					<li><Text id="app.imp7"/>.</li>					
				</ul>
				</td>
			</tr>
			<tr>
				<td colspan="4" width="60%"><strong><Text id="pdf.Signature"/>:</strong><br/>X <input type="text" class="width95per inputFieldnew" value={data.nameSignature}/> </td>
				<td colspan="2" width="40%"><strong><Text id="pdf.date"/>:</strong> <br/><input type="text" class="full-width inputFieldnew" value={data.todaysDate}/></td>
			</tr>
			<tr>
				<td colspan="6" class="gray-bg"><Text id="pdf.auth"/>:<br/>
				<label class="radio_container label-gap"><input type="radio" name="yes_no"/> <span class="checkmark" checked={data.AuthorizedRep === "Y"}></span> Yes</label> <label class="radio_container"><input type="radio" name="yes_no" checked={data.AuthorizedRep === "N"}/> <span class="checkmark"></span> No</label></td>
			</tr>
			<tr>
				<td colspan="3" width="50%"><Text id="app.Name"/>: <input type="text" class="width85per inputFieldnew" value={data.authorizedrepname}/> </td>
				<td colspan="3" width="50%"><Text id="app.address"/>: <input type="text" class="width80per inputFieldnew" value={data.authorizedrepaddress}/></td>
			</tr>
			<tr>
				<td colspan="3" width="50%"><Text id="app.phno"/>:  <input type="text" class="width50per inputFieldnew" value={data.authorizedrepphone}/> </td>
				<td colspan="3" width="50%"><Text id="app.Enrollee"/>: <input type="text" class="width50per inputFieldnew"value={data.authorizedreprelationship}/></td>
			</tr>
			<tr>
				<td colspan="6" class="gray-bg"><Text id="app.License"/>:<br/>
				<label class="radio_container label-gap"><input type="radio" name="yes_no"/> <span class="checkmark" ></span> Yes</label> <label class="radio_container"><input type="radio" name="yes_no" /> <span class="checkmark"></span> No</label></td>
			</tr>
			<tr>
				<td colspan="3" width="50%"><Text id="app.sale"/>: <input type="text" class="width50per inputFieldnew" /> </td>
				<td colspan="3" width="50%"><Text id="app.Licenseno"/>: <input type="text" class="width50per inputFieldnew"/></td>
			</tr>
		</table>
				
      </div>

      <div class="html2pdf__page-break"></div>
	  <br/>
	  <br/>

      <div class="page">		
			<table class="page2-table">
				<tr><td colspan="6" class="gray-bg strong"><Text id="pdf.Section"/> 2 – <Text id="step2.subStep"/></td></tr>
				<tr>
					<td colspan="6">
					<Text id="step2.A"/>.
					</td>
				</tr>
				<tr>
					<td colspan="6">
					<Text id="step2.A1"/>.
					<label class="radio_container label-gap"><input type="checkbox" checked={data.language === "SPANISH"}/> <span class="checkmark" ></span> <Text id="step2.Spanish"/></label>
					</td>
				</tr>
				<tr>
					<td colspan="6">
					<Text id="step2.A2"/>.<br/>
					<label class="radio_container label-gap"><input type="radio" name="format" checked={data.language === "BRAILLE"}/> <span class="checkmark"></span> Braille</label> 
					<label class="radio_container label-gap"><input type="radio" name="format" checked={data.language === "LARGE_PRINT"}/> <span class="checkmark"></span> Large print</label>
					<label class="radio_container"><input type="radio" name="format" checked={data.language === "AUDIO_CD"}/> <span class="checkmark"></span> Audio CD</label>
					<br/>
					<p><Text id="step2.Para1"/>1-855-562-8853<Text id="step2.Para2"/></p>
					</td>
				</tr>
				<tr>
					<td colspan="6">
						<Text id="pdf.Physician"/>:<br/>
						<input type="text" class="full-width inputFieldnew" value={data.pcpName}/>
					</td>
				</tr>
				<tr>
				<td colspan="2" width="33%"><Text id="step2.currentpatient"/><br/>
						<label class="radio_container label-gap"><input type="radio" name="currentpatient" /> <span class="checkmark"></span> Yes</label> 
						<label class="radio_container"><input type="radio" name="currentpatient" /> <span class="checkmark"></span> No</label>
					</td>
					<td colspan="2" width="33%"><Text id="step2.Dowork"/> <br/>
						<label class="radio_container label-gap"><input type="radio" name="doyouwork" checked={data.youwork === "Y"}/> <span class="checkmark"></span> Yes</label> <label class="radio_container"><input type="radio" name="doyouwork" checked={data.youwork === "N"}/> <span class="checkmark"></span> No</label>
					</td>
					<td colspan="2" width="33%"><Text id="step2.spousework"/><br/>
						<label class="radio_container label-gap"><input type="radio" name="doesyourspousework" checked={data.spousework === "Y"}/> <span class="checkmark"></span> Yes</label> 
						<label class="radio_container"><input type="radio" name="doesyourspousework" checked={data.spousework === "N"}/> <span class="checkmark"></span> No</label>
					</td>
					
				</tr>
				<tr>
					<td colspan="6">
						<Text id="step2.Email"/><br/>
						<input type="text" class="full-width inputFieldnew" value={data.emailAddr}/>
					
						
					</td>
					</tr>
				
				<tr>
					<td colspan="6">
						<p><h3><Text id="step2.Para3"/></h3></p>
						<p><Text id="step2.Para4"/>.<Text id="step2.Para"/>.</p>
						<p><strong><Text id="step2.Para6"/>.</strong></p>
					</td>
				</tr>
			</table>
      </div>

      <div class="html2pdf__page-break"></div>

      <div class="page">
		<table class="page2-table">
			<tr><td class="gray-bg strong"><Text id="step3.Exhibit1a"/>: <Text id="step3.stepsub"/></td></tr>
			<tr>
				<td>
				<p><strong><Text id="step3.Para1"/>.</strong> <Text id="step3.Para2"/>.</p>
				<p><Text id="step3.Para3"/></p>
				<ul class="list-style-none">
				<li><label class="radio_container"><input type="checkbox" checked={data.aep === "AEP"}/> <span class="checkmark"></span> <Text id="step3.Op1"/>. <Text id="step3.Op1sub"/></label></li>
					<li><label class="radio_container"><input type="checkbox" checked={data.c1 === "NEW"}/> <span class="checkmark"></span> <Text id="step3.Op2"/>.</label></li>
			    	<li><label class="radio_container margin-bottom0"><input type="checkbox" checked={data.c2 === "MOV"}/> <span class="checkmark"></span> <Text id="step3.Op3"/>. <Text id="step3.movedate"/></label><br/><input type="text" class="addon-field inputFieldnew" value={data.attestation2}/></li>				
					<li><label class="radio_container margin-bottom0"><input type="checkbox" checked={data.c3 === "INC"} /> <span class="checkmark"></span> <Text id="step3.Op4"/>. <Text id="step3.releasedate"/></label><input type="text" class="addon-field inputFieldnew" value={data.attestation3}/></li>
					<li><label class="radio_container margin-bottom0"><input type="checkbox" checked={data.c4 === "RUS"}/> <span class="checkmark" ></span> <Text id="step3.Op5"/>. <Text id="step3.returndate"/></label> <input type="text" class="addon-field inputFieldnew" value={data.attestation4}/></li>
					<li><label class="radio_container margin-bottom0"><input type="checkbox" checked={data.c5 === "LAW"}/> <span class="checkmark" ></span> <Text id="step3.Op6"/>. <Text id="step3.statusdate"/></label> <input type="text" class="addon-field inputFieldnew" value={data.attestation5}/></li>
					<li><label class="radio_container"><input type="checkbox"/> <span class="checkmark" checked={data.c6 === "MDE" }></span> <Text id="step3.Op7"/>.</label></li>
					<li><label class="radio_container margin-bottom0"><input type="checkbox" checked={data.c7 === "HLP"}/> <span class="checkmark" ></span> <Text id="step3.Op8"/>. <Text id="step3.facilitydate"/></label> <input  type="text" class="addon-field inputFieldnew"/></li>
					<li><label class="radio_container"><input type="checkbox" checked={data.c8 === "NLS"}/> <span class="checkmark"></span> <Text id="step3.Op9"/>. <Text id="step3.extrahelp"/></label> <input type="text" class="addon-field inputFieldnew" value={data.attestation8}/></li>

					<div class="html2pdf__page-break"></div><br/><br/>
					<li><label class="radio_container"><input type="checkbox"  checked={data.c10 === "LTC"}/> <span class="checkmark" ></span> <Text id="step3.Op10"/>. <Text id="step3.facilitydate"/></label> <input value={data.attestation9} type="text" class="addon-field inputFieldnew"/></li>
					<li><label class="radio_container"><input type="checkbox"  checked={data.c10 === "PAC"}/> <span class="checkmark" ></span> <Text id="step3.Op11"/>. <Text id="step3.pacedate"/></label> <input value={data.attestation10} type="text" class="addon-field inputFieldnew"/></li>
					<li><label class="radio_container"><input type="checkbox" checked={data.c11 === "LCC"}/> <span class="checkmark" ></span> <Text id="step3.Op12"/>. <Text id="step3.drugdate"/></label> <input value={data.attestation11} type="text" class="addon-field inputFieldnew"/></li>
					<li><label class="radio_container"><input type="checkbox" checked={data.c12 === "LEC"}/> <span class="checkmark"></span> <Text id="step3.Op13"/>. <Text id="step3.leavingdate"/></label> <input value={data.attestation12} type="text" class="addon-field inputFieldnew"/></li>
					<li><label class="radio_container"><input type="checkbox" checked={data.c13 === "PAP"}/> <span class="checkmark"></span> <Text id="step3.Op14"/>.</label></li>
					<li><label class="radio_container"><input type="checkbox" checked={data.c13 === "EOC"}/> <span class="checkmark"></span> <Text id="step3.Op15"/>.</label></li>
					<li><label class="radio_container"><input type="checkbox" checked={data.c15 === "SNP"}/> <span class="checkmark"></span> <Text id="step3.Op16"/>. <Text id="step3.SNPdate"/></label> <input type="text" class="addon-field inputFieldnew" value={data.attestation15}/></li>
					<li><label class="radio_container margin-bottom0"><input type="checkbox" checked={data.c22 === "MCD"}/> <span class="checkmark" ></span> <Text id="step3.Op17"/>. <Text id="step3.disrolldate"/></label> <input type="text" value={data.recentlyChangeMedicaid} class="addon-field inputFieldnew" /></li>
					<li><label class="radio_container margin-bottom0"><input type="checkbox" checked={data.c23 === "HLP"}/> <span class="checkmark" ></span> <Text id="step3.Op18"/>. <Text id="step3.insertdate"/> </label> <input type="text" value={data.attestation23} class="addon-field inputFieldnew"/></li>
					<li><label class="radio_container"><input type="checkbox" checked={data.c25 === "DST"}/> <span class="checkmark"></span> <Text id="step3.Op19"/>. </label></li>
				</ul>
				<p><Text id="step3.Para4"/>
					</p>
				</td>
			</tr>
		</table>
	  </div>
	 
	  <div class="page">

	  </div>


     
	 </div>
	 
	
        </>
    )
}
}
const mapStateToProps = (state) => {
	return {
	  count: state.webApp.count,
	  year: state.webApp.year,
	  selectedPlan: state.webApp.selectedPlan,
	  preEnrollInfo: state.webApp.preEnrollInfo,
	};
  };
  const mapDispatchToProps = {
	  uploadPDF
  };
  
  export default connect(mapStateToProps, mapDispatchToProps)(Form1);