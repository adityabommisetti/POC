import React, { Component } from "react";
import { Text } from "react-internationalization";

export default class Header extends Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    render() {
        return (
            <div className="card">
                <h3 className="card-header block-heading"><a className="card-link collapsed" data-toggle="collapse" data-target="#Instructions"><Text id="inst.head"/></a></h3>
                <div className="panel-collapse collapse" id="Instructions">
                    <div className="card-body">
                        <p><Text id="inst.i23"/>.</p>
                        <p> {/* <strong><Text id="inst.i24"/></strong>:<br /> */}
                         <Text id="inst.i25"/>.</p>
                        <div className="row mt-4">
                            <div className="col-6">
                                <div className="box-item">
                                    <h4><Text id="inst.i1"/></h4>
                                    <p><Text id="inst.i2"/></p>
                                    <p><strong><Text id="inst.i3"/></strong></p>
                                    <ul>
                                        <li><Text id="inst.i4"/></li>
                                        <li><Text id="inst.i5"/></li>
                                    </ul>
                                    <p><strong><Text id="inst.i6"/></strong> <Text id="inst.i7"/></p>
                                    <ul>
                                        <li><Text id="inst.i8"/></li>
                                        <li><Text id="inst.i9"/></li>
                                    </ul>
                                </div>
                                <div className="box-item mt-4">
                                    <h4><Text id="inst.i10"/></h4>
                                    <p><Text id="inst.i11"/></p>
                                    <ul>
                                        <li><Text id="inst.i12"/></li>
                                        <li><Text id="inst.i13"/></li>
                                        <li><Text id="inst.i14"/></li>
                                    </ul>
                                </div>
                                <div className="box-item mt-4">
                                    <h4><Text id="inst.i26"/></h4>
                                    <p><Text id="inst.i27"/>.
                                    <Text id="inst.i28"/>.</p>
                                    <p><strong>En español</strong>: Llame a Sharp Health Plan al 1-855-562-8853, TTY 711 o a Medicare gratis al 1-800-633-4227 y oprima el 2 para asistencia en español y un representante estará disponible para asistirle.</p>
                                </div>
                            </div>

                            <div className="col-6">
                                <div className="box-item">
                                    <h4><Text id="inst.i15"/></h4>
                                    <ul>
                                        <li><Text id="inst.i16"/></li>
                                        <li><Text id="inst.i17"/></li>
                                    </ul>
                                </div>
                                <div className="box-item mt-4">
                                    <h4><Text id="inst.i29"/></h4>
                                    <ul>
                                        <li><Text id="inst.i30"/>.</li>
                                        <li><Text id="inst.i31"/>.</li>
                                    </ul>
                                    <p><Text id="inst.i32"/>.</p>
                                </div>
                                <div className="box-item mt-4">
                                    <h4><Text id="inst.i18"/> </h4>
                                    <ul>
                                        <li><Text id="inst.i19"/>
                                        <br />
                                            <img
                                                src={require("../assests/images/Medicardlogoshp_New.png")}
                                                alt=""
                                                class="width100per"
                                            />
                                        </li>
                                        <li><Text id="inst.i20"/> </li>
                                    </ul>
                                    <p><strong><Text id="inst.i22"/></strong>: <Text id="inst.i21"/></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
