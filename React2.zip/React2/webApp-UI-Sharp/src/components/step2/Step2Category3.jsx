import React from "react";
import moment from "moment";
import { Text } from "react-internationalization";
const Step2 = (props) => {
  const { data } = props;
  return (
    <React.Fragment>
       <div class="tab-content tab-contentSharp">
        <div id="step2" class="container tab-pane active">
          <h3 class="tab-heading"><Text id="st2cat3.STEP2"/>: <Text id="st2cat3.MEDICAREINFOR"/></h3>
          <p class="medicare-note">
          <Text id="st2cat3.info"/> 
            <br />
            <strong> <Text id="st2cat3.Note"/>: </strong> <Text id="st2cat3.notePart"/> 
          </p>

          <h4 class="sub-heading">
            <strong>
            <Text id="st2cat3.A"/> 
            </strong>
          </h4>
          <div class="form-group row">
            <div class="col-md-6">
              <p>
                <label for="medicareClaim" class="control-label">
                <Text id="st2cat3.MedicareNumber"/>*
                </label>
                <input
                  type="text"
                  placeholder="XXXXXXXXXXX"
                  pattern="/[a-zA-Z0-9]{10,11}/"
                  name="medicareClaim"
                  id="medicareClaim"
                  maxlength="12"
                  class={
                    data.medicareClaim.length < 10
                      ? "error-input"
                      : "form-control"
                  }
                  value={data.medicareClaim}
                  onChange={props.handleChange}
                  required=""
                />
              </p>

              <p>
                <label class="control-label" for="hospitalPartA">
                <Text id="st2cat3.HospitalDate"/>*
                </label>
                <input
                  placeholder="MM/DD/YYYY "
                  maxLength="10"
                  class={
                    data.hospitalPartA === "" ||
                    !moment(data.hospitalPartA, "MM/DD/YYYY", true).isValid()
                      ? "error-input"
                      : "form-control"
                  }
                  name="hospitalPartA"
                  id="hospitalPartA"
                  value={data.hospitalPartA}
                  onChange={props.handleDate}
                  required=""
                  onClick={(e) => props.handleDates("hospitalPartA")}
                />
              </p>

              <p>
                <label class="control-label" for="hospitalPartB">
                 <Text id="st2cat3.Medical"/>*
                </label>
                <input
                  placeholder="MM/DD/YYYY"
                  maxLength="10"
                  class={
                    data.hospitalPartB === "" ||
                    !moment(data.hospitalPartB, "MM/DD/YYYY", true).isValid()
                      ? "error-input"
                      : "form-control"
                  }
                  name="hospitalPartB"
                  id="hospitalPartB"
                  value={data.hospitalPartB}
                  onChange={props.handleDate}
                  required=""
                  onClick={(e) => props.handleDates("hospitalPartB")}
                />
              </p>
            </div>
            <div class="col-md-6">
              <img
                src={require("../../assests/images/Medicardlogoshp_New.png")}
                alt=""
                class="width100per"
              />
            </div>
          </div>

          <h4 class="sub-heading">
            <strong>
            <Text id="st2cat3.B"/>:
            </strong>
          </h4>
          <div class="form-group">
            <ol>
              <li>
                <fieldset class="radio radio-tab ml-3 mt-3">
                  <legend style={{ marginTop: "-2.5rem" }}>
                  <Text id="st2cat3.q1"/>*
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="meddependsp"
                      id="meddependspY"
                      class="custom-control-input"
                      value="Y"
                      checked={data.meddependsp === "Y"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="meddependspY"
                      class="radio-inline custom-control-label"
                    >
                      <Text id="app.Yes"/> 
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="meddependsp"
                      id="meddependspno"
                      class="custom-control-input"
                      value="N"
                      checked={data.meddependsp === "N"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="meddependspno"
                      class="radio-inline custom-control-label"
                    >
                      No
                    </label>
                  </div>
               
                {data.meddependsp === "Y" ? (
                  <div class="row">
                    <div class="col-4">
                      <label for="retiredate">If Yes, name of spouse:</label>
                      <input
                        type="text"
                        name="dependentSpouse"
                        id="dependentSpouse"
                        class="form-control"
                        value={data.dependentSpouse}
                        onChange={props.handleChange}
                      />
                    </div>
                    <div class="col-2"></div>
                    <div class="col-4">
                      <label for="retirename">Name(s) of dependents(s):</label>{" "}
                      <input
                        type="text"
                        name="dependentOther"
                        class="form-control"
                        value={data.dependentOther}
                        onChange={props.handleChange}
                      />
                    </div>
                  </div>
                ) : null}
                 </fieldset>
              </li>
              <li>
                <fieldset class="radio radio-tab ml-3 mt-3">
                  <legend style={{ marginTop: "-2.5rem" }}>
                  <Text id="st2cat3.q2"/>*
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="spousework"
                      id="c_q5_Y"
                      class="custom-control-input"
                      value="Y"
                      checked={data.spousework === "Y"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="c_q5_Y"
                      class="radio-inline custom-control-label"
                    >
                      <Text id="app.Yes"/> 
                      
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="spousework"
                      id="c_q5_no"
                      class="custom-control-input"
                      value="N"
                      checked={data.spousework === "N"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="c_q5_no"
                      class="radio-inline custom-control-label"
                    >
                      No
                    </label>
                  </div>
                </fieldset>
              </li>
              <li>
                <fieldset class="radio radio-tab ml-3 mt-3">
                  <legend style={{ marginTop: "-2.5rem" }}>
                  <Text id="st2cat3.q3"/>*
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="renalDisease"
                      id="c_q1_Y"
                      class="custom-control-input"
                      value="Y"
                      checked={data.renalDisease === "Y"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="c_q1_Y"
                      class="radio-inline custom-control-label"
                    >
                      <Text id="app.Yes"/> 
                      
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="renalDisease"
                      id="c_q1_no"
                      class="custom-control-input"
                      value="N"
                      checked={data.renalDisease === "N"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="c_q1_no"
                      class="radio-inline custom-control-label"
                    >
                      No
                    </label>
                  </div>
                  {data.renalDisease === "Y" ? (
                    <div>
                      <legend>
                        Have you had a successful kidney transplant and/or you
                        don't need regular dialysis any more?*
                      </legend>
                      If Yes, a Licensed Sales Representative may need to
                      contact you to obtain additional information.
                      <br></br>
                      <div class="custom-control custom-radio custom-control-inline">
                        <input
                          type="radio"
                          name="esrdcontact"
                          id="esrdcontact_Y"
                          class="custom-control-input"
                          value="Y"
                          checked={data.esrdcontact === "Y"}
                          onChange={props.handleChange}
                        />
                        <label
                          for="esrdcontact_Y"
                          class="radio-inline custom-control-label"
                        >
                      <Text id="app.Yes"/> 
                          
                        </label>
                      </div>
                      <div class="custom-control custom-radio custom-control-inline">
                        <input
                          type="radio"
                          name="esrdcontact"
                          id="esrdcontact_no"
                          class="custom-control-input"
                          value="N"
                          checked={data.esrdcontact === "N"}
                          onChange={props.handleChange}
                        />
                        <label
                          for="esrdcontact_no"
                          class="radio-inline custom-control-label"
                        >
                          No
                        </label>
                      </div>
                    </div>
                  ) : null}
                </fieldset>
              </li>
              <li>
                <fieldset class="radio radio-tab ml-3 mt-3" id="c_qns2">
                  <legend style={{ marginTop: "-2.5rem" }}>
                  <Text id="st2cat3.q4"/>*
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="vaBenefits"
                      id="c_q2_Y"
                      class="custom-control-input"
                      value="Y"
                      checked={data.vaBenefits === "Y"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="c_q2_Y"
                      class="radio-inline custom-control-label"
                    >
                      <Text id="app.Yes"/> 
                      
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="vaBenefits"
                      id="c_q2_no"
                      class="custom-control-input"
                      value="N"
                      checked={data.vaBenefits === "N"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="c_q2_no"
                      class="radio-inline custom-control-label"
                    >
                      No
                    </label>
                  </div>
                
                {data.vaBenefits === "Y" ? (
                  <div id="c_q2_fields">
                    <div class="row mt-3 ml-1">
                      <div class="col-md-4">
                        <label for="nameOfCov" class="control-label">
                          Name of other coverage*
                        </label>
                        <input
                          type="text"
                          class={
                            data.nameOfCov === ""
                              ? "error-input"
                              : "form-control"
                          }
                          id="nameOfCov"
                          name="nameOfCov"
                          value={data.nameOfCov}
                          onChange={props.handleChange}
                        />
                      </div>
                      <div class="col-md-4">
                        <label for="idOfCov" class="control-label">
                          ID# of this coverage*
                        </label>
                        <input
                          type="text"
                          class={
                            data.idOfCov === "" ? "error-input" : "form-control"
                          }
                          id="idOfCov"
                          name="idOfCov"
                          value={data.idOfCov}
                          onChange={props.handleChange}
                        />
                      </div>
                      <div class="col-md-4">
                        <label for="groupOfCov" class="control-label">
                          Group# for this coverage*
                        </label>
                        <input
                          type="text"
                          class={
                            data.groupOfCov === ""
                              ? "error-input"
                              : "form-control"
                          }
                          id="groupOfCov"
                          name="groupOfCov"
                          value={data.groupOfCov}
                          onChange={props.handleChange}
                        />
                      </div>
                    </div>
                  </div>
                ) : null}
                </fieldset>
              </li>
              <li>
                <fieldset class="radio radio-tab ml-3 mt-3" id="c_qns4">
                  <legend style={{ marginTop: "-2.5rem" }}>
                  <Text id="st2cat3.q5"/>*
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="prescriptionDrug"
                      id="c_q4_Y"
                      class="custom-control-input"
                      value="Y"
                      checked={data.prescriptionDrug === "Y"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="c_q4_Y"
                      class="radio-inline custom-control-label"
                    >
                      <Text id="app.Yes"/> 
                     
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="prescriptionDrug"
                      id="c_q4_no"
                      class="custom-control-input"
                      value="N"
                      checked={data.prescriptionDrug === "N"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="c_q4_no"
                      class="radio-inline custom-control-label"
                    >
                      No
                    </label>
                  </div>
                
                {data.prescriptionDrug === "Y" ? (
                  <div id="c_q4_fields">
                    <div class="row mt-3 ml-1">
                      <div class="col-md-7">
                        <label for="nameOfInst" class="control-label">
                          Name of Institution:
                        </label>
                        <input
                          type="text"
                          class={
                            data.nameOfInst === ""
                              ? "error-input"
                              : "form-control"
                          }
                          id="nameOfInst"
                          name="nameOfInst"
                          value={data.nameOfInst}
                          onChange={props.handleChange}
                          required=""
                        />
                      </div>
                      <div class="col-md-5">
                        <label for="phoneOfInst" class="control-label">
                          Phone Number of Institution:
                        </label>
                        <input
                          type="text"
                          class={
                            data.phoneOfInst === ""
                              ? "error-input"
                              : "form-control"
                          }
                          id="phoneOfInst"
                          name="phoneOfInst"
                          value={data.phoneOfInst}
                          onChange={props.handleChange}
                          placeholder="(   )   -"
                          maxlength="14"
                        />
                      </div>
                    </div>
                    <div class="row mt-3 ml-1">
                      <div class="col-md-12">
                        <label for="addrOfInst" class="control-label">
                          Address of Institution (number and street)
                        </label>
                        <input
                          type="text"
                          class={
                            data.addrOfInst === ""
                              ? "error-input"
                              : "form-control"
                          }
                          id="addrOfInst"
                          name="addrOfInst"
                          value={data.addrOfInst}
                          onChange={props.handleChange}
                          required=""
                        />
                      </div>
                    </div>
                  </div>
                ) : null}
                </fieldset>
              </li>

              <li>
                <fieldset class="radio radio-tab ml-3 mt-3">
                  <legend style={{ marginTop: "-2.5rem" }}>
                  <Text id="st2cat3.q6"/>
                  </legend>
                  <div class="col-md-7">
                    <input
                      type="text"
                      class="form-control"
                      id="hlthcovType"
                      name="hlthcovInscomp"
                      value={data.hlthcovInscomp}
                      onChange={props.handleChange}
                    />
                  </div>
                </fieldset>
              </li>
              <li>
                <fieldset class="radio radio-tab ml-3 mt-3">
                  <legend style={{ marginTop: "-2.5rem" }}>
                  <Text id="st2cat3.q7"/>
                  </legend>
                  <div class="col-md-7">
                    <input
                      type="text"
                      class="form-control"
                      id="hlthcovInscomp"
                      name="hlthcovType"
                      value={data.hlthcovType}
                      onChange={props.handleChange}
                    />
                  </div>
                </fieldset>
              </li>{" "}
            </ol>
          </div>

          <h4 class="sub-heading">
            <strong> <Text id="st2cat3.C"/></strong>
          </h4>
          <div class="form-group ml-3">
            <p>
            <Text id="st2cat3.csub1"/>
              <a
                href="sharpmedicareadvantage.com/findadoctor"
                style={{ marginLeft: "5px", marginRight: "5px" }}
              >
                <b> sharpmedicareadvantage.com/findadoctor</b>
              </a>
              <Text id="st2cat3.csub2"/>.
            </p>

            <div class="row">
              <div class="col-md-6 mt-3">
                <label for="pcpName" class={"control-label"}>
                <Text id="st2cat3.PCPName"/>:*
                </label>
                <select
                  name="pcpName"
                  id="pcpName"
                  class={data.pcpName === "" ? "error-input" : "form-control"}
                  onChange={props.pcpChange}
                  value={data.pcpName}
                >
                  {props.physicians.map((item, i) => {
                    return (
                      <option class="select-option" value={item.value} key={i}>
                        {item.label}
                      </option>
                    );
                  })}
                </select>
              </div>
              <div class="col-md-6 mt-3">
                <label for="clinicName" class={"control-label"}>
                <Text id="st2cat3.PCPMedicalGroup"/>:*
                </label>

                <select
                  name="pcpMedicalGroupName"
                  id="pcpName"
                  class={
                    data.pcpMedicalGroupName === ""
                      ? "error-input"
                      : "form-control"
                  }
                  onChange={props.handleChange}
                  value={data.pcpMedicalGroupName}
                >
                  <option class="select-option-tab" value="">
                    &nbsp;&nbsp;&nbsp;-Select-&nbsp;&nbsp;&nbsp;
                  </option>
                  <option class="select-option-tab" value="SRS">
                    Sharp Rees-Stealy Medical Group
                  </option>
                  <option class="select-option-tab" value="SCMG">
                    Sharp Community Medical Group
                  </option>
                  <option class="select-option-tab" value="GTC">
                    Greater Tri-City Medical Group
                  </option>
                </select>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                <fieldset class="radio radio-tab mt-3">
                  <legend><Text id="st2cat3.cq"/></legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="existingp"
                      id="currentPatient_Y"
                      class="custom-control-input"
                      value="Y"
                      checked={data.existingp === "Y"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="currentPatient_Y"
                      class="radio-inline custom-control-label"
                    >
                      <Text id="app.Yes"/> 
                      
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="existingp"
                      id="currentPatient_no"
                      class="custom-control-input"
                      value="N"
                      checked={data.existingp === "N"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="currentPatient_no"
                      class="radio-inline custom-control-label"
                    >
                      No
                    </label>
                  </div>
                </fieldset>
              </div>
            </div>
          </div>

          <div class="form-group">
            <fieldset class="radio radio-tab mt-3">
            <h4 class="sub-heading">
            {props.selectedPlan === "SDAHMO1" ||
             props.selectedPlan === "SDAHMO20"  ?
             <React.Fragment>
             <strong>D. <Text id="st2cat3.D"/></strong>
             <br />
             <br />
               <Text id="st2cat3.Dsub"/>
            </React.Fragment>:
            <strong>
            D. <Text id="st2cat3.Dsub"/>
            </strong>}
            
          </h4>
              <div class="row">
                <div class="col-md-12">
                  <div class="custom-control custom-checkbox custom-control-inline">
                    <input
                      type="checkbox"
                      class="custom-control-input"
                      name="languageCheckSpanish"
                      id="lfp_spanish"
                      value={data.languageCheckSpanish}
                      onChange={props.handleCheckbox2}
                      checked={data.languageCheckSpanish === "SPANISH" ? true :false}
                      disabled={data.languageCheckOther === "OTHER"}
                    />
                    <label
                      for="lfp_spanish"
                      class="radio-inline custom-control-label"
                    >
                     <Text id="st2cat3.Dchk1"/>
                    </label>
                  </div>
                  <br />
                  <div class="custom-control custom-checkbox custom-control-inline">
                    <input
                      type="checkbox"
                      class="custom-control-input"
                      name="languageCheckOther"
                      id="lfp_other"
                      value={data.languageCheckOther}
                      onChange={props.handleCheckbox2}
                      checked={data.languageCheckOther === "OTHER" ? true :false}
                      disabled={data.languageCheckSpanish === "SPANISH"}
                    />
                    <label
                      for="lfp_other"
                      class="radio-inline custom-control-label"
                    >
                      <Text id="st2cat3.Dchk2"/>
                    </label>
                  </div>
                  <br />
                  <label
                    for="lfp_other_field"
                    class="custom-control-inline w-50 mt-1"
                  >
                    <input
                      type="text"
                      placeholder={
                        data.language === "OTHER"
                          ? "Please enter Other Language"
                          : ""
                      }
                      name="languageValue"
                      id="lfp_other_field"
                      maxlength="11"
                      class="form-control"
                      required=""
                      value={data.languageValue}
                      onChange={props.handleChange}
                      disabled={data.languageCheckOther !== "OTHER"}
                    />
                  </label>
                </div>
                <br />
              </div>
            </fieldset>
          </div>
          <p>
          <Text id="st2cat3.Para1"/>.
          </p>
          <p>
          <Text id="st2cat3.Para2"/>t &nbsp;
            <a href="sharpmedicareadvantage.com">
              <b>sharpmedicareadvantage.com</b>
            </a>
            . <Text id="st2cat3.Para3"/>.
          </p>
          <p>
          <Text id="st2cat3.Para4"/>.
          </p>

          <p>
          <Text id="st2cat3.Para5"/>.
          </p>
          <p>
            <strong><Text id="st2cat3.NOTEcp"/>:</strong> <Text id="st2cat3.NOTEcpPart"/>.
          </p>

          <button
            class="btn btn-saveNext"
            id="next2"
            onClick={props.redirect}
            style={{ backgroundColor: "#603167" }}
          >
           <Text id="app.Save_Next"/>
          </button>
        </div>
      </div>
    </React.Fragment>
  );
};
export default Step2;

