import React from "react";
import { Text } from "react-internationalization";
import moment from "moment";
const Step2 = (props) => {
  const { data } = props;
  return (
    <React.Fragment>
       <div class="tab-content tab-contentSharp">
        <div id="step2" class="container tab-pane active">
          <h3 class="tab-heading"><Text id="st2cat3.STEP2"/>: <Text id="step2.MEDICAREINFO"/></h3>
          <p class="medicare-note">
            <Text id="step2.PleasePara"/>:
            <br />
            <strong><Text id="step2.Note"/>: </strong> <Text id="step2.notePart"/>.
          </p>

          <h4 class="sub-heading">
            <strong>
              <Text id="step2.APara"/>.
            </strong>
          </h4>
          <div class="form-group row">
            <div class="col-md-6">
              <p>
                <label for="medicareClaim" class="control-label">
                  <Text id="step2.MedicareNumber"/>*
                </label>
                <input
                  type="text"
                  placeholder="XXXXXXXXXXX"
                  pattern="/[a-zA-Z0-9]{10,11}/"
                  name="medicareClaim"
                  id="medicareClaim"
                  maxlength="12"
                  class={
                    data.medicareClaim.length < 10
                      ? "error-input"
                      : "form-control"
                  }
                  value={data.medicareClaim}
                  onChange={props.handleChange}
                  required=""
                />
              </p>

              <p>
                <label class="control-label" for="hospitalPartA">
                  <Text id="step2.Hospi"/>*
                </label>
                <input
                  placeholder="MM/DD/YYYY "
                  maxLength="10"
                  class={
                    data.hospitalPartA === "" ||
                    !moment(data.hospitalPartA, "MM/DD/YYYY", true).isValid()
                      ? "error-input"
                      : "form-control"
                  }
                  onClick={(e) => props.handleDates("hospitalPartA")}
                  name="hospitalPartA"
                  id="hospitalPartA"
                  value={data.hospitalPartA}
                  onChange={props.handleDate}
                  required=""
                />
              </p>

              <p>
                <label class="control-label" for="hospitalPartB">
                  <Text id="step2.Medical"/>*
                </label>
                <input
                  placeholder="MM/DD/YYYY"
                  maxLength="10"
                  class={
                    data.hospitalPartB === "" ||
                    !moment(data.hospitalPartB, "MM/DD/YYYY", true).isValid()
                      ? "error-input"
                      : "form-control"
                  }
                  onClick={(e) => props.handleDates("hospitalPartB")}
                  name="hospitalPartB"
                  id="hospitalPartB"
                  value={data.hospitalPartB}
                  onChange={props.handleDate}
                  required=""
                />
              </p>
            </div>
            <div class="col-md-6">
              <img
                src={require("../../assests/images/Medicardlogoshp_New.png")}
                alt=""
                class="width100per"
              />
            </div>
          </div>

          <h4 class="sub-heading">
            <strong><Text id="step2.BPara"/></strong>
          </h4>
          <div class="form-group">
            {/*<p class="text-align-justify">
              <strong>
                <Text id="step2.BPara"/>.{" "}
                {/*You can also
                choose to pay your premium by automatic deduction from your
                Social Security or Railroad Retirement Board (RRB) benefit check
                each month.}
              </strong>
            </p>*/}

            <p class="text-align-justify">
              <strong>
                <Text id="step2.Para8"/>.
                {/* You can also choose to pay your premium by automatic deduction
                from your Social Security or RRB.*/}
              </strong>
            </p>
            <p class="text-align-justify">
              <strong>
                <Text id="step2.Para4"/>.
              
              </strong>
            </p>

            <p class="text-align-justify">
              <strong>
                <Text id="step2.Para9"/>.
              </strong>
            </p>

            <p class="medicare-note text-align-justify">
              <Text id="step2.Para10"/>.
              <br />
              <br />
              <Text id="step2.Para11"/>.
            </p>

            <p>
              <strong><Text id="step2.paymentoption"/>:</strong>
            </p>

            <div class="radio radio-tab">
              <div class="custom-control custom-radio mt-3">
                <input
                  type="radio"
                  name="paymentOption"
                  id="getABill"
                  class="custom-control-input"
                  value="D"
                  checked={data.paymentOption === "D"}
                  onChange={props.handleChange}
                />
                <label for="getABill" class="radio-inline custom-control-label">
                  <strong>
                    <Text id="step2.Getbill"/>
                  </strong>
                </label>
              </div>

              <div class="custom-control custom-radio mt-3">
                <input
                  type="radio"
                  name="paymentOption"
                  class="custom-control-input"
                  id="electronicFunds"
                  value="R"
                  checked={data.paymentOption === "R"}
                  onChange={props.handleChange}
                />
                <label
                  for="electronicFunds"
                  class="radio-inline custom-control-label"
                >
                  <strong>
                    <Text id="step2.Electronicfunds"/>.
                  </strong>
                </label>
              </div>

              <div class="form-group row ml-3 mt-3">
                <div class="col-md-6">
                  <p>
                    <label for="acctholdername" class="control-label">
                      <Text id="step2.Accountname"/>:
                    </label>
                    <input
                      type="text"
                      class="form-control"
                      id="acctholdername"
                      name="acctholdername"
                      value={data.acctholdername}
                      onChange={props.handleChange}
                    />
                  </p>

                  <fieldset class="radio radio-tab">
                    <legend class="control-label"> <Text id="step2.Accounttype"/>:</legend>
                    <div class="custom-control custom-radio custom-control-inline">
                      <input
                        type="radio"
                        name="acctType"
                        id="checking"
                        value="C"
                        class="custom-control-input"
                        checked={data.acctType === "C"}
                        onChange={props.handleChange}
                      />
                      <label
                        for="checking"
                        class="radio-inline custom-control-label"
                      >
                         <Text id="step2.Checking"/>
                      </label>
                    </div>
                    <div class="custom-control custom-radio custom-control-inline">
                      <input
                        type="radio"
                        name="acctType"
                        id="saving"
                        value="S"
                        class="custom-control-input"
                        checked={data.acctType === "S"}
                        onChange={props.handleChange}
                      />
                      <label
                        for="saving"
                        class="radio-inline custom-control-label"
                      >
                         <Text id="step2.Saving"/>
                      </label>
                    </div>
                  </fieldset>
                </div>
                <div class="col-md-6">
                  <p>
                    <label for="bankname" class="control-label">
                    <Text id="step2.Bankname"/>:
                    </label>
                    <input
                      type="text"
                      class="form-control"
                      id="bankname"
                      name="bankname"
                      value={data.bankname}
                      onChange={props.handleChange}
                    />
                  </p>

                  <p>
                    <label for="routingNumber" class="control-label">
                    <Text id="step2.routingnumber"/>:
                    </label>
                    <input
                      type="text"
                      class="form-control"
                      id="routingNumber"
                      name="routingNumber"
                      value={data.routingNumber}
                      onChange={props.handleNumberChange}
                      placeholder="Enter 9-digit routing number"
                      maxlength="9"
                    />
                  </p>

                  <p>
                    <label for="accountNumber" class="control-label">
                    <Text id="step2.Bankaccountnumber"/>:
                    </label>
                    <input
                      type="text"
                      pattern="[0-9]*"
                      class="form-control"
                      id="accountNumber"
                      name="accountNumber"
                      value={data.accountNumber}
                      onChange={props.handleNumberChange}
                      placeholder="Enter a numeric a/c number"
                      maxlength="14"
                    />
                  </p>
                </div>
              </div>
            </div>
          </div>

          <h4 class="sub-heading">
            <strong> <Text id="step2.C"/></strong>
          </h4>
          <div class="form-group">
            <ol>
              <li>
                <fieldset class="radio radio-tab ml-3 mt-3">
                  <legend style={{ marginTop: "-2.5rem" }}>
                  <Text id="step2.q1"/>*
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="retiree"
                      id="retireeY"
                      class="custom-control-input"
                      value="Y"
                      checked={data.retiree === "Y"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="retireeY"
                      class="radio-inline custom-control-label"
                    >
                      <Text id="app.Yes" />
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="retiree"
                      id="retireeNo"
                      class="custom-control-input"
                      value="N"
                      checked={data.retiree === "N"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="retireeNo"
                      class="radio-inline custom-control-label"
                    >
                      No
                    </label>
                  </div>
                
                <div class="row">
                  <div class="col-4">
                    {data.retiree === "Y" ? (
                      <React.Fragment>
                        <label for="retiredate">
                          <Text id="st2cat3.retirement"/>:
                        </label>
                        <input
                          name="retiredate"
                          id="retiredate"
                          placeholder="MM/DD/YYYY"
                          class="form-control"
                          maxlength="10"
                          value={data.retiredate}
                          onChange={props.handleDate}
                          onClick={(e) => props.handleDates("retiredate")}
                        />
                      </React.Fragment>
                    ) : null}
                  </div>
                  <div class="col-2"></div>
                  <div class="col-4">
                    <label for="retirename"><Text id="st2cat3.nameretiree"/>:</label>{" "}
                    <input
                      type="text"
                      name="retirename"
                      class="form-control"
                      value={data.retirename}
                      onChange={props.handleChange}
                    />
                  </div>
                </div>
                </fieldset>
              </li>
              <li>
                <fieldset class="radio radio-tab ml-3 mt-3">
                  <legend style={{ marginTop: "-2.5rem" }}>
                  <Text id="step2.q2"/>*
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="empCover"
                      id="empCoverY"
                      class="custom-control-input"
                      value="Y"
                      checked={data.empCover === "Y"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="empCoverY"
                      class="radio-inline custom-control-label"
                    >
                      <Text id="app.Yes" />
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="empCover"
                      id="empCoverno"
                      class="custom-control-input"
                      value="N"
                      checked={data.empCover === "N"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="empCoverno"
                      class="radio-inline custom-control-label"
                    >
                      No
                    </label>
                  </div>
               
                {data.empCover === "Y" ? (
                  <div class="row">
                    <div class="col-4">
                      <label for="retiredate"><Text id="st2cat3.spousename"/>:</label>
                      <input
                        type="text"
                        name="dependentSpouse"
                        id="dependentSpouse"
                        class="form-control"
                        value={data.dependentSpouse}
                        onChange={props.handleChange}
                      />
                    </div>
                    <div class="col-2"></div>
                    <div class="col-4">
                      <label for="retirename"><Text id="st2cat3.dependents"/>:</label>{" "}
                      <input
                        type="text"
                        name="dependentOther"
                        class="form-control"
                        value={data.dependentOther}
                        onChange={props.handleChange}
                      />
                    </div>
                  </div>
                ) : null}
                 </fieldset>
              </li>

              <li>
                <fieldset class="radio radio-tab ml-3 mt-3">
                  <legend style={{ marginTop: "-2.5rem" }}>
                  <Text id="step2.q3"/>*
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="spousework"
                      id="c_q5_Y"
                      class="custom-control-input"
                      value="Y"
                      checked={data.spousework === "Y"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="c_q5_Y"
                      class="radio-inline custom-control-label"
                    >
                      <Text id="app.Yes" />
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="spousework"
                      id="c_q5_no"
                      class="custom-control-input"
                      value="N"
                      checked={data.spousework === "N"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="c_q5_no"
                      class="radio-inline custom-control-label"
                    >
                      No
                    </label>
                  </div>
                </fieldset>
              </li>

              <li>
                <fieldset class="radio radio-tab ml-3 mt-3">
                  <legend style={{ marginTop: "-2.5rem" }}>
                  <Text id="step2.q4"/>*
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="renalDisease"
                      id="c_q1_Y"
                      class="custom-control-input"
                      value="Y"
                      checked={data.renalDisease === "Y"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="c_q1_Y"
                      class="radio-inline custom-control-label"
                    >
                      <Text id="app.Yes" />
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="renalDisease"
                      id="c_q1_no"
                      class="custom-control-input"
                      value="N"
                      checked={data.renalDisease === "N"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="c_q1_no"
                      class="radio-inline custom-control-label"
                    >
                      No
                    </label>
                  </div>
                  {data.renalDisease === "Y" ? (
                    <div>
                      <legend>
                      <Text id="st2cat3.q4sub1"/>*
                      </legend>
                      <Text id="st2cat3.q4sub2"/>.
                      <br></br>
                      <div class="custom-control custom-radio custom-control-inline">
                        <input
                          type="radio"
                          name="esrdcontact"
                          id="esrdcontact_Y"
                          class="custom-control-input"
                          value="Y"
                          checked={data.esrdcontact === "Y"}
                          onChange={props.handleChange}
                        />
                        <label
                          for="esrdcontact_Y"
                          class="radio-inline custom-control-label"
                        >
                          <Text id="app.Yes" />
                        </label>
                      </div>
                      <div class="custom-control custom-radio custom-control-inline">
                        <input
                          type="radio"
                          name="esrdcontact"
                          id="esrdcontact_no"
                          class="custom-control-input"
                          value="N"
                          checked={data.esrdcontact === "N"}
                          onChange={props.handleChange}
                        />
                        <label
                          for="esrdcontact_no"
                          class="radio-inline custom-control-label"
                        >
                          No
                        </label>
                      </div>
                    </div>
                  ) : null}
                </fieldset>
              </li>
              <li>
                <fieldset class="radio radio-tab ml-3 mt-3" id="c_qns2">
                  <legend style={{ marginTop: "-2.5rem" }}>
                  <Text id="step2.q5"/>*
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="vaBenefits"
                      id="c_q2_Y"
                      class="custom-control-input"
                      value="Y"
                      checked={data.vaBenefits === "Y"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="c_q2_Y"
                      class="radio-inline custom-control-label"
                    >
                      <Text id="app.Yes" />
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="vaBenefits"
                      id="c_q2_no"
                      class="custom-control-input"
                      value="N"
                      checked={data.vaBenefits === "N"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="c_q2_no"
                      class="radio-inline custom-control-label"
                    >
                      No
                    </label>
                  </div>
                
                {data.vaBenefits === "Y" ? (
                  <div id="c_q2_fields">
                    <div class="row mt-3 ml-1">
                      <div class="col-md-4">
                        <label for="nameOfCov" class="control-label">
                        <Text id="st2cat3.coverage"/>*
                        </label>
                        <input
                          type="text"
                          class={
                            data.nameOfCov === ""
                              ? "error-input"
                              : "form-control"
                          }
                          id="nameOfCov"
                          name="nameOfCov"
                          value={data.nameOfCov}
                          onChange={props.handleChange}
                        />
                      </div>
                      <div class="col-md-4">
                        <label for="idOfCov" class="control-label">
                        <Text id="st2cat3.coverageId"/>*
                        </label>
                        <input
                          type="text"
                          class={
                            data.idOfCov === "" ? "error-input" : "form-control"
                          }
                          id="idOfCov"
                          name="idOfCov"
                          value={data.idOfCov}
                          onChange={props.handleChange}
                        />
                      </div>
                      <div class="col-md-4">
                        <label for="groupOfCov" class="control-label">
                        <Text id="st2cat3.grpcov"/>*
                        </label>
                        <input
                          type="text"
                          class={
                            data.groupOfCov === ""
                              ? "error-input"
                              : "form-control"
                          }
                          id="groupOfCov"
                          name="groupOfCov"
                          value={data.groupOfCov}
                          onChange={props.handleChange}
                        />
                      </div>
                    </div>
                  </div>
                ) : null}
                </fieldset>
              </li>

              <li>
                <fieldset class="radio radio-tab ml-3 mt-3" id="c_qns4">
                  <legend style={{ marginTop: "-2.5rem" }}>
                  <Text id="step2.q6"/>*
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="prescriptionDrug"
                      id="c_q4_Y"
                      class="custom-control-input"
                      value="Y"
                      checked={data.prescriptionDrug === "Y"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="c_q4_Y"
                      class="radio-inline custom-control-label"
                    >
                      <Text id="app.Yes" />
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="prescriptionDrug"
                      id="c_q4_no"
                      class="custom-control-input"
                      value="N"
                      checked={data.prescriptionDrug === "N"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="c_q4_no"
                      class="radio-inline custom-control-label"
                    >
                      No
                    </label>
                  </div>
               
                {data.prescriptionDrug === "Y" ? (
                  <div id="c_q4_fields">
                    <div class="row mt-3 ml-1">
                      <div class="col-md-7">
                        <label for="nameOfInst" class="control-label">
                        <Text id="st2cat3.isnt"/>:
                        </label>
                        <input
                          type="text"
                          class={
                            data.nameOfInst === ""
                              ? "error-input"
                              : "form-control"
                          }
                          id="nameOfInst"
                          name="nameOfInst"
                          value={data.nameOfInst}
                          onChange={props.handleChange}
                          required=""
                        />
                      </div>
                      <div class="col-md-5">
                        <label for="phoneOfInst" class="control-label">
                        <Text id="st2cat3.phoneinst"/>:
                        </label>
                        <input
                          type="text"
                          class={
                            data.phoneOfInst === ""
                              ? "error-input"
                              : "form-control"
                          }
                          id="phoneOfInst"
                          name="phoneOfInst"
                          value={data.phoneOfInst}
                          onChange={props.handleChange}
                          placeholder="(   )   -"
                          maxlength="14"
                        />
                      </div>
                    </div>
                    <div class="row mt-3 ml-1">
                      <div class="col-md-12">
                        <label for="addrOfInst" class="control-label">
                        <Text id="st2cat3.adressint"/>:
                        </label>
                        <input
                          type="text"
                          class={
                            data.addrOfInst === ""
                              ? "error-input"
                              : "form-control"
                          }
                          id="addrOfInst"
                          name="addrOfInst"
                          value={data.addrOfInst}
                          onChange={props.handleChange}
                          required=""
                        />
                      </div>
                    </div>
                  </div>
                ) : null}
                 </fieldset>
              </li>

              <li>
                <fieldset class="radio radio-tab ml-3 mt-3">
                  {navigator.userAgent.indexOf("MSIE") > -1 ||
                  navigator.userAgent.indexOf("rv:") > -1 ? (
                    <legend style={{ marginTop: "-40px" }}>
                     <Text id="step2.q7"/>
                    </legend>
                  ) : (
                    <legend>
                    <Text id="step2.q7"/>
                    </legend>
                  )}
                  <div class="row">
                    <div class="col-md-6">
                      <fieldset class="radio radio-tab mt-3">
                        <legend><Text id="step2.q7Part"/></legend>
                        <div class="custom-control custom-radio custom-control-inline">
                          <input
                            type="radio"
                            name="existingp"
                            id="currentPatient_Y"
                            class="custom-control-input"
                            value="Y"
                            checked={data.existingp === "Y"}
                            onChange={props.handleChange}
                          />
                          <label
                            for="currentPatient_Y"
                            class="radio-inline custom-control-label"
                          >
                            <Text id="app.Yes" />
                          </label>
                        </div>
                        <div class="custom-control custom-radio custom-control-inline">
                          <input
                            type="radio"
                            name="existingp"
                            id="currentPatient_no"
                            class="custom-control-input"
                            value="N"
                            checked={data.existingp === "N"}
                            onChange={props.handleChange}
                          />
                          <label
                            for="currentPatient_no"
                            class="radio-inline custom-control-label"
                          >
                            No
                          </label>
                        </div>
                      </fieldset>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6 mt-3">
                      <label for="pcpName" class={"control-label"}>
                        <Text id="step2.PCPName"/>:*
                      </label>
                      <select
                        name="pcpName"
                        id="pcpName"
                        class={
                          data.pcpName === "" ? "error-input" : "form-control"
                        }
                        onChange={props.pcpChange}
                        value={data.pcpName}
                      >
                        {props.physicians.map((item, i) => {
                          return (
                            <option
                              class="select-option"
                              value={item.value}
                              key={i}
                            >
                              {item.label}
                            </option>
                          );
                        })}
                      </select>
                    </div>
                    <div class="col-md-6 mt-3">
                      <label for="clinicName" class={"control-label"}>
                        <Text id="step2.MedicalGroup"/>:*
                      </label>

                      <input
                        name="pcpMedicalGroupName"
                        id="clinicName"
                        class={
                          data.pcpMedicalGroupName === ""
                            ? "error-input"
                            : "form-control"
                        }
                        style={{ cursor: "not-allowed" }}
                        disabled
                        value={data.pcpMedicalGroupName}
                      />
                    </div>
                  </div>
                </fieldset>
              </li>
              <li
                class={
                  navigator.userAgent.indexOf("MSIE") > -1 ||
                  navigator.userAgent.indexOf("rv:") > -1
                    ? "margintest"
                    : ""
                }
              >
                <fieldset class="radio radio-tab ml-3 mt-3">
                  <div class="form-group">
                    <fieldset class="radio radio-tab mt-3">
                      {navigator.userAgent.indexOf("MSIE") > -1 ||
                      navigator.userAgent.indexOf("rv:") > -1 ? (
                        <legend style={{ marginTop: "-56px" }}>
                          <Text id="step2.q8"/>
                        </legend>
                      ) : (
                        <legend>
                           <Text id="step2.q8"/>
                        </legend>
                      )}

                      <div class="row">
                        <div class="col-md-12">
                          <React.Fragment>
                            <div class="custom-control custom-radio custom-control-inline mt-3">
                              <input
                                type="radio"
                                name="language"
                                id="lfp_spanish"
                                class="custom-control-input"
                                value="SPANISH"
                                checked={data.language === "SPANISH"}
                                onChange={props.handleChange}
                              />
                              <label
                                for="lfp_spanish"
                                class="radio-inline custom-control-label"
                              >
                                <Text id="step2.q8rod1"/>
                              </label>
                            </div>
                            <br />
                            <div class="custom-control custom-radio custom-control-inline mt-3">
                              <input
                                type="radio"
                                name="language"
                                id="lfp_braille"
                                class="custom-control-input"
                                value="BRAILLE"
                                checked={data.language === "BRAILLE"}
                                onChange={props.handleChange}
                              />
                              <label
                                for="lfp_braille"
                                class="radio-inline custom-control-label"
                              >
                                 <Text id="step2.q8rod2"/>
                              </label>
                            </div>
                            <br />
                            <div class="custom-control custom-radio custom-control-inline mt-3">
                              <input
                                type="radio"
                                name="language"
                                id="lfp_largeprint"
                                class="custom-control-input"
                                value="LARGE_PRINT"
                                checked={data.language === "LARGE_PRINT"}
                                onChange={props.handleChange}
                              />
                              <label
                                for="lfp_largeprint"
                                class="radio-inline custom-control-label"
                              >
                                 <Text id="step2.q8rod3"/>
                              </label>
                            </div>
                            <br />
                            <div class="custom-control custom-radio custom-control-inline mt-3">
                              <input
                                type="radio"
                                name="language"
                                id="lfp_other"
                                class="custom-control-input"
                                value="OTHER"
                                checked={data.language === "OTHER"}
                                onChange={props.handleChange}
                              />
                              <label
                                for="lfp_other"
                                class="radio-inline custom-control-label"
                              >
                                <Text id="step2.q8rod4"/>
                              </label>
                            </div>
                            <br />
                          </React.Fragment>

                          <label
                            for="lfp_other_field"
                            class="custom-control-inline w-50 mt-1"
                          >
                            <input
                              type="text"
                              placeholder={
                                data.language === "OTHER"
                                  ? "Please enter Other Language"
                                  : ""
                              }
                              name="languageValue"
                              id="lfp_other_field"
                              maxlength="11"
                              class="form-control"
                              required=""
                              value={data.languageValue}
                              onChange={props.handleChange}
                              disabled={data.language !== "OTHER"}
                            />
                          </label>
                        </div>
                      </div>
                    </fieldset>
                  </div>
                </fieldset>
              </li>
            </ol>
          </div>

          {/* <h4 class="sub-heading">
            <strong>E. Language and Format Preferences</strong>
          </h4>
          <div class="form-group">
            <fieldset class="radio radio-tab mt-3">
              <legend>
                Please check one of the boxes below if you would prefer us to
                send you information in a language other than English or in
                another format
              </legend>
            </fieldset>
          </div>*/}
          <p>
            <Text id="step2.Para12"/>.
          </p>
          <p>
            <Text id="step2.Para13"/> &nbsp;
            <a href="sharpmedicareadvantage.com">
              <b><Text id="step2.sharplink"/></b>
            </a>
            . <Text id="step2.Para14"/>.
          </p>
          <p>
            <strong><Text id="step2.NOTECAp"/>:</strong> <Text id="step2.NOTECApPart"/>.
          </p>

          <button class="btn btn-saveNext" id="next2" onClick={props.redirect}>
           <Text id="app.Save_Next"/>
          </button>
        </div>
      </div>
    </React.Fragment>
  );
};
export default Step2;
