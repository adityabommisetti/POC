import React, { Component } from "react";
import Banner from "../Utils/GenericUI/Banner.jsx";
import history from "../Utils/History";
import { header, Body } from "../Utils/StaticData/YearSelectionStaticData";
import { connect } from "react-redux";
import {
  planSelectionContinue,
  removeplan,
} from "../Redux/Actions/webAppActions";
import Footer2 from "../Utils/GenericUI/Footer2.jsx";
import { Text } from "react-internationalization";
class SelectedPlans extends Component {
  constructor(props) {
    super(props);
    this.state = {
      value: this.props.selectedPlan,
      year: this.props.year,
    };
  }
  handleSelectChange = (event) => {
    const value = event.target.value;

    this.setState({
      value: value,
    });
  };
  continue = async () => {
    if (this.state.value === "") {
      let msg=this.props.lang==="es"?"Por favor seleccione plan !!":"Please select plan !!"
      alert(msg);
      return;
    } else {
      let payload = {
        strPlanId: this.state.value,
      };
      await this.props.planSelectionContinue(payload);
      history.push("/webapp/Sharp/Individual/enrollOnline");
    }
  };
  render() {
    const { value, year } = this.state;
    return (
      <React.Fragment>
        <div class="space">
          <Banner header={header} Body={Body} />
          <div class="text-center" style={{marginTop: "-40px"}}>
            <div class="margin-top1">
              <strong>
               <Text id="plan.hed1"/>.
              </strong>
            </div>
            <div class="plan-title2">
            <Text id="plan.hed2"/>:
            </div>
          </div>
        </div>
        {year === "2020" ? (
          <div class="container mt-3">
            <div class="form-group row">
              <div class="col-md-4">
                <div class="enrollment-steps">
                  <div class="enrollment-steps--header  step-3">
                    <h3 class="medicare-plan-TypeA-h3-white">
                      <Text id="plan.head1"/>
                      <br />
                      <Text id="plan.head2"/>:
                    </h3>
                  </div>
                  <div class="enrollment-steps--body  step-3">
                    <div class="plans custom-control custom-radio">
                      <div style={{ display: "inline !important" }}>
                        <input
                          id="planId"
                          name="Plan"
                          type="radio"
                          value="SDAGC20"
                          class="custom-control-input"
                          checked={value === "SDAGC20"}
                          onChange={this.handleSelectChange}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId"
                        >
                          2020 Sharp Direct Advantage
                          <br />
                          Gold Card (HMO)
                        </label>
                        <p>($0 monthly premium)</p>
                      </div>

                      <div>
                        <input
                          id="planId2"
                          name="Plan"
                          type="radio"
                          value="SDAGCWD20"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDAGCWD20"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId2"
                        >
                          2020 Sharp Direct Advantage
                          <br />
                          Gold Card (HMO) With Dental
                        </label>
                        <p>($12 monthly premium)</p>
                      </div>

                      <div>
                        <input
                          id="planId3"
                          name="Plan"
                          type="radio"
                          value="SDAPC20"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDAPC20"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId3"
                        >
                          2020 Sharp Direct Advantage
                          <br />
                          Platinum Card (HMO) With <br />
                          Dental
                        </label>
                        <p>($57 monthly premium)</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-md-4">
                <div class="enrollment-steps">
                  <div class="enrollment-steps--header  step-1">
                    <h3 class="medicare-plan-TypeA-h3-white">
                      Former Employees of Sharp
                      <br />
                      HealthCare only:
                    </h3>
                  </div>
                  <div class="enrollment-steps--body  step-1">
                    <div class="plans custom-control custom-radio">
                      <div>
                        <input
                          id="planId4"
                          name="Plan"
                          type="radio"
                          value="SDAB20"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDAB20"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId4"
                        >
                          2020 Sharp Direct Advantage
                          <br />
                          Basic (HMO)
                        </label>
                        <p>($0 monthly premium)</p>
                      </div>

                      <div>
                        <input
                          id="planId5"
                          name="Plan"
                          type="radio"
                          value="SDABWD20"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDABWD20"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId5"
                        >
                          2020 Sharp Direct Advantage
                          <br />
                          Basic (HMO) With Dental
                        </label>
                        <p>($12 monthly premium)</p>
                      </div>

                      <div>
                        <input
                          id="planId6"
                          name="Plan"
                          type="radio"
                          value="SDAP20"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDAP20"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId6"
                        >
                          2020 Sharp Direct Advantage
                          <br />
                          Premium (HMO)
                        </label>
                        <p>($62 monthly premium)</p>
                      </div>

                      <div>
                        <input
                          id="planId7"
                          name="Plan"
                          type="radio"
                          value="SDAPWD20"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDAPWD20"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId7"
                        >
                          2020 Sharp Direct Advantage
                          <br />
                          Premium (HMO) With Dental
                        </label>
                        <p>($74 monthly premium)</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-md-4">
                <div class="enrollment-steps">
                  <div class="enrollment-steps--header  step-4">
                    <h3 class="medicare-plan-TypeA-h3-white">
                      Retirees of the City of San Diego
                      <br /> (SDPEBA) only:
                    </h3>
                  </div>
                  <div class="enrollment-steps--body  step-4">
                    <div class="plans custom-control custom-radio">
                      <div>
                        <input
                          id="planId8"
                          name="Plan"
                          type="radio"
                          value="SDAHMO1"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDAHMO1"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId8"
                        >
                          2019-20 Sharp Direct Advantage (HMO)
                        </label>
                        <p>($201 monthly premium)</p>
                      </div>
                      <div>
                        <input
                          id="planId9"
                          name="Plan"
                          type="radio"
                          value="SDAHMO20"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDAHMO20"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId9"
                        >
                          2020-21 Sharp Direct Advantage (HMO)
                        </label>
                        <p>($201 monthly premium)</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="text-right">
              <button
                class="btn btn-SaveLogout margin-right1"
                onClick={this.continue}
              >
                Continue
              </button>
              <div class="margin-top1">
                <strong>
                  Not sure?&nbsp;
                  <a href="https://www.sharpmedicareadvantage.com/our-plans/explore-our-plans" 
                  style={{'color':  '#00a49b'}}>
                    Look at Our Plans.
                    </a>
                  </strong>
              </div>
            </div>
            <Footer2 />
          </div>
        ) : (
          <div class="container mt-3">
            <div class="form-group row">
              <div class="col-md-4">
                <div class="enrollment-steps">
                  <div class={this.props.lang==="es"?"enrollment-steps--header  step-3 sp_stepheight":"enrollment-steps--header  step-3"}>
                    <h3 class="medicare-plan-TypeA-h3-white">
                    <Text id="plan.head1"/>
                      <br />
                      <Text id="plan.head2"/>:
                    </h3>
                  </div>
                  <div class="enrollment-steps--body  step-3">
                    <div class="plans custom-control custom-radio">
                      <div style={{ display: "inline !important" }}>
                        <input
                          id="planId"
                          name="Plan"
                          type="radio"
                          value="SDAGC20"
                          class="custom-control-input"
                          checked={value === "SDAGC20"}
                          onChange={this.handleSelectChange}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId"
                        >
                         <Text id="plan.p1"/>
                          <br />
                          <Text id="plan.p1sb"/>
                        </label>
                        <p><Text id="plan.p1sb2"/></p>
                      </div>

                      <div>
                        <input
                          id="planId2"
                          name="Plan"
                          type="radio"
                          value="SDAGCWD20"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDAGCWD20"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId2"
                        >
                         <Text id="plan.p2"/> 
                          <br />
                          <Text id="plan.p2sb"/> 
                        </label>
                        <p>
                        <Text id="plan.p2sb2"/> 
                        </p>
                      </div>

                      <div>
                        <input
                          id="planId3"
                          name="Plan"
                          type="radio"
                          value="SDAPC20"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDAPC20"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId3"
                        ><Text id="plan.p3"/> 
                        <br />
                          <Text id="plan.p3sb"/><br />
                          <Text id="plan.Dental"/>
                        </label>
                        <p>
                          <Text id="plan.p3sb2"/>
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-md-4">
                <div class="enrollment-steps">
                  <div class={this.props.lang==="es"?"enrollment-steps--header  step-1 sp_stepheight":"enrollment-steps--header  step-1"}>
                    <h3 class="medicare-plan-TypeA-h3-white">
                      <Text id="plan.head3"/>
                      <br />
                      <Text id="plan.head4"/>
                    </h3>
                  </div>
                  <div class="enrollment-steps--body  step-1">
                    <div class="plans custom-control custom-radio">
                      <div>
                        <input
                          id="planId4"
                          name="Plan"
                          type="radio"
                          value="SDAB20"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDAB20"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId4"
                        >
                         <Text id="plan.p4"/>
                          <br />
                          <Text id="plan.p4sb"/> 
                        </label>
                        <p><Text id="plan.p4sb2"/></p>
                      </div>

                      <div>
                        <input
                          id="planId5"
                          name="Plan"
                          type="radio"
                          value="SDABWD20"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDABWD20"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId5"
                        >
                         <Text id="plan.p5"/> 
                          <br />
                          <Text id="plan.p5sb"/>  
                        </label>
                        <p><Text id="plan.p5sb2"/></p>
                      </div>

                      <div>
                        <input
                          id="planId6"
                          name="Plan"
                          type="radio"
                          value="SDAP20"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDAP20"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId6"
                        >
                          <Text id="plan.p6"/>
                          <br />
                          <Text id="plan.p6sb"/> 
                        </label>
                        <p><Text id="plan.p6sb2"/></p>
                      </div>

                      <div class={this.props.lang==="es"?"iespmarginplan4":""}>
                        <input
                          id="planId7"
                          name="Plan"
                          type="radio"
                          value="SDAPWD20"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDAPWD20"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId7"
                        >
                          <Text id="plan.p7"/> 
                          <br />
                          <Text id="plan.p7sb"/> 
                        </label>
                        <p> <Text id="plan.p7sb2"/></p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-md-4">
                <div class="enrollment-steps">
                  <div class={this.props.lang==="es"?"enrollment-steps--header  step-4 sp_stepheight":"enrollment-steps--header  step-4"}>
                    <h3 class="medicare-plan-TypeA-h3-white">
                     <Text id="plan.head5"/>
                      <br /><Text id="plan.head6"/>:
                    </h3>
                  </div>
                  <div class="enrollment-steps--body  step-4">
                    <div class="plans custom-control custom-radio">
                      <div>
                        <input
                          id="planId8"
                          name="Plan"
                          type="radio"
                          value="SDAHMO1"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDAHMO1"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId8"
                        >
                          <Text id="plan.p8"/>
                        </label>
                        <p> <Text id="plan.p8sb"/>)</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="text-right">
              <button
                class="btn btn-SaveLogout margin-right1"
                onClick={this.continue}
              >
               <Text id="plan.Continue"/>
              </button>
              <div class="margin-top1">
                <strong>
                 <Text id="plan.not"/>&nbsp;
                  <a href="https://www.sharpmedicareadvantage.com/our-plans/explore-our-plans"
                   style={{'color':  '#00a49b'}}>
                    <Text id="plan.look"/>.
                  </a>
                </strong>
              </div>
            </div>
            <Footer2 />
          </div>
        )}
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    year: state.webApp.year,
    guestLogin: state.webApp.guestLogin,
    selectedPlan: state.webApp.selectedPlan,
    lang:state.webApp.language,
  };
};
const mapDispatchToProps = {
  planSelectionContinue,
  removeplan,
};

export default connect(mapStateToProps, mapDispatchToProps)(SelectedPlans);
