import React, { Component } from "react";
import Banner from "../Utils/GenericUI/Banner.jsx";
import history from "../Utils/History";
import { header, Body } from "../Utils/StaticData/YearSelectionStaticData";
import { connect } from "react-redux";
import { yearSelection, removeplan } from "../Redux/Actions/webAppActions";
import Footer2 from "../Utils/GenericUI/Footer2.jsx";
import { Text } from "react-internationalization";
class YearSelection extends Component {
  constructor(props) {
    super(props);
    this.state = {
      value: "",
    };
  }
  handleSelectChange = async (event) => {
    const value = event.target ? event.target.value : event.value;
    await this.setState({
      value: value,
    });
  };
  continue = async (event) => {
    event.preventDefault();
    if (this.state.value === "") {
      let msg=this.props.lang==="es"?"¡Seleccione el año requerido!":" Please select the required year !!";
      alert(msg);
      return;
    } else {
      let payload = {
        planYear: this.state.value,
      };
      await this.props.removeplan();
      await this.props.yearSelection(payload);
      history.push("/webapp/Sharp/Individual/selectedPlans");
    }
  };
  render() {
    const { value } = this.state;
    return (
      <div>
        <Banner header={header} Body={Body} />

        <div class="container" style={{ marginTop: "-50px" }}>
          <div class="tab-content">
            <div class="container form-panel">
              <div class="form-group row">
                <div class="col-md-12 text-center">
                  <label class="control-label" for="year-id">
                   <Text id="year.head"/>:{" "}
                  </label>
                  <br />
                  <div style={{ marginTop: "25px", marginBottom: "20px" }}>
                    <select
                      class="form-control form-control-width20 "
                      name="year"
                      id="year-id"
                      value={value}
                      onChange={this.handleSelectChange}
                    >
                      <option class="select-option-tab" value="">
                     {this.props.lang==="es"?"Elija año":"Choose Year"} {/* <Text id="year.choose"/>*/}
                      </option>
                      <option class="select-option-tab" value="2020">
                        2020
                      </option>
                      <option class="select-option-tab" value="2021">
                        2021
                      </option>
                    </select>
                  </div>
                </div>
              </div>
              <div class="text-center">
                <button
                  class= {this.props.lang==="es" && value==="2020"?
                    "btn btn-SaveLogout margin-right1 disbconti":
                    "btn btn-SaveLogout margin-right1"
    }
                  onClick={this.continue}
                  disabled={this.props.lang==="es" && value==="2020"}
                >
                 <Text  id="year.Continue"/>
                </button>
                <div class="margin-top1">
                  <strong>
                    <Text id="year.not"/>&nbsp;
                  <a href="https://www.sharpmedicareadvantage.com/our-plans/explore-our-plans"
                      style={{'color':  '#00a49b'}}>
                      <Text id="year.look"/>.
                    </a>
                  </strong>
                </div>
              </div>
            </div>
          </div>
          <Footer2 />
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    lang:state.webApp.language
  };
};
const mapDispatchToProps = {
  yearSelection,
  removeplan,
};

export default connect(mapStateToProps, mapDispatchToProps)(YearSelection);
