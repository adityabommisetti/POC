import React, { Component } from "react";
import { connect } from "react-redux";
import moment from "moment";
import { Text } from "react-internationalization";
class Step3 extends Component {
  constructor(props) {
    super(props);
    this.state = {
      formerEmpOfSharp: false,
      retireEmpOfSharp: false,
    };
  }

  componentDidMount() {
    const selectedPlan = this.props.selectedPlan;
    if (
      selectedPlan === "SDAB20" ||
      selectedPlan === "SDABWD20" ||
      selectedPlan === "SDAP20" ||
      selectedPlan === "SDAPWD20"
    ) {
      this.setState({ formerEmpOfSharp: true });
    }
    if (selectedPlan === "SDAHMO1" || selectedPlan === "SDAHMO20") {
      this.setState({ retireEmpOfSharp: true });
    }
  }

  render() {
    const { data, disableCheck, year, selectedPlan } = this.props;
    console.log(selectedPlan);
    console.log(
      year === "2021" &&
        (selectedPlan === "SDAGCWD20" ||
          selectedPlan === "SDAGC20" ||
          selectedPlan === "SDAPC20")
    );
    return (
      <React.Fragment>
        <div class="tab-content tab-contentSharp">
          <div id="step3" class="container tab-pane active">
            {/* <div id="step3" class="container tab-pane fade"> */}
            {year === "2021" &&
            (selectedPlan === "SDAGCWD20" ||
              selectedPlan === "SDAGC20" ||
              selectedPlan === "SDAPC20") ? (
              <h3 class="tab-heading">
                <Text id="step3.Exhibit1a"/>: <Text id="step3.stepsub"/>.
              </h3>
            ) : (
              <React.Fragment>
                <h3 class="tab-heading">
                <Text id="step3.step3"/>: <Text id="step3.Step3sub"/>
                </h3>
                <p>
                  <strong>
                  <Text id="step3.Exhibit1a"/>: <Text id="step3.stepsub"/>
                  </strong>
                </p>
              </React.Fragment>
            )}
            <p>
              {this.state.retireEmpOfSharp === true ? (
                <strong>
                  Typically, you may enroll in a Medicare Advantage plan only
                  during the City of San Diego Medicare Retirees' open
                  enrollment period which is in June each year.
                </strong>
              ) : (
                <strong>
                  <Text id="step3.Para1"/>.
                </strong>
              )}
              <Text id="step3.Para2"/>.
            </p>
            <p>
              <Text id="step3.Para3"/>.
            </p>
            <ul class="list-group" id="step3_checklist">
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk1"
                    name="aep"
                    value={data.aep}
                    checked={data.aep === "AEP" ? true : false}
                    onChange={this.props.handleCheckbox}
                    disabled={
                      disableCheck === false || data.aep === "AEP"
                        ? false
                        : true
                    }
                  />

                  <label class="custom-control-label" for="step3_chk1">
                    {this.state.formerEmpOfSharp === true ? (
                      <strong>
                        <Text id="step3.optAnth1"/>.
                      </strong>
                    ) : this.state.retireEmpOfSharp === true ? (
                      <strong>
                       <Text id="step3.retiop"/>.
                      </strong>
                    ) : (
                      <React.Fragment>
                        <strong>
                          <Text id="step3.Op1" />.
                        </strong>{" "}
                        <Text id="step3.Op1sub" />.
                      </React.Fragment>
                    )}
                  </label>
                </div>
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk2"
                    name="c1"
                    value={data.c1}
                    disabled={
                      disableCheck === false || data.c1 === "NEW" ? false : true
                    }
                    checked={data.c1 === "NEW" ? true : false}
                    onChange={this.props.handleCheckbox}
                  />
                  <label class="custom-control-label" for="step3_chk2">
                    <strong>
                      <Text id="step3.Op2" />.
                    </strong>
                  </label>
                </div>
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk3"
                    name="c2"
                    checked={data.c2 === "MOV" ? true : false}
                    onChange={this.props.handleCheckbox}
                    disabled={
                      disableCheck === false || data.c2 === "MOV" ? false : true
                    }
                    value={data.c2}
                  />
                  <label class="custom-control-label" for="step3_chk3">
                    <strong>
                      <Text id="step3.Op3" />.
                    </strong>
                  </label>
                  <br />
                </div>
                {data.c2 === "MOV" ? (
                  <React.Fragment>
                    <label for="attestation2" class="attestmargin">
                     <Text id="step3.movedate"/>*
                      <input
                        type="attestation2"
                        id="attestation2"
                        name="attestation2"
                        class="form-control display-inline"
                        placeholder="MM/DD/YYYY"
                        maxLength="10"
                        value={data.attestation2}
                        onChange={this.props.handleDate}
                        onClick={(e) => this.props.handleDates("attestation2")}
                        class={
                          data.attestation2 === "" ||
                          !moment(
                            data.attestation2,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                      />
                    </label>
                  </React.Fragment>
                ) : null}
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk4"
                    name="c3"
                    disabled={
                      disableCheck === false || data.c3 === "INC" ? false : true
                    }
                    checked={data.c3 === "INC" ? true : false}
                    onChange={this.props.handleCheckbox}
                    value={data.c3}
                  />
                  <label class="custom-control-label" for="step3_chk4">
                    <strong>
                      <Text id="step3.Op4" />.
                    </strong>
                  </label>
                </div>
                {data.c3 === "INC" ? (
                  <React.Fragment>
                    <label for="attestation3">
                      <Text id="step3.releasedate"/>*
                      <input
                        id="attestation3"
                        name="attestation3"
                        class="form-control display-inline"
                        placeholder="MM/DD/YYYY"
                        maxLength="10"
                        value={data.attestation3}
                        onChange={this.props.handleDate}
                        onClick={(e) => this.props.handleDates("attestation3")}
                        class={
                          data.attestation3 === "" ||
                          !moment(
                            data.attestation3,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                      />
                    </label>
                  </React.Fragment>
                ) : null}
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk5"
                    name="c4"
                    value={data.c4}
                    disabled={
                      disableCheck === false || data.c4 === "RUS" ? false : true
                    }
                    checked={data.c4 === "RUS" ? true : false}
                    onChange={this.props.handleCheckbox}
                  />
                  <label class="custom-control-label" for="step3_chk5">
                    <strong>
                      <Text id="step3.Op5" />.
                    </strong>
                  </label>
                </div>
                {data.c4 === "RUS" ? (
                  <React.Fragment>
                    <label for="attestation4">
                      <Text id="step3.returndate"/>*
                      <input
                        id="attestation4"
                        name="attestation4"
                        class="form-control display-inline"
                        placeholder="MM/DD/YYYY"
                        maxLength="10"
                        value={data.attestation4}
                        onChange={this.props.handleDate}
                        onClick={(e) => this.props.handleDates("attestation4")}
                        class={
                          data.attestation4 === "" ||
                          !moment(
                            data.attestation4,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                      />
                    </label>
                  </React.Fragment>
                ) : null}
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk6"
                    name="c5"
                    value={data.c5}
                    disabled={
                      disableCheck === false || data.c5 === "LAW" ? false : true
                    }
                    checked={data.c5 === "LAW" ? true : false}
                    onChange={this.props.handleCheckbox}
                  />
                  <label class="custom-control-label" for="step3_chk6">
                    <strong>
                      <Text id="step3.Op6" />.
                    </strong>
                  </label>
                </div>
                {data.c5 === "LAW" ? (
                  <React.Fragment>
                    <label for="attestation5">
                     <Text id="step3.statusdate"/>*
                      <input
                        id="attestation5"
                        name="attestation5"
                        class="form-control display-inline"
                        placeholder="MM/DD/YYYY"
                        maxLength="10"
                        value={data.attestation5}
                        onChange={this.props.handleDate}
                        onClick={(e) => this.props.handleDates("attestation5")}
                        class={
                          data.attestation5 === "" ||
                          !moment(
                            data.attestation5,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                      />
                    </label>
                  </React.Fragment>
                ) : null}
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk7"
                    name="c6"
                    value={data.c6}
                    disabled={
                      disableCheck === false || data.c6 === "MDE" ? false : true
                    }
                    checked={data.c6 === "MDE" ? true : false}
                    onChange={this.props.handleCheckbox}
                  />
                  <label class="custom-control-label" for="step3_chk7">
                    <strong>
                      <Text id="step3.Op7" />.
                    </strong>
                  </label>
                </div>
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk8"
                    name="c7"
                    value={data.c7}
                    disabled={
                      disableCheck === false || data.c7 === "HLP" ? false : true
                    }
                    checked={data.c7 === "HLP" ? true : false}
                    onChange={this.props.handleCheckbox}
                  />
                  <label class="custom-control-label" for="step3_chk8">
                    <strong>
                      <Text id="step3.Op8" />.
                    </strong>
                  </label>
                </div>
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk9"
                    name="c8"
                    value={data.c8}
                    checked={data.c8 === "NLS" ? true : false}
                    onChange={this.props.handleCheckbox}
                    disabled={
                      disableCheck === false || data.c8 === "NLS" ? false : true
                    }
                  />
                  <label class="custom-control-label" for="step3_chk9">
                    <strong>
                      <Text id="step3.Op9" />.
                    </strong>
                  </label>
                </div>
                {data.c8 === "NLS" ? (
                  <React.Fragment>
                    <label for="attestation8">
                      <Text id="step3.extrahelp"/>*
                      <input
                        id="attestation8"
                        name="attestation8"
                        class="form-control display-inline"
                        placeholder="MM/DD/YYYY"
                        maxLength="10"
                        value={data.attestation8}
                        onChange={this.props.handleDate}
                        onClick={(e) => this.props.handleDates("attestation8")}
                        class={
                          data.attestation8 === "" ||
                          !moment(
                            data.attestation8,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                      />
                    </label>
                  </React.Fragment>
                ) : null}
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk10"
                    name="c9"
                    value={data.c9}
                    checked={data.c9 === "LTC" ? true : false}
                    onChange={this.props.handleCheckbox}
                    disabled={
                      disableCheck === false || data.c9 === "LTC" ? false : true
                    }
                  />
                  <label class="custom-control-label" for="step3_chk10">
                    <strong>
                      <Text id="step3.Op10" />
                      ).
                    </strong>
                  </label>
                </div>
                {data.c9 === "LTC" ? (
                  <React.Fragment>
                    <label for="attestation9"  class="attestmargin">
                    <Text id="step3.facilitydate"/>*
                      <input
                        id="attestation9"
                        name="attestation9"
                        class="form-control display-inline"
                        placeholder="MM/DD/YYYY"
                        maxLength="10"
                        value={data.attestation9}
                        onChange={this.props.handleDate}
                        onClick={(e) => this.props.handleDates("attestation9")}
                        class={
                          data.attestation9 === "" ||
                          !moment(
                            data.attestation9,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                      />
                    </label>
                  </React.Fragment>
                ) : null}
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk11"
                    name="c10"
                    value={data.c10}
                    checked={data.c10 === "PAC" ? true : false}
                    onChange={this.props.handleCheckbox}
                    disabled={
                      disableCheck === false || data.c10 === "PAC"
                        ? false
                        : true
                    }
                  />
                  <label class="custom-control-label" for="step3_chk11">
                    <strong>
                      <Text id="step3.Op11" />
                    </strong>
                  </label>
                </div>
                {data.c10 === "PAC" ? (
                  <React.Fragment>
                    <label for="attestation10">
                      <Text id="step3.pacedate"/>*
                      <input
                        id="attestation10"
                        name="attestation10"
                        class="form-control display-inline"
                        placeholder="MM/DD/YYYY"
                        maxLength="10"
                        value={data.attestation10}
                        onChange={this.props.handleDate}
                        onClick={(e) => this.props.handleDates("attestation10")}
                        class={
                          data.attestation10 === "" ||
                          !moment(
                            data.attestation10,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                      />
                    </label>
                  </React.Fragment>
                ) : null}
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk12"
                    name="c11"
                    value={data.c11}
                    disabled={
                      disableCheck === false || data.c11 === "LCC"
                        ? false
                        : true
                    }
                    checked={data.c11 === "LCC" ? true : false}
                    onChange={this.props.handleCheckbox}
                  />
                  <label class="custom-control-label" for="step3_chk12">
                    <strong>
                      <Text id="step3.Op12" />.
                    </strong>
                  </label>
                </div>
                {data.c11 === "LCC" ? (
                  <React.Fragment>
                    <label for="attestation11"  class="attestmargin">
                     <Text id="step3.drugdate"/>*
                      <input
                        id="attestation11"
                        name="attestation11"
                        class="form-control display-inline"
                        placeholder="MM/DD/YYYY"
                        maxLength="10"
                        value={data.attestation11}
                        onChange={this.props.handleDate}
                        onClick={(e) => this.props.handleDates("attestation11")}
                        class={
                          data.attestation11 === "" ||
                          !moment(
                            data.attestation11,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                      />
                    </label>
                  </React.Fragment>
                ) : null}
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk13"
                    name="c12"
                    checked={data.c12 === "LEC" ? true : false}
                    onChange={this.props.handleCheckbox}
                    disabled={
                      disableCheck === false || data.c12 === "LEC"
                        ? false
                        : true
                    }
                    value={data.c12}
                  />
                  <label class="custom-control-label" for="step3_chk13">
                    <strong>
                      <Text id="step3.Op13" />.
                    </strong>
                  </label>
                </div>
                {data.c12 === "LEC" ? (
                  <React.Fragment>
                    <label for="attestation12">
                     <Text id="step3.leavingdate"/>*
                      <input
                        id="attestation12"
                        name="attestation12"
                        class="form-control display-inline"
                        placeholder="MM/DD/YYYY"
                        maxLength="10"
                        value={data.attestation12}
                        onChange={this.props.handleDate}
                        onClick={(e) => this.props.handleDates("attestation12")}
                        class={
                          data.attestation12 === "" ||
                          !moment(
                            data.attestation12,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                      />
                    </label>
                  </React.Fragment>
                ) : null}
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk14"
                    name="c13"
                    disabled={
                      disableCheck === false || data.c13 === "PAP"
                        ? false
                        : true
                    }
                    checked={data.c13 === "PAP" ? true : false}
                    onChange={this.props.handleCheckbox}
                    value={data.c13}
                  />
                  <label class="custom-control-label" for="step3_chk14">
                    <strong>
                      <Text id="step3.Op14" />.
                    </strong>
                  </label>
                </div>
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk15"
                    name="c14"
                    disabled={
                      disableCheck === false || data.c14 === "EOC"
                        ? false
                        : true
                    }
                    value={data.c14}
                    checked={data.c14 === "EOC" ? true : false}
                    onChange={this.props.handleCheckbox}
                  />
                  <label class="custom-control-label" for="step3_chk15">
                    <strong>
                      <Text id="step3.Op15" />.
                    </strong>
                  </label>
                </div>
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk16"
                    name="c15"
                    checked={data.c15 === "SNP" ? true : false}
                    onChange={this.props.handleCheckbox}
                    disabled={
                      disableCheck === false || data.c15 === "SNP"
                        ? false
                        : true
                    }
                    value={data.c15}
                  />
                  <label class="custom-control-label" for="step3_chk16">
                    <strong>
                      <Text id="step3.Op16" />.
                    </strong>
                  </label>
                </div>
                {data.c15 === "SNP" ? (
                  <React.Fragment>
                    <label for="attestation15"  class="attestmargin">
                     <Text id="step3.SNPdate"/>*
                      <input
                        id="attestation15"
                        name="attestation15"
                        class="form-control display-inline"
                        placeholder="MM/DD/YYYY"
                        maxLength="10"
                        value={data.attestation15}
                        onChange={this.props.handleDate}
                        onClick={(e) => this.props.handleDates("attestation15")}
                        class={
                          data.attestation15 === "" ||
                          !moment(
                            data.attestation15,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                      />
                    </label>
                  </React.Fragment>
                ) : null}
              </li>
              {!(
                this.props.year === "2021" &&
                (this.props.selectedPlan === "SDAGCWD20" ||
                  this.props.selectedPlan === "SDAGC20" ||
                  this.props.selectedPlan === "SDAPC20")
              ) ? (
                <li class="list-group-item">
                  <div class="custom-control custom-checkbox custom-control-inline">
                    <input
                      type="checkbox"
                      class="custom-control-input attestmargin"
                      id="step3_chk17"
                      name="c16"
                      checked={data.c16 === "OTH" ? true : false}
                      onChange={this.props.handleCheckbox}
                      value={data.c16}
                      disabled={
                        disableCheck === false || data.c16 === "OTH"
                          ? false
                          : true
                      }
                    />
                    <label class="custom-control-label" for="step3_chk17">
                      <strong>Other:</strong>
                    </label>
                  </div>
                  {data.c16 === "OTH" ? (
                    <React.Fragment>
                      <input
                        type="text"
                        class="form-control"
                        name="c16Attestation "
                        value={data.c16Attestation}
                        onChange={this.props.handleChange}
                        class={
                          data.c16Attestation === ""
                            ? "error-input"
                            : "form-control"
                        }
                      />
                      <label for="attestation16"  class="attestmargin">
                      <Text id="step3.insertdate"/>*
                        <input
                          id="attestation16"
                          class="form-control display-inline"
                          placeholder="MM/DD/YYYY"
                          maxLength="10"
                          name="attestation16"
                          value={data.attestation16}
                          onChange={this.props.handleDate}
                          onClick={(e) =>
                            this.props.handleDates("attestation16")
                          }
                          class={
                            data.attestation16 === "" ||
                            !moment(
                              data.attestation16,
                              "MM/DD/YYYY",
                              true
                            ).isValid()
                              ? "error-input"
                              : "form-control"
                          }
                        />
                      </label>
                    </React.Fragment>
                  ) : null}
                </li>
              ) : (
                <React.Fragment>
                  <li class="list-group-item">
                    <div class="custom-control custom-checkbox custom-control-inline">
                      <input
                        type="checkbox"
                        class="custom-control-input"
                        id="step3_chk22"
                        name="c22"
                        checked={data.c22 === "MCD" ? true : false}
                        onChange={this.props.handleCheckbox}
                        disabled={
                          disableCheck === false || data.c22 === "MCD"
                            ? false
                            : true
                        }
                        value={data.c22}
                      />
                      <label class="custom-control-label" for="step3_chk22">
                        <strong>
                          <Text id="step3.Op17" />{" "}
                        </strong>
                      </label>
                    </div>
                    {data.c22 === "MCD" ? (
                      <React.Fragment>
                        <label for="recentlyChangeMedicaid">
                        <Text id="step3.disrolldate"/>*
                          <input
                            id="recentlyChangeMedicaid"
                            name="recentlyChangeMedicaid"
                            class="form-control display-inline"
                            placeholder="MM/DD/YYYY"
                            maxLength="10"
                            value={data.recentlyChangeMedicaid}
                            onChange={this.props.handleDate}
                            onClick={(e) =>
                              this.props.handleDates("recentlyChangeMedicaid")
                            }
                            class={
                              data.recentlyChangeMedicaid === "" ||
                              !moment(
                                data.recentlyChangeMedicaid,
                                "MM/DD/YYYY",
                                true
                              ).isValid()
                                ? "error-input"
                                : "form-control"
                            }
                          />
                        </label>
                      </React.Fragment>
                    ) : null}
                  </li>
                  <li class="list-group-item">
                    <div class="custom-control custom-checkbox custom-control-inline">
                      <input
                        type="checkbox"
                        class="custom-control-input"
                        id="step3_chk23"
                        name="c23"
                        checked={data.c23 === "HLP" ? true : false}
                        onChange={this.props.handleCheckbox}
                        disabled={
                          disableCheck === false || data.c23 === "HLP"
                            ? false
                            : true
                        }
                        value={data.c23}
                      />
                      <label class="custom-control-label" for="step3_chk23">
                        <strong>
                          <Text id="step3.Op18" />
                        </strong>
                      </label>
                    </div>
                    {data.c23 === "HLP" ? (
                      <React.Fragment>
                        <label for="attestation23">
                        <Text id="step3.insertdate"/>*
                          <input
                            id="attestation23"
                            name="attestation23"
                            class="form-control display-inline"
                            placeholder="MM/DD/YYYY"
                            maxLength="10"
                            value={data.attestation23}
                            onChange={this.props.handleDate}
                            onClick={(e) =>
                              this.props.handleDates("attestation23")
                            }
                            class={
                              data.attestation23 === "" ||
                              !moment(
                                data.attestation23,
                                "MM/DD/YYYY",
                                true
                              ).isValid()
                                ? "error-input"
                                : "form-control"
                            }
                          />
                        </label>
                      </React.Fragment>
                    ) : null}
                  </li>
                  <li class="list-group-item">
                    <div class="custom-control custom-checkbox custom-control-inline">
                      <input
                        type="checkbox"
                        class="custom-control-input"
                        id="step3_chk17"
                        name="c25"
                        value={data.c25}
                        disabled={
                          disableCheck === false || data.c25 === "DST"
                            ? false
                            : true
                        }
                        checked={data.c25 === "DST" ? true : false}
                        onChange={this.props.handleCheckbox}
                      />
                      <label class="custom-control-label" for="step3_chk17">
                        <strong>
                          <Text id="step3.Op19" />.
                        </strong>
                      </label>
                    </div>
                  </li>
                </React.Fragment>
              )}
            </ul>
            <p class="mt-3">
              <Text id="step3.Para4"/>.
            </p>
            <p>
              <strong><Text id="step3.NOTE"/>:</strong> <Text id="step3.notePart"/>.
            </p>
            {!(
              this.props.year === "2021" &&
              (this.props.selectedPlan === "SDAGCWD20" ||
                this.props.selectedPlan === "SDAGC20" ||
                this.props.selectedPlan === "SDAPC20")
            ) ? (
              <button
                class="btn btn-saveNext"
                id="next3"
                style={{ backgroundColor: "#603167" }}
                onClick={this.props.redirect}
              >
                <Text id="app.Save_Next"/>
              </button>
            ) : null}
          </div>
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    year: state.webApp.year,
  };
};
export default connect(mapStateToProps)(Step3);
