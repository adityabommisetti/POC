import React, { Component } from "react";
import Banner from "../Utils/GenericUI/Banner.jsx";
import { header, Body } from "../Utils/StaticData/EnrollStepsStaticData";
import history from "../Utils/History";
import { BrowserRouter } from "react-router-dom";
import Footer1 from "../Utils/GenericUI/Footer1";
import { Text } from "react-internationalization";
import { connect } from "react-redux";
const ie =
  navigator.userAgent.indexOf("MSIE") > -1 ||
  navigator.userAgent.indexOf("rv:") > -1;

class EnrollSteps extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  redirect = (event) => {
    event.preventDefault();
    history.push("/webapp/Sharp/Individual/userCreation");
  };
  render() {
    return (
      <BrowserRouter>
        <div class="jumbotron">
          <Banner header={header} Body={Body} />
          <div class="container mt-3">
            <div class="form-group row">
              <div class="col-md-4">
                <div class="enrollment-steps">
                  <div class="enrollment-steps--header  step-1">
                    <div class="enrollment-steps--header-label"><Text id="enroll.Step1"/></div>
                    <div class="triangle-right"></div>
                  </div>
                  <div class="enrollment-steps--body  step-1" style={{height: '530px'}}>
                    <div class="es-content-block">
                      <p class="enroll-content-heading"><Text id="enroll.choose"/></p><br />
                      <p class="enroll-content"><Text id="enroll.st1sub1"/>.</p>
                      <p class="enroll-content"><Text id="enroll.st1sub2"/>.</p>
                      <p class="enroll-content"><Text id="enroll.st1sub2"/>.</p>
                      <p class={
                      this.props.lang==="es"?(ie?"text-center iesp_margin-top3p5":
                      "text-center sp_margin-top3p5"):"text-center margin-top3p5"} ><a class="btn-esb btn-esb-teal" href="https://www.sharpmedicareadvantage.com/our-plans/explore-our-plans"><Text id="enroll.Browse"/></a></p>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-md-4">
                <div class="enrollment-steps"><div class="enrollment-steps--header  step-2">
                  <div class="enrollment-steps--header-label"><Text id="enroll.Step2"/></div>
                  <div class="triangle-right"></div></div>
                  <div class="enrollment-steps--body  step-2" style={{height: '530px'}}>
                    <div class="es-content-block">
                      <p class="enroll-content-heading"><Text id="enroll.gather"/></p>
                      <p class="enroll-content"><Text id="enroll.st2sub1"/>:</p>
                      <p class="enroll-content"><strong>1.<Text id="enroll.st1"/></strong></p>
                      <p class="enroll-content"><strong>2. <Text id="enroll.st2"/></strong></p>
                      <p class="enroll-content"><Text id="enroll.st2sub2"/>.</p>
                      <p class={this.props.lang==="es"?(ie?"text-center iesp_margin-top1p5":"text-center sp_margin-top1p5"):
                      ie?"text-center ieneg_margin":"text-center margin-top1p5"} ><a class="btn-esb btn-esb-teal" href=" https://www.sharpmedicareadvantage.com/find-a-doctor-or-pharmacy"><Text id="enroll.dr"/></a></p>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-md-4">
                <div class="enrollment-steps">
                  <div class="enrollment-steps--header  step-3">
                    <div class="enrollment-steps--header-label"><Text id="enroll.Step3"/></div>
                    <div class="triangle-right"></div>
                  </div>
                  <div class="enrollment-steps--body  step-3" style={{height: '530px'}}>
                    <div class="es-content-block">
                      <p class="enroll-content-heading"><Text id="enroll.start"/></p><br />
                      <p class="enroll-content"><Text id="enroll.st3sub1"/>.</p>
                      <p class="enroll-content"><Text id="enroll.st3sub2"/>.</p>
                      <p class={
                      this.props.lang==="es"?(ie?"text-center iesp_margin-top5p5":"text-center sp_margin-top5p5"):"text-center margin-top5p5"}>
                        <a class="btn-esb btn-esb-teal"
                          id="get-started-id"
                          onClick={this.redirect}><Text id="enroll.getst"/></a></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <Footer1 />
        </div>
      </BrowserRouter>
    );
  }
}
const mapStateToProps = (state) => {
  return { 
    lang:state.webApp.language
  };
};
const mapDispatchToProps = {

};
export default connect(mapStateToProps,mapDispatchToProps)(EnrollSteps);
