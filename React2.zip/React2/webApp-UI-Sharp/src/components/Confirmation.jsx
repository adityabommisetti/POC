import React from "react";
import { connect } from "react-redux";
import Footer1 from "../Utils/GenericUI/Footer1.jsx";
import { Text } from "react-internationalization";
import Form1 from "./Form1";
import Form2 from "./Form2";
import Form3 from "./Form3";
import { useState, useEffect } from "react";
import html2pdf from "html2pdf.js";

const Confirmation = (props) => {

  const [downloadLink, setLink] = useState(false);

  const downloadPDF = () => {
    
    setLink(true);

   
    
  }
  return (
    <React.Fragment>
      <div class="jumbotron" style={{ paddingBottom: "0vh" }}>
        <div class="container">
          <div class="enroll-header-content enroll-header-bg">
            <h2>{props.year} <Text id="header.confirmationHeader"/></h2>
            <p>
            <Text id="header.confirmationHeaderPara1"/>
              {props.count}<Text id="header.confirmationHeaderPara2"/>
            </p>
            <p align="center">
              <button
                class="btn-shp btn-shp-teal-download"
                id="downloadPdf"
                // href={
                //   process.env.NODE_ENV === "development"
                //     ? "https://techrefresh.medadvantage360.com/webapp-api/sharp/individual/Download"
                //     : "/webapp-api/sharp/individual/Download"
                // }
                onClick={downloadPDF}
                target="_blank"
              >
                <Text id="header.downloadPdf"/>
              </button>
            </p>
            <p>
              {(props.selectedPlan === "SDAHMO1" || props.selectedPlan === "SDAHMO20") ?
              <React.Fragment>
              <h2><Text id="header.nextStep"/></h2>
              <ul style={{textAlign: "left"}}>
                <li><Text id="header.nextStep1"/></li>
                <li><Text id="header.nextStep2"/></li>
                <li><Text id="header.nextStep3"/></li>
              </ul>
              </React.Fragment>
              : null}
            </p>
          </div>
        </div>
      </div>
      {props.year == "2021" ?(
      downloadLink ? 
      
      ((props.selectedPlan === "SDAGC20" || props.selectedPlan === "SDAGCWD20" 
      ||props.selectedPlan === "SDAPC20") ?
      
      (<Form1 data={props.preEnrollInfo} downloadLink=
      {downloadLink} selectedPlan={props.selectedPlan} count={props.count} />) :
      
    (props.selectedPlan === "SDAB20" || props.selectedPlan === "SDABWD20" 
							||props.selectedPlan === "SDAP20" || props.selectedPlan === "SDAPWD20")
?       
      
(<Form2 data={props.preEnrollInfo} downloadLink=
  {downloadLink} selectedPlan={props.selectedPlan} count={props.count} />) :

 (props.selectedPlan === "SDAHMO1" || props.selectedPlan === "SDAHMO20")  ?

     (<Form3 data={props.preEnrollInfo} downloadLink=
  {downloadLink} selectedPlan={props.selectedPlan} count={props.count} />) : null)
      
      : null) : null}

      

      <Footer1 />
    </React.Fragment>
  );
};

const mapStateToProps = (state) => {
  return {
    count: state.webApp.count,
    year: state.webApp.year,
    selectedPlan: state.webApp.selectedPlan,
    preEnrollInfo: state.webApp.preEnrollInfo,
  };
};
const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(Confirmation);
