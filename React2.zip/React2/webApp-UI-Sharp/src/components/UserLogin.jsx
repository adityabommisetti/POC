import React, { Component } from "react";
import Banner from "../Utils/GenericUI/Banner.jsx";
import { header, Body } from "../Utils/StaticData/UserLoginStaticData";
import { login } from "../Redux/Actions/webAppActions";
import RemoveRedEyeIcon from "@material-ui/icons/RemoveRedEye";
import history from "../Utils/History";
import Footer1 from "../Utils/GenericUI/Footer1";
import { Text } from "react-internationalization";

import { connect } from "react-redux";
class UserLogin extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: "",
      password: "",
      showPassword: false,
      passwordEye: false,
      emailError: false,
      passwordError: false,
    };
  }
  componentDidMount() {
    window.scroll(0, 0);
  }

  handleChange = (event) => {
    const name = event.target.name;
    const value = event.target.value;
    const emailError = name === "email" && value === "";
    const passwordError = name === "password" && value === "";

    this.setState({
      [name]: value,
      emailError: emailError,
      passwordError: passwordError,
    });
  };

  handleFocus = (name) => (event) => {
    event.preventDefault();

    this.setState({
      passwordEye: true,
    });
  };

  handleOnBlur = (name) => (event) => {
    event.preventDefault();
    const { email, password, showPassword } = this.state;
    const emailError = name === "email" && email === "";
    const passwordError = name === "password" && password === "";

    this.setState({
      emailError: emailError,
      passwordError: passwordError,
      passwordEye: showPassword,
    });
  };

  showPassword = (name, toggle) => (event) => {
    document.getElementById(name).focus();

    this.setState({
      passwordEye: true,
      showPassword: toggle,
    });
  };

  login = async (e) => {
    e.preventDefault();
    const { email, password } = this.state;

    const emailError = email === "";

    const passwordError = password === "";

    if (emailError) {
      let msg=this.props.lang==="es"?"El correo electrónico no puede estar vacío":"Email cannot be empty"
      alert(msg);
      return;
    }
    if (passwordError) {
      let msg=this.props.lang==="es"?"La contraseña no puede estar vacía":"Password cannot be empty"
      alert(msg);
      return;
    }
    let body = {
      emailAddress: email,
      password: password,
    };

    body = { ...body, customerId: "HCF0331" };
    const login = await this.props.login(body);
    if (login.message === "SUCCESS")
      history.push("/webapp/Sharp/Individual/yearSelection");
    else alert(login.message);
  };

  forgotPassword = (event) => {
    event.preventDefault();
    history.push("/webapp/Sharp/Individual/userPwdReset");
  };
  render() {
    const {
      email,
      password,
      showPassword,
      passwordEye,
      emailError,
      passwordError,
    } = this.state;
    return (
      <div id="userLogin">
        <Banner header={header} Body={Body} />
        <div class="container mt-3">
          <form onSubmit={this.login}>
            <div class="tab-content">
              <div class="container form-panel">
                <div class="form-group row">
                  <div class="col-md-12">
                    <label
                      for="emailAddress"
                      class={emailError ? "error-label" : "control-label"}
                    >
                      <Text id="user.emailAdd"/>*
                    </label>

                    <input
                      type="email"
                      name="email"
                      placeholder="john.smith@mail.com"
                      class={emailError ? "error-input" : "form-control"}
                      value={email}
                      onChange={this.handleChange}
                      onBlur={this.handleOnBlur("email")}
                    />
                    <br />
                    <label
                      for="password"
                      class={passwordError ? "error-label" : "control-label"}
                    >
                     <Text id="user.pwd"/>*
                    </label>
                    <input
                      type={showPassword ? "text" : "password"}
                      id="password"
                      name="password"
                      class={passwordError ? "error-input" : "form-control"}
                      value={password}
                      onFocus={this.handleFocus("password")}
                      onBlur={this.handleOnBlur("password")}
                      onChange={this.handleChange}
                    />
                    {passwordEye ? (
                      <div
                        class="eyeIcon-password"
                        onMouseUp={this.showPassword("password", false)}
                        onMouseDown={this.showPassword("password", true)}
                        onMouseOut={this.showPassword("password", false)}
                      >
                        <RemoveRedEyeIcon />
                      </div>
                    ) : null}
                    <br />
                  </div>
                </div>
                <div class="button-container-login-page" style={{marginTop : '30px'}}>
                  <button
                    class="btn btn-login"
                    id="signup"
                    onClick={this.login}
                  >
                    <Text id="user.login"/>
                  </button>
                  <div class="forgot-password">
                    <p>
                      <Text id="user.forget"/>
                      <a
                        href="#none"
                        class="reset-password-here"
                        onClick={this.forgotPassword}
                      >
                        <Text id="user.rtpwd"/>
                      </a>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
        <Footer1 />
      </div>
    );
  }
}
const mapStateToProps = (state) => {
  return {lang:state.webApp.language,
  };
};
const mapDispatchToProps = {
  login,
};
export default connect(mapStateToProps, mapDispatchToProps)(UserLogin);
