const en = {
  app: {
    lang: "Change Language",
    FirstName: "First Name*",
    Sex: "Sex*",
    Prefix: "Prefix",
    LastName: "Last Name*",
    BirthDate: "Birth Date*",
    MI: "MI",
    PrimaryPhoneNumber: "Primary Phone Number*",
    CellPhoneNumber: "Cell Phone Number",
    Instructions: "Instructions to fill out this form",
    PermanentAddress: "Permanent Residence Street Address",
    POBox: "Don't enter a PO Box",
    HomeNumber: "Home Phone Number",
    Optionalfield: "Optional field",
    City: "City",
    County: "County",
    State: "State",
    ZIPCode: "ZIP Code",
    MedicareNo: "Medicare Number",
    Name: "Name",
    DigitalSignature: "Digital Signature",
    TodayDate: "Today's Date",
    drugCoverage:
      "Will you have other drug coverage (like VA, TRICARE) in addition to Sharp Health Plan?",
    Yes: "Yes",
    No: "No",
    authorizedrepresentative: "Are you an authorized representative?",
    authorized:
      "If you are the authorized representative, you must sign above and provide the following information",
    License: "Are you working with a Licensed Sales Representative?",
    NOTE: "NOTE",
    notePart:
      "You may save and continue without completing all required fields (*); however, all required fields must be completed before submitting the enrollment form",
      Save_Next:"Save and Next",
      STEP1:"STEP 1",
      PERSONALINFO:"PERSONAL INFORMATION",
      APara:"A. To enroll in Sharp Health Plan please provide the following information",
      Effectdate:"Effective date of coverage",
      Socialnumber:"Social security number",
      mailingaddress:"Is the above address different from your mailing address ?",
      Please:"Please call me about the Sharp Health Plan Medical Plan",
      news:"  Yes, I'd like to receive health plan news and information via email",
      news1:"Yes, I'd like to receive health plan news and information via email or text message."+
        "(Message &  data rates may apply)",
     
      stepSub:"All fields on this page are required (unless marked optional)",
      imp:"IMPORTANT",
      impsub:"Read and sign below",
      imp1:" I must keep both Hospital (Part A) and Medical (Part B) to stay in Sharp Health Plan",
      imp2:"By joining this Medicare Advantage Plan, I acknowledge that Sharp Health Plan will share my "+
      "information with Medicare, who may use it to track my enrollment, to make payments, and for other "+
      "purposes allowed by Federal law that authorize the collection of this information (see Privacy Act"+
      "Statement below)",
      imp3:"Your response to this form is voluntary. However, failure to respond may affect enrollment in the plan",
      imp4:"The information on this enrollment form is correct to the best of my knowledge. I understand that if I"+
      " intentionally provide false information on this form, I will be disenrolled from the plan",
      imp5:"I understand that people with Medicare are generally not covered under Medicare while out of the country, "+
      "except for limited coverage near the U.S. border",
      imp6:'I understand that when my Sharp Health Plan coverage begins, I must get all of my medical and '+
      'prescription drug benefits from Sharp Health Plan. Benefits and services provided by Sharp Health Plan '+
      'and contained in my Sharp Health Plan "Evidence of Coverage" document (also known as a member contract'+
      'or subscriber agreement) will be covered. Neither Medicare nor Sharp Health Plan will pay for benefits '+
      'or services that are not covered',
      imp7:"I understand that my signature (or the signature of the person legally authorized to act on my behalf)"+
        "on this application means that I have read and understand the contents of this application. If "+
        "signed by an authorized representative (as described above), this signature certifies that",
      Male:"Male",
      Female:"Female",
      coverage:"Name of other coverage",
      mebernumber:"Member number for this coverage",
      groupNo:"Group number for this coverage",

      maillingAdd:"Mailing Address- Street Address/P.O.Box:(Only if different from your Permanent Residential Address)",
      email:"Email Address",
      Enrollee:"Relationship to Enrollee",
      address:"Address",
      phno:"Phone Number",
      sale:"Sales Representative Name",
      Licenseno:"Sales Representative License Number",
      save:"Save and Logout",
      submit:"Submit",

      error1:"We're missing a few pieces of information. Please check",
      error2:"for red highlighted fields. When all required information has been entered, the submit button will display in green",
      cong:" Congratulations! Your Medicare form is complete, please press SUBMIT to finish",

    online:"Online Individual Enrollment Form V1",
    enroll:"SHC Enrollment Form_M V1",

    Mr:"Mr",
      Mrs:"Mrs",
      Ms:"Ms",

      foot1:" Sharp Health Plan is an HMO plan with a Medicare contract. Enrollment in Sharp Health Plan depends on contract renewal",
      foot2:" Read the full disclaimer",
      foot3:"Online Individual Enrollment Form",
      foot4:"Page Last Updated",
      Step:"Step",

      newfooter:"According to the Paperwork Reduction Act of 1995, "+
      "no persons are required to respond to a collection "+
      "of information unless it displays a valid OMB control number. "+
      "The valid OMB control number for this information collection is 0938-NEW. "+
      "The time required to complete this information is estimated to average 20 minutes per response, "+
      "including the time to review instructions, search existing data resources, "+
      "gather the data needed, and complete and review the information collection. "+
      "If you have any comments concerning the accuracy of the time estimate(s) "+
      "or suggestions for improving this form, please write to: CMS, "+
      "7500 Security Boulevard, Attn: PRA Reports Clearance Officer, "+
      "Mail Stop C4-26-05, Baltimore, Maryland 21244-1850",


      san:"Are you the City of San Diego retiree?",
      san1:"yes, Are you covering a spouse or dependent ?",
      san2:" (If yes, complete section below.)",
      san3:" Dependent of City of San Diego Retiree",
      MiddleInitial:" Middle Initial",
      san4:" If you are not, employee name",
      san6:"If your spouse/dependent is not eligible for Medicare, then he/she will need"+
      "to complete the Non-Medicare / Early Retiree"+
      "enrollment form. Please contact SDPEBA at"+
      "1-888-315-8027 or visit www.sdpeba.org to download  the enrollment form",

    san7:"If you are not, are you the surviving spouse of a City of San Diego Retiree?",
    rtlast:"Retiree Last Name",
    rtfirst:"Retiree First Name",
    rtmiddle:"Retiree Middle Initial",
    san8:"If your spouse/dependent is not eligible for Medicare, then he/she will need"+
    "to complete the Non-Medicare / Early Retiree enrollment form. Please contact SDPEBA at"+
    "1-888-315-8027 or visit www.sdpeba.org to download the enrollment form"


  },
  inst: {
    head:"Instructions to fill out this form",
    i1: "Who can use this form?",
    i2: "People with Medicare who want to join a Medicare Advantage Plan",
    i3: "To join a plan, you must:",
    i4: "Be a United States citizen or be lawfully present in the U.S.",
    i5: "Live in the plan's service area",
    i6: "Important",
    i7: ": To join a Medicare Advantage Plan, you must also have both:",
    i8: "Medicare Part A (Hospital Insurance)",
    i9: "Medicare Part B (Medical Insurance)",
    i10: "When do I use this form?",
    i11: "You can join a plan:",
    i12:
      "Between October 15–December 7 each year (for coverage starting January 1)",
    i13: "Within 3 months of first getting Medicare",
    i14: "In certain situations where you’re allowed to join or switch plans",
    i15: "Reminders:",
    i16:
      "If you want to join a plan during fall open enrollment (October 15–December 7), the plan must get your completed form by December 7.",
    i17:
      "Your plan will send you a bill for the plan's premium. You can choose to sign up to have your premium payments deducted from your bank account or your monthly Social Security (or Railroad Retirement Board) benefit.",
    i18: "What do I need to complete this form?",
    i19:
      " Your Medicare Number (the number on your red, white, and blue Medicare card)",
    i20: "Your permanent address and phone number.",
    i21:
      "You must complete all items in Section 1. The items in Section 2 are optional — you can't be denied coverage because you don't fill them",
    i22: "Note:",

    i23:"If you and your spouse are both applying, you'll each need to fill out a separate form. For help completing the enrollment form, email us at medicaresales@sharp.com or call us at 1-855-562-8853 (TTY/TDD: 711) to complete your enrollment over the phone",
    // i24:"For Gold with Dental and Platinum Plans add",
    i25:"The comprehensive dental coverage is provided through DeltaCare USA, an HMO-type plan offered by Delta Dental of California. You will be auto-assigned a network dentist in your area. If you would like to change to another network provider, contact Delta Dental",
    i26:"When do I use this form?",
    i27:"Call Sharp Health Plan at 1-855-562-8853. TTY users can call 711",
    i28:"Or, call Medicare at 1-800-MEDICARE (1-800-633-4227). TTY users can call 1-877-486-2048",
    i29:"What happens next?",
    i30:"Be sure to answer all questions",
    i31:"Be sure you have read all the pages before you submit your enrollment form to Sharp Health Plan",
    i32:"Once we process your request to join, we'll contact you",
  },
  step2: {
    Step2: "Step 2",
    Spanish:" Spanish",
    subStep: "All fields on this page are optional",
    A:
      "Answering these questions is your choice. You can’t be denied coverage because you don’t fill them out",
    A1:
      "Select one if you want us to send you information in a language other than English",
    A2:
      "Select one if you want us to send you information in an accessible format",
    Ar1: "Braille",
    Ar2: "Large Print",
    Ar3: "Other",
    B: "Please choose a Primary Care Physician (PCP)",
    B1: "Need to find a doctor? Visit",
    B2: "to use our online search tool",
    PCPName: "PCP Name",
    ClinicName: "Clinic Name",
    currentpatient: "Are you a current patient?",
    Dowork: "Do you work?",
    spousework: "Does your spouse work?",
    Email: "E-mail Address",
    EmailOption: "Email Option Ind",
    Para1:"Please contact Sharp Health Plan at",
    Para2:"if you need information in an accessible format other than what’s listed above. Our office hours are . TTY users can call 711.",
    Para3:"Paying your plan premiums",
    Para4:" You can pay your monthly plan premium (including any late "+
      "enrollment penalty that you currently have or may owe) by"
+     " mail, Electronic Funds Transfer (EFT) or credit card each month",
    Para5:"You can also choose to pay your premium by having it automatically taken out of your Social Security or Railroad Retirement Board (RRB) benefit each month",
    Para6:"If you have to pay a Part D-Income Related Monthly "+
    "Adjustment Amount (Part D-IRMAA), you must pay this "+
    "extra amount in addition to your plan premium",
    Para7:"The amount is usually taken out of your Social Security"+
    "benefit, or you may get a bill from Medicare (or the RRB)."+
    "DON'T pay Sharp Health Plan the Part D-IRMAA",
    STEP2:"STEP 2",
    MEDICAREINFO:"MEDICARE INFORMATION",
    PleasePara:"Please Provide Your Medicare Insurance Information",
    Note:"Note",
    notePart:"You must have Medicare Part A and Part B to join a Medicare Advantage plan",
    APara:"A. Please fill in these blanks so they match your red, white and blue Medicare card",
    MedicareNumber:"Medicare Number",
    Hospi:"Hospital (Part A) Effective Date",
    Medical:"Medical (Part B) Effective Date",
    BPara:"B. Paying Your Plan Premium",
    Para8:'If we determine that you owe a late enrollment penalty (or if '+
      'you currently have a late enrollment penalty), we need to know '+
      'your payment preference. You can pay by mail, "Electronic Funds '+
      'Transfer (EFT)", or "credit card" each month',
    Para9:"If you are assessed a Part D-Income Related Monthly Adjustment "+
    "Amount(Part D-IRMAA), you will be notified by the Social "+
    "Security Administration. You will be responsible for paying this "+
    "extra amount in addition to your plan premium. You will either "+
    "have the amount with held from your Social Security benefit "+
    "check or be billed directly by Medicare or the RRB. DO NOT pay "+
    "Sharp Health Plan the Part D-IRMAA",
    Para10:"People with limited incomes may qualify for Extra Help to pay for "+
    "their prescription drug costs. If eligible, Medicare could pay for "+
    "75% or more of your drug costs including monthly prescription drug "+
    "premiums, annual deductibles and coinsurance. Additionally, those "+
    "who qualify will not be subject to the coverage gap or a late "+
    "enrollment penalty. Many people are eligible for these savings and "+
    "don't even know it. For more information about this Extra Help, "+
    "contact your local Social Security office or call Social Security "+
    "at 1-800-772-1213.TTY/TDD users should call 1-800-325-0778.You can "+
    "also apply for Extra Help online at "+
    "www.socialsecurity.gov/prescriptionhelp",
    Para11:"If you qualify for Extra Help with your Medicare prescription drug "+
    "coverage costs, Medicare will pay all or part of your plan premium "+
    "If Medicare pays only a portion of this premium, we will bill you "+
    "for the amount that Medicare doesn't cover",
    paymentoption:"Please select a premium payment option",
    Getbill:"Get a bill (if a payment applies, you will be able to pay by check or credit card monthly)",
    Electronicfunds:"Electronic funds transfer (EFT) from your bank account on "+
                    "the 1st of each month. If the 1st of the month falls on a "+
                    "weekend or bank holiday, your draft will occur on the next "+
                    "banking day",
    Accountname:"Account holder name",
    Bankname :"Bank name",
    Accounttype :"Account type",
    routingnumber:"Bank routing number",
    Bankaccountnumber:"Bank account number",
    Checking:"Checking",
    Saving:"Saving",
    C:"C. Please read and answer these important questions",
    q1:"Are you the retiree?",
    q2:"Are you covering a spouse or dependents(s) under this employer?",
    q3:"Do you or your spouse work?",
    q4:"Do you have End Stage Renal Disease (ESRD)?",
    q5:"Some individuals may have other drug coverage, including other private insurance, TRICARE, Federal employee health benefits coverage, VA benefits, or State pharmaceutical assistance programs. Will you have other prescription drug coverage in addition to Sharp Health Plan?",
    q6:"Are you a resident in a long-term care facility, such as a nursing home?",
    q7:"Please choose a Primary Care Physician (PCP)",
    q7Part:"Are you a current patient?",
    MedicalGroup:"PCP Medical Group",
    q8:"Please check one of the boxes below if you would prefer us to send you information in a language other than English or in another format",
    q8rod1:"Spanish",
    q8rod2:"Braille",
    q8rod3:"Large Print",
    q8rod4:"Other",
    Para12:"Please contact Sharp Health Plan at 1-855-562-8853 if you need "+
    "information in an accessible format or language other than what is "+
    "listed above. Our office hours are 8 a.m. to 8 p.m. 7 days per week "+
    "from October 1 to March 31: 7 days per week 8 a.m. to 8 p.m. From "+
    "April 1 to September 30: Monday through Friday, 8 a.m. to 8 p.m. and "+
    "on weekends and holidays, your call will be handled by our voicemail "+
    "system. A Customer Care Representative will return your phone call "+
    "the next business day. TTY/TDD users should call 711",
    Para13:"Sharp Health Plan provides the Evidence of Coverage, Formulary and Provider Directory online at",
    Para14:"Members can request a paper copy be mailed to them by calling Customer Care at the phone number listed above",
    NOTECAp:"NOTE",
    NOTECApPart:"You may save and continue without completing all required fields (*); however, all required fields must be completed before submitting the enrollment form",
    sharplink:"sharpmedicareadvantage.com",
    link2:"sharpmedicareadvantage.com/findadoctor",





  },

  step3: {
    Exhibit1a: "Exhibit 1a",
    stepsub:
      "Information to include on or with Enrollment Mechanism - Attestation of Eligibility for an Enrollment Period",
      Para1:"Typically, you may enroll in a Medicare Advantage Plan during "+
      "the annual enrollment period which is from October 15 through "+
      "December 7 of each year",
      Para2:"There are exceptions that allow you to enroll in a Medicare Advantage Plan outside of this period",
      Para3:"Please read the following statements carefully and check the box "+
      "if the statement applies to you. By checking any of the following "+
      "boxes you are certifying that, to the best of your knowledge, you "+
      "are eligible for an enrollment period. If we later determine that "+
      "this information is incorrect, you may be disenrolled",
      other:"Other:",
    Op1:
      "I am switching Medicare plans during the Annual Election Period of October 15 - December 7",
    Op1sub: "If yes, your effective date of coverage will be January 1",
    Op2: "I am new to Medicare",
    Op3:
      "I recently moved outside of the service area for my current plan or I recently moved and this plan is a new option for me",
    Op4: "I recently was released from incarceration",
    Op5:
      "I recently returned to the United States after living permanently outside of the U.S",
    Op6: "I recently obtained lawful presence status in the United States",
    Op7:
      "I have both Medicare and Medicaid (or my state helps pay for my Medicare premiums) or I get Extra Help paying for my Medicare prescription drug coverage, but I haven't had a change",
    Op8: "I get Extra Help paying for Medicare prescription drug coverage",
    Op9:
      "I no longer qualify for Extra Help paying for my Medicare prescription drugs",
    Op10:
      "I am moving into, live in , or recently moved out of a Long-Term Care Facility (for example, a nursing home or long term care facility)",
    Op11: "I recently left a PACE program",
    Op12:
      "I recently involuntarily lost my creditable prescription drug coverage (coverage as good as Medicare's)",
    Op13: "I am leaving employer or union coverage",
    Op14: "I belong to a pharmacy assistance program provided by my state",
    Op15:
      "My plan is ending its contract with Medicare or Medicare is ending its contact with my plan",
    Op16:
      "I was enrolled in a Special Needs Plan (SNP) but I have lost the special needs qualification required to be in that plan",
    Op17:
      "I recently had a change in my Medicaid (newly got Medicaid, had a change in level of Medicaid assistance, or lost Medicaid",
    Op18:
      "I recently had a change in my Extra Help paying for Medicare prescription drug coverage (newly got Extra Help, had a change in the level of Extra Help, or lost Extra Help",
    Op19:
      "I was affected by a weather-related emergency or major disaster (as declared by the Federal Emergency Management Agency (FEMA). One of the other statements here applied to me, but I was unable to make my enrollment because of the natural disaster",
    NOTE: "NOTE",
    Para4:"If none of these statements apply to you or you're not sure, "+
    "please contact Sharp Health Plan at 1-855-562-8853 (TTY/TDD users "+
    "should call 711) to see if you are eligible to enroll. We are open "+
    "from October 1 to March 31: 7 days per week 8 a.m. to 8 p.m. From "+
    "April 1 to September 30: Monday through Friday, 8 a.m. to 8 p.m. "+
    "and on weekends and holidays, your call will be handled by our "+
    "voicemail system. A Customer Care Representative will return your "+
    "phone call the next business day",
    notePart:"You may save and continue without completing all required fields (*); however, all required fields "+
    "must be completed before submitting the enrollment form",
    optAnth1:"I am a former employee or spouse/domestic partner/dependent of a former employee of Sharp HealthCare and I am not actively employed by Sharp HealthCare",
    Step3sub:"ATTESTATION OF ELIGIBILITY FOR AN ENROLLMENT PERIOD",
    step3:"STEP 3",



    movedate:"I moved on (insert date)",
    releasedate:"I was released on (insert date)",
    returndate:"I returned to the U.S. on (insert date)",
    statusdate:"I got this status on (insert date)",
    extrahelp:"I stopped receiving extra help on (insert date)",
    facilitydate:"I moved/will move into/out of the facility on (insert date)",
    pacedate:"I left PACE program on (insert date)",
    drugdate:"I lost my drug coverage on (insert date)",
    leavingdate:"I am leaving on (insert date)",
    SNPdate:"on (insert date)",
    disrolldate:"on (insert date)",
    insertdate:"(Insert date)",

    retiop:" I am a retiree or spouse/domestic partner/dependent of a retiree of the City of San Diego enrolling during open enrollment (June 1 - June 30, 2020)" ,
  },
  st2cat3:{
    adressint:"Address Of Institution ",
    STEP2:"STEP 2",
    MEDICAREINFOR:"MEDICARE INFORMATION",
    info:"Please Provide Your Medicare Insurance Information",
    Note:"Note",
    notePart:"You must have Medicare Part A and Part B to join a Medicare Advantage plan",
    A:"A. Please fill in these blanks so they match your red, white and blue Medicare card",
    MedicareNumber:"Medicare Number",
    HospitalDate:"Hospital (Part A) Effective Date",
    Medical:"Medical (Part B) Effective Date",
    B:" B. Please read and answer these important questions",
    q1:"Are you covering a Medicare-eligible spouse or dependents(s) under this employer or Union plan?",
    q2:"Do you or your spouse work?",
    q3:" Do you have End Stage Renal Disease (ESRD)?",
    q4:"Some individuals may have other drug coverage, including "+
    "other private insurance, TRICARE, Federal employee health "+
    "benefits coverage, VA benefits, or State pharmaceutical "+
    "assistance programs. Will you have other prescription drug "+
    "coverage in addition to Sharp Health Plan?",
   q5:"Are you a resident in a long-term care facility, such as a nursing home?",
   q6:"What is your current health coverage type?",
   q7:"What is your current insurance company?",
    C:"C. Please choose a Primary Care Physician (PCP)",
    csub1:"Need to find a doctor? Visit",
    csub2:"to use our online search tool",
    PCPName:"PCP Name",
    PCPMedicalGroup:"PCP Medical Group",
    cq:"Are you a current patient",
    D:"Language and Format Preferences",
    Dsub:"Please check one of the boxes below if you would prefer us to send you information in a language other than English or in another format",
    Dchk1:"Spanish",
    Dchk2:"Other",
    Para1:"Please contact Sharp Health Plan at 1-855-562-8853 if you need information in an accessible format or language other than what is listed above. Our office hours are 8 a.m. to 8 p.m. 7 days per week from October 1 to March 31: 7 days per week 8 a.m. to 8 p.m. From April 1 to September 30: Monday through Friday, 8 a.m. to 8 p.m. and on weekends and holidays, your call will be handled by our voicemail system. A Customer Care Representative will return your phone call the next business day. TTY/TDD users should call 711",
    Para2:" Sharp Health Plan provides the Evidence of Coverage, Formulary and Provider Directory online at",
    Para3:"Members can request a paper copy be mailed to them by calling Customer Care at the phone number listed above",
    Para4:"Please contact Sharp Direct Advantage at 1-855-862-8853 if you need information in another format or language than what is listed above"+
    "(TTY/TDD users should call 711). Our office hours are from 8 a.m. to 6 p.m., Monday to Friday",
    Para5:"Sharp Direct Advantage is offered by Sharp Health Plan. Sharp Direct Advantage is an HMO plan with a Medicare contract. Enrollment in"+
    "Sharp Direct Advantage depends on contract renewal. You must continue to pay your Part B premium. This information is not a"+
    "complete description of benefits. Contact the plan for moreinformation. Limitations, copayments and restrictions may apply."+
    "Benefits, premiums and/or co-payments/co-insurance may change as of January 1 of each year",
    NOTEcp:"NOTE",
    NOTEcpPart:"You may save and continue without completing all required fields (*); however, all required fields must be completed before submitting the enrollment form",

    retirement:"If Yes, retirement date (MM/DD/YYYY)",    
    nameretiree:"If No, name of retiree",
    spousename:"If Yes, name of spouse",
         dependents:"Name(s) of dependents(s)",
      q4sub1:"Have you had a successful kidney transplant and/or you don't need regular dialysis any more?",
      q4sub2:"If Yes, a Licensed Sales Representative may need to contact you to obtain additional information",
      coverage:"Name of other coverage",
      coverageId:"ID# of this coverage", 
      grpcov:"Group# for this coverage",
      isnt:"Name of Institution",
      phoneinst:"Phone Number of Institution",
      addressint:"Address of Institution (number and street)",


     },
step4:{
  STEP4:"STEP 4",
  READ_SIGN:"READ AND SIGN",
  subHead:"Please Read This Important Information",
  subHead1:"Sharp Direct Advantage is an HMO plan with a Medicare contract."+
  "Enrollment in Sharp Direct Advantage depends on contract renewal",
  Para1:"This information is not a complete description of benefits. "+
  "Contact the plan for more information. Limitations, copayments, "+
  "and restrictions may apply. Benefits, premiums and/or "+
  "co-payments/co-insurance may change on January 1 or each year. You "+
  "must continue to pay your Medicare Part B premium",
  Para2:"If you currently have health coverage from an employer or union, "+
  "joining Sharp Direct Advantage could affect your employer or union "+
  "health benefits. You could lose your employer or union health "+
  "coverage if you join Sharp Direct Advantage. Read the communications "+
  "your employer or union sends you. If you have questions, visit "+
  "their website, or contact the office listed in their "+
  "communications. If there isn't any information on whom to contact, "+
  "your benefits administrator or the office that answers questions "+
  "about your coverage can help",
  Para3:" PLEASE READ AND SIGN BELOW",
  Para4:"By completing this enrollment application, I agree to the following",
  Para5:"Sharp Direct Advantage is a Medicare Advantage plan and has a contract "+
  "with the Federal government. I will need to keep my Medicare Parts "+
  "A and B. I can be in only one Medicare Advantage plan at a time "+
  "and I understand that my enrollment in this plan will "+
  "automatically end my enrollment in another Medicare Direct Advantage or "+
  "prescription drug plan. It is my responsibility to inform you of "+
  "any prescription drug coverage that I have or may get in the "+
  "future. Enrollment in this plan is generally for the entire year. "+
  "Once I enroll, I may leave this plan or make changes only at "+
  "certain times of the year when an enrollment period is available "+
  "(Example: October 15 - December 7 of every year), or under certain "+
  "special circumstances",
  Para6:"Sharp Direct Advantage serves a specific service area. If I move out of "+
  "the area that Sharp Direct Advantage serves, I need to notify the plan "+
  "so I can disenroll and find a new plan in my new area. Once I am a "+
  "member of Sharp Direct Advantage, I have the right to appeal plan "+
  "decisions about payment or services if I disagree. I will read the "+
  "Evidence of Coverage document from Sharp Direct Advantage when I get it "+
  "to know which rules I must follow to get coverage with this "+
  "Medicare Advantage plan. I understand that people with Medicare "+
  "aren't usually covered under Medicare while out of the country "+
  "except for limited coverage near the U.S. border",
  Para7:"I understand that beginning on the date Sharp Direct Advantage coverage "+
  "begins, I must get all of my health care from Sharp Direct Advantage, "+
  "except for emergency or urgently needed services or out-of-area "+
  "dialysis services. Services authorized by Sharp Direct Advantage and "+
  "other services contained in my Sharp Direct Advantage Evidence of "+
  "Coverage document (also known as a member contract or subscriber "+
  "agreement) will be covered. Without authorization ",
  Para8:"NEITHER MEDICARE NOR SHARP Direct Advantage WILL PAY FOR THE SERVICES",
  Para9:"I understand that if I am getting assistance from a sales agent, "+
  "broker, or other individual employed by or contracted with Sharp "+
  "Direct Advantage, he/she may be paid based on my enrollment in Sharp "+
  "Direct Advantage",
  Para10:"Release of Information",
  Para11:"By joining this Medicare"+
  "Direct Advantage, I acknowledge that Sharp Direct Advantage will release my "+
  "information to Medicare and other plans as is necessary for "+
  "treatment, payment and health care operations. I also acknowledge "+
  "that Sharp Direct Advantage will release my information including my "+
  "prescription drug event data to Medicare, who may release it for "+
  "research and other purposes that follow all applicable Federal "+
  "statutes and regulations. The information on this enrollment form "+
  "is correct to the best of my knowledge. I understand that if I "+
  "intentionally provide false information on this form, I will be "+
  "disenrolled from the plan",
  Para12:"I understand that my signature (or the signature of the person "+
    "authorized to act on my behalf under the laws of the State where I "+
    "live) on this application means that I have read and understand "+
    "the contents of this application. If signed by an authorized "+
    "individual (as described above), this signature certifies that: 1) "+
    "this person is authorized under State law to complete this "+
    "enrollment, and 2) documentation of this authority is available "+
    "upon request from Medicare",
    Para13:"By joining this Medicare "+
    "Direct Advantage, I acknowledge that Sharp Direct Advantage will release my "+
    "information to Medicare and other plans as is necessary for "+
    "treatment, payment and health care operations. I also acknowledge "+
    "that Sharp Direct Advantage will release my information including my "+
    "prescription drug event data to Medicare, who may release it for "+
    "research and other purposes that follow all applicable Federal "+
    "statutes and regulations. The information on this enrollment form "+
    "is correct to the best of my knowledge. I understand that if I "+
    "intentionally provide false information on this form, I will be "+
    "disenrolled from the plan",
    Para14:"Sharp Health Plan is an HMO plan with a Medicare contract."+
    "Enrollment in Sharp Health Plan depends on contract renewal",
    Para15:" If you currently have health coverage from an employer or union, "+
    "joining Sharp Health Plan could affect your employer or union "+
    "health benefits. You could lose your employer or union health "+
    "coverage if you join Sharp Health Plan. Read the communications "+
    "your employer or union sends you. If you have questions, visit "+
    "their website, or contact the office listed in their "+
    "communications. If there isn't any information on whom to contact, "+
    "your benefits administrator or the office that answers questions "+
    "about your coverage can help ",
    Para16:"Sharp Health Plan is a Medicare Advantage plan and has a contract "+
    "with the Federal government. I will need to keep my Medicare Parts "+
    "A and B. I can be in only one Medicare Advantage plan at a time "+
    "and I understand that my enrollment in this plan will "+
    "automatically end my enrollment in another Medicare health plan or "+
    "prescription drug plan. It is my responsibility to inform you of "+
    "any prescription drug coverage that I have or may get in the "+
    "future. Enrollment in this plan is generally for the entire year. "+
    "Once I enroll, I may leave this plan or make changes only at "+
    "certain times of the year when an enrollment period is available "+
    "(Example: October 15 - December 7 of every year), or under certain "+
    "special circumstances",
    Para17:"Sharp Health Plan serves a specific service area. If I move out of "+
    "the area that Sharp Health Plan serves, I need to notify the plan "+
    "so I can disenroll and find a new plan in my new area. Once I am a "+
    "member of Sharp Health Plan, I have the right to appeal plan "+
    "decisions about payment or services if I disagree. I will read the "+
    "Evidence of Coverage document from Sharp Health Plan when I get it "+
    "to know which rules I must follow to get coverage with this "+
    "Medicare Advantage plan. I understand that people with Medicare "+
    "aren't usually covered under Medicare while out of the country "+
    "except for limited coverage near the U.S. border",
    Para18:"I understand that beginning on the date Sharp Health Plan coverage "+
    "begins, I must get all of my health care from Sharp Health Plan, "+
    "except for emergency or urgently needed services or out-of-area "+
    "dialysis services. Services authorized by Sharp Health Plan and "+
    "other services contained in my Sharp Health Plan Evidence of "+
    "Coverage document (also known as a member contract or subscriber "+
    "agreement) will be covered. Without authorization",
    Para19:"NEITHER MEDICARE NOR SHARP HEALTH PLAN WILL PAY FOR THE SERVICES",
    Para20:"I understand that if I am getting assistance from a sales agent, "+
    "broker, or other individual employed by or contracted with Sharp "+
    "Health Plan, he/she may be paid based on my enrollment in Sharp "+
    "Health Plan",
  accept:"I ACCEPT THE TERMS OF THIS AGREEMENT",
  Name:"Name",
  Digital:" Digital Signature",
  TodayDate:" Today's Date",
  authorized:"Are you an authorized representative?",
  authorPart:"If you are the authorized representative, you must sign above and provide the following information",
  Enrollee:" Relationship to Enrollee",
  Address:"Address",
  PhoneNumber:"Phone Number",
  Licensed:"Are you working with a Licensed Sales Representative?",
  sale:"Sales Representative Name",
  LicenseNo:"Sales Representative License Number",
  NOTE:"NOTE",
  notepart:"You may save and continue without completing all required fields (*); however, all required fields "+
              "must be completed before submitting the enrollment form",
},
user:{
  emailAdd:"Email Address",
  pwd:"Password",
  repwd:"Re-enter Password",
  guest:"CONTINUE AS GUEST",
  sign:"SIGN UP",
  already:" Already have an account?",
  log:"Log in here",
  login:"Log in",
  rtpwd:"Reset Password Here",

  Email:"Email",
  newpwd:"New Password",
  confpwd:"Confirm Password",
  Submit:"Submit",
  reset:"Send Reset",

  fogsub:"Enter your email address below and we'll send you password reset instructions",
  foghead:"Forgot your password ?",

  loghead:"Log in to your Sharp Health Plan Medicare Account",
  logsub:"Sharp Health Plan provides you with access to facilities and programs that"+
  "help you make the most of your health care. We're here to make finding and"+
  "enrolling in the right plan simple. Whether you have never purchased"+
  "Medicare health coverage before or are considering switching from your"+
  "current plan, we are committed to making your health care experience"+
  "affordable, simple, accessible and personal. At Sharp Health Plan, we"+
  "offer Medicare plans to feel good about",
  forget:"Forgot Password?"

},
enroll:{
  Step1:"Step 1",
  choose :"CHOOSE A PLAN",
  st1sub1 :"Before you begin your online Medicare form, you will need to know what plan you’d like to enroll in",
  st1sub2:"Click on the link below to browse Sharp Health Plan's Medicare Advantage plans and find the best one for your health care needs",
  st1sub3:"If you have questions for our Sharp Advantage Specialists, click button",
  Browse:"Browse Plans",

  Step2:"Step 2",
  gather:"GATHER YOUR INFORMATION",
  st2sub1:"There are two important items to gather prior to beginning the online enrollment form",
  st1:"Your red, white and blue Medicare card",
  st2:" Your primary care physician (PCP) name and plan medical group",
  st2sub2:'If you do not currently have a PCP or would like to select a different PCP, click on the button below to use our “Find a doctor” online search tool',
  dr:"Find A Doctor",

  Step3:"Step 3",
  start:"START YOUR ENROLLMENT FORM",
  st3sub1:"When you are ready to enroll in a plan, you will need to create a user account to start online enrollment",
  st3sub2:"Once you have an account, you will be able to begin your form, and return later to complete it",
  getst:"Get Started",

},
year:{
head:"Select the plan year you would like to enroll in",
choose:"Choose Year",
Continue:" Continue",
not:"Not sure?",
look:"Look at Our Plans",

},
plan:{
  hed1:"By completing this online form, you will be enrolling in a Sharp Direct Advantage Plan",
  hed2:"Select the plan you would like to enroll in",
  head1:"Open to all Medicare-eligible",
  head2:"residents of San Diego County",

  p1:"2021 Sharp Direct Advantage",                          
  p1sb:"Gold Card (HMO)",
  p1sb2:"($0 per month, Dental not included)",

  p2:"  2021 Sharp Direct Advantage",
  p2sb:"Gold Card (HMO) With Dental",
  p2sb2:"($12 per month, Dental Advantage by Delta Dental [HMO] included)",

  p3:"2021 Sharp Direct Advantage",
  p3sb:"Platinum Card (HMO) With",
  Dental:"Dental",
  p3sb2:"($58 per month, Dental Advantage by Delta Dental [HMO] included)",

  head3:"Former Employees of Sharp",
  head4:"HealthCare only",

  p4:" 2021 Sharp Direct Advantage",
  p4sb:"Basic (HMO)",
  p4sb2:"($0 monthly premium)",

  p5:"2021 Sharp Direct Advantage",
  p5sb:"Basic (HMO) With Dental",
  p5sb2:"($12 monthly premium)",

  p6:"2021 Sharp Direct Advantage",
  p6sb:"Premium (HMO)",
  p6sb2:"($62 monthly premium)",

  p7:"2021 Sharp Direct Advantage",
  p7sb:"Premium (HMO) With Dental",
  p7sb2:"($74 monthly premium)",

  head5:"Retirees of the City of San Diego",
  head6:" (SDPEBA) only",

  p8:"2020-21 Sharp Direct Advantage (HMO)",
  p8sb:"($201 monthly premium)",
  
  Continue:"Continue",
  not:" Not sure?",
  look:"Look at Our Plans",


  

},

header: {
  search:"Search",
  login:"Login",
  ourPlans:"Our Plans",
  ourPlansSub1:"Explore Our Plans",
  ourPlansSub2:"Added Benefits",
  
  aboutMedicare:"About Medicare",
  aboutMedicaresub1:"Your Medicare questions answered",
  aboutMedicaresub2:"What is Medicare?",
  aboutMedicaresub3:"Medicare eligibility and plan types",
  aboutMedicaresub4:"Enrollment periods",
  aboutMedicaresub5:"Glossary of terms",

  enroll:"Enroll",
  enrollSub1:"How to enroll",
  enrollSub2:"Enroll Online",
  
  members:"Members",
  membersSub1:"Member Center",
  membersSub2:"How to appoint a representative",
  membersSub3:"Pharmacy",
  membersSub4:"Member rights and disenrollment",
  membersSub5:"Manage your costs",
  membersSub6:"Reporting fraud",
  membersSub7:"Quality and Medicare star ratings",
  membersSub8:"Forms, authorizations and resources",

  wellness:"Wellness",
  wellnessSub1:"Wellness Center",
  wellnessSub2:"Wellness Program",
  wellnessSub3:"Preventive Care",

  findADoctor:"Find a Doctor",
  
  contactUs:" Contact Us",
  contactUsSub:"FAQ",
  contact:"Contact Information",

  suggession:"For the best experience, please use Google Chrome as your browser to begin the application process.",
  CreatAMedicareAccount:"Create a Medicare Account",
  CreatAMedicareAccountPara:"Sharp Health Plan provides you with access to expert care and award-winning facilities and programs that help you make the most of your health care. We're here to make finding and enrolling in the right plan simple. Whether you have never purchased Medicare health coverage before or are considering switching from your current plan, we are committed to making your health care experience affordable, simple, accessible and personal. At Sharp Health Plan, we offer Medicare plans to feel good about.",
  enrollmentSteps:"Enrollment Steps",
  enrollmentStepsPare:" Sharp Health Plan's Medicare Advantage plans provide you with access to facilities and programs that help you make the most of your health care. We're here to make finding and enrolling in the right plan simple. Whether you have never purchased Medicare health coverage before or are considering switching from your current plan, we are committed to making your health care experience affordable, simple, accesible and personal. At Sharp Health Plan, we offer Medicare plans to feel good about.",
  sharpHealthPlan:"Sharp Health Plan Medicare Plan",
  sharpHealthPlanPara:"Congratulations on successfully creating an account. It is important that you fully understand our benefits and rules. Before making your enrollment decision, be sure to review our pre-enrollment",
  checklist:"checklist",
  sharpHealthPlanPara1:". If you have any questions, or need information in another language or format, please contact Sharp Health Plan. Medicare beneficiaries may also enroll in Sharp Health Plan through the CMS Medicare Online Enrollment Center located at",
  stepHeader:"Sharp Direct Advantage Enrollment Form",
  stepeHeaderPara:"This plan is open to all Medicare-eligible residents of San Diego County.",
  changeMyPlane:"Change My Plan",
  contactPara:"Please contact Sharp Health Plan if you need information in another language or format",
  planSelection:"By completing this online form, you will be enrolling in a Sharp Direct Advantage Plan.",
  planSelectionpara:"Select the plan you would like to enroll in:", 
  
  planSDPEBA:"Sharp Direct Advantage® Enrollment Form",
  planSDPEBAPara:"This plan is offered exclusively for City of San Diego Medicare-eligible retirees and their dependents sponsored by San Diego Public Employee Benefit Association (SDPEBA).",
  planName:"Sharp Direct Advantage (HMO)",
  planSDPEBASubPara:"This plan is open to all Medicare-eligible City of San Diego retirees, sponsored by San Diego Public Employee Benefit Association (SDPEBA). SDPEBA membership is not required to join this plan.",
  importantInstruction:"Important Information",
  importantInstructionPara:"The Medicare application is intended for individual coverage only. If you and your spouse/ dependent are both applying for coverage, then each of you will need to complete a separate enrollment form.",
  importantInstructionNote:"Note – If your spouse/dependent is not eligible for Medicare, then he/she will need to complete the Non-Medicare / Early Retiree, enrollment form. Please contact SDPEBA at 1-888-315-8027 or visit www.sdpeba.org to download the enrollment form",

  planHealthCareOnly:"Sharp Direct Advantage Group Enrollment Form",
  planHealthCareOnlyPara:"This Plan is exclusively for former Sharp HealthCare employees.",

  confirmationHeader:"Sharp Direct Advantage Individual Enrollment Form",
  confirmationHeaderPara1:"Thank you for choosing Sharp Health Plan. Your Medicare enrollment form has been submitted successfully and confirmation number is :",
  confirmationHeaderPara2:", if there are any questions we will contact you. Click below to download and print a complete version of your form to keep for your records",
  downloadPdf:"DOWNLOAD PDF VERSION",

  nextStep:"Next Steps:",
      nextStep1:"We’ll review your form to ensure it’s complete. Then we’ll let you know by mail that we’ve received it",
      nextStep2:"We’ll let Medicare know that you’ve applied for Sharp Direct Advantage.",
      nextStep3:"Within 10 calendar days after Medicare confirms you’re eligible, we’ll let you know when your coverage starts. Then we’ll send your Sharp Direct Advantage ID card and information for new members.",
},
footer:{
  madewith: "Made with",
  by: "by Sharp Health Plan of San Diego",
  manage: "Manage your plan",
  pp: "Privacy Policy",
  pay: "Pay your bill",
  appeals: "Appeals and grievances",
  faq: "FAQs",
  HL: "Helpful links",
  login: "Login",
  gc: "Get care",
  finddoc: "Find a doctor",
  search: "Search drug list",
  findcare: "Find an urgent care",
  findhosp: "Find a hospital",
  oc: "Our company",
  Cus: "Contact us",
  Aus: "About us",
  call: "Call",
  hrsofOp1: "Hours of operation: Oct. 1 – Feb. 14 from 8 a.m. to 8 p.m.",
  hrsofOp2:" Pacific Time, 7 days a week; Feb. 15 – Sept. 30 from 8 a.m. to",
  hrsofOp3:" 8 p.m. Pacific Time, Monday through Friday. Calling after",
  hrsofOp4:" hours will direct you to our voicemail system and a Customer",
  hrsofOp5:" Care representative will return your call the next business day.",
  helpinLang: "Help in other languages",
  terms: "Terms of Use",
  sitemap: "Sitemap",
  need: "Need to get in touch",

},
pdf:{
  head1:"INDIVIDUAL ENROLLMENT REQUEST FORM TO ENROLL IN A",
  subHead1:"MEDICARE ADVANTAGE PLAN (PART C)",
  pdfi1:"Mail your completed and signed form to:",
  pdfi2:"Sharp Health Plan Medicare Dept.",
  pdfi3:"8520 Tech Way, Suite 201",
  pdfi4:"San Diego, CA 92123",
  pdfi5:"Once they process your request to join, a plan representative will contact you.",
  pdfi6:"How do I get help with this form?",
  pdfi7:"Call 1-855-562-8853 (TTY/TDD: 711).",
  pdfi8:"Or, call Medicare at 1-800-MEDICARE",
  pdfi9:"(1-800-633-4227). TTY users can call 1-877-486-2048.",

  Section1 :"Section 1 – All fields on this page are required (unless marked optional)",
  tojoin:"Select the plan you want to join",

  plan1:"Sharp Direct Advantage Gold Card ($0 per month, Dental not included)",
  plan2:"Sharp Direct Advantage Gold Card ($12 per month, Dental Advantage by Delta Dental [HMO]* included)",
  plan3:"Sharp Direct Advantage Platinum Card ($58 per month, Dental Advantage by Delta Dental [HMO]* included)",

  head3:"	The comprehensive dental coverage is provided through DeltaCare USA, an HMO-type plan offered by "+
  "by Delta Dental of California. You will be auto-assigned a network dentist in your area. If you would like "+
  "to change to another network provider, contact Delta Dental.",

  Streetaddress:"Street address",
  MediInfo:"Your Medicare information",
  label1:"Answer these important questions",
  label2:"Will you have other prescription drug coverage (like VA, TRICARE) in addition to Sharp Health Plan?",
  auth:"If you’re the authorized representative, sign above and fill out these fields",
  Signature:"Signature",
  date:"Today’s date",

  Section:"Section ",
  Physician:"List your Primary Care Physician (PCP), clinic, or health center",

 
  FirstName: "First Name:",
  LastName:"Last Name:",
  Middle:"Middle Initial",
  DOB:"Birth Date: MM/DD/YY",
  Sex:"Sex:",

  plan4:"2021 Sharp Direct Advantage Basic (HMO) ($0 monthly premium)",
  plan5:"2021 Sharp Direct Advantage Basic (HMO) With Dental ($12 monthly premium)",
  plan6:"2021 Sharp Direct Advantage Premium (HMO) ($62 monthly premium)",
  plan7:"2021 Sharp Direct Advantage Premium (HMO) With Dental ($74 monthly premium)",
  primaryno:"Primary Phone Number",



}
};
export default en;
