const es = {
  app: {
    lang: "Cambiar idioma",
    Sex: "Sexo*",
    Prefix: "Prefijo",
    FirstName: "Nombre de pila*",
    LastName: "Apellido*",
    BirthDate: "Fecha de nacimiento*",
    MI: "MI",
    PrimaryPhoneNumber: "Número de teléfono primario*",
    CellPhoneNumber: "Número Celular",
    Instructions: "Instrucciones para completar este formulario",
    PermanentAddress: "Dirección de residencia permanente",
    POBox: "No ingrese un apartado de correos",
    HomeNumber: "Número de teléfono de casa",
    Optionalfield: "Campo opcional",
    City: "Ciudad",
    County: "Condado",
    State: "Estado",
    ZIPCode: "Código postal",
    MedicareNo: "Número de Medicare",
    Name: "Nombre",
    DigitalSignature: "Firma digital",
    TodayDate: "Fecha",
    drugCoverage:
      "¿Tendrá otra cobertura de medicamentos (como VA, TRICARE) además de Sharp Health Plan?",
    Yes: "Sí",
    No: "No",
    authorizedrepresentative: "¿Eres un representante autorizado?",
    authorized:
      "Sí es el representante autorizado, debe firmar arriba y proporcionar la siguiente información",
    License: "¿Trabaja con un representante de ventas autorizado?",
    NOTE: "NOTA",
    notePart:
      "Puede guardar y continuar sin completar todos los campos obligatorios (*); sin embargo, todos los campos obligatorios deben completarse antes de enviar el formulario de inscripción",
      Save_Next:"Guardar y siguiente",
      STEP1:"PASO 1",
      PERSONALINFO:"INFORMACION PERSONAL",
      APara:"A. Para inscribirse en Sharp Health Plan, proporcione la siguiente información",
      Effectdate:"Fecha de vigencia de la cobertura",
      Socialnumber:"Número de seguridad social",
      mailingaddress:"¿La dirección anterior es diferente de su dirección postal?",
      Please:"Llámeme sobre el plan médico de Sharp Health Plan",
      news:"Sí, me gustaría recibir noticias e información sobre el plan de salud por correo electrónico",
      news1:"Sí, me gustaría recibir noticias e información sobre el plan de salud por correo electrónico o mensaje de texto "+
       "(pueden aplicarse tarifas de mensajes y datos)",
      stepSub:"Todos los campos de esta página son obligatorios (a menos que estén marcados como opcionales)",
      imp:"IMPORTANTE",
      impsub:"Lea y firme a continuación",
      imp1:"Debo mantener tanto el Hospital (Parte A) como el Médico (Parte B) para permanecer en Sharp Health Plan",
      imp2:"Al unirme a este Plan Medicare Advantage, reconozco que Sharp Health Plan compartirá mi "+
      "información con Medicare, que puede usarla para realizar un seguimiento de mi inscripción, para realizar pagos y para otros " +
      "propósitos permitidos por la ley federal que autorizan la recopilación de esta información (ver Ley de Privacidad " +
      "Declaración de abajo)",
      imp3:"Su respuesta a este formulario es voluntaria. Sin embargo, la falta de respuesta puede afectar la inscripción en el plan.",
      imp4:"La información en este formulario de inscripción es correcta a mi leal saber y entender. Entiendo que si a sabiendas proporciono"+ 
      " información falsa en este formulario, se cancelará mi inscripción en el plan.",
      imp5:"Entiendo que las personas con Medicare generalmente no están cubiertas por Medicare mientras están fuera del país "+
      "excepto por una cobertura limitada cerca de la frontera de EE. UU",
      imp6:'Entiendo que cuando comience la cobertura de mi Sharp Health Plan, debo obtener todos mis servicios médicos y '+
      'beneficios de medicamentos recetados de Sharp Health Plan. Beneficios y servicios proporcionados por Sharp Health Plan '+
      'y contenido en mi documento de "Evidencia de Cobertura" de Sharp Health Plan (también conocido como contrato de miembro' +
      'o acuerdo del suscriptor) estarán cubiertos. Ni Medicare ni Sharp Health Plan pagarán los beneficios '+
      'o servicios que no están cubiertos',
      imp7:"Entiendo que mi firma (o la firma de la persona legalmente autorizada para actuar en mi nombre) "+
      "en esta aplicación significa que he leído y comprendido el contenido de esta aplicación. Si " +
      "firmado por un representante autorizado (como se describe arriba), esta firma certifica que",
      Male:"Masculina",
      Female:"Hembra",
      coverage:"Nombre de otra cobertura",
      mebernumber:"Número de miembro para esta cobertura",
      groupNo:"Número de grupo para esta cobertura",
      maillingAdd:"Dirección postal: dirección postal / apartado postal: (solo si es diferente de su dirección residencial permanente)",
      email:"Dirección de correo electrónico",
      Enrollee:"Relación con la inscrita",
      address:"Habla a",
      phno:"Número de teléfono",
      sale:"Nombre del representante de ventas",
      Licenseno:"Número de licencia del representante de ventas",
      save:"Guardar y cerrar sesión",
      submit:"Enviar",

      error1:"Nos faltan algunos datos. por favor, compruebe",
      error2:"para los campos resaltados en rojo. Cuando se haya ingresado toda la información requerida, el botón Enviar se mostrará en verde",
      cong:"¡Felicidades! Su formulario de Medicare está completo, presione ENVIAR para completar",
      online:"Formulario de inscripción individual en línea V1",
      enroll:"Formulario de inscripción SHC_M V1",
      Mr:"Señor",
      Mrs:"señora",
      Ms:"Em",

      foot1:"Sharp Health Plan es un plan HMO con contrato con Medicare. La inscripción en Sharp Health Plan depende de la renovación del contrato",
      foot2:"Lea el descargo de responsabilidad completo",
      foot3:"Formulario de inscripción individual en línea",
      foot4:"Página actualizada por última vez",
      Step:"Paso",

      newfooter:"Según la Ley de reducción de trámites de 1995, "+
      "no se requiere que ninguna persona responda a una colección " +
      "de información a menos que muestre un número de control OMB válido." +
      "El número de control válido de OMB para esta recopilación de información es 0938-NEW." +
      "El tiempo requerido para completar esta información se estima en un promedio de 20 minutos por respuesta," +
      "incluido el tiempo para revisar las instrucciones, buscar los recursos de datos existentes," +
      "recopile los datos necesarios y complete y revise la recopilación de información." +
      "Si tiene algún comentario sobre la precisión de la (s) estimación (es) de tiempo" +
      "o sugerencias para mejorar este formulario, escriba a: CMS," +
      "7500 Security Boulevard, Attn: PRA Reports Clearance Officer," +
      "Mail Stop C4-26-05, Baltimore, Maryland 21244-1850",

      san:"¿Eres la jubilada de la ciudad de San Diego?",
      san1:"sí, ¿está cubriendo a un cónyuge o dependiente?",
      san2:"(En caso afirmativo, complete la sección a continuación).",
      san3:"Dependiente de Jubilado de la Ciudad de San Diego",
      MiddleInitial:"inicial del segundo nombre ",
      san4:"Si no es así, nombre del empleado",

      san6:"Si su cónyuge / dependiente no es elegible para Medicare, necesitará "+
      "para completar el plan No Medicare / Jubilado anticipado" +
      "formulario de inscripción. Póngase en contacto con SDPEBA al" +
      "1-888-315-8027 o visite www.sdpeba.org para descargar el formulario de inscripción",

      san7:"Si no es así, ¿es usted el cónyuge sobreviviente de un Jubilado de la Ciudad de San Diego?",
      rtlast:"Apellido del jubilado",
      rtfirst:"Nombre del jubilado",
      rtmiddle:"Inicial media jubilada",
      san8:"Si su cónyuge / dependiente no es elegible para Medicare, entonces necesitará" +
      "para completar el formulario de inscripción para personas que no son miembros de Medicare / jubilados anticipados."+
      "1-888-315-8027 o visite www.sdpeba.org para descargar el formulario de inscripción"
    },
  inst: {
    head:"Instrucciones para completar este formulario",
    i1: "¿Quién puede usar este formulario?",
    i2:
      "Las personas que tienen Medicare que quieren inscribirse en un plan Medicare Advantage.",
    i3:
      "Para inscribirse en un plan, debe cumplir con los siguientes requisitos:",
    i4:
      "ser ciudadano de los Estados Unidos y encontrarse legalmente en el país:",
    i5: "vivir en el área de servicio del plan.",
    i6: "Importante",
    i7:
      ": Para inscribirse en un plan Medicare Advantage, debe contar con ambas partes de las mencionadas a continuación:",
    i8: "Medicare Parte A (seguro hospitalario);",
    i9: "Medicare Parte B (seguro médico).",
    i10: "¿Cuándo puedo usar este formulario?",
    i11: "Puede inscribirse en un plan:",
    i12:
      "entre el 15 de octubre y el 7 de diciembre cada año (para la cobertura que comienza el 1.º de enero);",
    i13: "dentro de los 3 meses de inscribirse en Medicare por primera vez;",
    i14:
      "en situaciones determinadas en las que tenga permitido inscribirse o cambiar de plan.",
    i15: "Recuerde:",
    i16:
      "Si quiere inscribirse en un plan durante la inscripción abierta de otoño (del 15 de octubre al 7 de diciembre), el plan debe recibir el formulario completado antes del 7 de diciembre.",
    i17:
      "Su plan le enviará una factura por la prima. Puede optar por que los pagos de la prima se deduzcan de su cuenta bancaria o de su beneficio mensual del Seguro Social (o de la Junta de Retiro Ferroviario).",
    i18: "¿Qué necesito para completar este formulario?",
    i19:
      "Su número de Medicare (el número que figura en la tarjeta roja, blanca y azul de Medicare).",
    i20: "Su dirección de residencia permanente y número de teléfono.",
    i22: "Nota",
    i21:
      "Debe completar todos los puntos de la sección 1. Los puntos de la sección 2 son opcionales. No le pueden denegar la cobertura por no haberlos completado.",


    i23:"Si tanto usted como su cónyuge están solicitando, deberán completar un formulario por separado. Para obtener ayuda para completar el formulario de inscripción, envíenos un correo electrónico a medicaresales@sharp.com o llámenos al 1-855-562-8853 (TTY / TDD: 711) para completar su inscripción por teléfono",
    i24:"Para Gold con planes dentales y platino, agregue",
    i25:"La cobertura dental integral se brinda a través de DeltaCare USA, un plan tipo HMO ofrecido por Delta Dental of California. Se le asignará automáticamente un dentista de la red en su área. Si desea cambiarse a otro proveedor de la red, comuníquese con Delta Dental",
    i26:"¿Cuándo utilizo este formulario?",
    i27:"Llame a Sharp Health Plan al 1-855-562-8853. Los usuarios de TTY pueden llamar al 711",
    i28:"O llame a Medicare al 1-800-MEDICARE (1-800-633-4227). Los usuarios de TTY pueden llamar al 1-877-486-2048",
    i29:"¿Qué pasa después?",
    i30:"Asegúrese de responder todas las preguntas",
    i31:"Asegúrese de haber leído todas las páginas antes de enviar su formulario de inscripción a Sharp Health Plan",
    i32:"Una vez que procesemos su solicitud para unirse, nos comunicaremos con usted",
  },
  step2: {
    Step2: "Paso 2",
    Spanish:"Española",
    subStep: "Todos los campos de esta página son opcionales",
    A:
      "Responder estas preguntas es tu elección. No se le puede negar la cobertura porque no los completa",
    A1:
      "Seleccione uno si desea que le enviemos información en un idioma que no sea inglés",
    A2:
      "Seleccione uno si desea que le enviemos información en un formato accesible",
    Ar1: "Braille",
    Ar2: "Letra grande",
    Ar3: "Otro",   
    B: "Elija un médico de atención primaria (PCP)",
    B1: "¿Necesitas encontrar un médico? Visitar",
    B2: "para utilizar nuestra herramienta de búsqueda en línea",
    PCPName: "Nombre del PCP",
    ClinicName: "Nombre de la clínica",
    currentpatient: "¿Eres una paciente actual?",
    Dowork: "¿Haz tu trabajo?",
    spousework: "¿Tu esposa trabaja?",
    Email: "Dirección de correo electrónico",
    EmailOption: "Opción de correo electrónico Ind",
    Para1:"Comuníquese con Sharp Health Plan al",
    Para2:"si necesita información en un formato accesible que no sea el mencionado anteriormente. Nuestro horario de oficina es. Los usuarios de TTY pueden llamar al 711.",
    Para3:"Pagando las primas de su plan",
    Para4:"Puede pagar la prima mensual de su plan (incluida cualquier multa por inscripción tardía que tenga o deba actualmente) por correo, transferencia electrónica de fondos (EFT) o tarjeta de crédito cada mes",
    Para5:"También puede optar por pagar su prima sacándola automáticamente de su beneficio del Seguro Social o de la Junta de Retiro Ferroviario (RRB) cada mes",
    Para6:"Si tiene que pagar una mensualidad relacionada con los ingresos de la Parte D "+
    "Monto de ajuste (Parte D-IRMAA), debe pagar este "+
    "monto adicional además de la prima de su plan ",
    Para7:"El monto generalmente se deduce de su Seguro Social."+
    "beneficio, o puede recibir una factura de Medicare (o la RRB)."+
    "NO le pague a Sharp Health Plan la Parte D-IRMAA",
    STEP2:"PASO 2",
    MEDICAREINFO:"INFORMACION MEDICARE",
    PleasePara:"Proporcione la información de su seguro de Medicare",
    Note:"Nota",
    notePart:"Debe tener la Parte A y la Parte B de Medicare para unirse a un plan Medicare Advantage",
    APara:"A. Complete estos espacios en blanco para que coincidan con su tarjeta roja, blanca y azul de Medicare.",
    MedicareNumber:"Número de Medicare",
    Hospi:"Hospital (Parte A) Fecha de vigencia",
    Medical:"Fecha de vigencia médica (Parte B)",
    BPara:"B. Pago de la prima de su plan",
    Para8:'Si determinamos que debe una multa por inscripción tardía (o si ' +
      'actualmente tiene una multa por inscripción tardía), necesitamos saber '+
      'su preferencia de pago. Puede pagar por correo, "Fondos electrónicos '+
      'Transferir (EFT) "o" tarjeta de crédito "cada mes',
    Para9:"Si se le aplica un ajuste mensual relacionado con los ingresos de la Parte D "+
    "Monto (Parte D-IRMAA), el Social le notificará "+
    "Administración de seguridad. Serás responsable de pagar este "+
    "cantidad adicional además de la prima de su plan. Lo harás "+
    "tener la cantidad retenida de su beneficio del Seguro Social "+
    "verificar o ser facturado directamente por Medicare o la RRB. No paga "+
    "Sharp Health Plan la Parte D-IRMAA",
    Para10:"Las personas con ingresos limitados pueden calificar para recibir Ayuda adicional para pagar "+
    "sus costos de medicamentos recetados. Si es elegible, Medicare podría pagar "+
    "75% o más de los costos de sus medicamentos, incluido el medicamento recetado mensual "+
    "primas, deducibles anuales y coseguro. Además, esos "+
    "que califiquen no estarán sujetos al período sin cobertura ni a un retraso "+
    "penalización por inscripción. Muchas personas son elegibles para estos ahorros y "+
    "ni siquiera lo sé. Para obtener más información sobre esta Ayuda adicional, "+
    "comuníquese con su oficina local del Seguro Social o llame al Seguro Social "+
    "al 1-800-772-1213. Los usuarios de TTY / TDD deben llamar al 1-800-325-0778. También puede solicitar ayuda adicional en línea en "+
    "www.socialsecurity.gov/prescriptionhelp",
    Para11:"Si califica para Ayuda adicional con su medicamento recetado de Medicare "+
    "costos de cobertura, Medicare pagará la totalidad o parte de la prima de su plan "+
    "Si Medicare paga solo una parte de esta prima, le facturaremos "+
    "por la cantidad que Medicare no cubre",
    paymentoption:"Seleccione una opción de pago de prima",
    Getbill:"Obtenga una factura (si se aplica un pago, podrá pagar con cheque o tarjeta de crédito mensualmente)",
    Electronicfunds:"Transferencia electrónica de fondos (EFT) desde su cuenta bancaria en "+
    "el 1 de cada mes. Si el día 1 del mes cae en "+
    "fin de semana o feriado bancario, su giro se producirá el próximo "+
    "día bancario",
    Accountname:"Nombre del titular de la cuenta",
    Bankname :"Nombre del banco",
    Accounttype :"Tipo de cuenta",
    routingnumber:"Número de ruta bancaria",
    Bankaccountnumber:"número de cuenta bancaria",
    Checking:"Comprobación",
    Saving:"Ahorro",
    C:"C. Lea y responda estas preguntas importantes",
    q1:"¿Eres la jubilada?",
    q2:"¿Está cubriendo a un cónyuge o dependientes bajo este empleador?",
    q3:"¿Trabajas tu o tu esposa?",
    q4:"¿Tiene enfermedad renal en etapa terminal (ESRD)?",
    q5:"Algunas personas pueden tener otra cobertura de medicamentos, incluido otro seguro privado, TRICARE, cobertura de beneficios de salud para empleados federales, beneficios de VA o programas estatales de asistencia farmacéutica. ¿Tendrá otra cobertura de medicamentos recetados además de Sharp Health Plan?",
    q6:"¿Es residente de un centro de atención a largo plazo, como un hogar de ancianos?",
    q7:"Elija un médico de atención primaria (PCP)",
    q7Part:"¿Eres una paciente actual?",
    MedicalGroup:"Grupo Médico PCP",
    q8:"Marque una de las casillas a continuación si prefiere que le enviemos información en un idioma que no sea inglés o en otro formato.",
    q8rod1:"Española",
    q8rod2:"Braille",
    q8rod3:"Letra grande",
    q8rod4:"Otra",
    Para12:"Comuníquese con Plan de salud de Sharp al 1-855-562-8853 si necesita "+
    "información en un formato accesible o en un idioma que no sea el "+
    "listados arriba. Nuestro horario de atención es de 8 a.m. a 8 p.m. 7 dias a la semana "+
    "del 1 de octubre al 31 de marzo: 7 días a la semana de 8 a 20 h Desde "+
    "1 de abril al 30 de septiembre: de lunes a viernes, de 8 a 20 h. y "+
    "los fines de semana y feriados, su llamada será manejada por nuestro buzón de voz "+
    "sistema. Un representante de atención al cliente le devolverá la llamada telefónica "+
    "el siguiente día hábil. Los usuarios de TTY / TDD deben llamar al 711",
    Para13:"Plan de salud de Sharp proporciona la Evidencia de Cobertura, el Formulario y Directorio de proveedores en línea en",
    Para14:"Los miembros pueden solicitar que se les envíe una copia impresa llamando al Atención al cliente en el número de teléfono que figura arriba",
    NOTECAp:"NOTA",
    NOTECApPart:"Puede guardar y continuar sin completar todos los campos obligatorios (*); sin embargo, todos los campos obligatorios deben completarse antes de enviar el formulario de inscripción",
    sharplink:"granventajademedicare.com",
    link2:"granventajademedicare.com/encontrardoctor",
    },
  step3: {
    Exhibit1a: "Anexo 1a",
    stepsub:
      "Información para incluir en el Mecanismo de inscripción o con él: Certificación de elegibilidad para un período de inscripción",
    Para1:"Por lo general, puede inscribirse en un plan Medicare Advantage durante "+
    "el período de inscripción anual que es desde el 15 de octubre hasta "+
    "7 de diciembre de cada año",
    Para2:"Hay excepciones que le permiten inscribirse en Medicare. Plan Advantage fuera de este período",
    Para3:"Lea atentamente las siguientes declaraciones y marque la casilla "+
    "si la declaración se aplica a usted. Al marcar cualquiera de los siguientes "+
    "cajas usted certifica que, a su leal saber y entender, "+
    "son elegibles para un período de inscripción. Si luego determinamos que "+
    "esta información es incorrecta, es posible que se cancele su inscripción",
      Op1:
      "Cambiaré de plan de Medicare durante el período de elección anual del 15 de octubre al 7 de diciembre",
    Op1sub:
      "En caso afirmativo, la fecha de vigencia de su cobertura será el 1 de enero",
    Op2: "Soy nueva en Medicare",
    Op3:
      "Recientemente me mudé fuera del área de servicio de mi plan actual o me mudé recientemente y este plan es una nueva opción para mí",
    Op4: "Recientemente fui liberado del encarcelamiento",
    Op5:
      "Recientemente regresé a los Estados Unidos después de vivir permanentemente fuera de los US",
    Op6:
      "Recientemente obtuve el estado de presencia legal en los Estados Unidos",
    Op7:
      "Tengo Medicare y Medicaid (o mi estado me ayuda a pagar las primas de Medicare) o recibo Ayuda adicional para pagar mi cobertura de medicamentos recetados de Medicare, pero no he tenido ningún cambio",
    Op8:
      "Recibo ayuda adicional para pagar la cobertura de medicamentos recetados de Medicare",
    Op9:
      "Ya no califico para la Ayuda adicional para pagar mis medicamentos recetados de Medicare",
    Op10:
      "Me estoy mudando, vivo o recientemente me mudé de un Centro de atención a largo plazo (por ejemplo, un hogar de ancianos o un centro de atención a largo plazo)",
    Op11: "Recientemente dejé un programa PACE",
    Op12:
      "Recientemente perdí involuntariamente mi cobertura acreditable de medicamentos recetados (cobertura tan buena como la de Medicare)",
    Op13: "Dejo la cobertura del empleador o del sindicato",
    Op14:
      "Pertenezco a un programa de asistencia farmacéutica proporcionado por mi estado",
    Op15:
      "Mi plan está terminando su contrato con Medicare o Medicare está terminando su contacto con mi plan",
    Op16:
      "Estaba inscrito en un Plan de necesidades especiales (SNP) pero he perdido la calificación de necesidades especiales requerida para estar en ese plan",
    Op17:
      "Recientemente tuve un cambio en mi Medicaid (recientemente obtuve Medicaid, tuve un cambio en el nivel de asistencia de Medicaid o perdí Medicaid",
    Op18:
      "Recientemente tuve un cambio en mi Ayuda adicional para pagar la cobertura de medicamentos recetados de Medicare (recientemente recibí Ayuda adicional, tuve un cambio en el nivel de Ayuda adicional o perdí Ayuda adicional)",
    Op19:
      "Me afectó una emergencia relacionada con el clima o un desastre mayor (según lo declarado por la Agencia Federal para el Manejo de Emergencias (FEMA). Una de las otras declaraciones aquí se aplicaba a mí, pero no pude inscribirme debido al desastre natural",
    NOTE: "NOTA",
    Para4:"Si ninguna de estas declaraciones se aplica a usted o no está seguro,"+
    "comuníquese con Sharp Health Plan al 1-855-562-8853 (usuarios de TTY / TDD "+
    "debe llamar al 711) para ver si es elegible para inscribirse. Estamos abiertos "+
     "del 1 de octubre al 31 de marzo: 7 días a la semana de 8 a 20 h Desde "+
    "1 de abril al 30 de septiembre: de lunes a viernes, de 8 a 20 h."+
    "y los fines de semana y festivos, su llamada será atendida por nuestro "+
    "sistema de correo de voz. Un representante de atención al cliente le devolverá su "+
    "llamada telefónica el siguiente día hábil",
    notePart:"Puede guardar y continuar sin completar todos los campos obligatorios (*); sin embargo, todos los campos obligatorios deben completarse antes de enviar el formulario de inscripción",
 optAnth1:"Soy un ex empleado o cónyuge / pareja de hecho / dependiente de un ex empleado de Sharp HealthCare y no estoy empleado activamente por Sharp HealthCare",
 Step3sub:"DECLARACIÓN DE ELEGIBILIDAD PARA UN PERIODO DE INSCRIPCIÓN",
 step3:"PASO 3",

 movedate:"Me mudé el (insertar fecha)",
    releasedate:"Me liberaron el (insertar fecha)",
    returndate:"Regresé a los EE. UU. El (insertar fecha)",
    statusdate:"Obtuve este estado el (insertar fecha)",
    extrahelp:"Dejé de recibir ayuda adicional el (insertar fecha)",
    facilitydate:"Me mudé / me mudaré dentro / fuera de la instalación el (insertar fecha)",
    pacedate:"Dejé el programa PACE el (insertar fecha)",
    drugdate:"Perdí mi cobertura de medicamentos el (insertar fecha)",
    leavingdate:"Me voy el (insertar fecha",
    SNPdate:"el (insertar fecha)",
    disrolldate:"el (insertar fecha)",
    insertdate:"(Insertar la fecha)",

    retiop:"Soy un jubilado o cónyuge / pareja de hecho / dependiente de un jubilado de la ciudad de San Diego que se inscribe durante la inscripción abierta (del 1 de junio al 30 de junio de 2020)" ,
  }
  ,
  st2cat3:{
    adressint:"Dirección de la institución",
    STEP2:"PASO 2",
    MEDICAREINFOR:"INFORMACION MEDICARE",
    info:"Proporcione la información de su seguro de Medicare",
    Note:"Nota",
    notePart:"Debe tener la Parte A y la Parte B de Medicare para unirse a un plan Medicare Advantage",
    A:"A. Complete estos espacios en blanco para que coincidan con su tarjeta roja, blanca y azul de Medicare.",
    MedicareNumber:"Número de Medicare",
    HospitalDate:"Hospital (Parte A) Fecha de vigencia",
    Medical:"Fecha de vigencia médica (Parte B)",
    B:"B. Lea y responda estas preguntas importantes",
    q1:"¿Está cubriendo a un cónyuge o dependientes elegibles para Medicare bajo este plan de empleador o sindicato?",
    q2:"¿Trabajas tu o tu esposa?",
    q3:"¿Tiene enfermedad renal en etapa terminal (ESRD)?",
    q4:"Algunas personas pueden tener otra cobertura de medicamentos, incluida"+
    "otro seguro privado, TRICARE, salud de empleados federales"+
    "cobertura de beneficios, beneficios de VA o productos farmacéuticos estatales"+
    "programas de asistencia. ¿Tendrá otro medicamento recetado?"+
    "cobertura además de Sharp Health Plan?",
   q5:"¿Es residente de un centro de atención a largo plazo, como un hogar de ancianos?",
   q6:"¿Cuál es su tipo de cobertura médica actual?",
   q7:"¿Cuál es su compañía de seguros actual?",
    C:"C. Elija un médico de atención primaria (PCP)",
    csub1:"¿Necesitas encontrar un médico? Visitar",
    csub2:"para utilizar nuestra herramienta de búsqueda en línea",
    PCPName:"Nombre del PCP",
    PCPMedicalGroup:"Grupo Médico PCP",
    cq:"¿Eres una paciente actual?",
    D:"Preferencias de idioma y formato",
    Dsub:"Marque una de las casillas a continuación si prefiere que le enviemos información en un idioma que no sea inglés o en otro formato",
    Dchk1:"Española",
    Dchk2:"Otra",
    Para1:"Comuníquese con Sharp Health Plan al 1-855-562-8853 si necesita información en un formato accesible o en un idioma que no sea el mencionado anteriormente. Nuestro horario de atención es de 8 a.m. a 8 p.m. 7 días a la semana del 1 de octubre al 31 de marzo: 7 días a la semana de 8 a.m. a 8 p.m. Del 1 de abril al 30 de septiembre: de lunes a viernes, de 8 a 20 h. y los fines de semana y feriados, su llamada será manejada por nuestro sistema de correo de voz. Un representante de atención al cliente le devolverá la llamada telefónica el siguiente día hábil. Los usuarios de TTY / TDD deben llamar al 711",
    Para2:"Sharp Health Plan proporciona la Evidencia de cobertura, el Formulario y el Directorio de proveedores en línea en",
    Para3:"Los miembros pueden solicitar que se les envíe una copia impresa llamando a Atención al Cliente al número de teléfono que figura arriba ",
    Para4:"Comuníquese con Ventaja directa aguda al 1-855-862-8853 si necesita información en otro formato o idioma que no sea el que se menciona arriba. "+
    "(Los usuarios de TTY / TDD deben llamar al 711). Nuestro horario de atención es de 8 a.m. a 6 p.m., de lunes a viernes.",
    Para5:"Ventaja directa aguda es ofrecido por Sharp Health Plan. Ventaja directa aguda es un plan HMO con contrato con Medicare. Inscripción en,"+
    "Ventaja directa aguda depende de la renovación del contrato. Debe continuar pagando su prima de la Parte B. Esta información no es una"+
  "descripción completa de los beneficios. Comuníquese con el plan para obtener más información. Se pueden aplicar limitaciones, copagos y restricciones."+
    "Los beneficios, las primas y / o los copagos / coseguros pueden cambiar a partir del 1 de enero de cada año.",
    NOTEcp:"NOTA",
    NOTEcpPart:"Puede guardar y continuar sin completar todos los campos obligatorios (*); sin embargo, todos los campos obligatorios deben completarse antes de enviar el formulario de inscripción",
    
    
    retirement:"Si es así, fecha de jubilación (MM/DD/YYYY)",    
    nameretiree:"Si la respuesta es No, nombre del jubilado",
    spousename:"En caso afirmativo, nombre del cónyuge",
         dependents:"Nombre (s) de las dependientes(s)",
      q4sub1:"¿Ha tenido un trasplante de riñón exitoso y / o ya no necesita diálisis regular?",
      q4sub2:"En caso afirmativo, es posible que un representante de ventas con licencia deba comunicarse con usted para obtener información adicional",
      coverage:"Nombre de otra cobertura",
      coverageId:"ID # de esta cobertura", 
      grpcov:"Grupo # para esta cobertura",
      isnt:"Nombre de la institución",
      phoneinst:"Número de teléfono de la institución",
      addressint:"Dirección de la institución (número y calle)",   
  
  
  },
     step4:{
      STEP4:"PASO 4",
      READ_SIGN:"LEER Y FIRMAR",
      subHead:"Lea esta información importante",
      subHead1:"Ventaja directa aguda es un plan HMO con contrato con Medicare. "+
      "La inscripción en Ventaja directa aguda depende de la renovación del contrato",
      Para1:"Esta información no es una descripción completa de los beneficios."+
      "Comuníquese con el plan para obtener más información. Limitaciones, copagos, "+
      "y pueden aplicarse restricciones. Beneficios, primas y / o "+
      "los copagos / coseguros pueden cambiar el 1 de enero o cada año. Tú "+
      "debe seguir pagando su prima de la Parte B de Medicare ",
      Para2:"Si actualmente tiene cobertura médica de un empleador o sindicato, "+
      "unirse a Ventaja directa aguda podría afectar a su empleador o sindicato "+
      "beneficios de la salud. Podría perder la salud de su empleador o sindicato "+
      "cobertura si se inscribe en Ventaja directa aguda. Leer las comunicaciones "+
      "su empleador o sindicato lo envía. Si tiene preguntas, visite "+
      "su sitio web, o póngase en contacto con la oficina que figura en su "+
      "Comunicaciones Si no hay información sobre a quién contactar, "+
      "su administrador de beneficios o la oficina que responde preguntas "+
      "acerca de su cobertura puede ayudar",
      Para3:"POR FAVOR LEA Y FIRME ABAJO",
      Para4:"Al completar esta solicitud de inscripción, acepto lo siguiente ",
      Para5:"Ventaja directa aguda es un plan Medicare Advantage y tiene contrato "+
      "con el gobierno federal. Tendré que conservar mis Partes de Medicare " +
      "A y B. Solo puedo estar en un plan Medicare Advantage a la vez " +
      "y entiendo que mi inscripción en este plan " +
      "finalizará automáticamente mi inscripción en otro Medicare Direct Advantage o " +
      "plan de medicamentos recetados. Es mi responsabilidad informarle sobre" +
      "cualquier cobertura de medicamentos recetados que tenga o pueda obtener en el " +
      "futuro. La inscripción en este plan es generalmente para todo el año. " +
      "Una vez que me inscriba, puedo dejar este plan o hacer cambios solo en " +
      "ciertas épocas del año en las que hay un período de inscripción disponible " +
      "(Ejemplo: del 15 de octubre al 7 de diciembre de cada año), o bajo ciertos " +
      "circunstancias especiales",
      Para6:"Ventaja directa aguda atiende un área de servicio específica. Si me mudo de "+
      "el área que sirve Ventaja directa aguda, necesito notificar el plan " +
      "para poder cancelar mi inscripción y encontrar un nuevo plan en mi nueva área. Una vez que sea " +
      "miembro de Ventaja directa aguda, tengo derecho a apelar plan " +
      "decisiones sobre pagos o servicios si no estoy de acuerdo. Leeré el " +
      "Documento de Evidencia de cobertura de Ventaja directa aguda cuando lo reciba " +
      "para saber qué reglas debo seguir para obtener cobertura con esto " +
      "Plan Medicare Advantage. Entiendo que las personas con Medicare " +
      "por lo general, no están cubiertos por Medicare mientras están fuera del país" +
      "excepto por una cobertura limitada cerca de la frontera de EE. UU",
      Para7:"Entiendo que a partir de la fecha de cobertura de Ventaja directa aguda "+
      "comienza, debo recibir toda mi atención médica de Ventaja directa aguda, " +
      "excepto para servicios de emergencia o de urgencia o fuera del área " +
      "Servicios de diálisis. Servicios autorizados por Ventaja directa aguda y " +
      "otros servicios contenidos en mi Ventaja directa aguda Evidencia de " +
      "Documento de cobertura (también conocido como contrato de miembro o suscriptor " +
      "acuerdo) serán cubiertos. Sin autorización",
      Para8:"NI MEDICARE NI Ventaja directa aguda PAGARÁN LOS SERVICIOS",
      Para9:"Entiendo que si recibo asistencia de un agente de ventas, "+
      "corredor u otra persona empleada o contratada por Aguda " +
      "Ventaja directa, es posible que se le pague según mi inscripción en Aguda " +
      "Ventaja directa",
      Para10:"Liberación de información",
      
      Para13:"Al unirse a este Medicare "+
      "Ventaja directa, reconozco que Ventaja directa aguda lanzará mi " +
      "información a Medicare y otros planes según sea necesario para " +
      "tratamiento, pago y operaciones de atención médica. También reconozco " +
      "que Ventaja directa aguda divulgará mi información, incluida mi " +
      "datos de eventos de medicamentos recetados a Medicare, quien puede divulgarlos para " +
      "investigación y otros fines que sigan todos los requisitos federales aplicables " +
      "estatutos y reglamentos. La información en este formulario de inscripción " +
      "es correcta a mi leal saber y entender. Entiendo que si " +
      "proporcione intencionalmente información falsa en este formulario, seré " +
      "desafiliado del plan",
      Para14:"Sharp Health Plan es un plan HMO con contrato con Medicare . " +
      "La inscripción en Sharp Health Plan depende de la renovación del contrato ",
      Para15:" Si actualmente tiene cobertura médica de un empleador o sindicato, "+
      "unirse a Sharp Health Plan podría afectar a su empleador o sindicato " +
      "Beneficios de salud. Podría perder la salud de su empleador o sindicato " +
      "cobertura si se inscribe en Sharp Health Plan. Lea las comunicaciones " +
      "su empleador o sindicato le envía. Si tiene preguntas, visite " +
      "su sitio web, o póngase en contacto con la oficina que aparece en su " +
      "comunicaciones. Si no hay información sobre a quién contactar, " +
      "su administrador de beneficios o la oficina que responde preguntas " +
      "acerca de su cobertura puede ayudar",
      Para16:"Sharp Health Plan es un plan Medicare Advantage y tiene un contrato "+
      "con el gobierno federal. Tendré que conservar mis Partes de Medicare " +
      "A y B. Solo puedo estar en un plan Medicare Advantage a la vez " +
      "y entiendo que mi inscripción en este plan " +
      "finalizará automáticamente mi inscripción en otro plan de salud de Medicare o " +
      "plan de medicamentos recetados. Es mi responsabilidad informarle sobre " +
      "cualquier cobertura de medicamentos recetados que tenga o pueda obtener en el " +
      "futuro. La inscripción en este plan es generalmente para todo el año. " +
      "Una vez que me inscriba, puedo dejar este plan o hacer cambios solo en" +
      "ciertas épocas del año en las que hay un período de inscripción disponible" +
      "(Ejemplo: del 15 de octubre al 7 de diciembre de cada año), o bajo ciertos" +
      "circunstancias especiales",
      Para17:"Sharp Health Plan presta servicios en un área de servicio específica. Si me mudo de "+
      "el área que sirve Sharp Health Plan, necesito notificar al plan " +
      "para poder cancelar mi inscripción y encontrar un nuevo plan en mi nueva área. Una vez que sea " +
      "miembro de Sharp Health Plan, tengo derecho a apelar el plan " +
      "decisiones sobre pagos o servicios si no estoy de acuerdo. Leeré el " +
      "Documento de Evidencia de cobertura de Sharp Health Plan cuando lo reciba " +
      "para saber qué reglas debo seguir para obtener cobertura con esto " +
      "Plan Medicare Advantage. Entiendo que las personas con Medicare " +
      "por lo general, no están cubiertos por Medicare mientras están fuera del país " +
      "excepto por una cobertura limitada cerca de la frontera de EE. UU ",
      Para18:"Entiendo que a partir de la fecha de cobertura de Sharp Health Plan "+
      "comienza, debo obtener toda mi atención médica de Sharp Health Plan, " +
      "excepto para servicios de emergencia o de urgencia o fuera del área " +
      "servicios de diálisis. Servicios autorizados por Sharp Health Plan y " +
      "otros servicios incluidos en mi Evidencia de Sharp Health Plan de " +
      "Documento de cobertura (también conocido como contrato de miembro o suscriptor " +
      "acuerdo) serán cubiertos. Sin autorización ",
      Para19:"NI MEDICARE NI SHARP HEALTH PLAN PAGARÁN LOS SERVICIOS ",
      Para20:"Entiendo que si recibo ayuda de un agente de ventas, "+
      "corredor u otra persona empleada o contratada por Sharp "+
      "Plan de salud, se le puede pagar en función de mi inscripción en Sharp "+
      "Plan de salud",
      
      Para11:"Al unirse a este Medicare "+
      "plan de salud, reconozco que Sharp Health Plan divulgará mi "+
      "información a Medicare y otros planes según sea necesario para "+
      "tratamiento, pago y operaciones de atención médica. Yo tambien reconozco "+
      "que Sharp Health Plan divulgará mi información, incluida mi "+
      "datos de eventos de medicamentos recetados a Medicare, quien puede divulgarlos para "+
      "investigación y otros propósitos que sigan todos los "+
      "estatutos y reglamentos. La información en este formulario de inscripción "+
      "es correcta a mi leal saber y entender. Entiendo que si yo "+
      "proporcione intencionalmente información falsa en este formulario, seré "+
        "dado de baja del plan",
      Para12:"Entiendo que mi firma (o la firma de la persona "+
       "autorizado para actuar en mi nombre de acuerdo con las leyes del Estado donde "+
        "live) en esta aplicación significa que he leído y entendido "+
        "el contenido de esta aplicación. Si está firmado por un autorizado "+
        "individuo (como se describe arriba), esta firma certifica que: 1) "+
        "esta persona está autorizada por la ley estatal para completar este "+
        "registro y 2) la documentación de esta autoridad está disponible "+
        "a solicitud de Medicare",
      accept:"ACEPTO LOS TÉRMINOS DE ESTE ACUERDO",
      Name:"Nombre",
      Digital:" Firma digital",
      TodayDate:" De hoy Fecha",
      authorized:"¿Eres un representante autorizado?",
      authorPart:"Si es el representante autorizado, debe firmar arriba y proporcionar la siguiente información",
      Enrollee:"Relación con la inscrita",
      Address:"Habla a",
      PhoneNumber:"Número de teléfono",
      Licensed:"¿Trabaja con un representante de ventas autorizado?",
      sale:"Nombre del representante de ventas",
      LicenseNo:"Número de licencia del representante de ventas",
      NOTE:"NOTA",
      notepart:"Puede guardar y continuar sin completar todos los campos obligatorios (*); sin embargo, todos los campos obligatorios deben completarse antes de enviar el formulario de inscripción",
    },
    
user:{
  emailAdd:"Dirección de correo electrónico",
  pwd:"Contraseña",
  repwd:"Escriba la contraseña otra vez",
  guest:"CONTINUAR COMO INVITADA",
  sign:"REGÍSTRATE",
  already:"Ya tienes una cuenta?",
  log:"Entre aquí",
  login:"Iniciar sesión",
  rtpwd:"Restablecer contraseña aquí",

  Email:"Correo electrónico",
  newpwd:"Nueva contraseña",
  confpwd:"Confirmar contraseña",
  Submit:"Enviar",
  reset:"Enviar Restablecer",

  fogsub:"Ingrese su dirección de correo electrónico a continuación y le enviaremos instrucciones para restablecer la contraseña",
  foghead:"Olvidaste tu contraseña ?",

  loghead:"Inicie sesión en su cuenta de Medicare de Sharp Health Plan",
  logsub:"Sharp Health Plan le brinda acceso a instalaciones y programas que "+
  "ayudarlo a aprovechar al máximo su atención médica. Estamos aquí para hacer que la búsqueda y" +
  "inscribirse en el plan correcto es simple. Ya sea que nunca haya comprado" +
  "La cobertura de salud de Medicare antes o está considerando cambiar de su" +
  "plan actual, estamos comprometidos a hacer que su experiencia de atención médica" +
  "asequible, simple, accesible y personal. En Sharp Health Plan, nosotros" +
  "ofrecer planes de Medicare para sentirse bien",
  forget:"¿Se te olvidó tu contraseña?"

},
enroll:{
  Step1:"Paso 1",
  choose :"ELIGE UN PLAN",
  st1sub1 :"Antes de comenzar su formulario de Medicare en línea, deberá saber en qué plan le gustaría inscribirse",
  st1sub2:"Haga clic en el enlace a continuación para explorar los planes Medicare Advantage de Sharp Health Plan y encontrar el mejor para sus necesidades de atención médica",
  st1sub3:"Si tiene preguntas para nuestros especialistas de Sharp Advantage, haga clic en el botón",
  Browse:"Explorar planes",

  Step2:"Paso 2",
  gather:"REÚNE SU INFORMACIÓN",
  st2sub1:"Hay dos elementos importantes que debe recopilar antes de comenzar con el formulario de inscripción en línea",
  st1:"Su tarjeta de Medicare roja, blanca y azul",
  st2:"El nombre de su médico de atención primaria (PCP) y el grupo médico del plan",
  st2sub2:'Si actualmente no tiene un PCP o le gustaría seleccionar un PCP diferente, haga clic en el botón a continuación para usar nuestra herramienta de búsqueda en línea "Encontrar una doctora"',
  dr:"Encontrar una doctora",

  Step3:"Paso 3",
  start:"COMIENCE SU FORMULARIO DE INSCRIPCIÓN",
  st3sub1:"Cuando esté listo para inscribirse en un plan, deberá crear una cuenta de usuario para comenzar la inscripción en línea.",
  st3sub2:"Una vez que tenga una cuenta, podrá comenzar su formulario y regresar más tarde para completarlo",
  getst:"Obtener Empezada",

},
year:{
head:"Seleccione el año del plan en el que le gustaría inscribirse",
choose:"Elija año",
Continue:"Seguir",
not:"No estoy segura?",
look:"Mira nuestros planes",

},
plan:{
  hed1:"Al completar este formulario en línea, se inscribirá en un plan Sharp Direct Advantage",
  hed2:"Seleccione el plan en el que le gustaría inscribirse",
  head1:"Abierto a todos los elegibles para Medicare",
  head2:"residentes del condado de San Diego",

  p1:"2021 Ventaja directa de Sharp",                          
  p1sb:"Tarjeta Gold (HMO)",
  p1sb2:"($ 0 por mes, dental no incluido)",

  p2:"2021 Ventaja directa de Sharp",
  p2sb:"Tarjeta Gold (HMO) con servicio dental",
  p2sb2:"($ 12 por mes, Dental Ventaja de Delta Dental [HMO] incluido)",

  p3:"2021 Ventaja directa de Sharp",
  p3sb:"Tarjeta Platinum (HMO) con",
  Dental:"Dental",
  p3sb2:"($ 58 por mes, Dental Ventaja de Delta Dental [HMO] incluido)",

  head3:"Exempleadas de Sharp",
  head4:"HealthCare ",

  p4:" 2021 Aguda Directa Ventaja",
  p4sb:"Básica (HMO)",
  p4sb2:"(Prima mensual de $ 0)",

  p5:"2021 Aguda Directa Ventaja",
  p5sb:"Básica (HMO) con dental",
  p5sb2:"(Prima mensual de $ 12)",

  p6:"2021 Aguda Directa Ventaja",
  p6sb:"Premium (HMO)",
  p6sb2:"(Prima mensual de $ 62)",

  p7:"2021 Aguda Directa Ventaja",
  p7sb:"Premium (HMO) con servicio dental",
  p7sb2:"(Prima mensual de $ 74)",

  head5:"Jubiladas de la ciudad de san diego",
  head6:" (SDPEBA) solamente",

  p8:"2020-21 Aguda Directa Ventaja (HMO)",
  p8sb:"(Prima mensual de $ 201)",


  Continue:"Seguir",
  not:"No estoy segura?",
  look:"Mira nuestros planes",
  


  

    },

    header: {
      search:"Buscar",
      login:"Iniciar sesión",
      ourPlans:"Nuestros planes",
      ourPlansSub1:"Explore nuestros planes",
      ourPlansSub2:"Beneficios añadidos",
      aboutMedicare:"Acerca de Medicare",
      aboutMedicaresub1:"Respuestas a sus preguntas sobre Medicare",
       aboutMedicaresub2:"¿Qué es Medicare?",
       aboutMedicaresub3:"Tipos de planes y elegibilidad de Medicare",
       aboutMedicaresub4:"Periodos de matrícula",
       aboutMedicaresub5:"Glosario de términos",

      enroll:"Inscribirse",
      enrollSub1:"Como inscribirse",
      enrollSub2:"Inscríbase en línea",

      members:"Miembros",
      
      membersSub1:"Centro de miembros",
      membersSub2:"Cómo nombrar un representante",
      membersSub3:"Farmacia",
      membersSub4:"Derechos de los miembros y cancelación de la inscripción",
      membersSub5:"Administre sus costos",
      membersSub6:"Denuncia de fraude",
      membersSub7:"Calificaciones de calidad y estrellas de Medicare",
      membersSub8:"Formularios, autorizaciones y recursos",

      wellness:"Bienestar",
      wellnessSub1:"El centro de bienestar",
      wellnessSub2:"Programa de bienestar",
      wellnessSub3:"Cuidado preventivo",

      findADoctor:"Encontrar un doctor",

      contactUs:" Contacta con nosotras",
      contactUsSub:"Preguntas más frecuentes",
      contact:"Información del contacto",

      suggession:"Para obtener la mejor experiencia, utilice Google Chrome como su navegador para comenzar el proceso de solicitud.",
      CreatAMedicareAccount:"Cree una cuenta de Medicare",
      CreatAMedicareAccountPara:"Sharp Health Plan le brinda acceso a atención experta e instalaciones y programas galardonados que lo ayudan a aprovechar al máximo su atención médica. Estamos aquí para facilitar la búsqueda y la inscripción en el plan adecuado. Ya sea que nunca haya comprado una cobertura de salud de Medicare o esté considerando cambiarse de su plan actual, estamos comprometidos a hacer que su experiencia de atención médica sea asequible, simple, accesible y personal. En Sharp Health Plan, ofrecemos planes de Medicare para sentirse bien.",
      enrollmentSteps:"Pasos para la inscripción",
      enrollmentStepsPare:"Los planes Medicare Advantage de Sharp Health Plan le brindan acceso a instalaciones y programas que lo ayudan a aprovechar al máximo su atención médica. Estamos aquí para facilitar la búsqueda y la inscripción en el plan adecuado. Ya sea que nunca haya comprado una cobertura médica de Medicare o esté considerando cambiar de su plan actual, estamos comprometidos a hacer que su experiencia de atención médica sea asequible, simple, accesible y personal. En Sharp Health Plan, ofrecemos planes de Medicare para sentirse bien.",
      sharpHealthPlan:"Plan Medicare de Sharp Health Plan",
      sharpHealthPlanPara:"Felicitaciones por crear una cuenta con éxito. Es importante que comprenda completamente nuestros beneficios y reglas. Antes de tomar su decisión de inscripción, asegúrese de revisar nuestra preinscripción",
      checklist:"Lista de Verificación",
      sharpHealthPlanPara1:". Si tiene alguna pregunta o necesita información en otro idioma o formato, comuníquese con Sharp Health Plan. Los beneficiarios de Medicare también pueden inscribirse en Sharp Health Plan a través del Centro de inscripción en línea de Medicare de CMS ubicado en",
      stepHeader:"Formulario de inscripción de Sharp Direct Advantage",
      stepeHeaderPara:"Este plan está abierto a todos los residentes elegibles para Medicare del condado de San Diego.",
      changeMyPlane:"Cambiar mi plan",
      contactPara:"Comuníquese con Sharp Health Plan si necesita información en otro idioma o formato",
      planSelection:"Al completar este formulario en línea, se inscribirá en un plan Sharp Direct Advantage.",
      planSelectionpara:"Seleccione el plan en el que le gustaría inscribirse:", 
      
      planSDPEBA:"Formulario de inscripción de Sharp Direct Advantage®",
      planSDPEBAPara:"Este plan se ofrece exclusivamente para los jubilados elegibles para Medicare de la Ciudad de San Diego y sus dependientes patrocinados por la Asociación de Beneficios para Empleados Públicos de San Diego (SDPEBA).",
      planName:"Ventaja directa de Sharp (HMO)",
      planSDPEBASubPara:"Este plan está abierto a todos los jubilados de la Ciudad de San Diego que reúnan los requisitos de Medicare, patrocinado por la Asociación de Beneficios para Empleados Públicos de San Diego (SDPEBA). No es necesario ser miembro de SDPEBA para unirse a este plan.",
      importantInstruction:"Información importante",
      importantInstructionPara:"La solicitud de Medicare está destinada únicamente a cobertura individual. Si usted y su cónyuge / dependiente están solicitando cobertura, cada uno de ustedes deberá completar un formulario de inscripción por separado.",
      importantInstructionNote:"Nota: si su cónyuge / dependiente no es elegible para Medicare, deberá completar el formulario de inscripción para personas que no tienen Medicare / jubilado anticipado. Comuníquese con SDPEBA al 1-888-315-8027 o visite www.sdpeba.org para descargar el formulario de inscripción",

      
      planHealthCareOnly:"Formulario de inscripción grupal de Sharp Direct Advantage",
      planHealthCareOnlyPara:"Este Plan es exclusivamente para ex empleados de Sharp HealthCare.",

      confirmationHeader:"Formulario de inscripción individual de Sharp Direct Advantage",
      confirmationHeaderPara1:"Gracias por elegir Sharp Health Plan. Su formulario de inscripción a Medicare se envió correctamente y el número de confirmación es:",

      confirmationHeaderPara2:", si tiene alguna duda nos pondremos en contacto con usted. Haga clic a continuación para descargar e imprimir una versión completa de su formulario para mantenerla en sus registros",
      downloadPdf:"DESCARGAR VERSIÓN PDF",
      
      nextStep:"Próximos pasos:",
      nextStep1:"Revisaremos su formulario para asegurarnos de que esté completo. Luego, te avisaremos por correo que lo recibimos",
      nextStep2:"Le informaremos a Medicare que solicitó Sharp Direct Advantage.",
      nextStep3:"Dentro de los 10 días calendario posteriores a que Medicare confirme que es elegible, le informaremos cuándo comienza su cobertura. Luego, le enviaremos su tarjeta de identificación de Sharp Direct Advantage e información para miembros nuevos.",
      

    },
footer:{
  madewith: "Hecho con",
  by: "por Sharp Health Plan de San Diego",
  manage: "Administra tu plan",
  pp: "Política de privacidad",
  pay: "Paga tu cuenta",
  appeals: "Apelaciones y quejas",
  faq: "Preguntas frecuentes",
  HL: "Enlaces Útiles",
  login: "Iniciar sesión",
  gc: "Obtener cuidado",
  finddoc: "Encontrar un doctor",
  search: "Buscar lista de medicamentos",
  findcare: "Encuentre una atención de urgencia",
  findhosp: "Encuentra un hospital",
  oc: "Nuestra compañía",
  Cus: "Contacta con nosotros",
  Aus: "Sobre nosotros",
  call: "Llamada",
  hrsofOp1: "Horario de atención: del 1 de octubre al 14 de febrero de 8 a.m. a 8 p.m.",
  hrsofOP2: " Hora del Pacífico, los 7 días de la semana; 15 de febrero - 30 de septiembre de 8 a.m. a",
  hrsofOp3: " 8 p.m. Hora del Pacífico, de lunes a viernes. Llamando después",
  hrsofOp4: " horas lo dirigirá a nuestro sistema de correo de voz y un cliente",
  hrsofOp5: " El representante de atención le devolverá la llamada el siguiente día hábil.",
  helpinLang: "Ayuda en otros idiomas", 
  terms: "Términos de Uso",
  sitemap: "Mapa del sitio",
  need: "Necesita ponerse en contacto",
},

pdf:{
  head1:"FORMULARIO DE SOLICITUD DE INSCRIPCIÓN INDIVIDUAL PARA INSCRIBIRSE EN UN",
  subHead1:"PLAN ADVANTAGE DE MEDICARE (PARTE C)",
  pdfi1:"Envíe su formulario completo y firmado a:",
  pdfi2:"Departamento de Medicare de Sharp Health Plan",
  pdfi3:"8520 Tech Way, Suite 201",
  pdfi4:"92123 de San Diego",
  pdfi5:"Una vez que procesen su solicitud para unirse, un representante del plan se comunicará con usted..",
  pdfi6:"¿Cómo obtengo ayuda con este formulario?",
  pdfi7:"Llame al 1-855-562-8853 (TTY / TDD: 711).",
  pdfi8:"O llame a Medicare al 1-800-MEDICARE",
  pdfi9:"(1-800-633-4227). Los usuarios de TTY pueden llamar al 1-877-486-2048.",

  Section1 :"Sección 1: todos los campos de esta página son obligatorios (a menos que estén marcados como opcionales)",
  tojoin:"Seleccione el plan al que desea unirse",

  plan1:"Tarjeta Sharp Direct Advantage Gold ($ 0 por mes, servicios dentales no incluidos)",
  plan2:"Tarjeta Sharp Direct Advantage Gold ($ 12 por mes, Dental Advantage de Delta Dental [HMO] * incluido)",
  plan3:"Tarjeta Sharp Direct Advantage Platinum ($ 58 por mes, incluye Dental Advantage de Delta Dental [HMO] *)",

  head3:"La cobertura dental integral se brinda a través de DeltaCare USA, un plan tipo HMO ofrecido por" +
  "por Delta Dental of California. Se le asignará automáticamente un dentista de la red en su área. Si desea" +
  "para cambiar a otro proveedor de la red, comuníquese con Delta Dental.",

  Streetaddress:"Dirección",
  MediInfo:"Su información de Medicare",
  label1:"Responde estas importantes preguntas",
  label2:"¿Tendrá otra cobertura de medicamentos recetados (como VA, TRICARE) además de Sharp Health Plan?",
  auth:"Si es el representante autorizado, firme arriba y complete estos campos",
  Signature:"Firma",
  date:"Fecha",

  Section:"Sección",
  Physician:"Indique su médico de atención primaria (PCP), clínica o centro de salud",

 
  FirstName: "Nombre de pila:",
  LastName:"Apellido:",
  Middle:"inicial del segundo nombre",
  DOB:"Fecha de nacimiento: DD / MM / AA",
  Sex:"Sexo:",
  plan4:"2021 Sharp Direct Advantage Basic (HMO) (prima mensual de $ 0)",
  plan5:"2021 Sharp Direct Advantage Basic (HMO) With Dental ($12 monthly premium)",
  plan6:"2021 Sharp Direct Advantage Premium (HMO) ($62 monthly premium)",
  plan7:"2021 Sharp Direct Advantage Premium (HMO) With Dental ($74 monthly premium)",
  primaryno:"Primary Phone Number",
}
};
export default es;
