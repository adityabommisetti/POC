export function en() {
  return import("./en").then((res) => res.default);
}

export function es() {
  return import("./es").then((res) => res.default);
}
