import React, { Component } from "react";
import html2pdf from "html2pdf.js";
import { Text } from "react-internationalization";
import "../assests/css/styles12.css";

class Form2 extends Component{
    constructor(props) {
        super()
	}
	componentDidMount(){
 
			var element = document.getElementById('pdfbody');		
		var opt = {
		  margin:       0.2,
		  filename:     'myfile.pdf',
		  image:        { type: 'jpeg', quality: 0.99 },
		  html2canvas:  { scale: 2 },
		  jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' }
		}; 
		
		html2pdf().from(element).set(opt).save()
		
		
	  
		}
	
    render(){
		const 	{data}=this.props
        return(
            <>
                  <div id="pdfbody">

                  <table class="page">
			<tr>
				<td>
				 <img src={require("../assests/images/sharp-bnw-logo.png")} class="sharp-bnw-logo"/>
				</td>
			</tr>
			
			<tr>
			<td>
            <table class="page2-table">
				<tr><td colspan="6" class="gray-bg strong"><Text id="pdf.Section1"/> </td></tr>
				<tr>
					<td colspan="6"><Text id="pdf.tojoin"/>:
						<ul class="list-style-none">
						<li><label class="radio_container"><input name="select-plan" type="radio"
							checked={this.props.selectedPlan === "SDAGC20" || this.props.selectedPlan === "SDAGCWD20" 
							|| this.props.selectedPlan === "SDAPC20"} />
							 <span class="checkmark"></span> <Text id="pdf.plan1"/></label></li>
							<li><label class="radio_container"><input name="select-plan" type="radio"
							 checked={this.props.selectedPlan === "SDAB20" || this.props.selectedPlan === "SDABWD20" 
							|| this.props.selectedPlan === "SDAP20" || this.props.selectedPlan === "SDAPWD20"}/> <span class="checkmark"></span> <Text id="pdf.plan2"/></label></li>
							<li><label class="radio_container"><input name="select-plan" type="radio" 
							checked={this.props.selectedPlan === "SDAHMO1" || this.props.selectedPlan === "SDAHMO20" 
							}/> <span class="checkmark"></span> <Text id="pdf.plan3"/></label></li>

						</ul>
					
					</td>
				</tr>
                <tr><td colspan="6">
						<span class="name-fields"><Text id="app.Effectdate"/><br/><input type="text" value={data.effDate}
						
						class="full-width inputFieldnew"  /></span> <span class="name-fields"><Text id="app.Socialnumber"/><br/><input type="text" 
						class="full-width inputFieldnew"  value={data.ssn} /></span> 
				</td></tr>
				<tr><td colspan="6">
						<span class="name-fields"><Text id="pdf.FirstName"/><br/><input type="text"
						 value={data.firstName} name="firstName"
						class="full-width inputFieldnew"  /></span> <span class="name-fields"><Text id="pdf.LastName"/><br/><input type="text" 
						class="full-width inputFieldnew"  value={data.lastName} name="lastName"/></span> <span class="name-fields"><Text id="pdf.Middle"/>:<br/><input type="text" class="full-width inputFieldnew"  value={data.middleInitial}/></span>
				</td></tr>
				<tr>
					<td colspan="2"><Text id="pdf.DOB"/> <br/> <input type="text"
					 name="birthDate"  value={data.birthDate} class="inputFieldnew"/></td>
					<td><Text id="pdf.Sex"/> <br/><label class="radio_container label-gap"><input type="radio" name="sex"  checked={data.sex === "M"} /> <span class="checkmark"></span><Text id="app.Male"/></label> <label class="radio_container"><input type="radio" name="sex"  checked={data.sex === "F"}/> <span class="checkmark"></span> <Text id="app.Female"/></label></td>
					<td colspan="3"><Text id="pdf.primaryno"/>: <br/><input type="text" class="width75per inputFieldnew"     value={data.primaryPhone} /></td>
				</tr>
				<tr><td colspan="6"><Text id="app.PermanentAddress"/>(<Text id="app.POBox"/>): <br/><input type="text" class="full-width inputFieldnew"   value={data.permanentAddrStreet}/></td></tr>
				<tr><td colspan="2"><Text id="app.City"/>:<br/> <input type="text" class="full-width inputFieldnew"   value={data.permanentCity}/></td><td><Text id="app.County"/>:<br/> <input type="text" value={data.permanentCounty} class="full-width inputFieldnew"/></td><td><Text id="app.State"/>:<br/> <input type="text"   value="CA" class="full-width inputFieldnew"/></td><td colspan="2"><Text id="app.ZIPCode"/>:<br/> <input type="text" class="full-width inputFieldnew"  value={data.permanentZip}/></td></tr>
				<tr><td colspan="6"><Text id="app.maillingAdd"/>:<br/>
				 <input type="text" class="width85per inputFieldnew" value={data.mailingAddr}/>
				</td></tr>
				<tr><td colspan="3"><Text id="app.City"/><br/> <input type="text" class="full-width inputFieldnew"  value={data.mailingCity}/></td><td><Text id="app.State"/>:<br/> <input type="text" class="full-width inputFieldnew"   value={data.state}/></td><td colspan="2"><Text id="app.ZIPCode"/>:<br/> <input type="text" class="full-width inputFieldnew" value={data.mailingzip}/></td></tr>				
                <tr><td colspan="6"><Text id="app.email"/>:<br/>
				<input type="text" class="width85per inputFieldnew" value={data.mailingAddr}/>
				</td></tr>
				<tr>
                    <td colspan="6">
                    <ul class="list-style-none">
                <li><label class="radio_container"><input type="checkbox"/> <span class="checkmark"></span> <Text id="app.Please"/>.</label></li>
                <li><label class="radio_container"><input type="checkbox"/> <span class="checkmark"></span> <Text id="app.news"/>.</label></li>
                </ul>
                    </td>
                </tr>
				
			</table>
	
			</td>
		 </tr>
      </table>
      
      <div class="html2pdf__page-break"></div>

      

<div class="page">

      <table class="page2-table">
      <tr><td colspan="6" class="gray-bg strong"><Text id="app.imp"/>: <Text id="app.impsub"/>:</td></tr>
      <tr><td colspan="6">
						<span class="name-fields"><Text id="app.MedicareNo"/><br/><input type="text"
						value={data.medicareClaim}
						class="full-width inputFieldnew"  /></span> <span class="name-fields"><Text id="step2.Hospi"/><br/><input type="text" 
						class="full-width inputFieldnew"  value={data.hospitalPartA}/></span> <span class="name-fields"><Text id="step2.Medical"/>:<br/><input type="text" value={data.hospitalPartB} class="full-width inputFieldnew"/></span>
				</td></tr>
                <tr><td colspan="6" class="gray-bg strong"><Text id="step2.BPara"/>:</td></tr>
                <tr><td colspan="6">
						<p><Text id="step2.Para8"/></p><br/>
                        <p><Text id="step2.Para4"/></p><br/>
                        <p><Text id="step2.Para9"/></p><br/>
                        <p><Text id="step2.Para10"/></p><br/>
                        <p><Text id="step2.Para11"/></p><br/>
   				</td></tr>
                   <tr><td colspan="6">
                   <p><Text id="step2.paymentoption"/></p>
                   <ul class="list-style-none">
							<li><label class="radio_container"><input name="select-plan" type="radio" checked={data.paymentOption === "D"}/> <span class="checkmark"></span> <Text id="step2.Getbill"/></label></li>
							<li><label class="radio_container"><input name="select-plan" type="radio"  checked={data.paymentOption === "R"}/> <span class="checkmark"></span> <Text id="step2.Electronicfunds"/></label></li>							
						</ul>
                   </td>
                   </tr>
				   <div class="html2pdf__page-break"></div>
                   <tr><td colspan="6">
						<span class="name-fields"><Text id="step2.Accountname"/><br/><input type="text"
						value={data.acctholdername}
						class="full-width inputFieldnew"  /></span> <span class="name-fields"><Text id="step2.Bankname"/><br/><input type="text" 
						class="full-width inputFieldnew"  value={data.bankname} /></span> 
				</td></tr>
                <tr><td colspan="6">
                <span class="name-fields"><Text id="step2.Accounttype"/>:
                   <ul class="list-style-none">
							<li><label class="radio_container"><input name="select-plan" type="radio" checked={data.acctType === "C"}/> <span class="checkmark"></span> <Text id="step2.Checking"/></label></li>
							<li><label class="radio_container"><input name="select-plan" type="radio" checked={data.acctType === "S"}/> <span class="checkmark"></span> <Text id="step2.Saving"/></label></li>							
						</ul> 
                        </span> 
                        <span class="name-fields"><Text id="step2.routingnumber"/><br/><input type="text"
						value={data.routingNumber}
						class="full-width inputFieldnew"  />
                        <Text id="step2.Bankaccountnumber"/><br/><input type="text"
						value={data.accountNumber}
						class="full-width inputFieldnew"  />
                        </span>
				</td></tr>
                <tr><td colspan="6">
                   <p><Text id="step2.C"/></p>
                   <ol class="list-style-none" >
							<li>1.<Text id="step2.q1"/><br/>
							&nbsp;	&nbsp;	&nbsp; <label class="radio_container"><input name="select-plan" type="radio" checked={data.retiree === "Y"}/> <span class="checkmark"></span> Yes </label> &nbsp;&nbsp;&nbsp;&nbsp; <label class="radio_container"><input name="select-plan" type="radio" checked={data.retiree === "N"}/> <span class="checkmark"></span> No</label> <br/>
                          
                           <Text id="st2cat3.retirement"/><br/><input type="text"
						value={data.retiredate}
						class="full-width inputFieldnew"  />
                        <Text id="st2cat3.nameretiree"/><br/><input type="text"
						value={data.retirename} 
						class="full-width inputFieldnew"  />
                            </li>
							<li>
                            2.<Text id="step2.q2"/><br/>
							&nbsp;	&nbsp;	&nbsp; <label class="radio_container"><input name="select-plan" type="radio" checked={data.empCover === "Y"}/> <span class="checkmark"></span> Yes </label> &nbsp;&nbsp;&nbsp;&nbsp; <label class="radio_container"><input name="select-plan" type="radio" checked={data.empCover === "N"}/> <span class="checkmark"></span> No</label> <br/>
                          
                          <Text id="st2cat3.spousename"/><br/><input type="text"
                       value={data.dependentSpouse} 
                       class="full-width inputFieldnew"  />
                       <Text id="st2cat3.dependents"/><br/><input type="text"
                       value={data.dependentOther} 
                       class="full-width inputFieldnew"  />
                                </li>	
                                <li>
                            3.<Text id="step2.q3"/><br/>
							&nbsp;	&nbsp;	&nbsp;<label class="radio_container"><input name="select-plan" type="radio" checked={data.spousework === "Y"}/> <span class="checkmark"></span> Yes </label> &nbsp;&nbsp;&nbsp;&nbsp; <label class="radio_container"><input name="select-plan" type="radio" checked={data.spousework === "N"}/> <span class="checkmark"></span> No</label> <br/>
                          
                          
                                </li>		
                                <li>
                                4.<Text id="st2cat3.q3"/><br/>
                                <Text id="st2cat3.q4sub1"/><br/>
                                <Text id="st2cat3.q4sub2"/><br/>
                                &nbsp;	&nbsp;	&nbsp;<label class="radio_container"><input name="select-plan" type="radio" checked={data.esrdcontact === "Y"}/> <span class="checkmark"></span> Yes </label> &nbsp;&nbsp;&nbsp;&nbsp; <label class="radio_container"><input name="select-plan" type="radio" checked={data.esrdcontact === "N"}/> <span class="checkmark"></span> No</label> <br/>

                                    </li>			
                                    <li>
                                5.<Text id="step2.q5"/><br/>
                                
								&nbsp;	&nbsp;	&nbsp; <label class="radio_container"><input name="select-plan" type="radio" checked={data.vaBenefits === "Y"}/> <span class="checkmark"></span> Yes </label> &nbsp;&nbsp;&nbsp;&nbsp; <label class="radio_container"><input name="select-plan" checked={data.vaBenefits === "N"} type="radio"/> <span class="checkmark"></span> No</label> <br/>
                                <Text id="st2cat3.coverage"/><br/><input type="text"
                       value={data.nameOfCov}
                       class="full-width inputFieldnew"  />
                        <Text id="st2cat3.coverageId"/><br/><input type="text"
                       value={data.idOfCov} 
                       class="full-width inputFieldnew"  />
                        <Text id="st2cat3.grpcov"/><br/><input type="text"
                       value={data.groupOfCov} 
                       class="full-width inputFieldnew"  />
                                    </li>
									<li>
									<div class="html2pdf__page-break"></div><br/>		
                                6.<Text id="step2.q6"/><br/>
                                
								&nbsp;	&nbsp;	&nbsp; <label class="radio_container"><input name="select-plan" type="radio" checked={data.prescriptionDrug === "Y"}/> <span class="checkmark"></span> Yes </label> &nbsp;&nbsp;&nbsp;&nbsp; <label class="radio_container"><input name="select-plan" checked={data.prescriptionDrug === "N"} type="radio"/> <span class="checkmark"></span> No</label> <br/>
                                <Text id="st2cat3.isnt"/><br/><input type="text"
                      value={data.nameOfInst} 
                       class="full-width inputFieldnew"  />
                        <Text id="st2cat3.phoneinst"/><br/><input type="text"
                       value={data.phoneOfInst} 
                       class="full-width inputFieldnew"  />
                        <Text id="st2cat3.addressint"/><br/><input type="text"
                       value={data.addrOfInst}
                       class="full-width inputFieldnew"  />
                                    </li>
									<li>
                                7.<Text id="step2.q7"/><br/>
								<Text id="step2.q7Part"/><br/>
                                
								&nbsp;	&nbsp;	&nbsp;  <label class="radio_container"><input name="select-plan" type="radio" checked={data.existingp === "Y"}/> <span class="checkmark"></span> Yes </label> &nbsp;&nbsp;&nbsp;&nbsp; <label class="radio_container"><input name="select-plan" type="radio" checked={data.existingp === "N"}/> <span class="checkmark"></span> No</label> <br/>
                                <Text id="st2cat3.PCPName"/><br/><input type="text" 
                       value={data.pcpName}
                       class="full-width inputFieldnew"  />
                        <Text id="st2cat3.PCPMedicalGroup"/><br/><input type="text"
                       value={data.pcpMedicalGroupName}
                       class="full-width inputFieldnew"  />                       
                                    </li>
									<li>
                                8.<Text id="step2.q8"/><br/>							
                                
								&nbsp;	&nbsp;	&nbsp;  <label class="radio_container"><input name="select-plan" type="radio" checked={data.language === "SPANISH"}/> <span class="checkmark"></span> <Text id="step2.q8rod1"/> </label> <br/>
								&nbsp;	&nbsp;	&nbsp;<label class="radio_container"><input name="select-plan" type="radio" checked={data.language === "BRAILLE"}/> <span class="checkmark"></span><Text id="step2.q8rod2"/> </label><br/>
								&nbsp;	&nbsp;	&nbsp;<label class="radio_container"><input name="select-plan" type="radio" checked={data.language === "LARGE_PRINT"}/> <span class="checkmark"></span><Text id="step2.q8rod3"/></label><br/>
								&nbsp;	&nbsp;	&nbsp;<label class="radio_container"><input name="select-plan" type="radio" checked={data.language === "OTHER"}/> <span class="checkmark"></span><Text id="step2.q8rod4"/> </label>    <br/>             
								<input type="text"
                       value={data.languageValue}
                       class="full-width inputFieldnew"  />  
								 </li>		
						</ol>
						<p>
							<Text id="step2.Para12"/>							
						</p>
						<p>
							<Text id="step2.Para13"/>							
						</p>
						<p>
							<Text id="step2.NOTECAp"/>
							<Text id="step2.NOTECApPart"/>							
						</p>
                   </td>
                   </tr>
  </table>
          
</div>

<div class="html2pdf__page-break"></div><br/>

<div class="page">
  <table class="page2-table">
	  <tr><td class="gray-bg strong"><Text id="step3.Exhibit1a"/>: <Text id="step3.stepsub"/></td></tr>
	  <tr>
		  <td>
		  <p><strong><Text id="step3.Para1"/>.</strong> <Text id="step3.Para2"/>.</p>
		  <p><Text id="step3.Para3"/></p>
		  <ul class="list-style-none">
		  <li><label class="radio_container"><input type="checkbox" checked={data.aep === "AEP"} /> <span class="checkmark"></span> <Text id="step3.optAnth1"/></label></li>
		  <li><label class="radio_container"><input type="checkbox" checked={data.c1 === "NEW"}/> <span class="checkmark"></span> <Text id="step3.Op2"/>.</label></li>
			    	<li><label class="radio_container margin-bottom0"><input type="checkbox" checked={data.c2 === "MOV"}/> <span class="checkmark"></span> <Text id="step3.Op3"/>. <Text id="step3.movedate"/></label><br/><input type="text" class="addon-field inputFieldnew" value={data.attestation2}/></li>				
					<li><label class="radio_container margin-bottom0"><input type="checkbox" checked={data.c3 === "INC"} /> <span class="checkmark"></span> <Text id="step3.Op4"/>. <Text id="step3.releasedate"/></label><input type="text" class="addon-field inputFieldnew" value={data.attestation3}/></li>
					<li><label class="radio_container margin-bottom0"><input type="checkbox" checked={data.c4 === "RUS"}/> <span class="checkmark" ></span> <Text id="step3.Op5"/>. <Text id="step3.returndate"/></label> <input type="text" class="addon-field inputFieldnew" value={data.attestation4}/></li>
					<li><label class="radio_container margin-bottom0"><input type="checkbox" checked={data.c5 === "LAW"}/> <span class="checkmark" ></span> <Text id="step3.Op6"/>. <Text id="step3.statusdate"/></label> <input type="text" class="addon-field inputFieldnew" value={data.attestation5}/></li>
					<li><label class="radio_container"><input type="checkbox"/> <span class="checkmark" checked={data.c6 === "MDE" }></span> <Text id="step3.Op7"/>.</label></li>
					<li><label class="radio_container margin-bottom0"><input type="checkbox" checked={data.c7 === "HLP"}/> <span class="checkmark" ></span> <Text id="step3.Op8"/>. <Text id="step3.facilitydate"/></label> <input  type="text" class="addon-field inputFieldnew"/></li>
					<li><label class="radio_container"><input type="checkbox" checked={data.c8 === "NLS"}/> <span class="checkmark"></span> <Text id="step3.Op9"/>. <Text id="step3.extrahelp"/></label> <input type="text" class="addon-field inputFieldnew" value={data.attestation8}/></li>
					<li><label class="radio_container"><input type="checkbox"  checked={data.c10 === "LTC"}/> <span class="checkmark" ></span> <Text id="step3.Op10"/>. <Text id="step3.facilitydate"/></label> <input value={data.attestation9} type="text" class="addon-field inputFieldnew"/></li>
					<div class="html2pdf__page-break"></div><br/>
					<li><label class="radio_container"><input type="checkbox"  checked={data.c10 === "PAC"}/> <span class="checkmark" ></span> <Text id="step3.Op11"/>. <Text id="step3.pacedate"/></label> <input value={data.attestation10} type="text" class="addon-field inputFieldnew"/></li>
					<li><label class="radio_container"><input type="checkbox" checked={data.c11 === "LCC"}/> <span class="checkmark" ></span> <Text id="step3.Op12"/>. <Text id="step3.drugdate"/></label> <input value={data.attestation11} type="text" class="addon-field inputFieldnew"/></li>
					<li><label class="radio_container"><input type="checkbox" checked={data.c12 === "LEC"}/> <span class="checkmark"></span> <Text id="step3.Op13"/>. <Text id="step3.leavingdate"/></label> <input value={data.attestation12} type="text" class="addon-field inputFieldnew"/></li>
					<li><label class="radio_container"><input type="checkbox" checked={data.c13 === "PAP"}/> <span class="checkmark"></span> <Text id="step3.Op14"/>.</label></li>
					<li><label class="radio_container"><input type="checkbox" checked={data.c13 === "EOC"}/> <span class="checkmark"></span> <Text id="step3.Op15"/>.</label></li>
					<li><label class="radio_container"><input type="checkbox" checked={data.c15 === "SNP"}/> <span class="checkmark"></span> <Text id="step3.Op16"/>. <Text id="step3.SNPdate"/></label> <input type="text" class="addon-field inputFieldnew" value={data.attestation15}/></li>
					
			  
			  <li><label class="radio_container"><input type="checkbox" checked={data.c16 === "OTH"}/> <span class="checkmark"></span> <Text id="step3.other"/></label></li>
			  
			  
			  </ul>
		  <p><Text id="step3.Para4"/>
			  </p>
		  </td>
	  </tr>
  </table>
</div>
      


<div class="html2pdf__page-break"></div>
<div class="page">
<table class="page2-table">
      <tr><td colspan="6" class="gray-bg strong"><Text id="step4.subHead"/></td></tr>
	  <tr><td colspan="6">
						<p><Text id="step4.Para1"/></p><br/>
                        <p><Text id="step4.Para2"/></p><br/>
                        <p><strong><Text id="step4.Para3"/><br/>
                        <Text id="step4.Para4"/></strong></p><br/>
                        <p><Text id="step4.Para5"/></p><br/>
						<p><Text id="step4.Para6"/></p><br/>
                        <p><Text id="step4.Para7"/><br/>
                        <strong><Text id="step4.Para8"/></strong></p><br/>
                        <p><Text id="step4.Para9"/></p><br/>
						<p>
              <strong><Text id="step4.Para10"/>:</strong><Text id="step4.Para13"/>.
            </p>
						
                        <p><Text id="step4.Para12"/></p><br/>
						<span>:</span>
                        
                        <p><Text id="step4.Para14"/></p><br/>
						<p><Text id="step4.Para1"/></p><br/>
                        <p><Text id="step4.Para15"/></p><br/>
						<p>
              <strong>
              <Text id="step4.READ_SIGN"/> 
                <br />
                <Text id="step4.subHead"/>:
              </strong>
            </p>
						<p><Text id="step4.Para16"/></p><br/>
                        <p><Text id="step4.Para17"/></p><br/>
                        <p>
            <Text id="step4.Para18"/>  ,
              <strong>
              <Text id="step4.Para19"/>.
              </strong>
            </p>
                        <p><Text id="step4.Para20"/></p><br/>
						<p>
              <strong><Text id="step4.Para1"/>:</strong> <Text id="step4.Para11"/>.
            </p>
            <p>
             <Text id="step4.Para12"/>.
            </p>
   				</td></tr>

				   <tr><td colspan="6">
						<span class="name-fields"><Text id="step4.Name"/><br/><input type="text"
						 name="nameSignature" value={data.nameSignature}
						class="full-width inputFieldnew"  />
						</span>
						 <span class="name-fields"><Text id="step4.Digital"/><br/><input type="text" 
						class="full-width inputFieldnew" value={data.nameSignature}   name="digisignature"/></span>
						 <span class="name-fields"><Text id="step4.TodayDate"/><br/><input type="text" value={data.todayDate} class="full-width inputFieldnew" /></span>
				</td></tr>
				<tr><td colspan="6">
				<Text id="step4.authorized"/> <br/><label class="radio_container label-gap"><input type="radio" checked={data.AuthorizedRep === "Y"} name="AuthorizedRep"  /> <span class="checkmark"></span><Text id="app.Yes"/></label> <label class="radio_container"><input type="radio" checked={data.AuthorizedRep === "N"} />
				 <span class="checkmark"></span> <Text id="app.No"/></label>
				</td></tr>
				<tr><td colspan="6">
				<Text id="step4.Licensed"/> <br/><label class="radio_container label-gap"><input type="radio" name="AuthorizedRep"  checked={
                        data.AgentAssistingEnrollment === "Y"}/> <span class="checkmark"></span><Text id="app.Yes"/></label> <label class="radio_container"><input type="radio" checked={
							data.AgentAssistingEnrollment === "N"} />
				 <span class="checkmark"></span> <Text id="app.No"/></label>
				</td></tr>
</table>
</div>
	  </div>  
	 
            </>
        )
    }
}
export default Form2