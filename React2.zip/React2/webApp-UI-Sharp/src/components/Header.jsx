import React, { Component } from "react";
import { Text } from "react-internationalization";
import { connect } from "react-redux";
 class Header extends Component {
  constructor(props) {
    super(props);

    this.state = {};
  }
  zoom = (event, zoom) => {
    event.preventDefault();
    if (zoom === "large") {
      document.body.style.zoom = "125%";
    } else {
      document.body.style.zoom = "100%";
    }
  };
  render() {
    return (
      <React.Fragment>
        <header class="pt-1">
          <div class="container">
            <div class="row flex-nowrap justify-content-between align-items-center" style={{marginBottom:"1.5em"}}>
              <div class="col-4 pt-1">
                <div class="navbar-left shp-logo">
                  <a class="navbar-brand" href="https://www.sharpmedicareadvantage.com">
                    <img
                      src={require("../assests/images/SHP_Logo.png")}
                      width="125"
                      height="60"
                      alt="Sharp Health Plan"
                    />
                  </a>
                </div>
              {/*  <div class="navbar-left nonmob">
                  <img
                    class="make-life-better-tab"
                    src={require("../assests/images/makelifebetter.png")}
                    width="140"
                    height="35"
                    alt="make life better (sm)"
                  />
                </div>*/}
              </div>
              <div class="col-4 text-center">
                <div class="call-us">
                  <a
                    class="navbar-link"
                    href="tel:1-855-562-8853"
                    title="Call 1-855-562-8853 (TTY/TDD 711)"
                  >
                    <img
                      class="talk-to-nurse-img-tab"
                      src={require("../assests/images/talktonurse.png")}
                      height="24"
                      alt="Contact Us"
                    />
                    <strong>Call 1-855-562-8853 (TTY/TDD 711)</strong>
                  </a>
                </div>
              </div>

              <div class="col-4 d-flex justify-content-end align-items-center">
                {navigator.userAgent.indexOf("MSIE") > -1 ||
                navigator.userAgent.indexOf("rv:") > -1 ? null : (
                  <div
                    class="nav-item pull-right"
                    style={{ marginLeft: "0px" }}
                  >
                    <img
                      class="zoom-small"
                      src={require("../assests/images/Text_sizer_small.PNG")}
                      onClick={(e) => this.zoom(e, "small")}
                      height="25px"
                      alt=""
                      title="Change text size"
                    />
                    <img
                      class="zoom-large"
                      src={require("../assests/images/Text_sizer_large.PNG")}
                      onClick={(e) => this.zoom(e, "large")}
                      width="24"
                      height="35"
                      alt=""
                      title="Change text size"
                    />
                  </div>
                )}

                <div class="nav-item pull-right" >
                  <a
                    class="navbar-link"
                    href="https://www.sharpmedicareadvantage.com/search"
                    title="Search for something"

                  >
                   <Text id="header.search"/>
                    <img
                      class="srch-login-img-tab"
                      src={require("../assests/images/search.png")}
                      width="35"
                      height="35"
                      alt="Search"
                    />
                  </a>
                </div>
                <div class="nav-item pull-right" >
                  <a
                    class="navbar-link"
                    href="https://www.sharpmedicareadvantage.com/login"
                    title="Log in"
                    data-module="-loginOverlay"
                  >
                   <Text id="header.login"/>
                    <img
                      class="srch-login-img-tab"
                      src={require("../assests/images/login.png")}
                      width="35"
                      height="35"
                      alt="Member Login"
                    />
                  </a>
                </div>
                <div class="clearfix"></div>
              </div>
            </div>

            <div class="container navbar-container-bg">
              <nav class="navbar navbar-expand-lg" id="main_navbar">
                <button
                  class="navbar-toggler"
                  type="button"
                  data-toggle="collapse"
                  data-target="#navbarSupportedContent"
                  aria-controls="navbarSupportedContent"
                  aria-expanded="false"
                  aria-label="Toggle navigation"
                >
                  <span class="navbar-toggler-icon">
                    <i class="icon-menu"></i>
                  </span>
                </button>
                <a class="hidden-element" href="#main-content-area">
                  Skip Navigation
                </a>
                <div
                  class="collapse navbar-collapse"
                  id="navbarSupportedContent"
                >
                  <ul class="navbar-nav mr-auto">
                    <li class={this.props.lang==="es"?"nav-item headpadding2":"nav-item headpadding"}>
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        id="ourplan-dropdown"
                        role="button"
                        data-toggle="dropdown"
                        aria-haspopup="true"
                        aria-expanded="false"
                      >
                       <Text id="header.ourPlans" />
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="ourplan-dropdown"
                      >
                        <li>
                          <a
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/our-plans/explore-our-plans"
                          >
                           <Text id="header.ourPlansSub1" />
                          </a>
                        </li>
                        <li>
                          <a
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/our-plans/added-benefits"
                          >
                            <Text id="header.ourPlansSub2" />
                          </a>
                        </li>
                      </ul>
                    </li>
                    <li class={this.props.lang==="es"?"nav-item headpadding2":"nav-item headpadding"}>
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        id="about-medicare-dropdown"
                        role="button"
                        data-toggle="dropdown"
                        aria-haspopup="true"
                        aria-expanded="false"
                      >
                        <Text id="header.aboutMedicare"/>
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="about-medicare-dropdown"
                      >
                        <li>
                          <a
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/about-medicare/your-medicare-questions-answered"
                            target="_blank"
                          >
                            <Text id="header.aboutMedicaresub1"/>
                            
                          </a>
                        </li>
                        <li>
                          <a
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/about-medicare/what-is-medicare"
                            target="_blank"
                          >
                            <Text id="header.aboutMedicaresub2"/>
                          </a>
                        </li>
                        <li>
                          <a
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/about-medicare/medicare-eligibility-and-plan-types"
                            target="_blank"
                          >
                            <Text id="header.aboutMedicaresub3"/>
                          </a>
                        </li>
                        <li>
                          <a
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/about-medicare/enrollment-periods"
                            target="_blank"
                          >
                            <Text id="header.aboutMedicaresub4"/>
                          </a>
                        </li>
                        <li>
                          <a
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/about-medicare/glossary-of-terms"
                            target="_blank"
                          >
                            <Text id="header.aboutMedicaresub5"/>
                          </a>
                        </li>
                      </ul>
                    </li>
                    <li class={this.props.lang==="es"?"nav-item headpadding2":"nav-item headpadding"}>
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        id="enroll-dropdown"
                        role="button"
                        data-toggle="dropdown"
                        aria-haspopup="true"
                        aria-expanded="false"
                      >
                        <Text id="header.enroll"/>
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="enroll-dropdown"
                      >
                        <li>
                          <a
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/enroll/how-to-enroll"
                            target="_blank"
                          >
                            <Text id="header.enrollSub1"/>
                          </a>
                        </li>
                        <li>
                          <a
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/enroll/enroll-online"
                            target="_blank"
                          >
                            <Text id="header.enrollSub2"/>
                          </a>
                        </li>
                      </ul>
                    </li>
                    <li class={this.props.lang==="es"?"nav-item headpadding2":"nav-item headpadding"}>
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        id="about-medicare-dropdown2"
                        role="button"
                        data-toggle="dropdown"
                        aria-haspopup="true"
                        aria-expanded="false"
                      >
                        <Text id="header.members"/>
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="about-medicare-dropdown2"
                      >
                        <li>
                          <a
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/members/member-center"
                            target="_blank"
                          >
                            <Text id="header.membersSub1"/>
                          </a>
                        </li>
                        <li>
                          <a
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/members/how-to-appoint-a-representative"
                            target="_blank"
                          >
                            <Text id="header.membersSub2"/>
                          </a>
                        </li>
                        <li>
                          <a
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/members/pharmacy-group-page/pharmacy-and-prescription-drugs"
                            target="_blank"
                          >
                           <Text id="header.membersSub3"/>
                          </a>
                        </li>
                        <li>
                          <a
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/members/member-rights-and-disenrollment"
                            target="_blank"
                          >
                            <Text id="header.membersSub4"/>
                          </a>
                        </li>
                        <li>
                          <a
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/members/manage-your-costs"
                            target="_blank"
                          >
                            <Text id="header.membersSub5"/>
                          </a>
                        </li>
                        <li>
                          <a
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/members/reporting-fraud"
                            target="_blank"
                          >
                           <Text id="header.membersSub6"/>
                          </a>
                        </li>
                        <li>
                          <a
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/members/quality-and-medicare-star-ratings"
                            target="_blank"
                          >
                           <Text id="header.membersSub7"/>
                          </a>
                        </li>
                        <li>
                          <a
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/members/forms-authorizations-resources/resources-for-sharp-advantage-plans"
                            target="_blank"
                          >
                            <Text id="header.membersSub8"/>
                          </a>
                        </li>
                      </ul>
                    </li>
                    <li class={this.props.lang==="es"?"nav-item headpadding2":"nav-item headpadding"}>
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        id="about-medicare-dropdown3"
                        role="button"
                        data-toggle="dropdown"
                        aria-haspopup="true"
                        aria-expanded="false"
                      >
                        <Text id="header.wellness"/>
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="about-medicare-dropdown3"
                      >
                        <li>
                          <a
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/wellness/wellness-center"
                            target="_blank"
                          >
                             <Text id="header.wellnessSub1"/>
                          </a>
                        </li>
                        <li>
                          <a
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/wellness/wellness-program"
                            target="_blank"
                          >
                            <Text id="header.wellnessSub2"/>
                          </a>
                        </li>
                        <li>
                          <a
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/wellness/preventive-care"
                            target="_blank"
                          >
                           <Text id="header.wellnessSub3"/>
                          </a>
                        </li>
                      </ul>
                    </li>
                    <li class={this.props.lang==="es"?"nav-item headpadding2":"nav-item headpadding"}>
                      <a
                        class="nav-link "
                        href="https://www.sharpmedicareadvantage.com/find-a-doctor-or-pharmacy"
                      >
                        <Text id="header.findADoctor"/>
                      </a>
                    </li>
                    <li class={this.props.lang==="es"?"nav-item headpadding2":"nav-item headpadding"}>
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        id="about-medicare-dropdown4"
                        role="button"
                        data-toggle="dropdown"
                        aria-haspopup="true"
                        aria-expanded="false"
                      >
                        <Text id="header.contactUs"/>
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="about-medicare-dropdown4"
                      >
                        <li>
                        <a
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/contact-us/contact-information"
                          >
                            <Text id="header.contact"/>
                          </a>
                          <a
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/contact-us/faqs"
                          >
                            <Text id="header.contactUsSub"/>
                          </a>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </div>
              </nav>
            </div>
          </div>
        </header>
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => {
  return {
      lang:state.webApp.language,
  };
};
const mapDispatchToProps = {
 
};

export default connect(mapStateToProps, mapDispatchToProps)(Header)