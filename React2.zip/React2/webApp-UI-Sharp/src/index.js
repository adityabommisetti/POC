import { applyMiddleware, createStore } from "redux";
import App from "./App";
import { Provider } from "react-redux";
import React from "react";
import ReactDOM from "react-dom";
import logger from "redux-logger";
import rootReducer from "./Redux/Reducers";
import thunk from "redux-thunk";
import "./assests/css/style.css";
import "./assests/css/bstyle.css";
import "bootstrap/dist/css/bootstrap.min.css";
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';
require("webpack-jquery-ui");
require("webpack-jquery-ui/css");

let store = null;

if (process.env.NODE_ENV === "development") {
  store = createStore(rootReducer, applyMiddleware(thunk, logger));
} else {
  store = createStore(rootReducer, applyMiddleware(thunk));
}

ReactDOM.render(
  <Provider store={store}>
    <div>
      <App />
    </div>
  </Provider>,

  document.getElementById("root")
);
