import * as ActionTypes from "../ActionTypes";
import * as URL from "../API_URL";
import { getRequest, postRequest } from "./index";

export const login = (loginData) => {
  return postRequest(URL.LOGIN, loginData, ActionTypes.LOGIN);
};

export const signUp = (signUpData) => {
  return postRequest(URL.SIGNUP, signUpData, ActionTypes.SIGNUP);
};

export const guestLogin = (customerId) => {
  let url = URL.GUEST_LOGIN + "?customerId=" + customerId;
  return getRequest(url, ActionTypes.GUEST_LOGIN);
};

export const yearSelection = (year) => {
  return postRequest(URL.YEAR_SELECTION, year, ActionTypes.YEAR_SELECTION);
};

export const planSelectionContinue = (plan) => {
  return postRequest(
    URL.PLAN_SELECTION_CONTINUE,
    plan,
    ActionTypes.PLAN_SELECTION_CONTINUE
  );
};

export const saveLogout = (data) => {
  return postRequest(URL.SAVE_LOGOUT, data, ActionTypes.SAVE_LOGOUT);
};

export const submitForm = (data) => {
  return postRequest(URL.SUBMIT_FORM, data, ActionTypes.SUBMIT_FORM);
};

export const downloadPdf = () => {
  return getRequest(URL.DOWNLOAD_PDF, ActionTypes.DOWNLOAD_PDF);
};

export const getClinicalName = (name) => {
  return getRequest(
    `${URL.GET_CLINICAL_NAME}${name}`,
    ActionTypes.GET_CLINICAL_NAME
  );
};

export const sendLink = (email) => {
  return getRequest(
    `${URL.FORGOT_PASSWORD}${email}`,
    ActionTypes.FORGOT_PASSWORD
  );
};

export const resetPassword = (data) => {
  return postRequest(URL.RESET_PASSWORD, data, ActionTypes.RESET_PASSWORD);
};

export const removeplan = () => {
  return {
    type: ActionTypes.REMOVEPLAN,
  };
};

export const vapCache = () => {
  return getRequest(URL.VAP_CACHE, ActionTypes.VAP_CACHE);
};

export const vapSubmit = (data) => {
  return postRequest(URL.VAP_SUBMISSION, data, ActionTypes.VAP_SUBMISSION);
};
// 
export const getPDF = () => {
  
  return getRequest(URL.VAP_GETPDF, ActionTypes.VAP_GETPDF);
};

export const setValue = (value) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.SET_VALUE,
      value: value,
    });
  };
};
