import * as ActionTypes from "../ActionTypes";
import axios from "../../Utils/axios";

export function getRequest(API_URL, Success_Action) {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .get(API_URL)
        .then((response) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (response.status === 200) {
            if (Success_Action === "VAP_CACHE") {
              for (const key of Object.keys(response.data.data)) {
                if (key === "relEnrollemList") {
                  if (
                    Array.isArray(response.data.data[key]) &&
                    response.data.data[key]
                  ) {
                    response.data.data[key].splice(0, 0, {
                      label: "Select...",
                      value: "",
                    });
                  }
                }
              }
            }
            dispatch({ type: Success_Action, payload: response.data });
            return response.data;
          } else {
            dispatch({ type: Success_Action, payload: [] });
          }
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.data) {
            return error.response.data;
          }
        });
    }
    return "success";
  };
}

export function postRequest(API_URL, body, Success_Action) {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .post(API_URL, body)
        .then((response) => {
          if (response.status === 200) {
            dispatch({
              type: Success_Action,
              payload: response.data,
              body: body,
            });
          } else {
            dispatch({ type: Success_Action, payload: {} });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return response.data;
        })

        .catch((error) => {
          error.response &&
            error.response.data &&
            dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return error.response.data.message;
        });
    }
    return "success";
  };
}
