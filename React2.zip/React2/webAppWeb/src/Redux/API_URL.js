export const LOGIN = "/sharp/individual/yearSelection";
export const SIGNUP = "/sharp/individual/yearSelection";
export const GUEST_LOGIN = "/sharp/individual/yearSelectionGuest";
export const YEAR_SELECTION = "/sharp/individual/selectedPlans";
export const PLAN_SELECTION_CONTINUE = "/sharp/individual/enrollOnline";
export const SUBMIT_FORM = "/sharp/individual/Confirmation";
export const DOWNLOAD_PDF = "/sharp/individual/Download";
export const GET_CLINICAL_NAME = "/sharp/individual/clinicName?ofcCde=";
export const SAVE_LOGOUT = "/sharp/individual/Save";
export const FORGOT_PASSWORD = "/forgotpassword/sendEmail?emailId=";
export const RESET_PASSWORD = "/password/change";

export const VAP_CACHE = "/vap/initial/cache";  
export const VAP_GETPDF = "/vap/pdf/download"; 
// /webapp-api/
export const VAP_SUBMISSION = "/vap/save/enrollmentInfo";
export const VAP_DOWNLOAD = "/vap/pdf/download";

export const DOWNLOAD_FORM = "/download/pdf";
