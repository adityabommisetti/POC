import React, { Component } from "react";
import { connect } from "react-redux";

const ie =
  navigator.userAgent.indexOf("MSIE") > -1 ||
  navigator.userAgent.indexOf("rv:") > -1;

const fire = navigator.userAgent.indexOf("Firefox") != -1;

class Step2 extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  async componentDidMount() {
    window.scroll(0, 0);
  }

  render() {
    const { data, selectedPlan } = this.props;

    return (
      <React.Fragment>
        <div class="container tab-pane active">
          <h4 class="sub-heading">
            A. Please read and answer these important questions:
          </h4>
          <div class="form-group">
            <ol class="list-type1">
              <li class={fire ? "firemarginTop firemarginBottom" : ""}>
                <fieldset
                  class={
                    ie
                      ? "radio radio-tab iemargin"
                      : "radio radio-tab ml-3 mt-3"
                  }
                  id="c_qns2"
                >
                  <legend>
                    <p style={{ marginTop: "-3px !important" }}>
                      Some individuals may have other drug coverage, including
                      other private insurance, TRICARE, Federal employee health
                      benefits coverage, VA benefits, or State pharmaceutical
                      assistance programs.
                    </p>
                    <span id="healthBenefits">
                      {" "}
                      Will you have other prescription drug coverage in addition
                      to Virginia Premier? <span class="mandatory">
                        *
                      </span>:{" "}
                    </span>
                    <br />
                    <span class="font-weight-normal">
                      If "yes", please list your other coverage and your
                      identification (ID) number(s) for this coverage:
                    </span>
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="healthBenefits"
                      id="c_q2_yes"
                      class="custom-control-input"
                      value="Y"
                      checked={data.healthBenefits === "Y"}
                      onChange={this.props.handleChange}
                      required=""
                      style={{ zIndex: -1 }}
                    />
                    <label
                      style={{ cursor: "pointer" }}
                      for="c_q2_yes"
                      class="radio-inline custom-control-label"
                    >
                      Yes
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="healthBenefits"
                      id="c_q2_no"
                      value="N"
                      class="custom-control-input"
                      checked={data.healthBenefits === "N"}
                      onChange={this.props.handleChange}
                    />
                    <label
                      style={{ cursor: "pointer" }}
                      for="c_q2_no"
                      class="radio-inline custom-control-label"
                    >
                      No
                    </label>
                  </div>

                  {data.healthBenefits === "Y" ? (
                    <React.Fragment>
                      <div id="c_q2_fields">
                        <div class="row mt-3 ml-1 align-items-flex-end">
                          <div class="col-md-4">
                            <label
                              for="nameOfOtherCoverage"
                              class="control-label"
                              id="medicalNameCoverage"
                            >
                              Name of other coverage
                              <span class="mandatory">*</span>:
                            </label>
                            <input
                              type="text"
                              class={
                                data.medicalNameCoverage === ""
                                  ? "error-input"
                                  : "form-control"
                              }
                              id="nameOfCov"
                              name="medicalNameCoverage"
                              value={data.medicalNameCoverage}
                              onChange={this.props.handleChange}
                            />{" "}
                          </div>
                          <div class="col-md-4">
                            <label
                              for="idNoOfThisCoverage"
                              class="control-label"
                              id="medicalIdCoverage"
                            >
                              ID# of this coverage
                              <span class="mandatory">*</span>:
                            </label>
                            <input
                              type="text"
                              class={
                                data.medicalIdCoverage === ""
                                  ? "error-input"
                                  : "form-control"
                              }
                              id="idOfCov"
                              name="medicalIdCoverage"
                              value={data.medicalIdCoverage}
                              onChange={this.props.handleChange}
                            />{" "}
                          </div>
                          <div class="col-md-4">
                            <label
                              for="groupOfCov"
                              class="control-label"
                              id="medicalGroupCoverage"
                            >
                              Group# for this coverage
                              <span class="mandatory">*</span>:
                            </label>
                            <input
                              type="text"
                              class={
                                data.medicalGroupCoverage === ""
                                  ? "error-input"
                                  : "form-control"
                              }
                              id="medicalGroupCoverage"
                              name="medicalGroupCoverage"
                              value={data.medicalGroupCoverage}
                              onChange={this.props.handleChange}
                            />{" "}
                          </div>
                        </div>
                      </div>
                    </React.Fragment>
                  ) : null}
                </fieldset>
              </li>

              <li class={fire ? "firemarginBottom" : ""}>
                <fieldset
                  class={
                    ie
                      ? "radio radio-tab iemargin"
                      : "radio radio-tab ml-3 mt-3"
                  }
                  id="c_qns4"
                >
                  <legend style={{ marginTop: "13px !important" }}>
                    <span id="nursingHome">
                      {" "}
                      Are you a resident in a long-term care facility, such as a
                      nursing home? <span class="mandatory">*</span>:
                    </span>
                    <br />
                    <span class="font-weight-normal">
                      If "yes," please provide the following information:
                    </span>
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="nursingHome"
                      id="c_q4_yes"
                      class="custom-control-input"
                      value="Y"
                      checked={data.nursingHome === "Y"}
                      onChange={this.props.handleChange}
                      require=""
                      style={{ zIndex: -1 }}
                    />
                    <label
                      style={{ cursor: "pointer" }}
                      for="c_q4_yes"
                      class="radio-inline custom-control-label"
                    >
                      Yes
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="nursingHome"
                      id="c_q4_no"
                      class="custom-control-input"
                      value="N"
                      checked={data.nursingHome === "N"}
                      onChange={this.props.handleChange}
                    />
                    <label
                      style={{ cursor: "pointer" }}
                      for="c_q4_no"
                      class="radio-inline custom-control-label"
                    >
                      No
                    </label>
                  </div>

                  {data.nursingHome === "Y" ? (
                    <React.Fragment>
                      <div class="row mt-3 ml-1 align-items-flex-end">
                        <div class="col-md-7">
                          <label
                            for="instituteName"
                            class="control-label"
                            id="instituteName"
                          >
                            Name of Institution <span class="mandatory">*</span>
                            :
                          </label>
                          <input
                            type="text"
                            class={
                              data.instituteName === ""
                                ? "error-input"
                                : "form-control"
                            }
                            id="instituteName"
                            name="instituteName"
                            value={data.instituteName}
                            onChange={this.props.handleChange}
                            required=""
                          />{" "}
                        </div>
                        <div class="col-md-5">
                          <label
                            for="phoneNumberOfInstitution"
                            class="control-label"
                            id="institutePhone"
                          >
                            Phone Number of Institution
                            <span class="mandatory">*</span>:
                          </label>
                          <input
                            type="text"
                            class={
                              ie
                                ? data.institutePhone === ""
                                  ? "error-input ieheight"
                                  : "form-control ieheight"
                                : data.institutePhone === ""
                                ? "error-input "
                                : "form-control "
                            }
                            id="institutePhone"
                            name="institutePhone"
                            value={data.institutePhone}
                            onChange={this.props.handleChange}
                            placeholder="(   )   -"
                            maxlength="14"
                          />{" "}
                        </div>
                      </div>
                      <div class="row mt-3 ml-1">
                        <div class="col-md-12">
                          <label
                            for="instituteAddress"
                            class="control-label"
                            id="instituteAddress"
                          >
                            Address of Institution (number and street)
                            <span class="mandatory">*</span>:
                          </label>
                          <input
                            type="text"
                            class={
                              data.instituteAddress === ""
                                ? "error-input"
                                : "form-control"
                            }
                            id="instituteAddress"
                            name="instituteAddress"
                            value={data.instituteAddress}
                            onChange={this.props.handleChange}
                            required=""
                          />{" "}
                        </div>
                      </div>
                    </React.Fragment>
                  ) : null}
                </fieldset>
              </li>
              <li class={fire ? "firemarginBottom" : ""}>
                <fieldset
                  class={
                    ie
                      ? "radio radio-tab iemargin"
                      : "radio radio-tab ml-3 mt-3"
                  }
                  id="c_qns3"
                >
                  <legend style={{ marginTop: "13px !important" }}>
                    <span id="stateMedicaid">
                      Are you enrolled in your State Medicaid program?{" "}
                      <span class="mandatory">*</span>:
                    </span>
                    <br />
                    <span class="font-weight-normal">
                      If "yes", please provide your Medicaid number
                    </span>
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="stateMedicaid"
                      id="c_q3_yes"
                      class="custom-control-input"
                      value="Y"
                      checked={data.stateMedicaid === "Y"}
                      onChange={this.props.handleChange}
                      required=""
                      style={{ zIndex: -1 }}
                    />
                    <label
                      style={{ cursor: "pointer" }}
                      for="c_q3_yes"
                      class="radio-inline custom-control-label"
                    >
                      Yes
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="stateMedicaid"
                      id="c_q3_no"
                      class="custom-control-input"
                      value="N"
                      checked={data.stateMedicaid === "N"}
                      onChange={this.props.handleChange}
                    />
                    <label
                      style={{ cursor: "pointer" }}
                      for="c_q3_no"
                      class="radio-inline custom-control-label"
                    >
                      No
                    </label>
                  </div>

                  {data.stateMedicaid === "Y" ? (
                    <React.Fragment>
                      <div class="row mt-3 ml-1">
                        <div class="col-lg-5 col-md-7">
                          <label
                            for="medicaidNumber"
                            class="control-label"
                            id="medicaidNumber"
                          >
                            Medicaid number<span class="mandatory">*</span>:
                          </label>
                          <input
                            type="text"
                            class="form-control"
                            value={data.medicaidNumber}
                            onChange={this.props.handleChange}
                            name="medicaidNumber"
                            minlength="10"
                            maxlength="12"
                            class={
                              data.medicaidNumber === "" ||
                              (data.medicaidNumber &&
                                data.medicaidNumber.length < 10)
                                ? "error-input"
                                : "form-control"
                            }
                          />{" "}
                        </div>
                      </div>
                    </React.Fragment>
                  ) : null}
                </fieldset>
              </li>
              <li class={fire ? "firemarginBottom" : ""}>
                <fieldset
                  class={
                    ie
                      ? "radio radio-tab iemargin"
                      : "radio radio-tab ml-3 mt-3"
                  }
                >
                  <legend style={{ marginTop: "14px !important" }}>
                    <span id="spousework">
                      Do you or your spouse work?{" "}
                      <span class="mandatory">*</span>:
                    </span>
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="spouse"
                      id="c_q5_yes"
                      class="custom-control-input"
                      value="Y"
                      checked={data.spouse === "Y"}
                      onChange={this.props.handleChange}
                      required=""
                    />
                    <label
                      style={{ cursor: "pointer" }}
                      for="c_q5_yes"
                      class="radio-inline custom-control-label"
                    >
                      Yes
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="spouse"
                      id="c_q5_no"
                      class="custom-control-input"
                      value="N"
                      checked={data.spouse === "N"}
                      onChange={this.props.handleChange}
                    />
                    <label
                      style={{ cursor: "pointer" }}
                      for="c_q5_no"
                      class="radio-inline custom-control-label"
                    >
                      No
                    </label>
                  </div>
                </fieldset>
              </li>
              <li>
                <div class="mt-3 ml-1 mb-3">
                  <strong>
                    <i>Optional field:</i> Please choose the name of a Primary
                    Care Physician (PCP), clinic or health center:
                  </strong>
                </div>
                <div class="ml-2">
                  <div class="form-group row">
                    {this.props.dropdowns &&
                    this.props.dropdowns.pcpList &&
                    this.props.dropdowns.pcpList.length > 0 ? (
                      <div class={ie ? "col-md-6" : "col-md-5"}>
                        <label for="physicianName" class="control-label">
                          Name:
                        </label>
                        <input
                          type="text"
                          name="physicianName"
                          id="physicianName"
                          class="form-control1"
                          onChange={this.props.handleChange}
                          value={data.physicianName}
                          list="items"
                        />

                        <datalist id="items">
                          {this.props.dropdowns.pcpList.map((item) => {
                            console.log(item);
                            return (
                              <option
                                value={item.physicianName}
                                title="test"
                              ></option>
                            );
                          })}
                        </datalist>
                      </div>
                    ) : null}
                  </div>
                  <div class="form-group row">
                    <div class="col-md-9">
                      <label for="pcpAddr" class="control-label">
                        Address:
                      </label>
                      <input
                        type="text"
                        class="form-control1 readonly"
                        name="pcpAddr"
                        id="pcpAddr"
                        // class="form-control"
                        readonly
                        value={data.pcpAddr}
                        disabled="disabled"
                      />
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-lg-3 col-md-4">
                      <label for="pcpCity" class="control-label">
                        City:
                      </label>
                      <input
                        type="text"
                        class="form-control1 readonly"
                        name="pcpCity"
                        id="pcpCity"
                        value={data.pcpCity}
                        readonly
                        disabled="disabled"
                      />{" "}
                    </div>

                    <div class="col-lg-3 col-md-4">
                      <label for="pcpState" class="control-label">
                        State:
                      </label>
                      <br />
                      <input
                        type="text"
                        class="form-control1 readonly"
                        name="pcpState"
                        id="pcpState"
                        value={data.pcpState}
                        readonly
                        disabled="disabled"
                      />
                    </div>
                    <div class="col-lg-3 col-md-4">
                      <label for="physician" class="control-label">
                        ZIP Code:
                      </label>
                      <input
                        type="text"
                        class="form-control1 readonly"
                        name="physician"
                        id="physician"
                        value={data.physician}
                        readonly
                        disabled="disabled"
                      />{" "}
                    </div>
                  </div>
                </div>
              </li>
            </ol>
          </div>
          <h4 class="sub-heading">B. Language and Format Preferences</h4>
          <div class="form-group">
            <fieldset class="radio radio-tab mt-3 mb-3">
              <legend>
                Please check one of the boxes below if you would prefer us to
                send you information in a language other than English or in an
                accessible format:
              </legend>
              <div class="row">
                <div class="col-md-12">
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="language"
                      id="lfp_spanish"
                      class="custom-control-input"
                      value="Spanish"
                      checked={data.language === "Spanish"}
                      onChange={this.props.handleChange}
                    />
                    <label
                      for="lfp_spanish"
                      class="radio-inline custom-control-label"
                      style={{ cursor: "pointer" }}
                    >
                      Spanish
                    </label>
                  </div>

                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="language"
                      id="lfp_largeprint"
                      class="custom-control-input"
                      value="LARGE_PRINT"
                      checked={data.language === "LARGE_PRINT"}
                      onChange={this.props.handleChange}
                    />
                    <label
                      style={{ cursor: "pointer" }}
                      for="lfp_largeprint"
                      class="radio-inline custom-control-label"
                    >
                      Large Print
                    </label>
                  </div>
                </div>
              </div>
            </fieldset>
            <p>
              Please contact Virginia Premier at 1-833-280-1194 if you need
              information in an accessible format or language other than what is
              listed above. Our office hours are 8 am to 8 pm, 7 days a week
              from October 1 to March 31. From April 1 through September 30, we
              are open Monday through Friday, 8 am to 8 pm. On certain holidays
              and weekends from April 1 through September 30, your call will be
              handled by our automated phone system. TTY users should call 711.
            </p>
          </div>

          <button
            class="btnvap btn-primaryvap btn-save-n-next"
            id="step2"
            onClick={this.props.redirect}
          >
            Save &amp; Next
          </button>
        </div>
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    dropdowns: state.webApp.dropdowns,
  };
};
const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(Step2);
