import React, { Component } from "react";
import history from "../Utils/History";
import Footer from "./vap_footer";
import { connect } from "react-redux";
import { setValue } from "../Redux/Actions/webAppActions";
import logo from "../assests/images/vp-logo.png";
let test = {};
class LandingPage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      myParam: "",
    };
  }

  async componentWillMount() {
    window.scroll(0, 0);

    // let value = this.props.location.search;
    // console.log(value);

    const getQueryParams = () =>
      window.location.search
        .replace("?", "")
        .split("&")
        .reduce(
          (r, e) => (
            (r[e.split("=")[0]] = decodeURIComponent(e.split("=")[1])), r
          ),
          {}
        );
    const urlParams = new URLSearchParams(window.location.search);

    this.setState({ myParam: urlParams.get("planYear") });
    test = getQueryParams();

    await this.props.setValue(test);
  }
  continue = () => {
    history.push("/webapptest/VAP/PreEnroll");
  };
  render() {
    const urlParams = new URLSearchParams(window.location.search);
    const myParam = urlParams.get("planYear");
    sessionStorage.setItem("landing", true);
    sessionStorage.setItem("landing", true);
    //  this.setState({ myParam: urlParams.get("planYear") });
    console.log(myParam != "" && myParam == 2020);

    return (
      <React.Fragment>
        <div class="elementor elementor-124 elementor-location-header">
          <div class="elementor-section-wrap">
            <section class="elementor-section elementor-top-section elementor-element elementor-section-content-middle elementor-section-boxed ">
              <div class="elementor-container">
                <div class="elementor-row">
                  <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-8342e5f">
                    <div class="elementor-column-wrap elementor-element-populated">
                      <div class="elementor-widget-wrap">
                        <div class="elementor-element">
                          <div class="elementor-widget-container">
                            <div class="elementor-image">
                              <a href="https://www.virginiapremier.com/">
                                {" "}
                                <img
                                  width="254"
                                  height="54"
                                  src={logo}
                                  class="attachment-full size-full"
                                  alt="Virginia Premier logo"
                                />{" "}
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            <section class="elementor-section elementor-top-section elementor-element elementor-element-110a0f69 elementor-section-height-min-height elementor-section-boxed elementor-section-height-default elementor-section-items-middle">
              <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-row">
                  <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-6264989c">
                    <div class="elementor-column-wrap elementor-element-populated">
                      <div class="elementor-widget-wrap">
                        <div class="elementor-element elementor-element-3a15e9fc elementor-widget elementor-widget-theme-page-title elementor-page-title elementor-widget-heading">
                          <div class="elementor-widget-container">
                            <h1 class="elementor-heading-title elementor-size-default fontise">
                              Virginia Premier Advantage Elite (HMO DSNP)
                            </h1>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            <section class="elementor-section elementor-top-section elementor-element elementor-element-ba60d30 elementor-section-boxed mt-4">
              <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-row">
                  <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-8e19ec2">
                    <div class="elementor-column-wrap elementor-element-populated">
                      <div class="elementor-widget-wrap">
                        <div
                          class="elementor-element elementor-element-ca304d8 elementor-widget elementor-widget-text-editor"
                          data-id="ca304d8"
                        >
                          <div class="elementor-widget-container">
                            {myParam != "" && myParam == 2020 ? (
                              <div class="elementor-text-editor elementor-clearfix">
                                <p>
                                  To submit the 2020 application, click on the
                                  below links
                                  <br />
                                  <a href="https://enroll.medadvantage360.com/WebApp/Vap?planId=H9877&pbpId=001&planYear=2020">
                                    Elite
                                  </a>
                                  <br />
                                  <a href="https://enroll.medadvantage360.com/WebApp/Vap?planId=H9877&pbpId=002&planYear=2020">
                                    Gold
                                  </a>
                                  <br />
                                  <a href="https://enroll.medadvantage360.com/WebApp/Vap?planId=H9877&pbpId=003&planYear=2020">
                                    Platinum
                                  </a>
                                </p>
                              </div>
                            ) : (
                              ""
                            )}
                            <div class="elementor-text-editor elementor-clearfix">
                              <p>
                                INDIVIDUAL ENROLLMENT REQUEST FORM TO ENROLL IN
                                A MEDICARE ADVANTAGE PLAN (PART C)
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>
        <div id="content" class="site-content mb-4">
          <div class="ast-container">
            <div class="content-area primary">
              <main id="main" class="site-main">
                <div class="wrapper-inner">
                  <div class="row">
                    <div class="col-lg-6 col-sm-12">
                      <div>
                        <h4>Who can use this form?</h4>
                        <p>
                          People with Medicare who want to join a Medicare
                          Advantage Plan
                        </p>
                        <p class="">
                          <strong>To join a plan, you must:</strong>
                        </p>
                        <ul>
                          <li>
                            Be a United States citizen or be lawfully present in
                            the U.S.
                          </li>
                          <li>Live in the plan's service area</li>
                        </ul>
                        <p class="">
                          <strong>
                            Important: To join a Medicare Advantage Plan, <br />
                            you must also have both:
                          </strong>
                        </p>
                        <ul>
                          <li>Medicare Part A (Hospital Insurance)</li>
                          <li>Medicare Part B (Medical Insurance)</li>
                        </ul>
                      </div>
                      <div class="mt-5">
                        <h4>When do I use this form?</h4>
                        <p>
                          <strong>You can join a plan:</strong>
                        </p>
                        <ul>
                          <li>
                            Between October 15–December 7 each year (for
                            coverage starting January1)
                          </li>
                          <li>Within 3 months of first getting Medicare</li>
                          <li>
                            In certain situations where you're allowed to join
                            or switch plans
                          </li>
                        </ul>
                        <p>
                          Visit Medicare.gov to learn more about when you can
                          sign up for a plan.
                        </p>
                      </div>

                      <div class="mt-5">
                        <h4>What do I need to complete this form?</h4>
                        <ul>
                          <li>
                            Your Medicare Number (the number on your red, white,
                            and blue Medicare card)
                          </li>
                          <li>Your permanent address and phone number</li>
                        </ul>
                        <p>
                          <strong>Note:</strong> You must complete all items in
                          Step1,Section A. The items in Step2, Section B are
                          optional — you can't be denied coverage because you
                          don't fill them out.
                        </p>
                      </div>
                    </div>

                    <div class="col-lg-6 col-sm-12">
                      <div>
                        <h4>Reminders:</h4>
                        <ul>
                          <li>
                            If you want to join a plan during fall open
                            enrollment (October 15–December 7), the plan must
                            get your completed form by December 7.
                          </li>
                          <li>
                            Your plan will send you a bill for the plan's
                            premium. You can choose to sign up to have your
                            premium payments deducted from your bank account or
                            your monthly Social Security (or Railroad Retirement
                            Board) benefit.
                          </li>
                        </ul>
                      </div>
                      <div class="mt-5">
                        <h4>What happens next?</h4>
                        {/*<p>Send your completed and signed form to:</p>
                        <p>
                          Virginia Premier
                          <br />
                          PO Box 4250
                          <br />
                          Richmond, VA 23220-8250
                        </p>*/}
                        <p>
                          Once they process your request to join, they'll
                          contact you.
                        </p>
                      </div>

                      <div class="mt-5">
                        <h4>How do I get help with this form?</h4>
                        <p>
                          Call Virginia Premier at 1-877-739-1370. TTY users can
                          call 711.
                        </p>
                        <p>
                          Or, call Medicare at 1-800-MEDICARE (1-800-633-4227).
                          TTY users can call 1-877-486-2048.
                        </p>
                        <p lang="es">
                          <strong>Es español:</strong> Llame a Virginia Premier
                          al 1-877-739-1370 (TTY: 711) o a Medicare gratis al
                          1-800-633-4227 y oprima el 2 para asistencia en
                          español y un representante estará disponible para
                          asistirle.
                        </p>
                      </div>
                    </div>
                  </div>
                  <div class="text-center mt-2">
                    {myParam != "" && myParam == 2020 ? (
                      <button class="btn btn-secondary">Continue</button>
                    ) : (
                      <button
                        class="btnvap btn-primaryvap"
                        onClick={this.continue}
                      >
                        Continue
                      </button>
                    )}
                  </div>
                </div>
              </main>
            </div>
          </div>
        </div>
        <Footer />
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {};
const mapDispatchToProps = {
  setValue,
};

export default connect(mapStateToProps, mapDispatchToProps)(LandingPage);
