import React, { Component } from "react";
import Step1 from "./vap_step1";
import Step2 from "./vap_step2";
import Step3 from "./vap_step3";
import Step4 from "./vap_step4";
import * as DateUtil from "../Utils/DatePicker";
import { INITIAL_STATE } from "./vap_initialState";
import { handleDateChange } from "../Utils/DateFormatter";
import history from "../Utils/History";
import Footer from "./vap_footer";
import LinearProgress from "@material-ui/core/LinearProgress";
import { withStyles } from "@material-ui/core/styles";
import { connect } from "react-redux";
import { vapSubmit, vapCache } from "../Redux/Actions/webAppActions";
import logo from "../assests/images/vp-logo.png";
import moment from "moment";
import SimpleReactValidator from "simple-react-validator";


const styles = (props) => ({
  progressComplete: {
    backgroundColor: "#00695C",
  },
  root: {
    height: "20px",
  },
  progressIncomplete: {
    backgroundColor: "#b8880c",
  },
});

class PreEnroll extends Component {
  constructor(props) {
    super(props);    
    this.validator = new SimpleReactValidator();
  }

  state = {
    formData: [
      { lastName: 0 },
      { firstName: 0 },
      { sex: 0 },
      { permanentAddr: 0 },
      { permanentCity: 0 },

      { medicareClaim: 0 },
      { beneficiarySex: 0 },
      { permanentZip: 0 },
      { birthDate: 0 },
      { medicalDate: 0 },
      { hospitalDate: 0 },
      { nameSignature: 0 },
      { spouse: 0 },
    ],

    formRadio: [
      {
        nursingHome: 3,
        fields: [
          { instituteName: 0 },
          { institutePhone: 0 },
          { instituteAddress: 0 },
        ],
      },

      { stateMedicaid: 1, fields: [{ medicaidNumber: 0 }] },
      {
        healthBenefits: 2,
        fields: [{ medicalNameCoverage: 0 }, { medicalIdCoverage: 0 }],
      },
      { trcntCreditChBox: 1, fields: [{ recentlyCreditable: 0 }] },
      { newElgbChBox: 1, fields: [{ newlyEligbleMedicare: 0 }] },
      { revMedChBox: 1, fields: [{ recieveMedicareDrugs: 0 }] },
      { changeInMedicaidChBox: 1, fields: [{ changeInMedicaid: 0 }] },
      { changeInExtraHelpChBox: 1, fields: [{ changeInExtraHelp: 0 }] },
      { recntleftPlChBox: 1, fields: [{ recntLeftPace: 0 }] },
      { mvdUsChBox: 1, fields: [{ movedBackUs: 0 }] },
      { outLngTermFcSeeChBox: 1, fields: [{ outLongTermFacility: 0 }] },
    ],
    count: 13,
    stepVal: "step1",
    data: { ...INITIAL_STATE },
    disableCheck: false,
    checkedCount: [],
    isAep:false
    // validDates: [],
  };

  validStep3Check = async () => {
    if (this.state.data.nameSignature === "") {
      var elmnt = document.getElementById("printName");
      elmnt.scrollIntoView();
    } else {
      window.scroll(0, 0);
      await this.setState({ stepVal: "step4" });
    }
  };

  validStep1Check = async () => {
    if (this.state.data.lastName === "") {
      var elmnt = document.getElementById("lastName");
      elmnt.scrollIntoView();
    } else if (this.state.data.firstName === "") {
      var elmnt = document.getElementById("firstName");
      elmnt.scrollIntoView();
    } else if (this.state.data.birthDate === "") {
      var elmnt = document.getElementById("birthDate1");
      elmnt.scrollIntoView();
    } else if (this.state.data.sex === "") {
      var elmnt = document.getElementById("sex");
      elmnt.scrollIntoView();
    } else if (this.state.data.permanentAddr === "") {
      var elmnt = document.getElementById("permanentAddr");
      elmnt.scrollIntoView();
    } else if (this.state.data.permanentCity === "") {
      var elmnt = document.getElementById("permanentCity");
      elmnt.scrollIntoView();
    } else if (this.state.data.permanentZip === "") {
      var elmnt = document.getElementById("permanentZip");
      elmnt.scrollIntoView();
    } else if (
      this.state.data.mailingAddressRequired === "YES" &&
      this.state.data.mailingAddr === ""
    ) {
      var elmnt = document.getElementById("mailingAddr");
      elmnt.scrollIntoView();
    } else if (
      this.state.data.mailingAddressRequired === "YES" &&
      this.state.data.mailingCity === ""
    ) {
      var elmnt = document.getElementById("mailingCity");
      elmnt.scrollIntoView();
    } else if (
      this.state.data.mailingAddressRequired === "YES" &&
      this.state.data.mailingState === ""
    ) {
      var elmnt = document.getElementById("mailingState");
      elmnt.scrollIntoView();
    } else if (
      this.state.data.mailingAddressRequired === "YES" &&
      this.state.data.mailingZip === ""
    ) {
      var elmnt = document.getElementById("mailingZip");
      elmnt.scrollIntoView();
    } else if (this.state.data.medicareClaim === "") {
      var elmnt = document.getElementById("medicareClaim");
      elmnt.scrollIntoView();
    } else if (this.state.data.hospitalDate === "") {
      var elmnt = document.getElementById("partA");
      elmnt.scrollIntoView();
    } else if (this.state.data.medicalDate === "") {
      var elmnt = document.getElementById("partB");
      elmnt.scrollIntoView();
    } else {
      window.scroll(0, 0);
      this.setState({ stepVal: "step2" });
    }
  };

  validStep2Check = async () => {
    if (this.state.data.healthBenefits === "") {
      var elmnt = document.getElementById("healthBenefits");
      elmnt.scrollIntoView();
    } else if (
      this.state.data.healthBenefits === "Y" &&
      this.state.data.medicalNameCoverage === ""
    ) {
      var elmnt = document.getElementById("medicalNameCoverage");
      elmnt.scrollIntoView();
    } else if (
      this.state.data.healthBenefits === "Y" &&
      this.state.data.medicalIdCoverage === ""
    ) {
      var elmnt = document.getElementById("medicalIdCoverage");
      elmnt.scrollIntoView();
    } else if (
      this.state.data.healthBenefits === "Y" &&
      this.state.data.medicalGroupCoverage === ""
    ) {
      var elmnt = document.getElementById("medicalGroupCoverage");
      elmnt.scrollIntoView();
    } else if (this.state.data.nursingHome === "") {
      var elmnt = document.getElementById("nursingHome");
      elmnt.scrollIntoView();
    } else if (
      this.state.data.nursingHome === "Y" &&
      this.state.data.medicalGroupCoverage === ""
    ) {
      var elmnt = document.getElementById("sex");
      elmnt.scrollIntoView();
    } else if (
      this.state.data.nursingHome === "Y" &&
      this.state.data.instituteName === ""
    ) {
      var elmnt = document.getElementById("instituteName");
      elmnt.scrollIntoView();
    } else if (
      this.state.data.nursingHome === "Y" &&
      this.state.data.institutePhone === ""
    ) {
      var elmnt = document.getElementById("institutePhone");
      elmnt.scrollIntoView();
    } else if (
      this.state.data.nursingHome === "Y" &&
      this.state.data.instituteAddress === ""
    ) {
      var elmnt = document.getElementById("instituteAddress");
      elmnt.scrollIntoView();
    } else if (this.state.data.stateMedicaid === "") {
      var elmnt = document.getElementById("stateMedicaid");
      elmnt.scrollIntoView();
    } else if (
      this.state.data.stateMedicaid === "Y" &&
      this.state.data.medicaidNumber === ""
    ) {
      var elmnt = document.getElementById("medicaidNumber");
      elmnt.scrollIntoView();
    }
    else if (
      this.state.data.spouse === ""
    ) {
      var elmnt = document.getElementById("spousework");
      elmnt.scrollIntoView();
    } else {
      window.scroll(0, 0);
      this.setState({ stepVal: "step3" });
    }
  };

  redirect = async (event) => {
    let id = event.target.id;

    if (id === "step1") {
      this.validStep1Check();
    }
    if (id === "step2") {
      this.validStep2Check();
    }
    if (id === "step3") {
      this.validStep3Check();
    }
    if (id === "step4") {
      await this.setState({ stepVal: "step1" });
    }
  };
  submitData = async () => {
    let planId = this.props.paramValues.planId;
    let pbpId = this.props.paramValues.pbpId;
    let planYear = this.props.paramValues.planYear;

    let payload = {
      ...this.state.data,
      planId: planId,
      pbpId: pbpId,
      planYear: planYear,
    };
    if(this.state.data.emailAddr === "" || this.validator.check(this.state.data.emailAddr, "email") ){  
    const response = await this.props.vapSubmit(payload);
    if (response.message === "SUCCESS") {
      this.props.history.replace("/webapptest/VAP/Confirmation");
      window.history.entries = [];
      window.history.index = -1;
      this.props.history.entries = [];
      this.props.history.index = -1;
    } else {
      alert(response);
    }
  }else{
    alert("Please Enter valid Email address");
  }
  };

  handleDate = async (event) => {
    let name = event.target.name;
    let value = event.target.value;

    value = handleDateChange(value);

    if (moment(value, "MM/DD/YYYY", true).isValid() && value.length == 10) {
      this.formProgress(name, value);
    } else {
      this.formProgress(name, "");
    }
    await this.setState({
      data: { ...this.state.data, [name]: value },
    });
  };

  async componentDidMount() {
    await this.props.vapCache();
    window.scroll(0, 0);
    let data = this.state.data;
    if (data) {
      if (
        data.c1 !== "" ||
        data.c2 !== "" ||
        data.c3 !== "" ||
        data.c4 !== "" ||
        data.c5 !== "" ||
        data.c6 !== "" ||
        data.c7 !== "" ||
        data.c8 !== "" ||
        data.c9 !== "" ||
        data.c10 !== "" ||
        data.c11 !== "" ||
        data.c12 !== "" ||
        data.c13 !== "" ||
        data.c14 !== "" ||
        data.c15 !== "" ||
        data.c16 !== "" ||
        data.c22 !== "" ||
        data.c21 !== "" ||
        data.c25 !== "" ||
        data.c24 !== ""
      ) {
        await this.setState({ disableCheck: true });
      }
    }

    console.log(this.props.history.location);
    if (this.props.history.location.search) {
      const urlParams = new URLSearchParams(window.location.search);

      let planId = urlParams.get("planId");
      let pbpId = urlParams.get("pbpId");
      let planYear = urlParams.get("planYear");

      if (planId && pbpId && planYear) {
        history.push(
          "/webapptest/VAP/LandingPage?planYear=" +
            planYear +
            "&planId=" +
            planId +
            "&pbpId=" +
            pbpId
        );
      } else {
        history.push("/webapptest/InvalidPage");
      }
    }
  }

  handleCheckbox = async (event) => {
    let name = event.target.name;
    let value = event.target.checked;
    var checkedItems = [];
    this.formProgress(name, value);
    this.state.formRadio.map((d) => {
      if (name === Object.keys(d)[0] && value === true) {
        this.setState((prevState) => ({
          count: prevState.count + d[Object.keys(d)[0]],
          formData: [...prevState.formData, ...d[Object.keys(d)[1]]],
        }));
      } else if (name === Object.keys(d)[0] && value === false) {
        let index = -1;
        let subArray = d[Object.keys(d)[1]];
        let removedata = this.state.formData;
        subArray.map((c) => {
          index = removedata.findIndex(
            (p) => Object.keys(p)[0] === Object.keys(c)[0]
          );
          removedata.splice(index, 1);
        });
        console.log(removedata);

        console.log(this.state.count);

        this.setState((prevState) => ({
          count: prevState.count - d[Object.keys(d)[0]],
          formData: removedata,
        }));
      }
    });
    // VAP

    if (name === "soaPaper") {
      value = event.target.checked ? "Yes" : "";

    }

    if (name === "soaRecordedCall") {
      value = event.target.checked ? "Yes" : "";

    }
    if (name === "eligibleEnroll") {
      value = event.target.checked ? "E" : "";

    }

  

    if (name === "trcntCreditChBox") {
      value = event.target.checked ? "recntCredit" : "";

      if (value === "") {
        await this.setState({
          data: { ...this.state.data, recentlyCreditable: "" },
        });
      }
    }

    if (name === "newElgbChBox") {
      value = event.target.checked ? "newElgb" : "";
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, newlyEligbleMedicare: "" },
        });
      }
    }

    if (name === "revMedChBox") {
      value = event.target.checked ? "revMed" : "";
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, recieveMedicareDrugs: "" },
        });
      }
    }

    if (name === "levEmpChBox") {
      value = event.target.checked ? "levEmp" : "";
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, leavingEmployerCoverage: "" },
        });
      }
    }

    if (name === "changeInMedicaidChBox") {
      value = event.target.checked ? "MCD" : "";
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, changeInMedicaid: "" },
        });
      }
    }

    if (name === "changeInExtraHelpChBox") {
      value = event.target.checked ? "changeInExtraHelp" : "";
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, changeInExtraHelp: "" },
        });
      }
    }

    if (name === "noElgbspseChBox") {
      value = event.target.checked ? "noElgbspseChValue" : "";
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, noEligSpecial: "" },
        });
      }
    }

    if (name === "nlElgPrescChBox") {
      value = event.target.checked ? "mpElgbPresc" : "";
    }

    if (name === "recntleftPlChBox") {
      value = event.target.checked ? "recntLeftPlac" : "";
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, recntLeftPace: "" },
        });
      }
    }

    if (name === "mvdUsChBox") {
      value = event.target.checked ? "mvdUs" : "";
      if (value === "") {
        await this.setState({ data: { ...this.state.data, movedBackUs: "" } });
      }
    }

    if (name === "unCovChBox") {
      value = event.target.checked ? "unCov" : "";
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, unionCoverage: "" },
        });
      }
    }

    if (name === "belongStatePharmacy") {
      value = event.target.checked ? "B" : "";
    }

    if (name === "noneApplyMe") {
      value = event.target.checked ? "N" : "";
    }

    if (name === "changeInMedicareChBox") {
      value = event.target.checked ? "DIF" : "";
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, changeInMedicare: "" },
        });
      }
    }

    if (name === "outLngTermFcSeeChBox") {
      value = event.target.checked ? "outLngTermFcSee" : "";
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, outLongTermFacility: "" },
        });
      }
    }

    if (name === "affectedByDisaster") {
      value = event.target.checked ? "Y" : "";
    }

    if (name === "mAOEPChange") {
      value = event.target.checked ? "Y" : "";
    }

    await this.setState({
      data: { ...this.state.data, [name]: value },
    });

    // name = name.substring(1);
    if (name && value != "") {
      await this.setState({ checkedCount: [...this.state.checkedCount, name] });
    }

    if (name && value === "") {
      if (this.state.checkedCount.length > 0) {
        let items = this.state.checkedCount.filter((item) => item != name);
        await this.setState({ checkedCount: items });
      }
    }

  

var currentDate = new Date();
    
    var minDate = new Date('10/17/2020');
    var maxDate =  new Date('12/07/2020');

    if (currentDate > minDate && currentDate < maxDate ){
      await this.setState({isAep:true})
      await this.setState({    data: { ...this.state.data, aep: "A" }})
 }
 else{
  await  this.setState({isAep:false})
 }


 if(this.state.isAep === false){
 
  if(this.state.checkedCount && this.state.checkedCount.length > 0 && this.state.checkedCount.includes("eligibleEnroll")){
    this.setState({    data: { ...this.state.data, aep: "I" }})
  }
  else{
   this.setState({ data: { ...this.state.data, aep: "S" }})
  }
}






    if (this.state.checkedCount && this.state.checkedCount.length < 5) {

 
      await this.setState({ disableCheck: false });
    } else {
      await this.setState({ disableCheck: true });
    }
  };

  handleCheckbox1 = async (event) => {
    let name = event.target.name;
    let value = event.target.checked;
    console.log(name);
    console.log(value);
    if (name === "Formulary") {
      value = event.target.checked ? "Y" : "N";
    }
    if (name === "pharmacy") {
      value = event.target.checked ? "Y" : "N";
    }
    if (name === "eoc") {
      value = event.target.checked ? "Y" : "N";
    }

    if (name === "mailingAddressRequired") {
      value = event.target.checked ? "YES" : "";
    }
    await this.setState({
      data: { ...this.state.data, [name]: value },
    });
  };

  handleDates = (fieldId) => {
    var self = this;
    DateUtil.getDatePicker("#" + fieldId).datepicker("show");
    DateUtil.getDatePicker("#" + fieldId).on("change", (e) => {
      this.setDates(fieldId, e.target.value);
    });
  };

  setDates = async (fieldId, value) => {
    await this.setState({ data: { ...this.state.data, [fieldId]: value } });
    if (moment(value, "MM/DD/YYYY", true).isValid() && value.length == 10) {
      this.formProgress(fieldId, value);
    } else {
      this.formProgress(fieldId, "");
    }
  };
  formProgress = (name, value) => {
    let formData = this.state.formData.map((d) => {
      if (d[name] == 0 && value.trim().length > 0) {
        return { [name]: 1 };
      } else if (d[name] == 1 && value.trim().length == 0) {
        return { [name]: 0 };
      }
      return d;
    });
    this.setState({ formData: formData });
  };
  handleChange = async (e) => {
    let name = e.target.name;
    let value = e.target ? e.target.value : e.value;
    this.formProgress(name, value);
    this.state.formRadio.map((d) => {
      if (name === Object.keys(d)[0] && value === "Y") {
        this.setState((prevState) => ({
          count: prevState.count + d[Object.keys(d)[0]],
          formData: [...prevState.formData, ...d[Object.keys(d)[1]]],
        }));
      } else if (name === Object.keys(d)[0] && value === "N") {
        if (this.state.data[name].trim() !== "") {
          let index = -1;
          let subArray = d[Object.keys(d)[1]];
          let removedata = this.state.formData;
          subArray.map((c) => {
            index = removedata.findIndex(
              (p) => Object.keys(p)[0] === Object.keys(c)[0]
            );
            removedata.splice(index, 1);
          });

          this.setState((prevState) => ({
            count: prevState.count - d[Object.keys(d)[0]],
            formData: removedata,
          }));
        }
      }
    });
    // var jobsUnique = this.state.formData.filter((v,i,a)=>a.findIndex(t=>(JSON.stringify(t) === JSON.stringify(v)))===i)
    // console.log(jobsUnique);

//   var currentDate = new Date();
    
//   var minDate = new Date('10/17/2020');
//   var maxDate =  new Date('12/07/2020');

//   if (currentDate > minDate && currentDate < maxDate ){
//     await this.setState({isAep:true})
//     await this.setState({    data: { ...this.state.data, aep: "A" }})
// }
// else{
// await  this.setState({isAep:false})
// }

//  if(name === "aep"){

  
//   var currentDate = new Date();
    
//   var minDate = new Date('10/17/2020');
//   var maxDate =  new Date('12/07/2020');

//   if (currentDate > minDate && currentDate < maxDate ){
//     await this.setState({isAep:true})
//     await this.setState({    data: { ...this.state.data, aep: "A" }})
// }
// else{
// await  this.setState({isAep:false})
// }

// if(this.state.isAep === false ){
//   if(this.state.data.eligibleEnroll != ""){
//     this.setState({    data: { ...this.state.data, aep: "I" }})
//   }
//   else{
//     this.setState({    data: { ...this.state.data, aep: "S" }})
//   }
  
// }
// else{
//   this.setState({    data: { ...this.state.data, aep: "A" }})
// }



//  }


if(name == "timerecorded"){
  
  value=this.formatTime(value.replace(/[^0-9]/g, ""))
}

    if (
      name.toLowerCase().includes("phnumber") ||
      name.toLowerCase().includes("phone") ||
      name.toLowerCase().includes("emergphnum")
    ) {
      value = this.formatPhoneNumber(value.replace(/[^0-9]/g, ""));
    }

    if (name.toLowerCase().includes("attestation")) {
      await this.setState({ attestionDt: value });
    }
   
      await this.setState({ data: { ...this.state.data, [name]: value } });
    
    

    if (name === "physicianName" && this.state.data.physicianName == "") {
      await this.setState({
        data: {
          ...this.state.data,
          pcpAddr: "",
          pcpCity: "",
          pcpState: "",
          physician: "",
        },
      });
    }
    // stateMedicaid Y  medicaidNumber
    //console.log(name +' '+value)
    // console.log(this.state.data);
    // if(name=='medicaidNumber' ){

    // }
    // if(name =='stateMedicaid'){
    //   let formData = this.state.formData.map(d=>{
    //     if(value ==='Y' && name=='stateMedicaid'){
    //       return{ [name] :0};
    //     }else if(value ==='N' && name=='stateMedicaid'){
    //       return {[name] :1};
    //     }
    //     if(name =='medicaidNumber'){

    //     }
    //     return d
    //   })
    //   console.clear();
    //   console.log(formData)
    //   this.setState({formData:formData})
    // }

    if (name === "physicianName" && this.state.data.physicianName !== "") {
      console.log(this.state.data.physicianName);
      let item = this.props.dropdowns.pcpList.filter(
        (item) => item.physicianName == this.state.data.physicianName
      );

      console.log(this.state.data.physicianName);

      if (item.length > 0) {
        await this.setState({
          data: {
            ...this.state.data,
            pcpAddr: item[0].address,
            pcpCity: item[0].city,
            pcpState: item[0].state,
            physician: item[0].zipcode,
          },
        });
      }
    }

    if (name === "agentName" && this.state.data.agentName != "") {
      
      console.log(this.state.data.agentId);
      let item = this.props.dropdowns.agentList.filter(
        (item) => item.name == this.state.data.agentName
      );
      if (item.length > 0) {
        await this.setState({
          data: {
            ...this.state.data,
            email: item[0].email,
            name: item[0].name,
            phNum: item[0].phNum,
            agentId: item[0].agentId,
          },
        });
      }
    }
  };

  formatPhoneNumber = (phoneNumberString) => {
    var match = phoneNumberString.match(/^(\d{3})(\d{3})(\d{4})$/);
    if (match) {
      return "(" + match[1] + ") " + match[2] + "-" + match[3];
    }
    return phoneNumberString;
  };

  formatTime = (time) => {
    var match = time.match(/^(\d{2})(\d{2})$/);
    if (match) {
      return  match[1] + ":" + match[2] 
    }
    return time;
  };
  handleNumberChange = (event) => {
    let name = event.target.name;
    let value = event.target.value;

    value = value.replace(/[^0-9]/g, "");
    if (value.length === 5) {
      this.formProgress(name, value);
    } else {
      this.formProgress(name, "");
    }
    this.setState({ data: { ...this.state.data, [name]: value } });
  };

  handleSteps = async (event) => {
    let value = event.target ? event.target.id : event.id;
    if (value) {
      await this.setState({ stepVal: value });
    }
  };
  render() {
    let count = 0; //11;
    count = this.state.formData
      .map((item) => {
        return Object.values(item)[0];
      })
      .reduce((prev, next) => prev + next);

    const progress = (count / this.state.count) * 100;

    console.log(this.state.count);
    return (
      <React.Fragment>
        <div
          class="hfeed site"
          id="page"
          style={{
            fontFamily: "Opens Sans,  Helvetia, Arial, sans-serif  !important",
          }}
        >
          <div class="elementor elementor-124 elementor-location-header">
            <div class="elementor-section-wrap">
              <section class="elementor-section elementor-top-section elementor-element elementor-section-content-middle elementor-section-boxed ">
                <div class="elementor-container">
                  <div class="elementor-row">
                    <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-8342e5f">
                      <div class="elementor-column-wrap elementor-element-populated">
                        <div class="elementor-widget-wrap">
                          <div class="elementor-element">
                            <div class="elementor-widget-container">
                              <div class="elementor-image">
                                <a href="https://www.virginiapremier.com/">
                                  {" "}
                                  <img
                                    width="254"
                                    height="54"
                                    src={logo}
                                    class="attachment-full size-full"
                                    alt="Virginia Premier logo"
                                  />{" "}
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </section>

              <section class="elementor-section elementor-top-section elementor-element elementor-element-110a0f69 elementor-section-height-min-height elementor-section-boxed elementor-section-height-default elementor-section-items-middle">
                <div class="elementor-container elementor-column-gap-default">
                  <div class="elementor-row">
                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-6264989c">
                      <div class="elementor-column-wrap elementor-element-populated">
                        <div class="elementor-widget-wrap">
                          <div class="elementor-element elementor-element-3a15e9fc elementor-widget elementor-widget-theme-page-title elementor-page-title elementor-widget-heading">
                            <div class="elementor-widget-container">
                              <h1 class="elementor-heading-title elementor-size-default">
                                Virginia Premier Advantage Elite (HMO DSNP)
                              </h1>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
              <section class="elementor-section elementor-top-section elementor-element elementor-element-ba60d30 elementor-section-boxed mt-4">
                <div class="elementor-container elementor-column-gap-default">
                  <div class="elementor-row">
                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-8e19ec2">
                      <div class="elementor-column-wrap elementor-element-populated">
                        <div class="elementor-widget-wrap">
                          <div
                            class="elementor-element elementor-element-ca304d8 elementor-widget elementor-widget-text-editor"
                            data-id="ca304d8"
                          >
                            <div class="elementor-widget-container">
                              <div class="progress-bar">
                                <LinearProgress
                                  variant="determinate"
                                  value={progress}
                                  color="primary"
                                  classes={{
                                    root: this.props.classes.root,
                                    barColorPrimary:
                                      progress === 100
                                        ? this.props.classes.progressComplete
                                        : this.props.classes.progressIncomplete,
                                  }}
                                />
                              </div>
                              <div class="elementor-text-editor elementor-clearfix">
                                <h4>
                                  Please contact Virginia Premier if you need
                                  information in another language or format
                                  (Braille)
                                </h4>
                                <p>
                                  This Plan Requires Individuals to Have Both
                                  Medicare and Medicaid Coverage.
                                  <br />
                                  To Enroll in Virginia Premier Advantage Elite,
                                  Please Provide the Following Information:
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
            </div>
          </div>
          <div id="content" class="site-content mb-4">
            <div class="ast-container">
              <div class="content-area primary">
                <main id="main" class="site-main">
                  <div>
                    <ul
                      class="nav nav-pills nav-justified"
                      value={this.state.stepVal}
                      onClick={this.handleSteps}
                    >
                      <li class="nav-item">
                        {" "}
                        <a
                          class={
                            this.state.stepVal === "step1"
                              ? "nav-link activevap"
                              : "nav-link"
                          }
                          data-toggle="tab"
                          href="#step1"
                          id="step1"
                        >
                          Step 1
                        </a>{" "}
                      </li>
                      <li class="nav-item">
                        {" "}
                        <a
                          class={
                            this.state.stepVal === "step2"
                              ? "nav-link activevap"
                              : "nav-link"
                          }
                          data-toggle="tab"
                          href="#step2"
                          id="step2"
                        >
                          Step 2
                        </a>{" "}
                      </li>
                      <li class="nav-item">
                        {" "}
                        <a
                          class={
                            this.state.stepVal === "step3"
                              ? "nav-link activevap"
                              : "nav-link"
                          }
                          data-toggle="tab"
                          href="#step3"
                          id="step3"
                        >
                          Step 3
                        </a>{" "}
                      </li>
                      <li class="nav-item">
                        {" "}
                        <a
                          class={
                            this.state.stepVal === "step4"
                              ? "nav-link activevap"
                              : "nav-link"
                          }
                          data-toggle="tab"
                          href="#step4"
                          id="step4"
                        >
                          Step 4
                        </a>{" "}
                      </li>
                    </ul>
                    <p style={{ fontStyle: "italic" }}>
                      All fields marked with <span class="mandatory">*</span>{" "}
                      are required.
                    </p>
                    <div class="tab-content">
                      {this.state.stepVal === "step1" && (
                        <Step1
                          data={this.state.data}
                          handleChange={this.handleChange}
                          handleDates={this.handleDates}
                          redirect={this.redirect}
                          value={this.state.value}
                          handleSelectChange={this.handleSelectChange}
                          handleNumberChange={this.handleNumberChange}
                          handleCheckbox={this.handleCheckbox1}
                          handleDate={this.handleDate}
                        />
                      )}
                      {this.state.stepVal === "step2" && (
                        <Step2
                          data={this.state.data}
                          handleChange={this.handleChange}
                          handleDates={this.handleDates}
                          redirect={this.redirect}
                          handleCheckbox={this.handleCheckbox1}
                          handleDate={this.handleDate}
                        />
                      )}
                      {this.state.stepVal === "step3" && (
                        <Step3
                          data={this.state.data}
                          handleChange={this.handleChange}
                          handleDate={this.handleDate}
                          redirect={this.redirect}
                        />
                      )}
                      {this.state.stepVal === "step4" && (
                        <Step4
                          submitForm={progress === 100 ? false : true}
                          data={this.state.data}
                          handleChange={this.handleChange}
                          handleDates={this.handleDates}
                          disableCheck={this.state.disableCheck}
                          handleCheckbox={this.handleCheckbox}
                          redirect={this.redirect}
                          submitData={this.submitData}
                          handleDate={this.handleDate}
                          isAep={this.state.isAep}
                        />
                      )}
                    </div>
                  </div>
                </main>
              </div>
            </div>
          </div>
        </div>
        <Footer />
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    dropdowns: state.webApp.dropdowns,
    paramValues: state.webApp.paramValues,
  };
};
const mapDispatchToProps = {
  vapSubmit,
  vapCache,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(PreEnroll));
