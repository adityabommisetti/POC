import React, { Component } from "react";
import logo from "../assests/images/stop-sign-small.png";
import { connect } from "react-redux";
const ie =
  navigator.userAgent.indexOf("MSIE") > -1 ||
  navigator.userAgent.indexOf("rv:") > -1;

class Step4 extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  async componentDidMount() {
    window.scroll(0, 0);
  }

  render() {
    const { data, selectedPlan } = this.props;
    return (
      <React.Fragment>
        <div class="container tab-pane active">
          <div class="text-center">
            <img src={logo} class="stop-image" alt="Stop Sign" />
            <h4 class="mb-3">Please Read This Important Information</h4>
          </div>
          <p>
            <strong>
              If you currently have health coverage from an employer or union,
              joining Virginia Premier could affect your employer or union
              health benefits. You could lose your employer or union health
              coverage if you join Virginia Premier.
            </strong>{" "}
            Read the communications your employer or union sends you. If you
            have questions, visit their website, or contact the office listed in
            their communications. If there isn’t any information on whom to
            contact, your benefits administrator or the office that answers
            questions about your coverage can help.
          </p>

          <h4 class="mb-3">Please Read and Sign Below</h4>
          <p>
            By completing this enrollment application, I agree to the following:
          </p>
          <p>
            Virginia Premier is a Medicare Advantage plan and has a contract
            with the Federal government. I will need to keep my Medicare Parts A
            and B. I can be in only one Medicare Advantage plan at a time, and I
            understand that my enrollment in this plan will automatically end my
            enrollment in another Medicare health plan or prescription drug
            plan. It is my responsibility to inform you of any prescription drug
            coverage that I have or may get in the future. Enrollment in this
            plan is generally for the entire year. Once I enroll, I may leave
            this plan or make changes only at certain times of the year when an
            enrollment period is available (Example: October 15 – December 7 of
            every year), or under certain special circumstances.
          </p>
          <p>
            Virginia Premier serves a specific service area. If I move out of
            the area that Virginia Premier serves, I need to notify the plan so
            I can disenroll and find a new plan in my new area. Once I am a
            member of Virginia Premier, I have the right to appeal plan
            decisions about payment or services if I disagree. I will read the
            Evidence of Coverage document from Virginia Premier when I get it to
            know which rules I must follow to get coverage with this Medicare
            Advantage plan. I understand that people with Medicare aren’t
            usually covered under Medicare while out of the country except for
            limited coverage near the U.S. border.
          </p>
          <p>
            I understand that beginning on the date Virginia Premier coverage
            begins, I must get all of my health care from Virginia Premier,
            except for emergency or urgently needed services or out-of-area
            dialysis services. Services authorized by Virginia Premier and other
            services contained in my Virginia Premier Evidence of Coverage
            document (also known as a member contract or subscriber agreement)
            will be covered. Without authorization,{" "}
            <strong>
              NEITHER MEDICARE NOR VIRGINIA PREMIER WILL PAY FOR THE SERVICES.
            </strong>
          </p>
          <p>
            I understand that if I am getting assistance from a sales agent,
            broker, or other individual employed by or contracted with Virginia
            Premier, he/she may be paid based on my enrollment in Virginia
            Premier.
          </p>
          <p>
            <strong>
              <u>Release of Information:</u>
            </strong>{" "}
            By joining this Medicare health plan, I acknowledge that Virginia
            Premier will release my information to Medicare and other plans as
            is necessary for treatment, payment and health care operations. I
            also acknowledge that Virginia Premier will release my information
            including my prescription drug event data to Medicare, who may
            release it for research and other purposes which follow all
            applicable Federal statutes and regulations. The information on this
            enrollment form is correct to the best of my knowledge. I understand
            that if I intentionally provide false information on this form, I
            will be disenrolled from the plan.
          </p>
          <p>
            I understand that my signature (or the signature of the person
            authorized to act on my behalf under the laws of the State where I
            live) on this application means that I have read and understand the
            contents of this application. If signed by an authorized individual
            (as described above), this signature certifies that 1) this person
            is authorized under State law to complete this enrollment and 2)
            documentation of this authority is available upon request from
            Medicare.
          </p>

          <div class="row">
            <div class="col-4">
              <label class="control-label" for="printName" id="printName">
                Print Name<span class="mandatory">*</span> :
              </label>
              <input
                type="text"
                class={
                  this.props.data.nameSignature === ""
                    ? "error-input"
                    : "form-control"
                }
                id="printName"
                name="nameSignature"
                value={data.nameSignature}
                onChange={this.props.handleChange}
              />
            </div>
            <div class="col-4">
              <label class="control-label" for="digitalSignature">
                Digital Signature<span class="mandatory">*</span> :
              </label>
              <input
                type="text"
                class="form-control"
                id="digitalSignature"
                name="digitalSignature"
                disabled="disabled"
                // onChange={this.props.handleChange}
                value={data.nameSignature}
              />
            </div>
            <div class="col-4">
              <label class="control-label" for="todaysDate">
                Today's Date<span class="mandatory">*</span> :
              </label>
              <input
                style={{ border: "1px solid #666666" }}
                type="text"
                readOnly
                class={
                  this.props.data.todaysDate === ""
                    ? "error-input"
                    : "form-control"
                }
                name="todaysDate"
                id="todaysDate"
                placeholder="mm/dd/yyyy"
                value={data.todaysDate}
                onChange={this.props.handleChange}
              />
            </div>
          </div>

          <div id="authorizedrep" class="mt-5 mb-4">
            <p>
              <strong>
                If you are the authorized representative, you must sign above
                and provide the following information:
              </strong>
            </p>
            <div class="row mt-3">
              <div class="col-md-4">
                <label class="control-label" for="authorizedrepname">
                  Name:
                </label>
                <input
                  type="text"
                  class="form-control"
                  name="legalFirstName"
                  id="authorizedrepname"
                  value={data.legalFirstName}
                  onChange={this.props.handleChange}
                />
              </div>
              <div class="col-md-8">
                <label class="control-label" for="authorizedRepAddr">
                  Address:
                </label>
                <input
                  type="text"
                  class="form-control"
                  id="authorizedrepaddress"
                  name="legalAddress"
                  value={data.legalAddress}
                  onChange={this.props.handleChange}
                />
              </div>
            </div>
            <div class="row mt-3">
              <div class="col-md-4">
                <label class="control-label" for="authorizedrepphone">
                  Phone Number:
                </label>
                <input
                  type="text"
                  name="legalPhNumber"
                  id="authorizedrepphone"
                  class={ie ? "form-control ieheight" : "form-control"}
                  placeholder="(   )"
                  maxlength="14"
                  value={data.legalPhNumber}
                  onChange={this.props.handleChange}
                />
              </div>
              <div
                class={
                  ie ? "col-lg-3 col-md-4 iemargintop" : "col-lg-3 col-md-4"
                }
              >
                <label for="relationshipToYou" class="control-label">
                  Relationship to Enrollee:
                </label>
                <select
                  style={{
                    borderRadius: "4px",
                    paddingTop: "4px",
                    paddingBottom: "4px",
                    height: "37px",
                    width: "356px",
                  }}
                  class="form-control"
                  id="relationshipToYou"
                  name="legalRelationErloll"
                  value={data.legalRelationErloll}
                  onChange={this.props.handleChange}
                >
                  {/* {this.props.dropdowns &&
                    this.props.dropdowns.relEnrollemap.map((item, i) => {
                      return (
                        <option
                          class="select-option"
                          value={item.value}
                          key={i}
                        >
                          {item.label}
                        </option>
                      );
                    })} */}

                  {this.props.dropdowns &&
                    this.props.dropdowns.relEnrollemList &&
                    this.props.dropdowns.relEnrollemList.map((item, i) => {
                      return (
                        <option
                          class="select-option"
                          value={item.value}
                          key={i}
                        >
                          {item.label}
                        </option>
                      );
                    })}
                  {/* <option value="ATY">ATTORNEY</option>
                  <option value="DEP">DEPENDENT</option>
                  <option value="EMP">EMPLOYEE</option>
                  <option value="DAD">FATHER</option>
                  <option value="FCH">FOSTER CHILD</option>
                  <option value="FSP">FOSTER PARENT</option>
                  <option value="PAL">FRIEND</option>
                  <option value="GCH">GRANDCHILD</option>
                  <option value="GFA">GRANDFATHER</option>
                  <option value="GMA">GRANDMOTHER</option>
                  <option value="GPR">GRANDPARENT</option>
                  <option value="GRD">GUARDIAN</option>
                  <option value="LIF">LIFE PARTNER</option>
                  <option value="MOM">MOTHER</option>
                  <option value="NCH">NATURAL CHILD</option>
                  <option value="NN">NIECE/NEPHEW</option>
                  <option value="OTH">OTHER</option>
                  <option value="POA">POWER OF ATTORNEY</option>
                  <option value="REL">RELATIVE</option>
                  <option value="SIB">SIBLING</option>
                  <option value="SPS">SPOUSE</option>
                  <option value="SCH">STEP CHILD</option>
                  <option value="STP">STEP PARENT</option> */}
                </select>
              </div>

              {/*<div class="col-md-8">
                <label class="control-label" for="authorizedreprelationship">
                  Relationship to Enrollee:
                </label>
                <input
                  type="text"
                  class="form-control"
                  name="legalRelationErloll"
                  id="authorizedreprelationship"
                  value={data.legalRelationErloll}
                  onChange={this.props.handleChange}
                />
              </div>*/}
            </div>
          </div>

          <button
            class="btnvap btn-primaryvap btn-save-n-next"
            id="step3"
            onClick={this.props.redirect}
          >
            Save &amp; Next
          </button>
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    dropdowns: state.webApp.dropdowns,
  };
};
const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(Step4);
