import React, { Component } from "react";

export default class Footer extends Component {
  render() {
    return (
      <React.Fragment>
        <div class="elementor elementor-3579 elementor-location-footer">
          <div class="elementor-section-wrap">
            <section class="elementor-section elementor-top-section elementor-element elementor-element-3aba5b4a elementor-section-height-min-height elementor-section-content-top elementor-section-items-top elementor-section-boxed elementor-section-height-default">
              <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-row">
                  <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-6b9ec446">
                    <div class="elementor-column-wrap elementor-element-populated">
                      <div class="elementor-widget-wrap">
                        <div class="elementor-element elementor-element-772b64de elementor-widget elementor-widget-text-editor">
                          <div class="elementor-widget-container">
                            <div class="elementor-text-editor elementor-clearfix">
                              <p>
                                <strong>Material ID</strong>
                                :H9877_0519-MEFR-800068_C
                                <br />
                                <strong>Updated Date</strong>:October 15, 2020
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>
      </React.Fragment>
    );
  }
}
