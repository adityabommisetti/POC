import React, { Component } from "react";
import history from "../Utils/History";
import Footer from "./vap_footer";
import moment from "moment";
import Header from "./vap_header";
import { connect } from "react-redux";
import { getPDF } from "../Redux/Actions/webAppActions";
import logo from "../assests/images/vp-logo.png";
//
class Confirmation extends Component {
  constructor(props) {
    super(props);

    this.state = {
      stepVal: "btn-step1",
    };
  }

  handleSelectChange = async (event) => {
    const value = event.target.value;

    await this.setState({
      value: value,
    });
  };

  componentDidMount() {
    // this.props.history.push(null, null, "no-back-button");
    // window.addEventListener("popstate", function (event) {
    //   this.props.history.push(null, null, "no-back-button");
    // });
  }

  openPDFDoc = async () => {
    await this.props.getPDF();
    var base64str = this.props.pdf;

    var binary = atob(base64str.replace(/\s/g, ""));
    var len = binary.length;
    var buffer = new ArrayBuffer(len);
    var view = new Uint8Array(buffer);
    for (var i = 0; i < len; i++) {
      view[i] = binary.charCodeAt(i);
    }
    var blob = new Blob([view], {
      type: "application/pdf",
    });
    var url = window.URL.createObjectURL(blob);
    if (navigator.msSaveBlob) {
      return navigator.msSaveOrOpenBlob(blob, "download.pdf");
    }
    window.open(
      url,
      "popUpWindow",
      "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=900" +
        ", height=900" +
        ", top=10" +
        ", left=10"
    );
  };

  render() {
    const { data } = this.props;
    return (
      <React.Fragment>
        <Header />
        <div id="content" class="site-content mb-4">
          <div class="ast-container">
            <div class="content-area primary">
              <main id="main" class="site-main">
                <div class="wrapper-inner">
                  <div class="row">
                    <div class="col-lg-8 col-md-10 col-sm-12">
                      <h2 class="mt-3 mb-3">Thank you.</h2>
                      <p>
                        Your enrollment application will be sent to the Centers
                        for Medicare and Medicaid Services (CMS) for review.
                      </p>

                      <p>
                        Please be aware that you may be contacted if any
                        additional information is needed to complete your
                        enrollment request.
                      </p>

                      <p>
                        Your enrollment tracking number is
                        <span style={{ marginLeft: "10px " }}>
                          {" "}
                          <strong> {this.props.vapcount} </strong>
                        </span>
                      </p>

                      <p>Please keep this for your records.</p>

                      <p>
                        You will be notified by mail if your enrollment has been
                        approved or denied. If you have any questions, please
                        call our Member Services department at 1-877-739-1370
                        (TTY 711). From October 1 to February 14, you can reach
                        us by phone from 8:00 am to 8:00 pm, seven days a week,
                        except on some holidays. From February 15 to September
                        30 our hours are the same, but on weekends and some
                        holidays our automated phone system will answer you
                        call.
                      </p>

                      <p>
                        If you would like to print a copy of your application,
                        please click on the "Print a Copy" button below.
                      </p>

                      <div class="mt-2">
                        <button
                          class="btn btn-primaryvap"
                          onClick={() => {
                            this.openPDFDoc();
                          }}
                        >
                          Print a Copy
                        </button>
                        <br />
                        <button class="btn btn-secondary mt-2">
                          Return to Virginia Premier
                        </button>
                      </div>

                      <p class="mt-2">
                        Virginia Premier is an (HMO) and (HMO SNP) organisation
                        with a Medicare contract Enrollment in any Virginia
                        Premier plan depends on contract renewal.
                      </p>
                    </div>
                  </div>
                </div>
              </main>
            </div>
          </div>
        </div>
        <Footer />
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    pdf: state.webApp.pdf,
    vapcount: state.webApp.vapcount,
  };
};
const mapDispatchToProps = { getPDF };

export default connect(mapStateToProps, mapDispatchToProps)(Confirmation);
