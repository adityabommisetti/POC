import React, { Component } from "react";
import logo from "../assests/images/vp-logo.png";

export default class Header extends Component {
  constructor(props) {
    super(props);

    this.state = {};
  }

  render() {
    const { classes, children } = this.props;
    return (
      <React.Fragment>
        <div class="elementor elementor-124 elementor-location-header">
          <div class="elementor-section-wrap">
            <section class="elementor-section elementor-top-section elementor-element elementor-section-content-middle elementor-section-boxed ">
              <div class="elementor-container">
                <div class="elementor-row">
                  <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-8342e5f">
                    <div class="elementor-column-wrap elementor-element-populated">
                      <div class="elementor-widget-wrap">
                        <div class="elementor-element">
                          <div class="elementor-widget-container">
                            <div class="elementor-image">
                              <a href="https://www.virginiapremier.com/">
                                <img
                                  width="254"
                                  height="54"
                                  src={logo}
                                  class="attachment-full size-full"
                                  alt="Virginia Premier logo"
                                />{" "}
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            <section class="elementor-section elementor-top-section elementor-element elementor-element-110a0f69 elementor-section-height-min-height elementor-section-boxed elementor-section-height-default elementor-section-items-middle">
              <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-row">
                  <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-6264989c">
                    <div class="elementor-column-wrap elementor-element-populated">
                      <div class="elementor-widget-wrap">
                        <div class="elementor-element elementor-element-3a15e9fc elementor-widget elementor-widget-theme-page-title elementor-page-title elementor-widget-heading">
                          <div class="elementor-widget-container">
                            <h1 class="elementor-heading-title elementor-size-default">
                              Virginia Premier Advantage Elite (HMO DSNP)
                            </h1>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* <section class="elementor-section elementor-top-section elementor-element elementor-element-ba60d30 elementor-section-boxed mt-4">
              <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-row">
                  <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-8e19ec2">
                    <div class="elementor-column-wrap elementor-element-populated">
                      <div class="elementor-widget-wrap">
                        <div
                          class="elementor-element elementor-element-ca304d8 elementor-widget elementor-widget-text-editor"
                          data-id="ca304d8"
                        >
                          <div class="elementor-widget-container">
                            <div class="elementor-text-editor elementor-clearfix">
                              <p>
                                INDIVIDUAL ENROLLMENT REQUEST FORM TO ENROLL IN
                                A MEDICARE ADVANTAGE PLAN (PART C)
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section> */}
          </div>
        </div>
      </React.Fragment>
    );
  }
}
