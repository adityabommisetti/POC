import React, { Component } from "react";
export default class InvalidPage extends Component {
  render() {
    return (
      <div className="jumbotron">
        <div id="main">
          <div class="fof">
            <h1>Error 404</h1>
          </div>
        </div>
      </div>
    );
  }
}
