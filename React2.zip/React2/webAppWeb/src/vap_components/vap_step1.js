import React, { Component } from "react";
import history from "../Utils/History";
import { connect } from "react-redux";
import moment from "moment";
const ie =
  navigator.userAgent.indexOf("MSIE") > -1 ||
  navigator.userAgent.indexOf("rv:") > -1;

class Step1 extends Component {
  constructor(props) {
    super(props);

    this.state = {
      stepVal: "btn-step1",
    };
  }

  handleSelectChange = async (event) => {
    const value = event.target.value;

    await this.setState({
      value: value,
    });
  };
  async componentDidMount() {
    window.scroll(0, 0);
  }

  render() {
    const { data } = this.props;
    return (
      <React.Fragment>
        <div id="step1" class="container tab-pane active">
          <div class="form-panel">
            <h4 class="sub-heading">
              A. Please Provide the following information:
            </h4>
            <div class="form-group row">
              <div class="col-lg-3 col-md-6 mt-2">
                <label for="lastName" class="control-label" id="lastName">
                  Last Name<span class="mandatory">*</span>:
                </label>
                <input
                  type="text"
                  id="lastName"
                  value={data.lastName}
                  onChange={this.props.handleChange}
                  name="lastName"
                  required=""
                  class={data.lastName === "" ? "error-input" : "form-control"}
                />{" "}
              </div>
              <div class="col-lg-3 col-md-6 mt-2">
                <label for="firstName" class="control-label" id="firstName">
                  First Name<span class="mandatory">*</span>:
                </label>
                <input
                  type="text"
                  id="firstName"
                  name="firstName"
                  class={data.firstName === "" ? "error-input" : "form-control"}
                  required=""
                  value={data.firstName}
                  onChange={this.props.handleChange}
                />{" "}
              </div>
              <div class="col-lg-3 col-md-6 mt-2">
                <label for="middleInitial" class="control-label">
                  Middle Initial:
                </label>
                <input
                  type="text"
                  class="form-control"
                  maxlength="1"
                  id="middleInitial"
                  name="middleInitial"
                  value={data.middleInitial}
                  onChange={this.props.handleChange}
                />{" "}
              </div>
              <div class="col-lg-3 col-md-6 mt-2">
                <fieldset class={ie ? "radio ieradio" : "radio"}>
                  <legend>Prefix</legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      id="Mr"
                      name="suffix"
                      class="custom-control-input"
                      value="Mr"
                      checked={data.suffix === "Mr"}
                      onChange={this.props.handleChange}
                    />
                    <label
                      for="Mr"
                      class="radio-inline custom-control-label"
                      style={{ cursor: "pointer" }}
                    >
                      Mr
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      id="Mrs"
                      name="suffix"
                      class="custom-control-input"
                      value="Mrs"
                      checked={data.suffix === "Mrs"}
                      onChange={this.props.handleChange}
                    />
                    <label
                      for="Mrs"
                      class="radio-inline custom-control-label"
                      style={{ cursor: "pointer" }}
                    >
                      Mrs
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      id="Ms"
                      name="suffix"
                      class="custom-control-input"
                      value="Ms"
                      checked={data.suffix === "Ms"}
                      onChange={this.props.handleChange}
                    />
                    <label
                      for="Ms"
                      class="radio-inline custom-control-label"
                      style={{ cursor: "pointer" }}
                    >
                      Ms
                    </label>
                  </div>
                </fieldset>
              </div>
            </div>
            <div class="form-group row align-items-flex-end">
              <div class="col-lg-3 col-md-4">
                <label for="birthDate" class="control-label" id="birthDate1">
                  Birth Date<span class="mandatory">*</span>:
                </label>
                <input
                  name="birthDate"
                  id="birthDate"
                  placeholder="MM/DD/YYYY"
                  required=""
                  style={{
                    borderRadius: "0",
                    paddingTop: "4px",
                    paddingBottom: "4px",
                    height: "37px",
                  }}
                  value={data.birthDate}
                  onClick={(e) => this.props.handleDates("birthDate")}
                  maxLength="10"
                  class={
                    data.birthDate === "" ||
                    !moment(data.birthDate, "MM/DD/YYYY", true).isValid()
                      ? "error-input"
                      : "form-control"
                  }
                  onChange={this.props.handleDate}
                />{" "}
              </div>
              <div class="col-lg-3 col-md-4">
                <fieldset class="radio radio-tab">
                  <legend class="control-label" id="sex">
                    Sex<span class="mandatory">*</span>:
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      value="M"
                      name="sex"
                      id="male"
                      class="custom-control-input"
                      style={data.sex === "" ? { borderColor: "red" } : {}}
                      checked={data.sex === "M"}
                      onChange={this.props.handleChange}
                      style={{ zIndex: -1 }}
                    />
                    <label
                      for="male"
                      class="radio-inline custom-control-label"
                      style={{ cursor: "pointer" }}
                    >
                      Male
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      value="F"
                      name="sex"
                      id="female"
                      class="custom-control-input"
                      style={data.sex === "" ? { borderColor: "red" } : {}}
                      checked={data.sex === "F"}
                      onChange={this.props.handleChange}
                      style={{ zIndex: -1 }}
                    />
                    <label
                      for="female"
                      class="radio-inline custom-control-label"
                      style={{ cursor: "pointer" }}
                    >
                      Female
                    </label>
                  </div>
                </fieldset>
              </div>
              <div class="col-lg-3 col-md-4">
                <label for="primaryPhone" class="control-label">
                  Home Phone Number:
                </label>
                <input
                  type="text"
                  id="primaryPhone"
                  name="homePhNumber"
                  class={ie ? "form-control ieheight" : "form-control"}
                  // class={
                  //   data.homePhNumber === "" ? "error-input" : "form-control"
                  // }
                  placeholder="(   )"
                  required=""
                  maxlength="14"
                  value={data.homePhNumber}
                  onChange={this.props.handleChange}
                />{" "}
              </div>
              <div class="col-lg-3 col-md-5 mt-2">
                <label for="altPhoneNo" class="control-label">
                  <i>Optional field:</i>
                  <br />
                  Alternate Phone Number:
                </label>
                <input
                  type="text"
                  id="altPhoneNo"
                  name="altrPhNumber"
                  class={ie ? "form-control ieheight" : "form-control"}
                  placeholder="(   )"
                  maxlength="14"
                  // class={
                  //   data.altrPhNumber === "" ? "error-input" : "form-control"
                  // }
                  placeholder="(   )"
                  required=""
                  maxlength="14"
                  value={data.altrPhNumber}
                  onChange={this.props.handleChange}
                />{" "}
              </div>
            </div>

            <div class="form-group row align-items-flex-end">
              <div class="col-md-9">
                <label
                  for="permanentAddr"
                  class="control-label"
                  id="permanentAddr"
                >
                  Permanent Residence Street Address{" "}
                  <strong>(P.O. Box is not allowed)</strong>:
                  <span class="mandatory">*</span>{" "}
                </label>
                <input
                  type="text"
                  name="permanentAddr"
                  id="permanentAddr"
                  class={
                    data.permanentAddr === "" ? "error-input" : "form-control"
                  }
                  required=""
                  value={data.permanentAddr}
                  onChange={this.props.handleChange}
                />{" "}
              </div>
            </div>
            <div class="form-group row align-items-flex-end">
              <div class="col-lg-3 col-md-4">
                <label
                  for="permanentCity"
                  class="control-label"
                  id="permanentCity"
                >
                  City<span class="mandatory">*</span>:
                </label>
                <input
                  type="text"
                  class="form-control"
                  name="permanentCity"
                  class={
                    data.permanentCity === "" ? "error-input" : "form-control"
                  }
                  name="permanentCity"
                  id="permanentCity"
                  required=""
                  value={data.permanentCity}
                  onChange={this.props.handleChange}
                />{" "}
              </div>
              <div class="col-md-3 col-md-4">
                <label
                  for="permanentCounty"
                  class="control-label"
                  id="permanentCounty"
                >
                  <i>Optional field:</i> County:
                </label>
                <input
                  type="text"
                  class="form-control"
                  name="permanentCounty"
                  id="permanentCounty"
                  value={data.permanentCounty}
                  onChange={this.props.handleChange}
                  height={ie ? "34px" : "auto"}
                />{" "}
              </div>
              <div class="col-lg-3 col-md-4">
                <label for="permanentState" class="control-label">
                  State
                </label>
                <br />
                <select
                  style={{
                    borderRadius: "0",
                    paddingTop: "4px",
                    paddingBottom: "4px",
                    height: ie ? "34px" : "37px",
                  }}
                  id="permanentState"
                  class="form-control"
                  required=""
                  value={data.permanentState}
                  onChange={this.props.handleChange}
                  name="permanentState"
                  disabled="disabled"
                >
                  <option>VA</option>
                </select>
              </div>
              <div class="col-lg-2 col-md-2 mt-2">
                <label
                  for="permanentZip"
                  class="control-label"
                  id="permanentZip"
                >
                  ZIP Code<span class="mandatory">*</span>:
                </label>
                <input
                  type="text"
                  class={
                    data.permanentZip === "" ||
                    (data.permanentZip && data.permanentZip.length < 5)
                      ? "error-input "
                      : "form-control "
                  }
                  name="permanentZip"
                  id="permanentZip"
                  minlength="5"
                  maxlength="5"
                  required=""
                  value={data.permanentZip}
                  onChange={this.props.handleNumberChange}
                  height={ie ? "34px" : "auto"}
                />{" "}
              </div>
            </div>

            <div class="form-group row">
              <div class="col-md-12">
                {" "}
                Is the above address different from your mailing address ?
                &nbsp;&nbsp;
                <div class="custom-control custom-checkbox custom-control-inline ie1">
                  <input
                    type="checkbox"
                    name="mailingAddressRequired"
                    id="mailingAddressRequired"
                    class="custom-control-input"
                    value={data.mailingAddressRequired}
                    checked={
                      data.mailingAddressRequired === "YES" ? true : false
                    }
                    onChange={this.props.handleCheckbox}
                  />
                  <label
                    style={{ cursor: "pointer" }}
                    for="mailingAddressRequired"
                    class="custom-control-label"
                  >
                    <strong>YES</strong>
                  </label>
                </div>
              </div>
            </div>
            {data.mailingAddressRequired === "YES" ? (
              <React.Fragment>
                <div id="mailing-adddress">
                  <div class="form-group row align-items-flex-end">
                    <div class="col-md-9">
                      <label
                        for="mailingAddr"
                        class="control-label"
                        id="mailingAddr"
                      >
                        Mailing Address (only if different from your Permanent
                        Residence Address): <span class="mandatory">*</span>
                      </label>
                      <input
                        type="text"
                        class={
                          data.mailingAddr === ""
                            ? "error-input"
                            : "form-control"
                        }
                        name="mailingAddr"
                        id="mailingAddr"
                        required=""
                        value={data.mailingAddr}
                        onChange={this.props.handleChange}
                      />{" "}
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-lg-3 col-md-4">
                      <label
                        for="mailingCity"
                        class="control-label"
                        id="mailingCity"
                      >
                        City<span class="mandatory">*</span>
                      </label>
                      <input
                        type="text"
                        class={
                          data.mailingCity === ""
                            ? "error-input"
                            : "form-control"
                        }
                        name="mailingCity"
                        id="mailingCity"
                        required=""
                        value={data.mailingCity}
                        onChange={this.props.handleChange}
                      />{" "}
                    </div>
                    <div class="col-lg-3 col-md-4">
                      <label
                        for="mailingState"
                        class="control-label"
                        id="mailingState"
                      >
                        State<span class="mandatory">*</span>
                      </label>
                      <select
                        style={{
                          borderRadius: "0",
                          paddingTop: "4px",
                          paddingBottom: "4px",
                          height: "37px",
                        }}
                        class="form-control"
                        class={
                          data.mailingState === ""
                            ? "error-input"
                            : "form-control"
                        }
                        name="mailingState"
                        id="mailingState"
                        value={data.mailingState}
                        onChange={this.props.handleChange}
                      >
                        <option value="none">Select...</option>
                        <option value="AK">AK</option>
                        <option value="AL">AL</option>
                        <option value="AR">AR</option>
                        <option value="AZ">AZ</option>
                        <option value="CA">CA</option>
                        <option value="CO">CO</option>
                        <option value="CT">CT</option>
                        <option value="DC">DC</option>
                        <option value="DE">DE</option>
                        <option value="FL">FL</option>
                        <option value="GA">GA</option>
                        <option value="HI">HI</option>
                        <option value="IA">IA</option>
                        <option value="ID">ID</option>
                        <option value="IL">IL</option>
                        <option value="IN">IN</option>
                        <option value="KS">KS</option>
                        <option value="KY">KY</option>
                        <option value="LA">LA</option>
                        <option value="MA">MA</option>
                        <option value="MD">MD</option>
                        <option value="ME">ME</option>
                        <option value="MI">MI</option>
                        <option value="MN">MN</option>
                        <option value="MO">MO</option>
                        <option value="MS">MS</option>
                        <option value="MT">MT</option>
                        <option value="NC">NC</option>
                        <option value="ND">ND</option>
                        <option value="NE">NE</option>
                        <option value="NH">NH</option>
                        <option value="NJ">NJ</option>
                        <option value="NM">NM</option>
                        <option value="NV">NV</option>
                        <option value="NY">NY</option>
                        <option value="OH">OH</option>
                        <option value="OK">OK</option>
                        <option value="OR">OR</option>
                        <option value="PA">PA</option>
                        <option value="RI">RI</option>
                        <option value="SC">SC</option>
                        <option value="SD">SD</option>
                        <option value="TN">TN</option>
                        <option value="TX">TX</option>
                        <option value="UT">UT</option>
                        <option value="VA">VA</option>
                        <option value="VT">VT</option>
                        <option value="WA">WA</option>
                        <option value="WI">WI</option>
                        <option value="WV">WV</option>
                        <option value="WY">WY</option>
                      </select>
                    </div>
                    <div class="col-lg-3 col-md-4">
                      <label
                        for="mailingZip"
                        class="control-label"
                        id="mailingZip"
                      >
                        Zip Code<span class="mandatory">*</span>
                      </label>
                      <input
                        type="text"
                        class={
                          data.mailingZip === ""
                            ? "error-input"
                            : "form-control"
                        }
                        name="mailingZip"
                        id="mailingZip"
                        minlength="5"
                        maxlength="5"
                        required=""
                        value={data.mailingZip}
                        onChange={this.props.handleChange}
                      />{" "}
                    </div>
                  </div>
                </div>
              </React.Fragment>
            ) : null}
            <div class="form-group row align-items-flex-end">
              <div class="col-lg-6 col-md-5">
                <label for="emergencyContact" class="control-label">
                  <i>Optional field:</i> Emergency Contact:
                </label>
                <input
                  type="text"
                  id="emergencyContact"
                  name="emergencyCont"
                  class="form-control"
                  value={data.emergencyCont}
                  onChange={this.props.handleChange}
                />{" "}
              </div>
              <div class="col-lg-3 col-md-3">
                <label for="mailingPhoneNo" class="control-label">
                  Phone Number:
                </label>
                <input
                  type="text"
                  id="mailingPhoneNo"
                  name="emergPhNum"
                  class={ie ? "form-control ieheight" : "form-control"}
                  placeholder="(   )"
                  maxlength="14"
                  value={data.emergPhNum}
                  onChange={this.props.handleChange}
                />{" "}
              </div>
              <div class="col-lg-3 col-md-4">
                <label for="relationshipToYou" class="control-label">
                  Relationship to You:
                </label>
                <select
                  style={{
                    borderRadius: "0",
                    paddingTop: "4px",
                    paddingBottom: "4px",
                    height: "37px",
                  }}
                  class="form-control "
                  id="relationshipToYou"
                  name="relationYou"
                  value={data.relationYou}
                  onChange={this.props.handleChange}
                >
                  {/* {this.props.dropdowns &&
                    this.props.dropdowns.relEnrollemap.map((item, i) => {
                      return (
                        <option
                          class="select-option"
                          value={item.value}
                          key={i}
                        >
                          {item.label}
                        </option>
                      );
                    })} */}

                  {this.props.dropdowns &&
                    this.props.dropdowns.relEnrollemList &&
                    this.props.dropdowns.relEnrollemList.map((item, i) => {
                      return (
                        <option
                          class="select-option"
                          value={item.value}
                          key={i}
                        >
                          {item.label}
                        </option>
                      );
                    })}
                  {/* <option value="ATY">ATTORNEY</option>
                  <option value="DEP">DEPENDENT</option>
                  <option value="EMP">EMPLOYEE</option>
                  <option value="DAD">FATHER</option>
                  <option value="FCH">FOSTER CHILD</option>
                  <option value="FSP">FOSTER PARENT</option>
                  <option value="PAL">FRIEND</option>
                  <option value="GCH">GRANDCHILD</option>
                  <option value="GFA">GRANDFATHER</option>
                  <option value="GMA">GRANDMOTHER</option>
                  <option value="GPR">GRANDPARENT</option>
                  <option value="GRD">GUARDIAN</option>
                  <option value="LIF">LIFE PARTNER</option>
                  <option value="MOM">MOTHER</option>
                  <option value="NCH">NATURAL CHILD</option>
                  <option value="NN">NIECE/NEPHEW</option>
                  <option value="OTH">OTHER</option>
                  <option value="POA">POWER OF ATTORNEY</option>
                  <option value="REL">RELATIVE</option>
                  <option value="SIB">SIBLING</option>
                  <option value="SPS">SPOUSE</option>
                  <option value="SCH">STEP CHILD</option>
                  <option value="STP">STEP PARENT</option> */}
                </select>
              </div>
            </div>

            <div class="form-group row align-items-flex-end">
              <div class="col-lg-6 col-md-7">
                <label for="emailAddr" class="control-label">
                  <i>Optional field:</i> E-mail Address:
                </label>
                <input
                  type="email"
                  id="emailAddr"
                  class="form-control"
                  name="emailAddr"
                  value={data.emailAddr}
                  onChange={this.props.handleChange}
                />
              </div>
            </div>
            <h4 class="sub-heading mt-4">
              B. Please Provide Your Medicare Insurance Information
            </h4>
            <div class="form-panel">
              <div class="form-group row">
                <div class="col-lg-6 col-md-5">
                  <p>
                    Please take out your red, white and blue Medicare card to
                    complete this section.
                  </p>

                  <ul class="list-type1">
                    <li>
                      Fill out this information as it appears on your Medicare
                      card.
                    </li>
                    <span>- OR -</span>
                    <li>
                      Attach a copy of your Medicare card or your letter from
                      Social Security or the Railroad Retirement Board.
                    </li>
                  </ul>
                </div>
                <div class="col-lg-6 col-md-7">
                  <div class="form-group row">
                    <div class="col-12">
                      <label for="nameOfBeneficiary" class="control-label">
                        Name (as it appears on your Medicare Card):
                      </label>
                      <input
                        type="text"
                        class="form-control"
                        name="nameBeneficiary"
                        id="nameOfBeneficiary"
                        placeholder="Print Name"
                        value={data.nameBeneficiary}
                        onChange={this.props.handleChange}
                      />
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-12">
                      <input
                        // type="text"
                        class="form-control readonly"
                        name="signature"
                        id="signature"
                        placeholder="Signature"
                        value={data.nameBeneficiary}
                        disabled="disabled"
                        //onChange={this.props.handleChange}
                      />
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-lg-8 col-md-7 col-sm-12">
                      <label
                        for="medicareClaimNo"
                        class="control-label"
                        id="medicareClaim"
                      >
                        Medicare Number<span class="mandatory">*</span>
                      </label>
                      <input
                        type="text"
                        placeholder="XXXXXXXXXXX"
                        pattern="/[a-zA-Z0-9]{10,11}/"
                        placeholder="XXXXXXXXXXX"
                        name="medicareClaim"
                        id="medicareClaim"
                        minlength="10"
                        maxlength="12"
                        class={
                          data.medicareClaim === "" ||
                          (data.medicareClaim && data.medicareClaim.length < 10)
                            ? "error-input"
                            : "form-control"
                        }
                        value={data.medicareClaim}
                        onChange={this.props.handleChange}
                        height={ie ? "37px" : "auto"}
                      />
                    </div>
                    <div
                      class={
                        ie
                          ? "col-lg-4 col-md-5 col-sm-12 iemargintop"
                          : "col-lg-4 col-md-5 col-sm-12"
                      }
                    >
                      <label class="control-label" for="medicareInfoSex">
                        Sex<span class="mandatory">*</span>
                      </label>
                      <select
                        style={{
                          borderRadius: "0",
                          paddingTop: "4px",
                          paddingBottom: "4px",
                          height: "37px",
                        }}
                        id="medicareInfoSex"
                        name="beneficiarySex"
                        class={
                          data.beneficiarySex === ""
                            ? "error-input"
                            : "form-control"
                        }
                        value={data.beneficiarySex}
                        onChange={this.props.handleChange}
                      >
                        <option>Select...</option>
                        <option>Male</option>
                        <option>Female</option>
                      </select>
                    </div>
                  </div>
                  <div class="mt-2 mb-2">
                    <strong>Is Entitled To</strong>
                  </div>
                  <div class="form-group row">
                    <div class="col-lg-6 col-md-6">
                      <label
                        class="control-label"
                        for="hospitalDate"
                        id="partA"
                      >
                        Hospital (Part A) Effective Date
                        <span class="mandatory">*</span>
                      </label>
                      <input
                        style={{
                          borderRadius: "0",
                          paddingTop: "4px",
                          paddingBottom: "4px",
                          height: "37px",
                        }}
                        placeholder="MM/DD/YYYY "
                        maxLength="10"
                        class={
                          data.hospitalDate === "" ||
                          !moment(
                            data.hospitalDate,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                        name="hospitalDate"
                        id="hospitalDate"
                        value={data.hospitalDate}
                        onChange={this.props.handleDate}
                        onClick={(e) => this.props.handleDates("hospitalDate")}
                      />
                    </div>
                    <div class="col-lg-6 col-md-6">
                      <label class="control-label" for="medicalDate" id="partB">
                        Medical (Part B) Effective Date
                        <span class="mandatory">*</span>
                      </label>
                      <input
                        style={{
                          borderRadius: "0",
                          paddingTop: "4px",
                          paddingBottom: "4px",
                          height: "37px",
                        }}
                        maxLength="10"
                        placeholder="MM/DD/YYYY "
                        class={
                          data.medicalDate === "" ||
                          !moment(
                            data.medicalDate,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                        name="medicalDate"
                        id="medicalDate"
                        value={data.medicalDate}
                        onChange={this.props.handleDate}
                        onClick={(e) => this.props.handleDates("medicalDate")}
                      />
                    </div>
                  </div>
                  <p class="mt-3">
                    ***** You must have Medicare Part A and Part B to join a
                    Medicare Advantage plan.
                  </p>
                </div>
              </div>
            </div>
            <button
              class="btnvap btn-primaryvap btn-save-n-next"
              id="step1"
              onClick={this.props.redirect}
            >
              Save &amp; Next
            </button>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    dropdowns: state.webApp.dropdowns,
  };
};
const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(Step1);
