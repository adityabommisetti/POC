import React, { Component } from "react";
import moment from "moment";
import { connect } from "react-redux";
import $ from "jquery";

const ie =
  navigator.userAgent.indexOf("MSIE") > -1 ||
  navigator.userAgent.indexOf("rv:") > -1;

const fire = navigator.userAgent.indexOf("Firefox") != -1;

class Step4 extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  async componentDidMount() {
    window.scroll(0, 0);
    
//   var currentDate = new Date();
    
//   var minDate = new Date('10/17/2020');
//   var maxDate =  new Date('12/07/2020');

//   if (currentDate > minDate && currentDate < maxDate ){
//      this.setState({isAep:true})
    
// }
// else{
//   this.setState({isAep:false})
// }
  }

  render() {
    const { data, disableCheck } = this.props;



    return (
      <React.Fragment>
        <div class="container tab-pane active">
          <h4 class="mb-2">
            Attestation of Eligibility for an Enrollment Period
          </h4>
          <p>
            <strong>
              Typically, you may enroll in a Medicare Advantage plan only during
              the annual enrollment period from October 15 through December 7 of
              each year.
            </strong>{" "}
            There are exceptions that may allow you to enroll in a Medicare
            Advantage plan outside of this period.
          </p>
          <p>
            Please read the following statements carefully and check the box if
            the statement applies to you. By checking any of the following boxes
            you are certifying that, to the best of your knowledge, you are
            eligible for an Enrollment Period. If we later determine that this
            information is incorrect, you may be disenrolled.
          </p>
          <ul class="list-group" id="step3_checklist">
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step4_chk2"
                  name="eligibleEnroll"
                  value={data.eligibleEnroll}
                  disabled={
                    disableCheck === false || data.eligibleEnroll === "E"
                      ? false
                      : true
                  }
                  checked={data.eligibleEnroll === "E" ? true : false}
                  onChange={this.props.handleCheckbox}
                />
                <label class="custom-control-label" for="step4_chk2">
                  <strong>I am new to Medicare.</strong>
                </label>
              </div>
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step4_chk2a"
                  name="mAOEPChange"
                  value={data.mAOEPChange}
                  disabled={
                    disableCheck === false || data.mAOEPChange === "Y"
                      ? false
                      : true
                  }
                  checked={data.mAOEPChange === "Y" ? true : false}
                  onChange={this.props.handleCheckbox}
                />
                <label class="custom-control-label" for="step4_chk2a">
                  <strong>
                    I am enrolled in a Medicare Advantage plan and want to make
                    a change during the Medicare Advantage Open Enrollment
                    Period (MA OEP).
                  </strong>
                </label>
              </div>
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step4_chk3"
                  name="trcntCreditChBox"
                  checked={
                    data.trcntCreditChBox === "recntCredit" ? true : false
                  }
                  onChange={this.props.handleCheckbox}
                  disabled={
                    disableCheck === false ||
                    data.trcntCreditChBox === "recntCredit"
                      ? false
                      : true
                  }
                  value={data.trcntCreditChBox}
                />
                <label class="custom-control-label" for="step4_chk3">
                  <strong>
                    I recently moved outside of the service area for my current
                    plan or I recently moved and this plan is a new option for
                    me.
                  </strong>
                </label>
                <br />{" "}
              </div>
              {data.trcntCreditChBox === "recntCredit" ? (
                <React.Fragment>
                  <div style={{ marginLeft: "2.5rem" }}>
                    <label for="imovedon">
                      I moved on (insert date)<span class="mandatory">*</span>
                      <input
                        style={{
                          borderRadius: "0",
                          paddingTop: "4px",
                          paddingBottom: "4px",
                          height: "37px",
                        }}
                        name="recentlyCreditable"
                        id="recentlyCreditable"
                        maxLength="10"
                        placeholder="MM/DD/YYYY"
                        value={data.recentlyCreditable}
                        class={
                          data.recentlyCreditable === "" ||
                          !moment(
                            data.recentlyCreditable,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                        onClick={(e) =>
                          this.props.handleDates("recentlyCreditable")
                        }
                        onChange={this.props.handleDate}
                      />
                    </label>
                  </div>
                </React.Fragment>
              ) : null}
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step4_chk4"
                  name="newElgbChBox"
                  disabled={
                    disableCheck === false || data.newElgbChBox === "newElgb"
                      ? false
                      : true
                  }
                  checked={data.newElgbChBox === "newElgb" ? true : false}
                  onChange={this.props.handleCheckbox}
                  value={data.newElgbChBox}
                />
                <label class="custom-control-label" for="step4_chk4">
                  <strong>I recently was released from incarceration.</strong>
                </label>
                <span style={{ marginleft: "20px" }}>
                  {data.newElgbChBox === "newElgb" ? (
                    <React.Fragment>
                      <label for="newlyEligbleMedicare">
                        I was released on (insert date)
                        <span class="mandatory">*</span>
                        <input
                          style={{
                            borderRadius: "0",
                            paddingTop: "4px",
                            paddingBottom: "4px",
                            height: "37px",
                          }}
                          name="newlyEligbleMedicare"
                          id="newlyEligbleMedicare"
                          maxLength="10"
                          placeholder="MM/DD/YYYY"
                          value={data.newlyEligbleMedicare}
                          class={
                            data.newlyEligbleMedicare === "" ||
                            !moment(
                              data.newlyEligbleMedicare,
                              "MM/DD/YYYY",
                              true
                            ).isValid()
                              ? "error-input"
                              : "form-control"
                          }
                          onClick={(e) =>
                            this.props.handleDates("newlyEligbleMedicare")
                          }
                          onChange={this.props.handleDate}
                        />
                      </label>
                    </React.Fragment>
                  ) : null}
                </span>
              </div>

              {/* {data.newElgbChBox === "newElgb" ? (
                <React.Fragment>
                  <label for="newlyEligbleMedicare">
                    I was released on (insert date)
                    <span class="mandatory">*</span>
                    <input
                      style={{
                        borderRadius: "0",
                        paddingTop: "4px",
                        paddingBottom: "4px",
                        height: "37px",
                      }}
                      name="newlyEligbleMedicare"
                      id="newlyEligbleMedicare"
                      maxLength="10"
                      placeholder="MM/DD/YYYY"
                      value={data.newlyEligbleMedicare}
                      class={
                        data.newlyEligbleMedicare === "" ||
                        !moment(
                          data.newlyEligbleMedicare,
                          "MM/DD/YYYY",
                          true
                        ).isValid()
                          ? "error-input"
                          : "form-control"
                      }
                      onClick={(e) =>
                        this.props.handleDates("newlyEligbleMedicare")
                      }
                      onChange={this.props.handleDate}
                    />
                  </label>
                </React.Fragment>
              ) : null} */}
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step4_chk5"
                  name="revMedChBox"
                  value={data.revMedChBox}
                  disabled={
                    disableCheck === false || data.revMedChBox === "revMed"
                      ? false
                      : true
                  }
                  checked={data.revMedChBox === "revMed" ? true : false}
                  onChange={this.props.handleCheckbox}
                />
                <label class="custom-control-label" for="step4_chk5">
                  <strong>
                    I recently returned to the United States after living
                    permanently outside of the U.S.
                  </strong>
                </label>
              </div>
              {data.revMedChBox === "revMed" ? (
                <React.Fragment>
                  <div style={{ marginLeft: "2.5rem" }}>
                    <label for="recieveMedicareDrugs">
                      I returned to the U.S. on (insert date)
                      <span class="mandatory">*</span>
                      <input
                        style={{
                          borderRadius: "0",
                          paddingTop: "4px",
                          paddingBottom: "4px",
                          height: "37px",
                        }}
                        name="recieveMedicareDrugs"
                        id="recieveMedicareDrugs"
                        maxLength="10"
                        placeholder="MM/DD/YYYY"
                        value={data.recieveMedicareDrugs}
                        class={
                          data.recieveMedicareDrugs === "" ||
                          !moment(
                            data.recieveMedicareDrugs,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                        onClick={(e) =>
                          this.props.handleDates("recieveMedicareDrugs")
                        }
                        onChange={this.props.handleDate}
                      />
                    </label>
                  </div>
                </React.Fragment>
              ) : null}
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step4_chk6"
                  name="levEmpChBox"
                  value={data.levEmpChBox}
                  disabled={
                    disableCheck === false || data.levEmpChBox === "levEmp"
                      ? false
                      : true
                  }
                  checked={data.levEmpChBox === "levEmp" ? true : false}
                  onChange={this.props.handleCheckbox}
                />
                <label class="custom-control-label" for="step4_chk6">
                  <strong>
                    I recently obtained lawful presence status in the United
                    States.
                  </strong>
                </label>
              </div>

              {data.levEmpChBox === "levEmp" ? (
                <React.Fragment>
                  <div style={{ marginLeft: "2.5rem" }}>
                    <label for="leavingEmployerCoverage">
                      I got this status on (insert date)
                      <span class="mandatory">*</span>
                      <input
                        style={{
                          borderRadius: "0",
                          paddingTop: "4px",
                          paddingBottom: "4px",
                          height: "37px",
                        }}
                        name="leavingEmployerCoverage"
                        id="leavingEmployerCoverage"
                        maxLength="10"
                        placeholder="MM/DD/YYYY"
                        value={data.leavingEmployerCoverage}
                        class={
                          data.leavingEmployerCoverage === "" ||
                          !moment(
                            data.leavingEmployerCoverage,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                        onClick={(e) =>
                          this.props.handleDates("leavingEmployerCoverage")
                        }
                        onChange={this.props.handleDate}
                      />
                    </label>
                  </div>
                </React.Fragment>
              ) : null}
            </li>

            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step4_chk7"
                  name="changeInMedicaidChBox"
                  value={data.changeInMedicaidChBox}
                  disabled={
                    disableCheck === false ||
                    data.changeInMedicaidChBox === "MCD"
                      ? false
                      : true
                  }
                  checked={
                    data.changeInMedicaidChBox === "MCD"
                      ? true
                      : false
                  }
                  onChange={this.props.handleCheckbox}
                />
                <label class="custom-control-label" for="step4_chk7">
                  <strong>
                    I recently had a change in my Medicaid (newly got Medicaid,
                    had a change in level of Medicaid assistance, or lost
                    Medicaid)
                  </strong>
                </label>
              </div>
              {data.changeInMedicaidChBox === "MCD" ? (
                <React.Fragment>
                  <div style={{ marginLeft: "2.5rem" }}>
                    <label for="recentlyChangeMedicaid">
                      (insert date)<span class="mandatory">*</span>
                      <input
                        style={{
                          borderRadius: "0",
                          paddingTop: "4px",
                          paddingBottom: "4px",
                          height: "37px",
                        }}
                        name="changeInMedicaid"
                        id="changeInMedicaid"
                        placeholder="MM/DD/YYYY"
                        maxLength="10"
                        value={data.changeInMedicaid}
                        class={
                          data.changeInMedicaid === "" ||
                          !moment(
                            data.changeInMedicaid,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                        onClick={(e) =>
                          this.props.handleDates("changeInMedicaid")
                        }
                        onChange={this.props.handleDate}
                      />
                    </label>
                  </div>
                </React.Fragment>
              ) : null}
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step4_chk8"
                  name="changeInExtraHelpChBox"
                  value={data.changeInExtraHelpChBox}
                  disabled={
                    disableCheck === false ||
                    data.changeInExtraHelpChBox === "changeInExtraHelp"
                      ? false
                      : true
                  }
                  checked={
                    data.changeInExtraHelpChBox === "changeInExtraHelp"
                      ? true
                      : false
                  }
                  onChange={this.props.handleCheckbox}
                />
                <label class="custom-control-label" for="step4_chk8">
                  <strong>
                    I recently had a change in my Extra Help paying for Medicare
                    prescription drug coverage (newly got Extra Help, had a
                    change in the level of Extra Help, or lost Extra Help)
                  </strong>
                </label>
              </div>
              {data.changeInExtraHelpChBox === "changeInExtraHelp" ? (
                <React.Fragment>
                  <div style={{ marginLeft: "2.5rem " }}>
                    <label for="changeInExtraHelp">
                      (insert date)<span class="mandatory">*</span>
                      <input
                        style={{
                          borderRadius: "0",
                          paddingTop: "4px",
                          paddingBottom: "4px",
                          height: "37px",
                        }}
                        name="changeInExtraHelp"
                        id="changeInExtraHelp"
                        maxLength="10"
                        placeholder="MM/DD/YYYY"
                        value={data.changeInExtraHelp}
                        class={
                          data.changeInExtraHelp === "" ||
                          !moment(
                            data.changeInExtraHelp,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                        onClick={(e) =>
                          this.props.handleDates("changeInExtraHelp")
                        }
                        onChange={this.props.handleDate}
                      />
                    </label>
                  </div>
                </React.Fragment>
              ) : null}
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step4_chk9"
                  disabled={
                    disableCheck === false ||
                    data.nlElgPrescChBox === "mpElgbPresc"
                      ? false
                      : true
                  }
                  name="nlElgPrescChBox"
                  value={data.nlElgPrescChBox}
                  checked={
                    data.nlElgPrescChBox === "mpElgbPresc" ? true : false
                  }
                  onChange={this.props.handleCheckbox}
                />
                <label class="custom-control-label" for="step4_chk9">
                  <strong>
                    I have both Medicare and Medicaid (or my state helps pay for
                    my Medicare premiums) or I get Extra Help paying for my
                    Medicare prescription drug coverage, but I haven't had a
                    change.
                  </strong>
                </label>
              </div>
            </li>

            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step4_chk10"
                  name="noElgbspseChBox"
                  value={data.noElgbspseChBox}
                  checked={
                    data.noElgbspseChBox === "noElgbspseChValue" ? true : false
                  }
                  onChange={this.props.handleCheckbox}
                  disabled={
                    disableCheck === false ||
                    data.noElgbspseChBox === "noElgbspseChValue"
                      ? false
                      : true
                  }
                />
                <label class="custom-control-label" for="step4_chk10">
                  <strong>
                    I am moving into, live in, or recently moved out of a
                    Long-Term Care Facility (for example, a nursing home or
                    long-term care facility).
                  </strong>
                </label>
              </div>

              {data.noElgbspseChBox === "noElgbspseChValue" ? (
                <React.Fragment>
                  <div style={{ marginLeft: "2.5rem" }}>
                    <label for="noEligSpecial">
                      I moved/will move into/out of the facility on (insert
                      date)<span class="mandatory">*</span>
                      <input
                        style={{
                          borderRadius: "0",
                          paddingTop: "4px",
                          paddingBottom: "4px",
                          height: "37px",
                        }}
                        name="noEligSpecial"
                        maxLength="10"
                        id="noEligSpecial"
                        placeholder="MM/DD/YYYY"
                        value={data.noEligSpecial}
                        class={
                          data.noEligSpecial === "" ||
                          !moment(
                            data.noEligSpecial,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                        onClick={(e) => this.props.handleDates("noEligSpecial")}
                        onChange={this.props.handleDate}
                      />
                    </label>
                  </div>
                </React.Fragment>
              ) : null}
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step4_chk11"
                  name="recntleftPlChBox"
                  value={data.recntleftPlChBox}
                  checked={
                    data.recntleftPlChBox === "recntLeftPlac" ? true : false
                  }
                  onChange={this.props.handleCheckbox}
                  disabled={
                    disableCheck === false ||
                    data.recntleftPlChBox === "recntLeftPlac"
                      ? false
                      : true
                  }
                />
                <label class="custom-control-label" for="step4_chk11">
                  <strong>I recently left a PACE program.</strong>
                </label>
                <span style={{ marginLeft: "20px" }}>
                  {data.recntleftPlChBox === "recntLeftPlac" ? (
                    <React.Fragment>
                      <label for="recntLeftPace">
                        I left PACE program on (insert date)
                        <span class="mandatory">*</span>
                        <input
                          style={{
                            borderRadius: "0",
                            paddingTop: "4px",
                            paddingBottom: "4px",
                            height: "37px",
                          }}
                          name="recntLeftPace"
                          id="recntLeftPace"
                          maxLength="10"
                          placeholder="MM/DD/YYYY"
                          value={data.recntLeftPace}
                          class={
                            data.recntLeftPace === "" ||
                            !moment(
                              data.recntLeftPace,
                              "MM/DD/YYYY",
                              true
                            ).isValid()
                              ? "error-input"
                              : "form-control"
                          }
                          onClick={(e) =>
                            this.props.handleDates("recntLeftPace")
                          }
                          onChange={this.props.handleDate}
                        />
                      </label>
                    </React.Fragment>
                  ) : null}
                </span>
              </div>
              {/* {data.recntleftPlChBox === "recntLeftPlac" ? (
                <React.Fragment>
                  <label for="recntLeftPace">
                    I left PACE program on (insert date)
                    <span class="mandatory">*</span>
                    <input
                      style={{
                        borderRadius: "0",
                        paddingTop: "4px",
                        paddingBottom: "4px",
                        height: "37px",
                      }}
                      name="recntLeftPace"
                      id="recntLeftPace"
                      maxLength="10"
                      placeholder="MM/DD/YYYY"
                      value={data.recntLeftPace}
                      class={
                        data.recntLeftPace === "" ||
                        !moment(
                          data.recntLeftPace,
                          "MM/DD/YYYY",
                          true
                        ).isValid()
                          ? "error-input"
                          : "form-control"
                      }
                      onClick={(e) => this.props.handleDates("recntLeftPace")}
                      onChange={this.props.handleDate}
                    />
                  </label>
                </React.Fragment>
              ) : null} */}
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step4_chk12"
                  name="mvdUsChBox"
                  value={data.mvdUsChBox}
                  disabled={
                    disableCheck === false || data.mvdUsChBox === "mvdUs"
                      ? false
                      : true
                  }
                  checked={data.mvdUsChBox === "mvdUs" ? true : false}
                  onChange={this.props.handleCheckbox}
                />
                <label class="custom-control-label" for="step4_chk12">
                  <strong>
                    I recently involuntarily lost my creditable prescription
                    drug coverage (coverage as good as Medicare's).
                  </strong>
                </label>
              </div>
              {data.mvdUsChBox === "mvdUs" ? (
                <React.Fragment>
                  <div style={{ marginLeft: "2.5rem" }}>
                    <label for="movedBackUs">
                      I lost my drug coverage on (insert date)
                      <span class="mandatory">*</span>
                      <input
                        style={{
                          borderRadius: "0",
                          paddingTop: "4px",
                          paddingBottom: "4px",
                          height: "37px",
                        }}
                        name="movedBackUs"
                        id="movedBackUs"
                        maxLength="10"
                        placeholder="MM/DD/YYYY"
                        value={data.movedBackUs}
                        class={
                          data.movedBackUs === "" ||
                          !moment(
                            data.movedBackUs,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                        onClick={(e) => this.props.handleDates("movedBackUs")}
                        onChange={this.props.handleDate}
                      />
                    </label>
                  </div>
                </React.Fragment>
              ) : null}
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step4_chk13"
                  name="unCovChBox"
                  checked={data.unCovChBox === "unCov" ? true : false}
                  onChange={this.props.handleCheckbox}
                  disabled={
                    disableCheck === false || data.unCovChBox === "unCov"
                      ? false
                      : true
                  }
                  value={data.unCovChBox}
                />
                <label class="custom-control-label" for="step4_chk13">
                  <strong>I am leaving employer or union coverage </strong>
                </label>
                <span style={{ marginLeft: "20px" }}>
                  {data.unCovChBox === "unCov" ? (
                    <React.Fragment>
                      <label for="unionCoverage">
                        I am leaving on (insert date)*
                        <input
                          style={{
                            borderRadius: "0",
                            paddingTop: "4px",
                            paddingBottom: "4px",
                            height: "37px",
                          }}
                          name="unionCoverage"
                          id="unionCoverage"
                          maxLength="10"
                          placeholder="MM/DD/YYYY"
                          value={data.unionCoverage}
                          class={
                            data.unionCoverage === "" ||
                            !moment(
                              data.unionCoverage,
                              "MM/DD/YYYY",
                              true
                            ).isValid()
                              ? "error-input"
                              : "form-control"
                          }
                          onClick={(e) =>
                            this.props.handleDates("unionCoverage")
                          }
                          onChange={this.props.handleDate}
                        />
                      </label>
                    </React.Fragment>
                  ) : null}
                </span>
              </div>

              {/* {data.unCovChBox === "unCov" ? (
                <React.Fragment>
                  <label for="unionCoverage">
                    I am leaving on (insert date)*
                    <input
                      style={{
                        borderRadius: "0",
                        paddingTop: "4px",
                        paddingBottom: "4px",
                        height: "37px",
                      }}
                      name="unionCoverage"
                      id="unionCoverage"
                      maxLength="10"
                      placeholder="MM/DD/YYYY"
                      value={data.unionCoverage}
                      class={
                        data.unionCoverage === "" ||
                        !moment(
                          data.unionCoverage,
                          "MM/DD/YYYY",
                          true
                        ).isValid()
                          ? "error-input"
                          : "form-control"
                      }
                      onClick={(e) => this.props.handleDates("unionCoverage")}
                      onChange={this.props.handleDate}
                    />
                  </label>
                </React.Fragment>
              ) : null} */}
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step4_chk14"
                  name="belongStatePharmacy"
                  disabled={
                    disableCheck === false || data.belongStatePharmacy === "B"
                      ? false
                      : true
                  }
                  checked={data.belongStatePharmacy === "B" ? true : false}
                  onChange={this.props.handleCheckbox}
                  value={data.belongStatePharmacy}
                />
                <label class="custom-control-label" for="step4_chk14">
                  <strong>
                    I belong to a pharmacy assistance program provided by my
                    state.
                  </strong>
                </label>
              </div>
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step4_chk15"
                  name="noneApplyMe"
                  disabled={
                    disableCheck === false || data.noneApplyMe === "N"
                      ? false
                      : true
                  }
                  value={data.noneApplyMe}
                  checked={data.noneApplyMe === "N" ? true : false}
                  onChange={this.props.handleCheckbox}
                />
                <label class="custom-control-label" for="step4_chk15">
                  <strong>
                    My plan is ending its contract with Medicare, or Medicare is
                    ending its contract with my plan.
                  </strong>
                </label>
              </div>
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step4_chk16"
                  name="changeInMedicareChBox"
                  value={data.changeInMedicareChBox}
                  disabled={
                    disableCheck === false ||
                    data.changeInMedicareChBox === "DIF"
                      ? false
                      : true
                  }
                  checked={
                    data.changeInMedicareChBox === "DIF"
                      ? true
                      : false
                  }
                  onChange={this.props.handleCheckbox}
                />
                <label class="custom-control-label" for="step4_chk16">
                  <strong>
                    I was enrolled in a plan by Medicare (or my state) and I
                    want to choose a different plan.{" "}
                  </strong>
                </label>
              </div>
              {data.changeInMedicareChBox === "DIF" ? (
                <div style={{ marginLeft: "2.5rem" }}>
                  <label for="changeInMedicare">
                    My enrollment in that plan started on (insert date)*
                    <input
                      style={{
                        borderRadius: "0",
                        paddingTop: "4px",
                        paddingBottom: "4px",
                        height: "37px",
                      }}
                      name="changeInMedicare"
                      id="changeInMedicare"
                      maxLength="10"
                      placeholder="MM/DD/YYYY"
                      value={data.changeInMedicare}
                      class={
                        data.changeInMedicare === "" ||
                        !moment(
                          data.changeInMedicare,
                          "MM/DD/YYYY",
                          true
                        ).isValid()
                          ? "error-input"
                          : "form-control"
                      }
                      onClick={(e) =>
                        this.props.handleDates("changeInMedicare")
                      }
                      onChange={this.props.handleDate}
                    />
                  </label>
                </div>
              ) : null}
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step4_chk17"
                  name="outLngTermFcSeeChBox"
                  checked={
                    data.outLngTermFcSeeChBox === "outLngTermFcSee"
                      ? true
                      : false
                  }
                  onChange={this.props.handleCheckbox}
                  disabled={
                    disableCheck === false ||
                    data.outLngTermFcSeeChBox === "outLngTermFcSee"
                      ? false
                      : true
                  }
                  value={data.outLngTermFcSeeChBox}
                />
                <label class="custom-control-label" for="step4_chk17">
                  <strong>
                    I was enrolled in a Special Needs Plan (SNP) but I have lost
                    the special needs qualification required to be in that plan.{" "}
                  </strong>
                </label>
              </div>
              {data.outLngTermFcSeeChBox === "outLngTermFcSee" ? (
                <React.Fragment>
                  <div style={{ marginLeft: "2.5rem" }}>
                    <label for="outLongTermFacility">
                      I was disenrolled from the SNP on (insert date)*
                      <input
                        style={{
                          borderRadius: "0",
                          paddingTop: "4px",
                          paddingBottom: "4px",
                          height: "37px",
                        }}
                        id="outLongTermFacility"
                        name="outLongTermFacility"
                        placeholder="MM/DD/YYYY"
                        maxLength="10"
                        value={data.outLongTermFacility}
                        onChange={this.props.handleDate}
                        onClick={(e) =>
                          this.props.handleDates("outLongTermFacility")
                        }
                        class={
                          data.outLongTermFacility === "" ||
                          !moment(
                            data.outLongTermFacility,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                      />
                    </label>
                  </div>
                </React.Fragment>
              ) : null}
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step4_chk18"
                  name="affectedByDisaster"
                  value={data.affectedByDisaster}
                  disabled={
                    disableCheck === false || data.affectedByDisaster === "Y"
                      ? false
                      : true
                  }
                  checked={data.affectedByDisaster === "Y" ? true : false}
                  onChange={this.props.handleCheckbox}
                />
                <label class="custom-control-label" for="step4_chk18">
                  <strong>
                    I was affected by an emergency or major disaster (as
                    declared by the Federal Emergency Management Agency (FEMA)
                    or by a Federal, state or local government entity. One of
                    the other statements here applied to me, but I was unable to
                    make my enrollment request because of the disaster.
                  </strong>
                </label>
              </div>
            </li>
          </ul>
          <p class="mt-3">
            If none of these statements applies to you or you’re not sure,
            please contact Virginia Premier at 1-833-280-1194 (TTY users should
            call 711) to see if you are eligible to enroll. We are open 8 am to
            8 pm, 7 days a week from October 1 to March 31. From April 1 through
            September 30, we are open Monday through Friday, 8 am to 8 pm. On
            certain holidays and weekends from April 1 through September 30,
            your call will be handled by our automated phone system.
          </p>

          <div class="card mb-4">
            <h3 class="card-header block-heading text-center">
              Applicant: Please do not complete the following sections,
              Agent/Broker: Please fill in ALL fields below
            </h3>
            <div class="panel">
              <div class="card-body">
                <div class="form-group row">
                  <div class="col-md-3 col-sm-12">
                    <label for="effectDateCoverage" class="control-label">
                      Coverage effective date:
                    </label>
                    <input
                      style={{
                        borderRadius: "0",
                        paddingTop: "4px",
                        paddingBottom: "4px",
                        height: "37px",
                      }}
                      //type="date"
                      class="form-control"
                      id="effectDateCoverage"
                      name="effectDateCoverage"
                      placeholder="MM/DD/YYYY"
                      onClick={(e) =>
                        this.props.handleDates("effectDateCoverage")
                      }
                      maxLength="10"
                      onChange={this.props.handleDate}
                      value={data.effectDateCoverage}
                      //value={this.props.data.effectDateCoverage}
                      // onChange={this.props.handleChange}
                    />{" "}
                  </div>
                  <div class="col-md-3 col-sm-12">
                    <label for="planIDNo" class="control-label">
                      PLAN ID #:
                    </label>
                    <input
                      type="text"
                      class="form-control"
                      id="planIDNo"
                      value={this.props.data.planId}
                      name="planId"
                      onChange={this.props.handleChange}
                    />{" "}
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-12">
                    <fieldset class="radio">
                      <div class="custom-control custom-radio custom-control-inline">
                        <input
                          type="radio"
                          class="custom-control-input"
                          id="iep_icep"
                          name="aep"
                          onChange={this.props.handleChange}
                          value="I"
                          checked={this.props.data.aep === "I"}
                          style={{ zIndex: -1 }}
                        
                        />
                        <label
                          style={{ cursor: "pointer" }}
                          class="radio-inline custom-control-label"
                          for="iep_icep"
                        >
                          IEP/ICEP
                        </label>
                      </div>

                      <div class="custom-control custom-radio custom-control-inline">
                        <input
                          type="radio"
                          class="custom-control-input"
                          id="aep"
                          name="aep"
                          onChange={this.props.handleChange}
                          value="A"
                          checked={this.props.data.aep === "A"}
                          style={{ zIndex: -1 }}
                        />
                        <label
                          style={{ cursor: "pointer" }}
                          class="radio-inline custom-control-label"
                          for="aep"
                        >
                          AEP
                        </label>
                      </div>
                      {/* <div class="custom-control custom-radio custom-control-inline">
                        <input
                          type="radio"
                          class="custom-control-input"
                          id="oep"
                          name="aep"
                          onChange={this.props.handleChange}
                          value="I"
                          checked={this.props.data.aep === "S"}
                        />
                        <label class="radio-inline custom-control-label" for="oep">
                          OEP
                        </label>
                      </div> */}
                      <div class="custom-control custom-radio custom-control-inline ">
                        <input
                          type="radio"
                          class="custom-control-input"
                          id="sep_type"
                          name="aep"
                          onChange={ this.props.handleChange}
                          value="S"
                          checked={this.props.data.aep === "S"}
                          style={{ zIndex: -1 }}
                         
                        />
                        <label
                          style={{ cursor: "pointer" }}
                          class="radio-inline custom-control-label ie2"
                          for="sep_type"
                        >
                          SEP(type):
                        </label>{" "}
                        <input
                          style={{
                            height: "32px",
                            marginTop: "12px",
                          }}
                          type="text"
                          class="form-control"
                        />
                      </div>
                      <div class="custom-control custom-radio custom-control-inline">
                        <input
                          type="radio"
                          class="custom-control-input"
                          id="not_eligible"
                          name="aep"
                          onChange={this.props.handleChange}
                          value="N"
                          checked={this.props.data.aep === "N"}
                          style={{ zIndex: -1 }}
                        />
                        <label
                          style={{ cursor: "pointer" }}
                          class="radio-inline custom-control-label"
                          for="not_eligible"
                        >
                          Not eligible
                        </label>
                      </div>
                    </fieldset>
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-md-6 col-sm-12">
                    <fieldset class="radio">
                      <legend>
                        I helped the applicant fill out this application.
                      </legend>
                      <div class="custom-control custom-radio custom-control-inline">
                        <input
                          type="radio"
                          name="ihelpedtofill"
                          id="ihelpedtofill_yes"
                          class="custom-control-input"
                          value="Yes"
                          onChange={this.props.handleChange}
                          checked={this.props.data.ihelpedtofill  === "Yes"}
                        />
                        <label
                          style={{ cursor: "pointer" }}
                          for="ihelpedtofill_yes"
                          class="radio-inline custom-control-label"
                        >
                          Yes
                        </label>
                      </div>
                      <div class="custom-control custom-radio custom-control-inline">
                        <input
                          type="radio"
                          name="ihelpedtofill"
                          id="ihelpedtofill_no"
                          class="custom-control-input"
                          value="No"
                          onChange={this.props.handleChange}
                          checked={this.props.data.ihelpedtofill  === "No"}
                        />
                        <label
                          style={{ cursor: "pointer" }}
                          for="ihelpedtofill_no"
                          class="radio-inline custom-control-label"
                        >
                          No
                        </label>
                      </div>
                    </fieldset>
                  </div>
                </div>
                <div class="form-group row">
                  <div
                    class="col-md-12 col-sm-12"
                    id="individualFace2FaceAppointment"
                  >
                    <fieldset class="radio">
                      <legend>
                        Was this an individual face-to-face appointment?
                      </legend>
                      <div class="custom-control custom-radio custom-control-inline">
                        <input
                          type="radio"
                          name="facetoface_appointment"
                          id="facetoface_appointment_yes"
                          class="custom-control-input"
                          value="Yes"
                          checked={data.facetoface_appointment === "Yes"}
                          onChange={this.props.handleChange}
                        />
                        <label
                          style={{ cursor: "pointer" }}
                          for="facetoface_appointment_yes"
                          class="radio-inline custom-control-label"
                        >
                          Yes
                        </label>
                      </div>
                      <div class="custom-control custom-radio custom-control-inline">
                        <input
                          type="radio"
                          name="facetoface_appointment"
                          id="facetoface_appointment_no"
                          class="custom-control-input"
                          value="No"
                          checked={data.facetoface_appointment === "No"}
                          onChange={this.props.handleChange}
                        />
                        <label
                          style={{ cursor: "pointer" }}
                          for="facetoface_appointment_no"
                          class="radio-inline custom-control-label"
                        >
                          No
                        </label>
                      </div>
                    </fieldset>
                  </div>
                  {this.props.data.facetoface_appointment === "Yes" ? (
                    <div class="col-md-12 col-sm-12" id="scopeOfAppointment">
                      <fieldset class="radio">
                        <legend>
                          If yes, how was a scope of appointment (SOA)
                          collected?
                        </legend>
                      </fieldset>
                      <div class="row">
                        {/* <div class="col-lg-3 col-md-5"> */}
                        <div class="custom-control custom-checkbox custom-control-inlinepaper ">
                          <input
                            type="checkbox"
                            class="custom-control-input"
                            id="scope_paper"
                            name="soaPaper"
                            checked={data.soaPaper === "Yes" ? true : false} 
                            onChange={this.props.handleCheckbox}
                          />
                          <label
                            class="custom-control-label"
                            for="scope_paper"
                            style={{ paddingLeft: "0px" }}
                          >
                            Paper
                          </label>
                          <span class="record">
                            <input
                              type="checkbox"
                              class="custom-control-input"
                              id="scope_recordedcall"
                              name="soaRecordedCall"
                              checked={data.soaRecordedCall  === "Yes" ? true : false} 
                              onChange={this.props.handleCheckbox}
                            />
                            <label
                              class="custom-control-label"
                              for="scope_recordedcall"
                              style={{ paddingLeft: "0px" }}
                            >
                              Recorded call
                            </label>
                          </span>

                          {/* </div> */}

                          {/* <div class="custom-control custom-checkbox custom-control-inline record">
                            <input
                              type="checkbox"
                              class="custom-control-input"
                              id="scope_recordedcall"
                            />
                            <label
                              class="custom-control-label"
                              for="scope_recordedcall"
                            >
                              Recorded call
                            </label>
                          </div> */}
                        </div>
                        <div class="col-md-3">
                          <input
                            placeholder="Date recorded"
                            required=""
                            style={{
                              borderRadius: "0",
                              paddingTop: "4px",
                              paddingBottom: "4px",
                              height: "37px",
                            }}
                            value={data.recordedDate}
                            onClick={(e) =>
                              this.props.handleDates("daterecorded")
                            }
                            maxLength="10"
                            onChange={this.props.handleDate}
                            name="daterecorded"
                            id="daterecorded"
                            class="form-control"
                          />
                        </div>
                        <div class="col-md-3">
                          <input
                            type="text"
                            name="timerecorded"
                            id="timerecorded"
                            class="form-control"
                            placeholder="Time recorded"
                            value={data.timerecorded}
                            maxLength={4}
                            onChange={this.props.handleChange}
                            style={{
                              borderRadius: "0",
                              paddingTop: "4px",
                              paddingBottom: "4px",
                              height: "37px",
                            }}
                          />
                        </div>
                        <span class="mt-1">EST. AM/PM</span>
                      </div>
                    </div>
                  ) : null}
                </div>
                <hr />
                <div class="ml-2">
                  <div class="form-group row align-items-flex-end">
                    <div class="col-md-8">
                      <div class="form-group row">
                        {this.props.dropdowns &&
                        this.props.dropdowns.agentList &&
                        this.props.dropdowns.agentList.length > 0 ? (
                          <div class="col-lg-6 ">
                            <label for="p-number" class="control-label">
                              Print Name
                            </label>
                            <input
                              style={{
                                borderRadius: "0",
                                paddingTop: "4px",
                                paddingBottom: "4px",
                                height: "37px",
                              }}
                              type="text"
                              class="form-control"
                              name="agentName"
                              id="p-number"
                              value={data.agentName.trim()}
                              list="items"
                              onChange={this.props.handleChange}
                            />
                            <datalist id="items">
                              {this.props.dropdowns.agentList.map((item) => {
                                console.log(item);
                                return <option value={item.name}></option>;
                              })}
                            </datalist>
                          </div>
                        ) : null}
                      </div>{" "}
                    </div>
                    {/* <div class="col-md-6">
                      <input
                        type="text"
                        class="form-control"
                        placeholder="Last Name"
                      />{" "}
                    </div> */}
                  </div>
                  <div class="form-group row">
                    <div class="col-md-6 col-md-6">
                      <label for="p-number" class="control-label">
                        Last Name:
                      </label>
                      <input
                        style={{
                          borderRadius: "0",
                          paddingTop: "4px",
                          paddingBottom: "4px",
                          height: "37px",
                        }}
                        //type="text"
                        disabled="disabled"
                        class="form-control"
                        placeholder="Last Name"
                        // value={data.name.trim()}
                      />{" "}
                    </div>

                    <div class="col-lg-6">
                      <label for="p-number" class="control-label">
                        Writing Agent Producer Number (P-Number):
                      </label>
                      <input
                        style={{
                          borderRadius: "0",
                          paddingTop: "4px",
                          paddingBottom: "4px",
                          height: "37px",
                        }}
                        // type="text"
                        class="form-control readonly"
                        name="name"
                        id="p-number"
                        value={data.agentId}
                        disabled="disabled"
                      />
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-lg-3 col-md-3">
                      <label for="phNum" class="control-label">
                        Phone:
                      </label>
                      <input
                        style={{
                          borderRadius: "0",
                          paddingTop: "4px",
                          paddingBottom: "4px",
                          height: "37px",
                        }}
                        // type="text"
                        disabled="disabled"
                        class="form-control readonly"
                        name="phNum"
                        id="phNum"
                        value={data.phNum}
                        readonly
                      />{" "}
                    </div>

                    <div class="col-lg-3 col-md-3">
                      <label for="agentFax" class="control-label">
                        Fax:
                      </label>
                      <br />
                      <input
                        style={{
                          borderRadius: "0",
                          paddingTop: "4px",
                          paddingBottom: "4px",
                          height: "37px",
                        }}
                        disabled="disabled"
                        //type="text"
                        class="form-control readonly"
                        name="agentFax"
                        id="agentFax"
                        value={data.agentFax}
                        readonly
                      />
                    </div>
                    <div class="col-lg-6 col-md-6">
                      <label for="email" class="control-label">
                        Email:
                      </label>
                      <input
                        style={{
                          borderRadius: "0",
                          paddingTop: "4px",
                          paddingBottom: "4px",
                          height: "37px",
                        }}
                        disabled="disabled"
                        //type="text"
                        class="form-control readonly"
                        name="email"
                        id="email"
                        value={data.email}
                        readonly
                      />{" "}
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-lg-6 col-md-6">
                      <label for="pcpCity" class="control-label">
                        Signature:
                      </label>
                      <input
                        style={{
                          borderRadius: "0",
                          paddingTop: "4px",
                          paddingBottom: "4px",
                          height: "37px",
                        }}
                        disabled="disabled"
                        //type="text"
                        class="form-control"
                        name="pcpCity"
                        id="pcpCity"
                        value={data.name ? data.name.trim() : ""}
                      />
                    </div>
                    <div class="col-lg-3 col-md-6">
                      <label for="applrecDate" class="control-label">
                        Application received date:
                      </label>
                      <br />
                      <input
                        style={{
                          borderRadius: "0",
                          paddingTop: "4px",
                          paddingBottom: "4px",
                          height: "37px",
                        }}
                        // type="date"
                        placeholder="MM/DD/YYYY"
                        class="form-control"
                        name="applrecDate"
                        id="applrecDate"
                        maxLength="10"
                        value={data.applrecDate}
                        onClick={(e) => this.props.handleDates("applrecDate")}
                        onChange={this.props.handleDate}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="form-group row mt-3">
            <div class="col-md-8">
              {this.props.submitForm ? (
                <span
                  class="small text-danger"
                  style={{ fontSize: "15px !important" }}
                >
                  <strong>
                    We're missing a few pieces of information. Please check
                    steps 1-4 for red highlighted fields. When all required
                    information has been entered, the submit button will enable
                  </strong>
                </span>
              ) : (
                <span class="small text-success">
                  <strong>
                    Congratulations! Your Medicare form is complete, please
                    press SUBMIT to finish.
                  </strong>
                </span>
              )}
            </div>

            <div class="col-md-4 text-right">
              <button
                class={
                  this.props.submitForm
                    ? "btn btn-secondary"
                    : "btnvap btn-primaryvap"
                }
                disabled={this.props.submitForm}
                onClick={this.props.submitData}
              >
                Submit
              </button>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    dropdowns: state.webApp.dropdowns,
  };
};
const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(Step4);
