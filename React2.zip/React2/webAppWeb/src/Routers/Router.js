import React from "react";
import { Router, Redirect, Route, Switch } from "react-router-dom";
import EnrollSteps from "../components/enrollSteps.jsx";
import UserCreation from "../components/UserCreation.jsx";
import YearSelection from "../components/YearSelection.jsx";
import UserLogin from "../components/UserLogin";
import PlanSelection from "../components/PlanSelection";
import history from "../Utils/History";
import PreEnrollForm from "../components/PreEnrollForm";
import Confirmation from "../components/Confirmation";
import ForgotPassword from "../components/ForgotPassword";
import ResetPassword from "../components/ResetPassword";
import IndyUserCreation from "../indy_components/UserCreation";
import IndyYearSelection from "../indy_components/YearSelection";
import IndyUserLogin from "../indy_components/LoginForm";
import IndyPlanSelection from "../indy_components/PlanSelection";

import IndyPreEnroll from "../indy_components/PreEnroll";
import IndyExhibit from "../indy_components/exhibit";
import IndyConfirmation from "../indy_components/Confirmation";
import VAPPreEnroll from "../vap_components/vap_preenroll";
import LandingPage from "../vap_components/Landingpage";
import VAPConfirmation from "../vap_components/vap_Confirmation";
import DownloadForm from "../download/DownloadForm";

import "../assests/css/style.css";
import "../assests/css/bstyle.css";
const WebAppRouter = () => {
  let path = "";
  let email = "";
  const url = window.location.href;

  if (url.includes("/webapp/resetpassword/")) {
    email = url.split("resetpassword/")[1];

    path = `/webapp/resetpassword/${email}`;
  }

  return (
    <React.Fragment>
      <Router history={history} forceRefresh={true}>
        <Switch>
          <Route
            exact
            path="/webapp/Sharp/Individual/enrollSteps"
            render={() => <EnrollSteps />}
          />
          <Route
            path="/webapp/Sharp/Individual/userCreation"
            render={() => <UserCreation />}
            component={UserCreation}
          />
          <Route
            path="/webapp/Sharp/Individual/yearSelectionGuest"
            render={() => <YearSelection />}
          />
          <Route
            path="/webapp/Sharp/Individual/yearSelection"
            render={() => <YearSelection />}
          />
          <Route
            path="/webapp/Sharp/Individual/userLogin"
            render={() => <UserLogin />}
          />
          <Route
            path="/webapp/Sharp/Individual/selectedPlans"
            render={() => <PlanSelection />}
          />
          <Route
            path="/webapp/Sharp/Individual/enrollOnline"
            render={() => <PreEnrollForm />}
            component={PreEnrollForm}
          />
          <Route
            path="/webapp/Sharp/Individual/Confirmation"
            render={() => <Confirmation />}
            component={Confirmation}
          />
          <Route
            path="/webapp/Sharp/Individual/userPwdReset"
            render={() => <ForgotPassword />}
            component={ForgotPassword}
          />
          {path.length > 0 ? (
            <Route path={path} render={() => <ResetPassword email={email} />} />
          ) : null}

          <Route
            path="/webapp/IndyHealth/userCreation"
            render={() => <IndyUserCreation />}
            component={IndyUserCreation}
          />

          <Route
            path="/webapp/IndyHealth/yearSelectionGuest"
            render={() => <IndyYearSelection />}
          />
          <Route
            path="/webapp/IndyHealth/yearSelection"
            render={() => <IndyYearSelection />}
          />
          <Route
            path="/webapp/IndyHealth/exhibit"
            render={() => <IndyExhibit />}
          />
          <Route
            path="/webapp/IndyHealth/selectedPlans"
            render={() => <IndyPlanSelection />}
          />
          <Route
            path="/webapp/IndyHealth/enrollOnline"
            render={() => <IndyPreEnroll />}
            component={IndyPreEnroll}
          />
          <Route
            path="/webapp/IndyHealth/userLogin"
            render={() => <IndyUserLogin />}
          />

          <Route
            path="/webapp/IndyHealth/Confirmation"
            render={() => <IndyConfirmation />}
            component={IndyConfirmation}
          />
          <Route
            path="/webapptest/VAP/Confirmation"
            render={() => <VAPConfirmation />}
            component={VAPConfirmation}
          />
          <Route
            path="/webapptest/VAP/PreEnroll"
            render={() => <VAPPreEnroll />}
            component={VAPPreEnroll}
          />
          <Route
            path="/webapptest/VAP/LandingPage"
            render={() => <LandingPage />}
            component={LandingPage}
          />

          <Route
            path="/webapptest/VAP/Confirmation"
            render={() => <VAPConfirmation />}
            component={VAPConfirmation}
          />
          <Route
            path="/webapp/IndyHealth/showPdfApplicationForm"
            render={() => <DownloadForm />}
          />
          <Route
            path="/webapp/Sharp/showPdfApplicationForm"
            render={() => <DownloadForm />}
          />
          <Route
            path="/webapptest/Vap/showPdfApplicationForm"
            render={() => <DownloadForm />}
          />

          {<Redirect from="/" to="/webapptest/VAP/LandingPage" />}

          {/*<Redirect from="/" to="/webapp/IndyHealth/showPdfApplicationForm" />*/}
          {/*<Redirect from="/" to="/webapp/Sharp/showPdfApplicationForm" />*/}
          {/*<Redirect from="/" to="/webapp/Vap/showPdfApplicationForm" />*/}

          {/* <Redirect from="/" to="/webapp/IndyHealth/userCreation" /> */}

          {/* <Redirect from="/" to="/webapp/Sharp/Individual/enrollSteps" /> */}
        </Switch>
      </Router>
    </React.Fragment>
  );
};
export default WebAppRouter;
