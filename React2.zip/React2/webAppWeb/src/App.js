import React from "react";
import Router from "./Routers/Router";
import "./App.css";
import "./assests/css/spinner.css";
import { connect } from "react-redux";
import Header from "./components/Header";
import history from "./Utils/History";
import HeaderIndy from "./indy_components/Header";
import Footer from "./indy_components/Footer";
import logo from "../src/assests/images/IH-InsuranceCo-logo.png";

const App = (props) => {
  let value = window.location.href.toString().indexOf("Sharp");
  let value1 = window.location.href.toString().indexOf("Indy");
  let search = window.location.search;
  let value2 = window.location.href.toString().indexOf("VAP");

  return value > -1 ? (
    <React.Fragment>
      <title> WebApp Sharp Health Plan</title>

      <div className="App">
        {props.isLoading ? <div id="cover-spin" /> : null}
        <Header />
        <Router />
      </div>
    </React.Fragment>
  ) : value1 > -1 ? (
    <React.Fragment>
      <title> Indy Health</title>

      {props.isLoading ? <div id="cover-spin" /> : null}

      <HeaderIndy />

      <Router />
      <Footer />
    </React.Fragment>
  ) : search || sessionStorage.getItem("landing", true) ? (
    <React.Fragment>
      <title> Virginia Premier</title>

      {props.isLoading ? <div id="cover-spin" /> : null}
      <div
        class="hfeed site"
        id="page"
        style={{
          fontFamily: "Opens Sans,  Helvetia, Arial, sans-serif  !important",
        }}
      >
        <Router />
      </div>
    </React.Fragment>
  ) : (
    <div className="jumbotron">
      <div id="main">
        <div class="fof">
          <h1>Error 404</h1>
        </div>
      </div>
    </div>
  );
};
const mapStateToProps = (state) => {
  return {
    isLoading: state.spinner.isLoading,
  };
};
export default connect(mapStateToProps)(App);
