import React, { Component } from "react";
import { compose } from "redux";
import SimpleReactValidator from "simple-react-validator";
import CUSTOMER_LOGO from "../Utils/StaticData/staticHeader";
import Step1 from "./Step1.jsx";
import Step2_2021 from "./Step2.jsx";
import Step2Category1 from "./step2/Step2Category1.jsx";
import Step2Category2 from "./step2/Step2Category2.jsx";
import Step2Category3 from "./step2/Step2Category3.jsx";
import Step3 from "./Step3.jsx";
import Step4 from "./Step4.jsx";
import StepsFooter from "./stepsFooter";
import { INITIAL_STATE } from "./initialState";
import { connect } from "react-redux";
import LinearProgress from "@material-ui/core/LinearProgress";
import { withStyles } from "@material-ui/core/styles";
import Footer1 from "../Utils/GenericUI/Footer1";
import Footer2 from "../Utils/GenericUI/Footer2";
import * as DateUtil from "../Utils/DatePicker";
import { handleDateChange } from "../Utils/DateFormatter";
import {
  saveLogout,
  submitForm,
  getClinicalName,
  removeplan,
} from "../Redux/Actions/webAppActions";
import history from "../Utils/History";
import moment from "moment";
const styles = (props) => ({
  progressComplete: {
    backgroundColor: "#00695C",
  },
  root: {
    height: "20px",
  },
  progressIncomplete: {
    backgroundColor: "#b8880c",
  },
});
let test = false;
class PreEnrollForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      stepVal: "step1",
      data:
        Object.keys(this.props.preEnrollInfo).length === 0
          ? { ...INITIAL_STATE }
          : this.props.preEnrollInfo,
      disableCheck: false,
      physicians: this.props.physicians,
      authorizedrelations: this.props.authorizedrelations,
      selectedPlan: "",
      checkName: "",
    };
    this.validator = new SimpleReactValidator();
  }

  unload = () => {
    console.log("page unloaded");
  };

  async componentDidMount() {
    window.scroll(0, 0);
    window.onbeforeunload = function () {
      return "";
    }.bind(this);
    console.log("onLoad");
    console.log(this.props.year);
    console.log(this.props.selectedPlan);

    if (this.props.year === "" || this.props.selectedPlan === "") {
      history.push("/webapp/Sharp/Individual/userCreation");
    }
    if (
      this.props.year === "2021" &&
      (this.props.selectedPlan === "SDAGCWD20" ||
        this.props.selectedPlan === "SDAGC20" ||
        this.props.selectedPlan === "SDAPC20")
    ) {
      await this.setState((prevState) => ({
        data: {
          ...prevState.data,
          emailAlert: "N",
        },
      }));
    }
    let data = this.state.data;
    if (data) {
      if (
        data.c1 !== "" ||
        data.c2 !== "" ||
        data.c3 !== "" ||
        data.c4 !== "" ||
        data.c5 !== "" ||
        data.c6 !== "" ||
        data.c7 !== "" ||
        data.c8 !== "" ||
        data.c9 !== "" ||
        data.c10 !== "" ||
        data.c11 !== "" ||
        data.c12 !== "" ||
        data.c13 !== "" ||
        data.c14 !== "" ||
        data.c15 !== "" ||
        data.c16 !== "" ||
        data.c22 !== "" ||
        data.aep !== ""
      ) {
        await this.setState({ disableCheck: true });
      }
    }
    await this.setState({ selectedPlan: this.props.selectedPlan });
  }

  componentWillUnmount() {
    window.removeEventListener("beforeunload", this.onUnload);
  }

  handleSteps = async (event) => {
    let value = event.target ? event.target.id : event.id;
    if (value) {
      await this.setState({ stepVal: value });
    }
  };
  handleDates = (fieldId) => {
    var self = this;
    DateUtil.getDatePicker("#" + fieldId).datepicker("show");
    DateUtil.getDatePicker("#" + fieldId).on("change", (e) => {
      this.setDates(fieldId, e.target.value);
    });
  };

  setDates = async (fieldId, value) => {
    await this.setState({ data: { ...this.state.data, [fieldId]: value } });
  };
  handleCheckbox = async (event) => {
    let name = event.target.name;
    let value = event.target.checked;
    let save = "";

    if (name === "mailingAddressRequired") {
      value = event.target.checked ? "YES" : "";
    }

    if (name === "aep") {
      value = event.target.checked ? "AEP" : "";
      save = name;
    }
    if (name === "c1") {
      value = event.target.checked ? "NEW" : "";
      save = name;
    }
    if (name === "c2") {
      value = event.target.checked ? "MOV" : "";
      save = name;

      if (value === "") {
        await this.setState({ data: { ...this.state.data, attestation2: "" } });
      }
    }
    if (name === "c3") {
      value = event.target.checked ? "INC" : "";
      save = name;
      if (value === "") {
        await this.setState({ data: { ...this.state.data, attestation3: "" } });
      }
    }
    if (name === "c4") {
      value = event.target.checked ? "RUS" : "";
      save = name;
      if (value === "") {
        await this.setState({ data: { ...this.state.data, attestation4: "" } });
      }
    }
    if (name === "c5") {
      value = event.target.checked ? "LAW" : "";
      save = name;
      if (value === "") {
        await this.setState({ data: { ...this.state.data, attestation5: "" } });
      }
    }
    if (name === "c6") {
      value = event.target.checked ? "MDE" : "";
      save = name;
    }
    if (name === "c8") {
      value = event.target.checked ? "NLS" : "";
      save = name;
      if (value === "") {
        await this.setState({ data: { ...this.state.data, attestation8: "" } });
      }
    }
    if (name === "c9") {
      value = event.target.checked ? "LTC" : "";
      save = name;
      if (value === "") {
        await this.setState({ data: { ...this.state.data, attestation9: "" } });
      }
    }
    if (name === "c10") {
      value = event.target.checked ? "PAC" : "";
      save = name;
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, attestation10: "" },
        });
      }
    }
    if (name === "c11") {
      value = event.target.checked ? "LCC" : "";
      save = name;
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, attestation11: "" },
        });
      }
    }
    if (name === "c12") {
      value = event.target.checked ? "LEC" : "";
      save = name;
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, attestation12: "" },
        });
      }
    }
    if (name === "c13") {
      value = event.target.checked ? "PAP" : "";
      save = name;
    }
    if (name === "c14") {
      value = event.target.checked ? "EOC" : "";
      save = name;
    }
    if (name === "c15") {
      value = event.target.checked ? "SNP" : "";
      save = name;
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, attestation15: "" },
        });
      }
    }
    if (name === "c22") {
      value = event.target.checked ? "MCD" : "";
      save = name;
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, recentlyChangeMedicaid: "" },
        });
      }
    }
    if (name === "c25") {
      value = event.target.checked ? "DST" : "";
      save = name;
    }
    if (name === "c7") {
      value = event.target.checked ? "HLP" : "";
      save = name;
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, attestation7: "" },
        });
      }
    }
    if (name === "c16") {
      value = event.target.checked ? "OTH" : "";
      save = name;
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, c16Attestation: "", attestation16: "" },
        });
      }
    }

    await this.setState({
      data: { ...this.state.data, [name]: value },
      checkName: save,
    });

    if (value === "") {
      await this.setState({ disableCheck: false });
    } else {
      await this.setState({ disableCheck: true });
      test = true;
    }
  };

  submitData = async () => {
    let productId = "";
    let pbpId = "";

    let selectedPlan = this.state.selectedPlan;
    if (selectedPlan === "SDAGC20") {
      productId = "IN1C";
      pbpId = "003";
    }
    if (selectedPlan === "SDAGCWD20") {
      productId = "IN1D";
      pbpId = "003";
    }
    if (selectedPlan === "SDAPC20") {
      productId = "IN2C";
      pbpId = "004";
    }
    if (selectedPlan === "SDAB20") {
      productId = "SH01";
      pbpId = "801";
    }
    if (selectedPlan === "SDABWD20") {
      productId = "SH1A";
      pbpId = "801";
    }
    if (selectedPlan === "SDAP20") {
      productId = "SH03";
      pbpId = "801";
    }
    if (selectedPlan === "SDAPWD20") {
      productId = "SH2B";
      pbpId = "801";
    }
    if (selectedPlan === "SDAHMO1" || selectedPlan === "SDAHMO20") {
      productId = "ME02";
      pbpId = "802";
    }

    let payload = {
      ...this.state.data,
      productId: productId,
      pbpId: pbpId,
    };
    const response = await this.props.submitForm(payload);

    if (response.message === "SUCCESS") {
      history.push("/webapp/Sharp/Individual/Confirmation");
    } else {
      alert("Submission Failed");
    }
  };

  saveData = async () => {
    const response = await this.props.saveLogout(this.state.data);

    if (response.data === "Enrollment form saved successfully") {
      await this.props.removeplan();
      history.push("/webapp/Sharp/Individual/userCreation");
    } else {
      alert("Save Failed");
    }
  };

  redirect = async (event) => {
    let id = event.target.id;

    if (id === "next2") {
      await this.setState({ stepVal: "step3" });
    }
    if (id === "next1") {
      await this.setState({ stepVal: "step2" });
    }
    if (id === "next3") {
      await this.setState({ stepVal: "step4" });
    }
    if (id === "next4") {
      await this.setState({ stepVal: "step1" });
    }
  };
  formatPhoneNumber = (phoneNumberString) => {
    var match = phoneNumberString.match(/^(\d{3})(\d{3})(\d{4})$/);
    if (match) {
      return "(" + match[1] + ") " + match[2] + "-" + match[3];
    }
    return phoneNumberString;
  };
  handleNumberChange = (event) => {
    let name = event.target.name;
    let value = event.target.value;
    value = value.replace(/[^0-9]/g, "");

    this.setState({ data: { ...this.state.data, [name]: value } });
  };

  handleDate = async (event) => {
    let name = event.target.name;
    let value = event.target.value;
    value = handleDateChange(value);
    await this.setState({
      data: { ...this.state.data, [name]: value },
    });
  };
  handleChange = (event) => {
    let name = event.target.name;
    let value = event.target.value;

    if (name.toLowerCase().includes("phone")) {
      value = this.formatPhoneNumber(value.replace(/[^0-9]/g, ""));
    }

    if (event.target.type === "checkbox" && name !== "language") {
      value = event.target.checked ? "Y" : "N";
    }

    if (name === "renalDisease" && value === "N") {
      this.setState({
        data: { ...this.state.data, [name]: value, esrdcontact: "" },
      });
      return;
    }

    if (name === "vaBenefits" && value === "N") {
      this.setState({
        data: {
          ...this.state.data,
          [name]: value,
          nameOfCov: "",
          idOfCov: "",
          groupOfCov: "",
        },
      });
      return;
    }

    if (name === "medicaidprg" && value === "N") {
      this.setState({
        data: { ...this.state.data, [name]: value, medicaidNbr: "" },
      });
      return;
    }
    if (name === "prescriptionDrug" && value === "N") {
      this.setState({
        data: {
          ...this.state.data,
          [name]: value,
          nameOfInst: "",
          phoneOfInst: "",
          addrOfInst: "",
        },
      });
      return;
    }
    if (name === "retiree" && value === "N") {
      this.setState({
        data: {
          ...this.state.data,
          [name]: value,
          retiredate: "",
          coveringSpouseOrDependent: "",
          coveringSpouseOrDependentEmployeeName: "",
          coveringSpouseOrDependentMiddleName: "",
          coveringSpouseOrDependentFirstName: "",
          coveringSpouseOrDependentLastName: "",
        },
      });
      return;
    }
    if (name === "retiree" && value === "Y") {
      this.setState({
        data: {
          ...this.state.data,
          [name]: value,
          retirename: "",
          survivingSpouseCitySanDiegoRetiree: "",
          survivingSpouseCitySanDiegoRetireeLastName: "",
          survivingSpouseCitySanDiegoRetireeFirstName: "",
          survivingSpouseCitySanDiegoRetireeMiddleName: "",
        },
      });
      return;
    }

    if (name === "coveringSpouseOrDependent" && value === "Y") {
      this.setState({
        data: {
          ...this.state.data,
          [name]: value,
          coveringSpouseOrDependentEmployeeName: "",
        },
      });
      return;
    }
    if (name === "coveringSpouseOrDependent" && value === "N") {
      this.setState({
        data: {
          ...this.state.data,
          [name]: value,
          coveringSpouseOrDependentMiddleName: "",
          coveringSpouseOrDependentFirstName: "",
          coveringSpouseOrDependentLastName: "",
        },
      });
      return;
    }
    if (name === "coveringSpouseOrDependentEmployeeName" && value === "N") {
      this.setState({
        data: {
          ...this.state.data,
          [name]: value,
          survivingSpouseCitySanDiegoRetireeLastName: "",
          survivingSpouseCitySanDiegoRetireeFirstName: "",
          survivingSpouseCitySanDiegoRetireeMiddleName: "",
        },
      });
      return;
    }
    if ((name === "empCover" || name === "meddependsp") && value === "N") {
      this.setState({
        data: {
          ...this.state.data,
          [name]: value,
          dependentSpouse: "",
          dependentOther: "",
        },
      });
      return;
    }

    this.setState({ data: { ...this.state.data, [name]: value } });
  };
  pcpChange = async (event) => {
    const name = event.target.name;
    const value = event.target.value;
    const plan = this.state.selectedPlan;

    if (plan !== "SDAHMO1") {
      const data = await this.props.getClinicalName(value);

      this.setState({
        data: {
          ...this.state.data,
          [name]: value,
          pcpMedicalGroupName: data.data,
        },
      });
    } else {
      this.setState({
        data: {
          ...this.state.data,
          [name]: value,
        },
      });
    }
  };
  render() {
    const { data, selectedPlan, year } = this.state;
    console.log(selectedPlan);
    let progress = "";
    if (
      year === "2021" &&
      (selectedPlan === "SDAGCWD20" ||
        selectedPlan === "SDAGC20" ||
        selectedPlan === "SDAPC20")
    ) {
      let count = 30;
      console.log(
        !this.validator.check(data.emailAddr, "email") ||
          !data.emailAddr.endsWith(".com") ||
          !data.emailAddr !== ""
      );

      const progress1 = data.firstName === "" ? 0 : 1;
      const progress2 = data.lastName === "" ? 0 : 1;
      const progress3 =
        data.birthDate === "" ||
        !moment(data.birthDate, "MM/DD/YYYY", true).isValid()
          ? 0
          : 1;
      console.log(progress3);
      const progress4 = data.primaryPhone === "" ? 0 : 1;
      const progress5 = data.permanentAddrStreet === "" ? 0 : 1;
      const progress6 = data.permanentCity === "" ? 0 : 1;

      const progress7 =
        data.emailAddr === "" ||
        !this.validator.check(data.emailAddr, "email") ||
        !data.emailAddr.endsWith(".com")
          ? 0
          : 1;

      console.log(data.emailAddr === "");
      console.log(!this.validator.check(data.emailAddr, "email"));
      console.log(!data.emailAddr.endsWith(".com"));
      console.log(progress7);

      // const progress7 =
      //   (!this.validator.check(data.emailAddr, "email")||
      //   !data.emailAddr.endsWith(".com") ) &&
      //   data.emailAddr == ""
      //     ? 0
      //     : 1;
      const progress8 = data.permanentZip === "" ? 0 : 1;
      const progress9 = data.sex === "" ? 0 : 1;
      const progress10 = data.medicareClaim === "" ? 0 : 1;
      const progress11 = data.pcpName === "" ? 0 : 1;
      const progress12 = data.pcpMedicalGroupName === "" ? 0 : 1;
      const progress13 = data.nameSignature === "" ? 0 : 1;

      const progress14 =
        data.AuthorizedRep === "Y" && data.authorizedrepname !== "" ? 1 : 0;
      const progress15 =
        data.AuthorizedRep === "Y" && data.authorizedreprelationship !== ""
          ? 1
          : 0;
      const progress16 =
        data.AuthorizedRep === "Y" && data.authorizedrepaddress !== "" ? 1 : 0;
      const progress17 =
        data.AuthorizedRep === "Y" && data.authorizedrepphone !== "" ? 1 : 0;
      const progress18 =
        data.AgentAssistingEnrollment === "Y" && data.nameAgent !== "" ? 1 : 0;

      const progress19 = data.c2 === "MOV" && data.attestation2 !== "" ? 1 : 0;
      const progress20 = data.c3 === "INC" && data.attestation3 !== "" ? 1 : 0;
      const progress21 = data.c4 === "RUS" && data.attestation4 !== "" ? 1 : 0;
      const progress22 = data.c5 === "LAW" && data.attestation5 !== "" ? 1 : 0;
      const progress23 = data.c8 === "NLS" && data.attestation8 !== "" ? 1 : 0;
      const progress24 = data.c9 === "LTC" && data.attestation9 !== "" ? 1 : 0;
      const progress25 =
        data.c10 === "PAC" && data.attestation10 !== "" ? 1 : 0;
      const progress26 =
        data.c11 === "LCC" && data.attestation11 !== "" ? 1 : 0;
      const progress27 =
        data.c12 === "LEC" && data.attestation12 !== "" ? 1 : 0;
      const progress28 =
        data.c15 === "SNP" && data.attestation15 !== "" ? 1 : 0;
      const progress29 =
        data.c22 === "MCD" && data.recentlyChangeMedicaid !== "" ? 1 : 0;
      const progress30 = data.c7 === "HLP" && data.attestation7 !== "" ? 1 : 0;

      if (
        (data.attestation2 === "" ||
          !moment(data.attestation2, "MM/DD/YYYY", true).isValid()) &&
        (data.attestation3 === "" ||
          !moment(data.attestation3, "MM/DD/YYYY", true).isValid()) &&
        (data.attestation4 === "" ||
          !moment(data.attestation4, "MM/DD/YYYY", true).isValid()) &&
        (data.attestation5 === "" ||
          !moment(data.attestation5, "MM/DD/YYYY", true).isValid()) &&
        (data.attestation8 === "" ||
          !moment(data.attestation8, "MM/DD/YYYY", true).isValid()) &&
        (data.attestation9 === "" ||
          !moment(data.attestation9, "MM/DD/YYYY", true).isValid()) &&
        (data.attestation10 === "" ||
          !moment(data.attestation10, "MM/DD/YYYY", true).isValid()) &&
        (data.attestation11 === "" ||
          !moment(data.attestation11, "MM/DD/YYYY", true).isValid()) &&
        (data.attestation12 === "" ||
          !moment(data.attestation12, "MM/DD/YYYY", true).isValid()) &&
        (data.attestation15 === "" ||
          !moment(data.attestation15, "MM/DD/YYYY", true).isValid()) &&
        (data.recentlyChangeMedicaid === "" ||
          !moment(data.recentlyChangeMedicaid, "MM/DD/YYYY", true).isValid()) &&
        (data.attestation7 === "" ||
          !moment(data.attestation7, "MM/DD/YYYY", true).isValid())
      ) {
        count -= 12;
      } else {
        count -= 11;
      }
      if (data.AuthorizedRep !== "Y") count -= 4;
      if (data.AgentAssistingEnrollment !== "Y") count -= 1;
      progress =
        ((progress1 +
          progress2 +
          progress3 +
          progress4 +
          progress5 +
          progress6 +
          progress7 +
          progress8 +
          progress9 +
          progress10 +
          progress11 +
          progress12 +
          progress13 +
          progress14 +
          progress15 +
          progress16 +
          progress17 +
          progress18 +
          progress19 +
          progress20 +
          progress21 +
          progress22 +
          progress23 +
          progress24 +
          progress25 +
          progress26 +
          progress27 +
          progress28 +
          progress29 +
          progress30) /
          count) *
        100;
    } else {
      let count = 30;

      const progress1 = data.firstName === "" ? 0 : 1;
      const progress2 = data.lastName === "" ? 0 : 1;
      const progress3 =
        data.birthDate === "" ||
        !moment(data.birthDate, "MM/DD/YYYY", true).isValid()
          ? 0
          : 1;
      const progress4 = data.primaryPhone === "" ? 0 : 1;
      const progress5 = data.permanentAddrStreet === "" ? 0 : 1;
      const progress6 = data.permanentCity === "" ? 0 : 1;
      const progress7 = data.emailAddr === "" ? 0 : 1;
      const progress8 = data.permanentZip === "" ? 0 : 1;
      const progress9 = data.sex === "" ? 0 : 1;
      const progress10 = data.medicareClaim === "" ? 0 : 1;

      const progress11 =
        data.hospitalPartA === "" ||
        !moment(data.hospitalPartA, "MM/DD/YYYY", true).isValid()
          ? 0
          : 1;
      const progress12 =
        data.hospitalPartB === "" ||
        !moment(data.hospitalPartB, "MM/DD/YYYY", true).isValid()
          ? 0
          : 1;

      const progress13 = data.pcpName === "" ? 0 : 1;
      const progress14 = data.nameSignature === "" ? 0 : 1;

      const progress15 =
        data.AuthorizedRep === "Y" && data.authorizedrepname !== "" ? 1 : 0;
      const progress16 =
        data.AuthorizedRep === "Y" && data.authorizedreprelationship !== ""
          ? 1
          : 0;
      const progress17 =
        data.AuthorizedRep === "Y" && data.authorizedrepaddress !== "" ? 1 : 0;
      const progress18 =
        data.AuthorizedRep === "Y" && data.authorizedrepphone !== "" ? 1 : 0;
      const progress19 =
        data.AgentAssistingEnrollment === "Y" && data.nameAgent !== "" ? 1 : 0;

      const progress20 = data.c2 === "MOV" && data.attestation2 !== "" ? 1 : 0;
      const progress21 = data.c3 === "INC" && data.attestation3 !== "" ? 1 : 0;
      const progress22 = data.c4 === "RUS" && data.attestation4 !== "" ? 1 : 0;
      const progress23 = data.c5 === "LAW" && data.attestation5 !== "" ? 1 : 0;
      const progress24 = data.c8 === "NLS" && data.attestation8 !== "" ? 1 : 0;
      const progress25 = data.c9 === "LTC" && data.attestation9 !== "" ? 1 : 0;
      const progress26 =
        data.c10 === "PAC" && data.attestation10 !== "" ? 1 : 0;

      const progress27 =
        data.c11 === "LCC" && data.attestation11 !== "" ? 1 : 0;
      const progress28 =
        data.c12 === "LEC" && data.attestation12 !== "" ? 1 : 0;
      const progress29 =
        data.c15 === "SNP" && data.attestation15 !== "" ? 1 : 0;
      const progress30 =
        data.c16 === "OTH" &&
        (data.c16Attestation !== "" || data.attestation16 !== "")
          ? 1
          : 0;
      if (
        (data.attestation2 === "" ||
          !moment(data.attestation2, "MM/DD/YYYY", true).isValid()) &&
        (data.attestation3 === "" ||
          !moment(data.attestation3, "MM/DD/YYYY", true).isValid()) &&
        (data.attestation4 === "" ||
          !moment(data.attestation4, "MM/DD/YYYY", true).isValid()) &&
        (data.attestation5 === "" ||
          !moment(data.attestation5, "MM/DD/YYYY", true).isValid()) &&
        (data.attestation8 === "" ||
          !moment(data.attestation8, "MM/DD/YYYY", true).isValid()) &&
        (data.attestation9 === "" ||
          !moment(data.attestation9, "MM/DD/YYYY", true).isValid()) &&
        (data.attestation10 === "" ||
          !moment(data.attestation10, "MM/DD/YYYY", true).isValid()) &&
        (data.attestation11 === "" ||
          !moment(data.attestation11, "MM/DD/YYYY", true).isValid()) &&
        (data.attestation12 === "" ||
          !moment(data.attestation12, "MM/DD/YYYY", true).isValid()) &&
        data.attestation15 === ""
      ) {
        count -= 11;
      } else {
        count -= 10;
      }
      if (data.AuthorizedRep !== "Y") count -= 4;
      if (data.AgentAssistingEnrollment !== "Y") count -= 1;
      // if(
      //   selectedPlan === "SDAB20" ||
      //   selectedPlan === "SDABWD20" ||
      //   selectedPlan === "SDAP20" ||
      //   selectedPlan === "SDAPWD20" ||
      //   selectedPlan === "SDAHMO1" ||
      //   selectedPlan === "SDAHMO20"
      // ){
      //   count +=1;
      //   if(data.effDate === "" ||
      //   !moment(data.effDate, "MM/DD/YYYY", true).isValid()){
      //     count-=1;
      //   }
      // }
      // console.log("progress1" + progress1);
      // console.log("progress2" + progress2);
      // console.log("progress3" + progress3);
      // console.log("progress4" + progress4);
      // console.log("progress5" + progress5);
      // console.log("progress6" + progress6);
      // console.log("progress7" + progress7);
      // console.log("progress8" + progress8);
      // console.log("progress9" + progress9);
      // console.log("progress10" + progress10);

      // console.log("progress11" + progress11);
      // console.log("progress12" + progress12);
      // console.log("progress13" + progress13);
      // console.log("progress14" + progress14);
      // console.log("progress15" + progress15);
      // console.log("progress16" + progress16);
      // console.log("progress17" + progress17);
      // console.log("progress18" + progress18);
      // console.log("progress19" + progress19);
      // console.log("progress20" + progress20);

      // console.log("progress21" + progress21);
      // console.log("progress22" + progress22);
      // console.log("progress23" + progress23);
      // console.log("progress24" + progress24);
      // console.log("progress25" + progress25);
      // console.log("progress26" + progress26);
      // console.log("progress27" + progress27);
      // console.log("progress28" + progress28);
      // console.log("progress29" + progress29);
      // console.log("progress30" + progress30);

      progress =
        ((progress1 +
          progress2 +
          progress3 +
          progress4 +
          progress5 +
          progress6 +
          progress7 +
          progress8 +
          progress9 +
          progress10 +
          progress11 +
          progress12 +
          progress13 +
          progress14 +
          progress15 +
          progress16 +
          progress17 +
          progress18 +
          progress19 +
          progress20 +
          progress21 +
          progress22 +
          progress23 +
          progress24 +
          progress25 +
          progress26 +
          progress27 +
          progress28 +
          progress29 +
          progress30) /
          count) *
        100;

      console.log(progress);
    }
    //Category1 : Plans of ---> Open to all Medicare-eligible residents of San Diego County
    //Category2 : Plans of ---> Former Employees of Sharp HealthCare only
    //Category3 : Plans of ---> Retirees of the City of San Diego (SDPEBA) only
    let Step2 = "";
    if (
      this.props.year === "2021" &&
      (this.props.selectedPlan === "SDAGCWD20" ||
        this.props.selectedPlan === "SDAGC20" ||
        this.props.selectedPlan === "SDAPC20")
    ) {
      Step2 = Step2_2021;
    } else {
      Step2 = Step2Category1;
      if (
        selectedPlan === "SDAB20" ||
        selectedPlan === "SDABWD20" ||
        selectedPlan === "SDAP20" ||
        selectedPlan === "SDAPWD20"
      ) {
        Step2 = Step2Category2;
      }

      if (selectedPlan === "SDAHMO1" || selectedPlan === "SDAHMO20") {
        Step2 = Step2Category3;
      }
    }

    if (selectedPlan === "SDAHMO1" || selectedPlan === "SDAHMO20") {
      Step2 = Step2Category3;
    }

    const { checkName } = this.state;
    if (this.props.year === "2020") {
      test = this.state.disableCheck
        ? checkName === "aep" ||
          checkName === "c1" ||
          checkName === "c6" ||
          checkName === "c7" ||
          checkName === "c13" ||
          checkName == "c14"
          ? false
          : data.attestation2 !== "" ||
            data.attestation3 !== "" ||
            data.attestation4 !== "" ||
            data.attestation5 !== "" ||
            data.attestation8 !== "" ||
            data.attestation9 !== "" ||
            data.attestation10 !== "" ||
            data.attestation11 !== "" ||
            data.attestation12 !== "" ||
            data.attestation15 !== "" ||
            data.c16Attestation !== "" ||
            data.attestation16 !== ""
          ? false
          : true
        : false;
    } else {
      test = this.state.disableCheck
        ? checkName === "aep" ||
          checkName === "c1" ||
          checkName === "c6" ||
          checkName === "c7" ||
          checkName === "c13" ||
          checkName == "c14"
          ? false
          : data.attestation2 !== "" ||
            data.attestation3 !== "" ||
            data.attestation4 !== "" ||
            data.attestation5 !== "" ||
            data.attestation8 !== "" ||
            data.attestation9 !== "" ||
            data.attestation10 !== "" ||
            data.attestation11 !== "" ||
            data.attestation12 !== "" ||
            data.attestation15 !== "" ||
            data.c16Attestation !== "" ||
            data.attestation16 !== ""
          ? false
          : true
        : false;
    }

    return (
      <React.Fragment>
        <div class="background">
          <CUSTOMER_LOGO />
          <div class="container mt-3">
            <div class="progress-bar">
              <LinearProgress
                variant="determinate"
                value={progress}
                color="primary"
                classes={{
                  root: this.props.classes.root,
                  barColorPrimary:
                    progress === 100
                      ? this.props.classes.progressComplete
                      : this.props.classes.progressIncomplete,
                }}
              />
            </div>

            <ul
              class="nav nav-pills nav-justified"
              value={this.state.stepVal}
              onClick={this.handleSteps}
            >
              <li class="nav-item">
                <p
                  class={
                    this.state.stepVal === "step1"
                      ? "nav-link active"
                      : "nav-link"
                  }
                  data-toggle="tab"
                  id="step1"
                >
                  Step 1
                </p>
              </li>
              <li class="nav-item">
                <p
                  class={
                    this.state.stepVal === "step2"
                      ? "nav-link active"
                      : "nav-link"
                  }
                  data-toggle="tab"
                  id="step2"
                >
                  Step 2
                </p>
              </li>
              <li class="nav-item">
                <p
                  class={
                    this.state.stepVal === "step3"
                      ? "nav-link active"
                      : "nav-link"
                  }
                  data-toggle="tab"
                  id="step3"
                >
                  Step 3
                </p>
              </li>
              {!(
                this.props.year === "2021" &&
                (this.props.selectedPlan === "SDAGCWD20" ||
                  this.props.selectedPlan === "SDAGC20" ||
                  this.props.selectedPlan === "SDAPC20")
              ) ? (
                <li class="nav-item">
                  <p
                    class={
                      this.state.stepVal === "step4"
                        ? "nav-link active"
                        : "nav-link"
                    }
                    data-toggle="tab"
                    id="step4"
                  >
                    Step 4
                  </p>
                </li>
              ) : null}
            </ul>

            {this.state.stepVal === "step1" && (
              <Step1
                selectedPlan={this.props.selectedPlan}
                data={this.state.data}
                handleNumberChange={this.handleNumberChange}
                authorizedrelations={this.props.authorizedrelations}
                handleChange={this.handleChange}
                redirect={this.redirect}
                handleDates={this.handleDates}
                handleDate={this.handleDate}
                handleCheckbox={this.handleCheckbox}
              />
            )}
            {this.state.stepVal === "step2" && (
              <Step2
                selectedPlan={this.props.selectedPlan}
                data={this.state.data}
                handleChange={this.handleChange}
                handleNumberChange={this.handleNumberChange}
                pcpChange={this.pcpChange}
                physicians={this.state.physicians}
                redirect={this.redirect}
                handleDates={this.handleDates}
                handleDate={this.handleDate}
              />
            )}
            {this.state.stepVal === "step3" && (
              <Step3
                selectedPlan={this.props.selectedPlan}
                data={this.state.data}
                handleCheckbox={this.handleCheckbox}
                redirect={this.redirect}
                disableCheck={this.state.disableCheck}
                handleChange={this.handleChange}
                handleDates={this.handleDates}
                handleDate={this.handleDate}
              />
            )}
            {!(
              this.props.year === "2021" &&
              (this.props.selectedPlan === "SDAGCWD20" ||
                this.props.selectedPlan === "SDAGC20" ||
                this.props.selectedPlan === "SDAPC20")
            ) &&
              this.state.stepVal === "step4" && (
                <Step4
                  selectedPlan={this.props.selectedPlan}
                  data={this.state.data}
                  handleChange={this.handleChange}
                  redirect={this.redirect}
                  authorizedrelations={this.props.authorizedrelations}
                  handleDates={this.handleDates}
                  handleDate={this.handleDate}
                />
              )}

            <div class="row" style={{ marginTop: "0.9rem" }}>
              <div class="col-md-2">
                <button
                  class="btn btn-SaveLogout"
                  id="submit"
                  onClick={this.saveData}
                >
                  Save and Logout
                </button>
              </div>

              <div class="col-md-8">
                {!(progress === 100 && !test) ? (
                  <span
                    class="small text-danger"
                    style={{ fontSize: "15px !important" }}
                  >
                    <strong>
                      We're missing a few pieces of information. Please check
                      {!(
                        this.props.year === "2021" &&
                        (this.props.selectedPlan === "SDAGCWD20" ||
                          this.props.selectedPlan === "SDAGC20" ||
                          this.props.selectedPlan === "SDAPC20")
                      )
                        ? " steps 1-4 "
                        : " steps 1-3 "}
                      for red highlighted fields. When all required information
                      has been entered, the submit button will display in green.
                    </strong>
                  </span>
                ) : (
                  <span class="small text-success">
                    <strong>
                      Congratulations! Your Medicare form is complete, please
                      press SUBMIT to finish.
                    </strong>
                  </span>
                )}
              </div>
              <div class="col-md-2">
                <button
                  class={
                    progress === 100 && !test
                      ? "btn btn-primary float-right"
                      : "btn btn-secondary float-right"
                  }
                  id="submit"
                  onClick={this.submitData}
                  disabled={!(progress === 100 && !test)}
                >
                  Submit
                </button>
              </div>
            </div>

            {/* {this.props.progress !== 100 ? (
                <span
                  class="small text-danger"
                  style={{ fontSize: "15px !important" }}
                >
                  <strong>
                    We're missing a few pieces of information. Please check
                    steps 1-3 for red highlighted fields. When all required
                    information has been entered, the submit button will display
                    in green.
                  </strong>
                </span>
              ) : (
                <span class="small text-success">
                  <strong>
                    Congratulations! Your Medicare form is complete, please
                    press SUBMIT to finish.
                  </strong>
                </span>
              )}

              <button
                class={
                  progress === 100
                    ? "btn btn-primary float-right"
                    : "btn btn-secondary float-right"
                }
                id="submit"
                onClick={this.submitData}
                disabled={progress !== 100}
              >
                Submit
              </button> */}

            <br />
            {selectedPlan === "SDAGCWD20" ||
            selectedPlan === "SDAGC20" ||
            selectedPlan === "SDAPC20" ? (
              <p style={{ float: "left", marginTop: "20px" }}>
                <strong>H5386_2020 Online Individual Enrollment Form V1</strong>
              </p>
            ) : selectedPlan === "SDAB20" ||
              selectedPlan === "SDABWD20" ||
              selectedPlan === "SDAP20" ||
              selectedPlan === "SDAPWD20" ? (
              <div>
                <p style={{ float: "left", marginTop: "20px" }}>
                  <strong>H5386_2020 SHC Enrollment Form_M V1</strong>
                </p>
              </div>
            ) : null}

            <StepsFooter />
          </div>
          {selectedPlan === "SDAB20" ||
          selectedPlan === "SDABWD20" ||
          selectedPlan === "SDAP20" ||
          selectedPlan === "SDAPWD20" ? (
            <Footer2 />
          ) : (
            <Footer1 />
          )}
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    year: state.webApp.year,
    preEnrollInfo: state.webApp.preEnrollInfo,
    guestLogin: state.webApp.guestLogin,
    physicians: state.webApp.physicians,
    authorizedrelations: state.webApp.authorizedrelations,
    selectedPlan: state.webApp.selectedPlan,
  };
};
const mapDispatchToProps = {
  saveLogout,
  submitForm,
  getClinicalName,
  removeplan,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(PreEnrollForm));
