import React, { Component } from "react";
import { connect } from "react-redux";
import { resetPassword } from "../Redux/Actions/webAppActions";
import history from "../Utils/History";
class ResetPassword extends Component {
  constructor(props) {
    super(props);
    this.state = {
      newPwd: "",
      ConfirmPwd: "",
    };
  }

  handlechange = (name) => (event) => {
    let value = event.target.value;
    this.setState({
      [name]: value,
    });
  };

  submit = async (e) => {
    e.preventDefault();
    const { newPwd, ConfirmPwd } = this.state;
    if (!newPwd) {
      alert("Please enter New Password");
    } else if (!ConfirmPwd) {
      alert("Please enter Confirm Password");
    } else if (newPwd !== ConfirmPwd) {
      alert("New Password and Confirm Password doesnt match");
    } else {
      const body = {
        userId: this.props.email,
        newPwd: ConfirmPwd,
      };

      const response = await this.props.resetPassword(body);
      if (response.status === "OK") {
        alert(response.message);
        history.push("/webapp/Sharp/Individual/userLogin");
      } else {
        alert(response.message);
      }
    }
  };

  render() {
    let header = "Reset Password";

    return (
      <div class="reset-pwd-container card">
        <form onSubmit={this.submit}>
          <div class="forgotPwd mb-4">
            <div class="row">
              <div class="col-md-2"></div>{" "}
              <div class="col-md-8" style={{ marginTop: "2rem" }}>
                <h4>{header}</h4>
              </div>
            </div>
          </div>{" "}
          <div class="mx-auto col-md-6 mb-5">
            <div class="form-group">
              <label htmlFor="email" class="control-label">
                Email
              </label>
              <input
                type="text"
                class="form-control"
                value={this.props.email}
                id="email"
                disabled
              />
            </div>
            <div class="form-group">
              <label htmlFor="newpwd" class="control-label">
                New Password
              </label>
              <input
                type="password"
                class="form-control"
                value={this.state.newPwd}
                onChange={this.handlechange("newPwd")}
                id="newPwd"
                required
              />
            </div>
            <div class="form-group">
              <label htmlFor="confirmPwd" class="control-label">
                Confirm Password
              </label>
              <input
                type="password"
                class="form-control"
                value={this.state.ConfirmPwd}
                onChange={this.handlechange("ConfirmPwd")}
                id="ConfirmPwd"
                required
              />
            </div>
            <div class="form-group">
              <div class="row">
                <div class="col text-center">
                  <button type="submit" class="btn btn-lg btn-primary spinner">
                    &nbsp;&nbsp;Submit &nbsp;&nbsp;
                  </button>{" "}
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    );
  }
}
const mapStateToProps = (state) => {
  return {};
};
const mapDispatchToProps = {
  resetPassword,
};
export default connect(mapStateToProps, mapDispatchToProps)(ResetPassword);
