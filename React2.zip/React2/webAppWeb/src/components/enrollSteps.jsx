import React, { Component } from "react";
import Banner from "../Utils/GenericUI/Banner.jsx";
import { header, Body } from "../Utils/StaticData/EnrollStepsStaticData";
import history from "../Utils/History";
import { BrowserRouter } from "react-router-dom";
import Footer1 from "../Utils/GenericUI/Footer1";

class EnrollSteps extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  redirect = (event) => {
    event.preventDefault();
    history.push("/webapp/Sharp/Individual/userCreation");
  };
  render() {
    return (
      <BrowserRouter>
        <div class="jumbotron">
          <Banner header={header} Body={Body} />
          <div class="container mt-3">
            <div class="form-group row">
              <div class="col-md-4">
                <div class="enrollment-steps">
                  <div class="enrollment-steps--header  step-1">
                    <div class="enrollment-steps--header-label">Step 1</div>
                    <div class="triangle-right"></div>
                  </div>
                  <div class="enrollment-steps--body  step-1">
                    <div class="es-content-block">
                      <p class="enroll-content-heading">CHOOSE A PLAN</p><br />
                      <p class="enroll-content">Before you begin your online Medicare form, you will need to know what plan you’d like to enroll in.</p>
                      <p class="enroll-content">Click on the link below to browse Sharp Health Plan's Medicare Advantage plans and find the best one for your health care needs.</p>
                      <p class="enroll-content">If you have questions for our Sharp Advantage Specialists, click button.</p>
                      <p class="text-center margin-top3p5"><a class="btn-esb btn-esb-teal" href="https://www.sharpmedicareadvantage.com/our-plans/explore-our-plans">Browse Plans</a></p>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-md-4">
                <div class="enrollment-steps"><div class="enrollment-steps--header  step-2">
                  <div class="enrollment-steps--header-label">Step 2</div>
                  <div class="triangle-right"></div></div>
                  <div class="enrollment-steps--body  step-2">
                    <div class="es-content-block">
                      <p class="enroll-content-heading">GATHER YOUR INFORMATION</p>
                      <p class="enroll-content">There are two important items to gather prior to beginning the online enrollment form:</p>
                      <p class="enroll-content"><strong>1. Your red, white and blue Medicare card</strong></p>
                      <p class="enroll-content"><strong>2. Your primary care physician (PCP) name and plan medical group</strong></p>
                      <p class="enroll-content">If you do not currently have a PCP or would like to select a different PCP, click on the button below to use our “Find a doctor” online search tool.</p>
                      <p class="text-center margin-top1p5"><a class="btn-esb btn-esb-teal" href="https://www.sharpmedicareadvantage.com/members/get-care/sharp-advantage-providers">Find A Doctor</a></p>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-md-4">
                <div class="enrollment-steps">
                  <div class="enrollment-steps--header  step-3">
                    <div class="enrollment-steps--header-label">Step 3</div>
                    <div class="triangle-right"></div>
                  </div>
                  <div class="enrollment-steps--body  step-3">
                    <div class="es-content-block">
                      <p class="enroll-content-heading">START YOUR ENROLLMENT FORM</p><br />
                      <p class="enroll-content">When you are ready to enroll in a plan, you will need to create a user account to start online enrollment.</p>
                      <p class="enroll-content">Once you have an account, you will be able to begin your form, and return later to complete it.</p>
                      <p class="text-center margin-top5p5">
                        <a class="btn-esb btn-esb-teal"
                          id="get-started-id"
                          onClick={this.redirect}>Get Started</a></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <Footer1 />
        </div>
      </BrowserRouter>
    );
  }
}

export default EnrollSteps;
