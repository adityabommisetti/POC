import React, { Component } from "react";

export default class Header extends Component {
  constructor(props) {
    super(props);

    this.state = {};
  }
  zoom = (event, zoom) => {
    event.preventDefault();
    if (zoom === "large") {
      document.body.style.zoom = "125%";
    } else {
      document.body.style.zoom = "100%";
    }
  };
  render() {
    return (
      <React.Fragment>
        <header class="pt-1">
          <div class="container">
            <div class="row flex-nowrap justify-content-between align-items-center">
              <div class="col-4 pt-1">
                <div class="navbar-left shp-logo">
                  <a class="navbar-brand" href="/">
                    <img
                      src={require("../assests/images/shp-logo.png")}
                      width="125"
                      height="60"
                      alt="Sharp Health Plan"
                    />
                  </a>
                </div>
                <div class="navbar-left nonmob">
                  <img
                    class="make-life-better-tab"
                    src={require("../assests/images/makelifebetter.png")}
                    width="140"
                    height="35"
                    alt="make life better (sm)"
                  />
                </div>
              </div>
              <div class="col-4 text-center">
                <div class="call-us">
                  <a
                    class="navbar-link"
                    href="tel:1-855-562-8853"
                    title="Call 1-855-562-8853 (TTY/TDD 711)"
                  >
                    <img
                      class="talk-to-nurse-img-tab"
                      src={require("../assests/images/talktonurse.png")}
                      height="24"
                      alt="Contact Us"
                    />
                    <strong>Call 1-855-562-8853 (TTY/TDD 711)</strong>
                  </a>
                </div>
              </div>

              <div class="col-4 d-flex justify-content-end align-items-center">
                {navigator.userAgent.indexOf("MSIE") > -1 ||
                navigator.userAgent.indexOf("rv:") > -1 ? null : (
                  <div
                    class="nav-item pull-right"
                    style={{ marginLeft: "0px" }}
                  >
                    <img
                      class="zoom-small"
                      src={require("../assests/images/Text_sizer_small.PNG")}
                      onClick={(e) => this.zoom(e, "small")}
                      height="25px"
                      alt=""
                      title="Change text size"
                    />
                    <img
                      class="zoom-large"
                      src={require("../assests/images/Text_sizer_large.PNG")}
                      onClick={(e) => this.zoom(e, "large")}
                      width="24"
                      height="35"
                      alt=""
                      title="Change text size"
                    />
                  </div>
                )}

                <div class="nav-item pull-right">
                  <a
                    class="navbar-link"
                    href="https://www.sharpmedicareadvantage.com/search"
                    title="Search for something"
                  >
                    Search
                    <img
                      class="srch-login-img-tab"
                      src={require("../assests/images/search.png")}
                      width="35"
                      height="35"
                      alt="Search"
                    />
                  </a>
                </div>
                <div class="nav-item pull-right">
                  <a
                    class="navbar-link"
                    href="https://www.sharpmedicareadvantage.com/login"
                    title="Log in"
                    data-module="-loginOverlay"
                  >
                    Login
                    <img
                      class="srch-login-img-tab"
                      src={require("../assests/images/login.png")}
                      width="35"
                      height="35"
                      alt="Member Login"
                    />
                  </a>
                </div>
                <div class="clearfix"></div>
              </div>
            </div>

            <div class="container navbar-container-bg">
              <nav class="navbar navbar-expand-lg" id="main_navbar">
                <button
                  class="navbar-toggler"
                  type="button"
                  data-toggle="collapse"
                  data-target="#navbarSupportedContent"
                  aria-controls="navbarSupportedContent"
                  aria-expanded="false"
                  aria-label="Toggle navigation"
                >
                  <span class="navbar-toggler-icon">
                    <i class="icon-menu"></i>
                  </span>
                </button>
                <div
                  class="collapse navbar-collapse"
                  id="navbarSupportedContent"
                >
                  <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                      <a
                        rel="noopener noreferrer"
                        class="nav-link dropdown-toggle"
                        href="#none"
                        onClick={(e) => e.preventDefault()}
                        id="ourplan-dropdown"
                        role="button"
                        data-toggle="dropdown"
                        aria-haspopup="true"
                        aria-expanded="false"
                      >
                        Our Plans
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="ourplan-dropdown"
                      >
                        <li>
                          <a
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/our-plans/explore-our-plans"
                          >
                            Explore Our Plans
                          </a>
                        </li>
                        <li>
                          <a
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/our-plans/added-benefits"
                          >
                            Added Benefits
                          </a>
                        </li>
                      </ul>
                    </li>
                    <li class="nav-item">
                      <a
                        rel="noopener noreferrer"
                        class="nav-link dropdown-toggle"
                        href="#none"
                        onClick={(e) => e.preventDefault()}
                        id="about-medicare-dropdown"
                        role="button"
                        data-toggle="dropdown"
                        aria-haspopup="true"
                        aria-expanded="false"
                      >
                        About Medicare
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="about-medicare-dropdown"
                      >
                        <li>
                          <a
                            rel="noopener noreferrer"
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/about-medicare/your-medicare-questions-answered"
                            target="_blank"
                          >
                            Your Medicare questions answered
                          </a>
                        </li>
                        <li>
                          <a
                            rel="noopener noreferrer"
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/about-medicare/what-is-medicare"
                            target="_blank"
                          >
                            What is Medicare?
                          </a>
                        </li>
                        <li>
                          <a
                            rel="noopener noreferrer"
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/about-medicare/medicare-eligibility-and-plan-types"
                            target="_blank"
                          >
                            Medicare eligibility and plan types
                          </a>
                        </li>
                        <li>
                          <a
                            rel="noopener noreferrer"
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/about-medicare/enrollment-periods"
                            target="_blank"
                          >
                            Enrollment periods
                          </a>
                        </li>
                        <li>
                          <a
                            rel="noopener noreferrer"
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/about-medicare/glossary-of-terms"
                            target="_blank"
                          >
                            Glossary of terms
                          </a>
                        </li>
                      </ul>
                    </li>
                    <li class="nav-item">
                      <a
                        rel="noopener noreferrer"
                        class="nav-link dropdown-toggle"
                        href="#none"
                        onClick={(e) => e.preventDefault()}
                        id="enroll-dropdown"
                        role="button"
                        data-toggle="dropdown"
                        aria-haspopup="true"
                        aria-expanded="false"
                      >
                        Enroll
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="enroll-dropdown"
                      >
                        <li>
                          <a
                            rel="noopener noreferrer"
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/enroll/how-to-enroll"
                            target="_blank"
                          >
                            How to enroll
                          </a>
                        </li>
                        <li>
                          <a
                            rel="noopener noreferrer"
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/enroll/enroll-online"
                            target="_blank"
                          >
                            Enroll Online
                          </a>
                        </li>
                      </ul>
                    </li>
                    <li class="nav-item">
                      <a
                        rel="noopener noreferrer"
                        class="nav-link dropdown-toggle"
                        href="#none"
                        onClick={(e) => e.preventDefault()}
                        id="about-medicare-dropdown2"
                        role="button"
                        data-toggle="dropdown"
                        aria-haspopup="true"
                        aria-expanded="false"
                      >
                        Members
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="about-medicare-dropdown2"
                      >
                        <li>
                          <a
                            rel="noopener noreferrer"
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/members/member-center"
                            target="_blank"
                          >
                            Member Center
                          </a>
                        </li>
                        <li>
                          <a
                            rel="noopener noreferrer"
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/members/how-to-appoint-a-representative"
                            target="_blank"
                          >
                            How to appoint a representative
                          </a>
                        </li>
                        <li>
                          <a
                            rel="noopener noreferrer"
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/members/pharmacy-group-page/pharmacy-and-prescription-drugs"
                            target="_blank"
                          >
                            Pharmacy
                          </a>
                        </li>
                        <li>
                          <a
                            rel="noopener noreferrer"
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/members/member-rights-and-disenrollment"
                            target="_blank"
                          >
                            Member rights and disenrollment
                          </a>
                        </li>
                        <li>
                          <a
                            rel="noopener noreferrer"
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/members/manage-your-costs"
                            target="_blank"
                          >
                            Manage your costs
                          </a>
                        </li>
                        <li>
                          <a
                            rel="noopener noreferrer"
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/members/reporting-fraud"
                            target="_blank"
                          >
                            Reporting fraud
                          </a>
                        </li>
                        <li>
                          <a
                            rel="noopener noreferrer"
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/members/quality-and-medicare-star-ratings"
                            target="_blank"
                          >
                            Quality and Medicare star ratings
                          </a>
                        </li>
                        <li>
                          <a
                            rel="noopener noreferrer"
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/members/forms-authorizations-resources/resources-for-sharp-advantage-plans"
                            target="_blank"
                          >
                            Forms, authorizations and resources
                          </a>
                        </li>
                      </ul>
                    </li>
                    <li class="nav-item">
                      <a
                        class="nav-link dropdown-toggle"
                        href="#none"
                        onClick={(e) => e.preventDefault()}
                        id="about-medicare-dropdown3"
                        role="button"
                        data-toggle="dropdown"
                        aria-haspopup="true"
                        aria-expanded="false"
                      >
                        Wellness
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="about-medicare-dropdown3"
                      >
                        <li>
                          <a
                            rel="noopener noreferrer"
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/wellness/wellness-center"
                            target="_blank"
                          >
                            Wellness Center
                          </a>
                        </li>
                        <li>
                          <a
                            rel="noopener noreferrer"
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/wellness/wellness-program"
                            target="_blank"
                          >
                            Wellness Program
                          </a>
                        </li>
                        <li>
                          <a
                            rel="noopener noreferrer"
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/wellness/preventive-care"
                            target="_blank"
                          >
                            Preventive Care
                          </a>
                        </li>
                      </ul>
                    </li>
                    <li class="nav-item">
                      <a
                        class="nav-link"
                        href="#none"
                        id="find-dr"
                        aria-haspopup="true"
                        aria-expanded="false"
                      >
                        Find a doctor
                      </a>
                    </li>
                    <li class="nav-item">
                      <a
                        class="nav-link dropdown-toggle"
                        href="#none"
                        onClick={(e) => e.preventDefault()}
                        id="about-medicare-dropdown4"
                        role="button"
                        data-toggle="dropdown"
                        aria-haspopup="true"
                        aria-expanded="false"
                      >
                        Contact Us
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="about-medicare-dropdown4"
                      >
                        <li>
                          <a
                            class="dropdown-item"
                            href="https://www.sharpmedicareadvantage.com/contact-us/faqs"
                          >
                            FAQ
                          </a>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </div>
              </nav>
            </div>
          </div>
        </header>
      </React.Fragment>
    );
  }
}
