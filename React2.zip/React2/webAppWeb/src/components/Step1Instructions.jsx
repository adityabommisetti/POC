import React, { Component } from "react";

export default class Header extends Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    render() {
        return (
            <div className="card">
                <h3 className="card-header block-heading"><a className="card-link collapsed" data-toggle="collapse" data-target="#Instructions">Instructions to fill out this form</a></h3>
                <div className="panel-collapse collapse" id="Instructions">
                    <div className="card-body">
                        <p>If you and your spouse are both applying, you'll each need to fill out a separate form. For help completing the enrollment form, email us at medicaresales@sharp.com or call us at 1-855-562-8853 (TTY/TDD: 711) to complete your enrollment over the phone.</p>
                        <p><strong>For Gold with Dental and Platinum Plans add</strong>:<br />
                         The comprehensive dental coverage is provided through DeltaCare USA, an HMO-type plan offered by Delta Dental of California. You will be auto-assigned a network dentist in your area. If you would like to change to another network provider, contact Delta Dental.</p>
                        <div className="row mt-4">
                            <div className="col-6">
                                <div className="box-item">
                                    <h4>Who can use this form?</h4>
                                    <p>People with Medicare who want to join a Medicare Advantage Plan</p>
                                    <p><strong>To join a plan, you must:</strong></p>
                                    <ul>
                                        <li>Be a United States citizen or be lawfully present in the U.S.</li>
                                        <li>Live in the plan's service area</li>
                                    </ul>
                                    <p><strong>Important</strong>: To join a Medicare Advantage Plan, you must also have both:</p>
                                    <ul>
                                        <li>Medicare Part A (Hospital Insurance)</li>
                                        <li>Medicare Part B (Medical Insurance)</li>
                                    </ul>
                                </div>
                                <div className="box-item mt-4">
                                    <h4>When do I use this form?</h4>
                                    <p>You can join a plan:</p>
                                    <ul>
                                        <li>Between October 15–December 7 each year (for coverage starting January 1)</li>
                                        <li>Within 3 months of first getting Medicare</li>
                                        <li>In certain situations where you’re allowed to join or switch plans</li>
                                    </ul>
                                </div>
                                <div className="box-item mt-4">
                                    <h4>When do I use this form?</h4>
                                    <p>Call Sharp Health Plan at 1-855-562-8853. TTY users can call 711.
                       Or, call Medicare at 1-800-MEDICARE (1-800-633-4227). TTY users can call 1-877-486-2048.</p>
                                    <p><strong>En español</strong>: Llame a Sharp Health Plan al 1-855-562-8853, TTY 711 o a Medicare gratis al 1-800-633-4227 y oprima el 2 para asistencia en español y un representante estará disponible para asistirle.</p>
                                </div>
                            </div>

                            <div className="col-6">
                                <div className="box-item">
                                    <h4>Reminders:</h4>
                                    <ul>
                                        <li>If you want to join a plan during fall open  enrollment (October 15–December 7), the plan must get your completed form by December 7.</li>
                                        <li>Your plan will send you a bill for the plan's premium. You can choose to sign up to have your premium payments deducted from your bank account or your monthly Social Security (or Railroad Retirement Board) benefit.</li>
                                    </ul>
                                </div>
                                <div className="box-item mt-4">
                                    <h4>What happens next? </h4>
                                    <ul>
                                        <li>Be sure to answer all questions.</li>
                                        <li>Be sure you have read all the pages before you submit your enrollment form to Sharp Health Plan.</li>
                                    </ul>
                                    <p>Once we process your request to join, we'll contact you.</p>
                                </div>
                                <div className="box-item mt-4">
                                    <h4>What do I need to complete this form? </h4>
                                    <ul>
                                        <li>Your Medicare Number (the number on your red, white, and blue Medicare card)
                                        <br />
                                            <img
                                                src={require("../assests/images/Medicardlogoshp_New.png")}
                                                alt=""
                                                class="width100per"
                                            />
                                        </li>
                                        <li>Your permanent address and phone number </li>
                                    </ul>
                                    <p><strong>Note</strong>: You must complete all items in Section 1. The items in Section 2 are optional — you can't be denied coverage because you don't fill them </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
