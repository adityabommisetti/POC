import React, { Component } from "react";
import Banner from "../Utils/GenericUI/Banner.jsx";
import history from "../Utils/History";
import { header, Body } from "../Utils/StaticData/YearSelectionStaticData";
import { connect } from "react-redux";
import {
  planSelectionContinue,
  removeplan,
} from "../Redux/Actions/webAppActions";
import Footer2 from "../Utils/GenericUI/Footer2.jsx";
class SelectedPlans extends Component {
  constructor(props) {
    super(props);
    this.state = {
      value: this.props.selectedPlan,
      year: this.props.year,
    };
  }
  handleSelectChange = (event) => {
    const value = event.target.value;

    this.setState({
      value: value,
    });
  };
  continue = async () => {
    if (this.state.value === "") {
      alert(" Please select plan !!");
      return;
    } else {
      let payload = {
        strPlanId: this.state.value,
      };
      await this.props.planSelectionContinue(payload);
      history.push("/webapp/Sharp/Individual/enrollOnline");
    }
  };
  render() {
    const { value, year } = this.state;
    return (
      <React.Fragment>
        <div class="space">
          <Banner header={header} Body={Body} />
          <div class="text-center">
            <div class="margin-top1">
              <strong>
                By completing this online form, you will be enrolling in a Sharp
                Direct Advantage Plan.
              </strong>
            </div>
            <div class="plan-title2">
              Select the plan you would like to enroll in:
            </div>
          </div>
        </div>
        {year === "2020" ? (
          <div class="container mt-3">
            <div class="form-group row">
              <div class="col-md-4">
                <div class="enrollment-steps">
                  <div class="enrollment-steps--header  step-3">
                    <h3 class="medicare-plan-TypeA-h3-white">
                      Open to all Medicare-eligible
                      <br />
                      residents of San Diego County:
                    </h3>
                  </div>
                  <div class="enrollment-steps--body  step-3">
                    <div class="plans custom-control custom-radio">
                      <div style={{ display: "inline !important" }}>
                        <input
                          id="planId"
                          name="Plan"
                          type="radio"
                          value="SDAGC20"
                          class="custom-control-input"
                          checked={value === "SDAGC20"}
                          onChange={this.handleSelectChange}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId"
                        >
                          2020 Sharp Direct Advantage
                          <br />
                          Gold Card (HMO)
                        </label>
                        <p>($0 monthly premium)</p>
                      </div>

                      <div>
                        <input
                          id="planId2"
                          name="Plan"
                          type="radio"
                          value="SDAGCWD20"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDAGCWD20"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId2"
                        >
                          2020 Sharp Direct Advantage
                          <br />
                          Gold Card (HMO) With Dental
                        </label>
                        <p>($12 monthly premium)</p>
                      </div>

                      <div>
                        <input
                          id="planId3"
                          name="Plan"
                          type="radio"
                          value="SDAPC20"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDAPC20"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId3"
                        >
                          2020 Sharp Direct Advantage
                          <br />
                          Platinum Card (HMO) With <br />
                          Dental
                        </label>
                        <p>($57 monthly premium)</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-md-4">
                <div class="enrollment-steps">
                  <div class="enrollment-steps--header  step-1">
                    <h3 class="medicare-plan-TypeA-h3-white">
                      Former Employees of Sharp
                      <br />
                      HealthCare only:
                    </h3>
                  </div>
                  <div class="enrollment-steps--body  step-1">
                    <div class="plans custom-control custom-radio">
                      <div>
                        <input
                          id="planId4"
                          name="Plan"
                          type="radio"
                          value="SDAB20"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDAB20"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId4"
                        >
                          2020 Sharp Direct Advantage
                          <br />
                          Basic (HMO)
                        </label>
                        <p>($0 monthly premium)</p>
                      </div>

                      <div>
                        <input
                          id="planId5"
                          name="Plan"
                          type="radio"
                          value="SDABWD20"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDABWD20"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId5"
                        >
                          2020 Sharp Direct Advantage
                          <br />
                          Basic (HMO) With Dental
                        </label>
                        <p>($12 monthly premium)</p>
                      </div>

                      <div>
                        <input
                          id="planId6"
                          name="Plan"
                          type="radio"
                          value="SDAP20"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDAP20"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId6"
                        >
                          2020 Sharp Direct Advantage
                          <br />
                          Premium (HMO)
                        </label>
                        <p>($62 monthly premium)</p>
                      </div>

                      <div>
                        <input
                          id="planId7"
                          name="Plan"
                          type="radio"
                          value="SDAPWD20"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDAPWD20"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId7"
                        >
                          2020 Sharp Direct Advantage
                          <br />
                          Premium (HMO) With Dental
                        </label>
                        <p>($74 monthly premium)</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-md-4">
                <div class="enrollment-steps">
                  <div class="enrollment-steps--header  step-4">
                    <h3 class="medicare-plan-TypeA-h3-white">
                      Retirees of the City of San Diego
                      <br /> (SDPEBA) only:
                    </h3>
                  </div>
                  <div class="enrollment-steps--body  step-4">
                    <div class="plans custom-control custom-radio">
                      <div>
                        <input
                          id="planId8"
                          name="Plan"
                          type="radio"
                          value="SDAHMO1"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDAHMO1"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId8"
                        >
                          2019-20 Sharp Direct Advantage (HMO)
                        </label>
                        <p>($201 monthly premium)</p>
                      </div>
                      <div>
                        <input
                          id="planId9"
                          name="Plan"
                          type="radio"
                          value="SDAHMO20"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDAHMO20"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId9"
                        >
                          2020-21 Sharp Direct Advantage (HMO)
                        </label>
                        <p>($201 monthly premium)</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="text-right">
              <button
                class="btn btn-primary margin-right1"
                onClick={this.continue}
              >
                Continue
              </button>
              <div class="margin-top1">
                <strong>
                  Not sure?&nbsp;
                  <a href="https://www.sharpmedicareadvantage.com/our-plans/explore-our-plans" 
                  style={{'backgroundColor':  '#1ba39c !important'}}>
                    Look at Our Plans.
                    </a>
                  </strong>
              </div>
            </div>
            <Footer2 />
          </div>
        ) : (
          <div class="container mt-3">
            <div class="form-group row">
              <div class="col-md-4">
                <div class="enrollment-steps">
                  <div class="enrollment-steps--header  step-3">
                    <h3 class="medicare-plan-TypeA-h3-white">
                      Open to all Medicare-eligible
                      <br />
                      residents of San Diego County:
                    </h3>
                  </div>
                  <div class="enrollment-steps--body  step-3">
                    <div class="plans custom-control custom-radio">
                      <div style={{ display: "inline !important" }}>
                        <input
                          id="planId"
                          name="Plan"
                          type="radio"
                          value="SDAGC20"
                          class="custom-control-input"
                          checked={value === "SDAGC20"}
                          onChange={this.handleSelectChange}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId"
                        >
                          2021 Sharp Direct Advantage
                          <br />
                          Gold Card (HMO)
                        </label>
                        <p>($0 per month, Dental not included)</p>
                      </div>

                      <div>
                        <input
                          id="planId2"
                          name="Plan"
                          type="radio"
                          value="SDAGCWD20"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDAGCWD20"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId2"
                        >
                          2021 Sharp Direct Advantage
                          <br />
                          Gold Card (HMO) With Dental
                        </label>
                        <p>
                          ($12 per month, Dental Advantage by Delta Dental [HMO]
                          included)
                        </p>
                      </div>

                      <div>
                        <input
                          id="planId3"
                          name="Plan"
                          type="radio"
                          value="SDAPC20"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDAPC20"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId3"
                        >
                          2021 Sharp Direct Advantage
                          <br />
                          Platinum Card (HMO) With <br />
                          Dental
                        </label>
                        <p>
                          ($58 per month, Dental Advantage by Delta Dental [HMO]
                          included)
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-md-4">
                <div class="enrollment-steps">
                  <div class="enrollment-steps--header  step-1">
                    <h3 class="medicare-plan-TypeA-h3-white">
                      Former Employees of Sharp
                      <br />
                      HealthCare only:
                    </h3>
                  </div>
                  <div class="enrollment-steps--body  step-1">
                    <div class="plans custom-control custom-radio">
                      <div>
                        <input
                          id="planId4"
                          name="Plan"
                          type="radio"
                          value="SDAB20"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDAB20"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId4"
                        >
                          2021 Sharp Direct Advantage
                          <br />
                          Basic (HMO)
                        </label>
                        <p>($0 monthly premium)</p>
                      </div>

                      <div>
                        <input
                          id="planId5"
                          name="Plan"
                          type="radio"
                          value="SDABWD20"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDABWD20"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId5"
                        >
                          2021 Sharp Direct Advantage
                          <br />
                          Basic (HMO) With Dental
                        </label>
                        <p>($12 monthly premium)</p>
                      </div>

                      <div>
                        <input
                          id="planId6"
                          name="Plan"
                          type="radio"
                          value="SDAP20"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDAP20"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId6"
                        >
                          2021 Sharp Direct Advantage
                          <br />
                          Premium (HMO)
                        </label>
                        <p>($62 monthly premium)</p>
                      </div>

                      <div>
                        <input
                          id="planId7"
                          name="Plan"
                          type="radio"
                          value="SDAPWD20"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDAPWD20"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId7"
                        >
                          2021 Sharp Direct Advantage
                          <br />
                          Premium (HMO) With Dental
                        </label>
                        <p>($74 monthly premium)</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-md-4">
                <div class="enrollment-steps">
                  <div class="enrollment-steps--header  step-4">
                    <h3 class="medicare-plan-TypeA-h3-white">
                      Retirees of the City of San Diego
                      <br /> (SDPEBA) only:
                    </h3>
                  </div>
                  <div class="enrollment-steps--body  step-4">
                    <div class="plans custom-control custom-radio">
                      <div>
                        <input
                          id="planId8"
                          name="Plan"
                          type="radio"
                          value="SDAHMO1"
                          class="custom-control-input"
                          onChange={this.handleSelectChange}
                          checked={value === "SDAHMO1"}
                        />
                        <label
                          class="radio-inline custom-control-label"
                          for="planId8"
                        >
                          {this.props.year === "2021"
                            ? "2020-21 Sharp Direct Advantage (HMO)"
                            : "2019-20 Sharp Direct Advantage (HMO)"}
                        </label>
                        <p>($201 monthly premium)</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="text-right">
              <button
                class="btn btn-SaveLogout margin-right1"
                onClick={this.continue}
              >
                Continue
              </button>
              <div class="margin-top1">
                <strong>
                  Not sure?&nbsp;
                  <a href="https://www.sharpmedicareadvantage.com/our-plans/explore-our-plans"
                   style={{'backgroundColor':  '#1ba39c !important'}}>
                    Look at Our Plans.
                  </a>
                </strong>
              </div>
            </div>
            <Footer2 />
          </div>
        )}
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    year: state.webApp.year,
    guestLogin: state.webApp.guestLogin,
    selectedPlan: state.webApp.selectedPlan,
  };
};
const mapDispatchToProps = {
  planSelectionContinue,
  removeplan,
};

export default connect(mapStateToProps, mapDispatchToProps)(SelectedPlans);
