import React from "react";
import moment from "moment";
const Step2 = (props) => {
  const { data } = props;
  return (
    <React.Fragment>
      <div class="tab-content">
        <div id="step2" class="container tab-pane active">
          <h3 class="tab-heading">STEP 2: MEDICARE INFORMATION</h3>
          <p class="medicare-note">
            Please Provide Your Medicare Insurance Information:
            <br />
            <strong>Note: </strong> You must have Medicare Part A and Part B to
            join a Medicare Advantage plan.
          </p>

          <h4 class="sub-heading">
            <strong>
              A. Please fill in these blanks so they match your red, white and
              blue Medicare card.
            </strong>
          </h4>
          <div class="form-group row">
            <div class="col-md-6">
              <p>
                <label for="medicareClaim" class="control-label">
                  Medicare Number*
                </label>
                <input
                  type="text"
                  placeholder="XXXXXXXXXXX"
                  pattern="/[a-zA-Z0-9]{10,11}/"
                  name="medicareClaim"
                  id="medicareClaim"
                  maxlength="11"
                  class={
                    data.medicareClaim.length < 11
                      ? "error-input"
                      : "form-control"
                  }
                  value={data.medicareClaim}
                  onChange={props.handleChange}
                  required=""
                />
              </p>

              <p>
                <label class="control-label" for="hospitalPartA">
                  Hospital (Part A) Effective Date*
                </label>
                <input
                  placeholder="MM/DD/YYYY "
                  maxLength="10"
                  class={
                    data.hospitalPartA === "" ||
                    !moment(data.hospitalPartA, "MM/DD/YYYY", true).isValid()
                      ? "error-input"
                      : "form-control"
                  }
                  onClick={(e) => props.handleDates("hospitalPartA")}
                  name="hospitalPartA"
                  id="hospitalPartA"
                  value={data.hospitalPartA}
                  onChange={props.handleDate}
                  required=""
                />
              </p>

              <p>
                <label class="control-label" for="hospitalPartB">
                  Medical (Part B) Effective Date*
                </label>
                <input
                  placeholder="MM/DD/YYYY"
                  maxLength="10"
                  class={
                    data.hospitalPartB === "" ||
                    !moment(data.hospitalPartB, "MM/DD/YYYY", true).isValid()
                      ? "error-input"
                      : "form-control"
                  }
                  onClick={(e) => props.handleDates("hospitalPartB")}
                  name="hospitalPartB"
                  id="hospitalPartB"
                  value={data.hospitalPartB}
                  onChange={props.handleDate}
                  required=""
                />
              </p>
            </div>
            <div class="col-md-6">
              <img
                src={require("../../assests/images/Medicardlogoshp_New.png")}
                alt=""
                class="width100per"
              />
            </div>
          </div>

          <h4 class="sub-heading">
            <strong>B. Paying Your Plan Premium</strong>
          </h4>
          <div class="form-group">
            <p class="text-align-justify">
              <strong>
                If we determine that you owe a late enrollment penalty (or if
                you currently have a late enrollment penalty), we need to know
                your payment preference. You can pay by mail, "Electronic Funds
                Transfer (EFT)", or "credit card" each month.{" "}
                {/*You can also
                choose to pay your premium by automatic deduction from your
                Social Security or Railroad Retirement Board (RRB) benefit check
                each month.*/}
              </strong>
            </p>

            <p class="text-align-justify">
              <strong>
                You can pay your monthly plan premium (including any late
                enrollment penalty that you currently have or may owe) by mail,
                "Electronic Funds Transfer (EFT)" or "credit card" each month.
                {/* You can also choose to pay your premium by automatic deduction
                from your Social Security or RRB.*/}
              </strong>
            </p>

            <p class="text-align-justify">
              <strong>
                If you are assessed a Part D-Income Related Monthly Adjustment
                Amount(Part D-IRMAA), you will be notified by the Social
                Security Administration. You will be responsible for paying this
                extra amount in addition to your plan premium. You will either
                have the amount with held from your Social Security benefit
                check or be billed directly by Medicare or the RRB. DO NOT pay
                Sharp Health Plan the Part D-IRMAA.
              </strong>
            </p>

            <p class="medicare-note text-align-justify">
              People with limited incomes may qualify for Extra Help to pay for
              their prescription drug costs. If eligible, Medicare could pay for
              75% or more of your drug costs including monthly prescription drug
              premiums, annual deductibles and coinsurance. Additionally, those
              who qualify will not be subject to the coverage gap or a late
              enrollment penalty. Many people are eligible for these savings and
              don't even know it. For more information about this Extra Help,
              contact your local Social Security office or call Social Security
              at 1-800-772-1213.TTY/TDD users should call 1-800-325-0778.You can
              also apply for Extra Help online at
              www.socialsecurity.gov/prescriptionhelp.
              <br />
              <br />
              If you qualify for Extra Help with your Medicare prescription drug
              coverage costs, Medicare will pay all or part of your plan premium
              If Medicare pays only a portion of this premium, we will bill you
              for the amount that Medicare doesn't cover.
            </p>

            <p>
              <strong>Please select a premium payment option:</strong>
            </p>

            <div class="radio radio-tab">
              <div class="custom-control custom-radio mt-3">
                <input
                  type="radio"
                  name="paymentOption"
                  id="getABill"
                  class="custom-control-input"
                  value="D"
                  checked={data.paymentOption === "D"}
                  onChange={props.handleChange}
                />
                <label for="getABill" class="radio-inline custom-control-label">
                  <strong>
                    Get a bill (if a payment applies, you will be able to pay by
                    check or credit card monthly)
                  </strong>
                </label>
              </div>

              <div class="custom-control custom-radio mt-3">
                <input
                  type="radio"
                  name="paymentOption"
                  class="custom-control-input"
                  id="electronicFunds"
                  value="R"
                  checked={data.paymentOption === "R"}
                  onChange={props.handleChange}
                />
                <label
                  for="electronicFunds"
                  class="radio-inline custom-control-label"
                >
                  <strong>
                    Electronic funds transfer (EFT) from your bank account on
                    the 1st of each month. If the 1st of the month falls on a
                    weekend or bank holiday, your draft will occur on the next
                    banking day.
                  </strong>
                </label>
              </div>

              <div class="form-group row ml-3 mt-3">
                <div class="col-md-6">
                  <p>
                    <label for="acctholdername" class="control-label">
                      Account holder name:
                    </label>
                    <input
                      type="text"
                      class="form-control"
                      id="acctholdername"
                      name="acctholdername"
                      value={data.acctholdername}
                      onChange={props.handleChange}
                    />
                  </p>

                  <fieldset class="radio radio-tab">
                    <legend class="control-label">Account type:</legend>
                    <div class="custom-control custom-radio custom-control-inline">
                      <input
                        type="radio"
                        name="acctType"
                        id="checking"
                        value="C"
                        class="custom-control-input"
                        checked={data.acctType === "C"}
                        onChange={props.handleChange}
                      />
                      <label
                        for="checking"
                        class="radio-inline custom-control-label"
                      >
                        Checking
                      </label>
                    </div>
                    <div class="custom-control custom-radio custom-control-inline">
                      <input
                        type="radio"
                        name="acctType"
                        id="saving"
                        value="S"
                        class="custom-control-input"
                        checked={data.acctType === "S"}
                        onChange={props.handleChange}
                      />
                      <label
                        for="saving"
                        class="radio-inline custom-control-label"
                      >
                        Saving
                      </label>
                    </div>
                  </fieldset>
                </div>
                <div class="col-md-6">
                  <p>
                    <label for="bankname" class="control-label">
                      Bank name:
                    </label>
                    <input
                      type="text"
                      class="form-control"
                      id="bankname"
                      name="bankname"
                      value={data.bankname}
                      onChange={props.handleChange}
                    />
                  </p>

                  <p>
                    <label for="routingNumber" class="control-label">
                      Bank routing number:
                    </label>
                    <input
                      type="text"
                      class="form-control"
                      id="routingNumber"
                      name="routingNumber"
                      value={data.routingNumber}
                      onChange={props.handleNumberChange}
                      placeholder="Enter 9-digit routing number"
                      maxlength="9"
                    />
                  </p>

                  <p>
                    <label for="accountNumber" class="control-label">
                      Bank account number:
                    </label>
                    <input
                      type="text"
                      pattern="[0-9]*"
                      class="form-control"
                      id="accountNumber"
                      name="accountNumber"
                      value={data.accountNumber}
                      onChange={props.handleNumberChange}
                      placeholder="Enter a numeric a/c number"
                      maxlength="14"
                    />
                  </p>
                </div>
              </div>
            </div>
          </div>

          <h4 class="sub-heading">
            <strong>C. Please read and answer these important questions</strong>
          </h4>
          <div class="form-group">
            <ol>
              <li>
                <fieldset class="radio radio-tab ml-3 mt-3">
                  <legend style={{ marginTop: "-2.5rem" }}>
                    Are you the retiree?*
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="retiree"
                      id="retireeY"
                      class="custom-control-input"
                      value="Y"
                      checked={data.retiree === "Y"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="retireeY"
                      class="radio-inline custom-control-label"
                    >
                      Yes
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="retiree"
                      id="retireeNo"
                      class="custom-control-input"
                      value="N"
                      checked={data.retiree === "N"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="retireeNo"
                      class="radio-inline custom-control-label"
                    >
                      No
                    </label>
                  </div>
                </fieldset>
                <div class="row">
                  <div class="col-4">
                    {data.retiree === "Y" ? (
                      <React.Fragment>
                        <label for="retiredate">
                          If Yes, retirement date (MM/DD/YYYY):
                        </label>
                        <input
                          name="retiredate"
                          id="retiredate"
                          placeholder="MM/DD/YYYY"
                          class="form-control"
                          maxlength="10"
                          value={data.retiredate}
                          onChange={props.handleDate}
                          onClick={(e) => props.handleDates("retiredate")}
                        />
                      </React.Fragment>
                    ) : null}
                  </div>
                  <div class="col-2"></div>
                  <div class="col-4">
                    <label for="retirename">If No, name of retiree:</label>{" "}
                    <input
                      type="text"
                      name="retirename"
                      class="form-control"
                      value={data.retirename}
                      onChange={props.handleChange}
                    />
                  </div>
                </div>
              </li>
              <li>
                <fieldset class="radio radio-tab ml-3 mt-3">
                  <legend style={{ marginTop: "-2.5rem" }}>
                    Are you covering a spouse or dependents(s) under this
                    employer?
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="empCover"
                      id="empCoverY"
                      class="custom-control-input"
                      value="Y"
                      checked={data.empCover === "Y"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="empCoverY"
                      class="radio-inline custom-control-label"
                    >
                      Yes
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="empCover"
                      id="empCoverno"
                      class="custom-control-input"
                      value="N"
                      checked={data.empCover === "N"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="empCoverno"
                      class="radio-inline custom-control-label"
                    >
                      No
                    </label>
                  </div>
                </fieldset>
                {data.empCover === "Y" ? (
                  <div class="row">
                    <div class="col-4">
                      <label for="retiredate">If Yes, name of spouse:</label>
                      <input
                        type="text"
                        name="dependentSpouse"
                        id="dependentSpouse"
                        class="form-control"
                        value={data.dependentSpouse}
                        onChange={props.handleChange}
                      />
                    </div>
                    <div class="col-2"></div>
                    <div class="col-4">
                      <label for="retirename">Name(s) of dependents(s):</label>{" "}
                      <input
                        type="text"
                        name="dependentOther"
                        class="form-control"
                        value={data.dependentOther}
                        onChange={props.handleChange}
                      />
                    </div>
                  </div>
                ) : null}
              </li>

              <li>
                <fieldset class="radio radio-tab ml-3 mt-3">
                  <legend style={{ marginTop: "-2.5rem" }}>
                    Do you or your spouse work?*
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="spousework"
                      id="c_q5_Y"
                      class="custom-control-input"
                      value="Y"
                      checked={data.spousework === "Y"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="c_q5_Y"
                      class="radio-inline custom-control-label"
                    >
                      Yes
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="spousework"
                      id="c_q5_no"
                      class="custom-control-input"
                      value="N"
                      checked={data.spousework === "N"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="c_q5_no"
                      class="radio-inline custom-control-label"
                    >
                      No
                    </label>
                  </div>
                </fieldset>
              </li>

              <li>
                <fieldset class="radio radio-tab ml-3 mt-3">
                  <legend style={{ marginTop: "-2.5rem" }}>
                    Do you have End Stage Renal Disease (ESRD)?*
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="renalDisease"
                      id="c_q1_Y"
                      class="custom-control-input"
                      value="Y"
                      checked={data.renalDisease === "Y"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="c_q1_Y"
                      class="radio-inline custom-control-label"
                    >
                      Yes
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="renalDisease"
                      id="c_q1_no"
                      class="custom-control-input"
                      value="N"
                      checked={data.renalDisease === "N"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="c_q1_no"
                      class="radio-inline custom-control-label"
                    >
                      No
                    </label>
                  </div>
                  {data.renalDisease === "Y" ? (
                    <div>
                      <legend>
                        Have you had a successful kidney transplant and/or you
                        don't need regular dialysis any more?*
                      </legend>
                      If Yes, a Licensed Sales Representative may need to
                      contact you to obtain additional information.
                      <br></br>
                      <div class="custom-control custom-radio custom-control-inline">
                        <input
                          type="radio"
                          name="esrdcontact"
                          id="esrdcontact_Y"
                          class="custom-control-input"
                          value="Y"
                          checked={data.esrdcontact === "Y"}
                          onChange={props.handleChange}
                        />
                        <label
                          for="esrdcontact_Y"
                          class="radio-inline custom-control-label"
                        >
                          Yes
                        </label>
                      </div>
                      <div class="custom-control custom-radio custom-control-inline">
                        <input
                          type="radio"
                          name="esrdcontact"
                          id="esrdcontact_no"
                          class="custom-control-input"
                          value="N"
                          checked={data.esrdcontact === "N"}
                          onChange={props.handleChange}
                        />
                        <label
                          for="esrdcontact_no"
                          class="radio-inline custom-control-label"
                        >
                          No
                        </label>
                      </div>
                    </div>
                  ) : null}
                </fieldset>
              </li>
              <li>
                <fieldset class="radio radio-tab ml-3 mt-3" id="c_qns2">
                  <legend style={{ marginTop: "-2.5rem" }}>
                    Some individuals may have other drug coverage, including
                    other private insurance, TRICARE, Federal employee health
                    benefits coverage, VA benefits, or State pharmaceutical
                    assistance programs. Will you have other prescription drug
                    coverage in addition to Sharp Health Plan?*
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="vaBenefits"
                      id="c_q2_Y"
                      class="custom-control-input"
                      value="Y"
                      checked={data.vaBenefits === "Y"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="c_q2_Y"
                      class="radio-inline custom-control-label"
                    >
                      Yes
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="vaBenefits"
                      id="c_q2_no"
                      class="custom-control-input"
                      value="N"
                      checked={data.vaBenefits === "N"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="c_q2_no"
                      class="radio-inline custom-control-label"
                    >
                      No
                    </label>
                  </div>
                </fieldset>
                {data.vaBenefits === "Y" ? (
                  <div id="c_q2_fields">
                    <div class="row mt-3 ml-1">
                      <div class="col-md-4">
                        <label for="nameOfCov" class="control-label">
                          Name of other coverage*
                        </label>
                        <input
                          type="text"
                          class={
                            data.nameOfCov === ""
                              ? "error-input"
                              : "form-control"
                          }
                          id="nameOfCov"
                          name="nameOfCov"
                          value={data.nameOfCov}
                          onChange={props.handleChange}
                        />
                      </div>
                      <div class="col-md-4">
                        <label for="idOfCov" class="control-label">
                          ID# of this coverage*
                        </label>
                        <input
                          type="text"
                          class={
                            data.idOfCov === "" ? "error-input" : "form-control"
                          }
                          id="idOfCov"
                          name="idOfCov"
                          value={data.idOfCov}
                          onChange={props.handleChange}
                        />
                      </div>
                      <div class="col-md-4">
                        <label for="groupOfCov" class="control-label">
                          Group# for this coverage*
                        </label>
                        <input
                          type="text"
                          class={
                            data.groupOfCov === ""
                              ? "error-input"
                              : "form-control"
                          }
                          id="groupOfCov"
                          name="groupOfCov"
                          value={data.groupOfCov}
                          onChange={props.handleChange}
                        />
                      </div>
                    </div>
                  </div>
                ) : null}
              </li>

              <li>
                <fieldset class="radio radio-tab ml-3 mt-3" id="c_qns4">
                  <legend style={{ marginTop: "-2.5rem" }}>
                    Are you a resident in a long-term care facility, such as a
                    nursing home?*
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="prescriptionDrug"
                      id="c_q4_Y"
                      class="custom-control-input"
                      value="Y"
                      checked={data.prescriptionDrug === "Y"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="c_q4_Y"
                      class="radio-inline custom-control-label"
                    >
                      Yes
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="prescriptionDrug"
                      id="c_q4_no"
                      class="custom-control-input"
                      value="N"
                      checked={data.prescriptionDrug === "N"}
                      onChange={props.handleChange}
                    />
                    <label
                      for="c_q4_no"
                      class="radio-inline custom-control-label"
                    >
                      No
                    </label>
                  </div>
                </fieldset>
                {data.prescriptionDrug === "Y" ? (
                  <div id="c_q4_fields">
                    <div class="row mt-3 ml-1">
                      <div class="col-md-7">
                        <label for="nameOfInst" class="control-label">
                          Name of Institution:
                        </label>
                        <input
                          type="text"
                          class={
                            data.nameOfInst === ""
                              ? "error-input"
                              : "form-control"
                          }
                          id="nameOfInst"
                          name="nameOfInst"
                          value={data.nameOfInst}
                          onChange={props.handleChange}
                          required=""
                        />
                      </div>
                      <div class="col-md-5">
                        <label for="phoneOfInst" class="control-label">
                          Phone Number of Institution:
                        </label>
                        <input
                          type="text"
                          class={
                            data.phoneOfInst === ""
                              ? "error-input"
                              : "form-control"
                          }
                          id="phoneOfInst"
                          name="phoneOfInst"
                          value={data.phoneOfInst}
                          onChange={props.handleChange}
                          placeholder="(   )   -"
                          maxlength="14"
                        />
                      </div>
                    </div>
                    <div class="row mt-3 ml-1">
                      <div class="col-md-12">
                        <label for="addrOfInst" class="control-label">
                          Address of Institution (number and street)
                        </label>
                        <input
                          type="text"
                          class={
                            data.addrOfInst === ""
                              ? "error-input"
                              : "form-control"
                          }
                          id="addrOfInst"
                          name="addrOfInst"
                          value={data.addrOfInst}
                          onChange={props.handleChange}
                          required=""
                        />
                      </div>
                    </div>
                  </div>
                ) : null}
              </li>

              <li>
                <fieldset class="radio radio-tab ml-3 mt-3">
                  {navigator.userAgent.indexOf("MSIE") > -1 ||
                  navigator.userAgent.indexOf("rv:") > -1 ? (
                    <legend style={{ marginTop: "-40px" }}>
                      Please choose a Primary Care Physician (PCP)
                    </legend>
                  ) : (
                    <legend>
                      Please choose a Primary Care Physician (PCP)
                    </legend>
                  )}
                  <div class="row">
                    <div class="col-md-6">
                      <fieldset class="radio radio-tab mt-3">
                        <legend>Are you a current patient?</legend>
                        <div class="custom-control custom-radio custom-control-inline">
                          <input
                            type="radio"
                            name="existingp"
                            id="currentPatient_Y"
                            class="custom-control-input"
                            value="Y"
                            checked={data.existingp === "Y"}
                            onChange={props.handleChange}
                          />
                          <label
                            for="currentPatient_Y"
                            class="radio-inline custom-control-label"
                          >
                            Yes
                          </label>
                        </div>
                        <div class="custom-control custom-radio custom-control-inline">
                          <input
                            type="radio"
                            name="existingp"
                            id="currentPatient_no"
                            class="custom-control-input"
                            value="N"
                            checked={data.existingp === "N"}
                            onChange={props.handleChange}
                          />
                          <label
                            for="currentPatient_no"
                            class="radio-inline custom-control-label"
                          >
                            No
                          </label>
                        </div>
                      </fieldset>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6 mt-3">
                      <label for="pcpName" class={"control-label"}>
                        PCP Name:*
                      </label>
                      <select
                        name="pcpName"
                        id="pcpName"
                        class={
                          data.pcpName === "" ? "error-input" : "form-control"
                        }
                        onChange={props.pcpChange}
                        value={data.pcpName}
                      >
                        {props.physicians.map((item, i) => {
                          return (
                            <option
                              class="select-option"
                              value={item.value}
                              key={i}
                            >
                              {item.label}
                            </option>
                          );
                        })}
                      </select>
                    </div>
                    <div class="col-md-6 mt-3">
                      <label for="clinicName" class={"control-label"}>
                        PCP Medical Group:*
                      </label>

                      <input
                        name="pcpMedicalGroupName"
                        id="clinicName"
                        class={
                          data.pcpMedicalGroupName === ""
                            ? "error-input"
                            : "form-control"
                        }
                        disabled=""
                        value={data.pcpMedicalGroupName}
                      />
                    </div>
                  </div>
                </fieldset>
              </li>
              <li
                class={
                  navigator.userAgent.indexOf("MSIE") > -1 ||
                  navigator.userAgent.indexOf("rv:") > -1
                    ? "margintest"
                    : ""
                }
              >
                <fieldset class="radio radio-tab ml-3 mt-3">
                  <div class="form-group">
                    <fieldset class="radio radio-tab mt-3">
                      {navigator.userAgent.indexOf("MSIE") > -1 ||
                      navigator.userAgent.indexOf("rv:") > -1 ? (
                        <legend style={{ marginTop: "-56px" }}>
                          Please check one of the boxes below if you would
                          prefer us to send you information in a language other
                          than English or in another format
                        </legend>
                      ) : (
                        <legend>
                          Please check one of the boxes below if you would
                          prefer us to send you information in a language other
                          than English or in another format
                        </legend>
                      )}

                      <div class="row">
                        <div class="col-md-12">
                          <React.Fragment>
                            <div class="custom-control custom-radio custom-control-inline mt-3">
                              <input
                                type="radio"
                                name="language"
                                id="lfp_spanish"
                                class="custom-control-input"
                                value="SPANISH"
                                checked={data.language === "SPANISH"}
                                onChange={props.handleChange}
                              />
                              <label
                                for="lfp_spanish"
                                class="radio-inline custom-control-label"
                              >
                                Spanish
                              </label>
                            </div>
                            <br />
                            <div class="custom-control custom-radio custom-control-inline mt-3">
                              <input
                                type="radio"
                                name="language"
                                id="lfp_braille"
                                class="custom-control-input"
                                value="BRAILLE"
                                checked={data.language === "BRAILLE"}
                                onChange={props.handleChange}
                              />
                              <label
                                for="lfp_braille"
                                class="radio-inline custom-control-label"
                              >
                                Braille
                              </label>
                            </div>
                            <br />
                            <div class="custom-control custom-radio custom-control-inline mt-3">
                              <input
                                type="radio"
                                name="language"
                                id="lfp_largeprint"
                                class="custom-control-input"
                                value="LARGE_PRINT"
                                checked={data.language === "LARGE_PRINT"}
                                onChange={props.handleChange}
                              />
                              <label
                                for="lfp_largeprint"
                                class="radio-inline custom-control-label"
                              >
                                Large Print
                              </label>
                            </div>
                            <br />
                            <div class="custom-control custom-radio custom-control-inline mt-3">
                              <input
                                type="radio"
                                name="language"
                                id="lfp_other"
                                class="custom-control-input"
                                value="OTHER"
                                checked={data.language === "OTHER"}
                                onChange={props.handleChange}
                              />
                              <label
                                for="lfp_other"
                                class="radio-inline custom-control-label"
                              >
                                Other
                              </label>
                            </div>
                            <br />
                          </React.Fragment>

                          <label
                            for="lfp_other_field"
                            class="custom-control-inline w-50 mt-1"
                          >
                            <input
                              type="text"
                              placeholder={
                                data.language === "OTHER"
                                  ? "Please enter Other Language"
                                  : ""
                              }
                              name="languageValue"
                              id="lfp_other_field"
                              maxlength="11"
                              class="form-control"
                              required=""
                              value={data.languageValue}
                              onChange={props.handleChange}
                              disabled={data.language !== "OTHER"}
                            />
                          </label>
                        </div>
                      </div>
                    </fieldset>
                  </div>
                </fieldset>
              </li>
            </ol>
          </div>

          {/* <h4 class="sub-heading">
            <strong>E. Language and Format Preferences</strong>
          </h4>
          <div class="form-group">
            <fieldset class="radio radio-tab mt-3">
              <legend>
                Please check one of the boxes below if you would prefer us to
                send you information in a language other than English or in
                another format
              </legend>
            </fieldset>
          </div>*/}
          <p>
            Please contact Sharp Health Plan at 1-855-562-8853 if you need
            information in an accessible format or language other than what is
            listed above. Our office hours are 8 a.m. to 8 p.m. 7 days per week
            from October 1 to March 31: 7 days per week 8 a.m. to 8 p.m. From
            April 1 to September 30: Monday through Friday, 8 a.m. to 8 p.m. and
            on weekends and holidays, your call will be handled by our voicemail
            system. A Customer Care Representative will return your phone call
            the next business day. TTY/TDD users should call 711.
          </p>
          <p>
            Sharp Health Plan provides the Evidence of Coverage, Formulary and
            Provider Directory online at &nbsp;
            <a href="sharpmedicareadvantage.com">
              <b>sharpmedicareadvantage.com</b>
            </a>
            . Members can request a paper copy be mailed to them by calling
            Customer Care at the phone number listed above.
          </p>
          <p>
            <strong>NOTE:</strong> You may save and continue without completing
            all required fields (*); however, all required fields must be
            completed before submitting the enrollment form.
          </p>

          <button class="btn btn-saveNext" id="next2" onClick={props.redirect}>
            Save and Next
          </button>
        </div>
      </div>
    </React.Fragment>
  );
};
export default Step2;
