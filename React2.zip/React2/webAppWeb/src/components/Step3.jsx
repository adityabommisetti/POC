import React, { Component } from "react";
import { connect } from "react-redux";
import moment from "moment";
class Step3 extends Component {
  constructor(props) {
    super(props);
    this.state = {
      formerEmpOfSharp: false,
      retireEmpOfSharp: false,
    };
  }

  componentDidMount() {
    const selectedPlan = this.props.selectedPlan;
    if (
      selectedPlan === "SDAB20" ||
      selectedPlan === "SDABWD20" ||
      selectedPlan === "SDAP20" ||
      selectedPlan === "SDAPWD20"
    ) {
      this.setState({ formerEmpOfSharp: true });
    }
    if (selectedPlan === "SDAHMO1" || selectedPlan === "SDAHMO20") {
      this.setState({ retireEmpOfSharp: true });
    }
  }

  render() {
    const { data, disableCheck, year, selectedPlan } = this.props;
    console.log(selectedPlan);
    console.log(
      year === "2021" &&
        (selectedPlan === "SDAGCWD20" ||
          selectedPlan === "SDAGC20" ||
          selectedPlan === "SDAPC20")
    );
    return (
      <React.Fragment>
        <div class="tab-content">
          <div id="step3" class="container tab-pane active">
            {/* <div id="step3" class="container tab-pane fade"> */}
            {year === "2021" &&
            (selectedPlan === "SDAGCWD20" ||
              selectedPlan === "SDAGC20" ||
              selectedPlan === "SDAPC20") ? (
              <h3 class="tab-heading">
                Exhibit 1a: Information to include on or with Enrollment
                Mechanism - Attestation of Eligibility for an Enrollment Period.
              </h3>
            ) : (
              <React.Fragment>
                <h3 class="tab-heading">
                  STEP 3: ATTESTATION OF ELIGIBILITY FOR AN ENROLLMENT PERIOD
                </h3>
                <p>
                  <strong>
                    Exhibit 1a: Information to include on or with Enrollment
                    Mechanism - Attestation of Eligibility for an Enrollment
                    Period
                  </strong>
                </p>
              </React.Fragment>
            )}
            <p>
              {this.state.retireEmpOfSharp === true ? (
                <strong>
                  Typically, you may enroll in a Medicare Advantage plan only
                  during the City of San Diego Medicare Retirees' open
                  enrollment period which is in June each year.
                </strong>
              ) : (
                <strong>
                  Typically, you may enroll in a Medicare Advantage Plan during
                  the annual enrollment period which is from October 15 through
                  December 7 of each year.
                </strong>
              )}
              There are exceptions that allow you to enroll in a Medicare
              Advantage Plan outside of this period.
            </p>
            <p>
              Please read the following statements carefully and check the box
              if the statement applies to you. By checking any of the following
              boxes you are certifying that, to the best of your knowledge, you
              are eligible for an enrollment period. If we later determine that
              this information is incorrect, you may be disenrolled.
            </p>
            <ul class="list-group" id="step3_checklist">
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk1"
                    name="aep"
                    value={data.aep}
                    checked={data.aep === "AEP" ? true : false}
                    onChange={this.props.handleCheckbox}
                    disabled={
                      disableCheck === false || data.aep === "AEP"
                        ? false
                        : true
                    }
                  />

                  <label class="custom-control-label" for="step3_chk1">
                    {this.state.formerEmpOfSharp === true ? (
                      <strong>
                        I am a former employee or spouse/domestic
                        partner/dependent of a former employee of Sharp
                        HealthCare and I am not actively employed by Sharp
                        HealthCare..
                      </strong>
                    ) : this.state.retireEmpOfSharp === true ? (
                      <strong>
                        I am a retiree or spouse/domestic partner/dependent of a
                        retiree of the City of San Diego enrolling during open
                        enrollment (June 1 - June 30, 2020).
                      </strong>
                    ) : (
                      <React.Fragment>
                        <strong>
                          I am switching Medicare plans during the Annual
                          Election Period of October 15 - December 7.
                        </strong>{" "}
                        If yes, your effective date of coverage will be January
                        1.
                      </React.Fragment>
                    )}
                  </label>
                </div>
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk2"
                    name="c1"
                    value={data.c1}
                    disabled={
                      disableCheck === false || data.c1 === "NEW" ? false : true
                    }
                    checked={data.c1 === "NEW" ? true : false}
                    onChange={this.props.handleCheckbox}
                  />
                  <label class="custom-control-label" for="step3_chk2">
                    <strong>I am new to Medicare.</strong>
                  </label>
                </div>
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk3"
                    name="c2"
                    checked={data.c2 === "MOV" ? true : false}
                    onChange={this.props.handleCheckbox}
                    disabled={
                      disableCheck === false || data.c2 === "MOV" ? false : true
                    }
                    value={data.c2}
                  />
                  <label class="custom-control-label" for="step3_chk3">
                    <strong>
                      I recently moved outside of the service area for my
                      current plan or I recently moved and this plan is a new
                      option for me.
                    </strong>
                  </label>
                  <br />
                </div>
                {data.c2 === "MOV" ? (
                  <React.Fragment>
                    <label for="attestation2">
                      I moved on (insert date)*
                      <input
                        type="attestation2"
                        id="attestation2"
                        name="attestation2"
                        class="form-control display-inline"
                        placeholder="MM/DD/YYYY"
                        maxLength="10"
                        value={data.attestation2}
                        onChange={this.props.handleDate}
                        onClick={(e) => this.props.handleDates("attestation2")}
                        class={
                          data.attestation2 === "" ||
                          !moment(
                            data.attestation2,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                      />
                    </label>
                  </React.Fragment>
                ) : null}
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk4"
                    name="c3"
                    disabled={
                      disableCheck === false || data.c3 === "INC" ? false : true
                    }
                    checked={data.c3 === "INC" ? true : false}
                    onChange={this.props.handleCheckbox}
                    value={data.c3}
                  />
                  <label class="custom-control-label" for="step3_chk4">
                    <strong>I recently was released from incarceration.</strong>
                  </label>
                </div>
                {data.c3 === "INC" ? (
                  <React.Fragment>
                    <label for="attestation3">
                      I was released on (insert date)*
                      <input
                        id="attestation3"
                        name="attestation3"
                        class="form-control display-inline"
                        placeholder="MM/DD/YYYY"
                        maxLength="10"
                        value={data.attestation3}
                        onChange={this.props.handleDate}
                        onClick={(e) => this.props.handleDates("attestation3")}
                        class={
                          data.attestation3 === "" ||
                          !moment(
                            data.attestation3,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                      />
                    </label>
                  </React.Fragment>
                ) : null}
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk5"
                    name="c4"
                    value={data.c4}
                    disabled={
                      disableCheck === false || data.c4 === "RUS" ? false : true
                    }
                    checked={data.c4 === "RUS" ? true : false}
                    onChange={this.props.handleCheckbox}
                  />
                  <label class="custom-control-label" for="step3_chk5">
                    <strong>
                      I recently returned to the United States after living
                      permanently outside of the U.S.
                    </strong>
                  </label>
                </div>
                {data.c4 === "RUS" ? (
                  <React.Fragment>
                    <label for="attestation4">
                      I returned to the U.S. on (insert date)*
                      <input
                        id="attestation4"
                        name="attestation4"
                        class="form-control display-inline"
                        placeholder="MM/DD/YYYY"
                        maxLength="10"
                        value={data.attestation4}
                        onChange={this.props.handleDate}
                        onClick={(e) => this.props.handleDates("attestation4")}
                        class={
                          data.attestation4 === "" ||
                          !moment(
                            data.attestation4,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                      />
                    </label>
                  </React.Fragment>
                ) : null}
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk6"
                    name="c5"
                    value={data.c5}
                    disabled={
                      disableCheck === false || data.c5 === "LAW" ? false : true
                    }
                    checked={data.c5 === "LAW" ? true : false}
                    onChange={this.props.handleCheckbox}
                  />
                  <label class="custom-control-label" for="step3_chk6">
                    <strong>
                      I recently obtained lawful presence status in the United
                      States.
                    </strong>
                  </label>
                </div>
                {data.c5 === "LAW" ? (
                  <React.Fragment>
                    <label for="attestation5">
                      I got this status on (insert date)*
                      <input
                        id="attestation5"
                        name="attestation5"
                        class="form-control display-inline"
                        placeholder="MM/DD/YYYY"
                        maxLength="10"
                        value={data.attestation5}
                        onChange={this.props.handleDate}
                        onClick={(e) => this.props.handleDates("attestation5")}
                        class={
                          data.attestation5 === "" ||
                          !moment(
                            data.attestation5,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                      />
                    </label>
                  </React.Fragment>
                ) : null}
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk7"
                    name="c6"
                    value={data.c6}
                    disabled={
                      disableCheck === false || data.c6 === "MDE" ? false : true
                    }
                    checked={data.c6 === "MDE" ? true : false}
                    onChange={this.props.handleCheckbox}
                  />
                  <label class="custom-control-label" for="step3_chk7">
                    <strong>
                      I have both Medicare and Medicaid (or my state helps pay
                      for my Medicare premiums) or I get Extra Help paying for
                      my Medicare prescription drug coverage, but I haven't had
                      a change.
                    </strong>
                  </label>
                </div>
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk8"
                    name="c7"
                    value={data.c7}
                    disabled={
                      disableCheck === false || data.c7 === "HLP" ? false : true
                    }
                    checked={data.c7 === "HLP" ? true : false}
                    onChange={this.props.handleCheckbox}
                  />
                  <label class="custom-control-label" for="step3_chk8">
                    <strong>
                      I get Extra Help paying for Medicare prescription drug
                      coverage.
                    </strong>
                  </label>
                </div>
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk9"
                    name="c8"
                    value={data.c8}
                    checked={data.c8 === "NLS" ? true : false}
                    onChange={this.props.handleCheckbox}
                    disabled={
                      disableCheck === false || data.c8 === "NLS" ? false : true
                    }
                  />
                  <label class="custom-control-label" for="step3_chk9">
                    <strong>
                      I no longer qualify for Extra Help paying for my Medicare
                      prescription drugs.
                    </strong>
                  </label>
                </div>
                {data.c8 === "NLS" ? (
                  <React.Fragment>
                    <label for="attestation8">
                      I stopped receiving extra help on (insert date)*
                      <input
                        id="attestation8"
                        name="attestation8"
                        class="form-control display-inline"
                        placeholder="MM/DD/YYYY"
                        maxLength="10"
                        value={data.attestation8}
                        onChange={this.props.handleDate}
                        onClick={(e) => this.props.handleDates("attestation8")}
                        class={
                          data.attestation8 === "" ||
                          !moment(
                            data.attestation8,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                      />
                    </label>
                  </React.Fragment>
                ) : null}
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk10"
                    name="c9"
                    value={data.c9}
                    checked={data.c9 === "LTC" ? true : false}
                    onChange={this.props.handleCheckbox}
                    disabled={
                      disableCheck === false || data.c9 === "LTC" ? false : true
                    }
                  />
                  <label class="custom-control-label" for="step3_chk10">
                    <strong>
                      I am moving into, live in , or recently moved out of a
                      Long-Term Care Facility (for example, a nursing home or
                      long term care facility).
                    </strong>
                  </label>
                </div>
                {data.c9 === "LTC" ? (
                  <React.Fragment>
                    <label for="attestation9">
                      I moved/will move into/out of the facility on (insert
                      date)*
                      <input
                        id="attestation9"
                        name="attestation9"
                        class="form-control display-inline"
                        placeholder="MM/DD/YYYY"
                        maxLength="10"
                        value={data.attestation9}
                        onChange={this.props.handleDate}
                        onClick={(e) => this.props.handleDates("attestation9")}
                        class={
                          data.attestation9 === "" ||
                          !moment(
                            data.attestation9,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                      />
                    </label>
                  </React.Fragment>
                ) : null}
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk11"
                    name="c10"
                    value={data.c10}
                    checked={data.c10 === "PAC" ? true : false}
                    onChange={this.props.handleCheckbox}
                    disabled={
                      disableCheck === false || data.c10 === "PAC"
                        ? false
                        : true
                    }
                  />
                  <label class="custom-control-label" for="step3_chk11">
                    <strong>I recently left a PACE program</strong>
                  </label>
                </div>
                {data.c10 === "PAC" ? (
                  <React.Fragment>
                    <label for="attestation10">
                      I left PACE program on (insert date)*
                      <input
                        id="attestation10"
                        name="attestation10"
                        class="form-control display-inline"
                        placeholder="MM/DD/YYYY"
                        maxLength="10"
                        value={data.attestation10}
                        onChange={this.props.handleDate}
                        onClick={(e) => this.props.handleDates("attestation10")}
                        class={
                          data.attestation10 === "" ||
                          !moment(
                            data.attestation10,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                      />
                    </label>
                  </React.Fragment>
                ) : null}
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk12"
                    name="c11"
                    value={data.c11}
                    disabled={
                      disableCheck === false || data.c11 === "LCC"
                        ? false
                        : true
                    }
                    checked={data.c11 === "LCC" ? true : false}
                    onChange={this.props.handleCheckbox}
                  />
                  <label class="custom-control-label" for="step3_chk12">
                    <strong>
                      I recently involuntarily lost my creditable prescription
                      drug coverage (coverage as good as Medicare's).
                    </strong>
                  </label>
                </div>
                {data.c11 === "LCC" ? (
                  <React.Fragment>
                    <label for="attestation11">
                      I lost my drug coverage on (insert date)*
                      <input
                        id="attestation11"
                        name="attestation11"
                        class="form-control display-inline"
                        placeholder="MM/DD/YYYY"
                        maxLength="10"
                        value={data.attestation11}
                        onChange={this.props.handleDate}
                        onClick={(e) => this.props.handleDates("attestation11")}
                        class={
                          data.attestation11 === "" ||
                          !moment(
                            data.attestation11,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                      />
                    </label>
                  </React.Fragment>
                ) : null}
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk13"
                    name="c12"
                    checked={data.c12 === "LEC" ? true : false}
                    onChange={this.props.handleCheckbox}
                    disabled={
                      disableCheck === false || data.c12 === "LEC"
                        ? false
                        : true
                    }
                    value={data.c12}
                  />
                  <label class="custom-control-label" for="step3_chk13">
                    <strong>I am leaving employer or union coverage</strong>
                  </label>
                </div>
                {data.c12 === "LEC" ? (
                  <React.Fragment>
                    <label for="attestation12">
                      I am leaving on (insert date)*
                      <input
                        id="attestation12"
                        name="attestation12"
                        class="form-control display-inline"
                        placeholder="MM/DD/YYYY"
                        maxLength="10"
                        value={data.attestation12}
                        onChange={this.props.handleDate}
                        onClick={(e) => this.props.handleDates("attestation12")}
                        class={
                          data.attestation12 === "" ||
                          !moment(
                            data.attestation12,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                      />
                    </label>
                  </React.Fragment>
                ) : null}
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk14"
                    name="c13"
                    disabled={
                      disableCheck === false || data.c13 === "PAP"
                        ? false
                        : true
                    }
                    checked={data.c13 === "PAP" ? true : false}
                    onChange={this.props.handleCheckbox}
                    value={data.c13}
                  />
                  <label class="custom-control-label" for="step3_chk14">
                    <strong>
                      I belong to a pharmacy assistance program provided by my
                      state.
                    </strong>
                  </label>
                </div>
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk15"
                    name="c14"
                    disabled={
                      disableCheck === false || data.c14 === "EOC"
                        ? false
                        : true
                    }
                    value={data.c14}
                    checked={data.c14 === "EOC" ? true : false}
                    onChange={this.props.handleCheckbox}
                  />
                  <label class="custom-control-label" for="step3_chk15">
                    <strong>
                      My plan is ending its contract with Medicare or Medicare
                      is ending its contact with my plan.
                    </strong>
                  </label>
                </div>
              </li>
              <li class="list-group-item">
                <div class="custom-control custom-checkbox custom-control-inline">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="step3_chk16"
                    name="c15"
                    checked={data.c15 === "SNP" ? true : false}
                    onChange={this.props.handleCheckbox}
                    disabled={
                      disableCheck === false || data.c15 === "SNP"
                        ? false
                        : true
                    }
                    value={data.c15}
                  />
                  <label class="custom-control-label" for="step3_chk16">
                    <strong>
                      I was enrolled in a Special Needs Plan (SNP) but I have
                      lost the special needs qualification required to be in
                      that plan.
                    </strong>
                  </label>
                </div>
                {data.c15 === "SNP" ? (
                  <React.Fragment>
                    <label for="attestation15">
                      I was disenrolled from the SNP on (insert date)*
                      <input
                        id="attestation15"
                        name="attestation15"
                        class="form-control display-inline"
                        placeholder="MM/DD/YYYY"
                        maxLength="10"
                        value={data.attestation15}
                        onChange={this.props.handleDate}
                        onClick={(e) => this.props.handleDates("attestation15")}
                        class={
                          data.attestation15 === "" ||
                          !moment(
                            data.attestation15,
                            "MM/DD/YYYY",
                            true
                          ).isValid()
                            ? "error-input"
                            : "form-control"
                        }
                      />
                    </label>
                  </React.Fragment>
                ) : null}
              </li>
              {!(
                this.props.year === "2021" &&
                (this.props.selectedPlan === "SDAGCWD20" ||
                  this.props.selectedPlan === "SDAGC20" ||
                  this.props.selectedPlan === "SDAPC20")
              ) ? (
                <li class="list-group-item">
                  <div class="custom-control custom-checkbox custom-control-inline">
                    <input
                      type="checkbox"
                      class="custom-control-input"
                      id="step3_chk17"
                      name="c16"
                      checked={data.c16 === "OTH" ? true : false}
                      onChange={this.props.handleCheckbox}
                      value={data.c16}
                      disabled={
                        disableCheck === false || data.c16 === "OTH"
                          ? false
                          : true
                      }
                    />
                    <label class="custom-control-label" for="step3_chk17">
                      <strong>Other:</strong>
                    </label>
                  </div>
                  {data.c16 === "OTH" ? (
                    <React.Fragment>
                      <input
                        type="text"
                        class="form-control"
                        name="c16Attestation"
                        value={data.c16Attestation}
                        onChange={this.props.handleChange}
                        class={
                          data.c16Attestation === ""
                            ? "error-input"
                            : "form-control"
                        }
                      />
                      <label for="attestation16">
                        on (insert date)*
                        <input
                          id="attestation16"
                          class="form-control display-inline"
                          placeholder="MM/DD/YYYY"
                          maxLength="10"
                          name="attestation16"
                          value={data.attestation16}
                          onChange={this.props.handleDate}
                          onClick={(e) =>
                            this.props.handleDates("attestation16")
                          }
                          class={
                            data.attestation16 === "" ||
                            !moment(
                              data.attestation16,
                              "MM/DD/YYYY",
                              true
                            ).isValid()
                              ? "error-input"
                              : "form-control"
                          }
                        />
                      </label>
                    </React.Fragment>
                  ) : null}
                </li>
              ) : (
                <React.Fragment>
                  <li class="list-group-item">
                    <div class="custom-control custom-checkbox custom-control-inline">
                      <input
                        type="checkbox"
                        class="custom-control-input"
                        id="step3_chk7"
                        name="c22"
                        value={data.c22}
                        disabled={
                          disableCheck === false || data.c22 === "MCD"
                            ? false
                            : true
                        }
                        checked={data.c22 === "MCD" ? true : false}
                        onChange={this.props.handleCheckbox}
                      />
                      <label class="custom-control-label" for="step3_chk7">
                        <strong>
                          I recently had a change in my Medicaid (newly got
                          Medicaid, had a change in level of Medicaid
                          assistance, or lost Medicaid{" "}
                        </strong>
                      </label>
                    </div>
                    {data.c22 === "MCD" ? (
                      <React.Fragment>
                        <label for="recentlyChangeMedicaid">
                          (insert date)*
                          <input
                            name="recentlyChangeMedicaid"
                            id="recentlyChangeMedicaid"
                            placeholder="MM/DD/YYYY"
                            maxLength="10"
                            value={data.recentlyChangeMedicaid}
                            class={
                              data.recentlyChangeMedicaid === "" ||
                              !moment(
                                data.recentlyChangeMedicaid,
                                "MM/DD/YYYY",
                                true
                              ).isValid()
                                ? "error-input"
                                : "form-control"
                            }
                            onClick={(e) =>
                              this.props.handleDates("recentlyChangeMedicaid")
                            }
                            onChange={this.props.handleChange}
                          />
                        </label>
                      </React.Fragment>
                    ) : null}
                  </li>
                  <li class="list-group-item">
                    <div class="custom-control custom-checkbox custom-control-inline">
                      <input
                        type="checkbox"
                        class="custom-control-input"
                        id="step3_chk8"
                        name="c23"
                        value={data.c23}
                        disabled={
                          disableCheck === false || data.c7 === "HLP"
                            ? false
                            : true
                        }
                        checked={data.c23 === "HLP" ? true : false}
                        onChange={this.props.handleCheckbox}
                      />
                      <label class="custom-control-label" for="step3_chk8">
                        <strong>
                          I recently had a change in my Extra Help paying for
                          Medicare prescription drug coverage (newly got Extra
                          Help, had a change in the level of Extra Help, or lost
                          Extra Help)
                        </strong>
                      </label>
                    </div>
                    {data.c23 === "HLP" ? (
                      <React.Fragment>
                        <label for="recentlyChangeExtraHelp">
                          (insert date)*
                          <input
                            name="attestation7"
                            id="attestation7"
                            maxLength="10"
                            placeholder="MM/DD/YYYY"
                            value={data.attestation7}
                            class={
                              data.attestation7 === "" ||
                              !moment(
                                data.attestation7,
                                "MM/DD/YYYY",
                                true
                              ).isValid()
                                ? "error-input"
                                : "form-control"
                            }
                            onClick={(e) =>
                              this.props.handleDates("attestation7")
                            }
                            onChange={this.props.handleChange}
                          />
                        </label>
                      </React.Fragment>
                    ) : null}
                  </li>
                  <li class="list-group-item">
                    <div class="custom-control custom-checkbox custom-control-inline">
                      <input
                        type="checkbox"
                        class="custom-control-input"
                        id="step3_chk17"
                        name="c25"
                        value={data.c25}
                        disabled={
                          disableCheck === false || data.c25 === "DST"
                            ? false
                            : true
                        }
                        checked={data.c25 === "DST" ? true : false}
                        onChange={this.props.handleCheckbox}
                      />
                      <label class="custom-control-label" for="step3_chk17">
                        <strong>
                          I was affected by a weather-related emergency or major
                          disaster (as declared by the Federal Emergency
                          Management Agency (FEMA). One of the other statements
                          here applied to me, but I was unable to make my
                          enrollment because of the natural disaster.
                        </strong>
                      </label>
                    </div>
                  </li>
                </React.Fragment>
              )}
            </ul>
            <p class="mt-3">
              If none of these statements apply to you or you're not sure,
              please contact Sharp Health Plan at 1-855-562-8853 (TTY/TDD users
              should call 711) to see if you are eligible to enroll. We are open
              from October 1 to March 31: 7 days per week 8 a.m. to 8 p.m. From
              April 1 to September 30: Monday through Friday, 8 a.m. to 8 p.m.
              and on weekends and holidays, your call will be handled by our
              voicemail system. A Customer Care Representative will return your
              phone call the next business day.
            </p>
            <p>
              <strong>NOTE:</strong> You may save and continue without
              completing all required fields (*); however, all required fields
              must be completed before submitting the enrollment form.
            </p>
            {!(
              this.props.year === "2021" &&
              (this.props.selectedPlan === "SDAGCWD20" ||
                this.props.selectedPlan === "SDAGC20" ||
                this.props.selectedPlan === "SDAPC20")
            ) ? (
              <button
                class="btn btn-saveNext"
                id="next3"
                style={{ backgroundColor: "#603167" }}
                onClick={this.props.redirect}
              >
                Save and Next
              </button>
            ) : null}
          </div>
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    // year: state.webApp.year,
    year: "2021",
  };
};
export default connect(mapStateToProps)(Step3);
