import React, { Component } from "react";
import Banner from "../Utils/GenericUI/Banner.jsx";
import { header, Body } from "../Utils/StaticData/ForgotPwdStaticData.jsx";
import { sendLink } from "../Redux/Actions/webAppActions";
import history from "../Utils/History";
import Footer1 from "../Utils/GenericUI/Footer1";

import { connect } from "react-redux";
class ForgotPassword extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: "",
    };
  }
  componentDidMount() {
    window.scroll(0, 0);
  }

  handleChange = (event) => {
    const value = event.target.value;

    this.setState({
      email: value,
    });
  };

  sendLink = async (e) => {
    e.preventDefault();
    const { email } = this.state;

    if (!email) {
      alert("Email cannot be empty");
      return;
    }

    const body = email;

    const response = await this.props.sendLink(body);

    if (response.status === "OK") {
      alert(response.message);
      history.push("/webapp/Sharp/Individual/userLogin");
    } else alert(response.message);
  };
  render() {
    const { email } = this.state;
    return (
      <div id="forgotPassword">
        <Banner header={header} Body={Body} />
        <div class="container mt-3">
          <form onSubmit={this.sendLink}>
            <div class="tab-content">
              <div class="container form-panel">
                <div class="form-group row">
                  <div class="col-md-12">
                    <label for="emailAddress" class="control-label">
                      Email Address*
                    </label>

                    <input
                      type="email"
                      name="email"
                      placeholder="john.smith@mail.com"
                      class="form-control"
                      value={email}
                      onChange={this.handleChange}
                    />
                    <br />

                    <br />
                  </div>
                </div>
                <div class="button-container-login-page">
                  <button
                    class="btn btn-primary"
                    id="sendLink"
                    onClick={this.sendLink}
                  >
                    Send Reset
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
        <Footer1 />
      </div>
    );
  }
}
const mapStateToProps = (state) => {
  return {};
};
const mapDispatchToProps = {
  sendLink,
};
export default connect(mapStateToProps, mapDispatchToProps)(ForgotPassword);
