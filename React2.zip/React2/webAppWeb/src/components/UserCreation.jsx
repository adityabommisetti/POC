import React from "react";
import Banner from "../Utils/GenericUI/Banner.jsx";
import { header, Body } from "../Utils/StaticData/UserCreationStaticData";
import history from "../Utils/History";
import RemoveRedEyeIcon from "@material-ui/icons/RemoveRedEye";
import SimpleReactValidator from "simple-react-validator";
import { connect } from "react-redux";
import { signUp, guestLogin } from "../Redux/Actions/webAppActions";
import Footer1 from "../Utils/GenericUI/Footer1";
import { INITIAL_STATE } from "./initialState";

class UserCreation extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      email: "",
      password: "",

      confirmPassword: "",
      showPassword: false,
      passwordEye: false,
      showConfirmPassword: false,
      confirmPasswordEye: false,
      emailError: false,
      passwordError: false,
      confirmPasswordError: false,
      modified: false,
    };
    this.validator = new SimpleReactValidator();
  }
  componentDidMount() {
    window.scroll(0, 0);
  }

  handleChange = async (event) => {
    const { password } = this.state;
    const name = event.target.name;
    const value = event.target.value;
    const emailError =
      name === "email" &&
      (!this.validator.check(value, "email") || value === "");
    const passwordError = name === "password" && value === "";
    const confirmPasswordError =
      name === "confirmPassword" && (value === "" || password !== value);

    await this.setState({
      [name]: value,
      emailError: emailError,
      passwordError: passwordError,
      confirmPasswordError: confirmPasswordError,
      modified: true,
    });
  };

  handleFocus = (name) => (event) => {
    event.preventDefault();
    const showPasswordEye = name === "password";
    const showConfirmPasswordEye = name === "confirmPassword";
    this.setState({
      passwordEye: showPasswordEye,
      confirmPasswordEye: showConfirmPasswordEye,
    });
  };

  handleOnBlur = (name) => (event) => {
    event.preventDefault();
    const {
      showConfirmPassword,
      showPassword,
      email,
      password,
      confirmPassword,
    } = this.state;
    const showPasswordEye = name === "password" && showPassword;
    const showConfirmPasswordEye =
      name === "confirmPassword" && showConfirmPassword;
    const emailError =
      name === "email" &&
      (!this.validator.check(email, "email") || email === "");
    const passwordError = password === "";
    const confirmPasswordError =
      confirmPassword === "" || password !== confirmPassword;
    this.setState({
      passwordEye: showPasswordEye,
      confirmPasswordEye: showConfirmPasswordEye,
      emailError: emailError,
      passwordError: passwordError,
      confirmPasswordError: confirmPasswordError,
    });
  };

  showPassword = (name, toggle) => (event) => {
    document.getElementById(name).focus();
    const eyeIcon = name === "password" ? "passwordEye" : "confirmPasswordEye";
    const show = name === "password" ? "showPassword" : "showConfirmPassword";
    this.setState({
      [eyeIcon]: true,
      [show]: toggle,
    });
  };

  signUp = async (e) => {
    // e.preventDefault();
    const { email, password, confirmPassword } = this.state;

    const emailError = !this.validator.check(email, "email") || email === "";

    const confirmPasswordError =
      confirmPassword === "" || password !== confirmPassword;

    if (emailError) {
      alert("Email format is incorrect");
      return;
    }
    if (!password) {
      alert("Please enter Password");
      return;
    }
    if (confirmPasswordError) {
      alert("Passwords do not match - Please Re-enter");
      return;
    }
    let body = {
      emailAddress: email,
      password: password,
      reconfirmPwd: confirmPassword,
    };
    body = { ...body, customerId: "HCF0331" };
    const signup = await this.props.signUp(body);
    if (signup.message === "SUCCESS")
      history.push("/webapp/Sharp/Individual/yearSelection");
    else alert(signup.message);
  };
  continueAsGuest = async (e) => {
    e.preventDefault();
    const guestLogin = await this.props.guestLogin(INITIAL_STATE.customerId);
    if (guestLogin.data === "Logged in as guest")
      history.push("/webapp/Sharp/Individual/yearSelectionGuest");
    else alert("Login Failed");
  };
  login = (e) => {
    e.preventDefault();
    history.push("/webapp/Sharp/Individual/userLogin");
  };
  render() {
    const {
      password,
      confirmPassword,
      email,
      showPassword,
      showConfirmPassword,
      passwordEye,
      confirmPasswordEye,
      emailError,
      passwordError,
      confirmPasswordError,
    } = this.state;
    return (
      <div id="userCreation">
        <Banner header={header} Body={Body} />
        <div class="container mt-3">
          <div class="tab-content">
            <div class="container form-panel">
              <div class="form-group row">
                <div class="col-md-12">
                  <label for="emailAddress" class="control-label">
                    Email Address*
                  </label>

                  <input
                    type="email"
                    name="email"
                    placeholder="john.smith@mail.com"
                    class={emailError ? "error-input" : "form-control"}
                    value={email}
                    onChange={this.handleChange}
                    onBlur={this.handleOnBlur("email")}
                  />
                  <br />
                  <label for="password" class="control-label">
                    Password*
                  </label>
                  <input
                    type={showPassword ? "text" : "password"}
                    id="password"
                    name="password"
                    class={passwordError ? "error-input" : "form-control"}
                    value={password}
                    onFocus={this.handleFocus("password")}
                    onBlur={this.handleOnBlur("password")}
                    onChange={this.handleChange}
                  />
                  {passwordEye ? (
                    <div
                      class="eyeIcon-password"
                      onMouseUp={this.showPassword("password", false)}
                      onMouseDown={this.showPassword("password", true)}
                      onMouseOut={this.showPassword("password", false)}
                    >
                      <RemoveRedEyeIcon />
                    </div>
                  ) : null}
                  <br />
                  <label for="reenterpwd" class="control-label">
                    Re-enter Password*
                  </label>
                  <input
                    type={showConfirmPassword ? "text" : "password"}
                    id="confirmPassword"
                    class={
                      confirmPasswordError ? "error-input" : "form-control"
                    }
                    autoFocus
                    name="confirmPassword"
                    value={confirmPassword}
                    onFocus={this.handleFocus("confirmPassword")}
                    onBlur={this.handleOnBlur("confirmPassword")}
                    onChange={this.handleChange}
                  />
                  {confirmPasswordEye ? (
                    <div
                      class="eyeIcon-confirm-password"
                      onMouseUp={this.showPassword("confirmPassword", false)}
                      onMouseDown={this.showPassword("confirmPassword", true)}
                      onMouseOut={this.showPassword("confirmPassword", false)}
                    >
                      <RemoveRedEyeIcon onClick={this.showPassword} />
                    </div>
                  ) : null}
                </div>
              </div>
              <div class="button-container-login-page">
                <button
                  class="btn btn-login margin-right1"
                  id="continue-as-a-guest"
                  onClick={this.continueAsGuest}
                >
                  Continue As Guest
                </button>
                <button
                  class={
                    this.state.modified ? "btn btn-login" : "btn btn-secondary"
                  }
                  id="signup"
                  onClick={this.signUp}
                  disabled={!this.state.modified}
                >
                  Sign Up
                </button>
                <div class="already-have-account">
                  <p>
                    Already have an account? <br />
                    <a href="#none" onClick={this.login}>
                      Log in here
                    </a>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <Footer1 />
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {};
};
const mapDispatchToProps = {
  signUp,
  guestLogin,
};

export default connect(mapStateToProps, mapDispatchToProps)(UserCreation);
