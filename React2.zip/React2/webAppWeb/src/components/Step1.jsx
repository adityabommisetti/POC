import React, { Component } from "react";
import SimpleReactValidator from "simple-react-validator";
import { connect } from "react-redux";
import moment from "moment";
import Instructions from "./Step1Instructions";
class Step1 extends Component {
  constructor(props) {
    super(props);

    this.state = {
      formerEmpOfSharp: false,
    };
    this.validator = new SimpleReactValidator();
  }
  static getDerivedStateFromProps(nextProps) {
    let selectedPlan = nextProps.selectedPlan;
    console.log(selectedPlan);
    if (
      selectedPlan === "SDAB20" ||
      selectedPlan === "SDABWD20" ||
      selectedPlan === "SDAP20" ||
      selectedPlan === "SDAPWD20"
    ) {
      return { formerEmpOfSharp: true };
    }
  }

  /*async componentWillReceiveProps(nextProps) {
    let selectedPlan = nextProps.selectedPlan;
    console.log(selectedPlan);
    if (
      selectedPlan === "SDAB20" ||
      selectedPlan === "SDABWD20" ||
      selectedPlan === "SDAP20" ||
      selectedPlan === "SDAPWD20"
    ) {
      await this.setState({ formerEmpOfSharp: true });
    }
  }*/
  render() {
    const { data, selectedPlan, year } = this.props;
    const { formerEmpOfSharp } = this.state;
    return (
      <React.Fragment>
        <div class="tab-content">
          <div id="step1" class="container tab-pane active">
            {year === "2021" &&
            (selectedPlan === "SDAGCWD20" ||
              selectedPlan === "SDAGC20" ||
              selectedPlan === "SDAPC20") ? (
              <React.Fragment>
                <Instructions />
                <br />
                <h3 class="tab-heading">
                  Step 1 – All fields on this page are required (unless marked
                  optional)
                </h3>
              </React.Fragment>
            ) : (
              <h3 class="tab-heading">STEP 1: PERSONAL INFORMATION</h3>
            )}
            <div class="form-panel">
              <p>
                <strong>
                  A. To enroll in Sharp Health Plan please provide the following
                  information:
                </strong>
              </p>
              {selectedPlan === "SDAHMO1" || selectedPlan === "SDAHMO20" ? (
                <>
                  <div class="radio radio-tab">
                    <label for="sandiego" class="control-label">
                      Are you the City of San Diego retiree?*
                    </label>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <input
                      type="radio"
                      name="retiree"
                      id="retireey"
                      value="Y"
                      checked={data.retiree === "Y"}
                      onChange={this.props.handleChange}
                    />
                    <label for="sandiego" class="radio-sandiego-retiree">
                      Yes
                    </label>
                    <input
                      type="radio"
                      name="retiree"
                      id="retireen"
                      value="N"
                      checked={data.retiree === "N"}
                      onChange={this.props.handleChange}
                    />
                    <label for="sandiego" class="radio-sandiego-retiree">
                      No
                    </label>
                  </div>
                  {data.retiree === "Y" ? (
                    <>
                      <div class="radio radio-tab">
                        <label
                          for="coveringSpouseOrDependent"
                          class="control-label"
                        >
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;If
                          yes, Are you covering a spouse or dependent ?
                        </label>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input
                          type="radio"
                          name="coveringSpouseOrDependent"
                          id="coveringSpouseOrDependentY"
                          value="Y"
                          checked={data.coveringSpouseOrDependent === "Y"}
                          onChange={this.props.handleChange}
                        />{" "}
                        <label
                          for="coveringSpouseOrDependent"
                          class="radio-sandiego-retiree"
                        >
                          Yes
                        </label>
                        <input
                          type="radio"
                          name="coveringSpouseOrDependent"
                          id="coveringSpouseOrDependentN"
                          value="N"
                          checked={data.coveringSpouseOrDependent === "N"}
                          onChange={this.props.handleChange}
                        />
                        <label
                          for="coveringSpouseOrDependent"
                          class="radio-sandiego-retiree"
                        >
                          {" "}
                          No
                        </label>
                        <label class="control-label">
                          (If yes, complete section below.)
                        </label>
                      </div>

                      {data.coveringSpouseOrDependent === "Y" ? (
                        <>
                          <div class="surviving-spouse-city-SanDiego-retiree">
                            <label class="control-label">
                              Dependent of City of San Diego Retiree:{" "}
                            </label>
                          </div>

                          <div class="surviving-spouse-city-SanDiego-retiree">
                            <div class="col-md-3">
                              <label for="lastName" class="control-label">
                                Last Name:
                              </label>
                              <input
                                type="text"
                                id="coveringSpouseOrDependentLastName"
                                class={"form-control"}
                                value={data.coveringSpouseOrDependentLastName}
                                onChange={this.props.handleChange}
                                name="coveringSpouseOrDependentLastName"
                              />
                            </div>
                            <div class="col-md-3">
                              <label for="firstName" class="control-label">
                                First Name:
                              </label>
                              <input
                                type="text"
                                id="coveringSpouseOrDependentFirstName"
                                name="coveringSpouseOrDependentFirstName"
                                value={data.coveringSpouseOrDependentFirstName}
                                onChange={this.props.handleChange}
                                class={"form-control"}
                              />
                            </div>
                            <div class="col-md-3">
                              <label for="middleInitial" class="control-label">
                                Middle Initial:
                              </label>
                              <input
                                type="text"
                                class="form-control"
                                maxLength="1"
                                value={data.coveringSpouseOrDependentMiddleName}
                                onChange={this.props.handleChange}
                                id="coveringSpouseOrDependentMiddleName"
                                name="coveringSpouseOrDependentMiddleName"
                              />
                            </div>
                          </div>
                          <br />
                          <br />
                          <div class="radio radio-tab">
                            <p class="medicare-note">
                              <strong>NOTE: </strong>If your spouse/dependent is
                              not eligible for Medicare, then he/she will need
                              to complete the Non-Medicare / Early Retiree
                              enrollment form. Please contact SDPEBA at
                              1-888-315-8027 or visit www.sdpeba.org to download
                              the enrollment form.
                            </p>
                          </div>
                        </>
                      ) : data.coveringSpouseOrDependent === "N" ? (
                        <div class="surviving-spouse-city-SanDiego-retiree">
                          <div class="col-md-9">
                            <label class="control-label">
                              If you are not, employee name:
                            </label>
                            <br />
                            <input
                              type="text"
                              class="form-control"
                              name="coveringSpouseOrDependentEmployeeName"
                              id="coveringSpouseOrDependentEmployeeNameId"
                              value={data.coveringSpouseOrDependentEmployeeName}
                              onChange={this.props.handleChange}
                            />
                          </div>
                        </div>
                      ) : null}
                    </>
                  ) : data.retiree === "N" ? (
                    <div class="radio radio-tab">
                      <label
                        for="survivingSpouseCitySanDiegoRetiree"
                        class="control-label"
                      >
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; If you
                        are not, are you the surviving spouse of a City of San
                        Diego Retiree?
                      </label>
                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <input
                        type="radio"
                        name="survivingSpouseCitySanDiegoRetiree"
                        id="survivingSpouseCitySanDiegoRetireeY"
                        value="Y"
                        checked={
                          data.survivingSpouseCitySanDiegoRetiree === "Y"
                        }
                        onChange={this.props.handleChange}
                      />{" "}
                      <label
                        for="survivingSpouseCitySanDiegoRetiree"
                        class="radio-sandiego-retiree"
                      >
                        Yes
                      </label>
                      <input
                        type="radio"
                        name="survivingSpouseCitySanDiegoRetiree"
                        id="survivingSpouseCitySanDiegoRetireeN"
                        value="N"
                        checked={
                          data.survivingSpouseCitySanDiegoRetiree === "N"
                        }
                        onChange={this.props.handleChange}
                      />
                      <label
                        for="survivingSpouseCitySanDiegoRetiree"
                        class="radio-sandiego-retiree"
                      >
                        {" "}
                        No
                      </label>
                      {data.survivingSpouseCitySanDiegoRetiree === "Y" ? (
                        <>
                          <div class="surviving-spouse-city-SanDiego-retiree">
                            <div class="col-md-3">
                              <label for="lastName" class="control-label">
                                Retiree Last Name:
                              </label>
                              <input
                                type="text"
                                id="survivingSpouseCitySanDiegoRetireeLastName"
                                class={"form-control"}
                                value={
                                  data.survivingSpouseCitySanDiegoRetireeLastName
                                }
                                onChange={this.props.handleChange}
                                name="survivingSpouseCitySanDiegoRetireeLastName"
                              />
                            </div>
                            <div class="col-md-3">
                              <label for="firstName" class="control-label">
                                Retiree First Name:
                              </label>
                              <input
                                type="text"
                                id="survivingSpouseCitySanDiegoRetireeFirstName"
                                name="survivingSpouseCitySanDiegoRetireeFirstName"
                                value={
                                  data.survivingSpouseCitySanDiegoRetireeFirstName
                                }
                                onChange={this.props.handleChange}
                                class={"form-control"}
                              />
                            </div>
                            <div class="col-md-3">
                              <label for="middleInitial" class="control-label">
                                Retiree Middle Initial:
                              </label>
                              <input
                                type="text"
                                class="form-control"
                                value={
                                  data.survivingSpouseCitySanDiegoRetireeMiddleName
                                }
                                onChange={this.props.handleChange}
                                id="survivingSpouseCitySanDiegoRetireeMiddleName"
                                name="survivingSpouseCitySanDiegoRetireeMiddleName"
                              />
                            </div>
                          </div>
                          <br />
                          <br />
                          <div class="radio radio-tab">
                            <p class="medicare-note">
                              <strong>NOTE: </strong>If your spouse/dependent is
                              not eligible for Medicare, then he/she will need
                              to complete the Non-Medicare / Early Retiree
                              enrollment form. Please contact SDPEBA at
                              1-888-315-8027 or visit www.sdpeba.org to download
                              the enrollment form.
                            </p>
                          </div>
                        </>
                      ) : null}
                    </div>
                  ) : null}
                </>
              ) : null}

              {formerEmpOfSharp ||
              selectedPlan === "SDAHMO1" ||
              selectedPlan === "SDAHMO20" ? (
                <div class="form-group row">
                  <div class="col-md-3">
                    <label for="effDate" class="control-label">
                      Effective date of coverage*
                    </label>
                    <input
                      class={
                        data.effDate === "" ||
                        !moment(data.effDate, "MM/DD/YYYY", true).isValid()
                          ? "error-input"
                          : "form-control"
                      }
                      maxLength="10"
                      value={data.effDate}
                      onChange={this.props.handleDate}
                      onClick={(e) => this.props.handleDates("effDate")}
                      name="effDate"
                      id="effDate"
                      placeholder="MM/DD/YYYY"
                      required=""
                    />
                  </div>
                  {formerEmpOfSharp ? (
                    <div class="col-md-3">
                      <label for="ssn" class="control-label">
                        Social security number*
                      </label>
                      <input
                        type="text"
                        id="ssn"
                        name="ssn"
                        value={data.ssn}
                        onChange={this.props.handleNumberChange}
                        class={data.ssn === "" ? "error-input" : "form-control"}
                        required=""
                        maxLength="9"
                      />
                    </div>
                  ) : null}
                </div>
              ) : null}
              <div class="form-group row">
                <div class="col-md-3">
                  <fieldset class="radio">
                    <legend>Prefix</legend>
                    <div class="custom-control custom-radio custom-control-inline">
                      <input
                        type="radio"
                        id="mr"
                        name="prefix"
                        class="custom-control-input"
                        value="mr"
                        checked={data.prefix === "mr" ? true : false}
                        onChange={this.props.handleChange}
                      />
                      <label for="mr" class="radio-inline custom-control-label">
                        Mr
                      </label>
                    </div>
                    <div class="custom-control custom-radio custom-control-inline">
                      <input
                        type="radio"
                        id="mrs"
                        name="prefix"
                        class="custom-control-input"
                        value="mrs"
                        checked={data.prefix === "mrs" ? true : false}
                        onChange={this.props.handleChange}
                      />
                      <label
                        for="mrs"
                        class="radio-inline custom-control-label"
                      >
                        Mrs
                      </label>
                    </div>
                    <div class="custom-control custom-radio custom-control-inline">
                      <input
                        type="radio"
                        id="ms"
                        name="prefix"
                        class="custom-control-input"
                        value="ms"
                        checked={data.prefix === "ms" ? true : false}
                        onChange={this.props.handleChange}
                      />
                      <label for="ms" class="radio-inline custom-control-label">
                        Ms
                      </label>
                    </div>
                  </fieldset>
                </div>
                <div class="col-md-3">
                  <label for="firstName" class="control-label">
                    First Name*
                  </label>
                  <input
                    type="text"
                    id="firstName"
                    name="firstName"
                    value={data.firstName}
                    onChange={this.props.handleChange}
                    class={
                      data.firstName === "" ? "error-input" : "form-control"
                    }
                    required=""
                  />
                </div>

                <div class="col-md-3">
                  <label for="lastName" class="control-label">
                    Last Name*
                  </label>
                  <input
                    type="text"
                    id="lastName"
                    class={
                      data.lastName === "" ? "error-input" : "form-control"
                    }
                    value={data.lastName}
                    onChange={this.props.handleChange}
                    name="lastName"
                    required=""
                  />
                </div>
                <div class="col-md-3">
                  <label for="middleInitial" class="control-label">
                    MI:
                  </label>
                  <input
                    type="text"
                    class="form-control"
                    maxLength="1"
                    value={data.middleInitial}
                    onChange={this.props.handleChange}
                    id="middleInitial"
                    name="middleInitial"
                  />
                </div>
              </div>
              <div class="form-group row">
                <div class="col-md-3">
                  <label for="birthDate" class="control-label">
                    Birth Date*
                  </label>
                  <input
                    class={
                      data.birthDate === "" ||
                      !moment(data.birthDate, "MM/DD/YYYY", true).isValid()
                        ? "error-input"
                        : "form-control"
                    }
                    value={data.birthDate}
                    maxLength="10"
                    onChange={this.props.handleDate}
                    onClick={(e) => this.props.handleDates("birthDate")}
                    name="birthDate"
                    id="birthDate"
                    placeholder="MM/DD/YYYY"
                    required=""
                  />
                </div>
                <div class="col-md-3">
                  <fieldset class="radio radio-tab">
                    <legend
                      class={data.sex === "" ? "error-label" : "control-label"}
                    >
                      Sex*
                    </legend>
                    <div class="custom-control custom-radio custom-control-inline">
                      <input
                        type="radio"
                        value="M"
                        onChange={this.props.handleChange}
                        name="sex"
                        id="male"
                        class={
                          data.sex === ""
                            ? "error-input"
                            : "custom-control-input"
                        }
                        style={{ zIndex: -2 }}
                      />
                      <label
                        for="male"
                        class="radio-inline custom-control-label"
                      >
                        Male
                      </label>
                    </div>
                    <div class="custom-control custom-radio custom-control-inline">
                      <input
                        type="radio"
                        value="F"
                        name="sex"
                        onChange={this.props.handleChange}
                        id="female"
                        class={
                          data.sex === ""
                            ? "error-input"
                            : "custom-control-input"
                        }
                        style={{ zIndex: -2 }}
                      />
                      <label
                        for="female"
                        class="radio-inline custom-control-label"
                      >
                        Female
                      </label>
                    </div>
                  </fieldset>
                </div>
                <div class="col-md-3">
                  <label for="primaryPhone" class="control-label">
                    Primary Phone Number*
                  </label>
                  <input
                    type="text"
                    id="primaryPhone"
                    value={data.primaryPhone}
                    onChange={this.props.handleChange}
                    name="primaryPhone"
                    class={
                      data.primaryPhone === "" ||
                      data.primaryPhone.indexOf("(") === -1 ||
                      data.primaryPhone.indexOf(")") === -1
                        ? "error-input"
                        : "form-control"
                    }
                    placeholder="(   )   -"
                    required=""
                    maxLength="14"
                  />
                </div>
                {!(
                  this.props.year === "2021" &&
                  (this.props.selectedPlan === "SDAGCWD20" ||
                    this.props.selectedPlan === "SDAGC20" ||
                    this.props.selectedPlan === "SDAPC20")
                ) ? (
                  <div class="col-md-3">
                    <label for="alternatePhone" class="control-label">
                      Cell Phone Number:
                    </label>
                    <input
                      type="text"
                      id="alternatePhone"
                      name="alternatePhone"
                      value={data.alternatePhone}
                      onChange={this.props.handleChange}
                      class="form-control"
                      placeholder="(   )   -"
                      maxLength="14"
                    />
                  </div>
                ) : null}
              </div>
              <div class="form-group row">
                <div class="col-md-12">
                  <label for="permanentAddrStreet" class="control-label">
                    Permanent Residence Street Address:{" "}
                    <strong>(Don't enter a PO Box)*</strong>
                  </label>
                  <input
                    type="text"
                    name="permanentAddrStreet"
                    id="permanentAddrStreet"
                    value={data.permanentAddrStreet}
                    onChange={this.props.handleChange}
                    class={
                      data.permanentAddrStreet === ""
                        ? "error-input"
                        : "form-control"
                    }
                    required=""
                  />
                </div>
              </div>
              <div class="form-group row">
                <div class="col-md-3">
                  <label for="permanentCity" class="control-label">
                    City*
                  </label>
                  <input
                    type="text"
                    class={
                      data.permanentCity === "" ? "error-input" : "form-control"
                    }
                    value={data.permanentCity}
                    onChange={this.props.handleChange}
                    name="permanentCity"
                    id="permanentCity"
                    required=""
                  />
                </div>

                <div class="col-md-3">
                  <label for="permanentCounty" class="control-label">
                    County
                  </label>
                  <input
                    type="text"
                    style={{ cursor: "not-allowed" }}
                    class="form-control"
                    name="permanentCounty"
                    id="permanentCounty"
                    value="SAN DIEGO"
                    disabled
                  />
                </div>

                <div class="col-md-3">
                  <label for="permanentState" class="control-label">
                    State
                  </label>
                  <input
                    type="text"
                    style={{ cursor: "not-allowed" }}
                    class="form-control"
                    name="permanentState"
                    id="permanentState"
                    value="CA"
                    disabled
                  />
                </div>

                <div class="col-md-3">
                  <label for="permanentZip" class="control-label">
                    ZIP Code*
                  </label>
                  <input
                    type="text"
                    class={
                      data.permanentZip.length < 5
                        ? "error-input"
                        : "form-control"
                    }
                    name="permanentZip"
                    id="permanentZip"
                    minlength="5"
                    value={data.permanentZip}
                    onChange={this.props.handleNumberChange}
                    maxLength="5"
                    required=""
                  />
                </div>
              </div>

              {!(
                year === "2021" &&
                (selectedPlan === "SDAGCWD20" ||
                  selectedPlan === "SDAGC20" ||
                  selectedPlan === "SDAPC20")
              ) ? (
                <React.Fragment>
                  <div class="form-group">
                    <div>
                      <label for="language" class="control-label mr-2">
                        Is the above address different from your mailing address
                        ?
                      </label>
                      <div class="custom-control custom-checkbox custom-control-inline mt-3">
                        <input
                          type="checkbox"
                          name="mailingAddressRequired"
                          id="mailingAddressRequired"
                          class="custom-control-input"
                          checked={data.mailingAddressRequired === "YES"}
                          onChange={this.props.handleCheckbox}
                        />
                        <label
                          for="mailingAddressRequired"
                          class="radio-inline custom-control-label"
                        >
                          <strong>YES</strong>
                        </label>
                      </div>
                    </div>
                  </div>
                  {this.props.data.mailingAddressRequired === "YES" ? (
                    <div id="mailing-adddress">
                      <div class="form-group row">
                        <div class="col-md-12">
                          <label for="mailingAddr" class="control-label">
                            Mailing Address- Street Address/P.O.Box:(Only if
                            different from your Permanent Residential Address)*
                          </label>
                          <input
                            type="text"
                            class={
                              data.mailingAddr === ""
                                ? "error-input"
                                : "form-control"
                            }
                            value={data.mailingAddr}
                            onChange={this.props.handleChange}
                            name="mailingAddr"
                            id="mailingAddr"
                            required=""
                          />
                        </div>
                      </div>
                      <div class="form-group row">
                        <div class="col-md-3">
                          <label for="mailingCity" class="control-label">
                            City*
                          </label>
                          <input
                            type="text"
                            class={
                              data.mailingCity === ""
                                ? "error-input"
                                : "form-control"
                            }
                            value={data.mailingCity}
                            onChange={this.props.handleChange}
                            name="mailingCity"
                            id="mailingCity"
                            required=""
                          />
                        </div>
                        <div class="col-md-3">
                          <label
                            for="mailingState"
                            style={{ marginTop: "1em" }}
                          >
                            State
                          </label>
                          <input
                            type="text"
                            class="form-control"
                            name="mailingState"
                            id="mailingState"
                            value="CA"
                            disabled
                          />
                        </div>
                        <div class="col-md-3">
                          <label for="mailingzip" class="control-label">
                            Zip Code*
                          </label>
                          <input
                            type="text"
                            class={
                              data.mailingzip === ""
                                ? "error-input"
                                : "form-control"
                            }
                            name="mailingzip"
                            id="mailingzip"
                            minlength="5"
                            value={data.mailingzip}
                            onChange={this.props.handleChange}
                            maxLength="5"
                            required=""
                          />
                        </div>
                      </div>
                    </div>
                  ) : null}
                  <div class="form-group row">
                    <div class="col-md-12">
                      <label for="emailAddr" class="control-label">
                        Email Address
                      </label>
                      <input
                        type="email"
                        id="emailAddr"
                        name="emailAddr"
                        value={data.emailAddr}
                        onChange={this.props.handleChange}
                        class={
                          !this.validator.check(data.emailAddr, "email") ||
                          !data.emailAddr.endsWith(".com") ||
                          data.emailAddr === ""
                            ? "error-input"
                            : "form-control"
                        }
                        required=""
                      />
                    </div>
                  </div>
                  <div class="form-group row">
                    <div
                      class="col-md-12"
                      style={{
                        display: formerEmpOfSharp ? "flex" : "none",
                      }}
                    >
                      <div class="checkbox checkbox-tab">
                        <div class="custom-control custom-checkbox custom-control-inline">
                          <input
                            type="checkbox"
                            id="shpmp"
                            name="shpmp"
                            class="custom-control-input"
                            checked={data.shpmp === "Y"}
                            onChange={this.props.handleChange}
                          />
                          <label for="shpmp" class="custom-control-label">
                            <strong>
                              Please call me about the Sharp Health Plan Medical
                              Plan.
                            </strong>
                          </label>
                        </div>
                      </div>
                    </div>

                    <div class="col-md-12">
                      <div class="checkbox checkbox-tab">
                        <div class="custom-control custom-checkbox custom-control-inline">
                          <input
                            type="checkbox"
                            checked={data.emailAlert === "Y"}
                            id="emailAlert"
                            name="emailAlert"
                            defaultChecked
                            class="custom-control-input"
                            onChange={this.props.handleChange}
                          />
                          <label for="emailAlert" class="custom-control-label">
                            {selectedPlan === "SDAHMO1" ||
                            selectedPlan === "SDAHMO20" ? (
                              <strong>
                                Yes, I'd like to receive health plan news and
                                information via email or text message.(Message &
                                data rates may apply)
                              </strong>
                            ) : (
                              <strong>
                                Yes, I'd like to receive health plan news and
                                information via email.
                              </strong>
                            )}
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                </React.Fragment>
              ) : (
                <React.Fragment>
                  <div class="form-group row">
                    <div class="col-md-6">
                      <p>
                        <label for="medicareClaim" class="control-label">
                          Medicare Number*
                        </label>
                        <input
                          type="text"
                          pattern="/[a-zA-Z0-9]{10,11}/"
                          placeholder="XXXXXXXXXXX"
                          name="medicareClaim"
                          id="medicareClaim"
                          minlength="10"
                          maxLength="12"
                          class={
                            data.medicareClaim === "" ||
                            (data.medicareClaim &&
                              data.medicareClaim.length < 10)
                              ? "error-input"
                              : "form-control"
                          }
                          value={data.medicareClaim}
                          onChange={this.props.handleChange}
                          required=""
                        />
                      </p>
                    </div>
                  </div>
                  <div class="form-group row" style={{ marginLeft: "4px" }}>
                    <fieldset
                      class="radio radio-tab mt-3"
                      id="c_qns1"
                      name="c_qns1"
                      onChange={this.props.handleChange}
                      value={data.c_qns1}
                    >
                      <legend>
                        Will you have other drug coverage (like VA, TRICARE) in
                        addition to Sharp Health Plan?{" "}
                      </legend>
                      <div class="custom-control custom-radio custom-control-inline">
                        <input
                          type="radio"
                          name="vaBenefits"
                          id="c_q2_yes"
                          class="custom-control-input"
                          value="Y"
                          checked={data.vaBenefits === "Y"}
                          onChange={this.props.handleChange}
                        />
                        <label
                          for="c_q2_yes"
                          class="radio-inline custom-control-label"
                        >
                          Yes
                        </label>
                      </div>
                      <div class="custom-control custom-radio custom-control-inline">
                        <input
                          type="radio"
                          name="vaBenefits"
                          id="c_q2_no"
                          class="custom-control-input"
                          value="N"
                          checked={data.vaBenefits === "N"}
                          onChange={this.props.handleChange}
                        />
                        <label
                          for="c_q2_no"
                          class="radio-inline custom-control-label"
                        >
                          No
                        </label>
                      </div>
                    </fieldset>
                  </div>
                  {data.vaBenefits === "Y" ? (
                    <div class="row mt-3 mb-2">
                      <div class="col-md-4">
                        <label for="nameOfCov" class="control-label">
                          Name of other coverage * :
                        </label>
                        <input
                          type="text"
                          class={
                            data.nameOfCov === ""
                              ? "error-input"
                              : "form-control"
                          }
                          id="nameOfCov"
                          name="nameOfCov"
                          value={data.nameOfCov}
                          onChange={this.props.handleChange}
                        />
                      </div>
                      <div class="col-md-4">
                        <label
                          for="idOfCov"
                          class="control-label"
                          style={{ width: "356px" }}
                        >
                          Member number for this coverage * :
                        </label>
                        <input
                          type="text"
                          class={
                            data.idOfCov === "" ? "error-input" : "form-control"
                          }
                          id="idOfCov"
                          name="idOfCov"
                          value={data.idOfCov}
                          onChange={this.props.handleChange}
                        />
                      </div>
                      <div class="col-md-4">
                        <label for="groupOfCov" class="control-label">
                          Group number for this coverage * :
                        </label>
                        <input
                          type="text"
                          class={
                            data.groupOfCov === ""
                              ? "error-input"
                              : "form-control"
                          }
                          id="groupOfCov"
                          name="groupOfCov"
                          value={data.groupOfCov}
                          onChange={this.props.handleChange}
                        />
                      </div>
                    </div>
                  ) : null}
                  <div class="card">
                    <h3 class="card-header block-heading">
                      IMPORTANT: Read and sign below
                    </h3>
                    <div class="panel">
                      <div class="card-body">
                        <ul>
                          <li>
                            I must keep both Hospital (Part A) and Medical (Part
                            B) to stay in Sharp Health Plan.
                          </li>
                          <li>
                            By joining this Medicare Advantage Plan, I
                            acknowledge that Sharp Health Plan will share my
                            information with Medicare, who may use it to track
                            my enrollment, to make payments, and for other
                            purposes allowed by Federal law that authorize the
                            collection of this information (see Privacy Act
                            Statement below).
                          </li>
                          <li>
                            Your response to this form is voluntary. However,
                            failure to respond may affect enrollment in the
                            plan.
                          </li>
                          <li>
                            The information on this enrollment form is correct
                            to the best of my knowledge. I understand that if I
                            intentionally provide false information on this
                            form, I will be disenrolled from the plan.
                          </li>
                          <li>
                            I understand that people with Medicare are generally
                            not covered under Medicare while out of the country,
                            except for limited coverage near the U.S. border.
                          </li>
                          <li>
                            I understand that when my Sharp Health Plan coverage
                            begins, I must get all of my medical and
                            prescription drug benefits from Sharp Health Plan.
                            Benefits and services provided by Sharp Health Plan
                            and contained in my Sharp Health Plan "Evidence of
                            Coverage" document (also known as a member contract
                            or subscriber agreement) will be covered. Neither
                            Medicare nor Sharp Health Plan will pay for benefits
                            or services that are not covered.
                          </li>
                          <li>
                            I understand that my signature (or the signature of
                            the person legally authorized to act on my behalf)
                            on this application means that I have read and
                            understand the contents of this application. If
                            signed by an authorized representative (as described
                            above), this signature certifies that:{" "}
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-md-4">
                      <label for="nameSignature" class="control-label">
                        Name*
                      </label>
                      <input
                        type="text"
                        id="nameSignature"
                        name="nameSignature"
                        value={data.nameSignature}
                        onChange={this.props.handleChange}
                        class={
                          this.props.data.nameSignature === ""
                            ? "error-input"
                            : "form-control"
                        }
                      />
                    </div>
                    <div class="col-md-4">
                      <label for="nameSignature" class="control-label">
                        Digital Signature
                      </label>
                      <input
                        type="text"
                        id="nameSignature"
                        name="nameSignature"
                        disabled="true"
                        style={{ cursor: "not-allowed" }}
                        value={data.nameSignature}
                        onChange={this.props.handleChange}
                        class={"form-control"}
                      />
                    </div>
                    <div class="col-md-4">
                      <label for="todaysDate" class="control-label">
                        Today's Date
                      </label>
                      <input
                        type="text"
                        style={{ cursor: "not-allowed" }}
                        id="todaysDate"
                        name="todaysDate"
                        disabled="true"
                        value={data.todaysDate}
                        onChange={this.props.handleChange}
                        class={"form-control"}
                      />
                    </div>
                    <div class="col-md-12">
                      <fieldset
                        class="radio radio-tab mt-3"
                        id="authorizedrep_radio"
                      >
                        <legend>Are you an authorized representative? </legend>
                        <div class="custom-control custom-radio custom-control-inline">
                          <input
                            type="radio"
                            name="AuthorizedRep"
                            id="authorizedRepresentative_Y"
                            class="custom-control-input"
                            value="Y"
                            onChange={this.props.handleChange}
                            checked={data.AuthorizedRep === "Y" ? true : false}
                          />
                          <label
                            for="authorizedRepresentative_Y"
                            class="radio-inline custom-control-label"
                          >
                            Yes
                          </label>
                        </div>
                        <div class="custom-control custom-radio custom-control-inline">
                          <input
                            type="radio"
                            name="AuthorizedRep"
                            id="authorizedRepresentative_no"
                            class="custom-control-input"
                            value="N"
                            onChange={this.props.handleChange}
                          />
                          <label
                            for="authorizedRepresentative_no"
                            class="radio-inline custom-control-label"
                            checked={data.AuthorizedRep === "N" ? true : false}
                          >
                            No
                          </label>
                        </div>
                      </fieldset>
                      <div class="form-group">
                        <strong>
                          If you are the authorized representative, you must
                          sign above and provide the following information:
                        </strong>
                      </div>
                      {data.AuthorizedRep === "Y" ? (
                        <React.Fragment>
                          <div class="row mt-3">
                            <div class="col-md-6">
                              <label
                                class="control-label"
                                for="authorizedrepname"
                              >
                                Name*
                              </label>
                              <input
                                type="text"
                                class={
                                  this.props.data.authorizedrepname === ""
                                    ? "error-input"
                                    : "form-control"
                                }
                                name="authorizedrepname"
                                id="authorizedrepname"
                                required=""
                                value={data.authorizedrepname}
                                onChange={this.props.handleChange}
                              />
                            </div>
                            <div class="col-md-6">
                              <label
                                class="control-label"
                                for="authorizedreprelationship"
                              >
                                Relationship to Enrollee*
                              </label>
                              <select
                                name="authorizedreprelationship"
                                id="authorizedreprelationship"
                                class={
                                  this.props.data.authorizedreprelationship ===
                                  ""
                                    ? "error-input"
                                    : "form-control"
                                }
                                value={data.authorizedreprelationship}
                                onChange={this.props.handleChange}
                              >
                                {this.props.authorizedrelations.map(
                                  (item, i) => {
                                    return (
                                      <option
                                        class="select-option"
                                        value={item.value}
                                        key={i}
                                      >
                                        {item.label}
                                      </option>
                                    );
                                  }
                                )}
                              </select>
                            </div>
                          </div>
                          <div class="row mt-3">
                            <div class="col-md-8">
                              <label
                                class="control-label"
                                for="authorizedRepAddr"
                              >
                                Address*
                              </label>
                              <input
                                type="text"
                                class={
                                  this.props.data.authorizedrepaddress === ""
                                    ? "error-input"
                                    : "form-control"
                                }
                                id="authorizedRepAddr"
                                name="authorizedrepaddress"
                                value={data.authorizedrepaddress}
                                onChange={this.props.handleChange}
                                required=""
                              />
                            </div>
                            <div class="col-md-4">
                              <label
                                class="control-label"
                                for="authorizedrepphone"
                              >
                                Phone Number*
                              </label>
                              <input
                                type="text"
                                name="authorizedrepphone"
                                id="authorizedrepphone"
                                class={
                                  this.props.data.authorizedrepphone === ""
                                    ? "error-input"
                                    : "form-control"
                                }
                                placeholder="(   )   -"
                                required=""
                                maxLength="14"
                                value={data.authorizedrepphone}
                                onChange={this.props.handleChange}
                              />
                            </div>
                          </div>
                        </React.Fragment>
                      ) : null}
                      <fieldset
                        class="radio radio-tab mt-3"
                        id="licensed_sales_representative_radio"
                      >
                        <legend>
                          Are you working with a Licensed Sales Representative?
                        </legend>
                        <div class="custom-control custom-radio custom-control-inline">
                          <input
                            type="radio"
                            name="AgentAssistingEnrollment"
                            id="licensedSalesRepresentative_Y"
                            class="custom-control-input"
                            value="Y"
                            onChange={this.props.handleChange}
                            checked={
                              data.AgentAssistingEnrollment === "Y"
                                ? true
                                : false
                            }
                          />
                          <label
                            for="licensedSalesRepresentative_Y"
                            class="radio-inline custom-control-label"
                          >
                            Yes
                          </label>
                        </div>
                        <div class="custom-control custom-radio custom-control-inline">
                          <input
                            type="radio"
                            name="AgentAssistingEnrollment"
                            id="licensedSalesRepresentative_no"
                            class="custom-control-input"
                            value="N"
                            onChange={this.props.handleChange}
                          />
                          <label
                            for="licensedSalesRepresentative_no"
                            class="radio-inline custom-control-label"
                          >
                            No
                          </label>
                        </div>
                      </fieldset>
                      {data.AgentAssistingEnrollment === "Y" ? (
                        <React.Fragment>
                          <div class="row">
                            <div class="col-md-6">
                              <label
                                class="control-label"
                                for="salesRepresentativeName"
                              >
                                Sales Representative Name*
                              </label>
                              <input
                                type="text"
                                class={
                                  this.props.data.nameAgent === ""
                                    ? "error-input"
                                    : "form-control"
                                }
                                name="nameAgent"
                                id="salesRepresentativeName"
                                required=""
                                onChange={this.props.handleChange}
                                value={data.nameAgent}
                              />
                            </div>
                            <div class="col-md-6">
                              <label
                                class="control-label"
                                for="salesRepresentativeLicenseNumber"
                              >
                                Sales Representative License Number
                              </label>
                              <input
                                type="text"
                                class="form-control"
                                name="agentLicense"
                                id="salesRepresentativeLicenseNumber"
                                required=""
                                onChange={this.props.handleChange}
                                value={data.agentLicense}
                              />
                            </div>
                          </div>
                        </React.Fragment>
                      ) : null}
                    </div>
                  </div>
                </React.Fragment>
              )}

              <p class="medicare-note">
                <strong>NOTE:</strong> You may save and continue without
                completing all required fields (*); however, all required fields
                must be completed before submitting the enrollment form.
              </p>
              <button
                class="btn btn-saveNext"
                id="next1"
                onClick={this.props.redirect}
              >
                Save and Next
              </button>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    year: state.webApp.year,
  };
};
export default connect(mapStateToProps)(Step1);
