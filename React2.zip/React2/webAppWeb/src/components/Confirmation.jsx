import React from "react";
import { connect } from "react-redux";
import Footer1 from "../Utils/GenericUI/Footer1.jsx";

const Confirmation = (props) => {
  return (
    <React.Fragment>
      <div class="jumbotron" style={{ paddingBottom: "0px", marginBottom: "0px", bottom: "0px" }}>
        <div class="container">
          <div class="enroll-header-content enroll-header-bg">
            <h2>{props.year} Sharp Direct Advantage Individual Enrollment Form</h2>
            <p>
              Thank you for choosing Sharp Health Plan. Your Medicare enrollment
              form has been submitted successfully and confirmation number is :
              {props.count}, if there are any questions we will contact you.
              Click below to download and print a complete version of your form
              to keep for your records
            </p>
            <p align="center">
              <a
                class="btn-shp btn-shp-teal-download"
                id="downloadPdf"
                href={
                  process.env.NODE_ENV === "development"
                    ? "https://techrefresh.medadvantage360.com/webapp-api/sharp/individual/Download"
                    : "/webapp-api/sharp/individual/Download"
                }
              >
                DOWNLOAD PDF VERSION
              </a>
            </p>
          </div>
        </div>
      </div>

      <Footer1 />
    </React.Fragment>
  );
};

const mapStateToProps = (state) => {
  return {
    count: state.webApp.count,
    year: state.webApp.year
  };
};
const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(Confirmation);
