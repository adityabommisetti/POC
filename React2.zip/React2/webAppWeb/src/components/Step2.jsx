import React, { Component } from "react";
import SimpleReactValidator from "simple-react-validator";
export default class Step1 extends Component {
  constructor(props) {
    super(props);

    this.state = {
      formerEmpOfSharp: false,
    };
    this.validator = new SimpleReactValidator();
  }

  async componentWillReceiveProps(nextProps) {
    let selectedPlan = nextProps.selectedPlan;
    if (
      selectedPlan === "SDAB20" ||
      selectedPlan === "SDABWD20" ||
      selectedPlan === "SDAP20" ||
      selectedPlan === "SDAPWD20"
    ) {
      await this.setState({ formerEmpOfSharp: true });
    }
  }

  render() {
    const { data, selectedPlan } = this.props;
    const { formerEmpOfSharp } = this.state;
    console.log(
      !this.validator.check(data.emailAddr, "email") ||
        !data.emailAddr.endsWith(".com") ||
        data.emailAddr === ""
    );

    return (
      <React.Fragment>
        <div class="tab-content">
          <div id="step1" class="container tab-pane active">
            <h3 class="tab-heading">
              Step 2 – All fields on this page are optional
            </h3>
            <div class="form-panel">
              <p>
                <strong>
                  A. Answering these questions is your choice. You can’t be
                  denied coverage because you don’t fill them out.
                </strong>
              </p>
              <div class="form-group">
                <div>
                  <label for="language" class="control-label mr-2">
                    Select one if you want us to send you information in a
                    language other than English.
                  </label>
                  <div class="custom-control custom-checkbox custom-control-inline mt-3">
                    <input
                      type="checkbox"
                      name="language"
                      id="language"
                      class="custom-control-input"
                      value="Spanish"
                      onChange={this.props.handleChange}
                    />
                    <label
                      for="language"
                      class="radio-inline custom-control-label"
                    >
                      Spanish
                    </label>
                  </div>
                </div>
                <fieldset class="radio radio-tab mt-3">
                  <legend>
                    Select one if you want us to send you information in an
                    accessible format.
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline mt-1">
                    <input
                      type="radio"
                      name="languageValue"
                      id="lfp_braille"
                      class="custom-control-input"
                      value="BRAILLE"
                      checked={data.languageValue === "BRAILLE"}
                      onChange={this.props.handleChange}
                    />
                    <label
                      for="lfp_braille"
                      class="radio-inline custom-control-label"
                    >
                      Braille
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline mt-1">
                    <input
                      type="radio"
                      name="languageValue"
                      id="lfp_largeprint"
                      class="custom-control-input"
                      value="LARGE_PRINT"
                      checked={data.languageValue === "LARGE_PRINT"}
                      onChange={this.props.handleChange}
                    />
                    <label
                      for="lfp_largeprint"
                      class="radio-inline custom-control-label"
                    >
                      Large Print
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline mt-1">
                    <input
                      type="radio"
                      name="languageValue"
                      id="lfp_other"
                      class="custom-control-input"
                      value="OTHER"
                      checked={data.languageValue === "OTHER"}
                      onChange={this.props.handleChange}
                    />
                    <label
                      for="lfp_other"
                      class="radio-inline custom-control-label"
                    >
                      Other
                    </label>
                  </div>
                  <div
                    class="custom-control custom-control-inline mt-1"
                    style={{ width: "500px" }}
                  >
                    <input
                      type="text"
                      id="otherlanguageValue"
                      name="languageValue"
                      value={
                        data.languageValue === "BRAILLE" ||
                        data.languageValue === "LARGE_PRINT" ||
                        data.languageValue === "OTHER"
                          ? ""
                          : data.languageValue
                      }
                      disabled={
                        data.languageValue === "" ||
                        data.languageValue === "BRAILLE" ||
                        data.languageValue === "LARGE_PRINT"
                      }
                      onChange={this.props.handleChange}
                      class={"form-control"}
                    />
                  </div>
                </fieldset>
                <br />
                <p class="medicare-note">
                  Please contact Sharp Health Plan at
                  <a href="tel:1-855-562-8853"> 1-855-562-8853 </a>
                  if you need information in an accessible format other than
                  what’s listed above. Our office hours are . TTY users can call
                  711.
                </p>
              </div>
              <div class="form-group">
                <p>
                  <strong>
                    B. Please choose a Primary Care Physician (PCP)
                  </strong>
                </p>
                <p class="medicare-note">
                  Need to find a doctor? Visit &nbsp;
                  <a href="https://sharpmedicareadvantage.com/findadoctor">
                    sharpmedicareadvantage.com/findadoctor
                  </a>
                  &nbsp; to use our online search tool.
                </p>
                <div class="row mt-3">
                  <div class="col-md-6">
                    <label for="pcpName" class="control-label">
                      PCP Name:*
                    </label>
                    <select
                      name="pcpName"
                      id="pcpName"
                      class={
                        data.pcpName === "" ? "error-input" : "form-control"
                      }
                      onChange={this.props.pcpChange}
                      value={data.pcpName}
                    >
                      {this.props.physicians.map((item, i) => {
                        return (
                          <option
                            class="select-option"
                            value={item.value}
                            key={i}
                          >
                            {item.label}
                          </option>
                        );
                      })}
                    </select>
                  </div>
                  <div class="col-md-6">
                    <label for="pcpMedicalGroupName" class="control-label">
                      Clinic Name:*
                    </label>
                    <input
                      type="text"
                      id="pcpMedicalGroupName"
                      name="pcpMedicalGroupName"
                      value={data.pcpMedicalGroupName}
                      onChange={this.props.handleChange}
                      style={{ cursor: "not-allowed" }}
                      disabled="true"
                      class={
                        data.pcpMedicalGroupName === ""
                          ? "error-input"
                          : "form-control"
                      }
                    />
                  </div>
                </div>
                <div class="row mt-3">
                  <div class="col-md-4">
                    <fieldset class="radio radio-tab mt-3">
                      <legend>Are you a current patient?</legend>
                      <div class="custom-control custom-radio custom-control-inline">
                        <input
                          type="radio"
                          name="existingp"
                          id="currentPatient_Y"
                          class="custom-control-input"
                          value="Y"
                          checked={data.existingp === "Y"}
                          onChange={this.props.handleChange}
                        />
                        <label
                          for="currentPatient_Y"
                          class="radio-inline custom-control-label"
                        >
                          Yes
                        </label>
                      </div>
                      <div class="custom-control custom-radio custom-control-inline">
                        <input
                          type="radio"
                          name="existingp"
                          id="currentPatient_no"
                          class="custom-control-input"
                          value="N"
                          checked={data.existingp === "N"}
                          onChange={this.props.handleChange}
                        />
                        <label
                          for="currentPatient_no"
                          class="radio-inline custom-control-label"
                        >
                          No
                        </label>
                      </div>
                    </fieldset>
                  </div>
                  <div class="col-md-4">
                    <fieldset class="radio radio-tab mt-3">
                      <legend>Do you work?</legend>
                      <div class="custom-control custom-radio custom-control-inline mt-1">
                        <input
                          type="radio"
                          name="youwork"
                          id="dDoYouWork_Yes"
                          class="custom-control-input"
                          value="Y"
                          checked={data.youwork === "Y"}
                          onChange={this.props.handleChange}
                        />
                        <label
                          for="dDoYouWork_Yes"
                          class="radio-inline custom-control-label"
                        >
                          Yes
                        </label>
                      </div>
                      <div class="custom-control custom-radio custom-control-inline mt-1">
                        <input
                          type="radio"
                          name="youwork"
                          id="dDoYouWork_No"
                          class="custom-control-input"
                          value="N"
                          checked={data.youwork === "N"}
                          onChange={this.props.handleChange}
                        />
                        <label
                          for="dDoYouWork_No"
                          class="radio-inline custom-control-label"
                        >
                          No
                        </label>
                      </div>
                    </fieldset>
                  </div>
                  <div class="col-md-4">
                    <fieldset class="radio radio-tab mt-3">
                      <legend class="margin-left-0p5">
                        Does your spouse work?
                      </legend>
                      <div class="custom-control custom-radio custom-control-inline mt-1">
                        <input
                          type="radio"
                          name="spousework"
                          id="dDoYourSpouseWork_Yes"
                          class="custom-control-input"
                          value="Y"
                          checked={data.spousework === "Y"}
                          onChange={this.props.handleChange}
                        />
                        <label
                          for="dDoYourSpouseWork_Yes"
                          class="radio-inline custom-control-label"
                        >
                          Yes
                        </label>
                      </div>
                      <div class="custom-control custom-radio custom-control-inline mt-1">
                        <input
                          type="radio"
                          name="spousework"
                          id="dDoYourSpouseWork_No"
                          class="custom-control-input"
                          value="N"
                          checked={data.spousework === "N"}
                          onChange={this.props.handleChange}
                        />
                        <label
                          for="dDoYourSpouseWork_No"
                          class="radio-inline custom-control-label"
                        >
                          No
                        </label>
                      </div>
                    </fieldset>
                  </div>
                </div>
                <div class="row mt-3">
                  <div class="col-md-12">
                    <label for="clinicName" class="control-label">
                      E-mail Address*:
                    </label>
                    <input
                      type="text"
                      id="emailAddr"
                      name="emailAddr"
                      value={data.emailAddr}
                      onChange={this.props.handleChange}
                      class={
                        this.validator.check(data.emailAddr, "email") &&
                        data.emailAddr.endsWith(".com") &&
                        data.emailAddr !== ""
                          ? "form-control"
                          : "error-input"
                      }
                    />
                    <div class="checkbox checkbox-tab mt-1">
                      <div class="custom-control custom-checkbox custom-control-inline ml-0">
                        <input
                          type="checkbox"
                          checked={data.emailAlert === "Y" ? true : false}
                          id="emailAlert"
                          name="emailAlert"
                          defaultChecked
                          class="custom-control-input"
                          onChange={this.props.handleChange}
                        />
                        <label for="emailAlert" class="custom-control-label">
                          Email Option Ind
                        </label>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-12 mt-2">
                    <h4>Paying your plan premiums</h4>
                    <p>
                      You can pay your monthly plan premium (including any late
                      enrollment penalty that you currently have or may owe) by
                      mail, Electronic Funds Transfer (EFT) or credit card each
                      month.
                      <strong>
                        You can also choose to pay your premium by having it
                        automatically taken out of your Social Security or
                        Railroad Retirement Board (RRB) benefit each month.
                      </strong>
                    </p>
                    <p>
                      <strong>
                        If you have to pay a Part D-Income Related Monthly
                        Adjustment Amount (Part D-IRMAA), you must pay this
                        extra amount in addition to your plan premium.
                      </strong>
                      The amount is usually taken out of your Social Security
                      benefit, or you may get a bill from Medicare (or the RRB).
                      DON'T pay Sharp Health Plan the Part D-IRMAA.
                    </p>
                  </div>
                </div>
              </div>
              <button
                class="btn btn-saveNext"
                id="next2"
                onClick={this.props.redirect}
                style={{ backgroundColor: "#603167" }}
              >
                Save and Next
              </button>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}
