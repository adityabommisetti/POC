import React, { Component } from "react";

export default class Step4 extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const { data,selectedPlan } = this.props;
    return (
      <React.Fragment>
        <div class="tab-content">
          <div id="step4" class="container tab-pane active">
            {/* <div id="step4" class="container tab-pane fade"> */}
            <h3 class="tab-heading">STEP 4: READ AND SIGN</h3>
            <h4 class="mb-3 text-center">
              Please Read This Important Information
            </h4>
            {selectedPlan === "SDAHMO1" ||
            selectedPlan ===  "SDAHMO20" ?
            <span>
            <p>
              Sharp Direct Advantage is an HMO plan with a Medicare contract.
              Enrollment in Sharp Direct Advantage depends on contract renewal.
            </p>
            <p>
              This information is not a complete description of benefits.
              Contact the plan for more information. Limitations, copayments,
              and restrictions may apply. Benefits, premiums and/or
              co-payments/co-insurance may change on January 1 or each year. You
              must continue to pay your Medicare Part B premium.
            </p>
            <p>
              If you currently have health coverage from an employer or union,
              joining Sharp Direct Advantage could affect your employer or union
              health benefits. You could lose your employer or union health
              coverage if you join Sharp Direct Advantage. Read the communications
              your employer or union sends you. If you have questions, visit
              their website, or contact the office listed in their
              communications. If there isn't any information on whom to contact,
              your benefits administrator or the office that answers questions
              about your coverage can help.
            </p>
            <p>
              <strong>
                PLEASE READ AND SIGN BELOW
                <br />
                By completing this enrollment application, I agree to the
                following:
              </strong>
            </p>
            <p>
              Sharp Direct Advantage is a Medicare Advantage plan and has a contract
              with the Federal government. I will need to keep my Medicare Parts
              A and B. I can be in only one Medicare Advantage plan at a time
              and I understand that my enrollment in this plan will
              automatically end my enrollment in another Medicare Direct Advantage or
              prescription drug plan. It is my responsibility to inform you of
              any prescription drug coverage that I have or may get in the
              future. Enrollment in this plan is generally for the entire year.
              Once I enroll, I may leave this plan or make changes only at
              certain times of the year when an enrollment period is available
              (Example: October 15 - December 7 of every year), or under certain
              special circumstances.
            </p>
            <p>
              Sharp Direct Advantage serves a specific service area. If I move out of
              the area that Sharp Direct Advantage serves, I need to notify the plan
              so I can disenroll and find a new plan in my new area. Once I am a
              member of Sharp Direct Advantage, I have the right to appeal plan
              decisions about payment or services if I disagree. I will read the
              Evidence of Coverage document from Sharp Direct Advantage when I get it
              to know which rules I must follow to get coverage with this
              Medicare Advantage plan. I understand that people with Medicare
              aren't usually covered under Medicare while out of the country
              except for limited coverage near the U.S. border.
            </p>
            <p>
              I understand that beginning on the date Sharp Direct Advantage coverage
              begins, I must get all of my health care from Sharp Direct Advantage,
              except for emergency or urgently needed services or out-of-area
              dialysis services. Services authorized by Sharp Direct Advantage and
              other services contained in my Sharp Direct Advantage Evidence of
              Coverage document (also known as a member contract or subscriber
              agreement) will be covered. Without authorization,
              <strong>
                NEITHER MEDICARE NOR SHARP Direct Advantage WILL PAY FOR THE
                SERVICES.
              </strong>
            </p>
            <p>
              I understand that if I am getting assistance from a sales agent,
              broker, or other individual employed by or contracted with Sharp
              Direct Advantage, he/she may be paid based on my enrollment in Sharp
              Direct Advantage.
            </p>
            <p>
              <strong>Release of Information:</strong> By joining this Medicare
              Direct Advantage, I acknowledge that Sharp Direct Advantage will release my
              information to Medicare and other plans as is necessary for
              treatment, payment and health care operations. I also acknowledge
              that Sharp Direct Advantage will release my information including my
              prescription drug event data to Medicare, who may release it for
              research and other purposes that follow all applicable Federal
              statutes and regulations. The information on this enrollment form
              is correct to the best of my knowledge. I understand that if I
              intentionally provide false information on this form, I will be
              disenrolled from the plan.
            </p>
            <p>
              I understand that my signature (or the signature of the person
              authorized to act on my behalf under the laws of the State where I
              live) on this application means that I have read and understand
              the contents of this application. If signed by an authorized
              individual (as described above), this signature certifies that: 1)
              this person is authorized under State law to complete this
              enrollment, and 2) documentation of this authority is available
              upon request from Medicare.
            </p>
            </span>
            :
            <span>
             <p>
              Sharp Health Plan is an HMO plan with a Medicare contract.
              Enrollment in Sharp Health Plan depends on contract renewal.
            </p>
            <p>
              This information is not a complete description of benefits.
              Contact the plan for more information. Limitations, copayments,
              and restrictions may apply. Benefits, premiums and/or
              co-payments/co-insurance may change on January 1 or each year. You
              must continue to pay your Medicare Part B premium.
            </p>
            <p>
              If you currently have health coverage from an employer or union,
              joining Sharp Health Plan could affect your employer or union
              health benefits. You could lose your employer or union health
              coverage if you join Sharp Health Plan. Read the communications
              your employer or union sends you. If you have questions, visit
              their website, or contact the office listed in their
              communications. If there isn't any information on whom to contact,
              your benefits administrator or the office that answers questions
              about your coverage can help.
            </p>
            <p>
              <strong>
                PLEASE READ AND SIGN BELOW
                <br />
                By completing this enrollment application, I agree to the
                following:
              </strong>
            </p>
            <p>
              Sharp Health Plan is a Medicare Advantage plan and has a contract
              with the Federal government. I will need to keep my Medicare Parts
              A and B. I can be in only one Medicare Advantage plan at a time
              and I understand that my enrollment in this plan will
              automatically end my enrollment in another Medicare health plan or
              prescription drug plan. It is my responsibility to inform you of
              any prescription drug coverage that I have or may get in the
              future. Enrollment in this plan is generally for the entire year.
              Once I enroll, I may leave this plan or make changes only at
              certain times of the year when an enrollment period is available
              (Example: October 15 - December 7 of every year), or under certain
              special circumstances.
            </p>
            <p>
              Sharp Health Plan serves a specific service area. If I move out of
              the area that Sharp Health Plan serves, I need to notify the plan
              so I can disenroll and find a new plan in my new area. Once I am a
              member of Sharp Health Plan, I have the right to appeal plan
              decisions about payment or services if I disagree. I will read the
              Evidence of Coverage document from Sharp Health Plan when I get it
              to know which rules I must follow to get coverage with this
              Medicare Advantage plan. I understand that people with Medicare
              aren't usually covered under Medicare while out of the country
              except for limited coverage near the U.S. border.
            </p>
            <p>
              I understand that beginning on the date Sharp Health Plan coverage
              begins, I must get all of my health care from Sharp Health Plan,
              except for emergency or urgently needed services or out-of-area
              dialysis services. Services authorized by Sharp Health Plan and
              other services contained in my Sharp Health Plan Evidence of
              Coverage document (also known as a member contract or subscriber
              agreement) will be covered. Without authorization,
              <strong>
                NEITHER MEDICARE NOR SHARP HEALTH PLAN WILL PAY FOR THE
                SERVICES.
              </strong>
            </p>
            <p>
              I understand that if I am getting assistance from a sales agent,
              broker, or other individual employed by or contracted with Sharp
              Health Plan, he/she may be paid based on my enrollment in Sharp
              Health Plan.
            </p>
            <p>
              <strong>Release of Information:</strong> By joining this Medicare
              health plan, I acknowledge that Sharp Health Plan will release my
              information to Medicare and other plans as is necessary for
              treatment, payment and health care operations. I also acknowledge
              that Sharp Health Plan will release my information including my
              prescription drug event data to Medicare, who may release it for
              research and other purposes that follow all applicable Federal
              statutes and regulations. The information on this enrollment form
              is correct to the best of my knowledge. I understand that if I
              intentionally provide false information on this form, I will be
              disenrolled from the plan.
            </p>
            <p>
              I understand that my signature (or the signature of the person
              authorized to act on my behalf under the laws of the State where I
              live) on this application means that I have read and understand
              the contents of this application. If signed by an authorized
              individual (as described above), this signature certifies that: 1)
              this person is authorized under State law to complete this
              enrollment, and 2) documentation of this authority is available
              upon request from Medicare.
            </p></span>}

            <h4 class="mb-3 text-center">
              I ACCEPT THE TERMS OF THIS AGREEMENT
            </h4>
            <div class="row">
              <div class="col-xs-12 col-md-4 col-lg-4">
                <label class="control-label" for="nameSignature">
                  Name*
                </label>
                <input
                  type="text"
                  class={
                    this.props.data.nameSignature === ""
                      ? "error-input"
                      : "form-control"
                  }
                  id="nameSignature"
                  name="nameSignature"
                  required=""
                  value={data.nameSignature}
                  onChange={this.props.handleChange}
                />
              </div>
              <div class="col-xs-12 col-md-4 col-lg-4">
                <label class="control-label" for="digitalSignature">
                  Digital Signature
                </label>
                <input
                  type="text"
                  class="form-control"
                  id="digitalSignature"
                  disabled="disabled"
                  name="digisignature"
                  value={data.nameSignature}
                />
              </div>
              <div class="col-xs-12 col-md-4 col-lg-4">
                <label class="control-label" for="todaysDate">
                  Today's Date
                </label>
                <input
                  type="text"
                  class="form-control"
                  name="todaysDate"
                  id="todaysDate"
                  disabled="disabled"
                  value={data.nameSignature!==""?data.todaysDate:null}
                />
              </div>
            </div>
            <div class="row">
              <div class="col-xs-12 col-md-12 col-lg-12">
                <fieldset class="radio radio-tab mt-3" id="authorizedrep_radio">
                  <legend>Are you an authorized representative? </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="AuthorizedRep"
                      id="authorizedRepresentative_Y"
                      class="custom-control-input"
                      value="Y"
                      onChange={this.props.handleChange}
                      checked={data.AuthorizedRep === "Y" ? true : false}
                    />
                    <label
                      for="authorizedRepresentative_Y"
                      class="radio-inline custom-control-label"
                    >
                      Yes
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="AuthorizedRep"
                      id="authorizedRepresentative_no"
                      class="custom-control-input"
                      value="N"
                      onChange={this.props.handleChange}
                    />
                    <label
                      for="authorizedRepresentative_no"
                      class="radio-inline custom-control-label"
                      checked={data.AuthorizedRep === "N" ? true : false}
                    >
                      No
                    </label>
                  </div>
                </fieldset>
              </div>
            </div>

            <p style={{marginTop:"1.5rem"}}>
             <b> If you are the authorized representative, you must sign above and
              provide the following information:</b>
            </p>
            {data.AuthorizedRep === "Y" ? (
              <React.Fragment>
                <div class="row mt-3">
                  <div class="col-md-6">
                    <label class="control-label" for="authorizedrepname">
                      Name*
                    </label>
                    <input
                      type="text"
                      class={
                        this.props.data.authorizedrepname === ""
                          ? "error-input"
                          : "form-control"
                      }
                      name="authorizedrepname"
                      id="authorizedrepname"
                      required=""
                      value={data.authorizedrepname}
                      onChange={this.props.handleChange}
                    />
                  </div>
                  <div class="col-md-6">
                    <label
                      class="control-label"
                      for="authorizedreprelationship"
                    >
                      Relationship to Enrollee*
                    </label>
                    <select
                      name="authorizedreprelationship"
                      id="authorizedreprelationship"
                      class={
                        this.props.data.authorizedreprelationship === ""
                          ? "error-input"
                          : "form-control"
                      }
                      value={data.authorizedreprelationship}
                      onChange={this.props.handleChange}
                    >
                      {this.props.authorizedrelations.map((item, i) => {
                        return (
                          <option
                            class="select-option"
                            value={item.value}
                            key={i}
                          >
                            {item.label}
                          </option>
                        );
                      })}
                    </select>
                  </div>
                </div>
                <div class="row mt-3">
                  <div class="col-md-8">
                    <label class="control-label" for="authorizedRepAddr">
                      Address*
                    </label>
                    <input
                      type="text"
                      class={
                        this.props.data.authorizedrepaddress === ""
                          ? "error-input"
                          : "form-control"
                      }
                      id="authorizedRepAddr"
                      name="authorizedrepaddress"
                      value={data.authorizedrepaddress}
                      onChange={this.props.handleChange}
                      required=""
                    />
                  </div>
                  <div class="col-md-4">
                    <label class="control-label" for="authorizedrepphone">
                      Phone Number*
                    </label>
                    <input
                      type="text"
                      name="authorizedrepphone"
                      id="authorizedrepphone"
                      class={
                        this.props.data.authorizedrepphone === ""
                          ? "error-input"
                          : "form-control"
                      }
                      placeholder="(   )   -"
                      required=""
                      maxlength="14"
                      value={data.authorizedrepphone}
                      onChange={this.props.handleChange}
                    />
                  </div>
                </div>
              </React.Fragment>
            ) : null}
            <div class="row mt-3">
              <div class="col-xs-12 col-md-12 col-lg-12">
                <fieldset
                  class="radio radio-tab mt-3"
                  id="licensed_sales_representative_radio"
                >
                  <legend style={{fontWeight:"bold"}}>
                    Are you working with a Licensed Sales Representative?
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="AgentAssistingEnrollment"
                      id="licensedSalesRepresentative_Y"
                      class="custom-control-input"
                      value="Y"
                      onChange={this.props.handleChange}
                      checked={
                        data.AgentAssistingEnrollment === "Y" ? true : false
                      }
                    />
                    <label
                      for="licensedSalesRepresentative_Y"
                      class="radio-inline custom-control-label"
                    >
                      Yes
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                    <input
                      type="radio"
                      name="AgentAssistingEnrollment"
                      id="licensedSalesRepresentative_no"
                      class="custom-control-input"
                      value="N"
                      onChange={this.props.handleChange}
                    />
                    <label
                      for="licensedSalesRepresentative_no"
                      class="radio-inline custom-control-label"
                    >
                      No
                    </label>
                  </div>
                </fieldset>
              </div>
            </div>
            {data.AgentAssistingEnrollment === "Y" ? (
              <React.Fragment>
                <div class="row">
                  <div class="col-md-6">
                    <label class="control-label" for="salesRepresentativeName">
                      Sales Representative Name*
                    </label>
                    <input
                      type="text"
                      class={
                        this.props.data.nameAgent === ""
                          ? "error-input"
                          : "form-control"
                      }
                      name="nameAgent"
                      id="salesRepresentativeName"
                      required=""
                      onChange={this.props.handleChange}
                      value={data.nameAgent}
                    />
                  </div>
                  <div class="col-md-6">
                    <label
                      class="control-label"
                      for="salesRepresentativeLicenseNumber"
                    >
                      Sales Representative License Number
                    </label>
                    <input
                      type="text"
                      class="form-control"
                      name="agentLicense"
                      id="salesRepresentativeLicenseNumber"
                      required=""
                      onChange={this.props.handleChange}
                      value={data.agentLicense}
                    />
                  </div>
                </div>
              </React.Fragment>
            ) : null}

            <p class="mt-3">
              <strong>NOTE:</strong> You may save and continue without
              completing all required fields (*); however, all required fields
              must be completed before submitting the enrollment form.
            </p>
            <button
              class="btn btn-saveNext"
              id="next4"
              onClick={this.props.redirect}
              style={{backgroundColor:"#603167"}}
            >
              Save and Next
            </button>
          </div>
        </div>
      </React.Fragment>
    );
  }
}
