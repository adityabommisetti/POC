import React from "react";
import history from "../../Utils/History";
import { connect } from "react-redux";
const subHeader = (header) => {
  let subHedar = "";
  subHedar = (
    <React.Fragment>
      <div class="jumbotron" style={{ paddingBottom: "0vh" }}>
        <div class="container">
          <div class="enroll-header-content enroll-header-bg">
            <h2>
              {header.substring(0, 4)} Sharp Direct Advantage Enrollment Form
            </h2>
            <p>
              This plan is open to all Medicare-eligible residents of San Diego
              County
            </p>
          </div>
          <div style={{ textAlign: "left" }}>
            <div>
              <div class="plan-title pull-left">
                <span style={{ padding: "10px" }}>{header}</span>
                <a
                  class="teal pull-left change-plan"
                  href="none"
                  onClick={(e) => {
                    e.preventDefault();

                    if (localStorage.getItem("guestLogin") === "true")
                      history.push(
                        "/webapp/Sharp/Individual/yearSelectionGuest"
                      );
                    else history.push("/webapp/Sharp/Individual/yearSelection");
                  }}
                >
                  Change My Plan
                </a>
              </div>
            </div>
            {/* <div>
              This plan is open to all Medicare-eligible City of San Diego
              retirees, sponsored by San Diego Public Employee Benefit
              Association (SDPEBA). SDPEBA membership is not required to join
              this plan.
            </div>
            <br />{" "}
            <div>
              <strong>Important Information</strong>
            </div>
            <br />
            <div>
              The Medicare application is intended for individual coverage only.
              If you and your spouse/ dependent are both applying for coverage,
              then each of you will need to complete a separate enrollment form.
              <p>
                Note – If your spouse/dependent is not eligible for Medicare,
                then he/she will need to complete the Non-Medicare / Early
                Retiree, enrollment form. Please contact SDPEBA at
                1-888-315-8027 or visit www.sdpeba.org to download the
                enrollment form
              </p>
            </div> */}
            <div>
              Please contact Sharp Health Plan if you need information in
              another language or format.&nbsp;&nbsp;
              <a
                class="contact-us"
                href="https://www.sharpmedicareadvantage.com/contact-us/contact-information"
              >
                <strong>CONTACT US</strong>
              </a>
            </div>
          </div>{" "}
        </div>
      </div>
    </React.Fragment>
  );
  if (
    header === "2020 Sharp Direct Advantage Gold Card (HMO)" ||
    header === "2020 Sharp Direct Advantage Gold Card (HMO) With Dental" ||
    header === "2020 Sharp Direct Advantage Platinum Card (HMO) With Dental" ||
    header === "2021 Sharp Direct Advantage Gold Card (HMO)" ||
    header === "2021 Sharp Direct Advantage Gold Card (HMO) With Dental" ||
    header === "2021 Sharp Direct Advantage Platinum Card (HMO) With Dental"
  ) {
    return subHedar;
  } else if (
    header === "2019-20 Sharp Direct Advantage (HMO)" ||
    header === "2020-21 Sharp Direct Advantage (HMO)" ||
    header === "2020-21 Sharp Direct Advantage (HMO)" ||
    header === "2020-21 Sharp Direct Advantage (HMO)"
  ) {
    console.log("else if" + header);
    return (
      <React.Fragment>
        <div class="jumbotron" style={{ paddingBottom: "0vh" }}>
          <div class="container">
            <div class="enroll-header-content enroll-header-bg">
              <h2>Sharp Direct Advantage® Enrollment Form</h2>
              <p>
                This plan is offered exclusively for City of San Diego
                Medicare-eligible retirees and their dependents sponsered by San
                Diego Public Employee Benefit Association (SDPEBA).
              </p>
            </div>
            <div style={{ textAlign: "left" }}>
              <div class="plan-title pull-left">
                <span style={{ padding: "10px" }}>
                  Sharp Direct Advantage (HMO)
                </span>
                <a
                  class="teal pull-left change-plan"
                  href="none"
                  onClick={(e) => {
                    e.preventDefault();

                    localStorage.getItem("guestLogin") === "true"
                      ? history.push(
                          "/webapp/Sharp/Individual/yearSelectionGuest"
                        )
                      : history.push("/webapp/Sharp/Individual/yearSelection");
                  }}
                >
                  Change My Plan
                </a>
              </div>
            </div>
            <div style={{ textAlign: "left" }}>
              This plan is open to all Medicare-eligible City of San Diego
              retirees, sponsored by San Diego Public Employee Benefit
              Association (SDPEBA). SDPEBA membership is not required to join
              this plan.
            </div>
            <br />{" "}
            <div style={{ textAlign: "left" }}>
              <strong>Important Information</strong>
            </div>
            <br />
            <div style={{ textAlign: "left" }}>
              The Medicare application is intended for individual coverage only.
              If you and your spouse/ dependent are both applying for coverage,
              then each of you will need to complete a separate enrollment form.
              <p style={{ textAlign: "left" }}>
                Note – If your spouse/dependent is not eligible for Medicare,
                then he/she will need to complete the Non-Medicare / Early
                Retiree, enrollment form. Please contact SDPEBA at
                1-888-315-8027 or visit www.sdpeba.org to download the
                enrollment form
              </p>
            </div>
            <div style={{ textAlign: "left" }}>
              Please contact Sharp Health Plan if you need information in
              another language or format.&nbsp;&nbsp;
              <a
                class="contact-us"
                href="https://www.sharpmedicareadvantage.com/contact-us/contact-information"
              >
                <strong>CONTACT US</strong>
              </a>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  } else {
    return (
      <React.Fragment>
        <div class="jumbotron" style={{ paddingBottom: "0vh" }}>
          <div class="container">
            <div class="enroll-header-content enroll-header-bg">
              <h2>
                {header.substring(0, 4)} Sharp Direct Advantage Group Enrollment
                Form
              </h2>
              {header ===
              "2020 Sharp Direct Advantage Gold Card (HMO) with Dental" ? (
                <p>
                  This plan is open to all Medicare-eligible residents of San
                  Diego County.
                </p>
              ) : header ===
                "2021 Sharp Direct Advantage Gold Card (HMO) with Dental" ? (
                <p>
                  This plan is open to all Medicare-eligible residents of San
                  Diego County.
                </p>
              ) : (
                <p>
                  This Plan is exclusively for former Sharp HealthCare
                  employees.
                </p>
              )}
            </div>
            <div style={{ textAlign: "left" }}>
              <div class="plan-title pull-left">
                <span style={{ padding: "10px" }}>{header}</span>
                <a
                  class="teal pull-left change-plan"
                  href="none"
                  onClick={(e) => {
                    e.preventDefault();

                    localStorage.getItem("guestLogin") === "true"
                      ? history.push(
                          "/webapp/Sharp/Individual/yearSelectionGuest"
                        )
                      : history.push("/webapp/Sharp/Individual/yearSelection");
                  }}
                >
                  Change My Plan
                </a>
              </div>
            </div>
            <div style={{ textAlign: "left" }}>
              Please contact Sharp Health Plan if you need information in
              another language or format.&nbsp;&nbsp;
              <a
                class="contact-us"
                href="https://www.sharpmedicareadvantage.com/contact-us/contact-information"
              >
                <strong>CONTACT US</strong>
              </a>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
};
const CUSTOMER_LOGO1 = {
  SDAGC20: subHeader("2020 Sharp Direct Advantage Gold Card (HMO)"),
  SDAGCWD20: subHeader(
    "2020 Sharp Direct Advantage Gold Card (HMO) with Dental"
  ),
  SDAPC20: subHeader(
    "2020 Sharp Direct Advantage Platinum Card (HMO) With Dental"
  ),
  SDAB20: subHeader("2020 Sharp Direct Advantage Basic (HMO)"),
  SDABWD20: subHeader("2020 Sharp Direct Advantage Basic (HMO) with Dental"),
  SDAP20: subHeader("2020 Sharp Direct Advantage Premium (HMO)"),
  SDAPWD20: subHeader("2020 Sharp Direct Advantage Premium (HMO) with Dental"),
  SDAHMO1: subHeader("2019-20 Sharp Direct Advantage (HMO)"),
  SDAHMO20: subHeader("2020-21 Sharp Direct Advantage (HMO)"),
};
const CUSTOMER_LOGO2 = {
  SDAGC20: subHeader("2021 Sharp Direct Advantage Gold Card (HMO)"),
  SDAGCWD20: subHeader(
    "2021 Sharp Direct Advantage Gold Card (HMO) with Dental"
  ),
  SDAPC20: subHeader(
    "2021 Sharp Direct Advantage Platinum Card (HMO) With Dental"
  ),
  SDAB20: subHeader("2021 Sharp Direct Advantage Basic (HMO)"),
  SDABWD20: subHeader("2021 Sharp Direct Advantage Basic (HMO) with Dental"),
  SDAP20: subHeader("2021 Sharp Direct Advantage Premium (HMO)"),
  SDAPWD20: subHeader("2021 Sharp Direct Advantage Premium (HMO) With Dental"),

  SDAHMO1: subHeader("2019-20 Sharp Direct Advantage (HMO)"),
  SDAHMO20: subHeader("2020-21 Sharp Direct Advantage (HMO)"),
};

const CUSTOMER_LOGO = (props) => {
  return (
    <React.Fragment>
      {props.year === "2020"
        ? CUSTOMER_LOGO1[props.selectedPlan]
        : CUSTOMER_LOGO2[props.selectedPlan]}
    </React.Fragment>
  );
};

const mapStateToProps = (state) => {
  return {
    selectedPlan: state.webApp.selectedPlan,
    year: state.webApp.year,
  };
};
export default connect(mapStateToProps)(CUSTOMER_LOGO);
