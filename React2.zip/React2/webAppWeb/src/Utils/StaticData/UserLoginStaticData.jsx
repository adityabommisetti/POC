import React from "react";

export const header = "Log in to your Sharp Health Plan Medicare Account";
export const Body = (props) => {
  return (
    <p>
      Sharp Health Plan provides you with access to facilities and programs that
      help you make the most of your health care. We're here to make finding and
      enrolling in the right plan simple. Whether you have never purchased
      Medicare health coverage before or are considering switching from your
      current plan, we are committed to making your health care experience
      affordable, simple, accessible and personal. At Sharp Health Plan, we
      offer Medicare plans to feel good about.
    </p>
  );
};
