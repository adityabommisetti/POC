import React from "react";

export const header = "Forgot your password ?";
export const Body = (props) => {
  return (
    <p>
      Enter your email address below and we'll send you password reset
      instructions.
    </p>
  );
};
