import React from "react";
export const header = "Sharp Health Plan Medicare Plan";
export const Body = (props) => {
  return (
    <React.Fragment>
    <div>
      <p>
        Congratulations on successfully creating an account. It is important
        that you fully understand our benefits and rules. Before making your
        enrollment decision, be sure to review our pre-enrollment{" "}
        <a
          href="https://www.sharpmedicareadvantage.com/enroll/pre-enrollment-checklist/"
          class="enroll-subheader-content"
        >
          checklist
        </a>
        . If you have any questions, or need information in another language or
        format, please contact Sharp Health Plan. Medicare beneficiaries may
        also enroll in Sharp Health Plan through the CMS Medicare Online
        Enrollment Center located at{" "}
        <a href="https://www.medicare.gov/" class="enroll-subheader-content">
          http://www.medicare.gov
        </a>
        .{" "}
      </p>
      <p align="center">
        <a
          href="https://www.sharpmedicareadvantage.com/contact-us/"
          class="enroll-header-content"
        >
          <strong>CONTACT US -&gt;</strong>
        </a>
      </p>
    
    </div>
</React.Fragment>
  );
};
