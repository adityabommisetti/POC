import React from "react";

const Footer2 = (props) => {
  return (
    <footer id="footer-inc">
      <div class="container-fluid footer pad0">
        {" "}
        <div class="footer-img container"></div>
        <div class="container footer-lower">
          <div>
            <div>
              <div class="row">
                <div class="col-xs-3 col-sm-3 col-md-3 footer-white-line">
                  &nbsp;
                </div>
                <div class="col-xs-6 col-sm-6 col-md-6 footer-center-text text-center">
                  <strong>
                    Made with &nbsp;
                    <span class="footer-lower--heart footer-lower--heart-tab">
                      ♥
                    </span>
                    &nbsp; by Sharp Health Plan of San Diego
                  </strong>
                </div>
                <div class="col-xs-3 col-sm-3 col-md-3 footer-white-line">
                  &nbsp;
                </div>
              </div>
              <div class="row footer-lower--help"></div>
            </div>
          </div>
        </div>
        <div class="container footer-bottom">
          <div>
            <div>
              <div
                class="row medicare-row"
                itemscope="itemscope"
                itemtype="http://schema.org/Organization"
              >
                <div class="row footer-width">
                  <div class="col-3">
                    <a
                      rel="noopener noreferrer"
                      href="https://www.sharpmedicareadvantage.com/privacy-policy"
                      target="_blank"
                    >
                      Privacy Policy
                    </a>{" "}
                    <span style={{ color: "#e2e2e2" }}>|</span>
                    <a
                      rel="noopener noreferrer"
                      href="https://www.sharpmedicareadvantage.com/terms-and-conditions-of-use-agreement"
                      target="_blank"
                    >
                      Terms of Use
                    </a>{" "}
                    <span style={{ color: "#e2e2e2" }}></span>
                    <br />
                    <span style={{ marginTop: "10px", display: " block" }}>
                      © <span id="copy-date">2019</span> Sharp Health Plan
                    </span>
                  </div>
                  <div
                    class="col-3"
                    style={{ paddingRight: "15px", paddingTop: "5px" }}
                  >
                    <a
                      rel="noopener noreferrer"
                      href="https://www.facebook.com/SharpHealthPlan"
                      target="_blank"
                      itemprop="sameAs"
                    >
                      <img
                        alt="Sharp Health Plan on Facebook"
                        height="30"
                        src={require("../../assests/images/icon-footer-fb.png")}
                        width="30"
                      />
                    </a>
                    &nbsp;
                    <a
                      rel="noopener noreferrer"
                      href="https://www.linkedin.com/company/3842158"
                      target="_blank"
                      itemprop="sameAs"
                    >
                      <img
                        alt="Sharp Health Plan on LinkedIn"
                        height="30"
                        src={require("../../assests/images/icon-footer-li.png")}
                        width="30"
                      />
                    </a>
                    &nbsp;
                    <a
                      rel="noopener noreferrer"
                      href="https://search.google.com/local/writereview?placeid=ChIJt-ifWRVU2YARVQCfUq5LkA8"
                      target="_blank"
                      itemprop="sameAs"
                    >
                      <img
                        alt="Sharp Health Plan on Google"
                        height="30"
                        src={require("../../assests/images/icon-footer-google-white-closed.png")}
                        width="30"
                      />
                    </a>
                    &nbsp;
                    <a
                      rel="noopener noreferrer"
                      href="https://www.yelp.com/writeareview/biz/OkYw6xTrPYNXeh1MggTNVA?return_url=%2Fbiz%2FOkYw6xTrPYNXeh1MggTNVA&amp;source=biz_details_war_button"
                      target="_blank"
                      itemprop="sameAs"
                    >
                      <img
                        alt="Sharp Health Plan on Yelp"
                        height="30"
                        src={require("../../assests/images/icon-footer-yelp-white-closed.png")}
                        width="30"
                      />
                    </a>
                  </div>
                  <div class="col-3">
                    <strong itemprop="name">Sharp Health Plan</strong>
                    <br />
                    <span itemprop="postalAddress">
                      <span itemprop="streetAddress">
                        8520 Tech Way, Suite 201
                      </span>
                      <br />
                      <span itemprop="addressLocality">San Diego</span>,{" "}
                      <span itemprop="addressRegion">CA</span>
                      <span itemprop="postalCode">92123</span>
                    </span>
                  </div>

                  <div class="col-3">
                    <div class="footer-social  mob-pull-right">
                      <p>
                        Need to get in touch?
                        <br />
                        <a
                          rel="noopener noreferrer"
                          href="https://www.sharpmedicareadvantage.com/contact-us/contact-information"
                          target="_blank"
                          aria-label="Contact Us page"
                        >
                          Contact us
                        </a>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>{" "}
        </div>{" "}
      </div>{" "}
    </footer>
  );
};
export default Footer2;
