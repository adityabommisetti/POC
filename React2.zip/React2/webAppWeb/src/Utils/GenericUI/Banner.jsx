import React from "react";
import history from "../History";

const Banner = (props) => {
  const { header, Body } = props;
  return (
    <div class="jumbotron space">
      {history.location.pathname === "/webapp/Sharp/Individual/userCreation" ? (
        <p style={{ textAlign: "center", fontSize: "20px" }}>
          <strong>
            For the best experience, please use Google Chrome as your browser to
            begin the application process.
          </strong>{" "}
        </p>
      ) : null}
      <div class="container">
        <div class="enroll-header-content enroll-header-bg">
          <div class="enroll-header-content-width">
            <h2>{header}</h2>
            <p>
              <Body />
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
export default Banner;
