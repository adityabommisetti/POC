import React, { Component } from "react";
import history from "../Utils/History";

export default class Step3 extends Component {
  constructor(props) {
    super(props);

    this.state = {
      stepVal: "btn-step1",
    };
  }

  async componentDidMount() {
    window.scroll(0, 0);
  }

  Confirmation = async () => {
    await this.props.submitData();
  };

  render() {
    const { data, disableCheck } = this.props;
    console.log(this.props.progress);

    return (
      <React.Fragment>
        <div class="container tab-pane active">
          <h3 class="tab-headingindy">
            STEP 3: ATTESTATION OF ELIGIBILITY FOR AN ENROLLMENT PERIOD
          </h3>
          <p>
            <strong>
              Typically, you may enroll in a Medicare Prescription Drug Plan
              only during the annual enrollment period from October 15 through
              December 7 of each year.
            </strong>
            Additionally, there are exceptions that may allow you to enroll in a
            Medicare Prescription Drug Plan outside of the annual enrollment
            period.
          </p>
          <p>
            Please read the following statements carefully and check the box if
            the statement applies to you. By checking any of the following boxes
            you are certifying that, to the best of your knowledge, you are
            eligible for an Enrollment Period. If we later determine that this
            information is incorrect, you may be disenrolled.
          </p>
          <ul class="list-group" id="step3_checklist">
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step3_chk1"
                  name="c1"
                  value={data.c1}
                  disabled={
                    disableCheck === false || data.c1 === "NEW" ? false : true
                  }
                  checked={data.c1 === "NEW" ? true : false}
                  onChange={this.props.handleCheckbox}
                />
                <label class="custom-control-label" for="step3_chk1">
                  <strong>I am new to Medicare.</strong>
                </label>
              </div>
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step3_chk2"
                  name="c21"
                  value={data.c21}
                  disabled={
                    disableCheck === false || data.c21 === "OEP" ? false : true
                  }
                  checked={data.c21 === "OEP" ? true : false}
                  onChange={this.props.handleCheckbox}
                />
                <label class="custom-control-label" for="step3_chk2">
                  <strong>
                    I am enrolled in a Medicare Advantage plan and want to make
                    a change during the Medicare Advantage Open Enrollment
                    Period (MA OEP).
                  </strong>
                </label>
              </div>
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step3_chk3"
                  name="c2"
                  checked={data.c2 === "MOV" ? true : false}
                  onChange={this.props.handleCheckbox}
                  disabled={
                    disableCheck === false || data.c2 === "MOV" ? false : true
                  }
                  value={data.c2}
                />
                <label class="custom-control-label" for="step3_chk3">
                  <strong>
                    I recently moved outside of the service area for my current
                    plan or I recently moved and this plan is a new option for
                    me.
                  </strong>
                </label>
                <br />
              </div>
              {data.c2 === "MOV" ? (
                <React.Fragment>
                  <label for="imovedon">
                    I moved on (insert date)*
                    <input
                      name="attestation2"
                      id="attestation2"
                      maxLength="10"
                      placeholder="MM/DD/YYYY"
                      value={data.attestation2}
                      class={data.attestation2 === "" ?
                       "error-input" : "form-control"}
                      onClick={(e) => this.props.handleDates("attestation2")}
                      onChange={this.props.handleChange}
                    />
                    {/* <input
                      type="date"
                      id="imovedon"
                      name="attestation2"
                      class="form-control display-inline"
                      placeholder="MM/DD/YYYY"
                      value={data.attestation2}
                      onChange={this.props.handleChange}
                    /> */}
                  </label>
                </React.Fragment>
              ) : null}
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step3_chk4"
                  name="c3"
                  disabled={
                    disableCheck === false || data.c3 === "INC" ? false : true
                  }
                  checked={data.c3 === "INC" ? true : false}
                  onChange={this.props.handleCheckbox}
                  value={data.c3}
                />
                <label class="custom-control-label" for="step3_chk4">
                  <strong>I recently was released from incarceration.</strong>
                </label>
              </div>

              {data.c3 === "INC" ? (
                <React.Fragment>
                  <label for="iwasreleased">
                    I was released on (insert date)*
                    <input
                      name="attestation3"
                      id="attestation3"
                      maxLength="10"
                      placeholder="MM/DD/YYYY"
                      value={data.attestation3}
                      class={data.attestation3 === "" ?
                       "error-input" : "form-control"}
                      onClick={(e) => this.props.handleDates("attestation3")}
                      onChange={this.props.handleChange}
                    />
                  </label>
                </React.Fragment>
              ) : null}
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step3_chk5"
                  name="c4"
                  value={data.c4}
                  disabled={
                    disableCheck === false || data.c4 === "RUS" ? false : true
                  }
                  checked={data.c4 === "RUS" ? true : false}
                  onChange={this.props.handleCheckbox}
                />
                <label class="custom-control-label" for="step3_chk5">
                  <strong>
                    I recently returned to the United States after living
                    permanently outside of the U.S.
                  </strong>
                </label>
              </div>
              {data.c4 === "RUS" ? (
                <React.Fragment>
                  <label for="ireturnedtous">
                    I returned to the U.S. on (insert date)*
                    <input
                      name="attestation4"
                      id="attestation4"
                      maxLength="10"
                      placeholder="MM/DD/YYYY"
                      value={data.attestation4}
                      class={data.attestation4 === "" ?
                       "error-input" : "form-control"}
                      onClick={(e) => this.props.handleDates("attestation4")}
                      onChange={this.props.handleChange}
                    />
                  </label>
                </React.Fragment>
              ) : null}
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step3_chk6"
                  name="c5"
                  value={data.c5}
                  disabled={
                    disableCheck === false || data.c5 === "LAW" ? false : true
                  }
                  checked={data.c5 === "LAW" ? true : false}
                  onChange={this.props.handleCheckbox}
                />
                <label class="custom-control-label" for="step3_chk6">
                  <strong>
                    I recently obtained lawful presence status in the United
                    States.
                  </strong>
                </label>
              </div>
              <div class="sub-field ml-4 mt-3">
                {data.c5 === "LAW" ? (
                  <React.Fragment>
                    <label for="igotthisstatus">
                      I got this status on (insert date)*
                      <input
                        name="attestation5"
                        id="attestation5"
                        maxLength="10"
                        placeholder="MM/DD/YYYY"
                        value={data.attestation5}
                        class={data.attestation5 === "" ?
                       "error-input" : "form-control"}
                        onClick={(e) => this.props.handleDates("attestation5")}
                        onChange={this.props.handleChange}
                      />
                    </label>
                  </React.Fragment>
                ) : null}
              </div>
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step3_chk7"
                  name="c22"
                  value={data.c22}
                  disabled={
                    disableCheck === false || data.c22 === "MCD" ? false : true
                  }
                  checked={data.c22 === "MCD" ? true : false}
                  onChange={this.props.handleCheckbox}
                />
                <label class="custom-control-label" for="step3_chk7">
                  <strong>
                    I recently had a change in my Medicaid (newly got Medicaid,
                    had a change in level of Medicaid assistance, or lost
                    Medicaid) on{" "}
                  </strong>
                </label>
              </div>
              {data.c22 === "MCD" ? (
                <React.Fragment>
                  <label for="recentlyChangeMedicaid">
                    (insert date)*
                    <input
                      name="recentlyChangeMedicaid"
                      id="recentlyChangeMedicaid"
                      placeholder="MM/DD/YYYY"
                      maxLength="10"
                      value={data.recentlyChangeMedicaid}
                      class={data.recentlyChangeMedicaid === "" ?
                       "error-input" : "form-control"}
                      onClick={(e) => this.props.handleDates("recentlyChangeMedicaid")}
                      onChange={this.props.handleChange}
                    />
                  </label>
                </React.Fragment>
              ) : null}
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step3_chk8"
                  name="c7"
                  value={data.c7}
                  disabled={
                    disableCheck === false || data.c7 === "HLP" ? false : true
                  }
                  checked={data.c7 === "HLP" ? true : false}
                  onChange={this.props.handleCheckbox}
                />
                <label class="custom-control-label" for="step3_chk8">
                  <strong>
                    I recently had a change in my Extra Help paying for Medicare
                    prescription drug coverage (newly got Extra Help, had a
                    change in the level of Extra Help, or lost Extra Help) on
                  </strong>
                </label>
              </div>
              {data.c7 === "HLP" ? (
                <React.Fragment>
                  <label for="recentlyChangeExtraHelp">
                    (insert date)*
                    <input
                      name="attestation7"
                      id="attestation7"
                      maxLength="10"
                      placeholder="MM/DD/YYYY"
                      value={data.attestation7}
                      class={data.attestation7 === "" ?
                       "error-input" : "form-control"}
                      onClick={(e) => this.props.handleDates("attestation7")}
                      onChange={this.props.handleChange}
                    />
                  </label>
                </React.Fragment>
              ) : null}
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step3_chk9"
                  disabled={
                    disableCheck === false || data.c6 === "MDE" ? false : true
                  }
                  name="c6"
                  value={data.c6}
                  checked={data.c6 === "MDE" ? true : false}
                  onChange={this.props.handleCheckbox}
                />
                <label class="custom-control-label" for="step3_chk9">
                  <strong>
                    I have both Medicare and Medicaid (or my state helps pay for
                    my Medicare premiums) or I get Extra Help paying for my
                    Medicare prescription drug coverage, but I haven't had a
                    change.
                  </strong>
                </label>
              </div>
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step3_chk10"
                  name="c9"
                  value={data.c9}
                  checked={data.c9 === "LTC" ? true : false}
                  onChange={this.props.handleCheckbox}
                  disabled={
                    disableCheck === false || data.c9 === "LTC" ? false : true
                  }
                />
                <label class="custom-control-label" for="step3_chk10">
                  <strong>
                    I live in or recently moved out of a Long-Term Care Facility
                    (for example, a nursing home or long term care facility).{" "}
                  </strong>
                </label>
              </div>
              <div class="sub-field ml-4 mt-3">
                {data.c9 === "LTC" ? (
                  <React.Fragment>
                    <label for="imoved_willmove">
                      I moved/will move into/out of the facility on (insert
                      date)*
                      <input
                        name="attestation9"
                        maxLength="10"
                        id="attestation9"
                        placeholder="MM/DD/YYYY"
                        value={data.attestation9}
                        class={data.attestation9 === "" ?
                       "error-input" : "form-control"}
                        onClick={(e) => this.props.handleDates("attestation9")}
                        onChange={this.props.handleChange}
                      />
                    </label>
                  </React.Fragment>
                ) : null}
              </div>
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step3_chk11"
                  name="c10"
                  value={data.c10}
                  checked={data.c10 === "PAC" ? true : false}
                  onChange={this.props.handleCheckbox}
                  disabled={
                    disableCheck === false || data.c10 === "PAC" ? false : true
                  }
                />
                <label class="custom-control-label" for="step3_chk11">
                  <strong>I recently left a PACE program on </strong>
                </label>
              </div>

              {data.c10 === "PAC" ? (
                <React.Fragment>
                  <label for="ileftpace">
                    I left PACE program on (insert date)*
                    <input
                      name="attestation10"
                      id="attestation10"
                      maxLength="10"
                      placeholder="MM/DD/YYYY"
                      value={data.attestation10}
                      class={data.attestation10 === "" ?
                       "error-input" : "form-control"}
                      onClick={(e) => this.props.handleDates("attestation10")}
                      onChange={this.props.handleChange}
                    />
                  </label>
                </React.Fragment>
              ) : null}
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step3_chk12"
                  name="c11"
                  value={data.c11}
                  disabled={
                    disableCheck === false || data.c11 === "LCC" ? false : true
                  }
                  checked={data.c11 === "LCC" ? true : false}
                  onChange={this.props.handleCheckbox}
                />
                <label class="custom-control-label" for="step3_chk12">
                  <strong>
                    I recently involuntarily lost my creditable prescription
                    drug coverage (as good as Medicare's).
                  </strong>
                </label>
              </div>

              {data.c11 === "LCC" ? (
                <React.Fragment>
                  <label for="ilostmydrugcoverage">
                    I lost my drug coverage on (insert date)*
                    <input
                      name="attestation11"
                      id="attestation11"
                      maxLength="10"
                      placeholder="MM/DD/YYYY"
                      value={data.attestation11}
                      class={data.attestation11 === "" ?
                       "error-input" : "form-control"}
                      onClick={(e) => this.props.handleDates("attestation11")}
                      onChange={this.props.handleChange}
                    />
                  </label>
                </React.Fragment>
              ) : null}
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step3_chk13"
                  name="c12"
                  checked={data.c12 === "LEC" ? true : false}
                  onChange={this.props.handleCheckbox}
                  disabled={
                    disableCheck === false || data.c12 === "LEC" ? false : true
                  }
                  value={data.c12}
                />
                <label class="custom-control-label" for="step3_chk13">
                  <strong>I am leaving employer or union coverage on </strong>
                </label>
              </div>
              <div class="sub-field ml-4 mt-3">
                {data.c12 === "LEC" ? (
                  <React.Fragment>
                    <label for="iamleavingon">
                      I am leaving on (insert date)*
                      <input
                        name="attestation12"
                        id="attestation12"
                        maxLength="10"
                        placeholder="MM/DD/YYYY"
                        value={data.attestation12}
                        class={data.attestation12 === "" ?
                       "error-input" : "form-control"}
                        onClick={(e) => this.props.handleDates("attestation12")}
                        onChange={this.props.handleChange}
                      />
                    </label>
                  </React.Fragment>
                ) : null}
              </div>
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step3_chk14"
                  name="c13"
                  disabled={
                    disableCheck === false || data.c13 === "PAP" ? false : true
                  }
                  checked={data.c13 === "PAP" ? true : false}
                  onChange={this.props.handleCheckbox}
                  value={data.c13}
                />
                <label class="custom-control-label" for="step3_chk14">
                  <strong>
                    I belong to a pharmacy assistance program provided by my
                    state.
                  </strong>
                </label>
              </div>
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step3_chk15"
                  name="c14"
                  disabled={
                    disableCheck === false || data.c14 === "EOC" ? false : true
                  }
                  value={data.c14}
                  checked={data.c14 === "EOC" ? true : false}
                  onChange={this.props.handleCheckbox}
                />
                <label class="custom-control-label" for="step3_chk15">
                  <strong>
                    My plan is ending its contract with Medicare, or Medicare is
                    ending its contract with my plan.
                  </strong>
                </label>
              </div>
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step3_chk16"
                  name="c24"
                  value={data.c24}
                  disabled={
                    disableCheck === false || data.c24 === "DIF" ? false : true
                  }
                  checked={data.c24 === "DIF" ? true : false}
                  onChange={this.props.handleCheckbox}
                />
                <label class="custom-control-label" for="step3_chk16">
                  <strong>
                    I was enrolled in a plan by Medicare (or my state) and I
                    want to choose a different plan.
                  </strong>
                </label>
              </div>
              {data.c21 === "DIF" ? (
                <div class="sub-field ml-4 mt-3">
                  <label for="iwasdisenrolled">
                    My enrollment in that plan started on (insert date)*
                    <input
                      name="attestation24"
                      id="attestation24"
                      maxLength="10"
                      placeholder="MM/DD/YYYY"
                      value={data.attestation24}
                      class={data.attestation24 === "" ?
                       "error-input" : "form-control"}
                      onClick={(e) => this.props.handleDates("attestation24")}
                      onChange={this.props.handleChange}
                    />
                  </label>
                </div>
              ) : null}
            </li>
            <li class="list-group-item">
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="step3_chk17"
                  name="c25"
                  value={data.c25}
                  disabled={
                    disableCheck === false || data.c25 === "DST" ? false : true
                  }
                  checked={data.c25 === "DST" ? true : false}
                  onChange={this.props.handleCheckbox}
                />
                <label class="custom-control-label" for="step3_chk17">
                  <strong>
                    I was affected by a weather-related emergency or major
                    disaster (as declared by the Federal Emergency Management
                    Agency (FEMA). One of the other statements here applied to
                    me, but I was unable to make my enrollment because of the
                    natural disaster.
                  </strong>
                </label>
              </div>
            </li>
          </ul>
          <p class="mt-3">
            If none of these statements applies to you or you're not sure,
            please contact Indy Health Insurance Company at{" "}
            <a href="tel:1-800-799-0927">1-800-799-0927</a> to see if you are
            eligible to enroll. We are open 8 a.m. to 8 p.m., seven days a week
            (except Thanksgiving and Christmas) from October 1 through March 31,
            and Monday to Friday (except holidays) from April 1 through
            September 30. TTY users should call 711.
          </p>

          <div class="row mt-2">
            <div class="col-md-5 col-sm-12"></div>
            <div class="col-md-5 col-sm-12 mt-2">
              {this.props.progress !== 100 ? (
                <span
                  class="small text-danger"
                  style={{ fontSize: "15px !important" }}
                >
                  <strong>
                    We're missing a few pieces of information. Please check
                    steps 1-3 for red highlighted fields. When all required
                    information has been entered, the submit button will display
                    in green.
                  </strong>
                </span>
              ) : (
                  <span class="small text-success">
                    <strong>
                      Congratulations! Your Medicare form is complete, please
                      press SUBMIT to finish.
                  </strong>
                  </span>
                )}
            </div>
            <div class="col-md-2 col-sm-12 mt-2">
              <button
                class={
                  this.props.progress === 100
                    ? "btn btn-primary float-right"
                    : "btn btn-secondary float-right"
                }
                onClick={this.Confirmation}
                disabled={this.props.progress !== 100}
              >
                Submit
              </button>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}
