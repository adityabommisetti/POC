import React, { Component } from "react";
import history from "../Utils/History";
import Step1 from "./Step1";
import Step2 from "./Step2";
import Step3 from "./Step3";
import { INITIAL_STATE } from "./InitialState";
import { connect } from "react-redux";
import {
  saveLogout,
  submitForm,
  getClinicalName,
} from "../Redux/Actions/webAppActions";
import { withStyles } from "@material-ui/core/styles";
import { planSelectionContinue } from "../Redux/Actions/webAppActions";
import LinearProgress from "@material-ui/core/LinearProgress";
import * as DateUtil from "../Utils/DatePicker";
import $ from "jquery";
import moment from "moment";
const styles = (props) => ({
  progressComplete: {
    backgroundColor: "#00695C",
  },
  root: {
    height: "20px",
  },
  progressIncomplete: {
    backgroundColor: "#b8880c",
  },
});

class PreEnroll extends Component {
  constructor(props) {
    super(props);

    this.state = {
      stepVal: "btn-step1",
      data:
        Object.keys(this.props.preEnrollInfo).length === 0
          ? { ...INITIAL_STATE }
          : this.props.preEnrollInfo,
      disableCheck: false,
      value: "",
      checkedQuestion: "",
      attestionDt: "",
    };
  }

  handleSelectChange = async (event) => {
    await this.setState({
      value: event.target.value,
    });

    if (this.state.value === "") {
      alert(" Please select plan !!");
      return;
    } else {
      let payload = {
        strPlanId: this.state.value,
      };
      await this.props.planSelectionContinue(payload);
      await this.setState({
        data:
          this.props.preEnrollInfo &&
          Object.keys(this.props.preEnrollInfo).length === 0
            ? { ...INITIAL_STATE }
            : this.props.preEnrollInfo,
      });

      if (
        this.props.preEnrollInfo &&
        Object.keys(this.props.preEnrollInfo).length !== 0
      ) {
        if (this.props.checkQsnNumInAttes != "") {
          await this.setState({ disableCheck: true });
        }
      }
    }
  };

  async componentDidMount() {
    window.scroll(0, 0);
    let data = this.state.data;
    if (data) {
      if (
        data.c1 !== "" ||
        data.c2 !== "" ||
        data.c3 !== "" ||
        data.c4 !== "" ||
        data.c5 !== "" ||
        data.c6 !== "" ||
        data.c7 !== "" ||
        data.c8 !== "" ||
        data.c9 !== "" ||
        data.c10 !== "" ||
        data.c11 !== "" ||
        data.c12 !== "" ||
        data.c13 !== "" ||
        data.c14 !== "" ||
        data.c15 !== "" ||
        data.c16 !== "" ||
        data.c22 !== "" ||
        data.c21 !== "" ||
        data.c25 !== "" ||
        data.c24 !== ""
      ) {
        await this.setState({ disableCheck: true });
      }
    }
  }

  redirect = async (event) => {
    let id = event.target.id;

    if (id === "save-n-continue1") {
      await this.setState({ stepVal: "btn-step2" });
    }
    if (id === "save-n-continue2") {
      await this.setState({ stepVal: "btn-step3" });
    }
    if (id === "save-n-continue3") {
      await this.setState({ stepVal: "btn-step1" });
    }
  };

  // async componentWillReceiveProps(nextProps) {
  //   console.log(nextProps);
  //   if (
  //     nextProps.preEnrollInfo &&
  //     Object.keys(nextProps.preEnrollInfo).length != 0
  //   ) {
  //     await this.setState({ data: nextProps.preEnrollInfo });
  //   }
  // }

  handleCheckbox1 = async (event) => {
    let name = event.target.name;
    let value = event.target.checked;
    console.log(name);
    console.log(value);
    if (name === "Formulary") {
      value = event.target.checked ? "Y" : "N";
    }
    if (name === "pharmacy") {
      value = event.target.checked ? "Y" : "N";
    }
    if (name === "eoc") {
      value = event.target.checked ? "Y" : "N";
    }

    if (name === "mailingAddressRequired") {
      value = event.target.checked ? "YES" : "";
    }
    await this.setState({
      data: { ...this.state.data, [name]: value },
    });
  };

  handleCheckbox = async (event) => {
    let name = event.target.name;
    let value = event.target.checked;

    if (name === "aep") {
      value = event.target.checked ? "AEP" : "";
    }
    if (name === "c1") {
      value = event.target.checked ? "NEW" : "";
    }
    if (name === "c2") {
      value = event.target.checked ? "MOV" : "";

      if (value === "") {
        await this.setState({ data: { ...this.state.data, attestation2: "" } });
      }
    }
    if (name === "c3") {
      value = event.target.checked ? "INC" : "";
      if (value === "") {
        await this.setState({ data: { ...this.state.data, attestation3: "" } });
      }
    }
    if (name === "c4") {
      value = event.target.checked ? "RUS" : "";
      if (value === "") {
        await this.setState({ data: { ...this.state.data, attestation4: "" } });
      }
    }
    if (name === "c5") {
      value = event.target.checked ? "LAW" : "";
      if (value === "") {
        await this.setState({ data: { ...this.state.data, attestation5: "" } });
      }
    }
    if (name === "c6") {
      value = event.target.checked ? "MDE" : "";
    }

    if (name === "c7") {
      value = event.target.checked ? "HLP" : "";
    }
    if (name === "c21") {
      value = event.target.checked ? "OEP" : "";
    }
    if (name === "c22") {
      value = event.target.checked ? "MCD" : "";
    }
    if (name === "c24") {
      value = event.target.checked ? "DIF" : "";
    }

    if (name === "c25") {
      value = event.target.checked ? "DST" : "";
    }

    if (name === "c8") {
      value = event.target.checked ? "NLS" : "";
      if (value === "") {
        await this.setState({ data: { ...this.state.data, attestation8: "" } });
      }
    }
    if (name === "c9") {
      value = event.target.checked ? "LTC" : "";
      if (value === "") {
        await this.setState({ data: { ...this.state.data, attestation9: "" } });
      }
    }
    if (name === "c10") {
      value = event.target.checked ? "PAC" : "";
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, attestation10: "" },
        });
      }
    }
    if (name === "c11") {
      value = event.target.checked ? "LCC" : "";
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, attestation11: "" },
        });
      }
    }
    if (name === "c12") {
      value = event.target.checked ? "LEC" : "";
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, attestation12: "" },
        });
      }
    }
    if (name === "c13") {
      value = event.target.checked ? "PAP" : "";
    }
    if (name === "c14") {
      value = event.target.checked ? "EOC" : "";
    }
    if (name === "c15") {
      value = event.target.checked ? "SNP" : "";
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, attestation15: "" },
        });
      }
    }
    if (name === "c16") {
      value = event.target.checked ? "OTH" : "";
      if (value === "") {
        await this.setState({
          data: { ...this.state.data, c16Attestation: "", attestation16: "" },
        });
      }
    }

    await this.setState({
      data: { ...this.state.data, [name]: value },
    });

    if (value === "") {
      await this.setState({ disableCheck: false });
    } else {
      await this.setState({ disableCheck: true });
    }
    console.log(this.state.data);

    name = name.substring(1);
    await this.setState({ checkedQuestion: name });
  };

  saveData = async () => {
    const response = await this.props.saveLogout(this.state.data);

    if (response.data === "Enrollment form saved successfully") {
      history.push("/webapp/IndyHealth/userCreation");
    } else {
      alert("Save Failed");
    }
  };

  handleSteps = async (event) => {
    let value = event.target ? event.target.id : event.id;
    if(value){
      await this.setState({ stepVal: value });
    }
  };

  
  handleDates = (fieldId) => {
    var self = this;
    DateUtil.getDatePicker("#"+fieldId).datepicker( "show" )
    DateUtil.getDatePicker("#"+fieldId)
    .on("change", e => {
      this.setDates(fieldId, e.target.value)
    });
  };

  setDates = async(fieldId, value) =>{
    await this.setState({ data: { ...this.state.data, [fieldId]: value } });
    console.log(this.state.data[fieldId])
  }

  handleChange = async (e) => {
    let name = e.target.name;

    let value = e.target ? e.target.value : e.value;

    if (name.toLowerCase().includes("phone")) {
      value = this.formatPhoneNumber(value.replace(/[^0-9]/g, ""));
    }

    if (name.toLowerCase().includes("attestation")) {
      await this.setState({ attestionDt: value });
    }
    await this.setState({ data: { ...this.state.data, [name]: value } });
    console.log(this.state.data);
  };

  formatPhoneNumber = (phoneNumberString) => {
    var match = phoneNumberString.match(/^(\d{3})(\d{3})(\d{4})$/);
    if (match) {
      return "(" + match[1] + ") " + match[2] + "-" + match[3];
    }
    return phoneNumberString;
  };
  handleNumberChange = (event) => {
    let name = event.target.name;
    let value = event.target.value;
    console.log(value);
    value = value.replace(/[^0-9]/g, "");

    this.setState({ data: { ...this.state.data, [name]: value } });
  };

  submitData = async () => {
    let productId = "";
    let pbpId = "";
    let fullPlanName;

    let selectedPlan = this.state.value;
    if (selectedPlan === "INDY_SAVER_ARK") {
      fullPlanName = "Arkansas $25.30 per month";
      productId = "012";
      pbpId = "012";
    } else if (selectedPlan === "INDY_SAVER_GEORG") {
      fullPlanName = "Georgia $26.20 per month";
      productId = "010";
      pbpId = "010";
    } else if (selectedPlan === "INDY_SAVER_ILLINOIS") {
      fullPlanName = "Illinois $24.50 per month";
      productId = "011";
      pbpId = "011";
    } else if (selectedPlan === "INDY_SAVER_PENSYL") {
      fullPlanName = "Pennsylvania $34.00 per month";
      productId = "009";
      pbpId = "009";
    } else if (selectedPlan === "INDY_SAVER_WESTVIR") {
      fullPlanName = "West Virginia $34.00 per month";
      productId = "009";
      pbpId = "009";
    } else if (selectedPlan === "INDY_ELITE_GEORG") {
      fullPlanName = "Georgia $47.00 per month";
      productId = "006";
      pbpId = "006";
    } else if (selectedPlan === "INDY_ELITE_ARK") {
      fullPlanName = "Arkansas $44.40 per month";
      productId = "008";
      pbpId = "008";
    } else if (selectedPlan === "INDY_ELITE_ILLINOIS") {
      fullPlanName = "Illinois $43.30 per month";
      productId = "007";
      pbpId = "007";
    } else if (selectedPlan === "INDY_ELITE_PENSYL") {
      fullPlanName = "Pennsylvania $47.10 per month";
      productId = "005";
      pbpId = "005";
    } else {
      fullPlanName = "West Virginia $47.10 per month";
      productId = "005";
      pbpId = "005";
    }

    let payload = {
      ...this.state.data,
      productId: productId,
      pbpId: pbpId,
      fullPlanName: fullPlanName,
      checkQsnNumInAttes: this.state.checkedQuestion,
      attestationDate: this.state.attestionDt,
    };

    console.log(payload);
    const response = await this.props.submitForm(payload);

    if (response.message === "SUCCESS") {
      history.push("/webapp/IndyHealth/Confirmation");
    } else {
      alert("Submission Failed");
    }
  };

  render() {
    const { data, selectedPlan } = this.state;
    let count = 19;
    const progress1 = data.firstName === "" ? 0 : 1;
    const progress2 = data.lastName === "" ? 0 : 1;
    const progress3 = (data.birthDate === "" &&
    !moment(data.birthDate, "MM/DD/YYYY", true).isValid()) === "" ? 0 : 1;
    const progress4 = data.primaryPhone === "" ? 0 : 1;
    const progress5 = data.permanentAddrStreet === "" ? 0 : 1;
    const progress6 = data.permanentCity === "" ? 0 : 1;
    const progress7 = data.emailAddr === "" ? 0 : 1;
    const progress8 = data.permanentZip === "" ? 0 : 1;
    const progress9 = data.sex === "" ? 0 : 1;
    const progress10 = data.medicareClaim === "" ? 0 : 1;
    // const progress11 = data.pcpName === "" ? 0 : 1;
    const progress11 = data.nameSignature === "" ? 0 : 1;
    // const progress12 = data.authorizedrepname !== "" ? 1 : 0;

    // const progress13 = data.authorizedreprelationship !== "" ? 1 : 0;
    // const progress14 = data.authorizedrepaddress !== "" ? 1 : 0;
    // const progress15 = data.authorizedrepphone !== "" ? 1 : 0;
    // const progress16 = data.digitalSignature === "" ? 0 : 1;

    const progress12 = data.vaBenefits === "Y" && data.nameOfCov !== "" ? 1 : 0;
    const progress13 = data.vaBenefits === "Y" && data.idOfCov !== "" ? 1 : 0;
    const progress14 =
      data.vaBenefits === "Y" && data.groupOfCov !== "" ? 1 : 0;

    const progress15 =
      data.mailingAddressRequired === "YES" && data.mailingAddr !== "" ? 1 : 0;
    const progress16 =
      data.mailingAddressRequired === "YES" && data.mailingCity !== "" ? 1 : 0;
    const progress17 =
      data.mailingAddressRequired === "YES" && data.mailingState !== "" ? 1 : 0;
    const progress18 =
      data.mailingAddressRequired === "YES" && data.mailingZip !== "" ? 1 : 0;

    const progress19 = data.todaysDate === "" ? 0 : 1;

    console.log("progress1" + progress1);

    if (data.vaBenefits !== "Y") count -= 3;
    if (data.mailingAddressRequired !== "YES") count -= 4;
    const progress =
      ((progress1 +
        progress2 +
        progress3 +
        progress4 +
        progress5 +
        progress6 +
        progress7 +
        progress8 +
        progress9 +
        progress10 +
        progress11 +
        progress12 +
        progress13 +
        progress14 +
        progress15 +
        progress16 +
        progress17 +
        progress18 +
        progress19) /
        count) *
      100;

    return (
      <React.Fragment>
        <div id="content" class="site-content">
          <div id="primary" class="content-area">
            <main id="main" class="site-main">
              <article
                id="post-2"
                class="post-2 page type-page status-publish hentry"
              >
                <header id="home" class="entry-header hide">
                  <h1 class="entry-title">Enrollment Form</h1>
                </header>
                <div class="entry-content margin-top7">
                  <div class="wp-block-editor-blocks-wrapper alignfull page-section bg-gray">
                    <div class="wrapper-inner">
                      <div class="wrapper-inner">
                        <div class="wrapper-inner-blocks">
                          <div class="row">
                            <div class="col-md-9">
                              <h2
                                id="home"
                                class="text-center "
                                style={{ marginLeft: "20rem !important" }}
                              >
                                2021 Indy Health Plan{" "}
                              </h2>
                              <p class="text-center mb-0">
                                Please contact Health Plan if you need
                                information in another language or form.
                                <br />
                                <a href="">CONTACT US &gt;</a>
                              </p>
                            </div>
                            <div class="col-md-3 text-right">
                              <span>
                                OMB No. 0938-1378
                                <br />
                                Expires:7/31/2023
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="wp-block-editor-blocks-wrapper alignfull page-section">
                    <div class="container mt-3">
                      <div class="progress-bar">
                        <LinearProgress
                          variant="determinate"
                          value={progress}
                          color="primary"
                          classes={{
                            root: this.props.classes.root,
                            barColorPrimary:
                              progress === 100
                                ? this.props.classes.progressComplete
                                : this.props.classes.progressIncomplete,
                          }}
                        />
                      </div>
                    </div>
                    <br />

                    <div class="wrapper-inner">
                      <ul
                        class="nav nav-pills nav-justified"
                        value={this.state.stepVal}
                        onClick={this.handleSteps}
                      >
                        <li class="nav-item">
                          <a
                            class={
                              this.state.stepVal === "btn-step1"
                                ? "nav-link active"
                                : "nav-link"
                            }
                            data-toggle="tab"
                            href="#step1"
                            id="btn-step1"
                          >
                            Step 1
                          </a>
                        </li>
                        <li class="nav-item">
                          <a
                            class={
                              this.state.stepVal === "btn-step2"
                                ? "nav-link active"
                                : "nav-link"
                            }
                            data-toggle="tab"
                            href="#step2"
                            id="btn-step2"
                          >
                            Step 2
                          </a>
                        </li>
                        <li class="nav-item">
                          <a
                            class={
                              this.state.stepVal === "btn-step3"
                                ? "nav-link active"
                                : "nav-link"
                            }
                            data-toggle="tab"
                            href="#step3"
                            id="btn-step3"
                          >
                            Step 3
                          </a>
                        </li>
                      </ul>
                      <div class="tab-contentindy">
                        {this.state.stepVal === "btn-step1" && (
                          <Step1
                            data={this.state.data}
                            handleChange={this.handleChange}
                            handleDates={this.handleDates}
                            redirect={this.redirect}
                            value={this.state.value}
                            handleSelectChange={this.handleSelectChange}
                            handleNumberChange={this.handleNumberChange}
                            handleCheckbox={this.handleCheckbox1}
                          />
                        )}
                        {this.state.stepVal === "btn-step2" && (
                          <Step2
                            data={this.state.data}
                            handleChange={this.handleChange}
                            handleDates={this.handleDates}
                            redirect={this.redirect}
                            handleCheckbox={this.handleCheckbox1}
                          />
                        )}
                        {this.state.stepVal === "btn-step3" && (
                          <Step3
                            data={this.state.data}
                            handleChange={this.handleChange}
                            handleDates={this.handleDates}
                            disableCheck={this.state.disableCheck}
                            handleCheckbox={this.handleCheckbox}
                            redirect={this.redirect}
                            submitData={this.submitData}
                            progress={progress}
                          />
                        )}
                      </div>
                      <div class="row mt-2">
                        <div class="col-md-5 col-sm-12 mt-2">
                          <button
                            class="button2 float-left"
                            onClick={this.saveData}
                          >
                            Save and Logout
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </article>
            </main>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    preEnrollInfo: state.webApp.preEnrollInfo,
    guestLogin: state.webApp.guestLogin,
    physicians: state.webApp.physicians,
    authorizedrelations: state.webApp.authorizedrelations,
  };
};
const mapDispatchToProps = {
  saveLogout,
  submitForm,
  getClinicalName,
  planSelectionContinue,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(PreEnroll));
