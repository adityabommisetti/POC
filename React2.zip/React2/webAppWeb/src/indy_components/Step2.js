import React, { Component } from "react";
import history from "../Utils/History";
import SimpleReactValidator from "simple-react-validator";

export default class Step2 extends Component {
  constructor(props) {
    super(props);

    this.state = {
      stepVal: "btn-step1",
    };
    this.validator = new SimpleReactValidator();
  }

  handleSteps = async (event) => {
    let value = event.target ? event.target.id : event.id;
    await this.setState({ stepVal: value });
  };

  async componentDidMount() {
    window.scroll(0, 0);
  }

  render() {
    const { data } = this.props;
    return (
      <React.Fragment>
        <div class="container tab-pane active">
          <h3 class="tab-headingindy">STEP 2: </h3>
          <p>All fields on this page are optional</p>
          <h4 class="sub-heading">
            <strong>
              Answering these questions is your choice. You can't be denied
              coverage because you don't fill them out.
            </strong>
          </h4>
          <div class="form-group">
            <div>
              <label for="otherLanguage" class="control-label mr-2">
                Select one if you want us to send you information in a language
                other than English.
              </label>
              <div class="custom-control custom-radio custom-control-inline mt-3">
                <input
                  type="radio"
                  name="otherlanguage"
                  id="otherlanguage"
                  class="custom-control-input"
                  value="Spanish"
                  checked={data.otherlanguage === "Spanish"}
                  onChange={this.props.handleChange}
                />
                <label
                  for="otherlanguage"
                  class="radio-inline custom-control-label"
                >
                  Spanish
                </label>
              </div>
            </div>
            <fieldset class="radio radio-tab mt-3">
              <legend>
                Select one if you want us to send you information in an
                accessible format.
              </legend>
              <div class="custom-control custom-radio custom-control-inline mt-1">
                <input
                  type="radio"
                  name="language"
                  id="lfp_braille"
                  class="custom-control-input"
                  value="BRAILLE"
                  checked={data.language === "BRAILLE"}
                  onChange={this.props.handleChange}
                />
                <label
                  for="lfp_braille"
                  class="radio-inline custom-control-label"
                >
                  Braille
                </label>
              </div>
              <div class="custom-control custom-radio custom-control-inline mt-1">
                <input
                  type="radio"
                  name="language"
                  id="lfp_largeprint"
                  class="custom-control-input"
                  value="LARGE_PRINT"
                  checked={data.language === "LARGE_PRINT"}
                  onChange={this.props.handleChange}
                />
                <label
                  for="lfp_largeprint"
                  class="radio-inline custom-control-label"
                >
                  Large Print
                </label>
              </div>
              <div class="custom-control custom-radio custom-control-inline mt-1">
                <input
                  type="radio"
                  name="language"
                  id="lfp_audiocd"
                  class="custom-control-input"
                  value="AUDIO_CD"
                  checked={data.language === "AUDIO_CD"}
                  onChange={this.props.handleChange}
                />
                <label
                  for="lfp_audiocd"
                  class="radio-inline custom-control-label"
                >
                  Audio CD
                </label>
              </div>
            </fieldset>
            <br />
            <br />

            <p>
              Please contact Indy Health Insurance Company at
              <a href="tel:1-800-799-0927"> 1-800-799-0927 </a>
              if you need information in an accessible format other than what's
              listed above. Our office hours are 8 a.m. to 8 p.m., seven days a
              week (except Thanksgiving and Christmas) from October 1 through
              March 31, and Monday to Friday (except holidays) from April 1
              through September 30. TTY users can call 711.
            </p>
            <div class="row mb-4">
              <div class="col-md-6">
                <fieldset class="radio radio-tab mt-3">
                  <legend>Do you work?</legend>
                  <div class="custom-control custom-radio custom-control-inline mt-1">
                    <input
                      type="radio"
                      name="youwork"
                      id="dDoYouWork_Yes"
                      class="custom-control-input"
                      value="Y"
                      checked={data.youwork === "Y"}
                      onChange={this.props.handleChange}
                    />
                    <label
                      for="dDoYouWork_Yes"
                      class="radio-inline custom-control-label"
                    >
                      Yes
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline mt-1">
                    <input
                      type="radio"
                      name="youwork"
                      id="dDoYouWork_No"
                      class="custom-control-input"
                      value="N"
                      checked={data.youwork === "N"}
                      onChange={this.props.handleChange}
                    />
                    <label
                      for="dDoYouWork_No"
                      class="radio-inline custom-control-label"
                    >
                      No
                    </label>
                  </div>
                </fieldset>
              </div>
              <div class="col-md-6">
                <fieldset class="radio radio-tab mt-3">
                  <legend class="margin-left-0p5">
                    Does your spouse work?
                  </legend>
                  <div class="custom-control custom-radio custom-control-inline mt-1">
                    <input
                      type="radio"
                      name="spousework"
                      id="dDoYourSpouseWork_Yes"
                      class="custom-control-input"
                      value="Y"
                      checked={data.spousework === "Y"}
                      onChange={this.props.handleChange}
                    />
                    <label
                      for="dDoYourSpouseWork_Yes"
                      class="radio-inline custom-control-label"
                    >
                      Yes
                    </label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline mt-1">
                    <input
                      type="radio"
                      name="spousework"
                      id="dDoYourSpouseWork_No"
                      class="custom-control-input"
                      value="N"
                      checked={data.spousework === "N"}
                      onChange={this.props.handleChange}
                    />
                    <label
                      for="dDoYourSpouseWork_No"
                      class="radio-inline custom-control-label"
                    >
                      No
                    </label>
                  </div>
                </fieldset>
              </div>
            </div>

            <p>
              <label for="listPCP" class="control-label mr-2">
                List your Primary Care Physician (PCP), clinic, or health
                center:
              </label>
              <input
                type="text"
                id="listPCP"
                class="form-control"
                name="listPCP"
                value={data.listPCP}
                onChange={this.props.handleChange}
              />
            </p>
            <p class="mt-3">
              <label for="vieEmail" class="control-label">
                I want to get the following materials via email. Select one or
                more.
              </label>
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  name="pharmacy"
                  id="pharmacy"
                  class="custom-control-input"
                  value={data.pharmacy}
                  onChange={this.props.handleCheckbox}
                  checked={data.pharmacy === "Y" ? true : false}
                />
                <label for="pharmacy" class="custom-control-label">
                  Pharmacy Directory
                </label>
              </div>
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  name="Formulary"
                  value={data.Formulary}
                  onChange={this.props.handleCheckbox}
                  checked={data.Formulary === "Y" ? true : false}
                  id="Formulary"
                  class="custom-control-input"
                />
                <label for="Formulary" class="custom-control-label">
                  Formulary
                </label>
              </div>
              <div class="custom-control custom-checkbox custom-control-inline">
                <input
                  type="checkbox"
                  name="eoc"
                  id="eoc"
                  class="custom-control-input"
                  onChange={this.props.handleCheckbox}
                  checked={data.eoc === "Y" ? true : false}
                />
                <label for="eoc" class="custom-control-label">
                  Evidence of Coverage (EOC)
                </label>
              </div>
              <br />
              <label for="emailAddress" class="control-label">
                E-mail Address:
              </label>
              <input
                type="text"
                class={
                  !this.validator.check(data.emailAddr, "email") ||
                    !data.emailAddr.endsWith(".com") ||
                    data.emailAddr === ""
                    ? "error-input"
                    : "form-control"
                }
                id="emailAddress"
                name="emailAddr"
                value={data.emailAddr}
                onChange={this.props.handleChange}
                required=""
              />
            </p>
          </div>

          <h4 class="sub-heading">
            <strong>Paying your plan premiums</strong>
          </h4>
          <div class="form-group">
            <p class="text-align-justify">
              You can pay your monthly plan premium by mail Electronic Funds
              Transfer (EFT) or check each month.{" "}
              <strong>
               {/* You can also choose to pay your premium by having it
                automatically taken out of your Social Security or Railroad
               Retirement Board (RRB) benefit each month.*/}
              </strong>
            </p>

            <p class="text-align-justify">
              <strong>
                If you have to pay a Part D-Income Related Monthly Adjustment
                Amount (Part D-IRMAA), you must pay this extra amount in
                addition to your plan premium.
              </strong>{" "}
              The amount is usually taken out of your Social Security benefit,
              or you may get a bill from Medicare (or the RRB). DON'T pay Indy
              Health Insurance Company the Part D-IRMAA.
            </p>
          </div>
          <hr />
          <div>
            <p class="small">
              <strong>PRIVACY ACT STATEMENT:</strong>
              The Centers for Medicare &amp; Medicaid Services (CMS) collects
              information from Medicare plans to track beneficiary enrollment in
              Medicare Advantage (MA) or Prescription Drug Plans (PDP), improve
              care, and for the payment of Medicare benefits. Sections 1851 and
              1860D-1 of the Social Security Act and 42 CFR &#167;&#167; 422.50,
              422.60, 423.30 and 423.32 authorize the collection of this
              information. CMS may use, disclose and exchange enrollment data
              from Medicare beneficiaries as specified in the System of Records
              Notice (SORN) "Medicare Advantage Prescription Drug (MARx)",
              System No. 09-70-0588. Your response to this form is voluntary.
              However, failure to respond may affect enrollment in the plan.
            </p>
          </div>

          <button
            class="button btn-save-n-continue"
            id="save-n-continue2"
            onClick={this.props.redirect}
          >
            Save and Continue
          </button>
        </div>
      </React.Fragment>
    );
  }
}
