import React, { Component } from "react";
import * as URL from "../Redux/API_URL";
import axios from "../Utils/axios";
import logo1 from "../assests/images/shp-logo.png";
import logo2 from "../assests/images/IHS-logo.png";
import logo3 from "../assests/images/vp-logo.png";

let value = window.location.href.toString().indexOf("Sharp");
let value1 = window.location.href.toString().indexOf("Indy");

class DownloadForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      applId: "",
      customerId: "",
    };
  }

  openPDFDoc = (doc) => {
    return axios
      .get(
        URL.DOWNLOAD_FORM +
          "?appId=" +
          this.state.applId +
          "&customerId=" +
          this.state.customerId,
        {
          headers: { "x-auth-token": localStorage.getItem("token") },
        }
      )
      .then((response) => {
        var base64str = response.data.data;
        var binary = atob(base64str.replace(/\s/g, ""));
        var len = binary.length;
        var buffer = new ArrayBuffer(len);
        var view = new Uint8Array(buffer);
        for (var i = 0; i < len; i++) {
          view[i] = binary.charCodeAt(i);
        }
        var blob = new Blob([view], { type: "application/pdf" });
        var url = window.URL.createObjectURL(blob);
        if (navigator.msSaveBlob) {
          return navigator.msSaveOrOpenBlob(blob, "download.pdf");
        } else {
          window.open(
            url,
            "popUpWindow",
            "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=900" +
              ", height=900" +
              ", top=10" +
              ", left=10"
          );
        }
      })

      .catch((error) => {
        alert("Please enter valid Application number");
        if (error.response && error.response.status === 500) {
          if (error.response.headers["x-auth-token"]) {
            var token = error.response.headers["x-auth-token"];

            localStorage.setItem("token", "Bearer " + token);
          }
        }
      });
  };

  handleChange = (event) => {
    const value = event.target.value;
    this.setState({
      applId: value,
    });
  };

  componentDidMount = () => {
    console.log(value);
    if (value > -1) {
      this.setState({
        customerId: "HCF0335",
      });
    } else if (value1 > -1) {
      this.setState({
        customerId: "HCF0245",
      });
    } else {
      this.setState({
        customerId: "HCF0232",
      });
    }
  };
  render() {
    let value = window.location.href.toString().indexOf("Sharp");
    let value1 = window.location.href.toString().indexOf("Indy");
    return (
      <React.Fragment>
        <div>
          <p
            style={{
              textAlign: "center",
              fontSize: "50px",
              marginTop: "55px",
              fontFamily: "bold",
            }}
          >
            GENERATE PDF FORM
          </p>
          <div>
            {value > -1 ? (
              <img
                width="254"
                height="54"
                src={logo1}
                class="attachment-full size-full"
                alt="Sharp logo"
              />
            ) : value1 > -1 ? (
              <img
                width="254"
                height="54"
                src={logo2}
                class="attachment-full size-full"
                alt="Indy Health logo"
              />
            ) : (
              <img
                width="254"
                height="54"
                src={logo3}
                class="attachment-full size-full"
                alt="Virginia Premier logo"
              />
            )}
          </div>
          <p style={{ textAlign: "center", fontFamily: "bold" }}>
            Please Enter Confirmation Number
          </p>
          <div class="text-center mt-2">
            <input
              id="applId"
              value={this.state.applId}
              type="text"
              onChange={this.handleChange}
            ></input>
          </div>
          <div class="text-center mt-2">
            <button class="btnvap btn-primaryvap" onClick={this.openPDFDoc}>
              Download
            </button>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

export default DownloadForm;
