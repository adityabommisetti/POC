import { withStyles } from "@material-ui/core/styles";
import { default as React } from "react";
import { connect } from 'react-redux';
import { Styles } from "../../assets/styles/Theme";
import { getCacheData } from '../../Store/Plan/Action/CacheAction';
import InputField from "../UI/InputField";

function DiscrepencyDetails(props) {
    const { classes, dropdowns } = props;
    return (
        <div class="panel-body">
        <div class="twin-margin">
            <div class="twin-boxes">
                <div class="form-panel">
                    <div className={classes.container}>
                        <div>
                        <InputField
                                name="endDate"
                                label="Effective Date To"
                                value={"5"}
                                disabled={true}
                            />
                        </div>
                        <div className={classes.validationMessage} />
                        <div>
                        <InputField
                                name="endDate"
                                label="Effective Date To"
                                value={"5"}
                                disabled={true}
                            />
                        </div>
                        <div className={classes.validationMessage} />
                    </div>
                </div>
            </div>
            <div class="twin-boxes">
                <div class="form-panel">
                    <div className={classes.container}>
                    <div>
                            <InputField
                                name="endDate"
                                label="Effective Date To"
                                value={"5"}
                                disabled={true}
                            />
                        </div>
                        <div className={classes.validationMessage} />
                        <div>
                        <InputField
                                name="endDate"
                                label="Effective Date To"
                                value={"5"}
                                disabled={true}
                            />
                        </div>
                        <div className={classes.validationMessage} />
                    </div>
                </div>
            </div>
        </div>
    </div>
    );
}


const mapStateToProps = state => {
    return {
        dropdowns: state.cacheData.dropdowns
    };
};

const mapDispatchToProps = {
    getCacheData
};

export default
    connect(mapStateToProps, mapDispatchToProps)
        (withStyles(Styles)(DiscrepencyDetails));

