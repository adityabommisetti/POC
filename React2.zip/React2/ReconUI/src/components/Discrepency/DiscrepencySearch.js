import Button from "@material-ui/core/Button";
import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormLabel from "@material-ui/core/FormLabel";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import { withStyles } from "@material-ui/core/styles";
import RadioButtonCheckedIcon from "@material-ui/icons/RadioButtonChecked";
import RadioButtonUncheckedIcon from "@material-ui/icons/RadioButtonUnchecked";
import { default as React } from "react";
import { connect } from 'react-redux';
import { Styles } from "../../assets/styles/Theme";
import { getDiscrepancy } from '../../Store/Plan/Action/DiscrepancyAction';
import * as DateUtil from "../../utils/DatePicker";
import InputField from "../UI/InputField";
import MultiSelect from "../UI/MultiSelect";
const dateChk = {};

function DiscrepancySearch(props) {

  const monthPicker = (selectedDate, field) => {
    if (selectedDate._d) {
      var date = new Date(selectedDate._d),
        mnth = ("0" + (date.getMonth() + 1)).slice(-2),
        selectedDate = [mnth, date.getFullYear()].join("/");
    } else {
      selectedDate = selectedDate.replace(/[^0-9]/g, "").trim();
      selectedDate = selectedDate.replace(/^(\d{2})/, "$1/");
      selectedDate = selectedDate.replace(/(\d)\/(\d{4}).*/, "$1/$2");
    }
  };

  const { classes, dropdowns } = props;

  const INITIAL_STATE = {
    partName: "",
    planNames: [],
    startDate: "",
    hicNumber: "",
    discrpCds: [],
    endDate: "",
    discrpStatus: "",
    updateId: "",
    updateDateFrom: "",
    updateDateTo: ""
  };
  

  const [searchVo, setSearchVo] = React.useState({...INITIAL_STATE})

  const handleChange = e => {
    const { name, value } = e.target
    setSearchVo(prevState => ({
      ...prevState,
      [name]: value
    }))
  };

  const handleDates = (fieldId, targetVo) => {
    DateUtil.getDatePicker(fieldId).on("change", e => {
      if (dateChk.name !== e.target.name || dateChk.value !== e.target.value) {
        setDate(e.target.name, e.target.value, targetVo);
      }
      dateChk.name = e.target.name;
      dateChk.value = e.target.value;
    });
  };

  const setDate = (name, value, targetVo) => {
    setSearchVo(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleSearchFieldChange = name => event => {
    let value = event.target
      ? event.target.value.toUpperCase()
      : event.value.toUpperCase();
    setSearchVo({ ...searchVo, [name]: value })
  };

  const handleSearchSelect = async (name, value) => {
    console.log("handleSearchSelect")
    console.log(name);
    console.log(value);
    let temp = [...searchVo[name]];
    const valueIndex = searchVo[name].indexOf(value);
    if (valueIndex == -1) {
      temp = [...temp, value]
    } else {
      temp.splice(valueIndex, 1);
    }
    console.log(temp)
    await setSearchVo(prevState => ({
      ...prevState,
      [name]: temp
    }));
  };

  const handleSearch = (e, props) => {
    props.getDiscrepancy(searchVo);
  };

  const handleReset = (e) => {
    setSearchVo({ ...searchVo, ...INITIAL_STATE })
  };

  console.log(dropdowns)
  console.log(searchVo)
  return (
    <div class="sidebar-search">
      <div class="input-group">
        <MultiSelect
          label="Plan Search"
          dataList={dropdowns.PLANSLIST}
          propertyName="planNames"
          value={searchVo.planNames}
          handleSearchSelect={handleSearchSelect}
        />
      </div>
      <div class="sidebar-search">
        <FormControl
          component="fieldset"
          className={classes.formControl}
        >
          <FormLabel
            component="legend"
            className={classes.legend}
          ></FormLabel>
          <RadioGroup
            name="partName"
            className={classes.group}
            value={searchVo.partName}
            onChange={handleSearchFieldChange("partName")}
          >
            <FormControlLabel
              value="BOTH"
              control={
                <Radio
                  color="primary"
                  icon={<RadioButtonUncheckedIcon fontSize="small" />}
                  checkedIcon={
                    <RadioButtonCheckedIcon fontSize="small" />
                  }
                />
              }
              label="Both"
            />
            <FormControlLabel
              value="PARTC"
              control={
                <Radio
                  color="primary"
                  icon={<RadioButtonUncheckedIcon fontSize="small" />}
                  checkedIcon={
                    <RadioButtonCheckedIcon fontSize="small" />
                  }
                />
              }
              label="Part C"
            />
            <FormControlLabel
              value="PARTD"
              control={
                <Radio
                  color="primary"
                  icon={<RadioButtonUncheckedIcon fontSize="small" />}
                  checkedIcon={
                    <RadioButtonCheckedIcon fontSize="small" />
                  }
                />
              }
              label="Part D"
            />
          </RadioGroup>
        </FormControl>
      </div>
      <div style={{ marginTop: "80px" }}>
        <InputField
          name="hicNumber"
          label="Medicare ID"
          value={searchVo.hicNumber}
          onChange={handleSearchFieldChange("hicNumber")}
        />
      </div>
      <div class="input-group">
        <MultiSelect
          label="Status"
          dataList={dropdowns.DISCRPSTATUSLIST}
          propertyName="discrpStatus"
          value={searchVo.discrpStatus}
          handleSearchSelect={handleSearchSelect}
        />
      </div>
      <div class="input-group">
        <MultiSelect
          label="Type"
          dataList={dropdowns.DISCRPTYPESPARTC}
          propertyName="discrpCds"
          value={searchVo.discrpCds}
          handleSearchSelect={handleSearchSelect}
        />
      </div>
      <div>
        <InputField
          name="startDate"
          placeholder="MM/DD/YYYY"
          label="Effective Date From"
          value={searchVo.startDate}
          onClick={(e) => handleDates("#startDate", "searchVo")}
          maxLength={10}
          onChange={handleSearchFieldChange("startDate")}
        />
      </div>
      <div>
        <InputField
          name="endDate"
          placeholder="MM/DD/YYYY"
          label="Effective Date To"
          value={searchVo.endDate}
          onClick={(e) => handleDates("#endDate", "searchVo")}
          maxLength={10}
          onChange={handleSearchFieldChange("endDate")}
        />
      </div>
      <div>
        <InputField
          name="updateDateFrom"
          placeholder="MM/DD/YYYY"
          label="Update Date From"
          value={searchVo.updateDateFrom}
          onClick={(e) => handleDates("#updateDateFrom", "searchVo")}
          maxLength={10}
          onChange={handleSearchFieldChange("updateDateFrom")}
        />
      </div>
      <div>
        <InputField
          name="updateDateTo"
          placeholder="MM/DD/YYYY"
          label="Update Date To"
          value={searchVo.updateDateTo}
          onClick={(e) => handleDates("#updateDateTo", "searchVo")}
          maxLength={10}
          onChange={handleSearchFieldChange("updateDateTo")}
        />
      </div>
      <div>
        <InputField
          name="updateId"
          label="Update ID"
          value={searchVo.updateId}
          onChange={handleSearchFieldChange("updateId")}
        />
      </div>
      <Button
        id="reset"
        variant="contained"
        style={{ marginTop: "5px" }}
        color="primary"
        onClick={(e) => handleReset(e)}
        className={props.classes.button}
      >
        Reset
      </Button>
      <Button
        id="reset"
        variant="contained"
        style={{ marginTop: "5px" }}
        color="primary"
        onClick={(e) => handleSearch(e, props)}
        className={props.classes.button}
      >
        Search
      </Button>
    </div>
  );
}



const mapStateToProps = state => {
  return {
    dropdowns: state.cacheData.dropdowns
  };
};

const mapDispatchToProps = {
  getDiscrepancy
};

export default
  connect(mapStateToProps, mapDispatchToProps)
    (withStyles(Styles)(DiscrepancySearch));

