import { withStyles } from "@material-ui/core/styles";
import { isEmpty } from 'lodash';
import { default as React } from "react";
import { connect } from 'react-redux';
import { Styles } from "../../assets/styles/Theme";
import { getCacheData } from '../../Store/Plan/Action/CacheAction';
import DataTable from "../UI/GenericTable";
import { DISCREPENCY_LIST } from '../UI/tableHeader';
import Popup from "reactjs-popup";
import Button from "@material-ui/core/Button";
import Export from '../../utils/Export';
import ExpansionPanel from '../UI/ExpansionPanel';

function DiscrepencyDetails(props) {
    const { classes, dropdowns, discrepancyData } = props;
    const [rowsPerPage, handleRows] = React.useState(3);
    const [page, handlePages] = React.useState(0);
    const [detailList, handleDiscrepency] = React.useState([]);

    const handleChangeRowsPerPage = (rowsPerPage) => {
        handleRows(rowsPerPage)
    };

    const handleChangePage = (page) => {
        handlePages(page)
    };

    React.useEffect(() => {
        if (!isEmpty(props.discrepancyDetailList)) {
            const list = props.discrepancyDetailList;
            list.map(function (e) {
                e.isSelected = false;
            });
            handleDiscrepency(list)
        }
    }, [props.discrepancyDetailList])


    const handleSelect = (index) => {
        handleDiscrepency(detailList.map((obj, key) => {
            if (key === index) return { ...obj, isSelected: !detailList[index].isSelected }
            return obj;
        }));
    }

    const handleSelectAll = (selectAll) => {
        const list = detailList;
        list.map(function (e) {
            e.isSelected = selectAll;
        });
        handleDiscrepency(list)
    };
    return (
        (!isEmpty(detailList) ?
        <div class="details-section">
                <div>
                    <Popup
                        className={classes.mobileWidth}
                        modal
                        trigger={
                            <Button
                                id="reset"
                                variant="contained"
                                style={{ marginTop: "5px" }}
                                color="primary"
                                className={props.classes.button}
                            >
                                Export
                        </Button>
                        }
                        position="right center"
                    >
                        {close => (
                            <div>
                                <Export
                                    close={close}
                                    page={page}
                                    rowsPerPage={3}
                                    header={DISCREPENCY_LIST}
                                    data={detailList}
                                />
                            </div>
                        )}
                    </Popup>
                </div>
                <ExpansionPanel summary="Discrepancy List - Part C and Part D">
                    <DataTable
                        data={detailList}
                        header={DISCREPENCY_LIST}
                        rowsPerPage={rowsPerPage}
                        sortable={true}
                        handleSelect={handleSelect}
                        handleSelectAll={handleSelectAll}
                        handleChangePage={handleChangePage}
                        handleChangeRowsPerPage={handleChangeRowsPerPage}
                    />
                </ExpansionPanel>
            </div>
            : null)
    );
}


const mapStateToProps = state => {
    return {
        discrepancyData: state.discrepancy.discrepancyData,
        discrepancyDetailList: state.discrepancy.discrepancyData.discrepancyDetailList
    };
};

const mapDispatchToProps = {
    getCacheData
};

export default
    connect(mapStateToProps, mapDispatchToProps)
        (withStyles(Styles)(DiscrepencyDetails));

