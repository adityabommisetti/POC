import { withStyles } from "@material-ui/core/styles";
import { isEmpty } from 'lodash';
import { default as React } from "react";
import { Styles } from "../../assets/styles/Theme";
import DataTable from "../UI/GenericTable";
import { DISCREPENCY_HISTORY } from '../UI/tableHeader';

function DiscrepencyHistory(props) {
    const { classes } = props;
    const [historyList, handleHistory] = React.useState([]);

    
    React.useEffect(() => {
        if (!isEmpty(props.historyList)) {
            handleHistory(props.historyList);
        }
    }, [props.historyList]);


    const rowSelect = (index) => {
        console.log(index);
    };

    const handleChangePage = (page) => {
        console.log(page)
    };

    return (
        <DataTable
            data={historyList}
            header={DISCREPENCY_HISTORY}
            rowsPerPage={10}
            rowSelect={rowSelect}
            handleChangePage={handleChangePage}
        />
    );
}

export default (withStyles(Styles)(DiscrepencyHistory));

