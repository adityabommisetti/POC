import { withStyles } from "@material-ui/core/styles";
import { isEmpty } from 'lodash';
import { default as React } from "react";
import { connect } from 'react-redux';
import { Styles } from "../../assets/styles/Theme";
import { getCacheData } from '../../Store/Plan/Action/CacheAction';
import DiscrepencySearch from "./DiscrepencySearch";
import DiscrepancyList from "./DiscrepancyList";

function Discrepency(props) {
  const { classes, dropdowns } = props;
  const [isExpanded, setisExpanded] = React.useState(false);

  React.useEffect(() => {
    props.getCacheData();
  }, []);

  const handleToggle = (e) => {
    setisExpanded(!isExpanded)
  };

  console.log(props.dropdowns)

  return (
    (!isEmpty(dropdowns) ?
      <div className='main-container'>
        <div className={`search-section ${isExpanded ? 'search-close' : ''}`}>
          <span className="search-toggle-btn toggle-btn-right" onClick={(e) => handleToggle(e)}>
            <i class="icon icon-angle-left"></i>
          </span>
          {!isExpanded ?
          <div  style={{overflowY: "scroll"}}>
            <DiscrepencySearch
              handleToggle={handleToggle}
              isExpanded={isExpanded}
              dropdowns={dropdowns}
            /> 
            </div>: null}
        </div>
        <DiscrepancyList
          handleToggle={handleToggle}
          isExpanded={isExpanded}
        />
      </div>
      : null)
  );
}


const mapStateToProps = state => {
  return {
      dropdowns: state.cacheData.dropdowns
  };
};

const mapDispatchToProps = {
  getCacheData
};

export default 
connect(mapStateToProps, mapDispatchToProps)
(withStyles(Styles)(Discrepency));

