import React, { Suspense } from 'react';
import { Redirect, Route, Switch } from 'react-router-dom';
import Plan from '../Plan/Plan';
import Beneficiary from '../Beneficiary/Beneficiary'
import Discrepency from '../Discrepency/Discrepency';
import CircularIndeterminate from '../../utils/CircularProgress';

const Routers = () => {
    return (
        <React.Fragment>
            <Switch>
                <Route path='/plan' render={() => <Suspense fallback={<CircularIndeterminate />}><Plan /> </Suspense>} />
                <Route path='/beneficiary' render={() => <Suspense fallback={<CircularIndeterminate />}><Beneficiary /> </Suspense>} />
                <Route path='/discrepancies' render={() => <Suspense fallback={<CircularIndeterminate />}><Discrepency /> </Suspense>} />
                <Redirect from='/' to="/plan" />
            </Switch>
        </React.Fragment>
    )
}

export default Routers;


