import MuiExpansionPanel from "@material-ui/core/ExpansionPanel";
import MuiExpansionPanelDetails from "@material-ui/core/ExpansionPanelDetails";
import MuiExpansionPanelSummary from "@material-ui/core/ExpansionPanelSummary";
import React from "react";
import { withStyles } from "@material-ui/core/styles";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import ExpandLessIcon from "@material-ui/icons/ExpandLess";

const ExpansionPanel = withStyles({
  root: {
    border: "1px solid rgba(0, 0, 0, .125)",
    boxShadow: "none",
    minHeight: "42px !important",
    // marginBottom: "6px",
    // marginTop: "6px",
    "&:not(:last-child)": {
      marginBottom: "20px",
    },
    "&:before": {
      display: "none",
    },
    "&$expanded": {
      margin: "auto",
      minHeight: "42px !important",
      // marginBottom: "6px",
      // marginTop: "6px",
    },
  },
  expanded: {},
})(MuiExpansionPanel);

const ExpansionPanelSummary = withStyles({
  root: {
    backgroundColor: "#e9f5ff",
    fontSize: "1.4em",
    lineHeight: ".8",

    minHeight: "42px !important",
    height: "28px",
    fontWeight: "500",
    "&$expanded": {
      minHeight: "42px !important",
    },
  },
  content: {
    "&$expanded": {},
  },
  expanded: {},
})(MuiExpansionPanelSummary);

const ExpansionPanelDetails = withStyles((theme) => ({
  root: {
    backgroundColor: "#e9f5ff",
    padding: "0.5em", // "1em",
  },
}))(MuiExpansionPanelDetails);

class CustomizedExpansionPanels extends React.PureComponent {
  state = {
    expanded: this.props.defaultCollapsed === true ? false : true,
  };

  UNSAFE_componentWillReceiveProps = (nextProps) => {
    this.setState({
      expanded: nextProps.defaultCollapsed === true ? false : true,
    });
  };

  handleChange = async () => {
    await this.setState({
      expanded: !this.state.expanded,
    });
    if (this.props.onClick) {
      this.props.onClick();
    }
  };

  handleOnBlur = async () => {
    await this.setState({
      expanded: !this.state.expanded,
    });
    if (this.props.onClick) {
      this.props.onClick();
    }
  };

  render() {
    return (
      <div>
        <ExpansionPanel
          square
          onChange={this.handleChange}
          expanded={this.state.expanded}
        >
          <ExpansionPanelSummary
            className="PanelHeaderSection_ieTarget"
            aria-controls="panel1d-content"
            id="panel1d-header"
          >
            <React.Fragment>
              {this.state.expanded ? (
                <span
                  style={{
                    marginLeft: "-16px",
                    height: "30px",
                    width: "8px",
                    backgroundColor: "#0089cf",
                    marginTop: "3px",
                  }}
                />
              ) : (
                <span
                  style={{
                    marginLeft: "-16px",
                    height: "30px",
                    width: "8px",
                    backgroundColor: "#0089cf",
                    marginTop: "3px",
                  }}
                />
              )}
              <span style={{ color: "#0089cf", padding: ".5em .6em .6em 1em" }}>
                {this.props.summary}
              </span>
              {this.state.expanded ? (
                <ExpandLessIcon
                  style={{
                    color: "#0089cf",
                    marginTop: "2px",
                    fontSize: "1.5em",
                  }}
                />
              ) : (
                <ExpandMoreIcon
                  style={{
                    color: "#0089cf",
                    marginTop: "2px",
                    fontSize: "1.5em",
                  }}
                />
              )}
            </React.Fragment>
          </ExpansionPanelSummary>

          <ExpansionPanelDetails>{this.props.children}</ExpansionPanelDetails>
        </ExpansionPanel>
      </div>
    );
  }
}

export default CustomizedExpansionPanels;
