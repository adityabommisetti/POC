import { Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle } from '@material-ui/core';
import Button from "@material-ui/core/Button";
import React, { Component } from 'react';

import { withStyles, makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import {Discode} from '../../../assets/staticData'

function Modal(props) {
    const StyledTableCell = withStyles((theme) => ({
        head: {
          backgroundColor: '#dfe2ee',
          color: 'black',
        },
        body: {
          fontSize: 14,
        },
      }))(TableCell);
      
      const StyledTableRow = withStyles((theme) => ({
        root: {
          '&:nth-of-type(odd)': {
            backgroundColor: theme.palette.action.hover,
          },
        },
      }))(TableRow);
      
      function createData(name, calories, fat, carbs, protein) {
        return { name, calories, fat, carbs, protein };
      }
      

      
    const [toggle, setToggle] = React.useState('')
    const [check, setCheck] = React.useState('')
    React.useEffect(()=>{
        setToggle( props.show)
        setCheck(false)
    },[])
    React.useEffect(()=>{
        if (props.show) {
            setToggle(true)
        }
    },[props])
  
   


        return (
            <Dialog open={props.show && toggle}>
                <DialogTitle style={{backgroundColor: '#dfe2ee'}}>{'Discrepancy Codes & Discreptions'}</DialogTitle>

                <DialogContent>
                    
                        {/* {props.message} */}
                        <TableContainer component={Paper}>
      <Table  aria-label="customized table">
        <TableHead>
          <TableRow>
            <StyledTableCell style={{width:'7%'}}>Discrepancy code</StyledTableCell>
            <StyledTableCell align="left">Description</StyledTableCell>
            <StyledTableCell align="left">Source</StyledTableCell>
            {/* <StyledTableCell align="right">Carbs&nbsp;(g)</StyledTableCell>
            <StyledTableCell align="right">Protein&nbsp;(g)</StyledTableCell> */}
          </TableRow>
        </TableHead>
        <TableBody>
          {Discode.map((row) => (
            <StyledTableRow key={row.Discrepancycode}>
              <StyledTableCell component="th" scope="row">
                {row.Discrepancycode}
              </StyledTableCell>
              <StyledTableCell align="left">{row.Description}</StyledTableCell>
              <StyledTableCell align="left">{row.Source}</StyledTableCell>
        
            </StyledTableRow>
          ))}
        
        </TableBody>
      </Table>
    </TableContainer>
  
                    

                </DialogContent>

                <DialogActions>
                    <Button
                        variant="contained"
                        color="primary"
                        onClick={() => {
                            props.modalClosed();
                        }}
                    >
                        OK
                    </Button>
                </DialogActions>
            </Dialog>
        )
    }


export default Modal;