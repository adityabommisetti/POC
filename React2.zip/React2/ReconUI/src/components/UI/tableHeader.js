export  const PlanSummaryHeader =[
  // { label: "Payment Type",
  // title: "Payment Type",
  // key: "partName"
  // },
  { label: "Description",
  title: "Description",
  key: "description"
  },
  { label: "CMS Paid",
  title: "CMS Paid",
  key: "cmsPaid"
  },
  { label: "Part C/D",
  title: "Part C/D",
  key: "planExpected"
  },
  { label: "discrepency",
  title: "discrepency",
  key: "discrepency"
  }
]

export  const PlanSummaryPartD =[
  { label: "Payment Type",
  title: "Payment Type",
  key: "partName"
  },
  { label: "Description",
  title: "Description",
  key: "description"
  },
  { label: "CMS Paid",
  title: "CMS Paid",
  key: "cmsPaid"
  },
  { label: "Part C/D",
  title: "Part C/D",
  key: "planExpected"
  },
  { label: "discrepency",
  title: "discrepency",
  key: "discrepency"
  }
]
export  const PlanHeader =[
    {
  label: "CMS Paid",
  title: "CMS Paid",
  key: "cmsPaidPartC"
  },
  {
  label: "Part C/D",
  title: "Part C/D",
  key: "planExpectedPartC"
  },
  {
  label: "discrepency",
  title: "discrepency",
  key: "diffrencePartC"
  },
  {
  label: "ECMS Paid",
  title: "ECMS Paid",
  key: "cmsPaidPartD"
  },
  {
  label: "Part C/D",
  title: "Part C/D",
  key: "planExpectedPartD"
  },
  {
  label: "discrepency",
  title: "discrepency",
  key: "diffrencePartD"
  }
  ]


  export  const DisacpHeader =[
    {
      label: "Total",
      title: "Total",
      key: "countPartC"
      },
  {
  label: "Open",
  title: "Open",
  key: "openPartC"
  },
  {
  label: "In Progress",
  title: "In Progress",
  key: "inProgressPartC"
  },
  {
  label: "Force Closed",
  title: "Force Closed",
  key: "forceClosedPartC"
  },
  {
  label: "Resolved",
  title: "Resolved",
  key: "resolvedPartC"
  },
 


  // "rollupId": "T9999",
  // "rollupName": "T9999",
  // "countPartC": "3,980",
  // "openPartC": "3,308",
  // "inProgressPartC": "2",
  // "forceClosedPartC": "0",
  // "resolvedPartC": "670",
  // "countPartD": "606",
  // "openPartD": "533",
  // "inProgressPartD": "0",
  // "forceClosedPartD": "0",
  // "resolvedPartD": "73",
//  Total 	Open 	In Progress 	Force Closed 	Resolved



  {
    label: "Total",
    title: "Total",
    key: "countPartD"
    },
    {
    label: "Open",
    title: "Open",
    key: "openPartD"
    },
    {
    label: "In Progress",
    title: "In Progress",
    key: "inProgressPartD"
    },
    {
    label: "Force Closed",
    title: "Force Closed",
    key: "forceClosedPartD"
    },
    {
    label: "Resolved",
    title: "Resolved",
    key: "resolvedPartD"
    },
  ]

  export  const DISCREPENCY_LIST =[
    { label: "Medicare ID",
    title: "Medicare ID",
    key: "hicNumber"
    },
    { label: "Plan ID",
    title: "Plan ID",
    key: "planId"
    },
    { label: "Part C/D",
    title: "Part C/D",
    key: "discrepancyIndicator"
    },
    { label: "Discrepency",
    title: "Discrepency",
    key: "discrepancyCd"
    },
    { label: "Eff Date",
    title: "Eff Date",
    key: "pymtEffDateFrmt"
    },
    { label: "Status",
    title: "Status",
    key: "discrepancyStatus"
    },
    { label: "PBP",
    title: "PBP",
    key: "pbpId"
    },
    { label: "CMS",
    title: "CMS",
    key: "cmsValue"
    },
    { label: "Plan",
    title: "Plan",
    key: "planId"
    },
    { label: "UserID",
    title: "UserID",
    key: "lastUpdtUserID"
    },
    { label: "Last Update",
    title: "Last Update",
    key: "lastUpdtTime"
    }
  ];

  
  export  const DISCREPENCY_HISTORY =[
    { label: "Discrepancy",
    title: "Discrepancy",
    key: "discrepancyCd"
    },
    { label: "Status",
    title: "Status",
    key: "discrepancyStatus"
    },
    { label: "Create Date",
    title: "Create Date",
    key: "createDate"
    },
    { label: "Last Update",
    title: "Last Update",
    key: "lastUpdtDate"
    },
    { label: "Comments",
    title: "Comments",
    key: "comment"
    },
    { label: "Updated By",
    title: "Updated By",
    key: "lastUpdtUserId"
    },
    { label: "Assigned To",
    title: "Assigned To",
    key: "lastUpdtUserId"
    }
  ];

  
