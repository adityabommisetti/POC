import React,{useState, useEffect}from 'react';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown';
import Remove from '@material-ui/icons/Remove';
import Add from '@material-ui/icons/Add';
import IconButton from '@material-ui/core/IconButton';
import {PlanHeader} from '../UI/tableHeader'
import Link from '@material-ui/core/Link';
function Tabrow(props) {
  const [open1, setOpen1] = React.useState(true);
  const [month, setMonth] = React.useState('y');
  const [roleupId, setroleupId] = React.useState([]);
  useEffect(()=>{
    setMonth(props.type)
    setroleupId(props.row)
  },[props.row,props.type])
const rowClick =()=>{
  if(month !== 'm'){
    setOpen1(!open1); props.collTable(roleupId,props.rollupId,open1, props.index)
  }
  
}
const arrowIcon =(icon,rollupId)=>{
 return (<React.Fragment> {icon} {rollupId } </React.Fragment>)
}
const ll = (
  <Link
  component="button"
  onClick={() => {
    props.stepBack(month)
  }}
>
  {typeof props.rollupId === 'string' ?props.rollupId:props.partName}
</Link>
)
  return (
    
       <React.Fragment>
      <TableRow>
       
      <TableCell style={{borderBottom: month== 'm'? '1px solid #fff':''}}>
     
      <React.Fragment>
      <IconButton aria-label="expand row" size="small" onClick={(e) => {rowClick()}}>
        {month== 'p' || month== 'y'? open1?
          arrowIcon(<Add style={{ fontSize: 'small' }}/>):
          arrowIcon(<Remove style={{ fontSize: 'small' }}/>):''
         }
      
      </IconButton>

      { month== 'p'?
          arrowIcon(ll):
          month== 'y'?  
        arrowIcon(<React.Fragment>&nbsp;&nbsp;{ll}</React.Fragment> ):
        arrowIcon((<React.Fragment>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{ll}</React.Fragment>) )
        
         }
      
      </React.Fragment>
    </TableCell>{
   <React.Fragment>
{
(props.header) && props.header.map(data =>{
  return  <TableCell style={{borderBottom: month== 'm'? '1px solid #fff':''}}  align="right">{props[data.key]}</TableCell>
  })
}
  </React.Fragment>
    } 
</TableRow>
</React.Fragment>
  );
}

export default Tabrow;
