import React from "react";
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";
import Paper from "@material-ui/core/Paper";
import ReactSelect, { components as daComponents } from "react-select";
import {SelectLabel, SelectWrapper, SelectSizing} from "./styledComponents";

/**Strip out all class references from CSS or theme
 * 
 * Styled Components List: 
 * -InputFieldWrapper(to make all input divs right size)
 * -SelectWrapper(to proportion the values container and indicators container, etc...)
 * 
 */
export const Select = props => {
  var labelData = props.textFieldProps;
 

  const options = [{
  label:"Select",
  value:' ',
    }].concat(props.options)
  // console.log("optiosn",options)
  
  return (
    <>
    <SelectWrapper>
    <SelectLabel>
     {labelData.label}
    </SelectLabel>
    <SelectSizing>
      <ReactSelect
        label={props.label}
        className={props.className}
        value={props.propertyName || " "}
        onChange={props.handleChange}
        components={props.allComponents}
        options={options}
        margin="normal"
        classes={props.classes}
        isDisabled={props.isDisabled}
        onBlur={props.onBlur ? props.onBlur : null}
        textFieldProps={labelData}
        width={props.width}
      />
      </SelectSizing>
    </SelectWrapper>
    </>

  );
};

// function inputComponent({ inputRef, ...props }) {
//   return (
//     <div style={{ width: props.widthContainer }} ref={inputRef} {...props} />
//   );
// }

export function Control(props) {
  return (
    // <TextField
    //   style={{
    //     width: props.selectProps.width ? props.selectProps.width : "155px",
    //     height: props.selectProps.height? props.selectProps.height : "30px"
    //   }}
    //   id={props.id}
    //   InputProps={{
    //     inputComponent,
    //     inputProps: {
    //       className: props.selectProps.classes.input,
    //       style: {
    //         fontSize: props.selectProps.fontSize? props.selectProps.fontSize : ".6rem"
    //       },
    //       inputRef: props.innerRef,
    //       widthContainer: props.selectProps.width
    //         ? props.selectProps.width
    //         : "180px",
    //       children: props.children,
         
    //     }
    //   }}
    //   {...props.selectProps.textFieldProps}
      
    // />
    <daComponents.Control style={{height: props.selectProps.height ? props.selectProps.height : "30px"}} {...props} />
  );
}
export function SelectContainer({children, ...props}) {
  return(
    <daComponents.SelectContainer       style={{
     //   width: props.selectProps.width ? props.selectProps.width : "155px",
       // height: props.selectProps.height? props.selectProps.height : "30px",
        menuPlacement: "auto", menuPosition: "absolute"}} {...props.innerprops} >
          
      {props.children} 
    </daComponents.SelectContainer>
  )
}

export function Option(props) {
  return (
    <MenuItem
      style={{ fontSize: "11px",  padding: "0px 10px"}}
      selected={props.isFocused}
      component="span"
      {...props.innerProps}
    >
      {props.children}
    </MenuItem>
  );
}

export function Menu({children, ...props}) {
  return (
    // <Paper
    //   square
    //   style={{
    //     borderRadius: 5,
    //     maxHeight: 180,
    //     scrollBehavior: "smooth",
    //     overflow: "auto",
    //     marginTop: 0,
    //     width: props.selectProps.width ? props.selectProps.width : "155 px",
       
    //   }}
    //   className={props.selectProps.classes.paper}
    //   {...props.innerProps}
    // >
    //   {props.children}
    // </Paper>
    <daComponents.Menu style={{borderRadius: 5, maxHeight: 180, width: props.selectProps.width? props.selectProps.width : 155}} {...props.innerProps}>{children}</daComponents.Menu>
  );
}

export function ValueContainer(props) {

  return (
   <daComponents.ValueContainer style={ {padding: 0, margin: 0}} {...props.innerProps}>
      {props.children}
    </daComponents.ValueContainer>
  );
}

export function IndicatorsContainer({children, ...props}) {
  return (
  <daComponents.IndicatorsContainer {...props.innerProps}>
    {children}
  </daComponents.IndicatorsContainer>
  );
}

export const components = {
  SelectContainer,
  IndicatorsContainer,
  Control,
  Menu,
  Option,
};