import React from 'react';
import { Link } from 'react-router-dom';

function Footer() {
  return (
    <footer class="footer mt-2" style={{  position: 'fixed',
         left: '1',
        bottom: '0',
        width: '100%'}}>
    <div class="small container-fluid">
        <div >
            <div style={{display:'inline-block'}}>
                <p>&copy; 2019 Wipro Technologies. All rights reserved. </p>
                
            </div>
            <div  style={{display:'inline-block' , float:'right'}}>
                <ul class="footer-list">
                    <li><a href="#">Contact Us</a>
                    </li>
                    <li><a href="#">Additional Solutions</a>
                    </li>
                    <li><a href="#">Medicare News</a>
                    </li>
                    <li><a href="#">Documents</a>
                    </li>
                    <li><a href="#">MMP Resource Tool Kit</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>
  );
}

export default Footer;