import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { makeStyles } from '@material-ui/core/styles';
import Box from '@material-ui/core/Box';
import Collapse from '@material-ui/core/Collapse';
import IconButton from '@material-ui/core/IconButton';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Typography from '@material-ui/core/Typography';
import Paper from '@material-ui/core/Paper';
import Tabrow from './Tabrow' 

let samArray=[]
const useRowStyles = makeStyles({
root: {
 '& > *': {
   borderBottom: 'unset',
 },
},
});

function Row(props) {
const { row } = props;
const [open, setOpen] = React.useState(false);
const [open1, setOpen1] = React.useState(false);
const collTable= (e,y,flag,ind)=>{

  setOpen1(!open1)
}

return (
 <React.Fragment>
 <Tabrow header ={props.header}  style1={{backgroundColor:'#f6f5f5'}} type ='p' collTable ={()=>{setOpen(!open)}} align="right" {...row}>  </Tabrow>
 { open &&(
     row[props.p1].map((year,ind) =>(
       <React.Fragment>
         <Tabrow header ={props.header} stepBack={(d,k)=>props.stepBack(d,row.partName)} style={{backgroundColor:'#f6f5f5'}} {...year} collTable ={collTable} type ='m' index ={ind} row ={ row.partName} />

</React.Fragment>
)
    ))
}
    
 </React.Fragment>
);
}

export default function DataTable2(props) {
  const [getdata,setdata] = React.useState(props.data)
  useEffect(()=>{
    setdata(props.data);
  },[props.data])
    
return (
 <TableContainer component={Paper}>
   {/* <Table aria-label="collapsible table" style={{backgroundColor:'#d2d2d2'}}>
   <TableRow>
   <TableCell  style ={{width:'30%',borderBottom:'#d2d2d2'}}/>
   <TableCell  style ={{width:'60%', align:'centar'}}>part C</TableCell>
     <TableCell style ={{width:'10%', align:'left'}}>part D</TableCell>
     </TableRow>
   </Table> */}
   <Table aria-label="collapsible table">
     <TableHead>
       <TableRow >
         <TableCell header ='Payment Type' align="center" style={{backgroundColor:'#dfe2ee'}} >
         Payment Type
         </TableCell>
       {
         props.header.map(head =>{
         return (<TableCell header ={props.header}style={{backgroundColor:'#dfe2ee'}}  align="right" onClick={()=>{}}>{head.label}</TableCell>)
         })
       }
       
       </TableRow>
     </TableHead>
     <TableBody>
       {getdata.map((row, i) => (
         //
         <Row stepBack={(d)=>props.stepBack(d,row.rollupId)} p1 ={props.p1}   key={i} row={row} index ={i} header ={props.header}/>
       ))}
     </TableBody>
   </Table>
 </TableContainer>
);
}
