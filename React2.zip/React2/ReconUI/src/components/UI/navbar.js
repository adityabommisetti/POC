import React from 'react';
import Paper from '@material-ui/core/Paper';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';

const styles = (theme) => ({
  headerCellAttestation: {
    color: "white",
    paddingRight: 4,
    paddingLeft: 5,
  },
  // MuiTab-textColorPrimary.Mui-selected {
  //   border-top-left-radius: 10px;
  //   border-top-right-radius: 10px;
  //   color: white !important ;
  //   background-color: #0089cf !important;
  // }
  
  // .MuiTab-textColorPrimary {
  //   border-top-left-radius: 10px !important;
  //   border-top-right-radius: 10px !important;
  //   margin-left: 10px !important;
  //   background-color: #e8e7e7 !important;
  //   color: rgba(0, 0, 0, 0.54);
  // }
  
});
export default function DisabledTabs(props) {
  const [value0, setValue0] = React.useState(0);
  const [value1, setValue1] = React.useState(false);
  React.useEffect(()=>{
    //alert(props.tabno)
    if(props.tabno == 1){
      setValue0(props.setSelect);
      setValue1(false);
    }else{
      setValue1(props.setSelect);
      setValue0(false);
    }
     
  },[props.setSelect])
  const handleChange0 = (event, newValue) => {
    
    const  ll = {
      tabno:1,
      value:newValue,
      text:event.target.innerText
    }
    
    props.trackTab(ll)
    setValue0(newValue);
    setValue1(false);
  };
  const handleChange1 = (event, newValue) => {
    const  ll = {
      tabno:2,
      value:newValue,
      text:event.target.innerText
    }
    props.trackTab(ll)
    setValue1(newValue);
    setValue0(false);
  };

  return (
    <React.Fragment>
      {/* <FullWidthTabs  orientation ={orient} trackTab={subtab} tabs ={dash1} tabno ={1} setSelect ={0}/> */}

      <Tabs
      // props.setSelect
        value={Number.parseInt(value0)}
        indicatorColor="primary"
        textColor="primary"
        onChange={handleChange0}
        orientation= {props.orientation}       
      >
        {
         props.tabs1.map(d=>{
            return (<Tab label={d} 
              // onClick={()=>{alert(d)}}
              style={{   }}/>)
          })
        }
      </Tabs>
      {/* end */}
		   <div style={{paddingTop:'1px'}}>

		   {/* <FullWidthTabs  orientation ={orient} trackTab={subtab} tabs ={dash2} tabno ={2}  setSelect ={false}/> */}
{props.tabs2.length> 0?
       <Tabs
        value={value1}
        indicatorColor="primary"
        textColor="primary"
        onChange={handleChange1}
        aria-label="disabled tabs example"
        orientation= {props.orientation}
       
      >
        {
         props.tabs2.map(d=>{
            return (<Tab label={d} 
              style={{   }}/>)
          })
        }
      </Tabs>:''
}
		   </div>
    </React.Fragment>
     
     
  );
}
