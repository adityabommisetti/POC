import React from 'react';

function MultiSelect(props) {
    const { dataList,
            label,
            propertyName,
            value }
            = props;
    return (
        <span class="label-container label-width">
            <label for="plan-search">{label}</label>
            <select id="plan-search"
                class="form-select"
                disabled={props.disabled?true:false}
                multiple size="3">
                {dataList.map((obj, key) =>
                    <option 
                    style={{backgroundColor:value && value.indexOf(obj.value) != -1 ?
                         "#cecece": ""}}
                        value={obj.value}
                        key={key}
                        onClick={(e)=>props.handleSearchSelect(propertyName, obj.value)}>
                        {obj.label}
                    </option>
                )}
            </select>
        </span>
    );
}

export default MultiSelect;