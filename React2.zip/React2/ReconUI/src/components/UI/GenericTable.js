// import formatTimeStamp, { formatFullTimeStamp } from "../../utils/Utils";
import { TablePagination } from '@material-ui/core';
import Checkbox from "@material-ui/core/Checkbox";
import InputAdornment from "@material-ui/core/InputAdornment";
import { withStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableFooter from "@material-ui/core/TableFooter";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import orderBy from "lodash/orderBy";
import React, { Component } from 'react';
import { styles } from "../../assets/styles/DataTableStyle";
import InputField from "./InputField";
import Pagination from "./Pagination";

const invertDirection = {
  asc: "desc",
  desc: "asc",
};

const StyledTableRow = withStyles((theme) => ({
  root: {
    '&:nth-of-type(odd)': {
      backgroundColor: '#fff',
    },
    '&:nth-of-type(even)': {
      backgroundColor: '#e8e7e7',
    }
  },
}))(TableRow);

class DataTable extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedRow: 0,
      search: "",
      colToSort: "",
      sortDir: "desc",
      page: 0,
      rowsPerPage: this.props.rowsPerPage,
      anchorEl: null,
      exportData: "",
      mobileMoreAnchorEl: null,
      radio: "current",
      index: 0,
      flag: this.props.flag,
      mbrSearch: false,
      sortClick: false,
      selectedPage: 0,
      selectAll: false
    };
  }

  componentDidMount() {
    if (this.props.errorCdTable) {
      this.setState({
        rowsPerPage: parseInt(this.props.data.length)
      })
    }
  }

  async UNSAFE_componentWillReceiveProps(nextProps) {
    const pageNo = Math.floor(nextProps.index / nextProps.rowsPerPage);
    const selectedRow = nextProps.index % nextProps.rowsPerPage;
    if (this.props.searchTable && !this.props.flag) {
      this.setState({
        page: pageNo,
        selectedRow: selectedRow,
        rowsPerPage: parseInt(nextProps.rowsPerPage),
        selectedPage: pageNo,
      })
    } else if (this.props.searchTable && this.props.flag) {
      this.setState({
        page: 0,
        selectedRow: 0,
        colToSort: "",
        sortDir: "",
        selectedPage: 0,
        rowsPerPage: parseInt(nextProps.rowsPerPage)
      })
    } 
  }
  exportDataFunc = async (data, all) => {
    if (all) {
      await this.props.getExportData(true);
      const data = this.props.allExportData
      this.setState({
        exportData: data.slice(),
        radio: 'all',
        displayMessage: true
      })
    } else {
      await this.props.getExportData(false);
      const data = this.props.allExportData
      await this.setState({
        displayMessage: false,
        exportData: data.slice(),
        radio: 'current'
      });
    }
  }

  handleSort = async (colName) => {
    const { selectedRow, rowsPerPage } = this.state
    await this.setState((prevState) => ({
      colToSort: colName,
      sortClick: true,
      sortDir:
        this.state.colToSort === colName
          ? invertDirection[this.state.sortDir]
          : "asc",
      selectedRow: 0
    }));
    //await this.props.handleSort(this.state.colToSort, this.state.sortDir);
  };

  rowSelect = async (rowIndex, data) => {
    const { page, rowsPerPage } = this.state;
    const selectedIndex = page * rowsPerPage + rowIndex;
    this.props.rowSelect(selectedIndex);
    await this.setState({
      sortClick: false,
      selectedPage: page,
      selectedRow: rowIndex
    });
  };

  handleChangePage = async (page) => {
    const {rowsPerPage} = this.state;
    if (typeof page !== "number" && this.state.search === "") {
      await this.props.fetchMore(this.state.page);
      return;
    }
    const index = page * rowsPerPage;
    const selectedIndex =
      page * rowsPerPage;
    this.setState({
      selectedPage: page,
      page,
    });
    this.props.handleChangePage(page);
  };

  handleChangeRowsPerPage = async(event) => {
    await this.setState({ rowsPerPage: event.target.value });
    this.props.handleChangeRowsPerPage(this.state.rowsPerPage);
  };

  handleSelectAll = async(event) => {
    await this.setState({ selectAll: !this.state.selectAll })
    this.props.handleSelectAll(this.state.selectAll)
  }

  handleMobileMenuOpen = (event) => {
    this.setState({ mobileMoreAnchorEl: event.currentTarget });
  };
  handleMobileMenuClose = () => {
    this.setState({ mobileMoreAnchorEl: null });
  };
  handleMenuClose = () => {
    this.setState({ anchorEl: null });
    this.handleMobileMenuClose();
  };
  serachHandle = async (event) => {
    await this.setState({
      search: event.target.value,
    });
  };

  labelDisplayedRows = (from, to, count) => {
    const rowsPerPage = this.state.rowsPerPage;
    return (
      <React.Fragment>
        <span>
          Page :
        {Math.ceil(from / rowsPerPage) !== 0
            ? Math.ceil(from / rowsPerPage)
            : 1}{" "}
        - {}
          {count !== -1
            ? Math.ceil(count / rowsPerPage)
            : Math.ceil(to / rowsPerPage)}
        </span>
        <span>
          &nbsp;
        of {this.props.searchTable ?
            this.props.totalRecords :
            this.props.data.length}
        &nbsp;
        records
      </span>
      </React.Fragment>
    );
  };

  render() {
    const rowsPerPageOptions = [
      {
        label: 5,
        value: 5
      },
      {
        label: 10,
        value: 10
      }];
    const {
      classes,
      searchable,
      sortTable,
      multipleSelect,
      removePagination,
      selectedRow,
      dateColumn,
      notClickable,
    } = this.props;

    const {
      rowsPerPage,
      page,
      exportData,
      selectedPage,
      selectAll,
      colToSort,
      sortDir,
      mobileMoreAnchorEl
    } = this.state;

    let data = this.props.data;
    let isdataExist = data.length > 0;
    const header = this.props.header
    const search = this.state.search.toLowerCase();
    let msg = "NO DATA FOUND";
    if (this.props.msgChange) {
      msg = this.props.msgChange;
    };

    if (this.state.search) {
      data = data.filter((row) => {
        let flag = false;
        header.forEach((object) => {
          if (row[object.key]) {
            const value = row[object.key].toString().toLowerCase();
            if (value.includes(search.toLowerCase())) {
              flag = true;
            }
          }
        });
        return flag;
      });
    };

    if (colToSort) {
      const name = colToSort;
      let tempData = [...data];
      if (dateColumn && dateColumn.includes(colToSort)) {
        tempData.sort(function compare(a, b) {
          let date1 =
            a[name].length === 7
              ? [a[name].slice(0, 3), "01/", a[name].slice(3)].join("")
              : a[name];
          let date2 =
            b[name].length === 7
              ? [b[name].slice(0, 3), "01/", b[name].slice(3)].join("")
              : b[name];

          const result =
            date1 === "99/99/9999"
              ? 1
              : date2 === "99/99/9999"
                ? -1
                : Date.parse(date1) - Date.parse(date2);
          return result;
        });
        if (sortDir === "desc") {
          tempData.reverse();
        }
      } else {
        tempData = orderBy(data, colToSort, sortDir);
      }
      data = [...tempData];
    };

    console.log(data)
    return (
      <div style={{ width: "100%" }}>
        {searchable ? (
          <div>
          <InputField
            id="input-with-icon-adornment"
            value={search}
            placeholder="Search..."
            className={classes.search}
            onChange={this.serachHandle}
            width={"220px"}
            startAdornment={
              <InputAdornment position="start">
                <i className="material-icons">search</i>
              </InputAdornment>
            }
          />
        </div>) : null}
        <div>
          
        </div>
        <div>
          {/* <Select
            components={components}
            propertyName={rowsPerPageOptions.filter(
              option => option.value === rowsPerPage
            )}
            options={rowsPerPage}
            label="Choose Claim Type ..."
            textFieldProps={{
              id: "encType",
              label: "Claim Type",
              InputLabelProps: {
                className: classes.label,
                shrink: true
              }
            }}
            className={classes.textFieldSearch}
            handleChange={this.props.handleChangeRowsPerPage}
            classes={classes}
          /> */}
        </div>
        <div
          className={classes.tableWrapper}
          style={{ width: this.props.width ? this.props.width : "100%" }}
        >
          <Table
            className={removePagination ? classes.tableModified : classes.table}
            id="maintable"
          >
            <TableHead className={classes.thead}>
              <TableRow className={classes.headRow}>
                <TableCell>
                  {multipleSelect?
                  <div>
                    <Checkbox
                      icon={
                        <CheckBoxOutlineBlankIcon style={{ fontSize: "16px" }} />
                      }
                      checkedIcon={
                        <CheckBoxIcon className={classes.encounterCheckBox} />
                      }
                      checked={this.state.selectAll}
                      onClick={this.handleSelectAll}
                      inputProps={{
                        "aria-label": "primary checkbox"
                      }}
                    />
                  </div> : null}
                </TableCell>
                {header.map((mbrCol, i) => (
                  <TableCell
                    align="left"
                    className={classes.headerCell}
                    key={i}
                    style={{ padding: '0.21rem', color: '#ffff' }}
                  >
                    {sortTable && isdataExist ?
                      (<div onClick={() => this.handleSort(mbrCol.key)}>
                        {mbrCol.label}
                        {this.state.colToSort === mbrCol.key
                          ? (
                            this.state.sortDir === "asc" ? (
                              <span class="sort"> &nbsp;&#8593;</span>
                            ) : (
                                <span class="sort"> &nbsp;&#8595;</span>
                              )
                          ) : (
                            <span class="sort sort-default"> &nbsp;&#8597;</span>
                          )}
                      </div>
                      ) : (
                        mbrCol.label
                      )}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>

            <TableBody className={classes.tbody}>
              {data.length < 1 && (
                <TableRow className={classes.row}>
                  <TableCell
                    name='cell'
                    colSpan={header.length}
                    className={classes.tableCell}
                  >
                    {msg}
                  </TableCell>
                </TableRow>
              )}
              {data
                .slice(
                  page * parseInt(rowsPerPage),
                  page * parseInt(rowsPerPage) + parseInt(rowsPerPage)
                )
                .map((genericDetail, j) => (
                  <StyledTableRow
                    className={
                      selectedRow
                        ? classes.row
                        : this.state.selectedRow === j &&
                          page === selectedPage &&
                          !notClickable
                          ? classes.selectedrow
                          : classes.row
                    }
                    key={j}
                  >
                    <TableCell>
                    {multipleSelect ?
                          <div>
                            <Checkbox
                              icon={
                                <CheckBoxOutlineBlankIcon style={{ fontSize: "16px" }} />
                              }
                              checkedIcon={
                                <CheckBoxIcon className={classes.encounterCheckBox} />
                              }
                              checked={genericDetail["isSelected"]}
                              onClick={(e) => this.props.handleSelect(j)}
                              inputProps={{
                                "aria-label": "primary checkbox"
                              }}
                            />
                          </div>: null}
                        </TableCell>
                        
                    {header.map((genericKey, p) => (
                      <React.Fragment>
                        <TableCell
                          key={p}
                          style={{ height: '18px !important' }}
                          align="left"
                          className={classes.tableCell}
                          onClick={notClickable ? () => { } :
                          () => this.rowSelect(j, data[page * rowsPerPage + j])}
                        >
                          {genericDetail[genericKey.key]}
                        </TableCell>
                      </React.Fragment>
                    ))}
                  </StyledTableRow>
                ))}
            </TableBody>
            {!removePagination && data.length > 0 ? (
              <TableFooter className={classes.footer}>
                <TableRow className={classes.footer}>
                  <TablePagination
                    className={classes.pagination}
                    colSpan={header.length+1}
                    count={data.length}
                    rowsPerPage={rowsPerPage}
                    page={page}
                    SelectProps={{
                      native: true,
                    }}
                    classes={{
                      toolbar: classes.footer,
                    }}
                    labelDisplayedRows={({ from, to, count }) =>
                      this.labelDisplayedRows(from, to, count)
                    }
                    rowsPerPageOptions={[]}
                    backIconButtonProps={this.props.searchTable &&
                      (this.props.totalRecords > data.length) &&
                      (!this.state.search)}
                    onChangePage={this.handleChangePage}
                    onChangeRowsPerPage={this.handleChangeRowsPerPage}
                    ActionsComponent={Pagination}
                    nextIconButtonProps={this.fetchMore1}
                  />
                </TableRow>
              </TableFooter>
            ) : null}
          </Table>
        </div>
      </div>
    );
  }
}

export default (withStyles(styles)(DataTable));