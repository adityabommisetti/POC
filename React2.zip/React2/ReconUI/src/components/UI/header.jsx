import React from 'react';
import { Link } from 'react-router-dom';

function Header() {
  return (
    <div className="App">
      <div className="view-container">
        <header>
          <ul className="logo-wrapper">
            <li><img className="header-logo" src={require('../../assets/images/logo-white.png')} alt="" /></li>
            <li><span className="line"></span></li>
            <li className="circle-wrapper hand-icon">
              <span className="logo"></span>
              <span className="logo-name">R360</span>
            </li>
          </ul>

          <ul className="icons-wrapper">
            <li className="pt-2 profile-name pr-0">
              <p>Ramik Wilson</p>
              <span>last login 29/04/2020: 10:30 AM</span>
            </li>
            <li className="pr-3">
              <img className="profile-img" src={require('../../assets/images/avatar.png')} alt="" />
            </li>
            <li>
              <img className="pt-2" src={require('../../assets/images/signout-white.png')} alt="" />
            </li>
          </ul>

        </header>
        <div className="sub-navigation">

          <ul>
            <span className="mobile-nav">
              <Link to='/plan'>
                <li>Plan</li>
              </Link>
              <Link to='/beneficiary'>
                <li>Beneficiary</li>
              </Link>
              <Link to='/pde'>
                <li>PDE</li>
              </Link>
              <Link to='/troop'>
                <li>TrOOP</li>
              </Link>
              <Link to='/discrepancies'>
                <li>Discrepancies</li>
              </Link>
              <Link to='/setUp'>
                <li>Set Up</li>
              </Link>
              <Link to='/annualRecon'>
                <li>Part D Annual Recon</li>
              </Link>
              <Link to='/workQueue'>
                <li>Work Queue</li>
              </Link>
            </span>

          </ul>
        </div>
      </div>
    </div>
  );
}

export default Header;