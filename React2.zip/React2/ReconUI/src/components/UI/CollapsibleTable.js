import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { makeStyles } from '@material-ui/core/styles';
import Box from '@material-ui/core/Box';
import Collapse from '@material-ui/core/Collapse';
import IconButton from '@material-ui/core/IconButton';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Typography from '@material-ui/core/Typography';
import Paper from '@material-ui/core/Paper';
import Tabrow from '../UI/Tabrow' 

let samArray=[]
const useRowStyles = makeStyles({
root: {
 '& > *': {
   borderBottom: 'unset',
 },
},
});

function Row(props) {
const { row } = props;
const [open, setOpen] = React.useState(false);
const [open1, setOpen1] = React.useState(false);
const collTable= (e,y,flag,ind)=>{
for (let i = 0; i < samArray.length; i++) {
   if(Object.keys(samArray[i])[0] === e){
     if((samArray[i])[e].indexOf(y) >=0){
      if(!flag && (samArray[i])[e].indexOf(y) >= 0){
      (samArray[i])[e].splice((samArray[i])[e].indexOf(y),1);
      break
      }
     }
 else if( flag){
     (samArray[i])[e].push(y);
     break
    }
     }else{
      if(Object.keys(samArray[i])[0] !== e && flag){
            samArray.push({[e]:[y]});
            break
      }
     }
}

  if(flag && samArray.length === 0){
    samArray.push({[e]:[y]})
  }
  
  setOpen1(!open1)
}

let ll = row[props.p1]
debugger
return (
 <React.Fragment>
 <Tabrow header ={props.header} stepBack={(d,k)=>props.stepBack(d,row.rollupId)} style1={{backgroundColor:'#f6f5f5'}} type ='p' collTable ={()=>{setOpen(!open)}} align="right" {...row}>  </Tabrow>
 { open &&(
     row[props.p1].map((year,ind) =>(
       <React.Fragment>
         <Tabrow header ={props.header} stepBack={(d,k)=>props.stepBack(d,row.rollupId, year.rollupId)} style={{backgroundColor:'#f6f5f5'}} {...year} collTable ={collTable} type ='y' index ={ind} row ={ row.rollupId} />
{ year[props.p1].map((month) =>(
    <React.Fragment>
    {
    samArray.map(w=>{
    return  (Object.keys(w)[0] === row.rollupId)?(
        <React.Fragment>
          {w[row.rollupId].indexOf(year.rollupId) >= 0?
           (
            <Tabrow header ={props.header} stepBack={(d,k)=>props.stepBack(d,row.rollupId,{month:month.rollupId,year:year.rollupId})} style={{backgroundColor:'#f6f5f5 !important'}} {...month} type ='m'  />
            ):''
    }
 </React.Fragment>
    ):''
    })
  }

 </React.Fragment>))

}
</React.Fragment>
)
    ))
}
    
 </React.Fragment>
);
}

export default function CollapsibleTable(props) {
  const [getdata,setdata] = React.useState(props.data)

  useEffect(()=>{
    setdata(props.data);
  },[props.data])
    
return (
 <TableContainer component={Paper}>
   <Table aria-label="collapsible table" style={{backgroundColor:'#d2d2d2'}}>
   <TableRow>
   <TableCell  style ={{width:'30%',borderBottom:'#d2d2d2'}}/>
   <TableCell  style ={{width:'60%', align:'centar'}}>part C</TableCell>
     <TableCell style ={{width:'10%', align:'left'}}>part D</TableCell>
     </TableRow>
   </Table>
   <Table aria-label="collapsible table">
     <TableHead>
       <TableRow >
         <TableCell header ='Plan' align="center" style={{backgroundColor:'#d2d2d2'}} >
           Plan
         </TableCell>
       {
         props.header.map(head =>{
         return (<TableCell header ={props.header}style={{backgroundColor:'#dfe2ee'}}  align="right" onClick={()=>{}}>{head.label}</TableCell>)
         })
       }
       
       </TableRow>
     </TableHead>
     <TableBody>
       {getdata.map((row, i) => (
         <Row p1 ={props.p1}  stepBack={(d,k,m,y)=>props.stepBack(d,row.rollupId,m,y)} key={row.name} row={row} index ={i} header ={props.header}/>
       ))}
     </TableBody>
   </Table>
 </TableContainer>
);
}
