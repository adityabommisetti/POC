import InfoIcon from '@material-ui/icons/Info';
import React from 'react';
import { withStyles, makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Divider from '@material-ui/core/Divider';
import Modal from '../UI/Modal/Modal'
const StyledTableCell = withStyles((theme) => ({
  head: {
    backgroundColor: 'rgb(223, 226, 238)',
    color: 'black',
  },
  headerIcon:{
        marginLeft: '10px',
 //   position: 'absolute',
    marginTop: '0.189rem'
},
  // head: {
  //   // backgroundColor: theme.palette.common.black,
  //   // color: theme.palette.common.white,
  //    padding:'10px',
  //   // scrollBehavior: 'initial'
  // },
  body: {scrollBehavior: 'initial',
    fontSize: 14,
    
  },
}))(TableCell);

const StyledTableRow = withStyles((theme) => ({
  head: {
    backgroundColor: 'rgb(223, 226, 238)',
    color: 'black',
  },
  root: {
    '&:nth-of-type(odd)': {
      backgroundColor: theme.palette.action.hover,
    },
  }
}))(TableRow);

function createData(name, calories, fat, carbs, protein) {
  return { name, calories, fat, carbs, protein };
}

const rows = [
  createData('Frozen yoghurt', 159, 6.0),
  createData('Ice cream sandwich', 237, 9.0),
  createData('Eclair', 262, 16.0),
  createData('Cupcake', 305, 3.7),
  createData('Gingerbread', 356, 16.0),
];

const useStyles = makeStyles({
  table: {
    //minWidth: 700,
    
  },
});

export default function CustomizedTables(props) {
  const classes = useStyles();
  const  [closePopup, setclosePopup] = React.useState(false)
const modalClosed = ()=>{
  setclosePopup(false)
}
  return (
    <React.Fragment style={{   flexGrow: 3}}>
      <Modal
          dialogTitle="Address"
          message={<h1>hi how are you</h1>}
          show={closePopup}// this.state.closePopup
          modalClosed={() => { 
           modalClosed();
          }}
        ></Modal>
    <TableContainer component={Paper} style={{margin: '3px'}} >
      <Table className={classes.table} aria-label="customized table">
        <TableHead >
          <TableRow   >
            <StyledTableCell >Discrepancy <span className='headerIcon'> <InfoIcon onClick={()=>{setclosePopup(true)}} fontSize="small" style={{color: '#0089cf'}}/></span></StyledTableCell>
            <StyledTableCell align="center">Count</StyledTableCell>
            <StyledTableCell align="center">%</StyledTableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {props.data1.map((row) => (
            <StyledTableRow key={row.disName}>
              {/* 3.	For Part C, display text in bold if "affectPymtInd": "Y".
4.	For Part D, display text in bold if "affectPymtInd": "P" or "affectPymtInd": "A". */}

              <StyledTableCell component="th" scope="row" onClick={()=>{}} style={{fontWeight: row.affectPymtInd === 'Y'|| row.affectPymtInd === 'P'|| row.affectPymtInd === 'A'? 'bold':'normal',color:row.discrepancyCount >0?'#007bff':''}}>
                {row.disName}
              </StyledTableCell>
              <StyledTableCell align="center">{row.discrepancyCount}</StyledTableCell>
              <StyledTableCell align="center">{row.discrepancyPercentage}</StyledTableCell>
            </StyledTableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
    <TableContainer component={Paper} style={{margin: '3px'}}>
      <Table className={classes.table} aria-label="customized table">
        <TableHead>
          <TableRow>
            <StyledTableCell >Discrepancy <span className='headerIcon'> <InfoIcon fontSize="small" onClick={()=>{setclosePopup(true)}}style={{color: '#0089cf'}}/></span></StyledTableCell>
            <StyledTableCell align="center">Count</StyledTableCell>
            <StyledTableCell align="center">%</StyledTableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {props.data2.map((row) => (
            <StyledTableRow key={row.name}>
              <StyledTableCell component="th" scope="row" onClick={()=>{}} style={{fontWeight: row.affectPymtInd === 'Y'|| row.affectPymtInd === 'P'|| row.affectPymtInd === 'A'? 'bold':'normal',color:row.discrepancyCount >0?'#007bff':''}}>
                {row.disName}
              </StyledTableCell>
              <StyledTableCell align="center">{row.discrepancyCount}</StyledTableCell>
              <StyledTableCell align="center">{row.discrepancyPercentage}</StyledTableCell>
            </StyledTableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
    <TableContainer component={Paper} style={{margin: '3px'}}>
      <Table className={classes.table} aria-label="customized table">
        <TableHead>
          <TableRow>
            <StyledTableCell >Discrepancy <span className='headerIcon'> <InfoIcon onClick={()=>{setclosePopup(true)}} fontSize="small" style={{color: '#0089cf'}}/></span></StyledTableCell>
            <StyledTableCell align="center">Count</StyledTableCell>
            <StyledTableCell align="center">%</StyledTableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {props.data3.map((row, i) => (
            <StyledTableRow key={row.disName}>
              <StyledTableCell component="th" scope="row" onClick={()=>{}} style={{fontWeight: (row.affectPymtInd === 'Y'|| row.affectPymtInd === 'P'|| row.affectPymtInd === 'A')? 'bold':'normal',color:row.discrepancyCount >0?'#007bff':''}}>
                {row.disName}
              </StyledTableCell>
              <StyledTableCell align="center">{row.discrepancyCount}</StyledTableCell>
              <StyledTableCell align="center">{row.discrepancyPercentage}</StyledTableCell>
             
            </StyledTableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
    
    </React.Fragment>
  
  );
}
