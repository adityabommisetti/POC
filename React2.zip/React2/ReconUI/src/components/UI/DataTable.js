import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import { withStyles } from '@material-ui/core/styles';

const useStyles = makeStyles({
  table: {
    minWidth: 400,
  },
});

const StyledTableRow = withStyles((theme) => ({
  root: {
    '&:nth-of-type(odd)': {
      backgroundColor: theme.palette.action.hover,
    },
    '&:nth-of-type(even)': {
      backgroundColor: '#ccc',
    }
  },
}))(TableRow);
export default function DataTable(props) {
  const classes = useStyles();

  return (
    <TableContainer component={Paper}>
      <Table className={classes.table} aria-label="simple table">
        <TableHead>
          <TableRow>
              {
                  props.header.map(d=>
                   ( <TableCell style={{backgroundColor:'#dfe2ee',padding:'0.21rem' }}  component="th" scope="row"><strong>{d.label}</strong> </TableCell>)
                  )
              }
          </TableRow>
        </TableHead>
        <TableBody>
          {props.data.map((row) => (
            <StyledTableRow key={row.name}>
              {/* < <TableRow>
                {row.name}
              </ <TableRow> */}
    
              <TableCell >{row.cmsPaid}</TableCell>
              <TableCell >{row.planExpected}</TableCell>
              <TableCell >{row.difference}</TableCell>
              <TableCell >{row.partName}</TableCell>
              <TableCell >{row.description}</TableCell>
            </StyledTableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
