import { withStyles } from "@material-ui/core/styles";
// import { default as React } from "react";
import { Styles } from "../../assets/styles/Theme";
import React,{useContext} from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import FullWidthTabs from '../UI/navbar'
import '../../App.css';
import {PlanHeader} from '../UI/tableHeader' //'./components/UI/tableHeader';
import Paper from "@material-ui/core/Paper";
import CollapsibleTable from "../UI/CollapsibleTable"
import PaymentSummary from '../Plan/PaymentSummary'
import DiscrepancySummary from '../Plan/DiscrepancySummary'
import ShowDiscrepancy from '../Plan/ShowDiscrepancy'
import ShowPayments from '../Plan/ShowPayments'
import Header from '../UI/header';
import {getPaymentDashboard, planAction, getShowDiscrepancy,
     getDiscrepancyDashboard, getDiscrepancySummary, getShowPayments} from '../../Store/Plan/Action/PlanAction'

     import {BeneficiaryAction} from '../../Store/Beneficiary/Action/BeneficiaryAction'
     import { connect } from 'react-redux';
import BeneficiaryDashboard from '../Beneficiary/BeneficiaryDashboard'
import { PlanContext } from '../../Context/PlanContext';
import Footer from "../UI/Footer";
const paydash =['DASHBOARD','Payment Details', 'Discrepancy Details']
const discdash =['Discrepancy Dashboard']

function BeneficiaryDetails(props) {
    const { classes, isExpanded } = props;
   const [dash1,setDash1]= React.useState(paydash)
   const [dash2,setDash2]= React.useState(discdash)
   const [tabselect,settabselect]= React.useState(1)// {tab1:1,tab2:-1}
   const [orient,setorient]= React.useState('horizontal')
   const [tabh,setSelect]= React.useState(0)
   const [toggle,setToggle]= React.useState(true)
   const [ctab, setctab] = React.useState('DASHBOARD');
   const align = window.innerWidth <=500? "vertical":'horizontal'
   const [planContext, setPlanSearch] = useContext(PlanContext);
   React.useEffect(()=>{
    const params ={
        "planNames":["T9999"],
        "hicNumber":"990100340D",
        "startDate":"09/2006",
        "endDate":"09/2006"
    }
    
    props.BeneficiaryAction(params);
   },[])

   React.useEffect(()=>{
    setorient(align)
   },[align])
	const subtab =(tab)=>{
        if(tab.text === 'DASHBOARD'){
            const  index = planContext.tablist.findIndex(x => x.selectedTab ==="paymentDashBoard");
            const payd =   planContext.tablist[index]
               
            setPlanSearch((prevState) => (
                {
                ...prevState,
                selectedTab:  'paymentDashBoard',
                fromDate:payd.fromDate,
                    toDate:payd.toDate,
                    radio:payd.radio,
                    membership:payd.membership
             }
             ));
        }
        if(tab.text === 'DISCREPANCY SUMMARY'){
            const  index = planContext.tablist.findIndex(x => x.selectedTab ==="discrepancySummary");
            const dissum =   planContext.tablist[index]
            
            setPlanSearch((prevState) => (
                {
                    ...prevState,
                    selectedTab:  'discrepancySummary',
                    fromDate:dissum.fromDate,
                    toDate:dissum.toDate,
                    radio:dissum.radio,
                    membership:dissum.membership
                }
             ));
        }
      else  if(tab.text === 'PAYMENT SUMMARY'){
        const  index = planContext.tablist.findIndex(x => x.selectedTab ==="paymentSummary");
        const dissum =   planContext.tablist[index]
       
        setPlanSearch((prevState) => (
            {
            ...prevState,
            selectedTab:  'paymentSummary',
            fromDate:dissum.fromDate,
            toDate:dissum.toDate,
            radio:dissum.radio,
            membership:dissum.membership
         }
         ));
        }
       else if(tab.text === 'DISCREPANCY DASHBOARD'){
        const  index = planContext.tablist.findIndex(x => x.selectedTab ==="discrepancyDashBoard");
        const disd =   planContext.tablist[index]
        
            // setPlanSearch((prevState) => (
            //     {
            //     ...prevState,
            //     selectedTab:  'discrepancyDashBoard',
            //     fromDate:disd.fromDate,
            //     toDate:disd.toDate,
            //     radio:disd.radio,
            //     membership:disd.membership
            //  }
            //  ));
            //  if(props.discprepancyData && props.discprepancyData.length === 0){
            //     callDis()
            // }
           
        }
       setctab(tab.text)
      
// if(tab.tabno === 2){
    settabselect(tab.tabno)
// }
    }
    // const callDis = async() =>{
    //     let pp = {
    //         "Plan":"",
    //         "DateType":"E",
    //         "StartDate":"",
    //         "EndDate":""
    //     }
        
    //      await props.getDiscrepancyDashboard(pp)
    // }
    const  stepBack =(m,k,r)=>{
        alert(m)
        let months = ''
        var month = '';
         if(typeof r === 'object'){
             months = [{month:'January',i:'01'}, {month:'February',i:'02'},{month:'March',i:'03'}, {month:'April',i:'04'}, {month:'May',i:'05'}, {month:'June',i:'06'},
             {month:'July',i:'07'},{month:'August',i:'08'}, {month:'September',i:'09'},{month:'October',i:'10'},{month:'November',i:'11'},{month:'December',i:'12'}]
                 months.map(data=>{
                     if(data.month === r.month){
                        month = data.i
                     }
                     return null
                 });
            }
          
        const ob ={
            "Plan":k,
            "DateType":"",
            "StartDate": m === 'p'?'':typeof r === 'string'?'01/'+r:month+'/'+r.year,
            "EndDate":m === 'p'?'':typeof r === 'string'?'12/'+r:month+'/'+r.year,
            "pbpId":""
            }
            setPlanSearch((prevState) => (
                {
                ...prevState,
                "fromDate": m === 'p'?'':typeof r === 'string'?'01/'+r:month+'/'+r.year,
                "toDate":m === 'p'?'':typeof r === 'string'?'12/'+r:month+'/'+r.year,
                }
             ));
      setToggle(!toggle)
      setSelect( toggle?1:'  1')
       
        if(tabselect === 1 ){
            setctab('PAYMENT SUMMARY')
            setPlanSearch((prevState) => (
                {
                ...prevState,
                selectedTab:  'paymentSummary'
             }
             ));
            props.planAction(ob)
            props.getShowDiscrepancy(ob)
            dash1.length === 1 && setDash1([...dash1,'PAYMENT SUMMARY','Show Discrepancies'])
        }else{
            if(tabselect === 2 ){
                setctab('DISCREPANCY SUMMARY');
               const  index = planContext.tablist.findIndex(x => x.selectedTab ==="discrepancySummary");
               const dis =   planContext.tablist[index]
                setPlanSearch((prevState) => (
                    {
                    ...prevState,
                    selectedTab:  'discrepancySummary',
                      fromDate:dis.fromDate,
                      toDate:dis.toDate,
                      radio:dis.radio,
                      membership:dis.membership
                 }
                 ));

                props.getDiscrepancySummary(ob);
                props.getShowPayments(ob)
                dash2.length === 1 && setDash2([...dash2, 'DISCREPANCY SUMMARY', 'SHOW PAYMENTS'])
            }
        }
       
    }
    const renderSwitch =(param)=> {
   switch(param) {
      
        case 'DASHBOARD':
          return  (props.beneficiaryData&& props.beneficiaryData.paymentDashboardVOList)?
          <BeneficiaryDashboard/>:''
          break;
        case 'PAYMENT SUMMARY':
            return <PaymentSummary/>    
          break;
          case 'DISCREPANCY SUMMARY':
            return <DiscrepancySummary/>    
          break;
          case 'SHOW DISCREPANCIES':
            return <ShowDiscrepancy/>    
          break;
          case 'SHOW PAYMENTS':
            return <ShowPayments/>    
          break;
          case 'DISCREPANCY DASHBOARD':{
         //   return (props.discprepancyData && props.discprepancyData.length>0)? <CollapsibleTable  stepBack ={(d,k,r)=>stepBack(d,k,r)} data ={ props.discprepancyData} header ={DisacpHeader}  p1='discrepancyDashBoardVOList'/>:''
            break;
          }
        default:
          // alert(param)
          // code block
      } 
    }
    // console.clear();
    // console.log(props.beneficiaryData)
    return (
        <React.Fragment>
            <div className={`result-section ${isExpanded ? 'result-close' : ''}`}>
                {isExpanded ?
                    <span className="search-toggle-btn toggle-btn-left" onClick={(e) => props.handleToggle(e)}>
                        <i class="icon icon-angle-left"></i>
                    </span> : null}
                <h1 class="page-heading">Plan</h1>
                <div class="breadcrumb"> Home / Plan</div>
                
                <React.Fragment>
	   <div style={{backgroundColor:'#e9f5ff', border: '1px solid #666699',borderRadius: '5px',width: '88vw'}}>
		   <div style={{ border: '1px solid #e0e0eb', borderRadius: '5px'}}>
			   <Paper>
               <FullWidthTabs  orientation ={orient} trackTab={subtab} tabs2 ={[]} tabs1 ={dash1} tabno ={tabselect} setSelect ={tabh}/>
		   </Paper>
</div>                 
<br/>
<div style={{padding:'20px',paddingTop:'0px',backgroundColor:'#e9f5ff',borderRadius: '5px'}}>
    {renderSwitch(ctab)}
</div>

	   </div>

</React.Fragment>
   <Footer />
            </div>
        </React.Fragment>
    );
}


 const mapStateToProps = state => {
     // beneficiary
  return {
    beneficiaryData: state.beneficiary.beneficiaryDashboard,
     discprepancyData: state.plan.discrepancyDashboard
  };
};

const mapDispatchToProps = {
    BeneficiaryAction,
  getDiscrepancyDashboard,
  getDiscrepancySummary,
  getShowPayments,
  planAction,
  getShowDiscrepancy
};

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(Styles)(BeneficiaryDetails));



  