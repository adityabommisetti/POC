import React,{useContext} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Accordion from '@material-ui/core/Accordion';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import Container from '@material-ui/core/Container';
import { PlanSummaryHeader, PlanSummaryPartD} from '../UI/tableHeader'
import CollapsibleTable from "../UI/CollapsibleTable"
import {planAction} from '../../Store/Plan/Action/PlanAction'
import { OpenInBrowserTwoTone } from '@material-ui/icons';
import {PlanHeader, DisacpHeader} from '../UI/tableHeader'
import { connect } from 'react-redux';
import isEmpty from "lodash/isEmpty";
import { PlanContext } from '../../Context/PlanContext';
const useStyles = makeStyles((theme) => ({
  root: {
    width: '30%',
  },
  container:{
    marginLeft:'0px'
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: '33.33%',
    flexShrink: 0,
    color:'#0089cf',
    fontSize: '1.02rem !important'
  },

}));

 function BeneficiaryDashboard(props) {
  const classes = useStyles();
  const [expanded, setExpanded] = React.useState(false);
  const [expanded1, setExpanded1] = React.useState(false);
  //let subarr1 =[];
  const [subarr1, setsubarr1] = React.useState([]);
  const [planContext, setPlanSearch] = useContext(PlanContext);
  //  React.useEffect(()=>{
  
  //  },[ props.paymentData])
  React.useEffect(()=>{
   
    for (const property in props.paymentData) {
      if(property === 'paymentByPartCVOList'){
        let pp0 =props.paymentData[property]['paymentByPartAVOList'];
        let pp1 =props.paymentData[property]['paymentByPartBVOList'];
        let pp2 =props.paymentData[property]['paymentByPartCVOList'];
        setsubarr1([{...pp0[1],rollupId:[pp0[2],pp0[3]]},
        {...pp1[1],rollupId:[pp1[2],pp1[3]]},
        {...pp2[1],rollupId:[pp2[2],pp2[3]]},
      ])
        
      }
    }
    // if(!isEmpty(props.paymentData)){
    //   const  fromDate=  props.paymentData.latestDateArray[0];
    //   const  toDate=  props.paymentData.latestDateArray[1]
    //     setPlanSearch((prevState) => (
    //       {
    //       ...prevState,
    //       fromDate:  fromDate.substring(4, 6)+'/'+fromDate.substring(0, 4),
    //       toDate:  toDate.substring(4, 6)+'/'+ toDate.substring(0, 4)
    //       }
    //    ));
    //     }
  },[props.paymentData])

  const handleChange1 = (panel) => (event, isExpanded1) => {
    setExpanded1(isExpanded1 ? panel : false);
  };

  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };
const stepBack =()=>{

}

  return (
    <Container fixed className={classes.container}>
    {/* <Typography component="div" style={{ backgroundColor: '#cfe8fc', height: '100vh' }} /> */}
    <React.Fragment className={classes.root}>
      <Accordion style={{backgroundColor:'rgb(231 244 255)',boxShadow: 'none'}} expanded={expanded === 'panel1'} onChange={handleChange('panel1')}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1bh-content"
          id="panel1bh-header"
        >
          <Typography className={classes.heading}>Payments</Typography>
          
        </AccordionSummary>
        <AccordionDetails>
        <Typography  style={{width: '74vw'}}>
    <div style={{padding:'20px',paddingTop:'15px',paddingLeft:'0px',backgroundColor:'#e9f5ff',borderRadius: '5px'}}>
       <CollapsibleTable stepBack ={(d,k,r)=>stepBack(d,k,r)} 
           p1='paymentDashBoardVOList'
           data ={props.beneficiaryData.paymentDashboardVOList} 
           header ={PlanHeader}/>
</div> 
          </Typography>
        </AccordionDetails>
      </Accordion>

      <br/>

      <Accordion style={{backgroundColor:'rgb(231 244 255)',boxShadow: 'none'}} expanded={expanded1 === 'panel2'} onChange={handleChange1('panel2')}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1bh-content"
          id="panel1bh-header"
        >
          <Typography className={classes.heading}>Discrepancy</Typography>
          
        </AccordionSummary>
        <AccordionDetails>
        <Typography  style={{width: '74vw'}}>
    <div style={{padding:'20px',paddingTop:'15px',paddingLeft:'0px',backgroundColor:'#e9f5ff',borderRadius: '5px'}}>
 
          { (!isEmpty(props.beneficiaryData.discrepancyDashboardVOList))? 
          <CollapsibleTable  stepBack ={(d,k,r)=>stepBack(d,k,r)} 
                             data ={ props.beneficiaryData.discrepancyDashboardVOList} 
                             header ={DisacpHeader}  p1='discrepancyDashBoardVOList'/>:''}
</div> 
          </Typography>
        </AccordionDetails>
      </Accordion>

      <br/>
   
    
     </React.Fragment>
  
  </Container>
  );
}
const mapStateToProps = state => {
  return {
      paymentData: state.plan.paymentSummary,
      beneficiaryData: state.beneficiary.beneficiaryDashboard,
  };
};

const mapDispatchToProps = {
  planAction
};

export default connect(mapStateToProps, mapDispatchToProps)(BeneficiaryDashboard);