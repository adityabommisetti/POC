import { withStyles } from "@material-ui/core/styles";
import { default as React } from "react";
import { Styles } from "../../assets/styles/Theme";
import BeneficiarySearch from "./BeneficiarySearch";
import BeneficiaryDetails from "./BeneficiaryDetails";
import { connect } from 'react-redux';
import { getCacheData } from '../../Store/Plan/Action/CacheAction';
import  BeneficiaryContextProvider from '../../Context/PlanContext'
function Beneficiary(props) {
  const { classes } = props;
  const [searchVo, setSearchVo] = React.useState({
    fromDate: "",
    toDate: ""
  })

  const [isExpanded, setisExpanded] = React.useState(false);

  React.useEffect(() => {
    props.getCacheData();
  }, []);

  const setDate = (name, value, targetVo) => {
    if (targetVo === "searchVo") {
      setSearchVo({ ...searchVo, [name]: value })
    }
  };

  const handleToggle = (e) => {
    setisExpanded(!isExpanded)
  };

  return (
    <BeneficiaryContextProvider>
      <div className='main-container'>
        <div className={`search-section ${isExpanded ? 'search-close' : ''}`}>
          <span className="search-toggle-btn toggle-btn-right" onClick={(e) => handleToggle(e)}>
            <i class="icon icon-angle-left"></i>
          </span>
          {!isExpanded ?
            <BeneficiarySearch
              handleToggle={handleToggle}
              isExpanded={isExpanded}
            /> : null}
        </div>
        <BeneficiaryDetails
          handleToggle={handleToggle}
          isExpanded={isExpanded}
        />
      </div>
    </BeneficiaryContextProvider>
  );
}


const mapStateToProps = state => {
  return {
      dropdowns: state.cacheData.dropdowns
  };
};

const mapDispatchToProps = {
  getCacheData
};

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(Styles)(Beneficiary));

