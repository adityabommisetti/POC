import Button from "@material-ui/core/Button";
import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormLabel from "@material-ui/core/FormLabel";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import { withStyles } from "@material-ui/core/styles";
import RadioButtonCheckedIcon from "@material-ui/icons/RadioButtonChecked";
import RadioButtonUncheckedIcon from "@material-ui/icons/RadioButtonUnchecked";
import {searchPlan} from '../../Store/Plan/Action/PlanAction'
import { connect } from 'react-redux';
import React, { useContext } from 'react';
import { PlanContext } from '../../Context/PlanContext';
import { Styles } from "../../assets/styles/Theme";
import * as DateUtil from "../../utils/DatePicker";
import InputField from "../UI/InputField";
import MultiSelect from "../UI/MultiSelect";
import MaterialSelect from "../UI/MaterialSelect";
//import { components, Select } from "../UI/Select";

const dateChk = {};

function BeneficiarySearch(props) {
  const [planContext, setPlanSearch] = useContext(PlanContext);
  
 

  const { classes } = props;
  const [searchVo, setSearchVo] = React.useState({
    fromDate: "",
    toDate: ""
  })
 
 
  const handleDates = (fieldId, targetVo) => {
    var self = this;
    DateUtil.getDatePicker(fieldId).on("change", e => {
      if (dateChk.name !== e.target.name || dateChk.value !== e.target.value) {
        setDate(e.target.name, e.target.value, targetVo);
      }
      dateChk.name = e.target.name;
      dateChk.value = e.target.value;
    });
  };
  const setDate = (name, value, targetVo) => {
    setPlanSearch((prevState) => ({
      ...prevState,
      [name]: value.replace("-", "/")
   }));

    if (targetVo === "searchVo") {
      setSearchVo({ ...searchVo, [name]: value })
    }
  };
  const handleSearchFieldChange = name => event => {
    let value = event.target
      ? event.target.value.toUpperCase()
      : event.value.toUpperCase();
     
    setSearchVo({ ...searchVo, [name]: value })
  };

  const handleSearchSelect = (name , value) => {
    let plan = [value]
   let index = plan.findIndex(x=> x ==value)
   if( index !== -1){
    plan.splice(index, 1)
   } 
  //  plan = [...planContext.plan,value]
   else{
    plan = [...planContext.plan,value]
   // plan.splice(0, 0,value)
   }


    setPlanSearch((prevState) => ({
      ...prevState,
      plan:plan
   }));
  };
const submit=()=>{
  const params ={
    "Plan": planContext.plan[0],
    "DateType":planContext.radio === '0'?'E':'A',
    "StartDate":planContext.fromDate,
    "EndDate":planContext.toDate,
    selectedTab:planContext.selectedTab
}
planContext.tablist.map((data,i) =>{
  if(data.selectedTab === planContext.selectedTab){
    planContext.tablist[i] ={
      selectedTab:planContext.selectedTab,
      plan:planContext.plan,
      fromDate:planContext.fromDate,
       toDate:planContext.toDate,
       radio:planContext.radio,
       membership:'',
     }
       setPlanSearch((prevState) => (
          {
          ...prevState,
          tablist:[...prevState.tablist]
          }
       ));
  }
})

 props.searchPlan(params)
}
  const planIDs = [
    {
   label: "",
   value: ""
  } ];
 
  return (
    <div class="sidebar-search">
      <div class="input-group">
      <MultiSelect
        label="Plan Search"
        dataList={props.cacheData?props.cacheData.PLANSLIST:planIDs}
        propertyName="planID"
        handleSearchSelect={handleSearchSelect}
        disabled ={planContext.disable}
      />

      </div>
 
                <div style={{ marginTop: "40px" }}>
                  <InputField
                    name="fromDate"
                    placeholder="mm/yyyy"
                    label="From"
                    value={planContext.fromDate}
                    onClick={handleDates("#fromDate", "searchVo")}
                    maxLength={6}
                    onChange={handleSearchFieldChange("fromDate")}
                    disabled={planContext.disable}
                    required
                  />
                </div>
                <div>
                  <InputField
                    name="toDate"
                    placeholder="mm/yyyy"
                    label="To"
                    value={planContext.toDate}
                    onClick={handleDates("#toDate", "searchVo")}
                    maxLength={6}
                    disabled={planContext.disable}
                    onChange={handleSearchFieldChange("toDate")}
                    required
                  />
                </div>
              <Button
                        id="reset"
                        variant="contained"
                        style={{ marginTop: "5px" }}
                        color="primary"
                        className={props.classes.button}
                        disabled ={planContext.disable}
                      >
                        Reset
                      </Button>
                      <Button
                        id="reset"
                        variant="contained"
                        style={{ marginTop: "5px" }}
                        color="primary"
                        className={props.classes.button}
                        disabled ={planContext.disable}
                        onClick={()=>{submit()}}
                      >
                        Search
                      </Button>
    </div>
  );
}
const mapStateToProps = state => {
  return {
     cacheData: state.plan.cacheData
  };
};

const mapDispatchToProps = {
  searchPlan
};

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(Styles)(BeneficiarySearch));

