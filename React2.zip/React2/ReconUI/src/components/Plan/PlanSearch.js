import Button from "@material-ui/core/Button";
import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormLabel from "@material-ui/core/FormLabel";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import { withStyles } from "@material-ui/core/styles";
import RadioButtonCheckedIcon from "@material-ui/icons/RadioButtonChecked";
import RadioButtonUncheckedIcon from "@material-ui/icons/RadioButtonUnchecked";
import {searchPlan} from '../../Store/Plan/Action/PlanAction'
import { connect } from 'react-redux';
import React, { useContext } from 'react';
import { PlanContext } from '../../Context/PlanContext';
import { Styles } from "../../assets/styles/Theme";
import * as DateUtil from "../../utils/DatePicker";
import InputField from "../UI/InputField";
import MultiSelect from "../UI/MultiSelect";
import MaterialSelect from "../UI/MaterialSelect";
//import { components, Select } from "../UI/Select";

const dateChk = {};

function PlanSearch(props) {
  const [planContext, setPlanSearch] = useContext(PlanContext);
  
 
  const monthPicker = (selectedDate, field) => {
    if (selectedDate._d) {
      var date = new Date(selectedDate._d),
        mnth = ("0" + (date.getMonth() + 1)).slice(-2),
        selectedDate = [mnth, date.getFullYear()].join("/");
    } else {
      selectedDate = selectedDate.replace(/[^0-9]/g, "").trim();
      selectedDate = selectedDate.replace(/^(\d{2})/, "$1/");
      selectedDate = selectedDate.replace(/(\d)\/(\d{4}).*/, "$1/$2");
    }
    
  };

  const { classes } = props;
  const [searchVo, setSearchVo] = React.useState({
    fromDate: "",
    toDate: ""
  })
 
   const handleChange = (event) => {
    let name = event.target.name;
      setPlanSearch((prevState) => (
        {
        ...prevState,
        radio:name === "apply"?'1':'0'
        }
     ));
  };
  const handleDates = (fieldId, targetVo) => {
    var self = this;
    DateUtil.getDatePicker(fieldId).on("change", e => {
      if (dateChk.name !== e.target.name || dateChk.value !== e.target.value) {
        setDate(e.target.name, e.target.value, targetVo);
      }
      dateChk.name = e.target.name;
      dateChk.value = e.target.value;
    });
  };
  const setDate = (name, value, targetVo) => {
    setPlanSearch((prevState) => ({
      ...prevState,
      [name]: value.replace("-", "/")
   }));

    if (targetVo === "searchVo") {
      setSearchVo({ ...searchVo, [name]: value })
    }
  };
  const handleSearchFieldChange = name => event => {
    let value = event.target
      ? event.target.value.toUpperCase()
      : event.value.toUpperCase();
     
    setSearchVo({ ...searchVo, [name]: value })
  };

  const handleSearchSelect = (name , value) => {
    let plan = [value]
   let index = plan.findIndex(x=> x ==value)
   if( index !== -1){
    plan.splice(index, 1)
   } 
  //  plan = [...planContext.plan,value]
   else{
    plan = [...planContext.plan,value]
   // plan.splice(0, 0,value)
   }
  // console.log("handleSearchSelect")
  // console.log(name);
  // console.log(value);
  // planContext.plan[0]
  // let temp = [...searchVo[name]];
  // const valueIndex = searchVo[name].indexOf(value);
  // if (valueIndex == -1) {
  //   temp = [...temp, value]
  // } else {
  //   temp.splice(valueIndex, 1);
  // }
  // console.log(temp)
  // await setSearchVo(prevState => ({
  //   ...prevState,
  //   [name]: temp
  // }));

    setPlanSearch((prevState) => ({
      ...prevState,
      plan:plan
   }));
  };
const submit=()=>{
  const params ={
    "Plan": planContext.plan[0],
    "DateType":planContext.radio === '0'?'E':'A',
    "StartDate":planContext.fromDate,
    "EndDate":planContext.toDate,
    selectedTab:planContext.selectedTab
}
planContext.tablist.map((data,i) =>{
  if(data.selectedTab === planContext.selectedTab){
    planContext.tablist[i] ={
      selectedTab:planContext.selectedTab,
      plan:planContext.plan,
      fromDate:planContext.fromDate,
       toDate:planContext.toDate,
       radio:planContext.radio,
       membership:'',
     }
       setPlanSearch((prevState) => (
          {
          ...prevState,
          tablist:[...prevState.tablist]
          }
       ));
  }
})

 props.searchPlan(params)
}
  const planIDs = [
    {
   label: "",
   value: ""
  } ];
 
  return (
    <div class="sidebar-search">
      <div class="input-group">
      <MultiSelect
        label="Plan Search"
        dataList={props.cacheData?props.cacheData.PLANSLIST:planIDs}
        propertyName="planID"
        handleSearchSelect={handleSearchSelect}
        disabled ={planContext.disable}
      />
      <MaterialSelect />
      {/* <span class="label-container label-width">
        <label for="plan_search_pbp_search">PBP Search</label>
        <select id="plan_search_pbp_search" class="form-select" multiple size="3">
          <option>All</option>
          <option>PBP1</option>
          <option>PBP2</option>
          <option>PBP3</option>
        </select>
      </span> */}
      </div>
      <div style={{ marginRight: "58px" }}>
                  <FormControl
                    component="fieldset"
                    className={classes.formControl}
                  >
                    <FormLabel
                      component="legend"
                      className={classes.legend}
                    ></FormLabel>
                    <RadioGroup
                      name="planInd"
                      className={classes.group}
                      value={planContext.radio}
                     
                      //onChange={handleSearchFieldChange("dateInd")}
                    >
                      <FormControlLabel
                        value="0"
                        control={
                          <Radio
                          disabled ={planContext.disable}
                          name ='effective'
                          onChange={(e) => handleChange(e)}
                            color="primary"
                            icon={<RadioButtonUncheckedIcon fontSize="small" />}
                            checkedIcon={
                              <RadioButtonCheckedIcon fontSize="small" />
                            }
                          />
                        }
                        label="Effective"
                      />
                      <FormControlLabel
                        value="1"
                        control={
                          <Radio
                          name='apply'
                          disabled ={planContext.disable}
                          onChange={(e) => handleChange(e)}
                            color="primary"
                            icon={<RadioButtonUncheckedIcon fontSize="small" />}
                            checkedIcon={
                              <RadioButtonCheckedIcon fontSize="small" />
                            }
                          />
                        }
                        label="Apply"
                      />
                    </RadioGroup>
                  </FormControl>
                </div>
                <div style={{ marginTop: "40px" }}>
                  <InputField
                    name="fromDate"
                    placeholder="mm/yyyy"
                    label="From"
                    value={planContext.fromDate}
                    onClick={handleDates("#fromDate", "searchVo")}
                    maxLength={6}
                    onChange={handleSearchFieldChange("fromDate")}
                    disabled={planContext.disable}
                    required
                  />
                </div>
                <div>
                  <InputField
                    name="toDate"
                    placeholder="mm/yyyy"
                    label="To"
                    value={planContext.toDate}
                    onClick={handleDates("#toDate", "searchVo")}
                    maxLength={6}
                    disabled={planContext.disable}
                    onChange={handleSearchFieldChange("toDate")}
                    required
                  />
                </div>
              <Button
                        id="reset"
                        variant="contained"
                        style={{ marginTop: "5px" }}
                        color="primary"
                        className={props.classes.button}
                        disabled ={planContext.disable}
                      >
                        Reset
                      </Button>
                      <Button
                        id="reset"
                        variant="contained"
                        style={{ marginTop: "5px" }}
                        color="primary"
                        className={props.classes.button}
                        disabled ={planContext.disable}
                        onClick={()=>{submit()}}
                      >
                        Search
                      </Button>
    </div>
  );
}
const mapStateToProps = state => {
  return {
     cacheData: state.plan.cacheData
  };
};

const mapDispatchToProps = {
  searchPlan
};

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(Styles)(PlanSearch));
//export default withStyles(Styles)(PlanSearch);
