import React,{useContext} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Accordion from '@material-ui/core/Accordion';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import Container from '@material-ui/core/Container';
import TextField from '@material-ui/core/TextField';
import DataTable from '../UI/DataTable'
import DataTable2 from "../UI/Datatable2"
import { PlanSummaryHeader, PlanSummaryPartD} from '../UI/tableHeader'
import {planAction} from '../../Store/Plan/Action/PlanAction'
import { OpenInBrowserTwoTone } from '@material-ui/icons';
import { connect } from 'react-redux';
import isEmpty from "lodash/isEmpty";
import { PlanContext } from '../../Context/PlanContext';
const useStyles = makeStyles((theme) => ({
  root: {
    width: '30%',
  },
  container:{
    marginLeft:'0px'
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: '33.33%',
    flexShrink: 0,
    color:'#0089cf',
    fontSize: '1.02rem !important'
  },

}));

 function PaymentSummary(props) {
  const classes = useStyles();
  const [expanded, setExpanded] = React.useState(false);
  const [expanded1, setExpanded1] = React.useState(false);
  //let subarr1 =[];
  const [subarr1, setsubarr1] = React.useState([]);
  const [planContext, setPlanSearch] = useContext(PlanContext);
  //  React.useEffect(()=>{
  
  //  },[ props.paymentData])
  React.useEffect(()=>{
   
    for (const property in props.paymentData) {
      if(property === 'paymentByPartCVOList'){
        let pp0 =props.paymentData[property]['paymentByPartAVOList'];
        let pp1 =props.paymentData[property]['paymentByPartBVOList'];
        let pp2 =props.paymentData[property]['paymentByPartCVOList'];
        setsubarr1([{...pp0[1],rollupId:[pp0[2],pp0[3]]},
        {...pp1[1],rollupId:[pp1[2],pp1[3]]},
        {...pp2[1],rollupId:[pp2[2],pp2[3]]},
      ])
        
      }
    }
    // if(!isEmpty(props.paymentData)){
    //   const  fromDate=  props.paymentData.latestDateArray[0];
    //   const  toDate=  props.paymentData.latestDateArray[1]
    //     setPlanSearch((prevState) => (
    //       {
    //       ...prevState,
    //       fromDate:  fromDate.substring(4, 6)+'/'+fromDate.substring(0, 4),
    //       toDate:  toDate.substring(4, 6)+'/'+ toDate.substring(0, 4)
    //       }
    //    ));
    //     }
  },[props.paymentData])

  const handleChange1 = (panel) => (event, isExpanded1) => {
    setExpanded1(isExpanded1 ? panel : false);
  };

  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };
const stepBack =()=>{

}

  return (
    <Container fixed className={classes.container}>
    {/* <Typography component="div" style={{ backgroundColor: '#cfe8fc', height: '100vh' }} /> */}
    <React.Fragment className={classes.root}>
  <strong>{props.paymentData && props.paymentData.summaryHeaderTitle}</strong>
      <Accordion style={{backgroundColor:'rgb(231 244 255)',boxShadow: 'none'}} expanded={expanded === 'panel1'} onChange={handleChange('panel1')}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1bh-content"
          id="panel1bh-header"
        >
          <Typography className={classes.heading}>Payment Details - Part C</Typography>
          
        </AccordionSummary>
        <AccordionDetails>
        <Typography  style={{width: '74vw'}}>
          { props.paymentData?
          <div style={{display:'flex',
  justifyContent: 'space-between'}}>
      <div >
      <TextField id="standard-basic" label="CMS Paid" value={ '$'+props.paymentData.workAgedSummaryVO.cmsPaid}  InputProps={{
            readOnly: true,
        
          }} />
      </div> 
 
      <div >
      <TextField id="standard-basic" label="Plan Expected" value={ '$'+props.paymentData.workAgedSummaryVO.planExepected}   InputProps={{
            readOnly: true
          }} />
      </div> <div >
      <TextField id="standard-basic" label="Difference" value={ '$'+props.paymentData.workAgedSummaryVO.difference}   InputProps={{
            readOnly: true
          }} />
      </div>
      </div>
      :''
  }
    <div style={{padding:'20px',paddingTop:'15px',paddingLeft:'0px',backgroundColor:'#e9f5ff',borderRadius: '5px'}}>
<DataTable2 stepBack ={(d)=>stepBack(d)} data ={subarr1} header ={PlanSummaryHeader}
p1='rollupId'/>
</div> 
          </Typography>
        </AccordionDetails>
      </Accordion>

      <br/>

      <Accordion style={{backgroundColor:'rgb(231 244 255)',boxShadow: 'none',width: '74vw'}} expanded={expanded1 === 'panel2'} onChange={handleChange1('panel2')}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1bh-content"
          id="panel1bh-header"
          style={{width: '74vw'}}
        >
          <Typography className={classes.heading}>Payment Details - Part D</Typography>
          
        </AccordionSummary>
        <AccordionDetails >
          <Typography  style={{width: '74vw'}}>
        {props.paymentData?  <div style={{display:'flex',
  justifyContent: 'space-between'}}>
      <div >
      <TextField  label="CMS Paid" value={ '$'+props.paymentData.paymentSummaryHeaderVO.cmsPaid}  InputProps={{
            readOnly: true,
        
          }} />
      </div> <div >
        <TextField  label={"Plan Expected"} value={ '$'+props.paymentData.paymentSummaryHeaderVO.planExpected}  InputProps={{
            readOnly: true,
            
          }} />
      </div> <div >
      <TextField  label="Difference" value={ '$'+props.paymentData.paymentSummaryHeaderVO.difference}  InputProps={{
            readOnly: true
          }} />
      </div>
      </div>
  :''
        }
      <br/> <br/> <br/>
<DataTable data={props.paymentData ? props.paymentData.paymentByPartDVOList:[]} header ={PlanSummaryPartD}/>
          </Typography>
        </AccordionDetails>
      </Accordion>

      <br/>
   
    
      <br/><br/><br/><br/><br/><br/>
     </React.Fragment>
  
  </Container>
  );
}
const mapStateToProps = state => {
  return {
      paymentData: state.plan.paymentSummary,
  };
};

const mapDispatchToProps = {
  planAction
};

export default connect(mapStateToProps, mapDispatchToProps)(PaymentSummary);