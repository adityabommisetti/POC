import { withStyles } from "@material-ui/core/styles";
import { default as React } from "react";
import { Styles } from "../../assets/styles/Theme";
import PlanSearch from "./PlanSearch";
import PlanDetails from "./PlanDetails";
import { connect } from 'react-redux';
import { getCacheData } from '../../Store/Plan/Action/CacheAction';
import  PlanContextProvider from '../../Context/PlanContext'
function Plan(props) {
  const { classes } = props;
  const [searchVo, setSearchVo] = React.useState({
    fromDate: "",
    toDate: ""
  })

  const [isExpanded, setisExpanded] = React.useState(false);

  React.useEffect(() => {
    props.getCacheData();
  }, []);

  const setDate = (name, value, targetVo) => {
    if (targetVo === "searchVo") {
      setSearchVo({ ...searchVo, [name]: value })
    }
  };
  const handleSearchFieldChange = name => event => {
    let value = event.target
      ? event.target.value.toUpperCase()
      : event.value.toUpperCase();
    setSearchVo({ ...searchVo, [name]: value })
  };

  const handleToggle = (e) => {
    setisExpanded(!isExpanded)
  };

  console.log(props.dropdowns)

  return (
    <PlanContextProvider>
      <div className='main-container'>
        <div className={`search-section ${isExpanded ? 'search-close' : ''}`}>
          <span className="search-toggle-btn toggle-btn-right" onClick={(e) => handleToggle(e)}>
            <i class="icon icon-angle-left"></i>
          </span>
          {!isExpanded ?
            <PlanSearch
              handleToggle={handleToggle}
              isExpanded={isExpanded}
            /> : null}
        </div>
        <PlanDetails
          handleToggle={handleToggle}
          isExpanded={isExpanded}
        />
      </div>
    </PlanContextProvider>
  );
}


const mapStateToProps = state => {
  return {
      dropdowns: state.cacheData.dropdowns
  };
};

const mapDispatchToProps = {
  getCacheData
};

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(Styles)(Plan));

