import React,{useContext,useEffect} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Accordion from '@material-ui/core/Accordion';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import Container from '@material-ui/core/Container';
import DataTableIcon from "../UI/DataTableIcon"
import { PlanSummaryHeader, PlanSummaryPartD} from '../UI/tableHeader'
import { PlanContext } from '../../Context/PlanContext';
import {planAction} from '../../Store/Plan/Action/PlanAction'
import {chunk} from 'lodash';
import { connect } from 'react-redux';
const useStyles = makeStyles((theme) => ({
  root: {
    width: '30%',
  },
  container:{
    marginLeft:'0px'
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: '33.33%',
    flexShrink: 0,
    color:'#0089cf',
    fontSize: '1.02rem !important'
  },

}));

 function ShowDiscrepancy(props) {
  const classes = useStyles();
  const [expanded, setExpanded] = React.useState(false);
  const [expanded1, setExpanded1] = React.useState(false);


  const handleChange1 = (panel) => (event, isExpanded1) => {
    setExpanded1(isExpanded1 ? panel : false);
  };

  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };
const stepBack =()=>{

}

let dis1= [];
let dis2= [];
let dis3= [];
let dispartD1= [];
let dispartD2= [];
let dispartD3= [];
if(props.discrepancyData){
  const {discrepancySummaryPartCVOList, discrepancySummaryPartDVOList} = props.discrepancyData;
  let partcLength= Math.ceil(props.discrepancyData.discrepancySummaryPartCVOList.length/3)
  let partdLength= Math.ceil(props.discrepancyData.discrepancySummaryPartDVOList.length/3)

  dis1 = chunk(discrepancySummaryPartCVOList, partcLength)[0]
  dis2 = chunk(discrepancySummaryPartCVOList, partcLength)[1]
  dis3 = chunk(discrepancySummaryPartCVOList, partcLength)[2]

  dispartD1 = chunk(discrepancySummaryPartDVOList, partdLength)[0]
  dispartD2 = chunk(discrepancySummaryPartDVOList, partdLength)[1]
  dispartD3 = chunk(discrepancySummaryPartDVOList, partdLength)[2]
}
const [planContext, setPlanSearch] = useContext(PlanContext);
useEffect(()=>{
  setPlanSearch((prevState) => (
    {
    ...prevState,
    disable:true
    }
 ));
},[])
useEffect(() => {
  return () => { 
    setPlanSearch((prevState) => (
      {
      ...prevState,
      disable:false
      }
   ));
   }
}, [props] );

  return (
    <Container fixed className={classes.container}>
    {/* <Typography component="div" style={{ backgroundColor: '#cfe8fc', height: '100vh' }} /> */}
    <React.Fragment className={classes.root}>
  <strong>{'T9999 for Effective Date July, 2007'}</strong>
      <Accordion style={{backgroundColor:'rgb(231 244 255)',boxShadow: 'none'}} expanded={expanded === 'panel1'} onChange={handleChange('panel1')}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1bh-content"
          id="panel1bh-header"
        >
          <Typography className={classes.heading}>Total Not Closed Discrepancy Counts and Percentages - Part C</Typography>
          
        </AccordionSummary>
        <AccordionDetails>
        <Typography  style={{width: '74vw'}}>
      
    <div style={{padding:'20px',paddingTop:'15px',paddingLeft:'0px',backgroundColor:'#e9f5ff',borderRadius: '5px',display: 'inline-flex',

width: '73vw'}}>
< DataTableIcon data1 ={dis1}  data2 ={dis2}  data3 ={dis3}/>
</div> 
          </Typography>
        </AccordionDetails>
      </Accordion>

      <br/>

      <Accordion style={{backgroundColor:'rgb(231 244 255)',boxShadow: 'none',width: '74vw'}} expanded={expanded1 === 'panel2'} onChange={handleChange1('panel2')}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1bh-content"
          id="panel1bh-header"
          style={{width: '74vw',flexBasis: '36.33%'}}
        >
          <Typography className={classes.heading}>Total Not Closed Discrepancy Counts and Percentages - Part D</Typography>
          
        </AccordionSummary>
        <AccordionDetails >
        <Typography  style={{width: '74vw'}}>
      
      <div style={{padding:'20px',paddingTop:'15px',paddingLeft:'0px',backgroundColor:'#e9f5ff',borderRadius: '5px',display: 'inline-flex',
  
  width: '73vw'}}>
  < DataTableIcon data1 ={dispartD1}  data2 ={dispartD2}  data3 ={dispartD3}/>
  </div> 
            </Typography>
        </AccordionDetails>
      </Accordion>

      <br/>
   
    
      <br/><br/><br/><br/><br/><br/>
     </React.Fragment>
  
  </Container>
  );
}
const mapStateToProps = state => {
  return {
    discrepancyData: state.plan.showDiscrepancy,
  };
};

const mapDispatchToProps = {
  planAction
};

export default connect(mapStateToProps, mapDispatchToProps)(ShowDiscrepancy);