import React from "react";
import { Redirect, Route, Switch, Link } from "react-router-dom";
import { withStyles } from "@material-ui/core/styles";
import {loginAction} from '../../Store/Plan/Action/PlanAction'
import { connect } from 'react-redux';
import { withRouter } from "react-router-dom";
const Login = (props) => {
    const [user, setuserName] =React.useState({userName:'',pass:''})
const loginHandler =(e)=>{
    e.preventDefault()
    props.loginAction(user)
}
const  handleChange = e => {
    let value = e.target.name;
    setuserName({...user,[e.target.name]:e.target.value})
   // alert(value)
}
  return (
    <div class="small-panel">
      <br />
      <br />

      <div class="panel-head-container">
        <h2 class="panel-head">Please enter your User ID and Password</h2>
      </div>
      <form >
        <div class="panel-body">
          <div class="form-panel">
            <span class="label-container label-margin1">
              <label for="user_id">User ID</label>{" "}
              <input
                type="text"
                class="form-field"
                id="user_id"
                value={user.userName}
                name="userName"
                onChange={(e)=>{handleChange(e)}}
              />
            </span>
            <br />
            <span class="label-container">
              <label for="password">Password</label>{" "}
              <input
                type="password"
                class="form-field"
                name="pass"
                value={user.pass}
                onChange={(e)=>{handleChange(e)}}
              />
            </span>
            <br />
            <span class="button-container button-margin1">
              <button
                class="btn btn-primary"
                 disabled={!(user.pass && user.userName)}
                onClick={(e)=>{loginHandler(e)}}
              >
                Login
              </button>
            </span>
          </div>
        </div>
      </form>
    </div>
  );
};


const mapStateToProps = state => {
    return {
        loginData: state,
    };
};

const mapDispatchToProps = {
    loginAction
};

export default connect(mapStateToProps, mapDispatchToProps)(Login);
//export default withRouter((Login));
