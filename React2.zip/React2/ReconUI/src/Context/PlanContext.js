import React, { useState } from 'react';

export const PlanContext = React.createContext();

const PlanContextProvider = props => {
    
  const [planSearch, setPlanSearch] = useState(
      {plan:[],
  fromDate:'',
   toDate:'',
   radio:'0',
   membership:'',
   selectedTab:'paymentDashBoard',
   disable:false,
   tablist:[
   {
    selectedTab:'discrepancySummary',
    plan:[],
    fromDate:'',
     toDate:'',
     radio:'0',
     membership:'',
   },
   {
    selectedTab:'discrepancyDashBoard',
    plan:[],
    fromDate:'',
     toDate:'',
     radio:'0',
     membership:'',
   },
   {
    selectedTab:'paymentSummary',
    plan:[],
    fromDate:'',
     toDate:'',
     radio:'0',
     membership:'',
   },
   {
    selectedTab:'paymentDashBoard',
    plan:[],
    fromDate:'',
     toDate:'',
     radio:'0',
     membership:'',
   }]
  });

  return (
    <PlanContext.Provider
    value={[planSearch, setPlanSearch]}>
      {props.children}
    </PlanContext.Provider>
  );
};

export default PlanContextProvider;