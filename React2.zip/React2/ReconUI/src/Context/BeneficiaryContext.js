import React, { useState } from 'react';

export const BeneficiaryContext = React.createContext();

const BeneficiaryContextProvider = props => {
    
  const [planSearch, setPlanSearch] = useState(
      {plan:[],
  fromDate:'',
   toDate:'',
   radio:'0',
   membership:'',
   selectedTab:'paymentDashBoard',
   disable:false,
   tablist:[
   {
    selectedTab:'discrepancySummary',
    plan:[],
    fromDate:'',
     toDate:'',
     radio:'0',
     membership:'',
   },
   {
    selectedTab:'discrepancyDashBoard',
    plan:[],
    fromDate:'',
     toDate:'',
     radio:'0',
     membership:'',
   },
   {
    selectedTab:'paymentSummary',
    plan:[],
    fromDate:'',
     toDate:'',
     radio:'0',
     membership:'',
   },
   {
    selectedTab:'paymentDashBoard',
    plan:[],
    fromDate:'',
     toDate:'',
     radio:'0',
     membership:'',
   }]
  });

  return (
    <BeneficiaryContext.Provider
    value={[planSearch, setPlanSearch]}>
      {props.children}
    </BeneficiaryContext.Provider>
  );
};

export default BeneficiaryContextProvider;