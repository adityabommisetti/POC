import axios from "axios";

axios.defaults.headers.post["Content-Type"] =
  "application/x-www-form-urlencoded";
axios.defaults.headers.common = {
  ...axios.defaults.headers.common,
  "Content-Type": "application/json"
};
axios.defaults.preflightContinue = true;

const http = axios.create({
   baseURL: "https://techrefresh.medadvantage360.com/recon-api/",
   headers: {
    "Access-Control-Allow-Origin": "*",
     "Access-Control-Allow-Headers": "*",
     "Content-Type": "application/json",
  }
});

export default http;
axios.defaults.crossDomain = true;
