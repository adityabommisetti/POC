import isEmpty from "lodash/isEmpty";
const checkErrorField = (name, searchResults) => {
  const errList = !isEmpty(searchResults) ? searchResults.applErrList : [];
  const array = errList.filter((object) => object.formField === name);
  return array.length > 0;
};

export default checkErrorField;
