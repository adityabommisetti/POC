import moment from "moment";
import isEmpty from "lodash/isEmpty";

export const customValidations = {
  date_after: {
    // name the rule
    message: ":attribute should be greater than start date.",
    rule: (val, params, validator) => {
      console.log(params[0] === val)
      if (val === "99/9999" || params[0] === val) {
        return true;
      }
      const startDate = params[0];
      return moment(val).isAfter(startDate);
    },
  },

  date_after_month_year: {
    // name the rule
    message: ":attribute should be greater than start date.",
    rule: (val, params, validator) => {
      const startDate = params[0];
      const endDate = val;
      var beforeInMoment = moment.utc(startDate, "MM/YYYY");
      var afterInMoment = moment.utc(endDate, "MM/YYYY");
      if (afterInMoment.isAfter(beforeInMoment) || startDate === endDate) {
        return true;
      }
      else {
        return false;
      }
    },
  },

  date_format: {
    message: "Invalid Date Format. Please enter format as MM/DD/YYYY",
    rule: (val, params, validator) => {
      if (
        val === "" ||
        val === null ||
        val === undefined ||
        val === "99/99/9999"
      ) {
        return true;
      }
      return moment(val, "MM/DD/YYYY", true).isValid();
    },
  },

  date_format_month_year: {
    message: "Invalid Date Format. Please enter format as MM/YYYY",
    rule: (val, params, validator) => {
      if (
        val === "" ||
        val === null ||
        val === undefined ||
        val === "99/9999"
      ) {
        return true;
      }
      return moment(val, "MM/YYYY", true).isValid();
    },
  },

  date_format_null: {
    message: "Invalid date. Please format as MM/DD/YYYY",
    rule: (val, params, validator) => {
      if (val === "" || val === null || val === undefined) {
        return true;
      }
      return moment(val, "MM/DD/YYYY", true).isValid();
    },
  },

  phone_no: {
    // name the rule
    message: "Please enter valid 10 digit number.",
    rule: (val, params, validator) => {
      val = val.replace(/[^0-9]/g, "")
      if (val.length !== 10) {
        return false
      }
      return true;
    },
  },

  amountValidator: {
    message: ":attribute is not valid.",
    rule: (val, params, validator) => {
      let regex = /^\s*-?(\d+(\.\d+)?|\.\d+)\s*$/;
      if (!regex.test(val)) {
        return false;
      } else {
        return true;
      }
    },
  },

  clmNbrValidator: {
    message: "The ClaimNbr may only contain letters and numbers.",
    rule: (val, params, validator) => {
      let regex = /^[a-zA-Z0-9,]+$/;
      if (!regex.test(val)) {
        return false;
      } else {
        return true;
      }
    },
  },

  ValidSSN: {
    message: "Invalid SSN Format nnn-nn-nnnn",
    rule: (val, params, validator) => {
      if (val.length === 11) {
        if(val ===  "000-00-0000"){
          return false;
        }else if (isFinite(val.substring(0, 3))) {
          if (val.charAt(3) === "-") {
            if (isFinite(val.substring(4, 6))) {
              if (val.charAt(6) === "-") {
                if (isFinite(val.substring(7))) {
                  return true;
                }
              }
            }
          }
        }
      }
      return false;
    },
  },
  check_Date: {
    message: "Received Date cannot be future date",
    rule: (val, params, validator) => {
      var date = moment(val, "MM/DD/YYYY");
      if (moment() > date) {
        return true;
      } else {
        return false;
      }
    },
  },
  date_formats: {
    message: ":attribute is incorrect \n Please format as MM/DD/YYYY",
    rule: (val, params, validator) => {
      if (val === "99/99/9999") {
        return true;
      }
      if (!moment(val, "MM/DD/YYYY", true)) {
        return false;
      }
    },
  },
  date_format_MM_YYYY: {
    message: "Invalid date , Please format as MM/YYYY",
    rule: (val, params, validator) => {
      if (
        val === "" ||
        val === null ||
        val === undefined
      ) {
        return true;
      }
      return moment(val, "MM/YYYY", true).isValid();
    },
  },
};
