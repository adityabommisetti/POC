import axios from 'axios';

axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';

axios.defaults.headers.common = {
    ...axios.defaults.headers.common,
    "Content-Type": 'application/json',
};
axios.defaults.preflightContinue = true;
//axios.defaults.crossDomain = true;

 
const http =  axios.create({
    // baseURL: 'http://MRMCVDI-030:8086/msslogin-api/',
     baseURL: "https://techrefresh.medadvantage360.com/msslogin-api/",
   // baseURL: "http://172.16.5.185:8081/msslogin-api", // DUSHYANT
   // baseURL: "http://MRMCVDI-032:8082/mss-api/", // nirmal
  // baseURL: "http://MCMRWD-OSD06.MRMC.LOC:8082/mss-api/", // sushree
    // 
    //timeout: 18000,
    headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json',
        'Access-Control-Allow-Headers': '*',
    },
});



export default http;