import $ from "jquery";

const config = {
    showAnim: "clip",
    dateFormat: "mm-yy",
    changeMonth: true,
    changeYear: true,
    yearRange: "c-200:c+200",
    dayNamesMin: ["S", "M", "T", "W", "T", "F", "S"],
}
export const getDatePicker = (fieldId) => {
    return $(fieldId)
        .datepicker(config);
}

export const getStartDatePicker = (fieldId) => {
    return $(fieldId)
        .datepicker({
            ...config,
            beforeShowDay: function (date) {
                if (date.getDate() === 1) {
                    return [true, ""];
                }
                return [false, ""];
            }
        });
}


export const getMonthDatePicker = (fieldId) => {
    return $(fieldId)
        .datepicker({
            ...config,
            dateFormat: "mm/yy",
            beforeShowDay: function (date) {
                if (
                    date.getDate() ===
                    getLastDayOfYearAndMonth(date.getFullYear(), date.getMonth())
                ) {
                    return [true, ""];
                }
                return [false, ""];
            }
        });

}

export const getLastDatePicker = (fieldId) => {
    return $(fieldId)
        .datepicker({
            ...config,
            beforeShowDay: function (date) {
                if (
                    date.getDate() ===
                    getLastDayOfYearAndMonth(date.getFullYear(), date.getMonth())
                ) {
                    return [true, ""];
                }
                return [false, ""];
            }
        });

}

function getLastDayOfYearAndMonth(year, month) {
    return new Date(new Date(year, month + 1, 1) - 1).getDate();
}