import Button from "@material-ui/core/Button";
import FormControlLabel from '@material-ui/core/FormControlLabel';
import MenuItem from '@material-ui/core/MenuItem';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import { withStyles } from "@material-ui/core/styles";
import React from 'react';
import { CSVLink } from "react-csv";
import { Styles } from "../assets/styles/Theme";

function Export(props) {
    const { classes, header, data, page, rowsPerPage } = props;
    const [radio, handleChange] = React.useState("current");
    const [format, handleFormat] = React.useState("csv");
    const [exportData, handleExportData] = React.useState(data);


    React.useEffect(() => {
        if (radio === "current") {
            let filterData = data.slice(
                page * rowsPerPage,
                page * rowsPerPage + rowsPerPage,
            )
            handleExportData(filterData)
        } else {
            handleExportData(data)
        }
    }, [props.page, props.rowsPerPage, radio])

    const handleExport = (e) => {
        var jsPDF = require('jspdf');
        require('jspdf-autotable');
        var doc = new jsPDF();
        doc.autoTable({ html: 'table' });
        doc.save("R360.pdf");
    }

    console.log(radio);
    console.log(format);
    console.log(exportData);
    console.log(props.rowsPerPage);
    console.log(props.page);
    return (
        <React.Fragment>
            <div class="modal-header">
                <h4 class="modal-title">Export/Print</h4>
            </div>
            <div class="export-body">
                <MenuItem>
                    <RadioGroup
                        row
                        className={classes.group}
                        onChange={(e) => handleChange(e.target.value)}
                        value={radio}
                    >
                        <FormControlLabel value="current" control={<Radio color="primary" />} label="Current Page" />
                        <FormControlLabel value="all" control={<Radio color="primary" />} label="All Pages" />
                    </RadioGroup>
                </MenuItem>
                <MenuItem>
                    <RadioGroup
                        row
                        className={classes.group}
                        onChange={(e) => handleFormat(e.target.value)}
                        value={format}
                    >
                        <FormControlLabel value="csv" control={<Radio color="primary" />} label="CSV File" />
                        <FormControlLabel value="pdf" control={<Radio color="primary" />} label="PDF File" />
                    </RadioGroup>
                </MenuItem>
                <div className={props.classes.buttonContainer}>
                    {format === "csv" ?
                        <CSVLink
                            filename={"R360.csv"}
                            className="btn btn-primary"
                            target="_blank"
                            data={exportData}
                            headers={header}
                            separator={","}
                        >
                            <Button
                                variant="contained"
                                color="primary"
                                className={props.classes.button}
                                id="exportButton"
                            >
                                Export
                            </Button>
                        </CSVLink> :
                        <Button
                            variant="contained"
                            color="primary"
                            onClick={(e) => handleExport(exportData, header)}
                            className={props.classes.button}
                            id="exportButton"
                        >
                            Export
                        </Button>}
                    <Button
                        variant="contained"
                        color="primary"
                        onClick={(e) => props.close(e)}
                        className={props.classes.button}
                        id="cancelButton"
                    >
                        Close
                    </Button>
                </div>
            </div>
        </React.Fragment>
    );
}

export default (withStyles(Styles)(Export));

