

import * as ActionTypes from "../ActionType";
import isEmpty from "lodash/isEmpty";
function emptyArrayIfEmpty(data) {
  if (!isEmpty(data)) {
    return data;
  }
  return [];
}

const initialState = {
    beneficiaryDashboard:[],
    discrepancyDashboard:[],
    // showPayments:[]
  };
  export default function beneficiaryReducer(state = initialState, action) {
    switch (action.type) {
      case ActionTypes.BENEFICIARY_DASHBOARD: 
        return {
          ...state, beneficiaryDashboard: action.payload.data,
        };
      case ActionTypes.CACHE_DATA: 
        return {// 
           ...state, cacheData: emptyArrayIfEmpty(action.payload.data),
        };
     

      default:
        return state;
    }
  }
  