//import axios from "../../../utils/axios";
import * as URL from "../../../Services/API_URL";

import * as ActionTypes from "../Action/ActionType";
import axios1 from "../../../utils/CallUrl";


function postRequest(API_URL, body, Success_Action) {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios1
        .post(API_URL, body, {
          headers: {
            "x-auth-token": localStorage.getItem("token"),
          },
        })
        .then((response) => {
          if (response.status === 200) {
              dispatch({
                type: Success_Action,
                payload: response.data
              });        
          } else {
            dispatch({
              type: Success_Action,
              payload: [],
            });
          }

          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return "success";
        })

        .catch((error) => {
          error.response &&
            error.response.data &&
            dispatch({
              type: ActionTypes.SET_SPINNER,
              payload: false,
            });

          // if (error.response && error.response.status === 500) {
          //   if (error.response.headers["x-auth-token"]) {
          //     var token = error.response.headers["x-auth-token"];

          //     localStorage.setItem("token", "Bearer " + token);
          //   }
          // }

          return error//.response.data.message;
        });
    }
    return "success";
  };
}

export const BeneficiaryAction = (searchVO) => {
  return postRequest(
    URL.BENEFICIARY_DASHBOARD,
    searchVO,
    ActionTypes.BENEFICIARY_DASHBOARD
  );
};
