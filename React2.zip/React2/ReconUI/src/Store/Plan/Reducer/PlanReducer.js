

import * as ActionTypes from "../Action/ActionType";
import isEmpty from "lodash/isEmpty";
function emptyArrayIfEmpty(data) {
  if (!isEmpty(data)) {
    return data;
  }
  return [];
}

const initialState = {
    paymentDashboard:[],
    discrepancyDashboard:[],
    // showPayments:[]
  };
  export default function planReducer(state = initialState, action) {
    switch (action.type) {
      case ActionTypes.GET_PAYMENT_DASHBOARD: 
        return {
          ...state, paymentDashboard: action.payload.data,
        };
        case ActionTypes.GET_DISCREPANCY_DASHBOARD: 
        return {
           ...state, discrepancyDashboard: emptyArrayIfEmpty(action.payload.data),
        };
        case ActionTypes.PLAN_SEARCH: 
        let disSum =state.discrepancySummary;
        let  disDash = state.discrepancyDashboard
       if( action.payload.data.discrepancySummaryVOList){
          let spartc =   action.payload.data.discrepancySummaryVOList.discrepancySummaryPartCVOList.map(d=>{

            return  {...d,disName:d.discrepancyName+ '-'+d.discrepancyShortName}
           })
           let spartd =   action.payload.data.discrepancySummaryVOList.discrepancySummaryPartDVOList.map(d=>{
      
            return  {...d,disName:d.discrepancyName+ '-'+d.discrepancyShortName}
           })
       
              if(spartc.length>0 || spartd.length>0){
                disSum = {...action.payload.data.discrepancySummaryVOList,discrepancySummaryPartCVOList:spartc,discrepancySummaryPartDVOList:spartd}
              }
            }
if(action.payload.data.discrepancyDashBoardList){
  disDash = action.payload.data.discrepancyDashBoardList
}
        return {// 
           ...state, paymentDashboard: emptyArrayIfEmpty(action.payload.data.paymentDashBoardList),
            discrepancyDashboard: emptyArrayIfEmpty(disDash),
            discrepancySummary: emptyArrayIfEmpty(disSum)
        };
       

        case ActionTypes.CACHE_DATA: 
        return {// 
           ...state, cacheData: emptyArrayIfEmpty(action.payload.data),
        };
        case ActionTypes.GET_PAYMENT_SUMMARY: 
        return {
          ...state, paymentSummary: emptyArrayIfEmpty(action.payload.data),
        };
        case ActionTypes.GET_DISCREPANCY_SUMMARY: 
     let partc =   action.payload.data.discrepancySummaryPartCVOList.map(d=>{

      return  {...d,disName:d.discrepancyName+ '-'+d.discrepancyShortName}
     })
     let partd =   action.payload.data.discrepancySummaryPartDVOList.map(d=>{

      return  {...d,disName:d.discrepancyName+ '-'+d.discrepancyShortName}
     })
        return {
          ...state, discrepancySummary: {...action.payload.data,discrepancySummaryPartCVOList:partc,discrepancySummaryPartDVOList:partd},
        };
        case ActionTypes.GET_SHOW_DISCREPANCY: 
        let partsc =   action.payload.data.discrepancySummaryPartCVOList.map(d=>{

          return  {...d,disName:d.discrepancyName+ '-'+d.discrepancyShortName}
         })
         let partsd =   action.payload.data.discrepancySummaryPartDVOList.map(d=>{
    
          return  {...d,disName:d.discrepancyName+ '-'+d.discrepancyShortName}
         })
            return {
              ...state, showDiscrepancy: {...action.payload.data,discrepancySummaryPartCVOList:partsc,discrepancySummaryPartDVOList:partsd},
            };
      // case ActionTypes.ADMIN_LOGIN_FAILED:
      //   return {
      //     errorMsg: action.errorMsg
      //   };
      case ActionTypes.GET_SHOW_PAYMENTS: 
      return {
        ...state, showPayment: emptyArrayIfEmpty(action.payload.data),
      };
  
      default:
        return state;
    }
  }
  