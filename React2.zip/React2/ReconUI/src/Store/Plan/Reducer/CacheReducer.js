import * as ActionTypes from "../Action/ActionType";
const initialState = {
    dropdowns:[]
  };
  export default function cacheReducer(state = initialState, action) {
    switch (action.type) {
      case ActionTypes.CACHE_DATA: 
        return {
          ...state, 
          dropdowns: action.payload.data,
        };
      default:
        return state;
    }
  }
  