import { combineReducers } from "redux";
import CacheReducer from "../Reducer/CacheReducer";
import loginReducer from "../Reducer/LoginReducer";
import PlanReducer from "../Reducer/PlanReducer";
import beneficiaryReducer from "../../Beneficiary/Action/Reducer/BeneficiaryReducer"
//import * as ActionTypes from "../../constants/actionConstants/applActionValues";
import DiscrepancyReducer from "../Reducer/DiscrepancyReducer";


const appReducer = combineReducers({
  loginData: loginReducer,
  cacheData: CacheReducer,
  plan:PlanReducer,
  beneficiary:beneficiaryReducer,
  plan:PlanReducer,
  discrepancy:DiscrepancyReducer
});

const rootReducer = (state, action) => {
  return appReducer(state, action);
};

export default rootReducer;
