import * as ActionTypes from "../Action/ActionType";
const initialState = {
    discrepancyData:[]
  };
  export default function discrepancyReducer(state = initialState, action) {
    switch (action.type) {
      case ActionTypes.DISCREPANCY_SEARCH: 
        return {
          ...state, 
          discrepancyData: action.payload.data,
        };
      default:
        return state;
    }
  }
  