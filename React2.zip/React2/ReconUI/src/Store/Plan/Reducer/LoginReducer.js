//import * as ActionTypes from "../../constants/actionConstants/applActionValues";
const initialState = {
  loginVo: {},
  authenticated: false,
  errorMsg: "",
};
export default function loginReducer(state = initialState, action) {
  switch (action.type) {
   
    case'LOGIN_SUCCESS': 
      return {
        tocken: localStorage.getItem("token"),
        authenticated: true,
        errorMsg: ""
      };


    // case ActionTypes.ADMIN_LOGIN_FAILED:
    //   return {
    //     errorMsg: action.errorMsg
    //   };

    

    default:
      return state;
  }
}
