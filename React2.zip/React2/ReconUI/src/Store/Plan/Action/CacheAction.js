//import axios from "../../../utils/axios";
import axios1 from "../../../utils/CallUrl";
import * as ActionTypes from "./ActionType";

export const getCacheData = () => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios1
        .get("recon/reconInitial", {
          headers: {
            "x-auth-token": localStorage.getItem("token"),
          },
        })
        .then((response) => {
          if (response.status === 200) {
              dispatch({
                type: ActionTypes.CACHE_DATA,
                payload: response.data
              });        
          } else {
            dispatch({
              type: ActionTypes.CACHE_DATA,
              payload: [],
            });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return "success";
        })
        .catch((error) => {
          error.response &&
            error.response.data &&
            dispatch({
              type: ActionTypes.SET_SPINNER,
              payload: false,
            });
          return error;
        });
    }
    return "success";
  };
}