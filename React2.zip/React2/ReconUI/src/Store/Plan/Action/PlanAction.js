//import axios from "../../../utils/axios";
import * as URL from "../../../Services/API_URL";
//import * as ActionTypes from "../../constants/actionConstants/applActionValues";
import axios from "../../../utils/axios";
import * as ActionTypes from "./ActionType";
import axios1 from "../../../utils/CallUrl";


function postRequest(API_URL, body, Success_Action) {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios1
        .post(API_URL, body, {
          headers: {
            "x-auth-token": localStorage.getItem("token"),
          },
        })
        .then((response) => {
          if (response.status === 200) {
              dispatch({
                type: Success_Action,
                payload: response.data
              });        
          } else {
            dispatch({
              type: Success_Action,
              payload: [],
            });
          }

          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return "success";
        })

        .catch((error) => {
          error.response &&
            error.response.data &&
            dispatch({
              type: ActionTypes.SET_SPINNER,
              payload: false,
            });

          // if (error.response && error.response.status === 500) {
          //   if (error.response.headers["x-auth-token"]) {
          //     var token = error.response.headers["x-auth-token"];

          //     localStorage.setItem("token", "Bearer " + token);
          //   }
          // }

          return error//.response.data.message;
        });
    }
    return "success";
  };
}
export const loginAction = (loginBody) => {
  return async (dispatch) => {
  var authorizationBasic = window.btoa(
    loginBody.userName + ":" + loginBody.pass
  );
    axios
     .post( "auth/login", '', {
       headers: { Authorization: "Basic " + authorizationBasic },
    })
     .then((response) => {
     if (response.data.statusCode === 200) {
                      var token = response.headers["x-auth-token"];
                      localStorage.setItem("token", "Bearer " + token);
                      localStorage.setItem("login", true);
         dispatch({
                            type:'LOGIN_SUCCESS',//ActionTypes.LOGIN_SUCCESS,
                            payload: response.data,
                          });
                        }
                       
})
     .catch((error) => {
        localStorage.clear();
        console.log(error);

     });
    }
};

export const planAction = (searchVO) => {
  return postRequest(
    URL.GET_PAYMENT_SUMMARY,
    searchVO,
    ActionTypes.GET_PAYMENT_SUMMARY
  );
};

export const getPaymentDashboard = (searchVO) => {
  return postRequest(
    URL.GET_PAYMENT_DASHBOARD,
    searchVO,
    ActionTypes.GET_PAYMENT_DASHBOARD
  );
};

export const getDiscrepancyDashboard = (searchVO) => {
  return postRequest(
    URL.GET_DISCREPANCY_DASHBOARD,
    searchVO,
    ActionTypes.GET_DISCREPANCY_DASHBOARD
  );
};

export const getDiscrepancySummary = (searchVO) => {
  return postRequest(
    URL.GET_DISCREPANCY_SUMMARY,
    searchVO,
    ActionTypes.GET_DISCREPANCY_SUMMARY
  );
};

export const getShowPayments = (searchVO) => {
  return postRequest(
    URL.GET_SHOW_PAYMENTS,
    searchVO,
    ActionTypes.GET_SHOW_PAYMENTS
  );
};

export const getShowDiscrepancy = (searchVO) => {
  return postRequest(
    URL.GET_SHOW_DISCREPANCY,
    searchVO,
    ActionTypes.GET_SHOW_DISCREPANCY
  );
};

export const searchPlan = (searchVO) => {
  return postRequest(
    URL.PLAN_SEARCH,
    searchVO,
    ActionTypes.PLAN_SEARCH
  );
};