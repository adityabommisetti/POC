export const GET_PAYMENT_SUMMARY = "recon/getPaymentSummary";
export const GET_PAYMENT_DASHBOARD = "recon/getPaymentDashboard";
export const GET_DISCREPANCY_DASHBOARD = "recon/getDiscrepancyDashBoard";
export const GET_DISCREPANCY_SUMMARY = "recon/getDiscrepancySummary";
export const GET_SHOW_PAYMENTS = "recon/getShowPayments";
export const GET_SHOW_DISCREPANCY = "recon/getShowDiscrepancies";
export const PLAN_SEARCH = "recon/planSearch";
// Beneficiar
export const BENEFICIARY_DASHBOARD = 'beneficiary/getBeneficiaryDashboard';

// recon/getShowDiscrepancies


/**Discrepancy */
export const DISCREPANCY_SEARCH = "discrepancy/getDiscrepancies";
