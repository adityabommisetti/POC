
export const     Discode =
     [
        {
            Discrepancycode:'BPRR',
            Description:'Rounding, bid used in calculation on the plan side is not the finalized bid ',
            Source:'MMR Field 60 (pos 247 - 254) + 61 (pos 255 - 262) vs Plan Bid'
        },
                                  
        {
            Discrepancycode:'CENR',
            Description:`A CENR discrepancy is generated when a beneficiary appears on CMS file(s) but 
            does not appear on Plan file(s) for a given payment month and PBP ID ',
            Source:'MMR has a record vs No record on the Plan Data File`
        },
                                                
        {
            Discrepancycode:'CNTY ',
            Description:'Data discrepancy between the MMR and plan monthly file',
            Source:'MMR field 10 (pos 55 - 57) vs Plan Data File field 11 (pos 93 - 95)'
        },
                                                                 
        {
            Discrepancycode:'CSRR',
            Description:'Wipro did not receive finalized bid.',
            Source:'MMR fields 56( pos 215 - 222) + 57(pos 223 - 230) vs Plan Bid'
        },
                                                                              
    
    
        {
            Discrepancycode:'DEFF',
            Description:`Informational discrepancy only. If member is new to Medicare he/she has no risk
            factor so CMS uses a default risk factor. Usually Plan has no such information or
            data element  `,
            Source:'MMR fields 23(pos 71). Any value of "Y" or 1 - 6 will cause an informational discrepancy.'
        },
        //  	 	                                                                
    
    
        {
            Discrepancycode:'DOB',
            Description:'CMS data vs Plan data',
            Source:'MMR field 8(pos 41 - 48) vs PDF field 9 (pos 83 - 90)'
        },
        //  	 	                                                
    
        {
            Discrepancycode:'DSBR',
            Description:'Wipro did not receive finalized bid.',
            Source:'MMR field 62 (pos 263 - 270) + 63 (pos 271 - 278) vs Plan Bid'
        }
    ]



//export  const   = 





