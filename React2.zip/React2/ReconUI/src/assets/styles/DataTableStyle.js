export const styles = theme => ({
  table: {
    position: "relative",
    margin: "auto",
    width: "100%",
    border: "1px solid rgba(0,0,0,0.1)"
  },
  tableModified: {
    overflow: "auto"
  },
  exportIcon: {
    float: "right",
    color: "green",
    cursor: "pointer",
    fontSize: "24px"
  },
  icons: {
    cursor: 'pointer'
  },
  excelIcon: {
    fontSize: "24px",
    float: "right",
    color: "green",
    cursor: "pointer",
    padding: "12px"
  },

  csvIcon: {
    fontSize: "24px",
    float: "right",
    color: "#3a94d0",
    cursor: "pointer",
    padding: "12px"
  },

  pdfIcon: {
    fontSize: "24px",
    float: "right",
    color: "red",
    cursor: "pointer",
    padding: "12px"
  },
  textIcon: {
    fontSize: "24px",
    float: "right",
    color: "black",
    cursor: "pointer",
    padding: "12px"
  },
  tableWrapper: {
    display: 'inline-block',
    [theme.breakpoints.down("sm")]: {
      overflowX: "auto",
      display: "grid"
    }
  },
  tableWrapperTest: {
    display: 'inline-block',
    width: "50%",
    [theme.breakpoints.down("sm")]: {
      overflowX: "auto",
      display: "grid"
    }
  },
  exportDisplay: {
    display: "contents"
  },
  exportDisplayDashboard: {
    display: "contents",
    marginBottom: "5px",

  },
  thead: {
    height: "30px",
    background: "#dfe2ee",
    color: "#fff"
  },

  selectedrow: {
    height: "30px",
    backgroundColor: "#cbd4d8",
    "&:hover": {
      cursor: "pointer"
    }
  },
  export: {
    paddingLeft: "16%"
  },

  exportDemo: {
    paddingLeft: "5%"
  },

  displayMessage: {
    wordBreak: "break-all",
    color: "red",
    fontSize: "12px"
  },

  placing: {
    [theme.breakpoints.only("lg")]: {
      top: "27% !important"
    }
  },
  headRow: {
    height: "34px"
  },

  footer: {
    height: "32px",
    minHeight: "32px",
    background: "#fff",
    color: "#000"
  },

  headerRow: {
    width: "60px",
    paddingRight: 4,
    paddingLeft: 30
  },
  tbody: {
    background: "ghostwhite"
  },

  row: {
    height: "30px",
    "&:hover": {
      backgroundColor: "#f2f2f2",
      color: "white",
      cursor: "pointer"
    }
  },
  headerCell: {
    color: "#000 !important",
    fontWeight: "900px",
    paddingRight: 4,
    paddingLeft: 5,
    "&:last-child": { padding: "0px" }
  },

  pagination: {
    color: "white",
    padding: "0px",
  },

  floatRight: {
    float: "right",
    padding: "10px"
  },
  search: {
    [theme.breakpoints.down("sm")]: {
      marginLeft: "2px"
    }
  },
  tableCell: {
    fontSize: "11px",
    paddingRight: 4,
    paddingLeft: 5,
    height: "18px"
  },
  tableCellHeader: {
    paddingRight: 4,
    paddingLeft: 5,
    background: "#053674",
    color: "white",
    height: "34px"
  },
  tableHover: {
    paddingRight: 4,
    paddingLeft: 5,
    height: "34px",
    "&:hover": {
      textDecoration: 'underline',
      cursor: 'pointer'
    }
  },
  headingCell: {
    paddingRight: 4,
    paddingLeft: 5,
    fontWeight: "500"
  },

  svgicon: {
    opacity: 0.0
  },
  validationMessage: {
    color: "red",
    fontSize: "12px",
    marginLeft: "25px",
    width: "180px"
  },
});

export const actionsStyles = theme => ({
  root: {
    flexShrink: 0,
    color: theme.palette.text.secondary,
    marginLeft: theme.spacing.unit * 2.5
  },
  iconButton: {
    padding: "5px",
    color: "#000",
    fontWeight: "bold"
  }
});
