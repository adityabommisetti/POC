import drawerImage from "../images/table.jpg";

export const styles = theme => ({
  table: {
    position: "relative",
    margin: "auto",
    width: "100%",
    // paddingTop: '40%',
    border: "1px solid rgba(0,0,0,0.1)"
  },
  tableModified: {
    overflow: "auto",

  },
  exportIcon: {
    float: "right",
    color: "green",
    cursor: "pointer",
    fontSize: "24px"
  },
  excelIcon: {
    fontSize: "24px",
    float: "right",
    color: "green",
    cursor: "pointer",
    padding: "12px"
  },

  csvIcon: {
    fontSize: "24px",
    float: "right",
    color: "#3a94d0",
    cursor: "pointer",
    padding: "12px"
  },

  pdfIcon: {
    fontSize: "24px",
    float: "right",
    color: "red",
    cursor: "pointer",
    padding: "12px"
  },
  tableWrapper: {
    [theme.breakpoints.down("sm")]: {
      overflowX: "auto",
      display: "grid"
    },
  
   
  },
  exportDisplay: {
    display: "contents"
  },
  thead: {
    height: "20px",
    background: "#36b2e4", // '#0385ba'
    backgroundImage: "url(" + drawerImage + ")",
  
  },

  selectedrow: {
    height: "20px",
    backgroundColor: "#cbd4d8"
  },
  export: {
    paddingLeft: "16%"
  },

  placing: {
    [theme.breakpoints.only("lg")]: {
      top: "27% !important"
    }
  },
  headRow: {
    height: "20px",
    padding:'50px'
  },

  footer: {
    height: "20px",
    minHeight: "20px"
  },

  headerRow: {
    color: "white",
    paddingRight: 4,
    paddingLeft: 30
  },
  tbody: {
    background: "ghostwhite"
  },

  row: {
    height: "20px",
    "&:hover": {
      backgroundColor: "#f2f2f2",
      color: "white"
    }
  },
  headerCell: {
    color: "white",
    paddingRight: 4,
    paddingLeft: 5
  },

  pagination: {
    background: "#36b2e4", //'#0385ba',//'#3ec1ba',//'#0385ba',
    color: "white",
    // height: '15px',
    // minHeight: '15px',
    padding: "0px",
    backgroundImage: "url(" + drawerImage + ")"
  },

  floatRight: {
    float: "right",
    // padding: "10px"
  },
  search: {
    [theme.breakpoints.down("sm")]: {
      marginLeft: "2px"
    }
  },
  tableCell: {
    paddingRight: 4,
    paddingLeft: 5
  },

  tableCellEligCheck: {
    paddingRight: 30,
    paddingLeft: 5,
    height:'20px'
  },
  headingCell: {
    paddingRight: 4,
    paddingLeft: 5,
    fontWeight: "200",
    height:'20px'
  },

  svgicon: {
    opacity: 0.0
  },
  tablecellroot:{    
        
        paddingLeft:'5px',
        paddingRight:'5px',
        paddingTop:'0px !important',
        paddingBottom:'0px !important',
        textAlign: 'left',
        borderBottom: '1px solid rgba(224, 224, 224, 1)',
        verticalAlign: 'inherit',
        textTransform:'uppercase'
  },
});
