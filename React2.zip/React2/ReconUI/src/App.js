import React from 'react';
import { connect } from 'react-redux';
import { BrowserRouter as Router, Switch } from 'react-router-dom';
import './App.css';
import Login from './components/Login/Login';
import Header from './components/UI/header';
import Footer from "./components/UI/Footer";
import Routers from './components/RouterComp.js/Router';
function App(props) {
  return (
    <Router>
      <React.Fragment>

      {
        props.loginData?<Header />:''
      }  
		<div style={{display: 'flex', height: '100px'}}>
      {
        props.loginData? 
        <React.Fragment>
        <Switch>
          <Routers />
        </Switch>
        {/* <Footer/> */}
        </React.Fragment>
        :
       <div style={{marginLeft: 'auto',marginRight: 'auto'}}>
       <Login/>
         </div>	
         }
	   	</div>	
       		
      </React.Fragment>
    </Router>
  );
}
const mapStateToProps = state => {
  return {
      loginData: state.loginData.tocken,
  };
};

const mapDispatchToProps = {
  
};

export default connect(mapStateToProps, mapDispatchToProps)(App);
//export default App;
