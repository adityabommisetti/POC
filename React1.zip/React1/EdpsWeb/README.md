1. Import the Project 
2. npm install in Main directory (Download all the dependencies)
3. npm start
