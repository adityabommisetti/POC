$(document).ready(function () {
			/* ---- Tabs behaviour function ---- */
		var hidWidth;
		var scrollBarWidths = 40;

		var widthOfList = function(){
		  var itemsWidth = 0;
		  $('.tabs .list li').each(function(){
			var itemWidth = $(this).outerWidth();
			itemsWidth+=itemWidth;
		  });
		  return itemsWidth;
		};

		var widthOfHidden = function(){
		  return (($('.tabs .tab-wrapper').outerWidth())-widthOfList()-getLeftPosi())-scrollBarWidths;
		};

		var getLeftPosi = function(){
		  return $('.tabs .list').position().left;
		};

		var reAdjust = function(){
		  if (($('.tabs .tab-wrapper').outerWidth()) < widthOfList()) {
			$('.tabs .scroller-right').show();
		  }
		  else {
			$('.tabs .scroller-right').hide();
		  }
		  
		  if (getLeftPosi()<0) {
			$('.tabs .scroller-left').show();
		  }
		  else {
			$('.tabs .item').animate({left:"-="+getLeftPosi()+"px"},'slow');
			$('.tabs .scroller-left').hide();
		  }
		}

		reAdjust();

		$(window).on('resize',function(e){  
			reAdjust();
		});

		$('.tabs .scroller-right').click(function() {
		  
		  $('.tabs .scroller-left').fadeIn('slow');
		  $('.tabs .scroller-right').fadeOut('slow');
		  
		  $('.tabs .list').animate({left:"+="+widthOfHidden()+"px"},'slow',function(){

		  });
		});

		$('.tabs .scroller-left').click(function() {
		  
			$('.tabs .scroller-right').fadeIn('slow');
			$('.tabs .scroller-left').fadeOut('slow');
		  
			$('.tabs .list').animate({left:"-="+getLeftPosi()+"px"},'slow',function(){
			
			});
		});  

});