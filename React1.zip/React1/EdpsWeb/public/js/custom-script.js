$(document).ready(function () {
		if($(window).width() <= 414){
			$('#sidebar').addClass('active');
			$('#content').addClass('content_active');
		}
		 $('#sidebarCollapse').on('click', function () {
			 $('#sidebar').toggleClass('active');
			 $('#content').toggleClass('content_active');
			//$('#sidebar .list-unstyled li a span').toggle();
			
		 });
		 
		 /* dropdown */
		  $('.panel .panel-head').on('click', function () {
			$(this).toggleClass('open');
			 $(this).next('.panel-body input[type=checkbox],.panel-body input[type=radio]').addClass('visibilityHidden');
			 $(this).next('div').slideToggle("slow",function(){
				  $(this).next('.panel-body input[type=checkbox],.panel-body input[type=radio]').removeClass('visibilityHidden');
			 });
		 });
		 
		 /* slideDown/Up for Temporary and Permanent OOA selection */
		 $( "select#ooa_type2" )
		  .change(function () {
			var x = "";
			$( "select#ooa_type2 option:selected" ).each(function() {
				  if($(this).val()==="Temporary"){
					$("#temporary_ooa").slideDown("slow");
					$("#permanent_ooa").slideUp("slow");
				  }else{
					$("#permanent_ooa").slideDown("slow");
					$("#temporary_ooa").slideUp("slow");
				  }
			});
			
		  });
		  
		/* ------------- Show/Hide Preset Note ------------------ */
		$('#btn_preset_note').on('click', function () {
			 $('#preset_note_section').show();
			 $('#comments_section').hide();
		 });
		 $('#btn_new_comment').on('click', function () {
			 $('#preset_note_section').hide();
			 $('#comments_section').show();
		 });
		 
		 $('.attestation-section').on('click','button#add_attestation', function () {
			 $(this).closest('.attestation-section').append(
			 '<div class="attestation-row"><span class="label-container"><label for="medicare_sep_exception">Medicare SEP Exception</label><br><select id="medicare_sep_exception"><option>Select...</option></select></span><span class="label-container"><label for="attestation_date">Attestation Date *</label><br><select id="attestation_date"><option>Select...</option></select></span><span class="button-container"><button class="btn btn-secondary delete_attestation" >Delete</button></div>'
			 );
		 });
		 $('.attestation-section').on('click','button.delete_attestation', function () {
			 $(this).closest('.attestation-row').remove();
		 });
 
});