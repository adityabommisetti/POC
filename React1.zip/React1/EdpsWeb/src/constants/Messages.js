export const messages={
    UPDATED_SUCCESSFULLY:"Updated Successfully",
    UPDATION_FAILED:"Updation Failed!!",
    DELETED_SUCCESSFULLY:"Deleted Successfully",
    DELETION_FAILED:"Deletion Failed!!",
    INSERTED_SUCCESSFULLY:"Inserted Successfully",
    INSERTION_FAILED:"Insertion Failed!!",
    COPIED_SUCCESSFULLY:"Copied Successfully",
    COPY_FAILED:"Failed to copy"
}