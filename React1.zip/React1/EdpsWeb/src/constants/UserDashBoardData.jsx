export const DASHBOARD_DATA = [
    {
        id:"PCP",
        name :"PCP Assigned",
        count:15,
        type:'S',
        icons:'fa fa-user-md'
    },
    {
        id:"Error",
        name :"Errored Application",
        count:15,
        type:'E',
        icons:'fa fa-user-md'
    },
    {
        id:"Enroll",
        name :"Enrollment Processed'",
        count:15,
        type:'S',
        icons:'fa fa-user-md'
    }

]