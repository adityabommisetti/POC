export const SUBMITTER_ID = [
  {
    label: "SELECT",
    value: ""
  },
    {
      value: "ETEST01",
      label: "ETEST01"
    }
];
export const SUBSCRIBER_STATE = [
  {
    label: "SELECT",
    value: ""
  },
  {
    value: "ONE",
    label: "ONE"
  },
  {
    value: "TWO",
    label: "TWO"
  },
  {
    value: "THREE",
    label: "THREE"
  },
  {
    value: "FOUR",
    label: "FOUR"
  },
  {
    value: "FIVE",
    label: "FIVE"
  },
  {
    value: "SIX",
    label: "SIX"
  }
];
export const PROVIDER_COMMIUNICATION = [
  {
    value: "EM",
    label: "EM"
  },
  {
    value: "FX",
    label: "FX"
  },
  {
    value: "TE",
    label: "TE"
  },
  {
    value: "EX",
    label: "EX"
  }
];

export const PROVIDER_TYPE = [
  {
    value: "1",
    label: "Person"
  },
  {
    value: "2",
    label: "Organization"
  }
];


export const CLAIM_TYPE = [
  {
    label: "SELECT",
    value: ""
  },
  {
    label: "INSTITUTIONAL",
    value: "I"
  },
  {
    label: "PROFESSIONAL",
    value: "P"
  },
  {
    label: "DME",
    value: "E"
  }
];
export const ERROR_SOURCE = [
  {
    label: "ALL",
    value: ""
  },
  {
    label: "COMPLIANCE",
    value: "CCR"
  },
  {
    label: "CMS",
    value: "CMS"
  }
];
export const ERROR_GROUP = [
  {
    label: "ALL",
    value: ""
  },
  {
    label: "MAO002",
    value: "MAO002"
  },
  {
    label: "277CA",
    value: "277GRP"
  },
  {
    label: "999",
    value: "999GRP"
  },
  {
    label: "LEVEL5",
    value: "LEVEL5"
  },
  {
    label: "BASIC",
    value: "BASIC"
  }
];
export const STATUS_CACHE = [
  {
    label: "ALL",
    value: ""
  },
  {
    label: "ACCEPTED",
    value: "ACC"
  },
  {
    label: "ACCEPTED w/Err",
    value: "ACE"
  },
  {
    label: "BASIC",
    value: "BAS"
  },
  {
    label: "COMPLIANCE",
    value: "CCR"
  },
  {
    label: "CORRECTED",
    value: "COR"
  },  
  {
    label: "DELETED",
    value: "DEL"
  },
  {
    label: "FAILED",
    value: "FAL"
  },
  {
    label: "IGNORE",
    value: "IGN"
  },
  {
    label: "LEVEL5",
    value: "LV5"
  },
  {
    label: "PENDING ACCEPT",
    value: "PAC"
  },
  {
    label: "PENDING",
    value: "PEN"
  },
  {
    label: "REJECTED",
    value: "REJ"
  },
  {
    label: "RESUBMIT",
    value: "RES"
  },
  {
    label: "SUBMITTED",
    value: "SUB"
  },
];
export const SEARCH_STATIC_DATA = [
 {
  "claimNbr": "100346",
  "revNbr" : "100346",
  "hicNbr" : "C0009900005",
  "date":"07/01/2017",
  "status":"COR",
  "type":"Professional",
  "cr":"",
 },
 {
  claimNbr : "100346",
  revNbr : "100346",
  hicNbr : "C0009900005",
  date:'07/01/2017',
  status:'COR',
  type:'Professional',
  cr:'',
 },
 {
  claimNbr : "100346",
  revNbr : "100346",
  hicNbr : "C0009900005",
  date:'07/01/2017',
  status:'COR',
  type:'Professional',
  cr:'',
 },
 {
  claimNbr : "100346",
  revNbr : "100346",
  hicNbr : "C0009900005",
  date:'07/01/2017',
  status:'COR',
  type:'Professional',
  cr:'',
 },
 {
  claimNbr : "100346",
  revNbr : "100346",
  hicNbr : "C0009900005",
  date:'07/01/2017',
  status:'COR',
  type:'Professional',
  cr:'',
 },
 {
  claimNbr : "100346",
  revNbr : "100346",
  hicNbr : "C0009900005",
  date:'07/01/2017',
  status:'COR',
  type:'Professional',
  cr:'',
 }
];

export const SEARCH_ERROR_DATA = [
  {
   "segment": "",
   "code" : "98325",
   "source" : "CMS",
   "group":"MAO002",
   "lineSeq":"1",
   "description":"Service Line(s) Duplicated"
  },
  {
    "segment": "",
    "code" : "98325",
    "source" : "CMS",
    "group":"MAO002",
    "lineSeq":"1",
    "description":"Service Line(s) Duplicated"
   },
   {
    "segment": "",
    "code" : "98325",
    "source" : "CMS",
    "group":"MAO002",
    "lineSeq":"1",
    "description":"Service Line(s) Duplicated"
   },
   {
    "segment": "",
    "code" : "98325",
    "source" : "CMS",
    "group":"MAO002",
    "lineSeq":"1",
    "description":"Service Line(s) Duplicated"
   },

]

export const CLAIM_ADJUSTMENT_DATA = [
  {
   "groupCode": "100346",
   "reasonCode" : "100346",
   "amount" : "C0009900005",
   "quantity":"07/01/2017"
  },
  {
    "groupCode": "100346",
    "reasonCode" : "100346",
    "amount" : "C0009900005",
    "quantity":"07/01/2017"
   },

 ];
 export const CLAIM_ATTACHMENT_DATA = [
  {
   "reTypeCode": "100346",
   "transmitCode" : "100346",
   "ctrlNbr" : "C0009900005"
  },
  {
    "reTypeCode": "100346",
    "transmitCode" : "100346",
    "ctrlNbr" : "C0009900005"
   },

 ];

 export const CLAIM_PROVIDER_DATA = [
  {
   "providerType": "Attending Provider",
   "entityType" : "1 - Person",
   "providerName" : "XXXXX XXXXXXXX XXXXXXXXX",
  },
  {
    "providerType": "Rendering Provider",
    "entityType" : "1 - Person",
    "providerName" : "XXXXX XXXXX XXX",
   },
]

