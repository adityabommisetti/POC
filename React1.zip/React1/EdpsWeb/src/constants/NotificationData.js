export const NOTIFICATION_DATA = [

    {
        notificationId :1,
        message : "TRR process got completed",
        user_viewed : true
    },
    
    {
        notificationId :2,
        message : "Member Enrollment Done",
        user_viewed : false
    },
    
    {
        notificationId :3,
        message : "PCP Process got failed",
        user_viewed : false
    },
    
    {
        notificationId :4,
        message : "Password is going to expire ",
        user_viewed : true
    },
]
