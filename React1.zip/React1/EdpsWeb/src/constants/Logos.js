export const logo = require('../assets/images/wipro-logo.png');
export const sidebarbackground = require('../assets/images/sidebar-background.jpg');

export const CUSTOMER_LOGO = {
    HCF0281: require('../assets/images/SSS.jpg'), //TripleS,
    HCF0267: require('../assets/images/UHP_master_logo.jpg'), //UHCA,
    HCF0232: require('../assets/images/VAP_2018_Logo.png'), //Virginia,
    HCF0068: require('../assets/images/Sentara.jpg'), //Sentara,
    HCF0259: require('../assets/images/CFL.jpg'), //CFL,
    HCF0314: require('../assets/images/BCBSTN_Black.jpg'), //BCBSTN,
    HCF0581: require('../assets/images/LACare.jpg'), //LACARE,
    HCF0327: require('../assets/images/IHPLOGO5.jpg'), //ILS,
    HCF0332: require('../assets/images/IHPLOGO6.jpg'), //IHP,
    HCF0331: require('../assets/images/SharpLogo.png'), //SHARP
  }





