export const ENCOUNTER_EXPORT = [
  {
    label: "Source",
    title: "Source",
    key: "source",
    name: "Source",
    prop: "source"
  },
  {
    label: "Extract Date",
    title: "Extract Date",
    key: "extractDate",
    name: "Extract Date",
    prop: "extractDate"
  },
  {
    label: "Submitter Id",
    title: "Submitter Id",
    key: "submitterId",
    name: "Submitter Id",
    prop: "submitterId"
  },
  {
    label: "Search From",
    title: "Search From",
    key: "searchFrom",
    name: "Search From",
    prop: "searchFrom"
  },
  {
    label: "Search To",
    title: "Search To",
    key: "searchTo",
    name: "Search To",
    prop: "searchTo"
  },
  {
    label: "Search Claim Type",
    title: "Search Claim Type",
    key: "claimType",
    name: "Search Claim Type",
    prop: "claimType"
  },
  {
    label: "Search Claim Nbr",
    title: "Search Claim Nbr",
    key: "searchClaimNBR",
    name: "Search Claim Nbr",
    prop: "searchClaimNBR"
  },
  {
    label: "Search VAN Trace Nbr",
    title: "Search VAN Trace Nbr",
    key: "valueAddNtwkTraceNbr",
    name: "Search VAN Trace Nbr",
    prop: "valueAddNtwkTraceNbr"
  },
  {
    label: "Search HICN",
    title: "Search HICN",
    key: "searchHicNbr",
    name: "Search HICN",
    prop: "searchHicNbr"
  },
  {
    label: "Search Medicare ID",
    title: "Search Medicare ID",
    key: "searchMedicareId",
    name: "Search Medicare ID",
    prop: "searchMedicareId"
  },
  {
    label: "Search Status",
    title: "Search Status",
    key: "searchStatus",
    name: "Search Status",
    prop: "searchStatus"
  },
  {
    label: "Search Error Source",
    title: "Search Error Source",
    key: "searchErrorSource",
    name: "Search Error Source",
    prop: "searchErrorSource"
  },
  {
    label: "Search Error Group",
    title: "Search Error Group",
    key: "searchErrorGroup",
    name: "Search Error Group",
    prop: "searchErrorGroup"
  },
  {
    label: "Search Error Code",
    title: "Search Error Code",
    key: "searchErrorCode",
    name: "Search Error Code",
    prop: "searchErrorCode"
  },
  {
    label: "Claim Ref Nbr",
    title: "Claim Ref Nbr",
    key: "wtxClaimRefNbr",
    name: "Claim Ref Nbr",
    prop: "wtxClaimRefNbr"
  },
  {
    label: "Claim Rev Nbr",
    title: "Claim Rev Nbr",
    key: "wtxClaimRevNbr",
    name: "Claim Rev Nbr",
    prop: "wtxClaimRevNbr"
  },
  {
    label: "Pat Ctrl Nbr",
    title: "Pat Ctrl Nbr",
    key: "patCtrlNbr",
    name: "Pat Ctrl Nbr",
    prop: "patCtrlNbr"
  },
  /** */
  {
    label: "HICN",
    title: "HICN",
    key: "hic",
    name: "HICN",
    prop: "hic"
  },
  {
    label: "Medicare ID",
    title: "Medicare ID",
    key: "mbi",
    name: "Medicare ID",
    prop: "mbi"
  },
  {
    label: "Service Date",
    title: "Service Date",
    key: "serviceBeginDtFrmt",
    name: "Service Date",
    prop: "serviceBeginDtFrmt"
  },
  {
    label: "Submission Date",
    title: "Submission Date",
    key: "transFileDtFrmt",
    name: "Submission Date",
    prop: "transFileDtFrmt"
  },
  {
    label: "ENC Type",
    title: "ENC Type",
    key: "claimType",
    name: "ENC Type",
    prop: "claimType"
  },
  {
    label: "Status",
    title: "Status",
    key: "processStatus",
    name: "Status",
    prop: "processStatus"
  },
  {
    label: "CMS ICN",
    title: "CMS ICN",
    key: "cmsIcn",
    name: "CMS ICN",
    prop: "cmsIcn"
  },
  {
    label: "CMS File Id",
    title: "CMS File Id",
    key: "inIntrchgCtrlNbr",
    name: "CMS File Id",
    prop: "inIntrchgCtrlNbr"
  },
  {
    label: "Procedure Code",
    title: "Procedure Code",
    key: "procedureCd",
    name: "Procedure Code",
    prop: "procedureCd"
  },
  {
    label: "Diagnosis Code",
    title: "Diagnosis Code",
    key: "diagnosisCd",
    name: "Diagnosis Code",
    prop: "diagnosisCd"
  },
  {
    label: "Original File Id",
    title: "Original File Id",
    key: "origIntrchgCtrlNbr",
    name: "Original File Id",
    prop: "origIntrchgCtrlNbr"
  },
  {
    label: "Receiver Id",
    title: "Receiver Id",
    key: "receiverId",
    name: "Receiver Id",
    prop: "receiverId"
  },
  {
    label: "Group or Policy Number",
    title: "Group or Policy Number",
    key: "subsGrpOrPolNbr",
    name: "Group or Policy Number",
    prop: "subsGrpOrPolNbr"
  },
  {
    label: "Contract Id",
    title: "Contract Id",
    key: "contarctId",
    name: "Contract Id",
    prop: "contarctId"
  },
  {
    label: "Error Segment",
    title: "Error Segment",
    key: "errorSegment",
    name: "Error Segment",
    prop: "errorSegment"
  },
  {
    label: "Error Code",
    title: "Error Code",
    key: "errorCd",
    name: "Error Code",
    prop: "errorCd"
  },
  {
    label: "Error Source",
    title: "Error Source",
    key: "errorSource",
    name: "Error Source",
    prop: "errorSource"
  },
  {
    label: "Error Group",
    title: "Error Group",
    key: "errorGroup",
    name: "Error Group",
    prop: "errorGroup"
  },
  {
    label: "Claim Line Seq Nbr",
    title: "Claim Line Seq Nbr",
    key: "claimSeqNbr",
    name: "Claim Line Seq Nbr",
    prop: "claimSeqNbr"
  },
  {
    label: "Error Description",
    title: "Error Description",
    key: "errorDesc",
    name: "Error Description",
    prop: "errorDesc"
  },
  {
    label: "MAO004 Status",
    title: "MAO004 Status",
    key: "maoflag",
    name: "MAO004 Status",
    prop: "maoflag"
  },
  {
    label: "Allowed/Disallowed",
    title: "Allowed/Disallowed",
    key: "allowedDisallowedFlag",
    name: "Allowed/Disallowed",
    prop: "allowedDisallowedFlag"
  }
];


export const CLAIM_VERSION = [
  {
    label: "Sequence Number",
    title: "claimSeqNbr",
    key: "claimSeqNbr"
  },
  {
    label: "Status",
    title: "Status",
    key: "processStatus"
  },
  {
    label: "Frequency Code",
    title: "Frequency Code",
    key: "clmFreqCdDesc"
  },
  {
    label: "Override Desc",
    title: "Override Desc",
    key: "overrideIndDesc"
  }
];

export const VANTAN_SEARCH = [
  {
    label: "Sequence Number",
    title: "Sequence Number",
    key: "claimSeqNbr"
  },
  {
    label: "Claim Ref Nbr",
    title: "Claim Ref Nbr",
    key: "wtxClaimRefNbr"
  },
  {
    label: "Original Claim Nbr",
    title: "Original Claim Nbr",
    key: "origClmRefNbr"
  },
  {
    label: "Adjusted Claim Nbr",
    title: "Adjusted Claim Nbr",
    key: "adjClmRefNbr"
  },
  {
    label: "Status",
    title: "Status",
    key: "processStatus"
  },
  {
    label: "Override Desc",
    title: "Override Desc",
    key: "overrideIndDesc"
  }
];

export const LOG_DETAILS_EXPORT = [
  {
    label: "Claim Ref Nbr",
    title: "Claim Ref Nbr",
    key: "wtxClaimRefNbr",
    name: "Claim Ref Nbr",
    prop: "wtxClaimRefNbr"
  },
  {
    label: "Claim Rev Nbr",
    title: "Claim Rev Nbr",
    key: "wtxClaimRevNbr",
    name: "Claim Rev Nbr",
    prop: "wtxClaimRevNbr"
  },
  {
    label: "Log Time",
    title: "Log Time",
    key: "formattedLogTime",
    name: "Log Time",
    prop: "formattedLogTime"
  },
  {
    label: "Entity Name",
    title: "Entity Name",
    key: "screenBlock",
    name: "Entity Name",
    prop: "screenBlock"
  },
  {
    label: "Field Name",
    title: "Field Name",
    key: "screenField",
    name: "Field Name",
    prop: "screenField"
  },

  {
    label: "Value Before",
    title: "Value Before",
    key: "valueBefore",
    name: "Value Before",
    prop: "valueBefore"
  },

  {
    label: "Value After",
    title: "Value After",
    key: "valueAfter",
    name: "Value After",
    prop: "valueAfter"
  },
  {
    label: "User Id",
    title: "User Id",
    key: "createUserid",
    name: "User Id",
    prop: "createUserid"
  }
];



export const DASHBOARD_EXPORT = [
  {
    label: "Source",
    title: "Source",
    key: "source",
    name: "Source",
    prop: "source"
  },
  {
    label: "Extract Date",
    title: "Extract Date",
    key: "extractDate",
    name: "Extract Date",
    prop: "extractDate"
  },
  {
    label: "Submitter Id",
    title: "Submitter Id",
    key: "submitterId",
    name: "Submitter Id",
    prop: "submitterId"
  },

  {
    label: "Search From",
    title: "Search From",
    key: "searchFrom",
    name: "Search From",
    prop: "searchFrom"
  },

  {
    label: "Search To",
    title: "Search To",
    key: "searchTo",
    name: "Search To",
    prop: "searchTo"
  },
  {
    label: "Date Type",
    title: "Date Type",
    key: "dateType",
    name: "Date Type",
    prop: "dateType"
  },
  {
    label: "Service/Submission Date",
    title: "Service/Submission Date",
    key: "formatedDate",
    name: "Service/Submission Date",
    prop: "formatedDate"
  },
  {
    label: "Institutional Pending",
    title: "Institutional Pending",
    key: "instPending",
    name: "Institutional Pending",
    prop: "instPending"
  },
  {
    label: "Institutional Accepted",
    title: "Institutional Accepted",
    key: "instAccepted",
    name: "Institutional Accepted",
    prop: "instAccepted"
  },
  {
    label: "Institutional Rejected",
    title: "Institutional Rejected",
    key: "instRejected",
    name: "Institutional Rejected",
    prop: "instRejected"
  },
  {
    label: "Institutional Ignored",
    title: "Institutional Ignored",
    key: "instIgnored",
    name: "Institutional Ignored",
    prop: "instIgnored"
  },
  {
    label: "Totals",
    title: "Totals",
    key: "instTotal",
    name: "Totals",
    prop: "instTotal"
  },
  {
    label: "Professional Pending",
    title: "Professional Pending",
    key: "profPending",
    name: "Professional Pending",
    prop: "profPending"
  },
  {
    label: "Professional Accepted",
    title: "Professional Accepted",
    key: "profAccepted",
    name: "Professional Accepted",
    prop: "profAccepted"
  },
  {
    label: "Professional Rejected",
    title: "Professional Rejected",
    key: "profRejected",
    name: "Professional Rejected",
    prop: "profRejected"
  },
  {
    label: "Professional Ignored",
    title: "Professional Ignored",
    key: "profIgnored",
    name: "Professional Ignored",
    prop: "profIgnored"
  },
  {
    label: "Totals",
    title: "Totals",
    key: "profTotal",
    name: "Totals",
    prop: "profTotal"
  },
  {
    label: "DME Pending",
    title: "DME Pending",
    key: "dmePending",
    name: "DME Pending",
    prop: "dmePending"
  },
  {
    label: "DME Accepted",
    title: "DME Accepted",
    key: "dmeAccepted",
    name: "DME Accepted",
    prop: "dmeAccepted"
  },
  {
    label: "DME Rejected",
    title: "DME Rejected",
    key: "dmeRejected",
    name: "DME Rejected",
    prop: "dmeRejected"
  },
  {
    label: "DME Ignored",
    title: "DME Ignored",
    key: "dmeIgnored",
    name: "DME Ignored",
    prop: "dmeIgnored"
  },
  {
    label: "Totals",
    title: "Totals",
    key: "dmeTotal",
    name: "Totals",
    prop: "dmeTotal"
  }
];

export const ERRORCODE_EXPORT = [
  {
    label: "Source",
    title: "Source",
    key: "source",
    name: "Source",
    prop: "source"
  },
  {
    label: "Extract Date",
    title: "Extract Date",
    key: "extractDate",
    name: "Extract Date",
    prop: "extractDate"
  },
  {
    label: "Submitter Id",
    title: "Submitter Id",
    key: "submitterId",
    name: "Submitter Id",
    prop: "submitterId"
  },
  {
    label: "Claim Type",
    title: "Claim Type",
    key: "encTypeDesc",
    name: "Claim Type",
    prop: "encTypeDesc"
  },
  {
    label: "Search From",
    title: "Search From",
    key: "formattedsearchFrom",
    name: "Search From",
    prop: "formattedsearchFrom"
  },
  {
    label: "Search To",
    title: "Search To",
    key: "formattedsearchTo",
    name: "Search To",
    prop: "formattedsearchTo"
  },
  {
    label: "Error Source",
    title: "Error Source",
    key: "errorSourceDesc",
    name: "Error Source",
    prop: "errorSourceDesc"
  },
  {
    label: "Error Group",
    title: "Error Group",
    key: "errorGroupDesc",
    name: "Error Group",
    prop: "errorGroupDesc"
  },
  {
    label: "Error Code",
    title: "Error Code",
    key: "errorCd",
    name: "Error Code",
    prop: "errorCd"
  },
  {
    label: "Date Type",
    title: "Date Type",
    key: "dateType",
    name: "Date Type",
    prop: "dateType"
  },
  {
    label: "Service/Submission Date",
    title: "Service/Submission Date",
    key: "formattedDateYrmo",
    name: "Service/Submission Date",
    prop: "formattedDateYrmo"
  },
  {
    label: "Source",
    title: "Source",
    key: "errorSourceDesc",
    name: "Source",
    prop: "errorSourceDesc"
  },
  {
    label: "Group",
    title: "Group",
    key: "errorGroupDesc",
    name: "Group",
    prop: "errorGroupDesc"
  },
  {
    label: "Reject Code",
    title: "Reject Code",
    key: "errorCd",
    name: "Reject Code",
    prop: "errorCd"
  },
  {
    label: "Reject Description",
    title: "Reject Description",
    key: "errorDescription",
    name: "Reject Description",
    prop: "errorDescription"
  },
  {
    label: "Error Total",
    title: "Error Total",
    key: "errorCnt",
    name: "Error Total",
    prop: "errorCnt"
  },
  {
    label: "Claim Total",
    title: "Claim Total",
    key: "clmCnt",
    name: "Claim Total",
    prop: "clmCnt"
  },
  {
    label: "Type",
    title: "Type",
    key: "encTypeDesc",
    name: "Type",
    prop: "encTypeDesc"
  }
];

export const REJECT_EXPORT = [
  {
    label: "Source",
    title: "Source",
    key: "source",
    name: "Source",
    prop: "source"
  },
  {
    label: "Extract Date",
    title: "Extract Date",
    key: "extractDate",
    name: "Extract Date",
    prop: "extractDate"
  },
  {
    label: "Submitter Id",
    title: "Submitter Id",
    key: "submitterId",
    name: "Submitter Id",
    prop: "submitterId"
  },

  {
    label: "Search From",
    title: "Search From",
    key: "searchFrom",
    name: "Search From",
    prop: "searchFrom"
  },

  {
    label: "Search To",
    title: "Search To",
    key: "searchTo",
    name: "Search To",
    prop: "searchTo"
  },
  {
    label: "Date Type",
    title: "Date Type",
    key: "dateType",
    name: "Date Type",
    prop: "dateType"
  },
  {
    label: "Service/Submission Date",
    title: "Service/Submission Date",
    key: "formatedDate",
    name: "Service/Submission Date",
    prop: "formatedDate"
  },
  {
    label: "Institutional CCR",
    title: "Institutional CCR",
    key: "instCCR",
    name: "Institutional CCR",
    prop: "instCCR"
  },
  {
    label: "Institutional Rejected",
    title: "Institutional Rejected",
    key: "instRejected",
    name: "Institutional Rejected",
    prop: "instRejected"
  },
  {
    label: "Totals",
    title: "Totals",
    key: "instTotal",
    name: "Totals",
    prop: "instTotal"
  },
  {
    label: "Professional CCR",
    title: "Professional CCR",
    key: "profCCR",
    name: "Professional CCR",
    prop: "profCCR"
  },
  {
    label: "Professional Rejected",
    title: "Professional Rejected",
    key: "profRejected",
    name: "Professional Rejected",
    prop: "profRejected"
  },
  {
    label: "Totals",
    title: "Totals",
    key: "profTotal",
    name: "Totals",
    prop: "profTotal"
  },
  {
    label: "DME CCR",
    title: "DME CCR",
    key: "dmeCCR",
    name: "DME CCR",
    prop: "dmeCCR"
  },
  {
    label: "DME Rejected",
    title: "DME Rejected",
    key: "dmeRejected",
    name: "DME Rejected",
    prop: "dmeRejected"
  },
  {
    label: "Totals",
    title: "Totals",
    key: "dmeTotal",
    name: "Totals",
    prop: "dmeTotal"
  }
];



export const ENCOUNTER_DETAILS_SEARCH = [
  {
    label: "Claim Ref Nbr",
    title: "Claim Ref Nbr",
    key: "wtxClaimRefNbr",
    name: "Claim Ref Nbr",
    prop: "wtxClaimRefNbr"
  },
  {
    label: "Claim Rev Nbr",
    title: "Claim Rev Nbr",
    key: "wtxClaimRevNbr",
    name: "Claim Rev Nbr",
    prop: "wtxClaimRevNbr"
  },
  {
    label: "Medicare ID",
    title: "Medicare ID",
    key: "subsHicNbr",
    name: "Medicare ID",
    prop: "subsHicNbr"
  },
  {
    label: "Service/Submission Date",
    title: "Service/Submission Date",
    key: "displayDate",
    name: "Service/Submission Date",
    prop: "displayDate"
  },
  {
    label: "Status",
    title: "Status",
    key: "processStatus",
    name: "Status",
    prop: "processStatus"
  },
  {
    label: "Type",
    title: "Type",
    key: "encTypeDesc",
    name: "Type",
    prop: "encTypeDesc"
  },
  {
    label: "CR",
    title: "CR",
    key: "crClaimType",
    name: "CR",
    prop: "crClaimType"
  }
];

export const CITY_ZIP_HEADER = [
  {
    label: "City",
    title: "City",
    key: "perCity"
  },
  {
    label: "State",
    title: "State",
    key: "perState"
  },
  {
    label: "Zip5",
    title: "Zip5",
    key: "perZip5"
  },
  {
    label: "Zip4",
    title: "Zip4",
    key: "perZip4"
  },

  {
    label: "Country",
    title: "Country",
    key: "perCounty"
  }
];

export const LOG_DETAILS = [
  {
    label: "Log Time",
    title: "Log Time",
    key: "formattedLogTime",
    name: "Log Time",
    prop: "formattedLogTime"
  },
  {
    label: "Entity Name",
    title: "Entity Name",
    key: "screenBlock",
    name: "Entity Name",
    prop: "screenBlock"
  },
  {
    label: "Field Name",
    title: "Field Name",
    key: "screenField",
    name: "Field Name",
    prop: "screenField"
  },

  {
    label: "Value Before",
    title: "Value Before",
    key: "valueBefore",
    name: "Value Before",
    prop: "valueBefore"
  },

  {
    label: "Value After",
    title: "Value After",
    key: "valueAfter",
    name: "Value After",
    prop: "valueAfter"
  },
  {
    label: "User Id",
    title: "User Id",
    key: "createUserid",
    name: "User Id",
    prop: "createUserid"
  }
];

export const ENCOUNTER_DETAILS_ERROR = [
  {
    label: "Segment",
    title: "Segment",
    key: "errorSegment"
  },
  {
    label: "Code",
    title: "Code",
    key: "errorCd"
  },
  {
    label: "Source",
    title: "Source",
    key: "errorSource"
  },

  {
    label: "Group",
    title: "Group",
    key: "errorGroupDesc"
  },

  {
    label: "Line Seq#",
    title: "Line Seq#",
    key: "clmLineSeqNbr"
  },
  {
    label: "Description",
    title: "Description",
    key: "errorDescription"
  }
];

export const CLAIM_ADJUSTMENT_DETAILS = [
  {
    label: "Group Code",
    title: "Group Code",
    key: "groupCode"
  },
  {
    label: "Reason Code",
    title: "Reason Code",
    key: "reasonCode"
  },
  {
    label: "Amount",
    title: "Amount",
    key: "amount"
  },

  {
    label: "Quantity",
    title: "Quantity",
    key: "quantity"
  }
];
export const CLAIM_ATTACHMENT_DETAILS = [
  {
    label: "Report Type Code",
    title: "Report Type Code",
    key: "attachmentRptTypeCd"
  },
  {
    label: "Transmit Code",
    title: "Transmit Code",
    key: "attachmentTransmitCd"
  },
  {
    label: "Control Number",
    title: "Control Number",
    key: "attachmentCtrlNbr"
  }
];

export const CONDITION_UPDATE = [
  {
    label: "Code",
    title: "Code",
    key: "conditionCode",
    maxlength: "2",
    date: false
  },

  {
    label: "Action",
    title: "Action",
    key: ""
  }
];

export const DIAGNOSIS_PROFESSIONAL_UPDATE = [
  {
    label: "Type",
    title: "Type",
    key: "diagnosisType",
    maxlength: "3",
    date: false
  },

  {
    label: "Code",
    title: "Code",
    key: "diagnosisCode",
    maxlength: "7",
    date: false
  },
  {
    label: "Risk Diag Flag",
    title: "Risk Diag Flag",
    key: "instRiskDiagFlag",
    maxlength: "3",
    date: false
  },
  {
    label: "Action",
    title: "Action",
    key: ""
  }
];
export const DIAGNOSIS_PROFESSIONAL_ADD = [
  {
    label: "Type",
    title: "Type",
    key: "diagnosisType",
    maxlength: "3",
    date: false
  },

  {
    label: "Code",
    title: "Code",
    key: "diagnosisCode",
    maxlength: "3",
    date: false
  },

  {
    label: "Action",
    title: "Action",
    key: ""
  }
];
export const DIAGNOSIS_INSTITUTIONAL_UPDATE = [
  {
    label: "Type",
    title: "Type",
    key: "diagnosisType",
    maxlength: "3",
    date: false
  },

  {
    label: "Code",
    title: "Code",
    key: "diagnosisCode",
    maxlength: "7",
    date: false
  },
  {
    label: "POA",
    title: "POA",
    key: "presentOnAdmitInd",
    maxlength: "1",
    date: false
  },
  {
    label: "Risk Diag Flag",
    title: "Risk Diag Flag",
    key: "riskDiagFlag",
    maxlength: "3",
    disable: true
  },
  {
    label: "Action",
    title: "Action",
    key: ""
  }
];
export const DIAGNOSIS_INSTITUTIONAL_ADD = [
  {
    label: "Type",
    title: "Type",
    key: "diagnosisType",
    maxlength: "3",
    date: false
  },

  {
    label: "Code",
    title: "Code",
    key: "diagnosisCode",
    maxlength: "7",
    date: false
  },
  {
    label: "POA",
    title: "POA",
    key: "presentOnAdmitInd",
    maxlength: "1",
    date: false
  },
  {
    label: "Action",
    title: "Action",
    key: ""
  }
];
export const DIAGNOSIS_TABLE_HEADER1 = [
  {
    label: "Type",
    title: "Type",
    key: "Type"
  },

  {
    label: "Code",
    title: "Code",
    key: "Code"
  },

  {
    label: "Action",
    title: "Action",
    key: "Action"
  }
];
export const EXT_COUNTER_TABLE_HEADER = [
  {
    label: "Type",
    title: "Type",
    key: "Type"
  },

  {
    label: "Code",
    title: "Code",
    key: "Code"
  },
  {
    label: "POA",
    title: "POA",
    key: "POA"
  },
  {
    label: "Action",
    title: "Action",
    key: "Action"
  }
];
export const EXT_COUNTER_TABLE_HEADER1 = [
  {
    label: "Type",
    title: "Type",
    key: "Type"
  },

  {
    label: "Code",
    title: "Code",
    key: "Code"
  },
  {
    label: "POA",
    title: "POA",
    key: "POA"
  },
  {
    label: "Action",
    title: "Action",
    key: "Action"
  }
];

export const OCURRENCE_SPAN_UPDATE = [
  {
    label: "Code",
    title: "Code",
    key: "occurSpanCd",
    maxlength: "10",
    date: false
  },
  {
    label: "From",
    title: "From",
    key: "formattedOccurSpanToDate",
    maxlength: "11",
    date: true
  },
  {
    label: "Through",
    title: "Through",
    key: "formattedOccurSpanFromDate",
    maxlength: "11",
    date: true
  },
  {
    label: "Action",
    title: "Action",
    key: ""
  }
];

export const PROCEDURE_CODE_UPDATE = [
  {
    label: "Type",
    title: "Type",
    key: "procType",
    maxlength: "3",
    date: false
  },
  {
    label: "Code",
    title: "Code",
    key: "procCd",
    maxlength: "7",
    date: false
  },
  {
    label: "Date",
    title: "Date",
    key: "formattedProcDate",
    maxlength: "11",
    date: true
  },
  {
    label: "Action",
    title: "Action",
    key: ""
  }
];

export const OCCURENCESPAN_TABLE_HEADER = [
  {
    label: "Code",
    title: "Code",
    key: "Code"
  },

  {
    label: "From",
    title: "From",
    key: "From"
  },
  {
    label: "Through",
    title: "Through",
    key: "Through"
  },

  {
    label: "Action",
    title: "Action",
    key: "Action"
  }
];
export const OCCURENCESPAN_TABLE_HEADER1 = [
  {
    label: "Type",
    title: "Type",
    key: "Type"
  },

  {
    label: "From (MM/DD/YYYY)",
    title: "From",
    key: "From"
  },
  {
    label: "Through (MM/DD/YYYY)",
    title: "Through",
    key: "Through"
  },
  {
    label: "Action",
    title: "Action",
    key: "Action"
  }
];
export const VALUE_TABLE_HEADER1 = [
  {
    label: "Type",
    title: "Type",
    key: "Type"
  },

  {
    label: "Amount",
    title: "Amount",
    key: "Amount"
  },

  {
    label: "Action",
    title: "Action",
    key: "Action"
  }
];
export const OCCURRENCE_UPDATE = [
  {
    label: "Code",
    title: "Code",
    key: "occurenceCd",
    maxlength: "7",
    date: false
  },

  {
    label: "Date",
    title: "Date",
    key: "formattedOccurenceDate",
    maxlength: "8",
    date: true
  },

  {
    label: "Action",
    title: "Action",
    key: ""
  }
];
export const OCCURENCE_TABLE_HEADER1 = [
  {
    label: "Type",
    title: "Type",
    key: "Type"
  },

  {
    label: "Date(MM/DD/YYYY)",
    title: "Date",
    key: "Date"
  },

  {
    label: "Action",
    title: "Action",
    key: "Action"
  }
];
export const TREATMENT_TABLE_UPDATE = [
  {
    label: "Code",
    title: "Code",
    key: "treatmentCd",
    maxlength: "30"
  },

  {
    label: "Action",
    title: "Action",
    key: ""
  }
];
export const TREATMENT_TABLE_HEADER1 = [
  {
    label: "Code",
    title: "Code",
    key: "Code"
  },

  {
    label: "Action",
    title: "Action",
    key: "Action"
  }
];
export const CLAIM_PROVIDER = [
  {
    label: "Provider Type",
    title: "Provider Type",
    key: "provTypeDes"
  },
  {
    label: "Entity Type",
    title: "Entity Type",
    key: "provEntityTypeDisp"
  },
  {
    label: "Provider Name",
    title: "Provider Name",
    key: "providerName"
  },
  {
    label: "Action",
    title: "Action",
    key: "action"
  }
];
export const CLAIM_SUSCRIBER = [
  {
    label: "Insured Name",
    title: "Insured Name",
    key: "insuredFullName"
  },
  {
    label: "Subs HIC Nbr",
    title: "Subs HIC Nbr",
    key: "othSubsHicNbr"
  },
  {
    label: "Subs Medicare ID",
    title: "Subs Medicare ID",
    key: "othSubsMbi"
  },
  {
    label: "Subs Member ID",
    title: "Subs Member ID",
    key: "othSubsMemberId"
  }
];

export const CLAIM_LINE_PROFESSIONAL = [
  {
    label: "Procedure Code",
    title: "Procedure Code",
    key: "liProcCd"
  },
  {
    label: "Begin Date",
    title: "Begin Date",
    key: "formattedServiceBeginDt"
  },
  {
    label: "End Date",
    title: "End Date",
    key: "formattedServiceEndDt"
  },
  {
    label: "Claim Line Number",
    title: "Claim Line Number",
    key: "claimLineSeqNbr"
  }
];

export const CLAIM_LINE_INSTITUTIONAL = [
  {
    label: "Revenue Code",
    title: "Revenue Code",
    key: "instLiRevenueCd"
  },
  {
    label: "Procedure Code",
    title: "Procedure Code",
    key: "liProcCd"
  },
  {
    label: "Begin Date",
    title: "Begin Date",
    key: "formattedInstLiBeginDt"
  },
  {
    label: "End Date",
    title: "End Date",
    key: "formattedInstLiEndDt"
  },
  {
    label: "Claim Line Number",
    title: "Claim Line Number",
    key: "claimLineSeqNbr"
  }
];

export const CLAIM_LINE_ATTACHMENT = [
  {
    label: "Report Type Code",
    title: "Report Type Code",
    key: "attachmentRptTypeCd"
  },
  {
    label: "Transmit Code",
    title: "Transmit Code",
    key: "attachmentTransmitCd"
  },
  {
    label: "Control Number",
    title: "Control Number",
    key: "attachmentCtrlNbr"
  }
];

export const CLAIM_LINE_REFERRAL = [
  {
    label: "Prior Auth Or Refer Nbr",
    title: "Prior Auth Or Refer Nbr",
    key: "priorauthOrReferNbr"
  },
  {
    label: "Other Payer Prim Auth ID",
    title: "Other Payer Prim Auth ID",
    key: "othPayrPrimRefId"
  },
  {
    label: "Referral Nbr",
    title: "Referral Nbr",
    key: "liReferralNbr"
  },
  {
    label: "Other Payer Prim Refer ID",
    title: "Other Payer Prim Refer ID",
    key: "othPayrPrimRefId"
  }
];

export const CLAIM_LINE_DOC = [
  {
    label: "Doc Qual",
    title: "Doc Qual",
    key: "docQual"
  },
  {
    label: "Doc ID",
    title: "Doc ID",
    key: "othPayrPrimRefId"
  },
  {
    label: "Question Num Or Letter",
    title: "Question Num Or Letter",
    key: "docId"
  },
  {
    label: "Resp Qual",
    title: "Resp Qual",
    key: "questionResponseQual"
  },
  {
    label: "Question Response",
    title: "Question Response",
    key: "questionResponse"
  },
  {
    label: "Resp Date",
    title: "Resp Date",
    key: "questionResponseDt"
  },
  {
    label: "RespPct",
    title: "RespPct",
    key: "questionResponsePct"
  }
];

export const CLAIM_PROVIDER_HEADER = [
  {
    label: "Provider Type",
    title: "Provider Type",
    key: "provType"
  },
  {
    label: "Provider License Number",
    title: "Provider License Number",
    key: "othPayrProvLicNbr"
  }
];

export const CLAIM_ADJUDICATION = [
  {
    label: "Procedure Code",
    title: "Procedure Code",
    key: "clmliAdjudProcCd"
  },
  {
    label: "Mod1",
    title: "Mod1",
    key: "clmliAdjudProcMod1"
  },
  {
    label: "Mod2",
    title: "Mod2",
    key: "clmliAdjudProcMod2"
  },
  {
    label: "Mod3",
    title: "Mod3",
    key: "clmliAdjudProcMod3"
  },
  {
    label: "Mod4",
    title: "Mod4",
    key: "clmliAdjudProcMod4"
  },
  {
    label: "Revenue Code",
    title: "Revenue Code",
    key: "clmliAdjudRevenueCd"
  },
  {
    label: "Paid Amt",
    title: "Paid Amt",
    key: "formattedClmliPaidAmt"
  }
];

export const CLAIM_LINE_PROVIDER = [
  {
    label: "Provider Type",
    title: "Provider Type",
    key: "provType"
  },
  {
    label: "Entity Type",
    title: "Entity Type",
    key: "provEntityType"
  },
  {
    label: "Provider Name",
    title: "Provider Name",
    key: "provFirstName"
  }
];

export const MONTHLY_FILE = [
  {
    label: "Number Of Files",
    title: "Number Of Files",
    key: "files"
  },
  {
    label: "Encounters Received",
    title: "Encounters Received",
    key: "encInFile"
  },
  {
    label: "WiproREJ",
    title: "WiproREJ",
    key: "wiproRej"
  },
  {
    label: "Encounters Submitted",
    title: "Encounters Submitted",
    key: "wiproResub"
  },
  {
    label: "999REJ",
    title: "999REJ",
    key: "cms999Rej"
  },
  {
    label: "999ACC",
    title: "999ACC",
    key: "cms999Acc"
  },
  {
    label: "277CA REJ",
    title: "277CA REJ",
    key: "cms277CaRej"
  },
  {
    label: "277CA ACC",
    title: "277CA ACC",
    key: "cms277CaAcc"
  },
  {
    label: "MAO002REJ",
    title: "MAO002REJ",
    key: "cmsMao002Rej"
  },
  {
    label: "MAO002ACC",
    title: "MAO002ACC",
    key: "cmsMao002Acc"
  }
];

export const ACCEPTED_COUNT = [
  {
    label: "File ID",
    title: "File ID",
    key: "icn"
  },
  {
    label: "Customer File ID",
    title: "Customer File ID",
    key: "custFileId"
  },
  {
    label: "EN/CR",
    title: "EN/CR",
    key: "claimType"
  },
  {
    label: "Received",
    title: "Received",
    key: "encInFile"
  },
  {
    label: "Submitted",
    title: "Submitted",
    key: "encSenttoCMS"
  },
  {
    label: "999ACC",
    title: "999ACC",
    key: "cms999ACC"
  },
  {
    label: "277ACC",
    title: "277ACC",
    key: "cms277CAACC"
  },
  {
    label: "MAO002ACC",
    title: "MAO002ACC",
    key: "cmsMAO002ACC"
  }
];

export const REJECTED_COUNT = [
  {
    label: "File ID",
    title: "File ID",
    key: "icn"
  },
  {
    label: "Customer File ID",
    title: "Customer File ID",
    key: "custFileId"
  },
  {
    label: "EN/CR",
    title: "EN/CR",
    key: "claimType"
  },
  {
    label: "Received",
    title: "Received",
    key: "encInFile"
  },
  {
    label: "WiproREJ",
    title: "WiproREJ",
    key: "wiproRej"
  },
  {
    label: "999REJ",
    title: "999REJ",
    key: "cms999Rej"
  },
  {
    label: "277REJ",
    title: "277REJ",
    key: "cms277CARej"
  },
  {
    label: "MAO002REJ",
    title: "MAO002REJ",
    key: "cmsMAO002Rej"
  }
];

export const ERROR_CODE = [
  {
    label: "Date",
    title: "Date",
    key: "formattedDateYrmo",
    name: "Date",
    prop: "formattedDateYrmo"
  },
  {
    label: "Source",
    title: "Source",
    key: "errorSource",
    name: "Source",
    prop: "errorSource"
  },
  {
    label: "Group",
    title: "Group",
    key: "errorGroupDesc",
    name: "Group",
    prop: "errorGroupDesc"
  },
  {
    label: "Err Code",
    title: "Err Code",
    key: "errorCd",
    name: "Err Code",
    prop: "errorCd"
  },
  {
    label: "Error Description",
    title: "Error Description",
    key: "errorDescription",
    name: "Error Description",
    prop: "errorDescription"
  },
  {
    label: "Err Tot",
    title: "Err Tot",
    key: "errorCnt",
    name: "Err Tot",
    prop: "errorCnt"
  },
  {
    label: "Clm Tot",
    title: "Clm Tot",
    key: "clmCnt",
    name: "Clm Tot",
    prop: "clmCnt"
  },
  {
    label: "Type",
    title: "Type",
    key: "encTypeDesc",
    name: "Type",
    prop: "encTypeDesc"
  }
];

export const OCURRENCE_SPAN_ADD = [
  {
    label: "Code",
    title: "Code",
    key: "Code"
  },

  {
    label: "From (MM/DD/YYYY)",
    title: "From",
    key: "From"
  },
  {
    label: "Through (MM/DD/YYYY)",
    title: "Through",
    key: "Through"
  },
  {
    label: "Action",
    title: "Action",
    key: "Action"
  }
];
export const VALUE_CODE_UPDATE = [
  {
    label: "Code",
    title: "Code",
    key: "valueCd",
    maxlength: "2",
    date: false
  },

  {
    label: "Amount",
    title: "Amount",
    key: "valueCdAmt",
    maxlength: "10",
    date: false
  },

  {
    label: "Action",
    title: "Action",
    key: ""
  }
];
export const EXT_CAUSE_INJURY_UPDATE = [
  {
    label: "Type",
    title: "Type",
    key: "extcauseofinjuryType",
    maxlength: "3",
    date: false
  },

  {
    label: "Code",
    title: "Code",
    key: "extcauseofinjuryCd",
    maxlength: "30",
    date: false
  },

  {
    label: "POA",
    title: "POA",
    key: "presentOnAdmitInd",
    maxlength: "1",
    date: false
  },

  {
    label: "Action",
    title: "Action",
    key: ""
  }
];

export const ClAIM_LI_ADJUD_ADJUS_UPDATE = [
  {
    label: "GroupCode",
    title: "GroupCode",
    key: "clmliAdjustGrpCd",
    maxlength: "2",
    date: false
  },

  {
    label: "ReasonCode",
    title: "ReasonCode",
    key: "clmliAdjustReasonCd",
    maxlength: "5",
    date: false
  },

  {
    label: "Amount",
    title: "Amount",
    key: "formattedClmAdjustAmt",
    maxlength: "10",
    date: false
  },
  {
    label: "Quantity",
    title: "Quantity",
    key: "clmliAdjustQty",
    maxlength: "8",
    date: false
  },
  {
    label: "Action",
    title: "Action",
    key: ""
  }
];

export const CLAIM_NOTES = [
  {
    label: "Reference Code",
    title: "Reference Code",
    key: "claimRefCd"
  },
  {
    label: "Note",
    title: "Note",
    key: "claimNote"
  }
];

export const FILE_TRACKING = [
  {
    label: "CUST_FILE_NAME",
    title: "CUST_FILE_NAME",
    key: "custFileName"
  },

  {
    label: "FILE_ID",
    title: "FILE_ID",
    key: "fileId"
  },

  {
    label: "CUST_FILE_ID",
    title: "CUST_FILE_ID",
    key: "custFileId"
  },
  {
    label: "C837_FILE_NAME",
    title: "C837_FILE_NAME",
    key: "cms837FileName"
  },
  {
    label: "TA1_FILE_NAME",
    title: "TA1_FILE_NAME",
    key: "ta1FileName"
  },
  {
    label: "C999_FILE_NAME",
    title: "C999_FILE_NAME",
    key: "cms999FileName"
  },
  {
    label: "C277_FILE_NAME",
    title: "C277_FILE_NAME",
    key: "cms277FileName"
  },
  {
    label: "MAO1_FILE_NAME",
    title: "MAO1_FILE_NAME",
    key: "cmsMAO1FileName"
  },
  {
    label: "MAO2_FILE_NAME",
    title: "MAO2_FILE_NAME",
    key: "cmsMAO2FileName"
  },
  {
    label: "INVALID_RSP_FILE_NAME",
    title: "INVALID_RSP_FILE_NAME",
    key: "invalRspFileName"
  }
];

export const FILE_DASHBOARD_EXPORT = [
  {
    label: "CUST_FILE_NAME",
    title: "CUST_FILE_NAME",
    key: "custFileName",
    name: "CUST_FILE_NAME",
    prop: "custFileName"
  },
  {
    label: "Recieved Cnt",
    title: "Recieved Cnt",
    key: "encInFile",
    name: "Recieved Cnt",
    prop: "encInFile"
  },
  {
    label: "Recieved Date",
    title: "Recieved Date",
    key: "submissionDate",
    name: "Recieved Date",
    prop: "submissionDate"
  },

  {
    label: "Wipro REJ",
    title: "Wipro REJ",
    key: "wiproRej",
    name: "Wipro REJ",
    prop: "wiproRej"
  },

  {
    label: "File Id",
    title: "File Id",
    key: "icn",
    name: "File Id",
    prop: "icn"
  },
  {
    label: "Cust File Id",
    title: "Cust File Id",
    key: "custFileId",
    name: "Cust File Id",
    prop: "custFileId"
  },
  {
    label: "837 File Name",
    title: "837 File Name",
    key: "cms837Name",
    name: "837 File Name",
    prop: "cms837Name"
  },
  {
    label: "Submitted",
    title: "Submitted",
    key: "encSenttoCMS",
    name: "Submitted",
    prop: "encSenttoCMS"
  },
  {
    label: "999 RSP FILE NAME",
    title: "999 RSP FILE NAME",
    key: "cms999Name",
    name: "999 RSP FILE NAME",
    prop: "cms999Name"
  },
  {
    label: "999 ACC",
    title: "999 ACC",
    key: "cms999ACC",
    name: "999 ACC",
    prop: "cms999ACC"
  },
  {
    label: "999 REJ",
    title: "999 REJ",
    key: "cms999Rej",
    name: "999 REJ",
    prop: "cms999Rej"
  },
  {
    label: "277 RSP FILE NAME",
    title: "277 RSP FILE NAME",
    key: "cms277Name",
    name: "277 RSP FILE NAME",
    prop: "cms277Name"
  },
  {
    label: "277 ACC",
    title: "277 ACC",
    key: "cms277CAACC",
    name: "277 ACC",
    prop: "cms277CAACC"
  },
  {
    label: "277 REJ",
    title: "277 REJ",
    key: "cms277CARej",
    name: "277 REJ",
    prop: "cms277CARej"
  },
  {
    label: "MAO002 FILE NAME",
    title: "MAO002 FILE NAME",
    key: "cmsMAOName",
    name: "MAO002 FILE NAME",
    prop: "cmsMAOName"
  },
  {
    label: "MAO002 ACC",
    title: "MAO002 ACC",
    key: "cmsMAO002ACC",
    name: "MAO002 ACC",
    prop: "cmsMAO002ACC"
  },
  {
    label: "MAO002 REJ",
    title: "MAO002 REJ",
    key: "cmsMAO002Rej",
    name: "MAO002 REJ",
    prop: "cmsMAO002Rej"
  }
];
