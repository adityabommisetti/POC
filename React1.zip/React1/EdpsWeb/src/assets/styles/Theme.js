export const Styles = theme => ({
  input: {
    display: "flex",
    padding: 0,
    marginTop: "1px"
  },

  paper: {
    position: "absolute",
    zIndex: 1,
    marginTop: theme.spacing.unit,
    //width: "180px",
    left: 0,
    right: 0
  },
  content: {
    overflow: "auto",
  },
  childContent: {
    width: "48%",
    padding: "1em",
    background: "white",
  },
  left: {
    float: "left",
  },
  right: {
    float: "right",
  },
  tableHeadings: {
    color: "rgba(39, 108, 155, 1)",
    textAlign: "center",
    fontSize: "17px",
  },
  uncMnthsTable: {
    width: "51%",
    margin: "left",
    padding: "1em",
    background: "white",
  },
  exportDemo: {
    paddingLeft: "5%"
  },
  exportDisplay: {
    display: "contents"
  },
  csvIcon: {
    fontSize: "24px",
    float: "right",
    color: "#3a94d0",
    cursor: "pointer",
    padding: "12px"
  },

  pdfIcon: {
    fontSize: "24px",
    float: "right",
    color: "red",
    cursor: "pointer",
    padding: "12px"
  },
  textIcon: {
    fontSize: "24px",
    float: "right",
    color: "black",
    cursor: "pointer",
    padding: "12px"
  },
  excelIcon: {
    fontSize: "24px",
    float: "right",
    color: "green",
    cursor: "pointer",
    padding: "12px"
  },

  preset: {
    padding: "1px 0 7px !important"
  },
  rootSubtabs: {
    flexGrow: 1,
    width: "100%",
    backgroundColor: theme.palette.background.paper,
    paddingTop: "10px"
  },
  expansionDetails: {
    padding: "0 !important"
  },
  expansionSummary: {
    minHeight: "0px !important",
    height: "25px"
  },
  typography1: {
    verticalAlign: "center",
    // marginTop: "20px",
    paddingLeft: "65px",
    marginBottom: "20px",
    marginTop: "32px",
    color: "rgba(39, 108, 155, 1)",
    fontSize: "15px",
    width: "221px",
    fontFamily: "Arial"
  },

  checkboxmember: {
    fontSize: '16px',
    color: 'rgba(39, 108, 155, 1)'
  },

  heading: {
    marginTop: "20px",
    paddingLeft: "50px"
  },

  addBtnContainer: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    marginTop: "10px"
  },
  questionMark: {
    fontSize: "20px",
    cursor: "pointer",
    color: "cadetblue"
  },



  mobileWidth: {
    width: '70% !important',
    padding: '0px !important',
    maxHeight: '75vh !important',
    overflowY: 'auto !important',

    [theme.breakpoints.down('xs')]: {
      marginTop: '70px !important',
      width: '150% !important',
      maxHeight: '100vh !important',
      overflowY: 'auto !important',
      shrink: 'true !important'
    }
  },

  buttonContainer12: {

    position: "relative",
    // display: 'inline-block',
    verticalAlign: "middle",
    //  paddingLeft: '60%',
    textAlign: "right",
    paddingTop: '18px',
    paddingLeft: '383px'
  },

  radioSpan: {
    padding: '0 !important',
  },

  valueContainer: {
    display: "flex",
    flexWrap: "wrap",
    flex: 1,
    alignItems: "left",
    overflow: "hidden",
    fontSize: "0.95em",
    padding: ".2em .5em",
    backgroundColor: '#FFFFFF',
    borderWidth: "0",
    border: "1px solid #999 !important",
    borderRight: "0px !important",

    // minWidth: "12em",
    maxHeight: "1.9em",
    borderRadius: "5px 0px 0px 5px",
    //  boxShadow: "0px 1px #999"
  },

  valueContainerEnabled: {
    display: "flex",
    flexWrap: "wrap",
    flex: 1,
    alignItems: "left",
    overflow: "hidden",
    fontSize: "0.95em",
    padding: ".2em .5em",
    backgroundColor: '#EBEBE4',
    borderWidth: "0",
    border: "1px solid #999 !important",
    borderRight: "0px !important",

    // minWidth: "12em",
    maxHeight: "1.9em",
    borderRadius: "5px 0px 0px 5px",
    //  boxShadow: "0px 1px #999"
  },
  //userDoc 
  containeruserDoc: {
    backgroundColor: "rgba(236, 236, 236)",
    width: "100%",
    textAlign: "left",
    padding: "20px",
    borderRadius: "10px"

  },
  textuserDoc: {
    textDecoration: "underLine",
    color: "rgb(5, 54, 116)"
  },
  downloadIcon: {
    color: "black",
    cursor: "pointer",
    padding: "12px"
  },


  label: {
    fontSize: "1rem",
    fontWeight: "700",
    minWidth: "132%",
    color: "#053674 !important",
    marginBottom: "12px"
  },

  labelupdated: {
    fontSize: "1rem",
    fontWeight: "700",
    minWidth: "132%",
    color: "red !important",
    marginBottom: "12px"
  },



  legend: {
    color: '#053674',
    fontWeight: '600',
    fontSize: '0.8rem',
    marginBottom: '0px !important'
  },

  legendpassword: {
    color: '#053674',
    fontWeight: '600',
    //  fontSize: '0.8rem',
    marginBottom: '0px !important',
    width: "280px !important",
    fontSize: '20px'
  },

  legend1password: {
    color: '#053674',
    fontWeight: '600',
    // fontSize: '10px !important',
    marginBottom: '0px !important',
    width: "280px !important",
    fontSize: '20px'
  },
  passwordrules: {
    width: "48%",
    display: "-webkit-inline-box"
  },
  containerStyle: {
    display: "flex"
  },
  containersubstyle: {
    marginLeft: '403px'
  },

  containersubstyle1: {
    marginLeft: '384px'
  },

  dropdownSelect: {
    width: "180px",
    height: "30px",
    //  marginTop: "5px",
    fontSize: "1rem",
    marginBottom: "20px",
    padding: "0px",
    marginTop: "-12px",
    marginLeft: '426px'
  },
  subsContainerstyle: {
    marginLeft: '587px',
  },

  /** Demographic  */

  textFieldSelect1: {
    marginLeft: '50px',
    marginRight: '50px',
    width: '180px',
    height: '30px',
    marginTop: '15px',
    fontSize: '1rem',
    marginBottom: '10px',
    padding: '0px',
  },

  buttonContainerupdate: {

    position: "relative",
    // display: 'inline-block',
    verticalAlign: "middle",
    //  paddingLeft: '60%',
    textAlign: "right",
    // float: 'right',
    paddingTop: "10px",


  },

  emergency: {

    color: 'rgba(39, 108, 155, 1)',
    paddingTop: '30px',
    paddingLeft: '40px'
  },

  attestation: {
    color: 'rgba(39, 108, 155, 1)',
    paddingTop: '30px',
    paddingLeft: '20px'
  },

  attestation1: {
    color: 'rgba(39, 108, 155, 1)',
    paddingTop: '30px',
    paddingLeft: '3px'
  },

  label1: {
    fontSize: '1rem',
    fontWeight: '450',
    color: 'rgba(39, 108, 155, 1) !important'
  },

  labelSearchFields: {
    fontSize: "14.5px",
    fontWeight: "950"
  },

  readOnlyLable: {
    padding: "14px",
    marginTop: "50px",
    fontSize: "12px",
    fontWeight: "500",
    wordBreak: "break-all",
    color: "rgb(39, 108, 155)",
    [theme.breakpoints.down("xs")]: {
      display: "table-row-group"
    }
  },

  readOnlyLableDisabled: {
    paddingLeft: '10px',
    marginBottom: '0 !important',
    fontSize: '12px',
    fontWeight: '500',
    wordBreak: 'break-all',
    alignText: 'left',
    width: '300px',
    color: "rgba(39, 108, 155, 1)!important",
    [theme.breakpoints.down('xs')]: {
      display: 'table-row-group'
    }

  },
  applicationTableHeading: {
    backgroundColor: '#053674',
    padding: '.5em 1em',
    fontSize: '1em',
    marginTop: '10px',
    marginBottom: '4px',
    color: '#fff'
  },


  search: {
    fontSize: "24px",
    paddingLeft: "20px",
    paddingTop: "20px"
  },

  memberSectionHeading: {
    fontWeight: '500',
    fontSize: '1rem',
    color: '#0d5196',
    lineHeight: '2',
    padding: '0 !important'

  },
  sectionHeading: {
    fontWeight: '500',
    fontSize: '1rem',
    color: '#0d5196',
    lineHeight: '2',
    paddingLeft: '5px',

  },
  formLabel: {
    color: '#053674',
    fontWeight: '600',
    fontSize: '0.8rem'
  },
  textArealLabel: {
    color: '#053674',
    fontWeight: '600',
    fontSize: '0.7rem',
    marginTop: "6px"
  },
  searchresults: {
    color: 'rgba(39, 108, 155, 1)',
    textAlign: 'left',
    fontWeight: '500'
  },
  popUpIcons: {
    fontSize: "30px",
    paddingLeft: "20px",
    paddingRight: '20px',
    paddingTop: "25px",
    cursor: 'pointer'
  },
  buttonContainer13: {

    position: "relative",
    // display: 'inline-block',
    verticalAlign: "middle",
    //  paddingLeft: '60%',
    textAlign: "right",
    paddingTop: '18px',
    paddingLeft: '24px'


  },
  securityFormLabel: {
    fontSize: '12px !important',
    paddingLeft: '5px'
  },
  expansionSummaryHeading: {
    paddingLeft: "5px !important"
  },
  summary: {
    color: 'rgba(39, 108, 155, 1)',
    paddingTop: '30px',
    textAlign: 'center'
  },
  expansionPannel: {
    margin: '0 !important'
  },
  comment: {
    textAlign: 'center !important',
  },
  radioButton: {
    fontSize: '16px !important',
    paddingLeft: '5px'
  },
  radioFont: {
    padding: '0 !important'
  },
  paperCard: {
    width: "20%",
    height: "250px",
    textAlign: "center",
    margin: "auto",
    overflow: "auto",
    borderWidth: '1px',
    borderStyle: 'solid',
    borderColor: 'rgba(0, 0, 0, 0.5)',


    [theme.breakpoints.down('sm')]: {
      width: "100%",
    }
  },
  searchCheckbox: {
    width: 'auto',
    height: '36px',
    fontSize: '12px',
    color: 'rgba(0, 0, 0, 0.38)',
    display: 'inline-block',
    verticalAlign: 'middle',
  },

  checkboxTextSize: {
    marginTop: "15px",
    fontSize: "15px",
    fontWeight: "450",
    paddingRight: "24px",
    color: "rgba(39, 108, 155, 1) !important"
  },

  checkbox: {
    marginLeft: '25px',
    width: '180px',
    height: '36px',
    marginTop: '25px',
    fontSize: '12px',
    color: 'rgba(0, 0, 0, 0.38)',
    display: 'inline-block',
    verticalAlign: 'bottom',
  },
  securityContainer: {
    display: 'flex',
    flexWrap: 'wrap',
    width: 'fit-content',
    margin: 'auto',
    textAlign: 'center',


  },
  pageFooter: {
    padding: "10px 30px"
  },

  readOnly: {
    fontSize: "12px",
    fontWeight: "500"
  },
  historyDiv: {
    border: "1px solid black"
  },

  passwordbuttonContainer: {
    marginRight: '500px !important',
    position: "relative",
    // display: 'inline-block',
    verticalAlign: "middle",
    //  paddingLeft: '60%',
    textAlign: "right"
    // float: 'right'
  },

  buttonContainer: {
    position: "relative",
    // display: 'inline-block',
    verticalAlign: "middle",
    //  paddingLeft: '60%',
    textAlign: "right",

    // float: 'right'
  },

  buttonContainerapp: {
    position: "relative",
    verticalAlign: "middle",
    textAlign: "right",
    paddingRight: '200px'
  },
  paperservices: {
    marginLeft: '100px',
    width: "40%",
    height: "250px",
    textAlign: "center",
    display: 'inline-block',
    overflow: "auto",
    borderWidth: '1px',
    borderStyle: 'solid',
    borderColor: 'rgba(0, 0, 0, 0.5)',
  },

  buttonContainermiddle: {
    position: "relative",
    // display: 'inline-block',
    verticalAlign: "middle",
    //  paddingLeft: '60%',
    textAlign: "right",
    marginRight: '40%'
    // float: 'right'
  },

  buttonContainerupload: {
    position: "relative",
    // display: 'inline-block',
    verticalAlign: "middle",
    //  paddingLeft: '60%',
    textAlign: "middle"
    // float: 'right'
  },

  buttonContainer1: {
    position: "relative",
    // display: 'inline-block',
    verticalAlign: "middle",
    //  paddingLeft: '60%',
    textAlign: "right",
    // float: 'right',
    paddingTop: "10px",

  },

  buttonContainerelection: {
    position: "relative",
    // display: 'inline-block',
    verticalAlign: "middle",
    //  paddingLeft: '60%',
    textAlign: "left",
    // float: 'right',
    paddingBottom: "10px",

  },

  buttonContainerroles: {
    position: "relative",
    // display: 'inline-block',
    verticalAlign: "middle",
    //  paddingLeft: '60%',
    textAlign: "right",
    paddingTop: "17px",
    // float: 'right'
  },

  textFont: {
    fontSize: "12px",
    fontWeight: "500",
    color: "#2e333a"
  },
  /*Till here*/
  textField: {
    marginLeft: "35px",
    height: "36px",
    marginTop: "15px",
    fontSize: "12px"
  },
  hide: {
    display: "none"
  },
  textFieldSelect: {
    width: "185px",
    height: "30px",
    marginTop: "5px",
    fontSize: "1rem",
    marginBottom: "20px",
    padding: "0px"
  },
  textFieldSearch: {
    width: "205px",
    height: "30px",
    marginTop: "5px",
    fontSize: "1rem",
    marginBottom: "20px",
    padding: "0px"
  },
  menu: {
    width: "200"
  },
  button: {
    margin: theme.spacing.unit,
    [theme.breakpoints.down("sm")]: {
      fontSize: "8px",
      width: "80px",
      marginTop: "-5px"
    }
  },
  applicationSectionHeading: {
    backgroundColor: '#053674',
    padding: '.5em 1em',
    fontSize: '1em',
    marginTop: '20px',
    marginBottom: '20px',
    color: '#fff'
  },
  confirmDialogButton: {
    margin: theme.spacing.unit,
    backgroundColor: "#2e88e2",
    color: "white",
    "&:hover": {
      backgroundColor: "#2e88e2"
    }
  },
  confirmDialog: {
    border: "1px none black",
    borderRadius: "8px",
    backgroundColor: "white",
    padding: "30px",
    boxShadow: "0 10px 6px -6px #777",
    [theme.breakpoints.down("md")]: {
      padding: "15px"
    }
  },
  encounterCheckBox: {
    fontSize: "20px",
    color: "rgba(39, 108, 155, 1)"
  },
  card: {
    position: "relative",
    margin: "auto",
    width: "100%",
    backgroundColor: "transparent"
  },
  root: {
    ...theme.mixins.gutters(),
    paddingTop: theme.spacing.unit * 2,
    paddingBottom: theme.spacing.unit * 2,
    marginTop: theme.spacing.unit * 3,
    overflowX: "auto",
    display: "flex",
    width: "fit-content",
    alignSelf: "center",
    marginLeft: "auto",
    marginRight: "auto"
  },

  container: {
    display: "flex",
    flexWrap: "wrap",
    width: "fit-content",
    marginTop: '10px',
    marginBottom: '10px',
    marginRight: "15px"
  },
  box: {
    width: "fit-content",
    display: "flex",
    justifyContent: "center",
    alignItems: "center" /* for single line flex container */,
    alignContent: "center" /* for multi-line flex container */
  },
  typography: { 
    textDecoration: "underline",
     margin: "20px" 
    },
  validation: {
    lineHeight: 2.5
  },
  validationMessage: {
    color: "red",
    fontSize: "12px",
    marginLeft: "25px",
    width: "180px"
  },
  commentsValidationMessage: {
    color: "red",
    fontSize: "12px",
    marginLeft: "95px",
    width: "180px"
  },
  validationMessageSelect: {
    color: "red",
    fontSize: "12px",
    marginLeft: "25px",
    width: "180px",
    paddingTop: "4px"
  },
  group: {
    flexDirection: "row !important",
  },
  formControl: {
    width: 'auto',
    height: '36px',
    fontSize: '12px',
    marginTop: '15px',
    marginRight: '99px',
    fontWeight: '500',
    // marginBottom: '30px'
  },
  applheading: {
    width: "413px",
    height: "20px",
    marginTop: "15px",
    marginBottom: "20px",
    fontSize: "15px",
    padding: "0px"
  },
  heading1: {
    color: "red",
    fontSize: "16px",
    fontWeight: "500",
    marginTop: "24px"
  },
  checkboxControl: {
    padding: "4px",
    fontSize: '16px !important'
  },
  checkBoxStyle: {
    fontSize: "23px"
  },
  formControlLabel: {
    fontSize: '0.6rem',
    '& label': { fontSize: '0.6rem' }
  },
  encounterPanel: {
    marginLeft: '-15px'
  },
  encounterTwinPanel: {
    marginLeft: '70px'
  }
});
