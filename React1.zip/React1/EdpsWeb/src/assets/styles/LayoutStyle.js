import sidebarbackground from "../images/navbar-left.png";

const drawerWidth = 240

const sideBarWidth = 64;

const styles = theme => ({
  root: {
    display: "flex"
  },

  icons: {
    fontSize: "22px",
    height: "1em",
    color: "#053674",
    fontStyle: "normal",
    "&:hover": {
      color: "white"
    },
    "&:active": {
      color: "green"
    }
  },
  avatar: {
    width: "30px",
    height: "30px"
  },
  paper: {
    height: "240px",
    overflowX: 'hidden ',
    overflowY: 'auto',
    width: '30em'

  },
  appBar: {
    //background:'linear-gradient(to bottom, #7abcff 0%,#60abf8 44%,#4096ee 100%)',
    // backgroundImage: "url(" + drawerImage + ")",
    backgroundColor: "#053674",
    color: "#ffffff",
    zIndex: '800 !important',
    width: `calc(100% - ${sideBarWidth}px)`,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen
    }),
    [theme.breakpoints.up("xs")]: {
      width: `calc(100% - ${sideBarWidth}px)`
    },
    [theme.breakpoints.down("xs")]: {
      width: "100%"
    }
  },
  appBarShift: {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen
    }),

    [theme.breakpoints.down("xs")]: {
      width: "100%"
    }
  },
  hide: {
    display: "none"
  },

  drawer: {
    zIndex: '800 !important',
    width: drawerWidth,
    flexShrink: 0,
    whiteSpace: "nowrap"
  },

  drawerOpenSubMenu: {
    overflowY: "auto",
    backgroundImage: "url(" + sidebarbackground + ") ",
    overflowX: "hidden",
    maxHeight: "calc(100% - 220px)!important"
  },

  drawerOpen: {
    width: drawerWidth,
    overflowY: "auto",
    zIndex: '800 !important',
    backgroundImage: "url(" + sidebarbackground + ") ",

    overflowX: "hidden",
    //background:'-webkit-linear-gradient(top, #ffffff 0%,#f1f1f1 46%,#e1e1e1 80%,#f6f6f6 100%)',
    //background:'linear-gradient(to bottom, #b4d5e2 0%,#23538a 100%)',
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.smooth,
      duration: "0.4s"
    })
  },
  drawerClose: {
    zIndex: '800 !important',
    backgroundImage: "url(" + sidebarbackground + ")",

    // background:'linear-gradient(to bottom, #b4d5e2 0%,#23538a 100%)',
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.smooth,
      duration: "0.25s"
    }),
    overflowX: "hidden",
    width: theme.spacing.unit * 7 + 1,
    [theme.breakpoints.up("sm")]: {
      width: theme.spacing.unit * 8 + 1
    }
  },

  gutters: {
    paddingLeft: "5px",
    paddingRight: "5px"
  },

  sectionDesktop: {
    [theme.breakpoints.down("md")]: {
      display: "none"
    },
    [theme.breakpoints.up("sm")]: {
      display: "inline-block"
    }
  },

  sectionMobile: {
    display: "block",
    paddingLeft: "5px",
    [theme.breakpoints.up("sm")]: {
      display: "none"
    }
  },

  selected: {
    //background:'-webkit-gradient(linear, left top, left bottom, color-stop(0%, #73b1e6), color-stop(41%, #589cd6), color-stop(47%, #589cd6), color-stop(100%, #648fb3))',
    background:
      "-webkit-linear-gradient( top left, rgb(201, 211, 222) 0%, rgb(155, 183, 189) 37%, rgb(128, 165, 183) 45%, rgba(164, 186, 191, 0.8) 50% )"
    //backgroundImage:'-webkit-linear-gradient( top left, rgb(39, 113, 189) 0%, rgb(40, 139, 197) 37%, rgb(44, 145, 193) 45%, rgba(18, 156, 187, 0.8) 50% )'
  },
  // items:{
  //   "&:hover": {
  //      background: '#c1c9d0',
  //      boxShadow:`
  //               1px 1px #53a7ea,
  //               2px 2px #53a7ea,
  //               3px 3px #53a7ea`,
  //       webkitTransform: `translateX(-3px)`,
  //       transform: `translateX(-3px)`
  //   }
  // },
  toolbar: {
    display: "flex",
    alignItems: "center",
    justifyContent: "flex-end",
    padding: "10px 8px",
    zIndex: 100,
    ...theme.mixins.toolbar
  },
  whiteColor: {
    color: "white"
  },
  content: {
    flexGrow: 1,
    //padding: '10px',
    padding: theme.spacing.unit * 3,
    overflowX: 'overlay',
    [theme.breakpoints.down("sm")]: {
      overflowX: "auto"

    },
  },

  mobile: {
    display: "block",
    [theme.breakpoints.down("sm")]: {
      display: "block"
    }
  },
  display: {
    display: "block",
    paddingLeft: "25px"
  },

  drawerMargin: {
    marginTop: "10px"
  },
  nested: {
    marginLeft: "15px",

  },
  rightAlign: {
    marginLeft: "auto"
  },
  wiproLogo: {
    // height: "60px",
    width: "60px",
    padding :"6px 3px",
    // position: "fixed",
    backgroundColor: 'white'
  },

  customerLogo: {
    //  height: "60px",
    width: "172px",
    padding: '10px',
    // marginBottom:'5px',
    // marginLeft: '59px',
    backgroundColor: 'white'
  },
  toastContainer: {
    position: "absolute",
    marginTop: "55px",
    zIndex: "100"
  },
  toast: {
    minHeight: "0px",
    marginBottom: "0px",
    border: "1px solid black",
    color: "black"
  },

  itemIcon: {
    fontSize: "20px",
    float: "left",
    textAlign: "center",
    verticalAlign: "middle",
    color: "#ffffff"
  },

  subheading: {
    color: "white"
  }
});

export default styles;
