const styles = theme => ({

button: {
    margin: theme.spacing.unit,
    color: '#fff',
    width: '100px',
    fontSize: '10px',
    padding: '9px 5px',
    backgroundColor: '#389bde',
    borderRadius: '90px',
    boxShadow: '0px 1px 2px 0px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0,0,0,0.24), 0px 3px 1px -2px rgba(0,0,0,0.02)',
    [theme.breakpoints.down('sm')]: {
    fontSize:'8px',
    width: '80px'
    }
  },
  
});

export default styles;