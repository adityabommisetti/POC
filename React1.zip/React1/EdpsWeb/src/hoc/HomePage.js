import React from "react";
import { Switch, withRouter } from "react-router-dom";
import Routers from "../routes/RouterComp";
import Layout from "./Layout";

const HomePage = React.memo(props => {


  return (
    <Switch>
      <Layout logout={props.logout}>
        <Routers />
      </Layout>
    </Switch>
  );
}
)



export default withRouter(HomePage);
