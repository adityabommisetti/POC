import "react-toastify/dist/ReactToastify.css";

import { CUSTOMER_LOGO, logo } from "../constants/Logos";

import AppBar from "@material-ui/core/AppBar";
import CssBaseline from "@material-ui/core/CssBaseline";
import Divider from "@material-ui/core/Divider";
import Drawer from "@material-ui/core/Drawer";
import { MobileDrawer } from "../components/Navigation/SwipeableDrawer";
import React from "react";
import SideDrawerTabs from "./SideDrawerTabs";
import ToolBar from "../components/Navigation/Toolbar";
import classNames from "classnames";
import { compose } from "recompose";
import { connect } from "react-redux";
import {loginAction} from "../redux/actions/loginAction"
import styles from "../assets/styles/LayoutStyle";
import { withRouter } from "react-router-dom";
import { withStyles } from "@material-ui/core/styles";
import  {Unauthorised 
} from '../components/UI/Unauthorised';

class Layout extends React.Component {
  state = {
    open: false,
    memberOpen: false,
    letterOpen: false,
    showhideFlag: false,
    mobileOpen: false,
    unauthorised:false
  };
  toggleDrawer = (side, open) => () => {
    this.setState((prevstate) => ({
      [side]: open,
      showhideFlag: open,
    }));
  };

  togglemobileDrawer = (side, open) => () => {
    this.setState({
      [side]: open,
    });
  };

   componentDidMount() {
    const servicesEnabled = this.props.loginData.servicesEnabled;
    const pageURL = window.location.href;
    const lastURLSegment = pageURL.substr(pageURL.lastIndexOf('/') + 1);

    const authMap = new Map([
       //['URL','SERVICE NAME']
      ['billing', 'EEMB']
    ]);
    
    if (authMap.get(lastURLSegment) != undefined && !servicesEnabled.includes(authMap.get(lastURLSegment))) {
      this.setState({ unauthorised: true });
  
    }
  }

  render() {
    let style;
    const { unauthorised } = this.state;
    const { classes, children } = this.props;
    let loginGroupName = this.props.loginData.loginVo.customerId;
    if (loginGroupName === "HCF0232") {
      style = {
        width: "140px",
      };
    } else if (loginGroupName === "HCF0281") {
      style = {
        width: "175px",
      };
    } else if (loginGroupName === "HCF0331") {
      style = {
        width: "115px",
      };
    }

    if (unauthorised) {
      return <Unauthorised />;
    }

    return (
      <React.Fragment>
        <div className={classes.root}>
          <CssBaseline />
          <AppBar
            className={classNames(classes.appBar, {
              [classes.appBarShift]: this.state.open,
            })}
          >
            <ToolBar
              logout={this.props.logout}
              classes={classes}
              handleDrawer={this.toggleDrawer("open", !this.state.open)}
              toggleDrawer={this.toggleDrawer(
                "mobileOpen",
                !this.state.mobileOpen
              )}
            />
          </AppBar>

          <MobileDrawer
            classes={classes}
            logo={logo}
            open={this.state.mobileOpen}
            hmkLogo={CUSTOMER_LOGO[loginGroupName]}
            handler={this.togglemobileDrawer("mobileOpen", false)}
            drawer={<SideDrawerTabs />}
          />

          <Drawer
            variant="permanent"
            className={classNames(classes.drawer, classes.sectionDesktop, {
              [classes.drawerOpen]: this.state.open,
              [classes.drawerClose]: !this.state.open,
            })}
            classes={{
              paper: classNames({
                [classes.drawerOpen]: this.state.open,
                [classes.drawerClose]: !this.state.open,
              }),
            }}
            open={this.state.open}
          >
            <span className={classes.logoContaier}>
              <img src={logo} className={classes.wiproLogo} alt="Wipro Logo" />
              <img
                style={style}
                src={CUSTOMER_LOGO[loginGroupName]}
                className={classes.customerLogo}
                alt="Customer Logo"
              />
            </span>

            <Divider />
            <SideDrawerTabs showhideFlag={this.state.showhideFlag} />
          </Drawer>

          <main className={classes.content}>
            <div className={classes.toolbar} />

            {children}
          </main>
          <br />
          <br />
          <br />
        </div>
        <br />
        <br />
        <footer className="footer margin-top1 mainFooter">
          <div className="small container">
            <div className="row">
              <div className="col-md-5">
                <p style={{ marginLeft: "20%" }}>
                  &copy; 2019 Wipro Technologies. All rights reserved.{" "}
                </p>
              </div>
              <div className="col-md-7">
                <ul className="footer-list">
                  <li>
                    <a href="/#">Contact Us</a>
                  </li>
                  <li>
                    <a href="/#">Additional Solutions</a>
                  </li>
                  <li>
                    <a href="/#">Medicare News</a>
                  </li>
                  <li>
                    <a href="/#">Documents</a>
                  </li>
                  <li>
                    <a href="/#">MMP Resource Tool Kit</a>
                  </li>
                  
                </ul>
              </div>
            </div>
          </div>
        </footer>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    loginData: state.loginData,
    isLoading: state.spinner.isLoading,
    
  };
};

const mapDispatchToProps = {
  loginAction,
  
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(compose(withRouter, withStyles(styles, { withTheme: true }))(Layout));
