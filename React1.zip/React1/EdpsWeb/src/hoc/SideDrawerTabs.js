import React, { Fragment, Component } from "react";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import { Link } from "react-router-dom";
import Tooltip from "@material-ui/core/Tooltip";
import classNames from "classnames";
import styles from "../assets/styles/LayoutStyle";
import { withStyles } from "@material-ui/core/styles";
import { compose } from "recompose";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import { loginAnalytics } from "../redux/actions/AnalyticsAction"


class SideDrawerTabs extends Component {
  state = {
    memberOpen: false,
    letterOpen: false,
    anchorEl: null
  };

  handleClick = event => {
    this.setState({ anchorEl: event.currentTarget });
    this.setState(state => ({
      memberOpen: !state.memberOpen,
      letterOpen: false,
    }));
  };


  handleLetterClick = event => {
    this.setState({ anchorEl: event.currentTarget });
    this.setState(state => ({
      memberOpen: false,
      letterOpen: !state.letterOpen,
    }));
  };
  handleAnalyticClick = async () => {
    await this.props.loginAnalytics();
    let { data } = this.props.analyticsData;
    let { jasperURL, ppValue } = data
    let url = jasperURL + "?pp=" + ppValue
    window.open(url)

  }

  handleClose = () => {
    this.setState({ anchorEl: null, letterOpen: false, memberOpen: false });

  };
  async componentDidMount() {
    this.intervalId = setInterval(() => {
      if (localStorage.getItem("token") === null) {
        this.props.closeAllTab();
      }
    }, 1000);
  }
  async componentWillUnmount() {
    await clearInterval(this.intervalId);
  }




  render() {

    const { classes, location: { pathname } } = this.props;
    const { anchorEl } = this.state;
    const open = Boolean(anchorEl);

    return (
      <Fragment>
        <List>
          <ListItem
            className="hvr-bounce-to-right"
            button
            component={Link}
            to={{
              pathname: "/dashboard",
              name: "Graphical Dashboard"
            }}
            selected={"/dashboard" === pathname}
            classes={{
              selected: classes.selected,
              button: classes.items
            }}
          >
            <Tooltip title="Graphical Dashboard" placement="right">
              <ListItemIcon>
                <i className={classNames("material-icons", classes.icons)}>
                  dashboard
                </i>
              </ListItemIcon>
            </Tooltip>
            <ListItemText
              className={{
                [classes.display]: this.props.showhideFlag
              }}
              primary="Graphical Dashboard"
            />
          </ListItem>

          <ListItem
            className="hvr-bounce-to-right"
            button
            component={Link}
            to={{
              pathname: "/encounter",
              name: "EDPS Management"
            }}
            selected={"/encounter" === pathname}
            classes={{
              selected: classes.selected,
              button: classes.items
            }}
          >
            <Tooltip title="EDPS Management" placement="right">
              <ListItemIcon>
                <i className={classNames("fas fa-chart-bar", classes.icons)} id="chartManagement" />
              </ListItemIcon>
            </Tooltip>
            <ListItemText

              className={{
                [classes.display]: this.props.showhideFlag
              }}
              primary="EDPS Management"
            />
          </ListItem>
          <ListItem

            className="hvr-bounce-to-right"
            button
            classes={{
              selected: classes.selected,
              button: classes.items
            }}
            component={Link}
            to={{
              pathname: "/reject",
              name: "Reject Analysis Summary"
            }}
            selected={"/reject" === pathname}
          >
            <Tooltip title="Reject Analysis Summary" placement="right">
              <ListItemIcon>

                <i className={classNames("fas fa-times-circle", classes.icons)} id="rejectAnalysis" />
              </ListItemIcon>
            </Tooltip>

            <ListItemText
              className={{ [classes.display]: this.props.showhideFlag }}
              primary="Reject Analysis Summary"
            />
          </ListItem>

          <ListItem

            className="hvr-bounce-to-right"
            button
            classes={{
              selected: classes.selected,
              button: classes.items
            }}
            component={Link}
            to={{
              pathname: "/chart",
              name: "Chart Management"
            }}
            selected={"/chart" === pathname}
          >
            <Tooltip title="Chart Management" placement="right">
              <ListItemIcon>

                <i className={classNames("fas fa-chart-line", classes.icons)} id="chartManagement" />
              </ListItemIcon>
            </Tooltip>

            <ListItemText
              className={{ [classes.display]: this.props.showhideFlag }}
              primary="Chart Management"
            />
          </ListItem>

          <ListItem
            className="hvr-bounce-to-right"
            button
            component={Link}
            to={{
              pathname: "/chartReject",
              name: "Chart Reject Analysis"
            }}
            selected={"/chartReject" === pathname}
            classes={{
              selected: classes.selected,
              button: classes.items
            }}
          >
            <Tooltip title="Chart Reject Management" placement="right">
              <ListItemIcon>
                <i className={classNames("fa fa-pie-chart", classes.icons)}>
                </i>
              </ListItemIcon>
            </Tooltip>
            <ListItemText
              className={{
                [classes.display]: this.props.showhideFlag
              }}
              primary="Chart Reject Analysis"
            />
          </ListItem>

          <ListItem
            className="hvr-bounce-to-right"
            button
            component={Link}
            to="/file"
            selected={"/file" === pathname}
            /**Routing Path needs to be changed */
            onClick={this.handleClick}
            aria-label="More"
            aria-owns={open ? "mouse-over-popover" : undefined}
            aria-haspopup="true"
            classes={{
              selected: classes.selected,
              button: classes.items
            }}
          >
            <Tooltip title="EDPS File Management" placement="right">
              <ListItemIcon>
                <i className={classNames("fas fa-folder-open", classes.icons)} />
              </ListItemIcon>
            </Tooltip>
            <ListItemText
              className={{ [classes.display]: this.props.showhideFlag }}
              primary="EDPS File Management"
            />
          </ListItem>

          <ListItem

            className="hvr-bounce-to-right"
            button
            component={Link}
            to="/userDoc"
            selected={"/userDoc" === pathname}
            onClick={this.handleClick}
            aria-label="More"
            aria-owns={open ? "mouse-over-popover" : undefined}
            aria-haspopup="true"
            classes={{
              selected: classes.selected,
              button: classes.items
            }}
          >
            <Tooltip title="User Document" placement="right">
              <ListItemIcon>
                <i className={classNames("fas fa-file-alt", classes.icons)} />
              </ListItemIcon>
            </Tooltip>
            <ListItemText
              className={{ [classes.display]: this.props.showhideFlag }}
              primary="User Document"
            />
          </ListItem>

          <ListItem

            className="hvr-bounce-to-right"
            button
            component={Link}
            to="/help"
            selected={"/help" === pathname}
            onClick={this.handleClick}
            aria-label="More"
            aria-owns={open ? "mouse-over-popover" : undefined}
            aria-haspopup="true"
            classes={{
              selected: classes.selected,
              button: classes.items
            }}
          >
            <Tooltip title="Help" placement="right">
              <ListItemIcon>
                <i className={classNames("fas fa-question-circle", classes.icons)} />
              </ListItemIcon>
            </Tooltip>
            <ListItemText
              className={{ [classes.display]: this.props.showhideFlag }}
              primary="Help"
            />
          </ListItem>
          <ListItem

            className="hvr-bounce-to-right"
            button

            onClick={this.handleAnalyticClick}
            aria-label="More"
            aria-owns={open ? "mouse-over-popover" : undefined}
            aria-haspopup="true"
            classes={{
              selected: classes.selected,
              button: classes.items
            }}
          >
            <Tooltip title="Analytics" placement="right">
              <ListItemIcon>
                <i className={classNames("far fa-chart-bar", classes.icons)} />
              </ListItemIcon>
            </Tooltip>
            <ListItemText
              className={{ [classes.display]: this.props.showhideFlag }}
              primary="Analytics"
            />
          </ListItem>
        </List>
      </Fragment>
    );
  }
}
const mapDispatchToProps = {

  loginAnalytics,
};
const mapStateToProps = (state) => {
  return {

    analyticsData: state.AnalyticsReducer.loginVoAnalytics
  };
};

export default compose(
  withRouter,
  withStyles(styles, { withTheme: true }),
  connect(mapStateToProps, mapDispatchToProps)
)(SideDrawerTabs);

