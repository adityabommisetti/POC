import cacheDataReducer from "./CacheDataReducer";
import { combineReducers } from "redux";
import encounterDetailsReducer from "./../reducers/encounterDetailsReducer";
import ClaimCodeReducer from "./../reducers/ClaimCodeReducer";
import FileReducer from "./../reducers/FileReducer";
import CityZipReducer from "./../reducers/CityZipReducer";
import loginReducer from "./../reducers/LoginReducer";
import NotificationReducer from "./../reducers/NotificationReducer";
import AnalyticsReducer from "./../reducers/AnalyticsReducer"
import { spinnerReducer } from "../reducers/SpinnerReducer";

const appReducer = combineReducers({
  encounterDetailsData: encounterDetailsReducer,
  ClaimCodeReducer: ClaimCodeReducer,
  FileReducer: FileReducer,
  CityZipReducer: CityZipReducer,
  spinner: spinnerReducer,
  dropdowns: cacheDataReducer,
  loginData: loginReducer,
  notificationReducer:NotificationReducer,
  AnalyticsReducer: AnalyticsReducer
});

const rootReducer = (state, action) => {
  return appReducer(state, action)
}

export default rootReducer;
 