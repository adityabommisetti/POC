import * as ActionTypes from "../../constants/actionConstants/applActionValues";

const initialState = {
  subscriberVo: [],
  providerVo: [],
  dashBoardList: [],
  dashBoardYrData: [],
  dashBoardMnthData: [],
  rejectBoardYrData: [],
  rejectBoardMnthData: [],
  rejectBoardList: [],
  errorCodeList: [],
  searchResultList: [],
  claimVersion: [],
  vanTanList: [],
  logDetails: [],
  subscriber_Data: [],
  provider_Data: [],
  fileDashboard: [],
  dashBoardExpData: [],
  rejectBoardExpData: [],
  dashBoardGraphCriteria: [],
  rejectBoardGraphCriteria: [],
  dashBoardEncounterCriteria: [],
  dashBoardChartCriteria: [],
  rejectBoardEncounterCriteria: [],
  rejectBoardChartCriteria: [],
  errorCodeEncounterCriteria: [],
  errorCodeChartCriteria: [],
  encounterCriteria: [],
  rejectEncounterCriteria: [],
  chartEncounterCriteria: [],
  chartRejectEncounterCriteria: []
}


export default function encounterDetailsReducer(state = initialState, action) {
  switch (action.type) {

    case ActionTypes.ENCOUNTER_CRITERIA:
      return {
        ...state,
        encounterCriteria: action.payload
      };
    case ActionTypes.REJECT_CRITERIA:
      return {
        ...state,
        rejectEncounterCriteria: action.payload
      };
    case ActionTypes.CHART_CRITERIA:
      return {
        ...state,
        chartEncounterCriteria: action.payload
      };
    case ActionTypes.CHART_REJECT_CRITERIA:
      return {
        ...state,
        chartRejectEncounterCriteria: action.payload
      };
    case ActionTypes.DASHBOARD_ENCOUNTER_CRITERIA:
      return {
        ...state,
        dashBoardEncounterCriteria: action.payload
      };
    case ActionTypes.DASHBOARD_CHART_CRITERIA:
      return {
        ...state,
        dashBoardChartCriteria: action.payload
      };
    case ActionTypes.REJECTBOARD_ENCOUNTER_CRITERIA:
      return {
        ...state,
        rejectBoardEncounterCriteria: action.payload
      };
    case ActionTypes.REJECTBOARD_CHART_CRITERIA:
      return {
        ...state,
        rejectBoardChartCriteria: action.payload
      };
    case ActionTypes.ERRORCODE_CHART_CRITERIA:
      return {
        ...state,
        errorCodeChartCriteria: action.payload
      };
    case ActionTypes.ERRORCODE_ENCOUNTER_CRITERIA:
      return {
        ...state,
        errorCodeEncounterCriteria: action.payload
      };
    case ActionTypes.DASHBOARD_GRAPH_CRITERIA:
      return {
        ...state,
        dashBoardGraphCriteria: action.payload
      };
    case ActionTypes.REJECTBOARD_GRAPH_CRITERIA:
      return {
        ...state,
        rejectBoardGraphCriteria: action.payload
      };
    case ActionTypes.ENCOUNTER_SEARCH:
      return {
        ...state,
        searchResultList: action.payload.data
      };
    case ActionTypes.CLAIM_VERSION:
      return {
        ...state,
        claimVersion: action.payload
      };
    case ActionTypes.VAN_TAN_SEARCH:
      return {
        ...state,
        vanTanList: action.payload
      };
    case ActionTypes.DASHBOARD_SEARCH:
      return {
        ...state,
        dashBoardList: action.payload.data
      };
    case ActionTypes.DASHBOARD_EXPORT:
      return {
        ...state,
        dashBoardExpData: [...action.payload.data]
      };
    case ActionTypes.DASHBOARD_YEAR_GRAPH:
      return {
        ...state,
        dashBoardYrData: action.payload.data
      };
    case ActionTypes.DASHBOARD_MONTH_GRAPH:
      return {
        ...state,
        dashBoardMnthData: action.payload.data
      };
      case ActionTypes.REJECTBOARD_YEAR_GRAPH:
        return {
          ...state,
          rejectBoardYrData: action.payload.data
        };
      case ActionTypes.REJECTBOARD_MONTH_GRAPH:
        return {
          ...state,
          rejectBoardMnthData: action.payload.data
        };
    case ActionTypes.REJECT_EXPORT:
      return {
        ...state,
        rejectBoardExpData: action.payload.data
      };
    case ActionTypes.DASHBOARD_REJECT:
      return {
        ...state,
        rejectBoardList: action.payload.data
      };
    case ActionTypes.LOG_DETAILS:
      return {
        ...state,
        logDetails: action.payload.data
      };
    case ActionTypes.SUBSCRIBER_DETAILS:
      return {
        ...state,
        subscriber_Data: action.payload.data
      };
    case ActionTypes.PROVIDER_DETAILS:
      return {
        ...state,
        provider_Data: action.payload.data
      };
    case ActionTypes.FILE_DASHBOARD:
      return {
        ...state,
        fileDashboard: action.payload.data
      };
    case ActionTypes.ERROR_CODE:
      return {
        ...state,
        errorCodeList: action.payload.data
      };
    case ActionTypes.CLAIM_NOTES_DETAILS:
      return {
        ...state,
        notesDatatable: action.payload.data
      };
    default:
      return state;
  }
}
