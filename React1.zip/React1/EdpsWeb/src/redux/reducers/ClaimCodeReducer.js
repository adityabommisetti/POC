import * as ActionTypes from "../../constants/actionConstants/applActionValues";

const initialState = {
    claim_Data: [],
    claimVo: [],
    claim_diagnosis_data: [],
    claim_condition_data: [],
    claim_OccurrenceSpan_data: [],
    claim_procedureCode_data: [],
    claim_Value_data: [],
    claim_Ext_Cause_Injury_Data: [],
    claim_Occurrence_data: [],
    claim_treatment_data: [],
}
export default function claimCodeReducer(state = initialState, action) {
    switch (action.type) {
        case ActionTypes.FETCH_CLAIM:
            return {
                ...state,
                claimVo: action.payload.data
            };
        case ActionTypes.DELETE_CLAIM_PROVIDER:
            return {
                ...state,
                claimVo: {
                    ...state.claimVo,
                    claimProvidersList: action.payload.data
                }
            };
        case ActionTypes.CLAIM_DETAILS:
            return {
                ...state,
                claim_Data: action.payload.data
            };
        case ActionTypes.CLAIM_DIAGNOSIS_CODE:
            return {
                ...state,
                claim_diagnosis_data: action.payload.data
            };

        case ActionTypes.CLAIM_CONDITION_CODE:
            return {
                ...state,
                claimVo: {
                    ...state.claimVo,
                    claimConditionsList: action.payload.data
                }
            };

        case ActionTypes.CLAIM_PROCEDURE_CODE:
            return {
                ...state,
                claim_procedureCode_data: action.payload.data
            };

        case ActionTypes.CLAIM_OCCURRENCE_SPAN_CODE:
            return {
                ...state,
                claim_OccurrenceSpan_data: action.payload.data
            };
        case ActionTypes.CLAIM_OCCURRENCE_CODE:
            return {
                ...state,
                claim_Occurrence_data: action.payload.data
            };
        case ActionTypes.CLAIM_TREATMENT_CODE:
            return {
                ...state,
                claim_treatment_data: action.payload.data
            };

        case ActionTypes.CLAIM_VALUE_CODE:
            return {
                ...state,
                claim_Value_data: action.payload.data
            };

        case ActionTypes.CLAIM_EXT_CAUSE_INJURY:
            return {
                ...state,
                claim_Ext_Cause_Injury_Data: action.payload.data
            };

        case ActionTypes.CLAIM_LINE_ADJUDICATION_ADJUSTMENT:
            return {
                ...state,
                claimVo: {
                    ...state.claimVo,
                    claimLineAdjudications: [
                        ...state.claimVo.claimLineAdjudications.map(
                            (el, index) => index === action.index ? { ...el, "adjustments": action.payload.data } : el
                        )
                    ]
                }
            };

        default:
            return state;
    }
}
