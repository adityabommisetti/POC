import * as ActionTypes from "../../constants/actionConstants/applActionValues";

const initialState = {
  fileDashboard: [],
  monthlyData: [],
  dailyData: [],
  fileTrack: []
}

export default function FileReducer(state = initialState, action) {
  switch (action.type) {

    case ActionTypes.FILE_DASHBOARD:
      return {
        ...state,
        fileDashboard: action.payload.data
      };
    case ActionTypes.MONTHLY_FILE:
      return {
        ...state,
        monthlyData: action.payload.data
      };
    case ActionTypes.DAILY_FILE:
      return {
        ...state,
        dailyData: action.payload.data
      };
    case ActionTypes.FILE_TRACKING:
      return {
        ...state,
        fileTrack: action.payload.data
      };
    default:
      return state;
  }
}

