import * as ActionTypes from "../../constants/actionConstants/applActionValues";

const initialState = {
    cityZipSearchData: []
}
export default function cityZipSearchReducer(state = initialState, action) {
    switch (action.type) {
        case ActionTypes.CITY_ZIP_SEARCH:
            return {
              ...state,
              cityZipSearchData: [...action.payload.data]
            };
        case ActionTypes.RESET_CITY_ZIP_SEARCH:
            return {
                ...state,
                cityZipSearchData: []
            };

        default:
            return state;
    }
}
