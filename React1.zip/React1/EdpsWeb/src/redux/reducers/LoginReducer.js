import * as ActionTypes from "../../constants/actionConstants/applActionValues";

const initialState = { loginVo: {}, authenticated: false, errorMsg: "", servicesEnabled: [] };

export default function loginReducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.LOGIN_SUCCESS:
      return {
        loginVo: action.loginVo.object,
        servicesEnabled: action.loginVo.listObject,
        authenticated: true,
        errorMsg: ""
      };


    case ActionTypes.LOGIN_FAILED:
      return {
        errorMsg: action.errorMsg
      };

    default:
      return state;
  }
}
