import * as ActionTypes from "../../constants/actionConstants/applActionValues";
export default function cacheDataReducer(state = {}, action) {
    switch (action.type) {
        case ActionTypes.CACHE_DATA:
            return { ...action.payload.data };
        default:
            return state;
    }
}
