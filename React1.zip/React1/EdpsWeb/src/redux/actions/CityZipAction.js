import * as ActionTypes from "../../constants/actionConstants/applActionValues";
import * as URL from "../../services/API_URL";
import axios from "../../utils/axios";

export const searchCityZip = (searchVO) => {
  return async dispatch => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true
    });
    if (spin) {
      return axios
        .post(URL.CITY_ZIP_POPUP, searchVO, { headers: { "x-auth-token": localStorage.getItem("token") } })
        .then(response => {
          dispatch({ type: ActionTypes.CITY_ZIP_SEARCH, payload: response.data });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })
        .catch(error => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];
              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "done";
  };
};

export const resetZip = () => {
    return async (dispatch) => {
      dispatch({
        type: ActionTypes.RESET_CITY_ZIP_SEARCH,
      });
    };
  };
  
