import * as ActionTypes from "../../constants/actionConstants/applActionValues";
import * as URL from "../../services/API_URL";
import axios from "../../utils/axios";

function postRequest(API_URL, body, Success_Action) {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .post(API_URL, body, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            dispatch({ type: Success_Action, payload: response.data });
          } else {
            dispatch({ type: Success_Action, payload: { data: [] } });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })
        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          dispatch({ type: Success_Action, payload: { data: [] } });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];
              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return null;
  };
};

export const fileDashboardDetails = (searchVO) => {
  return postRequest(URL.FILE_DASHBOARD, searchVO, ActionTypes.FILE_DASHBOARD);
};

// export const fileDashboardDetails = searchVo => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.FILE_DASHBOARD, searchVo, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.FILE_DASHBOARD, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//         });
//     }
//     return "done";
//   };
// };

export const monthlyDetails = (searchVO) => {
  return postRequest(URL.MONTHLY_FILE, searchVO, ActionTypes.MONTHLY_FILE);
};

// export const monthlyDetails = searchVo => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.MONTHLY_FILE, searchVo, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.MONTHLY_FILE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//         });
//     }
//     return "done";
//   };
// };

export const dailyDetails = (searchVO) => {
  return postRequest(URL.DAILY_FILE, searchVO, ActionTypes.DAILY_FILE);
};

// export const dailyDetails = searchVo => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.DAILY_FILE, searchVo, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.DAILY_FILE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//         });
//     }
//     return "done";
//   };
// };



export const updateFile = searchVo => {
  return async dispatch => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true
    });
    if (spin) {
      return axios
        .post(URL.FILE_UPDATE, searchVo, { headers: { "x-auth-token": localStorage.getItem("token") } })
        .then(response => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return response.data;
        })
        .catch(error => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];
              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return error.response.data
        });
    }
    return "done";
  };
};

export const retreiveFile = searchVo => {
  return async dispatch => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true
    });
    if (spin) {
      return axios
        .post(URL.FILE_RETREIVE, searchVo, { headers: { "x-auth-token": localStorage.getItem("token") } })
        .then(response => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return (response.data.data);
        })
        .catch(error => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];
              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "done";
  };
};


export const fileTracking = searchVo => {
  return async dispatch => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true
    });
    if (spin) {
      return axios
        .post(URL.FILE_TRACKING, searchVo, { headers: { "x-auth-token": localStorage.getItem("token") } })
        .then(response => {
          dispatch({ type: ActionTypes.FILE_TRACKING, payload: response.data });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return (response.data.data);
        })
        .catch(error => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];
              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "done";
  };
};







