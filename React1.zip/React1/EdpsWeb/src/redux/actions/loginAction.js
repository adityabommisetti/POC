import * as ActionTypes from "../../constants/actionConstants/applActionValues";
import * as URL from "../../services/API_URL";

import axios from "axios";

const EDPSURL = "/edps-api";
const MSSLOGINURL = "/mss-api";
const MSSURL = "/msslogin-api";
//const MSSURL = "http://d-113161145:8082/mss-api"

export const getUserInfo = () => {
  return async dispatch => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true
    });
    if (spin) {
      return axios
        .get(EDPSURL + "/auth/get/userinfo", { headers: { "x-auth-token": localStorage.getItem("token") } })
        .then(response => {
          if (response && response.data.statusCode === 200) {
            dispatch({
              type: ActionTypes.LOGIN_SUCCESS,
              loginVo: response.data
            });
          } else {
            alert("Login Failed!");
            localStorage.clear();
            dispatch({
              type: ActionTypes.LOGIN_FAILED,
              errorMsg: response.data.message
            });
          }

          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })
        .catch(error => {
          localStorage.clear();
          dispatch({
            type: ActionTypes.LOGIN_FAILED,
            errorMsg: ""
          });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        });
    }
    return "done";
  };
};

export const loginAction = loginBody => {
  return async dispatch => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true
    });
    if (spin) {
      var authorizationBasic = window.btoa(loginBody.userId + ':' + loginBody.pwd);
      return axios
        .post(MSSURL + "/auth/login", "", {
          headers: { "Authorization": "Basic " + authorizationBasic }
        })
        .then(response => {
          console.log(response);
          if (response && response.data.statusCode === 200) {
            var token = response.headers["x-auth-token"];
            localStorage.setItem("token", "Bearer " + token);
            localStorage.setItem("login", true);
            dispatch({
              type: ActionTypes.LOGIN_SUCCESS,
              loginVo: response.data
            });
          } else {
            localStorage.clear();
            alert("Login Failed!");
            dispatch({
              type: ActionTypes.LOGIN_FAILED,
              errorMsg: response.data.message
            });
          }

          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })
        .catch(error => {
          localStorage.clear();

          dispatch({
            type: ActionTypes.LOGIN_FAILED,
            errorMsg: error.response.data.message
          });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        });
    }
    return "done";
  };
};

export const logoutAction = () => {
  return async dispatch => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true
    });
    if (spin) {
      return axios
        .get(MSSURL + '/auth/logout')
        .then(response => {
          localStorage.clear();
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })
        .catch(error => {
          console.log(error);
          localStorage.clear();
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        });
    }
    return "done";
  };
};


export const getNotificationData = () => {
  return async dispatch => {
    return axios
      .get(MSSLOGINURL + URL.NOTIFICATION_API, { headers: { "x-auth-token": localStorage.getItem("token") } })
      .then(response => {
        dispatch({
          type: ActionTypes.GET_NOTIFICATION_DATA,
          payload: response.data
        });
        return "success";
      })
      .catch(error => {
        dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        if (error.response && error.response.status === 500) {
          if (error.response.headers["x-auth-token"]) {
            var token = error.response.headers["x-auth-token"];
            localStorage.setItem("token", "Bearer " + token);
          }
        }
        if (error.response && error.response.data) {
          return error.response.data.message;
        }
      });
  };
};


