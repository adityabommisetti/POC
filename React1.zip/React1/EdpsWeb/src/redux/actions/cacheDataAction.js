import * as ActionTypes from "../../constants/actionConstants/applActionValues";
import * as URL from "../../services/API_URL";
import axios from "../../utils/axios";

export const fetchCacheData = () => {
  return async dispatch => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true
    });
    if (spin) {
      return axios
        .get(URL.CACHE_DATA, { headers: { "x-auth-token": localStorage.getItem("token") } })
        .then(response => {
          for (const key of Object.keys(response.data.data)) {
            if (response.data.data[key] &&
              (key !== ("stateList") &&
               key !== ("optionsSubmitters") &&
               key !== ("optionsEncType") && 
               key !== ("lstEntityType") && 
               key !== ("lstProviderType") && 
               key !== ("dashboardEncTypeList") && 
               key !== ("lstEntityType"))) {
              response.data.data[key].splice(0, 0, { value: "", label: "Select" })
            }
          }
          dispatch({ type: ActionTypes.CACHE_DATA, payload: response.data });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })
        .catch(error => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];
              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "done";
  };
};