import * as ActionTypes from "../../constants/actionConstants/applActionValues";
import * as URL from "../../services/API_URL";
import axios from "axios";

export const loginAnalytics = () => {
    return async (dispatch) => {
      const spin = await dispatch({
        type: ActionTypes.SET_SPINNER,
        payload: true
      });
  
      if (spin) {
        var TimeoutAnalytics=setTimeout(
          dispatch,4000,{type: ActionTypes.SET_SPINNER}, {payload: false});
        return axios
          .get("/msslogin-api" + URL.LOGIN_ANALYTICS, {
           headers: { "x-auth-token": localStorage.getItem("token") },
          })
          .then((response) => {
            dispatch({ type: ActionTypes.LOGIN_ANALYTICS, spin: false });
            if (response.status === 200) {
              clearTimeout(TimeoutAnalytics);
              dispatch({ type: ActionTypes.LOGIN_ANALYTICS, payload: response.data });
              dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
              return response.data.message;
            } else {
              clearTimeout(TimeoutAnalytics);
              dispatch({ type: ActionTypes.LOGIN_ANALYTICS, payload: [] });
              dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
            }
          })
          .catch(error => {
            clearTimeout(TimeoutAnalytics);
            dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
            console.log(error);
            if (error.response && error.response.status === 500) {
              if (error.response.headers["x-auth-token"]) {
                var token = error.response.headers["x-auth-token"];
                localStorage.setItem("token", "Bearer " + token);
              }
            }
          });    }
      return "success";
    };
  };