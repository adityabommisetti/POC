import * as ActionTypes from "../../constants/actionConstants/applActionValues";
import * as URL from "../../services/API_URL";
import axios from "../../utils/axios";

export const encounterCriteria = (searchVo, location) => {
  return async dispatch => {
    if(location === "/encounter"){
      return dispatch({ type: ActionTypes.ENCOUNTER_CRITERIA, payload: searchVo });
    } else if(location === "/reject"){
      return dispatch({ type: ActionTypes.REJECT_CRITERIA, payload: searchVo });
    } else if(location === "/chart"){
      return dispatch({ type: ActionTypes.CHART_CRITERIA, payload: searchVo });
    } else if(location === "/chartReject"){
      return dispatch({ type: ActionTypes.CHART_REJECT_CRITERIA, payload: searchVo });
    }
  };
};

export const dashBoardCriteria = (searchVo, location) => {
  return async dispatch => {
    if(location === "/encounter"){
      dispatch({ type: ActionTypes.DASHBOARD_ENCOUNTER_CRITERIA, payload: searchVo });
    } else if(location === "/chart"){
      dispatch({ type: ActionTypes.DASHBOARD_CHART_CRITERIA, payload: searchVo });
    }
  };
};

export const rejectBoardCriteria = (searchVo, location) => {
  return async dispatch => {
    if(location === "/reject"){
      dispatch({ type: ActionTypes.REJECTBOARD_ENCOUNTER_CRITERIA, payload: searchVo });
    } else if(location === "/chartReject"){
      dispatch({ type: ActionTypes.REJECTBOARD_CHART_CRITERIA, payload: searchVo });
    }
  };
};

export const dashBoardGraphCriteria = (searchVo) => {
  return async dispatch => {
    dispatch({ type: ActionTypes.DASHBOARD_GRAPH_CRITERIA, payload: searchVo });
  };
};

export const rejectBoardGraphCriteria = (searchVo) => {
  return async dispatch => {
    dispatch({ type: ActionTypes.REJECTBOARD_GRAPH_CRITERIA, payload: searchVo });
  };
};

export const errorCodeCriteria = (searchVo, location) => {
  return async dispatch => {
    if(location === "/reject"){
      return dispatch({ type: ActionTypes.ERRORCODE_ENCOUNTER_CRITERIA, payload: searchVo });
    } else if(location === "/chartReject"){
      return dispatch({ type: ActionTypes.ERRORCODE_CHART_CRITERIA, payload: searchVo });
    }
  };
};

function postRequest(API_URL, body, Success_Action) {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .post(API_URL, body, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            dispatch({ type: Success_Action, payload: response.data });
          } else {
            dispatch({ type: Success_Action, payload: { data: [] } });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })
        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          dispatch({ type: Success_Action, payload: { data: [] } });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];
              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "done";
  };
};

export const dashBoardSearch = (searchVO) => {
  return postRequest(URL.DASHBOARD_SEARCH, searchVO, ActionTypes.DASHBOARD_SEARCH);
};

export const dashBoardExport = (searchVO) => {
  return postRequest(URL.DASHBOARD_EXPORT, searchVO, ActionTypes.DASHBOARD_EXPORT);
};

export const dashBoardGraph = (searchVO) => {
  if(searchVO.reportType === ""){
    return postRequest(URL.DASHBOARD_GRAPH, searchVO, ActionTypes.DASHBOARD_YEAR_GRAPH);
  }
  else{
    return postRequest(URL.DASHBOARD_GRAPH, searchVO, ActionTypes.DASHBOARD_MONTH_GRAPH);
  } 
};

export const rejectBoardGraph = (searchVO) => {
  if(searchVO.reportType === ""){
    return postRequest(URL.REJECTBOARD_GRAPH, searchVO, ActionTypes.REJECTBOARD_YEAR_GRAPH);
  }
  else{
    return postRequest(URL.REJECTBOARD_GRAPH, searchVO, ActionTypes.REJECTBOARD_MONTH_GRAPH);
  } 
};

export const rejectBoardSearch = (searchVO) => {
  return postRequest(URL.DASHBOARD_REJECT, searchVO, ActionTypes.DASHBOARD_REJECT);
};

// export const rejectBoardSearch = searchVo => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.DASHBOARD_REJECT, searchVo, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.DASHBOARD_REJECT, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//         });
//     }
//     return "done";
//   };
// };

export const rejectBoardExport = (searchVO) => {
  return postRequest(URL.REJECT_EXPORT, searchVO, ActionTypes.REJECT_EXPORT);
};

// export const rejectBoardExport = searchVo => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.claimVersionRequired, searchVo, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.REJECT_EXPORT, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//         });
//     }
//     return "done";
//   };
// };

export const errorCodeSearch = (searchVO) => {
  return postRequest(URL.ERROR_CODE, searchVO, ActionTypes.ERROR_CODE);
};

// export const errorCodeSearch = searchVo => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.ERROR_CODE, searchVo, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.ERROR_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//         });
//     }
//     return "done";
//   };
// };

export const encounterSearch = (searchVO) => {
  return postRequest(URL.SEARCH_ENCOUNTER, searchVO, ActionTypes.ENCOUNTER_SEARCH);
};

export const getEncounterExport = searchVo => {
  return async dispatch => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true
    });
    if (spin) {
      return axios
        .post(searchVo.exportAll ? URL.EXPORT_ENCOUNTER_ALL: URL.EXPORT_ENCOUNTER_CURRENT, 
          searchVo, { headers: { "x-auth-token": localStorage.getItem("token") } })
        .then(response => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
            return(response.data.data)
        })
        .catch(error => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response.headers["x-auth-token"]) {
            var token = error.response.headers["x-auth-token"];
            localStorage.setItem("token", "Bearer " + token);
          }
        });
    }
    return "done";
  };
};


export const fetchVersion = searchVo => {
  return async dispatch => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true
    });
    if (spin) {
      return axios
        .post(URL.CLAIM_VERSION, searchVo, { headers: { "x-auth-token": localStorage.getItem("token") } })
        .then(response => {
          if(searchVo.claimVersionRequired){
            dispatch({ type: ActionTypes.CLAIM_VERSION, payload: response.data.data });
            dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          }else if(searchVo.isVanTn){
            dispatch({ type: ActionTypes.VAN_TAN_SEARCH, payload: response.data.data });
            dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          }
        })
        .catch(error => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response.headers["x-auth-token"]) {
            var token = error.response.headers["x-auth-token"];
            localStorage.setItem("token", "Bearer " + token);
          }
        });
    }
    return "done";
  };
};

export const logDetailsSearch = (searchVO) => {
  return postRequest(URL.LOG_DETAILS, searchVO, ActionTypes.LOG_DETAILS);
};

// export const logDetailsSearch = searchVo => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.LOG_DETAILS, searchVo, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.LOG_DETAILS, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//         });
//     }
//     return "done";
//   };
// };

export const subscriberDetails = (searchVO) => {
  return postRequest(URL.FETCH_SUBSCRIBER, searchVO, ActionTypes.SUBSCRIBER_DETAILS);
};

// export const subscriberDetails = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.FETCH_SUBSCRIBER, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.SUBSCRIBER_DETAILS, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//         });
//     }
//     return "done";
//   };
// };

export const subscriberUpdate = params => {
  return async dispatch => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true
    });
    if (spin) {
      return axios
        .post(URL.UPDATE_SUBSCRIBER, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
        .then(response => {
          dispatch({ type: ActionTypes.SUBSCRIBER_DETAILS, payload: response.data });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return "success";
        })
        .catch(error => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response.headers["x-auth-token"]) {
            var token = error.response.headers["x-auth-token"];
            localStorage.setItem("token", "Bearer " + token);
          }
          return (error.response.data.message);
        });
    }
    return "done";
  };
};

export const providerDetails = (searchVO) => {
  return postRequest(URL.FETCH_PROVIDER, searchVO, ActionTypes.PROVIDER_DETAILS);
};

// export const providerDetails = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.FETCH_PROVIDER, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.PROVIDER_DETAILS, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//         });
//     }
//     return "done";
//   };
// };

export const providerUpdate = params => {
  return async dispatch => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true
    });
    if (spin) {
      return axios
        .post(URL.UPDATE_PROVIDER, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
        .then(response => {
          dispatch({ type: ActionTypes.PROVIDER_DETAILS, payload: response.data });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return "success";
        })
        .catch(error => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response.headers["x-auth-token"]) {
            var token = error.response.headers["x-auth-token"];
            localStorage.setItem("token", "Bearer " + token);
          }
          return (error.message);
        });
    }
    return "done";
  };
};

export const fetchClaim = (searchVO) => {
  return postRequest(URL.FETCH_CLAIM, searchVO, ActionTypes.FETCH_CLAIM);
};

// export const fetchClaim = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.FETCH_CLAIM, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.FETCH_CLAIM, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//         });
//     }
//     return "done";
//   };
// };


export const updateClaim = params => {
  return async dispatch => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true
    });
    if (spin) {
      return axios
        .post(URL.UPDATE_CLAIM, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
        .then(response => {
          dispatch({ type: ActionTypes.FETCH_CLAIM, payload: response.data });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return "success";
        })
        .catch(error => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response.headers["x-auth-token"]) {
            var token = error.response.headers["x-auth-token"];
            localStorage.setItem("token", "Bearer " + token);
          }
          return (error.response.data.message);
        });
    }
    return "done";
  };
};



export const deleteClmProvider = params => {
  return async dispatch => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true
    });
    if (spin) {
      return axios
        .post(URL.DELETE_CLAIM_PROVIDER, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
        .then(response => {
          dispatch({ type: ActionTypes.DELETE_CLAIM_PROVIDER, payload: response.data });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return response.data;
        })
        .catch(error => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response.headers["x-auth-token"]) {
            var token = error.response.headers["x-auth-token"];
            localStorage.setItem("token", "Bearer " + token);
          }
          return (error.response.data.message);
        });
    }
    return "done";
  };
};


export const fetchAttachment = (params, index) => {
  return async dispatch => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true
    });
    if (spin) {
      return axios
        .post(URL.FETCH_ATTACHMENT, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
        .then(response => {
          dispatch({ type: ActionTypes.CLAIM_LINE_ADJUDICATION_ADJUSTMENT, payload: response.data, index: index });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })
        .catch(error => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];
              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "done";
  };
};


export const addClmLineAdj = (params, index) => {
  return async dispatch => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true
    });
    if (spin) {
      return axios
        .post(URL.ADD_CLAIM_LINE_ADJUDICATION_ADJUSTMENT, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
        .then(response => {
          dispatch({ type: ActionTypes.CLAIM_LINE_ADJUDICATION_ADJUSTMENT, payload: response.data, index: index  });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return response.data;
        })
        .catch(error => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];
              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return error.response.data
        });
    }
    return "done";
  };
};
export const updateClmLineAdj = (params, index) => {
  return async dispatch => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true
    });
    if (spin) {
      return axios
        .post(URL.UPDATE_CLAIM_LINE_ADJUDICATION_ADJUSTMENT, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
        .then(response => {
          dispatch({ type: ActionTypes.CLAIM_LINE_ADJUDICATION_ADJUSTMENT, payload: response.data, index: index  });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return response.data;
        })
        .catch(error => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];
              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return error.response.data
        });
    }
    return "done";
  };
};

export const deleteClmLineAdj = (params, index) => {
  return async dispatch => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true
    });
    if (spin) {
      return axios
        .post(URL.DELETE_CLAIM_LINE_ADJUDICATION_ADJUSTMENT, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
        .then(response => {
          dispatch({ type: ActionTypes.CLAIM_LINE_ADJUDICATION_ADJUSTMENT, payload: response.data, index: index });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return response.data;
        })
        .catch(error => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];
              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return error.response.data
        });
    }
    return "done";
  };
};