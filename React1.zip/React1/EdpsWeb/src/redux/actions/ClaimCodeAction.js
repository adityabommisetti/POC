import * as ActionTypes from "../../constants/actionConstants/applActionValues";
import * as URL from "../../services/API_URL";
import axios from "../../utils/axios";


function postRequest(API_URL, body, Success_Action) {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .post(API_URL, body, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            dispatch({ type: Success_Action, payload: response.data });
          } else {
            dispatch({ type: Success_Action, payload: { data: [] } });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return response.data;
        })
        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          dispatch({ type: Success_Action, payload: { data: [] } });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];
              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return (error.response.data);
        });
    }
    return "done";
  };
};

export const getClmConditionCd = (searchVO) => {
  return postRequest(URL.FETCH_CLAIM_CONDITION, searchVO, ActionTypes.CLAIM_CONDITION_CODE);
};

// export const getClmConditionCd = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.FETCH_CLAIM_CONDITION, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_CONDITION_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//         });
//     }
//     return "done";
//   };
// };

export const addClmConditionCd = (searchVO) => {
  return postRequest(URL.ADD_CLAIM_CONDITION, searchVO, ActionTypes.CLAIM_CONDITION_CODE);
};

// export const addClmConditionCd = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.ADD_CLAIM_CONDITION, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_CONDITION_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return (error.response.data);
//         });
//     }
//     return "done";
//   };
// };

export const deleteClmConditionCd = (searchVO) => {
  return postRequest(URL.DELETE_CLAIM_CONDITION, searchVO, ActionTypes.CLAIM_CONDITION_CODE);
};

// export const deleteClmConditionCd = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.DELETE_CLAIM_CONDITION, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_CONDITION_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return (error.response.data);
//         });
//     }
//     return "done";
//   };
// };

export const updateClmConditionCd = (searchVO) => {
  return postRequest(URL.UPDATE_CLAIM_CONDITION, searchVO, ActionTypes.CLAIM_CONDITION_CODE);
};


// export const updateClmConditionCd = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.UPDATE_CLAIM_CONDITION, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_CONDITION_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data;
//         });
//     }
//     return "done";
//   };
// };

export const getDiagnosisCode = (searchVO) => {
  return postRequest(URL.FETCH_CLAIM_DIAGNOSIS, searchVO, ActionTypes.CLAIM_DIAGNOSIS_CODE);
};

// export const getDiagnosisCode = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.FETCH_CLAIM_DIAGNOSIS, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_DIAGNOSIS_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data;
//         });
//     }
//     return "done";
//   };
// };

export const addDiagnosisCode = (searchVO) => {
  return postRequest(URL.ADD_CLAIM_DIAGNOSIS, searchVO, ActionTypes.CLAIM_DIAGNOSIS_CODE);
};

// export const addDiagnosisCode = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.ADD_CLAIM_DIAGNOSIS, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_DIAGNOSIS_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data;
//         });
//     }
//     return "done";
//   };
// };

export const deleteDiagnosisCode = (searchVO) => {
  return postRequest(URL.DELETE_CLAIM_DIAGNOSIS, searchVO, ActionTypes.CLAIM_DIAGNOSIS_CODE);
};

// export const deleteDiagnosisCode = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.DELETE_CLAIM_DIAGNOSIS, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_DIAGNOSIS_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data;
//         });
//     }
//     return "done";
//   };
// };

export const updateDiagnosisCode = (searchVO) => {
  return postRequest(URL.UPDATE_CLAIM_DIAGNOSIS, searchVO, ActionTypes.CLAIM_DIAGNOSIS_CODE);
};

// export const updateDiagnosisCode = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.UPDATE_CLAIM_DIAGNOSIS, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_DIAGNOSIS_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data;
//         });
//     }
//     return "done";
//   };
// };

export const getClmProcedureCd = (searchVO) => {
  return postRequest(URL.FETCH_CLAIM_PROCEDURECODE, searchVO, ActionTypes.CLAIM_PROCEDURE_CODE);
};

// export const getClmProcedureCd = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.FETCH_CLAIM_PROCEDURECODE, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_PROCEDURE_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data;
//         });
//     }
//     return "done";
//   };
// };

export const addClmProcedureCd = (searchVO) => {
  return postRequest(URL.ADD_CLAIM_PROCEDURECODE, searchVO, ActionTypes.CLAIM_PROCEDURE_CODE);
};

// export const addClmProcedureCd = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.ADD_CLAIM_PROCEDURECODE, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_PROCEDURE_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data
//         });
//     }
//     return "done";
//   };
// };


export const updateClmProcedureCd = (searchVO) => {
  return postRequest(URL.UPDATE_CLAIM_PROCEDURECODE, searchVO, ActionTypes.CLAIM_PROCEDURE_CODE);
};

// export const updateClmProcedureCd = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.UPDATE_CLAIM_PROCEDURECODE, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_PROCEDURE_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data
//         });
//     }
//     return "done";
//   };
// };

export const deleteClmProcedureCd = (searchVO) => {
  return postRequest(URL.DELETE_CLAIM_PROCEDURECODE, searchVO, ActionTypes.CLAIM_PROCEDURE_CODE);
};

// export const deleteClmProcedureCd = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.DELETE_CLAIM_PROCEDURECODE, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_PROCEDURE_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data
//         });
//     }
//     return "done";
//   };
// };

export const getOccurrenceSpan = (searchVO) => {
  return postRequest(URL.FETCH_CLAIM_OCCURRENCE_SPAN, searchVO, ActionTypes.CLAIM_OCCURRENCE_SPAN_CODE);
};

// export const getOccurrenceSpan = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.FETCH_CLAIM_OCCURRENCE_SPAN, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_OCCURRENCE_SPAN_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data;
//         });
//     }
//     return "done";
//   };
// };

export const addOccurrenceSpan = (searchVO) => {
  return postRequest(URL.ADD_CLAIM_OCCURRENCE_SPAN, searchVO, ActionTypes.CLAIM_OCCURRENCE_SPAN_CODE);
};

// export const addOccurrenceSpan = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.ADD_CLAIM_OCCURRENCE_SPAN, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_OCCURRENCE_SPAN_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data;
//         });
//     }
//     return "done";
//   };
// };

export const updateOccurrenceSpan = (searchVO) => {
  return postRequest(URL.UPDATE_CLAIM_OCCURRENCE_SPAN, searchVO, ActionTypes.CLAIM_OCCURRENCE_SPAN_CODE);
};

// export const updateOccurrenceSpan = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.UPDATE_CLAIM_OCCURRENCE_SPAN, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_OCCURRENCE_SPAN_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data;
//         });
//     }
//     return "done";
//   };
// };

export const deleteOccurrenceSpan = (searchVO) => {
  return postRequest(URL.DELETE_CLAIM_OCCURRENCE_SPAN, searchVO, ActionTypes.CLAIM_OCCURRENCE_SPAN_CODE);
};

// export const deleteOccurrenceSpan = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.DELETE_CLAIM_OCCURRENCE_SPAN, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_OCCURRENCE_SPAN_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data;
//         });
//     }
//     return "done";
//   };
// };

export const getValue = (searchVO) => {
  return postRequest(URL.FETCH_CLAIM_VALUE_CODE, searchVO, ActionTypes.CLAIM_VALUE_CODE);
};

// export const getValue = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.FETCH_CLAIM_VALUE_CODE, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_VALUE_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data
//         });
//     }
//     return "done";
//   };
// };

export const addValue = (searchVO) => {
  return postRequest(URL.ADD_CLAIM_VALUE_CODE, searchVO, ActionTypes.CLAIM_VALUE_CODE);
};

// export const addValue = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.ADD_CLAIM_VALUE_CODE, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_VALUE_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data
//         });
//     }
//     return "done";
//   };
// };

export const updateValue = (searchVO) => {
  return postRequest(URL.UPDATE_CLAIM_VALUE_CODE, searchVO, ActionTypes.CLAIM_VALUE_CODE);
};

// export const updateValue = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.UPDATE_CLAIM_VALUE_CODE, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_VALUE_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data
//         });
//     }
//     return "done";
//   };
// };

export const deleteValue = (searchVO) => {
  return postRequest(URL.DELETE_CLAIM_VALUE_CODE, searchVO, ActionTypes.CLAIM_VALUE_CODE);
};

// export const deleteValue = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.DELETE_CLAIM_VALUE_CODE, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_VALUE_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data
//         });
//     }
//     return "done";
//   };
// };

export const getOccurrence = (searchVO) => {
  return postRequest(URL.FETCH_CLAIM_OCCURRENCE, searchVO, ActionTypes.CLAIM_OCCURRENCE_CODE);
};

// export const getOccurrence = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.FETCH_CLAIM_OCCURRENCE, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_OCCURRENCE_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data;
//         });
//     }
//     return "done";
//   };
// };

export const addOccurrence = (searchVO) => {
  return postRequest(URL.ADD_CLAIM_OCCURRENCE, searchVO, ActionTypes.CLAIM_OCCURRENCE_CODE);
};

// export const addOccurrence = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.ADD_CLAIM_OCCURRENCE, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_OCCURRENCE_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data;
//         });
//     }
//     return "done";
//   };
// };

export const updateOccurrence = (searchVO) => {
  return postRequest(URL.UPDATE_CLAIM_OCCURRENCE, searchVO, ActionTypes.CLAIM_OCCURRENCE_CODE);
};

// export const updateOccurrence = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.UPDATE_CLAIM_OCCURRENCE, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_OCCURRENCE_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data;
//         });
//     }
//     return "done";
//   };
// };

export const deleteOccurrence = (searchVO) => {
  return postRequest(URL.DELETE_CLAIM_OCCURRENCE, searchVO, ActionTypes.CLAIM_OCCURRENCE_CODE);
};

// export const deleteOccurrence = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.DELETE_CLAIM_OCCURRENCE, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_OCCURRENCE_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data;
//         });
//     }
//     return "done";
//   };
// };

export const getTreatment = (searchVO) => {
  return postRequest(URL.FETCH_CLAIM_TREATMENT, searchVO, ActionTypes.CLAIM_TREATMENT_CODE);
};

// export const getTreatment = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.FETCH_CLAIM_TREATMENT, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_TREATMENT_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data;
//         });
//     }
//     return "done";
//   };
// };

export const addTreatment = (searchVO) => {
  return postRequest(URL.ADD_CLAIM_TREATMENT, searchVO, ActionTypes.CLAIM_TREATMENT_CODE);
};

// export const addTreatment = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.ADD_CLAIM_TREATMENT, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_TREATMENT_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data;
//         });
//     }
//     return "done";
//   };
// };

export const updateTreatment = (searchVO) => {
  return postRequest(URL.UPDATE_CLAIM_TREATMENT, searchVO, ActionTypes.CLAIM_TREATMENT_CODE);
};

// export const updateTreatment = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.UPDATE_CLAIM_TREATMENT, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_TREATMENT_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data;
//         });
//     }
//     return "done";
//   };
// };

export const deleteTreatment = (searchVO) => {
  return postRequest(URL.DELETE_CLAIM_TREATMENT, searchVO, ActionTypes.CLAIM_TREATMENT_CODE);
};

// export const deleteTreatment = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.DELETE_CLAIM_TREATMENT, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_TREATMENT_CODE, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data;
//         });
//     }
//     return "done";
//   };
// };

export const getClmExtCauseCd = (searchVO) => {
  return postRequest(URL.FETCH_CLAIM_EXT_CAUSE_INJURY, searchVO, ActionTypes.CLAIM_EXT_CAUSE_INJURY);
};

// export const getClmExtCauseCd = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.FETCH_CLAIM_EXT_CAUSE_INJURY, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_EXT_CAUSE_INJURY, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data
//         });
//     }
//     return "done";
//   };
// };

export const addClmExtCauseCd = (searchVO) => {
  return postRequest(URL.ADD_CLAIM_EXT_CAUSE_INJURY, searchVO, ActionTypes.CLAIM_EXT_CAUSE_INJURY);
};

// export const addClmExtCauseCd = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.ADD_CLAIM_EXT_CAUSE_INJURY, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_EXT_CAUSE_INJURY, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data
//         });
//     }
//     return "done";
//   };
// };

export const updateClmExtCauseCd = (searchVO) => {
  return postRequest(URL.UPDATE_CLAIM_EXT_CAUSE_INJURY, searchVO, ActionTypes.CLAIM_EXT_CAUSE_INJURY);
};

// export const updateClmExtCauseCd = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.UPDATE_CLAIM_EXT_CAUSE_INJURY, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_EXT_CAUSE_INJURY, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data
//         });
//     }
//     return "done";
//   };
// };

export const deleteClmExtCauseCd = (searchVO) => {
  return postRequest(URL.DELETE_CLAIM_EXT_CAUSE_INJURY, searchVO, ActionTypes.CLAIM_EXT_CAUSE_INJURY);
};

// export const deleteClmExtCauseCd = params => {
//   return async dispatch => {
//     const spin = await dispatch({
//       type: ActionTypes.SET_SPINNER,
//       payload: true
//     });
//     if (spin) {
//       return axios
//         .post(URL.DELETE_CLAIM_EXT_CAUSE_INJURY, params, { headers: { "x-auth-token": localStorage.getItem("token") } })
//         .then(response => {
//           dispatch({ type: ActionTypes.CLAIM_EXT_CAUSE_INJURY, payload: response.data });
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return response.data;
//         })
//         .catch(error => {
//           dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
//           return error.response.data
//         });
//     }
//     return "done";
//   };
// };
