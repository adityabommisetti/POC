import "./App.css";
import "../src/utils/DatePicker";
import "./assets/css/react-confirm-alert.css";
import "./assets/css/spinner.css";

import React, { Component } from "react";
import {
  getUserInfo,
  loginAction,
  logoutAction
} from "./redux/actions/loginAction";

import { BrowserRouter, Switch } from "react-router-dom";
import Error from "./components/UI/404"
import HomePage from "./hoc/HomePage";
import LoginPage from './LoginPage';
import Modal from "./components/UI/Modal/Modal";
import { NotificationContainer } from "react-notifications";
import axios from './utils/axios';
import { connect } from "react-redux";
import styles from "./assets/styles/style";
import { withStyles } from "@material-ui/core/styles";
import {Maintenence} from "./components/UI/Maintenence";

class App extends Component {


  constructor(props) {
    super(props);

    this.state = {
      userName: "",
      password: "",
      authenticated: true,
      errorMsg: "",
      statusCode: "",
      maintenence: false

    };

    let object = this;
    axios.interceptors.response.use(
      function (response) {
        var token = response.headers["x-auth-token"];
        //update the token - renow token case -JWT
        if (token) {
          localStorage.setItem("token", "Bearer " + token);
        }

        return response;
      },
      function (error) {
        if (!error.response) {
          object.serverDown();
        }
        const statusCode = error.response.status;
        if (statusCode === 403) {
          const msg = error.response.data.message;
          object.handleError(msg, statusCode);
        }

        return Promise.reject(error);
      }
    );
  };

  serverDown = () => {
    this.setState({ maintenence: true });
  };

  handleError = (msg, statusCode) => {
    this.setState({
      closePopup: true,
      userName: "",
      password: "",
      message: msg,
      statusCode: statusCode
    });
  };

  handleOnBlurFieldChange = (event) => {
    let value = event.target.value.trim();
    let name = event.target.name;
    if (name === "DOB" && value.length === 8) {
      value = value.replace(/[^0-9]/g, "").trim();
      value = value.replace(/^(\d{2})/, "$1/").trim();
      value = value.replace(/\/(\d{2})/, "/$1/").trim();
      value = value.replace(/(\d)\/(\d{4}).*/, "$1/$2").trim();
    }

    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value.trim(),
      },
      collapseSearch: false,
    }));
    this.props.searchAttributes({ applicationSearch: this.state.searchVo });
  };
 

  handleChange = e => {
    this.setState({
      [e.target.name]: e.target.value
    });
  };

  modalClosed = async () => {
    await this.setState({ closePopup: false });

    if (this.state.statusCode === 403 && this.state.closePopup === false) {
      //window.close();
      await localStorage.clear();
      process.env.NODE_ENV === "development"
        ? window.location.replace("/")
        : window.close();
    }
  };

  loginHandler = e => {
    e.preventDefault();
    const userName = this.state.userName;
    const password = this.state.password;

    let body = {
      userId: userName.toUpperCase(),
      pwd: password
    };
    this.props.loginAction(body);
  };

  logout = async () => {
    this.setState({
      userName: "",
      password: ""
    });
    await this.props.logoutAction();
    window.location.replace("/");
  };

  async componentDidMount() {
    if (localStorage.getItem("token")) {
      await this.props.getUserInfo();
    }
    this.setupBeforeUnloadListener();
  }

  onWindowClose = () => {
    this.logout();
  };

  setupBeforeUnloadListener = () => {
    window.addEventListener("beforeunload", (ev) => {
      ev.preventDefault();
      return this.onWindowClose();
    });
  };

  render() {
    const { isLoading, loginData } = this.props;
    const isAuthenticated = loginData.authenticated;
    const isProdDeploy = process.env.REACT_APP_ROUTER_BASE;


    const authPage = isProdDeploy ? (
      <div></div>
    ) : (
        <LoginPage
          id="login"
          loginHandler={this.loginHandler}
          userName={this.state.userName}
          password={this.state.password}
          handleChange={this.handleChange}
          errorMsg={loginData.errorMsg}
        />
      );


      return (
        <React.Fragment>
          {
            <Modal
              dialogTitle=""
              message={this.state.message}
              show={this.state.closePopup}
              modalClosed={() => {
                this.modalClosed();
              }}
            ></Modal>
          }
  
          {isLoading ? <div id="cover-spin" /> : null}
  
          <NotificationContainer />
  
          <BrowserRouter basename={process.env.REACT_APP_ROUTER_BASE || ""}>
            <Switch>
              {this.state.maintenence ? <Maintenence /> : null}
  
              {isAuthenticated ? <HomePage logout={this.logout} /> : authPage}
            </Switch>
          </BrowserRouter>
        </React.Fragment>
      );
    }
  }
const mapStateToProps = state => {
  return {
    loginData: state.loginData,
    isLoading: state.spinner.isLoading
  };
};
const mapDispatchToProps = {
  getUserInfo,
  loginAction,
  logoutAction,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(App));
