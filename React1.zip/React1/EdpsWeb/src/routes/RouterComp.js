import React, { Suspense } from 'react';
import { Redirect, Route, Switch } from 'react-router-dom';
import DashboardRoute from '../components/SideMenu/DashboardRoute';
import ChartManagementRoute from '../components/SideMenu/chartManagementRoute';
import ChartRejectAnalysis from '../components/SideMenu/chartRejectAnalysis';
import EdpsManagementRoute from '../components/SideMenu/edpsManagementRoute';
import RejectAnalysisRoute from '../components/SideMenu/rejectAnalysisRoute';
import FileManagement from '../components/SideMenu/fileManagement';
import UserDoc from '../components/UserDoc';
import Help from '../components/Help';
import CircularIndeterminate from '../utils/CircularProgress';


const Routers = () => {

  return (
    <React.Fragment>
      <Switch>
      <Route path='/dashboard' render={()=><Suspense fallback={<CircularIndeterminate />}><DashboardRoute/> </Suspense>} />
      <Route path='/encounter' render={()=><Suspense fallback={<CircularIndeterminate />}><EdpsManagementRoute/> </Suspense>} />
      <Route path='/reject' render={()=><Suspense fallback={<CircularIndeterminate />}><RejectAnalysisRoute/> </Suspense>} />
      <Route path='/chart' render={()=><Suspense fallback={<CircularIndeterminate />}><ChartManagementRoute/> </Suspense>} />
      <Route path='/chartReject' render={()=><Suspense fallback={<CircularIndeterminate />}><ChartRejectAnalysis/> </Suspense>} />
      <Route path='/userDoc' render={()=><Suspense fallback={<CircularIndeterminate />}><UserDoc/> </Suspense>} />
      <Route path='/file' render={()=><Suspense fallback={<CircularIndeterminate />}><FileManagement/> </Suspense>} />
      <Route path='/help' render={()=><Suspense fallback={<CircularIndeterminate />}><Help/> </Suspense>} />
       <Redirect from='/'  to="/dashboard" />  
      </Switch>     
      </React.Fragment>
  )
}

export default Routers;


