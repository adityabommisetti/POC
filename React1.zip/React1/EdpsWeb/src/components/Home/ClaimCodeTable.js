import { withStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import React, { Component } from 'react';
import { styles } from '../../assets/styles/DataTableStyle';
import InputField from "./../UI/InputField";

class ClaimTable extends Component {
    constructor(props) {
        super(props);
        this.state = {
            byPassVariable: "instRiskDiagFlag"
        }
    }
    render() {
        const { classes, updateData, addData, header, tableName } = this.props;
        const { byPassVariable } = this.state;
        return (
            <div className={classes.tableWrapper}>

                <Table className={classes.table}>
                    <TableHead className={classes.thead}>
                        <TableRow>
                            <TableCell className={classes.headerCell} colSpan={header.length} align="center" >
                                {tableName}
                            </TableCell>
                        </TableRow>
                        <TableRow className={classes.headRow}>
                            {header.map((headerEle, i) => (
                                <TableCell align='left' className={classes.headerCell} key={i}>
                                    {headerEle.label}
                                </TableCell>
                            ))}
                        </TableRow>
                    </TableHead>

                    <TableBody className={classes.tbody} >
                        {updateData && updateData.length > 0 ?
                            (updateData.map((genericDetail, j) => (
                                <TableRow>
                                    {header.map((genericKey, p) => (

                                        <TableCell
                                            key={p}
                                            align='left'
                                            className={classes.tableCell}
                                        >
                                            {genericKey.key !== "" ?
                                                <div style={{"marginTop":"-13px"}}>
                                                    <InputField
                                                        name={genericKey.key}
                                                        id={genericKey.key + j + p}
                                                        placeholder={genericKey.date ? "MM/DD/YYYY" : null}
                                                        className="form-field"
                                                        disabled={genericKey.key === byPassVariable || (this.props.disabled || j !== this.props.index)}
                                                        onClick={genericKey.date ? this.props.handleDates(j, this.props.updateTargetVo) : null}
                                                        maxLength={genericKey.maxlength}
                                                        value={genericDetail[genericKey.key]}
                                                        onChange={this.props.handlechangeUpdate(genericKey.key, this.props.updateTargetVo)}
                                                    />
                                                    {(this.props.validator && j === this.props.index) && (genericKey.key !== byPassVariable) ?
                                                        <div className={classes.validationMessage}>
                                                            {this.props.validator.message(
                                                                genericKey.key,
                                                                genericDetail[genericKey.key],
                                                                genericKey.date ? "required|date_format" : "required"
                                                            )}
                                                        </div> : null}
                                                </div>
                                                :
                                                (this.props.editable ?
                                                    <React.Fragment>
                                                        <button type="button" class="btn btn-primary"
                                                            onClick={(e) => { this.props.handleEdit(genericDetail, j, e) }}
                                                        >
                                                            {j !== this.props.index ? "Update" : "Save"}
                                                        </button>
                                                        <button type="button" class="btn btn-secondary"
                                                            onClick={(e) => { this.props.handleDelete(genericDetail, j, e) }}
                                                            style={{display:(genericDetail.diagnosisType==="BK" || 
                                                            genericDetail.diagnosisType==="ABK")
                                                            ? "none":""}}
                                                        >
                                                            {j !== this.props.index ? "Delete" : "Cancel"}
                                                        </button>
                                                    </React.Fragment>
                                                    : null)
                                            }

                                        </TableCell>))}
                                </TableRow>))) : "NO DATA FOUND"}
                    </TableBody>
                </Table>
                {this.props.editable ?
                    <Table className={classes.table}>
                        <TableHead className={classes.thead}>
                            <TableRow className={classes.headRow}>
                                {header.map((headerEle, i) => (
                                    headerEle.key !== byPassVariable ?
                                        <TableCell align='left' className={classes.headerCell} key={i}>
                                            {headerEle.label}
                                        </TableCell> : null
                                ))}
                            </TableRow>
                        </TableHead>
                        <TableBody className={classes.tbody} >
                            <TableRow>
                                {header.map((genericKey, p) => (
                                    genericKey.key !== byPassVariable ?
                                        <TableCell
                                            key={p}
                                            align='left'
                                            className={classes.tableCell}
                                        >
                                            {genericKey.key !== "" ?
                                                <div style={{"marginTop":"-13px"}}>
                                                    <InputField
                                                        name={genericKey.key}
                                                        id={genericKey.key + p}
                                                        placeholder={genericKey.date ? "MM/DD/YYYY" : null}
                                                        className="form-field"
                                                        onClick={genericKey.date ? this.props.handleDates(genericKey.key, 0, this.props.addTargetVo) : null}
                                                        maxLength={genericKey.maxlength}
                                                        value={addData[genericKey.key]}
                                                        onChange={this.props.handlechangeUpdate([genericKey.key], this.props.addTargetVo)}
                                                    />
                                                    {this.props.validator && this.props.index === "" ?
                                                        <div className={classes.validationMessage}>
                                                            {this.props.validator.message(
                                                                genericKey.key,
                                                                addData[genericKey.key],
                                                                (addData[genericKey.key] === "BK" || addData[genericKey.key] === "ABK") 
                                                                ? "principleCode"
                                                                : (genericKey.date ? "required|date_format" : "required")
                                                            )}
                                                        </div>
                                                        : null}
                                                </div>
                                                :
                                                <React.Fragment>
                                                    <div style = {{marginRight:"5rem"}}>
                                                    <button class="btn btn-secondary"
                                                        onClick={(e) => this.props.handleAdd(e)}>
                                                        Add
                                                </button></div>
                                                
                                                </React.Fragment>
                                            }
                                        </TableCell>
                                        : null))}
                            </TableRow>
                        </TableBody>
                    </Table> : null}
            </div>
        );
    }
}

export default withStyles(styles)(ClaimTable);

