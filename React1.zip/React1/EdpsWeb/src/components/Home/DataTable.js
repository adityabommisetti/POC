import React, { Component } from 'react';
//import TablePagination from "@material-ui/core/TablePagination";
import { TablePagination } from '@material-ui/core';
// import formatTimeStamp, { formatFullTimeStamp } from "../../utils/Utils";
import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Input from "@material-ui/core/Input";
import InputAdornment from "@material-ui/core/InputAdornment";
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import { withStyles } from "@material-ui/core/styles";
// import PrintSearchExpot from "./PrintSearchExport";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableFooter from "@material-ui/core/TableFooter";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Tooltip from "@material-ui/core/Tooltip";
import classNames from 'classnames';
import isEmpty from "lodash/isEmpty";
import orderBy from "lodash/orderBy";
import { CSVLink } from "react-csv";
import { styles } from "../../assets/styles/DataTableStyle";
import ExportExcel from '../../utils/ExportExcelComponent';
import Pagination from "../UI/Pagination";

const invertDirection = {
  asc: "desc",
  desc: "asc",
};

class DataTable extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedRow: 0,
      search: "",
      colToSort: "",
      sortDir: "desc",
      page: 0,
      rowsPerPage: this.props.rowsPerPage,
      anchorEl: null,
      exportData: "",
      mobileMoreAnchorEl: null,
      radio: "current",
      index: 0,
      flag: this.props.flag,
      mbrSearch: false,
      sortClick: false,
      selectedPage: 0
    };
  }

  componentDidMount() {
    if (this.props.errorCdTable) {
      this.setState({
        rowsPerPage: parseInt(this.props.data.length)
      })
    }
  }

  async UNSAFE_componentWillReceiveProps(nextProps) {
    const pageNo = Math.floor(nextProps.index / nextProps.rowsPerPage);
    const selectedRow = nextProps.index % nextProps.rowsPerPage;
    if (this.props.searchTable && !this.props.flag) {
      this.setState({
        page: pageNo,
        selectedRow: selectedRow,
        rowsPerPage: parseInt(nextProps.rowsPerPage),
        selectedPage: pageNo,
      })
    } else if (this.props.searchTable && this.props.flag) {
      this.setState({
        page: 0,
        selectedRow: 0,
        colToSort: "",
        sortDir: "",
        selectedPage: 0,
        rowsPerPage: parseInt(nextProps.rowsPerPage)
      })
    } else if (this.props.errorCdTable) {
      this.setState({
        rowsPerPage: parseInt(nextProps.data.length)
      })
    }
  }
  exportDataFunc = async (data, all) => {
    if (all) {
      await this.props.getExportData(true);
      const data = this.props.allExportData
      this.setState({
        exportData: data.slice(),
        radio: 'all',
        displayMessage: true
      })
    } else {
      await this.props.getExportData(false);
      const data = this.props.allExportData
      await this.setState({
        displayMessage: false,
        exportData: data.slice(),
        radio: 'current'
      });
    }
  }

  handleSort = async (colName) => {
    const { selectedRow, rowsPerPage } = this.state
    await this.setState((prevState) => ({
      colToSort: colName,
      sortClick: true,
      sortDir:
        this.state.colToSort === colName
          ? invertDirection[this.state.sortDir]
          : "asc",
      selectedRow: 0
    }));
    await this.props.handleSort(this.state.colToSort, this.state.sortDir);
    await this.props.clicked(selectedRow, this.props.data[selectedRow], rowsPerPage);
  };

  rowSelect = async (rowIndex, data) => {
    const { page, rowsPerPage } = this.state;
    const selectedIndex = page * rowsPerPage + rowIndex;
    await this.setState({
      sortClick: false,
      selectedPage: page,
      selectedRow: rowIndex
    });
    await this.props.clicked(selectedIndex, data);
  };

  handleChangePage = async (page) => {
    if (typeof page !== "number" && this.state.search === "") {
      await this.props.fetchMore(this.state.page);
      return;
    }
    const index = page * this.state.rowsPerPage;
    const selectedIndex =
      page * this.state.rowsPerPage;
    this.setState({
      selectedPage: page,
      page,
    });
    if (!this.props.searchTable) {
      this.setState({
        selectedRow: 0
      })
    }
    if (this.state.search === "") {
      this.props.handleChangePage && this.props.handleChangePage(index);
      this.props.clickedFooter && this.props.clickedFooter(page);
      await this.props.clicked(selectedIndex, this.props.data[selectedIndex], this.state.rowsPerPage);
    }
  };

  handleChangeRowsPerPage = (event) => {
    this.setState({ page: 0, rowsPerPage: event.target.value });
    this.props.handleChangeRowsPerPage(event.target.value);
  };


  handleMobileMenuOpen = (event) => {
    this.setState({ mobileMoreAnchorEl: event.currentTarget });
  };
  handleMobileMenuClose = () => {
    this.setState({ mobileMoreAnchorEl: null });
  };
  handleMenuClose = () => {
    this.setState({ anchorEl: null });
    this.handleMobileMenuClose();
  };
  serachHandle = async (event) => {
    await this.setState({
      search: event.target.value,
    });
  };

  labelDisplayedRows = (from, to, count) => {
    const rowsPerPage = this.state.rowsPerPage;
    return (
      <React.Fragment>
        <span>
          Page :
        {Math.ceil(from / rowsPerPage) !== 0
            ? Math.ceil(from / rowsPerPage)
            : 1}{" "}
        - {}
          {count !== -1
            ? Math.ceil(count / rowsPerPage)
            : Math.ceil(to / rowsPerPage)}
        </span>
        <span>
          &nbsp;
        of {this.props.searchTable ?
            this.props.totalRecords :
            this.props.data.length}
        &nbsp;
        records
      </span>
      </React.Fragment>
    );
  };

  render() {
    const {
      classes,
      searchable,
      searchTable,
      exportHeader,
      exportAsExcel,
      removePagination,
      selectedRow,
      notClickable,
      rowsPerPageOptions
    } = this.props;

    const {
      rowsPerPage,
      page,
      exportData,
      selectedPage,
      mobileMoreAnchorEl
    } = this.state;

    const isMobileMenuOpen = Boolean(mobileMoreAnchorEl);
    let data = this.props.data;
    let isdataExist = data.length > 0;
    const header = this.props.header
    const search = this.state.search.toLowerCase();
    let msg = "NO DATA FOUND";
    if (this.props.msgChange) {
      msg = this.props.msgChange;
    }

    if (this.state.search) {
      data = data.filter((row) => {
        let flag = false;
        header.forEach((object) => {
          if (row[object.key]) {
            const value = row[object.key].toString().toLowerCase();
            if (value.includes(search.toLowerCase())) {
              flag = true;
            }
          }
        });
        return flag;
      });
    }
    return (
      <div style={{ width: "100%" }}>
        {searchable ? (
          <FormControl className={classes.paddingSearch}>
            <Input
              id="input-with-icon-adornment"
              value={search}
              placeholder="Search..."
              className={classes.search}
              onChange={this.serachHandle}
              width={"220px"}
              startAdornment={
                <InputAdornment position="start">
                  <i className="material-icons">search</i>
                </InputAdornment>
              }
            />
          </FormControl>
        ) : null}
        <div className={classes.exportDisplay}>
          {(exportAsExcel && data.length > 0) ? (
            <Tooltip title="Export">
              <i
                onClick={(e) => {
                  this.exportDataFunc(data, false);
                  this.handleMobileMenuOpen(e);
                }}
                className={classNames("fas fa-file-export", classes.exportIcon)} />
            </Tooltip>
          ) :
            exportAsExcel ? (<Tooltip title="Export"><i className={classNames("fas fa-file-export", classes.exportIcon)} /></Tooltip>) : null}


          <Menu
            classes={{
              paper: classes.placing,
            }}
            anchorEl={mobileMoreAnchorEl}
            anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
            transformOrigin={{ vertical: 'top', horizontal: 'right' }}
            open={isMobileMenuOpen}
            onClose={this.handleMenuClose}
          >
            {this.props.searchTable ?
              <MenuItem>
                <RadioGroup
                  row
                  value={this.state.radio}
                >
                  <FormControlLabel value="current" control={<Radio />} label="Current Page" onClick={() => this.exportDataFunc(data, false)} />
                  <FormControlLabel value="all" control={<Radio />} label="All Pages" onClick={() => this.exportDataFunc(data, true)} />
                </RadioGroup>
              </MenuItem> : null}
            <MenuItem className={classes.exportDemo}>
              <ExportExcel fileName='edps' dataSet={exportData} colName={exportHeader} classes={classes} />
              <CSVLink data={exportData} headers={exportHeader} separator={","} filename={"edps.txt"}>
                <i className={classNames("fa fa-file-text", classes.pdfIcon)} ></i>
              </CSVLink>
            </MenuItem>
            {this.state.displayMessage ?
              <MenuItem className={classes.displayMessage}>
                Export on all page option may take several minutes.
            </MenuItem> : null}
          </Menu>
        </div>
        <div
          className={classes.tableWrapper}
          style={{ width: this.props.width ? this.props.width : "100%" }}
        >
          <Table
            className={removePagination ? classes.tableModified : classes.table}
            id="maintable"
          >
            <TableHead className={classes.thead}>
              <TableRow className={classes.headRow}>
                {header.map((mbrCol, i) => (
                  <TableCell
                    align="left"
                    className={classes.headerCell}
                    key={i}
                  >
                    {searchTable && isdataExist &&
                      (mbrCol.key !== "encTypeDesc" || mbrCol.key !== "crClaimType") ?
                      (<div onClick={() => this.handleSort(mbrCol.key)}>
                        {mbrCol.label}
                        {this.state.colToSort === mbrCol.key
                          ? (
                            this.state.sortDir === "asc" ? (
                              <span class="sort"> &nbsp;&#8593;</span>
                            ) : (
                                <span class="sort"> &nbsp;&#8595;</span>
                              )
                          ) : (
                            <span class="sort sort-default"> &nbsp;&#8597;</span>
                          )}
                      </div>
                      ) : (
                        mbrCol.label
                      )}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>

            <TableBody className={classes.tbody}>
              {data.length < 1 && (
                <TableRow className={classes.row}>
                  <TableCell
                    name='cell'
                    colSpan={header.length}
                    className={classes.tableCell}
                  >
                    {msg}
                  </TableCell>
                </TableRow>
              )}
              {data
                .slice(
                  page * parseInt(rowsPerPage),
                  page * parseInt(rowsPerPage) + parseInt(rowsPerPage)
                )
                .map((genericDetail, j) => (
                  <TableRow
                    className={
                      selectedRow
                        ? classes.row
                        : this.state.selectedRow === j &&
                          page === selectedPage &&
                          !notClickable
                          ? classes.selectedrow
                          : classes.row
                    }
                    key={j}
                  >
                    {header.map((genericKey, p) => (
                      <TableCell
                        key={p}
                        style={this.props.errorTable ? { color: "red" } : null}
                        align="left"
                        className={classes.tableCell}
                        onClick={notClickable ? () => { } :
                          genericKey.key === "crClaimType" && genericDetail[genericKey.key] !== "" ?
                            () => this.props.crTypeSelect(genericDetail) :
                            () => this.rowSelect(j, data[page * rowsPerPage + j])}
                      >
                        {genericDetail[genericKey.key]}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
            </TableBody>
            {!removePagination && data.length > 0 ? (
              <TableFooter className={classes.footer}>
                <TableRow className={classes.footer}>
                  <TablePagination
                    className={classes.pagination}
                    rowsPerPageOptions={
                      rowsPerPageOptions ? rowsPerPageOptions : []
                    }
                    colSpan={
                      !this.props.activityTable
                        ? header.length
                        : header.length + 1
                    }
                    count={data.length}
                    rowsPerPage={rowsPerPage}
                    page={page}
                    SelectProps={{
                      native: true,
                    }}
                    classes={{
                      toolbar: classes.footer,
                    }}
                    labelDisplayedRows={({ from, to, count }) =>
                      this.labelDisplayedRows(from, to, count)
                    }
                    backIconButtonProps={this.props.searchTable &&
                      (this.props.totalRecords > data.length) &&
                      (!this.state.search)}
                    onChangePage={this.handleChangePage}
                    onChangeRowsPerPage={this.handleChangeRowsPerPage}
                    ActionsComponent={Pagination}
                    nextIconButtonProps={this.fetchMore1}
                  />
                </TableRow>
              </TableFooter>
            ) : null}
          </Table>
        </div>
      </div>
    );
  }
}

export default (withStyles(styles)(DataTable));