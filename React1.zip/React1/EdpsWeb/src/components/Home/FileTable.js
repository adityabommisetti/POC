import React, { Component } from 'react';
import { styles } from '../../assets/styles/DataTableStyle';
import { withStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableFooter from '@material-ui/core/TableFooter';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import classNames from "classnames";
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import RadioGroup from '@material-ui/core/RadioGroup';
import Tooltip from "@material-ui/core/Tooltip";
import isEmpty from "lodash/isEmpty";
import { exportToText, generate, exportToCsv, } from "../Home/ExportFunction";

class DashBoardTable extends Component {

    constructor(props) {
        super(props);
        this.state = {
            rowIndex: "",
            collapse: false,
            mobileMoreAnchorEl: null,
            anchorEl: null,
            allClaimCollapse: true,
            yearCollapse: []
        };
    }

    
    UNSAFE_componentWillReceiveProps(nextProps) {
        if (nextProps.data.yearData && !isEmpty(nextProps.data.yearData)) {
            this.setState({ yearCollapse: [] })
            nextProps.data.yearData.map((obj) => {
                this.setState(prevState => ({
                    yearCollapse: [...prevState.yearCollapse, false]
                }));
            });
        }
    }


    handleCollapse = (selectedIndex) => event => {
        event.preventDefault();
        let temp = this.state.yearCollapse;
        temp[selectedIndex] = !temp[selectedIndex]
        this.setState({
            yearCollapse: temp
        })
    };


    getLstDayOfMonFnc = (date) => {
        return new Date(date.getFullYear(), date.getMonth(), 0).getDate()
    }

    handleRecordSelect = (year, month, intrRecId, encType, splitFileStatus) => async (event) => {
        event.preventDefault();
        const dateYRMO = year.concat(month);
        const dataObj = {
            encType: encType,
            dateYRMO: dateYRMO,
            intrRecId: intrRecId,
            splitFileStatus: splitFileStatus
        }
        this.props.handleRecordSelect(dataObj);
    };
    handleMobileMenuOpen = event => {
        this.setState({ mobileMoreAnchorEl: event.currentTarget });
    };
    handleMenuClose = () => {
        this.setState({ anchorEl: null });
        this.handleMobileMenuClose();
    };
    handleMobileMenuClose = () => {
        this.setState({ mobileMoreAnchorEl: null });
    };

    render() {
        const { classes, data, removePagination, exportAsExcel } = this.props;
        const { mobileMoreAnchorEl } = this.state
        const isMobileMenuOpen = Boolean(mobileMoreAnchorEl);
        let tableHeader = (
            <React.Fragment>
                <TableCell align='left' className={classes.headerCell}>Pending</TableCell>
                <TableCell align='left' className={classes.headerCell}>Completed</TableCell>
                <TableCell align='left' className={classes.headerCell}>Failed</TableCell>
                <TableCell align='left' className={classes.headerCell}>Total</TableCell>
            </React.Fragment>
        );

        return (
            <React.Fragment>
                <div style={{ width: '100%', textAlign: 'center' }}>
                    <div className={classes.tableWrapper} style={{ width: this.props.width ? this.props.width : '100%' }}>
                            <React.Fragment>
                                {/*  <button id="btnExport" onClick={this.fnExcelReport}>EXPORT</button>*/}
                                <div className={classes.exportDisplay} style={{ textAlign: 'right', marginBottom: '10px' }}>


                                    {(exportAsExcel) ? (<i onClick={(e) => { this.handleMobileMenuOpen(e); }} className={classNames("fas fa-file-export", classes.exportIcon)} style={{ marginBottom: "10px" }} />) :
                                        exportAsExcel ? (<i className={classNames("fas fa-file-export", classes.exportIcon)} style={{ marginBottom: "10px" }} />) : null}


                                    <Menu
                                        classes={{
                                            paper: classes.placing,
                                        }}
                                        anchorEl={mobileMoreAnchorEl}
                                        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
                                        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
                                        open={isMobileMenuOpen}
                                        onClose={this.handleMenuClose}
                                    >
                                        <MenuItem>
                                            <RadioGroup
                                                row
                                                value={this.state.radio}
                                            >

                                                <Tooltip title="Excel">

                                                    <i className={classNames("fa fa-file-excel-o", classes.excelIcon)} onClick={exportToCsv}   ></i>
                                                </Tooltip>
                                                <Tooltip title="Pdf">
                                                    <i
                                                        className={classNames("fa fa-file-pdf-o", classes.pdfIcon)} onClick={generate} style={{}}></i>
                                                </Tooltip>
                                                <Tooltip title="Text">
                                                    <i
                                                        className={classNames("fa fa-file-text", classes.textIcon)} onClick={exportToText} style={{}}></i>
                                                </Tooltip>
                                            </RadioGroup>
                                        </MenuItem>
                                    </Menu>

                                </div>
                                <Table className={removePagination ? classes.tableModified : classes.table} id="table">
                                    <TableHead className={classes.thead} onCellClick={this.handleCellClick}>
                                    <TableRow className={classes.headRow}>
                                        <TableCell align='center' className={classes.headerCell} colSpan={6}>INSTITUTIONAL</TableCell>
                                        <TableCell align='center' className={classes.headerCell} colSpan={4}>PROFESSIONAL</TableCell>
                                        <TableCell align='center' className={classes.headerCell} colSpan={6}>DME</TableCell>
                                        <TableCell align='center'></TableCell>
                                    </TableRow>
                                        <TableRow className={classes.headRow}>
                                            <TableCell align='left' className={classes.headerCell}>All Claims</TableCell>
                                            {tableHeader}
                                            <TableCell></TableCell>
                                            {tableHeader}
                                            <TableCell></TableCell>
                                            {tableHeader}
                                            <TableCell></TableCell>
                                            <TableCell className={classes.headerCell}>Total</TableCell>
                                        </TableRow>
                                    </TableHead>
                                    {(Object.keys(data).length !== 0) ?
                                    <TableBody className={classes.tbody} >
                                        {data.map((yearData, i) => (
                                            <React.Fragment>
                                                <TableRow key={i} style={{ "backgroundColor": "#e9e9ea" }} onClick={this.handleCollapse(i)}>
                                                    <TableCell className={classes.tableCell}>
                                                    {this.state.yearCollapse[i] ?
                                                            <i className={classNames("fas fa-plus-circle", classes.icons)} /> :
                                                            <i className={classNames("fas fa-minus-circle", classes.icons)} />}
                                                        {yearData.yrMo}
                                                    </TableCell>
                                                    <TableCell className={classes.tableCell}>{yearData.instInProg}</TableCell>
                                                    <TableCell className={classes.tableCell}>{yearData.instCompl}</TableCell>
                                                    <TableCell className={classes.tableCell}>{yearData.instFailed}</TableCell>
                                                    <TableCell className={classes.tableCell}>{yearData.instTotal}</TableCell>
                                                    <TableCell></TableCell>
                                                    <TableCell className={classes.tableCell}>{yearData.profInProg}</TableCell>
                                                    <TableCell className={classes.tableCell}>{yearData.profCompl}</TableCell>
                                                    <TableCell className={classes.tableCell}>{yearData.profFailed}</TableCell>
                                                    <TableCell className={classes.tableCell}>{yearData.profTotal}</TableCell>
                                                    <TableCell></TableCell>
                                                    <TableCell className={classes.tableCell}>{yearData.dmeInProg}</TableCell>
                                                    <TableCell className={classes.tableCell}>{yearData.dmeCompl}</TableCell>
                                                    <TableCell className={classes.tableCell}>{yearData.dmeFailed}</TableCell>
                                                    <TableCell className={classes.tableCell}>{yearData.dmeTotal}</TableCell>
                                                    <TableCell></TableCell>
                                                    <TableCell className={classes.tableCell}>{yearData.allTotal}</TableCell>
                                                </TableRow>
                                                {yearData.monthlyLst.map((monthData, j) => (
                                                    <TableRow key={j} style={{
                                                        display: this.state.yearCollapse[i]
                                                            ? "none" : ""
                                                    }} >
                                                        {
                                                            <React.Fragment>
                                                                <TableCell className={classes.tableCell}>{monthData.yrMo}</TableCell>
                                                                
                                                                <TableCell className={classes.tableHover} onClick={this.handleRecordSelect(yearData.yrMo, monthData.yrMoVal, monthData.intrchgRecvrIdI, "I", "I")}>{monthData.instInProg}</TableCell>
                                                                <TableCell className={classes.tableHover} onClick={this.handleRecordSelect(yearData.yrMo, monthData.yrMoVal, monthData.intrchgRecvrIdI, "I", "C")}>{monthData.instCompl}</TableCell>
                                                                <TableCell className={classes.tableHover} onClick={this.handleRecordSelect(yearData.yrMo, monthData.yrMoVal, monthData.intrchgRecvrIdI, "I", "F")}>{monthData.instFailed}</TableCell>
                                                                <TableCell className={classes.tableCell}>{monthData.instTotal}</TableCell>
                                                                <TableCell></TableCell>
                                                                
                                                                <TableCell className={classes.tableHover} onClick={this.handleRecordSelect(yearData.yrMo, monthData.yrMoVal, monthData.intrchgRecvrIdI, "P", "I")}>{monthData.profInProg}</TableCell>
                                                                <TableCell className={classes.tableHover} onClick={this.handleRecordSelect(yearData.yrMo, monthData.yrMoVal, monthData.intrchgRecvrIdI, "P", "C")}>{monthData.profCompl}</TableCell>
                                                                <TableCell className={classes.tableHover} onClick={this.handleRecordSelect(yearData.yrMo, monthData.yrMoVal, monthData.intrchgRecvrIdI, "P", "F")}>{monthData.profFailed}</TableCell>
                                                                <TableCell className={classes.tableCell}>{monthData.profTotal}</TableCell>

                                                                <TableCell></TableCell>
                                                                <TableCell className={classes.tableHover} onClick={this.handleRecordSelect(yearData.yrMo, monthData.yrMoVal, monthData.intrchgRecvrIdI, "E", "I")}>{monthData.dmeInProg}</TableCell>
                                                                <TableCell className={classes.tableHover} onClick={this.handleRecordSelect(yearData.yrMo, monthData.yrMoVal, monthData.intrchgRecvrIdI, "E", "I")}>{monthData.dmeCompl}</TableCell>
                                                                <TableCell className={classes.tableHover} onClick={this.handleRecordSelect(yearData.yrMo, monthData.yrMoVal, monthData.intrchgRecvrIdI, "E", "I")}>{monthData.dmeFailed}</TableCell>
                                                                <TableCell className={classes.tableCell}>{monthData.dmeTotal}</TableCell>
                                                                <TableCell></TableCell>
                                                                <TableCell className={classes.tableCell}>{monthData.allTotal}</TableCell>
                                                            </React.Fragment>
                                                        }
                                                    </TableRow>
                                                ))}
                                            </React.Fragment>
                                        ))}
                                    </TableBody>: "NO DATA FOUND"}
                                    <TableFooter className={classes.footer}>
                                        <TableRow className={classes.footer}>
                                            <TableCell className={classes.tableCell} colSpan={18}></TableCell>
                                        </TableRow>
                                    </TableFooter>
                                </Table>
                            </React.Fragment>
                            
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default withStyles(styles)(DashBoardTable);

