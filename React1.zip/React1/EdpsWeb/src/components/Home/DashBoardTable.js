import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import { withStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableFooter from '@material-ui/core/TableFooter';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Tooltip from "@material-ui/core/Tooltip";
import classNames from "classnames";
import isEmpty from "lodash/isEmpty";
import React, { Component } from 'react';
import { CSVLink } from "react-csv";
import { connect } from "react-redux";
import { styles } from '../../assets/styles/DataTableStyle';
import { DASHBOARD_EXPORT } from "../../constants/header/encounterDetailsHeader";
import { dashBoardExport } from "../../redux/actions/encounterDetailsAction";
import ExportExcel from '../../utils/ExportExcelComponent';


class DashBoardTable extends Component {

    constructor(props) {
        super(props);
        this.state = {
            anchorEl: null,
            rowIndex: "",
            allClaimCollapse: true,
            mobileMoreAnchorEl: null,
            yearCollapse: []
        };
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        if (nextProps.data.yearlyList && !isEmpty(nextProps.data.yearlyList)) {
            this.setState({ yearCollapse: [] })
            nextProps.data.yearlyList.map((obj) => {
                this.setState(prevState => ({
                    yearCollapse: [...prevState.yearCollapse, true]
                }));
            });
        }
    }

    handleClaimExpansion = event => {
        event.preventDefault();
        let temp = this.state.yearCollapse
        this.state.yearCollapse.map((obj, key) => {
            temp[key] = true
        });
        this.setState({
            allClaimCollapse: !this.state.allClaimCollapse
        })
    }

    handleYearExpansion = (selectedIndex) => event => {
        event.preventDefault();
        let temp = this.state.yearCollapse;
        temp[selectedIndex] = !temp[selectedIndex]
        this.setState({
            yearCollapse: temp
        })
    };

    getLstDayOfMonFnc = (date) => {
        return new Date(date.getFullYear(), date.getMonth(), 0).getDate()
    };

    handleMonthSelect = (year, month, status, encType, submitterId, searchSummaryDateInd) => async (event) => {
        event.preventDefault();
        const fromDate = month + "/" + "01" + "/" + year;
        const toDate = month + "/" + this.getLstDayOfMonFnc(new Date(year, month, 1)) + "/" + year;
        this.props.handleMonthSelect(status, encType, submitterId, fromDate, toDate, searchSummaryDateInd);
    };
    handleMobileMenuOpen = async (event) => {
        this.setState({ mobileMoreAnchorEl: event.currentTarget });
        await this.props.dashBoardExport(this.props.searchVo);
    };
    handleMenuClose = () => {
        this.setState({ anchorEl: null });
        this.handleMobileMenuClose();
    };
    handleMobileMenuClose = () => {
        this.setState({ mobileMoreAnchorEl: null });
    };

    generate = (data, header) => {
        var jsPDF = require('jspdf');
        require('jspdf-autotable');
        var doc = new jsPDF();
        doc.autoTable(header, data);
        doc.save("Dashboard.pdf");
    };

    render() {
        const { mobileMoreAnchorEl } = this.state
        const { classes, data, removePagination, exportAsExcel, exportData } = this.props;
        const isMobileMenuOpen = Boolean(mobileMoreAnchorEl);

        let tableHeader = (
            <React.Fragment>
                <TableCell align='center' className={classes.headerCell}>Pending</TableCell>
                <TableCell align='center' className={classes.headerCell}>Accepted</TableCell>
                <TableCell align='center' className={classes.headerCell}>Failed</TableCell>
                <TableCell align='center' className={classes.headerCell}>Ignored</TableCell>
                <TableCell align='center' className={classes.headerCell}>Total</TableCell>
            </React.Fragment>
        );

        return (
            <React.Fragment>
                <div style={{ width: '100%', textAlign: 'center' }}>
                    <div className={classes.tableWrapper} style={{ width: this.props.width ? this.props.width : '100%' }}>

                        <React.Fragment>
                            <div className={classes.exportDisplay} style={{ textAlign: 'right', marginBottom: '10px' }}>
                                {(exportAsExcel) ? (
                                    <Tooltip title="Export">
                                        <i onClick={(e) => { this.handleMobileMenuOpen(e); }} className={classNames("fas fa-file-export", classes.exportIcon)} style={{ marginBottom: "10px" }} />
                                    </Tooltip>) :
                                    exportAsExcel ? (<Tooltip title="Export"><i className={classNames("fas fa-file-export", classes.exportIcon)} style={{ marginBottom: "10px" }} /></Tooltip>) : null}
                                <Menu
                                    classes={{
                                        paper: classes.placing,
                                    }}
                                    anchorEl={mobileMoreAnchorEl}
                                    anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
                                    transformOrigin={{ vertical: 'top', horizontal: 'right' }}
                                    open={isMobileMenuOpen}
                                    onClose={this.handleMenuClose}
                                >
                                    <MenuItem className={classes.exportDemo}>
                                        <ExportExcel fileName='Dashboard.xlsx' dataSet={exportData} colName={DASHBOARD_EXPORT} classes={classes} />
                                        <CSVLink data={exportData} headers={DASHBOARD_EXPORT} separator={","} filename={"Dashboard.txt"}>
                                            <i className={classNames("fa fa-file-text", classes.pdfIcon)} ></i>
                                        </CSVLink>

                                        {/* <i className={classNames("fa fa-file-pdf-o", classes.pdfIcon)} aria-hidden="true" onClick={() => this.generate(exportData, DASHBOARD_EXPORT)}></i>

                                        <Tooltip title="Text">
                                            <i className={classNames("fa fa-file-text", classes.textIcon)} onClick={exportToText}></i>
                                        </Tooltip> */}
                                    </MenuItem>
                                </Menu>
                            </div>
                            <Table className={removePagination ? classes.tableModified : classes.table} id="table">
                                <TableHead className={classes.thead} onCellClick={this.handleCellClick}>
                                    <TableRow className={classes.headRow}>
                                        <TableCell align='center' className={classes.headerCell} colSpan={1}></TableCell>
                                        <TableCell align='center' className={classes.headerCell} colSpan={5}>INSTITUTIONAL</TableCell>
                                        <TableCell align='center' className={classes.headerCell} colSpan={5}>PROFESSIONAL</TableCell>
                                        <TableCell align='center' className={classes.headerCell} colSpan={5}>DME</TableCell>
                                    </TableRow>
                                    <TableRow className={classes.headRow}>
                                        <TableCell align='center' className={classes.headerCell}>All Claims</TableCell>
                                        {tableHeader}
                                        {tableHeader}
                                        {tableHeader}
                                    </TableRow>
                                </TableHead>
                                {!isEmpty(data) ?
                                    <TableBody className={classes.tbody} >
                                        <TableRow onClick={this.handleClaimExpansion}>
                                            <TableCell className={classes.tableCell}>
                                                {(this.state.allClaimCollapse) ?
                                                    <i className={classNames("fas fa-minus-circle", classes.icons)} /> :
                                                    <i className={classNames("fas fa-plus-circle", classes.icons)} />}
                                                {"All Claims"}
                                            </TableCell>
                                            <TableCell align='center' className={classes.tableCell}>{data.instTotals.pending}</TableCell>
                                            <TableCell align='center' className={classes.tableCell}>{data.instTotals.accepted}</TableCell>
                                            <TableCell align='center' className={classes.tableCell}>{data.instTotals.rejected}</TableCell>
                                            <TableCell align='center' className={classes.tableCell}>{data.instTotals.ignored}</TableCell>
                                            <TableCell align='center' className={classes.tableCell}>{data.instTotals.total}</TableCell>

                                            <TableCell align='center' className={classes.tableCell}>{data.profTotals.pending}</TableCell>
                                            <TableCell align='center' className={classes.tableCell}>{data.profTotals.accepted}</TableCell>
                                            <TableCell align='center' className={classes.tableCell}>{data.profTotals.rejected}</TableCell>
                                            <TableCell align='center' className={classes.tableCell}>{data.profTotals.ignored}</TableCell>
                                            <TableCell align='center' className={classes.tableCell}>{data.profTotals.total}</TableCell>

                                            <TableCell align='center' className={classes.tableCell}>{data.dmeTotals.pending}</TableCell>
                                            <TableCell align='center' className={classes.tableCell}>{data.dmeTotals.accepted}</TableCell>
                                            <TableCell align='center' className={classes.tableCell}>{data.dmeTotals.rejected}</TableCell>
                                            <TableCell align='center' className={classes.tableCell}>{data.dmeTotals.ignored}</TableCell>
                                            <TableCell align='center' className={classes.tableCell}>{data.dmeTotals.total}</TableCell>
                                        </TableRow>
                                        {data.yearlyList.map((yearData, i) => (
                                            <React.Fragment>
                                                <TableRow key={i} style={{
                                                    display: (this.state.allClaimCollapse) ? "" : "none",
                                                    backgroundColor: '#e9e9ea'
                                                }} onClick={this.handleYearExpansion(i)}>
                                                    <TableCell className={classes.tableCell}>
                                                        {this.state.yearCollapse[i] ?
                                                            <i className={classNames("fas fa-minus-circle", classes.icons)} /> :
                                                            <i className={classNames("fas fa-plus-circle", classes.icons)} />}
                                                        {yearData.year}
                                                    </TableCell>
                                                    <TableCell align='center' className={classes.tableCell}>{yearData.instTotals.pending}</TableCell>
                                                    <TableCell align='center' className={classes.tableCell}>{yearData.instTotals.accepted}</TableCell>
                                                    <TableCell align='center' className={classes.tableCell}>{yearData.instTotals.rejected}</TableCell>
                                                    <TableCell align='center' className={classes.tableCell}>{yearData.instTotals.ignored}</TableCell>
                                                    <TableCell align='center' className={classes.tableCell}>{yearData.instTotals.total}</TableCell>

                                                    <TableCell align='center' className={classes.tableCell}>{yearData.profTotals.pending}</TableCell>
                                                    <TableCell align='center' className={classes.tableCell}>{yearData.profTotals.accepted}</TableCell>
                                                    <TableCell align='center' className={classes.tableCell}>{yearData.profTotals.rejected}</TableCell>
                                                    <TableCell align='center' className={classes.tableCell}>{yearData.profTotals.ignored}</TableCell>
                                                    <TableCell align='center' className={classes.tableCell}>{yearData.profTotals.total}</TableCell>

                                                    <TableCell align='center' className={classes.tableCell}>{yearData.dmeTotals.pending}</TableCell>
                                                    <TableCell align='center' className={classes.tableCell}>{yearData.dmeTotals.accepted}</TableCell>
                                                    <TableCell align='center' className={classes.tableCell}>{yearData.dmeTotals.rejected}</TableCell>
                                                    <TableCell align='center' className={classes.tableCell}>{yearData.dmeTotals.ignored}</TableCell>
                                                    <TableCell align='center' className={classes.tableCell}>{yearData.dmeTotals.total}</TableCell>
                                                </TableRow>
                                                {yearData.monthlyList.map((monthData, j) => (
                                                    <TableRow key={j} style={{
                                                        display: (this.state.yearCollapse[i] && this.state.allClaimCollapse)
                                                            ? "" : "none"
                                                    }}>
                                                        {
                                                            <React.Fragment>
                                                                <TableCell className={classes.tableCell}>{monthData.monthName}</TableCell>
                                                                <TableCell align='center' className={classes.tableHover} onClick={this.handleMonthSelect(yearData.year, monthData.month, "PEN", "I", this.props.submitterId, this.props.searchSummaryDateInd)}>{monthData.instTotals.pending}</TableCell>
                                                                <TableCell align='center' className={classes.tableHover} onClick={this.handleMonthSelect(yearData.year, monthData.month, "ACC", "I", this.props.submitterId, this.props.searchSummaryDateInd)}>{monthData.instTotals.accepted}</TableCell>
                                                                <TableCell align='center' className={classes.tableHover} onClick={this.handleMonthSelect(yearData.year, monthData.month, "FAL", "I", this.props.submitterId, this.props.searchSummaryDateInd)}>{monthData.instTotals.rejected}</TableCell>
                                                                <TableCell align='center' className={classes.tableHover} onClick={this.handleMonthSelect(yearData.year, monthData.month, "IGN", "I", this.props.submitterId, this.props.searchSummaryDateInd)}>{monthData.instTotals.ignored}</TableCell>
                                                                <TableCell align='center' className={classes.tableCell}>{monthData.instTotals.total}</TableCell>

                                                                <TableCell align='center' className={classes.tableHover} onClick={this.handleMonthSelect(yearData.year, monthData.month, "PEN", "P", this.props.submitterId, this.props.searchSummaryDateInd)}>{monthData.profTotals.pending}</TableCell>
                                                                <TableCell align='center' className={classes.tableHover} onClick={this.handleMonthSelect(yearData.year, monthData.month, "ACC", "P", this.props.submitterId, this.props.searchSummaryDateInd)}>{monthData.profTotals.accepted}</TableCell>
                                                                <TableCell align='center' className={classes.tableHover} onClick={this.handleMonthSelect(yearData.year, monthData.month, "FAL", "P", this.props.submitterId, this.props.searchSummaryDateInd)}>{monthData.profTotals.rejected}</TableCell>
                                                                <TableCell align='center' className={classes.tableHover} onClick={this.handleMonthSelect(yearData.year, monthData.month, "IGN", "P", this.props.submitterId, this.props.searchSummaryDateInd)}>{monthData.profTotals.ignored}</TableCell>
                                                                <TableCell align='center' className={classes.tableCell}>{monthData.profTotals.total}</TableCell>

                                                                <TableCell align='center' className={classes.tableHover} onClick={this.handleMonthSelect(yearData.year, monthData.month, "PEN", "E", this.props.submitterId, this.props.searchSummaryDateInd)}>{monthData.dmeTotals.pending}</TableCell>
                                                                <TableCell align='center' className={classes.tableHover} onClick={this.handleMonthSelect(yearData.year, monthData.month, "ACC", "E", this.props.submitterId, this.props.searchSummaryDateInd)}>{monthData.dmeTotals.accepted}</TableCell>
                                                                <TableCell align='center' className={classes.tableHover} onClick={this.handleMonthSelect(yearData.year, monthData.month, "FAL", "E", this.props.submitterId, this.props.searchSummaryDateInd)}>{monthData.dmeTotals.rejected}</TableCell>
                                                                <TableCell align='center' className={classes.tableHover} onClick={this.handleMonthSelect(yearData.year, monthData.month, "IGN", "E", this.props.submitterId, this.props.searchSummaryDateInd)}>{monthData.dmeTotals.ignored}</TableCell>
                                                                <TableCell align='center' className={classes.tableCell}>{monthData.dmeTotals.total}</TableCell>
                                                            </React.Fragment>
                                                        }
                                                    </TableRow>
                                                ))}
                                            </React.Fragment>
                                        ))}
                                    </TableBody> : "NO DATA FOUND"}
                                <TableFooter className={classes.footer}>
                                    <TableRow className={classes.footer}>
                                        <TableCell className={classes.tableCell} colSpan={18}></TableCell>
                                    </TableRow>
                                </TableFooter>
                            </Table>
                        </React.Fragment>
                    </div>
                </div>
            </React.Fragment >
        );
    }
}

const mapStateToProps = state => {
    return {
        exportData: state.encounterDetailsData.dashBoardExpData,
        isLoading: state.spinner.isLoading,
        dropdowns: state.dropdowns,
    };
};

const mapDispatchToProps = {
    dashBoardExport
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(withStyles(styles)(DashBoardTable));

