//**Text  **//
export const exportToText = () => {
    var filename = "table.txt"
    var data = [];
    var rows = document.querySelectorAll("table tr");
    for (var i = 0; i < rows.length; i++) {
        var row = [], cols = rows[i].querySelectorAll("td,th");
        for (var j = 0; j < cols.length; j++)
            row.push(cols[j].innerText);
        data.push(row.join(","));
    }
    downloadText(data.join("\n"), filename);
}

export const downloadText = (data, filename) => {
    var TextFile;
    var downloadLink;
    TextFile = new Blob([data], { type: "text/plain;charset=utf-8" });
    downloadLink = document.createElement("a");
    downloadLink.download = filename;
    downloadLink.href = window.URL.createObjectURL(TextFile);
    downloadLink.style.display = "none";
    document.body.appendChild(downloadLink);
    downloadLink.click();
}


//CSV
export const downloadCsV = (csv, filename) => {
    var csvFile;
    var downloadLink;
    csvFile = new Blob([csv], { type: "text/csv" });
    downloadLink = document.createElement("a");
    downloadLink.download = filename;
    downloadLink.href = window.URL.createObjectURL(csvFile);
    downloadLink.style.display = "none";
    document.body.appendChild(downloadLink);
    downloadLink.click();
}
export const exportToCsv = () => {
    var filename = "Edps.csv"
    var csv = [];
    var rows = document.querySelectorAll("table tr");
    for (var i = 0; i < rows.length-6;i++) {
        var row = [], cols = rows[i].querySelectorAll("td,th");
        for (var j = 0; j < cols.length; j++)
            row.push(cols[j].innerText);
        csv.push(row.join(","));
    }
    downloadCsV(csv.join("\n"), filename);
}


//Pdf Generate
export const generate = () => {
    var jsPDF = require('jspdf');
    require('jspdf-autotable');
    var doc = new jsPDF();
    doc.autoTable({ html: 'table' });
    doc.save("EDPS.pdf");
}

//Excel Not working Proper

export const fnExcelReport = () => {
    var i, j;
    var csv = "";
    var table = document.getElementById("table");
    var table_headings = table.children[0].children[0].children;
    var table_body_rows = table.children[1].children;
    var heading;
    var headingsArray = [];
    for (i = 0; i < table_headings.length; i++) {
        heading = table_headings[i];
        headingsArray.push('"' + heading.innerHTML + '"');
    }
    csv += headingsArray.join(',') + ";\n";
    var row;
    var columns;
    var column;
    var columnsArray;
    for (i = 0; i < table_body_rows.length; i++) {
        row = table_body_rows[i];
        columns = row.children;
        columnsArray = [];
        for (j = 0; j < columns.length; j++) {
            var column = columns[j];
            columnsArray.push('"' + column.innerHTML + '"');
        }
        csv += columnsArray.join(',') + "\n";
    }
    download("Dashboard.csv", csv);
}

export const download = (filename, text) => {
    var pom = document.createElement('a');
    pom.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(text));
    pom.setAttribute('download', filename);
    if (document.createEvent) {
        var event = document.createEvent('MouseEvents');
        event.initEvent('click', true, true);
        pom.dispatchEvent(event);
    }
    else {
        pom.click();
    }
}