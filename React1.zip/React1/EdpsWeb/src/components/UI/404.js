import React from "react";

const Error = () => {

    return (

        <div className="jumbotron">
            <div id="main">
                {/* <div class="fof">
                    <h1>Error 404</h1>
                </div> */}
            </div>
        </div>
    );
};

export default Error;
