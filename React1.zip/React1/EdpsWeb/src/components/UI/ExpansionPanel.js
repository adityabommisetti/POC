import MuiExpansionPanel from "@material-ui/core/ExpansionPanel";
import MuiExpansionPanelDetails from "@material-ui/core/ExpansionPanelDetails";
import MuiExpansionPanelSummary from "@material-ui/core/ExpansionPanelSummary";
import React from "react";
import { withStyles } from "@material-ui/core/styles";

const ExpansionPanel = withStyles({
  root: {
    border: "1px solid rgba(0, 0, 0, .125)",
    boxShadow: "none",
    marginBottom: "10px",
    minHeight: "42px !important",
    marginTop: "10px",
    "&:not(:last-child)": {
      marginBottom: "20px"
    },
    "&:before": {
      display: "none"
    },
    "&$expanded": {
      margin: "auto",
      minHeight: "42px !important",
      marginBottom: "10px",
      marginTop: "10px"
    }
  },
  expanded: {}
})(MuiExpansionPanel);

const ExpansionPanelSummary = withStyles({
  root: {
    backgroundColor: "rgba(204, 204, 204)",
    fontSize: "1.4em",
    lineHeight: ".8",

    minHeight: "42px !important",
    height: "28px",
    fontWeight: "500",
    "&$expanded": {
      minHeight: "42px !important"
    }
  },
  content: {
    "&$expanded": {}
  },
  expanded: {}
})(MuiExpansionPanelSummary);

const ExpansionPanelDetails = withStyles(theme => ({
  root: {
    backgroundColor: "rgba(236, 236, 236)",
    padding: "0.5em" // "1em",
  }
}))(MuiExpansionPanelDetails);

class CustomizedExpansionPanels extends React.PureComponent {
  state = {
    expanded: this.props.defaultCollapsed === true ? false : true
  };

  componentWillReceiveProps = nextProps => {
    this.setState({
      expanded: nextProps.defaultCollapsed === true ? false : true
    });
  };

  handleChange = async () => {
    await this.setState({
      expanded: !this.state.expanded
    });
    if (this.props.onClick) {
      this.props.onClick();
    }
  };
  render() {
    return (
      <div>
        <ExpansionPanel
          square
          expanded={this.state.expanded}
          onChange={this.handleChange}
        >
          <ExpansionPanelSummary
            className="PanelHeaderSection_ieTarget"
            aria-controls="panel1d-content"
            id="panel1d-header"
          >
            <React.Fragment>
              {this.state.expanded ? (
                <img
                  alt="arrowDown"
                  src={require("../../assets/images/arrow-down.png")}
                  style={{ height: "25px", marginTop: "8px" }}
                />
              ) : (
                  <img
                    alt="arrowUp"
                    src={require("../../assets/images/arrow-up.png")}
                    style={{ height: "25px", marginTop: "8px" }}
                  />
                )}
              <span style={{ color: "#053674", padding: ".5em .6em .6em 1em" }}>
                {this.props.summary}
              </span>
            </React.Fragment>
          </ExpansionPanelSummary>
          <ExpansionPanelDetails>{this.props.children}</ExpansionPanelDetails>
        </ExpansionPanel>
      </div>
    );
  }
}

export default CustomizedExpansionPanels;
