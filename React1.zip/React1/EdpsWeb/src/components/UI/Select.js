import React from "react";
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";
import Paper from "@material-ui/core/Paper";
import ReactSelect from "react-select";

export const Select = props => {
    var labelData = props.textFieldProps;

  return (
    <div className="label-container">
      <ReactSelect
      label={props.label}
      defaultValue={props.defaultValue ? props.defaultValue : null} 
      className={props.className}
      value={props.propertyName || " "}
      onChange={props.handleChange}
      components={props.components}
      options={props.options}
      margin="normal"
      classes={props.classes}
      isDisabled={props.isDisabled}
      onBlur={props.onBlur ? props.onBlur : null}
      textFieldProps={labelData}
      width={props.width}
    />
    </div>
    
  );
};

function inputComponent({ inputRef, ...props }) {
  return (
    <div style={{ width: props.widthContainer }} ref={inputRef} {...props} />
  );
}

export function Control(props) {
  const enableSelect = props.selectProps.classes.input + " enableSelect";
  const disableClass = props.selectProps.classes.input + " disabledSelect";
  return (
    <TextField
      style={{
        width: props.selectProps.width ? props.selectProps.width : "170px"
      }}
      id={props.id}
      InputProps={{
        inputComponent,
        inputProps: {
          className: props.isDisabled ? disableClass : enableSelect,
          style: {
            fontSize: "12px"
          },
          inputRef: props.innerRef,
          widthcontainer: props.selectProps.width
            ? props.selectProps.width
            : "180px",
          children: props.children,
          ...props.innerProps
        }
      }}
      {...props.selectProps.textFieldProps}
    />
  );
}

export function Option(props) {
  return (
    <MenuItem
      style={{ fontSize: "11px", padding: "0px 10px" }}
      selected={props.isFocused}
      component="span"
      {...props.innerProps}
    >
      {props.children}
    </MenuItem>
  );
}

export function Menu(props) {
  return (
    <Paper
      square
      style={{
        borderRadius: 5,
        maxHeight: 180,
        scrollBehavior: "smooth",
        overflow: "auto",
        marginTop: "0px",
        width: props.selectProps.width ? props.selectProps.width : "170px"
      }}
      className={props.selectProps.classes.paper}
      {...props.innerProps}
    >
      {props.children}
    </Paper>
  );
}

export function ValueContainer(props) {
  return (
    <div className={props.isDisabled ? 
      props.selectProps.classes.valueContainerEnabled:
      props.selectProps.classes.valueContainer}>
      {props.children}
    </div>
  );
}

export const components = {
  Control,
  Menu,
  ValueContainer,
  Option
};