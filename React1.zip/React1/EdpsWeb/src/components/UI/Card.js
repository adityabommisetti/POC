import MuiCard from "@material-ui/core/Card";
import { withStyles } from "@material-ui/core/styles";
import classNames from "classnames";
import React, { Component } from "react";
import Popup from "reactjs-popup";
import { Chart } from 'primereact/chart';
import isEmpty from "lodash/isEmpty";
import { Styles } from "../../assets/styles/DashBoardStyles";

const Card = withStyles({
    root: {
        border: "1px solid rgba(0, 0, 0, .125)",
        boxShadow: "1px",
        marginBottom: "6px",
        height: "320px !important",
        marginTop: "6px",
        cursor: "pointer",
    }
})(MuiCard);

class Dashlet extends Component {
    constructor() {
        super();
        this.state = {
            maxSize: false,
            openPopup: false,
        };
    }

    closePopup = () => {
        this.setState({ openPopup: false });
    };

    openPopup = () => {
        this.setState({ openPopup: true });
    };

    modalClosed = () => {
        this.setState({ closePopup: false });
    };

    render() {
        const { classes, data, label, onChartSelect } = this.props;
        console.log(data.labels)
        const options = {
            tooltips: {
                mode: 'index',
                intersect: false
            },
            responsive: true,
            scales: {
                xAxes: [{
                    stacked: true
                }],
                yAxes: [{
                    stacked: true
                }]
            },
            'onClick': function (e, item) {
                var activePoints = this.getElementAtEvent(e);
                var firstPoint = activePoints[0];
                if (firstPoint !== undefined) {
                    var axis = data.labels[firstPoint._index];
                    var tooltiplable = data.datasets[firstPoint._datasetIndex].label;
                    var value = data.datasets[firstPoint._datasetIndex].data[firstPoint._index];
                    onChartSelect(axis, tooltiplable, label)
                }
            }
            //'onClick': (evt, item) => this.props.onChartSelect(evt, item, this.props.label)
        };
        return (
            <div>
                <Card>
                    <div className={classes.header}>
                        {this.props.title}
                        <span
                            class={classNames("fa fa-expand", classes.maxIcon)}
                            onClick={this.openPopup}
                        />
                        <Popup
                            className={classes.mobileWidth}
                            modal
                            open={this.state.openPopup}
                            contentStyle={{ width: "85%", height: "80%" }}
                        >
                            {(close) => (
                                <div>
                                    <i className="close" onClick={this.closePopup}>
                                        &times;
                                    </i>
                                    <div className={classes.spacePop}>
                                        {!isEmpty(data.labels) ?
                                            <Chart type="bar" data={data} options={options} width="600px" />
                                            : <div className={classes.applicationSectionHeading}>
                                                <span>NO DATA FOUND</span>
                                            </div>
                                        }
                                        <h3 style={{ paddingLeft: "200px" }}>{label}</h3>
                                    </div>
                                </div>
                            )}
                        </Popup>
                        <div className={classes.spaceCard}>
                            <div className={classes.applicationSectionHeading}>
                                <span>{label}</span>
                            </div>
                            {!isEmpty(data.labels) ?
                                <Chart type="bar" data={data} options={options} width="420px" />
                                : <span>NO DATA FOUND</span>
                            }
                        </div>
                    </div>
                </Card>
            </div>
        );
    }
}
export default withStyles(Styles)(Dashlet);
