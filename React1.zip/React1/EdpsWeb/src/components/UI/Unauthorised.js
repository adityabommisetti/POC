import React from "react";

export const Unauthorised = () => {
  return (
    <div class="page-wrap d-flex flex-row align-items-center">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-12 text-center">
            <span class="display-1 d-block">Oops</span>
            <div class="mb-4 lead">
            <h4>
                    Unauthorised!</h4>
                
                <div>
                    <p>
                        You are not allowed to access this page.</p>
                    <p>
                    <img
                  src="/images/wipro-logo.png"
                  alt="Wipro logo"
                  className="wipro-logo-pwd"
                />   Wipro Team</p>
                        
                </div>
                <a href="/" class="btn btn-link">
              Back to Home
            </a>
                <div  class="text-center mainten">Please contact our Help Desk 
		<br/><i className ="fa fa-phone"></i>&nbsp;(877) 833-3499 
		<br/> Be sure to mention you are on the Medicare Support Services Website and the error you received.
	</div>
            </div>
             
          </div>
        </div>
      </div>
    </div>
  );
};
