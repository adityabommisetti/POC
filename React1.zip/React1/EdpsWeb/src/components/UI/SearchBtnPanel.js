import React from "react";
import Button from "@material-ui/core/Button";
import { withStyles } from "@material-ui/core/styles";

const styles = theme => ({
  buttonContainer: {
    position: "relative",
    display: "contents",
    verticalAlign: "middle",
    float: "right"
  },
  button: {
    margin: theme.spacing.unit,
    [theme.breakpoints.down("sm")]: {
      fontSize: "8px",
      width: "80px"
    },
    [theme.breakpoints.up("md")]: {
        marginTop: "18px"
      }
  }
});

const ButtonPanel = props => {

  return (
    <div className={props.classes.buttonContainer}>
      <Button
        variant="contained"
        color="primary"
        onClick={props.search}
        className={props.classes.button}
        id="searchButton"
      >
        Search
        </Button>
      <Button
        variant="contained"
        color="primary"
        onClick={props.reset}
        className={props.classes.button}
        id="resetButton"
      >
        Reset
        </Button>
    </div>
  );
};

export default withStyles(styles, { withTheme: true })(ButtonPanel);
