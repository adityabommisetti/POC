import React from 'react';

const InputField = (props) => {
  var astrix = "";
  if (props.required) {
    astrix = <span class='imp'>*</span>
  }

  return (

    <span className="label-container">
      <label
        style={{ color: props.color ? props.color : '#053674', maxWidth: '200px', marginBottom: '0', lineHeight: props.lineHeight ? props.lineHeight : 'normal' }}
        htmlFor={props.details}>
        {props.label}{astrix}
      </label>
      <br />
      <input
        name={props.name}
        id={props.id ? props.id : props.name}
        className="form-field"
        type={props.type ? props.type : 'text'}
        value={props.value}
        cols={props.cols ? props.cols : null}
        rows={props.rows ? props.rows : null}
        rowsmax={props.rowsMax ? props.rowsMax : null}
        onChange={props.onChange}
        onClick={props.onClick ? props.onClick : null}
        disabled={props.disabled}
        maxLength={props.maxLength ? props.maxLength : null}
        style={{ width: props.width ? props.width : '155px' }}
        required={props.req}
        placeholder={props.placeholder ? props.placeholder : null}
        onBlur={props.onBlur ? props.onBlur : null}

      />
    </span>

  )
}


export default InputField;