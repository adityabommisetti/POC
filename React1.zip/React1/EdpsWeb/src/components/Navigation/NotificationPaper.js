import { Badge } from '@material-ui/core'
import ClickAwayListener from "@material-ui/core/ClickAwayListener";
import Divider from '@material-ui/core/Divider';
import Drawer from '@material-ui/core/Drawer';
import Grow from "@material-ui/core/Grow";
import IconButton from '@material-ui/core/IconButton';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import NotificationsIcon from '@material-ui/icons/Notifications';
import Paper from "@material-ui/core/Paper";
import Poppers from "@material-ui/core/Popper";
import React from "react";
import classNames from 'classnames';
import { withStyles } from '@material-ui/core/styles';
import { getNotificationData } from "../../redux/actions/loginAction";
import { connect } from "react-redux";
import * as ActionTypes from "../../constants/actionConstants/applActionValues";
import Typography from "@material-ui/core/Typography";
import Modal from "../../components/UI/Modal/Modal";

const styles = theme => ({
  notificationPanel: {
    width: '240px',
    maxWidth: '240px',
    fontSize: "13px",
    transition: '.3s linear all',
    fontWeight: "400",
    backgroundColor: '#fff',
    color: '#3a3434',
    boxShadow: '0 3px 8px rgba(0, 0, 0, .25)',
    overflow: 'auto',
    height: '250px',
    "&::before": {
      content: "''",
      display: 'block',
      position: 'absolute',
      width: 0,
      height: 0,
      color: 'transparent',
      border: '10px solid black',
      borderColor: 'transparent transparent white',
      marginTop: '-30px',

    }


  },

  notificationContent: {
    fontSize: '12px',
  },
  showDesktop: {
    display: 'block',

    [theme.breakpoints.down('sm')]: {
      display: 'none',
    }
  },

  showMobile: {
    display: 'none',
    [theme.breakpoints.down('sm')]: {

      display: 'block'

    },
  },

  notificationsBody: {
    padding: '23px 0px 0px 0px !important',
    minHeight: '250px',
  },

  notificationTitle: {
    fontWeight: 'bold',
    padding: '8px',
    fontSize: '13px',
    backgroundColor: '#4278a6',
    position: 'fixed',
    width: '100%',
    color: 'white',
    zIndex: '1000',
    textAlign: 'center'
  }  ,
  noData:{
    margin:"20px",
     fontSize:"15px",
     fontWeight:"bold",
     fontFamily:"Lato, sans-serif",
     color: "rgba(39, 108, 155, 1)",
  },

  list: {
    width: 250,
  },
  fullList: {
    width: 'auto',
  },



  notificationItem: {
    cursor: 'pointer',

    padding: "10px 10px",
    //borderRadius: "2px",
    borderStyle: 'solid',
    marginTop: '1px',
    //  backgroundColor:'#d6dae0',
    WebkitTransition: "all 150ms linear",
    MozTransition: "all 150ms linear",
    OTransition: "all 150ms linear",
    MsTransition: "all 150ms linear",
    transition: "all 150ms linear",
    display: "block",
    clear: "both",
    height: '35px',
    //lineHeight: "1.012",
    wordWrap: "break-word",
     "&:hover": {
       color: 'white',
       background: '-webkit-linear-gradient(top, #7abcff 0%,#60abf8 44%,#4096ee 100%)',
  },
},
container:{
  width: "400px"
},

seen: {
  backgroundColor: "#FFF",
  fontWeight: "100 !important",

},
unseen: {
  fontWeight: "bold !important",
  backgroundColor: "#c8cfd2"    
}
});


class HeaderLinks extends React.Component {
  state = {
    open: false,
    right: false,
    data: [],
    closePopup: false
  };
  handleToggle = () => {
    this.setState(state => ({ open: !state.open }));
  };
  componentDidMount() {
    this.notify();
    let id = setInterval(
      () => this.notify(),
      ActionTypes.NOTIFICATION_TIMEDOUT
    );
    this.setState({ id: id });
  }
  notify = async () => {
    await this.props.getNotificationData();
    let data = this.props.notificationData;

    for (let i = 0; i < data.length; i++) {
      let test = { user_viewed: false };
      Object.assign(data[i], test);
   
    }
    await this.setState({ data: [...this.state.data, ...data] });
  
  };


  toggleDrawer = (side, open) => () => {
    this.setState({
      [side]: open,
    });
  };


 handleClose = event => {
    // if (this.anchorEl.contains(event.target)) {
    //   return;
    // }
    if (
      event.offsetX > event.target.clientWidth ||
      event.offsetY > event.target.clientHeight
    ) {
      return;
    }

    this.setState({ open: false, right: false });
  };
  modalClosed = async () => {
    this.setState({ closePopup: false });
    await this.setState({ open: true, right: false });
  };


  notificationSeen = clickedIndex => {
    let notiList = [...this.state.data];

    const newData = notiList.map((notificaiton, index) => {
      if (index === clickedIndex) {
        notificaiton.user_viewed = true;
        this.setState({
          message: notificaiton.msgDesc,
          closePopup: true
        });
      }
      return notificaiton;
    });

    this.setState({
      data: newData
    });
  };

  render() {

    const { classes } = this.props;

    const { open } = this.state;
    const seenData = this.state.data.filter(res => res.user_viewed === false);
    const notificationCount = seenData.length;

    const NotiData = (
     
      <React.Fragment>
      <List>      
            
        {this.state.data.length > 0 ?
         
        (this.state.data.map((notification, index) => (
         
          <ListItem
            button
            key={notification.notifTimeStamp}
            onClick={() => this.notificationSeen(index)}
            className={classNames(classes.notificationItem, {
              [classes.seen]: notification.user_viewed,
              [classes.unseen]: !notification.user_viewed
            })}
          >
            <ListItemText            
              disableTypography
        primary={<Typography type="body2" 
        className={classNames( {
          [classes.primaryTextSeen]: notification.user_viewed,
          [classes.primaryText]: !notification.user_viewed
        })}
        >{notification.msgTitle}</Typography>}
        secondary={<Typography type="body2" className={classes.secondaryText}> {notification.notifTimeStamp}</Typography>}
        />
          </ListItem>
        )))
       
        : <p className={classes.noData}>
          NO NOTIFICATIONS FOUND </p>}
      </List>
      </React.Fragment>
    );

    const sideList = <div className={classes.list}>{NotiData}</div>;


    return (
      <React.Fragment>
        <Modal
          dialogTitle="Notification"
          message={this.state.message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <IconButton
          color={this.state.open === false ? "inherit" : "primary"}
          onClick={this.handleToggle}
          buttonRef={node => {
            this.anchorEl = node;
          }}
          justicon={(window.innerWidth > 959).toString()}
          simple={(!(window.innerWidth > 959)).toString()}
          aria-owns={open ? "menu-list-grow" : null}
          aria-haspopup="true"
        >
          <Badge
            badgeContent={notificationCount}
            color="secondary"
            className={classes.showMobile}
          >
            <NotificationsIcon onClick={this.toggleDrawer("right", true)} />
            <Drawer
              anchor="right"
              open={this.state.right}
              onClose={this.toggleDrawer("right", false)}
            >
              <div tabIndex={0} role="button">
                <div className={classes.notificationTitle}>Notifications</div>
                <Divider />
                <br />
                
                 {sideList}
              
                
                
              </div>
            </Drawer>
          </Badge>

          <Badge
            badgeContent={notificationCount}
            color="secondary"
            className={classes.showDesktop}
          >
            <NotificationsIcon />
          </Badge>
        </IconButton>

        <Poppers
          className={classes.showDesktop}
          open={open}
          anchorEl={this.anchorEl}
          transition
          disablePortal
        >
          {({ TransitionProps, placement }) => (
            <Grow
              {...TransitionProps}
              id="menu-list-grow"
              style={{
                transformOrigin:
                  placement === "bottom" ? "center top" : "center bottom"
              }}
            >
              <div className={classes.container}>
                <Paper className={classes.notificationPanel}>
                  <ClickAwayListener onClickAway={this.handleClose}>
                    <div className={classes.notificationContainer}>
                      <div className={classes.notificationTitle}>
                        Notifications
                      </div>
                      <div className={classes.notificationsBody}>
                        {NotiData}
                      </div>
                    </div>
                  </ClickAwayListener>
                </Paper>
              </div>
            </Grow>
          )}
        </Poppers>
      </React.Fragment>
    );
  }
}
const mapStateToProps = state => {
  return {
    notificationData: state.notificationReducer.notificationData
  };
};

const mapDispatchToProps = {
  getNotificationData
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles, { withTheme: true })(HeaderLinks));

