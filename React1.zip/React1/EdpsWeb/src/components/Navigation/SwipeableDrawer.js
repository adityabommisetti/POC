import React from 'react';
import Divider from '@material-ui/core/Divider';
import classNames from 'classnames';
import Drawer from '@material-ui/core/Drawer';

export const MobileDrawer = (props) => {


  
  return (
  
  <Drawer 
    className={classNames(props.classes.drawer,
      props.classes.sectionMobile,
      {
        [props.classes.drawerOpen]: props.open,
        [props.classes.drawerClose]: !props.open,
      })}
    classes={{
      paper: classNames({
        [props.classes.drawerOpen]: props.open,
        [props.classes.drawerClose]: !props.open,
      })
    }}
    open={props.open}
    onClose={props.handler}>
    <div>
      <span style={{ display: 'flex' }}>
        <img src={props.logo} className={props.classes.wiproLogo} alt="Wipro Logo"/>
        <img src={props.hmkLogo} className={props.classes.customerLogo} alt="Customer Logo"/>
      </span>
      <Divider />
      {props.drawer}
    </div>
  </Drawer>
  )
}