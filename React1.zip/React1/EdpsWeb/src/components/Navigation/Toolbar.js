import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import NotificationPaper from './NotificationPaper';
import React from "react";
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import classNames from 'classnames';
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";

class ToolBar extends React.PureComponent {
  closeTab() {
    window.close();
  }

  render() {
    const { classes } = this.props;

    return (
      <Toolbar className={classes.root} classes={{ gutters: classes.gutters }}>
        <IconButton
          color="inherit"
          aria-label="Desktop drawer"
          className={classNames(classes.menuButton,
            classes.sectionDesktop
          )}
          onClick={this.props.handleDrawer}
        >
          <MenuIcon />
        </IconButton>

        <IconButton
          color="inherit"
          aria-label="Mobile drawer"
          onClick={this.props.toggleDrawer}
          className={classNames(classes.menuButton,
            classes.sectionMobile
          )}
        >
          <MenuIcon />
        </IconButton>
        <Typography variant="h6" color="inherit" noWrap>
          EDPS
    </Typography>



        <div className={classes.grow} />
        <div className={classes.rightAlign}>
          <i className="icon-user-1"></i> Welcome {this.props.loginData.loginVo.customerName}-{this.props.loginData.loginVo.userId}

          <IconButton color="inherit" onClick={this.closeTab}>

            <a
              title='Home'><i className="icon-home"></i></a>

          </IconButton>

          <NotificationPaper />
          {
            process.env.NODE_ENV === "development" ?
              <IconButton color="inherit" onClick={this.props.logout}>


                <i className="fas fa-sign-out-alt" title='Log Out'></i>

              </IconButton>
              : null
          }
        </div>
      </Toolbar>
    )
  }
}

const mapStateToProps = state => {
  return {
    loginData: state.loginData
  };
};
export default withRouter(connect(mapStateToProps)(ToolBar));
