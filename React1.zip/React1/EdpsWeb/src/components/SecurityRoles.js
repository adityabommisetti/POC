import React, { Component } from "react";
import { withStyles } from "@material-ui/core/styles";
import InputField from './UI/InputField';
import Paper from "@material-ui/core/Paper";
import { Select, Control, Menu, Option, ValueContainer } from "./UI/Select";
import { SECURITY_ROLES_DATA as DATA, SECURITY_DATA} from "../constants/staticData/SecurityRolesStaticData";
import { Styles } from "../assets/styles/Theme";
import Button from '@material-ui/core/Button';
import Radio from '@material-ui/core/Radio';
import RadioButtonUncheckedIcon from '@material-ui/icons/RadioButtonUnchecked';
import RadioButtonCheckedIcon from '@material-ui/icons/RadioButtonChecked';
import "../assets/css/icon.css";
import {
  SECURITY_ROLE_LIST
} from "../constants/staticData/SecurityRolesStaticData";

const components = {
  Control,
  Menu,
  ValueContainer,
  Option
};
class SecurityRoles extends Component {
  state = {
    data: DATA,
    securityVo: SECURITY_DATA[0],
    checked: -1
  };

  selectRow = index => {
    const data = [...this.state.data];
    const selectedVo = data[index];
    this.setState(() => ({
      letterVo: {
        ...selectedVo
      }
    }));
  };
  handleChangeSearchSelect = name => event => {
    let value = event.value;
    this.setState(prevState => ({
      securityVo:
      {
        ...prevState.securityVo,
        [name]: value
      },
    }))
  };
  handlechange = name => event => {
    
    let value = event.target.value;

    this.setState(prevState => ({
      securityVo:
      {
        ...prevState.securityVo,
        [name]: value

      },    
    }))
  };
  checked = (i) => {
     this.setState({
       checked : i,
     })
  }
  render() {
    const { classes } = this.props;

    return (
        <div>
      <Paper elevation={0} >
       
        <form autoComplete="off">
        <div class="panel-body">
       
          <div className={classes.securityContainer}>

         <div>

          <Select
                components={components}
                propertyName={SECURITY_ROLE_LIST.filter(
                  option => option.value === this.state.securityVo.userId
                )}
                options={SECURITY_ROLE_LIST}
                label="Choose user ID ..."
                textFieldProps={{
                  label: "User ID",
                  InputLabelProps: {
                    className: classes.label,
                    shrink: true
                  }
                }}
                className={classes.textFieldSelect}
                handleChange={this.handleChangeSearchSelect('userId')}
                isDisabled={false}
                classes={classes}
              />
              </div>
              <div>
             <InputField
              name="name"
              InputProps={{
                className: classes.textFont,
                inputProps: {
                  maxLength: 50
                }
              }}
              label="User Name"
              value={this.state.securityVo.userId}
              onChange={this.handlechange("userId")}
              disabled={false}
            />
            </div>
   
        <Button type="submit" variant="contained" color="primary"
          className={classes.button}>
          Update
       </Button>
       

       </div>

       <br/>
      <br/>
      </div>
      <div class="panel-body">
			<div class="form-panel">
			<fieldset class="label-container sr_box">
			<legend></legend>
      <Paper elevation={0} className={classes.paperCard}>
        {this.state.data.map((role, i) => (
      
     <div style={{textAlign: "left"}}>
      <Radio 
          classes={{root: classes.radioSpan}}
          checked = {this.state.checked === i}
          onClick = {() => {this.checked(i)}}
          icon={<RadioButtonUncheckedIcon classes={{fontSizeSmall: classes.radioButton}}fontSize="small" />}
          checkedIcon={<RadioButtonCheckedIcon classes={{fontSizeSmall: classes.radioButton}} fontSize="small" />}
        />
        <span className={classes.securityFormLabel}>{role.key} </span>
    
     </div>))}
     
      </Paper>
      </fieldset>
			</div>
			</div>
      
   
        </form>

      
      
    
      </Paper>

</div>

    );
  }
}

export default withStyles(Styles)(SecurityRoles);
