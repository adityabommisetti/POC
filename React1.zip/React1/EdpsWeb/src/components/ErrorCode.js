import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormLabel from "@material-ui/core/FormLabel";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import { withStyles } from "@material-ui/core/styles";
import RadioButtonCheckedIcon from '@material-ui/icons/RadioButtonChecked';
import RadioButtonUncheckedIcon from '@material-ui/icons/RadioButtonUnchecked';
import isEmpty from "lodash/isEmpty";
import React, { Component } from "react";
import { connect } from "react-redux";
import { Styles } from "../assets/styles/Theme";
import { ERRORCODE_EXPORT, ERROR_CODE } from '../constants/header/encounterDetailsHeader';
import { errorCodeSearch, errorCodeCriteria } from "../redux/actions/encounterDetailsAction";
import * as DateUtil from "./../utils/DatePicker";
import DataTable from "./Home/DataTable";
import ExpansionPanel from "./UI/ExpansionPanel";
import InputField from "./UI/InputField";
import SearchBtnPanel from "./UI/SearchBtnPanel";
import { components, Select } from "./UI/Select";
import { withRouter } from 'react-router';
import { compose } from 'redux';
import Datetime from "react-datetime";
import SimpleReactValidator from "simple-react-validator";
import { customValidations } from "../utils/CustomValidations";


const INITIAL_DATA = {
  submitterId: "",
  encType: "P",
  fromDateYrmo: ("01/").concat(new Date().getFullYear()),
  toDateYrmo: ("12/").concat(new Date().getFullYear()),
  searchSummaryDateInd: "0",
  claimType: "EN",
  pageValue: "1",
  errorCd: "",
  errorGroup: "",
  errorSource: ""
};

class Errorcode extends Component {
  constructor(props) {
    super(props);
    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format_month_year,
        date_after_month_year: customValidations.date_after_month_year
      },
    });
    this.state = {
      searchVo: { ...INITIAL_DATA },
      errorCodeList: null,
      location: this.props.history.location.pathname
    }
  };

  componentWillMount() {
    if (this.props.parentTab === "edpsManagement" || this.props.parentTab === "rejectAnalysis") {
      this.setState(prevState => ({
        searchVo: {
          ...prevState.searchVo,
          claimType: "EN"
        }
      }));
    }
    else {
      this.setState(prevState => ({
        searchVo: {
          ...prevState.searchVo,
          claimType: "CR"
        }
      }));
    }
  };

  async componentDidMount() {
    const { errorCodeEncounterCriteria, errorCodeChartCriteria, errorPayload } = this.props;
    let errorCriteria = (this.state.location === "/reject") ? errorCodeEncounterCriteria : errorCodeChartCriteria;
    if (!isEmpty(this.props.dropdowns)) {
      INITIAL_DATA.submitterId = !isEmpty(this.props.dropdowns.optionsSubmitters) ?
        this.props.dropdowns.optionsSubmitters[0].value : ""
      await this.setState(prevState => ({
        searchVo: {
          ...prevState.searchVo,
          "submitterId": !isEmpty(this.props.dropdowns.optionsSubmitters) ?
            this.props.dropdowns.optionsSubmitters[0].value : "",
        }
      }));
    }
    if (!isEmpty(errorCriteria)) {
      await this.setState(prevState => ({
        searchVo: {
          ...prevState.searchVo,
          submitterId: errorCriteria.submitterId,
          encType: errorCriteria.encType,
          fromDateYrmo: errorCriteria.fromDateYrmo,
          toDateYrmo: errorCriteria.toDateYrmo,
          errorSource: errorCriteria.errorSource,
          searchSummaryDateInd: errorCriteria.searchSummaryDateInd
        }
      }))
    }else if(!isEmpty(errorPayload)) {
      debugger
      await this.setState(prevState => ({
        searchVo: {
          ...prevState.searchVo,
          submitterId: errorPayload.submitterId,
          encType: errorPayload.encType,
          fromDateYrmo: errorPayload.fromDateYrmo,
          toDateYrmo: errorPayload.toDateYrmo,
          errorSource: errorPayload.errorSource,
          searchSummaryDateInd: errorPayload.searchSummaryDateInd
        }
      }))
    } 
    await this.props.errorCodeSearch(this.state.searchVo);
    this.setState({ errorCodeList: this.props.errorCodeList });
  };

  monthPicker = (selectedDate, field) => {
    if (selectedDate._d) {
      var date = new Date(selectedDate._d),
        mnth = ("0" + (date.getMonth() + 1)).slice(-2),
        selectedDate = [mnth, date.getFullYear()].join("/");
    } else {
      selectedDate = selectedDate.replace(/[^0-9]/g, "").trim();
      selectedDate = selectedDate.replace(/^(\d{2})/, "$1/");
      selectedDate = selectedDate.replace(/(\d)\/(\d{4}).*/, "$1/$2");
    }
    this.setState({
      ...this.state,
      searchVo: { ...this.state.searchVo, [field]: selectedDate },
    });
  };

  handleSearchFieldChange = name => event => {
    let value = event.target
      ? event.target.value.toUpperCase()
      : event.value.toUpperCase();
    this.setState(prevState => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value
      }
    }));
  };

  handleAlphaNumeric = (name) => e => {
    let value = e.target.value.replace(/[^-\w\s\']/g, "").toUpperCase();
    this.setState(prevState => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value
      }
    }));
  };

  handleDates = fieldId => {
    var self = this;
    DateUtil.getMonthDatePicker(fieldId).on("change", e => {
      self.setDate(e.target.name, e.target.value);
    });
  };

  setDate = (name, value) => {
    this.setState(prevState => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value
      }
    }));
  };

  search = async () => {
    if (!this.validator.allValid()) {
      this.validator.showMessages();
      this.forceUpdate();
    }
    else {
      await this.props.errorCodeCriteria(this.state.searchVo, this.state.location);
      await this.props.errorCodeSearch(this.state.searchVo);
      this.setState({ errorCodeList: this.props.errorCodeList });
    }
  };

  reset = async () => {
    await this.setState({ 
      searchVo: { 
        ...INITIAL_DATA,
        claimType: 
        (this.props.parentTab === "edpsManagement" || 
        this.props.parentTab === "rejectAnalysis")
        ? "EN" : "CR"
       }
     })
    this.props.errorCodeCriteria(this.state.searchVo, this.state.location);
  };


  getLstDayOfMonFnc = (date) => {
    return new Date(date.getFullYear(), date.getMonth(), 0).getDate()
  };

  selectRow = async (index) => {
    const data = this.props.errorCodeList[index];
    console.log(data);
    const month = data.formattedDateYrmo.substr(0, data.formattedDateYrmo.indexOf("/"));
    const year = data.formattedDateYrmo.substr(data.formattedDateYrmo.indexOf("/") + 1, data.formattedDateYrmo.length);
    const fromDate = month + "/" + "01" + "/" + year;
    const toDate = month + "/" + this.getLstDayOfMonFnc(new Date(year, month, 1)) + "/" + year;
    data.fromDate = fromDate;
    data.toDate = toDate;
    this.props.errorBoardSelect(data);
  }

  render() {
    const { classes, dropdowns } = this.props;
    const { searchVo, collapseSearch, errorCodeList } = this.state;
    console.log(dropdowns.cmsErrorGroup)
    console.log(dropdowns.complianceErrorGroup)
    console.log(searchVo.errorSource)

    return (
      <React.Fragment>
        {!isEmpty(dropdowns) ?
          <ExpansionPanel
            summary="Search"
            defaultCollapsed={collapseSearch}
          >
            <div className={classes.container} id="SearchPanel">
              <div>
                <Select
                  components={components}
                  defaultValue={dropdowns.optionsSubmitters[0]}
                  propertyName={dropdowns.optionsSubmitters.filter(
                    option =>
                      option.value === searchVo.submitterId
                  )}
                  options={dropdowns.optionsSubmitters}
                  label="Choose Submitter ID ..."
                  textFieldProps={{
                    id: "submitterId",
                    label: "Submitter ID",
                    InputLabelProps: {
                      className: classes.label,
                      shrink: true
                    }
                  }}
                  className={classes.textFieldSearch}
                  handleChange={this.handleSearchFieldChange("submitterId")}
                  classes={classes}
                />
              </div>
              <div>
                <Select
                  components={components}
                  propertyName={dropdowns.optionsEncType.filter(
                    option =>
                      option.value === searchVo.encType
                  )}
                  options={dropdowns.optionsEncType}
                  label="Choose Claim Type ..."
                  textFieldProps={{
                    id: "encType",
                    label: "Claim Type",
                    InputLabelProps: {
                      className: classes.label,
                      shrink: true
                    }
                  }}
                  className={classes.textFieldSearch}
                  handleChange={this.handleSearchFieldChange("encType")}
                  classes={classes}
                />
              </div>
              <div style={{ marginRight: "-40px" }}>
                <FormControl
                  component="fieldset"
                  className={classes.formControl}
                >
                  <FormLabel component="legend" className={classes.legend}></FormLabel>
                  <RadioGroup
                    name="searchSummaryDateInd"
                    className={classes.group}
                    value={searchVo.searchSummaryDateInd}
                    onChange={this.handleSearchFieldChange("searchSummaryDateInd")}
                  >
                    <FormControlLabel value="0" control={<Radio color="primary"
                      icon={<RadioButtonUncheckedIcon fontSize="small" />}
                      checkedIcon={<RadioButtonCheckedIcon fontSize="small" />}
                    />} label="Submission Date" />
                    <FormControlLabel value="1" control={<Radio color="primary"
                      icon={<RadioButtonUncheckedIcon fontSize="small" />}
                      checkedIcon={<RadioButtonCheckedIcon fontSize="small" />}
                    />} label="Service Date" />
                  </RadioGroup>
                </FormControl>
              </div>
              <div>
                <Select
                  components={components}
                  propertyName={dropdowns.optionsErrorSource.filter(
                    option =>
                      option.value === searchVo.errorSource
                  )}
                  options={dropdowns.optionsErrorSource}
                  label="Choose Status ..."
                  textFieldProps={{
                    id: "errorSource",
                    label: "Error Source",
                    InputLabelProps: {
                      className: classes.label,
                      shrink: true
                    }
                  }}
                  className={classes.textFieldSearch}
                  handleChange={this.handleSearchFieldChange("errorSource")}
                  classes={classes}
                />
              </div>
              <div>

                <Select
                  components={components}
                  propertyName={dropdowns.optionsErrorGroup.filter(
                    option =>
                      option.value === searchVo.errorGroup
                  )}   
                  options={searchVo.errorSource != "" ?(searchVo.errorSource === "CMS" ? dropdowns.cmsErrorGroup :
                   dropdowns.complianceErrorGroup  ) : dropdowns.optionsErrorGroup }   
                  // options={searchVo.errorSource === "CMS" ? dropdowns.cmsErrorGroup :
                  //   dropdowns.complianceErrorGroup }   
                  
                   label="Choose Error Group ..."
                  textFieldProps={{
                    id: "errorGroup",
                    label: "Error Group",
                    InputLabelProps: {
                      className: classes.label,
                      shrink: true
                    }
                  }}
                  
                  className={classes.textFieldSearch}
                  handleChange={this.handleSearchFieldChange("errorGroup")}
                  classes={classes}
                  
                />
              </div>
              <div>
                <InputField
                  name="errorCd"
                  label="Error Code"
                  maxLength={5}
                  value={searchVo.errorCd}
                  onChange={this.handleAlphaNumeric("errorCd")}
                />
                <div className={classes.validationMessage} />
              </div>
              <div>
                <label>From</label>
                <Datetime
                  onChange={(moment) => this.monthPicker(moment, "fromDateYrmo")}
                  value={searchVo.fromDateYrmo}
                  dateFormat="MM/YYYY"
                  closeOnSelect="true"
                  inputProps={{
                    placeholder: "MM/YYYY",
                    className: "monthPicker",
                    maxLength: 7,
                  }}
                  timeFormat={false}
                />
                <div className={classes.validationMessage}>
                  {this.validator.message(
                    "FromDate",
                    searchVo.fromDateYrmo,
                    "required|date_format"
                  )}
                </div>
              </div>
              <div>
                <label>To</label>
                <Datetime
                  onChange={(moment) => this.monthPicker(moment, "toDateYrmo")}
                  value={searchVo.toDateYrmo}
                  dateFormat="MM/YYYY"
                  closeOnSelect="true"
                  inputProps={{
                    placeholder: "MM/YYYY",
                    className: "monthPicker",
                    maxLength: 7,
                  }}
                  timeFormat={false}
                />
               <div className={classes.validationMessage}>
                  {this.validator.message(
                    "ToDate",
                    searchVo.toDateYrmo,
                    [
                      "required",
                      "date_format",
                      { date_after_month_year: searchVo.fromDateYrmo },
                    ]
                  )}
                </div>
              </div>
              <div>
                <SearchBtnPanel
                  search={this.search}
                  reset={this.reset}
                />
              </div>
            </div>
          </ExpansionPanel>
          : null}
        {errorCodeList !== null ?
          <ExpansionPanel summary="Error Codes List" >
            <DataTable
              data={errorCodeList}
              exportCurrent={errorCodeList}
              header={ERROR_CODE}
              exportHeader={ERRORCODE_EXPORT}
              fileName="Error_Code"
              exportAsExcel={true}
              errorCdTable
              clicked={this.selectRow}
            />
          </ExpansionPanel>
          : null}
      </React.Fragment>
    );
  }
}
const mapStateToProps = state => {
  return {
    errorCodeList: state.encounterDetailsData.errorCodeList,
    errorCodeEncounterCriteria: state.encounterDetailsData.errorCodeEncounterCriteria,
    errorCodeChartCriteria: state.encounterDetailsData.errorCodeChartCriteria,
    isLoading: state.spinner.isLoading,
    dropdowns: state.dropdowns,
  };
};

const mapDispatchToProps = {
  errorCodeSearch,
  errorCodeCriteria
};

export default compose(
  withRouter,
  withStyles(Styles),
  connect(mapStateToProps, mapDispatchToProps)
)(Errorcode);

