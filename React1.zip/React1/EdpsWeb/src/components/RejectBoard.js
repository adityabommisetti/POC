import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormLabel from "@material-ui/core/FormLabel";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import { withStyles } from "@material-ui/core/styles";
import RadioButtonCheckedIcon from '@material-ui/icons/RadioButtonChecked';
import RadioButtonUncheckedIcon from '@material-ui/icons/RadioButtonUnchecked';
import isEmpty from "lodash/isEmpty";
import React, { Component } from "react";
import { connect } from "react-redux";
import { withRouter } from 'react-router';
import { compose } from 'redux';
import { Styles } from "../assets/styles/Theme";
import { rejectBoardSearch, rejectBoardCriteria } from "../redux/actions/encounterDetailsAction";
import * as DateUtil from "./../utils/DatePicker";
import RejectBoardTable from "./Home/RejectBoardTable";
import ExpansionPanel from "./UI/ExpansionPanel";
import SearchBtnPanel from "./UI/SearchBtnPanel";
import { components, Select } from "./UI/Select";
import Datetime from "react-datetime";
import SimpleReactValidator from "simple-react-validator";
import { customValidations } from "../utils/CustomValidations";

const INITIAL_STATE = {
  submitterId: "",
  fromDateYrmo: ("01/").concat(new Date().getFullYear()),
  toDateYrmo: ("12/").concat(new Date().getFullYear()),
  searchSummaryDateInd: "0",
  claimType: ""
};

class RejectBoard extends Component {
  constructor(props) {
    super(props);
    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format_month_year,
        date_after_month_year: customValidations.date_after_month_year
      },
    });
    this.state = {
      rejectList: null,
      searchVo: { ...INITIAL_STATE },
      location: this.props.history.location.pathname
    };
  }


  async componentWillMount() {
    if (this.props.parentTab === "edpsManagement" || this.props.parentTab === "rejectAnalysis") {
      await this.setState(prevState => ({
        searchVo: {
          ...prevState.searchVo,
          claimType: "EN"
        }
      }));
    }
    else {
      await this.setState(prevState => ({
        searchVo: {
          ...prevState.searchVo,
          claimType: "CR"
        }
      }));
    }
  }

  async componentDidMount() {
    const { rejectBoardEncounterCriteria, rejectBoardChartCriteria } = this.props;
    let rejectBoardCriteria = this.props.history.location.pathname === "/reject" ?
      rejectBoardEncounterCriteria : rejectBoardChartCriteria;
    if (!isEmpty(rejectBoardCriteria)) {
      await this.setState({
        searchVo: { ...rejectBoardCriteria }
      })
      await this.props.rejectBoardSearch(this.state.searchVo);
      this.setState({
        rejectList: this.props.rejectBoardList
      });
    }
    else if ((!isEmpty(this.props.dropdowns)
      && this.state.searchVo.submitterId === "")
      && !isEmpty(this.props.rejectBoardList)) {
      await this.setState(prevState => ({
        searchVo: {
          ...prevState.searchVo,
          "submitterId": !isEmpty(this.props.dropdowns.optionsSubmitters) ?
            this.props.dropdowns.optionsSubmitters[0].value : "",
        }
      }));
      await this.props.rejectBoardSearch(this.state.searchVo);
      this.setState({
        rejectList: this.props.rejectBoardList
      });
    }
  }


  async UNSAFE_componentWillReceiveProps(nextProps) {

    if ((!isEmpty(nextProps.dropdowns)
      && this.state.searchVo.submitterId === "")
      && isEmpty(nextProps.rejectBoardList)) {
      await this.setState(prevState => ({
        searchVo: {
          ...prevState.searchVo,
          "submitterId": !isEmpty(nextProps.dropdowns.optionsSubmitters) ?
            nextProps.dropdowns.optionsSubmitters[0].value : ""
        }
      }));
      await this.props.rejectBoardSearch(this.state.searchVo, this.state.location);
      this.setState({
        rejectList: this.props.rejectBoardList
      });
    }
  }


  monthPicker = (selectedDate, field) => {
    if (selectedDate._d) {
      var date = new Date(selectedDate._d),
        mnth = ("0" + (date.getMonth() + 1)).slice(-2),
        selectedDate = [mnth, date.getFullYear()].join("/");
    } else {
      selectedDate = selectedDate.replace(/[^0-9]/g, "").trim();
      selectedDate = selectedDate.replace(/^(\d{2})/, "$1/");
      selectedDate = selectedDate.replace(/(\d)\/(\d{4}).*/, "$1/$2");
    }
    this.setState({
      ...this.state,
      searchVo: { ...this.state.searchVo, [field]: selectedDate },
    });
  };

  handleSearchFieldChange = name => event => {
    let value = event.target
      ? event.target.value.toUpperCase()
      : event.value.toUpperCase();
    this.setState(prevState => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value
      },
      collapseSearch: false
    }));
  };


  handleDates = fieldId => {
    var self = this;
    DateUtil.getMonthDatePicker(fieldId).on("change", e => {
      self.setDate(e.target.name, e.target.value);
    });
  };

  setDate = (name, value) => {
    this.setState(prevState => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value
      }
    }));
  };

  search = async () => {
    if (!this.validator.allValid()) {
      this.validator.showMessages();
      this.forceUpdate();
    }
    else {
      await this.props.rejectBoardCriteria(this.state.searchVo, this.state.location);
      await this.props.rejectBoardSearch(this.state.searchVo);
      this.setState({
        rejectList: this.props.rejectBoardList
      });
    }
  };

  reset = async () => {
    INITIAL_STATE.submitterId = !isEmpty(this.props.dropdowns.optionsSubmitters) ?
      this.props.dropdowns.optionsSubmitters[0].value : ""
    await this.setState({ 
      searchVo: { 
        ...INITIAL_STATE,
        claimType: 
        (this.props.parentTab === "edpsManagement" || 
        this.props.parentTab === "rejectAnalysis")
        ? "EN" : "CR"
       }
     });
    this.props.rejectBoardCriteria(this.state.searchVo, this.state.location);
  };

  render() {
    const { classes, dropdowns } = this.props;
    const { rejectList, searchVo, collapseSearch } = this.state;
    return (
      <React.Fragment>
        {Object.entries(dropdowns).length !== 0 ?
          <ExpansionPanel
            summary="Search"
            defaultCollapsed={collapseSearch}
          >
            <div className={classes.container} id="SearchPanel">
              <div>
                <Select
                  components={components}
                  propertyName={dropdowns.optionsSubmitters.filter(
                    option =>
                      option.value === searchVo.submitterId
                  )}
                  defaultValue={dropdowns.optionsSubmitters[0]}
                  options={dropdowns.optionsSubmitters}
                  label="Choose Submitter ID ..."
                  textFieldProps={{
                    id: "submitterId",
                    label: "Submitter ID",
                    InputLabelProps: {
                      className: classes.label,
                      shrink: true
                    }
                  }}
                  className={classes.textFieldSearch}
                  handleChange={this.handleSearchFieldChange("submitterId")}
                  classes={classes}
                />
              </div>
              <div style={{ marginRight: "-40px" }}>
                <FormControl
                  component="fieldset"
                  className={classes.formControl}
                >
                  <FormLabel component="legend" className={classes.legend}></FormLabel>
                  <RadioGroup
                    name="searchSummaryDateInd"
                    className={classes.group}
                    value={searchVo.searchSummaryDateInd}
                    onChange={this.handleSearchFieldChange("searchSummaryDateInd")}
                  >
                    <FormControlLabel value="0" control={<Radio color="primary"
                      icon={<RadioButtonUncheckedIcon fontSize="small" />}
                      checkedIcon={<RadioButtonCheckedIcon fontSize="small" />}
                    />} label="Submission Date" />
                    <FormControlLabel value="1" control={<Radio color="primary"
                      icon={<RadioButtonUncheckedIcon fontSize="small" />}
                      checkedIcon={<RadioButtonCheckedIcon fontSize="small" />}
                    />} label="Service Date" />
                  </RadioGroup>
                </FormControl>
              </div>
              <div>
                <label>From</label>
                <Datetime
                  onChange={(moment) => this.monthPicker(moment, "fromDateYrmo")}
                  value={searchVo.fromDateYrmo}
                  dateFormat="MM/YYYY"
                  closeOnSelect="true"
                  inputProps={{
                    placeholder: "MM/YYYY",
                    className: "monthPicker",
                    maxLength: 7,
                  }}
                  timeFormat={false}
                />
                <div className={classes.validationMessage} />
                {this.validator.message(
                  "FromDate",
                  searchVo.fromDateYrmo,
                  "required|date_format"
                )}
              </div>
              <div>
                <label>To</label>
                <Datetime
                  onChange={(moment) => this.monthPicker(moment, "toDateYrmo")}
                  value={searchVo.toDateYrmo}
                  dateFormat="MM/YYYY"
                  closeOnSelect="true"
                  inputProps={{
                    placeholder: "MM/YYYY",
                    className: "monthPicker",
                    maxLength: 7,
                  }}
                  timeFormat={false}
                />
                <div className={classes.validationMessage}>
                  {this.validator.message(
                    "ToDate",
                    searchVo.toDateYrmo,
                    [
                      "required",
                      "date_format",
                      " date_after_month_year",
                      { date_after_month_year: searchVo.fromDateYrmo },
                    ]
                  )}
                </div>
              </div>
              {/* <div>
                <InputField
                  name="fromDateYrmo"
                  placeholder="MM/YYYY"
                  label="From"
                  value={searchVo.fromDateYrmo}
                  onClick={this.handleDates("#fromDateYrmo")}
                  maxLength={7}
                  onChange={this.handleSearchFieldChange("fromDateYrmo")}
                  required
                />
                <div className={classes.validationMessage} />
              </div>
              <div>
                <InputField
                  name="toDateYrmo"
                  placeholder="MM/YYYY"
                  label="To"
                  value={searchVo.toDateYrmo}
                  onClick={this.handleDates("#toDateYrmo")}
                  maxLength={7}
                  onChange={this.handleSearchFieldChange("toDateYrmo")}
                  required
                />
                <div className={classes.validationMessage} />
              </div> */}
              <div>
                <SearchBtnPanel
                  search={this.search}
                  reset={this.reset}
                />
              </div>
            </div>

          </ExpansionPanel> : null}
        {rejectList !== null ?
          <ExpansionPanel summary="Reject Results" >
            <RejectBoardTable
              data={this.props.rejectBoardList}
              exportAsExcel={true}
              searchVo={this.state.searchVo}
              submitterId={this.state.searchVo.submitterId}
              searchSummaryDateInd={this.state.searchVo.searchSummaryDateInd}
              rejectBoardSelect={this.props.rejectBoardSelect}
            />
          </ExpansionPanel>
          : null}
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  return {
    rejectBoardList: state.encounterDetailsData.rejectBoardList,
    rejectBoardEncounterCriteria: state.encounterDetailsData.rejectBoardEncounterCriteria,
    rejectBoardChartCriteria: state.encounterDetailsData.rejectBoardChartCriteria,
    isLoading: state.spinner.isLoading,
    dropdowns: state.dropdowns,
  };
};

const mapDispatchToProps = {
  rejectBoardSearch,
  rejectBoardCriteria
};

export default compose(
  withRouter,
  withStyles(Styles),
  connect(mapStateToProps, mapDispatchToProps)
)(RejectBoard)
