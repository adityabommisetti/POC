import React from "react";
import Popup from "reactjs-popup";
import isEmpty from "lodash/isEmpty";
import DataTable from "../Home/DataTable";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";
import InputField from "../UI/InputField";
import { Styles } from "../../assets/styles/Theme";
import ExpansionPanel from "../UI/ExpansionPanel";
import CityZipSearch from "./CityZipSearch";
import { CLAIM_LINE_PROVIDER } from "../../constants/header/encounterDetailsHeader";
import { components, Select } from "../UI/Select";

class ClaimLineProvider extends React.Component {
  state = {
    claimProviderList: this.props.clmLineProv,
    selectedVo:
      this.props.clmLineProv != null
        ? {
          ...(this.props.clmLineProv[0] ? this.props.clmLineProv[0] : null),
        }
        : {},
    rowIndex: 0,
  };

  static getDerivedStateFromProps(nextProps, prevState) {
    if (!isEmpty(nextProps.clmLineProv)) {
      if (
        prevState.claimProviderList[prevState.rowIndex] !==
        nextProps.clmLineProv[prevState.rowIndex]
      ) {
        return {
          selectedVo: nextProps.clmLineProv[prevState.rowIndex],
        };
      }
    }
    return null;
  }

  selectRow = async (index) => {
    const selectedVo = this.state.claimProviderList[index];
    await this.setState({
      selectedVo: selectedVo,
      rowIndex: index,
    });
  };

  render() {
    const {
      classes,
      dropdowns,
      clmLineProv,
      editable,
      selectedRow,
      dataTableVo
    } = this.props;
    const { selectedVo, rowIndex } = this.state;
    return (
      <React.Fragment>
        <div>
          <DataTable
            data={dataTableVo ? dataTableVo : []}
            header={CLAIM_LINE_PROVIDER}
            rowsPerPage={5}
            sortable={true}
            clicked={this.selectRow}
          />
        </div>
        {!isEmpty(clmLineProv) ? (
          <ExpansionPanel summary="Claim - Line - Provider Detail">
            <div id="clmLineProvDetail">
              <div class="panel-body">
                <div className={classes.container}>
                  <div>
                    <InputField
                      name="provType"
                      id="claimLineProviders_provType"
                      value={selectedVo.provType}
                      onChange={this.props.handleChange(
                        "claimLineProviders",
                        rowIndex
                      )}
                      label="Provider Type"
                      disabled={true}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="provLocNbr"
                      id="claimLineProviders_provLocNbr"
                      value={selectedVo.provLocNbr}
                      onChange={this.props.handleChange(
                        "claimLineProviders",
                        rowIndex
                      )}
                      label="LOC Nbr"
                      disabled={!editable}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="provEntityType"
                      value={selectedVo.provEntityType}
                      onChange={this.props.handleChange(
                        "claimLineProviders",
                        rowIndex
                      )}
                      label="Entity Type"
                      disabled={!editable}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="provFirstName"
                      value={selectedVo.provFirstName}
                      onChange={this.props.handleChange(
                        "claimLineProviders",
                        rowIndex
                      )}
                      label="Name"
                      disabled={!editable}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="provLicNbr"
                      id="claimLineProviders_provLicNbr"
                      value={selectedVo.provLicNbr}
                      onChange={this.props.handleChange(
                        "claimLineProviders",
                        rowIndex
                      )}
                      label="License Nbr"
                      disabled={!editable}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="provNpi"
                      id="claimLineProviders_provNpi"
                      value={selectedVo.provNpi}
                      onChange={this.props.handleChange(
                        "claimLineProviders",
                        rowIndex
                      )}
                      label="NPI"
                      disabled={!editable}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="provUpin"
                      id="claimLineProviders_provUpin"
                      value={selectedVo.provUpin}
                      onChange={this.props.handleChange(
                        "claimLineProviders",
                        rowIndex
                      )}
                      label="UPIN"
                      disabled={!editable}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="provOthPayerId"
                      id="claimLineProviders_provOthPayerId"
                      value={selectedVo.provOthPayerId}
                      onChange={this.props.handleChange(
                        "claimLineProviders",
                        rowIndex
                      )}
                      label="Other Payer ID"
                      disabled={!editable}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="provCommNbr"
                      id="claimLineProviders_provCommNbr"
                      value={selectedVo.provCommNbr}
                      onChange={this.props.handleChange(
                        "claimLineProviders",
                        rowIndex
                      )}
                      label="Comm Nbr"
                      disabled={!editable}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  {selectedRow.encType === "P" ||
                    selectedRow.encType === "E" ? (
                      <React.Fragment>
                        <div>
                          <InputField
                            name="provTaxonomyCd"
                            id="claimLineProviders_provTaxonomyCd"
                            value={selectedVo.provTaxonomyCd}
                            onChange={this.props.handleChange(
                              "claimLineProviders",
                              rowIndex
                            )}
                            label="Taxonomy"
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="provCountry"
                            id="claimLineProviders_provCountry"
                            value={selectedVo.provCountry}
                            onChange={this.props.handleChange(
                              "claimLineProviders",
                              rowIndex
                            )}
                            label="Country Code"
                            maxLength={3}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="provCntrySubd"
                            id="claimLineProviders_provCntrySubd"
                            value={selectedVo.provCntrySubd}
                            onChange={this.props.handleChange(
                              "claimLineProviders",
                              rowIndex
                            )}
                            label="Subd Code"
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="provAddrLine1"
                            id="claimLineProviders_provAddrLine1"
                            value={selectedVo.provAddrLine1}
                            onChange={this.props.handleChange(
                              "claimLineProviders",
                              rowIndex
                            )}
                            label="Address1"
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="provAddrLine2"
                            id="claimLineProviders_provAddrLine2"
                            value={selectedVo.provAddrLine2}
                            onChange={this.props.handleChange(
                              "claimLineProviders",
                              rowIndex
                            )}
                            label="Address2"
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="provCity"
                            id="claimLineProviders_provCity"
                            label="City"
                            maxLength={30}
                            disabled={!editable}
                            onChange={this.props.handleChange(
                              "claimLineProviders",
                              rowIndex
                            )}
                            value={selectedVo.provCity}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <Select
                            components={components}
                            propertyName={dropdowns.stateList.filter(
                              (option) => option.value === selectedVo.provState
                            )}
                            options={dropdowns.stateList}
                            label="Choose Process Status ..."
                            textFieldProps={{
                              id: "provState",
                              label: "State",
                              InputLabelProps: {
                                className: classes.label,
                                shrink: true,
                              },
                            }}
                            className={classes.textFieldSelect}
                            handleChange={this.props.handleSelect(
                              "provState",
                              "claimLineProviders",
                              rowIndex
                            )}
                            classes={classes}
                            isDisabled={!editable}
                          />
                        </div>
                        <div>
                          <InputField
                            name="provZip"
                            id="claimLineProviders_provZip"
                            maxLength={10}
                            label="Zip"
                            disabled={!editable}
                            onBlur={this.props.handleClmBlur(
                              "",
                              selectedVo.provZip,
                              "provZip",
                              "claimLineProviders",
                              rowIndex)}
                            onChange={this.props.handleChange(
                              "claimLineProviders",
                              rowIndex
                            )}
                            value={selectedVo.provZip}
                          />
                          {editable ? (
                            <Popup
                              style={{ height: "65%" }}
                              className={classes.mobileWidth}
                              modal
                              trigger={<span class="more-info" />}
                              position="right center"
                            >
                              {(close) => (
                                <div>
                                  <CityZipSearch
                                    headerLabel="ProviderZip Search"
                                    zip5={selectedVo.provZip}
                                    zip4={""}
                                    param={"provZip"}
                                    targetVo={"claimLineProviders"}
                                    index={rowIndex}
                                    searchType="Zip_SEARCH"
                                    close={close}
                                    setData={this.props.setZipData}
                                  />
                                </div>
                              )}
                            </Popup>
                          ) : null}
                          <div className={classes.validationMessage}>
                            {this.props.validator.message(
                              "zip",
                              selectedVo.provZip,
                              "numeric|min:0,num"
                            )}
                          </div>
                        </div>
                      </React.Fragment>
                    ) : null}
                </div>
              </div>
            </div>
          </ExpansionPanel>
        ) : null}
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    dataTableVo: state.ClaimCodeReducer.claimVo.claimLineProviders
  };
};

export default connect(
  mapStateToProps,
  null
)(withStyles(Styles)(ClaimLineProvider));
