import Paper from "@material-ui/core/Paper";
import { withStyles } from "@material-ui/core/styles";
import isEmpty from "lodash/isEmpty";
import React from "react";
import { connect } from "react-redux";
import { Styles } from "../../assets/styles/Theme";
import Modal from "../../components/UI/Modal/Modal";
import * as ActionTypes from "../../constants/actionConstants/applActionValues";
import * as Type from "../../constants/ConfirmType";
import { PROVIDER_COMMIUNICATION } from "../../constants/staticData/encounterDetails";
import {
  providerDetails,
  providerUpdate,
} from "../../redux/actions/encounterDetailsAction";
import {
  searchCityZip,
  resetZip
} from "../../redux/actions/CityZipAction";
import Popup from "reactjs-popup";
import CityZipSearch from "./CityZipSearch";
import InputField from "../UI/InputField";
import { components, Select } from "../UI/Select";
import ConfirmBox from "../utils/PopUp";
import EncButtonPanel from "./EncButtonPanel";
import SimpleReactValidator from "simple-react-validator";
import { customValidations } from "../../utils/CustomValidations";

class Subscriber extends React.Component {
  constructor(props) {
    super(props);
    this.validator = new SimpleReactValidator({
      validators: {
        ValidSSN: customValidations.ValidSSN
      },
    });
    this.state = {
      providerVo: {
        mfId: "",
        intrchgSndrId: "",
        prodTestInd: "",
        intrchgCtrlNbr: "",
        txnSetCtrlNbr: "",
        billPrvHrchyId: "",
        billPrvAffilTaxId: "",
        billPrvTaxonomyCd: "",
        billPrvCurrencyCd: "",
        billPrvEntityType: "",
        billPrvEntityTypeDesc: null,
        billPrvOrgName: "",
        billPrvFirstName: "",
        billPrvMiddleName: "",
        billPrvSuffix: "",
        billPrvLastName: null,
        billPrvNpi: "",
        billPrvAddrLine1: "",
        billPrvAddrLine2: "",
        billPrvCity: "",
        billPrvState: "",
        billPrvZip: "",
        billPrvCountry: "",
        billPrvCntrySubdCd: "",
        billPrvSsn: "",
        billPrvLicNbr: "",
        billPrvUpin: "",
        billPrvContactName: "",
        billPrvComNbrQual1: "",
        billPrvComNbr1: "",
        billPrvComNbrQual2: "",
        billPrvComNbr2: "",
        billPrvComNbrQual3: "",
        billPrvComNbr3: "",
        p2prvEntityType: "",
        p2prvEntityTypeDesc: null,
        p2prvAddrLine1: "",
        p2prvAddrLine2: "",
        p2prvCity: "",
        p2prvState: "",
        p2prvZip: "",
        p2prvCountry: "",
        p2prvCntrySubdCd: "",
        p2planOrgName: null,
        p2planPrimPayerId: null,
        p2planPrimPlanId: null,
        p2planAddrLine1: null,
        p2planAddrLine2: null,
        p2planCity: null,
        p2planState: null,
        p2planZip: null,
        p2planCountry: null,
        p2planCntrySubdCd: null,
        p2planPayerIdNbr: null,
        p2planLocNbr: null,
        p2planNaicCd: null,
        p2planTaxId: null,
        lastUpdtTime: "",
        lastUpdtUserid: "",
        formattedBillPrvAffilTaxId: "",
        formattedBillPrvSsn: ""
      },
      currWtxClaimRefNbr: "",
      editable: false,
      modified: false,
      validateStatus: false
    };
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (!isEmpty(nextProps.providerDataList)) {
      if (
        prevState.currWtxClaimRefNbr !==
        nextProps.providerDataList.wtxClaimRefNbr
      ) {
        return {
          providerVo: { ...nextProps.providerDataList },
          currWtxClaimRefNbr: nextProps.providerDataList.wtxClaimRefNbr,
          editable: false,
        };
      }
    }
    return null;
  }

  handleChange = (name) => (event) => {
    let value = event.target
      ? event.target.value.toUpperCase()
      : event.value.toUpperCase();
    this.setState((prevState) => ({
      providerVo: {
        ...prevState.providerVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleEdit = () => {
    this.setState({
      editable: true,
      closePopup: false,
    });
  };

  handleUpdate = async (e) => {
    e.preventDefault();
    if (!this.validator.allValid()) {
      this.validator.showMessages();
      this.forceUpdate();
      this.setState({
        validateStatus: true
      })
    }
    else {
      this.setState({
        validateStatus: false
      })
      let msg = Type.ENCOUNTER;
      if (this.props.selectedRow.processStatus === "COR") {
        msg = Type.UPDATE;
      }
      ConfirmBox(this.confirmUpdate, msg, this.props);
    }
  };

  confirmUpdate = async () => {
    const status = await this.props.providerUpdate(this.state.providerVo);
    if (status === "success") {
      this.setState((prevState) => ({
        providerVo: {
          ...prevState.providerVo,
          ...this.props.providerDataList,
        },
        message: ActionTypes.UPDATE_SUCCESS,
        editable: false,
        modified: false,
        closePopup: true,
      }));
    } else {
      this.setState({
        closePopup: true,
        message: status,
        editable: false,
        currWtxClaimRefNbr: "",
      });
    }
  };

  handleCancel = () => {
    this.setState((prevState) => ({
      providerVo: {
        ...prevState.providerVo,
        ...this.props.providerDataList,
      },
      editable: false,
      modified: false,
      validateStatus: false
    }));
  };
  handleNumber = (name) => (e) => {
    let value = e.target.value.replace(/[^0-9]/g, "");
    this.setState((prevState) => ({
      providerVo: {
        ...prevState.providerVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  setZipData = async (data, param) => {
    console.clear()
    console.log(data)
    console.log(param)
    if (param === "billPrvZip") {
      this.setState((prevState) => ({
        providerVo: {
          ...prevState.providerVo,
          billPrvCity: data.perCity,
          billPrvState: data.perState,
          billPrvCountry: data.countyCd,
          billPrvZip: data.perZip5
        },
        modified: true,
      }));
    } else if (param === "p2prvZip") {
      this.setState((prevState) => ({
        providerVo: {
          ...prevState.providerVo,
          p2prvCity: data.perCity,
          p2prvState: data.perState,
          p2prvCountry: data.countyCd,
          p2prvZip: data.perZip5
        },
        modified: true,
      }));
    } else if (param === "p2planZip") {
      this.setState((prevState) => ({
        providerVo: {
          ...prevState.providerVo,
          p2planCity: data.perCity,
          p2planState: data.perState,
          p2planCountry: data.countyCd,
          p2planZip: data.perZip5
        },
        modified: true,
      }));
    }
  };


  handleBlur = (zip4, zip5, param) => async (event) => {
    event.preventDefault();
    const zipVo = {
      zip4: zip4,
      zip5: zip5
    }
    await this.props.resetZip();
    await this.props.searchCityZip(zipVo);
    if (!isEmpty(this.props.zipData)) {
      const data = this.props.zipData[0];
      this.setZipData(data, param);
    }
  };

  modalClosed = () => {
    this.setState({ closePopup: false });
  };

  render() {
    const { classes, dropdowns, selectedRow } = this.props;
    const {
      providerVo,
      editable,
      message,
      closePopup,
      modified,
    } = this.state;
    return (
      <React.Fragment>
        <Modal
          dialogTitle="PROVIDER"
          message={message}
          show={closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Paper elevation={0} className={classes.card}>
          <form autoComplete="off">
            <React.Fragment>
              {providerVo.emptyObject === false ?
                (selectedRow &&
                  selectedRow.processStatus !== "ACC" &&
                  selectedRow.processStatus !== "SUB" &&
                  selectedRow.processStatus !== "PAC" &&
                  selectedRow.processStatus !== "RES" &&
                  selectedRow.processStatus !== "BAS" ?
                  (<div style={{ textAlign: "right" }}>
                    <EncButtonPanel
                      handleEdit={this.handleEdit}
                      handleUpdate={this.handleUpdate}
                      handleCancel={this.handleCancel}
                      handleNumber={this.handleNumber}
                      editable={!editable}
                      modified={modified}
                      selectedRow={selectedRow}
                    /></div>) : null)
                :
                <div style={{ textAlign: "right" }}>
                  <EncButtonPanel
                    handleEdit={this.handleEdit}
                    handleUpdate={this.handleUpdate}
                    handleCancel={this.handleCancel}
                    handleNumber={this.handleNumber}
                    disabled={true}
                    modified={modified}
                    selectedRow={selectedRow}
                  /></div>}

              {providerVo.emptyObject ?
                <div class="alert alert-danger" id="displayMessage">
                  <strong>Failed: &nbsp;</strong>
                  {"NO PROVIDER DATA "}
                </div> : null}



              {this.state.validateStatus ?
                <div class="alert alert-danger" id="displayMessage">
                  <strong>Failed: &nbsp;</strong>
                  {"Please check the fields with error."}
                </div> : null}





              <div className={classes.applicationSectionHeading}>
                <span> Billing Provider</span>
              </div>
              <div class="panel-body">
                <div className={classes.container}>
                  {selectedRow.encType === "I" ? (
                    <div>
                      <InputField
                        name="billPrvOrgName"
                        label="Org Name"
                        maxLength={50}
                        disabled={!editable}
                        onChange={this.handleChange("billPrvOrgName")}
                        value={providerVo.billPrvOrgName}
                      />
                      <div className={classes.validationMessage} />
                    </div>
                  ) : null}
                  {selectedRow.encType === "P" ||
                    selectedRow.encType === "E" ? (
                      <div>
                        <Select
                          components={components}
                          propertyName={dropdowns.lstEntityType.filter(
                            (option) =>
                              option.value === providerVo.billPrvEntityType
                          )}
                          options={dropdowns.lstEntityType}
                          label="Choose Entity Type ..."
                          textFieldProps={{
                            id: "billPrvEntityType",
                            label: "Entity Type",
                            InputLabelProps: {
                              className: classes.label,
                              shrink: true,
                            },
                          }}
                          className={classes.textFieldSelect}
                          handleChange={this.handleChange("billPrvEntityType")}
                          classes={classes}
                          isDisabled={!editable}
                        />
                      </div>
                    ) : null}
                  {selectedRow.encType === "P" ||
                    selectedRow.encType === "E" ? (
                      <div>
                        <InputField
                          name="billPrvUpin"
                          label="UPIN"
                          maxLength={50}
                          disabled={!editable}
                          onChange={this.handleChange("billPrvUpin")}
                          value={providerVo.billPrvUpin}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}

                  <div>
                    <InputField
                      name="billPrvContactName"
                      label="Contact Name"
                      maxLength={65}
                      disabled={true}
                      onChange={this.handleChange("billPrvContactName")}
                      value={providerVo.billPrvContactName}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  {selectedRow.encType === "P" ||
                    selectedRow.encType === "E" ? (
                      editable ?
                        <React.Fragment>
                          <div>
                            <InputField
                              name="billPrvFirstName"
                              label="First Name"
                              maxLength={50}
                              width="380px"
                              disabled={!editable}
                              onChange={this.handleChange("billPrvFirstName")}
                              value={providerVo.billPrvFirstName}
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div style={{ marginRight: "7px" }}>
                            <InputField
                              name="billPrvMiddleName"
                              label="Middle Name"
                              maxLength={50}
                              width="380px"

                              disabled={!editable}
                              onChange={this.handleChange("billPrvMiddleName")}
                              value={providerVo.billPrvMiddleName}
                            />
                            <div className={classes.validationMessage} />
                          </div>
                        </React.Fragment>
                        :
                        <div>
                          <InputField
                            name="billPrvFullName"
                            label="Name"
                            maxLength={50}
                            width="370px"
                            disabled={!editable}
                            onChange={this.handleChange("billPrvFullName")}
                            value={providerVo.billPrvFullName}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                    ) : null}
                  <div>
                    <InputField
                      name="billPrvTaxonomyCd"
                      label="Taxonomy"
                      maxLength={10}
                      disabled={!editable}
                      onChange={this.handleChange("billPrvTaxonomyCd")}
                      value={providerVo.billPrvTaxonomyCd}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  {selectedRow.encType === "P" ||
                    selectedRow.encType === "E" ? (
                      <div>
                        <InputField
                          name="billPrvLicNbr"
                          label="Lic Nbr"
                          maxLength={9}
                          disabled={!editable}
                          onChange={this.handleChange("billPrvLicNbr")}
                          value={providerVo.billPrvLicNbr}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}
                  <div>
                    <InputField
                      name="billPrvNpi"
                      label="NPI"
                      maxLength={10}
                      disabled={!editable}
                      onChange={this.handleChange("billPrvNpi")}
                      value={providerVo.billPrvNpi}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="formattedBillPrvAffilTaxId"
                      label="Affil. Tax ID"
                      maxLength={50}
                      disabled={!editable}
                      onChange={this.handleChange("formattedBillPrvAffilTaxId")}
                      value={providerVo.formattedBillPrvAffilTaxId}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  {selectedRow.encType === "P" ||
                    selectedRow.encType === "E" ? (
                      <div>
                        <InputField
                          name="formattedBillPrvSsn"
                          label="SSN"
                          maxLength={12}
                          disabled={!editable}
                          onChange={this.handleChange("formattedBillPrvSsn")}
                          value={providerVo.formattedBillPrvSsn}
                        />
                        <div className={classes.validationMessage} >
                          {this.validator.message(
                            "SSN",
                            providerVo.formattedBillPrvSsn,
                            "ValidSSN"
                          )}
                        </div>
                      </div>
                    ) : null}
                  <div style={{ marginRight: "20px" }}>
                    <InputField
                      name="billPrvAddrLine1"
                      label="Address1"
                      maxLength={55}
                      width="370px"
                      disabled={!editable}
                      onChange={this.handleChange("billPrvAddrLine1")}
                      value={providerVo.billPrvAddrLine1}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="billPrvAddrLine2"
                      label="Address2"
                      maxLength={55}
                      disabled={!editable}
                      onChange={this.handleChange("billPrvAddrLine2")}
                      value={providerVo.billPrvAddrLine2}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="billPrvCity"
                      label="City"
                      maxLength={30}
                      disabled={!editable}
                      onChange={this.handleChange("billPrvCity")}
                      value={providerVo.billPrvCity}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <Select
                      components={components}
                      propertyName={dropdowns.stateList.filter(
                        (option) => option.value === providerVo.billPrvState
                      )}
                      options={dropdowns.stateList}
                      label="Choose State ..."
                      textFieldProps={{
                        id: "state",
                        label: "State",
                        InputLabelProps: {
                          className: classes.label,
                          shrink: true,
                        },
                      }}
                      className={classes.textFieldSelect}
                      handleChange={this.handleChange("billPrvState")}
                      classes={classes}
                      isDisabled={!editable}
                    />
                  </div>
                  <div>
                    <InputField
                      name="billPrvZip"
                      label="Zip"
                      maxLength={10}
                      disabled={!editable}
                      onChange={this.handleNumber("billPrvZip")}
                      value={providerVo.billPrvZip}
                      onBlur={this.handleBlur("", providerVo.billPrvZip, "billPrvZip")}
                    />
                    {editable ? (
                      <Popup
                        style={{ height: "65%" }}
                        className={classes.mobileWidth}
                        modal
                        trigger={<span class="more-info" />}
                        position="right center"
                      >
                        {(close) => (
                          <div>
                            <CityZipSearch
                              headerLabel="ProvZip Search"
                              zip5={providerVo.billPrvZip}
                              zip4={""}
                              param={"billPrvZip"}
                              searchType="Zip_SEARCH"
                              close={close}
                              setData={this.setZipData}
                            />
                          </div>
                        )}
                      </Popup>
                    ) : null}
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="billPrvCountry"
                      label="Country Code"
                      maxLength={3}
                      disabled={!editable}
                      onChange={this.handleChange("billPrvCountry")}
                      value={providerVo.billPrvCountry}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="billPrvCntrySubdCd"
                      label="Subd Code"
                      maxLength={3}
                      disabled={!editable}
                      onChange={this.handleChange("billPrvCntrySubdCd")}
                      value={providerVo.billPrvCntrySubdCd}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="billPrvCurrencyCd"
                      label="Currency Cd"
                      maxLength={11}
                      disabled={true}
                      onChange={this.handleChange("billPrvCurrencyCd")}
                      value={providerVo.billPrvCurrencyCd}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                </div>
                <div className={classes.container}>
                  <span>Communication :</span>
                  <div>
                    {this.state.editable ? (
                      <div>
                        <Select
                          components={components}
                          propertyName={PROVIDER_COMMIUNICATION.filter(
                            (option) =>
                              option.value === providerVo.billPrvComNbrQual1
                          )}
                          options={PROVIDER_COMMIUNICATION}
                          label="Choose State ..."
                          textFieldProps={{
                            id: "billPrvComNbrQual1",
                            label: "Qual/Nbr1",
                            InputLabelProps: {
                              className: classes.label,
                              shrink: true,
                            },
                          }}
                          className={classes.textFieldSelect}
                          handleChange={this.handleChange("billPrvComNbrQual1")}
                          classes={classes}
                          isDisabled={!editable}
                        />
                      </div>
                    ) : null}
                    <InputField
                      name="billPrvComNbr1"
                      label="Qual/Nbr1"
                      maxLength={11}
                      disabled={!editable}
                      onChange={this.handleChange("billPrvComNbr1")}
                      value={providerVo.billPrvComNbr1}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    {this.state.editable ? (
                      <div>
                        <Select
                          components={components}
                          propertyName={PROVIDER_COMMIUNICATION.filter(
                            (option) =>
                              option.value === providerVo.billPrvComNbrQual2
                          )}
                          options={PROVIDER_COMMIUNICATION}
                          label="Choose State ..."
                          textFieldProps={{
                            id: "billPrvComNbrQual2",
                            label: "Qual/Nbr2",
                            InputLabelProps: {
                              className: classes.label,
                              shrink: true,
                            },
                          }}
                          className={classes.textFieldSelect}
                          handleChange={this.handleChange("billPrvComNbrQual2")}
                          classes={classes}
                          isDisabled={!editable}
                        />
                      </div>
                    ) : null}
                    <InputField
                      name="billPrvComNbr2"
                      label="Qual/Nbr2"
                      maxLength={11}
                      disabled={!editable}
                      onChange={this.handleChange("billPrvComNbr2")}
                      value={providerVo.billPrvComNbr2}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    {this.state.editable ? (
                      <div>
                        <Select
                          components={components}
                          propertyName={PROVIDER_COMMIUNICATION.filter(
                            (option) =>
                              option.value === providerVo.billPrvComNbrQual3
                          )}
                          options={PROVIDER_COMMIUNICATION}
                          label="Choose State ..."
                          textFieldProps={{
                            id: "billPrvComNbrQual3",
                            label: "Qual/Nbr3",
                            InputLabelProps: {
                              className: classes.label,
                              shrink: true,
                            },
                          }}
                          className={classes.textFieldSelect}
                          handleChange={this.handleChange("billPrvComNbrQual3")}
                          classes={classes}
                          isDisabled={!editable}
                        />
                      </div>
                    ) : null}
                    <InputField
                      name="billPrvComNbr3"
                      label="Qual/Nbr3"
                      maxLength={11}
                      disabled={!editable}
                      onChange={this.handleChange("billPrvComNbr3")}
                      value={providerVo.billPrvComNbr3}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                </div>
              </div>
              <div className={classes.applicationSectionHeading}>
                <span>Pay-To Provider</span>
              </div>
              <div class="panel-body">
                <div className={classes.container}>
                  {selectedRow.encType === "P" ||
                    selectedRow.encType === "E" ? (
                      <div>
                        <Select
                          components={components}
                          propertyName={dropdowns.lstEntityType.filter(
                            (option) =>
                              option.value === providerVo.p2prvEntityType
                          )}
                          options={dropdowns.lstEntityType}
                          label="Choose Entity Type ..."
                          textFieldProps={{
                            id: "p2prvEntityType",
                            label: "Entity Type",
                            InputLabelProps: {
                              className: classes.label,
                              shrink: true,
                            },
                          }}
                          className={classes.textFieldSelect}
                          handleChange={this.handleChange("p2prvEntityType")}
                          classes={classes}
                          isDisabled={!editable}
                        />
                      </div>
                    ) : null}
                  <div>
                    <InputField
                      name="p2prvAddrLine1"
                      label="Address1"
                      maxLength={55}
                      disabled={!editable}
                      onChange={this.handleChange("p2prvAddrLine1")}
                      value={providerVo.p2prvAddrLine1}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="p2prvAddrLine2"
                      label="Address2"
                      maxLength={55}
                      disabled={!editable}
                      onChange={this.handleChange("p2prvAddrLine2")}
                      value={providerVo.p2prvAddrLine2}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="p2prvCity"
                      label="City"
                      maxLength={30}
                      disabled={!editable}
                      onChange={this.handleChange("p2prvCity")}
                      value={providerVo.p2prvCity}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <Select
                      components={components}
                      propertyName={dropdowns.stateList.filter(
                        (option) => option.value === providerVo.p2prvState
                      )}
                      options={dropdowns.stateList}
                      label="Choose State ..."
                      textFieldProps={{
                        id: "state",
                        label: "State",
                        InputLabelProps: {
                          className: classes.label,
                          shrink: true,
                        },
                      }}
                      className={classes.textFieldSelect}
                      handleChange={this.handleChange("p2prvState")}
                      classes={classes}
                      isDisabled={!editable}
                    />
                  </div>
                  <div>
                    <InputField
                      name="p2prvZip"
                      maxLength={10}
                      label="Zip"
                      disabled={!editable}
                      onChange={this.handleNumber("p2prvZip")}
                      value={providerVo.p2prvZip}
                      onBlur={this.handleBlur("", providerVo.p2prvZip, "p2prvZip")}
                    />
                    {editable ? (
                      <Popup
                        style={{ height: "65%" }}
                        className={classes.mobileWidth}
                        modal
                        trigger={<span class="more-info" />}
                        position="right center"
                      >
                        {(close) => (
                          <div>
                            <CityZipSearch
                              headerLabel="ProvZip Search"
                              zip5={providerVo.p2prvZip}
                              zip4={""}
                              param={"p2prvZip"}
                              searchType="Zip_SEARCH"
                              close={close}
                              setData={this.setZipData}
                            />
                          </div>
                        )}
                      </Popup>
                    ) : null}
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="p2prvCountry"
                      label="Country Code"
                      maxLength={3}
                      disabled={!editable}
                      onChange={this.handleChange("p2prvCountry")}
                      value={providerVo.p2prvCountry}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="p2prvCntrySubdCd"
                      label="Subd Code"
                      maxLength={3}
                      disabled={!editable}
                      onChange={this.handleChange("p2prvCntrySubdCd")}
                      value={providerVo.p2prvCntrySubdCd}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                </div>
              </div>
              <div className={classes.applicationSectionHeading}>
                <span>Pay-To Plan</span>
              </div>
              <div class="panel-body">
                <div className={classes.container}>

                  <div>
                    <InputField
                      name="p2planOrgName"
                      label="Org Name"
                      maxLength={50}
                      disabled={!editable}
                      onChange={this.handleChange("p2planOrgName")}
                      value={providerVo.p2planOrgName}
                    />
                    <div className={classes.validationMessage} />
                  </div>

                  <div>
                    <InputField
                      name="p2planPrimPayerId"
                      label="Prim Payer ID"
                      maxLength={60}
                      disabled={!editable}
                      onChange={this.handleChange("p2planPrimPayerId")}
                      value={providerVo.p2planPrimPayerId}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="p2planPayerIdNbr"
                      label="Payer ID"
                      maxLength={15}
                      disabled={!editable}
                      onChange={this.handleChange("p2planPayerIdNbr")}
                      value={providerVo.p2planPayerIdNbr}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="p2planPrimPlanId"
                      label="Prim Plan ID"
                      maxLength={65}
                      disabled={!editable}
                      onChange={this.handleChange("p2planPrimPlanId")}
                      value={providerVo.p2planPrimPlanId}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="p2planTaxId"
                      label="Tax ID"
                      maxLength={50}
                      disabled={!editable}
                      onChange={this.handleChange("p2planTaxId")}
                      value={providerVo.p2planTaxId}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="p2planLocNbr"
                      label="Loc Nbr"
                      maxLength={15}
                      disabled={!editable}
                      onChange={this.handleChange("p2planLocNbr")}
                      value={providerVo.p2planLocNbr}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="p2planNaicCd"
                      label="NAIC Code"
                      maxLength={11}
                      disabled={!editable}
                      onChange={this.handleChange("p2planNaicCd")}
                      value={providerVo.p2planNaicCd}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="p2planAddrLine1"
                      label="Address1"
                      maxLength={55}
                      disabled={!editable}
                      onChange={this.handleChange("p2planAddrLine1")}
                      value={providerVo.p2planAddrLine1}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="p2planAddrLine2"
                      label="Address2"
                      maxLength={55}
                      disabled={!editable}
                      onChange={this.handleChange("p2planAddrLine2")}
                      value={providerVo.p2planAddrLine2}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="p2planCity"
                      label="City"
                      maxLength={30}
                      disabled={!editable}
                      onChange={this.handleChange("p2planCity")}
                      value={providerVo.p2planCity}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <Select
                      components={components}
                      propertyName={dropdowns.stateList.filter(
                        (option) => option.value === providerVo.p2planState
                      )}
                      options={dropdowns.stateList}
                      label="Choose State ..."
                      textFieldProps={{
                        id: "state",
                        label: "State",
                        InputLabelProps: {
                          className: classes.label,
                          shrink: true,
                        },
                      }}
                      className={classes.textFieldSelect}
                      handleChange={this.handleChange("p2planState")}
                      classes={classes}
                      isDisabled={!editable}
                    />
                  </div>
                  <div>
                    <InputField
                      name="p2planZip"
                      maxLength={10}
                      label="Zip"
                      disabled={!editable}
                      onChange={this.handleNumber("p2planZip")}
                      value={providerVo.p2planZip}
                      onBlur={this.handleBlur("", providerVo.p2planZip, "p2planZip")}
                    />
                    {editable ? (
                      <Popup
                        style={{ height: "65%" }}
                        className={classes.mobileWidth}
                        modal
                        trigger={<span class="more-info" />}
                        position="right center"
                      >
                        {(close) => (
                          <div>
                            <CityZipSearch
                              headerLabel="ProvZip Search"
                              zip5={providerVo.p2planZip}
                              zip4={""}
                              param={"p2planZip"}
                              searchType="Zip_SEARCH"
                              close={close}
                              setData={this.setZipData}
                            />
                          </div>
                        )}
                      </Popup>
                    ) : null}
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="p2planCountry"
                      label="Country Code"
                      maxLength={3}
                      disabled={!editable}
                      onChange={this.handleChange("p2planCountry")}
                      value={providerVo.p2planCountry}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="p2planCntrySubdCd"
                      label="Subd Code"
                      maxLength={3}
                      disabled={!editable}
                      onChange={this.handleChange("p2planCntrySubdCd")}
                      value={providerVo.p2planCntrySubdCd}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                </div>
              </div>
            </React.Fragment>
          </form>
        </Paper>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    providerDataList: state.encounterDetailsData.provider_Data,
    zipData: state.CityZipReducer.cityZipSearchData,
    isLoading: state.spinner.isLoading,
    dropdowns: state.dropdowns,
  };
};

const mapDispatchToProps = {
  providerDetails,
  providerUpdate,
  searchCityZip,
  resetZip
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(Subscriber));
