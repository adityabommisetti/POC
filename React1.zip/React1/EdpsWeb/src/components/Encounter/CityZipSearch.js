import React, { Component } from "react";
import { CITY_ZIP_HEADER } from "../../constants/header/encounterDetailsHeader";

import Button from "@material-ui/core/Button";
import DataTable from "../Home/DataTable";
import InputField from "../UI/InputField";
import Paper from "@material-ui/core/Paper";
import { Styles } from "../../assets/styles/PopUpStyle";
import classNames from "classnames";
import { connect } from "react-redux";
import { searchCityZip, resetZip } from "../../redux/actions/CityZipAction";
import { withStyles } from "@material-ui/core/styles";
import isEmpty from "lodash/isEmpty";

class CityZipSearch extends Component {
  constructor(props) {
    super(props);
    this.state = {
      zipVo: {
        zip4: this.props.zip4,
        zip5: this.props.zip5
      },
      selectedIndex: 0,
      data: [],
    };
  };

  async componentDidMount() {
    await this.props.resetZip();
    await this.props.searchCityZip(this.state.zipVo);
    await this.setState({
      data: this.props.data,
      selectedIndex: 0
    });
  }

  onRowSelect = (index) => {
    this.setState({
      selectedIndex: index,
    });
  };

  loadData = async (event) => {
    event.preventDefault();
    await this.props.resetZip();
    await this.props.searchCityZip(this.state.zipVo);
    await this.setState({
      data: [...this.props.data],
      selectedIndex: 0
    });
  };

  onSubmit = () => {
    const { data, targetVo, param, index } = this.props;
    const tableData = [...data];
    const selectedRow = tableData[this.state.selectedIndex];
    this.props.setData(selectedRow, param, targetVo, index);
    this.props.close();
  };

  reset = () => {
    this.setState((prevState) => ({
      zipVo: {
        ...prevState.zipVo,
        zip4: "",
        zip5: ""
      },
    }));
  };

  handleChange = (e) => {
    let id = [e.target.id];
    const value = e.target.value;
    this.setState((prevState) => ({
      zipVo: {
        ...prevState.zipVo,
        [id]: value,
      },
    }));
  };

  handleOnBlur = (e) => {
    let value = e.target.value.replace(/[^0-9]/g, "").trim();
    let id = [e.target.id];

    this.setState((prevState) => ({
      zipVo: {
        ...prevState.zipVo,
        [id]: value,
      },
    }));
  };

  render() {
    const { classes, headerLabel, data } = this.props;
    let dataSet = null;
    console.clear();
    console.log(data);
    if (data) {
      dataSet = (
        <div className={classes.table}>
          <DataTable
            data={data}
            header={CITY_ZIP_HEADER}
            rowsPerPage={10}
            sortableHeader={true}
            clicked={this.onRowSelect}
            index={this.state.selectedIndex}
          />
          <div className={classes.div1}>
            <Button
              variant="contained"
              color="primary"
              disabled={isEmpty(this.props.data)}
              className={classNames(classes.button, classes.submit)}
              onClick={this.onSubmit}
            >
              Submit
            </Button>
          </div>
        </div>
      );
    }

    return (
      <React.Fragment>
        <Paper
          className={classes.root}
          elevation={0}
          style={{ padding: "15px" }}
        >
          <fieldset className={classes.fieldset}>
           
            <form className={classes.container} autoComplete="off">
              <div style={{alignItems:"center"}}>
            <legend className={classes.legend}>{headerLabel}</legend></div>
              <div className={classes.div1}>
                <InputField
                  required
                  id="zip5"
                  label="Zip 5"
                  className={classes.textField}
                  margin="normal"
                  InputLabelProps={{ className: classes.label }}
                  value={this.state.zipVo.zip5}
                  maxLength="5"
                  onChange={this.handleChange}
                />

                <InputField
                  id="zip4"
                  label="Zip 4"
                  className={classes.textField}
                  margin="normal"
                  InputLabelProps={{ className: classes.label }}
                  value={this.state.zipVo.zip4}
                  onChange={this.handleChange}
                  maxLength="4"
                />
              </div>
              <div className={classes.div1}>
                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={this.loadData}
                >
                  <i className="material-icons">search</i>
                </Button>

                <Button
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={this.props.close}
                >
                  <i className="material-icons">cancel</i>
                </Button>
                <Button
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={this.reset}
                >
                  <i class="material-icons">refresh</i>
                </Button>
              </div>
            </form>
          </fieldset>
        </Paper>
        {dataSet}
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => ({
  data: state.CityZipReducer.cityZipSearchData
});

const mapDispatchToProps = {
  searchCityZip,
  resetZip
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(CityZipSearch));
