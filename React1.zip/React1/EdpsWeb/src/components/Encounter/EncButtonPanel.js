import React from "react";
import Button from "@material-ui/core/Button";
import { withStyles } from "@material-ui/core/styles";

const styles = theme => ({
  buttonContainer: {
    position: "relative",
    display: "contents",
    verticalAlign: "middle",
    textAlign: "right"
  },
  button: {
    margin: theme.spacing.unit,
    [theme.breakpoints.down("sm")]: {
      fontSize: "8px",
      width: "80px"
    }
  }
});

const ButtonPanel = props => {

  return (
    <div className={props.classes.buttonContainer}>
      <Button
        variant="contained"
        color="primary"
        onClick={props.handleEdit}
        className={props.classes.button}
        id="editButton"
        disabled={!props.editable}
      >
        Update
        </Button>
      <Button
        variant="contained"
        color="primary"
        onClick={props.handleUpdate}
        className={props.classes.button}
        id="updateButton"
        disabled={!props.modified}
        
      >
        Save
        </Button>
      <Button
        variant="contained"
        color="primary"
        onClick={props.handleCancel}
        className={props.classes.button}
        id="cancelButton"
        disabled={props.editable}
        
      >
        Cancel
        </Button>
    </div>
  );
};

export default withStyles(styles, { withTheme: true })(ButtonPanel);
