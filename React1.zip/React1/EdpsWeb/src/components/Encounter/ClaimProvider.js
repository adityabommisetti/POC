import React from "react";
import isEmpty from "lodash/isEmpty";
import DataTable from "../Home/DataTable";
import { withStyles } from "@material-ui/core/styles";
import InputField from "../UI/InputField";
import { Styles } from "../../assets/styles/Theme";
import ExpansionPanel from "../UI/ExpansionPanel";
import { deleteClmProvider } from "../../redux/actions/ClaimCodeAction";
import { CLAIM_PROVIDER } from "../../constants/header/encounterDetailsHeader";
import { components, Select } from "../UI/Select";

class ClaimProvider extends React.Component {
  state = {
    claimProviderList: this.props.claimProvider,
    selectedVo:
      this.props.claimProvider != null
        ? {
          ...(this.props.claimProvider[0]
            ? this.props.claimProvider[0]
            : null),
        }
        : {},
    rowIndex: 0,
    message: ""
  };

  static getDerivedStateFromProps(nextProps, prevState) {
    if (!isEmpty(nextProps.claimProvider)) {
      if (
        prevState.claimProviderList[prevState.rowIndex] !==
        nextProps.claimProvider[prevState.rowIndex]
      ) {
        return {
          claimProviderList: nextProps.claimProvider,
          selectedVo: nextProps.claimProvider[prevState.rowIndex],
        };
      }
    }
    return null;
  }

  selectRow = async (index) => {
    const selectedVo = this.state.claimProviderList[index];
    await this.setState({
      selectedVo: selectedVo,
      rowIndex: index,
    });
  };

  // delete = async (list, index, e) => {
  //   e.preventDefault();
  //   const deleteStatus = await this.props.deleteClmProvider(list);
  //   if (deleteStatus.status === "OK") {
  //     this.setState({
  //       claimProviderList: [...this.props.claimProvider],
  //       message: deleteStatus.message
  //     });

  //   }
  //   else {
  //     this.setState({
  //       message: deleteStatus.message
  //     });
  //   }
  // };

  render() {
    const { classes, dropdowns, claimProvider, editable } = this.props;
    const { selectedVo } = this.state;
    return (
      <React.Fragment>
        <div>
          <DataTable
            data={claimProvider}
            header={CLAIM_PROVIDER}
            rowsPerPage={5}
            sortable={true}
            clicked={this.selectRow}
            editable={!editable}
            deleteClmProvider={this.props.deleteClmProvider}
          />
        </div>
        {!isEmpty(claimProvider) ? (
          <div>
            <ExpansionPanel summary="Claim - Provider - Detail">
              <div id="claimProviderDetail"></div>
              <div class="panel-body">
              <div class="twin-margin">
                <div class="twin-boxes">
                  <div class="form-panel">
                    <div className={classes.container}>
                      {!editable ? (
                        <div>
                          <InputField
                            name="providerName"
                            label="Name"
                            width="370px"
                            disabled={true}
                            value={selectedVo.providerName}
                            onChange={this.props.handleChange(
                              "claimProvidersList",
                              this.state.rowIndex
                            )}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                      {editable ? (
                        <div>
                          <InputField
                            name="provFirstName"
                            label="First Name"
                            disabled={true}
                            value={selectedVo.provFirstName}
                            onChange={this.props.handleChange(
                              "claimProvidersList",
                              this.state.rowIndex
                            )}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                      {editable ? (
                        <div>
                          <InputField
                            name="provMiddleName"
                            label="Middle Name"
                            disabled={true}
                            value={selectedVo.provMiddleName}
                            onChange={this.props.handleChange(
                              "claimProvidersList",
                              this.state.rowIndex
                            )}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                      {editable ? (
                        <div>
                          <InputField
                            name="provLastName"
                            label="Last Name"
                            disabled={true}
                            value={selectedVo.provLastName}
                            onChange={this.props.handleChange(
                              "claimProvidersList",
                              this.state.rowIndex
                            )}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                      <div>
                        <InputField
                          name="provAddrLine1"
                          id="claimProvidersList_provAddrLine1"
                          label="Address 1"
                          disabled={true}
                          value={selectedVo.provAddrLine1}
                          onChange={this.props.handleChange(
                            "claimProvidersList",
                            this.state.rowIndex
                          )}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <InputField
                          name="provAddrLine2"
                          id="claimProvidersList_provAddrLine2"
                          label="Address 2"
                          disabled={true}
                          value={selectedVo.provAddrLine2}
                          onChange={this.props.handleChange(
                            "claimProvidersList",
                            this.state.rowIndex
                          )}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <InputField
                          name="provCity"
                          id="claimProvidersList_provCity"
                          onChange={this.props.handleChange(
                            "claimProvidersList",
                            this.state.rowIndex
                          )}
                          label="City"
                          value={selectedVo.provCity}
                          disabled={true}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <Select
                          components={components}
                          propertyName={dropdowns.stateList.filter(
                            (option) => option.value === selectedVo.provState
                          )}
                          options={dropdowns.stateList}
                          label="Choose Process Status ..."
                          textFieldProps={{
                            id: "provState",
                            label: "State",
                            InputLabelProps: {
                              className: classes.label,
                              shrink: true,
                            },
                          }}
                          className={classes.textFieldSelect}
                          handleChange={this.props.handleSelect(
                            "provState",
                            "claimProvidersList",
                            this.state.rowIndex
                          )}
                          classes={classes}
                          isDisabled={true}
                        />
                      </div>
                      <div>
                        <InputField
                          name="prov"
                          id="claimProvidersList_prov"
                          label="Zip"
                          disabled={true}
                          value={selectedVo.prov}
                          onChange={this.props.handleChange(
                            "claimProvidersList",
                            this.state.rowIndex
                          )}
                        />
                        <div className={classes.validationMessage}>
                         {this.props.validator.message(
                              "Zip",
                              selectedVo.prov,
                              "numeric|min:0,num"
                          )}
                        </div>
                      </div>
                      <div>
                        <InputField
                          name="provCountry"
                          id="claimProvidersList_provCountry"
                          label="Country Code"
                          maxLength={3}
                          disabled={true}
                          value={selectedVo.provCountry}
                          onChange={this.props.handleChange(
                            "claimProvidersList",
                            this.state.rowIndex
                          )}
                        />
                        <div className={classes.validationMessage}></div>
                      </div>
                      <div>
                        <InputField
                          name="provCntrySubd"
                          id="claimProvidersList_provCntrySubd"
                          label="Subd Code"
                          disabled={true}
                          value={selectedVo.provCntrySubd}
                          onChange={this.props.handleChange(
                            "claimProvidersList",
                            this.state.rowIndex
                          )}
                        />
                        <div className={classes.validationMessageSelect}></div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="twin-boxes">
                  <div class="form-panel">
                    <div className={classes.container} style={{marginLeft:"48px"}}>
                      {/* <div>
                        <InputField
                          name="provType"
                          id="claimProvidersList_provType"
                          label="Provider Type"
                          disabled={!editable}
                          value={selectedVo.provType}
                          onChange={this.props.handleChange(
                            "claimProvidersList",
                            this.state.rowIndex
                          )}
                        />
                        <div className={classes.validationMessage} />
                      </div> */}
                      <div >
                        <Select
                          components={components}
                          propertyName={dropdowns.lstProviderType.filter(
                            (option) => option.value === selectedVo.provType
                          )}
                          options={dropdowns.lstProviderType}
                          label="Choose Provider Type ..."
                          textFieldProps={{
                            id: "provTypeprovTypeDes",
                            label: "Provider Type",
                            InputLabelProps: {
                              className: classes.label,
                              shrink: true,
                            },
                          }}
                          className={classes.textFieldSelect}
                          handleChange={this.props.handleSelect(
                            "provType",
                            "claimProvidersList",
                            this.state.rowIndex
                          )}
                          classes={classes}
                          isDisabled={true}
                        />
                      </div>
                      <div>
                        <Select
                          components={components}
                          propertyName={dropdowns.lstEntityType.filter(
                            (option) =>
                              option.value === selectedVo.provEntityType
                          )}
                          options={dropdowns.lstEntityType}
                          label="Choose Entity Type ..."
                          textFieldProps={{
                            id: "provEntityType",
                            label: "Entity Type",
                            InputLabelProps: {
                              className: classes.label,
                              shrink: true,
                            },
                          }}
                          className={classes.textFieldSelect}
                          handleChange={this.props.handleSelect(
                            "provEntityType",
                            "claimProvidersList",
                            this.state.rowIndex
                          )}
                          classes={classes}
                          isDisabled={true}
                        />
                      </div>

                      <div>
                        <InputField
                          name="provOthPayerId"
                          id="claimProvidersList_provOthPayerId"
                          label="Other Payer ID"
                          disabled={true}
                          value={selectedVo.provOthPayerId}
                          onChange={this.props.handleChange(
                            "claimProvidersList",
                            this.state.rowIndex
                          )}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div />
                      <div>
                        <InputField
                          name="provLocNbr"
                          id="claimProvidersList_provLocNbr"
                          label="Loc Nbr"
                          disabled={true}
                          value={selectedVo.provLocNbr}
                          onChange={this.props.handleChange(
                            "claimProvidersList",
                            this.state.rowIndex
                          )}
                        />
                        <div className={classes.validationMessage}></div>
                      </div>
                      <div>
                        <InputField
                          name="provLicNbr"
                          id="claimProvidersList_provLicNbr"
                          label="License Nbr"
                          disabled={true}
                          value={selectedVo.provLicNbr}
                          onChange={this.props.handleChange(
                            "claimProvidersList",
                            this.state.rowIndex
                          )}
                        />
                        <div className={classes.validationMessage}></div>
                      </div>
                      <div>
                        <InputField
                          name="provUpin"
                          id="claimProvidersList_provUpin"
                          label="UPIN"
                          disabled={true}
                          value={selectedVo.provUpin}
                          onChange={this.props.handleChange(
                            "claimProvidersList",
                            this.state.rowIndex
                          )}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <InputField
                          name="provCommNbr"
                          id="claimProvidersList_provCommNbr"
                          label="Comm Nbr"
                          disabled={true}
                          value={selectedVo.provCommNbr}
                          onChange={this.props.handleChange(
                            "claimProvidersList",
                            this.state.rowIndex
                          )}
                        />
                        <div className={classes.validationMessage}></div>
                      </div>
                      <div>
                        <InputField
                          name="provTaxonomyCd"
                          id="claimProvidersList_provTaxonomyCd"
                          label="Taxonomy"
                          disabled={true}
                          value={selectedVo.provTaxonomyCd}
                          onChange={this.props.handleChange(
                            "claimProvidersList",
                            this.state.rowIndex
                          )}
                        />
                        <div className={classes.validationMessage}></div>
                      </div>
                      <div>
                        <InputField
                          name="provNpi"
                          id="claimProvidersList_provNpi"
                          label="NPI"
                          disabled={true}
                          value={selectedVo.provNpi}
                          onChange={this.props.handleChange(
                            "claimProvidersList",
                            this.state.rowIndex
                          )}
                        />
                        <div className={classes.validationMessage}></div>
                      </div>
                    </div>
                  </div>
                </div>
                </div>
              </div>
            </ExpansionPanel>
          </div>
        ) : null}
      </React.Fragment>
    );
  }
}

export default withStyles(Styles)(ClaimProvider);
