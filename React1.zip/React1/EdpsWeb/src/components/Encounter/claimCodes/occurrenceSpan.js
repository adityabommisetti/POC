import { withStyles } from "@material-ui/core/styles";
import isEmpty from "lodash/isEmpty";
import React, { Component } from "react";
import { connect } from "react-redux";
import { styles as Styles } from "../../../assets/styles/DataTableStyle";
import Modal from "../../../components/UI/Modal/Modal";
import { OCURRENCE_SPAN_UPDATE } from "../../../constants/header/encounterDetailsHeader";
import { addOccurrenceSpan, deleteOccurrenceSpan, getOccurrenceSpan, updateOccurrenceSpan } from "../../../redux/actions/ClaimCodeAction";
import * as DateUtil from "../../../utils/DatePicker";
import ClaimCodeTable from "../../Home/ClaimCodeTable";
import SimpleReactValidator from "simple-react-validator";
import { customValidations } from "../../../utils/CustomValidations";

const dateChk = {};

class OccurrenceSpan extends Component {
    constructor(props) {
        super(props);
        this.validator = new SimpleReactValidator({
            validators: {
                date_format: customValidations.date_format,
                date_after: customValidations.date_after
            },
        });
        this.state = {
            selectedRow: 0,
            showModal: false,
            message: "",
            disabled: true,
            index: "",
            occurAddVo: {
                mfId: this.props.selectedRowData.mfId,
                wtxClaimRefNbr: this.props.selectedRowData.wtxClaimRefNbr,
                wtxClaimRevNbr: this.props.selectedRowData.wtxClaimRevNbr,
                clmSeqNbr: this.props.selectedRowData.claimSeqNbr,
                claimType: this.props.selectedRowData.claimType,
                occurSpanCd: "",
                formattedOccurSpanToDate: "",
                formattedOccurSpanFromDate: "",
                encType: this.props.selectedRowData.encType
            },
            occurUpdateVo: [],
        };
    };

    async componentDidMount() {
        await this.props.getOccurrenceSpan(this.props.selectedRowData);
        if (!isEmpty(this.props.occurnceData)) {
            this.setState({
                occurUpdateVo: [...this.props.occurnceData]
            })
        }
    };

    async UNSAFE_componentWillReceiveProps(nextProps, prevState) {
        if (nextProps.selectedRowData &&
            (this.state.selectedRow !== nextProps.selectedRowData.wtxClaimRefNbr)) {
            await this.props.getOccurrenceSpan(nextProps.selectedRowData);
            this.setState({
                occurUpdateVo: [...nextProps.occurnceData],
                selectedRow: nextProps.selectedRowData.wtxClaimRefNbr
            })
        }
    };

    handleEdit = async (list, index, e) => {
        e.preventDefault();
        if (index === this.state.index) {
            await this.save(list, index, e);
        }
        else {
            await this.update(list, index);
        }
    };

    handlechangeUpdate = (name, target) => e => {
        let value = e.target
            ? e.target.value.toUpperCase()
            : e.value.toUpperCase();
        let targetVo = target;
        if (targetVo === "occurUpdateVo") {
            const OccurrenceSpanList = [...this.state.occurUpdateVo];
            OccurrenceSpanList[this.state.index] = { ...OccurrenceSpanList[this.state.index], [name]: value }
            this.setState({
                occurUpdateVo: [...OccurrenceSpanList],
                check: false
            });
        }
        else {
            this.setState(prevState => ({
                occurAddVo: {
                    ...prevState.occurAddVo,
                    [name]: value
                }
            }));
        }
    };

    handleDelete = async (list, index, e) => {
        e.preventDefault();
        if (index === this.state.index) {
            await this.cancel(list, index, e);
        }
        else {
            await this.deleteOccurrenceSpan(list, index, e);
        }
    };

    update = (list, index) => {
        this.setState(prevState => ({
            disabled: false,
            index: index
        }));
    };

    save = async (list, i, e) => {
        e.preventDefault();
        console.log(this.validator)
        if (i === this.state.index) {
            if (!this.validator.allValid()) {
                this.validator.showMessages();
                this.forceUpdate();
            }
            else {
                const saveStatus = await this.props.updateOccurrenceSpan(list);
                if (saveStatus.status === "200") {
                    this.setState({
                        occurUpdateVo: [...this.props.occurnceData],
                        closePopup: true,
                        index: "",
                        message: saveStatus.message,
                        disabled: false,
                    });
                }
                else {
                    this.setState({
                        closePopup: true,
                        message: saveStatus.message
                    });
                }
                this.validator.hideMessages();
                this.forceUpdate();
            }
        }
    };

    cancel = (index) => {
        this.setState({
            occurUpdateVo: [...this.props.occurnceData],
            disabled: true,
            index: ""
        });
        this.validator.hideMessages();
        this.forceUpdate();
    };

    deleteOccurrenceSpan = async (list, index, e) => {
        e.preventDefault();
        const deleteStatus = await this.props.deleteOccurrenceSpan(list);
        if (deleteStatus.status === "200") {
            this.setState({
                occurUpdateVo: [...this.props.occurnceData],
                closePopup: true,
                message: deleteStatus.message,
                index: "",
                disabled: false,
            });
        }
        else {
            this.setState({
                closePopup: true,
                message: deleteStatus.message
            });
        }
        this.validator.hideMessages();
        this.forceUpdate();
    };

    handleAdd = async (e) => {
        e.preventDefault();
        this.setState({ index: "" })
        if (!this.validator.allValid()) {
            this.validator.showMessages();
            this.forceUpdate();
        }
        else {
            const addStatus = await this.props.addOccurrenceSpan(this.state.occurAddVo);
            if (addStatus.status === "200") {
                this.setState(prevState => ({
                    occurAddVo: {
                        ...prevState.occurAddVo,
                        occurSpanCd: "",
                        formattedOccurSpanToDate: "",
                        formattedOccurSpanFromDate: "",
                    },
                    occurUpdateVo: [...this.props.occurnceData],
                    closePopup: true,
                    index: "",
                    message: addStatus.message
                }));
            }
            else {
                this.setState({
                    closePopup: true,
                    message: addStatus.message
                });
            }
            this.validator.hideMessages();
            this.forceUpdate();
        }
    }

    modalClosed = () => {
        this.setState({ closePopup: false })
    };


    handleDates = (index, targetVo) => (event) => {
        var self = this;
        let dateId = "#" + event.target.id;
        DateUtil.getDatePicker(dateId).datepicker('show').on("change", e => {
            if (dateChk.name !== e.target.name || dateChk.value !== e.target.value) {
                self.setDate(e.target.name, e.target.value, index, targetVo);
            }
            dateChk.name = e.target.name;
            dateChk.value = e.target.value;
        });
    };

    setDate = (name, value, index, targetVo) => {
        if (targetVo === "occurUpdateVo") {
            const OccurrenceSpanList = [...this.state.occurUpdateVo];
            OccurrenceSpanList[index] = { ...OccurrenceSpanList[index], [name]: value }
            this.setState({
                occurUpdateVo: [...OccurrenceSpanList],
            });
        }
        else {
            this.setState(prevState => ({
                occurAddVo: {
                    ...prevState.occurAddVo,
                    [name]: value
                }
            }));
        }
    };

    handleSearchFieldChange = name => event => {
        let value = event.target
            ? event.target.value.toUpperCase()
            : event.value.toUpperCase();

        if (name === "formattedOccurSpanToDate" ||
            name === "formattedOccurSpanFromDate" &&
            value.length === 8) {
            value = value.replace(/[^0-9]/g, "").trim();
            value = value.replace(/^(\d{2})/, "$1/");
            value = value.replace(/\/(\d{2})/, "/$1/");
            value = value.replace(/(\d)\/(\d{4}).*/, "$1/$2");
        }
        this.setState(prevState => ({
            occurUpdateVo: {
                ...prevState.occurUpdateVo,
                [name]: value
            },
            collapseSearch: false
        }));
    };

    render() {
        const { classes } = this.props;
        const { occurUpdateVo, disabled, index, message, closePopup, occurAddVo } = this.state;

        return (
            <div class="panel-body">
                <Modal dialogTitle='Occurrence Span'
                    message={message}
                    show={closePopup}
                    modalClosed={this.modalClosed}>
                </Modal>
                <div style={{ width: "117%", alignSelf: "stretch", marginInlineStart:"100px" }}>
                    <div className={classes.tableWrapper} style={{ width: "117%"}}>
                        <ClaimCodeTable
                            updateData={occurUpdateVo}
                            addData={occurAddVo}                        
                            header={OCURRENCE_SPAN_UPDATE}
                            editable={this.props.editable}
                            updateTargetVo="occurUpdateVo"
                            addTargetVo="occurAddVo"
                            tableName="OCCURRENCE SPAN"
                            disabled={disabled}
                            index={index}
                            validator={this.validator}
                            handleDates={this.handleDates}
                            handlechangeUpdate={this.handlechangeUpdate}
                            handleEdit={this.handleEdit}
                            handleDelete={this.handleDelete}
                            handleAdd={this.handleAdd}
                        />
                    </div>
                </div>
            </div>)
    }
}

const mapStateToProps = state => {
    return {
        occurnceData: state.ClaimCodeReducer.claim_OccurrenceSpan_data,
    };
};

const mapDispatchToProps = {
    addOccurrenceSpan,
    deleteOccurrenceSpan,
    getOccurrenceSpan,
    updateOccurrenceSpan
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(withStyles(Styles)(OccurrenceSpan));