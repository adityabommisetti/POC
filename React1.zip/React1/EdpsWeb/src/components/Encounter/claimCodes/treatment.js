import { withStyles } from "@material-ui/core/styles";
import React, { Component } from "react";
import { connect } from "react-redux";
import { styles as Styles } from "../../../assets/styles/DataTableStyle";
import Modal from "../../../components/UI/Modal/Modal";
import { TREATMENT_TABLE_UPDATE } from "../../../constants/header/encounterDetailsHeader";
import { getTreatment, addTreatment, updateTreatment, deleteTreatment } from "../../../redux/actions/ClaimCodeAction";
import ClaimCodeTable from "../../Home/ClaimCodeTable";
import SimpleReactValidator from "simple-react-validator";
import { customValidations } from "../../../utils/CustomValidations";


class Treatment extends Component {
    constructor(props) {
        super(props);
        this.validator = new SimpleReactValidator({
            validators: {
              date_format: customValidations.date_format,
              date_after: customValidations.date_after
            },
          });
        this.state = {
            selectedRow: this.props.selectedRowData.wtxClaimRefNbr,
            showModal: false,
            message: "",
            disabled: true,
            index: "",
            treatAddVo: {
                mfId: this.props.selectedRowData.mfId,
                wtxClaimRefNbr: this.props.selectedRowData.wtxClaimRefNbr,
                wtxClaimRevNbr: this.props.selectedRowData.wtxClaimRevNbr,
                clmSeqNbr: this.props.selectedRowData.claimSeqNbr,
                claimType: this.props.selectedRowData.claimType,
                treatmentCd: "",
                encType: this.props.selectedRowData.encType

            },
            treatUpdateVo: {
                mfId: "",
                wtxClaimRefNbr: "",
                wtxClaimRevNbr: null,
                clmSeqNbr: null,
                treatSeqNbr: null,
                claimType: "",
                treatmentCd: "",
                encType: ""

            }
        };
    };

    async componentDidMount() {
        await this.props.getTreatment(this.props.selectedRowData);
        if (this.props.treatmentData) {
            this.setState({
                treatUpdateVo: [...this.props.treatmentData],
            });
        }
    };

    async UNSAFE_componentWillReceiveProps(nextProps, prevState) {
        if (nextProps.selectedRowData &&
            (this.state.selectedRow !== nextProps.selectedRowData.wtxClaimRefNbr)) {
            await this.props.getTreatment(nextProps.selectedRowData);
            this.setState({
                treatUpdateVo: [...nextProps.treatmentData],
                selectedRow: nextProps.selectedRowData.wtxClaimRefNbr
            })
        }
    };

    handleEdit = async (list, index, e) => {
        e.preventDefault();
        if (index === this.state.index) {
            await this.save(list, index, e);
        }
        else {
            await this.update(list, index);
        }
    };

    handlechangeUpdate = (name, target) => e => {
        let value = e.target
            ? e.target.value.toUpperCase()
            : e.value.toUpperCase();
        let targetVo = target;
        console.log(this.state.index);
        if (targetVo === "treatUpdateVo") {
            const TreatmentList = [...this.state.treatUpdateVo];
            TreatmentList[this.state.index] = { ...TreatmentList[this.state.index], [name]: value }
            this.setState({
                treatUpdateVo: [...TreatmentList],
                check: false
            });
        }
        else {
            this.setState(prevState => ({
                treatAddVo: {
                    ...prevState.treatAddVo,
                    [name]: value
                }
            }));
        }
    };

    handleDelete = async (list, index, e) => {
        e.preventDefault();
        if (index === this.state.index) {
            await this.cancel(list, index, e);
        }
        else {
            await this.deleteTreatment(list, index, e);
        }
    };

    update = (list, index) => {
        this.setState(prevState => ({
            disabled: false,
            index: index
        }));
    };

    save = async (list, i, e) => {
        e.preventDefault();
        if (!this.validator.allValid()) {
            this.validator.showMessages();
            this.forceUpdate();
          }
          else {
        if (i === this.state.index) {
            const saveStatus = await this.props.updateTreatment(list);
            if (saveStatus.status === "200") {
                this.setState({
                    treatUpdateVo: [...this.props.treatmentData],
                    closePopup: true,
                    index: "",
                    message: saveStatus.message,
                    disabled: false,
                });
            }
            else {
                this.setState({
                    closePopup: true,
                    message: saveStatus.message
                });
            }
            this.validator.hideMessages();
            this.forceUpdate();
        }
        }
    };

    cancel = (index) => {
        this.setState({
            treatUpdateVo: [...this.props.treatmentData],
            disabled: true,
            index: ""
        });
        this.validator.hideMessages();
        this.forceUpdate();
    };

    deleteTreatment = async (list, index, e) => {
        e.preventDefault();
        const deleteStatus = await this.props.deleteTreatment(list);
        if (deleteStatus.status === "200") {
            this.setState({
                treatUpdateVo: [...this.props.treatmentData],
                closePopup: true,
                message: deleteStatus.message,
                index: "",
                disabled: false,
            });
        }
        else {
            this.setState({
                closePopup: true,
                message: deleteStatus.message
            });
        }
        this.validator.hideMessages();
        this.forceUpdate();
    };

    handleAdd = async (e) => {
        e.preventDefault();
        if (this.validator.allValid()) {
        const addStatus = await this.props.addTreatment(this.state.treatAddVo);
        if (addStatus.status === "200") {
            this.setState(prevState => ({
                treatAddVo: {
                    ...prevState.treatAddVo,
                    treatmentCd: ""
                },
                treatUpdateVo: [...this.props.treatmentData],
                closePopup: true,
                index: "",
                message: addStatus.message
            }));
        }
        else {
            this.setState({
                closePopup: true,
                message: addStatus.message
            });
        }
        this.validator.hideMessages();
        this.forceUpdate();
    }
    else {
        this.validator.showMessages();
        this.forceUpdate();
    }
}

    modalClosed = () => {
        this.setState({ closePopup: false })
    };

    render() {
        const { classes } = this.props;
        const { treatUpdateVo, disabled, index, message, closePopup, treatAddVo } = this.state;

        return (
            <div class="panel-body">
                <Modal dialogTitle='TREATMENT'
                    message={message}
                    show={closePopup}
                    modalClosed={this.modalClosed}>
                </Modal>
                <div style={{ width: "100%", alignSelf: "stretch", marginInlineStart:"200px" }}>
                    <div className={classes.tableWrapper} style={{ width: "100%" }}>
                        <ClaimCodeTable
                            updateData={treatUpdateVo}
                            addData={treatAddVo}
                            header={TREATMENT_TABLE_UPDATE}
                            editable={this.props.editable}
                            updateTargetVo="treatUpdateVo"
                            addTargetVo="treatAddVo"
                            tableName="TREATMENT"
                            disabled={disabled}
                            index={index}
                            validator={this.validator}
                            handleDates={this.handleDates}
                            handlechangeUpdate={this.handlechangeUpdate}
                            handleEdit={this.handleEdit}
                            handleDelete={this.handleDelete}
                            handleAdd={this.handleAdd}
                        />
                    </div>
                </div>
            </div>)
    }
}

const mapStateToProps = state => {
    return {
        treatmentData: state.ClaimCodeReducer.claim_treatment_data,
    };
};

const mapDispatchToProps = {
    getTreatment,
    addTreatment,
    updateTreatment,
    deleteTreatment
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(withStyles(Styles)(Treatment));