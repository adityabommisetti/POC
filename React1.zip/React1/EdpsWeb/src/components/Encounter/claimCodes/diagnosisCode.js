import { withStyles } from "@material-ui/core/styles";
import React, { Component } from "react";
import isEmpty from "lodash/isEmpty";
import { connect } from "react-redux";
import { styles as Styles } from "../../../assets/styles/DataTableStyle";
import Modal from "../../../components/UI/Modal/Modal";
import { DIAGNOSIS_PROFESSIONAL_UPDATE, DIAGNOSIS_INSTITUTIONAL_UPDATE } from "../../../constants/header/encounterDetailsHeader";
import { getDiagnosisCode, addDiagnosisCode, deleteDiagnosisCode, updateDiagnosisCode } from "../../../redux/actions/ClaimCodeAction";
import ClaimCodeTable from "../../Home/ClaimCodeTable";
import SimpleReactValidator from "simple-react-validator";
import { customValidations } from "../../../utils/CustomValidations";


const styles = theme => ({
    ...Styles(theme),
    headerCellAttestation: {
        color: "white",
        paddingRight: 4,
        paddingLeft: 5
    },
    validationMessage: {
        color: "red",
        fontSize: "12px"
    }
});
const dateChk = {};

class DiagnosisCode extends Component {
    constructor(props) {
        super(props);
        this.validator = new SimpleReactValidator({
            validators: {
              date_format: customValidations.date_format,
              date_after: customValidations.date_after,
              principleCode : customValidations.principleCode
            },
          });
        this.state = {
            selectedRow: this.props.selectedRowData.wtxClaimRefNbr,
            showModal: false,
            message: "",
            disabled: true,
            index: "",
            diagAddVO: {
                mfId: this.props.selectedRowData.mfId,
                wtxClaimRefNbr: this.props.selectedRowData.wtxClaimRefNbr,
                wtxClaimRevNbr: this.props.selectedRowData.wtxClaimRevNbr,
                claimSeqNbr: this.props.selectedRowData.claimSeqNbr,
                claimType: this.props.selectedRowData.claimType,
                diagnosisType: "",
                diagnosisCode: "",
                encType: this.props.selectedRowData.encType,
                presentOnAdmitInd: ""
            },
            diagUpdateVO: {
                mfId: "",
                wtxClaimRefNbr: "",
                wtxClaimRevNbr: null,
                claimSeqNbr: null,
                claimType: "",
                diagnosisSeqNbr: null,
                diagnosisCode: "",
                diagnosisType: "",
                riskDiagFlag: "",
                encType: ""
            }
        };
    };
    
    async componentDidMount() {
        await this.props.getDiagnosisCode(this.props.selectedRowData);
        if (!isEmpty(this.props.diagnosisData)) {
            this.setState({
                diagUpdateVO: [...this.props.diagnosisData],
            });
        }
    };


    async UNSAFE_componentWillReceiveProps(nextProps, prevState) {
        if (nextProps.selectedRowData &&
            (this.state.selectedRow !== nextProps.selectedRowData.wtxClaimRefNbr)) {
            await this.props.getDiagnosisCode(nextProps.selectedRowData);
            this.setState({
                diagUpdateVO: [...nextProps.diagnosisData],
                selectedRow: nextProps.selectedRowData.wtxClaimRefNbr
            })
        }
    };

    handleEdit = async (list, index, e) => {
        e.preventDefault();
        if (index === this.state.index) {
            await this.save(list, index, e);
        }
        else {
            await this.update(list, index);
        }
    };

    handlechangeUpdate = (name, target) => e => {
        let value = e.target
            ? e.target.value.toUpperCase()
            : e.value.toUpperCase();
        let targetVo = target;
        if (targetVo === "diagUpdateVO") {
            const DiagnosisCodeList = [...this.state.diagUpdateVO];
            DiagnosisCodeList[this.state.index] = { ...DiagnosisCodeList[this.state.index], [name]: value }
            this.setState({
                diagUpdateVO: [...DiagnosisCodeList],
                check: false
            });
        }
        else {
            this.setState(prevState => ({
                diagAddVO: {
                    ...prevState.diagAddVO,
                    [name]: value
                }
            }));
        }
    };

    handleDelete = async (list, index, e) => {
        e.preventDefault();
        if (index === this.state.index) {
            await this.cancel(list, index, e);
        }
        else {
            await this.deleteDiagnosis(list, index, e);
        }
    };
    update = (list, index) => {
        this.setState(prevState => ({
            disabled: false,
            index: index
        }));
    };

    save = async (list, i, e) => {
        e.preventDefault();
        if (!this.validator.allValid()) {
            this.validator.showMessages();
            this.forceUpdate();
          }
          else {
        if (i === this.state.index) {
            const saveStatus = await this.props.updateDiagnosisCode(list);
            if (saveStatus.status === "200") {
                this.setState({
                    diagUpdateVO: [...this.props.diagnosisData],
                    closePopup: true,
                    index: "",
                    message: saveStatus.message,
                    disabled: false,
                });
            }
            else {
                this.setState({
                    closePopup: true,
                    message: saveStatus.message
                });
            }
            this.validator.hideMessages();
            this.forceUpdate();
        }
     }
    };

    cancel = (index) => {
        this.setState({
            diagUpdateVO: [...this.props.diagnosisData],
            disabled: true,
            index: ""
        });
        this.validator.hideMessages();
        this.forceUpdate();
    };

    deleteDiagnosis = async (list, index, e) => {
        e.preventDefault();
        const deleteStatus = await this.props.deleteDiagnosisCode(list);
        if (deleteStatus.status === "200") {
            this.setState({
                diagUpdateVO: [...this.props.diagnosisData],
                closePopup: true,
                message: deleteStatus.message,
                index: "",
                disabled: false,
            });
        }
        else {
            this.setState({
                closePopup: true,
                message: deleteStatus.message
            });
        }
        this.validator.hideMessages();
        this.forceUpdate();
    };

    handleAdd = async (e) => {
        e.preventDefault();
        if (this.validator.allValid()) {
        const addStatus = await this.props.addDiagnosisCode(this.state.diagAddVO);
        if (addStatus.status === "200") {
            this.setState(prevState => ({
                diagAddVO: {
                    ...prevState.diagAddVO,
                    diagnosisType: "",
                    diagnosisCode: "",
                    presentOnAdmitInd: "",
                    riskDiagFlag: ""
                },
                diagUpdateVO: [...this.props.diagnosisData],
                closePopup: true,
                index: "",
                message: addStatus.message
            }));
        }
        else {
            this.setState({

                closePopup: true,
                message: addStatus.message
            });
        }
        this.validator.hideMessages();
        this.forceUpdate();
      }
      else {
        this.validator.showMessages();
        this.forceUpdate();
    }
    }

    modalClosed = () => {
        this.setState({ closePopup: false })
    };

    render() {
        const { classes, selectedRowData } = this.props;
        const { diagUpdateVO, disabled, index, message, closePopup, diagAddVO } = this.state;
        return (
            <div class="panel-body">
                <Modal dialogTitle='Diagnosis Code'
                    message={message}
                    show={closePopup}
                    modalClosed={this.modalClosed}>
                </Modal>
                <div style={{ width: "150%", alignSelf: "stretch" }}>
                    <div className={classes.tableWrapper} style={{ width: "110%" }}>
                        <ClaimCodeTable
                            updateData={diagUpdateVO}                    
                            addData={diagAddVO}
                            editable={this.props.editable}
                            header={selectedRowData.encType ==="P"||
                            selectedRowData.encType ==="E"?
                            DIAGNOSIS_PROFESSIONAL_UPDATE: DIAGNOSIS_INSTITUTIONAL_UPDATE}
                            editable={this.props.editable}
                            updateTargetVo="diagUpdateVO"
                            addTargetVo="diagAddVO"
                            tableName="DIAGNOSIS"
                            disabled={disabled}
                            index={index}
                            validator={this.validator}
                            handlechangeUpdate={this.handlechangeUpdate}
                            handleEdit={this.handleEdit}
                            handleDelete={this.handleDelete}
                            handleAdd={this.handleAdd}
                        />
                    </div>
                </div>
            </div>)
    }
}




const mapStateToProps = state => {
    return {
        diagnosisData: state.ClaimCodeReducer.claim_diagnosis_data,
    }
};

const mapDispatchToProps = {
    getDiagnosisCode,
    addDiagnosisCode,
    deleteDiagnosisCode,
    updateDiagnosisCode
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(withStyles(styles)(DiagnosisCode));