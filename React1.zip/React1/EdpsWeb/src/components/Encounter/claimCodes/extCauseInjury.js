import { withStyles } from "@material-ui/core/styles";
import React, { Component } from "react";
import { connect } from "react-redux";
import { styles } from "../../../assets/styles/DataTableStyle";
import Modal from "../../../components/UI/Modal/Modal";
import { EXT_CAUSE_INJURY_UPDATE } from "../../../constants/header/encounterDetailsHeader";
import ClaimCodeTable from "../../Home/ClaimCodeTable";
import { getClmExtCauseCd, addClmExtCauseCd, updateClmExtCauseCd, deleteClmExtCauseCd } from "../../../redux/actions/ClaimCodeAction";
import SimpleReactValidator from "simple-react-validator";
import { customValidations } from "../../../utils/CustomValidations";


class ExtCauseInjury extends Component {
    constructor(props) {
        super(props);
        this.validator = new SimpleReactValidator({
            validators: {
              date_format: customValidations.date_format,
              date_after: customValidations.date_after
            },
          });
        this.state = {
            selectedRow: this.props.selectedRowData.wtxClaimRefNbr,
            message: "",
            disabled: true,
            closePopup: false,
            index: "",
            ExtCauseInjuryUpdateVO: {
                mfId: "",
                wtxClaimRefNbr: "",
                wtxClaimRevNbr: null,
                clmSeqNbr: null,
                extinjSeqNbr: null,
                extcauseofinjuryType: "",
                extcauseofinjuryCd: "",
                presentOnAdmitInd: "",
                lastUpdtTime: "",
                lastUpdtUserid: "",
                claimType: "",
                encType: ""
            },
            ExtCauseInjuryAddVO: {
                mfId: this.props.selectedRowData.mfId,
                wtxClaimRefNbr: this.props.selectedRowData.wtxClaimRefNbr,
                wtxClaimRevNbr: this.props.selectedRowData.wtxClaimRevNbr,
                clmSeqNbr: this.props.selectedRowData.claimSeqNbr,
                claimType: this.props.selectedRowData.claimType,
                extcauseofinjuryType: "",
                extcauseofinjuryCd: "",
                presentOnAdmitInd: "",
                encType: this.props.selectedRowData.encType

            },

        };

    };

    async componentDidMount() {
        await this.props.getClmExtCauseCd(this.props.selectedRowData)
        if (this.props.ExtCauseInjuryData) {
            this.setState({
                ExtCauseInjuryUpdateVO: [...this.props.ExtCauseInjuryData],
            });
        }
    };

    async UNSAFE_componentWillReceiveProps(nextProps, prevState) {
        if (nextProps.selectedRowData &&
            (this.state.selectedRow !== nextProps.selectedRowData.wtxClaimRefNbr)) {
            await this.props.getClmExtCauseCd(nextProps.selectedRowData);
            this.setState({
                ExtCauseInjuryUpdateVO: [...nextProps.ExtCauseInjuryData],
                selectedRow: nextProps.selectedRowData.wtxClaimRefNbr
            })
        }
    };

    handleEdit = async (list, index, e) => {
        e.preventDefault();
        if (index === this.state.index) {
            await this.save(list, index, e);
        }
        else {
            await this.update(index, e);
        }
    };

    handlechangeUpdate = (name, target) => e => {
        let value = e.target
            ? e.target.value.toUpperCase()
            : e.value.toUpperCase();
        let targetVo = target;
        if (targetVo === "ExtCauseInjuryUpdateVO") {
            const extCauseCodeList = [...this.state.ExtCauseInjuryUpdateVO];
            extCauseCodeList[this.state.index] = { ...extCauseCodeList[this.state.index], [name]: value }
            this.setState({
                ExtCauseInjuryUpdateVO: [...extCauseCodeList],
                check: false
            });
        }
        else {
            this.setState(prevState => ({
                ExtCauseInjuryAddVO: {
                    ...prevState.ExtCauseInjuryAddVO,
                    [name]: value
                }
            }));
        }
    };

    handleDelete = async (list, index, e) => {
        e.preventDefault();
        if (index === this.state.index) {
            await this.cancel();
        }
        else {
            await this.delete(list, e);
        }
    };

    update = async (index, e) => {
        e.preventDefault();
        this.setState({
            disabled: false,
            index: index
        });
    }

    save = async (data, i, e) => {
        e.preventDefault();
        if (!this.validator.allValid()) {
            this.validator.showMessages();
            this.forceUpdate();
          }
          else {
        if (i === this.state.index) {
            const saveStatus = await this.props.updateClmExtCauseCd(data);
            if (saveStatus.status === "200") {
                this.setState({
                    ExtCauseInjuryUpdateVO: [...this.props.ExtCauseInjuryData],
                    closePopup: true,
                    index: "",
                    message: saveStatus.message,
                    disabled: false,
                });
            }
            else {
                this.setState({
                    closePopup: true,
                    message: saveStatus.message
                });
            }
            this.validator.hideMessages();
            this.forceUpdate();
        }
    }
    }

    cancel = () => {
        this.setState({
            ExtCauseInjuryUpdateVO: [...this.props.ExtCauseInjuryData],
            disabled: true,
            index: ""
        });
        this.validator.hideMessages();
        this.forceUpdate();
    };

    delete = async (data, e) => {
        e.preventDefault();
        const deleteStatus = await this.props.deleteClmExtCauseCd(data);
        if (deleteStatus.status === "200") {
            this.setState({
                closePopup: true,
                message: deleteStatus.message,
                indesx: "",
                disabled: false,
                ExtCauseInjuryUpdateVO: [...this.props.ExtCauseInjuryData]
            });
        }
        else {
            this.setState({
                closePopup: true,
                message: deleteStatus.message
            });
        }
        this.validator.hideMessages();
        this.forceUpdate();
    }

    handleAdd = async (e) => {
        e.preventDefault();
        if ((this.state.ExtCauseInjuryAddVO.extcauseofinjuryType !== "") &&
            (this.state.ExtCauseInjuryAddVO.extcauseofinjuryCd !== "") &&
            (this.state.ExtCauseInjuryAddVO.presentOnAdmitInd !== "")&& (this.validator.allValid())) {
            const status = await this.props.addClmExtCauseCd(this.state.ExtCauseInjuryAddVO);
            if (status.status === "200") {
                this.setState(prevState => ({
                    ExtCauseInjuryAddVO: {
                        ...prevState.ExtCauseInjuryAddVO,
                        extcauseofinjuryType: "",
                        extcauseofinjuryCd: "",
                        presentOnAdmitInd: "",
                    },
                    ExtCauseInjuryUpdateVO: [...this.props.ExtCauseInjuryData],
                    message: status.message,
                    closePopup: true,
                    index: ""
                }));
            }
            else {
                this.setState({
                    closePopup: true,
                    message: status.message
                });
            }
                this.validator.hideMessages();
                this.forceUpdate();
              }
              else {
                this.validator.showMessages();
                this.forceUpdate();
            }
        }

    modalClosed = () => {
        this.setState({ closePopup: false })
    }

    render() {
        const { classes } = this.props;
        const { ExtCauseInjuryUpdateVO, disabled, index, message, closePopup, ExtCauseInjuryAddVO } = this.state;
        return (

            <div class="panel-body">
                <Modal
                    dialogTitle="External Cause Of injury"
                    message={message}
                    show={closePopup}
                    modalClosed={this.modalClosed} />

                <div style={{width: "115%", alignSelf: "stretch", marginInlineStart:"110px" }}>
                    <div className={classes.tableWrapper} style={{ width: "115%" }}>
                        <ClaimCodeTable
                            updateData={ExtCauseInjuryUpdateVO}
                            addData={ExtCauseInjuryAddVO}
                            header={EXT_CAUSE_INJURY_UPDATE}
                            editable={this.props.editable}
                            updateTargetVo="ExtCauseInjuryUpdateVO"
                            addTargetVo="ExtCauseInjuryAddVO"
                            tableName="EXTERNAL CAUSE OF INJURY"
                            disabled={disabled}
                            index={index}
                            validator={this.validator}
                            handlechangeUpdate={this.handlechangeUpdate}
                            handleEdit={this.handleEdit}
                            handleDelete={this.handleDelete}
                            handleAdd={this.handleAdd}
                        />
                    </div>
                </div>
            </div>
        );
    }
}

const mapStateToProps = state => {
    return {
        ExtCauseInjuryData: state.ClaimCodeReducer.claim_Ext_Cause_Injury_Data
    };
};
const mapDispatchToProps = {
    getClmExtCauseCd,
    addClmExtCauseCd,
    updateClmExtCauseCd,
    deleteClmExtCauseCd
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(withStyles(styles)(ExtCauseInjury));