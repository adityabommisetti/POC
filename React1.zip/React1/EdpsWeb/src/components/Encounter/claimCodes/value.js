import { withStyles } from "@material-ui/core/styles";
import React, { Component } from "react";
import { connect } from "react-redux";
import { styles } from "../../../assets/styles/DataTableStyle";
import Modal from "../../../components/UI/Modal/Modal";
import { VALUE_CODE_UPDATE } from "../../../constants/header/encounterDetailsHeader";
import ClaimCodeTable from "../../Home/ClaimCodeTable";
import * as DateUtil from '../../../utils/DatePicker'
import { getValue, addValue, updateValue, deleteValue } from "../../../redux/actions/ClaimCodeAction";
import SimpleReactValidator from "simple-react-validator";
import { customValidations } from "../../../utils/CustomValidations";

const dateChk = {};
class ValueCode extends Component {
    constructor(props) {
        super(props);
        this.validator = new SimpleReactValidator({
            validators: {
              date_format: customValidations.date_format,
              date_after: customValidations.date_after
            },
          });
        this.state = {
            selectedRow: this.props.selectedRowData.wtxClaimRefNbr,
            message: "",
            disabled: true,
            closePopup: false,
            index: -1,
            valueAddVO: {
                mfId: this.props.selectedRowData.mfId,
                wtxClaimRefNbr: this.props.selectedRowData.wtxClaimRefNbr,
                wtxClaimRevNbr: this.props.selectedRowData.wtxClaimRevNbr,
                clmSeqNbr: this.props.selectedRowData.claimSeqNbr,
                claimType: this.props.selectedRowData.claimType,
                valueCd: "",
                valueCdAmt: "",
                encType: this.props.selectedRowData.encType
            },
            valueUpdateVO: {
                mfId: "",
                wtxClaimRefNbr: "",
                wtxClaimRevNbr: null,
                clmSeqNbr: null,
                valueSeqNbr: null,
                valueCd: "",
                valueCdAmt: null,
                lastUpdtTime: "",
                lastUpdtUserid: "",
                encType: null,
                claimType: ""
            }
        };
    };

    async componentDidMount() {
        await this.props.getValue(this.props.selectedRowData)
        if (this.props.ValueData) {
            this.setState({
                valueUpdateVO: [...this.props.ValueData],
            });
        }
    };

    async UNSAFE_componentWillReceiveProps(nextProps, prevState) {
        if (nextProps.selectedRowData &&
            (this.state.selectedRow !== nextProps.selectedRowData.wtxClaimRefNbr)) {
            await this.props.getValue(nextProps.selectedRowData);
            this.setState({
                valueUpdateVO: [...nextProps.ValueData],
                selectedRow: nextProps.selectedRowData.wtxClaimRefNbr
            })
        }
    };

    handleEdit = async (list, index, e) => {
        e.preventDefault();
        if (index === this.state.index) {
            await this.save(list, index, e);
        }
        else {
            await this.update(index, e);
        }
    };

    handlechangeUpdate = (name, target) => e => {
        let value = e.target
            ? e.target.value.toUpperCase()
            : e.value.toUpperCase();
        let targetVo = target;
        if (targetVo === "valueUpdateVO") {
            const ValueList = [...this.state.valueUpdateVO];
            ValueList[this.state.index] = { ...ValueList[this.state.index], [name]: value }
            this.setState({
                valueUpdateVO: [...ValueList],
                check: false
            });
        }
        else {
            this.setState(prevState => ({
                valueAddVO: {
                    ...prevState.valueAddVO,
                    [name]: value
                }
            }));
        }
    };

    handleDelete = async (list, index, e) => {
        e.preventDefault();
        if (index === this.state.index) {
            await this.cancel(index);
        }
        else {
            await this.delete(list, e);
        }
    };

    update = async (index, e) => {
        e.preventDefault();
        this.setState({
            disabled: false,
            index: index
        });
    }

    save = async (data, i, e) => {
        e.preventDefault();
        if (!this.validator.allValid()) {
            this.validator.showMessages();
            this.forceUpdate();
          }
          else {
        if (i === this.state.index) {
            const saveStatus = await this.props.updateValue(data);
            if (saveStatus.status === "200") {
                this.setState({
                    valueUpdateVO: [...this.props.ValueData],
                    closePopup: true,
                    index: "",
                    message: saveStatus.message,
                    disabled: false,
                });
            }
            else {
                this.setState({
                    closePopup: true,
                    message: saveStatus.message
                });
            }
            this.validator.hideMessages();
            this.forceUpdate();
        }
    }
}


    cancel = (index) => {
        this.setState({
            valueUpdateVO: [...this.props.ValueData],
            disabled: true,
            index: ""
        });
        this.validator.hideMessages();
        this.forceUpdate();
    };

    delete = async (data, e) => {
        e.preventDefault();
        const deleteStatus = await this.props.deleteValue(data);
        if (deleteStatus.status === "200") {
            this.setState({
                closePopup: true,
                message: deleteStatus.message,
                indesx: "",
                disabled: false,
                valueUpdateVO: [...this.props.ValueData]
            });
        }
        else {
            this.setState({
                closePopup: true,
                message: deleteStatus.message
            });
        }
        this.validator.hideMessages();
        this.forceUpdate();
    }

    handleAdd = async (e) => {
        e.preventDefault();
        
        if ((this.state.valueAddVO.valueCd !== "") &&
            (this.state.valueAddVO.valueCdAmt !== "")&& (this.validator.allValid()) ) {
            const status = await this.props.addValue(this.state.valueAddVO);
            if (status.status === "200") {
                this.setState(prevState => ({
                    valueAddVO: {
                        ...prevState.valueAddVO,
                        valueCd: "",
                        valueCdAmt: ""
                    },
                    valueUpdateVO: [...this.props.ValueData],
                    message: status.message,
                    closePopup: true,
                    index: ""
                }));
            }
            else {
                this.setState({
                    closePopup: true,
                    message: status.message
                });
            }
            this.validator.hideMessages();
            this.forceUpdate();
          }
          else {
            this.validator.showMessages();
            this.forceUpdate();
        }
    
    }

    modalClosed = () => {
        this.setState({ closePopup: false })
    }

    handleDates = (fieldId, index, targetVo) => (event) => {
        var self = this;
        let dateId = "#" + fieldId
        DateUtil.getDatePicker(dateId).on("change", e => {
            if (dateChk.name !== e.target.name || dateChk.value !== e.target.value) {
                self.setDate(e.target.name, e.target.value, index, targetVo);
            }
            dateChk.name = e.target.name;
            dateChk.value = e.target.value;
        });
    };

    setDate = (name, value, index, targetVo) => {
        if (targetVo === "valueUpdateVO") {
            const ValueList = [...this.state.valueUpdateVO];
            ValueList[index] = { ...ValueList[index], [name]: value }
            this.setState({
                valueUpdateVO: [...ValueList],
            });
        }
        else {
            this.setState(prevState => ({
                valueAddVO: {
                    ...prevState.valueAddVO,
                    [name]: value
                }
            }));
        }
    };

    render() {
        const { classes } = this.props;
        const { valueUpdateVO, disabled, index, message, closePopup, valueAddVO } = this.state;
        return (
            <div class="panel-body">
                <Modal
                    dialogTitle="VALUE"
                    message={message}
                    show={closePopup}
                    modalClosed={this.modalClosed} />

                <div style={{ width: "100%", textAlign: "center" }}>
                    <div className={classes.tableWrapper} style={{ width: "100%" }}>
                        <ClaimCodeTable
                            updateData={valueUpdateVO}
                            addData={valueAddVO}
                            header={VALUE_CODE_UPDATE}
                            editable={this.props.editable}
                            updateTargetVo="valueUpdateVO"
                            addTargetVo="valueAddVO"
                            tableName="VALUE"
                            disabled={disabled}
                            index={index}
                            validator={this.validator}
                            handleDates={this.handleDates}
                            handlechangeUpdate={this.handlechangeUpdate}
                            handleEdit={this.handleEdit}
                            handleDelete={this.handleDelete}
                            handleAdd={this.handleAdd}
                        />
                    </div>
                </div>
            </div>
        );
    }
}

const mapStateToProps = state => {
    return {
        ValueData: state.ClaimCodeReducer.claim_Value_data
    };
};
const mapDispatchToProps = {
    getValue,
    addValue,
    updateValue,
    deleteValue
};
export default connect(
    mapStateToProps,
    mapDispatchToProps
)(withStyles(styles)(ValueCode));

