import * as DateUtil from '../../../utils/DatePicker'
import { withStyles } from "@material-ui/core/styles";
import isEmpty from "lodash/isEmpty";
import React, { Component } from "react";
import { connect } from "react-redux";
import { styles as Styles } from "../../../assets/styles/DataTableStyle";
import Modal from "../../../components/UI/Modal/Modal";
import { PROCEDURE_CODE_UPDATE } from "../../../constants/header/encounterDetailsHeader";
import { getClmProcedureCd, addClmProcedureCd, updateClmProcedureCd, deleteClmProcedureCd } from "../../../redux/actions/ClaimCodeAction";
import ClaimCodeTable from "../../Home/ClaimCodeTable";
import SimpleReactValidator from "simple-react-validator";
import { customValidations } from "../../../utils/CustomValidations";

const styles = theme => ({
    ...Styles(theme),
    headerCellAttestation: {
        color: "white",
        paddingRight: 4,
        paddingLeft: 5
    },
    validationMessage: {
        color: "red",
        fontSize: "12px"
    }
});
const dateChk = {};

class ProcedureCode extends Component {
    constructor(props) {
        super(props);
        this.validator = new SimpleReactValidator({
            validators: {
              date_format: customValidations.date_format,
              date_after: customValidations.date_after
            },
          });
        this.state = {
            selectedRow: this.props.selectedRowData.wtxClaimRefNbr,
            message: "",
            disabled: true,
            closePopup: false,
            index: "",
            ProcedureCodeUpdateVO: {
                mfId: "",
                wtxClaimRefNbr: "",
                wtxClaimRevNbr: null,
                clmSeqNbr: null,
                procSeqNbr: null,
                procType: "",
                procCd: "",
                procDate: "",
                lastUpdtTime: "",
                lastUpdtUserid: "",
                princKey: false,
                claimType: null,
                encType: "",
                formattedProcDate: ""
            },
            ProcedureCodeAddVO: {
                mfId: this.props.selectedRowData.mfId,
                wtxClaimRefNbr: this.props.selectedRowData.wtxClaimRefNbr,
                wtxClaimRevNbr: this.props.selectedRowData.wtxClaimRevNbr,
                clmSeqNbr: this.props.selectedRowData.claimSeqNbr,
                procType: "",
                procCd: "",
                procDate: "",
                formattedProcDate: "",
                claimType: this.props.selectedRowData.claimType,
                encType: this.props.selectedRowData.encType
            },
        };
    };

    
    async componentDidMount() {
        await this.props.getClmProcedureCd(this.props.selectedRowData);
        if (!isEmpty(this.props.ProcedureData)) {
            this.setState({
                ProcedureCodeUpdateVO: [...this.props.ProcedureData],
            });
        }
    };


    async UNSAFE_componentWillReceiveProps(nextProps, prevState) {
        if (nextProps.selectedRowData &&
            (this.state.selectedRow !== nextProps.selectedRowData.wtxClaimRefNbr)) {
            await this.props.getClmProcedureCd(nextProps.selectedRowData);
            this.setState({
                ProcedureCodeUpdateVO: [...nextProps.ProcedureData],
                selectedRow: nextProps.selectedRowData.wtxClaimRefNbr
            })
        }
    };

    handleEdit = async (list, index, e) => {
        e.preventDefault();
        if (index === this.state.index) {
            await this.save(list, index, e);
        }
        else {
            await this.update(index, e);
        }
    };

    handlechangeUpdate = (name, target) => e => {
        let value = e.target
            ? e.target.value.toUpperCase()
            : e.value.toUpperCase();
        let targetVo = target;
        if (targetVo === "ProcedureCodeUpdateVO") {
            const ProcedureCodeList = [...this.state.ProcedureCodeUpdateVO];
            ProcedureCodeList[this.state.index] = { ...ProcedureCodeList[this.state.index], [name]: value }
            this.setState({
                ProcedureCodeUpdateVO: [...ProcedureCodeList],
                check: false
            });
        }
        else {
            this.setState(prevState => ({
                ProcedureCodeAddVO: {
                    ...prevState.ProcedureCodeAddVO,
                    [name]: value
                }
            }));
        }
    };

    handleDelete = async (list, index, e) => {
        e.preventDefault();
        if (index === this.state.index) {
            await this.cancel();
        }
        else {
            await this.delete(list, e);
        }
    };

    update = async (index, e) => {
        e.preventDefault();
        this.setState({
            disabled: false,
            index: index
        });
    };

    save = async (data, i, e) => {
        e.preventDefault();
        if (!this.validator.allValid()) {
            this.validator.showMessages();
            this.forceUpdate();
          }
          else {
        if (i === this.state.index) {
            const saveStatus = await this.props.updateClmProcedureCd(data);
            if (saveStatus.status === "200") {
                this.setState({
                    ProcedureCodeUpdateVO: [...this.props.ProcedureData],
                    closePopup: true,
                    index: "",
                    message: saveStatus.message,
                    disabled: false,
                });
            }
            else {
                this.setState({
                    closePopup: true,
                    message: saveStatus.message
                });
            }
            this.validator.hideMessages();
            this.forceUpdate();
        }
    }
    }

    cancel = () => {
        this.setState({
            ProcedureCodeUpdateVO: [...this.props.ProcedureData],
            disabled: true,
            index: ""
        });
        this.validator.hideMessages();
        this.forceUpdate();
    };

    delete = async (data, e) => {
        e.preventDefault();
        const deleteStatus = await this.props.deleteClmProcedureCd(data);
        if (deleteStatus.status === "200") {
            this.setState({
                closePopup: true,
                message: deleteStatus.message,
                index: "",
                disabled: false,
                ProcedureCodeUpdateVO: [...this.props.ProcedureData]
            });
        }
        else {
            this.setState({
                closePopup: true,
                message: deleteStatus.message
            });
        }
        this.validator.hideMessages();
        this.forceUpdate();
    }

    handleAdd = async (e) => {
        e.preventDefault();
        if (this.validator.allValid()) {
            const status = await this.props.addClmProcedureCd(this.state.ProcedureCodeAddVO);
            if (status.status === "200") {
                this.setState(prevState => ({
                    ProcedureCodeAddVO: {
                        ...prevState.ProcedureCodeAddVO,
                        procType: "",
                        procCd: "",
                        formattedProcDate: "",
                        index: ""
                    },
                    ProcedureCodeUpdateVO: [...this.props.ProcedureData],
                    message: status.message,
                    closePopup: true
                }));
            }
            else {
                this.setState({
                    closePopup: true,
                    message: status.message
                });
            }
            this.validator.hideMessages();
            this.forceUpdate();
          }
          else {
            this.validator.showMessages();
            this.forceUpdate();
        }
    }

    modalClosed = () => {
        this.setState({ closePopup: false })
    }

    handleDates = (index, targetVo) => (event) => {
        var self = this;
        let dateId = "#" + event.target.id;
        DateUtil.getDatePicker(dateId).datepicker('show').on("change", e => {
            if (dateChk.name !== e.target.name || dateChk.value !== e.target.value) {
                self.setDate(e.target.name, e.target.value, index, targetVo);
            }
            dateChk.name = e.target.name;
            dateChk.value = e.target.value;
        });
    };

    setDate = (name, value, index, targetVo) => {
        if (targetVo === "ProcedureCodeUpdateVO") {
            const ProcedureCodeList = [...this.state.ProcedureCodeUpdateVO];
            ProcedureCodeList[index] = { ...ProcedureCodeList[index], [name]: value }
            this.setState({
                ProcedureCodeUpdateVO: [...ProcedureCodeList],
            });
        }
        else {
            this.setState(prevState => ({
                ProcedureCodeAddVO: {
                    ...prevState.ProcedureCodeAddVO,
                    [name]: value
                }
            }));
        }
    };

    render() {
        const { classes } = this.props;
        const { ProcedureCodeUpdateVO, disabled, index, message, closePopup, ProcedureCodeAddVO } = this.state;
        return (
            <div class="panel-body">
                <Modal
                    dialogTitle="PROCEDURE CODE"
                    message={message}
                    show={closePopup}
                    modalClosed={this.modalClosed} />

                <div style={{ width: "115%", alignSelf: "stretch", marginInlineStart:"120px" }}>
                    <div className={classes.tableWrapper} style={{ width: "115%"}}>
                        <ClaimCodeTable
                            updateData={ProcedureCodeUpdateVO}
                            addData={ProcedureCodeAddVO}
                            header={PROCEDURE_CODE_UPDATE}
                            editable={this.props.editable}
                            updateTargetVo="ProcedureCodeUpdateVO"
                            addTargetVo="ProcedureCodeAddVO"
                            tableName="PROCEDURE"
                            disabled={disabled}
                            index={index}
                            validator={this.validator}
                            handleDates={this.handleDates}
                            handlechangeUpdate={this.handlechangeUpdate}
                            handleEdit={this.handleEdit}
                            handleDelete={this.handleDelete}
                            handleAdd={this.handleAdd}
                        />
                    </div>
                </div>
            </div>
        );
    }
}

const mapStateToProps = state => {
    return {
        ProcedureData: state.ClaimCodeReducer.claim_procedureCode_data
    };
};
const mapDispatchToProps = {
    getClmProcedureCd,
    addClmProcedureCd,
    updateClmProcedureCd,
    deleteClmProcedureCd
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(withStyles(styles)(ProcedureCode));