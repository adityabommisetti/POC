import { withStyles } from "@material-ui/core/styles";
import React, { Component } from "react";
import isEmpty from "lodash/isEmpty";
import { connect } from "react-redux";
import { styles as Styles } from "../../../assets/styles/DataTableStyle";
import { getClmConditionCd, addClmConditionCd, deleteClmConditionCd, updateClmConditionCd } from "../../../redux/actions/ClaimCodeAction";
import { CONDITION_UPDATE } from "../../../constants/header/encounterDetailsHeader";
import ClaimCodeTable from "../../Home/ClaimCodeTable";
import Modal from "../../../components/UI/Modal/Modal";
import SimpleReactValidator from "simple-react-validator";
import { customValidations } from "../../../utils/CustomValidations";


const styles = theme => ({
  ...Styles(theme),
});

class Condition extends Component {
  constructor(props) {
    super(props);
    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
        date_after: customValidations.date_after
      },
    });
    this.state = {
      disabled: true,
      ConditionAddVO: {
        mfId: this.props.selectedRowData.mfId,
        wtxClaimRefNbr: this.props.selectedRowData.wtxClaimRefNbr,
        wtxClaimRevNbr: this.props.selectedRowData.wtxClaimRevNbr,
        claimSeqNbr: this.props.selectedRowData.claimSeqNbr,
        claimType: this.props.selectedRowData.claimType,
        conditionSeqNbr: "",
        conditionCode: "",
        encType: this.props.selectedRowData.encType
      },
      conditionUpdateVO: {
        claimSeqNbr: null,
        claimType: null,
        conditionCode: "",
        conditionSeqNbr: null,
        lastUpdtTime: null,
        lastUpdtUserid: null,
        mfId: "",
        wtxClaimRefNbr: "",
        wtxClaimRevNbr: null,
        encType: ""
      },
      selectedRow: 0,
      showModal: false,
      message: "",
      index: ""
    };
  }

  async componentDidMount() {
    if (!isEmpty(this.props.ConditionData)) {
      await this.setState({
        conditionUpdateVO: [...this.props.ConditionData]
      });
    }
  };

  async UNSAFE_componentWillReceiveProps(nextProps) {
    if (!isEmpty(nextProps.ConditionData)) {
      await this.setState({
        conditionUpdateVO: [...nextProps.ConditionData]
      })
    }
    else {
      this.setState({
        conditionUpdateVO: []
      })
    }
  }

  handleEdit = async (list, index, e) => {
    e.preventDefault();
    if (index === this.state.index) {
      await this.save(list, index, e);
    }
    else {
      await this.update(index);
    }
  };

  handlechangeUpdate = (name, target) => e => {
    let value = e.target
      ? e.target.value.toUpperCase()
      : e.value.toUpperCase();
    let targetVo = target;
    if (targetVo === "conditionUpdateVO") {
      const ConditionList = [...this.state.conditionUpdateVO];
      ConditionList[this.state.index] = { ...ConditionList[this.state.index], [name]: value }
      this.setState({
        conditionUpdateVO: [...ConditionList],
        check: false
      });
    }
    else {
      this.setState(prevState => ({
        ConditionAddVO: {
          ...prevState.ConditionAddVO,
          [name]: value
        }
      }));
    }
  };

  handleDelete = async (list, index, e) => {
    e.preventDefault();
    if (index === this.state.index) {
      await this.cancel(list, index, e);
    }
    else {
      await this.deleteCondition(list, index, e);
    }
  };


  update = (index) => {
    this.setState({
      disabled: false,
      index: index
    }
    );
  }

  save = async (list, i, e) => {
    e.preventDefault();
    console.log(this.validator)
    if (i === this.state.index) {
      if (!this.validator.allValid()) {
        this.validator.showMessages();
        this.forceUpdate();
    }
    else{
      const saveStatus = await this.props.updateClmConditionCd(list);
      if (saveStatus.status === "200") {
        this.setState({
          conditionUpdateVO: [...this.props.ConditionData],
          closePopup: true,
          index: "",
          message: saveStatus.message,
          disabled: false
        });
      }
      else {
        this.setState({
          closePopup: true,
          message: saveStatus.message
        });
      }
      this.validator.hideMessages();
            this.forceUpdate();
      
    }
  };
}

  cancel = (index) => {
    this.setState({
      conditionUpdateVO: [...this.props.ConditionData],
      disabled: true,
      index: ""
    });
  };

  deleteCondition = async (list, index, e) => {
    e.preventDefault();
    const deleteStatus = await this.props.deleteClmConditionCd(list);
    if (deleteStatus.status === "OK") {
      this.setState({
        conditionUpdateVO: [...this.props.ConditionData],
        closePopup: true,
        message: deleteStatus.message,
        index: "",
        disabled: false,
      });

    }
    else {
      this.setState({
        closePopup: true,
        message: deleteStatus.message
      });
    }
  };

  handleAdd = async (e) => {
    e.preventDefault();
    this.setState({ index: "" })
    if (!this.validator.allValid()) {
      this.validator.showMessages();
      this.forceUpdate();
  }
  else {
    const addStatus = await this.props.addClmConditionCd(this.state.ConditionAddVO);
    if (addStatus.status === "200") {
      if (!isEmpty(this.props.ConditionData)) {
        this.setState(prevState => ({
          ConditionAddVO: {
            ...prevState.ConditionAddVO,
            conditionCode: ""
          },
          conditionUpdateVO: [...this.props.ConditionData],
          closePopup: true,
          index: "",
          message: addStatus.message
        }));
      }
    }
    else {
      this.setState({
        closePopup: true,
        message: addStatus.message
      });
    }
    this.validator.hideMessages();
            this.forceUpdate();
  }
  }

  modalClosed = () => {
    this.setState({ closePopup: false })
  }


  render() {
    const { classes } = this.props;
    const { conditionUpdateVO, disabled, index, message, closePopup, ConditionAddVO } = this.state;

    return (
      <div class="panel-body">
        <Modal dialogTitle='CONDITION'
          message={message}
          show={closePopup}
          modalClosed={this.modalClosed}>
        </Modal>
        <div style={{ width: "100%", textAlign: "center" }}>
          <div className={classes.tableWrapperTest}>
            <ClaimCodeTable
              updateData={conditionUpdateVO}
              addData={ConditionAddVO}
              header={CONDITION_UPDATE}
              editable={this.props.editable}
              tableName="CONDITION"
              updateTargetVo="conditionUpdateVO"
              addTargetVo="ConditionAddVO"
              disabled={disabled}
              index={index}
              validator={this.validator}
              handlechangeUpdate={this.handlechangeUpdate}
              handleEdit={this.handleEdit}
              handleDelete={this.handleDelete}
              handleAdd={this.handleAdd}
            />
          </div>
        </div>
      </div>)
  }
}

const mapStateToProps = state => {
  return {
    ConditionData: state.ClaimCodeReducer.claimVo.claimConditionsList
  };
};

const mapDispatchToProps = {
  addClmConditionCd,
  deleteClmConditionCd,
  updateClmConditionCd,
  getClmConditionCd
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(Condition));

