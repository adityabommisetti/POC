import { withStyles } from "@material-ui/core/styles";
import React, { Component } from "react";
import isEmpty from "lodash/isEmpty";
import { connect } from "react-redux";
import { styles as Styles } from "../../../assets/styles/DataTableStyle";
import Modal from "../../../components/UI/Modal/Modal";
import { OCCURRENCE_UPDATE } from "../../../constants/header/encounterDetailsHeader";
import { addOccurrence, deleteOccurrence, getOccurrence, updateOccurrence } from "../../../redux/actions/ClaimCodeAction";
import * as DateUtil from "../../../utils/DatePicker";
import ClaimCodeTable from "../../Home/ClaimCodeTable";
import SimpleReactValidator from "simple-react-validator";
import { customValidations } from "../../../utils/CustomValidations";

const dateChk = {};

class Occurrence extends Component {
    constructor(props) {
        super(props);
        this.validator = new SimpleReactValidator({
            validators: {
              date_format: customValidations.date_format,
              date_after: customValidations.date_after
            },
          });
        this.state = {
            selectedRow: this.props.selectedRowData.wtxClaimRefNbr,
            showModal: false,
            message: "",
            disabled: true,
            index: "",
            occuAddVo: {
                mfId: this.props.selectedRowData.mfId,
                wtxClaimRefNbr: this.props.selectedRowData.wtxClaimRefNbr,
                wtxClaimRevNbr: this.props.selectedRowData.wtxClaimRevNbr,
                clmSeqNbr: this.props.selectedRowData.claimSeqNbr,
                claimType: this.props.selectedRowData.claimType,
                occurenceCd: "",
                occurenceDate: "",
                formattedOccurenceDate: "",
                encType: this.props.selectedRowData.encType
            },
            occuUpdateVo: {
                mfId: "",
                wtxClaimRefNbr: "",
                wtxClaimRevNbr: null,
                clmSeqNbr: null,
                occurSeqNbr: null,
                occurenceCd: "",
                occurenceDate: "",
                lastUpdtTime: "",
                lastUpdtUserid: "",
                claimType: "",
                encType: "",
                formattedOccurenceDate: ""
            }
        };
    };

    async componentDidMount() {
        await this.props.getOccurrence(this.props.selectedRowData)
        if (!isEmpty(this.props.occurrenceData)) {
            this.setState({
                occuUpdateVo: [...this.props.occurrenceData],
            });
        }
    };


    async UNSAFE_componentWillReceiveProps(nextProps, prevState) {
        if (nextProps.selectedRowData &&
            (this.state.selectedRow !== nextProps.selectedRowData.wtxClaimRefNbr)) {
            await this.props.getOccurrence(nextProps.selectedRowData);
            this.setState({
                occuUpdateVo: [...nextProps.occurrenceData],
                selectedRow: nextProps.selectedRowData.wtxClaimRefNbr
            })
        }
    };

    handleEdit = async (list, index, e) => {
        e.preventDefault();
        if (index === this.state.index) {
            await this.save(list, index, e);
        }
        else {
            await this.update(index, e);
        }
    };

    handlechangeUpdate = (name, target) => e => {
        let value = e.target
            ? e.target.value.toUpperCase()
            : e.value.toUpperCase();
        let targetVo = target;
        if (targetVo === "occuUpdateVo") {
            const OccurrenceList = [...this.state.occuUpdateVo];
            OccurrenceList[this.state.index] = { ...OccurrenceList[this.state.index], [name]: value }
            this.setState({
                occuUpdateVo: [...OccurrenceList],
                check: false
            });
        }
        else {
            this.setState(prevState => ({
                occuAddVo: {
                    ...prevState.occuAddVo,
                    [name]: value
                }
            }));
        }
    };

    handleDelete = async (list, index, e) => {
        e.preventDefault();
        if (index === this.state.index) {
            await this.cancel(list, index, e);
        }
        else {
            await this.deleteOccurrence(list, index, e);
        }
    };

    update = async (index, e) => {
        e.preventDefault();
        this.setState({
            disabled: false,
            index: index
        });
    }

    save = async (list, i, e) => {
        e.preventDefault();
        console.log(this.validator)
        if (i === this.state.index) {
            if (!this.validator.allValid()) {
                this.validator.showMessages();
                this.forceUpdate();
            }
            else {
                const saveStatus = await this.props.updateOccurrence(list);
                if (saveStatus.status === "200") {
                    this.setState({
                        occuUpdateVo: [...this.props.occurrenceData],
                        closePopup: true,
                        index: "",
                        message: saveStatus.message,
                        disabled: false,
                    });
                }
                else {
                    this.setState({
                        closePopup: true,
                        message: saveStatus.message
                    });
                }
                this.validator.hideMessages();
                this.forceUpdate();
            }
        }
    };

    cancel = (index) => {
        this.setState({
            occuUpdateVo: [...this.props.occurrenceData],
            disabled: true,
            index: ""
        });
        this.validator.hideMessages();
        this.forceUpdate();
    };

    deleteOccurrence = async (list, index, e) => {
        e.preventDefault();
        const deleteStatus = await this.props.deleteOccurrence(list);
        if (deleteStatus.status === "200") {
            this.setState({
                occuUpdateVo: [...this.props.occurrenceData],
                closePopup: true,
                message: deleteStatus.message,
                index: "",
                disabled: false,
            });
        }
        else {
            this.setState({
                closePopup: true,
                message: deleteStatus.message
            });
        }
        this.validator.hideMessages();
        this.forceUpdate();
    };

    handleAdd = async (e) => {
        e.preventDefault();
        this.setState({ index: "" })
        if (!this.validator.allValid()) {
            this.validator.showMessages();
            this.forceUpdate();
        }
        else {
            const addStatus = await this.props.addOccurrence(this.state.occuAddVo);
            if (addStatus.status === "200") {
                this.setState(prevState => ({
                    occuAddVo: {
                        ...prevState.occuAddVo,
                        occurenceCd: "",
                        formattedOccurenceDate: "",
                    },
                    occuUpdateVo: [...this.props.occurrenceData],
                    closePopup: true,
                    index: "",
                    message: addStatus.message
                }));
            }
            else {
                this.setState({
                    closePopup: true,
                    message: addStatus.message
                });
            }
            this.validator.hideMessages();
            this.forceUpdate();
        }
    }

    modalClosed = () => {
        this.setState({ closePopup: false })
    };

    handleDates = (index, targetVo) => (event) => {
        var self = this;
        let dateId = "#" + event.target.id;
        DateUtil.getDatePicker(dateId).datepicker('show').on("change", e => {
            if (dateChk.name !== e.target.name || dateChk.value !== e.target.value) {
                self.setDate(e.target.name, e.target.value, index, targetVo);
            }
            dateChk.name = e.target.name;
            dateChk.value = e.target.value;
        });
    };

    setDate = (name, value, index, targetVo) => {
        if (targetVo === "occuUpdateVo") {
            const OccurrenceList = [...this.state.occuUpdateVo];
            OccurrenceList[index] = { ...OccurrenceList[index], [name]: value }
            this.setState({
                occuUpdateVo: [...OccurrenceList],
            });
        }
        else {
            this.setState(prevState => ({
                occuAddVo: {
                    ...prevState.occuAddVo,
                    [name]: value
                }
            }));
        }
    };

    handleSearchFieldChange = name => event => {
        let value = event.target
            ? event.target.value.toUpperCase()
            : event.value.toUpperCase();

        if (name === "formattedOccurenceDate" && value.length === 8) {
            value = value.replace(/[^0-9]/g, "").trim();
            value = value.replace(/^(\d{2})/, "$1/");
            value = value.replace(/\/(\d{2})/, "/$1/");
            value = value.replace(/(\d)\/(\d{4}).*/, "$1/$2");
        }
        this.setState(prevState => ({
            occuUpdateVo: {
                ...prevState.occuUpdateVo,
                [name]: value
            },
            collapseSearch: false
        }));
    };
    render() {
        const { classes } = this.props;
        const { occuUpdateVo, disabled, index, message, closePopup, occuAddVo } = this.state;

        return (
            <div class="panel-body">
                <Modal dialogTitle='Occurrence'
                    message={message}
                    show={closePopup}
                    modalClosed={this.modalClosed}>
                </Modal>
                <div style={{width: "115%", alignSelf: "stretch", marginInlineStart:"160px" }}>
                    <div className={classes.tableWrapper} style={{ width: "100%" }}>
                        <ClaimCodeTable
                            updateData={occuUpdateVo}
                            addData={occuAddVo}
                            header={OCCURRENCE_UPDATE}
                            editable={this.props.editable}
                            updateTargetVo="occuUpdateVo"
                            addTargetVo="occuAddVo"
                            tableName="OCCURRENCE"
                            disabled={disabled}
                            index={index}
                            validator={this.validator}
                            handleDates={this.handleDates}
                            handlechangeUpdate={this.handlechangeUpdate}
                            handleEdit={this.handleEdit}
                            handleDelete={this.handleDelete}
                            handleAdd={this.handleAdd}
                        />
                    </div>
                </div>
            </div>)
    }
}

const mapStateToProps = state => {
    return {
        occurrenceData: state.ClaimCodeReducer.claim_Occurrence_data,
    };
};

const mapDispatchToProps = {
    addOccurrence,
    deleteOccurrence,
    getOccurrence,
    updateOccurrence
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(withStyles(Styles)(Occurrence));
