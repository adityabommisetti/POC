import React from "react";
import isEmpty from "lodash/isEmpty";
import DataTable from "../Home/DataTable";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";
import InputField from "../UI/InputField";
import { Styles } from "../../assets/styles/Theme";
import ExpansionPanel from "../UI/ExpansionPanel";
import { CLAIM_PROVIDER_HEADER } from "../../constants/header/encounterDetailsHeader";

class claimSubscriberProvider extends React.Component {
  state = {
    clmSubProvList: this.props.clmSubProvData,
    selectedVo:
      this.props.clmSubProvData != null
        ? {
            ...(this.props.clmSubProvData[0]
              ? this.props.clmSubProvData[0]
              : null),
          }
        : {},
    rowIndex: 0,
  };

  // async componentWillReceiveProps(nextProps) {
  //     await this.setState({
  //         clmSubProvList: nextProps.clmSubProvData
  //     })
  //     this.setState({
  //         selectedVo: nextProps.clmSubProvData[this.state.rowIndex]
  //     });
  // };

  static getDerivedStateFromProps(nextProps, prevState) {
    if (!isEmpty(nextProps.clmSubProvData)) {
      if (
        prevState.clmSubProvList[prevState.rowIndex] !==
        nextProps.clmSubProvData[prevState.rowIndex]
      ) {
        return {
          selectedVo: nextProps.clmSubProvData[prevState.rowIndex],
        };
      }
    }
    return null;
  }

  selectRow = async (index) => {
    const selectedVo = this.props.clmSubProvData[index];
    await this.setState({
      selectedVo: selectedVo,
    });
  };

  render() {
    const { classes, clmSubProvData, editable, selectedRow, dataTableVo } = this.props;
    const { selectedVo } = this.state;
    return (
      <React.Fragment>
        <div>
          <DataTable
            data={dataTableVo? dataTableVo: []}
            header={CLAIM_PROVIDER_HEADER}
            rowsPerPage={5}
            sortable={true}
            clicked={this.selectRow}
          />
        </div>
        {!isEmpty(clmSubProvData) ? (
          <React.Fragment>
            <ExpansionPanel summary=" Claim - Other Subscriber - Provider - Detail">
              <div id="claimProvider">
                <div class="panel-body">
                  <div className={classes.container}>
                    <div>
                      <InputField
                        name="provType"
                        id="claimOthSubsProvList_provType"
                        label="Provider Type"
                        disabled={true}
                        value={selectedVo.provType}
                        onChange={this.props.handleChange(
                          "claimOthSubsProvList",
                          this.state.rowIndex
                        )}
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="othPayrProvLocNbr"
                        label="Loc Nbr"
                        disabled={!editable}
                        value={selectedVo.othPayrProvLocNbr}
                        maxLength={50}
                        onChange={this.props.handleChange(
                          "claimOthSubsProvList",
                          this.state.rowIndex
                        )}
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="othPayrProvLicNbr"
                        label="License Nbr"
                        disabled={!editable}
                        maxLength={50}
                        value={selectedVo.othPayrProvLicNbr}
                        onChange={this.props.handleChange(
                          "claimOthSubsProvList",
                          this.state.rowIndex
                        )}
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    {selectedRow.encType === "P" ||
                    selectedRow.encType === "E" ? (
                      <div>
                        <InputField
                          name="othPayrProvEntityType"
                          label="Prov Entity Type"
                          disabled={!editable}
                          value={selectedVo.othPayrProvEntityType}
                          onChange={this.props.handleChange(
                            "claimOthSubsProvList",
                            this.state.rowIndex
                          )}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}
                    <div />
                    <div>
                      <InputField
                        name="othPayrProvUpin"
                        label="UPIN"
                        disabled={!editable}
                        value={selectedVo.othPayrProvUpin}
                        maxLength={50}
                        onChange={this.props.handleChange(
                          "claimOthSubsProvList",
                          this.state.rowIndex
                        )}
                      />
                      <div className={classes.validationMessage}></div>
                    </div>
                    <div>
                      <InputField
                        name="othPayrProvCommNbr"
                        label="Comm Nbr"
                        disabled={!editable}
                        maxLength={50}
                        value={selectedVo.othPayrProvCommNbr}
                        onChange={this.props.handleChange(
                          "claimOthSubsProvList",
                          this.state.rowIndex
                        )}
                      />
                      <div className={classes.validationMessageSelect}></div>
                    </div>
                  </div>
                </div>
              </div>
            </ExpansionPanel>
          </React.Fragment>
        ) : null}
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    dataTableVo: state.ClaimCodeReducer.claimVo.claimOthSubsProvList
  };
};

export default connect(
  mapStateToProps,
  null
)(withStyles(Styles)(claimSubscriberProvider));

