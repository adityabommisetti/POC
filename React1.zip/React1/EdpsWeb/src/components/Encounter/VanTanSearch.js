import React, { Component } from "react";
import { withStyles } from "@material-ui/core/styles";
import DataTable from "../Home/DataTable";
import InputField from "../UI/InputField";
import { Styles } from "../../assets/styles/PopupTheme";
import { connect } from "react-redux";
import { VANTAN_SEARCH } from "../../constants/header/encounterDetailsHeader";
import { fetchVersion } from "../../redux/actions/encounterDetailsAction";

class VanTanSearch extends Component {

    async componentDidMount() {
        const payload = { ...this.props.searchVo };
        payload.isVanTn = true;
        payload.claimSeqNbr = "";
        payload.wtxClaimRefNbr = "";
        await this.props.fetchVersion(payload);
    }

    selectRow = (index) => {
        const data = [...this.props.vanTanList];
        const selectedRow = data[index];
        this.props.claimVersion(selectedRow);
        this.props.close();
    }


    render() {
        const { classes, vanTanList, searchVo } = this.props;
        return (
            <React.Fragment>
                <div className={classes.applicationSectionHeading}>
                    <span>VAN TAN SEARCH</span>
                </div>
                <div className={classes.container}>
                    <div>
                        <InputField
                            name="vanTanSearch"
                            value={searchVo.valueAddNtwkTraceNbr}
                            label="VanTan Nbr"
                            disabled={true}
                        />
                        <div className={classes.validationMessage} />
                    </div>
                </div>
                <DataTable
                    data={vanTanList}
                    header={VANTAN_SEARCH}
                    rowsPerPage={10}
                    sortable={true}
                    clicked={this.selectRow}
                />
                <button
                    class="btn btn-primary"
                    style={{ float: 'right' }}
                    onClick={this.props.close}
                >
                    Cancel
                </button>
            </React.Fragment>
        );
    }
}

const mapStateToProps = state => {
    return {
        vanTanList: state.encounterDetailsData.vanTanList
    };
};

const mapDispatchToProps = {
    fetchVersion
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(withStyles(Styles)(VanTanSearch));
