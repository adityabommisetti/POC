import React from "react";
import Popup from "reactjs-popup";
import isEmpty from "lodash/isEmpty";
import { connect } from "react-redux";
import DataTable from "../Home/DataTable";
import { withStyles } from "@material-ui/core/styles";
import InputField from "../UI/InputField";
import { Styles } from "../../assets/styles/Theme";
import CityZipSearch from "./CityZipSearch";
import ExpansionPanel from "../UI/ExpansionPanel";
import { components, Select } from "../UI/Select";
import {
  CLAIM_LINE_PROFESSIONAL,
  CLAIM_LINE_INSTITUTIONAL,
  CLAIM_LINE_ATTACHMENT,
  CLAIM_LINE_REFERRAL,
  CLAIM_LINE_DOC,
} from "../../constants/header/encounterDetailsHeader";

class ClaimLine extends React.Component {
  state = {
    claimLineVo: this.props.claimLineData,
    selectedVo:
      this.props.claimLineData != null
        ? {
          ...(this.props.claimLineData[0]
            ? this.props.claimLineData[0]
            : null),
        }
        : {},
    rowIndex: 0,
  };

  static getDerivedStateFromProps(nextProps, prevState) {
    if (!isEmpty(nextProps.claimLineData)) {
      if (
        prevState.claimLineVo[prevState.rowIndex] !==
        nextProps.claimLineData[prevState.rowIndex]
      ) {
        return {
          selectedVo: nextProps.claimLineData[prevState.rowIndex],
        };
      }
    }
    return null;
  }

  selectRow = async (index) => {
    const selectedVo = this.props.claimLineData[index];
    await this.setState({
      selectedVo: selectedVo,
      rowIndex: index,
    });
  };

  render() {
    const {
      classes,
      dropdowns,
      claimLineData,
      editable,
      selectedRow,
      dataTableVo
    } = this.props;
    const { selectedVo, rowIndex } = this.state;
    return (
      <React.Fragment>
        <DataTable
          data={dataTableVo ? dataTableVo : []}
          header={selectedRow.encType === "I" ?
            CLAIM_LINE_INSTITUTIONAL :
            CLAIM_LINE_PROFESSIONAL}
          rowsPerPage={5}
          sortable={true}
          clicked={this.selectRow}
        />
        {!isEmpty(claimLineData) ? (
          <React.Fragment>
            <ExpansionPanel summary="Claim - Line -Detail">
              <div id="claimLine">
                <div class="panel-body">
                  <div className={classes.container}>
                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="instApprovedRevenueCd"
                          id="instApprovedRevenueCd"
                          value={selectedVo.instApprovedRevenueCd}
                          label="Revenue Code"
                          disabled={!editable}
                          maxLength={4}
                          onChange={this.props.handleChange(
                            "claimLinesList",
                            rowIndex
                          )}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}
                    <div>
                      <InputField
                        name="claimLineSeqNbr"
                        value={selectedVo.claimLineSeqNbr}
                        label="Claim Line Nbr"
                        disabled={true}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="liProcCd"
                        disabled={!editable}
                        maxLength={7}
                        value={selectedVo.liProcCd}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="Procedure Code"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="liProcMod1"
                        disabled={!editable}
                        maxLength={2}
                        value={selectedVo.liProcMod1}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="Procedure Mod1"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="liProcMod2"
                        disabled={!editable}
                        maxLength={2}
                        value={selectedVo.liProcMod2}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="Procedure Mod2"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="liProcMod3"
                        disabled={!editable}
                        maxLength={2}
                        value={selectedVo.liProcMod3}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="Procedure Mod3"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="liProcMod4"
                        disabled={!editable}
                        maxLength={2}
                        value={selectedVo.liProcMod4}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="Procedure Mod4"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <React.Fragment>
                          <div>
                            <InputField
                              name="formattedLiDmeRentalPrice"
                              disabled={true}
                              value={selectedVo.formattedLiDmeRentalPrice}
                              onChange={this.props.handleChange(
                                "claimLinesList",
                                rowIndex
                              )}
                              label="DME Rent Price"
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div>
                            <InputField
                              name="dmeCertTypeCd"
                              disabled={!editable}
                              maxLength={1}
                              value={selectedVo.dmeCertTypeCd}
                              onChange={this.props.handleChange(
                                "claimLinesList",
                                rowIndex
                              )}
                              label="DME Cert Type"
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div>
                            <InputField
                              name="dmeAttachTransmitCd"
                              disabled={!editable}
                              maxLength={2}
                              value={selectedVo.dmeAttachTransmitCd}
                              onChange={this.props.handleChange(
                                "claimLinesList",
                                rowIndex
                              )}
                              label="DME Attach Transm Cd"
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div>
                            <InputField
                              name="formattedLiDmePurchPrice"
                              disabled={true}
                              value={selectedVo.formattedLiDmePurchPrice}
                              onChange={this.props.handleChange(
                                "claimLinesList",
                                rowIndex
                              )}
                              label="DME Purch Price"
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div>
                            <InputField
                              name="dmeCertCondInd"
                              disabled={!editable}
                              maxLength={1}
                              value={selectedVo.dmeCertCondInd}
                              onChange={this.props.handleChange(
                                "claimLinesList",
                                rowIndex
                              )}
                              label="DME Cert Cond Ind"
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div>
                            <InputField
                              name="liDmeProcCd"
                              disabled={!editable}
                              maxLength={9}
                              value={selectedVo.liDmeProcCd}
                              onChange={this.props.handleChange(
                                "claimLinesList",
                                rowIndex
                              )}
                              label="DME Proc Cd"
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div>
                            <InputField
                              name="dmeDuration"
                              disabled={!editable}
                              value={selectedVo.dmeDuration}
                              onChange={this.props.handleChange(
                                "claimLinesList",
                                rowIndex
                              )}
                              label="DME Duration"
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div>
                            <InputField
                              name="dmeCertOnFileCd1"
                              disabled={!editable}
                              maxLength={2}
                              value={selectedVo.dmeCertOnFileCd1}
                              onChange={this.props.handleChange(
                                "claimLinesList",
                                rowIndex
                              )}
                              label="DME Cert on File Cd1"
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div>
                            <InputField
                              name="dmeCertOnFileCd2"
                              disabled={!editable}
                              maxLength={2}
                              value={selectedVo.dmeCertOnFileCd2}
                              onChange={this.props.handleChange(
                                "claimLinesList",
                                rowIndex
                              )}
                              label="DME Cert on File Cd2"
                            />
                            <div className={classes.validationMessage} />
                          </div>
                        </React.Fragment>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="liProdSvcidQual"
                            id="liProdSvcidQual"
                            disabled={!editable}
                            maxLength={2}
                            value={selectedVo.liProdSvcidQual}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Prov Svc ID Qual"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="formattedLiSalesTaxAmt"
                            disabled={true}
                            value={selectedVo.formattedLiSalesTaxAmt}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Sales Tax Amount"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    <div>
                      <InputField
                        name="policyComplianceCd"
                        disabled={!editable}
                        maxLength={1}
                        value={selectedVo.policyComplianceCd}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="Policy Compl Cd"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="liUomQual"
                        disabled={!editable}
                        maxLength={2}
                        value={selectedVo.liUomQual}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="UOM Qual"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="formattedPostageClaimedAmt"
                            disabled={true}
                            value={selectedVo.formattedPostageClaimedAmt}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Postage Claim Amt"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="liEpsdtInd"
                            disabled={!editable}
                            maxLength={1}
                            value={selectedVo.liEpsdtInd}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="EPSDT Ind"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="liEmergencyInd"
                            disabled={!editable}
                            maxLength={1}
                            value={selectedVo.liEmergencyInd}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Emergency Ind"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="obstetricAddlUnits"
                            disabled={!editable}
                            value={selectedVo.obstetricAddlUnits}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Obstetric Addl Units"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="liDiagcdPtr1"
                            disabled={!editable}
                            maxLength={2}
                            value={selectedVo.liDiagcdPtr1}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Diag Ptr1"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="liDiagcdPtr2"
                            disabled={!editable}
                            maxLength={2}
                            value={selectedVo.liDiagcdPtr2}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Diag Ptr2"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="liDiagcdPtr3"
                            disabled={!editable}
                            maxLength={2}
                            value={selectedVo.liDiagcdPtr3}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Diag Ptr3"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="liDiagcdPtr4"
                            disabled={!editable}
                            maxLength={2}
                            value={selectedVo.liDiagcdPtr4}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Diag Ptr4"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="liPlaceOfServiceCd"
                            disabled={!editable}
                            maxLength={2}
                            value={selectedVo.liPlaceOfServiceCd}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Place of Svc Cd"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="liLenOfMedNecessity"
                            disabled={!editable}
                            maxLength={5}
                            value={selectedVo.liLenOfMedNecessity}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Len of Med Necess"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    <div>
                      <InputField
                        name="formattedLiServiceUnitCnt"
                        id="claimLinesList_formattedLiServiceUnitCnt"
                        disabled={!editable}
                        maxLength={50}
                        value={selectedVo.formattedLiServiceUnitCnt}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="Svc Unit Count"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="drugUomQual"
                        disabled={!editable}
                        maxLength={2}
                        value={selectedVo.drugUomQual}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="Drug UOM Qual"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="drugUnitCnt"
                        disabled={!editable}
                        maxLength={2}
                        value={selectedVo.drugUnitCnt}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="Drug Unit Count"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="liFamilyPlaningInd"
                            disabled={!editable}
                            maxLength={1}
                            value={selectedVo.liFamilyPlaningInd}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Fam Plan Ind"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    <div>
                      <InputField
                        name="rejectReasonCd"
                        disabled={!editable}
                        maxLength={2}
                        value={selectedVo.rejectReasonCd}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="Rej Reason Code"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="formattedLiChargeAmt"
                            disabled={true}
                            value={selectedVo.formattedLiChargeAmt}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Svc Chrg Amt"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="liRentalUnitPrcInd"
                            disabled={!editable}
                            maxLength={1}
                            value={selectedVo.liRentalUnitPrcInd}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Rent Unit Prc Ind"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="liCopayStatusCd"
                            disabled={!editable}
                            maxLength={1}
                            value={selectedVo.liCopayStatusCd}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Copay Stat Cd"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="contractVersionId"
                            id="claimLinesList_contractVersionId"
                            value={selectedVo.contractVersionId}
                            disabled={!editable}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Contract Version ID"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="formattedContractAmt"
                            disabled={true}
                            value={selectedVo.formattedContractAmt}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Contract Amt"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="hospiceEmployedPrvInd"
                            disabled={!editable}
                            maxLength={1}
                            value={selectedVo.hospiceEmployedPrvInd}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="HospiceEmplPrvInd"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    <div>
                      <InputField
                        name="pricingMethodology"
                        id="claimLinesList_pricingMethodology"
                        disabled={!editable}
                        maxLength={2}
                        value={selectedVo.pricingMethodology}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="Pricing Methdlgy"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="formattedInstLiBeginDt"
                          value={selectedVo.formattedInstLiBeginDt}
                          label=" Begin Date"
                          disabled={!editable}
                          onClick={this.props.handleDates(
                            "#formattedInstLiBeginDt",
                            "claimLinesList",
                            rowIndex
                          )}
                          onChange={this.props.handleChange(
                            "claimLinesList",
                            rowIndex
                          )}
                        />
                        <div className={classes.validationMessage}>
                          {this.props.validator.message(
                            "beginDate",
                            selectedVo.formattedInstLiBeginDt,
                            "date_format"
                          )}
                        </div>
                      </div>
                    ) : null}
                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="formattedInstLiEndDt"
                          value={selectedVo.formattedInstLiEndDt}
                          label="End Date"
                          disabled={!editable}
                          onClick={this.props.handleDates(
                            "#formattedInstLiEndDt",
                            "claimLinesList",
                            rowIndex
                          )}
                          onChange={this.props.handleChange(
                            "claimLinesList",
                            rowIndex
                          )}
                        />
                        <div className={classes.validationMessage}>
                          {this.props.validator.message(
                            "endDate",
                            selectedVo.formattedInstLiEndDt,
                            "date_format"
                          )}
                        </div>
                      </div>
                    ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="contractTypeCd"
                            id="claimLinesList_contractTypeCd"
                            disabled={!editable}
                            value={selectedVo.contractTypeCd}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Contract Type Cd"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="formattedContractPct"
                            id="claimLinesList_formattedContractPct"
                            disabled={!editable}
                            value={selectedVo.formattedContractPct}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Contract Pct"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    <div>
                      <InputField
                        name="exceptionCd"
                        id="claimLinesList_exceptionCd"
                        disabled={!editable}
                        maxLength={1}
                        value={selectedVo.exceptionCd}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="Exception Code"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="serviceCdQual"
                        disabled={!editable}
                        maxLength={2}
                        value={selectedVo.serviceCdQual}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="Svc Code Qual"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="liProdSvcidQual"
                          id="claimLinesList_liProdSvcidQual"
                          disabled={!editable}
                          maxLength={2}
                          value={selectedVo.liProdSvcidQual}
                          onChange={this.props.handleChange(
                            "claimLinesList",
                            rowIndex
                          )}
                          label="Prov Svc ID Qual"
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}
                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="formattedLiDeniedChargeAmt"
                          id="formattedLiDeniedChargeAmt"
                          disabled={true}
                          value={selectedVo.formattedLiDeniedChargeAmt}
                          onChange={this.props.handleChange(
                            "claimLinesList",
                            rowIndex
                          )}
                          label="Non Covrd Chrg Amt"
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}
                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="formattedLiChargeAmt"
                          disabled={true}
                          value={selectedVo.formattedLiChargeAmt}
                          onChange={this.props.handleChange(
                            "claimLinesList",
                            rowIndex
                          )}
                          label="Charge Amt"
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}

                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="formattedLiServiceTaxAmt"
                          disabled={true}
                          value={selectedVo.formattedLiServiceTaxAmt}
                          onChange={this.props.handleChange(
                            "claimLinesList",
                            rowIndex
                          )}
                          label="Service Tax Amt"
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}

                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="formattedLiFacilityTaxAmt"
                          disabled={true}
                          value={selectedVo.formattedLiFacilityTaxAmt}
                          onChange={this.props.handleChange(
                            "claimLinesList",
                            rowIndex
                          )}
                          label="Facility Tax Amt"
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="formattedContractTermsDiscPct"
                            disabled={!editable}
                            value={selectedVo.formattedContractTermsDiscPct}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Contr Terms Disc PCT"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    <div>
                      <InputField
                        name="nationalDrugCd"
                        disabled={!editable}
                        maxLength={11}
                        value={selectedVo.nationalDrugCd}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="Nat Drug Code"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="nationalDrugCdQual"
                        disabled={!editable}
                        maxLength={2}
                        value={selectedVo.nationalDrugCdQual}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="Nat Drug Code Qual"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <React.Fragment>
                          <div>
                            <InputField
                              name="formattedServiceBeginDt"
                              value={selectedVo.formattedServiceBeginDt}
                              label="Svc Begin Date"
                              maxLength={10}
                              disabled={!editable}
                              onClick={this.props.handleDates(
                                "#formattedServiceBeginDt",
                                "claimLinesList",
                                rowIndex
                              )}
                              onChange={this.props.handleChange(
                                "claimLinesList",
                                rowIndex
                              )}
                            />
                            <div className={classes.validationMessage}>
                              {this.props.validator.message(
                                "svcBeginDate",
                                selectedVo.formattedServiceBeginDt,
                                "date_format"
                              )}
                            </div>
                          </div>
                          <div>
                            <InputField
                              name="formattedServiceEndDt"
                              disabled={!editable}
                              value={selectedVo.formattedServiceEndDt}
                              label="Svc End Date"
                              maxLength={10}
                              onClick={this.props.handleDates(
                                "#formattedServiceEndDt",
                                "claimLinesList",
                                rowIndex
                              )}
                              onChange={this.props.handleChange(
                                "claimLinesList",
                                rowIndex
                              )}
                            />
                            <div className={classes.validationMessage}>
                              {this.props.validator.message(
                                "svcEndDate",
                                selectedVo.formattedServiceEndDt,
                                "date_format"
                              )}
                            </div>
                          </div>
                          <div>
                            <InputField
                              name="formattedRecertificationDt"
                              disabled={!editable}
                              value={selectedVo.formattedRecertificationDt}
                              onClick={this.props.handleDates(
                                "#formattedRecertificationDt",
                                "claimLinesList",
                                rowIndex
                              )}
                              onChange={this.props.handleChange(
                                "claimLinesList",
                                rowIndex
                              )}
                              label="Recert Date"
                            />
                            <div className={classes.validationMessage}>
                              {this.props.validator.message(
                                "recertDate",
                                selectedVo.formattedRecertificationDt,
                                "date_format"
                              )}
                            </div>
                          </div>
                          <div>
                            <InputField
                              name="formattedHemoglobinDt"
                              disabled={!editable}
                              value={selectedVo.formattedHemoglobinDt}
                              onClick={this.props.handleDates(
                                "#formattedHemoglobinDt",
                                "claimLinesList",
                                rowIndex
                              )}
                              onChange={this.props.handleChange(
                                "claimLinesList",
                                rowIndex
                              )}
                              label="Hemoglobin Date"
                            />
                            <div className={classes.validationMessage}>
                              {this.props.validator.message(
                                "hemoglobinDate",
                                selectedVo.formattedHemoglobinDt,
                                "date_format"
                              )}
                            </div>
                          </div>
                          <div>
                            <InputField
                              name="formattedSerumCreatineDt"
                              disabled={!editable}
                              value={selectedVo.formattedSerumCreatineDt}
                              onClick={this.props.handleDates(
                                "#formattedSerumCreatineDt",
                                "claimLinesList",
                                rowIndex
                              )}
                              onChange={this.props.handleChange(
                                "claimLinesList",
                                rowIndex
                              )}
                              label="Serum Create Date"
                            />
                            <div className={classes.validationMessage}>
                              {this.props.validator.message(
                                "serumCreateDate",
                                selectedVo.formattedSerumCreatineDt,
                                "date_format"
                              )}
                            </div>
                          </div>
                          <div>
                            <InputField
                              name="formattedShippedDt"
                              disabled={!editable}
                              value={selectedVo.formattedShippedDt}
                              onClick={this.props.handleDates(
                                "#formattedShippedDt",
                                "claimLinesList",
                                rowIndex
                              )}
                              onChange={this.props.handleChange(
                                "claimLinesList",
                                rowIndex
                              )}
                              label="Shipped Date"
                            />
                            <div className={classes.validationMessage}>
                              {this.props.validator.message(
                                "shippedDate",
                                selectedVo.formattedShippedDt,
                                "date_format"
                              )}
                            </div>
                          </div>
                          <div>
                            <InputField
                              name="formattedLastCertificationDt"
                              value={selectedVo.formattedLastCertificationDt}
                              disabled={!editable}
                              onClick={this.props.handleDates(
                                "#formattedLastCertificationDt",
                                "claimLinesList",
                                rowIndex
                              )}
                              onChange={this.props.handleChange(
                                "claimLinesList",
                                rowIndex
                              )}
                              label="Last Cert Date"
                            />
                            <div className={classes.validationMessage}>
                              {this.props.validator.message(
                                "lastCertDate",
                                selectedVo.formattedLastCertificationDt,
                                "date_format"
                              )}
                            </div>
                          </div>
                          <div>
                            <InputField
                              name="formattedPrescriptionDt"
                              disabled={!editable}
                              value={selectedVo.formattedPrescriptionDt}
                              onClick={this.props.handleDates(
                                "#formattedPrescriptionDt",
                                "claimLinesList",
                                rowIndex
                              )}
                              onChange={this.props.handleChange(
                                "claimLinesList",
                                rowIndex
                              )}
                              label="Prescription Date"
                            />
                            <div className={classes.validationMessage}>
                              {this.props.validator.message(
                                "prescriptionDate",
                                selectedVo.formattedPrescriptionDt,
                                "date_format"
                              )}
                            </div>
                          </div>
                          <div>
                            <InputField
                              name="formattedBeginTherapyDt"
                              disabled={!editable}
                              value={selectedVo.formattedBeginTherapyDt}
                              onClick={this.props.handleDates(
                                "#formattedBeginTherapyDt",
                                "claimLinesList",
                                rowIndex
                              )}
                              onChange={this.props.handleChange(
                                "claimLinesList",
                                rowIndex
                              )}
                              label="Begin Therapy Date"
                            />
                            <div className={classes.validationMessage}>
                              {this.props.validator.message(
                                "beginTherapyDate",
                                selectedVo.formattedBeginTherapyDt,
                                "date_format"
                              )}
                            </div>
                          </div>
                          <div>
                            <InputField
                              name="formattedTreatmentTherapyDt"
                              disabled={!editable}
                              value={selectedVo.formattedTreatmentTherapyDt}
                              onClick={this.props.handleDates(
                                "#formattedTreatmentTherapyDt",
                                "claimLinesList",
                                rowIndex
                              )}
                              onChange={this.props.handleChange(
                                "claimLinesList",
                                rowIndex
                              )}
                              label="Treat Therapy Date"
                            />
                            <div className={classes.validationMessage}>
                              {this.props.validator.message(
                                "treatTherapyDate",
                                selectedVo.formattedTreatmentTherapyDt,
                                "date_format"
                              )}
                            </div>
                          </div>
                          <div>
                            <InputField
                              name="formattedLastXrayDt"
                              disabled={!editable}
                              value={selectedVo.formattedLastXrayDt}
                              onClick={this.props.handleDates(
                                "#formattedLastXrayDt",
                                "claimLinesList",
                                rowIndex
                              )}
                              onChange={this.props.handleChange(
                                "claimLinesList",
                                rowIndex
                              )}
                              label="Last X-Ray Date"
                              maxlength= {10}
                            />
                            <div className={classes.validationMessage}>
                              {this.props.validator.message(
                                "lastXrayDate",
                                selectedVo.formattedLastXrayDt,
                                "date_format"
                              )}
                            </div>
                          </div>
                          <div>
                            <InputField
                              name="formattedInitialTreatmentDt"
                              disabled={!editable}
                              value={selectedVo.formattedInitialTreatmentDt}
                              onClick={this.props.handleDates(
                                "#formattedInitialTreatmentDt",
                                "claimLinesList",
                                rowIndex
                              )}
                              onChange={this.props.handleChange(
                                "claimLinesList",
                                rowIndex
                              )}
                              label="Init Treat Date"
                              maxLength={8}
                            />
                            <div className={classes.validationMessage}>
                              {this.props.validator.message(
                                "initialTreatmentDt",
                                selectedVo.formattedInitialTreatmentDt,
                                "date_format"
                              )}
                            </div>
                          </div>
                        </React.Fragment>
                      ) : null}
                  </div>
                  <hr />
                  <div className={classes.container}>
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="liNoteCd"
                            disabled={!editable}
                            maxLength={3}
                            value={selectedVo.liNoteCd}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Note Code"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}

                    <div>
                      <InputField
                        name="liProcDesc"
                        disabled={!editable}
                        maxLength={80}
                        value={selectedVo.liProcDesc}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="Procedure Descr"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="tpoLineNote"
                            disabled={!editable}
                            maxLength={80}
                            value={selectedVo.tpoLineNote}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="TPO Note"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    <div>
                      <InputField
                        name="liNoteText"
                        disabled={!editable}
                        maxLength={80}
                        value={selectedVo.liNoteText}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="Note"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                  </div>
                  <hr />
                  {selectedRow.encType === "P" ||
                    selectedRow.encType === "E" ? (
                      <div className={classes.container}>
                        <div>
                          <InputField
                            name="immunizationBatchNbr"
                            disabled={!editable}
                            maxLength={50}
                            value={selectedVo.immunizationBatchNbr}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Immuniz Batch Nbr"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="lineItemControlNbr"
                            value={selectedVo.lineItemControlNbr}
                            disabled={!editable}
                            maxLength={50}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Line Item Cntrl Nbr"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="mammogramCertNbr"
                            id="claimLinesList_mammogramCertNbr"
                            disabled={!editable}
                            value={selectedVo.mammogramCertNbr}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Mammogram Cert Nbr"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="heightResult"
                            disabled={!editable}
                            maxLength={20}
                            value={selectedVo.heightResult}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Height Result"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="hemoglobinResult"
                            disabled={!editable}
                            maxLength={20}
                            value={selectedVo.hemoglobinResult}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Hemoglobin Result"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="hematocritResult"
                            disabled={!editable}
                            maxLength={20}
                            value={selectedVo.hematocritResult}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Hematocrit Result"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="epoetinStartDoseRslt"
                            disabled={!editable}
                            maxLength={20}
                            value={selectedVo.epoetinStartDoseRslt}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Epoetin Strt Dose Rslt"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="creatinineResult"
                            disabled={!editable}
                            maxLength={20}
                            value={selectedVo.creatinineResult}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Creatinine Result"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="cliaImproveAmendNbr"
                            disabled={!editable}
                            maxLength={20}
                            value={selectedVo.cliaImproveAmendNbr}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="CLIAImprovAmendNbr"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="referringCliaNbr"
                            disabled={!editable}
                            maxLength={50}
                            value={selectedVo.referringCliaNbr}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Referring CLIA Nbr"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="orderPrvContactName"
                            disabled={!editable}
                            maxLength={60}
                            value={selectedVo.orderPrvContactName}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="OrderPrvContName"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="orderPrvEmail"
                            disabled={!editable}
                            maxLength={30}
                            value={selectedVo.orderPrvEmail}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Order Prv Email"
                          />
                          <div className={classes.validationMessage}>
                            {this.props.validator.message(
                              "orderPrvEmail",
                              selectedVo.orderPrvEmail,
                              "email"
                            )}
                          </div>
                        </div>
                        <div>
                          <InputField
                            name="orderPrvFax"
                            disabled={!editable}
                            maxLength={18}
                            value={selectedVo.orderPrvFax}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Order Prv FAX"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="orderPrvPhone"
                            disabled={!editable}
                            maxLength={18}
                            value={selectedVo.orderPrvPhone}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Order Prv Phone"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="orderPrvPhoneExt"
                            disabled={!editable}
                            maxLength={18}
                            value={selectedVo.orderPrvPhoneExt}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Order Prv Ext"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      </div>
                    ) : null}
                  <hr />
                  <div className={classes.container}>
                    <div>
                      <InputField
                        name="linkSeqNbr"
                        disabled={!editable}
                        maxLength={50}
                        value={selectedVo.linkSeqNbr}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="Link Seq Nbr"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="prescriptionNbr"
                        disabled={!editable}
                        maxLength={50}
                        value={selectedVo.prescriptionNbr}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="Prescription Nbr"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                  </div>
                  <div className={classes.applicationSectionHeading}>
                    <span> Repricing</span>
                  </div>
                  <div className={classes.container}>
                    <div>
                      <InputField
                        name="reprcdLiRefNbr"
                        disabled={!editable}
                        maxLength={15}
                        value={selectedVo.reprcdLiRefNbr}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="Line Ref Nbr"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <React.Fragment>
                          <div>
                            <InputField
                              name="reprcdAprvAmbpatgrpcd"
                              disabled={!editable}
                              maxLength={15}
                              value={selectedVo.reprcdAprvAmbpatgrpcd}
                              onChange={this.props.handleChange(
                                "claimLinesList",
                                rowIndex
                              )}
                              label="Apprv Amb Pat Grp Cd"
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div>
                            <InputField
                              name="formattedReprcdAprvAmbpatgrpamt"
                              disabled={true}
                              maxLength={15}
                              value={selectedVo.formattedReprcdAprvAmbpatgrpamt}
                              onChange={this.props.handleChange(
                                "claimLinesList",
                                rowIndex
                              )}
                              label="Apprv Amb Pat Grp Amt"
                            />
                            <div className={classes.validationMessage} />
                          </div>
                        </React.Fragment>
                      ) : null}
                    <div>
                      <InputField
                        name="adjReprcdLiRefNbr"
                        disabled={!editable}
                        maxLength={15}
                        value={selectedVo.adjReprcdLiRefNbr}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="Adj Line Ref Nbr"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="formattedReprcdAllowedAmt"
                        id="formattedReprcdAllowedAmt"
                        disabled={true}
                        value={selectedVo.formattedReprcdAllowedAmt}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="Allowed Amt"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="formattedReprcdSavingAmt"
                        disabled={true}
                        value={selectedVo.formattedReprcdSavingAmt}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="Saving Amt"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="formattedReprcdPerdiemAmt"
                        id="claimLinesList_reprcdPerdiemAmt"
                        disabled={true}
                        value={selectedVo.formattedReprcdPerdiemAmt}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="Per Diem Amt"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    {selectedRow.encType === "I" ? (
                      <React.Fragment>
                        <div>
                          <InputField
                            name="instReprcdDrgAmt"
                            disabled={true}
                            value={selectedVo.instReprcdDrgAmt}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="DRG Amt"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="instReprcdDrgCd"
                            disabled={!editable}
                            maxLength={30}
                            value={selectedVo.instReprcdDrgCd}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="DRG Code"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="instLiRevenueCd"
                            id="claimLinesList_instLiRevenueCd"
                            disabled={!editable}
                            maxLength={4}
                            value={selectedVo.instLiRevenueCd}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Rev Code"
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      </React.Fragment>
                    ) : null}
                    <div>
                      <InputField
                        name="reprcdOrgId"
                        id="claimLinesList_reprcdOrgId"
                        disabled={!editable}
                        maxLength={50}
                        value={selectedVo.reprcdOrgId}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="Organization ID"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="formattedReprcdSvcUnitCnt"
                        disabled={!editable}
                        value={selectedVo.formattedReprcdSvcUnitCnt}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="Svc Unit Cnt"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="reprcdUomCd"
                        disabled={!editable}
                        maxLength={2}
                        value={selectedVo.reprcdUomCd}
                        onChange={this.props.handleChange(
                          "claimLinesList",
                          rowIndex
                        )}
                        label="UOM Code"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="reprcdAprvHcpcsCd"
                            disabled={!editable}
                            maxLength={15}
                            value={selectedVo.reprcdAprvHcpcsCd}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                            label="Appr HCPCS Code"
                          />
                          <div className={classes.validationMessage} />
                        </div>) :
                      (<div>
                        <InputField
                          name="instReprcdApprHcpcsCd"
                          disabled={!editable}
                          maxLength={15}
                          value={selectedVo.instReprcdApprHcpcsCd}
                          onChange={this.props.handleChange(
                            "claimLinesList",
                            rowIndex
                          )}
                          label="Appr HCPCS Code"
                        />
                        <div className={classes.validationMessage} />
                      </div>)}
                  </div>
                  {selectedRow.encType === "P" ||
                    selectedRow.encType === "E" ? (
                      <React.Fragment>
                        <div className={classes.applicationSectionHeading}>
                          <span> Ambulatory</span>
                        </div>
                        <div class="panel-body">
                          <div class="twin-margin">
                            <div class="twin-boxes">
                              <div class="form-panel">
                                <div className={classes.container}>
                                  <div>
                                    <InputField
                                      name="ambPickupAddrLine1"
                                      id="claimLinesList_ambPickupAddrLine1"
                                      label="Pick Up Addr1"
                                      disabled={!editable}
                                      value={selectedVo.ambPickupAddrLine1}
                                      onChange={this.props.handleChange(
                                        "claimLinesList",
                                        rowIndex
                                      )}
                                    />
                                    <div className={classes.validationMessage} />
                                  </div>
                                  <div>
                                    <InputField
                                      name="ambPickupAddrLine2"
                                      id="claimLinesList_ambPickupAddrLine2"
                                      label="Pick Up Addr2"
                                      disabled={!editable}
                                      value={selectedVo.ambPickupAddrLine2}
                                      onChange={this.props.handleChange(
                                        "claimLinesList",
                                        rowIndex
                                      )}
                                    />
                                    <div className={classes.validationMessage} />
                                  </div>
                                  <div>
                                    <InputField
                                      name="ambPickupCity"
                                      id="claimLinesList_ambPickupCity"
                                      label="Pick Up City"
                                      disabled={!editable}
                                      value={selectedVo.ambPickupCity}
                                      onChange={this.props.handleChange(
                                        "claimLinesList",
                                        rowIndex
                                      )}
                                    />
                                    <div className={classes.validationMessage} />
                                  </div>
                                  <div>
                                    <Select
                                      components={components}
                                      propertyName={dropdowns.stateList.filter(
                                        (option) =>
                                          option.value === selectedVo.ambPickupState
                                      )}
                                      options={dropdowns.stateList}
                                      label="Choose Process Status ..."
                                      textFieldProps={{
                                        id: "othSubsState",
                                        label: "Pick Up State",
                                        InputLabelProps: {
                                          className: classes.label,
                                          shrink: true,
                                        },
                                      }}
                                      className={classes.textFieldSelect}
                                      handleChange={this.props.handleSelect(
                                        "ambPickupState",
                                        "claimLinesList",
                                        rowIndex
                                      )}
                                      classes={classes}
                                      isDisabled={!editable}
                                    />
                                  </div>
                                  <div />
                                  <div>
                                    <InputField
                                      name="ambPickupZip"
                                      label="Pick Up Zip"
                                      maxLength={10}
                                      disabled={!editable}
                                      value={selectedVo.ambPickupZip}
                                      onBlur={this.props.handleClmBlur(
                                        "",
                                        selectedVo.ambPickupZip,
                                        "ambPickupZip",
                                        "claimLinesList",
                                        rowIndex)}
                                      onChange={this.props.handleNumber(
                                        "claimLinesList",
                                        rowIndex
                                      )}
                                    />
                                    {editable ? (
                                      <Popup
                                        style={{ height: "65%" }}
                                        className={classes.mobileWidth}
                                        modal
                                        trigger={<span class="more-info" />}
                                        position="right center"
                                      >
                                        {(close) => (
                                          <div>
                                            <CityZipSearch
                                              headerLabel="PickUpZip Search"
                                              zip5={selectedVo.ambPickupZip}
                                              zip4={""}
                                              targetVo={"claimLinesList"}
                                              param={"ambPickupZip"}
                                              index={rowIndex}
                                              searchType="Zip_SEARCH"
                                              close={close}
                                              setData={this.props.setZipData}
                                            />
                                          </div>
                                        )}
                                      </Popup>
                                    ) : null}
                                    <div className={classes.validationMessage}>
                                      {this.props.validator.message(
                                        "pickUpZip",
                                        selectedVo.ambPickupZip,
                                        "numeric|min:0,num"
                                      )}
                                    </div>
                                  </div>
                                  <div>
                                    <InputField
                                      name="ambPickupCountry"
                                      label="Country Code"
                                      maxLength={3}
                                      disabled={!editable}
                                      value={selectedVo.ambPickupCountry}
                                      onChange={this.props.handleChange(
                                        "claimLinesList",
                                        rowIndex
                                      )}
                                    />
                                    <div
                                      className={classes.validationMessageSelect}
                                    ></div>
                                  </div>
                                  <div>
                                    <InputField
                                      name="ambPickupCntrySubd"
                                      id="claimLinesList_ambPickupCntrySubd"
                                      label="Subd Code"
                                      disabled={!editable}
                                      value={selectedVo.ambPickupCntrySubd}
                                      onChange={this.props.handleChange(
                                        "claimLinesList",
                                        rowIndex
                                      )}
                                    />
                                    <div
                                      className={classes.validationMessageSelect}
                                    ></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="twin-boxes">
                              <div class="form-panel">
                                <div className={classes.container} style={{marginLeft:"48px"}}>
                                  <div>
                                    <InputField
                                      name="ambDropoffLoc"
                                      id="claimLinesList_ambDropoffLoc"
                                      label="Drop Off Loc"
                                      disabled={!editable}
                                      value={selectedVo.ambDropoffLoc}
                                      onChange={this.props.handleChange(
                                        "claimLinesList",
                                        rowIndex
                                      )}
                                    />
                                    <div className={classes.validationMessage} />
                                  </div>
                                  <div>
                                    <InputField
                                      name="ambDropoffAddrLine1"
                                      id="claimLinesList_ambDropoffAddrLine1"
                                      label="Drop Off Addr1"
                                      disabled={!editable}
                                      value={selectedVo.ambDropoffAddrLine1}
                                      onChange={this.props.handleChange(
                                        "claimLinesList",
                                        rowIndex
                                      )}
                                    />
                                    <div className={classes.validationMessage} />
                                  </div>

                                  <div>
                                    <InputField
                                      name="ambDropoffAddrLine2"
                                      id="claimLinesList_ambDropoffAddrLine2"
                                      label="Drop Off Addr2"
                                      disabled={!editable}
                                      value={selectedVo.ambDropoffAddrLine2}
                                      onChange={this.props.handleChange(
                                        "claimLinesList",
                                        rowIndex
                                      )}
                                    />
                                    <div className={classes.validationMessage} />
                                  </div>
                                  <div />
                                  <div>
                                    <InputField
                                      name="ambDropoffCity"
                                      id="claimLinesList_ambDropoffCity"
                                      label="Drop Off City"
                                      disabled={!editable}
                                      value={selectedVo.ambDropoffCity}
                                      onChange={this.props.handleChange(
                                        "claimLinesList",
                                        rowIndex
                                      )}
                                    />
                                    <div
                                      className={classes.validationMessage}
                                    ></div>
                                  </div>
                                  <div>
                                    <Select
                                      components={components}
                                      propertyName={dropdowns.stateList.filter(
                                        (option) =>
                                          option.value ===
                                          selectedVo.ambDropoffState
                                      )}
                                      options={dropdowns.stateList}
                                      label="Choose Process Status ..."
                                      textFieldProps={{
                                        id: "othSubsState",
                                        label: "Drop Off State",
                                        InputLabelProps: {
                                          className: classes.label,
                                          shrink: true,
                                        },
                                      }}
                                      className={classes.textFieldSelect}
                                      handleChange={this.props.handleSelect(
                                        "ambDropoffState",
                                        "claimLinesList",
                                        rowIndex
                                      )}
                                      classes={classes}
                                      isDisabled={!editable}
                                    />
                                  </div>
                                  <div>
                                    <InputField
                                      name="ambDropoffZip"
                                      label="Drop Off Zip"
                                      disabled={!editable}
                                      value={selectedVo.ambDropoffZip}
                                      onBlur={this.props.handleClmBlur(
                                        "",
                                        selectedVo.ambDropoffZip,
                                        "ambDropoffZip",
                                        "claimLinesList",
                                        rowIndex)}
                                      onChange={this.props.handleNumber(
                                        "claimLinesList",
                                        rowIndex
                                      )}
                                    />
                                    {editable ? (
                                      <Popup
                                        style={{ height: "65%" }}
                                        className={classes.mobileWidth}
                                        modal
                                        trigger={<span class="more-info" />}
                                        position="right center"
                                      >
                                        {(close) => (
                                          <div>
                                            <CityZipSearch
                                              headerLabel="DropOffZip Search"
                                              zip5={selectedVo.ambDropoffZip}
                                              zip4={""}
                                              targetVo={"claimLinesList"}
                                              param={"ambDropoffZip"}
                                              index={rowIndex}
                                              searchType="Zip_SEARCH"
                                              close={close}
                                              setData={this.props.setZipData}
                                            />
                                          </div>
                                        )}
                                      </Popup>
                                    ) : null}
                                    <div className={classes.validationMessage}>
                                      {this.props.validator.message(
                                        "dropOffZip",
                                        selectedVo.ambDropoffZip,
                                        "numeric|min:0,num"
                                      )}
                                    </div>
                                  </div>

                                  <div>
                                    <InputField
                                      name="ambDropoffCountry"
                                      id="claimLinesList_ambDropoffCountry"
                                      label="Country Code"
                                      maxLength={3}
                                      disabled={!editable}
                                      value={selectedVo.ambDropoffCountry}
                                      onChange={this.props.handleChange(
                                        "claimLinesList",
                                        rowIndex
                                      )}
                                    />
                                    <div
                                      className={classes.validationMessage}
                                    ></div>
                                  </div>
                                  <div>
                                    <InputField
                                      name="ambDropoffCntrySubd"
                                      id="claimLinesList_ambDropoffCntrySubd"
                                      label="Subd Code"
                                      disabled={!editable}
                                      value={selectedVo.ambDropoffCntrySubd}
                                      onChange={this.props.handleChange(
                                        "claimLinesList",
                                        rowIndex
                                      )}
                                    />
                                    <div
                                      className={classes.validationMessage}
                                    ></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <hr />
                      </React.Fragment>
                    ) : null}
                  {selectedRow.encType === "P" ||
                    selectedRow.encType === "E" ? (
                      <div className={classes.container}>

                        <div>
                          <InputField
                            name="ambTransportReasCd"
                            id="claimLinesList_ambTransportReasCd"
                            label="Transp Reason"
                            disabled={!editable}
                            maxLength={1}
                            value={selectedVo.ambTransportReasCd}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                          />
                          <div className={classes.validationMessage}></div>
                        </div>


                        <div>
                          <InputField
                            name="ambTransportDistance"
                            id="claimLinesList_ambTransportDistance"
                            label="Transp Distance"
                            disabled={!editable}
                            maxLength={22}
                            value={selectedVo.ambTransportDistance}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                          />
                          <div className={classes.validationMessage}></div>
                        </div>


                        <div>
                          <InputField
                            name="ambPatientWeight"
                            id="claimLinesList_ambPatientWeight"
                            label="Patient Weight"
                            disabled={!editable}
                            maxLength={10}
                            value={selectedVo.ambPatientWeight}
                            onChange={this.props.handleNumber(
                              "claimLinesList",
                              rowIndex
                            )}
                          />
                          <div className={classes.validationMessage}></div>
                        </div>

                      </div>
                    ) : null}
                  {selectedRow.encType === "P" ||
                    selectedRow.encType === "E" ? (
                      <div className={classes.container}>
                        <div>
                          <InputField
                            name="ambCertCondInd"
                            id="claimLinesList_ambCertCondInd"
                            label="Cert Cond Ind"
                            maxLength={1}
                            disabled={!editable}
                            value={selectedVo.ambCertCondInd}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                          />
                          <div className={classes.validationMessage}></div>
                        </div>


                        <div>
                          <InputField
                            name="ambCertCondCd1"
                            id="claimLinesList_ambCertCondCd1"
                            label="Cert Cond Code1"
                            maxLength={2}
                            disabled={!editable}
                            value={selectedVo.ambCertCondCd1}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                          />
                          <div className={classes.validationMessage}></div>
                        </div>


                        <div>
                          <InputField
                            name="ambCertCondCd2"
                            id="claimLinesList_ambCertCondCd2"
                            label="Cert Cond Code2"
                            maxLength={2}
                            disabled={!editable}
                            value={selectedVo.ambCertCondCd2}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                          />
                          <div className={classes.validationMessage}></div>
                        </div>


                        <div>
                          <InputField
                            name="ambCertCondCd3"
                            id="claimLinesList_ambCertCondCd3"
                            label="Cert Cond Code3"
                            maxLength={2}
                            disabled={!editable}
                            value={selectedVo.ambCertCondCd3}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                          />
                          <div className={classes.validationMessage}></div>
                        </div>


                        <div>
                          <InputField
                            name="ambCertCondCd4"
                            id="claimLinesList_ambCertCondCd4"
                            label="Cert Cond Code4"
                            maxLength={2}
                            disabled={!editable}
                            value={selectedVo.ambCertCondCd4}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                          />
                          <div className={classes.validationMessage}></div>
                        </div>


                        <div>
                          <InputField
                            name="ambCertCondCd5"
                            id="claimLinesList_ambCertCondCd5"
                            label="Cert Cond Code5"
                            maxLength={2}
                            disabled={!editable}
                            value={selectedVo.ambCertCondCd5}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                          />
                          <div className={classes.validationMessage}></div>
                        </div>

                      </div>
                    ) : null}
                  {selectedRow.encType === "P" ||
                    selectedRow.encType === "E" ? (
                      <div className={classes.container}>
                        <div>
                          <InputField
                            name="ambRoundTripPurpDesc"
                            label="Round Trip Purpose"
                            disabled={!editable}
                            maxLength={80}
                            width="380px"
                            value={selectedVo.ambRoundTripPurpDesc}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                          />
                          <div className={classes.validationMessage}></div>
                        </div>

                        <div>
                          <InputField
                            name="ambStretcherPurpDesc"
                            label="Stretcher Purpose"
                            disabled={!editable}
                            maxLength={80}
                            width="380px"
                            value={selectedVo.ambStretcherPurpDesc}
                            onChange={this.props.handleChange(
                              "claimLinesList",
                              rowIndex
                            )}
                          />
                          <div className={classes.validationMessage}></div>
                        </div>
                      </div>
                    ) : null}
                </div>
              </div>
              <React.Fragment>
              <div className={classes.applicationTableHeading}>
                <span> Claim Line Attachment</span>
              </div>
              <div>
                <DataTable
                  data={
                    selectedVo.claimLineAttachments
                      ? selectedVo.claimLineAttachments
                      : []
                  }
                  header={CLAIM_LINE_ATTACHMENT}
                  rowsPerPage={5}
                  sortable={true}
                  clicked={this.selectRow}
                />
              </div>
              </React.Fragment>
              {selectedRow.encType === "P" || selectedRow.encType === "E" ? (
                <React.Fragment>
                <div className={classes.applicationTableHeading}>
                  <span> Claim Line Referral</span>
                </div>
                  <DataTable
                    data={
                      selectedVo.claimLineAttachments
                        ? selectedVo.claimLineAttachments
                        : []
                    }
                    header={CLAIM_LINE_REFERRAL}
                    rowsPerPage={5}
                    sortable={true}
                    clicked={this.selectRow}
                  />
                </React.Fragment>
              ) : null}
              {selectedRow.encType === "P" || selectedRow.encType === "E" ? (
                <React.Fragment>
                <div className={classes.applicationTableHeading}>
                  <span> Claim Line Doc</span>
                </div>
                  <div>
                    <DataTable
                      data={
                        selectedVo.claimLineDocs ? selectedVo.claimLineDocs : []
                      }
                      header={CLAIM_LINE_DOC}
                      rowsPerPage={5}
                      sortable={true}
                      clicked={this.selectRow}
                    />
                  </div>
                </React.Fragment>
              ) : null}
            </ExpansionPanel>
          </React.Fragment>
        ) : (
            ""
          )}
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    dataTableVo: state.ClaimCodeReducer.claimVo.claimLinesList
  };
};

export default connect(
  mapStateToProps,
  null
)(withStyles(Styles)(ClaimLine));
