import React, { Component } from "react";
import { withStyles } from "@material-ui/core/styles";
import DataTable from "../Home/DataTable";
import { Styles } from "../../assets/styles/PopupTheme";
import { connect } from "react-redux";
import InputField from "../UI/InputField";
import { LOG_DETAILS, LOG_DETAILS_EXPORT } from "../../constants/header/encounterDetailsHeader";
import { logDetailsSearch } from "../../redux/actions/encounterDetailsAction";

class LogDetail extends Component {
  constructor(props) {
    super(props);
    this.state = {
      logVo: {
        mfId: this.props.selectedRow.mfId,
        wtxClaimRevNbr: this.props.selectedRow.wtxClaimRevNbr,
        claimSeqNbr: this.props.selectedRow.claimSeqNbr,
        claimType: this.props.selectedRow.claimType,
        wtxClaimRefNbr: this.props.selectedRow.wtxClaimRefNbr,
        historyFlag: false
      },
      selectedRowIndex: 0
    };
  }

  async componentDidMount() {
    this.props.logDetailsSearch(this.state.logVo);
  }

  selectRow = (index) => {
    console.log(index)
  }

  history = async () => {
    await this.setState(prevState => ({
      logVo: {
        ...prevState.logVo,
        historyFlag: true
      }
    }));
    this.props.logDetailsSearch(this.state.logVo);
  };

  render() {
    const { classes, logDetails, selectedRow } = this.props;
    return (
      <React.Fragment>
        <div className={classes.applicationSectionHeading}>
          <span>CHANGE LOG</span>
        </div>
        <div className={classes.container}>
          <div>
            <InputField
              name="logclmRefNbr"
              value={selectedRow.wtxClaimRefNbr}
              label="Claim Ref Nbr"
              disabled={true}
            />
            <div className={classes.validationMessage} />
          </div>
          <div>
            <InputField
              name="logclmRevNbr"
              value={selectedRow.wtxClaimRevNbr}
              label="Claim Rev Nbr"
              disabled={true}
            />
            <div className={classes.validationMessage} />
          </div>
        </div>

        <DataTable
          data={logDetails}
          header={LOG_DETAILS}
          exportHeader={LOG_DETAILS_EXPORT}
          exportAsExcel={true}
          rowsPerPage={5}
          sortable={true}
          clicked={this.selectRow}
        />
        <button
          class="btn btn-primary"
          style={{ float: 'right' }}
          onClick={this.props.close}
        >
          Cancel
        </button>
        <button
          class="btn btn-secondary"
          style={{ float: 'right' }}
          onClick={this.history}
        >
          History
        </button>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  return {
    logDetails: state.encounterDetailsData.logDetails
  };
};

const mapDispatchToProps = {
  logDetailsSearch
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(LogDetail));
