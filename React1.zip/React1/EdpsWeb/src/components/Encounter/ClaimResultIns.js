import React from "react";
import { withStyles } from "@material-ui/core/styles";
import InputField from "../UI/InputField";
import { Styles } from "../../assets/styles/Theme";
import { Control, Menu, Option, Select, ValueContainer } from "../UI/Select";
const components = {
  Control,
  Menu,
  ValueContainer,
  Option,
};

class ClaimResultIns extends React.Component {
  render() {
    const { classes, dropdowns, editable, claimVo } = this.props;
    return (
      <div class="panel-body">
        {claimVo.claimResult ? (
          <div className={classes.container}>
            <div>
              <InputField
                name="patientCtrlNbr"
                value={claimVo.claimResult.patientCtrlNbr}
                maxLength={20}
                onChange={this.props.handleChange("claimResult")}
                label="Patient Control Nbr"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="formattedTotClmChargeAmt"
                id="formattedTotClmChargeAmt"
                value={claimVo.claimResult.formattedTotClmChargeAmt}
                onChange={this.props.handleChange("claimResult")}
                label="Tot Claim Charge Amt"
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            {!editable ?
              (<div>
                <InputField
                  name="processStatus"
                  id="claimResult_processStatus"
                  value={claimVo.claimResult.processStatus}
                  onChange={this.props.handleChange("claimResult")}
                  label="Process Status"
                  disabled={true}
                />
                <div className={classes.validationMessage} />
              </div>) :
              (<div>
                <Select
                  components={components}
                  propertyName={dropdowns.processStatus.filter(
                    (option) => option.value === claimVo.claimResult.processStatus
                  )}
                  options={dropdowns.processStatus}
                  label="Choose Process Status ..."
                  textFieldProps={{
                    id: "processStatus",
                    label: "Process Status",
                    InputLabelProps: {
                      className: classes.label,
                      shrink: true,
                    },
                  }}
                  className={classes.textFieldSelect}
                  handleChange={this.props.handleSelect(
                    "processStatus",
                    "claimResult"
                  )}
                  classes={classes}
                  isDisabled={!editable}
                />
              </div>)}
            <div>
              <InputField
                name="wtxClaimRevNbr"
                onChange={this.props.handleChange("claimResult")}
                label="Claim Rev Nbr"
                value={claimVo.claimResult.wtxClaimRevNbr}
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="wtxClaimRefNbr"
                value={claimVo.claimResult.wtxClaimRefNbr}
                onChange={this.props.handleChange("claimResult")}
                label="Claim Ref Nbr"
                maxLength={20}
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            <div style={{ marginRight: "16px" }}>
              <InputField
                name="custFileName"
                value={claimVo.claimResult.custFileName}
                width="371px"
                onChange={this.props.handleChange("claimResult")}
                label="File Name"
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="formattedPatientRespAmt"
                value={claimVo.claimResult.formattedPatientRespAmt}
                onChange={this.props.handleChange("claimResult")}
                label="Patient Resp Amt"
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="contractTypeCd"
                id="claimResult_contractTypeCd"
                value={claimVo.claimResult.contractTypeCd}
                onChange={this.props.handleChange("claimResult")}
                label="Contract Type Code"
                maxLength={2}
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="instClmFacTypeCd"
                value={claimVo.claimResult.instClmFacTypeCd}
                onChange={this.props.handleChange("claimResult")}
                label="Claim Fac Type Cd"
                maxLength={2}
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="clmFreqTypeCd"
                value={claimVo.claimResult.clmFreqTypeCd}
                onChange={this.props.handleChange("claimResult")}
                label="Claim Freq Type Cd"
                maxLength={1}
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="formattedContractAmt"
                value={claimVo.claimResult.formattedContractAmt}
                onChange={this.props.handleChange("claimResult")}
                label="Contract Amt"
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="contractVersionId"
                id="claimResult_contractVersionId"
                value={claimVo.claimResult.contractVersionId}
                onChange={this.props.handleChange("claimResult")}
                label="Contract Versn ID"
                maxLength={50}
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="formattedContractPct"
                id="claimResult1_formattedContractPct"
                value={claimVo.claimResult.formattedContractPct}
                onChange={this.props.handleChange("claimResult")}
                label="Contract Pct"
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="contractCd"
                id="contractCd"
                value={claimVo.claimResult.contractCd}
                onChange={this.props.handleChange("claimResult")}
                label="Contract Code"
                maxLength={15}
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="instAdmitDiagType"
                value={claimVo.claimResult.instAdmitDiagType}
                onChange={this.props.handleChange("claimResult")}
                label="Admit Diag Type"
                maxLength={3}
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="instAdmitDiagCd"
                value={claimVo.claimResult.instAdmitDiagCd}
                onChange={this.props.handleChange("claimResult")}
                label="Admit Diag Code"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="beneAssignCertInd"
                value={claimVo.claimResult.beneAssignCertInd}
                onChange={this.props.handleChange("claimResult")}
                label="Bene Assign Cert"
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="formattedTermsDiscountPct"
                id="formattedTermsDiscountPct"
                value={claimVo.claimResult.formattedTermsDiscountPct}
                onChange={this.props.handleChange("claimResult")}
                label="Terms Discount Pct"
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="prvAcceptAssignCd"
                value={claimVo.claimResult.prvAcceptAssignCd}
                onChange={this.props.handleChange("claimResult")}
                label="Prev Accept Assign Cd"
                maxLength={1}
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="instRepricedUom"
                id="claimResult_instRepricedUom"
                value={claimVo.claimResult.instRepricedUom}
                onChange={this.props.handleChange("claimResult")}
                label="UOM"
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="formattedRepricedAllowedAmt"
                value={claimVo.claimResult.formattedRepricedAllowedAmt}
                onChange={this.props.handleChange("claimResult")}
                label="Reprice Allowed Amt"
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="formattedRepricedSavingAmt"
                value={claimVo.claimResult.formattedRepricedSavingAmt}
                onChange={this.props.handleChange("claimResult")}
                label="Reprice Saving Amt"
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="formattedRepricedApprvdAmt"
                value={claimVo.claimResult.formattedRepricedApprvdAmt}
                onChange={this.props.handleChange("claimResult")}
                label="Reprice Approved Amt"
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            {/* property */}
            {/* <div>
              <InputField
                name="instRepricingPerdiemAmt"
                value={claimVo.claimResult.instRepricingPerdiemAmt}
                onChange={this.props.handleChange("claimResult")}
                label="Repricing Per Diem Amt"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div> */}
            <div>
              <InputField
                name="formattedRepricingPerdiemAmt"
                value={claimVo.claimResult.formattedRepricingPerdiemAmt}
                onChange={this.props.handleChange("claimResult")}
                label="Reprice Per Diem Amt"
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="pricingMethodology"
                id="claimResult_pricingMethodology"
                maxLength={1}
                value={claimVo.claimResult.pricingMethodology}
                onChange={this.props.handleChange("claimResult")}
                label="Pricing Methdlgy"
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="ambPickupZip"
                id="ambPickupZip"
                maxLength={10}
                value={claimVo.claimResult.ambPickupZip}
                onChange={this.props.handleChange("claimResult")}
                label="Ambulance Pikup Zip"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="releaseOfInfoCd"
                value={claimVo.claimResult.releaseOfInfoCd}
                onChange={this.props.handleChange("claimResult")}
                label="Rlse of Info Code"
                disabled={!editable}
                maxLength={1}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="instPatientStatusCd"
                value={claimVo.claimResult.instPatientStatusCd}
                onChange={this.props.handleChange("claimResult")}
                label="Patient Status Code"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="autoAccidentState"
                value={claimVo.claimResult.autoAccidentState}
                onChange={this.props.handleChange("claimResult")}
                label="Auto Accident State"
                maxLength={2}
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="delayReasonCd"
                value={claimVo.claimResult.delayReasonCd}
                onChange={this.props.handleChange("claimResult")}
                label="Delay Reason"
                maxLength={2}
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="svcAuthExcptCd"
                id="claimResult1_svcAuthExcptCd"
                value={claimVo.claimResult.svcAuthExcptCd}
                onChange={this.props.handleChange("claimResult")}
                label="Svc Auth Except Cd"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="instDrgCd"
                value={claimVo.claimResult.instDrgCd}
                onChange={this.props.handleChange("claimResult")}
                label="DRG Code"
                maxLength={30}
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="instAdmitType"
                id="instAdmitType"
                value={claimVo.claimResult.instAdmitType}
                onChange={this.props.handleChange("claimResult")}
                label="Admit Type"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="instAdmitSourceCd"
                value={claimVo.claimResult.instAdmitSourceCd}
                onChange={this.props.handleChange("claimResult")}
                label="Admit Srce Code"
                maxLength={1}
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="formattedAdmitDt"
                value={claimVo.claimResult.formattedAdmitDt}
                onClick={this.props.handleDates("#formattedAdmitDt", "claimResult")}
                onChange={this.props.handleChange("claimResult")}
                label="Admit Date"
                maxLength={10}
                disabled={!editable}
              />
              <div className={classes.validationMessage}>
                {this.props.validator.message(
                  "AdmitDate",
                  claimVo.claimResult.formattedAdmitDt,
                  "date_format"
                )}
              </div>
            </div>
            <div>
              <InputField
                name="instAdmitHour"
                value={claimVo.claimResult.instAdmitHour}
                onChange={this.props.handleChange("claimResult")}
                label="Admit Hour"
                maxLength={4}
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="instDischargeHour"
                value={claimVo.claimResult.instDischargeHour}
                onChange={this.props.handleChange("claimResult")}
                label="Discharge Hour"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="formattedStatementFromDt"
                value={claimVo.claimResult.formattedStatementFromDt}
                onClick={this.props.handleDates(
                  "#formattedStatementFromDt",
                  "claimResult"
                )}
                onChange={this.props.handleChange("claimResult")}
                label="Statement From Date"
                maxLength={10}
                disabled={!editable}
              />
              <div className={classes.validationMessage}>
                {this.props.validator.message(
                  "statementFromDate",
                  claimVo.claimResult.formattedStatementFromDt,
                  "date_format"
                )}
              </div>
            </div>
            <div>
              <InputField
                name="formattedStatementToDt"
                value={claimVo.claimResult.formattedStatementToDt}
                onClick={this.props.handleDates(
                  "#formattedStatementToDt",
                  "claimResult"
                )}
                onChange={this.props.handleChange("claimResult")}
                label="Statement to Date"
                maxLength={10}
                disabled={!editable}
              />
              <div className={classes.validationMessage}>
                {this.props.validator.message(
                  "statementToDate",
                  claimVo.claimResult.formattedStatementToDt,
                  "date_format"
                )}
              </div>
            </div>
            {/* property  */}
            <div>
              <InputField
                name="epsdtCertCondInd"
                value={claimVo.claimResult.epsdtCertCondInd}
                onChange={this.props.handleChange("claimResult")}
                label="EPSDT Cert Cond Appl"
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="epsdtCondInd1"
                maxLength={2}
                value={claimVo.claimResult.epsdtCondInd1}
                onChange={this.props.handleChange("claimResult")}
                label="EPSDT Condition1"
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="epsdtCondInd2"
                maxLength={2}
                value={claimVo.claimResult.epsdtCondInd2}
                onChange={this.props.handleChange("claimResult")}
                label="EPSDT Condition2"
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="epsdtCondInd3"
                maxLength={2}
                value={claimVo.claimResult.epsdtCondInd3}
                onChange={this.props.handleChange("claimResult")}
                label="EPSDT Condition3"
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
          </div>
        ) : null}
      </div>
    );
  }
}

export default withStyles(Styles)(ClaimResultIns);
