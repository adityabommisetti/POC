import React from "react";
import Popup from "reactjs-popup";
import isEmpty from "lodash/isEmpty";
import DataTable from "../Home/DataTable";
import { withStyles } from "@material-ui/core/styles";
import InputField from "../UI/InputField";
import { Styles } from "../../assets/styles/Theme";
import CityZipSearch from "./CityZipSearch";
import ExpansionPanel from "../UI/ExpansionPanel";
import { CLAIM_SUSCRIBER } from "../../constants/header/encounterDetailsHeader";
import { components, Select } from "../UI/Select";

class ClaimSubscriber extends React.Component {
  state = {
    claimSubscriberList: this.props.claimSubscriber,
    selectedVo:
      this.props.claimSubscriber != null
        ? {
          ...(this.props.claimSubscriber[0]
            ? this.props.claimSubscriber[0]
            : null),
        }
        : {},
    rowIndex: 0,
  };

  // async componentWillReceiveProps(nextProps) {
  //     await this.setState({
  //         claimSubscriberList: nextProps.claimSubscriber
  //     })
  //     if (nextProps.claimSubscriber && nextProps.claimSubscriber.length > 0) {
  //         this.setState({
  //             selectedVo: nextProps.claimSubscriber[rowIndex]
  //         });
  //     }
  // }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (!isEmpty(nextProps.claimSubscriber)) {
      if (
        prevState.claimSubscriberList[prevState.rowIndex] !==
        nextProps.claimSubscriber[prevState.rowIndex]
      ) {
        return {
          selectedVo: nextProps.claimSubscriber[prevState.rowIndex],
        };
      }
    }
    return null;
  }

  selectRow = async (index) => {
    const selectedVo = this.state.claimSubscriberList[index];
    await this.setState({
      selectedVo: selectedVo,
      rowIndex: index,
    });
  };

  render() {
    const {
      classes,
      dropdowns,
      claimSubscriber,
      editable,
      selectedRow,
    } = this.props;
    const { selectedVo, rowIndex } = this.state;
    return (
      <React.Fragment>
        <div>
          <DataTable
            data={claimSubscriber}
            header={CLAIM_SUSCRIBER}
            rowsPerPage={5}
            sortable={true}
            clicked={this.selectRow}
          />
        </div>
        {!isEmpty(claimSubscriber) ? (
          <ExpansionPanel summary="Claim - Other Subscriber-Detail">
            <div id="claimSubscriberDetail">
              <div class="panel-body">
                <div className={classes.container}>
                  <div>
                    <InputField
                      name="insuredGrpOrPolNbr"
                      id="claimOthSubsList_insuredGrpOrPolNbr"
                      value={selectedVo.insuredGrpOrPolNbr}
                      maxLength={50}
                      onChange={this.props.handleChange(
                        "claimOthSubsList",
                        rowIndex
                      )}
                      label="Insured Grp or Pol Nbr"
                      disabled={!editable}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  {selectedRow.encType === "P" ||
                    selectedRow.encType === "E" ? (
                      <div>
                        <InputField
                          name="patSignSrcCd"
                          id="claimOthSubsList_patSignSrcCd"
                          value={selectedVo.patSignSrcCd}
                          maxLength={1}
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          label="Pat Sign Src Code"
                          disabled={!editable}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}

                  <div>
                    <InputField
                      name="formattedRemainPatientLiab"
                      value={selectedVo.formattedRemainPatientLiab}
                      onChange={this.props.handleChange(
                        "claimOthSubsList",
                        rowIndex
                      )}
                      label="Remain Patient Liab"
                      disabled={true}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="formattedPayerPaidAmt"
                      value={selectedVo.formattedPayerPaidAmt}
                      onChange={this.props.handleChange(
                        "claimOthSubsList",
                        rowIndex
                      )}
                      label="Payer Paid Amt"
                      disabled={true}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="benefitsAsgnCertInd"
                      value={selectedVo.benefitsAsgnCertInd}
                      maxLength={1}
                      onChange={this.props.handleChange(
                        "claimOthSubsList",
                        rowIndex
                      )}
                      label="Benefits Assign Cert"
                      disabled={!editable}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="formattedCheckRemitDt"
                      value={selectedVo.formattedCheckRemitDt}
                      maxLength={10}
                      onClick={this.props.handleDates(
                        "#formattedCheckRemitDt",
                        "claimOthSubsList",
                        rowIndex
                      )}
                      onChange={this.props.handleChange(
                        "claimOthSubsList",
                        rowIndex
                      )}
                      label="Check Remit Date"
                      disabled={!editable}
                    />
                    <div className={classes.validationMessage}>
                      {this.props.validator.message(
                        "checkRemitDate",
                        selectedVo.formattedCheckRemitDt,
                        "date_format"
                      )}
                    </div>
                  </div>
                  <div>
                    <InputField
                      name="formattedCobNonCovrdChrgAmt"
                      value={selectedVo.formattedCobNonCovrdChrgAmt}
                      onChange={this.props.handleChange(
                        "claimOthSubsList",
                        rowIndex
                      )}
                      label="Cob Non Cov Charge Amt"
                      disabled={true}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="payerResponseCd"
                      value={selectedVo.payerResponseCd}
                      maxLength={1}
                      onChange={this.props.handleChange(
                        "claimOthSubsList",
                        rowIndex
                      )}
                      label="Payer Resp Code"
                      disabled={!editable}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="releaseMedRcdFlg"
                      value={selectedVo.releaseMedRcdFlg}
                      maxLength={1}
                      onChange={this.props.handleChange(
                        "claimOthSubsList",
                        rowIndex
                      )}
                      label="Release Med Rec Flag"
                      disabled={!editable}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="indivRelationshipCd"
                      value={selectedVo.indivRelationshipCd}
                      maxLength={2}
                      onChange={this.props.handleChange(
                        "claimOthSubsList",
                        rowIndex
                      )}
                      label="Indiv Relat Code"
                      disabled={!editable}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                </div>
              </div>
              {selectedRow.encType === "I" ? (
                <React.Fragment>
                  <div className={classes.applicationSectionHeading}>
                    <span>Inpatient Adjudication Information</span>
                  </div>
                  <div class="panel-body">
                    <div className={classes.container}>
                      <div>
                        <InputField
                          name="formattedMiaClmSspPasthruAmt"
                          value={selectedVo.formattedMiaClmSspPasthruAmt}
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          label="Claim SSP Passthrgh Amt"
                          disabled={true}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <InputField
                          name="formattedMiaClmDisposShareAmt"
                          value={selectedVo.formattedMiaClmDisposShareAmt}
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          label="Claim Dispos Share Amt"
                          disabled={true}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <InputField
                          name="formattedMiaClmPpsCapitalAmt"
                          value={selectedVo.formattedMiaClmPpsCapitalAmt}
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          label="Claim PPS Cap Amt"
                          disabled={true}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <InputField
                          name="formattedMiaClmDrgAmt"
                          value={selectedVo.formattedMiaClmDrgAmt}
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          label="Claim DRG Amt"
                          disabled={true}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <InputField
                          name="formattedMiaOldCapitalAmt"
                          value={selectedVo.formattedMiaOldCapitalAmt}
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          label="Old Cap Amt"
                          disabled={true}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <InputField
                          name="formattedMiaPpsCapFspDrgAmt"
                          value={selectedVo.formattedMiaPpsCapFspDrgAmt}
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          label="PPS Cap FSP DRG Amt"
                          disabled={true}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <InputField
                          name="formattedMiaPpsCapHspDrgAmt"
                          value={selectedVo.formattedMiaPpsCapHspDrgAmt}
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          label="PPS Cap HSP DRG Amt"
                          disabled={true}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <InputField
                          name="formattedMiaPpsCapDshDrgAmt"
                          value={selectedVo.formattedMiaPpsCapDshDrgAmt}
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          label="PPS Cap DSH DRG Amt"
                          disabled={true}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <InputField
                          name="formattedMiaPpsCapImeAmt"
                          value={selectedVo.formattedMiaPpsCapImeAmt}
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          label="PPS Cap IME Amt"
                          disabled={true}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <InputField
                          name="formattedMiaPpsOprHospDrgAmt"
                          value={selectedVo.formattedMiaPpsOprHospDrgAmt}
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          label="PPS Opr Hosp DRG Amt"
                          disabled={true}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <InputField
                          name="formattedMiaPpsOprFedDrgAmt"
                          value={selectedVo.formattedMiaPpsOprFedDrgAmt}
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          label="PPS Opr FED DRG Amt"
                          disabled={true}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <InputField
                          name="formattedMiaPpsCapExceptnAmt"
                          value={selectedVo.formattedMiaPpsCapExceptnAmt}
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          label="PPS Cap Excptn Amt"
                          disabled={true}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <InputField
                          name="formattedMiaClmPpsCapOutlAmt"
                          value={selectedVo.formattedMiaClmPpsCapOutlAmt}
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          label="Claim PPS Cap Outl Amt"
                          disabled={true}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <InputField
                          name="formattedMiaClmIndTeachgAmt"
                          value={selectedVo.formattedMiaClmIndTeachgAmt}
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          label="Claim Ind Teachg Amt"
                          disabled={true}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <InputField
                          name="formattedMiaNonPayProfCbAmt"
                          value={selectedVo.formattedMiaNonPayProfCbAmt}
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          label="Non Pay Prof CB Amt"
                          disabled={true}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <InputField
                          name="instMiaCoveredDays"
                          value={selectedVo.instMiaCoveredDays}
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          label="Covered Days"
                          disabled={!editable}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <InputField
                          name="instMiaLifePsychDayCnt"
                          value={selectedVo.instMiaLifePsychDayCnt}
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          label="Life Psych Days"
                          disabled={!editable}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <InputField
                          name="instMiaCostDayCnt"
                          value={selectedVo.instMiaCostDayCnt}
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          label="Cost Day Cntr"
                          disabled={!editable}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    </div>
                  </div>
                </React.Fragment>
              ) : null}
              <hr />
              <div class="panel-body">
                {selectedRow.encType === "I" ? (
                  <div>
                    <div className={classes.container}>
                      <InputField
                        name="instMiaClmpmtRemarkCd"
                        value={selectedVo.instMiaClmpmtRemarkCd}
                        maxLength={50}
                        onChange={this.props.handleChange(
                          "claimOthSubsList",
                          rowIndex
                        )}
                        label="Claim Pmnt Remark Code"
                        disabled={!editable}
                      />
                    </div>
                    <div className={classes.container} >
                      <div style = {{marginRight :"16px"}}>
                      <InputField
                        name="instMiaClmPmtRemarkCd1"
                        value={selectedVo.instMiaClmPmtRemarkCd1}
                        maxLength={50}
                        label="Claim Pmnt Rem Code 1/2"
                        onChange={this.props.handleChange(
                          "claimOthSubsList",
                          rowIndex
                        )}
                        disabled={!editable}
                      />
                      </div>
                      <div style ={{marginRight :"16px"}}> 
                      <InputField
                        name="instMiaClmPmtRemarkCd2"
                        value={selectedVo.instMiaClmPmtRemarkCd2}
                        maxLength={50}
                        onChange={this.props.handleChange(
                          "claimOthSubsList",
                          rowIndex
                        )}
                        disabled={!editable}
                      />
                      </div >
                      <div style ={{marginRight :"16px"}}>
                      <InputField
                        name="instMiaClmPmtRemarkCd3"
                        value={selectedVo.instMiaClmPmtRemarkCd3}
                        maxLength={50}
                        label="Claim Pmnt Rem Code 3/4"
                        onChange={this.props.handleChange(
                          "claimOthSubsList",
                          rowIndex
                        )}
                        disabled={!editable}
                      />
                      </div>
                      <div style ={{marginRight :"16px"}}>
                      <InputField
                        name="instMiaClmPmtRemarkCd4"
                        value={selectedVo.instMiaClmPmtRemarkCd4}
                        maxLength={50}
                        onChange={this.props.handleChange(
                          "claimOthSubsList",
                          rowIndex
                        )}
                        disabled={!editable}
                      />
                      </div>
                    </div>
                  </div>
                ) : null}
                <div className={classes.applicationSectionHeading}>
                  <span> Outpatient Adjudication Information</span>
                </div>
                <div style={{ marginLeft: "-16px" }}>
                  <div class="panel-body">
                    <div className={classes.container}>
                      <div>
                        <InputField
                          name="formattedMoaHcpcsPayableAmt"
                          value={selectedVo.formattedMoaHcpcsPayableAmt}
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          label="HCPCS Payable Amt"
                          disabled={true}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <InputField
                          name="formattedMoaEsrdPmtAmt"
                          value={selectedVo.formattedMoaEsrdPmtAmt}
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          label="ESRD Payment Amt"
                          disabled={true}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <InputField
                          name="formattedMoaNonpayProfCbAmt"
                          value={selectedVo.formattedMoaNonpayProfCbAmt}
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          label="Non Pay Prof CB Amt"
                          disabled={true}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <InputField
                          name="formattedMoaReimburseRate"
                          value={selectedVo.formattedMoaReimburseRate}
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          label="Reimburse Rate"
                          disabled={true}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <InputField
                          name="moaClmPmtRemarkCd1"
                          value={selectedVo.moaClmPmtRemarkCd1}
                          maxLength={50}
                          label="ClaimPaymentRemCd 1"
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          disabled={!editable}
                        />
                      </div>
                      <div className={classes.container} >
                        <div style ={{marginRight: "15px"}}>
                        <InputField
                          name="moaClmPmtRemarkCd2"
                          value={selectedVo.moaClmPmtRemarkCd2}
                          maxLength={50}
                         
                          label="ClaimPaymentRemCd 2/3"
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          disabled={!editable}
                        />
                        </div>
                        <div style ={{marginRight: "15px"}}>
                           <InputField
                          name="moaClmPmtRemarkCd3"
                          value={selectedVo.moaClmPmtRemarkCd3}
                          maxLength={50}
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          disabled={!editable}
                        />
                        </div>
                        <div style ={{marginRight: "15px"}}>
                        <InputField
                          name="moaClmPmtRemarkCd4"
                          value={selectedVo.moaClmPmtRemarkCd4}
                          maxLength={50}
                          label="ClaimPaymentRemCd 4/5"
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          disabled={!editable}
                        />
                        </div>

                        <div style ={{marginRight: "15px"}}>
                        <InputField
                          name="moaClmPmtRemarkCd5"
                          value={selectedVo.moaClmPmtRemarkCd5}
                          maxLength={50}
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          disabled={!editable}
                        />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className={classes.applicationSectionHeading}>
                  <span>Other Insurance</span>
                </div>
                <div className={classes.container}>
                  <div>
                    <InputField
                      name="otherClmFilingInd"
                      value={selectedVo.otherClmFilingInd}
                      maxLength={2}
                      onChange={this.props.handleChange(
                        "claimOthSubsList",
                        rowIndex
                      )}
                      label="Claim Filing"
                      disabled={!editable}
                    />
                    <div className={classes.validationMessage} />
                  </div>

                  {selectedRow.encType === "P" ||
                    selectedRow.encType === "E" ? (
                      <div>
                        <InputField
                          name="otherClminsuredType"
                          value={selectedVo.otherClminsuredType}
                          maxLength={2}
                          onChange={this.props.handleChange(
                            "claimOthSubsList",
                            rowIndex
                          )}
                          label="Insured Type"
                          disabled
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}

                  <div>
                    <InputField
                      name="othInsuredFirstName"
                      value={selectedVo.othInsuredFirstName}
                      onChange={this.props.handleChange(
                        "claimOthSubsList",
                        rowIndex
                      )}
                      label="Insured First Name"
                      disabled={true}
                    />
                    <div className={classes.validationMessage} />
                  </div>

                  <div>
                    <InputField
                      name="othInsuredMiddleName"
                      value={selectedVo.othInsuredMiddleName}
                      onChange={this.props.handleChange(
                        "claimOthSubsList",
                        rowIndex
                      )}
                      label="Insured Middle Name"
                      disabled={true}
                    />
                    <div className={classes.validationMessage} />
                  </div>

                  <div>
                    <InputField
                      name="othInsuredLastName"
                      value={selectedVo.othInsuredLastName}
                      onChange={this.props.handleChange(
                        "claimOthSubsList",
                        rowIndex
                      )}
                      label="Insured Last Name"
                      disabled={true}
                    />
                    <div className={classes.validationMessage} />
                  </div>

                  <div>
                    <InputField
                      name="otherInsuredGrpName"
                      value={selectedVo.otherInsuredGrpName}
                      onChange={this.props.handleChange(
                        "claimOthSubsList",
                        rowIndex
                      )}
                      label="Insured Grp Name"
                      disabled={true}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="othSubsMemberId"
                      value={selectedVo.othSubsMemberId}
                      onChange={this.props.handleChange(
                        "claimOthSubsList",
                        rowIndex
                      )}
                      label="Subs Member ID"
                      maxLength="50"
                      disabled={true}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="othSubsHicNbr"
                      value={selectedVo.othSubsHicNbr}
                      onChange={this.props.handleChange(
                        "claimOthSubsList",
                        rowIndex
                      )}
                      label="Subs HIC Nbr"
                      maxLength={12}
                      disabled
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="othSubsMbi"
                      value={selectedVo.othSubsMbi}
                      onChange={this.props.handleChange(
                        "claimOthSubsList",
                        rowIndex
                      )}
                      label="Subs Medicare ID"
                      disabled
                    />
                    <div className={classes.validationMessage}>
                      {this.props.validator.message(
                        "subsMedicareID",
                        selectedVo.othSubsMbi,
                        "alpha_num"
                      )}
                    </div>
                  </div>
                  <div>
                    <InputField
                      name="othSubsEntityType"
                      value={selectedVo.othSubsEntityType}
                      onChange={this.props.handleChange(
                        "claimOthSubsList",
                        rowIndex
                      )}
                      label="Subs Ent Type"
                      disabled
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="formattedOthSubsSsn"
                      value={selectedVo.formattedOthSubsSsn}
                      onChange={this.props.handleChange(
                        "claimOthSubsList",
                        rowIndex
                      )}
                      label="Subs SSN"
                      disabled
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div style = {{marginRight :"16px"}}>
                    <InputField
                      name="othSubsAddrLine1"
                      width="375px"
                      value={selectedVo.othSubsAddrLine1}
                      onChange={this.props.handleChange(
                        "claimOthSubsList",
                        rowIndex
                      )}
                      label="Subs Address1"
                      disabled
                    />
                    <div className={classes.validationMessage} />
                  </div>

                  <div>
                    <InputField
                      name="othSubsAddrLine2"
                      value={selectedVo.othSubsAddrLine2}
                      onChange={this.props.handleChange(
                        "claimOthSubsList",
                        rowIndex
                      )}
                      label="Subs Address2"
                      disabled
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="othSubsCity"
                      onChange={this.props.handleChange(
                        "claimOthSubsList",
                        rowIndex
                      )}
                      label="Subs City"
                      value={selectedVo.othSubsCity}
                      disabled
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <Select
                      components={components}
                      propertyName={dropdowns.stateList.filter(
                        (option) => option.value === selectedVo.othSubsState
                      )}
                      options={dropdowns.stateList}
                      label="Choose Process Status ..."
                      textFieldProps={{
                        id: "othSubsState",
                        label: "Subs State",
                        InputLabelProps: {
                          className: classes.label,
                          shrink: true,
                        },
                      }}
                      className={classes.textFieldSelect}
                      handleChange={this.props.handleSelect(
                        "othSubsState",
                        "claimOthSubsList",
                        rowIndex
                      )}
                      classes={classes}
                      isDisabled
                    />
                  </div>
                  <div>
                    <InputField
                      name="othSubsZip"
                      label="Subs Zip"
                      disabled
                      value={selectedVo.othSubsZip}
                      onChange={this.props.handleChange(
                        "claimOthSubsList",
                        rowIndex
                      )}
                    />
                    <div className={classes.validationMessage}>
                      {this.props.validator.message(
                        "zip",
                        selectedVo.otherSubsZip,
                        "numeric|min:0,num"
                      )}
                    </div>
                  </div>
                  <div>
                    <InputField
                      name="othSubsCountry"
                      value={selectedVo.othSubsCountry}
                      onChange={this.props.handleChange(
                        "claimOthSubsList",
                        rowIndex
                      )}
                      label="Subs Country Code"
                      maxLength={3}
                      disabled
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="othSubsCntrySubd"
                      value={selectedVo.othSubsCntrySubd}
                      onChange={this.props.handleChange(
                        "claimOthSubsList",
                        rowIndex
                      )}
                      label="Subs Subd Code"
                      maxLength={3}
                      disabled
                    />
                    <div className={classes.validationMessage} />
                  </div>
                </div>
              </div>
              <div class="panel-body">
                <div class="twin-margin">
                  <div class="twin-boxes">
                    <div class="form-panel">
                      <div className={classes.container}>
                        <div >
                          <InputField
                            name="othPayrOrgName"
                            label="Payer Org Name"
                            maxLength={60}
                            width="370px"
                            disabled={!editable}
                            value={selectedVo.othPayrOrgName}
                            onChange={this.props.handleChange(
                              "claimOthSubsList",
                              rowIndex
                            )}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div className={classes.container}>
                          <InputField
                            name="othPayrAddrLine1"
                            label="Payer Address 1"
                            maxLength={55}
                            width="370px"
                            disabled={!editable}
                            value={selectedVo.othPayrAddrLine1}
                            onChange={this.props.handleChange(
                              "claimOthSubsList",
                              rowIndex
                            )}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="othPayrAddrLine2"
                            maxLength={55}
                            label="Payer Address 2"
                            disabled={!editable}
                            value={selectedVo.othPayrAddrLine2}
                            onChange={this.props.handleChange(
                              "claimOthSubsList",
                              rowIndex
                            )}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="othPayrCity"
                            onChange={this.props.handleChange(
                              "claimOthSubsList",
                              rowIndex
                            )}
                            label="Payer City"
                            value={selectedVo.othPayrCity}
                            maxLength={30}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <Select
                            components={components}
                            propertyName={dropdowns.stateList.filter(
                              (option) => option.value === selectedVo.othPayrState
                            )}
                            options={dropdowns.stateList}
                            label="Choose Process Status ..."
                            textFieldProps={{
                              id: "othPayrState",
                              label: "Payer State",
                              InputLabelProps: {
                                className: classes.label,
                                shrink: true,
                              },
                            }}
                            className={classes.textFieldSelect}
                            handleChange={this.props.handleSelect(
                              "othPayrState",
                              "claimOthSubsList",
                              rowIndex
                            )}
                            classes={classes}
                            isDisabled={!editable}
                          />
                        </div>
                        <div>
                          <InputField
                            name="othPayrZip"
                            label="Payer Zip"
                            maxLength={10}
                            disabled={!editable}
                            onBlur={this.props.handleClmBlur(
                              "",
                              selectedVo.othPayrZip,
                              "othPayrZip",
                              "claimOthSubsList",
                              rowIndex)}
                            value={
                              selectedVo.othPayrZip
                                ? selectedVo.othPayrZip.replace(/[^0-9]/g, "")
                                : ""
                            }
                            onChange={this.props.handleChange(
                              "claimOthSubsList",
                              rowIndex
                            )}
                          />
                          {editable ? (
                            <Popup
                              style={{ height: "65%" }}
                              className={classes.mobileWidth}
                              modal
                              trigger={<span class="more-info" />}
                              position="right center"
                            >
                              {(close) => (
                                <div>
                                  <CityZipSearch
                                    headerLabel="SubsZip Search"
                                    zip5={selectedVo.othPayrZip}
                                    zip4={""}
                                    targetVo={"claimOthSubsList"}
                                    param={"othPayrZip"}
                                    index={rowIndex}
                                    searchType="Zip_SEARCH"
                                    close={close}
                                    setData={this.props.setZipData}
                                  />
                                </div>
                              )}
                            </Popup>
                          ) : null}
                          <div className={classes.validationMessage}>
                            {this.props.validator.message(
                              "Payer Zip",
                              selectedVo.othPayrZip,
                              "numeric|min:0,num"
                            )}
                          </div>
                        </div>
                        <div>
                          <InputField
                            name="othPayrCountry"
                            label="Payer Country Code"
                            disabled={!editable}
                            maxLength={3}
                            value={selectedVo.othPayrCountry}
                            onChange={this.props.handleChange(
                              "claimOthSubsList",
                              rowIndex
                            )}
                          />
                          <div className={classes.validationMessageSelect} />
                        </div>
                        <div>
                          <InputField
                            name="othPayrCntrySubdCd"
                            label="Payer Subd Code"
                            disabled={!editable}
                            maxLength={3}
                            value={
                              selectedVo.othPayrCntrySubdCd
                                ? selectedVo.othPayrCntrySubdCd.replace(
                                  /[^0-9]/g,
                                  ""
                                )
                                : ""
                            }
                            onChange={this.props.handleChange(
                              "claimOthSubsList",
                              rowIndex
                            )}
                          />
                          <div className={classes.validationMessageSelect} />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="twin-boxes">
                    <div class="form-panel">
                      <div className={classes.container}  style={{marginLeft:"52px"}}>
                        <div >
                          <InputField
                            name="othPayrPayerId"
                            label="Payer ID"
                            disabled={!editable}
                            value={selectedVo.othPayrPayerId}
                            onChange={this.props.handleChange(
                              "claimOthSubsList",
                              rowIndex
                            )}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="othPayrPlanId"
                            maxLength={80}
                            label="Payer Plan ID"
                            disabled={!editable}
                            value={selectedVo.othPayrPlanId}
                            onChange={this.props.handleChange(
                              "claimOthSubsList",
                              rowIndex
                            )}
                          />
                          <div className={classes.validationMessage} />
                        </div>

                        <div>
                          <InputField
                            name="othPayrSecId"
                            label="Payer Sec ID"
                            maxLength={50}
                            disabled={!editable}
                            value={selectedVo.othPayrSecId}
                            onChange={this.props.handleChange(
                              "claimOthSubsList",
                              rowIndex
                            )}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div />
                        <div>
                          <InputField
                            name="othPayrTaxId"
                            label="Payer Tax ID"
                            disabled={!editable}
                            value={selectedVo.othPayrTaxId}
                            onChange={this.props.handleChange(
                              "claimOthSubsList",
                              rowIndex
                            )}
                          />
                          <div className={classes.validationMessage}></div>
                        </div>
                        <div>
                          <InputField
                            name="othPayrNaic"
                            label="Payer NAIC"
                            disabled={!editable}
                            maxLength={50}
                            value={selectedVo.othPayrNaic}
                            onChange={this.props.handleChange(
                              "claimOthSubsList",
                              rowIndex
                            )}
                          />
                          <div className={classes.validationMessage}></div>
                        </div>
                        <div>
                          <InputField
                            name="othPayrReferralNbr"
                            label="Payer Referral Nbr"
                            disabled={!editable}
                            maxLength={50}
                            value={selectedVo.othPayrReferralNbr}
                            onChange={this.props.handleChange(
                              "claimOthSubsList",
                              rowIndex
                            )}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="othPayrPriorAuthNbr"
                            label="Payer Prior Auth Nbr"
                            disabled={!editable}
                            maxLength={50}
                            value={selectedVo.othPayrPriorAuthNbr}
                            onChange={this.props.handleChange(
                              "claimOthSubsList",
                              rowIndex
                            )}
                          />
                          <div className={classes.validationMessage}></div>
                        </div>
                        <div>
                          <InputField
                            name="othPayrClmCtrlNbr"
                            label="Payer Claim Cntrl Nbr"
                            maxLength={50}
                            disabled={!editable}
                            value={selectedVo.othPayrClmCtrlNbr}
                            onChange={this.props.handleChange(
                              "claimOthSubsList",
                              rowIndex
                            )}
                          />
                          <div className={classes.validationMessage}></div>
                        </div>
                        <div>
                          <InputField
                            name="othPayrClmadjInd"
                            label="Payer Claim Adj"
                            disabled={!editable}
                            maxLength={1}
                            value={selectedVo.othPayrClmadjInd}
                            onChange={this.props.handleChange(
                              "claimOthSubsList",
                              rowIndex
                            )}
                          />
                          <div className={classes.validationMessage}></div>
                        </div>
                        <div>
                          <InputField
                            name="othPayrLocNbr"
                            label="Payer Loc Nbr"
                            disabled={!editable}
                            maxLength={50}
                            value={selectedVo.othPayrLocNbr}
                            onChange={this.props.handleChange(
                              "claimOthSubsList",
                              rowIndex
                            )}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </ExpansionPanel>
        ) : null}
      </React.Fragment>
    );
  }
}

export default withStyles(Styles)(ClaimSubscriber);
