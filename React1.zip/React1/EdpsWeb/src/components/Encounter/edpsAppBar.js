import AppBar from '@material-ui/core/AppBar';
import { withStyles } from '@material-ui/core/styles';
import Tab from '@material-ui/core/Tab';
import Tabs from '@material-ui/core/Tabs';
import Typography from '@material-ui/core/Typography';
import PropTypes from 'prop-types';
import React from 'react';
import Claim from './claim';
import Provider from './provider';
import Subscriber from './subscriber';
import ErrorBoundary from '../Error/ErrorBoundary';

function TabContainer(props) {
  return (
    <Typography component="div" style={{ padding: 2 * 3 }}>
      {props.children}
    </Typography>
  );
}

TabContainer.propTypes = {
  children: PropTypes.node.isRequired,
};

const styles = theme => ({
  root: {
    flexGrow: 1,
    width: '100%',
    backgroundColor: theme.palette.background.paper,
  },
});

class EdpsAppBar extends React.Component {

  constructor(props) {
    super(props);
    this.handleTabChange = this.handleTabChange.bind(this)
  }

  handleTabChange = (event, value) => {
    this.props.updatedTab(value)
  };

  render() {
    const { classes, value } = this.props;
    let tabIndex = 0
    return (
      <div className={classes.root}>
        <AppBar position="static" color="default">
          <Tabs
            value={this.props.value}
            onChange={this.handleTabChange}
            variant="scrollable"
            scrollButtons="on"
            indicatorColor="primary"
            textColor="primary"
          >
             <Tab label="Subscriber" value="subscriber" />
             <Tab label="Claim" value="claim" />
             <Tab label="Provider" value="provider" />
          </Tabs>
        </AppBar>
        {(value === "subscriber" || value === tabIndex++) &&
          <TabContainer><ErrorBoundary><Subscriber
            selectedRow={this.props.selectedRow} /></ErrorBoundary>
          </TabContainer>
        }
        {(value === "claim" || value === tabIndex++) &&
          <TabContainer><ErrorBoundary><Claim
            selectedRow={this.props.selectedRow} /></ErrorBoundary>
          </TabContainer>
        }
         {(value === "provider" || value === tabIndex++) &&
          <TabContainer><ErrorBoundary><Provider
            selectedRow={this.props.selectedRow} /></ErrorBoundary>
          </TabContainer>
        }
      </div>
    );
  }
}

EdpsAppBar.propTypes = {
  classes: PropTypes.object.isRequired,
};



export default (withStyles(styles)(EdpsAppBar));