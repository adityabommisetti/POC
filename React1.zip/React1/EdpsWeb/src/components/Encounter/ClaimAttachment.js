import { withStyles } from "@material-ui/core/styles";
import isEmpty from "lodash/isEmpty";
import React, { Component } from "react";
import { connect } from "react-redux";
import Modal from "../../components/UI/Modal/Modal";
import { styles as Styles } from "../../assets/styles/DataTableStyle";
import { ClAIM_LI_ADJUD_ADJUS_UPDATE } from "../../constants/header/encounterDetailsHeader";
import { addClmLineAdj, deleteClmLineAdj, updateClmLineAdj } from "../../redux/actions/encounterDetailsAction";
import ClaimCodeTable from "../Home/ClaimCodeTable";



const styles = theme => ({
    ...Styles(theme),
});

class ClaimAttachment extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedRow: 0,
            showModal: false,
            message: "",
            disabled: true,
            index: "",
            AdjUpdateVO: {
                wtxClaimRefNbr: "",
                wtxClaimRevNbr: null,
                claimSeqNbr: null,
                claimType: "",
                claimLineSeqNbr: null,
                clmliAdjudSeqNbr: null,
                clmliAdjustGrpCd: "",
                clmliAdjustSeqNbr: null,
                clmliAdjustReasonCd: "",
                formattedClmAdjustAmt: null,
                clmliAdjustQty: null,
                encType: ""
            },
            AdjAddVO: {
                wtxClaimRefNbr: this.props.selectedRow.wtxClaimRefNbr,
                wtxClaimRevNbr: this.props.selectedRow.wtxClaimRevNbr,
                claimSeqNbr: this.props.selectedRow.claimSeqNbr,
                claimType: this.props.selectedRow.claimType,
                claimLineSeqNbr: this.props.claimLineSeqNbr,
                clmliAdjudSeqNbr: this.props.clmliAdjudSeqNbr,
                clmliAdjustGrpCd: "",
                clmliAdjustReasonCd: "",
                formattedClmAdjustAmt: "",
                clmliAdjustQty: "",
                encType: this.props.selectedRow.encType
            }
        };
    }

    componentWillReceiveProps(nextProps) {
        if (!isEmpty(nextProps.claimAdjData)) {
            this.setState(prevState => ({
                AdjAddVO: {
                    ...prevState.AdjAddVO,
                    "claimLineSeqNbr": nextProps.claimAdjData[nextProps.rowIndex].claimLineSeqNbr,
                    "clmliAdjudSeqNbr": nextProps.claimAdjData[nextProps.rowIndex].clmliAdjudSeqNbr
                },
                AdjUpdateVO: nextProps.claimAdjData[nextProps.rowIndex].adjustments
            }));
        }
    };

    handleEdit = async (list, index, e) => {
        e.preventDefault();
        if (index === this.state.index) {
            await this.save(list, index, e);
        }
        else {
            await this.update(index, e);
        }
    };

    handlechangeUpdate = (name, target) => e => {
        let value = e.target
            ? e.target.value.toUpperCase()
            : e.value.toUpperCase();
        let targetVo = target;
        if (targetVo === "AdjUpdateVO") {
            const AdjudicationList = [...this.state.AdjUpdateVO];
            AdjudicationList[this.state.index] = { ...AdjudicationList[this.state.index], [name]: value }
            this.setState({
                AdjUpdateVO: [...AdjudicationList],
                check: false
            });
        }
        else {
            this.setState(prevState => ({
                AdjAddVO: {
                    ...prevState.AdjAddVO,
                    [name]: value
                }
            }));
        }
    };

    handleDelete = async (list, index, e) => {
        e.preventDefault();
        if (index === this.state.index) {
            await this.cancel();
        }
        else {
            await this.delete(list, e);
        }
    };

    update = async (index, e) => {
        e.preventDefault();
        this.setState({
            disabled: false,
            index: index
        });
    }

    save = async (data, i, e) => {
        e.preventDefault();
        if (i === this.state.index) {
            const saveStatus = await this.props.updateClmLineAdj(data, this.props.rowIndex);
            if (saveStatus.status === "200" && !isEmpty(this.props.claimAdjData[this.props.rowIndex])) {
                this.setState({
                    AdjUpdateVO: [...this.props.claimAdjData[this.props.rowIndex].adjustments],
                    closePopup: true,
                    index: "",
                    message: saveStatus.message,
                    disabled: false,
                });
            }
            else {
                this.setState({
                    closePopup: true,
                    message: saveStatus.message
                });
            }
        }
    }

    cancel = () => {
        this.setState({
            AdjUpdateVO: [...this.props.claimAdjData[this.props.rowIndex].adjustments],
            disabled: true,
            index: -1
        });
    };

    delete = async (data, e) => {
        e.preventDefault();
        const deleteStatus = await this.props.deleteClmLineAdj(data, this.props.rowIndex);
        if (deleteStatus.status === "200" && !isEmpty(this.props.claimAdjData[this.props.rowIndex])) {
            this.setState({
                AdjUpdateVO: [...this.props.claimAdjData[this.props.rowIndex].adjustments],
                closePopup: true,
                message: deleteStatus.message,
                index: "",
                disabled: false
            });
        }
        else {
            this.setState({
                closePopup: true,
                message: deleteStatus.message
            });
        }
    }

    handleAdd = async (e) => {
        e.preventDefault();
        if ((this.state.AdjAddVO.clmliAdjustGrpCd !== "") &&
            (this.state.AdjAddVO.clmliAdjustReasonCd !== "") &&
            (this.state.AdjAddVO.formattedClmAdjustAmt !== "") &&
            (this.state.AdjAddVO.clmliAdjustQty)) {
            const status = await this.props.addClmLineAdj(this.state.AdjAddVO, this.props.rowIndex);
            if (status.status === "200" && !isEmpty(this.props.claimAdjData[this.props.rowIndex])) {
                this.setState(prevState => ({
                    AdjAddVO: {
                        ...prevState.AdjAddVO,
                        clmliAdjustGrpCd: "",
                        clmliAdjustReasonCd: "",
                        formattedClmAdjustAmt: "",
                        clmliAdjustQty: ""
                    },
                    AdjUpdateVO: [...this.props.claimAdjData[this.props.rowIndex].adjustments],
                    message: status.message,
                    closePopup: true,
                    index: ""
                }));
            }
            else {
                this.setState({
                    closePopup: true,
                    message: status.message
                });
            }
        }
    }

    modalClosed = () => {
        this.setState({ closePopup: false })
    };

    render() {
        const { classes } = this.props;
        const { disabled, index, message, closePopup, AdjUpdateVO, AdjAddVO } = this.state;
        return (
            <React.Fragment>
                <Modal
                    dialogTitle="Claim Line Attachment"
                    message={message}
                    show={closePopup}
                    modalClosed={this.modalClosed} />

                <div style={{ width: "150%", alignSelf: "stretch", marginInlineStart:"60px" }}>
                    <div className={classes.tableWrapper} style={{ width: "100%" }}>
                        <ClaimCodeTable
                            updateData={AdjUpdateVO}
                            addData={AdjAddVO}
                            header={ClAIM_LI_ADJUD_ADJUS_UPDATE}
                            editable={this.props.editable}
                            updateTargetVo="AdjUpdateVO"
                            addTargetVo="AdjAddVO"
                            tableName="Claim Line Adjudication Adjustment"
                            disabled={disabled}
                            index={index}
                            handlechangeUpdate={this.handlechangeUpdate}
                            handleEdit={this.handleEdit}
                            handleDelete={this.handleDelete}
                            handleAdd={this.handleAdd}
                        />
                    </div>
                </div>
            </React.Fragment>)
    }
}

const mapStateToProps = state => {
    return {
        claimAdjData: state.ClaimCodeReducer.claimVo.claimLineAdjudications
    };
};


const mapDispatchToProps = {
    addClmLineAdj,
    updateClmLineAdj,
    deleteClmLineAdj
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(withStyles(styles)(ClaimAttachment));