import Paper from "@material-ui/core/Paper";
import { withStyles } from "@material-ui/core/styles";
import Typography from "@material-ui/core/Typography";
import classNames from "classnames";
import isEmpty from "lodash/isEmpty";
import React from "react";
import { connect } from "react-redux";
import { Styles } from "../../assets/styles/Theme";
import Modal from "../../components/UI/Modal/Modal";
import * as ActionTypes from "../../constants/actionConstants/applActionValues";
import * as Type from "../../constants/ConfirmType";
import * as DateUtil from "../../utils/DatePicker";
import DataTable from "../Home/DataTable";
import ExpansionPanel from "../UI/ExpansionPanel";
import InputField from "../UI/InputField";
import { components, Select } from "../UI/Select";
import ConfirmBox from "../utils/PopUp";
import ClaimAdjudication from "./ClaimAdjudication";
import ClaimAppBar from "./ClaimAppBar";
import ClaimLine from "./ClaimLine";
import ClaimLineProv from "./ClaimLineProvider";
import ClaimNotes from "./ClaimNotes";
import ClaimProvider from "./ClaimProvider";
import ClaimResultIns from "./ClaimResultIns";
import ClaimResultProf from "./ClaimResultProf";
import ClaimSubscriber from "./ClaimSubscriber";
import ClaimSubscriberProvider from "./ClaimSubscriberProvider";
import EncButtonPanel from "./EncButtonPanel";
import CityZipSearch from "./CityZipSearch";
import Popup from "reactjs-popup";
import SimpleReactValidator from "simple-react-validator";
import { customValidations } from "../../utils/CustomValidations";
import { INITIAL_CLAIM_STATE } from "../../constants/claimInitialState";
import { fetchClaim, updateClaim, deleteClmProvider } from "../../redux/actions/encounterDetailsAction";
import { searchCityZip, resetZip } from "../../redux/actions/CityZipAction";
import {
  CLAIM_ADJUSTMENT_DETAILS,
  CLAIM_ATTACHMENT_DETAILS
} from "../../constants/header/encounterDetailsHeader";

const dateChk = {};
class Claims extends React.Component {
  constructor(props) {
    super(props);
    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format
      },
    });
    this.state = {
      claimVo: { ...INITIAL_CLAIM_STATE },
      currClaimRefNbr: "",
      editable: false,
      modified: false,
      closePopup: false,
      tabIndexValue: "condition",
      index: 0,
      validateStatus: false
    };
  };

  static getDerivedStateFromProps(nextProps, prevState) {
    if (!isEmpty(nextProps.claimVo)) {
      if (
        prevState.currWtxClaimRefNbr !== nextProps.selectedRow.wtxClaimRefNbr
      ) {
        return {
          claimVo: { ...nextProps.claimVo },
          currWtxClaimRefNbr: nextProps.claimVo.claimResult.wtxClaimRefNbr,
          selectedRow: nextProps.selectedRow,
          editable: false
        };
      }
    }
    return null;
  }

  // async componentWillReceiveProps(nextProps, prevState) {
  //     if (nextProps.claimVo && Object.keys(nextProps.claimVo).length !== 0) {
  //         this.setState(prevState => ({
  //           selectedRow: nextProps.selectedRow,
  //             claimVo: {
  //                 ...prevState.claimVo,
  //                 ...nextProps.claimVo
  //             }
  //         }));
  //     }
  // }

  setData = async (name, value, targetVo, index) => {
    const selectedIndex = index;
    if (targetVo === "claimResult") {
      await this.setState((prevState) => ({
        claimVo: {
          ...prevState.claimVo,
          [targetVo]: {
            ...prevState.claimVo[targetVo],
            [name]: value,
          },
        },
        modified: true,
      }));
    } else {
      await this.setState((prevState) => ({
        claimVo: {
          ...prevState.claimVo,
          [targetVo]: prevState.claimVo[targetVo].map((el, index) =>
            index === selectedIndex ? { ...el, [name]: value } : el
          ),
        },
        modified: true,
      }));
    }
  };

  handleChange = (targetVo, parentIndex) => (event) => {
    const selectedIndex = parentIndex;
    let name = event.target.name;
    let value = event.target
      ? event.target.value.toUpperCase()
      : event.value.toUpperCase();
    this.setData(name, value, targetVo, selectedIndex);
  };

  handleSelect = (feildname, targetVo, index) => (event) => {
    let name = feildname;
    let selectedIndex = index;
    let value = event.target
      ? event.target.value.toUpperCase()
      : event.value.toUpperCase();
    this.setData(name, value, targetVo, selectedIndex);
  };

  handleDates = (fieldId, targetVo, index) => {
    const selectedIndex = index;
    var self = this;
    DateUtil.getDatePicker(fieldId).on("change", (e) => {
      if (dateChk.name !== e.target.name || dateChk.value !== e.target.value) {
        self.setData(e.target.name, e.target.value, targetVo, selectedIndex);
      }
      dateChk.name = e.target.name;
      dateChk.value = e.target.value;
    });
  };
  handleNumber = (targetVo, parentIndex) => (event) => {
    const selectedIndex = parentIndex;
    let name = event.target.name;
    let value = event.target.value.replace(/[^0-9]/g, "");
    this.setData(name, value, targetVo, selectedIndex);
  };

  handleEdit = () => {
    this.setState({
      editable: true,
      closePopup: false,
    });
  };

  handleUpdate = async (e) => {
    e.preventDefault();
    console.log(this.validator)
    if (!this.validator.allValid()) {
      this.validator.showMessages();
      this.forceUpdate();
      this.setState({
        validateStatus: true
      })
    }
    else {
      this.setState({
        validateStatus: false,
      })
      let msg = this.state.claimVo.claimResult &&
        this.state.claimVo.claimResult.processStatus === "COR" ? Type.UPDATE : Type.ENCOUNTER;
      ConfirmBox(this.confirmUpdate, msg, this.props);
    }
  };

  confirmUpdate = async () => {
    const status = await this.props.updateClaim(this.state.claimVo);
    if (status === "success") {
      this.setState((prevState) => ({
        claimVo: {
          ...prevState.claimVo,
          ...this.props.claimVo,
        },
        message: ActionTypes.UPDATE_SUCCESS,
        editable: false,
        modified: false,
        closePopup: true,
      }));
    } else {
      this.setState({
        closePopup: true,
        message: status,
        editable: false,
        currWtxClaimRefNbr: "",
      });
    }
  };

  handleCancel = () => {
    this.setState((prevState) => ({
      claimVo: {
        ...prevState.claimVo,
        ...this.props.claimVo,
      },
      editable: false,
      modified: false,
      message: "",
      validateStatus: ""
    }));
  };

  setZipData = async (data, param, targetVo, index) => {
    const selectedIndex = index;
    if (targetVo === "claimResult" && param === "ambDropoffZip") {
      await this.setState({
        claimVo: {
          ...this.state.claimVo,
          [targetVo]: {
            ...this.state.claimVo[targetVo],
            ambDropoffCity: data.perCity,
            ambDropoffState: data.perState,
            ambDropoffCountry: data.countyCd,
            ambDropoffZip: data.perZip5,
          },
        },
        modified: true,
      })
    } else if (targetVo === "claimResult" && param === "ambPickupZip") {
      await this.setState((prevState) => ({
        claimVo: {
          ...prevState.claimVo,
          [targetVo]: {
            ...prevState.claimVo[targetVo],
            ambPickupCity: data.perCity,
            ambPickupState: data.perState,
            ambPickupCountry: data.countyCd,
            ambPickupZip: data.perZip5,
          },
        },
        modified: true,
      }));
    } else if (targetVo === "claimOthSubsList" && param === "othPayrZip") {
      await this.setState((prevState) => ({
        claimVo: {
          ...prevState.claimVo,
          [targetVo]: prevState.claimVo[targetVo].map((el, index) =>
            index === selectedIndex ? {
              ...el,
              othPayrCity: data.perCity,
              othPayrState: data.perState,
              othPayrCountry: data.countyCd,
              othPayrZip: data.perZip5,
            } : el
          ),
        },
        modified: true,
      }));
    } else if (targetVo === "claimLinesList" && param === "ambPickupZip") {
      await this.setState((prevState) => ({
        claimVo: {
          ...prevState.claimVo,
          [targetVo]: prevState.claimVo[targetVo].map((el, index) =>
            index === selectedIndex ? {
              ...el,
              ambPickupCity: data.perCity,
              ambPickupState: data.perState,
              ambPickupCountry: data.countyCd,
              ambPickupZip: data.perZip5,
            } : el
          ),
        },
        modified: true,
      }));
    } else if (targetVo === "claimLinesList" && param === "ambDropoffZip") {
      await this.setState((prevState) => ({
        claimVo: {
          ...prevState.claimVo,
          [targetVo]: prevState.claimVo[targetVo].map((el, index) =>
            index === selectedIndex ? {
              ...el,
              ambDropoffCity: data.perCity,
              ambDropoffState: data.perState,
              ambDropoffCountry: data.countyCd,
              ambDropoffZip: data.perZip5,
            } : el
          ),
        },
        modified: true,
      }));
    } else if (targetVo === "claimLineProviders" && param === "provZip") {
      await this.setState((prevState) => ({
        claimVo: {
          ...prevState.claimVo,
          [targetVo]: prevState.claimVo[targetVo].map((el, index) =>
            index === selectedIndex ? {
              ...el,
              provCity: data.perCity,
              provState: data.perState,
              provCountry: data.countyCd,
              provZip: data.perZip5,
            } : el
          ),
        },
        modified: true,
      }));
    }
  };

  handleClmBlur = (zip4, zip5, targetVo, param, index) => async (event) => {
    event.preventDefault();
    const payload = {
      zip4: zip4,
      zip5: zip5
    }
    await this.props.resetZip();
    await this.props.searchCityZip(payload);
    if (!isEmpty(this.props.zipData)) {
      const zipData = this.props.zipData[0];
      this.setZipData(zipData, targetVo, param, index);
    }
  };

  updatedTab = (tabname) => {
    this.setState({
      tabNameValue: tabname,
      tabIndexValue: tabname
    });
  };

  modalClosed = () => {
    this.setState({ closePopup: false });
  };

  deleteClmProvider = async (list) => {
    const payload = {
      mfId: list.mfId,
      wtxClaimRefNbr: list.wtxClaimRefNbr,
      wtxClaimRevNbr: list.wtxClaimRevNbr,
      claimSeqNbr: list.claimSeqNbr,
      claimType: list.claimType,
      provType: list.provType,
      encType: list.encType
    }
    const deleteStatus = await this.props.deleteClmProvider(payload);
    this.setState({
      claimVo: { ...this.props.claimVo },
      message: deleteStatus.message
    });
  };

  render() {
    const { classes, dropdowns, selectedRow } = this.props;
    const { claimVo, editable, message, closePopup, modified } = this.state;
    return (
      <React.Fragment>
        <Modal
          dialogTitle="CLAIM"
          message={message}
          show={closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Paper elevation={0} className={classes.card}>
          <form autoComplete="off">
            {selectedRow &&
              selectedRow.processStatus !== "ACC" &&
              selectedRow.processStatus !== "SUB" &&
              selectedRow.processStatus !== "PAC" &&
              selectedRow.processStatus !== "RES" &&
              selectedRow.processStatus !== "BAS" ?
              (<div style={{ textAlign: "right" }}><EncButtonPanel
                handleEdit={this.handleEdit}
                handleUpdate={this.handleUpdate}
                handleCancel={this.handleCancel}
                handleNumber={this.handleNumber}
                editable={!editable}
                modified={modified}
                selectedRow={selectedRow}
              /></div>) : null}
            {this.state.validateStatus ?
              <div class="alert alert-danger" id="displayMessage">
                <strong>Failed: &nbsp;</strong>
                {"Please check the fields with error."}
              </div> : null}
            <React.Fragment>
              <div>
                <div class="panel-body">
                  {selectedRow.encType === "P" ||
                    selectedRow.encType === "E" ? (
                      <div className={classes.encounterPanel}>
                        <ClaimResultProf
                          claimVo={claimVo}
                          handleChange={this.handleChange}
                          handleSelect={this.handleSelect}
                          handleDates={this.handleDates}
                          handleNumber={this.handleNumber}
                          validator={this.validator}
                          editable={editable}
                          dropdowns={dropdowns}
                        />
                      </div>
                    ) : (
                      <div className={classes.encounterPanel}>
                        <ClaimResultIns
                          claimVo={claimVo}
                          handleChange={this.handleChange}
                          handleSelect={this.handleSelect}
                          handleDates={this.handleDates}
                          handleNumber={this.handleNumber}
                          validator={this.validator}
                          editable={editable}
                          dropdowns={dropdowns}
                        />
                      </div>
                    )}
                  <div className={classes.container}>
                    <div>
                      <InputField
                        name="cmsIcn"
                        value={claimVo.claimResult.cmsIcn}
                        onChange={this.handleChange("claimResult")}
                        label="CMS ICN"
                        maxLength="20"
                        disabled={true}
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="payerClmCtrlNbr"
                        value={claimVo.claimResult.payerClmCtrlNbr}
                        onChange={this.handleChange("claimResult")}
                        label="Payer Claim Control Nbr"
                        maxLength="50"
                        disabled={!editable}
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="priorAuthNbr"
                        value={claimVo.claimResult.priorAuthNbr}
                        onChange={this.handleChange("claimResult")}
                        label="Prior Authorization Nbr"
                        maxLength="50"
                        disabled={!editable}
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="valueAddNtwkTraceNbr"
                        value={claimVo.claimResult.valueAddNtwkTraceNbr}
                        onChange={this.handleChange("claimResult")}
                        label="Value Add Network Trace Nbr"
                        disabled={!editable}
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="instPeerRevewOrgAprvNbr"
                          value={claimVo.claimResult.instPeerRevewOrgAprvNbr}
                          onChange={this.handleChange("claimResult")}
                          label="Peer Review Org Approval Nbr"
                          maxLength="50"
                          disabled={!editable}
                          selectedRow={selectedRow}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="carePlanOversightNbr"
                            value={claimVo.claimResult.carePlanOversightNbr}
                            onChange={this.handleChange("claimResult")}
                            label="Care Plan Overst Nbr"
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="mammogramCertNbr"
                            id="claimResult_mammogramCertNbr"
                            value={claimVo.claimResult.mammogramCertNbr}
                            onChange={this.handleChange("claimResult")}
                            label="Mammogram Cert Nbr"
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    <div>
                      <InputField
                        name="referralNbr"
                        value={claimVo.claimResult.referralNbr}
                        onChange={this.handleChange("claimResult")}
                        label="Referral Nbr"
                        maxLength="50"
                        disabled={!editable}
                      />
                      <div className={classes.validationMessage} />
                    </div>

                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="instInvestigDeviceExmptId"
                          maxLength="50"
                          value={claimVo.claimResult.instInvestigDeviceExmptId}
                          onChange={this.handleChange("claimResult")}
                          label="Investing Device Exempt ID"

                          disabled={!editable}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="investigDeviceExempId"
                            maxLength="50"
                            value={claimVo.claimResult.investigDeviceExempId}
                            onChange={this.handleChange("claimResult")}
                            label="Investing Device Exempt ID"

                            disabled={!editable}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    <div>
                      <InputField
                        name="medicalRecordNbr"
                        value={claimVo.claimResult.medicalRecordNbr}
                        onChange={this.handleChange("claimResult")}
                        label="Medical Record Nbr"
                        maxLength="50"
                        disabled={!editable}
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="instBillingNotes"
                          value={claimVo.claimResult.instBillingNotes}
                          onChange={this.handleChange("claimResult")}
                          label="Billing Notes"
                          disabled={!editable}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="demonstrationProjId"
                            value={claimVo.claimResult.demonstrationProjId}
                            onChange={this.handleChange("claimResult")}
                            label="Demo Project ID"
                            maxLength="50"
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="instDemonstrationProjectId"
                          value={claimVo.claimResult.instDemonstrationProjectId}
                          onChange={this.handleChange("claimResult")}
                          label="Demo Project ID"
                          maxLength="50"
                          disabled={!editable}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="cliaNbr"
                            value={claimVo.claimResult.cliaNbr}
                            onChange={this.handleChange("claimResult")}
                            label="CLIA Nbr"
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="claimNotes"
                            value={claimVo.claimResult.claimNotes}
                            onChange={this.handleChange("claimResult")}
                            label="Claim Notes"
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {(selectedRow.encType === "P" ||
                      selectedRow.encType === "E") && !editable ? (
                        <div>
                          <InputField
                            name="maStatus"
                            value={claimVo.claimResult.maStatus}
                            onChange={this.handleChange("claimResult")}
                            label="MAO004 Status"
                            disabled={true}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="formattedIllnessOccurDt"
                            value={claimVo.claimResult.formattedIllnessOccurDt}
                            onClick={this.handleDates(
                              "#formattedIllnessOccurDt",
                              "claimResult"
                            )}
                            onChange={this.handleChange("claimResult")}
                            label="Illness Occur Date"
                            maxLength={10}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage}>
                            {this.validator.message(
                              "illnessOccurDate",
                              claimVo.claimResult.formattedIllnessOccurDt,
                              "date_format"
                            )}
                          </div>
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="formattedInitialTreatmentDt"
                            value={
                              claimVo.claimResult.formattedInitialTreatmentDt
                            }
                            onChange={this.handleChange("claimResult")}
                            onClick={this.handleDates(
                              "#formattedInitialTreatmentDt",
                              "claimResult"
                            )}
                            label="Initial Treatment Date"
                            maxLength={10}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage}>
                            {this.validator.message(
                              "initialTreatmentDate",
                              claimVo.claimResult.formattedInitialTreatmentDt,
                              "date_format"
                            )}
                          </div>
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="formattedLastSeenDt"
                            value={claimVo.claimResult.formattedLastSeenDt}
                            onClick={this.handleDates(
                              "#formattedLastSeenDt",
                              "claimResult"
                            )}
                            onChange={this.handleChange("claimResult")}
                            label="Last Seen Date"
                            maxLength={10}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage}>
                            {this.validator.message(
                              "lastSeenDate",
                              claimVo.claimResult.formattedLastSeenDt,
                              "date_format"
                            )}
                          </div>
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="formattedAcuteManifestationDt"
                            value={
                              claimVo.claimResult.formattedAcuteManifestationDt
                            }
                            onClick={this.handleDates(
                              "#formattedAcuteManifestationDt",
                              "claimResult"
                            )}
                            onChange={this.handleChange("claimResult")}
                            label="Acute Manifest Date"
                            maxLength={10}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage}>
                            {this.validator.message(
                              "acuteManifestDate",
                              claimVo.claimResult.formattedAcuteManifestationDt,
                              "date_format"
                            )}
                          </div>
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="formattedLastMenstrualPerDt"
                            value={
                              claimVo.claimResult.formattedLastMenstrualPerDt
                            }
                            onClick={this.handleDates(
                              "#formattedLastMenstrualPerDt",
                              "claimResult"
                            )}
                            onChange={this.handleChange("claimResult")}
                            label="Last Menstr Per Date"
                            maxLength={10}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage}>
                            {this.validator.message(
                              "lastMenstrPerDate",
                              claimVo.claimResult.formattedLastMenstrualPerDt,
                              "date_format"
                            )}
                          </div>
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="formattedLastXrayDt"
                            value={claimVo.claimResult.formattedLastXrayDt}
                            onClick={this.handleDates(
                              "#formattedLastXrayDt",
                              "claimResult"
                            )}
                            onChange={this.handleChange("claimResult")}
                            label="Last Xray Date"
                            maxLength={10}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage}>
                            {this.validator.message(
                              "lastXrayDate",
                              claimVo.claimResult.formattedLastXrayDt,
                              "date_format"
                            )}
                          </div>
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="formattedDisabilityStartDt"
                            value={claimVo.claimResult.formattedDisabilityStartDt}
                            onClick={this.handleDates(
                              "#formattedDisabilityStartDt",
                              "claimResult"
                            )}
                            onChange={this.handleChange("claimResult")}
                            label="Disability Start Date"
                            maxLength={10}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage}>
                            {this.validator.message(
                              "disabilityStartDate",
                              claimVo.claimResult.formattedDisabilityStartDt,
                              "date_format"
                            )}
                          </div>
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="formattedDisabilityEndDt"
                            value={claimVo.claimResult.formattedDisabilityEndDt}
                            onClick={this.handleDates(
                              "#formattedDisabilityEndDt",
                              "claimResult"
                            )}
                            onChange={this.handleChange("claimResult")}
                            label="Disability End Date"
                            maxLength={10}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage}>
                            {this.validator.message(
                              "disabilityEndDt",
                              claimVo.claimResult.formattedDisabilityEndDt,
                              "date_format"
                            )}
                          </div>
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="formattedLastWorkedDt"
                            value={claimVo.claimResult.formattedLastWorkedDt}
                            onClick={this.handleDates(
                              "#formattedLastWorkedDt",
                              "claimResult"
                            )}
                            onChange={this.handleChange("claimResult")}
                            label="Last Worked Date"
                            maxLength={10}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage}>
                            {this.validator.message(
                              "lastWorkedDate",
                              claimVo.claimResult.formattedLastWorkedDt,
                              "date_format"
                            )}
                          </div>
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="formattedAuthReturnWorkDt"
                            value={claimVo.claimResult.formattedAuthReturnWorkDt}
                            onClick={this.handleDates(
                              "#formattedAuthReturnWorkDt",
                              "claimResult"
                            )}
                            onChange={this.handleChange("claimResult")}
                            label="Auth Return Work Date"
                            maxLength={10}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage}>
                            {this.validator.message(
                              "authReturnWorkDate",
                              claimVo.claimResult.formattedAuthReturnWorkDt,
                              "date_format"
                            )}
                          </div>
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="formattedAsumdCareStartDt"
                            value={claimVo.claimResult.formattedAsumdCareStartDt}
                            onClick={this.handleDates(
                              "#formattedAsumdCareStartDt",
                              "claimResult"
                            )}
                            onChange={this.handleChange("claimResult")}
                            label="Asumd Care Start Date"
                            maxLength={10}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage}>
                            {this.validator.message(
                              "asumdCareStartDt",
                              claimVo.claimResult.formattedAsumdCareStartDt,
                              "date_format"
                            )}
                          </div>
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="formattedAsumdCareEndDt"
                            value={claimVo.claimResult.formattedAsumdCareEndDt}
                            onClick={this.handleDates(
                              "#formattedAsumdCareEndDt",
                              "claimResult"
                            )}
                            onChange={this.handleChange("claimResult")}
                            label="Asumd Care End Date"
                            maxLength={10}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage}>
                            {this.validator.message(
                              "asumdCareEndDt",
                              claimVo.claimResult.formattedAsumdCareEndDt,
                              "date_format"
                            )}
                          </div>
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="formattedFirstVisitConsultDt"
                            value={
                              claimVo.claimResult.formattedFirstVisitConsultDt
                            }
                            onClick={this.handleDates(
                              "#formattedFirstVisitConsultDt",
                              "claimResult"
                            )}
                            onChange={this.handleChange("claimResult")}
                            label="First Visit Consult Date"
                            maxLength={10}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage}>
                            {this.validator.message(
                              "firstVisitConsultDate",
                              claimVo.claimResult.formattedFirstVisitConsultDt,
                              "date_format"
                            )}
                          </div>
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="formattedAccidentDt"
                            value={claimVo.claimResult.formattedAccidentDt}
                            onClick={this.handleDates(
                              "#formattedAccidentDt",
                              "claimResult"
                            )}
                            onChange={this.handleChange("claimResult")}
                            label="Accident Date"
                            maxLength={10}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage}>
                            {this.validator.message(
                              "accidentDate",
                              claimVo.claimResult.formattedAccidentDt,
                              "date_format"
                            )}
                          </div>
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="formattedHospAdmitDt"
                            value={claimVo.claimResult.formattedHospAdmitDt}
                            onClick={this.handleDates(
                              "#formattedHospAdmitDt",
                              "claimResult"
                            )}
                            onChange={this.handleChange("claimResult")}
                            label="Hosp Admit Date"
                            maxLength={10}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage}>
                            {this.validator.message(
                              "hospAdmitDate",
                              claimVo.claimResult.formattedHospAdmitDt,
                              "date_format"
                            )}
                          </div>
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="formattedHospDischargeDt"
                            value={claimVo.claimResult.formattedHospDischargeDt}
                            onClick={this.handleDates(
                              "#formattedHospDischargeDt",
                              "claimResult"
                            )}
                            onChange={this.handleChange("claimResult")}
                            label="Hosp Discharge Date"
                            maxLength={10}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage}>
                            {this.validator.message(
                              "hospDischargeDate",
                              claimVo.claimResult.formattedHospDischargeDt,
                              "date_format"
                            )}
                          </div>
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="formattedHearVisionDt"
                            value={claimVo.claimResult.formattedHearVisionDt}
                            onChange={this.handleChange("claimResult")}
                            onClick={this.handleDates(
                              "#formattedHearVisionDt",
                              "claimResult"
                            )}
                            label="Hear Vision Date"
                            maxLength={10}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage}>
                            {this.validator.message(
                              "hearVisionDate",
                              claimVo.claimResult.formattedHearVisionDt,
                              "date_format"
                            )}
                          </div>
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="patientCondCd"
                            value={claimVo.claimResult.patientCondCd}
                            maxLength={1}
                            onChange={this.handleChange("claimResult")}
                            label="Patient Condition Code"
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="patientCondDesc1"
                            value={claimVo.claimResult.patientCondDesc1}
                            onChange={this.handleChange("claimResult")}
                            label="Condition1"
                            disabled={true}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="patientCondDesc2"
                            value={claimVo.claimResult.patientCondDesc2}
                            onChange={this.handleChange("claimResult")}
                            label="Condition2"
                            disabled={true}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    <hr />

                    {selectedRow.encType === "I" && !editable ? (
                      <div>
                        <InputField
                          name="maStatus"
                          value={claimVo.claimResult.maStatus}
                          onChange={this.handleChange("claimResult")}
                          label="MAO004 Status"
                          disabled={true}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}
                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          onChange={this.handleChange("claimResult")}
                          label="Patient Visit Reason"
                          disabled={true}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}
                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="instPatVisitreasType1"
                          value={claimVo.claimResult.instPatVisitreasType1}
                          onChange={this.handleChange("claimResult")}
                          label="Type/Code1"
                          maxLength="3"
                          disabled={!editable}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}
                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="instPatVisitreasCd1"
                          value={claimVo.claimResult.instPatVisitreasCd1}
                          onChange={this.handleChange("claimResult")}
                          disabled={!editable}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}
                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="instPatVisitreasType2"
                          value={claimVo.claimResult.instPatVisitreasType2}
                          onChange={this.handleChange("claimResult")}
                          label="Type/Code2"
                          maxLength="3"
                          disabled={!editable}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}
                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="instPatVisitreasCd2"
                          value={claimVo.claimResult.instPatVisitreasCd2}
                          onChange={this.handleChange("claimResult")}
                          disabled={!editable}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}
                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="instPatVisitreasType3"
                          value={claimVo.claimResult.instPatVisitreasType3}
                          onChange={this.handleChange("claimResult")}
                          label="Type/Code3"
                          maxLength="3"
                          disabled={!editable}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}

                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="instPatVisitreasCd3"
                          value={claimVo.claimResult.instPatVisitreasCd3}
                          onChange={this.handleChange("claimResult")}
                          disabled={!editable}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}
                  </div>
                </div>

                <div className={classes.applicationSectionHeading}>
                  <span> Repricing</span>
                </div>
                <div class="panel-body">
                  <div className={classes.container}>
                    <div>
                      <InputField
                        name="reprcdClmRefNbr"
                        value={claimVo.claimResult.reprcdClmRefNbr}
                        onChange={this.handleChange("claimResult")}
                        label="Claim Ref Nbr"
                        disabled={true}
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "ClmRefNbr",
                          claimVo.claimResult.reprcdClmRefNbr,
                          "alpha_num"
                        )}
                      </div>
                    </div>
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="adjReprcdClmRefNbr"
                            value={claimVo.claimResult.adjReprcdClmRefNbr}
                            onChange={this.handleChange("claimResult")}
                            label="Adj Claim Ref Nbr"
                            maxLength={20}
                            disabled={true}
                          />
                          <div className={classes.validationMessage}>
                            {this.validator.message(
                              "adjReprcdClmRefNbr",
                              claimVo.claimResult.adjReprcdClmRefNbr,
                              "alpha_num"
                            )}
                          </div>
                        </div>
                      ) : null}
                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="adjReprcdClmRefNbr"
                          value={claimVo.claimResult.adjReprcdClmRefNbr}
                          onChange={this.handleChange("claimResult")}
                          label="Adj Claim Ref Nbr"
                          maxLength={20}
                          disabled={!editable}
                        />
                        <div className={classes.validationMessage}>
                          {this.validator.message(
                            "adjReprcdClmRefNbr",
                            claimVo.claimResult.adjReprcdClmRefNbr,
                            "alpha_num"
                          )}
                        </div>
                      </div>
                    ) : null}
                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="instRepricedApprvdDrgCd"
                          value={claimVo.claimResult.instRepricedApprvdDrgCd}
                          onChange={this.handleChange("claimResult")}
                          label="Approved DRG Code"
                          maxLength="30"
                          disabled={!editable}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}
                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="instRepricedApprvdRevCd"
                          value={claimVo.claimResult.instRepricedApprvdRevCd}
                          onChange={this.handleChange("claimResult")}
                          label="Approved Rev Code"
                          maxLength="30"
                          disabled={!editable}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="formattedRepricerReceivedDt"
                            value={claimVo.claimResult.formattedRepricerReceivedDt}
                            onClick={this.handleDates(
                              "#formattedRepricerReceivedDt",
                              "claimResult"
                            )}
                            onChange={this.handleChange("claimResult")}
                            label="Received Date"
                            maxLength={10}
                            disabled={true}
                          />
                          <div className={classes.validationMessage}>
                            {this.validator.message(
                              "receivedDate",
                              claimVo.claimResult.formattedRepricerReceivedDt,
                              "date_format"
                            )}
                          </div>
                        </div>
                      ) : null}
                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="formattedRepricerReceivedDt"
                          value={claimVo.claimResult.formattedRepricerReceivedDt}
                          onClick={this.handleDates(
                            "#formattedRepricerReceivedDt",
                            "claimResult"
                          )}
                          onChange={this.handleChange("claimResult")}
                          label="Received Date"
                          maxLength={10}
                          disabled={!editable}
                        />
                        <div className={classes.validationMessage}>
                          {this.validator.message(
                            "receivedDate",
                            claimVo.claimResult.formattedRepricerReceivedDt,
                            "date_format"
                          )}
                        </div>
                      </div>
                    ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="reprcdAprvAmbpatgrp"
                            value={claimVo.claimResult.reprcdAprvAmbpatgrp}
                            onChange={this.handleChange("claimResult")}
                            label="ApprvdAmbPatGrp"
                            disabled={true}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="reprcdPolComplianceCd"
                            value={claimVo.claimResult.reprcdPolComplianceCd}
                            onChange={this.handleChange("claimResult")}
                            label="Pol Compl"
                            disabled={true}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>

                          <InputField
                            name="reprcdOrgId"
                            id="claimResult_reprcdOrgId"
                            maxLength={50}
                            value={claimVo.claimResult.reprcdOrgId}
                            onChange={this.handleChange("claimResult")}
                            label="Organization ID"
                            disabled={true}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="reprcdOrgId"
                          id="claimResult_reprcdOrgId"
                          maxLength={50}
                          value={claimVo.claimResult.reprcdOrgId}
                          onChange={this.handleChange("claimResult")}
                          label="Organization ID"
                          disabled={!editable}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}
                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="instRepricedUom"
                          id="instRepricedUom"
                          value={claimVo.claimResult.instRepricedUom}
                          onChange={this.handleChange("claimResult")}
                          label="UOM"
                          disabled={!editable}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="reprcdExceptionCd"
                            id="claimResult_reprcdExceptionCd"
                            value={claimVo.claimResult.reprcdExceptionCd}
                            onChange={this.handleChange("claimResult")}
                            label="Exception Code"
                            maxLength="1"
                            disabled={true}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="reprcdExceptionCd"
                          id="claimResult_reprcdExceptionCd"
                          value={claimVo.claimResult.reprcdExceptionCd}
                          onChange={this.handleChange("claimResult")}
                          label="Exception Code"
                          maxLength="1"
                          disabled={!editable}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}
                  </div>
                  <div className={classes.container}>
                    <div>
                      <InputField
                        name="formattedReprcdAllowedAmt"
                        id="claimResult_reprcdAllowedAmt"
                        value={claimVo.claimResult.formattedReprcdAllowedAmt}
                        onChange={this.handleChange("claimResult")}
                        label="Allowed Amt"
                        disabled={true}
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="formattedReprcdSavingAmt"
                        value={claimVo.claimResult.formattedReprcdSavingAmt}
                        onChange={this.handleChange("claimResult")}
                        label="Saving Amt"
                        disabled={true}
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="formattedAprsvcUnitCnt"
                          value={claimVo.claimResult.formattedAprsvcUnitCnt}
                          onChange={this.handleChange("claimResult")}
                          label=" Apr Svc Unit Cnt "
                          disabled={true}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="reprcdRejectReasCd"
                            id="claimResult_reprcdRejectReasCd"
                            value={claimVo.claimResult.reprcdRejectReasCd}
                            onChange={this.handleChange("claimResult")}
                            label="Rej Reason Code"
                            maxLength="2"
                            disabled={true}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="reprcdRejectReasCd"
                          id="claimResult_reprcdRejectReasCd"
                          value={claimVo.claimResult.reprcdRejectReasCd}
                          onChange={this.handleChange("claimResult")}
                          label="Rej Reason Code"
                          maxLength="2"
                          disabled={!editable}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}
                    <div>
                      <InputField
                        name="formattedReprcdPerdiemAmt"
                        id="claimResult_reprcdPerdiemAmt"
                        value={claimVo.claimResult.formattedReprcdPerdiemAmt}
                        onChange={this.handleChange("claimResult")}
                        label="Per Diem Amt"
                        disabled={true}
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="formattedRepricedApprvdAmt"
                          value={claimVo.claimResult.formattedRepricedApprvdAmt}
                          onChange={this.handleChange("claimResult")}
                          label="Approved Amt"
                          disabled={true}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}
                    {selectedRow.encType === "I" ? (
                      <div>
                        <InputField
                          name="instRepricedPolCmpliantCd"
                          value={claimVo.claimResult.instRepricedPolCmpliantCd}
                          onChange={this.handleChange("claimResult")}
                          label="Pol Compl Code"
                          maxLength="1"
                          disabled={!editable}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                    ) : null}
                    {selectedRow.encType === "P" ||
                      selectedRow.encType === "E" ? (
                        <div>
                          <InputField
                            name="formattedReprcdAprvAmbpatgrpamt"
                            id="claimResult_reprcdAprvAmbpatgrpamt"
                            value={claimVo.claimResult.formattedReprcdAprvAmbpatgrpamt}
                            onChange={this.handleChange("claimResult")}
                            label="Approved Amb Pat Grp Amt"
                            disabled={true}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      ) : null}
                  </div>
                </div>
                {selectedRow.encType === "P" || selectedRow.encType === "E" ? (
                  <React.Fragment>
                    <div className={classes.applicationSectionHeading}>
                      <span> Ambulatory</span>
                    </div>
                    <div class="panel-body">
                      <div class="twin-margin">
                        <div class="twin-boxes">
                          <div class="form-panel">
                            <div className={classes.container}>
                              <div>
                                <InputField
                                  name="ambPickupAddrLine1"
                                  id="claimResult_ambPickupAddrLine1"
                                  onChange={this.handleChange("claimResult")}
                                  label="Pick Up Addr1"
                                  value={claimVo.claimResult.ambPickupAddrLine1}
                                  disabled={!editable}
                                />
                                <div className={classes.validationMessage} />
                              </div>
                              <div>
                                <InputField
                                  name="ambPickupAddrLine2"
                                  id="claimResult_ambPickupAddrLine2"
                                  onChange={this.handleChange("claimResult")}
                                  label="Pick Up Addr2"
                                  value={claimVo.claimResult.ambPickupAddrLine2}
                                  disabled={!editable}
                                />
                                <div className={classes.validationMessage} />
                              </div>
                              <div>
                                <InputField
                                  name="ambPickupCity"
                                  id="claimResult_ambPickupCity"
                                  onChange={this.handleChange("claimResult")}
                                  label="Pick Up City"
                                  value={claimVo.claimResult.ambPickupCity}
                                  disabled={!editable}
                                />
                                <div className={classes.validationMessage} />
                              </div>
                              <div>
                                <Select
                                  components={components}
                                  propertyName={dropdowns.stateList.filter(
                                    (option) =>
                                      option.value ===
                                      claimVo.claimResult.ambPickupState
                                  )}
                                  options={dropdowns.stateList}
                                  label="Choose PickUp State ..."
                                  textFieldProps={{
                                    id: "claimResult_ambPickupState",
                                    label: "Pick Up State",
                                    InputLabelProps: {
                                      className: classes.label,
                                      shrink: true,
                                    },
                                  }}
                                  className={classes.textFieldSelect}
                                  handleChange={this.handleSelect(
                                    "ambPickupState",
                                    "claimResult"
                                  )}
                                  classes={classes}
                                  isDisabled={!editable}
                                />
                              </div>
                              <div>

                                <InputField
                                  name="ambPickupZip"
                                  id="claimResult_ambPickupZip"
                                  label="Pick Up Zip"
                                  maxLength={10}
                                  onChange={this.handleNumber("claimResult")}
                                  value={claimVo.claimResult.ambPickupZip}
                                  onBlur={this.handleClmBlur(
                                    "",
                                    claimVo.claimResult.ambPickupZip,
                                    "ambPickupZip",
                                    "claimResult")}
                                  disabled={!editable}
                                />

                                {editable ? (

                                  <Popup
                                    style={{ height: "65%" }}
                                    className={classes.mobileWidth}
                                    modal
                                    trigger={<span class="more-info" />}
                                    position="right center"
                                  >
                                    {(close) => (

                                      <div>
                                        <CityZipSearch
                                          headerLabel="PickUp Zip Search"

                                          zip5={claimVo.claimResult.ambPickupZip}
                                          zip4={""}
                                          param={"ambPickupZip"}
                                          targetVo={"claimResult"}
                                          searchType="Zip_SEARCH"
                                          close={close}
                                          setData={this.setZipData}
                                        />
                                      </div>
                                    )}
                                  </Popup>
                                ) : null}

                                <div className={classes.validationMessage}>
                                  {this.validator.message(
                                    "pickUpZip",
                                    claimVo.claimResult.ambPickupZip,
                                    "numeric|min:0,num"
                                  )}
                                </div>
                              </div>

                              <div>
                                <InputField
                                  name="ambPickupCountry"
                                  id="claimResult_ambPickupCountry"
                                  onChange={this.handleChange("claimResult")}
                                  label="Country Code"
                                  maxLength={3}
                                  value={claimVo.claimResult.ambPickupCountry}
                                  disabled={!editable}
                                />
                                <div className={classes.validationMessage} />
                              </div>
                              <div>
                                <InputField
                                  name="ambPickupCntrySubd"
                                  id="claimResult_ambPickupCntrySubd"
                                  label="Subd Code"
                                  maxLength={3}
                                  onChange={this.handleChange("claimResult")}
                                  value={claimVo.claimResult.ambPickupCntrySubd}
                                  disabled={!editable}
                                />
                                <div className={classes.validationMessage} />
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="twin-boxes" >
                          <div className={classes.container} style={{marginLeft:"18px"}}>
                            <div>
                              <InputField
                                name="ambDropoffLoc"
                                id="claimResult_ambDropoffLoc"
                                label="Drop Off Loc"
                                width="370px"
                                onChange={this.handleChange("claimResult")}
                                value={claimVo.claimResult.ambDropoffLoc}
                                disabled={!editable}
                              />
                              <div className={classes.validationMessage} />
                            </div>                      
                                                    
                              <div>
                                <InputField
                                  name="ambDropoffAddrLine1"
                                  id="claimResult_ambDropoffAddrLine1"
                                  label="Drop Off Addr1"
                                  onChange={this.handleChange("claimResult")}
                                  value={claimVo.claimResult.ambDropoffAddrLine1}
                                  disabled={!editable}
                                />
                                <div className={classes.validationMessage} />
                              </div>
                              <div>
                                <InputField
                                  name="ambDropoffAddrLine2"
                                  id="claimResult_ambDropoffAddrLine2"
                                  label="Drop Off Addr2"
                                  onChange={this.handleChange("claimResult")}
                                  value={claimVo.claimResult.ambDropoffAddrLine2}
                                  disabled={!editable}
                                />
                                <div className={classes.validationMessage} />
                              </div>
                              <div>
                                <InputField
                                  name="ambDropoffCity"
                                  id="claimResult_ambDropoffCity"
                                  onChange={this.handleChange("claimResult")}
                                  label="Drop Off City"
                                  value={claimVo.claimResult.ambDropoffCity}
                                  disabled={!editable}
                                />
                                <div className={classes.validationMessage} />
                              </div>
                              <div>
                                <Select
                                  components={components}
                                  propertyName={dropdowns.stateList.filter(
                                    (option) =>
                                      option.value ===
                                      claimVo.claimResult.ambDropoffState
                                  )}
                                  options={dropdowns.stateList}
                                  label="Choose Drop Off State ..."
                                  textFieldProps={{
                                    id: "ambDropoffState",
                                    label: "Drop Off State",
                                    InputLabelProps: {
                                      className: classes.label,
                                      shrink: true,
                                    },
                                  }}
                                  className={classes.textFieldSelect}
                                  handleChange={this.handleSelect(
                                    "ambDropoffState",
                                    "claimResult"
                                  )}
                                  classes={classes}
                                  isDisabled={!editable}
                                />
                              </div>
                              <div>
                                <InputField
                                  name="ambDropoffZip"
                                  id="claimResult_ambDropoffZip"
                                  label="Drop Off Zip"
                                  maxLength={10}
                                  onChange={this.handleNumber("claimResult")}
                                  value={claimVo.claimResult.ambDropoffZip}
                                  disabled={!editable}
                                  onBlur={this.handleClmBlur(
                                    "",
                                    claimVo.claimResult.ambDropoffZip,
                                    "ambDropoffZip",
                                    "claimResult")}
                                  disabled={!editable}
                                />
                                {editable ? (
                                  <Popup
                                    style={{ height: "65%" }}
                                    className={classes.mobileWidth}
                                    modal
                                    trigger={<span class="more-info" />}
                                    position="right center"
                                  >
                                    {(close) => (
                                      <div>
                                        <CityZipSearch
                                          headerLabel="DropOff Zip Search"
                                          zip5={claimVo.claimResult.ambDropoffZip}
                                          zip4={""}
                                          param={"ambDropoffZip"}
                                          targetVo={"claimResult"}
                                          searchType="Zip_SEARCH"
                                          close={close}
                                          setData={this.setZipData}
                                        />
                                      </div>
                                    )}
                                  </Popup>
                                ) : null}
                                <div className={classes.validationMessage}>
                                  {this.validator.message(
                                    "dropOffZip",
                                    claimVo.claimResult.ambDropoffZip,
                                    "numeric|min:0,num"
                                  )}
                                </div>
                              </div>
                              <div>
                                <InputField
                                  name="ambDropoffCountry"
                                  id="claimResult_ambDropoffCountry"
                                  label="Country Code"
                                  maxLength={3}
                                  onChange={this.handleChange("claimResult")}
                                  value={claimVo.claimResult.ambDropoffCountry}
                                  disabled={!editable}
                                />
                                <div className={classes.validationMessage} />
                              </div>
                              <div>
                                <InputField
                                  name="ambDropoffCntrySubd"
                                  id="claimResult_ambDropoffCntrySubd"
                                  label="Subd Code"
                                  maxLength={3}
                                  onChange={this.handleChange("claimResult")}
                                  value={claimVo.claimResult.ambDropoffCntrySubd}
                                  disabled={!editable}
                                />
                                <div className={classes.validationMessage} />
                              </div>
                            </div>
                            </div>
                          </div>
                        
                    
                      <div className={classes.container}>
                        <div>
                          <InputField
                            name="ambPatWeight"
                            label="Patient Weight"
                            maxLength={10}
                            onChange={this.handleNumber("claimResult")}
                            value={claimVo.claimResult.ambPatWeight}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="ambCertCondInd"
                            label="Cert Cond Ind"
                            maxLength={1}
                            onChange={this.handleChange("claimResult")}
                            value={claimVo.claimResult.ambCertCondInd}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="ambTranspDistance"
                            onChange={this.handleNumber("claimResult")}
                            label="Transp Distance"
                            maxLength={15}
                            value={claimVo.claimResult.ambTranspDistance}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="ambTranspReasonCd"
                            onChange={this.handleChange("claimResult")}
                            label="Transp Reason"
                            maxLength={1}
                            value={claimVo.claimResult.ambTranspReasonCd}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      </div>
                      <div className={classes.container}>
                        <div>
                          <InputField
                            name="ambCertCondCd1"
                            id="claimResult_ambCertCondCd1"
                            label="Cert Cond Code1"
                            maxLength={2}
                            onChange={this.handleChange("claimResult")}
                            value={claimVo.claimResult.ambCertCondCd1}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="ambCertCondCd2"
                            id="claimResult_ambCertCondCd2"
                            label="Cert Cond Code2"
                            maxLength={2}
                            onChange={this.handleChange("claimResult")}
                            value={claimVo.claimResult.ambCertCondCd2}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="ambCertCondCd3"
                            id="claimResult_ambCertCondCd3"
                            label="Cert Cond Code3"
                            maxLength={2}
                            onChange={this.handleChange("claimResult")}
                            value={claimVo.claimResult.ambCertCondCd3}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="ambCertCondCd4"
                            id="claimResult_ambCertCondCd4"
                            onChange={this.handleChange("claimResult")}
                            label="Cert Cond Code4"
                            maxLength={2}
                            value={claimVo.claimResult.ambCertCondCd4}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="ambCertCondCd5"
                            id="claimResult_ambCertCondCd5"
                            label="Cert Cond Code5"
                            maxLength={2}
                            onChange={this.handleChange("claimResult")}
                            value={claimVo.claimResult.ambCertCondCd5}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      </div>
                      <div className={classes.container}>
                        <div>
                          <InputField
                            name="roundTripPurposeDesc"
                            label="Round Trip Purpose"
                            onChange={this.handleChange("claimResult")}
                            value={claimVo.claimResult.roundTripPurposeDesc}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="stretcherPurposeDesc"
                            label="Stretcher Purpose"
                            onChange={this.handleChange("claimResult")}
                            value={claimVo.claimResult.stretcherPurposeDesc}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                      </div>
                      <div className={classes.content}>
                        <React.Fragment>
                          <div className={classes.content}>
                            <div className={classes.applicationTableHeading}>
                              <span>Claim Adjustment</span>
                            </div>
                            {claimVo.adjustments ?
                              <DataTable
                                data={claimVo.adjustments}
                                header={CLAIM_ADJUSTMENT_DETAILS}
                                rowsPerPage={5}
                                sortableHeader={true}
                              />
                              : null}
                          </div>
                        </React.Fragment>
                        <React.Fragment>
                          <div className={classes.content}>
                            <div className={classes.applicationTableHeading}>
                              <span>Claim Attachment</span>
                            </div>
                            {claimVo.attachments ?
                              <DataTable
                                data={claimVo.attachments}
                                header={CLAIM_ATTACHMENT_DETAILS}
                                rowsPerPage={5}
                                sortableHeader={true}
                              />
                              : null
                            }
                          </div>
                        </React.Fragment>
                      </div>
                    </div>
                  </React.Fragment>
                ) : null}

              </div>
              <div id="claimCodes">
                <ExpansionPanel summary="Claim Codes">
                  <ClaimAppBar
                    indexVal={this.state.index}
                    editable={editable}
                    updatedTab={this.updatedTab}
                    value={this.state.tabIndexValue}
                    claimConditionList={claimVo.claimConditionsList}
                    selectedRowData={this.props.selectedRow}
                  />
                </ExpansionPanel>
              </div>
              <div id="claimProvider">
                <ExpansionPanel summary="Claim Provider">
                  <ClaimProvider
                    claimProvider={claimVo.claimProvidersList}
                    handleChange={this.handleChange}
                    handleSelect={this.handleSelect}
                    deleteClmProvider={this.deleteClmProvider}
                    validator={this.validator}
                    editable={editable}
                    dropdowns={dropdowns}
                  />
                </ExpansionPanel>
              </div>
              <div id="claimSubscriber">
                <ExpansionPanel summary="Claim - Other Subscriber">
                  <ClaimSubscriber
                    claimSubscriber={claimVo.claimOthSubsList}
                    selectedRow={selectedRow}
                    handleDates={this.handleDates}
                    handleChange={this.handleChange}
                    handleSelect={this.handleSelect}
                    handleClmBlur={this.handleClmBlur}
                    setZipData={this.setZipData}
                    validator={this.validator}
                    editable={editable}
                    dropdowns={dropdowns}
                  />
                </ExpansionPanel>
              </div>
              <div id="claimSubscriberProvider">
                <ExpansionPanel summary="Claim - Other Subscriber - Provider">
                  <ClaimSubscriberProvider
                    clmSubProvData={claimVo.claimOthSubsProvList}
                    selectedRow={selectedRow}
                    handleChange={this.handleChange}
                    validator={this.validator}
                    editable={editable}
                    dropdowns={dropdowns}
                  />
                </ExpansionPanel>
              </div>
              <div id="claimLine">
                <ExpansionPanel summary="Claim - Line">
                  <ClaimLine
                    claimLineData={claimVo.claimLinesList}
                    selectedRow={selectedRow}
                    handleDates={this.handleDates}
                    handleChange={this.handleChange}
                    handleSelect={this.handleSelect}
                    handleNumber={this.handleNumber}
                    handleClmBlur={this.handleClmBlur}
                    setZipData={this.setZipData}
                    validator={this.validator}
                    editable={editable}
                    dropdowns={dropdowns}
                  />
                </ExpansionPanel>
              </div>
              <div id="claimLineProvider">
                <ExpansionPanel summary="Claim - Line - Provider">
                  <ClaimLineProv
                    clmLineProv={claimVo.claimLineProviders}
                    selectedRow={selectedRow}
                    handleDates={this.handleDates}
                    handleChange={this.handleChange}
                    handleSelect={this.handleSelect}
                    handleClmBlur={this.handleClmBlur}
                    setZipData={this.setZipData}
                    validator={this.validator}
                    editable={editable}
                    dropdowns={dropdowns}
                  />
                </ExpansionPanel>
              </div>
              <div id="claimLineAdjudication">
                <ExpansionPanel summary="Claim - Line - Adjudication">
                  <ClaimAdjudication
                    claimAdjData={claimVo.claimLineAdjudications}
                    selectedRow={selectedRow}
                    handleDates={this.handleDates}
                    handleChange={this.handleChange}
                    validator={this.validator}
                    editable={editable}
                    dropdowns={dropdowns}
                  />
                </ExpansionPanel>
              </div>
              {selectedRow.encType === "I" ? (
                <div id="claimNotesList">
                  <ExpansionPanel summary="Claim-Notes">
                    <ClaimNotes claimNotesData={claimVo.claimNotesList} />
                  </ExpansionPanel>
                </div>
              ) : null}
            </React.Fragment>
          </form>
        </Paper>
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    dropdowns: state.dropdowns,
    claimVo: state.ClaimCodeReducer.claimVo,
    zipData: state.CityZipReducer.cityZipSearchData,
    adjDatatable: state.ClaimCodeReducer.claimVo.adjustments
      ? state.ClaimCodeReducer.claimVo.adjustments
      : [],
    attchDatatable: state.ClaimCodeReducer.claimVo.attachments
      ? state.ClaimCodeReducer.claimVo.attachments
      : [],
    isLoading: state.spinner.isLoading,
  };
};

const mapDispatchToProps = {
  fetchClaim,
  updateClaim,
  searchCityZip,
  resetZip,
  deleteClmProvider
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(Claims));
