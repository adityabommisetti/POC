import React, { Component } from "react";
import { withStyles } from "@material-ui/core/styles";
import DataTable from "../Home/DataTable";
import InputField from "../UI/InputField";
import { Styles } from "../../assets/styles/PopupTheme";
import { connect } from "react-redux";
import { CLAIM_VERSION } from "../../constants/header/encounterDetailsHeader";
import { fetchVersion } from "../../redux/actions/encounterDetailsAction";

class ClaimVersion extends Component {

    async componentDidMount() {
        const payload = { ...this.props.searchVo };
        payload.claimVersionRequired = true;
        payload.claimSeqNbr = "";
        await this.props.fetchVersion(payload);
    }

    selectRow = (index) => {
        const data = [...this.props.versionList];
        const selectedRow = data[index];
        this.props.claimVersion(selectedRow);
        this.props.close();
    }


    render() {
        const { classes, versionList, searchVo } = this.props;
        return (
            <React.Fragment>
                <div className={classes.applicationSectionHeading}>
                    <span>CLAIM VERSION</span>
                </div>
                <div className={classes.container}>
                    <div>
                        <InputField
                            name="logclmRefNbr"
                            value={searchVo.wtxClaimRefNbr}
                            label="Claim Ref Nbr"
                            disabled={true}
                        />
                        <div className={classes.validationMessage} />
                    </div>
                </div>
                <DataTable
                    data={versionList}
                    header={CLAIM_VERSION}
                    rowsPerPage={10}
                    sortable={true}
                    clicked={this.selectRow}
                />
                <button
                    class="btn btn-primary"
                    style={{ float: 'right' }}
                    onClick={this.props.close}
                >
                    Cancel
                </button>
            </React.Fragment>
        );
    }
}

const mapStateToProps = state => {
    return {
        versionList: state.encounterDetailsData.claimVersion
    };
};

const mapDispatchToProps = {
    fetchVersion
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(withStyles(Styles)(ClaimVersion));
