import Button from "@material-ui/core/Button";
import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormLabel from "@material-ui/core/FormLabel";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import { withStyles } from "@material-ui/core/styles";
import RadioButtonCheckedIcon from '@material-ui/icons/RadioButtonChecked';
import RadioButtonUncheckedIcon from '@material-ui/icons/RadioButtonUnchecked';
import isEmpty from "lodash/isEmpty";
import React, { Component } from "react";
import Datetime from "react-datetime";
import { connect } from "react-redux";
import { withRouter } from 'react-router';
import { compose } from 'redux';
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../../assets/styles/Theme";
import { customValidations } from "../../../utils/CustomValidations";
import * as DateUtil from "../../../utils/DatePicker";
import Card from "../../UI/Card";
import ExpansionPanel from "../../UI/ExpansionPanel";
import SearchBtnPanel from "../../UI/SearchBtnPanel";
import { components, Select } from "../../UI/Select";
import { rejectBoardGraph, rejectBoardGraphCriteria, errorCodeCriteria }
 from "../../../redux/actions/encounterDetailsAction";

const INITIAL_STATE = {
  submitterId: "",
  searchSummaryDateInd: "0",
  mfId: "",
  fromDateYrmo: ("01/").concat(new Date().getFullYear()),
  toDateYrmo: ("12/").concat(new Date().getFullYear()),
  claimType: "EN",
  reportType: "",
  requiredEncType: ""
};

class RejectBoardGraph extends Component {
  constructor(props) {
    super(props);
    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format_month_year,
        date_after_month_year: customValidations.date_after_month_year
      },
    });
    this.state = {
      searchVo: { ...INITIAL_STATE },
      instYrData: [],
      profYrData: [],
      dmeYrData: [],
      instMnthData: [],
      profMnthData: [],
      dmeMnthData: [],
      location: this.props.history.location.pathname,
      propList: ["Ccr", "Rejected"],
      colorList: 
      ['#EC407A',
        '#AB47BC',
        '#42A5F5',
        '#7E57C2',
        '#66BB6A',
        '#FFCA28',
        '#26A69A'
      ],
    };
  }

  setGraphData = (graphData, targetVo, label) => {
    const { propList, colorList } = this.state;
    var datasets = [];
    var labels = [];
    for (var i = 0; i < propList.length; i++) {
      var singleData = {};
      var data = [];
      singleData["type"] = "bar";
      singleData["backgroundColor"] = colorList[i];
      singleData["label"] = propList[i];
      for (var j = 0; j < graphData.length; j++) {
        data.push(graphData[j][propList[i].toLowerCase()])
      }
      singleData["data"] = data;
      datasets.push(singleData);
    }
    for (var j = 0; j < graphData.length; j++) {
      labels.push(graphData[j][label])
    }
    this.setState((prevState) => ({
      [targetVo]: {
        ...prevState[targetVo],
        ["datasets"]: datasets,
        ["labels"]: labels,
      },
    }));
  }

  async componentDidMount() {
    if (!isEmpty(this.props.criteria)) {
      await this.setState({
        searchVo: { ...this.props.criteria }
      })
    }
    else if ((!isEmpty(this.props.dropdowns)
      && this.state.searchVo.submitterId === "")
      && !isEmpty(this.props.rejectBoardYrData)) {
      await this.setState(prevState => ({
        searchVo: {
          ...prevState.searchVo,
          "submitterId": !isEmpty(this.props.dropdowns.optionsSubmitters) ?
            this.props.dropdowns.optionsSubmitters[0].value : "",
        }
      }));
    }
    await this.props.rejectBoardGraph (this.state.searchVo);
    this.setGraphData(this.props.rejectBoardYrData.instList, "instYrData", "yearValue");
    this.setGraphData(this.props.rejectBoardYrData.profList, "profYrData", "yearValue");
    this.setGraphData(this.props.rejectBoardYrData.dmeList, "dmeYrData", "yearValue");
  }


  async UNSAFE_componentWillReceiveProps(nextProps) {
    if ((!isEmpty(nextProps.dropdowns)
      && this.state.searchVo.submitterId === "")
      && isEmpty(nextProps.rejectBoardYrData)) {
      await this.setState(prevState => ({
        searchVo: {
          ...prevState.searchVo,
          "submitterId": !isEmpty(nextProps.dropdowns.optionsSubmitters) ?
            nextProps.dropdowns.optionsSubmitters[0].value : ""
        }
      }));
      await this.setState(prevState => ({
        searchVo: {
          ...prevState.searchVo,
          "reportType": ""
        }
      }));
      await this.props.rejectBoardGraph (this.state.searchVo, this.state.location);
      this.setGraphData(this.props.rejectBoardYrData.instList, "instYrData", "yearValue");
      this.setGraphData(this.props.rejectBoardYrData.profList, "profYrData", "yearValue");
      this.setGraphData(this.props.rejectBoardYrData.dmeList, "dmeYrData", "yearValue");
    }
  }

  monthPicker = (selectedDate, field) => {
    if (selectedDate._d) {
      var date = new Date(selectedDate._d),
        mnth = ("0" + (date.getMonth() + 1)).slice(-2),
        selectedDate = [mnth, date.getFullYear()].join("/");
    } else {
      selectedDate = selectedDate.replace(/[^0-9]/g, "").trim();
      selectedDate = selectedDate.replace(/^(\d{2})/, "$1/");
      selectedDate = selectedDate.replace(/(\d)\/(\d{4}).*/, "$1/$2");
    }
    this.setState({
      ...this.state,
      searchVo: { ...this.state.searchVo, [field]: selectedDate },
    });
  };

  handleSearchFieldChange = name => event => {
    let value = event.target
      ? event.target.value.toUpperCase()
      : event.value.toUpperCase();

    if (name === "fromDateYrmo" || name === "toDateYrmo" && value.length === 8) {
      // value = value.replace(/[^0-9]/g, "").trim();
      // value = value.replace(/^(\d{2})/, "$1/");
      // value = value.replace(/(\d)\/(\d{4}).*/, "$1/$2");
      // value = value.replace('(0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])[- /.](19|20)\d\d');
      value = value.replace('(0[1-9]|10|11|12)/20[0-9]{2}$');
    }
    this.setState(prevState => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value
      },
      collapseSearch: false
    }));
  };

  handleDates = fieldId => {
    var self = this;
    DateUtil.getMonthDatePicker(fieldId).on("change", e => {
      self.setDate(e.target.name, e.target.value);
    });
  };

  setDate = (name, value) => {
    this.setState(prevState => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value
      }
    }));
  };

  search = async () => {
    if (!this.validator.allValid()) {
      this.validator.showMessages();
      this.forceUpdate();
    }
    else {
      //await this.props.dashBoardCriteria(this.state.searchVo, this.state.location);
      await this.setState(prevState => ({
        searchVo: {
          ...prevState.searchVo,
          "reportType": ""
        }
      }));
      await this.props.rejectBoardGraphCriteria(this.state.searchVo);
      await this.props.rejectBoardGraph (this.state.searchVo);
      this.setGraphData(this.props.rejectBoardYrData.instList, "instYrData", "yearValue");
      this.setGraphData(this.props.rejectBoardYrData.profList, "profYrData", "yearValue");
      this.setGraphData(this.props.rejectBoardYrData.dmeList, "dmeYrData", "yearValue");
    }
  };

  reset = async () => {
    INITIAL_STATE.submitterId = !isEmpty(this.props.dropdowns.optionsSubmitters) ?
      this.props.dropdowns.optionsSubmitters[0].value : ""
    await this.setState({
      searchVo: {
        ...INITIAL_STATE,
        claimType:
          (this.props.parentTab === "edpsManagement" ||
            this.props.parentTab === "rejectAnalysis")
            ? "EN" : "CR"
      }
    })
    //this.props.dashBoardCriteria(this.state.searchVo, this.state.location);
  };

  onYearSelect = async (year, status) => {
    // let year = "";
    // if (item[0] !== undefined) {
    //   if (label === "PROFESSIONAL") {
    //     year = this.props.rejectBoardYrData.profList[item[0]._index].yearValue
    //   } else if (label === "INSTITUTIONAL") {
    //     year = this.props.rejectBoardYrData.instList[item[0]._index].yearValue
    //   } else {
    //     year = this.props.rejectBoardYrData.dmeList[item[0]._index].yearValue
    //   }
    // }
    await this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        reportType: year
      },
    }));
    await this.props.rejectBoardGraph (this.state.searchVo);
    this.setGraphData(this.props.rejectBoardMnthData.instList, "instMnthData", "monthName");
    this.setGraphData(this.props.rejectBoardMnthData.profList, "profMnthData", "monthName");
    this.setGraphData(this.props.rejectBoardMnthData.dmeList, "dmeMnthData", "monthName");
  };

  getLstDayOfMonFnc = (date) => {
    return new Date(date.getFullYear(), date.getMonth(), 0).getDate()
  };

  onMonthSelect = (month, source, label) => {
    const yearNum = this.state.searchVo.reportType;
    let monthNum = "";
    let encType = "";
    for (let i = 0; i < this.props.dropdowns.monthsList.length; i++) {
      if (this.props.dropdowns.monthsList[i].label === month) {
        monthNum = this.props.dropdowns.monthsList[i].value
      }
    }
    if (label === "PROFESSIONAL") {
      encType = "P"
    } else if (label === "INSTITUTIONAL") {
      encType = "I"
    } else {
      encType = "E"
    }
    let payload = { ...this.state.searchVo };
    payload.fromDateYrmo = monthNum + "/"+ yearNum;
    payload.toDateYrmo = monthNum + "/"+ yearNum;
    payload.encType = encType;
    payload.errorSource = (source === "Rejected") ? "CMS": "CCR";
    payload.graphRoute = true;
    console.log(payload);
    if (payload && payload.claimType === "EN") {
      this.props.history.push({
        pathname: '/reject',
        errorPayload: payload
      })
    } else {
      this.props.history.push({
        pathname: '/chartReject',
        errorPayload: payload
      })
    }
  };

  displayYear = () => {
    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        reportType: ""
      },
    }));
  };

  render() {
    const { classes, dropdowns } = this.props;
    const { searchVo, collapseSearch } = this.state;
    return (
      <React.Fragment>
        {!isEmpty(dropdowns) ?
          <ExpansionPanel
            summary="Search"
            defaultCollapsed={collapseSearch}
          >
            <div className={classes.container} id="SearchPanel">
              <div>
                <Select
                  components={components}
                  propertyName={dropdowns.optionsSubmitters.filter(
                    option =>
                      option.value === searchVo.submitterId
                  )}
                  defaultValue={dropdowns.optionsSubmitters[0]}
                  options={dropdowns.optionsSubmitters}
                  label="Choose Submitter ID ..."
                  textFieldProps={{
                    id: "submitterId",
                    label: "Submitter ID",
                    InputLabelProps: {
                      className: classes.label,
                      shrink: true
                    }
                  }}
                  className={classes.textFieldSearch}
                  handleChange={this.handleSearchFieldChange("submitterId")}
                  classes={classes}
                />
              </div>
              <div style={{ marginRight: "-40px" }}>
                <FormControl
                  component="fieldset"
                  className={classes.formControl}
                >
                  <FormLabel component="legend" className={classes.legend}></FormLabel>
                  <RadioGroup
                    name="searchSummaryDateInd"
                    className={classes.group}
                    value={searchVo.searchSummaryDateInd}
                    onChange={this.handleSearchFieldChange("searchSummaryDateInd")}
                  >
                    <FormControlLabel value="0" control={<Radio color="primary"
                      icon={<RadioButtonUncheckedIcon fontSize="small" />}
                      checkedIcon={<RadioButtonCheckedIcon fontSize="small" />}
                    />} label="Submission Date" />
                    <FormControlLabel value="1" control={<Radio color="primary"
                      icon={<RadioButtonUncheckedIcon fontSize="small" />}
                      checkedIcon={<RadioButtonCheckedIcon fontSize="small" />}
                    />} label="Service Date" />
                  </RadioGroup>
                </FormControl>
              </div>
              <div>
                <label>From</label>
                <Datetime
                  onChange={(moment) => this.monthPicker(moment, "fromDateYrmo")}
                  value={searchVo.fromDateYrmo}
                  dateFormat="MM/YYYY"
                  closeOnSelect="true"
                  inputProps={{
                    placeholder: "MM/YYYY",
                    className: "monthPicker",
                    maxLength: 7,
                  }}
                  timeFormat={false}
                />
                <div className={classes.validationMessage}>
                  {this.validator.message(
                    "FromDate",
                    searchVo.fromDateYrmo,
                    "required|date_format"
                  )}
                </div>
              </div>
              <div>
                <label>To</label>
                <Datetime
                  onChange={(moment) => this.monthPicker(moment, "toDateYrmo")}
                  value={searchVo.toDateYrmo}
                  dateFormat="MM/YYYY"
                  closeOnSelect="true"
                  inputProps={{
                    placeholder: "MM/YYYY",
                    className: "monthPicker",
                    maxLength: 7,
                  }}
                  timeFormat={false}
                />
                <div className={classes.validationMessage}>
                  {this.validator.message(
                    "ToDate",
                    searchVo.toDateYrmo,
                    [
                      "required",
                      "date_format",
                      { date_after_month_year: searchVo.fromDateYrmo },
                    ]
                  )}
                </div>
              </div>
              <div>
                <Select
                  components={components}
                  propertyName={dropdowns.dashboardEncTypeList.filter(
                    option =>
                      option.value === searchVo.claimType
                  )}
                  options={dropdowns.dashboardEncTypeList}
                  label="Choose ClaimType ID ..."
                  textFieldProps={{
                    id: "claimType",
                    label: "Encounter Type",
                    InputLabelProps: {
                      className: classes.label,
                      shrink: true
                    }
                  }}
                  className={classes.textFieldSearch}
                  handleChange={this.handleSearchFieldChange("claimType")}
                  classes={classes}
                />
              </div>
              {/* <div>
                <InputField
                  name="fromDateYrmo"
                  placeholder="MM/YYYY"
                  label="From"
                  value={searchVo.fromDateYrmo}
                  onClick={this.handleDates("#fromDateYrmo")}
                  maxLength={7}
                  onChange={this.handleSearchFieldChange("fromDateYrmo")}
                  required
                />

                <div className={classes.validationMessage} />
              </div> */}
              {/* <div>
                <InputField
                  name="toDateYrmo"
                  placeholder="MM/YYYY"
                  label="To"
                  value={searchVo.toDateYrmo}
                  onClick={this.handleDates("#toDateYrmo")}
                  maxLength={7}
                  onChange={this.handleSearchFieldChange("toDateYrmo")}
                  required
                />
                <div className={classes.validationMessage} />
              </div> */}
              <div>
                <SearchBtnPanel
                  search={this.search}
                  reset={this.reset}
                />
              </div>
            </div>
          </ExpansionPanel> : null}
        <ExpansionPanel summary="Encounter Analytics">
          {searchVo.reportType === "" ?
            <React.Fragment>
              <Card data={this.state.instYrData} label="INSTITUTIONAL" onChartSelect={this.onYearSelect} />
              <Card data={this.state.profYrData} label="PROFESSIONAL" onChartSelect={this.onYearSelect} />
              <Card data={this.state.dmeYrData} label="DME" onChartSelect={this.onYearSelect} />
            </React.Fragment> :
            <React.Fragment>
              <div className={classes.applicationSectionHeading}>
                <span>{searchVo.reportType}</span>
              </div>
              <div style={{ "float": "right" }}>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={this.displayYear}
                  className={classes.button}
                  id="cancelButton"
                >
                  Year Data
              </Button>
              </div>
              <div style={{ "marginTop": "90px" }}>
                <Card data={this.state.instMnthData} label="INSTITUTIONAL" onChartSelect={this.onMonthSelect} />
                <Card data={this.state.profMnthData} label="PROFESSIONAL" onChartSelect={this.onMonthSelect} />
                <Card data={this.state.dmeMnthData} label="DME" onChartSelect={this.onMonthSelect} />
              </div>
            </React.Fragment>
          }
        </ExpansionPanel>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  return {
    rejectBoardYrData: state.encounterDetailsData.rejectBoardYrData,
    rejectBoardMnthData: state.encounterDetailsData.rejectBoardMnthData,
    criteria: state.encounterDetailsData.rejectBoardGraphCriteria,
    isLoading: state.spinner.isLoading,
    dropdowns: state.dropdowns,
  };
};

const mapDispatchToProps = {
  rejectBoardGraph,
  errorCodeCriteria,
  rejectBoardGraphCriteria
};

export default compose(
  withRouter,
  withStyles(Styles),
  connect(mapStateToProps, mapDispatchToProps)
)(RejectBoardGraph)
