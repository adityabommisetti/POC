import Paper from "@material-ui/core/Paper";
import { withStyles } from "@material-ui/core/styles";
import * as DateUtil from "../../utils/DatePicker";
import isEmpty from "lodash/isEmpty";
import React from "react";
import { connect } from "react-redux";
import { Styles } from "../../assets/styles/Theme";
import Modal from "../../components/UI/Modal/Modal";
import * as ActionTypes from "../../constants/actionConstants/applActionValues";
import * as Type from "../../constants/ConfirmType";
import Popup from "reactjs-popup";
import {
  subscriberDetails,
  subscriberUpdate
} from "../../redux/actions/encounterDetailsAction";
import {
  searchCityZip,
  resetZip
} from "../../redux/actions/CityZipAction";
import InputField from "../UI/InputField";
import { components, Select } from "../UI/Select";
import ConfirmBox from "../utils/PopUp";
import EncButtonPanel from "./EncButtonPanel";
import SimpleReactValidator from "simple-react-validator";
import { customValidations } from "../../utils/CustomValidations";
import CityZipSearch from "./CityZipSearch";

const dateChk = {};
class Subscriber extends React.Component {
  constructor(props) {
    super(props);
    this.validator = new SimpleReactValidator({
      validators: {
        ValidSSN: customValidations.ValidSSN,
        date_format: customValidations.date_format
      },
    });
    this.state = {
      subscriberVo: {
        mfId: "",
        intrchgSndrId: "",
        prodTestInd: "",
        intrchgCtrlNbr: "",
        txnSetCtrlNbr: "",
        billPrvHrchyId: "",
        billPrvAffilTaxId: "",
        subsHrchyId: "",
        subsHicNbr: "",
        mbi: "",
        subsSeqNbr: 1,
        overrideInd: null,
        subsPayerSeqCd: "",
        subsRelationCd: "",
        subsGrpOrPolNbr: "",
        subsPlanName: "",
        subsInsuranceTypeCd: "",
        subsFilingIndCd: "",
        subsPatDod: "",
        subsPatUom: "",
        subsPatWeight: 0,
        subsPatPregnantInd: "",
        subsEntityType: "",
        subsLastName: "",
        subsFirstName: "",
        subsMiddleName: "",
        subsNameSuffix: "",
        subsMemberId: "",
        subsAddrLine1: "",
        subsAddrLine2: "",
        subsCity: "",
        subsState: "",
        subsZip: "",
        subsCountry: "",
        subsCntrySubdCd: "",
        subsDob: "",
        subsSex: "",
        subsSsn: "",
        propCasltyClmNbr: "",
        propCasltySubsName: "",
        propCasltySubsPhone: "",
        propCasltySubsPhnExt: "",
        payerName: "",
        payerId: "",
        payerPlanId: "",
        payerAddrLine1: "",
        payerAddrLine2: "",
        payerCity: "",
        payerState: "",
        payerZip: "",
        payerCountry: "",
        payerCntrySubdCd: "",
        payerTaxId: "",
        payerLocNbr: "",
        payerNaicCd: "",
        billPrvCommNbr: "",
        billPrvLocNbr: "",
        lastUpdtTime: null,
        lastUpdtUserid: null,
        payerSecId: "",
        wtxClaimRevNbr: 0,
        claimSeqNbr: 1,
        claimType: "",
        wtxClaimRefNbr: "",
        encType: "P",
        subsGrpName: "",
        formattedSubsSsn: "",
        formattedSubsDob: "",
        insTypeCode: "",
        patientPregn: ""
      },
      currWtxClaimRefNbr: "",
      editable: false,
      closePopup: false,
      modified: false,
      validateStatus: false
    };
  };

  // async componentDidMount() {
  //     this.setState(prevState => ({
  //         subscriberVo: {
  //             ...prevState.subscriberVo,
  //             ...this.props.SubScribeDataList
  //         },
  //     }));
  // }

  // async componentWillReceiveProps(nextProps, prevState) {
  //     if (nextProps.SubScribeDataList && Object.keys(nextProps.SubScribeDataList).length !== 0) {
  //         this.setState(prevState => ({
  //             subscriberVo: {
  //                 ...prevState.subscriberVo,
  //                 ...nextProps.SubScribeDataList
  //             },
  //         }));
  //     }
  // }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (!isEmpty(nextProps.SubScribeDataList)) {
      if (
        prevState.currWtxClaimRefNbr !==
        nextProps.SubScribeDataList.wtxClaimRefNbr
      ) {
        return {
          subscriberVo: { ...nextProps.SubScribeDataList },
          currWtxClaimRefNbr: nextProps.SubScribeDataList.wtxClaimRefNbr,
          editable: false,
        };
      }
    }
    return null;
  }

  handleChange = (name) => (event) => {
    let value = event.target
      ? event.target.value.toUpperCase()
      : event.value.toUpperCase();

    if (name === "subsSsn") {
      value = value.replace(/[^0-9]/g, "");
    }

    this.setState((prevState) => ({
      subscriberVo: {
        ...prevState.subscriberVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleDates = (fieldId) => {
    var self = this;
    DateUtil.getDatePicker(fieldId).on("change", (e) => {
      if (dateChk.name !== e.target.name || dateChk.value !== e.target.value) {
        self.setDate(e.target.name, e.target.value);
      }
      dateChk.name = e.target.name;
      dateChk.value = e.target.value;
    });
  };

  setDate = async (name, value) => {
    await this.setState((prevState) => ({
      subscriberVo: {
        ...prevState.subscriberVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleEdit = () => {
    this.setState({
      editable: true,
      closePopup: false,
    });
  };

  handleUpdate = async () => {
    console.log(this.validator)
    const { subscriberVo } = this.state;
    if (subscriberVo.subsFirstName === "") {
      alert("First Name cannot be blank.");
    }
    else if (subscriberVo.subsLastName === "") {
      alert("Last Name cannot be blank.");
    }
    else if (subscriberVo.subsAddrLine1 === "") {
      alert("Address Line 1 cannot be blank.");
    }
    else if (subscriberVo.subsCity === "") {
      alert("City cannot be blank.");
    }
    // else if ((subscriberVo.subsZip &&
    //   subscriberVo.subsZip.length < 5) ||
    //   !/^[0-9]+$/.test(subscriberVo.subsZip)
    // ) {
    //   alert("Invalid Zip Format (Do not include a dash)");
    // }
    else if (!this.validator.allValid()) {
      this.validator.showMessages();
      this.forceUpdate();
      this.setState({
        validateStatus: true
      })
    }
    else {
      this.setState({
        validateStatus: false
      })
      let msg = Type.ENCOUNTER;
      if (this.props.selectedRow.processStatus === "COR") {
        msg = Type.UPDATE;
      }
      ConfirmBox(this.confirmUpdate, msg, this.props);
    }
  };

  confirmUpdate = async () => {
    const status = await this.props.subscriberUpdate(this.state.subscriberVo);
    if (status === "success") {
      this.setState((prevState) => ({
        subscriberVo: {
          ...prevState.subscriberVo,
          ...this.props.SubScribeDataList,
        },
        message: ActionTypes.UPDATE_SUCCESS,
        editable: false,
        modified: false,
        closePopup: true,
      }));
    } else {
      this.setState({
        closePopup: true,
        message: status,
        editable: false,
        modified: false,
        currWtxClaimRefNbr: "",
      });
    }
  };
  handleNumber = (name) => (e) => {
    let value = e.target.value.replace(/[^0-9]/g, "");
    console.log("value in number " + value);
    this.setState((prevState) => ({
      subscriberVo: {
        ...prevState.subscriberVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleCancel = () => {
    this.setState((prevState) => ({
      subscriberVo: {
        ...prevState.subscriberVo,
        ...this.props.SubScribeDataList
      },
      editable: false,
      modified: false,
      validateStatus: false
    }));
  };


  setPayerAddress = (data) => {
    this.setState((prevState) => ({
      subscriberVo: {
        ...prevState.subscriberVo,
        payerCity: data.perCity,
        payerState: data.perState,
        payerCountry: data.countyCd,
        payerZip: data.perZip5
      },
      modified: true,
    }));
  };

  handlePayerBlur = (zip4, zip5) => async (event) => {
    event.preventDefault();
    const zipVo = {
      zip4: zip4,
      zip5: zip5
    }
    await this.props.resetZip();
    await this.props.searchCityZip(zipVo);
    if (!isEmpty(this.props.zipData)) {
      const data = this.props.zipData[0];
      this.setPayerAddress(data);
    }
  };

  setSubsAddress = (data) => {
    this.setState((prevState) => ({
      subscriberVo: {
        ...prevState.subscriberVo,
        subsCity: data.perCity,
        subsState: data.perState,
        subsCountry: data.countyCd,
        subsZip: data.perZip5
      },
      modified: true,
    }));
  };

  setZipData = async (data, param) => {
    if (param === "subsZip") {
      this.setState((prevState) => ({
        subscriberVo: {
          ...prevState.subscriberVo,
          subsCity: data.perCity,
          subsState: data.perState,
          subsCountry: data.countyCd,
          subsZip: data.perZip5
        },
        modified: true,
      }));
    } else if (param === "payerZip") {
      this.setState((prevState) => ({
        subscriberVo: {
          ...prevState.subscriberVo,
          payerCity: data.perCity,
          payerState: data.perState,
          payerCountry: data.countyCd,
          payerZip: data.perZip5
        },
        modified: true,
      }));
    }
  }

  handleBlur = (zip4, zip5, param) => async (event) => {
    event.preventDefault();
    const zipVo = {
      zip4: zip4,
      zip5: zip5
    }
    await this.props.resetZip();
    await this.props.searchCityZip(zipVo);
    if (!isEmpty(this.props.zipData)) {
      const data = this.props.zipData[0];
      this.setZipData(data, param);
    }
  };

  modalClosed = () => {
    this.setState({ closePopup: false });
  };

  render() {
    const { classes, dropdowns, selectedRow } = this.props;
    const {
      subscriberVo,
      editable,
      message,
      closePopup,
      modified,
    } = this.state;
    return (
      <React.Fragment>
        <Modal
          dialogTitle="SUBSCRIBER"
          message={message}
          show={closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        {!isEmpty(selectedRow) ? (
          <Paper elevation={0} className={classes.card}>
            <form autoComplete="off">
              <React.Fragment>
                <div>
                  {subscriberVo.emptyObject === false ?

                    (selectedRow &&
                      selectedRow.processStatus !== "ACC" &&
                      selectedRow.processStatus !== "SUB" &&
                      selectedRow.processStatus !== "PAC" &&
                      selectedRow.processStatus !== "RES" &&
                      selectedRow.processStatus !== "BAS" ?
                      (<div style={{ textAlign: "right" }}>
                        <EncButtonPanel
                          handleEdit={this.handleEdit}
                          handleUpdate={this.handleUpdate}
                          handleCancel={this.handleCancel}
                          handleNumber={this.handleNumber}
                          editable={!editable}
                          modified={modified}
                          selectedRow={selectedRow}
                        /></div>) : null)
                    :
                    <div style={{ textAlign: "right" }}>
                      <EncButtonPanel
                        handleEdit={this.handleEdit}
                        handleUpdate={this.handleUpdate}
                        handleCancel={this.handleCancel}
                        handleNumber={this.handleNumber}
                        disabled={true}
                        modified={modified}
                        selectedRow={selectedRow}
                      /></div>}



                  
                {subscriberVo.emptyObject ?
                <div class="alert alert-danger" id="displayMessage">
                  
                  {"NO SUBSCRIBER DATA"}
                </div> : null}

                {this.state.validateStatus ?
                  <div class="alert alert-danger" id="displayMessage">
                    <strong>Failed: &nbsp;</strong>
                    {"Please check the fields with error."}
                  </div> : null}



                <div class="panel-body">
                  <div class="twin-margin">
                    <div class="twin-boxes">
                      <div class="form-panel">
                        <div className={classes.container}>
                          <div>
                            <InputField
                              name="subsFirstName"
                              label=" First Name"
                              maxLength={24}
                              onChange={this.handleChange("subsFirstName")}
                              value={subscriberVo.subsFirstName}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div>
                            <InputField
                              name="subsMiddleName"
                              label="Middle Name"
                              maxLength={24}
                              onChange={this.handleChange("subsMiddleName")}
                              value={subscriberVo.subsMiddleName}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div>
                            <InputField
                              name="subsLastName"
                              label="Last Name"
                              maxLength={35}
                              onChange={this.handleChange("subsLastName")}
                              value={subscriberVo.subsLastName}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div style={{ "marginRight": "-18px" }}>
                            <InputField
                              name="subsEntityType"
                              label="Entity Type"
                              maxLength={1}
                              onChange={this.handleChange("subsEntityType")}
                              value={subscriberVo.subsEntityType}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div>
                            <InputField
                              name="subsAddrLine1"
                              label="Address1"
                              maxLength={55}
                              width="370px"
                              onChange={this.handleChange("subsAddrLine1")}
                              value={subscriberVo.subsAddrLine1}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div />
                          <div>
                            <InputField
                              name="subsAddrLine2"
                              label="Address2"
                              maxLength={50}
                              onChange={this.handleChange("subsAddrLine2")}
                              value={subscriberVo.subsAddrLine2}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage}></div>
                          </div>
                          <div>
                            <InputField
                              name="subsCity"
                              label="City"
                              maxLength={50}
                              onChange={this.handleChange("subsCity")}
                              value={subscriberVo.subsCity}
                              disabled={!editable}
                            />
                            <div
                              className={classes.validationMessageSelect}
                            ></div>
                          </div>
                          <div>
                            <Select
                              components={components}
                              propertyName={dropdowns.stateList.filter(
                                (option) =>
                                  option.value === subscriberVo.subsState
                              )}
                              options={dropdowns.stateList}
                              label="Choose Submitter ID ..."
                              textFieldProps={{
                                id: "subsState",
                                label: "State",
                                InputLabelProps: {
                                  className: classes.label,
                                  shrink: true,
                                },
                              }}
                              className={classes.textFieldSelect}
                              handleChange={this.handleChange("subsState")}
                              classes={classes}
                              isDisabled={!editable}
                            />
                            <div className={classes.validationMessage}></div>
                          </div>
                          <div>
                            <InputField
                              name="subsZip"
                              label="Zip"
                              maxLength={5}
                              onChange={this.handleNumber("subsZip")}
                              value={subscriberVo.subsZip}
                              disabled={!editable}
                              onBlur={this.handleBlur("", subscriberVo.subsZip, "subsZip")}
                            />
                            {editable ? (
                              <Popup
                                style={{ height: "65%" }}
                                className={classes.mobileWidth}
                                modal
                                trigger={<span class="more-info" />}
                                position="right center"
                              >
                                {(close) => (
                                  <div>
                                    <CityZipSearch
                                      headerLabel="SubsZip Search"
                                      zip5={subscriberVo.subsZip}
                                      zip4={""}
                                      param={"subsZip"}
                                      searchType="Zip_SEARCH"
                                      close={close}
                                      setData={this.setZipData}
                                    />
                                  </div>
                                )}
                              </Popup>
                            ) : null}
                            <div className={classes.validationMessage} />
                            {/* {this.validator.message(
                              "subsZip",
                              subscriberVo.subsZip,
                              "numeric|min:5,num"
                            )}
                          </div> */}
                          </div>
                          <div>
                            <InputField
                              name="subsCountry"
                              label="Country Code"
                              maxLength={3}
                              onChange={this.handleChange("subsCountry")}
                              value={subscriberVo.subsCountry}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div>
                            <InputField
                              name="subsCntrySubdCd"
                              label="Subd Code"
                              maxLength={3}
                              onChange={this.handleChange("subsCntrySubdCd")}
                              value={subscriberVo.subsCntrySubdCd}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage} />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="twin-boxes"  >
                      <div class="form-panel">
                        <div className={classes.container} style={{ marginLeft: "32px" }}>
                          <div >
                            <InputField
                              name="formattedSubsDob"
                              label="DOB"
                              maxLength={10}
                              onClick={this.handleDates("#formattedSubsDob")}
                              onChange={this.handleChange("formattedSubsDob")}
                              value={subscriberVo.formattedSubsDob}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage} >
                              {this.validator.message(
                                "dob",
                                subscriberVo.formattedSubsDob,
                                "date_format"
                              )}
                            </div>
                          </div>
                          <div>
                            <Select
                              components={components}
                              propertyName={dropdowns.genderList.filter(
                                (option) => option.value === subscriberVo.subsSex
                              )}
                              options={dropdowns.genderList}
                              label="Choose Sex ..."
                              textFieldProps={{
                                id: "sex",
                                label: "Sex",
                                InputLabelProps: {
                                  className: classes.label,
                                  shrink: true,
                                },
                              }}
                              className={classes.textFieldSelect}
                              handleChange={this.handleChange("subsSex")}
                              classes={classes}
                              isDisabled={!editable}
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div>
                            <InputField
                              name="subsHicNbr"
                              label="HICN"
                              maxLength={12}
                              onChange={this.handleChange("subsHicNbr")}
                              value={subscriberVo.subsHicNbr}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div>
                            <InputField
                              name="mbi"
                              label="Medicare ID"
                              maxLength={12}
                              onChange={this.handleChange("mbi")}
                              value={subscriberVo.mbi}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div />
                          <div>
                            <InputField
                              name="formattedSubsSsn"
                              label="SSN"
                              maxLength={11}
                              onChange={this.handleChange("formattedSubsSsn")}
                              value={subscriberVo.formattedSubsSsn}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage} >
                              {this.validator.message(
                                "SSN",
                                subscriberVo.formattedSubsSsn,
                                "ValidSSN"
                              )}
                            </div>
                          </div>
                          <div>
                            <InputField
                              name="subsPayerSeqCd"
                              label="Payer Seq Code"
                              maxLength={1}
                              onChange={this.handleChange("subsPayerSeqCd")}
                              value={subscriberVo.subsPayerSeqCd}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage}></div>
                          </div>
                          <div>
                            <InputField
                              name="subsRelationCd"
                              label="Relation Code"
                              maxLength={2}
                              onChange={this.handleChange("subsRelationCd")}
                              value={subscriberVo.subsRelationCd}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div>
                            <InputField
                              name="subsMemberId"
                              label="Member ID"
                              maxLength={20}
                              onChange={this.handleChange("subsMemberId")}
                              value={subscriberVo.subsMemberId}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage}></div>
                          </div>
                          <div>
                            <InputField
                              name="subsFilingIndCd"
                              label="Filing Ind Code"
                              maxLength={2}
                              onChange={this.handleChange("subsFilingIndCd")}
                              value={subscriberVo.subsFilingIndCd}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage}></div>
                          </div>
                          <div>
                            <InputField
                              name="subsGrpOrPolNbr"
                              label="Group or Policy Nbr"
                              maxLength={50}
                              onChange={this.handleChange("subsGrpOrPolNbr")}
                              value={subscriberVo.subsGrpOrPolNbr}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage}></div>
                          </div>
                          {selectedRow.encType === "I" ? (
                            <div>
                              <InputField
                                name="subsGrpName"
                                label="Group Name"
                                maxLength={50}
                                onChange={this.handleChange("subsGrpName")}
                                value={subscriberVo.subsGrpName}
                                disabled={!editable}
                              />
                              <div className={classes.validationMessage}></div>
                            </div>
                          ) : null}
                          {selectedRow.encType === "P" ||
                            selectedRow.encType === "E" ? (
                              <div>
                                <InputField
                                  name="subsPlanName"
                                  label="Group Name"
                                  maxLength={50}
                                  onChange={this.handleChange("subsPlanName")}
                                  value={subscriberVo.subsPlanName}
                                  disabled={!editable}
                                />
                                <div className={classes.validationMessage}></div>
                              </div>
                            ) : null}
                          {selectedRow.encType === "P" ||
                            selectedRow.encType === "E" ? (
                              <React.Fragment>
                                <div>
                                  <InputField
                                    name="subsInsuranceTypeCd"
                                    label="Ins Type Code"
                                    maxLength={50}
                                    onChange={this.handleChange("subsInsuranceTypeCd")}
                                    value={subscriberVo.subsInsuranceTypeCd}
                                    disabled={!editable}
                                  />
                                  <div className={classes.validationMessage}></div>
                                </div>


                                <div>
                                  <InputField
                                    name="subsPatDod"
                                    label="Patient DOD"
                                    maxLength={50}
                                    onChange={this.handleChange("subsPatDod")}
                                    value={subscriberVo.subsPatDod}
                                    disabled={!editable}
                                  />
                                  <div className={classes.validationMessage} />
                                </div>
                                <div>
                                  <InputField
                                    name="subsPatUom"
                                    label="Patient UOM"
                                    maxLength={50}
                                    onChange={this.handleChange("subsPatUom")}
                                    value={subscriberVo.subsPatUom}
                                    disabled={!editable}
                                  />
                                  <div className={classes.validationMessage} />
                                </div>
                                <div>
                                  <InputField
                                    name="subsPatPregnantInd"
                                    label="Patient Pregn"
                                    maxLength={50}
                                    onChange={this.handleChange("subsPatPregnantInd")}
                                    value={subscriberVo.subsPatPregnantInd}
                                    disabled={!editable}
                                  />
                                  <div className={classes.validationMessage} />
                                </div>

                                <div>
                                  <InputField
                                    name="subsPatWeight"
                                    label="Patient Weight"
                                    maxLength={50}
                                    onChange={this.handleNumber("subsPatWeight")}
                                    value={subscriberVo.subsPatWeight}
                                    disabled={!editable}
                                  />
                                  <div className={classes.validationMessage} />
                                </div>
                              </React.Fragment>
                            ) : null}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div></div>

                <div className={classes.applicationSectionHeading}>
                  <span> Payer</span>
                </div>
                <div class="panel-body">
                  <div class="twin-margin">
                    <div class="twin-boxes">
                      <div class="form-panel">
                        <div className={classes.container}>
                          <div>
                            <InputField
                              name="payerName"
                              label="Name"
                              maxLength={24}
                              onChange={this.handleChange("payerName")}
                              value={subscriberVo.payerName}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div>
                            <InputField
                              name="payerAddrLine1"
                              label="Address Line 1"
                              maxLength={55}
                              width="370px"
                              onChange={this.handleChange("payerAddrLine1")}
                              value={subscriberVo.payerAddrLine1}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div />
                          <div>
                            <InputField
                              name="payerAddrLine2"
                              label="Address Line 2"
                              maxLength={50}
                              onChange={this.handleChange("payerAddrLine2")}
                              value={subscriberVo.payerAddrLine2}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage}></div>
                          </div>
                          <div>
                            <InputField
                              name="payerCity"
                              label="City"
                              maxLength={50}
                              onChange={this.handleChange("payerCity")}
                              value={subscriberVo.payerCity}
                              disabled={!editable}
                            />
                            <div
                              className={classes.validationMessageSelect}
                            ></div>
                          </div>
                          <div>
                            <Select
                              components={components}
                              propertyName={dropdowns.stateList.filter(
                                (option) =>
                                  option.value === subscriberVo.payerState
                              )}
                              options={dropdowns.stateList}
                              label="Choose State ..."
                              textFieldProps={{
                                id: "state",
                                label: "State",
                                InputLabelProps: {
                                  className: classes.label,
                                  shrink: true,
                                },
                              }}
                              className={classes.textFieldSelect}
                              handleChange={this.handleChange("payerState")}
                              classes={classes}
                              isDisabled={!editable}
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div>
                            <InputField
                              name="payerZip"
                              label="Zip"
                              maxLength={20}
                              onChange={this.handleNumber("payerZip")}
                              value={subscriberVo.payerZip}
                              disabled={!editable}
                              onBlur={this.handlePayerBlur("", subscriberVo.payerZip, "payerZip")}
                            />
                            {editable ? (
                              <Popup
                                style={{ height: "65%" }}
                                className={classes.mobileWidth}
                                modal
                                trigger={<span class="more-info" />}
                                position="right center"
                              >
                                {(close) => (
                                  <div>
                                    <CityZipSearch
                                      headerLabel="PayerZip Search"
                                      zip5={subscriberVo.payerZip}
                                      zip4={""}
                                      param={"payerZip"}
                                      searchType="Zip_SEARCH"
                                      close={close}
                                      setData={this.setZipData}
                                    />
                                  </div>
                                )}
                              </Popup>
                            ) : null}
                            <div className={classes.validationMessage}></div>
                          </div>
                          <div>
                            <InputField
                              name="payerCountry"
                              label="Country Code"
                              maxLength={3}
                              onChange={this.handleChange("payerCountry")}
                              value={subscriberVo.payerCountry}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div>
                            <InputField
                              name="payerCntrySubdCd"
                              label="Subd Code"
                              maxLength={3}
                              onChange={this.handleChange("payerCntrySubdCd")}
                              value={subscriberVo.payerCntrySubdCd}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage}></div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="twin-boxes">
                      <div class="form-panel">
                        <div className={classes.container} style={{ marginLeft: "32px" }}>
                          <div>
                            <InputField
                              name="payerId"
                              label="ID"
                              maxLength={24}
                              onChange={this.handleChange("payerId")}
                              value={subscriberVo.payerId}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div>
                            <InputField
                              name="payerTaxId"
                              label="Tax ID"
                              maxLength={100}
                              onChange={this.handleChange("payerTaxId")}
                              value={subscriberVo.payerTaxId}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div>
                            <InputField
                              name="payerPlanId"
                              label="Plan ID"
                              maxLength={50}
                              onChange={this.handleChange("payerPlanId")}
                              value={subscriberVo.payerPlanId}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div>
                            <InputField
                              name="payerLocNbr"
                              label="Loc Nbr"
                              maxLength={4}
                              onChange={this.handleChange("payerLocNbr")}
                              value={subscriberVo.payerLocNbr}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div />
                          <div>
                            <InputField
                              name="payerNaicCd"
                              label="NAIC Code"
                              maxLength={55}
                              onChange={this.handleChange("payerNaicCd")}
                              value={subscriberVo.payerNaicCd}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div>
                            <InputField
                              name="payerSecId"
                              label="Sec ID"
                              maxLength={50}
                              onChange={this.handleChange("payerSecId")}
                              value={subscriberVo.payerSecId}
                              disabled={!editable}
                            />
                            <div className={classes.validationMessage} />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className={classes.applicationSectionHeading}>
                    <span> Other Info</span>
                  </div>
                  <div style={{ marginLeft: "-16px" }}>
                    <div class="panel-body">
                      <div className={classes.container}>
                        <div>
                          <InputField
                            name="billPrvCommNbr"
                            label="Bill Prv Comm Nbr"
                            maxLength={50}
                            onChange={this.handleChange("billPrvCommNbr")}
                            value={subscriberVo.billPrvCommNbr}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="billPrvLocNbr"
                            label="Bill Prv Loc Nbr"
                            maxLength={50}
                            onChange={this.handleChange("billPrvLocNbr")}
                            value={subscriberVo.billPrvLocNbr}
                            disabled={!editable}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div>
                          <InputField
                            name="propCasltyClmNbr"
                            label="P&C Clm Nbr"
                            maxLength={20}
                            onChange={this.handleChange("propCasltyClmNbr")}
                            disabled={!editable}
                            value={subscriberVo.propCasltyClmNbr}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        {selectedRow.encType === "P" ||
                          selectedRow.encType === "E" ? (
                            <React.Fragment>
                              <div>
                                <InputField
                                  name="propCasltySubsName"
                                  label="P&C Subs Name"
                                  maxLength={35}
                                  onChange={this.handleChange("propCasltySubsName")}
                                  disabled={!editable}
                                  value={subscriberVo.propCasltySubsName}
                                />
                                <div className={classes.validationMessage} />
                              </div>
                              <div>
                                <InputField
                                  name="propCasltySubsPhone"
                                  label="P&C Subs Phone"
                                  maxLength={35}
                                  disabled={!editable}
                                  onChange={this.handleChange("propCasltySubsPhone")}
                                  value={subscriberVo.propCasltySubsPhone}
                                />
                                <div className={classes.validationMessage} />
                              </div>
                              <div>
                                <InputField
                                  name="propCasltySubsPhnExt"
                                  label="P&C Subs Ext"
                                  maxLength={35}
                                  disabled={!editable}
                                  onChange={this.handleChange("propCasltySubsPhnExt")}
                                  value={subscriberVo.propCasltySubsPhnExt}
                                />
                                <div className={classes.validationMessage} />
                              </div>
                            </React.Fragment>
                          ) : null}
                      </div>
                    </div>
                  </div>
                </div>
                </div>


              </React.Fragment>
            </form>
          </Paper>
        ) : null}
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    SubScribeDataList: state.encounterDetailsData.subscriber_Data,
    zipData: state.CityZipReducer.cityZipSearchData,
    isLoading: state.spinner.isLoading,
    dropdowns: state.dropdowns,
  };
};

const mapDispatchToProps = {
  subscriberDetails,
  subscriberUpdate,
  searchCityZip,
  resetZip
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(Subscriber));
