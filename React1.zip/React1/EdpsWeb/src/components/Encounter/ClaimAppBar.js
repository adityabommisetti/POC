import AppBar from '@material-ui/core/AppBar';
import { withStyles } from '@material-ui/core/styles';
import Tab from '@material-ui/core/Tab';
import Tabs from '@material-ui/core/Tabs';
import Typography from '@material-ui/core/Typography';
import PropTypes from 'prop-types';
import React from 'react';
import Condition from './claimCodes/condition';
import DiagnosisCode from './claimCodes/diagnosisCode';
import ProcedureCode from './claimCodes/procedureCode';
import OccurrenceSpan from './claimCodes/occurrenceSpan';
import ValueCode from './claimCodes/value';
import ExtCauseInjury from "./claimCodes/extCauseInjury"
import Treatment from './claimCodes/treatment';
import Occurrence from './claimCodes/occurance';

function TabContainer(props) {
  return (
    <Typography component="div" style={{ padding: 8 * 3 }}>
      {props.children}
    </Typography>
  );
}

TabContainer.propTypes = {
  children: PropTypes.node.isRequired,
};

const styles = theme => ({
  root: {
    flexGrow: 1,
    width: '100%',
    backgroundColor: theme.palette.background.paper,
  },
});

class claimAppBar extends React.Component {

  constructor(props) {
    super(props);
    this.handleTabChange = this.handleTabChange.bind(this)
  }

  handleTabChange = (event, value) => {
    this.props.updatedTab(value)
  };

  render() {
    const { classes, value } = this.props;
    let tabIndex = 0;
    const encType = this.props.selectedRowData.encType;
    return (
      <div className={classes.root}>
        <AppBar position="static" color="default">
          <Tabs
            value={this.props.value}
            onChange={this.handleTabChange}
            variant="scrollable"
            scrollButtons="on"
            indicatorColor="primary"
            textColor="primary"
          >
            <Tab label="Condition" value="condition" />
            <Tab label="Diagnosis Code" value="dignsCode" />
            {encType === "I" ? <Tab label="Procedure Code" value="procCode" /> : null}
            {encType === "I" ? <Tab label="Occurrence Span" value="occrSpan" /> : null}
            {encType === "I" ? <Tab label="Value" value="value" /> : null}
            {encType === "I" ? <Tab label="Occurrence" value="occu" /> : null}
            {encType === "I" ? <Tab label="Treatment" value="treat" /> : null}
            {encType === "I" ? <Tab label="External Cause of Injury" value="extCauseOfInjury" /> : null}
          </Tabs>
        </AppBar>
        {
          (value === "condition" || value === tabIndex++) && <TabContainer>
            {this.props.claimConditionList ? <Condition
              claimConditionListData={this.props.claimConditionList}
              selectedRowData={this.props.selectedRowData}
              editable={this.props.editable}
              claimData={this.props.claimExpCol} /> : ""}</TabContainer>}
        {
          (value === "dignsCode" || value === tabIndex++) && <TabContainer>
            <DiagnosisCode
              selectedRowData={this.props.selectedRowData}
              editable={this.props.editable} />
          </TabContainer>
        }
        {
          (value === "procCode" || value === tabIndex++) && <TabContainer>
            <ProcedureCode
              selectedRowData={this.props.selectedRowData}
              editable={this.props.editable} />
          </TabContainer>
        }
        {
          (value === "occrSpan" || value === tabIndex++) && <TabContainer>
            <OccurrenceSpan
              selectedRowData={this.props.selectedRowData}
              editable={this.props.editable} />
          </TabContainer>
        }
        {
          (value === "value" || value === tabIndex++) && <TabContainer>
            <ValueCode
              selectedRowData={this.props.selectedRowData}
              editable={this.props.editable} />
          </TabContainer>
        }
        {
          (value === "occu" || value === tabIndex++) && <TabContainer>
            <Occurrence
              selectedRowData={this.props.selectedRowData}
              editable={this.props.editable} />
          </TabContainer>
        }
        {
          (value === "treat" || value === tabIndex++) && <TabContainer>
            <Treatment
              selectedRowData={this.props.selectedRowData}
              editable={this.props.editable} />
          </TabContainer>
        }
        {
          (value === "extCauseOfInjury" || value === tabIndex++) && <TabContainer>
            <ExtCauseInjury
              selectedRowData={this.props.selectedRowData}
              editable={this.props.editable} />
          </TabContainer>
        }
      </div >
    );
  }
}

claimAppBar.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default (withStyles(styles)(claimAppBar));