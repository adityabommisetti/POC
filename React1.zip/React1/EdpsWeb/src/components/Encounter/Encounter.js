import Button from "@material-ui/core/Button";
import Checkbox from "@material-ui/core/Checkbox";
import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormLabel from "@material-ui/core/FormLabel";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import { withStyles } from "@material-ui/core/styles";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import RadioButtonCheckedIcon from "@material-ui/icons/RadioButtonChecked";
import RadioButtonUncheckedIcon from "@material-ui/icons/RadioButtonUnchecked";
import isEmpty from "lodash/isEmpty";
import React, { Component } from "react";
import { connect } from "react-redux";
import { compose } from 'redux';
import Popup from "reactjs-popup";
import { Styles } from "../../assets/styles/Theme";
import * as DateUtil from "../../utils/DatePicker";
import DataTable from "../Home/DataTable";
import ExpansionPanel from "../UI/ExpansionPanel";
import InputField from "../UI/InputField";
import SearchBtnPanel from "../UI/SearchBtnPanel";
import { components, Select } from "../UI/Select";
import { withRouter } from 'react-router';
import EdpsAppBar from './edpsAppBar';
import autosize from "autosize";
import LogDetailsPopUp from "./LogDetailsPopUp";
import ClaimVersion from "./ClaimVersion";
import VanTanSearch from "./VanTanSearch";
import SimpleReactValidator from "simple-react-validator";
import { customValidations } from "../../utils/CustomValidations";
import {
  ENCOUNTER_DETAILS_ERROR,
  ENCOUNTER_DETAILS_SEARCH,
  ENCOUNTER_EXPORT
} from "../../constants/header/encounterDetailsHeader";
import {
  encounterSearch,
  encounterCriteria,
  getEncounterExport,
  fetchClaim,
  providerDetails,
  subscriberDetails
} from "../../redux/actions/encounterDetailsAction";

const dateChk = {};
const INITIAL_STATE = {
  mfId: "",
  dateInd: "0",
  fromDate: "01/01/2020",
  toDate: "12/31/".concat(new Date().getFullYear()),
  encType: "P",
  clmType: "EN",
  groupStatus: "",
  submitterId: "",
  errorSource: "",
  errorCode: "",
  selectedDate: "",
  rejectCode: "",
  formattedErrorSource: "",
  errorGroup: "",
  wtxClaimRefNbr: "",
  hicNbr: "",
  origIntrchgCtrlNbr: null,
  maoflag: "",
  valueAddNtwkTraceNbr: "",
  origClmRefNbr: "",
  claimSeqNbr: "",
  fileIcn: "",
  cmsIcn: "",
  diagnosisCd: "",
  procedureCd: "",
  dataSource: "",
  contractNbr: "",
  providerId: "",
  overrideInd: "",
  pageValue: 0,
  sortingRequired: false,
  ascending: false,
  sortField: "",
  isVanTn: false,
  paperClaim: false,
  exportAll: false,
  fileTrackFlag: false,
  enOrCrNavigation: false,
  claimVersionRequired: false
};
class Encounter extends Component {
  constructor(props) {
    super(props);
    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
        date_after: customValidations.date_after,
        clmNbrValidator: customValidations.clmNbrValidator
      },
    });
    this.state = {
      searchVo: { ...INITIAL_STATE },
      subsClmRefNbr: 0,
      clmClmRefNbr: 0,
      provClmRefNbr: 0,
      collapseSearch: false,
      searchResultList: [],
      allExportData: [],
      selectedRow: {},
      errorList: [],
      rowsPerPage: 25,
      selectedIndex: 0,
      errorIndex: 0,
      clmRefNbr: 0,
      flag: false,
      allSubmitter: false,
      tabIndexValue: "subscriber",
      location: this.props.history.location.pathname
    };
  }

  async componentDidMount() {
    let searchCriteria = {};
    const { location } = this.state;
    const { routePayload } = this.props;
    autosize(this.textarea);
    if (!isEmpty(this.props.dropdowns)) {
      await this.setState(prevState => ({
        searchVo: {
          ...prevState.searchVo,
          "submitterId": !isEmpty(this.props.dropdowns.optionsSubmitters) ?
            this.props.dropdowns.optionsSubmitters[0].value : "",
        }
      }));
    }
    if (location === "/encounter") {
      searchCriteria = this.props.encCriteria;
    } else if (location === "/reject") {
      searchCriteria = this.props.rejectEncounterCriteria;
    } else if (location === "/chart") {
      searchCriteria = this.props.chartEncounterCriteria;
    } else if (location === "/chartReject") {
      searchCriteria = this.props.chartRejectEncounterCriteria;
    }
    if (!isEmpty(this.props.routePayload)) {
      await this.setState(prevState => ({
        searchVo: {
          ...prevState.searchVo,
          fromDate: routePayload.fromDate ? routePayload.fromDate : "",
          toDate: routePayload.toDate ? routePayload.toDate : "",
          groupStatus: routePayload.groupStatus ? routePayload.groupStatus : "",
          fileTrackFlag: routePayload.fileTrackFlag ? true : false,
          clmType: routePayload.claimType,
          encType: routePayload.encType,
          submitterId: routePayload.submitterId,
          origIntrchgCtrlNbr: routePayload.origIntrchgCtrlNbr,
          dateInd: routePayload.dateInd ? routePayload.dateInd : routePayload.searchSummaryDateInd
        }
      }));
    } else if (!isEmpty(searchCriteria)) {
      await this.setState(prevState => ({
        searchVo: {
          ...prevState.searchVo,
          ...searchCriteria,
          errorSource: searchCriteria.errorSource,
          errorCode: searchCriteria.errorCd ? searchCriteria.errorCd : searchCriteria.errorCode,
          fromDate: searchCriteria.fromDate ? searchCriteria.fromDate : searchCriteria.fromDateYrmo,
          toDate: searchCriteria.toDate ? searchCriteria.toDate : searchCriteria.toDateYrmo,
          dateInd: searchCriteria.dateInd ? searchCriteria.dateInd : searchCriteria.searchSummaryDateInd
        }
      }));
    }
    await this.getEncounterDetails(this.state.searchVo);
    await this.setState({
      selectedRow: !isEmpty(this.props.searchResultsVo.EncSearchList)
        ? this.props.searchResultsVo.EncSearchList[0] : {},
      tabIndexValue: "subscriber"
    });
    this.getTabData();
  }

  componentWillMount() {
    const encHeaderLen = ENCOUNTER_DETAILS_SEARCH.length - 1;
    if (
      this.props.parentTab === "edpsManagement" ||
      this.props.parentTab === "rejectAnalysis"
    ) {
      this.setState(prevState => ({
        searchVo: {
          ...prevState.searchVo,
          clmType: "EN"
        },
        searchResultList: []
      }));
      ENCOUNTER_DETAILS_SEARCH[encHeaderLen].label = "CR";
      ENCOUNTER_DETAILS_SEARCH[encHeaderLen].title = "CR";
      ENCOUNTER_DETAILS_SEARCH[encHeaderLen].name = "CR";
    } else {
      this.setState(prevState => ({
        searchVo: {
          ...prevState.searchVo,
          clmType: "CR"
        },
        searchResultList: []
      }));
      ENCOUNTER_DETAILS_SEARCH[encHeaderLen].label = "EN";
      ENCOUNTER_DETAILS_SEARCH[encHeaderLen].title = "EN";
      ENCOUNTER_DETAILS_SEARCH[encHeaderLen].name = "EN";
    }
  }


  handleCheckBox = name => event => {
    this.setState(prevState => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: !this.state.searchVo[name]
      }
    }));
  };

  handleSubmitterId = name => event => {
    let submitterId = this.props.dropdowns.optionsSubmitters[0].value;
    if (!this.state.allSubmitter && this.props.dropdowns) {
      submitterId = "all";
    }
    this.setState(prevState => ({
      searchVo: {
        ...prevState.searchVo,
        submitterId: submitterId
      },
      allSubmitter: !this.state.allSubmitter
    }));
  };

  handleDates = (fieldId, targetVo) => {
    var self = this;
    DateUtil.getDatePicker(fieldId).on("change", e => {
      if (dateChk.name !== e.target.name || dateChk.value !== e.target.value) {
        self.setDate(e.target.name, e.target.value, targetVo);
      }
      dateChk.name = e.target.name;
      dateChk.value = e.target.value;
    });
  };

  setDate = (name, value, targetVo) => {
    if (targetVo === "searchVo") {
      this.setState(prevState => ({
        searchVo: {
          ...prevState.searchVo,
          [name]: value
        }
      }));
    }
  };

  handleSearchFieldChange = name => event => {
    let value = event.target
      ? event.target.value.toUpperCase()
      : event.value.toUpperCase();
    this.setState(prevState => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value
      },
      collapseSearch: false
    }));
  };

  handleNumber = name => e => {
    let value = e.target.value.replace(/[^0-9]/g, "");
    this.setState(prevState => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value
      }
    }));
  };

  handleAlphaNumeric = (name, targetVo) => e => {
    let value = e.target.value.replace(/[^-\w\s]/g, "").toUpperCase();
    this.setState(prevState => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value
      },
      collapseSearch: false
    }));
  };

  getEncounterDetails = async () => {
    await this.props.encounterSearch(this.state.searchVo);
    if (!isEmpty(this.props.searchResultsVo)) {
      this.setState({
        searchResultList: [...this.props.searchResultsVo.EncSearchList],
        errorList: [...this.props.searchResultsVo.EncErrorList]
      });
    }
  };

  handleSort = async (colToSort, sortDir) => {
    this.setState(prevState => ({
      searchVo: {
        ...prevState.searchVo,
        sortingRequired: true,
        ascending: sortDir === 'asc' ? true : false,
        sortField: colToSort,
        pageValue: 0
      },
      selectedIndex: 0
    }));
    await this.props.encounterSearch(this.state.searchVo);
    if (!isEmpty(this.props.searchResultsVo)) {
      await this.setState({
        searchResultList: [...this.props.searchResultsVo.EncSearchList],
        errorList: [...this.props.searchResultsVo.EncErrorList],
        selectedRow: !isEmpty(this.props.searchResultsVo.EncSearchList)
          ? this.props.searchResultsVo.EncSearchList[0] : {}
      });
    }
    this.getTabData();
  }

  getTabData = () => {
    if (!isEmpty(this.props.searchResultsVo.EncSearchList)) {
      if (
        this.state.tabIndexValue === "subscriber" &&
        this.state.subsClmRefNbr !== this.state.selectedRow.wtxClaimRefNbr
      ) {
        this.props.subscriberDetails(this.state.selectedRow);
        this.setState({
          subsClmRefNbr: this.state.selectedRow.wtxClaimRefNbr
        });
      } else if (
        this.state.tabIndexValue === "claim" &&
        this.state.clmClmRefNbr !== this.state.selectedRow.wtxClaimRefNbr
      ) {
        this.props.fetchClaim(this.state.selectedRow);
        this.setState({
          clmClmRefNbr: this.state.selectedRow.wtxClaimRefNbr
        });
      } else if (
        this.state.tabIndexValue === "provider" &&
        this.state.provClmRefNbr !== this.state.selectedRow.wtxClaimRefNbr
      ) {
        this.props.providerDetails(this.state.selectedRow);
        this.setState({
          provClmRefNbr: this.state.selectedRow.wtxClaimRefNbr
        });
      }
    }
  };

  search = async () => {
    if (!this.validator.allValid()) {
      this.validator.showMessages();
      this.forceUpdate();
    }
    else {
      const { searchVo } = this.state;
      const pattern1 = new RegExp(
        "^[a-zA-Z0-9*]*$"
      ); /**AlphaNumeric Value Only */
      const pattern2 = new RegExp(
        "^[a-zA-Z0-9]+(,[a-zA-Z0-9]+)*$"
      ); /** Value separated by comma*/
      const pattern3 = new RegExp(
        "^[a-zA-Z0-9]*-?[a-zA-Z0-9]*$"
      ); /**Values in the range */
      if (
        searchVo.errorCode !== "" &&
        !(
          pattern1.test(searchVo.errorCode) ||
          pattern2.test(searchVo.errorCode) ||
          pattern3.test(searchVo.errorCode)
        )
      ) {
        alert("Please Fill Error Code in Correct Format.");
      } else if (
        searchVo.diagnosisCd !== "" &&
        !(
          pattern1.test(searchVo.diagnosisCd) ||
          pattern2.test(searchVo.diagnosisCd) ||
          pattern3.test(searchVo.diagnosisCd)
        )
      ) {
        alert("Please Fill Diagnosis Code in Correct Format.");
      } else if (
        searchVo.procedureCd !== "" &&
        !(
          pattern1.test(searchVo.procedureCd) ||
          pattern2.test(searchVo.procedureCd) ||
          pattern3.test(searchVo.procedureCd)
        )
      ) {
        alert("Please Fill Procedure Code in Correct Format.");
      } else {
        await this.setState(prevState => ({
          searchVo: {
            ...prevState.searchVo,
            pageValue: 0,
            sortingRequired: false,
            ascending: "",
            sortField: ""
          },
          flag: true
        }));
        await this.props.encounterCriteria(this.state.searchVo, this.state.location);
        await this.getEncounterDetails();
        await this.setState(prevState => ({
          searchVo: {
            ...prevState.searchVo,
            pageValue: 0
          },
          selectedRow: !isEmpty(this.props.searchResultsVo.EncSearchList)
            ? this.props.searchResultsVo.EncSearchList[0]
            : {},
          selectedIndex: 0,
          tabIndexValue: "subscriber",
          flag: false
        }));
        this.getTabData();
        if (searchVo.wtxClaimRefNbr !== "") {
          alert(
            this.props.searchResultsVo.EncSearchList.length +
            " Out of " +
            searchVo.wtxClaimRefNbr.split(",").length +
            " Claims Found"
          );
        }
      }
    }
  };

  reset = async () => {
    INITIAL_STATE.submitterId = !isEmpty(this.props.dropdowns.optionsSubmitters) ?
      this.props.dropdowns.optionsSubmitters[0].value : "";
    await this.setState({
      searchVo: {
        ...INITIAL_STATE,
        clmType:
          (this.props.parentTab === "edpsManagement" ||
            this.props.parentTab === "rejectAnalysis")
            ? "EN" : "CR"
      },
      allSubmitter: false
    })
    await this.props.encounterCriteria(this.state.searchVo, this.state.location);
  };

  handleChangeRowsPerPage = async (rowsPerPage) => {
    this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  applSearchNextPage = async (pageNo) => {
    const payload = { ...this.state.searchVo };
    payload.pageValue = (this.state.searchResultList.length / 100);
    await this.props.encounterSearch(payload);
    this.setState({
      searchResultList: [...this.state.searchResultList, ...this.props.searchResultsVo.EncSearchList],
      errorList: [...this.props.searchResultsVo.EncErrorList]
    });
    this.getTabData();
  };

  crTypeSelect = async (data) => {
    const searchVo = { ...this.state.searchVo };
    searchVo.wtxClaimRefNbr = data.wtxClaimRefNbr;
    searchVo.pageValue = 0;
    searchVo.clmType = this.props.parentTab === "edpsManagement" ? 'CR' : 'EN'
    searchVo.enOrCrNavigation = true;
    if (this.props.parentTab === "edpsManagement") {
      await this.props.encounterCriteria(searchVo, '/chart');
      this.props.history.push({
        pathname: '/chart',
        encounterPayload: searchVo
      })
    } else {
      await this.props.encounterCriteria(searchVo, '/encounter');
      this.props.history.push({
        pathname: '/encounter',
        encounterPayload: searchVo
      })
    }
  }

  selectRow = async (selectedRowIndex, data) => {
    if (data.wtxClaimRefNbr !== this.state.selectedRow.wtxClaimRefNbr) {
      const selectedVo = data;
      const searchVo = { ...this.state.searchVo };
      searchVo.wtxClaimRefNbr = selectedVo.wtxClaimRefNbr;
      searchVo.pageValue = 0;
      await this.props.encounterSearch(searchVo);
      this.setState({
        selectedIndex: selectedRowIndex,
        selectedRow: data,
        errorList: [...this.props.searchResultsVo.EncErrorList]
      });
      console.log(this.state.selectedRow)
      this.getTabData();
    }
  };

  selectError = index => {
    this.setState({
      errorIndex: index
    })
  };

  updatedTab = async (tabname) => {
    await this.setState({
      tabIndexValue: tabname
    });
    this.getTabData();
  };

  claimVersion = (data) => {
    this.setState(prevState => ({
      searchVo: {
        ...prevState.searchVo,
        claimSeqNbr: data.claimSeqNbr,
        overrideInd: data.overrideInd,
        wtxClaimRefNbr: data.wtxClaimRefNbr,
      }
    }));
  }

  getExportData = async (isAllExport) => {
    const payload = { ...this.state.searchVo };
    payload.exportAll = isAllExport
    const data = await this.props.getEncounterExport(payload);
    console.log(data)
    this.setState({
      allExportData: data
    })
  }

  render() {
    const textAreaStyles = {
      maxHeight: "100px",
      minHeight: "12px",
      resize: "none",
      boxSizing: "border-box",
      overflow: "hidden scroll",
      overflowWrap: "break-word",
      borderRadius: "5px 0px 0px 5px",
      border: "1px solid #999 !important",
      width: "170px",
      height: "28px !important"
    };

    const { classes, dropdowns } = this.props;
    const { searchVo, searchResultList, errorList, rowsPerPage, flag } = this.state;

    return (
      <React.Fragment>
        <React.Fragment>
          {!isEmpty(dropdowns) ? (
            <ExpansionPanel
              summary="Search"
              defaultCollapsed={this.state.collapseSearch}
            >
              <div className={classes.container} id="SearchPanel">
                <div>
                  <Select
                    components={components}
                    defaultValue={dropdowns.optionsSubmitters[0]}
                    propertyName={dropdowns.optionsSubmitters.filter(
                      option => option.value === searchVo.submitterId
                    )}
                    options={dropdowns.optionsSubmitters}
                    label="Choose Submitter ID ..."
                    textFieldProps={{
                      id: "submitterId",
                      label: "Submitter ID",
                      InputLabelProps: {
                        className: classes.label,
                        shrink: true
                      }
                    }}
                    className={classes.textFieldSearch}
                    handleChange={this.handleSearchFieldChange("submitterId")}
                    classes={classes}
                    isDisabled={this.state.allSubmitter}
                  />
                </div>
                <div
                  className={classes.Checkbox}
                  style={{ width: "182px", marginTop: "15px" }}
                >
                  <FormLabel classes={{ root: classes.formLabel }}>
                    All SubmitterId
                  </FormLabel>
                  <Checkbox
                    icon={
                      <CheckBoxOutlineBlankIcon style={{ fontSize: "16px" }} />
                    }
                    checkedIcon={
                      <CheckBoxIcon className={classes.encounterCheckBox} />
                    }
                    checked={this.state.allSubmitter}
                    onClick={this.handleSubmitterId("allSubmitter")}
                    inputProps={{
                      "aria-label": "primary checkbox"
                    }}
                  />
                </div>
                <div style={{ marginRight: "58px" }}>
                  <FormControl
                    component="fieldset"
                    className={classes.formControl}
                  >
                    <FormLabel
                      component="legend"
                      className={classes.legend}
                    ></FormLabel>
                    <RadioGroup
                      name="dateInd"
                      className={classes.group}
                      value={searchVo.dateInd}
                      onChange={this.handleSearchFieldChange("dateInd")}
                    >
                      <FormControlLabel
                        value="0"
                        control={
                          <Radio
                            color="primary"
                            icon={<RadioButtonUncheckedIcon fontSize="small" />}
                            checkedIcon={
                              <RadioButtonCheckedIcon fontSize="small" />
                            }
                          />
                        }
                        label="Submission Date"
                      />
                      <FormControlLabel
                        value="1"
                        control={
                          <Radio
                            color="primary"
                            icon={<RadioButtonUncheckedIcon fontSize="small" />}
                            checkedIcon={
                              <RadioButtonCheckedIcon fontSize="small" />
                            }
                          />
                        }
                        label="Service Date"
                      />
                    </RadioGroup>
                  </FormControl>
                </div>
                <div>
                  <InputField
                    name="providerId"
                    label="Provider ID"
                    maxLength={10}
                    value={searchVo.providerId}
                    onChange={this.handleSearchFieldChange("providerId")}
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="fromDate"
                    placeholder="MM/DD/YYYY"
                    label="From"
                    value={searchVo.fromDate}
                    onClick={this.handleDates("#fromDate", "searchVo")}
                    maxLength={10}
                    onChange={this.handleSearchFieldChange("fromDate")}
                    required
                  />
                  <div className={classes.validationMessage}>
                    {this.validator.message(
                      "FromDate",
                      searchVo.fromDate,
                      "required|date_format"
                    )}
                  </div>
                </div>
                <div>
                  <InputField
                    name="toDate"
                    placeholder="MM/DD/YYYY"
                    label="To"
                    value={searchVo.toDate}
                    onClick={this.handleDates("#toDate", "searchVo")}
                    maxLength={10}
                    onChange={this.handleSearchFieldChange("toDate")}
                    required
                  />
                  <div className={classes.validationMessage}>
                    {this.validator.message(
                      "ToDate",
                      searchVo.toDate,
                      [
                        "required",
                        "date_format",
                        { date_after: searchVo.fromDate },
                      ]
                    )}

                  </div>
                </div>
                <div>
                  <Select
                    components={components}
                    propertyName={dropdowns.optionsEncType.filter(
                      option => option.value === searchVo.encType
                    )}
                    options={dropdowns.optionsEncType}
                    label="Choose Claim Type ..."
                    textFieldProps={{
                      id: "encType",
                      label: "Claim Type",
                      InputLabelProps: {
                        className: classes.label,
                        shrink: true
                      }
                    }}
                    className={classes.textFieldSearch}
                    handleChange={this.handleSearchFieldChange("encType")}
                    classes={classes}
                  />
                </div>
                <div>
                  <InputField
                    name="hicNbr"
                    label="Medicare ID"
                    maxLength="12"
                    value={searchVo.hicNbr}
                    onChange={this.handleSearchFieldChange("hicNbr")}
                  />
                  <div className={classes.validationMessage}>
                    {this.validator.message(
                      "medicareId",
                      searchVo.hicNbr,
                      "alpha_num"
                    )}
                  </div>
                </div>
                <div>
                  <Select
                    components={components}
                    propertyName={dropdowns.optionsGroupStatus.filter(
                      option => option.value === searchVo.groupStatus
                    )}
                    options={dropdowns.optionsGroupStatus}
                    label="Choose Status ..."
                    textFieldProps={{
                      id: "groupStatus",
                      label: "Status",
                      InputLabelProps: {
                        className: classes.label,
                        shrink: true
                      }
                    }}
                    className={classes.textFieldSearch}
                    handleChange={this.handleSearchFieldChange("groupStatus")}
                    classes={classes}
                  />
                </div>
                <div>
                  <Select
                    components={components}
                    propertyName={dropdowns.optionsErrorSource.filter(
                      option => option.value === searchVo.errorSource
                    )}
                    options={dropdowns.optionsErrorSource}
                    label="Choose Status ..."
                    textFieldProps={{
                      id: "errorSource",
                      label: "Error Source",
                      InputLabelProps: {
                        className: classes.label,
                        shrink: true
                      }
                    }}
                    className={classes.textFieldSearch}
                    handleChange={this.handleSearchFieldChange("errorSource")}
                    classes={classes}
                  />
                </div>
                <div>
                  <Select
                    components={components}
                    propertyName={dropdowns.optionsErrorGroup.filter(
                      option => option.value === searchVo.errorGroup
                    )}
                    options={dropdowns.optionsErrorGroup}
                    label="Choose Error Group ..."
                    textFieldProps={{
                      id: "errorGroup",
                      label: "Error Group",
                      InputLabelProps: {
                        className: classes.label,
                        shrink: true
                      }
                    }}
                    className={classes.textFieldSearch}
                    handleChange={this.handleSearchFieldChange("errorGroup")}
                    classes={classes}
                  />
                </div>
                <div>
                  <InputField
                    name="errorCode"
                    label="Error Code"
                    value={searchVo.errorCode}
                    onChange={this.handleSearchFieldChange("errorCode")}
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="contractNbr"
                    label="Contract #"
                    maxLength={5}
                    value={searchVo.contractNbr}
                    onChange={this.handleSearchFieldChange("contractNbr")}
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="origClmRefNbr"
                    label="Other Cust Claim ID"
                    maxLength={20}
                    value={searchVo.origClmRefNbr}
                    onChange={this.handleSearchFieldChange("origClmRefNbr")}
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="diagnosisCd"
                    label="Diagnosis"
                    value={searchVo.diagnosisCd}
                    onChange={this.handleSearchFieldChange("diagnosisCd")}
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="procedureCd"
                    label="Procedure code"
                    value={searchVo.procedureCd}
                    onChange={this.handleSearchFieldChange("procedureCd")}
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="cmsIcn"
                    label="CMS ICN"
                    maxLength={15}
                    value={searchVo.cmsIcn}
                    onChange={this.handleSearchFieldChange("cmsIcn")}
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="fileIcn"
                    label="File ICN"
                    maxLength={15}
                    value={searchVo.fileIcn}
                    onChange={this.handleSearchFieldChange("fileIcn")}
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="valueAddNtwkTraceNbr"
                    label="Network ID"
                    maxLength={20}
                    value={searchVo.valueAddNtwkTraceNbr}
                    onChange={this.handleSearchFieldChange(
                      "valueAddNtwkTraceNbr"
                    )}
                  />
                  <Popup
                    className={classes.mobileWidth}
                    modal
                    trigger={
                      <Button
                        id="vanTanBtn"
                        variant="contained"
                        style={{ marginTop: "5px" }}
                        color="primary"
                        disabled={!this.state.searchVo.valueAddNtwkTraceNbr}
                        className={this.props.classes.button}
                      >
                        Network ID
                      </Button>
                    }
                    position="right center"
                  >
                    {close => (
                      <div>
                        <VanTanSearch
                          close={close}
                          searchVo={searchVo}
                          claimVersion={this.claimVersion}
                        />
                      </div>
                    )}
                  </Popup>
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <div>
                    <FormLabel
                      classes={{ root: classes.formLabel }}
                      style={{
                        color: "#053674",
                        fontSize: "0.7rem",
                        fontWeight: "600",
                        marginTop: "6px"
                      }}
                    >
                      Claim Nbr
                </FormLabel>
                  </div>
                  <div>
                    <textarea
                      style={textAreaStyles}
                      ref={c => (this.textarea = c)}
                      rows={1}
                      value={searchVo.wtxClaimRefNbr}
                      onChange={this.handleSearchFieldChange("wtxClaimRefNbr")}
                    />
                    {/* <div className={classes.validationMessage}>
                    {this.validator.message(
                      "clmNbr",
                      searchVo.wtxClaimRefNbr,
                      "clmNbrValidator"
                    )}
                  </div> */}
                    <Popup
                      className={classes.mobileWidth}
                      modal
                      trigger={
                        <Button
                          id="claimVersion"
                          variant="contained"
                          style={{ marginTop: "-10px" }}
                          color="primary"
                          disabled={!this.state.searchVo.wtxClaimRefNbr}
                          className={this.props.classes.button}
                        >
                          Claim Version
                        </Button>
                      }
                      position="right center"
                    >
                      {close => (
                        <div>
                          <ClaimVersion
                            close={close}
                            searchVo={searchVo}
                            claimVersion={this.claimVersion}
                          />
                        </div>
                      )}
                    </Popup>
                  </div>
                </div>
                <div
                  className={classes.Checkbox}
                  style={{ width: "182px", marginTop: "15px", marginLeft: "80px" }}
                >
                  <FormLabel classes={{ root: classes.formLabel }}>
                    Paper Claim
                  </FormLabel>
                  <Checkbox
                    icon={
                      <CheckBoxOutlineBlankIcon style={{ fontSize: "16px" }} />
                    }
                    checkedIcon={
                      <CheckBoxIcon className={classes.encounterCheckBox} />
                    }
                    checked={this.state.searchVo.paperClaim}
                    onClick={this.handleCheckBox("paperClaim")}
                    value={this.state.searchVo.paperClaim}
                    inputProps={{
                      "aria-label": "primary checkbox"
                    }}
                  />
                </div>
              </div>
              <div className={classes.container} id="btnPanel">
                <SearchBtnPanel search={this.search} reset={this.reset} />
              </div>
            </ExpansionPanel>
          ) : null}

          {this.props.searchResultsVo.EncSearchList ? (
            <ExpansionPanel
              summary={((this.props.parentTab === "edpsManagement") || (this.props.parentTab === "rejectAnalysis")) ?
                "Medicare Encounter - List" : (this.props.parentTab === "chartManagement") ?
                  "Medicare Chart Review" : "Search Results"}
              rowChanged={this.rowChanged}
            >
              <DataTable
                data={searchResultList}
                allExportData={this.state.allExportData}
                header={ENCOUNTER_DETAILS_SEARCH}
                exportHeader={ENCOUNTER_EXPORT}
                sortable={true}
                searchTable
                clicked={this.selectRow}
                flag={flag}
                searchable={true}
                exportAsExcel={true}
                applExportbtn={true}
                rowsPerPage={rowsPerPage}
                rowsPerPageOptions={[10, 15, 20, 25]}
                index={this.state.selectedIndex}
                crTypeSelect={this.crTypeSelect}
                getExportData={this.getExportData}
                fetchMore={this.applSearchNextPage}
                handleSort={this.handleSort}
                handleChangeRowsPerPage={this.handleChangeRowsPerPage}
                totalRecords={searchResultList[0] && searchResultList[0].totalRecords}
              />
            </ExpansionPanel>
          ) : null}
          {!isEmpty(errorList) ? (
            <ExpansionPanel summary="Error List">
              <DataTable
                data={errorList}
                header={ENCOUNTER_DETAILS_ERROR}
                rowsPerPage={5}
                sortable={true}
                selectedIndex={this.state.errorIndex}
                errorTable
                clicked={this.selectError}
              />
              <div>
                <InputField
                  label="Error Count"
                  value={errorList.length}
                  disabled={true}
                />
                <div className={classes.validationMessage} />
              </div>
            </ExpansionPanel>) : null}
        </React.Fragment>
        <React.Fragment>
          {!isEmpty(searchResultList) ? (
            <Popup
              className={classes.mobileWidth}
              style={{ float: "right" }}
              modal
              trigger={
                <Button
                  id="logDetails-popup"
                  name="logDetails-popup"
                  variant="contained"
                  color="primary"
                  className={this.props.classes.button}
                >
                  Log Details
                </Button>
              }
              position="right center"
            >
              {close => (
                <div>
                  <LogDetailsPopUp
                    close={close}
                    selectedRow={this.state.selectedRow}
                  />
                </div>
              )}
            </Popup>
          ) : null}
        </React.Fragment>
        {!isEmpty(searchResultList) ? (
          <React.Fragment>
            <EdpsAppBar
              updatedTab={this.updatedTab}
              value={this.state.tabIndexValue}
              selectedRow={this.state.selectedRow}
            />
          </React.Fragment>
        ) : null}
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  return {
    dropdowns: state.dropdowns,
    searchResultsVo: state.encounterDetailsData.searchResultList,
    encCriteria: state.encounterDetailsData.encounterCriteria,
    rejectEncounterCriteria: state.encounterDetailsData.rejectEncounterCriteria,
    chartEncounterCriteria: state.encounterDetailsData.chartEncounterCriteria,
    chartRejectEncounterCriteria: state.encounterDetailsData.chartRejectEncounterCriteria
  };
};

const mapDispatchToProps = {
  encounterSearch,
  encounterCriteria,
  getEncounterExport,
  subscriberDetails,
  fetchClaim,
  providerDetails
};

export default compose(
  withRouter,
  withStyles(Styles),
  connect(mapStateToProps, mapDispatchToProps)
)(Encounter)  