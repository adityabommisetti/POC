import React from 'react';
import DataTable from "../Home/DataTable";
import { withStyles } from "@material-ui/core/styles";
import { Styles } from "../../assets/styles/Theme";
import { CLAIM_NOTES } from "../../constants/header/encounterDetailsHeader";

class ClaimNotes extends React.Component {
    render() {
        const { classes, claimNotesData } = this.props;
        return (
            <React.Fragment>
                <div className={classes.content}>
                    <div className={classes.applicationTableHeading}>
                        <span> Claim Notes</span>
                    </div>
                    <DataTable
                        data={claimNotesData}
                        header={CLAIM_NOTES}
                        rowsPerPage={3}
                        sortableHeader={true}
                    />
                </div>
            </React.Fragment>
        )
    }
}

export default (withStyles(Styles)(ClaimNotes));
