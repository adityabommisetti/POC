import React from "react";
import { withStyles } from "@material-ui/core/styles";
import InputField from "../UI/InputField";
import { Styles } from "../../assets/styles/Theme";
import { Control, Menu, Option, Select, ValueContainer } from "../UI/Select";
const components = {
  Control,
  Menu,
  ValueContainer,
  Option,
};

class ClaimResultProf extends React.Component {
  render() {
    const { classes, dropdowns, claimVo, editable } = this.props;
    return (
      <div class="panel-body">
        {claimVo.claimResult ? (
          <div className={classes.container}>
            <div>
              <InputField
                name="patientCtrlNbr"
                maxLength={20}
                value={claimVo.claimResult.patientCtrlNbr}
                onChange={this.props.handleChange("claimResult")}
                label="Patient Control Nbr"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="formattedTotClmChargeAmt"
                id="claimResult_formattedTotClmChargeAmt"
                value={claimVo.claimResult.formattedTotClmChargeAmt}
                onChange={this.props.handleChange("claimResult")}
                label="Tot Claim Charge Amt"
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            {!editable ?
              (<div>
                <InputField
                  name="processStatus"
                  id="claimResult_processStatus"
                  value={claimVo.claimResult.processStatus}
                  onChange={this.props.handleChange("claimResult")}
                  label="Process Status"
                  disabled={true}
                />
                <div className={classes.validationMessage} />
              </div>) :
              (<div>
                <Select
                  components={components}
                  propertyName={dropdowns.processStatus.filter(
                    (option) => option.value === claimVo.claimResult.processStatus
                  )}
                  options={dropdowns.processStatus}
                  label="Choose Process Status ..."
                  textFieldProps={{
                    id: "processStatus",
                    label: "Process Status",
                    InputLabelProps: {
                      className: classes.label,
                      shrink: true,
                    },
                  }}
                  className={classes.textFieldSelect}
                  handleChange={this.props.handleSelect(
                    "processStatus",
                    "claimResult"
                  )}
                  classes={classes}
                  isDisabled={!editable}
                />
              </div>)}
            <div>
              <InputField
                name="wtxClaimRevNbr"
                onChange={this.props.handleChange("claimResult")}
                label="Claim Rev Nbr"
                value={claimVo.claimResult.wtxClaimRevNbr}
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="wtxClaimRefNbr"
                value={claimVo.claimResult.wtxClaimRefNbr}
                onChange={this.props.handleChange("claimResult")}
                label="Claim Ref Nbr"
                maxLength={20}
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            <div style={{ marginRight: "16px" }}>
              <InputField
                name="custFileName"
                value={claimVo.claimResult.custFileName}
                width="371px"
                onChange={this.props.handleChange("claimResult")}
                label="File Name"
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="formattedPatientPaidAmt"
                value={claimVo.claimResult.formattedPatientPaidAmt}
                onChange={this.props.handleChange("claimResult")}
                label="Patient Paid Amt"
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="contractTypeCd"
                id="contractTypeCd"
                maxLength={2}
                value={claimVo.claimResult.contractTypeCd}
                onChange={this.props.handleChange("claimResult")}
                label="Contract Type Code"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <Select
                components={components}
                propertyName={dropdowns.lstPlaceOfService.filter(
                  (option) =>
                    option.value === claimVo.claimResult.placeOfService
                )}
                options={dropdowns.lstPlaceOfService}
                label="Place of Service ..."
                textFieldProps={{
                  id: "placeOfService",
                  label: "Place of Service",
                  InputLabelProps: {
                    className: classes.label,
                    shrink: true,
                  },
                }}
                className={classes.textFieldSelect}
                handleChange={this.props.handleSelect(
                  "placeOfService",
                  "claimResult"
                )}
                classes={classes}
                isDisabled={!editable}
              />
            </div>
            <div>
              <InputField
                name="contractVersionId"
                id="contractVersionId"
                maxLength={40}
                value={claimVo.claimResult.contractVersionId}
                onChange={this.props.handleChange("claimResult")}
                label="Contract Versn ID"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="formattedContractAmt"
                value={claimVo.claimResult.formattedContractAmt}
                onChange={this.props.handleChange("claimResult")}
                label="Contract Amt"
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="prvAcceptAssignCd"
                maxLength={1}
                value={claimVo.claimResult.prvAcceptAssignCd}
                onChange={this.props.handleChange("claimResult")}
                label="Prv Accept Assgn Cd "
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="clmFreqTypeCd"
                maxLength={1}
                value={claimVo.claimResult.clmFreqTypeCd}
                onChange={this.props.handleChange("claimResult")}
                label="Claim Freq Type Cd"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="contractCd"
                maxLength={15}
                value={claimVo.claimResult.contractCd}
                onChange={this.props.handleChange("claimResult")}
                label="Contract Code"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="formattedContractPct"
                id="formattedContractPct"
                value={claimVo.claimResult.formattedContractPct}
                onChange={this.props.handleChange("claimResult")}
                label="Contract Pct"
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="releaseOfInfoCd"
                maxLength={1}
                value={claimVo.claimResult.releaseOfInfoCd}
                onChange={this.props.handleChange("claimResult")}
                label="Release of Info Code"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="employmentAccidentInd"
                maxLength={2}
                value={claimVo.claimResult.employmentAccidentInd}
                onChange={this.props.handleChange("claimResult")}
                label="Empl Accident Ind"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="formattedTermsDiscountPct"
                value={claimVo.claimResult.formattedTermsDiscountPct}
                onChange={this.props.handleChange("claimResult")}
                label="Terms Discount Pct"
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
            <InputField
                name="autoAccidentState"
                maxLength={2}
                value={claimVo.claimResult.autoAccidentState}
                onChange={this.props.handleChange("claimResult")}
                label="Auto Accident State"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="autoAccidentInd"
                maxLength={2}
                value={claimVo.claimResult.autoAccidentInd}
                onChange={this.props.handleChange("claimResult")}
                label="Auto Accident"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="autoAccidentCountry"
                maxLength={3}
                value={claimVo.claimResult.autoAccidentCountry}
                onChange={this.props.handleChange("claimResult")}
                label="Auto Accident Cntry"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            {/* nhfduedh */}
            <div>
              <InputField
                name="otherAccidentInd"
                maxLength={2}
                id="claimResult_otherAccidentInd"
                value={claimVo.claimResult.otherAccidentInd}
                onChange={this.props.handleChange("claimResult")}
                label="Other Accident Ind"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="svcFacContactName"
                maxLength={60}
                value={claimVo.claimResult.svcFacContactName}
                onChange={this.props.handleChange("claimResult")}
                label="Svc Facility Contact"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="svcFacPhone"
                maxLength={18}
                value={claimVo.claimResult.svcFacPhone}
                onChange={this.props.handleChange("claimResult")}
                label="Svc Facility Phone"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="svcFacPhoneExt"
                maxLength={18}
                value={claimVo.claimResult.svcFacPhoneExt}
                onChange={this.props.handleChange("claimResult")}
                label="Svc Facility Ext"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="svcAuthExcptCd"
                maxLength={1}
                id="claimResult2_svcAuthExcptCd"
                value={claimVo.claimResult.svcAuthExcptCd}
                onChange={this.props.handleChange("claimResult")}
                label="Svc Auth Except Cd"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="claimRefCd"
                maxLength={3}
                value={claimVo.claimResult.claimRefCd}
                onChange={this.props.handleChange("claimResult")}
                label="Claim Ref Cd"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="prvSignatureOnfileInd"
                maxLength={1}
                value={claimVo.claimResult.prvSignatureOnfileInd}
                onChange={this.props.handleChange("claimResult")}
                label="Prv Sign On File"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="epsdtCertCondInd"
                value={claimVo.claimResult.epsdtCertCondInd}
                onChange={this.props.handleChange("claimResult")}
                label="EPSDT Cert Cond Ind"
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="epsdtCondInd1"
                maxLength={2}
                value={claimVo.claimResult.epsdtCondInd1}
                onChange={this.props.handleChange("claimResult")}
                label="EPSDT Condition1"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="epsdtCondInd2"
                maxLength={2}
                value={claimVo.claimResult.epsdtCondInd2}
                onChange={this.props.handleChange("claimResult")}
                label="EPSDT Condition2"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="epsdtCondInd3"
                maxLength={2}
                value={claimVo.claimResult.epsdtCondInd3}
                onChange={this.props.handleChange("claimResult")}
                label="EPSDT Condition3"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="patSignatureSrcCd"
                maxLength={1}
                value={claimVo.claimResult.patSignatureSrcCd}
                onChange={this.props.handleChange("claimResult")}
                label="Pat Sign Src Cd"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="delayReasonCd"
                maxLength={2}
                value={claimVo.claimResult.delayReasonCd}
                onChange={this.props.handleChange("claimResult")}
                label="Delay Reason"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="medicareCrossoverCd"
                maxLength={1}
                value={claimVo.claimResult.medicareCrossoverCd}
                onChange={this.props.handleChange("claimResult")}
                label="Medicare Crsovr Cd"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="beneAssignCertInd"
                maxLength={1}
                value={claimVo.claimResult.beneAssignCertInd}
                onChange={this.props.handleChange("claimResult")}
                label="Bene Assign Cert"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="anestSurgProcCd1"
                maxLength={9}
                value={claimVo.claimResult.anestSurgProcCd1}
                onChange={this.props.handleChange("claimResult")}
                label="Anest Surg Proc Cd1"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="anestSurgProcCd2"
                maxLength={9}
                value={claimVo.claimResult.anestSurgProcCd2}
                onChange={this.props.handleChange("claimResult")}
                label="Anest Surg Proc Cd2"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="labHomeRespCd"
                maxLength={1}
                value={claimVo.claimResult.labHomeRespCd}
                onChange={this.props.handleChange("claimResult")}
                label="Lab Home Resp Code"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="labHomeCondInd"
                maxLength={2}
                value={claimVo.claimResult.labHomeCondInd}
                onChange={this.props.handleChange("claimResult")}
                label="Lab Home Cond Ind"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="visnCodeCategory"
                maxLength={2}
                value={claimVo.claimResult.visnCodeCategory}
                onChange={this.props.handleChange("claimResult")}
                label="Visn Code Cat"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="visnCertCondInd"
                maxLength={1}
                value={claimVo.claimResult.visnCertCondInd}
                onChange={this.props.handleChange("claimResult")}
                label="Visn Cert Cond"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="visnCertCondCd1"
                maxLength={2}
                value={claimVo.claimResult.visnCertCondCd1}
                onChange={this.props.handleChange("claimResult")}
                label="Visn Cert Cond Cd1"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="visnCertCondCd2"
                maxLength={2}
                value={claimVo.claimResult.visnCertCondCd2}
                onChange={this.props.handleChange("claimResult")}
                label="Visn Cert Cond Cd2"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="visnCertCondCd3"
                maxLength={2}
                value={claimVo.claimResult.visnCertCondCd3}
                onChange={this.props.handleChange("claimResult")}
                label="Visn Cert Cond Cd3"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="visnCertCondCd4"
                maxLength={2}
                value={claimVo.claimResult.visnCertCondCd4}
                onChange={this.props.handleChange("claimResult")}
                label="Visn Cert Cond Cd4"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="visnCertCondCd5"
                maxLength={2}
                value={claimVo.claimResult.visnCertCondCd5}
                onChange={this.props.handleChange("claimResult")}
                label="Visn Cert Cond Cd5"
                disabled={!editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="pricingMethodology"
                id="pricingMethodology"
                value={claimVo.claimResult.pricingMethodology}
                onChange={this.props.handleChange("claimResult")}
                label="Pricing Methdlgy"
                disabled={true}
              />
              <div className={classes.validationMessage} />
            </div>
          </div>
        ) : null}
      </div>
    );
  }
}

export default withStyles(Styles)(ClaimResultProf);
