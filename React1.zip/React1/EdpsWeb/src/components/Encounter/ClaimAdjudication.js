import { withStyles } from "@material-ui/core/styles";
import isEmpty from "lodash/isEmpty";
import React from "react";
import { connect } from "react-redux";
import { Styles } from "../../assets/styles/Theme";
import { CLAIM_ADJUDICATION } from "../../constants/header/encounterDetailsHeader";
import { fetchAttachment } from "../../redux/actions/encounterDetailsAction";
import DataTable from "../Home/DataTable";
import InputField from "../UI/InputField";
import ClaimAttachment from "./ClaimAttachment";
import ExpansionPanel from "../UI/ExpansionPanel";

class ClaimAdjudications extends React.Component {
  state = {
    clmAdjudications: [],
    selectedVo:
      this.props.claimAdjData != null
        ? {
          ...(this.props.claimAdjData[0] ? this.props.claimAdjData[0] : null),
        }
        : {},
    clmAdjstmnt: {
      wtxClaimRefNbr: this.props.selectedRow.wtxClaimRefNbr,
      wtxClaimRevNbr: this.props.selectedRow.wtxClaimRevNbr,
      claimSeqNbr: this.props.selectedRow.claimSeqNbr,
      claimType: this.props.selectedRow.claimType,
      claimLineSeqNbr: 0,
      clmliAdjudSeqNbr: 0,
      encType: this.props.selectedRow.encType,
    },
    rowIndex: 0,
    message: "",
    disabled: true,
    closePopup: false,
    rowClick: false,
  };

  static getDerivedStateFromProps(nextProps, prevState) {
    if (!isEmpty(nextProps.claimAdjData)) {
      if (
        prevState.clmAdjudications[prevState.rowIndex] !==
        nextProps.claimAdjData[prevState.rowIndex]
      ) {
        return {
          clmAdjudications: nextProps.claimAdjData,
          selectedVo: nextProps.claimAdjData[prevState.rowIndex],
        };
      }
    }
    return null;
  }

  selectRow = async (index) => {
    const selectedVo = this.state.clmAdjudications[index];
    await this.setState((prevState) => ({
      clmAdjstmnt: {
        ...prevState.clmAdjstmnt,
        claimLineSeqNbr: this.props.claimAdjData[index].claimLineSeqNbr,
        clmliAdjudSeqNbr: this.props.claimAdjData[index].clmliAdjudSeqNbr,
      },
      selectedVo: selectedVo,
      rowIndex: index,
    }));
    this.props.fetchAttachment(this.state.clmAdjstmnt, this.state.rowIndex);
  };

  render() {
    const { classes, claimAdjData, editable, dataTableVo } = this.props;
    const { selectedVo } = this.state;
    return (
      <React.Fragment>
        <div>
          <DataTable
            data={dataTableVo ? dataTableVo : []}
            header={CLAIM_ADJUDICATION}
            rowsPerPage={5}
            sortable={true}
            clicked={this.selectRow}
          />
        </div>
        {!isEmpty(claimAdjData) ? (
          <div>
            <ExpansionPanel summary="Claim - Line - Adjudication - Detail">
              <div id="claimAdjudicationDetail"></div>
              <div class="panel-body">
                <div className={classes.container}>
                  <div>
                    <InputField
                      name="othPayrPrimaryId"
                      label="Other Payer ID"
                      disabled={!editable}
                      value={selectedVo.othPayrPrimaryId}
                      onChange={this.props.handleChange(
                        "claimLineAdjudications",
                        this.state.rowIndex
                      )}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="clmliAdjudRevenueCd"
                      label="Revenue Code"
                      disabled={!editable}
                      maxLength={4}
                      value={selectedVo.clmliAdjudRevenueCd}
                      onChange={this.props.handleChange(
                        "claimLineAdjudications",
                        this.state.rowIndex
                      )}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="formattedClmliPaidAmt"
                      label="Paid Amt"
                      disabled={true}
                      value={selectedVo.formattedClmliPaidAmt}
                      onChange={this.props.handleChange(
                        "claimLineAdjudications",
                        this.state.rowIndex
                      )}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="prodSvcidQual"
                      id="claimLineAdjudications_prodOrSvcidQual"
                      label="Prod or Svc ID Qual"
                      disabled={!editable}
                      maxLength={2}
                      value={selectedVo.prodSvcidQual}
                      onChange={this.props.handleChange(
                        "claimLineAdjudications",
                        this.state.rowIndex
                      )}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="formattedClmliPaidSvcUnitCnt"
                      id="claimLineAdjudications1_formattedClmliPaidSvcUnitCnt"
                      label="Paid Svc Unit Count"
                      disabled={!editable}
                      maxLength={2}
                      value={selectedVo.formattedClmliPaidSvcUnitCnt}
                      onChange={this.props.handleChange(
                        "claimLineAdjudications",
                        this.state.rowIndex
                      )}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="clmliBundledLineNbr"
                      label="Bundled Line Nbr"
                      disabled={!editable}
                      maxLength={4}
                      value={selectedVo.clmliBundledLineNbr}
                      onChange={this.props.handleChange(
                        "claimLineAdjudications",
                        this.state.rowIndex
                      )}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="formattedAdjudPaymentDt"
                      label="Payment Date"
                      disabled={!editable}
                      value={selectedVo.formattedAdjudPaymentDt}
                      onClick={this.props.handleDates(
                        "#formattedAdjudPaymentDt",
                        "claimLineAdjudications",
                        this.state.rowIndex
                      )}
                      onChange={this.props.handleChange(
                        "claimLineAdjudications",
                        this.state.rowIndex
                      )}
                    />
                    <div className={classes.validationMessage}>
                      {this.props.validator.message(
                        "paymentDate",
                        selectedVo.formattedAdjudPaymentDt,
                        "date_format"
                      )}
                    </div>
                  </div>
                  <div>
                    <InputField
                      name="remainPatientLiab"
                      label="Remain Patient Liab"
                      disabled={true}
                      value={selectedVo.remainPatientLiab}
                      onChange={this.props.handleChange(
                        "claimLineAdjudications",
                        this.state.rowIndex
                      )}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                </div>
                <div className={classes.container}>
                  <div>
                    <InputField
                      name="clmliAdjudProcCd"
                      label="Procedure Code"
                      maxLength={7}
                      disabled={!editable}
                      value={selectedVo.clmliAdjudProcCd}
                      onChange={this.props.handleChange(
                        "claimLineAdjudications",
                        this.state.rowIndex
                      )}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div />
                  <div>
                    <InputField
                      name="clmliAdjudProcMod1"
                      label="Procedure Mod1"
                      disabled={!editable}
                      maxLength={2}
                      value={selectedVo.clmliAdjudProcMod1}
                      onChange={this.props.handleChange(
                        "claimLineAdjudications",
                        this.state.rowIndex
                      )}
                    />
                    <div className={classes.validationMessage}></div>
                  </div>
                  <div>
                    <InputField
                      name="clmliAdjudProcMod2"
                      label="Procedure Mod2"
                      disabled={!editable}
                      maxLength={2}
                      value={selectedVo.clmliAdjudProcMod2}
                      onChange={this.props.handleChange(
                        "claimLineAdjudications",
                        this.state.rowIndex
                      )}
                    />
                    <div className={classes.validationMessageSelect}></div>
                  </div>
                  <div>
                    <InputField
                      name="clmliAdjudProcMod3"
                      label="Procedure Mod3"
                      disabled={!editable}
                      maxLength={2}
                      value={selectedVo.clmliAdjudProcMod3}
                      onChange={this.props.handleChange(
                        "claimLineAdjudications",
                        this.state.rowIndex
                      )}
                    />
                    <div className={classes.validationMessageSelect}></div>
                  </div>
                  <div>
                    <InputField
                      name="clmliAdjudProcMod4"
                      label="Procedure Mod4"
                      disabled={!editable}
                      maxLength={2}
                      value={selectedVo.clmliAdjudProcMod4}
                      onChange={this.props.handleChange(
                        "claimLineAdjudications",
                        this.state.rowIndex
                      )}
                    />
                    <div className={classes.validationMessageSelect}></div>
                  </div>
                  <div>
                    <InputField
                      name="clmliAdjudProcDesc"
                      label="Procedure Descr"
                      disabled={!editable}
                      maxLength={80}
                      value={selectedVo.clmliAdjudProcDesc}
                      onChange={this.props.handleChange(
                        "claimLineAdjudications",
                        this.state.rowIndex
                      )}
                    />
                    <div className={classes.validationMessageSelect}></div>
                  </div>
                </div>
              </div>
            </ExpansionPanel>
          </div>
        ) : null}
        <ClaimAttachment
          selectedRow={this.props.selectedRow}
          rowIndex={this.state.rowIndex}
          editable={this.props.editable}
        />
      </React.Fragment>
    );
  }
}


const mapStateToProps = (state) => {
  return {
    dataTableVo: state.ClaimCodeReducer.claimVo.claimLineAdjudications
  };
};

const mapDispatchToProps = {
  fetchAttachment,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(ClaimAdjudications));

