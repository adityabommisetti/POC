import Button from "@material-ui/core/Button";
import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormLabel from "@material-ui/core/FormLabel";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import { withStyles } from "@material-ui/core/styles";
import TextField from "@material-ui/core/TextField";
import RadioButtonCheckedIcon from '@material-ui/icons/RadioButtonChecked';
import RadioButtonUncheckedIcon from '@material-ui/icons/RadioButtonUnchecked';
import isEmpty from "lodash/isEmpty";
import React, { Component } from "react";
import { connect } from "react-redux";
import { withRouter } from 'react-router';
import { compose } from 'redux';
import { Styles } from "../../assets/styles/Theme";
import Modal from "../../components/UI/Modal/Modal";
import { ACCEPTED_COUNT, FILE_DASHBOARD_EXPORT, MONTHLY_FILE, REJECTED_COUNT } from "../../constants/header/encounterDetailsHeader";
import { dailyDetails, fileDashboardDetails, monthlyDetails, retreiveFile, updateFile } from "../../redux/actions/FileTransferAction";
import * as DateUtil from "../../utils/DatePicker";
import DataTable from "../Home/DataTable";
import FileTable from "../Home/FileTable";
import ExpansionPanel from "../UI/ExpansionPanel";
import InputField from "../UI/InputField";
import SearchBtnPanel from "../UI/SearchBtnPanel";
import { components, Select } from "../UI/Select";
import Datetime from "react-datetime";
import SimpleReactValidator from "simple-react-validator";
import { customValidations } from "../../utils/CustomValidations";

const INITIAL_DATA = {
  submitterId: "",
  encType: "",
  typeOfBusiness: "EN",
  searchValue: "",
  searchType: "",
  claimNumber: "",
  claimType: "",
  fromDateYrmo: ("01/").concat(new Date().getFullYear()),
  toDateYrmo: ("12/").concat(new Date().getFullYear()),
};

class FileDashboard extends Component {
  constructor(props) {
    super(props);
    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format_month_year,
        date_after_month_year: customValidations.date_after_month_year
      },
    });
    this.state = {
      closePopup: false,
      dashBoardList: [],
      searchVo: { ...INITIAL_DATA },
      monthlyVo: {
        submitterId: "",
        encType: "",
        dateYrMo: "",
        intrRecId: "",
        splitFileStatus: "",
        typeOfBusiness: "",
      },
      fileDashboard: null,
      monthlyData: [],
      dailyData: [],
      commentVo: {
        submitterId: "",
        fileId: "",
        notes: ""
      },
      criteriaFlag: true,
      monthlyFlag: false,
      dailyFlag: false,
      showModal: false,
      message: "",
    };
  }


  async componentDidMount() {
    if (!isEmpty(this.props.dropdowns)) {
      await this.setState(prevState => ({
        searchVo: {
          ...prevState.searchVo,
          "submitterId": !isEmpty(this.props.dropdowns.optionsSubmitters) ?
            this.props.dropdowns.optionsSubmitters[0].value : "",
        }
      }));
      await this.props.fileDashboardDetails(this.state.searchVo);
        this.dailyFileHeaderUpdate("dailyFile");
        this.setState({
          fileDashboard: [...this.props.fileDashboard],
          criteriaFlag: true,
          monthlyFlag: false,
          dailyFlag: false
        })
    }
  }


  async UNSAFE_componentWillReceiveProps(nextProps) {
    if ((!isEmpty(nextProps.dropdowns)
      && this.state.searchVo.submitterId === "")
      && isEmpty(this.props.fileDashboard)) {
      if (nextProps.dropdowns.optionsSubmitters[0].value !== this.state.searchVo.submitterId) {
        await this.setState(prevState => ({
          searchVo: {
            ...prevState.searchVo,
            "submitterId": !isEmpty(nextProps.dropdowns.optionsSubmitters) ?
              nextProps.dropdowns.optionsSubmitters[0].value : "",
          }
        }));
        await this.props.fileDashboardDetails(this.state.searchVo);
        this.dailyFileHeaderUpdate("dailyFile");
        this.setState({
          fileDashboard: [...this.props.fileDashboard],
          criteriaFlag: true,
          monthlyFlag: false,
          dailyFlag: false
        })
      }
    }
  }

  handleSearchFieldChange = name => event => {
    let value = event.target
      ? event.target.value.toUpperCase()
      : event.value.toUpperCase();
    this.setState(prevState => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value
      },
      collapseSearch: false
    }));
  };

  handleComment = name => event => {
    let value = event.target.value.toUpperCase();
    this.setState(prevState => ({
      commentVo: {
        ...prevState.commentVo,
        [name]: value
      }
    }));
  }

  handleDates = fieldId => {
    var self = this;
    DateUtil.getMonthDatePicker(fieldId).on("change", e => {
      self.setDate(e.target.name, e.target.value);
    });
  };

  setDate = (name, value) => {
    this.setState(prevState => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value
      }
    }));
  };

  monthPicker = (selectedDate, field) => {
    if (selectedDate._d) {
      var date = new Date(selectedDate._d),
        mnth = ("0" + (date.getMonth() + 1)).slice(-2),
        selectedDate = [mnth, date.getFullYear()].join("/");
    } else {
      selectedDate = selectedDate.replace(/[^0-9]/g, "").trim();
      selectedDate = selectedDate.replace(/^(\d{2})/, "$1/");
      selectedDate = selectedDate.replace(/(\d)\/(\d{4}).*/, "$1/$2");
    }
    this.setState({
      ...this.state,
      searchVo: { ...this.state.searchVo, [field]: selectedDate },
    });
  };

  dailyFileHeaderUpdate = (data) => {
    if (!isEmpty(this.props[data]) &&
      ACCEPTED_COUNT[0].key !== "custFileName" &&
      REJECTED_COUNT[0].key !== "custFileName") {
      ACCEPTED_COUNT.splice(0, 0, {
        label: this.props[data][0].submissionDate,
        title: this.props[data][0].submissionDate,
        key: "custFileName"
      });
      REJECTED_COUNT.splice(0, 0, {
        label: this.props[data][0].submissionDate,
        title: this.props[data][0].submissionDate,
        key: "custFileName"
      })
    }
  }

  dashBoardSearch = async () => {
    const { searchVo } = this.state;
    if (!this.validator.allValid()) {
      this.validator.showMessages();
      this.forceUpdate();
    }
    else {
      if (searchVo.searchType === "" && searchVo.searchValue !== "") {
        alert("Please select either File Name or File ID");
      }
      else if (searchVo.searchType !== "" && searchVo.encType !== "") {
        alert("Select either FileName/File ID or Claim type. Both can't be selected");
      }
      else if (searchVo.searchType !== "" && searchVo.claimNumber !== "") {
        alert("Select either FileName/File ID or Claim Number. Both can't be selected")
      }
      else if (searchVo.searchType !== "" && searchVo.searchValue === "") {
        alert("File ID cannot be empty");
      }
      else if (searchVo.encType !== "" && searchVo.claimNumber === "") {
        alert("Claim Number cannot be empty")
      }
      else if (searchVo.searchType !== "" && searchVo.searchValue !== "") {
        await this.props.fileDashboardDetails(this.state.searchVo);
        this.dailyFileHeaderUpdate("fileDashboard");
        this.setState({
          dailyData: [...this.props.fileDashboard],
          criteriaFlag: false,
          monthlyFlag: false,
          dailyFlag: true
        })
      }
      else {
        await this.props.fileDashboardDetails(this.state.searchVo);
        this.dailyFileHeaderUpdate("dailyFile");
        this.setState({
          fileDashboard: [...this.props.fileDashboard],
          criteriaFlag: true,
          monthlyFlag: false,
          dailyFlag: false
        })
      }
    }
  };

  reset = () => {
    INITIAL_DATA.submitterId = !isEmpty(this.props.dropdowns.optionsSubmitters) ?
      this.props.dropdowns.optionsSubmitters[0].value : ""
    this.setState({ searchVo: { ...INITIAL_DATA } });
  };

  handleRecordSelect = async (dataObj) => {
    const { searchVo } = this.state;
    window.scrollTo(0,2000);
    await this.setState(prevState => ({
      monthlyVo: {
        ...prevState.monthlyVo,
        submitterId: searchVo.submitterId,
        encType: dataObj.encType,
        dateYrMo: dataObj.dateYRMO,
        intrRecId: dataObj.intrRecId,
        splitFileStatus: dataObj.splitFileStatus,
        typeOfBusiness: searchVo.typeOfBusiness,
      }
    }));
    await this.props.monthlyDetails(this.state.monthlyVo);
    if (!isEmpty(this.props.monthlyData) && MONTHLY_FILE[0].key !== "monDay") {
      MONTHLY_FILE.splice(0, 0, {
        label: this.props.monthlyData[0].monYear,
        title: this.props.monthlyData[0].monYear,
        key: "monDay"
      })
    }
    this.setState({
      monthlyData: this.props.monthlyData,
      monthlyFlag: true
    })
  };

  monthRowSelect = async (index) => {
    const data = [...this.props.monthlyData];
    const selectedVo = data[index];
    await this.props.dailyDetails(selectedVo);
    this.dailyFileHeaderUpdate("dailyFile");
    await this.setState({
      dailyData: [...this.props.dailyFile],
      dailyFlag: true
    })
  };

  dayRowSelect = async (index) => {
    const data = [...this.state.dailyData];
    const selectedVo = data[index];
    selectedVo.fileTrackFlag = true;
    if (selectedVo && selectedVo.claimType === "EN") {
      this.props.history.push({
        pathname: '/encounter',
        state: selectedVo
      })
    } else {
      this.props.history.push({
        pathname: '/chart',
        state: selectedVo
      })
    }
  };

  updateNote = async () => {
    const saveStatus = await this.props.updateFile(this.state.commentVo);
    if (saveStatus.status === "200") {
      this.setState(prevState => ({
        commentVo: {
          ...prevState.commentVo,
          notes: ""
        },
        closePopup: true,
        message: ("Updated the Customer Remarks for the file Id:").concat(this.state.commentVo.fileId),
      }));
    }
    else {
      this.setState({
        closePopup: true,
        message: saveStatus.message
      });
    }
  };

  retrieveNote = async () => {
    const notes = await this.props.retreiveFile(this.state.commentVo);
    this.setState(prevState => ({
      commentVo: {
        ...prevState.commentVo,
        notes: notes
      },
      closePopup: true,
      message: ("Retrieved the Customer Remarks for the file Id:").concat(this.state.commentVo.fileId),
    }));
  };

  modalClosed = () => {
    this.setState({ closePopup: false })
  }

  render() {
    const { classes, dropdowns } = this.props;
    const { closePopup, message } = this.state;
    return (
      <React.Fragment>
        <Modal dialogTitle='File Update'
          message={message}
          show={closePopup}
          modalClosed={this.modalClosed}>
        </Modal>
        {Object.entries(this.props.dropdowns).length !== 0 ?
          <ExpansionPanel
            summary="File Dashboard"
            defaultCollapsed={this.state.collapseSearch}
          >
            <div className={classes.container} id="SearchPanel">
              <div>
                <Select
                  components={components}
                  propertyName={dropdowns.optionsSubmitters.filter(
                    option =>
                      option.value === this.state.searchVo.submitterId
                  )}
                  options={dropdowns.optionsSubmitters}
                  label="Choose Submitter ID ..."
                  textFieldProps={{
                    id: "submitterId",
                    label: "Submitter ID",
                    InputLabelProps: {
                      className: classes.label,
                      shrink: true
                    }
                  }}
                  className={classes.textFieldSearch}
                  handleChange={this.handleSearchFieldChange("submitterId")}
                  classes={classes}
                />
              </div>

              <div>
                <label>Submission Date From</label>
                <Datetime
                  onChange={(moment) => this.monthPicker(moment, "fromDateYrmo")}
                  value={this.state.searchVo.fromDateYrmo}
                  dateFormat="MM/YYYY"
                  closeOnSelect="true"
                  inputProps={{
                    placeholder: "MM/YYYY",
                    className: "monthPicker",
                    maxLength: 7,
                  }}
                  timeFormat={false}
                />
                <div className={classes.validationMessage}>
                  {this.validator.message(
                    "FromDate",
                    this.state.searchVo.fromDateYrmo,
                    "required|date_format"
                  )}
                </div>
              </div>
              <div>
                <label>Submission Date To</label>
                <Datetime
                  onChange={(moment) => this.monthPicker(moment, "toDateYrmo")}
                  value={this.state.searchVo.toDateYrmo}
                  dateFormat="MM/YYYY"
                  closeOnSelect="true"
                  inputProps={{
                    placeholder: "MM/YYYY",
                    className: "monthPicker",
                    maxLength: 7,
                  }}
                  timeFormat={false}
                />
                <div className={classes.validationMessage}>
                  {this.validator.message(
                    "ToDate",
                    this.state.searchVo.toDateYrmo,
                    [
                      "required",
                      "date_format",
                      { date_after_month_year: this.state.searchVo.fromDateYrmo },
                    ]
                  )}
                </div>
              </div>

              {/* <div>
                <InputField
                  name="fromDateYrmo"
                  placeholder="MM/YYYY"
                  label="Submission Date From"
                  id="fromDateYrmo"
                  value={this.state.searchVo.fromDateYrmo}
                  onClick={this.handleDates("#fromDateYrmo")}
                  maxLength={7}
                  onChange={this.handleSearchFieldChange("fromDateYrmo")}
                  required
                />
                <div className={classes.validationMessage} />
              </div>
              <div>
                <InputField
                  name="toDateYrmo"
                  placeholder="MM/YYYY"
                  label="Submission Date To"
                  id="toDateYrmo"
                  value={this.state.searchVo.toDateYrmo}
                  onClick={this.handleDates("#toDateYrmo")}
                  maxLength={7}
                  onChange={this.handleSearchFieldChange("toDateYrmo")}
                  required
                />
                <div className={classes.validationMessage} />
              </div> */}
              <div style={{ marginRight: "-90px" }}>
                <FormControl
                  component="fieldset"
                  className={classes.formControl}
                >
                  <FormLabel component="legend" className={classes.legend}></FormLabel>
                  <RadioGroup
                    name="searchType"
                    className={classes.group}
                    value={this.state.searchVo.searchType}
                    onChange={this.handleSearchFieldChange("searchType")}
                  >
                    <FormControlLabel value="FILENAME" control={<Radio color="primary"
                      icon={<RadioButtonUncheckedIcon fontSize="small" />}
                      checkedIcon={<RadioButtonCheckedIcon fontSize="small" />}
                    />} label="File Name" />
                    <FormControlLabel value="FILEID" control={<Radio color="primary"
                      icon={<RadioButtonUncheckedIcon fontSize="small" />}
                      checkedIcon={<RadioButtonCheckedIcon fontSize="small" />}
                    />} label="File ID" />
                  </RadioGroup>
                </FormControl>
              </div>
              <div>
                <InputField
                  name="searchValue"
                  value={this.state.searchVo.searchValue}
                  onChange={this.handleSearchFieldChange("searchValue")}
                  maxLength={12}
                />
                <div className={classes.validationMessage} />
              </div>
              <div>
                <Select
                  components={components}
                  propertyName={dropdowns.lstTypeOfBussines.filter(
                    option =>
                      option.value === this.state.searchVo.typeOfBusiness
                  )}
                  options={dropdowns.lstTypeOfBussines}
                  label="Choose Type of Business"
                  textFieldProps={{
                    id: "typeOfBusiness",
                    label: "Type of Business",
                    InputLabelProps: {
                      className: classes.label,
                      shrink: true
                    }
                  }}
                  className={classes.textFieldSearch}
                  handleChange={this.handleSearchFieldChange("typeOfBusiness")}
                  classes={classes}
                />
              </div>
              <div>
                <Select
                  components={components}
                  propertyName={dropdowns.optionsEncType.filter(
                    option =>
                      option.value === this.state.searchVo.encType
                  )}
                  options={dropdowns.optionsEncType}
                  label="Choose Claim Type"
                  textFieldProps={{
                    id: "encType",
                    label: "Claim Type",
                    InputLabelProps: {
                      className: classes.label,
                      shrink: true
                    }
                  }}
                  className={classes.textFieldSearch}
                  handleChange={this.handleSearchFieldChange("encType")}
                  classes={classes}
                />
              </div>
              <div>
                <InputField
                  name="claimNumber"
                  label="Claim Nbr"
                  value={this.state.searchVo.claimNumber}
                  onChange={this.handleSearchFieldChange("claimNumber")}
                  maxLength={20}
                />
                <div className={classes.validationMessage} />
              </div>
              <SearchBtnPanel
                search={this.dashBoardSearch}
                reset={this.reset}
              />
            </div>
          </ExpansionPanel> : null}
        {this.state.criteriaFlag && this.state.fileDashboard ?
          <ExpansionPanel summary="File Dashboard" >
            <FileTable
              data={this.state.fileDashboard}
              submitterId={this.state.searchVo.submitterId}
              handleRecordSelect={this.handleRecordSelect}
              rowsPerPage={5}
            />
          </ExpansionPanel>
          : null}
        {this.state.monthlyFlag ?
          <div id="monthEnc" >
            <ExpansionPanel summary="Monthly Encounter Details" >
              <DataTable
                data={this.state.monthlyData}
                header={MONTHLY_FILE}
                rowsPerPage={3}
                sortableHeader={true}
                clicked={this.monthRowSelect}
              />
            </ExpansionPanel>
          </div> : null}
        {this.state.dailyFlag ?
          <React.Fragment>
            <div id="dailyEnc" >
              <ExpansionPanel summary="Daily File Processing">
                <div className={classes.applicationTableHeading}>
                  <span>Accepted Count</span>
                </div>
                <DataTable
                  data={this.state.dailyData}
                  header={ACCEPTED_COUNT}
                  rowsPerPage={5}
                  sortableHeader={true}
                  clicked={this.dayRowSelect}
                  exportAsExcel={true}
                  exportHeader={FILE_DASHBOARD_EXPORT}
                />
                <br />
                <div className={classes.applicationTableHeading}>
                  <span>Rejected Count</span>
                </div>
                <DataTable
                  data={this.state.dailyData}
                  header={REJECTED_COUNT}
                  rowsPerPage={5}
                  sortableHeader={true}
                  clicked={this.dayRowSelect}
                />
              </ExpansionPanel>
            </div>
            <div>
              <InputField
                name="fileId"
                label="File Id"
                value={this.state.commentVo.fileId}
                maxLength={12}
                onChange={this.handleComment("fileId")}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <TextField
                id="outlined-textarea"
                label="Notes"
                autoFocus
                multiline
                rows="2"
                style={{
                  width: "85%",
                  height: "75px",
                  marginBottom: "40px",
                  marginLeft: "0px",
                  backgroundColor: "#FFFFFF"
                }}
                className={classes.textField}
                inputProps={{ maxLength: 255 }}
                onChange={this.handleComment("notes")}
                value={this.state.commentVo.notes}
                margin="none"
                variant="outlined"
              />
              <div className={classes.commentsValidationMessage} />
            </div>

            <div className={this.props.classes.buttonContainer}>
              <Button
                variant="contained"
                color="primary"
                onClick={this.updateNote}
                className={this.props.classes.button}
                id="updateNote"
              >
                Update Note
              </Button>
              <Button
                variant="contained"
                color="primary"
                onClick={this.retrieveNote}
                className={this.props.classes.button}
                id="retrieveNote"
              >
                Retrieve Note
              </Button>
            </div>

          </React.Fragment>
          : null}
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  return {
    fileDashboard: state.FileReducer.fileDashboard,
    monthlyData: state.FileReducer.monthlyData,
    dailyFile: state.FileReducer.dailyData,
    isLoading: state.spinner.isLoading,
    dropdowns: state.dropdowns,
  };
};

const mapDispatchToProps = {
  fileDashboardDetails,
  monthlyDetails,
  dailyDetails,
  updateFile,
  retreiveFile
};

export default compose(
  withRouter,
  withStyles(Styles),
  connect(mapStateToProps, mapDispatchToProps)
)(FileDashboard)

