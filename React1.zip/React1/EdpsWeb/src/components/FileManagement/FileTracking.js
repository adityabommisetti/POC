import Button from "@material-ui/core/Button";
import MuiExpansionPanelDetails from "@material-ui/core/ExpansionPanelDetails";
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import { withStyles } from "@material-ui/core/styles";
import Tooltip from "@material-ui/core/Tooltip";
import classNames from "classnames";
import isEmpty from "lodash/isEmpty";
import { Component, default as React } from 'react';
import { CSVLink } from "react-csv";
import { connect } from "react-redux";
import { Styles } from "../../assets/styles/Theme";
import { FILE_TRACKING } from "../../constants/header/encounterDetailsHeader";
import { fileTracking } from "../../redux/actions/FileTransferAction";
import * as DateUtil from "../../utils/DatePicker";
import { exportToText } from "../Home/ExportFunction";
import ExportExcel from '../../utils/ExportExcelComponent';
import ExpansionPanel from "../UI/ExpansionPanel";
import InputField from "../UI/InputField";
import { components, Select } from "../UI/Select";
import Datetime from "react-datetime";

const INITIAL_DATA = {
    submitterId: "",
    fileName: "",
    fromDate: ("01/").concat(new Date().getFullYear()),
    toDate: ("12/").concat(new Date().getFullYear()),
    typeOfBusiness: "EN"
}

const ExpansionPanelDetails = withStyles(theme => ({
    root: {
        height: "180px"
    }
}))(MuiExpansionPanelDetails);

class FileExport extends Component {
    constructor(props) {
        super(props);
        this.state = {
            searchVo: { ...INITIAL_DATA },
            mobileMoreAnchorEl: null,
            exportAsExcel: false,
            anchorEl: null,
            exportData: '',
            radio: 'current',
        };
    }

    async componentDidMount() {
        if (!isEmpty(this.props.dropdowns)) {
            await this.setState(prevState => ({
                searchVo: {
                    ...prevState.searchVo,
                    "submitterId": !isEmpty(this.props.dropdowns.optionsSubmitters) ?
                        this.props.dropdowns.optionsSubmitters[0].value : "",
                }
            }));
        }
    }


    async UNSAFE_componentWillReceiveProps(nextProps) {
        if ((!isEmpty(nextProps.dropdowns)
            && this.state.searchVo.submitterId === "")) {
            if (nextProps.dropdowns.optionsSubmitters[0].value !== this.state.searchVo.submitterId) {
                await this.setState(prevState => ({
                    searchVo: {
                        ...prevState.searchVo,
                        "submitterId": !isEmpty(nextProps.dropdowns.optionsSubmitters) ?
                            nextProps.dropdowns.optionsSubmitters[0].value : ""
                    }
                }));
            }
        }
    }

    monthPicker = (selectedDate, field) => {
        if (selectedDate._d) {
            var date = new Date(selectedDate._d),
                mnth = ("0" + (date.getMonth() + 1)).slice(-2),
                selectedDate = [mnth, date.getFullYear()].join("/");
        } else {
            selectedDate = selectedDate.replace(/[^0-9]/g, "").trim();
            selectedDate = selectedDate.replace(/^(\d{2})/, "$1/");
            selectedDate = selectedDate.replace(/(\d)\/(\d{4}).*/, "$1/$2");
        }
        this.setState({
            ...this.state,
            searchVo: { ...this.state.searchVo, [field]: selectedDate },
        });
    };

    handleDates = fieldId => {
        var self = this;
        DateUtil.getMonthDatePicker(fieldId).on("change", e => {
            self.setDate(e.target.name, e.target.value);
        });
    };

    setDate = (name, value) => {
        this.setState(prevState => ({
            searchVo: {
                ...prevState.searchVo,
                [name]: value
            }
        }));
    };

    handleSearchFieldChange = name => event => {
        let value = event.target
            ? event.target.value.toUpperCase()
            : event.value.toUpperCase();
        this.setState(prevState => ({
            searchVo: {
                ...prevState.searchVo,
                [name]: value
            }
        }));
    };

    export = (e) => {
        this.exportDataFunc(this.props.fileTrack, false);
        this.handleMobileMenuOpen(e);
        this.props.fileTracking(this.state.searchVo);
    };

    generate = (data, header) => {
        var jsPDF = require('jspdf');
        require('jspdf-autotable');
        var doc = new jsPDF();
        doc.autoTable(header, data);
        doc.save("EDPS.pdf");
    }

    exportDataFunc = (data, all) => {
        const exportdata = this.props.fileTrack.slice();
        const searchdata = this.props.fileTrack.slice();

        if (all) {
            this.setState({
                exportData: exportdata,
                radio: 'all'
            })
        } else {
            this.setState({
                exportData: searchdata,
                radio: 'current'
            })
        }
    }

    handleMobileMenuOpen = event => {
        this.setState({ mobileMoreAnchorEl: event.currentTarget });
    };

    handleMenuClose = () => {
        this.setState({ anchorEl: null });
        this.handleMobileMenuClose();
    };

    handleMobileMenuClose = () => {
        this.setState({ mobileMoreAnchorEl: null });
    };

    render() {
        const { classes, dropdowns, fileTrack } = this.props;
        const { searchVo, mobileMoreAnchorEl } = this.state;
        const isMobileMenuOpen = Boolean(mobileMoreAnchorEl);
        return (
            <React.Fragment>
                {!isEmpty(dropdowns) ?
                    <ExpansionPanel
                        summary="Response File tracking"
                        defaultCollapsed={this.state.collapseSearch}
                    >
                        <ExpansionPanelDetails>
                            <div className={classes.container} id="SearchPanel">
                                <div>
                                    <Select
                                        components={components}
                                        propertyName={dropdowns.optionsSubmitters.filter(
                                            option =>
                                                option.value === searchVo.submitterId
                                        )}
                                        options={dropdowns.optionsSubmitters}
                                        label="Choose Submitter ID ..."
                                        textFieldProps={{
                                            id: "submitterId",
                                            label: "Submitter ID",
                                            InputLabelProps: {
                                                className: classes.label,
                                                shrink: true
                                            }
                                        }}
                                        className={classes.textFieldSearch}
                                        handleChange={this.handleSearchFieldChange("submitterId")}
                                        classes={classes}
                                    />
                                </div>
                                <div>
                                    <label>Submission Date From</label>
                                    <Datetime
                                        onChange={(moment) => this.monthPicker(moment, "fromDate")}
                                        value={searchVo.fromDate}
                                        dateFormat="MM/YYYY"
                                        closeOnSelect="true"
                                        inputProps={{
                                            placeholder: "MM/YYYY",
                                            className: "monthPicker",
                                            maxLength: 7,
                                        }}
                                        timeFormat={false}
                                    />
                                    <div className={classes.validationMessage} />
                                </div>
                                <div>
                                    <label>Submission Date To</label>
                                    <Datetime
                                        onChange={(moment) => this.monthPicker(moment, "toDate")}
                                        value={searchVo.toDate}
                                        dateFormat="MM/YYYY"
                                        closeOnSelect="true"
                                        inputProps={{
                                            placeholder: "MM/YYYY",
                                            className: "monthPicker",
                                            maxLength: 7,
                                        }}
                                        timeFormat={false}
                                    />
                                    <div className={classes.validationMessage} />
                                </div>

                                {/* <div>
                                <InputField
                                    name="fromDate"
                                    placeholder="MM/YYYY"
                                    label="Submission Date From"
                                    value={searchVo.fromDate}
                                    onClick={this.handleDates("#fromDate")}
                                    maxLength={7}
                                    onChange={this.handleSearchFieldChange("fromDate")}
                                    required
                                />

                                <div className={classes.validationMessage} />
                            </div>
                            <div>
                                <InputField
                                    name="toDate"
                                    placeholder="MM/YYYY"
                                    label="Submission Date To"
                                    value={searchVo.toDate}
                                    onClick={this.handleDates("#toDate")}
                                    maxLength={7}
                                    onChange={this.handleSearchFieldChange("toDate")}
                                    required
                                />

                                <div className={classes.validationMessage} />
                            </div> */}
                                <div>
                                    <InputField
                                        name="fileName"
                                        value={searchVo.fileName}
                                        label="File Name"
                                        onChange={this.handleSearchFieldChange("fileName")}
                                    />
                                    <div className={classes.validationMessage} />
                                </div>
                                <div>
                                    <Select
                                        components={components}
                                        propertyName={dropdowns.lstTypeOfBussines.filter(
                                            option =>
                                                option.value === this.state.searchVo.typeOfBusiness
                                        )}
                                        options={dropdowns.lstTypeOfBussines}
                                        label="Choose Type of Business"
                                        textFieldProps={{
                                            id: "typeOfBusiness",
                                            label: "Type of Business",
                                            InputLabelProps: {
                                                className: classes.label,
                                                shrink: true
                                            }
                                        }}
                                        className={classes.textFieldSearch}
                                        handleChange={this.handleSearchFieldChange("typeOfBusiness")}
                                        classes={classes}
                                    />
                                </div>
                                <Button
                                    variant="contained"
                                    color="primary"
                                    onClick={this.export}
                                    className={this.props.classes.button}
                                    id="exportBtn"
                                >
                                    Export
                            </Button>
                            </div>
                            <div className={classes.exportDisplay}>
                                <Menu
                                    classes={{
                                        paper: classes.placing,
                                    }}
                                    anchorEl={mobileMoreAnchorEl}
                                    anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
                                    transformOrigin={{ vertical: 'top', horizontal: 'right' }}
                                    open={isMobileMenuOpen}
                                    onClose={this.handleMenuClose}
                                >
                                    <MenuItem>
                                        <RadioGroup
                                            row
                                            value={this.state.radio}
                                        >
                                            <FormControlLabel value="current" control={<Radio />} label="Current" onClick={() => this.exportDataFunc(fileTrack, false)} />
                                            <FormControlLabel value="all" control={<Radio />} label="All" onClick={() => this.exportDataFunc(fileTrack, true)} />
                                        </RadioGroup>
                                    </MenuItem>
                                    <MenuItem className={classes.exportDemo}>
                                    <ExportExcel fileName='FileTrack' dataSet={fileTrack} colName={FILE_TRACKING} classes={classes} />        
                                        <CSVLink data={fileTrack} headers={FILE_TRACKING} separator={","} filename={"FileTrack.txt"}>
                                        <i className={classNames("fa fa-file-text", classes.pdfIcon)} ></i>
                                        </CSVLink>
                                        {/* <Tooltip title="Text">
                                            <i className={classNames("fa fa-file-text", classes.textIcon)} onClick={exportToText} style={{}}></i>
                                        </Tooltip> */}
                                    </MenuItem>
                                </Menu>
                            </div>
                        </ExpansionPanelDetails>
                    </ExpansionPanel> : null}
            </React.Fragment>
        )
    }
}
const mapStateToProps = state => {
    return {
        fileTrack: state.FileReducer.fileTrack,
        dropdowns: state.dropdowns
    };
};

const mapDispatchToProps = {
    fileTracking
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(withStyles(Styles)(FileExport));
