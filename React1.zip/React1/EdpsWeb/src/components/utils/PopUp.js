import React from 'react';
import Button from '@material-ui/core/Button';
import { confirmAlert } from 'react-confirm-alert';

const ConfirmBox = (submitForm, Type, props) => {
  let message = null;
  switch (Type) {
    case "UPDATE": message = "Are you sure you want to update?";
    break;
    case "ENCOUNTER": message = "Are you sure to continue saving without changing the process status to COR?"
    break;
    default: message = "";
  }

  confirmAlert({
    customUI: ({ onClose }) => {
      const { classes } = props;
      return (
        <div className={classes.confirmDialog} >
          <h3>{message}</h3>
          <Button className={classes.confirmDialogButton} variant="contained" onClick={onClose}>No</Button>

          <Button className={classes.confirmDialogButton} variant="contained"
            onClick={() => {
              submitForm();
              onClose();
            }}
          >
            Yes
          </Button>
        </div>
      );
    }
  });
}

export default (ConfirmBox);
