import React from 'react';
import Button from '@material-ui/core/Button';
import { confirmAlert } from 'react-confirm-alert';

const MessageBox = (submitForm, Type,props) => {
  let message = null;
  switch (Type) {
  
    case "MESSAGE": message = "Delete of Primary Address in not allowed"
                  
      break;
  
      default : message = "";
  }

   confirmAlert({
    customUI: ({ onClose }) => {
      const { classes } = props;
      return (
        <div className={classes.confirmDialog} >
          <h3>{message}</h3>
          {/* <p>It will discard all your changes for current model</p> */}
         

          <Button className={classes.confirmDialogButton} variant="contained"
            onClick={() => {
              submitForm();
              onClose();
              
            }}
          >
            Ok
                    </Button>

                   
        </div>
      );
    }
  });

  



}

export default (MessageBox);
