import AppBar from '@material-ui/core/AppBar';
import NoSsr from '@material-ui/core/NoSsr';
import { withStyles } from '@material-ui/core/styles';
import Tab from '@material-ui/core/Tab';
import Tabs from '@material-ui/core/Tabs';
import Typography from '@material-ui/core/Typography';
import isEmpty from "lodash/isEmpty";
import PropTypes from 'prop-types';
import React, { Component } from 'react';
import { connect } from "react-redux";
import { withRouter } from 'react-router';
import { compose } from 'redux';
import { fetchCacheData } from "../../redux/actions/cacheDataAction";
import { encounterCriteria } from "../../redux/actions/encounterDetailsAction";
import Dashboard from '../Dashboard';
import Encounter from '../Encounter/Encounter';
import ErrorBoundary from '../Error/ErrorBoundary';

function TabContainer(props) {
  return (
    <Typography component="div" style={{ padding: 8 }}>
      {props.children}
    </Typography>
  );
}

TabContainer.propTypes = {
  children: PropTypes.node.isRequired,
};

function LinkTab(props) {
  return <Tab component="a" onClick={event => event.preventDefault()} {...props} />;
}

const styles = theme => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
  },
  bigIndicator:
  {
    height: 2,
    backgroundColor: "white"
  },
  tabMargin: {
    borderRight: '0.15em solid #eee'
  }
});

class edpsManagementRoute extends Component {

  constructor(props) {
    super(props);
    this.state = {
      value: 0,
      encounterPayload: {},
      graphRoute: false,
      location: this.props.history.location.pathname
    }
  }

  componentWillMount() {
    if (isEmpty(this.props.dropdowns)) {
      this.props.fetchCacheData();
    }
  }


  componentDidMount() {
    if (!isEmpty(this.props.location.state)) {
      this.setState({
        routePayload: this.props.location.state,
        graphRoute: this.props.location.state.graphRoute &&
        this.props.location.state.graphRoute ? true : false,
        value: 1
      })
    }
    else if (!isEmpty(this.props.location.encounterPayload)) {
      this.setState({
        value: 1
      })
    }
  }

  handleChange = (event, value) => {
    console.log(this.state)
    if(this.state.graphRoute){
      this.props.history.push({
        pathname: '/dashboard'
      })
    }else{
      this.setState({
        value,
        routePayload: {}
      });
    }
  };


  handleMonthSelect = async (groupStatus, encType, submitterId, fromDate, toDate, searchSummaryDateInd) => {
    let payload = {
      fromDate,
      toDate,
      groupStatus,
      encType,
      submitterId,
      searchSummaryDateInd
    }
    await this.props.encounterCriteria(payload, this.state.location);
    await this.setState({
      dashBoardPayload: payload,
      value: 1
    })
  };



  render() {
    const { classes } = this.props;
    const { value } = this.state;
    return (
      // <p>EDPS Management</p>
      <NoSsr>
        <div className={classes.root}>
          <AppBar position="static">
            <Tabs variant="fullWidth" value={value} onChange={this.handleChange}
              classes={{
                indicator:
                  classes.bigIndicator
              }}>
              <LinkTab label="EDPS Dashboard" href="page1" className={classes.tabMargin} />
              <LinkTab label="Encounter Detail" href="page2" />
            </Tabs>
          </AppBar>

          {value === 0 && <TabContainer>
            <Dashboard
              parentTab={"edpsManagement"}
              handleMonthSelect={this.handleMonthSelect} />
          </TabContainer>}
          {value === 1 && <TabContainer>
            <ErrorBoundary>
              <Encounter
                parentTab={"edpsManagement"}
                routePayload={this.state.routePayload} />
            </ErrorBoundary>
          </TabContainer>}
        </div>
      </NoSsr>
    );
  }
}

edpsManagementRoute.propTypes = {
  classes: PropTypes.object.isRequired,
};

const mapDispatchToProps = {
  fetchCacheData,
  encounterCriteria
};

export default compose(
  withRouter,
  withStyles(styles),
  connect(null, mapDispatchToProps)
)(edpsManagementRoute);