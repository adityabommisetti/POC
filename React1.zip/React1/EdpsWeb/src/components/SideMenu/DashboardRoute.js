import AppBar from '@material-ui/core/AppBar';
import NoSsr from '@material-ui/core/NoSsr';
import { withStyles } from '@material-ui/core/styles';
import Tab from '@material-ui/core/Tab';
import Tabs from '@material-ui/core/Tabs';
import Typography from '@material-ui/core/Typography';
import isEmpty from "lodash/isEmpty";
import PropTypes from 'prop-types';
import React, { Component } from 'react';
import { connect } from "react-redux";
import { withRouter } from 'react-router';
import { compose } from 'redux';
import { fetchCacheData } from "../../redux/actions/cacheDataAction";
import Dashboard from '../Encounter/Graph/DashboardGraph';
import Rejectboard from '../Encounter/Graph/RejectBoardGraph';
import ErrorBoundary from '../Error/ErrorBoundary';

function TabContainer(props) {
  return (
    <Typography component="div" style={{ padding: 8 }}>
      {props.children}
    </Typography>
  );
}

TabContainer.propTypes = {
  children: PropTypes.node.isRequired,
};

function LinkTab(props) {
  return <Tab component="a" onClick={event => event.preventDefault()} {...props} />;
}

const styles = theme => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
  },
  bigIndicator:
  {
    height: 2,
    backgroundColor: "white"
  },
  tabMargin: {
    borderRight: '0.15em solid #eee'
  }
});

class DashboardRoute extends Component {

  constructor(props) {
    super(props);
    this.state = {
      value: 0
    }
  }

  componentWillMount() {
    if (isEmpty(this.props.dropdowns)) {
      this.props.fetchCacheData();
    }
  };

  componentDidMount() {
    console.log(this.props.location.chartRoute)
   if (this.props.location.chartRoute) {
      this.setState({
        value: 1
      })
    }
  }


  handleChange = (event, value) => {
    this.setState({
      value
    });
  };

  render() {
    const { classes } = this.props;
    const { value } = this.state;
    return (
      // <p>EDPS Management</p>
      <NoSsr>
        <div className={classes.root}>
          <AppBar position="static">
            <Tabs variant="fullWidth" value={value} onChange={this.handleChange}
              classes={{
                indicator:
                  classes.bigIndicator
              }}>
              <LinkTab label="EDPS Dashboard" href="page1" className={classes.tabMargin} />
              <LinkTab label="Reject Dashboard" href="page2" />
            </Tabs>
          </AppBar>

          {value === 0 && <TabContainer>
            <ErrorBoundary>
            <Dashboard />
            </ErrorBoundary>
          </TabContainer>}
          {value === 1 && <TabContainer>
            <ErrorBoundary>
            <Rejectboard />
            </ErrorBoundary>
          </TabContainer>}
        </div>
      </NoSsr>
    );
  }
}

DashboardRoute.propTypes = {
  classes: PropTypes.object.isRequired,
};

const mapDispatchToProps = {
  fetchCacheData
};

export default compose(
  withRouter,
  withStyles(styles),
  connect(null, mapDispatchToProps)
)(DashboardRoute);