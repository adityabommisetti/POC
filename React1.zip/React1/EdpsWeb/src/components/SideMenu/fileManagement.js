import AppBar from '@material-ui/core/AppBar';
import NoSsr from '@material-ui/core/NoSsr';
import { withStyles } from '@material-ui/core/styles';
import Tab from '@material-ui/core/Tab';
import Tabs from '@material-ui/core/Tabs';
import Typography from '@material-ui/core/Typography';
import isEmpty from "lodash/isEmpty";
import PropTypes from 'prop-types';
import React, { Component } from 'react';
import { connect } from "react-redux";
import { fetchCacheData } from "../../redux/actions/cacheDataAction";
import FileDashBoard from '../FileManagement/fileDashBoard';
import FileTracking from '../FileManagement/FileTracking';


function TabContainer(props) {
  return (
    <Typography component="div" style={{ padding: 8 }}>
      {props.children}
    </Typography>
  );
}

TabContainer.propTypes = {
  children: PropTypes.node.isRequired,
};

function LinkTab(props) {
  return <Tab component="a" onClick={event => event.preventDefault()} {...props} />;
}

const styles = theme => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
  },
  bigIndicator:
  {
    height: 2,
    backgroundColor: "white"
  },
  tabmargin: {
    borderLeft: "0.2rem solid #eee"
  }
});

class fileManagement extends Component {
  state = {
    value: 0,
  };

  componentWillMount() {
    if (isEmpty(this.props.dropdowns)) {
      this.props.fetchCacheData();
    }
  }

  handleChange = (event, value) => {
    this.setState({ value });
  };

  selectRow = () => {
  }

  render() {
    const { classes } = this.props;
    const { value } = this.state;
    return (
      <NoSsr>
        <div className={classes.root}>
          <AppBar position="static">
            <Tabs variant="fullWidth" value={value} onChange={this.handleChange}
              classes={{
                indicator:
                  classes.bigIndicator
              }}>
              <LinkTab label="File Dashboard" href="page1" />
              <LinkTab label="File Tracking" href="page2" className={classes.tabmargin} />
            </Tabs>
          </AppBar>
          {value === 0 && <TabContainer><FileDashBoard /></TabContainer>}
          {value === 1 && <TabContainer><FileTracking /></TabContainer>}
        </div>
      </NoSsr>
    );
  }
}

fileManagement.propTypes = {
  classes: PropTypes.object.isRequired,
};

const mapDispatchToProps = {
  fetchCacheData
};

export default connect(
  null,
  mapDispatchToProps
)(withStyles(styles)(fileManagement));

