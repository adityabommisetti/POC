import AppBar from '@material-ui/core/AppBar';
import NoSsr from '@material-ui/core/NoSsr';
import { withStyles } from '@material-ui/core/styles';
import Tab from '@material-ui/core/Tab';
import Tabs from '@material-ui/core/Tabs';
import Typography from '@material-ui/core/Typography';
import isEmpty from "lodash/isEmpty";
import PropTypes from 'prop-types';
import React, { Component } from 'react';
import { connect } from "react-redux";
import { withRouter } from 'react-router';
import { compose } from 'redux';
import { fetchCacheData } from "../../redux/actions/cacheDataAction";
import { encounterCriteria, errorCodeCriteria } from "../../redux/actions/encounterDetailsAction";
import Encounter from '../Encounter/Encounter';
import ErrorBoundary from '../Error/ErrorBoundary';
import ErrorCode from '../ErrorCode';
import RejectBoard from '../RejectBoard';


function TabContainer(props) {
  return (
    <Typography component="div" style={{ padding: 8 }}>
      {props.children}
    </Typography>
  );
}

TabContainer.propTypes = {
  children: PropTypes.node.isRequired,
};

function LinkTab(props) {
  return <Tab component="a" onClick={event => event.preventDefault()} {...props} />;
}

const styles = theme => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
  },
  bigIndicator:
  {
    height: 2,
    backgroundColor: "white"
  },
  tabmargin: {
    borderLeft: "0.2rem solid #eee"
  }
});

class rejectAnalysisRoute extends Component {
  state = {
    value: 0,
    rejectPayload: {},
    errorPayload: {},
    graphRoute: false,
    location: this.props.history.location.pathname
  };

  componentWillMount() {
    if (isEmpty(this.props.dropdowns)) {
      this.props.fetchCacheData();
    }
  };

  async componentDidMount() {
    if (!isEmpty(this.props.location.errorPayload)) {
      await this.setState({
        errorPayload: this.props.location.errorPayload,
        graphRoute: this.props.location.errorPayload.graphRoute &&
          this.props.location.errorPayload.graphRoute ? true : false,
        value: 1
      })
    }
  };

  getLstDayOfMonFnc = (date) => {
    return new Date(date.getFullYear(), date.getMonth(), 0).getDate()
  };

  rejectBoardSelect = async (errorSource, encType, submitterId, fromDateYrmo, toDateYrmo, searchSummaryDateInd, month, year) => {
    let errorPayload = {
      errorSource,
      encType,
      submitterId,
      fromDateYrmo,
      toDateYrmo,
      searchSummaryDateInd
    }
    const fromDate = month + "/" + "01" + "/" + year;
    const toDate = month + "/" + this.getLstDayOfMonFnc(new Date(year, month, 1)) + "/" + year;
    let encounterPayload = {
      errorSource,
      encType,
      submitterId,
      fromDate,
      toDate,
      searchSummaryDateInd
    }
    await this.props.errorCodeCriteria(errorPayload, this.state.location);
    await this.props.encounterCriteria(encounterPayload, this.state.location);
    this.setState({
      value: 1
    })
  };

  errorBoardSelect = async (errData) => {
    await this.props.encounterCriteria(errData, this.state.location);
    this.setState({
      errorPayload: errData,
      value: 2
    })
  }

  handleChange = (event, value) => {
    if (this.state.graphRoute) {
      this.props.history.push({
        pathname: '/dashboard',
        chartRoute: true
      })
    }
    this.setState({
      value
    });
  };

  render() {
    const { classes } = this.props;
    const { value, errorPayload } = this.state;
    return (
      // <p>EDPS Management</p>
      <NoSsr>
        <div className={classes.root}>
          <AppBar position="static">
            <Tabs variant="fullWidth" value={value} onChange={this.handleChange}
              classes={{
                indicator:
                  classes.bigIndicator
              }}>
              <LinkTab label="Reject Dashboard" href="page1" />
              <LinkTab label="Error Codes Dashboard" href="page2" className={classes.tabmargin} />
              <LinkTab label="Encounter Detail" href="page3" className={classes.tabmargin} />

            </Tabs>
          </AppBar>
          {value === 0 && <TabContainer><RejectBoard parentTab={"rejectAnalysis"} rejectBoardSelect={this.rejectBoardSelect} /></TabContainer>}
          {value === 1 && <TabContainer><ErrorCode parentTab={"rejectAnalysis"} errorPayload={errorPayload} errorBoardSelect={this.errorBoardSelect} /></TabContainer>}
          {value === 2 && <TabContainer><ErrorBoundary><Encounter parentTab={"rejectAnalysis"} /></ErrorBoundary></TabContainer>}
        </div>
      </NoSsr>
    );
  }
}
rejectAnalysisRoute.propTypes = {
  classes: PropTypes.object.isRequired,
};


const mapDispatchToProps = {
  fetchCacheData,
  errorCodeCriteria,
  encounterCriteria
};

export default compose(
  withRouter,
  withStyles(styles),
  connect(null, mapDispatchToProps)
)(rejectAnalysisRoute);

