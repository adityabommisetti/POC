import React from "react";
import { Link } from 'react-router-dom';
import { withStyles } from '@material-ui/core/styles';
import classNames from "classnames";
import { Styles } from "../assets/styles/Theme"
export const logo = require('../components/assets/EDPS_User_Guide.pdf');



function userDoc(props) {
     const { classes } = props
     return (
          <div className={classes.containeruserDoc}>
               <Link to={logo} target="_blank" download className={classes.textuserDoc}>  Download EDPS User Guide<i className={classNames("fa fa-download", classes.downloadIcon)}></i></Link>
          </div>
     );
}

export default withStyles(Styles)(userDoc);
