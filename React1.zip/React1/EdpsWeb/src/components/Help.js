import React from "react";
import { withStyles } from '@material-ui/core/styles';
import { Styles } from "../assets/styles/Theme";



function Help(props) {
     const { classes } = props
     return (
          <div className={classes.containeruserDoc}>
               EDPS Help
          </div>
     );
}

export default withStyles(Styles)(Help);
