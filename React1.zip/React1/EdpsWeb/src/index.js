
import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
import "react-notifications/lib/notifications.css";
import { Provider } from "react-redux";
import { MuiThemeProvider, createMuiTheme } from "@material-ui/core/styles";
import "./assets/css/react-confirm-alert.css";
import "./assets/css/spinner.css";
import rootReducer from './redux/reducers';
import { createStore, applyMiddleware } from 'redux';
import thunk from 'redux-thunk';
import logger from 'redux-logger'
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';
import 'core-js/features/array/find';
import 'core-js/features/array/includes';
import 'core-js/features/number/is-nan';
import "./index.css";
import "./App.css";
import "./react-datetime.css";

import "./assets/css/react-confirm-alert.css";
import "./assets/css/spinner.css";
import "./assets/css/comments.css";
require("webpack-jquery-ui");
require("webpack-jquery-ui/css");

const store = createStore(rootReducer, applyMiddleware(thunk, logger));


const customeTheme = createMuiTheme({
  palette: {
    primary: { main: '#389bde' },
    secondary: { main: '#db2534' },

  },
  overrides: {
    MuiButton: {
      containedPrimary: {
        color: '#fff',
        width: 'auto',
        fontSize: '11px',
        padding: ".55em 1.02em .7em",
        marginLeft: ".5em",
        backgroundColor: '#389bb5',
        borderRadius: '5px',
        boxShadow: '0px 1px 2px 0px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0,0,0,0.24), 0px 3px 1px -2px rgba(0,0,0,0.02)',
      }
    }
    ,
    MuiInput: {

      underline: {

        "&:after": {
          borderBottom: 0
        },
        "&:before": {
          content: !!window.MSInputMethodContext && !!document.documentMode ? "''" : ""

        }
      }
    },
    MuiFormLabel: {
      asterisk: {
        color: "red"
      }
    },
    MuiExpansionPanelDetails: {
      root: {
        display: 'block !important'
      }
    },
    MuiTablePagination: {
      menuItem: {
        backgroundColor: "#053674 !important"
      }
    },
    MuiTypography: {
      body1: {
        fontSize: "0.875rem"
      }
    }
  },


  MuiSvgIcon: {
    root: {
      fill: 'black'
    }
  },

});



ReactDOM.render(
  <Provider store={store}>
    {<div>
      <MuiThemeProvider theme={customeTheme}>
        <App />
      </MuiThemeProvider>
    </div>}
  </Provider>

  , document.getElementById('root'));

