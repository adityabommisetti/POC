export const Styles = theme => ({
    root: {
        height: '100vh',
    },
    paper: {
        margin: "8rem 4rem",
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
    },
    form: {
        width: '100%', // Fix IE 11 issue.
        marginTop: 1,
    },

    submit: {
        margin: "3 0 2"
    },

    avatar: {
        margin: theme.spacing.unit,
        backgroundColor: theme.palette.secondary.main,
    },

    image: {
        backgroundImage: 'url(https://source.unsplash.com/1600x900/?codes)',
        backgroundRepeat: 'no-repeat',
        backgroundColor:
            theme.palette.type === 'dark' ? theme.palette.grey[900] : theme.palette.grey[50],
        backgroundSize: 'cover',
        backgroundPosition: 'center',
    },


});
