export const LOGIN = "/auth/login";
export const LOGOUT = "/auth/logout";
export const GET_USER_INFO = "/auth/get/userinfo";
export const CACHE_DATA = "/getCacheData";
export const SEARCH_ENCOUNTER = "/searchEncounter";
export const EXPORT_ENCOUNTER_CURRENT = "/exportCurrentEncDetail";
export const EXPORT_ENCOUNTER_ALL = "/exporAlltEncDetail";
export const CLAIM_VERSION = "/getClaimVersions";
export const FETCH_SUBSCRIBER = "/getSubscriber";
export const UPDATE_SUBSCRIBER = "/updateSubscriber";
export const FETCH_PROVIDER = "/getEncProfProvider";
export const UPDATE_PROVIDER = "/updateBillProviders";
export const LOG_DETAILS = "/logDetails";
export const FETCH_CLAIM = "/getClaim";
export const DELETE_CLAIM_PROVIDER = "/deleteClaimProvider";
export const UPDATE_CLAIM = "/updateClaim";
export const FETCH_ATTACHMENT = "/getClaimLineAdjustments";
export const DASHBOARD_SEARCH = "/dashBoardSearch";
export const DASHBOARD_EXPORT = "/exportDashBoard";
export const DASHBOARD_GRAPH = "/dashBoardReportSearch";
export const REJECTBOARD_GRAPH = "/rejectDashboardReport";
export const REJECT_EXPORT = "/exportRejectDashBoard";
export const FILE_DASHBOARD = "/searchEDPSFileDsbdMngt";   
export const MONTHLY_FILE = "/searchMonthlyFTDetails";   
export const DAILY_FILE = "/getDailyFileProcessing";
export const FILE_UPDATE = "/updateRemark";
export const FILE_RETREIVE = "/retrieveRemark";
export const FILE_TRACKING = "/exportFileTracking";
export const ERROR_CODE = "/errorCodesDashboardSearch";
export const CITY_ZIP_POPUP = "/zipCodeSearch";

export const FETCH_CLAIM_CONDITION = "/getClaimConditions";
export const ADD_CLAIM_CONDITION = "/addClaimCondition";
export const DELETE_CLAIM_CONDITION = "/deleteClaimCondition";
export const UPDATE_CLAIM_CONDITION = "/updateClaimCondition";

export const FETCH_CLAIM_DIAGNOSIS = "/getClaimDiagnosisList";
export const ADD_CLAIM_DIAGNOSIS = "/addClaimDiagnosis";
export const DELETE_CLAIM_DIAGNOSIS = "/deleteClaimDiagnosis";
export const UPDATE_CLAIM_DIAGNOSIS = "/updateClaimDiagnosis";

export const FETCH_CLAIM_PROCEDURECODE = "/getClaimProcCodes";
export const ADD_CLAIM_PROCEDURECODE = "/addClaimProcCode";
export const UPDATE_CLAIM_PROCEDURECODE = "/updateClaimProcCode";
export const DELETE_CLAIM_PROCEDURECODE = "/deleteProcCode";
export const DASHBOARD_REJECT = "/rejectDashboardSearch";

export const FETCH_CLAIM_OCCURRENCE_SPAN = "/getClaimOccurrenceSpans";
export const ADD_CLAIM_OCCURRENCE_SPAN = "/addClaimOccurrenceSpan";
export const UPDATE_CLAIM_OCCURRENCE_SPAN = "/updateClaimOccurrenceSpan";
export const DELETE_CLAIM_OCCURRENCE_SPAN = "/deleteOccurrenceSpan";


export const FETCH_CLAIM_VALUE_CODE = "/getClaimValues";
export const ADD_CLAIM_VALUE_CODE = "/addClaimValue";
export const UPDATE_CLAIM_VALUE_CODE = "/updateClaimValue";
export const DELETE_CLAIM_VALUE_CODE = "/deleteClaimValue";

export const FETCH_CLAIM_EXT_CAUSE_INJURY = "/getClaimExtInjuries"
export const ADD_CLAIM_EXT_CAUSE_INJURY = "/addClaimExtInjury"
export const UPDATE_CLAIM_EXT_CAUSE_INJURY = "/updateClaimExtInjury "
export const DELETE_CLAIM_EXT_CAUSE_INJURY = "/deleteExtInjury "

export const FETCH_CLAIM_OCCURRENCE = "/getClaimOccurrences";
export const ADD_CLAIM_OCCURRENCE = "/addClaimOccurrence";
export const UPDATE_CLAIM_OCCURRENCE = "/updateClaimOccurrence";
export const DELETE_CLAIM_OCCURRENCE = "/deleteClaimOccurrence";

export const FETCH_CLAIM_TREATMENT = "/getClaimTreatments";
export const ADD_CLAIM_TREATMENT = "/addClaimTreatment";
export const UPDATE_CLAIM_TREATMENT = "/updateClaimTreatment";
export const DELETE_CLAIM_TREATMENT = "/deleteClaimTreatment";

export const ADD_CLAIM_LINE_ADJUDICATION_ADJUSTMENT = "/addClaimLineAdjustments";
export const UPDATE_CLAIM_LINE_ADJUDICATION_ADJUSTMENT = "/updateClaimLineAdjustments";
export const DELETE_CLAIM_LINE_ADJUDICATION_ADJUSTMENT = "/deleteClaimLineAdjustments";

export const NOTIFICATION_API = "/notifications/stream";
export const WF_SEARCH_NEXT_PAGE = "/workflow/search/next";


export const LOGIN_ANALYTICS="/analytics/getJasper/orgprefix/EDPS"