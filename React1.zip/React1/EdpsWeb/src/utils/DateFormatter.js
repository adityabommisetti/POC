export const handleDateChange =(value) =>{
    if(value.length===8){
        value = value.replace(/[^0-9]/g, "").trim();
        value = value.replace(/^(\d{2})/, "$1/");
        value = value.replace(/\/(\d{2})/, "/$1/");
        value = value.replace(/(\d)\/(\d{4}).*/, "$1/$2");
    }
    return value;
}