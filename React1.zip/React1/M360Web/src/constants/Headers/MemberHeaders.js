export const MEMBER_HEADER = [
  {
    label: "Wipro ID",
    title: "Member ID",
    key: "memberId",
  },
  {
    label: "M360 ID",
    title: "Member ID",
    key: "memberId",
  },
  {
    label: "Medicare ID",
    title: "Medicare ID",
    key: "medicareId",
  },
  {
    label: "Plan Member ID",
    title: "Supplemental ID",
    key: "supplementalId",
  },
  {
    label: "Effective Month",
    title: "Effective Month",
    key: "cmsEffMonth",
  },
  {
    label: "Member Name",
    title: "Member Name",
    key: "name",
  },
];

export const ERROR_HEADER = [
  {
    label: "Field",
    title: "Field",
    key: "fieldDispName",
  },
  {
    label: "Message",
    title: "Message",
    key: "errorMsg",
  },
  {
    label: "Status",
    title: "Status",
    key: "errorStatus",
  },
  {
    label: "Data",
    title: "Data",
    key: "errorData",
  },
];
export const ENROLLMENT_HEADER = [
  {
    label: "Group",
    title: "Group",
    key: "groupName",
  },
  {
    label: "Product",
    title: "Product",
    key: "productName",
  },
  {
    label: "Start Date",
    title: "Start Date",
    key: "effStartDateFrmt",
  },
  {
    label: "End Date",
    title: "End Date",
    key: "effEndDateFrmt",
  },
  {
    label: "Enroll Status",
    title: "Enroll Status",
    key: "enrollStatus",
  },
  {
    label: "Plan",
    title: "Plan",
    key: "planId",
  },
  {
    label: "PBP",
    title: "PBP",
    key: "pbpId",
  },
  {
    label: "Override",
    title: "Override",
    key: "overrideInd",
  },
];

export const DSINFO_HEADER = [
  {
    label: "Code",
    title: "Code",
    key: "dsCd",
  },
  {
    label: "Value",
    title: "Value",
    key: "dsValue",
  },
  {
    label: "Start Date",
    title: "Start Date",
    key: "effStartDateFrmt",
  },
  {
    label: "End Date",
    title: "End Date",
    key: "effEndDateFrmt",
  },
  {
    label: "Created",
    title: "Created",
    key: "createTime",
  },
  {
    label: "User",
    title: "User",
    key: "createUserId",
  },
  {
    label: "Override",
    title: "Override",
    key: "overrideInd",
  },
];

export const TRR_TABLE_HEADER = [
  {
    label: "Processed",
    title: "Processed",
    key: "logDateFrmt",
  },
  {
    label: "Effective Date",
    title: "Effective Date",
    key: "effectiveDateFrmt",
  },
  {
    label: "TXN",
    title: "TXN",
    key: "transactionCode",
  },

  {
    label: "Reply",
    title: "Reply",
    key: "transReplyCd",
  },

  {
    label: "Description",
    title: "Description",
    key: "transReplyDesc",
  },
  {
    label: "Acc/Rej",
    title: "Acc/Rej",
    key: "accRejInd",
  },
  {
    label: "Source",
    title: "Source",
    key: "sourceId",
  },
  {
    label: "Update",
    title: "Update",
    key: "updateYN",
  },
  {
    label: "Update Item",
    title: "Update Item",
    key: "updateType",
  },
  {
    label: "Update Field",
    title: "Update Field",
    key: "fieldName",
  },
];

export const TRRDATA_TABLE_HEADER = [
  {
    label: "Trr Variable Desc",
    title: "Trr Variable Desc",
    key: "variableDesc",
  },
  {
    label: "Trr Variable Data",
    title: "Trr Variable Data",
    key: "variableData",
  },
  {
    label: "Trr Variable Data Desc",
    title: "Trr Variable Data Desc",
    key: "variableDataDesc",
  },
];

export const COB_TABLE_HEADER = [
  {
    label: "Type",
    title: "Type",
    key: "cobDesc",
  },
  {
    label: "OHI",
    title: "OHI",
    key: "ohiDesc",
  },
  {
    label: "Start Date",
    title: "Start Date",
    key: "effStartDateFrmt",
  },

  {
    label: "End Date",
    title: "End Date",
    key: "effEndDateFrmt",
  },

  {
    label: "Override",
    title: "Override",
    key: "overrideInd",
  },
];

export const IC_MODEL_TABLE_HEADER = [
  {
    label: "Start Date",
    title: "Start Date",
    key: "startDate",
  },

  {
    label: "End Date",
    title: "End Date",
    key: "endDate",
  },
  {
    label: "Model Type",
    title: "Model Type",
    key: "modelType",
  },
  {
    label: "Plan",
    title: "Plan",
    key: "plan",
  },
  {
    label: "Group Id",
    title: "Group Id",
    key: "groupId",
  },
  {
    label: "Medicare Id",
    title: "Medicare Id",
    key: "medicareId",
  },
  {
    label: "Benefit Code",
    title: "Benefit Code",
    key: "benefitCode",
  },
  {
    label: "Enroll Status",
    title: "Enroll Status",
    key: "enrollStatus",
  },

  {
    label: "Override",
    title: "Override",
    key: "overrideInd",
  },
];

export const POS_TABLE_HEADER = [
  {
    label: "Notification Date",
    title: "Notification Date",
    key: "notificateDateFrmt",
  },

  {
    label: "Status Flag",
    title: "Status Flag",
    key: "statusFlag",
  },
  {
    label: "Drug Status",
    title: "Drug Status",
    key: "drugEditStatus",
  },
  {
    label: "Impln Date",
    title: "Impln Date",
    key: "implDateFrmt",
  },
  {
    label: "TXN Status",
    title: "TXN Status",
    key: "txnStatus",
  },
  {
    label: "Drug Code",
    title: "Drug Code",
    key: "drugCode",
  },
  {
    label: "Override",
    title: "Override",
    key: "overrideInd",
  },
];
export const BILLING_HEADER = [
  {
    label: "Bill Pay method",
    title: "Bill Pay method",
    key: "billPayMethodDesc",
  },
  {
    label: "Start Date",
    title: "Start Date",
    key: "effStartDateFrmt",
  },
  {
    label: "End Date",
    title: "End Date",
    key: "effEndDateFrmt",
  },
  {
    label: "Override",
    title: "Override",
    key: "overrideInd",
  },
];

export const AGENT_TABLE_HEADER = [
  {
    label: "Agency",
    title: "Agency",
    key: "agencyName",
  },

  {
    label: "Agent",
    title: "Agent",
    key: "agentName",
  },
  {
    label: "Plan Id",
    title: "Plan Id",
    key: "planId",
  },
  {
    label: "Start Date",
    title: "Start Date",
    key: "effStartDateFrmt",
  },
  {
    label: "End Date",
    title: "End Date",
    key: "effEndDateFrmt",
  },
  {
    label: "Override",
    title: "Override",
    key: "overrideInd",
  },
];

export const LETTERS_TABLE_HEADER = [
  {
    label: "Name",
    title: "Name",
    key: "letterName",
  },
  {
    label: "Letter Description",
    title: "Letter Description",
    key: "description",
  },
  {
    label: "Requested",
    title: "Requested",
    key: "requestDate",
  },

  {
    label: "Orig Mailing",
    title: "Orig Mailing",
    key: "origMailDate",
  },

  {
    label: "Last Mailing",
    title: "Last Mailing",
    key: "lastMailDate",
  },

  {
    label: "PDF View",
    title: "PDF View",
    key: "letterAvailabilityInDB", // pdfView
  },
];

export const LETTER_DETAILS_TABLE_HEADER = [
  {
    label: "Variable",
    title: "Variable",
    key: "variableDesc",
  },
  {
    label: "Data",
    title: "Data",
    key: "variableData",
  },
];

export const LTC_TABLE_HEADER = [
  {
    label: "LTC ID",
    title: "LTC ID",
    key: "ltcId",
  },

  {
    label: "Facility Name",
    title: "Facility Name",
    key: "facilityName",
  },
  {
    label: "Start Date",
    title: "Start Date",
    key: "effStartDateFrmt",
  },
  {
    label: "End Date",
    title: "End Date",
    key: "effEndDateFrmt",
  },

  {
    label: "Created",
    title: "Created",
    key: "createTime",
  },
  {
    label: "User",
    title: "User",
    key: "createUserId",
  },
  {
    label: "Override",
    title: "Override",
    key: "overrideInd",
  },
];

/** LEP Table Headers */
export const LEP_TABLE_HEADER = [
  {
    label: "Start Date",
    title: "Start Date",
    key: "effStartDateFrmt",
  },

  {
    label: "End Date",
    title: "End Date",
    key: "effEndDateFrmt",
  },
  {
    label: "Uncov Mths",
    title: "Uncov Mths",
    key: "nbrUncovMonths",
  },
  {
    label: "LEP Amt",
    title: "LEP Amt",
    key: "lepAmt",
  },
  {
    label: "LEP Waived",
    title: "LEP Waived",
    key: "lepWaivedAmt",
  },
  {
    label: "Created",
    title: "Created",
    key: "createTime",
  },
  {
    label: "User",
    title: "User",
    key: "createUserId",
  },
  {
    label: "Override",
    title: "Override",
    key: "overrideInd",
  },
];

export const ELIGIBILITY_TABLE_HEADER = [
  {
    label: "Part A Start Date",
    title: "Part A Start Date",
    key: "partAEntitleSDate",
  },

  {
    label: "Part A End Date",
    title: "Part A End Date",
    key: "partAEntitleEDate",
  },

  {
    label: "Part B Start Date",
    title: "Part B Start Date",
    key: "partBEntitleSDate",
  },

  {
    label: "Part B End Date",
    title: "Part B End Date",
    key: "partBEntitleEDate",
  },
  {
    label: "Part D Start Date",
    title: "Part D Start Date",
    key: "partDEntitleSDate",
  },

  {
    label: "Part D End Date",
    title: "Part D End Date",
    key: "partDEntitleEDate",
  },
];

/* export const ELIGIBILITY_TABLE_HEADER = {
  head:["Part A Start Date","Part A End Date","Part B Start Date","Part B End Date","Part D Start Date","Part D End Date"],
  data:[["partAEntitleSDate","partAEntitleEDate","partBEntitleSDate","partBEntitleEDate","partDEntitleSDate"]]
} */

export const RDS_TABLE_HEADER = [
  {
    label: "Start Date",
    title: "Start Date",
    key: "startDate",
  },

  {
    label: "End Date",
    title: "End Date",
    key: "endDate",
  },
];

export const PARTD_TABLE_HEADER = [
  {
    label: "Start Date",
    title: "Start Date",
    key: "startDate",
  },

  {
    label: "End Date",
    title: "End Date",
    key: "endDate",
  },
];

export const UNCOVEREDMONTHS_TABLE_HEADER = [
  {
    label: "Start Date",
    title: "Start Date",
    key: "nunCmoStartDateFrmt",
  },

  {
    label: "Indicator",
    title: "Indicator",
    key: "nunCmoIndicator",
  },

  {
    label: "Number of Uncovered Months",
    title: "Number of Uncovered Months",
    key: "nunCmoNbrUnCovMths",
  },

  {
    label: "Total Number of Uncovered Months",
    title: "Total Number of Uncovered Months",
    key: "totNbrUnCovMths",
  },

  {
    label: "Record Add Time Stamp",
    title: "Record Add Time Stamp",
    key: "profileLastUpdt",
  },
];

export const UNCOVERED_TABLE_HEADER = [
  {
    label: "LEP Effective Date",
    title: "LEP Effective Date",
    key: "lepEffDateFrmt",
  },

  {
    label: "Uncovered Start Date",
    title: "Uncovered Start Date",
    key: "uncovMthStDtFrmt",
  },
  {
    label: "Uncovered End Date",
    title: "Uncovered End Date",
    key: "uncovMthEndDtFrmt",
  },
  {
    label: "Uncovered Months",
    title: "Uncovered Months",
    key: "plepMonths",
  },
  {
    label: "Override",
    title: "Override",
    key: "overRideInd",
  },
];

export const ATTESTATION_TABLE_HEADER = [
  {
    label: "Complete Response Received Date",
    title: "Complete Response Received Date",
    key: "comptRespRecDateFrmt",
  },

  {
    label: "Does Prior Credible Coverage exist?",
    title: "Does Prior Credible Coverage exist?",
    key: "brkInCoverage",
  },
  {
    label: "Source of credible Rx coverage",
    title: "Source of credible Rx coverage",
    key: "credRXCoverage",
  },
  {
    label: "From Date",
    title: "From Date",
    key: "fromDateFrmt",
  },
  {
    label: "To Date",
    title: "Override",
    key: "toDateFrmt",
  },
  {
    label: "Uncovered Month",
    title: "Uncovered Month",
    key: "ccfUncovMnths",
  },
  {
    label: "Response Type",
    title: "Response Type",
    key: "respType",
  },
  {
    label: "Override",
    title: "Override",
    key: "overRideInd",
  },
];

export const ASESINFO_HEADER = [
  {
    label: "Start Date",
    title: "Start Date",
    key: "effStartDateFrmt",
  },
  {
    label: "End Date",
    title: "End Date",
    key: "effEndDateFrmt",
  },
  {
    label: "ASES Status",
    title: "ASES Status",
    key: "status",
  },
  {
    label: "Plan Version",
    title: "Plan Version",
    key: "planVersion",
  },
  {
    label: "Created",
    title: "Created",
    key: "createTime",
  },
  {
    label: "User",
    title: "User",
    key: "createUserId",
  },
  {
    label: "Override",
    title: "Override",
    key: "overrideInd",
  },
];

//LTC
export const FACILITY_TABLE_HEADER = [
  {
    label: "LTC Facility ID",
    title: "LTC Facility ID",
    key: "ltcId",
  },
  {
    label: "Facility Name",
    title: "Facility Name",
    key: "facilityName",
  },
  {
    label: "Address",
    title: "Address",
    key: "facilityAddress",
  },
];

//ACCRETION
export const ACCRETION_HEADER = [
  {
    label: "Transaction Type",
    title: "Transaction Type",
    key: "transactionType",
  },
  {
    label: "Transaction Type Description",
    title: "Transaction Type Description",
    key: "transDesc",
  },

  {
    label: "Effective Date",
    title: "Effective Date",
    key: "effectiveDateFrmt",
  },
  {
    label: "Date/Time",
    title: "Date/Time",
    key: "time",
  },
];

//Address

export const ADDRESS_TABLE_HEADER = [
  {
    label: "Address Type",
    title: "Address Type",
    key: "addressType",
  },
  {
    label: "Address",
    title: "Address",
    key: "address1",
  },
  {
    label: "City",
    title: "City",
    key: "city",
  },
  {
    label: "State",
    title: "State",
    key: "stateAbbr",
  },

  {
    label: "ZIP",
    title: "ZIP",
    key: "zipCdFrmt",
  },
  {
    label: "Home Phone",
    title: "Home Phone",
    key: "homePhoneNbr",
  },
  {
    label: "Start Date",
    title: "Start Date",
    key: "effStartDateFrmt",
  },
  {
    label: "End Date",
    title: "End Date",
    key: "effEndDateFrmt",
  },
  {
    label: "Override",
    title: "Override",
    key: "overrideInd",
  },
];

export const CITY_TABLE_MEMBER_HEADER = [
  {
    label: "City",
    title: "City",
    key: "perCity",
  },
  {
    label: "State",
    title: "State",
    key: "perState",
  },
  {
    label: "Zip5",
    title: "Zip5",
    key: "perZip5",
  },
  {
    label: "Zip4",
    title: "Zip4",
    key: "perZip4",
  },
  {
    label: "County",
    title: "County",
    key: "perCounty",
  },
];

export const CITY_TABLE_HEADER = [
  {
    label: "City",
    title: "City",
    key: "cityName",
  },
  {
    label: "State",
    title: "State",
    key: "stateCd",
  },
  {
    label: "Zip5",
    title: "Zip5",
    key: "zipCd5",
  },
  {
    label: "Zip4",
    title: "Zip4",
    key: "zipCd4",
  },
];

export const COUNTY_TABLE_HEADER = [
  {
    label: "County",
    title: "County",
    key: "ssaCnty",
  },
  {
    label: "County Name",
    title: "County Name",
    key: "countyName",
  },
  {
    label: "State",
    title: "State",
    key: "stateCd",
  },
  {
    label: "Zip5",
    title: "Zip5",
    key: "zipCd5",
  },
];

export const GROUP_TABLE_HEADER = [
  {
    label: "Group",
    title: "Group",
    key: "groupName",
  },
  {
    label: "GROUP ID",
    title: "GROUP ID",
    key: "groupId",
  },
  {
    label: "Product",
    title: "Product",
    key: "productName",
  },
  {
    label: "PROD ID",
    title: "PROD ID",
    key: "productId",
  },
  {
    label: "Plan",
    title: "Plan",
    key: "planId",
  },
  {
    label: "PBP",
    title: "PBP",
    key: "pbpId",
  },
  {
    label: "Segment",
    title: "Segment",
    key: "segmentId",
  },
  {
    label: "State",
    title: "State",
    key: "state",
  },
];

export const PCP_TABLE_HEADER = [
  {
    title: "PCP",
    label: "PCP",
    key: "pcpNbr",
  },
  {
    title: "Location",
    label: "Location",
    key: "locationId",
  },
  {
    title: "Start Date",
    label: "Start Date",
    key: "effStartDateFrmt",
  },
  {
    title: "End Date",
    label: "End Date",
    key: "effEndDateFrmt",
  },
  {
    title: "Created",
    label: "Created",
    key: "createTime",
  },
  {
    title: "User",
    label: "User",
    key: "createUserId",
  },
  {
    title: "Override",
    label: "Override",
    key: "overrideInd",
  },
];

export const OOA_HEADER = [
  {
    label: "Temp/Perm",
    title: "Temp/Perm",
    key: "tempPerm",
  },
  {
    label: "OOA Source",
    title: "OOA Source",
    key: "sourceDesc",
  },

  {
    label: "OOA Reason",
    title: "OOA Reason",
    key: "reasonDesc",
  },
  {
    label: "Received Date",
    title: "Received Date",
    key: "receiveDateFrmt",
  },

  {
    label: "Leave Date",
    title: "Leave Date",
    key: "leaveDateFrmt",
  },
  {
    label: "D/E Effective Date",
    title: "D/E Effective Date",
    key: "deEffectiveDateFrmt",
  },
  {
    label: "D/E Reason",
    title: "D/E Reason",
    key: "deReasonDesc",
  },
];

export const OOA_TYPE = [
  {
    value: " ",
    label: "Select",
  },
  {
    value: "TEMP",
    label: "Temporary",
  },
  {
    value: "PERM",
    label: "Permanent",
  },
];
export const OOA_SOURCE = [
  {
    value: "Select",
    label: "Select",
  },
  {
    value: "MAIL-01",
    label: "MAIL-01",
  },
  {
    value: "MAIL-02",
    label: "MAIL-02",
  },
];

export const PCP_SEARCH_POPUP_HEADER = [
  {
    label: "Office Code",
    title: "Office Code",
    key: "pcpNbr",
  },
  {
    label: "Location ID",
    title: "Location ID",
    key: "locationId",
  },
  {
    label: "Doctor Name",
    title: "Doctor Name",
    key: "doctorName",
  },

  {
    label: "Accept New Patient",
    title: "Accept New Patient",
    key: "acceptNewPatient",
  },
  {
    label: "Address",
    title: "Address",
    key: "doctorAddress",
  },
  {
    label: "City",
    title: "City",
    key: "doctorCity",
  },
  {
    label: "State",
    title: "State",
    key: "doctorState",
  },
  {
    label: "Zip",
    title: "Zip",
    key: "doctorZip",
  },

  {
    label: "NPI",
    title: "NPI",
    key: "pcpNpi",
  },
];

export const COMMENTS_HEADER = [
  {
    label: "Created",
    title: "Created",
    key: "createTime",
  },
  {
    label: "User",
    title: "User",
    key: "createUserId",
  },

  {
    label: "Comments",
    title: "Comments",
    key: "applComments",
  },
];

export const MEMBER_COMMENTS_HEADER = [
  {
    label: "Created",
    title: "Created",
    key: "createTime",
  },
  {
    label: "User",
    title: "User",
    key: "createUserId",
  },

  {
    label: "Comments",
    title: "Comments",
    key: "mbrComments",
  },
];

export const PWO_TABLE_HEADER = [
  {
    label: "PWO Type",
    title: "PWO Type",
    key: "pwoType",
  },
  {
    label: "PWO Desc",
    title: "PWO Desc",
    key: "pwoDesc",
  },
  {
    label: "Effective Date",
    title: "Effective Date",
    key: "effectiveDate",
  },
  {
    label: "Term Date",
    title: "Term Date",
    key: "termDate",
  },

  {
    label: "Override",
    title: "Override",
    key: "overrideInd",
  },
];

export const EMPLOYER_TABLE_HEADER = [
  {
    label: "Employer Contibution Type",
    title: "Employer Contibution Type",
    key: "employerContibutionType",
  },
  {
    label: "Amount",
    title: "Amount",
    key: "amount",
  },
  {
    label: "Effective Date",
    title: "Effective Date",
    key: "effectiveDate",
  },
  {
    label: "Termination Date",
    title: "Term Date",
    key: "terminationDate",
  },
];

export const SPAP_TABLE_HEADER = [
  {
    label: "SPAP Type",
    title: "SPAP Type",
    key: "spapType",
  },
  {
    label: "SPAP Id",
    title: "SPAP Id",
    key: "spapId",
  },
  {
    label: "Effective From",
    title: "Effective From",
    key: "effectiveFrom",
  },
  {
    label: "Effective To",
    title: "Effective To",
    key: "effectiveTo",
  },
  {
    label: "Override",
    title: "Override",
    key: "override",
  },
];
export const LIS_TABLE_HEADER = [
  {
    label: "Start Date",
    title: "Start Date",
    key: "effStartDateFrmt",
  },
  {
    label: "End Date",
    title: "End Date",
    key: "effEndDateFrmt",
  },
  {
    label: "Copay",
    title: "Copay",
    key: "liCoPayCd",
  },
  {
    label: "Percent",
    title: "Percent",
    key: "lisPctCd",
  },
  {
    label: "Amount",
    title: "Amount",
    key: "lisAmt",
  },
  {
    label: "Created",
    title: "Created",
    key: "createTime",
  },
  {
    label: "User",
    title: "User",
    key: "createUserId",
  },
  {
    label: "Override",
    title: "Override",
    key: "overrideInd",
  },
];
