export const PRE_ENROLLMENT_STATUS = [
  {
    label: "Application ID",
    title: "Application ID",
    key: "applId",
  },
  {
    label: "Product Name",
    title: "Product Name",
    key: "prodName",
  },

  {
    label: "Application Type",
    title: "Application Type",
    key: "applType",
  },
  {
    label: "Medicare Id",
    title: "Medicare Id",
    key: "medicareId",
  },

  {
    label: "First Name",
    title: "First Name",
    key: "firstName",
  },
  {
    label: "Last Name",
    title: "Last Name",
    key: "lastName",
  },
  {
    label: "Application Status",
    title: "Application Status",
    key: "applStatus",
  },
  {
    label: "Birth Date",
    title: "Birth Date",
    key: "birthDate",
  },
  {
    label: "Received Date",
    title: "Received Date",
    key: "recieveDate",
  },
  {
    label: "Assigned To User",
    title: "Assigned To User",
    key: "assignedToUser",
  },
];

export const APPLICATION_AGING = [
  {
    label: "Application ID",
    title: "Application ID",
    key: "applId",
  },
  {
    label: "Aging Days",
    title: "Ageing Days",
    key: "ageingDays",
  },
  {
    label: "Product Name",
    title: "Product Name",
    key: "prodName",
  },

  {
    label: "Application Type",
    title: "Application Type",
    key: "applType",
  },
  {
    label: "Medicare Id",
    title: "Medicare Id",
    key: "medicareId",
  },

  {
    label: "First Name",
    title: "First Name",
    key: "firstName",
  },
  {
    label: "Last Name",
    title: "Last Name",
    key: "lastName",
  },
  {
    label: "Application Status",
    title: "Application Status",
    key: "applStatus",
  },
  {
    label: "Birth Date",
    title: "Birth Date",
    key: "birthDate",
  },
  {
    label: "Received Date",
    title: "Received Date",
    key: "recieveDate",
  },
  {
    label: "Assigned To User",
    title: "Assigned To User",
    key: "assignedToUser",
  },
];
export const RFI_TRACKING = [
  {
    label: "Application ID",
    title: "Application ID",
    key: "applId",
  },
  {
    label: "Product Name",
    title: "Product Name",
    key: "prodName",
  },

  {
    label: "Application Type",
    title: "Application Type",
    key: "applType",
  },
  {
    label: "Medicare Id",
    title: "Medicare Id",
    key: "medicareId",
  },

  {
    label: "First Name",
    title: "First Name",
    key: "firstName",
  },
  {
    label: "Last Name",
    title: "Last Name",
    key: "lastName",
  },
  {
    label: "Application Status",
    title: "Application Status",
    key: "applStatus",
  },
  {
    label: "Birth Date",
    title: "Birth Date",
    key: "birthDate",
  },
  {
    label: "Received Date",
    title: "Received Date",
    key: "recieveDate",
  },
  {
    label: "Assigned To User",
    title: "Assigned To User",
    key: "assignedToUser",
  },
  {
    label: "Activation Date",
    title: "Activation Date",
    key: "activationDate",
  },
];

export const MEMBERSHIP_DISTRIBUTION = [
  {
    label: "Plan",
    title: "Plan",
    key: "planId",
  },

  {
    label: "PBP Id",
    title: "PBP Id",
    key: "pbpId",
  },

  {
    label: "Enrollment",
    title: "Enrollment",
    key: "enrollCount",
  },
  {
    label: "DisEnrollment",
    title: "DisEnrollment",
    key: "disEnrollCount",
  },
];

export const CMS_STATUS = [
  {
    label: "Wipro ID",
    title: "Member ID",
    key: "memberId",
  },
  {
    label: "M360 ID",
    title: "Member ID",
    key: "memberId",
  },

  {
    label: "Transaction Type",
    title: "Transaction Type",
    key: "transactionType",
  },
  {
    label: "Plan Member ID",
    title: "Supplemental ID",
    key: "supplementalId",
  },
  {
    label: "Product Name",
    title: "Product Name",
    key: "prodName",
  },
  {
    label: "Type",
    title: "Type",
    key: "type",
  },
  {
    label: "Medicare ID",
    title: "Medicare ID",
    key: "medicareId",
  },
  {
    label: "First Name",
    title: "First Name",
    key: "firstName",
  },
  {
    label: "Last Name",
    title: "Last Name",
    key: "lastName",
  },
];
