export const TIMER_TABLE_HEADER = [
  {
    label: "Timer Type",
    title: "TimerType",
    key: "timerType"
  },
  {
    label: "Application ID",
    title: "ID",
    key: "primaryId"
  },
  {
    label: "Wipro ID",
    title: "ID",
    key: "primaryId"
  },
  {
    label: "M360 ID",
    title: "ID",
    key: "primaryId"
  },
  {
    label: "Status",
    title: "Status",
    key: "status"
  },

  {
    label: "Creation Time",
    title: "CreationTime",
    key: "creationTime"
  },

  {
    label: "Trig.Source",
    title: "Trig.Source",
    key: "trgSource"
  }
]