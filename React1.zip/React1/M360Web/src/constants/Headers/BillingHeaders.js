export const INVOICE_HEADER = [
  {
    label: "Invoice",
    title: "Invoice",
    key: "invoiceNbr"
  },
  {
    label: "Type",
    title: "Type",
    key: "displayInvType"
  },
  {
    label: "M360 ID",
    title: "Member",
    key: "invoiceId"
  },
  {
    label: "Wipro ID",
    title: "Member",
    key: "invoiceId"
  },
  {
    label: "Name",
    title: "Name",
    key: "name"
  },
  {
    label: "Due Date",
    title: "Due Date",
    key: "dueDateFrmt"
  },
  {
    label: "Status",
    title: "Status",
    key: "invoiceStatusDesc"
  },
  {
    label: "Final Amt ($)",
    title: "Final Amt",
    key: "totalAmt"
  }
];

export const INVOICE_DETAILS_HEADER = [
  {
    label: "Item",
    title: "Item",
    key: "itemAddNbr"
  },
  {
    label: "Check",
    title: "Check",
    key: "checkNbr"
  },
  {
    label: "Desc",
    title: "Desc",
    key: "itemDesc"
  },
  {
    label: "Function Cd",
    title: "Function Cd",
    key: "functionCd"
  },
  {
    label: "Status",
    title: "Status",
    key: "lineStatusDesc"
  },
  {
    label: "Amount ($)",
    title: "Amount",
    key: "detailAmt"
  }
];

export const INVOICE_COMMENTS_HEADER = [
  {
    label: "Created",
    title: "Created",
    key: "createTime"
  },
  {
    label: "User",
    title: "User",
    key: "createUserId"
  },
  {
    label: "Comment",
    title: "Comment",
    key: "mbrComments"
  }
];

export const INVOICE_MBR_GRP_HEADER = [
  {
    label: "Wipro ID ",
    title: "User",
    key: "grpId"
  },
  {
    label: "M360 ID ",
    title: "User",
    key: "grpId"
  },
  {
    label: "Name",
    title: "Name",
    key: "groupName"
  }
];

export const PAYMENT_HEADER = [
  {
    label: "Pay Source",
    title: "Pay Source",
    key: "source"
  },
  {
    label: "Batch Date",
    title: "Batch Date",
    key: "batchdate"
  },
  {
    label: "Batch Seq Nbr",
    title: "Batch Seq Nbr",
    key: "batchseqnumbr"
  },
  {
    label: "Bank Acct Cd",
    title: "Bank Acct Cd",
    key: "bankaccntcd"
  },
  {
    label: "Batch Balance Amt ($)",
    title: "Batch Balance Amt",
    key: "balanceamount"
  },
  {
    label: "Detail Total Amt ($)",
    title: "Detail Total Amt",
    key: "detailtotalamt"
  }
];

export const PAYMENT_DETAILS_HEADER = [
  {
    label: "Item Nbr",
    title: "Item Nbr",
    key: "itemnumber"
  },
  {
    label: "Wipro ID",
    title: "Member Id",
    key: "memberid"
  },
  {
    label: "M360 ID",
    title: "Member Id",
    key: "memberid"
  },
  {
    label: "Due Date",
    title: "Due Date",
    key: "duedate"
  },
  {
    label: "Check Date",
    title: "Check Date",
    key: "checkdate"
  },
  {
    label: "Check Nbr",
    title: "Check Nbr",
    key: "checknbr"
  },
  {
    label: "Payment Amt ($)",
    title: "Payment Amt",
    key: "paymentAmt"
  }
];
export const ADDPAYMENT_DETAILS_HEADER = [
  {
    label: "Delete",
    title: "Delete",
    key: "del"
  },
  {
    label: "Wipro ID",
    title: "Member Id",
    key: "memberid"
  },
  {
    label: "M360 ID",
    title: "Member Id",
    key: "memberid"
  },
  {
    label: "Check Date",
    title: "Check Date",
    key: "checkdate"
  },
  {
    label: "Check Nbr",
    title: "Check Nbr",
    key: "checknbr"
  },
  {
    label: "Payment Amt ($)",
    title: "Payment Amt",
    key: "paymentAmt"
  }
];

export const DRAFT_DETAILS_HEADER = [
  {
    label: "M360 ID",
    title: "Member",
    key: "invoiceId"
  },
  {
    label: "Wipro ID",
    title: "Member",
    key: "invoiceId"
  },
  {
    label: "Name",
    title: "Name",
    key: "lastName"
  },
  {
    label: "Invoice",
    title: "Invoice",
    key: "invoiceNbr"
  },
  {
    label: "Created Date",
    title: "Created Date",
    key: "createDateFrmt"
  },
  {
    label: "Due Date",
    title: "Due Date",
    key: "dueDateFrmt"
  },
  {
    label: "Settlement",
    title: "Settlement",
    key: "settlementDateFrmt"
  },
  {
    label: "Response",
    title: "Response",
    key: "responseCode"
  },
  {
    label: "Status",
    title: "Status",
    key: "invoiceStatus"
  },
  {
    label: "Amount ($)",
    title: "Amount",
    key: "invoiceAmt"
  }
];

export const MBRPAYMENT_DETAILS_HEADER = [
  {
    label: "Wipro ID",
    title: "Member Id",
    key: "invoiceId"
  },
  {
    label: "M360 ID",
    title: "Member Id",
    key: "invoiceId"
  },
  {
    label: "Name",
    title: "Name",
    key: "nameFrmt"
  },
  {
    label: "Medicare Id",
    title: "Medicare Id",
    key: "hicNbr"
  },
  {
    label: "Pay Source",
    title: "Pay Source",
    key: "paySourceDesc"
  },
  {
    label: "Batch Info",
    title: "Batch Info",
    key: "batchInfoFrmt"
  },
  {
    label: "Check Date",
    title: "Check Date",
    key: "checkDateFrmt"
  },
  {
    label: "Check Nbr",
    title: "Check Nbr",
    key: "checkNbr"
  },
  {
    label: "Pay Amt ($)",
    title: "Pay Amt",
    key: "paymentAmt"
  }
];

export const MBRPAYMENT_INVOICE_HEADER = [
  {
    label: "Invoice Nbr",
    title: "Invoice Nbr",
    key: "invoiceNbr"
  },
  {
    label: "Invoice Type",
    title: "Invoice Type",
    key: "invoiceType"
  },
  {
    label: "Due Date",
    title: "Due Date",
    key: "dueDateFrmt"
  },
  {
    label: "Applied Amt ($)",
    title: "Applied Amt",
    key: "appliedAmt"
  },
  {
    label: "Create Time",
    title: "Create Time",
    key: "createTime"
  },
  {
    label: "Create User",
    title: "Create User",
    key: "createUserId"
  }
];

export const PAYMENT_ITEM_HEADER = [
  {
    label: "Item Nbr",
    title: "Item Nbr",
    key: "itemNbr"
  },
  {
    label: "Wipro ID",
    title: "Member ID",
    key: "memberId"
  },
  {
    label: "M360 ID",
    title: "Member ID",
    key: "memberId"
  },
  {
    label: "Due Date",
    title: "Due Date",
    key: "invoiceDueDate"
  },
  {
    label: "Check Date",
    title: "Check Date",
    key: "checkDate"
  },
  {
    label: "Check Nbr",
    title: "Check Nbr",
    key: "checkNbr"
  },
  {
    label: "Payment Amt ($)",
    title: "Payment Amt",
    key: "paymentAmt"
  }
];
export const NEWPAYMENT_ITEM_HEADER = [
  {
    label: "Wipro ID",
    title: "Member ID",
    key: "Member ID"
  },
  {
    label: "M360 ID",
    title: "Member ID",
    key: "Member ID"
  },
  {
    label: "Check Date",
    title: "Check Date",
    key: "Check Date"
  },
  {
    label: "Check Nbr",
    title: "Check Nbr",
    key: "checkNbr"
  },
  {
    label: "Payment Amt ($)",
    title: "Payment Amt",
    key: "paymentAmt"
  }
];
export const PAYMENT_INVOICE_HEADER = [
  {
    label: "Invoice Nbr",
    title: "Invoice Nbr",
    key: "invoiceNbr"
  },
  {
    label: "Applied Amt ($)",
    title: "Applied Amount",
    key: "appliedAmount"
  },
  {
    label: "Create Time",
    title: "Create Time",
    key: "createTime"
  },
  {
    label: "Create User",
    title: "Create User",
    key: "createUserId"
  },
  {
    label: "Modified Time",
    title: "Modified Time",
    key: "lastUpdtTime"
  },
  {
    label: "Modified User",
    title: "Modified User",
    key: "lastUpdtUserId"
  }
];

export const PAYMENT_ENTRY_HEADER = [
  {
    label: "Pay Source",
    title: "Pay Source",
    key: "paySourceDesc"
  },
  {
    label: "Batch Date",
    title: "Batch Date",
    key: "batchDate"
  },
  {
    label: "Batch Seq Nbr",
    title: "Batch Seq",
    key: "batchSeqNbr"
  },
  {
    label: "Bank Acct Cd",
    title: "Bank Acct Cd",
    key: "bankAcntCd"
  },
  {
    label: "Batch Balance Amt ($)",
    title: "Batch Balance Amt",
    key: "batchBalance"
  },
  {
    label: "Detail Total Amt ($)",
    title: "Detail Total Amt",
    key: "detailAmount"
  }
];
