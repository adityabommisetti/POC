export const SUPERVISOR_HEADER = [
  {
    label: "UserId",
    title: "UserId",
    key: "userId",
  },

  {
    label: "UserName",
    title: "UserName",
    key: "name",
  },
  {
    label: "User Status",
    title: "User Status",
    key: "userStatus",
  },
];

export const SHOW_USERS_HEADER = [
  {
    label: "Supervisor Name",
    title: "supervisorName",
    key: "supervisorName",
  },
  {
    label: "Supervisor ID",
    title: "Supervisor ID",
    key: "supervisorId",
  },
  {
    label: "User ID",
    title: "User ID",
    key: "userId",
  },
  {
    label: "User Name",
    title: "userName",
    key: "userName",
  },

  {
    label: "User Access Level",
    title: "userAccess",
    key: "userLevel",
  },
];

export const QUEUES_HEADER = [
  {
    label: "Case Name",
    title: "Case Name",
    key: "queueName",
  },
  {
    label: "Case Prty",
    title: "Case Prty",
    key: "queuePrty",
  },
  {
    label: "Comp Days",
    title: "Comp Days",
    key: "compDays",
  },
  {
    label: "At Risk Days",
    title: "atRiskDays",
    key: "atRiskDays",
  },
  {
    label: "Case Activity Description",
    title: "Case Activity Description",
    key: "queueDesc",
  },
];

export const CASE_HEADER = [
  {
    label: "Case ID",
    title: "Case ID",
    key: "caseId",
  },
  {
    label: "Comments",
    title: "Comments",
    key: "comments",
  },
  {
    label: "UserID",
    title: "UserID",
    key: "createUserId",
  },
  {
    label: "Create Time",
    title: "Create Time",
    key: "createTime",
  },
];
