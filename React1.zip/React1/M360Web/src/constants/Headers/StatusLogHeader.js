export const STATUS_LOG_HEADER = [
  {
    label: "Log Time",
    title: "logTime",
    key: "logTime"
  },
  {
    label: "Last Update UserId",
    title: "lastUpdtUserId",
    key: "lastUpdtUserId"
  },
  {
    label: "Application Status",
    title: "applStatus",
    key: "applStatus"
  }
];
