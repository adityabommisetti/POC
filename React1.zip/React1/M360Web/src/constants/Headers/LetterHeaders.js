export const LETTER_DETAILS_TABLE_HEADER = [
  {
    label: "Batch ID",
    title: "Batch ID",
    key: "filebatchid",
  },
  {
    label: "Source",
    title: "Source",
    key: "recordTypeFrmt",
  },

  {
    label: "Application ID",
    title: "ID",
    key: "primaryId",
  },
  {
    label: "Wipro ID",
    title: "ID",
    key: "primaryId",
  },
  {
    label: "M360 ID",
    title: "ID",
    key: "primaryId",
  },

  {
    label: "Requested Date",
    title: "Requested Date",
    key: "requestDateFrmt",
  },
  {
    label: "Letter Name",
    title: "Letter Name",
    key: "letterNameFrmt",
  },
  {
    label: "Status",
    title: "Status",
    key: "recordStatus",
  },
  {
    label: "PDF View",
    title: "PDF View",
    key: "letterAvailabilityInDBPdfIcon",
  },
];
export const LETTER_QC_TABLE_HEADER = [
  {
    label: "Action",
    title: "Action",
    key: "checkbox",
  },
  {
    label: "File Batch ID",
    title: "File Batch ID",
    key: "filebatchid",
  },
  {
    label: "Source",
    title: "Source",
    key: "recordType",
  },

  {
    label: "Primary ID",
    title: "Primary ID",
    key: "primaryId",
  },

  {
    label: "Requested Date",
    title: "Requested Date",
    key: "requestDateFrmt",
  },
  {
    label: "Letter Name",
    title: "Letter Name",
    key: "letterName",
  },
  {
    label: "Status",
    title: "Status",
    key: "recordStatus",
  },
  {
    label: "PDF View",
    title: "PDF View",
    key: "letterAvailabilityInDBGet",
  },
];
export const LETTER_REQUEST_TABLE_HEADER = [
  {
    label: "Source",
    title: "Source",
    key: "sourceTypeDesc",
  },
  {
    label: "Wipro ID",
    title: "App ID",
    key: "primaryId",
  },
  {
    label: "M360 ID",
    title: "App ID",
    key: "primaryId",
  },
  {
    label: "Application ID",
    title: "App ID",
    key: "primaryId",
  },
  {
    label: "Effective Date",
    title: "Effective Date",
    key: "effDateFrmt",
  },

  {
    label: "Create Date",
    title: "Create Date",
    key: "createTimeFrmt",
  },

  {
    label: "Description",
    title: "Description",
    key: "letterNameDesc",
  },
  {
    label: "Status",
    title: "Status",
    key: "triggerStatus",
  },
];
