export const APPLICATION_SEARCH_HEADER = [
  {
    label: "Application ID",
    title: "Application ID",
    key: "applId"
  },
  {
    label: "Medicare ID",
    title: "Medicare ID",
    key: "medicareId"
  },
  {
    label: "Member Name",
    title: "Member Name",
    key: "fullName"
  },

  {
    label: "Birth Date",
    title: "Birth Date",
    key: "birthDtFrmt"
  },

  {
    label: "Product",
    title: "Product",
    key: "enrollProdName"
  }
];

export const APPLICATION_ERROR_HEADER = [
  {
    label: "Field Name",
    title: "Field Name",
    key: "fieldNbr"
  },
  {
    label: "Error Code",
    title: "Error Code",
    key: "errorCd"
  },
  {
    label: "Description",
    title: "Description",
    key: "errorMsg"
  },

  {
    label: "Value",
    title: "Value",
    key: "errorData"
  }
];

export const PCP_SEARCH_POPUP_HEADER = [
  {
    label: "Office Code",
    title: "Office Code",
    key: "pcpOfficeCd"
  },
  {
    label: "Location ID",
    title: "Location ID",
    key: "PcpLocationId"
  },
  {
    label: "Doctor Name",
    title: "Doctor Name",
    key: "pcpName"
  },

  {
    label: "Accept New Patient",
    title: "Accept New Patient",
    key: "pcpCurrPatnt"
  },
  {
    label: "Address",
    title: "Address",
    key: "pcpAddress"
  },
  {
    label: "City",
    title: "City",
    key: "pcpCity"
  },
  {
    label: "State",
    title: "State",
    key: "pcpState"
  },
  {
    label: "Zip",
    title: "Zip",
    key: "pcpZip"
  },
  {
    label: "NPI ID",
    title: "NPI ID",
    key: "pcpNpiId"
  }
];

export const AGENCY_SEARCH_POPUP_HEADER = [
  {
    label: "Agency ID",
    title: "Agency ID",
    key: "agencyId"
  },
  {
    label: "Agency Name",
    title: "Agency Name",
    key: "agencyName"
  },
  {
    label: "Agency Type",
    title: "Agency Type",
    key: "agencyType"
  },
  {
    label: "Agent ID",
    title: "Agent ID",
    key: "agentId"
  },
  {
    label: "Agent Name",
    title: "Agent Name",
    key: "agentName"
  },
  {
    label: "Agent Type",
    title: "Agent Type",
    key: "agentType"
  }
];

export const CITY_ZIP_HEADER = [
  {
    label: "City",
    title: "City",
    key: "perCity"
  },
  {
    label: "State",
    title: "State",
    key: "perState"
  },
  {
    label: "Zip5",
    title: "Zip5",
    key: "perZip5"
  },
  {
    label: "Zip4",
    title: "Zip4",
    key: "perZip4"
  },

  {
    label: "County",
    title: "County",
    key: "perCounty"
  }
];

export const GROUP_TABLE_HEADER = [
  {
    label: "Group",
    title: "Group",
    key: "groupName"
  },
  {
    label: "GROUP ID",
    title: "GROUP ID",
    key: "groupId"
  },
  {
    label: "Product",
    title: "Product",
    key: "productName"
  },
  {
    label: "PROD ID",
    title: "PROD ID",
    key: "productId"
  },
  {
    label: "Plan",
    title: "Plan",
    key: "planId"
  },
  {
    label: "PBP",
    title: "PBP",
    key: "pbpId"
  },
  {
    label: "Segment",
    title: "Segment",
    key: "segmentId"
  },
  {
    label: "State",
    title: "State",
    key: "stateCd"
  }
];
