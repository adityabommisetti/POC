export const DELETE = "DELETE";
export const UPDATE = "UPDATE";
export const ADD = "ADD";
export const MESSAGE = "MESSAGE";
export const SUPPRESSTC = "SUPPRESSTC";
export const TIMERCHECK = "TIMERCHECK";
export const CLOSE = "CLOSE";
