export const INITIAL_STATE = {
  effEndDateFrmt: "",
  effStartDateFrmt: "",
  effStartDate: "",
  effEndDate: "",
  overrideInd: "",
  addressType: "",
  addrTypeDesc: "",
  createTime: "",
  address1: "",
  address2: "",
  address3: "",
  addressChange: "",
  lastUpdtTime: "",
  lastUpdtUserId: "",
  comment: "",
  city: "",
  stateCd: "",
  stateAbbr: "",
  zipCd: "",
  zipCd5: "",
  zipCd4: "",
  countyCd: "",
  countyName: "",
  countryCd: "",
  homePhoneNbr: "",
  workPhoneNbr: "",
  cellPhoneNbr: "",
  surveyCompInd: "Y",
  surveyText: "",
  inquiryText: "",
  addChange: "",
  surveyResponse: "",
  sccChange: "",
  faxNbr: "",
  editable: true,
  Prefix: "",
  firstName: "",
  middleName: "",
  lastName: "",
  status: "",
  SSN: "",
  gender: "",
  maritalstatus: "",
  race: "",
  language: "",
  spousework: "",
  accessible: "",
  insurancecardname: "",
  authRepresentativeFirst: "",
  authRepresentativeMiddle: "",
  authRepresentativeLast: "",
  relationship: "",
  emergencyName: "",
  leptype: ""
};


export const APPLICATION_TYPE = [
  { value: "", label: "Select" },
  {
    value: "NMA",
    label: "NMA"
  },
  {
    value: "NPD",
    label: "NPD"
  },
  {
    value: "CMA",
    label: "CMA"
  },
  {
    value: "CPD",
    label: "CPD"
  }
];

export const GENDER = [
  { value: "", label: "Select" },
  {
    value: "M",
    label: "Male"
  },
  {
    value: "F",
    label: "Female"
  },
  {
    value: "O",
    label: "Other"
  }
];
//<><><><><><>< // REMOVE
export const ADDRESS_TYPE_LIST = [
  {
    value: "",
    label: "Select"
  },
  {
    value: "AUTH",
    label: "AUTHORIZED/POA"
  },
  {
    // value: 'BILL',
    value: "BILL",
    label: "BILLING ADDRESS"
  },
  {
    value: "EMER",
    label: "EMERGENCY ADDRESS"
  },
  {
    value: "INST",
    label: "INSTITUTIONAL ADDR"
  },
  {
    value: "MAIL",
    label: "MAILING ADDRESS"
  },

  {
    //  value: 'PRIM',
    value: "PRIM",
    label: "PRIMARY ADDRESS"
  },
  {
    value: "TEMP",
    label: "TEMPORARY ADDRESS"
  }
];

export const PREFIX_LIST = [
  {
    value: "1",
    label: "DR"
  },
  {
    // value: 'BILL',
    value: "2",
    label: "MS"
  },
  {
    value: "3",
    label: "MRS"
  }
];

export const LETTER_REQUEST_SOURCE = [
  {
    value: "",
    label: "Select"
  },
  {
    value: "A",
    label: "Application"
  },
  {
    value: "M",
    label: "Member"
  }
];

export const LETTER_REQUESTSOURCE = [
  {
    value: "",
    label: "Select"
  },
  {
    value: "Application",
    label: "Application"
  },
  {
    value: "Member",
    label: "Member"
  }
];
//Remove
export const LETTER_REQUEST_STATUS = [
  { value: "", label: "Select" },
  {
    value: "CANCELLED",
    label: "Timer/Update Cancel"
  },
  {
    value: "CLOSED",
    label: "Trigger Completed"
  },
  {
    value: "CLOSPNDRPT",
    label: "Closed Pending RPT"
  },
  {
    value: "EXPIRED",
    label: "Follow-up expired"
  },
  {
    value: "FAILED",
    label: "Trigger failed"
  },
  {
    value: "OPEN",
    label: "Open for process"
  }
];

export const LETTER_UPLOAD_SOURCE = [
  {
    value: "Application",
    label: "Application"
  },
  {
    value: "Member",
    label: "Member"
  }
];

export const LETTER_UPLOAD_SOURCE_SHORT = [
  {
    value: " ",
    label: "Select"

  },
  {
    value: "A",
    label: "Application"
  },
  {
    value: "M",
    label: "Member"
  }
];


export const LETTER_DETAILS_STATUS = [
  {
    value: "",
    label: "Select"
  },
  {
    value: "APPLIED",
    label: "APPLIED"
  },
  {
    value: "APPROVED",
    label: "APPROVED"
  },
  {
    value: "COMPLETED",
    label: "COMPLETED"
  },
  {
    value: "DELETED",
    label: "DELETED"
  },
  {
    value: "EXTRACTED",
    label: "EXTRACTED"
  },
  {
    value: "HOLD",
    label: "HOLD"
  },
  {
    value: "LOADED",
    label: "LOADED"
  },
  {
    value: "LDAPP",
    label: "LOADED/APPLIED"
  },
  {
    value: "REJECTED",
    label: "REJECTED"
  },
  {
    value: "UPLOADED",
    label: "UPLOADED"
  },
  // {
  //   value: "CORRERROR",
  //   label: "CORRERROR"
  // },

];

//Remove
export const LETTER_EDIT_STATUS = [
  {
    value: "",
    label: "Select"
  },
  {
    value: "APPLIED",
    label: "APPLIED"
  },
    {
    value: "DELETED",
    label: "DELETED	"
  },
  {
    value: "LOADED",
    label: "LOADED"
  },
  {
    value: "HOLD",
    label: "HOLD"
  }
  // {
  //   value: "APPROVED",
  //   label: "APPROVED"
  // },
  // {
  //   value: "COMPLETED",
  //   label: "COMPLETED"
  // },
  //   {
  //   value: "CORRERROR",
  //   label: "CORRERROR"
  // },
  // {
  //   value: "EXTRACTED",
  //   label: "EXTRACTED"
  // },
  
  // {
  //   value: "REJECTED",
  //   label: "REJECTED"
  // },
  // {
  //   value: "UPLOADED",
  //   label: "UPLOADED"
  // }
];



export const DECISION_TYPE_LIST = [
  {
    value: "",
    label: "Select"
  },
  {
    value: "1",
    label: "Yes"
  },
  {
    // value: '',
    value: "2",
    label: "No"
  }
];
export const TIMER_SOURCE_HEADER = [
  {
    value: "",
    label: "Select"
  },
  {
    value: "A",
    label: "Application"
  },
  {
    value: "M",
    label: "Member"
  }
];

export const TIMER_SOURCE_TRIGGER_STATUS = [
  {
    value: " ",
    label: "Select"
  },
  {
    value: "A",
    label: "ALL"
  },
  {
    value: "O",
    label: "OPEN"
  },
  {
    value: "C",
    label: "CLOSED"
  }
];



export const STATUS_FLAG = [
  {
    value: "",
    label: "Select"
  },
  {
    value: "A",
    label: "ADD"
  },
  {
    value: "U",
    label: "UPDATE"
  },
  {
    value: "D",
    label: "DELETE"
  }
];

export const DRUG_EDIT_CODE = [
  {
    value: "",
    label: "Select"
  },
  {
    value: "PS1",
    label: "PS1"
  },
  {
    value: "PS2",
    label: "PS2"
  }
];

export const PRESCRIBER_LIMITATION_STATUS = [
  {
    value: "",
    label: ""
  },
  {
    value: "Yes",
    label: "Yes"
  },
  {
    value: "No",
    label: "No"
  }
];

export const PHARMACY_LIMITATION_STATUS = [
  {
    value: "",
    label: ""
  },
  {
    value: "Yes",
    label: "Yes"
  },
  {
    value: "No",
    label: "No"
  }
];

export const HINT1_LIST = [
  {
    value: "",
    label: "where were you born?"
  },
  {
    value: "",
    label: "what was your first car?"
  },
  {
    value: "",
    label: "What is your favourite color?"
  }
];

export const HINT2_LIST = [
  {
    value: "",
    label: "what country do you like to visit?"
  },
  {
    value: "",
    label: "in what year was your mother born"
  },
  {
    value: "",
    label: "What is your father's middle name?"
  }
];

export const HINT3_LIST = [
  {
    value: "",
    label: "What is your mother's middle name?"
  },
  {
    value: "",
    label: "what was your high school mascot?"
  },
  {
    value: "",
    label: "what country do you like to visit?"
  }
];


export const REASSIGNMENT_TYPE = [
  {
    value: "",
    label: "Select"
  },
  {
    value: "All to User",
    label: "All to User"
  }
];
//Remove
export const QUEUES_LIST = [
  {
    value: "",
    label: "Select"
  },
  {
    value: "CRIT APP ERR",
    label: "CRIT APP ERR"
  }
];

//remove
export const NEW_USER = [
  {
    value: "",
    label: "Select"
  },
  {
    value: "Test",
    label: "Test"
  }
];
//remove
export const SUPERVISOR_STATUS = [
  {
    value: "A",
    label: "Active"
  },
  {
    value: "I",
    label: "Inactive"
  }
];
