export const INITIAL_STATE = {
    lastName: "",
    memberId: "",
    invoiceNo: "",
    invoiceStatus: "",
    medicareId: "",
    invoiceGroup: "",
    invoiceType: "",
    supplementalId: "",
    batchdate: "",
    batchseqnumbr: "",
    balance: "",
    source: "",
    bankaccntcd: "",
    balanceamount: "",
    detailamnt: "",
    batchind: "",
    batchposind: "",
    batchdetailcnt: "",
    posted: "",
    memberid: "",
    itemnumber: "",
    duedate: "",
    checkdate: "",
    checknbr: "",
    paymentAmt: ""

}

export const POSTED_IND = [
    {
        value: '',
        label: 'Select'
    },
    {
        value: 'Y',
        label: 'Yes',
    },
    {
        value: 'N',
        label: 'No',
    }
]


export const BALANCE_LIST = [
    {
        value: '',
        label: 'Select',
    },
    {
        value: 'Y',
        label: 'Yes',
    },
    {
        value: 'N',
        label: 'No',
    }
]
