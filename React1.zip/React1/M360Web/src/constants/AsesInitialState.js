export  const INITIAL_STATE ={  
    effStartDate:'',
    effEndDate:'',
    ODSIFamID:'',
    MbrSuffix:'',
   // planVer:'',
    MPI:'',
    mediIndicator:'',
    status:'',
    planVsrChnge:'',
    regionCode: '',


//     "createTime": "2020-06-15 13:51:48.00042",
// "createUserId": "SR0232D",
// "customerId": "HCF0281",
// "lastUpdtTime": "2020-06-15 13:51:48.00042",
// "lastUpdtUserId": "SR0232D",
// "showAll": null,
// "memberId": "C00513574",
// "effStartDate": "20200601",
// "effEndDate": "99999999",
// "overrideInd": "N",
// "odsiFamilyId": "dev13",
// "mbrSuffix": "de",
 "planVersion": "001",
// "mpi": "dev13",
// "medicaidInd": "Y",
// "planVersionChangeInd": "Y",
// "status": "ASESENRRJC",
// "regionCode": "",
// "costSharing": "",
// "maxCopy": "",
// "extFlag": "",
// "spendDwnFlg": "",
// "grpCd": "",
// "deceasedDt": "",
// "type": null,
// "effStartDateFrmt": "06/01/2020",
// "effEndDateFrmt": "99/99/9999"
    
}


export const ASES_STATUS_LIST =[
    {
        value: '',
        label: 'Select',
    },
    
    {
        value: 'ASESELGAPR',
        label: 'ASESELGAPR',
    }, 
    {
        value: 'ASESELGPND',
        label: 'ASESELGPND',
    }, 
    {
        value: 'ASESELGRJC',
        label: 'ASESELGRJC',
    }, 
    {
        value: 'ASESENRAPR',
        label: 'ASESENRAPR',
    }, 
    {
        value: 'ASESENRPND',
        label: 'ASESENRPND',
    }, 
    {
        value: 'ASESENRRJC',
        label: 'ASESENRRJC',
    }, 
    {
        value: 'ASESENRSUB',
        label: 'ASESENRSUB',
    } 
]

export const ASES_PLAN_VERSION =[
    {
        value: '001',
        label: '001',
    }, 
    {
        value: '002',
        label: '002',
    },
    {
        value: '003',
        label: '003',
    }, 
    {
        value: '004',
        label: '004',
    },
    {
        value: '005',
        label: '005',
    }, 
    {
        value: '006',
        label: '006',
    },
    {
        value: '007',
        label: '007',
    }, 
    {
        value: '008',
        label: '008',
    },
    {
        value: '011',
        label: '011',
    }, 
    {
        value: '012',
        label: '012',
    },
    {
        value: '013',
        label: '013',
    }, 
    {
        value: '014',
        label: '014',
    },
    {
        value: '015',
        label: '015',
    }, 
    {
        value: '016',
        label: '016',
    },
    {
        value: '017',
        label: '017',
    }, 
    {
        value: '018',
        label: '018',
    },
    {
        value: '019',
        label: '019',
    }, 
    {
        value: '020',
        label: '020',
    }
]

export const ASES_SELECT =[
    {
        value: '',
        label: 'Select',
    }, 
    {
        value: 'Y',
        label: 'Y',
    }, 
    {
        value: 'N',
        label: 'N',
    }
]