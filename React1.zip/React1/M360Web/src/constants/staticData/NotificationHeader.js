export const NOTIFICATION_HEADER = [
  {
    label: "Time",
    title: "Time",
    key: "notifTimeStamp"
  },
  {
    label: "Title",
    title: "Title",
    key: "msgTitle"
  }
];
