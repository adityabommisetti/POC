
export const PREFIX_LIST = [
    
    {
        value: '1',
        label: 'DR',
    },
    {
       // value: 'BILL',
        value: '2',
        label: 'MS',
    },
    {
        value: '3',
        label: 'MRS',
    },
  
    
]

export const STATUS_LIST = [
    
    {
        value: 'SUCCESS',
        label: '200',
    },
    {
       // value: '',
        value: 'FAILED',
        label: '404',
    },
 
    
]

export const MARITAL_STATUS_LIST = [
    
    {
        value: '1',
        label: 'MARRIED',
    },
    {
       // value: '',
        value: '2',
        label: 'SINGLE',
    },
 
    
]

export const RACE_LIST = [
    
    {
        value: '1',
        label: 'WHITE',
    },
    {
       // value: '',
        value: '2',
        label: 'BLACK',
    },
 
    
]

export const LANGUAGE_LIST = [
    
    {
        value: '1',
        label: 'ENGLISH',
    },
    {
       // value: '',
        value: '2',
        label: 'SPANISH',
    },
 
    
]


export const SPOUSEWORK_LIST = [
    
    {
        value: '1',
        label: 'Y',
    },
    {
       // value: '',
        value: '2',
        label: 'N',
    },
 
    
]

export const ACCESSIBLE_LIST = [
    
    {
        value: '1',
        label: 'None',
    },
    {
       // value: '',
        value: '2',
        label: 'Data',
    },
 
    
]

export const RELATIONSHIP_LIST = [
    
    {
        value: '1',
        label: 'Son',
    },
    {
       // value: '',
        value: '2',
        label: 'Daughter',
    },
 
    
]

export const GENDER_LIST = [
    
    {
        value: '1',
        label: 'MALE',
    },
    {
       // value: '',
        value: '2',
        label: 'FEMALE',
    },
 
    
]

export const CORRESPONDENCE_METHOD_LIST = [

    {
        value: '1',
        label: 'AudioTape',
    },
    {
       // value: '',
        value: '2',
        label: 'Braille',
    },
 

]


export const BILL_PAY_METHOD = [
    {
        label: 'C - Credit Card',
        value: 'C',
    },

    {
        label: 'D - Draft',
        value: 'D',
    },
    {
        label: 'O - Other (Check, Cash, Money order)',
        value: 'O',
    },
    {
        label: 'P - Pension',
        value: 'P',
    },
    {
        label: 'S - SSA',
        value: 'S',
    },
]




export const BILLING_FREQ = [
    {
        label: 'A - Annually',
        value: 'A',
    },

    {
        label: 'M - Monthly',
        value: 'M',
    },
    {
        label: 'Q - Quarterly',
        value: 'Q',
    },
    {
        label: 'S - Semi Annually',
        value: 'S',
    },
    {
        label: '',
        value: '',
    },
]


export const ACC_TYPE = [
    {
        value: ' ',
        label: '',
    },
    {
        value: 'C',
        label: 'Checking',
    },
    {
        value: 'S',
        label: 'Saving',
    }
]


export const COB_TYPE = [
    {
        value: ' ',
        label: '',
    },
    {
        value: 'P',
        label: 'Primary',
    },
    {
        value: 'S',
        label: 'secondary',
    }
]