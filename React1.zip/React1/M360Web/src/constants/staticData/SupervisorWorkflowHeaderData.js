export const ATRISK_HEADER= [
    {
      label: "Days Left",
      title: "Days Left",
      key: "daysRemaining"
    },
    {
      label: "Priority",
      title: "Priority",
      key: "queuePrtyFrmt"
    },
    {
      label: "Case Desc",
      title: "Case Desc",
      key: "queueName"
    },
    
    /*{
      label: "Queue Type",
      title: "Queue Type",
      key: "queueName"
    },*/
  
    {
      label: "Count",
      title: "Count",
      key: "count"
    },
  ];

  export const ATRISK_SELECT_HEADER= [
    {
      label: "Supervisor",
      title: "Supervisor",
      key: "supervisorName"
    },
    {
      label: "User Name",
      title: "User Name",
      key: "userName"
    },

    {
      label: "Priority",
      title: "Priority",
      key: "queuePrtyFrmt"
    },
    {
      label: "Days Left",
      title: "Days Left",
      key: "daysRemaining"
    },
    {
      label: "Due Date",
      title: "Due Date",
      key: "caseDueDateFrmt"
    },
    
    /*{
      label: "Queue Type",
      title: "Queue Type",
      key: "queueName"
    },*/
  
    {
      label: "Medicare Id",
      title: "Medicare Id",
      key: "medicareId"
    },
    {
      label: "Cust Name",
      title: "Cust Name",
      key: "memberName"
    },
    {
      label: "Case Desc",
      title: "Case Desc",
      key: "caseDesc"
    },
  ];