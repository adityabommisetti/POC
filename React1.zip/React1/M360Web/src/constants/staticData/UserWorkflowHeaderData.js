export const CASES_HEADER = [
  {
    label: "Days Left",
    title: "Days Left",
    key: "daysRemaining"
  },
  {
    label: "Source",
    title: "Source",
    key: "source"
  },
  {
    label: "Case Date",
    title: "Case Date",
    key: "caseDateFrmt"
  },

  {
    label: "Due Date",
    title: "Due Date",
    key: "caseDueDateFrmt"
  },
  {
    label: "Case ID",
    title: "Case ID",
    key: "caseId"
  },
  {
    label: "Medicare ID",
    title: "Medicare ID",
    key: "medicareId"
  },
  {
    label: "Application Status",
    title: "Application Status",
    key: "applicationStatus"
  },
  {
    label: "Name",
    title: "Name",
    key: "mbrName"
  },
  {
    label: "Case Desc",
    title: "Case Desc",
    key: "caseDesc"
  },
  {
    label: "Case Status",
    title: "Case Status",
    key: "caseStatus"
  },
  {
    label: "Assigned To",
    title: "Assigned To",
    key: "firstName"
  },
  {
    label: "Work Item Comment",
    title: "Work Item Comment",
    key: "WorkItemComment"
  },
  {
    label: "Transfer the Work Item",
    title: "Transfer the Work Item",
    key: "TTWI"
  }
];

export const ACTIVITIES_HEADER = [
  {
    label: "Activity Desc",
    title: "Activity Desc",
    key: "activityDesc"
  },
  {
    label: "Error Id",
    title: "Error Id",
    key: "errorId"
  },
  {
    label: "Activity Status",
    title: "Activity Status",
    key: "activityStatus"
  },
  {
    label: "",
    title: "",
    key: ""
  }
];
