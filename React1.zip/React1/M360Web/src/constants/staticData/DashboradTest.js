export const Dashlet_LIST = [
  "Pre-Enrollment Status",
  "Application Aging ",
  "Membership Distribution",
  "Application Distribution",
  "LIS Distribution",
  "Special Status Distribution",
  "Letters Volume Distribution",
  "File Load And Error Distribution",
  "RFI Tracking",
  "CMS Status",
  "Pending Transaction To CMS",
];

export const Enrollment_data = {
  labels: ["A", "B", "C"],
  datasets: [
    {
      data: [300, 50, 100],
      backgroundColor: ["#FF6384", "#36A2EB", "#FFCE56"],
      hoverBackgroundColor: ["#FF6384", "#36A2EB", "#FFCE56"],
    },
  ],
};
export const Aging_data = {
  labels: ["Data1", "Data2", "Data3"],
  datasets: [
    {
      data: [30, 40, 100, 20, 420],
      backgroundColor: ["#FF6384", "#36A2EB", "#FFCE56"],
      hoverBackgroundColor: ["#FF6384", "#36A2EB", "#FFCE56"],
    },
  ],
};

export const MemberShip_data = {
  labels: ["January", "February", "March", "April", "May", "June", "July"],
  datasets: [
    {
      label: "Dataset 1",
      backgroundColor: [
        "#EC407A",
        "#AB47BC",
        "#42A5F5",
        "#7E57C2",
        "#66BB6A",
        "#FFCA28",
        "#26A69A",
      ],
      yAxisID: "y-axis-1",
      data: [65, 59, 80, 81, 56, 55, 10],
    },
    {
      label: "Dataset 2",
      backgroundColor: "#78909C",
      yAxisID: "y-axis-2",
      data: [28, 48, 40, 19, 86, 27, 90],
    },
  ],
};
