export const SUPERVISOR_DATA = [
  {
    UserId: "RG0232T",
    LastName: "G",
    FirstName: "SDSR",
    UserStatus: "Active",
    Priority1: "INCOMPLETE/PERR",
    Priority2: "",
    Priority3: "",
    Priority4: "",
    Other: ""
  },
  {
    UserId: "RG0232T",
    LastName: "G",
    FirstName: "SDSR",
    UserStatus: "Active",
    Priority1: "INCOMPLETE/PERR",
    Priority2: "",
    Priority3: "",
    Priority4: "",
    Other: ""
  },
  {
    UserId: "RG0232T",
    LastName: "G",
    FirstName: "SDSR",
    UserStatus: "Active",
    Priority1: "INCOMPLETE/PERR",
    Priority2: "",
    Priority3: "",
    Priority4: "",
    Other: ""
  },
  {
    UserId: "RG0232T",
    LastName: "G",
    FirstName: "SDSR",
    UserStatus: "Active",
    Priority1: "INCOMPLETE/PERR",
    Priority2: "",
    Priority3: "",
    Priority4: "",
    Other: ""
  },
  {
    UserId: "RG0232T",
    LastName: "G",
    FirstName: "SDSR",
    UserStatus: "Active",
    Priority1: "INCOMPLETE/PERR",
    Priority2: "",
    Priority3: "",
    Priority4: "",
    Other: ""
  }
];

export const SHOW_USERS_DATA = [
  {
    supervisorId: "NND001",
    supervisorName: "Nandagopalan Nataraj",
    userId: "JMD001",
    userName: "Manchini Jeffery",
    userAccess: "1"
  },
  {
    supervisorId: "NND002",
    supervisorName: "Nandagopalan",
    userId: "JMD002",
    userName: "Jeff",
    userAccess: "1"
  },
  {
    supervisorId: "NND003",
    supervisorName: "Nataraj",
    userId: "JMD003",
    userName: "Manchini ",
    userAccess: "1"
  },
  {
    supervisorId: "NND004",
    supervisorName: "gopalan",
    userId: "JMD004",
    userName: " Jeffery",
    userAccess: "1"
  }
];
export const AccessLevels = [
  {
    value: "",
    label: "Select"
  },
  {
    value: "1",
    label: "ADMIN"
  },
  {
    value: "2",
    label: "SUPERVISOR"
  },
  {
    value: "3",
    label: "USER"
  },
  {
    value: "4",
    label: "NO ACCESS"
  }
];
export const supervisors = [
  {
    value: "SUPERVISOR1",
    label: "SUPERVISOR1"
  },
  {
    value: "SUPERVISOR2",
    label: "SUPERVISOR2"
  },
  {
    value: "SUPERVISOR3",
    label: "SUPERVISOR3"
  },
  {
    value: "SUPERVISOR4",
    label: "SUPERVISOR5"
  },
  {
    value: "SUPERVISOR6",
    label: "SUPERVISOR6"
  }
];
export const ROLES = [
  {
    value: "",
    label: "Select"
  },
  {
    value: "3",
    label: "User"
  },
  {
    value: "2",
    label: "Supervisor"
  },
 
];
