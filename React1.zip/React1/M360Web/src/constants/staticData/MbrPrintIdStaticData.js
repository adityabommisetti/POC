export const PRINTID_QUESTIONS_SET1 = [
  {
    label: "NEW MEMBER KIT",
    value: "100",
  },
  {
    label: "ANOC",
    value: "101",
  },
  {
    label: "PROVIDER DIRECTORY",
    value: "102",
  },
  {
    label: "EOC",
    value: "103",
  },
  {
    label: "DENTAL DIRECTORIES",
    value: "104",
  },
  {
    label: "FORMULARY",
    value: "105",
  },

  {
    label: "VISION DIRECTORY",
    value: "106",
  },
  {
    label: "NEW ID CARD",
    value: "5",
  },
  {
    label: "PCP CHANGE ID CARD",
    value: "6",
  },
  {
    label: " REPLACEMENT ID",
    value: "7",
  },
];
export const PRINTID_QUESTIONS_SET2 = [
  {
    label: "ID CARD PRINT",
    value: "1",
  },
  {
    label: "PROVIDER DIRECTORY PRINT",
    value: "101",
  },
  {
    label: "ID CARD PRINT AND PROVIDER DIRECTORY PRINT",
    value: "3",
  },
  {
    label: "E-DELIVERY FOR BOTH",
    value: "4",
  },
];

export const PRINTID_ADDITIONAL_QUESTIONS = [
  {
    label: "NEW ID CARD",
    value: "5",
  },
  {
    label: "PCP CHANGE ID CARD",
    value: "6",
  },
  {
    label: "REPLACEMENT ID CARD",
    value: "7",
  },
];
