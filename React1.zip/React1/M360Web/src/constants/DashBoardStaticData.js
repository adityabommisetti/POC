export const AGG_DATA = [
  {
    customerId: "HCF251",
    agreementId: "12345",
    agreementTimeStamp: "2014-01-06 05:40:08.76",
    applicationId: "1669",
    memeberId: "C0000000499",
    agreementNbr: "87512587",
    hicNbr: "999012049A",
    groupId: "01430315",
    agreementDate: "20131217",
    agreementDueDate: "20131224",
    dateComplete: "20140106",
    daysReamaining: 2,
    agreementDesc: "ELECTION ERRORS ",
    agreementStatus: "CLOSED",
    riskInd: "N",
    name: "WENDY MARIA",
    source: "BATCH",
    aggreCompUser: "DEVELOP01",
    aggreCompDate: "20140106",
    orgQuePerAggrement: 2,
    remQuePerAggreement: 0,
    overideInd: "N",
    lastUpdtUserId: "M6MBW001",
    lastUpdtTime: "2014-04-01 05:02:30.105599",
    mbiNbr: "9W19PR0CA52"
  }, {
    customerId: "HCF001",
    agreementId: "231562",
    agreementTimeStamp: "2014-01-06 05:40:08.76",
    applicationId: "1619",
    memeberId: "C0000000499",
    agreementNbr: "87867587",
    hicNbr: "9912650049A",
    groupId: "01945315",
    agreementDate: "20131217",
    agreementDueDate: "20131224",
    dateComplete: "20140106",
    daysReamaining: 2,
    agreementDesc: "ELECTION ERRORS ",
    agreementStatus: "CLOSED",
    riskInd: "N",
    name: "WENDY MARIA",
    source: "BATCH",
    aggreCompUser: "DEVELOP01",
    aggreCompDate: "20140106",
    orgQuePerAggrement: 2,
    remQuePerAggreement: 0,
    overideInd: "N",
    lastUpdtUserId: "M6MBW001",
    lastUpdtTime: "2014-04-01 05:02:30.105599",
    mbiNbr: "9W18PR0CA52"
  }
  , {
    customerId: "HCFL640",
    agreementId: "33333",
    agreementTimeStamp: "2014-01-06 05:40:08.76",
    applicationId: "1069",
    memeberId: "C0000000499",
    agreementNbr: "87500587",
    hicNbr: "946546049A",
    groupId: "01930315",
    agreementDate: "20131217",
    agreementDueDate: "20131224",
    dateComplete: "20140106",
    daysReamaining: 2,
    agreementDesc: "ELECTION ERRORS ",
    agreementStatus: "CLOSED",
    riskInd: "N",
    name: "WENDY MARIA",
    source: "BATCH",
    aggreCompUser: "DEVELOP01",
    aggreCompDate: "20140106",
    orgQuePerAggrement: 2,
    remQuePerAggreement: 0,
    overideInd: "N",
    lastUpdtUserId: "M6MBW001",
    lastUpdtTime: "2014-04-01 05:02:30.105599",
    mbiNbr: "9W19PR0CA53"
  },
  {
    customerId: "HCFLCS4",
    agreementId: "55555",
    agreementTimeStamp: "2014-01-06 05:40:08.76",
    applicationId: "1669",
    memeberId: "C0000000499",
    agreementNbr: "87547587",
    hicNbr: "999478949A",
    groupId: "019154515",
    agreementDate: "20131217",
    agreementDueDate: "20131224",
    dateComplete: "20140106",
    daysReamaining: 2,
    agreementDesc: "ELECTION ERRORS ",
    agreementStatus: "CLOSED",
    riskInd: "N",
    name: "WENDY MARIA",
    source: "BATCH",
    aggreCompUser: "DEVELOP01",
    aggreCompDate: "20140106",
    orgQuePerAggrement: 2,
    remQuePerAggreement: 0,
    overideInd: "N",
    lastUpdtUserId: "M6MBW001",
    lastUpdtTime: "2014-04-01 05:02:30.105599",
    mbiNbr: "9W19PR0CA55"
  }
];

export const AGG_HEADER = [
  {
    label: "AGREEMENT_ID",
    title: "AGREEMENT_ID",
    name: "AGREEMENT_ID",
    prop: "agreementId",
    key: "agreementId"
  },
  {
    label: "APPLICATION ID",
    title: "APPLICATION ID",
    key: "applicationId",
    name: "APPLICATION ID",
    prop: "applicationId"
  },
  {
    label: "MEMBER ID",
    title: "MEMBER ID",
    key: "memeberId",
    name: "MEMBER ID",
    prop: "memeberId"
  },
  {
    label: "AGREEMENT NBR",
    title: "AGREEMENT NBR",
    name: "AGREEMENT NBR",
    prop: "agreementNbr",
    key: "agreementNbr"
  },
  {
    label: "HIC NBR",
    title: "HIC NBR",
    name: "HIC NBR",
    prop: "hicNbr",
    key: "hicNbr"
  },
  {
    label: "GROUP ID",
    title: "GROUP ID",
    name: "GROUP ID",
    prop: "groupId",
    key: "groupId"
  },
  {
    label: "AGREEMENT DATE",
    title: "AGREEMENT DATE",
    name: "AGREEMENT DATE",
    prop: "agreementDate",
    key: "agreementDate"
  }
]






