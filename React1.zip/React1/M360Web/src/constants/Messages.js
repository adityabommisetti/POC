export const messages = {
  UPDATED_SUCCESSFULLY: "Updated Successfully",
  DELETED_SUCCESSFULLY: "Deleted Successfully",
  INSERTED_SUCCESSFULLY: "Added Successfully",
  COPIED_SUCCESSFULLY: "Copied Successfully",
  UPDATION_FAILED: "Failed to Update Record!!",
  DELETION_FAILED: "Failed to Delete Record!!",
  INSERTION_FAILED: "Failed to Add Record!!",
  COPY_FAILED: "Failed to copy!!",
  REQ_DATE_COVERAGE: "Request date of coverage is required!",
};
