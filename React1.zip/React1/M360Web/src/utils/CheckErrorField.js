import isEmpty from "lodash/isEmpty";
const checkErrorField = (name, searchResults) => {
  const errList = !isEmpty(searchResults) ? searchResults.applErrList : [];
  const array = errList.filter((object) => object.formField === name);
  return array.length > 0;
};

export const checkErrorField1 = (name, searchResults) => {
  const errList = !isEmpty(searchResults) ? searchResults.applErrList : [];
  const array = errList.filter((object) => object.formField === name);
  if (name === "electionType") {
    // debugger
  }
  return array.length === 1;
};
export default checkErrorField;
