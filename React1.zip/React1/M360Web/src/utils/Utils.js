const formatTimeStamp = (time) => {
  let frmtTimeStamp = time;
  if (time && time.length > 18 && time.split("-")[0].length === 4) {
    frmtTimeStamp =
      time.substring(5, 10) +
      "-" +
      time.substring(0, 4) +
      " " +
      time.substring(11, 19);
  }

  return frmtTimeStamp;
};

export const formatFullTimeStamp = (time) => {
  let fullTimeStamp = time;
  if (time && time.length > 18 && time.split("-")[0].length === 4) {
    fullTimeStamp =
      time.substring(5, 10) +
      "-" +
      time.substring(0, 4) +
      " " +
      time.substring(11, time.length);
  }
  return fullTimeStamp;
};

export default formatTimeStamp;
