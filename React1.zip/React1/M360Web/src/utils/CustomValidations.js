import moment from "moment";
import isEmpty from "lodash/isEmpty";

export const customValidations = {
  date_after: {
    // name the rule
    message: ":attribute should be greater than start date.",
    rule: (val, params, validator) => {
      if (val === "99/99/9999") {
        return true;
      }
      const startDate = params[0];
      return moment(val).isAfter(startDate);
    },
  },

  date_after_today: {
    // name the rule
    message: ":attribute cannot be earlier than current date.",
    rule: (val, params, validator) => {
      const date =moment().subtract(1, 'days')
      return moment(val).isAfter(date);
    },
  },
  date_format: {
    message: "Invalid date. Please format as MM/DD/YYYY",
    rule: (val, params, validator) => {
      if (
        val === "" ||
        val === null ||
        val === undefined ||
        val === "99/99/9999"
      ) {
        return true;
      }
      return moment(val, "MM/DD/YYYY", true).isValid();
    },
  },
  date_format_null: {
    message: "Invalid date. Please format as MM/DD/YYYY",
    rule: (val, params, validator) => {
      if (val === "" || val === null || val === undefined) {
        return true;
      }
      return moment(val, "MM/DD/YYYY", true).isValid();
    },
  },
  date_format99: {
    message: "Invalid date. Please format as MM/DD/YYYY",
    rule: (val, params, validator) => {
      if (val === "99/99/9999") {
        return true;
      }
      return moment(val, "MM/DD/YYYY", true).isValid();
    },
  },
  phone_no: {
    // name the rule
    message: "Please enter valid 10 digit number.",
    rule: (val, params, validator) => {
      val = val.replace(/[^0-9]/g, "")
      if(val.length !== 10){
        return false
      }
      return true;
    },
  },

  c_after_or_equal_99: {
    // name the rule
    message: ":attribute should be greater than or equal to :date",
    rule: (val, params, validator) => {
      if (val === "99/99/9999") {
        return true;
      }
      return moment(val).isSameOrAfter(params[0]);
    },
    messageReplace: (message, params) => {
      return message.replace(":date", params[0]);
    },
  },
  c_after_or_equal: {
    // name the rule
    message: ":attribute should be greater than or equal to :date",
    rule: (val, params, validator) => {
      return moment(val).isSameOrAfter(params[0]);
    },
    messageReplace: (message, params) => {
      return message.replace(":date", params[0]);
    },
  },
  c_after: {
    // name the rule
    message: ":attribute should be greater than :date",
    rule: (val, params, validator) => {
      return moment(val).isAfter(params[0]);
    },
    messageReplace: (message, params) => {
      return message.replace(":date", params[0]);
    },
  },
  c_after99: {
    // name the rule
    message: ":attribute should be greater than :date",
    rule: (val, params, validator) => {
      if (val === "99/99/9999") {
        return true;
      }
      return moment(val).isAfter(params[0]);
    },
    messageReplace: (message, params) => {
      return message.replace(":date", params[0]);
    },
  },
  c_date_before: {
    message: ":attribute should be less than :date",
    rule: (val, params, validator) => {
      return moment(val).isBefore(params[0]);
    },
    messageReplace: (message, params) => {
      return message.replace(":date", params[0]);
    },
  },
  c_date_before_or_equal: {
    message: ":attribute should be less than or equal to :date",
    rule: (val, params, validator) => {
      return moment(val).isSameOrBefore(params[0]);
    },
    messageReplace: (message, params) => {
      return message.replace(":date", params[0]);
    },
  },

  amountValidator: {
    message: ":attribute is not valid.",
    rule: (val, params, validator) => {
      let regex = /^\s*-?(\d+(\.\d+)?|\.\d+)\s*$/;
      if (!regex.test(val)) {
        return false;
      } else {
        return true;
      }
    },
  },

  ValidSSN: {
    message: "Invalid SSN Format nnn-nn-nnnn",
    rule: (val, params, validator) => {
      if (val.length === 11) {
        if (isFinite(val.substring(0, 3))) {
          if (val.charAt(3) === "-") {
            if (isFinite(val.substring(4, 6))) {
              if (val.charAt(6) === "-") {
                if (isFinite(val.substring(7))) {
                  return true;
                }
              }
            }
          }
        }
      }
      return false;
    },
  },

  first_day_of_month: {
    message: ":attribute should be first day of month",
    rule: (val, params, validator) => {
      if (moment(val, "MM/DD/YYYY", true).isValid()) {
        return moment(val, "MM/DD/YYYY").date() === 1;
      }
      return true;
    },
  },
  last_day_of_month99: {
    message: ":attribute should be last day of month",
    rule: (val, params, validator) => {
      if (val === "99/99/9999") {
        return true;
      }
      if (moment(val, "MM/DD/YYYY", true).isValid()) {
        if (
          moment(val, "MM/DD/YYYY").date() !==
          getLastDayOfYearAndMonth(
            moment(val, "MM/DD/YYYY").year(),
            moment(val, "MM/DD/YYYY").month()
          )
        ) {
          return false;
        }
      }
      return true;
    },
  },
  last_day_of_month: {
    message: ":attribute should be last day of month",
    rule: (val, params, validator) => {
      if (moment(val, "MM/DD/YYYY", true).isValid()) {
        if (
          moment(val, "MM/DD/YYYY").date() !==
          getLastDayOfYearAndMonth(
            moment(val, "MM/DD/YYYY").year(),
            moment(val, "MM/DD/YYYY").month()
          )
        ) {
          return false;
        }
      }
      return true;
    },
  },
  CountryUSA: {
    message: "Primary Address Must be in US",
    rule: (val, params, validator) => {
      if (val.trim() !== "USA" && val.trim() !== "US") {
        return false;
      }
    }
  },
  date_conflict_uncov: {
    message: "Date conflicts. Time Period :from to :to is already exist in system. \n Please provide valid start date",
    rule: (val, params, validator) => {
      const date = params[0];
      const data = params[1];
      if (
        moment(val, "MM/DD/YYYY", true).isValid() &&
        moment(date, "MM/DD/YYYY", true).isValid()
      ) {
        for (var i = 0; i < data.length; i++) {
          if (
            moment(val).isBetween(
              data[i].uncovMthStDtFrmt,
              data[i].uncovMthEndDtFrmt
            ) ||
            moment(date).isBetween(
              data[i].uncovMthStDtFrmt,
              data[i].uncovMthEndDtFrmt
            ) ||
            moment(data[i].uncovMthStDtFrmt).isBetween(val, date) ||
            moment(data[i].uncovMthEndDtFrmt).isBetween(val, date)
          ) {
            return false;
          }
        }
      }
      return true;
    },
    messageReplace: (message, params) => {
      return message.replace(":from",params[2]).replace(":to",params[0]);
    },
   
   
  },
  date_conflict_ccf: {
    message: "Date conflicts, Please provide valid start date",
    rule: (val, params, validator) => {
      const date = params[0];
      const data = params[1];
      if (
        moment(val, "MM/DD/YYYY", true).isValid() &&
        moment(date, "MM/DD/YYYY", true).isValid()
      ) {
        for (var i = 0; i < data.length; i++) {
          if (
            moment(val).isBetween(data[i].fromDateFrmt, data[i].toDateFrmt) ||
            moment(date).isBetween(data[i].fromDateFrmt, data[i].toDateFrmt) ||
            moment(data[i].fromDateFrmt).isBetween(val, date) ||
            moment(data[i].toDateFrmt).isBetween(val, date)
          ) {
            return false;
          }
        }
      }
      return true;
    },
  },
  check_Date: {
    message: "Received Date cannot be future date",
    rule: (val, params, validator) => {
      var date = moment(val, "MM/DD/YYYY");
      if (moment() > date) {
        return true;
      } else {
        return false;
      }
    },
  },
  date_formats: {
    message: ":attribute is incorrect \n Please format as MM/DD/YYYY",
    rule: (val, params, validator) => {
      if (val === "99/99/9999") {
        return true;
      }
      if (!moment(val, "MM/DD/YYYY", true)) {
        return false;
      }
    },
  },
  received_date_180: {
    message: ":attribute cannot be Past 180 days for plan :MA/MAPD",
    rule: (val, params, validator) => {
      const date = val;
      const plan = params[0];
      if (
        (plan === "MAPD" || plan === "MA") &&
        moment().diff(date, "days") <= 180
      ) {
        return true;
      } else {
        return false;
      }
    },
  },

  draft_day: {
    message: ":attribute must be between 1 and 28",
    rule: (val, params, validator) => {
      if (val < 1 || val > 28) {
        return false;
      }
    },
  },

  received_date_363: {
    message: ":attribute cannot be Past 363 days for plan :PDP",
    rule: (val, params, validator) => {
      const date = val;
      const plan = params[0];
      if (plan === "PDP" && moment().diff(date, "days") <= 363) {
        return true;
      } else {
        return false;
      }
    },
  },
// pos
  enrolment_period: {
    message: ":attribute should be within active enrollment period",
    rule: (val, params, validator) => {
      // const eStartDate = val[2];
      var eStartDate = moment(params[0]).subtract(1, "day");
      const eEndDate = params[1];
      let date = eEndDate;
      if (params[3] === "") {
        return true;
      }
      if (eEndDate === "99/99/9999") {
        date = "09/09/9999";
      }
      return moment(params[3]).isBetween(eStartDate, date);
    }
  },
  CCM_60days: {
    message: ":attribute Date cannot be greater than CCM + 60 days",
    rule: (val, params, validator) => {
      //  const eEndDate = val[3];
      //let date = eEndDate;
      if (params[0] === "") {
        return true;
      }
      let diffDays = 0;
      if (typeof params[0] === "string") {
        const mm = params[1].substring(0, 2);
        const yy = params[1].substring(6, 10);
        const dd = params[1].substring(3, 5);

        const date1 = new Date(mm + "/" + dd + "/" + yy);
        const emm = params[0].substring(0, 2);
        const eyy = params[0].substring(6, 10);
        const edd = params[0].substring(3, 5);
        const date2 = new Date(emm + "/" + edd + "/" + eyy);
        const diffTime = Math.abs(date2 - date1);
        diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      }
      return diffDays <= 60;
    }
  },
  date_after_notificationd: {
    // name the rule
    message: ":attribute should be greater than start date.",
    rule: (val, params, validator) => {
      if (params[1] === "") {
        return true;
      }
      const startDate = params[0];
      const endDate = params[1];
      return moment(endDate).isAfter(startDate);
    }
  },
  Notification_End_Date: {
    message:
      ":attribute should be between 30-59 days of the Notification Start Date.",
    rule: (val, params, validator) => {
      if (params[1] === "") {
        return true;
      }
      var startDate = moment(params[0]);
      var endDate = moment(params[1]);
      var result = Math.abs(endDate.diff(startDate, "days"));
      return result >= 29 && result <= 59;
    }
  },
  Notification_End_Date_ImplSDate: {
    // 10/03/2019  >   10/02/2019
    message: ":attribute should be less than Implementation Start Date",
    rule: (val, params, validator) => {
      const iStartDate = params[1];
      const nEndDate = params[0];
      if (iStartDate === "" || nEndDate === "") {
        return true;
      } else {
        return iStartDate >= nEndDate;
      }
    }
  },
  Implementation_Start_Date: {
    // estartDate 02/01/2019
    message:
      ":attribute should be between 31-60 days of the Notification Start Date.",
    rule: (val, params, validator) => {
      var iStartDate = moment(val).add(1, "day"); //moment(val[0]);
      var notificationStartDate = moment(params[0]);
      var result = Math.abs(iStartDate.diff(notificationStartDate, "days"));
      if (!iStartDate.get("year")) {
        return true;
      }
      return result >= 31 && result <= 60;
    }
  },
  drug_Class: {
    // estartDate 02/01/2019
    message: "Drug Edit Class is required when Drug Edit Status is YES",
    rule: (val, params, validator) => {
      // var drugEditStatus = val;
      // var drugEditClass = params[1];
      var drugEditStatus = val[0];
      var drugEditClass = val[1];
      if (drugEditStatus === "Y") {
        return drugEditClass !== "";
      }
      return true;
    }
  },
  drug_Class_No: {
    // estartDate 02/01/2019
    message: "Drug Edit Class is not required when Drug Edit Status is NO",
    rule: (val, params, validator) => {
      var drugEditStatus = val[0];
      var drugEditClass = val[1];
      if (drugEditStatus === "N") {
        return drugEditClass.trim() === ""//!isEmpty(drugEditClass)//drugEditClass.trim() === "";
      }
      return true;
    }
  },
  implementation_Period12: {
    message:
      "If Status flag is Add, then Implementation End date cannot be beyond 12 months",
    rule: (val, params, validator) => {
      const iStartDate = params[0];
      const iEndDate = val;

      if (iEndDate === "") {
        return true;
      }

      var implementationEndDat24MoObj = moment(iStartDate)
        .add(12, "M")
        .format("MM/DD/YYYY");
      if (
        new Date(iEndDate) > new Date(implementationEndDat24MoObj) &&
        params[1] === "A"
      ) {
        return false;
      }
      return true;
    }
  },
  implementation_Period24: {
    message:
      "If Status flag is Update, then Implementation End date cannot be beyond 24 months",
    rule: (val, params, validator) => {
      const iStartDate = params[0];
      const iEndDate = val;

      if (iStartDate === "") {
        return true;
      }

      var implementationEndDat24MoObj = moment(iStartDate)
        .add(24, "M")
        .format("MM/DD/YYYY");

      if (
        new Date(iEndDate) > new Date(implementationEndDat24MoObj) &&
        params[1] === "U"
      ) {
        return false;
      }
      return true;
    }
  },
  drug_Code: {
    // estartDate 02/01/2019
    message: "Drug Edit Code is required when Drug Edit Status is YES",
    rule: (val, params, validator) => {
      var drugEditStatus = val[0];
      var drugCode = val[1];
      if (drugEditStatus === "Y") {
        return drugCode !== "";
      }
      return true;
    }
  },
  drug_Code_No: {
    // estartDate 02/01/2019
    message: "Drug Edit Code is not required when Drug Edit Status is NO",
    rule: (val, params, validator) => {
      var drugEditStatus = val[0];
      var drugCode = val[1];
      if (drugEditStatus === "N") {
        return drugCode === "";
      }
      return true;
    }
  },
  txn_Status: {
    message:
      "Please select Ready for CMS transaction from TXN Status dropdown",
    rule: (val, params, validator) => {
      return val !== "CMSREADY" ? false : true;
    }
  },
  integerType1: {
    // estartDate 02/01/2019
    message: "Application type integer",
    rule: (val, params, validator) => {
     // var sid = params[0];
      var searchId = val[0];
      var sourceType = val[1];
      if(sourceType === "A" &&  (/^\d+$/.test(searchId) || isEmpty(searchId)) ){
        return true;
      }
      if(sourceType === "M"|| sourceType === ""){
        return true;
              }
      return false;
    }
  },
  date_format_MM_YYYY: {
    message: "Invalid date , Please format as MM/YYYY",
    rule: (val, params, validator) => {
      if (
        val === "" ||
        val === null ||
        val === undefined 
      ) {
        return true;
      }
      return moment(val, "MM/YYYY", true).isValid();
    },
  },
};

function getLastDayOfYearAndMonth(year, month) {
  return new Date(new Date(year, month + 1, 1) - 1).getDate();
}
