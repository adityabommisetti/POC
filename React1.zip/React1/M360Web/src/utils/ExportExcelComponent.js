import React, { Component } from 'react';
import ReactExport from 'react-data-export';
import classNames from 'classnames';
import Tooltip from '@material-ui/core/Tooltip';

const ExcelFile = ReactExport.ExcelFile;
const ExcelSheet = ReactExport.ExcelFile.ExcelSheet;
const ExcelColumn = ReactExport.ExcelFile.ExcelColumn;

class ExportExcelComp extends Component {
  render() {
    const { classes } = this.props;

    const colNameArr = this.props.colName;
    let listData = colNameArr.map(header => {
      return <ExcelColumn label={header.title} value={header.key} />;
    });

    return (
      <ExcelFile
        element={
          <Tooltip title='Export to Excel' placement='down'>
            <span className='button'>
              <i
                className={classNames('fa fa-file-excel-o', classes.excelIcon)}
                style={{}}
              ></i>
            </span>
          </Tooltip>
        }
      >
        <ExcelSheet data={this.props.dataSet} name={this.props.fileName}>
          {listData}
        </ExcelSheet>
      </ExcelFile>
    );
  }
}

export default ExportExcelComp;
