import moment from "moment";
import isEmpty from "lodash/isEmpty";
export const validationRules = {
  validators: {
    required: {
      message: ":attribute is required.",
      rule: (val, params, validator) => {
        const value = val[0];
        if (isEmpty(value)) { //  === ""
          return false;
        }
        return true;
      }
    },

    endDateRequired: {
      message: ":attribute is required.",
      rule: (val, params, validator) => {
        const value = val[1];
        if (value === "") {
          return false;
        }
        return true;
      }
    },

    inpuRequired: {
      message: ":attribute is required.",
      rule: (val, params, validator) => {
        const value = val[1];
        if (value) {
          return true;
        } else {
          return false;
        }
      }
    },
    date_after_or_equal: {
      // name the rule
      message: ":attribute should not be past date.",
      rule: (val, params, validator) => {
        if (moment().isAfter(val[0])) {
          return false;
        }
        return true;
      }
    },

    first_day_of_month: {
      message: ":attribute is not the first day of the month",
      rule: (val, params, validator) => {
        const startDate = val[0];
        if (startDate && !(startDate.substring(3, 5) === "01")) {
          return false;
        }
        return true;
      }
    },
    CountryUSA: {
      message: "Primary Address Must be in US",
      rule: (val, params, validator) => {
        if (val.trim() !== "USA" && val.trim() !== "US") {
          return false;
        }
      }
    },
    last_day_of_month: {
      message: "Date should be last day of month",
      rule: (val, params, validator) => {
        if (val.length > 1) {
          if (val[1] === "99/99/9999") {
            return true;
          }
          if (moment(val[1], "MM/DD/YYYY", true).isValid()) {
            if (
              moment(val[1], "MM/DD/YYYY").date() !==
              getLastDayOfYearAndMonth(
                moment(val[1], "MM/DD/YYYY").year(),
                moment(val[1], "MM/DD/YYYY").month()
              )
            ) {
              return false;
            }
          }
        } else {
          if (val[0] === "99/99/9999") {
            return true;
          }
          if (moment(val[0], "MM/DD/YYYY", true).isValid()) {
            if (
              moment(val[0], "MM/DD/YYYY").date() !==
              getLastDayOfYearAndMonth(
                moment(val[0], "MM/DD/YYYY").year(),
                moment(val[0], "MM/DD/YYYY").month()
              )
            ) {
              return false;
            }
          }
        }

        return true;
      }
    },

    date_before: {
      // name the rule
      message: ":attribute should be less than start date.",
      rule: (val, params, validator) => {
        if (val[1] === "99/99/9999") {
          return true;
        }
        const startDate = val[0];
        const endDate = val[1];
        return moment(startDate).isBefore(endDate);
      }
    },

    enrolment_period: {
      message: ":attribute should be within active enrollment period",
      rule: (val, params, validator) => {
        // const eStartDate = val[2];
        var eStartDate = moment(val[2]).subtract(1, "day");
        const eEndDate = val[3];
        let date = eEndDate;
        if (val[4] === "") {
          return true;
        }
        if (eEndDate === "99/99/9999") {
          date = "09/09/9999";
        }
        return moment(val[4]).isBetween(eStartDate, date);
      }
    },
    date_after: {
      // name the rule
      message: ":attribute should be greater than start date.",
      rule: (val, params, validator) => {
        if (val[1] === "99/99/9999") {
          return true;
        }
        const startDate = val[0];
        const endDate = val[1];
        return moment(endDate).isAfter(startDate);
      }
    },
    date_after_notificationd: {
      // name the rule
      message: ":attribute should be greater than start date.",
      rule: (val, params, validator) => {
        if (val[1] === "") {
          return true;
        }
        const startDate = val[0];
        const endDate = val[1];
        return moment(endDate).isAfter(startDate);
      }
    },
    date_format: {
      message: ":attribute is incorrect \n Please format as MM/DD/YYYY",
      rule: (val, params, validator) => {
        if (val[0] === "99/99/9999") {
          return true;
        }
        if (!moment(val[0], "MM/DD/YYYY", true)) {
          return false;
        }
      }
    },

    ValidSSN: {
      message: "Invalid SSN Format nnn-nn-nnnn",
      rule: (val, params, validator) => {
        if (val.length === 11) {
          if (isFinite(val.substring(0, 3))) {
            if (val.charAt(3) === "-") {
              if (isFinite(val.substring(4, 6))) {
                if (val.charAt(6) === "-") {
                  if (isFinite(val.substring(7))) {
                    return true;
                  }
                }
              }
            }
          }
        }
        return false;
      }
    },
    CCM_60days: {
      message: ":attribute Date cannot be greater than CCM + 60 days",
      rule: (val, params, validator) => {
        //  const eEndDate = val[3];
        //let date = eEndDate;
        if (val[4] === "") {
          return true;
        }
        let diffDays = 0;
        if (typeof val[0] === "string") {
          const mm = val[val.length - 1].substring(0, 2);
          const yy = val[val.length - 1].substring(6, 10);
          const dd = val[val.length - 1].substring(3, 5);

          const date1 = new Date(mm + "/" + dd + "/" + yy);
          const emm = val[0].substring(0, 2);
          const eyy = val[0].substring(6, 10);
          const edd = val[0].substring(3, 5);
          const date2 = new Date(emm + "/" + edd + "/" + eyy);
          const diffTime = Math.abs(date2 - date1);
          diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        }
        return diffDays <= 60;
      }
    },

    implementation_Period24: {
      message:
        "If Status flag is Update, then Implementation End date cannot be beyond 24 months",
      rule: (val, params, validator) => {
        const iStartDate = val[0];
        const iEndDate = val[1];

        if (val[4] === "") {
          return true;
        }

        var implementationEndDat24MoObj = moment(iStartDate)
          .add(24, "M")
          .format("MM/DD/YYYY");

        if (
          new Date(iEndDate) > new Date(implementationEndDat24MoObj) &&
          val[5] === "U"
        ) {
          return false;
        }
        return true;
      }
    },
    implementation_Period12: {
      message:
        "If Status flag is Add, then Implementation End date cannot be beyond 12 months",
      rule: (val, params, validator) => {
        const iStartDate = val[0];
        const iEndDate = val[1];

        if (val[4] === "") {
          return true;
        }

        var implementationEndDat24MoObj = moment(iStartDate)
          .add(12, "M")
          .format("MM/DD/YYYY");
        if (
          new Date(iEndDate) > new Date(implementationEndDat24MoObj) &&
          val[5] === "A"
        ) {
          return false;
        }
        return true;
      }
    },
    Notification_End_Date: {
      message:
        ":attribute should be between 30-59 days of the Notification Start Date.",
      rule: (val, params, validator) => {
        if (val[1] === "") {
          return true;
        }
        var startDate = moment(val[0]);
        var endDate = moment(val[1]);
        var result = Math.abs(endDate.diff(startDate, "days"));
        return result >= 29 && result <= 59;
      }
    },
    Notification_End_Date_ImplSDate: {
      // 10/03/2019  >   10/02/2019
      message: ":attribute should be less than Implementation Start Date",
      rule: (val, params, validator) => {
        const iStartDate = val[5];
        const nEndDate = val[1];
        if (iStartDate === "" || nEndDate === "") {
          return true;
        } else {
          return iStartDate >= nEndDate;
        }
      }
    },
    Implementation_Start_Date: {
      // estartDate 02/01/2019
      message:
        ":attribute should be between 31-60 days of the Notification Start Date.",
      rule: (val, params, validator) => {
        var iStartDate = moment(val[0]).add(1, "day"); //moment(val[0]);
        var notificationStartDate = moment(val[5]);
        var result = Math.abs(iStartDate.diff(notificationStartDate, "days"));
        if (!iStartDate.get("year")) {
          return true;
        }
        return result >= 31 && result <= 60;
      }
    },
    drug_Class: {
      // estartDate 02/01/2019
      message: "Drug Edit Class is required when Drug Edit Status is YES",
      rule: (val, params, validator) => {
        var drugEditStatus = val[0];
        var drugEditClass = val[1];
        if (drugEditStatus === "Y") {
          return drugEditClass !== "";
        }
        return true;
      }
    },
    drug_Class_No: {
      // estartDate 02/01/2019
      message: "Drug Edit Class is not required when Drug Edit Status is NO",
      rule: (val, params, validator) => {
        var drugEditStatus = val[0];
        var drugEditClass = val[1];
        if (drugEditStatus === "N") {
          return drugEditClass.trim() === "";
        }
        return true;
      }
    },
    drug_Code: {
      // estartDate 02/01/2019
      message: "Drug Edit Code is required when Drug Edit Status is YES",
      rule: (val, params, validator) => {
        var drugEditStatus = val[0];
        var drugCode = val[2];
        if (drugEditStatus === "Y") {
          return drugCode !== "";
        }
        return true;
      }
    },
    drug_Code_No: {
      // estartDate 02/01/2019
      message: "Drug Edit Code is not required when Drug Edit Status is NO",
      rule: (val, params, validator) => {
        var drugEditStatus = val[0];
        var drugCode = val[2];
        if (drugEditStatus === "N") {
          return drugCode === "";
        }
        return true;
      }
    },
    drug_edit: {
      //
      message: "Drug Edit Code is should be empty when Drug Edit Status is NO",
      rule: (val, params, validator) => {
        var drugEditStatus = val[0];
        var drugEditClass = val[1];
        if (drugEditStatus === "N") {
          return drugEditClass === "";
        }
        return true;
      }
    },

    txn_Status: {
      message:
        "Please select Ready for CMS transaction from TXN Status dropdown",
      rule: (val, params, validator) => {
        return val[1] !== "CMSREADY" ? false : true;
      }
    },
    monthEndCheck: {
      message:
        ":attribute cannot be later  than the end of the month which follows the current calendar month",
      rule: (val, params, validator) => {
        if (val.length > 1) {
          const curent_M_Last_D = getLastDayOfYearAndMonth(
            moment(new Date(), "MM/DD/YYYY").year(),
            moment(new Date(), "MM/DD/YYYY").month()
          );
          const cc = moment(
            moment().get("month") +
              1 +
              "/" +
              curent_M_Last_D +
              "/" +
              moment().year(),
            "MM/DD/YYYY"
          );
          if (moment(val[4], "MM/DD/YYYY") >= cc) {
            return false;
          } else {
            return true;
          }
        }
      }
    },
    date_after_notification: {
      // name the rule  Notification End Date should be less than Implementation Start Date
      message: ":attribute should be less than Implementation Start Date.",
      rule: (val, params, validator) => {
        const startDate = val[5];
        const endDate = val[1];
        // moment('2010-10-20').isAfter('2010-10-19'); // true
        // moment('2010-10-20').isBefore('2010-10-21'); // true
        // new Date(2010-10-20) > new Date(2010-10-21) // true
        return moment(endDate).isBefore(startDate);
      }
    },

    draft_day: {
      message: ":attribute must be between 1 and 28",
      rule: (val, params, validator) => {
        if (val < 1 || val > 28) {
          return false;
        }
      }
    },

    check_Date: {
      message: "Received Date cannot be future date",
      rule: (val, params, validator) => {
        var date = moment(val[0], "MM/DD/YYYY");
        if (moment() > date) {
          return true;
        } else {
          return false;
        }
      }
    },

    received_date_180: {
      message: ":attribute cannot be Past 180 days for plan :MA/MAPD",
      rule: (val, params, validator) => {
        const date = val[0];
        const plan = val[1];
        if (
          (plan === "MAPD" || plan === "MA") &&
          moment().diff(date, "days") <= 180
        ) {
          return true;
        } else {
          return false;
        }
      }
    },

    received_date_363: {
      message: ":attribute cannot be Past 363 days for plan :PDP",
      rule: (val, params, validator) => {
        const date = val[0];
        const plan = val[1];
        if (plan === "PDP" && moment().diff(date, "days") <= 363) {
          return true;
        } else {
          return false;
        }
      }
    },

    distinctUserAndSupervisior: {
      message: "supervisior should be changed",
      rule: (val, params, validator) => {
        if (val[2] === "USER" && val[1] === val[0]) {
          return false;
        } else {
          return true;
        }
      }
    },
    amountValidator: {
      message: ":attribute is not valid.",
      rule: (val, params, validator) => {
        let regex = /^\s*-?(\d+(\.\d+)?|\.\d+)\s*$/;
        if (!regex.test(val[1])) {
          return false;
        } else {
          return true;
        }
      }
    }
  }
};

function getLastDayOfYearAndMonth(year, month) {
  return new Date(new Date(year, month + 1, 1) - 1).getDate();
}
