import Button from "@material-ui/core/Button";
import React from "react";
import { confirmAlert } from "react-confirm-alert";

const ConfirmBox = (submitForm, Type, props, onNo) => {
  let message = null;
  switch (Type) {
    case "ADD":
      message = "Are you sure you want to add?";
      break;
    case "DELETE":
      message = "Are you sure you want to delete?";
      break;
    case "UPDATE":
      message = "Are you sure you want to update?";
      break;
    case "SUPPRESSTC":
      message = "Do you want to suppress the TC 76 transaction";
      break;
    case "TIMERCHECK":
      message = "Do you really want to TurnOFF the Timer";
      break;
      case "CLOSE":
        message = "Do you really want to close the Queue";
        break;
    default:
      message = Type;
  }

  confirmAlert({
    customUI: ({ onClose }) => {
      const { classes } = props;
      return (
        <div className={classes.confirmDialog}>
          <h4>{message}</h4>
          {/* <p>It will discard all your changes for current model</p> */}

          <div>
            <Button
              className={classes.confirmDialogButton}
              variant="contained"
              onClick={() => {
                onNo && onNo();
                onClose();
              }}
            >
              No
            </Button>

            <Button
              className={classes.confirmDialogButton}
              variant="contained"
              onClick={() => {
                submitForm();
                onClose();
              }}
            >
              Yes
            </Button>
          </div>
        </div>
      );
    }
  });
};

export default ConfirmBox;
