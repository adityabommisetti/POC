const scrollTo = (id) => {
  let top =
    document.getElementById(id).getBoundingClientRect().top + window.scrollY;
  let left =
    document.getElementById(id).getBoundingClientRect().left + window.scrollX;
  window.scrollTo({
    top: top - 67,
    left: left,
    behavior: "smooth",
  });
};
export default scrollTo;
