import 'react-notifications/lib/notifications.css';
import './assets/css/react-confirm-alert.css';
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';
import 'core-js/features/array/find';
import 'core-js/features/array/includes';
import 'core-js/features/number/is-nan';
import './assets/css/react-confirm-alert.css';
import './assets/css/spinner.css';
import './assets/css/comments.css';
import './react-datetime.css';

import { MuiThemeProvider, createMuiTheme } from '@material-ui/core/styles';
import { applyMiddleware, createStore } from 'redux';

import App from './App';
import { Provider } from 'react-redux';
import React from 'react';
import ReactDOM from 'react-dom';
import logger from 'redux-logger';
import rootReducer from './redux/reducers';
import thunk from 'redux-thunk';

require('webpack-jquery-ui');
require('webpack-jquery-ui/css');

let store = null;

if (process.env.NODE_ENV === 'development') {
  store = createStore(rootReducer, applyMiddleware(thunk, logger));
} else {
  store = createStore(rootReducer, applyMiddleware(thunk));
}

const customeTheme = createMuiTheme({
  palette: {
    primary: { main: '#389bde' },
    secondary: { main: '#db2534' }
  },
  typography: {
    fontFamily: 'Lato, sans-serif !important'
  },
  overrides: {

    MuiPrivateTabIndicator: {
      colorSecondary: {
        backgroundColor: '#ffffff'
      }
    },
    MuiTablePagination: {
      menuItem: {
        backgroundColor: '#f7f1f1',
        color: 'black'
      },
      select:{
        width:"30px"
      }
    }
    ,

    MuiSelect:{
      icon:{
        color:"white"
      }
    },
    //  MuiTabs: {
    //    root: {
    //      minWidth: '10px !important',
    //      minHeight: '40px !important',
    //      background: 'rgb(109,179,242)', /* Old browsers */
    //      background: '-moz-linear-gradient(top,  rgba(109,179,242,1) 0%, rgba(84,163,238,1) 32%, rgba(54,144,240,1) 86%, rgba(30,105,222,1) 100%); ',
    //      background: '-webkit-linear-gradient(top,  rgba(109,179,242,1) 0%,rgba(84,163,238,1) 32%,rgba(54,144,240,1) 86%,rgba(30,105,222,1) 100%); ',
    //      background: 'linear-gradient(to bottom,  rgba(109,179,242,1) 0%,rgba(84,163,238,1) 32%,rgba(54,144,240,1) 86%,rgba(30,105,222,1) 100%); ',

    //    },
    //    scrollable: {
    //      overflowX: 'hidden !important'
    //    },
    //    scrollButtonsAuto: {
    //      display: 'block !important',
    //      padding: '6px'
    //    },
    //    textColorPrimary:{
    //     color:'#ffffff'
    //    },
    //    selected:{
    //      background:'linear-gradient(to bottom,  rgb(81, 157, 225) 0%,rgb(57, 144, 227) 32%,rgb(52, 127, 207) 86%,rgba(30,105,222,1) 100%)'
    //    }
    //  },


    //  MuiPrivateTabScrollButton: {
    //    root: {
    //      width: '1.5rem',
    //      marginTop: '0.5rem',
    //     color: '#ffffff'
    //    }
    //  },
    //  MuiTab: {
    //    root: {
    //      minWidth: '10px !important',
    //      minHeight: '40px !important',
    //    },

    //    labelContainer: {
    //      padding: '6px !important'
    //    },
    //    '&$selected': {

    //      border: '1px solid #89afc1',
    //      background: 'rgb(109,179,242);',
    //      background: 'linear-gradient(to bottom,  rgb(147, 204, 255) 0%,rgb(48, 127, 202) 32%,rgba(54,144,240,1) 72%,rgba(30,105,222,1) 100%)',

    //    },
    //    textColorInherit: {
    //      border: '1px solid whitesmoke',
    //      minHeight: '37px !important'

    //    }

    MuiButton: {
      containedPrimary: {
        color: '#fff',
        width: 'auto',
        fontSize: '11px',
        padding: '.55em 1.02em .7em',
        marginLeft: '.5em',
        backgroundColor: '#389bb5',
        borderRadius: '5px',
        boxShadow:
          '0px 1px 2px 0px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0,0,0,0.24), 0px 3px 1px -2px rgba(0,0,0,0.02)'
      }
    },
    MuiAutocomplete:{
      option:{
        backgroundColor:"green",
        fontSize:'0.8rem'
      }
    },
    MuiListItem: {
      root: {
        paddingRight: '0px !important'
      }
    },
    MuiListItemIcon: {
      root: {
        minWidth: '48px',
        marginRight: '5px'
      }
    },
    MuiExpansionPanelDetails: {
      root: {
        paddingBottom: '2px !important',
        display: '100% !important'
      }
    },


    MuiInput: {
      underline: {
        "&:after": {
          borderBottom: 0
        },
        "&:before": {
          content:
            !!window.MSInputMethodContext && !!document.documentMode ? "''" : ""
        }
      }
    },

    MuiFormLabel: {
      asterisk: {
        color: 'red'
      },
      root: {
        fontFamily: 'Lato, sans-serif !important'
      }
    },
    MuiCheckbox: {
      root: { color: '#15aef7' }

    }
  },



});

ReactDOM.render(
  <Provider store={store}>
    {
      <div>
        <MuiThemeProvider theme={customeTheme}>
          <App />
        </MuiThemeProvider>
      </div>
    }
  </Provider>,

  document.getElementById('root'),
);
