import * as ActionTypes from "../../redux/types/ActionType";
import moment from "moment";
const initialState = {
  checkedList: [],
  searchCritireaVo: {
    preEnrollmentStatus: {
      endDate: moment(new Date()).format("MM/DD/YYYY"),
      startDate: moment(moment().subtract(30, "days")).format("MM/DD/YYYY"),
    },
    mbrDistribution: { plan: "" },
    applDistribution: { plan: "" },
    lisDistribution: {
      plan: "",
      date: moment(new Date()).format("MM/DD/YYYY"),
    },
    fileDistribution: {
      endDate: moment(new Date()).format("MM/DD/YYYY"),
      startDate: moment(moment().subtract(30, "days")).format("MM/DD/YYYY"),
    },
  },
  chartDataset: {
    preEnrollmentStatusData: {
      Labels: [],
      Values: [],
    },
    mbrDistribution: { Labels: [], Dataset: [] },
    applDistribution: { Labels: [], Dataset: [] },
    lisDistribution: { Labels: [], Dataset: [] },
    fileDistribution: { Labels: [], Dataset: [] },
  },
  preEnrollmentStatus: { searchFlag: false, spin: "", data: {} },
  applicationAging: { searchFlag: false, spin: "", data: {} },
  rfiTracking: { searchFlag: false, spin: "", data: {} },
  memberShipDistribution: { searchFlag: false, spin: "", data: {} },
  cmsStatus: { searchFlag: false, spin: "", data: {} },
  pendingTransactionsToCMS: { searchFlag: false, spin: "", data: {} },
  applDistribution: { searchFlag: false, spin: "", data: {} },
  specialStatus: { searchFlag: false, spin: "", data: {} },
  letterDistribution: { searchFlag: false, spin: "", data: {} },
  fileDistribution: { searchFlag: false, spin: "", data: {} },
  customerPlanIds: {},
  lisDistribution: { searchFlag: false, spin: "", data: {} },
};
export default function dashboardReducer(state = initialState, action) {
  switch (action.type) {
    //Pre Enrollment Status
    case ActionTypes.PRE_ENROLLMENT_STATUS:
      if (action.payload) {
        return {
          ...state,
          preEnrollmentStatus: {
            ...state.preEnrollmentStatus,
            data: action.payload.data,
            searchFlag: false,
          },
        };
      } else {
        return {
          ...state,
          preEnrollmentStatus: {
            ...state.preEnrollmentStatus,
            spin: action.spin,
          },
        };
      }

    //Application Aging
    case ActionTypes.APPLICATION_AGING:
      if (action.payload) {
        return {
          ...state,
          applicationAging: {
            ...state.applicationAging,
            data: action.payload.data,
            searchFlag: false,
          },
        };
      } else {
        return {
          ...state,
          applicationAging: {
            ...state.applicationAging,
            spin: action.spin,
          },
        };
      }

    //FFI Tracking
    case ActionTypes.RFI_TRACKING:
      if (action.payload) {
        return {
          ...state,
          rfiTracking: {
            ...state.rfiTracking,
            data: action.payload.data,
            searchFlag: false,
          },
        };
      } else {
        return {
          ...state,
          rfiTracking: {
            ...state.rfiTracking,
            spin: action.spin,
          },
        };
      }
    //Membership Chart
    case ActionTypes.MEMBERSHIP_DISTRIBUTION:
      if (action.payload) {
        return {
          ...state,
          memberShipDistribution: {
            ...state.memberShipDistribution,
            data: action.payload.data,
            searchFlag: false,
          },
        };
      } else {
        return {
          ...state,
          memberShipDistribution: {
            ...state.memberShipDistribution,
            spin: action.spin,
          },
        };
      }
    //CMS Status
    case ActionTypes.CMS_STATUS:
      if (action.payload) {
        return {
          ...state,
          cmsStatus: {
            ...state.cmsStatus,
            data: action.payload.data,
            searchFlag: false,
          },
        };
      } else {
        return {
          ...state,
          cmsStatus: {
            ...state.cmsStatus,
            spin: action.spin,
          },
        };
      }
    //CMS Transaction Status
    case ActionTypes.CMS_TRANSACTION_STATUS:
      if (action.payload) {
        return {
          ...state,
          pendingTransactionsToCMS: {
            ...state.pendingTransactionsToCMS,
            data: action.payload.data,
            searchFlag: false,
          },
        };
      } else {
        return {
          ...state,
          pendingTransactionsToCMS: {
            ...state.pendingTransactionsToCMS,
            spin: action.spin,
          },
        };
      }
    case ActionTypes.APPLICATION_DISTRIBUTION:
      if (action.payload) {
        return {
          ...state,
          applDistribution: {
            ...state.applDistribution,
            data: action.payload.data,
            searchFlag: false,
          },
        };
      } else {
        return {
          ...state,
          applDistribution: {
            ...state.applDistribution,
            spin: action.spin,
          },
        };
      }
    // Special Status Distribution
    case ActionTypes.Special_Status:
      if (action.payload) {
        return {
          ...state,
          specialStatus: {
            ...state.specialStatus,
            data: action.payload.data,
            searchFlag: false,
          },
        };
      } else {
        return {
          ...state,
          specialStatus: {
            ...state.specialStatus,
            spin: action.spin,
          },
        };
      }
    //Letter Distribution
    case ActionTypes.LETTER_DISTRIBUTION:
      if (action.payload) {
        return {
          ...state,
          letterDistribution: {
            ...state.letterDistribution,
            data: action.payload.data,
            searchFlag: false,
          },
        };
      } else {
        return {
          ...state,
          letterDistribution: {
            ...state.letterDistribution,
            spin: action.spin,
          },
        };
      }
    //File load and Distribution
    case ActionTypes.FILE_LOAD_DISTRIBUTION:
      if (action.payload) {
        return {
          ...state,
          fileDistribution: {
            ...state.fileDistribution,
            data: action.payload.data,
            searchFlag: false,
          },
        };
      } else {
        return {
          ...state,
          fileDistribution: {
            ...state.fileDistribution,
            spin: action.spin,
          },
        };
      }
    //Get Customer Plain Ids Lis Member Distrtibution
    case ActionTypes.GET_PLANIDs:
      return {
        ...state,
        customerPlanIds: action.payload.data,
      };
    case ActionTypes.LIS_DISTRIBUTION:
      if (action.payload) {
        return {
          ...state,
          lisDistribution: {
            ...state.lisDistribution,
            data: action.payload.data,
            searchFlag: false,
          },
        };
      } else {
        return {
          ...state,
          lisDistribution: {
            ...state.lisDistribution,
            spin: action.spin,
          },
        };
      }
    case ActionTypes.SET_CHART_DATASET:
      return {
        ...state,
        chartDataset: action.payload,
      };
    case ActionTypes.SET_DASHLET_SEARCHVO:
      return {
        ...state,
        searchCritireaVo: action.payload,
      };
    case ActionTypes.DASHBOARD_SEARCH:
      return {
        ...state,
        checkedList: action.payload.checkedList,
        preEnrollmentStatus: {
          ...state.preEnrollmentStatus,
          searchFlag: true,
        },
        applicationAging: {
          ...state.applicationAging,
          searchFlag: true,
        },
        memberShipDistribution: {
          ...state.memberShipDistribution,
          searchFlag: true,
        },
        applDistribution: {
          ...state.applDistribution,
          searchFlag: true,
        },
        lisDistribution: {
          ...state.lisDistribution,
          searchFlag: true,
        },
        specialStatus: {
          ...state.specialStatus,
          searchFlag: true,
        },
        letterDistribution: {
          ...state.letterDistribution,
          searchFlag: true,
        },
        fileDistribution: {
          ...state.fileDistribution,
          searchFlag: true,
        },
        rfiTracking: {
          ...state.rfiTracking,
          searchFlag: true,
        },
        cmsStatus: {
          ...state.cmsStatus,
          searchFlag: true,
        },
        pendingTransactionsToCMS: {
          ...state.pendingTransactionsToCMS,
          searchFlag: true,
        },
      };

    default:
      return state;
  }
}
