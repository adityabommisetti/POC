import * as ActionTypes from "../../redux/types/ActionType";
import isEmpty from "lodash/isEmpty";
import { INITIAL_APPLICATION_DATA } from "../../constants/ApplInitialState";

const initialState = {
  searchResultsVo: null,
  newCommentList: [],
  presetNotesList: [],
  lepData: null,
  applsearchCriteria: {},
  statusLogData: [],
};

export const applSearchReducer = (state = initialState, action) => {
  switch (action.type) {
    case ActionTypes.APPL_SEARCH:
      return {
        ...state,
        searchCriteriaVo: {
          ...action.searchCriteriaVo,
        },
        searchResultsVo: {
          ...action.payload.data,
          nextPage: action.payload.data.nextPage,
          lstInstitutes: action.payload.data.lstInstitutes
            ? [
                { label: "Select", value: "" },
                ...action.payload.data.lstInstitutes,
              ]
            : {},
        },

        applsearchCriteria: {
          ...(action.payload.data.applSearchList
            ? { ...action.payload.data.applSearchList[0] }
            : {}),
        },
        lepData: null,
        newCommentList: [],
      };

    case ActionTypes.APPL_SEARCH_NEXT_PAGE:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          applSearchList: [
            ...state.searchResultsVo.applSearchList,
            ...action.payload.data.content,
          ],
          nextPage: action.payload.data.nextPage,
        },
      };

    case ActionTypes.GET_INSTITUTION_DETAILS:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          applOtherCovVO: {
            ...state.searchResultsVo.applOtherCovVO,
            nameInstitute: isEmpty(action.payload.data)
              ? ""
              : action.payload.data.nameInstitute,
            nameInstituteDes: isEmpty(action.payload.data)
              ? ""
              : action.payload.data.nameInstituteDes,
            ltcFacPhone: isEmpty(action.payload.data)
              ? ""
              : action.payload.data.ltcFacilityPhone,
            ltcFacAddress: isEmpty(action.payload.data)
              ? ""
              : action.payload.data.ltcFacilityAddress,
          },
        },
      };

    case ActionTypes.CANCEL:
      return {
        ...state,
        searchResultsVo: null,
      };

    case ActionTypes.FETCH_COUNTY_ACTION:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          lstCounty: [...action.payload.data.countyList],
          applAddress: {
            ...state.searchResultsVo.applAddress,
            perState: action.payload.data.stateCd,
          },
          lstCity: [...action.payload.data.cityList],
        },
      };
    case ActionTypes.FETCH_MAIL_COUNTY_ACTION:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mailCounty: [...action.payload.data.countyList],
          applAddress: {
            ...state.searchResultsVo.applAddress,
            mailState: action.payload.data.stateCd,
          },
          mailCity: [...action.payload.data.cityList],
        },
      };

    case ActionTypes.SET_CITIES:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,

          lstCity: [...action.payload.data],
        },
      };

    case ActionTypes.RESTORE_CURR_APPL:
      return {
        ...state,
        searchResultsVo: { ...action.payload },
      };
    case ActionTypes.REVERT_CHANGES:
      return {
        ...state,
        searchResultsVo: {
          ...action.payload,
          applSearchList: [...state.searchResultsVo.applSearchList],
        },
        newCommentList: [],
        applsearchCriteria: {
          ...action.payload.application,
        },
      };

    case ActionTypes.ROW_CLICK:
      return {
        ...state,
        searchResultsVo: {
          ...action.payload.data,
          applSearchList: [...state.searchResultsVo.applSearchList],
          nextPage: state.searchResultsVo.nextPage,
        },

        newCommentList: [],
        applsearchCriteria: {
          ...action.payload.application,
        },
      };
    case ActionTypes.ORIGINAL_APPL_SEARCH:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          ...action.payload.data,
          applSearchList: [...state.searchResultsVo.applSearchList],
          applErrList: [...state.searchResultsVo.applErrList],
          lstInstitutes: [...state.searchResultsVo.lstInstitutes],
          lstCity: [...state.searchResultsVo.lstCity],
          lstCounty: [...state.searchResultsVo.lstCounty],
        },
      };
    case ActionTypes.SET_VALUE:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,

          [action.targetVo]: {
            ...state.searchResultsVo[action.targetVo],
            [action.name]: action.value,
          },
        },
      };

    case ActionTypes.RESET_ADDRESS:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          applAddress: {
            ...state.searchResultsVo.applAddress,
            mailCountry: action.value,
            mailState: "",
            mailCounty: "",
            mailCity: "",
            mailZip5: "",
          },
        },
      };
    case ActionTypes.SET_PCP_DATA:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          applOtherPlanVO: {
            ...state.searchResultsVo.applOtherPlanVO,
            officeCd: action.selectedVo.pcpOfficeCd,
            locationId: action.selectedVo.PcpLocationId,
            pcpName: action.selectedVo.pcpName,
            currentPatientInd: action.selectedVo.pcpCurrPatnt,
            officeCategoryCd: action.selectedVo.pcpOffCatCd,
            alternateOfficeCd: action.selectedVo.pcpNpiId,
          },
        },
      };

    case ActionTypes.SET_AGENT_DATA:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          applAgentVO: {
            ...state.searchResultsVo.applAgentVO,
            commAgencyId:
              action.selectedVo.agencyId + "-" + action.selectedVo.agencyName,
            brokAgencyId: action.selectedVo.agencyId,
            agencyType: action.selectedVo.agencyType,
            brokerType: action.selectedVo.agentType,
            brokAgentId: action.selectedVo.agentId,
            agencyName: action.selectedVo.agencyName,
            agentName: action.selectedVo.agentName,
          },
        },
      };
    case ActionTypes.SET_GRP_PROD_DATA:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          grpProdVO: {
            ...state.searchResultsVo.grpProdVO,
            enrollGroupName: action.selectedVo.groupName,
            enrollProdName: action.selectedVo.productName,
            groupId: action.selectedVo.groupId,
            areaId: action.selectedVo.areaId,
            area: action.selectedVo.area,
            eghpInd: action.selectedVo.eghpInd,
            planDesignation: action.selectedVo.planDesignation,
            prtCPremiumAmt: action.selectedVo.prtCPremiumAmt,
            prtDPremiumAmt: action.selectedVo.prtDPremiumAmt,
            supplPremiumAmt: action.selectedVo.supplPremiumAmt,
            premiumReductionAmt: action.selectedVo.premiumReductionAmt,
            dsrRebateAmt: action.selectedVo.dsrRebateAmt,
            snpInd: action.selectedVo.snpInd,
            pymtAmt: action.selectedVo.pymtAmt,
            lineOfBusiness: action.selectedVo.lineOfBusiness,
          },
          applPlanVO: {
            ...state.searchResultsVo.applPlanVO,
            enrollPlan: action.selectedVo.planId,
            enrollPbp: action.selectedVo.pbpId,
            enrollSegment: action.selectedVo.segmentId,
            enrollPymtAmt: action.selectedVo.pymtAmt,
            enrollProduct: action.selectedVo.productId,
            enrollGrpId: action.selectedVo.groupId,
          },
        },
      };
    case ActionTypes.SET_PRIMARY_ZIP:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          applAddress: {
            ...state.searchResultsVo.applAddress,
            perCity: action.selectedVo.perCity,
            perState: action.selectedVo.perStateCd,
            perZip5: action.selectedVo.perZip5,
            perZip4: action.selectedVo.perZip4,
            perCounty: action.selectedVo.countyCd,
          },
        },
      };
    case ActionTypes.SET_MAILING_ZIP:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          applAddress: {
            ...state.searchResultsVo.applAddress,
            mailCity: action.selectedVo.perCity,
            mailState: action.selectedVo.perStateCd,
            mailZip5: action.selectedVo.perZip5,
            mailZip4: action.selectedVo.perZip4,
            mailCounty: action.selectedVo.countyCd,
          },
        },
      };

    case ActionTypes.SET_AUTH_ZIP_STATE:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          applAddress: {
            ...state.searchResultsVo.applAddress,
            authRepCity: action.selectedVo.perCity,
            authRepState: action.selectedVo.perStateCd,
            authRepZip5: action.selectedVo.perZip5,
            authRepZip4: action.selectedVo.perZip4,
          },
        },
      };
    case ActionTypes.SET_AUTH_ZIP:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          applAddress: {
            ...state.searchResultsVo.applAddress,
            authRepCity: isEmpty(action.payload.data.cityList)
              ? ""
              : action.payload.data.cityList[0].value,
            authRepState: action.payload.data.stateCd,
          },
        },
      };
    case ActionTypes.SET_ELIG_DATA:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          applVO: {
            ...state.searchResultsVo.applVO,
            mbrFirstName: action.selectedVo.firstName,
            mbrMiddleName: action.selectedVo.middleName,
            mbrLastName: action.selectedVo.lastName,
            mbrBirthDt: action.selectedVo.birthDate,
            mbrGender: action.selectedVo.gender,
          },
          applAddress: {
            ...state.searchResultsVo.applAddress,
            perState: action.selectedVo.state,
          },
          applOtherCovVO: {
            ...state.searchResultsVo.applOtherCovVO,
            esrd: action.selectedVo.esrd && action.selectedVo.esrd.trim(),
            ltcInstInd:
              action.selectedVo.instInd && action.selectedVo.instInd.trim(),
            medicaidInd:
              action.selectedVo.medicaidInd &&
              action.selectedVo.medicaidInd.trim(),
          },
        },
      };
    case ActionTypes.NEW_MEMBER_APPLICATION:
      return {
        ...state,
        searchResultsVo: {
          ...INITIAL_APPLICATION_DATA,

          applVO: {
            ...INITIAL_APPLICATION_DATA.applVO,
            applType: action.payload,
            /*language: action.appFields === "Y" ? "SPA" : "ENG",*/
          },
          lepData: null,
        },

        newCommentList: [],
        lepData: null,
      };

    case ActionTypes.UPDATE_ERROR:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          validateFlag: action.payload,
        },
      };

    case ActionTypes.APPL_CANCEL:
      return {
        ...state,
        searchResultsVo: { ...state.searchResultsVo, ...action.payload.data },
      };

    case ActionTypes.ADD_NEW_COMMENT:
      return {
        ...state,
        newCommentList: [...state.newCommentList, action.payload],
        applCommentsList: [
          ...state.newCommentList,
          ...state.searchResultsVo.applCommentsList,
        ],
      };

    case ActionTypes.APPL_UPDATE:
      return {
        ...state,

        searchResultsVo: {
          ...state.searchResultsVo,
          ...action.payload.data,
          lstInstitutes: action.payload.data.lstInstitutes
            ? [
                { label: "Select", value: "" },
                ...action.payload.data.lstInstitutes,
              ]
            : {},
          applCommentsList: [
            ...state.newCommentList,
            ...state.searchResultsVo.applCommentsList,
          ],
        },
        newCommentList: [],
      };

    case ActionTypes.APPL_VALIDATE:
      return {
        ...state,
        searchResultsVo: { ...state.searchResultsVo, ...action.payload.data },
      };

    case ActionTypes.UPDATE_COMMENTS_SUCCESS:
      let newList = state.newCommentList;
      if (newList.length > 0) {
        for (let i = 0; i < newList.length; i++) {
          newList[i].insert = "N";
        }
      }

      return {
        ...state,
        // newCommentList: [...newList],
        searchResultsVo: {
          ...state.searchResultsVo,
          applCommentsList: [
            ...state.newCommentList,
            ...state.searchResultsVo.applCommentsList,
          ],
        },
        newCommentList: [],
      };
    case ActionTypes.UPDATE_COMMENTS_FAILED:
      return {
        ...state,
        newCommentList: [],
      };

    case ActionTypes.SUBMIT_FORM:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          ...action.payload.data,
          lstInstitutes: [
            { label: "Select", value: " " },
            ...action.payload.data.lstInstitutes,
          ],
        },
      };

    case ActionTypes.SET_ATTESTATION_LIST:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          applAttestationList: [...action.payload],
        },
      };

    case ActionTypes.SET_LEP_DETAILS:
      return {
        ...state,
        lepData: {
          ...action.payload,
        },
      };
    case ActionTypes.ADD_UNCOV_DATA:
      return {
        ...state,
        lepData: {
          ...state.lepData,
          potentialUnCovMthsList: [
            action.payload,
            ...state.lepData.potentialUnCovMthsList,
          ],
        },
      };
    case ActionTypes.SET_UNCOV_DATA:
      return {
        ...state,
        lepData: {
          ...state.lepData,
          potentialUnCovMthsList: !isEmpty(action.payload.data)
            ? action.payload.data
            : [...action.payload],
        },
      };

    case ActionTypes.ADD_ATTESTATION_DATA:
      return {
        ...state,
        lepData: {
          ...state.lepData,
          lepAttestInfoVO: {
            ...state.lepData.lepAttestInfoVO,
            lepAttestList: [
              action.payload.data,
              ...state.lepData.lepAttestInfoVO.lepAttestList,
            ],
          },
        },
      };

    case ActionTypes.SET_ATTESTATION_CALL:
      return {
        ...state,
        lepData: {
          ...state.lepData,
          attestCallMasterVO: {
            ...state.lepData.attestCallMasterVO,
            inBoundInComplete: action.payload.inBoundInComplete
              ? [
                  ...state.lepData.attestCallMasterVO.inBoundInComplete,
                  ...action.payload.inBoundInComplete,
                ]
              : state.lepData.attestCallMasterVO.inBoundInComplete,
            inBoundInitial: action.payload.inBoundInitial
              ? [
                  ...state.lepData.attestCallMasterVO.inBoundInitial,
                  ...action.payload.inBoundInitial,
                ]
              : state.lepData.attestCallMasterVO.inBoundInitial,
            inBoundLate: action.payload.inBoundLate
              ? [
                  ...state.lepData.attestCallMasterVO.inBoundLate,
                  ...action.payload.inBoundLate,
                ]
              : state.lepData.attestCallMasterVO.inBoundLate,
            outBoundInComplete: action.payload.outBoundInComplete
              ? [
                  ...state.lepData.attestCallMasterVO.outBoundInComplete,
                  ...action.payload.outBoundInComplete,
                ]
              : state.lepData.attestCallMasterVO.outBoundInComplete,
            outBoundInitial: action.payload.outBoundInitial
              ? [
                  ...state.lepData.attestCallMasterVO.outBoundInitial,
                  ...action.payload.outBoundInitial,
                ]
              : state.lepData.attestCallMasterVO.outBoundInitial,
            le21TimerCheck: action.payload.le21TimerCheck
              ? action.payload.le21TimerCheck
              : state.lepData.attestCallMasterVO.le21TimerCheck,
          },
        },
      };

    case ActionTypes.SET_APPL_LEP_VALUE:
      return {
        ...state,
        lepData: {
          ...state.lepData,
          [action.targetVo]: {
            ...state.lepData[action.targetVo],
            [action.name]: action.value,
          },
        },
      };
    case ActionTypes.UPDATE_ATTESTATION_CALL:
      return {
        ...state,
        lepData: {
          ...state.lepData,
          attestCallMasterVO: {
            ...state.lepData.attestCallMasterVO,
            obc1TimerCheck: action.payload.obc1TimerCheck
              ? action.payload.obc1TimerCheck
              : state.lepData.attestCallMasterVO.obc1TimerCheck,
            obc2TimerCheck: action.payload.obc2TimerCheck
              ? action.payload.obc2TimerCheck
              : state.lepData.attestCallMasterVO.obc2TimerCheck,
            le21TimerCheck: action.payload.le21TimerCheck
              ? action.payload.le21TimerCheck
              : state.lepData.attestCallMasterVO.le21TimerCheck,
            obc3TimerCheck: action.payload.obc3TimerCheck
              ? action.payload.obc3TimerCheck
              : state.lepData.attestCallMasterVO.obc3TimerCheck,
          },
        },
      };

    case ActionTypes.STATUS_LOG:
      return {
        ...state,
        statusLogData: action.payload.data,
      };

    default:
      return state;
  }
};
