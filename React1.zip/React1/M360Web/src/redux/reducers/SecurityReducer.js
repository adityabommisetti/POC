import * as ActionTypes from "../../redux/types/ActionType";

const  initialState = {
   cacheData:{},
   serviceData:{},
  };
 

  export default function sercurityRoleReducer(state = initialState, action) {
     
    switch (action.type) {
      case ActionTypes.GET_USER_ROLE_DATA:
        return {
          cacheData:action.payload.data
        };
        
        case ActionTypes.UPDATE_ROLE_DATA:
        return {
          cacheData:{
              ...state.cacheData,
                userList:action.payload
          }
        };

        case ActionTypes.GET_SERVICE_DATA:
          return{
            ...state,
            serviceData:action.payload.data
          }

          case ActionTypes.ADD_SERVICE:
            return{
              ...state,
              serviceData:action.payload
              
            }
            case ActionTypes.DELETE_SERVICE:
              return{
                ...state,
              serviceData:action.payload
              }
   
  
      default:
        return state;
    }
  };