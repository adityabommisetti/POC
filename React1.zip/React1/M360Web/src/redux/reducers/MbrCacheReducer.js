import * as ActionTypes from "../../redux/types/ActionType";

export default function memberCacheReducer(state = {}, action) {
  switch (action.type) {
    case ActionTypes.FETCH_MEMBER_CACHE_DATA:

      return { ...action.payload.data };


    default:
      return state;
  }
}
