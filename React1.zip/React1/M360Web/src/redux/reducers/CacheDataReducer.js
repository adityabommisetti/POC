import * as ActionTypes from "../../redux/types/ActionType";

import { INITIAL_APPLICATION_DATA } from "../../constants/ApplInitialState";

export default function cacheDataReducer(state = {}, action) {
  switch (action.type) {
    case ActionTypes.FETCH_CACHE_DATA:
      return { ...action.payload.data };
    case ActionTypes.NEW_APPLICATION:
      return { ...state, ...INITIAL_APPLICATION_DATA };
    case ActionTypes.PRESET_NOTES:
      return {
        ...state,
        preSetNoteList: [...action.payload.data]
      };



    default:
      return state;
  }
}
