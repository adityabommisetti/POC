import * as ActionTypes from "../../redux/types/ActionType";

const initialState = {
  letterDescriptionData: [],
  lstLetterDetails: [],
  lstLetterDetailsCover: [],
  qcSearchList: [],
  letterupdated: {},
  qcCheckedList: [],
  batchIdList: [{ value: "-1", label: "Select" }],
  qcDescription: [{ value: "-1", label: "Select" }]
};

export default function letterReviewReducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.INITIAL_LETTER:
      const allLetterList = [
        { value: " ", label: "Select" },
        ...action.payload.data.allLetterList
      ];
      return {
        ...state,
        letterDescriptionData: allLetterList
      };

    case ActionTypes.LETTER_REVIEW_DATA_UPDATE:
      let updatedList = [...state.lstLetterDetails];
      updatedList[action.payload.selectedIndex] = {
        ...updatedList[action.payload.selectedIndex],
        lastMailDateFrmt: action.payload.lastMailDateFrmt,
        requestDateFrmt: action.payload.requestDateFrmt,
        origMailDateFrmt: action.payload.origMailDateFrmt,
        printDateFrmt: action.payload.printDateFrmt,
        reprintDateFrmt: action.payload.reprintDateFrmt,
        responseDueDateFrmt: action.payload.responseDueDateFrmt,
        responseDateFrmt: action.payload.responseDateFrmt
      };
      const update = updatedList[action.payload.selectedIndex];
      update.recordTypeFrmt =
        update.recordType === "M" ? "Member" : "Application";
      update.letterNameFrmt = update.description.trim()
        ? update.letterName + "-" + update.description
        : update.letterName;
      return {
        ...state,
        lstLetterDetails: [...updatedList]
      };

    case ActionTypes.LETTER_REVIEW_SEARCH:
      const lstLetterVO = action.payload.data.lstLetterVO === undefined ? [] : [...action.payload.data.lstLetterVO];
      for (var i = 0; i < lstLetterVO.length; i++) {
        if (lstLetterVO[i].recordType === "A") {
          lstLetterVO[i].primaryId = parseInt(lstLetterVO[i].primaryId);
        }
      }

      return {
        ...state,
        lstLetterDetails: lstLetterVO,
        lstLetterDetailsCover: action.payload.data.lstMbrCorrVO,
        nextPage: action.payload.data.nextPage
      };
    case ActionTypes.SEARCH_NEXT_REVIEW:
      return {
        ...state,
        lstLetterDetails: [...state.lstLetterDetails, ...action.payload.data.content],
        nextPage: action.payload.data.nextPage
      };
    case ActionTypes.RESET_LETTER_DETAILS:
      return {
        ...state,
        lstLetterDetails: [],
        lstLetterDetailsCover: []
      };

    case ActionTypes.LETTER_REVIEW_DATA:
      return {
        ...state,
        lstLetterDetailsCover: action.payload.data
      };

    case ActionTypes.LETTER_QC_SEARCH_BATCHID:
      const batchId = action.payload.data;
      batchId.splice(0, 0, { value: "", label: "Select" });
      return {
        ...state,
        batchIdList: batchId
      };

    case ActionTypes.QC_RESET:
      return {
        ...state,
        batchIdList: [{ value: "", label: "Select" }],
        qcDescription: [{ value: "", label: "Select" }],
        qcSearchList: []
      };

    case ActionTypes.LETTER_QC_DESCRIPTION:
      const Description = action.payload.data;
      Description.splice(0, 0, { value: "", label: "Select" });
      return {
        ...state,
        qcDescription: Description
      };

    case ActionTypes.LETTER_QC_SEARCH:
      return {
        ...state,
        qcSearchList: action.payload.data
      };

    case ActionTypes.RESET_CHECK_LIST:
      return {
        ...state,
        qcCheckedList: []
      };

    case ActionTypes.LETTER_QC_ADD:
      const qc = state.qcCheckedList.length > 0 ? state.qcCheckedList : [];

      return {
        ...state,
        qcCheckedList: [...qc, action.payload]
      };

    case ActionTypes.LETTER_QC_DELETE:
      let checkedList = state.qcCheckedList.map((data, i) => {
        if (
          data.letterName.concat(data.primaryId, data.filebatchid) ===
          action.payload.letterName.concat(
            action.payload.primaryId,
            action.payload.filebatchid
          )
        ) {
          state.qcCheckedList.splice(i, 1);
        }
      });
      checkedList = state.qcCheckedList.filter(item => item);
      return {
        ...state,
        qcCheckedList: checkedList
      };

    default:
      return state;
  }
}
