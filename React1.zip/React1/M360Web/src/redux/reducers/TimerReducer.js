import * as ActionTypes from "../../redux/types/ActionType";

const initialState = {
  searchResultsVo: [],
  timersType: [],
  nextPage: false
};

export default function timerReducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.GET_TIMER_DETAILS:
      return {
        ...state,
        searchResultsVo: action.payload.data.emmTimersVOs ? [...action.payload.data.emmTimersVOs] : [],
        nextPage: action.payload.data.nextPage
      };
    case ActionTypes.RESET_TIMER_DATA:
      return {
        ...state,
        searchResultsVo: []
      };
    case ActionTypes.TIMER_UPDATE:
      return {
        ...state,
        searchResultsVo: action.payload.data.emmTimersVOs ? [...action.payload.data.emmTimersVOs] : [],
        nextPage: action.payload.data.nextPage
      };

    case ActionTypes.GET_TIMER_TYPE:
      return {
        ...state,
        timersType: action.payload.data
      };

    case ActionTypes.SEARCH_NEXT_TIMERS:
      return {
        ...state,
        searchResultsVo: [...state.searchResultsVo, ...action.payload.data.content],
        nextPage: action.payload.data.nextPage
      };
    default:
      return state;
  }
}
