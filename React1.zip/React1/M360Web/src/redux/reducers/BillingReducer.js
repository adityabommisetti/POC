import * as ActionTypes from "../../redux/types/ActionType";
const initialState = {
  bilingCacheData: {},
  invoice: {
    adjustmentComments: "",
    invoiceSearchResults: {
      billingInvSummary: [],
      billingInvHeaderDtlsVOs: [],
      billingInvDetails: [],
      commentList: [],
      lstFunctionCode: [],
      lstRefReasonCode: [],
      nextPage: false,
    },
    mbrGrpSearch: [],
    oldResults: [],
    refFlag: false,
    searchCriteriaVo: {},
    searchFlag: false,
    tableIndexes: {
      invoiceHeaderDetails: 0,
      invoiceDetails: 0,
      invoiceComments: 0,
    },
  },
  payTypesList: null,
  paymentEntry: {
    nextPage: false,
    searchCriteriaVo: {},
    tableIndexes: {
      paymentHeaderIndex: 0,
      paymentDetailsIndex: 0,
    },
    oldResults: [],
    paymentEntrySearchResults: {
      billingPaymentslist: [],
      billingPaymentDtlsList: [],
    },
  },
  billingPaymentcache: [],
  mbrPayments: {
    nextPage: false,
    searchCriteriaVo: {},
    tableIndexes: {
      mbrPaymentList: 0,
    },
    oldResults: [],
    mbrPaymentSearchResults: {
      mbrPaymentsVO: [],
      mbrPymntDtlInvcVO: [],
    },
  },
  bankAcctCd: null,
  draft: {
    nextPage: false,
    searchCriteriaVo: {},
    tableIndex: 0,
    billingDraftHeaderVOList: [],
    billingDraftDetailVOList: [],
  },
};

export default function billingReducer(state = initialState, action) {
  switch (action.type) {
    //Invoice
    case ActionTypes.BILLING_CACHE_DATA:
      return {
        ...state,
        bilingCacheData: action.payload.data,
      };

    case ActionTypes.BILLING_INVOICE_SEARCH:
      return {
        ...state,
        invoice: {
          ...state.invoice,
          invoiceSearchResults: action.payload.data
            ? action.payload.data
            : initialState.invoice.invoiceSearchResults,
          oldResults: action.payload.data
            ? action.payload.data.billingInvHeaderDtlsVOs
            : [],
          searchFlag: true,
          searchCriteriaVo: action.searchCriteriaVo,
        },
      };

    case ActionTypes.BILLING_INVOICE_PAGINATION:
      return {
        ...state,
        invoice: {
          ...state.invoice,
          oldResults: [
            ...state.invoice.oldResults,
            ...action.payload.data.content,
          ],
          invoiceSearchResults: {
            ...state.invoice.invoiceSearchResults,
            nextPage: action.payload.data.nextPage,
          },
        },
      };

    case ActionTypes.BILLING_INVOICE_SEARCH_SELECT:
      return {
        ...state,
        invoice: {
          ...state.invoice,
          invoiceSearchResults: action.payload.data
            ? {
                ...action.payload.data,
                nextPage: state.invoice.invoiceSearchResults.nextPage,
              }
            : { ...state.invoice.invoiceSearchResults },
        },
      };
    case ActionTypes.BILLING_INVOICE_ADJUSTMENT:
      return {
        ...state,
        invoice: {
          ...state.invoice,
          invoiceSearchResults:
            Object.keys(action.payload.data).length > 0
              ? {
                  ...action.payload.data,
                  nextPage: state.invoice.invoiceSearchResults.nextPage,
                }
              : { ...state.invoice.invoiceSearchResults },
        },
      };

    case ActionTypes.BILLING_INVOICE_TRANSFER:
      return {
        ...state,
        invoice: {
          ...state.invoice,
          invoiceSearchResults:
            Object.keys(action.payload.data).length > 0
              ? {
                  ...action.payload.data,
                  nextPage: state.invoice.invoiceSearchResults.nextPage,
                }
              : { ...state.invoice.invoiceSearchResults },
        },
      };

    case ActionTypes.BILLING_INVOICE_SAVE_COMMENT:
      return {
        ...state,
        invoice: {
          ...state.invoice,
          invoiceSearchResults: {
            ...state.invoice.invoiceSearchResults,
            commentList: action.payload.data,
          },
        },
      };

    case ActionTypes.SET_INVOICE_TABLE_INDEX:
      return {
        ...state,
        invoice: {
          ...state.invoice,
          tableIndexes: {
            ...state.invoice.tableIndexes,
            ...action.payload,
          },
        },
      };

    case ActionTypes.SET_INVOICE_COMMENT_REF_FLAG:
      return {
        ...state,
        invoice: {
          ...state.invoice,
          refFlag: action.payload,
        },
      };

    case ActionTypes.SET_INVOICE_ADJUSTMENT_COMMENT:
      return {
        ...state,
        invoice: {
          ...state.invoice,
          adjustmentComments: action.payload,
        },
      };

    case ActionTypes.BILLING_INVOICE_MBR_GRP_SEARCH:
      return {
        ...state,
        invoice: {
          ...state.invoice,
          mbrGrpSearch: action.payload.data,
        },
      };

    case ActionTypes.BILLING_DRAFT_SEARCH:
      return {
        ...state,
        draft: action.payload.data
          ? {
              ...action.payload.data,
              searchCriteriaVo: action.searchCriteriaVo,
            }
          : initialState.draft,
      };

    case ActionTypes.BILLING_DRAFT_DETAIL_SEARCH:
      return {
        ...state,
        draft: {
          ...state.draft,
          billingDraftDetailVOList: action.payload.data,
        },
      };

    case ActionTypes.BILLING_DRAFT_TABLE_INDEX:
      return {
        ...state,
        draft: {
          ...state.draft,
          tableIndex: action.payload,
        },
      };

    case ActionTypes.BILLING_DRAFT_PAGINATION:
      return {
        ...state,
        draft: {
          ...state.draft,
          nextPage: action.payload.data.nextPage,
          billingDraftDetailVOList: [
            ...state.draft.billingDraftDetailVOList,
            ...action.payload.data.content,
          ],
        },
      };
    //PaymentEntry
    case ActionTypes.BILLING_PAYMENT_SEARCH:
      return {
        ...state,
        paymentEntry: {
          ...state.paymentEntry,
          paymentEntrySearchResults: {
            ...state.paymentEntry.paymentEntrySearchResults,
            billingPaymentslist:
              action.payload.data.billingPaymentslist !== null
                ? action.payload.data.billingPaymentslist
                : [],
            billingPaymentDtlsList:
              action.payload.data.billingPaymentDtlsList !== null
                ? action.payload.data.billingPaymentDtlsList
                : [],
          },
          searchCriteriaVo: action.searchCriteriaVo,
          nextPage: action.payload.data.nextPage,
        },
      };

    case ActionTypes.BILLING_PAYMENT_DETAILS:
      return {
        ...state,
        paymentEntry: {
          ...state.paymentEntry,
          paymentEntrySearchResults: {
            ...state.paymentEntry.paymentEntrySearchResults,
            billingPaymentDtlsList: [...action.payload.data],
          },
        },
      };

    case ActionTypes.BILLING_PAYMENT_NEWPAYMENT:
      return {
        ...state,
        paymentEntry: {
          ...state.paymentEntry,
          paymentEntrySearchResults: {
            ...state.paymentEntry.paymentEntrySearchResults,
            billingPaymentslist: [...action.payload.data.billingPaymentslist],
            billingPaymentDtlsList: [
              ...action.payload.data.billingPaymentDtlsList,
            ],
          },
        },
      };

    case ActionTypes.BILLING_PAYMENT_ADDPAYMENT_DETAIL:
      return {
        ...state,
        paymentEntry: {
          ...state.paymentEntry,
          paymentEntrySearchResults: {
            ...state.paymentEntry.paymentEntrySearchResults,
            billingPaymentslist: [...action.payload.data.billingPaymentslist],
            billingPaymentDtlsList: [
              ...action.payload.data.billingPaymentDtlsList,
            ],
          },
        },
      };
    case ActionTypes.BILLING_PAYMENT_ENTRY_PAGINATION:
      return {
        ...state,
        paymentEntry: {
          ...state.paymentEntry,
          nextPage: action.payload.data.nextPage,
          paymentEntrySearchResults: {
            ...state.paymentEntry.paymentEntrySearchResults,
            billingPaymentslist: [
              ...state.paymentEntry.paymentEntrySearchResults
                .billingPaymentslist,
              ...action.payload.data.content,
            ],
          },
        },
      };

    case ActionTypes.BILLING_PAYMENT_HEADER_UPDATE:
      for (
        var j = 0;
        j <
        state.paymentEntry.paymentEntrySearchResults.billingPaymentslist.length;
        j++
      ) {
        if (
          state.paymentEntry.paymentEntrySearchResults.billingPaymentslist[j]
            .batchDate === action.payload.data.batchDate &&
          state.paymentEntry.paymentEntrySearchResults.billingPaymentslist[j]
            .batchSeqNbr === action.payload.data.batchSeqNbr
        ) {
          break;
        }
      }
      let data = [
        ...state.paymentEntry.paymentEntrySearchResults.billingPaymentslist,
      ];
      data.splice(j, 1, action.payload.data);

      return {
        ...state,
        paymentEntry: {
          ...state.paymentEntry,
          paymentEntrySearchResults: {
            ...state.paymentEntry.paymentEntrySearchResults,
            billingPaymentslist: data,
          },
        },
      };

    case ActionTypes.BILLING_PAYMENT_DETAILS_UPDATE:
      for (
        j = 0;
        j <
        state.paymentEntry.paymentEntrySearchResults.billingPaymentslist.length;
        j++
      ) {
        if (
          state.paymentEntry.paymentEntrySearchResults.billingPaymentslist[j]
            .paySource === action.payload.data.billPaymentsHeader.paySource &&
          state.paymentEntry.paymentEntrySearchResults.billingPaymentslist[j]
            .bankAcntCd === action.payload.data.billPaymentsHeader.bankAcntCd &&
          state.paymentEntry.paymentEntrySearchResults.billingPaymentslist[j]
            .batchDate === action.payload.data.billPaymentsHeader.batchDate &&
          state.paymentEntry.paymentEntrySearchResults.billingPaymentslist[j]
            .batchSeqNbr ===
            action.payload.data.billPaymentsHeader.batchSeqNbr &&
          state.paymentEntry.paymentEntrySearchResults.billingPaymentslist[j]
            .batchPostedInd ===
            action.payload.data.billPaymentsHeader.batchPostedInd
        ) {
          break;
        }
      }
      state.paymentEntry.paymentEntrySearchResults.billingPaymentslist.splice(
        j,
        1,
        action.payload.data.billPaymentsHeader
      );
      return {
        ...state,
        paymentEntry: {
          ...state.paymentEntry,
          paymentEntrySearchResults: {
            ...state.paymentEntry.paymentEntrySearchResults,
            billingPaymentslist: [
              ...state.paymentEntry.paymentEntrySearchResults
                .billingPaymentslist,
            ],
            billingPaymentDtlsList: [
              ...action.payload.data.billPaymentsDtlsList,
            ],
          },
        },
      };

    case ActionTypes.BILLING_PAYMENTENTRY_HEADERTABLE_INDEX:
      return {
        ...state,
        paymentEntry: {
          ...state.paymentEntry,
          tableIndexes: {
            ...state.paymentEntry.tableIndexes,
            paymentHeaderIndex: action.payload,
          },
        },
      };
    case ActionTypes.BILLING_PAYMENTENTRY_DETAILSTABLE_INDEX:
      return {
        ...state,
        paymentEntry: {
          ...state.paymentEntry,
          tableIndexes: {
            ...state.paymentEntry.tableIndexes,
            paymentDetailsIndex: action.payload,
          },
        },
      };
    //MemberPayments

    case ActionTypes.BILLING_MBRPAYMENTS_SEARCH:
      return {
        ...state,
        mbrPayments: {
          ...state.mbrPayments,
          mbrPaymentSearchResults: {
            ...state.mbrPayments.mbrPaymentSearchResults,
            mbrPaymentsVO: [...action.payload.data.mbrPaymentsVO],
            mbrPymntDtlInvcVO: [...action.payload.data.mbrPymntDtlInvcVO],
          },
          searchCriteriaVo: action.searchCriteriaVo,
          nextPage: action.payload.data.nextPage,
        },
      };

    case ActionTypes.BILLING_MBRPAYMENTS_INVOICE:
      return {
        ...state,
        mbrPayments: {
          ...state.mbrPayments,
          mbrPaymentSearchResults: {
            ...state.mbrPayments.mbrPaymentSearchResults,
            mbrPymntDtlInvcVO: [...action.payload.data],
          },
        },
      };
    case ActionTypes.BILLING_MBRPAYMENTS_TABLE_INDEX:
      return {
        ...state,
        mbrPayments: {
          ...state.mbrPayments,
          tableIndexes: {
            ...state.mbrPayments.tableIndexes,
            mbrPaymentList: action.payload,
          },
        },
      };

    case ActionTypes.BILLING_MBRPAYMENTS_UPDATE:
      for (
        var i = 0;
        i < state.mbrPayments.mbrPaymentSearchResults.mbrPaymentsVO.length;
        i++
      ) {
        if (
          state.mbrPayments.mbrPaymentSearchResults.mbrPaymentsVO[i]
            .customerId === action.payload.data.customerId &&
          state.mbrPayments.mbrPaymentSearchResults.mbrPaymentsVO[i]
            .paySourceType === action.payload.data.paySourceType &&
          state.mbrPayments.mbrPaymentSearchResults.mbrPaymentsVO[i]
            .batchDate === action.payload.data.batchDate &&
          state.mbrPayments.mbrPaymentSearchResults.mbrPaymentsVO[i]
            .batchSeqNbr === action.payload.data.batchSeqNbr &&
          state.mbrPayments.mbrPaymentSearchResults.mbrPaymentsVO[i].itemNbr ===
            action.payload.data.itemNbr
        ) {
          break;
        }
      }
      state.mbrPayments.mbrPaymentSearchResults.mbrPaymentsVO.splice(
        i,
        1,
        action.payload.data
      );

      return {
        ...state,
        mbrPaymentsVO: [
          ...state.mbrPayments.mbrPaymentSearchResults.mbrPaymentsVO,
        ],
      };

    case ActionTypes.BILLING_MBRPAYMENTS_PAGINATION:
      return {
        ...state,
        mbrPayments: {
          ...state.mbrPayments,
          nextPage: action.payload.data.nextPage,
          mbrPaymentSearchResults: {
            ...state.mbrPayments.mbrPaymentSearchResults,
            mbrPaymentsVO: [
              ...state.mbrPayments.mbrPaymentSearchResults.mbrPaymentsVO,
              ...action.payload.data.content,
            ],
          },
        },
      };
    default:
      return state;
  }
}
