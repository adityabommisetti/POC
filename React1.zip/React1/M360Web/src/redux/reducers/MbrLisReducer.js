import * as ActionTypes from "../../redux/types/ActionType";

const initialState = {
  lisDetails: []
}

export default function mbrLisReducer(state = initialState, action) {
  switch (action.type) {

    case ActionTypes.LIS_ACTIVE:
      return {
        ...state,
        lisDetails: [
          ...action.payload.data
        ]
      };

    default:

      return state;
  }
}
