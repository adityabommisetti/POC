import * as ActionTypes from "../../redux/types/ActionType";

const initialState = {
  notificationData: []
};

export default function notificationReducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.GET_NOTIFICATION_DATA:
      return {
        ...state,
        notificationData: [...action.payload.data]
      };

    default:
      return state;
  }
}
