import * as ActionTypes from "../../redux/types/ActionType";

export default function cityZipSearchReducer(state = [], action) {
  switch (action.type) {
    case ActionTypes.CITY_ZIP_SEARCH:
      return [...action.payload];

    case ActionTypes.RESET_ZIP_DATA_TABLE:
      return [];

    default:
      return state;
  }
}
