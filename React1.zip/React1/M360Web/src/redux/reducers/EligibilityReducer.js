import * as ActionTypes from "../../redux/types/ActionType";

export default function eligSearchReducer(state = {}, action) {
  switch (action.type) {
    case ActionTypes.ELIG_SEARCH:
      return { ...action.payload };

    default:
      return state;
  }
}
