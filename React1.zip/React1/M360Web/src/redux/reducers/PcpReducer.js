export default function pcpReducer(state = [], action) {

  switch (action.type) {
    case "PCP_SEARCH":
      return [...state, ...action.payload];

    default:
      return state;
  }
}
