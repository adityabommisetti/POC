import * as ActionTypes from "../../redux/types/ActionType";


const initialState = {
  selectedLetterData: {},
  lookUpList: {},
  LetterReqList: [],
  letterCreated: {},
  nextPage:false
};

export default function letterRequestReducer(state = initialState, action) {
  switch (action.type) {
// RESET_DATA
case ActionTypes.RESET_DATA:
  return {
    ...state,
    LetterReqList: action.payload.data,
    letterCreated: {}
  };

    case ActionTypes.SELECT_LETTER:
      return {
        ...state,
        selectedLetterData: action.payload.data,
        letterCreated: {}
      };
    case ActionTypes.CREATE_LETTER:
      return {
        ...state,
        letterCreated: action.payload.data
      };
    case ActionTypes.CLOSE_LETTER:
      
    const letterReqData =  action.payload.data.letterReqVOs.map(data=>{
      if(data.sourceType=== "A"){
        data.primaryId =  parseInt(data.primaryId);
      }
      return data;
    })
    return {
      ...state,
      LetterReqList: action.payload.data.letterReqVOs?[...letterReqData]:[],
      nextPage:action.payload.data.nextPage
    };
    case ActionTypes.POST_LOOKUP:
      return {
        ...state,
        lookUpList: action.payload.data
      };
    case ActionTypes.GET_LETTER_REQUEST:
    const leterReqData =  action.payload.data.letterReqVOs.map(data=>{
        if(data.sourceType=== "A"){
          data.primaryId =  parseInt(data.primaryId);
        }
        return data;
      })
      return {
        ...state,
        LetterReqList: action.payload.data.letterReqVOs?[...leterReqData]:[],
        nextPage:action.payload.data.nextPage
      };
      case ActionTypes.SEARCH_NEXT:
              return {
                ...state,
                LetterReqList:[...state.LetterReqList,...action.payload.data.content], 
                nextPage:action.payload.data.nextPage
              };
    default:
      return state;
  }
}
