import * as ActionTypes from "../../redux/types/ActionType";

const initialState = {
  searchResultsVo: [],
  wfCacheData: null,
  caseComments: [],
  supervisorFlag: "",
  riskData: [],
  riskDetails: [],
  caseTableData: [],
  supervisorData: [],
  userList: [],
  dashletData: [],
  showUserData: [],
  newUserList: [],
  supervisorList: [],
  newSupervisorList: [],
  adminList: [],
  workflowUserDetails: [],
};

export default function workflowReducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.WORKFLOW_SEARCH:
      return {
        ...state,
        searchCriteriaVo: {
          ...action.searchCriteriaVo,
        },
        searchResultsVo: {
          ...action.payload.data,
          nextPage: action.payload.data.nextPage,
        },
      };

    case ActionTypes.WF_SEARCH_NEXT_PAGE:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,

          caseData: [
            ...state.searchResultsVo.caseData,
            ...action.payload.data.content,
          ],
          nextPage: action.payload.data.nextPage,
        },
      };

    case ActionTypes.GET_WORKFLOW_CACHE_DATA:
      return {
        ...state,
        wfCacheData: {
          ...action.payload.data,
        },
      };

    case ActionTypes.WORKFLOW_GET_ACTIVITIES:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          nextPage: state.searchResultsVo.nextPage,
          activityData: [...action.payload.data],
        },
      };

    case ActionTypes.WORKFLOW_ASSIGN_WORK:
      return {
        ...state,
        searchResultsVo: {
          ...action.payload.data,
        },
      };

    case ActionTypes.WORKFLOW_CASE_UPDATE:
      return {
        ...state,
        searchResultsVo: {
          ...action.payload.data,
        },
      };

    case ActionTypes.REFRESH_DASHLETS:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          dashletData: [...action.payload.data],
        },
      };

    case ActionTypes.GET_CASE_COMMENTS:
      return {
        ...state,
        caseComments: [...action.payload.data],
      };

    case ActionTypes.ADD_CASEDATA_COMMENTS:
      const id = action.requestBody.caseId;
      const caseData = state.searchResultsVo.caseData.map((data) => {
        if (data.caseId === id) {
          data.commentIndicator = true;
        }
        return data;
      });
      console.log(caseData);
      return {
        ...state,
        caseComments: [...action.payload.data],
        searchResultsVo: {
          ...state.searchResultsVo,
          caseData: caseData,
        },
      };
    case ActionTypes.CASE_TABLE_DATA:
      return {
        ...state,
        caseTableData: action.payload.data,
      };
    case ActionTypes.AT_RISK_TABLE_DATA:
      return {
        ...state,
        atRiskDataSummary: action.payload.data,
      };
    case ActionTypes.AT_RISK_DETAIL:
      return {
        ...state,
        atRiskDetailData: action.payload.data,
      };

    case ActionTypes.SUPERVISOR_FLAG:
      return {
        ...state,
        supervisorFlag: action.payload.data,
      };

    case ActionTypes.ASSIGNMENT_LIMIT:
      return {
        ...state,
        wfCacheData: {
          ...state.wfCacheData,
          maxAssignableWork: action.payload.maxAssignableWork,
        },
      };
    case ActionTypes.RISK_DATA:
      return {
        ...state,
        riskData: [...action.payload.data],
      };
    case ActionTypes.RISK_DETAILS:
      return {
        ...state,
        riskDetails: [...action.payload.data],
      };

    case ActionTypes.FETCH_SUPERVISOR_DETAILS:
      return {
        ...state,
        supervisorData: [...action.payload.data],
      };
    case ActionTypes.FETCH_SUPERVISOR_TAB_DETAILS:
      return {
        ...state,
        supervisorData: action.payload.data.supervisorUserVOList,
        userList: action.payload.data.userList,
        supervisorList: action.payload.data.supervisorList,
      };
    case ActionTypes.USER_LIST:
      return {
        ...state,
        userList: action.payload.data,
      };
    case ActionTypes.FETCH_WFUSERS_DETAILS:
      return {
        ...state,
        showUserData: [...action.payload.data],
      };

    case ActionTypes.PRIORITY_STATUS:
      return {
        ...state,
        supervisorData: [...action.payload.data],
      };
    case ActionTypes.SUPERVISORSTATUS_UPDATE:
      return {
        ...state,
        supervisorData: [...action.payload.data],
      };

    case ActionTypes.SUPERVISOR_DASHLET_FETCH:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          dashletData: [...action.payload.data],
        },
      };
    case ActionTypes.MANUAL_POPUP_DELETE:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          dashletData: [...action.payload.data],
        },
      };

    case ActionTypes.WFSHOW_USERS_UPDATE:
      return {
        ...state,
        showUserData: [...action.payload.data],
      };

    case ActionTypes.ADD_WFUSERS_UPDATE:
      return {
        ...state,
        userList: action.payload.data.userList,
        supervisorList: action.payload.data.supervisorList,
        supUserList: action.payload.data.supUserList,
      };

    case ActionTypes.WFSHOW_USERS_DROPDOWNS:
      return {
        ...state,
        newUserList: action.payload.data.newUserList,
        supervisorList: action.payload.data.supervisorList,
        newSupervisorList: action.payload.data.newSupervisorList,
        adminList: action.payload.data.adminList,
      };
    case ActionTypes.WORKFLOW_USER_SEARCH:
      return {
        ...state,
        workflowUserDetails: action.payload.data,
      };
    case ActionTypes.WORKFLOW_USER_UPDATE:
      return {
        ...state,
        userList: action.payload.data.initial.userList,
        supervisorList: action.payload.data.initial.supervisorList,
        supUserList: action.payload.data.initial.supUserList,
        workflowUserDetails: action.payload.data.search,
      };

    default:
      return state;
  }
}
