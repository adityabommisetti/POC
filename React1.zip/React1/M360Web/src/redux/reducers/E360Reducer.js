import * as ActionTypes from "../../redux/types/ActionType";

const initialState = {
  loginVoE360: "",
};
export default function E360loginReducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.LOGIN_E360:
      return {
        loginVoE360: action.payload.data,
      };

    default:
      return state;
  }
}
