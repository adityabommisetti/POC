import * as ActionTypes from "../../redux/types/ActionType";

const initialState = {
  commentsList: []
}

export default function commentsReducer(state = initialState, action) {
  switch (action.type) {

    case ActionTypes.GET_COMMENTS:
    case ActionTypes.POST_COMMENT:
      return {
        ...state,
        commentsList: action.payload.data
      };
    default:

      return state;
  }
}
