import * as ActionTypes from "../../redux/types/ActionType";
import isEmpty from "lodash/isEmpty";

const initialState = {
  searchResultsVo: null,
  letterDetails: null,
  error: false,
  message: false,
  pcpSearchData: [],
  mbrSearchCriteria: {},
  facilitySearch: [],
  enrollSearchData: [],
  planType: null,
  accretionList: [],
  lepData: null,
  selectedMemberId: { memberId: "", applicationId: "" },
  searchAttributes: {},
  selectedTab: "",
  showAllActiveIndi: { showAllActiveInd: true, Ind: "" },
  searchCount: 0,
};

function trimToNullIfEmpty(data) {
  if (!isEmpty(data)) {
    return data;
  }
  return null;
}

function trimToEmptyArrayIfEmpty(data) {
  if (!isEmpty(data)) {
    return data;
  }
  return [];
}

export default function memberReducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.GET_MBR_LETTERS:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrLetterList: !isEmpty(action.payload.data)
            ? [...action.payload.data.lstLetterVO]
            : null,
        },

        letterDetails: action.payload.data
          ? [...action.payload.data.lstMbrCorrVO]
          : null,
      };
    case ActionTypes.LETTER_VARDATA:
      return {
        ...state,
        letterDetails: [...action.payload.data],
      };
    case ActionTypes.PCP_SHOW_ACTIVE:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrPcpInfoList: trimToNullIfEmpty(action.payload.data),
        },
      };

    case ActionTypes.PCP_DELETE:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrPcpInfoList: trimToNullIfEmpty(action.payload.data),
        },
      };

    case ActionTypes.PCP_UPDATE:
      for (let i = 0; i < action.payload.data.pcp.length; i++) {
        if (action.payload.data.pcp[i].doctorZip.length === 6) {
          action.payload.data.pcp[i].doctorZip = action.payload.data.pcp[
            i
          ].doctorZip
            .replace(/[^0-9]/g, "")
            .trim();
        }
      }
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrPcpInfoList: trimToNullIfEmpty(action.payload.data.pcp),
          mbrErrorList: [...action.payload.data.error],
        },
      };

    case ActionTypes.MEMBERPCP_POPUP_SEARCH:
      for (let i = 0; i < action.payload.data.length; i++) {
        if (action.payload.data[i].doctorZip.length === 6) {
          action.payload.data[i].doctorZip = action.payload.data[i].doctorZip
            .replace(/[^0-9]/g, "")
            .trim();
        }
      }
      return {
        ...state,
        pcpSearchData: [...action.payload.data],
      };

    case ActionTypes.RESET_MEMBER_SEARCH:
      let indexList = state.selectedMemberId;
      let updatedIndex = { ...indexList, ...action.payload };
      if (action.payload) {
        return {
          ...state,
          selectedMemberId: updatedIndex,
          selectedTab: "demo",
        };
      }
      break;
    case ActionTypes.SEARCH_ATTRIBUTES:
      let attributes = { ...state.searchAttributes, ...action.payload };
      if (action.payload) {
        return {
          ...state,
          searchAttributes: attributes,
        };
      }
      break;
    case ActionTypes.MEMBER_SEARCH:
      if (action.payload.length === 0) {
        return {
          ...state,
          searchResultsVo: null,
          message: true,
        };
      }

      return {
        ...state,
        searchCount: state.searchCount + 1,
        searchCriteriaVo: {
          ...action.searchCriteriaVo,
        },
        searchResultsVo: {
          ...action.payload.data,
          nextPage: action.payload.data.nextPage,
          mbrSearchList: [...action.payload.data.mbrSearchList],
          mbrDsInfoList: [...action.payload.data.mbrDsInfoList],
          mbrAddressList: [...action.payload.data.mbrAddressList],
          mbrEnrollmentList: action.payload.data.mbrEnrollmentList,
          // reset searchResultsVo state on member search
          mbrAgentInfoList: [],
          mbrPosInfoList: [],
          mbrTrrList: [],
          mbrLtcInfoList: [],
          mbrLetterList: [],
          mbrBillingList: [],
          mbrCobVOList: [],
          mbrPcpInfoList: [],
          accretionList: [],
          mbrCommentList: [],
          mbrOoaInfoList: [],
          mbrLisInfoList: [],
          mbrAsesList: [],
          mbrSoaPdf: { data: null, message: "" },
        },
        message: false,
        mbrSearchCriteria: { ...action.payload.data.mbrSearchList[0] },
      };

    case ActionTypes.MEMBER_SEARCH_PAGINATION:
      return {
        ...state,

        searchResultsVo: {
          ...state.searchResultsVo,
          mbrSearchList: [
            ...state.searchResultsVo.mbrSearchList,
            ...action.payload.data.content,
          ],
          nextPage: action.payload.data.nextPage,
        },
      };
    case ActionTypes.MEMBER_ROW_CLICK:
      return {
        ...state,

        searchResultsVo: {
          ...action.payload.data,
          nextPage: state.searchResultsVo.nextPage,
          mbrSearchList: [...state.searchResultsVo.mbrSearchList],
          mbrDsInfoList: [...action.payload.data.mbrDsInfoList],
          mbrAddressList: [...action.payload.data.mbrAddressList],
          mbrEnrollmentList: trimToEmptyArrayIfEmpty(
            action.payload.data.mbrEnrollmentList
          ),
          mbrErrorList: [...action.payload.data.mbrErrorList],
          mbrLisInfoList: trimToEmptyArrayIfEmpty(
            action.payload.data.mbrLisInfoList
          ),
          mbrPcpInfoList: trimToEmptyArrayIfEmpty(
            action.payload.data.mbrPcpInfoList
          ),
          mbrCommentList: trimToEmptyArrayIfEmpty(
            action.payload.data.mbrCommentList
          ),
          mbrCobVOList: trimToEmptyArrayIfEmpty(
            action.payload.data.mbrCobVOList
          ),
          mbrPosInfoList: trimToEmptyArrayIfEmpty(
            action.payload.data.mbrPosInfoList
          ),
          mbrTrrList: trimToEmptyArrayIfEmpty(action.payload.data.mbrTrrList),
          mbrOoaInfoList: trimToEmptyArrayIfEmpty(
            action.payload.data.mbrOoaInfoList
          ),
          mbrAgentInfoList: trimToEmptyArrayIfEmpty(
            action.payload.data.mbrAgentInfoList
          ),
          mbrBillingList: trimToEmptyArrayIfEmpty(
            action.payload.data.mbrBillingList
          ),
          accretionList: trimToEmptyArrayIfEmpty(
            action.payload.data.mbrAccretionList
          ),
          mbrLtcInfoList: trimToEmptyArrayIfEmpty(
            action.payload.data.mbrLtcInfoList
          ),
        },
        mbrSearchCriteria: { ...action.payload.member },

        lepData: trimToEmptyArrayIfEmpty(action.payload.data.eemLepMasterVO),
        mbrLetterList: trimToEmptyArrayIfEmpty(
          action.payload.data.mbrLetterList
        ),
      };

    case ActionTypes.GET_MEMBER_COMMENTS:
    case ActionTypes.POST_MEMBER_COMMENT:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrCommentList: trimToNullIfEmpty(action.payload.data),
        },
      };

    case ActionTypes.LIS_ACTIVE:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrLisInfoList: trimToNullIfEmpty(action.payload.data),
        },
      };

    case ActionTypes.SET_VALUE_MEMBER:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          [action.targetVo]: {
            ...state.searchResultsVo[action.targetVo],
            [action.name]: action.value,
          },
        },
      };
    case ActionTypes.SET_SELECTED_TAB:
      return {
        ...state,
        selectedTab: action.value,
      };

    case ActionTypes.LIS_UPDATE:
      return {
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrLisInfoList: trimToNullIfEmpty(action.payload.data),
        },
      };
    case ActionTypes.DSINFO_ACTIVE:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrDsInfoList: trimToNullIfEmpty(action.payload.data),
        },
      };

    case ActionTypes.DSINFO_DELETE:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrDsInfoList: trimToNullIfEmpty(action.payload.data),
        },
      };

    case ActionTypes.DSINFO_UPDATE:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrDsInfoList: trimToNullIfEmpty(action.payload.data),
        },
      };

    case ActionTypes.GET_ADDRESS:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrAddressList: trimToEmptyArrayIfEmpty(action.payload.data),
        },
      };
    case ActionTypes.DELETE_ADDRESS:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrAddressList: trimToEmptyArrayIfEmpty(action.payload.data),
        },
      };
    case ActionTypes.NEW_UPDATE_ADDRESS:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrAddressList: trimToEmptyArrayIfEmpty(
            action.payload.data.mbrAddressList
          ),
          mbrDsInfoList:
            action.payload.data.mbrDsInfoList.length > 0
              ? trimToEmptyArrayIfEmpty(action.payload.data.mbrDsInfoList)
              : state.searchResultsVo.mbrDsInfoList,
        },
      };

    case ActionTypes.DEMOGRAPHIC_UPDATE:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrDemographicVO: { ...action.payload.data },
        },
      };

    case ActionTypes.GET_LTC:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrLtcInfoList: trimToNullIfEmpty(action.payload.data),
        },
      };
    case ActionTypes.DELETE_LTC:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrLtcInfoList: trimToNullIfEmpty(action.payload.data),
        },
        mbrLtcInfoList: trimToNullIfEmpty(action.payload.data),
      };
    case ActionTypes.ADD_UPDATE_LTC:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrLtcInfoList: trimToNullIfEmpty(action.payload.data.mbrLtcInfoList),
          mbrErrorList: action.payload.data.errorList,
        },
      };
    case ActionTypes.GET_TRR:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrTrrList: trimToNullIfEmpty(action.payload.data),
        },
      };

    case ActionTypes.GET_TRR_DATA:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrTrrDataList: trimToNullIfEmpty(action.payload.data),
        },
      };

    case ActionTypes.GET_SOA_PDF:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrSoaPdf: {
            data: action.payload.data,
            message: action.payload.message,
          },
        },
      };

    case ActionTypes.ATTEST_LETTER:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrAttestPdf: {
            data: action.payload.data,
            message: action.payload.message,
          },
        },
      };
    case ActionTypes.LTC_FACILITY_SEARCH:
      return {
        ...state,
        facilitySearch: [
          ...(!isEmpty(action.payload) ? action.payload.data : []),
        ],
      };

    case ActionTypes.MEMBER_ENROLL:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          suppLepPlatino: action.payload.data.suppLepPlatino,
          mbrEnrollmentList: action.payload.data.enrollVOList
            ? trimToEmptyArrayIfEmpty(action.payload.data.enrollVOList)
            : trimToEmptyArrayIfEmpty(action.payload.data),
        },
      };

    case ActionTypes.MEMBER_ENROLL_SEARCH:
      return {
        ...state,
        enrollSearchData: [...action.payload.data],
      };

    case ActionTypes.GET_ASES:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrAsesList: trimToNullIfEmpty(action.payload.data),
        },
      };

    case ActionTypes.INSERT_UPDATE_ASES:
    case ActionTypes.SET_UPDATEASESDATA:
    case ActionTypes.DELETE_ASES:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrAsesList: Array.isArray(action.payload)
            ? trimToNullIfEmpty(action.payload)
            : trimToNullIfEmpty(action.payload.data),
        },
      };
    case ActionTypes.GET_POS:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrPosInfoList: trimToNullIfEmpty(action.payload.data),
        },
      };

    case ActionTypes.UPDATE_INSERT_POS:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrPosInfoList: trimToNullIfEmpty(action.payload.data),
        },
      };
    case ActionTypes.DELETE_POS:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrPosInfoList: trimToNullIfEmpty(action.payload.data),
        },
      };

    case ActionTypes.ENROLL_PLAN_TYPE:
      return {
        ...state,
        planType: action.payload.data,
      };

    case ActionTypes.GET_COB:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrCobVOList: trimToNullIfEmpty(action.payload.data),
        },
      };
    case ActionTypes.GET_OOA:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrOoaInfoList: trimToNullIfEmpty(action.payload.data),
        },
      };

    case ActionTypes.UPDATE_OOA:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrOoaInfoList: trimToNullIfEmpty(action.payload.data.mbrOoaList),
          mbrEnrollmentList:
            action.payload.data.mbrEnrollList &&
            action.payload.data.mbrEnrollList.length > 0
              ? trimToEmptyArrayIfEmpty(action.payload.data.mbrEnrollList)
              : [...state.searchResultsVo.mbrEnrollmentList],
        },
      };

    case ActionTypes.GET_BILLING:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrBillingList: trimToNullIfEmpty(action.payload.data),
        },
      };
    case ActionTypes.DELETE_BILLING:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrBillingList: trimToNullIfEmpty(action.payload.data),
        },
      };
    case ActionTypes.UPDATE_BILLING:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrBillingList: trimToNullIfEmpty(action.payload.data),
        },
      };
    case ActionTypes.GET_AGENT:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrAgentInfoList: trimToNullIfEmpty(action.payload.data),
        },
      };
    case ActionTypes.UPDATE_INSERT_AGENT:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrAgentInfoList: trimToNullIfEmpty(action.payload),
        },
      };
    case ActionTypes.DELETE_AGENT:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrAgentInfoList: trimToNullIfEmpty(action.payload.data),
        },
      };
    case ActionTypes.GET_ACCRETION:
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          accretionList: trimToNullIfEmpty(action.payload.data),
        },
      };
    case ActionTypes.SET_MBR_LEP_DATA:
      return {
        ...state,
        lepData: action.payload,
      };

    case ActionTypes.SET_LEP_VALUE:
      return {
        ...state,
        lepData: {
          ...state.lepData,
          [action.targetVo]: {
            ...state.lepData[action.targetVo],
            [action.name]: action.value,
          },
        },
      };

    case ActionTypes.SET_LEP_VO:
      return {
        ...state,
        lepData: {
          ...state.lepData,
          [action.targetVo]: action.payload,
        },
      };

    case ActionTypes.SET_MBR_ATTESTATION_CALL:
      return {
        ...state,
        lepData: {
          ...state.lepData,
          attestCallMasterVO: {
            ...state.lepData.attestCallMasterVO,
            inBoundInComplete: action.payload.inBoundInComplete
              ? [
                  ...state.lepData.attestCallMasterVO.inBoundInComplete,
                  ...action.payload.inBoundInComplete,
                ]
              : state.lepData.attestCallMasterVO.inBoundInComplete,
            inBoundInitial: action.payload.inBoundInitial
              ? [
                  ...state.lepData.attestCallMasterVO.inBoundInitial,
                  ...action.payload.inBoundInitial,
                ]
              : state.lepData.attestCallMasterVO.inBoundInitial,
            inBoundLate: action.payload.inBoundLate
              ? [
                  ...state.lepData.attestCallMasterVO.inBoundLate,
                  ...action.payload.inBoundLate,
                ]
              : state.lepData.attestCallMasterVO.inBoundLate,
            outBoundInComplete: action.payload.outBoundInComplete
              ? [
                  ...state.lepData.attestCallMasterVO.outBoundInComplete,
                  ...action.payload.outBoundInComplete,
                ]
              : state.lepData.attestCallMasterVO.outBoundInComplete,
            outBoundInitial: action.payload.outBoundInitial
              ? [
                  ...state.lepData.attestCallMasterVO.outBoundInitial,
                  ...action.payload.outBoundInitial,
                ]
              : state.lepData.attestCallMasterVO.outBoundInitial,
            le21TimerCheck: action.payload.le21TimerCheck
              ? action.payload.le21TimerCheck
              : state.lepData.attestCallMasterVO.le21TimerCheck,
          },
        },
      };
    case ActionTypes.UPDATE_MBR_ATTESTATION_CALL:
      return {
        ...state,
        lepData: {
          ...state.lepData,
          attestCallMasterVO: {
            ...state.lepData.attestCallMasterVO,
            obc1TimerCheck: action.payload.attestCallMasterVO.obc1TimerCheck
              ? action.payload.attestCallMasterVO.obc1TimerCheck
              : state.lepData.attestCallMasterVO.obc1TimerCheck,
            obc2TimerCheck: action.payload.attestCallMasterVO.obc2TimerCheck
              ? action.payload.attestCallMasterVO.obc2TimerCheck
              : state.lepData.attestCallMasterVO.obc2TimerCheck,
            le21TimerCheck: action.payload.attestCallMasterVO.le21TimerCheck
              ? action.payload.attestCallMasterVO.le21TimerCheck
              : state.lepData.attestCallMasterVO.le21TimerCheck,
            obc3TimerCheck: action.payload.attestCallMasterVO.obc3TimerCheck
              ? action.payload.attestCallMasterVO.obc3TimerCheck
              : state.lepData.attestCallMasterVO.obc3TimerCheck,
          },
          eemMbrLepInfoVOs: action.payload.eemMbrLepInfoVOs,
        },
      };
    case ActionTypes.SET_SHOWALLINDI:
      return {
        ...state,
        showAllActiveIndi: { ...action.payload },
      };
    case ActionTypes.SET_UPDATEDTA: {
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrDsInfoList: trimToNullIfEmpty(action.payload),
        },
      };
    }
    case ActionTypes.SET_UPDATEENROLLDATA: {
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrEnrollmentList: trimToNullIfEmpty(action.payload),
        },
      };
    }
    case ActionTypes.SET_UPDATEADDRESSDATA: {
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrAddressList: trimToNullIfEmpty(action.payload),
        },
      };
    }
    case ActionTypes.SET_UPDATEOOADATA: {
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrOoaInfoList: trimToNullIfEmpty(action.payload),
        },
      };
    }
    case ActionTypes.SET_UPDATELISDATA: {
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrLisInfoList: trimToNullIfEmpty(action.payload),
        },
      };
    }
    case ActionTypes.SET_UPDATEPCPDATA: {
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrPcpInfoList: trimToNullIfEmpty(action.payload),
        },
      };
    }
    case ActionTypes.SET_UPDATELTCDATA: {
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrLtcInfoList: trimToNullIfEmpty(action.payload),
        },
      };
    }
    case ActionTypes.SET_UPDATEAGENTDATA: {
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrAgentInfoList: trimToNullIfEmpty(action.payload),
        },
      };
    }
    case ActionTypes.SET_UPDATECOBDATA: {
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrCobVOList: trimToNullIfEmpty(action.payload),
        },
      };
    }
    case ActionTypes.SET_UPDATEPOSDATA: {
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrPosInfoList: trimToNullIfEmpty(action.payload),
        },
      };
    }
    case ActionTypes.SET_UPDATEBILINGDATA: {
      return {
        ...state,
        searchResultsVo: {
          ...state.searchResultsVo,
          mbrBillingList: trimToNullIfEmpty(action.payload),
        },
      };
    }
    case ActionTypes.RESET_SERACH: {
      return {
        ...state,
        searchAttributes: {
          ...state.searchAttributes,
          memberSearch: {},
        },
      };
    }
    default:
      return state;
  }
}
