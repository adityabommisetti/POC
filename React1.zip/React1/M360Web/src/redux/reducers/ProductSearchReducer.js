export default function productSearchReducer(state = [], action) {
  switch (action.type) {
    case "GROUP_SEARCH":
      return [...state, ...action.payload];

    default:
      return state;
  }
}
