import * as ActionTypes from "../../redux/types/ActionType";

const initialState = {
  loginVo: {},
  authenticated: false,
  errorMsg: "",
  servicesEnabled: [],
};
export default function loginReducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.LOGIN_SUCCESS:
      return {
        loginVo: action.payload.object,
        servicesEnabled: action.payload.listObject,
        authenticated: true,
        errorMsg: "",
        profiles: action.payload.profiles,
        isPassExpired: action.payload.object.pwdExpired,
        mbdAggRequired: action.payload.object.mbdAggRequired,
      };

    case ActionTypes.LOGIN_FAILED:
      return {
        errorMsg: action.errorMsg,
      };

    default:
      return state;
  }
}
