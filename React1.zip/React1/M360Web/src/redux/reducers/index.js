import * as ActionTypes from "../../redux/types/ActionType";

import CommentsReducer from "./../reducers/CommentsReducer";
import applPopupReducer from "./../reducers/ApplPopupReducer";
import { applSearchReducer } from "./../reducers/ApplSearchResultReducer";
import cacheDataReducer from "./../reducers/CacheDataReducer";
import { combineReducers } from "redux";
import currApplReducer from "./../reducers/CurrentApplReducer";
import letterRequestReducer from "./../reducers/LetterRequestReducer";
import letterReviewReducer from "./../reducers/LetterReviewReducer";
import loginReducer from "./../reducers/LoginReducer";
import mbrLisReducer from "./../reducers/MbrLisReducer";
import memberCacheReducer from "./../reducers/MbrCacheReducer";
import memberReducer from "./../reducers/MbrReducer";
import { spinnerReducer } from "./../reducers/SpinnerReducer";
import timerReducer from "./../reducers/TimerReducer";
import workflowReducer from "./../reducers/WorkflowReducer";
import serurityReducer from "./../reducers/SecurityReducer";
import billingReducer from "./../reducers/BillingReducer";
import notificationReducer from "./../reducers/notificationReducer";
import dashboardReducer from "./../reducers/DashboardReducer";
import E360loginReducer from "./../reducers/E360Reducer"

const appReducer = combineReducers({
  applSearch: applSearchReducer,
  spinner: spinnerReducer,
  memberSearch: memberReducer,
  letterRequest: letterRequestReducer,
  letterReview: letterReviewReducer,
  membercache: memberCacheReducer,
  comments: CommentsReducer,
  applPopupVO: applPopupReducer,
  dropdowns: cacheDataReducer,
  currApplVo: currApplReducer,
  loginData: loginReducer,
  lisSearch: mbrLisReducer,
  timerSearch: timerReducer,
  workflow: workflowReducer,
  security: serurityReducer,
  billingReducer: billingReducer,
  notificationReducer: notificationReducer,
  dashboard: dashboardReducer,
  E360login:E360loginReducer,

});

const rootReducer = (state, action) => {
  if (action.type === ActionTypes.LOGOUT_ACTION) {
    state = undefined;
  }

  return appReducer(state, action);
};

export default rootReducer;
