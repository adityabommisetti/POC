import * as ActionTypes from "../../redux/types/ActionType";

const initialState = {
  agencyData: [],
  pcpPopupData: [],
  productSearchData: [],
  cityZipSearchData: [],
  mbdData: []
};

export default function applPopupReducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.AGENCY_SEARCH:
      return {
        ...state,
        agencyData: [...action.payload.data]
      };
    case ActionTypes.PCP_SEARCH:
      return {
        ...state,
        pcpPopupData: action.payload.data
      };
    case ActionTypes.GROUP_SEARCH:
      return {
        ...state,
        productSearchData: [...action.payload.data]
      };
    case ActionTypes.CITY_ZIP_SEARCH:
      return {
        ...state,
        cityZipSearchData: [...action.payload.data]
      };
      case ActionTypes.RESET_CITY_ZIP_SEARCH:
        return {
          ...state,
          cityZipSearchData: []
        };
    case ActionTypes.ELIG_SEARCH:
      return {
        ...state,
        mbdData: { ...action.payload.data }
      };

    default:
      return state;
  }
}
