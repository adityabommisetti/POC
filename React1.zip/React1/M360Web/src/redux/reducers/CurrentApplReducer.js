export default function currApplReducer(state = {}, action) {
    switch (action.type) {
      case "SAVE_CURR_APPL":
        return {...action.payload};
  
      default:
        return state;
    }
  }
  