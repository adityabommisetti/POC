export default function agencyReducer(state = [], action) {
  switch (action.type) {
    case "AGENCY_SEARCH":
      return [...state, ...action.payload];

    default:
      return state;
  }
}
