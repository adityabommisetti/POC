import * as ActionTypes from "../../redux/types/ActionType";

import * as URL from "../../services/API_URL";

import axios from "../../utils/axios";

export const updateRoleData = (body, data) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .post(URL.UPDATE_ROLE_DATA, body, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            dispatch({ type: ActionTypes.UPDATE_ROLE_DATA, payload: data });
          } else {
            dispatch({ type: ActionTypes.UPDATE_ROLE_DATA, payload: [] });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return response.message;
        })

        .catch((error) => {
          error.response &&
            error.response &&
            dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return error.respons;
        });
    }
    return "success";
  };
};

export const deleteService = (body, servicedata) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .post(URL.DELETE_SERVICE, body, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            let data = deleteServiceFilter(body.serviceId, servicedata);

            dispatch({ type: ActionTypes.DELETE_SERVICE, payload: data });
          } else {
            dispatch({ type: ActionTypes.DELETE_SERVICE, payload: [] });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return response.data.message;
        })

        .catch((error) => {
          error.response &&
            error.response &&
            dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return error.respons;
        });
    }
    return "success";
  };
};

export const addService = (body, servicedata) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .post(URL.ADD_SERVICE, body, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            let data = addServiceFilter(body.serviceId, servicedata);

            dispatch({ type: ActionTypes.ADD_SERVICE, payload: data });
          } else {
            dispatch({ type: ActionTypes.ADD_SERVICE, payload: [] });
          }

          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return response.data;
        })

        .catch((error) => {
          error.response &&
            error.response &&
            dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return error.response.data;
        });
    }
    return "success";
  };
};

export const getRequest = (API_URL, Success_Action) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .get(API_URL, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (response.status === 200) {
            dispatch({ type: Success_Action, payload: response.data });
            return response.data.message;
          } else {
            dispatch({ type: Success_Action, payload: [] });
          }
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.data) {
            return error.response.data.message;
          }
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "success";
  };
};

export const postRequest = (API_URL, Success_Action) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .post(
          API_URL,
          {},
          {
            headers: { "x-auth-token": localStorage.getItem("token") },
          }
        )
        .then((response) => {
          if (response.status === 200) {
            dispatch({ type: Success_Action, payload: response.data });
          } else {
            dispatch({ type: Success_Action, payload: [] });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return response.data.message;
        })

        .catch((error) => {
          error.response &&
            error.response.data &&
            dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return error.response.data.message;
        });
    }
    return "success";
  };
};

export const getServiceData = (groupId) => {
  return postRequest(
    URL.GET_SERVICE_DATA + groupId,
    ActionTypes.GET_SERVICE_DATA
  );
};

export const getUserRoleData = () => {
  return getRequest(URL.GET_USER_ROLE_DATA, ActionTypes.GET_USER_ROLE_DATA);
};

const addServiceFilter = (serviceId, serviceList) => {
  let data = serviceList.availableServices.filter((role) => {
    return serviceId.includes(role.serviceId);
  });
  serviceList.enabledServices = [...serviceList.enabledServices, ...data];

  serviceList.availableServices = serviceList.availableServices.filter(
    (role) => {
      return !data.includes(role);
    }
  );

  return serviceList;
};

const deleteServiceFilter = (serviceId, serviceList) => {
  let data = serviceList.enabledServices.filter((role) => {
    return serviceId.includes(role.serviceId);
  });

  serviceList.availableServices = [...serviceList.availableServices, ...data];

  serviceList.enabledServices = serviceList.enabledServices.filter((role) => {
    return !data.includes(role);
  });

  return serviceList;
};
