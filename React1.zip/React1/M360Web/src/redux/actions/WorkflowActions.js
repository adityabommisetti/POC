import * as ActionTypes from "../../redux/types/ActionType";
import * as URL from "../../services/API_URL";

import axios from "../../utils/axios";

export const postRequest = (API_URL, body, Success_Action) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .post(API_URL, body, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            // for (let i = 0; i < response.data.data.caseData.length; i++) {
            //   let test = { checked: "N" };
            //   Object.assign(response.data.data.caseData[i], test);
            // }
            if (API_URL === URL.WORKFLOW_USER_UPDATE) {
              for (const key of Object.keys(response.data.data.initial)) {
                if (
                  Array.isArray(response.data.data.initial[key]) &&
                  response.data.data.initial[key]
                ) {
                  if (key == "supervisorList")
                    response.data.data.initial[key].splice(0, 0, {
                      label: "Select",
                      value: "",
                    });
                }

                console.log(response.data.data.initial);
              }
            }

            dispatch({
              type: Success_Action,
              payload: response.data,
              requestBody: body,
            });
          } else {
            dispatch({ type: Success_Action, payload: [], requestBody: body });
          }
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
            requestBody: body,
          });
          return response.data.message;
        })

        .catch((error) => {
          error.response &&
            error.response.data &&
            dispatch({
              type: ActionTypes.SET_SPINNER,
              payload: false,
              requestBody: body,
            });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return error.response.data.message;
        });
    }
    return "success";
  };
};

export const getRequest = (API_URL, Success_Action) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .get(API_URL, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (
            API_URL === URL.WFSHOW_USER_DROPDOWNS ||
            API_URL === URL.GET_SUPERVISOR_TAB_DETAILS
          ) {
            for (const key of Object.keys(response.data.data)) {
              if (
                Array.isArray(response.data.data[key]) &&
                response.data.data[key]
              ) {
                if (key !== "supervisorUserVOList")
                  response.data.data[key].splice(0, 0, {
                    label: "Select",
                    value: "",
                  });
              }

              console.log(response.data.data);
            }
          }

          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (response.status === 200) {
            dispatch({ type: Success_Action, payload: response.data });
            return response.data.message;
          } else {
            dispatch({ type: Success_Action, payload: [] });
          }
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.data) {
            return error.response.data.message;
          }
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "success";
  };
};

export const fetchWfCacheData = () => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .get(URL.GET_WORKFLOW_CACHE_DATA, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          // for (const key of Object.keys(response.data.data)) {
          //   if (
          //     Array.isArray(response.data.data[key]) &&
          //     response.data.data[key]
          //   )
          //     if (key === "queueList") {
          //       response.data.data[key].splice(0, 0, {
          //         value: "",
          //         label: "Select",
          //       });
          //     }
          // }
          dispatch({
            type: ActionTypes.GET_WORKFLOW_CACHE_DATA,
            payload: response.data,
          });
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "success";
  };
};

export const searchWorkFlow = (searchVO) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .post(URL.WORKFLOW_SEARCH, searchVO, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            for (let i = 0; i < response.data.data.caseData.length; i++) {
              let test = { checked: "N" };
              Object.assign(response.data.data.caseData[i], test);
            }

            dispatch({
              type: ActionTypes.WORKFLOW_SEARCH,
              searchCriteriaVo: searchVO,
              payload: response.data,
            });
          } else {
            dispatch({ type: ActionTypes.WORKFLOW_SEARCH, payload: [] });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return "success";
        })

        .catch((error) => {
          error.response &&
            error.response.data &&
            dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return error;
        });
    }
    return "success";
  };
};

export const assignWork = (fetchSize) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .get(URL.WORKFLOW_ASSIGN_WORK + fetchSize, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            for (let i = 0; i < response.data.data.caseData.length; i++) {
              let test = { checked: "N" };
              Object.assign(response.data.data.caseData[i], test);
            }

            dispatch({
              type: ActionTypes.WORKFLOW_ASSIGN_WORK,
              payload: response.data,
            });
          } else {
            dispatch({ type: ActionTypes.WORKFLOW_ASSIGN_WORK, payload: [] });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return "success";
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return error.response.data.message;
        });
    }
    return "success";
  };
};

export const getActivities = (caseId) => {
  return getRequest(
    URL.WORKFLOW_GET_ACTIVITIES + caseId,
    ActionTypes.WORKFLOW_GET_ACTIVITIES
  );
};

export const updateCase = (test) => {
  return postRequest(
    URL.CASE_STATUS_UPDATE,
    test,
    ActionTypes.WORKFLOW_CASE_UPDATE
  );
};

export const refreshDashlets = (userName, tabVal) => {
  return getRequest(
    URL.REFRESH_DASHLETS + "/" + userName + "/" + tabVal,
    ActionTypes.REFRESH_DASHLETS
  );
};

export const getCaseDataComments = (test) => {
  return postRequest(URL.CASE_COMMENTS, test, ActionTypes.GET_CASE_COMMENTS);
};

export const addCaseComments = (test) => {
  return postRequest(
    URL.ADD_CASE_COMMENTS,
    test,
    ActionTypes.ADD_CASEDATA_COMMENTS
  );
};

export const isSuperVisor = () => {
  return getRequest(URL.CHECK_SUPERVISOR, ActionTypes.SUPERVISOR_FLAG);
};

export const updateAssignmentLimit = (newAssignmentLimit) => {
  const API_URL = URL.ASSIGNMENT_LIMIT + newAssignmentLimit;

  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .post(
          API_URL,
          {},
          {
            headers: { "x-auth-token": localStorage.getItem("token") },
          }
        )
        .then((response) => {
          response.data.maxAssignableWork = 0;
          if (response.status === 200) {
            response.data.maxAssignableWork = newAssignmentLimit;
            dispatch({
              type: ActionTypes.ASSIGNMENT_LIMIT,
              payload: response.data,
            });
          } else {
            dispatch({ type: ActionTypes.ASSIGNMENT_LIMIT, payload: [] });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return response.data.message;
        })

        .catch((error) => {
          error.response &&
            error.response.data &&
            dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return error.response.data.message;
        });
    }
    return "success";
  };
};

export const getSupervisorDetails = (userId, supOrAdminId) => {
  return getRequest(
    URL.GET_SUPERVISOR_DETAILS +
      "?userId=" +
      userId +
      "&supOrAdminId=" +
      supOrAdminId,
    ActionTypes.FETCH_SUPERVISOR_DETAILS
  );
};

export const getUserDetails = (supervisorName) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .get(URL.USER_LIST + supervisorName, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            response.data.data.splice(0, 0, {
              label: "Select",
              value: "",
            });

            dispatch({
              type: ActionTypes.USER_LIST,
              payload: response.data,
            });
          } else {
            dispatch({ type: ActionTypes.USER_LIST, payload: [] });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });

          return "success";
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return error.response.data.message;
        });
    }
    return "success";
  };
};

export const getSupervisorTabDetails = () => {
  return getRequest(
    URL.GET_SUPERVISOR_TAB_DETAILS,
    ActionTypes.FETCH_SUPERVISOR_TAB_DETAILS
  );
};

export const supervisorUpdateStatus = (data) => {
  return postRequest(
    URL.SUPERVISOR_STATUS_UPDATE,
    data,
    ActionTypes.SUPERVISORSTATUS_UPDATE
  );
};

export const manualPopupDelete = (data) => {
  return postRequest(
    URL.MANUAL_POPUP_DELETE,
    data,
    ActionTypes.MANUAL_POPUP_DELETE
  );
};

export const priorityUpdateStatus = (data) => {
  return postRequest(
    URL.PRIORITY_STATUS_UPDATE,
    data,
    ActionTypes.PRIORITY_STATUS
  );
};

export const getSupervisorDashlet = (userName) => {
  return getRequest(
    URL.DASHLET_SUPERVISOR + userName,
    ActionTypes.SUPERVISOR_DASHLET_FETCH
  );
};

export const loadShowUsers = (data) => {
  return getRequest(
    URL.FETCH_WFUSER_DETAILS,
    data,
    ActionTypes.FETCH_WFUSERS_DETAILS
  );
};
export const showUsersUpdate = (data) => {
  return postRequest(
    URL.WFSHOW_USER_UPDATE,
    data,
    ActionTypes.WFSHOW_USERS_UPDATE
  );
};
export const addWFuser = (data) => {
  let body = {
    role: data.role,
    userId: data.userId,
    supervisorId: data.supervisorId,
  };

  return postRequest(
    URL.ADD_WFUSER_UPDATE,
    body,
    ActionTypes.ADD_WFUSERS_UPDATE
  );
};
export const showUserDropdowns = () => {
  return getRequest(
    URL.WFSHOW_USER_DROPDOWNS,
    ActionTypes.WFSHOW_USERS_DROPDOWNS
  );
};

export const workflowSearchNextPage = (searchVO) => {
  return postRequest(
    URL.WF_SEARCH_NEXT_PAGE,
    searchVO,
    ActionTypes.WF_SEARCH_NEXT_PAGE
  );
};

export const getWFuserDetails = (name, supervisiorId) => {
  const body = {
    name: name,
    searchSupervisorId: supervisiorId,
  };
  return postRequest(
    URL.WORKFLOW_USER_SEARCH,
    body,
    ActionTypes.WORKFLOW_USER_SEARCH
  );
};
export const updatWFuserDetails = (body) => {
  return postRequest(
    URL.WORKFLOW_USER_UPDATE,
    body,
    ActionTypes.WORKFLOW_USER_UPDATE
  );
};
