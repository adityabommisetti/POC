import * as ActionTypes from "../../redux/types/ActionType";
import * as URL from "../../services/API_URL";

import axios from "../../utils/loginaxios";

export const getUserInfo = () => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .get(URL.GET_USER_INFO, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.data.statusCode === 200) {
            dispatch({
              type: ActionTypes.LOGIN_SUCCESS,
              payload: response.data,
            });
          } else {
            localStorage.clear();
            dispatch({
              type: ActionTypes.LOGIN_FAILED,
              errorMsg: response.data.message,
            });
          }

          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })
        .catch((error) => {
          localStorage.clear();
          console.log(error);

          dispatch({
            type: ActionTypes.LOGIN_FAILED,
            errorMsg: "",
          });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        });
    }
    return "done";
  };
};

export const loginAction = (loginBody) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      var authorizationBasic = window.btoa(
        loginBody.userId + ":" + loginBody.pwd
      );
      return axios
        .post(URL.LOGIN, "", {
          headers: { Authorization: "Basic " + authorizationBasic },
        })
        .then((response) => {
          if (response.data.statusCode === 200) {
            var token = response.headers["x-auth-token"];
            localStorage.setItem("token", "Bearer " + token);
            localStorage.setItem("login", true);
            dispatch({
              type: ActionTypes.LOGIN_SUCCESS,
              payload: response.data,
            });
          } else {
            localStorage.clear();
            dispatch({
              type: ActionTypes.LOGIN_FAILED,
              errorMsg: response.data.message,
            });
          }

          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })
        .catch((error) => {
          localStorage.clear();
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          dispatch({
            type: ActionTypes.LOGIN_FAILED,
            errorMsg: error.response.data.message,
          });
        });
    }
    return "done";
  };
};

export const logoutAction = () => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .get(URL.LOGOUT, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          localStorage.clear();
          dispatch({ type: ActionTypes.LOGOUT_ACTION });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })
        .catch((error) => {
          localStorage.clear();
          console.log(error);
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        });
    }
    return "done";
  };
};

export const postRequest = (API_URL, body, Success_Action) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .post(API_URL, body, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            dispatch({ type: Success_Action, payload: response.data });
          } else {
            dispatch({ type: Success_Action, payload: [] });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return response.data;
        })

        .catch((error) => {
          error.response &&
            error.response.data &&
            dispatch({ type: ActionTypes.SET_SPINNER, payload: false });

          return error.response.data;
        });
    }
    return "success";
  };
};

export const loginE360 = (data) => {
  return postRequest(URL.LOGIN_E360, data, ActionTypes.LOGIN_E360);
};
