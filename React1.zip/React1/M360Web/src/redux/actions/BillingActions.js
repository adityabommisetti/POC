import * as ActionTypes from "../../redux/types/ActionType";
import * as URL from "../../services/API_URL";
import axios from "../../utils/axios";

function postRequest(API_URL, body, Success_Action) {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .post(API_URL, body, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            //To Save the SearchCriterio in REdux store for pagination
            if (
              URL.BILLING_INVOICE_SEARCH === API_URL ||
              URL.BILLING_PAYMENT_SEARCH === API_URL ||
              URL.BILLING_MBRPAYMENTS_SEARCH === API_URL ||
              URL.BILLING_DRAFT_SEARCH === API_URL
            ) {
              dispatch({
                type: Success_Action,
                payload: response.data,
                searchCriteriaVo: body,
              });
            } else {
              dispatch({ type: Success_Action, payload: response.data });
            }
          } else {
            dispatch({ type: Success_Action, payload: { data: [] } });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return response.data;
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          dispatch({ type: Success_Action, payload: { data: [] } });
          if (error.response && error.response.data) {
            return error.response.data;
          }
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return null;
  };
}

export const getRequest = (API_URL, Success_Action) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .get(API_URL, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (response.status === 200) {
            dispatch({ type: Success_Action, payload: response.data });
            return response.data;
          } else {
            dispatch({ type: Success_Action, payload: [] });
          }
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.data) {
            return error.response.data;
          }
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "success";
  };
};

export function getBillingCacheData(API_URL, Success_Action) {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .get(API_URL, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          for (const key of Object.keys(response.data.data)) {
            if (
              Array.isArray(response.data.data[key]) &&
              response.data.data[key]
            ) {
              if (key != "lstInvoiceGroup")  {
                response.data.data[key].splice(0, 0, {
                  value: "",
                  label: "Select",
                });
              }
            }
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (response.status === 200) {
            dispatch({ type: Success_Action, payload: response.data });
          } else {
            dispatch({ type: Success_Action, payload: [] });
          }
          return response.data;
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.data) {
            return error.response.data;
          }
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "success";
  };
}

export const searchInvoice = (data) => {
  return postRequest(
    URL.BILLING_INVOICE_SEARCH,
    data,
    ActionTypes.BILLING_INVOICE_SEARCH
  );
};

export const invoiceSearchNext = (data) => {
  return postRequest(
    URL.BILLING_INVOICE_PAGINATION,
    data,
    ActionTypes.BILLING_INVOICE_PAGINATION
  );
};

export const invoiceSearchSelect = (data) => {
  return postRequest(
    URL.BILLING_INVOICE_SEARCH_SELECT,
    data,
    ActionTypes.BILLING_INVOICE_SEARCH_SELECT
  );
};

export const getDetailAmount = (data) => {
  return postRequest(
    URL.BILLING_INVOICE_DETAIL_AMOUNT,
    data,
    ActionTypes.BILLING_INVOICE_DETAIL_AMOUNT
  );
};

export const setRefFlag = (value) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.SET_INVOICE_COMMENT_REF_FLAG,
      payload: value,
    });
  };
};

export const setAdjustmentComments = (value) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.SET_INVOICE_ADJUSTMENT_COMMENT,
      payload: value,
    });
  };
};

export const adjustmentUpdate = (data) => {
  return postRequest(
    URL.BILLING_INVOICE_ADJUSTMENT,
    data,
    ActionTypes.BILLING_INVOICE_ADJUSTMENT
  );
};

export const invoiceTransfer = (data) => {
  return postRequest(
    URL.BILLING_INVOICE_TRANSFER,
    data,
    ActionTypes.BILLING_INVOICE_TRANSFER
  );
};

export const invoiceMbrGrpSearch = (data) => {
  return postRequest(
    URL.BILLING_INVOICE_MBR_GRP_SEARCH,
    data,
    ActionTypes.BILLING_INVOICE_MBR_GRP_SEARCH
  );
};

export const saveComments = (data) => {
  return postRequest(
    URL.BILLING_INVOICE_SAVE_COMMENT,
    data,
    ActionTypes.BILLING_INVOICE_SAVE_COMMENT
  );
};

export const setInvoiceTableIndex = (index) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.SET_INVOICE_TABLE_INDEX,
      payload: index,
    });
  };
};

export const getPaymentEntrySearch = (data) => {
  return postRequest(
    URL.BILLING_PAYMENT_SEARCH,
    data,
    ActionTypes.BILLING_PAYMENT_SEARCH
  );
};

export const getPaymentDetail = (selectedVO) => {
  return postRequest(
    URL.BILLING_PAYMENT_DETAILS,
    selectedVO,
    ActionTypes.BILLING_PAYMENT_DETAILS
  );
};

export const getBillingPaymentSearch = (searchVO) => {
  return postRequest(
    URL.BILLING_MBRPAYMENTS_SEARCH,
    searchVO,
    ActionTypes.BILLING_MBRPAYMENTS_SEARCH
  );
};

export const getBillingPaymentDetailInvoice = (selectedVO) => {
  return postRequest(
    URL.BILLING_MBRPAYMENTS_INVOICE,
    selectedVO,
    ActionTypes.BILLING_MBRPAYMENTS_INVOICE
  );
};

export const newPaymentEntry = (params) => {
  return postRequest(
    URL.BILLING_PAYMENT_NEWPAYMENT,
    params,
    ActionTypes.BILLING_PAYMENT_NEWPAYMENT
  );
};

export const paymentEntrySearchNext = (params) => {
  return postRequest(
    URL.BILLING_PAYMENT_ENTRY_PAGINATION,
    params,
    ActionTypes.BILLING_PAYMENT_ENTRY_PAGINATION
  );
};

export const addPaymentdetails = (params) => {
  return postRequest(
    URL.BILLING_PAYMENT_ADDPAYMENT_DETAIL,
    params,
    ActionTypes.BILLING_PAYMENT_ADDPAYMENT_DETAIL
  );
};

export const paymentHeaderUpdate = (params, selectedIndex) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.BILLING_PAYMENT_HEADER_UPDATE, params, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            response.data.selectedIndex = selectedIndex;
            dispatch({
              type: ActionTypes.BILLING_PAYMENT_HEADER_UPDATE,
              payload: response.data,
            });
          } else {
            dispatch({
              type: ActionTypes.BILLING_PAYMENT_HEADER_UPDATE,
              payload: [],
            });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return "success";
        })

        .catch((error) => {
          error.response &&
            error.response.data &&
            dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return error.response.data.message;
        });
    }
    return "success";
  };
};

export const paymentDetailsUpdate = (params) => {
  return postRequest(
    URL.BILLING_PAYMENT_DETAILS_UPDATE,
    params,
    ActionTypes.BILLING_PAYMENT_DETAILS_UPDATE
  );
};
export const setPaymentHeaderIndex = (body) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.BILLING_PAYMENTENTRY_HEADERTABLE_INDEX,
      payload: body,
    });
  };
};
export const setPaymentDetailsIndex = (body) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.BILLING_PAYMENTENTRY_DETAILSTABLE_INDEX,
      payload: body,
    });
  };
};

export const setMbrPaymentsIndex = (body) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.BILLING_MBRPAYMENTS_TABLE_INDEX,
      payload: body,
    });
  };
};
export const updateMbrPayments = (params) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.BILLING_MBRPAYMENTS_UPDATE, params, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            response.data.selectedIndex = params.selectedIndex;
            dispatch({
              type: ActionTypes.BILLING_MBRPAYMENTS_UPDATE,
              payload: response.data,
            });
          } else {
            dispatch({
              type: ActionTypes.BILLING_MBRPAYMENTS_UPDATE,
              payload: [],
            });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return "success";
        })
        .catch((error) => {
          error.response &&
            error.response.data &&
            dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return error.response.data.message;
        });
    }
    return "success";
  };
};

export const getBillingPaymentCache = () => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .get(URL.BILLING_CACHE_DATA, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          for (const key of Object.keys(response.data.data)) {
            if (
              Array.isArray(response.data.data[key]) &&
              response.data.data[key]
            ) {
              response.data.data[key].splice(0, 0, {
                value: "",
                label: "Select",
              });
            }
          }
          dispatch({
            type: ActionTypes.BILLING_CACHE_DATA,
            payload: response.data,
          });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })
        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "success";
  };
};

export const mbrPaymentsSearchNext = (params) => {
  return postRequest(
    URL.BILLING_MBRPAYMENTS_PAGINATION,
    params,
    ActionTypes.BILLING_MBRPAYMENTS_PAGINATION
  );
};

export const draftSearch = (params) => {
  return postRequest(
    URL.BILLING_DRAFT_SEARCH,
    params,
    ActionTypes.BILLING_DRAFT_SEARCH
  );
};

export const draftDetailSearch = (params) => {
  return postRequest(
    URL.BIILLING_DRAFT_DETAIL_SEARCH,
    params,
    ActionTypes.BILLING_DRAFT_DETAIL_SEARCH
  );
};

export const setDraftTableIndex = (body) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.BILLING_DRAFT_TABLE_INDEX,
      payload: body,
    });
  };
};

export const draftSearchNext = (params) => {
  return postRequest(
    URL.BILLING_DRAFT_PAGINATION,
    params,
    ActionTypes.BILLING_DRAFT_PAGINATION
  );
};
