import * as ActionTypes from "../../redux/types/ActionType";
import * as URL from "../../services/API_URL";

import axios from "../../utils/axios";

function postRequest(API_URL, body, Success_Action) {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .post(API_URL, body, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            let response1 = null;
            if (Array.isArray(response.data.data.emmTimersVOs)) {
              response1 = response.data.data.emmTimersVOs;
            } else {
              response1 = response.data.data.content;
            }

            for (let i = 0; i < response1.length; i++) {
              let test = { editValue: true, editable: true };
              Object.assign(response1[i], test);
            }

            dispatch({ type: Success_Action, payload: response.data });
          } else {
            dispatch({ type: Success_Action, payload: [] });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })

        .catch((error) => {
          error.response && error.response.data && console.log(error);
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return error.response.data.message;
        });
    }
    return null;
  };
}

function getRequest(API_URL, Success_Action) {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .get(API_URL, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            dispatch({ type: Success_Action, payload: response.data });
          } else {
            dispatch({ type: Success_Action, payload: [] });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          dispatch({ type: Success_Action, payload: [] });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return null;
  };
}

export const timerGetDetails = (searchVO) => {
  return postRequest(URL.GET_TIMER, searchVO, ActionTypes.GET_TIMER_DETAILS);
};

export const timerUpdate = (searchVO) => {
  return postRequest(URL.TIMER_CALL, searchVO, ActionTypes.TIMER_UPDATE);
};

export const getTimerType = () => {
  const SERVICE_URL = URL.GET_TIMER_TYPE;
  return getRequest(SERVICE_URL, ActionTypes.GET_TIMER_TYPE);
};

export const SearchNextPage = (params) => {
  return postRequest(
    URL.SEARCH_NEXT_TIMERS,
    params,
    ActionTypes.SEARCH_NEXT_TIMERS
  );
};

export const resetTimerData = (params) => {
  return async (dispatch) => {
    dispatch({ type: ActionTypes.RESET_TIMER_DATA, payload: { data: [] } });
  };
};
