import * as ActionTypes from "../../redux/types/ActionType";
import * as URL from "../../services/API_URL";

import axios from "../../utils/axios";

function postRequest(API_URL, body, Success_Action) {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .post(API_URL, body, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            //To Save the SearchCriterio in REdux store for pagination
            if (URL.APPL_SEARCH === API_URL) {
              dispatch({
                type: Success_Action,
                payload: response.data,
                searchCriteriaVo: body,
              });
            } else {
              dispatch({ type: Success_Action, payload: response.data });
            }
          } else {
            dispatch({ type: Success_Action, payload: { data: [] } });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          dispatch({ type: Success_Action, payload: { data: [] } });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return null;
  };
}

function getRequest(API_URL, Success_Action) {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .get(API_URL, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200 || response.status === "OK") {
            dispatch({ type: Success_Action, payload: response.data });
          } else {
            dispatch({ type: Success_Action, payload: [] });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          dispatch({ type: Success_Action, payload: [] });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return null;
  };
}

export const applSearch = (searchVO) => {
  return postRequest(URL.APPL_SEARCH, searchVO, ActionTypes.APPL_SEARCH);
};

export const applSearchNextPage = (searchVO) => {
  return postRequest(
    URL.APPL_SEARCH_NEXT_PAGE,
    searchVO,
    ActionTypes.APPL_SEARCH_NEXT_PAGE
  );
};

export const searchPcp = (searchVO) => {
  return postRequest(URL.PCP_POPUP, searchVO, ActionTypes.PCP_SEARCH);
};

export const searchAgent = (searchVO) => {
  return postRequest(URL.AGENT_POPUP, searchVO, ActionTypes.AGENCY_SEARCH);
};

export const searchCityZip = (searchVO) => {
  return postRequest(URL.CITY_ZIP_POPUP, searchVO, ActionTypes.CITY_ZIP_SEARCH);
};

export const resetCityZip = (searchVO) => {
  return postRequest(
    URL.CITY_ZIP_POPUP,
    searchVO,
    ActionTypes.RESET_CITY_ZIP_SEARCH
  );
};

export const groupProdSearch = (searchVO) => {
  return postRequest(
    URL.GROUP_PRODUCT_POPUP,
    searchVO,
    ActionTypes.GROUP_SEARCH
  );
};

export const eligCheckSearch = (searchVO, searchResultsVo) => {
  return postRequest(URL.ELIG_SEARCH_URL, searchVO, ActionTypes.ELIG_SEARCH);
};

export const originalApplication = (currentApplVo) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(
          URL.ORIGINAL_APPLICATION,
          { applId: currentApplVo.applVO.applId },
          {
            headers: { "x-auth-token": localStorage.getItem("token") },
          }
        )
        .then((response) => {
          dispatch({
            type: ActionTypes.SAVE_CURR_APPL,
            payload: currentApplVo,
          });
          dispatch({
            type: ActionTypes.ORIGINAL_APPL_SEARCH,
            payload: response.data,
          });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })

        .catch((error) => {
          dispatch({
            type: ActionTypes.SAVE_CURR_APPL,
            payload: currentApplVo,
          });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "done";
  };
};

export const rowClickSearch = (application) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .get(URL.ROW_SEARCH + "/" + application.applId, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          response.data.application = application;
          dispatch({ type: ActionTypes.ROW_CLICK, payload: response.data });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "done";
  };
};

export const fetchCacheData = () => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .get(URL.CACHE_URL, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          for (const key of Object.keys(response.data.data)) {
            if (response.data.data[key]) {
              response.data.data[key].splice(0, 0, {
                value: "",
                label: "Select",
              });
            }
          }
          dispatch({
            type: ActionTypes.FETCH_CACHE_DATA,
            payload: response.data,
          });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "done";
  };
};

export const updateComments = (commentList) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.APPL_UDPATE_COMMENTS, commentList, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.data.status === "OK") {
            dispatch({ type: ActionTypes.UPDATE_COMMENTS_SUCCESS });
          } else {
            dispatch({ type: ActionTypes.UPDATE_COMMENTS_FAILED });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.UPDATE_COMMENTS_FAILED });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          console.log(error);
        });
    }
    return "done";
  };
};

export const getInstitution = (params) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: false,
    });
    if (spin) {
      return axios
        .post(URL.GET_INSTITUTION_DETAILS, params, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            dispatch({
              type: ActionTypes.GET_INSTITUTION_DETAILS,
              payload: response.data,
            });
          } else {
            dispatch({
              type: ActionTypes.GET_INSTITUTION_DETAILS,
              payload: [],
            });
          }
          // dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return "success";
        })

        .catch((error) => {
          error.response &&
            error.response.data &&
            dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return error.response.data.message;
        });
    }
    return "success";
  };
};

//LEP
export const getLepDetails = (searchResultsVo, userId) => {
  let searchVO = {
    applId: searchResultsVo.applVO.applId,
    hic_Nbr: searchResultsVo.applVO.displayHic,
    mbi: searchResultsVo.applVO.mbrHicNbr,
    reqDtCov: searchResultsVo.applPlanVO.reqDtCov,
    applStatus: searchResultsVo.applVO.currStatus,
    operatorId: userId,
  };

  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.GET_LEP_DETAILS, searchVO, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          dispatch({
            type: ActionTypes.SET_LEP_DETAILS,
            payload: response.data.data,
          });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "done";
  };
};
//LEP
export const addUncoveredDetail = (searchResultsVo, addVo) => {
  let vo = {
    primaryId: searchResultsVo.applVO.applId,

    lepEffDateFrmt: searchResultsVo.applPlanVO.reqDtCov,
    ...addVo,
  };

  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.ADD_UNCOV, vo, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          dispatch({
            type: ActionTypes.ADD_UNCOV_DATA,
            payload: response.data.data,
          });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          console.log(error);
        });
    }
    return "done";
  };
};
//LEP
export const deleteUncoveredDetail = (vo, index, list) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.DELETE_UNCOV, vo, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            list.splice(index, 1);

            dispatch({ type: ActionTypes.SET_UNCOV_DATA, payload: list });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "done";
  };
};
//LEP
export const showAllUncoveredDetail = (applId) => {
  const SERVICE_URL = URL.SHOW_ALL_UNCOV + "/" + applId + "/Y";
  return getRequest(SERVICE_URL, ActionTypes.SET_UNCOV_DATA);
};
//LEP
export const showActiveUncovData = (list) => {
  const listActive = list.filter((ob) => ob.overRideInd === "N");
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.SET_UNCOV_DATA,
      payload: listActive,
    });
  };
};

//LEP
export const addAttestationData = (addVo, applId, reqDate) => {
  let attestVo = {
    ...addVo,
    primaryId: applId,
    lepEffDate: reqDate,
  };

  return postRequest(
    URL.ADD_ATTESTATION,
    attestVo,
    ActionTypes.ADD_ATTESTATION_DATA
  );
};

//LEP
export const deleteAttestationData = (list, index, applId) => {
  let vo = {
    primaryId: applId,
    createTime: list[index].createTime,
    createUserId: list[index].createUserId,
    customerId: list[index].customerId,
  };
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.DELETE_ATTESTATION, vo, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            list.splice(index, 1);

            dispatch({
              type: ActionTypes.SET_APPL_LEP_VALUE,
              name: "lepAttestList",
              targetVo: "lepAttestInfoVO",
              value: list,
            });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })
        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          console.log(error);
        });
    }
    return "done";
  };
};
//LEP
export const copyAttestationData = (list, reqDtCov, applId, attList) => {
  let vo = {
    primaryId: applId,
    reqDateCov: reqDtCov,
    lepAttestListReq: list,
  };

  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.COPY_ATTESTATION, vo, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            attList.map((ob) => (ob.overRideInd = "Y"));
            const setList = [
              ...response.data.data.lepAttestListResp,
              ...attList,
            ];
            dispatch({ type: ActionTypes.SET_UNCOV_DATA, payload: setList });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })
        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "done";
  };
};
//LEP
export const showAllAttestationData = (applId) => {
  const SERVICE_URL = URL.SHOW_ALL_ATTESTATION + "/" + applId + "/Y";
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .get(SERVICE_URL, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            dispatch({
              type: ActionTypes.SET_APPL_LEP_VALUE,
              name: "lepAttestList",
              targetVo: "lepAttestInfoVO",
              value: response.data.data,
            });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return null;
  };
};

//LEP
export const showActiveAttestationList = (list) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.SET_APPL_LEP_VALUE,
      name: "lepAttestList",
      targetVo: "lepAttestInfoVO",
      value: list,
    });
  };
};
//LEP
export const setAttestationLetterValue = (name, value, targetVo) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.SET_APPL_LEP_VALUE,
      name: name,
      targetVo: targetVo,
      value: value,
    });
  };
};
//LEP
export const updateAttestationLetter = (vo) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.UPDATE_ATTESTATION_LETTER, vo, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          dispatch({
            type: ActionTypes.UPDATE_ATTESTATION_CALL,
            payload: response.data.data,
          });

          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return response.data;
        })
        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          console.log(error);
        });
    }
    return "done";
  };
};

//LEP
export const updateAttestationCall = (vo, attestCallVo) => {
  let bodyVo = {
    ...attestCallVo,
    outBoundInitial: [
      {
        ...vo.outBoundInitial,
        attempt: attestCallVo.outBoundInitial.length + 1,
      },
    ],
    inBoundInitial: [
      { ...vo.inBoundInitial, attempt: attestCallVo.inBoundInitial.length + 1 },
    ],
    outBoundInComplete: [
      {
        ...vo.outBoundInComplete,
        attempt: attestCallVo.outBoundInComplete.length + 1,
      },
    ],
    inBoundInComplete: [
      {
        ...vo.inBoundInComplete,
        attempt: attestCallVo.inBoundInComplete.length + 1,
      },
    ],
    inBoundLate: [
      { ...vo.inBoundLate, attempt: attestCallVo.inBoundLate.length + 1 },
    ],
  };
  return postRequest(
    URL.UPDATE_ATTESTATION_CALLS,
    bodyVo,
    ActionTypes.SET_ATTESTATION_CALL
  );
};

export const revertApplChanges = (applData) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.REVERT_CHANGES,
      payload: applData,
      application: { applId: applData.applVO.applId },
    });
  };
};

export const setValue = (name, targetVo, value) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.SET_VALUE,
      name: name,
      targetVo: targetVo,
      value: value,
    });
  };
};

export const cancel = () => {
  return async (dispatch) => {
    dispatch({ type: ActionTypes.CANCEL });
  };
};

export const setCurrentApplication = (currApplVo) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.RESTORE_CURR_APPL,
      payload: currApplVo,
    });
  };
};

export const resetAddress = (value) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.RESET_ADDRESS,
      value: value,
    });
  };
};

export const setPcpData = (selectedVo) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.SET_PCP_DATA,
      selectedVo: selectedVo,
    });
  };
};

export const setAgentData = (selectedVo) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.SET_AGENT_DATA,
      selectedVo: selectedVo,
    });
  };
};

export const setPrimaryZip = (selectedVo) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.SET_PRIMARY_ZIP,
      selectedVo: selectedVo,
    });
  };
};

export const setMailingZip = (selectedVo) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.SET_MAILING_ZIP,
      selectedVo: selectedVo,
    });
  };
};

export const setAuthZipState = (selectedVo) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.SET_AUTH_ZIP_STATE,
      selectedVo: selectedVo,
    });
  };
};

export const setAuthZip = (zip5, zip4) => {
  let bodypayload = {
    perZip5: zip5,
    perZip4: zip4,
  };

  return postRequest(
    URL.FETCH_CITY_COUNTY,
    bodypayload,
    ActionTypes.SET_AUTH_ZIP
  );
};
export const setGroupProdData = (selectedVo) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.SET_GRP_PROD_DATA,
      selectedVo: selectedVo,
    });
  };
};

export const setEligData = (selectedVo) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.SET_ELIG_DATA,
      selectedVo: selectedVo,
    });
  };
};

export const resetZipTable = () => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.RESET_ZIP_DATA_TABLE,
    });
  };
};

export const applCancel = (searchVO, userID, params) => {
  let data = searchVO.applCommentsList;
  for (let i = 0; i < data.length; i++) {
    if (data[i].insert === "Y") {
      data[i].insert = "N";
    }
  }

  const { sucessCallBack, failureCallBack } = params;

  let bodyPayload = {
    applCommentsList: data,
    applId: searchVO.applVO.applId,
    // "ltrReasonCd":searchVO.applVO.ltrReasonCd,
    ltrReasonCd: searchVO.applVO.cancelReason,
    // "date": "07/30/2019",
    date: searchVO.applVO.cancelDt,
    planDesg: searchVO.grpProdVO.planDesignation,
    userId: userID,
  };
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.APPL_CANCEL, bodyPayload, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          console.log(response);
          dispatch({ type: ActionTypes.APPL_CANCEL, payload: response.data });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          sucessCallBack && sucessCallBack(response.data);
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          failureCallBack && failureCallBack(error);
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          console.log(error);
        });
    }
    return "done";
  };
};

export const newApplication = (newApplFlag, appFields) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.NEW_MEMBER_APPLICATION,
      payload: newApplFlag,
      appFields: appFields,
    });
  };
};

export const validateError = (message) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.UPDATE_ERROR,
      payload: message,
    });
  };
};

export const setAttestationList = (attestationList) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.SET_ATTESTATION_LIST,
      payload: attestationList,
    });
  };
};

export const addComment = (commentVo) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.ADD_NEW_COMMENT,
      payload: commentVo,
    });
  };
};

export const validateApplication = (searchResultVO, params) => {
  const { sucessCallBack, failureCallBack } = params;
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.APPL_VALIDATE, searchResultVO, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          dispatch({ type: ActionTypes.APPL_VALIDATE, payload: response.data });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          sucessCallBack && sucessCallBack(response.data);
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          failureCallBack && failureCallBack(error);
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          console.log(error);
        });
    }
    return "done";
  };
};

export const applUpdate = (searchResultVO, commentList, params) => {
  const { sucessCallBack, failureCallBack } = params;
  let vo = {
    ...searchResultVO,
    applCommentsList: [...commentList],
  };
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.APPL_UPDATE, vo, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          dispatch({ type: ActionTypes.APPL_UPDATE, payload: response.data });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          sucessCallBack && sucessCallBack(response.data);
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          failureCallBack && failureCallBack(error);
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          console.log(error);
        });
    }
    return "done";
  };
};

export const fetchMemberData = (birthDt, reqDt, searchVO) => {
  searchVO.applVO.message = "";
  searchVO.applVO.mbrBirthDt = birthDt;
  searchVO.applPlanVO.reqDtCov = reqDt;

  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.SUBMIT_FORM, searchVO, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          dispatch({ type: ActionTypes.SUBMIT_FORM, payload: response.data });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return response.data.data.applVO.message;
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          console.log(error);
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return "Eligibility Check Failed";
        });
    }
    return "done";
  };
};

//export const fetchCounty = (zip5) => {
export const fetchCityCounty = (zip5, zip4) => {
  let bodypayload = {
    perZip5: zip5,
    perZip4: zip4,
  };

  return postRequest(
    URL.FETCH_CITY_COUNTY,
    bodypayload,
    ActionTypes.FETCH_COUNTY_ACTION
  );
};
export const fetchMailCityCounty = (zip5, zip4) => {
  let bodypayload = {
    perZip5: zip5,
    perZip4: zip4,
  };

  return postRequest(
    URL.FETCH_CITY_COUNTY,
    bodypayload,
    ActionTypes.FETCH_MAIL_COUNTY_ACTION
  );
};
export const fetchCities = (perZip5, countyVal) => {
  let bodypayload = {
    perZip5: perZip5,
    county: countyVal,
  };

  return postRequest(URL.FETCH_CITIES, bodypayload, ActionTypes.SET_CITIES);
};

export const PresetNotes = (radiostatus, note1, notedesc, selectvalue) => {
  let bodypayload = {
    radioCheck: radiostatus,
    preSetNote: note1,
    preSetNoteDescr: notedesc,
    preSetKey: selectvalue,
  };

  return postRequest(
    URL.GET_PRESETNOTES,
    bodypayload,
    ActionTypes.PRESET_NOTES
  );
};

export const getCommentData = (memberId) => {
  return getRequest(URL.GET_COMMENTS + memberId, ActionTypes.GET_COMMENTS);
};

export const submitComment = (comment, options) => {
  // const { successCallback } = options;
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.POST_COMMENT, comment, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          dispatch({ type: ActionTypes.POST_COMMENT, payload: response.data });
          dispatch({ type: ActionTypes.GET_COMMENTS, payload: response.data });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          console.log(error);
        });
    }
    return "done";
  };
};

export const StatusLogAction = (applId) => {
  return getRequest(URL.STATUS_LOG + applId, ActionTypes.STATUS_LOG);
};
