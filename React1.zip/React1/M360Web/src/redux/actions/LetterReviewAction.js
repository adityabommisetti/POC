import * as ActionTypes from "../../redux/types/ActionType";
import * as URL from "../../services/API_URL";
import React from "react";
import axios from "../../utils/axios";

export const resetLetterDetails = (params) => {
  return async (dispatch) => {
    dispatch({ type: ActionTypes.RESET_LETTER_DETAILS, payload: params });
  };
};

export const SearchNextPage = (params) => {
  return postRequest(
    URL.SEARCH_NEXT_REVIEW,
    params,
    ActionTypes.SEARCH_NEXT_REVIEW
  );
};
export const letterReviewUpdate = (params) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .post(URL.LETTER_REVIEW_DATA_UPDATE, params, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            response.data.selectedIndex = params.selectedIndex;

            let pdfletterReview = {};
            if (response.data.data) {
              pdfletterReview = response.data.data;
              pdfletterReview.selectedIndex = params.selectedIndex;
              if (pdfletterReview.letterAvailabilityInDB === "Y") {
                pdfletterReview.letterAvailabilityInDBGet = React.createElement(
                  "i",
                  {
                    className: "fa fa-file-pdf-o",
                    style: { color: "red" },
                  },
                  ""
                );
              } else {
                pdfletterReview.letterAvailabilityInDB = "";
              }
            }
            dispatch({
              type: ActionTypes.LETTER_REVIEW_DATA_UPDATE,
              payload: pdfletterReview,
            });
          } else {
            dispatch({
              type: ActionTypes.LETTER_REVIEW_DATA_UPDATE,
              payload: [],
            });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })

        .catch((error) => {
          error.response &&
            error.response.data &&
            dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return error.response.data.message;
        });
    }
    return "success";
  };
};

const openPDFDoc = (doc) => {
  const params = {
    primaryId: doc.primaryId,
    letterName: doc.letterName,
    letterUploadedTime: doc.letterUploadedTime,
    pdfArchival: doc.pdfArchival,
  };
  return axios
    .post(URL.DISPLAY_DOC, params, {
      headers: { "x-auth-token": localStorage.getItem("token") },
    })
    .then((response) => {
      var base64str = response.data.data;
      var binary = atob(base64str.replace(/\s/g, ""));
      var len = binary.length;
      var buffer = new ArrayBuffer(len);
      var view = new Uint8Array(buffer);
      for (var i = 0; i < len; i++) {
        view[i] = binary.charCodeAt(i);
      }
      var blob = new Blob([view], { type: "application/pdf" });
      var url = window.URL.createObjectURL(blob);
      if (navigator.msSaveBlob) {
        return navigator.msSaveOrOpenBlob(blob, "download.pdf");
      }else{
      window.open(
        url,
        "popUpWindow",
        "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=900" +
          ", height=900" +
          ", top=10" +
          ", left=10"
      );
    }
    })

    .catch((error) => {
      if (error.response && error.response.status === 500) {
        if (error.response.headers["x-auth-token"]) {
          var token = error.response.headers["x-auth-token"];

          localStorage.setItem("token", "Bearer " + token);
        }
      }
    });
};

export const letterReviewSearch = (params) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.LETTER_REVIEW_SEARCH, params, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (
            response.data.data.lstLetterVO &&
            response.data.data.lstLetterVO.length > 0
          ) {
            response.data.data.lstLetterVO.map((data, ind) => {
              data.recordTypeFrmt =
                data.recordType === "M" ? "Member" : "Application";
              data.letterNameFrmt = data.description.trim()
                ? data.letterName + "-" + data.description
                : data.letterName;

              if (data.letterAvailabilityInDB === "Y") {
                response.data.data.lstLetterVO[
                  ind
                ].letterAvailabilityInDBPdfIcon = React.createElement(
                  "i",
                  {
                    className: "fa fa-file-pdf-o",
                    style: { color: "red" },
                    onClick: (event, chk = ind) => {
                      openPDFDoc(response.data.data.lstLetterVO[chk]);
                      event.stopPropagation();
                    },
                  },
                  ""
                );
                return response;
              } else {
                response.data.data.lstLetterVO[ind].letterAvailabilityInDB = "";
                return response;
              }
            });
          }
          dispatch({
            type: ActionTypes.LETTER_REVIEW_SEARCH,
            payload: response.data,
          });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.data) {
            return error.response.data.message;
          }
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "success";
  };
};

export const letterReviewData = (params) => {
  return postRequest(
    URL.LETTER_REVIEW_DATA,
    params,
    ActionTypes.LETTER_REVIEW_DATA
  );
};

export const letterInitialDropDown = () => {
  return getRequest(URL.INITIAL_LETTER, ActionTypes.INITIAL_LETTER);
};

function postRequest(API_URL, body, Success_Action) {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .post(API_URL, body, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            dispatch({ type: Success_Action, payload: response.data });
          } else {
            dispatch({ type: Success_Action, payload: [] });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return "success";
        })

        .catch((error) => {
          error.response &&
            error.response.data &&
            dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return error.response.data.message;
        });
    }
    return "success";
  };
}

function getRequest(API_URL, Success_Action) {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .get(API_URL, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (response.status === 200) {
            dispatch({ type: Success_Action, payload: response.data });
          } else {
            dispatch({ type: Success_Action, payload: [] });
          }
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.data) {
            return error.response.data.message;
          }
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "success";
  };
}

export const letteUpload = (data) => {
  return postRequest(URL.LETTER_UPLOAD, data, ActionTypes.LETTER_UPLOAD);
};

export const resetCkeckedList = (params) => {
  return async (dispatch) => {
    dispatch({ type: ActionTypes.RESET_CHECK_LIST, payload: [] });
  };
};

export const qcReset = (params) => {
  return async (dispatch) => {
    dispatch({ type: ActionTypes.QC_RESET, payload: [] });
  };
};

export const letterQCSearchBatchId = (data) => {
  return postRequest(
    URL.LETTER_QC_SEARCH_BATCHID,
    data,
    ActionTypes.LETTER_QC_SEARCH_BATCHID
  );
};

export const letterQCSearch = (params) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.LETTER_QC_SEARCH, params, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.data.data && response.data.data.length > 0) {
            response.data.data.map((data, ind) => {
              data.checkbox = React.createElement("input", {
                className: "",
                id: data.letterName.concat(data.primaryId, data.filebatchid),
                name: "acs",
                type: "checkbox",
                onClick: () => {
                  const id = data.letterName.concat(
                    data.primaryId,
                    data.filebatchid
                  );
                  if (document.getElementById(id).checked) {
                    dispatch({
                      type: ActionTypes.LETTER_QC_ADD,
                      payload: data,
                    });
                  } else {
                    dispatch({
                      type: ActionTypes.LETTER_QC_DELETE,
                      payload: data,
                    });
                  }
                },
              });
              if (data.letterAvailabilityInDB === "Y") {
                response.data.data[
                  ind
                ].letterAvailabilityInDBGet = React.createElement(
                  "i",
                  {
                    className: "fa fa-file-pdf-o",
                    style: { color: "red" },
                    onClick: (i, chk = ind) => {
                      openPDFDoc(response.data.data[chk]);
                    },
                  },
                  ""
                );
              } else {
                response.data.data[ind].letterAvailabilityInDB = "";
              }
              return response;
            });
          }
          dispatch({
            type: ActionTypes.LETTER_QC_SEARCH,
            payload: response.data,
          });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })

        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.data) {
            return error.response.data.message;
          }
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "success";
  };
};

export const letterQCDescriptionList = (batchId) => {
  return getRequest(
    URL.LETTER_QC_DESCRIPTION + batchId,
    ActionTypes.LETTER_QC_DESCRIPTION
  );
};
