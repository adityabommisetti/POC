import * as ActionTypes from "../../redux/types/ActionType";
import * as URL from "../../services/API_URL";

import React from "react";
import axios from "../../utils/axios";
import { messages } from "../../constants/Messages";

function postRequest(API_URL, body, Success_Action) {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .post(API_URL, body, {
          headers: {
            "x-auth-token": localStorage.getItem("token"),
          },
        })
        .then((response) => {
          if (response.status === 200) {
            //To Save the SearchCriterio in REdux store for pagination
            if (URL.GET_MEMBER_DETAILS === API_URL) {
              dispatch({
                type: Success_Action,
                payload: response.data,
                searchCriteriaVo: body,
              });
            } else {
              dispatch({ type: Success_Action, payload: response.data });
            }
          } else {
            dispatch({
              type: Success_Action,
              payload: [],
            });
          }

          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return "success";
        })

        .catch((error) => {
          error.response &&
            error.response.data &&
            dispatch({
              type: ActionTypes.SET_SPINNER,
              payload: false,
            });

          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }

          return error.response.data.message;
        });
    }
    return "success";
  };
}

function getRequest(API_URL, Success_Action) {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .get(API_URL, {
          headers: {
            "x-auth-token": localStorage.getItem("token"),
          },
        })
        .then((response) => {
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          if (response.status === 200) {
            dispatch({
              type: Success_Action,
              payload: response.data,
            });
          } else {
            dispatch({
              type: Success_Action,
              payload: {
                data: [],
              },
            });
          }
        })

        .catch((error) => {
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          if (error.response && error.response.data) {
            return error.response.data.message;
          }
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "success";
  };
}

function getShowAllRequest(API_URL) {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .get(API_URL, {
          headers: {
            "x-auth-token": localStorage.getItem("token"),
          },
        })
        .then((response) => {
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });

          return response.data.data;
        })

        .catch((error) => {
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          if (error.response && error.response.data) {
            return error.response.data.message;
          }
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return null;
  };
}

export const resetMemberSearch = (selectedRoowIndex) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.RESET_MEMBER_SEARCH,
      payload: selectedRoowIndex,
    });
  };
};

export const searchAttributes = (data) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.SEARCH_ATTRIBUTES,
      payload: data,
    });
  };
};
export const setSelectedTab = (value) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.SET_SELECTED_TAB,
      value: value,
    });
  };
};

export const MemberSearch = (searchVO) => {
  return postRequest(
    URL.GET_MEMBER_DETAILS,
    searchVO,
    ActionTypes.MEMBER_SEARCH
  );
};

export const memberSearchNextPage = (searchVO) => {
  return postRequest(
    URL.GET_MEMBER_SEARCH_PAGINATION,
    searchVO,
    ActionTypes.MEMBER_SEARCH_PAGINATION
  );
};

export const fetchMemberCacheData = () => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .get(URL.GET_MEMBER_CACHE, {
          headers: {
            "x-auth-token": localStorage.getItem("token"),
          },
        })
        .then((response) => {
          for (const key of Object.keys(response.data.data)) {
            if (
              Array.isArray(response.data.data[key]) &&
              response.data.data[key]
            ) {
              response.data.data[key].splice(0, 0, {
                label: "Select",
                value: "",
              });
            }
          }
          dispatch({
            type: ActionTypes.FETCH_MEMBER_CACHE_DATA,
            payload: response.data,
          });
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
        })

        .catch((error) => {
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "success";
  };
};

export const memberrowClickSearch = (
  id,
  date,
  medicareid,
  showAll,
  member,
  tabIndex
) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(
          URL.GET_MEMBER_ROWCLICK,
          {
            memberId: id,
            medicareId: medicareid,
            selectedTab: tabIndex,
            cmsEffMonth: date,
            showAll: showAll,
          },
          {
            headers: {
              "x-auth-token": localStorage.getItem("token"),
            },
          }
        )

        .then((response) => {
          response.data.member = member;
          if (
            response.data.data.mbrLetterList &&
            response.data.data.mbrLetterList.length > 0
          ) {
            // for (const index in response.data.data) {
            response.data.data.mbrLetterList.map((data, ind) => {
              if (data.letterAvailabilityInDB === "Y") {
                response.data.data.mbrLetterList[
                  ind
                ].letterAvailabilityInDB = React.createElement(
                  "i",
                  {
                    className: "fa fa-file-pdf-o",
                    style: {
                      color: "red",
                      cursor: "pointer",
                    },
                    onClick: (event, chk = ind) => {
                      openPDFDoc(response.data.data.mbrLetterList[chk]);
                      event.stopPropagation();
                    },
                  },
                  ""
                );
                return response;
              } else {
                response.data.data.mbrLetterList[ind].letterAvailabilityInDB =
                  "";
              }
              response.data.data.mbrLetterList[ind].origMailDate =
                response.data.data.mbrLetterList[ind].origMailDateFrmt;
              response.data.data.mbrLetterList[ind].requestDate =
                response.data.data.mbrLetterList[ind].requestDateFrmt;

              return response;
            });
          }
          dispatch({
            type: ActionTypes.MEMBER_ROW_CLICK,
            payload: response.data,
          });
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
        })

        .catch((error) => {
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          if (error.response && error.response.data) {
            return error.response.data.message;
          }
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "success";
  };
};

export const setValueMember = (name, targetVo, value) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.SET_VALUE_MEMBER,
      name: name,
      targetVo: targetVo,
      value: value,
    });
  };
};

export const PCPActiveDetails = (data) => {
  const SERVICE_URL = URL.GET_MEMBER_PCP + "/" + data;
  return getRequest(SERVICE_URL, ActionTypes.PCP_SHOW_ACTIVE);
};

export const PCPDeleteDetails = (data) => {
  return postRequest(URL.MEMBER_PCP_DELETE, data, ActionTypes.PCP_DELETE);
};

export const PCPUpdateDetails = (data) => {
  return postRequest(URL.PCP_UPDATE, data, ActionTypes.PCP_UPDATE);
};

export const MemberPCPSearchData = (searchVo) => {
  return postRequest(
    URL.MEMBERPCP_POPUP_SEARCH,
    searchVo,
    ActionTypes.MEMBERPCP_POPUP_SEARCH
  );
};

// LTC

export const getLtcData = (memberId) => {
  const SERVICE_URL = URL.GET_LTC + "/" + memberId;
  return getRequest(SERVICE_URL, ActionTypes.GET_LTC);
};

export const updateLtc = (body) => {
  //    body['lengthOfStay'] =  parseInt(body.lengthOfStay);
  return postRequest(URL.ADD_UPDATE_LTC, body, ActionTypes.ADD_UPDATE_LTC);
};

export const deleteLTCItem = (body) => {
  return postRequest(URL.DELETE_LTC, body, ActionTypes.DELETE_LTC);
};

export const ltcFacilitySearch = (body) => {
  return postRequest(
    URL.LTC_FACILITY_SEARCH,
    body,
    ActionTypes.LTC_FACILITY_SEARCH
  );
};

// address

export const getAddress = (memberId) => {
  const SERVICE_URL = URL.GET_ADDRESS + "/" + memberId;
  return getRequest(SERVICE_URL, ActionTypes.GET_ADDRESS);
};

export const insertUpdateAddress = (body) => {
  return postRequest(
    URL.NEW_UPDATE_ADDRESS,
    body,
    ActionTypes.NEW_UPDATE_ADDRESS
  );
};

export const deleteAddress = (body) => {
  return postRequest(URL.DELETE_ADDRESS, body, ActionTypes.DELETE_ADDRESS);
};

export const updateDemographic = (body) => {
  return postRequest(
    URL.DEMOGRAPHIC_UPDATE,
    body,
    ActionTypes.DEMOGRAPHIC_UPDATE
  );
};

//DSINFO
export const DSINFODetails = (memberId) => {
  const SERVICE_URL = URL.GET_DSINFO + "/" + memberId;
  return getRequest(SERVICE_URL, ActionTypes.DSINFO_ACTIVE);
};

export const DSINFOUpdate = (body) => {
  return postRequest(URL.ADD_UPDATE_DSINFO, body, ActionTypes.DSINFO_UPDATE);
};

export const DSINFODelete = (body) => {
  return postRequest(URL.DELETE_DSINFO, body, ActionTypes.DSINFO_DELETE);
};

export const attestLetter = (body) => {
  return postRequest(URL.DISPLAY_DOC, body, ActionTypes.ATTEST_LETTER);
};
export const getTRR = (memberId) => {
  const SERVICE_URL = URL.GET_TRR + "/" + memberId;
  return getRequest(SERVICE_URL, ActionTypes.GET_TRR);
};

export const getTRRData = (memberId, logTime) => {
  const SERVICE_URL = URL.GET_TRR_DATA + "/" + memberId + "/" + logTime;
  return getRequest(SERVICE_URL, ActionTypes.GET_TRR_DATA);
};

export const getSoaPdf = (memberId) => {
  const SERVICE_URL = URL.GET_SOA_PDF + "/" + memberId;
  // return getRequest(SERVICE_URL, ActionTypes.GET_SOA_PDF);

  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .get(SERVICE_URL, {
          headers: {
            "x-auth-token": localStorage.getItem("token"),
          },
        })
        .then((response) => {
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });

          if (response.status === 200 || response.status === 500) {
            dispatch({
              type: "GET_SOA_PDF",
              payload: response.data,
            });
          } else {
            dispatch({
              type: "GET_SOA_PDF",
              payload: {
                data: [],
              },
            });
          }
        })

        .catch((error) => {
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          if (error.response && error.response.data) {
            dispatch({
              type: "GET_SOA_PDF",
              payload: error.response.data,
            });
            return error.response.data.message;
          }
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "success";
  };
};

export const openPDFDocSoa = (data) => {
  var base64str = data;
  var binary = atob(base64str.replace(/\s/g, ""));
  var len = binary.length;
  var buffer = new ArrayBuffer(len);
  var view = new Uint8Array(buffer);
  for (var i = 0; i < len; i++) {
    view[i] = binary.charCodeAt(i);
  }
  var blob = new Blob([view], {
    type: "application/pdf",
  });
  var url = window.URL.createObjectURL(blob);
  if (navigator.msSaveBlob) {
    return navigator.msSaveOrOpenBlob(blob, "download.pdf");
  }
  window.open(
    url,
    "popUpWindow",
    "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=900" +
      ", height=900" +
      ", top=10" +
      ", left=10"
  );

  return {
    type: ActionTypes.SET_UPDATEASESDATA,
    payload: data,
  };
};

/////////////
export const mbrEnrollmentDetails = (memberId) => {
  const SERVICE_URL = URL.MEMBER_ENROLL_FETCH + "/" + memberId;
  return getRequest(SERVICE_URL, ActionTypes.MEMBER_ENROLL);
};

export const mbrProductSearch = (searchVo) => {
  return postRequest(
    URL.MEMBER_ENROLL_SEARCH,
    searchVo,
    ActionTypes.MEMBER_ENROLL_SEARCH
  );
};

export const enrollPlanType = (plan) => {
  return postRequest(
    URL.MEMBER_ENROLL_PLAN,
    plan,
    ActionTypes.ENROLL_PLAN_TYPE
  );
};

export const updateEnrollment = (enrollmentVo) => {
  return postRequest(
    URL.MEMBER_ENROLL_UPDATE,
    enrollmentVo,
    ActionTypes.MEMBER_ENROLL
  );
};

export const printIdcard = (body) => {
  return postRequest(URL.PRINT_IDCARD, body, ActionTypes.PRINT_IDCARD);
};

// pos
// export const compareMemberId = params => {
//   return async dispatch => {
//     dispatch({ type: ActionTypes.COMPARE_MEMBER_ID, payload: params });
//   };
// };
export const getAses = (params) => {
  const SERVICE_URL = URL.GET_ASES + "/" + params;
  return getRequest(SERVICE_URL, ActionTypes.GET_ASES);
};

export const insetUpdateAses = (asesVO) => {
  return postRequest(
    URL.INSERT_UPDATE_ASES,
    asesVO,
    ActionTypes.INSERT_UPDATE_ASES
  );
};

export const deleteAses = (asesVO) => {
  return postRequest(URL.DELETE_ASES, asesVO, ActionTypes.DELETE_ASES);
};

export const getPos = (params) => {
  const SERVICE_URL = URL.GET_POS + "/" + params;
  return getRequest(SERVICE_URL, ActionTypes.GET_POS);
};
export const getShowAll = (params) => {
  const SERVICE_URL = URL[params.url] + "/" + params.memberId;
  return getShowAllRequest(SERVICE_URL);
};

export const fetchMailCityCounty = (zip5, zip4) => {
  let bodypayload = {
    perZip5: zip5,
    perZip4: zip4,
  };

  // return postRequest(
  //   URL.FETCH_CITY_COUNTY,
  //   bodypayload,
  //   ActionTypes.FETCH_MAIL_COUNTY_ACTION_M
  // );

  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .post(URL.FETCH_CITY_COUNTY, bodypayload, {
          headers: {
            "x-auth-token": localStorage.getItem("token"),
          },
        })
        .then((response) => {
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          if (response.status === 200) {
            //dispatch({ type: Success_Action, payload: response.data });
            return response.data.data;
          } else {
            return null;
          }
        })

        .catch((error) => {
          error.response &&
            error.response.data &&
            dispatch({
              type: ActionTypes.SET_SPINNER,
              payload: false,
            });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return error.response.data.message;
        });
    }
    return "success";
  };
};

export const filterPos = (params) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.FILTER_POS,
      payload: {
        data: params,
      },
    });
  };
};

export const filterDSINFO = (params) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.FILTER_DSINFO,
      payload: {
        data: params,
      },
    });
  };
};

export const insetUpdatePos = (params) => {
  return postRequest(
    URL.UPDATE_INSERT_POS,
    params,
    ActionTypes.UPDATE_INSERT_POS
  );
};

export const getCommentData = (memberId) => {
  const SERVICE_URL = URL.GET_MEMBER_COMMENTS + "/" + memberId;
  return getRequest(SERVICE_URL, ActionTypes.GET_MEMBER_COMMENTS);
};

export const submitComment = (comment, options) => {
  // const { successCallback } = options;
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.POST_MEMBER_COMMENT, comment, {
          headers: {
            "x-auth-token": localStorage.getItem("token"),
          },
        })
        .then((response) => {
          dispatch({
            type: ActionTypes.POST_MEMBER_COMMENT,
            payload: response.data,
          });
          dispatch({
            type: ActionTypes.GET_MEMBER_COMMENTS,
            payload: response.data,
          });
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          return "success";
        })

        .catch((error) => {
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "success";
  };
};

export const deletePos = (params) => {
  return postRequest(URL.DELETE_POS, params, ActionTypes.DELETE_POS);
};

const openPDFDoc = (doc) => {
  const params = {
    primaryId: doc.primaryId,
    letterName: doc.letterName,
    letterUploadedTime: doc.letterUploadedTime,
    pdfArchival: doc.pdfArchival,
  };

  return axios
    .post(URL.DISPLAY_DOC, params, {
      headers: {
        "x-auth-token": localStorage.getItem("token"),
      },
    })
    .then((response) => {
      var base64str = response.data.data;
      var binary = atob(base64str.replace(/\s/g, ""));
      var len = binary.length;
      var buffer = new ArrayBuffer(len);
      var view = new Uint8Array(buffer);
      for (var i = 0; i < len; i++) {
        view[i] = binary.charCodeAt(i);
      }
      var blob = new Blob([view], {
        type: "application/pdf",
      });
      var url = window.URL.createObjectURL(blob);
      if (navigator.msSaveBlob) {
        return navigator.msSaveOrOpenBlob(blob, "download.pdf");
      }
      window.open(
        url,
        "popUpWindow",
        "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=900" +
          ", height=900" +
          ", top=10" +
          ", left=10"
      );
    })

    .catch((error) => {
      if (error.response && error.response.status === 500) {
        if (error.response.headers["x-auth-token"]) {
          var token = error.response.headers["x-auth-token"];

          localStorage.setItem("token", "Bearer " + token);
        }
      }
    });
};

export const memberData = (memberData) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .get(URL.GET_MBR_LETTERS + "/" + memberData, {
          headers: {
            "x-auth-token": localStorage.getItem("token"),
          },
        })
        .then((response) => {
          // for (const index in response.data.data) {
          response.data.data.lstLetterVO.map((data, ind) => {
            if (data.letterAvailabilityInDB === "Y") {
              response.data.data.lstLetterVO[
                ind
              ].letterAvailabilityInDB = React.createElement(
                "i",
                {
                  className: "fa fa-file-pdf-o",
                  style: {
                    color: "red",
                    cursor: "pointer",
                  },
                  onClick: (event, chk = ind) => {
                    openPDFDoc(response.data.data.lstLetterVO[chk]);
                    event.stopPropagation();
                  },
                },
                ""
              );
            } else {
              response.data.data.lstLetterVO[ind].letterAvailabilityInDB = "";
            }
            response.data.data.lstLetterVO[ind].origMailDate =
              response.data.data.lstLetterVO[ind].origMailDateFrmt;
            response.data.data.lstLetterVO[ind].requestDate =
              response.data.data.lstLetterVO[ind].requestDateFrmt;

            return response;
          });

          // }

          dispatch({
            type: ActionTypes.GET_MBR_LETTERS,
            payload: response.data,
          });
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
        })
        .catch((error) => {
          dispatch({
            type: ActionTypes.GET_MBR_LETTERS,
            payload: [],
          });
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "success";
  };
};

export const memberLetterData = (memberData) => {
  return postRequest(
    URL.LETTER_VARDATA,
    memberData,
    ActionTypes.LETTER_VARDATA
  );
};

export const getCobData = (params) => {
  const SERVICE_URL = URL.MEMBER_COB_FETCH + "/" + params;
  return getRequest(SERVICE_URL, ActionTypes.GET_COB);
};

export const updateCob = (CobVo) => {
  return postRequest(URL.MEMBER_COB_UPDATE, CobVo, ActionTypes.GET_COB);
};

export const deleteCob = (params) => {
  return postRequest(URL.MEMBER_COB_DELETE, params, ActionTypes.GET_COB);
};

export const getBillingData = (params) => {
  const SERVICE_URL = URL.MEMBER_BILLING_FETCH + "/" + params;
  return getRequest(SERVICE_URL, ActionTypes.GET_BILLING);
};

export const updateBillingData = (params) => {
  return postRequest(
    URL.MEMBER_BILLING_UPDATE,
    params,
    ActionTypes.UPDATE_BILLING
  );
};

export const deleteBillingData = (params) => {
  return postRequest(
    URL.MEMBER_BILLING_DELETE,
    params,
    ActionTypes.DELETE_BILLING
  );
};

//OOA
export const getOoaData = (params) => {
  const SERVICE_URL = URL.MEMBER_OOA_FETCH + "/" + params;
  return getRequest(SERVICE_URL, ActionTypes.GET_OOA);
};

export const updateOoa = (ooaVo) => {
  return postRequest(URL.MEMBER_OOA_UPDATE, ooaVo, ActionTypes.UPDATE_OOA);
};

//Agent

export const insetUpdateAgent = (params) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.INSERT_UPDATE_AGENT, params, {
          headers: {
            "x-auth-token": localStorage.getItem("token"),
          },
        })
        .then((response) => {
          dispatch({
            type: ActionTypes.UPDATE_INSERT_AGENT,
            payload: response.data.data.agent,
          });
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          return "success";
        })

        .catch((error) => {
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });

          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }

          return error.response.data.message;
        });
    }
    return "success";
  };
};

export const getAgent = (params) => {
  const SERVICE_URL = URL.GET_AGENT + "/" + params;
  return getRequest(SERVICE_URL, ActionTypes.GET_AGENT);
};

export const deleteAgent = (params) => {
  return postRequest(URL.DELETE_AGENT, params, ActionTypes.DELETE_AGENT);
};

export const getAccretion = (memberId) => {
  const SERVICE_URL = URL.GET_ACCRETION + "/" + memberId;
  return getRequest(SERVICE_URL, ActionTypes.GET_ACCRETION);
};

export const updateAddressDsinfo = (dsinfoVO) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.MEMBER_SEARCH,
      payload: dsinfoVO,
    });
  };
};

export const fetchMbrLep = (memberId, showAll) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .get(URL.FETCH_MBR_LEP_DATA + memberId + "/" + showAll, {
          headers: {
            "x-auth-token": localStorage.getItem("token"),
          },
        })
        .then((response) => {
          dispatch({
            type: ActionTypes.SET_MBR_LEP_DATA,
            payload: response.data.data,
          });
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
        })

        .catch((error) => {
          dispatch({
            type: ActionTypes.SET_MBR_LEP_DATA,
            payload: null,
          });
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "success";
  };
};

export const setMbrLepValue = (name, value, targetVo) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.SET_LEP_VALUE,
      name: name,
      targetVo: targetVo,
      value: value,
    });
  };
};

export const updateMaximus = (updateVo) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.UPDATE_MAXIMUS, updateVo, {
          headers: {
            "x-auth-token": localStorage.getItem("token"),
          },
        })
        .then((response) => {
          dispatch({
            type: ActionTypes.SET_LEP_VO,
            payload: response.data.data,
            targetVo: "eemlepMaximusVO",
          });
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          return messages.UPDATED_SUCCESSFULLY;
        })

        .catch((error) => {
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return messages.UPDATION_FAILED;
        });
    }
    return "success";
  };
};

export const deleteLepData = (list, index) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.DELETE_LEP_DATA, list[index], {
          headers: {
            "x-auth-token": localStorage.getItem("token"),
          },
        })
        .then(async (response) => {
          if (response.data.status === "OK") {
            list.splice(index, 1);
            await dispatch({
              type: ActionTypes.SET_LEP_VO,
              payload: list,
              targetVo: "eemMbrLepInfoVOs",
            });
            dispatch({
              type: ActionTypes.SET_SPINNER,
              payload: false,
            });
            return messages.DELETED_SUCCESSFULLY;
          } else {
            dispatch({
              type: ActionTypes.SET_SPINNER,
              payload: false,
            });
            return messages.DELETION_FAILED;
          }
        })

        .catch((error) => {
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return messages.DELETION_FAILED;
        });
    }
    //return messages.DELETION_FAILED;
  };
};

export const updateLepData = (updateVo) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.UPDATE_LEP_DATA, updateVo, {
          headers: {
            "x-auth-token": localStorage.getItem("token"),
          },
        })
        .then((response) => {
          dispatch({
            type: ActionTypes.SET_LEP_VO,
            payload: response.data.data,
            targetVo: "eemMbrLepInfoVOs",
          });

          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          return messages.UPDATED_SUCCESSFULLY;
        })

        .catch((error) => {
          let msg = error.response.data.message
            ? error.response.data.message.substring(
                error.response.data.message.lastIndexOf(":") + 1
              )
            : messages.UPDATION_FAILED;
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return msg;
        });
    }
    return "success";
  };
};
export const showAllLepData = (memberId) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .get(URL.SHOW_ALL_LEP_DATA + memberId, {
          headers: {
            "x-auth-token": localStorage.getItem("token"),
          },
        })
        .then((response) => {
          dispatch({
            type: ActionTypes.SET_LEP_VO,
            payload: response.data.data,
            targetVo: "eemMbrLepInfoVOs",
          });
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
        })
        .catch((error) => {
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "success";
  };
};

export const showActiveLepData = (list) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.SET_LEP_VO,
      payload: list,
      targetVo: "eemMbrLepInfoVOs",
    });
  };
};

export const copyAttestationData = (list, reqDtCov, memberId, attList) => {
  let vo = {
    primaryId: memberId,
    reqDateCov: reqDtCov,
    lepAttestListReq: list,
  };
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.COPY_MBR_ATTESTATION, vo, {
          headers: {
            "x-auth-token": localStorage.getItem("token"),
          },
        })
        .then((response) => {
          if (response.status === 200) {
            attList.map((ob) => (ob.overRideInd = "Y"));
            const setList = [
              ...response.data.data.lepAttestListResp,
              ...attList,
            ];
            dispatch({
              type: ActionTypes.SET_LEP_VO,
              payload: setList,
              targetVo: "potentialUnCovMthsList",
            });
            dispatch({
              type: ActionTypes.SET_SPINNER,
              payload: false,
            });
            return messages.COPIED_SUCCESSFULLY;
          } else {
            dispatch({
              type: ActionTypes.SET_SPINNER,
              payload: false,
            });
            return messages.COPY_FAILED;
          }
        })
        .catch((error) => {
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return messages.COPY_FAILED;
        });
    }
    return "success";
  };
};

export const showAllMbrAttestationData = (memberId) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .get(URL.SHOW_ALL_MBR_CCF + memberId + "/Y", {
          headers: {
            "x-auth-token": localStorage.getItem("token"),
          },
        })
        .then((response) => {
          dispatch({
            type: ActionTypes.SET_LEP_VALUE,
            name: "lepAttestList",
            targetVo: "lepAttestInfoVO",
            value: response.data.data,
          });

          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
        })
        .catch((error) => {
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "success";
  };
};

export const showActiveMbrAttestationData = (list) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.SET_LEP_VALUE,
      name: "lepAttestList",
      targetVo: "lepAttestInfoVO",
      value: list,
    });
  };
};

export const addAttestationData = (addVo, memberId, ccfList) => {
  let vo = {
    primaryId: memberId,
    ...addVo,
  };

  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.ADD_MBR_ATTESTATION_DATA, vo, {
          headers: {
            "x-auth-token": localStorage.getItem("token"),
          },
        })
        .then((response) => {
          let list = [
            {
              ...response.data.data,
            },
            ...ccfList,
          ];
          dispatch({
            type: ActionTypes.SET_LEP_VALUE,
            name: "lepAttestList",
            targetVo: "lepAttestInfoVO",
            value: list,
          });
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          return messages.INSERTED_SUCCESSFULLY;
        })

        .catch((error) => {
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return messages.INSERTION_FAILED;
        });
    }
    return "success";
  };
};

//LEP
export const deleteAttestationData = (list, index, memberId) => {
  let vo = {
    primaryId: memberId,
    createTime: list[index].createTime,
    createUserId: list[index].createUserId,
    customerId: list[index].customerId,
  };

  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.DELETE_MBR_ATTESTATION_DATA, vo, {
          headers: {
            "x-auth-token": localStorage.getItem("token"),
          },
        })
        .then((response) => {
          if (response.status === 200) {
            list.splice(index, 1);

            dispatch({
              type: ActionTypes.SET_LEP_VALUE,
              name: "lepAttestList",
              targetVo: "lepAttestInfoVO",
              value: list,
            });
            dispatch({
              type: ActionTypes.SET_SPINNER,
              payload: false,
            });
            return messages.INSERTED_SUCCESSFULLY;
          } else {
            dispatch({
              type: ActionTypes.SET_SPINNER,
              payload: false,
            });
            return messages.INSERTION_FAILED;
          }
        })
        .catch((error) => {
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return messages.INSERTION_FAILED;
        });
    }
    return "success";
  };
};

export const addUncoveredDetail = (memberId, effDate, addVo, list) => {
  let vo = {
    primaryId: memberId,
    lepEffDateFrmt: effDate,
    ...addVo,
  };

  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.ADD_MBR_UNCOV_DATA, vo, {
          headers: {
            "x-auth-token": localStorage.getItem("token"),
          },
        })
        .then((response) => {
          let setList = [
            {
              ...response.data.data,
            },
            ...list,
          ];
          dispatch({
            type: ActionTypes.SET_LEP_VO,
            payload: setList,
            targetVo: "potentialUnCovMthsList",
          });
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          return messages.INSERTED_SUCCESSFULLY;
        })

        .catch((error) => {
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return messages.INSERTION_FAILED;
        });
    }
    return "success";
  };
};
//LEP
export const deleteUncoveredDetail = (vo, index, list) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.DELETE_MBR_UNCOV_DATA, vo, {
          headers: {
            "x-auth-token": localStorage.getItem("token"),
          },
        })
        .then((response) => {
          if (response.status === 200) {
            list.splice(index, 1);

            dispatch({
              type: ActionTypes.SET_LEP_VO,
              payload: list,
              targetVo: "potentialUnCovMthsList",
            });
            dispatch({
              type: ActionTypes.SET_SPINNER,
              payload: false,
            });
            return messages.DELETED_SUCCESSFULLY;
          } else {
            dispatch({
              type: ActionTypes.SET_SPINNER,
              payload: false,
            });
            return messages.DELETION_FAILED;
          }
        })

        .catch((error) => {
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return messages.DELETION_FAILED;
        });
    }
    return "success";
  };
};
//LEP
export const showAllUncoveredDetail = (memberId) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .get(URL.SHOW_ALL_MBR_UNCOV_DATA + memberId + "/Y", {
          headers: {
            "x-auth-token": localStorage.getItem("token"),
          },
        })
        .then((response) => {
          dispatch({
            type: ActionTypes.SET_LEP_VO,
            payload: response.data.data,
            targetVo: "potentialUnCovMthsList",
          });

          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
        })

        .catch((error) => {
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "success";
  };
};
//LEP
export const showActiveUncovData = (list) => {
  const listActive = list.filter((ob) => ob.overRideInd === "N");
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.SET_LEP_VO,
      payload: listActive,
      targetVo: "potentialUnCovMthsList",
    });
  };
};

export const updateAttestationCall = (vo, attestCallVo) => {
  let reqVo = {
    ...attestCallVo,
    outBoundInitial: [
      {
        ...vo.outBoundInitial,
        attempt: attestCallVo.outBoundInitial.length + 1,
      },
    ],
    inBoundInitial: [
      {
        ...vo.inBoundInitial,
        attempt: attestCallVo.inBoundInitial.length + 1,
      },
    ],
    outBoundInComplete: [
      {
        ...vo.outBoundInComplete,
        attempt: attestCallVo.outBoundInComplete.length + 1,
      },
    ],
    inBoundInComplete: [
      {
        ...vo.inBoundInComplete,
        attempt: attestCallVo.inBoundInComplete.length + 1,
      },
    ],
    inBoundLate: [
      {
        ...vo.inBoundLate,
        attempt: attestCallVo.inBoundLate.length + 1,
      },
    ],
  };
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.UPDATE_MBR_ATTEST_CALL, reqVo, {
          headers: {
            "x-auth-token": localStorage.getItem("token"),
          },
        })
        .then((response) => {
          dispatch({
            type: ActionTypes.SET_MBR_ATTESTATION_CALL,
            payload: response.data.data,
          });

          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          return messages.UPDATED_SUCCESSFULLY;
        })
        .catch((error) => {
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return messages.UPDATION_FAILED;
        });
    }
    return "success";
  };
};

export const updateAttestationLetter = (vo) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.UPDATE_MBR_ATTEST_LETTER, vo, {
          headers: {
            "x-auth-token": localStorage.getItem("token"),
          },
        })
        .then((response) => {
          dispatch({
            type: ActionTypes.UPDATE_MBR_ATTESTATION_CALL,
            payload: response.data.data,
          });

          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          return response.data;
        })
        .catch((error) => {
          dispatch({
            type: ActionTypes.SET_SPINNER,
            payload: false,
          });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return messages.UPDATION_FAILED;
        });
    }
    return "success";
  };
};

export const LISDetails = (data) => {
  const SERVICE_URL = URL.MEMBER_LIS_FETCH + "/" + data;
  return getRequest(SERVICE_URL, ActionTypes.LIS_ACTIVE);
};

export const LISUpdate = (data) => {
  return postRequest(URL.MEMBER_LIS_UPDATE, data, ActionTypes.LIS_ACTIVE);
};

export const LISDelete = (data) => {
  return postRequest(URL.MEMBER_LIS_DELETE, data, ActionTypes.LIS_ACTIVE);
};
export const updateShowAllIndi = (flag) => {
  return {
    type: ActionTypes.SET_SHOWALLINDI,
    payload: flag,
  };
};

export const updateIndData = (data) => {
  return {
    type: ActionTypes.SET_UPDATEDTA,
    payload: data,
  };
};
export const updateIndEnrollData = (data) => {
  return {
    type: ActionTypes.SET_UPDATEENROLLDATA,
    payload: data,
  };
};
export const updateIndAddressData = (data) => {
  return {
    type: ActionTypes.SET_UPDATEADDRESSDATA,
    payload: data,
  };
};

export const updateIndOOAData = (data) => {
  return {
    type: ActionTypes.SET_UPDATEOOADATA,
    payload: data,
  };
};

export const updateIndlisData = (data) => {
  return {
    type: ActionTypes.SET_UPDATELISDATA,
    payload: data,
  };
};
export const updateIndpcpData = (data) => {
  return {
    type: ActionTypes.SET_UPDATEPCPDATA,
    payload: data,
  };
};
export const updateIndltcData = (data) => {
  return {
    type: ActionTypes.SET_UPDATELTCDATA,
    payload: data,
  };
};
export const updateIndagentData = (data) => {
  return {
    type: ActionTypes.SET_UPDATEAGENTDATA,
    payload: data,
  };
};
export const updateIndcobData = (data) => {
  return {
    type: ActionTypes.SET_UPDATECOBDATA,
    payload: data,
  };
};
export const updateIndposData = (data) => {
  return {
    type: ActionTypes.SET_UPDATEPOSDATA,
    payload: data,
  };
};
export const updateIndbillingData = (data) => {
  return {
    type: ActionTypes.SET_UPDATEBILINGDATA,
    payload: data,
  };
};

export const updateIndAsesData = (data) => {
  return {
    type: ActionTypes.SET_UPDATEASESDATA,
    payload: data,
  };
};

export const resetClearsearch = () => {
  return {
    type: ActionTypes.RESET_SERACH,
  };
};
