import * as ActionTypes from "../../redux/types/ActionType";
import * as URL from "../../services/API_URL";

import axios from "../../utils/axios";

export const getNotificationData = () => {
  return async (dispatch) => {
    return axios
      .get(URL.NOTIFICATION_API, {
        headers: { "x-auth-token": localStorage.getItem("token") },
      })
      .then((response) => {
        if (response.status === 200) {
          dispatch({
            type: ActionTypes.GET_NOTIFICATION_DATA,
            payload: response.data,
          });
        } else {
          dispatch({
            type: ActionTypes.GET_NOTIFICATION_DATA,
            payload: response.data,
          });
        }
        return "success";
      })
      .catch((error) => {
        dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        if (error.response && error.response.status === 500) {
          if (error.response.headers["x-auth-token"]) {
            var token = error.response.headers["x-auth-token"];

            localStorage.setItem("token", "Bearer " + token);
          }
        }
        if (error.response && error.response.data) {
          return error.response.data.message;
        }
      });
  };
};
