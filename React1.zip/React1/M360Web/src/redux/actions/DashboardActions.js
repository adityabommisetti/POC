import * as ActionTypes from "../../redux/types/ActionType";
import * as URL from "../../services/API_URL";
import axios from "../../utils/axios";

function getPlanCache(API_URL, Success_Action) {
  return async (dispatch) => {
    return axios
      .get(API_URL, {
        headers: { "x-auth-token": localStorage.getItem("token") },
      })
      .then((response) => {
        dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        if (response.status === 200) {
          dispatch({ type: Success_Action, payload: response.data });
          return response.data.message;
        } else {
          dispatch({ type: Success_Action, payload: [] });
        }
      })

      .catch((error) => {
        dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        if (error.response && error.response.data) {
          return error.response.data.message;
        }
        if (error.response && error.response.status === 500) {
          if (error.response.headers["x-auth-token"]) {
            var token = error.response.headers["x-auth-token"];

            localStorage.setItem("token", "Bearer " + token);
          }
        }
      });
  };
}
function getRequest(API_URL, Success_Action) {
  return async (dispatch) => {
    const spin = dispatch({
      type: Success_Action,
      spin: true,
    });

    if (spin) {
      return axios
        .get(API_URL, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          dispatch({ type: Success_Action, spin: false });
          if (response.status === 200) {
            dispatch({ type: Success_Action, payload: response.data });
            return response.data.message;
          } else {
            dispatch({ type: Success_Action, payload: [] });
          }
        })

        .catch((error) => {
          dispatch({ type: Success_Action, spin: false });
          if (error.response && error.response.data) {
            return error.response.data.message;
          }
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
        });
    }
    return "success";
  };
}

export const postRequest = (API_URL, body, Success_Action) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: Success_Action,
      spin: true,
    });

    if (spin) {
      return axios
        .post(API_URL, body, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            dispatch({ type: Success_Action, payload: response.data });
          } else {
            dispatch({ type: Success_Action, payload: [] });
          }
          dispatch({ type: Success_Action, spin: false });
          return response.data;
        })

        .catch((error) => {
          error.response &&
            error.response.data &&
            dispatch({ type: Success_Action, spin: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }

          return error.response;
        });
    }
    return "success";
  };
};
export const preEnrollmentStatus = (data) => {
  return postRequest(
    URL.PRE_ENROLLMENT_STATUS,
    data,
    ActionTypes.PRE_ENROLLMENT_STATUS
  );
};

export const applicationAging = () => {
  return getRequest(URL.APPLICATION_AGING, ActionTypes.APPLICATION_AGING);
};

export const rfiTracking = () => {
  return getRequest(URL.RFI_TRACKING, ActionTypes.RFI_TRACKING);
};

export const memberShipDistribution = (body) => {
  return postRequest(
    URL.MEMBERSHIP_DISTRIBUTION,
    body,
    ActionTypes.MEMBERSHIP_DISTRIBUTION
  );
};

export const cmsStatus = () => {
  return getRequest(URL.CMS_STATUS, ActionTypes.CMS_STATUS);
};

export const pendingTransactionsToCMS = () => {
  return getRequest(
    URL.CMS_TRANSACTION_STATUS,
    ActionTypes.CMS_TRANSACTION_STATUS
  );
};

export const applDistribution = (data) => {
  return postRequest(
    URL.APPLICATION_DISTRIBUTION,
    data,
    ActionTypes.APPLICATION_DISTRIBUTION
  );
};

export const specialDistribution = () => {
  return getRequest(URL.Special_Status, ActionTypes.Special_Status);
};

export const letterDistribution = () => {
  return getRequest(URL.LETTER_DISTRIBUTION, ActionTypes.LETTER_DISTRIBUTION);
};

export const fileDistribution = (data) => {
  return postRequest(
    URL.FILE_LOAD_DISTRIBUTION,
    data,
    ActionTypes.FILE_LOAD_DISTRIBUTION
  );
};

export const getcustomerPlanIds = () => {
  return getPlanCache(URL.GET_PLANIDs, ActionTypes.GET_PLANIDs);
};

export const lisDistribution = (data) => {
  return postRequest(URL.LIS_DISTRIBUTION, data, ActionTypes.LIS_DISTRIBUTION);
};

export const storeChartDataset = (value) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.SET_CHART_DATASET,
      payload: value,
    });
  };
};
export const setSearchCritirea = (value) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.SET_DASHLET_SEARCHVO,
      payload: value,
    });
  };
};

export const dashboardSearchFlag = (payload) => {
  return async (dispatch) => {
    dispatch({
      type: ActionTypes.DASHBOARD_SEARCH,
      payload: payload,
    });
  };
};
