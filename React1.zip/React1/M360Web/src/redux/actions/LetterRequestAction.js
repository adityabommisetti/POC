import * as ActionTypes from "../../redux/types/ActionType";
import * as URL from "../../services/API_URL";

import axios from "../../utils/axios";

export const clearSelectLetter = (params) => {
  return async (dispatch) => {
    dispatch({ type: ActionTypes.SELECT_LETTER, payload: { data: {} } });
  };
};

export const resetLetterReqListData = (params) => {
  return async (dispatch) => {
    dispatch({ type: ActionTypes.RESET_DATA, payload: { data: [] } });
  };
};

export const createLetter = (params) => {
  return postRequest(URL.CREATE_LETTER, params, ActionTypes.CREATE_LETTER);
};
export const getLetterReq = (data) => {
  return postRequest(
    URL.GET_LETTER_REQUEST,
    data,
    ActionTypes.GET_LETTER_REQUEST
  );
};
export const postLookUp = (params) => {
  return postRequest(URL.POST_LOOKUP, params, ActionTypes.POST_LOOKUP);
};
export const closeLetter = (params) => {
  return postRequest(URL.CLOSE_LETTER, params, ActionTypes.CLOSE_LETTER);
};
export const SearchNextPage = (params) => {
  return postRequest(URL.SEARCH_NEXT, params, ActionTypes.SEARCH_NEXT);
};

export const selectLetter = (params) => {
  return postRequest(URL.SELECT_LETTER, params, ActionTypes.SELECT_LETTER);
};

function postRequest(API_URL, body, Success_Action) {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });

    if (spin) {
      return axios
        .post(API_URL, body, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            dispatch({ type: Success_Action, payload: response.data });
          } else {
            dispatch({ type: Success_Action, payload: [] });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return "success";
        })

        .catch((error) => {
          error.response &&
            error.response.data &&
            dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          if (error.response && error.response.status === 500) {
            if (error.response.headers["x-auth-token"]) {
              var token = error.response.headers["x-auth-token"];

              localStorage.setItem("token", "Bearer " + token);
            }
          }
          return error.response.data.message;
        });
    }
    return "success";
  };
}
