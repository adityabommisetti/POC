import * as DateUtil from "../../utils/DatePicker";
import {
  LETTER_REQUESTSOURCE,
  LETTER_REQUEST_SOURCE,
  LETTER_REQUEST_STATUS,
} from "../../constants/SelectStaticData";
import React, { Component } from "react";
import AutoComplete1 from "../UI/Select";
import {
  clearSelectLetter,
  createLetter,
  getLetterReq,
  postLookUp,
  closeLetter,
  selectLetter,
  resetLetterReqListData,
  SearchNextPage,
} from "../../redux/actions/LetterRequestAction";
import {
  resetMemberSearch,
  searchAttributes,
} from "../../redux/actions/MemberActions";
import { messages } from "../../constants/Messages";
import Button from "@material-ui/core/Button";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import Checkbox from "@material-ui/core/Checkbox";
import DataTable from "../Home/DataTable";
import ExpansionPanel from "../UI/ExpansionPanel";
import FormLabel from "@material-ui/core/FormLabel";
import HistoryData from "../UI/MemberHistory";
import InputField from "../UI/InputField";
import TextField from "@material-ui/core/TextField";
import Modal from "../../components/UI/Modal/Modal";
import Paper from "@material-ui/core/Paper";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../assets/styles/Theme";
import { connect } from "react-redux";
import { handleDateChange } from "../../utils/DateFormatter";
import { LETTER_REQUEST_TABLE_HEADER as header } from "../../constants/Headers/LetterHeaders";
import { withStyles } from "@material-ui/core/styles";
import isEmpty from "lodash/isEmpty";
import { customValidations } from "../../utils/CustomValidations";

let LETTER_REQUEST_NAME = [{ value: "", label: "Select" }];
let dateChk = {};
const INITIAL_STATE = {
  searchType: "",
  searchCreateDate: "",
  searchStatus: "",
  source: "",
  appIdorWiproId: "",
  effDateFrmt: "",
  createDate: "",
  description: "",
  status: "",
  firstName: "",
  lastName: "",
  designation: "",
  pbp: "",
  plan: "",
  type: "",
  createUserId: "",
  createTime: "",
  lastUpdtUserId: "",
  lastUpdtTime: "",
  customerId: "",
  letterName: "",
  letterNameDesc: "",
  lstLetterName: null,
  lstVarData: null,
  mbrFName: "",
  mbrLName: "",
  pbpId: "",
  planDesignation: "",
  planId: "",
  primaryId: "",
  sourceType: "",
  sourceTypeDesc: "",
  triggerCode: "",
  triggerCodeDesc: "",
  triggerStatus: "",
  triggerStatusDesc: "",
  triggerType: "",
  triggerTypeDesc: "",
  varDataDesc: null,
  varDataId: null,
  varDataLen: null,
  varDataText: null,
  varDataType: null,
};

class LetterRequest extends Component {
  constructor(props) {
    super(props);
    this.validator = new SimpleReactValidator({
      validators: {
        integerType: customValidations.integerType1,
      },
    });
    this.validator1 = new SimpleReactValidator();
    this.validatorDynamic = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
      },
    });
  }

  state = {
    toggleDatatable: false || this.props.letterReqListData.length > 0,
    letterVo: {
      ...INITIAL_STATE,
    },
    data: null,
    modified: false,
    isNewSegment: false,
    showAllActive: true,
    editable: false,
    edit: false,
    showButton: false,
    displaydata: false,
    selectedIndex: 0,
    values: [],
    closePopup: false,
    message: "",
    fieldsArray: [],
    toggleCreate: false,
    disabledVarField: false,
    rowsPerPage: 10,
    mbridLit: [],
  };

  memberSearchNextPage = async (pageNo) => {
    const { letterReqListData } = this.props;
    const lastRow = letterReqListData[letterReqListData.length - 1];
    let payload = {
      searchType: lastRow.sourceType,
      searchId: this.state.searchId,
      searchCreateDate: this.state.searchCreateDate,
      searchStatus: this.state.searchStatus,
      lastRowPrimaryId: lastRow.primaryId,
      lastRowTriggerType: lastRow.triggerType,
      lastRowEffDate: lastRow.effDate,
      lastRowCreateTime: lastRow.createTime,
    };
    if (this.props.nextPage) {
      await this.props.SearchNextPage(payload);
      this.setState({ selectedIndex: pageNo * this.state.rowsPerPage });
    }
  };

  selectRow = (index) => {
    this.props.clearSelectLetter();
    const data = [...this.props.letterReqListData];
    const selectedVo = data[index];
    LETTER_REQUEST_NAME = [
      { value: selectedVo.letterNameDesc, label: selectedVo.letterNameDesc },
    ];
    this.setState(() => ({
      toggleCreate: false,
      fieldsArray: [],
      values: [],
      selectedIndex: index,
      letterVo: { ...selectedVo },
      letterOldVo: { ...selectedVo },
      editable: false,
      edit: false,
      isNewSegment: false,
      modified: false,
      showButton: false,
    }));
  };

  handlechangeDynamic = (name) => (event) => {
    let value = event.target.value;
    this.setState((prevState) => ({
      [name]: value,
    }));
  };

  handleOnBlur = (event) => {
    const name = event.target.name;
    const value = event.target.value.trim();

    this.setState((prevState) => ({
      letterVo: {
        ...prevState.letterVo,
        [name]: value,
      },
      searchId: name === "searchId" ? value : prevState.searchId,
    }));
  };

  handlechange = (event) => {
    let value = event.target.value.toUpperCase();
    let name = event.target.name;
    if (name === "searchId") {
      if (this.state.letterVo.sourceType === "A") {
        value = value.replace(/[^0-9]/g, "").trim();
        this.setState({ searchId: value }, () => {
          this.attributRestore();
        });
      } else {
        this.setState({ searchId: value.toUpperCase() }, () => {
          this.attributRestore();
        });
      }
    } else {
      this.setState(
        (prevState) => ({
          letterVo: {
            ...prevState.letterVo,
            [name]: value,
          },
          modified: true,
        }),
        () => {
          this.attributRestore();
        }
      );
    }
  };

  handleChangeSearchSelect = (name) => (event) => {
    if (name === "searchStatus") {
      this.setState({ searchStatus: event.value }, () => {
        this.attributRestore();
      });
    } else {
      let value = event.value;
      this.setState(
        (prevState) => ({
          letterVo: {
            ...prevState.letterVo,
            [name]: value,
          },
          modified: true,
        }),
        () => {
          this.attributRestore();
        }
      );
    }
  };

  modalClosed = () => {
    this.setState({ closePopup: false });
  };

  componentDidMount() {
    if (this.props.searchAttribute) {
      INITIAL_STATE.searchId = this.props.searchAttribute.searchId;
      INITIAL_STATE.searchCreateDate = this.props.searchAttribute.searchCreateDate;
      INITIAL_STATE.searchStatus = this.props.searchAttribute.searchStatus;
       INITIAL_STATE.sourceType = this.props.searchAttribute.searchType;
      // letterVo.sourceType
      this.setState(() => ({        
        letterVo: {
          ...INITIAL_STATE,sourceType:this.props.searchAttribute.searchType
        },
      }));
      console.clear(); 
      console.log(this.props.searchAttribute)
      this.setState({
        searchStatus: this.props.searchAttribute.searchStatus,
        searchCreateDate: this.props.searchAttribute.searchCreateDate,
        searchId: this.props.searchAttribute.searchId,
      });
    }

    if (!isEmpty(this.props.letterReqListData)) {
      const selectedVo = this.props.letterReqListData[0];
      LETTER_REQUEST_NAME = [
        { value: selectedVo.letterNameDesc, label: selectedVo.letterNameDesc },
      ];
      this.setState(() => ({
        letterVo: { ...selectedVo, sourceType:this.props.searchAttribute.searchType },
      }));
    }
    const { loginProfile } = this.props;
    const MBRIDLIT = loginProfile.filter((data) => data.label === "MBRIDLIT");
    this.setState({
      mbridLit: MBRIDLIT[0],
    });
  }
  componentDidUpdate() {
    let { letterVo } = this.state;
    if (
      !isEmpty(letterVo.lstLetterName) &&
      letterVo.lstLetterName[0].value !== ""
    ) {
      this.setState((prevState) => ({
        lstLetterName: [
          {
            value: "",
            label: "Select",
          },
          ...prevState.letterVo.lstLetterName,
        ],
      }));

      letterVo.lstLetterName.splice(0, 0, {
        value: "",
        label: "Select",
      });
    }
  }

  handleChangePage = (index) => {
    this.selectRow(index);
  };

  attributRestore = () => {
    const params = {
      searchType: this.state.letterVo.sourceType,
      searchId: this.state.searchId,
      searchStatus: this.state.searchStatus,
      searchCreateDate: this.state.searchCreateDate,
    };
    this.props.searchAttributes({ letterRequest: params });
  };

  LetterSearch = async (event) => {
    this.validator1.hideMessages();
    event.preventDefault();
    this.attributRestore();
    const searchId = this.state.searchId;
    const sourceType = this.state.letterVo.sourceType;
    if (sourceType === "A" && !/^\d+$/.test(searchId) && !isEmpty(searchId)) {
      this.props.resetLetterReqListData();
      this.setState({
        letterVo: {
          ...INITIAL_STATE,
          sourceType: "A",
        },
      });
      return;
    }

    this.setState({
      showButton: false,
      edit: false,
      editable: false,
    });
    const params = {
      searchType: this.state.letterVo.sourceType,
      searchId: this.state.searchId,
      searchStatus: this.state.searchStatus,
      searchCreateDate: this.state.searchCreateDate,
    };
    
    if (this.validator.allValid()) {
      this.setState({ toggleDatatable: true });
      const status = await this.props.getLetterReq(params);
      const searchCreateDate = this.state.searchCreateDate;
      
      LETTER_REQUEST_NAME =
        this.props.letterReqListData.length > 0
          ? [
            {
              value: this.props.letterReqListData[0].letterNameDesc,
              label: this.props.letterReqListData[0].letterNameDesc,
            },
          ]
          : [{ value: "", label: "" }];

      if (this.props.letterReqListData.length > 0 && status === "success") {
        this.setState({
          letterVo: {
            ...this.props.letterReqListData[0],
            searchCreateDate: searchCreateDate,
            letterName: this.props.letterReqListData[0].letterName,
          },
          displaydata: true,
          toggleCreate: false,
          selectedIndex: 0,
        });
      } else {
        this.setState({
          letterVo: {
            ...INITIAL_STATE,
            sourceType:this.state.letterVo.sourceType
          },
          displaydata: true,
          toggleCreate: false,
        });
      }
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  clearFields = () => {
    this.validator1.hideMessages();
    if (this.state.letterVo.sourceType) {
      INITIAL_STATE.sourceType = this.state.letterVo.sourceType;
    }

    this.setState({
      editable: false,
      edit: true,
      isNewSegment: true,
      showButton: true,
      letterVo: {
        ...INITIAL_STATE,
      },
    });
    LETTER_REQUEST_NAME = [{ value: "", label: "Select" }];
  };

  reset = () => {
    this.validator.hideMessages();

    LETTER_REQUEST_NAME = [{ value: "", label: "Select" }]
    
    this.setState((prevState) => ({
      letterVo: {...prevState.letterVo, lstLetterName:[]},
        letterVoetterVo:{...prevState.letterVoetterVo, lstLetterName:[]}
      
    }));
    this.setState(() => ({
      toggleDatatable: false,
      toggleCreate: false,
      showButton: false,
      edit: false,
      editable: false,
      letterVo: {
        source: "",
      },
      searchCreateDate: "",
      searchId: "",
      searchStatus: "",
    }));
    this.props.resetLetterReqListData();
    this.props.clearSelectLetter();
      const params = {
            searchType: "",
            searchId: "",
            searchStatus: "",
            searchCreateDate: "",
          };
          this.props.searchAttributes({ letterRequest: params });
    this.setState({ displaydata: false });
  };

  handleChangeRowsPerPage = (rowsPerPage) => {
    this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  createLetter = async () => {
    this.state.letterVo.customerId = this.props.loginData.loginVo.customerId;
    let vo = { ...this.state.letterVo };
    if (document.getElementById("NoDataEntry")) {
      document.getElementById("NoDataEntry").style.display = "none";
    }
    const keys = Object.keys(this.state.values);
    const lstVarDataUpdated = vo.lstVarData.map((data, i) => {
      keys.map((d) => {
        if (d === data.varId) {
          data.fieldValue = this.state.values[data.varId]
            ? this.state.values[data.varId]
            : "";
          return data;
        }
        return null;
      });
      return data;
    });

    this.setState((prevState) => ({
      edit: false,
      showButton: false,
      toggleCreate: false,
    }));
    let params = {
      ...this.state.letterVo,
      lstVarData: lstVarDataUpdated,
      sourceType:
        this.state.letterVo.sourceTypeDesc === "Application" ? "A" : "M",
    };
    delete params.lstLetterName;

    if (this.validatorDynamic.allValid()) {
      let status = await this.props.createLetter(params);
      if ("success" === status) {
        status = messages.UPDATED_SUCCESSFULLY;
      }

      const trigger = {
        triggerStatusDesc: this.props.letterCreated.triggerStatusDesc,
        triggerTypeDesc: this.props.letterCreated.triggerTypeDesc,
      };
      this.setState((prevState) => ({
        closePopup: true,
        disabledVarField: true,
        message: status,
        letterVo: { ...prevState.letterVo, ...trigger },
      }));
    } else {
      this.validatorDynamic.showMessages();
      this.forceUpdate();
      this.setState({ toggleCreate: true });
    }
  };
  callLookUp = async () => {

    const sourceType = this.state.letterVo.sourceType;
    const params = {
      searchType:
        this.state.letterVo.sourceTypeDesc === "Application" ? "A" : "M",
      searchId: this.state.letterVo.primaryId,
    };

    this.setState({ toggleCreate: false })
    if (this.validator1.allValid()) {
      this.props.clearSelectLetter();

      const status = await this.props.postLookUp(params);

      if (status === "success") {
        let data = this.props.lookUpData;
        this.setState((prevState) => ({
          letterVo: {
            ...prevState.letterVo,
            ...data,
            sourceType: sourceType,
          },
        }));
      } else {
        this.setState({
          closePopup: true,
          message: status,
        });
      }
    } else {
      this.validator1.showMessages();
      this.forceUpdate();
    }
    if (document.getElementById("NoDataEntry")) {
      document.getElementById("NoDataEntry").style.display = "none";
    }
    LETTER_REQUEST_NAME = [{ value: "", label: "Select" }];
  };

  selectLetter = async () => {
    if (document.getElementById("NoDataEntry")) {
      document.getElementById("NoDataEntry").style.display = "block";
    }
    this.validatorDynamic.hideMessages();
    this.setState({ fieldsArray: [], toggleCreate: true });
    const params = {
      searchType:
        this.state.letterVo.sourceTypeDesc === "Application" ? "A" : "M",
      searchId: this.state.letterVo.primaryId,
      letterName: this.state.letterVo.description,
    };
    const status = await this.props.selectLetter(params);

    if (status === "success") {
      this.setState((prevState) => ({
        disabledVarField: false,
        values: [],
        letterVo: {
          ...prevState.letterVo,
          letterName: this.props.selectedLetter.letterName,
          lstVarData: this.props.selectedLetter.lstVarData,
        },
      }));
    }
  };
  handleChangelstVarData(i, e) {
    this.setState({
      values: { ...this.state.values, [e.target.name]: e.target.value },
    });
  }
  handleDate = (event) => {
    let value = event.target.value;
    let name = event.target.name;

    if (name === "searchCreateDate") {
      this.setState((prevState) => ({
        [name]: handleDateChange(value),
        modified: true,
      }));
    } else if (name === "effDateFrmt") {
      this.setState((prevState) => ({
        ...prevState,
        letterVo: { ...prevState.letterVo, [name]: handleDateChange(value) },
        modified: true,
      }));
    } else {
      this.setState({
        values: { ...this.state.values, [name]: value },
      });
    }
  };

  handleDates = (event) => {
    let fieldId = "#" + event.target.name;
    var self = this;

    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        if (
          dateChk.name !== e.target.name ||
          dateChk.value !== e.target.value
        ) {
          self.setDate(e.target.name, e.target.value);
          document.getElementById(fieldId.substr(1)).focus();
        }
        dateChk.name = e.target.name;
        dateChk.value = e.target.value;
      });
  };
  setDate = (name, value) => {
    if (name === "searchCreateDate") {
      this.setState((prevState) => ({
        letterVo: {
          ...prevState.letterVo,
          [name]: handleDateChange(value),
        },
        [name]: handleDateChange(value),
        modified: true,
      }));
    } else {
      this.setState((prevState) => ({
        letterVo: {
          ...prevState.letterVo,
          [name]: value,
        },
        modified: true,
        values: { ...this.state.values, [name]: value },
      }));
    }
  };

  handleChangeSearchSelectAuto = (data, name) => {

    let value = data ? data.value : ' ';
    if (name === "searchStatus") {
      this.setState({ searchStatus: value }, () => {
        this.attributRestore();
      });
    } else {

      this.setState(
        (prevState) => ({
          letterVo: {
            ...prevState.letterVo,
            [name]: value,
          },
          modified: true,
        }),
        () => {
          this.attributRestore();
        }
      );
    }

  }

  checked = (e, name) => {
    const check = this.state.values[name];
    if (check === "X") {
      this.setState({
        values: { ...this.state.values, [name]: "" },
      });
    } else {
      this.setState({
        values: { ...this.state.values, [name]: "X" },
      });
    }
  };

  componentWillUnmount() {
    this.props.resetMemberSearch({
      applicationId: this.props.selectedMemberId.applicationId,
    });
  }
 
  closeLetter = async ()=>{
    const obj={
    letterReqVOs: [
        this.state.letterVo
      ],
	  searchType:this.state.letterVo.sourceType,
	  searchId:this.state.searchId,
	  searchStatus:this.state.searchStatus,
    searchCreateDate:this.state.searchCreateDate

    };
    const status = await this.props.closeLetter(obj)

    LETTER_REQUEST_NAME =
    this.props.letterReqListData.length > 0
      ? [
        {
          value: this.props.letterReqListData[0].letterNameDesc,
          label: this.props.letterReqListData[0].letterNameDesc,
        },
      ]
      : [{ value: "", label: "" }];

  if (this.props.letterReqListData.length > 0 && status === "success") {
    await this.setState({
      letterVo: {
        ...this.props.letterReqListData[0],
        letterName: this.props.letterReqListData[0].letterName,
      },
      displaydata: true,
      toggleCreate: false,
      selectedIndex: 0,
    });
  } else {
    this.setState({
      letterVo: {
        ...INITIAL_STATE,
        sourceType:this.state.letterVo.sourceType
      },
      displaydata: true,
      toggleCreate: false,
    });
  }
  }
  render() {
    const { classes, servicesEnabled, letterReqListData } = this.props;
    let { letterVo, mbridLit } = this.state;
    let header1 = header

    
    if (letterReqListData.length > 0) {
      header1 = header.filter((value) => letterReqListData[0].sourceType === "A" ?
        value.label !== "M360 ID" && value.label !== "Wipro ID" : value.label !== "Application ID")
    }
    
    var fieldsArray = [];
    if (
      letterVo &&
      letterVo.lstVarData &&
      letterVo.lstVarData.length > 0 &&
      letterVo.lstLetterName
    ) {
      const { classes } = this.props;
      for (var i = 0; i <= letterVo.lstVarData.length - 1; i++) {
        const nameId = letterVo.lstVarData[i].varId;
        fieldsArray.push(
          <React.Fragment key={letterVo.lstVarData[i].description}>
            

            <div className={classes.container}>
              <div>
                {(() => {
                  switch (letterVo.lstVarData[i].fieldType) {
                    case "T":
                    case "C":
                    case "Z":
                      return (
                        <InputField
                          name={nameId}
                          label={letterVo.lstVarData[i].description}
                          display="inline"
                          maxLength={letterVo.lstVarData[i].fieldLength}
                          value={this.state.values[nameId]}
                          disabled={this.state.disabledVarField}
                          onChange={this.handleChangelstVarData.bind(
                            this,
                            nameId
                          )}
                        />
                      );
                    case "D":
                      return (
                        <div style={{ width: "700px" }}>
                          <div style={{ width: "700px" }}>
                            <InputField
                              name={nameId}
                              onClick={this.handleDates}
                              onChange={this.handleDate}
                              label={letterVo.lstVarData[i].description}
                              value={this.state.values[nameId]}
                              display="inline"
                              disabled={this.state.disabledVarField}
                              margin="normal"
                              maxLength={letterVo.lstVarData[i].fieldLength}
                            />
                            <div
                              style={{ marginLeft: "0px" }}
                              className={classes.validationMessageSelect}
                            >
                              {this.validatorDynamic.message(
                                "Date",
                                this.state.values[nameId],
                                "required|date_format"
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    case "X":
                      return (
                        <div className={classes.searchCheckbox}>
                          <Checkbox
                            id={nameId}
                            style={{ width: 36, height: 36 }}
                            icon={
                              <CheckBoxOutlineBlankIcon
                                style={{ fontSize: "16px" }}
                              />
                            }
                            checkedIcon={
                              <CheckBoxIcon
                                className={classes.checkboxmember}
                              />
                            }
                            onClick={(e) => {
                              this.checked(e, nameId);
                            }}
                            disabled={this.state.disabledVarField}
                            checked={this.state.values[nameId] ? true : false}
                          />
                          <FormLabel
                            classes={{ root: classes.formLabel }}
                            style={{ display: "inline" }}
                          >
                            {letterVo.lstVarData[i].description}
                          </FormLabel>
                        </div>
                      );
                    default:
                      return (
                        <div>
                          <TextField
                            id="outlined-textarea"
                            placeholder="Enter Comments (Max 255 characters)"
                            multiline
                            rows="5"
                            style={{
                              width: "50%",
                              marginBottom: "40px",
                              marginLeft: "0px",
                              backgroundColor: "#FFFFFF",
                              border: "1px solid rgba(81, 203, 238, 1)",
                            }}
                            className={classes.textField}
                            inputProps={{ maxLength: 255 }}
                            onChange={this.handleChangelstVarData.bind(
                              this,
                              nameId
                            )}
                            value={this.state.values[nameId]}
                            margin="none"
                            variant="outlined"
                          />
                          <div className={classes.commentsValidationMessage} />
                        </div>
                      );
                  }
                })()}
              </div>
            </div>
          </React.Fragment>
        );
      }
    }

    let searchButton = (
      <div className={classes.buttonContainer5}>
        <span
          class="button-container-search"
          style={{ marginTop: "17px", marginLeft: "-5px" }}
        >
          <button type="submit" class="btn btn-primary icon-search">
            Search
          </button>

          <button type="button" class="btn btn-secondary" onClick={this.reset}>
            Reset
          </button>
        </span>
      </div>
    );

    let lookUp = (
      <div className={classes.buttonContainer5}>
        <Button
          variant="contained"
          color="primary"
          className={classes.button}
          onClick={() => {
            this.callLookUp();
          }}
        >
          Lookup
        </Button>
      </div>
    );

    let newLetterRequest = (
      <div className={classes.buttonContainer}>
        {servicesEnabled.includes("EEUL") ? (
          <Button
            variant="contained"
            color="primary"
            className={classes.buttonFitToText}
            onClick={this.clearFields}
          >
            New Letter Request
          </Button>
        ) : null}
      </div>
    );
    
    let closeRequest = (
      <div className={classes.buttonContainer}>
        
        {this.state.letterVo.triggerStatus === "OPEN" ? (
          
          <Button
            variant="contained"
            color="primary"
            className={classes.buttonFitToText}
            onClick={this.closeLetter}
          >
            Close Letter
          </Button>
        ) : null}
      </div>
    );

    return (
      <React.Fragment>
        <Modal
          dialogTitle="Letters"
          message={this.state.message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>

        <Paper
          elevation={0}
          className={classes.card}
          style={{ minHeight: "400px" }}
        >
          <form autoComplete="off" onSubmit={this.LetterSearch}>
            <div class="search-panel">
              <ExpansionPanel
                summary="Search"              >
                <div className={classes.container}>
                  <div>
                    <AutoComplete1

                      options={LETTER_REQUEST_SOURCE}
                      handleChange={this.handleChangeSearchSelectAuto}
                      defaultValue={LETTER_REQUEST_SOURCE[0]}
                      value={letterVo.sourceType ? LETTER_REQUEST_SOURCE.filter(data => data.value === letterVo.sourceType)[0] : LETTER_REQUEST_SOURCE[0]}
                      label='Source'
                      margin='5px'
                      name='sourceType'
                    />
                    <div className={classes.validationMessageSelect}>
                      {this.validator.message(
                        "Source",
                        letterVo.sourceType,
                        "required"
                      )}
                    </div>
                  </div>

                  <div style={{ marginLeft: '19px' }}
                  >
                    <InputField
                      name="searchId"
                      label={
                        letterVo.sourceType
                          ? letterVo.sourceType === "A"
                            ? "Application Id"
                            : mbridLit.value === "TSA" ? "Wipro ID" : "M360 ID"
                          : "Primary ID"
                      }
                      value={this.state.searchId}
                      onChange={this.handlechange}
                      onBlur={this.handleOnBlur}
                      maxLength={15}
                    />
                    <div className={classes.validationMessage} />
                  </div>

                  <div>
                    <InputField
                      name="searchCreateDate"
                      placeholder="MM/DD/YYYY"
                      label="Create Date"
                      onClick={this.handleDates}
                      onChange={this.handleDate}
                      value={this.state.searchCreateDate}
                      margin="normal"
                      maxLength="10"
                    />
                    <div className={classes.validationMessage}>
                      {this.validator.message(
                        "Create Date",
                        this.state.searchCreateDate,
                        "date_format"
                      )}
                    </div>
                  </div>

                  <div>
                    <AutoComplete1
                      options={LETTER_REQUEST_STATUS}
                      handleChange={this.handleChangeSearchSelectAuto}
                      defaultValue={LETTER_REQUEST_STATUS[0]}
                      value={this.state.searchStatus ? LETTER_REQUEST_STATUS.filter(data => data.value === this.state.searchStatus)[0] : LETTER_REQUEST_STATUS[0]}
                      label='Status'
                      margin='0px'
                      name='searchStatus'
                    />
                    <div className={classes.validationMessageSelect} />
                  </div>
                  <div>{searchButton}</div>
                </div>
              </ExpansionPanel>
            </div>
          </form>

          <div>
            <div
              style={{ display: this.state.toggleDatatable ? "block" : "none" }}
              class="search-panel"
            >
              <ExpansionPanel
                summary="Search Results"
              >
                <DataTable
                  data={this.props.letterReqListData}
                  header={header1}
                  rowsPerPage={
                    this.props.letterReqListData.length < this.state.rowsPerPage
                      ? this.props.letterReqListData.length
                      : this.state.rowsPerPage
                  }
                  sortableHeader={true}
                  clicked={this.selectRow}
                  index={this.state.selectedIndex}
                  fetchMore={this.memberSearchNextPage}
                  nextPage={this.props.nextPage}
                  sortable={true}
                  rowsPerPageOptions={[10, 15, 20]}
                  searchable={true}
                  exportAsExcel={true} //
                  handleChangeRowsPerPage={this.handleChangeRowsPerPage}
                  handleChangePage={this.handleChangePage}
                  dateColumn="effDateFrmt"
                />
              </ExpansionPanel>
            </div>

            <form autoComplete="off" class="panel-body">
              <div className={classes.containerletter}>
                <div>
                  <AutoComplete1
                    options={LETTER_REQUESTSOURCE}
                    handleChange={this.handleChangeSearchSelectAuto}
                    value={letterVo.sourceTypeDesc ? LETTER_REQUESTSOURCE.filter(data => data.value === letterVo.sourceTypeDesc)[0] : LETTER_REQUESTSOURCE[0]}
                    defaultValue={LETTER_REQUESTSOURCE[0]}
                    label='Source'
                    name='sourceTypeDesc'
                    disabled={!this.state.edit}
                  />
                  <div className={classes.validationMessageSelect}>
                    {this.validator1.message(
                      "Source",
                      letterVo.sourceTypeDesc,
                      "required"
                    )}
                  </div>
                </div>

                <div>
                  <InputField
                    name="primaryId"
                    required
                    label={
                      letterVo.sourceTypeDesc
                        ? letterVo.sourceTypeDesc === "Application"
                          ? "Application Id"
                          : mbridLit.value === "TSA" ? "Wipro ID" : "M360 ID"
                        : "Primary ID"
                    }
                    value={letterVo.primaryId}
                    maxLength={20}
                    onChange={this.handlechange}
                    onBlur={this.handleOnBlur}
                    disabled={!this.state.edit}
                  />
                  <div className={classes.validationMessageSelect}>
                    {this.validator1.message(
                      "primaryId",
                      letterVo.primaryId,
                      "required"
                    )}
                  </div>
                </div>
                {this.state.showButton ? (
                  <div style={{ marginTop: "12px" }}>{lookUp}</div>
                ) : null}

                <div style={{ float: "right", marginTop: "12px" }}>
                  {newLetterRequest}
                </div>
                <div style={{ float: "right", marginTop: "12px" }}>
                  {closeRequest}
                </div>
              </div>
              <div className={classes.containerletter}>
                <div>
                  <InputField
                    name="firstName"
                    label="First Name"
                    value={letterVo.mbrFName}
                    onChange={this.handlechange}
                    onBlur={this.handleOnBlur}
                    disabled={!this.state.editable}
                  />
                  <div className={classes.validationMessage} />
                </div>

                <div>
                  <InputField
                    name="lastName"
                    label="Last Name"
                    value={letterVo.mbrLName}
                    onChange={this.handlechange}
                    onBlur={this.handleOnBlur}
                    disabled={!this.state.editable}
                  />
                  <div className={classes.validationMessage} />
                </div>

                <div>
                  <InputField
                    name="triggerTypeDesc"
                    label="Type"
                    value={letterVo.triggerTypeDesc}
                    onChange={this.handlechange}
                    onBlur={this.handleOnBlur}
                    disabled={!this.state.editable}
                  />
                  <div className={classes.validationMessage} />
                </div>

                <div>
                  <InputField
                    name="triggerStatusDesc"
                    label="Status"
                    value={letterVo.triggerStatusDesc}
                    onBlur={this.handleOnBlur}
                    onChange={this.handlechange}
                    disabled={!this.state.editable}
                  />
                  <div className={classes.validationMessage} />
                </div>
              </div>
              <div className={classes.containerletter}>
                <div>
                  <InputField
                    name="planId"
                    label="Plan"
                    value={letterVo.planId}
                    onChange={this.handlechange}
                    onBlur={this.handleOnBlur}
                    disabled={!this.state.editable}
                  />
                  <div className={classes.validationMessage} />
                </div>

                <div>
                  <InputField
                    name="PpbId"
                    label="PBP"
                    maxLength={3}
                    value={letterVo.pbpId}
                    onChange={this.handlechange}
                    onBlur={this.handleOnBlur}
                    disabled={!this.state.editable}
                  />
                  <div className={classes.validationMessage} />
                </div>

                <div>
                  <InputField
                    name="planDesignation"
                    label="Designation"
                    value={letterVo.planDesignation}
                    onChange={this.handlechange}
                    onBlur={this.handleOnBlur}
                    disabled={!this.state.editable}
                  />
                  <div className={classes.validationMessage} />
                </div>

                <div>
                  <InputField
                    name="effDateFrmt"
                    placeholder="MM/DD/YYYY"
                    onClick={this.handleDates}
                    onChange={this.handleDate}
                    label="Effective Date"
                    required
                    disabled={!this.state.edit}
                    value={letterVo.effDateFrmt}
                  />
                </div>
              </div>
              <div className={classes.containerletter}>
                <div>
                  <AutoComplete1

                    handleChange={this.handleChangeSearchSelectAuto}
                    label='Description'
                    options={
                      letterVo.lstLetterName
                        ? letterVo.lstLetterName
                        : LETTER_REQUEST_NAME
                    }
                    width="800px"
                    defaultValue={LETTER_REQUEST_NAME[0]}
                    value={
                      letterVo.lstLetterName
                        ? letterVo.lstLetterName.filter(
                          (option) => option.value === letterVo.description
                        )[0]
                        : LETTER_REQUEST_NAME.filter(
                          (option) => option.value === letterVo.letterNameDesc
                        )[0]
                    }
                    name='description'
                    disabled={!this.state.edit}
                  />
                  <div className={classes.validationMessage} />
                </div>
              </div>

              {letterVo.lstLetterName && this.state.showButton ? (
                <React.Fragment>
                  <div>
                    {" "}
                    <Button
                      variant="contained"
                      color="primary"
                      className={classes.button}
                      disbled={!letterVo.description}
                      onClick={() => {
                        this.selectLetter();
                      }}
                    >
                      select
                    </Button>
                  </div>
                </React.Fragment>
              ) : (
                  ""
                )}
              {letterVo.lstLetterName ? (
                <React.Fragment>
                  {letterVo.lstVarData && letterVo.lstVarData.length > 0 ? (
                    <React.Fragment>{fieldsArray}</React.Fragment>
                  ) : (
                      <div id="NoDataEntry">
                        {fieldsArray.length !== 0 ? "" : "No Data Entry Required"}
                      </div>
                    )}
                </React.Fragment>
              ) : (
                  ""
                )}

              {this.state.toggleCreate ? (
                <React.Fragment>
                  <div>
                    {" "}
                    <Button
                      variant="contained"
                      color="primary"
                      className={classes.button}
                      onClick={this.createLetter}
                    >
                      create
                    </Button>
                  </div>
                </React.Fragment>
              ) : (
                  ""
                )}
            </form>
            <HistoryData
              createUserId={
                letterVo.createUserId
                  ? letterVo.createUserId
                  : this.props.letterCreated.createUserId
              }
              createTime={
                letterVo.createTime
                  ? letterVo.createTime
                  : this.props.letterCreated.createTime
              }
              lastUpdtTime={
                letterVo.lastUpdtTime
                  ? letterVo.lastUpdtTime
                  : this.props.letterCreated.lastUpdtTime
              }
              lastUpdtUserId={
                letterVo.lastUpdtUserId
                  ? letterVo.lastUpdtUserId
                  : this.props.letterCreated.lastUpdtUserId
              }
            />
          </div>
        </Paper>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    selectedMemberId: state.memberSearch.selectedMemberId,
    letterReqListData: state.letterRequest.LetterReqList,
    lookUpData: state.letterRequest.lookUpList,
    selectedLetter: state.letterRequest.selectedLetterData,
    letterCreated: state.letterRequest.letterCreated,
    letterClosed: state.letterRequest.letterClosed,
    loginData: state.loginData,
    nextPage: state.letterRequest.nextPage,
    servicesEnabled: state.loginData.servicesEnabled,
    loginProfile: state.loginData.profiles,
    searchAttribute: state.memberSearch.searchAttributes
      ? state.memberSearch.searchAttributes.letterRequest
      : null,
  };
};
const mapDispatchToProps = {
  getLetterReq,
  postLookUp,
  selectLetter,
  createLetter,
  clearSelectLetter,
  resetLetterReqListData,
  resetMemberSearch,
  searchAttributes,
  SearchNextPage,
  closeLetter,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(LetterRequest));
