import Loadable from 'react-loadable-visibility/react-loadable';
import React from "react";




export const LetterDetails = Loadable({
	loader: () => import('./LetterDetails'),
	loading() {
		return <div></div>
	}
})

export const LetterQC = Loadable({
	loader: () => import('./LetterQC'),
	loading() {
		return <div></div>
	}
})

export const LetterUpload= Loadable({
	loader: () => import('./LetterUpload'),
	loading() {
		return <div></div> 
	}
})