import AppBar from "@material-ui/core/AppBar";
import { LetterDetails, LetterQC, LetterUpload } from "./LetterTabImport";
import NoSsr from "@material-ui/core/NoSsr";
import PropTypes from "prop-types";
import React from "react";
import Tab from "@material-ui/core/Tab";
import Tabs from "@material-ui/core/Tabs";
import Typography from "@material-ui/core/Typography";
import { connect } from "react-redux";
import { letterInitialDropDown } from "../../redux/actions/LetterReviewAction";
import { withStyles } from "@material-ui/core/styles";

function TabContainer(props) {
  return (
    <Typography component="div" style={{ padding: 8 }}>
      {props.children}
    </Typography>
  );
}

TabContainer.propTypes = {
  children: PropTypes.node.isRequired
};

function LinkTab(props) {
  return (
    <Tab component="a" onClick={event => event.preventDefault()} {...props} />
  );
}

const Styles = theme => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper
  },
  bigIndicator: {
    height: 2,
    backgroundColor: "white"
  }
});

class LetterReview extends React.Component {
  state = {
    value: 0
  };

  handleChange = (event, value) => {
    this.setState({ value });
  };

  async componentDidMount() {
    if (Object.keys(this.props.descriptionDropDown).length === 0) {
      await this.props.letterInitialDropDown();
    }
  }
  render() {
    const { classes } = this.props;
    const { value } = this.state;

    return (
      <NoSsr>
        <div className={classes.root}>
          <AppBar position="static">
            <Tabs
              variant="fullWidth"
              value={value}
              onChange={this.handleChange}
              classes={{
                indicator: classes.bigIndicator
              }}
            >
              <LinkTab label="Letter Details" href="page1" />
              <LinkTab label="Letter Upload" href="page2" />
              <LinkTab label="Letter QC" href="page3" />
            </Tabs>
          </AppBar>
          {value === 0 && (
            <TabContainer>
              <LetterDetails />
            </TabContainer>
          )}
          {value === 1 && (
            <TabContainer>
              <LetterUpload />
            </TabContainer>
          )}
          {value === 2 && (
            <TabContainer>
              <LetterQC />
            </TabContainer>
          )}
        </div>
      </NoSsr>
    );
  }
}

LetterReview.propTypes = {
  classes: PropTypes.object.isRequired
};

const mapStateToProps = state => {
  return {
    mbrSearchCriteria: state.memberSearch.mbrSearchCriteria,
    memberIdCheck: state.memberSearch.memberId,
    descriptionDropDown: state.letterReview.letterDescriptionData
  };
};
const mapDispatchToProps = {
  letterInitialDropDown
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(LetterReview));
