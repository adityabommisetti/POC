import * as DateUtil from "../../utils/DatePicker";
import isEmpty from "lodash/isEmpty";
import {
  LETTER_DETAILS_STATUS,
  LETTER_EDIT_STATUS,
  LETTER_REQUEST_SOURCE,
} from "../../constants/SelectStaticData";
import React, { Component } from "react";
import AutoComplete1 from "../UI/Select";
import {
  letterInitialDropDown,
  letterReviewData,
  letterReviewSearch,
  letterReviewUpdate,
  resetLetterDetails,
  SearchNextPage,
} from "../../redux/actions/LetterReviewAction";
import {
  resetMemberSearch,
  searchAttributes,
} from "../../redux/actions/MemberActions";
import Button from "@material-ui/core/Button";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import Checkbox from "@material-ui/core/Checkbox";
import DataTable from "../Home/DataTable";
import ExpansionPanel from "../UI/ExpansionPanel";
import FormLabel from "@material-ui/core/FormLabel";
import HistoryData from "../UI/MemberHistory";
import InputField from "../UI/InputField";
import MuiExpansionPanelDetails from "@material-ui/core/ExpansionPanelDetails";
import Paper from "@material-ui/core/Paper";
import { Styles } from "../../assets/styles/Theme";
import { connect } from "react-redux";
import { handleDateChange } from "../../utils/DateFormatter";
import { LETTER_DETAILS_TABLE_HEADER as header } from "../../constants/Headers/LetterHeaders";
import Modal from "../../components/UI/Modal/Modal";
import { withStyles } from "@material-ui/core/styles";

const LETTER_TABLE_HEADER = [
  {
    label: "Variable",
    title: "Variable",
    key: "variableDesc",
  },
  {
    label: "Data",
    title: "Data",
    key: "variableData",
  },
];

let dateChk = {};
const INITIAL_STATE = {
  searchSource: "",
  searchStatus: "",
  searchReqFormDate: "",
  searchReqToDate: "",
  searchBatchId: "",
  serachPrimaryId: "",
  searchDescription: "",
  filebatchid: "",
  primaryId: "",
  requestedDate: "",
  letterName: "",
  status: "",
  pdfView: "",
  supplementalId: "",
  recordStatus: "",
  requestDateFrmt: "",
  origMailDateFrmt: "",
  lastMailDateFrmt: "",
  printDateFrmt: "",
  reprintDateFrmt: "",
  responseDueDateFrmt: "",
  responseDateFrmt: "",
};

const ExpansionPanelDetails = withStyles((theme) => ({
  root: {
    padding: theme.spacing.unit * 2,
    display: "block",
  },
}))(MuiExpansionPanelDetails);

class LetterDetails extends Component {
  constructor(props) {
    super(props);
    this.state = {
      toggleDatatable:
        false ||
        (this.props.letterDetailsData &&
          this.props.letterDetailsData.length > 0),
      letterDetailsVO: {
        ...INITIAL_STATE,
        serachPrimaryId: this.props.searchAttribute
          ? this.props.searchAttribute.searchId
          : "",
        searchReqFormDate: this.props.searchAttribute
          ? this.props.searchAttribute.searchReqFromDateFrmt
          : "",
        searchReqToDate: this.props.searchAttribute
          ? this.props.searchAttribute.searchReqToDateFrmt
          : "",
        searchStatus: this.props.searchAttribute
          ? this.props.searchAttribute.searchStatus
          : "",
        searchBatchId: this.props.searchAttribute
          ? this.props.searchAttribute.searchBatchId
          : "",
        searchDescription: this.props.searchAttribute
          ? this.props.searchAttribute.searchLetterName
          : "",
      },
      letterData: [],
      data: null,
      modified: false,
      editable: false,
      displaydata: false,
      collapseSearch: false,
      collapseTableSearch: false,
      selectedIndex: 0,
      rowsPerPage: 10,
      searchSource: "",
      resetSearchChecked: false,
      closePopup: false,
      onload: true,
      mbridLit: [],
    };

    this.state = {
      toggleDatatable:
        false ||
        (this.props.letterDetailsData &&
          this.props.letterDetailsData.length > 0),
      letterDetailsVO: {
        ...INITIAL_STATE,
        serachPrimaryId: this.props.searchAttribute
          ? this.props.searchAttribute.searchId
          : "",
        searchReqFormDate: this.props.searchAttribute
          ? this.props.searchAttribute.searchReqFromDateFrmt
          : "",
        searchReqToDate: this.props.searchAttribute
          ? this.props.searchAttribute.searchReqToDateFrmt
          : "",
        searchStatus: this.props.searchAttribute
          ? this.props.searchAttribute.searchStatus
          : "",
        searchBatchId: this.props.searchAttribute
          ? this.props.searchAttribute.searchBatchId
          : "",
        searchDescription: this.props.searchAttribute
          ? this.props.searchAttribute.searchLetterName
          : "",
      },
      letterData: [],
      data: null,
      modified: false,
      editable: false,
      displaydata: false,
      collapseSearch: false,
      collapseTableSearch: false,
      selectedIndex: 0,
      rowsPerPage: 10,
      searchSource: "",
      resetSearchChecked: false,
      closePopup: false,
      onload: true,
    };
  }
  selectRow = async (index) => {
    localStorage.setItem("letterdetailIndex", index);
    this.setState((prevState) => ({
      reset: false,
    }));
    const data = [...this.props.letterDetailsData];
    const selectedVo = data[index];
    if (this.state.letterDetailsVO.serachPrimaryId) {
      selectedVo.serachPrimaryId = this.state.letterDetailsVO.serachPrimaryId;
    }
    const memberData = {
      fileBatchId: selectedVo.filebatchid,
      recordType: selectedVo.recordType,
      primaryId: selectedVo.primaryId,
      letterName: selectedVo.letterName,
    };
    await this.props.letterReviewData(memberData);

    this.setState((prevState) => ({
      selectedIndex: index,
      displaydata: true,
      letterDetailsVO: {
        ...selectedVo,
        searchReqFormDate: prevState.letterDetailsVO.searchReqFormDate,
        searchReqToDate: prevState.letterDetailsVO.searchReqToDate,
        searchStatus: prevState.letterDetailsVO.searchStatus,
        searchBatchId: prevState.letterDetailsVO.searchBatchId,
        searchDescription: prevState.letterDetailsVO.searchDescription,
      },
    }));
  };

  handleOnBlur = (name) => (event) => {
    let value = event.target.value.toUpperCase();
    this.setState((prevState) => ({
      letterDetailsVO: {
        ...prevState.letterDetailsVO,
        [name]: value.trim(),
      },
    }));
  };

  handlechange = (name) => (event) => {
    let value = event.target.value.toUpperCase();
    this.setState((prevState) => ({
      letterDetailsVO: {
        ...prevState.letterDetailsVO,
        [name]: value,
      },
      modified: true,
    }));
    this.attributeRestore();
  };

  setDate = (name, value) => {
    this.setState((prevState) => ({
      letterDetailsVO: {
        ...prevState.letterDetailsVO,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleDate = (name, targetVo) => (event) => {
    let value = event.target.value;
    this.setState((prevState) => ({
      letterDetailsVO: {
        ...prevState.letterDetailsVO,
        [name]: handleDateChange(value),
      },
      modified: true,
    }));
  };

  handleChangeSearchSelectAuto = (data, name) => {
    if (name === "searchSource") {
      this.setState(
        (prevState) => ({
          letterDetailsVO: {
            ...prevState.letterDetailsVO,
            [name]: data ? data.value : '',
          },
          [name]: data ? data.value : ' ',
          modified: true,
        }),
        () => {
          this.attributeRestore();
        }
      );
    } else {
      this.setState(
        (prevState) => ({
          letterDetailsVO: {
            ...prevState.letterDetailsVO,
            [name]: data ? data.value : ' ',
          },
          modified: true,
        }),
        () => {
          this.attributeRestore();
        }
      );
    }
  }

  updateLetter = async () => {
    let selectedVo = { ...this.state.letterDetailsVO };

    const data = [...this.props.letterDetailsData];
    const oldVo = data[this.state.selectedIndex];
    const newVoParams =
      selectedVo.lastMailDateFrmt +
      selectedVo.requestDateFrmt +
      selectedVo.origMailDateFrmt +
      selectedVo.printDateFrmt +
      selectedVo.recordStatus +
      selectedVo.reprintDateFrmt +
      selectedVo.responseDueDateFrmt +
      selectedVo.responseDateFrmt;
    const oldVoParams =
      oldVo.lastMailDateFrmt +
      oldVo.requestDateFrmt +
      oldVo.origMailDateFrmt +
      oldVo.printDateFrmt +
      oldVo.recordStatus +
      oldVo.reprintDateFrmt +
      oldVo.responseDueDateFrmt +
      oldVo.responseDateFrmt;
    const check = JSON.stringify(newVoParams) === JSON.stringify(oldVoParams);
    selectedVo.selectedIndex = this.state.selectedIndex;

    selectedVo.deleteAdj = 0;
    selectedVo.holdAdj = 0;
    if (check) {
      this.setState({
        message: "NO FIELDS UDPATED",
        closePopup: true,
      });
      return;
    }
    if (oldVo.deleteInd !== selectedVo.deleteInd) {
      if (this.state.reset) {
        selectedVo.deleteAdj = 1;
        selectedVo.deleteInd = "Y";
      } else {
        selectedVo.deleteInd = "N";
        selectedVo.deleteAdj = -1;
      }
    }

    if (oldVo.recordStatus !== selectedVo.recordStatus) {
      if (selectedVo.recordStatus === "HOLD") {
        selectedVo.holdAdj = 1;
      } else {
        selectedVo.holdAdj = -1;
      }
    }

    if (this.state.reset) {
      selectedVo.deleteInd = "Y";
    } else {
      selectedVo.deleteInd = "N";
    }
    delete selectedVo.lastMailDate;
    delete selectedVo.requestDate;
    delete selectedVo.origMailDate;
    delete selectedVo.printDate;
    delete selectedVo.reprintDate;
    delete selectedVo.responseDueDate;
    delete selectedVo.responseDate;
    this.props.letterReviewUpdate(selectedVo);
  };

  attributeRestore = () => {
    const params = {
      customerId: null,
      searchType: this.state.searchSource,
      searchId: this.state.letterDetailsVO.serachPrimaryId,
      searchReqFromDateFrmt: this.state.letterDetailsVO.searchReqFormDate,
      searchReqToDateFrmt: this.state.letterDetailsVO.searchReqToDate,
      searchStatus: this.state.letterDetailsVO
        ? this.state.letterDetailsVO.searchStatus
        : null,
      searchBatchId: this.state.letterDetailsVO.searchBatchId,
      searchLetterName: this.state.letterDetailsVO.searchDescription,
      searchDeleteInd: this.state.resetSearchChecked ? "Y" : "",
    };

    this.props.searchAttributes({ letterDetails: params });
  };
  handleChangePage = (index) => {
    this.selectRow(index);
  };
  LetterDetailsSearch = async (event) => {
    event.preventDefault();
    this.setState((prevState) => ({
      reset: false,
    }));
    const params = {
      customerId: null,
      searchType: this.state.searchSource,
      searchId: this.state.letterDetailsVO.serachPrimaryId.trim(),
      searchReqFromDateFrmt: this.state.letterDetailsVO.searchReqFormDate,
      searchReqToDateFrmt: this.state.letterDetailsVO.searchReqToDate,
      searchStatus: this.state.letterDetailsVO
        ? this.state.letterDetailsVO.searchStatus
        : null,
      searchBatchId: this.state.letterDetailsVO.searchBatchId.trim(),
      searchLetterName: this.state.letterDetailsVO.searchDescription,
      searchDeleteInd: this.state.resetSearchChecked ? "Y" : "",
    };

    await this.props.letterReviewSearch(params);
    this.setState({ toggleDatatable: true });
    this.attributeRestore();
    let letterDetailsVO = this.state.letterDetailsVO;

    if (
      this.props.letterDetailsData &&
      this.props.letterDetailsData.length > 0
    ) {
      letterDetailsVO = {
        ...letterDetailsVO,
        ...this.props.letterDetailsData[0],
      };
      this.setState((prevState) => ({
        displaydata: true,
        letterDetailsVO: letterDetailsVO,
        selectedIndex: 0,
      }));
    }
  };

  memberSearchNextPage = async (pageNo) => {
    const { letterDetailsData } = this.props;
    const lastRow = letterDetailsData[letterDetailsData.length - 1];
    let payload = {
      customerId: null,
      searchType: this.state.searchSource,
      searchReqFromDateFrmt: this.state.letterDetailsVO.searchReqFormDate,
      searchReqToDateFrmt: this.state.letterDetailsVO.searchReqToDate,
      searchStatus: this.state.letterDetailsVO
        ? this.state.letterDetailsVO.searchStatus
        : null,
      searchBatchId: this.state.letterDetailsVO.searchBatchId,
      searchLetterName: this.state.letterDetailsVO.searchDescription,
      searchDeleteInd: this.state.resetSearchChecked ? "Y" : "",
      lastRowPrimaryId: lastRow.primaryId,
      lastRowFileBatchId: lastRow.filebatchid,
      lastRowLetterName: lastRow.letterName,
      lastRowRecordType: lastRow.recordType,
    };
    if (this.props.nextPage) {
      await this.props.SearchNextPage(payload);
      this.setState({ selectedIndex: pageNo * this.state.rowsPerPage });
    }
  };

  handleChangeRowsPerPage = (rowsPerPage) => {
    this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  handleDates = (fieldId) => (event) => {
    var self = this;

    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        if (
          dateChk.name !== e.target.name ||
          dateChk.value !== e.target.value
        ) {
          self.setDate(e.target.name, e.target.value);
          document.getElementById(fieldId.substr(1)).focus();
        }
        dateChk.name = e.target.name;
        dateChk.value = e.target.value;
      });
  };

  setDate = (name, value) => {
    this.setState((prevState) => ({
      letterDetailsVO: {
        ...prevState.letterDetailsVO,
        [name]: handleDateChange(value),
      },
      modified: true,
    }));
  };

  reset = () => {
   
    let letterDetailsVO = { ...INITIAL_STATE };
    this.setState((prevState) => ({
      toggleDatatable: false,
      searchSource: "",
      letterDetailsVO: letterDetailsVO,
      resetSearchChecked: false,
    }));
    this.props.resetLetterDetails();
    this.props.searchAttributes({ letterDetails: {} });
  };

  checkedSearch = (e) => {
    this.setState((prevState) => ({
      resetSearchChecked: !this.state.resetSearchChecked,
    }));
  };
  checked = (e) => {
    this.setState((prevState) => ({
      reset: !this.state.reset,
    }));

    this.setState((prevState) => ({
      letterDetailsVO: {
        ...prevState.letterDetailsVO,
        deleteInd: !this.state.reset ? "Y" : "N",
      },
    }));
  };
  componentDidUpdate() {
    if (this.props.searchAttribute && this.state.onload) {
      this.setState((prevState) => ({
        onload: false,
        searchSource: this.props.searchAttribute.searchType,
        letterDetailsVO: {
          ...prevState.letterDetailsVO,
          serachPrimaryId: this.props.searchAttribute.searchId,
          searchReqFormDate: this.props.searchAttribute.searchReqFromDateFrmt,
          searchReqToDate: this.props.searchAttribute.searchReqToDateFrmt,
          searchStatus: this.props.searchAttribute.searchStatus,
          searchBatchId: this.props.searchAttribute.searchBatchId,
          searchDescription: this.props.searchAttribute.searchLetterName
        },
      }));
    }
  }

  componentWillUnmount() {
    this.props.resetMemberSearch({
      applicationId: this.props.selectedMemberId.applicationId,
    });
  }

  componentDidMount() {
    if (!isEmpty(this.props.letterDetailsData)) {
      const index = localStorage.getItem("letterdetailIndex")
        ? localStorage.getItem("letterdetailIndex")
        : 0;
      const selectedVo = this.props.letterDetailsData[index];
      this.setState(() => ({
        letterDetailsVO: {
          ...selectedVo,
        },
      }));
    }
    const { loginProfile } = this.props;
    const MBRIDLIT = loginProfile.filter((data) => data.label === "MBRIDLIT");
    this.setState({
      mbridLit: MBRIDLIT[0],
    });
  }

  modalClosed = () => {
    this.setState({ closePopup: false });
  };

  render() {
    const { classes, servicesEnabled, letterDetailsData } = this.props;
    const { letterDetailsVO, mbridLit } = this.state;

    let header1 = header
    if (!isEmpty(letterDetailsData)) {
      header1 = header.filter((value) =>
        letterDetailsData[0].recordType === "A"
          ? value.label !== "M360 ID" && value.label !== "Wipro ID"
          : value.label !== "Application ID"
      );
    }
    let update = (
      <div className={classes.buttonContainer}>
        {servicesEnabled.includes("EEUL") ? (
          <Button
            variant="contained"
            color="primary"
            className={classes.button}
            onClick={() => {
              this.updateLetter();
            }}
          >
            Update
          </Button>
        ) : null}
      </div>
    );

    let LETTER_EDIT_STATUS1 = [...LETTER_EDIT_STATUS];
    let statusOptions = false;
    let recordStatus = "";
    ["APPLIED", "LOADED", "HOLD"].map((data) => {
      if (!isEmpty(this.props.letterDetailsData)) {
        recordStatus = this.props.letterDetailsData[this.state.selectedIndex]
          .recordStatus;
        if (data === recordStatus) {
          statusOptions = recordStatus.includes(data);
        }
      }
      return null;
    });
    if (!statusOptions) {
      LETTER_EDIT_STATUS1.splice(1, 0, {
        value: recordStatus,
        label: recordStatus,
      });
    }
    return (
      <React.Fragment>
        <Modal
          dialogTitle="Letter details"
          message={this.state.message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Paper elevation={0} className={classes.card}>
          <div class="search-panel">
            <ExpansionPanel
              summary="Search"
              defaultCollapsed={this.state.collapseSearch}
              style={{ display: "block" }}
            >
              <ExpansionPanelDetails>
                <form onSubmit={this.LetterDetailsSearch}>
                  <div
                    className={classes.containertypography}
                    style={{ display: "-webkit-inline-box" }}
                  >
                    <div>
                      <AutoComplete1
                        options={LETTER_REQUEST_SOURCE}
                        handleChange={this.handleChangeSearchSelectAuto}
                        defaultValue={LETTER_REQUEST_SOURCE[0]}
                        value={LETTER_REQUEST_SOURCE.filter(data => data.value === this.state.searchSource)[0]}
                        label='Source'
                        margin='0px'
                        fontSize="0.718em"
                        name='searchSource'
                      />
                      <div className={classes.validationMessageSelect} />
                    </div>

                    <div>
                      <InputField
                        name="serachPrimaryId"
                        label={
                          letterDetailsVO.searchSource
                            ? letterDetailsVO.searchSource === "A"
                              ? "Application ID"
                              : mbridLit.value === "TSA"
                                ? "Wipro ID"
                                : "M360 ID"
                            : "Primary ID"
                        }
                        value={letterDetailsVO.serachPrimaryId}
                        onChange={this.handlechange("serachPrimaryId")}
                        onBlur={this.handleOnBlur("serachPrimaryId")}
                        maxLength={15}
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="searchReqFormDate"
                        placeholder="MM/DD/YYYY"
                        maxLength={10}
                        onClick={this.handleDates(
                          "#searchReqFormDate",
                          "letterDetailsVO"
                        )}
                        onChange={this.handleDate(
                          "searchReqFormDate",
                          "letterDetailsVO"
                        )}
                        label="Request Date Form"
                        value={letterDetailsVO.searchReqFormDate}
                        margin="normal"
                      />
                      <div className={classes.validationMessage} />
                    </div>

                    <div>
                      <InputField
                        name="searchReqToDate"
                        placeholder="MM/DD/YYYY"
                        maxLength={10}
                        onClick={this.handleDates(
                          "#searchReqToDate",
                          "letterDetailsVO"
                        )}
                        onChange={this.handleDate(
                          "searchReqToDate",
                          "letterDetailsVO"
                        )}
                        label="To"
                        value={letterDetailsVO.searchReqToDate}
                        margin="normal"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <AutoComplete1
                        fontSize="0.718em"
                        margin="0px"
                        options={LETTER_DETAILS_STATUS}
                        handleChange={this.handleChangeSearchSelectAuto}
                        defaultValue={LETTER_DETAILS_STATUS[0]}
                        value={LETTER_DETAILS_STATUS.filter(data => data.value === letterDetailsVO.searchStatus)[0]}
                        label='Status'
                        name='searchStatus'
                      />
                    </div>
                  </div>

                  <div className={classes.containertypography}>
                    <div>
                      <InputField
                        name="Choose Batch Id..."
                        label="Batch ID"
                        width="180px"
                        value={letterDetailsVO.searchBatchId}
                        onChange={this.handlechange("searchBatchId")}
                        onBlur={this.handleOnBlur("searchBatchId")}
                        maxLength={10}
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      {this.props.descriptionDropDown.length > 0 ? (
                        <AutoComplete1
                          options={this.props.descriptionDropDown}
                          handleChange={this.handleChangeSearchSelectAuto}
                          defaultValue={this.props.descriptionDropDown[0]}
                          value={letterDetailsVO.searchDescription ? this.props.descriptionDropDown.filter(data => data.value === letterDetailsVO.searchDescription)[0] : this.props.descriptionDropDown[0]}
                          width='580px'
                          margin="0px"
                          fontSize="0.718em"
                          label='Description'
                          name='searchDescription'
                        />
                      ) : (
                          ""
                        )}
                      <div className={classes.validationMessageSelect} />
                    </div>

                    <div
                      className={classes.buttonContainer12}
                      style={{ paddingTop: "17px", paddingLeft: "3vw" }}
                    >
                      <Checkbox
                        style={{ width: 36, height: 36 }}
                        icon={
                          <CheckBoxOutlineBlankIcon
                            style={{ fontSize: "16px" }}
                          />
                        }
                        checkedIcon={
                          <CheckBoxIcon
                            style={{
                              fontSize: "16px",
                              color: "rgba(39, 108, 155, 1)",
                            }}
                          />
                        }
                        checked={this.state.resetSearchChecked}
                        onClick={(e) => {
                          this.checkedSearch(e);
                        }}
                      />
                      <FormLabel classes={{ root: classes.checkboxTextSize }}>
                        Delete
                      </FormLabel>
                      <span class="button-container-search">
                        <button
                          type="submit"
                          class="btn btn-primary icon-search"
                        >
                          Search
                        </button>

                        <button
                          type="button"
                          class="btn btn-secondary"
                          onClick={this.reset}
                        >
                          New search
                        </button>
                      </span>
                    </div>
                  </div>
                </form>
              </ExpansionPanelDetails>
            </ExpansionPanel>
          </div>
          {
            true ? (
              <div>
                {
                  <div
                    style={{
                      display: this.state.toggleDatatable ? "block" : "none",
                    }}
                    class="search-panel"
                  >
                    <ExpansionPanel
                      summary="Search Results"
                      defaultCollapsed={this.state.collapseTableSearch}
                    >
                      <DataTable
                        dateColumn="requestDateFrmt"
                        data={
                          isEmpty(this.props.letterDetailsData)
                            ? []
                            : this.props.letterDetailsData
                        }
                        header={header1}
                        rowsPerPage={
                          this.props.letterDetailsData &&
                            this.props.letterDetailsData.length <
                            this.state.rowsPerPage
                            ? this.props.letterDetailsData.length
                            : this.state.rowsPerPage
                        }
                        sortableHeader={true}
                        clicked={this.selectRow}
                        index={this.state.selectedIndex}
                        fetchMore={this.memberSearchNextPage}
                        nextPage={this.props.nextPage}
                        sortable={true}
                        rowsPerPageOptions={[10, 15, 20]}
                        searchable={true}
                        exportAsExcel={true}
                        handleChangeRowsPerPage={this.handleChangeRowsPerPage}
                        handleChangePage={this.handleChangePage}
                      />
                    </ExpansionPanel>
                  </div>
                }
                {this.props.letterDetailsData &&
                  this.props.letterDetailsData.length > 0 ? (
                    <React.Fragment>
                      {update}
                      <form
                        autoComplete="off"
                        style={{ backgroundColor: "#ececec" }}
                      >
                        <div className={classes.containertypography}>
                          <div>
                            <InputField
                              name="recordType"
                              label="Record Type"
                              value={letterDetailsVO.recordTypeFrmt}
                              onChange={this.handlechange("recordType")}
                              disabled={!this.state.editable}
                            />
                            <div className={classes.validationMessage} />
                          </div>

                          <div>
                            <InputField
                              name="WiproId"
                              label={
                                letterDetailsVO.searchSource
                                  ? letterDetailsVO.searchSource === "A"
                                    ? "Application ID"
                                    : mbridLit.value === "TSA"
                                      ? "Wipro ID"
                                      : "M360 ID"
                                  : "Primary ID"
                              }
                              value={letterDetailsVO.primaryId}
                              onChange={this.handlechange("primaryId")}
                              disabled={!this.state.editable}
                            />
                            <div className={classes.validationMessage} />
                          </div>

                          <div>
                            <InputField
                              name="supplementalId"
                              label="Plan Member ID"
                              value={letterDetailsVO.supplementalId}
                              onChange={this.handlechange("supplementalId")}
                              disabled={!this.state.editable}
                            />
                            <div className={classes.validationMessage} />
                          </div>

                          <div>
                            <AutoComplete1
                              handleChange={this.handleChangeSearchSelectAuto}
                              label='Status'
                              margin="0px"
                              fontSize="0.718em"
                              options={LETTER_EDIT_STATUS1}
                              defaultValue={LETTER_EDIT_STATUS1[1]}
                              value={LETTER_EDIT_STATUS1[1]}
                              name='recordStatus'
                              disabled={
                                letterDetailsVO.recordStatus === "DELETED" ||
                                letterDetailsVO.recordStatus === "EXTRACTED"
                              }
                            />
                          </div>
                          <div className={classes.checkbox} style={{ marginTop: "17px" }}>
                            <Checkbox
                              disabled={
                                letterDetailsVO.recordStatus === "DELETED"
                              }
                              style={{ width: 36, height: 36 }}
                              icon={
                                <CheckBoxOutlineBlankIcon
                                  style={{ fontSize: "16px" }}
                                />
                              }
                              checkedIcon={
                                <CheckBoxIcon
                                  style={{
                                    fontSize: "16px",
                                    color: "rgba(39, 108, 155, 1)",
                                  }}
                                />
                              }
                              checked={
                                this.state.reset ||
                                letterDetailsVO.deleteInd === "Y" ||
                                letterDetailsVO.recordStatus === "DELETED"
                              }
                              onClick={(e) => {
                                this.checked(e);
                              }}
                            />
                            <FormLabel
                              classes={{ root: classes.checkboxTextSize }}
                            >
                              Delete
                          </FormLabel>
                          </div>
                        </div>
                        <div className={classes.containertypography}>
                          <div className={classes.space3}>
                            <div>
                              <InputField
                                name="LetterName"
                                label="Letter Name"
                                value={letterDetailsVO.letterNameFrmt}
                                width="600px"
                                disabled={!this.state.editable}
                              />
                              <div className={classes.validationMessage} />
                            </div>
                          </div>
                        </div>
                        <div className={classes.containertypography}>
                          <div>
                            <InputField
                              name="requestDateFrmt"
                              placeholder="MM/DD/YYYY"
                              onClick={this.handleDates(
                                "#requestDateFrmt",
                                "letterDetailsVO"
                              )}
                              onChange={this.handleDate(
                                "requestDateFrmt",
                                "letterDetailsVO"
                              )}
                              label="Print Request Date"
                              required
                              value={letterDetailsVO.requestDateFrmt}
                              margin="normal"
                            />
                            <div className={classes.validationMessage} />
                          </div>

                          <div>
                            <InputField
                              name="origMailDateFrmt"
                              placeholder="MM/DD/YYYY"
                              onClick={this.handleDates(
                                "#origMailDateFrmt",
                                "letterDetailsVO"
                              )}
                              onChange={this.handleDate(
                                "origMailDateFrmt",
                                "letterDetailsVO"
                              )}
                              label="Orginal Mail Date"
                              required
                              value={letterDetailsVO.origMailDateFrmt}
                              margin="normal"
                            />
                            <div className={classes.validationMessage} />
                          </div>

                          <div>
                            <InputField
                              name="lastMailDateFrmt"
                              placeholder="MM/DD/YYYY"
                              onClick={this.handleDates(
                                "#lastMailDateFrmt",
                                "letterDetailsVO"
                              )}
                              onChange={this.handleDate(
                                "lastMailDateFrmt",
                                "letterDetailsVO"
                              )}
                              label="Last Mail Date"
                              required
                              value={letterDetailsVO.lastMailDateFrmt}
                              margin="normal"
                            />
                            <div className={classes.validationMessage} />
                          </div>

                          <div>
                            <InputField
                              name="Batch ID"
                              label="Batch ID"
                              required
                              value={letterDetailsVO.filebatchid}
                              margin="normal"
                              disabled={!this.state.editable}
                            />
                            <div className={classes.validationMessage} />
                          </div>
                        </div>

                        <div className={classes.containertypography2}>
                          <div>
                            <InputField
                              name="printDateFrmt"
                              placeholder="MM/DD/YYYY"
                              onClick={this.handleDates(
                                "#printDateFrmt",
                                "letterDetailsVO"
                              )}
                              onChange={this.handleDate(
                                "printDateFrmt",
                                "letterDetailsVO"
                              )}
                              label="Date Printed"
                              required
                              value={letterDetailsVO.printDateFrmt}
                              margin="normal"
                            />
                            <div className={classes.validationMessage} />
                          </div>

                          <div>
                            <InputField
                              name="reprintDateFrmt"
                              placeholder="MM/DD/YYYY"
                              onClick={this.handleDates(
                                "#reprintDateFrmt",
                                "letterDetailsVO"
                              )}
                              onChange={this.handleDate(
                                "reprintDateFrmt",
                                "letterDetailsVO"
                              )}
                              label="Reprint Date"
                              required
                              value={letterDetailsVO.reprintDateFrmt}
                              margin="normal"
                            />
                            <div className={classes.validationMessage} />
                          </div>

                          <div>
                            <InputField
                              name="responseDueDateFrmt"
                              placeholder="MM/DD/YYYY"
                              onClick={this.handleDates(
                                "#responseDueDateFrmt",
                                "letterDetailsVO"
                              )}
                              onChange={this.handleDate(
                                "responseDueDateFrmt",
                                "letterDetailsVO"
                              )}
                              label="Response Due Date"
                              required
                              value={letterDetailsVO.responseDueDateFrmt}
                              margin="normal"
                            />
                            <div className={classes.validationMessage} />
                          </div>

                          <div>
                            <InputField
                              name="responseDateFrmt"
                              placeholder="MM/DD/YYYY"
                              onClick={this.handleDates(
                                "#responseDateFrmt",
                                "letterDetailsVO"
                              )}
                              onChange={this.handleDate(
                                "responseDateFrmt",
                                "letterDetailsVO"
                              )}
                              label="Response Date"
                              required
                              value={letterDetailsVO.responseDateFrmt}
                              margin="normal"
                            />
                            <div className={classes.validationMessage} />
                          </div>
                        </div>
                      </form>
                    </React.Fragment>
                  ) : (
                    ""
                  )}

                <br />

                <br />
                {!isEmpty(this.props.letterDetailsData) &&
                  !isEmpty(this.props.letterCoverDetailsData) ? (
                    <div className={classes.letter}>
                      <DataTable
                        data={this.props.letterCoverDetailsData}
                        header={LETTER_TABLE_HEADER}
                        rowsPerPage={this.props.letterCoverDetailsData.length}
                        sortableHeader={true}
                        clicked={() => { }}
                        index={0}
                        selectedRow="true"
                        removePagination="true"
                      />
                    </div>
                  ) : null}
                <HistoryData
                  createUserId={letterDetailsVO.createUserId}
                  createTime={letterDetailsVO.createTime}
                  lastUpdtTime={letterDetailsVO.lastUpdtTime}
                  lastUpdtUserId={letterDetailsVO.lastUpdtUserId}
                />
              </div>
            ) : null
          }
        </Paper>
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    descriptionDropDown: state.letterReview.letterDescriptionData,
    letterDetailsData: state.letterReview.lstLetterDetails,
    letterCoverDetailsData: state.letterReview.lstLetterDetailsCover,
    selectedMemberId: state.memberSearch.selectedMemberId,
    nextPage: state.letterReview.nextPage,
    searchAttribute: state.memberSearch.searchAttributes
      ? state.memberSearch.searchAttributes.letterDetails
      : null,
    servicesEnabled: state.loginData.servicesEnabled,
    loginProfile: state.loginData.profiles,
  };
};
const mapDispatchToProps = {
  letterInitialDropDown,
  letterReviewSearch,
  letterReviewData,
  resetLetterDetails,
  letterReviewUpdate,
  resetMemberSearch,
  searchAttributes,
  SearchNextPage,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(LetterDetails));