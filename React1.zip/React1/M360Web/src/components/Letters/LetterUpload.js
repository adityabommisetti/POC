import * as DateUtil from "../../utils/DatePicker";
import React, { Component } from "react";
import AutoComplete1 from "../UI/Select";
import ExpansionPanel from "../UI/ExpansionPanel";
import ImageUploader from "react-images-upload";
import InputField from "../UI/InputField";
import { LETTER_UPLOAD_SOURCE_SHORT } from "../../constants/SelectStaticData";
import Modal from "../../components/UI/Modal/Modal";
import Paper from "@material-ui/core/Paper";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../assets/styles/Theme";
import { connect } from "react-redux";
import { handleDateChange } from "../../utils/DateFormatter";
import { letteUpload } from "../../redux/actions/LetterReviewAction";
import { withStyles } from "@material-ui/core/styles";

let dateChk = {};
class LetterUpload extends Component {
  constructor(props) {
    super(props);
    this.state = {
      letterUploadVO: {
        source: "",
        primaryId: "",
        printRequestDate: "",
        originalMailDate: "",
        lastMailDate: "",
        datePrinted: "",
        reprintDate: "",
        responseDueDate: "",
        responseDate: "",
        closePopup: false,
        message: "",
        mbridLit: [],
      },
    };
    this.validator = new SimpleReactValidator();
  }

  handleDates = (fieldId) => {
    var self = this;

    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        if (
          dateChk.name !== e.target.name ||
          dateChk.value !== e.target.value
        ) {
          self.setDate(e.target.name, e.target.value);
          document.getElementById(fieldId.substr(1)).focus();
        }
        dateChk.name = e.target.name;
        dateChk.value = e.target.value;
      });
  };

  setDate = (name, value) => {
    this.setState((prevState) => ({
      letterUploadVO: {
        ...prevState.letterUploadVO,
        [name]: handleDateChange(value),
      },
      modified: true,
    }));
  };

  handleDate = (name, targetVo) => (event) => {
    let value = event.target.value;
    this.setState((prevState) => ({
      letterUploadVO: {
        ...prevState.letterUploadVO,
        [name]: handleDateChange(value),
      },
      modified: true,
    }));
  };

  handleOnBlur = () => {
    this.setState((prevState) => ({
      letterUploadVO: {
        ...prevState.letterUploadVO,
        primaryId: prevState.letterUploadVO.primaryId.trim(),
      },
    }));
  };

  handlechange = (name) => (event) => {
    let value = event.target.value.toUpperCase();
    this.setState((prevState) => ({
      letterUploadVO: {
        ...prevState.letterUploadVO,
        [name]: value,
      },
    }));
  };

  handleChangeSearchSelectAuto = (data, name) => {
    this.setState((prevState) => ({
      letterUploadVO: {
        ...prevState.letterUploadVO,
        [name]: data ? data.value : ' ',
      },
    }));
  };

  onChange(e) {
    let reader = new FileReader();
    this.setState({ file: e.target.files[0] });
    reader.onload = (e) => {
      console.warn("file data", e.target.result);
    };
  }

  uploadProof = (pictureFiles, pictureDataURLs) => {
    if (this.validator.allValid()) {
      let status;
      let filename = "abcd";
      for (var img in pictureFiles) {
        if (pictureFiles.hasOwnProperty(img)) {
          filename = pictureFiles[img].name;
        }
      }

      if (filename.substr(filename.length - 3).toLowerCase() === "pdf") {
        const file = pictureFiles[pictureFiles.length - 1];

        return new Promise((resolve, reject) => {
          const reader = new FileReader();

          reader.onload = (event) => {
            resolve(event.target.result);
            const params = {
              customerId: null,
              memberId: this.state.letterUploadVO.primaryId,
              userId: null,
              fileName: filename.substring(0, filename.length - 4),
              file: event.target.result.substring(28),
              recordType: this.state.letterUploadVO.source,
              fileBatchId: null,
              memberLetters: null,
              printRequestDateFrmt: this.state.letterUploadVO.printRequestDate,
              origMailDateFrmt: this.state.letterUploadVO.originalMailDate,
              lastMailDateFrmt: this.state.letterUploadVO.lastMailDate,
              printDateFrmt: this.state.letterUploadVO.datePrinted,
              reprintDateFrmt: this.state.letterUploadVO.reprintDate,
              responseDueDateFrmt: this.state.letterUploadVO.responseDueDate,
              responseDateFrmt: this.state.letterUploadVO.responseDate,
            };

            status = this.props.letteUpload(params);
            this.setModal(status);
          };
          reader.onerror = (err) => {
            reject(err);
          };
          reader.readAsDataURL(file);

          var divsToHide = document.getElementsByClassName("errorMessage"); //divsToHide is an array
          for (var i = 0; i < divsToHide.length; i++) {
            divsToHide[i].parentNode.removeChild(divsToHide[i]);
          }
        });
      }
      this.setState({
        message: "Only PDF Files are allowed",
        closePopup: true,
      });
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };
  setModal = (status) => {
    status
      .then((msg) => {
        if (msg === "success") {
          this.setState({
            closePopup: true,
            message: "Uploaded successfully",
          });
        } else {
          this.setState({
            message: msg,
            closePopup: true,
          });
        }
      })
      .catch((msg) =>
        this.setState({
          message: msg,
          closePopup: true,
        })
      );
  };
  componentDidMount() {
    var el = document.getElementsByClassName("fileContainer");
    if (el) {
      el[0].style.background = "none";
      el[0].style.boxShadow = "none";
    }
    const { loginProfile } = this.props;
    const MBRIDLIT = loginProfile.filter((data) => data.label === "MBRIDLIT");
    this.setState({
      mbridLit: MBRIDLIT[0],
    });
  }
  componentDidUpdate() { }
  modalClosed = () => {
    this.setState({ closePopup: false });
  };

  render() {
    const { classes, servicesEnabled } = this.props;
    const mbridLit = this.state;
    return (
      <React.Fragment>
        <Modal
          dialogTitle="Letter Upload"
          message={this.state.message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>

        <Paper elevation={0} className={classes.card}>
          <form autoComplete="off">
            <div class="search-panel">
              <ExpansionPanel
                summary="Search"
                defaultCollapsed={this.state.collapseSearch}
              >
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    this.uploadProof();
                  }}
                >
                  <div className={classes.containertypography}>
                    <div className={classes.container}>
                      <div className={classes.Margin}>
                        <AutoComplete1
                          options={LETTER_UPLOAD_SOURCE_SHORT}
                          handleChange={this.handleChangeSearchSelectAuto}
                          defaultValue={LETTER_UPLOAD_SOURCE_SHORT[0]}
                          value={this.state.letterUploadVO.source ? LETTER_UPLOAD_SOURCE_SHORT.filter(data => data.value === this.state.letterUploadVO.source)[0] : LETTER_UPLOAD_SOURCE_SHORT[0]}
                          label='Source'
                          name='source'
                          margin="0px"
                          fontSize="0.718em"
                        />
                        <div className={classes.validationMessageSelect}>
                          <div
                            style={{ marginLeft: "-23px" }}
                            className={classes.validationMessage}
                          >
                            {this.validator.message(
                              "Source",
                              this.state.letterUploadVO.source,
                              "required"
                            )}
                          </div>
                        </div>
                      </div>

                      <div>
                        <InputField
                          maxLength={15}
                          name="primaryId"
                          InputProps={{ className: classes.textFont }}
                          label={
                            this.state.letterUploadVO.source
                              ? this.state.letterUploadVO.source === "A"
                                ? "Application Id"
                                : mbridLit.value === "TSA" ? "Wipro ID" : "M360 ID"
                              : "Primary ID"
                          }
                          value={this.state.letterUploadVO.primaryId}
                          onChange={this.handlechange("primaryId")}
                          onBlur={this.handleOnBlur}
                          className={classes.textField}
                          InputLabelProps={{
                            className: classes.label,
                            shrink: true,
                          }}
                        />
                        <div className={classes.validationMessageSelect}>
                          <div
                            style={{ marginLeft: "-23px" }}
                            className={classes.validationMessage}
                          >
                            {this.validator.message(
                              "Primary Id",
                              this.state.letterUploadVO.primaryId,
                              "required"
                            )}
                          </div>
                        </div>
                      </div>

                      <div>
                        <InputField
                          name="printRequestDate"
                          placeholder="MM/DD/YYYY"
                          onClick={() =>
                            this.handleDates(
                              "#printRequestDate",
                              "letterUploadVO"
                            )
                          }
                          onChange={this.handleDate(
                            "printRequestDate",
                            "letterUploadVO"
                          )}
                          maxLength="10"
                          label="Print Request Date"
                          value={this.state.letterUploadVO.printRequestDate}
                          margin="normal"
                        />
                        <div className={classes.validationMessageSelect} />
                      </div>

                      <div>
                        <InputField
                          name="originalMailDate"
                          placeholder="MM/DD/YYYY"
                          onClick={() =>
                            this.handleDates(
                              "#originalMailDate",
                              "letterUploadVO"
                            )
                          }
                          onChange={this.handleDate(
                            "originalMailDate",
                            "letterUploadVO"
                          )}
                          maxLength="10"
                          label="Orginal Mail Date"
                          value={this.state.letterUploadVO.originalMailDate}
                          margin="normal"
                        />
                        <div className={classes.validationMessageSelect} />
                      </div>

                      <div>
                        <InputField
                          name="lastMailDate"
                          placeholder="MM/DD/YYYY"
                          onClick={() =>
                            this.handleDates("#lastMailDate", "letterUploadVO")
                          }
                          onChange={this.handleDate(
                            "lastMailDate",
                            "letterUploadVO"
                          )}
                          maxLength="10"
                          label="Last Mail Date"
                          value={this.state.letterUploadVO.lastMailDate}
                          margin="normal"
                        />
                        <div className={classes.validationMessageSelect} />
                      </div>
                    </div>
                    <div className={classes.container}>
                      <div className={classes.Margin}>
                        <InputField
                          name="datePrinted"
                          placeholder="MM/DD/YYYY"
                          onClick={() =>
                            this.handleDates("#datePrinted", "letterUploadVO")
                          }
                          onChange={this.handleDate(
                            "datePrinted",
                            "letterUploadVO"
                          )}
                          maxLength="10"
                          label="Date Printed"
                          width="180px"
                          value={this.state.letterUploadVO.datePrinted}
                          margin="normal"
                        />
                        <div className={classes.validationMessageSelect} />
                      </div>
                      <div>
                        <InputField
                          name="reprintDate"
                          placeholder="MM/DD/YYYY"
                          onClick={() =>
                            this.handleDates("#reprintDate", "letterUploadVO")
                          }
                          onChange={this.handleDate(
                            "reprintDate",
                            "letterUploadVO"
                          )}
                          maxLength="10"
                          label="Reprint Date"
                          value={this.state.letterUploadVO.reprintDate}
                          margin="normal"
                        />
                        <div className={classes.validationMessageSelect} />
                      </div>

                      <div>
                        <InputField
                          name="responseDueDate"
                          placeholder="MM/DD/YYYY"
                          onClick={() =>
                            this.handleDates(
                              "#responseDueDate",
                              "letterUploadVO"
                            )
                          }
                          onChange={this.handleDate(
                            "responseDueDate",
                            "letterUploadVO"
                          )}
                          maxLength="10"
                          label="Response Due Date"
                          value={this.state.letterUploadVO.responseDueDate}
                          margin="normal"
                        />
                        <div className={classes.validationMessageSelect} />
                      </div>
                      <div>
                        <InputField
                          name="responseDate"
                          placeholder="MM/DD/YYYY"
                          onClick={() =>
                            this.handleDates("#responseDate", "letterUploadVO")
                          }
                          onChange={this.handleDate(
                            "responseDate",
                            "letterUploadVO"
                          )}
                          maxLength="10"
                          label="Response Date"
                          value={this.state.letterUploadVO.responseDate}
                          margin="normal"
                        />
                        <div className={classes.validationMessageSelect} />
                      </div>
                      <div>
                        {servicesEnabled.includes("EEUA") ? (
                          <ImageUploader
                            buttonClassName="form-upload-proof-btn"
                            withIcon={false}
                            buttonText="Upload"
                            onChange={this.uploadProof}
                            imgExtension={[".pdf"]}
                            maxFileSize={5242880}
                            label=""
                          />
                        ) : null}

                        <button type="submit" hidden="hidden"></button>
                      </div>
                    </div>
                  </div>
                </form>
              </ExpansionPanel>
            </div>
          </form>
        </Paper>
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    letterCoverDetailsData: state.letterReview.lstLetterDetailsCover,
    servicesEnabled: state.loginData.servicesEnabled,
    loginProfile: state.loginData.profiles,
  };
};
const mapDispatchToProps = {
  letteUpload,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(LetterUpload));
