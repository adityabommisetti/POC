import React, { Component } from "react";
import AutoComplete1 from "../UI/Select";
import {
  letterQCDescriptionList,
  letterQCSearch,
  letterQCSearchBatchId,
  qcReset,
  resetCkeckedList,
} from "../../redux/actions/LetterReviewAction";
import * as DateUtil from "../../utils/DatePicker";
import Button from "@material-ui/core/Button";
import DataTable from "../Home/DataTable";
import ExpansionPanel from "../UI/ExpansionPanel";
import InputField from "../UI/InputField";
import Paper from "@material-ui/core/Paper";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../assets/styles/Theme";
import { connect } from "react-redux";
import { handleDateChange } from "../../utils/DateFormatter";
import { LETTER_QC_TABLE_HEADER as header } from "../../constants/Headers/LetterHeaders";
import { withStyles } from "@material-ui/core/styles";
const width = {
  width: "215px",
};
var page1 = 0;
let dateChk = {};
const INITIAL_STATE = {
  searchReqFormDate: "",
  searchReqToDate: "",
  searchBatchId: "",
  serachPrimaryId: "",
  searchDescription: "",

  fileBatchId: "",
  source: "",
  primaryId: "",
  reqDate: "",
  letterName: "",
  status: "",
  pdfView: "",
};

const buttonmargin = {
  marginTop: "22px",
  marginLeft: "17px",
};

class LetterQC extends Component {
  state = {
    letterQcVO: { ...INITIAL_STATE },
    data: null,
    modified: false,
    editable: false,
    selectedIndex: 0,
    page: 0,
    displaydata: false,
    rowsPerPage: 10,
  };

  constructor(props) {
    super(props);
    this.validator = new SimpleReactValidator();
  }

  handlechange = (name) => (event) => {
    let value = event.target.value;
    this.setState((prevState) => ({
      letterQcVO: {
        ...prevState.letterQcVO,
        [name]: value,
      },
      modified: true,
    }));
  };
  changePage = (page) => {
    this.setState({ page: page, selectedIndex: page * 10 });
    page1 = this.state.page;
  };
  selectRow = (index) => {
    this.setState({ selectedIndex: index });
    page1 = this.state.page;
  };

  componentDidUpdate() {
    if (this.state.page !== page1) {
      var items = document.getElementsByName("acs");
      for (var i = 0; i < items.length; i++) {
        if (items[i].type === "checkbox") items[i].checked = false;
      }
      var index = 0;
      for (index; index < this.props.qcData.length; index++) {
        this.props.qcCheckedList.map((data) => {
          if (
            data.letterName.concat(data.primaryId, data.filebatchid) ===
            this.props.qcData[index].letterName.concat(
              this.props.qcData[index].primaryId,
              this.props.qcData[index].filebatchid
            )
          ) {
            const id = data.letterName.concat(data.primaryId, data.filebatchid);
            if (document.getElementById(id)) {
              return (document.getElementById(id).checked = true);
            }
          }
          return null;
        });
      }
    }
  }

  handleChangeSearchSelectAuto = (data, name) => {
    this.setState((prevState) => ({
      letterQcVO: {
        ...prevState.letterQcVO,
        [name]: data ? data.value : '',
      },
      modified: true,
    }));
    if (name === "searchBatchId" && data && data.value !== "") {
      this.props.letterQCDescriptionList(data.value);
      this.setState((prevState) => ({
        letterQcVO: {
          ...prevState.letterQcVO,
          searchDescription: "",
        },
        modified: true,
      }));
    }
  }

  handleChangeRowsPerPage = (rowsPerPage) => {
    this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  handleDates = (fieldId, targetVo) => (event) => {
    var self = this;
    setTimeout(() => {
      DateUtil.getDatePicker(fieldId)
        .datepicker("show")
        .on("change", (e) => {
          if (
            dateChk.name !== e.target.name ||
            dateChk.value !== e.target.value
          ) {
            self.setDate(e.target.name, e.target.value, targetVo);
            document.getElementById(fieldId.substr(1)).focus();
            if (
              this.state.letterQcVO.searchReqFormDate &&
              this.state.letterQcVO.searchReqToDate
            ) {
              const params = {
                searchReqFromDateFrmt: this.state.letterQcVO.searchReqFormDate,
                searchReqToDateFrmt: this.state.letterQcVO.searchReqToDate,
              };

              this.props.letterQCSearchBatchId(params);
            }
          }
          dateChk.name = e.target.name;
          dateChk.value = e.target.value;
        });
    }, 0);
  };

  setDate = (name, value) => {
    this.setState((prevState) => ({
      letterQcVO: {
        ...prevState.letterQcVO,
        [name]: value,
      },
      modified: true,
    }));
  };

  reset = () => {
    this.validator.hideMessages();
    this.props.qcReset();
    this.setState({
      letterQcVO: {
        ...INITIAL_STATE,
      },
    });
  };

  statusType = (status) => {
    if (this.props.qcCheckedList.length > 0) {
      const params = {
        letterReviewSearch: {
          searchReqFromDateFrmt: this.state.letterQcVO.searchReqFormDate,
          searchReqToDateFrmt: this.state.letterQcVO.searchReqToDate,
          searchBatchId: this.state.letterQcVO.searchBatchId,
          searchLetterName: this.state.letterQcVO.searchDescription,
          ltrStatus: status,
        },
        lstLetterVO: this.props.qcCheckedList,
      };
      this.props.letterQCSearch(params);
      this.props.resetCkeckedList();
      var items = document.getElementsByName("acs");
      for (var i = 0; i < items.length; i++) {
        if (items[i].type === "checkbox") items[i].checked = false;
      }
    }
  };

  handleChangePage = (index) => {
    this.selectRow(index)
  };

  handleDate = (name, targetVo) => (event) => {
    let value = event.target.value;
    this.setState((prevState) => ({
      letterQcVO: {
        ...prevState.letterQcVO,
        [name]: handleDateChange(value),
      },
      modified: true,
    }));
  };

  handleChangeSearchSelect = (name) => (event) => {
    let value = event.value;
    this.setState((prevState) => ({
      letterQcVO: {
        ...prevState.letterQcVO,
        [name]: value,
      },
      modified: true,
    }));
    if (name === "searchBatchId" && value !== "") {
      this.props.letterQCDescriptionList(value);
      this.setState((prevState) => ({
        letterQcVO: {
          ...prevState.letterQcVO,
          searchDescription: "",
        },
        modified: true,
      }));
    }
  };

  LetterQcSearch = (event) => {
    event.preventDefault();
    const params = {
      letterReviewSearch: {
        searchReqFromDateFrmt: this.state.letterQcVO.searchReqFormDate,
        searchReqToDateFrmt: this.state.letterQcVO.searchReqToDate,
        searchBatchId: this.state.letterQcVO.searchBatchId,
        searchLetterName: this.state.letterQcVO.searchDescription,
        ltrStatus: "EXTRACTED",
      },
      lstLetterVO: [],
    };

    if (this.validator.allValid()) {
      this.props.letterQCSearch(params);
      this.props.resetCkeckedList();
      var items = document.getElementsByName("acs");
      for (var i = 0; i < items.length; i++) {
        if (items[i].type === "checkbox") items[i].checked = false;
      }
      this.setState({
        displaydata: true,
      });
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  componentWillUnmount() {
    this.props.qcReset();
  }
  render() {
    const { classes, loading } = this.props;
    const { letterQcVO } = this.state;
    return (
      <Paper elevation={0} className={classes.card}>
        {loading && <div id="cover-spin" />}

        <form autoComplete="off">
          <div class="search-panel">
            <ExpansionPanel
              summary="Search Results"
              defaultCollapsed={this.state.collapseTableSearch}
            >
              <form onSubmit={this.LetterQcSearch}>
                <div id="db">
                  <div className={classes.containertypography}>
                    <div className={classes.space3}>
                      <div style={width}>
                        <InputField
                          name="searchReqFormDate"
                          placeholder="MM/DD/YYYY"
                          onClick={this.handleDates(
                            "#searchReqFormDate",
                            "letterQcVO"
                          )}
                          onChange={this.handleDate(
                            "searchReqFormDate",
                            "letterQcVO"
                          )}
                          label="Request Date From"
                          required={this.state.editable}
                          value={letterQcVO.searchReqFormDate}
                          width={classes.dateColum}
                          maxLength="10"
                        />
                      </div>
                      <div
                        style={{ marginLeft: "0px" }}
                        className={classes.validationMessageSelect}
                      >
                        {this.validator.message(
                          "Request date",
                          letterQcVO.searchReqFormDate,
                          "required"
                        )}
                      </div>
                    </div>
                    <div className={classes.space3}>
                      <div style={width}>
                        <InputField
                          name="searchReqToDate"
                          placeholder="MM/DD/YYYY"
                          onClick={this.handleDates(
                            "#searchReqToDate",
                            "letterQcVO"
                          )}
                          onChange={this.handleDate(
                            "searchReqToDate",
                            "letterQcVO"
                          )}
                          label="To"
                          maxLength="10"
                          required
                          value={letterQcVO.searchReqToDate}
                          width={classes.dateColum}
                        />
                      </div>
                      <div
                        style={{ marginLeft: "0px" }}
                        className={classes.validationMessageSelect}
                      >
                        {this.validator.message(
                          "To date",
                          letterQcVO.searchReqToDate,
                          "required"
                        )}
                      </div>
                    </div>

                    <div className={classes.space3}>
                      <div style={width}>
                        <AutoComplete1
                          options={this.props.batchIdData}
                          handleChange={this.handleChangeSearchSelectAuto}
                          defaultValue={this.props.batchIdData[0]}
                          value={letterQcVO.searchBatchId ? this.props.batchIdData.filter(data => data.value === letterQcVO.searchBatchId) : this.props.batchIdData[0]}
                          label='Batch ID'
                          name='searchBatchId'
                          margin='0px'
                          fontSize="0.718em"
                        />

                        <div className={classes.validationMessageSelect}>
                        </div>
                      </div>
                    </div>
                    <div className={classes.containerdemo2}>
                      <div style={{ marginTop: "1em" }}>
                        <AutoComplete1
                          options={this.props.qcDescription}
                          handleChange={this.handleChangeSearchSelectAuto}
                          defaultValue={this.props.qcDescription[0]}
                          value={letterQcVO.searchDescription ? this.props.qcDescription.filter(data => data.value === letterQcVO.searchDescription) : this.props.qcDescription[0]}
                          label='Description'
                          name='searchDescription'
                          width="600px"
                          margin='0px'
                          fontSize="0.718em"
                        />
                        <div className={classes.validationMessageSelect} />
                      </div>
                    </div>
                    <span
                      class="button-container-search"
                      style={{ float: "right" }}
                    >
                      <button
                        style={buttonmargin}
                        type="submit"
                        class="btn btn-primary icon-search"
                      >
                        Search
                      </button>

                      <button
                        style={buttonmargin}
                        type="button"
                        class="btn btn-secondary"
                        onClick={this.reset}
                      >
                        New search
                      </button>
                    </span>
                  </div>
                </div>
              </form>
            </ExpansionPanel>
          </div>
        </form>
        <div>
          {this.state.displaydata ? (
            <>
              {this.props.qcData.length > 0 ? (
                <div>
                  <div className={this.props.classes.buttonContainer}>
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => {
                        this.statusType("APPROVED");
                      }}
                      className={this.props.classes.button}
                      id="Approved"
                      disabled={
                        this.props.qcData[0].recordStatus !== "EXTRACTED"
                          ? true
                          : false
                      }
                    >
                      Approved
                    </Button>

                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => {
                        this.statusType("REJECTED");
                      }}
                      className={this.props.classes.button}
                      id="Rejected"
                      disabled={
                        this.props.qcData[0].recordStatus !== "EXTRACTED"
                          ? true
                          : false
                      }
                    >
                      Rejected
                    </Button>

                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => {
                        this.statusType("HOLD");
                      }}
                      className={this.props.classes.button}
                      id="hold"
                      disabled={
                        this.props.qcData[0].recordStatus !== "EXTRACTED"
                          ? true
                          : false
                      }
                    >
                      Hold
                    </Button>
                  </div>
                  <div class="search-panel">
                    <ExpansionPanel
                      summary="Search Results"
                      defaultCollapsed={this.state.collapseTableSearch}
                    >
                      <DataTable
                        data={this.props.qcData}
                        header={header}
                        sortableHeader={true}
                        index={this.state.selectedIndex}
                        clickedFooter={this.changePage}
                        clicked={this.selectRow}
                        sortable={true}
                        rowsPerPageOptions={[10, 15, 20]}
                        searchable={true}
                        exportAsExcel={true}
                        handleChangeRowsPerPage={this.handleChangeRowsPerPage}
                        rowsPerPage={
                          this.props.qcData.length < this.state.rowsPerPage
                            ? this.props.qcData.length
                            : this.state.rowsPerPage
                        }
                        handleChangePage={this.handleChangePage}
                      />
                    </ExpansionPanel>
                  </div>
                </div>
              ) : (
                  <DataTable
                    data={[]}
                    header={header}
                    sortableHeader={true}
                    index={this.state.selectedIndex}
                  />
                )}
            </>
          ) : null}
        </div>
      </Paper>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    batchIdData: state.letterReview.batchIdList,
    qcData: state.letterReview.qcSearchList,
    qcDescription: state.letterReview.qcDescription,
    qcCheckedList: state.letterReview.qcCheckedList,
  };
};
const mapDispatchToProps = {
  letterQCSearchBatchId,
  letterQCDescriptionList,
  letterQCSearch,
  resetCkeckedList,
  qcReset,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(LetterQC));
