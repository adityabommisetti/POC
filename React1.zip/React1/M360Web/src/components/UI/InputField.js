import React from "react";

const InputField = React.memo((props) => {
  var astrix = "";
  if (props.required) {
    astrix = <span class="imp">*</span>;
  }
  return (
    <span className="label-container"
      style={{ fontSize: props.fontSize ? props.fontSize : "0.875rem", textAlign: "left" }}>
      <label
        htmlFor={props.details}
        style={{
          color: props.color ? props.color : "#053674",
          marginBottom: "0",
          paddingLeft: "3px",
          lineHeight: props.lineHeight ? props.lineHeight : "normal",
          display: props.display === "inline" ? "inline" : "inline-block",
        }}
      >
        {props.label}
        {astrix}
      </label>
      <br />
      <input
        name={props.name}
        id={props.id ? props.id : props.name}
        className="form-field"
        type={props.type ? props.type : "text"}
        value={props.value ? props.value : ""}
        cols={props.cols ? props.cols : null}
        rows={props.rows ? props.rows : null}
        rowsmax={props.rowsMax ? props.rowsMax : null}
        onChange={props.onChange}
        onClick={props.onClick ? props.onClick : null}
        disabled={props.disabled}
        maxLength={
          props.name && props.name.endsWith("Frmt")
            ? 10
            : props.maxLength
              ? props.maxLength
              : null
        }
        minLength={props.minlength ? props.minlength : null}
        style={{
          minWidth: props.minWidth ? props.minWidth : null,
          width: props.width ? props.width : "155px",
          backgroundColor: props.isErrorField ? "yellow" : null,
        }}
        required={props.req}
        placeholder={props.placeholder ? props.placeholder : null}
        onBlur={props.onBlur ? props.onBlur : null}
      />
    </span >
  );
});

export default InputField;
