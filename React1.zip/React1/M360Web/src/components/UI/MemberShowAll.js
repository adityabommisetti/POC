import React from "react"
import Button from "@material-ui/core/Button";


 const MbrShowAll =(props)=>{
    return (
        <div style={{float:"right"}}>
            <Button
          variant="contained"
          color="primary"
          onClick={props.showAll}
          className={props.classes.button}
          id="showAllButton"
        >
          {props.toggleLabel ? "Show All" : "Show Active"}
        </Button>
        </div>
    )
}
export default MbrShowAll