import Button from "@material-ui/core/Button";
import Fade from "@material-ui/core/Fade";
import React from "react";
import { withStyles } from "@material-ui/core/styles";
import formatTimeStamp,{formatFullTimeStamp} from "../../utils/Utils";

const styles = (theme) => ({
  addBtnContainer: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    marginTop: "10px",
  },

  button: {
    margin: theme.spacing.unit,
    [theme.breakpoints.down("sm")]: {
      fontSize: "8px",
      width: "80px",
    },
  },
});

const HistoryData = React.memo((props) => {
  var createTime = null;
  var createUserId = null;
  var lastUpdtTime = null;
  var lastUpdtUserId = null;
  var milliSec = false;

  if (props.isNewSegment) {
    return (
      <Fade in={props.isNewSegment}>
        <div className={props.classes.addBtnContainer}>
          <Button
            variant="contained"
            color="primary"
            onClick={props.reset}
            className={props.classes.button}
          >
            Reset
          </Button>
          <Button
            variant="contained"
            color="primary"
            onClick={props.addSegment}
            className={props.classes.button}
          >
            Add
          </Button>
          {!props.disableBack ? (
            <Button
              variant="contained"
              color="primary"
              onClick={props.back}
              className={props.classes.button}
            >
              Back
            </Button>
          ) : null}
        </div>
      </Fade>
    );
  } else {
    createTime = props.createTime;
    createUserId = props.createUserId;
    lastUpdtTime = props.lastUpdtTime;
    lastUpdtUserId = props.lastUpdtUserId;
    milliSec = props.milliSec;
  }

  return (
    <React.Fragment>
      {!props.isNewSegment ? (
        <div class="member-info-block">
          <ul>
            {createTime ? (
              <li>
                <span>Create Time:</span>
                <span>{milliSec?formatFullTimeStamp(createTime):formatTimeStamp(createTime)}</span>
              </li>
            ) : null}
            {createUserId ? (
              <li>
                <span>Create User:</span>
                <span>{createUserId} </span>
              </li>
            ) : null}
            {lastUpdtTime ? (
              <li>
                <span>Modified Time:</span>
                <span>{milliSec?formatFullTimeStamp(lastUpdtTime):formatTimeStamp(lastUpdtTime)}</span>
              </li>
            ) : null}
            {lastUpdtUserId ? (
              <li>
                <span>Modified User:</span>
                <span>{lastUpdtUserId}</span>
              </li>
            ) : null}
          </ul>
        </div>
      ) : null}
    </React.Fragment>
  );
});

export default withStyles(styles, { withTheme: true })(HistoryData);
