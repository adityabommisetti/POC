import MenuItem from "@material-ui/core/MenuItem";
import Paper from "@material-ui/core/Paper";
import React, { Component } from "react";
import ReactSelect from "react-select";
import TextField from "@material-ui/core/TextField";
import Tooltip from '@material-ui/core/Tooltip';
import { withStyles } from '@material-ui/core/styles';
import { Autocomplete } from '@material-ui/lab';
import $ from "jquery";

const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: theme.palette.common.white,
    color: 'rgba(0, 0, 0, 0.87)',
    boxShadow: theme.shadows[1],
    fontSize: 11,
    padding: 0,
    maxWidth: 585,
    marginTop: "0px",
    float: "left",
    // display:"flex"
  },
}))(Tooltip);


//export const AutoComplete1 = React.memo((props) => {
export default class AutoComplete1 extends Component {


  constructor(props) {
    super(props);
    this.state = {
      tooltip: this.props.value
    }
  }
  static getDerivedStateFromProps(nextProps, prevState) {
    if(nextProps.isErrorField){
      $( "#"+nextProps.name ).parent().css( 'background-color','yellow' );
    }else{
      $( "#"+nextProps.name ).parent().css( 'background-color','' );
    }
    
    if (prevState.tooltip && (nextProps.value !== prevState.tooltip.value)) {
      return {
        tooltip: nextProps.value
      }
    }
  }
  render() {
    $("#" + this.props.name).parent().css("margin-left", this.props.margin ? this.props.margin : "19px");
    // $( "#tool").parent().css( "margin-left", "19px" );
    return (
      <React.Fragment>
        {this.props.label ? (<div style={{
          color: 'rgb(5, 54, 116)',
          marginBottom: '0px',
          marginTop: '0.23rem',
          lineHeight: 'inherit',
          fontWeight: '600',
          paddingLeft: "3px",
          fontSize: this.props.fontSize ? this.props.fontSize : '0.8em',
          // display:'flex',
          marginLeft: this.props.margin ? this.props.margin : "19px",
          // marginBottom: '0.4em !important'
        }} >{this.props.label}</div>) : null}


        <LightTooltip
          id='tool'
          title={this.state.tooltip ? this.state.tooltip.label : ''}>
          <Autocomplete
            ListboxProps={{ style: { maxHeight: '15rem' } }}
            id={this.props.name}
            size="small"
            defaultValue={this.props.defaultValue}
            disabled={this.props.disabled}
            name={this.props.name}
            options={this.props.options}
            getOptionLabel={(option) => option.label} //  width= '180px'
            style={{ width: this.props.width ? this.props.width : '180px', marginTop: this.props.marginTop ? this.props.marginTop : '0px', marginLeft: this.props.marginLeft, paddingLeft: this.props.paddingLeft? this.props.paddingLeft: null }}
            value={this.state.tooltip ? this.state.tooltip : this.props.defaultValue}
            onChange={(event, newValue) => {
              if (newValue === null) {
                return
              }
              this.setState({ tooltip: newValue })
              this.props.handleChange(newValue, this.props.name, this.props.vo);
            }}
            renderInput={(params) => <TextField {...params} variant="outlined" />}
          />
        </LightTooltip >
      </React.Fragment>
    );
  }
}
export const Select = React.memo((props) => {
  var labelData = props.textFieldProps;

  return (
    <div className="label-container">
      <ReactSelect
        label={props.label}
        className={props.className}
        value={props.propertyName || " "}
        onChange={props.handleChange}
        components={props.components}
        options={props.options}
        margin="normal"
        classes={props.classes}
        isDisabled={props.isDisabled}
        onBlur={props.onBlur ? props.onBlur : null}
        textFieldProps={labelData}
        width={props.width}
      />
    </div>
  );
});

function inputComponent({ inputRef, ...props }) {
  return (
    <div style={{ width: props.widthContainer }} ref={inputRef} {...props} />
  );
}

const Control = (props) => {
  return (
    <TextField
      style={{
        width: props.selectProps.width ? props.selectProps.width : "170px",
      }}
      id={props.id}
      InputProps={{
        inputComponent,
        inputProps: {
          className: props.selectProps.classes.input,
          style: {
            fontSize: "12px",
            backgroundColor: props.selectProps.textFieldProps.isErrorField
              ? "yellow"
              : props.isDisabled
                ? "#ebebe4"
                : "white",
          },
          inputRef: props.innerRef,
          widthcontainer: props.selectProps.width
            ? props.selectProps.width
            : "180px",
          children: props.children,
          ...props.innerProps,
        },
      }}
      {...props.selectProps.textFieldProps}
    />
  );
};

const Option = (props) => {
  return (
    <MenuItem
      style={{ fontSize: "11px", padding: "0px 10px" }}
      selected={props.isFocused}
      component="span"
      {...props.innerProps}
    >
      {props.children}
    </MenuItem>
  );
};

const Menu = (props) => {
  return (
    <Paper
      square
      style={{
        fontSize: "small",
        borderRadius: 5,
        maxHeight: 180,
        scrollBehavior: "smooth",
        overflow: "auto",
        marginTop: "0px",
        width: props.selectProps.width ? props.selectProps.width : "170px",
      }}
      className={props.selectProps.classes.paper}
      {...props.innerProps}
    >
      {props.children}
    </Paper>
  );
};

const ValueContainer = (props) => {
  return (
    <div
      className={props.selectProps.classes.valueContainer}
      style={{
        backgroundColor: props.selectProps.textFieldProps.isErrorField
          ? "yellow"
          : props.isDisabled
            ? "#ebebe4"
            : "white",
      }}
    >
      {props.children}
    </div>
  );
};

export const components = {
  Control,
  Menu,
  ValueContainer,
  Option,
};
