import * as DateUtil from '../../utils/DatePicker';

import React, { Component } from "react";

import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Typography from "@material-ui/core/Typography";
import moment from "moment";
import { styles } from "../../assets/styles/DataTableStyle";
import { withStyles } from "@material-ui/core/styles";

class DataTableAttestCall extends Component {
  handlechange = event => {
    let value = event.target.value;
    let id = event.target.name;
    this.props.setValue(id, value, this.props.tableType);
  };
  handleDate = () => {
    let fieldId = "#" + this.props.tableType + "date";
    DateUtil.getDatePicker(fieldId).datepicker("show")
      .on("change", e => {
        this.props.setValue(
          e.target.name,
          e.target.value,
          this.props.tableType
        );
      });
  };

  handleDateChange = event => {
    let value = event.target.value;
    let name = event.target.name;
    value = value.replace(/[^0-9]/g, "").trim();
    if (value.length === 8) {
      value = value.replace(/^(\d{2})/, "$1/");
      value = value.replace(/\/(\d{2})/, "/$1/");
      value = value.replace(/(\d)\/(\d{4}).*/, "$1/$2");
    }
    this.props.setValue(name, value, this.props.tableType);
  };

  render() {
    const { classes, data, tableType, newRow, vo } = this.props;

    const displayList = data.map((data, index) => (
      <TableRow>
        <TableCell className={classes.tableCellHeader}>
          {index + 1} Attempt
        </TableCell>
        <TableCell className={classes.tableCell}>{data.date}</TableCell>
        <TableCell className={classes.tableCell}>{data.status}</TableCell>
        <TableCell className={classes.tableCell}>{data.userId}</TableCell>
        <TableCell className={classes.tableCell}>{data.createTime}</TableCell>
      </TableRow>
    ));
    const newRowDisplay = newRow ? (
      <TableRow className={classes.row}>
        <TableCell className={classes.tableCellHeader}>
          {data.length + 1} Attempt
        </TableCell>
        <TableCell className={classes.tableCell}>
          <div class="form-group">
            <input
              name="date"
              placeholder= "MM/DD/YYYY"
              id={tableType + "date"}
              type="text"
              class="lepInput"
              onChange={this.handleDateChange}
              onClick={this.handleDate}
              value={vo.date}
            />
            <div className={classes.validationMessage}>
              {this.props.validator.message("Date", vo.date, [
                "required",
                "date_format",
                {
                  date_before: moment().format("MM/DD/YYYY"),
                  not_before_30_days: moment().subtract(30, "days")
                }
              ])}
            </div>
          </div>
        </TableCell>

        <TableCell className={classes.tableCell}>
          <div>
            <select
              class="lepSelect"
              id="status"
              name="status"
              onChange={this.handlechange}
              value={vo.status}
            >
              <option value="">Select</option>
              <option value="M">Missing</option>
              <option value="I">Incomplete</option>
              <option value="C">Complete</option>
            </select>
            <div className={classes.validationMessage}>
              {this.props.validator.message("status", vo.status, "required")}
            </div>
          </div>
        </TableCell>

        <TableCell className={classes.tableCell}></TableCell>
        <TableCell className={classes.tableCell}></TableCell>
      </TableRow>
    ) : null;

    return (
      <React.Fragment>
        <div style={{ width: "100%", textAlign: "center" }}>
          <div style={{ display: "inline" }}>
            <Typography
              variant="h6"
              id="tableTitle"
              className={classes.attestation1}
            >
              {this.props.header}
            </Typography>
          </div>

          <div
            className={classes.tableWrapper}
            style={{
              width: this.props.width ? this.props.width : "50%",
              display: "inline-block"
            }}
          >
            <Table className={classes.tableModified}>
              <TableHead className={classes.thead}>
                <TableRow className={classes.headRow}>
                  <TableCell className={classes.headerCell}></TableCell>
                  <TableCell className={classes.headerCell}>Date</TableCell>
                  <TableCell className={classes.headerCell}>Status</TableCell>
                  <TableCell className={classes.headerCell}>User ID</TableCell>
                  <TableCell className={classes.headerCell}>
                    Date/Timestamp
                  </TableCell>
                </TableRow>
              </TableHead>

              <TableBody className={classes.tbody}>
                {displayList}
                {newRowDisplay}
              </TableBody>
            </Table>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

export default withStyles(styles)(DataTableAttestCall);
