import React from "react";
import { withStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import { RDS_TABLE_HEADER as header2 } from "../../constants/Headers/MemberHeaders";
import { PARTD_TABLE_HEADER as header3 } from "../../constants/Headers/MemberHeaders";
import { UNCOVEREDMONTHS_TABLE_HEADER as header4 } from "../../constants/Headers/MemberHeaders";
import DataTable from "../Home/DataTable";
import EligInfoTable from "./EligInfoTable";
import LisTable from "./LISInfoTable";
import EnrollInfoTable from "./EnrollInfoTable";
import classNames from "classnames";
import Typography from "@material-ui/core/Typography";
import { Styles } from "../../assets/styles/Theme";

const styles = (theme) => ({
  ...Styles(theme),
  content: {
    overflow: "auto",
    //width: '600px'
  },

  childContent: {
    width: "33%",
    // margin: "5px",
    padding: "1em",
    background: "white",
  },
  left: {
    float: "left",
  },
  right: {
    float: "right",
  },
  tableHeadings: {
    color: "rgba(39, 108, 155, 1)",
    //paddingTop:'30px',
    textAlign: "center",
    fontSize: "17px",
  },
  uncMnthsTable: {
    width: "66%",
    padding: "1em",
    background: "white",
  },
});
const Summary = (props) => {
  const {
    classes,
    data,
    nunCMOList,
    rdsList,
    partDList,
    showEnrollInfo,
  } = props;

  return (
    <Paper elevation={0} className={classes.card}>
      <div>
        <div>
          <Typography
            variant="h6"
            id="tableTitle"
            className={classes.tableHeadings}
          >
            Eligibility Information
          </Typography>
          <EligInfoTable classes={classes} data={data} width="97%" />
        </div>

        <div className={classes.content}>
          <div className={classNames(classes.childContent, classes.left)}>
            <Typography
              variant="h6"
              id="tableTitle"
              className={classes.tableHeadings}
            >
              RDS History
            </Typography>
            <DataTable
              data={rdsList}
              header={header2}
              rowsPerPage={5}
              notClickable
              index={0}
              sortable={true}
              rowsPerPageOptions={[5, 10, 15, 20]}
              subtab
            />
          </div>

          <div className={classNames(classes.childContent, classes.right)}>
            <Typography
              variant="h6"
              id="tableTitle"
              className={classes.tableHeadings}
            >
              Part D History
            </Typography>
            <DataTable
              data={partDList}
              header={header3}
              rowsPerPage={5}
              notClickable
              index={0}
              sortable={true}
              rowsPerPageOptions={[5, 10, 15, 20]}
              subtab
            />
          </div>
          <div className={classNames(classes.childContent, classes.left)}>
            <Typography
              variant="h6"
              id="tableTitle"
              className={classes.tableHeadings}
            >
              Low Income Subsidy
            </Typography>
            <LisTable data={data} />
          </div>
        </div>

        <div className={classes.content}>
          <div className={classNames(classes.uncMnthsTable, classes.left)}>
            <Typography
              variant="h6"
              id="tableTitle"
              className={classes.tableHeadings}
            >
              Number of Uncovered Months
            </Typography>
            <DataTable
              data={nunCMOList}
              notClickable
              index={0}
              header={header4}
              rowsPerPage={5}
              sortable={true}
              rowsPerPageOptions={[5, 10, 15, 20]}
              subtab
            />
          </div>
          {showEnrollInfo ? (
            <div className={classNames(classes.childContent, classes.right)}>
              <Typography
                variant="h6"
                id="tableTitle"
                className={classes.tableHeadings}
              >
                Enroll Information
              </Typography>
              <EnrollInfoTable data={data} />
            </div>
          ) : null}
        </div>
      </div>
    </Paper>
  );
};

export default withStyles(styles)(Summary);
