import React, { Component } from "react";
import { withStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import { styles } from "../../assets/styles/DataTableStyle";

class DataTable extends Component {
  render() {
    const { classes, data } = this.props;

    return (
      <div style={{ width: "100%", textAlign: "center" }}>
        <div
          className={classes.tableWrapper}
          style={{ width: this.props.width ? this.props.width : "100%" }}
        >
          <Table className={classes.tableModified}>
            <TableHead className={classes.thead}>
              <TableRow className={classes.headRow}>
                <TableCell align="center" className={classes.headerCell}>
                  Medicare Id
                </TableCell>
                <TableCell align="center" className={classes.headerCell}>
                  Birth Date
                </TableCell>
                <TableCell align="center" className={classes.headerCell}>
                  65th Birth Date
                </TableCell>
              </TableRow>
            </TableHead>

            <TableBody className={classes.tbody}>
              {Object.keys(data).length > 0 ? (
                <TableRow className={classes.row}>
                  <TableCell className={classes.lepSummaryTableCell}>
                    {data.hicNBRVal}
                  </TableCell>
                  <TableCell className={classes.lepSummaryTableCell}>
                    {data.mbrBirthDt}
                  </TableCell>
                  <TableCell className={classes.lepSummaryTableCell}>
                    {data.mbr65BirthDt}
                  </TableCell>
                </TableRow>
              ) : (
                <TableRow>
                  <TableCell
                    className={classes.lepSummaryTableCell}
                    colSpan={3}
                  >
                    NO DATA FOUND
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    );
  }
}

export default withStyles(styles)(DataTable);
