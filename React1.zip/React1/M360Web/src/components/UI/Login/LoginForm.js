import React from "react";

const LoginForm =  React.memo((props) => {

    return (
        <div className="container padding-tb-1 loginTop">
            <div className="logo-container">
                <img src='/images/wipro-logo.png' alt='wipro logo' />
            </div>
            <div className="login-section">

                <h4 className="login-heading">Customer Login</h4>
                <span className='imp'>{props.errorMsg}</span>
                <form>
                    <div className="login-fields">

                        <input type="text" name="userName" placeholder="Username"
                            value={props.userName} onChange={props.handleChange}
                            className="form-control username" />
                        <input type="password" id="pass" name="pass" placeholder="Password"
                            value={props.pass} onChange={props.handleChange}
                            className="form-control password" />
                        <button type="submit" id="loginBtn" className="btn btn-primary btn-login"
                            disabled={!(props.pass && props.userName)}
                            onClick={props.loginHandler}
                        >Login</button>
                    </div>
                </form>

                <p className="forgot-password small">
                    Forgot your <a className="link" href="/#forgetPwd">password</a>?
					</p>

            </div>
        </div>
    );
});

export default LoginForm;
