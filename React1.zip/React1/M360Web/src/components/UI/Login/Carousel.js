import React from "react";

const Carousel = React.memo(() => {

    return (
        <div className="container padding-zero">

            <div >

                <div className="carousel-inner">
                    <ul id="carousel-gallery" className="gallery list-unstyled cS-hidden">
                        <li data-thumb="<div class='thumbnail imp-box imp-box1'><p>A&amp;G360</p></div>">
                            <img src='/images/AG.jpg' alt="A&amp;G360" />
                            <div className="carousel-caption">
                                <h3>A&amp;G360</h3>
                                <p>A Comprehensive Medicare Advantage Appeals and Grievances and Complaint Tracking Module</p>
                            </div>
                        </li>
                        <li data-thumb="<div class='thumbnail imp-box imp-box2'><p>Member360</p></div>">
                            <img src='/images/member360.jpg' alt="Member360" />
                            <div className="carousel-caption">
                                <h3>Member360</h3>
                                <p>A Comprehensive Medicare Advantage Membership Management System</p>
                            </div>
                        </li>
                        <li data-thumb="<div class='thumbnail imp-box imp-box3'><p>Revenue360</p></div>">
                            <img src='/images/revenue.jpg' alt="Revenue360" />
                            <div className="carousel-caption">
                                <h3>Revenue 360</h3>
                                <p>A Comprehensive Medicare Advantage Revenue Management System</p>
                            </div>
                        </li>
                        <li data-thumb="<div class='thumbnail imp-box imp-box4'><p>EDPS</p></div>">
                            <img src='/images/edps.jpg' alt="EDPS" />
                            <div className="carousel-caption">
                                <h3>EDPS</h3>
                                <p>A Comprehensive Medicare Advantage Encounter Data Processing System</p>
                            </div>
                        </li>
                        <li data-thumb="<div class='thumbnail imp-box imp-box5'><p>e-Enroll</p></div>">
                            <img src='/images/AG.jpg' alt="e-Enroll" /> e-Enroll
        </li>

                        <li data-thumb="<div class='thumbnail imp-box imp-box6'><p>E&amp;E</p></div>">
                            <img src='/images/member360.jpg' alt="E&amp;E" /> E&amp;E360
        </li>
                        <li data-thumb="<div class='thumbnail imp-box imp-box7'><p>Q/Care</p></div>">
                            <img src='/images/Revenue.jpg' alt="Q/Care" /> Q/Care
        </li>
                        <li data-thumb="<div class='thumbnail imp-box imp-box8'><p>HCC360</p></div>">
                            <img src='/images/edps.jpg' alt="EDPS" /> HCC360
        </li>

                    </ul>
                </div>

            </div>
        </div>
    );
});

export default Carousel;
