import React from "react";

const Information = React.memo(() => {

    return (

        <div className="jumbotron margin-top2 margin-bottom-zero">
            <div className="container panel-social-contact">
                <div className="row panel-social-contact-row1">
                    <div className="col-md-2">
                        <div className="logo-container">
                            <img src='/images/wipro-logo.png' alt='wipro logo' />
                        </div>
                    </div>
                    <div className="col-md-7">
                        <p>Wipro is a proven provider of IT services focused on managing mission-critical IT systems for a variety of enterprise customers across all industry segments. With investment in people, process and technology, Wipro is a pioneer in global data and infrastructure management.</p>
                    </div>
                    <div className="col-md-3">
                        <ul className="social">
                            <li><a href="https://plus.google.com/+wipro/posts" target="blank"><i className="icon-google"></i></a></li>
                            <li><a href="https://www.facebook.com/WiproTechnologies" target="blank"><i className="icon-facebook-squared"></i></a></li>
                            <li><a href="https://www.youtube.com/user/Wiprovideos" target="blank"><i className="icon-youtube-2"></i></a></li>
                            <li><a href="https://www.linkedin.com/company/wipro" target="blank"><i className="icon-linkedin-rect-1"></i></a></li>
                            <li><a href="https://twitter.com/wipro" target="blank"><i className="icon-twitter-1"></i></a></li>
                        </ul>
                    </div>
                </div>

                <div className="row panel-social-contact-row2">
                    <div className="col-md-8 panel-social-contact-row2-col1">
                        <h4>OUR CUSTOMERS</h4>
                        <div className="customer-logos">
                        </div>
                    </div>
                    <div className="col-md-4 panel-social-contact-row2-col2">
                        <h4>CUSTOMER SERVICE</h4>
                        <p><strong>Help Desk</strong>
                        </p>
                        <p><span className="oi" data-glyph="envelope-closed" title="email" aria-hidden="true"></span>  <a href="mailto:mcaresupport@wipro.com">mcaresupport@wipro.com</a>
                        </p>
                        <p><span className="oi" data-glyph="phone" title="phone" aria-hidden="true"></span> (877) 833-3499</p>
                        <p className="margin-top1"><strong>SALES</strong>
                        </p>
                        <p>Contact : James Stewart</p>
                        <p><span className="oi" data-glyph="envelope-closed" title="email" aria-hidden="true"></span>  <a href="mailto:james.stewart@wipro.com">james.stewart@wipro.com</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
});

export default Information;
