import { Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle } from '@material-ui/core';
import Button from "@material-ui/core/Button";
import React, { Component } from 'react';


class Modal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            toggle: props.show,
            check: false
        };
    }
    static getDerivedStateFromProps(props, state) {
        if (props.show) {
            return { toggle: true }
        }
     return null;
    }

    render() {
        return (
            <Dialog open={this.props.show && this.state.toggle}>
                <DialogTitle>{this.props.dialogTitle}</DialogTitle>

                <DialogContent>
                    <DialogContentText>
                        {this.props.message}
                    </DialogContentText>

                </DialogContent>

                <DialogActions>
                    <Button
                        variant="contained"
                        color="primary"
                        onClick={() => {
                            this.props.modalClosed();
                        }}
                    >
                        OK
                    </Button>
                </DialogActions>
            </Dialog>
        )
    }
}

export default Modal;