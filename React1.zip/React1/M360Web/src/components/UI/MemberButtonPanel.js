import React from "react";
import Fade from "@material-ui/core/Fade";
import Button from "@material-ui/core/Button";
import { withStyles } from "@material-ui/core/styles";
import { connect } from "react-redux";

const styles = (theme) => ({
  buttonContainer: {
    position: "relative",
    // display: 'inline-block',
    display: "contents",
    verticalAlign: "middle",
    float: "right",
  },
  button: {
    margin: theme.spacing.unit,
    [theme.breakpoints.down("sm")]: {
      fontSize: "8px",
      width: "80px",
    },
  },
});

const MemberButtonPanel = (props) => {
  if (props.isNewSegment) {
    return null;
  }

  return (
    <Fade in={!props.isNewSegment}>
      <div className={props.classes.buttonContainer}>
        {/* <Button
          variant="contained"
          color="primary"
          onClick={props.showAll}
          className={props.classes.button}
          id="showAllButton"
        >
          {props.toggleLabel ? "Show All" : "Show Active"}
        </Button>*/}

        <Button
          variant="contained"
          color="primary"
          onClick={props.newSegment}
          className={props.classes.button}
          disabled={props.supLep}
          id="NewButton"
        >
          New
        </Button>
        <Button
          variant="contained"
          color="primary"
          onClick={props.modelSegment}
          className={props.classes.button}
          disabled={props.disable || props.supLep}
          id="ModelButton"
        >
          Model Segment
        </Button>
        <Button
          variant="contained"
          color="primary"
          onClick={props.delete}
          className={props.classes.button}
          disabled={props.editable || props.disable}
          id="DeleteButton"
        >
          Delete
        </Button>
        {props.servicesEnabled.includes("EEUM") ? (
          <Button
            type="submit"
            variant="contained"
            color="primary"
            onClick={props.update}
            disabled={!props.modified || props.disable}
            className={props.classes.button}
            id="UpdateButton"
          >
            Update
          </Button>
        ) : null}
      </div>
    </Fade>
  );
};
const mapStateToProps = (state) => {
  return {
    servicesEnabled: state.loginData.servicesEnabled,
  };
};
export default connect(
  mapStateToProps,
  null
)(withStyles(styles, { withTheme: true })(MemberButtonPanel));
