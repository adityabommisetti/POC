import React, { Component } from "react";
import { withStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import Paper from "@material-ui/core/Paper";
import Typography from "@material-ui/core/Typography";
import AttestationTableMbr from "../Member/LEP/MbrAttestationTable";
import AttestationTableAppl from "../Application/LEP/AttestationTable";
import { Styles } from "../../assets/styles/Theme";
import Switch from "@material-ui/core/Switch";
import LetterTable from "./LepLetterTable";
import AttestationReceived from "../Member/LEP/MbrAttestationReceived";
import "../../App.css";

class Attestation extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showAllActive: false,
    };
  }

  toggleShowAll = async () => {
    await this.setState((prevState) => ({
      showAllActive: !prevState.showAllActive,
    }));
    if (this.state.showAllActive) {
      this.props.showAllAttestationData(this.props.primaryId);
    } else {
      let list = this.props.data.lepAttestList.filter(
        (ob) => ob.overRideInd === "N"
      );
      this.props.showActiveAttestationList(list);
    }
  };
  copyAttestationData = () => {
    let reqList = this.props.data.lepAttestList.filter(
      (ob) => ob.overRideInd === "N" && ob.brkInCoverage === "No"
    );
    if (reqList.length > 0) {
      this.props.copyAttestationData(
        reqList,
        this.props.lepEffDate,
        this.props.primaryId,
        this.props.uncovList
      );
    } else {
      alert("No data found to copy with Prior Credible Coverage as 'N'");
    }
  };

  render() {
    const { classes, data } = this.props;
    const { showAllActive } = this.state;

    return (
      <Paper elevation={0} className={classes.card}>
        <React.Fragment>
          <div style={{ width: "100%", textAlign: "center" }}>
            <div style={{ display: "inline" }}>
              <Typography
                variant="h6"
                id="tableTitle"
                className={classes.attestation1}
              >
                Attestation Letter
              </Typography>
              <LetterTable
                data={data}
                setLepValue={this.props.setLepValue}
                updateAttestationLetter={this.props.updateAttestationLetter}
                mbrLep={this.props.mbrLep}
              />
              <Typography
                variant="h6"
                id="tableTitle"
                className={classes.attestation1}
              >
                Attestation
              </Typography>
            </div>
          </div>
          <div style={{ width: "100%", textAlign: "right" }}>
            <div style={{ display: "inline-flex" }}>
              <div className={classes.buttonContainer}>
                <Switch
                  id="showAllActive"
                  checked={showAllActive}
                  onChange={this.toggleShowAll}
                  value="overrideDupApplication"
                  color="primary"
                />
                <span>Show All</span>
              </div>
              <Button
                variant="contained"
                color="primary"
                className={classes.button}
                onClick={this.copyAttestationData}
                disabled={
                  this.props.suppLepPlatinoApp === "true" ||
                  this.props.supLepMbr === "true"
                }
              >
                Copy
              </Button>
            </div>
          </div>

          <div style={{ width: "100%", textAlign: "center" }}>
            <div style={{ display: "inline" }}>
              {this.props.mbrLep ? (
                <React.Fragment>
                  <AttestationTableMbr rowsPerPage={5} sortableHeader={true} />
                  <br />
                  <AttestationReceived />
                </React.Fragment>
              ) : (
                <AttestationTableAppl rowsPerPage={5} sortableHeader={true} />
              )}
            </div>
          </div>
        </React.Fragment>
      </Paper>
    );
  }
}

export default withStyles(Styles)(Attestation);
