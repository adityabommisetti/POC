import React, { Component } from "react";
import { withStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import { styles } from "../../assets/styles/DataTableStyle";


class DataTable extends Component {
  render() {
    const { classes, data } = this.props;

    return (
      <div style={{ width: "100%", textAlign: "center" }}>
        <div
          className={classes.tableWrapper}
          style={{ width: this.props.width ? this.props.width : "100%" }}
        >
          <Table className={classes.tableModified}>
            <TableHead className={classes.thead}>
              <TableRow className={classes.headRow}>
                <TableCell  className={classes.headerCell}>
                  Part A Start Date
                </TableCell>
                <TableCell  className={classes.headerCell}>
                  Part A End Date
                </TableCell>
                <TableCell  className={classes.headerCell}>
                  Part B Start Date
                </TableCell>
                <TableCell  className={classes.headerCell}>
                  Part B End Date
                </TableCell>
                <TableCell  className={classes.headerCell}>
                  Part D Start Date
                </TableCell>
                {/* <TableCell align="center" className={classes.headerCell}>
                  Part D End Date
                </TableCell> */}
              </TableRow>
            </TableHead>

            <TableBody className={classes.tbody}>
              {data ? (
                <TableRow className={classes.row}>
                  <TableCell className={classes.tableCell}>
                    {data.partAEntitleSDate}
                  </TableCell>
                  <TableCell className={classes.tableCell}>
                    {data.partAEntitleEDate}
                  </TableCell>
                  <TableCell className={classes.tableCell}>
                    {data.partBEntitleSDate}
                  </TableCell>
                  <TableCell className={classes.tableCell}>
                    {data.partBEntitleEDate}
                  </TableCell>
                  <TableCell className={classes.tableCell}>
                    {data.partDEntitleSDate}
                  </TableCell>
                  {/* <TableCell className={classes.tableCell}>
                    {data.partDEntitleEDate}
                  </TableCell> */}
                </TableRow>
              ) : (
                  <TableRow className={classes.row}>
                  <TableCell className={classes.tableCell} colSpan={5}>
                   No Data Found
                  </TableCell>
                  
                </TableRow>
               
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    );
  }
}



export default withStyles(styles)(DataTable);
