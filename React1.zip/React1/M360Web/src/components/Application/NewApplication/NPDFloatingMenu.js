import React from "react";

export default class FloatingMenu extends React.Component {
  componentDidMount() {
    var links = document.getElementsByTagName("i");
    for (var i = 0; i < links.length; i++) {
      links[i].addEventListener("click", this.changeColor);
    }
  }

  
  changeColor=(e)=> {
    var links = document.getElementsByTagName("i");
    for (let i = 0; i < links.length; i++) {
      links[i].parentNode.classList.remove("changeLabel");
    }
    let x=e.target.parentNode.nodeName    
    if(x==="A"){
      e.target.parentNode.classList.add("changeLabel");
    }else if(x==="DIV"){
      e.target.classList.add("changeLabel"); 
    }
   
  }


  render() {
    const { appFields } = this.props;
    return (
      <div class="float-Menu">
        <a
          tabIndex="-1"
          href="#personalInfo"
          title="Personal Information"
          activeclassname="active"
          onClick={(e) => {this.props.scrollToElement(e, "personalInfo"); this.changeColor(e)}}
        >
          <i class="fa fa-info-circle"></i>
        </a>
        {appFields.value === "Y" ? (
          <a
            tabIndex="-1"
            href="#lep"
            title="LEP"
            onClick={(e) => {this.props.scrollToElement(e, "lep"); this.changeColor(e)}}
          >
            <i class="fa fa-money"></i>
          </a>
        ) : null}
        <a
          tabIndex="-1"
          href="#address"
          title="Address"
          onClick={(e) => {this.props.scrollToElement(e, "address"); this.changeColor(e)}}
        >
          <i class="fa fa-address-book"></i>
        </a>
        <a
          tabIndex="-1"
          href="#enrollment"
          title="Enrollment"
          onClick={(e) => {this.props.scrollToElement(e, "enrollment"); this.changeColor(e)}}
        >
          <i class="fas fa-user-check"></i>
        </a>
        {/* <a
        tabIndex="-1"
          href="#pcp"
          title="PCP"
          onClick={(e) => this.props.scrollToElement(e, "pcp")}
        >
          <i class="fas fa-user-nurse"></i>
        </a> */}
        {appFields.value === "Y" ? (
          <a
            tabIndex="-1"
            href="#banking"
            title="Banking Information"
            onClick={(e) => {this.props.scrollToElement(e, "banking"); this.changeColor(e)}}
          >
            <i class="fa fa-bank"></i>
          </a>
        ) : null}
        <a
          tabIndex="-1"
          href="#questions"
          title="Questions"
          onClick={(e) => {this.props.scrollToElement(e, "questions"); this.changeColor(e)}}
        >
          <i class="fa fa-question-circle-o"></i>
        </a>
        <a
          tabIndex="-1"
          href="#election"
          title="Election"
          onClick={(e) => {this.props.scrollToElement(e, "election"); this.changeColor(e)}}
        >
          <i class="fas fa-vote-yea"></i>
        </a>
       
        {appFields.value === "N" ? (
          <a
            tabIndex="-1"
            href="#banking"
            title="Banking Information"
            onClick={(e) => {this.props.scrollToElement(e, "banking"); this.changeColor(e)}}
          >
            <i class="fa fa-bank"></i>
          </a>
        ) : null}
        <a
          tabIndex="-1"
          href="#agent"
          title="Agent"
          onClick={(e) => {this.props.scrollToElement(e, "agent"); this.changeColor(e)}}
        >
          <i class="fas fa-user-secret"></i>
        </a>

        {appFields.value === "N" ? (
          <a
            tabIndex="-1"
            href="#lep"
            title="LEP"
            onClick={(e) => {this.props.scrollToElement(e, "lep"); this.changeColor(e)}}
          >
            <i class="fa fa-money"></i>
          </a>
        ) : null} <a
          tabIndex="-1"
          href="#signature"
          title="Signature"
          onClick={(e) => {this.props.scrollToElement(e, "signature"); this.changeColor(e)}}
        >
          <i class="fas fa-file-signature"></i>
        </a>
      </div>
    );
  }
}