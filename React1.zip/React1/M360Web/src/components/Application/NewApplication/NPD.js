import React from "react";
import Address from "../ApplAddress";
import Attestation from "../ApplAttestation";
import BankingInfo from "../ApplBankingInfo";
import BrokeAgentData from "../ApplBrokerAgent";
import CancellationInfo from "../ApplCancellationInfo";
import CommentsSignature from "../ApplCommentsSignature";
import DenialInfo from "../ApplDenialInformation";
import EnrollmentInfo from "../ApplEnrollment";
import ExpansionPanel from "../../UI/ExpansionPanel";
import PersonalInfo from "../ApplPersonalInfo";
import Questions from "../ApplQuestions";
import { LEP } from "../ApplTabImport";
export default class NPD extends React.Component {
  render() {
    const { collapse, appFields, searchResultsVo, lepCollapse } = this.props;
    return (
      <React.Fragment>
        <div id="personalInfo">
          <ExpansionPanel
            summary="Personal Information"
            defaultCollapsed={collapse}
          >
            <PersonalInfo
            //  handlechangeAuto ={this.props.handlechangeAuto}
              handleDates={this.props.handleDates}
              handleDateChange={this.props.handleDateChange}
              handlechange={this.props.handlechange}
              handlechangeAuto ={this.props.handlechangeAuto}
              handleOnBlur={this.props.handleOnBlur}
              validator={this.props.validator}
              handleNumberChange={this.props.handleNumberChange}
              originalApplication={this.props.originalApp}
              handleAlpha={this.props.handleAlpha}
              statusHoldValidator={this.props.statusHoldValidator}
            />
          </ExpansionPanel>
        </div>
        {!this.props.originalApp &&
        !this.props.newApplFlag &&
        appFields.value === "Y" ? (
          <div id="lep">
            <ExpansionPanel
              summary="LEP"
              onClick={this.props.loadLep}
              defaultCollapsed={lepCollapse}
            >
              <LEP setLepCollapse={this.props.setLepCollapse} />
            </ExpansionPanel>
          </div>
        ) : null}
        <div id="address">
          <ExpansionPanel
            summary="Address Information"
            defaultCollapsed={collapse}
          >
            <Address
              handleDates={this.props.handleDates}
              handlechangeCounty={this.props.handleChangeDropDown}
              handlechange={this.props.handlechange}
              handlechangeAuto ={this.props.handlechangeAuto}
              handleOnBlur={this.props.handleOnBlur}
              setData={this.props.setCityZipData}
              handleNumberChange={this.props.handleNumberChange}
              showEmergencyInfo={this.props.showEmergencyInfo}
              handleNumber={this.props.handleNumber}
              validator={this.props.validator}
              originalApplication={this.props.originalApp}
              handleAlpha={this.props.handleAlpha}
              handleCheckbox={this.props.handleCheckbox}
              statusHoldValidator={this.props.statusHoldValidator}
            />
          </ExpansionPanel>
        </div>
        <div id="enrollment">
          <ExpansionPanel summary="Enrollment" defaultCollapsed={collapse}>
            <EnrollmentInfo
              handleDates={this.props.handleDates}
              handleDateChange={this.props.handleDateChange}
              handlechange={this.props.handlechange}
              handlechangeAuto ={this.props.handlechangeAuto}
              handleOnBlur={this.props.handleOnBlur}
              validator={this.props.validator}
              handleNumber={this.props.handleNumber}
              originalApplication={this.props.originalApp}
              statusHoldValidator={this.props.statusHoldValidator}
              closePopup={this.props.closePopup}
            />
          </ExpansionPanel>
        </div>
        {appFields.value === "Y" && (
          <div id="banking">
            <ExpansionPanel
              summary="Banking Information"
              defaultCollapsed={collapse}
            >
              <BankingInfo
                handleDates={this.props.handleDates}
                handlechange={this.props.handlechange}
                handlechangeAuto ={this.props.handlechangeAuto}
                handleOnBlur={this.props.handleOnBlur}
                validator={this.props.validator}
                handleNumber={this.props.handleNumber}
                handleAlphaNumeric={this.props.handleAlphaNumeric}
                originalApplication={this.props.originalApp}
                handleAlpha={this.props.handleAlpha}
              />
            </ExpansionPanel>
          </div>
        )}

        <div id="questions">
          <ExpansionPanel
            summary={
              appFields.value === "Y"
                ? "Important Questions"
                : "Questions To Be Answered"
            }
            defaultCollapsed={collapse}
          >
            <Questions
              handleDates={this.props.handleDates}
              handleDateChange={this.props.handleDateChange}
              handlechange={this.props.handlechange}
              handlechangeAuto ={this.props.handlechangeAuto}
              handleOnBlur={this.props.handleOnBlur}
              validator={this.props.validator}
              originalApplication={this.props.originalApp}
            />
          </ExpansionPanel>
        </div>
        <div id="election">
          <ExpansionPanel summary="Election" defaultCollapsed={collapse}>
            <Attestation
              handleDates={this.props.handleDates}
              handleDateChange={this.props.handleDateChange}
              handlechange={this.props.handlechange}
              handlechangeAuto ={this.props.handlechangeAuto}
              handleOnBlur={this.props.handleOnBlur}
              validator={this.props.validator}
              originalApplication={this.props.originalApp}
              handleCheckbox={this.props.handleCheckbox}
            />
          </ExpansionPanel>
        </div>
        
        {appFields.value === "N" && (
          <div id="banking">
            <ExpansionPanel
              summary="Banking Information"
              defaultCollapsed={collapse}
            >
              <BankingInfo
                handleDates={this.props.handleDates}
                handlechange={this.props.handlechange}
                handlechangeAuto ={this.props.handlechangeAuto}
                handleOnBlur={this.props.handleOnBlur}
                validator={this.props.validator}
                handleNumber={this.props.handleNumber}
                handleAlphaNumeric={this.props.handleAlphaNumeric}
                originalApplication={this.props.originalApp}
                handleAlpha={this.props.handleAlpha}
              />
            </ExpansionPanel>
          </div>
        )}
        <div id="agent">
          <ExpansionPanel summary="Agent" defaultCollapsed={collapse}>
            <BrokeAgentData
              handleDates={this.props.handleDates}
              handleDateChange={this.props.handleDateChange}
              handlechangeSearchSelect={this.props.handleChangeSearchSelect}
              handlechange={this.props.handlechange}
              handlechangeAuto ={this.props.handlechangeAuto}
              handleOnBlur={this.props.handleOnBlur}
              validator={this.props.validator}
              originalApplication={this.props.originalApp}
            />
          </ExpansionPanel>
        </div>
        {this.props.cancelFlag ||
        searchResultsVo.applVO.currStatus === "CANCELED" ? (
          <div id="cancel">
            <ExpansionPanel
              summary="Cancellation Info"
              defaultCollapsed={collapse}
            >
              <CancellationInfo
                handleDates={this.props.handleDates}
                handlechange={this.props.handlechange}
                handleOnBlur={this.props.handleOnBlur}
                validator={this.props.validator}
                handlechangeAuto={this.props.handlechangeAuto}
              />
            </ExpansionPanel>
          </div>
        ) : null}
        {!this.props.originalApp &&
        !this.props.newApplFlag &&
        appFields.value === "N" ? (
          <div id="lep">
            <ExpansionPanel
              summary="LEP"
              onClick={this.props.loadLep}
              defaultCollapsed={lepCollapse}
            >
              <LEP setLepCollapse={this.props.setLepCollapse} />
            </ExpansionPanel>
          </div>
        ) : null}
<div id="signature">
          <ExpansionPanel
            summary="Comments Signature"
            defaultCollapsed={collapse}
          >
            <CommentsSignature
              handleDates={this.props.handleDates}
              handleDateChange={this.props.handleDateChange}
              handleNumberChange={this.props.handleNumberChange}
              handlechange={this.props.handlechange}
              handlechangeAuto ={this.props.handlechangeAuto}
              handleOnBlur={this.props.handleOnBlur}
              setData={this.props.setCityZipData}
              validator={this.props.validator}
              originalApplication={this.props.originalApp}
              handleAlpha={this.props.handleAlpha}
              handleCheckbox={this.props.handleCheckbox}
              handleNumber={this.props.handleNumber}
              newApplFlag={this.props.newApplFlag}
              disable={this.props.disable}
            />
          </ExpansionPanel>
        </div>
        {this.props.denialFlag ||
        searchResultsVo.applVO.currStatus === "DENIEDOTHR" ||
        searchResultsVo.applVO.currStatus === "DENIEDETYP" ||
        searchResultsVo.applVO.currStatus === "DENIEDELG" ? (
          <div id="denial">
            <ExpansionPanel summary="Denial Info" defaultCollapsed={collapse}>
              <DenialInfo
                handleDateChange={this.props.handleDateChange}
                handleDates={this.props.handleDates}
                handlechange={this.props.handlechange}
                handleOnBlur={this.props.handleOnBlur}
                validator={this.props.validator}
                handlechangeAuto ={this.props.handlechangeAuto}
              />
            </ExpansionPanel>
          </div>
        ) : null}
      </React.Fragment>
    );
  }
}
