import React, { Component } from "react";
import Autocomplete1 from "../UI/Select";

import GroupProdSearchPopup from "./ApplGroupProductSearch";
import InputField from "../UI/InputField";
import Paper from "@material-ui/core/Paper";
import Popup from "reactjs-popup";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../assets/styles/Theme";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";
import Modal from "../UI/Modal/Modal";
import { setValue } from "../../redux/actions/ApplActions";
import checkErrorField from "../../utils/CheckErrorField";
import scrollTo from "../../utils/ScrollToElement";
class Address extends Component {
  constructor(props) {
    super(props);
    this.state = {
      validationmsg: "Please Enter Address",
      closePopup: false,
      message: "",
      campidInd: [],
      contrnoInd: [],
      appFields: [],
    };
    this.validator = new SimpleReactValidator();
  }

  handlechange = (name, targetVo) => async (event) => {
    let value = event.target
      ? event.target.value.toUpperCase()
      : event.value.toUpperCase();

    await this.props.setValue(name, targetVo, value);
  };

  closePopup = (message) => {
    scrollTo("address");
    this.setState({ closePopup: true, message: message });
  };
  modalClosed = () => {
    this.setState({ closePopup: false });
  };

  validateLIS = (applLisVO) => {
    if (
      (applLisVO.effStartDt ||
        applLisVO.effEndDt ||
        applLisVO.liCoPayCd ||
        applLisVO.lisPctCd) === ""
    ) {
      return false;
    } else if (
      (applLisVO.effStartDt ||
        applLisVO.effEndDt ||
        applLisVO.liCoPayCd ||
        applLisVO.lisPctCd) == null
    ) {
      return false;
    } else {
      return true;
    }
  };

  updatedMsg = (value, msg) => {
    this.setState({
      closePopup: value,
      message: msg,
    });
  };
  modalClosed = () => {
    this.setState({ closePopup: false });
  };

  async componentDidMount() {
    const { loginProfile } = this.props;
    const CAMPIDIND = loginProfile.filter((data) => data.label === "CAMPIDIND");
    const CONTRNOIND = loginProfile.filter(
      (data) => data.label === "CONTRNOIND"
    );
    const APPFIELDS = loginProfile.filter((data) => data.label === "APPFIELDS");
    const lobVald = loginProfile.filter((data) => data.label === "LOB_VALD");
    if (lobVald.value === "Y") {
    } else {
    }
    this.setState({
      campidInd: CAMPIDIND[0],
      contrnoInd: CONTRNOIND[0],
      appFields: APPFIELDS[0],
    });
  }

  render() {
    const {
      classes,
      searchResultsVo,
      originalApplication,
      dropdowns,
    } = this.props;
    const applVO = searchResultsVo.applVO;
    const applPlanVO = searchResultsVo.applPlanVO;
    const grpProdVO = searchResultsVo.grpProdVO;
    const applLisVO = searchResultsVo.applLisVO;
    const { campidInd, contrnoInd, appFields } = this.state;

    return (
      <React.Fragment>
        <Modal
          message={this.state.message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Paper elevation={0} className={classes.card}>
          <div className={classes.applicationSectionHeading}>
            <span> You are Enrolled / Enrolling In</span>
          </div>
          {applVO.applType === "CMA" || applVO.applType === "CPD" ? (
            <React.Fragment>
              <div className={classes.container}>
                <div style={{ marginRight: "52px" }}>
                  <InputField
                    name="currGroupName"
                    label="Current Group"
                    maxLength={50}
                    width="357px"
                    disabled
                    value={grpProdVO.currGroupName}
                    onChange={this.props.handlechange(
                      "currGroupName",
                      "grpProdVO"
                    )}
                    onBlur={this.props.handleOnBlur("grpProdVO")}
                    isErrorField={checkErrorField(
                      "currGroupName",
                      searchResultsVo
                    )}
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="currProdName"
                    label="Current Product"
                    disabled
                    value={grpProdVO.currProdName}
                    width="357px"
                    isErrorField={checkErrorField(
                      "currProdName",
                      searchResultsVo
                    )}
                    onChange={this.props.handlechange(
                      "currProdName",
                      "grpProdVO"
                    )}
                    onBlur={this.props.handleOnBlur("grpProdVO")}
                  />
                  <div className={classes.validationMessage} />
                </div>
              </div>
              <div className={classes.container}>
                <div>
                  <InputField
                    name="currPlanId"
                    label="Plan"
                    maxLength={5}
                    disabled
                    value={applPlanVO.currPlanId}
                    onChange={this.props.handlechange(
                      "currPlanId",
                      "applPlanVO"
                    )}
                    onBlur={this.props.handleOnBlur("applPlanVO")}
                    isErrorField={checkErrorField(
                      "currPlanId",
                      searchResultsVo
                    )}
                  />
                  <div className={classes.validationMessage} />
                </div>

                <div>
                  <InputField
                    name="currPbpId"
                    label="PBP"
                    maxLength={3}
                    disabled
                    width="40px !important"
                    value={applPlanVO.currPbpId}
                    onChange={this.props.handleNumber(
                      "currPbpId",
                      "applPlanVO"
                    )}
                    isErrorField={checkErrorField("currPbpId", searchResultsVo)}
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="currPbpSegmentId"
                    label="Segment"
                    maxLength={3}
                    disabled
                    value={applPlanVO.currPbpSegmentId}
                    onChange={this.props.handleNumber(
                      "currPbpSegmentId",
                      "applPlanVO"
                    )}
                    isErrorField={checkErrorField(
                      "currPbpSegmentId",
                      searchResultsVo
                    )}
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="currPaymentAmt"
                    label="Current Payment Amtount"
                    maxLength={10}
                    disabled
                    value={applPlanVO.currPaymentAmt}
                    onChange={this.props.handleNumber(
                      "currPaymentAmt",
                      "applPlanVO"
                    )}
                    isErrorField={checkErrorField(
                      "currPaymentAmt",
                      searchResultsVo
                    )}
                  />
                  <div className={classes.validationMessage} />
                </div>
              </div>
              <hr />
            </React.Fragment>
          ) : null}
          <div className={classes.container}>
            <div style={{ marginRight: "52px", marginLeft: "8px" }}>
              <InputField
                name="enrollGroupName"
                label="Enrolling Group"
                maxLength={50}
                width="357px"
                value={grpProdVO.enrollGroupName}
                onChange={this.props.handlechange(
                  "enrollGroupName",
                  "grpProdVO"
                )}
                onBlur={this.props.handleOnBlur("grpProdVO")}
                disabled={originalApplication}
                isErrorField={checkErrorField(
                  "enrollGroupName",
                  searchResultsVo
                )}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <span class="label-container">
                <label htmlFor="enrollProdName">Enrolling Product</label>
                <span className="imp">*</span>
                <br />
                <input
                  maxLength={50}
                  type="text"
                  class="form-field input-popup"
                  id="enrollProdName"
                  name="enrollProdName"
                  style={{
                    width: "475px",
                    backgroundColor: checkErrorField(
                      "enrollProduct",
                      searchResultsVo
                    )
                      ? "yellow"
                      : null,
                  }}
                  value={grpProdVO.enrollProdName}
                  onChange={this.props.handlechange(
                    "enrollProdName",
                    "grpProdVO"
                  )}
                  onBlur={this.props.handleOnBlur("grpProdVO")}
                  disabled={originalApplication}
                />

                {!originalApplication ? (
                  <Popup
                    className={classes.mobileWidth}
                    modal
                    trigger={<span class="more-info" id="more-info" />}
                    position="right center"
                  >
                    {(close) => (
                      <div>
                        <GroupProdSearchPopup
                          closePopup={this.closePopup}
                          //setData={this.props.setGroupProdData}
                          //data={searchResultsVo}
                          close={close}
                        />
                      </div>
                    )}
                  </Popup>
                ) : null}
              </span>
              <div
                className={classes.validationMessage}
                style={{ width: "357px" }}
              >
                {
                  // applVO.applStatus !== "INCOMPLETE" ||
                  // applVO.applStatus !== "Hold" ||
                  // applVO.applStatus !== "READY"
                  //   ? this.props.statusHoldValidator.message(
                  //       "enrollingProduct",
                  //       grpProdVO.enrollProdName,
                  //       "required"
                  //     )
                  //   :
                  this.props.validator.message(
                    "enrollingProduct",
                    grpProdVO.enrollProdName,
                    "required"
                  )
                }
              </div>
            </div>

            <div className={classes.container}>
              <div>
                <InputField
                  name="enrollPlan"
                  id="enrollPlanId"
                  label="Plan"
                  maxLength={5}
                  value={applPlanVO.enrollPlan}
                  onChange={this.props.handlechange("enrollPlan", "applPlanVO")}
                  onBlur={this.props.handleOnBlur("grpProdVO")}
                  disabled={originalApplication}
                  isErrorField={checkErrorField("enrollPlan", searchResultsVo)}
                  required
                />
                <div className={classes.validationMessage}>
                  {
                    // applVO.applStatus !== "INCOMPLETE" ||
                    // applVO.applStatus !== "Hold" //||
                    //   ? //applVO.applStatus !== "READY"
                    //     this.props.statusHoldValidator.message(
                    //       "plan",
                    //       applPlanVO.enrollPlan,
                    //       "required"
                    //     )
                    //   :
                    this.props.validator.message(
                      "plan",
                      applPlanVO.enrollPlan,
                      "required"
                    )
                  }
                </div>
              </div>
              <div>
                <InputField
                  name="enrollPbpId"
                  id="enrollPbpId"
                  label="PBP"
                  maxLength={3}
                  value={applPlanVO.enrollPbp}
                  onChange={this.props.handleNumber("enrollPbp", "applPlanVO")}
                  disabled={originalApplication}
                  isErrorField={checkErrorField("enrollPbp", searchResultsVo)}
                />
                <div className={classes.validationMessage} />
              </div>
              <div>
                <InputField
                  name="enrollSegment"
                  id="enrollPbpSegmentId"
                  label="Segment"
                  maxLength={3}
                  value={applPlanVO.enrollSegment}
                  onChange={this.props.handleNumber(
                    "enrollSegment",
                    "applPlanVO"
                  )}
                  isErrorField={checkErrorField(
                    "enrollSegment",
                    searchResultsVo
                  )}
                  disabled={originalApplication}
                />
                <div className={classes.validationMessage} />
              </div>
              <div>
                <InputField
                  name="enrollPaymentAmt"
                  id="enrollPaymentAmt"
                  label="New Payment Amount"
                  maxLength={10}
                  value={applPlanVO.enrollPymtAmt}
                  onChange={this.props.handleNumber(
                    "enrollPymtAmt",
                    "applPlanVO"
                  )}
                  isErrorField={checkErrorField(
                    "enrollPymtAmt",
                    searchResultsVo
                  )}
                  disabled={originalApplication}
                />
                <div className={classes.validationMessage} />
              </div>

              <div className={classes.Select2}>
                <Autocomplete1
                  handleChange={this.props.handlechangeAuto}
                  width={"230px"}
                  vo='applVO'
                  margin='0px'
                  label='Enroll Source'
                  options={dropdowns.lstEnrollSrce}
                  defaultValue={dropdowns.lstEnrollSrce[0]}
                  value={dropdowns.lstEnrollSrce.filter(data => data.value === applVO.enrollSrceCd)[0]}
                  name='enrollSrceCd'
                  disabled={originalApplication}
                />
                <div className={classes.validationMessageSelect} />
              </div>
              <div />
              {campidInd.value === "Y" ? (
                <div  style={{marginLeft:'25px'}}>
                  <InputField
                    name="compaignId"
                    id="compaignId"
                    label="Campaign Id"
                    value={applVO.compaignId}
                    onChange={this.props.handlechange("compaignId", "applVO")}
                    disabled={originalApplication}
                   
                  />
                  <div className={classes.validationMessage} />
                </div>
              ) : null}
              {contrnoInd.value === "Y" ? (
                <div>
                  <InputField
                    name="contractorNo"
                    id="contractorNo"
                    label="Contract Number"
                    value={applVO.contractorNo}
                    onChange={this.props.handlechange("contractorNo", "applVO")}
                    disabled={originalApplication}
                  />
                  <div className={classes.validationMessage} />
                </div>
              ) : null}
              {!(appFields.value === "Y") ||
                (appFields.value === "Y" &&
                  (applVO.applType === "CMA" || applVO.applType === "CPD")) ? (
                  <React.Fragment>
                    {" "}
                    <div style={{ width: "335px" }}>
                      <Autocomplete1
                        handleChange={this.props.handlechangeAuto}
                        width="280px"
                        vo='applVO'
                        margin='0px'
                        label='Send Correspondence in the following Language'
                        options={dropdowns.lstLanguages}
                        defaultValue={{ label: "ENGLISH", value: "ENG" }}
                        value={dropdowns.lstLanguages.filter(data => data.value === applVO.language)[0]}
                        name='language'
                        disabled={originalApplication}
                      />
                      <div className={classes.validationMessageSelect} />
                    </div>
                    <div style={{ width: "15rem" }}>
                     
                      <Autocomplete1
                        handleChange={this.props.handlechangeAuto}
                        width={"217px"}
                        vo='applVO'
                        margin='0px'
                        label='Alternate Correspondence Method'
                        options={dropdowns.lstAltCorrespondences}
                        defaultValue={dropdowns.lstAltCorrespondences[0]}
                        value={dropdowns.lstAltCorrespondences.filter(data => data.value === applVO.altCorrespondenceInd)[0]}
                        name='altCorrespondenceInd'
                        disabled={originalApplication}
                      />
                      <div className={classes.validationMessageSelect} />
                    </div>
                  </React.Fragment>
                ) : null}
            </div>
          </div>

          <div className={classes.applicationSectionHeading}>
            {appFields.value === "Y" ? (
              <span>Plan Premium</span>
            ) : (
                <span>Your Plan Premium</span>
              )}
          </div>
          <div className={classes.container}>
            <div>
              
              <Autocomplete1
                handleChange={this.props.handlechangeAuto}
                width={"200px"}
                vo='applVO'
                margin='0px'
                label='MA/PD Premium Payment Option'
                options={dropdowns.lstPWOptions}
                defaultValue={dropdowns.lstPWOptions[0]}
                value={dropdowns.lstPWOptions.filter(data => data.value === applVO.pwOption)[0]}
                name='pwOption'
                disabled={originalApplication}
              />
              <div className={classes.validationMessageSelect} />
            </div>
          </div>
          <div className={classes.applicationSectionHeading}>
            <span>LIS Information</span>
          </div>
          <div className={classes.container}>
            <div>
              <InputField
                name="effStartDt"
                id="effStartDt"
                label="Start Date"
                maxLength="10"
                placeholder="MM/DD/YYYY"
                value={applLisVO.effStartDt}
                onClick={this.props.handleDates("#effStartDt", "applLisVO")}
                disabled={originalApplication}
                onChange={this.props.handleDateChange(
                  "effStartDt",
                  "applLisVO"
                )}

              // onBlur={this.props.dateChange}
              />
              <div className={classes.validationMessage}>
                {this.validateLIS(applLisVO)
                  ? this.props.validator.message(
                    "StartDt",
                    applLisVO.effStartDt,
                    "required|date_format"
                  )
                  : null}
              </div>
            </div>
            <div>
              <InputField
                name="effEndDt"
                id="effEndDt"
                label="End Date"
                maxLength="10"
                placeholder="MM/DD/YYYY"
                value={applLisVO.effEndDt}
                onClick={this.props.handleDates("#effEndDt", "applLisVO")}
                disabled={originalApplication}
                onChange={this.props.handleDateChange("effEndDt", "applLisVO")}

              // onBlur={this.props.dateChange}
              />
              <div className={classes.validationMessage}>
                {this.validateLIS(applLisVO)
                  ? this.props.validator.message(
                    "EndDt",
                    applLisVO.effEndDt,
                    "required|date_format"
                  )
                  : null}
              </div>
            </div>
            <div>
              
              <Autocomplete1
                handleChange={this.props.handlechangeAuto}
                vo='applLisVO'
                margin='0px'
                label='Copay'
                options={dropdowns.validLiCopays}
                defaultValue={dropdowns.validLiCopays[0]}
                value={dropdowns.validLiCopays.filter(data => data.value === applLisVO.liCoPayCd)[0]}
                name='liCoPayCd'
                disabled={originalApplication}
              />
              <div className={classes.validationMessageSelect}>
                {this.validateLIS(applLisVO)
                  ? this.props.validator.message(
                    "coPay",
                    applLisVO.liCoPayCd,
                    "required"
                  )
                  : null}
              </div>
            </div>
            <div className={classes.Select2}>
              
              <Autocomplete1
                handleChange={this.props.handlechangeAuto}
                vo='applLisVO'
                margin='0px'
                label='Select'
                options={dropdowns.validLiPercents}
                defaultValue={dropdowns.validLiPercents[0]}
                value={dropdowns.validLiPercents.filter(data => data.value === applLisVO.lisPctCd)[0]}
                name='lisPctCd'
                disabled={originalApplication}
              />
              <div className={classes.validationMessageSelect}>
                {this.validateLIS(applLisVO)
                  ? this.props.validator.message(
                    "percent",
                    applLisVO.lisPctCd,
                    "required"
                  )
                  : null}
              </div>
            </div>
          </div>
        </Paper>
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    dropdowns: state.dropdowns,
    searchResultsVo: state.applSearch.searchResultsVo,
    loginProfile: state.loginData.profiles,
  };
};
const mapDispatchToProps = {
  setValue,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(Address));
