import "../../App.css";

import React, { Component } from "react";
import { eligCheckSearch, setEligData } from "../../redux/actions/ApplActions";

import Button from "@material-ui/core/Button";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import Checkbox from "@material-ui/core/Checkbox";
import { styles as DataTableStyles } from "../../assets/styles/EligibilityTableStyle";
import { Styles as PopupStyles } from "../../assets/styles/PopupTheme";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import classNames from "classnames";
import combineStyles from "../../utils/CombineStyles";
import { connect } from "react-redux";
import { fetchLabelFromValue } from "./ApplCommonFunctions";
import { withStyles } from "@material-ui/core/styles";

class EligibityCheck extends Component {
  constructor(props) {
    super(props);
    this.state = {
      searchVo: {
        medicareId: this.props.searchResultsVo.applVO.mbrHicNbr,
        lastName: this.props.searchResultsVo.applVO.mbrLastName,
        DOB: this.props.searchResultsVo.applVO.mbrBirthDt
      },
      finalVo: {
        firstName: "",
        middleName: "",
        lastName: "",
        birthDate: "",
        gender: "",
        state: "",
        esrd: "",
        instInd: "",
        medicaidInd: ""
      },
      update: {
        firstName: false,
        middleName: false,
        lastName: false,
        birthDate: false,
        gender: false,
        state: false,
        esrd: false,
        instInd: false,
        medicaidInd: false
      }
    };
  }

  UNSAFE_componentWillReceiveProps = nextProps => {
    this.setState({
      searchVo: {
        medicareId: nextProps.searchResultsVo.applVO.mbrHicNbr,
        lastName: nextProps.searchResultsVo.applVO.mbrLastName,
        DOB: nextProps.searchResultsVo.applVO.mbrBirthDt
      }
    });
  };

  update = async () => {
    const update = this.state.update;
    const mbd = this.props.mbd;
    const searchResultsVo = this.props.searchResultsVo;
    await this.setState({
      finalVo: {
        firstName: update.firstName
          ? mbd.firstName
          : searchResultsVo.applVO.mbrFirstName,
        middleName: update.middleName
          ? mbd.middleInit
          : searchResultsVo.applVO.mbrMiddleName,
        lastName: update.lastName
          ? mbd.lastName
          : searchResultsVo.applVO.mbrLastName,
        birthDate: update.birthDate
          ? mbd.birthDate
          : searchResultsVo.applVO.mbrBirthDt,
        gender: update.gender ? mbd.genderCd : searchResultsVo.applVO.mbrGender,
        state: update.state
          ? mbd.stateCd
          : searchResultsVo.applAddress.perState,
        esrd: update.esrd ? mbd.esrdInd : searchResultsVo.applOtherCovVO.esrd,
        instInd: update.instInd
          ? mbd.instInd
          : searchResultsVo.applOtherCovVO.ltcInstInd,
        medicaidInd: update.medicaidInd
          ? mbd.medicInd
          : searchResultsVo.applOtherCovVO.stMedicaid
      }
    });
    this.props.setEligData(this.state.finalVo);
    this.props.close();
  };

  handleCheckBox = name => {
    const value = !this.state.update[name];
    this.setState(prevState => ({
      update: {
        ...prevState.update,
        [name]: value
      }
    }));
  };

  componentDidMount() {
    if (this.props.searchResultsVo.applPlanVO.reqDtCov === "") {
      this.props.close();
      this.props.updatedMsg(true, "Please enter Requested Date of Cov");
    } else if (
      this.props.searchResultsVo.applVO.mbrBirthDt === "" &&
      this.props.searchResultsVo.applVO.mbrLastName === ""
    ) {
      this.props.close();
      this.props.updatedMsg(true, "Please enter BirthDate or LastName");
    } else if (this.props.searchResultsVo.applVO.mbrHicNbr === "") {
      this.props.close();
      this.props.updatedMsg(true, "Please Enter Medicare ID");
    } else {
      this.props.eligCheckSearch(
        this.state.searchVo,
        this.props.searchResultsVo
      );
    }
  }

  checkAll = () => {
    this.setState({
      update: {
        firstName: true,
        middleName: true,
        lastName: true,
        birthDate: true,
        gender: true,
        state: true,
        esrd: true,
        instInd: true,
        medicaidInd: true
      }
    });
  };

  uncheckAll = () => {
    this.setState({
      update: {
        firstName: false,
        middleName: false,
        lastName: false,
        birthDate: false,
        gender: false,
        state: false,
        esrd: false,
        instInd: false,
        medicaidInd: false
      }
    });
  };

  toggleDate(date) {
    return date ? (
      date.trim()
    ) : (
      <span style={{ visibility: "hidden" }}>00/00/0000</span>
    );
  }
  render() {
    const { classes, mbd, searchResultsVo, dropdowns } = this.props;

    return (
      <React.Fragment>
        <div className={classes.tableWrapper}>
          <Table className={classes.tableModified}>
            <TableHead className={classes.thead}>
              <TableRow className={classes.headRow}>
                <TableCell className={classes.headerCell} />
                <TableCell className={classes.headerCell}>
                  Application
                </TableCell>
                <TableCell className={classes.headerCell}>Update</TableCell>

                <TableCell
                  className={classes.headerCell}
                  style={{ paddingLeft: "30px" }}
                >
                  MBD
                </TableCell>
              </TableRow>
            </TableHead>

            <TableBody className={classes.tbody}>
              <TableRow className={classes.row}>
                <TableCell
                  className={classes.headingCell}
                  style={{ borderRight: "groove" }}
                >
                  Medicare ID:
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                >
                  {searchResultsVo.applVO.mbrHicNbr}
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                />
                <TableCell
                  className={classes.tablecellroot}
                  style={{ paddingLeft: "30px" }}
                >
                  {mbd.mbi ? mbd.mbi : mbd.hicNbr}
                </TableCell>
              </TableRow>
              <TableRow className={classes.row}>
                <TableCell
                  className={classes.headingCell}
                  style={{ borderRight: "groove" }}
                >
                  First Name:
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                >
                  {searchResultsVo.applVO.mbrFirstName}
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                >
                  {/* <div className={classes.textField}> */}
                  <Checkbox
                    style={{ width: 36, height: 16 }}
                    color="primary"
                    name="firstName"
                    id="firstName"
                    checked={this.state.update.firstName}
                    onClick={() => this.handleCheckBox("firstName")}
                    icon={<CheckBoxOutlineBlankIcon style={{ fontSize: 16 }} />}
                    checkedIcon={<CheckBoxIcon style={{ fontSize: 16 }} />}
                  />
                  {/* </div> */}
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ paddingLeft: "30px" }}
                >
                  {mbd.firstName}
                </TableCell>
              </TableRow>
              <TableRow className={classes.row}>
                <TableCell
                  className={classes.headingCell}
                  style={{ borderRight: "groove" }}
                >
                  Middle Initial:
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                >
                  {searchResultsVo.applVO.mbrMiddleName}
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                >
                  <div className={classes.textField}>
                    <Checkbox
                      style={{ width: 36, height: 16 }}
                      color="primary"
                      name="middleName"
                      id="middleName"
                      checked={this.state.update.middleName}
                      onClick={() => this.handleCheckBox("middleName")}
                      icon={
                        <CheckBoxOutlineBlankIcon style={{ fontSize: 16 }} />
                      }
                      checkedIcon={<CheckBoxIcon style={{ fontSize: 16 }} />}
                    />
                  </div>
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ paddingLeft: "30px" }}
                >
                  {mbd.middleInit}
                </TableCell>
              </TableRow>
              <TableRow className={classes.row}>
                <TableCell
                  className={classes.headingCell}
                  style={{ borderRight: "groove" }}
                >
                  Last Name:
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                >
                  {searchResultsVo.applVO.mbrLastName}
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                >
                  <div className={classes.textField}>
                    <Checkbox
                      style={{ width: 36, height: 16 }}
                      color="primary"
                      id="LastName"
                      name="LastName"
                      checked={this.state.update.lastName}
                      onClick={() => this.handleCheckBox("lastName")}
                      icon={
                        <CheckBoxOutlineBlankIcon style={{ fontSize: 16 }} />
                      }
                      checkedIcon={<CheckBoxIcon style={{ fontSize: 16 }} />}
                    />
                  </div>
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ paddingLeft: "30px" }}
                >
                  {mbd.lastName}
                </TableCell>
              </TableRow>
              <TableRow className={classes.row}>
                <TableCell
                  className={classes.headingCell}
                  style={{ borderRight: "groove" }}
                >
                  Birth Date:
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                >
                  {searchResultsVo.applVO.mbrBirthDt}
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                >
                  <div className={classes.textField}>
                    <Checkbox
                      style={{ width: 36, height: 16 }}
                      color="primary"
                      name="birthDate"
                      id="birthDate"
                      checked={this.state.update.birthDate}
                      onClick={() => this.handleCheckBox("birthDate")}
                      icon={
                        <CheckBoxOutlineBlankIcon style={{ fontSize: 16 }} />
                      }
                      checkedIcon={<CheckBoxIcon style={{ fontSize: 16 }} />}
                    />
                  </div>
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ paddingLeft: "30px" }}
                >
                  {mbd.birthDate}
                </TableCell>
              </TableRow>
              <TableRow className={classes.row}>
                <TableCell
                  className={classes.headingCell}
                  style={{ borderRight: "groove" }}
                >
                  Gender:
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                >
                  {searchResultsVo.applVO.mbrGender}
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                >
                  <div className={classes.textField}>
                    <Checkbox
                      style={{ width: 36, height: 16 }}
                      color="primary"
                      name="gender"
                      id="gender"
                      checked={this.state.update.gender}
                      onClick={() => this.handleCheckBox("gender")}
                      icon={
                        <CheckBoxOutlineBlankIcon style={{ fontSize: 16 }} />
                      }
                      checkedIcon={<CheckBoxIcon style={{ fontSize: 16 }} />}
                    />
                  </div>
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ paddingLeft: "30px" }}
                >
                  {mbd.genderCd}
                </TableCell>
              </TableRow>
              <TableRow className={classes.row}>
                <TableCell
                  className={classes.headingCell}
                  style={{ borderRight: "groove" }}
                >
                  State:
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                >
                  {fetchLabelFromValue(
                    dropdowns.lstStates,
                    searchResultsVo.applAddress.perState
                  )}
               
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                >
                  <div className={classes.textField}>
                    <Checkbox
                      style={{ width: 36, height: 16 }}
                      color="primary"
                      name="state"
                      id="state"
                      checked={this.state.update.state}
                      onClick={() => this.handleCheckBox("state")}
                      icon={
                        <CheckBoxOutlineBlankIcon style={{ fontSize: 16 }} />
                      }
                      checkedIcon={<CheckBoxIcon style={{ fontSize: 16 }} />}
                    />
                  </div>
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ paddingLeft: "30px" }}
                >
                  {fetchLabelFromValue(dropdowns.lstStates, mbd.stateCd)}
                </TableCell>
              </TableRow>
              <TableRow className={classes.row}>
                <TableCell
                  className={classes.headingCell}
                  style={{ borderRight: "groove" }}
                >
                  County:
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                >
                  
                  {fetchLabelFromValue(
                    this.props.searchResultsVo.lstCounty,
                    searchResultsVo.applAddress.perCounty
                  )}
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                />
                <TableCell
                  className={classes.tablecellroot}
                  style={{ paddingLeft: "30px" }}
                >
                  {mbd.countyCd}
                </TableCell>
              </TableRow>
              <TableRow className={classes.row}>
                <TableCell
                  className={classes.headingCell}
                  style={{ borderRight: "groove" }}
                >
                  ESRD:
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                >
                  {searchResultsVo.applOtherCovVO.esrd}
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                >
                  <div className={classes.textField}>
                    <Checkbox
                      style={{ width: 36, height: 16 }}
                      color="primary"
                      name="esrd"
                      id="esrdInd"
                      checked={this.state.update.esrd}
                      onClick={() => this.handleCheckBox("esrd")}
                      icon={
                        <CheckBoxOutlineBlankIcon style={{ fontSize: 16 }} />
                      }
                      checkedIcon={<CheckBoxIcon style={{ fontSize: 16 }} />}
                    />
                  </div>
                </TableCell>
                <TableCell className={classes.tablecellroot}>
                  <TableCell>
                    {mbd.esrd ? (
                      mbd.esrd
                    ) : (
                      <span style={{ visibility: "hidden" }}>N</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <span style={{ fontWeight: "bold" }}>Start Date:</span>{" "}
                    {this.toggleDate(mbd.esrdStartDate)}
                  </TableCell>
                  <TableCell>
                    <span style={{ fontWeight: "bold" }}> End Date:</span>{" "}
                    {this.toggleDate(mbd.esrdEndDate)}
                  </TableCell>
                </TableCell>
              </TableRow>
              <TableRow className={classes.row}>
                <TableCell
                  className={classes.headingCell}
                  style={{ borderRight: "groove" }}
                >
                  Institutional:
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                >
                  {searchResultsVo.applOtherCovVO.ltcInstInd}
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                >
                  <div className={classes.textField}>
                    <Checkbox
                      style={{ width: 36, height: 16 }}
                      color="primary"
                      name="instInd"
                      id="instInd"
                      checked={this.state.update.instInd}
                      onClick={() => this.handleCheckBox("instInd")}
                      icon={
                        <CheckBoxOutlineBlankIcon style={{ fontSize: 16 }} />
                      }
                      checkedIcon={<CheckBoxIcon style={{ fontSize: 16 }} />}
                    />
                  </div>
                </TableCell>
                <TableCell className={classes.tablecellroot}>
                  <TableCell>{mbd.instInd}</TableCell>
                  <TableCell>
                    <span style={{ fontWeight: "bold" }}>Start Date:</span>{" "}
                    {this.toggleDate(mbd.instStartDate)}
                  </TableCell>
                  <TableCell>
                    <span style={{ fontWeight: "bold" }}> End Date:</span>{" "}
                    {this.toggleDate(mbd.instEndDate)}
                  </TableCell>
                </TableCell>
              </TableRow>
              <TableRow className={classes.row}>
                <TableCell
                  className={classes.headingCell}
                  style={{ borderRight: "groove" }}
                >
                  Medicaid:
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                >
                  {searchResultsVo.applOtherCovVO.stMedicaid}
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                >
                  <div className={classes.textField}>
                    <Checkbox
                      style={{ width: 36, height: 16 }}
                      color="primary"
                      value="medicaidInd"
                      id="medicaidInd"
                      name="medicaidInd"
                      checked={this.state.update.medicaidInd}
                      onClick={() => this.handleCheckBox("medicaidInd")}
                      icon={
                        <CheckBoxOutlineBlankIcon style={{ fontSize: 16 }} />
                      }
                      checkedIcon={<CheckBoxIcon style={{ fontSize: 16 }} />}
                    />
                  </div>
                </TableCell>
                <TableCell className={classes.tablecellroot}>
                  <TableCell>{mbd.medicInd}</TableCell>
                  <TableCell>
                    <span style={{ fontWeight: "bold" }}>Start Date:</span>{" "}
                    {this.toggleDate(mbd.medicStartDate)}
                  </TableCell>
                  <TableCell>
                    <span style={{ fontWeight: "bold" }}> End Date:</span>{" "}
                    {this.toggleDate(mbd.medicEndDate)}
                  </TableCell>
                </TableCell>
              </TableRow>
              <TableRow className={classes.row}>
                <TableCell
                  className={classes.headingCell}
                  style={{ borderRight: "groove" }}
                >
                  Hospice:
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                >
                  {searchResultsVo.applOtherCovVO.ltcInstInd}
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                />
                <TableCell className={classes.tablecellroot}>
                  <TableCell>{mbd.hospiceInd}</TableCell>
                  <TableCell>
                    <span style={{ fontWeight: "bold" }}>Start Date:</span>{" "}
                    {this.toggleDate(mbd.hospiceStartDate)}
                  </TableCell>
                  <TableCell>
                    <span style={{ fontWeight: "bold" }}> End Date:</span>{" "}
                    {this.toggleDate(mbd.hospiceEndDate)}
                  </TableCell>
                </TableCell>
              </TableRow>
              <TableRow className={classes.row}>
                <TableCell
                  className={classes.headingCell}
                  style={{ borderRight: "groove" }}
                >
                  Entitlement Date - Part A:
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                >
                  {searchResultsVo.applEligiVO.partAEffDate}
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                />
                <TableCell className={classes.tablecellroot}>
                  <TableCell>
                    <span style={{ visibility: "hidden" }}>N</span>
                  </TableCell>
                  <TableCell>
                    <span style={{ fontWeight: "bold" }}>Start Date:</span>{" "}
                    {this.toggleDate(mbd.prtAEntitleDate)}
                  </TableCell>
                  <TableCell>
                    <span style={{ fontWeight: "bold" }}> End Date:</span>{" "}
                    {this.toggleDate(mbd.prtAEntitleEndDate)}
                  </TableCell>
                </TableCell>
              </TableRow>
              <TableRow className={classes.row}>
                <TableCell
                  className={classes.headingCell}
                  style={{ borderRight: "groove" }}
                >
                  Entitlement Date - Part B:
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                >
                  {searchResultsVo.applEligiVO.partBEffDate}
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                />
                <TableCell className={classes.tablecellroot}>
                  <TableCell>
                    <span style={{ visibility: "hidden" }}>N</span>
                  </TableCell>
                  <TableCell>
                    <span style={{ fontWeight: "bold" }}>Start Date:</span>{" "}
                    {this.toggleDate(mbd.prtBEntitleDate)}
                  </TableCell>
                  <TableCell>
                    <span style={{ fontWeight: "bold" }}> End Date:</span>{" "}
                    {this.toggleDate(mbd.prtBEntitleEndDate)}
                  </TableCell>
                </TableCell>
              </TableRow>
              <TableRow className={classes.row}>
                <TableCell
                  className={classes.headingCell}
                  style={{ borderRight: "groove" }}
                >
                  Entitlement Date - Part D:
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                >
                  {searchResultsVo.applEligiVO.partDEffDate}
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                />
                <TableCell className={classes.tablecellroot}>
                  <TableCell>
                    {" "}
                    <span style={{ visibility: "hidden" }}>N</span>
                  </TableCell>
                  <TableCell>
                    <span style={{ fontWeight: "bold" }}>Start Date:</span>{" "}
                    {this.toggleDate(mbd.prtDEligibleDate)}
                  </TableCell>
                </TableCell>
              </TableRow>
              <TableRow className={classes.row}>
                <TableCell
                  className={classes.headingCell}
                  style={{ borderRight: "groove" }}
                >
                  Death Date:
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                >
                  {this.props.mbd.deathDate}
                </TableCell>
                <TableCell
                  className={classes.tablecellroot}
                  style={{ borderRight: "groove" }}
                />
                <TableCell
                  className={classes.tablecellroot}
                  style={{ paddingLeft: "30px" }}
                >
                  {mbd.deathDate}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </div>

        <div
          className={classes.div1}
          style={{ minHeight: "84px!important", paddingTop: "10px" }}
        >
          <Button
            variant="contained"
            color="primary"
            id="checkAll"
            className={classNames(classes.button, classes.submit)}
            onClick={this.checkAll}
          >
            Check All
          </Button>
          <Button
            variant="contained"
            color="primary"
            id="uncheckAll"
            className={classNames(classes.button, classes.submit)}
            onClick={this.uncheckAll}
          >
            Uncheck All
          </Button>
          <Button
            variant="contained"
            color="primary"
            id="update"
            className={classNames(classes.button, classes.submit)}
            onClick={this.update}
          >
            Update
          </Button>
          <Button
            variant="contained"
            color="primary"
            id="cancel"
            className={classNames(classes.button, classes.submit)}
            onClick={this.props.close}
          >
            Cancel
          </Button>
        </div>
      </React.Fragment>
    );
  }
}
const combinedStyles = combineStyles(DataTableStyles, PopupStyles);

const mapStateToProps = state => ({
  mbd: state.applPopupVO.mbdData,
  searchResultsVo: state.applSearch.searchResultsVo,
  dropdowns: state.dropdowns
});

const mapDispatchToProps = {
  eligCheckSearch,
  setEligData
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(combinedStyles)(EligibityCheck));
