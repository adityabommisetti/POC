import React, { Component } from "react";
import AutoComplete1 from "../UI/Select";
import { messages } from "../../constants/Messages";
import AgencySearchPopup from "./ApplAgencySearchPopup";
import InputField from "../UI/InputField";
import Paper from "@material-ui/core/Paper";
import Popup from "reactjs-popup";
import { Styles } from "../../assets/styles/Theme";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";
import Modal from "../UI/Modal/Modal";

class BrokerAgentData extends Component {
  constructor(props) {
    super(props);
    this.state = {
      closePopup: false,
      appFields: [],
    };
  }
  async componentDidMount() {
    const { loginProfile } = this.props;
    const APPFIELDS = loginProfile.filter((data) => data.label === "APPFIELDS");
    this.setState({
      appFields: APPFIELDS[0],
    });
  }
  closePopup = () => {
    window.scroll(0, 200);
    this.setState({ closePopup: true, message: messages.REQ_DATE_COVERAGE });
  };
  modalClosed = () => {
    this.setState({ closePopup: false });
  };
  render() {
    const {
      classes,
      searchResultsVo,
      originalApplication,
      dropdowns,
    } = this.props;
    const applAgentVO = searchResultsVo.applAgentVO;
    const applVO = searchResultsVo.applVO;
    
    return (
      <React.Fragment>
        <Modal
          dialogTitle="Personal info"
          message={this.state.message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Paper elevation={0} className={classes.card}>
          <div className={classes.container}>
            <span class="label-container" style={{ width: "535px", marginLeft: "-5px" }}>
              <label htmlFor="commision_agency_org" style={{ marginLeft: "5px" }}>
                Commision Agency&#47;Org
              </label>
              <br />
              <input
                type="text"
                class="form-field input-popup"
                id="commAgencyId"
                name="commAgencyId"
                maxLength={100}
                style={{ width: "500px" }}
                value={applAgentVO.commAgencyId ? applAgentVO.commAgencyId : ""}
                onChange={this.props.handlechange(
                  "commAgencyId",
                  "applAgentVO"
                )}
                onBlur={this.props.handleOnBlur("applAgentVO")}
                disabled={originalApplication}
              />

              {!originalApplication ? (
                <Popup
                  className={classes.mobileWidth}
                  modal
                  trigger={<span class="more-info" id="agency_popup" />}
                  position="right center"
                >
                  {(close) => (
                    <div>
                      <AgencySearchPopup
                        closePopup={this.closePopup}
                        setData={this.props.setAgencyData}
                        close={close}
                        type="Application"
                      />
                    </div>
                  )}
                </Popup>
              ) : null}
            </span>
            <div className={classes.Margin}>
              <AutoComplete1
                vo='applVO'
                options={dropdowns.lstApplCategory}
                handleChange={this.props.handlechangeAuto}
                defaultValue={dropdowns.lstApplCategory[0]}
                value={
                  dropdowns.lstApplCategory.filter(
                    (data) =>
                      data.value === applVO.applCategory
                  )[0]
                }
                label="Application. Category"
                name="applCategory"
                disabled={originalApplication}
              />

              <div className={classes.validationMessageSelect}>
                {this.props.validator.message(
                  "applCategory",
                  applVO.applCategory,
                  "required"
                )}
              </div>
            </div>
            <div>
              <InputField
                name="agentDt"
                label="Date"
                id="agentDt"
                maxLength={10}
                placeholder="MM/DD/YYYY"
                value={applAgentVO.agentDt ? applAgentVO.agentDt : ""}
                onClick={this.props.handleDates("#agentDt", "applAgentVO")}
                disabled={originalApplication}
                onChange={this.props.handleDateChange("agentDt", "applAgentVO")}
              />
              <div className={classes.validationMessage}>
                {this.props.validator.message(
                  "Date",
                  applAgentVO.agentDt,
                  "date_format"
                )}
              </div>
            </div>
            <div style={{ width: "305px" }}>
              <InputField
                name="brokerType"
                disabled={originalApplication}
                label="Agent Type"
                value={applAgentVO.brokerType ? applAgentVO.brokerType : ""}
                onChange={this.props.handlechange("brokerType", "applAgentVO")}
                onBlur={this.props.handleOnBlur("applAgentVO")}
                width="280px"
              />

              <div className={classes.validationMessageSelect} />
            </div>

            <div className={classes.agentfield}>
              <InputField
                name="agentName"
                disabled={originalApplication}
                label="Agent Name"
                value={applAgentVO.agentName ? applAgentVO.agentName : ""} //{applAgentVO.agentName}
                onChange={this.props.handlechange("agentName", "applAgentVO")}
                onBlur={this.props.handleOnBlur("applAgentVO")}
                width="200px"
              />

              <div className={classes.validationMessageSelect} />
            </div>

            <div className={classes.containerAgent}>
              <div style={{ width: "475px", marginLeft: "-10px" }}>
                <InputField
                  name="agencyType"
                  disabled={originalApplication}
                  label="Agency Type"
                  value={applAgentVO.agencyType ? applAgentVO.agencyType : ""}
                  onChange={this.props.handlechange(
                    "agencyType",
                    "applAgentVO"
                  )}
                  onBlur={this.props.handleOnBlur("applAgentVO")}
                  width="450px"
                />

                <div className={classes.validationMessageSelect} />
              </div>
              <div>
                <InputField
                  name="agencyName"
                  disabled={originalApplication}
                  label="Agency Name"
                  value={applAgentVO.agencyName ? applAgentVO.agencyName : ""}
                  onChange={this.props.handlechange(
                    "agencyName",
                    "applAgentVO"
                  )}
                  onBlur={this.props.handleOnBlur("applAgentVO")}
                  width="350px"
                />

                <div className={classes.validationMessageSelect} />
              </div>
            </div>
          </div>
        </Paper>
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    dropdowns: state.dropdowns,
    searchResultsVo: state.applSearch.searchResultsVo,
    loginProfile: state.loginData.profiles,
  };
};
export default connect(mapStateToProps)(withStyles(Styles)(BrokerAgentData));
