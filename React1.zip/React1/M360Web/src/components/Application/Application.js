import * as DateUtil from "../../utils/DatePicker";

import React, { Component } from "react";
import {
  applCancel,
  applUpdate,
  cancel,
  fetchCacheData,
  fetchMemberData,
  newApplication,
  revertApplChanges,
  rowClickSearch,
  applSearch as searchApplication,
  setValue,
  validateApplication,
  validateError,
  getInstitution,
  applSearchNextPage,
  getLepDetails,
} from "../../redux/actions/ApplActions";

import ApplSearchPanel from "./ApplSearchPanel";
import ApplicationTabs from "./ApplSubtabs";
import DataTable from "../Home/DataTable";
import ExpansionPanel from "../UI/ExpansionPanel";
import Modal from "../UI/Modal/Modal";
import NewApplButton from "./NewApplButton";
import Paper from "@material-ui/core/Paper";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../assets/styles/Theme";
import Switch from "@material-ui/core/Switch";
import { connect } from "react-redux";
import { APPLICATION_SEARCH_HEADER as header } from "../../constants/Headers/ApplicationHeaders";
import isEmpty from "lodash/isEmpty";
import moment from "moment";
import {
  resetMemberSearch,
  searchAttributes,
} from "../../redux/actions/MemberActions";
import { withStyles } from "@material-ui/core/styles";
import { handleDateChange } from "../../utils/DateFormatter";
import scrollTo from "../../utils/ScrollToElement";
const dateChk = {};
class Application extends Component {
  constructor(props) {
    super(props);
    this.state = {
      searchVo: {
        firstName: this.props.searchAttribute
          ? props.searchAttribute.firstName
          : "",
        lastName: this.props.searchAttribute
          ? props.searchAttribute.lastName
          : "",
        DOB: this.props.searchAttribute ? props.searchAttribute.DOB : "",
        applId: this.props.searchAttribute ? props.searchAttribute.applId : "",
        searchStatus: this.props.searchAttribute
          ? props.searchAttribute.searchStatus
          : "",
        hicNbr: this.props.searchAttribute ? props.searchAttribute.hicNbr : "",
      },
      showEmergencyInfo: true,
      newApplFlag: null,
      collapseSearch: false,
      isvalid: true,
      denialFlag: false,
      cancelFlag: false,
      flag: false,
      originalApplication: false,
      selectedRowIndex: 0,
      isClosed: false,
      validatePopup: false,
      validatePopup1: false,
      closePopup: false,
      rowsPerPage: 10,
      pageNo: 0,
      searchResults: {},
      disable: "",
      resetFlag: true,
      autoApplDt: [],
      valSignAgt: [],
      nOICd: [], //Name Of Institute profile Code
      enbCMAQues: [],
      appFields: [],
      newApplIdGen: false,
    };
    const validate = {
      phone_no: {
        // name the rule
        message: "Please enter valid 10 digit number.",
        rule: (val, params, validator) => {
          val = val.replace(/[^0-9]/g, "");
          if (val.length !== 10) {
            return false;
          }
          return true;
        },
      },

      if_zip_entered: {
        message: ":attribute is required.",
        rule: (val, params, validator) => {
          const zip = val[0];
          const data = val[1];
          if (!isEmpty(zip) && isEmpty(data)) {
            return false;
          } else {
            return true;
          }
        },
      },
      mailing_address: {
        message: ":attribute is required.",
        rule: (val, params, validator) => {
          const zip = val[3];
          let data = val[2];
          if (data) {
            data = Array.from(new Set(data.split("null"))).toString();
          }

          if (isEmpty(zip) && data !== "" && data !== 0 && data.length !== 0) {
            return false;
          } else if (data === "") {
            return true;
          } else {
            return true;
          }
        },
      },
      date_after_or_equal: {
        message: ":attribute should not be past date.",
        rule: (val, params, validator) => {
          if (moment().isAfter(this.props.searchResultsVo.applVO.denialRcvDt)) {
            return false;
          }
          return true;
        },
      },
      date_format: {
        message: "Invalid date. Please format as valid MM/DD/YYYY",
        rule: (val, params, validator) => {
          if (val === "99/99/9999" || val === "00/00/0000") {
            return true;
          }
          return moment(val, "MM/DD/YYYY", true).isValid();
        },
      },
      attestationDateRequired: {
        message: "attestation date is required",
        required: true,
        rule: (val, params, validator) => {
          if (!isEmpty(val)) {
            return true;
          } else return false;
        },
      },
      attestation_exception_required: {
        message: "sep exception is required",
        required: true,
        rule: (val, params, validator) => {
          if (!isEmpty(val)) {
            return true;
          } else return false;
        },
      },
    };
    this.validator = new SimpleReactValidator({
      validators: validate,

      autoForceUpdate: this,
    });
    this.statusIncoValidator = new SimpleReactValidator({
      validators: validate,

      autoForceUpdate: this,
    });

    this.statusHoldValidator = new SimpleReactValidator({
      validators: validate,

      autoForceUpdate: this,
    });
    this.applSearchValidator = new SimpleReactValidator({
      validators: validate,
      autoForceUpdate: this,
    });
  }

  UNSAFE_componentWillMount() {
    if (Object.keys(this.props.dropdowns).length === 0) {
      this.props.fetchCacheData();
    }
  }

  selectRow = async (selectedRowIndex, application) => {
    this.setState({
      denialFlag: false,
      cancelFlag: false,
      selectedRowIndex: selectedRowIndex,
    });

    if (application.applId !== this.props.applsearchCriteria.applId) {
      await this.props.rowClickSearch(application);
    }
  };

  changePage =async (page, application)=>{

    await this.props.rowClickSearch(application);
  }
  cancel = (event) => {
    event.preventDefault();
    this.setState({
      collapseSearch: false,
    });
    this.props.cancel();
  };

  initialValidation = () => {
    if (
      !(
        this.props.searchResultsVo.applVO.applStatus === "CANCELLED" ||
        this.props.searchResultsVo.applVO.applStatus === "DENIEDETYP" ||
        this.props.searchResultsVo.applVO.applStatus === "DENIEDELG" ||
        this.props.searchResultsVo.applVO.applStatus === "DENIEDOTHR"
      )
    ) {
      return true;
    }
    return false;
  };

  newApplicationType = async (applType) => {
    const appFields = this.state.appFields.value;
    this.validator.hideMessages();
    this.statusIncoValidator.hideMessages();
    this.statusHoldValidator.hideMessages();
    this.setState({
      newApplFlag: applType,
      collapseSearch: true,
      isvalid: false,
      denialFlag: false,
      cancelFlag: false,
      originalApplication: false,
      isClosed: true,
      newApplIdGen: false,
    });

    await this.props.newApplication(applType, appFields);
    await this.props.validateError("");
    this.clearSearch();
    this.setState({
      searchResultsVo: this.props.searchResultsVo,
    });
  };

  checkValid = async (val) => {
    const { searchResultsVo, dropdowns } = this.props;
    const { applVO } = searchResultsVo;
    searchResultsVo.applAttestationList.map((item, i) => {
      return dropdowns.lstSepExceptions.map((object, j) => {
        if (item.attestInd === object.value && object.dateRequiredInd === "N") {
          this.validator.fields["attestationDate" + i] = true;
        }
        return null;
      });
    });

    if (
      isEmpty(applVO.achbankAcctNbr) &&
      isEmpty(applVO.achAbaRoutingNbr) &&
      isEmpty(applVO.achBankName)
    ) {
      this.validator.fields.abaRoutingNbr = true;
      this.validator.fields.bankAcctNbr = true;
      this.validator.fields.draftDay = true;
    }

    if (!this.validator.allValid()) {
      this.validator.showMessages();
      await this.props.validateError(
        "Please fill mandatory field/s highlighted in red"
      );
      scrollTo("displayMessage");
      return;
    } else if (val === "Validation") {
      this.validator.allValid() &&
        (await this.props.validateApplication(this.props.searchResultsVo, {
          sucessCallBack: async (data) => {
            await this.props.validateError("Validation");
          },
          failureCallBack: async (error) => {
            await this.props.validateError("Validation Failed!");
          },
        }));
    } else if (val === "Update" && this.state.cancelFlag === false) {
      this.validator.allValid() &&
        (await this.props.applUpdate(
          this.props.searchResultsVo,
          this.props.newCommentList,
          {
            sucessCallBack: async (data) => {
              await this.props.validateError("Update");
            },
            failureCallBack: async (error) => {
              await this.props.validateError("Update Failed!");
            },
          }
        ));
    }
    scrollTo("displayMessage");
  };

  handleChangeSearchSelectAuto =(data,name)=>{
    
    let value = data?data.value.toUpperCase(): ' ';


    if (name === "DOB" && value.length === 8) {
      value = value.replace(/[^0-9]/g, "").trim();
      value = value.replace(/^(\d{2})/, "$1/");
      value = value.replace(/\/(\d{2})/, "/$1/");
      value = value.replace(/(\d)\/(\d{4}).*/, "$1/$2");
    }

    if (name === "hicNbr") {
      value = value.replace(/[^0-9]/g, "").trim();
    }

    this.setState(
      (prevState) => ({
        searchVo: {
          ...prevState.searchVo,
          [name]: value,
        },
        collapseSearch: false,
      }),
      () => {
        this.props.searchAttributes({ applicationSearch: this.state.searchVo });
      }
    );
  };


  handleSearchFieldChange = (name) => (event) => {
    let value = event.target
      ? event.target.value.toUpperCase()
      : event.value.toUpperCase();

    if (name === "DOB" && value.length === 8) {
      value = value.replace(/[^0-9]/g, "").trim();
      value = value.replace(/^(\d{2})/, "$1/");
      value = value.replace(/\/(\d{2})/, "/$1/");
      value = value.replace(/(\d)\/(\d{4}).*/, "$1/$2");
    }

    if (name === "hicNbr") {
      value = event.target.value;
      value = value.replace(/[^0-9]/g, "").trim();
    }

    this.setState(
      (prevState) => ({
        searchVo: {
          ...prevState.searchVo,
          [name]: value,
        },
        collapseSearch: false,
      }),
      () => {
        this.props.searchAttributes({ applicationSearch: this.state.searchVo });
      }
    );
  };

  handlechangeAuto = (event, name, targetVo) => {
    if(event === null){
      return;
    }
    let value = event.value//.toUpperCase();
    const reqDtCov = this.props.searchResultsVo.applPlanVO.reqDtCov;
    const applType = this.props.searchResultsVo.applVO.applType;
    const enbCMAQues = this.state.enbCMAQues;
    if (
      name === "nameInstitute" &&
      value &&
      (applType === "NMA" ||
        applType === "NPD" ||
        (applType === "CMA" && enbCMAQues.value === "Y"))
    ) {
      if (isEmpty(reqDtCov)) {
        this.setState({
          closePopup: true,
          message: "request date of coverage is required",
        });
      }
      const params = {
        nameInstitute: value,
        reqDtCov: reqDtCov,
      };

      this.props.getInstitution(params);
    }
    if (targetVo === "applPlanVO" && name === "enrollPlan") {
      this.doEnrollPBPChange();
    }

    if (name === "esrd") {
      this.props.setValue("pcoInd", targetVo, value);
    }
    this.props.setValue(name, targetVo, value);
    this.setState({ flag: false });
    this.props.searchAttributes({ applicationSearch: this.state.searchVo });
  };


  handlechange = (name, targetVo) => (event) => {
    let value = event.target
      ? event.target.value.toUpperCase()
      : event.value.toUpperCase();
    const reqDtCov = this.props.searchResultsVo.applPlanVO.reqDtCov;
    const applType = this.props.searchResultsVo.applVO.applType;
    const enbCMAQues = this.state.enbCMAQues;
    if (
      name === "nameInstitute" &&
      value &&
      (applType === "NMA" ||
        applType === "NPD" ||
        (applType === "CMA" && enbCMAQues.value === "Y"))
    ) {
      if (isEmpty(reqDtCov)) {
        this.setState({
          closePopup: true,
          message: "request date of coverage is required",
        });
      }
      const params = {
        nameInstitute: value,
        reqDtCov: reqDtCov,
      };

      this.props.getInstitution(params);
    }
    if (targetVo === "applPlanVO" && name === "enrollPlan") {
      this.doEnrollPBPChange();
    }

    if (name === "esrd") {
      this.props.setValue("pcoInd", targetVo, value);
    }

    this.props.setValue(name, targetVo, value);
    this.setState({ flag: false });
    this.props.searchAttributes({ applicationSearch: this.state.searchVo });
  };

  doEnrollPBPChange = async () => {
    let name = "enrollProdName";
    let targetVo = "grpProdVO";
    let value = "";
    await this.props.setValue(name, targetVo, value);
  };

  handleOnBlur = (targetVo) => (event) => {
    this.props.setValue(event.target.name, targetVo, event.target.value.trim());
    this.setState({ flag: false });
  };
  handleOnBlurFieldChange = (event) => {
    let value = event.target.value.trim();
    let name = event.target.name;
    if (name === "DOB" && value.length === 8) {
      value = value.replace(/[^0-9]/g, "").trim();
      value = value.replace(/^(\d{2})/, "$1/").trim();
      value = value.replace(/\/(\d{2})/, "/$1/").trim();
      value = value.replace(/(\d)\/(\d{4}).*/, "$1/$2").trim();
    }

    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value.trim(),
      },
      collapseSearch: false,
    }));
    this.props.searchAttributes({ applicationSearch: this.state.searchVo });
  };

  handleCheckbox = (name, targetVo) => (event) => {
    let value = event.target.checked ? "Y" : "N";
    this.props.setValue(name, targetVo, value);
  };

  handleStartDate = (fieldId) => {
    var self = this;
    DateUtil.getStartDatePicker(fieldId).on("change", (e) => {
      self.setDate(e.target.name, e.target.value);
      document.getElementById(fieldId.substr(1)).focus();
    });
    this.props.searchAttributes({ applicationSearch: this.state.searchVo });
  };

  handleDates = (fieldId, targetVo) => (event) => {
    var self = this;
    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        if (
          dateChk.name !== e.target.name ||
          dateChk.value !== e.target.value
        ) {
          dateChk.name = e.target.name;
          dateChk.value = e.target.value;

          self.setDate(e.target.name, e.target.value, targetVo);
          document.getElementById(fieldId.substr(1)).focus();
        }
      });
    this.props.searchAttributes({ applicationSearch: this.state.searchVo });
  };

  setDate = (name, value, targetVo) => {
    if (targetVo === "searchVo") {
      this.setState((prevState) => ({
        searchVo: {
          ...prevState.searchVo,
          [name]: value,
        },
      }));
    } else {
      this.props.setValue(name, targetVo, value);
    }
    dateChk.name = "";
    dateChk.value = "";
  };

  handleDateChange = (name, targetVo) => (event) => {
    let value = event.target.value;
    value = handleDateChange(value);
    this.props.setValue(name, targetVo, value);
  };

  handleNumberChange = (name, targetVo) => (event) => {
    let value = event.target.value.replace(/[^0-9]/g, "");
    if (name === "mbrSsn") {
      value = value.replace(/(\d{3})(\d{2})(\d{4})/, "$1-$2-$3");
      //value = value.replace(/^(\d{3})/, "$1-");
      //value = value.replace(/-(\d{2})/, "-$1-");
      //value = value.replace(/(\d)-(\d{4}).*/, "$1-$2");

      //value = value.replace(/(-\d{2})/, "$1");
      //value = value.replace(/(-\d{4}).*/, "$1");
       //value = value.replace(/[^0-9]/g, "").trim();
//if(value.length === 10){
  //value = value.slice(0, 3) + "-" + value.slice(3, 5)+'-' + value.slice(5, value.length);
//}
    } else {
      value = value.replace(
        /^(?=[0-9]{10})([0-9]{3})([0-9]{3})([0-9]{4})/,
        "$1-$2-$3"
      );
    }
    this.props.setValue(name, targetVo, value);
  };

  handleNumber = (name, targetVo) => (e) => {
    let value = e.target.value.replace(/[^0-9]/g, "");
    if (
      (targetVo === "applPlanVO" && name === "enrollPbp") ||
      (targetVo === "applPlanVO" && name === "enrollPbp")
    ) {
      this.doEnrollPBPChange();
    }
    this.props.setValue(name, targetVo, value);
  };

  handleAlphaNumeric = (name, targetVo) => (e) => {
    if (name === "hicNbr") {
      let value = e.target.value.replace(/[^-\w\s']/g, "").toUpperCase();
      this.setState((prevState) => ({
        searchVo: {
          ...prevState.searchVo,
          [name]: value,
        },
        collapseSearch: false,
      }));
    } else {
      let value = e.target.value.replace(/[^-\w\s']/g, "").toUpperCase();
      this.props.setValue(name, targetVo, value);
    }
  };
  handleAlpha = (name, targetVo) => (e) => {
    let value = e.target.value.replace(/[^-a-z A-Z\s']/g, "").toUpperCase();
    this.props.setValue(name, targetVo, value);
  };

  handleSearchAppl = async (e) => {
    e.preventDefault();
    if (this.applSearchValidator.allValid()) {
      this.applSearchValidator.hideMessages();
      this.setState({
        newApplFlag: false,
        collapseSearch: false,
        flag: true,
        originalApplication: false,
        isClosed: true,
        disable: false,
        resetFlag: true,
      });
      let search = this.state.searchVo;
      if (document.activeElement.name === "DOB") {
          search.DOB = search.DOB.replace(/[^0-9]/g, "").trim();
          search.DOB = search.DOB.replace(/^(\d{2})/, "$1/").trim();
          search.DOB = search.DOB.replace(/\/(\d{2})/, "/$1/").trim();
          search.DOB = search.DOB.replace(/(\d)\/(\d{4}).*/, "$1/$2").trim();
      }
      else{
    	  try {
	    	  if(document.activeElement.name !== 'Undefined'){
	              search[document.activeElement.name]=search[document.activeElement.name].trim();
	    	  }
    	  }
    	  catch(err){
    		  //console.log(err);
    	  }
      }
      await this.props.searchApplication(search);
      this.props.searchAttributes({ applicationSearch: this.state.searchVo });

      // if (!isEmpty(this.props.searchResultsVo.applVO)) {
      //   this.validator.hideMessages();
      //   await this.props.getLepDetails(
      //     this.props.searchResultsVo,
      //     this.props.loginData.loginVo.userId
      //   );
      // }
      await this.props.validateError("");
      this.setState({
        denialFlag: false,
        cancelFlag: false,
        flag: false,
      });
    } else {
      this.applSearchValidator.showMessages();
    }
  };

  clearSearch = () => {
    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        firstName: "",
        lastName: "",
        DOB: "",
        applId: "",
        searchStatus: "",
        hicNbr: "",
      },
      resetFlag: false,
    }));
    this.props.searchAttributes({ applicationSearch: this.state.searchVo });
  };
  handleResetAppl = (event) => {
    event.preventDefault();
    this.clearSearch();
    this.props.searchAttributes({ applicationSearch:{} });
  };

  denialApplication = async (event) => {
    event.preventDefault();
    var curStatus = this.props.searchResultsVo.applVO.currStatus;
    if (
      curStatus === "COMPLETED" ||
      curStatus === "DENIEDELG" ||
      curStatus === "DENIEDETYP" ||
      curStatus === "DENIEDOTHR" ||
      curStatus === "CANCELED"
    ) {
      await this.props.validateError(
        "Denial not allowed for COMPLETED or DENIED or CANCELLED Application"
      );
      scrollTo("displayMessage");
      return;
    }
    this.setState(
      {
        denialFlag: true,
        cancellation: false,
        cancelFlag: false,
        value: 10,
      },
      () => {
        if (this.state.denialFlag) {
          scrollTo("denial");
        }
      }
    );
  };

  cancelApplication = async (event) => {
    event.preventDefault();
    const { applVO } = this.props.searchResultsVo;
    const currStatus = applVO.currStatus;
    if (currStatus === "COMPLETED") {
      await this.props.validateError(
        "Cannot Cancel the Application !! \nCurrent Status is COMPLETED"
      );
      scrollTo("displayMessage");
      return false;
    }
    if (currStatus === "CANCELED") {
      await this.props.validateError(
        "Cannot Cancel the Application t!! \nCurrent Status is CANCELLED"
      );
      scrollTo("displayMessage");
      return false;
    }
    if (
      currStatus === "DENIEDELG" ||
      currStatus === "DENIEDETYP" ||
      currStatus === "DENIEDOTHR"
    ) {
      await this.props.validateError(
        "Cannot Cancel the Application !! \nCurrent Status is DENIED"
      );
      scrollTo("displayMessage");
      return false;
    }

    this.setState(
      {
        denialFlag: false,
        cancelFlag: true,
      },
      () => {
        if (this.state.cancelFlag) {
          scrollTo("cancel");
        }
      }
    );
  };

  originalApplication = (val) => {
    this.setState({ originalApplication: val });
  };

  UNSAFE_componentWillReceiveProps(props) {
    if (!isEmpty(props.searchResultsVo)) {
      this.setState({ isClosed: true });
    }
  }

  updateApplication = async () => {
    const { autoApplDt, valSignAgt, nOICd } = this.state;
    const { searchResultsVo, dropdowns } = this.props;
    const { applVO, applOtherPlanVO, applAgentVO } = searchResultsVo;
    const { applStatus, currStatus } = applVO;
    searchResultsVo.applAttestationList.map((item, i) => {
      dropdowns.lstSepExceptions.map((object, j) => {
        if (item.attestInd === object.value && object.dateRequiredInd === "N") {
          this.validator.fields["attestationDate" + i] = true;
        }
        return null;
      });
      return null;
    });
    if (isEmpty(applVO.achbankAcctNbr) && isEmpty(applVO.achAbaRoutingNbr)) {
      this.validator.fields.abaRoutingNbr = true;
      this.validator.fields.bankAcctNbr = true;
      this.validator.fields.draftDay = true;
    }
    if (this.state.denialFlag === false && this.state.cancelFlag === true) {
      this.validator.fields.denialDate = true;
      this.validator.fields.denialreason = true;
    }

    if (currStatus === "CANCELED") {
      await this.props.validateError(
        "Application Cannot be UPDATED!! Current Status is CANCELLED"
      );
      scrollTo("displayMessage");
      return false;
    }
    if (
      currStatus === "DENIEDELG" ||
      currStatus === "DENIEDETYP" ||
      currStatus === "DENIEDOTHR"
    ) {
      await this.props.validateError(
        "Application Cannot be UPDATED!! \nCurrent Status is DENIED"
      );
      scrollTo("displayMessage");
      return false;
    }
    if (
      (currStatus === "INCRFIREQ" ||
        currStatus === "INCRFIGEN" ||
        currStatus === "DUPLENRL" ||
        currStatus === "DUPLAPPL" ||
        currStatus === "HOLD" ||
        currStatus === "ELGCRITICL" ||
        currStatus === "ERRORCRITL" ||
        currStatus === "OPOUTYES" ||
        currStatus === "ERROR") &&
      applStatus === "FORCEDAPPR"
    ) {
      await this.props.validateError(
        "Can't Update to FORCEDAPPR when Status is " + currStatus + "."
      );
      scrollTo("displayMessage");
      return false;
    }
    if (
      applStatus === "INCOMPLETE" &&
      !(
        currStatus === "" ||
        currStatus === "READY" ||
        currStatus === "INCOMPLETE"
      )
    ) {
      await this.props.validateError(
        "Can't Update to FORCEDAPPR when Status is " + currStatus + "."
      );
      scrollTo("displayMessage");
      return false;
    }
    if (currStatus === "COMPLETED") {
      await this.props.validateError(
        "Application Cannot be UPDATED!! \nCurrent Status is COMPLETED"
      );
      scrollTo("displayMessage");
      return false;
    }

    if (autoApplDt.value === "Y" && applVO.applDate !== applVO.receiptDate) {
      this.setState({
        message: "Application Date and Received Date should be Same",
        closePopup: true,
      });

      return false;
    }

    if (nOICd.value === "Y" && applOtherPlanVO.nameInstitute === "") {
      this.setState({
        message: "Please select Name of Instution.",
        closePopup: true,
      });

      return false;
    }

    if (valSignAgt.value === "Y") {
      if (applOtherPlanVO.pcpName === "") {
        this.setState({
          message: "Please select PCP.",
          closePopup: true,
        });
        return false;
      }

      if (applAgentVO.agentName === "") {
        this.setState({
          message: "Please enter Agent Name.",
          closePopup: true,
        });
        return false;
      }

      if (applVO.signOnFile === "") {
        this.setState({
          message: "Please select Signature on File.",
          closePopup: true,
        });
        return false;
      }
      return false;
    }

    if (this.props.searchResultsVo.applPlanVO.reqDtCov === "") {
      this.validator.showMessages();
      await this.props.validateError(
        "Please fill mandatory field/s highlighted in red"
      );

      this.setState(() => ({
        message: "Request date of coverage is required",
        closePopup: true,
      }));

      scrollTo("displayMessage");
      return;
    }
    if (!this.validator.allValid()) {
      this.validator.showMessages();
      await this.props.validateError(
        "Please fill mandatory field/s highlighted in red"
      );
      scrollTo("displayMessage");
      return;
    } else {
      if (
        this.state.denialFlag &&
        applStatus !== "DENIEDELG" &&
        applStatus !== "DENIEDETYP" &&
        applStatus !== "DENIEDOTHR"
      ) {
        await this.props.validateError("Please select Application Status");
        scrollTo("displayMessage");
        return false;
      }
      this.validator.hideMessages();
    }

    if (this.state.cancelFlag) {
      await this.props.applCancel(
        this.props.searchResultsVo,
        this.props.loginData.loginVo.userId,
        {
          sucessCallBack: async (data) => {
            await this.props.validateError("Update");
          },
          failureCallBack: async (error) => {
            await this.props.validateError("Update Failed!");
          },
        },
        this.props.newCommentList
      );
      scrollTo("displayMessage");
      return;
    }

    if (applStatus === "FORCEDAPPR" && currStatus === "INCRFIELCT") {
      await this.props.validateError(
        "Can't Update to FORCEDAPPR when Status is " + currStatus + "."
      );
      scrollTo("displayMessage");
      return false;
    } else if (
      applStatus === "INCOMPLETE" ||
      applStatus === "HOLD" ||
      applStatus === "READY"
    ) {
      this.validator.hideMessages();
      if (applStatus === "INCOMPLETE") {
        if (!this.statusIncoValidator.allValid()) {
          this.statusIncoValidator.showMessages();
          this.statusHoldValidator.hideMessages();
          await this.props.validateError(
            "Please fill mandatory field/s highlighted in red"
          );
          scrollTo("displayMessage");
          return;
        }
      }

      if (
        !this.statusIncoValidator.allValid() &&
        !this.statusHoldValidator.allValid() //&&
      ) {
        this.statusIncoValidator.showMessages();
        this.statusHoldValidator.showMessages();

        await this.props.validateError(
          "Please fill mandatory field/s highlighted in red"
        );
        scrollTo("displayMessage");
        return;
      } else {
        await this.props.applUpdate(
          this.props.searchResultsVo,
          this.props.newCommentList,
          {
            sucessCallBack: async (data) => {
              await this.props.validateError("Update");
            },
            failureCallBack: async (error) => {
              await this.props.validateError("Update Failed!");
            },
          }
        );
        if (this.props.searchResultsVo.validateFlag === "Update") {
          this.setState({
            newApplFlag: true,
            newApplIdGen: true,

          });
        }
      }
      scrollTo("displayMessage");
    } else {
      this.checkValid("Update");
    }
  };

  closeApplication = () => {
    this.setState({
      newApplFlag: false,
      collapseSearch: false,
      flag: true,
      originalApplication: false,
      isClosed: false,
    });
  };

  async componentDidMount() {
    const { loginProfile, searchResultsVo } = this.props;
    const VALSIGNAGT = loginProfile.filter(
      (data) => data.label === "VALSIGNAGT"
    );
    const AUTOAPPLDT = loginProfile.filter(
      (data) => data.label === "AUTOAPPLDT"
    );
    const NOICD = loginProfile.filter((data) => data.label === "NOICD");
    const ENBCMAQUES = loginProfile.filter(
      (data) => data.label === "ENBCMAQUES"
    );
    const APPFIELDS = loginProfile.filter((data) => data.label === "APPFIELDS");
    let newApplFlag = false;

    if (!isEmpty(searchResultsVo)) {
      if (isEmpty(searchResultsVo.applSearchList)) {
        newApplFlag = true;
      }
    }
    this.setState({
      autoApplDt: AUTOAPPLDT[0],
      valSignAgt: VALSIGNAGT[0],
      nOICd: NOICD[0],
      enbCMAQues: ENBCMAQUES[0],
      appFields: APPFIELDS[0],
      newApplFlag: newApplFlag,
    });

    if (this.state.searchVo.applId) {
      const applicationId = this.state.selectedMemberId
        ? this.state.selectedMemberId.applicationId
        : 0;

      this.setState({ selectedIndex: applicationId });
    }
  }

  componentWillUnmount() {
    this.props.resetMemberSearch({
      applicationId: this.props.applsearchCriteria.applId,
    });
  }

  modalClosed = () => {
    this.setState({ closePopup: false });
  };

  handleChangeRowsPerPage = async (rowsPerPage) => {
    this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  applSearchNextPage = async (pageNo) => {
    const { applSearchList } = this.props.searchResultsVo;
    const lastRow = applSearchList[applSearchList.length - 1];
    let payload = {
      ...this.props.searchCriteriaVo,
      applId: lastRow.applId,
    };

    await this.props.applSearchNextPage(payload);

    this.setState({ selectedRowIndex: pageNo * this.state.rowsPerPage });
  };
  render() {
    const { classes, searchResultsVo } = this.props;
    const {
      message,
      closePopup,
      newApplFlag,
      searchResults,
      collapseSearch,
      searchVo,
      isClosed,
      flag,
      selectedRowIndex,
      rowsPerPage,
      originalApplication,
      showEmergencyInfo,
      validatePopup,
      isvalid,
      cancelFlag,
      denialFlag,
      resetFlag,
    } = this.state;

    let lstApplStatus = this.props.dropdowns.lstApplStatus
      ? this.props.dropdowns.lstApplStatus
      : [{ value: "", label: "Select" }];
    if (searchResultsVo !== searchResults) {
      Object.keys(this.validator.fields).map((field) => {
        this.validator.fields[field] = true;
        return null;
      });
      this.setState({
        searchResults: searchResultsVo,
      });
    }

    return (
      <React.Fragment>
        <Modal
          dialogTitle="Application "
          message={message}
          show={closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Paper
          elevation={0}
          className={classes.card}
          style={{ minHeight: "400px" }}
        >
          <div class="search-panel-small">
            <NewApplButton
              classes={this.props.classes}
              newApplicationType={this.newApplicationType}
            />

            <ApplSearchPanel
              collapseSearch={collapseSearch}
              searchVo={searchVo}
              classes={classes}
              lstApplStatus={lstApplStatus}
              handleSearchFieldChange={this.handleSearchFieldChange}
              handleChangeSearchSelectAuto={this.handleChangeSearchSelectAuto}
              handleOnBlurFieldChange={this.handleOnBlurFieldChange}
              handleDates={this.handleDates}
              handleSearchAppl={this.handleSearchAppl}
              handleResetAppl={this.handleResetAppl}
              handleAlphaNumeric={this.handleAlphaNumeric}
              applSearchValidator={this.applSearchValidator}
            />
          </div>

          {searchResultsVo ? (
            <React.Fragment>
              {searchResultsVo.applSearchList != null && isClosed ? (
                <React.Fragment>
                  {searchResultsVo.applSearchList.length !== 1 &&
                    !newApplFlag ? (
                      <ExpansionPanel summary="Search Results">
                        <DataTable
                          data={this.props.searchResultsVo.applSearchList}
                          header={header}
                          sortable={true}
                          rowsPerPageOptions={[10, 15, 20]}
                          clicked={this.selectRow}
                          clickedFooter={this.changePage}
                          flag={flag}
                          index={selectedRowIndex}
                          searchable={true}
                          exportAsExcel={true}
                          applExportbtn={true}
                          rowsPerPage={rowsPerPage}
                          handleChangeRowsPerPage={this.handleChangeRowsPerPage}
                          fetchMore={this.applSearchNextPage}
                          nextPage={searchResultsVo.nextPage}
                          dateColumn="birthDtFrmt"
                        />
                      </ExpansionPanel>
                    ) : null}
                  {searchResultsVo.applSearchList.length > 0 ||
                    searchResultsVo.newApplInd ? (
                      <React.Fragment>
                        <div
                          className={classes.buttonContainer}
                          id="overRideDuplicateApplication"
                        >
                          <Switch
                            color="primary"
                            value={searchResultsVo.applVO.appDuplicateCheck}
                            checked={
                              searchResultsVo.applVO.appDuplicateCheck === "Y"
                                ? true
                                : false
                            }
                            onChange={this.handleCheckbox(
                              "appDuplicateCheck",
                              "applVO"
                            )}
                          />
                          <span>Override Duplicate Application</span>
                        </div>

                        <ApplicationTabs
                          originalApplicationParent={this.originalApplication}
                          originalApp={originalApplication}
                          cancel={this.cancel}
                          datalogin={this.props.loginData}
                          handleDates={this.handleDates}
                          handleChangeDropDown={this.handleChangeDropDown}
                          handleChangeSearchSelect={this.handleChangeSearchSelect}
                          handlechange={this.handlechange}
                          handlechangeAuto ={this.handlechangeAuto}
                          handleOnBlur={this.handleOnBlur}
                          handleDateChange={this.handleDateChange}
                          handleNumberChange={this.handleNumberChange}
                          showEmergencyInfo={showEmergencyInfo}
                          handleNumber={this.handleNumber}
                          validator={this.validator}
                          closePopup={validatePopup}
                          statusIncoValidator={this.statusIncoValidator}
                          statusHoldValidator={this.statusHoldValidator}
                          handleAlphaNumeric={this.handleAlphaNumeric}
                          handleAlpha={this.handleAlpha}
                          handleCheckbox={this.handleCheckbox}
                          newApplFlag={newApplFlag}
                          isvalid={isvalid}
                          checkValid={this.checkValid}
                          newApplIdGen={this.state.newApplIdGen}
                          denialFlag={denialFlag}
                          denialApplication={this.denialApplication}
                          cancelApplication={this.cancelApplication}
                          cancelFlag={cancelFlag}
                          updateApplication={this.updateApplication}
                          closeApplication={this.closeApplication}
                          disable={this.state.disable}
                        />
                      </React.Fragment>
                    ) : null}
                </React.Fragment>
              ) : resetFlag === true ? (
                <DataTable data={[]} header={header} />
              ) : null}
            </React.Fragment>
          ) : null}
        </Paper>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    loginProfile: state.loginData.profiles,
    searchResultsVo: state.applSearch.searchResultsVo,
    searchCriteriaVo: state.applSearch.searchCriteriaVo,
    isLoading: state.spinner.isLoading,
    dropdowns: state.dropdowns,
    loginData: state.loginData,
    newCommentList: state.applSearch.newCommentList,
    selectedMemberId: state.memberSearch.selectedMemberId,
    applsearchCriteria: state.applSearch.applsearchCriteria,
    searchResultsVoDatabse: state.applSearch.searchResultsVoDatabse,
    searchAttribute: state.memberSearch.searchAttributes
      ? state.memberSearch.searchAttributes.applicationSearch
      : null,
  };
};

const mapDispatchToProps = {
  searchApplication,
  setValue,
  rowClickSearch,
  fetchCacheData,
  newApplication,
  validateApplication,
  applUpdate,
  cancel,
  validateError,
  getInstitution,
  applCancel,
  resetMemberSearch,
  searchAttributes,
  fetchMemberData,
  revertApplChanges,
  applSearchNextPage,
  getLepDetails,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(Application));
