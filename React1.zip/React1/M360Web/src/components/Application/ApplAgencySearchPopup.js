import React, { Component } from "react";
import {
  searchAgent,
  setAgentData,
  setValue,
} from "../../redux/actions/ApplActions";
import isEmpty from "lodash/isEmpty";
import Button from "@material-ui/core/Button";
import DataTable from "../Home/DataTable";
import InputField from "../UI/InputField";
import Paper from "@material-ui/core/Paper";
import { Styles } from "../../assets/styles/PopupTheme";
import classNames from "classnames";
import { connect } from "react-redux";
import { AGENCY_SEARCH_POPUP_HEADER as header } from "../../constants/Headers/ApplicationHeaders";
import { withStyles } from "@material-ui/core/styles";

class AgencySearch extends Component {
  constructor(props) {
    super(props);
    let params = {};
    if (this.props.searchResultsVo && this.props.type === "Application") {
      params = {
        enrollGrpId: this.props.searchResultsVo.applPlanVO.enrollGrpId,
        enrollPbp: this.props.searchResultsVo.applPlanVO.enrollPbp,
        enrollSegment: this.props.searchResultsVo.applPlanVO.enrollSegment,
        enrollPlan: this.props.searchResultsVo.applPlanVO.enrollPlan,
        enrollProduct: this.props.searchResultsVo.applPlanVO.enrollProduct,
      };
    }
    this.state = {
      searchVo: {
        recordType: this.props.type,
        ...params,
        agentId:
          this.props.searchResultsVo && this.props.type === "Application"
            ? this.props.searchResultsVo.applAgentVO.brokAgentId
            : this.props.agent.agentId,
        agentName:
          this.props.searchResultsVo && this.props.type === "Application"
            ? this.props.searchResultsVo.applAgentVO.agentName
            : this.props.agent.agentName,
        agentType:
          this.props.searchResultsVo && this.props.type === "Application"
            ? this.props.searchResultsVo.applAgentVO.brokerType
            : this.props.agent.agentType, // this.props.agent.agentType,
        agencyId:
          this.props.searchResultsVo && this.props.type === "Application"
            ? this.props.searchResultsVo.applAgentVO.brokAgencyId
            : this.props.agent.agencyId, // ,
        agencyName:
          this.props.searchResultsVo && this.props.type === "Application"
            ? this.props.searchResultsVo.applAgentVO.agencyName
            : this.props.agent.agencyName,
        agencyType:
          this.props.searchResultsVo && this.props.type === "Application"
            ? this.props.searchResultsVo.applAgentVO.agencyType
            : this.props.agent.agencyType,
        reqDateCov:
          this.props.searchResultsVo && this.props.type === "Application"
            ? this.props.searchResultsVo.applPlanVO.reqDtCov
            : this.props.agent.effStartDateFrmt,
      },
      selectedVo: null,
      selectedIndex: 0,
    };
  }

  componentDidMount() {
    const { loginProfile, searchResultsVo } = this.props;
    const reqDtCov =  searchResultsVo && searchResultsVo.applPlanVO.reqDtCov;
    const signDt = searchResultsVo && searchResultsVo.applVO.signDt;
    const AGENTDT = loginProfile.filter((data) => data.label === "AGENTDT");
    const agentDt = AGENTDT[0];
    let body = this.state.searchVo;

    if (this.props.searchResultsVo !== null) {
      if (
        this.props.searchResultsVo.applPlanVO.reqDtCov.length !== 10 &&
        this.props.type === "Application"
      ) {
        this.props.close();
        this.props.closePopup();
      } else if (this.props.type === "Application") {
        if (agentDt.value !== "R" && signDt === "") {
          alert("Please Enter Application Signature Date");
          this.props.close();
          return;
        } else if (agentDt.value !== "R") {
          body = {
            ...this.state.searchVo,
            reqDateCov: signDt,
          };
        } else if (agentDt.value === "R") {
          body = {
            ...this.state.searchVo,
            reqDateCov: reqDtCov,
          };
        }
        this.props.searchAgent(body);
      }
    }

    if (
      this.props.type === "Member" &&
      this.state.searchVo.reqDateCov.length !== 10
    ) {
      this.props.close();
      this.props.closePopup();
    } else if (this.props.type === "Member") {
      this.props.searchAgent(this.state.searchVo);
    }
  }

  onRowSelect = (index, page) => {
    this.setState({
      selectedIndex: index,
      page: page,
    });
  };

  onSubmit = (event) => {
    event.preventDefault();
    if (this.state.selectedIndex || this.state.selectedIndex === 0) {
      const tableData = [...this.props.data];
      const selectedVo = tableData[this.state.selectedIndex];
      if (this.props.searchResultsVo && this.props.type === "Application") {
        this.props.setAgentData(selectedVo); // a
      } else {
        this.props.setData(selectedVo); // m
      }
    }
    this.props.close();
  };

  reset = () => {
    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        agentId: "",
        agencyId: "",
        agencyType: "",
        agentType: "",
        agentName: "",
        agencyName: "",
      },
    }));
  };

  handleChange = (e) => {
    let value = e.target.value;
    let name = [e.target.name];

    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: typeof value === "string" ? value.toUpperCase() : value, // str.toUpperCase()
      },
    }));
  };

  handleOnBlur = (e) => {
    let value = e.target.value.trim();
    let name = [e.target.name];

    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: typeof value === "string" ? value.toUpperCase() : value, // str.toUpperCase()
      },
    }));
  };

  render() {
    const { classes, data } = this.props;

    return (
      <React.Fragment>
        <Paper
          className={classes.root}
          elevation={0}
          style={{ padding: "15px" }}
        >
          <fieldset className={classes.fieldset}>
            <legend className={classes.legend}>Agency Search</legend>
            <form autoComplete="off" onSubmit={(e) => this.search(e)}>
              <div className={classes.container} style={{ margin: "0px auto" }}>
                <div>
                  <InputField
                    name="agencyId"
                    label="Agency ID"
                    maxLength={15}
                    value={this.state.searchVo.agencyId}
                    onChange={this.handleChange}
                    onBlur={this.handleOnBlur}
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="agencyName"
                    label="Agency Name"
                    maxLength={50}
                    value={this.state.searchVo.agencyName}
                    onChange={this.handleChange}
                    onBlur={this.handleOnBlur}
                  />
                  <div className={classes.validationMessage} />
                </div>
              </div>

              <div className={classes.container} style={{ margin: "0px auto" }}>
                <div>
                  <InputField
                    name="agentId"
                    label="Agent ID"
                    maxLength={15}
                    value={this.state.searchVo.agentId}
                    onChange={this.handleChange}
                    onBlur={this.handleOnBlur}
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="agentName"
                    label="Agent Name"
                    maxLength={50}
                    value={this.state.searchVo.agentName}
                    onChange={this.handleChange}
                    onBlur={this.handleOnBlur}
                  />
                  <div className={classes.validationMessage} />
                </div>
              </div>

              <div className={classes.div1}>
                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={(e) => {
                    e.preventDefault();
                    this.props.searchAgent(this.state.searchVo);
                  }}
                >
                  <i className="material-icons">search</i>
                </Button>

                <Button
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={this.props.close}
                >
                  <i className="material-icons">cancel</i>
                </Button>
                <Button
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={this.reset}
                >
                  <i class="material-icons">refresh</i>
                </Button>
              </div>
            </form>
          </fieldset>
        </Paper>

        <div className={classes.table}>
          <span className="AgencySearch-table">
            <DataTable
              data={data}
              header={header}
              rowsPerPage={5}
              sortable={false}
              clicked={this.onRowSelect}
              index={this.state.selectedIndex}
              pageNo={this.state.page}
            />
          </span>

          <div className={classes.div1}>
            <Button
              disabled={isEmpty(data)}
              variant="contained"
              color="primary"
              id="agencySubmit"
              className={classNames(classes.button, classes.submit)}
              onClick={this.onSubmit}
            >
              Submit
            </Button>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  data: state.applPopupVO.agencyData,
  searchResultsVo: state.applSearch.searchResultsVo,
  loginProfile: state.loginData.profiles,
});

const mapDispatchToProps = {
  searchAgent,
  setValue,
  setAgentData,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(AgencySearch));
