import Autocomplete1 from "../UI/Select";

import ExpansionPanel from "../UI/ExpansionPanel";
import InputField from "../UI/InputField";
import React from "react";

const ApplSearchPanel = (props) => {
  const { classes, searchVo, lstApplStatus, collapseSearch } = props;
  return (
    <ExpansionPanel
      summary="Application Search"
      defaultCollapsed={collapseSearch}
    >
      <form onSubmit={props.handleSearchAppl}>
        <div className={classes.container} id="SearchPanel">
          <div>
            <InputField
              name="hicNbr"
              label="Medicare ID"
              maxLength="12"
              value={searchVo.hicNbr}
              onChange={props.handleAlphaNumeric("hicNbr")}
              onBlur={props.handleOnBlurFieldChange}
            />

            <div className={classes.validationMessage} />
          </div>
          <div>
            <InputField
              name="firstName"
              label="First Name"
              maxLength={24}
              value={searchVo.firstName}
              onChange={props.handleSearchFieldChange("firstName")}
              onBlur={props.handleOnBlurFieldChange}
            />

            <div className={classes.validationMessage} />
          </div>
          <div>
            <InputField
              name="lastName"
              label="Last Name"
              maxLength={35}
              value={searchVo.lastName}
              onChange={props.handleSearchFieldChange("lastName")}
              onBlur={props.handleOnBlurFieldChange}
              InputLabelProps={{
                className: classes.label,
                shrink: true,
              }}
            />

            <div className={classes.validationMessage} />
          </div>
          <div>
            <InputField
              name="applId"
              label="Application ID"
              maxLength={12}
              value={searchVo.applId}
              onChange={props.handleSearchFieldChange("applId")}
              onBlur={props.handleOnBlurFieldChange}
              InputLabelProps={{
                className: classes.label,
                shrink: true,
              }}
            />

            <div className={classes.validationMessage} />
          </div>
          <div>
            <InputField
              name="DOB"
              placeholder="MM/DD/YYYY"
              label="Birth Date"
              value={searchVo.DOB}
              onClick={props.handleDates("#DOB", "searchVo")}
              maxLength={10}
              InputLabelProps={{
                className: classes.label,
                shrink: true,
              }}
              onChange={props.handleSearchFieldChange("DOB")}
              onBlur={props.handleOnBlur}
            />

            <div className={classes.validationMessage}>
              {props.applSearchValidator.message(
                "birthDate",
                searchVo.DOB,
                "date_format"
              )}
            </div>
          </div>

          <div>
            <Autocomplete1
              margin="0px"
              handleChange={props.handleChangeSearchSelectAuto}
              label="Application Status"
              options={lstApplStatus}
              defaultValue={
                searchVo.searchStatus
                  ? lstApplStatus.filter(
                      (data) => data.value === searchVo.searchStatus
                    )[0]
                  : lstApplStatus[0]
              }
              value={
                searchVo.searchStatus
                  ? lstApplStatus.filter(
                      (data) => data.value === searchVo.searchStatus
                    )[0]
                  : lstApplStatus[0]
              }
              name="searchStatus"
            />
          </div>

          <span
            class="button-container-search"
            style={{ marginTop: "17px", marginLeft: "20px" }}
          >
            <button class="btn btn-primary icon-search">Search</button>

            <button class="btn btn-secondary" onClick={props.handleResetAppl}>
              Reset
            </button>
          </span>
        </div>
      </form>
    </ExpansionPanel>
  );
};

export default ApplSearchPanel;
