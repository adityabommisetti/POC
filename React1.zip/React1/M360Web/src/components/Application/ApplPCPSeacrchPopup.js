import React, { Component } from "react";
import {
  searchPcp,
  setPcpData as setData,
} from "../../redux/actions/ApplActions";

import Button from "@material-ui/core/Button";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import Checkbox from "@material-ui/core/Checkbox";
import DataTable from "../Home/DataTable";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import InputField from "../UI/InputField";
import Paper from "@material-ui/core/Paper";
import { Styles } from "../../assets/styles/PopupTheme";
import classNames from "classnames";
import { connect } from "react-redux";
import { PCP_SEARCH_POPUP_HEADER as header } from "../../constants/Headers/ApplicationHeaders";
import { withStyles } from "@material-ui/core/styles";
import isEmpty from "lodash/isEmpty";

class PcpSearchPopup extends Component {
  constructor(props) {
    super(props);
    this.state = {
      searchVo: {
        searchOfficeCd: this.props.data.applOtherPlanVO.officeCd,
        searchLocationId: this.props.data.applOtherPlanVO.locationId,
        searchDocName: this.props.data.applOtherPlanVO.pcpName,
        searchCurrPatient: this.props.data.applOtherPlanVO.currentPatientInd,
        searchLob: this.props.data.grpProdVO.lineOfBiz,
        searchAltOfcCode: this.props.data.applOtherPlanVO.alternateOfficeCd,
        reqDateCov: this.props.data.applPlanVO.reqDtCov,
        enrollGrpId: this.props.data.applPlanVO.enrollGrpId,
        enrollPbp: this.props.data.applPlanVO.enrollPbp,
        enrollSegment: this.props.data.applPlanVO.enrollSegment,
        enrollPlan: this.props.data.applPlanVO.enrollPlan,
        enrollProduct: this.props.data.applPlanVO.enrollProduct,
        searchNpiId: this.props.data.applOtherPlanVO.alternateOfficeCd,
      },
      selectedIndex: 0,
    };
  }

  componentDidMount() {
    if (this.props.searchResultsVo.applPlanVO.reqDtCov === "") {
      this.props.close();
      this.props.closePopup();
    } else {
      this.props.searchPcp(this.state.searchVo);
    }
  }

  onRowSelect = (index) => {
    this.setState({
      selectedIndex: index,
    });
  };

  onSubmit = async () => {
    const tableData = [...this.props.pcpData];
    const selectedVo = tableData[this.state.selectedIndex];
    let searchCurrPatnt =
      this.state.searchVo.searchCurrPatient === null
        ? "N"
        : this.state.searchVo.searchCurrPatient;
    await this.setState((prevState) => ({
      selectedVo: {
        ...selectedVo,
        pcpCurrPatnt: searchCurrPatnt,
      },
    }));
    this.props.setData(this.state.selectedVo);
    this.props.close();
  };

  reset = () => {
    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        searchOfficeCd: "",
        searchLocationId: "",
        searchDocName: "",
        searchCurrPatient: "N",
        searchNpiId: "",
      },
    }));
  };

  handleChange = (e) => {
    let value = "";
    let name = e.target.name;
    if (name === "searchCurrPatient") {
      value = e.target.checked ? "Y" : "N";
    } else {
      value = e.target.value.toUpperCase();
    }

    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value,
      },
    }));
  };

  handleOnBlur = (e) => {
    let value = "";
    let name = e.target.name;
    if (name === "searchCurrPatient") {
      value = e.target.checked ? "Y" : "N";
    } else {
      value = e.target.value.trim();
    }

    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value,
      },
    }));
  };

  render() {
    const { classes, pcpData } = this.props;
    return (
      <React.Fragment>
        <Paper
          className={classes.root}
          elevation={0}
          style={{ padding: "15px" }}
        >
          <fieldset className={classes.fieldset}>
            <legend className={classes.legend}>PCP Search</legend>
            <form autoComplete="off">
              <div className={classes.container} style={{ margin: "0px auto" }}>
                <div>
                  <InputField
                    name="searchOfficeCd"
                    id="searchOfficeCd"
                    label="Office Code"
                    value={this.state.searchVo.searchOfficeCd}
                    onChange={this.handleChange}
                    onBlur={this.handleOnBlur}
                  />
                  <div className={classes.validationMessage} />
                </div>
                {this.props.searchResultsVo.npiInd === "Y" ? (
                  <div>
                    <InputField
                      name="searchNpiId"
                      id="searchNpiId"
                      label="NPI ID"
                      value={this.state.searchVo.searchNpiId}
                      onChange={this.handleChange}
                      onBlur={this.handleOnBlur}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                ) : null}
                <div>
                  <InputField
                    name="searchLocationId"
                    id="searchOfficeCd"
                    label="Location ID"
                    value={this.state.searchVo.searchLocationId}
                    onChange={this.handleChange}
                    onBlur={this.handleOnBlur}
                  />
                  <div className={classes.validationMessage} />
                </div>
                <InputField
                  name="searchDocName"
                  id="searchOfficeCd"
                  label="Doctor Name"
                  value={this.state.searchVo.searchDocName}
                  onChange={this.handleChange}
                  onBlur={this.handleOnBlur}
                />
                <div className={classes.validationMessage} />
              </div>

              <div className={classes.container} style={{ margin: "0px auto" }}>
                <div className={classes.textField}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        style={{ width: 36, height: 36 }}
                        color="primary"
                        id="searchOfficeCd"
                        name="searchCurrPatient"
                        icon={
                          <CheckBoxOutlineBlankIcon
                            className={classes.checkBoxStyle}
                          />
                        }
                        checkedIcon={
                          <CheckBoxIcon className={classes.checkBoxStyle} />
                        }
                        checked={
                          this.state.searchVo.searchCurrPatient === "Y"
                            ? true
                            : false
                        }
                        disabled={this.state.editable}
                        onClick={this.handleChange}
                      />
                    }
                    label="Current Patient"
                    classes={{ label: classes.formLabel }}
                  />
                </div>
              </div>

              <div className={classes.div1}>
                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={(e) => {
                    e.preventDefault();
                    this.props.searchPcp(this.state.searchVo);
                  }}
                >
                  <i className="material-icons">search</i>
                </Button>

                <Button
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={this.props.close}
                >
                  <i className="material-icons">cancel</i>
                </Button>
                <Button
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={this.reset}
                >
                  <i class="material-icons">refresh</i>
                </Button>
              </div>
            </form>
          </fieldset>
        </Paper>

        <div className={classes.table}>
          <span className="AgencySearch-table">
            <DataTable
              data={!isEmpty(pcpData) ? pcpData : []}
              header={header}
              rowsPerPage={5}
              sortable={false}
              clicked={this.onRowSelect}
              index={this.state.selectedIndex}
            />
          </span>

          {pcpData && pcpData.length > 0 ? (
            <div className={classes.div1}>
              <Button
                variant="contained"
                color="primary"
                id="pcpSubmit"
                className={classNames(classes.button, classes.submit)}
                onClick={this.onSubmit}
              >
                Submit
              </Button>
            </div>
          ) : null}
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  pcpData: state.applPopupVO.pcpPopupData,
  searchResultsVo: state.applSearch.searchResultsVo,
});

const mapDispatchToProps = {
  searchPcp,
  setData,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(PcpSearchPopup));
