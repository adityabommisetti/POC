import Button from "@material-ui/core/Button";
import React from "react";

const Applbuttons = [
  { name: "MA - New Member Appl", id: "applNMA", type: "NMA" },
  { name: "PD - New Member Appl", id: "applPDP", type: "NPD" },
  { name: "MA- Contract Chg Form", id: "applCMA", type: "CMA" },
  { name: "PD- Contract Chg Form", id: "applCPD", type: "CPD" }
];

const NewApplButton = props => {
  const { classes } = props;

  let buttonList = Applbuttons.map(appl => {
    return (
      <Button
        name={appl.id}
        id={appl.id}
        key={appl.id}
        variant="contained"
        color="primary"
        onClick={() => props.newApplicationType(appl.type)}
        className={classes.button}
      >
        {appl.name}
      </Button>
    );
  });
  return (
    <div class="panel-head-container">
      <div className={classes.buttonContainer}>{buttonList}</div>
    </div>
  );
};

export default NewApplButton;
