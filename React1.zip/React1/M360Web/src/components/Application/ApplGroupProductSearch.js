import React, { Component } from "react";
import {
  groupProdSearch,
  setGroupProdData,
} from "../../redux/actions/ApplActions";

import Button from "@material-ui/core/Button";
import DataTable from "../Home/DataTable";
import InputField from "../UI/InputField";
import Paper from "@material-ui/core/Paper";
import { Styles } from "../../assets/styles/PopupTheme";
import classNames from "classnames";
import { connect } from "react-redux";
import { GROUP_TABLE_HEADER as header } from "../../constants/Headers/ApplicationHeaders";
import { withStyles } from "@material-ui/core/styles";
import isEmpty from "lodash/isEmpty";

class ProductSearch extends Component {
  constructor(props) {
    super(props);
    this.state = {
      searchVo: {
        group: this.props.data.grpProdVO.enrollGroupName,
        prod: this.props.data.grpProdVO.enrollProdName,
        plan: this.props.data.applPlanVO.enrollPlan,
        pbp: this.props.data.applPlanVO.enrollPbp,
        segment: this.props.data.applPlanVO.enrollSegment,
        zip5:
          this.props.data.applVO.outOfArea === "E"
            ? ""
            : this.props.data.applAddress.perZip5,
        zip4:
          this.props.data.applVO.outOfArea === "E"
            ? ""
            : this.props.data.applAddress.perZip4,
        groupId: this.props.data.applPlanVO.enrollGrpId,
        prodId: this.props.data.applPlanVO.enrollProduct,
        PerState: this.props.data.applAddress.perState,
        covDt: this.props.data.applPlanVO.reqDtCov,
        OutOfArea: this.props.data.applVO.outOfArea,
        PerCounty: this.props.data.applAddress.perCounty,
        applType: this.props.data.applVO.applType,
      },

      selectedIndex: 0,
      data: this.props.product,
      message: null,
      reset: false,
      searchFlag: false,
    };
  }

  componentDidMount() {
    if (this.props.data.applAddress.perZip5 === "") {
      this.props.close();
      this.props.closePopup("Please Enter Zip Code");
    } else if (this.props.data.applPlanVO.reqDtCov === "") {
      this.props.close();
      this.props.closePopup("Please enter Requested Date of Cov");
    } else if (
      this.props.data.applVO.mbrBirthDt === "" &&
      this.props.data.applVO.mbrLastName === ""
    ) {
      this.props.close();
      this.props.closePopup("Please enter BirthDate or LastName");
    } else if (this.props.data.applVO.mbrHicNbr === "") {
      this.props.close();
      this.props.closePopup("Please enter Medicare ID");
    } else {
      this.props.groupProdSearch(this.state.searchVo);
    }
  }

  onRowSelect = (index, page) => {
    this.setState({
      selectedIndex: index,
      page: page,
    });
  };

  onSubmit = () => {
    const tableData = [...this.props.searchData];
    const selectedVo = tableData[this.state.selectedIndex];
    this.props.setGroupProdData(selectedVo);
    this.props.close();
  };

  reset = () => {
    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        groupId: "",
        group: "",
        prod: "",
        prodId: "",
        plan: "",
        pbp: "",
        segment: "",
      },
    }));
  };

  handleNumberChange = (e) => {
    let value = e.target.value.replace(/[^0-9]/g, "");
    let name = e.target.name;
    this.setValue(name, value);
  };

  handleChange = (e) => {
    let value = e.target.value;
    let name = e.target.name;
    if (value) {
      value = value.toUpperCase();
    }
    this.setValue(name, value);
  };

  handleOnBlur = (e) => {
    let value = e.target.value.trim();
    let name = e.target.name;
    if (value) {
      value = value.trim();
    }
    this.setValue(name, value);
  };

  setValue = (name, value) => {
    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value,
      },
    }));
  };

  search = () => {
    this.setState({ searchFlag: true });
  };

  checked = () => {
    this.setState({
      reset: !this.state.reset,
    });
  };

  render() {
    const { classes, searchData } = this.props;

    return (
      <React.Fragment>
        <Paper className={classes.root} elevation={0}>
          <fieldset className={classes.fieldset}>
            <legend className={classes.legend}>Product Search</legend>
            <form
              //className={classes.container}
              autoComplete="off"
              onSubmit={(e) => this.search(e)}
            >
              <div className={classes.centerAlign}>
                <div className={classes.inlineBlock}>
                  <div
                    className={classes.container}
                    style={{ margin: "0px auto" }}
                  >
                    <div>
                      <InputField
                        name="group"
                        label="Group"
                        className={classes.textField}
                        margin="normal"
                        InputLabelProps={{ className: classes.label }}
                        value={this.state.searchVo.group}
                        maxLength={5}
                        onChange={this.handleChange}
                        onBlur={this.handleOnBlur}
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="prod"
                        label="Product"
                        width="450px"
                        className={classes.textField}
                        margin="normal"
                        InputLabelProps={{ className: classes.label }}
                        value={this.state.searchVo.prod}
                        maxLength={5}
                        onChange={this.handleChange}
                        onBlur={this.handleOnBlur}
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="groupId"
                        label="Group ID"
                        className={classes.textField}
                        margin="normal"
                        InputLabelProps={{ className: classes.label }}
                        value={this.state.searchVo.groupId}
                        maxLength={5}
                        onChange={this.handleChange}
                        onBlur={this.handleOnBlur}
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="prodId"
                        label="Product ID"
                        className={classes.textField}
                        margin="normal"
                        InputLabelProps={{ className: classes.label }}
                        value={this.state.searchVo.prodId}
                        maxLength={5}
                        onChange={this.handleChange}
                        onBlur={this.handleOnBlur}
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="plan"
                        label="Plan"
                        className={classes.textField}
                        margin="normal"
                        InputLabelProps={{ className: classes.label }}
                        value={this.state.searchVo.plan}
                        maxLength={5}
                        onChange={this.handleChange}
                        onBlur={this.handleOnBlur}
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="pbp"
                        label="PBP"
                        className={classes.textField}
                        margin="normal"
                        InputLabelProps={{ className: classes.label }}
                        value={this.state.searchVo.pbp}
                        maxLength={3}
                        onChange={this.handleNumberChange}
                        onBlur={this.props.handleOnBlur}
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <InputField
                        name="segment"
                        label="Segment"
                        className={classes.textField}
                        margin="normal"
                        InputLabelProps={{ className: classes.label }}
                        value={this.state.searchVo.segment}
                        maxLength={5}
                        onChange={this.handleNumberChange}
                        onBlur={this.props.handleOnBlur}
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <span class="label-container">
                      <label for="zip2">Zip</label>
                      <br />
                      <div className="product-search">
                        <input
                          type="text"
                          class="form-field zip input-popup"
                          name="zip5"
                          id="zip2"
                          disabled
                          maxLength={5}
                          value={this.state.searchVo.zip5}
                          onChange={this.handleChange}
                          onBlur={this.handleOnBlur}
                        />
                        <input
                          type="text"
                          class="form-field zip"
                          id="zip2"
                          name="zip4"
                          disabled
                          maxLength={4}
                          value={this.state.searchVo.zip4}
                          onChange={this.handleChange}
                          onBlur={this.handleOnBlur}
                        />
                      </div>
                    </span>
                  </div>

                  <div className={classes.div1}>
                    <Button
                      type="submit"
                      variant="contained"
                      color="primary"
                      className={classes.button}
                      onClick={(e) => {
                        e.preventDefault();
                        this.props.groupProdSearch(this.state.searchVo);
                      }}
                    >
                      <i className="material-icons">search</i>
                    </Button>

                    <Button
                      variant="contained"
                      color="primary"
                      className={classes.button}
                      onClick={this.props.close}
                    >
                      <i className="material-icons">cancel</i>
                    </Button>
                    <Button
                      variant="contained"
                      color="primary"
                      className={classes.button}
                      onClick={this.reset}
                    >
                      <i class="material-icons">refresh</i>
                    </Button>
                  </div>
                </div>
              </div>
            </form>
          </fieldset>
        </Paper>

        <DataTable
          data={!isEmpty(searchData) ? searchData : []}
          header={header}
          rowsPerPage={5}
          sortable={false}
          clicked={this.onRowSelect}
          index={this.state.selectedIndex}
          pageNo={this.state.page}
        />

        {this.props.searchData && this.props.searchData.length > 0 ? (
          <div className={classes.buttonmargin}>
            <Button
              variant="contained"
              color="primary"
              className={classNames(classes.button, classes.submit)}
              onClick={this.onSubmit}
              id="grpPrdctSubmit"
            >
              Submit
            </Button>
          </div>
        ) : null}
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  searchData: state.applPopupVO.productSearchData,
  data: state.applSearch.searchResultsVo,
});

const mapDispatchToProps = {
  groupProdSearch,
  setGroupProdData,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(ProductSearch));
