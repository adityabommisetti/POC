import "../../assets/css/comments.css";

import {
  PresetNotes,
  addComment,
  setAuthZip,
  setAuthZipState,
} from "../../redux/actions/ApplActions";
import React, { Component } from "react";
import Autocomplete1 from "../UI/Select";
import * as ActionTypes from "../../redux/types/ActionType";
import Button from "@material-ui/core/Button";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import Checkbox from "@material-ui/core/Checkbox";
import CityZipSerachPopup from "./ApplCityZipSearch";
import DataTable from "../Home/DataTable";
import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormLabel from "@material-ui/core/FormLabel";
import InputField from "../UI/InputField";
import Modal from "../UI/Modal/Modal";
import Paper from "@material-ui/core/Paper";
import Popup from "reactjs-popup";
import Radio from "@material-ui/core/Radio";
import RadioButtonCheckedIcon from "@material-ui/icons/RadioButtonChecked";
import RadioButtonUncheckedIcon from "@material-ui/icons/RadioButtonUnchecked";
import RadioGroup from "@material-ui/core/RadioGroup";
import { Styles } from "../../assets/styles/Theme";
import TextField from "@material-ui/core/TextField";
import { connect } from "react-redux";
import { COMMENTS_HEADER as header } from "../../constants/Headers/MemberHeaders";
import { withStyles } from "@material-ui/core/styles";
import checkErrorField from "../../utils/CheckErrorField";
import isEmpty from "lodash/isEmpty";

var moment = require("moment");

const INITIAL_STATE = {
  presetNotes: "",
  created: "",
  user: "",
  comments: "",
  editable: true,
  presetNotes1: "",
  presetNotes2: "",
};

class CommentsSignature extends Component {
  constructor(props) {
    super(props);

    this.state = {
      authRepZip5: "",
      editable: false,
      commentsVo: INITIAL_STATE,
      presetCommentFlag: false,
      modified: false,
      isNewSegment: false,
      presetNotesSelected: false,
      oldCommentsVo: {},
      data:
        this.props.newCommentList.length > 0
          ? [
              ...this.props.newCommentList,
              ...this.props.searchResultsVo.applCommentsList,
            ]
          : [...this.props.searchResultsVo.applCommentsList],
      comment: "",
      disableComments: false,
      radio: "",
      value: "",
      presetKey: "",
      disablepreset: false,
      closePopup: false,
      selectedRowIndex: 0,
      message: "",
    };
  }
  setAuthZip = (data) => {
    this.props.setAuthZipState(data);
  };
  componentDidUpdate() {
    if (document.getElementById("outlined-textarea")) {
      document.getElementById("outlined-textarea").style.color = "black";
    }
    const { authRepZip5 } = this.props.searchResultsVo.applAddress;
    if (
      authRepZip5 &&
      authRepZip5.length === 5 &&
      this.state.authRepZip5 !== authRepZip5
    ) {
      let value = authRepZip5.replace(/[^0-9]/g, "");
      this.props.setAuthZip(value);
      this.setState({ authRepZip5: authRepZip5 });
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (
      nextProps.searchResultsVo.applVO.applId === "" &&
      this.props.searchResultsVo.applVO.applType !==
        nextProps.searchResultsVo.applVO.applType
    ) {
      this.setState({
        comment: "",
        disableComments: false,
      });
    } else if (
      this.props.searchResultsVo.applVO.applId !==
      nextProps.searchResultsVo.applVO.applId
    ) {
      this.setState({
        comment: "",
        disableComments: false,
        data:
          nextProps.newCommentList.length > 0
            ? [
                ...nextProps.newCommentList,
                ...nextProps.searchResultsVo.applCommentsList,
              ]
            : [...nextProps.searchResultsVo.applCommentsList],
      });
    }

    if (
      nextProps.searchResultsVo.applVO.applType === "NMA" ||
      nextProps.searchResultsVo.applVO.applType === "NPD" ||
      nextProps.searchResultsVo.applVO.applType === "CMA" ||
      nextProps.searchResultsVo.applVO.applType === "CPD"
    ) {
      this.setState({
        presetNotesSelected: false,
        commentsVo: {
          ...this.state.commentsVo,
          presetNotes: "",
        },
      });
    }
    this.setState({
      presetCommentFlag: this.props.disabled,
      isNewSegment: this.props.disabled,
    });
  }

  handlechange = (name) => async (event) => {
    let value = event.target.value;
    await this.setState((prevState) => ({
      commentsVo: {
        ...prevState.commentsVo,
        [name]: value.toUpperCase(),
      },
      modified: true,
    }));
  };

  handleOnBlur = (event) => {
    let value = event.target.value.trim();
    let name = event.target.name;
    this.setState((prevState) => ({
      commentsVo: {
        ...prevState.commentsVo,
        [name]: value,
      },

      comment: name === "comment" ? value.trim() : prevState.comment,
      modified: true,
    }));
  };

  Fieldchange = (e) => {
    this.setState({ comment: e.target.value });
  };

  handleChangeSearchSelectAuto = async (data, name) => {
    let value = data.value;
    let label = data.label;

    if (label === "Select") {
      label = "";
    }
    await this.setState((prevState) => ({
      commentsVo: {
        ...prevState.commentsVo,
        [name]: value,
        presetNotes1: label,
        presetNotes2: value,
      },
      presetKey: label,
      modified: true,
      comment: label + " : " + value + " : ",
    }));
  };

  goBack = () => {
    this.setState({
      isNewSegment: false,
      presetNotesSelected: false,
      editable: false,
      modified: false,
      commentsVo: { ...this.state.oldCommentsVo },
    });
  };

  createNewSegment = () => {
    this.setState({
      value: "",
      radio: "",
      editable: true,
      presetCommentFlag: true,
      presetNotesSelected: false,
      isNewSegment: true,
      disableComments: true,
      commentsVo: {
        ...this.state.commentsVo,
        ...INITIAL_STATE,
      },
    });
  };

  selectRow = (index, page) => {
    this.setState({
      selectedRowIndex: index,
      page: page,
    });

    const data = [
      ...this.props.newCommentList,
      ...this.props.searchResultsVo.applCommentsList,
    ];
    const selectedVo = data[index];

    this.setState(() => ({
      data: data,
      commentsVo: { ...selectedVo },
      oldCommentsVo: { ...selectedVo },
      editable: false,
      isNewSegment: false,
      presetNotesSelected: false,
      modified: false,
      disableComments: true,
    }));
  };

  presetNotes = (event) => {
    event.preventDefault();
    this.setState({
      editable: true,
      radio: "",
      presetCommentFlag: true,
      presetNotesSelected: true,
      isNewSegment: false,
      commentsVo: {
        ...this.state.commentsVo,
        ...INITIAL_STATE,
      },
    });
  };
  handleRadiochange = async (event) => {
    this.setState({ radio: event.target.value });
    if (
      isEmpty(this.state.commentsVo.presetNotes) &&
      event.target.value === "D"
    ) {
      alert("Please select a value from dropdown to be delete");
    }
    if (
      isEmpty(this.state.commentsVo.presetNotes) &&
      event.target.value === "M"
    ) {
      alert("Please select a value from dropdown to be modified");
      await this.setState({
        commentsVo: { ...this.state.commentsVo, presetNotes2: "" },
      });
    
    }
  };
  addNewComment = async (event) => {
    let commentsVo = this.state.commentsVo;
    let message = "";
    const { searchResultsVo } = this.props;
    const status =
      searchResultsVo.applVO.currStatus === "CANCELED"
        ? "CANCELED"
        : searchResultsVo.applVO.currStatus === "COMPLETED"
        ? "COMPLETED"
        : "DENIED";

    let updateState = true;

    if (this.state.radio === "" && this.state.presetNotesSelected) {
      updateState = false;
      alert("No radio button choosen");
      return;
    }
    /* if(isEmpty(this.state.commentsVo.presetNotes  && updateState)){
      updateState = false
      alert("Please select a value from dropdown to be modified")
    }*/
    // if (this.state.presetNotesSelected ) {
    //   alert("Preset Notes cannot be blank");
    //   updateState = false
    //   return
    // } else
    if (this.state.radio === "A") {
      if (
        this.state.commentsVo.presetNotes1 === "" &&
        this.state.commentsVo.presetNotes2 === ""
      ) {
        message = "Please Enter Preset Notes";
        updateState = false;
      } else if (
        searchResultsVo.applVO.currStatus === "CANCELED" ||
        searchResultsVo.applVO.currStatus === "DENIEDETYP" ||
        searchResultsVo.applVO.currStatus === "DENIEDELG" ||
        searchResultsVo.applVO.currStatus === "DENIEDOTHR" ||
        searchResultsVo.applVO.currStatus === "COMPLETED"
      ) {
        message =
          "Cannot Save the Comment!!" + "\n" + "Current Status is " + status;
      } else {
        await this.props.PresetNotes(
          this.state.radio,
          commentsVo.presetNotes1,
          commentsVo.presetNotes2,
          commentsVo.presetNotes
        );

        message = ActionTypes.ADD;
        this.setState({
          presetNotesSelected: false,
          radio: "",
          editable: false,
          isNewSegment: false,
          commentsVo: {
            ...this.state.commentsVo,
            presetNotes: "",
          },
        });
      }

      this.setState({
        closePopup: true,
        message: message,
      });
    } else if (this.state.radio === "M") {
      if (
        this.state.commentsVo.presetNotes1 === "" &&
        this.state.commentsVo.presetNotes2 === ""
      ) {
        message = "Please Enter preset Notes";
        updateState = false;
      } else if (
        searchResultsVo.applVO.currStatus === "CANCELED" ||
        searchResultsVo.applVO.currStatus === "DENIEDETYP" ||
        searchResultsVo.applVO.currStatus === "DENIEDELG" ||
        searchResultsVo.applVO.currStatus === "DENIEDOTHR" ||
        searchResultsVo.applVO.currStatus === "COMPLETED"
      ) {
        message =
          "Cannot Save the Comment!!" + "\n" + "Current Status is " + status;
      } else if (isEmpty(this.state.commentsVo.presetNotes)) {
        updateState = false;
        message = "Please select a value from dropdown to be modified";
      } else {
        if (updateState) {
          await this.props.PresetNotes(
            this.state.radio,
            this.state.commentsVo.presetNotes1,
            this.state.commentsVo.presetNotes2,
            this.state.presetKey
          );

          message = ActionTypes.UPDATE;
          await this.setState({
            presetNotesSelected: false,
            radio: "",
            editable: false,
            isNewSegment: false,
            commentsVo: {
              ...this.state.commentsVo,
              presetNotes: "",
            },
          });
        }
      }

      await this.setState({
        closePopup: true,
        message: message,
        //
      });
    } else if (this.state.radio === "D") {
      if (
        this.state.commentsVo.presetNotes1 === "" &&
        this.state.commentsVo.presetNotes2 === ""
      ) {
        message = "Please Enter Preset Notes";
        updateState = false;
      } else if (
        searchResultsVo.applVO.currStatus === "CANCELED" ||
        searchResultsVo.applVO.currStatus === "DENIEDETYP" ||
        searchResultsVo.applVO.currStatus === "DENIEDELG" ||
        searchResultsVo.applVO.currStatus === "DENIEDOTHR" ||
        searchResultsVo.applVO.currStatus === "COMPLETED"
      ) {
        message =
          "Cannot Save the Comment!!" + "\n" + "Current Status is " + status;
        updateState = false;
      } else if (isEmpty(this.state.commentsVo.presetNotes)) {
        updateState = false;
        message = "Please select a value from dropdown to be delete";
      } else {
        if (updateState) {
          await this.props.PresetNotes(
            this.state.radio,
            this.state.commentsVo.presetNotes1,
            this.state.commentsVo.presetNotes2,
            this.state.presetKey
          );
          message = ActionTypes.DELETE;
          await this.setState({
            presetNotesSelected: false,
            radio: "",
            editable: false,
            isNewSegment: false,
            commentsVo: {
              ...this.state.commentsVo,
              presetNotes: "",
            },
          });
        }
      }

      await this.setState({
        closePopup: true,
        message: message,
      });
    }

    event.preventDefault();

    if (!this.state.comment) {
      if (this.state.isNewSegment === true) {
        this.setState({
          closePopup: true,
          message: "Enter some comment to save",
        });
      }
    } else if (
      searchResultsVo.applVO.currStatus === "CANCELED" ||
      searchResultsVo.applVO.currStatus === "DENIEDETYP" ||
      searchResultsVo.applVO.currStatus === "DENIEDELG" ||
      searchResultsVo.applVO.currStatus === "DENIEDOTHR" ||
      searchResultsVo.applVO.currStatus === "COMPLETED"
    ) {
      this.setState({
        closePopup: true,
        message:
          "Cannot Save the Comment!!" + "\n" + "Current Status is " + status,
      });
    } else {
      const newCommentVo = {
        createTime: moment().format("YYYY-MM-DD HH:mm:ss.SSS"),
        createUserId: this.props.loginVo.userId,
        applComments: this.state.comment,
        applicationId: this.props.searchResultsVo.applVO.applId,
        insert: "Y",
      };

      if (this.state.isNewSegment) {
        await this.props.addComment(newCommentVo);
      }
      //

      //
      this.setState({ selectedRowIndex: 0 });
      this.setState({
        comment: "",
        isNewSegment: false,
        data: [
          ...this.props.newCommentList,
          ...this.props.searchResultsVo.applCommentsList,
        ],
      });
    }
  };

  updateComments = (event) => {
    event.preventDefault();
  };

  modalClosed = () => {
    this.setState({ closePopup: false });
  };

  render() {
    const {
      classes,
      originalApplication,
      searchResultsVo,
      dropdowns,
      servicesEnabled,
    } = this.props;
    const applVO = searchResultsVo.applVO;

    const applAddress = searchResultsVo.applAddress;
    const authRepState = applAddress.authRepState
      ? applAddress.authRepState.trim()
      : "";

    return (
      <React.Fragment>
        <Modal
          dialogTitle={this.state.comment !== "" ? "Comments" : "Preset Notes"}
          message={this.state.message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Paper elevation={0} className={classes.card}>
          <div class="panel-body">
            <div class="twin-boxes">
              <div class="panel-subhead expanded2">
                <h3>Application Signature</h3>
              </div>
              <div className={classes.container}>
                <div>
                  <InputField
                    name="receiptDate"
                    label="Application Received Date"
                    id="receiptDate"
                    maxLength={10}
                    disabled={originalApplication}
                    value={applVO.receiptDate}
                    placeholder="MM/DD/YYYY"
                    onClick={this.props.handleDates("#receiptDate", "applVO")}
                    isErrorField={checkErrorField(
                      "receiptDate",
                      searchResultsVo
                    )}
                    onChange={this.props.handleDateChange(
                      "receiptDate",
                      "applVO"
                    )}
                    //  onBlur={this.props.dateChange}
                  />
                  <div className={classes.validationMessage} />
                </div>
              </div>
              <div className={classes.container}>
                <div className="signatureCheck">
                  <FormControl
                    component="fieldset"
                    className={classes.formControl}
                  >
                    <FormLabel component="legend" className={classes.legend}>
                      Signature On File
                    </FormLabel>
                    <RadioGroup
                      aria-label="Resident"
                      name="Resident"
                      className={classes.group}
                      value={applVO.signOnFile}
                      id="receiptDate"
                      onChange={this.props.handlechange("signOnFile", "applVO")}
                    >
                      <FormControlLabel
                        value="Y"
                        control={
                          <Radio
                            color="primary"
                            disabled={originalApplication}
                            icon={<RadioButtonUncheckedIcon fontSize="small" />}
                            checkedIcon={
                              <RadioButtonCheckedIcon fontSize="small" />
                            }
                          />
                        }
                        label="Yes"
                      />
                      <FormControlLabel
                        value="N"
                        control={
                          <Radio
                            color="primary"
                            disabled={originalApplication}
                            icon={<RadioButtonUncheckedIcon fontSize="small" />}
                            checkedIcon={
                              <RadioButtonCheckedIcon fontSize="small" />
                            }
                          />
                        }
                        label="No"
                      />
                    </RadioGroup>
                  </FormControl>
                </div>
                <div style={{ marginRight: "120px" }}>
                  <InputField
                    name="signDt"
                    label="Application Signature Date"
                    id="signDt"
                    maxLength={10}
                    disabled={
                      applVO.signOnFile === "N"
                        ? true
                        : false || originalApplication
                    }
                    value={applVO.signDt ? applVO.signDt : ""}
                    placeholder="MM/DD/YYYY"
                    onClick={this.props.handleDates("#signDt", "applVO")}
                    onChange={this.props.handleDateChange("signDt", "applVO")}
                    isErrorField={checkErrorField("signDt", searchResultsVo)}
                    //   onBlur={this.props.dateChange}
                    required
                  />
                  <div className={classes.validationMessage}>
                    {this.props.searchResultsVo.applVO.applStatus !== "HOLD" ? (
                      <div>
                        {this.props.validator.message(
                          "signDate",
                          applVO.signDt,
                          "date_format|required"
                        )}
                      </div>
                    ) : null}
                  </div>
                </div>
              </div>
              <div className={classes.container}>
                <div className={classes.textField}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        style={{ width: 16, height: 16 }}
                        className="OverrideChkbox"
                        color="primary"
                        icon={
                          <CheckBoxOutlineBlankIcon
                            className={classes.checkBoxStyle}
                          />
                        }
                        checkedIcon={
                          <CheckBoxIcon className={classes.checkBoxStyle} />
                        }
                        id="signOvrrdDt"
                        checked={applVO.signOvrrdDt === "Y" ? true : false}
                        disabled={originalApplication}
                        onChange={this.props.handleCheckbox(
                          "signOvrrdDt",
                          "applVO"
                        )}
                      />
                    }
                    label="Override Signature Date"
                    classes={{ label: classes.formLabel }}
                  />
                </div>
              </div>
            </div>

            <div class="twin-boxes">
              <div class="panel-subhead expanded2" style={{ width: "107%" }}>
                <h3>Authorized Representative</h3>
              </div>
              <div class="form-panel">
                <div className={classes.container}>
                  <div>
                    <InputField
                      name="authRepFirstName"
                      label="First Name"
                      id="authRepFirstName"
                      maxLength={24}
                      disabled={originalApplication}
                      value={
                        applVO.authRepFirstName ? applVO.authRepFirstName : ""
                      }
                      onChange={this.props.handlechange(
                        "authRepFirstName",
                        "applVO"
                      )}
                      isErrorField={checkErrorField(
                        "authRepFirstName",
                        searchResultsVo
                      )}
                      onBlur={this.props.handleOnBlur("applVO")}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="authRepMidName"
                      label="Middle Name"
                      maxLength={1}
                      disabled={originalApplication}
                      value={applVO.authRepMidName ? applVO.authRepMidName : ""}
                      onChange={this.props.handlechange(
                        "authRepMidName",
                        "applVO"
                      )}
                      onBlur={this.props.handleOnBlur("applVO")}
                      isErrorField={checkErrorField(
                        "authRepMidName",
                        searchResultsVo
                      )}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="authRepLastName"
                      label="Last Name"
                      id="authRepLastName"
                      maxLength={35}
                      disabled={originalApplication}
                      value={
                        applVO.authRepLastName ? applVO.authRepLastName : ""
                      }
                      lineHeight={1}
                      onChange={this.props.handlechange(
                        "authRepLastName",
                        "applVO"
                      )}
                      onBlur={this.props.handleOnBlur("applVO")}
                      isErrorField={checkErrorField(
                        "authRepLastName",
                        searchResultsVo
                      )}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="authRepStreet"
                      label="Address"
                      width={"380px"}
                      id="authRepStreet"
                      maxLength={50}
                      lineHeight={1}
                      disabled={originalApplication}
                      value={
                        applAddress.authRepStreet
                          ? applAddress.authRepStreet
                          : ""
                      }
                      onChange={this.props.handlechange(
                        "authRepStreet",
                        "applAddress"
                      )}
                      onBlur={this.props.handleOnBlur("applAddress")}
                      isErrorField={checkErrorField(
                        "authRepStreet",
                        searchResultsVo
                      )}
                    />

                    <div className={classes.validationMessage}>
                      {this.props.validator.message(
                        "Address",
                        [applAddress.authRepZip5, applAddress.authRepStreet],
                        "if_zip_entered"
                      )}
                    </div>
                  </div>
                  <div />
                  <div className={classes.citydropdown}>
                    <InputField
                      name="authRepCity"
                      label="City"
                      id="authRepCity"
                      maxLength={20}
                      width="250px"
                      disabled={originalApplication}
                      value={
                        applAddress.authRepCity ? applAddress.authRepCity : ""
                      }
                      onChange={this.props.handlechange(
                        "authRepCity",
                        "applAddress"
                      )}
                      isErrorField={checkErrorField(
                        "authRepCity",
                        searchResultsVo
                      )}
                      onBlur={this.props.handleOnBlur("applAddress")}
                    />
                    <div className={classes.validationMessage}>
                      {
                        <div>
                          {this.props.validator.message(
                            "City",
                            [applAddress.authRepZip5, applAddress.authRepCity],
                            "if_zip_entered"
                          )}
                        </div>
                      }
                    </div>
                  </div>
                  <div className={classes.Select2}>
                    <Autocomplete1
                      handleChange={this.props.handlechangeAuto}
                      vo="applAddress"
                      margin="0px"
                      label="State"
                      options={dropdowns.lstStates}
                      defaultValue={dropdowns.lstStates}
                      value={
                        dropdowns.lstStates.filter(
                          (data) => data.value === applAddress.authRepState
                        )[0]
                      }
                      name="authRepState"
                      disabled={originalApplication}
                    />
                    {/* <div className={classes.validationMessageSelect} /> */}
                    <div className={classes.validationMessageSelect}>
                      {
                        <div>
                          {this.props.validator.message(
                            "State",
                            [applAddress.authRepZip5, authRepState],
                            "if_zip_entered"
                          )}
                        </div>
                      }
                    </div>
                  </div>
                  <div style={{ marginRight: "-25px" }}>
                    <span class="label-container">
                      <label for="zip2">Zip</label>
                      <br />
                      <div className="panel-signature">
                        <input
                          type="text"
                          class="form-field zip"
                          id="authRepZip5"
                          maxLength={5}
                          value={
                            applAddress.authRepZip5
                              ? applAddress.authRepZip5
                              : ""
                          }
                          disabled={originalApplication}
                          onChange={this.props.handleNumber(
                            "authRepZip5",
                            "applAddress"
                          )}
                          style={{
                            backgroundColor: checkErrorField(
                              "authRepZip5",
                              searchResultsVo
                            )
                              ? "yellow"
                              : null,
                          }}
                        />
                        <input
                          type="text"
                          class="form-field zip input-popup"
                          id="authRepZip4"
                          maxLength={4}
                          value={
                            applAddress.authRepZip4
                              ? applAddress.authRepZip4
                              : ""
                          }
                          disabled={originalApplication}
                          onChange={this.props.handleNumber(
                            "authRepZip4",
                            "applAddress"
                          )}
                          style={{
                            backgroundColor: checkErrorField(
                              "authRepZip4",
                              searchResultsVo
                            )
                              ? "yellow"
                              : null,
                          }}
                        />

                        {!originalApplication ? (
                          <Popup
                            className={classes.mobileWidth}
                            modal
                            trigger={
                              <span class="more-info" id="comments-popup" />
                            }
                            position="right center"
                          >
                            {(close) => (
                              <div>
                                <CityZipSerachPopup
                                  zip5={applAddress.authRepZip5}
                                  zip4={applAddress.authRepZip4}
                                  setData={this.setAuthZip}
                                  close={close}
                                />
                              </div>
                            )}
                          </Popup>
                        ) : null}
                      </div>
                    </span>
                  </div>
                  <div>
                    <InputField
                      name="authRepPhone"
                      label="Phone"
                      id="authRepPhone"
                      maxLength={12}
                      disabled={originalApplication}
                      value={
                        applAddress.authRepPhone ? applAddress.authRepPhone : ""
                      }
                      onChange={this.props.handleNumberChange(
                        "authRepPhone",
                        "applAddress"
                      )}
                      isErrorField={checkErrorField(
                        "authRepPhone",
                        searchResultsVo
                      )}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div className={classes.Select2}>
                    <Autocomplete1
                      handleChange={this.props.handlechangeAuto}
                      vo="applVO"
                      margin="0px"
                      width="200px"
                      label="Relationship to Enrollee"
                      options={dropdowns.lstRelations}
                      defaultValue={dropdowns.lstRelations}
                      value={
                        dropdowns.lstRelations.filter(
                          (data) => data.value === applVO.authRepRelation
                        )[0]
                      }
                      name="authRepRelation"
                      disabled={originalApplication}
                    />
                    <div className={classes.validationMessageSelect} />
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* </form> */}
          <div
            className={classes.applicationSectionHeading}
            style={{ marginBottom: "38px" }}
          >
            <span> Application Comments</span>
          </div>
          {searchResultsVo.applCommentsList.length +
            this.props.newCommentList.length >
          0 ? (
            <DataTable
              data={[
                ...this.props.newCommentList,
                ...searchResultsVo.applCommentsList,
              ]}
              header={header}
              sortable={false}
              rowsPerPage={3}
              sortableHeader={true}
              clicked={this.selectRow}
              index={this.state.selectedRowIndex}
            />
          ) : null}
          {!originalApplication ? (
            <div style={{ marginTop: "39px" }}>
              <div className={classes.buttonContainerApplComt}>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={this.presetNotes}
                  className={classes.button}
                  id="preNotes"
                >
                  Preset Notes
                </Button>

                <Button
                  variant="contained"
                  color="primary"
                  onClick={this.createNewSegment}
                  className={classes.button}
                  id="newCmmnts"
                >
                  Add Comment
                </Button>
                {!servicesEnabled.includes("EEUP") ? (
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={this.addNewComment}
                    className={classes.button}
                    disabled={!this.state.presetCommentFlag}
                    id="update"
                  >
                    Save
                  </Button>
                ) : null}
              </div>
              <div class="panel-body" style={{ marginTop: "-66px" }}>
                <div class="form-panel">
                  <div
                    style={{
                      width: "730px",
                      paddingLeft: "24px",
                      marginLeft: "-20px",
                    }}
                  >
                    <Autocomplete1
                      handleChange={this.handleChangeSearchSelectAuto}
                      // margin='0px'
                      width="500px"
                      label="PRESET NOTE"
                      options={dropdowns.preSetNoteList}
                      defaultValue={{ label: "Select", value: "" }}
                      value={
                        dropdowns.preSetNoteList.filter(
                          (data) =>
                            data.value === this.state.commentsVo.presetNotes
                        )[0]
                      }
                      name="presetNotes"
                      disabled={originalApplication}
                    />
                  </div>
                  <br></br>

                  <div className={classes.validationMessage} />
                </div>
                {!this.state.presetNotesSelected && this.state.isNewSegment ? (
                  <div>
                    <TextField
                      id="outlined-textarea"
                      name="comment"
                      autoFocus
                      placeholder="Enter Comments (Max 255 characters)"
                      multiline
                      rows="2"
                      style={{
                        width: "85%",
                        height: "75px",
                        marginBottom: "40px",
                        marginLeft: "0px",
                        backgroundColor: "#FFFFFF",
                        border: "1px solid rgba(81, 203, 238, 1)",
                      }}
                      className={classes.textField}
                      inputProps={{ maxLength: 255 }}
                      onChange={(e) => this.Fieldchange(e)}
                      onBlur={this.handleOnBlur}
                      value={
                        this.state.isNewSegment
                          ? this.state.comment
                          : this.state.data.length > 0
                          ? this.state.data[this.state.selectedRowIndex]
                              .applComments
                          : null
                      }
                      margin="none"
                      variant="outlined"
                      disabled={this.state.isNewSegment ? false : true}
                    />
                    <div className={classes.commentsValidationMessage} />
                  </div>
                ) : null}
                {this.state.presetNotesSelected ? (
                  <div>
                    <div className="commentOptionsAppl">
                      <FormControl
                        component="fieldset"
                        className={classes.formControl1}
                      >
                        <RadioGroup
                          row
                          value={this.state.radio}
                          onChange={this.handleRadiochange}
                        >
                          <FormControlLabel
                            // className={classes.formControl1}
                            value="A"
                            control={<Radio color="primary" />}
                            label="Add"
                            id="add"
                            disabled={!this.state.presetNotesSelected}
                            // onClick={this.radioCLick}
                          />
                          <FormControlLabel
                            value="M"
                            control={<Radio color="primary" />}
                            label="Modify"
                            id="modify"
                            //onChange={this.handleRadiochange("radioSelected")}
                            disabled={!this.state.presetNotesSelected}
                          />
                          <FormControlLabel
                            value="D"
                            control={<Radio color="primary" />}
                            label="Delete"
                            id="delete"
                            //onChange={this.handleRadiochange("radioSelected")}
                            disabled={!this.state.presetNotesSelected}
                          />
                        </RadioGroup>
                      </FormControl>
                    </div>
                    <br></br>
                    <InputField
                      classes={{ multiline: classes.preset }}
                      name="presetNotes1"
                      id="presetNotes1"
                      label="PRESET NOTE"
                      multiline={true}
                      cols={12}
                      colsMax={12}
                      rows={2}
                      width="570px"
                      rowsMax={2}
                      maxLength={65}
                      value={
                        this.state.commentsVo.presetNotes1
                          ? this.state.commentsVo.presetNotes1
                          : ""
                      }
                      onChange={this.handlechange("presetNotes1")}
                      onBlur={this.handleOnBlur}
                      disabled={!this.state.editable}
                      isErrorField={checkErrorField(
                        "presetNotes1",
                        searchResultsVo
                      )}
                      margin="none"
                    />
                    <br></br>
                    <div style={{ paddingLeft: "24px" }}>
                      {" "}
                      <label
                        style={{
                          color: "#053674",
                          marginBottom: "0",
                          lineHeight: "normal",
                          display: "inline-block",
                        }}
                      >
                        PRESET NOTE LONG DESC.
                      </label>
                      <br></br>
                      <TextField
                        id="outlined-textarea"
                        name="presetNotes2"
                        autoFocus
                        placeholder="Enter Description (Max 255 characters)"
                        multiline
                        rows="2"
                        style={{
                          width: "85%",
                          height: "75px",
                          marginBottom: "40px",
                          marginLeft: "0px",
                          backgroundColor: "#FFFFFF",
                          border: "1px solid rgba(81, 203, 238, 1)",
                        }}
                        className={classes.textField}
                        inputProps={{ maxLength: 255 }}
                        onChange={this.handlechange("presetNotes2")}
                        onBlur={this.handleOnBlur}
                        disabled={!this.state.editable}
                        value={
                          this.state.commentsVo.presetNotes2
                            ? this.state.commentsVo.presetNotes2
                            : ""
                        }
                        margin="none"
                        variant="outlined"
                      />
                    </div>
                  </div>
                ) : null}
              </div>
            </div>
          ) : null}
        </Paper>
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    newCommentList: state.applSearch.newCommentList,
    dropdowns: state.dropdowns,
    loginVo: state.loginData.loginVo,
    searchResultsVo: state.applSearch.searchResultsVo,
    servicesEnabled: state.loginData.servicesEnabled,
  };
};
const mapDispatchToProps = {
  setAuthZip,
  setAuthZipState,
  addComment,
  PresetNotes,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(CommentsSignature));
