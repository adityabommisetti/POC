import React, { Component } from "react";
import Autocomplete1 from "../UI/Select";

import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormLabel from "@material-ui/core/FormLabel";
import InputField from "../UI/InputField";
import Paper from "@material-ui/core/Paper";
import Radio from "@material-ui/core/Radio";
import RadioButtonCheckedIcon from "@material-ui/icons/RadioButtonChecked";
import RadioButtonUncheckedIcon from "@material-ui/icons/RadioButtonUnchecked";
import RadioGroup from "@material-ui/core/RadioGroup";
import { Styles } from "../../assets/styles/Theme";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";
import checkErrorField from "../../utils/CheckErrorField";

const SELECT_OBJECT = {
  label: "Select",
  value: "",
};
class Questions extends Component {
  constructor(props) {
    super(props);
    this.state = {
      appFields: [],
      ltcQues: [],
      listInst: [],
    };
  }
  componentDidMount() {
    const { loginProfile, searchResultsVo } = this.props;
    this.setState({listInst: [SELECT_OBJECT, ...searchResultsVo.lstInstitutes]});
    
    const APPFIELDS = loginProfile.filter((data) => data.label === "APPFIELDS");
    const LTC_QUES = loginProfile.filter((data) => data.label === "LTC_QUES");
    this.setState({
      appFields: APPFIELDS[0],
      ltcQues: LTC_QUES[0],
    });
  }
  render() {
    const {
      classes,
      searchResultsVo,
      originalApplication,
      dropdowns,
    } = this.props;
    const applVO = searchResultsVo.applVO;
    const applEligiVO = searchResultsVo.applEligiVO;
    const applOtherCovVO = searchResultsVo.applOtherCovVO;
    const { appFields, ltcQues, listInst } = this.state;
    return (
      <Paper elevation={0} className={classes.card}>
        {applVO.applType === "NMA" ? (
          <React.Fragment>
            <div className={classes.container}>
              <div className="queAlign">
                <div>
                  <FormControl
                    component="fieldset"
                    className={classes.formControl}
                  >
                    <FormLabel
                      component="legend"
                      className={classes.legend}
                      style={{ width: "280px !important" }}
                    >
                      Do you have End Stage Renal Disease &nbsp;
                      <RadioGroup
                        aria-label="esrdInd"
                        name="esrdInd"
                        className={classes.group}
                        value={applOtherCovVO.esrd}
                        onChange={this.props.handlechange(
                          "esrd",
                          "applOtherCovVO"
                        )}
                      >
                        <FormControlLabel
                          value="Y"
                          control={
                            <Radio
                              color="primary"
                              disabled={originalApplication}
                              icon={
                                <RadioButtonUncheckedIcon fontSize="small" />
                              }
                              checkedIcon={
                                <RadioButtonCheckedIcon fontSize="small" />
                              }
                            />
                          }
                          label="Yes"
                        />
                        <FormControlLabel
                          value="N"
                          control={
                            <Radio
                              color="primary"
                              disabled={originalApplication}
                              icon={
                                <RadioButtonUncheckedIcon fontSize="small" />
                              }
                              checkedIcon={
                                <RadioButtonCheckedIcon fontSize="small" />
                              }
                            />
                          }
                          label="No"
                        />
                      </RadioGroup>
                    </FormLabel>
                  </FormControl>

                  <FormControl
                    component="fieldset"
                    className={classes.formControl}
                  >
                    <FormLabel component="legend" className={classes.legend}>
                      PCO &nbsp;
                      <RadioGroup
                        aria-label="PCO"
                        name="pcoInd"
                        className={classes.group}
                        value={applOtherCovVO.pcoInd}
                        onChange={this.props.handlechange(
                          "pcoInd",
                          "applOtherCovVO"
                        )}
                      >
                        <FormControlLabel
                          value="Y"
                          control={
                            <Radio
                              color="primary"
                              disabled={originalApplication}
                              icon={
                                <RadioButtonUncheckedIcon fontSize="small" />
                              }
                              checkedIcon={
                                <RadioButtonCheckedIcon fontSize="small" />
                              }
                            />
                          }
                          label="Yes"
                        />
                        <FormControlLabel
                          value="N"
                          control={
                            <Radio
                              color="primary"
                              disabled={originalApplication}
                              icon={
                                <RadioButtonUncheckedIcon fontSize="small" />
                              }
                              checkedIcon={
                                <RadioButtonCheckedIcon fontSize="small" />
                              }
                            />
                          }
                          label="No"
                        />
                      </RadioGroup>
                    </FormLabel>
                  </FormControl>

                  <FormControl
                    component="fieldset"
                    className={classes.formControl}
                  >
                    <FormLabel component="legend" className={classes.legend}>
                      Dialysis &nbsp;
                      <RadioGroup
                        aria-label="Dialysis"
                        name="Dialysis"
                        className={classes.group}
                        value={applOtherCovVO.dialysis}
                        onChange={this.props.handlechange(
                          "dialysis",
                          "applOtherCovVO"
                        )}
                      >
                        <FormControlLabel
                          value="Y"
                          control={
                            <Radio
                              color="primary"
                              disabled={originalApplication}
                              icon={
                                <RadioButtonUncheckedIcon fontSize="small" />
                              }
                              checkedIcon={
                                <RadioButtonCheckedIcon fontSize="small" />
                              }
                            />
                          }
                          label="Yes"
                        />
                        <FormControlLabel
                          value="N"
                          control={
                            <Radio
                              color="primary"
                              disabled={originalApplication}
                              icon={
                                <RadioButtonUncheckedIcon fontSize="small" />
                              }
                              checkedIcon={
                                <RadioButtonCheckedIcon fontSize="small" />
                              }
                            />
                          }
                          label="No"
                        />
                      </RadioGroup>
                    </FormLabel>
                  </FormControl>
                </div>
                <div className={classes.container}>
                  <div>
                    <InputField
                      name="esrdStartDt"
                      label="Start Date"
                      maxLength={10}
                      placeholder="MM/DD/YYYY"
                      disabled
                      value={applEligiVO.esrdStartDt}
                      onClick={this.props.handleDates(
                        "#esrdStartDt",
                        "applEligiVO"
                      )}
                      onChange={this.props.handleDateChange(
                        "esrdStartDt",
                        "applEligiVO"
                      )}
                      isErrorField={checkErrorField(
                        "esrdStartDt",
                        searchResultsVo
                      )}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="esrdEndDt"
                      label="End Date"
                      maxLength={10}
                      placeholder="MM/DD/YYYY"
                      disabled
                      value={applEligiVO.esrdEndDt}
                      onClick={this.props.handleDates(
                        "#esrdEndDt",
                        "applEligiVO"
                      )}
                      onChange={this.props.handleDateChange(
                        "esrdEndDt",
                        "applEligiVO"
                      )}
                      isErrorField={checkErrorField(
                        "esrdEndDt",
                        searchResultsVo
                      )}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                </div>
              </div>
            </div>
          </React.Fragment>
        ) : null}
        <FormControl component="fieldset" className={classes.formControl}>
          <FormLabel
            component="legend"
            className={classes.legend}
            style={{ marginLeft: "10px" }}
          >
            Do you have other Drug Coverage &nbsp;
            <RadioGroup
              aria-label="Drug Coverage"
              name="DrugCoverage"
              className={classes.group}
              value={applOtherCovVO.secRxInd}
              onChange={this.props.handlechange("secRxInd", "applOtherCovVO")}
            >
              <FormControlLabel
                value="Y"
                control={
                  <Radio
                    color="primary"
                    disabled={originalApplication}
                    icon={<RadioButtonUncheckedIcon fontSize="small" />}
                    checkedIcon={<RadioButtonCheckedIcon fontSize="small" />}
                  />
                }
                label="Yes"
              />
              <FormControlLabel
                value="N"
                control={
                  <Radio
                    color="primary"
                    disabled={originalApplication}
                    icon={<RadioButtonUncheckedIcon fontSize="small" />}
                    checkedIcon={<RadioButtonCheckedIcon fontSize="small" />}
                  />
                }
                label="No"
              />
            </RadioGroup>
          </FormLabel>
        </FormControl>
        <div className={classes.container}>
          <div className={classes.QueAns}>
            <InputField
              name="otherCov"
              label="Name of other coverage"
              maxLength={50}
              value={applOtherCovVO.otherCov}
              onChange={this.props.handlechange("otherCov", "applOtherCovVO")}
              onBlur={this.props.handleOnBlur("applOtherCovVO")}
              disabled={originalApplication}
              isErrorField={checkErrorField("otherCov", searchResultsVo)}
            />
            <div className={classes.validationMessage} />
          </div>
          <div>
            <InputField
              name="covId"
              label="ID# for this Coverage"
              maxLength={20}
              value={applOtherCovVO.covId}
              onClick={this.props.handleDates("applOtherCovVO")}
              onChange={this.props.handlechange("covId", "applOtherCovVO")}
              onBlur={this.props.handleOnBlur("applOtherCovVO")}
              disabled={originalApplication}
              isErrorField={checkErrorField("covId", searchResultsVo)}
            />
            <div className={classes.validationMessage} />
          </div>
          <div>
            <InputField
              name="covBin"
              label="BIN"
              maxLength={6}
              value={applOtherCovVO.covBin}
              onChange={this.props.handlechange("covBin", "applOtherCovVO")}
              onBlur={this.props.handleOnBlur("applOtherCovVO")}
              disabled={originalApplication}
              isErrorField={checkErrorField("covBin", searchResultsVo)}
            />
            <div className={classes.validationMessage} />
          </div>
          <div>
            <InputField
              name="groupNo"
              label="Group Number"
              maxLength={20}
              value={applOtherCovVO.groupNo}
              onChange={this.props.handlechange("groupNo", "applOtherCovVO")}
              onBlur={this.props.handleOnBlur("applOtherCovVO")}
              disabled={originalApplication}
              isErrorField={checkErrorField("groupNo", searchResultsVo)}
            />
            <div className={classes.validationMessage} />
          </div>
          <div>
            <InputField
              name="covPcn"
              label="PCN"
              maxLength={10}
              value={applOtherCovVO.covPcn}
              onChange={this.props.handlechange("covPcn", "applOtherCovVO")}
              onBlur={this.props.handleOnBlur("applOtherCovVO")}
              disabled={originalApplication}
              isErrorField={checkErrorField("covPcn", searchResultsVo)}
            />
            <div className={classes.validationMessage} />
          </div>
        </div>
        <FormControl component="fieldset" className={classes.formControl}>
          <FormLabel
            component="legend"
            className={classes.legend}
            style={{ marginLeft: "10px" }}
          >
            Resident in a Long-Term Facility &nbsp;
            <RadioGroup
              aria-label="Resident"
              name="Resident"
              className={classes.group}
              value={applOtherCovVO.ltcInstInd}
              onChange={this.props.handlechange("ltcInstInd", "applOtherCovVO")}
            >
              <FormControlLabel
                value="Y"
                control={
                  <Radio
                    color="primary"
                    disabled={originalApplication}
                    icon={<RadioButtonUncheckedIcon fontSize="small" />}
                    checkedIcon={<RadioButtonCheckedIcon fontSize="small" />}
                  />
                }
                label="Yes"
              />
              <FormControlLabel
                value="N"
                control={
                  <Radio
                    color="primary"
                    disabled={originalApplication}
                    icon={<RadioButtonUncheckedIcon fontSize="small" />}
                    checkedIcon={<RadioButtonCheckedIcon fontSize="small" />}
                  />
                }
                label="No"
              />
            </RadioGroup>
          </FormLabel>
        </FormControl>
        <div className={classes.container}>
          <div className={classes.QueAns}>
            <InputField
              name="instStartDt"
              label="Start Date"
              maxLength={10}
              placeholder="MM/DD/YYYY"
              disabled
              value={applEligiVO.instStartDt}
              onClick={this.props.handleDates("#instStartDt", "applEligiVO")}
              onChange={this.props.handleDateChange(
                "instStartDt",
                "applEligiVO"
              )}
              isErrorField={checkErrorField("instStartDt", searchResultsVo)}
            />
            <div className={classes.validationMessage} />
          </div>
          <div>
            <InputField
              name="instEndDt"
              label="End Date"
              maxLength={10}
              placeholder="MM/DD/YYYY"
              disabled
              value={applEligiVO.instEndDt}
              onClick={this.props.handleDates("#instEndDt", "applEligiVO")}
              onChange={this.props.handleDateChange("instEndDt", "applEligiVO")}
              isErrorField={checkErrorField("instEndDt", searchResultsVo)}
            />
            <div className={classes.validationMessage} />
          </div>
          <div className={classes.spaceQuestion}>
            <Autocomplete1
              handleChange={this.props.handlechangeAuto}
              vo="applOtherCovVO"
              margin="0px"
              label="Name of Institution"
              options={listInst}
              defaultValue={
                applOtherCovVO.nameInstitute
                  ? listInst.filter(
                      (data) => data.value === applOtherCovVO.nameInstitute
                    )[0]
                  : { label: "Select", value: "" }
              }
              value={
                listInst.filter(
                  (data) => data.value === applOtherCovVO.nameInstitute
                )[0]
              }
              name="nameInstitute"
              disabled={originalApplication}
            />
            <div className={classes.validationMessageSelect} />
          </div>
          <div>
            <InputField
              name="ltcFacPhone"
              label="Phone Number"
              disabled
              value={applOtherCovVO.ltcFacPhone}
              onChange={this.props.handlechange(
                "ltcFacPhone",
                "applOtherCovVO"
              )}
              isErrorField={checkErrorField("ltcFacPhone", searchResultsVo)}
            />
            <div className={classes.validationMessage} />
          </div>
          <div className={classes.QueAns}>
            <InputField
              name="ltcFacAddress"
              label="Address (Number and Street)"
              disabled
              value={applOtherCovVO.ltcFacAddress}
              width="480px"
              onChange={this.props.handlechange(
                "ltcFacAddress",
                "applOtherCovVO"
              )}
            />
            <div className={classes.validationMessage} />
          </div>
        </div>
        <FormControl component="fieldset" className={classes.formControl}>
          <FormLabel
            component="legend"
            className={classes.legend}
            style={{ marginLeft: "10px" }}
          >
            Enrolled in State Medicaid program &nbsp;
            <RadioGroup
              aria-label="Enrolled SMP"
              name="medicaidInd"
              className={classes.group}
              value={applOtherCovVO.stMedicaid}
              onChange={this.props.handlechange("stMedicaid", "applOtherCovVO")}
            >
              <FormControlLabel
                value="Y"
                control={
                  <Radio
                    color="primary"
                    disabled={originalApplication}
                    icon={<RadioButtonUncheckedIcon fontSize="small" />}
                    checkedIcon={<RadioButtonCheckedIcon fontSize="small" />}
                  />
                }
                label="Yes"
              />
              <FormControlLabel
                value="N"
                control={
                  <Radio
                    color="primary"
                    disabled={originalApplication}
                    icon={<RadioButtonUncheckedIcon fontSize="small" />}
                    checkedIcon={<RadioButtonCheckedIcon fontSize="small" />}
                  />
                }
                label="No"
              />
            </RadioGroup>
          </FormLabel>
        </FormControl>
        <div className={classes.container}>
          <div className={classes.QueAns}>
            <InputField
              name="medicStartDt"
              label="Start Date"
              maxLength={10}
              placeholder="MM/DD/YYYY"
              disabled
              value={applEligiVO.medicStartDt}
              onClick={this.props.handleDates("#medicStartDt", "applEligiVO")}
              onChange={this.props.handleDateChange(
                "medicStartDt",
                "applEligiVO"
              )}
              isErrorField={checkErrorField("medicStartDt", searchResultsVo)}
            />
            <div className={classes.validationMessage} />
          </div>
          <div>
            <InputField
              name="medicEndDt"
              label="End Date"
              maxLength={10}
              placeholder="MM/DD/YYYY"
              disabled
              value={applEligiVO.medicEndDt}
              onClick={this.props.handleDates("#medicEndDt", "applEligiVO")}
              onChange={this.props.handleDateChange(
                "medicEndDt",
                "applEligiVO"
              )}
              isErrorField={checkErrorField("medicEndDt", searchResultsVo)}
            />
            <div className={classes.validationMessage} />
          </div>

          <div>
            <InputField
              name="medicaidId"
              label="Medicaid ID"
              maxLength={20}
              disabled={
                applOtherCovVO.stMedicaid === "N"
                  ? true
                  : false || originalApplication
              }
              value={applOtherCovVO.medicaidId}
              onChange={this.props.handlechange("medicaidId", "applOtherCovVO")}
              onBlur={this.props.handleOnBlur("applOtherCovVO")}
              isErrorField={checkErrorField("medicaidId", searchResultsVo)}
            />
            <div className={classes.validationMessage} />
          </div>
        </div>

        <React.Fragment>
          <div className={classes.container}>
            {applVO.applType === "NMA" ? (
              <FormControl component="fieldset" className={classes.formControl}>
                <FormLabel component="legend" className={classes.legend}>
                  You or Your Spouse Work &nbsp;
                  <RadioGroup
                    aria-label="Spouse Work"
                    name="spouseWorkInd"
                    className={classes.group}
                    value={applOtherCovVO.spouseWork}
                    onChange={this.props.handlechange(
                      "spouseWork",
                      "applOtherCovVO"
                    )}
                  >
                    <FormControlLabel
                      value="Y"
                      control={
                        <Radio
                          color="primary"
                          disabled={originalApplication}
                          icon={<RadioButtonUncheckedIcon fontSize="small" />}
                          checkedIcon={
                            <RadioButtonCheckedIcon fontSize="small" />
                          }
                        />
                      }
                      label="Yes"
                    />
                    <FormControlLabel
                      value="N"
                      control={
                        <Radio
                          color="primary"
                          disabled={originalApplication}
                          icon={<RadioButtonUncheckedIcon fontSize="small" />}
                          checkedIcon={
                            <RadioButtonCheckedIcon fontSize="small" />
                          }
                        />
                      }
                      label="No"
                    />
                  </RadioGroup>
                </FormLabel>
              </FormControl>
            ) : null}
            {appFields.value === "Y" ? (
              <React.Fragment>
                {" "}
                <div style={{ width: "335px" }}>
                  {/* <Select
                    components={components}
                    propertyName={dropdowns.lstLanguages.filter(
                      (option) => option.value === applVO.language
                    )}
                    options={dropdowns.lstLanguages}
                    label="Select"
                    textFieldProps={{
                      id: "languageCd",
                      label: "Send Correspondence in the following Language",
                      InputLabelProps: {
                        className: classes.label,
                        shrink: true,
                      },
                    }}
                    width="290px"
                    className={classes.textFieldSelect}
                    handleChange={this.props.handlechange("language", "applVO")}
                    classes={classes}
                    isDisabled={originalApplication}
                  /> */}
                  <Autocomplete1
                    handleChange={this.props.handlechangeAuto}
                    vo="applVO"
                    margin="0px"
                    label="Send Correspondence in the following Language"
                    options={dropdowns.lstLanguages}
                    defaultValue={{label:"ENGLISH",value:"ENG"}}
                    value={
                      dropdowns.lstLanguages.filter(
                        (data) => data.value === applVO.language
                      )[1]
                    }
                    name="language"
                    disabled={originalApplication}
                  />
                  <div className={classes.validationMessageSelect} />
                </div>
                <div style={{ width: "15rem" }}>
                  {/* <Select
                    components={components}
                    propertyName={dropdowns.lstAltCorrespondences.filter(
                      (option) => option.value === applVO.altCorrespondenceInd
                    )}
                    options={dropdowns.lstAltCorrespondences}
                    label="Select"
                    textFieldProps={{
                      id: "altCorrespondenceInd",
                      label: "Alternate Correspondence Method",
                      InputLabelProps: {
                        className: classes.label,
                        shrink: true,
                      },
                    }}
                    width="217px"
                    className={classes.textFieldSelect}
                    handleChange={this.props.handlechange(
                      "altCorrespondenceInd",
                      "applVO"
                    )}
                    classes={classes}
                    isDisabled={originalApplication}
                  /> */}
                  <Autocomplete1
                    handleChange={this.props.handlechangeAuto}
                    vo="applVO"
                    margin="0px"
                    label="Alternate Correspondence Method"
                    options={dropdowns.lstAltCorrespondences}
                    defaultValue={{ label: "Select", value: "" }}
                    value={
                      dropdowns.lstAltCorrespondences.filter(
                        (data) => data.value === applVO.altCorrespondenceInd
                      )[0]
                    }
                    name="altCorrespondenceInd"
                    width="217px"
                    disabled={originalApplication}
                  />
                  <div className={classes.validationMessageSelect} />
                </div>
              </React.Fragment>
            ) : null}
          </div>
        </React.Fragment>

        {ltcQues.value === "Y" ? (
          <React.Fragment>
            <FormControl component="fieldset" className={classes.formControl}>
              <FormLabel
                component="legend"
                className={classes.legend}
                style={{ width: "280px !important" }}
              >
                Do you/will you live in a LTC or ALF&nbsp; for more than 90
                days? &nbsp;
                <RadioGroup
                  aria-label="addLQ1"
                  name="addLQ1"
                  className={classes.group}
                  value="Y"
                  onChange={this.props.handlechange("addLQ1", "applOtherCovVO")}
                >
                  <FormControlLabel
                    value="Y"
                    control={
                      <Radio
                        color="primary"
                        disabled={originalApplication}
                        icon={<RadioButtonUncheckedIcon fontSize="small" />}
                        checkedIcon={
                          <RadioButtonCheckedIcon fontSize="small" />
                        }
                      />
                    }
                    label="Yes"
                  />
                  <FormControlLabel
                    value="N"
                    control={
                      <Radio
                        color="primary"
                        disabled={originalApplication}
                        icon={<RadioButtonUncheckedIcon fontSize="small" />}
                        checkedIcon={
                          <RadioButtonCheckedIcon fontSize="small" />
                        }
                      />
                    }
                    label="No"
                  />
                </RadioGroup>
              </FormLabel>
            </FormControl>
            <FormControl component="fieldset" className={classes.formControl}>
              <FormLabel component="legend" className={classes.legend}>
                Do you receive Medical Assistance&nbsp;from the State and have
                Medicare?&nbsp;
                <RadioGroup
                  aria-label="addLQ2"
                  name="addLQ2"
                  className={classes.group}
                  value={"Y"}
                  onChange={this.props.handlechange("addLQ2", "applOtherCovVO")}
                >
                  <FormControlLabel
                    value="Y"
                    control={
                      <Radio
                        color="primary"
                        disabled={originalApplication}
                        icon={<RadioButtonUncheckedIcon fontSize="small" />}
                        checkedIcon={
                          <RadioButtonCheckedIcon fontSize="small" />
                        }
                      />
                    }
                    label="Yes"
                  />
                  <FormControlLabel
                    value="N"
                    control={
                      <Radio
                        color="primary"
                        disabled={originalApplication}
                        icon={<RadioButtonUncheckedIcon fontSize="small" />}
                        checkedIcon={
                          <RadioButtonCheckedIcon fontSize="small" />
                        }
                      />
                    }
                    label="No"
                  />
                </RadioGroup>
              </FormLabel>
            </FormControl>
            <FormControl component="fieldset" className={classes.formControl}>
              <FormLabel component="legend" className={classes.legend}>
                Does applicant have a diagnosis &nbsp;of Dementia? :&nbsp;
                <RadioGroup
                  aria-label="addLQ3"
                  name="addLQ3"
                  className={classes.group}
                  value={"Y"}
                  onChange={this.props.handlechange("addLQ3", "applOtherCovVO")}
                >
                  <FormControlLabel
                    value="Y"
                    control={
                      <Radio
                        color="primary"
                        disabled={originalApplication}
                        icon={<RadioButtonUncheckedIcon fontSize="small" />}
                        checkedIcon={
                          <RadioButtonCheckedIcon fontSize="small" />
                        }
                      />
                    }
                    label="Yes"
                  />
                  <FormControlLabel
                    value="N"
                    control={
                      <Radio
                        color="primary"
                        disabled={originalApplication}
                        icon={<RadioButtonUncheckedIcon fontSize="small" />}
                        checkedIcon={
                          <RadioButtonCheckedIcon fontSize="small" />
                        }
                      />
                    }
                    label="No"
                  />
                </RadioGroup>
              </FormLabel>
            </FormControl>
          </React.Fragment>
        ) : null}
      </Paper>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    searchResultsVo: state.applSearch.searchResultsVo,
    dropdowns: state.dropdowns,
    loginProfile: state.loginData.profiles,
  };
};
export default connect(mapStateToProps)(withStyles(Styles)(Questions));