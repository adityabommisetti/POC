import React, { Component } from "react";
import Autocomplete1 from "../UI/Select";

import $ from "jquery";
import Button from "@material-ui/core/Button";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import Checkbox from "@material-ui/core/Checkbox";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import InputField from "../UI/InputField";
import Paper from "@material-ui/core/Paper";
import { Styles } from "../../assets/styles/Theme";
import { connect } from "react-redux";
import { handleDateChange } from "../../utils/DateFormatter";
import { setAttestationList } from "../../redux/actions/ApplActions";
import { withStyles } from "@material-ui/core/styles";
import checkErrorField, { checkErrorField1 } from "../../utils/CheckErrorField";

class Attestation extends Component {
  handleChange = (idx, name) => (e) => {
    let value = "";
    if (name === "attestInd") {
      value = e.value;
    } else {
      value = e.target.value;
      value = handleDateChange(value);
    }
    this.setValue(name, value, idx);
  };

  handleOnBlur = (idx, name) => (e) => {
    let value = "";
    if (name === "attestInd") {
      value = e.value.trim();
    } else {
      value = e.target.value.trim();
    }

    this.setValue(name, value, idx);
  };

  handleChangeAuto1 = (event, name, idx) => {
    let value = event.value;
    this.setValue(name, value, idx)
  };

  handleOnBlur = (idx, name) => (e) => {
    let value = "";
    if (name === "attestInd") {
      value = e.value.trim();
    } else {
      value = e.target.value.trim();
    }

    this.setValue(name, value, idx);
  };

  handleDates = (idx) => {
    const fieldId = "#attestDate" + idx;
    setTimeout(() => {
      $(fieldId)
        .datepicker({
          showAnim: "clip",
          dateFormat: "mm/dd/yy",
          changeMonth: true,
          changeYear: true,
          yearRange: "c-120:c+1",
          dayNamesMin: ["S", "M", "T", "W", "T", "F", "S"],
        })
        .on("change", (e) => {
          this.setValue(e.target.name, e.target.value, idx);
        });
    }, 0);
  };
  setValue = (name, value, idx) => {
    let rows = [...this.props.searchResultsVo.applAttestationList];
    rows[idx][name] = value;
    if (rows[idx].logicalInd === "" && name === "attestDate") {
      rows[idx].logicalInd = "U";
    }
    this.props.setAttestationList(rows);
  };
  handleAddRow = (event) => {
    event.preventDefault();
    const item = {
      applId: this.props.searchResultsVo.applVO.applId,
      attestaionSeqNbr: "",
      attestDate: "",
      attestInd: "",
      index: "",
      logicalInd: "I",
    };
    this.props.setAttestationList([
      ...this.props.searchResultsVo.applAttestationList,
      item,
    ]);
  };
  handleRemoveSpecificRow = (idx) => (event) => {
    event.preventDefault();
    const rows = [...this.props.searchResultsVo.applAttestationList];
    if (rows[idx].logicalInd === "I") {
      rows.splice(idx, 1);
    } else {
      rows[idx].logicalInd = "D";
    }
    this.props.setAttestationList(rows);
  };

  render() {
    const {
      classes,
      searchResultsVo,
      originalApplication,
      dropdowns,
      servicesEnabled,
    } = this.props;
    const applPlanVO = searchResultsVo.applPlanVO;
    const applVO = searchResultsVo.applVO;
    const applEligiVO = searchResultsVo.applEligiVO;
    // checkErrorField1alert(checkErrorField("electionType", searchResultsVo))
    return (
      <Paper elevation={0} className={classes.card}>
        <div className={classes.applicationSectionHeading}>
          <span>Attestation of Eligibility for an Enrollment Period</span>
        </div>
        <div className={classes.container}>
          <div style={{ width: "220px" }}>
            <Autocomplete1
              handleChange={this.props.handlechangeAuto}
              isErrorField={checkErrorField1("electionType", searchResultsVo)}
              vo='applPlanVO'
              margin='0px'
              width="280px"
              label='Election Type'
              options={dropdowns.lstElectionTypes}
              defaultValue={dropdowns.lstElectionTypes}
              value={dropdowns.lstElectionTypes.filter(data => data.value === applPlanVO.electionType)[0]}
              name='electionType'
              disabled={originalApplication}
            />
            <div className={classes.validationMessageSelect}>
              {applVO.applStatus === "FORCEDAPPR"
                ? this.props.validator.message(
                  "electionType",
                  applPlanVO.electionType,
                  "required"
                )
                : null}
            </div>
          </div>
          <div className={classes.textField} style={{ marginLeft: "70px" }}>
            <FormControlLabel
              control={
                <Checkbox
                  style={{ width: 36, height: 36 }}
                  disabled
                  color="primary"
                  icon={
                    <CheckBoxOutlineBlankIcon
                      className={classes.checkBoxStyle}
                    />
                  }
                  checkedIcon={
                    <CheckBoxIcon className={classes.checkboxmember} />
                  }
                  checked={applVO.editOverride === "Y" ? true : false}
                />
              }
              id="editOverride"
              label="Edit Override"
              classes={{ label: classes.formLabel }}
            />
          </div>
          <div>
            <InputField
              name="electionDt"
              id="electionDt"
              label="Election Date"
              disabled={applPlanVO.electionType !== "L"}
              placeholder="MM/DD/YYYY"
              value={applPlanVO.electionDt}
              onClick={this.props.handleDates("#electionDt", "applPlanVO")}
              onChange={this.props.handleDateChange("electionDt", "applPlanVO")}
              isErrorField={checkErrorField("electionDt", searchResultsVo)}
            />
            <div className={classes.validationMessage}>
              {this.props.validator.message(
                "electionDate",
                applPlanVO.electionDt,
                "date_format"
              )}
            </div>
          </div>

          <div>
            <Autocomplete1
              handleChange={this.props.handlechangeAuto}
              vo='applPlanVO'
              margin='0px'
              width="300px"
              label='SEP Reason'
              options={dropdowns.lstSepReasons}
              defaultValue={dropdowns.lstSepReasons}
              value={dropdowns.lstSepReasons.filter(data => data.value === applPlanVO.sepReason)[0]}
              name='sepReason'
              disabled={originalApplication}
            />

            <div className={classes.validationMessageSelect} />
          </div>

          <div className={classes.appAddQuestion}>
            {!servicesEnabled.includes("EEUP") ? (
              <Button
                id="add_attestation"
                variant="contained"
                color="primary"
                onClick={this.handleAddRow}
                disabled={originalApplication}
              >
                Add Attestation Question
              </Button>
            ) : null}
          </div>
        </div>

        {searchResultsVo.applAttestationList.map((item, idx) => {
          const array = dropdowns.lstSepExceptions.filter(
            (object) =>
              object.value === item.attestInd && object.dateRequiredInd === "Y"
          );
          return item.logicalInd !== "D" ? (
            <div className={classes.container} key={idx}>
              <div style={{ marginRight: "190px" }}>

                <Autocomplete1
                  handleChange={this.handleChangeAuto1}
                  vo={idx}
                  margin='0px'
                  width="380px"
                  label='Medicare SEP Exception'
                  options={dropdowns.lstSepExceptions}
                  defaultValue={dropdowns.lstSepExceptions[0]}
                  value={dropdowns.lstSepExceptions.filter(data => data.value === item.attestInd)[0]}
                  name='attestInd'
                  disabled={originalApplication}
                />
                <div className={classes.validationMessageSelect}>
                  {this.props.validator.message(
                    "sepException" + idx,
                    item.attestInd,
                    "attestation_exception_required"
                  )}
                </div>
              </div>
              <div>
                <InputField
                  name="attestDate"
                  label="Attestation Date"
                  id={"attestDate" + idx}
                  placeholder="MM/DD/YYYY"
                  value={item.attestDate}
                  maxLength="10"
                  onClick={this.handleDates(idx)}
                  disabled={originalApplication}
                  onChange={this.handleChange(idx, "attestDate")}
                  onBlur={this.handleOnBlur}
                  isErrorField={checkErrorField("attestDate", searchResultsVo)}
                  width="200px"
                />
                <div className={classes.validationMessage}>
                  {array.length > 0
                    ? this.props.validator.message(
                      "attestationDate" + idx,
                      item.attestDate,
                      "attestationDateRequired"
                    )
                    : null}
                  {this.props.validator.message(
                    "attestationDate-" + idx,
                    item.attestDate,
                    "date_format"
                  )}
                </div>
              </div>
              {!originalApplication ? (
                <span class="button-container">
                  {!servicesEnabled.includes("EEUP") ? (
                    <Button
                      id="add_attestation"
                      variant="contained"
                      color="primary"
                      onClick={this.handleRemoveSpecificRow(idx)}
                    >
                      Delete
                    </Button>
                  ) : null}
                </span>
              ) : null}
            </div>
          ) : null;
        })}

        {applVO.applType === "NMA" || applVO.applType === "NPD" ? (
          <React.Fragment>
            <div className={classes.applicationSectionHeading}>
              <span>Medicare Card Information</span>
            </div>
            <div className={classes.container}>
              <div>
                <InputField
                  className="inputMargin"
                  name="partAEffDate"
                  label="Hospital (Part A) Effective Date"
                  id="partAEffDate"
                  value={applEligiVO.partAEffDate}
                  placeholder="MM/DD/YYYY"
                  maxLength={10}
                  onClick={this.props.handleDates(
                    "#partAEffDate",
                    "applEligiVO"
                  )}
                  disabled={originalApplication}
                  isErrorField={checkErrorField(
                    "partAEffDate",
                    searchResultsVo
                  )}
                  onChange={this.props.handleDateChange(
                    "partAEffDate",
                    "applEligiVO"
                  )}
                />
                <div className={classes.validationMessage}>
                  {this.props.validator.message(
                    "partAEffDate",
                    applEligiVO.partAEffDate,
                    "date_format"
                  )}
                </div>
              </div>
              <div>
                <InputField
                  className="inputMargin"
                  name="partBEffDate"
                  label="Medical (Part B) Effective Date"
                  id="partBEffDate"
                  maxLength={10}
                  value={applEligiVO.partBEffDate}
                  placeholder="MM/DD/YYYY"
                  onClick={this.props.handleDates(
                    "#partBEffDate",
                    "applEligiVO"
                  )}
                  disabled={originalApplication}
                  isErrorField={checkErrorField(
                    "partBEffDate",
                    searchResultsVo
                  )}
                  onChange={this.props.handleDateChange(
                    "partBEffDate",
                    "applEligiVO"
                  )}
                />
                <div className={classes.validationMessage}>
                  {this.props.validator.message(
                    "partBEffDate",
                    applEligiVO.partBEffDate,
                    "date_format"
                  )}
                </div>
              </div>
              <div>
                <InputField
                  className="inputMargin"
                  name="partDEffDate"
                  label="Medical (Part D) Effective Date"
                  id="partDEffDate"
                  maxLength={10}
                  value={applEligiVO.partDEffDate}
                  placeholder="MM/DD/YYYY"
                  onClick={this.props.handleDates(
                    "#partDEffDate",
                    "applEligiVO"
                  )}
                  disabled={originalApplication}
                  isErrorField={checkErrorField(
                    "partDEffDate",
                    searchResultsVo
                  )}
                  onChange={this.props.handleDateChange(
                    "partDEffDate",
                    "applEligiVO"
                  )}
                />
                <div className={classes.validationMessage}>
                  {this.props.validator.message(
                    "partDEffDate",
                    applEligiVO.partDEffDate,
                    "date_format"
                  )}
                </div>
              </div>
              <div className={classes.textField}>
                <FormControlLabel
                  control={
                    <Checkbox
                      style={{ width: 36, height: 36 }}
                      color="primary"
                      icon={
                        <CheckBoxOutlineBlankIcon
                          className={classes.checkBoxStyle}
                        />
                      }
                      disabled
                      checked={applEligiVO.eligOverInd === "Y"}
                      checkedIcon={
                        <CheckBoxIcon className={classes.checkboxmember} />
                      }
                    />
                  }
                  id="editOverride"
                  label="Edit Override"
                  classes={{ label: classes.formLabel }}
                />
              </div>
            </div>
          </React.Fragment>
        ) : null}
      </Paper>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    searchResultsVo: state.applSearch.searchResultsVo,
    dropdowns: state.dropdowns,
    servicesEnabled: state.loginData.servicesEnabled,
  };
};
const mapDispatchToProps = {
  setAttestationList,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(Attestation));
