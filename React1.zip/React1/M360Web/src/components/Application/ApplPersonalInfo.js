import * as DateUtil from "./../../utils/DatePicker";

import React, { Component } from "react";
import Autocomplete1 from "../UI/Select";
import { fetchMemberData, setValue } from "../../redux/actions/ApplActions";

import Button from "@material-ui/core/Button";
import EligibityCheck from "./ApplEligibityCheckPopup";
import { GENDER } from "../../constants/SelectStaticData";
import InputField from "../UI/InputField";
import Modal from "../UI/Modal/Modal";
import Paper from "@material-ui/core/Paper";
import Popup from "reactjs-popup";
import { Styles } from "../../assets/styles/Theme";
import { connect } from "react-redux";
import moment from "moment";
import { withStyles } from "@material-ui/core/styles";
import { handleDateChange } from "../../utils/DateFormatter";
import checkErrorField from "../../utils/CheckErrorField";

class PersonalInfo extends Component {
  constructor(props) {
    super(props);
    this.state = {
      dataChanged: false,
      dataFetched: false,
      manualChange: false,
      closePopup: false,
      message: "",
      mbridLit: [],
      supplId: [],
      subscId: [],
    };
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.state.dataFetched) {
      this.setState({
        dataFetched: false,
      });
    }
  }
  handleDate = (targetVo) => (event) => {
    let fieldId = "#" + event.target.name;

    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", async (e) => {
        await this.props.setValue(e.target.name, targetVo, e.target.value);
        // document.getElementById(fieldId.substr(1)).focus();
        this.setState({
          dataChanged: true,
        });
        this.fetchMemberData();
        //document.getElementById(fieldId.substr(1)).blur();
      });
    // document.getElementById(fieldId.substr(1)).blur();
  };

  updatedMsg = (value, msg) => {
    this.setState({
      closePopup: value,
      message: msg,
    });
  };
  modalClosed = () => {
    this.setState({ closePopup: false });
  };

  handleDateChange = (name, targetVo) => (event) => {
    let value = event.target.value;
    value = handleDateChange(value);
    this.props.setValue(name, targetVo, value);
    this.setState({
      dataChanged: true,
    });
  };

  handleChange = (name, targetVo) => (event) => {
    let value = event.target.value;
    if (name === "lastName") {
      value = value.replace(/[^-a-z A-Z\s']/g, "");
    }
    if (value) {
      value = value.toUpperCase();
    }
    this.props.setValue(name, targetVo, value);
    this.setState({
      dataChanged: true,
    });
  };

  handleOnBlur = (name, targetVo) => (event) => {
    event.preventDefault();
    const value = this.props.searchResultsVo[targetVo][name].trim();
    this.props.setValue(name, targetVo, value);
    if (this.state.dataChanged) {
      this.setState({
        dataChanged: false,
      });

      this.fetchMemberData();
    }
  };

  fetchMemberData = async () => {
    const birthDt = this.props.searchResultsVo.applVO.mbrBirthDt.trim();
    const hicNbr = this.props.searchResultsVo.applVO.mbrHicNbr.trim();
    const lastName = this.props.searchResultsVo.applVO.mbrLastName.trim();
    const reqDt = this.props.searchResultsVo.applPlanVO.reqDtCov.trim();
    if (this.state.dataChanged && !this.state.dataFetched) {
      if ((lastName || birthDt) && hicNbr && reqDt) {
        if (
          moment(reqDt, "MM/DD/YYYY", true).isValid() &&
          (hicNbr.length >= 10 || hicNbr.length <= 12)
        ) {
          if (birthDt) {
            if (moment(birthDt, "MM/DD/YYYY", true).isValid()) {
              this.setState({
                dataFetched: true,
              });

              const status = await this.props.fetchMemberData(
                birthDt,
                reqDt,
                this.props.searchResultsVo
              );
              this.setState({
                closePopup: true,
                message: status,
              });
            }
          } else {
            this.setState({
              dataFetched: true,
            });

            const status = await this.props.fetchMemberData(
              birthDt,
              reqDt,
              this.props.searchResultsVo
            );
            this.setState({
              closePopup: true,
              message: status,
            });
          }
        }
      }
    }
    this.setState({
      dataChanged: false,
    });
  };

  modalClosed = () => {
    this.setState({ closePopup: false });
  };

  async componentDidMount() {
    const { loginProfile } = this.props;
    const MBRIDLIT = loginProfile.filter((data) => data.label === "MBRIDLIT");
    const SUPPLID = loginProfile.filter((data) => data.label === "SUPPLID");
    const SUBSCID = loginProfile.filter((data) => data.label === "SUBSCID");
    this.setState({
      mbridLit: MBRIDLIT[0],
      supplId: SUPPLID[0],
      subscId: SUBSCID[0],
    });
  }

  render() {
    const {
      classes,
      searchResultsVo,
      originalApplication,
      dropdowns,
    } = this.props;
    const applVO = searchResultsVo.applVO;
    const applEligiVO = searchResultsVo.applEligiVO;
    const applPlanVO = searchResultsVo.applPlanVO;
    const { mbridLit, supplId, subscId } = this.state;

    return (
      <React.Fragment>
        <Modal
          dialogTitle="Personal info"
          message={this.state.message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Paper elevation={0} className={classes.card}>
          <div className={classes.applicationSectionHeading}>
            <span>Enroll Information</span>
          </div>

          <div className={classes.container}>
            <div>
              <InputField
                name="reqDtCov"
                label="Requested Date of Coverage"
                placeholder="MM/DD/YYYY"
                value={applPlanVO.reqDtCov}
                disabled={originalApplication}
                maxLength={10}
                onClick={this.handleDate("applPlanVO")}
                onChange={this.handleDateChange("reqDtCov", "applPlanVO")}
                required={applVO.applStatus !== "INCOMPLETE"}
                onBlur={this.handleOnBlur("reqDtCov", "applPlanVO")}
                isErrorField={checkErrorField("reqDtCov", searchResultsVo)}
              />
              <div className={classes.validationMessage}>
                {
                  // applVO.applStatus !== "INCOMPLETE" ||
                  // applVO.applStatus !== "HOLD" ||
                  // applVO.applStatus !== "READY"
                  //   ? this.props.statusHoldValidator.message(
                  //       "requestedDateOfCov",
                  //       applPlanVO.reqDtCov,
                  //       "required|date_format"
                  //     )
                  //  :
                  this.props.validator.message(
                    "requestedDateOfCov",
                    applPlanVO.reqDtCov,
                    "required|date_format"
                  )
                }
              </div>
            </div>
          </div>
          <div className={classes.container}>
            <div>
              <Autocomplete1 
                     handleChange={this.props.handlechangeAuto}
                    // handleChange={this.props.handlechange("applType", "applVO")}
                     vo='applVO'
                     margin='0px'
                    label ='Prefix'
                    options={dropdowns.lstPrefix}
                    defaultValue={ dropdowns.lstPrefix[0] }
                      value={dropdowns.lstPrefix.filter(data => data.value === applVO.mbrPrefix)[0]}
                    name='mbrPrefix'
                    disabled ={originalApplication}
                    />
              <div className={classes.validationMessageSelect} />
            </div>
            <div>
              <InputField
                name="mbrFirstName"
                label="First Name"
                maxLength={24}
                value={applVO.mbrFirstName}
                onChange={this.props.handleAlpha("mbrFirstName", "applVO")}
                onBlur={this.handleOnBlur("mbrFirstName", "applVO")}
                disabled={originalApplication}
                required={applVO.applStatus !== "INCOMPLETE"}
                isErrorField={checkErrorField("mbrFirstName", searchResultsVo)}
              />
              <div className={classes.validationMessage}>
                {applVO.applStatus !== "INCOMPLETE" ||
                applVO.applStatus !== "HOLD" ||
                applVO.applStatus !== "READY"
                  ? this.props.statusHoldValidator.message(
                      "firstName",
                      applVO.mbrFirstName,
                      "required"
                    )
                  : this.props.validator.message(
                      "firstName",
                      applVO.mbrFirstName,
                      "required"
                    )}
              </div>
            </div>
            <div>
              <InputField
                name="mbrMiddleName"
                label="Middle Name"
                maxLength={1}
                value={applVO.mbrMiddleName}
                onChange={this.props.handleAlpha("mbrMiddleName", "applVO")}
                onBlur={this.handleOnBlur("mbrMiddleName", "applVO")}
                disabled={originalApplication}
                isErrorField={checkErrorField("mbrMiddleName", searchResultsVo)}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="mbrLastName"
                label="Last Name"
                maxLength={35}
                disabled={originalApplication}
                value={applVO.mbrLastName}
                onChange={this.handleChange("mbrLastName", "applVO")}
                onBlur={this.handleOnBlur("mbrLastName", "applVO")}
                required={applVO.applStatus !== "INCOMPLETE"}
                isErrorField={checkErrorField("mbrLastName", searchResultsVo)}
              />
              <div className={classes.validationMessage}>
                {applVO.applStatus !== "INCOMPLETE" ||
                applVO.applStatus !== "HOLD" ||
                applVO.applStatus !== "READY"
                  ? this.props.statusHoldValidator.message(
                      "lastName",
                      applVO.mbrLastName,
                      "required"
                    )
                  : this.props.validator.message(
                      "lastName",
                      applVO.mbrLastName,
                      "required"
                    )}
              </div>
            </div>
            <div>
              <InputField
                name="suffix"
                label="Suffix"
                id="suffix"
                maxLength={4}
                value={applVO.suffix}
                onChange={this.props.handlechange("suffix", "applVO")}
                onBlur={this.handleOnBlur("suffix", "applVO")}
                disabled={originalApplication}
                isErrorField={checkErrorField("suffix", searchResultsVo)}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="mbrBirthDt"
                label="Birth Date"
                placeholder="MM/DD/YYYY"
                value={applVO.mbrBirthDt}
                maxLength={10}
                disabled={originalApplication}
                onClick={this.handleDate("applVO")}
                onChange={this.handleDateChange("mbrBirthDt", "applVO")}
                isErrorField={checkErrorField("mbrBirthDt", searchResultsVo)}
                required
              />
              <div className={classes.validationMessage}>
                {this.props.validator.message(
                  "birthDate",
                  applVO.mbrBirthDt,
                  "date_format|required"
                )}
              </div>
            </div>

            <div>
              <InputField
                name="mbrHicNbr"
                label="Medicare ID"
                value={applVO.mbrHicNbr}
                maxLength="12"
                onChange={this.handleChange("mbrHicNbr", "applVO")}
                onBlur={this.handleOnBlur("mbrHicNbr", "applVO")}
                disabled={originalApplication}
                required={applVO.applStatus !== "INCOMPLETE"}
                isErrorField={checkErrorField("mbrHicNbr", searchResultsVo)}
              />
              {!originalApplication ? (
                <Popup
                  className={classes.mobileWidth}
                  modal
                  trigger={
                    <Button
                      variant="contained"
                      color="primary"
                      className={this.props.classes.button}
                      id="eligibilityCheck"
                    >
                      ELIG. CHECK
                    </Button>
                  }
                  position="right center"
                >
                  {(close) => (
                    <div>
                      <EligibityCheck
                        close={close}
                        updatedMsg={this.updatedMsg}
                      />
                    </div>
                  )}
                </Popup>
              ) : null}

              <div className={classes.validationMessage}>
                {this.props.validator.message(
                  "medicareId",
                  applVO.mbrHicNbr,
                  "required"
                )}
              </div>
            </div>
            <div className={classes.eligAlign}>
              <InputField
                name="dtLstChked"
                id="dtLstChked"
                label="Last Checked"
                width="195px"
                value={applEligiVO.lastChkedTimeFrmt}
                placeholder="MM/DD/YYYY"
                disabled
              />
              <div className={classes.validationMessage} />
            </div>
          </div>
          <div className={classes.container}>
            <div>
              <InputField
                name="xrefNbr"
                id="xrefNbr"
                label="XREF Claim Number"
                value={applVO.xrefNbr}
                disabled
              />
              <div className={classes.validationMessage} />
            </div>
            {!originalApplication ? (
              <div>
                <InputField
                  name="mbrHicNbr"
                  label="HIC Number"
                  maxLength={12}
                  value={applVO.displayHic}
                  disabled
                />
                <div className={classes.validationMessage} />
              </div>
            ) : null}
          </div>

          <div className={classes.applicationSectionHeading}>
            <span>Personal Information</span>
          </div>
          <div className={classes.container}>
            <div>
              <InputField
                name="mbrApplNo"
                id="mbrApplNo"
                label="Application Number"
                maxLength={20}
                value={applVO.mbrApplNo}
                onChange={this.props.handlechange("mbrApplNo", "applVO")}
                onBlur={this.handleOnBlur("mbrApplNo", "applVO")}
                disabled={originalApplication}
                isErrorField={checkErrorField("mbrApplNo", searchResultsVo)}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="altMbrId"
                label="Plan Member ID"
                value={applVO.altMbrId}
                maxLength={15}
                onChange={this.props.handlechange("altMbrId", "applVO")}
                disabled={originalApplication || supplId.value === "G"}
                isErrorField={checkErrorField("altMbrId", searchResultsVo)}
              />
              <div className={classes.validationMessage} />
            </div>

            <div>
              <InputField
                name="memberId"
                id="memberId"
                label={mbridLit.value === "TSA" ? "Wipro ID" : "M360 ID"}
                value={applVO.mbrId}
                disabled
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="mbrRxId"
                label="RX ID"
                value={applVO.mbrRxId}
                onChange={this.props.handlechange("mbrRxId", "applVO")}
                disabled={originalApplication || supplId.value === "G"}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="ssn"
                id="ssn"
                label="SSN"
                value={applVO.mbrSsn}
                maxLength={11}
                onChange={this.props.handleNumberChange("mbrSsn", "applVO")}
                disabled={originalApplication}
                isErrorField={checkErrorField("mbrSsn", searchResultsVo)}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
                    <Autocomplete1 
                     handleChange={this.props.handlechangeAuto}
                    // handleChange={this.props.handlechange("applType", "applVO")}
                     vo='applVO'
                      margin='0px'
                    label ='Gender'
                    options={GENDER}
                    defaultValue={ GENDER[0] }
                      value={GENDER.filter(data => data.value === applVO.mbrGender)[0]}
                    name='mbrGender'
                    disabled ={originalApplication}
                    />
              <div className={classes.validationMessageSelect} />
            </div>

            <div>
              <InputField
                name="insCardName"
                id="insCardName"
                label="Insurance Card Name"
                value={applVO.insCardName}
                maxLength={50}
                onChange={this.props.handlechange("insCardName", "applVO")}
                disabled={originalApplication}
                isErrorField={checkErrorField("insCardName", searchResultsVo)}
              />
              <div className={classes.validationMessage} />
            </div>
            {subscId.value === "Y" || subscId.value === "A" ? (
              <div>
                <InputField
                  name="subscriberId"
                  id="subscriberId"
                  label={
                    subscId.value === "A" ? "Alternate ID" : "Subscriber ID"
                  }
                  value={applVO.subscriberId}
                  maxLength={10}
                  disabled={originalApplication}
                  onChange={this.props.handlechange("subscriberId", "applVO")}
                  isErrorField={checkErrorField(
                    "subscriberId",
                    searchResultsVo
                  )}
                />
                <div className={classes.validationMessage} />
              </div>
            ) : null}
          </div>
        </Paper>
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    searchResultsVo: state.applSearch.searchResultsVo,
    dropdowns: state.dropdowns,
    loginProfile: state.loginData.profiles,
  };
};
const mapDispatchToProps = {
  fetchMemberData,
  setValue,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(PersonalInfo));
