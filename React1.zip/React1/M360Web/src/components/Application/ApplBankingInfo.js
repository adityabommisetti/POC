import React, { Component } from "react";
import Autocomplete1 from "../UI/Select";

import InputField from "../UI/InputField";
import Paper from "@material-ui/core/Paper";
import { Styles } from "../../assets/styles/Theme";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";
import checkErrorField from "../../utils/CheckErrorField";

class BankingInfo extends Component {
  render() {
    const {
      classes,
      searchResultsVo,
      originalApplication,
      dropdowns,
    } = this.props;
    const applVO = searchResultsVo.applVO;

    return (
      <Paper elevation={0} className={classes.card}>
        <div className={classes.container}>
          <div style={{ width: "289px" }}>
            <InputField
              name="billFirstName"
              label="First Name"
              id="billFirstName"
              maxLength={24}
              value={applVO.billFirstName}
              onChange={this.props.handleAlpha("billFirstName", "applVO")}
              onBlur={this.props.handleOnBlur("applVO")}
              disabled={originalApplication}
              isErrorField={checkErrorField("billFirstName", searchResultsVo)}
              width="265px"
            />
            <div className={classes.validationMessage} />
          </div>
          <div>
            <InputField
              name="billMiddleName"
              label="Middle Name"
              id="billMiddleName"
              maxLength={1}
              value={applVO.billMiddleName}
              onChange={this.props.handleAlpha("billMiddleName", "applVO")}
              onBlur={this.props.handleOnBlur("applVO")}
              disabled={originalApplication}
              isErrorField={checkErrorField("billMiddleName", searchResultsVo)}
            />
            <div className={classes.validationMessage} />
          </div>
          <div style={{ width: "385px" }}>
            <InputField
              name="billLastName"
              label="Last Name"
              id="billLastName"
              maxLength={35}
              value={applVO.billLastName}
              onChange={this.props.handleAlpha("billLastName", "applVO")}
              onBlur={this.props.handleOnBlur("applVO")}
              disabled={originalApplication}
              isErrorField={checkErrorField("billLastName", searchResultsVo)}
              width="363px"
            />
            <div className={classes.validationMessage} />
          </div>
          <div>
            <InputField
              name="achNameOnAct"
              label="Name On Account"
              maxLength={60}
              value={applVO.achNameOnAct}
              onChange={this.props.handlechange("achNameOnAct", "applVO")}
              onBlur={this.props.handleOnBlur("applVO")}
              disabled={originalApplication}
              isErrorField={checkErrorField("achNameOnAct", searchResultsVo)}
              width="550px"
            />
            <div className={classes.validationMessage} />
          </div>{" "}
        </div>
        <div className={classes.container}>
          <div style={{ width: "309px" }}>
            <Autocomplete1
              handleChange={this.handleChangeSearchSelectAuto}
              margin='0px'
              width="265px"
              vo='applVO'
              label='Account Type'
              options={dropdowns.lstAccountType}
              defaultValue={dropdowns.lstAccountType}
              value={dropdowns.lstAccountType.filter(data => data.value === applVO.achAccountType)[0]}
              name='achBillFrequency'
              disabled={originalApplication}
            />
            <div className={classes.validationMessageSelect} />
          </div>

          <div>
            <InputField
              name="bankAcctNbr"
              label="Bank Account Number"
              id="bankAcctNbr"
              maxLength={17}
              value={applVO.achbankAcctNbr}
              onChange={this.props.handleNumber("achbankAcctNbr", "applVO")}
              disabled={originalApplication}
              isErrorField={checkErrorField("achbankAcctNbr", searchResultsVo)}
            />
            <div className={classes.validationMessage}>
              {applVO.achAbaRoutingNbr !== ""
                ? this.props.validator.message(
                  "bankAcctNbr",
                  applVO.achbankAcctNbr,
                  "required"
                )
                : null}
            </div>
          </div>
          <div>
            <InputField
              name="abaRoutingNbr"
              label="ABA Routing Number"
              id="abaRoutingNbr"
              maxLength={9}
              value={applVO.achAbaRoutingNbr}
              onChange={this.props.handleNumber("achAbaRoutingNbr", "applVO")}
              disabled={originalApplication}
              isErrorField={checkErrorField(
                "achAbaRoutingNbr",
                searchResultsVo
              )}
            />
            <div className={classes.validationMessage}>
              {applVO.achbankAcctNbr !== ""
                ? this.props.validator.message(
                  "abaRoutingNbr",
                  applVO.achAbaRoutingNbr,
                  "required|size:9"
                )
                : null}
            </div>
          </div>

          <div style={{ width: "183px" }}>
            <Autocomplete1
              handleChange={this.handleChangeSearchSelectAuto}
              margin='0px'
              width="157px"
              vo='applVO'
              label='Billing Frequency'
              options={dropdowns.lstBillFrequency}
              defaultValue={dropdowns.lstBillFrequency}
              value={dropdowns.lstBillFrequency.filter(data => data.value === applVO.achBillFrequency)[0]}
              name='achBillFrequency'
              disabled={originalApplication}
            />
            <div className={classes.validationMessageSelect} />
          </div>
          <div style={{ width: "283px" }}>
            <InputField
              name="draftDay"
              label="Draft Day"
              id="draftDay"
              maxLength={2}
              value={applVO.achDraftDay}
              onChange={this.props.handleNumber("achDraftDay", "applVO")}
              disabled={originalApplication}
              isErrorField={checkErrorField("achDraftDay", searchResultsVo)}
              width="263px"
            />
            <div className={classes.validationMessage}>
              {applVO.achBankName !== "" ||
                applVO.achAbaRoutingNbr !== "" ||
                applVO.achbankAcctNbr !== ""
                ? this.props.validator.message(
                  "draftDay",
                  applVO.achDraftDay,
                  "between:1,28,num"
                )
                : null}
            </div>
          </div>
          <div>
            <InputField
              name="achBankName"
              label="Bank Name"
              id="bankName"
              maxLength={30}
              value={applVO.achBankName}
              onChange={this.props.handleAlphaNumeric("achBankName", "applVO")}
              onBlur={this.props.handleOnBlur("applVO", applVO.achBankName)}
              disabled={originalApplication}
              isErrorField={checkErrorField("bankName", searchResultsVo)}
              width="263px"
            />
            <div className={classes.validationMessage} />
          </div>
        </div>
      </Paper>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    dropdowns: state.dropdowns,
    searchResultsVo: state.applSearch.searchResultsVo,
  };
};
export default connect(mapStateToProps)(withStyles(Styles)(BankingInfo));
