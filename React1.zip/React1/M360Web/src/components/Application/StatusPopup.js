import DataTable from "../Home/DataTable";
import Paper from "@material-ui/core/Paper";
import React from "react";
import { StatusLogAction } from "../../redux/actions/ApplActions";
import { Styles } from "../../assets/styles/PopupTheme";
import { connect } from "react-redux";
import { STATUS_LOG_HEADER as header } from "../../constants/Headers/StatusLogHeader";
import { withStyles } from "@material-ui/core/styles";
import classNames from "classnames";

class StatusPopup extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedIndex: 0,
      page: 0,
      data: this.props.statusLogData ? this.props.statusLogData : []
    };
  }

  async componentDidMount() {
    await this.props.StatusLogAction(this.props.searchResultsVo.applVO.applId);
    await this.setState({ data: this.props.statusLogData });
  }
  onRowSelect = (index, page) => {
    this.setState({
      selectedIndex: index,
      page: page
    });
  };
  render() {
    const { classes } = this.props;
    return (
      <React.Fragment>
        <Paper
          className={classes.root}
          elevation={0}
          style={{ padding: "15px" }}
        >
          <div
            className={classes.buttonContainer}
            style={{ float: "right", marginTop: "5px" }}
          >
            <i
              style={{ fontSize: "25px", marginLeft: "5px", color: "black" }}
              className={classNames("fa fa-times")}
              onClick={this.props.close}
            />
          </div>

          <div className={classes.table}>
            <DataTable
              data={this.state.data}
              header={header}
              rowsPerPage={5}
              sortable={false}
              clicked={this.onRowSelect}
              index={this.state.selectedIndex}
              pageNo={this.state.page}
            />
          </div>
        </Paper>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  return {
    searchResultsVo: state.applSearch.searchResultsVo,
    statusLogData: state.applSearch.statusLogData
  };
};
const mapDispatchToProps = {
  StatusLogAction
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(StatusPopup));
