import React, { Component } from "react";
import Autocomplete1 from "../UI/Select";

import InputField from "../UI/InputField";
import Paper from "@material-ui/core/Paper";
import { Styles } from "../../assets/styles/Theme";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";
import { setValue } from "../../redux/actions/ApplActions";

class CancellationInfo extends Component {
  constructor(props) {
    super(props);
    this.state = {
      date: "",
    };
  }
  componentDidMount() {
    const cancelDate = this.props.searchResultsVo.applPlanVO.reqDtCov;
    var that = this;
    var date = new Date().getDate(); //Current Date
    let newdate = date < 10 ? "0" + date : date;
    var month = new Date().getMonth() + 1; //Current Month
    let newmonth = month < 10 ? "0" + month : month;
    var year = new Date().getFullYear(); //Current Year
    this.props.setValue("cancelDt", "applVO", cancelDate);
    that.setState({
      date: newmonth + "/" + newdate + "/" + year,
    });
  }

  setDate = (name, value, targetVo) => {
    if (targetVo === "searchVo") {
      this.setState((prevState) => ({
        searchVo: {
          ...prevState.searchVo,
          [name]: value,
        },
      }));
    } else {
      this.props.setValue(name, targetVo, value);
    }
  };

  render() {
    const { classes, searchResultsVo, dropdowns } = this.props;
    const { applVO } = searchResultsVo;

    return (
      <Paper elevation={0} className={classes.card}>
        <div className={classes.container}>
          <div>
            <InputField
              id="cancelDt"
              name="cancelDt"
              label="Date Processed"
              value={this.state.date}
            />

            <div className={classes.validationMessage}></div>
          </div>

          <div>
             <Autocomplete1 
                     handleChange={this.props.handlechangeAuto}
                     vo='applVO'
                     // margin='0px'
                    label ='Reason'
                    options={dropdowns.reasonList}
                    defaultValue={dropdowns.reasonList[0]}
                     // value={searchResultsVo.lstCity.filter(data => data.value === applAddress.perCity)[0]}
                     value={dropdowns.reasonList.filter(data => data.value === applVO.cancelReason)[0]}
                    name='cancelReason'
                    width="280px"
                    
                    />
            <div className={classes.validationMessageSelect}>
              {this.props.validator.message(
                "Reason",
                applVO.cancelReason,
                "required"
              )}
            </div>
          </div>
        </div>
      </Paper>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    dropdowns: state.dropdowns,
    searchResultsVo: state.applSearch.searchResultsVo,
  };
};
const mapDispatchToProps = {
  setValue,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(CancellationInfo));
