import React, { Component } from "react";
import Autocomplete1 from "../UI/Select";
import {
  fetchCities,
  fetchCityCounty,
  fetchMailCityCounty,
  resetAddress,
  setMailingZip,
  setPrimaryZip,
  setValue,
} from "../../redux/actions/ApplActions";

import CheckBoxIcon from "@material-ui/icons/CheckBox";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import Checkbox from "@material-ui/core/Checkbox";
import CityZipSerachPopup from "./ApplCityZipSearch";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import InputField from "../UI/InputField";
import Paper from "@material-ui/core/Paper";
import Popup from "reactjs-popup";
import { Styles } from "../../assets/styles/Theme";
import { connect } from "react-redux";
import isEmpty from "lodash/isEmpty";
import { withStyles } from "@material-ui/core/styles";
import checkErrorField from "../../utils/CheckErrorField";
import FormLabel from "@material-ui/core/FormLabel";

class Address extends Component {
  state = {
    disableTextField: false,
    showEmergencyInfo: true,
    appFields: [],
  };

  validateMailingAddress = () => {
    const searchResultsVo = this.props.searchResultsVo.applAddress;

    if (
      isEmpty(searchResultsVo.mailAdd1) &&
      isEmpty(searchResultsVo.mailState) &&
      isEmpty(searchResultsVo.mailCity) &&
      isEmpty(searchResultsVo.mailZip4) &&
      isEmpty(searchResultsVo.mailAdd2) &&
      isEmpty(searchResultsVo.mailCountry)
    ) {
      return true;
    }
    return false;
  };

  handleMailingCountryChange = (event, name) => {
    let value = event.value;
    this.handleChangeDropDown(value);
    if (value !== "USA" && value !== "") {
      this.setState({
        disableTextField: true,
      });
    } else {
      this.setState({
        disableTextField: false,
      });
    }
  };

  populateCityCounty = async (event) => {
    event.preventDefault();
    let value = event.target.value.replace(/[^0-9]/g, "");
    this.props.setValue("perZip5", "applAddress", value);
    let zip4 = this.props.searchResultsVo.applAddress.perZip4;
    if (value !== null && value.length === 5) {
      await this.props.fetchCityCounty(value, zip4);
      if (this.props.searchResultsVo.lstCounty.length > 0) {
        this.props.setValue(
          "perCounty",
          "applAddress",
          this.props.searchResultsVo.lstCounty[0].value
        );
      }
      if (this.props.searchResultsVo.lstCity.length > 0) {
        this.props.setValue(
          "perCity",
          "applAddress",
          this.props.searchResultsVo.lstCity[0].value
        );
      }
    }
  };
  populateCityCountyMail = async (event) => {
    event.preventDefault();
    let value = event.target.value.replace(/[^0-9]/g, "");
    this.props.setValue("mailZip5", "applAddress", value);
    let zip4 = this.props.searchResultsVo.applAddress.mailZip4;
    if (value !== null && value.length === 5) {
      await this.props.fetchMailCityCounty(value, zip4);
      if (this.props.searchResultsVo.mailCounty.length > 0) {
        this.props.setValue(
          "mailCounty",
          "applAddress",
          this.props.searchResultsVo.mailCounty[0].value
        );
      }
      if (this.props.searchResultsVo.mailCity.length > 0) {
        this.props.setValue(
          "mailCity",
          "applAddress",
          this.props.searchResultsVo.mailCity[0].value
        );
      }
    }
  };

  fetchCitiesOnZip4 = async (event) => {
    let name = event.target.id;
    event.preventDefault();
    let value = event.target.value.replace(/[^0-9]/g, "");
    if (name === "mailZip4") {
      this.props.setValue("mailZip4", "applAddress", value);
    } else {
      this.props.setValue("perZip4", "applAddress", value);
    }

    let zip5 = this.props.searchResultsVo.applAddress.perZip5;
    if (
      zip5 !== null &&
      zip5.length === 5 &&
      value !== null &&
      value.length === 4
    ) {
      await this.props.fetchCityCounty(zip5, value);
      if (this.props.searchResultsVo.lstCounty.length > 0) {
        this.props.setValue(
          "perCounty",
          "applAddress",
          this.props.searchResultsVo.lstCounty[0].value
        );
      }
      if (this.props.searchResultsVo.lstCity.length > 0) {
        this.props.setValue(
          "perCity",
          "applAddress",
          this.props.searchResultsVo.lstCity[0].value
        );
      }
    }
  };

  handleCounty = (name, targetVo) => async (event) => {
    let value = event.value;
    await this.props.setValue(name, targetVo, value);
    this.fetchCity(value);
  };

  fetchCity = (value) => {
    let zip5 = this.props.searchResultsVo.applAddress.perZip5;
    if (zip5 !== null && zip5.length === 5 && value) {
      this.props.fetchCities(zip5, value);
    }
  };

  handleCheckbox = (name, targetVo) => (event) => {
    let value =
      name === "outOfArea"
        ? event.target.checked
          ? "E"
          : "N"
        : event.target.checked
        ? "Y"
        : "";
    this.props.setValue(name, targetVo, value);
  };

  handleChangeDropDown = (value) => {
    const name = "mailCountry";
    const targetVo = "applAddress";
    if (value !== "USA" && value !== "") {
      this.props.resetAddress(value);
    } else {
      this.props.setValue(name, targetVo, value);
    }
  };

  static getDerivedStateFromProps(nextProps, prevState) {
    const { searchResultsVo, loginProfile } = nextProps;
    const CMAEMRGIND = loginProfile.filter(
      (data) => data.label === "CMAEMRGIND"
    );
    const showEmergencyInfo =
      searchResultsVo.applVO.applType === "NMA" ||
      searchResultsVo.applVO.applType === "NPD" ||
      (searchResultsVo.applVO.applType === "CMA" && CMAEMRGIND[0].value === "Y")
        ? true
        : false;
    return {
      showEmergencyInfo: showEmergencyInfo,
    };
  }

  async componentDidMount() {
    const { loginProfile } = this.props;
    const APPFIELDS = loginProfile.filter((data) => data.label === "APPFIELDS");
    this.setState({
      appFields: APPFIELDS[0],
    });
  }

  render() {
    const {
      classes,
      searchResultsVo,
      originalApplication,
      dropdowns,
    } = this.props;
    const applAddress = searchResultsVo.applAddress;
    const applVO = searchResultsVo.applVO;
    const { appFields } = this.state;

    //let city = applAddress.perCity?searchResultsVo.lstCity.filter(data => data.value === applAddress.perCity)[0]:searchResultsVo.lstCity[0];

    return (
      <Paper elevation={0} className={classes.card}>
        <div class="panel-body">
          <div class="twin-boxes">
            <div class="panel-subhead expanded2">
              <h3>Primary Address</h3>
            </div>
            <div className={classes.textField}>
              <FormControlLabel
                control={
                  <Checkbox
                    style={{ width: 16, height: 16, marginRight: 16 }}
                    className="OutofAreacheckboxlbl"
                    color="primary"
                    id="ooaInd"
                    icon={
                      <CheckBoxOutlineBlankIcon
                        className={classes.checkBoxStyle}
                      />
                    }
                    checkedIcon={
                      <CheckBoxIcon className={classes.checkBoxStyle} />
                    }
                    checked={applVO.outOfArea === "E" ? true : false}
                    disabled={originalApplication}
                    onChange={this.handleCheckbox("outOfArea", "applVO")}
                  />
                }
                label="Out of Area"
                classes={{ label: classes.formLabel }}
              />
            </div>
            <div class="form-panel">
              <div className={classes.container}>
                <div>
                  <InputField
                    name="perAdd1"
                    label="Address Line 1"
                    disabled={originalApplication}
                    value={applAddress.perAdd1}
                    maxLength={50}
                    width="372px"
                    onChange={this.props.handlechange("perAdd1", "applAddress")}
                    onBlur={this.props.handleOnBlur("applAddress")}
                    required
                    isErrorField={checkErrorField("perAdd1", searchResultsVo)}
                  />
                  <div className={classes.validationMessage}>
                    {this.props.validator.message(
                      "AddressLine1",
                      applAddress.perAdd1,
                      "required"
                    )}
                  </div>
                </div>
                <div>
                  <InputField
                    name="perAdd2"
                    label="Address Line 2"
                    disabled={originalApplication}
                    value={applAddress.perAdd2}
                    maxLength={50}
                    onChange={this.props.handlechange("perAdd2", "applAddress")}
                    onBlur={this.props.handleOnBlur("applAddress")}
                    isErrorField={checkErrorField("perAdd2", searchResultsVo)}
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="perAdd3"
                    label="Address Line 3"
                    value={applAddress.perAdd3}
                    disabled={originalApplication}
                    maxLength={50}
                    onChange={this.props.handlechange("perAdd3", "applAddress")}
                    onBlur={this.props.handleOnBlur("applAddress")}
                    isErrorField={checkErrorField("perAdd3", searchResultsVo)}
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div className={classes.citydropdown}>
                  <Autocomplete1
                    handleChange={this.props.handlechangeAuto}
                    vo="applAddress"
                    // margin='0px'
                    label="City"
                    options={searchResultsVo.lstCity}
                    defaultValue={
                      applAddress.perCity
                        ? searchResultsVo.lstCity.filter(
                            (data) => data.value === applAddress.perCity
                          )[0]
                        : { label: "Select", value: "" }
                    }
                    //value={searchResultsVo.lstCity.filter(data => data.value === applAddress.perCity)[0]}
                    value={
                      searchResultsVo.lstCity.filter(
                        (data) => data.value === applAddress.perCity
                      )[0]
                    }
                    name="perCity"
                    width="250px"
                    disabled={originalApplication}
                  />

                  <div className={classes.validationMessage}>
                    {this.props.validator.message(
                      "city",
                      applAddress.perCity,
                      "required"
                    )}
                  </div>
                </div>

                <div>
                  <Autocomplete1
                    handleChange={this.props.handlechangeAuto}
                    // handleChange={this.props.handlechange("applType", "applVO")}
                    vo="applAddress"
                    // margin='0px'
                    label="State"
                    options={dropdowns.lstStates}
                    defaultValue={dropdowns.lstStates[0]}
                    value={
                      dropdowns.lstStates.filter(
                        (data) => data.value === applAddress.perState
                      )[0]
                        ? dropdowns.lstStates.filter(
                            (data) => data.value === applAddress.perState
                          )[0]
                        : dropdowns.lstStates[0]
                    }
                    name="perState"
                    disabled={originalApplication}
                  />
                  <div className={classes.validationMessageSelect}>
                    {this.props.validator.message(
                      "state",
                      applAddress.perState,
                      "required"
                    )}
                  </div>
                </div>
                <div>
                  <span class="label-container">
                    <label htmlFor="zip2">Zip</label>
                    <span className="imp">*</span>
                    <br />
                    <input
                      type="text"
                      class="form-field zip"
                      id="perZip5"
                      maxLength={5}
                      value={applAddress.perZip5}
                      disabled={originalApplication}
                      onChange={this.populateCityCounty}
                      style={{
                        backgroundColor: checkErrorField(
                          "perZip5",
                          searchResultsVo
                        )
                          ? "yellow"
                          : null,
                      }}
                    />
                    <input
                      type="text"
                      class="form-field zip input-popup"
                      id="perZip4"
                      maxLength={4}
                      value={applAddress.perZip4}
                      disabled={originalApplication}
                      onChange={this.fetchCitiesOnZip4}
                      style={{
                        backgroundColor: checkErrorField(
                          "perZip4",
                          searchResultsVo
                        )
                          ? "yellow"
                          : null,
                      }}
                    />

                    {!originalApplication ? (
                      <Popup
                        className={classes.mobileWidth}
                        modal
                        trigger={<span class="more-info" id="peraddress-zip" />}
                        position="right center"
                      >
                        {(close) => (
                          <div>
                            <CityZipSerachPopup
                              zip5={applAddress.perZip5}
                              zip4={applAddress.perZip4}
                              setData={this.props.setPrimaryZip}
                              primaryAddress
                              close={close}
                            />
                          </div>
                        )}
                      </Popup>
                    ) : null}
                  </span>
                  <div className={classes.validationMessageSelect}>
                    {this.props.validator.message(
                      "zip5",
                      applAddress.perZip5,
                      "required"
                    )}
                  </div>
                </div>

                <div>
                  <Autocomplete1
                    handleChange={this.props.handlechangeAuto}
                    // handleChange={this.props.handlechange("applType", "applVO")}
                    vo="applAddress"
                    // margin='0px'
                    label="County"
                    options={searchResultsVo.lstCounty}
                    defaultValue={
                      applAddress.perCounty
                        ? searchResultsVo.lstCounty.filter(
                            (data) => data.value === applAddress.perCounty
                          )[0]
                        : searchResultsVo.lstCounty[0]
                        ? searchResultsVo.lstCounty[0]
                        : { label: "Select", value: "" }
                    }
                    value={
                      applAddress.perCounty
                        ? searchResultsVo.lstCounty.filter(
                            (data) => data.value === applAddress.perCounty
                          )[0]
                        : searchResultsVo.lstCounty[0]
                        ? searchResultsVo.lstCounty[0]
                        : { label: "Select", value: "" }
                    }
                    name="perCounty"
                    disabled={originalApplication}
                  />
                  <div className={classes.validationMessageSelect}>
                    {this.props.validator.message(
                      "County",
                      applAddress.perCounty,
                      "required"
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="twin-boxes">
            <div class="panel-subhead expanded2">
              <h3>Mailing Address</h3>
            </div>
            <div class="form-panel">
              <div className={classes.container}>
                <div>
                  <InputField
                    name="mailFirstName"
                    label="First Name"
                    maxLength={24}
                    disabled={originalApplication}
                    value={applVO.mailFirstName}
                    onChange={this.props.handlechange(
                      "mailFirstName",
                      "applVO"
                    )}
                    onBlur={this.props.handleOnBlur("applVO")}
                    isErrorField={checkErrorField(
                      "mailFirstName",
                      searchResultsVo
                    )}
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="mailMiddleName"
                    label="Middle Name"
                    maxLength={1}
                    disabled={originalApplication}
                    value={applVO.mailMiddleName}
                    onChange={this.props.handlechange(
                      "mailMiddleName",
                      "applVO"
                    )}
                    onBlur={this.props.handleOnBlur("applVO")}
                    isErrorField={checkErrorField(
                      "mailMiddleName",
                      searchResultsVo
                    )}
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="mailLastName"
                    label="Last Name"
                    maxLength={35}
                    disabled={originalApplication}
                    value={applVO.mailLastName}
                    onChange={this.props.handlechange("mailLastName", "applVO")}
                    onBlur={this.props.handleOnBlur("applVO")}
                    isErrorField={checkErrorField(
                      "mailLastName",
                      searchResultsVo
                    )}
                  />
                  <div className={classes.validationMessage} />
                </div>

                <div>
                  <InputField
                    name="mailSuffix"
                    label="Suffix"
                    maxLength={4}
                    disabled={originalApplication}
                    value={applVO.mailSuffix}
                    onChange={this.props.handlechange("mailSuffix", "applVO")}
                    onBlur={this.props.handleOnBlur("applVO")}
                    isErrorField={checkErrorField(
                      "mailSuffix",
                      searchResultsVo
                    )}
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div />
                <div>
                  <InputField
                    name="mailAdd1"
                    label="Address Line 1"
                    maxLength={50}
                    width="379px"
                    disabled={originalApplication}
                    value={applAddress.mailAdd1}
                    onChange={this.props.handlechange(
                      "mailAdd1",
                      "applAddress"
                    )}
                    onBlur={this.props.handleOnBlur("applAddress")}
                    isErrorField={checkErrorField("mailAdd1", searchResultsVo)}
                  />
                  <div className={classes.validationMessage}>
                    {
                      <div>
                        {this.props.validator.message(
                          "Mailing address",
                          [
                            applAddress.mailZip5,
                            applAddress.mailAdd1,
                            applAddress.mailZip5 +
                              applAddress.mailAdd1 +
                              applAddress.mailCity +
                              applAddress.mailState,
                            applAddress.mailAdd1,
                          ],
                          "if_zip_entered|mailing_address"
                        )}
                      </div>
                    }
                  </div>
                </div>
                <div>
                  <InputField
                    name="mailAdd2"
                    label="Address Line 2"
                    maxLength={50}
                    disabled={originalApplication}
                    value={applAddress.mailAdd2}
                    onChange={this.props.handlechange(
                      "mailAdd2",
                      "applAddress"
                    )}
                    onBlur={this.props.handleOnBlur("applAddress")}
                    isErrorField={checkErrorField("mailAdd2", searchResultsVo)}
                  />
                  <div className={classes.validationMessage}>
                    {/* {!this.validateMailingAddress()
                      ? !(
                        applAddress.mailCountry === "USA" ||
                        applAddress.mailCountry === ""
                      )
                        ? this.props.validator.message(
                          "AddressLine2",
                          applAddress.mailAdd2,
                          "required"
                        )
                        : null
                      : null} */}
                  </div>
                </div>
                <div>
                  <InputField
                    name="mailAdd3"
                    label="Address Line 3"
                    maxLength={50}
                    width="379px"
                    disabled={originalApplication}
                    value={applAddress.mailAdd3}
                    onChange={this.props.handlechange(
                      "mailAdd3",
                      "applAddress"
                    )}
                    onBlur={this.props.handleOnBlur("applAddress")}
                    isErrorField={checkErrorField("mailAdd3", searchResultsVo)}
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div className={classes.citydropdown}>
                  <InputField
                    name="mailCity"
                    label="City"
                    maxLength={20}
                    disabled={
                      this.state.disableTextField || originalApplication
                    }
                    value={applAddress.mailCity}
                    width="250px"
                    onChange={this.props.handlechange(
                      "mailCity",
                      "applAddress"
                    )}
                    onBlur={this.props.handleOnBlur("applAddress")}
                    isErrorField={checkErrorField("mailCity", searchResultsVo)}
                  />
                  <div className={classes.validationMessage}>
                    {
                      <div>
                        {this.props.validator.message(
                          "Address",
                          [
                            applAddress.mailZip5,
                            applAddress.mailCity,
                            applAddress.mailZip5 +
                              applAddress.mailAdd1 +
                              applAddress.mailCity +
                              applAddress.mailState,
                            applAddress.mailCity,
                          ],
                          "if_zip_entered|mailing_address"
                        )}
                      </div>
                    }
                  </div>
                </div>

                <div>
                  <Autocomplete1
                    handleChange={this.props.handlechangeAuto}
                    vo="applAddress"
                    // margin='0px'
                    label="State"
                    options={dropdowns.lstStates}
                    defaultValue={dropdowns.lstStates[0]}
                    //  value={dropdowns.lstStates.filter(data => data.value === applAddress.mailState)[0]}
                    value={
                      dropdowns.lstStates.filter(
                        (data) => data.value === applAddress.mailState
                      )[0]
                        ? dropdowns.lstStates.filter(
                            (data) => data.value === applAddress.mailState
                          )[0]
                        : dropdowns.lstStates[0]
                    }
                    name="mailState"
                    disabled={
                      originalApplication || this.state.disableTextField
                    }
                  />
                  <div className={classes.validationMessageSelect}>
                    <div className={classes.validationMessage}>
                      {
                        <div>
                          {this.props.validator.message(
                            "State",
                            [
                              applAddress.mailZip5,
                              applAddress.mailState,
                              applAddress.mailZip5 +
                                applAddress.mailAdd1 +
                                applAddress.mailCity +
                                applAddress.mailState,
                              applAddress.mailState,
                            ],
                            "if_zip_entered|mailing_address"
                          )}
                        </div>
                      }
                    </div>
                  </div>
                </div>
                <div>
                  <span class="label-container" style={{ marginRight: "30px" }}>
                    <label htmlFor="zip2">Zip</label>
                    <br />
                    <div>
                      <input
                        type="text"
                        class="form-field zip"
                        id="mailZip5"
                        maxLength={5}
                        value={applAddress.mailZip5 ? applAddress.mailZip5 : ""}
                        onChange={this.populateCityCountyMail}
                        disabled={
                          this.state.disableTextField || originalApplication
                        }
                        style={{
                          backgroundColor: checkErrorField(
                            "mailZip5",
                            searchResultsVo
                          )
                            ? "yellow"
                            : null,
                        }}
                      />
                      <input
                        type="text"
                        class="form-field zip input-popup"
                        id="mailZip4"
                        maxLength={4}
                        value={applAddress.mailZip4 ? applAddress.mailZip4 : ""}
                        onChange={this.fetchCitiesOnZip4}
                        disabled={
                          this.state.disableTextField || originalApplication
                        }
                        style={{
                          backgroundColor: checkErrorField(
                            "mailZip4",
                            searchResultsVo
                          )
                            ? "yellow"
                            : null,
                        }}
                      />

                      {!originalApplication ? (
                        <Popup
                          className={classes.mobileWidth}
                          modal
                          trigger={
                            <span class="more-info" id="mailaddress-zip" />
                          }
                          position="right center"
                        >
                          {(close) => (
                            <div>
                              <CityZipSerachPopup
                                zip5={applAddress.mailZip5}
                                zip4={applAddress.mailZip4}
                                setData={this.props.setMailingZip}
                                close={close}
                              />
                            </div>
                          )}
                        </Popup>
                      ) : null}
                    </div>
                  </span>
                  <div className={classes.validationMessage}>
                    {
                      <div>
                        {this.props.validator.message(
                          "Zip",
                          [
                            applAddress.mailZip5,
                            applAddress.mailState,
                            applAddress.mailZip5 +
                              applAddress.mailAdd1 +
                              applAddress.mailCity +
                              applAddress.mailState,
                            applAddress.mailZip5,
                          ],
                          "mailing_address"
                        )}
                      </div>
                    }
                  </div>
                </div>
                <div id="country-dropdown">
                  <Autocomplete1
                    handleChange={this.handleMailingCountryChange}
                    width={"360px"}
                    vo="applVO"
                    // margin='0px'
                    label="Country"
                    options={dropdowns.lstCountry}
                    defaultValue={dropdowns.lstCountry[0]}
                    value={
                      dropdowns.lstCountry.filter(
                        (data) => data.value === applAddress.mailCountry
                      )[0]
                    }
                    name="mailCountry"
                    disabled={originalApplication}
                  />
                  <div className={classes.validationMessageSelect} />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className={classes.applicationSectionHeading}>
          <span>Contact Information</span>
        </div>
        <div className={classes.container}>
          <div style={{ width: "396px" }}>
            <InputField
              // type="email"
              name="mbrEmail"
              label="Email"
              value={applVO.mbrEmail}
              disabled={originalApplication}
              maxLength={50}
              width="372px"
              onChange={this.props.handlechange("mbrEmail", "applVO")}
              onBlur={this.props.handleOnBlur("applVO")}
              isErrorField={checkErrorField("mbrEmail", searchResultsVo)}
            />
            <div className={classes.validationMessage}>
              {this.props.validator.message("Email", applVO.mbrEmail, "email")}
            </div>
          </div>
          {appFields.value === "Y" ? (
            <div className={classes.textField}>
              <FormLabel>Health Plan News via E-mail</FormLabel>
              <Checkbox
                style={{ width: 36, height: 36 }}
                name="healthPlanNews"
                color="primary"
                id="healthPlanNews"
                icon={
                  <CheckBoxOutlineBlankIcon className={classes.checkBoxStyle} />
                }
                checkedIcon={<CheckBoxIcon className={classes.checkBoxStyle} />}
                checked={applVO.healthPlanNews === "Y" ? true : false}
                //disabled={applVO.healthPlanNews === "Y" ? true : false}
                onChange={this.handleCheckbox("healthPlanNews", "applVO")}
                value={applVO.healthPlanNews}
              />
            </div>
          ) : null}
          <div>
            <InputField
              name="perPhone"
              label="Home Phone"
              maxLength={12}
              disabled={originalApplication}
              value={applAddress.perPhone ? applAddress.perPhone : ""}
              onChange={this.props.handleNumberChange(
                "perPhone",
                "applAddress"
              )}
              isErrorField={checkErrorField("perPhone", searchResultsVo)}
            />
            <div className={classes.validationMessage}>
              {this.props.validator.message(
                "Home Phone",
                applAddress.perPhone,
                "phone_no"
              )}
            </div>
          </div>
          <div style={{ width: "230px" }}>
            <InputField
              name="perWorkPhone"
              label="Work Phone"
              maxLength={12}
              disabled={originalApplication}
              value={applAddress.perWorkPhone ? applAddress.perWorkPhone : ""}
              onChange={this.props.handleNumberChange(
                "perWorkPhone",
                "applAddress"
              )}
              isErrorField={checkErrorField("perWorkPhone", searchResultsVo)}
              width="205px"
            />
            <div className={classes.validationMessage}>
              {this.props.validator.message(
                "Work Phone",
                applAddress.perWorkPhone,
                "phone_no"
              )}
            </div>
          </div>

          <div>
            <InputField
              name="perCell"
              label="Cell Phone"
              maxLength={12}
              disabled={originalApplication}
              value={applAddress.perCell ? applAddress.perCell : ""}
              onChange={this.props.handleNumberChange("perCell", "applAddress")}
              isErrorField={checkErrorField("perCell", searchResultsVo)}
            />
            <div className={classes.validationMessage}>
              {this.props.validator.message(
                "Cell Phone",
                applAddress.perCell,
                "phone_no"
              )}
            </div>
          </div>
          <div />
          <div>
            <InputField
              name="perFax"
              label="FAX"
              maxLength={12}
              disabled={originalApplication}
              value={applAddress.perFax ? applAddress.perFax : ""}
              onChange={this.props.handleNumberChange("perFax", "applAddress")}
              isErrorField={checkErrorField("perFax", searchResultsVo)}
              width="266px"
            />
            <div className={classes.validationMessageSelect}>
              {this.props.validator.message(
                "FAX",
                applAddress.perFax ? applAddress.perFax : "",
                "phone_no"
              )}
            </div>
          </div>
        </div>
        {this.state.showEmergencyInfo ? (
          <React.Fragment>
            <div className={classes.applicationSectionHeading}>
              <span>Emergency Contact Information</span>
            </div>
            <div className={classes.container}>
              <div>
                <InputField
                  name="emergName"
                  label="Name"
                  maxLength={50}
                  disabled={originalApplication}
                  value={applVO.emergName}
                  onChange={this.props.handleAlpha("emergName", "applVO")}
                  onBlur={this.props.handleOnBlur("applVO")}
                  width="372px"
                  isErrorField={checkErrorField("emergName", searchResultsVo)}
                />
                <div className={classes.validationMessage} />
              </div>
              <div className={classes.tabmargin}>
                <InputField
                  name="emergPhone"
                  label="Contact Number"
                  maxLength={12}
                  disabled={originalApplication}
                  value={applVO.emergPhone}
                  onChange={this.props.handleNumberChange(
                    "emergPhone",
                    "applVO"
                  )}
                />
                <div className={classes.validationMessage}>
                  {this.props.validator.message(
                    "Contact Number",
                    applVO.emergPhone,
                    "phone_no"
                  )}
                </div>
              </div>

              <div style={{ width: "230px" }}>
                <Autocomplete1
                  handleChange={this.props.handlechangeAuto}
                  width={"205px"}
                  vo="applVO"
                  // margin='0px'
                  label="Relation"
                  options={dropdowns.lstRelations}
                  defaultValue={dropdowns.lstRelations[0]}
                  value={
                    dropdowns.lstRelations.filter(
                      (data) => data.value === applVO.emergRelation
                    )[0]
                  }
                  name="emergRelation"
                  disabled={originalApplication}
                />
                <div className={classes.validationMessageSelect} />
              </div>
              <div>
                <InputField
                  type="email"
                  name="email"
                  label="(Optional) E-Mail Address"
                  width="470px"
                  maxLength={50}
                  disabled={originalApplication}
                  value={applVO.emergEmail}
                  onChange={this.props.handlechange("emergEmail", "applVO")}
                  onBlur={this.props.handleOnBlur("applVO")}
                  isErrorField={checkErrorField("email", searchResultsVo)}
                />
                <div className={classes.validationMessage}>
                  {this.props.validator.message(
                    "email",
                    applVO.emergEmail,
                    "email"
                  )}
                </div>
              </div>
            </div>
          </React.Fragment>
        ) : null}
      </Paper>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    dropdowns: state.dropdowns,
    searchResultsVo: state.applSearch.searchResultsVo,
    loginProfile: state.loginData.profiles,
  };
};
const mapDispatchToProps = {
  resetAddress,
  setValue,
  setPrimaryZip,
  setMailingZip,
  fetchCityCounty,
  fetchMailCityCounty,
  fetchCities,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(Address));
