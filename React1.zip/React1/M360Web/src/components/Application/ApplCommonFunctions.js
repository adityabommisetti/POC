export const fetchLabelFromValue= (list,value)=>{
    if(list===undefined||list===null)
    {
        return "";
    }
    const result= list.find(option => (option.value === value));
    if(result===undefined||result===null)
    {
        return "";
    }
   return result.label;
}