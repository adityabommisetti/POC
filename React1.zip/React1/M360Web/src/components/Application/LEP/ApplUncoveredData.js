import * as DateUtil from "../../../utils/DatePicker";
import * as Type from "../../../constants/ConfirmType";

import React, { Component } from "react";
import {
  addUncoveredDetail,
  deleteUncoveredDetail,
  showActiveUncovData,
  showAllUncoveredDetail,
} from "../../../redux/actions/ApplActions";
import isEmpty from "lodash/isEmpty";
import Badge from "@material-ui/core/Badge";
import Button from "@material-ui/core/Button";
import ConfirmBox from "../../../utils/PopUp";
import DataTable from "../../Home/DataTable";
import HistoryData from "../../UI/MemberHistory";
import InputField from "../../UI/InputField";
import Modal from "../../../components/UI/Modal/Modal";
import Paper from "@material-ui/core/Paper";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../../assets/styles/Theme";
import Typography from "@material-ui/core/Typography";
import { connect } from "react-redux";
import { customValidations } from "../../../utils/CustomValidations";
import { UNCOVERED_TABLE_HEADER as header } from "../../../constants/Headers/MemberHeaders";
import { withStyles } from "@material-ui/core/styles";
import { handleDateChange } from "../../../utils/DateFormatter";

class UncoveredData extends Component {
  constructor(props) {
    super(props);
    this.state = {
      addVo: {
        uncovMthStDtFrmt: "",
        uncovMthEndDtFrmt: "",
      },
      selectedRow: 0,
      showAll: false,
      showModal: false,
      message: "",
    };

    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
        first_day_of_month: customValidations.first_day_of_month,
        last_day_of_month: customValidations.last_day_of_month,
        after_start_date: customValidations.c_after,
        date_before: customValidations.c_date_before,
        date_conflict: customValidations.date_conflict_uncov,
      },
    });
  }

  handlechange = (event) => {
    let value = event.target.value;
    let name = event.target.name;
    // value = value.replace(/[^0-9]/g, "").trim();
    // if (value.length === 8) {
    //   value = value.replace(/^(\d{2})/, "$1/");
    //   value = value.replace(/\/(\d{2})/, "/$1/");
    //   value = value.replace(/(\d)\/(\d{4}).*/, "$1/$2");
    // }
    // this.setValue(name, value);
    this.setState((prevState) => ({
      addVo: {
        ...prevState.addVo,
        [name]: handleDateChange(value),
      },
      modified: true,
    }));
  };

  handleStartDate = (event) => {
    var self = this;
    const fieldId = "#" + event.target.name;
    DateUtil.getStartDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        self.setValue(e.target.name, e.target.value);
      });
  };

  handleLastDate = (event) => {
    var self = this;
    const fieldId = "#" + event.target.name;
    DateUtil.getLastDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        self.setValue(e.target.name, e.target.value);
      });
  };

  selectRow = (index) => {
    this.setState({
      selectedRow: index,
    });
  };

  setValue = (name, value) => {
    this.setState((prevState) => ({
      addVo: {
        ...prevState.addVo,
        [name]: value,
      },
    }));
  };

  toggleShowAll = async () => {
    await this.setState((prevState) => ({
      showAll: !prevState.showAll,
    }));
    if (this.state.showAll) {
      this.props.showAllUncoveredDetail(
        this.props.searchResultsVo.applVO.applId
      );
    } else {
      this.props.showActiveUncovData(this.props.data.potentialUnCovMthsList);
    }
  };

  deleteUncoveredDetail = () => {
    ConfirmBox(this.confirmDelete, Type.DELETE, this.props);
  };

  confirmDelete = async () => {
    const selectedRow = this.state.selectedRow;
    await this.props
      .deleteUncoveredDetail(
        this.props.data.potentialUnCovMthsList[selectedRow],
        selectedRow,
        this.props.data.potentialUnCovMthsList
      )
      .then(() =>
        this.setState({
          message: "DELETE SUCCESSFULLY",
          showModal: true,
        })
      )
      .catch(() =>
        this.setState({
          message: "ERROR",
          showModal: true,
        })
      );
    //this.setModal(status);
    //if (selectedRow >= this.props.data.potentialUnCovMthsList.length) {
    this.setState((prevState) => ({
      selectedRow: 0,
    }));
    //  }
  };

  addUncoveredDetail = () => {
    if (!this.validator.allValid()) {
      this.validator.showMessages();
      this.forceUpdate();
      return;
    }if(new Date(this.state.addVo.uncovMthStDtFrmt).getTime() > new Date(this.props.searchResultsVo.applPlanVO.reqDtCov).getTime()){
      alert("Uncovered Start date cannot be later than the application effective date of coverage")
      return
    }
    ConfirmBox(this.confirmInsert, Type.ADD, this.props);
  };

  confirmInsert = () => {
    this.props
      .addUncoveredDetail(this.props.searchResultsVo, this.state.addVo)
      .then(() =>
        this.setState({
          message: "ADDED SUCCESSFULLY",
          showModal: true,
          uncovMthStDtFrmt:"",
          uncovMthEndDtFrmt:""
        })
      )
      .catch(() =>
        this.setState({
          message: "ERROR",
          showModal: true,
        })
      );
  };
  modalClosed = () => {
    this.setState({ showModal: false });
  };

  setModal = (status) => {
    status
      .then(() =>
        this.setState({
          message: "ADDED SUCCESSFULLY",
          showModal: true,
        })
      )
      .catch(() =>
        this.setState({
          message: "ERROR",
          showModal: true,
        })
      );
  };

  render() {
    const { classes, data } = this.props;
    const { selectedRow, addVo, showAll } = this.state;

    var totalUncovMonth = 0;
    if (data && !isEmpty(data.potentialUnCovMthsList)) {
      totalUncovMonth = data.potentialUnCovMthsList
        .map((unCovVo) => unCovVo.plepMonths)
        .reduce((val1, val2) => val1 + val2);
    }

    let buttonContainer = (
      <div className={classes.buttonContainer1}>
        <Button
          variant="contained"
          color="primary"
          onClick={this.toggleShowAll}
          className={classes.button}
        >
          {showAll ? "Show Active" : "Show All"}
        </Button>

        <Button
          variant="contained"
          color="primary"
          onClick={this.deleteUncoveredDetail}
          className={classes.button}
          disabled={
            this.state.editable ||
            this.props.searchResultsVo.suppLepPlatino === "true"
          }
        >
          Delete
        </Button>

        <Button
          variant="contained"
          color="primary"
          onClick={this.addUncoveredDetail}
          className={classes.button}
          disabled={
            this.state.editable ||
            this.props.searchResultsVo.suppLepPlatino === "true"
          }
        >
          Add
        </Button>
      </div>
    );

    return (
      <Paper elevation={0} className={classes.card}>
        <Modal
          dialogTitle="LEP"
          message={this.state.message}
          show={this.state.showModal}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        {data ? (
          <React.Fragment>
            <div style={{ width: "100%", textAlign: "center" }}>
              <div>
                <Typography
                  variant="h6"
                  id="tableTitle"
                  className={classes.attestation1}
                >
                  Total Uncovered Months -
                  <Badge
                    showZero
                    className={classes.badgeUncovered}
                    badgeContent={totalUncovMonth}
                    color="primary"
                    max={99999}
                  ></Badge>
                </Typography>
                <DataTable
                  data={data.potentialUnCovMthsList}
                  header={header}
                  rowsPerPage={3}
                  sortable={false}
                  clicked={this.selectRow}
                  index={this.state.selectedRow}
                  width="75%"
                />
              </div>
            </div>
            <div className={classes.buttonContainer}> {buttonContainer}</div>
            <div style={{ width: "100%", textAlign: "center" }}>
              <div style={{ display: "inline-flex" }}>
                <div style={{ textAlign: "left" }}>
                  <InputField
                    name="uncovMthStDtFrmt"
                    placeholder="MM/DD/YYYY"
                    label="Uncovered Months Start Date"
                    value={addVo.uncovMthStDtFrmt}
                    onClick={this.handleStartDate}
                    maxLength={10}
                    onChange={this.handlechange}
                  />

                  <div className={classes.validationMessage}>
                    {this.validator.message(
                      "StartDate",
                      addVo.uncovMthStDtFrmt,
                      [
                        "required",
                        "date_format",
                        "first_day_of_month",
                        {
                          
                          date_conflict: [
                            addVo.uncovMthStDtFrmt,                                                      
                            this.props.data.potentialUnCovMthsList,
                            addVo.uncovMthEndDtFrmt, 
                          ],
                        },
                      ]
                    )}
                  </div>
                </div>
                <div style={{ textAlign: "left" }}>
                  <InputField
                    name="uncovMthEndDtFrmt"
                    placeholder="MM/DD/YYYY"
                    label="Uncovered Months End Date"
                    value={addVo.uncovMthEndDtFrmt}
                    onClick={this.handleLastDate}
                    maxLength={10}
                    onChange={this.handlechange}
                  />

                  <div className={classes.validationMessage}>
                    {this.validator.message(
                      "EndDate",
                      addVo.uncovMthEndDtFrmt,
                      [
                        "required",
                        "date_format",
                        "last_day_of_month",
                        {
                          after_start_date: addVo.uncovMthStDtFrmt,
                          date_before: this.props.searchResultsVo.applPlanVO
                            .reqDtCov,
                        },
                      ]
                    )}
                  </div>
                </div>
              </div>
            </div>

            {data.potentialUnCovMthsList &&
              data.potentialUnCovMthsList.length > 0 ? (
                <div>
                  <HistoryData
                    createUserId={
                      data.potentialUnCovMthsList[selectedRow].createUserId
                    }
                    createTime={
                      data.potentialUnCovMthsList[selectedRow].createTime
                    }
                    lastUpdtTime={
                      data.potentialUnCovMthsList[selectedRow].lastUpdtTime
                    }
                    lastUpdtUserId={
                      data.potentialUnCovMthsList[selectedRow].lastUpdtUserId
                    }
                  />
                </div>
              ) : null}
          </React.Fragment>
        ) : null}
      </Paper>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    data: state.applSearch.lepData,
    searchResultsVo: state.applSearch.searchResultsVo,
  };
};
const mapDispatchToProps = {
  addUncoveredDetail,
  deleteUncoveredDetail,
  showAllUncoveredDetail,
  showActiveUncovData,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(UncoveredData));
