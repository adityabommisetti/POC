import * as DateUtil from "../../../utils/DatePicker";
import * as Type from "../../../constants/ConfirmType";

import React, { Component } from "react";
import {
  addAttestationData,
  deleteAttestationData,
} from "../../../redux/actions/ApplActions";
import Button from "@material-ui/core/Button";
import ConfirmBox from "../../../utils/PopUp";
import Modal from "../../../components/UI/Modal/Modal";
import MuiTableCell from "@material-ui/core/TableCell";
import Pagination from "../../UI/Pagination";
import SimpleReactValidator from "simple-react-validator";
import { styles as Styles } from "../../../assets/styles/DataTableStyle";
import SvgIcon from "@material-ui/core/SvgIcon";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableFooter from "@material-ui/core/TableFooter";
import TableHead from "@material-ui/core/TableHead";
import TablePagination from "@material-ui/core/TablePagination";
import TableRow from "@material-ui/core/TableRow";
import { connect } from "react-redux";
import { customValidations } from "../../../utils/CustomValidations";
import { ATTESTATION_TABLE_HEADER as header } from "../../../constants/Headers/MemberHeaders";
import orderBy from "lodash/orderBy";
import { withStyles } from "@material-ui/core/styles";
import { handleDateChange } from "../../../utils/DateFormatter";

function HomeIcon(props) {
  return (
    <SvgIcon {...props}>
      <path d={props.path} />
    </SvgIcon>
  );
}

const invertDirection = {
  asc: "desc",
  desc: "asc",
};

const styles = (theme) => ({
  ...Styles(theme),
  headerCellAttestation: {
    color: "white",
    paddingRight: 4,
    paddingLeft: 5,
  },
  validationMessage: {
    color: "red",
    fontSize: "12px",
    //marginLeft: "25px",
    //width: "180px"
  },
});

const TableCell = withStyles({
  root: {
    display: "table-cell",
    //padding: 4px 56px 4px 24px;
    // textAlign: 'left',
    borderBottom: "1px solid rgba(224, 224, 224, 1)",
    verticalAlign: "inherit",
    paddingLeft: "0px !important",
    paddingRight: "10px !important",
    // color: "white"
  },
})(MuiTableCell);

class DataTable extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedRow: 0,
      colToSort: "",
      sortDir: "desc",
      page: 0,
      rowsPerPage: this.props.rowsPerPage,
      showModal: false,
      message: "",
      attestationVO: {
        // applId: 208544,
        comptRespRecDateFrmt: "",
        brkInCoverage: "",
        credRXCoverage: "",
        fromDateFrmt: "",
        toDateFrmt: "",
        // lepEffDate: null,

        respType: "",
      },
    };
    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
        first_day_of_month: customValidations.first_day_of_month,
        last_day_of_month: customValidations.last_day_of_month,
        date_before: customValidations.c_date_before,
        after_start_date: customValidations.c_after,
        date_conflict: customValidations.date_conflict_ccf,
      },
    });
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      rowsPerPage: nextProps.rowsPerPage,
    });
  }
  addRow = () => {
    if (this.state.attestationVO.brkInCoverage === "N") {
      this.validator.fields.credRxCoverage = true;
    }
    if (this.validator.allValid())
      ConfirmBox(this.confirmAdd, Type.ADD, this.props);
    else {
      this.forceUpdate();
      this.validator.showMessages();
    }
  };

  confirmAdd = async () => {
    await this.props
      .addAttestationData(
        this.state.attestationVO,
        this.props.appId,
        this.props.reqDtCov
      )
      .then(() =>
        this.setState({
          message: "ADDED SUCCESSFULLY",
          showModal: true,
          comptRespRecDateFrmt: "",
          brkInCoverage: "",
          credRXCoverage: "",
          fromDateFrmt: "",
          toDateFrmt: "",
          respType: "",
        })
      )
      .catch(() =>
        this.setState({
          message: "ERROR",
          showModal: true,
        })
      );
  };
  handleSort = (colName) => {
    this.setState((prevState) => ({
      colToSort: colName,
      sortDir:
        this.state.colToSort === colName
          ? invertDirection[this.state.sortDir]
          : "asc",
    }));
  };

  rowSelect = (rowIndex) => {
    this.setState({
      selectedRow: rowIndex,
    });
    const index = this.state.page * this.state.rowsPerPage + rowIndex;
    this.props.clicked(index);
  };

  handleChangePage = async (page) => {
    await this.setState({
      page,
      selectedRow: 0,
    });
    const index = this.state.page * this.state.rowsPerPage;
    this.props.clicked(index);
  };

  handleChangeRowsPerPage = (event) => {
    this.setState({ page: 0, rowsPerPage: event.target.value });
  };

  handlechange = (event) => {
    let value = event.target.value;
    let name = event.target.id;
    this.setValue(name, value);
  };

  handleDatesChange = (event) => {
    let value = event.target.value;
    let name = event.target.id;
    // value = value.replace(/[^0-9]/g, "").trim();
    // if (value.length === 8) {
    //   value = value.replace(/^(\d{2})/, "$1/");
    //   value = value.replace(/\/(\d{2})/, "/$1/");
    //   value = value.replace(/(\d)\/(\d{4}).*/, "$1/$2");
    // }
    // this.setValue(name, value);
    this.setState((prevState) => ({
      attestationVO: {
        ...prevState.attestationVO,
        [name]: handleDateChange(value),
      },
      modified: true,
    }));
  };

  handleStartDate = (event) => {
    var self = this;
    const fieldId = "#" + event.target.id;
    DateUtil.getStartDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        self.setValue(e.target.id, e.target.value);
      });
  };

  handleLastDate = (event) => {
    var self = this;
    const fieldId = "#" + event.target.id;
    DateUtil.getLastDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        self.setValue(e.target.id, e.target.value);
      });
  };

  handleDate = (event) => {
    var self = this;
    const fieldId = "#" + event.target.id;
    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        self.setValue(e.target.id, e.target.value);
      });
  };

  setValue = (name, value) => {
    this.setState((prevState) => ({
      attestationVO: {
        ...prevState.attestationVO,
        [name]: value,
      },
    }));
  };
  modalClosed = () => {
    this.setState({ showModal: false });
  };

  render() {
    const { classes, appId, servicesEnabled } = this.props;
    const { rowsPerPage, page, attestationVO } = this.state;
    let { data } = this.props;

    if (data.length < rowsPerPage && data.length >= 1) {
      this.setState({
        rowsPerPage: data.length,
      });
    }
    if (this.state.colToSort) {
      data = orderBy(data, this.state.colToSort, this.state.sortDir);
    }

    return (
      <React.Fragment>
        <Modal
          dialogTitle="LEP"
          message={this.state.message}
          show={this.state.showModal}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <div style={{ width: "100%", textAlign: "center" }}>
          <div className={classes.tableWrapper} style={{ width: "100%" }}>
            <Table className={classes.table}>
              <TableHead className={classes.thead}>
                <TableRow className={classes.headRow}>
                  {header.map((mbrCol, i) => (
                    <TableCell
                      align="center"
                      className={classes.headerCellAttestation}
                      classes={{ root: classes.rootAttestatationCell }}
                      key={i}
                    >
                      <div
                        style={{
                          display: "flex",
                          justifyContent: "center",
                          alignItems: "center",
                        }}
                        //onClick={() => this.handleSort(mbrCol.key)}
                      >
                        {mbrCol.label}
                        {this.state.colToSort === mbrCol.key ? (
                          this.state.sortDir === "asc" ? (
                            <HomeIcon path="M9 6l-4 4h8z" />
                          ) : (
                            <HomeIcon path="M5 8l4 4 4-4z" />
                          )
                        ) : (
                          <HomeIcon
                            className={classes.svgicon}
                            path="M9 6l-4 4h8z"
                          />
                        )}
                      </div>
                    </TableCell>
                  ))}
                  <TableCell
                    align="center"
                    className={classes.headerCellAttestation}
                    classes={{ root: classes.rootAttestatationCell }}
                  >
                    Add/Delete
                  </TableCell>
                </TableRow>
              </TableHead>

              <TableBody className={classes.tbody}>
                <TableRow>
                  <TableCell align="center" className={classes.tableCell}>
                    <div>
                      <input
                        id="comptRespRecDateFrmt"
                        placeholder="MM/DD/YYYY"
                        className="form-field"
                        value={attestationVO.comptRespRecDateFrmt}
                        onChange={this.handleDatesChange}
                        onClick={this.handleDate}
                        maxLength={10}
                        style={{
                          width: "90px",
                          textTransform: "uppercase",
                        }}
                      />

                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "DateOfCoverage",
                          attestationVO.comptRespRecDateFrmt,
                          "required|date_format"
                        )}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell align="center" className={classes.tableCell}>
                    <div style={{ display: "inline-block" }}>
                      <select
                        class="lepSelect"
                        id="brkInCoverage"
                        value={attestationVO.brkInCoverage}
                        onChange={this.handlechange}
                      >
                        <option value=""></option>
                        <option value="Y">Yes</option>
                        <option value="N">No</option>
                      </select>
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "ResponseType",
                          attestationVO.brkInCoverage,
                          "required"
                        )}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell align="center" className={classes.tableCell}>
                    <div>
                      <input
                        id="credRXCoverage"
                        className="form-field"
                        maxLength={25}
                        value={attestationVO.credRXCoverage}
                        onChange={this.handlechange}
                        style={{
                          width: "90px",
                          textTransform: "uppercase",
                        }}
                      />

                      {attestationVO.brkInCoverage === "Y" ? (
                        <div className={classes.validationMessage}>
                          {this.validator.message(
                            "credRxCoverage",
                            attestationVO.credRXCoverage,
                            "required"
                          )}
                        </div>
                      ) : null}
                    </div>
                  </TableCell>
                  <TableCell align="center" className={classes.tableCell}>
                    <div>
                      <input
                        id="fromDateFrmt"
                        placeholder="MM/DD/YYYY"
                        className="form-field"
                        value={attestationVO.fromDateFrmt}
                        onChange={this.handleDatesChange}
                        onClick={this.handleStartDate}
                        maxLength={10}
                        style={{
                          width: "90px",
                          textTransform: "uppercase",
                        }}
                      />

                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "FromDate",
                          attestationVO.fromDateFrmt,
                          [
                            "required",
                            "date_format",
                            "first_day_of_month",
                            {
                              date_before: this.props.reqDtCov,
                              date_conflict: [attestationVO.toDateFrmt, data],
                            },
                          ]
                        )}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell align="center" className={classes.tableCell}>
                    <div>
                      <input
                        id="toDateFrmt"
                        placeholder="MM/DD/YYYY"
                        className="form-field"
                        value={attestationVO.toDateFrmt}
                        onChange={this.handleDatesChange}
                        onClick={this.handleLastDate}
                        maxLength={10}
                        style={{
                          width: "90px",
                          textTransform: "uppercase",
                        }}
                      />

                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "ToDate",
                          attestationVO.toDateFrmt,
                          [
                            "required",
                            "date_format",
                            "last_day_of_month",
                            {
                              date_before: this.props.reqDtCov,
                              after_start_date: attestationVO.fromDateFrmt,
                            },
                          ]
                        )}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell></TableCell>
                  <TableCell>
                    <div>
                      <select
                        class="lepSelect"
                        id="respType"
                        value={attestationVO.respType}
                        onChange={this.handlechange}
                      >
                        <option value="">Select</option>
                        <option value="X">Fax</option>
                        <option value="F">Form</option>
                        <option value="T">Telephonic</option>
                        <option value="O">Onsite</option>
                      </select>

                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "ResponseType",
                          attestationVO.respType,
                          "required"
                        )}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell></TableCell>
                  <TableCell>
                    {!servicesEnabled.includes("EEUP") ? (
                      <Button
                        variant="contained"
                        color="primary"
                        className={classes.button}
                        onClick={this.addRow}
                        disabled={
                          this.props.searchResultsVo.suppLepPlatino === "true"
                        }
                      >
                        Add
                      </Button>
                    ) : null}
                  </TableCell>
                </TableRow>
                {data
                  .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                  .map((genericDetail, j) => (
                    <TableRow className={classes.row} key={j}>
                      {header.map((genericKey, p) => (
                        <TableCell
                          align="center"
                          key={p}
                          className={classes.tableCell}
                        >
                          {genericDetail[genericKey.key]}
                        </TableCell>
                      ))}
                      <TableCell align="center" className={classes.tableCell}>
                        {!servicesEnabled.includes("EEUP") ? (
                          <Button
                            variant="contained"
                            color="primary"
                            className={classes.button}
                            onClick={() => {
                              this.props.deleteAttestationData(data, j, appId);
                            }}
                            disabled={
                              this.props.searchResultsVo.suppLepPlatino ===
                              "true"
                            }
                          >
                            Delete
                          </Button>
                        ) : null}
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
              {data.length > 0 ? (
                <TableFooter className={classes.footer}>
                  <TableRow className={classes.footer}>
                    <TablePagination
                      className={classes.pagination}
                      rowsPerPageOptions={[]}
                      colSpan={header.length + 1}
                      count={data.length}
                      rowsPerPage={rowsPerPage}
                      page={page}
                      SelectProps={{
                        native: true,
                      }}
                      classes={{
                        toolbar: classes.footer,
                      }}
                      onChangePage={this.handleChangePage}
                      onChangeRowsPerPage={this.handleChangeRowsPerPage}
                      ActionsComponent={Pagination}
                    />
                  </TableRow>
                </TableFooter>
              ) : null}
            </Table>
          </div>
        </div>
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    data: state.applSearch.lepData.lepAttestInfoVO.lepAttestList,
    appId: state.applSearch.searchResultsVo.applVO.applId,
    reqDtCov: state.applSearch.searchResultsVo.applPlanVO.reqDtCov,
    lepData: state.applSearch.lepData,
    servicesEnabled: state.loginData.servicesEnabled,
    searchResultsVo: state.applSearch.searchResultsVo,
  };
};

const mapDispatchToProps = {
  addAttestationData,
  deleteAttestationData,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(DataTable));
