import React, { Component } from "react";
import Button from "@material-ui/core/Button";
import Paper from "@material-ui/core/Paper";
import DataTableAttestCall from "../../../components/UI/DataTableAttestCall";
import { connect } from "react-redux";
import { updateAttestationCall } from "../../../redux/actions/ApplActions";
import SimpleReactValidator from "simple-react-validator";
import { customValidations } from "../../../utils/CustomValidations";

const INITIAL_STATE = {
  outBoundInitial: {
    date: "",
    status: "",
    isChange: "N",
  },
  inBoundInitial: {
    date: "",
    status: "",
    isChange: "N",
  },
  outBoundInComplete: {
    date: "",
    status: "",
    isChange: "N",
  },
  inBoundInComplete: {
    date: "",
    status: "",
    isChange: "N",
  },
  inBoundLate: {
    date: "",
    status: "",
    isChange: "N",
  },
};
class AttestationCalls extends Component {
  constructor(props) {
    super(props);
    this.state = {
      vo: {
        ...INITIAL_STATE,
      },
    };
    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
        date_before: customValidations.c_date_before_or_equal,
        not_before_30_days: customValidations.c_after,
      },
    });
  }
  setValue = (id, value, targetVo) => {
    this.setState((prevState) => ({
      vo: {
        ...prevState.vo,
        [targetVo]: {
          ...prevState.vo[targetVo],
          [id]: value,
          isChange: "Y",
        },
      },
    }));
  };

  update = () => {
    const currStatus = this.props.applStatus;
    if (currStatus === "COMPLETED") {
      alert("Application Cannot be UPDATED!! \nCurrent Status is COMPLETED");
      return false;
    }
    if (currStatus === "CANCELED") {
      alert("Application Cannot be UPDATED!! \nCurrent Status is CANCELED");
      return false;
    }
    if (
      currStatus === "DENIEDELG" ||
      currStatus === "DENIEDETYP" ||
      currStatus === "DENIEDOTHR"
    ) {
      alert("Application Cannot be UPDATED!! \nCurrent Status is DENIED");
      return false;
    }
    if (
      this.state.vo.outBoundInitial.isChange === "N" &&
      this.state.vo.inBoundInitial.isChange === "N" &&
      this.state.vo.outBoundInComplete.isChange === "N" &&
      this.state.vo.inBoundInComplete.isChange === "N" &&
      this.state.vo.inBoundLate.isChange === "N"
    ) {
      alert("There is no Record to update");
      return false;
    }
    if (!this.validator.allValid()) {
      this.validator.showMessages();
      this.forceUpdate();
      return;
    }
    if (window.confirm("Are you sure you want to Update")) {
      let vo = this.state.vo;
      this.props.updateAttestationCall(vo, this.props.data);
      this.setState({
        vo: {
          ...INITIAL_STATE,
        },
      });
    }
  };

  render() {
    const { data } = this.props;
    const { vo } = this.state;
    let outBoundInitialNewRow =
      data.obc1TimerCheck === "true" || data.obc2TimerCheck === "true";
    let inBoundInitialNewRow =
      data.obc1TimerCheck !== "false" ||
      (data.obc1TimerCheck === "false" && data.obc2TimerCheck !== "false");
    let outBoundInitialLength = data.outBoundInitial.length;
    let inBoundInitialLength = data.inBoundInitial.length;
    let cmoVo = true;
    let cmiVo = false;
    if (outBoundInitialLength > 0) {
      cmoVo =
        data.outBoundInitial[outBoundInitialLength - 1].status === "INCOMPLETE";
    }
    if (inBoundInitialLength > 0) {
      cmiVo =
        data.inBoundInitial[inBoundInitialLength - 1].status === "INCOMPLETE";
    }

    return (
      <Paper elevation={0}>
        {data ? (
          <React.Fragment>
            <div style={{ width: "100%", textAlign: "right" }}>
              <div style={{ display: "inline-flex" }}>
                <Button
                  variant="contained"
                  color="primary"
                  //className={classes.button}
                  onClick={this.update}
                  disabled={this.props.searchResultsVo.suppLepPlatino === "true"}
                >
                  Update
                </Button>
              </div>
            </div>
            <DataTableAttestCall
              data={data.outBoundInitial}
              tableType="outBoundInitial"
              header="Outbound Initial Attestation"
              setValue={this.setValue}
              validator={this.validator}
              vo={vo.outBoundInitial}
              newRow={
                outBoundInitialNewRow &&
                data.outBoundInitial.length < 3 &&
                cmoVo
              }
            />
            <DataTableAttestCall
              data={inBoundInitialNewRow ? data.inBoundInitial : []}
              tableType="inBoundInitial"
              header="Inbound Initial Attestation"
              setValue={this.setValue}
              validator={this.validator}
              vo={vo.inBoundInitial}
              newRow={
                (inBoundInitialNewRow &&
                  data.inBoundInitial.length < 2 &&
                  cmiVo) ||
                (data.obc1TimerCheck === "true" &&
                  data.inBoundInitial.length === 0)
              }
            />
            {data.le21TimerCheck === "true" ||
            data.le21TimerCheck === "closed" ? (
              <DataTableAttestCall
                data={data.outBoundInComplete}
                tableType="outBoundInComplete"
                header="Outbound Incomplete Attestation"
                setValue={this.setValue}
                validator={this.validator}
                vo={vo.outBoundInComplete}
                newRow={
                  data.le21TimerCheck === "true" &&
                  data.outBoundInComplete.length < 3
                }
              />
            ) : null}
            {data.le21TimerCheck === "true" ||
            data.le21TimerCheck === "closed" ? (
              <DataTableAttestCall
                data={data.inBoundInComplete}
                tableType="inBoundInComplete"
                header="Inbound Incomplete Attestation"
                vo={vo.inBoundInComplete}
                setValue={this.setValue}
                validator={this.validator}
                newRow={
                  data.le21TimerCheck === "true" &&
                  data.inBoundInComplete.length < 2
                }
              />
            ) : null}
            {data.obc3TimerCheck === "true" ||
            data.obc3TimerCheck === "closed" ? (
              <DataTableAttestCall
                data={data.inBoundLate}
                tableType="inBoundLate"
                header="Inbound Late Attestation"
                vo={vo.inBoundLate}
                setValue={this.setValue}
                validator={this.validator}
                newRow={
                  data.obc3TimerCheck === "true" && data.inBoundLate.length < 2
                }
              />
            ) : null}
          </React.Fragment>
        ) : null}
      </Paper>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    data: state.applSearch.lepData.attestCallMasterVO,
    applStatus: state.applSearch.searchResultsVo.applVO.applStatus,
    searchResultsVo: state.applSearch.searchResultsVo,
  };
};
const mapDispatchToProps = {
  updateAttestationCall,
};
export default connect(mapStateToProps, mapDispatchToProps)(AttestationCalls);
