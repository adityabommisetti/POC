import {
  copyAttestationData,
  setAttestationLetterValue,
  showActiveAttestationList,
  showAllAttestationData,
  updateAttestationLetter,
  getLepDetails,
} from "../../../redux/actions/ApplActions";
import AppBar from "@material-ui/core/AppBar";
import {
  LepAttestation,
  ApplAttestationCalls,
  LepSummary,
  ApplUncoveredData,
} from "../ApplTabImport";
import NoSsr from "@material-ui/core/NoSsr";
import PropTypes from "prop-types";
import React from "react";
import Tab from "@material-ui/core/Tab";
import Tabs from "@material-ui/core/Tabs";
import Typography from "@material-ui/core/Typography";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";
import isEmpty from "lodash/isEmpty";
function TabContainer(props) {
  return (
    <Typography component="div" style={{ padding: 8 }}>
      {props.children}
    </Typography>
  );
}

TabContainer.propTypes = {
  children: PropTypes.node.isRequired,
};

function LinkTab(props) {
  return (
    <Tab component="a" onClick={(event) => event.preventDefault()} {...props} />
  );
}

const Styles = (theme) => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
  },
  bigIndicator: {
    height: 2,
    backgroundColor: "white",
  },
});

class LEP extends React.Component {
  state = {
    value: 0,
    id: -1,
  };

  async componentDidMount() {
    if (!this.props.lepData) {
      await this.props.getLepDetails(
        this.props.searchResultsVo,
        this.props.loginData.loginVo.userId
      );
      this.props.setLepCollapse();
    }
  }

  handleChange = (event, value) => {
    this.setState({ value });
  };

  render() {
    const { classes, reqDtCov, appId, lepData } = this.props;
    const { value } = this.state;

    return (
      <NoSsr>
        <div className={classes.root}>
          <AppBar position="static">
            <Tabs
              variant="fullWidth"
              value={value}
              onChange={this.handleChange}
              classes={{ indicator: classes.bigIndicator }}
            >
              <LinkTab label="SUMMARY" href="page1" />
              <LinkTab label="UNCOVERED DATA" href="page2" />
              <LinkTab label="ATTESTATION" href="page3" />
              <LinkTab label="ATTESTATION CALLS" href="page4" />
            </Tabs>
          </AppBar>

          {value === 0 && (
            <TabContainer>
              <LepSummary
                data={!isEmpty(lepData) ? lepData.lepSummaryVO : []}
                nunCMOList={
                  !isEmpty(lepData) ? lepData.lepSummaryVO.nunCMOList : []
                }
                rdsList={!isEmpty(lepData) ? lepData.lepSummaryVO.rdsList : []}
                partDList={
                  !isEmpty(lepData) ? lepData.lepSummaryVO.partDList : []
                }
                showEnrollInfo
              />
            </TabContainer>
          )}
          {value === 1 && (
            <TabContainer>
              <ApplUncoveredData />
            </TabContainer>
          )}
          {value === 2 && (
            <TabContainer>
              <LepAttestation
                showAllAttestationData={this.props.showAllAttestationData}
                showActiveAttestationList={this.props.showActiveAttestationList}
                copyAttestationData={this.props.copyAttestationData}
                data={!isEmpty(lepData) ? lepData.lepAttestInfoVO : []}
                primaryId={appId}
                uncovList={
                  !isEmpty(lepData) ? lepData.potentialUnCovMthsList : []
                }
                lepEffDate={reqDtCov}
                setLepValue={this.props.setAttestationLetterValue}
                updateAttestationLetter={this.props.updateAttestationLetter}
                suppLepPlatinoApp={this.props.searchResultsVo.suppLepPlatino}
              />
            </TabContainer>
          )}
          {value === 3 && (
            <TabContainer>
              <ApplAttestationCalls />
            </TabContainer>
          )}
        </div>
      </NoSsr>
    );
  }
}

LEP.propTypes = {
  classes: PropTypes.object.isRequired,
};

const mapStateToProps = (state) => {
  return {
    lepData: state.applSearch.lepData,
    appId: state.applSearch.searchResultsVo.applVO.applId,
    reqDtCov: state.applSearch.searchResultsVo.applPlanVO.reqDtCov,
    loginData: state.loginData,
    searchResultsVo: state.applSearch.searchResultsVo,
  };
};

const mapDispatchToProps = {
  showAllAttestationData,
  showActiveAttestationList,
  copyAttestationData,
  setAttestationLetterValue,
  updateAttestationLetter,
  getLepDetails,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(LEP));
