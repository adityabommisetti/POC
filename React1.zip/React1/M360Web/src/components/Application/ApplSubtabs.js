import {
  applCancel,
  applUpdate,
  originalApplication,
  setCurrentApplication,
  updateComments,
  validateApplication,
  getLepDetails,
} from "../../redux/actions/ApplActions";
import Button from "@material-ui/core/Button";
import DataTable from "../Home/DataTable";
import ExpansionPanel from "../UI/ExpansionPanel";
import HistoryData from "../UI/MemberHistory";
import InputField from "../UI/InputField";
import Popup from "reactjs-popup";
import scrollTo from "../../utils/ScrollToElement";
import React from "react";
import StatusPopup from "./StatusPopup";
import { Styles } from "../../assets/styles/Theme";
import { connect } from "react-redux";
import { APPLICATION_ERROR_HEADER as errorHeader } from "../../constants/Headers/ApplicationHeaders";
import { withStyles } from "@material-ui/core/styles";
import AutoComplete1 from "../UI/Select";
//import isEmpty from "lodash/isEmpty";
import checkErrorField from "../../utils/CheckErrorField";
import NMA from "./NewApplication/NMA";
import NPD from "./NewApplication/NPD";
import CMA from "./NewApplication/CMA";
import CPD from "./NewApplication/CPD";
import NMAFloatingMenu from "./NewApplication/NMAFloatingMenu";
import NPDFloatingMenu from "./NewApplication/NPDFloatingMenu";
import CMAFloatingMenu from "./NewApplication/CMAFloatingMenu";
import CPDFloatingMenu from "./NewApplication/CPDFloatingMenu";
class ScrollableTabsButtonAuto extends React.Component {
  state = {
    originalApplication: false,
    selectedIndex: 0,
    denialApplStatus: [],
    errorList: [],
    collapse: false,
    applId: "-1",
    lepCollapse: false,
    getLepDetails: "",
    appFields: [],
    enbCMAQues: [],
    enbQues: [],
  };

  static getDerivedStateFromProps(nextProps, prevState) {
    const id = nextProps.searchResultsVo
      ? nextProps.searchResultsVo.applVO.applId.toString()
      : "-1";

    if (
      id !== prevState.applId ||
      (nextProps.lepData === null && id === prevState.applId)
    ) {
      return {
        applId: id,
        lepCollapse: true,
        getLepDetails: true,
      };
    }

    return null;
  }

  originalApplication = async (event) => {
    event.preventDefault();

    if (this.props.searchResultsVo.hasOrigAppl) {
      await this.props.originalApplicationParent(true);
      await this.props.originalApplication(this.props.searchResultsVo);
      scrollTo("overRideDuplicateApplication");
    } else {
      alert("No Original Application record exists!!");
    }
  };

  currentApplication = async (event) => {
    event.preventDefault();
    await this.props.originalApplicationParent(false);
    await this.props.setCurrentApplication(this.props.currApplVo);
    scrollTo("overRideDuplicateApplication");
  };

  handleChange = (event, value) => {
    this.setState({ value, denialFlag: false, cancelFlag: false });
    this.props.collapseSearchResult();
  };

  handleOnBlur = (event, value) => {
    this.setState({ value, denialFlag: false, cancelFlag: false });
    this.props.collapseSearchResult();
  };

  validateAppl = (event) => {
    event.preventDefault();
    this.props.checkValid("Validation");
  };

  updateComments = (event) => {
    if (this.props.newCommentList.length > 0) {
      if(!this.props.newApplIdGen){
        alert("APPLICATION ID IS REQUIRED TO SAVE COMMENT");
      }
      else{
        event.preventDefault();
        this.props.updateComments(this.props.newCommentList);
        alert("Comments Updated Successfully");
      }
    } else {
      alert("NO COMMENTS ELIGIBLE FOR SAVING");
    }
  };

  selectRow = (index) => {
    this.setState(() => ({ selectedIndex: index }));
  };

  componentDidMount() {
    let denialApplStatus = this.props.dropdowns.lstApplStatus.filter(
      (test) =>
        test.label === "DENIEDOTHR" ||
        test.label === "DENIEDETYP" ||
        test.label === "DENIEDELG" ||
        test.label === "Select"
    );

    this.setState({ denialApplStatus });
    const { loginProfile } = this.props;
    const APPFIELDS = loginProfile.filter((data) => data.label === "APPFIELDS");

    const ENBCMAQUES = loginProfile.filter(
      (data) => data.label === "ENBCMAQUES"
    );

    const ENBQUEST = loginProfile.filter((data) => data.label === "ENBQUEST");

    this.setState({
      appFields: APPFIELDS[0],
      enbCMAQues: ENBCMAQUES[0],
      enbQues: ENBQUEST[0],
    });
  }
  scrollToElement = async (event, id) => {
    event.preventDefault();
    const { getLepDetails, lepCollapse } = this.state;
    if (this.props.newApplFlag && id === "lep") {
      alert("No Application Id generated");
      return;
    }
    if (lepCollapse && getLepDetails && id === "lep") {
      await this.props.getLepDetails(
        this.props.searchResultsVo,
        this.props.loginData.loginVo.userId
      );
    }
    scrollTo(id);
    this.setState({
      collapse: false,
      lepCollapse: false,
      getLepDetails: false,
    });
  };
  loadLep = async () => {
    const { getLepDetails } = this.state;
    this.setState({
      lepCollapse: !this.state.lepCollapse,
    });
    if (getLepDetails) {
      await this.props.getLepDetails(
        this.props.searchResultsVo,
        this.props.loginData.loginVo.userId
      );
      this.setState({
        lepCollapse: false,
        getLepDetails: false,
      });
    }
  };
  setLepCollapse = () => {
    this.setState({
      lepCollapse: false,
      getLepDetails: false,
    });
  };
  render() {
    const { classes, searchResultsVo, servicesEnabled } = this.props;
    const {
      collapse,
      lepCollapse,
      appFields,
      enbQues,
      enbCMAQues,
    } = this.state;
    let operationalButtons = this.props.originalApp ? (
      <div class="button-container bottom-button-set1">
        <button class="btn btn-secondary" onClick={this.currentApplication}>
          Current Application
        </button>
      </div>
    ) : (
      <div className={this.props.classes.buttonContainerApplication}>
        {!servicesEnabled.includes("EMDL") ? (
          <Button
            id="denialApplication"
            variant="contained"
            color="primary"
            onClick={this.props.denialApplication}
            className={this.props.classes.button}
            // disabled={this.props.newApplFlag==="NMA"?false:true}
          >
            Denial
          </Button>
        ) : null}
        {servicesEnabled.includes("EMAO") ? (
          <Button
            id="originalApplication"
            variant="contained"
            color="primary"
            onClick={this.originalApplication}
            className={this.props.classes.button}
            // disabled={!searchResultsVo.hasOrigAppl || this.props.newApplFlag==="NMA"?false:true}
          >
            Original Application
          </Button>
        ) : null}

        {servicesEnabled.includes("EMAR") ? (
          <Button
            id="cancelApplication"
            variant="contained"
            color="primary"
            onClick={this.props.cancelApplication}
            className={this.props.classes.button}
            // disabled={this.props.newApplFlag==="NMA"?false:true}
          >
            Cancel Application
          </Button>
        ) : null}

        <Button
          id="updateComments"
          type="submit"
          variant="contained"
          color="primary"
          onClick={this.updateComments}
          className={this.props.classes.button}
        >
          Update Comments
        </Button>

        {servicesEnabled.includes("EMAV") ? (
          <Button
            id="validateAppl"
            variant="contained"
            color="primary"
            onClick={this.validateAppl}
            className={this.props.classes.button}
          >
            Validate Application
          </Button>
        ) : null}

        <Button
          id="cancelAppl"
          variant="contained"
          color="primary"
          onClick={this.props.closeApplication}
          className={this.props.classes.button}
          disabled={!this.props.newApplFlag}
        >
          Close
        </Button>

        {servicesEnabled.includes("EEUA") ? (
          <Button
            id="updateApplication"
            variant="contained"
            color="primary"
            onClick={() => {
              this.props.updateApplication();
            }}
            className={this.props.classes.button}
          >
            Update
          </Button>
        ) : null}
      </div>
    );

    let errorMsg =
      this.props.validateFlag &&
      this.props.validateFlag !== "Validation" &&
      this.props.validateFlag !== "Update" &&
      this.props.validateFlag !== "" ? (
        <div class="alert alert-danger" id="displayMessage">
          <strong>Error: &nbsp;</strong>
          {this.props.validateFlag}
        </div>
      ) : null;

    let successMsg =
      this.props.validateFlag === "Validation" ||
      this.props.validateFlag === "Update" ? (
        <div class="alert alert-success" id="displayMessage">
          <strong>Success: &nbsp;</strong>
          {this.props.validateFlag} Successful
        </div>
      ) : null;
    const applType = searchResultsVo.applVO.applType;
    return (
      <React.Fragment>
        {errorMsg}
        {successMsg}
        {searchResultsVo.applErrList != null &&
        searchResultsVo.applErrList.length > 0 ? (
          <ExpansionPanel summary="Error List" defaultCollapsed={collapse}>
            <DataTable
              data={searchResultsVo.applErrList}
              header={errorHeader}
              rowsPerPage={searchResultsVo.applErrList.length}
              sortable={false}
              index={0}
              errorTable
              notClickable
            />
          </ExpansionPanel>
        ) : null}
        <form autoComplete="off">
          <div class="panel-body">
            <div class="form-panel">
              <div className={classes.container}>
                <div>
                <AutoComplete1 
                     handleChange={this.props.handlechangeAuto}
                    // handleChange={this.props.handlechange("applType", "applVO")}
                     vo='applVO'
                    label ='Application Type'
                    options={this.props.dropdowns.lstApplType}
                    defaultValue={ this.props.dropdowns.lstApplType[0] }
                      value={this.props.dropdowns.lstApplType.filter(data => data.value === applType)[0]}
                    name='applType'
                    disabled ={this.props.originalApp}
                    />
                  <div className={classes.validationMessageSelect} />
                </div>
                <div>
                  <InputField
                    name="applicationId"
                    id="applicationId"
                    label="Application ID"
                    value={searchResultsVo.applVO.applId}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="applDate"
                    id="applDate"
                    label="Application Date"
                    placeholder="MM/DD/YYYY"
                    value={searchResultsVo.applVO.applDate}
                    onClick={this.props.handleDates("#applDate", "applVO")}
                    maxLength={10}
                    disabled={this.props.originalApp}
                    onChange={this.props.handleDateChange("applDate", "applVO")}
                    onBlur={this.props.handleOnBlur}
                    isErrorField={checkErrorField("applDate", searchResultsVo)}
                    required
                  />

                  <div className={classes.validationMessage}>
                    {this.props.statusIncoValidator.message(
                      "applicationDate",
                      searchResultsVo.applVO.applDate,
                      "required|date_format"
                    )}
                    {this.props.validator.message(
                      "applicationDate",
                      searchResultsVo.applVO.applDate,
                      "required|date_format"
                    )}
                  </div>
                </div>
                <div>
                  <InputField
                    name="currStatus"
                    id="currStatus"
                    label="Current Status"
                    value={searchResultsVo.applVO.currStatus}
                    disabled
                  />

                  <div className={classes.validationMessage} />
                </div>

                {!this.props.denialFlag ? (
                  <div>
                    <AutoComplete1 
                     handleChange={this.props.handlechangeAuto}
                    // handleChange={this.props.handlechange("applType", "applVO")}
                     vo='applVO'
                    label ='Application Status'
                    options={this.props.dropdowns.lstApplStatus}
                    defaultValue={ this.props.dropdowns.lstApplStatus[0] }
                      value={this.props.dropdowns.lstApplStatus.filter(data => data.value === searchResultsVo.applVO.applStatus)[0]}
                    name='applStatus'
                    disabled ={this.props.originalApp}
                    />
                    <div className={classes.validationMessageSelect}>
                      {this.props.validator.message(
                        "applicationStatus",
                        searchResultsVo.applVO.applStatus,
                        "required"
                      )}
                    </div>
                  </div>
                ) : (
                  <div>
                    {/* <Select
                      components={components}
                      propertyName={this.state.denialApplStatus.filter(
                        (option) =>
                          option.value === searchResultsVo.applVO.applStatus
                      )}
                      options={this.state.denialApplStatus}
                      label="Choose Application Status ..."
                      textFieldProps={{
                        id: "applStatus",
                        label: "Application Status",

                        InputLabelProps: {
                          className: classes.label,
                          shrink: true,
                        },
                      }}
                      className={classes.textFieldSelect}
                      handleChange={this.props.handlechange(
                        "applStatus",
                        "applVO"
                      )}
                      classes={classes}
                      isDisabled={this.props.originalApp}
                    /> */}
                    <AutoComplete1 
                     handleChange={this.props.handlechangeAuto}
                    // handleChange={this.props.handlechange("applType", "applVO")}
                     vo='applVO'
                    label ='Application Status'
                    options={this.state.denialApplStatus}
                    defaultValue={this.state.denialApplStatus[0] }
                      value={this.state.denialApplStatus.filter(data => data.value === searchResultsVo.applVO.applStatus)[0]}
                    name='applStatus'
                    disabled ={this.props.originalApp}
                    />

                    <div className={classes.validationMessageSelect}>
                      {this.props.validator.message(
                        "applicationStatus",
                        searchResultsVo.applVO.applStatus,
                        "required"
                      )}
                    </div>
                  </div>
                )}

                <div>
                  <InputField
                    name="operatorId"
                    id="operatorId"
                    label="Operator ID"
                    value={this.props.loginData.loginVo.userId}
                    disabled
                  />

                  <div className={classes.validationMessage} />
                </div>
                <React.Fragment>
                  <Popup
                    style={{ height: "65%" }}
                    className={classes.mobileWidth}
                    modal
                    trigger={
                      <span
                        class="button-container-search"
                        style={{
                          marginTop: "20px",
                          marginLeft: "20px",
                          marginBottom: "6px",
                        }}
                      >
                        <button
                          class="btn btn-primary"
                          onClick={(e) => e.preventDefault()}
                        >
                          Status Log
                        </button>
                      </span>
                    }
                    position="right center"
                  >
                    {(close) => (
                      <div>
                        <StatusPopup close={close} />
                      </div>
                    )}
                  </Popup>
                </React.Fragment>
              </div>
            </div>

            <HistoryData
              footer="true"
              createUserId={searchResultsVo.applVO.createUserId}
              createTime={searchResultsVo.applVO.createTime}
              lastUpdtTime={searchResultsVo.applVO.lstUpdtTime}
              lastUpdtUserId={searchResultsVo.applVO.lstUpdtUserId}
            />
          </div>
        </form>

        <div className={classes.rootSubtabs}>
          {applType === "NMA" ? (
            <React.Fragment>
              <NMAFloatingMenu
                appFields={appFields}
                scrollToElement={this.scrollToElement}
                cancel={this.props.cancelFlag}
                denial={this.props.denialFlag}
              />
              <NMA
                cancelFlag={this.props.cancelFlag}
                denialFlag={this.props.denialFlag}
                appFields={appFields}
                collapse={collapse}
                lepCollapse={lepCollapse}
                searchResultsVo={searchResultsVo}
                originalApp={this.props.originalApp}
                newApplFlag={this.props.newApplFlag}
                loadLep={this.loadLep}
                setLepCollapse={this.setLepCollapse}
                handleDates={this.props.handleDates}
                handleDateChange={this.props.handleDateChange}
                handlechange={this.props.handlechange}
                handlechangeAuto={this.props.handlechangeAuto} 
                handleOnBlur={this.props.handleOnBlur}
                validator={this.props.validator}
                handleNumberChange={this.props.handleNumberChange}
                handleAlpha={this.props.handleAlpha}
                statusHoldValidator={this.props.statusHoldValidator}
                handleChangeDropDown={this.props.handleChangeDropDown}
                showEmergencyInfo={this.props.showEmergencyInfo}
                handleNumber={this.props.handleNumber}
                handleCheckbox={this.props.handleCheckbox}
                closePopup={this.props.closePopup}
                originalApplication={this.props.originalApp}
                handleAlphaNumeric={this.props.handleAlphaNumeric}
                handlechangeSearchSelect={this.props.handleChangeSearchSelect}
                disable={this.props.disable}
              />
            </React.Fragment>
          ) : null}
          {applType === "NPD" ? (
            <React.Fragment>
              <NPDFloatingMenu
                appFields={appFields}
                scrollToElement={this.scrollToElement}
                cancel={this.props.cancelFlag}
                denial={this.props.denialFlag}
              />
              <NPD
                cancelFlag={this.props.cancelFlag}
                denialFlag={this.props.denialFlag}
                appFields={appFields}
                collapse={collapse}
                lepCollapse={lepCollapse}
                searchResultsVo={searchResultsVo}
                originalApp={this.props.originalApp}
                newApplFlag={this.props.newApplFlag}
                loadLep={this.loadLep}
                handlechangeAuto={this.props.handlechangeAuto} 
                setLepCollapse={this.setLepCollapse}
                handleDates={this.props.handleDates}
                handleDateChange={this.props.handleDateChange}
                handlechange={this.props.handlechange}
                handleOnBlur={this.props.handleOnBlur}
                validator={this.props.validator}
                handleNumberChange={this.props.handleNumberChange}
                handleAlpha={this.props.handleAlpha}
                statusHoldValidator={this.props.statusHoldValidator}
                handleChangeDropDown={this.props.handleChangeDropDown}
                showEmergencyInfo={this.props.showEmergencyInfo}
                handleNumber={this.props.handleNumber}
                handleCheckbox={this.props.handleCheckbox}
                closePopup={this.props.closePopup}
                originalApplication={this.props.originalApp}
                handleAlphaNumeric={this.props.handleAlphaNumeric}
                handlechangeSearchSelect={this.props.handleChangeSearchSelect}
                disable={this.props.disable}
              />
            </React.Fragment>
          ) : null}
          {applType === "CMA" ? (
            <React.Fragment>
              <CMAFloatingMenu
                enbCMAQues={enbCMAQues}
                enbQues={enbQues}
                appFields={appFields}
                scrollToElement={this.scrollToElement}
                cancel={this.props.cancelFlag}
                denial={this.props.denialFlag}
              />
              <CMA
                cancelFlag={this.props.cancelFlag}
                denialFlag={this.props.denialFlag}
                enbCMAQues={enbCMAQues}
                enbQues={enbQues}
                appFields={appFields}
                collapse={collapse}
                lepCollapse={lepCollapse}
                searchResultsVo={searchResultsVo}
                originalApp={this.props.originalApp}
                newApplFlag={this.props.newApplFlag}
                loadLep={this.loadLep}
                setLepCollapse={this.setLepCollapse}
                handleDates={this.props.handleDates}
                handleDateChange={this.props.handleDateChange}
                handlechange={this.props.handlechange}
                handlechangeAuto={this.props.handlechangeAuto} 
                handleOnBlur={this.props.handleOnBlur}
                validator={this.props.validator}
                handleNumberChange={this.props.handleNumberChange}
                handleAlpha={this.props.handleAlpha}
                statusHoldValidator={this.props.statusHoldValidator}
                handleChangeDropDown={this.props.handleChangeDropDown}
                showEmergencyInfo={this.props.showEmergencyInfo}
                handleNumber={this.props.handleNumber}
                handleCheckbox={this.props.handleCheckbox}
                closePopup={this.props.closePopup}
                originalApplication={this.props.originalApp}
                handleAlphaNumeric={this.props.handleAlphaNumeric}
                handlechangeSearchSelect={this.props.handleChangeSearchSelect}
                disable={this.props.disable}
              />
            </React.Fragment>
          ) : null}
          {applType === "CPD" ? (
            <React.Fragment>
              <CPDFloatingMenu
                appFields={appFields}
                scrollToElement={this.scrollToElement}
                cancel={this.props.cancelFlag}
                denial={this.props.denialFlag}
              />
              <CPD
                cancelFlag={this.props.cancelFlag}
                denialFlag={this.props.denialFlag}
                appFields={appFields}
                collapse={collapse}
                lepCollapse={lepCollapse}
                searchResultsVo={searchResultsVo}
                originalApp={this.props.originalApp}
                newApplFlag={this.props.newApplFlag}
                loadLep={this.loadLep}
                setLepCollapse={this.setLepCollapse}
                handleDates={this.props.handleDates}
                handleDateChange={this.props.handleDateChange}
                handlechange={this.props.handlechange}
                handlechangeAuto={this.props.handlechangeAuto} 
                handleOnBlur={this.props.handleOnBlur}
                validator={this.props.validator}
                handleNumberChange={this.props.handleNumberChange}
                handleAlpha={this.props.handleAlpha}
                statusHoldValidator={this.props.statusHoldValidator}
                handleChangeDropDown={this.props.handleChangeDropDown}
                showEmergencyInfo={this.props.showEmergencyInfo}
                handleNumber={this.props.handleNumber}
                handleCheckbox={this.props.handleCheckbox}
                closePopup={this.props.closePopup}
                originalApplication={this.props.originalApp}
                handleAlphaNumeric={this.props.handleAlphaNumeric}
                handlechangeSearchSelect={this.props.handleChangeSearchSelect}
                disable={this.props.disable}
              />
            </React.Fragment>
          ) : null}

          {operationalButtons}
        </div>
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    lepData: state.applSearch.lepData,
    dropdowns: state.dropdowns,
    currApplVo: state.currApplVo,
    newCommentList: state.applSearch.newCommentList,
    loginData: state.loginData,
    searchResultsVo: state.applSearch.searchResultsVo,
    validateFlag: state.applSearch.searchResultsVo.validateFlag,
    servicesEnabled: state.loginData.servicesEnabled,
    loginProfile: state.loginData.profiles,
  };
};
const mapDispatchToProps = {
  originalApplication,
  setCurrentApplication,
  validateApplication,
  applCancel,
  applUpdate,
  updateComments,
  getLepDetails,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(ScrollableTabsButtonAuto));
