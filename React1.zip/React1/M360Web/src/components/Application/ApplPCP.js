import React, { Component } from "react";
import Modal from "../UI/Modal/Modal";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import Checkbox from "@material-ui/core/Checkbox";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import InputField from "../UI/InputField";
import PCPSearchPopup from "./ApplPCPSeacrchPopup";
import Paper from "@material-ui/core/Paper";
import Popup from "reactjs-popup";
import { Styles } from "../../assets/styles/Theme";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";
import { messages } from "../../constants/Messages";
import checkErrorField from "../../utils/CheckErrorField";

class ApplicationPCP extends Component {
  constructor(props) {
    super(props);
    this.state = {
      closePopup: false,
    };
  }
  closePopup = () => {
    window.scroll(0, 200);
    this.setState({ closePopup: true, message: messages.REQ_DATE_COVERAGE });
  };
  modalClosed = () => {
    this.setState({ closePopup: false });
  };
  render() {
    const { classes, searchResultsVo, originalApplication } = this.props;
    const applOtherPlanVO = searchResultsVo.applOtherPlanVO;

    return (
      <React.Fragment>
        <Modal
          dialogTitle="Personal info"
          message={this.state.message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Paper elevation={0} className={classes.card}>
          <div className={classes.container}>
            <span class="label-container">
              <label for="chosen_pcp_clinic_or_health_center" className={classes.Input1}>
                Chosen PCP, Clinic or health center
              </label>
              <br />
              <input
                maxLength={50}
                type="text"
                name="pcpName"
                class="form-field input-popup"
                value={applOtherPlanVO.pcpName ? applOtherPlanVO.pcpName : ""}
                onChange={this.props.handlechange("pcpName", "applOtherPlanVO")}
                onBlur={this.props.handleOnBlur("applOtherPlanVO")}
                style={{
                  width: "353px",
                  backgroundColor: checkErrorField("pcpName", searchResultsVo)
                    ? "yellow"
                    : null,
                }}
                disabled={originalApplication}
              />
              {!originalApplication ? (
                <Popup
                  className={classes.mobileWidth}
                  modal
                  trigger={<span class="more-info" id="pcp_popup" />}
                  position="right center"
                  repositionOnResize={true}
                  contentStyle={{ width: "57% !important" }}
                >
                  {(close) => (
                    <div>
                      <PCPSearchPopup
                        closePopup={this.closePopup}
                        data={searchResultsVo}
                        close={close}
                      />
                    </div>
                  )}
                </Popup>
              ) : null}
            </span>

            <div className={classes.textField}>
              <FormControlLabel
                control={
                  <Checkbox
                    style={{ width: 36, height: 36 }}
                    color="primary"
                    id="currentPatientInd"
                    icon={
                      <CheckBoxOutlineBlankIcon
                        className={classes.checkBoxStyle}
                      />
                    }
                    checkedIcon={
                      <CheckBoxIcon className={classes.checkBoxStyle} />
                    }
                    checked={
                      applOtherPlanVO.currentPatientInd === "Y" ? true : false
                    }
                    disabled={originalApplication}
                    onChange={this.props.handleCheckbox(
                      "currentPatientInd",
                      "applOtherPlanVO"
                    )}
                  />
                }
                label="Current Patient"
                classes={{ label: classes.formLabel }}
              />
            </div>
            <div>
              <InputField
                name="officeCode"
                label="Office Code"
                id="officeCd"
                value={applOtherPlanVO.officeCd ? applOtherPlanVO.officeCd : ""}
                disabled
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <InputField
                name="locationId"
                label="Location ID"
                id="locationId"
                disabled
                value={
                  applOtherPlanVO.locationId ? applOtherPlanVO.locationId : ""
                }
              />
              <div className={classes.validationMessage} />
            </div>
            {this.props.searchResultsVo.npiInd === "Y" ? (
              <div>
                <InputField
                  name="alternateOfficeCd"
                  label="NPI ID"
                  id="alternateOfficeCd"
                  disabled
                  value={
                    applOtherPlanVO.alternateOfficeCd
                      ? applOtherPlanVO.alternateOfficeCd
                      : ""
                  }
                />
                <div className={classes.validationMessage} />
              </div>
            ) : null}
          </div>
        </Paper>
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    dropdowns: state.dropdowns,
    searchResultsVo: state.applSearch.searchResultsVo,
  };
};
export default connect(mapStateToProps)(withStyles(Styles)(ApplicationPCP));
