import React, { Component } from "react";
import AutoComplete1 from "../UI/Select";

import InputField from "../UI/InputField";
import Paper from "@material-ui/core/Paper";
import { Styles } from "../../assets/styles/Theme";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";

class DenialInfo extends Component {
  render() {
    const { classes, searchResultsVo, dropdowns } = this.props;
    const applVO = searchResultsVo.applVO;

    return (
      <Paper elevation={0} className={classes.card}>
        <div className={classes.containerDenial}>
          <div style={{ marginRight: "55px" }}>
            <InputField
              id="denialRcvDt"
              name="denialRcvDt"
              placeholder="MM/DD/YYYY"
              label="Denial received Date"
              value={applVO.denialRcvDt}
              onClick={this.props.handleDates("#denialRcvDt", "applVO")}
              onChange={this.props.handleDateChange("denialRcvDt", "applVO")}
              maxLength={10}
            />
            <div className={classes.validationMessageSelect}>
              {this.props.validator.message(
                "denialDate",
                applVO.denialRcvDt,
                "required"
              )}
            </div>
          </div>

          <div>
            <AutoComplete1
              handleChange={this.props.handlechangeAuto}
              width={"575px"}
              vo='applVO'
              margin='0px'
              label='Denial Reason'
              options={dropdowns.applDenialReasons}
              defaultValue={dropdowns.applDenialReasons[0]}
              value={dropdowns.applDenialReasons.filter(data => data.value === applVO.denialReasonCd)[0]}
              name='denialReasonCd'
            />

            <div className={classes.validationMessageSelect}>
              {this.props.validator.message(
                "denialreason",
                applVO.denialReasonCd,
                "required"
              )}
            </div>
          </div>
        </div>
      </Paper>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    dropdowns: state.dropdowns,
    searchResultsVo: state.applSearch.searchResultsVo,
  };
};
export default connect(mapStateToProps)(withStyles(Styles)(DenialInfo));
