import React, { Component } from "react";
import {
  fetchCityCounty,
  resetZipTable,
  searchCityZip,
  resetCityZip,
} from "../../redux/actions/ApplActions";

import Button from "@material-ui/core/Button";
import DataTable from "../Home/DataTable";
import InputField from "../UI/InputField";
import Paper from "@material-ui/core/Paper";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../assets/styles/PopupTheme";
import classNames from "classnames";
import { connect } from "react-redux";
import { CITY_ZIP_HEADER as header } from "../../constants/Headers/ApplicationHeaders";
import { withStyles } from "@material-ui/core/styles";

class CityZipsearch extends Component {
  constructor(props) {
    super(props);
    this.state = {
      searchVo: {
        zip5: this.props.zip5,
        zip4: this.props.zip4,
      },
      selectedIndex: 0,
    };
    this.validator = new SimpleReactValidator();
  }

  componentDidMount() {
    this.props.resetZipTable();

    this.forceUpdate();
    if (this.validator.allValid()) {
      this.props.searchCityZip(this.state.searchVo);
      this.validator.showMessages();
    } else {
      this.props.resetCityZip();
      this.validator.hideMessages();
    }
  }

  onRowSelect = (index, page) => {
    this.setState({
      selectedIndex: index,
      page: page,
    });
  };

  onSubmit = async () => {
    const tableData = [...this.props.data];
    const selectedVo = tableData[this.state.selectedIndex];
    if (this.props.primaryAddress) {
      await this.props.fetchCityCounty(
        this.state.searchVo.zip5,
        this.state.searchVo.zip4
      );
    }
    this.props.setData(selectedVo);
    this.props.close();
  };

  reset = () => {
    this.setState({
      searchVo: {
        zip5: "",
        zip4: "",
      },
    });
  };

  search = (event) => {
    event.preventDefault();
    this.validator.showMessages();
    this.forceUpdate();
    if (this.validator.allValid()) {
      this.props.searchCityZip(this.state.searchVo);
    }
  };

  handleChange = (e) => {
    let value = e.target.value.replace(/[^0-9]/g, "");
    let name = e.target.name;

    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value,
      },
    }));
  };

  handleOnBlur = (e) => {
    let value = e.target.value.replace(/[^0-9]/g, "").trim();
    let name = e.target.name;

    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value,
      },
    }));
  };

  render() {
    const { classes, data } = this.props;
    return (
      <React.Fragment>
        <Paper
          className={classes.root}
          elevation={0}
          style={{ padding: "15px" }}
        >
          <fieldset className={classes.fieldset}>
            <form>
              <legend className={classes.legend}>City ZIP Search</legend>
              <div className={classes.container} style={{ margin: "0px auto" }}>
                <div>
                  <InputField
                    required
                    name="zip5"
                    label="Zip 5"
                    id="zip5"
                    maxLength={5}
                    className={classes.textField}
                    margin="normal"
                    InputLabelProps={{ className: classes.label }}
                    value={this.state.searchVo.zip5}
                    onChange={this.handleChange}
                    onBlur={this.handleOnBlur}
                  />
                  <div className={classes.validationMessage}>
                    {this.validator.message(
                      "zip5",
                      this.state.searchVo.zip5,
                      "size:5|required"
                    )}
                  </div>
                </div>
                <div>
                  <InputField
                    name="zip4"
                    label="Zip 4"
                    id="zip4"
                    maxLength={4}
                    className={classes.textField}
                    margin="normal"
                    InputLabelProps={{ className: classes.label }}
                    value={this.state.searchVo.zip4}
                    onChange={this.handleChange}
                    onBlur={this.handleOnBlur}
                  />
                  <div className={classes.validationMessage}>
                    {this.validator.message(
                      "zip4",
                      this.state.searchVo.zip4,
                      "size:4"
                    )}
                  </div>
                </div>
              </div>

              <div className={classes.div1}>
                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={this.search}
                >
                  <i className="material-icons">search</i>
                </Button>

                <Button
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={this.props.close}
                >
                  <i className="material-icons">cancel</i>
                </Button>
                <Button
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={this.reset}
                >
                  <i class="material-icons">refresh</i>
                </Button>
              </div>
            </form>
          </fieldset>
        </Paper>

        <div className={classes.table}>
          <DataTable
            data={data}
            header={header}
            rowsPerPage={5}
            sortable={false}
            clicked={this.onRowSelect}
            index={this.state.selectedIndex}
            pageNo={this.state.page}
          />
          {data.length > 0 ? (
            <div className={classes.div1}>
              <Button
                variant="contained"
                color="primary"
                id="zipSubmit"
                className={classNames(classes.button, classes.submit)}
                onClick={this.onSubmit}
              >
                Submit
              </Button>
            </div>
          ) : null}
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  data: state.applPopupVO.cityZipSearchData,
  searchResultsVo: state.applSearch.searchResultsVo,
});

const mapDispatchToProps = {
  searchCityZip,
  resetZipTable,
  fetchCityCounty,
  resetCityZip,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(CityZipsearch));
