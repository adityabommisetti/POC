import Loadable from 'react-loadable-visibility/react-loadable';
import React from "react";

export const ApplAttestationCalls = Loadable({
	loader: () => import('./LEP/ApplAttestationCalls'),
	loading() {
		return <div></div>
	}
})
export const LepAttestation = Loadable({
	loader: () => import('../UI/LepAttestation'),
	loading() {
		return <div></div>
	}
});
export const LepSummary = Loadable({
	loader: () => import('../UI/LepSummary'),
	loading() {
		return <div></div>
	}
});
export const ApplUncoveredData = Loadable({
	loader: () => import('./LEP/ApplUncoveredData'),
	loading() {
		return <div></div>
	}
})

export const Address = Loadable({
	loader: () => import('./ApplAddress'),
	loading() {
		return <div></div>
	}
})

export const Attestation = Loadable({
	loader: () => import('./ApplAttestation'),
	loading() {
		return <div></div>
	}
})

export const BankingInfo = Loadable({
	loader: () => import('./ApplBankingInfo'),
	loading() {
		return <div></div> 
	}
})
export const BrokeAgentData = Loadable({
	loader: () => import('./ApplBrokerAgent'),
	loading() {
		return <div></div>
	}
})

export const CancellationInfo = Loadable({
	loader: () => import('./ApplCancellationInfo'),
	loading() {
		return <div></div>
	}
})
export const CommentsSignature = Loadable({
	loader: () => import('./ApplCommentsSignature'),
	loading() {
		return <div></div>
	}
})
export const DenialInfo = Loadable({
	loader: () => import('./ApplDenialInformation'),
	loading() {
		return <div></div>
	}
})
export const EnrollmentInfo = Loadable({
	loader: () => import('./ApplEnrollment'),
	loading() {
		return <div></div>
	}
})
export const LEP = Loadable({
	loader: () => import('./LEP/ApplLEP'),
	loading() {
		return <div></div>
	}
})
export const PCP = Loadable({
	loader: () => import('./ApplPCP'),
	loading() {
		return <div></div>
	}
})
export const PersonalInfo = Loadable({
	loader: () => import('./ApplPersonalInfo'),
	loading() {
		return <div></div>
	}
})
export const Questions = Loadable({
	loader: () => import('./ApplQuestions'),
	loading() {
		return <div>Loading...</div>
	}
})
