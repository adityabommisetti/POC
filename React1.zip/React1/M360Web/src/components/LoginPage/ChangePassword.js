import {
  HINT1_LIST,
  HINT2_LIST,
  HINT3_LIST
} from "./../../constants/SelectStaticData";
import { NavLink, Redirect } from "react-router-dom";
import React, { Component } from "react";
import { Select, components } from "../UI/Select";

import Button from "@material-ui/core/Button";
import { CUSTOMER_LOGO } from "../../constants/Logos";
import InputField from "../UI/InputField";
import Paper from "@material-ui/core/Paper";
import { Styles } from "../../assets/styles/Theme";
import { connect } from "react-redux";
import wiproLogo from "../../assets/images/wipro-logo.png";
import { withStyles } from "@material-ui/core/styles";

class ChangePassword extends Component {
  state = {
    ChangePasswordVo: {
      newpass: "",
      retypepass: "",
      phone: "",
      email: "",
      hint1: "",
      hint2: "",
      hint3: "",
      answer1: "",
      answer2: "",
      answer3: "",
      cancelflag: "false"
    }
  };

  handlechange = name => event => {
    let value = event.target.value;

    this.setState(prevState => ({
      ChangePasswordVo: {
        ...prevState.ChangePasswordVo,
        [name]: value
      },

      modified: true
    }));
  };

  handleChangeSearchSelect = name => event => {
    let value = event.value;
    this.setState(prevState => ({
      ChangePasswordVo: {
        ...prevState.ChangePasswordVo,
        [name]: value
      },
      modified: true
    }));
  };
  cancel = () => {
    this.setState({ cancelflag: true });
  };

  handleNumberChange = name => event => {
    let value = event.target.value.replace(/[^0-9]/g, "").trim();
    if (name === "phone") {
      value = value.replace(/(\d{3})/, "$1-");
      value = value.replace(/(\d{3})(\d{1})/, "$1-$2");
    }
    this.setState(prevState => ({
      ChangePasswordVo: {
        ...prevState.ChangePasswordVo,
        [name]: value
      },
      modified: true
    }));
  };

  render() {
    let loginGroupName = this.props.loginData.loginVo.customerId;
    let style;
    if (loginGroupName === "HCF0232") {
      style = {
        width: "140px"
      };
    } else if (loginGroupName === "HCF0281") {
      style = {
        width: "165px"
      };
    } else if (loginGroupName === "HCF0331") {
      style = {
        width: "95px"
      };
    }
    if (this.state.cancelflag) {
      return <Redirect to="/landingpage" />;
    }

    const { classes } = this.props;

    let ButtonPanel = (
      <div className={classes.passwordbuttonContainer}>
        <Button
          variant="contained"
          color="primary"
          onClick={this.submit}
          className={classes.button}
        >
          Submit
        </Button>

        <Button
          type="submit"
          variant="contained"
          color="primary"
          onClick={this.cancel}
          className={classes.button}
        >
          Cancel
        </Button>
      </div>
    );

    return (
      <div class="wrapper">
        <nav id="sidebar">
          <div class="sidebar-header">
            <span class="wlogo">
              <img src={wiproLogo} alt="Wipro logo" />
            </span>
            <span class="clogo">
              <img
                style={style}
                src={CUSTOMER_LOGO[loginGroupName]}
                alt={this.props.loginData.loginVo.customerName}
              />
            </span>
          </div>

          <ul class="list-unstyled components">
            <li>
              <a
                href="#m360submenu"
                data-toggle="collapse"
                aria-expanded="false"
                class="dropdown-toggle"
              >
                <i class="icon-users"></i> <span>M360</span>
              </a>
              <ul class="collapse list-unstyled" id="m360submenu">
                <li>
                  <NavLink to="/dashboard">EEM</NavLink>
                </li>
                <li>
                  <a href="/#">Eligibility</a>
                </li>
                <li>
                  <a href="/#">Billing</a>
                </li>
                <li>
                  <a href="/#">Dashboard</a>
                </li>
              </ul>
            </li>
            <li>
              <a href="/#">
                <i class="icon-money"></i> <span>R360</span>
              </a>
            </li>
            <li>
              <a href="/#">
                <i class="icon-doc-text"></i> <span>REPORTING</span>
              </a>
            </li>
            <li>
              <a href="/#">
                <i class="icon-desktop"></i> <span>ONLINE PROCESING</span>
              </a>
            </li>
            <li>
              <a href="/#">
                <i class="icon-user-md"></i> <span>IL MEDICAID RECON</span>
              </a>
            </li>
            <li>
              <a
                href="#risksubmenu"
                data-toggle="collapse"
                aria-expanded="false"
                class="dropdown-toggle"
              >
                <i class="icon-th-list"></i> <span>RISK MANAGEMENT</span>
              </a>
              <ul class="collapse list-unstyled" id="risksubmenu">
                <li>
                  <a href="/#">RAPS-Expert</a>
                </li>
                <li>
                  <a href="/#">Encounters</a>
                </li>
              </ul>
            </li>
          </ul>
        </nav>

        <div id="content" style={{ marginTop: "-24px" }}>
          <div class="topnav">
            <nav class="navbar navbar-default">
              <div class="container-fluid">
                <div class="navbar-header">
                  <button
                    type="button"
                    id="sidebarCollapse"
                    class="btn btn-info"
                  >
                    <i></i>
                    <i></i>
                    <i></i>
                  </button>
                </div>

                <div class="navbar-collapse" id="navbar-top-right">
                  <ul class="nav navbar-nav navbar-right">
                    <li>
                      <a href="/#">
                        <i class="icon-user-1"></i> Welcome Wipro Internal
                        Customer -- <span>{this.props.userId}</span>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </nav>
          </div>
          <div class="content-container">
            <Paper>
              <form autoComplete="off">
                <div className="panel-body">
                  <div className={classes.containerStyle}>
                    <div>
                      <InputField
                        name="userid"
                        label="User ID"
                        value={this.props.userId}
                        disabled={!this.state.editable}
                      />
                    </div>
                    <div className={classes.containersubstyle}>
                      <InputField
                        name="newpass"
                        label="New Password"
                        value={this.state.ChangePasswordVo.newpass}
                        onChange={this.handlechange("newpass")}
                        disabled={this.state.editable}
                        maxLength={50}
                      />
                    </div>
                  </div>

                  <div className={classes.containerStyle}>
                    <div>
                      <InputField
                        id="standard-error"
                        required
                        name="oldpassword"
                        label="Old Password"
                        value={this.state.ChangePasswordVo.oldpass}
                        onChange={this.handlechange("oldpass")}
                        disabled={this.state.editable}
                        maxLength={50}
                      />
                    </div>
                    <div className={classes.containersubstyle}>
                      <InputField
                        name="retypepass"
                        label="Retype Password:"
                        value={this.state.ChangePasswordVo.retypepass}
                        onChange={this.handlechange("retypepass")}
                        disabled={this.state.editable}
                      />
                    </div>
                  </div>

                  <div className={classes.passwordrules}>
                    <p component="legend" className={classes.legend}>
                      Passwords must be 8-28 characters. Contain at least 1
                      upper case, 1 lower case, 1 numeric and 1 special
                      characters.
                    </p>
                  </div>

                  <div className={classes.containerStyle}>
                    <div>
                      <Select
                        components={components}
                        propertyName={HINT1_LIST.filter(
                          option =>
                            option.value === this.state.ChangePasswordVo.hint1
                        )}
                        options={HINT1_LIST}
                        optionLabel="Praven"
                        label=" Forgot Password Hint 1:"
                        textFieldProps={{
                          label: "Forgot Password Hint 1:",

                          InputLabelProps: {
                            className: classes.label,
                            shrink: true
                          }
                        }}
                        className={classes.textFieldSelect}
                        style={{ marginTop: "-12px" }}
                        handleChange={this.handleChangeSearchSelect("hint1")}
                        isDisabled={this.state.editable}
                        classes={classes}
                        width="250px"
                      />
                    </div>
                    <div className={classes.containersubstyle1}>
                      <InputField
                        name="answer1"
                        label="Forgot Password Answer 1:"
                        value={this.state.ChangePasswordVo.answer1}
                        onChange={this.handlechange("answer1")}
                        disabled={this.state.editable}
                      />
                    </div>
                  </div>

                  <div className={classes.containerStyle}>
                    <div>
                      <Select
                        components={components}
                        propertyName={HINT2_LIST.filter(
                          option =>
                            option.value === this.state.ChangePasswordVo.hint1
                        )}
                        options={HINT2_LIST}
                        optionLabel="Praven"
                        label=" Forgot Password Hint 2:"
                        textFieldProps={{
                          label: "Forgot Password Hint 2:",

                          InputLabelProps: {
                            className: classes.label,
                            shrink: true
                          }
                        }}
                        className={classes.textFieldSelect}
                        handleChange={this.handleChangeSearchSelect("hint1")}
                        isDisabled={this.state.editable}
                        classes={classes}
                        width="250px"
                      />
                    </div>
                    <div className={classes.containersubstyle1}>
                      <InputField
                        name="answer2"
                        label="Forgot Password Answer 2:"
                        value={this.state.ChangePasswordVo.answer2}
                        onChange={this.handlechange("answer2")}
                        disabled={this.state.editable}
                      />
                    </div>
                  </div>

                  <div className={classes.containerStyle}>
                    <div>
                      <Select
                        components={components}
                        propertyName={HINT3_LIST.filter(
                          option =>
                            option.value === this.state.ChangePasswordVo.hint3
                        )}
                        options={HINT3_LIST}
                        optionLabel="Praven"
                        label=" Forgot Password Hint 3:"
                        textFieldProps={{
                          label: "Forgot Password Hint 3:",

                          InputLabelProps: {
                            className: classes.label,
                            shrink: true
                          }
                        }}
                        className={classes.textFieldSelect}
                        style={{ marginTop: "-12px" }}
                        handleChange={this.handleChangeSearchSelect("hint3")}
                        isDisabled={this.state.editable}
                        classes={classes}
                        width="250px"
                      />
                    </div>
                    <div className={classes.containersubstyle1}>
                      <InputField
                        name="answer3"
                        label="Forgot Password Answer 3:"
                        value={this.state.ChangePasswordVo.answer3}
                        onChange={this.handlechange("answer3")}
                        disabled={this.state.editable}
                      />
                    </div>
                  </div>

                  <div className={classes.containerStyle}>
                    <div>
                      <InputField
                        name="phone"
                        label="Phone"
                        value={this.state.ChangePasswordVo.phone}
                        disabled={this.state.editable}
                        onChange={this.handleNumberChange("phone")}
                      />
                    </div>

                    <div className={classes.containersubstyle}>
                      <InputField
                        name="email"
                        label="Email"
                        value={this.state.ChangePasswordVo.email}
                        disabled={this.state.editable}
                        onChange={this.handlechange("email")}
                      />
                    </div>
                  </div>

                  {ButtonPanel}
                </div>
              </form>
            </Paper>
          </div>

          <footer class="footer margin-top1">
            <div class="small container">
              <div class="row">
                <div class="col-md-5">
                  <p>&copy; 2019 Wipro Technologies. All rights reserved. </p>
                </div>
              </div>
            </div>
          </footer>
        </div>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    loginData: state.loginData
  };
};
export default connect(mapStateToProps)(withStyles(Styles)(ChangePassword));
