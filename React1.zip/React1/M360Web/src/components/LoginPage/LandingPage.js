import { Link, NavLink, Redirect } from "react-router-dom";
import React, { Component } from "react";

import { CUSTOMER_LOGO } from "../../constants/Logos";
import Footer from "../UI/Login/Footer";
import carouse1 from "../../assets/images/carousel-content-1new.png";
import carouse2 from "../../assets/images/carousel-content-2new.png";
import carouse3 from "../../assets/images/carousel-content-3new.png";
import { connect } from "react-redux";

class LandingPage extends Component {
  state = {
    redirect: false
  };
  setRedirect = () => {
    this.setState({
      redirect: true
    });
  };

  render() {
    const servicesEnabled = this.props.loginData.servicesEnabled;
    let rapsMenuCnt = 0;
    if (servicesEnabled.includes("RaExpert")) {
      rapsMenuCnt++;
    }
    if (servicesEnabled.includes("RCC")) {
      rapsMenuCnt++;
    }
    if (servicesEnabled.includes("HPE")) {
      rapsMenuCnt++;
    }
    if (servicesEnabled.includes("Enctr")) {
      rapsMenuCnt++;
    }
    if (this.state.redirect) {
      return <Redirect to="/changepassword" />;
    }

    let loginGroupName = this.props.loginData.loginVo.customerId;

    return (
      <div class="landing-page-bg">
        <div class="wrapper">
          <nav id="sidebar">
            <div class="sidebar-header">
              <span class="wlogo">
                <img src="/images/wipro-logo.png" alt="Wipro logo" />
              </span>
              <span class="clogo">
                <img
                  style={{ width: "140px" }}
                  src={CUSTOMER_LOGO[loginGroupName]}
                  alt={this.props.loginData.loginVo.customerName}
                />
              </span>
            </div>

            <ul class="list-unstyled components">
              <li>
                <a
                  href="#m360submenu"
                  data-toggle="collapse"
                  aria-expanded="false"
                  class="dropdown-toggle"
                  id="M360page"
                >
                  <i class="icon-users" /> <span>M360</span>
                </a>
                <ul class="collapse list-unstyled" id="m360submenu">
                  {servicesEnabled.includes("EEM") ? (
                    <li>
                      <a href="/mss/dashboard" id="EEMpage">
                        EEM
                      </a>
                    </li>
                  ) : null}
                  {servicesEnabled.includes("HII") ? (
                    <li>
                      <a href="#">Eligibility</a>
                    </li>
                  ) : null}
                  {servicesEnabled.includes("MBI XREF") ? (
                    <li>
                      <a href="#">MBI XREF</a>
                    </li>
                  ) : null}
                  <li>
                    <a href="/mss/billing">Billing</a>
                  </li>
                  <li>
                    <a href="/mss/dashboard">Dashboard</a>
                  </li>
                </ul>
              </li>
              <li>
                <a
                  href="#r360submenu"
                  data-toggle="collapse"
                  aria-expanded="false"
                  class="dropdown-toggle"
                  id="R360page"
                >
                  <i class="icon-users" /> <span>R360</span>
                </a>
                <ul class="collapse list-unstyled" id="r360submenu">
                  {servicesEnabled.includes("RXR") ||
                    servicesEnabled.includes("RP") ? (
                      <li>
                        <a href="#">Recon/RxRecon</a>
                      </li>
                    ) : null}
                  {servicesEnabled.includes("ILMR") ? (
                    <li>
                      <a href="#">IL Medicaid Recon</a>
                    </li>
                  ) : null}
                  {servicesEnabled.includes("NMMR") ? (
                    <li>
                      <a href="#">NM Medicaid Recon</a>
                    </li>
                  ) : null}
                  {servicesEnabled.includes("TXMR") ? (
                    <li>
                      <a href="#">TX Medicaid Recon</a>
                    </li>
                  ) : null}
                  {servicesEnabled.includes("MNMR") ? (
                    <li>
                      <a href="#">MN Medicaid Recon</a>
                    </li>
                  ) : null}
                </ul>
              </li>
              {servicesEnabled.includes("FTS") &&
                servicesEnabled.includes("FTEmail") ? (
                  <li>
                    <a
                      href="#m360submenu"
                      data-toggle="collapse"
                      aria-expanded="false"
                      class="dropdown-toggle"
                      id="M360page"
                    >
                      <i class="icon-users" /> <span>Reporting</span>
                    </a>
                    <ul class="collapse list-unstyled" id="m360submenu">
                      <li>
                        <a href="#">Reporting Menu</a>
                      </li>
                      <li>
                        <a href="#">Email Admin</a>
                      </li>
                    </ul>
                  </li>
                ) : (
                  <React.Fragment>
                    {servicesEnabled.includes("FTS") ? (
                      <li>
                        <a href="#">
                          <i class="icon-doc-text" /> <span>REPORTING</span>
                        </a>
                      </li>
                    ) : null}
                    {servicesEnabled.includes("FTEmail") ? (
                      <li>
                        <a href="#">
                          <i class="icon-doc-text" /> <span>Email Admin</span>
                        </a>
                      </li>
                    ) : null}
                  </React.Fragment>
                )}
              {servicesEnabled.includes("JAS") ? (
                <li>
                  <a href="#">
                    <i class="icon-desktop" /> <span>ANALYTICS</span>
                  </a>
                </li>
              ) : null}
              {servicesEnabled.includes("RESQ") ? (
                <li>
                  <a href="#">
                    <i class="icon-desktop" /> <span>E&E360</span>
                  </a>
                </li>
              ) : null}
              {rapsMenuCnt > 1 ? (
                <li>
                  <a
                    href="#risksubmenu"
                    data-toggle="collapse"
                    aria-expanded="false"
                    class="dropdown-toggle"
                  >
                    <i class="icon-th-list" /> <span>Risk Management</span>
                  </a>
                  <ul class="collapse list-unstyled" id="risksubmenu">
                    {servicesEnabled.includes("RaExpert") ? (
                      <li>
                        <a href="#">RA-Expert</a>
                      </li>
                    ) : null}
                    {servicesEnabled.includes("RCC") ? (
                      <li>
                        <a href="#">RAPS-Expert</a>
                      </li>
                    ) : null}
                    {servicesEnabled.includes("Enctr") ? (
                      <li>
                        <a href="#">Encounter Data</a>
                      </li>
                    ) : null}
                    {servicesEnabled.includes("HPE") ? (
                      <li>
                        <a href="#">Encounters</a>
                      </li>
                    ) : null}
                  </ul>
                </li>
              ) : rapsMenuCnt > 0 ? (
                <li>
                  {servicesEnabled.includes("RaExpert") ? (
                    <a href="#">
                      <i class="icon-desktop" /> <span>RA-Expert</span>
                    </a>
                  ) : null}
                  {servicesEnabled.includes("RCC") ? (
                    <a href="#">
                      <i class="icon-desktop" /> <span>RAPS-Expert</span>
                    </a>
                  ) : null}
                  {servicesEnabled.includes("Enctr") ? (
                    <a href="#">
                      <i class="icon-desktop" /> <span>Encounter Data</span>
                    </a>
                  ) : null}
                  {servicesEnabled.includes("HPE") ? (
                    <a href="#">
                      <i class="icon-desktop" /> <span>Encounters</span>
                    </a>
                  ) : null}
                </li>
              ) : null}
              {servicesEnabled.includes("RetroAdj") ? (
                <li>
                  <a href="#">
                    <i class="icon-desktop" /> <span>Retro Adjustment</span>
                  </a>
                </li>
              ) : null}
              {servicesEnabled.includes("ERS") ? (
                <li>
                  <a href="#">
                    <i class="icon-desktop" /> <span>Enroll Recon</span>
                  </a>
                </li>
              ) : null}
              {servicesEnabled.includes("BOR") ? (
                <li>
                  <a href="#">
                    <i class="icon-desktop" /> <span>Reporting</span>
                  </a>
                </li>
              ) : null}
              {servicesEnabled.includes("ELID") ? (
                <li>
                  <a href="#">
                    <i class="icon-desktop" /> <span>ELIGIBILITY IND</span>
                  </a>
                </li>
              ) : null}
            </ul>
          </nav>

          <div id="content">
            <div class="topnav topnav-margin">
              <nav class="navbar navbar-default">
                <div class="container-fluid">
                  <div class="navbar-header">
                    <button
                      type="button"
                      id="sidebarCollapse"
                      class="btn btn-info"
                    >
                      <i />
                      <i />
                      <i />
                    </button>
                  </div>

                  <div class="navbar-collapse" id="navbar-top-right">
                    <ul class="nav navbar-nav navbar-right">
                      <li>
                        <a href="#">
                          <i class="icon-user-1" /> Welcome{" "}
                          {this.props.loginData.loginVo.customerName}-
                          {this.props.loginData.loginVo.userId}
                        </a>
                      </li>

                      <li>
                        <a href="">
                          <i
                            class="icon-lock-open-3"
                            onClick={this.setRedirect}
                          />
                          <Link to="/changepassword">Change password</Link>
                        </a>
                      </li>
                      <li>
                        <a href="#" onClick={this.props.logout}>
                          <i class="icon-logout-2" /> Logout
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </nav>
            </div>
            <div class="content-container">
              <div class="container container-fixed">
                <div class="row">
                  <div class="col-md-12 mb-4">
                    <div
                      id="carouselExampleIndicators"
                      class="carousel slide"
                      data-ride="carousel"
                    >
                      <ol class="carousel-indicators">
                        <li
                          data-target="#carouselExampleIndicators"
                          data-slide-to="0"
                          class="active"
                        />
                        <li
                          data-target="#carouselExampleIndicators"
                          data-slide-to="1"
                        />
                        <li
                          data-target="#carouselExampleIndicators"
                          data-slide-to="2"
                        />
                      </ol>
                      <div class="carousel-inner">
                        <div class="carousel-item active">
                          <img src={carouse1} alt="" />
                          <div class="carousel-caption">
                            <h3>
                              4000 plus healthcare associates across the globe.
                            </h3>
                          </div>
                        </div>
                        <div class="carousel-item">
                          <img src={carouse2} alt="" />
                          <div class="carousel-caption">
                            <h3>
                              Health settle more than $15 billion claims
                              annually.
                            </h3>
                          </div>
                        </div>
                        <div class="carousel-item">
                          <img src={carouse3} alt="" />
                          <div class="carousel-caption">
                            <h3>99.75% Paperless claim submission.</h3>
                          </div>
                        </div>
                      </div>
                      <a
                        class="carousel-control-prev"
                        href="#carouselExampleIndicators"
                        role="button"
                        data-slide="prev"
                      >
                        {" "}
                        <span
                          class="carousel-control-prev-icon"
                          aria-hidden="true"
                        />
                        <span class="sr-only">Previous</span>
                      </a>
                      <a
                        class="carousel-control-next"
                        href="#carouselExampleIndicators"
                        role="button"
                        data-slide="next"
                      >
                        {" "}
                        <span
                          class="carousel-control-next-icon"
                          aria-hidden="true"
                        />
                        <span class="sr-only">Next</span>
                      </a>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12 mb-4">
                    <div class="box-item1">
                      <h3>Annoucements</h3>
                      <hr />
                      <div class="content-box">
                        <p>
                          Lorem ipsum dolor sit amet, consectetur adipiscing
                          elit, sed do eiusmod tempor incididunt ut labore et
                          dolore magna aliqua. Quis ipsum suspendisse ultrices
                          gravida. Risus commodo viverra maecenas accumsan lacus
                          vel facilisis.{" "}
                        </p>

                        <p>
                          Lorem ipsum dolor sit amet, consectetur adipiscing
                          elit, sed do eiusmod tempor incididunt ut labore et
                          dolore magna aliqua. Quis ipsum suspendisse ultrices
                          gravida. Risus commodo viverra maecenas accumsan lacus
                          vel facilisis.{" "}
                        </p>

                        <p>
                          Lorem ipsum dolor sit amet, consectetur adipiscing
                          elit, sed do eiusmod tempor incididunt ut labore et
                          dolore magna aliqua. Quis ipsum suspendisse ultrices
                          gravida. Risus commodo viverra maecenas accumsan lacus
                          vel facilisis.{" "}
                        </p>

                        <p>
                          Lorem ipsum dolor sit amet, consectetur adipiscing
                          elit, sed do eiusmod tempor incididunt ut labore et
                          dolore magna aliqua. Quis ipsum suspendisse ultrices
                          gravida. Risus commodo viverra maecenas accumsan lacus
                          vel facilisis.{" "}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <div class="container-fluid panel-social-contact">
                      <div class="row panel-social-contact-row">
                        <div class="col-md-2">
                          <div class="logo-container">
                            <img src='/images/wipro-logo.png' alt="" />
                          </div>
                        </div>
                        <div class="col-md-7">
                          <p>
                            Wipro is a proven provider of IT services focused on
                            managing mission-critical IT systems for a variety
                            of enterprise customers across all industry
                            segments. With investment in people, process and
                            technology, Wipro is a pioneer in global data and
                            infrastructure management.
                          </p>
                        </div>
                        <div class="col-md-3">
                          <ul class="social">
                            <li>
                              <a
                                href="https://plus.google.com/+wipro/posts"
                                target="blank"
                              >
                                <i class="icon-google" />
                              </a>
                            </li>
                            <li>
                              <a
                                href="https://www.facebook.com/WiproTechnologies"
                                target="blank"
                              >
                                <i class="icon-facebook-squared" />
                              </a>
                            </li>
                            <li>
                              <a
                                href="https://www.youtube.com/user/Wiprovideos"
                                target="blank"
                              >
                                <i class="icon-youtube-2" />
                              </a>
                            </li>
                            <li>
                              <a
                                href="https://www.linkedin.com/company/wipro"
                                target="blank"
                              >
                                <i class="icon-linkedin-rect-1" />
                              </a>
                            </li>
                            <li>
                              <a
                                href="https://twitter.com/wipro"
                                target="blank"
                              >
                                <i class="icon-twitter-1" />
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <Footer />
          </div>
        </div>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    loginData: state.loginData
  };
};
export default connect(mapStateToProps)(LandingPage);
