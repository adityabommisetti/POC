import "../../../src/assets/js/lightslider";

import React, { Component } from "react";

import $ from "jquery";
import Carousel from "../UI/Login/Carousel";
import Contact from "../UI/Login/Contact";
import Footer from "../UI/Login/Footer";
import Information from "../UI/Login/Information";
import LoginForm from "../UI/Login/LoginForm";
import Navbar from "../UI/Login/Navbar";

class SignIn extends Component {
  componentDidMount() {
    $("#carousel-gallery").lightSlider({
      gallery: true,
      item: 1,
      thumbItem: 4,
      slideMargin: 0,
      speed: 500,
      auto: true,
      loop: true,
      galleryMargin: 20,
      thumbMargin: 20,
      controls: true,
      onSliderLoad: function() {
        $("#carousel-gallery").removeClass("cS-hidden");
      }
    });
  }

  render() {
    return (
      <React.Fragment>
        <Navbar />

        <main role="main" className="login-body">
          <LoginForm
            id="login"
            loginHandler={this.props.loginHandler}
            userName={this.props.userName}
            pass={this.props.pass}
            handleChange={this.props.handleChange}
          	onBlur={this.props.handleOnBlurFieldChange}
            errorMsg={this.props.errorMsg}
          />
          <Carousel />
          <Contact />
          <Information />
        </main>
        <Footer />
      </React.Fragment>
    );
  }
}

export default SignIn;
