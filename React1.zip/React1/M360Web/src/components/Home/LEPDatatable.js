import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import orderBy from 'lodash/orderBy';
import TablePagination from '@material-ui/core/TablePagination';
import TableFooter from '@material-ui/core/TableFooter';
import SvgIcon from '@material-ui/core/SvgIcon';
import FormControl from '@material-ui/core/FormControl';
import InputAdornment from '@material-ui/core/InputAdornment';
import Input from '@material-ui/core/Input';
import { CSVLink } from "react-csv";
import classNames from 'classnames';
import ExportExcel from '../../utils/ExportExcelComponent'
import { styles } from '../../assets/styles/DataTableStyle_lep';
import Pagination from '../UI/Pagination';
import MenuItem from '@material-ui/core/MenuItem';
import Menu from '@material-ui/core/Menu';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';


function HomeIcon(props) {
  return (
    <SvgIcon {...props}>
      <path d={props.path} />
    </SvgIcon>
  );
}

const invertDirection = {
  asc: "desc",
  desc: "asc"
}

class DataTable extends Component {

  constructor(props) {
    super(props);
    this.state = {
      selectedRow: 0,
      search: '',
      colToSort: '',
      sortDir: 'desc',
      page: 0,
      rowsPerPage: this.props.rowsPerPage,
      anchorEl: null,
      exportData : '',
      mobileMoreAnchorEl: null,
      radio:'current'

    };
  }



  generate = (data, header) => {
    var jsPDF = require('jspdf');
    require('jspdf-autotable');
    var doc = new jsPDF();
    doc.autoTable(header, data);
    doc.save("Dashboard.pdf");
  }


  exportDataFunc = (data, all) =>{
   const exportdata =  this.props.data.slice();
   const searchdata =  data.slice();

    if(all){
      this.setState({ 
        exportData : exportdata,
        radio :  'all'
      })
    }else{
      if(data.length <= this.state.rowsPerPage) {
        this.setState({ 
          exportData : searchdata,
          radio :  'current'
        })
      }
     else {
      this.setState({ 
        exportData : searchdata.slice(this.state.page*this.state.rowsPerPage, this.state.page*this.state.rowsPerPage+this.state.rowsPerPage),
        radio :  'current'
      })
    }
   
    }

  }

  handleSort = (colName) => {
    this.setState(prevState => ({
      colToSort: colName,
      sortDir: this.state.colToSort === colName ? invertDirection[this.state.sortDir] : "asc"

    }))
  }


 
  
  rowSelect = (rowIndex) => {
    
      this.setState({
        selectedRow: rowIndex
      });
      this.props.clicked(rowIndex);
    
    
  }

  handleChangePage = (page) => {
    this.setState({ page });
  };

  handleChangeRowsPerPage = event => {
    this.setState({ page: 0, rowsPerPage: event.target.value });
  };
  
  handleMobileMenuOpen = event => {
    this.setState({ mobileMoreAnchorEl: event.currentTarget });
  };
  handleMobileMenuClose = () => {
    this.setState({ mobileMoreAnchorEl: null });
  };
  handleMenuClose = () => {
    this.setState({ anchorEl: null });
    this.handleMobileMenuClose();
  };

  render() {
    const {  mobileMoreAnchorEl } = this.state;
    const { classes,  searchable, sortable, exportAsExcel ,clickable, removePagination} = this.props;
    const { rowsPerPage, page, exportData } = this.state;
    const isMobileMenuOpen = Boolean(mobileMoreAnchorEl);
    let data = this.props.data;
    const header = this.props.header;
    const search = this.state.search.toLowerCase()
    let msg = "NO DATA FOUND";
    
    if(this.props.msgChange) {
         msg = this.props.msgChange
    }
    if (data.length < rowsPerPage && data.length >= 1) {
      this.setState({
        rowsPerPage: data.length
      })
    }
    if (this.state.colToSort) {
      data = orderBy(data, this.state.colToSort, this.state.sortDir)
    }
    if (this.state.search) {
      data = data.filter(row => {
        return row.agreementId.toLowerCase().includes(search)
          || row.hicNbr.toLowerCase().includes(search)
          || row.memeberId.toLowerCase().includes(search)
          || row.agreementNbr.toLowerCase().includes(search)
          || row.groupId.toLowerCase().includes(search)
          || row.applicationId.toLowerCase().includes(search)

      })
    }
    return (
      <div >
      <div className={classes.exportDisplay}>
      {(exportAsExcel && data.length > 0) ? (<i onClick={(e) => {this.exportDataFunc(data, false); this.handleMobileMenuOpen(e); }} className={classNames("fas fa-file-export", classes.exportIcon)} />) :
       exportAsExcel ? (<i className={classNames("fas fa-file-export", classes.exportIcon)} />) : null}
   

     <Menu 
      classes={{
        paper: classes.placing, 
      }}
        anchorEl={mobileMoreAnchorEl}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        open={isMobileMenuOpen}
        onClose={this.handleMenuClose}
      >
        <MenuItem>
        <RadioGroup 
        row 
        value={this.state.radio}
        >
            <FormControlLabel value="current" control={<Radio /> } label="Current" onClick= {() => this.exportDataFunc(data, false)}/>
            <FormControlLabel value="all" control={<Radio />} label="All" onClick= {() => this.exportDataFunc(data, true)}/>
          </RadioGroup>
       </MenuItem>
       <MenuItem className={classes.export}>
       <ExportExcel fileName='employee' dataSet={this.state.exportData} colName={header} classes={classes} /> 
       <CSVLink data={exportData} headers={header} separator={";"} filename={"my-file.csv"}>
          <i className={classNames("fas fa-file-csv", classes.csvIcon)} ></i>
        </CSVLink> 
      
          <i className={classNames("fa fa-file-pdf-o", classes.pdfIcon)} aria-hidden="true" onClick={() => this.generate(exportData, header)}></i>
        
       </MenuItem>
      </Menu> 
      </div>
      <div className={classes.tableWrapper}>
        {searchable ?
       
          <FormControl className={classes.floatRight}>

            <Input
              id="input-with-icon-adornment"
              value={this.state.search} placeholder="Search..."
              className={classes.search}
              onChange={e => this.setState({ 
                search: e.target.value
              
              })}
              startAdornment={
                <InputAdornment position="start">
                  <i className="material-icons">
                    search
                  </i>
                </InputAdornment>
              }
            />
          </FormControl>
          : null
        }
        </div>
        <div className={classes.tableWrapper}>

          <Table className={removePagination ? classes.tableModified : classes.table}>
            <TableHead className={classes.thead}>
              <TableRow className={classes.headRow}>
                {
                  header.map((mbrCol, i) => (
                    <TableCell align='center' className={classes.headerCell} key={i}>

                      {!sortable ? mbrCol.label : (<div
                        style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}
                        onClick={() => this.handleSort(mbrCol.key)}>
                        {mbrCol.label}
                        {this.state.colToSort === mbrCol.key ? (
                          this.state.sortDir === 'asc' ? <HomeIcon path="M9 6l-4 4h8z" /> : <HomeIcon path="M5 8l4 4 4-4z" />
                        ) : <HomeIcon className={classes.svgicon} path="M9 6l-4 4h8z" />}
                      </div>)}
                    </TableCell>
                  ))}
              </TableRow>
            </TableHead>

            <TableBody className={classes.tbody}>
              {data.length < 1 && (<TableRow className={classes.row}>
                <TableCell align='center' colSpan={7} className={classes.tableCell}> {msg} </TableCell>
              </TableRow>)}
              {
               //  data.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map(
                data.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((genericDetail, j) => (
                  <TableRow 
                  className={this.state.selectedRow === j && (!this.props.notClickable)? classes.selectedrow : classes.row}  
                  key={j} 
                  
                  onClick={this.props.notClickable?()=>{}:() => this.rowSelect(j)}>
                  {header.map((genericKey, p) => (
                    <TableCell align="center"
                     key={p} 
                     style={this.props.errorTable?{color:'red'}:null}
                    className={classes.tableCell}>{genericDetail[genericKey.key]}</TableCell>))}
                  </TableRow>))}


            </TableBody>
            {!removePagination ? 
            <TableFooter className={classes.footer}>
              <TableRow className={classes.footer}>
              {data.length > 0 ? <TablePagination className={classes.pagination}
                  rowsPerPageOptions={[]}
                  colSpan={header.length}
                  count={data.length}
                  rowsPerPage={rowsPerPage}
                  page={page}
                  SelectProps={{
                    native: true,
                  }}
                  classes={{
                    toolbar: classes.footer
                  }}
                  onChangePage={this.handleChangePage}
                  onChangeRowsPerPage={this.handleChangeRowsPerPage}
                  ActionsComponent={Pagination}
                /> : null }
              </TableRow>
            </TableFooter> : null }
          </Table>
         

        </div>
      </div>

    );
  }
}

export default withStyles(styles)(DataTable);