import Checkbox from "@material-ui/core/Checkbox";
import { withStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import React, { Component } from "react";
import { styles } from "../../assets/styles/DataTableStyle";
import { handleDateChange } from "../../utils/DateFormatter";
import InputField from "../UI/InputField";
import * as DateUtil from "../../utils/DatePicker";
import { connect } from "react-redux";

class BillingDataTable extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedRow: 0,
      search: "",
      colToSort: "",
      sortDir: "desc",
      page: 0,
      anchorEl: null,
      exportData: "",
      mobileMoreAnchorEl: null,
      radio: "current",
      index: 0,
      flag: this.props.flag,
      mbrSearch: false,
      sortClick: false,
      selectedPage: 0,
      addpaymentVo: [],
      mbridLit: [],
      payObj: {
        del: "",
        memberId: "",
        checkDate: "",
        checknbr: "",
        paymentAmt: "",
      },
    };
  }

  componentDidMount() {
    const { loginProfile } = this.props;
    const MBRIDLIT = loginProfile.filter((data) => data.label === "MBRIDLIT");
    this.setState({
      mbridLit: MBRIDLIT[0],
    });
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props.flag === true) {
      this.setState({
        page: 0,
        selectedRow: 0,
        index: 0,
        selectedPage: 0,
      });
    } else {
      const pageNo = Math.floor(nextProps.index / this.state.rowsPerPage);
      const selectedRow = nextProps.index % this.state.rowsPerPage;
      this.setState({
        page: pageNo,
        selectedRow: selectedRow,
        rowsPerPage: this.props.rowsPerPage,
      });
    }
  }

  // rowSelect = async (rowIndex, data) => {
  //     // const { page, rowsPerPage } = this.state;
  //     const { page } = this.state;
  //     const selectedIndex = rowIndex;

  //     await this.props.click(selectedIndex, data);

  //     await this.setState({
  //          sortClick: false,
  //         selectedPage: page
  //     });
  // };
  handleCheckBox = (j) => (event) => {
    event.preventDefault();
    let val = event.target.value;
    this.props.handleCheckBox(j, val);
  };
  handleChangePage = (page) => {
    this.setState({
      page,
    });
    if (!this.props.flag) {
      this.setState({
        mbrSearch: true,
      });
    }
  };
  handlechange = (name, index) => async (event) => {
    let value = event.target.value;
    if (event.target.name === "memberId") {
      value = event.target.value.toUpperCase();
    }
    if (event.target.name === "del") {
      value = event.target.value === "Y" ? "N" : "Y";
    }

    this.props.setdataVal(name, value, this.state.payObj, index);
  };
  handleChangeRowsPerPage = (event) => {
    this.setState({ page: 0, rowsPerPage: event.target.value });
  };

  handleMobileMenuOpen = (event) => {
    this.setState({ mobileMoreAnchorEl: event.currentTarget });
  };
  handleMobileMenuClose = () => {
    this.setState({ mobileMoreAnchorEl: null });
  };
  handleMenuClose = () => {
    this.setState({ anchorEl: null });
    this.handleMobileMenuClose();
  };
  serachHandle = (event) => {
    return this.setState({
      search: event.target.value,
    });
  };
  handleDates = (name, index) => (event) => {
    var self = this;
    let fieldId = "#" + event.target.id;
    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        self.setDate(e.target.name, e.target.value, index);
      });
  };

  setDate = (name, value, index) => {
    this.props.setdataVal("checkDate", value, this.state.payObj, index);
  };

  handleDate = (name, index) => (event) => {
    let value = event.target.value;
    value = handleDateChange(value);
    this.props.setdataVal(name, value, this.state.payObj, index);
  };

  render() {
    // const { mobileMoreAnchorEl } = this.state;

    const {
      classes,
      removePagination,
      selectedRow,

    } = this.props;

    let data = this.props.data;

    const header = this.props.header.filter((value) => this.state.mbridLit.value === "TSA" ? value.label !== "M360 ID" : value.label !== "Wipro ID")
    const Member = this.state.mbridLit.value === "TSA" ? "Wipro id" : "M360 id"
    return (
      <div style={{ width: "100%" }}>
        <div
          className={classes.tableWrapper}
          style={{ width: this.props.width ? this.props.width : "100%" }}
        >
          <Table
            className={removePagination ? classes.tableModified : classes.table}
            id="maintable"
          >
            <TableHead className={classes.thead}>
              <TableRow className={classes.headRow}>
                {header.map((mbrCol, i) => (
                  <TableCell
                    align="left"
                    className={classes.headerCell}
                    key={i}
                  >
                    {mbrCol.label}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>

            {this.props.data ? (
              <TableBody className={classes.tbody}>
                {data.map((genericDetail, j) => (
                  <TableRow
                    className={
                      selectedRow
                        ? classes.row
                        : this.state.selectedRow === j &&
                          !this.props.notClickable
                          ? classes.selectedrow
                          : classes.row
                    }
                    key={j}
                  // onClick={
                  //     this.props.notClickable
                  //         ? () => { }
                  //         : () => this.rowSelect(j)
                  // }
                  >
                    {/* <TableRow className={classes.row} key={j}> */}

                    <TableCell
                      style={this.props.errorTable ? { color: "red" } : null}
                      // align="center"
                      className={classes.tableCell}
                    >
                      <div>
                        {" "}
                        <Checkbox
                          name="del"
                          id={"del" + j}
                          value={this.props.data[j].del === "Y" ? "Y" : "N"}
                          color="primary"
                          checked={
                            this.props.data[j].del === "Y" ? true : false
                          }
                          classes={{
                            root: this.props.classes.checkboxControl,
                          }}
                          onClick={this.handlechange("del", j)}
                        />
                      </div>
                    </TableCell>
                    <TableCell
                      style={this.props.errorTable ? { color: "red" } : null}
                      // align="center"
                      className={classes.tableCell}
                    >
                      <div>
                        <InputField
                          name="memberId"
                          id={"memberId" + j}
                          className={this.props.classes.textField}
                          value={this.props.data[j].memberId}
                          maxLength={15}
                          onChange={this.handlechange("memberId", j)}
                        />{" "}
                        {this.props.data[j].del === "Y" ? (
                          <div className={this.props.validationMessage} />
                        ) : (
                            <div className={this.props.validationMessage}>
                              {this.props.validator.message(
                                Member,
                                this.props.data[j].memberId,
                                "required"
                              )}
                            </div>
                          )}
                      </div>
                    </TableCell>

                    <TableCell
                      // align="center"
                      className={classes.tableCell}
                    >
                      <div>
                        <InputField
                          name="checkDate"
                          id={"checkDate" + j}
                          maxLength={10}
                          placeholder="MM/DD/YYYY"
                          required={this.state.editable}
                          onClick={this.handleDates("checkDate", j)}
                          onChange={this.handleDate("checkDate", j)}
                          value={this.props.data[j].checkDate}
                        />
                        {this.props.data[j].del === "Y" ? (
                          <div className={this.props.validationMessage} />
                        ) : (
                            <div className={this.props.validationMessage}>
                              {this.props.validator.message(
                                "Check Date",
                                [0, this.props.data[j].checkDate],
                                "required"
                              )}
                              {this.props.validator.message(
                                "Check Date",
                                this.props.data[j].checkDate,
                                "date_format"
                              )}
                            </div>
                          )}
                      </div>
                    </TableCell>

                    <TableCell
                      // align="center"
                      className={classes.tableCell}
                    >
                      <div>
                        <InputField
                          name="checkNbr"
                          id={"checkNbr" + j}
                          className={this.props.classes.textField}
                          value={this.props.data[j].checkNbr}
                          maxLength={12}
                          onChange={this.handlechange("checkNbr", j)}
                        />
                        {this.props.data[j].del === "Y" ? (
                          <div className={this.props.validationMessage} />
                        ) : (
                            <div className={this.props.validationMessage}>
                              {this.props.validator.message(
                                "Check Nbr",
                                this.props.data[j].checkNbr,
                                "required"
                              )}
                            </div>
                          )}
                      </div>
                    </TableCell>

                    <TableCell
                      // align="center"
                      className={classes.tableCell}
                    >
                      <div>
                        <InputField
                          name="paymentAmt"
                          id={"paymentAmt" + j}
                          className={this.props.classes.textField}
                          value={this.props.data[j].paymentAmt}
                          maxLength={14}
                          onChange={this.handlechange("paymentAmt", j)}
                        />
                        {this.props.data[j].del === "Y" ? (
                          <div className={this.props.validationMessage} />
                        ) : (
                            <div className={this.props.validationMessage}>
                              {this.props.validator.message(
                                "Payment Amt",
                                this.props.data[j].paymentAmt,
                                "required|amountValidator"
                              )}
                            </div>
                          )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            ) : null}
          </Table>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    loginProfile: state.loginData.profiles
  };
};

export default connect(
  mapStateToProps
)(withStyles(styles)(BillingDataTable));
