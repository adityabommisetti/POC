import React from "react";
import { withStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import Typography from "@material-ui/core/Typography";
import Badge from "@material-ui/core/Badge";
import classNames from "classnames";

const styles = theme => ({
  root: {
    ...theme.mixins.gutters(),
    paddingTop: theme.spacing.unit * 2,
    paddingBottom: theme.spacing.unit * 2,
    display: "flex",
    width: "155px",
    padding: 0,
    marginLeft: "15px",
    boxShadow: "2px 2px 2px rgba(0,0,0,0.15)",
    transition: "box-shadow 0.3s ease-in-out",
    cursor: "pointer",
    "&:hover": {
      boxShadow: "0 5px 15px rgba(0,0,0,0.3)"
    }
  },
  icons: {
    width: "40px",
    height: "40px",
    padding: "10px"
  },

  logo: {
    width: "40px",
    height: "40px",
    transform: "translateX(-28px)",
    color: "white",
    borderRadius: "5px"
  },

  bottomright: {
    position: "absolute",
    bottom: "8px",
    right: "16px",
    fontSize: "18px"
  },

  badge: {
    //fontSize:'35px',
    backgroundColor: "none !important"
  },

  details: {
    //color:'white',
    fontWeight: "500",
    marginLeft: "-16px"
    //paddingLeft: "10px"
  },

  success: {
    background: "#5ec362"
  },
  info: {
    background: "#4fc3f7"
  },

  danger: {
    background: "#ef5350 "
  },
  alert: {
    background: "#ff5722"
  }
});

function PaperSheet(props) {
  const { classes } = props;
  return (
    <Paper
      className={classNames(classes.root)}
      elevation={1}
      style={{ padding: "15px" }}
    >
      <div
        className={classNames(classes.logo, {
          [classes.success]: props.iconBackground === "S",
          [classes.danger]: props.iconBackground === "D",
          [classes.info]: props.iconBackground === "I",
          [classes.alert]: props.iconBackground === "A"
        })}
      >
        <span style={{ width: "99%" }}>
          <i className={classNames(props.icon, classes.icons)}></i>
        </span>
      </div>

      <Typography component="p" className={classes.details}>
        {props.title} &nbsp; &nbsp; &nbsp;
        <Badge badgeContent={props.count}></Badge>
      </Typography>
    </Paper>
  );
}

export default withStyles(styles)(PaperSheet);
