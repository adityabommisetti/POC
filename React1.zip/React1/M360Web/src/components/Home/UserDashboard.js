import React from 'react';
import PaperSheet from './PaperSheet';
import Grid from '@material-ui/core/Grid';
import { withStyles } from '@material-ui/core/styles';


const styles = theme => ({
    root: {
      flexGrow: 1,
      marginTop:'15px',
      borderWidth:'5px solid gray',
      
    },
    paper: {
        display:'flex',
        marginTop:'100px',
      },
  });
  
function UserDashboard(props){
        const { classes } = props;
        return(
            <Grid container className={classes.root} spacing={12}>
            <Grid item xs={12}>
              <Grid container  justify="center" spacing={Number(16)}>
                
                  <Grid  item className="Dashboard_iconPCPAssigned">
                    <PaperSheet  icon='fa fa-user-md'  iconBackground="S" count="10" className={classes.paper} title ={'PCP Assigned'}/>
                  </Grid>
                <Grid item className="Dashboard_iconErroredApplication">
                  <PaperSheet icon='fas fa-exclamation-triangle' iconBackground="D"   count="12" className={classes.paper} title ={'Errored Application'}/>
                </Grid>

                <Grid item className="Dashboard_iconEnrollmentProcessed">
                  <PaperSheet icon='fas fa-user-plus' iconBackground="S"   count="32" className={classes.paper} title ={'Enrollment Processed'}/>
                </Grid>
                
                <Grid item className="Dashboard_iconTRRPending">
                  <PaperSheet  icon='fas fa-exchange-alt'  iconBackground="I"   count="15" className={classes.paper} title ={'TRR Pending'}/>
                </Grid>
                <Grid item className="Dashboard_iconLettersApproved">
                  <PaperSheet   icon='fa fa-envelope'  iconBackground="A"   count="15" className={classes.paper} title ={'Letters Approved'}/>
                </Grid>
              </Grid>
            </Grid>
           
          </Grid>
        );
    
}

export default withStyles(styles)(UserDashboard);