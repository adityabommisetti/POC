import React, { Component } from "react";
import { ERROR_FIELD_MAPPINGS } from "../../constants/ErrorFileds";
import Pagination from "../UI/Pagination";
import PrintSearchExpot from "./PrintSearchExport";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableFooter from "@material-ui/core/TableFooter";
import TableHead from "@material-ui/core/TableHead";
//import TablePagination from "@material-ui/core/TablePagination";
import { TablePagination } from "@material-ui/core";
import TableRow from "@material-ui/core/TableRow";
import formatTimeStamp, { formatFullTimeStamp } from "../../utils/Utils";
import orderBy from "lodash/orderBy";
import { connect } from "react-redux";
import { styles } from "../../assets/styles/DataTableStyle";
import { withStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import Tooltip from "@material-ui/core/Tooltip";
import classNames from "classnames";
const invertDirection = {
  asc: "desc",
  desc: "asc",
};
const Tooltip1 = withStyles((theme) => ({
  tooltip: {
    backgroundColor: theme.palette.common.white,
    color: 'rgba(0, 0, 0, 0.87)',
    boxShadow: theme.shadows[1],
    fontSize: 11,
    padding: 2,   
    marginTop: "0px",
    float: "left",
    //maxWidth:1800
    // display:"flex"
  },
}))(Tooltip);
class DataTable extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedRow: 0,
      search: "",
      colToSort: "",
      sortDir: "desc",
      page: 0,
      rowsPerPage: this.props.rowsPerPage,
      anchorEl: null,
      exportData: "",
      mobileMoreAnchorEl: null,
      radio: "current",
      index: 0,
      flag: this.props.flag,
      mbrSearch: false,
      sortClick: false,
      selectedPage: 0,
      data: this.props.data,
      resetFlag: this.props.resetFlag,
      mbridLit: [],
    };
  }

  componentDidMount() {
    const { loginProfile } = this.props;
    const MBRIDLIT = loginProfile.filter((data) => data.label === "MBRIDLIT");
   
    const pageNo = Math.floor(this.props.index / this.props.rowsPerPage);
   
      const selectedRow =this.props.index % this.props.rowsPerPage;
       this.setState({
        page: pageNo,
        selectedRow: selectedRow,
        rowsPerPage: parseInt(this.props.rowsPerPage),
        selectedPage: pageNo,
        data:this.props.data,
        mbridLit: MBRIDLIT[0],
      });
  
  }

  async UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props.flag === true || this.props.resetFlag === false) {
      await this.setState({
        page: 0,
        selectedRow: 0,
        index: 0,
        selectedPage: 0,
        sortDir: "desc",
        colToSort: "",
        rowsPerPage: nextProps.rowsPerPage,
        data: nextProps.data,
      });
    } else {
      const pageNo = Math.floor(nextProps.index / nextProps.rowsPerPage);
   
      const selectedRow = nextProps.index % nextProps.rowsPerPage;
      await this.setState({
        page: pageNo,
        selectedRow: selectedRow,
        rowsPerPage: parseInt(nextProps.rowsPerPage),
        selectedPage: pageNo,
        data: nextProps.data,
      });
    }
    await this.setState({
      search: ""
    });
  }

  generate = (data, header) => {
    var jsPDF = require("jspdf");
    var pdfsize = "a4";
    require("jspdf-autotable");
    var doc = new jsPDF("l", "mm", pdfsize);

    const index = header.findIndex((d) => {
      return d.title === "Action";
    });
    if (index !== -1) {
      header.splice(index, 1);
    }

    data.map((d) => {
      if (d.hasOwnProperty("letterAvailabilityInDBGet")) {
        d.letterAvailabilityInDBGet = "PDF";
      }

      if (d.hasOwnProperty("letterAvailabilityInDBPdfIcon")) {
        d.letterAvailabilityInDBPdfIcon = "PDF";
      }
      if (d.hasOwnProperty("checkbox")) {
        delete d.checkbox;
      }
      return d;
    });
    doc.autoTable(header, data);

    doc.save("Document.pdf");
  };

  exportDataFunc = (data, all) => {
    const exportdata = this.props.data.slice();
    const searchdata = data.slice();

    if (all) {
      this.setState({
        exportData: exportdata,
        radio: "all",
      });
    } else {
      if (data.length <= this.state.rowsPerPage) {
        this.setState({
          exportData: searchdata,
          radio: "current",
        });
      } else {
        this.setState({
          exportData: searchdata.slice(
            this.state.page * this.state.rowsPerPage,
            this.state.page * this.state.rowsPerPage + this.state.rowsPerPage
          ),
          radio: "current",
        });
      }
    }
  };

  handleSort = async (colName) => {
    await this.setState((prevState) => ({
      colToSort: colName,
      sortClick: true,
      sortDir:
        this.state.colToSort === colName
          ? invertDirection[this.state.sortDir]
          : "asc",
    }));

    //   const { page, rowsPerPage } = this.state;
    //   const index = page * this.state.rowsPerPage;
    // //  await  this.props.handleSort(index)
    //   const selectedIndex =
    //     page * this.state.rowsPerPage + this.state.selectedRow;
    //   this.setState({
    //     selectedPage: page,
    //     page,
    //   });
    //   await this.props.clicked(
    //     index,
    //     data[index],
    //     this.state.rowsPerPage
    //   );
  };

  rowSelect = async (rowIndex, data) => {
    const { page, rowsPerPage } = this.state;
    const selectedIndex = page * rowsPerPage + rowIndex;
    await this.setState({
      sortClick: false,
      selectedPage: page,
    });
    let search = this.state.search;
    await this.props.clicked(selectedIndex, data, rowsPerPage);
    this.setState({search:search})
  };

  handleChangePage = async (page) => {
    if (typeof page !== "number") {
      this.fetchMore1(page);
      return;
    }
    //
    const index = page * this.state.rowsPerPage;

    // const selectedIndex =
    //   page * this.state.rowsPerPage + this.state.selectedRow;
    this.setState({
      // selectedPage: page,
      page,
    });
    if (!this.props.flag) {
      this.setState({
        mbrSearch: true,
      });
    }
    //
    // this.props.handleChangePage && this.props.handleChangePage(index);
    //  this.props.clickedFooter && this.props.clickedFooter(page,this.props.data[index]);
    await this.props.clicked(
      index,
      this.props.data[index],
      this.state.rowsPerPage
    );
    // await this.props.clicked(selectedIndex, this.props.data[selectedIndex], this.state.rowsPerPage);
  };

  handleChangeRowsPerPage = (event) => {
    this.setState({
      page: 0,
      rowsPerPage: event.target.value,
      selectedRow: "",
      index: "",
    });
    this.props.handleChangeRowsPerPage(event.target.value);
  };

  fetchMore1 = async () => {
    await this.props.fetchMore(this.state.page);
  };
  handleMobileMenuOpen = (event) => {
    this.setState({ mobileMoreAnchorEl: event.currentTarget });
  };
  x;
  handleMobileMenuClose = () => {
    this.setState({ mobileMoreAnchorEl: null });
  };
  handleMenuClose = () => {
    this.setState({ anchorEl: null });
    this.handleMobileMenuClose();
  };
  serachHandle = (event) => {
    return this.setState({
      page:0,
      search: event.target.value,
    });
  };

  labelDisplayedRows = (from, to, count) => {
    const rowsPerPage = this.state.rowsPerPage;
    return (
      <span>
        Page :
        {Math.ceil(from / rowsPerPage) !== 0
          ? Math.ceil(from / rowsPerPage)
          : 1}{" "}
        - {}
        {count !== -1
          ? Math.ceil(count / rowsPerPage)
          : Math.ceil(to / rowsPerPage)}
      </span>
    );
  };

  
  render() {
    sessionStorage.setItem("backIconButtonProps", this.props.nextPage);
    const { mobileMoreAnchorEl } = this.state;
    const {
      classes,
      searchable,
      sortable,
      exportAsExcel,
      removePagination,
      selectedRow,
      notClickable,
      rowsPerPageOptions,
      dateColumn,
    } = this.props;
    const {
      rowsPerPage,
      page,
      exportData,
      sortClick,
      selectedPage,
      colToSort,
      sortDir,
    } = this.state;

    const isMobileMenuOpen = Boolean(mobileMoreAnchorEl);

    let data = this.state.data;

    let isdataExist = data.length > 0;
    const header = this.props.header.filter((value) =>
      this.state.mbridLit.value === "TSA"
        ? value.label !== "M360 ID"
        : value.label !== "Wipro ID"
    );
    const search = this.state.search.toLowerCase();
    let msg = "NO DATA FOUND";

    if (this.props.msgChange) {
      msg = this.props.msgChange;
    }

    if (colToSort && this.props.subtab) {
      const name = colToSort;
      if (dateColumn && dateColumn.includes(colToSort)) {
        let tempData = [...this.state.data];
        tempData.sort(function compare(a, b) {
          let date1 =
            a[name].length === 7
              ? [a[name].slice(0, 3), "01/", a[name].slice(3)].join("")
              : a[name];
          let date2 =
            b[name].length === 7
              ? [b[name].slice(0, 3), "01/", b[name].slice(3)].join("")
              : b[name];

          const result =
            date1 === "99/99/9999"
              ? 1
              : date2 === "99/99/9999"
                ? -1
                : Date.parse(date1) - Date.parse(date2);
          return result;
        });
        data = tempData;
        if (sortDir === "desc") {
          data.reverse();
        }
      } else {
        data.sort(function compare(a, b) {
          const result =
            sortDir === "asc"
              ? a[name] > b[name]
                ? -1
                : 1
              : b[name] > a[name]
                ? -1
                : 1;
          return result;
        });
      }
    }

    if (colToSort && !this.props.subtab) {
      const name = colToSort;
      let tempData = [...data];
      if (dateColumn && dateColumn.includes(colToSort)) {
        tempData.sort(function compare(a, b) {
          let date1 =
            a[name].length === 7
              ? [a[name].slice(0, 3), "01/", a[name].slice(3)].join("")
              : a[name];
          let date2 =
            b[name].length === 7
              ? [b[name].slice(0, 3), "01/", b[name].slice(3)].join("")
              : b[name];

          const result =
            date1 === "99/99/9999"
              ? 1
              : date2 === "99/99/9999"
                ? -1
                : Date.parse(date1) - Date.parse(date2);
          return result;
        });
        if (sortDir === "desc") {
          tempData.reverse();
        }
      } else {
        tempData = orderBy(data, colToSort, sortDir);
      }
      data = [...tempData];
    }

    let resolveFlag =
      this.props.searchFlag === true
        ? this.props.currentUser === this.props.assignee
          ? true
          : false
        : this.props.currentUser === this.props.assignee
          ? false
          : true;

    if (this.state.search) {
      data = data.filter((row) => {
        let flag = false;
        header.forEach((object) => {
          if (row[object.key]) {
            const value = row[object.key].toString().toLowerCase();
            //.slice(0, search.length);
            if (value.includes(search.toLowerCase())) {
              flag = true;
            }
          }
        });
        return flag;
      });
    }

    return (
      <div style={{ width: "100%" }}>
        {isdataExist && exportAsExcel ? (
          <PrintSearchExpot
            search={this.state.search}
            searchable={searchable}
            serachHandle={this.serachHandle}
            printTb={this.props.printTb}
            printHandle={this.props.printFun}
            exportAsExcel={exportAsExcel}
            exportHandle={(e) => {
              this.exportDataFunc(data, false);
              this.handleMobileMenuOpen(e);
            }}
            data={data}
            mobileMoreAnchorEl={mobileMoreAnchorEl}
            openMenu={isMobileMenuOpen}
            onCloseMenu={this.handleMenuClose}
            radio={this.state.radio}
            exportDataFunc={this.exportDataFunc}
            exportData={exportData}
            generate={this.generate}
            header={header}
            applExportbtn={this.props.applExportbtn}
          />
        ) : null}
        <div
          className={classes.tableWrapper}
          style={{ width: this.props.width ? this.props.width : "100%" }}
        >
          <Table
            className={removePagination ? classes.tableModified : classes.table}
            id="maintable"
          >
            <TableHead className={classes.thead}>
              <TableRow className={classes.headRow}>
                {header.map((mbrCol, i) => (
                  <TableCell
                    align="left"
                    className={classes.headerCell}
                    key={i}
                    style={{
                      paddingBottom: "0.4em!important",
                      paddingTop: "0.4em!important",
                    }}
                  >
                    {sortable && isdataExist ? (
                      <div onClick={() => this.handleSort(mbrCol.key)}>
                        {mbrCol.label}
                        {this.state.colToSort === mbrCol.key ? (
                          this.state.sortDir === "asc" ? (
                            <span class="sort"> &nbsp;&#8593;</span>
                          ) : (
                              <span class="sort"> &nbsp;&#8595;</span>
                            )
                        ) : (
                            <span class="sort sort-default"> &nbsp;&#8597;</span>
                          )}
                      </div>
                    ) : (
                        mbrCol.label
                      )}
                  </TableCell>
                ))}
                {this.props.activityTable ? (
                  resolveFlag ? (
                    <TableCell>
                      <Button
                        style={{
                          color: "#fff",
                          backgroundColor: "#389bb5",
                          fontSize: "10px",
                        }}
                        onClick={this.props.updatedVal}
                      >
                        Resolve
                      </Button>
                    </TableCell>
                  ) : null
                ) : null}
              </TableRow>
            </TableHead>

            <TableBody className={classes.tbody}>
              {data.length < 1 && (
                <TableRow className={classes.row}>
                  <TableCell
                    name="cell"
                    style={{
                      paddingBottom: "0.4em!important",
                      paddingTop: "0.4em!important",
                    }}
                    colSpan={header.length}
                    className={classes.tableCell}
                  >
                    {msg}
                  </TableCell>
                </TableRow>
              )}
              {data
                .slice(
                  page * parseInt(rowsPerPage),
                  page * parseInt(rowsPerPage) + parseInt(rowsPerPage)
                )
                .map((genericDetail, j) => (
                  <TableRow
                    className={
                      selectedRow
                        ? classes.row
                        : this.state.selectedRow === j &&
                          !sortClick &&
                          page === selectedPage &&
                          !notClickable
                          ? classes.selectedrow
                          : classes.row
                    }
                    key={j}
                    onClick={
                      notClickable
                        ? () => { }
                        : () => this.rowSelect(j, data[page * rowsPerPage + j])
                    }
                  >
                    {header.map((genericKey, p) => (
                    genericKey.key==="transReplyCd"?
                    <Tooltip1 title={genericDetail.transReplyDefinition} placement="centre top">
                      <TableCell
                        key={p}
                        style={this.props.errorTable ? { color: "red" } : null}
                        align="left"
                        className={
                          genericKey.key === "appliedAmt"
                            ? classes.appliedAmtTableCell
                            : classes.tableCell
                        }
                       
                      >
                        {this.props.errorTable && genericKey.key === "fieldNbr"
                          ? ERROR_FIELD_MAPPINGS[
                            genericDetail[genericKey.key]
                          ] === "M360 ID" &&
                            this.state.mbridLit.value === "TSA"
                            ? "WIPRO ID"
                            : ERROR_FIELD_MAPPINGS[
                            genericDetail[genericKey.key]
                            ]
                          : genericKey.key
                            .substr(genericKey.key.length - 4)
                            .toLowerCase() === "time"
                            ? genericKey.title === "Date/Time"
                              ? formatFullTimeStamp(genericDetail[genericKey.key])
                              : formatTimeStamp(genericDetail[genericKey.key])
                            : genericDetail[genericKey.key]}
                           
                            <i   className={classNames("fas fa-info-circle",classes.infoIcon)}></i>
                             
                      </TableCell>
                  
                    </Tooltip1>:

                      <TableCell
                        key={p}
                        style={this.props.errorTable ? { color: "red" } : null}
                        align="left"
                        className={
                          genericKey.key === "appliedAmt"
                            ? classes.appliedAmtTableCell
                            : classes.tableCell
                        }
                      
                      >
                        {this.props.errorTable && genericKey.key === "fieldNbr"
                          ? ERROR_FIELD_MAPPINGS[
                            genericDetail[genericKey.key]
                          ] === "M360 ID" &&
                            this.state.mbridLit.value === "TSA"
                            ? "WIPRO ID"
                            : ERROR_FIELD_MAPPINGS[
                            genericDetail[genericKey.key]
                            ]
                          : genericKey.key
                            .substr(genericKey.key.length - 4)
                            .toLowerCase() === "time"
                            ? genericKey.title === "Date/Time"
                              ? formatFullTimeStamp(genericDetail[genericKey.key])
                              : formatTimeStamp(genericDetail[genericKey.key])
                            : genericDetail[genericKey.key]}
                             
                             
                      </TableCell>
                    ))}
                   
                    {this.props.activityTable ? (
                      resolveFlag ? (
                        <TableCell></TableCell>
                      ) : null
                    ) : null}
                  </TableRow>
                ))}
            </TableBody>
            {!removePagination && data.length > 0 ? (
              <TableFooter className={classes.footer}>
                <TableRow className={classes.footer}>
                  <TablePagination
                    className={classes.pagination}
                    rowsPerPageOptions={
                      rowsPerPageOptions ? rowsPerPageOptions : []
                    }
                    colSpan={
                      !this.props.activityTable
                        ? header.length
                        : header.length + 1
                    }
                    count={data.length}
                    rowsPerPage={rowsPerPage}
                    //used to pass Total count -DB
                    backIconButtonProps={this.props.nextPage}
                    page={page}
                    SelectProps={{
                      native: true,
                    }}
                    classes={{
                      toolbar: classes.footer,
                    }}
                    labelDisplayedRows={({ from, to, count }) =>
                      this.labelDisplayedRows(from, to, count)
                    }
                    onChangePage={this.handleChangePage}
                    onChangeRowsPerPage={this.handleChangeRowsPerPage}
                    ActionsComponent={Pagination}
                    nextIconButtonProps={this.fetchMore1}
                  />
                </TableRow>
              </TableFooter>
            ) : null}
          </Table>
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    loginProfile: state.loginData.profiles,
  };
};

export default connect(mapStateToProps)(withStyles(styles)(DataTable));
