import React, { Component } from "react";
import { CSVLink } from "react-csv";
import ExportExcel from "../../utils/ExportExcelComponent";
import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Input from "@material-ui/core/Input";
import InputAdornment from "@material-ui/core/InputAdornment";
import Menu from "@material-ui/core/Menu";
import MenuItem from "@material-ui/core/MenuItem";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import classNames from "classnames";
import { styles } from "../../assets/styles/DataTableStyle";
import { withStyles } from "@material-ui/core/styles";

class PrintSearchExport extends Component {
  exportParent = boolValue => {
    this.props.exportDataFunc(this.props.data, boolValue);
  };

  render() {
    const {
      classes,
      search,
      searchable,
      serachHandle,
      printTb,
      printHandle,
      exportAsExcel,
      data,
      exportHandle,
      mobileMoreAnchorEl,
      openMenu,
      onCloseMenu,
      radio,
      generate,
      applExportbtn
    } = this.props;
  let  {
    exportData,
    header
  } = this.props;
  if(Array.isArray(header)){
  const index =  header.findIndex(d =>{
    return  d.title  === "Action"
    })
if(index !== -1){
  header.splice(index, 1)
}
  }
 if(Array.isArray(exportData)){
  exportData.map(d=>{
    
    if(d.hasOwnProperty('letterAvailabilityInDBGet')){
      d.letterAvailabilityInDBGet = "PDF"
      }
  
      if(d.hasOwnProperty('letterAvailabilityInDBPdfIcon')){
        d.letterAvailabilityInDBPdfIcon = "PDF"
        }
      if(d.hasOwnProperty('checkbox')){
       delete d.checkbox ;
        }
    return d;
  })
 }

    return (
      <div className={classes.print}>
        {searchable ? (
          <FormControl className={classes.paddingSearch}>
            <Input
              id="input-with-icon-adornment"
              value={search}
              placeholder="Search..."
              className={classes.search}
              onChange={serachHandle}
              width={"220px"}
              startAdornment={
                <InputAdornment position="start">
                  <i className="material-icons">search</i>
                </InputAdornment>
              }
            />
          </FormControl>
        ) : null}
        <span>
          {printTb ? (
            <i class="material-icons icons-custome" onClick={printHandle}>
              print
            </i>
          ) : null}
        </span>
        <span className={classes.marginExport}>
          {exportAsExcel && data.length > 0 ? (
            <i
              onClick={exportHandle}
              className={classNames("fas fa-file-export", applExportbtn ? classes.exportIconbtnAppl : classes.exportIcon)}
            />
          ) : exportAsExcel ? (
            <i
              className={classNames("fas fa-file-export", applExportbtn ? classes.exportIconbtnAppl : classes.exportIcon)}
            />
          ) : null}

          <Menu
            classes={{
              paper: classes.placing
            }}
            anchorEl={mobileMoreAnchorEl}
            anchorOrigin={{ vertical: "top", horizontal: "right" }}
            transformOrigin={{ vertical: "top", horizontal: "right" }}
            open={openMenu}
            onClose={onCloseMenu}
          >
            <MenuItem>
              <RadioGroup row value={radio}>
                <FormControlLabel
                  value="current"
                  control={<Radio />}
                  label="Current"
                  onClick={() => this.exportParent(false)}
                />
                <FormControlLabel
                  value="all"
                  control={<Radio />}
                  label="All"
                  onClick={() => this.exportParent(true)}
                />
              </RadioGroup>
            </MenuItem>
            <MenuItem className={classes.export}>
              <ExportExcel
                fileName="Document"
                dataSet={exportData}
                colName={header}
                classes={classes}
              />
              <CSVLink
                data={exportData}
                headers={header}
                separator={";"}
                filename={"Document.csv"}
              >
                <i
                  className={classNames("fas fa-file-csv", classes.csvIcon)}
                ></i>
              </CSVLink>

              <i
                className={classNames("fa fa-file-pdf-o", classes.pdfIcon)}
                aria-hidden="true"
                onClick={() => generate(exportData, header)}
              ></i>
            </MenuItem>
          </Menu>
        </span>
      </div>
    );
  }
}
export default withStyles(styles)(PrintSearchExport);
