import React from "react";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import { styles } from "../../assets/styles/DataTableStyle";
import { withStyles } from "@material-ui/core/styles";

class Demo extends React.Component {
  state = {
    selectedRow: 0
  };

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps) {
      const selectedRow = nextProps.index;
      this.setState({
        selectedRow: selectedRow
      });
    }
  }

  rowSelect = async (rowIndex, data) => {
    const selectedIndex = rowIndex;

    await this.props.clicked(selectedIndex, data);
  };

  render() {
    const { classes, selectedRow, notClickable, data, header } = this.props;
    let msg = "NO NOTIFICATIONS";

    return (
      <div>
        <Table>
          <TableHead className={classes.thead}>
            <TableRow className={classes.headRow}>
              {header.map((mbrCol, i) => (
                <TableCell align="left" className={classes.headerCell} key={i}>
                  <div>{mbrCol.label}</div>
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody className={classes.tbody}>
            {data.length < 1 && (
              <TableRow className={classes.row}>
                <TableCell
                  colSpan={header.length}
                  className={classes.tableCell}
                >
                  {" "}
                  {msg}{" "}
                </TableCell>
              </TableRow>
            )}
            {data.map((genericDetail, j) => (
              <TableRow
                className={
                  selectedRow
                    ? classes.row
                    : this.state.selectedRow === j
                    ? classes.selectedrow
                    : classes.row
                }
                key={j}
                onClick={
                  notClickable ? () => {} : () => this.rowSelect(j, data[j])
                }
              >
                {/* </TableRow>
              <TableRow
                className={
                  selectedRow
                    ? classes.row
                    : this.state.selectedRow === j && !notClickable
                    ? classes.selectedrow
                    : classes.row
                }
                key={j}
                onClick={notClickable ? () => {} : () => this.rowSelect(j)}
              > */}
                {header.map((genericKey, p) => (
                  <TableCell
                    key={p}
                    style={
                      this.props.notiTable
                        ? genericDetail.user_viewed === true
                          ? {
                              color: "rgba(39, 108, 155, 1)",
                              fontWeight: "normal"
                            }
                          : { fontWeight: "bold" }
                        : null
                    }
                    align="left"
                    className={classes.tableCell}
                  >
                    {genericDetail[genericKey.key]}
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    );
  }
}

export default withStyles(styles)(Demo);
