import React, { Component } from "react";
import Checkbox from "@material-ui/core/Checkbox";
import Button from "@material-ui/core/Button";
import ExpansionPanel from "../UI/ExpansionPanel";
import { Dashlet_LIST } from "../../constants/staticData/DashboradTest";
import { withStyles } from "@material-ui/core/styles";
import { Styles } from "../../assets/styles/DashboradStyles";
import { resetMemberSearch } from "../../redux/actions/MemberActions";
import {
  getcustomerPlanIds,
  setSearchFlag,
} from "../../redux/actions/DashboardActions";
import { connect } from "react-redux";
import isEmpty from "lodash/isEmpty";
import Dashlet from "./Card";
import Modal from "../../components/UI/Modal/Modal";

const Checkbox1 = withStyles((theme) => ({
  root: {
    padding: "5px 0px 5px 0px !important",
  },
}))(Checkbox);
class NewDashboard extends Component {
  constructor() {
    super();
    this.state = {
      checkedList: [],
      collapse: false,
      showDashlets: false,
      checkedItemList: [],
      closePopup: false,
    };
  }
  async componentDidMount() {
    if (isEmpty(this.props.dropdowns)) await this.props.getcustomerPlanIds();
  }
  handleChange = (e) => {
    let checkedList = [...this.state.checkedItemList];
  
    if (checkedList.length > 5 && e.target.checked) {
      this.setState({ closePopup: true });
    } else {
      if (e.target.checked) checkedList.push(e.target.name);
      else checkedList.splice(checkedList.indexOf(e.target.name), 1);

      this.setState({ checkedItemList: checkedList, collapse: false });
    }
  };
  reset = () => {
    this.setState({
      checkedList: [],
    });
  };
  componentWillUnmount() {
    this.props.resetMemberSearch({
      applicationId: this.props.selectedMemberId.applicationId,
    });
  }
  submit = () => {
    this.setState(
      {
        showDashlets: true,
        collapse: true,
        checkedList: this.state.checkedItemList,
      },
      () => this.props.setSearchFlag(true)
    );
  };
  modalClosed = () => {
    this.setState({ closePopup: false });
  };
  render() {
    const { classes } = this.props;
    const { checkedList, showDashlets, collapse, checkedItemList } = this.state;
    return (
      <div>
        <Modal
          dialogTitle="Max Limit Exceed"
          message="There is a maximum limit of 6 dashlets per view "
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <ExpansionPanel summary="Dashboard" defaultCollapsed={collapse}>
          <div className={classes.container}>
            <div className={classes.checkcontainer}>
              {Dashlet_LIST.map((item) => (
                <div className={classes.dashBoardCheckbox}>
                  <Checkbox1
                    color="primary"
                    checked={checkedItemList.includes(item)}
                    onChange={this.handleChange}
                    name={item}
                    padding={"0px 0px 0px 0px !important"}
                  />
                  <span className={classes.checkboxlebel}>{item}</span>
                </div>
              ))}
              <Button
                variant="contained"
                color="primary"
                className={classes.button}
                onClick={this.submit}
              >
                Apply
              </Button>
            </div>
          </div>
        </ExpansionPanel>

        {showDashlets ? (
          <div class="row">
            {checkedList.map((item) => (
              <div class="col-md-4">
                <Dashlet index={Dashlet_LIST.indexOf(item)} title={item} />
              </div>
            ))}
          </div>
        ) : null}
      </div>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    dropdowns: state.dashboard.customerPlanIds,
    selectedMemberId: state.memberSearch.selectedMemberId,
  };
};

const mapDispatchToProps = {
  getcustomerPlanIds,
  setSearchFlag,
  resetMemberSearch
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(NewDashboard));
