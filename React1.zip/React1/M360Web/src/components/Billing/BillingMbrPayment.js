import MuiExpansionPanelDetails from "@material-ui/core/ExpansionPanelDetails";
import Paper from "@material-ui/core/Paper";
import { withStyles } from "@material-ui/core/styles";
import React, { Component } from "react";
import { connect } from "react-redux";
import { Styles } from "../../assets/styles/Theme";
import {
  getBillingPaymentSearch,
  getBillingPaymentDetailInvoice,
  setMbrPaymentsIndex,
  mbrPaymentsSearchNext,
} from "../../redux/actions/BillingActions";
import ExpansionPanel from "../UI/ExpansionPanel";
import InputField from "../UI/InputField";
import AutoComplete1 from "../UI/Select";
import MemberPaymentDetails from "./BillingMbrPaymentDetails";
import DataTable from "../Home/DataTable";
import { MBRPAYMENT_DETAILS_HEADER as header } from "../../constants/Headers/BillingHeaders";
import isEmpty from "lodash/isEmpty";

const ExpansionPanelDetails = withStyles((theme) => ({
  root: {
    padding: theme.spacing.unit * 2,
    display: "block",
  },
}))(MuiExpansionPanelDetails);

const SEARCH_INITIAL_STATE = {
  customerId: null,
  searchPaySource: null,
  searchInvoiceId: null, //memberid
  searchCheckNbr: null,
  searchLastName: null,
  searchHicNbr: null, //MedicareId
  searchSupplId: null,
};
class MemberPayment extends Component {
  state = {
    selectedIndex: 0,
    rowsPerPage: 10,
    searchVo: SEARCH_INITIAL_STATE,
    editable: false,
    searchFlag: false,
    flag: false,
    mbridLit: [],
    resetFlag: true,
  };
  componentWillUnmount() {
    const { selectedIndex } = this.state;
    this.props.setMbrPaymentsIndex(selectedIndex);
  }

  componentDidMount() {
    const tableIndex = this.props.tableIndex;
    const { mbrPaymentList } = this.props;
    this.setState({
      selectedIndex: tableIndex,
      paymentVo: mbrPaymentList[tableIndex],
    });
    const { loginProfile } = this.props;
    const MBRIDLIT = loginProfile.filter((data) => data.label === "MBRIDLIT");
    this.setState({
      mbridLit: MBRIDLIT[0],
    });
  }
  static getDerivedStateFromProps(nextProps, prevState) {
    if (prevState.searchFlag === false && nextProps.mbrPaymentList.length > 0) {
      return { searchFlag: true };
    }
  }
  doBillPaymentsSearch = async (event) => {
    event.preventDefault();
    this.setState({ flag: true, searchFlag: true });
    await this.props.getBillingPaymentSearch(this.state.searchVo);
    await this.setState({
      flag: false,
      selectedIndex: 0,
      paymentVo: this.props.mbrPaymentList[0],
      resetFlag: true,
    });
  };
  reset = () => {
    this.setState({
      searchVo: SEARCH_INITIAL_STATE,
      resetFlag: false,
    });
  };
  handlechange = (event) => {
    let name = event.target.name;
    let value = event.target.value.toUpperCase();

    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value,
      },
    }));
  };

  handleChangeSearchSelectAuto = (data, name) => {
    let value = data.value;
    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleOnBlur = (event) => {
    let value = event.target.value.trim();
    let name = event.target.name;

    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  toggleFlag = () => {
    this.setState({ editable: true });
  };

  handleChangeRowsPerPage = async (rowsPerPage) => {
    await this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };
  selectRow = async (index, selectedVo, rowsPerPage) => {
    await this.setState({
      selectedIndex: index,
      editable: false,
      addCustomerFlag: false,
      paymentVo: selectedVo,
      rowsPerPage: rowsPerPage,
    });
    await this.props.getBillingPaymentDetailInvoice(selectedVo);
  };
  fetchMoreResults = async (pageNo) => {
    const { searchCriteriaVo, mbrPaymentList } = this.props;
    const lastIndex = mbrPaymentList.length - 1;
    const {
      searchPaySource,
      invoiceDueDate,
      batchDate,
      batchSeqNbr,
      itemNbr,
      invoiceId,
    } = mbrPaymentList[lastIndex];

    let payload = {
      ...searchCriteriaVo,
      searchInvoiceId: invoiceId,
      searchPaySource: searchPaySource,
      invoiceDueDate: invoiceDueDate,
      batchDate: batchDate,
      batchSeqNbr: batchSeqNbr,
      itemNbr: itemNbr,
    };
    await this.props.mbrPaymentsSearchNext(payload);
    this.setState({
      selectedIndex: pageNo * this.state.rowsPerPage,
    });
  };
  render() {
    const { classes, dropdowns, nextPage, mbrPaymentList } = this.props;
    const {
      searchVo,
      searchFlag,
      selectedIndex,
      collapseSearch,
      collapseTableSearch,
      rowsPerPage,
      flag,
      mbridLit,
      resetFlag,
      paymentVo,
    } = this.state;

    return (
      <Paper elevation={0} className={[classes.card, classes.paperHeight]}>
        <div class="search-panel">
          <ExpansionPanel summary="Search" defaultCollapsed={collapseSearch}>
            <ExpansionPanelDetails>
              <form onSubmit={this.doBillPaymentsSearch}>
                <div className={classes.containertypography}>
                  <div className={classes.textBox}>
                    <InputField
                      name="searchLastName"
                      InputProps={{ className: classes.textFont }}
                      label="Last Name"
                      maxLength={35}
                      className={classes.textField}
                      value={searchVo.searchLastName}
                      InputLabelProps={{
                        className: classes.label,
                        shrink: true,
                      }}
                      onChange={this.handlechange}
                      onBlur={this.handleOnBlur}
                    />
                    <div className={classes.billSrchvalidation} />
                  </div>
                  <div className={classes.textBox}>
                    <InputField
                      name="searchHicNbr"
                      InputProps={{ className: classes.textFont }}
                      label="Medicare ID"
                      className={classes.textField}
                      value={searchVo.searchHicNbr}
                      maxLength={12}
                      InputLabelProps={{
                        className: classes.label,
                        shrink: true,
                      }}
                      onChange={this.handlechange}
                      onBlur={this.handleOnBlur}
                    />
                    <div className={classes.billSrchvalidation} />
                  </div>
                  <div className={classes.textBox}>
                    <InputField
                      name="searchInvoiceId"
                      InputProps={{ className: classes.textFont }}
                      label={mbridLit.value === "TSA" ? "Wipro ID" : "M360 ID"}
                      className={classes.textField}
                      value={searchVo.searchInvoiceId}
                      maxLength={15}
                      InputLabelProps={{
                        className: classes.label,
                        shrink: true,
                      }}
                      onChange={this.handlechange}
                      onBlur={this.handleOnBlur}
                    />
                    <div className={classes.billSrchvalidation} />
                  </div>
                  <div className={classes.textBox}>
                    <InputField
                      name="searchCheckNbr"
                      InputProps={{ className: classes.textFont }}
                      label="Check Nbr"
                      className={classes.textField}
                      value={searchVo.searchCheckNbr}
                      maxLength={12}
                      InputLabelProps={{
                        className: classes.label,
                        shrink: true,
                      }}
                      onChange={this.handlechange}
                      onBlur={this.handleOnBlur}
                    />
                    <div className={classes.billSrchvalidation} />
                  </div>
                  <div className={classes.textBox}>
                    <AutoComplete1
                      options={
                        dropdowns
                          ? dropdowns
                          : {
                              label: "Select",
                              value: "",
                            }
                      }
                      margin="0px"
                      fontSize="0.718em"
                      handleChange={this.handleChangeSearchSelectAuto}
                      defaultValue={{
                        label: "Select",
                        value: "",
                      }}
                      value={
                        dropdowns
                          ? dropdowns.filter(
                              (option) =>
                                option.value === searchVo.searchPaySource
                            )[0]
                          : {
                              label: "Select",
                              value: "",
                            }
                      }
                      label="Pay Source Type"
                      name="searchPaySource"
                    />
                    <div className={classes.billSrchvalidation} />
                  </div>
                  <div className={classes.textBox}>
                    <InputField
                      name="searchSupplId"
                      InputProps={{ className: classes.textFont }}
                      label="Plan Member ID"
                      className={classes.textField}
                      value={searchVo.searchSupplId}
                      InputLabelProps={{
                        className: classes.label,
                        shrink: true,
                      }}
                      onChange={this.handlechange}
                      onBlur={this.handleOnBlur}
                      maxLength={15}
                    />
                    <div className={classes.billSrchvalidation} />
                  </div>
                  <span
                    class="button-container-search"
                    className={classes.expansionPanelbuttons}
                  >
                    <button type="submit" class="btn btn-primary icon-search">
                      Search
                    </button>
                    <button
                      type="button"
                      class="btn btn-secondary"
                      onClick={this.reset}
                    >
                      Reset
                    </button>
                  </span>
                </div>
              </form>
            </ExpansionPanelDetails>
          </ExpansionPanel>
        </div>
        {searchFlag && !isEmpty(mbrPaymentList) ? (
          <div class="search-panel">
            <ExpansionPanel
              summary="Search Results"
              defaultCollapsed={collapseTableSearch}
            >
              <DataTable
                data={isEmpty(mbrPaymentList) ? [] : mbrPaymentList}
                header={header}
                rowsPerPage={rowsPerPage}
                sortable={true}
                rowsPerPageOptions={[5, 10, 15, 20]}
                clicked={this.selectRow}
                flag={flag}
                index={selectedIndex}
                handleChangeRowsPerPage={this.handleChangeRowsPerPage}
                fetchMore={this.fetchMoreResults}
                nextPage={nextPage}
                dateColumn="checkDateFrmt"
              />
            </ExpansionPanel>
          </div>
        ) : resetFlag && searchFlag ? (
          <div class="search-panel">
            <ExpansionPanel
              summary="Search Results"
              defaultCollapsed={collapseTableSearch}
            >
              <DataTable data={[]} header={header} />
            </ExpansionPanel>
          </div>
        ) : null}
        {mbrPaymentList.length > 0 && searchFlag ? (
          <MemberPaymentDetails
            index={selectedIndex}
            searchVo={searchVo}
            selectedVo={paymentVo}
            flag={flag}
          />
        ) : null}
        <br />
      </Paper>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    mbrPaymentList:
      state.billingReducer.mbrPayments.mbrPaymentSearchResults.mbrPaymentsVO,
    tableIndex: state.billingReducer.mbrPayments.tableIndexes.mbrPaymentList,
    dropdowns: state.billingReducer.bilingCacheData.payTypesList,
    searchCriteriaVo: state.billingReducer.mbrPayments.searchCriteriaVo,
    nextPage: state.billingReducer.mbrPayments.nextPage,
    loginProfile: state.loginData.profiles,
  };
};
const mapDispatchToProps = {
  mbrPaymentsSearchNext,
  getBillingPaymentSearch,
  getBillingPaymentDetailInvoice,
  setMbrPaymentsIndex,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(MemberPayment));
