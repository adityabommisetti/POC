import Button from "@material-ui/core/Button";
import MuiExpansionPanelDetails from "@material-ui/core/ExpansionPanelDetails";
import Paper from "@material-ui/core/Paper";
import { withStyles } from "@material-ui/core/styles";
import React, { Component } from "react";
import { connect } from "react-redux";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../assets/styles/Theme";
import Modal from "../../components/UI/Modal/Modal";
import * as Type from "../../constants/ConfirmType";
import {
  ADDPAYMENT_DETAILS_HEADER,
  PAYMENT_INVOICE_HEADER,
  PAYMENT_ITEM_HEADER,
} from "../../constants/Headers/BillingHeaders";
import { messages } from "../../constants/Messages";
import {
  addPaymentdetails,
  getBillingPaymentCache,
  getPaymentDetail,
  paymentDetailsUpdate,
  getPaymentEntrySearch,
  newPaymentEntry,
  paymentHeaderUpdate,
  setPaymentHeaderIndex,
  setPaymentDetailsIndex,
} from "../../redux/actions/BillingActions";
import { handleDateChange } from "../../utils/DateFormatter";
import BillingDataTable from "../Home/BillingDataTable";
import DataTable from "../Home/DataTable";
import ExpansionPanel from "../UI/ExpansionPanel";
import InputField from "../UI/InputField";
import HistoryData from "../UI/MemberHistory";
import ConfirmBox from "../../utils/PopUp";
import * as DateUtil from "../../utils/DatePicker";
import { POSTED_IND } from "../../constants/BillingInitialState";
import AutoComplete1 from "../UI/Select";
import { customValidations } from "../../utils/CustomValidations";
import isEmpty from "lodash/isEmpty";

const NEWPAYMENT_DETAILS_DATA = {
  paymentAmt: "",
  paySource: "",
  paySourceDesc: "",
  batchDate: "",
  batchSeqNbr: "",
  bankAcntCd: "",
  batchBalance: "",
  detailAmount: "",
  batchBalInd: "",
  batchDtlCount: "",
  batchPostedInd: "",
};

let dateChk = {};
const ExpansionPanelDetails = withStyles((theme) => ({
  root: {
    padding: theme.spacing.unit * 2,
    display: "block",
    width: "100%",
  },
}))(MuiExpansionPanelDetails);

class BillingPaymentSearch extends Component {
  constructor(props) {
    super(props);
    this.state = {
      billingSearchData: this.props.billingSearchData,
      selectedPaymentVo: this.props.billingPaymentlist[0],
      paymentEntryVo: this.props.billingPaymentlist[0],
      data: this.props.billingPaymentlist,
      rows: 0,
      rowCount: 0,
      selectedIndex: 0,
      selectedDtlIndex: 0,
      selectedInvIndex: 0,
      newPaymentdata: NEWPAYMENT_DETAILS_DATA,
      paymentHeader: this.props.selectedVo,
      isNewSegment: false,
      addDtls: false,
      newAddPaymentarr: [],
      final: [],
      editable: false,
      rowsPerPage: 10,
      paymentDetailsVo: this.props.billingPaymentDtlsList[0],
      paymentDetailsList: this.props.billingPaymentDtlsList,
      editableDtls: false,
      mbridLit: [],
    };
    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
        amountValidator: customValidations.amountValidator,
      },
    });
  }
  componentWillUnmount() {
    const { selectedIndex, selectedDtlIndex } = this.state;
    this.props.setPaymentHeaderIndex(selectedIndex);
    this.props.setPaymentDetailsIndex(selectedDtlIndex);
  }

  componentDidMount() {
    const paymentDetailsIndex = this.props.paymentDetailsIndex;
    const { billingPaymentDtlsList, billingPaymentlist } = this.props;
    this.setState({
      selectedIndex: this.props.index,
      selectedDtlIndex: paymentDetailsIndex,
      paymentEntryVo: billingPaymentlist[this.props.index],
      paymentDetailsVo: billingPaymentDtlsList[paymentDetailsIndex],
    });
    const { loginProfile } = this.props;
    const MBRIDLIT = loginProfile.filter((data) => data.label === "MBRIDLIT");
    this.setState({
      mbridLit: MBRIDLIT[0],
    });
  }
  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.selectedVo) {
      if (prevState.paymentEntryVo) {
        if (
          !(
            nextProps.selectedVo.customerId ===
              prevState.paymentEntryVo.customerId &&
            nextProps.selectedVo.paySource ===
              prevState.paymentEntryVo.paySource &&
            nextProps.selectedVo.batchDate ===
              prevState.paymentEntryVo.batchDate &&
            nextProps.selectedVo.batchSeqNbr ===
              prevState.paymentEntryVo.batchSeqNbr
          )
        ) {
          return {
            paymentEntryVo: nextProps.selectedVo,
            paymentDetailsVo: nextProps.billingPaymentDtlsList[0],
            paymentDetailsList: nextProps.billingPaymentDtlsList,
            selectedIndex: nextProps.index,
            selectedDtlIndex: 0,
            editable: false,
          };
        }
      } else {
        return {
          paymentEntryVo: nextProps.selectedVo,
          paymentDetailsList: nextProps.billingPaymentDtlsList,
          paymentDetailsVo: nextProps.billingPaymentDtlsList[0],
          selectedIndex: nextProps.index,
          selectedDtlIndex: 0,
          editable: false,
        };
      }
    }if(nextProps.billingPaymentDtlsList!=prevState.paymentDetailsList){
     return{
      paymentDetailsList: nextProps.billingPaymentDtlsList,
     }
    }
    return null;
  }
  modalClosed = () => {
    this.setState({ closePopup: false });
  };

  paymentDetailsSearch = async () => {
    let payload = {
      ...this.state.paymentEntryVo,
    };
    await this.props.getPaymentDetail(payload);
    await this.setState({
      selectedDtlIndex: 0,
      paymentDetailsList: this.props.billingPaymentDtlsList,
      paymentDetailsVo: this.props.billingPaymentDtlsList[0],
    });
  };
  selectDetailsRow = (index, selectedVo, rowsPerPage) => {
    this.setState(() => ({
      paymentDetailsVo: {
        ...selectedVo,
      },
      editableDtls: false,
      selectedDtlIndex: index,
      rowsPerPage: rowsPerPage,
    }));
  };
  handleNumber = (targetVo) => (e) => {
    let name = e.target.name;
    let value = e.target.value.replace(/[^0-9]/g, "");
    this.setState((prevState) => ({
      [targetVo]: {
        ...prevState[targetVo],
        [name]: value,
      },
    }));
  };
  handleDecimalChange = (targetVo) => (event) => {
    let name = event.target.name;
    let value = event.target.value.replace(/[^0-9]/g, ".");
    this.setState((prevState) => ({
      [targetVo]: {
        ...prevState[targetVo],
        [name]: value,
      },
      modified: true,
    }));
  };
  selectedRow = async (index) => {
    const data = this.state.data;
    const selectedVo = data[index];
    await this.setState(() => ({
      paymentEntryVo: {
        ...selectedVo,
      },
      dynamicIndex: index,
    }));
  };
  setdataVal = async (name, value, payObj, index) => {
    let tempArr = JSON.parse(JSON.stringify(this.state.newAddPaymentarr));
    if (name === "checkNbr") {
      tempArr[index][name] = value.replace(/[^0-9]/g, "");
    } else if (name === "paymentAmt") {
      tempArr[index][name] = value.replace(/[^0-9]/g, ".");
    } else {
      tempArr[index][name] = value;
    }
    this.setState({
      newAddPaymentarr: tempArr,
    });
  };

  handlechange = (targetVo) => (event) => {
    let name = event.target.name;
   
      let value = event.target.value.toUpperCase();
      this.setState((prevState) => ({
        [targetVo]: {
          ...prevState[targetVo],
          [name]: value,
        },
      }));
    
    
  };
  handleRowchange = (e) => {
    let name = e.target.name;
    let value = e.target.value.replace(/[^0-9]/g, "");
    this.setState({ [name]: value });
  };
  handleChangeSearchSelectAuto = (data, name) => {
    let value = data.value;
    this.setState((prevState) => ({
      paymentEntryVo: {
        ...prevState.paymentEntryVo,
        [name]: value,
      },
      modified: true,
    }));
  };
  newSegment = async () => {
    this.props.setHideFlag(true);
    this.setState({
      isNewSegment: true,
      rows: 0,
      rowCount: 0,
    });
    this.validator.hideMessages();
    await this.setBatchDate();
  };
  setBatchDate = () => {
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1;
    var yyyy = today.getFullYear();
    if (dd < 10) {
      dd = "0" + dd;
    }

    if (mm < 10) {
      mm = "0" + mm;
    }
    today = mm + "/" + dd + "/" + yyyy;
    this.setState((prevState) => ({
      newPaymentdata: {
        ...prevState.newPaymentdata,
        batchDate: today,
        paySource: "M",
        paySourceDesc: "Manual",
        bankAcntCd: this.props.bankAcntCd,
        batchBalInd: "N",
        batchPostedInd: "N",
      },
    }));
  };
  addPaymentDtls = async () => {
    if (this.state.paymentEntryVo.batchPostedInd === "Y") {
      this.setState({
        closePopup: true,
        message: "Batch Payment has already been posted.",
        reset: false,
      });
      return false;
    } else {
      this.props.setHideFlag(true);
      this.validator.hideMessages();
      await this.setState({
        addDtls: true,
        rows: 0,
        rowCount: 0,
      });
    }
  };
  cancel = () => {
    this.props.setHideFlag(false);
    this.setState({
      newAddPaymentarr: [],
      newPaymentdata: NEWPAYMENT_DETAILS_DATA,
      isNewSegment: false,
      addDtls: false,
    });
  };
  updateFlag = () => {
    if (this.state.paymentEntryVo.batchPostedInd === "Y") {
      this.setState({
        closePopup: true,
        message: "Batch Payment has already been posted.",
        reset: false,
      });
      return false;
    } else {
      this.setState({ editable: true, editableDtls: false });
    }
  };
  updateDetailsCheck = () => {
    if (this.state.paymentDetailsVo.paymentPostedInd === "Y") {
      this.setState({
        closePopup: true,
        message: "Payment has already been posted.",
        reset: false,
      });
      return false;
    } else {
      this.setState({ editableDtls: true, editable: false });
    }
  };
  updateHeader = () => {
    if (this.validator.allValid()) {
      ConfirmBox(this.updatePaymentHeader, Type.UPDATE, this.props);
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };
  updatePaymentHeader = async () => {
    let status = await this.props.paymentHeaderUpdate(
      this.state.paymentEntryVo,
      this.state.selectedIndex
    );
    if (status === "success") {
      status = messages.UPDATED_SUCCESSFULLY;
      await this.setState({
        editable: false,
      });
    }
    this.setState({
      closePopup: true,
      message: status,
      reset: false,
    });
  };
  handleOnBlur = (targetVo) => (event) => {
    let value = event.target.value.trim();
    let name = event.target.name;
    this.setState((prevState) => ({
      [targetVo]: {
        ...prevState[targetVo],
        [name]: value.toUpperCase(),
      },
      modified: true,
    }));
  };
  handleDates = (event) => {
    let fieldId = "#" + event.target.name;
    var self = this;

    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        if (
          dateChk.name !== e.target.name ||
          dateChk.value !== e.target.value
        ) {
          self.setDate(e.target.name, e.target.value);
        }
        dateChk.name = e.target.name;
        dateChk.value = e.target.value;
      });
  };

  setDate = (name, value) => {
    this.setState((prevState) => ({
      paymentDetailsVo: {
        ...prevState.paymentDetailsVo,
        [name]: value,
      },
      modified: true,
    }));
  };
  handleDate = (event) => {
    let value = event.target.value;
    let name = event.target.name;
    this.setState((prevState) => ({
      paymentDetailsVo: {
        ...prevState.paymentDetailsVo,
        [name]: handleDateChange(value),
      },
      modified: true,
    }));
  };
  setPaymentEntryDtlList = async () => {
    await this.setState({
      paymentDetailsList: this.props.billingPaymentDtlsList,
    });
  };
  deleteRow = async () => {
    var updatedArr = this.state.newAddPaymentarr;
    var newArray = updatedArr.filter(function (el) {
      return el.del === "N" || el.del === "";
    });
    await this.setState({
      newAddPaymentarr: newArray,
      rowCount: newArray.length,
    });
  };
  addPaymentDetail = async (event) => {
    event.preventDefault();
    this.validator.hideMessages();
    var rows = this.state.rows;
    var initArr = [];
    for (var i = 0; i < rows; i++) {
      initArr.push({
        del: "",
        memberId: "",
        checkDate: "",
        checkNbr: "",
        paymentAmt: "",
      });
    }
    if (initArr.length > 0) {
      await this.setState({
        newAddPaymentarr: [...this.state.newAddPaymentarr, ...initArr],
      });
    }
    await this.setState({ rowCount: this.state.newAddPaymentarr.length });
  };
  updatenewPayment = () => {
    if (this.validator.allValid()) {
      ConfirmBox(this.updatenewPaymentDetails, Type.UPDATE, this.props);
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };
  updatenewPaymentDetails = async () => {
    await this.deleteRow();
    let data = {
      searchVO: { ...this.props.entrySearchVo },
      billPaymentsHeader: { ...this.state.newPaymentdata },
      billPaymentsDtlsList: [...this.state.newAddPaymentarr],
    };
    let stat = await this.props.newPaymentEntry(data);
    this.setState({ editable: false });

    if (stat.status === "OK") {
      stat.status = messages.UPDATED_SUCCESSFULLY;
      this.setState({
        editable: false,
        closePopup: true,
        message: stat.status,
        reset: false,
      });
      this.cancel();
    } else {
      this.setState({
        editable: true,
        closePopup: true,
        message: stat.status,
        reset: false,
      });
    }
  };
  handleCheckBox = async (index, val) => {
    let value = val === "Y" ? "N" : "Y";

    let data = [this.state.newAddPaymentarr];
    data[index].checked = value;
  };
  updateaddPayment = () => {
    if (this.state.newAddPaymentarr.length > 0) {
      if (this.validator.allValid()) {
        ConfirmBox(this.updateaddPaymentDtls, Type.UPDATE, this.props);
      } else {
        this.validator.showMessages();
        this.forceUpdate();
      }
    }
  };
  updateaddPaymentDtls = async () => {
    await this.deleteRow();
    let data = {
      searchVO: { ...this.props.entrySearchVo },
      billPaymentsHeader: { ...this.state.paymentEntryVo },
      billPaymentsDtlsList: [...this.state.newAddPaymentarr],
    };

    let addresult = await this.props.addPaymentdetails(data);
    if (addresult.status === "OK") {
      addresult.status = messages.UPDATED_SUCCESSFULLY;
      this.setState({
        editable: false,
        closePopup: true,
        message: addresult.status,
        reset: false,
      });
      this.cancel();
    } else {
      addresult.status = addresult.message;
      this.setState({
        editable: true,
        closePopup: true,
        message: addresult.status,
        reset: false,
      });
    }
  };
  updateDetails = () => {
    if(isEmpty(this.state.paymentDetailsVo.checkDate)){
      alert("Please enter the check Date")
    }
    else{
      if (this.validator.allValid()) {
       if(this.props.billingPaymentDtlsList[0].memberId!=this.state.paymentDetailsVo.memberId ||
          this.props.billingPaymentDtlsList[0].checkNbr!=this.state.paymentDetailsVo.checkNbr ||
          this.props.billingPaymentDtlsList[0].paymentAmt!=this.state.paymentDetailsVo.paymentAmt ||
          this.props.billingPaymentDtlsList[0].checkDate!=this.state.paymentDetailsVo.checkDate){
          alert("Invalid Invoice Id in Payment Details Update")
        }
        else
            ConfirmBox(this.updatePaymentDtls, Type.UPDATE, this.props);
      } else {
        this.validator.showMessages();
        this.forceUpdate();
      }
    }
    
  };

  updatePaymentDtls = async () => {
    let data = {
      billPaymentsHeader: { ...this.state.paymentEntryVo },
      bilPaymentEntryDtlsVO: { ...this.state.paymentDetailsVo },
    };
    let result = await this.props.paymentDetailsUpdate(data);
    if (result.status === "OK") {
      result.status = messages.UPDATED_SUCCESSFULLY;
      this.setState({
        closePopup: true,
        message: result.status,
        reset: false,
        editableDtls: false,
        paymentDetailsVo: this.props.billingPaymentDtlsList[
          this.state.selectedDtlIndex
        ],
        paymentEntryVo: this.props.billingPaymentlist[this.props.index],
      });
      this.setPaymentEntryDtlList();
    } else {
      result.status = result.message;
      this.setState({
        closePopup: true,
        message: result.status,
        reset: false,
        editableDtls: true,
      });
    }
  };
  handleChangeRowsPerPage = async (rowsPerPage) => {
    await this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  render() {
    const {
      classes,
      flag,
      billingPaymentlist,
      billingPaymentDtlsList,
      servicesEnabled,
    } = this.props;
    const {
      editable,
      editableDtls,
      addDtls,
      isNewSegment,
      paymentEntryVo,
      newPaymentdata,
      newAddPaymentarr,
      paymentDetailsVo,
      rows,
      mbridLit,
      message,
      closePopup,
      collapseSearch,
      rowCount,
      dynamicIndex,
      paymentDetailsList,
      selectedDtlIndex,
      invpage,
      selectedInvIndex,
    } = this.state;
    return (
      <React.Fragment>
        <Modal
          dialogTitle="Payment Entry"
          message={message}
          show={closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Paper elevation={0} className={classes.card}>
          {!isNewSegment && !addDtls ? (
            <div class="search-panel">
              <div className={classes.buttonContainer}>
                {!isEmpty(billingPaymentDtlsList) ? (
                  <div>
                    {servicesEnabled.includes("EEUB") ? (
                      <Button
                        variant="contained"
                        color="primary"
                        className={classes.buttonFitToText}
                        onClick={
                          editable !== true
                            ? this.updateFlag
                            : this.updateHeader
                        }
                      >
                        {editable !== true ? "Update" : "Save Details"}
                      </Button>
                    ) : null}
                  </div>
                ) : null}

                {servicesEnabled.includes("EEUB") ? (
                  <Button
                    variant="contained"
                    color="primary"
                    className={classes.buttonFitToText}
                    onClick={this.newSegment}
                  >
                    New Payment
                  </Button>
                ) : null}
              </div>
            </div>
          ) : null}

          {!isEmpty(billingPaymentDtlsList) && paymentEntryVo ? (
            <div class="panel-subhead">
              <h3>Payment Header Details</h3>
            </div>
          ) : null}
          {(!isEmpty(billingPaymentlist) && paymentEntryVo) || isNewSegment ? (
            <div class="panel-body">
              <div className={classes.containertypography}>
                <div>
                  <InputField
                    name="paySourceDesc"
                    label="Payment Source"
                    className={classes.textField}
                    value={
                      !isNewSegment
                        ? paymentEntryVo.paySourceDesc
                        : newPaymentdata.paySourceDesc
                    }
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="batchDate"
                    placeholder="MM/DD/YYYY"
                    label="Batch Date"
                    className={classes.textField}
                    value={
                      !isNewSegment
                        ? paymentEntryVo.batchDate
                        : newPaymentdata.batchDate
                    }
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="batchSeqNbr"
                    label="Batch Seq Nbr"
                    className={classes.textField}
                    value={
                      !isNewSegment
                        ? paymentEntryVo.batchSeqNbr
                        : newPaymentdata.batchSeqNbr
                    }
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="bankAcntCd"
                    label="Bank Account Cd:"
                    className={classes.textField}
                    value={
                      !isNewSegment
                        ? paymentEntryVo.bankAcntCd
                        : newPaymentdata.bankAcntCd
                    }
                    maxLength={4}
                    onChange={this.handlechange(
                      !isNewSegment ? "paymentEntryVo" : "newPaymentdata"
                    )}
                    onBlur={this.handleOnBlur(
                      !isNewSegment ? "paymentEntryVo" : "newPaymentdata"
                    )}
                    disabled={isNewSegment ? false : true}
                  />
                  {!isNewSegment ? (
                    <div className={classes.validationMessage}>
                      {this.validator.message(
                        "Bank Account Cd",
                        paymentEntryVo.bankAcntCd,
                        "required"
                      )}
                    </div>
                  ) : (
                    <div className={classes.validationMessage}>
                      {this.validator.message(
                        "Bank Account Cd",
                        [0, newPaymentdata.bankAcntCd],
                        "required"
                      )}
                    </div>
                  )}
                </div>
                <div>
                  <InputField
                    name="batchBalance"
                    label="Batch Balance Amt:"
                    className={classes.textField}
                    value={
                      !isNewSegment
                        ? paymentEntryVo.batchBalance
                        : newPaymentdata.batchBalance
                    }
                    maxLength={14}
                    onChange={this.handleDecimalChange(
                      !isNewSegment ? "paymentEntryVo" : "newPaymentdata"
                    )}
                    disabled={isNewSegment ? false : addDtls ? true : !editable}
                    onBlur={this.handleOnBlur(
                      !isNewSegment ? "paymentEntryVo" : "newPaymentdata"
                    )}
                  />
                  {!isNewSegment ? (
                    <div className={classes.validationMessage}>
                      {this.validator.message(
                        "Batch Balance Amt",
                        paymentEntryVo.batchBalance,
                        "required|amountValidator"
                      )}
                    </div>
                  ) : (
                    <div className={classes.validationMessage}>
                      {this.validator.message(
                        "Batch Balance Amt",
                        newPaymentdata.batchBalance,
                        "required|amountValidator"
                      )}
                    </div>
                  )}
                </div>

                <div>
                  <InputField
                    name="detailAmount"
                    label="Detail Total Amt:"
                    className={classes.textField}
                    value={
                      !isNewSegment
                        ? paymentEntryVo.detailAmount
                        : newPaymentdata.detailAmount
                    }
                    disabled
                    onChange={this.handlechange(
                      !isNewSegment ? "paymentEntryVo" : "newPaymentdata"
                    )}
                    onBlur={this.handleOnBlur(
                      !isNewSegment ? "paymentEntryVo" : "newPaymentdata"
                    )}
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="batchBalInd"
                    label="Batch Balance Ind"
                    className={classes.textField}
                    value={
                      !isNewSegment
                        ? paymentEntryVo.batchBalInd
                        : newPaymentdata.batchBalInd
                    }
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="batchPostedInd"
                    label="Batch Posted Ind"
                    className={classes.textField}
                    value={
                      !isNewSegment
                        ? paymentEntryVo.batchPostedInd
                        : newPaymentdata.batchPostedInd
                    }
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="batchDtlCount"
                    label="Batch Detail Cnt"
                    className={classes.textField}
                    value={
                      !isNewSegment
                        ? paymentEntryVo.batchDtlCount
                        : newPaymentdata.batchDtlCount
                    }
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
              </div>
              {!isNewSegment ? (
                <HistoryData
                  createUserId={paymentEntryVo.createUser}
                  createTime={paymentEntryVo.createTime}
                  lastUpdtTime={paymentEntryVo.modifiedTime}
                  lastUpdtUserId={paymentEntryVo.modifiedUser}
                />
              ) : null}
            </div>
          ) : null}
          {isNewSegment || addDtls ? (
            <ExpansionPanel
              summary="Payment Details "
              defaultCollapsed={collapseSearch}
            >
              <ExpansionPanelDetails>
                <span
                  class="button-container-search"
                  className={classes.alignButton}
                >
                  <form onSubmit={this.addPaymentDetail}>
                    <InputField
                      name="rows"
                      className={classes.textField}
                      maxLength={2}
                      value={rows}
                      onChange={this.handleRowchange}
                    />
                    <button
                      type="submit"
                      class="btn btn-secondary"
                      disabled={rows > 0 ? false : true}
                    >
                      Add Row
                    </button>

                    <button
                      type="button"
                      class="btn btn-secondary"
                      onClick={this.deleteRow}
                    >
                      Delete
                    </button>
                  </form>
                </span>

                {newAddPaymentarr ? (
                  <BillingDataTable
                    data={newAddPaymentarr}
                    selectedVo={this.props.selectedVo}
                    header={ADDPAYMENT_DETAILS_HEADER}
                    rowcount={rowCount}
                    click={this.selectedRow}
                    index={dynamicIndex}
                    setdataVal={this.setdataVal}
                    handleCheckBox={this.handleCheckBox}
                    validator={this.validator}
                    validationMessage={classes.validationMessage}
                  />
                ) : null}

                <span
                  class="button-container-search"
                  className={classes.alignButton}
                >
                  <button
                    type="button"
                    class="btn btn-secondary"
                    onClick={
                      !addDtls ? this.updatenewPayment : this.updateaddPayment
                    }
                  >
                    Update
                  </button>
                  <button
                    type="button"
                    class="btn btn-secondary"
                    onClick={this.cancel}
                  >
                    Cancel
                  </button>
                </span>
              </ExpansionPanelDetails>
            </ExpansionPanel>
          ) : null}

          {!addDtls && !isNewSegment && !isEmpty(billingPaymentlist) ? (
            <div class="search-panel">
              <ExpansionPanel
                summary="Payment Details"
                defaultCollapsed={collapseSearch}
              >
                <ExpansionPanelDetails>
                  {paymentEntryVo ? (
                    <div className={classes.containertypography}>
                      <div>
                        <InputField
                          name="itemNbr"
                          label="Item Nbr"
                          className={classes.textField}
                          value={paymentEntryVo.itemNbr}
                          onChange={this.handleNumber("paymentEntryVo")}
                        />

                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <InputField
                          name="memberId"
                          label={
                            mbridLit.value === "TSA" ? "Wipro ID" : "M360 ID"
                          }
                          className={classes.textField}
                          value={paymentEntryVo.memberId}
                          onChange={this.handlechange("paymentEntryVo")}
                          onBlur={this.handleOnBlur("paymentEntryVo")}
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <div>
                        <AutoComplete1
                          fontSize="0.718em"
                          margin="0px"
                          options={POSTED_IND}
                          handleChange={this.handleChangeSearchSelectAuto}
                          defaultValue={{
                            label: "Select",
                            value: "",
                          }}
                          value={
                            POSTED_IND.filter(
                              (option) =>
                                option.value === paymentEntryVo.paymentPostedInd
                            )[0]
                          }
                          label="Posted"
                          name="paymentPostedInd"
                        />
                        <div className={classes.validationMessage} />
                      </div>
                      <span
                        class="button-container-search "
                        className={classes.expansionPanelbuttons}
                      >
                        <button
                          type="button"
                          class="btn btn-primary icon-search"
                          onClick={this.paymentDetailsSearch}
                        >
                          Search
                        </button>
                      </span>
                    </div>
                  ) : null}
                  <DataTable
                    data={paymentDetailsList ? paymentDetailsList : []}
                    header={PAYMENT_ITEM_HEADER}
                    rowsPerPage={5}
                    sortableHeader={true}
                    clicked={this.selectDetailsRow}
                    index={selectedDtlIndex}
                    handleChangeRowsPerPage={this.handleChangeRowsPerPage}
                    flag={flag}
                  />

                  <div className={classes.buttonContainer}>
                    {!isEmpty(billingPaymentDtlsList) ? (
                      <div>
                        {servicesEnabled.includes("EEUB") ? (
                          <Button
                            variant="contained"
                            color="primary"
                            className={classes.buttonFitToText}
                            onClick={
                              !editableDtls
                                ? this.updateDetailsCheck
                                : this.updateDetails
                            }
                          >
                            {!editableDtls ? "Update" : "Save Details"}
                          </Button>
                        ) : null}
                      </div>
                    ) : null}
                    {servicesEnabled.includes("EEUB") ? (
                      <Button
                        variant="contained"
                        color="primary"
                        className={classes.buttonFitToText}
                        onClick={this.addPaymentDtls}
                      >
                        Add Payment Detail
                      </Button>
                    ) : null}
                  </div>
                </ExpansionPanelDetails>
              </ExpansionPanel>
            </div>
          ) : null}
          {!addDtls &&
          !isNewSegment &&
          !isEmpty(billingPaymentDtlsList) &&
          paymentDetailsVo ? (
            <div class="panel-body">
              <div className={classes.containertypography}>
                <div>
                  <InputField
                    id="pmtDtlItemNbr"
                    name="itemNbr"
                    label="Item Nbr"
                    className={classes.textField}
                    value={paymentDetailsVo.itemNbr}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="memberId"
                    label="Invoice ID"
                    className={classes.textField}
                    value={paymentDetailsVo.memberId}
                    disabled={!editableDtls}
                    onChange={this.handlechange("paymentDetailsVo")}
                    maxLength={15}
                    onBlur={this.handleOnBlur("paymentDetailsVo")}
                  />
                  <div className={classes.validationMessage}>
                    {this.validator.message(
                      "Invoice ID",
                      paymentDetailsVo.memberId,
                      "required"
                    )}
                  </div>
                </div>

                <div>
                  <InputField
                    name="invoiceDueDate"
                    placeholder="MM/DD/YYYY"
                    label="Invoice Due Date"
                    className={classes.textField}
                    value={paymentDetailsVo.invoiceDueDate}
                    onClick={this.handleDates}
                    onChange={this.handleDate}
                    onBlur={this.handleOnBlur("paymentDetailsVo")}
                    maxLength={10}
                    disabled={!editableDtls}
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="paymentPostedInd"
                    label="Payment Posted Ind:"
                    className={classes.textField}
                    value={paymentDetailsVo.paymentPostedInd}
                    onChange={this.handlechange("paymentDetailsVo")}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="checkDate"
                    placeholder="MM/DD/YYYY"
                    label="Check Date"
                    className={classes.textField}
                    value={paymentDetailsVo.checkDate}
                    disabled={!editableDtls}
                    onClick={this.handleDates}
                    onChange={this.handleDate}
                    onBlur={this.handleOnBlur("paymentDetailsVo")}
                    maxLength={10}
                  />
                  <div className={classes.validationMessage}>
                    {this.validator.message(
                      "Check Date",
                      paymentDetailsVo.checkDate,
                      "required"
                    )}
                    {this.validator.message(
                      "Check Date",
                      paymentDetailsVo.checkDate,
                      "date_format"
                    )}
                  </div>
                </div>
                <div>
                  <InputField
                    name="checkNbr"
                    label="Check Nbr"
                    className={classes.textField}
                    value={paymentDetailsVo.checkNbr}
                    disabled={!editableDtls}
                    onChange={this.handlechange("paymentDetailsVo")}
                    maxLength={12}
                    onBlur={this.handleOnBlur("paymentDetailsVo")}
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="paymentAmt"
                    label="Payment Amt"
                    className={classes.textField}
                    value={paymentDetailsVo.paymentAmt}
                    disabled={!editableDtls}
                    maxLength={10}
                    onChange={this.handleDecimalChange("paymentDetailsVo")}
                    onBlur={this.handleOnBlur("paymentDetailsVo")}
                  />
                  <div className={classes.validationMessage}>
                    {this.validator.message(
                      "Payment Amt",
                      paymentDetailsVo.paymentAmt,
                      "required|amountValidator"
                    )}
                  </div>
                </div>
              </div>
              <HistoryData
                createUserId={paymentDetailsVo.createUserId}
                createTime={paymentDetailsVo.createTime}
                lastUpdtTime={paymentDetailsVo.lastUpdtTime}
                lastUpdtUserId={paymentDetailsVo.lastUpdtUserId}
              />
              <DataTable
                data={
                  paymentDetailsVo.billingInvoiceList
                    ? paymentDetailsVo.billingInvoiceList
                    : []
                }
                header={PAYMENT_INVOICE_HEADER}
                rowsPerPage={5}
                sortableHeader={true}
                clicked={this.selectInvRow}
                removePagination="true"
                index={selectedInvIndex}
                pageNo={invpage}
              />
            </div>
          ) : null}
        </Paper>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    billingPaymentlist:
      state.billingReducer.paymentEntry.paymentEntrySearchResults
        .billingPaymentslist,
    billingPaymentDtlsList:
      state.billingReducer.paymentEntry.paymentEntrySearchResults
        .billingPaymentDtlsList,
    dropdowns: state.billingReducer.billingPaymentcache.payTypesList,
    bankAcntCd: state.billingReducer.bilingCacheData.bankAcctCd,
    paymentHeaderIndex:
      state.billingReducer.paymentEntry.tableIndexes.paymentHeaderIndex,
    paymentDetailsIndex:
      state.billingReducer.paymentEntry.tableIndexes.paymentDetailsIndex,
    servicesEnabled: state.loginData.servicesEnabled,
    loginProfile: state.loginData.profiles,
  };
};
const mapDispatchToProps = {
  getBillingPaymentCache,
  getPaymentEntrySearch,
  getPaymentDetail,
  newPaymentEntry,
  paymentHeaderUpdate,
  addPaymentdetails,
  paymentDetailsUpdate,
  setPaymentHeaderIndex,
  setPaymentDetailsIndex,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(BillingPaymentSearch));
