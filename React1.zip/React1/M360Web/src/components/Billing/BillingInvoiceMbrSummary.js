import React from "react";
import ExpansionPanel from "../UI/ExpansionPanel";
import InputField from "../UI/InputField";
import { Styles } from "../../assets/styles/Theme";
import { withStyles } from "@material-ui/core/styles";
import { connect } from "react-redux";

const InvoiceMemberSummary = (props) => {
  const { invoiceMbrSummary, classes, loginProfile } = props;

  const MBRIDLIT = loginProfile.filter((data) => data.label === "MBRIDLIT");

  const mbrIdLit = MBRIDLIT[0];
  return (
    <ExpansionPanel summary="Member Summary">
      <div class="panel-body" className={classes.panelBody}>
        <div className={classes.container}>
          <div className={classes.invoiceHeaderDiv}>
            <InputField
              width="215px"
              name="memberId"
              label={mbrIdLit.value === "TSA" ? "Wipro ID" : "M360 ID"}
              value={invoiceMbrSummary.memberId}
              disabled
            />
          </div>
          <div className={classes.invoiceHeaderDiv}>
            <InputField
              width="215px"
              name="firstName"
              label="Name"
              value={invoiceMbrSummary.name}
              disabled
            />
          </div>
          <div className={classes.invoiceHeaderDiv}>
            <InputField
              width="215px"
              name="medicareId"
              label="Medicare ID"
              value={invoiceMbrSummary.hicNbr}
              disabled
            />
          </div>
          <div className={classes.invoiceHeaderDiv}>
            <InputField
              width="215px"
              name="invoiceAmt"
              label="Invoice"
              value={invoiceMbrSummary.invoiceAmt}
              disabled
            />
          </div>
          <div className={classes.invoiceHeaderDiv}>
            <InputField
              width="215px"
              name="adjustmentAmt"
              label="Adjustments"
              value={invoiceMbrSummary.adjustmentAmt}
              disabled
            />
          </div>
          <div className={classes.invoiceHeaderDiv}>
            <InputField
              width="215px"
              name="paymentAmt"
              label="Payments"
              value={invoiceMbrSummary.paymentAmt}
              disabled
            />
          </div>
          <div className={classes.invoiceHeaderDiv}>
            <InputField
              width="215px"
              name="totalAmt"
              label="Total Due"
              value={invoiceMbrSummary.totalAmt}
              disabled
            />
          </div>
        </div>
      </div>
    </ExpansionPanel>
  );
};

const mapStateToProps = (state) => {
  return {
    invoiceMbrSummary:
      state.billingReducer.invoice.invoiceSearchResults.billingInvSummary,
    loginProfile: state.loginData.profiles,
  };
};

const mapDispatchToProps = {};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(InvoiceMemberSummary));
