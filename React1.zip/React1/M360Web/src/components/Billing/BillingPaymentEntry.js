import MuiExpansionPanelDetails from "@material-ui/core/ExpansionPanelDetails";
import Paper from "@material-ui/core/Paper";
import { withStyles } from "@material-ui/core/styles";
import React, { Component } from "react";
import { connect } from "react-redux";
import { Styles } from "../../assets/styles/Theme";
import { BALANCE_LIST } from "../../constants/BillingInitialState";
import {
  getBillingPaymentCache,
  getPaymentEntrySearch,
  getPaymentDetail,
  setPaymentHeaderIndex,
  paymentEntrySearchNext,
} from "../../redux/actions/BillingActions";
import { handleDateChange } from "../../utils/DateFormatter";
import ExpansionPanel from "../UI/ExpansionPanel";
import InputField from "../UI/InputField";
import AutoComplete1 from "../UI/Select";
import * as DateUtil from "../../utils/DatePicker";
import BillingPaymentSearch from "./BillingPaymentSearchRes";
import DataTable from "../Home/DataTable";
import { PAYMENT_ENTRY_HEADER } from "../../constants/Headers/BillingHeaders";
import { customValidations } from "../../utils/CustomValidations";
import SimpleReactValidator from "simple-react-validator";
import isEmpty from "lodash/isEmpty";

const INITAL_STATE = {
  paySource: "",
  batchDate: "",
  batchSeqNbr: "",
  batchBalance: "",
};
let dateChk = {};
const ExpansionPanelDetails = withStyles((theme) => ({
  root: {
    padding: theme.spacing.unit * 2,
    display: "block",
  },
}))(MuiExpansionPanelDetails);

class PaymentEntry extends Component {
  constructor(props) {
    super(props);
    this.state = {
      entrySearchVo: { ...INITAL_STATE },
      paymentEntryVo: this.props.billingPaymentlist[0],
      rows: 0,
      selectedIndex: this.props.paymentHeaderIndex
        ? this.props.paymentHeaderIndex
        : 0,
      rowId: 0,
      isNewSegment: false,
      flag: false,
      rowsPerPage: 10,
      searchFlag: false,
      resetFlag: true,
    };
    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
      },
    });
  }
  componentWillUnmount() {
    const { selectedIndex } = this.state;
    this.props.setPaymentHeaderIndex(selectedIndex);
  }

  componentDidMount() {
    const paymentHeaderIndex = this.props.paymentHeaderIndex;
    this.setState({
      selectedIndex: paymentHeaderIndex,
      paymentEntryVo: this.props.billingPaymentlist[paymentHeaderIndex],
    });
  }
  static getDerivedStateFromProps(nextProps, prevState) {
    if (
      prevState.searchFlag === false &&
      nextProps.billingPaymentlist.length > 0
    ) {
      return { searchFlag: true };
    }
  }
  row = async (rowindex) => {
    await this.setState({
      rowId: rowindex,
    });
  };

  handlechange = (name) => (event) => {
    let value = event.target.value.toUpperCase();
    this.setState((prevState) => ({
      entrySearchVo: {
        ...prevState.entrySearchVo,
        [name]: value,
      },
    }));
  };
  handleChangeSearchSelectAuto = (data, name) => {
    let value = data.value;
    this.setState((prevState) => ({
      entrySearchVo: {
        ...prevState.entrySearchVo,
        [name]: value,
      },
      modified: true,
    }));
  };
  handleDate = (event) => {
    let name = event.target.name;
    let value = event.target.value;
    this.setState((prevState) => ({
      entrySearchVo: {
        ...prevState.entrySearchVo,
        [name]: handleDateChange(value),
      },
      modified: true,
    }));
  };
  handleDates = (event) => {
    let fieldId = "#" + event.target.name;
    var self = this;

    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        if (
          dateChk.name !== e.target.name ||
          dateChk.value !== e.target.value
        ) {
          self.setDate(e.target.name, e.target.value);
          document.getElementById(fieldId.substr(1)).focus();
        }
        dateChk.name = e.target.name;
        dateChk.value = e.target.value;
      });
  };
  setDate = (name, value) => {
    this.setState((prevState) => ({
      entrySearchVo: {
        ...prevState.entrySearchVo,
        [name]: value,
      },
      modified: true,
    }));
  };
  handleOnBlur = (event) => {
    let value = event.target.value.trim();
    let name = event.target.name;
    this.setState((prevState) => ({
      entrySearchVo: {
        ...prevState.entrySearchVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  paymentSearch = async (event) => {
    event.preventDefault();
    if (this.validator.allValid()) {
      this.setState({ flag: true });
      await this.props.getPaymentEntrySearch(this.state.entrySearchVo);
      this.setState({
        searchFlag: true,
        flag: false,
        paymentEntryVo: this.props.billingPaymentlist[0],
        billingSearchDtlsData: this.props.billingPaymentDtlsList,
        resetFlag: true,
      });
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };
  selectRow = async (index, selectedVo, rowsPerPage) => {
    await this.props.getPaymentDetail(selectedVo);
    await this.setState(() => ({
      paymentEntryVo: {
        ...selectedVo,
      },
      editable: false,
      selectedIndex: index,
      rowsPerPage: rowsPerPage,
    }));
  };
  handleChangeRowsPerPage = async (rowsPerPage) => {
    await this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };
  setHideFlag = async (flag) => {
    await this.setState({
      isNewSegment: flag,
    });
  };
  reset = () => {
    this.setState({ entrySearchVo: { ...INITAL_STATE }, resetFlag: false });
  };
  handleNumber = (e) => {
    let name = e.target.name;
    let value = e.target.value.replace(/[^0-9]/g, "");
    this.setState((prevState) => ({
      entrySearchVo: {
        ...prevState.entrySearchVo,
        [name]: value,
      },
    }));
  };
  fetchMoreResults = async (pageNo) => {
    const { searchCriteriaVo, billingPaymentlist } = this.props;
    const lastIndex = billingPaymentlist.length - 1;
    const {
      paySource,
      batchDate,
      batchSeqNbr,
      // batchBalance,
    } = billingPaymentlist[lastIndex];

    let payload = {
      ...searchCriteriaVo,
      paySource: paySource,
      batchDate: batchDate,
      batchSeqNbr: batchSeqNbr,
      //batchBalance: batchBalance,
    };
    await this.props.paymentEntrySearchNext(payload);
    this.setState({
      selectedIndex: pageNo * this.state.rowsPerPage,
    });
  };

  render() {
    const { classes, payType, billingPaymentlist, nextPage } = this.props;
    const {
      entrySearchVo,
      isNewSegment,
      searchFlag,
      selectedIndex,
      paymentEntryVo,
      rowsPerPage,
      collapseSearch,
      collapseTableSearch,
      resetFlag,
      flag,
    } = this.state;

    return (
      <Paper elevation={0} className={[classes.card, classes.paperHeight]}>
        {!isNewSegment ? (
          <div class="search-panel">
            <ExpansionPanel summary="Search" defaultCollapsed={collapseSearch}>
              <ExpansionPanelDetails>
                <form onSubmit={this.paymentSearch}>
                  <div className={classes.containertypography}>
                    <div>
                      <InputField
                        name="batchDate"
                        placeholder="MM/DD/YYYY"
                        label="Batch Date:"
                        onClick={this.handleDates}
                        onChange={this.handleDate}
                        onBlur={this.handleOnBlur}
                        value={entrySearchVo.batchDate}
                        maxLength={10}
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "Batch Date",
                          entrySearchVo.batchDate,
                          "date_format"
                        )}
                      </div>
                    </div>
                    <div>
                      <InputField
                        name="batchSeqNbr"
                        InputProps={{ className: classes.textFont }}
                        label="Batch Seq Nbr"
                        className={classes.textField}
                        value={entrySearchVo.batchSeqNbr}
                        maxLength={8}
                        onChange={this.handleNumber}
                        onBlur={this.handleOnBlur}
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <AutoComplete1
                        options={BALANCE_LIST}
                        margin="0px"
                        fontSize="0.718em"
                        handleChange={this.handleChangeSearchSelectAuto}
                        defaultValue={{
                          label: "Select",
                          value: "",
                        }}
                        value={
                          BALANCE_LIST.filter(
                            (option) =>
                              option.value === entrySearchVo.batchBalance
                          )[0]
                        }
                        label="Batch Balance"
                        name="batchBalance"
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <div>
                      <AutoComplete1
                        options={
                          payType
                            ? payType
                            : [
                                {
                                  label: "Select",
                                  value: "",
                                },
                              ]
                        }
                        margin="0px"
                        fontSize="0.718em"
                        handleChange={this.handleChangeSearchSelectAuto}
                        defaultValue={{
                          label: "Select",
                          value: "",
                        }}
                        value={
                          payType
                            ? payType.filter(
                                (option) =>
                                  option.value === entrySearchVo.paySource
                              )[0]
                            : {
                                label: "Select",
                                value: "",
                              }
                        }
                        label="Pay Source Type"
                        name="paySource"
                      />

                      <div className={classes.validationMessage} />
                    </div>
                    <span
                      class="button-container-search"
                      className={classes.expansionPanelbuttons}
                    >
                      <button type="submit" class="btn btn-primary icon-search">
                        Search
                      </button>
                      <button
                        type="button"
                        class="btn btn-secondary"
                        onClick={this.reset}
                      >
                        Reset
                      </button>
                    </span>
                  </div>
                </form>
              </ExpansionPanelDetails>
            </ExpansionPanel>
          </div>
        ) : null}
        {searchFlag && !isNewSegment && !isEmpty(billingPaymentlist) ? (
          <>
            <ExpansionPanel
              summary="Search Results"
              defaultCollapsed={collapseTableSearch}
            >
              <DataTable
                data={isEmpty(billingPaymentlist) ? [] : billingPaymentlist}
                header={PAYMENT_ENTRY_HEADER}
                rowsPerPage={rowsPerPage}
                sortable={true}
                searchable={true}
                exportAsExcel={true}
                clicked={this.selectRow}
                index={selectedIndex}
                rowsPerPageOptions={[5, 10, 15, 20]}
                //flag={flag}
                handleChangeRowsPerPage={this.handleChangeRowsPerPage}
                fetchMore={this.fetchMoreResults}
                nextPage={nextPage}
                dateColumn="batchDate"
              />
            </ExpansionPanel>
          </>
        ) : searchFlag && resetFlag ? (
          <ExpansionPanel
            summary="Search Results"
            defaultCollapsed={collapseTableSearch}
          >
            <DataTable data={[]} header={PAYMENT_ENTRY_HEADER} />
          </ExpansionPanel>
        ) : null}
        <BillingPaymentSearch
          entrySearchVo={entrySearchVo}
          selectedVo={paymentEntryVo}
          row={this.row}
          index={selectedIndex}
          setHideFlag={this.setHideFlag}
          flag={flag}
          searchFlag={searchFlag}
        />
      </Paper>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    payType: state.billingReducer.bilingCacheData.payTypesList,
    bankAcctCd: state.billingReducer.bilingCacheData.bankAcctCd,
    billingPaymentlist:
      state.billingReducer.paymentEntry.paymentEntrySearchResults
        .billingPaymentslist,
    billingPaymentDtlsList:
      state.billingReducer.paymentEntry.paymentEntrySearchResults
        .billingPaymentDtlsList,
    paymentHeaderIndex:
      state.billingReducer.paymentEntry.tableIndexes.paymentHeaderIndex,
    nextPage: state.billingReducer.paymentEntry.nextPage,
    searchCriteriaVo: state.billingReducer.paymentEntry.searchCriteriaVo,
  };
};
const mapDispatchToProps = {
  getBillingPaymentCache,
  getPaymentEntrySearch,
  getPaymentDetail,
  setPaymentHeaderIndex,
  paymentEntrySearchNext,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(PaymentEntry));
