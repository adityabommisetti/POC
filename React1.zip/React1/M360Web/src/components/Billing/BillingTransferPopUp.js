import React, { Component } from "react";
import { INVOICE_MBR_GRP_HEADER as header } from "../../constants/Headers/BillingHeaders";
import Button from "@material-ui/core/Button";
import DataTable from "../Home/DataTable";
import InputField from "../UI/InputField";
import Paper from "@material-ui/core/Paper";
import { Styles } from "../../assets/styles/PopUpStyle";
import classNames from "classnames";
import { connect } from "react-redux";
import { invoiceMbrGrpSearch } from "../../redux/actions/BillingActions";
import { withStyles } from "@material-ui/core/styles";
import isEmpty from "lodash/isEmpty";
import Modal from "../UI/Modal/Modal";

class InvoiceTransferPopUp extends Component {
  constructor(props) {
    super(props);
    const { searchTransGrp } = this.props;
    this.state = {
      selectedVo: {
        searchTransLastName: "",
        searchTransName: "",
        searchTransGrp: searchTransGrp ? searchTransGrp : "",
      },
      message: "",
      closePopUp: false,
      selectedIndex: 0,
      data: null,
      mbridLit: [],
    };
  }

  onRowSelect = (index) => {
    this.setState({
      selectedIndex: index,
    });
    const { data } = this.props;
    const { selectedIndex } = this.state;
    const tableData = [data];
    const updateVo = tableData[selectedIndex];
    this.props.setData(updateVo);
  };

  modalClosed = () => {
    this.setState({ closePopUp: false });
  };

  loadData = async (event) => {
    event.preventDefault();
    const {
      searchTransLastName,
      searchTransName,
      searchTransGrp,
    } = this.state.selectedVo;
    if (
      searchTransLastName === "" &&
      searchTransName === "" &&
      searchTransGrp === ""
    ) {
      this.setState({
        message: "Please provide valid search criteria",
        closePopUp: true,
      });
    } else {
      await this.props.invoiceMbrGrpSearch(this.state.selectedVo);
    }
  };

  componentDidMount() {
    const { selectedVo } = this.state;
    const { searchTransGrp } = selectedVo;
    setTimeout(() => {
      if (searchTransGrp !== "") {
        this.props.invoiceMbrGrpSearch(selectedVo);
      }
    }, 0);
    const { loginProfile } = this.props;
    const MBRIDLIT = loginProfile.filter((data) => data.label === "MBRIDLIT");
    this.setState({
      mbridLit: MBRIDLIT[0],
    });
  }

  onSubmit = () => {
    const { selectedIndex } = this.state;
    const { data } = this.props;
    const tableData = [...data];
    const updateVo = tableData[selectedIndex];
    this.props.setData(updateVo);
    this.props.close();
  };

  reset = () => {
    this.setState(() => ({
      selectedVo: {
        searchTransLastName: "",
        searchTransName: "",
        searchTransGrp: "",
      },
    }));
  };

  handleChange = (event) => {
    const name = event.target.name;
    const value = event.target.value;
    this.setState((prevState) => ({
      selectedVo: {
        ...prevState.selectedVo,
        [name]: value,
      },
    }));
  };

  handleOnBlur = (event) => {
    const name = event.target.name;
    const value = event.target.value;
    this.setState((prevState) => ({
      selectedVo: {
        ...prevState.selectedVo,
        [name]: value,
      },
    }));
  };

  render() {
    const { classes, data } = this.props;
    const { message, closePopUp, selectedVo, selectedIndex, mbridLit } = this.state;
    let dataSet = null;
    if (!isEmpty(data)) {
      dataSet = (
        <div className={classes.table}>
          <DataTable
            data={selectedVo.searchTransGrp !== "" ? data : []}
            header={header}
            rowsPerPage={5}
            sortableHeader={true}
            clicked={this.onRowSelect}
            index={selectedIndex}
          />
          <div className={classes.div1}>
            <Button
              variant="contained"
              color="primary"
              disabled={isEmpty(data)}
              className={classNames(classes.button, classes.submit)}
              onClick={this.onSubmit}
            >
              Submit
            </Button>
          </div>
        </div>
      );
    }

    return (
      <React.Fragment>
        <Modal
          dialogTitle="Group Search"
          message={message}
          show={closePopUp}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Paper
          className={classes.root}
          elevation={0}
          style={{ padding: "15px" }}
        >
          <fieldset className={classes.fieldset}>
            <legend className={classes.legend}>Group Search</legend>
            <form autoComplete="off" onSubmit={this.loadData}>
              <div className={classes.container}>
                <div className={classes.transferPopUpDiv}>
                  <InputField
                    required
                    maxlength={15}
                    label={mbridLit.value === "TSA" ? "Wipro ID" : "M360 ID"}
                    name="searchTransGrp"
                    className={classes.textField}
                    margin="normal"
                    InputLabelProps={{ className: classes.label }}
                    value={selectedVo.searchTransGrp}
                    onChange={this.handleChange}
                    onBlur={this.handleOnBlur}
                  />
                </div>
                <div className={classes.transferPopUpDiv}>
                  <InputField
                    id="firstName"
                    label="First Name"
                    name="searchTransName"
                    className={classes.textField}
                    margin="normal"
                    InputLabelProps={{ className: classes.label }}
                    value={selectedVo.searchTransName}
                    onChange={this.handleChange}
                    onBlur={this.handleOnBlur}
                  />
                </div>
                <div className={classes.transferPopUpDiv}>
                  <InputField
                    id="lastName"
                    name="searchTransLastName"
                    label="Last Name"
                    className={classes.textField}
                    margin="normal"
                    InputLabelProps={{ className: classes.label }}
                    value={selectedVo.searchTransLastName}
                    onChange={this.handleChange}
                    onBlur={this.handleOnBlur}
                  />
                </div>
              </div>
              <div className={classes.div1}>
                <div className={classes.popUpIcons}>
                  <Button
                    type="submit"
                    variant="contained"
                    color="primary"
                    className={classes.button}
                  >
                    <i className="material-icons">search</i>
                  </Button>
                  <Button
                    variant="contained"
                    color="primary"
                    className={classes.button}
                    onClick={this.props.close}
                  >
                    <i className="material-icons">cancel</i>
                  </Button>
                  <Button
                    variant="contained"
                    color="primary"
                    className={classes.button}
                    onClick={this.reset}
                  >
                    <i class="material-icons">refresh</i>
                  </Button>
                </div>
              </div>
            </form>
          </fieldset>
        </Paper>
        {dataSet}
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => ({
  data: state.billingReducer.invoice.mbrGrpSearch,
  loginProfile: state.loginData.profiles,
});

const mapDispatchToProps = {
  invoiceMbrGrpSearch,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(InvoiceTransferPopUp));
