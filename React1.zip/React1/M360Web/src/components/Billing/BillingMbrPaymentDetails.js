import Button from "@material-ui/core/Button";
import Paper from "@material-ui/core/Paper";
import { withStyles } from "@material-ui/core/styles";
import React, { Component } from "react";
import { connect } from "react-redux";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../assets/styles/Theme";
import Modal from "../UI/Modal/Modal";
import * as Type from "../../constants/ConfirmType";
import { MBRPAYMENT_INVOICE_HEADER as paymentHeader } from "../../constants/Headers/BillingHeaders";
import { messages } from "../../constants/Messages";
import {
  getBillingPaymentDetailInvoice,
  updateMbrPayments,
  setMbrPaymentsIndex,
} from "../../redux/actions/BillingActions";
import { handleDateChange } from "../../utils/DateFormatter";
import DataTable from "../Home/DataTable";
import InputField from "../UI/InputField";
import HistoryData from "../UI/MemberHistory";
import ConfirmBox from "../../utils/PopUp";
import * as DateUtil from "../../utils/DatePicker";
import { customValidations } from "../../utils/CustomValidations";
import isEmpty from "lodash/isEmpty";

let dateChk = {};

class MemberPaymentDetails extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedIndex: 0,
      searchVo: this.props.searchVo,
      paymentVo: this.props.mbrPaymentList[0],
      editable: false,
      data: this.props.mbrPaymentList,
      closePopup: false,
      rowsPerPage: 10,
      page: 0,
      mbridLit: [],
    };
    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
        amountValidator: customValidations.amountValidator,
      },
    });
  }
  componentWillUnmount() {
    const { selectedIndex } = this.state;
    this.props.setMbrPaymentsIndex(selectedIndex);
  }

  componentDidMount() {
    const tableIndex = this.props.tableIndex;
    const { mbrPaymentList } = this.props;
    this.setState({
      selectedIndex: tableIndex,
      paymentVo: mbrPaymentList[tableIndex],
    });
    const { loginProfile } = this.props;
    const MBRIDLIT = loginProfile.filter((data) => data.label === "MBRIDLIT");
    this.setState({
      mbridLit: MBRIDLIT[0],
    });
  }
  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.selectedVo)
      if (
        !(
          nextProps.selectedVo.customerId === prevState.paymentVo.customerId &&
          nextProps.selectedVo.paySourceType ===
            prevState.paymentVo.paySourceType &&
          nextProps.selectedVo.batchDate === prevState.paymentVo.batchDate &&
          nextProps.selectedVo.batchSeqNbr ===
            prevState.paymentVo.batchSeqNbr &&
          nextProps.selectedVo.itemNbr === prevState.paymentVo.itemNbr
        )
      ) {
        return {
          paymentVo: nextProps.selectedVo,
          selectedIndex: nextProps.index,
          editable: false,
        };
      }
    return null;
  }

  updatePaymentDetails = () => {
    this.setState({ editable: true });
  };
  handleNumber = (e) => {
    let name = e.target.name;
    let value = e.target.value.replace(/[^0-9]/g, ".");
    this.setState((prevState) => ({
      paymentVo: {
        ...prevState.paymentVo,
        [name]: value,
      },
    }));
  };
  handleDates = (event) => {
    let fieldId = "#" + event.target.name;
    var self = this;

    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        if (
          dateChk.name !== e.target.name ||
          dateChk.value !== e.target.value
        ) {
          self.setDate(e.target.name, e.target.value);
        }
        dateChk.name = e.target.name;
        dateChk.value = e.target.value;
      });
  };

  setDate = (name, value) => {
    this.setState((prevState) => ({
      paymentVo: {
        ...prevState.paymentVo,
        [name]: value,
      },
      modified: true,
    }));
  };
  handleDate = (event) => {
    let value = event.target.value;
    let name = event.target.name;
    this.setState((prevState) => ({
      paymentVo: {
        ...prevState.paymentVo,
        [name]: handleDateChange(value),
      },
      modified: true,
    }));
  };

  handlechange = (event) => {
    let name = event.target.name;
    let value = event.target.value.toUpperCase();
    this.setState((prevState) => ({
      paymentVo: {
        ...prevState.paymentVo,
        [name]: value,
      },
    }));
  };

  modalClosed = () => {
    this.setState({ closePopup: false });
  };
  updateDetails = () => {
    if(isEmpty(this.state.paymentVo.checkDateFrmt)){
      alert("Please enter the check Date")
    }
    else if(isEmpty(this.state.paymentVo.invoiceDueDateFrmt)){
      alert("Please enter the Invoice Due Date")
    }
   else{
    if (this.validator.allValid()) {
      ConfirmBox(this.updatePaymentDetails, Type.UPDATE, this.props);
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
   }
   
  };
  updatePaymentDetails = async () => {
    const selectedVo = this.state.paymentVo;
    selectedVo.selectedIndex = this.state.selectedIndex;
    let status = await this.props.updateMbrPayments(selectedVo);
    if (status === "success") {
      status = messages.UPDATED_SUCCESSFULLY;
      this.setState({
        paymentVo: selectedVo,
        closePopup: true,
        message: status,
        reset: false,
        editable: false,
      });
    }
  };

  handleOnBlur = (event) => {
    let value = event.target.value.trim();
    let name = event.target.name;

    this.setState((prevState) => ({
      paymentVo: {
        ...prevState.paymentVo,
        [name]: value,
      },
      modified: true,
    }));
  };
  showPaymentDetailEntry = () => {
    if (this.state.paymentVo.paymentPostedInd === "Y") {
      this.setState({
        closePopup: true,
        message: "Payment has already been posted",
        reset: false,
      });
      return false;
    } else {
      this.setState({ editable: true });
    }
  };

  render() {
    const {
      classes,
      mbrPaymentDtlList,
      mbrPaymentList,
      servicesEnabled,
    } = this.props;
    const { paymentVo, editable, mbridLit, message, closePopup } = this.state;
    if (!editable && this.validator.messagesShown) {
      this.validator.hideMessages();
      this.forceUpdate();
    }

    return (
      <React.Fragment>
        <Modal
          dialogTitle="Member Payments"
          message={message}
          show={closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Paper elevation={0} className={classes.card}>
          {mbrPaymentList.length > 0 ? (
            <div className={classes.buttonContainer}>
              {servicesEnabled.includes("EEUB") ? (
                <Button
                  variant="contained"
                  color="primary"
                  className={classes.buttonFitToText}
                  onClick={
                    !editable ? this.showPaymentDetailEntry : this.updateDetails
                  }
                >
                  {!editable ? "Update" : "Save Details"}
                </Button>
              ) : null}
            </div>
          ) : null}

          {paymentVo ? (
            <div class="panel-body">
              <div className={classes.containertypography}>
                <div>
                  <InputField
                    name="invoiceId"
                    InputProps={{ className: classes.textFont }}
                    label={mbridLit.value === "TSA" ? "Wipro ID" : "M360 ID"}
                    className={classes.textField}
                    value={paymentVo.invoiceId}
                    onChange={this.handlechange}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div className={classes.mbrgrid3}>
                  <InputField
                    name="fullName"
                    InputProps={{ className: classes.textFont }}
                    label="Name"
                    className={classes.textField}
                    value={paymentVo.firstName + " " + paymentVo.lastName}
                    width="370px"
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="hicNbr"
                    InputProps={{ className: classes.textFont }}
                    label="Medicare ID"
                    className={classes.textField}
                    value={paymentVo.hicNbr}
                    onChange={this.handlechange}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="paySourceDesc"
                    InputProps={{ className: classes.textFont }}
                    label="Payment Source"
                    className={classes.textField}
                    value={paymentVo.paySourceDesc}
                    onChange={this.handlechange}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="batchDateFrmt"
                    placeholder="MM/DD/YYYY"
                    InputProps={{ className: classes.textFont }}
                    label="Batch Date"
                    className={classes.textField}
                    value={paymentVo.batchDateFrmt}
                    onChange={this.handlechange}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="batchSeqNbr"
                    InputProps={{ className: classes.textFont }}
                    label="Batch Seq Nbr"
                    className={classes.textField}
                    value={paymentVo.batchSeqNbr}
                    onChange={this.handlechange}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="itemNbr"
                    InputProps={{ className: classes.textFont }}
                    label="Item Nbr:"
                    className={classes.textField}
                    value={paymentVo.itemNbr}
                    onChange={this.handlechange}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="bankAcctCd"
                    InputProps={{ className: classes.textFont }}
                    label="Bank Account Cd:"
                    className={classes.textField}
                    value={paymentVo.bankAcctCd}
                    onChange={this.handlechange}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="invoiceDueDateFrmt"
                    placeholder="MM/DD/YYYY"
                    onClick={this.handleDates}
                    label="Invoice Due Date:"
                    onChange={this.handleDate}
                    onBlur={this.handleOnBlur}
                    value={paymentVo.invoiceDueDateFrmt}
                    disabled={!editable}
                    maxLength={10}
                  />
                  <div className={classes.validationMessage}>
                    {this.validator.message(
                      "Invoice Due Date",
                      paymentVo.invoiceDueDateFrmt,
                      "required|date_format"
                    )}
                  </div>
                </div>
                <div>
                  <InputField
                    name="paymentPostedInd"
                    InputProps={{ className: classes.textFont }}
                    label="Payment Posted Ind"
                    className={classes.textField}
                    value={paymentVo.paymentPostedInd}
                    onChange={this.handlechange}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="checkNbr"
                    InputProps={{ className: classes.textFont }}
                    label="Check Nbr"
                    className={classes.textField}
                    value={paymentVo.checkNbr}
                    onChange={this.handlechange}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="checkDateFrmt"
                    placeholder="MM/DD/YYYY"
                    label="Check Date"
                    value={paymentVo.checkDateFrmt}
                    maxLength={10}
                    disabled={!editable}
                    onClick={this.handleDates}
                    onChange={this.handleDate}
                    onBlur={this.handleOnBlur}
                  />
                  <div className={classes.validationMessage}>
                    {this.validator.message(
                      "Check Date",
                      [0, paymentVo.checkDateFrmt],
                      "required"
                    )}
                    {this.validator.message(
                      "Check Date",
                      paymentVo.checkDateFrmt,
                      "date_format"
                    )}
                  </div>
                </div>
                <div>
                  <InputField
                    name="paymentAmt"
                    label="Payment Amt"
                    value={paymentVo.paymentAmt}
                    disabled={!editable}
                    maxLength={10}
                    onChange={this.handleNumber}
                  />
                  <div className={classes.validationMessage}>
                    {this.validator.message(
                      "Payment Amt",
                      paymentVo.paymentAmt,
                      "required|amountValidator"
                    )}
                  </div>
                </div>
              </div>
              <br />
              <div>
                <HistoryData
                  createUserId={paymentVo.createUserId}
                  createTime={paymentVo.createTime}
                  lastUpdtTime={paymentVo.lastUpdtTime}
                  lastUpdtUserId={paymentVo.lastUpdtUserId}
                />
              </div>
              <br />

              <div
                className={
                  mbrPaymentDtlList.length > 10
                    ? classes.readOnlyTable
                    : classes.readOnlyTableAuto
                }
              >
                <DataTable
                  data={mbrPaymentDtlList}
                  header={paymentHeader}
                  rowsPerPage={20}
                  sortableHeader={true}
                  clicked={() => {}}
                  index={0}
                  selectedRow="true"
                  removePagination="true"
                />
              </div>
            </div>
          ) : null}

          <br />
        </Paper>
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    mbrPaymentList:
      state.billingReducer.mbrPayments.mbrPaymentSearchResults.mbrPaymentsVO,
    mbrPaymentDtlList:
      state.billingReducer.mbrPayments.mbrPaymentSearchResults
        .mbrPymntDtlInvcVO,
    tableIndex: state.billingReducer.mbrPayments.tableIndexes.mbrPaymentList,
    servicesEnabled: state.loginData.servicesEnabled,
    loginProfile: state.loginData.profiles,
  };
};
const mapDispatchToProps = {
  getBillingPaymentDetailInvoice,
  updateMbrPayments,
  setMbrPaymentsIndex,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(MemberPaymentDetails));
