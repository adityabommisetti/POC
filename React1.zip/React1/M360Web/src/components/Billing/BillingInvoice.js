import React, { Component } from "react";
import AutoComplete1 from "../UI/Select";
import Paper from "@material-ui/core/Paper";
import ExpansionPanel from "../UI/ExpansionPanel";
import InputField from "../UI/InputField";
import { Styles } from "../../assets/styles/Theme";
import { withStyles } from "@material-ui/core/styles";
import { connect } from "react-redux";
import { searchInvoice } from "../../redux/actions/BillingActions";
import InvoiceSearchResults from "./BillingInvoiceSearchResults";
import InvoiceHeaderDetails from "./BillingInvoiceHeaderDetails";
import InvoiceDetails from "./BillingInvoiceDetails";
import InvoiceComments from "./BillingInvoiceComments";
import InvoiceMemberSummary from "./BillingInvoiceMbrSummary";
import isEmpty from "lodash/isEmpty";
import {
  resetMemberSearch,
  searchAttributes,
} from "../../redux/actions/MemberActions";

const INITIAL_SEARCHVO = {
  searchLastName: "",
  searchMemberId: "",
  searchInvoiceNbr: "",
  searchMedicareId: "",
  searchInvoiceGroup: "M",
  searchInvoiceType: "BM",
  searchSupplementalId: "",
  searchInvoiceStatus: "",
  searchInvoiceId: "",
};
const SELECT_OBJECT = {
  label: "Select",
  value: "",
};

class Invoice extends Component {
  constructor(props) {
    super(props);
    this.state = {
      onload: true,
      searchVo: {
        ...INITIAL_SEARCHVO,
      },
      selectedRowIndex: 0,
      updateBtn: true,
      compareFlag: false, //To compare after every search
      invoiceTypes: [],
      mbridLit: [],
      resetFlag: true,
    };
  }
  static getDerivedStateFromProps(nextProps, prevState) {
    const { lstRelatedInvoiceType } = nextProps.CacheData;
    const name = INITIAL_SEARCHVO.searchInvoiceGroup;
    if (isEmpty(prevState.invoiceTypes) && lstRelatedInvoiceType) {
      const options = [...lstRelatedInvoiceType[name]];
      return {
        invoiceTypes: options, //To set options for InvoiceType
      };
    }
    return null;
  }

  componentDidUpdate() {
    if (this.state.onload) {
      this.setState({
        onload: false,
        searchVo: this.props.searchAttribute
          ? this.props.searchAttribute
          : INITIAL_SEARCHVO,
      });
    }
  }
  componentDidMount() {
    this.setState({
      searchVo: this.props.searchCriteriaVo,
    });
    const { loginProfile } = this.props;
    const MBRIDLIT = loginProfile.filter((data) => data.label === "MBRIDLIT");
    this.setState({
      mbridLit: MBRIDLIT[0],
    });
  }

  handleOnBlur = (event) => {
    let value = event.target.value;
    let name = event.target.name;
    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value.trim(),
      },
    }));
  };

  handleChange = (event) => {
    let value = event.target.value;
    let name = event.target.name;
    if (name === "searchInvoiceNbr") {
      value = value.replace(/[^0-9]/g, ""); //Accept only integers in InvoiceNbr field
    }
    this.setState(
      (prevState) => ({
        searchVo: {
          ...prevState.searchVo,
          [name]: value.toUpperCase(),
        },
      }),
      () => {
        this.props.searchAttributes({ billingSearch: this.state.searchVo });
      }
    );
  };

  handleChangeSearchSelectAuto = async (data, name) => {
    let value = data.value ? data.value : "";
    if (name === "searchInvoiceGroup") {
      //Based on InvoiceGroup selected, InvoiceType options will be changed
      const { lstRelatedInvoiceType } = this.props.CacheData;
      const options =
        value === ""
          ? [SELECT_OBJECT]
          : [SELECT_OBJECT, ...lstRelatedInvoiceType[value]];
      await this.setState(
        (prevState) => ({
          searchVo: {
            ...prevState.searchVo,
            searchInvoiceType: "",
            [name]: value.toUpperCase(),
          },
          invoiceTypes: options,
        }),
        () => {
          this.props.searchAttributes({ billingSearch: this.state.searchVo });
        }
      );
    } else {
      this.setState(
        (prevState) => ({
          searchVo: {
            ...prevState.searchVo,
            [name]: value.toUpperCase(),
          },
        }),
        () => {
          this.props.searchAttributes({ billingSearch: this.state.searchVo });
        }
      );
    }
  };

  handleResetAppl = async (e) => {
    e.preventDefault();

    const { lstRelatedInvoiceType } = this.props.CacheData;
    const name = INITIAL_SEARCHVO.searchInvoiceGroup;

    const options = [...lstRelatedInvoiceType[name]];
    await this.setState({
      invoiceTypes: options,
    });

    await this.setState({
      searchVo: {
        ...INITIAL_SEARCHVO,
      },
      resetFlag: false,
    });
    this.props.searchAttributes({ billingSearch: { ...INITIAL_SEARCHVO } });
  };

  handleSubmit = async (e) => {
    e.preventDefault();
    let { searchVo } = this.state;
    searchVo.searchInvoiceGroup = searchVo.searchInvoiceGroup.trim();
    searchVo.searchInvoiceId = searchVo.searchInvoiceId.trim();
    searchVo.searchInvoiceNbr = searchVo.searchInvoiceNbr.trim();
    searchVo.searchLastName = searchVo.searchLastName.trim();
    searchVo.searchMedicareId = searchVo.searchMedicareId.trim();
    searchVo.searchMemberId = searchVo.searchMemberId.trim();
    searchVo.searchSupplementalId = searchVo.searchSupplementalId.trim();
    await this.props.searchInvoice(searchVo);
    this.props.searchAttributes({ billingSearch: searchVo });
    this.setState({
      compareFlag: true,
      resetFlag: true,
    });
  };

  setFlag = (data) => {
    this.setState({
      compareFlag: data,
    });
  };

  componentWillUnmount() {
    this.props.resetMemberSearch({
      applicationId: this.props.selectedMemberId.applicationId,
    });
  }

  setUpdateBtn = (value) => {
    this.setState({
      updateBtn: value,
    });
  };

  render() {
    const {
      classes,
      CacheData,
      invoiceHeaderDetailsList,
      searchFlag,
    } = this.props;
    const { lstInvoiceStatus, lstInvoiceGroup } = CacheData;
    const {
      searchVo,
      updateBtn,
      invoiceTypes,
      compareFlag,
      mbridLit,
      resetFlag,
    } = this.state;

    return (
      <React.Fragment>
        <Paper
          elevation={0}
          className={classes.card}
          style={{
            minHeight: "400px",
          }}
        >
          <ExpansionPanel
            summary="Invoice Search"
            className={classes.containertypography}
          >
            {CacheData ? (
              <div class="panel-body" className={classes.panelBody}>
                <form onSubmit={this.handleSubmit}>
                  <div className={classes.bilinggrid1}>
                    <div className={classes.bilinggrid2}>
                      <InputField
                        width="180px"
                        name="searchLastName"
                        maxLength={35}
                        InputProps={{
                          className: classes.textFont,
                        }}
                        label="Last Name"
                        className={classes.textField}
                        value={searchVo.searchLastName}
                        InputLabelProps={{
                          className: classes.label,
                          shrink: true,
                        }}
                        onChange={(e) => {
                          this.handleChange(e);
                        }}
                        onBlur={(e) => {
                          this.handleOnBlur(e);
                        }}
                      />
                    </div>
                    <div className={classes.bilinggrid2}>
                      <InputField
                        width="180px"
                        maxLength={15}
                        name="searchMemberId"
                        InputProps={{
                          className: classes.textFont,
                        }}
                        label={
                          mbridLit.value === "TSA" ? "Wipro ID" : "M360 ID"
                        }
                        className={classes.textField}
                        value={searchVo.searchMemberId}
                        InputLabelProps={{
                          className: classes.label,
                          shrink: true,
                        }}
                        onChange={(e) => this.handleChange(e)}
                        onBlur={(e) => {
                          this.handleOnBlur(e);
                        }}
                      />
                    </div>
                    <div className={classes.bilinggrid2}>
                      <InputField
                        width="170px"
                        name="searchInvoiceNbr"
                        maxLength={15}
                        InputProps={{
                          className: classes.textFont,
                        }}
                        label="Invoice Nbr"
                        className={classes.textField}
                        value={searchVo.searchInvoiceNbr}
                        InputLabelProps={{
                          className: classes.label,
                          shrink: true,
                        }}
                        onChange={(e) => this.handleChange(e)}
                        onBlur={(e) => {
                          this.handleOnBlur(e);
                        }}
                      />
                    </div>
                    <div className={classes.bilinggrid2}>
                      <AutoComplete1
                        options={lstInvoiceStatus}
                        margin="0px"
                        fontSize="0.718em"
                        handleChange={this.handleChangeSearchSelectAuto}
                        defaultValue={
                          lstInvoiceStatus ? lstInvoiceStatus[0] : null
                        }
                        value={
                          lstInvoiceStatus
                            ? lstInvoiceStatus.filter(
                                (option) =>
                                  option.value === searchVo.searchInvoiceStatus
                              )[0]
                            : SELECT_OBJECT[0]
                        }
                        label="Invoice Status"
                        name="searchInvoiceStatus"
                      />
                    </div>
                    <div className={classes.bilinggrid2}>
                      <InputField
                        width="170px"
                        name="searchMedicareId"
                        maxLength={12}
                        InputProps={{
                          className: classes.textFont,
                        }}
                        label="Medicare ID"
                        className={classes.textField}
                        value={searchVo.searchMedicareId}
                        InputLabelProps={{
                          className: classes.label,
                          shrink: true,
                        }}
                        onChange={(e) => this.handleChange(e)}
                        onBlur={(e) => {
                          this.handleOnBlur(e);
                        }}
                      />
                    </div>
                    <div className={classes.bilinggrid2}>
                      <AutoComplete1
                        options={lstInvoiceGroup}
                        margin="0px"
                        fontSize="0.718em"
                        handleChange={this.handleChangeSearchSelectAuto}
                        defaultValue={
                          lstInvoiceGroup ? lstInvoiceGroup[0] : null
                        }
                        value={
                          lstInvoiceGroup
                            ? lstInvoiceGroup.filter(
                                (option) =>
                                  option.value === searchVo.searchInvoiceGroup
                              )[0]
                            : SELECT_OBJECT[0]
                        }
                        label="Invoice Group"
                        name="searchInvoiceGroup"
                      />
                    </div>
                    <div className={classes.bilinggrid2}>
                      {invoiceTypes && invoiceTypes.length > 0 ? (
                        <AutoComplete1
                          options={invoiceTypes}
                          margin="0px"
                          fontSize="0.718em"
                          handleChange={this.handleChangeSearchSelectAuto}
                          defaultValue={
                            invoiceTypes.filter(
                              (option) =>
                                option.value === searchVo.searchInvoiceType
                            )[0]
                          }
                          value={
                            invoiceTypes
                              ? invoiceTypes.filter(
                                  (option) =>
                                    option.value === searchVo.searchInvoiceType
                                )[0]
                              : invoiceTypes[0]
                          }
                          label="Invoice Type"
                          name="searchInvoiceType"
                        />
                      ) : null}
                    </div>
                    <div className={classes.bilinggrid2}>
                      <InputField
                        width="170px"
                        name="searchSupplementalId"
                        InputProps={{
                          className: classes.textFont,
                        }}
                        label="Plan Member ID"
                        className={classes.textField}
                        value={searchVo.searchSupplementalId}
                        InputLabelProps={{
                          className: classes.label,
                          shrink: true,
                        }}
                        onChange={(e) => this.handleChange(e)}
                        onBlur={(e) => {
                          this.handleOnBlur(e);
                        }}
                        maxLength={15}
                      />
                    </div>
                    <span
                      class="button-container-search"
                      className={classes.expansionPanelbuttons}
                    >
                      <button id="search" class="btn btn-primary icon-search">
                        Search
                      </button>
                      <button
                        id="reset"
                        class="btn btn-secondary"
                        onClick={this.handleResetAppl}
                      >
                        Reset
                      </button>
                    </span>
                  </div>
                </form>
              </div>
            ) : null}
          </ExpansionPanel>
          {searchFlag ? (
            <>
              {!isEmpty(invoiceHeaderDetailsList) ? (
                <>
                  <InvoiceSearchResults
                    setFlag={this.setFlag}
                    compareFlag={compareFlag}
                  />

                  <InvoiceMemberSummary />
                  <InvoiceHeaderDetails />
                  <InvoiceDetails setUpdateBtn={this.setUpdateBtn} />
                  <InvoiceComments updateBtn={updateBtn} />
                </>
              ) : resetFlag === true ? (
                <InvoiceSearchResults
                  setFlag={this.setFlag}
                  compareFlag={compareFlag}
                />
              ) : null}
            </>
          ) : null}
        </Paper>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    invoiceSearchResults: state.billingReducer.invoice.invoiceSearchResults,
    invoiceHeaderDetailsList: state.billingReducer.invoice.oldResults,
    searchFlag: state.billingReducer.invoice.searchFlag,
    CacheData: state.billingReducer.bilingCacheData,
    selectedMemberId: state.memberSearch.selectedMemberId,
    searchCriteriaVo: state.billingReducer.invoice.searchCriteriaVo,
    searchAttribute: !isEmpty(state.memberSearch.searchAttributes)
      ? state.memberSearch.searchAttributes.billingSearch
      : null,
    loginProfile: state.loginData.profiles,
  };
};

const mapDispatchToProps = {
  searchInvoice,
  resetMemberSearch,
  searchAttributes,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(Invoice));
