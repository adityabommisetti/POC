import MuiExpansionPanelDetails from "@material-ui/core/ExpansionPanelDetails";
import Paper from "@material-ui/core/Paper";
import { withStyles } from "@material-ui/core/styles";
import React, { Component } from "react";
import { connect } from "react-redux";
import { Styles } from "../../assets/styles/Theme";
import { DRAFT_DETAILS_HEADER as header } from "../../constants/Headers/BillingHeaders";
import {
  draftSearch,
  setDraftTableIndex,
  draftDetailSearch,
  draftSearchNext,
} from "../../redux/actions/BillingActions";
import DataTable from "../Home/DataTable";
import ExpansionPanel from "../UI/ExpansionPanel";
import InputField from "../UI/InputField";
import HistoryData from "../UI/MemberHistory";
import AutoComplete1 from "../UI/Select";
import isEmpty from "lodash/isEmpty";

const ExpansionPanelDetails = withStyles((theme) => ({
  root: {
    padding: theme.spacing.unit * 2,
    display: "block",
  },
}))(MuiExpansionPanelDetails);
const SEARCH_INITIAL_STATE = {
  searchInvoiceNbr: "",
  searchInvoiceId: "",
  searchDraftStatus: "",
  searchLastName: "",
  searchHicNbr: "",
  searchSupplId: "",
};
const DRAFT_SELECTEDVO = {
  invoiceNbr: "",
  itemNbr: 0,
  addNbr: 0,
  memberId: "",
  lastName: "",
  sendDate: "",
  draftAmount: "",
  traceNumber: "",
  accountType: "",
  draftStatus: "",
  dueDate: "",
  settlementDate: "",
  responseDate: "",
  responseCode: "",
  responseMessage: "",
  routingNumber: "",
  accountNumber: "",
  bankName: "",
  responseTime: "",
  draftDay: "",
  createTime: "",
  createUserId: "",
  lastUpdtTime: "",
  lastUpdtUserId: "",
  dueDateFrmt: "",
  settlementDateFrmt: "",
  responseDateFrmt: "",
  sendDateFrmt: "",
};
class Draft extends Component {
  constructor(props) {
    super(props);
    this.state = {
      searchVo: SEARCH_INITIAL_STATE,
      draftSelectedVo: {
        DRAFT_SELECTEDVO,
      },
      index: 0,
      searchFlag: false,
      rowsPerPage: 10,
      flag: false,
      mbridLit: [],
      resetFlag: true,
    };
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (
      prevState.searchFlag === false &&
      nextProps.billingDraftHeaderVOList.length > 0
    ) {
      return {
        searchFlag: true,
        draftSelectedVo: !isEmpty(nextProps.billingDraftDetailVOList)
          ? nextProps.billingDraftDetailVOList[0]
          : DRAFT_SELECTEDVO,
      };
    }
    return null;
  }
  componentWillUnmount() {
    const { index } = this.state;
    this.props.setDraftTableIndex(index);
  }

  componentDidMount() {
    const tableIndex = this.props.tableIndex;
    const { billingDraftDetailVOList } = this.props;
    this.setState({
      index: tableIndex,
      draftSelectedVo: billingDraftDetailVOList[0],
    });
    const { loginProfile } = this.props;
    const MBRIDLIT = loginProfile.filter((data) => data.label === "MBRIDLIT");
    this.setState({
      mbridLit: MBRIDLIT[0],
    });
  }
  handleChangeRowsPerPage = async (rowsPerPage) => {
    await this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  selectRow = async (index, selectedData, rowsPerPage) => {
    await this.props.draftDetailSearch(selectedData);

    await this.setState(() => ({
      draftSelectedVo: this.props.billingDraftDetailVOList[0],
      index: index,
      rowsPerPage: rowsPerPage,
    }));
  };
  reset = () => {
    this.setState({
      searchVo: { SEARCH_INITIAL_STATE },
      index: 0,
      resetFlag: false,
    });
  };
  handleOnBlur = (event) => {
    let name = event.target.name;
    let value = event.target.value.trim();

    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value,
      },
    }));
  };
  handlechange = () => (event) => {
    let name = event.target.name;
    let value =
      name === "searchInvoiceNbr"
        ? event.target.value.replace(/[^0-9]/g, "")
        : event.target.value.toUpperCase();

    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value,
      },
    }));
  };
  handleChangeSearchSelectAuto = (data, name) => {
    let value = data.value;
    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  doBillDraftSearch = async (event) => {
    event.preventDefault();
    this.setState({ flag: true });
    await this.props.draftSearch(this.state.searchVo);
    await this.setState(() => ({
      draftSelectedVo: !isEmpty(this.props.billingDraftDetailVOList)
        ? this.props.billingDraftDetailVOList[0]
        : DRAFT_SELECTEDVO,
      searchFlag: true,
      flag: false,
      resetFlag: true,
    }));
  };

  fetchMoreResults = async (pageNo) => {
    const { searchCriteriaVo, billingDraftHeaderVOList } = this.props;
    const lastIndex = billingDraftHeaderVOList.length - 1;
    const { searchInvoiceNbr } = billingDraftHeaderVOList[lastIndex];

    let payload = {
      ...searchCriteriaVo,
      searchInvoiceNbr: searchInvoiceNbr,
    };
    await this.props.draftSearchNext(payload);
    this.setState({ selectedRowIndex: pageNo * this.state.rowsPerPage });
  };

  render() {
    const {
      classes,
      billingDraftHeaderVOList,
      draftStatusLst,
      nextPage,
    } = this.props;
    const {
      draftSelectedVo,
      searchFlag,
      searchVo,
      flag,
      index,
      rowsPerPage,
      collapseSearch,
      collapseTableSearch,
      mbridLit,
      resetFlag,
    } = this.state;

    return (
      <Paper elevation={0} className={[classes.card, classes.paperHeight]}>
        <div class="search-panel">
          <ExpansionPanel summary="Search" defaultCollapsed={collapseSearch}>
            <ExpansionPanelDetails>
              <form onSubmit={this.doBillDraftSearch}>
                <div className={classes.containertypography}>
                  <div className={classes.textBox}>
                    <InputField
                      name="searchLastName"
                      width="155px"
                      InputProps={{ className: classes.textFont }}
                      label="Last Name"
                      className={classes.textField}
                      maxLength={35}
                      value={searchVo.searchLastName}
                      InputLabelProps={{
                        className: classes.label,
                        shrink: true,
                      }}
                      onChange={this.handlechange()}
                      onBlur={this.handleOnBlur}
                    />

                    <div className={classes.billSrchvalidation} />
                  </div>
                  <div className={classes.textBox}>
                    <InputField
                      name="searchInvoiceId"
                      width="155px"
                      InputProps={{ className: classes.textFont }}
                      label={mbridLit.value === "TSA" ? "Wipro ID" : "M360 ID"}
                      className={classes.textField}
                      value={searchVo.searchInvoiceId}
                      InputLabelProps={{
                        className: classes.label,
                        shrink: true,
                      }}
                      onChange={this.handlechange()}
                      onBlur={this.handleOnBlur}
                      maxLength={15}
                    />
                    <div className={classes.billSrchvalidation} />
                  </div>

                  <div className={classes.textBox}>
                    <InputField
                      name="searchInvoiceNbr"
                      width="155px"
                      InputProps={{ className: classes.textFont }}
                      label="Invoice Number"
                      className={classes.textField}
                      maxLength={15}
                      value={searchVo.searchInvoiceNbr}
                      InputLabelProps={{
                        className: classes.label,
                        shrink: true,
                      }}
                      onChange={this.handlechange()}
                      onBlur={this.handleOnBlur}
                    />
                    <div className={classes.billSrchvalidation}></div>
                  </div>
                  <div className={classes.Select4}>
                    <AutoComplete1
                      options={draftStatusLst}
                      margin="0px"
                      width="240px"
                      fontSize="0.718em"
                      handleChange={this.handleChangeSearchSelectAuto}
                      defaultValue={{
                        label: "Select",
                        value: "",
                      }}
                      value={
                        draftStatusLst
                          ? draftStatusLst.filter(
                              (option) =>
                                option.value === searchVo.searchDraftStatus
                            )[0]
                          : null
                      }
                      label="Draft Status"
                      name="searchDraftStatus"
                    />
                    <div className={classes.billSrchvalidation} />
                  </div>

                  <div className={classes.textBox}>
                    <InputField
                      name="searchHicNbr"
                      width="155px"
                      label="Medicare ID"
                      className={classes.textField}
                      value={searchVo.searchHicNbr}
                      onChange={this.handlechange()}
                      onBlur={this.handleOnBlur}
                      maxLength={12}
                    />
                    <div className={classes.billSrchvalidation} />
                  </div>
                  <div className={classes.textBox}>
                    <InputField
                      name="searchSupplId"
                      width="155px"
                      InputProps={{ className: classes.textFont }}
                      label="Plan Member ID"
                      className={classes.textField}
                      value={searchVo.searchSupplId}
                      InputLabelProps={{
                        className: classes.label,
                        shrink: true,
                      }}
                      onChange={this.handlechange()}
                      onBlur={this.handleOnBlur}
                      maxLength={15}
                    />
                    <div className={classes.billSrchvalidation} />
                  </div>

                  <div className={classes.expansionPanelbuttons}>
                    <span class="button-container-search">
                      <button type="submit" class="btn btn-primary icon-search">
                        Search
                      </button>

                      <button
                        type="button"
                        class="btn btn-secondary"
                        onClick={this.reset}
                      >
                        Reset
                      </button>
                    </span>
                  </div>
                </div>
              </form>
            </ExpansionPanelDetails>
          </ExpansionPanel>
        </div>

        {!isEmpty(billingDraftHeaderVOList) && searchFlag ? (
          <div class="search-panel">
            <ExpansionPanel
              summary="Search Results"
              defaultCollapsed={collapseTableSearch}
            >
              <DataTable
                flag={flag}
                index={index}
                sortable={true}
                header={header}
                searchable={true}
                nextPage={nextPage}
                exportAsExcel={true}
                dateColumn="dueDateFrmt"
                clicked={this.selectRow}
                rowsPerPage={rowsPerPage}
                data={billingDraftHeaderVOList}
                fetchMore={this.fetchMoreResults}
                rowsPerPageOptions={[5, 10, 15, 20]}
                handleChangeRowsPerPage={this.handleChangeRowsPerPage}
              />
            </ExpansionPanel>
          </div>
        ) : resetFlag && searchFlag ? (
          <div class="search-panel">
            <ExpansionPanel
              summary="Search Results"
              defaultCollapsed={collapseTableSearch}
            >
              <DataTable header={header} data={[]} />
            </ExpansionPanel>
          </div>
        ) : null}

        {!isEmpty(billingDraftHeaderVOList) && searchFlag ? (
          <div class="search-panel">
            <div class="panel-body margin-top1">
              <div className={classes.containertypography}>
                <div>
                  <InputField
                    name="memberId"
                    label={mbridLit.value === "TSA" ? "Wipro ID" : "M360 ID"}
                    value={draftSelectedVo.memberId}
                    disabled
                  />
                </div>

                <div>
                  <InputField
                    name="lastName"
                    label="Name"
                    value={draftSelectedVo.lastName}
                    disabled
                  />
                </div>

                <div>
                  <InputField
                    name="sendDate"
                    placeholder="MM/DD/YYYY"
                    label="Send Date"
                    value={draftSelectedVo.sendDateFrmt}
                    disabled
                  />
                </div>
                <div>
                  <InputField
                    name="draftAmount"
                    label="Draft Amt"
                    value={draftSelectedVo.draftAmount}
                    disabled
                  />
                </div>
                <div>
                  <InputField
                    name="invoiceNbr"
                    label="Invoice"
                    value={draftSelectedVo.invoiceNbr}
                    disabled
                  />
                </div>
                <div>
                  <InputField
                    name="traceNumber"
                    label="	Trace Number"
                    value={draftSelectedVo.traceNumber}
                    disabled
                  />
                </div>
                <div>
                  <InputField
                    name="accountType"
                    label="Account Type"
                    value={draftSelectedVo.accountType}
                    disabled
                  />
                </div>
                <div>
                  <InputField
                    name="draftStatus"
                    label="Status"
                    value={draftSelectedVo.draftStatus}
                    disabled
                  />
                </div>
                <div>
                  <InputField
                    name="dueDate"
                    placeholder="MM/DD/YYYY"
                    label="Due Date"
                    value={draftSelectedVo.dueDateFrmt}
                    disabled
                  />
                </div>
                <div>
                  <InputField
                    name="settlementDate"
                    placeholder="MM/DD/YYYY"
                    label="	Settlement Date"
                    value={draftSelectedVo.settlementDateFrmt}
                    disabled
                  />
                </div>
                <div>
                  <InputField
                    name="responseDate"
                    label="Response Date"
                    value={draftSelectedVo.responseDateFrmt}
                    disabled
                  />
                </div>
                <div>
                  <InputField
                    name="responseCode"
                    label="	Response Code"
                    value={draftSelectedVo.responseCode}
                    disabled
                  />
                </div>
                <div>
                  <InputField
                    name="routingNumber"
                    label="Routing"
                    value={draftSelectedVo.routingNumber}
                    disabled
                  />
                </div>
                <div>
                  <InputField
                    name="accountNumber"
                    label="Account Number"
                    value={draftSelectedVo.accountNumber}
                    disabled
                  />
                </div>
                <div>
                  <InputField
                    name="bankName"
                    label="Bank Name"
                    value={draftSelectedVo.bankName}
                    disabled
                  />
                </div>
                <div>
                  <InputField
                    name="draftDay"
                    label="Draft Day"
                    value={draftSelectedVo.draftDay}
                    disabled
                  />
                </div>
                <div>
                  <InputField
                    name="responseMessage"
                    label="Response Message"
                    value={draftSelectedVo.responseMessage}
                    disabled
                  />
                </div>
              </div>
              <HistoryData
                createUserId={draftSelectedVo.createUserId}
                createTime={draftSelectedVo.createTime}
                lastUpdtTime={draftSelectedVo.lastUpdtTime}
                lastUpdtUserId={draftSelectedVo.lastUpdtUserId}
              />
            </div>
          </div>
        ) : null}
      </Paper>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    billingDraftHeaderVOList:
      state.billingReducer.draft.billingDraftHeaderVOList,
    billingDraftDetailVOList:
      state.billingReducer.draft.billingDraftDetailVOList,
    draftStatusLst: state.billingReducer.bilingCacheData.draftStatusLst,
    tableIndex: state.billingReducer.draft.tableIndex,
    searchCriteriaVo: state.billingReducer.draft.searchCriteriaVo,
    nextPage: state.billingReducer.draft.nextPage,
    loginProfile: state.loginData.profiles,
  };
};
const mapDispatchToProps = {
  draftSearch,
  draftDetailSearch,
  setDraftTableIndex,
  draftSearchNext,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(Draft));
