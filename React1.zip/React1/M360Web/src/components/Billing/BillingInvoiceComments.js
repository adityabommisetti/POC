import { INVOICE_COMMENTS_HEADER } from "../../constants/Headers/BillingHeaders";
import TextField from "@material-ui/core/TextField";
import HistoryData from "../UI/MemberHistory";
import React, { Component } from "react";
import Modal from "../UI/Modal/Modal";
import Button from "@material-ui/core/Button";
import DataTable from "../Home/DataTable";
import ExpansionPanel from "../UI/ExpansionPanel";
import { Styles } from "../../assets/styles/Theme";
import { withStyles } from "@material-ui/core/styles";
import { connect } from "react-redux";
import {
  saveComments,
  setInvoiceTableIndex,
  setAdjustmentComments,
  setRefFlag,
} from "../../redux/actions/BillingActions";
import isEmpty from "lodash/isEmpty";
import SimpleReactValidator from "simple-react-validator";
import { validationRules } from "../../utils/ValidationRules";

const INITIAL_COMMENTS = {
  customerId: "",
  memberId: "",
  commentSeqNbr: "",
  mbrComments: "",
  createTime: "",
  createUserId: "",
  invoiceNbr: "",
};

class InvoiceComments extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedCommentsVo: INITIAL_COMMENTS,
      selectedRowIndex: 0,
      invoiceHeaderDetailsSelectedVo: [],
      message: "",
      closePopup: false,
      rowsPerPage: 10,
      commentRef: React.createRef(), //creating ref for comments field
      isNewSegment: false,
      updateBtn: true,
      newComments: "",
    };

    this.validator = new SimpleReactValidator({ ...validationRules });
  }
  static getDerivedStateFromProps(nextProps, prevState) {
    if (!isEmpty(nextProps.invoiceHeaderDetailsSelectedVo)) {
      if (
        nextProps.invoiceHeaderDetailsSelectedVo.invoiceNbr !==
        prevState.invoiceHeaderDetailsSelectedVo.invoiceNbr
      ) {
        return {
          invoiceHeaderDetailsSelectedVo:
            nextProps.invoiceHeaderDetailsSelectedVo,
          selectedRowIndex: 0,
          selectedCommentsVo: !isEmpty(nextProps.commentList)
            ? nextProps.commentList[0]
            : INITIAL_COMMENTS,
          isNewSegment: false,
        };
      } else {
        if (nextProps.refFlag) {
          return {
            isNewSegment: true,
            updateBtn: nextProps.updateBtn,
          };
        } else if (
          nextProps.updateBtn !== prevState.updateBtn &&
          !nextProps.updateBtn
        ) {
          return {
            isNewSegment: !nextProps.updateBtn,
            updateBtn: nextProps.updateBtn,
          };
        } else {
        }
        return {
          updateBtn: nextProps.updateBtn,
        };
      }
    }
    return null;
  }

  componentWillUnmount() {
    const { selectedRowIndex } = this.state;
    let payload = {
      invoiceComments: selectedRowIndex,
    };
    this.props.setInvoiceTableIndex(payload);
  }

  componentDidMount() {
    const index = this.props.tableIndex;
    const { commentList } = this.props;
    this.setState({
      selectedRowIndex: index,
      selectedCommentsVo: commentList[index],
    });
  }

  handleChange = (event) => {
    let value = event.target.value;
    const { updateBtn } = this.props;
    if (!updateBtn) {
      this.props.setAdjustmentComments(value);
    } else {
      this.setState({
        newComments: value,
      });
    }
  };
  handleOnBlur = (event) => {
    let value = event.target.value.trim();
    const { updateBtn } = this.props;
    if (!updateBtn) {
      this.props.setAdjustmentComments(value);
    } else {
      this.setState({
        newComments: value,
      });
    }
  };
  modalClosed = () => {
    this.setState({ closePopup: false });
  };

  createNewSegment = () => {
    this.setState({ isNewSegment: true });
  };

  addComments = async () => {
    if (this.state.newComments === "") {
      this.setState({
        message: "Please Enter Comments",
        closePopup: true,
      });
    } else {
      const { invoiceHeaderDetailsSelectedVo } = this.props;
      const { invoiceNbr } = invoiceHeaderDetailsSelectedVo;
      const comments = this.state.newComments;
      let body = {
        mbrComments: comments,
        invoiceNbr: invoiceNbr,
      };
      const data = await this.props.saveComments(body);
      if (data.status === "OK") {
        this.setState({
          message: "Comments Added Succesfully!!!",
          closePopup: true,
          selectedRowIndex: 0,
          isNewSegment: false,
          newComments: "",
        });
      }
    }
  };

  goBack = () => {
    this.setState({ isNewSegment: false });
  };

  commentsRowSelect = (index) => {
    this.setState(
      {
        selectedRowIndex: index,
        selectedCommentsVo: this.props.commentList[index],
        isNewSegment: false,
      },
      () => this.props.setAdjustmentComments("")
    );
  };

  handleChangePage = (index) => {
    this.setState(
      {
        selectedRowIndex: index,
        selectedCommentsVo: this.props.commentList[index],
        isNewSegment: false,
      },
      () => this.props.setAdjustmentComments("")
    );
  };

  handleChangeRowsPerPage = async (rowsPerPage) => {
    this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  resetComments = () => {
    this.setState({
      newComments: "",
    });
  };

  render() {
    const {
      classes,
      commentList,
      adjustmentComments,
      servicesEnabled,
    } = this.props;
    const {
      selectedRowIndex,
      selectedCommentsVo,
      message,
      closePopup,
      rowsPerPage,
      commentRef,
      isNewSegment,
      newComments,
      updateBtn,
    } = this.state;

    return (
      <React.Fragment>
        <Modal
          dialogTitle="Invoice"
          message={message}
          show={closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>

        <ExpansionPanel summary="Comments">
          <div class="panel-body" className={classes.panelBody}>
            <div>
              <DataTable
                data={commentList}
                header={INVOICE_COMMENTS_HEADER}
                rowsPerPage={rowsPerPage}
                rowsPerPageOptions={[5, 10, 15, 20]}
                clicked={this.commentsRowSelect}
                handleChangeRowsPerPage={this.handleChangeRowsPerPage}
                index={selectedRowIndex}
                handleChangePage={this.handleChangePage}
              />
            </div>
            <div className={classes.buttonContainer}>
              {servicesEnabled.includes("EEUB") ? (
                <Button
                  variant="contained"
                  color="primary"
                  id="newCommentButton"
                  className={classes.buttonFitToText}
                  onClick={this.createNewSegment}
                  disabled={isNewSegment || (isNewSegment && !updateBtn)}
                >
                  New Comment
                </Button>
              ) : null}
            </div>
            <div id="invoiceCommentsBox">
              <TextField
                name="mbrComments"
                id="comments"
                placeholder="Enter Comments (Max 255 characters)"
                multiline
                inputRef={commentRef}
                rows="2"
                className={classes.invoiceTextField}
                inputProps={{ maxLength: 255 }}
                onChange={this.handleChange}
                onBlur={this.handleOnBlur}
                value={
                  !isNewSegment && selectedCommentsVo
                    ? selectedCommentsVo.mbrComments
                    : !updateBtn
                    ? adjustmentComments
                    : newComments
                }
                margin="none"
                variant="outlined"
                disabled={isNewSegment ? false : !updateBtn ? false : true}
              />
            </div>

            <HistoryData
              createTime={
                selectedCommentsVo ? selectedCommentsVo.createTime : ""
              }
              createUserId={
                selectedCommentsVo ? selectedCommentsVo.createUserId : ""
              }
              footer="true"
              isNewSegment={!updateBtn ? false : isNewSegment}
              reset={this.resetComments}
              addSegment={this.addComments}
              back={this.goBack}
            />
          </div>
        </ExpansionPanel>
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    invoiceHeaderDetailsSelectedVo:
      state.billingReducer.invoice.invoiceSearchResults
        .billingInvHeaderDtlsVOs[0],
    commentList: state.billingReducer.invoice.invoiceSearchResults.commentList,
    tableIndex: state.billingReducer.invoice.tableIndexes.invoiceComments,
    adjustmentComments: state.billingReducer.invoice.adjustmentComments,
    refFlag: state.billingReducer.invoice.refFlag,
    servicesEnabled: state.loginData.servicesEnabled,
  };
};

const mapDispatchToProps = {
  saveComments,
  setInvoiceTableIndex,
  setAdjustmentComments,
  setRefFlag,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(InvoiceComments));
