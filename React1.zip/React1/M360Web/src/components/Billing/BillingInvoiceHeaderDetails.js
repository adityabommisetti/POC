import HistoryData from "../UI/MemberHistory";
import React from "react";
import ExpansionPanel from "../UI/ExpansionPanel";
import InputField from "../UI/InputField";
import { Styles } from "../../assets/styles/Theme";
import { withStyles } from "@material-ui/core/styles";
import { connect } from "react-redux";
import formatTimeStamp from "../../utils/Utils";

const InvoiceHeaderDetails = (props) => {
  const { classes, invoiceHeaderDetailsSelectedVo, loginProfile } = props;

  const MBRIDLIT = loginProfile.filter((data) => data.label === "MBRIDLIT");

  const mbrIdLit = MBRIDLIT[0];
  return (
    <ExpansionPanel summary="Invoice Header Details">
      <div class="panel-body" className={classes.panelBody}>
        <div className={classes.container}>
          <div className={classes.invoiceHeaderDiv}>
            <InputField
              width="215px"
              name="invoiceNbr"
              label="Invoice Nbr"
              value={invoiceHeaderDetailsSelectedVo.invoiceNbr}
              disabled
            />
          </div>
          <div className={classes.invoiceHeaderDiv}>
            <InputField
              width="215px"
              name="invoiceType"
              label="Invoice Type"
              value={invoiceHeaderDetailsSelectedVo.displayInvType}
              disabled
            />
          </div>
          <div className={classes.invoiceHeaderDiv}>
            <InputField
              width="215px"
              name="invoiceMemberId"
              label={mbrIdLit.value === "TSA" ? "Wipro ID" : "M360 ID"}
              value={invoiceHeaderDetailsSelectedVo.invoiceId}
              disabled
            />
          </div>
          <div className={classes.invoiceHeaderDiv}>
            <InputField
              width="215px"
              name="dueDate"
              label="Due Date"
              value={invoiceHeaderDetailsSelectedVo.dueDateFrmt}
              disabled
            />
          </div>
          <div className={classes.invoiceHeaderDiv}>
            <InputField
              width="215px"
              name="billThruDate"
              label="Bill Thru Date"
              value={invoiceHeaderDetailsSelectedVo.billThruDateFrmt}
              disabled
            />
          </div>
          <div className={classes.invoiceHeaderDiv}>
            <InputField
              width="215px"
              name="invoiceStatus"
              label="Invoice Status"
              value={invoiceHeaderDetailsSelectedVo.invoiceStatusDesc}
              disabled
            />
          </div>
          <div className={classes.invoiceHeaderDiv}>
            <InputField
              width="215px"
              name="invoiceAmount"
              label="Invoice Amt"
              value={invoiceHeaderDetailsSelectedVo.invoiceAmt}
              disabled
            />
          </div>
          <div className={classes.invoiceHeaderDiv}>
            <InputField
              width="215px"
              name="adjustmentAmount"
              label="Adjustment Amt"
              value={invoiceHeaderDetailsSelectedVo.adjustmentAmt}
              disabled
            />
          </div>
          <div className={classes.invoiceHeaderDiv}>
            <InputField
              width="215px"
              name="paymentAmount"
              label="Payment Amt"
              value={invoiceHeaderDetailsSelectedVo.paymentAmt}
              disabled
            />
          </div>
          <div className={classes.invoiceHeaderDiv}>
            <InputField
              width="215px"
              name="totalAmount"
              label="Final Amt"
              value={invoiceHeaderDetailsSelectedVo.totalAmt}
              disabled
            />
          </div>
          <div className={classes.invoiceHeaderDiv}>
            <InputField
              width="215px"
              name="wipUserId"
              label="WIP User ID"
              value={invoiceHeaderDetailsSelectedVo.wipUserId}
              disabled
            />
          </div>
          <div className={classes.invoiceHeaderDiv}>
            <InputField
              width="215px"
              name="wipTime"
              label="WIP Time"
              value={formatTimeStamp(invoiceHeaderDetailsSelectedVo.wipTime)}
              disabled
            />
          </div>
          <div className={classes.invoiceHeaderDiv}>
            <InputField
              width="215px"
              name="frequencyDesc"
              label="Frequency"
              value={invoiceHeaderDetailsSelectedVo.frequencyDesc}
              disabled
            />
          </div>
        </div>
        <HistoryData
          createTime={invoiceHeaderDetailsSelectedVo.createTime}
          createUserId={invoiceHeaderDetailsSelectedVo.createUserId}
          lastUpdtTime={invoiceHeaderDetailsSelectedVo.lastUpdtTime}
          lastUpdtUserId={invoiceHeaderDetailsSelectedVo.lastUpdtUserId}
          footer="true"
        />
      </div>
    </ExpansionPanel>
  );
};

const mapStateToProps = (state) => {
  return {
    invoiceHeaderDetailsSelectedVo:
      state.billingReducer.invoice.invoiceSearchResults
        .billingInvHeaderDtlsVOs[0],
    loginProfile: state.loginData.profiles,
  };
};

const mapDispatchToProps = {};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(InvoiceHeaderDetails));
