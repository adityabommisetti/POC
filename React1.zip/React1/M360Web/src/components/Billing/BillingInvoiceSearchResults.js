import React, { Component } from "react";
import DataTable from "../Home/DataTable";
import ExpansionPanel from "../UI/ExpansionPanel";
import { Styles } from "../../assets/styles/Theme";
import { withStyles } from "@material-ui/core/styles";
import { connect } from "react-redux";
import isEmpty from "lodash/isEmpty";
import {
  invoiceSearchSelect,
  setInvoiceTableIndex,
  invoiceSearchNext,
} from "../../redux/actions/BillingActions";
import { INVOICE_HEADER as header } from "../../constants/Headers/BillingHeaders";

class InvoiceSearchResults extends Component {
  constructor(props) {
    super(props);
    this.state = {
      closePopup: false,
      message: "",
      selectedRowIndex: 0,
      rowsPerPage: 10,
    };
  }
  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.compareFlag) {
      nextProps.setFlag(false);
      return { selectedRowIndex: 0 };
    }
    return null;
  }
  componentWillUnmount() {
    const { selectedRowIndex } = this.state;
    let payload = {
      invoiceHeaderDetails: selectedRowIndex,
    };
    this.props.setInvoiceTableIndex(payload);
  }

  componentDidMount() {
    const index = this.props.tableIndex;
    this.setState({
      selectedRowIndex: index,
    });
  }

  handleChangeRowsPerPage = (rowsPerPage) => {
    this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  handleChangePage = async (index) => {};

  invoiceHeaderDetailsRowSelect = async (index, selectedData, rowsPerPage) => {
    await this.props.invoiceSearchSelect(selectedData);
    this.setState({
      rowsPerPage: rowsPerPage,
      selectedRowIndex: index,
    });
  };

  fetchMoreResults = async (pageNo) => {
    const { searchCriteriaVo, invoiceHeaderDetailsList } = this.props;
    const lastIndex = invoiceHeaderDetailsList.length - 1;
    const { dueDate, invoiceNbr, invoiceId } = invoiceHeaderDetailsList[
      lastIndex
    ];

    let payload = {
      ...searchCriteriaVo,
      dueDate: dueDate,
      searchInvoiceNbr: invoiceNbr,
      searchInvoiceId: invoiceId,
    };
    await this.props.invoiceSearchNext(payload);
    this.setState({ selectedRowIndex: pageNo * this.state.rowsPerPage });
  };

  modalClosed = () => {
    this.setState({
      closePopup: false,
    });
  };

  render() {
    const { rowsPerPage, selectedRowIndex } = this.state;
    const { invoiceHeaderDetailsList, invoiceSearchResults } = this.props;
    return (
      <ExpansionPanel summary="Search Result">
        <DataTable
          data={isEmpty(invoiceHeaderDetailsList)?[]:invoiceHeaderDetailsList}
          header={header}
          rowsPerPage={rowsPerPage}
          sortable={true}
          rowsPerPageOptions={[5, 10, 15, 20]}
          clicked={this.invoiceHeaderDetailsRowSelect}
          index={selectedRowIndex}
          handleChangeRowsPerPage={this.handleChangeRowsPerPage}
          handleChangePage={this.handleChangePage}
          fetchMore={this.fetchMoreResults}
          nextPage={invoiceSearchResults.nextPage}
          searchable={true}
          exportAsExcel={true}
          dateColumn="dueDateFrmt"
        />
      </ExpansionPanel>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    invoiceSearchResults: state.billingReducer.invoice.invoiceSearchResults,
    invoiceHeaderDetailsList: state.billingReducer.invoice.oldResults,
    tableIndex: state.billingReducer.invoice.tableIndexes.invoiceHeaderDetails,
  };
};

const mapDispatchToProps = {
  invoiceSearchSelect,
  setInvoiceTableIndex,
  invoiceSearchNext,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(InvoiceSearchResults));
