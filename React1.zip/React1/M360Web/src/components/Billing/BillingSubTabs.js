import AppBar from "@material-ui/core/AppBar";
import NoSsr from "@material-ui/core/NoSsr";
import { withStyles } from "@material-ui/core/styles";
import Tab from "@material-ui/core/Tab";
import Tabs from "@material-ui/core/Tabs";
import Typography from "@material-ui/core/Typography";
import React from "react";
import { connect } from "react-redux";
import { getBillingCacheData } from "../../redux/actions/BillingActions";
import * as ActionTypes from "../../redux/types/ActionType";
import * as URL from "../../services/API_URL";
import Draft from "./BillingDraft";
import Invoice from "./BillingInvoice";
import MemberPayments from "./BillingMbrPayment";
import PaymentEntry from "./BillingPaymentEntry";
import ErrorBoundary from "../Error/ErrorBoundary";
import isEmpty from "lodash/isEmpty";
function TabContainer(props) {
  return (
    <Typography component="div" style={{ padding: 8 }}>
      {props.children}
    </Typography>
  );
}

function LinkTab(props) {
  return (
    <Tab component="a" onClick={(event) => event.preventDefault()} {...props} />
  );
}

const Styles = (theme) => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
  },
  bigIndicator: {
    height: 2,
    backgroundColor: "white",
  },
});

class NavTabs extends React.Component {
  state = {
    value: 0,
  };
  async componentDidMount() {
    if (isEmpty(this.props.CacheData))
      await this.props.getBillingCacheData(
        URL.BILLING_CACHE_DATA,
        ActionTypes.BILLING_CACHE_DATA
      );
  }
  handleChange = (event, value) => {
    this.setState({ value });
  };

  render() {
    const { classes } = this.props;
    const { value } = this.state;

    return (
      <NoSsr>
        <div className={classes.root}>
          <AppBar position="static">
            <Tabs
              variant="fullWidth"
              value={value}
              onChange={this.handleChange}
              classes={{
                indicator: classes.bigIndicator,
              }}
            >
              <LinkTab label="Invoice" href="page1" />
              <LinkTab label="Payment Entry" href="page2" />
              <LinkTab label="Member Payments" href="page3" />
              <LinkTab label="Draft" href="page4" />
            </Tabs>
          </AppBar>

          {value === 0 && (
            <TabContainer>
              <ErrorBoundary>
                <Invoice />
              </ErrorBoundary>
            </TabContainer>
          )}
          {value === 1 && (
            <TabContainer>
              <ErrorBoundary>
                <PaymentEntry />
              </ErrorBoundary>
            </TabContainer>
          )}
          {value === 2 && (
            <TabContainer>
              <ErrorBoundary>
                <MemberPayments />
              </ErrorBoundary>
            </TabContainer>
          )}
          {value === 3 && (
            <TabContainer>
              <ErrorBoundary>
                <Draft />
              </ErrorBoundary>
            </TabContainer>
          )}
        </div>
      </NoSsr>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    CacheData: state.billingReducer.bilingCacheData,
  };
};

const mapDispatchToProps = {
  getBillingCacheData,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(NavTabs));
