import { INVOICE_DETAILS_HEADER } from "../../constants/Headers/BillingHeaders";
import HistoryData from "../UI/MemberHistory";
import React, { Component } from "react";
import AutoComplete1 from "../UI/Select";
import Button from "@material-ui/core/Button";
import DataTable from "../Home/DataTable";
import Popup from "reactjs-popup";
import ExpansionPanel from "../UI/ExpansionPanel";
import InputField from "../UI/InputField";
import { Styles } from "../../assets/styles/Theme";
import { withStyles } from "@material-ui/core/styles";
import { connect } from "react-redux";
import {
  getDetailAmount,
  adjustmentUpdate,
  invoiceTransfer,
  setInvoiceTableIndex,
  setAdjustmentComments,
  setRefFlag,
} from "../../redux/actions/BillingActions";
import InvoiceTransferPopUp from "./BillingTransferPopUp";
import SimpleReactValidator from "simple-react-validator";
import Modal from "../UI/Modal/Modal";
import isEmpty from "lodash/isEmpty";
import scrollTo from "../../utils/ScrollToElement";
import formatTimeStamp from "../../utils/Utils";

const SELECT_OBJECT = {
  label: "Select",
  value: "",
};
class InvoiceDetails extends Component {
  constructor(props) {
    super(props);
    const { invoiceHeaderDetailsSelectedVo } = this.props;
    this.state = {
      mbridLit: [],
      message: "",
      updateBtn: true,
      rowsPerPage: 10,
      closePopup: false,
      transferBtn: false,
      selectedRowIndex: 0,
      functionOptions: {},
      transferVo: {
        transGrpId: 0,
        transName: " ",
        transAmt: 0,
      },
      adjustmentVo: {
        functionCdDesc: "",
        functionCd: "",
        bankAcctCd: "",
        detailAmt: "",
        xrefInvoiceNbr: "",
        reasonCd: "",
        reasonCdDesc: "",
      },
      invoiceHeaderDetailsSelectedVo: invoiceHeaderDetailsSelectedVo,
    };
    this.validator = new SimpleReactValidator({
      messages: {
        required: ":attribute is required",
      },
    });
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    const { invoiceHeaderDetailsSelectedVo } = nextProps;
    if (
      invoiceHeaderDetailsSelectedVo !==
      prevState.invoiceHeaderDetailsSelectedVo
    ) {
      nextProps.setAdjustmentComments("");
      return {
        invoiceHeaderDetailsSelectedVo: invoiceHeaderDetailsSelectedVo,
        selectedRowIndex: 0,
        transferBtn: false,
        updateBtn: true,
      };
    }
    return null;
  }

  componentWillUnmount() {
    const { selectedRowIndex } = this.state;
    let payload = {
      invoiceDetails: selectedRowIndex,
    };
    this.props.setInvoiceTableIndex(payload);
  }

  componentDidMount() {
    this.functionOptions();
    const index = this.props.tableIndex;
    const { loginProfile } = this.props;
    const MBRIDLIT = loginProfile.filter((data) => data.label === "MBRIDLIT");
    this.setState({
      mbridLit: MBRIDLIT[0],
      selectedRowIndex: index,
    });
  }

  handleOnBlur = (event, targetVo) => {
    let value = event.target.value;
    let name = event.target.name;
    this.setState((prevState) => ({
      ...prevState,
      [targetVo]: {
        ...prevState[targetVo],
        [name]: value.trim(),
      },
    }));
  };
  handleChange = (event, targetVo) => {
    let value = event.target.value;
    let name = event.target.name;
    if (name === "detailAmt" || name === "xrefInvoiceNbr") {
      value =
        name === "detailAmt"
          ? value.replace(/[^(\-)0-9.]/g, "")
          : value.replace(/[^0-9]/g, "");
    }
    this.setState((prevState) => ({
      ...prevState,
      [targetVo]: {
        ...prevState[targetVo],
        [name]: value.toUpperCase(),
      },
    }));
  };

  modalClosed = () => {
    this.setState({ closePopup: false });
    if (this.state.message === "Please Enter Comments") {
      scrollTo("invoiceCommentsBox");
      this.props.setRefFlag(false);
    }
  };

  handleChangeSearchSelect = (name) => (event) => {
    const { lstFunctionCode, invoiceDetailsList } = this.props;
    const { selectedRowIndex } = this.state;
    const invoiceDetailsSelectedVo = invoiceDetailsList[selectedRowIndex];
    let value = event.value ? event.value : "";
    let label = event.label;
    this.functionOptions();
    const data = lstFunctionCode.filter((data) => data.functionCd === value);
    let bankAcctCd = !isEmpty(data) ? data[0].bankAcctCd : "";
    if (value === "") {
      this.setState((prevState) => ({
        adjustmentVo: {
          ...prevState.adjustmentVo,
          functionCdDesc: label,
          [name]: value,
          bankAcctCd: "",
          detailAmt: "",
          reasonCd: "",
        },
      }));
    } else if (value === "MCR" || value === "RER" || value === "WTO") {
      this.setState((prevState) => ({
        adjustmentVo: {
          ...prevState.adjustmentVo,
          functionCdDesc: label,
          [name]: value,
          bankAcctCd: bankAcctCd,
          reasonCd: "",
          detailAmt:
            "-" +
            Math.abs(parseFloat(invoiceDetailsSelectedVo.detailAmt))
              .toFixed(2)
              .toString(),
        },
      }));
    } else {
      this.setState((prevState) => ({
        adjustmentVo: {
          ...prevState.adjustmentVo,
          functionCdDesc: label,
          [name]: value,
          bankAcctCd: bankAcctCd,
          reasonCd: "",
          detailAmt: Math.abs(parseFloat(invoiceDetailsSelectedVo.detailAmt))
            .toFixed(2)
            .toString(),
        },
      }));
    }
  };

  handleReasonSelect = (name) => (event) => {
    let value = event.value ? event.value : "";
    let label = event.label;
    this.setState(
      (prevState) => ({
        adjustmentVo: {
          ...prevState.adjustmentVo,
          reasonCdDesc: label,
          [name]: value,
          mbrComments: label,
        },
      }),
      () => this.props.setAdjustmentComments(label)
    );
  };

  adjustmentButtonClick = () => {
    this.setState((prevState) => ({
      updateBtn: false,
      transferBtn: false,
      adjustmentVo: {
        ...prevState.adjustmentVo,
        bankAcctCd: "",
        detailAmt: "",
        functionCd: "",
        reasonCd: "",
      },
    }));
  };

  updateTransferVo = (data) => {
    this.setState((prevState) => ({
      transferVo: {
        ...prevState.transferVo,
        transGrpId: data.grpId,
        transName: data.groupName,
      },
    }));
  };

  adjustmentUpdate = async () => {
    const {
      invoiceHeaderDetailsSelectedVo,
      invoiceDetailsList,
      searchInvoiceGroup,
      adjustmentComments,
    } = this.props;
    const { adjustmentVo, selectedRowIndex } = this.state;
    const invoiceDetailsSelectedVo = invoiceDetailsList[selectedRowIndex];
    const {
      functionCd,
      reasonCd,
      detailAmt,
      xrefInvoiceNbr,
      functionCdDesc,
      reasonCdDesc,
      bankAcctCd,
    } = adjustmentVo;
    const regexExp = /^\s*-?(\d+(\.\d+)?|\.\d+)\s*$/; //To check amount is valid or not
    if (functionCd === "") {
      this.setState({ message: "Please Select functionCd", closePopup: true });
    } else if (detailAmt === "" || !regexExp.test(detailAmt)) {
      this.setState({ message: "Please Enter Valid Amount", closePopup: true });
    } else if (reasonCd === "" && functionCd === "REF") {
      this.setState({
        message: "Please Select Refund Reason",
        closePopup: true,
      });
    } else if (adjustmentComments === "") {
      this.setState(
        {
          message: "Please Enter Comments",
          closePopup: true,
        },
        () => {
          this.props.setRefFlag(true);
        }
      );
    } else {
      let body = {
        billHeaderVO: invoiceHeaderDetailsSelectedVo,
        billInvVO: {
          ...invoiceDetailsSelectedVo,
          functionCd: functionCd,
          bankAcctCd: bankAcctCd,
          detailAmt: detailAmt,
          xrefInvoiceNbr: xrefInvoiceNbr,
          functionCdDesc: functionCdDesc,
          reasonCd: reasonCd,
          reasonCdDesc: reasonCdDesc,
        },
        billInvCommentVO: {
          mbrComments: adjustmentComments,
          invoiceNbr: invoiceDetailsSelectedVo.invoiceNbr,
        },
        searchInvoiceGroup: searchInvoiceGroup,
        memberId: invoiceDetailsSelectedVo.memberId,
      };

      const data = await this.props.adjustmentUpdate(body);

      if (data.message === "SUCCESS") {
        const { invoiceDetailsList } = this.props;
        const length = invoiceDetailsList.length - 1;
        this.setState(
          (prevState) => ({
            message: "Adjustment Sucessful",
            closePopup: true,
            updateBtn: true,
            selectedRowIndex: length,
          }),
          () => this.props.setAdjustmentComments("")
        );
      } else {
        this.setState((prevState) => ({
          message: data.message,
          closePopup: true,
        }));
      }
    }
  };

  transfer = async () => {
    if (this.validator.allValid()) {
      const { invoiceHeaderDetailsSelectedVo, invoiceDetailsList } = this.props;
      const { transferVo, selectedRowIndex } = this.state;
      const invoiceDetailsSelectedVo = invoiceDetailsList[selectedRowIndex];
      const { transGrpId, transName, transAmt } = transferVo;
      let body = {
        billHeaderVO: invoiceHeaderDetailsSelectedVo,
        billInvVO: invoiceDetailsSelectedVo,
        transGrpId: transGrpId,
        transName: transName,
        transAmt: transAmt,
      };
      const data = await this.props.invoiceTransfer(body);
      if (data.status === "OK") {
        const { invoiceDetailsList } = this.props;
        const length = invoiceDetailsList.length - 1;
        this.setState({
          selectedRowIndex: length,
          message: "Transfer Succesfull",
          closePopup: true,
          transferBtn: false,
        });
      } else {
        this.setState({
          message: data.message,
          closePopup: true,
        });
      }
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };
  transferBtnClick = async () => {
    const { invoiceDetailsList } = this.props;
    const { selectedRowIndex } = this.state;
    const {
      functionCd,
      lineStatus,
      itemNbr,
      customerId,
      invoiceNbr,
    } = invoiceDetailsList[selectedRowIndex];
    if (functionCd !== "PAY" && functionCd !== "TRT" && functionCd !== "TTM") {
      this.setState({
        message: "Invalid function Code - " + functionCd,
        closePopup: true,
      });
    } else if (lineStatus !== "A") {
      this.setState({
        message: "Invalid Line status",
        closePopup: true,
      });
    } else {
      let body = {
        itemNbr: itemNbr,
        customerId: customerId,
        invoiceNbr: invoiceNbr,
      };
      const data = await this.props.getDetailAmount(body);
      if (data.message === "SUCCESS") {
        let detailAmt = parseFloat(data.data);
        detailAmt = detailAmt * -1;
        detailAmt = detailAmt.toFixed(2);
        if (detailAmt > 0) {
          this.setState((prevState) => ({
            ...prevState.transferVo,
            transferVo: {
              transAmt: detailAmt,
            },
            transferBtn: true,
            updateBtn: true,
          }));
        } else {
          this.setState({
            message: "Insufficient funds to transfer",
            closePopup: true,
          });
        }
      }
    }
  };
  invoiceDetailsRowSelect = async (selectedIndex, rowsPerPage) => {
    this.setState(
      (prevState) => ({
        selectedRowIndex: selectedIndex,
        updateBtn: true,
        transferBtn: false,
        rowsPerPage: rowsPerPage > 5 ? rowsPerPage : 10,
      }),
      () => this.props.setAdjustmentComments("")
    );
  };
  handleChangeRowsPerPage = async (rowsPerPage) => {
    this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  functionOptions = () => {
    const { lstFunctionCode } = this.props;
    const options = lstFunctionCode
      ? lstFunctionCode.map((data) => {
        return {
          label: data.functionCd + "-" + data.shortDesc,
          value: data.functionCd,
        };
      })
      : {};
    const functionOptions = !isEmpty(Object.keys(options))
      ? [SELECT_OBJECT, ...options]
      : [SELECT_OBJECT];
    this.setState({
      functionOptions: functionOptions,
    });
  };
  render() {
    const {
      classes,
      lstRefReasonCode,
      invoiceDetailsList,
      servicesEnabled,
    } = this.props;
    const {
      invoiceHeaderDetailsSelectedVo,
      transferVo,
      transferBtn,
      updateBtn,
      selectedRowIndex,
      message,
      adjustmentVo,
      closePopup,
      functionOptions,
      rowsPerPage,
      mbridLit,
    } = this.state;
    const invoiceDetailsSelectedVo = invoiceDetailsList[selectedRowIndex];
    this.props.setUpdateBtn(updateBtn);
    return (
      <React.Fragment>
        <Modal
          dialogTitle="Invoice"
          message={message}
          show={closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        {!isEmpty(invoiceDetailsList) ? (
          <>
            <ExpansionPanel summary="Invoice Details">
              <div class="panel-body" className={classes.panelBody}>
                <DataTable
                  data={invoiceDetailsList}
                  header={INVOICE_DETAILS_HEADER}
                  rowsPerPage={rowsPerPage}
                  rowsPerPageOptions={[5, 10, 15, 20]}
                  clicked={this.invoiceDetailsRowSelect}
                  index={selectedRowIndex}
                  handleChangeRowsPerPage={this.handleChangeRowsPerPage}
                />
                <div className={classes.buttonContainer}>
                  {servicesEnabled.includes("EEUB") ? (
                    <Button
                      variant="contained"
                      color="primary"
                      className={classes.buttonFitToText}
                      onClick={this.transferBtnClick}
                      disabled={transferBtn}
                    >
                      Transfer
                    </Button>
                  ) : null}
                  {servicesEnabled.includes("EEUB") ||
                    servicesEnabled.includes("BNSF") ? (
                      <Button
                        variant="contained"
                        color="primary"
                        className={classes.buttonFitToText}
                        onClick={this.adjustmentButtonClick}
                        disabled={!updateBtn}
                      >
                        Adjustment
                      </Button>
                    ) : null}
                  <Button
                    variant="contained"
                    color="primary"
                    className={classes.buttonFitToText}
                    disabled={updateBtn}
                    onClick={this.adjustmentUpdate}
                  >
                    Update
                  </Button>
                </div>
                {transferBtn ? (
                  <>
                    <div class="panel-subhead">
                      <h3>Transfer Details</h3>
                    </div>
                    <div className={classes.confirmTransferBtn}>
                      <Button
                        variant="contained"
                        color="primary"
                        className={classes.buttonFitToText}
                        onClick={this.transfer}
                      >
                        Confirm Transfer
                      </Button>
                    </div>
                    <h6 className={classes.invoiceTransferText}>
                      <b>Current detail - Transfer From:</b>
                    </h6>
                    <div className={classes.container}>
                      <div className={classes.invoiceTransferDiv}>
                        <InputField
                          name="invoiceTransferMemberId"
                          label={
                            mbridLit.value === "TSA" ? "Wipro ID" : "M360 ID"
                          }
                          value={invoiceDetailsSelectedVo.memberId}
                          disabled
                        />
                      </div>
                      <div style={{ width: "359px" }}>
                        <InputField
                          name="lastName"
                          label="Name"
                          value={invoiceHeaderDetailsSelectedVo.name}
                          disabled
                          width="334px"
                        />
                      </div>
                      <div className={classes.invoiceTransferDiv}>
                        <InputField
                          name="subProductDesc"
                          label="Description"
                          value={invoiceDetailsSelectedVo.subProductDesc}
                          disabled
                        />
                      </div>
                      <div className={classes.invoiceTransferDiv}>
                        <InputField
                          name="functionCdDesc"
                          label="Function"
                          value={invoiceDetailsSelectedVo.functionCdDesc}
                          disabled
                        />
                      </div>
                      <div className={classes.invoiceTransferDiv}>
                        <InputField
                          name="bankAcctCd"
                          label="Bank Code"
                          value={invoiceDetailsSelectedVo.bankAcctCd}
                          disabled
                        />
                      </div>
                      <div className={classes.invoiceTransferDiv}>
                        <InputField
                          name="checkNbr"
                          label="Check"
                          value={invoiceDetailsSelectedVo.checkNbr}
                          disabled
                        />
                      </div>
                      <div className={classes.invoiceTransferDiv}>
                        <InputField
                          name="batchSeq"
                          label="Batch Seq"
                          value={invoiceDetailsSelectedVo.payBatchSeqNbr}
                          disabled
                        />
                      </div>
                      <div className={classes.invoiceTransferDiv}>
                        <InputField
                          name="lineItem"
                          label="Line Item"
                          value={invoiceDetailsSelectedVo.payItemNbr}
                          disabled
                        />
                      </div>
                      <div className={classes.invoiceTransferDiv}>
                        <InputField
                          name="paySource"
                          label="Pay Source"
                          value={invoiceDetailsSelectedVo.paySourceDesc}
                          disabled
                        />
                      </div>
                      <div className={classes.invoiceTransferDiv}>
                        <InputField
                          name="payBatchDate"
                          label="Batch"
                          value={invoiceDetailsSelectedVo.payBatchDate}
                          disabled
                        />
                      </div>
                      <div className={classes.invoiceTransferDiv}>
                        <InputField
                          name="payItemNbr"
                          label="Batch Item"
                          value={invoiceDetailsSelectedVo.payItemNbr}
                          disabled
                        />
                      </div>
                      <div className={classes.invoiceTransferDiv}>
                        <InputField
                          name="detailAmt"
                          label="Detail Amt"
                          value={invoiceDetailsSelectedVo.detailAmt}
                          disabled
                        />
                      </div>
                    </div>

                    <h6 className={classes.invoiceTransferText}>
                      <b>Current detail - Transfer To:</b>
                    </h6>

                    <div className={classes.container}>
                      <div className={classes.invoiceTransferDiv1}>
                        <InputField
                          required
                          name="transGrpId"
                          maxLength={15}
                          label={
                            mbridLit.value === "TSA" ? "Wipro ID" : "M360 ID"
                          }
                          value={transferVo.transGrpId}
                          onChange={(e) => this.handleChange(e, "transferVo")}
                          onBlur={(e) => this.handleOnBlur(e, "transferVo")}
                          width="170px"
                        />
                        <div className={classes.validationMessage}>
                          {this.validator.message(
                            mbridLit.value === "TSA" ? "Wipro ID" : "M360 ID",
                            transferVo.transGrpId,
                            "required"
                          )}
                        </div>
                      </div>
                      <div>
                        <Popup
                          style={{ height: "45%", paddingTop: "19px" }}
                          className={classes.mobileWidth}
                          modal
                          trigger={
                            <span
                              class="more-info"
                              style={{ paddingTop: "19px" }}
                            />
                          }
                          position="right center"
                        >
                          {(close) => (
                            <div>
                              <InvoiceTransferPopUp
                                close={close}
                                setData={this.updateTransferVo}
                                searchTransGrp={transferVo.transGrpId}
                              />
                            </div>
                          )}
                        </Popup>
                      </div>
                      <div className={classes.invoiceTransferDiv2}>
                        <InputField
                          width="516px"
                          name="name"
                          label="Name"
                          value={transferVo.transName}
                          disabled
                        />
                      </div>
                      <div className={classes.invoiceTransferDiv3}>
                        <InputField
                          maxLength={10}
                          required
                          name="transAmt"
                          label="Transfer Amt"
                          value={transferVo.transAmt}
                          onChange={(e) => this.handleChange(e, "transferVo")}
                          onBlur={(e) => this.handleOnBlur(e, "transferVo")}
                        />
                        <div className={classes.validationMessage}>
                          {this.validator.message(
                            "Transfer Amount",
                            transferVo.transAmt,
                            "required"
                          )}
                        </div>
                      </div>
                    </div>
                  </>
                ) : (
                    <>
                      <div className={classes.container}>
                        <div className={classes.invoiceAdjustmentDiv}>
                          <InputField
                            width="215px"
                            name="itemNbr"
                            label="Item"
                            value={invoiceDetailsSelectedVo.itemAddNbr}
                            disabled
                          />
                        </div>
                        <div className={classes.invoiceAdjustmentDiv}>
                          <InputField
                            width="215px"
                            name="lineStatusDesc"
                            label="Status"
                            value={invoiceDetailsSelectedVo.lineStatusDesc}
                            disabled
                          />
                        </div>
                        <div className={classes.invoiceAdjustmentDiv}>
                          <InputField
                            width="215px"
                            name="invoiceAdjustmentMemberId"
                            label={
                              mbridLit.value === "TSA" ? "Wipro ID" : "M360 ID"
                            }
                            value={invoiceDetailsSelectedVo.memberId}
                            disabled
                          />
                        </div>

                        <div className={classes.invoiceAdjustmentDiv}>
                          <InputField
                            width="215px"
                            name="groupName"
                            label="Group"
                            value={invoiceDetailsSelectedVo.groupName}
                            disabled
                          />
                        </div>
                        <div className={classes.invoiceAdjustmentDiv1}>
                          <InputField
                            width="440px"
                            name="productName"
                            label="Product"
                            value={invoiceDetailsSelectedVo.productName}
                            disabled
                          />
                        </div>
                        <div className={classes.invoiceAdjustmentDiv}>
                          <InputField
                            width="215px"
                            name="subProductDesc"
                            label="Sub Product"
                            value={invoiceDetailsSelectedVo.subProductDesc}
                            disabled
                          />
                        </div>
                        <div className={classes.invoiceAdjustmentDiv}>
                          <InputField
                            width="215px"
                            name="itemDescription"
                            label="Description"
                            value={invoiceDetailsSelectedVo.itemDesc}
                            disabled
                          />
                        </div>
                        <div className={classes.invoiceAdjustmentDiv}>
                          {!updateBtn ? (
                            // <Select
                            //   width="215px"
                            //   components={components}
                            //   label="Function"
                            //   propertyName={functionOptions.filter((option) =>
                            //     option.value === adjustmentVo.functionCd
                            //       ? option.label
                            //       : ""
                            //   )}
                            //   options={functionOptions}
                            //   textFieldProps={{
                            //     label: "Function",
                            //     InputLabelProps: {
                            //       className: classes.label,
                            //       shrink: true,
                            //     },
                            //   }}
                            //   className={classes.textFieldSelect}
                            //   handleChange={this.handleChangeSearchSelect(
                            //     "functionCd",
                            //     "adjustmentVo"
                            //   )}
                            //   isDisabled={updateBtn}
                            //   classes={classes}
                            // />
                            <AutoComplete1
                              width="215px"
                              margin="0px"
                              fontSize="0.718em"
                              options={functionOptions}
                              handleChange={this.handleChangeSearchSelect(
                                "functionCd",
                                "adjustmentVo"
                              )}
                              defaultValue={{
                                label: "Select",
                                value: "",
                              }}
                              value={adjustmentVo.functionCd}
                              label="Function"
                              name="functionCd"
                            />
                          ) : (
                              <InputField
                                width="215px"
                                name="functionCd"
                                label="Function"
                                value={invoiceDetailsSelectedVo.dispFunctionCdDesc}
                                disabled
                              />
                            )}
                        </div>

                        <div className={classes.invoiceAdjustmentDiv}>
                          <InputField
                            width="215px"
                            name="checkNbr"
                            label="Check"
                            value={invoiceDetailsSelectedVo.checkNbr}
                            disabled
                          />
                        </div>
                        <div className={classes.invoiceAdjustmentDiv}>
                          <InputField
                            maxLength={10}
                            width="215px"
                            name="detailAmt"
                            label="Detail Amt"
                            value={
                              !updateBtn
                                ? adjustmentVo.detailAmt
                                : invoiceDetailsSelectedVo.detailAmt
                            }
                            onChange={(e) => {
                              this.handleChange(e, "adjustmentVo");
                            }}
                            onBlur={(e) => this.handleOnBlur(e, "adjustmentVo")}
                            disabled={updateBtn}
                          />
                        </div>
                        <div className={classes.invoiceAdjustmentDiv}>
                          <InputField
                            maxLength={4}
                            width="215px"
                            name="bankAcctCd"
                            label="Bank Code"
                            value={
                              !updateBtn
                                ? adjustmentVo.bankAcctCd
                                : invoiceDetailsSelectedVo.bankAcctCd
                            }
                            onChange={(e) => {
                              this.handleChange(e, "adjustmentVo");
                            }}
                            onBlur={(e) => this.handleOnBlur(e, "adjustmentVo")}
                            disabled={updateBtn}
                          />
                        </div>

                        <div className={classes.invoiceAdjustmentDiv}>
                          <InputField
                            width="215px"
                            maxLength={10}
                            name="xrefInvoiceNbr"
                            label="Xref Invoice Nbr"
                            value={
                              !updateBtn
                                ? adjustmentVo.xrefInvoiceNbr
                                : invoiceDetailsSelectedVo.xrefInvoiceNbr
                            }
                            onChange={(e) => {
                              this.handleChange(e, "adjustmentVo");
                            }}
                            onBlur={(e) => this.handleOnBlur(e, "adjustmentVo")}
                            disabled={updateBtn}
                          />
                        </div>
                        <div className={classes.invoiceAdjustmentDiv}>
                          <InputField
                            width="215px"
                            name="paySourceDesc"
                            label="Pay Source"
                            value={invoiceDetailsSelectedVo.paySourceDesc}
                            disabled
                          />
                        </div>
                        <div className={classes.invoiceAdjustmentDiv}>
                          <InputField
                            width="215px"
                            name="payBatchDate"
                            label="Pay Batch"
                            value={invoiceDetailsSelectedVo.payBatchDateFrmt}
                            disabled
                          />
                        </div>
                        <div className={classes.invoiceAdjustmentDiv}>
                          <InputField
                            width="215px"
                            name="payBatchSeqNbr"
                            label="Batch Seq"
                            value={invoiceDetailsSelectedVo.payBatchSeqNbr}
                            disabled
                          />
                        </div>

                        <div className={classes.invoiceAdjustmentDiv}>
                          <InputField
                            width="215px"
                            name="item"
                            label="Item"
                            value={invoiceDetailsSelectedVo.itemNbr}
                            disabled
                          />
                        </div>
                        {adjustmentVo.functionCd === "REF" &&
                          !updateBtn &&
                          lstRefReasonCode ? (
                            <div>
                              <AutoComplete1
                                width="215px"
                                margin="0px"
                                fontSize="0.718em"
                                options={lstRefReasonCode}
                                handleChange={this.handleReasonSelect(
                                  "reasonCd",
                                  "adjustmentVo"
                                )}
                                defaultValue={{
                                  label: "Select",
                                  value: "",
                                }}
                                value={adjustmentVo.reasonCd}
                                label="Refund Reason"
                                name="reasonCd"
                              />
                            </div>
                          ) : null}
                        <div className={classes.invoiceAdjustmentDiv}>
                          <InputField
                            name="modifiedTime"
                            width="215px"
                            label="Modified Time"
                            value={formatTimeStamp(
                              invoiceDetailsSelectedVo.lastUpdtTime
                            )}
                            disabled
                          />
                        </div>
                        <div className={classes.invoiceAdjustmentDiv}>
                          <InputField
                            name="modifiedUser"
                            width="215px"
                            label="Modified User"
                            value={invoiceDetailsSelectedVo.lastUpdtUserId}
                            disabled
                          />
                        </div>
                      </div>
                      <HistoryData
                        createTime={invoiceDetailsSelectedVo.createTime}
                        createUserId={invoiceDetailsSelectedVo.createUserId}
                        lastUpdtTime={invoiceDetailsSelectedVo.lastUpdtTime}
                        lastUpdtUserId={invoiceDetailsSelectedVo.lastUpdtUserId}
                        footer="true"
                      />
                    </>
                  )}
              </div>
            </ExpansionPanel>
          </>
        ) : null}
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    loginProfile: state.loginData.profiles,
    tableIndex: state.billingReducer.invoice.tableIndexes.invoiceDetails,
    adjustmentComments: state.billingReducer.invoice.adjustmentComments,
    invoiceDetailsList:
      state.billingReducer.invoice.invoiceSearchResults.billingInvDetails,
    lstFunctionCode:
      state.billingReducer.invoice.invoiceSearchResults.lstFunctionCode,
    invoiceHeaderDetailsSelectedVo:
      state.billingReducer.invoice.invoiceSearchResults
        .billingInvHeaderDtlsVOs[0],
    lstRefReasonCode:
      state.billingReducer.invoice.invoiceSearchResults.lstRefReasonCode,

    refFlag: state.billingReducer.invoice.refFlag,
    searchInvoiceGroup:
      state.billingReducer.invoice.searchCriteriaVo.searchInvoiceGroup,
    servicesEnabled: state.loginData.servicesEnabled,
  };
};

const mapDispatchToProps = {
  getDetailAmount,
  adjustmentUpdate,
  invoiceTransfer,
  setInvoiceTableIndex,
  setAdjustmentComments,
  setRefFlag,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(InvoiceDetails));
