import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import NoSsr from '@material-ui/core/NoSsr';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';
import SecurityRoles from './Roles';
import SecurityServices from './Services';
import { resetMemberSearch } from "../../redux/actions/MemberActions";
import { connect } from "react-redux";

function TabContainer(props) {
  return (
    <Typography component="div" style={{ padding: 8  }}>
      {props.children}
    </Typography>
  );
}


TabContainer.propTypes = {
  children: PropTypes.node.isRequired,
};

function LinkTab(props) {
  return <Tab component="a" onClick={event => event.preventDefault()} {...props} />;
}

const styles = theme => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
  },
  bigIndicator:
  {
      height:2,
      backgroundColor:"white"
    }
});

class NavTabs extends React.Component {
  state = {
    value: 0,
  };

  handleChange = (event, value) => {
    this.setState({ value });
  };

  componentWillUnmount() {
     this.props.resetMemberSearch({ applicationId: this.props.selectedMemberId.applicationId });
    }
  render() {
    const { classes } = this.props;
    const { value } = this.state;

    return (
      <NoSsr>
        <div className={classes.root}>
          <AppBar position="static">
          <Tabs variant="fullWidth" value={value} onChange={this.handleChange}
            classes={{ indicator:
              classes.bigIndicator }}>
              <LinkTab label="Roles" href="page1" />
              <LinkTab label="Services" href="page2" />
             
            </Tabs>
          </AppBar>
          {value === 0 && <TabContainer><SecurityRoles/></TabContainer>}
          {value === 1 && <TabContainer><SecurityServices/></TabContainer>}
         
        </div>
      </NoSsr>
    );
  }
}

NavTabs.propTypes = {
  classes: PropTypes.object.isRequired,
};

const mapStateToProps = state => {
  return {
    selectedMemberId: state.memberSearch.selectedMemberId,
  };
};

const mapDispatchToProps = {
  resetMemberSearch,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(NavTabs));

