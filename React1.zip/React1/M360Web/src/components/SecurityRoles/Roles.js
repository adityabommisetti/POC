import { Select, components } from "./../UI/Select";
import React, { Component } from "react";

import Button from "@material-ui/core/Button";

import Paper from "@material-ui/core/Paper";

import { Styles } from "../../assets/styles/Theme";
import { withStyles } from "@material-ui/core/styles";
import {
  getUserRoleData,
  updateRoleData
} from "../../redux/actions/SecurityAction";
import { connect } from "react-redux";

class SecurityRoles extends Component {
  state = {
    securityVo: {
      userId: "",
      userName: ""
    },
    list: [],
    groupId: ""
  };

  async componentDidMount() {
    await this.props.getUserRoleData();
    this.setState({
      list: this.props.cacheData
    });
  }

  handleChangeSearchSelect = name => event => {
    let label = event.label;
    this.setState(prevState => ({
      securityVo: {
        ...prevState.securityVo,
        [name]: label
      },
      groupId: event.value
    }));
  };
  handleChangeSearchSelect1 = name => event => {
    let label = event.value;
    this.setState({
      [name]: label
    });
  };

  update = event => {
    event.preventDefault();
    const { userList } = this.state.list;
    const { groupId } = this.state;
    const { userId } = this.state.securityVo;
    let index = userList.findIndex(x => x.label === userId);
    userList[index].value = groupId;

    const list1 = userList;

    this.props.updateRoleData({ userId, groupId }, list1);
  };

  render() {
    const { classes } = this.props;
    const { userList, roleList } = this.props.cacheData;
    const { userId } = this.state.securityVo;
    const { groupId } = this.state;

    return (
      <div>
        {userList ? (
          <Paper elevation={0}>
            <form autoComplete="off">
              <div class="panel-body" className={classes.rolesHeight}>
                <div className={classes.securityContainer}>
                  <div>
                    <Select
                      components={components}
                      propertyName={userList.filter(
                        option => option.label === userId
                      )}
                      options={userList}
                      label="Choose user ID ..."
                      textFieldProps={{
                        label: "User ID",
                        InputLabelProps: {
                          className: classes.label,
                          shrink: true
                        }
                      }}
                      className={classes.textFieldSelect}
                      handleChange={this.handleChangeSearchSelect("userId")}
                      isDisabled={false}
                      classes={classes}
                    />
                  </div>
                  <div>
                    <Select
                      components={components}
                      propertyName={roleList.filter(option =>
                        option.value === groupId ? option.label : ""
                      )}
                      options={roleList}
                      label="Choose user ID ..."
                      textFieldProps={{
                        label: "Service",
                        InputLabelProps: {
                          className: classes.label,
                          shrink: true
                        }
                      }}
                      className={classes.textFieldSelect}
                      handleChange={this.handleChangeSearchSelect1("groupId")}
                      isDisabled={false}
                      classes={classes}
                    />
                  </div>
                  <Button
                    type="submit"
                    variant="contained"
                    color="primary"
                    onClick={this.update}
                    className={classes.roleButton}
                  >
                    Update
                  </Button>
                </div>
                <br />
                <br />
              </div>
            </form>
          </Paper>
        ) : null}
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    cacheData: state.security.cacheData
  };
};
const mapDispatchToProps = {
  getUserRoleData,
  updateRoleData
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(SecurityRoles));
