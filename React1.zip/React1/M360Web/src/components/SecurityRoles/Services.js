import "../../assets/css/icon.css";

import React, { Component } from "react";
import { Select, components } from "./../UI/Select";
import { addService, deleteService, getServiceData } from "../../redux/actions/SecurityAction"

import Button from "@material-ui/core/Button";
import { Checkbox } from "@material-ui/core";
import Paper from "@material-ui/core/Paper";
import { Styles } from "../../assets/styles/Theme";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";

class SecurityServices extends Component {
  constructor(props) {
    super(props)
    this.state = {
      deleteDisabled: true,
      addDisabled: true,
      flag: false,
      groupId: "",
      serviceList: this.props.serviceData ? this.props.serviceData : [],
      updateDisable: true,

    };
  }

  handleChangeSearchSelect = name => event => {
    let value = event.value;
    this.setState({
      [name]: value
    });
  };

  handleAvailableServices = (role, i) => {
    let data = [...this.state.serviceList.availableServices];
    data[i].check = role.check ? false : true;

    this.setState({
      ...this.state.serviceList,
      availableServices: [...data]

    });
  }

  handleEnabledServices = (role, i) => {
    let data = [...this.state.serviceList.enabledServices];
    data[i].check = role.check ? false : true;

    this.setState({
      ...this.state.enabledServices,
      enabledServices: [...data]

    });
  }

  update = async () => {
    const { addDisabled, serviceList } = this.state

    if (addDisabled) {

      let serviceId = serviceList.availableServices.map(role => {
        if (role.check === true)
          return role.serviceId
        else
          return null
      });
      serviceId = serviceId.filter(role => {
        return role != null
      })

      const { userId } = this.props.logindata

      await this.props.addService({ serviceId, userId }, serviceList)
   


  

      await this.setState({
        ...this.state,
        serviceList: { ...this.props.serviceData }
      })

    }

    else {
      const { groupId, serviceList } = this.state


      let serviceId = serviceList.enabledServices.map(role => {
        if (role.check === true)
          return role.serviceId
        else
          return null
      });
      serviceId = serviceId.filter(role => {
        return role != null
      })


      const { userId } = this.props.logindata
       await this.props.deleteService({ serviceId, userId, groupId }, serviceList)



      await this.setState({
        ...this.state,
        serviceList: { ...this.props.serviceData }
      })

    }
  }

  searchButton = async () => {
    const status = await this.props.getServiceData(this.state.groupId)
    if (status === "SUCCESS") {
      this.setState({
        serviceList: this.props.serviceData,
        flag: true
      });
      const serviceList = this.state.serviceList

      for (let i = 0; i < serviceList.availableServices.length; i++) {
        let test = { check: false };
        Object.assign(serviceList.availableServices[i], test);
      }
      for (let i = 0; i < serviceList.enabledServices.length; i++) {
        let test = { check: false };
        Object.assign(serviceList.enabledServices[i], test);
      }
    }
  };

  addService = () => {
    this.setState({
      deleteDisabled: false,
      addDisabled: true,
      updateDisable: false,
    })

  }

  deleteService = () => {
    this.setState({
      addDisabled: false,
      deleteDisabled: true,
      updateDisable: false
    })

  }


  render() {
    const { classes } = this.props;
    const { roleList } = this.props.cacheData;
    const { serviceList } = this.state
    const { addDisabled, deleteDisabled } = this.state

  

    return (
      <div>
        {roleList ?
          <Paper elevation={0}>
            <form autoComplete="off">
              <div class="panel-body">
                <div className={classes.container}>
                  <div>
                    <Select
                      components={components}
                      propertyName={roleList.filter(
                        option => option.value === this.state.groupId
                      )}
                      options={roleList}
                      label="Choose user ID ..."
                      textFieldProps={{
                        label: "User ID",
                        InputLabelProps: {
                          className: classes.label,
                          shrink: true
                        }
                      }}
                      className={classes.textFieldSelect}
                      handleChange={this.handleChangeSearchSelect("groupId")}
                      isDisabled={false}
                      classes={classes}
                    />
                  </div>

                  <div className={classes.buttonContainerroles}>
                    <Button

                      variant="contained"
                      color="primary"
                      className={classes.button}
                      onClick={this.searchButton.bind(this)}
                    >
                      Search
                  </Button>
                  </div>
                </div>

                <br />
                <br />
              </div>

              {this.state.flag ?


                <div class="panel-body">
                  <div className={classes.buttonContainermiddle}>
                    <Button
                      onClick={this.deleteService}
                      variant="contained"
                      color="primary"
                      className={classes.button}
                    >
                      Enable Delete Service
                </Button>

                    <Button
                      onClick={this.addService}
                      variant="contained"
                      color="primary"
                      className={classes.button}
                    >
                      Enable Add Service
                </Button>
                  </div>

                  <br />
                  <br />



                  <Paper elevation={0} className={classes.paperservices}>
                    <fieldset
                      class="label-container sr_box sr_box2"
                      id="services-available"
                    >
                      <legend>Services Available</legend>
                      <div class="scroll-box">
                        {serviceList.enabledServices.map((role, i) => (
                          <div style={{ textAlign: "left" }}>
                            <Checkbox
                              disabled={addDisabled}
                              classes={{ root: classes.radioSpan }}
                              checked={role.check}
                              onChange={() => {
                                this.handleEnabledServices(role, i);
                              }}
                            />
                            <span className={classes.securityFormLabel}>
                              {role.serviceName}
                            </span>
                          </div>
                        ))}
                      </div>
                    </fieldset>
                  </Paper>
                  <Paper elevation={0} className={classes.paperservices}>
                    <fieldset
                      class="label-container sr_box sr_box2 sr_box2_right"
                      id="more-services"
                    >
                      <legend>More Services Available to be added</legend>
                      <div class="scroll-box">
                        {this.state.serviceList.availableServices.map((role, i) => (
                          <div style={{ textAlign: "left" }}>
                            <Checkbox
                              disabled={deleteDisabled}
                              classes={{ root: classes.radioSpan }}
                              checked={role.check}
                              onClick={() => {
                                this.handleAvailableServices(role, i);
                              }}
                            />
                            <span className={classes.securityFormLabel}>
                              {role.serviceName}
                            </span>
                          </div>
                        ))}
                      </div>
                    </fieldset>
                  </Paper>
                  <div className={classes.buttonContainermiddle}>
                    <Button
                      variant="contained"
                      color="primary"
                      className={classes.button}
                      onClick={this.update}
                      disabled={this.state.updateDisable}
                    >
                      Update
                </Button>

                  </div>
                </div>
                : null}
            </form>
          </Paper>
          : null}
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    cacheData: state.security.cacheData,
    serviceData: state.security.serviceData,
    logindata: state.loginData.loginVo
  };
};
const mapDispatchToProps = {
  getServiceData,
  addService,
  deleteService
};


export default connect(mapStateToProps, mapDispatchToProps)(withStyles(Styles)(SecurityServices));
