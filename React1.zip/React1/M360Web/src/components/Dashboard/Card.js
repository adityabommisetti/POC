import React, { Component } from "react";
import MuiCard from "@material-ui/core/Card";
import Member from "./MemberShipDistribution";
import RFI from "./RFITracking";
import Pre from "./PreEnrollmentStatus";
import Aging from "./ApplicationAging";
import Cms from "./CMSStatus";
import Pending from "./PendingTransactionsToCMS";
import ApplDistrib from "./ApplDistribution";
import SpecialStatus from "./SpecialDistribution";
import LetterVol from "./LettersVolume";
import FileLoad from "./FileLoadDistribution";
import Lis from "./LisMemberDistribution";
import { withStyles } from "@material-ui/core/styles";
import { Styles } from "../../assets/styles/DashboradStyles";
import classNames from "classnames";
import Popup from "reactjs-popup";

const Card = withStyles({
  root: {
    border: "1px solid rgba(0, 0, 0, .125)",
    boxShadow: "1px",
    marginBottom: "6px",
    height: "230px !important",
    marginTop: "6px",
    cursor: "pointer",
  },
})(MuiCard);

class Dashlet extends Component {
  constructor() {
    super();
    this.state = {
      maxSize: false,
      openPopup: false,
      dashletExpandedComponents: [
        <Pre dashletExpanded={true} />,
        <Aging dashletExpanded={true} />,
        <Member dashletExpanded={true} />,
        <ApplDistrib dashletExpanded={true} />,
        <Lis dashletExpanded={true} />,
        <SpecialStatus dashletExpanded={true} />,
        <LetterVol dashletExpanded={true} />,
        <FileLoad dashletExpanded={true} />,
        <RFI dashletExpanded={true} />,
        <Cms dashletExpanded={true} />,
        <Pending dashletExpanded={true} />,
      ],
      components: [
        <Pre />,
        <Aging />,
        <Member />,
        <ApplDistrib />,
        <Lis />,
        <SpecialStatus />,
        <LetterVol />,
        <FileLoad />,
        <RFI />,
        <Cms />,
        <Pending />,
      ],
    };
  }

  closePopup = () => {
    this.setState({ openPopup: false });
  };

  openPopup = () => {
    this.setState({ openPopup: true });
  };

  modalClosed = () => {
    this.setState({ closePopup: false });
  };

  handle = () => {
    this.setState({
      maxSize: !this.state.maxSize,
    });
  };

  render() {
    const { classes } = this.props;

    return (
      <div>
        <Card>
          <div className={classes.header}>
            {this.props.title}
            <span
              class={classNames("fa fa-expand", classes.maxIcon)}
              onClick={this.openPopup}
            />
            <Popup
              className={classes.mobileWidth}
              modal
              open={this.state.openPopup}
              contentStyle={{ width: "85%", height: "80%" }}
            >
              {(close) => (
                <div>
                  <i className="close" onClick={this.closePopup}>
                    &times;
                  </i>
                  {this.state.dashletExpandedComponents[this.props.index]}
                </div>
              )}
            </Popup>
            {this.state.components[this.props.index]}
          </div>
        </Card>
      </div>
    );
  }
}
export default withStyles(Styles)(Dashlet);
