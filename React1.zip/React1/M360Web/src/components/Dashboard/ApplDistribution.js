import { Chart } from "primereact/components/chart/Chart";
import React, { Component } from "react";
import {
  applDistribution,
  storeChartDataset,
  setSearchCritirea,
} from "../../redux/actions/DashboardActions";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";
import isEmpty from "lodash/isEmpty";
import { Styles } from "../../assets/styles/DashboradStyles";
import SimpleReactValidator from "simple-react-validator";
import ExpansionPanel from "../UI/ExpansionPanel";
import Autocomplete1 from "../UI/Select";

const SELECT_OBJECT = {
  label: "Select",
  value: "",
};
class ApplicationDistribution extends Component {
  constructor(props) {
    super();
    this.state = {
      plan: "",
      collapse: false,
      resetFlag: false,
      dropdown: [],
    };
    this.validator = new SimpleReactValidator();
  }
  
    
  async componentWillReceiveProps(nextProps, prevState) {
    const { searchFlag } = nextProps;
    const { plan } = prevState;
        if (!isEmpty(nextProps.chartData)) {
      if (
        searchFlag &&
        this.state.resetFlag &&
        nextProps.checkedList &&
        !isEmpty(nextProps.checkedList) &&
        nextProps.checkedList.includes("Application Distribution")
      ) {
        return this.testingPhase([plan]);
      }
    }
    
  }
  
  testingPhase = async (plan) => {
    await this.setState({ resetFlag: false });
    await this.props.applDistribution(plan);
    await this.setState({ resetFlag: true });
  };
  async componentDidMount() {
    const { dashletExpanded, searchCritirea, dropdowns } = this.props;
    this.state.dropdown = [SELECT_OBJECT, ...dropdowns ]
    const plan = this.state.dropdown[1].label;
    if (!dashletExpanded) {
      await this.props.applDistribution([plan]);
      await this.props.setSearchCritirea({
        ...searchCritirea,
        applDistribution: {
          plan: plan,
         
        },
      });
    } else {
      this.setState({
        plan: searchCritirea.applDistribution.plan,
        
      });
    }
    this.setState({
      plan: plan,
     
    });
    this.setState({ resetFlag: true });
    this.setChartData(plan);
  }
  setChartData = async (plan) => {
    const { chartData, chartDataset } = this.props;
    const Labels = [];
    const enrollArray = [];
    const Dataset = [];
    const firstElement = Object.keys(chartData)[0];

    if (!isEmpty(chartData)) {
      chartData[firstElement].forEach((object) => {
        Labels.push(object.pbpId);
        enrollArray.push(object.enrollCount ? parseInt(object.enrollCount) : 0);
      });
    }
    let enrollDataset = {
      type: "bar",
      label: "Enrolled",
      backgroundColor: "#4caf50",
      hoverBackgroundColor: "green",
      data: enrollArray,
    };
    Dataset.push(enrollDataset);

    await this.props.storeChartDataset({
      ...chartDataset,
      applDistribution: { Dataset: Dataset, Labels: Labels },
    });
  };
  handleChangeSearchSelectAuto = (event) => {
    let value = event.value ? event.value : "";
    this.setState({
      plan: value,
      collapse: false,
    });
  };
  handleResetAppl = (e) => {
    e.preventDefault();
    this.validator.hideMessages();
    this.forceUpdate();
    this.setState({
      plan: "",
      collapse: false,
    });
  };
  handleSubmit = async (e) => {
    e.preventDefault();
    const plan = this.state.plan;
    const { searchCritirea } = this.props;
    if (!this.validator.allValid()) {
      this.validator.showMessages();
      this.forceUpdate();
      this.setState({
        collapse: false,
      });
    } else {
      await this.props.applDistribution([plan]);
      await this.props.setSearchCritirea({
        ...searchCritirea,
        applDistribution: {
          plan: plan,
        },
      });
      this.validator.hideMessages();
      this.forceUpdate();
      this.setChartData(plan);
    }
  };

  getLabel = (tooltipItem, data) => {
    let index = tooltipItem.datasetIndex;
    let label = data.datasets[index].label;
    let value = tooltipItem.value;
    return label + " : " + value;
  };

  render() {
    const {
      classes,
      dashletExpanded,
      chartDataset,
      spin,
    } = this.props;
    const { Dataset, Labels } = chartDataset.applDistribution;
    const { plan, collapse, dropdown } = this.state;

    const Data = {
      labels: Labels,
      datasets: Dataset,
    };
    const Options = {
      scales: {
        yAxes: [
          {
            scaleLabel: {
              display: true,
              labelString: "Enrolled Count",
            },
            ticks: {
              min: 0,
            },
          },
        ],
      },
      plugins: {
        datalabels: {
          display: false,
        },
      },
      legend: {
        position: "right",
      },
      tooltips: {
        callbacks: {
          label: (a, b) => this.getLabel(a, b),
        },
      },
      responsive: true,
      maintainAspectRation: false,
      animation: false,
    };
    const datasetObj =Object.values(Data.datasets);   
    for (const value of datasetObj) {
    var valuesZero = Object.values(value.data).every( num => {
        return num === 0;});
    }
    return (
      <div>
        {spin === true ? <div id="dashlet-spin" /> : null}
        {dashletExpanded ? (
          <div className={classes.header2}>
            <b>Application Distribution</b>

            <ExpansionPanel
              summary="Search"
              defaultCollapsed={collapse}
              className={classes.containertypography}
            >
              <div class="panel-body" className={classes.panelBody}>
                <form onSubmit={this.handleSubmit} autoComplete="off">
                  <div className={classes.container}>
                    <div>
                      <Autocomplete1
                        handleChange={this.handleChangeSearchSelectAuto}
                        label="Contracts List"
                        options={dropdown}
                        defaultValue={{label:'H9877', value:'H9877'}}
                        value={dropdown.filter(
                          (option) => option.value === plan
                        )[0]}
                        name="plan"
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message("Contract ", plan, "required")}
                      </div>
                    </div>

                    <span
                      class="button-container-search"
                      className={classes.expansionPanelbuttons}
                      style={{marginLeft:'35px'}}
                    >
                      <button id="search" class="btn btn-primary icon-search">
                        Search
                      </button>
                      <button
                        id="reset"
                        class="btn btn-secondary"
                        onClick={this.handleResetAppl}
                      >
                        Reset
                      </button>
                    </span>
                  </div>
                </form>
              </div>
            </ExpansionPanel>
          </div>
        ) : null}

        {!dashletExpanded && !spin ? (
          <div className={classes.chartContainer2}>
             {valuesZero ? 
            <div className = {classes.centreAlign}>
            No data to display
            </div> :
            <Chart type="bar" data={Data} options={Options} />}
          </div>
        ) : (
          <div>
            {!spin ? (
              <div className={classes.space}>
                 {valuesZero ? 
                  <div className = {classes.centreAlign}>
                  No data to display
                  </div> :
                <Chart type="bar" data={Data} options={Options} width="675px" />}
                <h3 style={{ paddingLeft: "290px" }}>{plan === "Select"? null: plan}</h3>
              </div>
            ) : null}
          </div>
        )}
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    chartData: state.dashboard.applDistribution.data,
    spin: state.dashboard.applDistribution.spin,
    dropdowns: state.dashboard.customerPlanIds,
    chartDataset: state.dashboard.chartDataset,
    searchCritirea: state.dashboard.searchCritireaVo,
    searchFlag: state.dashboard.applDistribution.searchFlag,
    checkedList: state.dashboard.checkedList,
  };
};
const mapDispatchToProps = {
  applDistribution,
  storeChartDataset,
  setSearchCritirea,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(ApplicationDistribution));
