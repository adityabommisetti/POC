import { Chart } from "primereact/components/chart/Chart";
import React, { Component } from "react";
import {
  memberShipDistribution,
  storeChartDataset,
  setSearchCritirea,
} from "../../redux/actions/DashboardActions";
import { connect } from "react-redux";
import { Styles } from "../../assets/styles/DashboradStyles";
import { withStyles } from "@material-ui/core/styles";
import isEmpty from "lodash/isEmpty";
import SimpleReactValidator from "simple-react-validator";
import ExpansionPanel from "../UI/ExpansionPanel";
import Autocomplete1 from "../UI/Select";

const SELECT_OBJECT = {
  label: "Select",
  value: "",
};
class MemberShipDistribution extends Component {
  constructor(props) {
    super();
    this.state = {
      plan: "",
      collapse: false,
      resetFlag: false,
      dropdown: [],
    };
    this.validator = new SimpleReactValidator();
  }
  async componentWillReceiveProps(nextProps, prevState){
    const { plan } = prevState;
    const { searchFlag } = nextProps;

    if (!isEmpty(nextProps.chartData)) {
      if (
        searchFlag &&
        this.state.resetFlag &&
        nextProps.checkedList &&
        !isEmpty(nextProps.checkedList) &&
        nextProps.checkedList.includes("Membership Distribution")
      ) {
        return this.testingPhase([plan]);
      }
    }  
  }
  testingPhase = async (plan) => {
    await this.setState({ resetFlag: false });
    await this.props.memberShipDistribution(plan);
    await this.setState({ resetFlag: true });
  };
  async componentDidMount() {
    const { dashletExpanded, searchCritirea, dropdowns } = this.props;
    this.state.dropdown = [ SELECT_OBJECT, ...dropdowns ]
    const plan = this.state.dropdown[1].label;
    
    if (!dashletExpanded) {
      await this.props.memberShipDistribution([plan]);
      await this.props.setSearchCritirea({
        ...searchCritirea,
        mbrDistribution: {
          plan: plan,
        },
      });
    } else {
      this.setState({
        plan: searchCritirea.mbrDistribution.plan,
      });
    }
    this.setState({
      plan: plan,
       resetFlag: true
    });
    this.setChartData(plan);
  }
  setChartData = async (plan) => {
    const { chartData, chartDataset } = this.props;
    const Labels = [];
    const enrollArray = [];
    const disEnrollArray = [];
    const Dataset = [];
    const firstElement = Object.keys(chartData)[0];

    if (!isEmpty(chartData)) {
      chartData[firstElement].forEach((object) => {
        Labels.push(object.pbpId);
        enrollArray.push(object.enrollCount ? parseInt(object.enrollCount) : 0);
        disEnrollArray.push(
          object.disEnrollCount ? parseInt(object.disEnrollCount) : 0
        );
      });
    }
    let enrollDataset = {
      type: "bar",
      label: "Enrolled",
      backgroundColor: "#4caf50",
      hoverBackgroundColor: "green",
      data: enrollArray,
    };
    Dataset.push(enrollDataset);
    let disEnrollDataset = {
      type: "bar",
      label: "DisEnrolled",
      backgroundColor: "#f44336",
      hoverBackgroundColor: "red",
      data: disEnrollArray,
    };
    Dataset.push(disEnrollDataset);

    await this.props.storeChartDataset({
      ...chartDataset,
      mbrDistribution: { Labels: Labels, Dataset: Dataset },
    });
  };
  handleChangeSearchSelectAuto = (data, name) => {
    let value = data.value ? data.value: "";
    this.setState({
      plan: value,
      collapse: false,
    });
  };
  handleResetAppl = (e) => {
    e.preventDefault();
    this.validator.hideMessages();
    this.forceUpdate();
    this.setState({
      plan: "",
      collapse: false,
    });
  };
  handleSubmit = async (e) => {
    e.preventDefault();
    const plan = this.state.plan;
    const { searchCritirea } = this.props;
    if (!this.validator.allValid()) {
      this.validator.showMessages();
      this.forceUpdate();
      this.setState({
        collapse: false,
        plan: plan,
      });
    } else {
      await this.props.memberShipDistribution([plan]);
      await this.props.setSearchCritirea({
        ...searchCritirea,
        mbrDistribution: {
          plan: plan,
        },
      });
      this.validator.hideMessages();
      this.forceUpdate();
      this.setChartData(plan);
    }
  };

  getLabel = (tooltipItem, data) => {
    let index = tooltipItem.datasetIndex;
    let label = data.datasets[index].label;
    let value = tooltipItem.value;
    return label + " : " + value;
  };

  render() {
    const {
      classes,
      dashletExpanded,
      spin,
      chartDataset,
    } = this.props;
    
    const { Labels, Dataset } = chartDataset.mbrDistribution;
    const { plan, collapse, dropdown } = this.state;
    const Data = {
      labels: Labels,
      datasets: Dataset,
    };
    const Options = {
      scales: {
        yAxes: [
          {
            scaleLabel: {
              display: true,
              labelString: "Enrolled/DisEnrolled Count",
            },
            ticks: {
              min: 0,
            },
          },
        ],
      },
      plugins: {
        datalabels: {
          display: false,
        },
      },
      legend: {
        position: "right",
      },
      tooltips: {
        callbacks: {
          label: (a, b) => this.getLabel(a, b),
        },
      },
      responsive: true,
      maintainAspectRation: false,
      animation: false,
    };
    const datasetObj =Object.values(Data.datasets);
   
    for (const value of datasetObj) {
    var valuesZero = Object.values(value.data).every( num => {
        return num === 0;});
    }
    return (
      <div>
        {spin === true ? <div id="dashlet-spin" /> : null}
        {dashletExpanded ? (
          <div className={classes.header2}>
            <b>MemberShip Distribution</b>

            <ExpansionPanel
              summary="Search"
              defaultCollapsed={collapse}
              className={classes.containertypography}
            >
              <div class="panel-body" className={classes.panelBody}>
                <form onSubmit={this.handleSubmit} autoComplete="off">
                  <div className={classes.container}>
                    <div>
                       <Autocomplete1
                        handleChange={this.handleChangeSearchSelectAuto}
                        label="Contracts List"
                        options={dropdown}
                        defaultValue={{label:'H9877', value:'H9877'}}
                        value={dropdown.filter(
                          (option) => option.value === plan
                        )[0]}
                        name="plan"
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message("Contract ", plan, "required")}
                      </div>
                    </div>

                    <span
                      class="button-container-search"
                      className={classes.expansionPanelbuttons}
                      style={{marginLeft:'35px'}}
                    >
                      <button id="search" class="btn btn-primary icon-search">
                        Search
                      </button>
                      <button
                        id="reset"
                        class="btn btn-secondary"
                        onClick={this.handleResetAppl}
                      >
                        Reset
                      </button>
                    </span>
                  </div>
                </form>
              </div>
            </ExpansionPanel>
          </div>
        ) : null}

        {!dashletExpanded && !spin ? (
          <div className={classes.chartContainer2}>
             {valuesZero ? 
            <div className = {classes.centreAlign}>
            No data to display
            </div> :
            <Chart type="bar" data={Data} options={Options} />}
          </div>
        ) : (
          <div>
            {!spin ? (
              <div className={classes.space}>
                 {valuesZero ? 
            <div className = {classes.centreAlign1}>
            No data to display
            </div> :
                <Chart type="bar" data={Data} options={Options} width="675px" />}
                <h3 style={{ paddingLeft: "290px" }}>{plan === "Select"? null: plan}</h3>
              </div>
            ) : null}
          </div>
        )}
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    chartData: state.dashboard.memberShipDistribution.data,
    spin: state.dashboard.memberShipDistribution.spin,
    dropdowns: state.dashboard.customerPlanIds,
    chartDataset: state.dashboard.chartDataset,
    searchCritirea: state.dashboard.searchCritireaVo,
    searchFlag: state.dashboard.memberShipDistribution.searchFlag,
    checkedList: state.dashboard.checkedList,
  };
};
const mapDispatchToProps = {
  memberShipDistribution,
  storeChartDataset,
  setSearchCritirea,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(MemberShipDistribution));
