import React, { Component } from "react";
import { Styles } from "../../assets/styles/DashboradStyles";
import { withStyles } from "@material-ui/core/styles";
import { connect } from "react-redux";
import { Chart } from "primereact/chart";
import "chartjs-plugin-datalabels";
import {
  fileDistribution,
  storeChartDataset,
  setSearchCritirea,
} from "../../redux/actions/DashboardActions";
import isEmpty from "lodash/isEmpty";
import ExpansionPanel from "../UI/ExpansionPanel";
import InputField from "../UI/InputField";
import { handleDateChange } from "../../utils/DateFormatter";
import * as DateUtil from "../../utils/DatePicker";
import SimpleReactValidator from "simple-react-validator";
import { customValidations } from "../../utils/CustomValidations";
import moment from "moment";

const INITIAL_STATE = {
  startDate: "",
  endDate: "",
};
const dateChk = {};

class FileDistribution extends Component {
  constructor(props) {
    super(props);
    this.state = {
      label: "",
      rowsPerPage: 10,
      selectedRowIndex: 0,
      index: 0,
      tableData: [],
      searchVo: {
        startDate: moment(moment().subtract(30, "days")).format("MM/DD/YYYY"),
        endDate: moment(new Date()).format("MM/DD/YYYY"),
      },
      openPopup: false,
      collapse: false,
      resetFlag: false,
    };

    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
        c_after_or_equal_99: customValidations.c_after_or_equal_99,
      },
    });
  }

  async componentWillReceiveProps(nextProps, prevState) {
    const { searchVo } = prevState;
    const { searchFlag } = nextProps;
    if (!isEmpty(nextProps.chartData)) {
      if (
        searchFlag &&
        this.state.resetFlag &&
        nextProps.checkedList &&
        !isEmpty(nextProps.checkedList) &&
        nextProps.checkedList.includes("File Load And Error Distribution")
      ) {
        return this.testingPhase({
          startDate: this.state.searchVo.startDate,
          endDate: this.state.searchVo.endDate,
        });
      }
    }
  }

  testingPhase = async (data) => {
    await this.setState({ resetFlag: false });
    await this.props.fileDistribution(data);
    await this.setState({ resetFlag: true });
  };
  async componentDidMount() {
    const { startDate, endDate } = this.state.searchVo;
    const { searchCritirea } = this.props;
    if (!this.props.dashletExpanded) {
      await this.props.fileDistribution({
        startDate: startDate,
        endDate: endDate,
      });
      await this.props.setSearchCritirea({
        ...searchCritirea,
        fileDistribution: {
          startDate: startDate,
          endDate: endDate,
        },
      });
    } else {
      await this.setState((prevState) => ({
        ...prevState,
        searchVo: {
          ...prevState.searchVo,
          startDate: searchCritirea.fileDistribution.startDate,
          endDate: searchCritirea.fileDistribution.endDate,
        },
      }));
    }
    this.setState({ resetFlag: true });
    this.setChartData();
  }

  handleChange = (event) => {
    let value = event.target.value;
    let name = event.target.name;
    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: handleDateChange(value),
      },
      collapse: false,
    }));
  };

  handleResetAppl = (e) => {
    e.preventDefault();
    this.validator.hideMessages();
    this.forceUpdate();
    this.setState({
      searchVo: {
        ...INITIAL_STATE,
      },
      collapse: false,
    });
  };
  setChartData = async () => {
    const { chartData, chartDataset } = this.props;
    let Labels = [];
    const loadedArray = [];
    const erroredArray = [];
    const rejectedArray = [];
    const Dataset = [];

    if (!isEmpty(chartData)) {
      Labels = Object.keys(chartData);
      Labels.forEach((item) => {
        let object = chartData[item];
        loadedArray.push(object.loaded ? parseInt(object.loaded) : 0);
        erroredArray.push(object.errored ? parseInt(object.errored) : 0);
        rejectedArray.push(object.rejected ? parseInt(object.rejected) : 0);
      });
    }
    let loadedDataset = {
      type: "bar",
      label: "Loaded",
      backgroundColor: "#4caf50",
      hoverBackgroundColor: "green",
      data: loadedArray,
    };
    Dataset.push(loadedDataset);
    let rejectedDataset = {
      type: "bar",
      label: "Rejected",
      backgroundColor: "#f44336",
      hoverBackgroundColor: "red",
      data: rejectedArray,
    };
    Dataset.push(rejectedDataset);
    let erroredDataset = {
      type: "bar",
      label: "Errored",
      backgroundColor: "blue",
      hoverBackgroundColor: "blue",
      data: erroredArray,
    };
    Dataset.push(erroredDataset);

    await this.props.storeChartDataset({
      ...chartDataset,
      fileDistribution: { Labels: Labels, Dataset: Dataset },
    });
  };
  handleSubmit = async (e) => {
    e.preventDefault();
    const { searchVo } = this.state;
    const { searchCritirea } = this.props;
    if (!this.validator.allValid()) {
      this.validator.showMessages();
      this.forceUpdate();
      this.setState({
        collapse: false,
      });
    } else {
      await this.props.fileDistribution({
        startDate: searchVo.startDate,
        endDate: searchVo.endDate,
      });
      await this.props.setSearchCritirea({
        ...searchCritirea,
        fileDistribution: {
          startDate: searchVo.startDate,
          endDate: searchVo.endDate,
        },
      });
      this.validator.hideMessages();
      this.forceUpdate();
      this.setChartData();
    }
  };

  handleDates = (event) => {
    let fieldId = "#" + event.target.name;
    var self = this;
    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (event) => {
        if (
          dateChk.name !== event.target.name ||
          dateChk.value !== event.target.value
        ) {
          self.setDate(event.target.name, event.target.value);
          document.getElementById(fieldId.substr(1)).focus();
        }
        dateChk.name = event.target.name;
        dateChk.value = event.target.value;
      });
  };

  setDate = (name, value) => {
    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value,
      },
      collapse: false,
    }));
  };
  getLabel = (tooltipItem, data) => {
    let index = tooltipItem.datasetIndex;
    let label = data.datasets[index].label;
    let value = tooltipItem.value;
    return label + " : " + value;
  };

  render() {
    const { searchVo, collapse } = this.state;
    const { classes, dashletExpanded, chartDataset, spin } = this.props;
    const { Labels, Dataset } = chartDataset.fileDistribution;
    const options = {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        yAxes: [
          {
            scaleLabel: {
              display: true,
              labelString: "File Distribution Count",
            },
            ticks: {
              min: 0,
            },
          },
        ],
      },
      plugins: {
        datalabels: {
          display: false,
        },
      },
      tooltips: {
        callbacks: {
          label: (tooltipItem, data) => this.getLabel(tooltipItem, data),
        },
      },
      legend: {
        position: "right",
        animation: false,
      },

      animation: false,
    };

    const data = {
      labels: Labels,
      datasets: Dataset,
    };

  
    const datasetObj =Object.values(data.datasets);
   
      for (const value of datasetObj) {
      var valuesZero = Object.values(value.data).every( num => {
          return num === 0;});
      }
    
    return (
      <div>
        {spin === true ? <div id="dashlet-spin" /> : null}
        {dashletExpanded ? (
          <div className={classes.header2}>
            <b>File Load And Error Distribution </b>

            <ExpansionPanel
              summary="Search"
              defaultCollapsed={collapse}
              className={classes.containertypography}
            >
              <div class="panel-body" className={classes.panelBody}>
                <form onSubmit={this.handleSubmit} autoComplete="off">
                  <div className={classes.container}>
                    <div>
                      <InputField
                        width="150px"
                        name="startDate"
                        label="Start Date"
                        maxLength={10}
                        value={searchVo.startDate}
                        onChange={(e) => {
                          this.handleChange(e);
                        }}
                        onClick={(e) => {
                          this.handleDates(e);
                        }}
                        placeholder= "MM/DD/YYYY"
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "startdate",
                          searchVo.startDate,
                          "required|date_format"
                        )}
                      </div>
                    </div>
                    <div>
                      <InputField
                        width="150px"
                        name="endDate"
                        label="End Date"
                        maxLength={10}
                        value={searchVo.endDate}
                        onClick={(e) => {
                          this.handleDates(e);
                        }}
                        onChange={(e) => {
                          this.handleChange(e);
                        }}
                        placeholder="MM/DD/YYYY"
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message("EndDate", searchVo.endDate, [
                          "required",
                          "date_format",
                          { c_after_or_equal_99: searchVo.startDate },
                        ])}
                      </div>
                    </div>
                    <span
                      class="button-container-search"
                      className={classes.expansionPanelbuttons}
                    >
                      <button id="search" class="btn btn-primary icon-search">
                        Search
                      </button>
                      <button
                        id="reset"
                        class="btn btn-secondary"
                        onClick={this.handleResetAppl}
                      >
                        Reset
                      </button>
                    </span>
                  </div>
                </form>
              </div>
            </ExpansionPanel>
          </div>
        ) : null}

        {!dashletExpanded && !spin ? (
          <div className={classes.chartContainer2}>
             {valuesZero ? 
            <div className = {classes.centreAlign}>
            No data to display
            </div> :
            <Chart type="bar" data={data} options={options} />}
          </div>
        ) : (
          <div>
            {!spin ? (
              <div className={classes.space}>
                {valuesZero ? 
            <div className = {classes.centreAlign1}>
            No data to display
            </div> :
                <Chart type="bar" data={data} options={options} width="675px" />}
              </div>
            ) : null}
          </div>
        )}
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    chartData: state.dashboard.fileDistribution.data,
    spin: state.dashboard.fileDistribution.spin,
    chartDataset: state.dashboard.chartDataset,
    searchCritirea: state.dashboard.searchCritireaVo,
    searchFlag: state.dashboard.fileDistribution.searchFlag,
    checkedList: state.dashboard.checkedList,
  };
};

const mapDispatchToProps = {
  fileDistribution,
  storeChartDataset,
  setSearchCritirea,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(FileDistribution));
