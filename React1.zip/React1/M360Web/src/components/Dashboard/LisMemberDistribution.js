import { Chart } from "primereact/components/chart/Chart";
import React, { Component } from "react";
import {
  lisDistribution,
  storeChartDataset,
  setSearchCritirea,
} from "../../redux/actions/DashboardActions";
import { connect } from "react-redux";
import { Styles } from "../../assets/styles/DashboradStyles";
import { withStyles } from "@material-ui/core/styles";
import isEmpty from "lodash/isEmpty";
import ExpansionPanel from "../UI/ExpansionPanel";
import Autocomplete1 from "../UI/Select";
import InputField from "../UI/InputField";
import { handleDateChange } from "../../utils/DateFormatter";
import * as DateUtil from "../../utils/DatePicker";
import SimpleReactValidator from "simple-react-validator";
import { customValidations } from "../../utils/CustomValidations";
import moment from "moment";
const dateChk = {};
const SELECT_OBJECT = {
  label: "Select",
  value: "",
};
class LisDistribution extends Component {
  constructor(props) {
    super();
    this.state = {
      plan: "",
      date: "",
      contractsList: "",
      collapse: false,
      resetFlag: false,
      dropdown: [],
    };
    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
      },
    });
  }
  async componentWillReceiveProps(nextProps, prevState) {
    const { searchFlag } = nextProps;
    const { plan, date } = prevState;
        if (!isEmpty(nextProps.chartData)) {
      if (
        searchFlag &&
        this.state.resetFlag &&
        nextProps.checkedList &&
        !isEmpty(nextProps.checkedList) &&
        nextProps.checkedList.includes("LIS Distribution")
      ) {
        return this.testingPhase({
          contractsList: [plan],
          date: date,
        });
      }
    }
    
  }
  
  testingPhase = async (data) => {
    await this.setState({ resetFlag: false });
    await this.props.lisDistribution(data);
    await this.setState({ resetFlag: true });
  };
 

  async componentDidMount() {
    const currentDate = moment(new Date()).format("MM/DD/YYYY");
    const { dashletExpanded, searchCritirea, dropdowns } = this.props;
    this.state.dropdown = [...dropdowns, SELECT_OBJECT]
    const plan = dropdowns[0].label;
    if (!dashletExpanded) {
      await this.props.lisDistribution({
        contractsList: [plan],
        date: currentDate,
      });
      await this.props.setSearchCritirea({
        ...searchCritirea,
        lisDistribution: {
          plan: plan,
          date: currentDate,
        },
      });
    } else {
      this.setState({
        contractsList: searchCritirea.lisDistribution.plan,
        date: searchCritirea.lisDistribution.date,
        resetFlag: true
      });
    }
    this.setChartData();
  }
  setChartData = async () => {
    const { chartData, chartDataset } = this.props;
    const Labels = [];
    const legendLabels = ["Not Low - Income", "High ", "Low ", "0", "15%"];

    const colorArray = ["blue", "green", "red", "yellow", "black"];
    const array = [[], [], [], [], []];

    const Dataset = [];

    if (!isEmpty(chartData)) {
      chartData.forEach((item) => {
        Labels.push(item.planId);
        array[0].push(item.lowIncomeCount ? parseInt(item.lowIncomeCount) : 0);
        array[1].push(
          item.highIncomeCount ? parseInt(item.highIncomeCount) : 0
        );
        array[2].push(item.lowCount ? parseInt(item.lowCount) : 0);
        array[3].push(item.zeroCount ? parseInt(item.zeroCount) : 0);
        array[4].push(
          item.fifteenPerCount ? parseInt(item.fifteenPerCount) : 0
        );
      });
    }
    legendLabels.forEach((value, index) => {
      let dataset = {
        type: "bar",
        label: value,
        backgroundColor: colorArray[index],
        data: array[index],
      };
      Dataset.push(dataset);
    });

    await this.props.storeChartDataset({
      ...chartDataset,
      lisDistribution: { Labels: Labels, Dataset: Dataset },
    });
  };
  handleChangeSearchSelectAuto = (event) => {
    let value = event.value;
    this.setState({
      contractsList: value,
      collapse: false,
    });
  };
  handleChange = (event) => {
    let value = event.target.value;
    this.setState({
      date: handleDateChange(value),
      collapse: false,
    });
  };
  handleResetAppl = (e) => {
    e.preventDefault();

    this.setState({
      contractsList: "",
      date: "",
      collapse: false,
    });
  };
  handleSubmit = async (e) => {
    e.preventDefault();
    const { date, contractsList } = this.state;
    const { searchCritirea } = this.props;
    if (!this.validator.allValid()) {
      this.validator.showMessages();
      this.forceUpdate();
      this.setState({
        collapse: false,
      });
    } else {
      await this.props.lisDistribution({
        contractsList: [contractsList],
        date: date,
      });
      await this.props.setSearchCritirea({
        ...searchCritirea,
        lisDistribution: {
          plan: contractsList,
          date: date,
        },
      });
      this.validator.hideMessages();
      this.forceUpdate();
      this.setChartData();
    }
  };
  handleDates = (event) => {
    let fieldId = "#" + event.target.name;
    var self = this;
    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (event) => {
        if (
          dateChk.name !== event.target.name ||
          dateChk.value !== event.target.value
        ) {
          self.setDate(event.target.name, event.target.value);
          document.getElementById(fieldId.substr(1)).focus();
        }
        dateChk.name = event.target.name;
        dateChk.value = event.target.value;
      });
  };

  setDate = (name, value) => {
    this.setState({
      date: value,
      collapse: false,
    });
  };

  getLabel = (tooltipItem, data) => {
    let index = tooltipItem.datasetIndex;
    let label = data.datasets[index].label;
    let value = tooltipItem.value;
    return label + " : " + value;
  };

  render() {
    const {
      classes,
      dashletExpanded,
      chartDataset,
      spin,
    } = this.props;
    const { contractsList, date, collapse, dropdown } = this.state;
    const { Dataset, Labels } = chartDataset.lisDistribution;
    const Data = {
      labels: Labels,
      datasets: Dataset,
    };
    const Options = {
      scales: {
        yAxes: [
          {
            scaleLabel: {
              display: true,
              labelString: "LIS Distribution Count",
            },
            ticks: {
              min: 0,
            },
          },
        ],
      },
      plugins: {
        datalabels: {
          display: false,
        },
      },
      legend: {
        position: "right",
      },
      tooltips: {
        callbacks: {
          label: (a, b) => this.getLabel(a, b),
        },
      },
      responsive: true,
      maintainAspectRation: false,
      animation: false,
    };
    const datasetObj =Object.values(Data.datasets);   
    for (const value of datasetObj) {
    var valuesZero = Object.values(value.data).every( num => {
        return num === 0;});
    }
    return (
      <div>
        {spin === true ? <div id="dashlet-spin" /> : null}
        {dashletExpanded ? (
          <div className={classes.header2}>
            <b>LIS Distribution</b>

            <ExpansionPanel
              summary="Search"
              defaultCollapsed={collapse}
              className={classes.containertypography}
            >
              <div class="panel-body" className={classes.panelBody}>
                <form onSubmit={this.handleSubmit} autoComplete="off">
                  <div className={classes.container}>
                    <div>
                      
                      <Autocomplete1
                        handleChange={this.handleChangeSearchSelectAuto}
                        label="Contracts List"
                        options={dropdown}
                        defaultValue={{label:'Select', value:''}}
                        value={dropdown.filter(
                          (option) => option.value === contractsList
                        )[0]}
                        name="plan"
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "Contract",
                          contractsList,
                          "required"
                        )}
                      </div>
                    </div>
                    <div   style={{marginLeft:'35px'}}>
                      <InputField
                        width="150px"
                        name="date"
                        label="Date"
                        maxLength={10}
                        value={date}
                        onClick={(e) => {
                          this.handleDates(e);
                        }}
                        onChange={(e) => {
                          this.handleChange(e);
                        }}
                        placeholder="MM/DD/YYYY"
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message("Date", date, "date_format")}
                      </div>
                    </div>

                    <span
                      class="button-container-search"
                      className={classes.expansionPanelbuttons}
                    >
                      <button id="search" class="btn btn-primary icon-search">
                        Search
                      </button>
                      <button
                        id="reset"
                        class="btn btn-secondary"
                        onClick={this.handleResetAppl}
                      >
                        Reset
                      </button>
                    </span>
                  </div>
                </form>
              </div>
            </ExpansionPanel>
          </div>
        ) : null}

        {!dashletExpanded && !spin ? (
          <div className={classes.chartContainer2}>
             {valuesZero ? 
              <div className = {classes.centreAlign}>
              No data to display
              </div> :
            <Chart type="bar" data={Data} options={Options} />}
          </div>
        ) : (
          <div>
            {!spin ? (
              <div className={classes.space}>
                 {valuesZero ? 
                  <div className = {classes.centreAlign1}>
                  No data to display
                  </div> :
                <Chart type="bar" data={Data} options={Options} width="675px" />}
              </div>
            ) : null}
          </div>
        )}
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    chartData: state.dashboard.lisDistribution.data,
    spin: state.dashboard.lisDistribution.spin,
    dropdowns: state.dashboard.customerPlanIds,
    chartDataset: state.dashboard.chartDataset,
    searchCritirea: state.dashboard.searchCritireaVo,
    searchFlag: state.dashboard.lisDistribution.searchFlag,
    checkedList: state.dashboard.checkedList,
  };
};
const mapDispatchToProps = {
  lisDistribution,
  storeChartDataset,
  setSearchCritirea,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(LisDistribution));
