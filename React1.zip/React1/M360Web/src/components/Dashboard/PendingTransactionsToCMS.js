import React, { Component } from "react";
import DataTable from "../Home/DataTable";
import { Styles } from "../../assets/styles/DashboradStyles";
import { withStyles } from "@material-ui/core/styles";
import { connect } from "react-redux";
import { Chart } from "primereact/chart";
import "chartjs-plugin-datalabels";
import { pendingTransactionsToCMS } from "../../redux/actions/DashboardActions";
import { CMS_STATUS as header } from "../../constants/Headers/DashboardHeaders";
import classNames from "classnames";
import Popup from "reactjs-popup";
import isEmpty from "lodash/isEmpty"

class PendingTransactionsToCMS extends Component {
  constructor(props) {
    super(props);
    this.state = {
      colorData: [],
      labelData: [],
      valueData: [],
      label: "",
      rowsPerPage: 10,
      selectedRowIndex: 0,
      index: 0,
      tableData: [],
      openPopup: false,
       resetFlag: false,
    };
  }
  closePopup = () => {
    this.setState({
      openPopup: false,
    });
  };
  async componentWillReceiveProps(nextProps, prevState) {
    const { searchFlag } = nextProps;
        if (!isEmpty(nextProps.chartData)) {
      if (
        searchFlag &&
        this.state.resetFlag &&
        nextProps.checkedList &&
        !isEmpty(nextProps.checkedList) &&
        nextProps.checkedList.includes("Pending Transaction To CMS")
      ) {
        return this.testingPhase();
      }
    }
    
  }
  
  testingPhase = async () => {
    await this.setState({ resetFlag: false });
    await this.props.pendingTransactionsToCMS();
    await this.setState({ resetFlag: true });
  };


  async componentDidMount() {
    if (!this.props.dashletExpanded) {
      await this.props.pendingTransactionsToCMS();
      this.setState({ resetFlag: true });
    }

    this.setChartData();
  }
  setChartData = () => {
    let labelArray = [];
    let valueArray = [];

    for (let i = 0; i < Object.keys(this.props.chartData).length; i++) {
      const label = Object.keys(this.props.chartData)[i];
      const value = this.props.chartData[label].length;
      labelArray.push(label);
      valueArray.push(value);
    }
    this.setState({
      labelData: labelArray,
      valueData: valueArray,
    });
  };
  clicked = (event, item) => {
    if (item[0]) {
      let label = item[0]._model.label; //label of clicked item
      let labelArray = Object.keys(this.props.chartData);
      let index = labelArray.indexOf(label); //index of clicked item
      let name = labelArray[index];
      this.setState({
        label: label.toUpperCase(),
        index: index,
        tableData: this.props.chartData[name],
        openPopup: true,
      });
    }
  };

  handleChangeRowsPerPage = async (rowsPerPage) => {
    this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  //dont remove selectedData parameter
  rowSelect = async (index, selectedData, rowsPerPage) => {
    this.setState(() => ({
      rowsPerPage: rowsPerPage,
      selectedRowIndex: index,
    }));
  };
  getTooltip = (tooltipItem, data) => {
    let index = tooltipItem.index;
    let label = data.labels[index];
    let value = data.datasets[0].data[index];
    return label + " : " + value + " APPLICATIONS";
  };

  render() {
    const {
      label,
      labelData,
      valueData,
      rowsPerPage,
      selectedRowIndex,
      tableData,
      openPopup,
    } = this.state;

    const options = {
      plugins: {
        responsive: true,
        maintainAspectRatio: false,
        datalabels: {
          display: false,
        },
      },

      tooltips: {
        callbacks: {
          label: (tooltipItem, data) => this.getTooltip(tooltipItem, data),
        },
      },
      legend: {
        position: "right",
        animation: false,
      },
      onClick: this.clicked,
      animation: false,
    };

    const data = {
      labels: labelData,
      datasets: [
        {
          data: valueData,
          backgroundColor: ["#0accf7", "#761191", "#f5ad11"],
          hoverBackgroundColor: ["#0accf7", "#761191", "#f5ad11"],
        },
      ],
    };
    const { classes, spin } = this.props;
    let valuesZero=  Object.values(valueData).every( value => {
      return value === 0; });
    return (
      <div>
        {spin === true ? <div id="dashlet-spin" /> : null}
        {!this.props.dashletExpanded && !spin ? (
          <div className={classes.chartContainer2}>
            {valuesZero ? 
            <div className = {classes.centreAlign}>
            No data to display
            </div> :
            <Chart type="doughnut" data={data} options={options} />}
          </div>
        ) : (
          <div>
            {!spin ? (
              <>
                <div className={classes.header2}>
                  Pending Transactions To CMS
                </div>
                <div className={classes.space}>
                {valuesZero ? 
            <div className = {classes.centreAlign}>
            No data to display
            </div> :
                  <Chart
                    type="doughnut"
                    data={data}
                    options={options}
                    width="500px"
                    height="355px"
                  />}
                </div>
              </>
            ) : null}

            <div>
              {label.length > 0 && this.props.dashletExpanded ? (
                <Popup
                  className={classes.popuptheme}
                  modal
                  open={openPopup}
                  onClose={this.closePopup}
                  contentStyle={{ width: "90%", height: "72%" }}
                >
                  {(close) => (
                    <div>
                      <i
                        class={classNames("fa fa-times", classes.closePop)}
                        onClick={this.closePopup}
                      ></i>
                      <div className={classes.header2}>
                        <b>{label}</b>
                      </div>
                      <DataTable
                        data={tableData}
                        header={header}
                        rowsPerPage={rowsPerPage}
                        exportAsExcel={true}
                        rowsPerPageOptions={[10, 15, 20]}
                        clicked={this.rowSelect}
                        index={selectedRowIndex}
                        handleChangeRowsPerPage={this.handleChangeRowsPerPage}
                      />
                    </div>
                  )}
                </Popup>
              ) : null}
            </div>
          </div>
        )}
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    chartData: state.dashboard.pendingTransactionsToCMS.data,
    spin: state.dashboard.pendingTransactionsToCMS.spin,
    searchFlag: state.dashboard.pendingTransactionsToCMS.searchFlag,
    checkedList: state.dashboard.checkedList,
  };
};

const mapDispatchToProps = {
  pendingTransactionsToCMS,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(PendingTransactionsToCMS));
