import React, { Component } from "react";
import DataTable from "../Home/DataTable";
import { Styles } from "../../assets/styles/DashboradStyles";
import { withStyles } from "@material-ui/core/styles";
import { connect } from "react-redux";
import { Chart } from "primereact/chart";
import "chartjs-plugin-datalabels";
import { cmsStatus } from "../../redux/actions/DashboardActions";
import { CMS_STATUS as header } from "../../constants/Headers/DashboardHeaders";

import Popup from "reactjs-popup";
import { isEmptyObject } from "jquery";
import isEmpty from "lodash/isEmpty";

class CMSStatus extends Component {
  constructor(props) {
    super(props);
    this.state = {
      labelData: [],
      valueData: [],
      label: "",
      rowsPerPage: 10,
      selectedRowIndex: 0,
      index: 0,
      tableData: [],
      openPopup: false,
      resetFlag: false,
    };
  }
  closePopup = () => {
    this.setState({
      openPopup: false,
    });
  };
  //    static  getDerivedStateFromProps(nextProps, prevState) {
  //     const { searchFlag } = nextProps;

  // // alert(searchFlag)
  // //     if(searchFlag){
  // //       return{
  // //         resetFlag:true
  // //       }
  // //     }
  // //     else{
  // //       return{
  // //         resetFlag:false
  // //       }
  // //     }
  //     if(Object.keys(nextProps.chartData).length != 0){
  //       console.log(searchFlag )
  //       console.log( prevState.resetFlag)
  //       if (searchFlag && prevState.resetFlag ) {
  //         debugger;
  //       let data = nextProps.cmsStatus();
  //         return{
  //           resetFlag:false
  //         }

  //       }

  //     }

  //       return{
  //         resetFlag:true
  //       }

  //   }

  async componentWillReceiveProps(nextProps, prevProps) {
    const { searchFlag } = nextProps;
    console.log(nextProps.chartData);

    if (!isEmpty(nextProps.chartData)) {
      if (
        searchFlag &&
        this.state.resetFlag &&
        nextProps.checkedList &&
        !isEmpty(nextProps.checkedList) &&
        nextProps.checkedList.includes("CMS Status")
      ) {
        return this.testingPhase();
      }
    }
  }

  testingPhase = async () => {
    await this.setState({ resetFlag: false });
    await this.props.cmsStatus();
    await this.setState({ resetFlag: true });
  };

  async componentDidMount() {
    if (!this.props.dashletExpanded) {
      await this.props.cmsStatus();
      this.setState({ resetFlag: true });
    }
    this.setChartData();
  }
  setChartData = () => {
    let labelArray = [];
    let valueArray = [];

    for (let i = 0; i < Object.keys(this.props.chartData).length; i++) {
      const label = Object.keys(this.props.chartData)[i];
      const value = Object.values(this.props.chartData)[i].length;
      labelArray.push(label);
      valueArray.push(value);
    }
    this.setState({
      labelData: labelArray,
      valueData: valueArray,
    });
  };
  clicked = (event, item) => {
    if (item[0]) {
      let label = item[0]._model.label; //label of clicked item
      let labelArray = Object.keys(this.props.chartData);
      let index = labelArray.indexOf(label); //index of clicked item
      let name = labelArray[index];
      this.setState({
        label: label.toUpperCase(),
        index: index,
        tableData: this.props.chartData[name],
        openPopup: true,
      });
    }
  };

  handleChangeRowsPerPage = async (rowsPerPage) => {
    this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  //dont remove selectedData parameter
  rowSelect = async (index, selectedData, rowsPerPage) => {
    this.setState(() => ({
      rowsPerPage: rowsPerPage,
      selectedRowIndex: index,
    }));
  };

  getTooltip = (tooltipItem, data) => {
    let index = tooltipItem.index;
    let label = data.labels[index];
    let value = data.datasets[0].data[index];
    return label + " : " + value + " APPLICATIONS";
  };

  render() {
    const {
      label,
      labelData,
      valueData,
      rowsPerPage,
      selectedRowIndex,
      tableData,
      openPopup,
    } = this.state;
    const { spin } = this.props;
    const options = {
      plugins: {
        responsive: true,
        maintainAspectRatio: false,
        datalabels: {
          display: false,
        },
      },
      tooltips: {
        callbacks: {
          label: (tooltipItem, data) => this.getTooltip(tooltipItem, data),
        },
      },
      legend: {
        position: "right",
        animation: false,
      },
      onClick: this.clicked,
      animation: false,
    };

    const data = {
      labels: labelData,
      datasets: [
        {
          data: valueData,
          backgroundColor: [
            "#db6e14",
            "#27db51",
            "#8427db",
            "#bddb27",
            "#25dbcc",
          ],
          hoverBackgroundColor: [
            "#db6e14",
            "#27db51",
            "#8427db",
            "#bddb27",
            "#25dbcc",
          ],
        },
      ],
    };
    const { classes } = this.props;
    let valuesZero=  Object.values(valueData).every( value => {
      return value === 0;});
    return (
      <div>
        {spin === true ? <div id="dashlet-spin" /> : null}
        {!this.props.dashletExpanded && !spin ? (
          <div className={classes.chartContainer2}>
             {valuesZero ? 
            <div className = {classes.centreAlign}>
            No data to display
            </div> :
            <Chart type="pie" data={data} options={options} />}
          </div>
        ) : (
          <div>
            {!spin ? (
              <>
                <div className={classes.header2}> CMS Status</div>
                <div className={classes.space}>
                {valuesZero ? 
            <div className = {classes.centreAlign1}>
            No data to display
            </div> :
                  <Chart
                    type="pie"
                    data={data}
                    options={options}
                    width="675px"
                  />}
                </div>
              </>
            ) : null}
            <div>
              <Popup
                className={classes.popuptheme}
                modal
                open={openPopup}
                onClose={this.closePopup}
                contentStyle={{ width: "80%", height: "68%" }}
              >
                {(close) => (
                  <div>
                    <i className="close" onClick={this.closePopup}>
                      &times;
                    </i>
                    <div className={classes.header2}>
                      <b>{label}</b>
                    </div>
                    <DataTable
                      data={tableData}
                      header={header}
                      rowsPerPage={rowsPerPage}
                      exportAsExcel={true}
                      rowsPerPageOptions={[10, 15, 20]}
                      clicked={this.rowSelect}
                      index={selectedRowIndex}
                      handleChangeRowsPerPage={this.handleChangeRowsPerPage}
                    />
                  </div>
                )}
              </Popup>
            </div>
          </div>
        )}
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    chartData: state.dashboard.cmsStatus.data,
    spin: state.dashboard.cmsStatus.spin,
    searchFlag: state.dashboard.cmsStatus.searchFlag,
    checkedList: state.dashboard.checkedList,
  };
};

const mapDispatchToProps = {
  cmsStatus,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(CMSStatus));
