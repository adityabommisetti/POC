import React, { Component } from "react";
import Checkbox from "@material-ui/core/Checkbox";
import Button from "@material-ui/core/Button";
import ExpansionPanel from "../UI/ExpansionPanel";
import { Dashlet_LIST } from "../../constants/staticData/DashboradTest";
import { withStyles } from "@material-ui/core/styles";
import { Styles } from "../../assets/styles/DashboradStyles";
import {
  getcustomerPlanIds,
  applicationAging,
  dashboardSearchFlag,
} from "../../redux/actions/DashboardActions";
import { connect } from "react-redux";
import { resetMemberSearch } from "../../redux/actions/MemberActions";
import isEmpty from "lodash/isEmpty";
import Dashlet from "./Card";
import Modal from "../../components/UI/Modal/Modal";
import "../../assets/css/dashletSpinner.css";

const Checkbox1 = withStyles((theme) => ({
  root: {
    padding: "5px 0px 5px 0px !important",
  },
}))(Checkbox);
class NewDashboard extends Component {
  constructor() {
    super();
    this.state = {
      checkedList: [],
      collapse: false,
      showDashlets: false,
      checkedItemList: [],
      closePopup: false,
    };
  }

  async componentDidMount() {
    if (isEmpty(this.props.dropdowns)) {
      await this.props.getcustomerPlanIds();
    }
    this.setState({
      checkedList: this.props.checkedList,
      showDashlets: true,
      checkedItemList: this.props.checkedList,
    });
  }
  handleChange = (e) => {
    let checkedList = [...this.state.checkedItemList];

    if (checkedList.length > 5 && e.target.checked) {
      this.setState({
        closePopup: true,
        message: "There is a maximum limit of 6 dashlets per view ",
      });
    } else {
      if (e.target.checked) checkedList.push(e.target.name);
      else checkedList.splice(checkedList.indexOf(e.target.name), 1);
      this.setState({ checkedItemList: checkedList, collapse: false });
    }
  };
  componentWillUnmount() {
    this.props.resetMemberSearch({
      applicationId: this.props.selectedMemberId.applicationId,
    });
  }

  reset = () => {
    this.setState({
      checkedList: [],
    });
  };
  submit = async () => {
    if (this.state.checkedItemList.length === 0) {
      this.setState({
        closePopup: true,
        message: "Please select at least 1 dashlet",
        collapse: false,
      });
    } else {
      await this.props.dashboardSearchFlag({
        checkedList: this.state.checkedItemList,
      });

      this.setState({
        showDashlets: true,
        collapse: true,
        checkedList: this.state.checkedItemList,
      });
    }
  };
  modalClosed = () => {
    this.setState({ closePopup: false });
  };
  reset = () => {
    this.setState({
      checkedItemList: [],
      collapse: false,
      showDashlets: false,
    });
  };
  render() {
    const { classes } = this.props;
    const {
      checkedList,
      showDashlets,
      collapse,
      checkedItemList,
      message,
    } = this.state;
    return (
      <div>
        <Modal
          dialogTitle="Dashboard View"
          message={message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <ExpansionPanel summary="Dashboard" defaultCollapsed={collapse}>
          <div className={classes.container}>
            <div className={classes.checkcontainer}>
              {Dashlet_LIST.map((item) => (
                <div className={classes.dashBoardCheckbox}>
                  <Checkbox1
                    color="primary"
                    checked={checkedItemList.includes(item)}
                    onChange={this.handleChange}
                    name={item}
                    padding={"0px 0px 0px 0px !important"}
                  />
                  <span className={classes.checkboxlebel}>{item}</span>
                </div>
              ))}
              <Button
                variant="contained"
                color="primary"
                className={classes.button}
                onClick={this.submit}
              >
                Apply
              </Button>
              <Button
                variant="contained"
                color="primary"
                className={classes.button}
                onClick={this.reset}
              >
                Reset
              </Button>
            </div>
          </div>
        </ExpansionPanel>

        {showDashlets ? (
          <div class="row">
            {checkedList.map((item) => {
              return (
                <div class="col-md-4">
                  <Dashlet index={Dashlet_LIST.indexOf(item)} title={item} />
                </div>
              );
            })}
          </div>
        ) : null}
      </div>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    selectedMemberId: state.memberSearch.selectedMemberId,
    dropdowns: state.dashboard.customerPlanIds,
    checkedList: state.dashboard.checkedList,
  };
};

const mapDispatchToProps = {
  getcustomerPlanIds,
  resetMemberSearch,
  applicationAging,
  dashboardSearchFlag,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(NewDashboard));
