import React, { Component } from "react";
import { Styles } from "../../assets/styles/DashboradStyles";
import { withStyles } from "@material-ui/core/styles";
import { connect } from "react-redux";
import { Chart } from "primereact/chart";
import "chartjs-plugin-datalabels";
import { specialDistribution } from "../../redux/actions/DashboardActions";
import isEmpty from "lodash/isEmpty";

class SpecialDistribution extends Component {
  constructor(props) {
    super(props);
    this.state = {
      labelData: ["Special Status"],
      chartDatasets: [],
      label: "",
      resetFlag: false
    };
  }
  async componentWillReceiveProps(nextProps, prevState) {
    const { searchFlag } = nextProps;
        if (!isEmpty(nextProps.chartData)) {
      if (
        searchFlag &&
        this.state.resetFlag &&
        nextProps.checkedList &&
        !isEmpty(nextProps.checkedList) &&
        nextProps.checkedList.includes("Special Status Distribution")
      ) {
        return this.testingPhase();
      }
    }
    
  }
  
  testingPhase = async () => {
    await this.setState({ resetFlag: false });
    await this.props.specialDistribution();
    await this.setState({ resetFlag: true });
  };
  
  async componentDidMount() {
    if (!this.props.dashletExpanded) {
      await this.props.specialDistribution();
      this.setState({ resetFlag: true });
    }
    this.setChartData();
  }
  setChartData = () => {
    let labelArray = [];
    let valueArray = [];
    let chartDatasets = [];
    const colorArray = [
      "#eb4034",
      "#8af558",
      "#4e524d",
      "#255951",
      "#cf57a7",
      "#8f5004",
      "#273d61",
    ];

    for (let i = 0; i < Object.keys(this.props.chartData).length; i++) {
      valueArray = [];
      const label = Object.keys(this.props.chartData)[i];
      const value = parseInt(Object.values(this.props.chartData)[i]);
      const color = colorArray[i];
      labelArray.push(label);
      valueArray.push(value);
      let dataset = {
        label: label,
        backgroundColor: color,
        data: valueArray,
      };
      chartDatasets.push(dataset);
    }
    this.setState({
      chartDatasets: chartDatasets,
    });
  };
  getLabel = (tooltipItem, data) => {
    let index = tooltipItem.datasetIndex;
    let label = data.datasets[index].label;
    let value = tooltipItem.value;
    return label + " : " + value;
  };

  render() {
    const { labelData, chartDatasets } = this.state;

    const options = {
      scales: {
        yAxes: [
          {
            scaleLabel: {
              display: true,
              labelString: "Distribution Count",
            },
            ticks: {
              min: 0,
            },
          },
        ],
      },
      plugins: {
        responsive: true,
        maintainAspectRatio: false,
        datalabels: {
          display: false,
        },
      },
      tooltips: {
        callbacks: {
          label: (tooltipItem, data) => this.getLabel(tooltipItem, data),
        },
      },
      legend: {
        position: "right",
        animation: false,
      },

      animation: false,
    };

    const data = {
      labels: labelData,
      datasets: chartDatasets,
    };
    const { classes, spin, dashletExpanded } = this.props;
    const datasetObj =Object.values(data.datasets);   
    for (const value of datasetObj) {
    var valuesZero = Object.values(value.data).every( num => {
        return num === 0;});
    }
    return (
      <div>
        {spin === true ? <div id="dashlet-spin" /> : null}
        {!dashletExpanded && !spin ? (
          <div className={classes.chartContainer2}>
             {valuesZero ? 
              <div className = {classes.centreAlign}>
              No data to display
              </div> :
            <Chart type="bar" data={data} options={options} />}
          </div>
        ) : (
          <div>
            <div className={classes.header2}> Special Status Distribution</div>
            {!spin ? (
              <div className={classes.space}>
                 {valuesZero ? 
                <div className = {classes.centreAlign1}>
                No data to display
                </div> :
                <Chart type="bar" data={data} options={options} width="675px" />}
              </div>
            ) : null}
            <div></div>
          </div>
        )}
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    chartData: state.dashboard.specialStatus.data,
    spin: state.dashboard.specialStatus.spin,
    searchFlag: state.dashboard.specialStatus.searchFlag,
    checkedList: state.dashboard.checkedList,
  };
};

const mapDispatchToProps = {
  specialDistribution,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(SpecialDistribution));
