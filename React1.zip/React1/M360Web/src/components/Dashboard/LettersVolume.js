import React, { Component } from "react";
import { letterDistribution } from "../../redux/actions/DashboardActions";
import { Styles } from "../../assets/styles/DashboradStyles";
import { withStyles } from "@material-ui/core/styles";
import { connect } from "react-redux";
import { Chart } from "primereact/chart";
import "chartjs-plugin-datalabels";
import isEmpty from "lodash/isEmpty";

class LettersVolume extends Component {
  constructor(props) {
    super(props);
    this.state = {
      labelData: ["Letters"],
      chartDatasets: [],
      label: "",
      resetFlag: false,
    };
  }
  async componentWillReceiveProps(nextProps, prevState) {
    const { searchFlag } = nextProps;
    console.log("chart--->  " + nextProps.chartData);
    console.log("reset--->" + this.state.resetFlag);
    console.log(!isEmpty(nextProps.chartData));
    console.log("search--->" + searchFlag);
    console.log(
      "cheching --->" +
        nextProps.checkedList.includes("Letters Volume Distribution")
    );
    if ((nextProps.chartData)) {
      if (
        searchFlag &&
        this.state.resetFlag &&
        nextProps.checkedList &&
        !isEmpty(nextProps.checkedList) &&
        nextProps.checkedList.includes("Letters Volume Distribution")
      ) {
        return this.testingPhase();
      }
    } 
  }
  testingPhase = async () => {
    await this.setState({ resetFlag: false });
    await this.props.letterDistribution();
    await this.setState({ resetFlag: true });
  };
  randomColorGenerator = () => {
    var r = Math.floor(Math.random() * 255);
    var g = Math.floor(Math.random() * 255);
    var b = Math.floor(Math.random() * 255);
    return "rgb(" + r + "," + g + "," + b + ")";
  };

  async componentDidMount() {
    if (!this.props.dashletExpanded) {
      await this.props.letterDistribution();
      this.setState({ resetFlag: true });
    }
    this.setChartData();
  }
  setChartData = () => {
    let valueArray = [];
    let chartDatasets = [];
    const colorArray = ["#4d5243", "#273d63"];
    for (let i = 0; i < Object.keys(this.props.chartData).length; i++) {
      valueArray = [];
      const label = Object.keys(this.props.chartData)[i];
      const value = parseInt(Object.values(this.props.chartData)[i]);
      const color = colorArray[i];
      valueArray.push(value);
      let dataset = {
        label: label,
        backgroundColor: color,
        data: valueArray,
      };
      chartDatasets.push(dataset);
    }
    this.setState({
      chartDatasets: chartDatasets,
    });
  };
  getLabel = (tooltipItem, data) => {
    let index = tooltipItem.datasetIndex;
    let label = data.datasets[index].label;
    let value = tooltipItem.value;
    return label + " : " + value;
  };

  render() {
    const { labelData, chartDatasets } = this.state;
    const { spin, classes, dashletExpanded } = this.props;
    const options = {
      scales: {
        yAxes: [
          {
            scaleLabel: {
              display: true,
              labelString: "Letters Volume Count",
            },
            ticks: {
              min: 0,
            },
          },
        ],
      },
      plugins: {
        responsive: true,
        maintainAspectRatio: false,
        datalabels: {
          display: false,
        },
      },
      tooltips: {
        callbacks: {
          label: (tooltipItem, data) => this.getLabel(tooltipItem, data),
        },
      },
      legend: {
        position: "right",
        animation: false,
      },

      animation: false,
    };

    const data = {
      labels: labelData,
      datasets: chartDatasets,
    };
    let valuesZero=  Object.values(chartDatasets).every( value => {
      return value === 0;});

    return (
      <div>
        {spin === true ? <div id="dashlet-spin" /> : null}
        {!dashletExpanded && !spin ? (
          <div className={classes.chartContainer2}>
            {valuesZero ? 
              <div className = {classes.centreAlign}>
              No data to display
              </div> :
            <Chart type="bar" data={data} options={options} />}
          </div>
        ) : (
          <div>
            <div className={classes.header2}> Letter Volume Distribution</div>
            {!spin ? (
              <div className={classes.space}>
                {valuesZero ? 
                  <div className = {classes.centreAlign}>
                  No data to display
                  </div> :
                <Chart type="bar" data={data} options={options} width="675px" />}
              </div>
            ) : null}
            <div></div>
          </div>
        )}
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    chartData: state.dashboard.letterDistribution.data,
    spin: state.dashboard.letterDistribution.spin,
    searchFlag: state.dashboard.letterDistribution.searchFlag,
    checkedList: state.dashboard.checkedList,
  };
};

const mapDispatchToProps = {
  letterDistribution,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(LettersVolume));
