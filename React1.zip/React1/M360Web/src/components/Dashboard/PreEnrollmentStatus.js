import React, { Component } from "react";
import DataTable from "../Home/DataTable";
import { Styles } from "../../assets/styles/DashboradStyles";
import { withStyles } from "@material-ui/core/styles";
import { connect } from "react-redux";
import { Chart } from "primereact/chart";
import "chartjs-plugin-datalabels";
import {
  preEnrollmentStatus,
  storeChartDataset,
  setSearchCritirea,
} from "../../redux/actions/DashboardActions";
import { PRE_ENROLLMENT_STATUS as header } from "../../constants/Headers/DashboardHeaders";
import ExpansionPanel from "../UI/ExpansionPanel";
import InputField from "../UI/InputField";
import { handleDateChange } from "../../utils/DateFormatter";
import * as DateUtil from "../../utils/DatePicker";
import SimpleReactValidator from "simple-react-validator";
import { customValidations } from "../../utils/CustomValidations";
import Popup from "reactjs-popup";
import moment from "moment";
import isEmpty from "lodash/isEmpty";

const INITIAL_STATE = {
  startDate: "",
  endDate: "",
};
const dateChk = {};

class PreEnrollmentStatus extends Component {
  constructor(props) {
    super(props);
    this.state = {
      label: "",
      rowsPerPage: 10,
      selectedRowIndex: 0,
      index: 0,
      tableData: [],
      searchVo: {
        endDate: moment(new Date()).format("MM/DD/YYYY"),
        startDate: moment(moment().subtract(30, "days")).format("MM/DD/YYYY"),
      },
      openPopup: false,
      collapse: false,
      resetFlag: false,
    };

    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
        c_after_or_equal_99: customValidations.c_after_or_equal_99,
      },
    });
  }
  async componentWillReceiveProps(nextProps, prevState) {
    const { searchVo } = prevState;
    const { searchFlag } = nextProps;
    console.log("chart--->  " + isEmpty(nextProps.chartData));
    console.log("reset--->" + this.state.resetFlag);
    console.log(isEmpty(nextProps.chartData));
    console.log("search--->" + searchFlag);
    console.log(
      "cheching --->" + nextProps.checkedList.includes("Pre-Enrollment Status")
    );
    if (!isEmpty(nextProps.chartData)) {
      if (
        searchFlag &&
        this.state.resetFlag &&
        nextProps.checkedList &&
        !isEmpty(nextProps.checkedList) &&
        nextProps.checkedList.includes("Pre-Enrollment Status")
      ) {
        return this.testingPhase({
          startDate: this.state.searchVo.startDate,
          endDate: this.state.searchVo.endDate,
        });
      }
    }
  }

  testingPhase = async (data) => {
    await this.setState({ resetFlag: false });
    await this.props.preEnrollmentStatus(data);
    await this.setState({ resetFlag: true });
  };

  async componentDidMount() {
    const { startDate, endDate } = this.state.searchVo;
    const { dashletExpanded, searchCritirea } = this.props;

    if (!dashletExpanded) {
      await this.props.preEnrollmentStatus({
        startDate: startDate,
        endDate: endDate,
      });
      await this.props.setSearchCritirea({
        ...searchCritirea,
        preEnrollmentStatus: {
          startDate: startDate,
          endDate: endDate,
        },
      });
    } else {
      await this.setState((prevState) => ({
        ...prevState,
        searchVo: {
          startDate: searchCritirea.preEnrollmentStatus.startDate,
          endDate: searchCritirea.preEnrollmentStatus.endDate,
        },
      }));
    }
    this.setState({ resetFlag: true });
    this.validator.hideMessages();
    this.forceUpdate();
    this.setChartData();
  }

  handleChange = (event) => {
    let value = event.target.value;
    let name = event.target.name;
    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: handleDateChange(value),
      },
      collapse: false,
    }));
  };

  handleResetAppl = (e) => {
    e.preventDefault();
    this.validator.hideMessages();
    this.forceUpdate();
    this.setState({
      searchVo: {
        ...INITIAL_STATE,
      },
      collapse: false,
    });
  };

  setChartData = async () => {
    const { chartData, chartDataset } = this.props;
    let labelArray = [];
    let valueArray = [];
    //loop to extract labels and values for chart from response(json)
    for (let i = 0; i < Object.keys(chartData).length; i++) {
      const label = Object.keys(chartData)[i];
      const value = Object.values(chartData)[i].length;
      labelArray.push(label);
      valueArray.push(value);
    }

    await this.props.storeChartDataset({
      ...chartDataset,
      preEnrollmentStatusData: {
        Labels: labelArray,
        Values: valueArray,
      },
    });
  };

  handleSubmit = async (e) => {
    e.preventDefault();
    const { searchVo } = this.state;
    const { searchCritirea } = this.props;
    if (!this.validator.allValid()) {
      this.validator.showMessages();
      this.forceUpdate();
      this.setState({
        collapse: false,
      });
    } else {
      await this.props.preEnrollmentStatus({
        startDate: searchVo.startDate,
        endDate: searchVo.endDate,
      });
      await this.props.setSearchCritirea({
        ...searchCritirea,
        preEnrollmentStatus: {
          startDate: searchVo.startDate,
          endDate: searchVo.endDate,
        },
      });
      this.validator.hideMessages();
      this.forceUpdate();
      this.setChartData();
    }
  };

  handleDates = (event) => {
    let fieldId = "#" + event.target.name;
    var self = this;
    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (event) => {
        if (
          dateChk.name !== event.target.name ||
          dateChk.value !== event.target.value
        ) {
          self.setDate(event.target.name, event.target.value);
          document.getElementById(fieldId.substr(1)).focus();
        }
        dateChk.name = event.target.name;
        dateChk.value = event.target.value;
      });
  };

  setDate = (name, value) => {
    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value,
      },
      collapse: false,
    }));
  };

  clicked = (event, item) => {
    if (item[0]) {
      let label = item[0]._model.label; //label of clicked item
      let labelArray = Object.keys(this.props.chartData);
      let index = labelArray.indexOf(label); //index of clicked item
      let name = labelArray[index];
      this.setState({
        label: label.toUpperCase(),
        index: index,
        openPopup: true,
        tableData: this.props.chartData[name], //storing the data to be displayed in table
      });
    }
  };

  closePopup = () => {
    this.setState({
      openPopup: false,
    });
  };

  handleChangeRowsPerPage = async (rowsPerPage) => {
    this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  //dont remove selectedData parameter
  rowSelect = async (index, selectedData, rowsPerPage) => {
    this.setState(() => ({
      rowsPerPage: rowsPerPage,
      selectedRowIndex: index,
    }));
  };

  //To dispaly Text on hover of chart
  getTooltip = (tooltipItem, data) => {
    let index = tooltipItem.index;
    let label = data.labels[index];
    let value = data.datasets[0].data[index];
    return label + " : " + value + " APPLICATIONS";
  };

  render() {
    const {
      label,
      openPopup,
      rowsPerPage,
      selectedRowIndex,
      tableData,
      searchVo,
      collapse,
    } = this.state;
    const { classes, dashletExpanded, chartDataset, spin } = this.props;
    const { Labels, Values } = chartDataset.preEnrollmentStatusData;
    const options = {
      responsive: false,
      maintainAspectRatio: false,
      plugins: {
        datalabels: {
          display: false,
        },
      },
      tooltips: {
        callbacks: {
          label: (tooltipItem, data) => this.getTooltip(tooltipItem, data),
        },
      },
      legend: {
        display: dashletExpanded ? true : false,
        position: "right",
        animation: false,
      },
      onClick: this.clicked,
      animation: false,
    };

    const data = {
      labels: Labels,
      datasets: [
        {
          data: Values,
          backgroundColor: [
            "#b9edc4",
            "#abede2",
            "#5a8f86",
            "#56609c",
            "#529651",
            "#a68465",
            "#996077",
            "#609099",
            "#fcba03",
            "#abeb0c",
            "#17e68c",
            "#0889a3",
            "#f1a2f2",
            "#cbf065",
            "#ed0e19",
            "#a2f2d9",
            "#a665c7",
            "#1782e6",
            "#9c5856",
            "#3db307",
            "#b295db",
          ],
          hoverBackgroundColor: [
            "#b9edc4",
            "#abede2",
            "#5a8f86",
            "#56609c",
            "#529651",
            "#a68465",
            "#996077",
            "#609099",
          ],
        },
      ],
    };
    let valuesZero=  Object.values(Values).every( value => {
       return value === 0;});
    return (
      <div style={{ backgroundColor: "rgba(255, 255, 255, 0.7)" }}>
        {spin === true ? <div id="dashlet-spin" /> : null}

        {dashletExpanded ? (
          <div className={classes.header2}>
            <b>Pre Enrollment Status</b>

            <ExpansionPanel
              summary="Search"
              defaultCollapsed={collapse}
              className={classes.containertypography}
            >
              <div class="panel-body" className={classes.panelBody}>
                <form onSubmit={this.handleSubmit} autoComplete="off">
                  <div className={classes.container}>
                    <div>
                      <InputField
                        width="150px"
                        name="startDate"
                        label="Start Date"
                        maxLength={10}
                        value={searchVo.startDate}
                        onChange={(e) => {
                          this.handleChange(e);
                        }}
                        onClick={(e) => {
                          this.handleDates(e);
                        }}
                        placeholder="MM/DD/YYYY"
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "startdate",
                          searchVo.startDate,
                          "required|date_format"
                        )}
                      </div>
                    </div>
                    <div>
                      <InputField
                        width="150px"
                        name="endDate"
                        label="End Date"
                        maxLength={10}
                        value={searchVo.endDate}
                        onClick={(e) => {
                          this.handleDates(e);
                        }}
                        onChange={(e) => {
                          this.handleChange(e);
                        }}
                        placeholder="MM/DD/YYYY"
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message("EndDate", searchVo.endDate, [
                          "required",
                          "date_format",
                          { c_after_or_equal_99: searchVo.startDate },
                        ])}
                      </div>
                    </div>
                    <span
                      class="button-container-search"
                      className={classes.expansionPanelbuttons}
                    >
                      <button id="search" class="btn btn-primary icon-search">
                        Search
                      </button>
                      <button
                        id="reset"
                        class="btn btn-secondary"
                        onClick={this.handleResetAppl}
                      >
                        Reset
                      </button>
                    </span>
                  </div>
                </form>
              </div>
            </ExpansionPanel>
          </div>
        ) : null}

        {!dashletExpanded && !spin ? (
          <div className={classes.chartContainer2}>
            {valuesZero ? 
            <div className = {classes.centreAlign}>
            No data to display for selected dates
            </div> :
            <Chart
              type="pie"
              data={data}
              options={options}
              //width="350px"
              height="190px"
              //className={classes.chartContainer3}
            /> }
          </div>
        ) : (
          <div>
            {!spin ? (
              <div className={classes.space}>
                {valuesZero ? 
            <div className = {classes.centreAlign1}>
            No data to display for selected dates
            </div> :
                <Chart type="pie" data={data} options={options} width="675px" />}
              </div> 
            ) : null}

            <div>
              <Popup
                className={classes.popuptheme}
                modal
                open={openPopup}
                onClose={this.closePopup}
                contentStyle={{ width: "90%", height: "92%" }}
              >
                {(close) => (
                  <div>
                    <i className="close" onClick={this.closePopup}>
                      &times;
                    </i>
                    <div className={classes.header2}>
                      <b>{label}</b>
                    </div>
                    <DataTable
                      data={tableData}
                      header={header}
                      exportAsExcel={true}
                      rowsPerPage={rowsPerPage}
                      rowsPerPageOptions={[10, 15, 20]}
                      clicked={this.rowSelect}
                      index={selectedRowIndex}
                      handleChangeRowsPerPage={this.handleChangeRowsPerPage}
                    />
                  </div>
                )}
              </Popup>
            </div>
          </div>
        )}
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    chartDataset: state.dashboard.chartDataset,
    spin: state.dashboard.preEnrollmentStatus.spin,
    chartData: state.dashboard.preEnrollmentStatus.data,
    searchCritirea: state.dashboard.searchCritireaVo,
    searchFlag: state.dashboard.preEnrollmentStatus.searchFlag,
    checkedList: state.dashboard.checkedList,
  };
};

const mapDispatchToProps = {
  preEnrollmentStatus,
  storeChartDataset,
  setSearchCritirea,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(PreEnrollmentStatus));
