import React, { Component } from "react";
import Button from "@material-ui/core/Button";
import { CSVLink } from "react-csv";
import CaseDataPopup from "./WF_CasePopup";
import Checkbox from "@material-ui/core/Checkbox";
import ExportExcel from "../../utils/ExportExcelComponent";
import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Input from "@material-ui/core/Input";
import InputAdornment from "@material-ui/core/InputAdornment";
import Menu from "@material-ui/core/Menu";
import MenuItem from "@material-ui/core/MenuItem";
import Pagination from "../UI/Pagination";
import Popup from "reactjs-popup";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import SvgIcon from "@material-ui/core/SvgIcon";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableFooter from "@material-ui/core/TableFooter";
import TableHead from "@material-ui/core/TableHead";
import TablePagination from "@material-ui/core/TablePagination";
import TableRow from "@material-ui/core/TableRow";
import TransferPopup from "./WF_Transfer";
import classNames from "classnames";
import { connect } from "react-redux";
import orderBy from "lodash/orderBy";
import { styles } from "../../assets/styles/DataTableStyle";
import { withStyles } from "@material-ui/core/styles";


const invertDirection = {
  asc: "desc",
  desc: "asc",
};

class DataTable extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedRow: 0,
      search: "",
      colToSort: "",
      sortDir: "desc",
      page: 0,
      rowsPerPage: this.props.rowsPerPage,
      anchorEl: null,
      exportData: "",
      mobileMoreAnchorEl: null,
      radio: "current",
      index: 0,
      flag: this.props.flag,
      open: false,
      updatedIndex: 0,
      selectAll: "N",
      transferAll: false,
      transferSelected: false,
      selectedPage: 0,
      data: this.props.data,
    };
  }

  async UNSAFE_componentWillReceiveProps(nextProps, prevProps) {
    await this.setState({
      search: ""
    });
    if (this.props.flag === true || this.props.resetFlag === false) {
      await this.setState({
        page: 0,
        selectedRow: 0,
        index: 0,
        selectedPage: 0,
        rowsPerPage: nextProps.rowsPerPage,
        data: nextProps.data,
        sortDir: "desc",
        colToSort: "",
      });
      console.log(this.state.data[0]);
    } else {
      const pageNo = Math.floor(nextProps.index / this.state.rowsPerPage);
      const selectedRow = nextProps.index % this.state.rowsPerPage;

      await this.setState({
        page: pageNo,
        selectedRow: selectedRow,
        rowsPerPage: parseInt(nextProps.rowsPerPage),
        selectedPage: pageNo,
        data: nextProps.data,
      });
    }
  }

  generate = (data, header) => {
    var pdfsize = "a4";
    var jsPDF = require("jspdf");
    require("jspdf-autotable");
    var doc = new jsPDF("l", "mm", pdfsize);
    doc.autoTable(header, data, {});
    doc.save("Document.pdf");
  };
  handleTransfer = () => {
    this.setState({
      open: true,
    });
  };
  handleTransferAll = () => {
    this.setState({ open: true, transferAll: true });
  };
  handleTransferSelected = () => {
    this.setState({ open: true, transferSelected: true });
  };

  handleClose = () => {
    this.setState({
      open: false,
    });
  };
  handleClear = () => {
    this.setState({
      transferAll: false,
      transferSelected: false,
    });
  };

  exportDataFunc = (data, all) => {
    const exportdata = this.props.data.slice();
    const searchdata = data.slice();

    if (all) {
      this.setState({
        exportData: exportdata,
        radio: "all",
      });
    } else {
      if (data.length <= this.state.rowsPerPage) {
        this.setState({
          exportData: searchdata,
          radio: "current",
        });
      } else {
        this.setState({
          exportData: searchdata.slice(
            this.state.page * this.state.rowsPerPage,
            this.state.page * this.state.rowsPerPage + this.state.rowsPerPage
          ),
          radio: "current",
        });
      }
    }
  };

  handleSort = (colName) => {
    this.setState((prevState) => ({
      colToSort: colName,
      sortDir:
        this.state.colToSort === colName
          ? invertDirection[this.state.sortDir]
          : "asc",
    }));
  };

  rowSelect = async (rowIndex, data) => {
    const { page, rowsPerPage } = this.state;
    const selectedIndex = page * rowsPerPage + rowIndex;
    await this.setState({
      selectedPage: page,
    });
    await this.props.clicked(selectedIndex, data, rowsPerPage);
  };

  handleChangePage = async (page) => {
    const index = page * this.state.rowsPerPage;
    // const selectedIndex =
    //   page * this.state.rowsPerPage + this.state.selectedRow;
    this.setState({
      selectedPage: page,
      page,
    });
    this.setState({ selectAll: "N" });
    (await this.props.handleChangePage) && this.props.handleChangePage(index);
    (await this.props.clickedFooter) && this.props.clickedFooter(page);
    await this.props.clicked(
      index,
      this.props.data[index],
      this.state.rowsPerPage
    );
  };

  handleChangeRowsPerPage = async (event) => {
    let value = event.target ? event.target.value : event.value;

    await this.setState({ page: 0, rowsPerPage: value });

    await this.props.handleChangeRowsPerPage(
      this.state.rowsPerPage,
      this.state.page
    );
  };

  handleMobileMenuOpen = (event) => {
    this.setState({ mobileMoreAnchorEl: event.currentTarget });
  };
  handleMobileMenuClose = () => {
    this.setState({ mobileMoreAnchorEl: null });
  };
  handleLabelChange = (name) => (event) => {
    let value = event.label
      ? event.label.toUpperCase()
      : event.target.value.toUpperCase();
    this.setState((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };
  handleChange = (name) => (event) => {
    let value = event.value
      ? event.value.toUpperCase()
      : event.target.value.toUpperCase();
    this.setState((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };
  modalClosed = () => {
    this.setState({ showModal: false });
  };
  handleSelectChange = (event) => {
    event.persist();
    this.setState((prevState) => ({
      ...prevState,
      [event.target.name]: event.target.value,
    }));
  };
  labelDisplayedRows = (from, to, count) => {
    const rowsPerPage = this.state.rowsPerPage;

    return (
      <span>
        <span>
          Page :
          {Math.ceil(from / rowsPerPage) !== 0
            ? Math.ceil(from / rowsPerPage)
            : 1}{" "}
          - {}
          {count !== -1
            ? Math.ceil(count / rowsPerPage)
            : Math.ceil(to / rowsPerPage)}
        </span>
      </span>
    );
  };

  fetchMore = async () => {
    await this.props.fetchMore(this.state.page);
  };
  handleCheckBoxU = (event) => {
    event.preventDefault();

    let val = event.target.value === "Y" ? "N" : "Y";
    this.setState({ selectAll: val });
    this.props.SelectAllHandleCheckBox(
      this.state.rowsPerPage,
      this.state.selectAll,
      val,
      this.state.page,
      this.state.selectedRow
    );
  };

  handleCheckBox = (j) => (event) => {
    event.preventDefault();

    let val = event.target.value;
    this.setState({ selectAll: "N" });

    const index = this.state.page * this.state.rowsPerPage + j;
    this.props.handleCheckBox(index, val);
  };

  handleMenuClose = () => {
    this.setState({ anchorEl: null });
    this.handleMobileMenuClose();
  };

  render() {
    const { mobileMoreAnchorEl } = this.state;

    const {
      classes,
      searchable,
      sortable,
      exportAsExcel,
      removePagination,
      selectedRow,
      rowsPerPageOptions,
      dateColumn,
    } = this.props;
    const {
      rowsPerPage,
      page,
      exportData,
      selectedPage,
      colToSort,
      sortDir,
    } = this.state;

    const isMobileMenuOpen = Boolean(mobileMoreAnchorEl);
    let data = this.state.data;
    const noOfSelectetedCases = data.filter((x) => x.checked === "Y").length;
    let header = "";
    let pdfheader = this.props.header.filter(
      (value) =>
        value.key !== "TTWI" && value.key !== "WorkItemComment"
    );

    this.props.caseStatus !== "CLOSED" &&
      (this.props.isSupervisor === "S" ||
        this.props.isSupervisor === "A" ||
        (this.props.selectedValues &&
          this.props.selectedValues.currentUserId === this.props.userId)) &&
      (this.props.isSupervisor === "U"
        ? this.props.assignedToUser === "Select"
          ? false
          : true
        : true)
      ? (header = this.props.header)
      : (header = this.props.header.filter(
        (value) => value.key !== "TTWI"
      ));

    const search = this.state.search.toLowerCase();
    let msg = "NO DATA FOUND";

    if (this.props.msgChange) {
      msg = this.props.msgChange;
    }
    // if (data.length < rowsPerPage && data.length >= 1) {
    //   this.setState({
    //     rowsPerPage: data.length,
    //   });
    // }

    if (colToSort) {
      if (dateColumn && dateColumn.includes(colToSort)) {
        const tempData = [...this.state.data];
        const name = colToSort;
        tempData.sort(function compare(a, b) {
          let date1 =
            a[name].length === 7
              ? [a[name].slice(0, 3), "01/", a[name].slice(3)].join("")
              : a[name];
          let date2 =
            b[name].length === 7
              ? [b[name].slice(0, 3), "01/", b[name].slice(3)].join("")
              : b[name];

          const result = Date.parse(date1) - Date.parse(date2);
          return result;
        });
        data = tempData;
        if (sortDir === "desc") {
          data.reverse();
        }
      } else {
        const name = "daysRemaining";
        if (this.state.colToSort === name) {
          let tempData = [...this.state.data];
          tempData.sort(function compare(a, b) {
            let value1 = a[name];
            let value2 = b[name];
            let result = sortDir === "asc" ? value1 - value2 : value2 - value1;
            return result;
          });
          data = tempData;
        } else data = orderBy(data, this.state.colToSort, this.state.sortDir);
      }
    }

    if (this.state.search) {
      const header = this.props.header;
      data = data.filter((row) => {
        let flag = false;
        header.forEach((object) => {
          if (row[object.key]) {
            const value = row[object.key].toString().toLowerCase();
            //.slice(0, search.length);
            if (value.includes(search.toLowerCase())) {
              flag = true;
            }
          }
        });
        return flag;
      });
    }

    return (
      <div style={{ width: "100%", textAlign: "right" }}>
        {this.props.wfCacheData ? (
          <TransferPopup
            open={this.state.open}
            handleClose={this.handleClose}
            data={this.props.data}
            transferAll={this.state.transferAll}
            transferSelected={this.state.transferSelected}
            handleClear={this.handleClear}
            selectedRow={this.state.selectedRow}
          />
        ) : null}
        <div className={classes.exportDisplay}>
          {exportAsExcel && data.length > 0 ? (
            <i
              onClick={(e) => {
                this.exportDataFunc(data, false);
                this.handleMobileMenuOpen(e);
              }}
              className={classNames("fas fa-file-export", classes.exportIcon)}
            />
          ) : exportAsExcel ? (
            <i
              className={classNames("fas fa-file-export", classes.exportIcon)}
            />
          ) : null}

          <Menu
            classes={{
              paper: classes.placing,
            }}
            anchorEl={mobileMoreAnchorEl}
            anchorOrigin={{ vertical: "top", horizontal: "right" }}
            transformOrigin={{ vertical: "top", horizontal: "right" }}
            open={isMobileMenuOpen}
            onClose={this.handleMenuClose}
          >
            <MenuItem>
              <RadioGroup row value={this.state.radio}>
                <FormControlLabel
                  value="current"
                  control={<Radio />}
                  label="Current"
                  onClick={() => this.exportDataFunc(data, false)}
                />
                <FormControlLabel
                  value="all"
                  control={<Radio />}
                  label="All"
                  onClick={() => this.exportDataFunc(data, true)}
                />
              </RadioGroup>
            </MenuItem>
            <MenuItem className={classes.export}>
              <ExportExcel
                fileName="Document"
                dataSet={this.state.exportData}
                colName={pdfheader}
                classes={classes}
              />
              <CSVLink
                data={exportData}
                headers={pdfheader}
                separator={";"}
                filename={"Document.csv"}
              >
                <i
                  className={classNames("fas fa-file-csv", classes.csvIcon)}
                ></i>
              </CSVLink>

              <i
                className={classNames("fa fa-file-pdf-o", classes.pdfIcon)}
                aria-hidden="true"
                onClick={() => this.generate(exportData, pdfheader)}
              ></i>
            </MenuItem>
          </Menu>
          {(this.props.isSupervisor === "S" ||
            this.props.isSupervisor === "A") && (
              <div className={classes.floatRight}>
                <span>
                  {noOfSelectetedCases ? (
                    <Button
                      class="btn btn-secondary"
                      variant="contained"
                      color="primary"
                      name="transferSelected"
                      className={classes.button}
                      onClick={this.handleTransferSelected}
                    >
                      Transfer Selected
                    </Button>
                  ) : (
                      <Button
                        class="btn btn-secondary"
                        variant="contained"
                        color="primary"
                        name="transferAll"
                        className={classes.button}
                        onClick={this.handleTransferAll}
                      >
                        Transfer All
                      </Button>
                    )}
                </span>
              </div>
            )}
        </div>

        <div className={classes.tableWrapper}>
          {searchable ? (
            <FormControl className={classes.floatRight}>
              <Input
                id="input-with-icon-adornment"
                value={this.state.search}
                placeholder="Search..."
                className={classes.search}
                width="150px"
                onChange={(e) =>
                  this.setState({
                    search: e.target.value,
                  })
                }
                startAdornment={
                  <InputAdornment position="start">
                    <i className="material-icons">search</i>
                  </InputAdornment>
                }
              />
            </FormControl>
          ) : null}
        </div>
        <div
          className={classes.tableWrapper}
          style={{ width: this.props.width ? this.props.width : "100%" }}
        >
          <Table
            className={removePagination ? classes.tableModified : classes.table}
            id="maintable"
          >
            <TableHead className={classes.thead}>
              <TableRow className={classes.headRow}>
                <TableCell align="center" className={classes.headerCell}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        value={this.state.selectAll === "Y" ? "Y" : "N"}
                        color="primary"
                        checked={this.state.selectAll === "Y" ? true : false}
                        classes={{
                          root: classes.checkboxControl,
                        }}
                        onClick={(e) => this.handleCheckBoxU(e)}
                      />
                    }
                    classes={{
                      root: classes.checkboxLabel,
                    }}
                  />
                </TableCell>
                {header.map((mbrCol, i) => (
                  <TableCell
                    align="left"
                    className={classes.headerCell}
                    key={i}
                  >
                    {sortable && data.length > 0 ? (
                      <div onClick={() => this.handleSort(mbrCol.key)}>
                        {mbrCol.label}
                        {this.state.colToSort === mbrCol.key ? (
                          this.state.sortDir === "asc" ? (
                            <span class="sort"> &nbsp;&#8593;</span>
                          ) : (
                              <span class="sort"> &nbsp;&#8595;</span>
                            )
                        ) : (
                            <span class="sort sort-default"> &nbsp;&#8597;</span>
                          )}
                      </div>
                    ) : (
                        mbrCol.label
                      )}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>

            <TableBody className={classes.tbody}>
              {data.length < 1 && (
                <TableRow className={classes.row}>
                  <TableCell
                    colSpan={header.length + 1}
                    className={classes.tableCell}
                  >
                    {" "}
                    {msg}{" "}
                  </TableCell>
                </TableRow>
              )}
              {console.log(this.state.data[0])}
              {console.log(this.props.data[0])}
              {data
                .slice(
                  page * parseInt(rowsPerPage),
                  page * parseInt(rowsPerPage) + parseInt(rowsPerPage)
                )
                .map((genericDetail, j) => (
                  <TableRow
                    className={
                      selectedRow
                        ? classes.row
                        : this.state.selectedRow === j &&
                          page === selectedPage &&
                          !this.props.notClickable
                          ? classes.selectedrow
                          : classes.row
                    }
                    key={j}
                  >
                    <TableCell align="center" className={classes.tableCell}>
                      <FormControlLabel
                        control={
                          <Checkbox
                            value={genericDetail.checked === "Y" ? "Y" : "N"}
                            color="primary"
                            checked={
                              genericDetail.checked === "Y" ? true : false
                            }
                            classes={{
                              root: classes.checkboxControl,
                            }}
                            onClick={this.handleCheckBox(j)}
                          />
                        }
                        classes={{
                          root: classes.checkboxLabel,
                        }}
                      />
                    </TableCell>

                    {header.map((genericKey, p) => (
                      <TableCell
                        key={p}
                        style={
                          genericDetail.riskInd === "Y"
                            ? { color: "red" }
                            : null
                        }
                        align="left"
                        onClick={
                          this.props.notClickable ||
                            genericKey.key === "WorkItemComment" ||
                            genericKey.key === "TTWI"
                            ? () => { }
                            : () =>
                              this.rowSelect(j, data[page * rowsPerPage + j])
                        }
                        className={classes.tableCell}
                      >
                        {genericKey.key === "WorkItemComment" ? (
                          <Popup
                            style={{ height: "65%" }}
                            className={classes.mobileWidth}
                            modal
                            trigger={
                              <i
                                class={
                                  genericDetail.commentIndicator
                                    ? "icon-info-circled icons-custome"
                                    : "icon-info-circled icons-custome-disabled"
                                }
                                style={{ fontSize: "25px" }}
                              ></i>
                            }
                            position="right center"
                          >
                            {(close) => (
                              <div>
                                <CaseDataPopup
                                  close={close}
                                  selectedValues={genericDetail}
                                  addComments={this.props.addComments}
                                />
                              </div>
                            )}
                          </Popup>
                        ) : genericKey.key === "TTWI" &&
                          genericDetail.caseStatus !== "CLOSED" &&
                          (this.props.isSupervisor === "S" ||
                            this.props.isSupervisor === "A" ||
                            genericDetail.currentUserId ===
                            this.props.userId) ? (
                              <i
                                class={
                                  this.state.selectedRow === j
                                    ? "material-icons icons-custome"
                                    : "material-icons icons-custome-disabled"
                                }
                                onClick={
                                  this.state.selectedRow === j
                                    ? this.handleTransfer
                                    : null
                                }
                              >
                                transfer_within_a_station
                              </i>
                            ) : (
                              genericDetail[genericKey.key]
                            )}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
            </TableBody>
            {!removePagination && data && data.length > 0 ? (
              <TableFooter className={classes.footer}>
                <TableRow className={classes.footer}>
                  <TablePagination
                    className={classes.pagination}
                    rowsPerPageOptions={
                      rowsPerPageOptions ? rowsPerPageOptions : []
                    }
                    colSpan={header.length + 3}
                    count={data.length}
                    rowsPerPage={rowsPerPage}
                    page={page}
                    SelectProps={{
                      native: true,
                    }}
                    classes={{
                      toolbar: classes.footer,
                    }}
                    labelDisplayedRows={({ from, to, count }) =>
                      this.labelDisplayedRows(from, to, count)
                    }
                    onChangePage={this.handleChangePage}
                    onChangeRowsPerPage={this.handleChangeRowsPerPage}
                    ActionsComponent={Pagination}
                    backIconButtonProps={this.props.nextPage}
                    nextIconButtonProps={this.fetchMore}
                  />
                </TableRow>
              </TableFooter>
            ) : null}
          </Table>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    searchResultsVo: state.workflow.searchResultsVo,
    customerId: state.loginData.loginVo.customerId,
    userId: state.loginData.loginVo.userId,
    wfCacheData: state.workflow.wfCacheData,
  };
};

const mapDispatchToProps = {};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(DataTable));
