import { SUPERVISOR_HEADER } from "../../constants/Headers/WorkFlowHeaders";

import React, { Component } from "react";
import {
  assignWork,
  getActivities,
  refreshDashlets,
  searchWorkFlow,
  updateCase,
  getSupervisorDetails,
  getSupervisorTabDetails,
  getSupervisorDashlet,
  supervisorUpdateStatus,
  priorityUpdateStatus,
  getUserDetails,
  manualPopupDelete,
} from "../../redux/actions/WorkflowActions";
import {
  REASSIGNMENT_TYPE,
  QUEUES_LIST,
  NEW_USER,
} from "../../constants/SelectStaticData";

import {
  fetchCacheData,
  applSearch as searchApplication,
} from "../../redux/actions/ApplActions";

import Button from "@material-ui/core/Button";

import DataTable from "../Home/DataTable";
import ExpansionPanel from "../UI/ExpansionPanel";

import Paper from "@material-ui/core/Paper";
import AutoComplete1 from "../UI/Select";
import { Styles } from "../../assets/styles/Theme";

import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";
import Dashlet from "./WF_Dashlet";
import SupervisorPopup from "./WF_Supervisor_Popup";
import Popup from "reactjs-popup";
import PriorityPopup from "./WF_Supervisor_Priority";
import Modal from "../../components/UI/Modal/Modal";
import * as ActionTypes from "../../redux/types/ActionType";
import ConfirmBox from "../../utils/PopUp";
import * as Type from "../../constants/ConfirmType";
import isEmpty from "lodash/isEmpty";
import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormLabel from "@material-ui/core/FormLabel";

import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import RadioButtonCheckedIcon from "@material-ui/icons/RadioButtonChecked";
import RadioButtonUncheckedIcon from "@material-ui/icons/RadioButtonUnchecked";

const INITIAL_STATE = {
  userId: "",
  supervisorId: "",
};

class supervisor extends Component {
  constructor(props) {
    super(props);
    this.state = {
      searchVo: {
        ...INITIAL_STATE,
        supervisorId: this.props.loginData.loginVo.userId,
      },
      data: [],
      addDelete: "",
      priority: "",
      queue: "",
      selectedIndex: 0,
      reAssignmentType: "",
      queueList: "",
      newUser: "",
      closePopup: "",
      supervisorTab: true,
      payloadReq: "",
      manualCollapse: true,
      manualpopupItems: [],
      closeFlag: false,
      prtyFlag: "N",
      prty: [
        {
          label: "",
          value: "",
          checked: "",
        },
        {
          label: "",
          value: "",
          checked: "",
        },
        {
          label: "",
          value: "",
          checked: "",
        },
        {
          label: "",
          value: "",
          checked: "",
        },
        {
          label: "",
          value: "",
          checked: "",
        },
        {
          label: "",
          value: "",
          checked: "",
        },
      ],
    };
  }

  handlechange = async (data, name) => {
    let value = data.value;

    if (
      name === "supervisorId" &&
      this.state.searchVo.supervisorId !== value &&
      value !== ""
    ) {
      await this.props.getUserDetails(value);
      await this.setState({
        searchVo: {
          ...this.state.searchVo,
          userId: "",
        },
      });
    }

    await this.setState({
      searchVo: {
        ...this.state.searchVo,
        [name]: value,
      },
      modified: true,
    });
    await this.setState({ manualCollapse: true });
  };

  handleChangeSelect = async (e) => {
    const { id } = e.target;
    let name = e.target.name;

    const { prty } = this.state;
    prty[id].value = e.target.value;
    prty[id].label = e.target.name;
    await this.setState({ prty });
    console.log(this.state.prty);
  };

  handlechangePrty = (name) => (event) => {
    let value = event.target
      ? event.target.value.toUpperCase()
      : event.value.toUpperCase();
    this.setState((prevState) => ({
      ...prevState,

      [name]: value,
    }));
  };

  handleCheckbox = async (e) => {
    const { id } = e.target;

    const { prty } = this.state;
    prty[id].checked = e.target.checked ? true : false;
    prty[id].label = e.target.name;
    await this.setState({ prty });
    console.log(this.state.prty);
  };

  DeleteAllItems = async () => {
    ConfirmBox(this.DeleteManualpopup, Type.CLOSE, this.props);
  };

  DeleteManualpopup = async () => {
    if (!isEmpty(this.state.manualpopupItems)) {
      let payload = {
        userId: "",
        queueName: "",
        deleteAll: "Y",
        dashletUserId:
          this.props.supervisorData &&
          this.props.supervisorData[this.state.selectedIndex].userId,
      };
      const status = await this.props.manualPopupDelete(payload);
      if (status === "SUCCESS") {
        this.setState({ closePopup: true, message: ActionTypes.CLOSE });
      } else {
        this.setState({
          closePopup: true,
          message: status,
        });
      }
    } else {
      this.setState({
        closePopup: true,
        message: "No Queues are available to Delete",
      });
    }
  };
  supervisorOpenitems = async (itemType, isSubItem, queueName) => {
    let payload = {};

    if (
      itemType !== "MANUAL POPUP" &&
      !isEmpty(this.state.manualpopupItems) &&
      !isEmpty(
        this.state.manualpopupItems.filter((item) => item.status === isSubItem)
      )
    ) {
      payload = {
        userId: this.props.supervisorData[this.state.selectedIndex].userId,
        queueName: queueName,
        deleteAll: "N",
        dashletUserId:
          this.props.supervisorData &&
          this.props.supervisorData[this.state.selectedIndex].userId,
      };
      console.log(payload);
      await this.setState({ payloadReq: payload });
      ConfirmBox(this.confirmQueue, Type.CLOSE, this.props);
    }

    if (itemType === "MANUAL POPUP") {
      payload = {
        userId: "",
        queueName: queueName,
        deleteAll: "N",
        dashletUserId:
          this.props.supervisorData &&
          this.props.supervisorData[this.state.selectedIndex].userId,
      };
      console.log(payload);
      await this.setState({ payloadReq: payload });
      ConfirmBox(this.confirmQueue, Type.CLOSE, this.props);
    }
  };

  confirmQueue = async () => {
    const status = await this.props.manualPopupDelete(this.state.payloadReq);
    if (status === "SUCCESS") {
      this.setState({ closePopup: true, message: ActionTypes.CLOSE });
    } else {
      this.setState({
        closePopup: true,
        message: status,
      });
    }
  };

  modalClosed = () => {
    this.setState({ closePopup: false });
  };
  handleChangeSearchSelectAuto = async (data, name) => {
    let value = data.value;
    await this.setState((prevState) => ({
      ...prevState,

      [name]: value,
    }));
    this.setState({ manualCollapse: true });
  };

  handleChangeSearchSelectAutoUser = async (data, name) => {
    let value = data.value;
    await this.setState({
      searchVo: {
        ...this.state.searchVo,
        [name]: value,
      },
    });
    await this.setState({ manualCollapse: true });
  };

  updatePriority = (payload) => {
    this.setState({ closeFlag: true });
    console.log(this.state.prty);
    let prt1selected = this.state.prty.filter(
      (data) => data.value === "1" && data.checked === true
    );
    let prt2selected = this.state.prty.filter(
      (data) => data.value === "2" && data.checked === true
    );
    let prt3selected = this.state.prty.filter(
      (data) => data.value === "3" && data.checked === true
    );
    let prt4selected = this.state.prty.filter(
      (data) => data.value === "4" && data.checked === true
    );
    console.log(prt1selected);
    console.log(prt2selected);
    console.log(prt3selected);
    console.log(prt4selected);
    let prt1val = [];
    let prt2val = [];
    let prt3val = [];
    let prt4val = [];
    if (this.props.wfCacheData.queueList.length > 0) {
      for (let j = 0; j < this.props.wfCacheData.queueList.length; j++) {
        if (prt1selected && prt1selected.length > 0) {
          for (let i = 0; i < prt1selected.length; i++) {
            if (
              prt1selected[i].label == this.props.wfCacheData.queueList[j].label
            ) {
              prt1val.push(this.props.wfCacheData.queueList[j].value);
            }
          }
        }
        if (prt2selected && prt2selected.length > 0) {
          for (let i = 0; i < prt2selected.length; i++) {
            if (
              prt2selected[i].label == this.props.wfCacheData.queueList[j].label
            ) {
              prt2val.push(this.props.wfCacheData.queueList[j].value);
            }
          }
        }

        if (prt3selected && prt3selected.length > 0) {
          for (let i = 0; i < prt3selected.length; i++) {
            if (
              prt3selected[i].label == this.props.wfCacheData.queueList[j].label
            ) {
              prt3val.push(this.props.wfCacheData.queueList[j].value);
            }
          }
        }

        if (prt4selected && prt4selected.length > 0) {
          for (let i = 0; i < prt4selected.length; i++) {
            if (
              prt4selected[i].label == this.props.wfCacheData.queueList[j].label
            ) {
              prt4val.push(this.props.wfCacheData.queueList[j].value);
            }
          }
        }
      }
    }

    let payloadreq = {
      userId: this.props.supervisorData[this.state.selectedIndex].userId,
      searchUserId: this.state.searchVo.userId,
      searchSupAdminId: this.state.searchVo.supervisorId,
      queAsgnNew: {
        1: prt1val,
        2: prt2val,
        3: prt3val,
        4: prt4val,
      },
      userConfFlag: this.state.prtyFlag,
    };

    console.log(payloadreq);
    this.setState({ payloadReq: payloadreq });
    ConfirmBox(this.confirmUpdatePriority, Type.UPDATE, this.props);
  };

  confirmUpdatePriority = async () => {
    const status = await this.props.priorityUpdateStatus(this.state.payloadReq);

    if (status === "SUCCESS") {
      this.refreshDashlets();
      this.setState({
        closePopup: true,
        message: ActionTypes.UPDATE,
        prtyFlag: "N",
      });
    } else {
      this.setState({
        closePopup: true,
        message: status,
      });
    }
  };

  updateUserStatus = (payload) => {
    let payloadRequest = {
      ...payload,
      searchUserId: this.state.searchVo.userId,
      searchSupAdminId: this.state.searchVo.supervisorId,
    };
    this.setState({ payloadReq: payloadRequest });
    ConfirmBox(this.confirmUserStatus, Type.UPDATE, this.props);
  };

  confirmUserStatus = async (payload) => {
    const status = await this.props.supervisorUpdateStatus(
      this.state.payloadReq
    );

    if (status === "SUCCESS") {
      let userStatus = "";
      if (this.state.payloadReq.userStatus === "A") {
        userStatus = "Active";
      } else {
        userStatus = "Inactive";
      }

      this.setState({
        closePopup: true,
        message: "User Status has been changed " + userStatus,
      });
    } else {
      this.setState({
        closePopup: true,
        message: status,
      });
    }
  };

  reset = async (e) => {
    e.preventDefault();
    await this.setState(
      {
        searchVo: {
          userId: "",
          supervisorId: "",
        },
      },
      () => {}
    );
  };

  refreshDashlets = async () => {
    await this.props.refreshDashlets(
      this.state.data[this.state.selectedIndex].userId,
      this.state.supervisorTab
    );
    this.setState({
      searchResultsVo: {
        ...this.props.searchResultsVo,
        dashletData: this.props.searchResultsVo.dashletData,
      },
    });
  };

  componentDidMount = async () => {
    let searchResultsVo = this.props.searchResultsVo;

    await this.props.getSupervisorTabDetails();
    if (this.props.supervisorData && this.props.supervisorData.length > 0) {
      await this.props.getSupervisorDashlet(
        this.props.supervisorData[0].userId
      );
      this.setState({
        searchResultsVo: {
          ...searchResultsVo,
          dashletData: searchResultsVo.dashletData,
        },
      });

      if (!isEmpty(this.props.searchResultsVo.dashletData)) {
        let manualData = this.props.searchResultsVo.dashletData.filter(
          (item) => item.status === "MANUAL POPUP"
        );
        if (!isEmpty(manualData[0].subItems)) {
          let manualpopupItems = manualData[0].subItems;
          await this.setState({ manualpopupItems });
          console.log(this.state.manualpopupItems);
        }
      }
      if (!isEmpty(this.props.wfCacheData.queueList)) {
        let prty = [
          {
            label: "",
            value: "",
            checked: "",
          },
          {
            label: "",
            value: "",
            checked: "",
          },
          {
            label: "",
            value: "",
            checked: "",
          },
          {
            label: "",
            value: "",
            checked: "",
          },
          {
            label: "",
            value: "",
            checked: "",
          },
          {
            label: "",
            value: "",
            checked: "",
          },
        ];
        for (let i = 0; i < this.props.wfCacheData.queueList.length; i++) {
          if (!isEmpty(this.props.supervisorData)) {
            prty[i].value = this.props.supervisorData[
              this.state.selectedIndex
            ].prtyOneList.includes(
              this.props.wfCacheData.queueList[i].label.toUpperCase()
            )
              ? "1"
              : this.props.supervisorData[
                  this.state.selectedIndex
                ].prtyTwoList.includes(
                  this.props.wfCacheData.queueList[i].label.toUpperCase()
                )
              ? "2"
              : this.props.supervisorData[
                  this.state.selectedIndex
                ].prtyThreeList.includes(
                  this.props.wfCacheData.queueList[i].label.toUpperCase()
                )
              ? "3"
              : this.props.supervisorData[
                  this.state.selectedIndex
                ].prtyFourList.includes(
                  this.props.wfCacheData.queueList[i].label.toUpperCase()
                )
              ? "4"
              : "";
            prty[i].label = this.props.supervisorData[
              this.state.selectedIndex
            ].prtyOneList.includes(
              this.props.wfCacheData.queueList[i].label.toUpperCase()
            )
              ? this.props.wfCacheData.queueList[i].label.toUpperCase()
              : this.props.supervisorData[
                  this.state.selectedIndex
                ].prtyTwoList.includes(
                  this.props.wfCacheData.queueList[i].label.toUpperCase()
                )
              ? this.props.wfCacheData.queueList[i].label.toUpperCase()
              : this.props.supervisorData[
                  this.state.selectedIndex
                ].prtyThreeList.includes(
                  this.props.wfCacheData.queueList[i].label.toUpperCase()
                )
              ? this.props.wfCacheData.queueList[i].label.toUpperCase()
              : this.props.supervisorData[
                  this.state.selectedIndex
                ].prtyFourList.includes(
                  this.props.wfCacheData.queueList[i].label.toUpperCase()
                )
              ? this.props.wfCacheData.queueList[i].label.toUpperCase()
              : "";
            prty[i].checked =
              this.props.supervisorData[
                this.state.selectedIndex
              ].prtyOneList.includes(
                this.props.wfCacheData.queueList[i].label.toUpperCase()
              ) ||
              this.props.supervisorData[
                this.state.selectedIndex
              ].prtyTwoList.includes(
                this.props.wfCacheData.queueList[i].label.toUpperCase()
              ) ||
              this.props.supervisorData[
                this.state.selectedIndex
              ].prtyThreeList.includes(
                this.props.wfCacheData.queueList[i].label.toUpperCase()
              ) ||
              this.props.supervisorData[
                this.state.selectedIndex
              ].prtyFourList.includes(
                this.props.wfCacheData.queueList[i].label.toUpperCase()
              )
                ? true
                : false;
          }
        }
        await this.setState({ prty: prty });
      }
    }
  };

  fetchSupervisorDetails = async (e) => {
    e.preventDefault();

    if (
      this.state.searchVo.userId === "" &&
      this.state.searchVo.supervisorId === ""
    ) {
      alert("Please Select at least Supervisor Name or User Name");
    } else {
      await this.props.getSupervisorDetails(
        this.state.searchVo.userId,
        this.state.searchVo.supervisorId
      );
      if (this.state.data && this.state.data.length > 0) {
        await this.props.getSupervisorDashlet(this.state.data[0].userId);
        await this.setState({
          searchResultsVo: {
            ...this.props.searchResultsVo,
            dashletData: this.props.searchResultsVo.dashletData,
          },
          selectedIndex: 0,
          manualCollapse: true,
        });
      }

      let prty = [
        {
          label: "",
          value: "",
          checked: "",
        },
        {
          label: "",
          value: "",
          checked: "",
        },
        {
          label: "",
          value: "",
          checked: "",
        },
        {
          label: "",
          value: "",
          checked: "",
        },
        {
          label: "",
          value: "",
          checked: "",
        },
        {
          label: "",
          value: "",
          checked: "",
        },
      ];

      for (let i = 0; i < this.props.wfCacheData.queueList.length; i++) {
        prty[i].value = this.props.supervisorData[
          this.state.selectedIndex
        ].prtyOneList.includes(
          this.props.wfCacheData.queueList[i].label.toUpperCase()
        )
          ? "1"
          : this.props.supervisorData[
              this.state.selectedIndex
            ].prtyTwoList.includes(
              this.props.wfCacheData.queueList[i].label.toUpperCase()
            )
          ? "2"
          : this.props.supervisorData[
              this.state.selectedIndex
            ].prtyThreeList.includes(
              this.props.wfCacheData.queueList[i].label.toUpperCase()
            )
          ? "3"
          : this.props.supervisorData[
              this.state.selectedIndex
            ].prtyFourList.includes(
              this.props.wfCacheData.queueList[i].label.toUpperCase()
            )
          ? "4"
          : "";
        prty[i].label = this.props.supervisorData[
          this.state.selectedIndex
        ].prtyOneList.includes(
          this.props.wfCacheData.queueList[i].label.toUpperCase()
        )
          ? this.props.wfCacheData.queueList[i].label.toUpperCase()
          : this.props.supervisorData[
              this.state.selectedIndex
            ].prtyTwoList.includes(
              this.props.wfCacheData.queueList[i].label.toUpperCase()
            )
          ? this.props.wfCacheData.queueList[i].label.toUpperCase()
          : this.props.supervisorData[
              this.state.selectedIndex
            ].prtyThreeList.includes(
              this.props.wfCacheData.queueList[i].label.toUpperCase()
            )
          ? this.props.wfCacheData.queueList[i].label.toUpperCase()
          : this.props.supervisorData[
              this.state.selectedIndex
            ].prtyFourList.includes(
              this.props.wfCacheData.queueList[i].label.toUpperCase()
            )
          ? this.props.wfCacheData.queueList[i].label.toUpperCase()
          : "";
        prty[i].checked =
          this.props.supervisorData[
            this.state.selectedIndex
          ].prtyOneList.includes(
            this.props.wfCacheData.queueList[i].label.toUpperCase()
          ) ||
          this.props.supervisorData[
            this.state.selectedIndex
          ].prtyTwoList.includes(
            this.props.wfCacheData.queueList[i].label.toUpperCase()
          ) ||
          this.props.supervisorData[
            this.state.selectedIndex
          ].prtyThreeList.includes(
            this.props.wfCacheData.queueList[i].label.toUpperCase()
          ) ||
          this.props.supervisorData[
            this.state.selectedIndex
          ].prtyFourList.includes(
            this.props.wfCacheData.queueList[i].label.toUpperCase()
          )
            ? true
            : false;
      }
      await this.setState({ prty: prty });
    }
  };

  static getDerivedStateFromProps(nextProps) {
    return {
      data: nextProps.supervisorData,
    };
  }

  selectRow = async (index) => {
    this.setState({ selectedIndex: index });
    await this.props.getSupervisorDashlet(this.state.data[index].userId);
    await this.setState({
      searchResultsVo: {
        ...this.props.searchResultsVo,
        dashletData: this.props.searchResultsVo.dashletData,
      },
    });
    if (!isEmpty(this.props.searchResultsVo.dashletData)) {
      let manualData = this.props.searchResultsVo.dashletData.filter(
        (item) => item.status === "MANUAL POPUP"
      );
      if (!isEmpty(manualData[0].subItems)) {
        let manualpopupItems = manualData[0].subItems;
        await this.setState({ manualpopupItems });
        console.log(this.state.manualpopupItems);
      }
    }

    let prty = [
      {
        label: "",
        value: "",
        checked: "",
      },
      {
        label: "",
        value: "",
        checked: "",
      },
      {
        label: "",
        value: "",
        checked: "",
      },
      {
        label: "",
        value: "",
        checked: "",
      },
      {
        label: "",
        value: "",
        checked: "",
      },
      {
        label: "",
        value: "",
        checked: "",
      },
    ];

    for (let i = 0; i < this.props.wfCacheData.queueList.length; i++) {
      if (!isEmpty(this.props.supervisorData)) {
        prty[i].value = this.props.supervisorData[index].prtyOneList.includes(
          this.props.wfCacheData.queueList[i].label.toUpperCase()
        )
          ? "1"
          : this.props.supervisorData[index].prtyTwoList.includes(
              this.props.wfCacheData.queueList[i].label.toUpperCase()
            )
          ? "2"
          : this.props.supervisorData[index].prtyThreeList.includes(
              this.props.wfCacheData.queueList[i].label.toUpperCase()
            )
          ? "3"
          : this.props.supervisorData[index].prtyFourList.includes(
              this.props.wfCacheData.queueList[i].label.toUpperCase()
            )
          ? "4"
          : "";
        prty[i].label = this.props.supervisorData[index].prtyOneList.includes(
          this.props.wfCacheData.queueList[i].label.toUpperCase()
        )
          ? this.props.wfCacheData.queueList[i].label.toUpperCase()
          : this.props.supervisorData[index].prtyTwoList.includes(
              this.props.wfCacheData.queueList[i].label.toUpperCase()
            )
          ? this.props.wfCacheData.queueList[i].label.toUpperCase()
          : this.props.supervisorData[index].prtyThreeList.includes(
              this.props.wfCacheData.queueList[i].label.toUpperCase()
            )
          ? this.props.wfCacheData.queueList[i].label.toUpperCase()
          : this.props.supervisorData[index].prtyFourList.includes(
              this.props.wfCacheData.queueList[i].label.toUpperCase()
            )
          ? this.props.wfCacheData.queueList[i].label.toUpperCase()
          : "";
        prty[i].checked =
          this.props.supervisorData[index].prtyOneList.includes(
            this.props.wfCacheData.queueList[i].label.toUpperCase()
          ) ||
          this.props.supervisorData[index].prtyTwoList.includes(
            this.props.wfCacheData.queueList[i].label.toUpperCase()
          ) ||
          this.props.supervisorData[index].prtyThreeList.includes(
            this.props.wfCacheData.queueList[i].label.toUpperCase()
          ) ||
          this.props.supervisorData[index].prtyFourList.includes(
            this.props.wfCacheData.queueList[i].label.toUpperCase()
          )
            ? true
            : false;
      }
    }
    await this.setState({ prty: prty });
  };

  render() {
    const { classes, searchResultsVo, userList, supervisorList } = this.props;
    const { searchVo, data } = this.state;

    return (
      <React.Fragment>
        <Modal
          dialogTitle="Supervisor"
          message={this.state.message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Paper
          elevation={0}
          className={classes.card}
          style={{ minHeight: "400px" }}
        >
          <div class="search-panel">
            <ExpansionPanel
              summary="Search"
              defaultCollapsed={this.state.collapseSearch}
            >
              <form>
                <div className={classes.container}>
                  {!isEmpty(supervisorList) &&
                  this.props.wfCacheData &&
                  (this.props.wfCacheData.supervisor === "A" ||
                    this.props.wfCacheData.supervisor === "S") ? (
                    <div>
                      {/* <Select
                            components={components}
                            propertyName={supervisorList.filter(
                              (option) => option.value === searchVo.supervisorId
                            )}
                            id="userName"
                            options={supervisorList}
                            textFieldProps={{
                              label: "Supervisor Name",
                              required: true,
                              InputLabelProps: {
                                className: classes.label,
                                shrink: true,
                              },
                            }}
                            className={classes.textFieldSelect}
                            width="180px"
                            handleChange={this.handlechange("supervisorId")}
                            classes={classes}
                          /> */}
                      <AutoComplete1
                        options={supervisorList}
                        handleChange={this.handlechange}
                        defaultValue={supervisorList[0]}
                        value={
                          supervisorList.filter(
                            (data) => data.value === searchVo.supervisorId
                          )[0]
                        }
                        label="Supervisor Name"
                        //margin='0px'
                        name="supervisorId"
                      />
                      <div className={classes.validationMessage}></div>
                    </div>
                  ) : null}

                  {!isEmpty(userList) ? (
                    <div>
                      {/* <Select
                            components={components}
                            propertyName={userList.filter(
                              (option) => option.value === searchVo.userId
                            )}
                            id="userName"
                            options={userList}
                            textFieldProps={{
                              label: "User Name",
                              required: true,
                              InputLabelProps: {
                                className: classes.label,
                                shrink: true,
                              },
                            }}
                            className={classes.textFieldSelect}
                            width="180px"
                            handleChange={this.handlechange("userId")}
                            classes={classes}
                          /> */}
                      <AutoComplete1
                        options={userList}
                        handleChange={this.handleChangeSearchSelectAutoUser}
                        defaultValue={userList[0]}
                        value={
                          userList.filter(
                            (data) => data.value === searchVo.userId
                          )[0]
                        }
                        label="User Name"
                        //margin='0px'
                        name="userId"
                      />
                      <div className={classes.validationMessage}></div>
                    </div>
                  ) : null}

                  <span
                    class="button-container-search"
                    style={{ marginTop: "20px", marginLeft: "20px" }}
                  >
                    <button
                      id="search"
                      type="submit"
                      class="btn btn-primary icon-search"
                      onClick={this.fetchSupervisorDetails}
                    >
                      Search
                    </button>
                    <button
                      id="reset"
                      class="btn btn-secondary"
                      onClick={this.reset}
                    >
                      Reset
                    </button>
                  </span>
                </div>
              </form>
              {/* </div> */}
              {/* <div>
                  {!isEmpty(data) ? (
                    <DataTable
                      data={data}
                      header={SUPERVISOR_HEADER}
                      rowsPerPage={10}
                      clicked={this.selectRow}
                      index={this.state.selectedIndex}
                      searchable={true}
                      exportAsExcel={true}
                    />
                  ) : null}

                  <React.Fragment>
                    <div style={{ float: "right" }}>
                      <Popup
                        style={{ height: "65%" }}
                        className={classes.mobileWidth}
                        modal
                        trigger={
                          <Button
                            type="submit"
                            variant="contained"
                            color="primary"
                            onClick={this.updateCaseStatus}
                            className={classes.buttonworkflow}
                          >
                            Priority Update
                          </Button>
                        }
                        position="right center"
                      >
                        {(close) => (
                          <div>
                            <PriorityPopup
                              close={close}
                              classes={classes}
                              selectedValues={data[this.state.selectedIndex]}
                              userId={searchVo.userId}
                              updatePriority={this.updatePriority}
                            />
                          </div>
                        )}
                      </Popup>
                      <Popup
                        style={{ height: "65%" }}
                        className={classes.mobileWidth}
                        modal
                        trigger={
                          <Button
                            type="submit"
                            variant="contained"
                            color="primary"
                            onClick={this.updateCaseStatus}
                            className={classes.buttonworkflow}
                          >
                            Update User Status
                          </Button>
                        }
                        position="right center"
                      >
                        {(close) => (
                          <div>
                            <SupervisorPopup
                              close={close}
                              classes={classes}
                              selectedValues={data[this.state.selectedIndex]}
                              userId={searchVo.userId}
                              updateUserStatus={this.updateUserStatus}
                            />
                          </div>
                        )}
                      </Popup>
                    </div>
                  </React.Fragment>
                </div> */}
              {/* </div> */}
            </ExpansionPanel>
          </div>
          <div class="panel">
            <ExpansionPanel
              summary="Supervisor/Admin workflow"
              defaultCollapsed={this.state.collapseSearch}
            >
              <div class="panel-body">
                <div class="row">
                  <div class="col-md-7">
                    {!isEmpty(data) ? (
                      <DataTable
                        data={data}
                        header={SUPERVISOR_HEADER}
                        rowsPerPage={10}
                        clicked={this.selectRow}
                        index={this.state.selectedIndex}
                        searchable={true}
                        exportAsExcel={true}
                      />
                    ) : null}
                    <div class="button-container">
                      <Popup
                        style={{ height: "65%" }}
                        className={classes.mobileWidth}
                        modal
                        trigger={
                          <Button
                            type="submit"
                            variant="contained"
                            color="primary"
                            onClick={this.updateCaseStatus}
                            className={classes.buttonworkflow}
                          >
                            Update User Status
                          </Button>
                        }
                        position="right center"
                      >
                        {(close) => (
                          <div>
                            <SupervisorPopup
                              close={close}
                              classes={classes}
                              selectedValues={data[this.state.selectedIndex]}
                              userId={searchVo.userId}
                              updateUserStatus={this.updateUserStatus}
                            />
                          </div>
                        )}
                      </Popup>
                    </div>
                  </div>

                  <div class="col-md-5">
                    <div class="row">
                      <div class="col-6">
                        <div class="panel-subhead5">
                          <h3>Priority</h3>
                        </div>
                      </div>
                      <div class="col-6 text-right">
                        <button
                          class="btn btn-secondary icon-edit"
                          data-target="#priority_edit_window"
                          data-toggle="modal"
                        >
                          Edit Priority
                        </button>
                      </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-12">
                        {this.props.supervisorData &&
                        this.props.supervisorData.length > 0 &&
                        this.props.supervisorData[this.state.selectedIndex] ? (
                          <div class="priority-dashlet-container">
                            <div class="priority-dashlet">
                              <h3 class="pd_head">Priority 1</h3>
                              <ul class="priority-list">
                                {!isEmpty(
                                  this.props.supervisorData[
                                    this.state.selectedIndex
                                  ].prtyOneList
                                ) &&
                                  this.props.supervisorData[
                                    this.state.selectedIndex
                                  ].prtyOneList.map((data, i) => {
                                    return (
                                      <React.Fragment>
                                        <li key={i}>{data}</li>
                                      </React.Fragment>
                                    );
                                  })}
                              </ul>
                            </div>

                            <div class="priority-dashlet">
                              <h3 class="pd_head">Priority 2</h3>
                              <ul class="priority-list">
                                {!isEmpty(
                                  this.props.supervisorData[
                                    this.state.selectedIndex
                                  ].prtyTwoList
                                ) &&
                                  this.props.supervisorData[
                                    this.state.selectedIndex
                                  ].prtyTwoList.map((data, i) => {
                                    {
                                      console.log(data);
                                    }
                                    return (
                                      <React.Fragment>
                                        <li key={i}>{data}</li>
                                      </React.Fragment>
                                    );
                                  })}
                              </ul>
                            </div>

                            <div class="priority-dashlet">
                              <h3 class="pd_head">Priority 3</h3>
                              <ul class="priority-list">
                                {!isEmpty(
                                  this.props.supervisorData[
                                    this.state.selectedIndex
                                  ].prtyThreeList
                                ) &&
                                  this.props.supervisorData[
                                    this.state.selectedIndex
                                  ].prtyThreeList.map((data, i) => {
                                    return (
                                      <React.Fragment>
                                        <li key={i}>{data}</li>
                                      </React.Fragment>
                                    );
                                  })}
                              </ul>
                            </div>

                            <div class="priority-dashlet">
                              <h3 class="pd_head">Priority 4</h3>
                              <ul class="priority-list">
                                {!isEmpty(
                                  this.props.supervisorData[
                                    this.state.selectedIndex
                                  ].prtyFourList
                                ) &&
                                  this.props.supervisorData[
                                    this.state.selectedIndex
                                  ].prtyFourList.map((data, i) => {
                                    {
                                      console.log(data);
                                    }
                                    return (
                                      <React.Fragment>
                                        <li key={i}>{data}</li>
                                      </React.Fragment>
                                    );
                                  })}
                              </ul>
                            </div>
                          </div>
                        ) : null}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </ExpansionPanel>
          </div>
          <React.Fragment>
            <div class="modal fade" id="priority_edit_window">
              <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable ">
                <div class="modal-content">
                  <div class="modal-header">
                    <h4 class="modal-title">Priority Edit</h4>
                    <button type="button" class="close" data-dismiss="modal">
                      &times;
                    </button>
                  </div>

                  <div class="modal-body panel-body">
                    <h3 class="pd_head">
                      Queue Name:
                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Priority:
                    </h3>

                    {this.props.wfCacheData.queueList &&
                    this.props.wfCacheData.queueList.length > 0 &&
                    !isEmpty(this.props.supervisorData) ? (
                      <React.Fragment>
                        <table class="table-list width100per">
                          {this.props.wfCacheData.queueList.map((data, i) => {
                            return (
                              <tr>
                                <td>
                                  <label>
                                    <input
                                      type="checkbox"
                                      class="form-checkbox2"
                                      id={i}
                                      name={data.label}
                                      onChange={this.handleCheckbox}
                                      checked={
                                        this.state.prty[i].checked === true
                                          ? true
                                          : false
                                      }
                                    />
                                    {data.label}
                                  </label>
                                </td>

                                <td>
                                  <select
                                    class="select-auto-width width4"
                                    onChange={this.handleChangeSelect}
                                    id={i}
                                    name={data.label}
                                    disabled={
                                      this.state.prty[i].checked === false
                                    }
                                    value={
                                      this.state.prty[i].value
                                        ? this.state.prty[i].value
                                        : ""
                                    }
                                  >
                                    <option></option>
                                    <option>1</option>
                                    <option>2</option>
                                    <option>3</option>
                                    <option>4</option>
                                  </select>
                                </td>
                              </tr>
                            );
                          })}
                        </table>
                      </React.Fragment>
                    ) : null}
                    <FormControl
                      component="fieldset"
                      className={classes.formControl}
                    >
                      <FormLabel component="legend" className={classes.legend}>
                        Do you want to unassign/Transfer the cases? &nbsp;
                        <RadioGroup
                          aria-label="Dialysis"
                          name="prtyFlag"
                          className={classes.group}
                          value={this.state.prtyFlag}
                          onChange={this.handlechangePrty("prtyFlag")}
                        >
                          <FormControlLabel
                            value="Y"
                            control={
                              <Radio
                                color="primary"
                                // disabled={originalApplication}
                                icon={
                                  <RadioButtonUncheckedIcon fontSize="small" />
                                }
                                checkedIcon={
                                  <RadioButtonCheckedIcon fontSize="small" />
                                }
                              />
                            }
                            label="Yes"
                          />
                          <FormControlLabel
                            value="N"
                            control={
                              <Radio
                                color="primary"
                                // disabled={originalApplication}
                                icon={
                                  <RadioButtonUncheckedIcon fontSize="small" />
                                }
                                checkedIcon={
                                  <RadioButtonCheckedIcon fontSize="small" />
                                }
                              />
                            }
                            label="No"
                          />
                        </RadioGroup>
                      </FormLabel>
                    </FormControl>
                  </div>

                  <div class="modal-footer">
                    <button
                      type="button"
                      class="btn btn-primary"
                      onClick={this.updatePriority}
                      data-dismiss="modal"
                    >
                      Update
                    </button>
                    <button
                      type="button"
                      class="btn btn-secondary"
                      data-dismiss="modal"
                    >
                      Close
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </React.Fragment>

          <React.Fragment>
            {searchResultsVo.dashletData ? (
              <React.Fragment>
                <Dashlet
                  data={searchResultsVo.dashletData}
                  supervisorTab={this.state.supervisorTab}
                  supervisorOpenitems={this.supervisorOpenitems}
                  DeleteAllItems={this.DeleteAllItems}
                />

                <div class="dashlet-refresh" onClick={this.refreshDashlets}>
                  <i
                    class="fa fa-refresh"
                    style={{ fontSize: 25, color: "#389bb5" }}
                  ></i>
                  <div>Refresh Dashlets</div>
                </div>
              </React.Fragment>
            ) : null}
          </React.Fragment>
        </Paper>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    searchResultsVo: state.workflow.searchResultsVo,
    isLoading: state.spinner.isLoading,
    wfCacheData: state.workflow.wfCacheData,
    loginData: state.loginData,
    supervisorData: state.workflow.supervisorData,
    userList: state.workflow.userList,
    supervisorList: state.workflow.supervisorList,
  };
};

const mapDispatchToProps = {
  searchWorkFlow,
  getActivities,
  assignWork,
  updateCase,
  searchApplication,
  fetchCacheData,
  refreshDashlets,
  getSupervisorDetails,
  getSupervisorTabDetails,
  getSupervisorDashlet,
  supervisorUpdateStatus,
  priorityUpdateStatus,
  getUserDetails,
  manualPopupDelete,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(supervisor));
