import * as Type from "../../constants/ConfirmType";
import { SHOW_USERS_HEADER } from "../../constants/Headers/WorkFlowHeaders";
import { AccessLevels } from "../../constants/staticData/supervisorData";
import React, { Component } from "react";
import {
  addWFuser,
  showUserDropdowns,
  getWFuserDetails,
  updatWFuserDetails,
} from "../../redux/actions/WorkflowActions";

import ConfirmBox from "../../utils/PopUp";
import DataTable from "../Home/DataTable";
import ExpansionPanel from "../UI/ExpansionPanel";
import InputField from "../UI/InputField";
import Modal from "../../components/UI/Modal/Modal";
import Paper from "@material-ui/core/Paper";
import AutoComplete1 from "../UI/Select";
import { Styles } from "../../assets/styles/Theme";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";
import { validationRules } from "../../utils/ValidationRules";
import SimpleReactValidator from "simple-react-validator";

class WF_ShowUsers extends Component {
  constructor(props) {
    super(props);
    this.state = {
      searchVo: {
        userName: "",
        supervisorName: "",
      },
      showUsersVo: {
        supervisorName: "",
        userId: "",
        supervisorId: "",
        userLevel: "",
        userName: "",
      },
      selectedIndex: 0,
      showModal: "",
      message: "",
      searched: false,
    };
    this.validator = new SimpleReactValidator(validationRules);
  }
  handleChangeSearchSelectAuto = async (data, name, targetVo) => {
    let value = data.value ? data.value.toUpperCase() : data.value;
    await this.setState({
      searchVo: {
        ...this.state.searchVo,
        supervisorName: value,
      },
    });
  };

  handleOnBlur = (name, targetVo) => (event) => {
    let value = event.target.value.trim();
    this.setState((prevState) => ({
      ...prevState,
      [targetVo]: { ...prevState[targetVo], [name]: value },
    }));
  };

  handlechange = (name, targetVo) => (event) => {
    let value = event.target.value;
    this.setState((prevState) => ({
      ...prevState,
      [targetVo]: { ...prevState[targetVo], [name]: value },
    }));
  };

  // handleLabelChange = (name, targetVo) => (event) => {
  //   let value = event.target ? event.target.value.toUpperCase() : event.label;

  //   this.setState((prevState) => ({
  //     ...prevState,
  //     [targetVo]: { ...prevState[targetVo], [name]: value },
  //   }));
  // };

  handleLabelChange = async (data, name, targetVo) => {
    let value = data.label ? data.label.toUpperCase() : data.label;
    await this.setState((prevState) => ({
      ...prevState,
      [targetVo]: { ...prevState[targetVo], [name]: value },
    }));
  };

  handleSearchReset = async (e) => {
    e.preventDefault();
    await this.setState({
      searchVo: {
        userName: "",
        supervisorName: "",
      },

      searched: false,
    });
  };

  handleUpdateReset = () => {
    this.setState({
      showUsersVo: this.props.workflowUserDetails[this.state.selectedIndex],
    });
    this.validator.hideMessages();
  };

  selectRow = async (index) => {
    const data = this.props.workflowUserDetails;
    const selectedVo = data[index];
    this.setState({
      selectedIndex: index,
      showUsersVo: selectedVo,
    });
    this.validator.hideMessages();
  };

  handleRadiochange = (event) => {
    this.setState({ radio: event.target.value });
  };

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.workflowUserDetails.length > 0) {
      const showUsersVo = nextProps.workflowUserDetails[0];
      this.setState({
        showUsersVo: showUsersVo,
        selectedIndex: this.state.selectedIndex,
      });
    }
  }
  componentDidMount() {
    if (this.props.workflowUserDetails.length > 0) {
      const showUsersVo = this.props.workflowUserDetails[0];
      this.setState({
        showUsersVo: showUsersVo,
      });
    }
  }
  fetchWFuserDetails = async (event) => {
    event.preventDefault();
    const { userName, supervisorName } = this.state.searchVo;
    await this.props.getWFuserDetails(userName, supervisorName);

    await this.setState({
      searched: true,
    });
  };

  updatWFuser = () => {
    if (this.validator.allValid()) {
      ConfirmBox(this.confirmUpdate, Type.UPDATE, this.props);
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  confirmUpdate = async () => {
    const { userName, supervisorName } = this.state.searchVo;
    const {
      userLevel,
      userId,
      supervisorName: supervisor,
    } = this.state.showUsersVo;

    const supervisiorId = this.props.supervisorList.filter(
      (option) => option.label === supervisor
    )[0].value;
    const role = AccessLevels.filter((option) => option.label === userLevel)[0]
      .value;

    const body = {
      role: role,
      userId: userId,
      supervisorId: supervisiorId,
      name: userName,
      searchSupervisorId: supervisorName,
    };
    let status = await this.props.updatWFuserDetails(body);
    status = status === "SUCCESS" ? "Updated successfully" : status;

    if (status === "Updated successfully") {
      this.setState({
        selectedIndex: this.state.selectedIndex,
        showUsersVo: this.props.workflowUserDetails[this.state.selectedIndex],
      });
    }
    this.setState({
      showModal: true,
      message: status,
    });
  };

  modalClosed = () => {
    this.setState({
      showModal: false,
    });
  };
  render() {
    const { classes, supervisorList, workflowUserDetails } = this.props;

    const {
      searchVo,
      showUsersVo,
      message,
      showModal,
      selectedIndex,
      searched,
    } = this.state;

    this.validator.purgeFields();

    return (
      <React.Fragment>
        <Paper
          elevation={0}
          className={classes.card}
          style={{ minHeight: "400px" }}
        >
          <Modal
            dialogTitle={"ADD/SHOW USER"}
            message={message}
            show={showModal}
            modalClosed={() => {
              this.modalClosed();
            }}
          ></Modal>

          <ExpansionPanel summary="User Search">
            <form>
              <div class="panel-body">
                <div className={classes.container}>
                  <div>
                    <InputField
                      name="userName"
                      label="User Name"
                      value={searchVo.userName}
                      onChange={this.handlechange("userName", "searchVo")}
                      onBlur={this.handleOnBlur("userName", "searchVo")}
                    />
                  </div>
                  <div className={classes.Select2}>
                    {/* <Select
                      components={components}
                      propertyName={supervisorList.filter(
                        (option) => option.value === searchVo.supervisorName
                      )}
                      id="OCCURANCE"
                      options={supervisorList}
                      textFieldProps={{
                        label: "Supervisor Name",
                        InputLabelProps: {
                          className: classes.label,
                          shrink: true,
                        },
                      }}
                      className={classes.textFieldSelect}
                      width="180px"
                      handleChange={this.handlechange(
                        "supervisorName",
                        "searchVo"
                      )}
                      classes={classes}
                    /> */}

                    <AutoComplete1
                      vo="searchVo"
                      options={supervisorList}
                      handleChange={this.handleChangeSearchSelectAuto}
                      defaultValue={{ label: "Select", value: "" }}
                      value={
                        supervisorList.filter(
                          (data) => data.value === searchVo.supervisorName
                        )[0]
                      }
                      label="Supervisor Name"
                      margin="0px"
                      name="supervisorName"
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <span
                    class="button-container-search"
                    className={classes.buttonContainerSearch}
                  >
                    <button
                      type="button"
                      id="search"
                      class="btn btn-primary icon-search"
                      onClick={this.fetchWFuserDetails}
                    >
                      Search
                    </button>
                    <button
                      type="button"
                      id="reset"
                      class="btn btn-secondary"
                      onClick={this.handleSearchReset}
                    >
                      Reset
                    </button>
                  </span>
                </div>
              </div>
            </form>
          </ExpansionPanel>
          {workflowUserDetails.length > 0 && searched ? (
            <>
              <ExpansionPanel summary="Show Users">
                <div class="panel-body " style={{ width: "100%" }}>
                  <DataTable
                    data={workflowUserDetails}
                    header={SHOW_USERS_HEADER}
                    rowsPerPage={10}
                    clicked={this.selectRow}
                    index={selectedIndex}
                    searchable={true}
                    exportAsExcel={true}
                  />
                  <div className={classes.container}>
                    <div>
                      {/* <Select
                        components={components}
                        propertyName={supervisorList.filter(
                          (option) =>
                            option.label === showUsersVo.supervisorName
                        )}
                        id="supervisorName"
                        options={supervisorList}
                        textFieldProps={{
                          label: "Supervisor Name",
                          required: true,
                          InputLabelProps: {
                            className: classes.label,
                            shrink: true,
                          },
                        }}
                        className={classes.textFieldSelect}
                        width="200px"
                        handleChange={this.handleLabelChange(
                          "supervisorName",
                          "showUsersVo"
                        )}
                        classes={classes}
                      /> */}
                      <AutoComplete1
                        vo="showUsersVo"
                        options={supervisorList}
                        margin="0px"
                        handleChange={this.handleLabelChange}
                        defaultValue={
                          showUsersVo.supervisorName
                            ? supervisorList.filter(
                                (data) =>
                                  data.label === showUsersVo.supervisorName
                              )[0]
                            : { label: "Select", value: "" }
                        }
                        value={
                          supervisorList.filter(
                            (data) => data.label === showUsersVo.supervisorName
                          )[0]
                        }
                        label="Supervisor Name"
                        name="supervisorName"
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "supervisorName",
                          [
                            supervisorList.filter(
                              (option) =>
                                option.label === showUsersVo.supervisorName
                            )[0] &&
                              supervisorList.filter(
                                (option) =>
                                  option.label === showUsersVo.supervisorName
                              )[0].value,
                            showUsersVo.userId,
                            showUsersVo.userLevel,
                          ],
                          "required|distinctUserAndSupervisior"
                        )}
                      </div>
                    </div>
                    <div className={classes.Select2}>
                      {/* <Select
                        components={components}
                        propertyName={AccessLevels.filter(
                          (option) => option.label === showUsersVo.userLevel
                        )}
                        id="userAccess"
                        options={AccessLevels}
                        textFieldProps={{
                          label: "User Access Level",
                          required: true,
                          InputLabelProps: {
                            className: classes.label,
                            shrink: true,
                          },
                        }}
                        className={classes.textFieldSelect}
                        width="180px"
                        handleChange={this.handleLabelChange(
                          "userLevel",
                          "showUsersVo"
                        )}
                        classes={classes}
                      /> */}
                      <AutoComplete1
                        vo="showUsersVo"
                        margin="0px"
                        options={AccessLevels}
                        handleChange={this.handleLabelChange}
                        defaultValue={AccessLevels[0]}
                        value={
                          AccessLevels.filter(
                            (data) => data.label === showUsersVo.userLevel
                          )[0]
                        }
                        label="User Access Level"
                        name="userLevel"
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "userLevel",
                          showUsersVo.userLevel,
                          "required"
                        )}
                      </div>
                    </div>
                    <div>
                      <InputField
                        name="userName"
                        label="User Name"
                        value={showUsersVo.userName}
                        width="200px"
                        disabled
                      />
                      <div className={classes.validationMessage} />
                    </div>
                    <span
                      class="button-container-search"
                      style={{ marginTop: "20px", marginLeft: "20px" }}
                    >
                      <button
                        id="search"
                        class="btn btn-primary"
                        onClick={this.updatWFuser}
                      >
                        Update
                      </button>
                      <button
                        id="reset"
                        class="btn btn-secondary"
                        onClick={this.handleUpdateReset}
                      >
                        Reset
                      </button>
                    </span>
                  </div>
                </div>
              </ExpansionPanel>
            </>
          ) : workflowUserDetails.length === 0 && searched ? (
            <div class="alert alert-info text-center">NO DATA FOUND</div>
          ) : null}
          <br />
          <br />
          <br />
        </Paper>
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    supervisorList: state.workflow.supervisorList,
    workflowUserDetails: state.workflow.workflowUserDetails,
  };
};

const mapDispatchToProps = {
  addWFuser,
  showUserDropdowns,
  getWFuserDetails,
  updatWFuserDetails,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(WF_ShowUsers));
