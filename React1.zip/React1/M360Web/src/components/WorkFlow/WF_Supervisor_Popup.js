import Button from "@material-ui/core/Button";
import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormLabel from "@material-ui/core/FormLabel";
import Paper from "@material-ui/core/Paper";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import RadioButtonCheckedIcon from "@material-ui/icons/RadioButtonChecked";
import RadioButtonUncheckedIcon from "@material-ui/icons/RadioButtonUnchecked";
import React from "react";
import { connect } from "react-redux";
import Modal from "../../components/UI/Modal/Modal";
import { SUPERVISOR_STATUS } from "../../constants/SelectStaticData";
import { supervisorUpdateStatus } from "../../redux/actions/WorkflowActions";
import InputField from "../UI/InputField";
import AutoComplete1 from "../UI/Select";
import * as DateUtil from "../../utils/DatePicker";
import { withStyles } from "@material-ui/core/styles";
import { Styles } from "../../assets/styles/Theme";
import { customValidations } from "../../utils/CustomValidations";
import SimpleReactValidator from "simple-react-validator";

class SupervisorPopup extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      userStatus: "",
      inactiveStartDateFrmt: "",
      inactiveEndDateFrmt: "",
      transferFlag: "Y",
      closePopup: false,
      message: "",
    };
    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
      },
    });
  }

  async componentDidMount() {
    await this.setState({
      userStatus: this.props.selectedValues.userStatus,
      inactiveStartDateFrmt: this.props.selectedValues.inactiveStartDateFrmt,
      inactiveEndDateFrmt: this.props.selectedValues.inactiveEndDateFrmt,
    });
  }

  confirmUpdate = async () => {
    this.props.close();
    let payload = {
      searchParms: {
        suserId: this.props.userId,
      },
      userStatus: this.state.userStatus,
      userId: this.props.selectedValues.userId,
      prtyMethod: this.props.selectedValues.prtyMethod,
      unAssignedFlag: this.state.transferFlag,
      inactiveStartDate: this.state.inactiveStartDateFrmt,
      inactiveEndDate: this.state.inactiveEndDateFrmt,
    };
    this.props.updateUserStatus(payload);
  };

  submitComment = async () => {};
  handleChangeSearchSelectAuto = (data, name) => {
    let value = data.value;
    this.setState((prevState) => ({
      ...prevState,

      [name]: value,
    }));
  };

  handleDates = (event) => {
    var self = this;
    const fieldId = "#" + event.target.id;
    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        self.setDate(e.target.id, e.target.value);
        document.getElementById(fieldId.substr(1)).focus();
      });
  };

  setDate = (name, value) => {
    this.setState((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  handleDateChange = (name) => (event) => {
    let value = event.target ? event.target.value : event.value;
    value = value.replace(/[^0-9]/g, "").trim();
    if (value.length === 8) {
      value = value.replace(/^(\d{2})/, "$1/");
      value = value.replace(/\/(\d{2})/, "/$1/");
      value = value.replace(/(\d)\/(\d{4}).*/, "$1/$2");
    }

    this.setState((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };
  modalClosed = () => {
    this.setState({ closePopup: false });
  };

  handlechange = (name) => (event) => {
    let value = event.target
      ? event.target.value.toUpperCase()
      : event.value.toUpperCase();
    this.setState((prevState) => ({
      ...prevState,

      [name]: value,
    }));
  };

  handleOnBlur = (event) => {
    let value = event.target.value.trim();
    let name = event.target.name;
    this.setState((prevState) => ({
      ...prevState,

      [name]: value,
    }));
  };

  render() {
    const { classes } = this.props;
    return (
      <React.Fragment>
        <Modal
          dialogTitle="Supervisor"
          message={this.state.message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Paper
          className={classes.root}
          elevation={0}
          style={{ padding: "15px" }}
        >
          <div className={classes.container}>
            <div>
              {/* <Select
                components={components}
                propertyName={SUPERVISOR_STATUS.filter(
                  (option) => option.value === this.state.userStatus
                )}
                options={SUPERVISOR_STATUS}
                label="User Status"
                textFieldProps={{
                  id: "user",
                  label: "User Status",
                  InputLabelProps: {
                    className: classes.label,
                    shrink: true,
                  },
                }}
                className={classes.textFieldSelect}
                handleChange={this.handleChangeSearchSelect("userStatus")}
                classes={classes}
              /> */}
              <AutoComplete1
                options={SUPERVISOR_STATUS}
                handleChange={this.handleChangeSearchSelectAuto}
                defaultValue={this.state.userStatus ?  SUPERVISOR_STATUS.filter(
                  (data) => data.value === this.state.userStatus
                )[0] : SUPERVISOR_STATUS[0] }
                value={
                  SUPERVISOR_STATUS.filter(
                    (data) => data.value === this.state.userStatus
                  )[0]
                }
                label="User Status"
                //margin='0px'
                // width="220px"
                name="userStatus"
              />
              <div className={classes.validationMessage} />
            </div>
            {this.state.userStatus === "I" && (
              <>
                <div>
                  <InputField
                    name="inactiveStartDateFrmt"
                    label="Inactive Start Date"
                    required={this.state.editable}
                    value={this.state.inactiveStartDateFrmt}
                    onClick={this.handleDates}
                    onChange={this.handleDateChange("inactiveStartDateFrmt")}
                    onBlur={this.handleOnBlur}
                    disabled={this.state.userStatus === "A"}
                    placeholder="MM/DD/YYYY"
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="inactiveEndDateFrmt"
                    label="Inactive Till Date"
                    required={this.state.editable}
                    value={this.state.inactiveEndDateFrmt}
                    onClick={this.handleDates}
                    onChange={this.handleDateChange("inactiveEndDateFrmt")}
                    onBlur={this.handleOnBlur}
                    disabled={this.state.userStatus === "A"}
                    placeholder="MM/DD/YYYY"
                  />
                  <div className={classes.validationMessage} />
                </div>
              </>
            )}
            {this.state.userStatus === "I" ? (
              <FormControl component="fieldset" className={classes.formControl}>
                <FormLabel component="legend" className={classes.legend}>
                  Do you want to unassign/Transfer the cases? &nbsp;
                  <RadioGroup
                    aria-label="Dialysis"
                    name="Dialysis"
                    className={classes.group}
                    value={this.state.transferFlag}
                    onChange={this.handlechange("transferFlag")}
                  >
                    <FormControlLabel
                      value="Y"
                      control={
                        <Radio
                          color="primary"
                          // disabled={originalApplication}
                          icon={<RadioButtonUncheckedIcon fontSize="small" />}
                          checkedIcon={
                            <RadioButtonCheckedIcon fontSize="small" />
                          }
                        />
                      }
                      label="Yes"
                    />
                    <FormControlLabel
                      value="N"
                      control={
                        <Radio
                          color="primary"
                          // disabled={originalApplication}
                          icon={<RadioButtonUncheckedIcon fontSize="small" />}
                          checkedIcon={
                            <RadioButtonCheckedIcon fontSize="small" />
                          }
                        />
                      }
                      label="No"
                    />
                  </RadioGroup>
                </FormLabel>
              </FormControl>
            ) : null}

            <div className={classes.buttonformat}>
              <Button
                variant="contained"
                color="primary"
                onClick={this.confirmUpdate}
                className={classes.buttonworkflow}
              >
                Update
              </Button>

              <Button
                variant="contained"
                color="primary"
                onClick={this.props.close}
                className={classes.buttonworkflow}
              >
                Close
              </Button>
            </div>
          </div>
        </Paper>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {};
};
const mapDispatchToProps = {
  supervisorUpdateStatus,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(SupervisorPopup));
