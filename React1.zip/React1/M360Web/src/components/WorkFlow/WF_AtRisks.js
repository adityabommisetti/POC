import React, { Component } from "react";
import {
  ATRISK_HEADER,
  ATRISK_SELECT_HEADER
} from "../../constants/staticData/SupervisorWorkflowHeaderData";
import { Styles } from "../../assets/styles/Theme";
import {
  fetchRiskData,
  fetchRiskDetails
} from "../../redux/actions/AtRiskAction";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";
import DataTable from "../Home/DataTable";

class AtRisks extends Component {
  constructor(props) {
    super(props);
    this.state = {
      buttonflag: true,
      selectedIndex: 0,
      detailIndex: 0,
      page: 0,
      data: this.props.riskData ? this.props.riskData : [],
      riskDetails: this.props.riskDetails ? this.props.riskDetails : [],
      searchVO: {
        queueCd: 0,
        daysRemaining: 0,
        queueName: "",
        queuePrty: 0,
        count: 0,
        queuePrtyFrmt: ""
      }
    };
  }

  /*componentWillReceiveProps(nextProps) {
    if (nextProps) {
      this.setState({
        data: nextProps.riskData,
        riskDetails: nextProps.riskDetails
      });
    }
  }*/
  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps) {
      return {
        data: nextProps.riskData,
        riskDetails: nextProps.riskDetails
      };
    }

  }


  onRowSelect = async (index, page) => {
    this.setState({
      selectedIndex: index,
      page: page
    });
    if (this.props.riskData[index]) {
      const data = this.props.riskData[index];
      let payload = {
        queueCd: data.queueCd,
        daysRemaining: data.daysRemaining,
        queueName: data.queueName,
        queuePrty: data.queuePrty,
        count: data.count,
        queuePrtyFrmt: data.queuePrtyFrmt
      };
      await this.props.fetchRiskDetails(payload);
    }
  };

  print = () => {
    var content = document.getElementById("SummaryTbl").innerHTML;
    var mywindow = window.open("", " ", "height=600,width=800");

    mywindow.document.write("<html><head><title></title>");
    mywindow.document.write("</head><body >");
    mywindow.document.write(content);
    mywindow.document.write("</body></html>");

    mywindow.document.close();
    mywindow.focus();
    mywindow.print();
    mywindow.close();
    return true;
  };

  async componentDidMount() {
    await this.props.fetchRiskData();
    await this.setState({
      data: this.props.riskData
    });
    this.onRowSelect(0);
  }

  render() {
    const { page, selectedIndex, data, detailIndex, riskDetails } = this.state;

    return (
      <React.Fragment>
        <div>
          {data && data.length > 0 ? (
            <DataTable
              data={data}
              header={ATRISK_HEADER}
              rowsPerPage={10}
              clicked={this.onRowSelect}
              index={selectedIndex}
              pageNo={page}
            />
          ) : null}

          <div id="SummaryTbl">
            <DataTable
              data={riskDetails}
              header={ATRISK_SELECT_HEADER}
              rowsPerPage={10}
              index={detailIndex}
              pageNo={page}
              exportAsExcel={true}
              printTb={true}
              printFun={this.print}
              notClickable={true}
            />
          </div>
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  return {
    riskData: state.workflow.riskData,
    riskDetails: state.workflow.riskDetails
  };
};

const mapDispatchToProps = {
  fetchRiskData,
  fetchRiskDetails
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(AtRisks));
