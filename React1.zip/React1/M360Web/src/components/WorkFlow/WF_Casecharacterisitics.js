import React, { Component } from "react";
import DataTable from "../Home/DataTable";
import { withStyles } from "@material-ui/core/styles";
import { Styles } from "../../assets/styles/Theme";
import { QUEUES_HEADER } from "../../constants/Headers/WorkFlowHeaders";
import InputField from "../UI/InputField";
import AutoComplete1 from "../UI/Select";
import Button from "@material-ui/core/Button";
import {
  getRequest,
  postRequest,
  updateAssignmentLimit,
  fetchWfCacheData,
} from "../../redux/actions/WorkflowActions";
import { connect } from "react-redux";
import * as ActionTypes from "../../redux/types/ActionType";
import Modal from "../../components/UI/Modal/Modal";
import * as URL from "../../services/API_URL";
import ConfirmBox from "../../utils/PopUp";
import * as Type from "../../constants/ConfirmType";
import FetchQueuePopup from "../WorkFlow/WF_FetchPopup";
import Popup from "reactjs-popup";
import formatTimeStamp from "../../utils/Utils";

const INITIAL_STATE = {
  queuePrty: "",
  compDays: "",
  atRiskDays: "",
  queueDesc: "",
};
const SELECT_OBJECT = {
  label : "Select",
  value: "",
};
class Queues extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedIndex: 0,
      inputs: INITIAL_STATE,
      modalMessage: "",
      showModal: false,
      maxLimit: "",
      alertmsg: "",
      newAssignmentLimit: "",
      modified: false,
    };
  }

  async componentWillUnmount() {
    await this.props.fetchWfCacheData();
  }

  selectRow = async (index) => {
    await this.setState({
      selectedIndex: index,
      inputs: this.props.caseTableData[index],
    });
  };

  async UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.caseTableData.length > 0) {
      await this.setState((prevState) => ({
        ...prevState,
        inputs: nextProps.caseTableData[this.state.selectedIndex],
      }));
    }
    if (nextProps.wfCacheData) {
      this.setState({ maxLimit: nextProps.wfCacheData.maxAssignableWork });
    }
  }

  updateAssignLimit = async () => {
    if (
      this.props.searchCriteriaVo &&
      this.props.searchCriteriaVo.assignedToUser ===
        this.props.loginData.loginVo.userId
    ) {
      this.setState({ maxLimit: this.props.wfCacheData.maxAssignableWork });
    }

    if (this.state.newAssignmentLimit === "") {
      this.setState({
        showModal: true,
        modalMessage: "Please Enter Value",
      });
    } else {
      const status = await this.props.updateAssignmentLimit(
        this.state.newAssignmentLimit
      );
      if (status === "SUCCESS") {
        this.setState({
          showModal: true,
          modalMessage: "Updated Successfully",
          newAssignmentLimit: null,
          modelFlag: true,
          alertmsg: null,
          closeFetch: true,
        });
      } else {
        this.setState({ showModal: true, modalMessage: status });
      }
    }
  };

  changeAssignLimit = (event) => {
    let value = event.target.value.replace(/[^0-9]/g, "").trim();
    value = value.replace(/^(?=[0-9]{3})([0-9]{3})/, "$1");
    this.setState({
      newAssignmentLimit: value,
      alertmsg: null,
    });
  };

  componentDidMount() {
    const fetchData = async () => {
      await this.props.getRequest(URL.CASE_QUEUE, ActionTypes.CASE_TABLE_DATA);
      await this.props.getRequest(
        URL.GET_WORKFLOW_CACHE_DATA,
        ActionTypes.GET_WORKFLOW_CACHE_DATA
      );
    };
    fetchData();
  }

  // handlechangeAuto = async (data, name, targetVo) => {
  //   let value = data.label ? data.label.toUpperCase() : data.target.label;
  //   await this.setState((prevState) => ({
  //     ...prevState,
  //     [targetVo]: { ...prevState[targetVo], [name]: value },
  //   }));
  // };

  handleLabelChange = async (data, name, targetVo) => {
    let value = data.label;
    await this.setState((prevState) => ({
      ...prevState,
      [targetVo]: { ...prevState[targetVo], [name]: value },
    }));
    await this.setState({ modified: true });
  };

  handlechange = (name) => async (event) => {
    let value = event.value
      ? event.value.toUpperCase()
      : event.target.value.toUpperCase();
    this.setState((prevState) => ({
      ...prevState,
      inputs: {
        ...prevState.inputs,
        [name]: value,
      },
    }));
    await this.setState({ modified: true });
  };

  handleOnBlur = (event) => {
    let value = event.label ? event.label : event.target.value.trim();
    let name = event.target.name;
    this.setState((prevState) => ({
      ...prevState,
      inputs: {
        ...prevState.inputs,
        [name]: value,
      },
    }));
  };

  handleReset = () => {
    this.setState((prevState) => ({
      ...prevState,
      inputs: this.props.caseTableData[this.state.selectedIndex],
    }));
  };

  handleUpdate = async () => {
    if (this.state.modified === true) {
      ConfirmBox(this.confirmUpdateCase, Type.UPDATE, this.props);
    } else {
      await this.setState({
        showModal: true,
        modalMessage: "No Fields Updated",
      });
    }
  };

  confirmUpdateCase = async () => {
    const Case = this.props.caseTableData[this.state.selectedIndex];
    const inputs = this.state.inputs;
    const queuPrty = this.props.wfCacheData.wfCasePriority.filter(
      (option) => option.label === inputs.queuePrty
    )[0].value;
    const queuePrty = [SELECT_OBJECT, ...queuPrty]

    const body = { ...Case, ...inputs, queuePrty: queuePrty };

    const status = await this.props.postRequest(
      URL.UPDATE_CASE_QUEUE,
      body,
      ActionTypes.CASE_TABLE_DATA
    );

    if (status === "SUCCESS") {
      await this.setState({
        showModal: true,
        modalMessage: "Updated Successfully",
      });
    } else {
      this.setState({ showModal: true, modalMessage: status });
    }
  };

  render() {
    const { classes, caseTableData: tableData } = this.props;
    const { inputs, modalMessage, showModal } = this.state;
    const wfCasePriority = this.props.wfCacheData
      ? [SELECT_OBJECT, ...this.props.wfCacheData.wfCasePriority]
      : [];

    return (
      <React.Fragment>
        <Modal
          dialogTitle={"Case Characteristics"}
          message={modalMessage}
          show={showModal}
          modalClosed={() => {
            this.setState({ showModal: false });
          }}
        ></Modal>

        <DataTable
          header={QUEUES_HEADER}
          data={tableData}
          rowsPerPage={10}
          clicked={this.selectRow}
          index={this.state.selectedIndex}
        />
        <div className={classes.buttonContainer}>
          {this.props.wfCacheData &&
          (this.props.wfCacheData.supervisor === "S" ||
            this.props.wfCacheData.supervisor === "A") ? (
            <React.Fragment>
              <Popup
                className={classes.mobileWidth}
                modal
                trigger={
                  <button class="btn btn-secondary update-Maxassign-work">
                    Update MaxAssign Work
                  </button>
                }
              >
                {(close) => (
                  <div>
                    <FetchQueuePopup
                      close={close}
                      classes={classes}
                      maxLimit={
                        this.state.maxLimit !== ""
                          ? this.state.maxLimit
                          : this.props.wfCacheData.maxAssignableWork
                      }
                      change={this.changeAssignLimit}
                      update={this.updateAssignLimit}
                      newVal={this.state.newAssignmentLimit}
                      alertmsg={this.state.alertmsg}
                    />
                  </div>
                )}
              </Popup>
            </React.Fragment>
          ) : null}

          <Button
            align="right"
            type="submit"
            variant="contained"
            color="primary"
            onClick={this.handleUpdate}
          >
            Update
          </Button>
          <Button
            variant="contained"
            color="primary"
            onClick={this.handleReset}
          >
            Reset
          </Button>
        </div>

        <div className="panel-body margin-top1">
          <div className={classes.container}>
            <div className={classes.Select2}>
              {/* <Select
                components={components}
                propertyName={
                  wfCasePriority
                    ? wfCasePriority.filter(
                        option => option.label === inputs.queuePrty
                      )
                    : ""
                }
                options={wfCasePriority}
                label="select"
                textFieldProps={{
                  label: "Case Priority",
                  id: "casePrty",
                  InputLabelProps: {
                    className: classes.label,
                    shrink: true
                  }
                }}
                className={classes.textFieldSelect}
                classes={classes}
                handleChange={this.handlechange("queuePrty")}
              /> */}

              {/* <AutoComplete1
               vo="inputs"
                options={wfCasePriority}
                margin="0px"
                //fontSize="0.718em"
                handleChange={this.handlechangeAuto.bind(this)}
                defaultValue={
                  inputs.queuePrty
                }
                value={
                  wfCasePriority.filter(
                    (data) => data.label ===  inputs.queuePrty
                  )[0]
                }
                label="Case Priority"
                name="queuePrty"
              /> */}
              <AutoComplete1
                vo="inputs"
                options={wfCasePriority}
                margin="0px"
                handleChange={this.handleLabelChange}
                defaultValue={
                  inputs.queuePrty
                    ? wfCasePriority.filter(
                        (data) => data.label === inputs.queuePrty
                      )[0]
                    : wfCasePriority[0]
                }
                value={
                  wfCasePriority.filter(
                    (data) => data.label === inputs.queuePrty
                  )[0]
                }
                label="Case Priority"
                name="queuePrty"
              />
            </div>
            <div>
              <InputField
                name="compDays"
                label="Comp Days"
                value={inputs.compDays}
                onChange={this.handlechange("compDays")}
                onBlur={this.handleOnBlur}
              />
            </div>
            <div>
              <InputField
                name="atRiskDays"
                label="At Risk Days"
                value={inputs.atRiskDays}
                onChange={this.handlechange("atRiskDays")}
                onBlur={this.handleOnBlur}
              />
            </div>
            <div>
              <InputField
                width="250px"
                name="queueDesc"
                label="Case Description"
                value={inputs.queueDesc}
                onChange={this.handlechange("queueDesc")}
                onBlur={this.handleOnBlur}
              />
            </div>
            <div>
              <InputField
                disabled
                width="180px"
                name="lastUpdtTime"
                label="Modified Time"
                value={formatTimeStamp(inputs.lastUpdtTime)}
              />
            </div>
            <div>
              <InputField
                disabled
                width="200px"
                name="lastUpdtUserName"
                label="Modified User"
                value={inputs.lastUpdtUserName}
              />
            </div>
          </div>
        </div>
        <br />
        <br />
        <br />
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    caseTableData: state.workflow.caseTableData,
    wfCacheData: state.workflow.wfCacheData,
    searchCriteriaVo: state.workflow.searchCriteriaVo,
    loginData: state.loginData,
  };
};

const mapDispatchToProps = {
  getRequest,
  postRequest,
  updateAssignmentLimit,
  fetchWfCacheData,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(Queues));
