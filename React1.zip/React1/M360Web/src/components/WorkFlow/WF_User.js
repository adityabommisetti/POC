import * as ActionTypes from "../../redux/types/ActionType";
import * as Type from "../../constants/ConfirmType";

import {
  ACTIVITIES_HEADER,
  CASES_HEADER,
} from "../../constants/staticData/UserWorkflowHeaderData";
import {
  MemberSearch,
  setSelectedTab,
  memberrowClickSearch,
} from "../../redux/actions/MemberActions";
import React, { Component } from "react";
import {
  assignWork,
  getActivities,
  refreshDashlets,
  searchWorkFlow,
  updateAssignmentLimit,
  updateCase,
  addCaseComments,
  workflowSearchNextPage,
  fetchWfCacheData,
} from "../../redux/actions/WorkflowActions";

import {
  resetMemberSearch,
  searchAttributes,
} from "../../redux/actions/MemberActions";
import {
  fetchCacheData,
  applSearch as searchApplication,
} from "../../redux/actions/ApplActions";

import Button from "@material-ui/core/Button";
import CaseDataTable from "./WF_CaseDatatable";
import ConfirmBox from "../../utils/PopUp";

import Dashlet from "./WF_Dashlet";
import DataTable from "../Home/DataTable";
import ExpansionPanel from "../UI/ExpansionPanel";
import InputField from "../UI/InputField";

import Modal from "../../components/UI/Modal/Modal";
import Paper from "@material-ui/core/Paper";
import AutoComplete1 from "../UI/Select";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../assets/styles/Theme";
import TextField from "@material-ui/core/TextField";
import { connect } from "react-redux";
import { validationRules } from "../../utils/ValidationRules";
import { withStyles } from "@material-ui/core/styles";
import { withRouter } from "react-router-dom";
import isEmpty from "lodash/isEmpty";

const INITIAL_STATE = {
  applId: "",
  assignedToUser: "",
  caseId: "",
  mbrName: "",
  medicareId: "",
  memberId: "",
  caseDesc: "",
  caseStatus: "",
  supplementalId: "",
  riskInd: "",
  fetchSize: "",
  daysRemaining: "",
};

const fetchQueueDropDownValues = [
  { label: "Select", value: "" },
  { label: "5", value: "5" },
  { label: "10", value: "10" },
  { label: "20", value: "20" },
  { label: "30", value: "30" },
  { label: "40", value: "40" },
  { label: "50", value: "50" },
  { label: "60", value: "60" },
  { label: "70", value: "70" },
  { label: "80", value: "80" },
  { label: "90", value: "90" },
  { label: "100", value: "100" },
];

class WorkflowTabs extends Component {
  constructor(props) {
    super(props);
    this.validator = new SimpleReactValidator({ ...validationRules });

    this.state = {
      wfSearchVO: {
        ...INITIAL_STATE,
        assignedToUser: this.props.loginData.loginVo.userId,
        applId: this.props.searchAttribute ? props.searchAttribute.applId : "",
        caseDesc: this.props.searchAttribute
          ? props.searchAttribute.caseDesc
          : "",
        caseId: this.props.searchAttribute ? props.searchAttribute.caseId : "",
        caseStatus: this.props.searchAttribute
          ? props.searchAttribute.caseStatus
          : "",
        mbrName: this.props.searchAttribute
          ? props.searchAttribute.mbrName
          : "",
        medicareId: this.props.searchAttribute
          ? props.searchAttribute.medicareId
          : "",
        memberId: this.props.searchAttribute
          ? props.searchAttribute.memberId
          : "",
        supplementalId: this.props.searchAttribute
          ? props.searchAttribute.supplementalId
          : "",
      },
      mbridLit: [],
      updatecaseState: "",
      searchResultsVo: {},
      modified: false,
      editable: false,
      caseSelectedRow: false,
      activitySelectedRow: 0,
      assignedQueues: "",
      open: "",
      closed: "",
      collapseSearch: false,
      caseSelectedIndex: 0,
      eventType: "",
      flag: false,
      updatedCaseList: [],
      closePopup: false,
      updatedItems: [],
      redirectName: "/workflow",
      openDetails: "",
      openCount: "",
      detailedOpenCases: "",
      holdCount: "",
      detailedholdCases: "",
      atRiskCount: "",
      atRiskDetailedCases: "",
      newAssignmentLimit: null,
      modelFlag: false,
      alertmsg: "",
      comment: "",
      isSupervisor: "",
      selectedVo: "",
      maxLimit: "",
      supervisorTab: false,
      validateFlag: true,
      activityTable: true,
      rowsPerPage: 10,
      searchFlag: false,
      compareFlag: false,
      resetFlag: true,
    };
    this.caseDatatable = React.createRef();
  }

  componentWillUnmount() {
    this.setState({ redirectName: "/" });
    this.props.resetMemberSearch({
      applicationId: this.props.selectedMemberId.applicationId,
    });
  }

  handlechange = (name) => (event) => {
    let value = event.target
      ? event.target.value.toUpperCase()
      : event.value.toUpperCase();
    this.setState(
      (prevState) => ({
        ...prevState,
        wfSearchVO: {
          ...prevState.wfSearchVO,
          [name]: value.trim(),
        },
        modified: true,
      }),
      () => {
        this.props.searchAttributes({
          workflowSearch: { ...this.state.wfSearchVO },
        });
      }
    );
  };

  handleOnBlur = (event) => {
    let value = event.target.value.trim();
    let name = event.target.name;
    this.setState(
      (prevState) => ({
        ...prevState,
        wfSearchVO: {
          ...prevState.wfSearchVO,
          [name]: value.trim(),
        },
        modified: true,
      }),
      () => {
        this.props.searchAttributes({
          workflowSearch: { ...this.state.wfSearchVO },
        });
      }
    );
  };

  handleChangeSearchSelect = (name) => (event) => {
    let value = event.target ? event.target.value : event.value;
    if (name === "fetchSize" || name === "caseDesc" || name === "caseStatus") {
      this.setState(
        (prevState) => ({
          ...prevState,
          wfSearchVO: {
            ...prevState.wfSearchVO,
            [name]: value,
          },
          modified: true,
          validateFlag:
            value === "HOLD" || value === "CLOSED" || value === "OPEN"
              ? false
              : true,
        }),
        () => {
          this.props.searchAttributes({
            workflowSearch: { ...this.state.wfSearchVO },
          });
        }
      );
    }

    if (name === "updatecaseState") {
      this.setState(
        {
          [name]: value,

          validateFlag:
            value === "HOLD" || value === "CLOSED" || value === "OPEN"
              ? false
              : true,
        },
        () => {
          this.props.searchAttributes({
            workflowSearch: { ...this.state.wfSearchVO },
          });
        }
      );
    }

    if (this.state.wfSearchVO.fetchSize === "") {
      this.validator.hideMessages();
    }
  };

  handleChangeSearchSelectAuto = async (data, name) => {
    let value = data.value;

    if (name === "updatecaseState") {
      await this.setState((prevState) => ({
        ...prevState,

        [name]: value,
        modified: true,
        // searchFlag: false,
      }));
    }

    else {


      await this.setState((prevState) => ({
        ...prevState,
        wfSearchVO: {
          ...prevState.wfSearchVO,
          [name]: value,
        },
        modified: true,
        // searchFlag: false,
      }));
    }
  };

  workflowSearchNextPage = async (pageNo) => {
    const { caseData } = this.props.searchResultsVo;

    const lastRow = caseData[caseData.length - 1];
    let payload = {
      ...this.props.searchCriteriaVo,
      daysRemaining: lastRow.daysRemaining,
      caseId: lastRow.caseId,
    };

    await this.props.workflowSearchNextPage(payload);
    this.setState({ caseSelectedIndex: pageNo * this.state.rowsPerPage });
  };

  async componentDidMount() {
    await this.props.fetchWfCacheData();
    await this.searchWorkFlow("defaultSearch");

    if (this.props.wfCacheData && this.props.wfCacheData.supervisor) {
      this.setState({ isSupervisor: this.props.wfCacheData.supervisor });
    }

    if (!isEmpty(this.props.searchResultsVo.caseData)) {
      await this.caseSelectedRow(0);
    }

    if (this.state.assignedToUser === this.props.loginData.loginVo.userId) {
      this.setState({ maxLimit: this.props.wfCacheData.maxAssignableWork });
    }
    const { loginProfile } = this.props;
    const MBRIDLIT = loginProfile.filter((data) => data.label === "MBRIDLIT");
    this.setState({
      mbridLit: MBRIDLIT[0],
    });
  }

  searchWorkFlow = async (searchFlag) => {
    let payload = { ...this.state.wfSearchVO };
    this.validator.hideMessages();
    await this.setState({ flag: true, searchFlag: true });

    if (searchFlag === "defaultSearch") {
      payload = {
        ...this.state.wfSearchVO,
        caseStatus: "OPEN",
      };
      this.setState({
        compareFlag: true,
        wfSearchVO: {
          ...this.state.wfSearchVO,
          caseStatus: "OPEN",
        },
      });
    } else {
      this.setState({ searchFlag: true, compareFlag: true });
    }

    this.props.searchAttributes({ workflowSearch: payload });
    await this.props.searchWorkFlow(payload);
    await this.setState({
      caseSelectedIndex: 0,
      searchResultsVo: {
        ...this.props.searchResultsVo,
        caseData: this.props.searchResultsVo.caseData,
        dashletData: this.props.searchResultsVo.dashletData,
      },
      updatecaseState: "",
    });
    console.log(this.state.searchResultsVo.caseData);
  };

  refreshDashlets = async () => {
    await this.props.refreshDashlets(
      this.state.wfSearchVO.assignedToUser,
      this.state.supervisorTab
    );
    this.setState({
      compareFlag: true,
      searchResultsVo: {
        ...this.state.searchResultsVo,
        dashletData: this.props.searchResultsVo.dashletData,
      },
    });
  };

  reset = async () => {
    this.validator.hideMessages();
    await this.setState({ resetFlag: false });
    this.setState({
      wfSearchVO: {
        ...INITIAL_STATE,
        assignedToUser: this.props.loginData.loginVo.userId,
        caseStatus: "OPEN",
      },
    });
  };

  // static getDerivedStateFromProps(nextProps, prevState) {
  //   if (nextProps) {
  //     return {
  //       searchResultsVo: nextProps.searchResultsVo,
  //       wfCacheData: nextProps.wfCacheData,
  //     };
  //   }
  //   return {
  //     wfSearchVO: INITIAL_STATE,
  //   };
  // }

  async componentWillReceiveProps(nextProps) {
    if (nextProps) {
      await this.setState({
        searchResultsVo: nextProps.searchResultsVo,
        wfCacheData: nextProps.wfCacheData,
      });
    }
  }

  updateCaseStatus = async (e) => {
    e.preventDefault();
    this.validator.fields.FetchCount = true;
    if (
      this.state.searchResultsVo.caseData[this.state.caseSelectedIndex]
        .caseStatus === this.state.updatecaseState
    ) {
      this.setState({
        // updatecaseState: "",
        // comment: "",
        closePopup: true,
        message: "Both Case status are same",
      });
    } else {
      var allData = [];

      for (let i = 0; i < this.state.searchResultsVo.caseData.length; i++) {
        if (this.state.searchResultsVo.caseData[i].checked === "Y") {
          allData.push(this.state.searchResultsVo.caseData[i]);
        }
      }

      if (allData.length === 0) {
        alert("No cases selected");
        return;
      }

      this.setState({ updatedItems: allData });

      if (!isEmpty(allData) && this.validator.fieldValid("Comment")) {
        if (this.state.updatecaseState === "CLOSED") {
          alert("You are updating the Case Status to closed.");
        }

        ConfirmBox(this.confirmUpdate, Type.UPDATE, this.props);
      } else {
        this.validator.showMessages();
        this.forceUpdate();
      }
    }
  };

  Fieldchange = (e) => {
    this.setState({ comment: e.target.value });
  };

  confirmUpdate = async () => {
    let payload = {
      wfSearchVO: this.state.wfSearchVO,
      emWFUpdateCaseVO: this.state.updatedItems,
      caseComment: this.state.comment,
      updateCaseStatus: this.state.updatecaseState,
    };

    const status = await this.props.updateCase(payload);

    let message = "";

    if (status === "Status updated successfully") {
      message = ActionTypes.UPDATE;
      this.validator.hideMessages();
      await this.setState({ caseSelectedIndex: 0 });
    } else {
      message = status;
    }

    this.setState({
      updatecaseState: "",
      comment: "",
      closePopup: true,
      message: message,
    });
  };

  modalClosed = () => {
    this.setState({
      closePopup: false,
    });
  };

  openItems = async (itemType, isSubItem, queueName) => {
    let payload = {};
    await this.setState({
      wfSearchVO: {
        ...INITIAL_STATE,
        assignedToUser: this.state.wfSearchVO.assignedToUser,
      },
    });
    // let assignedUser = this.state.wfSearchVO.assignedToUser;
    // assignedUser =
    //   "ASSIGNED" || "UNASSIGNED"
    //     ? this.props.loginData.loginVo.userId
    //     : assignedUser;

    if (itemType === "ATRISK") {
      payload = {
        ...INITIAL_STATE,
        riskInd: "Y",
        caseStatus: "",
        caseDesc: queueName,
        assignedToUser: this.state.wfSearchVO.assignedToUser,
      };
    } else if (itemType === "ASSIGNED") {
      payload = {
        ...INITIAL_STATE,
        riskInd: "",
        caseDesc: queueName,
        assignedToUser: "ASSIGNED",
        caseStatus: "",
      };
    } else if (itemType === "UNASSIGNED") {
      payload = {
        ...INITIAL_STATE,
        riskInd: "",
        caseDesc: queueName,
        assignedToUser: "UNASSIGNED",
      };
    } else {
      payload = {
        ...INITIAL_STATE,
        riskInd: "",
        caseStatus: itemType,
        caseDesc: queueName,
        assignedToUser: this.state.wfSearchVO.assignedToUser,
      };
    }

    this.setState({
      wfSearchVO: {
        ...this.state.wfSearchVO,
        riskInd: payload.riskInd,
        caseStatus: payload.caseStatus,
        caseDesc: payload.caseDesc,
        assignedToUser: payload.assignedToUser,
      },
    });
    await this.props.searchWorkFlow(payload);
    if (!isEmpty(this.props.searchResultsVo.caseData)) {
      await this.caseSelectedRow(0);
    }
  };

  assignWork = () => {
    this.setState({ validateFlag: true });
    if (this.validator.allValid()) {
      if (this.state.wfSearchVO.assignedToUser === "Select") {
        this.setState({
          message: "Please Select Assigned To User",
          closePopup: true,
        });
      } else {
        ConfirmBox(this.confirmAssignWork, Type.UPDATE, this.props);
      }
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  confirmAssignWork = async () => {
    let message = "";

    if (
      this.props.searchResultsVo.caseData.length <
      this.props.wfCacheData.maxAssignableWork
    ) {
      let assignWorksize =
        this.props.wfCacheData.wfOptIn === "N"
          ? 1
          : this.state.wfSearchVO.fetchSize;
      const status = await this.props.assignWork(assignWorksize);

      if (status === "success") {
        message = "Assign Work Done Successfully";
      } else {
        message = status;
      }

      this.setState({
        closePopup: true,
        message: message,
        wfSearchVO: {
          ...this.state.wfSearchVO,
          fetchSize: "",
        },
      });
    } else {
      this.setState({
        message: "Max Assignable Work Exceeded",
        closePopup: true,
      });
    }
  };

  SelectAllHandleCheckBox = (rowscount, selectall, val, page, selectedrow) => {
    let caseData = this.props.searchResultsVo.caseData;
    const a = page * rowscount + rowscount;
    let b = 0;
    if (a > caseData.length) {
      b = caseData.length;
    } else {
      b = a;
    }
    if (page < 1) {
      if (val === "N") {
        for (let i = 0; i < b; i++) {
          let data = [...caseData];
          data[i].checked = val;
        }
      } else {
        for (let i = 0; i < b; i++) {
          let data = [...caseData];
          data[i].checked = val;
        }
      }
    } else {
      if (val === "N") {
        for (let i = page * rowscount; i < b; i++) {
          let data = [...caseData];
          data[i].checked = val;
        }
      } else {
        for (let i = page * rowscount; i < b; i++) {
          let data = [...caseData];

          data[i].checked = val;
        }
      }
    }
  };

  handleCheckBox = async (index, val) => {
    let value = val === "Y" ? "N" : "Y";

    let data = [...this.props.searchResultsVo.caseData];
    data[index].checked = value;

    this.setState({
      searchResultsVo: {
        ...this.state.searchResultsVo,
        caseData: data,
      },
      caseSelectedIndex: index,
    });
  };

  updatedVal = async () => {
    const caseData = this.props.searchResultsVo.caseData[
      this.state.caseSelectedIndex
    ];

    if (caseData.source.toUpperCase() === "APPLICATION") {
      let payload = {
        firstName: "",
        lastName: "",
        DOB: "",
        applId: caseData.appId,
        searchStatus: "",
        hicNbr: "",
      };

      await this.props.fetchCacheData();
      await this.props.history.push(this.state.redirectName);
      await this.props.searchApplication(payload);
    } else if (caseData.source.toUpperCase() === "MEMBER") {
      const tabName = caseData.caseDesc.includes("PCP")
        ? "pcp"
        : caseData.caseDesc.includes("AGENT")
          ? "agent"
          : "demo";

      let searchVo = {
        memberId: caseData.mbrId,
        medicareId: caseData.medicareId,
        selectedTab: tabName,
      };

      await this.props.history.push(this.state.redirectName);
      await this.props.setSelectedTab(tabName);
      await this.props.MemberSearch(searchVo);
    }
  };
  activitySelectRow = async (index) => {
    this.setState({ activitySelectedRow: index });
  };

  handleChangeRowsPerPage = async (rowsPerPage) => {
    await this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  caseSelectedRow = async (index) => {
    await this.setState({
      updatecaseState: "",
      flag: false,
      comment: "",
      caseSelectedIndex: index,
      resetFlag: true,
    });

    let caseData = this.props.searchResultsVo.caseData;

    if (
      this.state.flag === false &&
      caseData[index].caseId !== this.state.selectedVo.caseId
    ) {
      await this.props.getActivities(
        this.state.searchResultsVo.caseData[index].caseId
      );
      this.setState({
        selectedVo: caseData[index],
      });
    }

    let redirectUrl = "";
    if (
      !isEmpty(caseData) &&
      caseData[index].source.toUpperCase() === "MEMBER"
    ) {
      redirectUrl = "/member/search";
    } else if (
      !isEmpty(caseData) &&
      caseData[index].source.toUpperCase() === "APPLICATION"
    ) {
      redirectUrl = "/application";
    }

    await this.setState({
      caseSelectedIndex: index,
      activitySelectedRow: 0,
      redirectName: redirectUrl,
      caseDataOldVo: caseData[index],
    });
  };

  changeAssignLimit = (event) => {
    this.setState({
      newAssignmentLimit: event.target.value,
      alertmsg: null,
    });
  };

  addComments = async (payload) => {
    await this.props.addCaseComments(payload);
    await this.setState({
      closePopup: true,
      message: "Comments Added Successfully",
    });
  };

  updateAssignLimit = async () => {
    if (this.state.newAssignmentLimit === null) {
      this.setState({
        alertmsg: "* Please Enter the Value",
      });
    } else {
      const status = await this.props.updateAssignmentLimit(
        this.state.newAssignmentLimit
      );
      if (status === "SUCCESS") {
        this.setState({
          closePopup: true,
          message: "Updated Successfully",
          newAssignmentLimit: null,
          modelFlag: true,
          alertmsg: null,
          closeFetch: true,
        });
      } else {
        this.setState({ closePopup: true, message: status });
      }
    }
  };
  setCompareFlag = (value) => {
    this.setState({
      compareFlag: value,
    });
  };
  render() {
    const { classes, wfCacheData, searchResultsVo } = this.props;
    const {
      mbridLit,
      wfSearchVO,
      updatecaseState,
      isSupervisor,
      compareFlag,
    } = this.state;
    const caseData = this.state.searchResultsVo.caseData;

    return (
      <React.Fragment>
        <Modal
          dialogTitle="WorkFlow"
          message={this.state.message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>

        <Paper
          elevation={0}
          className={classes.card}
          style={{ minHeight: "400px" }}
        >
          {wfCacheData ? (
            <div class="search-panel">
              <ExpansionPanel
                summary="Search"
                defaultCollapsed={this.state.collapseSearch}
              >
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    this.searchWorkFlow("search");
                  }}
                >
                  <div className={classes.container}>
                    <div>
                      <InputField
                        width="180px"
                        name="medicareId"
                        label="Medicare Id"
                        required={this.state.editable}
                        value={wfSearchVO.medicareId}
                        maxLength="12"
                        onChange={this.handlechange("medicareId")}
                        onBlur={this.handleOnBlur}
                      />
                      <div className={classes.validationMessage} />
                    </div>

                    <div>
                      <InputField
                        width="180px"
                        name="mbrName"
                        label="Member Name"
                        required={this.state.editable}
                        value={wfSearchVO.mbrName}
                        maxLength="60"
                        onChange={this.handlechange("mbrName")}
                        onBlur={this.handleOnBlur}
                        disabled={this.state.editable}
                      />
                      <div className={classes.validationMessage} />
                    </div>

                    <div>
                      <InputField
                        width="180px"
                        name="memberId"
                        label={
                          mbridLit.value === "TSA" ? "Wipro ID" : "M360 ID"
                        }
                        required={this.state.editable}
                        value={wfSearchVO.memberId}
                        maxLength="15"
                        onChange={this.handlechange("memberId")}
                        onBlur={this.handleOnBlur}
                        disabled={this.state.editable}
                      />
                      <div className={classes.validationMessage} />
                    </div>

                    <div>
                      <InputField
                        name="caseId"
                        label="Case Id"
                        required={this.state.editable}
                        value={wfSearchVO.caseId}
                        maxLength="10"
                        onChange={this.handlechange("caseId")}
                        onBlur={this.handleOnBlur}
                        disabled={this.state.editable}
                      />
                      <div className={classes.validationMessage} />
                    </div>

                    <div>
                      <InputField
                        name="supplementalId"
                        label="Plan Member ID"
                        required={this.state.editable}
                        value={wfSearchVO.supplementalId}
                        maxLength="15"
                        onChange={this.handlechange("supplementalId")}
                        onBlur={this.handleOnBlur}
                        disabled={this.state.editable}
                      />
                      <div className={classes.validationMessage} />
                    </div>

                    <div>
                      <InputField
                        name="applId"
                        label="Application Id"
                        required={this.state.editable}
                        value={wfSearchVO.applId}
                        maxLength="15"
                        onChange={this.handlechange("applId")}
                        onBlur={this.handleOnBlur}
                        disabled={this.state.editable}
                      />
                      <div className={classes.validationMessage} />
                    </div>

                    <div>
                      {/* <Select
                        components={components}
                        propertyName={wfCacheData.wfAssignedToUsers.filter(
                          (option) => option.value === wfSearchVO.assignedToUser
                        )}
                        options={wfCacheData.wfAssignedToUsers}
                        label="Assigned to User"
                        textFieldProps={{
                          id: "assignedToUser",
                          label: "Assigned to User",
                          InputLabelProps: {
                            className: classes.label,
                            shrink: true,
                          },
                        }}
                        className={classes.textFieldSelect}
                        handleChange={this.assignHandleChangeSelect(
                          "assignedToUser"
                        )}
                        classes={classes}
                        placeholder="Select"
                      /> */}

                      <AutoComplete1
                        options={wfCacheData.wfAssignedToUsers}
                        handleChange={this.handleChangeSearchSelectAuto}
                        defaultValue={wfCacheData.wfAssignedToUsers[0]}
                        value={
                          wfCacheData.wfAssignedToUsers.filter(
                            (data) => data.value === wfSearchVO.assignedToUser
                          )[0]
                        }
                        label="Assigned to User"
                        name="assignedToUser"
                        margin="0px"
                      />
                      <div className={classes.validationMessage} />
                    </div>

                    <div>
                      {/* <Select
                        components={components}
                        propertyName={wfCacheData.wfCaseStatuses.filter(
                          (option) => option.value === wfSearchVO.caseStatus
                        )}
                        options={wfCacheData.wfCaseStatuses}
                        label="Status"
                        textFieldProps={{
                          id: "caseStatus",
                          label: "Case Status",
                          InputLabelProps: {
                            className: classes.label,
                            shrink: true,
                          },
                        }}
                        className={classes.textFieldSelect}
                        handleChange={this.handleChangeSearchSelect(
                          "caseStatus"
                        )}
                        classes={classes}
                      /> */}
                      <AutoComplete1
                        options={wfCacheData.wfCaseStatuses}
                        handleChange={this.handleChangeSearchSelectAuto}
                        defaultValue={wfCacheData.wfCaseStatuses[0]}
                        value={
                          wfCacheData.wfCaseStatuses.filter(
                            (data) => data.value === wfSearchVO.caseStatus
                          )[0]
                        }
                        label="Case Status"
                        margin="0px"
                        name="caseStatus"
                      />{" "}
                      <div className={classes.validationMessage} />
                    </div>

                    <div>
                      {/* <Select
                        components={components}
                        propertyName={wfCacheData.wfCaseDesc.filter(
                          (option) => option.value === wfSearchVO.caseDesc
                        )}
                        options={wfCacheData.wfCaseDesc}
                        label="Status"
                        textFieldProps={{
                          id: "caseDesc",
                          label: "Case Desc",
                          InputLabelProps: {
                            className: classes.label,
                            shrink: true,
                          },
                        }}
                        width="200px"
                        className={classes.textFieldSelect}
                        handleChange={this.handleChangeSearchSelect("caseDesc")}
                        classes={classes}
                      /> */}
                      <AutoComplete1
                        options={wfCacheData.wfCaseDesc}
                        handleChange={this.handleChangeSearchSelectAuto}
                        defaultValue={wfCacheData.wfCaseDesc[0]}
                        value={
                          wfCacheData.wfCaseDesc.filter(
                            (data) => data.value === wfSearchVO.caseDesc
                          )[0]
                        }
                        label="Case Desc"
                        margin="0px"
                        width="180px"
                        name="caseDesc"
                      />
                      <div className={classes.validationMessage} />
                    </div>

                    <span
                      class="button-container-search"
                      style={{ marginTop: "17px", marginLeft: "20px" }}
                    >
                      <button class="btn btn-primary icon-search">
                        Search
                      </button>

                      <button class="btn btn-secondary" onClick={this.reset}>
                        Reset
                      </button>
                    </span>
                  </div>
                </form>
              </ExpansionPanel>
            </div>
          ) : null}

          <div class="search-panel">
            <div className={classes.container}>
              {this.props.wfCacheData &&
                this.props.wfCacheData.wfOptIn === "Y" ? (
                  <div className={classes.Select3}>
                    {/* <Select
                    components={components}
                    propertyName={fetchQueueDropDownValues.filter(
                      (option) => option.value === wfSearchVO.fetchSize
                    )}
                    options={fetchQueueDropDownValues}
                    label="Fetch Queue"
                    textFieldProps={{
                      id: "user",
                      label: " ",
                      InputLabelProps: {
                        className: classes.label,
                        shrink: true,
                      },
                    }}
                    className={classes.textFieldSelect}
                    handleChange={this.handleChangeSearchSelect("fetchSize")}
                    classes={classes}
                  /> */}

                    <AutoComplete1
                      options={fetchQueueDropDownValues}
                      handleChange={this.handleChangeSearchSelectAuto}
                      defaultValue={fetchQueueDropDownValues[0]}
                      value={
                        fetchQueueDropDownValues.filter(
                          (data) => data.value === wfSearchVO.fetchSize
                        )[0]
                      }
                      label=" "
                      marginTop="13px"
                      //margin='0px'

                      name="fetchSize"
                    />
                    <div className={classes.validationMessage}>
                      {this.state.validateFlag === true
                        ? this.validator.message(
                          "FetchCount",
                          [0, wfSearchVO.fetchSize],
                          "inpuRequired"
                        )
                        : null}
                    </div>
                  </div>
                ) : null}

              <span style={{ marginTop: "-38px" }}>
                <button
                  class="btn btn-secondary"
                  onClick={() => this.assignWork()}
                  disabled={
                    (this.state.searchFlag === true
                      ? this.state.wfSearchVO.assignedToUser ===
                        this.props.loginData.loginVo.userId
                        ? false
                        : true
                      : this.state.wfSearchVO.assignedToUser ===
                        this.props.loginData.loginVo.userId
                        ? true
                        : false) || isSupervisor === "N"
                      ? true
                      : false
                  }
                >
                  {this.props.wfCacheData &&
                    this.props.wfCacheData.wfOptIn === "Y"
                    ? "Assign Work"
                    : "Get Work"}
                </button>

                <span class="dashlet-refresh" onClick={this.refreshDashlets}>
                  <i
                    class="fa fa-refresh"
                    style={{
                      fontSize: 20,
                      color: "#389bb5",
                    }}
                    onClick={() => this.refreshDashlets}
                  ></i>
                  <span>Refresh Dashlets</span>
                </span>
              </span>
            </div>
          </div>

          <React.Fragment>
            <div
              onClick={() => {
                this.caseDatatable.current.scrollIntoView();
              }}
            >
              {this.props.searchResultsVo.dashletData && wfCacheData ? (
                <React.Fragment>
                  {this.props.isSupervisor === "S" ||
                    this.props.isSupervisor === "A" ? (
                      <Dashlet
                        compareFlag={compareFlag}
                        setCompareFlag={this.setCompareFlag}
                        data={searchResultsVo.dashletData}
                        openItems={this.openItems}
                        refreshDashlets={this.refreshDashlets}
                        supervisor={wfCacheData.supervisor}
                        supervisorTab={this.state.supervisorTab}
                      />
                    ) : (
                      <div style={{ textAlign: "center" }}>
                        <Dashlet
                          compareFlag={compareFlag}
                          setCompareFlag={this.setCompareFlag}
                          data={searchResultsVo.dashletData}
                          openItems={this.openItems}
                          refreshDashlets={this.refreshDashlets}
                          supervisor={wfCacheData.supervisor}
                          supervisorTab={this.state.supervisorTab}
                        />
                      </div>
                    )}
                </React.Fragment>
              ) : null}
            </div>
          </React.Fragment>
          <React.Fragment>
            <div className={classes.rootSubtabs}>
              <form>
                <div id="cases" ref={this.caseDatatable}>
                  <ExpansionPanel summary="Cases">
                    <div style={{ width: "100%" }}>
                      {caseData ? (
                        <CaseDataTable
                          search={this.state.search}
                          isSupervisor={this.state.isSupervisor}
                          data={caseData}
                          searchable={true}
                          header={CASES_HEADER}
                          rowsPerPage={this.state.rowsPerPage}
                          sortable={true}
                          clicked={this.caseSelectedRow}
                          index={this.state.caseSelectedIndex}
                          handleCheckBox={this.handleCheckBox}
                          disabledprop={this.state.updatecaseState}
                          SelectAllHandleCheckBox={this.SelectAllHandleCheckBox}
                          addComments={this.addComments}
                          exportAsExcel={true}
                          fileName="Document"
                          errorTable={
                            !isEmpty(caseData) &&
                              this.state.caseSelectedIndex &&
                              caseData[this.state.caseSelectedIndex]
                              ? caseData[this.state.caseSelectedIndex]
                                .riskInd === "Y"
                              : []
                          }
                          selectedValues={
                            caseData[this.state.caseSelectedIndex]
                          }
                          caseStatus={this.state.wfSearchVO.caseStatus}
                          assignedToUser={this.state.wfSearchVO.assignedToUser}
                          rowsPerPageOptions={[10, 15, 20]}
                          handleChangeRowsPerPage={this.handleChangeRowsPerPage}
                          nextPage={this.props.searchResultsVo.nextPage}
                          fetchMore={this.workflowSearchNextPage}
                          dateColumn={["caseDueDateFrmt", "caseDateFrmt"]}
                          flag={this.state.flag}
                          resetFlag={this.state.resetFlag}
                        />
                      ) : null}
                      {wfCacheData && !isEmpty(caseData) ? (
                        <div className={classes.workflowExpansion}>
                          {/* <Select
                            components={components}
                            propertyName={wfCacheData.wfCaseStatuses.filter(
                              (option) => option.value === updatecaseState
                            )}
                            options={wfCacheData.wfCaseStatuses}
                            label="Status"
                            textFieldProps={{
                              id: "updatecaseState",
                              // label: "Case Status",
                              InputLabelProps: {
                                className: classes.label,
                                shrink: true,
                              },
                            }}
                            className={classes.textFieldSelect}
                            handleChange={this.handleChangeSearchSelect(
                              "updatecaseState"
                            )}
                            classes={classes}
                          /> */}
                          <AutoComplete1
                            options={wfCacheData.wfCaseStatuses}
                            handleChange={this.handleChangeSearchSelectAuto}
                            defaultValue={wfCacheData.wfCaseStatuses[0]}
                            value={
                              wfCacheData.wfCaseStatuses.filter(
                                (data) => data.value === updatecaseState
                              )[0]
                            }
                            // label ='Case Status'
                            margin="0px"
                            marginTop="8px"
                            name="updatecaseState"
                          />
                          <Button
                            type="submit"
                            variant="contained"
                            color="primary"
                            onClick={this.updateCaseStatus}
                            disabled={
                              wfCacheData.isSupervisor === "A" ||
                                wfCacheData.isSupervisor === "S"
                                ? false
                                : (wfCacheData.isSupervisor === "U"
                                  ? wfSearchVO.assignedToUser !==
                                    this.props.loginData.loginVo.userId
                                    ? true
                                    : false
                                  : false) || updatecaseState === ""
                            }
                            className={classes.buttonworkflow}
                          >
                            Update Case Status
                          </Button>
                        </div>
                      ) : null}

                      {updatecaseState === "HOLD" ||
                        updatecaseState === "CLOSED" ||
                        updatecaseState === "OPEN" ? (
                          <div>
                            <TextField
                              id="outlined-textarea"
                              placeholder="Enter Comments (Max 255 characters)"
                              multiline
                              rows="2"
                              style={{
                                width: "85%",
                                marginBottom: "40px",
                                marginLeft: "35px",
                                color: "black !important",
                              }}
                              className={classes.textField}
                              inputProps={{ maxLength: 255 }}
                              onChange={this.Fieldchange}
                              onBlur={this.handleOnBlur}
                              value={this.state.comment}
                              margin="none"
                              variant="outlined"
                              required

                            // disabled={this.state.isNewSegment ? false : true}
                            />
                            <div className={classes.commentsValidationMessage}>
                              {this.validator.message(
                                "Comment",
                                [0, this.state.comment],
                                "inpuRequired"
                              )}
                            </div>
                          </div>
                        ) : null}
                    </div>
                  </ExpansionPanel>
                </div>

                <div id="activities">
                  <ExpansionPanel summary="Activities">
                    {!isEmpty(caseData) && searchResultsVo.activityData ? (
                      <DataTable
                        data={searchResultsVo.activityData}
                        header={ACTIVITIES_HEADER}
                        rowsPerPage={this.state.rowsPerPage}
                        sortableHeader={true}
                        clicked={this.activitySelectRow}
                        index={this.state.activitySelectedRow}
                        redirectName={this.state.redirectName}
                        updatedVal={this.updatedVal}
                        assignee={wfSearchVO.assignedToUser}
                        currentUser={this.props.loginData.loginVo.userId}
                        activityTable={this.state.activityTable}
                        searchFlag={this.state.searchFlag}
                      />
                    ) : null}
                  </ExpansionPanel>
                </div>
              </form>
            </div>
          </React.Fragment>
        </Paper>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    searchResultsVo: state.workflow.searchResultsVo,
    isLoading: state.spinner.isLoading,
    loginProfile: state.loginData.profiles,
    wfCacheData: state.workflow.wfCacheData,
    loginData: state.loginData,
    selectedMemberId: state.memberSearch.selectedMemberId,
    searchCriteriaVo: state.workflow.searchCriteriaVo,
    searchAttribute: state.memberSearch.searchAttributes
      ? state.memberSearch.searchAttributes.workflowSearch
      : null,
  };
};

const mapDispatchToProps = {
  searchWorkFlow,
  getActivities,
  assignWork,
  updateCase,
  searchApplication,
  fetchCacheData,
  refreshDashlets,
  updateAssignmentLimit,
  memberrowClickSearch,
  MemberSearch,
  setSelectedTab,
  addCaseComments,
  workflowSearchNextPage,
  resetMemberSearch,
  fetchWfCacheData,
  searchAttributes,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(withStyles(Styles)(WorkflowTabs)));
