import React from "react";
import { Styles } from "../../assets/styles/PopupTheme";
import { withStyles } from "@material-ui/core/styles";
import InputField from "../UI/InputField";

function FetchQueuePopup(props) {
  function update() {
    props.update();

    if (props.alertmsg === null) {
      props.close();
    }
  }

  const { classes, maxLimit, change, newVal, alertmsg, close } = props;
  return (
    <React.Fragment>
      <div className={classes.fetchcontainer}>
        <span className={classes.fetchstyle}>
          <InputField
            name="currentLimt"
            label="Current Assignment Limit"
            value={maxLimit}
            disabled
          />
          <span className={classes.tabmargin}>
            <InputField
              name="newLimit"
              label="New Assignment Limit"
              onChange={change}
              value={newVal}          
              maxLength="3"
            />
          </span>
          <div className={classes.fetchstyle1}>{alertmsg}</div>
        </span>

        <div className={classes.fetchbuttonconatiner}>
          <button class="btn btn-secondary" onClick={close}>
            Cancel
          </button>
          <button class="btn btn-secondary" onClick={update}>
            Update
          </button>
        </div>
      </div>
    </React.Fragment>
  );
}

export default withStyles(Styles)(FetchQueuePopup);
