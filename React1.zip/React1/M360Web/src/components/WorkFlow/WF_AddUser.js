import * as Type from "../../constants/ConfirmType";

import { ROLES } from "../../constants/staticData/supervisorData";
import React, { Component } from "react";
import {
  addWFuser,
  showUserDropdowns,
  getWFuserDetails,
  updatWFuserDetails,
} from "../../redux/actions/WorkflowActions";
import ConfirmBox from "../../utils/PopUp";
import ExpansionPanel from "../UI/ExpansionPanel";
import Modal from "../../components/UI/Modal/Modal";
import Paper from "@material-ui/core/Paper";
import AutoComplete1 from "../UI/Select";
import { Styles } from "../../assets/styles/Theme";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";
import { customValidations } from "../../utils/CustomValidations";
import SimpleReactValidator from "simple-react-validator";

class WF_AddUser extends Component {
  constructor(props) {
    super(props);
    this.state = {
      addVo: {
        role: "",
        userId: "",
        supervisorId: "",
      },
      showModal: "",
      message: "",
    };
    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
      },
    });
  }
  handleChangeSearchSelectAuto = async (data, name, targetVo) => {
    let value = data.value ? data.value.toUpperCase() : data.value;
    await this.setState((prevState) => ({
      ...prevState,
      [targetVo]: { ...prevState[targetVo], [name]: value },
    }));
  };
  handleRoleChange = async (data, name, targetVo) => {
    let value = data.value ? data.value.toUpperCase() : data.value;
    this.validator.hideMessages();
    await this.setState((prevState) => ({
      ...prevState,
      [targetVo]: {
        ...prevState[targetVo],
        [name]: value,
        userId: "",
        supervisorId: "",
      },
    }));
  };

  handleLabelChange = (name, targetVo) => (event) => {
    let value = event.target ? event.target.value.toUpperCase() : event.label;
    this.setState((prevState) => ({
      ...prevState,
      [targetVo]: { ...prevState[targetVo], [name]: value },
    }));
  };
  handleAddReset = () => {
    this.setState({ addVo: { role: "", userId: "", supervisorId: "" } });
    this.validator.hideMessages();
  };
  addUserSupervisor = () => {
    if (this.validator.allValid()) {
      ConfirmBox(this.confirmSave, Type.ADD, this.props);
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };
  confirmSave = async () => {
    let status = await this.props.addWFuser(this.state.addVo);
    if (status === "SUCCESS") {
      this.validator.hideMessages();
    }
    status = status === "SUCCESS" ? "Added successfully" : status;

    this.setState({
      showModal: true,
      message: status,
    });
    this.handleAddReset();
  };
  modalClosed = () => {
    this.setState({
      showModal: false,
    });
  };
  render() {
    this.validator.purgeFields();
    const {
      classes,
      newUserList,
      supervisorList,
      newSupervisorList,
      adminList,
    } = this.props;
    const { addVo, message, showModal } = this.state;
    return (
      <>
        <Paper
          elevation={0}
          className={classes.card}
          style={{ minHeight: "400px" }}
        >
          <Modal
            dialogTitle={"ADD/SHOW USER"}
            message={message}
            show={showModal}
            modalClosed={() => {
              this.modalClosed();
            }}
          ></Modal>
          <ExpansionPanel summary="Add User">
            <div class="panel-body">
              <div className={classes.container}>
                <div>
                  {/* <Select
                    components={components}
                    propertyName={ROLES.filter(
                      (option) => option.value === addVo.role
                    )}
                    id="role"
                    options={ROLES}
                    textFieldProps={{
                      label: "Role",
                      required: true,
                      InputLabelProps: {
                        className: classes.label,
                        shrink: true,
                      },
                    }}
                    className={classes.textFieldSelect}
                    width="180px"
                    handleChange={this.handleRoleChange("role", "addVo")}
                    classes={classes}
                  /> */}
                  <AutoComplete1
                    options={ROLES}
                    vo="addVo"
                    handleChange={this.handleRoleChange}
                    defaultValue={{ label: "Select", value: "" }}
                    value={ROLES.filter((data) => data.value === addVo.role)[0]}
                    label="Role"
                    margin="0px"
                    // width="220px"
                    name="role"
                  />
                  <div className={classes.validationMessage}>
                    {this.validator.message("role", addVo.role, "required")}
                  </div>
                </div>
                {addVo.role === "3" ? (
                  <>
                    <div>
                      {/* <Select
                        components={components}
                        propertyName={newUserList.filter(
                          (option) => option.value === addVo.userId
                        )}
                        id="userList"
                        options={newUserList}
                        textFieldProps={{
                          label: "User Name",
                          required: true,
                          InputLabelProps: {
                            className: classes.label,
                            shrink: true,
                          },
                        }}
                        className={classes.textFieldSelect}
                        width="180px"
                        handleChange={this.handlechange("userId", "addVo")}
                        classes={classes}
                      /> */}
                      <AutoComplete1
                        options={newUserList}
                        vo="addVo"
                        handleChange={this.handleChangeSearchSelectAuto}
                        defaultValue={{ label: "Select", value: "" }}
                        value={
                          newUserList.filter(
                            (data) => data.value === addVo.userId
                          )[0]
                        }
                        label="User Name"
                        margin="0px"
                        // width="220px"
                        name="userId"
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "User Name",
                          addVo.userId,
                          "required"
                        )}
                      </div>
                    </div>
                    <div>
                      {/* <Select
                        components={components}
                        propertyName={supervisorList.filter(
                          (option) => option.value === addVo.supervisorId
                        )}
                        id="supervisorId"
                        options={supervisorList}
                        textFieldProps={{
                          label: "Supervisor Name",
                          required: true,
                          InputLabelProps: {
                            className: classes.label,
                            shrink: true,
                          },
                        }}
                        className={classes.textFieldSelect}
                        width="180px"
                        handleChange={this.handlechange(
                          "supervisorId",
                          "addVo"
                        )}
                        classes={classes}
                      /> */}

                      <AutoComplete1
                        options={supervisorList}
                        vo="addVo"
                        handleChange={this.handleChangeSearchSelectAuto}
                        defaultValue={{ label: "Select", value: "" }}
                        value={
                          supervisorList.filter(
                            (data) => data.value === addVo.supervisorId
                          )[0]
                        }
                        label="Supervisor Name"
                        margin="0px"
                        // width="220px"
                        name="supervisorId"
                      />
                      <div className={classes.validationMessage}>
                        {addVo.role === "3" &&
                          this.validator.message(
                            "Supervisor Name",
                            addVo.supervisorId,
                            "required"
                          )}
                      </div>
                    </div>
                  </>
                ) : null}
                {addVo.role === "2" ? (
                  <>
                    <div className={classes.Select2}>
                      {/* <Select
                        components={components}
                        propertyName={newSupervisorList.filter(
                          (option) => option.value === addVo.userId
                        )}
                        id="supervisorList"
                        options={newSupervisorList}
                        textFieldProps={{
                          label: "Supervisor Name",

                          required: true,
                          InputLabelProps: {
                            className: classes.label,
                            shrink: true,
                          },
                        }}
                        className={classes.textFieldSelect}
                        width="180px"
                        handleChange={this.handlechange("userId", "addVo")}
                        classes={classes}
                      /> */}
                      <AutoComplete1
                        options={newSupervisorList}
                        vo="addVo"
                        handleChange={this.handleChangeSearchSelectAuto}
                        defaultValue={{ label: "Select", value: "" }}
                        value={
                          newSupervisorList.filter(
                            (data) => data.value === addVo.userId
                          )[0]
                        }
                        label="Supervisor Name"
                        margin="0px"
                        // width="220px"
                        name="userId"
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "Supervisor Name",
                          addVo.userId,
                          "required"
                        )}
                      </div>
                    </div>
                    <div className={classes.Select2}>
                      {/* <Select
                        components={components}
                        propertyName={adminList.filter(
                          (option) => option.value === addVo.supervisorId
                        )}
                        id="adminId"
                        options={adminList}
                        textFieldProps={{
                          label: "Admin Name",
                          required: true,
                          InputLabelProps: {
                            className: classes.label,
                            shrink: true,
                          },
                        }}
                        className={classes.textFieldSelect}
                        width="180px"
                        handleChange={this.handlechange(
                          "supervisorId",
                          "addVo"
                        )}
                        classes={classes}
                      /> */}
                      <AutoComplete1
                        options={adminList}
                        vo="addVo"
                        handleChange={this.handleChangeSearchSelectAuto}
                        defaultValue={{ label: "Select", value: "" }}
                        value={
                          adminList.filter(
                            (data) => data.value === addVo.supervisorId
                          )[0]
                        }
                        label="Admin Name"
                        margin="0px"
                        // width="220px"
                        name="supervisorId"
                      />
                      <div className={classes.validationMessage}>
                        {addVo.role === "3" ||
                          (addVo.role === "2" &&
                            this.validator.message(
                              "Admin Name",
                              addVo.supervisorId,
                              "required"
                            ))}
                      </div>
                    </div>
                  </>
                ) : null}

                <span
                  class="button-container-search"
                  className={classes.buttonContainerSearch}
                >
                  <button
                    id="search"
                    class="btn btn-primary "
                    onClick={this.addUserSupervisor}
                  >
                    ADD
                  </button>
                  <button
                    id="reset"
                    class="btn btn-secondary"
                    onClick={this.handleAddReset}
                  >
                    Reset
                  </button>
                </span>
              </div>
            </div>
          </ExpansionPanel>
        </Paper>
      </>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    newUserList: state.workflow.newUserList,
    supervisorList: state.workflow.supervisorList,
    newSupervisorList: state.workflow.newSupervisorList,
    adminList: state.workflow.adminList,
    workflowUserDetails: state.workflow.workflowUserDetails,
  };
};

const mapDispatchToProps = {
  addWFuser,
  showUserDropdowns,
  getWFuserDetails,
  updatWFuserDetails,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(WF_AddUser));
