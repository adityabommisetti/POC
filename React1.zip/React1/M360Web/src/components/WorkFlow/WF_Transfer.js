import React, { Component } from "react";
import { Styles } from "../../assets/styles/Theme";
import { withStyles } from "@material-ui/core/styles";
import InputField from "../UI/InputField";
import AutoComplete1 from "../UI/Select";
import { connect } from "react-redux";
import Button from "@material-ui/core/Button";
import * as ActionTypes from "../../redux/types/ActionType";
import * as URL from "../../services/API_URL";
import { postRequest } from "../../redux/actions/WorkflowActions";
import Modal from "../../components/UI/Modal/Modal";
import { validationRules } from "../../utils/ValidationRules";
import SimpleReactValidator from "simple-react-validator";
import TextField from "@material-ui/core/TextField";
import ConfirmBox from "../../utils/PopUp";
import Dialog from "@material-ui/core/Dialog";
import DialogContent from "@material-ui/core/DialogContent";
import DialogTitle from "@material-ui/core/DialogTitle";

class TransferPopup extends Component {
  constructor(props) {
    super(props);
    this.state = {
      transferToUser: "",
      transferComment: "",
      showModal: false,
      modalMessage: "",
      toUser: this.props.toUser.filter((x) => x.value !== this.props.fromUser),
      AdminSupUser: this.props.toUser,
      open: false,
    };
    this.validator = new SimpleReactValidator({ validationRules });
  }
  handleReset = () => {
    this.setState({ transferToUser: "", transferComment: "" });
  };

  handleClean = () => {
    this.handleReset();
    this.validator.hideMessages();
    this.props.handleClear();
  };

  handleSelectChange = (name) => (event) => {
    let value = event.value.toUpperCase();
    this.setState((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  handleChange = (event) => {
    event.persist();
    this.setState((prevState) => ({
      ...prevState,
      [event.target.name]: event.target.value,
    }));
  };

  handleOnBlur = (event) => {
    event.persist();
    this.setState((prevState) => ({
      ...prevState,
      [event.target.name]: event.target.value,
    }));
  };

  modalClosed = () => {
    this.setState({ showModal: false });
    this.props.handleClose();
  };

  handleSubmit = (e) => {
    e.preventDefault();

    if (this.validator.allValid()) {
      this.props.handleClose();
      const { transferAll, transferSelected } = this.props;
      const text = transferAll
        ? "all the cases?"
        : transferSelected
        ? "selected cases?"
        : "case?";
      ConfirmBox(
        this.confirmUpdateTransfer,
        `Are you sure you want to transfer ${text}`,
        this.props,
        this.handleClean
      );
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  confirmUpdateTransfer = async () => {
    const { transferComment, transferToUser } = this.state;
    const {
      transferAll,
      transferSelected,
      data,
      selectedRow,
      fromUser,
    } = this.props;
    const caseData = transferAll
      ? data
      : transferSelected
      ? data.filter((x) => x.checked === "Y")
      : [data[selectedRow]];

    const body = {
      caseData: caseData,
      fromUserId: fromUser,
      toUserId: transferToUser,
      comment: transferComment,
    };
    const status = await this.props.postRequest(
      URL.TRANSFER_CASE,
      body,
      ActionTypes.WORKFLOW_SEARCH
    );
    this.setState({
      showModal: true,
      modalMessage: status,
    });
    this.handleClean();
  };
  render() {
    const { classes, open, handleClose, Name, wfCacheData } = this.props;
    const {
      transferToUser,
      transferComment,
      modalMessage,
      showModal,
      toUser,
      AdminSupUser,
    } = this.state;
    return (
      <>
        <Modal
          dialogTitle={"WorkFlow"}
          message={modalMessage}
          show={showModal}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Dialog
          open={open}
          onClose={() => {
            handleClose();
            this.handleReset();
            this.validator.hideMessages();
          }}
        >
          <DialogTitle>
            Transfer the work item from one user to another
          </DialogTitle>
          <DialogContent>
            <form onSubmit={this.handleSubmit}>
              <div>
                <span>
                  <InputField
                    required
                    label="Transfer By"
                    disabled
                    value={Name}
                  />
                </span>
                <br />
                <span>
                  {/* <Select
                    components={components}
                    propertyName={
                      wfCacheData &&
                      (wfCacheData.supervisor === "S" ||
                        wfCacheData.supervisor === "A")
                        ? AdminSupUser.filter(
                            (option) => option.value === transferToUser
                          )
                        : toUser.filter(
                            (option) => option.value === transferToUser
                          )
                    }
                    options={
                      wfCacheData &&
                      (wfCacheData.supervisor === "S" ||
                        wfCacheData.supervisor === "A")
                        ? AdminSupUser
                        : toUser
                    }
                    label="Fetch Queue"
                    textFieldProps={{
                      id: "user",
                      required: true,
                      label: "To User",
                      InputLabelProps: {
                        className: classes.label,
                        shrink: true,
                      },
                    }}
                    className={classes.textFieldSelect}
                    handleChange={this.handleSelectChange("transferToUser")}
                    classes={classes}
                  /> */}
                  <AutoComplete1
                    options={
                      wfCacheData &&
                      (wfCacheData.supervisor === "S" ||
                        wfCacheData.supervisor === "A")
                        ? AdminSupUser
                        : toUser
                    }
                    margin="0px"
                    //fontSize="0.718em"
                    handleChange={this.handleSelectChange("transferToUser")}
                    defaultValue={{
                      label: "Select",
                      value: "",
                    }}
                    value={transferToUser}
                    label="To User"
                    name="user"
                  />
                </span>
                <br />
                {this.validator.message(
                  " To User",
                  transferToUser,
                  "required"
                ) && (
                  <>
                    <span className={classes.transferValidation}>
                      {this.validator.message(
                        " To User",
                        transferToUser,
                        "required"
                      )}
                    </span>
                    <br />
                  </>
                )}
                <span>
                  <label>Comment to document</label>
                </span>
                <span class="imp">*</span>
                <br />
                <TextField
                  placeholder="Enter Comments (Max 255 characters)"
                  multiline
                  rows="2"
                  style={{
                    width: "400px",
                  }}
                  inputProps={{ maxLength: 255 }}
                  onChange={(e) => this.handleChange(e)}
                  onBlur={this.handleOnBlur}
                  value={transferComment}
                  margin="none"
                  name="transferComment"
                  variant="outlined"
                />
                <br />
                <span className={classes.transferValidation}>
                  {this.validator.message(
                    "Comment",
                    transferComment,
                    "required"
                  )}
                </span>
              </div>
              <div className={classes.buttonContainer}>
                <Button variant="contained" color="primary" type="submit">
                  Update
                </Button>
                <Button
                  autoFocus
                  onClick={() => {
                    handleClose();
                    this.handleClean();
                  }}
                  variant="contained"
                  color="primary"
                >
                  Cancel
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    searchResultsVo: state.workflow.searchResultsVo,
    fromUser: state.loginData.loginVo.userId,
    Name: state.loginData.loginVo.firstName,
    toUser: state.workflow.wfCacheData.wfAssignedToUsers,
    wfCacheData: state.workflow.wfCacheData,
  };
};

const mapDispatchToProps = {
  postRequest,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(TransferPopup));
