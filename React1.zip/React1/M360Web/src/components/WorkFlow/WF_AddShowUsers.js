import React from "react";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Tabs from "@material-ui/core/Tabs";

import Tab from "@material-ui/core/Tab";
import WFAddUser from "./WF_AddUser";
import WFShowUsers from "./WF_ShowUsers";
import { connect } from "react-redux";
import { showUserDropdowns } from "../../redux/actions/WorkflowActions";

function LinkTab(props) {
  return (
    <Tab component="a" onClick={event => event.preventDefault()} {...props} />
  );
}

const styles = theme => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper
  },
  bigIndicator: {
    height: 2,
    backgroundColor: "white"
  }
});

class WF_AddShowUser extends React.Component {
  state = {
    value: 0
  };

  handleChange = (event, value) => {
    this.setState({ value });
  };

  // handleOnBlur = (event, value) => {
  //   this.setState({ value }.trim());
  // };

  async componentDidMount() {
    await this.props.showUserDropdowns();
    
  }
  render() {
    const { classes } = this.props;
    const { value } = this.state;

    return (
      <>
        <AppBar position="static">
          <Tabs
            variant="fullWidth"
            value={value}
            onChange={this.handleChange}
            onBlur={this.handleOnBlur}
            classes={{ indicator: classes.bigIndicator }}
          >
            <LinkTab label="Show Users" href="page1" />
            <LinkTab label="Add User" href="page2" />
          </Tabs>
        </AppBar>
        {value === 0 && <WFShowUsers />}
        {value === 1 && <WFAddUser />}
      </>
    );
  }
}

WF_AddShowUser.propTypes = {
  classes: PropTypes.object.isRequired
};
const mapDispatchToProps = {
  showUserDropdowns
};
export default connect(
  null,
  mapDispatchToProps
)(withStyles(styles)(WF_AddShowUser));
