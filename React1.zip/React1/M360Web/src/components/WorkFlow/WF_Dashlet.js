import React from "react";
import { useState, useEffect } from "react";

const Dashlet = React.memo((props) => {
  if (!props.data) {
    return;
  }

  const [index1, setIndex1] = useState(-1);
  const [index2, setIndex2] = useState(-1);

  useEffect(() => {
    if (props.compareFlag === true) {
      setIndex1();
      setIndex2();
      props.setCompareFlag(false);
    }
  }, [props]);

  const supervisorOpenitems = (
    listItemStatus,
    listStatus,
    itemQueueName,
    i,
    j
  ) => {
    if (j === -2) {
      props.supervisorOpenitems(listItemStatus);
      setIndex1(i);
      setIndex2(j);
    } else {
      props.supervisorOpenitems(listItemStatus, listStatus, itemQueueName);

      setIndex1(i);
      setIndex2(j);
    }
  };

  const openItems = (listItemStatus, listStatus, itemQueueName, i, j) => {
    if (j === -2) {
      props.openItems(listItemStatus);
      setIndex1(i);
      setIndex2(j);
    } else {
      props.openItems(listItemStatus, listStatus, itemQueueName);

      setIndex1(i);
      setIndex2(j);
    }
  };
  return props.data.map((listitem, i) => {
    {
      console.log(props.manualpopupItems);
    }
    return (
      <div class="dashlet" key={i + "listitem"} style={{ paddingLeft: "5px" }}>
        <i
          class={
            listitem.status !== "MANUAL POPUP"
              ? "d-icon icon-list-bullet"
              : "d-icon2 icon-cancel-circled"
          }
          onClick={() =>
            listitem.status === "MANUAL POPUP"
              ? props.DeleteAllItems(listitem)
              : null
          }
        ></i>
        <span
          style={
            index1 === i && index2 === -2
              ? {
                  boxShadow: "2px 2px 5px 2px ",
                  width: "145px",
                }
              : {}
          }
          class="dashlet-val"
          onClick={() =>
            props.supervisorTab === false
              ? openItems(listitem.status, "", "", i, -2)
              : null
          }
        >
          {listitem.status}: {listitem.count}
        </span>
        {listitem.subItems != null &&
          listitem.subItems.map((item, j) => {
            return (
              <React.Fragment>
                <div
                  class={
                    props.supervisorTab === true && item.hasAccess == false
                      ? "dashlet-val-hasaccess"
                      : "dashlet-val"
                  }
                  key={j + "subitems"}
                  style={
                    props.supervisorTab === false
                      ? index1 === i && index2 === j
                        ? {
                            paddingLeft: "5px",
                            boxShadow: "2px 2px 5px 2px ",
                          }
                        : { paddingLeft: "5px" }
                      : props.supervisorTab === true &&
                        item.manualPopup === true
                      ? { cursor: "pointer" }
                      : props.supervisorTab === true &&
                        item.manualPopup === false
                      ? { paddingLeft: "15px", cursor: "auto" }
                      : null
                  }
                >
                  {props.supervisorTab === true ? (
                    <i
                      class={
                        item.manualPopup === true
                          ? "d-icon2 icon-cancel-circled"
                          : null
                      }
                      onClick={() =>
                        props.supervisorTab === false
                          ? null
                          : supervisorOpenitems(
                              listitem.status,
                              item.status,
                              item.queueName,
                              i,
                              j
                            )
                      }
                      title="Click Here to Delete the Queue"
                    ></i>
                  ) : null}
                  <span
                    onClick={() =>
                      props.supervisorTab === false
                        ? openItems(
                            listitem.status,
                            item.status,
                            item.queueName,
                            i,
                            j
                          )
                        : supervisorOpenitems(
                            listitem.status,
                            item.status,
                            item.queueName,
                            i,
                            j
                          )
                    }
                    title={
                      props.supervisorTab === true && item.manualPopup === true
                        ? "Click Here to Delete the Queue"
                        : null
                    }
                  >
                    {item.status} : {item.count}
                  </span>
                </div>
              </React.Fragment>
            );
          })}
      </div>
    );
  });
});

export default Dashlet;
