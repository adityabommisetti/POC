import Button from "@material-ui/core/Button";
import Paper from "@material-ui/core/Paper";

import React from "react";
import { connect } from "react-redux";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import RadioButtonCheckedIcon from "@material-ui/icons/RadioButtonChecked";
import RadioButtonUncheckedIcon from "@material-ui/icons/RadioButtonUnchecked";
import { priorityUpdateStatus } from "../../redux/actions/WorkflowActions";
import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormLabel from "@material-ui/core/FormLabel";

import AutoComplete1 from "../UI/Select";
import * as DateUtil from "../../utils/DatePicker";
import isEmpty from "lodash/isEmpty";
const dateChk = {};

class PriorityPopup extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      prty1QueCd: this.props.selectedValues.prtyOne,
      prty2QueCd: this.props.selectedValues.prtyTwo,
      prty3QueCd: this.props.selectedValues.prtyThree,
      prty4QueCd: this.props.selectedValues.prtyFour,
      userConfFlag: "N",
    };
  }

  componentDidMount = async () => {
    await this.setState({
      prty1QueCd: this.props.selectedValues.prtyOne,
      prty2QueCd: this.props.selectedValues.prtyTwo,
      prty3QueCd: this.props.selectedValues.prtyThree,
      prty4QueCd: this.props.selectedValues.prtyFour,
    });
  };

  updateSupervisorPriority = () => {
    this.props.close();
    let prtold1 = "";
    let prtold2 = "";
    let prtold3 = "";
    let prtold4 = "";
    let prt1 = "";
    let prt2 = "";
    let prt3 = "";
    let prt4 = "";
    let prtFlag = false;
  

    if (!isEmpty(this.props.wfCacheData.queueList)) {
      let queueList = this.props.wfCacheData.queueList;
      let selectedValues = this.props.selectedValues;

      for (let i = 0; i < queueList.length; i++) {
        if (selectedValues.prtyOne === queueList[i].label) {
          prtold1 = queueList[i].value;
        }
        if (selectedValues.prtyTwo === queueList[i].label) {
          prtold2 = queueList[i].value;
        }
        if (selectedValues.prtyThree === queueList[i].label) {
          prtold3 = queueList[i].value;
        }
        if (selectedValues.prtyFour === queueList[i].label) {
          prtold4 = queueList[i].value;
        }
        if (this.state.prty1QueCd === queueList[i].label) {
          prt1 = queueList[i].value;
        }
        if (this.state.prty2QueCd === queueList[i].label) {
          prt2 = queueList[i].value;
        }
        if (this.state.prty3QueCd === queueList[i].label) {
          prt3 = queueList[i].value;
        }
        if (this.state.prty4QueCd === queueList[i].label) {
          prt4 = queueList[i].value;
        }
      }
    }

    let mySet = new Set([prt1, prt2, prt3, prt4]);
    let priority = [prt1, prt2, prt3, prt4];
    function getOccurrence(array, value) {
      if (value !== "") {
        var count = 0;
        array.forEach((v) => v === value && count++);
        return count;
      } else {
        count = 1;
        return count;
      }
    }

    let pr1Count = getOccurrence(priority, prt1);
    let pr2Count = getOccurrence(priority, prt2);
    let pr3Count = getOccurrence(priority, prt3);
    let pr4Count = getOccurrence(priority, prt4);
    let payload = {
      userIdSearch: this.props.userId,
      userId: this.props.selectedValues.userId,
      queAsgnOld: {
        prty1QueCd: prtold1,
        prty2QueCd: prtold2,
        prty3QueCd: prtold3,
        prty4QueCd: prtold4,
      },
      queAsgnNew: {
        prty1QueCd: prt1,
        prty2QueCd: prt2,
        prty3QueCd: prt3,
        prty4QueCd: prt4,
      },
      userConfFlag: this.state.userConfFlag,
    };
    if (mySet.size < 4) {
      priority.map((prty, i) => {
        if (prty !== "") {
          prtFlag = true;
        }
        return prtFlag;
      });
      if (
        prtFlag &&
        pr1Count < 2 &&
        pr2Count < 2 &&
        pr3Count < 2 &&
        pr4Count < 2
      ) {
        this.props.updatePriority(payload);
      } else {
        alert("Priorities should not be same");
      }
    } else {
      this.props.updatePriority(payload);
    }
  };

  handleChangeSearchSelectAuto = async (data, name) => {
    let label = data.label; //event.label ? event.label : event.target.label;

    await this.setState((prevState) => ({
      ...prevState,
      [name]: label,
    }));

    // this.setState((prevState) => ({
    //   ...prevState,
    //   [name]: label,
    // }));
  };

  handleDates = (fieldId) => {
    var self = this;
    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        if (
          dateChk.name !== e.target.name ||
          dateChk.value !== e.target.value
        ) {
          self.setDate(e.target.name, e.target.value);
          document.getElementById(fieldId.substr(1)).focus();
        }
        dateChk.name = e.target.name;
        dateChk.value = e.target.value;
      });
  };

  setDate = (name, value) => {
    this.setState((prevState) => ({
      ...prevState,

      [name]: value,
    }));
  };

  handleDateChange = (name) => (event) => {
    let value = event.target ? event.target.value : event.value;
    value = value.replace(/[^0-9]/g, "").trim();
    if (value.length === 8) {
      value = value.replace(/^(\d{2})/, "$1/");
      value = value.replace(/\/(\d{2})/, "/$1/");
      value = value.replace(/(\d)\/(\d{4}).*/, "$1/$2");
    }

    this.setState((prevState) => ({
      ...prevState,

      [name]: value,
    }));
  };

  handlechange = (name) => (event) => {
    let value = event.target
      ? event.target.value.toUpperCase()
      : event.value.toUpperCase();
    this.setState((prevState) => ({
      ...prevState,

      [name]: value,
    }));
  };

  render() {
    const { classes, wfCacheData } = this.props;
    return (
      <React.Fragment>
        <Paper
          className={classes.root}
          elevation={0}
          style={{ padding: "15px" }}
        >
          <div className={classes.container}>
            <div style={{ width: "245px" }}>
              {/* <Select
                components={components}
                propertyName={wfCacheData.queueList.filter(
                  (option) => option.label === this.state.prty1QueCd
                )}
                options={wfCacheData.queueList}
                label="Priority1"
                textFieldProps={{
                  id: "user",
                  label: "Priority1",
                  InputLabelProps: {
                    className: classes.label,
                    shrink: true,
                  },
                }}
                className={classes.textFieldSelect}
                handleChange={this.handleChangeSearchSelect("prty1QueCd")}
                classes={classes}
                width="220px"
              /> */}
              <AutoComplete1
                options={wfCacheData.queueList}
                handleChange={this.handleChangeSearchSelectAuto}
                defaultValue={wfCacheData.queueList[0]}
                value={
                  wfCacheData.queueList.filter(
                    (data) => data.label === this.state.prty1QueCd
                  )[0]
                }
                label="Priority1"
                //margin='0px'
                name="prty1QueCd"
                width="220px"
              />
              <div className={classes.validationMessage} />
            </div>
            <div style={{ width: "245px" }}>
              {/* <Select
                components={components}
                propertyName={wfCacheData.queueList.filter(
                  (option) => option.label === this.state.prty2QueCd
                )}
                options={.
                }
                label="Priority 2"
                textFieldProps={{
                  id: "user",
                  label: "Priority2",
                  InputLabelProps: {
                    className: classes.label,
                    shrink: true,
                  },
                }}
                className={classes.textFieldSelect}
                handleChange={this.handleChangeSearchSelect("prty2QueCd")}
                classes={classes}
                width="220px"
              /> */}
              <AutoComplete1
                options={wfCacheData.queueList}
                handleChange={this.handleChangeSearchSelectAuto}
                defaultValue={wfCacheData.queueList[0]}
                value={
                  wfCacheData.queueList.filter(
                    (data) => data.label === this.state.prty2QueCd
                  )[0]
                }
                label="Priority 2"
                //margin='0px'
                name="prty2QueCd"
                width="220px"
              />
              <div className={classes.validationMessage} />
            </div>

            <div style={{ width: "245px" }}>
              {/* <Select
                components={components}
                propertyName={wfCacheData.queueList.filter(
                  (option) => option.label === this.state.prty3QueCd
                )}
                options={wfCacheData.queueList}
                label="Priority3"
                textFieldProps={{
                  id: "user",
                  label: "Priority 3",
                  InputLabelProps: {
                    className: classes.label,
                    shrink: true,
                  },
                }}
                className={classes.textFieldSelect}
                handleChange={this.handleChangeSearchSelect("prty3QueCd")}
                classes={classes}
                width="220px"
              /> */}

              <AutoComplete1
                options={wfCacheData.queueList}
                handleChange={this.handleChangeSearchSelectAuto}
                defaultValue={wfCacheData.queueList[0]}
                value={
                  wfCacheData.queueList.filter(
                    (data) => data.label === this.state.prty3QueCd
                  )[0]
                }
                label="Case Status"
                //margin='0px'
                width="220px"
                name="prty3QueCd"
              />
              <div className={classes.validationMessage} />
            </div>

            <div style={{ width: "245px" }}>
              {/* <Select
                components={components}
                propertyName={wfCacheData.queueList.filter(
                  (option) => option.label === this.state.prty4QueCd
                )}
                options={wfCacheData.queueList}
                label="Priority 4"
                textFieldProps={{
                  id: "user",
                  label: "Priority4",
                  InputLabelProps: {
                    className: classes.label,
                    shrink: true,
                  },
                }}
                className={classes.textFieldSelect}
                handleChange={this.handleChangeSearchSelect("prty4QueCd")}
                classes={classes}
                width="220px"
              /> */}
              <AutoComplete1
                options={wfCacheData.queueList}
                handleChange={this.handleChangeSearchSelectAuto}
                defaultValue={wfCacheData.queueList[0]}
                value={
                  wfCacheData.queueList.filter(
                    (data) => data.label === this.state.prty4QueCd
                  )[0]
                }
                label="Case Status"
                //margin='0px'
                width="220px"
                name="prty4QueCd"
              />
              <div className={classes.validationMessage} />
            </div>
            <FormControl component="fieldset" className={classes.formControl}>
              <FormLabel component="legend" className={classes.legend}>
                Do you want to unassign/Transfer the cases? &nbsp;
                <RadioGroup
                  aria-label="Dialysis"
                  name="Dialysis"
                  className={classes.group}
                  value={this.state.userConfFlag}
                  onChange={this.handlechange("userConfFlag")}
                >
                  <FormControlLabel
                    value="Y"
                    control={
                      <Radio
                        color="primary"
                        // disabled={originalApplication}
                        icon={<RadioButtonUncheckedIcon fontSize="small" />}
                        checkedIcon={
                          <RadioButtonCheckedIcon fontSize="small" />
                        }
                      />
                    }
                    label="Yes"
                  />
                  <FormControlLabel
                    value="N"
                    control={
                      <Radio
                        color="primary"
                        // disabled={originalApplication}
                        icon={<RadioButtonUncheckedIcon fontSize="small" />}
                        checkedIcon={
                          <RadioButtonCheckedIcon fontSize="small" />
                        }
                      />
                    }
                    label="No"
                  />
                </RadioGroup>
              </FormLabel>
            </FormControl>

            <div className={classes.buttonformat}>
              <Button
                variant="contained"
                color="primary"
                onClick={this.updateSupervisorPriority}
                className={classes.buttonworkflow}
              >
                Update
              </Button>

              <Button
                variant="contained"
                color="primary"
                onClick={this.props.close}
                className={classes.buttonworkflow}
              >
                Close
              </Button>
            </div>
          </div>
        </Paper>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    wfCacheData: state.workflow.wfCacheData,
    loginData: state.loginData,
  };
};
const mapDispatchToProps = {
  priorityUpdateStatus,
};
export default connect(mapStateToProps, mapDispatchToProps)(PriorityPopup);
