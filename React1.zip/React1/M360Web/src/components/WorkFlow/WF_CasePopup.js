import DataTable from "../Home/DataTable";
import Paper from "@material-ui/core/Paper";
import React from "react";
import {
  getCaseDataComments,
  addCaseComments,
} from "../../redux/actions/WorkflowActions";
import { Styles } from "../../assets/styles/PopupTheme";
import { connect } from "react-redux";
import { CASE_HEADER as header } from "../../constants/Headers/WorkFlowHeaders";
import { withStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import classNames from "classnames";

class CaseDataPopup extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedIndex: 0,
      page: 0,
      data: this.props.caseComments ? this.props.caseComments : [],
      comment: "",
      isNewSegment: false,
    };
  }

  async componentDidMount() {
    await this.props.getCaseDataComments(this.props.selectedValues);
    this.setState({ data: this.props.caseComments });
  }

  Fieldchange = (e) => {
    this.setState({ comment: e.target.value});
  };

  addComment = async () => {
    this.setState({ isNewSegment: true });
  };

  submitComment = async () => {
    let payload = {
      primaryId:
        this.props.selectedValues.source.toUpperCase() === "APPLICATION"
          ? this.props.selectedValues.appId
          : this.props.selectedValues.mbrId,
      comments: this.state.comment,
      caseId: this.props.selectedValues.caseId,
      source: this.props.selectedValues.source,
    };

    if (this.state.comment !== "") {
      this.props.close();
      this.props.addComments(payload);

      this.setState({
        data: this.props.caseComments,
        isNewSegment: false,
        comment: "",
      });
    } else {
      alert("Please enter comment");
    }
  };

  onRowSelect = (index, page) => {
    this.setState({
      selectedIndex: index,
      page: page,
    });
  };
  render() {
    const { classes } = this.props;
    return (
      <React.Fragment>
        <Paper
          className={classes.root}
          elevation={0}
          style={{ padding: "15px" }}
        >
          <div className={classes.table}>
            <DataTable
              data={this.props.caseComments}
              header={header}
              rowsPerPage={3}
              clicked={this.onRowSelect}
              index={this.state.selectedIndex}
              pageNo={this.state.page}
            />
          </div>
          <br />
          {this.state.isNewSegment ? (
            <div>
              <TextField
                id="outlined-textarea"
                placeholder="Enter Comments (Max 255 characters)"
                multiline
                rows="2"
                style={{
                  width: "85%",
                  marginBottom: "40px",
                  marginLeft: "35px",
                  color: "black !important",
                }}
                className={classes.textField}
                inputProps={{ maxLength: 255 }}
                onChange={(e) => this.Fieldchange(e)}
                value={this.state.comment}
                margin="none"
                variant="outlined"
                // disabled={this.state.isNewSegment ? false : true}
              />
              <div className={classes.commentsValidationMessage} />
            </div>
          ) : null}

          <div className={classes.buttonContainer} style={{ float: "right" }}>
            <Button
              variant="contained"
              color="primary"
              onClick={this.addComment}
              className={classes.buttonworkflow}
              disabled={this.state.comment !== ""}
            >
              Add Comment
            </Button>

            <Button
              variant="contained"
              color="primary"
              onClick={this.submitComment}
              className={classes.buttonworkflow}
              disabled={!this.state.isNewSegment}
            >
              Submit
            </Button>

            <i
              style={{ fontSize: "25px", marginLeft: "5px", color: "black" }}
              className={classNames("fa fa-times")}
              onClick={this.props.close}
            />
          </div>
        </Paper>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    caseComments: state.workflow.caseComments,
  };
};
const mapDispatchToProps = {
  getCaseDataComments,
  addCaseComments,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(CaseDataPopup));
