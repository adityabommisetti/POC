import * as Type from "../../constants/ConfirmType";

import React, { Component } from "react";
import AutoComplete1 from "../UI/Select";
import {
  TIMER_SOURCE_HEADER,
  TIMER_SOURCE_TRIGGER_STATUS,
} from "../../constants/SelectStaticData";
import {
  timerGetDetails,
  timerUpdate,
  getTimerType,
  resetTimerData,
  SearchNextPage
} from "../../redux/actions/TimerActions";
import isEmpty from "lodash/isEmpty";
import Button from "@material-ui/core/Button";
import ConfirmBox from "../../utils/PopUp";
import DataTable from "./TimersTable";
import ExpansionPanel from "../UI/ExpansionPanel";
import InputField from "../UI/InputField";
import Modal from "../../components/UI/Modal/Modal";
import Paper from "@material-ui/core/Paper";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../assets/styles/Theme";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";
import {
  resetMemberSearch,
  searchAttributes,
} from "../../redux/actions/MemberActions";
import { TIMER_TABLE_HEADER as header } from "../../constants/Headers/TimerHeader";

const INITIAL_STATE = {
  activationTime: "",
  creationTime: "",
  customerId: "",
  editActivationDateStatus: null,
  history: "",
  lastUpdtTime: "",
  lastUpdtUserId: "",
  pbpId: "",
  planDesignation: "",
  planId: "",
  primaryId: "",
  sourceType: "",
  status: "",
  triggerCode: "",
  trgSource: "",
  triggerType: "",
  visible: false,
  index: 0,
};

class Timers extends Component {
  state = {
    rowsPerPageOptions: [10, 15, 20],
    timersVO: this.props.getTimerData[0]
      ? this.props.getTimerData[0]
      : { ...INITIAL_STATE }, //selected Row
    timersOldVO: this.props.getTimerData[0]
      ? this.props.getTimerData[0]
      : { ...INITIAL_STATE },
    data: this.props.getTimerData
      ? this.props.getTimerData
      : { ...INITIAL_STATE }, //List of Vo
    modified: false,
    isNewSegment: false,
    editable: false,
    selectedindex: 0,
    updatedValue: "",
    message: null,
    closePopup: false,
    updateFlag: true,
    searchFlag: false,
    search1: true,
    searchVo: {
      searchType: this.props.searchAttribute
        ? this.props.searchAttribute.searchType
        : "",
      searchId: this.props.searchAttribute
        ? this.props.searchAttribute.searchId
        : "",
      status: this.props.searchAttribute
        ? this.props.searchAttribute.status
        : "",
      triggerCode: this.props.searchAttribute
        ? this.props.searchAttribute.triggerCode
        : "",
    },
    rowsPerPage: 10,
    mbridLit: [],
    resetFlag: true
  };
  constructor(props) {
    super(props);
    this.validator = new SimpleReactValidator();
  }

  selectRow = (index) => {
    this.setState({ selectedindex: index });
    const data = [...this.state.data];
    const selectedVo = data[index];
    this.setState(() => ({
      timersVO: { ...selectedVo }, // copy data
      timersOldVO: { ...selectedVo }, //copy data immutable
      editable: false, // readOnly
      isNewSegment: false, //Not a new SEgment
      modified: false,
      index: index, // Disabled update
      updateFlag: true,
    }));
  };

  handlechange = (name) => (event) => {
    let value = event.target.value;
    this.setState(
      (prevState) => ({
        searchVo: {
          ...prevState.searchVo,
          [name]: value,
        },
        modified: true, // enable update button
      }),
      () => {
        this.props.searchAttributes({ timersSearch: this.state.searchVo });
      }
    );
  };
  handleOnBlur = (name) => (event) => {
    let value = event.target.value.trim();
    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value,
      },
      modified: true, // enable update button
    }));
  };
  //  
  handleChangeSearchSelectAuto = (data, name) => {
    let value = data.value;
    this.setState(
      (prevState) => ({
        searchVo: {
          ...prevState.searchVo,
          [name]: value,
        },
        modified: true,
      }),
      () => {
        this.props.searchAttributes({ timersSearch: this.state.searchVo });
      }
    );
  };

  fetchTimerDetails = async () => {
    if (this.validator.allValid()) {
      let payload = { ...this.state.searchVo }
      payload.searchId = payload.searchId.trim();
      await this.props.timerGetDetails(payload);
      this.props.searchAttributes({ timersSearch: payload });
      this.setState({
        updateFlag: false,
        searchFlag: true,
        search1: true,
        resetFlag: true
      });
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };
  componentDidMount() {
    if (this.props.getTimerData && this.props.getTimerData.length > 0) {
      this.setState({ searchFlag: true });
    } else {
      this.props.getTimerType();
    }
    const { loginProfile } = this.props;
    const MBRIDLIT = loginProfile.filter((data) => data.label === "MBRIDLIT");
    this.setState({
      mbridLit: MBRIDLIT[0],
    });
  }
  componentWillUnmount() {
    this.props.resetMemberSearch({
      applicationId: this.props.selectedMemberId.applicationId,
    });
    this.setState({ searchFlag: false });
  }

  setTimerValues = (data) => {
    if (data.length > 0) {
      this.setState({ updatedValue: data });
    }
  };

  updateTimer = () => {
    if (isEmpty(this.state.updatedValue)) {
      this.setState({
        message: "NO FIELDS UDPATED",
        closePopup: true,
      });
      return;
    }

    this.forceUpdate();
    var validation = document.getElementsByClassName("srv-validation-message");

    if ((
      window.find("Invalid date") ||
      window.find("The activation date field is required")
    )) {
      return;
    } else {
      if (
        (validation && validation.length === 0) ||
        (!(
          window.find("Invalid date") ||
          window.find("The activation date field is required")
        ) &&
          this.state.updatedValue.length > 0)
      ) {
        ConfirmBox(this.confirmUpdate, Type.UPDATE, this.props, () => {
          this.setState({ updateFlag: false, search1: false, updatedValue: [] });
          this.clickChild();
        });
      }
    }

  };

  modalClosed = () => {
    this.setState({ closePopup: false });
  };

  confirmUpdate = async () => {
    this.setState({ updateFlag: false, search1: false });

    let payload = {
      searchType: this.state.searchVo.searchType,
      searchId: this.state.searchVo.searchId,
      status: this.state.searchVo.status,
      emmTimersVOs: this.state.updatedValue,
      triggerCode: this.state.searchVo.triggerCode,
    };

    let status = await this.props.timerUpdate(payload);

    this.setState({
      closePopup: true,
      message: "Updated Successfully",
      updateFlag: true,
      updatedValue: [],
    });

    if (status !== undefined) {
      this.setState({
        closePopup: true,
        message: status,
      });
    } else {
      this.setState({
        closePopup: true,
        message: "Updated Successfully",
      });
    }
  };

  handleResetAppl = () => {
    this.setState(
      {
        searchVo: {
          searchType: "",
          searchId: "",
          status: "",
        },
        resetFlag: false
      },
      () => {
        this.props.searchAttributes({ timersSearch: this.state.searchVo });
      }
    );
    this.props.resetTimerData();
    this.validator.hideMessages();
  };

  validateMethod = () => (event) => {
    event.preventDefault();
    this.validator.showMessages();
    this.forceUpdate();
  };

  memberSearchNextPage = async (pageNo) => {
    const { getTimerData } = this.props;
    const lastRow = getTimerData[getTimerData.length - 1];

    let payload = {
      searchType: this.state.searchVo.searchType,
      searchId: this.state.searchVo.searchId,
      status: this.state.searchVo.status,
      triggerCode: this.state.searchVo.triggerCode,
      primaryId: lastRow.primaryId,
      activationTime: lastRow.activationTime,
      creationTime: lastRow.creationTime,
    };
    if (this.props.nextPage) {
      await this.props.SearchNextPage(payload);
      this.setState({ selectedIndex: pageNo * this.state.rowsPerPage });
    }
  };

  handleChangeRowsPerPage = (rowsPerPage) => {
    this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };
  render() {
    const { classes, loading, servicesEnabled, getTimerData } = this.props;
    const { mbridLit } = this.state;
    sessionStorage.setItem("backIconButtonProps", this.props.nextPage);
    let header1 = header
    if (getTimerData.length > 0) {
      header1 = header.filter((value) => getTimerData[0].sourceType === "A" ?
        value.label !== "M360 ID" && value.label !== "Wipro ID" : value.label !== "Application ID")
      header1 = header1.filter((value) => mbridLit.value === "TSA" ? value.label !== "M360 ID" : value.label !== "Wipro ID")
    }

    let searchButton = (
      <div className={classes.buttonContainer5}>
        <span
          class="button-container-search"
          style={{ marginTop: "15px", marginLeft: "93px" }}
        >
          <button type="submit" class="btn btn-primary icon-search">
            Search
          </button>

          <button type="button" class="btn btn-secondary" onClick={this.handleResetAppl}>
            Reset
          </button>
        </span>
      </div>
    );

    return (
      <Paper
        elevation={0}
        className={classes.card}
        style={{ minHeight: "400px" }}
      >
        <Modal
          dialogTitle="TIMERS"
          message={this.state.message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>

        <div class="search-panel">
          <ExpansionPanel
            summary="Search"
            defaultCollapsed={this.state.collapseSearch}
          >
            {loading && <div id="cover-spin" />}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                this.fetchTimerDetails();
              }}
            >
              <div className={classes.container}>
                <div>
                  <div className={classes.space3}>
                    <AutoComplete1
                      handleChange={this.handleChangeSearchSelectAuto}
                      label='Source'
                      options={TIMER_SOURCE_HEADER}
                      defaultValue={TIMER_SOURCE_HEADER[0]}
                      value={TIMER_SOURCE_HEADER.filter(data => data.value === this.state.searchVo.searchType)[0]}
                      name='searchType'
                    />

                  </div>
                  <div className={classes.validationMessageSelect}>
                    {this.validator.message(
                      "searchType",
                      this.state.searchVo.searchType,
                      "required"
                    )}
                  </div>
                </div>

                <div className={classes.space3} style={{ paddingLeft: '30px' }}>
                  <div>
                    <InputField
                      name="searchType"
                      maxLength={15}
                      label={
                        this.state.searchVo.searchType
                          ? this.state.searchVo.searchType === "A"
                            ? "Application Id"
                            : mbridLit.value === "TSA" ? "Wipro ID" : "M360 ID"
                          : "Primary ID"
                      }
                      value={this.state.searchVo.searchId}
                      onChange={this.handlechange("searchId")}
                      onBlur={this.handleOnBlur("searchId")}
                    />
                    <div className={classes.validationMessage} />
                  </div>
                </div>
                <div className={classes.space3}>
                  <div>
                    <AutoComplete1
                      handleChange={this.handleChangeSearchSelectAuto}
                      margin='0px'
                      label='Source'
                      options={TIMER_SOURCE_TRIGGER_STATUS}
                      defaultValue={TIMER_SOURCE_TRIGGER_STATUS[0]}
                      value={TIMER_SOURCE_TRIGGER_STATUS.filter(data => data.value === this.state.searchVo.status)[0]}
                      name='status'
                    />
                    <div className={classes.validationMessageSelect}>
                      {this.validator.message(
                        "status",
                        this.state.searchVo.status,
                        "required"
                      )}
                    </div>
                  </div>
                </div>

                <div className={classes.space3}>
                  {!isEmpty(this.props.timersType) ? (
                    <div>
                      <AutoComplete1
                        handleChange={this.handleChangeSearchSelectAuto}
                        label='Trigger Type'
                        options={this.props.timersType}
                        defaultValue={this.props.timersType[0]}
                        value={this.props.timersType.filter(data => data.value === this.state.searchVo.triggerCode)[0]}
                        name='triggerCode'
                        width="270px"
                      />
                      <div className={classes.validationMessageSelect}>
                      </div>
                    </div>
                  ) : (
                      ""
                    )}
                </div>
                <div>{searchButton}</div>
              </div>
            </form>
          </ExpansionPanel>
        </div>

        {this.props.getTimerData && this.props.getTimerData.length > 0 ? (
          <div className={classes.buttonContainer5}>
            {!servicesEnabled.includes("EMUT") ? (
              <Button
                variant="contained"
                color="primary"
                className={classes.button}
                onClick={this.updateTimer}
              >
                UPDATE
              </Button>
            ) : null}
          </div>
        ) : null}

        {
          this.state.searchFlag === true && this.state.resetFlag === true ? (
            <div className={classes.marginTimer}>
              <ExpansionPanel summary="Search Results">
                <DataTable
                  setClick={(click) => (this.clickChild = click)}
                  clicked={this.selectRow}
                  rowsPerPage={
                    this.props.getTimerData.length < this.state.rowsPerPage
                      ? this.props.getTimerData.length
                      : this.state.rowsPerPage
                  }
                  rowsPerPageOptions={this.state.rowsPerPageOptions}
                  updateTimer={this.updateTimer}
                  nextPage={this.props.nextPage}
                  setTimerValues={this.setTimerValues}
                  updateFlag={this.state.updateFlag}
                  handleChangeRowsPerPage={this.handleChangeRowsPerPage}
                  searchFlag={this.state.search1}
                  fetchMore={this.memberSearchNextPage}
                  header={header1}
                />
              </ExpansionPanel>
            </div>
          ) : null}
      </Paper>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    nextPage: state.timerSearch.nextPage,
    getTimerData: state.timerSearch.searchResultsVo,
    timersType: [
      {
        value: "",
        label: "Select",
      },
      ...state.timerSearch.timersType,
    ],
    selectedMemberId: state.memberSearch.selectedMemberId,
    servicesEnabled: state.loginData.servicesEnabled,
    searchAttribute: state.memberSearch.searchAttributes
      ? state.memberSearch.searchAttributes.timersSearch
      : null,
    loginProfile: state.loginData.profiles
  };
};

const mapDispatchToProps = {
  timerGetDetails,
  timerUpdate,
  getTimerType,
  resetMemberSearch,
  searchAttributes,
  resetTimerData,
  SearchNextPage
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(Timers));
