import Button from "@material-ui/core/Button";
import { withStyles } from "@material-ui/core/styles";
import SvgIcon from "@material-ui/core/SvgIcon";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import MuiTableCell from "@material-ui/core/TableCell";
import TableFooter from "@material-ui/core/TableFooter";
import TableHead from "@material-ui/core/TableHead";
import TablePagination from "@material-ui/core/TablePagination";
import TableRow from "@material-ui/core/TableRow";
import ConfirmBox from "../../utils/PopUp";
import orderBy from "lodash/orderBy";
import React, { Component } from "react";
import { connect } from "react-redux";
import SimpleReactValidator from "simple-react-validator";
import { styles as Styles } from "../../assets/styles/DataTableStyle";
import Modal from "../../components/UI/Modal/Modal";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import MuiCheckbox from "@material-ui/core/Checkbox";
import Pagination from "../UI/Pagination";
import { customValidations } from "../../utils/CustomValidations";
import * as Type from "../../constants/ConfirmType";
import * as DateUtil from "../../utils/DatePicker";
import DataTableTest from "../Home/DataTable"
function HomeIcon(props) {
  return (
    <SvgIcon {...props}>
      <path d={props.path} />
    </SvgIcon>
  );
}

const invertDirection = {
  asc: "desc",
  desc: "asc"
};

const styles = theme => ({
  ...Styles(theme),
  headerCellAttestation: {
    color: "white",
    paddingRight: 4,
    paddingLeft: 5
  },
  validationMessage: {
    color: "red",
    fontSize: "12px"
  }
});
const dateChk = {};
const TableCell = withStyles({
  root: {
    display: "table-cell",
    borderBottom: "1px solid rgba(224, 224, 224, 1)",
    verticalAlign: "inherit",
    paddingLeft: "0px !important",
    paddingRight: "10px !important"
  }
})(MuiTableCell);

const Checkbox = withStyles({
  root: {
    color: "rgba(0, 0, 0, 0.54)",
    padding: "0px"
  }
})(MuiCheckbox);

class DataTable extends Component {
  constructor(props) {
    super(props);
    this.getAlert = this.getAlert.bind(this);
    this.state = {
      selectedRow: 0,
      data: this.props.getTimerData,
      colToSort: "",
      sortDir: "desc",
      page: 0,
      rowsPerPage: this.props.rowsPerPage,
      showModal: false,
      message: "",
      editFlag: false,
      updatedVal: "",
      indexVal: 0,
      updateFlag: this.props.updateFlag,

      timersVo: {
        editValue: true,
        editable: true,
        activationTimeFrmt: "",
        creationTime: "",
        customerId: "",
        editActivationDateStatusFrmt: null,
        history: "",
        lastUpdtTime: "",
        lastUpdtUserId: "",
        pbpId: "",
        planDesignation: "",
        planId: "",
        primaryId: "",
        sourceType: "",
        status: "",
        triggercode: "",
        trgSource: "",
        triggerCode: "",
        triggerType: "",
        visible: false,
        index: 0
      }
    };

    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
        date_after_today: customValidations.date_after_today,
      }
    });
  }
  componentDidMount() {
    this.props.setClick(this.getAlert);
    var items = document.getElementsByName("acs");
    for (var i = 0; i < items.length; i++) {
      if (items[i].type === "checkbox") {
        items[i].disabled = true;
      }
    }
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.updateFlag === false) {
      if (nextProps.searchFlag === false) {
        return {
          rowsPerPage: nextProps.rowsPerPage,
          timersVo: nextProps.getTimerData[0],
          data: nextProps.getTimerData,
          page: (prevState.selectedRow > 0 || prevState.page > 0) ? prevState.page : 0,
          selectedRow: (prevState.selectedRow > 0 || prevState.page > 0) ? prevState.selectedRow : 0,
        }
      } else {
        return {
          rowsPerPage: nextProps.rowsPerPage,
          timersVo: nextProps.getTimerData[0],
          data: nextProps.getTimerData,
          page: 0,
          selectedRow: 0
        };
      }

    } else {
      return {
        data: nextProps.getTimerData
      };
    }
  }

  handleCheckBox = (event, checked, checkBoxId) => {
    var str = checkBoxId;
    str = str.substring(0, str.length - 3);
    str = document.getElementById(str).value.replace(/[^0-9]/g, "").trim();
    if (str.length < 8) {
      return
    }

    this.props.clicked(checkBoxId.match(/\d+/)[0]);
    const index = parseInt(checkBoxId.match(/\d+/)[0]);
    this.setState({ indexVal: index });
    let data = [...this.state.data];
    if (data[index].editable === false) {
      this.setState(prevState => ({
        data: data
      }));

      if (event.target.value === "N") {
        ConfirmBox(() => {
          data[index].checkStatus = "Y";
          document.getElementById(checkBoxId).checked = true;
          document.getElementById(index).disabled = true;
          var allData = [];
          for (let i = 0; i < this.state.data.length; i++) {
            if (
              this.state.data[i].checkStatus === "Y" ||
              this.state.data[i].editActivationDateStatusFrmt != null
            ) {
              allData.push(this.state.data[i]);
            }
          }
          this.props.setTimerValues(allData);
        }, Type.TIMERCHECK, this.props, () => {

        });
      } else {
        document.getElementById(checkBoxId).checked = false;
        data[index].checkStatus = "N";
        document.getElementById(index).disabled = false;
      }
      this.setState(prevState => ({
        data: data
      }));
    }
  };

  handleSort = colName => {
    this.setState(prevState => ({
      colToSort: colName,
      sortDir:
        this.state.colToSort === colName
          ? invertDirection[this.state.sortDir]
          : "asc"
    }));
  };

  fetchMore = async () => {
    await this.props.fetchMore(this.state.page);
  };

  rowSelect = async rowIndex => {
    const index = this.state.page * this.state.rowsPerPage + rowIndex;
    this.setState({
      selectedRow: rowIndex,
      timersVo: this.state.data[index]
    });
    this.props.clicked(index);
    this.setState({ indexVal: index });
  };

  handleChangePage = async page => {
    if (typeof page !== "number") {
      this.fetchMore(page);
      return;
    }
    this.forceUpdate();
    var validation = document.getElementsByClassName("srv-validation-message");
    if ((validation && validation.length === 0) || validation === undefined) {
      this.setState({
        page,
        selectedRow: 0
      });
      const index = this.state.page * this.state.rowsPerPage;
      this.props.clicked(index);
    }
  };

  getAlert() {
    let data = [...this.state.data];
    for (let i = 0; i < data.length; i++) {
      if (document.getElementById(i)) {
        document.getElementById(i + 'chk').checked = false;
        document.getElementById(i).disabled = true;
        document.getElementById(i + 'chk').disabled = true;
      }
      data[i].checkStatus = "N";
    }
    this.setState(prevState => ({
      data: data
    }));
  }

  handleChangeRowsPerPage = (event) => {
    this.setState({ page: 0, rowsPerPage: event.target.value });
    this.props.handleChangeRowsPerPage(event.target.value);
  };

  editTimer = async selectedRow => {
    const indexVal = this.state.page * this.state.rowsPerPage + selectedRow;
    const checkBoxId =
      this.state.page * this.state.rowsPerPage + selectedRow + "chk";
    var display = document.getElementById(indexVal + "err");
    if (display) {
      display.style.display = "none";
    }

    document.getElementById(checkBoxId).disabled = false;
    document.getElementById(indexVal).disabled = false;
    this.setState({ indexVal: indexVal });

    this.setState({
      selectedRow: selectedRow,
      timersVo: this.state.data[indexVal]
    });
    this.props.clicked(indexVal);

    let data = [...this.state.data];
    data[indexVal].editValue = false;

    data[indexVal].editable = false;

    this.setState(prevState => ({
      data: data
    }));
  };

  handleDateChange = event => {
    let value = event.target.value;
    const str = event.target.id + 'chk';
    value = value.replace(/[^0-9]/g, "").trim();
    if (value.length < 8) {
      document.getElementById(str).disabled = true
    }
    String.prototype.insert = function (index, string) {
      if (index > 0)
        return (
          this.substring(0, index) + string + this.substring(index, this.length)
        );
      return string + this;
    };

    switch (value.length) {
      case 2:
        value = value + "/";
        value =
          this.state.keyCode !== 8
            ? value
            : value.substring(0, value.length - 1);
        break;
      case 3:
        value = value.insert(2, "/");
        break;
      case 4:
        value = value.insert(2, "/");
        value = this.state.keyCode !== 8 ? value.insert(5, "/") : value;
        break;
      default:
        if (value.length > 1 && this.state.keyCode !== 8) {
          value = value.insert(2, "/");
          value = value.insert(5, "/");
        }
    }
    let index =
      this.state.page * this.state.rowsPerPage + this.state.selectedRow;
    let data = [...this.state.data];
    data[index].editActivationDateStatusFrmt = value;
    if (data[index].editable === false) {
      this.setState(prevState => ({
        data: data
      }));
    }
    var display = document.getElementById(index + "err");
    if (display) {
      display.style.display = "block";
    }
    var allData = [];
    for (let i = 0; i < this.state.data.length; i++) {
      if (
        this.state.data[i].editActivationDateStatusFrmt != null ||
        this.state.data[i].checkStatus === "Y"
      ) {
        allData.push(this.state.data[i]);
      }
    }
    if (!this.validator.allValid()) {
      this.validator.showMessages();
      this.forceUpdate();
      return;
    }
    this.props.setTimerValues(allData);
  };

  handleDates = e => {
    var self = this;
    const fieldId = "#" + e.target.id;
    if (document.getElementById(e.target.id).disabled) {
      return;
    }

    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", e => {
        if (
          dateChk.name !== e.target.name ||
          dateChk.value !== e.target.value
        ) {
          self.setValue(e.target.name, e.target.value);
        }
        dateChk.name = e.target.name;
        dateChk.value = e.target.value;
      });
  };
  setValue = async (name, value) => {
    const index =
      this.state.page * this.state.rowsPerPage + this.state.selectedRow;
    if (document.getElementById(index + "chk")) {
      document.getElementById(index + "chk").disabled = false;
    }

    let data = [...this.state.data];
    if (data[index].editable === false) {
      data[index].editActivationDateStatusFrmt = value;
      this.setState(prevState => ({
        data: data
      }));
    }

    var allData = [];
    for (let i = 0; i < this.state.data.length; i++) {
      if (
        this.state.data[i].editActivationDateStatusFrmt != null ||
        this.state.data[i].checkStatus === "Y"
      ) {
        allData.push(this.state.data[i]);
      }
    }
    this.props.setTimerValues(allData);
  };

  modalClosed = () => {
    this.setState({ showModal: false });
  };

  labelDisplayedRows = (from, to, count) => {
    const rowsPerPage = this.state.rowsPerPage;
    return (
      <span>
        Page :{Math.ceil(from / rowsPerPage)} - {}
        {count !== -1
          ? Math.ceil(count / rowsPerPage)
          : Math.ceil(to / rowsPerPage)}
      </span>
    );
  }

  render() {
    const { classes, selectedRow, rowsPerPageOptions, servicesEnabled, header } = this.props;
    const { rowsPerPage, page } = this.state;
    let { data } = this.state;

    if (this.state.colToSort) {
      data = orderBy(data, this.state.colToSort, this.state.sortDir);
    }

    return (
      <React.Fragment>
        {this.props.getTimerData && this.props.getTimerData.length > 0 ? (
          <React.Fragment>
            <Modal
              dialogTitle="TIMERS"
              message={this.state.message}
              show={this.state.showModal}
              modalClosed={() => {
                this.modalClosed();
              }}
            ></Modal>
            <div style={{ width: "100%", textAlign: "center" }}>
              <div className={classes.tableWrapper} style={{ width: "100%" }}>
                <Table className={classes.table}>
                  <TableHead className={classes.thead}>
                    <TableRow className={classes.headRow}>
                      {header.map((mbrCol, i) => (
                        <TableCell
                          align="left"
                          className={classes.headerCellAttestation}
                          classes={{ root: classes.rootAttestatationCell }}
                          key={i}
                        >
                          <div
                          >
                            {mbrCol.label}
                            {this.state.colToSort === mbrCol.key ? (
                              this.state.sortDir === "asc" ? (
                                <HomeIcon path="M9 6l-4 4h8z" />
                              ) : (
                                  <HomeIcon path="M5 8l4 4 4-4z" />
                                )
                            ) : (
                                <HomeIcon
                                  className={classes.svgicon}
                                  path="M9 6l-4 4h8z"
                                />
                              )}
                          </div>
                        </TableCell>
                      ))}
                      <TableCell
                        align="center"
                        className={classes.headerCellAttestation}
                        classes={{ root: classes.rootAttestatationCell }}
                      >
                        Activation Date
                      </TableCell>

                      <TableCell
                        align="center"
                        className={classes.headerCellAttestation}
                        classes={{ root: classes.rootAttestatationCell }}
                      >
                        Timer Termination
                      </TableCell>
                    </TableRow>
                  </TableHead>

                  <TableBody className={classes.tbody}>
                    {data.slice(page * parseInt(rowsPerPage), page * parseInt(rowsPerPage) + parseInt(rowsPerPage))

                      .map((genericDetail, j) => (
                        <TableRow
                          className={
                            selectedRow
                              ? classes.row
                              : this.state.selectedRow === j &&
                                !this.props.notClickable
                                ? classes.selectedrow
                                : classes.row
                          }
                          key={j}
                          onClick={
                            this.props.notClickable
                              ? () => { }
                              : () => this.rowSelect(j)
                          }
                        >
                          {header.map((genericKey, p) => (
                            <TableCell
                              key={p}
                              style={
                                this.props.errorTable ? { color: "red" } : null
                              }
                              align="left"
                              className={classes.tableCell}
                            >
                              {genericDetail[genericKey.key]}
                            </TableCell>
                          ))}

                          <TableCell
                            align="center"
                            className={classes.tableCell}
                          >
                            <div>
                              <input
                                maxlength="10"
                                id={
                                  this.state.page * this.state.rowsPerPage + j
                                }
                                placeholder="MM/DD/YYYY"
                                className="form-field"
                                value={
                                  genericDetail.editValue
                                    ? genericDetail.activationTimeFrmt
                                    : genericDetail.editActivationDateStatusFrmt
                                }
                                onChange={this.handleDateChange}
                                onKeyDown={e => {
                                  this.setState({ keyCode: e.keyCode });
                                }}
                                onClick={this.handleDates}
                                disabled={
                                  genericDetail.status === "CLOSED" ||
                                  genericDetail.editable === true
                                }
                                style={{
                                  width: "90px",
                                  textTransform: "uppercase"
                                }}
                              />

                              <div
                                id={
                                  this.state.page * this.state.rowsPerPage +
                                  j +
                                  "err"
                                }
                                style={{ marginLeft: "0px" }}
                                className={classes.validationMessage}
                              >

                                {!genericDetail.editValue
                                  ? this.validator.message(
                                    "Activation date",
                                    genericDetail.editActivationDateStatusFrmt,
                                    "required|date_format|date_after_today"
                                  ) : null}
                              </div>
                            </div>
                          </TableCell>

                          {genericDetail["status"] !== "CLOSED" ? (
                            <TableCell
                              align="center"
                              className={classes.tableCell}
                            >
                              <FormControlLabel
                                control={
                                  <Checkbox
                                    id={
                                      this.state.page * this.state.rowsPerPage +
                                      j +
                                      "chk"
                                    }
                                    name="acs"
                                    value={
                                      this.state.data[
                                        this.state.page *
                                        this.state.rowsPerPage +
                                        j
                                      ].checkStatus === "Y"
                                        ? "Y"
                                        : "N"
                                    }
                                    color="primary"
                                    checked={
                                      this.state.data[
                                        this.state.page *
                                        this.state.rowsPerPage +
                                        j
                                      ].checkStatus === "Y"
                                        ? true
                                        : false
                                    }
                                    classes={{
                                      root: classes.checkboxControl2
                                    }}
                                    onClick={e => {
                                      this.handleCheckBox(
                                        e,
                                        this.state.data[
                                          this.state.page *
                                          this.state.rowsPerPage +
                                          j
                                        ].checkStatus === "Y"
                                          ? "Y"
                                          : "N",
                                        this.state.page *
                                        this.state.rowsPerPage +
                                        j +
                                        "chk"
                                      );
                                    }}
                                  />
                                }
                                classes={{
                                  root: classes.checkboxLabel
                                }}
                              />
                              {!servicesEnabled.includes("EMUT") ? (
                                <Button
                                  variant="contained"
                                  color="primary"
                                  className={classes.button}
                                  onClick={() => this.editTimer(j)}
                                >
                                  Edit
                                </Button>
                              ) : null}
                            </TableCell>
                          ) : (
                              <TableCell></TableCell>
                            )}
                        </TableRow>
                      ))}
                  </TableBody>

                  {data.length > 0 ? (
                    <TableFooter className={classes.footer}>
                      <TableRow className={classes.footer}>
                        <TablePagination
                          className={classes.pagination}
                          rowsPerPageOptions={
                            rowsPerPageOptions ? rowsPerPageOptions : []
                          }
                          colSpan={header.length + 2}
                          backIconButtonProps={sessionStorage.getItem('backIconButtonProps')}
                          count={data.length}
                          rowsPerPage={rowsPerPage}
                          page={page}
                          SelectProps={{
                            native: true
                          }}
                          classes={{
                            toolbar: classes.footer
                          }}
                          labelDisplayedRows={({ from, to, count }) => this.labelDisplayedRows(from, to, count)}
                          onChangePage={this.handleChangePage}
                          onChangeRowsPerPage={this.handleChangeRowsPerPage}
                          ActionsComponent={Pagination}
                          nextIconButtonProps={this.fetchMore}
                        />
                      </TableRow>
                    </TableFooter>
                  ) : null}
                </Table>
              </div>
            </div>
          </React.Fragment>
        ) : <DataTableTest
            data={[]}
            header={header} />}
      </React.Fragment>
    );
  }
}
const mapStateToProps = state => {
  return {
    getTimerData: state.timerSearch.searchResultsVo,
    selectedMemberId: state.memberSearch.selectedMemberId,
    servicesEnabled: state.loginData.servicesEnabled,
  };
};

const mapDispatchToProps = {
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(DataTable));
