import * as DateUtil from "../../utils/DatePicker";
import * as Type from "../../constants/ConfirmType";
import isEmpty from "lodash/isEmpty";
import React, { Component } from "react";
import AutoComplete1 from "../UI/Select";
import { messages } from "../../constants/Messages";
import {
  enrollPlanType,
  mbrEnrollmentDetails,
  updateEnrollment,
  MemberSearch,
  getShowAll,
  updateIndEnrollData,
} from "../../redux/actions/MemberActions";

import Button from "@material-ui/core/Button";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import Checkbox from "@material-ui/core/Checkbox";
import ConfirmBox from "../../utils/PopUp";
import DataTable from "../Home/DataTable";
import FormLabel from "@material-ui/core/FormLabel";
import HistoryData from "../UI/MemberHistory";
import InputField from "../UI/InputField";
import Modal from "../../components/UI/Modal/Modal";
import Paper from "@material-ui/core/Paper";
import Popup from "reactjs-popup";
import ProductSerachPopup from "./MbrProductSearch";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../assets/styles/Theme";
import classNames from "classnames";
import { connect } from "react-redux";
import { ENROLLMENT_HEADER as header } from "../../constants/Headers/MemberHeaders";
import { withStyles } from "@material-ui/core/styles";
import PrintIDCardPopup from "./MbrPrintIDPopup";
import { customValidations } from "../../utils/CustomValidations";
import { handleDateChange } from "../../utils/DateFormatter";

const INITIAL_STATE = {
  memberId: "",
  buttonClicked: "", //if user clicks on cancel
  applicationDate: "",
  applicationDateFrmt: "",
  applicationId: "",
  cancellationReason: "",
  disReasonCd: "",
  editOverrideInd: "",
  effEndDate: "",
  effStartDate: "",
  elcDerivedInd: "",
  electionTypeCd: "",
  enrollReasonCd: "",
  enrollSrceCd: "",
  enrollStatus: "",
  grpId: "",
  pbpId: "",
  pbpSegmentId: "",
  planDesignation: "",
  planId: "",
  planReasonCd: "",
  planType: "",
  productId: "",
  receiptDate: "",
  receivedDate: "",
  receivedDateFrmt: "",
  rxId: "",
  sepElectionDateFrmt: "",
  sepReasonCd: "",
  signatureDate: "",
  signatureDateFrmt: "",
  supplementalId: "",
  trg72Ind: "",
  groupName: "",
  productName: "",
  createTime: "",
  createUserId: "",
  lastUpdtTime: "",
  lastUpdtUserId: "",
};
class MbrEnrollment extends Component {
  constructor(props) {
    super(props);
    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
        date_format2: customValidations.date_format99,
        first_day_of_month: customValidations.first_day_of_month,
        last_day_of_month: customValidations.last_day_of_month99,
        after_start_date: customValidations.c_after_or_equal_99,
      },
    });
    this.state = {
      mbrEnrollmentVo: INITIAL_STATE,
      modified: false,
      isNewSegment: false,
      //showAllActiveInd: true,
      modorcanClicked: false,
      editable: false,
      onBlurFlag: false,
      closePopup: false,
      showAllData: null,
      mbrEnrollList: [],
      memberId: this.props.mbrSearchCriteria.memberId,
      selectedIndex: 0,
      enrollStatusCache: [],
      btnDisable: false,
      cancellation: false,
      cancellationClicked: false,
      validDisenrollmentReasons: this.props.dropdowns.validDisenrollmentReasons,
      printIdc: [],
      rowsPerPage: 10,
      func1: this.showAll.bind(this),
      showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
      mbridLit: [],
    };
  }

  async componentDidMount() {
    var mbrEnrollList = [];
    let mbrEnrollmentVo = INITIAL_STATE;
    if (this.props.showAllActiveInd.showAllActiveInd === false) {
      this.showAll(true, this.props.mbrSearchCriteria.memberId);
    } else if (!isEmpty(this.props.enrollData)) {
      mbrEnrollList = this.props.enrollData;
      mbrEnrollmentVo = this.props.enrollData[0];
    }
    this.setState({
      mbrEnrollmentVo: mbrEnrollmentVo,
      mbrEnrollList: mbrEnrollList,
    });

    let enrollStatus = !isEmpty(this.props.enrollData)
      ? this.props.enrollData[0].enrollStatus
      : "";
    for (
      let i = 0;
      i <= this.props.dropdowns.validEnrollStatusReasons.length;
      i++
    ) {
      if (
        this.props.dropdowns.validEnrollStatusReasons[i] &&
        enrollStatus === this.props.dropdowns.validEnrollStatusReasons[i].name
      ) {
        this.setState({
          enrollStatusCache: this.props.dropdowns.validEnrollStatusReasons[i]
            .item,
        });
      }
    }
    const { validDisenrollmentReasons } = this.props.dropdowns;
    const options = validDisenrollmentReasons.map((data) => {
      return {
        label: data.value === "" ? data.label : data.value + " - " + data.label,
        value: data.value,
      };
    });
    this.setState({
      validDisenrollmentReasons: options,
    });
    const { loginProfile } = this.props;
    const PRINTIDC = loginProfile.filter((data) => data.label === "PRINTIDC");
    const MBRIDLIT = loginProfile.filter((data) => data.label === "MBRIDLIT");
    this.setState({
      printIdc: PRINTIDC[0],
      mbridLit: MBRIDLIT[0],
    });
    let { showAllActiveInd, Indi } = this.props.showAllActiveInd;
    if (showAllActiveInd === false && Indi === "B") {
      this.showAll(true, this.props.mbrSearchCriteria.memberId);
    }
    if (showAllActiveInd === true) {
      this.showAll(false);
    }
  }
  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.mbrSearchCriteria.memberId !== prevState.memberId) {
      if (!isEmpty(nextProps.enrollData)) {
        return {
          mbrEnrollmentVo: nextProps.enrollData[0],
          mbrEnrollList: nextProps.enrollData ? nextProps.enrollData : [],
          showAllData: null,
          //showAllActiveInd: true,
          modified: false,
          isNewSegment: false,
          editable: false,
          onBlurFlag: false,
          selectedIndex: 0,
          memberId: nextProps.mbrSearchCriteria.memberId,
          cancellation: false,
          modorcanClicked: false,
          model: prevState.func1(
            nextProps.showAllActiveInd.showAllActiveInd === false ? true : "N",
            nextProps.mbrSearchCriteria.memberId
          ),
        };
      }
      return {
        mbrEnrollmentVo: INITIAL_STATE,
        mbrEnrollList: [],
        showAllData: null,
        //showAllActiveInd: true,
        modified: false,
        isNewSegment: false,
        editable: false,
        onBlurFlag: false,
        selectedIndex: 0,
        memberId: nextProps.mbrSearchCriteria.memberId,
        cancellation: false,
        modorcanClicked: false,
        model: prevState.func1(
          nextProps.showAllActiveInd.showAllActiveInd === false ? true : "N",
          nextProps.mbrSearchCriteria.memberId
        ),
      };
    }

    if (
      nextProps.showAllActiveInd.showAllActiveInd !== prevState.showAllActiveInd
    ) {
      if (nextProps.showAllActiveInd.showAllActiveInd === false) {
        return {
          model: prevState.func1(true, nextProps.mbrSearchCriteria.memberId),
        };
      } else if (nextProps.showAllActiveInd.showAllActiveInd === true) {
        return {
          model: prevState.func1(false, nextProps.mbrSearchCriteria.memberId),
        };
      }
    }
    return prevState;
  }

  componentDidUpdate(prevProps, prevState) {
    if (
      !isEmpty(this.props.enrollData) &&
      this.props.enrollData[0].memberId !== prevProps.enrollData[0].memberId
    ) {
      this.validator.hideMessages();
    }
  }

  selectRow = (index) => {
    this.validator.hideMessages();
    const selectedVo = this.state.mbrEnrollList[index];
    this.setState(() => ({
      mbrEnrollmentVo: { ...selectedVo }, // copy data
      editable: false, // readOnly
      onBlurFlag: false,
      isNewSegment: false, //Not a new SEgment
      modified: false,
      selectedIndex: index,
      cancellation: false,
      modorcanClicked: false,
    }));
  };

  showAll = async (flag, mbrid) => {
    const memberId = mbrid;

    const { showAllData } = this.state;

    if (flag === true) {
      if (showAllData === null) {
        const data = await this.props.getShowAll({
          memberId: memberId + "/Y",
          url: "MEMBER_ENROLL_FETCH",
        });
        if (null != data) {
          const selectedVo = !isEmpty(data) ? data[0] : { ...INITIAL_STATE };
          this.setState(() => ({
            mbrEnrollList: data,
            showAllData: data,
            mbrEnrollmentVo: { ...selectedVo },
            showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
            selectedIndex: 0,
          }));
        }
      } else {
        const mbrEnrollmentVo = !isEmpty(showAllData)
          ? showAllData[0]
          : { ...INITIAL_STATE };
        this.setState({
          mbrEnrollList: showAllData,
          mbrEnrollmentVo: mbrEnrollmentVo,
          showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
          selectedIndex: 0,
        });
      }
    } else {
      if (flag === "N") {
         await this.props.getShowAll({
          memberId: memberId + "/N",
          url: "MEMBER_ENROLL_FETCH",
        });
      } else {
        let recodN =
          (await this.state.mbrEnrollList) === null
            ? []
            : this.state.mbrEnrollList.filter(
              (role) => role.overrideInd === "N"
            );

        await this.props.updateIndEnrollData(recodN);
      }

      const mbrEnrollList = this.props.enrollData;
      const selectedVo = !isEmpty(mbrEnrollList)
        ? mbrEnrollList[0]
        : { ...INITIAL_STATE };
      this.setState(() => ({
        mbrEnrollmentVo: { ...selectedVo },
        mbrEnrollList: mbrEnrollList,
        showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
        selectedIndex: 0,
      }));
    }
  };
  handleStartDate = (event) => {
    var self = this;
    const fieldId = "#" + event.target.id;
    DateUtil.getStartDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        self.setDate(e.target.id, e.target.value);
      });
  };

  handleDates = (event) => {
    var self = this;
    const fieldId = "#" + event.target.id;
    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        self.setDate(e.target.id, e.target.value);
      });
  };

  setDate = (name, value) => {
    this.setState((prevState) => ({
      mbrEnrollmentVo: {
        ...prevState.mbrEnrollmentVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handlechange = (event) => {
    let value = event.target.value.toUpperCase();
    let name = event.target.name;

    this.setState((prevState) => ({
      modified: true,
      mbrEnrollmentVo: {
        ...prevState.mbrEnrollmentVo,
        [name]: value,
      },
    }));
  };

  handleChangePage = (index) => {
    this.setState({ selectedIndex: index });
  };

  handleOnBlur = (event) => {
    let value = event.target.value.trim();
    let name = event.target.name;
    const {
      mbrEnrollList,
      mbrEnrollmentVo,
      onBlurFlag,
      selectedIndex,
    } = this.state;
    const { productName, groupName } = mbrEnrollmentVo;
    this.setState((prevState) => ({
      mbrEnrollmentVo: {
        ...prevState.mbrEnrollmentVo,
        [name]: value.toUpperCase(),
      },
      modified: true,
    }));

    if (
      productName === "" ||
      (groupName !== mbrEnrollList[selectedIndex].groupName && !onBlurFlag)
    ) {
      this.setState({
        mbrEnrollmentVo: {
          ...this.state.mbrEnrollmentVo,
          grpId: "",
          pbpId: "",
          pbpSegmentId: "",
          planId: "",
          productId: "",
          productName: "",
          onBlurFlag: true,
          groupName: this.state.mbrEnrollmentVo.groupName.trim(),
        },
      });
    }
  };
  handleChangeSearchSelectAuto = async (data, name) => {
    let value = data.value;
    if (name === "enrollStatus") {
      for (
        let i = 0;
        i <= this.props.dropdowns.validEnrollStatusReasons.length;
        i++
      ) {
        if (
          this.props.dropdowns.validEnrollStatusReasons[i] &&
          value === this.props.dropdowns.validEnrollStatusReasons[i].name
        ) {
          this.setState({
            enrollStatusCache: [
              ...this.props.dropdowns.validEnrollStatusReasons[i].item,
            ],
          });
        }
      }
    }

    this.setState((prevState) => ({
      mbrEnrollmentVo: {
        ...prevState.mbrEnrollmentVo,
        [name]: value,
      },
      modified: true,
    }));
  };
  handleChangeSearchSelect = (name) => (event) => {
    if (name === "enrollStatus") {
      for (
        let i = 0;
        i <= this.props.dropdowns.validEnrollStatusReasons.length;
        i++
      ) {
        if (
          this.props.dropdowns.validEnrollStatusReasons[i] &&
          event.value === this.props.dropdowns.validEnrollStatusReasons[i].name
        ) {
          this.setState({
            enrollStatusCache: [
              ...this.props.dropdowns.validEnrollStatusReasons[i].item,
            ],
          });
        }
      }
    }

    let value = event.value;
    this.setState((prevState) => ({
      mbrEnrollmentVo: {
        ...prevState.mbrEnrollmentVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleCheckBox = (name) => (event) => {
    let val = event.target.value === "Y" ? "N" : "Y";
    if (name === "elcDerivedInd") {
      this.setState((prevState) => ({
        mbrEnrollmentVo: {
          ...prevState.mbrEnrollmentVo,
          editOverrideInd: val,
        },
      }));
    }
    this.setState((prevState) => ({
      mbrEnrollmentVo: {
        ...prevState.mbrEnrollmentVo,
        [name]: val,
      },
      modified: true,
    }));
  };

  modelSegment = () => {
    if (this.state.mbrEnrollmentVo.overrideInd === "Y") {
      let msg = "This Record is not active ";
      this.setState({ message: msg, closePopup: true });
    } else {
      this.setState((prevState) => ({
        mbrEnrollmentVo: {
          ...prevState.mbrEnrollmentVo,
          buttonClicked: "",
          elcDerivedInd: "N",
        },
        modified: false,
        editable: true,
        cancellation: false,
        modorcanClicked: true,
      }));

      this.validator.hideMessages();
      this.forceUpdate();
    }
  };

  cancellation = () => {
    this.validator.hideMessages();
    if (this.state.mbrEnrollmentVo.enrollStatus === "EAPRV") {
      this.setState((prevState) => ({
        mbrEnrollmentVo: {
          ...prevState.mbrEnrollmentVo,
          enrollStatus: "DPEND",
          enrollReasonCd: "CMSREADY",
          buttonClicked: "cancelEnrollment",
        },
        modified: true,
        cancellation: true,
        cancellationClicked: true,
        editable: false,
        onBlurFlag: false,
        modorcanClicked: true,
      }));
    } else if (this.state.mbrEnrollmentVo.enrollStatus === "DAPRV") {
      this.setState((prevState) => ({
        mbrEnrollmentVo: {
          ...prevState.mbrEnrollmentVo,
          enrollStatus: "EPEND",
          enrollReasonCd: "CMSREADY",
          buttonClicked: "cancelEnrollment",
        },
        modified: true,
        cancellation: true,
        cancellationClicked: true,
        editable: false,
        onBlurFlag: false,
        modorcanClicked: true,
      }));
    } else if (this.state.mbrEnrollmentVo.enrollStatus === "DPEND") {
      this.setState((prevState) => ({
        mbrEnrollmentVo: {
          ...prevState.mbrEnrollmentVo,
          enrollStatus: "EAPRV",
          enrollReasonCd: "CMSAPRV",
          buttonClicked: "cancelEnrollment",
        },
        modified: true,
        cancellation: true,
        cancellationClicked: true,
        editable: false,
        onBlurFlag: false,
        modorcanClicked: true,
      }));
    } else {
      alert("Cancellation is not allowed for current Enrollment Status.");
    }
  };

  updateEnrollment = (event) => {
    event.preventDefault();
    if (!this.validator.allValid()) {
      this.validator.showMessages();
      this.forceUpdate();
    } else if (this.state.mbrEnrollmentVo.productName === "") {
      alert("Please Verify Group Product");
    } else if (
      !this.state.cancellation &&
      this.state.mbrEnrollmentVo.electionTypeCd === "S" &&
      this.state.mbrEnrollmentVo.sepReasonCd === ""
    ) {
      alert("SEP Reason Code cannot be blank.");
      this.validator.showMessages();
      this.forceUpdate();
    } else if (
      !this.state.cancellation &&
      (this.state.mbrEnrollmentVo.enrollStatus === "DPEND" ||
        this.state.mbrEnrollmentVo.enrollStatus === "DAPRV") &&
      (this.state.mbrEnrollmentVo.disReasonCd === "" ||
        this.state.mbrEnrollmentVo.disReasonCd === null)
    ) {
      alert("DIS Reason cannot be blank.");
      this.validator.showMessages();
      this.forceUpdate();
    } else if (
      !this.state.cancellation &&
      (this.state.mbrEnrollmentVo.enrollStatus === "EPEND" ||
        this.state.mbrEnrollmentVo.enrollStatus === "EAPRV" ||
        this.state.mbrEnrollmentVo.enrollStatus === "EOPOUT") &&
      this.state.mbrEnrollmentVo.disReasonCd !== ""
    ) {
      alert("Disenrollment Reason Code only valid for Disenrollments");
    } else if (
      !this.state.cancellation &&
      this.state.mbrEnrollmentVo.enrollStatus !== "EAPRV" &&
      this.state.mbrEnrollmentVo.trg72Ind === "Y"
    ) {
      alert("72 TXN is valid only for EAPRV.");
      this.setState((prevState) => ({
        mbrEnrollmentVo: {
          ...prevState.mbrEnrollmentVo,
          trg72Ind: "N",
        },
        modified: true,
      }));
    } else {
      ConfirmBox(this.confirmUpdate, Type.UPDATE, this.props);
    }
  };

  handleDate = (event) => {
    let value = event.target.value;
    let name = event.target.name;
    this.setState((prevState) => ({
      mbrEnrollmentVo: {
        ...prevState.mbrEnrollmentVo,
        [name]: handleDateChange(value),
      },
      modified: true,
    }));
  };

  confirmUpdate = async () => {
    const { mbrEnrollmentVo } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(mbrEnrollmentVo.showAll = val),
    });
    let payload = {
      ...this.state.mbrEnrollmentVo,
      memberId: this.props.mbrSearchCriteria.memberId,
    };
    let status = await this.props.updateEnrollment(payload);
    if (status === "success") {
      status = messages.UPDATED_SUCCESSFULLY;
      let newVO = isEmpty(this.props.enrollData)
        ? INITIAL_STATE
        : this.props.enrollData[0];
      this.setState(() => ({
        isNewSegment: false,
        editable: false,
        onBlurFlag: false,
        modified: false,
        mbrEnrollmentVo: newVO,
        mbrEnrollList: this.props.enrollData,
        showAllData: null,
        selectedIndex: 0,
        cancellation: false,
        modorcanClicked: false,
      }));
    }
    this.setState(() => ({
      message: status,
      closePopup: true,
    }));
  };

  handleCheckBox = (name) => (event) => {
    let val = event.target.value === "Y" ? "N" : "Y";
    if (name === "elcDerivedInd") {
      this.setState((prevState) => ({
        mbrEnrollmentVo: {
          ...prevState.mbrEnrollmentVo,
          editOverrideInd: val,
        },
      }));
    }
    this.setState((prevState) => ({
      mbrEnrollmentVo: {
        ...prevState.mbrEnrollmentVo,
        [name]: val,
      },
      modified: true,
    }));
  };

  setProduct = (selectedVo) => {
    this.setState((prevState) => ({
      mbrEnrollmentVo: {
        ...prevState.mbrEnrollmentVo,
        grpId: selectedVo.groupId,
        groupName: selectedVo.groupName,
        productName: selectedVo.productName,
        productId: selectedVo.productId,
        planId: selectedVo.planId,
        pbpId: selectedVo.pbpId,
        pbpSegmentId: selectedVo.segmentId,
        //zip: selectedVo.zip5 + selectedVo.zip4,
        zipCd5: selectedVo.zipCd5,
        zipCd4: selectedVo.zipCd4,
        state: selectedVo.state,
      },
      modified: true,
      editable: true,
    }));
    let planType = {
      pbpId: this.state.mbrEnrollmentVo.pbpId,
      planId: this.state.mbrEnrollmentVo.planId,
    };
    this.props.enrollPlanType(planType);
  };

  modalClosed = () => {
    this.setState({ closePopup: false });
  };
  handleChangeRowsPerPage = async (rowsPerPage) => {
    await this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  render() {
    const { classes, dropdowns, servicesEnabled } = this.props;
    const {
      mbrEnrollmentVo,
      validDisenrollmentReasons,
      printIdc,
      mbridLit,
    } = this.state;
    let buttonContainer = (
      <div className={classes.buttonContainer}>
        {printIdc && mbrEnrollmentVo && printIdc.value === "Y" ? (
          <Popup
            className={classes.mobileWidth}
            modal
            trigger={
              <Button
                variant="contained"
                color="primary"
                className={this.props.classes.button}
                id="PrintIDCardPopup"
              >
                Print ID Card
              </Button>
            }
            position="right center"
          >
            {(close) => (
              <div>
                <PrintIDCardPopup
                  memberId={mbrEnrollmentVo.memberId}
                  planId={mbrEnrollmentVo.planId}
                  pbpId={mbrEnrollmentVo.pbpId}
                  planDesignation={mbrEnrollmentVo.planDesignation}
                  effStartDateFrmt={mbrEnrollmentVo.effStartDateFrmt}
                  close={close}
                />
              </div>
            )}
          </Popup>
        ) : null}
        <Button
          variant="contained"
          color="primary"
          onClick={this.cancellation}
          className={classes.button}
        >
          Cancellation
        </Button>
        <Button
          variant="contained"
          color="primary"
          onClick={this.modelSegment}
          className={classes.button}
        >
          Model Segment
        </Button>
        {servicesEnabled.includes("EEUM") ? (
          <Button
            type="submit"
            variant="contained"
            color="primary"
            style={{ marginBottom: "7px" }}
            onClick={this.updateEnrollment}
            disabled={!this.state.modified}
          >
            Update
          </Button>
        ) : null}
      </div>
    );

    return (
        <React.Fragment>
          <Modal
            dialogTitle="Enrollment"
            message={this.state.message}
            show={this.state.closePopup}
            modalClosed={() => {
              this.modalClosed();
            }}
          ></Modal>
  
          <Paper
            elevation={0}
            className={classNames(classes.card, "animated fadeIn")}
          >
            <DataTable
              data={this.state.mbrEnrollList ? this.state.mbrEnrollList : []}
              header={header}
              rowsPerPage={this.state.rowsPerPage}
              clicked={this.selectRow}
              index={this.state.selectedIndex}
              pageNo={this.state.page}
              sortable={true}
              rowsPerPageOptions={[10, 15, 20]}
              handleChangeRowsPerPage={this.handleChangeRowsPerPage}
              handleChangePage={this.handleChangePage}
              dateColumn={["effStartDateFrmt", "effEndDateFrmt"]}
              subtab
            />
  
            {!isEmpty(this.state.mbrEnrollList) || this.state.isNewSegment ? (
              <React.Fragment>
                <form autoComplete="off">
                  {buttonContainer}
  
                  <div class="panel-body margin-top1">
                    <div className={classes.container}>
                      <div className={classes.container}>
                        <div>
                          <AutoComplete1
                            handleChange={this.handleChangeSearchSelectAuto}
                            label="Status"
                            width="170px"
                            options={dropdowns.validEnrollStatuses}
                            defaultValue={dropdowns.validEnrollStatuses[0]}
                            value={
                              dropdowns.validEnrollStatuses.filter(
                                (data) =>
                                  data.value === mbrEnrollmentVo.enrollStatus
                              )[0]
                            }
                            name="enrollStatus"
                            disabled={!this.state.editable}
                          />
                          <div className={classes.validationMessage}>
                            {this.validator.message(
                              "Status",
                              mbrEnrollmentVo.enrollStatus.trim(),
                              "required"
                            )}
                          </div>
                        </div>
                        <div>
                          <AutoComplete1
                            handleChange={this.handleChangeSearchSelectAuto}
                            label="Enroll Reason Code"
                            width="170px"
                            options={this.state.enrollStatusCache}
                            defaultValue={this.state.enrollStatusCache[0]}
                            value={
                              dropdowns.validEnrollReasons.filter(
                                (data) =>
                                  data.value === mbrEnrollmentVo.enrollReasonCd
                              )[0]
                            }
                            name="enrollReasonCd"
                            disabled={!this.state.editable}
                          />
                          <div className={classes.validationMessage}>
                            {this.validator.message(
                              "enrollReasonCd",
                              mbrEnrollmentVo.enrollReasonCd,
                              "required"
                            )}
                          </div>
                        </div>
                        <div>
                          <InputField
                            name="effStartDateFrmt"
                            placeholder="MM/DD/YYYY"
                            id="effStartDateFrmt"
                            onClick={this.handleStartDate}
                            label="Start Date"
                            value={mbrEnrollmentVo.effStartDateFrmt}
                            onChange={this.handleDate}
                            onBlur={this.handleOnBlur}
                            disabled={!this.state.editable}
                            required
                          />
                          <div className={classes.validationMessage}>
                            {this.validator.message(
                              "StartDate",
                              mbrEnrollmentVo.effStartDateFrmt,
                              "required|date_format"
                            )}
                          </div>
                        </div>
  
                        <div>
                          <InputField
                            name="effEndDateFrmt"
                            placeholder="MM/DD/YYYY"
                            id="effEndDateFrmt"
                            onClick={this.handleDates}
                            label="End Date"
                            onChange={this.handleDate}
                            onBlur={this.handleOnBlur}
                            value={mbrEnrollmentVo.effEndDateFrmt}
                            disabled={!this.state.editable}
                            required
                          />
                          <div className={classes.validationMessage}>
                            {this.validator.message(
                              "EndDate",
                              mbrEnrollmentVo.effEndDateFrmt,
                              [
                                "required",
                                "date_format2",
                                "date_format",
                                "last_day_of_month",
                                {
                                  after_start_date:
                                    mbrEnrollmentVo.effStartDateFrmt,
                                },
                              ]
                            )}
                          </div>
                        </div>
                        <div>
                          <InputField
                            name="overrideInd"
                            label="Override"
                            value={mbrEnrollmentVo.overrideInd}
                            onChange={this.handlechange}
                            onBlur={this.handleOnBlur}
                            disabled
                          />
                          <div className={classes.validationMessage} />{" "}
                        </div>
                        <div className={classes.Margin}>
                          <InputField
                            name="groupName"
                            label="Group"
                            width={"372px"}
                            value={mbrEnrollmentVo.groupName}
                            onChange={this.handlechange}
                            onBlur={this.handleOnBlur}
                            disabled={!this.state.editable}
                            maxLength={50}
                          />
                          <div className={classes.validationMessage} />
                        </div>
                        <div
                          style={{
                            width: "605px",
                            marginTop: "0px"
                          }}
                        >
                          <span class="label-container">
                            <label id="product">Product</label>
                            <br />
                            <input
                              maxLength={50}
                              type="text"
                              class="form-field"
                              id="product"
                              name="productName"
                              style={{ width: "580px" }}
                              value={mbrEnrollmentVo.productName}
                              onChange={this.handlechange}
                              onBlur={this.handleOnBlur}
                              disabled={!this.state.editable}
                            //endAdornment={this.state.editable}
                            />
  
                            {this.state.editable ? (
                              <Popup
                                style={{ height: "50%" }}
                                className={classes.mobileWidth}
                                modal
                                trigger={<span class="more-info" />}
                                position="right center"
                              >
                                {(close) => (
                                  <div>
                                    <ProductSerachPopup
                                      headerLabel="Product Search"
                                      search={mbrEnrollmentVo}
                                      setProduct={this.setProduct}
                                      close={close}
                                    />
                                  </div>
                                )}
                              </Popup>
                            ) : null}
                          </span>
                        </div>
                      </div>
                      <div className={classes.container}>
  
                        <div className={classes.containerdemo}>
                          {!this.state.cancellation ? (
                            <div>
                              {" "}
                              <InputField
                                name="grpId"
                                label="Group ID"
                                value={mbrEnrollmentVo.grpId}
                                onChange={this.handlechange}
                                disabled={!this.state.editable}
                                maxLength={50}
                                onBlur={this.handleOnBlur}
                              />
                              <div className={classes.validationMessage} />
                            </div>
                          ) : null}
  
                          {!this.state.cancellation ? (
                            <div>
                              {" "}
                              <InputField
                                name="productId"
                                label="Product ID"
                                value={mbrEnrollmentVo.productId}
                                onChange={this.handlechange}
                                maxLength={50}
                                onBlur={this.handleOnBlur}
                                disabled={!this.state.editable}
                              />
                              <div className={classes.validationMessage} />
                            </div>
                          ) : null}
  
                          <div>
                            <InputField
                              name="planId"
                              label="Plan"
                              className={classes.textField}
                              value={mbrEnrollmentVo.planId}
                              onChange={this.handlechange}
                              onBlur={this.handleOnBlur}
                              maxLength={5}
                              disabled={!this.state.editable}
                            />
                            <div className={classes.validationMessage}>
                              {this.validator.message(
                                "PlanID",
                                mbrEnrollmentVo.planId,
                                "required"
                              )}
                            </div>
                          </div>
  
                          <div>
                            <InputField
                              name="pbpId"
                              label="PBP Id"
                              value={mbrEnrollmentVo.pbpId}
                              onChange={this.handlechange}
                              onBlur={this.handleOnBlur}
                              maxLength={3}
                              disabled={!this.state.editable}
                            />
                            <div className={classes.validationMessage}>
                              {this.validator.message(
                                "pbpId",
                                mbrEnrollmentVo.pbpId,
                                "required"
                              )}
                            </div>
                          </div>
  
                          <div>
                            <InputField
                              name="pbpSegmentId"
                              label="Segment"
                              className={classes.textField}
                              value={mbrEnrollmentVo.pbpSegmentId}
                              onChange={this.handlechange}
                              onBlur={this.handleOnBlur}
                              maxLength={3}
                              disabled={!this.state.editable}
                            />
                            <div className={classes.validationMessage}>
                              {this.validator.message(
                                "pbpSegmentId",
                                mbrEnrollmentVo.pbpSegmentId,
                                "required"
                              )}
                            </div>
                          </div>
                          <div>
                            <InputField
                              name="planType"
                              label="Type"
                              value={
                                this.props.enrollType
                                  ? this.props.enrollType
                                  : mbrEnrollmentVo.planType
                              }
                              onChange={this.handlechange}
                              onBlur={this.handleOnBlur}
                              disabled
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div>
                            <InputField
                              name="planDesignation"
                              label="Designation"
                              value={mbrEnrollmentVo.planDesignation}
                              onChange={this.handlechange}
                              onBlur={this.handleOnBlur}
                              disabled
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div style={{ width: "410px" }}>
                            <AutoComplete1
                              handleChange={this.handleChangeSearchSelectAuto}
                              label="Status"
                              options={dropdowns.validEnrollSources}
                              defaultValue={dropdowns.validEnrollSources[0]}
                              value={
                                dropdowns.validEnrollSources.filter(
                                  (data) =>
                                    data.value === mbrEnrollmentVo.enrollSrceCd
                                )[0]
                              }
                              name="enrollSrceCd"
                              disabled={!this.state.editable}
                              width="370px"
                            />
                            <div className={classes.validationMessage}>
                              {this.validator.message(
                                "EnrollSource",
                                mbrEnrollmentVo.enrollSrceCd,
                                "required"
                              )}
                            </div>
                          </div>
  
                          <div className={classes.checkbox}>
                            <FormLabel classes={{ root: classes.formLabel }}>
                              Trigger TXN 72
                            </FormLabel>
                            <Checkbox
                              name="trigger"
                              style={{ width: 36, height: 36 }}
                              icon={
                                <CheckBoxOutlineBlankIcon
                                  style={{ fontSize: "16px" }}
                                />
                              }
                              checkedIcon={
                                <CheckBoxIcon
                                  className={classes.checkboxmember}
                                />
                              }
                              disabled={!this.state.editable}
                              checked={
                                mbrEnrollmentVo.trg72Ind === "Y" ? true : false
                              }
                              onClick={this.handleCheckBox("trg72Ind")}
                              value={mbrEnrollmentVo.trg72Ind}
                              inputProps={{
                                "aria-label": "primary checkbox",
                              }}
                            />
                          </div>
                        </div>
                        <div className={classes.containerdemo}>
                          <div style={{ width: "410px" }}>
                            <AutoComplete1
                              handleChange={this.handleChangeSearchSelectAuto}
                              label="Election Type"
                              options={dropdowns.validElectionTypes}
                              defaultValue={dropdowns.validElectionTypes[0]}
                              value={
                                dropdowns.validElectionTypes.filter(
                                  (data) =>
                                    data.value === mbrEnrollmentVo.electionTypeCd
                                )[0]
                              }
                              name="electionTypeCd"
                              disabled={!this.state.editable}
                              width="370px"
                            />
                            <div className={classes.validationMessage} />
                          </div>
                          <div style={{ width: "410px" }}>
                            <AutoComplete1
                              handleChange={this.handleChangeSearchSelectAuto}
                              label="SEP Reason"
                              options={dropdowns.validSEPReasons}
                              defaultValue={dropdowns.validSEPReasons[0]}
                              value={
                                dropdowns.validSEPReasons.filter(
                                  (data) =>
                                    data.value === mbrEnrollmentVo.sepReasonCd
                                )[0]
                              }
                              name="sepReasonCd"
                              disabled={!this.state.editable}
                              width="370px"
                            />
                          
                            <div className={classes.validationMessage}>
                              {this.state.mbrEnrollmentVo.electionTypeCd === "S"
                                ? this.validator.message(
                                  "SEP Reason ",
                                  mbrEnrollmentVo.sepReasonCd,
                                  "required"
                                )
                                : null}
                            </div>
                          </div>
                          <div>
                            <InputField
                              name="sepElectionDateFrmt"
                              placeholder="MM/DD/YYYY"
                              id="sepElectionDateFrmt"
                              onClick={this.handleDates}
                              label="SEP Date"
                              onChange={this.handleDate}
                              onBlur={this.handleOnBlur}
                              value={mbrEnrollmentVo.sepElectionDateFrmt}
                              disabled={!this.state.editable}
                            />
                            <div className={classes.validationMessage}>
                              {this.validator.message(
                                "SEPDate",
                                mbrEnrollmentVo.sepElectionDateFrmt,
                                "date_format"
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={classes.container}>
                        <div>
                          <div className={classes.containerdemo}>
                          {!this.state.modorcanClicked ?(
                            <div>
                              <InputField
                                name="receivedDateFrmt"
                                placeholder="MM/DD/YYYY"
                                id="receivedDateFrmt"
                                onClick={this.handleDates}
                                label="Received Date"
                                onChange={this.handleDate}
                                onBlur={this.handleOnBlur}
                                value={mbrEnrollmentVo.receivedDateFrmt}
                                disabled={
                                  !this.state.editable && !this.state.cancellation
                                }
                              />
                              <div className={classes.validationMessage}>
                                {this.state.cancellation
                                  ? this.validator.message(
                                    "ReceivedDate",
                                    mbrEnrollmentVo.receivedDateFrmt,
                                    "required"
                                  )
                                  : null}
                              </div>
                            </div>) : null}
                            {!this.state.cancellation ? (
                              <div style={{ width: "410px",  }}>
                               
                                <AutoComplete1
                                  handleChange={this.handleChangeSearchSelectAuto}
                                  label="DIS Reason"
                                  options={validDisenrollmentReasons}
                                  defaultValue={validDisenrollmentReasons[0]}
                                  value={
                                    validDisenrollmentReasons.filter(
                                      (data) =>
                                        data.value === mbrEnrollmentVo.disReasonCd
                                    )[0]
                                  }
                                  name="disReasonCd"
                                  disabled={!this.state.editable}
                                  width={this.state.cancellationClicked? "389px": "370px"}
                                  paddingLeft= {this.state.cancellationClicked? "19px": null}
                                />
                                <div className={classes.validationMessage}></div>
                              </div>
                            ) : null}
                            {this.state.editable ? (
                              <div style={{ width: "410px" }}>
                                <AutoComplete1
                                  handleChange={this.handleChangeSearchSelectAuto}
                                  label="Plan Reason"
                                  options={dropdowns.validPlanReasons}
                                  defaultValue={dropdowns.validPlanReasons[0]}
                                  marginLeft='19px'
                                  value={
                                    dropdowns.validPlanReasons.filter(
                                      (data) =>
                                        data.value === mbrEnrollmentVo.planReason
                                    )[0]
                                  }
                                  name="planReason"
                                  width="370px"
                                />
                                <div className={classes.validationMessage} />
                              </div>
                            ) : null}
                            <div className={classes.checkbox}>
                              <FormLabel classes={{ root: classes.formLabel }}>
                                Bypass Edits
                              </FormLabel>
                              <Checkbox
                                name="elcDerivedInd"
                                style={{ width: 36, height: 36 }}
                                icon={
                                  <CheckBoxOutlineBlankIcon
                                    style={{ fontSize: "16px" }}
                                  />
                                }
                                checkedIcon={
                                  <CheckBoxIcon
                                    className={classes.checkboxmember}
                                  />
                                }
                                disabled={!this.state.editable}
                                checked={
                                  mbrEnrollmentVo.elcDerivedInd === "Y"
                                    ? true
                                    : false
                                }
                                onClick={this.handleCheckBox("elcDerivedInd")}
                                value={mbrEnrollmentVo.elcDerivedInd}
                                inputProps={{
                                  "aria-label": "primary checkbox",
                                }}
                              />
                            </div>
                          </div>
  
                          <div className={classes.containerdemo}>
                            {!this.state.cancellation ? (
                              <div>
                                {" "}
                                <InputField
                                  name="supplementalId"
                                  InputProps={{ className: classes.textFont }}
                                  label="Plan Member ID"
                                  className={classes.textField}
                                  value={mbrEnrollmentVo.supplementalId}
                                  InputLabelProps={{
                                    className: classes.label,
                                    shrink: true,
                                  }}
                                  onChange={this.handlechange}
                                  onBlur={this.handleOnBlur}
                                  maxLength={15}
                                  disabled={
                                    !this.state.editable ||
                                    mbridLit.value === "TSA"
                                  }
                                />
                                <div className={classes.validationMessage} />
                              </div>
                            ) : null}
  
                            {!this.state.cancellation ? (
                              <div>
                                <InputField
                                  name="rxId"
                                  InputProps={{ className: classes.textFont }}
                                  label="RX ID"
                                  className={classes.textField}
                                  value={mbrEnrollmentVo.rxId}
                                  InputLabelProps={{
                                    className: classes.label,
                                    shrink: true,
                                  }}
                                  onChange={this.handlechange}
                                  maxLength={20}
                                  onBlur={this.handleOnBlur}
                                  disabled={
                                    !this.state.editable ||
                                    mbridLit.value === "TSA"
                                  }
                                />
                                <div className={classes.validationMessage} />
                              </div>
                            ) : null}
  
                            <div>
                              <InputField
                                name="applicationDateFrmt"
                                placeholder="MM/DD/YYYY"
                                id="applicationDateFrmt"
                                onClick={this.handleDates}
                                label="Application Date"
                                onChange={this.handleDate}
                                onBlur={this.handleOnBlur}
                                value={mbrEnrollmentVo.applicationDateFrmt}
                                disabled={!this.state.editable}
                              />
                              <div className={classes.validationMessage}>
                                {this.validator.message(
                                  "ApplicationDate",
                                  mbrEnrollmentVo.applicationDateFrmt,
                                  "required|date_format"
                                )}
                              </div>
                            </div>
  
                            <div>
                              <InputField
                                name="signatureDateFrmt"
                                placeholder="MM/DD/YYYY"
                                id="signatureDateFrmt"
                                onClick={this.handleDates}
                                label="Signature Date"
                                onChange={this.handleDate}
                                onBlur={this.handleOnBlur}
                                value={mbrEnrollmentVo.signatureDateFrmt}
                                disabled={!this.state.editable}
                              />
                              <div className={classes.validationMessage}>
                                {this.validator.message(
                                  "SignatureDate",
                                  [mbrEnrollmentVo.signatureDateFrmt],
                                  "required|date_format"
                                )}
                              </div>
                            </div>
                            <div className={classes.container}>
                          {!this.state.editable && !this.state.cancellation ? (
                            <div>
                              <InputField
                                name="receiptDateFrmt"
                                placeholder="MM/DD/YYYY"
                                id="receiptDateFrmt"
                                onClick={this.handleDates}
                                label="Application Received Date"
                                onChange={this.handleDate}
                                onBlur={this.handleOnBlur}
                                value={mbrEnrollmentVo.receiptDateFrmt}
                                disabled={!this.state.editable}
                              />
  
                              <div className={classes.validationMessage}>
                                {this.validator.message(
                                  "ApplicationReceivedDate",
                                  mbrEnrollmentVo.receiptDateFrmt,
                                  "date_format"
                                )}
                              </div>
                            </div>
                          ) : null}
                        </div>
                          </div>
  
                          <div className={classes.containerdemo}>
                            {this.state.modorcanClicked ?(
                            <div>
                              <InputField
                                name="receivedDateFrmt"
                                placeholder="MM/DD/YYYY"
                                id="receivedDateFrmt"
                                onClick={this.handleDates}
                                label="Received Date"
                                onChange={this.handleDate}
                                onBlur={this.handleOnBlur}
                                value={mbrEnrollmentVo.receivedDateFrmt}
                                disabled={
                                  !this.state.editable && !this.state.cancellation
                                }
                              />
                              <div className={classes.validationMessage}>
                                {this.state.cancellation
                                  ? this.validator.message(
                                    "ReceivedDate",
                                    mbrEnrollmentVo.receivedDateFrmt,
                                    "required"
                                  )
                                  : null}
                              </div>
                            </div>) : null}
                            <div style={{ width: "410px" }}>
                              <AutoComplete1
                                handleChange={this.handleChangeSearchSelectAuto}
                                label="Cancellation Reason"
                                options={dropdowns.enrollCancelReasons}
                                defaultValue={dropdowns.enrollCancelReasons[0]}
                                value={
                                  dropdowns.enrollCancelReasons.filter(
                                    (data) =>
                                      data.value ===
                                      mbrEnrollmentVo.cancellationReason
                                  )[0]
                                }
                                name="cancellationReason"
                                disabled={
                                  !this.state.editable && !this.state.cancellation
                                }
                                width="370px"
                              />
                              <div className={classes.validationMessage}>
                                {this.state.cancellation
                                  ? this.validator.message(
                                    "cancellationReason",
                                    mbrEnrollmentVo.cancellationReason,
                                    "required"
                                  )
                                  : null}
                              </div>
                            </div>
                          </div>
                        </div>
                       
                      </div>
                    </div>
                  </div>
                </form>
  
                <HistoryData
                  createTime={mbrEnrollmentVo.createTime}
                  createUserId={mbrEnrollmentVo.createUserId}
                  lastUpdtTime={mbrEnrollmentVo.lastUpdtTime}
                  lastUpdtUserId={mbrEnrollmentVo.lastUpdtUserId}
                  isNewSegment={this.state.isNewSegment}
                  reset={this.createNewSegment}
                  addSegment={this.addNewSegment}
                  back={this.goBack}
                  footer="true"
                  milliSec={true}
                />
              </React.Fragment>
            ) : (
                <div> {buttonContainer} </div>
              )}
          </Paper>
        </React.Fragment>
      );
    }
  }
  
  const mapStateToProps = (state) => {
    return {
      enrollData: state.memberSearch.searchResultsVo.mbrEnrollmentList,
      searchResultsVo: state.memberSearch.searchResultsVo,
      mbrSearchCriteria: state.memberSearch.mbrSearchCriteria,
      dropdowns: state.membercache,
      enrollType: state.memberSearch.planType,
      loginProfile: state.loginData.profiles,
      searchCriteriaVo: state.memberSearch.searchCriteriaVo,
      showAllActiveInd: state.memberSearch.showAllActiveIndi,
      servicesEnabled: state.loginData.servicesEnabled,
    };
  };
  
  const mapDispatchToProps = {
    mbrEnrollmentDetails,
    enrollPlanType,
    updateEnrollment,
    getShowAll,
    MemberSearch,
    updateIndEnrollData,
  };
  
  export default connect(
    mapStateToProps,
    mapDispatchToProps
  )(withStyles(Styles)(MbrEnrollment));