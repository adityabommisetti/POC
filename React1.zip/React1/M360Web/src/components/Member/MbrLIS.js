import Checkbox from "@material-ui/core/Checkbox";
import FormLabel from "@material-ui/core/FormLabel";
import Paper from "@material-ui/core/Paper";
import { withStyles } from "@material-ui/core/styles";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import classNames from "classnames";
import isEmpty from "lodash/isEmpty";
import React, { Component } from "react";
import { connect } from "react-redux";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../assets/styles/Theme";
import Modal from "../../components/UI/Modal/Modal";
import * as Type from "../../constants/ConfirmType";
import { LIS_TABLE_HEADER as header } from "../../constants/Headers/MemberHeaders";
import { messages } from "../../constants/Messages";
import {
  getShowAll,
  LISDelete,
  LISDetails,
  LISUpdate,
  updateIndlisData,
} from "../../redux/actions/MemberActions";
import { handleDateChange } from "../../utils/DateFormatter";
import { customValidations } from "../../utils/CustomValidations";
import DataTable from "../Home/DataTable";
import InputField from "../UI/InputField";
import MemberButtonPanel from "../UI/MemberButtonPanel";
import HistoryData from "../UI/MemberHistory";
import Autocomplete1 from "../UI/Select";
import ConfirmBox from "../../utils/PopUp";
import * as DateUtil from "../../utils/DatePicker";

const INITIAL_STATE = {
  customerId: "",
  memberId: "",
  effEndDate: "",
  effStartDate: "",
  overrideInd: "N",
  subsidySourceInd: "",
  subsidySourceDesc: "",
  liCoPayCd: "",
  liCoPayDesc: "",
  licBaeInd: "N",
  lisPctCd: "",
  lisBaeInd: "",
  lisAmt: "0.00",
  spapAmt: "0.00",
  createTime: "",
  createUserId: "",
  lastUpdtTime: "",
  lastUpdtUserId: "",
  message: null,
  type: "",
  frmtCreateTime: "",
  effEndDateFrmt: "99/99/9999",
  effStartDateFrmt: "",
  frmtLastUpdtTime: "",
  showAll: "",
};

class LIS extends Component {
  constructor(props) {
    super(props);
    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
        date_format2: customValidations.date_format99,
        first_day_of_month: customValidations.first_day_of_month,
        last_day_of_month: customValidations.last_day_of_month99,
        after_start_date: customValidations.c_after_or_equal_99,
      },
    });
    this.state = {
      lisVo: INITIAL_STATE,
      showAllData: null,
      lisList: null,
      modified: false,
      isNewSegment: false,
      //showAllActive: true,
      editable: false,
      selectedIndex: 0,
      closePopup: false,
      memberId: this.props.mbrSearchCriteria.memberId,
      rowsPerPage: 10,
      func1: this.showAll.bind(this),
      showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
    };
  }

  handleChangeSearchSelectAuto = async (data, name) => {
    let value = data.value;
    this.setState((prevState) => ({
      lisVo: {
        ...prevState.lisVo,
        [name]: value,
      },
      modified: true,
    }));
  };
  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.mbrSearchCriteria.memberId !== prevState.memberId) {
      if (!isEmpty(nextProps.lisData)) {
        return {
          lisVo: nextProps.lisData[0],
          lisList: nextProps.lisData,
          showAllData: null,
          //showAllActive: true,
          modified: false,
          isNewSegment: false,
          editable: false,
          selectedIndex: 0,
          memberId: nextProps.mbrSearchCriteria.memberId,
          model: prevState.func1(
            nextProps.showAllActiveInd.showAllActiveInd === false ? true : "N",
            nextProps.mbrSearchCriteria.memberId,
            nextProps.showAllActiveInd.showAllActiveInd
          ),
        };
      }
      return {
        lisVo: {
          ...INITIAL_STATE,
          memberId: nextProps.mbrSearchCriteria.memberId,
        },
        lisList: [],
        showAllData: null,
        //showAllActiveInd: true,
        modified: false,
        isNewSegment: false,
        editable: false,
        selectedIndex: 0,
        memberId: nextProps.mbrSearchCriteria.memberId,
        model: prevState.func1(
          nextProps.showAllActiveInd.showAllActiveInd === false ? true : "N",
          nextProps.mbrSearchCriteria.memberId,
          nextProps.showAllActiveInd.showAllActiveInd
        ),
      };
    }
    if (
      nextProps.showAllActiveInd.showAllActiveInd !== prevState.showAllActiveInd
    ) {
      if (nextProps.showAllActiveInd.showAllActiveInd === false) {
        return {
          model: prevState.func1(
            true,
            nextProps.mbrSearchCriteria.memberId,
            nextProps.showAllActiveInd.showAllActiveInd
          ),
        };
      } else if (nextProps.showAllActiveInd.showAllActiveInd === true) {
        return {
          model: prevState.func1(false, nextProps.mbrSearchCriteria.memberId),
        };
      }
      return null;
    }
  }
  async componentDidMount() {
    if (this.props.showAllActiveInd.showAllActiveInd === false) {
      this.showAll(true, this.props.mbrSearchCriteria.memberId);
    } else if (isEmpty(this.props.lisData) && this.props.lisData !== null) {
      const params = this.props.mbrSearchCriteria.memberId + "/N";
      await this.props.LISDetails(params);
      INITIAL_STATE.memberId = this.props.mbrSearchCriteria.memberId;
    }

    if (!isEmpty(this.props.lisData)) {
      this.setState({
        lisVo: this.props.lisData[0],
        lisList: this.props.lisData,
      });
    }
  }

  showAll = async (flag, mbrId, chkin) => {
    const { showAllData } = this.state;
    const memberId = mbrId;
    let chk = chkin ? "/N" : "/Y";
    if (flag) {
      if (showAllData === null) {
        const data = await this.props.getShowAll({
          memberId: memberId + chk,
          url: "MEMBER_LIS_FETCH",
        });

        if (null != data) {
          const selectedVO = data.length > 0 ? data[0] : { ...INITIAL_STATE };
          this.setState(() => ({
            lisList: data,
            lisVo: selectedVO,
            showAllData: null,
            showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
            selectedIndex: 0,
            editable: false,
            isNewSegment: false,
          }));
        }
      } else {
        const selectedVO = !isEmpty(showAllData)
          ? showAllData[0]
          : { ...INITIAL_STATE };

        this.setState(() => ({
          lisVo: selectedVO,
          lisList: showAllData,
          showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
          selectedIndex: 0,
          editable: false,
          isNewSegment: false,
        }));
      }
    } else {
      if (flag === "N") {
        const params = memberId + "/N";
        await this.props.LISDetails(params);
      } else {
        let recodN = await (this.state.lisList === null
          ? []
          : this.state.lisList.filter((role) => role.overrideInd === "N"));

        await this.props.updateIndlisData(recodN);
      }

      const selectedVO = !isEmpty(this.props.lisData)
        ? this.props.lisData[0]
        : { ...INITIAL_STATE };
      this.setState(() => ({
        lisVo: selectedVO,
        lisList: this.props.lisData,
        showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
        selectedIndex: 0,
        editable: false,
        showAllData: null,
      }));
    }
  };

  selectRow = async (index) => {
    const selectedVo = this.state.lisList[index];
    this.setState(() => ({
      lisVo: selectedVo,
      editable: false, // readOnly
      isNewSegment: false, //Not a new SEgment
      modified: false,
      selectedIndex: index,
    }));
  };

  handleChangePage = (index) => {
    this.selectRow(index);
  };

  handleDate = (event) => {
    let name = event.target.name;
    let value = event.target.value;
    this.setState((prevState) => ({
      lisVo: {
        ...prevState.lisVo,
        [name]: handleDateChange(value),
      },
      modified: true,
    }));
  };

  handleNumberChange = (event) => {
    let name = event.target.name;
    let value = event.target.value.replace(/[^0-9]/g, "").trim();
    this.setState((prevState) => ({
      lisVo: {
        ...prevState.lisVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleDecimalChange = (event) => {
    let name = event.target.name;
    let value = event.target.value.replace(/[^0-9]/g, ".").trim();
    this.setState((prevState) => ({
      lisVo: {
        ...prevState.lisVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleStartDate = (event) => {
    const fieldId = "#" + event.target.name;
    var self = this;
    DateUtil.getStartDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        self.setValue(e.target.name, e.target.value);
      });
  };

  handleDates = (event) => {
    let fieldId = "#" + event.target.name;

    var self = this;
    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        self.setValue(e.target.name, e.target.value);
      });
  };

  setValue = (name, value) => {
    this.setState((prevState) => ({
      lisVo: {
        ...prevState.lisVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleChangeSearchSelect = (name) => (event) => {
    let value = event.value ? event.value : event.target.value;
    this.setState((prevState) => ({
      lisVo: {
        ...prevState.lisVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  modelSegment = () => {
    if (this.state.lisVo.overrideInd === "Y") {
      let msg = "This Record is not active ";
      this.setState({ message: msg, closePopup: true });
    } else {
      this.setState({
        editable: true,
        isNewSegment: false,
      });
    }
  };

  createNewSegment = () => {
    this.validator.hideMessages();
    INITIAL_STATE.memberId = this.props.mbrSearchCriteria.memberId;
    this.setState({
      editable: true,
      isNewSegment: true,
      lisVo: {
        ...INITIAL_STATE,
      },
    });
  };

  update = (event) => {
    event.preventDefault();
    if (this.validator.allValid()) {
      ConfirmBox(this.confirmUpdate, Type.UPDATE, this.props);
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  confirmUpdate = async () => {
    const { lisVo } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(lisVo.showAll = val),
    });
    let status = await this.props.LISUpdate(this.state.lisVo);

    if ("success" === status) {
      status = messages.UPDATED_SUCCESSFULLY;
      this.setState({
        message: status,
        isNewSegment: false,
        editable: false,
        modified: false,
        lisVo: this.props.lisData[0],
        lisList: this.props.lisData,
        showAllData: null,
        closePopup: true,
        selectedIndex: 0,
      });
    } else {
      this.setState({
        message: status,
        //isNewSegment: false,
        editable: true,
        modified: true,
        //lisVo: this.props.lisData[0],
        //lisList: this.props.lisData,
        //showAllData: null,
        //closePopup: true,
        //selectedIndex: 0,
      });
    }
  };

  addNewSegment = () => {
    if (this.validator.allValid()) {
      ConfirmBox(this.confirmAddNewSegment, Type.ADD, this.props);
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  confirmAddNewSegment = async () => {
    const { lisVo } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(lisVo.showAll = val),
    });

    let status = await this.props.LISUpdate(this.state.lisVo);

    if ("success" === status) {
      status = messages.INSERTED_SUCCESSFULLY;
      this.setState({
        message: status,
        isNewSegment: false,
        editable: false,
        modified: false,
        lisVo: this.props.lisData[0],
        lisList: this.props.lisData,
        showAllData: null,
        closePopup: true,
        selectedIndex: 0,
      });
    } else {
      this.setState({
        message: status,
        //isNewSegment: false,
        editable: true,
        modified: true,
        //lisVo: this.props.lisData[0],
        //lisList: this.props.lisData,
        //showAllData: null,
        //closePopup: true,
        //selectedIndex: 0,
      });
    }
    /*this.setState({
      message: status,
      isNewSegment: false,
      editable: false,
      modified: false,
      lisVo: this.props.lisData[0],
      lisList: this.props.lisData,
      showAllData: null,
      closePopup: true,
      selectedIndex: 0,
    });*/
  };

  delete = () => {
    if (this.state.lisVo.overrideInd === "Y") {
      let msg = "This Record is not active ";
      this.setState({ message: msg, closePopup: true });
    } else {
      ConfirmBox(this.confirmDelete, Type.DELETE, this.props);
    }
  };

  confirmDelete = async () => {
    const index = this.state.selectedIndex ? this.state.selectedIndex : 0;
    const { lisVo } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(lisVo.showAll = val),
    });

    let status = await this.props.LISDelete(this.state.lisVo);

    let newVO = null;
    if ("success" === status) {
      status = messages.DELETED_SUCCESSFULLY;
    }

    newVO = isEmpty(this.props.lisData)
      ? INITIAL_STATE
      : this.props.lisData[index];

    this.setState({
      lisVo: newVO,
      lisList: this.props.lisData,
      showAllData: null,
      closePopup: true,
      message: status,
      selectedIndex: 0,
      isNewSegment: false,
      editable: false,
      modified: false,
    });
  };

  goBack = () => {
    const index = this.state.selectedIndex;
    const { lisData } = this.props;
    let lisVo = INITIAL_STATE;

    if (!isEmpty(lisData)) {
      lisVo = lisData[index];
    }
    this.setState({
      isNewSegment: false,
      editable: false,
      modified: false,
      lisVo: lisVo,
    });
    this.validator.hideMessages();
  };

  checked = () => {
    this.setState({
      reset: !this.state.reset,
    });
  };

  handleCheckBox = (name) => (event) => {
    let val = event.target.value === "Y" ? "N" : "Y";

    this.setState((prevState) => ({
      lisVo: {
        ...prevState.lisVo,
        [name]: val,
      },
      modified: true,
    }));
  };

  modalClosed = () => {
    this.setState({ closePopup: false });
  };
  handleChangeRowsPerPage = async (rowsPerPage) => {
    await this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  render() {
    const { classes, dropdowns } = this.props;
    const {
      lisList,
      lisVo,
      selectedIndex,
      modified,
      editable,
      showAllActive,
      isNewSegment,
    } = this.state;

    let ButtonPanel = (
      <MemberButtonPanel
        isNewSegment={this.state.isNewSegment}
        showAll={this.showAll}
        newSegment={this.createNewSegment}
        modelSegment={this.modelSegment}
        delete={this.delete}
        update={this.update}
        modified={modified}
        toggleLabel={showAllActive}
        editable={editable}
        disable={isEmpty(lisList)}
      />
    );
    return (
      <React.Fragment>
        <Modal
          dialogTitle="LIS"
          message={this.state.message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Paper
          elevation={0}
          className={classNames(classes.card, "animated fadeIn")}
        >
          <DataTable
            data={!isEmpty(lisList) ? lisList : []}
            header={header}
            rowsPerPage={this.state.rowsPerPage}
            clicked={this.selectRow}
            index={selectedIndex}
            sortable={true}
            rowsPerPageOptions={[10, 15, 20]}
            handleChangeRowsPerPage={this.handleChangeRowsPerPage}
            handleChangePage={this.handleChangePage}
            dateColumn={["effStartDateFrmt", "effEndDateFrmt"]}
            subtab
          />

          {(!isEmpty(lisList) && this.state.lisVo) || isNewSegment ? (
            <React.Fragment>
              <form autoComplete="off">
                <div className={classes.buttonContainer}>{ButtonPanel}</div>

                <div class="panel-body margin-top1">
                  <div className={classes.container}>
                    <div className={classes.input1}>
                      <InputField
                        name="effStartDateFrmt"
                        placeholder="MM/DD/YYYY"
                        onClick={this.handleStartDate}
                        label="Start Date"
                        width="180px"
                        maxLength={10}
                        value={lisVo.effStartDateFrmt}
                        onChange={this.handleDate}
                        disabled={!this.state.editable}
                        required={this.state.editable}
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "StartDate",
                          lisVo.effStartDateFrmt,
                          "required|date_format"
                        )}
                      </div>
                    </div>
                    <div>
                      <InputField
                        name="effEndDateFrmt"
                        placeholder="MM/DD/YYYY"
                        onClick={this.handleDates}
                        label="End Date"
                        required={this.state.editable}
                        maxLength={10}
                        value={lisVo.effEndDateFrmt}
                        onChange={this.handleDate}
                        disabled={!this.state.editable}
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "EndDate",
                          lisVo.effEndDateFrmt,
                          [
                            "required",
                            "date_format2",
                            "last_day_of_month",
                            {
                              after_start_date: lisVo.effStartDateFrmt,
                            },
                          ]
                        )}
                      </div>
                    </div>
                    <div>
                      <InputField
                        name="overrideInd"
                        label="Override"
                        value={lisVo.overrideInd}
                        disabled={true}
                      />
                      <div className={classes.validationMessage}></div>
                    </div>

                    <div className={classes.Select2}>
                      <Autocomplete1
                        handleChange={this.handleChangeSearchSelectAuto}
                        label="Copay"
                        options={dropdowns.validLiCopays}
                        defaultValue={dropdowns.validLiCopays[0]}
                        value={
                          dropdowns.validLiCopays.filter(
                            (data) => data.value === this.state.lisVo.liCoPayCd
                          )[0]
                        }
                        name="liCoPayCd"
                        disabled={!this.state.editable}
                        width="180px"
                        margin="0px"
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "Copay",
                          lisVo.liCoPayCd.trim(),
                          "required"
                        )}
                      </div>
                    </div>

                    <div className={classes.Select2}>
                      <Autocomplete1
                        handleChange={this.handleChangeSearchSelectAuto}
                        label="Subsidy Source"
                        options={dropdowns.validSubsidySrce}
                        defaultValue={dropdowns.validSubsidySrce[0]}
                        value={
                          dropdowns.validSubsidySrce.filter(
                            (data) =>
                              data.value === this.state.lisVo.subsidySourceInd
                          )[0]
                        }
                        name="subsidySourceInd"
                        disabled={!this.state.editable}
                        width="300px"
                        margin="0px"
                      />
                      <div className={classes.validationMessageSelect}></div>
                    </div>

                    <div className={classes.containerdemo}>
                      <div className={classes.Select1}>
                        <Autocomplete1
                          handleChange={this.handleChangeSearchSelectAuto}
                          label="Percent"
                          options={dropdowns.validLiPercents}
                          defaultValue={dropdowns.validLiPercents[0]}
                          value={
                            dropdowns.validLiPercents.filter(
                              (data) => data.value === this.state.lisVo.lisPctCd
                            )[0]
                          }
                          name="lisPctCd"
                          disabled={!this.state.editable}
                          width="180px"
                          margin="0px"
                        />
                        <div className={classes.validationMessage}>
                          {this.validator.message(
                            "Percent",
                            this.state.lisVo.lisPctCd.trim(),
                            "required"
                          )}
                        </div>
                      </div>
                      <div style={{ paddingTop: "18px" }}>
                        <div
                          className={classes.Checkbox}
                          style={{ width: "182px" }}
                        >
                          <FormLabel classes={{ root: classes.formLabel }}>
                            LIS BAE
                          </FormLabel>
                          <Checkbox
                            icon={
                              <CheckBoxOutlineBlankIcon
                                style={{ fontSize: "11px" }}
                              />
                            }
                            checkedIcon={
                              <CheckBoxIcon
                                className={classes.checkboxmember}
                              />
                            }
                            disabled={!this.state.editable}
                            checked={
                              this.state.lisVo.lisBaeInd === "Y" ? true : false
                            }
                            onClick={this.handleCheckBox("lisBaeInd")}
                            value={this.state.lisVo.lisBaeInd}
                            inputProps={{
                              "aria-label": "primary checkbox",
                            }}
                          />

                          <FormLabel classes={{ root: classes.formLabel }}>
                            LIC BAE
                          </FormLabel>
                          <Checkbox
                            icon={
                              <CheckBoxOutlineBlankIcon
                                style={{ fontSize: "11px" }}
                              />
                            }
                            checkedIcon={
                              <CheckBoxIcon
                                className={classes.checkboxmember}
                              />
                            }
                            disabled={!this.state.editable}
                            checked={
                              this.state.lisVo.licBaeInd === "Y" ? true : false
                            }
                            onClick={this.handleCheckBox("licBaeInd")}
                            value={this.state.lisVo.licBaeInd}
                            inputProps={{
                              "aria-label": "primary checkbox",
                            }}
                          />
                        </div>
                      </div>

                      <div>
                        <InputField
                          name="lisAmt"
                          label="LIS Amount"
                          value={this.state.lisVo.lisAmt}
                          onChange={this.handleDecimalChange}
                          maxLength={11}
                          disabled={!this.state.editable}
                          placeholder="0.00"
                        // required={this.state.editable}
                        />
                        <div className={classes.validationMessage}>
                          {this.validator.message(
                            "LisAmount",
                            this.state.lisVo.lisAmt,
                            "inpuRequired|amountValidator"
                          )}
                        </div>
                      </div>

                      <div>
                        <InputField
                          name="spapAmt"
                          label="SPAP Amount"
                          value={lisVo.spapAmt}
                          width="180px"
                          onChange={this.handleDecimalChange}
                          maxLength={11}
                          disabled={!this.state.editable}
                          placeholder="0.00"
                        />
                        <div className={classes.validationMessage}>
                          {this.validator.message(
                            "SpapAmount",
                            lisVo.spapAmt,
                            "inpuRequired|amountValidator"
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </form>

              <HistoryData
                createTime={lisVo.createTime}
                createUserId={lisVo.createUserId}
                lastUpdtTime={lisVo.lastUpdtTime}
                lastUpdtUserId={lisVo.lastUpdtUserId}
                isNewSegment={this.state.isNewSegment}
                reset={this.createNewSegment}
                addSegment={this.addNewSegment}
                back={this.goBack}
                footer="true"
              />
            </React.Fragment>
          ) : (
              <div className={classes.buttonContainer}> {ButtonPanel}</div>
            )}
        </Paper>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  lisData: state.memberSearch.searchResultsVo.mbrLisInfoList,
  dropdowns: state.membercache,
  searchResultsVo: state.memberSearch.searchResultsVo,
  mbrSearchCriteria: state.memberSearch.mbrSearchCriteria,
  memberIdCheck: state.memberSearch.memberId,
  showAllActiveInd: state.memberSearch.showAllActiveIndi,
});

const mapDispatchToProps = {
  LISDetails,
  LISUpdate,
  LISDelete,
  getShowAll,
  updateIndlisData,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(LIS));
