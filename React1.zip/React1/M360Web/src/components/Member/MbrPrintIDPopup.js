import * as DateUtil from "../../utils/DatePicker";
import React, { Component } from "react";
import InputField from "../UI/InputField";
import Paper from "@material-ui/core/Paper";
import { Styles } from "../../assets/styles/PopupTheme";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";
import { RadioGroup } from "@material-ui/core";
import Radio from "@material-ui/core/Radio";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Button from "@material-ui/core/Button";
import moment from "moment";
import { printIdcard } from "../../redux/actions/MemberActions";
import Modal from "../../components/UI/Modal/Modal";
import classNames from "classnames";

import {
  PRINTID_QUESTIONS_SET1 as DATA1,
  PRINTID_QUESTIONS_SET2 as DATA2,
  PRINTID_ADDITIONAL_QUESTIONS as DATA3,
} from "../../constants/staticData//MbrPrintIdStaticData";
import { handleDateChange } from "../../utils/DateFormatter";
class PrintIDCardPopup extends Component {
  constructor(props) {
    super(props);
    this.state = {
      closePopup: false,
      message: "",
      value: "",
      printIdc: {},
      printIdcText: {},
      effStartDateFrmt: this.props.effStartDateFrmt,
      mbridLit: [],
    };
  }

  componentDidMount() {
    const { loginProfile } = this.props;
    const PRINTIDC = loginProfile.filter((data) => data.label === "PRINTIDC");

    const PRINTIDC_TEXT = loginProfile.filter(
      (data) => data.label === "PRINTIDC_TEXT"
    );
    const MBRIDLIT = loginProfile.filter((data) => data.label === "MBRIDLIT");
    this.setState({
      printIdc: PRINTIDC[0],
      printIdcText: PRINTIDC_TEXT[0],
      mbridLit: MBRIDLIT[0],
    });
  }
  handleChange = (event) => {
    if (event.target.name === "effStartDateFrmt") {
      this.setState({
        effStartDateFrmt: handleDateChange(event.target.value),
      });
    } else {
      this.setState({
        value: event.target.value,
      });
    }
  };

  onSubmit = async (event) => {
    event.preventDefault();
    const { memberId, planId, pbpId, planDesignation } = this.props;
    const effStartDateFrmt = this.state.effStartDateFrmt;

    const { value } = this.state;
    let body = {
      memberId: memberId,
      planId: planId,
      pbpId: pbpId,
      planDesignation: planDesignation,
      printCode: value,
      effectiveStartDate: effStartDateFrmt,
    };
    let message = "";
    if (value === "") {
      message = "Please Select Print Code";
    } else if (!moment(effStartDateFrmt, "MM/DD/YYYY", true).isValid()) {
      message = "Please Enter Valid Date";
    } else {
      message = await this.props.printIdcard(body);
      if (message === "success") {
        message = "PRINT MATERIAL REQUEST SUBMITTED.";
      }
    }
    this.setState({
      closePopup: true,
      message: message,
    });

    //this.props.close();
  };

  reset = () => {
    this.setState(() => ({
      value: "",
      effStartDateFrmt: "",
    }));
  };

  modalClosed = () => {
    this.setState({ closePopup: false });
  };

  handleDates = (event) => {
    event.persist();
    event.preventDefault();
    // console.log(event);
    var self = this;
    const fieldId = "#" + event.target.id;
    DateUtil.getDatePickerPopup(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        self.setDate(e.target.id, e.target.value);
        document.getElementById(fieldId.substr(1)).focus();
      });
  };

  setDate = (name, value) => {
    this.setState({
      effStartDateFrmt: value,
      modified: true,
    });
  };

  render() {
    const { classes, memberId, planId, pbpId, planDesignation } = this.props;

    const {
      value,
      printIdc,
      printIdcText,
      message,
      closePopup,
      effStartDateFrmt,
      mbridLit
    } = this.state;

    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE ");
let divMargin = '0vw'
    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./))  // If Internet Explorer, return version number
    {
      divMargin = '-15vw'
    }
    return (
      <React.Fragment>
        <Modal
          dialogTitle="Print ID Card"
          message={message}
          show={closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Paper
          className={classes.root}
          elevation={0}
          style={{ padding: "15px" }}
        >
          <fieldset className={classes.fieldset}>
            <legend className={classes.legend}>Print ID Card</legend>
            <form autoComplete="off">
              <div className={classes.container}>
                <div className={classes.printIdInputFieldDiv}>
                  <InputField
                    name="memberId"
                    label={mbridLit.value === "TSA" ? "Wipro ID" : "M360 ID"}
                    className={classes.textField}
                    value={memberId}
                    disabled
                  />
                </div>
                <div className={classes.printIdInputFieldDiv}>
                  <InputField
                    name="planId"
                    label="Plan"
                    className={classes.textField}
                    value={planId}
                    disabled
                  />
                </div>
                <div className={classes.printIdInputFieldDiv}>
                  <InputField
                    name="pbpId"
                    label="PBP Id"
                    className={classes.textField}
                    value={pbpId}
                    disabled
                  />
                </div>
                <div className={classes.printIdInputFieldDiv}>
                  <InputField
                    name="planDesignation"
                    label="Designation"
                    className={classes.textField}
                    value={planDesignation}
                    disabled
                  />
                </div>
                <div className={classes.printIdInputFieldDiv}>
                  <InputField
                    name="effStartDateFrmt"
                    placeholder="MM/DD/YYYY"
                    label="Effective Start Date"
                    className={classes.textField}
                    value={effStartDateFrmt}
                    onChange={this.handleChange}
                    onClick={this.handleDates}
                  />
                </div>
              </div>

              <div>
                <div style={{ marginTop: "18px", textAlign: "center" }}>
                  <h4>Print Codes</h4>
                </div>
                <div style={{ marginBottom: "18px", marginLeft: "75px"}}>
                  <RadioGroup
                    aria-label="quiz"
                    name="quiz"
                    style={{ flexDirection: "row", textAlign: "left" }}
                  >
                    {printIdc != null &&
                      printIdc.value === "Y" &&
                      printIdcText.value === "SHOW_ALL_QUES" ? (
                        <>
                          {DATA1.map((data) => (
                            <div className={classes.printCodesDiv} key={data}>
                              <FormControlLabel
                                control={
                                  <Radio
                                    onChange={(e) => this.handleChange(e)}
                                    value={data.value}
                                    checked={data.value === value}
                                    color="primary"
                                    style={{ padding: "5px 5px 5px 5px" }}
                                  />
                                }
                                label={data.label}
                              />
                            </div>
                          ))}
                        </>
                      ) : (
                        <>
                          {DATA2.map((data) => (
                            <div className={classes.printCodesDiv} key={data}>
                              <FormControlLabel
                                control={
                                  <Radio
                                    onChange={(e) => this.handleChange(e)}
                                    value={data.value}
                                    checked={data.value === value}
                                    color="primary"
                                    style={{ padding: "5px 5px 5px 5px" }}
                                  />
                                }
                                label={data.label}
                              />
                            </div>
                          ))}

                          {printIdc != null &&
                            printIdcText.value === "SHOW_ADDL_QUE" ? (
                              <>
                                {DATA3.map((data) => (
                                  <div className={classes.printCodesDiv} key={data}>
                                    <FormControlLabel
                                      control={
                                        <Radio
                                          onChange={(e) => this.handleChange(e)}
                                          value={data.value}
                                          checked={data.value === value}
                                          color="primary"
                                          style={{ padding: "5px 5px 5px 5px" }}
                                        />
                                      }
                                      label={data.label}
                                    />
                                  </div>
                                ))}
                              </>
                            ) : null}
                        </>
                      )}
                  </RadioGroup>
                </div>

                <div className={classes.div3} style={{transform: 'translateX('+divMargin+''+')'}}>
                  <Button
                    variant="contained"
                    color="primary"
                    className={classes.button}
                    onClick={this.props.close}
                  >
                    <i className="material-icons">cancel</i>
                  </Button>
                  <Button
                    type="submit"
                    variant="contained"
                    color="primary"
                    className={classNames(classes.button, classes.submit)}
                    onClick={this.onSubmit}
                  >
                    submit
                  </Button>
                  <Button
                    variant="contained"
                    color="primary"
                    className={classes.button}
                    onClick={this.reset}
                  >
                    <i class="material-icons">refresh</i>
                  </Button>
                </div>
              </div>
            </form>
          </fieldset>
        </Paper>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    loginProfile: state.loginData.profiles,
  };
};

const mapDispatchToProps = {
  printIdcard,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(PrintIDCardPopup));
