import React, { Component } from "react";
import { getSoaPdf, openPDFDocSoa } from "../../redux/actions/MemberActions";
import Paper from "@material-ui/core/Paper";
import { Styles } from "../../assets/styles/Theme";
import classNames from "classnames";
import { connect } from "react-redux";
import Button from "@material-ui/core/Button";
import isEmpty from "lodash/isEmpty";
import { withStyles } from "@material-ui/core/styles";
import Modal from "../../components/UI/Modal/Modal";

class SOA extends Component {
  constructor(props) {
    super(props);
    this.state = {
      memberId: this.props.mbrSearchCriteria.memberId,
      message:'',
      closePopup: false,
  }
}

 async   componentDidMount() {
    if (isEmpty(this.props.soaData.data)) {
       await this.props.getSoaPdf(this.props.mbrSearchCriteria.memberId);
    }
  }
  async componentDidUpdate(){
    if(this.state.memberId !== this.props.mbrSearchCriteria.memberId){
      this.setState({memberId:this.props.mbrSearchCriteria.memberId})
      await  this.props.getSoaPdf(this.props.mbrSearchCriteria.memberId);
    }
  }

  modalClosed = () => {
    this.setState({ closePopup: false });
  };

openPdf =()=>{
  
  if(this.props.soaData && this.props.soaData.data ){
    
    this.props.openPDFDocSoa(this.props.soaData.data)
  }else{
    
    this.setState({message:this.props.soaData.message,closePopup: true})
  }
}
  render() {
    const { classes } = this.props;

    return (
      <Paper
        elevation={0}
        className={classNames(classes.card, "animated fadeIn")}
      >
      <div style={{float:'right',padding: '1vw'}}>
        <Modal
          dialogTitle="SOA"
          message={this.state.message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
      <Button
          variant="contained"
          color="primary"
          onClick={()=>{this.openPdf()}}
          // className={props.classes.button}
          // disabled={ props.disable}
          id="ModelButton"
        >
          View PDF
        </Button>
      </div>
      </Paper>
    );
  }
}
const mapStateToProps = state => {
  return {
    soaData: state.memberSearch.searchResultsVo.mbrSoaPdf,
    mbrSearchCriteria: state.memberSearch.mbrSearchCriteria
  };
};
const mapDispatchToProps = {
   getSoaPdf,
   openPDFDocSoa
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(SOA));
