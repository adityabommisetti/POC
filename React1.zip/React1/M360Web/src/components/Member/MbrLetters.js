import React, { Component } from "react";
import {
  memberData,
  memberLetterData,
} from "../../redux/actions/MemberActions";
import {
  LETTERS_TABLE_HEADER as header,
  LETTER_DETAILS_TABLE_HEADER as letterHeader,
} from "../../constants/Headers/MemberHeaders";
import isEmpty from "lodash/isEmpty";
import DataTable from "../Home/DataTable";
import HistoryData from "../UI/MemberHistory";
import InputField from "../UI/InputField";
import Paper from "@material-ui/core/Paper";
import { Styles } from "../../assets/styles/Theme";
import classNames from "classnames";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";

class MbrLetter extends Component {
  state = {
    letterVo: null,
    memberId: this.props.mbrSearchCriteria.memberId,
    selectedIndex: 0,
    rowsPerPage: 10,
  };

  selectRow = (index) => {
    const data = [...this.props.getMemberData];
    const selectedVo = data[index];
    const memberData = {
      fileBatchId: this.props.getMemberData[index].filebatchid,
      recordType: this.props.getMemberData[index].recordType,
      primaryId: this.props.getMemberData[index].primaryId,
      letterName: this.props.getMemberData[index].letterName,
    };
    this.props.memberLetterData(memberData);

    this.setState(() => ({
      letterVo: {
        ...selectedVo,
      },
      selectedIndex: index,
    }));
  };

  async componentDidMount() {
    if (
      isEmpty(this.props.getMemberData) &&
      this.props.getMemberData !== null
    ) {
      await this.props.memberData(this.props.mbrSearchCriteria.memberId);
    }
    const letterVo = !isEmpty(this.props.getMemberData)
      ? this.props.getMemberData[0]
      : null;
    this.setState({ letterVo: letterVo });
  }

  async componentDidUpdate() {
    if (
      this.state.memberId !== this.props.mbrSearchCriteria.memberId //&&
      //this.props.letterDetails === null
    ) {
      this.setState({
        // calling twice if state was not set hear
        memberId: this.props.mbrSearchCriteria.memberId,
        selectedIndex: 0,
      });
      // await this.props.memberData(this.props.mbrSearchCriteria.memberId);
      if (!isEmpty(this.props.getMemberData)) {
        const memberData = {
          fileBatchId: this.props.getMemberData[0].filebatchid,
          recordType: this.props.getMemberData[0].recordType,
          primaryId: this.props.getMemberData[0].primaryId,
          letterName: this.props.getMemberData[0].letterName,
        };
        this.props.memberLetterData(memberData);
        const letterVo = !isEmpty(this.props.getMemberData)
          ? this.props.getMemberData[0]
          : null;
        this.setState({ letterVo: letterVo });
      } else {
        this.setState({ letterVo: null });
      }
    }
  }

  handleChangePage = (index) => {
    this.selectRow(index);
  };

  handleChangeRowsPerPage = async (rowsPerPage) => {
    await this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  render() {
    const { classes } = this.props;
    const { letterVo } = this.state;

    return (
      <Paper
        elevation={0}
        className={classNames(classes.card, "animated fadeIn")}
      >
        <DataTable
          data={this.props.getMemberData ? this.props.getMemberData : []}
          header={header}
          sortable={true}
          rowsPerPageOptions={[10, 15, 20]}
          handleChangeRowsPerPage={this.handleChangeRowsPerPage}
          rowsPerPage={this.state.rowsPerPage}
          clicked={this.selectRow}
          index={this.state.selectedIndex}
          handleChangePage={this.handleChangePage}
          subtab
        />

        {letterVo && !isEmpty(this.props.getMemberData) ? (
          <form autoComplete="off">
            <div className="panel-body">
              <div className={classes.container}>
                <div>
                  <InputField
                    name="letter"
                    label="Letter"
                    width="370px"
                    value={letterVo.letterName}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div className={classes.mbrLetterStatus}>
                  <InputField
                    name="letterstatus"
                    label="Letter Status"
                    value={letterVo.recordStatus}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    id="delete"
                    name="delete"
                    label="Delete"
                    value={letterVo.delete}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="reqdate"
                    placeholder="MM/DD/YYYY"
                    label="Request Date"
                    value={letterVo.requestDateFrmt}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="originalmaildt"
                    placeholder="MM/DD/YYYY"
                    label="Orig Mail Date"
                    value={letterVo.origMailDateFrmt}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="lastmaildt"
                    placeholder="MM/DD/YYYY"
                    label="Last Mail Date"
                    value={letterVo.lastMailDateFrmt}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="printreqdt"
                    placeholder="MM/DD/YYYY"
                    label="Print Request Date"
                    value={letterVo.requestDateFrmt} // printReqDateFrmt
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="printdt"
                    placeholder="MM/DD/YYYY"
                    label="Date Printed"
                    value={letterVo.printDateFrmt}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="reprintdt"
                    placeholder="MM/DD/YYYY"
                    label="Reprint Date"
                    value={letterVo.reprintDateFrmt}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="responseduedt"
                    placeholder="MM/DD/YYYY"
                    label="Response Due Date"
                    value={letterVo.responseDueDateFrmt}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>

                <div>
                  <InputField
                    name="responsedt"
                    placeholder="MM/DD/YYYY"
                    label="Response Date"
                    value={letterVo.responseDateFrmt}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
              </div>

              <div className={classes.container}>
                <InputField
                  name="letterdesc"
                  label="Letter Description"
                  value={letterVo.description}
                  disabled
                  width="580px"
                />
                <div className={classes.validationMessage} />
              </div>
            </div>
          </form>
        ) : (
          ""
        )}
        <br />
        {!isEmpty(this.props.getMemberData) &&
        !isEmpty(this.props.letterDetails) ? (
          <div className={classes.letter}>
            <DataTable
              data={this.props.letterDetails}
              header={letterHeader}
              rowsPerPage={this.props.letterDetails.length}
              clicked={() => {}}
              index={0}
              selectedRow="true"
              removePagination="true"
            />
          </div>
        ) : null}
        {this.state.letterVo ? (
          <HistoryData
            footer="true"
            createUserId={this.state.letterVo.createUserId}
            createTime={this.state.letterVo.createTime}
            lastUpdtTime={this.state.letterVo.lastUpdtTime}
            lastUpdtUserId={this.state.letterVo.lastUpdtUserId}
          />
        ) : (
          ""
        )}
      </Paper>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    memberIdCheck: state.memberSearch.memberId,
    getMemberData: state.memberSearch.searchResultsVo.mbrLetterList,
    letterDetails: state.memberSearch.letterDetails,
    mbrSearchCriteria: state.memberSearch.mbrSearchCriteria,
    showAllActiveInd: state.memberSearch.showAllActiveIndi,
  };
};
const mapDispatchToProps = {
  memberData,
  memberLetterData,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(MbrLetter));
