import * as DateUtil from "../../utils/DatePicker";
import * as Type from "../../constants/ConfirmType";
import Modal from "../../components/UI/Modal/Modal";
import * as ActionTypes from "../../redux/types/ActionType";
import {
  ASES_SELECT,
  ASES_STATUS_LIST,
} from "../../constants/AsesInitialState";
import {
  ASES_INFO_DATA as DATA,
  ENROLLMENT_DATA as EnrollmentVo,
} from "../../constants/staticData/MemberStaticData";
import React, { Component } from "react";
import AutoComplete1 from "../UI/Select";

import ConfirmBox from "../../utils/PopUp";
import DataTable from "../Home/DataTable";
import HistoryData from "../UI/MemberHistory";
import InputField from "../UI/InputField";
import MemberButtonPanel from "../UI/MemberButtonPanel";
import Paper from "@material-ui/core/Paper";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../assets/styles/Theme";
import classNames from "classnames";
import { ASESINFO_HEADER as header } from "../../constants/Headers/MemberHeaders";
import moment from "moment";
import { withStyles } from "@material-ui/core/styles";
import isEmpty from "lodash/isEmpty";
import { connect } from "react-redux";
import {
  getAses,
  insetUpdateAses,
  updateIndAsesData,
  deleteAses,
  getShowAll,
} from "../../redux/actions/MemberActions";
const INITIAL_STATE = {
  costSharing: "",
  createTime: "",
  createUserId: "",
  customerId: "",
  deceasedDt: "",
  effEndDate: "",
  effEndDateFrmt: "99/99/9999",
  effStartDate: "",
  effStartDateFrmt: "",
  extFlag: "",
  grpCd: "",
  lastUpdtTime: "",
  lastUpdtUserId: "",
  maxCopy: "",
  mbrSuffix: "",
  overrideInd: "",
  memberId: "",
  mpi: "",
  odsiFamilyId: "",
  overrideInd: "",
  planVersion: "",
  planVersionChangeInd: "",
  regionCode: "",
  showAll: null,
  spendDwnFlg: "",
  status: "",
  type: null,
};

class Ases extends Component {
  constructor(props) {
    super(props);
    this.state = {
      closePopup: false,
      asesInfoVo: INITIAL_STATE,
      data: DATA,
      editable: false,
      modified: false,
      showAllActive: false,
      //showAll: false,
      loading: false,
      isNewSegment: false,
      selectedIndex: 0,
      func1: this.showAll.bind(this),
      memberId: this.props.mbrSearchCriteria.memberId,
      showAllData: null,
      mbrAsesList: null,
      rowsPerPage: 10,
    };
    this.validator = new SimpleReactValidator({
      validators: {
        date_format: {
          message: ":attribute is incorrect \n Please format as MM/DD/YYYY",
          rule: (val, params, validator) => {
            if (val === "99/99/9999") {
              return true;
            }
            if (moment(val, "MM/DD/YYYY", true).format() === "Invalid date") {
              return false;
            }
          },
        },
        startDateValidation: {
          message: ":attribute is not the first day of the month",
          rule: (val, params, validator) => {
            if (
              !(this.state.asesInfoVo.effStartDateFrmt.substring(3, 5) === "01")
            ) {
              return false;
            }
          },
        },
        endDateValidation: {
          message: ":attribute is not the last day of the month",
          rule: (val, params, validator) => {
            if (val === "99/99/9999") {
              return true;
            }
            if (
              !(
                moment(this.state.asesInfoVo.effEndDateFrmt)
                  .endOf("month")
                  .format("DD") ===
                this.state.asesInfoVo.effEndDateFrmt.substring(3, 5)
              )
            ) {
              return false;
            }
          },
        },
        startDateGreater: {
          message: "Start Date Greater Than End Date",
          rule: (val, params, validator) => {
            if (
              moment(
                this.state.asesInfoVo.effStartDateFrmt,
                "MM/DD/YYYY"
              ).format() >=
              moment(
                this.state.asesInfoVo.effEndDateFrmt,
                "MM/DD/YYYY"
              ).format()
            ) {
              return false;
            }
          },
        },
      },
    });
  }

  handlechange = (name) => (event) => {
    let value = event.target.value.toUpperCase();
    this.setState((prevState) => ({
      asesInfoVo: {
        ...prevState.asesInfoVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleOnBlur = (event) => {
    let value = event.target.value.trim();
    let name = event.target.name;
    this.setState((prevState) => ({
      asesInfoVo: {
        ...prevState.asesInfoVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleChangeSearchSelectAuto = (data, name) => {
    let value = data.value;
    this.setState((prevState) => ({
      asesInfoVo: {
        ...prevState.asesInfoVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleStartDate = (fieldId) => {
    var self = this;
    DateUtil.getStartDatePicker(fieldId).on("change", (e) => {
      self.setDate(e.target.name, e.target.value);
    });
  };

  handleDates = (fieldId) => {
    var self = this;
    DateUtil.getDatePicker(fieldId).on("change", (e) => {
      self.setDate(e.target.name, e.target.value);
    });
  };

  setDate = (name, value) => {
    this.setState((prevState) => ({
      asesInfoVo: {
        ...prevState.asesInfoVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  goBack = () => {
    this.validator.hideMessages();
    // const data = [...this.props.asesData];
    let selectedVo = INITIAL_STATE;

    if (!isEmpty(this.props.asesData)) {
      selectedVo = this.props.asesData[this.state.selectedIndex];
    }

   // const selectedVo = data[this.state.selectedIndex];
    this.setState(() => ({
      asesInfoVo: {selectedVo },
      isNewSegment:false,
      isNewSegment: false,
      editable: false,
      modified: false,
    }));
  };

  selectRow = (index) => {
    const data = [...this.props.asesData];
    const selectedVo = data[index];
    this.validator.hideMessages()
    this.setState(() => ({
      asesInfoVo: { ...selectedVo },
      editable: false,
      isNewSegment: false,
      modified: false,
      selectedIndex: index,
    }));
  };

  modelSegment = () => {
    this.validator.hideMessages()
    this.setState({
      editable: true,
      isNewSegment: false,
    });
  };

  createNewSegment = () => {
    this.validator.hideMessages()
    this.setState({
      editable: true,
      isNewSegment: true,
      asesInfoVo: {
        ...this.state.asesInfoVo,
        ...INITIAL_STATE,
      },
    });
  };

  /*Validation is pending*/
  addNewSegment = (event) => {
    this.validator.hideMessages();
    event.preventDefault();
    if (this.validator.allValid()) {
      ConfirmBox(this.confirmAddAsesInfo, Type.ADD, this.props);
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  modalClosed = () => {
    this.setState({ closePopup: false });
  };

  confirmAddAsesInfo = async () => {
    const { asesInfoVo } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(asesInfoVo.showAll = val),
    });
    let payload = {
      ...asesInfoVo,
      memberId: this.props.mbrSearchCriteria.memberId,
    };
    let status = await this.props.insetUpdateAses(payload);
    if ("success" === status) {
      status = ActionTypes.ADD;
      let newVO = isEmpty(this.props.asesData)
        ? INITIAL_STATE
        : this.props.asesData[0];
      let asesData = isEmpty(this.props.asesData) ? [] : this.props.asesData;
      this.setState({
        message: status,
        isNewSegment: false,
        editable: false,
        modified: false,
        asesInfoVo: newVO,
        mbrAsesList: asesData,
        showAllData: null,
        closePopup: true,
        selectedIndex: 0,
      });
    } else {
      this.setState({
        message: status,
        closePopup: true,
      });
    }

    this.validator.hideMessages();
  };

  updateAsesInfo = (event) => {
    event.preventDefault();
    if (this.validator.allValid()) {
      var d1 = EnrollmentVo[0].effStartDateFrmt;
      var d2 = this.state.asesInfoVo.effStartDateFrmt;
      if (this.state.asesInfoVo.status === "ASESENRSUB") {
        if (
          EnrollmentVo[0].status === "EAPRV" &&
          EnrollmentVo[0].cmsStatus === "CMSAPRV" &&
          d1 <= d2
        ) {
          return true;
        } else {
          alert("Member is Inactive or not in EAPRV/CMSAPRV status");
          return false;
        }
      } else {
        ConfirmBox(this.confirmUpdate, Type.UPDATE, this.props);
      }
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  confirmUpdate = async () => {
    const { asesInfoVo } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(asesInfoVo.showAll = val),
    });
    let payload = {
      ...this.state.asesInfoVo,
      memberId: this.props.mbrSearchCriteria.memberId,
    };
    let status = await this.props.insetUpdateAses(payload);

    if ("success" === status) {
      status = ActionTypes.UPDATE;

      let newVO = isEmpty(this.props.asesData)
        ? INITIAL_STATE
        : this.props.asesData[this.state.selectedIndex];
      this.setState(() => ({
        message: status,
        isNewSegment: false,
        editable: false,
        modified: false,
        asesInfoVo: newVO,
        mbrAsesList: this.props.asesData,
        showAllData: null,
        closePopup: true,
      }));
    } else {
      this.setState(() => ({
        message: status,
        closePopup: true,
      }));
    }
  };

  deleteAsesInfo = () => {
    ConfirmBox(this.confirmDelete, Type.DELETE, this.props);
  };

  confirmDelete = async () => {
    const { asesInfoVo } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(asesInfoVo.showAll = val),
    });

    let payload = {
      ...asesInfoVo,
      memberId: this.props.mbrSearchCriteria.memberId,
    };
    let status = await this.props.deleteAses(payload);
    let newVO = isEmpty(this.props.asesData)
      ? INITIAL_STATE
      : this.props.asesData[0];
    let message = "";
    if (status === "success") {
      message = ActionTypes.DELETE;
    } else {
      message = status;
    }

    this.setState({
      asesInfoVo: newVO,
      mbrAsesList: this.props.asesData,
      showAllData: null,
      closePopup: true,
      message: message,
      selectedIndex: 0,
      isNewSegment: false,
      editable: false,
      modified: false,
    });
    this.validator.hideMessages();
  };

  showAll = async (flag, mbrId) => {
    const memberId = mbrId;
    const { showAllData } = this.state;

    if (flag === true) {
      if (showAllData === null) {
        const data = await this.props.getShowAll({
          memberId: memberId + "/Y",
          url: "GET_ASES",
        });

        if (null != data) {
          const selectedVo = !isEmpty(data) ? data[0] : { ...INITIAL_STATE };
          this.setState(() => ({
            mbrAsesList: data,
            showAllData: data,
            asesInfoVo: { ...selectedVo },
            showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
            selectedIndex: 0,
            editable: false,
            isNewSegment: false,
          }));
        }
      } else {
        const asesInfoVo = !isEmpty(showAllData)
          ? showAllData[0]
          : { ...INITIAL_STATE };
        this.setState({
          mbrAsesList: showAllData,
          asesInfoVo: asesInfoVo,
          showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
          selectedIndex: 0,
          editable: false,
          isNewSegment: false,
        });
      }
    } else {
      if (flag === "N") {
        await this.props.getAses(memberId + "/N");
      } else {
        let recodN = await (this.state.mbrAsesList === null
          ? []
          : this.state.mbrAsesList.filter((role) => role.overrideInd === "N"));

        await this.props.updateIndAsesData(recodN);
        //  let asesData = isEmpty(this.props.asesData) ? [] : this.props.asesData;
        //  const mbrAsesList = asesData;
        const selectedVo = !isEmpty(recodN) ? recodN[0] : { ...INITIAL_STATE };
        this.setState(() => ({
          asesInfoVo: { ...selectedVo },
          mbrAsesList: recodN,
          showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
          selectedIndex: 0,
          editable: false,
          isNewSegment: false,
        }));
      }
      // let asesData = isEmpty(this.props.asesData) ? [] : this.props.asesData;
      // const mbrAsesList = asesData;
      // const selectedVo = !isEmpty(mbrAsesList)
      //   ? mbrAsesList[0]
      //   : { ...INITIAL_STATE };
      // this.setState(() => ({
      //   asesInfoVo : { ...selectedVo },
      //   mbrAsesList: mbrAsesList,
      //   showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
      //   selectedIndex: 0,
      //   editable:false,
      //   isNewSegment:false
      // }));
    }
  };

  componentDidUpdate() {}

  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.mbrSearchCriteria.memberId !== prevState.memberId) {
      if (!isEmpty(nextProps.asesData)) {
        return {
          asesInfoVo: nextProps.asesData[0],
          mbrAsesList: nextProps.asesData,
          showAllData: null,
          //showAllActiveInd: true,
          modified: false,
          isNewSegment: false,
          editable: false,
          selectedIndex: 0,
          memberId: nextProps.mbrSearchCriteria.memberId,
          model: prevState.func1(
            nextProps.showAllActiveInd.showAllActiveInd === false ? true : "N",
            nextProps.mbrSearchCriteria.memberId
          ),
        };
      }
      return {
        asesInfoVo: INITIAL_STATE,
        mbrAsesList: [],
        showAllData: null,
        //showAllActiveInd: true,
        modified: false,
        isNewSegment: false,
        editable: false,
        selectedIndex: 0,
        memberId: nextProps.mbrSearchCriteria.memberId,
        model: prevState.func1(
          nextProps.showAllActiveInd.showAllActiveInd === false ? true : "N",
          nextProps.mbrSearchCriteria.memberId
        ),
      };
    }
    if (
      nextProps.showAllActiveInd.showAllActiveInd !== prevState.showAllActiveInd
    ) {
      if (nextProps.showAllActiveInd.showAllActiveInd === false) {
        return {
          model: prevState.func1(true, nextProps.mbrSearchCriteria.memberId),
        };
      } else {
        return {
          model: prevState.func1(false, nextProps.mbrSearchCriteria.memberId),
        };
      }
    }
    return prevState;
  }

  handleChangeRowsPerPage = async (rowsPerPage) => {
    await this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  async componentDidMount() {
    // dateChk = {};
    if (this.props.showAllActiveInd.showAllActiveInd === false) {
      this.showAll(true, this.props.mbrSearchCriteria.memberId);
    } else if (isEmpty(this.props.asesData) && this.props.asesData !== null) {
      await this.props.getAses(this.props.mbrSearchCriteria.memberId + "/N");
      INITIAL_STATE.memberId = this.props.mbrSearchCriteria.memberId;
    }
    if (!isEmpty(this.props.asesData)) {
      this.setState(() => ({
        mbrAsesList: this.props.asesData,
        asesInfoVo: { ...this.props.asesData[0] },
      }));
    }
  }

  render() {
    const { classes, dropdowns } = this.props;
    let ButtonPanel = (
      <MemberButtonPanel
        isNewSegment={this.state.isNewSegment}
        showAll={this.state.showAll}
        toggleLabel={this.state.showAllActive}
        newSegment={this.createNewSegment}
        modelSegment={this.modelSegment}
        modified={this.state.modified}
        editable={this.state.editable}
        delete={this.deleteAsesInfo}
        update={this.updateAsesInfo}
        disable={isEmpty(this.state.mbrAsesList)}
      />
    );

    return (
      <React.Fragment>
        <Modal
          dialogTitle="ASES"
          message={this.state.message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Paper
          elevation={0}
          className={classNames(classes.card, "animated fadeIn")}
        >
          <DataTable
            data={isEmpty(this.state.mbrAsesList) ? [] : this.state.mbrAsesList}
            header={header}
            sortable={true}
            rowsPerPageOptions={[10, 15, 20]}
            handleChangeRowsPerPage={() => {}}
            rowsPerPage={this.state.rowsPerPage}
            clicked={this.selectRow}
            index={this.state.selectedIndex}
            handleChangePage={() => {}}
            subtab
            // data={this.props.asesData}
            // header={header}
            // rowsPerPage={10}
            // clicked={this.selectRow}
          />

          <form autoComplete="off">
            <div className={classes.buttonContainer}> {ButtonPanel}</div>
            {!isEmpty(this.state.mbrAsesList) || (this.state.isNewSegment ) ? (        <div className="panel-body margin-top1">
              <div class="classes.container" style={{ display: "inline-flex" }}>
                <div>
                  <InputField
                    name="effStartDateFrmt"
                    id="effStartDateFrmt"
                    type="text"
                    maxLength="10"
                    onClick={this.handleStartDate("#effStartDateFrmt")}
                    InputProps={{ className: classes.textFont }}
                    label="Start Date"
                    inputclassname={classes.textFont}
                    className={classes.textField}
                    value={this.state.asesInfoVo.effStartDateFrmt}
                    InputLabelProps={{ className: classes.label, shrink: true }}
                    onChange={this.handlechange("effStartDateFrmt")}
                    onBlur={this.handleOnBlur}
                    disabled={!this.state.editable}
                  />

                  <div className={classes.validationMessage}>
                    {this.validator.message(
                      "Start Date",
                      this.state.asesInfoVo.effStartDateFrmt,
                      "required|date_format|startDateValidation|startDateGreater"
                    )}
                  </div>
                </div>

                <div>
                  <InputField
                    name="effEndDateFrmt"
                    id="effEndDateFrmt"
                    type="text"
                    InputProps={{ className: classes.textFont }}
                    label="End Date"
                    maxLength="10"
                    onClick={this.handleDates("#effEndDateFrmt")}
                    inputclassname={classes.textFont}
                    className={classes.textField}
                    value={this.state.asesInfoVo.effEndDateFrmt}
                    InputLabelProps={{ className: classes.label, shrink: true }}
                    onChange={this.handlechange("effEndDateFrmt")}
                    onBlur={this.handleOnBlur}
                    disabled={!this.state.editable}
                  />

                  <div className={classes.validationMessage}>
                    {this.validator.message(
                      "End Date",
                      this.state.asesInfoVo.effEndDateFrmt,
                      "required|date_format|endDateValidation"
                    )}
                  </div>
                </div>

                <div>
                  <InputField
                    name="odsiFamilyId"
                    id="odsiFamilyId"
                    type="text"
                    InputProps={{ className: classes.textFont }}
                    label="ODSI Family ID"
                    inputclassname={classes.textFont}
                    className={classes.textField}
                    maxLength="11"
                    value={this.state.asesInfoVo.odsiFamilyId}
                    InputLabelProps={{ className: classes.label, shrink: true }}
                    onChange={this.handlechange("odsiFamilyId")}
                    onBlur={this.handleOnBlur}
                    disabled={!this.state.editable}
                  />

                  <div className={classes.validationMessage}></div>
                </div>

                <div>
                  <InputField
                    name="mbrSuffix"
                    id="mbrSuffix"
                    type="text"
                    InputProps={{ className: classes.textFont }}
                    label="Mbr Suffix"
                    inputclassname={classes.textFont}
                    className={classes.textField}
                    maxLength="2"
                    value={this.state.asesInfoVo.mbrSuffix}
                    InputLabelProps={{ className: classes.label, shrink: true }}
                    onChange={this.handlechange("mbrSuffix")}
                    onBlur={this.handleOnBlur}
                    disabled={!this.state.editable}
                  />

                  <div className={classes.validationMessage}></div>
                </div>

                <div>
                  <AutoComplete1
                    options={dropdowns.validPlanVersions}
                    handleChange={this.handleChangeSearchSelectAuto}
                    defaultValue={dropdowns.validPlanVersions[0]}
                    value={
                      dropdowns.validPlanVersions.filter(
                        (data) =>
                          data.value === this.state.asesInfoVo.planVersion
                      )[0]
                    }
                    label="Plan Version"
                    disabled={!this.state.editable}
                    name="planVersion"
                  />

                  <div className={classes.validationMessageSelect}>
                    {this.validator.message(
                      "Plan Version",
                      this.state.asesInfoVo.planVersion,
                      "required"
                    )}
                  </div>
                </div>
              </div>

              <div class="classes.container" style={{ display: "inline-flex" }}>
                <div>
                  <InputField
                    name="mpi"
                    id="mpi"
                    type="text"
                    InputProps={{ className: classes.textFont }}
                    label="MPI"
                    inputclassname={classes.textFont}
                    className={classes.textField}
                    maxLength="13"
                    value={this.state.asesInfoVo.mpi}
                    InputLabelProps={{ className: classes.label, shrink: true }}
                    onChange={this.handlechange("mpi")}
                    onBlur={this.handleOnBlur}
                    disabled={!this.state.editable}
                  />

                  <div className={classes.validationMessage}></div>
                </div>

                <div>
                  {/* <Select
                  components={components}
                  propertyName={ASES_SELECT.filter(option => option.value === this.state.asesInfoVo.medicaidInd)}
                  options={ASES_SELECT}
                  label="Choose Medicaid Indicator ..."
                  textFieldProps={{
                    label: 'Medicaid Indicator',
                    InputLabelProps: {
                      className: classes.label,
                      shrink: true,
                    },
                  }}
                  className={classes.textFieldSelect}
                  handleChange={this.handleChangeSearchSelect('medicaidInd')}
                  isDisabled={!this.state.editable}
                  classes={classes}

                /> */}
                  <AutoComplete1
                    options={ASES_SELECT}
                    handleChange={this.handleChangeSearchSelectAuto}
                    defaultValue={ASES_SELECT[0]}
                    value={
                      ASES_SELECT.filter(
                        (data) =>
                          data.value === this.state.asesInfoVo.overrideInd
                      )[0]
                    }
                    label="Medicaid Indicator"
                    name="overrideInd"
                    disabled={!this.state.editable}
                  />
                  <div className={classes.validationMessage}></div>
                </div>

                <div>
                  <InputField
                    name="regionCode"
                    id="regionCode"
                    type="text"
                    InputProps={{ className: classes.textFont }}
                    label="Region Code"
                    inputclassname={classes.textFont}
                    className={classes.textField}
                    value={this.state.asesInfoVo.regionCode}
                    InputLabelProps={{ className: classes.label, shrink: true }}
                    onChange={this.handlechange("regionCode")}
                    onBlur={this.handleOnBlur}
                    disabled={!this.state.editable}
                  />

                  <div className={classes.validationMessage}></div>
                </div>

                <div>
                  {/* <Select
                  components={components}
                  propertyName={ASES_STATUS_LIST.filter(option => option.value === this.state.asesInfoVo.status)}
                  options={ASES_STATUS_LIST}
                  label="Choose Status ..."
                  textFieldProps={{
                    label: 'Status',
                    InputLabelProps: {
                      className: classes.label,
                      shrink: true,
                    },
                  }}
                  className={classes.textFieldSelect}
                  handleChange={this.handleChangeSearchSelect('status')}
                  isDisabled={!this.state.editable}
                  classes={classes}

                /> */}
                  <AutoComplete1
                    options={ASES_STATUS_LIST}
                    handleChange={this.handleChangeSearchSelectAuto}
                    defaultValue={ASES_STATUS_LIST[0]}
                    value={
                      ASES_STATUS_LIST.filter(
                        (data) => data.value === this.state.asesInfoVo.status
                      )[0]
                    }
                    label="Status"
                    name="status"
                    disabled={!this.state.editable}
                  />
                  <div className={classes.validationMessageSelect}>
                    {this.validator.message(
                      "Status",
                      this.state.asesInfoVo.status,
                      "required"
                    )}
                  </div>
                </div>

                <div>
                  {/* <Select
                  components={components}
                  propertyName={ASES_SELECT.filter(option => option.value === this.state.asesInfoVo.planVersionChangeInd)}
                  options={ASES_SELECT}
                  label="Plan Version Change Indicator ..."
                  textFieldProps={{
                    label: 'Plan Version Change Indicator',
                    InputLabelProps: {
                      className: classes.label,
                      shrink: true,
                    },
                  }}
                  className={classes.textFieldSelect}
                  handleChange={this.handleChangeSearchSelect('planVersionChangeInd')}
                  isDisabled={!this.state.editable}
                  classes={classes}

                /> */}
                  <AutoComplete1
                    options={ASES_SELECT}
                    handleChange={this.handleChangeSearchSelectAuto}
                    defaultValue={ASES_SELECT[0]}
                    value={
                      ASES_SELECT.filter(
                        (data) =>
                          data.value ===
                          this.state.asesInfoVo.planVersionChangeInd
                      )[0]
                    }
                    label="Plan Version Change Indicator"
                    name="planVersionChangeInd"
                    disabled={!this.state.editable}
                  />
                  <div className={classes.validationMessage}></div>
                </div>
              </div>
            </div>
            ):null}
          </form>

          <HistoryData
            isNewSegment={this.state.isNewSegment}
            reset={this.createNewSegment}
            addSegment={this.addNewSegment}
            back={this.goBack}
            footer="true"
          />
        </Paper>
      </React.Fragment>
    );
  }
}

//export default withStyles(Styles)(Ases);

const mapStateToProps = (state) => {
  return {
    memberIdCheck: state.memberSearch.memberId,
    loginData: state.loginData,
    asesData: state.memberSearch.searchResultsVo.mbrAsesList,
    searchResultsVo: state.memberSearch.searchResultsVo,
    mbrSearchCriteria: state.memberSearch.mbrSearchCriteria,
    dropdowns: state.membercache,
    showAllActiveInd: state.memberSearch.showAllActiveIndi,
  };
};
const mapDispatchToProps = {
  getAses,
  insetUpdateAses,
  updateIndAsesData,
  getShowAll,
  deleteAses,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(Ases));
