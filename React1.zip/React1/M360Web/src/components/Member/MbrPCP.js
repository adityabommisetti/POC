import * as ActionTypes from "../../redux/types/ActionType";
import * as DateUtil from "../../utils/DatePicker";
import * as Type from "../../constants/ConfirmType";

import {
  PCPActiveDetails,
  PCPDeleteDetails,
  PCPUpdateDetails,
  getShowAll,
  updateIndpcpData,
} from "../../redux/actions/MemberActions";
import React, { Component } from "react";

import ConfirmBox from "../../utils/PopUp";
import DataTable from "../Home/DataTable";
import HistoryData from "../UI/MemberHistory";
import InputField from "../UI/InputField";
import MbrPCPSearchPopup from "./MbrPCPSearchPopup";
import MemberButtonPanel from "../UI/MemberButtonPanel";
import Modal from "../../components/UI/Modal/Modal";
import Paper from "@material-ui/core/Paper";
import Popup from "reactjs-popup";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../assets/styles/Theme";
import classNames from "classnames";
import { connect } from "react-redux";
import { handleDateChange } from "../../utils/DateFormatter";
import { PCP_TABLE_HEADER as header } from "../../constants/Headers/MemberHeaders";
import isEmpty from "lodash/isEmpty";
import { withStyles } from "@material-ui/core/styles";
import { customValidations } from "../../utils/CustomValidations";

// const containerPcp2 = {
//   display: "flex",
//   flexWrap: "wrap",
//   width: "fit-content",
//   marginLeft: "2px",
//   marginBottom: "6px",
// };

const textFieldPCP = {
  width: "410px",
};

const INITIAL_STATE = {
  acceptNewPatient: "",
  clinicName: "",
  createTime: "",
  createUserId: "",
  currentDateTime: null,
  currentPatientInd: "",
  customerId: "",
  disEnrollApprvStartDateMinusOne: null,
  doctorAddress: "",
  doctorCity: "",
  doctorName: "",
  doctorState: "",
  doctorZip: "",
  effEndDateFrmt: "99/99/9999",
  effStartDateFrmt: "",
  errorDescription: null,
  frmtCreateTime: "",
  frmtLastUpdtTime: "",
  lastUpdtTime: "",
  lastUpdtUserId: "",
  lineOfBusiness: "",
  locationId: "",
  memberId: "",
  message: null,
  officeCategoryCode: null,
  officeCategoryCodeColumnInDB: "",
  overrideInd: "N",
  pcpChangeInd: null,
  pcpChangeSendTime: null,
  pcpName: null,
  pcpNbr: "",
  pcpNpi: "",
  pcpStatus: null,
  pcpchangeReceiveTime: null,
  type: "PCP",
};

class MemberPCP extends Component {
  constructor(props) {
    super(props);
    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
        date_format2: customValidations.date_format99,
        first_day_of_month: customValidations.first_day_of_month,
        last_day_of_month: customValidations.last_day_of_month99,
        after_start_date: customValidations.c_after_or_equal_99,
      },
    });
    this.state = {
      onload: true,
      pcpVo: INITIAL_STATE,
      data: null,
      modified: false,
      isNewSegment: false,
      //showAllActive: true,
      editable: false,
      selectedIndex: 0,
      closePopup: false,
      showAllData: null,
      message: "",
      needPcpValidation: "N",
      rowsPerPage: 10,
      lobVald: [],
      func1: this.showAll.bind(this),
      showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
      selectedTab: this.props.selectedTab,
    };
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.mbrSearchCriteria.memberId !== prevState.memberId) {
      if (nextProps.pcpData) {
        console.log(nextProps.pcpData);
        return {
          pcpVo: nextProps.pcpData[0],
          data: nextProps.pcpData,
          showAllData: null,
          // showAllActive: true,
          modified: false,
          isNewSegment: false,
          editable: false,
          selectedIndex: 0,
          memberId: nextProps.mbrSearchCriteria.memberId,
          model: prevState.func1(
            nextProps.showAllActiveInd.showAllActiveInd === false ? true : "N",
            nextProps.mbrSearchCriteria.memberId
          ),
        };
      }
      let onloadPcp = prevState.onload
        ? {}
        : {
            model: prevState.func1(
              nextProps.showAllActiveInd.showAllActiveInd === false
                ? true
                : "N",
              nextProps.mbrSearchCriteria.memberId
            ),
          };
      return {
        pcpVo: INITIAL_STATE,
        data: [],
        showAllData: null,
        //showAllActive: true,
        modified: false,
        isNewSegment: false,
        editable: false,
        selectedIndex: 0,
        memberId: nextProps.mbrSearchCriteria.memberId,
        onload: false,
        ...onloadPcp,
      };
    }
    if (
      nextProps.showAllActiveInd.showAllActiveInd !== prevState.showAllActiveInd
    ) {
      if (nextProps.showAllActiveInd.showAllActiveInd === false) {
        return {
          model: prevState.func1(true, nextProps.mbrSearchCriteria.memberId),
        };
      } else {
        return {
          model: prevState.func1(false, nextProps.mbrSearchCriteria.memberId),
        };
      }
    }

    return null;
  }

  async componentDidMount() {
    INITIAL_STATE.memberId = this.props.mbrSearchCriteria.memberId;
    this.setState({
      pcpVo: {
        ...INITIAL_STATE,
      },
    });
    if (this.props.showAllActiveInd.showAllActiveInd === false) {
      await this.showAll(() => true, this.props.mbrSearchCriteria.memberId);
      console.log(this.props.pcpData);
    }
    // else if (
    //   isEmpty(this.props.pcpData) &&
    //   this.props.pcpData !== null &&
    //   this.props.selectedTab === "pcp"
    // ) {
    //   await this.props.PCPActiveDetails(
    //     this.props.mbrSearchCriteria.memberId + "/N"
    //   );
    //   INITIAL_STATE.memberId = this.props.mbrSearchCriteria.memberId;
    // }

    if (!isEmpty(this.props.pcpData)) {
      let pcpVo = this.props.pcpData[0];
      this.setState({
        pcpVo: pcpVo,
        data: this.props.pcpData,
      });
    }
    const { loginProfile } = this.props;
    const LOB_VALD = loginProfile.filter((data) => data.label === "LOB_VALD");
    this.setState({
      lobVald: LOB_VALD[0],
    });
  }

  selectRow = (index) => {
    const selectedVo = this.state.data[index];
    this.setState(() => ({
      pcpVo: { ...selectedVo }, // copy data
      editable: false, // readOnly
      isNewSegment: false, //Not a new SEgment
      selectedIndex: index,
      needPcpValidation: "N",
      modified: false, // Disabled update button
    }));
  };

  handlechange = (e) => {
    let value = e.target ? e.target.value.toUpperCase() : e.value.toUpperCase();
    let name = e.target.name;
    this.setState((prevState) => ({
      pcpVo: {
        ...prevState.pcpVo,
        [name]: value,
      },
      modified: true,
    }));
    // if (name === "doctorName") {
    //   this.doPcpDoctorChange();
    // }
    // if (name === "pcpNbr") {
    //   this.doPcpNbrChange();
    // }
    // if (name === "locationId") {
    //   this.doPcpLocChange();
    // }
  };
  validatePCP = () => {
    const { pcpNbr, locationId, pcpNpi, doctorName } = this.state.pcpVo;
    const { data, selectedIndex, isNewSegment } = this.state;
    const pcpData = isEmpty(data) ? [] : data[selectedIndex];
    const { pcpSearchData } = this.props;
    /* if(isEmpty(pcpSearchData)){
      alert("it is a blank")
    }*/
    const array = pcpSearchData.filter(
      (item) =>
        item.pcpNbr === pcpNbr &&
        item.locationId === locationId &&
        item.pcpNpi === pcpNpi &&
        item.doctorName === doctorName
    );
    if (
      (!isNewSegment &&
        array.length === 0 &&
        (pcpNbr !== pcpData.pcpNbr ||
          locationId !== pcpData.locationId ||
          pcpNpi !== pcpData.pcpNpi ||
          doctorName !== pcpData.doctorName)) ||
      (isNewSegment && array.length === 0)
    ) {
      this.setState({
        pcpVo: {
          ...this.state.pcpVo,
          pcpNbr: "",
          locationId: "",
          doctorName: "",
          doctorAddress: "",
          doctorCity: "",
          clinicName: "",
          doctorState: "",
          doctorZip: "",
          pcpNpi: "",
        },
        needPcpValidation: "Y",
      });
    } else {
      this.setState({
        needPcpValidation: "N",
      });
    }
  };
  handleOnBlur = (e) => {
    let value = e.target.value.trim();
    let name = e.target.name;
    this.setState((prevState) => ({
      pcpVo: {
        ...prevState.pcpVo,
        [name]: value,
      },
      modified: true,
    }));

    this.validatePCP();
  };

  handleDate = (event) => {
    let value = event.target.value;
    let name = event.target.name;
    this.setState((prevState) => ({
      pcpVo: {
        ...prevState.pcpVo,
        [name]: handleDateChange(value),
      },
      modified: true,
    }));
  };

  handleStartDate = (event) => {
    var self = this;
    const fieldId = "#" + event.target.name;
    DateUtil.getStartDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        self.setValue(e.target.name, e.target.value);
      });
  };

  handleDates = (event) => {
    var self = this;
    const fieldId = "#" + event.target.name;
    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        self.setValue(e.target.name, e.target.value);
      });
  };

  setValue = (name, value) => {
    this.setState((prevState) => ({
      pcpVo: {
        ...prevState.pcpVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  modelSegment = () => {
    if (this.state.pcpVo.overrideInd === "Y") {
      let msg = "This Record is not active ";
      this.setState({ message: msg, closePopup: true });
    } else {
      this.setState({
        editable: true, // Editable
        isNewSegment: false, // Not a new Segment
      });
    }
  };

  createNewSegment = () => {
    this.validator.hideMessages();
    this.forceUpdate();
    INITIAL_STATE.memberId = this.props.mbrSearchCriteria.memberId;
    this.setState({
      editable: true,
      isNewSegment: true,
      pcpVo: {
        ...INITIAL_STATE,
      },
    });
  };

  update = (event) => {
    event.preventDefault();
    const { pcpVo, data, selectedIndex } = this.state;

    if (JSON.stringify(pcpVo) === JSON.stringify(data[selectedIndex])) {
      this.setState({
        closePopup: true,
        message: "NO FIELDS UPDATED",
      });
      return;
    }

    if (this.state.needPcpValidation === "Y") {
      this.setState({
        closePopup: true,
        message: "Please Validate PCP",
      });
      this.validator.showMessages();
      this.forceUpdate();
      return;
    }

    if (this.validator.allValid()) {
      ConfirmBox(this.confirmUpdate, Type.UPDATE, this.props);
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  confirmUpdate = async () => {
    const { pcpVo } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(pcpVo.showAll = val),
    });
    if (this.state.pcpVo.pcpNbr) {
      let status = await this.props.PCPUpdateDetails(this.state.pcpVo);

      if (status === "success") {
        this.setState(() => ({
          data: this.props.pcpData,
          pcpVo: this.props.pcpData[this.state.selectedIndex],
          editable: false, // readOnly
          isNewSegment: false, //Not a new SEgment
          modified: false,
          showAllData: null,
          message: ActionTypes.UPDATE,
          closePopup: true,
        }));
      } else {
        if (status === "Please validate the PCP") {
          await this.setState({
            pcpVo: {
              ...this.state.pcpVo,
              doctorAddress: "",
              doctorCity: "",
              clinicName: "",
              doctorState: "",
              doctorZip: "",
            },
          });
        }
        this.setState({
          closePopup: true,
          message: status,
        });
      }
      this.validator.hideMessages();
    } else {
      this.setState({
        closePopup: true,
        message: "PCP Is Not Valid for the Effective Date",
      });
      return false;
    }
  };

  addNewSegment = () => {
    if (this.state.needPcpValidation === "Y") {
      this.setState({
        closePopup: true,
        message: "Please Validate PCP",
      });
      this.validator.showMessages();
      this.forceUpdate();
      return;
    }
    if (this.validator.allValid()) {
      ConfirmBox(this.confirmAddNewSegment, Type.ADD, this.props);
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  confirmAddNewSegment = async () => {
    const { pcpVo } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(pcpVo.showAll = val),
    });

    if (this.state.pcpVo.pcpNbr) {
      let status = await this.props.PCPUpdateDetails(this.state.pcpVo);
      if (status === "success") {
        this.setState(() => ({
          closePopup: true,
          message: ActionTypes.ADD,
          data: this.props.pcpData,
          pcpVo: this.props.pcpData[0],
          editable: false, // readOnly
          isNewSegment: false, //Not a new SEgment
          modified: false,
          showAllData: null,
          page: 0,
          selectedIndex: 0,
        }));
        this.validator.hideMessages();
      } else {
        if (status === "Please validate the PCP") {
          await this.setState({
            pcpVo: {
              ...this.state.pcpVo,
              doctorAddress: "",
              doctorCity: "",
              clinicName: "",
              doctorState: "",
              doctorZip: "",
            },
          });
        }

        this.setState({
          closePopup: true,
          message: status,
        });
      }
    } else {
      this.setState({
        closePopup: true,
        message: "PCP Is Not Valid for the Effective Date",
      });
      return false;
    }
  };

  delete = () => {
    if (this.state.pcpVo.overrideInd === "Y") {
      let msg = "This Record is not active ";
      this.setState({ message: msg, closePopup: true });
    } else {
      ConfirmBox(this.confirmDelete, Type.DELETE, this.props);
    }
  };
  doPcpNbrChange = () => {
    this.setState((prevState) => ({
      needPcpValidation: "Y",
      pcpVo: {
        ...prevState.pcpVo,
        locationId: "",
        doctorName: "",
      },
    }));
  };
  doPcpLocChange = () => {
    this.setState((prevState) => ({
      needPcpValidation: "Y",
      pcpVo: {
        ...prevState.pcpVo,
        doctorName: "",
      },
    }));
  };
  doPcpDoctorChange = () => {
    this.setState((prevState) => ({
      needPcpValidation: "Y",
      pcpVo: {
        ...prevState.pcpVo,
        locationId: "",
        pcpNbr: "",
      },
    }));
  };

  confirmDelete = async () => {
    const { pcpVo } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(pcpVo.showAll = val),
    });
    let status = await this.props.PCPDeleteDetails(this.state.pcpVo);
    let newVO = isEmpty(this.props.pcpData)
      ? INITIAL_STATE
      : this.props.pcpData[0];
    let message = "";
    if (status === "success") {
      message = ActionTypes.DELETE;
    } else {
      message = status;
    }

    this.setState({
      pcpVo: newVO,
      data: this.props.pcpData,
      showAllData: null,
      closePopup: true,
      message: message,
      selectedIndex: 0,
      isNewSegment: false,
      editable: false,
      modified: false,
    });
    this.validator.hideMessages();
  };

  updateValue = (selectedVo) => {
    this.setState({
      pcpVo: {
        ...this.state.pcpVo,
        pcpNbr: selectedVo.pcpNbr,
        locationId: selectedVo.locationId,
        doctorName: selectedVo.doctorName,
        doctorAddress: selectedVo.doctorAddress,
        doctorCity: selectedVo.doctorCity,
        clinicName: selectedVo.clinicName,
        doctorState: selectedVo.doctorState,
        doctorZip: selectedVo.doctorZip,
        pcpNpi: selectedVo.pcpNpi,
        lineOfBusiness: selectedVo.lineOfBusiness,
      },
      needPcpValidation: "N",
      modified: true,
    });
  };

  goBack = () => {
    const index = this.state.selectedIndex;
    const { pcpData } = this.props;
    let pcpVo = INITIAL_STATE;

    if (!isEmpty(pcpData)) {
      pcpVo = this.props.pcpData[index];
    }
    this.setState({
      isNewSegment: false,
      editable: false,
      modified: false,
      pcpVo: pcpVo,
    });
    this.validator.hideMessages();
  };

  showAll = async (flag, mbrId) => {
    const { showAllData } = this.state;
    //const active = !showAllActive;
    const memberId = mbrId;

    if (flag === true) {
      if (showAllData === null && this.props.selectedTab === "pcp") {
        const data = await this.props.getShowAll({
          memberId: memberId + "/Y",
          url: "GET_MEMBER_PCP",
        });

        if (null != data) {
          const selectedVO = !isEmpty(data) ? data[0] : { ...INITIAL_STATE };

          await this.setState(() => ({
            data: data,
            pcpVo: selectedVO,
            showAllData: data,
            showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
            selectedIndex: 0,
            editable: false, // readOnly
            isNewSegment: false,
          }));
        }
      } else {
        const selectedVO = !isEmpty(showAllData)
          ? showAllData[0]
          : { ...INITIAL_STATE };

        this.setState(() => ({
          data: showAllData,
          pcpVo: selectedVO,
          showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
          selectedIndex: 0,
          editable: false, // readOnly
          isNewSegment: false,
        }));
      }
    } else {
      if (flag === "N" && this.props.selectedTab === "pcp") {
        if (
          !isEmpty(this.props.pcpData) &&
          this.props.mbrSearchCriteria.memberId === memberId
        ) {
          let recodN = await this.props.pcpData.filter(
            (role) => role.overrideInd === "N"
          );
          await this.props.updateIndpcpData(recodN);
        } else {
          await this.props.PCPActiveDetails(memberId + "/N");
          INITIAL_STATE.memberId = this.props.mbrSearchCriteria.memberId;
          console.log(this.props.pcpData);
        }
      } else {
        let recodN = await (this.state.data === null
          ? []
          : this.state.data.filter((role) => role.overrideInd === "N"));

        await this.props.updateIndpcpData(recodN);
      }
      const selectedVO = !isEmpty(this.props.pcpData)
        ? this.props.pcpData[0]
        : { ...INITIAL_STATE };
      this.setState(() => ({
        data: this.props.pcpData,
        pcpVo: selectedVO,
        showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
        selectedIndex: 0,
        editable: false, // readOnly
        isNewSegment: false,
      }));
    }
  };

  modalClosed = () => {
    this.setState({ closePopup: false });
  };
  handleChangeRowsPerPage = async (rowsPerPage) => {
    await this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  handleChangePage = (index) => {
    this.setState({ selectedIndex: index });
    const selectedVo = this.state.data[index];
    this.setState(() => ({
      pcpVo: { ...selectedVo }, // copy data
      editable: false, // readOnly
      isNewSegment: false, //Not a new SEgment
      selectedIndex: index,
      needPcpValidation: "N",
      modified: false, // Disabled update button
    }));
  };

  render() {
    //let test1 = this.state.isNewSegment ? containerPcp : containerPcp2;
    const { classes } = this.props;
    const { pcpVo, editable, data, lobVald } = this.state;
    let ButtonPanel = (
      <MemberButtonPanel
        isNewSegment={this.state.isNewSegment}
        //showAll={this.showAll}
        // toggleLabel={this.state.showAllActive}
        newSegment={this.createNewSegment}
        modelSegment={this.modelSegment}
        modified={this.state.modified}
        editable={editable}
        delete={this.delete}
        update={this.update}
        disable={isEmpty(this.state.data)}
      />
    );

    return (
      <React.Fragment>
        <Modal
          dialogTitle="PCP"
          message={this.state.message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Paper
          className={classNames(classes.card, "animated fadeIn")}
          elevation={0}
        >
          <DataTable
            data={data ? data : []}
            header={header}
            sortable={true}
            rowsPerPageOptions={[10, 15, 20]}
            handleChangeRowsPerPage={this.handleChangeRowsPerPage}
            rowsPerPage={this.state.rowsPerPage}
            clicked={this.selectRow}
            index={this.state.selectedIndex}
            pageNo={this.state.page}
            handleChangePage={this.handleChangePage}
            dateColumn={["effStartDateFrmt", "effEndDateFrmt"]}
            subtab
          />

          {(!isEmpty(data) && this.state.pcpVo) || this.state.isNewSegment ? (
            <React.Fragment>
              <div className={classes.buttonContainer}> {ButtonPanel}</div>
              <div className="panel-body">
                <div className={classes.containerdemo}>
                  <div>
                    <InputField
                      name="effStartDateFrmt"
                      placeholder="MM/DD/YYYY"
                      label="Start Date"
                      required={editable}
                      value={pcpVo.effStartDateFrmt}
                      maxLength="10"
                      onChange={this.handleDate}
                      disabled={!editable}
                      onClick={this.handleStartDate}
                      onBlur={this.handleOnBlur}
                    />
                    <div className={classes.validationMessage}>
                      {this.validator.message(
                        "StartDate",
                        pcpVo.effStartDateFrmt,
                        "required|date_format|first_day_of_month"
                      )}
                    </div>
                  </div>

                  <div>
                    <InputField
                      name="effEndDateFrmt"
                      placeholder="MM/DD/YYYY"
                      onClick={this.handleDates}
                      label="End Date"
                      required={editable}
                      value={pcpVo.effEndDateFrmt}
                      maxLength={10}
                      onChange={this.handleDate}
                      onBlur={this.handleOnBlur}
                      disabled={!editable}
                    />
                    <div className={classes.validationMessage}>
                      {this.validator.message("EndDate", pcpVo.effEndDateFrmt, [
                        "required",
                        "date_format2",
                        "last_day_of_month",
                        {
                          after_start_date: pcpVo.effStartDateFrmt,
                        },
                      ])}
                    </div>
                  </div>

                  <div>
                    <InputField
                      name="overrideInd"
                      InputProps={{ className: classes.textFont }}
                      label="Override"
                      className={classes.textField}
                      value={pcpVo.overrideInd}
                      InputLabelProps={{
                        className: classes.label,
                        shrink: true,
                      }}
                      onChange={this.handlechange}
                      disabled
                    />
                    <div className={classes.validationMessage} />
                  </div>
                </div>
                <div className={classes.containerdemo}>
                  <div>
                    <InputField
                      name="pcpNbr"
                      label="PCP"
                      required={editable}
                      value={pcpVo.pcpNbr}
                      maxLength="12"
                      onChange={this.handlechange}
                      onBlur={this.handleOnBlur}
                      disabled={!editable}
                    />
                    <div className={classes.validationMessage}>
                      {this.validator.message(
                        "PCP Number",
                        pcpVo.pcpNbr,
                        "required"
                      )}
                    </div>
                  </div>
                  {this.props.searchResultsVo.npiInd === "Y" ? (
                    <div>
                      <InputField
                        name="pcpNpi"
                        label="NPI"
                        value={pcpVo.pcpNpi}
                        onChange={this.handlechange}
                        onBlur={this.handleOnBlur}
                        disabled={!editable}
                        maxLength={12}
                      />
                      <div className={classes.validationMessage} />
                    </div>
                  ) : null}
                  <div>
                    <InputField
                      name="locationId"
                      label="Location"
                      value={pcpVo.locationId}
                      maxLength="2"
                      onChange={this.handlechange}
                      onBlur={this.handleOnBlur}
                      disabled={!editable}
                    />
                    <div className={classes.validationMessage} />
                  </div>

                  <div className={classes.docField}>
                    <span class="label-container">
                      <label for="doctorName">Doctor Name</label>
                      <br />
                      <input
                        style={{ width: "371px" }}
                        type="text"
                        class="form-field"
                        id="doctorName"
                        name="doctorName"
                        value={pcpVo.doctorName}
                        maxLength="50"
                        onChange={this.handlechange}
                        onBlur={this.handleOnBlur}
                        disabled={!editable}
                      />

                      {editable ? (
                        <React.Fragment>
                          <Popup
                            contentStyle={{ height: "90%", width: "55%" }}
                            className={classes.mobileWidth}
                            modal
                            trigger={<span class="more-info" id="more-info" />}
                            position="right center"
                          >
                            {(close) => (
                              <div>
                                <MbrPCPSearchPopup
                                  search={pcpVo}
                                  close={close}
                                  updateValue={this.updateValue}
                                />
                              </div>
                            )}
                          </Popup>
                        </React.Fragment>
                      ) : null}
                    </span>
                  </div>
                </div>
                <div className={classes.containerdemo}>
                  <div style={textFieldPCP}>
                    <InputField
                      name="clinicName"
                      label="Clinic Name"
                      width="375px"
                      value={pcpVo.clinicName}
                      onChange={this.handlechange}
                      onBlur={this.handleOnBlur}
                      disabled
                    />
                    <div className={classes.validationMessage} />
                  </div>

                  {/* {pcpVo.customerId.slice(0, 2).toUpperCase() === "HC" ? ( */}
                  {lobVald.value === "Y" ? (
                    <div style={textFieldPCP}>
                      <InputField
                        name="lineOfBusiness"
                        label="Line Of Business"
                        value={pcpVo.lineOfBusiness}
                        maxLength="20"
                        onChange={this.handlechange}
                        onBlur={this.handleOnBlur}
                        disabled={true}
                      />
                      <div className={classes.validationMessage} />
                    </div>
                  ) : null}
                </div>
                <div className={classes.containerdemo}>
                  <div className={classes.docField}>
                    <InputField
                      name="doctorAddress"
                      label="Address"
                      width="371px"
                      value={pcpVo.doctorAddress}
                      margin="normal"
                      onChange={this.handlechange}
                      onBlur={this.handleOnBlur}
                      disabled
                    />
                    <div className={classes.validationMessage} />
                  </div>
                </div>
                <div className={classes.containerdemo}>
                  <div>
                    <InputField
                      name="doctorCity"
                      label="City"
                      value={pcpVo.doctorCity}
                      onChange={this.handlechange}
                      onBlur={this.handleOnBlur}
                      disabled
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="doctorState"
                      label="State"
                      value={pcpVo.doctorState}
                      onChange={this.handlechange}
                      onBlur={this.handleOnBlur}
                      disabled
                    />
                    <div className={classes.validationMessage} />
                  </div>
                  <div>
                    <InputField
                      name="doctorZip"
                      label="Zip"
                      value={pcpVo.doctorZip}
                      onChange={this.handlechange}
                      onBlur={this.handleOnBlur}
                      disabled
                    />
                    <div className={classes.validationMessage} />
                  </div>
                </div>
              </div>
              <HistoryData
                createTime={pcpVo.createTime}
                createUserId={pcpVo.createUserId}
                lastUpdtTime={pcpVo.lastUpdtTime}
                lastUpdtUserId={pcpVo.lastUpdtUserId}
                isNewSegment={this.state.isNewSegment}
                reset={this.createNewSegment}
                addSegment={this.addNewSegment}
                back={this.goBack}
                footer="true"
              />
            </React.Fragment>
          ) : (
            <div className={classes.buttonContainer}> {ButtonPanel}</div>
          )}
        </Paper>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  pcpData: state.memberSearch.searchResultsVo.mbrPcpInfoList,
  searchResultsVo: state.memberSearch.searchResultsVo,
  mbrSearchCriteria: state.memberSearch.mbrSearchCriteria,
  memberIdCheck: state.memberSearch.memberId,
  loginProfile: state.loginData.profiles,
  pcpSearchData: state.memberSearch.pcpSearchData,
  showAllActiveInd: state.memberSearch.showAllActiveIndi,
  selectedTab: state.memberSearch.selectedTab,
});

const mapDispatchToProps = {
  PCPActiveDetails,
  PCPDeleteDetails,
  PCPUpdateDetails,
  getShowAll,
  updateIndpcpData,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(MemberPCP));
