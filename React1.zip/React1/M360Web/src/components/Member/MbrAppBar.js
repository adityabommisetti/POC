import AppBar from "@material-ui/core/AppBar";
import ASES from "./MbrASES";
import Accretion from "./MbrAccretion";
import Agent from "./MbrAgent";
import Billing from "./MbrBilling";
import COB from "./MbrCOB";
import Comments from "./MbrComments";
import Demographics from "./MbrDemographic";
import DsInfo from "./MbrDsInfo";
import Enrollment from "./MbrEnrollment";
import LEP from "./LEP/MbrLepTab";
import LIS from "./MbrLIS";
import LTC from "./MbrLTC";
import Letters from "./MbrLetters";
import MemberAddress from "./MbrAddress";
import OOA from "./MbrOOA";
import PCP from "./MbrPCP";
import POS from "./MbrPOS";
import TRR from "./MbrTRR";
import SOA from "./MbrSOA";
/*import {
  ASES,
  Accretion,
  Agent,
  Billing,
  COB,
  Comments,
  Demographics,
  DsInfo,
  Enrollment,
  LEP,
  LIS,
  LTC,
  Letters,
  MemberAddress,
  OOA,
  PCP,
  POS,
  TRR,
} from "./TabImport";*/
import ErrorBoundary from "../Error/ErrorBoundary";
import PropTypes from "prop-types";
import React from "react";
import SimpleReactValidator from "simple-react-validator";

import Tab from "@material-ui/core/Tab";
import Tabs from "@material-ui/core/Tabs";
import { connect } from "react-redux";
import { validationRules } from "../../utils/ValidationRules";
import { withStyles } from "@material-ui/core/styles";
import { getShowAll} from "../../redux/actions/MemberActions";

const Tab1 = withStyles({
  root: {
    minWidth: "15%",
  },
})(Tab);

function TabContainer(props) {
  return <div>{props.children}</div>;
}

TabContainer.propTypes = {
  children: PropTypes.node.isRequired,
};

const styles = (theme) => ({
  root: {
    flexGrow: 1,
    width: "100%",
    backgroundColor: theme.palette.background.paper,
  },
});

class MemberAppBar extends React.Component {
  constructor(props) {
    super(props);
   
    this.validator = new SimpleReactValidator({ ...validationRules });

    this.handleTabChange = this.handleTabChange.bind(this);
  }

  handleTabChange = (event, value) => {
    this.props.updatedTab(value);
  };


  render() {
    const { classes, servicesEnabled, value } = this.props;

    return (
      <div className={classes.root}>
        <AppBar position="static" color="default">
          <Tabs
            // initialSelectedIndex={this.initialValue}
            value={this.props.value}
            onChange={this.handleTabChange}
            variant="scrollable"
            scrollButtons="on"
            indicatorColor="primary"
            textColor="primary"
          >
            <Tab1 label="Demographics" value="demo" />
            <Tab1 label="Enrollment" value="enroll" />
            <Tab1 label="Ds Info" value="dsinfo" />
            <Tab1 label="LIS" value="lis" />
            <Tab1 label="Address" value="address" />
            <Tab1 label="Letters" value="letters" />
            <Tab1 label="PCP" value="pcp" />
            {servicesEnabled.includes("VLTC") ? (
              <Tab1 label="LTC" value="ltc" />
            ) : null}
            <Tab1 label="Comments" value="comments" />
            <Tab1 label="TRR" value="trr" />
            <Tab1 label="COB" value="cob" />
            <Tab1 label="POS" value="pos" />
            <Tab1 label="Agent" value="agent" />
            <Tab1 label="Billing" value="billing" />
            <Tab1 label="LEP" value="lep" />
            <Tab1 label="OOA" value="ooa" />
            <Tab1 label="Accretion" value="accretion" />
            {servicesEnabled.includes("SOA") ? (
            <Tab1 label="SOA" value="SOA" />
            ) : null}
            {servicesEnabled.includes("EEAS") ? (
              <Tab1 label="ASES" value="ases" />
            ) : null}
            {/* {servicesEnabled.includes("OEV") ? (
              <Tab1 label="OEV" value="oev" />
            ) : null}
            {servicesEnabled.includes("SOA") ? (
              <Tab1 label="SOA" value="soa" />
            ) : null} */}

            {/* <Tab label="Demographics" icon={<PersonPinIcon />} />
            <Tab label="Enrollment" icon={<FavoriteIcon />} />
            <Tab label="Ds Info" icon={<PersonPinIcon />} />
            <Tab label="LIS" icon={<HelpIcon />} />
            <Tab label="Address" icon={<ShoppingBasket />} />
            <Tab label="Letters" icon={<ThumbDown />} />
            <Tab label="PCP" icon={<ThumbUp />} />
             {servicesEnabled.includes("VLTC") ?
             <React.Fragment>
            <Tab label="LTC" icon={<FavoriteIcon />} /> </React.Fragment> : null}
            <Tab label="Comments" icon={<PersonPinIcon />} />
            <Tab label="TRR" icon={<HelpIcon />} />
            <Tab label="COB" icon={<ShoppingBasket />} />
            <Tab label="POS" icon={<ThumbDown />} />
            <Tab label="Agent" icon={<ThumbUp />} />
            <Tab label="Billing" icon={<ShoppingBasket />} />
            <Tab label="LEP" icon={<ThumbDown />} />
            <Tab label="OOA" icon={<ThumbUp />} />
            <Tab label="Accretion" icon={<FavoriteIcon />} />
              {servicesEnabled.includes("EEAS") ?
              <React.Fragment>
            <Tab label="ASES" icon={<ThumbUp />} /> </React.Fragment> : null} */}
          </Tabs>
        </AppBar>
        {value === "demo" && (
          <TabContainer>
            <ErrorBoundary>
              <Demographics />
            </ErrorBoundary>
          </TabContainer>
        )}
        {value === "enroll" && (
          <TabContainer>
            <ErrorBoundary>
              <Enrollment />
            </ErrorBoundary>
          </TabContainer>
        )}
        {value === "dsinfo" && (
          <TabContainer>
            <ErrorBoundary>
              <DsInfo />
            </ErrorBoundary>
          </TabContainer>
        )}
        {value === "lis" && (
          <TabContainer>
            <ErrorBoundary>
              <LIS indexVal={this.props.indexVal} />
            </ErrorBoundary>
          </TabContainer>
        )}
        {value === "address" && (
          <TabContainer>
            <ErrorBoundary>
              <MemberAddress />
            </ErrorBoundary>
          </TabContainer>
        )}
        {value === "letters" && (
          <TabContainer>
            <ErrorBoundary>
              <Letters />
            </ErrorBoundary>
          </TabContainer>
        )}
        {value === "pcp" && (
          <TabContainer>
            <ErrorBoundary>
              <PCP />
            </ErrorBoundary>
          </TabContainer>
        )}
        {servicesEnabled.includes("VLTC")
          ? value === "ltc" && (
            <TabContainer>
              <ErrorBoundary>
                <LTC />
              </ErrorBoundary>
            </TabContainer>
          )
          : null}
        {value === "comments" && (
          <TabContainer>
            <ErrorBoundary>
              <Comments />
            </ErrorBoundary>
          </TabContainer>
        )}
        {value === "trr" && (
          <TabContainer>
            <ErrorBoundary>
              <TRR />
            </ErrorBoundary>
          </TabContainer>
        )}
        {value === "SOA" && (
          <TabContainer>
            <ErrorBoundary>
              <SOA />
            </ErrorBoundary>
          </TabContainer>
        )}
        {value === "cob" && (
          <TabContainer>
            <ErrorBoundary>
              <COB />
            </ErrorBoundary>
          </TabContainer>
        )}
        {value === "pos" && (
          <TabContainer>
            <ErrorBoundary>
              <POS validator={this.validator} />
            </ErrorBoundary>
          </TabContainer>
        )}
        {value === "agent" && (
          <TabContainer>
            <ErrorBoundary>
              <Agent  />
            </ErrorBoundary>
          </TabContainer>
        )}
        {value === "billing" && (
          <TabContainer>
            <ErrorBoundary>
              <Billing validator={this.validator} />
            </ErrorBoundary>
          </TabContainer>
        )}
        {value === "lep" && (
          <TabContainer>
            <ErrorBoundary>
              <LEP tabName={value} />
            </ErrorBoundary>
          </TabContainer>
        )}
        {value === "ooa" && (
          <TabContainer>
            <ErrorBoundary>
              <OOA validator={this.validator} />
            </ErrorBoundary>
          </TabContainer>
        )}
        {value === "accretion" && (
          <TabContainer>
            <ErrorBoundary>
              <Accretion />
            </ErrorBoundary>
          </TabContainer>
        )}
        {servicesEnabled.includes("EEAS")
          ? value === "ases" && (
            <TabContainer>
              <ErrorBoundary>
                <ASES validator={this.validator} />
              </ErrorBoundary>
            </TabContainer>
          )
          : null}
        {/* {servicesEnabled.includes("OEV")
          ? value === "oev" && (
            <TabContainer>
              <ErrorBoundary>
                <OEV />
              </ErrorBoundary>
            </TabContainer>
          )
          : null}
        {servicesEnabled.includes("SOA")
          ? value === "soa" && (
            <TabContainer>
              <ErrorBoundary>
                <SOA />
              </ErrorBoundary>
            </TabContainer>
          )
          : null} */}
      </div>
    );
  }
}

MemberAppBar.propTypes = {
  classes: PropTypes.object.isRequired,
};

const mapStateToProps = (state) => {
  return {
    servicesEnabled: state.loginData.servicesEnabled,
  };
  
};
const mapDispatchToProps = {
  
  getShowAll,
 
};

export default connect(mapStateToProps,mapDispatchToProps)(withStyles(styles)(MemberAppBar));




