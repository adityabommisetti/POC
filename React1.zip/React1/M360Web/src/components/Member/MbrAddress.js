import { messages } from "../../constants/Messages";
import * as DateUtil from "../../utils/DatePicker";
import * as Type from "../../constants/ConfirmType";
import isEmpty from "lodash/isEmpty";
import React, { Component } from "react";
import AutoComplete1 from "../UI/Select";
import {
  deleteAddress,
  getAddress,
  insertUpdateAddress,
  updateAddressDsinfo,
  getShowAll,
  fetchMailCityCounty,
  updateIndAddressData,
} from "../../redux/actions/MemberActions";

import CheckBoxIcon from "@material-ui/icons/CheckBox";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import Checkbox from "@material-ui/core/Checkbox";
import CityZipSerachPopup from "./MbrCityZipSearch";
import ConfirmBox from "../../utils/PopUp";
import DataTable from "../Home/DataTable";
import FormLabel from "@material-ui/core/FormLabel";
import HistoryData from "../UI/MemberHistory";
import InputField from "../UI/InputField";
import MemberButtonPanel from "../UI/MemberButtonPanel";
import Modal from "../../components/UI/Modal/Modal";
import Paper from "@material-ui/core/Paper";
import Popup from "reactjs-popup";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../assets/styles/Theme";
import { connect } from "react-redux";
import { handleDateChange } from "../../utils/DateFormatter";
import { ADDRESS_TABLE_HEADER as header } from "../../constants/Headers/MemberHeaders";
import { withStyles } from "@material-ui/core/styles";
import { customValidations } from "../../utils/CustomValidations";

const INITIAL_STATE = {
  address1: "",
  address2: " ",
  address3: "",
  addressChangeCd: "",
  addressType: "",
  cellPhoneNbr: " ",
  city: "",
  countryCd: "",
  countyCd: "",
  countyName: "",
  createTime: "",
  createUserId: "",
  customerId: "",
  effEndDate: "",
  effStartDate: "",
  faxNbr: "",
  homePhoneNbr: "",
  inquiryText: "",
  lastUpdtTime: "",
  lastUpdtUserId: "",
  memberId: "",
  overrideInd: "",
  sccSurveyNum: "",
  stateCd: "",
  surveyCompInd: "",
  surveyResRcvdDt: "",
  surveyResponse: "",
  surveyText: "",
  verbInqNum: " ",
  workPhoneNbr: " ",
  zipCd: "",
  zipCd4: "",
  zipCd5: "",
  showAll: "",
};

let dateChk = {};
class MemberAddress extends Component {
  constructor(props) {
    super(props);
    this.state = {
      keyCode: 1,
      closePopup: false,
      mbrAddressVo: INITIAL_STATE,
      reset: false,
      modified: false,
      isNewSegment: false,
      //showAllActiveInd: true,
      editable: false,
      message: "",
      trigger76: false,
      mbrAddressList: null,
      memberId: this.props.mbrSearchCriteria.memberId,
      selectedIndex: 0,
      showAllData: null,
      rowsPerPage: 10,
      func1: this.showAll.bind(this),
      showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
    };

    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
        date_after: customValidations.date_after,
        date_after99: customValidations.c_after99,
        first_day_of_month: customValidations.first_day_of_month,
        last_day_of_month: customValidations.last_day_of_month,
        phone_no: customValidations.phone_no,
      },
    });
  }

  handleDates = (event) => {
    dateChk = {};
    let fieldId = "#" + event.target.name;
    var self = this;

    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        if (
          dateChk.name !== e.target.name ||
          dateChk.value !== e.target.value
        ) {
          self.setDate(e.target.name, e.target.value);
        }
        dateChk.name = e.target.name;
        dateChk.value = e.target.value;
      });
  };

  setDate = (name, value) => {
    this.setState((prevState) => ({
      mbrAddressVo: {
        ...prevState.mbrAddressVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  goBack = () => {
    const index = this.state.selectedIndex;
    const { addressData } = this.props;
    let mbrAddressVo = INITIAL_STATE;

    if (!isEmpty(addressData)) {
      mbrAddressVo = this.props.addressData[index];
    }

    this.setState({
      isNewSegment: false,
      editable: false,
      modified: false,
      mbrAddressVo: mbrAddressVo,
      reset: false,
    });
    this.validator.hideMessages();
  };

  handleChangePage = (index) => {
    this.selectRow(index);
  };

  handleZipChange = (name) => (event) => {
    let value = event.target.value;
    value = value.replace(/[^0-9]/g, "").trim();

    if (value.length > 5) {
      value =
        this.state.keyCode !== 8
          ? value.slice(0, 5) + "-" + value.slice(5, value.length)
          : value;
    }
    this.setState((prevState) => ({
      mbrAddressVo: {
        ...prevState.mbrAddressVo,
        [name]: value,
      },
      modified: true,
    }));
    if (value.length === 5 || value.length === 9) {
      this.populateCityCountyMail(value);
    }
  };

  populateCityCountyMail = async (zip) => {
    let value = zip.replace(/[^0-9]/g, "");

    if (value.length === 5 || value.length === 9) {
      const data = await this.props.fetchMailCityCounty(
        value.slice(0, 5),
        value.slice(5, value.length)
      );

      if (data && !isEmpty(data.cityList)) {
        this.setState((prevState) => ({
          mbrAddressVo: {
            ...prevState.mbrAddressVo,
            city: data.cityList[0].value,
            stateCd: data.stateCd,
            countyCd: data.countyList[0].value,
            countyName: data.countyList[0].label,
          },
          modified: true,
        }));
      } else {
        this.setState((prevState) => ({
          mbrAddressVo: {
            ...prevState.mbrAddressVo,
            city: "",
            stateCd: "",
            countyCd: "",
            countyName: "",
          },
          modified: true,
        }));
      }
    }
  };

  modalClosed = () => {
    this.setState({ closePopup: false });
  };

  handlechange = (event) => {
    let value = event.target.value.toUpperCase();
    let name = event.target.name;
    this.setState((prevState) => ({
      mbrAddressVo: {
        ...prevState.mbrAddressVo,
        [name]: value.toUpperCase(),
      },
      modified: true,
    }));
  };

  handleOnBlur = (event) => {
    let value = event.target.value.trim();
    let name = event.target.name;

    this.setState((prevState) => ({
      mbrAddressVo: {
        ...prevState.mbrAddressVo,
        [name]: value.toUpperCase(),
      },
      modified: true,
    }));
  };

  handleChangeSearchSelectAuto = async (data, name) => {
    let value = data.value;
    this.setState((prevState) => ({
      mbrAddressVo: {
        ...prevState.mbrAddressVo,
        [name]: value,
      },
      modified: true,
    }));
  };
  handleChangeSearchSelect = (name) => (event) => {
    let value = event.value;
    this.setState((prevState) => ({
      mbrAddressVo: {
        ...prevState.mbrAddressVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleNumberChange = (event) => {
    let value = event.target.value.replace(/[^0-9]/g, "").trim();
    let name = event.target.name;

    if (name !== "faxNbr") {
      value = value.replace(
        /^(?=[0-9]{10})([0-9]{3})([0-9]{3})([0-9]{4})/,
        "$1-$2-$3"
      );
    }
    this.setState((prevState) => ({
      mbrAddressVo: {
        ...prevState.mbrAddressVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  modelSegment = () => {
    if (this.state.mbrAddressVo.overrideInd === "Y") {
      let msg = "This Record is not active ";
      this.setState({ message: msg, closePopup: true });
    } else {
      this.setState({
        editable: true,
        isNewSegment: false,
      });
    }
  };

  createNewSegment = () => {
    this.validator.hideMessages();
    INITIAL_STATE.memberId = this.props.mbrSearchCriteria.memberId;
    this.setState({
      editable: true,
      isNewSegment: true,
      mbrAddressVo: {
        ...INITIAL_STATE,
        effEndDateFrmt: "99/99/9999",
      },
    });
  };

  addNewSegment = (event) => {
    event.preventDefault();
    if (this.validator.allValid()) {
      ConfirmBox(this.confirmAddNewSegment, Type.ADD, this.props);
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  confirmAddNewSegment = async () => {
    const { mbrAddressVo } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(mbrAddressVo.showAll = val),
    });

    let data = {
      ...this.state.mbrAddressVo,
      memberId: this.props.mbrSearchCriteria.memberId,
    };
    data.zipCd5 = this.state.mbrAddressVo.zipCd5
      ? this.state.mbrAddressVo.zipCd5
      : this.state.mbrAddressVo.zipCd;

    if (data.zipCd.length > 5) {
      data.zipCd = data.zipCd.replace(/-/g, "");
    }

    let status = await this.props.insertUpdateAddress(data);
    if (status === "success") {
      status = messages.INSERTED_SUCCESSFULLY;
      let mbrAddressVo = this.props.addressData[0];
      if (mbrAddressVo.zipCd.length > 5) {
        mbrAddressVo.zipCd =
          mbrAddressVo.zipCd.slice(0, 5) +
          "-" +
          mbrAddressVo.zipCd.slice(5, mbrAddressVo.zipCd.length);
      }
      this.setState(() => ({
        mbrAddressVo: mbrAddressVo,
        editable: false, // readOnly
        isNewSegment: false, //Not a new SEgment
        modified: false,
        mbrAddressList: this.props.addressData,
      }));
    }
    this.setState({
      closePopup: true,
      message: status,
      reset: false,
    });

    this.validator.hideMessages();
  };

  updateAddress = (event) => {
    event.preventDefault();
    if (this.validator.allValid()) {
      ConfirmBox(this.confirmUpdate, Type.UPDATE, this.props);
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  confirmUpdate = async () => {
    let mbrAddressVo = { ...this.state.mbrAddressVo };
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";
    this.setState({
      ...(mbrAddressVo.showAll = val),
    });

    if (mbrAddressVo.zipCd.length > 5) {
      mbrAddressVo.zipCd = mbrAddressVo.zipCd.replace(/-/g, "");
    }
    mbrAddressVo.memberId = this.props.mbrSearchCriteria.memberId;

    let status = await this.props.insertUpdateAddress(mbrAddressVo);

    if (status === "success") {
      status = messages.UPDATED_SUCCESSFULLY;
      mbrAddressVo = this.props.addressData[this.state.selectedIndex];

      if (mbrAddressVo.zipCd.length > 5) {
        mbrAddressVo.zipCd =
          mbrAddressVo.zipCd.slice(0, 5) +
          "-" +
          mbrAddressVo.zipCd.slice(5, mbrAddressVo.zipCd.length);
      }
      this.setState(() => ({
        mbrAddressVo: mbrAddressVo,
        editable: false, // readOnly
        isNewSegment: false, //Not a new SEgment
        modified: false,
        mbrAddressList: this.props.addressData,
        closePopup: true,
        message: status,
        reset: false,
      }));
    } else {
      this.setState({
        closePopup: true,
        message: status,
        reset: false,
      });
    }

    this.validator.hideMessages();
  };

  selectRow = (index) => {
    const mbrAddressList = this.state.mbrAddressList;
    const selectedVo = mbrAddressList[index];
    let value = selectedVo.zipCd;

    if (value.length > 5 && !value.includes("-")) {
      value = value.slice(0, 5) + "-" + value.slice(5, value.length);
      selectedVo.zipCd = value;
    }
    this.setState(() => ({
      mbrAddressVo: { ...selectedVo }, // copy data
      editable: false, // readOnly
      isNewSegment: false, //Not a new SEgment
      modified: false,
      selectedIndex: index,
      reset: false,
    }));
  };

  deleteAddress = (event) => {
    event.preventDefault();

    if (this.state.mbrAddressVo.addressType !== "PRIM") {
      if (this.state.mbrAddressVo.overrideInd === "Y") {
        let msg = "This Record is not active ";
        this.setState({ message: msg, closePopup: true });
      } else {
        ConfirmBox(this.confirmDeleteAddress, Type.DELETE, this.props);
      }
    } else {
      this.setState({
        closePopup: true,
        message:
          "Delete of Primary Address in not allowed Please model segment instead",
      });
    }
  };

  messageConfirm = () => { };

  confirmDeleteAddress = async () => {
    const { mbrAddressVo } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(mbrAddressVo.showAll = val),
    });
    await this.props.deleteAddress(this.state.mbrAddressVo);
    this.setState(() => ({
      mbrAddressVo: !isEmpty(this.props.addressData)
        ? this.props.addressData[0]
        : { ...INITIAL_STATE },
      editable: false,
      isNewSegment: false,
      modified: false,
      closePopup: true,
      message: messages.DELETED_SUCCESSFULLY,
      selectedIndex: 0,
      mbrAddressList: this.props.addressData,
    }));
    this.validator.hideMessages();
  };

  componentDidMount() {
    let mbrAddressList = this.props.addressData;
    let mbrAddressVo = INITIAL_STATE;
    if (this.props.showAllActiveInd.showAllActiveInd === false) {
      this.showAll(true, this.props.mbrSearchCriteria.memberId);
    } else if (!isEmpty(this.props.addressData)) {
      let value = mbrAddressList[0].zipCd;
      if (value.length > 5 && value.indexOf("-") === -1) {
        value = value.slice(0, 5) + "-" + value.slice(5, value.length);
        mbrAddressList[0].zipCd = value;
        mbrAddressVo = mbrAddressList[0];
      }
      mbrAddressVo = mbrAddressList[0];
    }

    this.setState({
      mbrAddressVo: mbrAddressVo,
      mbrAddressList: mbrAddressList,
    });
    let { showAllActiveInd, Indi } = this.props.showAllActiveInd;
    if (showAllActiveInd === false && Indi === "B") {
      this.showAll(true, this.props.mbrSearchCriteria.memberId);
    }
    if (showAllActiveInd === true) {
      this.showAll(false);
    }
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.mbrSearchCriteria.memberId !== prevState.memberId) {
      if (!isEmpty(nextProps.addressData)) {
        return {
          mbrAddressVo: nextProps.addressData[0],
          mbrAddressList: nextProps.addressData,
          showAllData: null,
          //showAllActiveInd: true,
          modified: false,
          isNewSegment: false,
          editable: false,
          selectedIndex: 0,
          memberId: nextProps.mbrSearchCriteria.memberId,
          reset: false,
          model: prevState.func1(
            nextProps.showAllActiveInd.showAllActiveInd === false ? true : "N",
            nextProps.mbrSearchCriteria.memberId
          ),
        };
      }
      return {
        mbrAddressVo: INITIAL_STATE,
        mbrAddressList: [],
        showAllData: null,
        //showAllActiveInd: true,
        modified: false,
        isNewSegment: false,
        editable: false,
        selectedIndex: 0,
        memberId: nextProps.mbrSearchCriteria.memberId,
        reset: false,
        model: prevState.func1(
          nextProps.showAllActiveInd.showAllActiveInd === false ? true : "N",
          nextProps.mbrSearchCriteria.memberId
        ),
      };
    }
    if (
      nextProps.showAllActiveInd.showAllActiveInd !== prevState.showAllActiveInd
    ) {
      if (nextProps.showAllActiveInd.showAllActiveInd === false) {
        return {
          model: prevState.func1(true, nextProps.mbrSearchCriteria.memberId),
        };
      } else if (nextProps.showAllActiveInd.showAllActiveInd === true) {
        return {
          model: prevState.func1(false, nextProps.mbrSearchCriteria.memberId),
        };
      }
    }
    return prevState;
  }

  showAll = async (flag, mbrId) => {
    //const active = !this.state.showAllActiveInd;
    const memberId = mbrId;
    let { showAllData } = this.state;
    let mbrAddressVo = INITIAL_STATE;
    let mbrAddressList = [];
    if (flag === true) {
      if (showAllData === null) {
        const data = await this.props.getShowAll({
          url: "GET_ADDRESS",
          memberId: memberId + "/Y",
        });
        if (null != data) {
          const selectedVo = data.length > 0 ? data[0] : { ...INITIAL_STATE };
          mbrAddressVo = selectedVo;
          mbrAddressList = data;
          showAllData = data;
        }
      } else {
        mbrAddressVo = !isEmpty(showAllData)
          ? showAllData[0]
          : { ...INITIAL_STATE };
        mbrAddressList = showAllData;
      }
    } else {
      if (flag === "N") {
         await this.props.getShowAll({
          url: "GET_ADDRESS",
          memberId: memberId + "/N",
        });
      } else {
        let recodN = await (this.props.addressData === null
          ? []
          : this.props.addressData.filter((role) => role.overrideInd === "N"));

        await this.props.updateIndAddressData(recodN);
      }

      mbrAddressList = this.props.addressData;
      const selectedVo = !isEmpty(mbrAddressList)
        ? mbrAddressList[0]
        : { ...INITIAL_STATE };
      mbrAddressVo = selectedVo;
    }
    this.setState(() => ({
      mbrAddressVo: mbrAddressVo ? mbrAddressVo : { ...INITIAL_STATE },
      mbrAddressList: mbrAddressList,
      showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
      selectedIndex: 0,
      showAllData: showAllData,
      isNewSegment: false,
      editable: false,
    }));
  };

  updateCityStatae = (data) => {
    this.setState((prevState) => ({
      mbrAddressVo: {
        ...prevState.mbrAddressVo,
        city: data.perCity,
        stateCd: data.perStateCd,
        zipCd: data.perZip5 + "-" + data.perZip4,
        countyCd: data.countyCd,
        zipCd5: data.perZip5 + "-" + data.perZip4,
        countyName: data.perCounty,
      },
      modified: true,
    }));
  };

  editOverrideInd = () => {
    this.setState((prevState) => ({
      mbrAddressVo: {
        ...prevState.mbrAddressVo,
        editOverrideInd: "Y",
      },
    }));
  };

  checked = (e) => {
    let { reset } = this.state;
    if (!reset) {
      ConfirmBox(this.editOverrideInd, Type.SUPPRESSTC, this.props, () => {
        this.setState((prevState) => ({
          reset: false,
        }));
      });
    } else {
      this.setState((prevState) => ({
        mbrAddressVo: {
          ...prevState.mbrAddressVo,
          editOverrideInd: "",
        },
        reset: false,
      }));
    }
    this.setState((prevState) => ({
      reset: !reset,
    }));
  };

  handleDate = (event) => {
    let value = event.target.value;
    let name = event.target.name;
    this.setState((prevState) => ({
      mbrAddressVo: {
        ...prevState.mbrAddressVo,
        [name]: handleDateChange(value),
      },
      modified: true,
    }));
  };
  handleChangeRowsPerPage = async (rowsPerPage) => {
    await this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  render() {
    const { classes, dropdowns } = this.props;
    const { mbrAddressVo, editable, mbrAddressList } = this.state;

    let ButtonPanel = (
      <MemberButtonPanel
        isNewSegment={this.state.isNewSegment}
        //showAll={this.showAll}
        //toggleLabel={this.state.showAllActiveInd}
        newSegment={this.createNewSegment}
        modelSegment={this.modelSegment}
        modified={this.state.modified}
        editable={editable}
        delete={this.deleteAddress}
        update={this.updateAddress}
        disable={isEmpty(mbrAddressList)}
      />
    );

    return (
      <React.Fragment>
        <Modal
          dialogTitle="Address"
          message={this.state.message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Paper elevation={0} className={classes.card}>
          {mbrAddressList ? (
            <React.Fragment>
              <DataTable
                data={mbrAddressList}
                header={header}
                sortable={true}
                rowsPerPageOptions={[10, 15, 20]}
                handleChangeRowsPerPage={this.handleChangeRowsPerPage}
                rowsPerPage={this.state.rowsPerPage}
                clicked={this.selectRow}
                index={this.state.selectedIndex}
                handleChangePage={this.handleChangePage}
                dateColumn={["effStartDateFrmt", "effEndDateFrmt"]}
                subtab
              />

              <form autoComplete="off">
                <div className={classes.buttonContainer}> {ButtonPanel}</div>

                <div class="panel-body margin-top1">
                  <div className={classes.searchCheckbox}>
                    <Checkbox
                      disabled={!editable}
                      id="editOverrideInd"
                      style={{ width: 36, height: 36 }}
                      icon={
                        <CheckBoxOutlineBlankIcon
                          style={{ fontSize: "16px" }}
                        />
                      }
                      checkedIcon={
                        <CheckBoxIcon className={classes.checkboxmember} />
                      }
                      onClick={(e) => {
                        this.checked(e);
                      }}
                      checked={this.state.reset}
                    />
                    <FormLabel classes={{ root: classes.formLabel }}>
                      Bypass 76 TXN
                    </FormLabel>
                  </div>

                  <div className={classes.container}>
                    <div className={classes.Margin}>
                      <AutoComplete1
                        handleChange={this.handleChangeSearchSelectAuto}
                        label="Address Type"
                        options={dropdowns.validAddressTypes}
                        defaultValue={dropdowns.validAddressTypes[0]}
                        value={
                          dropdowns.validAddressTypes.filter(
                            (data) => data.value === mbrAddressVo.addressType
                          )[0]
                        }
                        name="addressType"
                        disabled={!editable}
                      />
                     
                      <div className={classes.validationMessageSelect}>
                        {this.validator.message(
                          "Address Type",
                          mbrAddressVo.addressType,
                          "required"
                        )}
                      </div>
                    </div>

                    <div className={classes.Margin1}>
                      <InputField
                        name="effStartDateFrmt"
                        placeholder="MM/DD/YYYY"
                        width="185px"
                        onClick={this.handleDates}
                        label="Start Date"
                        required={editable}
                        value={mbrAddressVo.effStartDateFrmt}
                        onChange={this.handleDate}
                        onBlur={this.handleOnBlur}
                        disabled={!editable}
                        maxLength={10}
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "Start Date",
                          mbrAddressVo.effStartDateFrmt,
                          "required|first_day_of_month|date_format"
                        )}
                      </div>

                      <div />
                    </div>
                    <div className={classes.Margin}>
                      <InputField
                        name="effEndDateFrmt"
                        placeholder="MM/DD/YYYY"
                        onClick={this.handleDates}
                        label="End Date"
                        width="180px"
                        onChange={this.handleDate}
                        onBlur={this.handleOnBlur}
                        required={editable}
                        value={mbrAddressVo.effEndDateFrmt}
                        disabled={!editable}
                        maxLength={10}
                      />

                      <div className={classes.validationMessage}>
                        {this.validator.message(
                            "EndDate",
                          mbrAddressVo.effEndDateFrmt,
                          [
                            "required",
                            "date_format",
                            "last_day_of_month",
                            { date_after99: mbrAddressVo.effStartDateFrmt },
                          ]
                        )}
                      </div>
                    </div>
                    <div className={classes.Margin}>
                      <InputField
                        name="overrideInd"
                        label="Override"
                        width="180px"
                        value={mbrAddressVo.overrideInd}
                        // onChange={this.handlechange}
                        onBlur={this.handleOnBlur}
                        disabled={true}
                      />
                      <div className={classes.validationMessage} />
                    </div>

                    <div className={classes.Margin1}>
                      <InputField
                        name="address1"
                        required={editable}
                        label="Address Line 1"
                        width={"408px"}
                        value={mbrAddressVo.address1}
                        onChange={this.handlechange}
                        onBlur={this.handleOnBlur}
                        disabled={!editable}
                        maxLength={50}
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "address1",
                          mbrAddressVo.address1,
                          "required"
                        )}
                      </div>
                    </div>

                    <div className={classes.Margin}>
                      <InputField
                        name="address2"
                        maxLength={50}
                        width="180px"
                        label="Address Line 2"
                        value={mbrAddressVo.address2}
                        onChange={this.handlechange}
                        onBlur={this.handleOnBlur}
                        disabled={!editable}
                      />
                      <div className={classes.validationMessage} />
                    </div>

                    <div className={classes.Margin}>
                      <InputField
                        name="address3"
                        InputProps={{
                          className: classes.textFont,
                          inputProps: {
                            maxLength: 50,
                          },
                        }}
                        label="Address Line 3"
                        width="180px"
                        value={mbrAddressVo.address3}
                        onChange={this.handlechange}
                        maxLength={50}
                        onBlur={this.handleOnBlur}
                        disabled={!editable}
                      />
                      <div className={classes.validationMessage} />
                    </div>

                    <div className={classes.Margin}>
                      <InputField
                        name="city"
                        maxLength={50}
                        required={editable}
                        label="City"
                        width="408px"
                        value={mbrAddressVo.city}
                        onChange={this.handlechange}
                        onBlur={this.handleOnBlur}
                        disabled={!editable}
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "City",
                          mbrAddressVo.city,
                          "required"
                        )}
                      </div>
                    </div>

                    <div className={classes.Margin}>
                      <AutoComplete1
                        handleChange={this.handleChangeSearchSelectAuto}
                        label="State"
                        options={dropdowns.validStates}
                        defaultValue={dropdowns.validStates[0]}
                        value={
                          dropdowns.validStates.filter(
                            (data) => data.value === mbrAddressVo.stateCd
                          )[0]
                        }
                        name="stateCd"
                        disabled={!editable}
                      />
                      <div className={classes.validationMessageSelect}>
                        {this.validator.message(
                          "State",
                          mbrAddressVo.stateCd,
                          "required"
                        )}
                      </div>
                    </div>

                    <div>
                      <span class="label-container">
                        <label for="zipCd">Zip</label>
                        <span className="imp">*</span>
                        <br />
                        <div className={classes.Margin1}>
                          <input
                            type="text"
                            class="form-field"
                            id="zipCd"
                            name="zipCd"
                            value={mbrAddressVo.zipCd}
                            maxLength="10"
                            onChange={this.handleZipChange("zipCd")}
                            onKeyDown={(e) => {
                              this.setState({ keyCode: e.keyCode });
                            }}
                            disabled={!editable}
                          />
                          {editable ? (
                            <Popup
                              style={{ height: "65%" }}
                              className={classes.mobileWidth}
                              modal
                              trigger={<span class="more-info" />}
                              position="right center"
                            >
                              {(close) => (
                                <div>
                                  <CityZipSerachPopup
                                    headerLabel="City Zip Search"
                                    zip5={mbrAddressVo.zipCd.slice(0, 5)}
                                    zip4={mbrAddressVo.zipCd.slice(6, 10)}
                                    searchType="Zip_SEARCH"
                                    setCity={this.setCity}
                                    setZip={this.setZip}
                                    close={close}
                                    setData={this.updateCityStatae}
                                  />
                                </div>
                              )}
                            </Popup>
                          ) : null}</div>
                      </span>
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "zipCd",
                          mbrAddressVo.zipCd,
                          "required"
                        )}
                      </div>
                    </div>
                    <div>
                      <AutoComplete1
                        handleChange={this.handleChangeSearchSelectAuto}
                        label="Country"
                        options={dropdowns.validCountry}
                        defaultValue={dropdowns.validCountry[0]}
                        value={
                          dropdowns.validCountry.filter(
                            (data) => data.value === mbrAddressVo.countryCd
                          )[0]
                        }
                        name="countryCd"
                        width="405px"
                        disabled={!editable}
                      // margin='1.5vw'
                      />
                     
                      <div className={classes.validationMessageSelect}>
                        {mbrAddressVo && mbrAddressVo.addressType === "PRIM"
                          ? this.validator.message(
                            "Country",
                            mbrAddressVo.countryCd,
                            "CountryUSA"
                          )
                          : null}
                      </div>
                    </div>
                    <div class={classes.countyMagin}>
                      <InputField
                        name="countyName"
                        label="County"
                        width="180px"
                        value={mbrAddressVo.countyName}
                        onChange={this.handlechange}
                        onBlur={this.handleOnBlur}
                        disabled={!editable}
                      />
                      <div className={classes.validationMessageSelect} />
                    </div>

                    <div className={classes.Margin}>
                      <InputField
                        name="homePhoneNbr"
                        label="Home Phone"
                        maxLength={12}
                        width="180px"
                        value={mbrAddressVo.homePhoneNbr}
                        onChange={this.handleNumberChange}
                        onBlur={this.handleOnBlur}
                        disabled={!editable}
                      />
                      <div className={classes.validationMessageSelect}>
                        {this.validator.message(
                          "Home Phone",
                          mbrAddressVo.homePhoneNbr,
                          "phone_no"
                        )}
                      </div>
                    </div>

                    <div className={classes.Margin}>
                      <InputField
                        name="cellPhoneNbr"
                        label="Cell Phone"
                        maxLength={12}
                        width="180px"
                        value={mbrAddressVo.cellPhoneNbr}
                        onChange={this.handleNumberChange}
                        onBlur={this.handleOnBlur}
                        disabled={!editable}
                      />
                      <div className={classes.validationMessageSelect}>
                        {this.validator.message(
                          "Cell Phone",
                          mbrAddressVo.cellPhoneNbr,
                          "phone_no"
                        )}
                      </div>
                    </div>
                    <div className={classes.Margin1}>
                      <InputField
                        name="workPhoneNbr"
                        label="Work Phone"
                        maxLength={12}
                        width="180px"
                        value={mbrAddressVo.workPhoneNbr}
                        onChange={this.handleNumberChange}
                        onBlur={this.handleOnBlur}
                        disabled={!editable}
                      />
                      <div className={classes.validationMessageSelect}>
                        {this.validator.message(
                          "Work Phone",
                          mbrAddressVo.workPhoneNbr,
                          "phone_no"
                        )}
                      </div>
                    </div>
                    <div>
                      <InputField
                        name="faxNbr"
                        label="FAX"
                        width="180px"
                        maxLength={10}
                        value={mbrAddressVo.faxNbr}
                        onChange={this.handleNumberChange}
                        onBlur={this.handleOnBlur}
                        disabled={!editable}
                      />
                      <div className={classes.validationMessageSelect}>
                        {this.validator.message(
                          "FAX",
                          mbrAddressVo.faxNbr,
                          "phone_no"
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </form>

              <HistoryData
                isNewSegment={this.state.isNewSegment}
                reset={this.createNewSegment}
                addSegment={this.addNewSegment}
                back={this.goBack}
                createUserId={mbrAddressVo.createUserId}
                createTime={mbrAddressVo.createTime}
                lastUpdtTime={mbrAddressVo.lastUpdtTime}
                lastUpdtUserId={mbrAddressVo.lastUpdtUserId}
              />
            </React.Fragment>
          ) : (
              <div className={classes.buttonContainer}> {ButtonPanel}</div>
            )}
        </Paper>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    addressData: state.memberSearch.searchResultsVo.mbrAddressList,
    mbrSearchCriteria: state.memberSearch.mbrSearchCriteria,
    dropdowns: state.membercache,
    servicesEnabled: state.loginData.servicesEnabled,
    memberIdCheck: state.memberSearch.memberId,
    showAllActiveInd: state.memberSearch.showAllActiveIndi,
  };
};
const mapDispatchToProps = {
  getAddress,
  insertUpdateAddress,
  deleteAddress,
  getShowAll,
  updateAddressDsinfo,
  fetchMailCityCounty,
  updateIndAddressData,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(MemberAddress));
