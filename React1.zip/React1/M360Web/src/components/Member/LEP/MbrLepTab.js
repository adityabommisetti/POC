import React from "react";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import Typography from "@material-ui/core/Typography";
import Attestation from "../../UI/LepAttestation";
import AttestationCalls from "./MbrAttestationCalls";
import Summary from "../../UI/LepSummary";
import Maximus from "./MbrMaximus";
import UncoveredData from "./MbrUncoveredData";
import LEPData from "./MbrLep";
import {
  fetchMbrLep,
  showAllMbrAttestationData,
  showActiveMbrAttestationData,
  copyAttestationData,
  setMbrLepValue,
  updateAttestationLetter,
  showAllLepData,
} from "../../../redux/actions/MemberActions";
import { connect } from "react-redux";
import isEmpty from "lodash/isEmpty";

function TabContainer(props) {
  return (
    <Typography component="div" style={{ padding: 8 }}>
      {props.children}
    </Typography>
  );
}

function LinkTab(props) {
  return (
    <Tab component="a" onClick={(event) => event.preventDefault()} {...props} />
  );
}

const Styles = (theme) => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
  },
  bigIndicator: {
    height: 2,
    backgroundColor: "white",
  },
});

class LEP extends React.Component {
  state = {
    value: 0,
    selectedRow: 0,
    selectedIndex: 0,
    memberId: null,
  };

  handleChange = (event, value) => {
    this.setState({ value });
  };

  componentDidMount() {
    if (
      isEmpty(this.props.lepData) ||
      (!isEmpty(this.props.lepData) &&
        this.props.lepData.primaryId !==
          this.props.searchResultsVo.mbrDemographicVO.memberId)
    ) {
      this.props.fetchMbrLep(
        this.props.memberId,
        this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N"
      );
    }

    this.setState({
      selectedRow: 0,
      selectedIndex: 0,
    });
    //if (this.props.showAllActiveInd.showAllActiveInd === false) {
    //this.props.showAllLepData(this.props.memberId);
    //}
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (
      this.props.memberId !== nextProps.memberId &&
      this.props.tabName === "lep"
    ) {
    }
    if (this.props.memberId !== nextProps.memberId) {
      this.setState({
        memberId: nextProps.memberId,
      });
    }
  }

  setSelectedRow = (index, row) => {
    this.setState({
      selectedRow: row,
      selectedIndex: index,
    });
  };

  render() {
    const { classes, lepData, memberId } = this.props;
    const { value } = this.state;
    return (
      <div className={classes.root}>
        <React.Fragment>
          <AppBar position="static">
            <Tabs
              variant="fullWidth"
              value={value}
              onChange={this.handleChange}
              classes={{ indicator: classes.bigIndicator }}
            >
              <LinkTab label="LEP" href="page1" />
              <LinkTab label="SUMMARY" href="page2" />
              <LinkTab label="UNCOVERED DATA" href="page3" />
              <LinkTab label="ATTESTATION" href="page4" />
              <LinkTab label="ATTESTATION CALLS" href="page5" />
              <LinkTab label="MAXIMUS" href="page6" />
            </Tabs>
          </AppBar>
          {value === 0 && (
            <TabContainer>
              <LEPData />
            </TabContainer>
          )}
          {value === 1 && (
            <TabContainer>
              <Summary
                data={!isEmpty(lepData) ? lepData.lepSummaryVO : []}
                nunCMOList={
                  !isEmpty(lepData) ? lepData.lepSummaryVO.nunCMOList : []
                }
                rdsList={!isEmpty(lepData) ? lepData.lepSummaryVO.rdsList : []}
                partDList={
                  !isEmpty(lepData) ? lepData.lepSummaryVO.partDList : []
                }
              />
            </TabContainer>
          )}
          {value === 2 && (
            <TabContainer>
              <UncoveredData />
            </TabContainer>
          )}
          {value === 3 && (
            <TabContainer>
              <Attestation
                showAllAttestationData={this.props.showAllMbrAttestationData}
                showActiveAttestationList={
                  this.props.showActiveMbrAttestationData
                }
                copyAttestationData={this.props.copyAttestationData}
                data={!isEmpty(lepData) ? lepData.lepAttestInfoVO : []}
                primaryId={memberId}
                mbrLep={true}
                uncovList={
                  !isEmpty(lepData) ? lepData.potentialUnCovMthsList : []
                }
                lepEffDate={this.props.lepEffDate}
                setLepValue={this.props.setMbrLepValue}
                updateAttestationLetter={this.props.updateAttestationLetter}
                supLepMbr={this.props.searchResultsVo.suppLepPlatino}
              />
            </TabContainer>
          )}
          {value === 4 && (
            <TabContainer>
              <AttestationCalls />
            </TabContainer>
          )}
          {value === 5 && (
            <TabContainer>
              <Maximus />
            </TabContainer>
          )}
        </React.Fragment>
      </div>
    );
  }
}

LEP.propTypes = {
  classes: PropTypes.object.isRequired,
};

const mapStateToProps = (state) => {
  return {
    lepData: state.memberSearch.lepData,
    memberId: state.memberSearch.mbrSearchCriteria.memberId,
    searchResultsVo: state.memberSearch.searchResultsVo,
    lepEffDate: !isEmpty(state.memberSearch.searchResultsVo.mbrEnrollmentList)
      ? state.memberSearch.searchResultsVo.mbrEnrollmentList[0].effStartDateFrmt
      : "",
    showAllActiveInd: state.memberSearch.showAllActiveIndi,
  };
};

const mapDispatchToProps = {
  fetchMbrLep,
  showAllMbrAttestationData,
  showActiveMbrAttestationData,
  copyAttestationData,
  setMbrLepValue,
  updateAttestationLetter,
  showAllLepData,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(LEP));
