import * as DateUtil from "../../../utils/DatePicker";

import React, { Component } from "react";
import {
  setMbrLepValue,
  updateAttestationLetter,
} from "../../../redux/actions/MemberActions";

import HistoryData from "../../UI/MemberHistory";
import SimpleReactValidator from "simple-react-validator";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import { connect } from "react-redux";
import { customValidations } from "../../../utils/CustomValidations";
import { styles } from "../../../assets/styles/DataTableStyle";
import { withStyles } from "@material-ui/core/styles";

class AttestationReceived extends Component {
  constructor(props) {
    super(props);
    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
      },
    });
  }

  handlechange = (event) => {
    let value = event.target.value;
    let name = event.target.name;
    this.setValue(name, value);
  };
  
  handleDate = (event) => {
    let fieldId = "#" + event.target.name;

    var self = this;
    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        self.setValue(e.target.name, e.target.value);
      });
  };
  

  handleDateChange = (event) => {
    let value = event.target.value;
    let name = event.target.name;
    value = value.replace(/[^0-9]/g, "").trim();
    if (value.length === 8) {
      value = value.replace(/^(\d{2})/, "$1/");
      value = value.replace(/\/(\d{2})/, "/$1/");
      value = value.replace(/(\d)\/(\d{4}).*/, "$1/$2");
    }
    this.setValue(name, value);
  };

  setValue = (name, value) => {
    this.props.setMbrLepValue(name, value, "lepAttestInfoVO");
  };

  render() {
    const { classes, data } = this.props;

    return (
      <div style={{ width: "100%", textAlign: "center" }}>
        <div
          className={classes.tableWrapper}
          style={{ width: this.props.width ? this.props.width : "100%" }}
        >
          <Table className={classes.tableModified}>
            <TableHead className={classes.thead}>
              <TableRow className={classes.headRow}>
                <TableCell
                  className={classes.headerCell}
                  colSpan={3}
                  align="center"
                  style={{ borderRight: "1px solid white" }}
                >
                  Attestation Received after 90 days
                </TableCell>
              </TableRow>

              <TableRow className={classes.headRow}>
                <TableCell
                  className={classes.headerCell}
                  style={{ borderRight: "1px solid white" }}
                >
                  Received Date
                </TableCell>
                <TableCell
                  className={classes.headerCell}
                  style={{ borderRight: "1px solid white" }}
                >
                  Response Type
                </TableCell>
                <TableCell
                  className={classes.headerCell}
                  style={{ borderRight: "1px solid white" }}
                >
                  Notified member of appeal instructions?
                </TableCell>
              </TableRow>
            </TableHead>

            <TableBody className={classes.tbody}>
              {data ? (
                <TableRow className={classes.row} align="center">
                  <TableCell className={classes.tableCell} align="center">
                    <div>
                      <input
                        id="attestationRecDateFrmt"
                        name="attestationRecDateFrmt"
                        placeholder= "MM/DD/YYYY"
                        label="Received Date "
                        required
                        style={{
                          width: "90px",
                          textTransform: "uppercase",
                        }}
                        className="form-field"
                        value={data.attestationRecDateFrmt}
                        onChange={this.handleDateChange}
                        onClick={this.handleDate}
                        disabled={data.enableAttestAfter90DaysSection ===false}
                      />
                      <div className={classes.validationMessage}></div>
                    </div>
                  </TableCell>

                  <TableCell className={classes.tableCell} align="center">
                    <div>
                      <select
                        name="attestationRecChannel"
                        class="lepSelect"
                        id="attestationRecChannel"
                        value={data.attestationRecChannel}
                        onChange={this.handlechange}
                        disabled={!data.enableAttestAfter90DaysSection}
                      >
                        <option value="">Select</option>
                        <option value="X">Fax</option>
                        <option value="F">Form</option>
                        <option value="T">Telephonic</option>
                        <option value="O">Onsite</option>
                      </select>

                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "ResponseType",
                          data.attestationRecChannel,
                          "required"
                        )}
                      </div>
                    </div>
                  </TableCell>

                  <TableCell className={classes.tableCell} align="center">
                    <div>
                      <select
                        name="notifiedMemberAppeal"
                        class="lepSelect"
                        id="notifiedMemberAppeal"
                        value={data.notifiedMemberAppeal}
                        onChange={this.handlechange}
                         disabled={!data.enableAttestAfter90DaysSection}
                      >
                        <option value="Y">Yes</option>
                        <option value="N">No</option>
                      </select>
                      {/* <input
                        name="notifiedMemberAppeal"
                        label="Notified Member of Appeal Instructions "
                        required
                        style={{
                          width: "90px",
                          textTransform: "uppercase"
                        }}
                        className="form-field"
                        value={data.notifiedMemberAppeal}
                        //disabled={!data.enableAttestAfter90DaysSection}
                        onChange={this.handlechange}
                      />*/}
                      <div className={classes.validationMessage}></div>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                <TableRow className={classes.row}>
                  <TableCell className={classes.tableCell} colSpan={5}>
                    No Data Found
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
          <HistoryData
            createUserId={data.otherCreateUserId}
            createTime={data.otherCreateTime}
            lastUpdtTime={data.otherLastUpdtTime}
            lastUpdtUserId={data.otherLastUpdtUserId}
          />
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    data: state.memberSearch.lepData.lepAttestInfoVO,
  };
};
const mapDispatchToProps = {
  setMbrLepValue,
  updateAttestationLetter,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(AttestationReceived));
