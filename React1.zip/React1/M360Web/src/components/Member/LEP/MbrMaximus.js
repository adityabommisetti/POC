import * as DateUtil from "../../../utils/DatePicker";
import * as Type from "../../../constants/ConfirmType";

import React, { Component } from "react";
import Autocomplete1 from "../../UI/Select";
import {
  setMbrLepValue,
  updateMaximus,
} from "../../../redux/actions/MemberActions";

import Button from "@material-ui/core/Button";
import ConfirmBox from "../../../utils/PopUp";
import { DECISION_TYPE_LIST } from "../../../constants/SelectStaticData";
import HistoryData from "../../UI/MemberHistory";
import InputField from "../../UI/InputField";
import Modal from "../../UI/Modal/Modal";
import Paper from "@material-ui/core/Paper";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../../assets/styles/Theme";
import Typography from "@material-ui/core/Typography";
import { connect } from "react-redux";
import { customValidations } from "../../../utils/CustomValidations";
import { withStyles } from "@material-ui/core/styles";
import { handleDateChange } from "../../../utils/DateFormatter";
import isEmpty from "lodash/isEmpty";

class Maximus extends Component {
  state = {};
  constructor(props) {
    super(props);
    this.state = {
      showModal: false,
      message: "",
      memberId :this.props.mbrSearchCriteria
    };
    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
        after_start_date: customValidations.c_after_or_equal,
      },
    });
  }

  handleChange = (event) => {
    let value = event.target.value;
    let name = event.target.name;
    this.props.setMbrLepValue(name, value, "eemlepMaximusVO");
  };
  //handleChangeDropDown = (name) => (event) => {
  handleChangeSearchSelectAuto = (data, name) => {
    let value = data.value;
    this.props.setMbrLepValue(name, value, "eemlepMaximusVO");
  };
componentDidUpdate(){
  // memberId :this.props.mbrSearchCriteria
  if(this.state.memberId !==this.props.mbrSearchCriteria){
    this.setState({memberId :this.props.mbrSearchCriteria})
    this.validator.hideMessages();
  }
}
  handleDateChange = (event) => {
    const name = event.target.name;
    let value = event.target.value;
    // if (value.length === 8) {

    //   value = value.replace(/[^0-9]/g, "").trim();
    //   value = value.replace(/^(\d{2})/, "$1/");
    //   value = value.replace(/\/(\d{2})/, "/$1/");
    //   value = value.replace(/(\d)\/(\d{4}).*/, "$1/$2");
    // }
    this.props.setMbrLepValue(name, handleDateChange(value), "eemlepMaximusVO");
  };

  handleDates = (event) => {
    const fieldId = "#" + event.target.name;
    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        this.props.setMbrLepValue(
          e.target.name,
          e.target.value,
          "eemlepMaximusVO"
        );
      });
  };

  update = (event) => {
    const { lepData } = this.props;
    event.preventDefault();
    if (!this.validator.allValid()) {
      this.validator.showMessages();
      this.forceUpdate();
      return;
    }
    if (!isEmpty(lepData))
      ConfirmBox(this.confirmUpdate, Type.UPDATE, this.props);
    else {
      this.setState({
        message: "Member does not have LEP",
        showModal: true,
      });
    }
  };
  confirmUpdate = () => {
    let payload = {
      ...this.props.data,
      memberId: this.props.memberId,
    };
    const status = this.props.updateMaximus(payload);
    this.setModal(status);
  };
  modalClosed = () => {
    this.setState({ showModal: false });
  };

  setModal = (status) => {
    status
      .then((msg) =>
        this.setState({
          message: msg,
          showModal: true,
        })
      )
      .catch((msg) =>
        this.setState({
          message: msg,
          showModal: true,
        })
      );
  };

  render() {
    const { classes, data } = this.props;
    return (
      <Paper elevation={0} className={classes.card}>
        <Modal
          dialogTitle="LEP"
          message={this.state.message}
          show={this.state.showModal}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Typography
          variant="h6"
          id="tableTitle"
          className={classes.attestation}
        >
          MAXIMUS Reconsideration
        </Typography>

        <form autoComplete="off">
          <div class="panel-body margin-top1">
            <div className={classes.container}>
              <div>
                <InputField
                  name="caseFileRecDateFrmt"
                  placeholder="MM/DD/YYYY"
                  onClick={this.handleDates}
                  label="Case File Record Date"
                  required
                  value={data.caseFileRecDateFrmt}
                  onChange={this.handleDateChange}
                  disabled={this.state.editable}
                />
                <div className={classes.validationMessage}>
                  {this.validator.message(
                    "CaseFileRecordDate",
                    data.caseFileRecDateFrmt,
                    "required|date_format"
                  )}
                </div>
              </div>
              <div>
                <InputField
                  name="caseFileDueDateFrmt"
                  onClick={this.handleDates}
                  label="Case File Due Date"
                  required
                  inputclassname={classes.textFont}
                  value={data.caseFileDueDateFrmt}
                  onChange={this.handleDateChange}
                  disabled={!this.state.editable}
                />
                <div className={classes.validationMessage}></div>
              </div>
              <div>
                <InputField
                  name="decisionRecDateFrmt"
                  placeholder="MM/DD/YYYY"
                  onClick={this.handleDates}
                  label="Decision Rec Date"
                  required
                  value={data.decisionRecDateFrmt}
                  onChange={this.handleDateChange}
                  disabled={this.state.editable}
                />
                <div className={classes.validationMessage}>
                  {this.validator.message(
                    "CaseFileRecordDate",
                    data.decisionRecDateFrmt,
                    [
                      "date_format",
                      { after_start_date: data.caseFileRecDateFrmt },
                    ]
                  )}
                </div>
              </div>

              <div className={classes.Select2}>
                <Autocomplete1
                  handleChange={this.handleChangeSearchSelectAuto}
                  label="Decision Type"
                  options={DECISION_TYPE_LIST}
                  defaultValue={data.decisionType?DECISION_TYPE_LIST.filter((da)=>da.value ===data.decisionType)[0]:DECISION_TYPE_LIST[0]}
                  value={data.decisionType?DECISION_TYPE_LIST.filter((da)=>da.value ===data.decisionType)[0]:DECISION_TYPE_LIST[0]}
                  name="decisionType"
                  margin="0px"
                  fontSize="0.718em"
                  disabled={this.state.editable}
                />
                <div className={classes.validationMessage}>
                  {data.decisionRecDateFrmt
                    ? this.validator.message(
                      "decisionType",
                      data.decisionType,
                      "required"
                    )
                    : null}
                </div>
              </div>
              <div>
                <InputField
                  name="transactionDueDateFrmt"
                  placeholder="MM/DD/YYYY"
                  onClick={this.handleDates}
                  label="73 Tr.Due Date"
                  required
                  value={data.transactionDueDateFrmt}
                  onChange={this.handleDateChange}
                />
                <div className={classes.validationMessage}></div>
              </div>

              <div>
                <InputField
                  name="caseFileNumber"
                  label="Case File Number"
                  required
                  value={data.caseFileNumber}
                  onChange={this.handleChange}
                  maxLength={20}
                />
                <div className={classes.validationMessage}>
                  {this.validator.message(
                    "caseFileNumber",
                    data.caseFileNumber,
                    "required"
                  )}
                </div>
              </div>
            </div>
          </div>
          <div className={classes.buttonContainer}>
            <Button
              variant="contained"
              color="primary"
              onClick={this.update}
              className={classes.button}
              disabled={this.props.searchResultsVo.suppLepPlatino === "true"}
            >
              Update
            </Button>
          </div>
        </form>
        <HistoryData
          createTime={data.createTime}
          createUserId={data.createUserId}
          lastUpdtTime={data.lastUpdtTime}
          lastUpdtUserId={data.lastUpdtUserId}
        />
      </Paper>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    data: state.memberSearch.lepData.eemlepMaximusVO,
    lepData: state.memberSearch.lepData.eemMbrLepInfoVOs,
    memberId: state.memberSearch.lepData.primaryId,
    searchResultsVo: state.memberSearch.searchResultsVo,
    mbrSearchCriteria: state.memberSearch.mbrSearchCriteria,
    //uncovList: state.applSearch.lepData.potentialUnCovMthsList
  };
};

const mapDispatchToProps = { setMbrLepValue, updateMaximus };

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(Maximus));
