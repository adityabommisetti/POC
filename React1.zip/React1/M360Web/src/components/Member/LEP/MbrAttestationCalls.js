import * as Type from "../../../constants/ConfirmType";

import React, { Component } from "react";

import Button from "@material-ui/core/Button";
import ConfirmBox from "../../../utils/PopUp";
import DataTableAttestCall from "../../UI/DataTableAttestCall";
import Modal from "../../UI/Modal/Modal";
import Paper from "@material-ui/core/Paper";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../../assets/styles/Theme";
import { connect } from "react-redux";
import { customValidations } from "../../../utils/CustomValidations";
import { updateAttestationCall } from "../../../redux/actions/MemberActions";
import { withStyles } from "@material-ui/core/styles";

const INITIAL_STATE = {
  outBoundInitial: {
    date: "",
    status: "",
    isChange: "N",
  },
  inBoundInitial: {
    date: "",
    status: "",
    isChange: "N",
  },
  outBoundInComplete: {
    date: "",
    status: "",
    isChange: "N",
  },
  inBoundInComplete: {
    date: "",
    status: "",
    isChange: "N",
  },
  inBoundLate: {
    date: "",
    status: "",
    isChange: "N",
  },
};
class AttestationCalls extends Component {
  constructor(props) {
    super(props);
    this.state = {
      vo: {
        ...INITIAL_STATE,
        showModal: false,
        message: "",
      },
    };
    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
        date_before: customValidations.c_date_before_or_equal,
        not_before_30_days: customValidations.c_after,
      },
    });
  }
  setValue = (id, value, targetVo) => {
    this.setState((prevState) => ({
      vo: {
        ...prevState.vo,
        [targetVo]: {
          ...prevState.vo[targetVo],
          [id]: value,
          isChange: "Y",
        },
      },
    }));
  };

  update = () => {
    /* const currStatus = this.props.applStatus;
    if (currStatus == "COMPLETED") {
      alert("Application Cannot be UPDATED!! \nCurrent Status is COMPLETED");
      return false;
    }
    if (currStatus == "CANCELED") {
      alert("Application Cannot be UPDATED!! \nCurrent Status is CANCELED");
      return false;
    }
    if (
      currStatus == "DENIEDELG" ||
      currStatus == "DENIEDETYP" ||
      currStatus == "DENIEDOTHR"
    ) {
      alert("Application Cannot be UPDATED!! \nCurrent Status is DENIED");
      return false;
    } */
    if (
      this.state.vo.outBoundInitial.isChange === "N" &&
      this.state.vo.inBoundInitial.isChange === "N" &&
      this.state.vo.outBoundInComplete.isChange === "N" &&
      this.state.vo.inBoundInComplete.isChange === "N" &&
      this.state.vo.inBoundLate.isChange === "N"
    ) {
      alert("There is no Record to update");
      return false;
    }
    if (!this.validator.allValid()) {
      this.validator.showMessages();
      this.forceUpdate();
      return;
    }

    ConfirmBox(this.confirmAddNewSegment, Type.ADD, this.props);
  };

  confirmAddNewSegment = () => {
    let vo = this.state.vo;
    const status = this.props.updateAttestationCall(vo, this.props.data);
    this.setModal(status);
    this.setState({
      vo: {
        ...INITIAL_STATE,
      },
    });
  };
  modalClosed = () => {
    this.setState({ showModal: false });
  };

  setModal = (status) => {
    status
      .then((msg) =>
        this.setState({
          message: msg,
          showModal: true,
        })
      )
      .catch((msg) =>
        this.setState({
          message: msg,
          showModal: true,
        })
      );
  };

  render() {
    const { data } = this.props;
    const { vo } = this.state;
    let outBoundInitialNewRow =
      data.obc1TimerCheck === "true" || data.obc2TimerCheck === "true";
    let inBoundInitialNewRow =
      data.obc1TimerCheck !== "false" ||
      (data.obc1TimerCheck === "false" && data.obc2TimerCheck !== "false");
    let outBoundInitialLength = data.outBoundInitial.length;
    let inBoundInitialLength = data.inBoundInitial.length;
    let cmoVo = true;
    let cmiVo = false;
    if (outBoundInitialLength > 0) {
      cmoVo =
        data.outBoundInitial[outBoundInitialLength - 1].status === "INCOMPLETE";
    }
    if (inBoundInitialLength > 0) {
      cmiVo =
        data.inBoundInitial[inBoundInitialLength - 1].status === "INCOMPLETE";
    }

    return (
      <Paper elevation={0}>
        <Modal
          dialogTitle="LEP"
          message={this.state.message}
          show={this.state.showModal}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        {data ? (
          <React.Fragment>
            <div style={{ width: "100%", textAlign: "right" }}>
              <div style={{ display: "inline-flex" }}>
                <Button
                  variant="contained"
                  color="primary"
                  //className={classes.button}
                  onClick={this.update}
                  disabled={this.props.searchResultsVo.suppLepPlatino === "true"}
                >
                  Update
                </Button>
              </div>
            </div>
            <DataTableAttestCall
              data ={data.outBoundInitial}
              tableType="outBoundInitial"
              header="Outbound Initial Attestation"
              setValue={this.setValue}
              validator={this.validator}
              vo={vo.outBoundInitial?vo.outBoundInitial:{    
                date: "",
                userId:"",
                isChange: "N",
                status: ""
            }
         }
              newRow={
                data.outBoundInitial.length?
                outBoundInitialNewRow &&
                data.outBoundInitial.length < 3 &&
                cmoVo:true
              }
            />
            <DataTableAttestCall
              data={inBoundInitialNewRow ? data.inBoundInitial : []}
              tableType="inBoundInitial"
              header="Inbound Initial Attestation"
              setValue={this.setValue}
              validator={this.validator}
              vo={vo.inBoundInitial?vo.inBoundInitial:{date: "",
              userId:"",
              isChange: "N",
              status: ""
            }}
              newRow={
                data.inBoundInitial.length?
                (inBoundInitialNewRow &&
                  data.inBoundInitial.length < 2 &&
                  cmiVo) ||
                (data.obc1TimerCheck === "true" &&
                  data.inBoundInitial.length === 0)
                  :true
              }
            />
            {data.le21TimerCheck === "true" ||
            data.le21TimerCheck === "closed" ? (
              <DataTableAttestCall
                data={data.outBoundInComplete}
                tableType="outBoundInComplete"
                header="Outbound Incomplete Attestation"
                setValue={this.setValue}
                validator={this.validator}
                vo={vo.outBoundInComplete}
                newRow={
                  data.le21TimerCheck === "true" &&
                  data.outBoundInComplete.length < 3
                }
              />
            ) : null}
            {data.le21TimerCheck === "true" ||
            data.le21TimerCheck === "closed" ? (
              <DataTableAttestCall
                data={data.inBoundInComplete}
                tableType="inBoundInComplete"
                header="Inbound Incomplete Attestation"
                vo={vo.inBoundInComplete}
                setValue={this.setValue}
                validator={this.validator}
                newRow={
                  data.le21TimerCheck === "true" &&
                  data.inBoundInComplete.length < 2
                }
              />
            ) : null}
            {data.obc3TimerCheck === "true" ||
            data.obc3TimerCheck === "closed" ? (
              <DataTableAttestCall
                data={data.inBoundLate}
                tableType="inBoundLate"
                header="Inbound Late Attestation"
                vo={vo.inBoundLate}
                setValue={this.setValue}
                validator={this.validator}
                newRow={
                  data.obc3TimerCheck === "true" && data.inBoundLate.length < 2
                }
              />
            ) : null}
          </React.Fragment>
        ) : null}
      </Paper>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    data: state.memberSearch.lepData.attestCallMasterVO,
    searchResultsVo: state.memberSearch.searchResultsVo,
  };
};
const mapDispatchToProps = {
  updateAttestationCall,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(AttestationCalls));
