import "../../../App.css";

import * as DateUtil from "../../../utils/DatePicker";
import * as Type from "../../../constants/ConfirmType";

import React, { Component } from "react";
import AutoComplete1 from "../../UI/Select";
import {
  deleteLepData,
  showActiveLepData,
  showAllLepData,
  updateLepData,
} from "../../../redux/actions/MemberActions";

import CheckBoxIcon from "@material-ui/icons/CheckBox";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import Checkbox from "@material-ui/core/Checkbox";
import ConfirmBox from "../../../utils/PopUp";
import DataTable from "../../Home/DataTable";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import HistoryData from "../../UI/MemberHistory";
import InputField from "../../UI/InputField";
import MemberButtonPanel from "../../UI/MemberButtonPanel";
import Modal from "../../UI/Modal/Modal";
import Paper from "@material-ui/core/Paper";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../../assets/styles/Theme";
import { connect } from "react-redux";
import { customValidations } from "../../../utils/CustomValidations";
import { LEP_TABLE_HEADER as header } from "../../../constants/Headers/MemberHeaders";
import { withStyles } from "@material-ui/core/styles";
import { handleDateChange } from "../../../utils/DateFormatter";
import isEmpty from "lodash/isEmpty";
const INITIAL_STATE = {
  attestationRecChannel: "",
  attestationRecDate: "",
  attestLock: "",
  attestStatus: "",
  attstLockInd: "",
  birthDate: "",
  caseFileDueDate: "",
  caseFileRecDate: "",
  createTime: "",
  createUserId: "",
  creditableCoverageFlag: "",
  customerId: "",
  decisionRecDate: "",
  decisionType: "",
  editOverrideInd: "",
  effEndDate: "",
  effStartDate: "",
  enrollEffStartDate: "",
  firstName: "",
  hicn: "",
  hicNBRVal: "",
  incompAttestLetRecDate: "",
  lastUpdtTime: "",
  lastUpdtUserId: "",
  lepAmt: "0.00",
  numUncocTransReason: "",
  lepWaivedAmt: "0.00",
  maOnly: "",
  maValue: "",
  mbi: "",
  memberId: "",
  message: "",
  nbrUncovMonths: "0",
  notifiedMemberAppeal: "",
  nunCMOList: "",
  // nunCmoNbrUnCovMths: "",
  overrideInd: "",
  partDList: "",
  pbpId: "",
  planDesignation: "",
  planId: "",
  rdsList: "",
  tempEnrollEffStartDate: "",
  transactionDueDate: "",
  trg73Ind: "",
  uncovStDate: "",
  type: "",
  effStartDateFrmt: "",
  effEndDateFrmt: "99/99/9999",
  showAll: "",
};

class LEPData extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedVo: INITIAL_STATE,
      modified: false,
      isNewSegment: false,
      //showAllActive: true,
      editable: false,
      selectedIndex: 0,
      showModal: false,
      message: "",
      data: [],
      searchCount: 0,
      rowsPerPage: 10,
      func1: this.showAll.bind(this),
      showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
    };

    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
        date_format2: customValidations.date_format99,
        first_day_of_month: customValidations.first_day_of_month,
        last_day_of_month: customValidations.last_day_of_month99,
        after_start_date: customValidations.c_after_or_equal_99,
      },
    });
  }
  static getDerivedStateFromProps(nextProps, prevState) {
    const lepData = nextProps.lepData;

    const data = !isEmpty(lepData) ? lepData.eemMbrLepInfoVOs : [];

    if (
      (!isEmpty(data) && data !== prevState.data) ||
      nextProps.searchCount !== prevState.searchCount ||
      nextProps.index !== prevState.index
    ) {
      return {
        data: data,
        selectedVo: data[0],
        editable: false,
        selectedIndex: 0,
        searchCount: nextProps.searchCount,
        // model:prevState.func1(true)
      };
    }

    if (
      nextProps.showAllActiveInd.showAllActiveInd !== prevState.showAllActiveInd
    ) {
      if (nextProps.showAllActiveInd.showAllActiveInd === false) {
        return {
          model: prevState.func1(true),
        };
      } else if (nextProps.showAllActiveInd.showAllActiveInd === true) {
        return {
          model: prevState.func1(false),
        };
      }
    }
  }
  componentDidMount() {
    const { loginProfile } = this.props;
    const TC73TRIG = loginProfile.filter((data) => data.label === "TC73TRIG");
    if (TC73TRIG[0].value === "Y") {
      this.setValue("trigger73Ind", true);
    }
    if (this.props.showAllActiveInd.showAllActiveInd === false) {
      this.showAll(true);
    } else if (this.props.showAllActiveInd.showAllActiveInd === true) {
      this.showAll(false);
    }
  }

  selectRow = async (index, page) => {
    await this.setState({
      selectedIndex: index,
      selectedVo: this.state.data[index],
      editable: false, // readOnly
      isNewSegment: false, //Not a new SEgment
      modified: false,
      //selectedIndex: index,
      page: page,
    });
  };

  handleStartDate = (event) => {
    const fieldId = "#" + event.target.name;
    DateUtil.getStartDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        this.setValue(e.target.name, e.target.value);
      });
  };

  handleDates = (event) => {
    const fieldId = "#" + event.target.name;
    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        this.setValue(e.target.name, e.target.value);
      });
  };

  handleChange = (event) => {
    const name = event.target.name;
    const value = event.target.value;
    this.setValue(name, value);
  };
  handleChangeSearchSelectAuto = (data, name) => {
    const value = data.value;
    this.setValue(name, value);
  };
  handleDatesChange = (event) => {
    const name = event.target.name;
    let value = event.target.value;
    // value = value.replace(/[^0-9]/g, "").trim();
    // if (value.length === 8) {
    //   value = value.replace(/^(\d{2})/, "$1/");
    //   value = value.replace(/\/(\d{2})/, "/$1/");
    //   value = value.replace(/(\d)\/(\d{4}).*/, "$1/$2");
    // }
    // this.setValue(name, value);
    this.setState((prevState) => ({
      selectedVo: {
        ...prevState.selectedVo,
        [name]: handleDateChange(value),
      },
      modified: true,
    }));
  };
  handleCheckBox = (event) => {
    const name = event.target.name;
    const value = event.target.checked ? "Y" : "N";
    this.setValue(name, value);
  };

  handleChangePage = (index) => {
    const data = this.props.lepData.eemMbrLepInfoVOs;
    this.setState({
      selectedIndex: index,
      selectedVo: data[index],
      editable: false, // readOnly
      isNewSegment: false, //Not a new SEgment
      modified: false,
      // page: this.state.page,
    });
  };

  handleNumberChange = (event) => {
    const name = event.target.name;
    let value = event.target.value.replace(/[^-\d.]/g, "").trim();
    if (name === "lepAmt" || name === "lepWaivedAmt") {
      if (event.target.value.split(".").length - 1 <= 1) {
        this.setValue(name, value);
      }
      return;
    }
    this.setValue(name, value);
  };

  setValue = (name, value) => {
    this.setState((prevState) => ({
      selectedVo: {
        ...prevState.selectedVo,
        [name]: value,
      },
    }));
    if (name !== "trg73Ind") {
      this.setState({
        modified: true,
      });
    }
  };

  createNewSegment = () => {
    this.validator.hideMessages();
    this.setState({
      editable: true,
      isNewSegment: true,

      selectedVo: { ...INITIAL_STATE },
    });
  };

  modelSegment = () => {
    if (this.state.selectedVo.overrideInd === "Y") {
      let msg = "This Record is not active ";
      this.setState({ message: msg, showModal: true });
    } else {
      this.setState({
        editable: true, // Editable
        isNewSegment: false, // Not a new Segment
      });
    }
  };

  reset = () => {
    this.setState({
      editable: true,
      isNewSegment: true,
      selectedVo: {
        ...INITIAL_STATE,
      },
    });
  };

  update = (event) => {
    event.preventDefault();
    if (!this.validator.allValid()) {
      this.validator.showMessages();
      this.forceUpdate();
      return;
    }
    ConfirmBox(this.confirmUpdate, Type.UPDATE, this.props);
  };

  confirmUpdate = async () => {
    const { selectedVo, selectedIndex } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(selectedVo.showAll = val),
    });

    const data = this.props.lepData.eemMbrLepInfoVOs;
    const selectedData = data[selectedIndex];
    let equal = true;
    if (selectedData && selectedData.length > 0) {
      Object.keys(selectedData).forEach((item, i) => {
        if (selectedData[item] !== selectedVo[item] && item !== "trg73Ind")
          equal = false;
      });
      if (equal) {
        this.setState({
          message: "NO FIELDS UPDATED",
          showModal: true,
        });
        return;
      }
    }

    const status = await this.props.updateLepData({
      ...selectedVo,
      memberId: this.props.memberId,
    });
    //this.setModal(status);
    if (status) {
      this.setState({
        showModal: true,
        message: status,
      });
    }
    const index = this.state.selectedIndex ? this.state.selectedIndex : 0;

    await this.setState(() => ({
      selectedVo: {
        ...this.state.data[index],
      },
      editable: false, // readOnly
      isNewSegment: false, //Not a new SEgment
      modified: false,
    }));
    this.validator.hideMessages();
  };

  delete = (event) => {
    event.preventDefault();

    if (this.state.selectedVo.overrideInd === "Y") {
      let msg = "This Record is not active ";
      this.setState({ message: msg, showModal: true });
    } else {
      ConfirmBox(this.confirmDelete, Type.DELETE, this.props);
    }
  };

  confirmDelete = async () => {
    const data = this.props.lepData.eemMbrLepInfoVOs;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";
    data.showAll = val;

    const status = await this.props.deleteLepData(
      data,
      this.state.selectedIndex
    );
    // this.setModal(status);
    if (status) {
      this.setState({
        showModal: true,
        message: status,
        page: 0,
        selectedIndex: 0,
      });
    }
  };

  goBack = () => {
    const data = this.props.lepData.eemMbrLepInfoVOs;
    this.setState({
      isNewSegment: false,
      editable: false,
      modified: false,
      selectedVo:
        this.state.selectedIndex > 0
          ? data[this.state.selectedIndex]
          : INITIAL_STATE,
    });
  };

  showAll = async (flag) => {
    const { lepData } = this.props;
    const data = !isEmpty(lepData) ? lepData.eemMbrLepInfoVOs : [];
    if (flag) {
      this.props.showAllLepData(this.props.memberId);
    } else {
      let list = await data.filter((ob) => ob.overrideInd === "N");
      await this.props.showActiveLepData(list);
    }
    this.setState(() => ({
      showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
      isNewSegment: false,
    }));
  };

  modalClosed = () => {
    this.setState({ showModal: false });
  };

  setModal = (status) => {
    status
      .then((msg) =>
        this.setState({
          message: msg,
          showModal: true,
        })
      )
      .catch((msg) =>
        this.setState({
          message: msg,
          showModal: true,
        })
      );
  };
  handleChangeRowsPerPage = async (rowsPerPage) => {
    await this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };
  render() {
    const { classes, lepData } = this.props;
    const { selectedVo } = this.state;
    const data = !isEmpty(lepData) ? lepData.eemMbrLepInfoVOs : [];
    let ButtonPanel = (
      <MemberButtonPanel
        isNewSegment={this.state.isNewSegment}
        showAll={this.showAll}
        toggleLabel={this.state.showAllActive}
        newSegment={this.createNewSegment}
        modelSegment={this.modelSegment}
        modified={this.state.modified}
        editable={this.state.editable}
        delete={this.delete}
        update={this.update}
        disable={data.length === 0}
        supLep={this.props.searchResultsVo.suppLepPlatino === "true"}
      />
    );
    

    return (
      <React.Fragment>
        <Modal
          dialogTitle="LEP"
          message={this.state.message}
          show={this.state.showModal}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Paper elevation={0} className={classes.card}>
          <React.Fragment>
            <DataTable
              data={data}
              header={header}
              rowsPerPage={this.state.rowsPerPage}
              sortable={true}
              clicked={this.selectRow}
              index={this.state.selectedIndex}
              rowsPerPageOptions={[10, 15, 20]}
              handleChangeRowsPerPage={this.handleChangeRowsPerPage}
              handleChangePage={this.handleChangePage}
              dateColumn={["effStartDateFrmt", "effEndDateFrmt"]}
              subtab
            />
            <div className={classes.buttonContainer}> {ButtonPanel}</div>

            <form autoComplete="off">
              {!isEmpty(data) || this.state.isNewSegment ? (
                <div class="panel-body margin-top1">
                  <div className={classes.container}>
                    <div>
                      <InputField
                        name="effStartDateFrmt"
                        placeholder="MM/DD/YYYY"
                        onClick={this.handleStartDate}
                        label="Start Date"
                        required
                        value={selectedVo.effStartDateFrmt}
                        maxLength="10"
                        onChange={this.handleDatesChange}
                        disabled={!this.state.editable}
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "StartDate",
                          selectedVo.effStartDateFrmt,
                          "required|date_format|first_day_of_month"
                        )}
                      </div>
                    </div>

                    <div>
                      <InputField
                        name="effEndDateFrmt"
                        placeholder="MM/DD/YYYY"
                        onClick={this.handleDates}
                        required
                        label="End Date"
                        maxLength="10"
                        value={selectedVo.effEndDateFrmt}
                        onChange={this.handleDatesChange}
                        disabled={!this.state.editable}
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "EndDate",
                          selectedVo.effEndDateFrmt,
                          [
                            "required",
                            "date_format2",
                            "last_day_of_month",
                            {
                              after_start_date: selectedVo.effStartDateFrmt,
                            },
                          ]
                        )}
                      </div>
                    </div>

                    <div>
                      <InputField
                        name="overrideInd"
                        label="Override"
                        value={selectedVo.overrideInd}
                        //onChange={this.handleChange}
                        disabled={true}
                      />
                      <div className={classes.validationMessage}></div>
                    </div>

                    <div>
                      <InputField
                        name="attstLockInd"
                        label="Attsn_Lock_Ind"
                        value={selectedVo.attstLockInd}
                        disabled={true}
                      />
                      <div className={classes.validationMessage}></div>
                    </div>
                    <div>
                      {this.props.dropdowns ? (
                        <AutoComplete1
                          handleChange={this.handleChangeSearchSelectAuto}
                          label="Type"
                          options={this.props.dropdowns.validLEPType}
                          width="170px"
                          fontSize="0.718em"
                          defaultValue={this.props.dropdowns.validLEPType[0]}
                          // {letterVo.sourceTypeDesc?LETTER_REQUESTSOURCE.filter(data => data.value === letterVo.sourceTypeDesc):LETTER_REQUESTSOURCE[0]}
                          value={
                            this.props.dropdowns.validLEPType.filter(
                              (option) =>
                                option.value === selectedVo.numUncocTransReason
                            )[0]
                          }
                          name="numUncocTransReason"
                          disabled={!this.state.editable}
                        />
                      ) : (
                          ""
                        )}
                      <div className={classes.validationMessageSelect}>
                        {this.validator.message(
                          "Type",
                          selectedVo.numUncocTransReason,
                          "required"
                        )}
                      </div>
                    </div>

                    <div>
                      <InputField
                        name="nbrUncovMonths"
                        label="Uncovered Months"
                        required
                        value={selectedVo.nbrUncovMonths===0?INITIAL_STATE.nbrUncovMonths:selectedVo.nbrUncovMonths}
                        onChange={this.handleNumberChange}
                        maxLength="3"
                        disabled={!this.state.editable}
                      />
                     {/* <div className={classes.validationMessageSelect}>
                        {this.validator.message(
                          "Uncovered Months",
                          selectedVo.nbrUncovMonths,
                          "required"
                        )}
                        </div>*/}
                    </div>

                    <div>
                      <InputField
                        name="lepAmt"
                        label="LEP Amt"
                        required
                        value={selectedVo.lepAmt}
                        onChange={this.handleNumberChange}
                        maxLength="11"
                        disabled={!this.state.editable}
                      />
                      <div className={classes.validationMessageSelect}>
                        {this.validator.message(
                          "Lep Amt",
                          selectedVo.lepAmt,
                          "required"
                        )}
                      </div>
                    </div>

                    <div>
                      <InputField
                        name="lepWaivedAmt"
                        label="LEP Waived Amt"
                        required
                        value={selectedVo.lepWaivedAmt}
                        maxLength="11"
                        onChange={this.handleNumberChange}
                        disabled={!this.state.editable}
                      />
                      <div className={classes.validationMessageSelect}>
                        {this.validator.message(
                          "Lep Waived Amt",
                          selectedVo.lepWaivedAmt,
                          "required"
                        )}
                      </div>
                    </div>

                    <div className={classes.textField1}>
                      <FormControlLabel
                        control={
                          <Checkbox
                            disabled={!this.state.editable}
                            name="editOverrideInd"
                            style={{ width: 36, height: 36 }}
                            color="primary"
                            icon={
                              <CheckBoxOutlineBlankIcon
                                className={classes.checkBoxStyle}
                              />
                            }
                            checkedIcon={
                              <CheckBoxIcon
                                className={classes.checkboxmember}
                              />
                            }
                            checked={
                              selectedVo.editOverrideInd === "Y" ? true : false
                            }
                            onChange={this.handleCheckBox}
                          />
                        }
                        id="editOverride"
                        label="Bypass Edits"
                        classes={{ label: classes.formLabel }}
                      />
                    </div>
                    <div className={classes.textField1}>
                      <FormControlLabel
                        control={
                          <Checkbox
                            disabled={!this.state.editable}
                            name="trg73Ind"
                            style={{ width: 36, height: 36 }}
                            color="primary"
                            icon={
                              <CheckBoxOutlineBlankIcon
                                className={classes.checkBoxStyle}
                              />
                            }
                            checkedIcon={
                              <CheckBoxIcon
                                className={classes.checkboxmember}
                              />
                            }
                            checked={selectedVo.trg73Ind === "Y" ? true : false}
                            onChange={this.handleCheckBox}
                          />
                        }
                        id="editOverride"
                        label="Trigger TXN 73"
                        classes={{ label: classes.formLabel }}
                      />
                    </div>

                    <div>
                      <InputField
                        name="firstName"
                        label="Name"
                        value={selectedVo.firstName}
                        disabled
                      />
                      <div className={classes.validationMessage}></div>
                    </div>

                    <div>
                      <InputField
                        name="birthDate"
                        onClick={this.handleDates}
                        label="65th BirthDay"
                        value={selectedVo.mbr65BirthDt}
                        disabled
                      />
                      <div className={classes.validationMessage}></div>
                    </div>

                    <div>
                      <InputField
                        name="mbi"
                        label="Medicare Id"
                        value={selectedVo.mbi}
                        disabled
                      />
                      <div className={classes.validationMessage}></div>
                    </div>

                    <div>
                      <InputField
                        name="planId"
                        label="Plan"
                        value={selectedVo.planId}
                        disabled
                      />
                      <div className={classes.validationMessage}></div>
                    </div>

                    <div>
                      <InputField
                        name="pbpId"
                        label="PBP"
                        value={selectedVo.pbpId}
                        maxLength={3}
                        disabled
                      />
                      <div className={classes.validationMessage}></div>
                    </div>
                    <div>
                      <InputField
                        name="maOnly"
                        label="MA Only"
                        value={selectedVo.maValue}
                        disabled
                      />
                      <div className={classes.validationMessage}></div>
                    </div>
                  </div>{" "}
                  <HistoryData
                    createUserId={selectedVo.createUserId}
                    createTime={selectedVo.createTime}
                    lastUpdtTime={selectedVo.lastUpdtTime}
                    lastUpdtUserId={selectedVo.lastUpdtUserId}
                    isNewSegment={this.state.isNewSegment}
                    reset={this.reset}
                    addSegment={this.update}
                    back={this.goBack}
                    disable={data.length === 0}
                  />
                </div>
              ) : null}
            </form>
          </React.Fragment>
        </Paper>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    searchCount: state.memberSearch.searchCount,
    lepData: state.memberSearch.lepData,
    memberId: state.memberSearch.mbrSearchCriteria.memberId,
    dropdowns: state.membercache,
    showAllActiveInd: state.memberSearch.showAllActiveIndi,
    loginProfile: state.loginData.profiles,
    searchResultsVo: state.memberSearch.searchResultsVo,
  };
};
const mapDispatchToProps = {
  deleteLepData,
  updateLepData,
  showAllLepData,
  showActiveLepData,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(LEPData));
