import * as DateUtil from "../../../utils/DatePicker";
import * as Type from "../../../constants/ConfirmType";

import React, { Component } from "react";
import {
  addUncoveredDetail,
  deleteUncoveredDetail,
  showActiveUncovData,
  showAllUncoveredDetail,
} from "../../../redux/actions/MemberActions";

import Badge from "@material-ui/core/Badge";
import Button from "@material-ui/core/Button";
import ConfirmBox from "../../../utils/PopUp";
import DataTable from "../../Home/DataTable";
import HistoryData from "../../UI/MemberHistory";
import InputField from "../../UI/InputField";
import Modal from "../../UI/Modal/Modal";
import Paper from "@material-ui/core/Paper";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../../assets/styles/Theme";
import Typography from "@material-ui/core/Typography";
import { connect } from "react-redux";
import { customValidations } from "../../../utils/CustomValidations";
import { UNCOVERED_TABLE_HEADER as header } from "../../../constants/Headers/MemberHeaders";
import { withStyles } from "@material-ui/core/styles";
import { handleDateChange } from "../../../utils/DateFormatter";
import isEmpty from "lodash/isEmpty";
class UncoveredData extends Component {
  constructor(props) {
    super(props);
    this.state = {
      addVo: {
        uncovMthStDtFrmt: "",
        uncovMthEndDtFrmt: "",
      },
      selectedRow: 0,
      showAll: false,
      showModal: false,
      message: "",
    };

    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
        first_day_of_month: customValidations.first_day_of_month,
        last_day_of_month: customValidations.last_day_of_month,
        after_start_date: customValidations.c_after,
        date_conflict: customValidations.date_conflict_uncov,
      },
    });
  }

  handlechange = (event) => {
    let value = event.target.value;
    let name = event.target.name;
    // value = value.replace(/[^0-9]/g, "").trim();
    // if (value.length === 8) {
    //   value = value.replace(/^(\d{2})/, "$1/");
    //   value = value.replace(/\/(\d{2})/, "/$1/");
    //   value = value.replace(/(\d)\/(\d{4}).*/, "$1/$2");
    // }
    // this.setValue(name, value);
    this.setState((prevState) => ({
      addVo: {
        ...prevState.addVo,
        [name]: handleDateChange(value),
      },
      modified: true,
    }));
  };

  handleStartDate = (event) => {
    var self = this;
    const fieldId = "#" + event.target.name;
    DateUtil.getStartDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        self.setValue(e.target.name, e.target.value);
      });
  };

  handleLastDate = (event) => {
    var self = this;
    const fieldId = "#" + event.target.name;
    DateUtil.getLastDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        self.setValue(e.target.name, e.target.value);
      });
  };

  selectRow = (index) => {
    this.setState({
      selectedRow: index,
    });
  };

  setValue = (name, value) => {
    this.setState((prevState) => ({
      addVo: {
        ...prevState.addVo,
        [name]: value,
      },
    }));
  };

  toggleShowAll = async () => {
    const { data, memberId } = this.props;
    await this.setState((prevState) => ({
      showAll: !prevState.showAll,
    }));
    if (this.state.showAll) {
      this.props.showAllUncoveredDetail(memberId);
    } else {
      this.props.showActiveUncovData(
        !isEmpty(data) ? data.potentialUnCovMthsList : []
      );
    }
  };

  deleteUncoveredDetail = () => {
    ConfirmBox(this.confirmDelete, Type.DELETE, this.props);
  };

  confirmDelete = () => {
    const selectedRow = this.state.selectedRow;
    const status = this.props.deleteUncoveredDetail(
      this.props.data.potentialUnCovMthsList[selectedRow],
      selectedRow,
      this.props.data.potentialUnCovMthsList
    );
    this.setModal(status);
    if (
      this.props.data.potentialUnCovMthsList &&
      selectedRow >= this.props.data.potentialUnCovMthsList.length
    ) {
      this.setState((prevState) => ({
        selectedRow: prevState.selectedRow - 1,
      }));
    }
  };

  addUncoveredDetail = () => {
    if (!this.validator.allValid()) {
      this.validator.showMessages();
      this.forceUpdate();
      return;
    }
    ConfirmBox(this.confirmInsert, Type.ADD, this.props);
  };

  confirmInsert = async () => {
    await this.props
      .addUncoveredDetail(
        this.props.memberId,
        this.props.lepEffDate,
        this.state.addVo,
        this.props.data.potentialUnCovMthsList
      )
      .then((msg) =>
        this.setState({
          message: msg,
          showModal: true,
        })
      )

      .catch((msg) =>
        this.setState({
          message: msg,
          showModal: true,
        })
      );
    this.setState({
      addVo: {
        uncovMthStDtFrmt: "",
        uncovMthEndDtFrmt: "",
      },
    });

    this.validator.hideMessages();
  };
  modalClosed = () => {
    this.setState({ showModal: false });
  };

  setModal = (status) => {
    status
      .then((msg) =>
        this.setState({
          message: msg,
          showModal: true,
        })
      )

      .catch((msg) =>
        this.setState({
          message: msg,
          showModal: true,
        })
      );

    this.validator.hideMessages();
  };
  render() {
    const { classes } = this.props;
    const data = !isEmpty(this.props.data) ? this.props.data : [];
    const { selectedRow, addVo, showAll } = this.state;
    let potentialUnCovMthsList = 0; //data.potentialUnCovMthsList[0].plepMonths
    if (!isEmpty(this.props.data)) {
      data.potentialUnCovMthsList.map((data) => {
        potentialUnCovMthsList =
          parseInt(data.plepMonths) + parseInt(potentialUnCovMthsList);
        return null;
      });
    }

    let buttonContainer = (
      <div className={classes.buttonContainer1}>
        <Button
          variant="contained"
          color="primary"
          onClick={this.toggleShowAll}
          className={classes.button}
        >
          {showAll ? "Show Active" : "Show All"}
        </Button>

        <Button
          variant="contained"
          color="primary"
          onClick={this.deleteUncoveredDetail}
          className={classes.button}
          disabled={
            this.state.editable ||
            this.props.searchResultsVo.suppLepPlatino === "true"
          }
        >
          Delete
        </Button>

        <Button
          variant="contained"
          color="primary"
          onClick={this.addUncoveredDetail}
          className={classes.button}
          disabled={
            this.state.editable ||
            this.props.searchResultsVo.suppLepPlatino === "true"
          }
        >
          Add
        </Button>
      </div>
    );

    return (
      <Paper elevation={0} className={classes.card}>
        <Modal
          dialogTitle="LEP"
          message={this.state.message}
          show={this.state.showModal}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>

        <React.Fragment>
          <div style={{ width: "100%", textAlign: "center" }}>
            <div style={{ display: "inline-block" }}>
              <Typography
                variant="h6"
                id="tableTitle"
                className={classes.attestation1}
              >
                Total Uncovered Months -
                <Badge
                  showZero
                  className={classes.badgeUncovered}
                  badgeContent={potentialUnCovMthsList}
                  color="primary"
                  max={99999}
                ></Badge>
              </Typography>
            </div>

            <DataTable
              data={
                !isEmpty(data.potentialUnCovMthsList)
                  ? data.potentialUnCovMthsList
                  : []
              }
              header={header}
              rowsPerPage={5}
              clicked={this.selectRow}
              selectedRow={selectedRow}
              index={this.state.selectedRow}
              width="75%"
              sortable={true}
              rowsPerPageOptions={[5, 10, 15, 20]}
              subtab
            />
          </div>
          <div className={classes.buttonContainer}> {buttonContainer}</div>
          <div style={{ width: "100%", textAlign: "center" }}>
            <div style={{ display: "inline-flex" }}>
              <div>
                <InputField
                  name="uncovMthStDtFrmt"
                  placeholder="MM/DD/YYYY"
                  label="Uncovered Months Start Date"
                  value={addVo.uncovMthStDtFrmt}
                  onClick={this.handleStartDate}
                  maxLength={10}
                  onChange={this.handlechange}
                />

                <div className={classes.validationMessage}>
                  {this.validator.message("StartDate", addVo.uncovMthStDtFrmt, [
                    "required",
                    "date_format",
                    "first_day_of_month",
                    {
                      date_conflict: [
                        addVo.uncovMthEndDtFrmt,
                        !isEmpty(data.potentialUnCovMthsList)
                          ? data.potentialUnCovMthsList
                          : "",
                      ],
                    },
                  ])}
                </div>
              </div>
              <div>
                <InputField
                  name="uncovMthEndDtFrmt"
                  placeholder="MM/DD/YYYY"
                  label="Uncovered Months End Date"
                  value={addVo.uncovMthEndDtFrmt}
                  onClick={this.handleLastDate}
                  maxLength={10}
                  onChange={this.handlechange}
                />

                <div className={classes.validationMessage}>
                  {this.validator.message("EndDate", addVo.uncovMthEndDtFrmt, [
                    "required",
                    "date_format",
                    "last_day_of_month",
                    { after_start_date: addVo.uncovMthStDtFrmt },
                  ])}
                </div>
              </div>
            </div>
          </div>

          {!isEmpty(data.potentialUnCovMthsList) ? (
            <div>
              <HistoryData
                createUserId={
                  data.potentialUnCovMthsList[selectedRow].createUserId
                }
                createTime={data.potentialUnCovMthsList[selectedRow].createTime}
                lastUpdtTime={
                  data.potentialUnCovMthsList[selectedRow].lastUpdtTime
                }
                lastUpdtUserId={
                  data.potentialUnCovMthsList[selectedRow].lastUpdtUserId
                }
              />
            </div>
          ) : null}
        </React.Fragment>
      </Paper>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    data: state.memberSearch.lepData,
    memberId: state.memberSearch.mbrSearchCriteria.memberId,
    searchResultsVo: state.memberSearch.searchResultsVo,
    lepEffDate:
      state.memberSearch.searchResultsVo.mbrEnrollmentList[0].effStartDateFrmt,
  };
};

const mapDispatchToProps = {
  addUncoveredDetail,
  deleteUncoveredDetail,
  showAllUncoveredDetail,
  showActiveUncovData,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(UncoveredData));
