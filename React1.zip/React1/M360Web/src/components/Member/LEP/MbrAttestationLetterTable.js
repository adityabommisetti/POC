import React, { Component } from "react";
import {
  setMbrLepValue,
  updateAttestationLetter,
} from "../../actions/MemberActions";
import * as DateUtil from "../../../utils/DatePicker";

import $ from "jquery";
import Button from "@material-ui/core/Button";
import Modal from "../../UI/Modal/Modal";
import SimpleReactValidator from "simple-react-validator";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import { connect } from "react-redux";
import moment from "moment";
import { styles } from "../../../assets/styles/DataTableStyle";
import { withStyles } from "@material-ui/core/styles";

class DataTable extends Component {
  constructor(props) {
    super(props);

    this.state = {
      modified: false,
      showModal: false,
      message: "",
    };

    this.validator = new SimpleReactValidator({
      validators: {
        date_format: {
          message: "Invalid date. Please format as MM/DD/YYYY",
          rule: (val, params, validator) => {
            return moment(val, "MM/DD/YYYY", true).isValid();
          },
        },
      },
    });
  }

  handlechange = (event) => {
    let value = event.target.value;
    let name = event.target.name;
    this.setValue(name, value);
  };
  handleDate = (event) => {
    var self = this;
    const fieldId = "#" + event.target.name;
    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        self.setValue(e.target.name, e.target.value);
      });
  };

  handleDateChange = (event) => {
    let value = event.target.value;
    let name = event.target.name;
    if (value.length === 8) {
      value = value.replace(/[^0-9]/g, "").trim();
      value = value.replace(/^(\d{2})/, "$1/");
      value = value.replace(/\/(\d{2})/, "/$1/");
      value = value.replace(/(\d)\/(\d{4}).*/, "$1/$2");
    }
    this.setValue(name, value);
  };

  setValue = (name, value) => {
    this.setState({
      modified: true,
    });
    this.props.setMbrLepValue(name, value, "lepAttestInfoVO");
  };
  modalClosed = () => {
    this.setState({ showModal: false });
  };

  setModal = (status) => {
    status
      .then((msg) =>
        this.setState({
          message: msg,
          showModal: true,
        })
      )
      .catch((msg) =>
        this.setState({
          message: msg,
          showModal: true,
        })
      );
  };
  update = () => {
    if (!this.validator.allValid()) {
      this.validator.showMessages();
      this.forceUpdate();
      return;
    }
    const status = this.props.updateAttestationLetter(this.props.data);
    this.setModal(status);
  };
  render() {
    const { classes, data } = this.props;
    return (
      <React.Fragment>
        <Modal
          dialogTitle="LEP"
          message={this.state.message}
          show={this.state.showModal}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <div style={{ width: "100%", textAlign: "center" }}>
          <div
            className={classes.tableWrapper}
            style={{ width: this.props.width ? this.props.width : "100%" }}
          >
            <Table className={classes.tableModified}>
              <TableHead className={classes.thead}>
                <TableRow className={classes.headRow}>
                  <TableCell
                    className={classes.headerCell}
                    colSpan={4}
                    align="center"
                    style={{ borderRight: "1px solid white" }}
                  >
                    Attestation Letter Status
                  </TableCell>
                  <TableCell
                    className={classes.headerCell}
                    colSpan={2}
                    align="center"
                  >
                    Incomplete Attestation Letter Status
                  </TableCell>
                </TableRow>
                <TableRow className={classes.headRow}>
                  <TableCell className={classes.headerCell} align="center">
                    Attestation Letter Mail Date
                  </TableCell>
                  <TableCell className={classes.headerCell} align="center">
                    Attestation Letter Expiration Date
                  </TableCell>
                  <TableCell className={classes.headerCell} align="center">
                    Attestation Letter PDF
                  </TableCell>
                  <TableCell className={classes.headerCell} align="center">
                    Attestation Status
                  </TableCell>
                  <TableCell className={classes.headerCell} align="center">
                    Received Date
                  </TableCell>
                  <TableCell className={classes.headerCell} align="center">
                    Expiration Date
                  </TableCell>
                </TableRow>
              </TableHead>

              <TableBody className={classes.tbody}>
                {data ? (
                  <TableRow className={classes.row} align="center">
                    <TableCell className={classes.tableCell}>
                      {data.attestLetMailDateFrmt}
                    </TableCell>
                    <TableCell className={classes.tableCell} align="center">
                      {data.attestLetExpDateFrmt}
                    </TableCell>
                    <TableCell className={classes.tableCell} align="center">
                      {data.letterAvailabilityInDB === "Y" ? (
                        <img
                          src={require("../../../assets/images/pdf.png")}
                          alt="pdf"
                          style={{ height: "1.8rem" }}
                        />
                      ) : null}
                    </TableCell>
                    <TableCell
                      className={classes.tableCell}
                      style={{ borderRight: "1px solid white" }}
                      align="center"
                    >
                      <select
                        class="lepSelect"
                        id="lep"
                        name="attestStatus"
                        onChange={this.handlechange}
                        value={data.attestStatus}
                        style={{ display: "inline" }}
                      >
                        <option value="">Select</option>
                        <option value="M">Missing</option>
                        <option value="I">Incomplete</option>
                        <option value="C">Complete</option>
                      </select>
                    </TableCell>
                    <TableCell className={classes.tableCell} align="center">
                      <div>
                        <input
                          name="appIncAttRcDtFrmt"
                          id="appIncAttRcDtFrmt"
                          type="text"
                          class="lepInput"
                          onChange={this.handleDateChange}
                          value={data.appIncAttRcDtFrmt}
                          onClick={this.handleDate}
                          style={{ display: "inline" }}
                          disabled={
                            data.attestStatus === "C" ||
                            data.attestStatus === "M"
                          }
                        />
                        <div className={classes.validationMessage}>
                          {this.validator.message(
                            "ReceivedDate",
                            data.appIncAttRcDtFrmt,
                            "date_format"
                          )}
                          {data.attestStatus === "I"
                            ? this.validator.message(
                                "ReceivedDate",
                                data.appIncAttRcDtFrmt,
                                "required"
                              )
                            : null}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className={classes.tableCell} align="center">
                      {data.appIncAttLetExpDtFrmt}
                    </TableCell>
                  </TableRow>
                ) : (
                  <TableRow className={classes.row}>
                    <TableCell className={classes.tableCell} colSpan={5}>
                      No Data Found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          <div>
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.update}
              disabled={
                !this.state.modified ||
                this.props.searchResultsVo.suppLepPlatino == "true"
              }
            >
              Update
            </Button>
          </div>
        </div>
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    data: state.memberSearch.lepData.lepAttestInfoVO,
    searchResultsVo: state.memberSearch.searchResultsVo,
  };
};
const mapDispatchToProps = {
  setMbrLepValue,
  updateAttestationLetter,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(DataTable));
