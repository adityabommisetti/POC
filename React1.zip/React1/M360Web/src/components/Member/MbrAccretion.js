import React, { Component } from "react";
import { getAccretion } from "../../redux/actions/MemberActions";
import DataTable from "../Home/DataTable";
import InputField from "../UI/InputField";
import Paper from "@material-ui/core/Paper";
import { Styles } from "../../assets/styles/Theme";
import { connect } from "react-redux";
import { ACCRETION_HEADER as header } from "../../constants/Headers/MemberHeaders";
import isEmpty from "lodash/isEmpty";
import { withStyles } from "@material-ui/core/styles";

class Accretion extends Component {
  state = {
    selectedIndex: 0,
    data: null,
    rowsPerPage: 10,
  };

  selectRow = (index) => {
    this.setState(() => ({
      selectedIndex: index,
    }));
  };

  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.mbrSearchCriteria.memberId !== prevState.memberId) {
      if (!isEmpty(nextProps.accretionData)) {
        return {
          data: nextProps.accretionData,
          selectedIndex: 0,
          memberId: nextProps.mbrSearchCriteria.memberId,
        };
      }
      return {
        data: [],
        selectedIndex: 0,
        memberId: nextProps.mbrSearchCriteria.memberId,
      };
    }

    return null;
  }

  async componentDidMount() {
    if (
      isEmpty(this.props.accretionData) &&
      this.props.accretionData !== null
    ) {
      await this.props.getAccretion(
        this.props.mbrSearchCriteria.memberId + "/Y"
      );
    }

    if (!isEmpty(this.props.accretionData)) {
      this.setState({
        data: this.props.accretionData,
      });
    }
  }
  handleChangeRowsPerPage = async (rowsPerPage) => {
    await this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  handleChangePage = (index) => {
    this.setState({ selectedIndex: index });
  };

  render() {
    const { classes } = this.props;
    const { selectedIndex, data } = this.state;

    return (
      <Paper elevation={0} className={classes.card}>
        {data ? (
          <DataTable
            data={data}
            header={header}
            sortable={true}
            rowsPerPageOptions={[10, 15, 20]}
            handleChangeRowsPerPage={this.handleChangeRowsPerPage}
            rowsPerPage={this.state.rowsPerPage}
            clicked={this.selectRow}
            index={selectedIndex}
            handleChangePage={this.handleChangePage}
            subtab
          />
        ) : null}
        {!isEmpty(data) ? (
          <form autoComplete="off">
            <div class="panel-body margin-top1">
              <div className={classes.container}>
                <div>
                  <InputField
                    name="transactionType"
                    label="Transaction Type"
                    value={data[selectedIndex].transactionType}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="effectiveDateFrmt"
                    label="Effective Date"
                    value={data[selectedIndex].effectiveDateFrmt}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="signdateFrmt"
                    label="Signature date"
                    value={data[selectedIndex].signdateFrmt}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="address1"
                    label="Address Line 1"
                    value={data[selectedIndex].address1}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="address2"
                    label="Address Line 2"
                    value={data[selectedIndex].address2}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="city"
                    label="City"
                    value={data[selectedIndex].city}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="state"
                    label="State"
                    value={data[selectedIndex].state}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="Zip5"
                    label="Zip5"
                    value={data[selectedIndex].Zip5}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="Zip4"
                    label="Zip4"
                    value={data[selectedIndex].Zip4}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="planId"
                    label="Plan ID"
                    value={data[selectedIndex].planId}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="pbpId"
                    label="PBP ID"
                    value={data[selectedIndex].pbpId}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="eghpInd"
                    label="EGHP Ind"
                    value={data[selectedIndex].eghpInd}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="primBin"
                    label="Primary Bin"
                    value={data[selectedIndex].primBin}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="primPcn"
                    label="Primary PCN"
                    value={data[selectedIndex].primPcn}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="primaryRxId"
                    label="Primary RxID"
                    value={data[selectedIndex].primRxId}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="secondaryBin"
                    label="Secondary Bin"
                    value={data[selectedIndex].secondaryBin}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="primeRxGrp"
                    label="Primary Rx Group"
                    value={data[selectedIndex].primeRxGrp}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="secPcn"
                    label="Secondary PCN"
                    value={data[selectedIndex].secPcn}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="secRxid"
                    label="Secondary RxID"
                    value={data[selectedIndex].secRxid}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="createUserId"
                    label="Create User ID"
                    value={data[selectedIndex].createUserId}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="birthDateFrmt"
                    label="DOB"
                    value={data[selectedIndex].birthDateFrmt}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="prtCAmt"
                    label="Part C Amount"
                    value={data[selectedIndex].prtCAmt}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="prtDAmt"
                    label="Part D Amount"
                    value={data[selectedIndex].prtDAmt}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="electionType"
                    label="Election Type"
                    value={data[selectedIndex].electionType}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="priorCommercialOvrInd"
                    label="Prior Commercial ovr Ind"
                    value={data[selectedIndex].priorCommercialOvrInd}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="disEnrollReason"
                    label="Disenrollment Reason"
                    value={data[selectedIndex].disEnrollReason}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="uncoveredMonths"
                    label="Total Uncovered Months"
                    value={data[selectedIndex].uncoveredMonths}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="premiumHoldOption"
                    label="Premium With Hold Option"
                    value={data[selectedIndex].premiumHoldOption}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="credCovflag"
                    label="Creditable Coverage Flag"
                    value={data[selectedIndex].credCovflag}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="prtDOutInd"
                    label="Part D Opt Out Ind"
                    value={data[selectedIndex].prtDOutInd}
                    disabled
                  />
                  <div className={classes.validationMessage} />
                </div>
              </div>
            </div>
          </form>
        ) : (
          ""
        )}
      </Paper>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    mbrSearchCriteria: state.memberSearch.mbrSearchCriteria,
    accretionData: state.memberSearch.searchResultsVo.accretionList,
    memberIdCheck: state.memberSearch.memberId,
  };
};
const mapDispatchToProps = { getAccretion };

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(Accretion));
