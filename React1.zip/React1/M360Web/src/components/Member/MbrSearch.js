import * as DateUtil from "../../utils/DatePicker";

import {
  ERROR_HEADER,
  MEMBER_HEADER as header,
} from "../../constants/Headers/MemberHeaders";
import { MEMBER_SNAPSHOT } from "../../constants/staticData/MemberStaticData";
import {
  MemberSearch,
  fetchMemberCacheData,
  memberrowClickSearch,
  resetMemberSearch,
  memberSearchNextPage,
  getShowAll,
  updateShowAllIndi,
  setSelectedTab,
  searchAttributes,
  resetClearsearch
} from "../../redux/actions/MemberActions";
import { setValue } from "../../redux/actions/ApplActions";
import Checkbox from "@material-ui/core/Checkbox";
import DataTable from "../Home/DataTable";
import ExpansionPanel from "../UI/ExpansionPanel";
import InputBase from "@material-ui/core/InputBase";
import InputField from "../UI/InputField";
import InputLabel from "@material-ui/core/InputLabel";
import MemberAppBar from "./MbrAppBar";
import Paper from "@material-ui/core/Paper";
import React from "react";
import { Styles } from "../../assets/styles/Theme";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";
import Datetime from "react-datetime";
import SimpleReactValidator from "simple-react-validator";
import { customValidations } from "../../utils/CustomValidations";
import { handleDateChange } from "../../utils/DateFormatter";
import MbrShowAll from "../UI/MemberShowAll";
const dateChk = {};
//import isEmpty from "lodash/isEmpty";
// const spacing = {
//   marginTop: "10px",
// };
// const INITIAL_STATE = {
//   memberId: "",
//   medicareId: "",
//   firstName: "",
//   supplementalId: "",
//   lastName: "",
//   cmsEffMonth: "",
//   dob: "",
//   showAll: "N",
// };

const Checkbox1 = withStyles((theme) => ({
  root: {
    padding: "5px 0px 5px 0px !important",
  },
}))(Checkbox);
class MbrSearch extends React.PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      searchVo: {
        memberId: this.props.searchAttribute
          ? props.searchAttribute.memberId
          : "",
        medicareId: this.props.searchAttribute
          ? props.searchAttribute.medicareId
          : "",
        firstName: this.props.searchAttribute
          ? props.searchAttribute.firstName
          : "",
        supplementalId: this.props.searchAttribute
          ? props.searchAttribute.supplementalId
          : "",
        lastName: this.props.searchAttribute
          ? props.searchAttribute.lastName
          : "",
        cmsEffMonth: this.props.searchAttribute
          ? props.searchAttribute.cmsEffMonth
          : "",
        dob: "",
        showAll: this.props.showAllActiveIndi === true ? "Y" : "N",
      },
      data: [],
      selectedVo: null,
      search: false,
      expanded: false,
      errorsExpanded: false,
      errorData: [],
      reset: false,
      searchExpand: true,
      collapseSearch: false,
      index: 0,
      tabNameValue: "",
      flag: false,
      selectedRowIndex: 0,
      memeberId: 0,
      errorIndex: 0,
      rowsPerPage: 10,
      pageNo: 0,
      tabSwitch: false,
      showAllData: {},
      showAllActiveInd: true,
      resetFlag: true,
      mbridLit: [],
    };

    this.setDate = this.setDate.bind(this);
    this.fetchMemberDetails = this.fetchMemberDetails.bind(this);
    this.validator = new SimpleReactValidator({
      validators: {
        date_format_MM_YYYY: customValidations.date_format_MM_YYYY,
      },
    });
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.selectedTab) {
      this.setState({ tabNameValue: nextProps.selectedTab });
    }
  }

  UNSAFE_componentWillMount() {
    if (Object.keys(this.props.membercache).length === 0) {
      this.props.fetchMemberCacheData();
    }

    this.setState({
      tabNameValue: this.props.selectedTab,
    });
  }

  componentWillUnmount() {
    // this.setState({ tabNameValue: "demo" });
    this.props.resetMemberSearch({ memberId: this.state.selectedRowIndex });
  }

  componentDidMount() {
    const { loginProfile } = this.props;
    const MBRIDLIT = loginProfile.filter((data) => data.label === "MBRIDLIT");
    this.setState({
      mbridLit: MBRIDLIT[0],
    });
    if (this.props.mbrSearchCriteria.memberId) {
      const selectedMemberId = this.props.selectedMemberId.memberId;
      this.setState({
        index: 0,
        selectedRowIndex: selectedMemberId,
      });
    }
  }

  monthPicker = (selectedDate) => {
    if (selectedDate._d) {
      var date = new Date(selectedDate._d),
        mnth = ("0" + (date.getMonth() + 1)).slice(-2),
        selectedDate1 = [mnth, date.getFullYear()].join("/");
    } else {
      if (selectedDate.length === 6 && !selectedDate.includes("/")) {
        selectedDate1 = selectedDate.replace(/[^0-9]/g, "").trim();
        //selectedDate1 = selectedDate.replace(/^(\d{2})/, "$1/");
        //selectedDate1 = selectedDate.replace(/(\d)\/(\d{4}).*/, "$1/$2");
        selectedDate1 = selectedDate.replace(/^(.{2})(.*)$/, "$1/$2");
      }
    }
    this.setState(
      {
        ...this.state,
        searchVo: { ...this.state.searchVo, cmsEffMonth: selectedDate1 },
      },
      () => {
        this.props.searchAttributes({ memberSearch: this.state.searchVo });
      }
    );
    document.getElementById("cmsEffMonth").focus();
  };

  handleDates = (fieldId) => {
    var self = this;
    DateUtil.getMonthDatePicker(fieldId).on("change", (e) => {
      self.setDate(e.target.name, e.target.value);
    });
  };

  setDate = async (name, value) => {
    this.setState(
      (prevState) => ({
        searchVo: {
          ...prevState.searchVo,
          [name]: value,
        },
      }),
      () => {
        this.props.searchAttributes({ memberSearch: this.state.searchVo });
      }
    );
  };

  changePage = async (page) => {
    let selectedIndex = page * this.state.rowsPerPage;
    const data = this.props.searchResultsVo.mbrSearchList[selectedIndex];
    await this.setState(() => ({
      selectedRowIndex: selectedIndex,
      memeberId: data.memberId,
      //rowsPerPage: 10,
      flag: false,
      resetFlag: true,
    }));

    await this.props.memberrowClickSearch(
      data.memberId,
      data.cmsEffMonth,
      data.medicareId,
      this.state.searchVo.showAll,
      data,
      this.state.tabNameValue
    );
  };
  selectRow = async (selectedRowIndex, member, rowsPerPage) => {
    const index = this.props.searchResultsVo.mbrSearchList.indexOf(member);
    const data = this.props.searchResultsVo.mbrSearchList[index];
    await this.setState(() => ({
      selectedRowIndex: selectedRowIndex,
      memeberId: member.memberId,
      rowsPerPage: rowsPerPage,
      flag: false,
      resetFlag: true,
    }));

    if (data.memberId !== this.props.mbrSearchCriteria.memberId) {
      await this.props.memberrowClickSearch(
        data.memberId,
        data.cmsEffMonth,
        member.medicareId,
        this.state.searchVo.showAll,
        data,
        this.state.tabNameValue
      );
    }
  };

  updatedTab = async (tabname) => {
    this.setState({
      tabNameValue: tabname,
    });
    await this.props.setSelectedTab(tabname);
  };

  fetchMemberDetails = async (e) => {
    e.preventDefault();
    let search = this.state.searchVo;
    if (document.activeElement.name === "DOB") {
      search.DOB = search.DOB.replace(/[^0-9]/g, "").trim();
      search.DOB = search.DOB.replace(/^(\d{2})/, "$1/").trim();
      search.DOB = search.DOB.replace(/\/(\d{2})/, "/$1/").trim();
      search.DOB = search.DOB.replace(/(\d)\/(\d{4}).*/, "$1/$2").trim();
    } else {
      try {
        if (document.activeElement.name !== "Undefined") {
          search[document.activeElement.name] = search[
            document.activeElement.name
          ].trim();
        }
      } catch (err) {
        //console.log(err);
      }
    }
    if (this.validator.allValid()) {
      await this.props.setSelectedTab("demo");
      await this.props.MemberSearch(this.state.searchVo);
      this.props.searchAttributes({ memberSearch: this.state.searchVo });
      this.setState({
        flag: true,
        resetFlag: true,
      });
      await this.setState({
        tabNameValue: "demo",
        index: 0,
        selectedRowIndex: 0,
      });
      if (this.state.searchVo.showAll === "Y") {
        await this.props.updateShowAllIndi({
          showAllActiveInd: false,
          Indi: "P",
        });
      } else {
        await this.props.updateShowAllIndi({
          showAllActiveInd: true,
          Indi: "N",
        });
      }
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
    this.props.resetMemberSearch({ memberId: this.state.selectedRowIndex });
  };

  handleDOBDates = (fieldId, targetVo) => (event) => {
    var self = this;
    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        if (
          dateChk.name !== e.target.name ||
          dateChk.value !== e.target.value
        ) {
          self.setDate(e.target.name, e.target.value, targetVo);
        }
        document.getElementById(fieldId.substr(1)).focus();
        dateChk.name = e.target.name;
        dateChk.value = e.target.value;
      });
    this.props.searchAttributes({ memberSearch: this.state.searchVo });
  };

  handleDate = (event) => {
    let value = event.target.value;
    let name = event.target.name;
    this.setState(
      (prevState) => ({
        searchVo: {
          ...prevState.searchVo,
          [name]: handleDateChange(value),
        },
        collapseSearch: false,
      }),
      () => {
        this.props.searchAttributes({ memberSearch: this.state.searchVo });
      }
    );
  };

  handleResetAppl = async (e) => {
    e.preventDefault();
    await this.setState({ resetFlag: false });
    await this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        memberId: "",
        medicareId: "",
        firstName: "",
        supplementalId: "",
        lastName: "",
        cmsEffMonth: "",
        dob: "",
        showAll: "N",
      },
    }));
    this.props.updateShowAllIndi({ showAllActiveInd: true, Indi: "N" });
    if (
      this.props.searchResultsVo &&
      this.props.searchResultsVo.mbrSearchList &&
      this.props.searchResultsVo.mbrSearchList.length > 0
    ) {
      await this.setState({ selectedRowIndex: 0 });
    }
    await this.props.resetClearsearch()
  };

  handleAlphaNumeric = (name) => (e) => {
    let value = e.target.value.replace(/[^-\w\s']/g, "").toUpperCase();
    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value,
      },
      collapseSearch: false,
    }));
  };
  handleSort = () => {
    this.setState({ selectedRowIndex: 0 });
  };

  handleSearchFieldChange = (name) => (event) => {
    let value = "";

    value = event.target
      ? event.target.value.toUpperCase()
      : event.value.toUpperCase();
    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value,
      },
      collapseSearch: false,
    }));
    this.props.searchAttributes({ memberSearch: this.state.searchVo });
  };
  handleOnBlur = (event) => {
    let name = event.target.name;
    let value = event.target.value.trim();

    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value,
      },
      collapseSearch: false,
    }));
    this.props.searchAttributes({ memberSearch: this.state.searchVo });
  };

  expandPanel = () => {
    this.setState({
      expanded: !this.state.expanded,
    });
  };

  errorsExpandPanel = () => {
    this.setState({
      errorsExpanded: !this.state.errorsExpanded,
    });
  };

  searchExpandPanel = () => {
    this.setState({
      searchExpand: !this.state.searchExpand,
    });
  };

  handleChangeRowsPerPage = async (rowsPerPage) => {
    await this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  memberSearchNextPage = async (pageNo) => {
    const { mbrSearchList } = this.props.searchResultsVo;
    const lastRow = mbrSearchList[mbrSearchList.length - 1];
    let payload = {
      ...this.props.searchCriteriaVo,
      memberId: lastRow.memberId,
      cmsEffMonth: lastRow.cmsEffMonth,
    };
    await this.props.memberSearchNextPage(payload);

    this.setState({ selectedRowIndex: pageNo * this.state.rowsPerPage });
  };

  handleCheckBox = (name) => async (event) => {
    let val = event.target.value === "Y" ? "N" : "Y";

    await this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: val,
      },
      modified: true,
    }));
  };
  showAll = async () => {
    if (this.props.showAllActiveInd.showAllActiveInd) {
      await this.setState((prevState) => ({
        searchVo: {
          ...prevState.searchVo,
          showAll: "Y",
        },
      }));
      this.props.updateShowAllIndi({ showAllActiveInd: false, Indi: "B" });
    } else {
      await this.setState((prevState) => ({
        searchVo: {
          ...prevState.searchVo,
          showAll: "N",
        },
      }));
      this.props.updateShowAllIndi({ showAllActiveInd: true, Indi: "N" });
    }
  };

  render() {
    const { classes, searchResultsVo, mbrSearchCriteria } = this.props;
    const mbrSnapshot = [...MEMBER_SNAPSHOT];
    const mbrSnapshotData = mbrSnapshot.filter((item) =>
      this.state.mbridLit.value === "TSA"
        ? item !== "M360 ID:"
        : item !== "Wipro ID:"
    );
    const {
      collapseSearch,
      searchVo,
      rowsPerPage,
      flag,
      selectedRowIndex,
      errorIndex,
      index,
      tabNameValue,
      resetFlag,
      mbridLit,
    } = this.state;

    let memberId = "";
    let hicNbr = "";
    let mbi = "";
    let name = "";
    let enrollStartDate = "";
    let enrollProdName = "";
    let enrollReason = "";
    let primaryaddress = "";
    let lis = "";
    let pcpName = "";
    let lep = "";
    let billingAmt = "";
    let PWO = "NO";
    let enrollstatus = "";
    let city = "";
    let state = "";
    let genderCd = "";
    let birthDateFrmt = "";
    let supplementalId="";

    if (
      searchResultsVo &&
      searchResultsVo.mbrEnrollmentList &&
      searchResultsVo.mbrEnrollmentList.length > 0
    ) {
      let enrollData =
        searchResultsVo.mbrEnrollmentList &&
        searchResultsVo.mbrEnrollmentList.filter(
          (mbrEnrollmentVo) =>
            mbrEnrollmentVo.overrideInd === "N" &&
            mbrEnrollmentVo.effEndDateFrmt === "99/99/9999"
        );
      enrollStartDate = enrollData[0].effStartDateFrmt;
      enrollProdName = enrollData[0].productName;
      enrollReason = enrollData[0].enrollReasonCd;
      enrollstatus = enrollData[0].enrollStatus;
    }

    if (
      searchResultsVo &&
      searchResultsVo.mbrAddressList &&
      searchResultsVo.mbrAddressList.length > 0
    ) {
      let addressData = searchResultsVo.mbrAddressList.filter(
        (mbraddressVo) => mbraddressVo.overrideInd === "N"
      );
      for (let i = 0; i < addressData.length; i++) {
        if (
          addressData[i].addressType === "PRIM" &&
          addressData[i].effEndDateFrmt === "99/99/9999"
        ) {
          primaryaddress = addressData[i].address1;
          city = addressData[i].city;
          state = addressData[i].stateAbbr;
          break;
        }
      }
    }

    if (
      searchResultsVo &&
      searchResultsVo.mbrDsInfoList &&
      searchResultsVo.mbrDsInfoList.length > 0
    ) {
      let dsInfoData = searchResultsVo.mbrDsInfoList.filter(
        (mbrdsInfo) => mbrdsInfo.overrideInd === "N"
      );
      for (let i = 0; i < dsInfoData.length; i++) {
        if (dsInfoData[i].dsCd === "PWO") {
          PWO = dsInfoData[i].dsValue;
        }
      }
    }

    if (
      searchResultsVo &&
      searchResultsVo.mbrSnapshot &&
      mbrSearchCriteria &&
      searchResultsVo.mbrDemographicVO
    ) {
      const { mbrSnapshot, mbrDemographicVO } = searchResultsVo;

      memberId = mbrSearchCriteria.memberId;
      hicNbr = mbrSearchCriteria.hicNbr;
      mbi = mbrSearchCriteria.mbi;
      name = mbrSearchCriteria.name;
      lis = mbrSnapshot.lisCopayCd && mbrSnapshot.lisPctCd && mbrSnapshot.lisAmt ? 'CP='+ mbrSnapshot.lisCopayCd + ' Perct ' + mbrSnapshot.lisPctCd + '% SUB $' + mbrSnapshot.lisAmt : '';
      pcpName = mbrSnapshot.pcpName;
      lep = mbrSnapshot.numUnCovMths && mbrSnapshot.lepAmt ? 'NUMCO ' + mbrSnapshot.numUnCovMths + ' LEP AMT $' + mbrSnapshot.lepAmt : '';
      billingAmt = mbrSnapshot.billingAmt ? '$' + mbrSnapshot.billingAmt : '$0.00';
      genderCd = mbrDemographicVO.genderCd;
      birthDateFrmt = mbrDemographicVO.birthDateFrmt;
      supplementalId=mbrSnapshot.supplementalId;
    }
    const snapShotValues = [
      memberId,
      hicNbr,
      mbi,
      name,
      enrollStartDate,
      enrollProdName,
      enrollstatus + "  " + enrollReason,
      primaryaddress + "|" + city + "|" + state,
      lis,
      pcpName,
      lep,
      billingAmt,
      PWO,
      genderCd,
      birthDateFrmt,
      supplementalId
    ];

    return (
      <Paper
        elevation={0}
        className={classes.card}
        style={{ minHeight: "400px" }}
      >
        <div class="search-panel">
          <ExpansionPanel
            summary="Member Search"
            defaultCollapsed={collapseSearch}
          >
            <form onSubmit={this.fetchMemberDetails}>
              <div className={classes.container}>
                <div>
                  <InputField
                    name="memberId"
                    InputProps={{ className: classes.textFont }}
                    label={mbridLit.value === "TSA" ? "Wipro ID" : "M360 ID"}
                    className={classes.textField}
                    value={searchVo.memberId}
                    InputLabelProps={{ className: classes.label, shrink: true }}
                    onChange={this.handleAlphaNumeric("memberId")}
                    onBlur={this.handleOnBlur}
                    maxLength={15}
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="medicareId"
                    InputProps={{ className: classes.textFont }}
                    label="Medicare ID"
                    className={classes.textField}
                    value={searchVo.medicareId}
                    InputLabelProps={{ className: classes.label, shrink: true }}
                    onChange={this.handleSearchFieldChange("medicareId")}
                    onBlur={this.handleOnBlur}
                    maxLength={12}
                  />
                  <div className={classes.validationMessage} />
                </div>

                <div>
                  <InputField
                    name="firstName"
                    InputProps={{ className: classes.textFont }}
                    label="Member First Name"
                    className={classes.textField}
                    value={searchVo.firstName}
                    InputLabelProps={{ className: classes.label, shrink: true }}
                    onChange={this.handleSearchFieldChange("firstName")}
                    onBlur={this.handleOnBlur}
                    maxLength={24}
                  />
                  <div className={classes.validationMessage} />
                </div>

                <div>
                  <InputField
                    name="supplementalId"
                    InputProps={{ className: classes.textFont }}
                    label="Plan Member ID"
                    className={classes.textField}
                    value={searchVo.supplementalId}
                    InputLabelProps={{ className: classes.label, shrink: true }}
                    onChange={this.handleSearchFieldChange("supplementalId")}
                    onBlur={this.handleOnBlur}
                    maxLength={15}
                  />
                  <div className={classes.validationMessage} />
                </div>

                <div>
                  <InputField
                    name="lastName"
                    InputProps={{ className: classes.textFont }}
                    label="Member Last Name"
                    className={classes.textField}
                    value={searchVo.lastName}
                    InputLabelProps={{ className: classes.label, shrink: true }}
                    onChange={this.handleSearchFieldChange("lastName")}
                    onBlur={this.handleOnBlur}
                    maxLength={35}
                  />
                  <div className={classes.validationMessage} />
                </div>

                <div>
                  <InputField
                    name="dob"
                    InputProps={{ className: classes.textFont }}
                    label="Date of Birth"
                    className={classes.textField}
                    value={searchVo.dob}
                    InputLabelProps={{ className: classes.label, shrink: true }}
                    onClick={this.handleDOBDates("#dob")}
                    onChange={this.handleDate}
                    onBlur={this.handleOnBlur}
                    maxLength={10}
                    placeholder="MM/DD/YYYY"
                  />
                  <div className={classes.validationMessage} />
                </div>

                <div>
                  <div>
                    <label>Effective Month (mm/yyyy)</label>

                    <Datetime
                      autoFocus
                      onChange={this.monthPicker}
                      value={searchVo.cmsEffMonth}
                      dateFormat="MM/YYYY"
                      inputProps={{
                        placeholder: "MM/YYYY",
                        className: "monthPicker",
                        maxLength: 7,
                        id: "cmsEffMonth",
                      }}
                      timeFormat={false}
                    />
                  </div>
                  <div className={classes.validationMessage}>
                    {this.validator.message(
                      "Effective Month ",
                      searchVo.cmsEffMonth,
                      "date_format_MM_YYYY"
                    )}
                  </div>
                </div>

                <span
                  class="button-container-search"
                  style={{ marginTop: "20px", marginLeft: "0px" }}
                >
                  <button id="search" class="btn btn-primary icon-search">
                    Search
                  </button>

                  <button
                    id="reset"
                    class="btn btn-secondary"
                    onClick={this.handleResetAppl}
                  >
                    Reset
                  </button>
                </span>
                <div className={classes.CheckboxAppl}>
                  <Checkbox1
                    color="primary"
                    checked={this.state.searchVo.showAll === "Y" ? true : false}
                    value={this.state.searchVo.showAll}
                    name="Show All"
                    padding={"0px 0px 0px 0px !important"}
                    onClick={this.handleCheckBox("showAll")}
                  />
                  <span className={classes.checkboxlebel}>Show All</span>
                </div>
              </div>
            </form>
          </ExpansionPanel>
        </div>

        {searchResultsVo ? (
          <React.Fragment>
            {searchResultsVo.mbrSearchList != null ? (
              <React.Fragment>
                {searchResultsVo.mbrSearchList.length !== 1 ? (
                  <ExpansionPanel summary="Search Results">
                    <DataTable
                      data={searchResultsVo.mbrSearchList}
                      header={header}
                      rowsPerPage={rowsPerPage}
                      sortable={true}
                      rowsPerPageOptions={[10, 15, 20]}
                      clicked={this.selectRow}
                      clickedFooter={this.changePage}
                      flag={flag}
                      index={selectedRowIndex}
                      searchable={true}
                      exportAsExcel={true}
                      handleChangeRowsPerPage={this.handleChangeRowsPerPage}
                      fetchMore={this.memberSearchNextPage}
                      nextPage={searchResultsVo.nextPage}
                      dateColumn="cmsEffMonth"
                      resetFlag={this.state.resetFlag}
                      handleSort={this.handleSort}
                    />
                  </ExpansionPanel>
                ) : null}

                <React.Fragment>
                  <div className={classes.mbrgrid1}>
                    {mbrSnapshotData.map((item, i) => {
                      return (
                        <div className={classes.mbrgrid2}>
                          <td>
                            <InputLabel
                              disabled
                              className={classes.readOnlyLableDisabled}
                            >
                              {item}
                              <InputBase
                                margin="dense"
                                disabled
                                className={classes.readOnly}
                                value={snapShotValues[i]}
                              />
                            </InputLabel>
                          </td>
                        </div>
                      );
                    })}
                  </div>
                </React.Fragment>

                <React.Fragment>
                  <ExpansionPanel summary="Errors">
                    {searchResultsVo.mbrErrorList ? (
                      <DataTable
                        data={this.props.searchResultsVo.mbrErrorList}
                        header={ERROR_HEADER}
                        rowsPerPage={5}
                        sortableHeader={true}
                        clicked={this.selectRow}
                        notClickable
                        msgChange="No Errors"
                        index={errorIndex}
                        errorTable
                      />
                    ) : null}
                  </ExpansionPanel>
                </React.Fragment>
              </React.Fragment>
            ) : null}
          </React.Fragment>
        ) : null}

        {this.props.message && resetFlag === true ? (
          <DataTable data={[]} header={header} />
        ) : null}

        {this.props.searchResultsVo ? (
          <div>
            <MbrShowAll
              showAll={this.showAll}
              classes={classes}
              toggleLabel={this.props.showAllActiveInd.showAllActiveInd}
            />

            <MemberAppBar
              indexVal={index}
              updatedTab={this.updatedTab}
              value={tabNameValue}
              handleShowAll={this.handleShowAll}
              showAllActiveInd={this.state.showAllActiveInd}
              showAllData={this.state.showAllData}
            />
          </div>
        ) : null}
      </Paper>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    loginProfile: state.loginData.profiles,
    selectedMemberId: state.memberSearch.selectedMemberId,

    searchCriteriaVo: state.memberSearch.searchCriteriaVo,
    dropdowns: state.dropdowns,
    membercache: state.membercache,
    searchResultsVo: state.memberSearch.searchResultsVo,
    message: state.memberSearch.message,
    mbrSearchCriteria: state.memberSearch.mbrSearchCriteria,
    selectedTab: state.memberSearch.selectedTab,
    searchAttribute: state.memberSearch.searchAttributes
      ? state.memberSearch.searchAttributes.memberSearch
      : null,
    showAllActiveInd: state.memberSearch.showAllActiveIndi,
  };
};

const mapDispatchToProps = {
  MemberSearch,
  fetchMemberCacheData,
  memberrowClickSearch,
  setValue,
  resetMemberSearch,
  memberSearchNextPage,
  getShowAll,
  updateShowAllIndi,
  setSelectedTab,
  searchAttributes,
  resetClearsearch
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(MbrSearch));
