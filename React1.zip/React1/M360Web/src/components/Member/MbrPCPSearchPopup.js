import React, { Component } from "react";

import Button from "@material-ui/core/Button";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import Checkbox from "@material-ui/core/Checkbox";
import DataTable from "../Home/DataTable";
import FormLabel from "@material-ui/core/FormLabel";
import InputField from "../UI/InputField";
import { MemberPCPSearchData } from "../../redux/actions/MemberActions";
import Paper from "@material-ui/core/Paper";
import { Styles } from "../../assets/styles/PopupTheme";
import classNames from "classnames";
import { connect } from "react-redux";
import { PCP_SEARCH_POPUP_HEADER as header } from "../../constants/Headers/MemberHeaders";
import { withStyles } from "@material-ui/core/styles";
import isEmpty from "lodash/isEmpty";

class MbrPCPSearchPopup extends Component {
  constructor(props) {
    super(props);
    this.state = {
      searchVo: {
        effDate: this.props.search.effStartDateFrmt,
        pcpNbr: this.props.search.pcpNbr,
        locationId: this.props.search.locationId,
        doctorName: this.props.search.doctorName,
        pcpNpi: this.props.search.pcpNpi,
      },
      selectedIndex: 0,
      page: 0,
      data: null,
    };
  }

  onRowSelect = (index, page) => {
    this.setState({
      selectedIndex: index,
      page: page,
    });
  };

  onSubmit = (event) => {
    event.preventDefault();
    const tableData = [...this.props.data];
    const selectedVo = tableData[this.state.selectedIndex];
    this.props.updateValue(selectedVo);
    this.props.close();
  };

  reset = () => {
    this.setState(() => ({
      searchVo: {
        pcpNbr: "",
        locationId: "",
        doctorName: "",
        effDate: this.state.searchVo.effDate,
      },
    }));
  };

  async componentDidMount() {
    if (this.props.search.effStartDateFrmt === "") {
      this.props.close();
      alert("Please Enter Effective Start date");
    } else {
      await this.props.MemberPCPSearchData(this.state.searchVo);
      this.setState({ data: this.props.data });
    }
  }

  filtersearch = async (event) => {
    event.preventDefault();
    await this.props.MemberPCPSearchData(this.state.searchVo);
    this.setState({ data: this.props.data });
  };

  handleChange = (e) => {
    let value = e.target.value.toUpperCase();
    let name = [e.target.name];

    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value,
      },
    }));
  };

  handleOnBlur = (e) => {
    let value = e.target.value.trim();
    let name = [e.target.name];

    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value,
      },
    }));
  };

  render() {
    const { classes } = this.props;
    const { searchVo, data } = this.state;

    return (
      <React.Fragment>
        <Paper
          className={classes.root}
          elevation={0}
          style={{ padding: "15px",textAlign:"center" }}
        >
          <fieldset className={classes.fieldset}>
            <legend className={classes.legend}>PCP Search</legend>
            <form autoComplete="off" onSubmit={this.filtersearch}>
              <div className={classes.container}>
                <div className={classes.div1}>
                  <span>
                    <InputField
                      name="pcpNbr"
                      label="Office Code"
                      maxLength={12}
                      required
                      value={searchVo.pcpNbr}
                      onChange={this.handleChange}
                      onBlur={this.handleOnBlur}
                    />
                  </span>
                  <span>
                    <InputField
                      name="locationId"
                      label="Location ID"
                      maxLength={2}
                      width={
                        this.props.searchResultsVo.npiInd === "Y"
                          ? null
                          : "262px"
                      }
                      value={searchVo.locationId}
                      onChange={this.handleChange}
                      onBlur={this.handleOnBlur}
                    />
                  </span>
                  {this.props.searchResultsVo.npiInd === "Y" ? (
                    <span>
                      <InputField
                        name="pcpNpi"
                        label="NPI"
                        width="8rem"
                        minWidth="8rem"
                        maxLength={12}
                        value={searchVo.pcpNpi}
                        onChange={this.handleChange}
                        onBlur={this.handleOnBlur}
                      />
                    </span>
                  ) : null}
                  <span className={classes.margins1}>
                    <InputField
                      name="doctorName"
                      label="Doctor Name"
                      required
                      value={searchVo.doctorName}
                      onChange={this.handleChange}
                      onBlur={this.handleOnBlur}
                      width={
                        this.props.searchResultsVo.npiInd === "Y"
                          ? "511px"
                          : "455px"
                      }
                      maxLength={50}
                    />
                  </span>
                </div>
              </div>
              <div className={classes.div1}>
                <Checkbox
                  style={{ width: 36, height: 36 }}
                  icon={
                    <CheckBoxOutlineBlankIcon style={{ fontSize: "16px" }} />
                  }
                  checkedIcon={
                    <CheckBoxIcon className={classes.checkboxmember} />
                  }
                  disabled={this.state.editable}
                />
                <FormLabel classes={{ root: classes.formLabel }}>
                  Accept New Patient
                </FormLabel>
              </div>
              <br></br>
              <div className={classes.div1}>
                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={this.filtersearch}
                >
                  <i className="material-icons">search</i>
                </Button>

                <Button
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={this.props.close}
                >
                  <i className="material-icons">cancel</i>
                </Button>
                <Button
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={this.reset}
                >
                  <i class="material-icons">refresh</i>
                </Button>
              </div>
            </form>
          </fieldset>
        </Paper>
        <div className={classes.table}>
          <span className="AgencySearch-table" style={{ width: "1200px"}}>
            {data ? (
              <DataTable
                data={data}
                header={header}
                rowsPerPage={5}
                clicked={this.onRowSelect}
                index={this.state.selectedIndex}
                pageNo={this.state.page}
                
              />
            ) : null}
          </span>

          {!isEmpty(this.props.data) ? (
            <div className={classes.div1}>
              <Button
                variant="contained"
                color="primary"
                className={classNames(classes.button, classes.submit)}
                onClick={this.onSubmit}
              >
                Submit
              </Button>
            </div>
          ) : null}
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  data: state.memberSearch.pcpSearchData,
  pcpVo: state.memberSearch.pcpDetails,
  searchResultsVo: state.memberSearch.searchResultsVo,
});

const mapDispatchToProps = {
  MemberPCPSearchData,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(MbrPCPSearchPopup));
