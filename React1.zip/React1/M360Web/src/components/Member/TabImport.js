import Loadable from 'react-loadable-visibility/react-loadable';
import React from "react";


export const Demographics = Loadable({
	loader: () => import('./MbrDemographic'),
	loading() {
		return <div></div>
	}
})

export const DsInfo = Loadable({
	loader: () => import('./MbrDsInfo'),
	loading() {
		return <div></div>
	}
})

export const Enrollment = Loadable({
	loader: () => import('./MbrEnrollment'),
	loading() {
		return <div></div> 
	}
})
export const ASES = Loadable({
	loader: () => import('./MbrASES'),
	loading() {
		return <div></div>
	}
})
export const Accretion = Loadable({
	loader: () => import('./MbrAccretion'),
	loading() {
		return <div></div>
	}
})
export const Agent= Loadable({
	loader: () => import('./MbrAgent'),
	loading() {
		return <div></div>
	}
})
export const Billing = Loadable({
	loader: () => import('./MbrBilling'),
	loading() {
		return <div></div>
	}
})
export const COB = Loadable({
	loader: () => import('./MbrCOB'),
	loading() {
		return <div></div>
	}
})
export const Comments = Loadable({
	loader: () => import('./MbrComments'),
	loading() {
		return <div></div>
	}
})
export const LEP = Loadable({
	loader: () => import('./LEP/MbrLepTab'),
	loading() {
		return <div></div>
	}
})
export const LIS = Loadable({
	loader: () => import('./MbrLIS'),
	loading() {
		return <div></div>
	}
})
export const LTC = Loadable({
	loader: () => import('./MbrLTC'),
	loading() {
		return <div></div>
	}
})
export const Letters = Loadable({
	loader: () => import('./MbrLetters'),
	loading() {
		return <div>Loading...</div>
	}
})
export const MemberAddress = Loadable({
	loader: () => import('./MbrAddress'),
	loading() {
		return <div>Loading...</div>
	}
})
export const OOA = Loadable({
	loader: () => import('./MbrOOA'),
	loading() {
		return <div></div>
	}
})
export const PCP = Loadable({
	loader: () => import('./MbrPCP'),
	loading() {
		return <div></div>
	}
})
export const POS = Loadable({
	loader: () => import('./MbrPOS'),
	loading() {
		return <div></div>
	}
})
export const TRR = Loadable({
	loader: () => import('./MbrTRR'),
	loading() {
		return <div></div>
	}
})
