import React, { Component } from "react";

import Button from "@material-ui/core/Button";
import DataTable from "../Home/DataTable";
import InputField from "../UI/InputField";
import Paper from "@material-ui/core/Paper";
import { Styles } from "../../assets/styles/PopUpStyle";
import classNames from "classnames";
import { connect } from "react-redux";
import { FACILITY_TABLE_HEADER as header } from "../../constants/Headers/MemberHeaders";
import { ltcFacilitySearch } from "../../redux/actions/MemberActions";
import { withStyles } from "@material-ui/core/styles";
import isEmpty from "lodash/isEmpty";

class FacilitySearch extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedVo: {
        address: "",
        facilityid:
          this.props.ltcIdNameChange === false ? this.props.ltcVo.ltcId : "",
        facilityname:
          this.props.ltcIdNameChange === false
            ? this.props.ltcVo.facilityName
            : "",
        effStartDateFrmt: this.props.ltcVo.effStartDateFrmt,
      },

      selectedIndex: 0,
      data: null,
    };
  }

  onRowSelect = (index) => {
    this.setState({
      selectedIndex: index,
    });
  };

  onSubmit = () => {
    const tableData = [...this.props.facilityList];
    const selectedVo = tableData[this.state.selectedIndex];
    this.props.setData(selectedVo);
    this.props.close();
  };

  componentDidMount() {
    const params = {
      customerId: this.props.loginData.loginVo.customerId,
      effDateFrmt: this.state.selectedVo.effStartDateFrmt,
      ltcFacId: this.state.selectedVo.facilityid,
      facilityName: this.state.selectedVo.facilityname,
    };
    if (!this.props.dateValidator) {
      this.props.close();
    } else {
      this.props.ltcFacilitySearch(params);
    }
  }

  search = (event) => {
    event.preventDefault();
  };

  reset = () => {
    this.setState(() => ({
      selectedVo: {
        effStartDateFrmt: this.props.ltcVo.effStartDateFrmt,
        facilityid: "",
        facilityname: "",
      },
    }));
  };

  handleChange = (e) => {
    let value = e.target.value.toUpperCase();
    let name = [e.target.id];
    this.setState((prevState) => ({
      selectedVo: {
        ...prevState.selectedVo,
        [name]: value,
      },
    }));
  };

  handleOnBlur = (e) => {
    let value = e.target.value.trim();
    let name = [e.target.id];
    this.setState((prevState) => ({
      selectedVo: {
        ...prevState.selectedVo,
        [name]: value,
      },
    }));
  };

  serachResult = (event) => {
    event.preventDefault();

    const params = {
      customerId: this.props.loginData.loginVo.customerId,
      effDateFrmt: this.state.selectedVo.effStartDateFrmt,
      ltcFacId: this.state.selectedVo.facilityid,
      facilityName: this.state.selectedVo.facilityname,
    };
    this.props.ltcFacilitySearch(params);
  };
  render() {
    const { classes, headerLabel } = this.props;
    let dataSet = null;

    if (this.props.facilityList) {
      dataSet = (
        <div className={classes.table}>
          <DataTable
            data={this.props.facilityList}
            header={header}
            rowsPerPage={5}
            clicked={this.onRowSelect}
            index={this.state.selectedIndex}
          />
          <div className={classes.div1}>
            <Button
              disabled={isEmpty(this.props.facilityList)}
              variant="contained"
              color="primary"
              className={classNames(classes.button, classes.submit)}
              onClick={this.onSubmit}
            >
              Submit
            </Button>
          </div>
        </div>
      );
    }

    return (
      <React.Fragment>
        <Paper
          className={classes.root}
          elevation={0}
          style={{ padding: "15px" }}
        >
          <fieldset className={classes.fieldset}>
            <legend className={classes.legend}>{headerLabel}</legend>
            <form
              className={classes.container}
              autoComplete="off"
              onSubmit={this.serachResult}
            >
              <div>
                <span style={{ width: "190px" }}>
                  <InputField
                    label="LTC Facility ID"
                    id="facilityid"
                    value={this.state.selectedVo.facilityid}
                    maxLength="12"
                    onChange={this.handleChange}
                    onBlur={this.handleOnBlur}
                  />
                </span>

                <span>
                  <InputField
                    label="Facility Name"
                    id="facilityname"
                    value={this.state.selectedVo.facilityname}
                    onChange={this.handleChange}
                    onBlur={this.handleOnBlur}
                    maxLength="50"
                    width="415px"
                  />
                </span>
              </div>
              <div className={classes.div1}>
                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  className={classes.button}
                >
                  <i className="material-icons" onClick={this.serachResult}>
                    search
                  </i>
                </Button>
                {/* <i class="fa fa-search" aria-hidden="true"></i> */}

                <Button
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={this.props.close}
                >
                  <i className="material-icons">cancel</i>
                </Button>
                <Button
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={this.reset}
                >
                  <i class="material-icons">refresh</i>
                </Button>
              </div>
            </form>
          </fieldset>
        </Paper>
        {dataSet}
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    facilityList: state.memberSearch.facilitySearch,
    loginData: state.loginData,
  };
};
const mapDispatchToProps = {
  ltcFacilitySearch,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(FacilitySearch));
