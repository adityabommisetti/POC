import React, { Component } from "react";
import { getTRRData } from "../../redux/actions/MemberActions";

import DataTable from "../Home/DataTable";

import { Styles } from "../../assets/styles/PopupTheme";
import { connect } from "react-redux";
import { TRRDATA_TABLE_HEADER as header } from "../../constants/Headers/MemberHeaders";
import { withStyles } from "@material-ui/core/styles";
import isEmpty from "lodash/isEmpty";
import Button from "@material-ui/core/Button";

class MbrTRRData extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedIndex: 0,
    };
  }

  async componentDidMount() {
    await this.props.getTRRData(
      this.props.mbrSearchCriteria.memberId,
      this.props.data.logTime
    );
  }

  render() {
    const { classes, trrData } = this.props;
    return (
      <React.Fragment>
        <div className={classes.table}>
          <div className="panel-subhead2">
            <h3> TRR DATA </h3>
          </div>

          <DataTable
            data={!isEmpty(trrData) ? trrData : []}
            header={header}
            rowsPerPage={5}
            sortable={false}
            clicked={() => {}}
            index={0}
            selectedRow="true"
            pageNo={this.state.page}
          />
        </div>
        <div className={classes.div1}>
          <Button
            variant="contained"
            color="primary"
            className={classes.button}
            onClick={this.props.close}
          >
            <i className="material-icons">cancel</i>
          </Button>
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  trrData: state.memberSearch.searchResultsVo.mbrTrrDataList,
  mbrSearchCriteria: state.memberSearch.mbrSearchCriteria,
});

const mapDispatchToProps = {
  getTRRData,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(MbrTRRData));
