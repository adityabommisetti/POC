import {
  LIS_TABLE_DATA as DATA,
  LIS_TABLE_HEADER as header,
} from "../../../constants/Headers/MemberHeader";
import React, { Component } from "react";

import $ from "jquery";
import { ADDRESS_TYPE_LIST } from "../../../constants/SelectStaticData";
import Button from "@material-ui/core/Button";
import Checkbox from "@material-ui/core/Checkbox";
import { Control } from "../../UI/Select";
import DataTable from "../../Home/DataTable";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import HistoryData from "../../UI/MemberHistory";
import InputField from "../../UI/InputField";
import MemberButtonPanel from "../../UI/MemberButtonPanel";
import { Menu } from "../../UI/Select";
import { Option } from "../../UI/Select";
import Paper from "@material-ui/core/Paper";
import { Select } from "../../UI/Select";
import { Styles } from "../../../assets/styles/Theme";
import { ValueContainer } from "../../UI/Select";
import { confirmAlert } from "react-confirm-alert";
import { withStyles } from "@material-ui/core/styles";

const components = {
  Control,
  Menu,
  ValueContainer,
  Option,
};

const INITIAL_LIS_STATE = {
  pwoType: "",
  pwoDesc: "",
  effectiveDate: "",
  termDate: "",
  overrideInd: "",
  planCode: "",
  createUserId: "",
  createTime: "",
  lastUpdtTime: "",
  lastUpdtUserId: "",
};

class PWO extends Component {
  state = {
    lisVo: DATA[0],
    lisOldVo: DATA[0],
    data: DATA,
    modified: false, //show/hide update button
    showAllActive: true, //showAll & active label change
    isNewSegment: false, //new Sengement
    editable: false, // Editable
  };

  selectRow = (index) => {
    const data = [...this.state.data];
    const selectedVo = data[index];
    this.setState(() => ({
      lisVo: {
        ...selectedVo,
      },
      lisOldVo: {
        ...selectedVo,
      },
      editable: false,
      isNewSegment: false,
      modified: false,
    }));
  };

  goBack = () => {
    this.setState({
      isNewSegment: false,
      editable: false,
      modified: false,
      pwoVo: { ...this.state.lisOldVo },
    });
  };

  handlechange = (name) => (event) => {
    let value = event.target.value;
    this.setState((prevState) => ({
      lisVo: {
        ...prevState.lisVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleStartDate = (fieldId) => {
    var self = this;
    $(fieldId)
      .datepicker({
        showAnim: "clip",
        beforeShowDay: function (date) {
          if (date.getDate() === 1) {
            return [true, ""];
          }
          return [false, ""];
        },
      })
      .on("change", (e) => {
        self.setDate(e.target.name, e.target.value);
      });
  };

  handleDates = (fieldId) => {
    var self = this;
    $(fieldId)
      .datepicker({ showAnim: "clip" })
      .on("change", (e) => {
        self.setDate(e.target.name, e.target.value);
      });
  };

  setDate = (name, value) => {
    this.setState((prevState) => ({
      lisVo: {
        ...prevState.lisVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleChangeSearchSelect = (name) => (event) => {
    let value = event.value;
    this.setState((prevState) => ({
      lisVo: {
        ...prevState.lisVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  modelSegment = () => {
    this.setState({
      editable: true,
      isNewSegment: false,
    });
  };

  createNewSegment = () => {
    this.setState({
      editable: true,
      isNewSegment: true,
      lisVo: {
        ...INITIAL_LIS_STATE,
      },
    });
  };

  updatePwo = (event) => {
    event.preventDefault();

    if (this.validator.allValid()) {
      confirmAlert({
        customUI: ({ onClose }) => {
          const { classes } = this.props;
          return (
            <div className={classes.confirmDialog}>
              <h3>Are you sure you want to update?</h3>
              {/* <p>It will discard all your changes for current model</p> */}
              <Button
                className={classes.confirmDialogButton}
                variant="contained"
                onClick={onClose}
              >
                No
              </Button>

              <Button
                className={classes.confirmDialogButton}
                variant="contained"
                onClick={() => {
                  this.confirmUpdateAddress();
                  onClose();
                }}
              >
                Yes
              </Button>
            </div>
          );
        },
      });
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  addNewSegment = () => {
    alert("adeed");
  };

  confirmUpdatePwo = () => {};
  render() {
    const { classes, loading } = this.props;

    let ButtonPanel = (
      <MemberButtonPanel
        isNewSegment={this.state.isNewSegment}
        showAll={this.props.showAll}
        toggleLabel={this.state.showAllActive}
        newSegment={this.createNewSegment}
        modelSegment={this.modelSegment}
        modified={this.state.modified}
        editable={this.state.editable}
        delete={this.deletePwo}
        update={this.updatePWo}
      />
    );

    return (
      <Paper elevation={0} className={classes.card}>
        {loading && <div id="cover-spin"></div>}
        {this.state.data ? (
          <DataTable
            data={this.state.data}
            header={header}
            rowsPerPage={5}
            clicked={this.selectRow}
          />
        ) : null}
        <form autoComplete="off">
          {ButtonPanel}
          <div className={classes.container}>
            <div>
              <InputField
                name="startDate"
                id="startDate"
                onClick={this.handleStartDate("#startDate")}
                label="Start Date"
                required
                value={this.state.lisVo.startDate}
                onChange={this.handlechange("startDate")}
                disabled={!this.state.editable}
              />
              <div className={classes.validationMessage}></div>
            </div>
            <div>
              <InputField
                name="endDate"
                onClick={this.handleDates("#endDate")}
                label="End Date"
                required
                value={this.state.lisVo.endDate}
                onChange={this.handlechange("endDate")}
                disabled={!this.state.editable}
              />
              <div className={classes.validationMessage}></div>
            </div>
            <div>
              <InputField
                name="groupNo"
                label="Group Number"
                required
                value={this.state.lisVo.groupNo}
                onChange={this.handlechange("groupNo")}
                disabled={!this.state.editable}
                maxLength={20}
              />
              <div className={classes.validationMessage}></div>
            </div>
            <div>
              <InputField
                name="overrideInd"
                label="Override Ind"
                required
                value={this.state.lisVo.overrideInd}
                onChange={this.handlechange("overrideInd")}
                disabled={!this.state.editable}
              />
              <div className={classes.validationMessage}></div>
            </div>

            <div>
              <Select
                components={components}
                propertyName={ADDRESS_TYPE_LIST.filter(
                  (option) => option.value === this.state.lisVo.subsidySource
                )}
                options={ADDRESS_TYPE_LIST}
                label="Choose Subsidy Source ..."
                textFieldProps={{
                  label: "Subsidy Source",
                  InputLabelProps: {
                    className: classes.label,
                    shrink: true,
                  },
                }}
                className={classes.textFieldSelect}
                handleChange={this.handleChangeSearchSelect("subsidySource")}
                isDisabled={!this.state.editable}
                classes={classes}
              />

              <div className={classes.validationMessageSelect}></div>
            </div>

            <div>
              <Select
                components={components}
                propertyName={ADDRESS_TYPE_LIST.filter(
                  (option) => option.value === this.state.lisVo.copay
                )}
                options={ADDRESS_TYPE_LIST}
                label="Choose copay ..."
                textFieldProps={{
                  label: "Copay",
                  InputLabelProps: {
                    className: classes.label,
                    shrink: true,
                  },
                }}
                className={classes.textFieldSelect}
                handleChange={this.handleChangeSearchSelect("copay")}
                isDisabled={!this.state.editable}
                classes={classes}
              />

              <div className={classes.validationMessageSelect}></div>
            </div>
            <div className={classes.textField}>
              <FormControlLabel
                control={
                  <Checkbox
                    value="checkedB"
                    color="primary"
                    checked={this.state.lisVo.licBae === "Y" ? true : false}
                    classes={{
                      root: classes.checkboxControl,
                    }}
                    disabled
                  />
                }
                label="LIC Bae"
                classes={{
                  root: classes.checkboxLabel,
                }}
              />
            </div>

            <div>
              <Select
                components={components}
                propertyName={ADDRESS_TYPE_LIST.filter(
                  (option) => option.value === this.state.lisVo.percent
                )}
                options={ADDRESS_TYPE_LIST}
                label="Choose Percent ..."
                textFieldProps={{
                  label: "Percent",
                  InputLabelProps: {
                    className: classes.label,
                    shrink: true,
                  },
                }}
                className={classes.textFieldSelect}
                handleChange={this.handleChangeSearchSelect("pwoType")}
                isDisabled={!this.state.editable}
                classes={classes}
              />

              <div className={classes.validationMessageSelect}></div>
            </div>
            <div className={classes.textField}>
              <FormControlLabel
                control={
                  <Checkbox
                    value="checkedB"
                    color="primary"
                    checked={this.state.lisVo.lisBae === "Y" ? true : false}
                    classes={{
                      root: classes.checkboxControl,
                    }}
                    disabled
                  />
                }
                label="LIS Bae"
                classes={{
                  root: classes.checkboxLabel,
                }}
              />
            </div>
            <div>
              <InputField
                name="lisAmt"
                label="LIS Amount"
                required
                value={this.state.lisVo.lisAmt}
                onChange={this.handlechange("lisAmt")}
                disabled={!this.state.editable}
                maxLength={10}
              />
              <div className={classes.validationMessage}></div>
            </div>

            <div>
              <InputField
                name="spapAmt"
                label="SPAP Amount"
                required
                value={this.state.lisVo.spapAmt}
                onChange={this.handlechange("spapAmt")}
                disabled={!this.state.editable}
                maxLength={10}
              />
              <div className={classes.validationMessage}></div>
            </div>
          </div>
        </form>

        <HistoryData
          isNewSegment={this.state.isNewSegment}
          reset={this.createNewSegment}
          addSegment={this.addNewSegment}
          back={this.goBack}
          createUserId={this.state.lisVo.createUserId}
          createTime={this.state.lisVo.createTime}
          lastUpdtTime={this.state.lisVo.lastUpdtTime}
          lastUpdtUserId={this.state.lisVo.lastUpdtUserId}
        />
      </Paper>
    );
  }
}

export default withStyles(Styles)(PWO);
