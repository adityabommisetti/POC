import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import { Select } from '../../UI/Select';
import Button from '@material-ui/core/Button';
import Paper from '@material-ui/core/Paper';
import { EMPLOYER_TABLE_HEADER as header, EMPLOYER_TABLE_DATA as DATA } from '../../../constants/Headers/MemberHeader';
import DataTable from '../../Home/DataTable';
import $ from "jquery";
import { confirmAlert } from 'react-confirm-alert';
import { Styles } from '../../../assets/styles/Theme';
import HistoryData from '../../UI/MemberHistory';
import MemberButton from '../../UI/MemberButtonPanel';
import InputField from '../../UI/InputField';



class EmployerContribution extends Component {
  state = {
    vo: {
      employerContibutionType: '',
      effectiveDate: '',
      terminationDate: '',
      receivedDate: '',
      amount: '',
      createUserId: '',
      createTime: '',
      lastUpdtTime: '',
      lastUpdtUserId: '',
    },
    employerContributionVo: DATA[0],
    oldEmployerContributionVo :DATA[0],
    data: DATA,
    modified: false,
    showAllActive:true,
    isNewSegment: false,
    editable: false
  }


  selectRow = (index) => {

    const data = [...this.state.data];
    const selectedVo = data[index];
    this.setState(() => ({
      employerContributionVo:
      {
        ...selectedVo
      },
      oldEmployerContributionVo:{
        ...selectedVo
        
      },
      editable:false,
      isNewSegment:false,
      modified:false
    }))
  }

  handlechange = name => event => {

    let value = event.target.value;


    this.setState(prevState => ({
      employerContributionVo:
      {
        ...prevState.employerContributionVo,
        [name]: value

      },

      modified: true
    }))
  };

  handleStartDate = fieldId => {
    var self = this;
    $(fieldId).datepicker({
      showAnim: "clip",
      beforeShowDay: function (date) {
        if (date.getDate() === 1) {
          return [true, ''];
        }
        return [false, ''];
      }
    }
    ).on("change", e => {
      self.setDate(e.target.name, e.target.value)
    });

  }

  handleDates = fieldId => {
    var self = this;
    $(fieldId).datepicker().on("change", e => {
      self.setDate(e.target.name, e.target.value)
    });

  }


  setDate = (name, value) => {
    this.setState(prevState => ({
      employerContributionVo:
      {
        ...prevState.employerContributionVo,
        [name]: value
      },
      modified: true
    }))


  }


  handleChangeSearchSelect = name => event => {
    let value = event.value;
    this.setState(prevState => ({
      employerContributionVo:
      {
        ...prevState.employerContributionVo,
        [name]: value
      },
      modified: true
    }))

  };

  modelSegment = () => {
    this.setState({
      editable: true,
      isNewSegment: false
    });

  }

  createNewSegment = () => {
    this.setState({
      editable: true,
      isNewSegment: true,
      employerContributionVo: {
        ...this.state.vo

      }
    });
  }

  updatePwo = (event) => {
    event.preventDefault();

    if (this.validator.allValid()) {
      confirmAlert({
        customUI: ({ onClose }) => {
          const { classes } = this.props;
          return (
            <div className={classes.confirmDialog} >
              <h3>Are you sure you want to update?</h3>
              {/* <p>It will discard all your changes for current model</p> */}
              <Button className={classes.confirmDialogButton} variant="contained" onClick={onClose}>No</Button>

              <Button className={classes.confirmDialogButton} variant="contained"
                onClick={() => {


                  this.confirmUpdatePwo();
                  onClose();
                }}
              >
                Yes
                    </Button>
            </div>
          );
        }
      });
    }
    else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  }


  addNewSegment = () => { }


    
  goBack = () => {
    this.setState({
      isNewSegment: false, 
      editable: false,
       modified:false,
       employerContributionVo: { ...this.state.oldEmployerContributionVo }
      });
  }


  confirmUpdatePwo = () => {


  }
  render() {
    const { classes, loading } = this.props;


    let ButtonPanel = <MemberButton
      isNewSegment={this.state.isNewSegment}
      showAll={this.props.showAll}
      toggleLabel={this.state.showAllActive}
      newSegment={this.createNewSegment}
      modelSegment={this.modelSegment}
      modified={this.state.modified}
      editable={this.state.editable}
      delete={this.deletePwo}
      update={this.updatePWo}
    />
    return (


      <Paper elevation={0} className={classes.card} >
        {loading && <div id="cover-spin"></div>}
        {this.state.data ?
          <DataTable
            data={this.state.data}
            header={header}
            rowsPerPage={5}
            clicked={this.selectRow}
          />

          : null}
        <form autoComplete="off" >
          {ButtonPanel}
          <div className={classes.container}>
            <div>
              <InputField
                name='employerContibutionType'
                id="employerContibutionType"
                label="employerContibutionType"
                required
                value={this.state.employerContributionVo.employerContibutionType}
                onChange={this.handlechange("employerContibutionType")}
                disabled={true}
              />
              <div className={classes.validationMessage}>
              </div>
            </div>
            <div>
              <InputField
                name='effectiveDate'
                id="effectiveDate"
                onClick={this.handleStartDate('#effectiveDate')}
                label="Effevtive Start Date"
                required
                value={this.state.employerContributionVo.effectiveDate}
                onChange={this.handlechange("effectiveDate")}
                disabled={!this.state.editable}
              />
              <div className={classes.validationMessage}>
              </div>
            </div>
            <div>
              <InputField
                name='terminationDate'
                id="terminationDate"
                onClick={this.handleDates('#terminationDate')}
                label="Termination Date"
                required
                value={this.state.employerContributionVo.terminationDate}
                onChange={this.handlechange("terminationDate")}
                disabled={!this.state.editable}
              />
              <div className={classes.validationMessage}>
              </div>
            </div>
            <div>
              <InputField
                name='amount'
                id="amount"
                label="amount"
                required
                value={this.state.employerContributionVo.amount}
                onChange={this.handlechange("amount")}
                disabled={!this.state.editable}
              />
              <div className={classes.validationMessage}>
              </div>
            </div>

            <div>
              <InputField
                name='receivedDate'
                id="receivedDate"
                onClick={this.handleDates('#receivedDate')}
                label="Termination Date"
                required
                value={this.state.employerContributionVo.receivedDate}
                onChange={this.handlechange("receivedDate")}
                disabled={!this.state.editable}
              />
              <div className={classes.validationMessage}>
              </div>
            </div>




          </div>
        </form>


        <HistoryData
          isNewSegment={this.state.isNewSegment}
          reset={this.createNewSegment}
          addSegment={this.addNewSegment}
          back={this.goBack}
          classes={classes}
          createUserId={this.state.employerContributionVo.createUserId}
          createTime={this.state.employerContributionVo.createTime}
          lastUpdtTime={this.state.employerContributionVo.lastUpdtTime}
          lastUpdtUserId={this.state.employerContributionVo.lastUpdtUserId}
        />

      </Paper>
    );
  }
}


export default withStyles(Styles)(EmployerContribution);