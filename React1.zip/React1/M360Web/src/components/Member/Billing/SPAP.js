import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Paper from '@material-ui/core/Paper';
import $ from "jquery";
import { SPAP_TABLE_HEADER as header, SPAP_TABLE_DATA as DATA } from '../../../constants/Headers/MemberHeader';
import DataTable from '../../Home/DataTable';
import { confirmAlert } from 'react-confirm-alert';
import { Control } from '../../UI/Select';
import { Menu } from '../../UI/Select';
import { Select } from '../../UI/Select';
import { Option } from '../../UI/Select';
import { ValueContainer } from '../../UI/Select';
import { ADDRESS_TYPE_LIST } from '../../../constants/SelectStaticData';
import { Styles } from '../../../assets/styles/Theme';
import MemberButtonPanel from '../../UI/MemberButtonPanel';
import InputField from '../../UI/InputField';


const components = {
  Control,
  Menu,
  ValueContainer,
  Option,
};

class SPAP extends Component {
  state = {
    vo: {
      pwoType: '',
      pwoDesc: '',
      effectiveDate: '',
      termDate: '',
      overrideInd: '',
      planCode: '',
      createUserId: '',
      createTime: '',
      lastUpdtTime: '',
      lastUpdtUserId: '',
    },
    spapVo: DATA[0],
    oldSpapVo: DATA[0],

    data: DATA,
    modified: false,
    showAllActive: true,

    isNewSegment: false,
    editable: false
  }
  selectRow = (index) => {

    const data = [...this.state.data];
    const selectedVo = data[index];
    this.setState(() => ({
      spapVo:
      {
        ...selectedVo
      },
      oldSpapVo: {
        ...selectedVo
      },
      editable: false,
      isNewSegment: false,
      modified: false

    }))
  }

  handlechange = name => event => {
    let value = event.target.value;

    this.setState(prevState => ({
      spapVo:
      {
        ...prevState.spapVo,
        [name]: value
      },
      modified: true
    }))
  };

  handleStartDate = fieldId => {
    var self = this;
    $(fieldId).datepicker({
      showAnim: "clip",
      beforeShowDay: function (date) {
        if (date.getDate() === 1) {
          return [true, ''];
        }
        return [false, ''];
      }
    }
    ).on("change", e => {
      self.setDate(e.target.name, e.target.value)
    });

  }

  handleDates = fieldId => {
    var self = this;
    $(fieldId).datepicker({ showAnim: "clip"}).on("change", e => {
      self.setDate(e.target.name, e.target.value)
    });

  }
  setDate = (name, value) => {
    this.setState(prevState => ({
      spapVo:
      {
        ...prevState.spapVo,
        [name]: value
      },
      modified: true
    }))
  }

  handleChangeSearchSelect = name => event => {
    let value = event.value;
    this.setState(prevState => ({
      spapVo:
      {
        ...prevState.spapVo,
        [name]: value
      },
      modified: true
    }))

  };

  modelSegment = () => {
    this.setState({
      editable: true,
      isNewSegment: false
    });

  }

  createNewSegment = () => {
    this.setState({
      editable: true,
      isNewSegment: true,
      spapVo: {
        ...this.state.vo

      }
    });
  }

  updatePwo = (event) => {
    event.preventDefault();

    if (this.validator.allValid()) {
      confirmAlert({
        customUI: ({ onClose }) => {
          const { classes } = this.props;
          return (
            <div className={classes.confirmDialog} >
              <h3>Are you sure you want to update?</h3>
              {/* <p>It will discard all your changes for current model</p> */}
              <Button className={classes.confirmDialogButton} variant="contained" onClick={onClose}>No</Button>

              <Button className={classes.confirmDialogButton} variant="contained"
                onClick={() => {


                  this.confirmUpdateAddress()
                  onClose();
                }}
              >
                Yes
                    </Button>
            </div>
          );
        }
      });
    }
    else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  }




  confirmUpdatePwo = () => {

  }
  render() {
    const { classes, showAllActive, loading } = this.props;


    let ButtonPanel = <MemberButtonPanel
      isNewSegment={this.state.isNewSegment}
      showAll={this.props.showAll}
      toggleLabel={this.state.showAllActive}
      newSegment={this.createNewSegment}
      modelSegment={this.modelSegment}
      modified={this.state.modified}
      editable={this.state.editable}
      delete={this.deletePwo}
      update={this.updatePWo}
    />

    return (


      <Paper elevation={0} className={classes.card} >
          {this.state.data ?
          <DataTable
            data={this.state.data}
            header={header}
            rowsPerPage={5}
            clicked={this.selectRow}
          />

          : null}
        <form autoComplete="off" >
          {ButtonPanel}
          <div className={classes.container}>
            <div>
              <InputField
                name='effectiveFrom'
                id="effectiveFrom"
                onClick={this.handleStartDate('#effectiveFrom')}
                label="Effective From"
                required
                value={this.state.spapVo.effectiveFrom}
                onChange={this.handlechange("effectiveFrom")}
                disabled={!this.state.editable}
              />
              <div className={classes.validationMessage}>
              </div>
            </div>

            <div>
              <InputField
                name='effectiveTo'
                id="effectiveTo"
                onClick={this.handleDates('#effectiveTo')}
                label="Effective To"
                required
                value={this.state.spapVo.effectiveTo}
                onChange={this.handlechange("effectiveTo")}
                disabled={!this.state.editable}
              />
              <div className={classes.validationMessage}>
              </div>
            </div>

            <div>
              <InputField
                name='spapId'
                id="spapId"
                label="Spap Id"
                required
                value={this.state.spapVo.spapId}
                onChange={this.handlechange("spapId")}
                disabled={!this.state.editable}
              />
              <div className={classes.validationMessage}>
              </div>
            </div>

            <div>
              <InputField
                name='spapType'
                id="spapType"
                label="SPAP Type"
                required
                value={this.state.spapVo.spapType}
                margin="normal"
                onChange={this.handlechange("spapType")}
                disabled={!this.state.editable}
              />
              <div className={classes.validationMessage}>
              </div>
            </div>
            <div>
              <Select

                components={components}
                propertyName={ADDRESS_TYPE_LIST.filter(option => option.value === this.state.spapVo.spapState)}
                options={ADDRESS_TYPE_LIST}
                label="Choose SPAP State ..."
                textFieldProps={{
                  label: 'SPAP State',
                  InputLabelProps: {
                    className: classes.label,
                    shrink: true,
                  },
                }}
                className={classes.textFieldSelect}
                handleChange={this.handleChangeSearchSelect('spapState')}
                isDisabled={!this.state.editable}
                classes={classes}

              />
              <div className={classes.validationMessageSelect}>
              </div></div>
          </div>
        </form>

      </Paper>
    );
  }
}

export default withStyles(Styles)(SPAP);