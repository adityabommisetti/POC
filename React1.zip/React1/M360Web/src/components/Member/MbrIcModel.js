import * as DateUtil from '../../utils/DatePicker';

import React, { Component } from "react";
import { Select, components } from "../UI/Select";

import { ADDRESS_TYPE_LIST } from "../../constants/SelectStaticData";
import Button from "@material-ui/core/Button";
import { COB_TABLE_DATA as DATA } from "../../constants/staticData/MemberStaticData";
import DataTable from "../Home/DataTable";
import Fade from "@material-ui/core/Fade";
import HistoryData from "../UI/MemberHistory";
import Paper from "@material-ui/core/Paper";
import { Styles } from "../../assets/styles/Theme";
import TextField from "@material-ui/core/TextField";
import { confirmAlert } from "react-confirm-alert";
import { COB_TABLE_HEADER as header } from "../../constants/Headers/MemberHeaders";
import { withStyles } from "@material-ui/core/styles";

class IcModel extends Component {
  state = {
    vo: {
      pwoType: "",
      pwoDesc: "",
      effectiveDate: "",
      termDate: "",
      overrideInd: "",
      planCode: "",
      createUserId: "",
      createTime: "",
      lastUpdtTime: "",
      lastUpdtUserId: ""
    },
    icModelVo: [],
    data: DATA,
    modified: false,
    newSegment: false,
    editable: false
  };
  selectRow = index => {
    const data = [...this.state.data];
    const selectedVo = data[index];
    this.setState(() => ({
      icModelVo: {
        ...selectedVo
      }
    }));
  };

  handlechange = name => event => {
    let value = event.target.value.toUpperCase();

    this.setState(prevState => ({
      icModelVo: {
        ...prevState.icModelVo,
        [name]: value
      },

      modified: true
    }));
  };

  handleOnBlur = event => {
    let value = event.target.value.trim();
    let name = event.target.name;

    this.setState(prevState => ({
      icModelVo: {
        ...prevState.icModelVo,
        [name]: value
      },

      modified: true
    }));
  };

  handleStartDate = fieldId => {
    var self = this;
    DateUtil.getStartDatePicker(fieldId)
      .on("change", e => {
        self.setDate(e.target.name, e.target.value);
      });
  };

  handleDates = fieldId => {
    var self = this;
    DateUtil.getDatePicker(fieldId)
      .on("change", e => {
        self.setDate(e.target.name, e.target.value);
      });
  };

  setDate = (name, value) => {
    this.setState(prevState => ({
      icModelVo: {
        ...prevState.icModelVo,
        [name]: value
      },
      modified: true
    }));
  };

  handleChangeSearchSelect = name => event => {
    let value = event.value;
    this.setState(prevState => ({
      icModelVo: {
        ...prevState.icModelVo,
        [name]: value
      },
      modified: true
    }));
  };

  modelSegment = () => {
    this.setState({
      editable: true,
      newSegment: false
    });
  };

  createNewSegment = () => {
    this.setState({
      editable: true,
      newSegment: true,
      icModelVo: {
        ...this.state.vo
      }
    });
  };

  updatePwo = event => {
    event.preventDefault();

    if (this.validator.allValid()) {
      confirmAlert({
        customUI: ({ onClose }) => {
          const { classes } = this.props;
          return (
            <div className={classes.confirmDialog}>
              <h3>Are you sure you want to update?</h3>
              {/* <p>It will discard all your changes for current model</p> */}
              <Button
                className={classes.confirmDialogButton}
                variant="contained"
                onClick={onClose}
              >
                No
              </Button>

              <Button
                className={classes.confirmDialogButton}
                variant="contained"
                onClick={() => {
                  this.confirmUpdateAddress();
                  onClose();
                }}
              >
                Yes
              </Button>
            </div>
          );
        }
      });
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  confirmUpdatePwo = () => { };
  render() {
    const { classes, showAllActive, loading } = this.props;
    let buttonContainer = (
      <Fade in={!this.state.newSegment}>
        <div className={classes.buttonContainer}>
          <Button
            variant="contained"
            color="primary"
            onClick={this.props.showAll}
            className={classes.button}
          >
            {showAllActive ? "Show Active" : "Show All"}
          </Button>

          <Button
            variant="contained"
            color="primary"
            onClick={this.createNewSegment}
            className={classes.button}
          >
            New
          </Button>
          <Button
            variant="contained"
            color="primary"
            onClick={this.modelSegment}
            className={classes.button}
          >
            Model Segment
          </Button>
          <Button
            variant="contained"
            color="primary"
            onClick={this.deletePwo}
            className={classes.button}
            disabled={this.state.editable}
          >
            Delete
          </Button>

          <Button
            type="submit"
            variant="contained"
            color="primary"
            onClick={this.updatePwo}
            disabled={!this.state.modified}
            className={classes.button}
          >
            Update
          </Button>
        </div>
      </Fade>
    );

    return (
      <Paper elevation={0} className={classes.card}>
        {loading && <div id="cover-spin" />}
        {this.state.data ? (
          <DataTable
            data={this.state.data}
            header={header}
            rowsPerPage={5}
            clicked={this.selectRow}
          />
        ) : null}
        <form autoComplete="off">
          {buttonContainer}
          <div className={classes.container}>

            <div>
              <TextField
                name="startDate"
                id="startDate"
                type="text"
                onClick={this.handleStartDate("#startDate")}
                InputProps={{ className: classes.textFont }}
                label="Start Date"
                required
                inputclassname={classes.textFont}
                className={classes.textField}
                value={this.state.icModelVo.startDate}
                InputLabelProps={{ className: classes.label, shrink: true }}
                margin="normal"
                onChange={this.handlechange("startDate")}
                disabled={!this.state.editable}
                onBlur={this.handleOnBlur}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <TextField
                name="endDate"
                id="endDate"
                type="text"
                onClick={this.handleDates("#endDate")}
                InputProps={{ className: classes.textFont }}
                label="End Date"
                required
                inputclassname={classes.textFont}
                className={classes.textField}
                value={this.state.icModelVo.endDate}
                InputLabelProps={{ className: classes.label, shrink: true }}
                margin="normal"
                onChange={this.handlechange("endDate")}
                onBlur={this.handleOnBlur}
                disabled={!this.state.editable}
              />
              <div className={classes.validationMessage} >
              </div>
            </div>
            <div>
              <TextField
                name="planCode"
                id="planCode"
                type="text"
                InputProps={{ className: classes.textFont }}
                label="Plan Code"
                required
                inputclassname={classes.textFont}
                className={classes.textField}
                value={this.state.icModelVo.planCode}
                InputLabelProps={{ className: classes.label, shrink: true }}
                margin="normal"
                onChange={this.handlechange("planCode")}
                onBlur={this.handleOnBlur}
                disabled={!this.state.editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <Select
                components={components}
                propertyName={ADDRESS_TYPE_LIST.filter(
                  option => option.value === this.state.icModelVo.modelType
                )}
                options={ADDRESS_TYPE_LIST}
                label="Choose IC Model Type ..."
                textFieldProps={{
                  label: "IC Model Type",
                  InputLabelProps: {
                    className: classes.label,
                    shrink: true
                  }
                }}
                className={classes.textFieldSelect}
                handleChange={this.handleChangeSearchSelect("modelType")}
                isDisabled={!this.state.editable}
                classes={classes}
              />

              <div className={classes.validationMessageSelect} />
            </div>
            <div>
              <Select
                components={components}
                propertyName={ADDRESS_TYPE_LIST.filter(
                  option => option.value === this.state.icModelVo.udFlag
                )}
                options={ADDRESS_TYPE_LIST}
                label="Choose IC Model UD Flag ..."
                textFieldProps={{
                  label: "IC Model UD Flag",
                  InputLabelProps: {
                    className: classes.label,
                    shrink: true
                  }
                }}
                className={classes.textFieldSelect}
                handleChange={this.handleChangeSearchSelect("udFlag")}
                isDisabled={!this.state.editable}
                classes={classes}
              />

              <div className={classes.validationMessageSelect} />
            </div>
            <div>
              <Select
                components={components}
                propertyName={ADDRESS_TYPE_LIST.filter(
                  option => option.value === this.state.icModelVo.modelType
                )}
                options={ADDRESS_TYPE_LIST}
                label="Choose Benefit St Cd ..."
                textFieldProps={{
                  label: "IC Model Benefit St Cd",
                  InputLabelProps: {
                    className: classes.label,
                    shrink: true
                  }
                }}
                className={classes.textFieldSelect}
                handleChange={this.handleChangeSearchSelect("modelType")}
                isDisabled={!this.state.editable}
                classes={classes}
              />

              <div className={classes.validationMessageSelect} />
            </div>
            <div>
              <TextField
                name="plan"
                id="plan"
                type="text"
                onClick={this.handleStartDate("#plan")}
                InputProps={{ className: classes.textFont }}
                label="Plan"
                required
                inputclassname={classes.textFont}
                className={classes.textField}
                value={this.state.icModelVo.plan}
                InputLabelProps={{ className: classes.label, shrink: true }}
                margin="normal"
                onChange={this.handlechange("plan")}
                disabled={!this.state.editable}
                onBlur={this.handleOnBlur}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <TextField
                name="pbp"
                id="pbp"
                type="text"
                onClick={this.handleStartDate("#pbp")}
                InputProps={{ className: classes.textFont }}
                label="PBP"
                required
                inputclassname={classes.textFont}
                className={classes.textField}
                value={this.state.icModelVo.pbp}
                InputLabelProps={{ className: classes.label, shrink: true }}
                margin="normal"
                onChange={this.handlechange("pbp")}
                onBlur={this.handleOnBlur}
                disabled={!this.state.editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <TextField
                name="groupId"
                id="groupId"
                type="text"
                onClick={this.handleStartDate("#groupId")}
                InputProps={{ className: classes.textFont }}
                label="Group"
                required
                inputclassname={classes.textFont}
                className={classes.textField}
                value={this.state.icModelVo.groupId}
                InputLabelProps={{ className: classes.label, shrink: true }}
                margin="normal"
                onChange={this.handlechange("groupId")}
                onBlur={this.handleOnBlur}
                disabled={!this.state.editable}
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <TextField
                name="medicareId"
                id="medicareId"
                type="text"
                onClick={this.handleStartDate("#medicareId")}
                InputProps={{ className: classes.textFont }}
                label="Medicare ID"
                required
                inputclassname={classes.textFont}
                className={classes.textField}
                value={this.state.icModelVo.medicareId}
                InputLabelProps={{ className: classes.label, shrink: true }}
                margin="normal"
                onChange={this.handlechange("medicareId")}
                onBlur={this.handleOnBlur}
                disabled
              />
              <div className={classes.validationMessage} />
            </div>
            <div>
              <Select
                components={components}
                propertyName={ADDRESS_TYPE_LIST.filter(
                  option => option.value === this.state.icModelVo.endDateReasonCode
                )}
                options={ADDRESS_TYPE_LIST}
                label="Choose End Dt Reason Cd ..."
                textFieldProps={{
                  label: "IC Model End Dt Reason Cd",
                  InputLabelProps: {
                    className: classes.label,
                    shrink: true
                  }
                }}
                className={classes.textFieldSelect}
                handleChange={this.handleChangeSearchSelect("endDateReasonCode")}
                isDisabled={!this.state.editable}
                classes={classes}
              />

              <div className={classes.validationMessageSelect} />
            </div>
            <div>
              <TextField
                name="enrollStatus"
                id="enrollStatus"
                type="text"
                onClick={this.handleStartDate("#enrollStatus")}
                InputProps={{ className: classes.textFont }}
                label="IC Enroll Status"
                required
                inputclassname={classes.textFont}
                className={classes.textField}
                value={this.state.icModelVo.enrollStatus}
                InputLabelProps={{ className: classes.label, shrink: true }}
                margin="normal"
                onChange={this.handlechange("enrollStatus")}
                onBlur={this.handleOnBlur}
                disabled={!this.state.editable}
              />
              <div className={classes.validationMessage} />
            </div>
          </div>
        </form>
        <HistoryData
          createUserId={this.state.icModelVo.createUserId}
          createTime={this.state.icModelVo.createTime}
          lastUpdtTime={this.state.icModelVo.lastUpdtTime}
          lastUpdtUserId={this.state.icModelVo.lastUpdtUserId}
        />
      </Paper>
    );
  }
}

export default withStyles(Styles)(IcModel);
