import * as DateUtil from "../../utils/DatePicker";
import * as Type from "../../constants/ConfirmType";
import * as ActionTypes from "../../redux/types/ActionType";
import React, { Component } from "react";
import Autocomplete1 from "../UI/Select";
import {
  deleteCob,
  getCobData,
  getShowAll,
  updateCob,
  updateIndcobData,
} from "../../redux/actions/MemberActions";

import ConfirmBox from "../../utils/PopUp";
import DataTable from "../Home/DataTable";
import HistoryData from "../UI/MemberHistory";
import InputField from "../UI/InputField";
import MemberButtonPanel from "../UI/MemberButtonPanel";
import Modal from "../../components/UI/Modal/Modal";
import Paper from "@material-ui/core/Paper";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../assets/styles/Theme";
import classNames from "classnames";
import { connect } from "react-redux";
import { customValidations } from "../../utils/CustomValidations";
import { COB_TABLE_HEADER as header } from "../../constants/Headers/MemberHeaders";
import isEmpty from "lodash/isEmpty";
import { messages } from "../../constants/Messages";
import { withStyles } from "@material-ui/core/styles";
import { handleDateChange } from "../../utils/DateFormatter";

const INITIAL_STATE = {
  customerId: "",
  memberId: "",
  cobType: "",
  cobDesc: "",
  ohiInd: "",
  ohiDesc: "",
  rxGrp: "",
  rxName: "",
  rxId: "",
  rxBin: "",
  rxPcn: "",
  overrideInd: "N",
  effStartDate: "",
  effEndDate: "99999999",
  createTime: "",
  createUserId: "",
  lastUpdtTime: "",
  lastUpdtUserId: "",
  lstOhiInd: null,
  listCobs: null,
  cobValidation: null,
  type: "",
  effStartDateFrmt: "",
  effEndDateFrmt: "99/99/9999",
  showAll: "",
};
const SELECT_OBJECT = {
  label: "Select",
  value: "",
};

class COB extends Component {
  constructor(props) {
    super(props);
    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
        date_format99: customValidations.date_format99,
        last_day_of_month: customValidations.last_day_of_month99,
        date_after99: customValidations.c_after99,
        date_after: customValidations.c_after,
      },
    });
    this.state = {
      cobVo: INITIAL_STATE,
      showAllData: null,
      cobList: [],
      modified: false,
      isNewSegment: false,
      editable: false,
      //showAllActive: true,
      selectedIndex: 0,
      closePopup: false,
      memberId: this.props.mbrSearchCriteria.memberId,
      oldmemberId: INITIAL_STATE.memberId,
      rowsPerPage: 10,
      func1: this.showAll.bind(this),
      showAllActiveInd: this.props.showAllActiveInd,
    };
  }

  handleChangePage = (index) => {
    this.setState({ selectedIndex: index });
    const selectedVo = this.state.cobList[index];
    let ohiDropDown = [SELECT_OBJECT, ...this.getOHILIst(selectedVo.cobType)];
    this.setState(() => ({
      ohiDropDown: ohiDropDown,
      cobVo: selectedVo,
      editable: false, // readOnly
      isNewSegment: false, //Not a new SEgment
      modified: false,
      selectedIndex: index,
    }));
  };

  handlechange = (event) => {
    let value = event.target.value.toUpperCase();
    let name = event.target.name;
    if (name === "rxBin" && value.length > 6) {
      return;
    } else if (name === "rxPcn" && value.length > 10) {
      return;
    } else if (name === "rxId" && value.length > 20) {
      return;
    } else if (name === "rxName" && value.length > 50) {
      return;
    }
    this.setState((prevState) => ({
      cobVo: {
        ...prevState.cobVo,
        [name]: value,
      },
      modified: true, // enable update button
    }));
  };

  handleOnBlur = (event) => {
    let value = event.target.value.trim();
    let name = event.target.name;

    this.setState((prevState) => ({
      cobVo: {
        ...prevState.cobVo,
        [name]: value,
      },
      modified: true, // enable update button
    }));
  };

  handleStartDate = (event) => {
    const fieldId = "#" + event.target.name;
    var self = this;
    DateUtil.getStartDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        self.setDate(e.target.name, e.target.value);
      });
  };

  handleDate = (event) => {
    let value = event.target.value;
    let name = event.target.name;
    this.setState((prevState) => ({
      cobVo: {
        ...prevState.cobVo,
        [name]: handleDateChange(value),
      },
      modified: true,
    }));
  };

  handleDates = (event) => {
    let fieldId = "#" + event.target.name;

    var self = this;
    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        self.setDate(e.target.name, e.target.value);
      });
  };

  setDate = (name, value) => {
    this.setState((prevState) => ({
      cobVo: {
        ...prevState.cobVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleChangeSearchSelectAuto = async (data, name) => {
    let value = data.value;
    if (name === "cobType") {
      let ohiDropDown = [SELECT_OBJECT, ...this.getOHILIst(value)];

      this.setState((prevState) => ({
        cobVo: {
          ...prevState.cobVo,
          cobType: value,
        },
        ohiDropDown: ohiDropDown,
      }));
    }

    this.setState((prevState) => ({
      cobVo: {
        ...prevState.cobVo,
        [name]: value,
      },
      modified: true,
    }));
  };
  handleChangeSearchSelect = (name) => (event) => {
    let value = event.value;

    if (name === "cobType") {
      let ohiDropDown = [SELECT_OBJECT, ...this.getOHILIst(value)];

      this.setState((prevState) => ({
        cobVo: {
          ...prevState.cobVo,
          cobType: value,
        },
        ohiDropDown: ohiDropDown,
      }));
    }

    this.setState((prevState) => ({
      cobVo: {
        ...prevState.cobVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  async componentDidMount() {
    if (this.props.showAllActiveInd.showAllActiveInd === false) {
      this.showAll(true, this.props.mbrSearchCriteria.memberId);
    } else if (isEmpty(this.props.cobData) && this.props.cobData !== null) {
      const params = this.props.mbrSearchCriteria.memberId + "/N";
      await this.props.getCobData(params);
      INITIAL_STATE.memberId = this.props.mbrSearchCriteria.memberId;
    }

    if (!isEmpty(this.props.cobData)) {
      let cobVO = this.props.cobData[0];
      let ohiDropDown = [SELECT_OBJECT, ...this.getOHILIst(cobVO.cobType)];
       this.setState({
        cobVo: cobVO,
        cobList: this.props.cobData,
        ohiDropDown: ohiDropDown,
      });
    }
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.mbrSearchCriteria.memberId !== prevState.memberId) {
      if (!isEmpty(nextProps.cobData)) {
        let cobVO = nextProps.cobData[0];

        let ohiDropDown = cobVO.cobType
          ? [SELECT_OBJECT, ...nextProps.dropdowns.validOhiInd[cobVO.cobType].item]
          : [];
        return {
          cobVo: cobVO,
          cobList: nextProps.cobData,
          showAllData: null,
          //showAllActive: true,
          modified: false,
          isNewSegment: false,
          editable: false,
          selectedIndex: 0,
          memberId: nextProps.mbrSearchCriteria.memberId,
          ohiDropDown: ohiDropDown,
          model: prevState.func1(
            nextProps.showAllActiveInd.showAllActiveInd === false ? true : "N",
            nextProps.mbrSearchCriteria.memberId
          ),
        };
      }
      return {
        cobVo: INITIAL_STATE,
        cobList: [],
        showAllData: null,
        //showAllActive: true,
        modified: false,
        isNewSegment: false,
        editable: false,
        selectedIndex: 0,
        memberId: nextProps.mbrSearchCriteria.memberId,
        model: prevState.func1(
          nextProps.showAllActiveInd.showAllActiveInd === false ? true : "N",
          nextProps.mbrSearchCriteria.memberId
        ),
      };
    }
    if (
      nextProps.showAllActiveInd.showAllActiveInd !== prevState.showAllActiveInd
    ) {
      if (nextProps.showAllActiveInd.showAllActiveInd === false) {
        return {
          model: prevState.func1(true, nextProps.mbrSearchCriteria.memberId),
        };
      } else {
        return {
          model: prevState.func1(false, nextProps.mbrSearchCriteria.memberId),
        };
      }
    }
    return null;
  }

  selectRow = async (index) => {
    const selectedVo = this.state.cobList[index];
    let ohiDropDown = [SELECT_OBJECT, ...this.getOHILIst(selectedVo.cobType)];

    this.setState(() => ({
      ohiDropDown: ohiDropDown,
      cobVo: selectedVo,
      editable: false, // readOnly
      isNewSegment: false, //Not a new SEgment
      modified: false,
      selectedIndex: index,
    }));
  };

  modelSegment = () => {
    if (this.state.cobVo.overrideInd === "Y") {
      let msg = "This Record is not active ";
      this.setState({ message: msg, closePopup: true });
    } else {
      this.setState({
        editable: true, // Editable
        isNewSegment: false, // Not a new Segment
      });
    }
  };

  createNewSegment = () => {
    this.validator.hideMessages();
    this.setState({
      editable: true,
      isNewSegment: true,
      cobVo: {
        ...INITIAL_STATE,
        memberId: this.props.mbrSearchCriteria.memberId,
      },
    });
  };

  update = (event) => {
    event.preventDefault();
    if (!this.validator.allValid()) {
      this.validator.showMessages();
      this.forceUpdate();
      return;
    }
    ConfirmBox(this.confirmUpdate, Type.UPDATE, this.props);
  };

  getOHILIst = (cobType) => {
    return cobType
      ? this.props.dropdowns.validOhiInd[cobType] &&
      this.props.dropdowns.validOhiInd[cobType].item
      : [];
  };

  confirmUpdate = async () => {
    const { cobVo } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(cobVo.showAll = val),
    });
    let payload = {
      ...this.state.cobVo,
      memberId: this.props.mbrSearchCriteria.memberId,
    };
    let status = await this.props.updateCob(payload);
    if ("success" === status) {
      status = messages.UPDATED_SUCCESSFULLY;
      this.setState(() => ({
        message: status,
        isNewSegment: false,
        editable: false,
        modified: false,
        cobList: this.props.cobData,
        showAllData: null,
        closePopup: true,
      }));
    } else {
      this.setState(() => ({
        message: status,
        closePopup: true,
      }));
    }
  };

  addNewSegment = () => {
    if (this.validator.allValid()) {
      ConfirmBox(this.confirmAddNewSegment, Type.ADD, this.props);
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  confirmAddNewSegment = async () => {
    const { cobVo } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(cobVo.showAll = val),
    });

    let payload = {
      ...this.state.cobVo,
      memberId: this.props.mbrSearchCriteria.memberId,
    };
    let status = await this.props.updateCob(payload);
    //let newVO = this.props.cobData[0];
    if ("success" === status) {
      status = messages.INSERTED_SUCCESSFULLY;

      this.setState((prevState) => ({
        ...prevState,
        isNewSegment: false,
        editable: false,
        modified: false,
        showAllData: null,
        cobVo: this.props.cobData[0],
        cobList: this.props.cobData,
        closePopup: true,
        message: status,
        selectedIndex: 0,
      }));
    } else {
      this.setState({
        closePopup: true,
        message: status,
      });
    }
  };

  delete = () => {
    if (this.state.cobVo.overrideInd === "Y") {
      let msg = "This Record is not active ";
      this.setState({ message: msg, closePopup: true });
    } else {
      ConfirmBox(this.confirmDelete, Type.DELETE, this.props);
    }
  };

  confirmDelete = async () => {
    const { cobVo } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(cobVo.showAll = val),
    });

    let payload = {
      ...cobVo,
      memberId: this.props.mbrSearchCriteria.memberId,
    };
    let status = await this.props.deleteCob(payload);
    let newVO = isEmpty(this.props.cobData)
      ? INITIAL_STATE
      : this.props.cobData[0];
    let message = "";
    if (status === "success") {
      message = ActionTypes.DELETE;
    } else {
      message = status;
    }

    this.setState({
      cobVo: newVO,
      cobList: this.props.cobData,
      showAllData: null,
      closePopup: true,
      message: message,
      selectedIndex: 0,
      isNewSegment: false,
      editable: false,
      modified: false,
    });
    this.validator.hideMessages();
  };

  goBack = () => {
    const index = this.state.selectedIndex;
    const { cobData } = this.props;
    let cobVO = INITIAL_STATE;

    if (!isEmpty(cobData)) {
      cobVO = cobData[index];
    }

    this.setState({
      isNewSegment: false,
      editable: false,
      modified: false,
      cobVo: cobVO,
    });
    this.validator.hideMessages();
  };

  showAll = async (flag, mbrId) => {
    const { showAllData } = this.state;

    const memberId = mbrId;

    if (flag === true) {
      if (showAllData === null) {
        const data = await this.props.getShowAll({
          memberId: memberId + "/Y",
          url: "MEMBER_COB_FETCH",
        });
        if (null != data) {
          const selectedVO = data.length > 0 ? data[0] : { ...INITIAL_STATE };
          this.setState(() => ({
            cobList: data,
            cobVo: selectedVO,
            showAllData: data,
            showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
            selectedIndex: 0,
            editable: false,
            isNewSegment: false,
          }));
        }
      } else {
        const selectedVO = !isEmpty(showAllData)
          ? showAllData[0]
          : { ...INITIAL_STATE };

        this.setState(() => ({
          cobList: showAllData,
          cobVo: selectedVO,
          showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
          selectedIndex: 0,
          editable: false,
          isNewSegment: false,
        }));
      }
    } else {
      if (flag === "N") {
        const params = memberId + "/N";
        await this.props.getCobData(params);
      } else {
        let recodN = await (this.state.cobList === null
          ? []
          : this.state.cobList.filter((role) => role.overrideInd === "N"));

        await this.props.updateIndcobData(recodN);
      }
      const { cobData } = this.props;
      const selectedVO = !isEmpty(cobData) ? cobData[0] : { ...INITIAL_STATE };
      this.setState(() => ({
        cobList: cobData,
        cobVo: selectedVO,
        showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
        selectedIndex: 0,
        editable: false,
        isNewSegment: false,
      }));
    }
  };

  modalClosed = () => {
    this.setState({ closePopup: false });
  };
  handleChangeRowsPerPage = async (rowsPerPage) => {
    await this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  render() {
    const { classes, dropdowns } = this.props;
    const {
      isNewSegment,
      ohiDropDown,
      cobVo,
      cobList,
      editable,
      modified,
      message,
      closePopup,
      selectedIndex,
    } = this.state;

    let ButtonPanel = (
      <MemberButtonPanel
        isNewSegment={isNewSegment}
        //showAll={this.showAll}
        //toggleLabel={showAllActive}
        newSegment={this.createNewSegment}
        modelSegment={this.modelSegment}
        modified={modified}
        editable={editable}
        delete={this.delete}
        update={this.update}
        disable={isEmpty(cobList)}
      />
    );
    return (
      <React.Fragment>
        <Modal
          dialogTitle="COB"
          message={message}
          show={closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>

        <Paper
          elevation={0}
          className={classNames(classes.card, "animated fadeIn")}
        >
          <DataTable
            data={cobList ? cobList : []}
            header={header}
            sortable={true}
            rowsPerPageOptions={[10, 15, 20]}
            handleChangeRowsPerPage={this.handleChangeRowsPerPage}
            rowsPerPage={this.state.rowsPerPage}
            clicked={this.selectRow}
            index={selectedIndex}
            handleChangePage={this.handleChangePage}
            dateColumn={["effStartDateFrmt", "effEndDateFrmt"]}
            subtab
          />

          {(!isEmpty(cobList) && this.state.cobVo) || isNewSegment ? (
            <React.Fragment>
              <form autoComplete="off">
                <div>
                  <div className={classes.buttonContainer}>{ButtonPanel}</div>

                  <div className="panel-body margin-top1">
                    <div className={classes.container}>
                      <div className={classes.Select2}>
                        <Autocomplete1
                          handleChange={this.handleChangeSearchSelectAuto}
                          label="COB Type"
                          options={dropdowns.validCobTypes}
                          defaultValue={dropdowns.validCobTypes[0]}
                          value={
                            dropdowns.validCobTypes.filter(
                              (data) => data.value === cobVo.cobType
                            )[0]
                          }
                          name="cobType"
                          disabled={!this.state.editable}
                          width="180px"
                          margin="0px"
                        />
                        <div className={classes.validationMessageSelect}>
                          {this.validator.message(
                            "CobType",
                            cobVo.cobType.trim(),
                            "required"
                          )}
                        </div>
                      </div>

                      <div>
                        <InputField
                          name="effStartDateFrmt"
                          placeholder="MM/DD/YYYY"
                          required={this.state.editable}
                          onClick={this.handleStartDate}
                          label="Start Date"
                          value={cobVo.effStartDateFrmt}
                          onChange={this.handleDate}
                          onBlur={this.handleOnBlur}
                          disabled={!this.state.editable}
                        />
                        <div className={classes.validationMessage}>
                          {this.validator.message(
                            "StartDate",
                            cobVo.effStartDateFrmt,
                            "required|date_format"
                          )}
                          {cobVo.cobType === "2"
                            ? this.validator.message(
                              "StartDate",
                              cobVo.effStartDateFrmt,
                              [
                                {
                                  date_after: this.props.enrollData[0]
                                    .effStartDateFrmt,
                                },
                              ]
                            )
                            : null}
                        </div>
                      </div>
                      <div>
                        <InputField
                          name="effEndDateFrmt"
                          placeholder="MM/DD/YYYY"
                          onClick={this.handleDates}
                          label="End Date"
                          value={cobVo.effEndDateFrmt}
                          onChange={this.handleDate}
                          onBlur={this.handleOnBlur}
                          maxLength={50}
                          disabled={!this.state.editable}
                          required={this.state.editable}
                        />

                        <div className={classes.validationMessage}>
                          {this.validator.message(
                            "EndDate",

                            cobVo.effEndDateFrmt,
                            [
                              "required",
                              "date_format99",
                              "last_day_of_month",
                              { date_after99: cobVo.effStartDateFrmt },
                            ]
                          )}
                        </div>
                      </div>
                      <div>
                        <InputField
                          name="overrideInd"
                          label="Override"
                          value={cobVo.overrideInd}
                          onChange={this.handlechange}
                          onBlur={this.handleOnBlur}
                          disabled={true}
                        />
                        <div className={classes.validationMessage}></div>
                      </div>
                      <div className={classes.Select1}>
                        {ohiDropDown ? (
                          <Autocomplete1
                            handleChange={this.handleChangeSearchSelectAuto}
                            label="OHI"
                            options={ohiDropDown}
                            defaultValue={ohiDropDown[0]}
                            value={
                              ohiDropDown.filter(
                                (data) => data.value === cobVo.ohiInd
                              )[0]
                            }
                            name="ohiInd"
                            disabled={!this.state.editable}
                            width="390px"
                            margin="0px"
                          />
                        ) : (
                            ""
                          )}
                        <div className={classes.validationMessageSelect}>
                          {this.validator.message(
                            "Ohi",
                            cobVo.ohiInd,
                            "required"
                          )}
                        </div>
                      </div>

                      <div>
                        <InputField
                          name="rxGrp"
                          label="RX Group"
                          value={cobVo.rxGrp}
                          onChange={this.handlechange}
                          onBlur={this.handleOnBlur}
                          maxLength={20}
                          disabled={!this.state.editable}
                        />
                        <div className={classes.validationMessage}>
                          {this.validator.message(
                            "rxGrp",
                            cobVo.rxGrp,
                            "required"
                          )}
                        </div>
                      </div>
                      <div>
                        <InputField
                          name="rxName"
                          label="RX Name"
                          required={this.state.editable}
                          value={cobVo.rxName}
                          onChange={this.handlechange}
                          onBlur={this.handleOnBlur}
                          maxLength={50}
                          disabled={!this.state.editable}
                        />
                        <div className={classes.validationMessage}>
                          {this.validator.message(
                            "rxName",
                            cobVo.rxName,
                            "required"
                          )}
                        </div>
                      </div>

                      <div>
                        <InputField
                          name="rxId"
                          label="RX Id"
                          value={cobVo.rxId}
                          onChange={this.handlechange}
                          onBlur={this.handleOnBlur}
                          maxLength={20}
                          disabled={!this.state.editable}
                          required={this.state.editable}
                        />
                        <div className={classes.validationMessage}>
                          {this.validator.message(
                            "rxId",
                            cobVo.rxId,
                            "required"
                          )}
                        </div>
                      </div>

                      <div className={classes.input1}>
                        <InputField
                          name="rxBin"
                          label="RX Bin"
                          value={cobVo.rxBin}
                          width="180px"
                          onChange={this.handlechange}
                          onBlur={this.handleOnBlur}
                          maxLength={6}
                          disabled={!this.state.editable}
                          required={this.state.editable}
                        />
                        <div className={classes.validationMessage}>
                          {this.validator.message(
                            "rxBin",
                            cobVo.rxBin,
                            "required"
                          )}
                        </div>
                      </div>

                      <div>
                        <InputField
                          name="rxPcn"
                          label="RX PCN"
                          value={cobVo.rxPcn}
                          onChange={this.handlechange}
                          onBlur={this.handleOnBlur}
                          maxLength={10}
                          disabled={!this.state.editable}
                          required={this.state.editable}
                        />
                        <div className={classes.validationMessage}>
                          {this.validator.message(
                            "rxPcn",
                            cobVo.rxPcn,
                            "required"
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
              <HistoryData
                createTime={cobVo.createTime}
                createUserId={cobVo.createUserId}
                lastUpdtTime={cobVo.lastUpdtTime}
                lastUpdtUserId={cobVo.lastUpdtUserId}
                isNewSegment={isNewSegment}
                reset={this.createNewSegment}
                addSegment={this.addNewSegment}
                back={this.goBack}
                footer="true"
              />
            </React.Fragment>
          ) : (
              <div className={classes.buttonContainer}> {ButtonPanel}</div>
            )}
        </Paper>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  cobData: state.memberSearch.searchResultsVo.mbrCobVOList,
  enrollData: state.memberSearch.searchResultsVo.mbrEnrollmentList,
  dropdowns: state.membercache,
  searchResultsVo: state.memberSearch.searchResultsVo,
  mbrSearchCriteria: state.memberSearch.mbrSearchCriteria,
  memberIdCheck: state.memberSearch.memberId,
  showAllActiveInd: state.memberSearch.showAllActiveIndi,
});

const mapDispatchToProps = {
  getCobData,
  updateCob,
  deleteCob,
  getShowAll,
  updateIndcobData,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(COB));
