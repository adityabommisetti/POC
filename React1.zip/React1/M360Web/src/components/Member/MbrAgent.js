import * as DateUtil from "../../utils/DatePicker";
import * as Type from "../../constants/ConfirmType";

import React, { Component } from "react";
import Autocomplete1 from "../UI/Select";
import {
  deleteAgent,
  getAgent,
  getShowAll,
  insetUpdateAgent,
  updateIndagentData,
} from "../../redux/actions/MemberActions";

import AgencySearchPopup from "../Application/ApplAgencySearchPopup";
import ConfirmBox from "../../utils/PopUp";
import DataTable from "../Home/DataTable";
import HistoryData from "../UI/MemberHistory";
import InputField from "../UI/InputField";
import MemberButtonPanel from "../UI/MemberButtonPanel";
import Modal from "../../components/UI/Modal/Modal";
import Paper from "@material-ui/core/Paper";
import Popup from "reactjs-popup";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../assets/styles/Theme";
import classNames from "classnames";
import { connect } from "react-redux";
import { handleDateChange } from "../../utils/DateFormatter";
import { AGENT_TABLE_HEADER as header } from "../../constants/Headers/MemberHeaders";
import isEmpty from "lodash/isEmpty";
import { messages } from "../../constants/Messages";
import { withStyles } from "@material-ui/core/styles";
import { customValidations } from "../../utils/CustomValidations";

const INITIAL_STATE = {
  customerId: "",
  validPlanId: "",
  memberId: "",
  agentId: "",
  agentType: "",
  agentTypeDesc: "",
  agentTIN: "",
  agentName: "",
  agentPhone: "",
  agentEmail: "",
  agencyId: "",
  agencyType: "",
  agencyTypeDesc: "",
  agencyTIN: "",
  agencyName: "",
  agencyPhone: "",
  agencyEmail: "",
  overrideInd: "N",
  planId: "",
  effStartDate: "",
  effEndDate: "",
  createTime: "",
  createUserId: "",
  lastUpdtTime: "",
  lastUpdtUserId: "",
  selAgencyId: null,
  disEnrollApprvStartDateMinusOne: null,
  currentDateTime: null,
  type: "",
  effStartDateFrmt: "",
  createTimeFrmt: "",
  lastUpdtTimeFrmt: "",
  effEndDateFrmt: "99/99/9999",
  showAll: "",
};

class Agent extends Component {
  constructor(props) {
    super(props);

    this.resetAgents = this.resetAgents.bind(this);

    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
        date_after: customValidations.date_after,
        last_day_of_month: customValidations.last_day_of_month,
        first_day_of_month: customValidations.first_day_of_month,
      },
    });
    this.state = {
      agentVo: INITIAL_STATE,
      modified: false,
      isNewSegment: false,
      editable: false,
      closePopup: false,
      showAllData: null,
      mbrAgentList: null,
      memberId: this.props.mbrSearchCriteria.memberId,
      selectedIndex: 0,
      togglePopup: false,
      rowsPerPage: 10,
      func1: this.showAll.bind(this),
      showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
    };
  }

  selectRow = (index) => {
    const selectedVo = this.state.mbrAgentList[index];
    this.setState(() => ({
      agentVo: { ...selectedVo }, // copy data
      editable: false, // readOnly
      isNewSegment: false, //Not a new SEgment
      modified: false,
      selectedIndex: index,
    }));
    this.validator.hideMessages();
  };

  handleDate = (event) => {
    let fieldId = event.target.name;
    let value = event.target.value;
    this.setState((prevState) => ({
      agentVo: {
        ...prevState.agentVo,
        [fieldId]: handleDateChange(value),
      },
      modified: true,
    }));
  };

  handlechange = (name) => (event) => {
    let value = event.target.value.toUpperCase();
    this.setState((prevState) => ({
      agentVo: {
        ...prevState.agentVo,
        [name]: value,
      },
      modified: true, // enable update button
    }));
    if (name === "agencyName") {
      this.resetAgents();
    }
  };

  handleOnBlur = (event) => {
    let value = event.target.value.trim();
    let name = event.target.name;
    this.setState((prevState) => ({
      agentVo: {
        ...prevState.agentVo,
        [name]: value,
      },
      modified: true, // enable update button
    }));
    if (name === "agencyName") {
      this.resetAgents();
    }
  };

  handleDates = (event) => {
    var self = this;
    const fieldId = "#" + event.target.name;
    // if (event.target.name === "effStartDateFrmt") {
    //   //debugger
    // }
    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        self.setValue(e.target.name, e.target.value);
      });
    //     const name = "#" + event.target.name;
    //     var self = this;

    //     DateUtil.getDatePicker(name)
    //       .datepicker("show")
    //       .on("change", e => {
    //         if (
    //           dateChk.name !== e.target.name ||
    //           dateChk.value !== e.target.value
    //         ) {
    //           self.setDate(e.target.name, e.target.value);
    //         }
    //         dateChk.name = e.target.name;
    //         dateChk.value = e.target.value;
    //       });
  };

  setValue = (name, value) => {
    if (value === "") {
    }
    this.setState((prevState) => ({
      agentVo: {
        ...prevState.agentVo,
        [name]: value,
      },
      modified: true,
    }));
    this.forceUpdate();
  };

  // setDate = (name, value) => {
  //   this.setState(prevState => ({
  //     agentVo: {
  //       ...prevState.agentVo,
  //       [name]: value
  //     },
  //     modified: true
  //   }));
  //   this.forceUpdate();
  // };

  handleChangeSearchSelect = (name) => (event) => {
    let value = event.value ? event.value : event;
    if (typeof value === "string") {
      this.setState((prevState) => ({
        agentVo: {
          ...prevState.agentVo,
          [name]: value,
        },
        modified: true,
      }));
    }
  };

  resetAgents = () => {
    this.setState((prevState) => ({
      agentVo: {
        ...prevState.agentVo,
        type: "",
        agentTIN: "",
        agentPhone: "",
        agentEmail: "",
      },
      modified: true,
    }));
  };

  modelSegment = () => {
    if (this.state.agentVo.overrideInd === "Y") {
      let msg = "This Record is not active ";
      this.setState({ message: msg, closePopup: true });
    } else {
      this.setState({
        editable: true, // Editable
        isNewSegment: false, // Not a new Segment
      });
    }
  };

  createNewSegment = () => {
    this.validator.hideMessages();
    INITIAL_STATE.memberId = this.props.mbrSearchCriteria.memberId;
    this.setState({
      editable: true, //editable
      isNewSegment: true, //new SEgment
      agentVo: {
        ...INITIAL_STATE, // marked all fields as Empty
      },
    });
  };

  update = (event) => {
    event.preventDefault();
    if (this.validator.allValid()) {
      ConfirmBox(this.confirmUpdate, Type.UPDATE, this.props);
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  confirmUpdate = async () => {
    const { agentVo } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(agentVo.showAll = val),
    });
    let payload = {
      ...this.state.agentVo,
      memberId: this.props.mbrSearchCriteria.memberId,
    };
    let status = await this.props.insetUpdateAgent(payload);

    if ("success" === status) {
      status = messages.UPDATED_SUCCESSFULLY;
    } else {
      this.setState({
        message: status,
        //isNewSegment: true,
        editable: true,
        modified: true,
        closePopup: true,
      });
      return;
    }
    this.setState(() => ({
      message: status,
      isNewSegment: false,
      editable: false,
      modified: false,
      agentVo: this.props.agentData[this.state.selectedIndex],
      mbrAgentList: this.props.agentData,
      showAllData: null,
      closePopup: true,
    }));
  };

  addNewSegment = () => {
    if (this.validator.allValid()) {
      ConfirmBox(this.confirmAddNewSegment, Type.ADD, this.props);
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  handleChangeSearchSelectAuto = async (data, name) => {
    let value = data.value;
    if (typeof value === "string") {
      this.setState((prevState) => ({
        agentVo: {
          ...prevState.agentVo,
          [name]: value,
        },
        modified: true,
      }));
    }
  };
  confirmAddNewSegment = async () => {
    const { agentVo } = this.state;

    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(agentVo.showAll = val),
    });
    let payload = {
      ...agentVo,
      memberId: this.props.mbrSearchCriteria.memberId,
    };
    let status = await this.props.insetUpdateAgent(payload);

    if ("success" === status) {
      status = messages.INSERTED_SUCCESSFULLY;
    } else {
      this.setState({
        message: status,
        isNewSegment: true,
        editable: true,
        modified: true,
        closePopup: true,
      });
      return;
    }
    let agentData = isEmpty(this.props.agentData) ? [] : this.props.agentData;
    let newVO = isEmpty(this.props.agentData)
      ? INITIAL_STATE
      : this.props.agentData[0];
    this.setState({
      message: status,
      isNewSegment: false,
      editable: false,
      modified: false,
      agentVo: newVO,
      mbrAgentList: agentData,
      showAllData: null,
      closePopup: true,
      selectedIndex: 0,
    });
    this.validator.hideMessages();
  };

  closePopup = () => {
    this.setState({
      //   togglePopup: true,
      closePopup: true, //!(this.validator.fields['Start date']),
      message: "Start date field is required",
    });
  };
  delete = () => {
    if (this.state.agentVo.overrideInd === "Y") {
      let msg = "This Record is not active ";
      this.setState({ message: msg, closePopup: true });
    } else {
      ConfirmBox(this.confirmDelete, Type.DELETE, this.props);
    }
  };

  confirmDelete = async () => {
    const { agentVo } = this.state;

    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(agentVo.showAll = val),
    });
    let payload = {
      ...agentVo,
      memberId: this.props.mbrSearchCriteria.memberId,
    };
    let status = await this.props.deleteAgent(payload);
    if ("success" === status) {
      status = messages.DELETED_SUCCESSFULLY;
    }
    let agentData = isEmpty(this.props.agentData) ? [] : this.props.agentData;
    let newVO = isEmpty(this.props.agentData)
      ? INITIAL_STATE
      : this.props.agentData[0];
    this.setState({
      agentVo: newVO,
      mbrAgentList: agentData,
      showAllData: null,
      closePopup: true,
      message: status,
      selectedIndex: 0,
      isNewSegment: false,
      editable: false,
      modified: false,
    });
  };

  setAgencyData = (selectedVo) => {
    this.setState({
      agentVo: {
        ...this.state.agentVo,
        ...selectedVo,
        agencyTIN: selectedVo.agencyTin,
        agentTIN: selectedVo.agentTin,
      },
      modified: true,
    });
  };

  handleChangePage = (index) => {
    this.selectRow(index);
  };
  goBack = () => {
    const index = this.state.selectedIndex;
    const { agentData } = this.props;
    let agentVo = INITIAL_STATE;

    if (!isEmpty(agentData)) {
      agentVo = this.props.agentData[index];
    }

    this.setState({
      isNewSegment: false,
      editable: false,
      modified: false,
      agentVo: agentVo,
    });
    this.validator.hideMessages();
  };

  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.mbrSearchCriteria.memberId !== prevState.memberId) {
      if (!isEmpty(nextProps.agentData)) {
        return {
          agentVo: nextProps.agentData[0],
          mbrAgentList: nextProps.agentData,
          showAllData: null,
          //showAllActiveInd: true,
          modified: false,
          isNewSegment: false,
          editable: false,
          selectedIndex: 0,
          memberId: nextProps.mbrSearchCriteria.memberId,
          model: prevState.func1(
            nextProps.showAllActiveInd.showAllActiveInd === false ? true : "N",
            nextProps.mbrSearchCriteria.memberId
          ),
        };
      }
    }

    if (
      nextProps.showAllActiveInd.showAllActiveInd !== prevState.showAllActiveInd
    ) {
      if (nextProps.showAllActiveInd.showAllActiveInd === false) {
        return {
          model: prevState.func1(true, nextProps.mbrSearchCriteria.memberId),
        };
      } else if (nextProps.showAllActiveInd.showAllActiveInd === true) {
        return {
          model: prevState.func1(false, nextProps.mbrSearchCriteria.memberId),
        };
      }
    }
    return prevState;
  }
  async componentDidUpdate(){
    if(this.state.memberId !== this.props.mbrSearchCriteria.memberId  && isEmpty(this.props.agentData)){
      this.setState(() => ({
        memberId: this.props.mbrSearchCriteria.memberId
      }));

      await this.props.getAgent(this.props.mbrSearchCriteria.memberId + "/N");
   
    let agentData = isEmpty(this.props.agentData) ? [] : this.props.agentData;

    const mbrAgentList = agentData;
    const selectedVo = !isEmpty(mbrAgentList)
      ? mbrAgentList[0]
      : { ...INITIAL_STATE };
    this.setState(() => ({
      agentVo: { ...selectedVo },
      mbrAgentList: mbrAgentList,
      showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
      selectedIndex: 0,
      isNewSegment: false,
      editable: false,
    }));
      
    }
  }
  async componentDidMount() {
    INITIAL_STATE.memberId = this.props.mbrSearchCriteria.memberId;
    if (this.props.showAllActiveInd.showAllActiveInd === false) {
      this.showAll(true, this.props.mbrSearchCriteria.memberId);
    } else if (isEmpty(this.props.agentData) && this.props.agentData !== null) {
      await this.props.getAgent(this.props.mbrSearchCriteria.memberId + "/N");
    }

    if (!isEmpty(this.props.agentData)) {
      let agentVo = this.props.agentData[0];
      this.setState({
        agentVo: agentVo,
        mbrAgentList: this.props.agentData,
      });
    }
  }

  modalClosed = () => {
    this.setState({ closePopup: false });
  };

  showAll = async (flag, mbrId) => {
    const memberId = mbrId;
    const { showAllData } = this.state;
    if (flag === true) {
      if (showAllData === null) {
        const data = await this.props.getShowAll({
          memberId: memberId + "/Y",
          url: "GET_AGENT",
        });
        if (null != data) {
          const selectedVo = !isEmpty(data) ? data[0] : { ...INITIAL_STATE };
          this.setState(() => ({
            mbrAgentList: data,
            showAllData: data,
            agentVo: { ...selectedVo },
            showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
            selectedIndex: 0,
            isNewSegment: false,
            editable: false,
          }));
        }
      } else {
        const agentVo = !isEmpty(showAllData)
          ? showAllData[0]
          : { ...INITIAL_STATE };
        this.setState({
          mbrAgentList: showAllData,
          agentVo: agentVo,
          showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
          selectedIndex: 0,
          isNewSegment: false,
          editable: false,
        });
      }
    } else {
      if (flag === "N") {
        await this.props.getAgent(memberId + "/N");
      } else {
        let recodN = await (this.state.mbrAgentList === null
          ? []
          : this.state.mbrAgentList.filter((role) => role.overrideInd === "N"));

        await this.props.updateIndagentData(recodN);
      }
      let agentData = isEmpty(this.props.agentData) ? [] : this.props.agentData;

      const mbrAgentList = agentData;
      const selectedVo = !isEmpty(mbrAgentList)
        ? mbrAgentList[0]
        : { ...INITIAL_STATE };
      this.setState(() => ({
        agentVo: { ...selectedVo },
        mbrAgentList: mbrAgentList,
        showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
        selectedIndex: 0,
        isNewSegment: false,
        editable: false,
      }));
    }
  };
  handleChangeRowsPerPage = async (rowsPerPage) => {
    await this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  render() {
    const { classes } = this.props;
    let agentVo = this.state.agentVo;
    const mbrAgentList = this.state.mbrAgentList;
    let ButtonPanel = (
      <MemberButtonPanel
        isNewSegment={this.state.isNewSegment}
        //showAll={this.showAll}
        //toggleLabel={this.state.showAllActiveInd}
        newSegment={this.createNewSegment}
        modelSegment={this.modelSegment}
        modified={this.state.modified}
        editable={this.state.editable}
        delete={this.delete}
        update={this.update}
        disable={isEmpty(mbrAgentList)}
      />
    );

    return (
      <React.Fragment>
        <Modal
          dialogTitle="AGENT"
          message={this.state.message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Paper
          elevation={0}
          className={classNames(classes.card, "animated fadeIn")}
        >
          <DataTable
            data={!isEmpty(mbrAgentList) ? mbrAgentList : []}
            header={header}
            sortable={true}
            rowsPerPageOptions={[10, 15, 20]}
            handleChangeRowsPerPage={this.handleChangeRowsPerPage}
            rowsPerPage={this.state.rowsPerPage}
            clicked={this.selectRow}
            index={this.state.selectedIndex}
            dateColumn={["effStartDateFrmt", "effEndDateFrmt"]}
            subtab
          />

          {!isEmpty(mbrAgentList) || (this.state.isNewSegment && agentVo) ? (
            <React.Fragment>
              <form autoComplete="off">
                <div className={classes.buttonContainer}> {ButtonPanel}</div>

                <div className="panel-body margin-top1">
                  <div className={classes.container}>
                    <div>
                      <Autocomplete1
                        handleChange={this.handleChangeSearchSelectAuto}
                        label="Status Flag"
                        options={this.props.dropdowns.validPlanId}
                        defaultValue={this.props.dropdowns.validPlanId[0]}
                        margin="0px"
                        value={
                          this.props.dropdowns.validPlanId.filter(
                            (data) => data.value === agentVo.planId
                          )[0]
                        }
                        name="planId"
                        disabled={!this.state.editable}
                      />
                      <div className={classes.validationMessageSelect}>
                        {this.validator.message(
                          "Plan Id",
                          agentVo.planId.trim(),
                          "required"
                        )}
                      </div>
                    </div>

                    <div>
                      <InputField
                        name="effStartDateFrmt"
                        placeholder="MM/DD/YYYY"
                        onClick={this.handleDates}
                        label="Start Date"
                        required={this.state.editable}
                        value={agentVo.effStartDateFrmt}
                        onChange={this.handleDate}
                        onBlur={this.handleOnBlur}
                        disabled={!this.state.editable}
                        maxLength={10}
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "Start date",
                          agentVo.effStartDateFrmt,
                          "required|date_format|first_day_of_month"
                        )}
                      </div>
                    </div>
                    <div>
                      <InputField
                        name="effEndDateFrmt"
                        placeholder="MM/DD/YYYY"
                        onClick={this.handleDates}
                        label="End Date"
                        required={this.state.editable}
                        value={agentVo.effEndDateFrmt}
                        onChange={this.handleDate}
                        onBlur={this.handleOnBlur}
                        disabled={!this.state.editable}
                        maxLength={10}
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "End date",
                          agentVo.effEndDateFrmt,
                          [
                            "required",
                            "date_format",
                            "date_after",
                            "last_day_of_month",
                            { date_after: agentVo.effStartDateFrmt },
                          ]
                        )}
                      </div>
                    </div>

                    <div>
                      <InputField
                        name="overrideInd"
                        label="Override"
                        value={agentVo.overrideInd}
                        disabled={true}
                      />
                      <div className={classes.validationMessage}></div>
                    </div>
                  </div>
                </div>
                <div class="panel-subhead ">
                  <h3> Agency Information </h3>
                </div>
                <div className="panel-body">
                  <div className={classes.container}>
                    <div>
                      <InputField
                        name="agencyTypeDesc"
                        label="Type"
                        value={agentVo.agencyTypeDesc}
                        disabled={true}
                        width="280px"
                      />
                      <div className={classes.validationMessage}></div>
                    </div>

                    <div>
                      <div
                        className={classes.container}
                        style={{
                          width: "525px",
                          marginTop: "0px",
                          display: "-webkit-inline-box",
                        }}
                      >
                        <span class="label-container">
                          <label for="Name">Name</label>
                          {this.state.editable && (
                            <span className="imp">*</span>
                          )}
                          <br />
                          <input
                            type="text"
                            id="agencyName"
                            class="form-field"
                            value={agentVo.agencyName}
                            onBlur={this.handleOnBlur}
                            onChange={this.handlechange("agencyName")}
                            style={{ width: "475px" }}
                            maxLength="60"
                            disabled={!this.state.editable}
                            endAdornment={this.state.editable}
                          />
                          {this.state.editable ? (
                            <Popup
                              style={{ height: "50%" }}
                              className={classes.mobileWidth}
                              modal
                              trigger={
                                <span class="more-info" id="more-info" />
                              }
                              position="right center"
                              // open={
                              //   this.validator.fields['Start date'] &&
                              //  this.state.togglePopup
                              // }
                              // onOpen={() => {
                              //   this.setState({
                              //     togglePopup: true  });
                              //  // alert(agentVo.effStartDateFrmt.length)

                              // }}
                              // onClose={() => {
                              //   this.setState({ togglePopup: false });
                              // }}
                            >
                              {(close) => (
                                <div>
                                  <AgencySearchPopup
                                    closePopup={this.closePopup}
                                    setData={this.setAgencyData}
                                    close={close}
                                    agent={agentVo}
                                    type="Member"
                                  />
                                </div>
                              )}
                            </Popup>
                          ) : null}
                        </span>
                      </div>
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "Agency Name",
                          agentVo.agencyName,
                          "required"
                        )}
                      </div>
                    </div>
                    <div>
                      <InputField
                        name="agencyTIN"
                        label="TIN"
                        value={agentVo.agencyTIN}
                        disabled={true}
                      />
                      <div className={classes.validationMessage}></div>
                    </div>

                    <div>
                      <InputField
                        name="agencyPhone"
                        label="Phone"
                        value={agentVo.agencyPhone}
                        disabled={true}
                      />
                      <div className={classes.validationMessage}></div>
                    </div>

                    <div>
                      <InputField
                        name="agencyEmail"
                        label="Email"
                        value={agentVo.agencyEmail}
                        disabled={true}
                        width="409px"
                      />
                      <div className={classes.validationMessage}></div>
                    </div>
                  </div>
                </div>
                <div class="panel-subhead ">
                  <h3> Agent Information </h3>
                </div>

                <div className="panel-body">
                  <div className={classes.container}>
                    <div>
                      <div>
                        <InputField
                          name="agentTypeDesc"
                          label="Agent Type"
                          value={agentVo.agentTypeDesc}
                          disabled={true}
                          width="280px"
                        />
                        <div className={classes.validationMessage}></div>
                      </div>
                    </div>

                    <div>
                      <div>
                        <InputField
                          name="agentName"
                          label="Agent name"
                          width="200px"
                          value={agentVo.agentName}
                          disabled={true}
                        />
                        <div className={classes.validationMessage}></div>
                      </div>
                      <div className={classes.validationMessage}></div>
                    </div>
                    <div>
                      <InputField
                        name="agentTIN"
                        label="TIN"
                        value={agentVo.agentTIN}
                        disabled={true}
                      />
                      <div className={classes.validationMessage}></div>
                    </div>

                    <div>
                      <InputField
                        name="agentPhone"
                        label="Phone"
                        value={agentVo.agentPhone}
                        disabled={true}
                      />
                      <div className={classes.validationMessage}></div>
                    </div>

                    <div>
                      <InputField
                        name="agentEmail"
                        label="Email"
                        value={agentVo.agentEmail}
                        disabled={true}
                        width="407px"
                      />
                      <div className={classes.validationMessage}></div>
                    </div>
                  </div>
                </div>
              </form>
              <HistoryData
                isNewSegment={this.state.isNewSegment}
                reset={this.createNewSegment}
                addSegment={this.addNewSegment}
                back={this.goBack}
                createUserId={agentVo.createUserId}
                createTime={agentVo.createTime}
                lastUpdtTime={agentVo.lastUpdtTime}
                lastUpdtUserId={agentVo.lastUpdtUserId}
              />
            </React.Fragment>
          ) : (
            <div className={classes.buttonContainer}> {ButtonPanel}</div>
          )}
        </Paper>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    agentData: state.memberSearch.searchResultsVo.mbrAgentInfoList,
    loginData: state.loginData,
    searchResultsVo: state.memberSearch.searchResultsVo,
    mbrSearchCriteria: state.memberSearch.mbrSearchCriteria,
    dropdowns: state.membercache,
    showAllActiveInd: state.memberSearch.showAllActiveIndi,
  };
};
const mapDispatchToProps = {
  getAgent,
  insetUpdateAgent,
  getShowAll,
  deleteAgent,
  updateIndagentData,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(Agent));
