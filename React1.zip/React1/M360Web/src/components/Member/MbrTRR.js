import React, { Component } from "react";
import { getTRR } from "../../redux/actions/MemberActions";

import DataTable from "../Home/DataTable";
import InputField from "../UI/InputField";
import Paper from "@material-ui/core/Paper";
import { Styles } from "../../assets/styles/Theme";
import classNames from "classnames";
import { connect } from "react-redux";
import { TRR_TABLE_HEADER as header } from "../../constants/Headers/MemberHeaders";
import isEmpty from "lodash/isEmpty";
import { withStyles } from "@material-ui/core/styles";
import Popup from "reactjs-popup";
import MbrTRRData from "./MbrTRRData";
import Button from "@material-ui/core/Button";

class TRR extends Component {
  state = {
    selectedIndex: 0,
    rowsPerPage: 10,
    trrDataPopup: false,
  };

  selectRow = (index) => {
    this.setState(() => ({
      selectedIndex: index,
    }));
  };

  async componentDidMount() {
    if (isEmpty(this.props.trrData) && this.props.trrData !== null) {
      await this.props.getTRR(this.props.mbrSearchCriteria.memberId);
    }
  }
  handleChangeRowsPerPage = async (rowsPerPage) => {
    await this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  handleChangePage = (index) => {
    this.setState({ selectedIndex: index });
  };

  openTrrDataPopup = (event) => {
    event.preventDefault();
    this.setState({ trrDataPopup: true });
  };

  closeTrrDataPopup = () => {
    this.setState({ trrDataPopup: false });
  };

  render() {
    const { classes, trrData } = this.props;
    const { selectedIndex } = this.state;

    return (
      <Paper
        elevation={0}
        className={classNames(classes.card, "animated fadeIn")}
      >
        <DataTable
          data={!isEmpty(trrData) ? trrData : []}
          header={header}
          sortable={true}
          rowsPerPageOptions={[10, 15, 20]}
          handleChangeRowsPerPage={this.handleChangeRowsPerPage}
          rowsPerPage={this.state.rowsPerPage}
          index={selectedIndex}
          clicked={this.selectRow}
          handleChangePage={this.handleChangePage}
          subtab
        />
        {this.state.trrDataPopup ? (
          <Popup
            className={classes.mobileWidth}
            modal
            open={this.state.trrDataPopup}
            onClose={this.closeTrrDataPopup}
          >
            <MbrTRRData
              data={trrData[selectedIndex]}
              close={this.closeTrrDataPopup}
            />
          </Popup>
        ) : null}

        {!isEmpty(trrData) ? (
          <form autoComplete="off">
            <div className={classes.buttonContainer}>
              <Button
                type="submit"
                variant="contained"
                color="primary"
                onClick={this.openTrrDataPopup}
                disabled={!trrData[selectedIndex].isTrrVarDataPresent}
                className={classes.button}
                id="TRR DATA"
              >
                TRR DATA
              </Button>
            </div>
            <div className="panel-body">
              <div className={classes.container}>
                <div>
                  <InputField
                    name="txn"
                    label="CMS Txn Date"
                    value={trrData[selectedIndex].processDateFrmt}
                    disabled
                  />
                </div>
                <div>
                  <InputField
                    name="effectiveDate"
                    label="Txn Eff Date"
                    value={trrData[selectedIndex].effectiveDateFrmt}
                    disabled
                  />
                </div>
                <div>
                  <InputField
                    name="txn"
                    label="Transaction Code"
                    value={trrData[selectedIndex].transactionCode}
                    disabled
                  />
                </div>
                <div>
                  <InputField
                    name="reply"
                    label="Reply Code"
                    value={
                      trrData[selectedIndex].transReplyCd +
                      "-" +
                      trrData[selectedIndex].transReplyDesc
                    }
                    disabled
                    width={"360px"}
                  />
                </div>
                <div>
                  <InputField
                    name="accRej"
                    label="Acc/Rej"
                    value={trrData[selectedIndex].accRejInd}
                    disabled
                  />
                </div>
                <div>
                  <InputField
                    name="source"
                    label="Source"
                    value={trrData[selectedIndex].sourceId}
                    disabled
                  />
                </div>
                <div>
                  <InputField
                    name="updateItem"
                    label="Update Item"
                    value={trrData[selectedIndex].updateType}
                    disabled
                  />
                </div>
                <div>
                  <InputField
                    name="updateField"
                    label="Update Performed"
                    value={trrData[selectedIndex].updateYN}
                    disabled
                  />
                </div>
                <div>
                  <InputField
                    name="logUser"
                    label="Log User"
                    value={trrData[selectedIndex].lastUpdtUserId}
                    disabled
                  />
                </div>
                <div>
                  <InputField
                    name="logTime"
                    label="Log Time"
                    value={trrData[selectedIndex].logTimeFrmt}
                    disabled
                  />
                </div>

                <div>
                  <InputField
                    name="Field"
                    label="Field"
                    value={trrData[selectedIndex].fieldName}
                    disabled
                    width={"360px"}
                  />
                </div>

                <div>
                  <InputField
                    name="Before"
                    label="Before"
                    value={trrData[selectedIndex].relatedFieldBefore}
                    disabled
                  />
                </div>
                <div>
                  <InputField
                    name="After"
                    label="After"
                    value={trrData[selectedIndex].relatedFieldAfter}
                    disabled
                  />
                </div>
              </div>
            </div>
          </form>
        ) : null}
        <hr />
      </Paper>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    trrData: state.memberSearch.searchResultsVo.mbrTrrList,
    mbrSearchCriteria: state.memberSearch.mbrSearchCriteria,
  };
};
const mapDispatchToProps = {
  getTRR,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(TRR));
