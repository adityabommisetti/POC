import "../../assets/css/comments.css";
import * as DateUtil from "../../utils/DatePicker";
import * as Type from "../../constants/ConfirmType";
import * as ActionTypes from "../../redux/types/ActionType";
import {
  OOA_TYPE,
  OOA_HEADER as header,
} from "../../constants/Headers/MemberHeaders";
import React, { Component } from "react";
import AutoComplete1 from "../UI/Select";
import {
  getOoaData,
  updateOoa,
  getShowAll,
  updateIndOOAData,
} from "../../redux/actions/MemberActions";
import Modal from "../../components/UI/Modal/Modal";
import Button from "@material-ui/core/Button";
import ConfirmBox from "../../utils/PopUp";
import DataTable from "../Home/DataTable";
import HistoryData from "../UI/MemberHistory";
import InputField from "../UI/InputField";
import MuiExpansionPanel from "@material-ui/core/ExpansionPanel";
import MuiExpansionPanelDetails from "@material-ui/core/ExpansionPanelDetails";
import MuiExpansionPanelSummary from "@material-ui/core/ExpansionPanelSummary";
import Paper from "@material-ui/core/Paper";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../assets/styles/Theme";
import Typography from "@material-ui/core/Typography";
import classNames from "classnames";
import { connect } from "react-redux";
import isEmpty from "lodash/isEmpty";
import moment from "moment";
import { withStyles } from "@material-ui/core/styles";
import { customValidations } from "../../utils/CustomValidations";
import { handleDateChange } from "../../utils/DateFormatter";

const ExpansionPanel = withStyles({
  root: {
    backgroundColor: "#ECECEC",
    color: "white",
    minHeight: "35px !important",
    boxShadow: "none",
    "&:not(:last-child)": {
      borderBottom: 0,
    },
    "&:before": {
      display: "none",
    },
  },
  expanded: {
    margin: "auto",
  },
  panelSubhead: {
    backgroundColor: "#053674",
    padding: "0.1rem 0.8rem",
    marginTop: "1em",
    minHeight: "35px !important",
    height: "35px !important",
  },
})(MuiExpansionPanel);

const ExpansionPanelSummary = withStyles({
  root: {
    backgroundColor: "#053674",
    color: "white",
    //  padding: ".5em 1em",
    marginTop: "1em",
    minHeight: "35px !important",
    //lineHeight: ".8",
    "&$expanded": {
      marginTop: "10px",
      minHeight: "35px !important",
    },
  },
  content: {
    "&$expanded": {
      minHeight: "35px !important",
      margin: "4px 0 !important",
    },
  },
  expanded: {
    color: "white",
  },
})((props) => <MuiExpansionPanelSummary {...props} />);

ExpansionPanelSummary.muiName = "ExpansionPanelSummary";
const ExpansionPanelDetails = withStyles((theme) => ({
  root: {
    padding: theme.spacing.unit * 2,
  },
}))(MuiExpansionPanelDetails);

const INITIAL_STATE = {
  customerId: "",
  memberId: "",
  tempPerm: "",
  ooaSource: "",
  sourceDesc: "",
  reasonDesc: "",
  deReasonDesc: "",
  ooaReason: "",
  receiveDate: "",
  leaveDate: "",
  returnDate: "",
  deEffectiveDate: "",
  deReason: "",
  endDate: "",
  createTime: "",
  createUserId: "",
  lastUpdtTime: "",
  lastUpdtUserId: "",
  overrideInd: "N",
  planDesignation: null,
  ooaSourceTrr: null,
  type: "",
  effEndDate: null,
  effStartDate: null,
  leaveDateFrmt: "",
  endDateFrmt: "",
  receiveDateFrmt: "",
  deEffectiveDateFrmt: "",
  returnDateFrmt: "",
  expanded: "TEMP",
};

class OOA extends Component {
  constructor(props) {
    super(props);
    this.validatorTemp = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
        date_formats: customValidations.date_formats,
        check_Date: customValidations.check_Date,
        received_date_180: customValidations.received_date_180,
        received_date_363: customValidations.received_date_363,
      },
    });
    this.validatorPerm = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
        date_formats: customValidations.date_formats,
        check_Date: customValidations.check_Date,
        received_date_180: customValidations.received_date_180,
        received_date_363: customValidations.received_date_363,
      },
    });
    this.state = {
      ooaVo: { ...INITIAL_STATE },
      memberId: this.props.mbrSearchCriteria.memberId,
      modified: false,
      isNewSegment: false,
      //showAllActive: true,
      editable: false,
      selectedIndex: 0,
      closePopup: false,
      message: "",
      expanded: "TEMP",
      rowsPerPage: 10,
      func1: this.showAll.bind(this),
      showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
      disableSelect: false,
      data: [],
      showAllData: null,
    };
  }

  async componentDidMount() {
    if (this.props.showAllActiveInd.showAllActiveInd === false) {
      this.showAll(true, this.props.mbrSearchCriteria.memberId);
    } else if (isEmpty(this.props.ooaData) && this.props.ooaData !== null) {
      await this.props.getOoaData(this.props.mbrSearchCriteria.memberId + "/N");
      INITIAL_STATE.memberId = this.props.mbrSearchCriteria.memberId;
    }

    if (!isEmpty(this.props.ooaData)) {
      let ooaVo = this.props.ooaData[0];
      await this.setState({
        ooaVo: ooaVo,
        data: this.props.ooaData,
      });
    }
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.mbrSearchCriteria.memberId !== prevState.memberId) {
      if (!isEmpty(nextProps.ooaData)) {
        return {
          ooaVo: nextProps.ooaData[0],
          showAllData: null,
          data: nextProps.ooaData,
          isNewSegment: false,
          editable: false,
          memberId: nextProps.mbrSearchCriteria.memberId,
          model: prevState.func1(
            nextProps.showAllActiveInd.showAllActiveInd === false ? true : "N",
            nextProps.mbrSearchCriteria.memberId
          ),
        };
      }
      return {
        ooaVo: INITIAL_STATE,
        showAllData: null,
        data: nextProps.ooaData,
        isNewSegment: false,
        editable: false,
        memberId: nextProps.mbrSearchCriteria.memberId,
        model: prevState.func1(
          nextProps.showAllActiveInd.showAllActiveInd === false ? true : "N",
          nextProps.mbrSearchCriteria.memberId
        ),
      };
    }
    if (
      nextProps.showAllActiveInd.showAllActiveInd !== prevState.showAllActiveInd
    ) {
      if (nextProps.showAllActiveInd.showAllActiveInd === false) {
        return {
          model: prevState.func1(true, nextProps.mbrSearchCriteria.memberId),
        };
      } else {
        return {
          model: prevState.func1(false, nextProps.mbrSearchCriteria.memberId),
        };
      }
    }

    return null;
  }

  modelSegment = () => {
    if (this.state.ooaVo.tempPerm === "PERM") {
      alert("Cannot modify a Permanent OOA segment");
    } else if (
      !isEmpty(this.props.ooaData[this.state.selectedIndex].returnDateFrmt)
    ) {
      alert("Cannot Modify a Temporary OOA ");
      this.setState({
        disableSelect: true,
      });
    } else {
      this.setState({
        editable: true, // Editable
        isNewSegment: false, // Not a new Segment
      });
    }
  };
  goBack = () => {
    this.setState({
      isNewSegment: false,
      editable: false,
      modified: false,
      ooaVo: { ...this.state.oldooaVo },
    });
  };

  createNewSegment = () => {
    INITIAL_STATE.memberId = this.props.mbrSearchCriteria.memberId;
    this.validatorTemp.hideMessages();
    this.validatorPerm.hideMessages();

    this.setState({
      editable: true,
      isNewSegment: true,
      ooaVo: {
        ...INITIAL_STATE,
      },
    });
  };

  update = (event) => {
    let enrollData = this.props.enrollData;
    let ooaData = this.props.ooaData;
    let enrollList =
      enrollData &&
      enrollData.filter(
        (value) =>
          value.overrideInd === "N" && value.effEndDateFrmt === "99/99/9999"
      );
    event.preventDefault();
    if (!this.state.isNewSegment && this.state.ooaVo.tempPerm === "PERM") {
      alert("Cannot modify OOA TYPE");
    } else if (
      this.state.ooaVo.tempPerm === "TEMP" &&
      !this.validatorTemp.allValid()
    ) {
      this.validatorTemp.showMessages();
      this.forceUpdate();
    } else if (
      this.state.ooaVo.tempPerm === "PERM" &&
      !this.validatorPerm.allValid()
    ) {
      this.validatorPerm.showMessages();
      this.forceUpdate();
    } else if (
      enrollList[0] &&
      enrollList[0].enrollStatus !== "EAPRV" &&
      enrollList[0].enrollReason !== "CMSAPRV"
    ) {
      alert(" Currently Enrollment status and Reason is not  EAPRV & CMSAPRV");
    } else if (this.state.isNewSegment) {
      for (let i = 0; i <= ooaData.length; i++) {
        if (
          ooaData[i] &&
          ((ooaData[i].tempPerm === "TEMP" &&
            ooaData[i].returnDateFrmt === "") ||
            ooaData[i].endDateFrmt === "")
        ) {
          alert("Cannot make a new Temp entry when already exists");
        }
      }
    } else {
      ConfirmBox(this.confirmUpdate, Type.UPDATE, this.props);
    }
  };

  confirmUpdate = async () => {
    const { ooaVo } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(ooaVo.showAll = val),
    });
   // let message = "";

    let status = await this.props.updateOoa(this.state.ooaVo);
    if (status === "success") {
      await this.setState(() => ({
        data: this.props.ooaData,
        ooaVo: this.props.ooaData[this.state.selectedIndex],
        editable: false, // readOnly
        isNewSegment: false, //Not a new SEgment
        modified: false,
        showAllData: null,
        message: ActionTypes.UPDATE,
        closePopup: true,
      }));
    } else {
     // message = status;
      await this.setState({
        closePopup: true,
        message: status,
      });
    }
  };

  showAll = async (flag, id) => {
    const { showAllData } = this.state;
    if (flag === true) {
      if (showAllData === null) {
        const data = await this.props.getShowAll({
          memberId: id + "/Y",
          url: "MEMBER_OOA_FETCH",
        });

        if (showAllData === null) {
          const selectedVO = !isEmpty(data) ? data[0] : { ...INITIAL_STATE };
          await this.setState(() => ({
            data: data,
            ooaVo: selectedVO,
            showAllData: data,
            showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
            selectedIndex: 0,
            editable: false,
            isNewSegment: false,
          }));
          //console.log(this.state.data)
        }
      } else {
        const selectedVO = !isEmpty(showAllData)
          ? showAllData[0]
          : { ...INITIAL_STATE };

        this.setState(() => ({
          data: showAllData,
          ooaVo: selectedVO,
          showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
          selectedIndex: 0,
          editable: false,
          isNewSegment: false,
        }));
      }
    } else {
      if (flag === "N") {
        await this.props.getShowAll({
          memberId: id + "/N",
          url: "MEMBER_OOA_FETCH",
        });
      } else {
        let recodN = await (this.state.data === []
          ? []
          : this.state.data.filter((role) => role.overrideInd === "N"));

        await this.props.updateIndOOAData(recodN);
      }

      const selectedVO = !isEmpty(this.props.ooaData)
        ? this.props.ooaData[0]
        : { ...INITIAL_STATE };
      this.setState(() => ({
        data: this.props.ooaData,
        ooaVo: selectedVO,
        showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
        selectedIndex: 0,
        editable: false,
        isNewSegment: false,
      }));
    }

    // if(flag===true){
    //   await this.props.getOoaData(id + "/Y");
    //   this.setState(()=>({
    //     showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
    //   }))
    // }else{

    //   await this.props.getOoaData(id+ "/N");

    //   console.log(this.props.ooaData)
    //   this.setState(()=>({
    //     showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
    //   }))
    // }
  };

  addNewSegment = () => {
    let enrollData = this.props.enrollData;
    let enrollList =
      enrollData &&
      enrollData.filter(
        (value) =>
          value.overrideInd === "N" && value.effEndDateFrmt === "99/99/9999"
      );
    if (
      this.state.ooaVo.tempPerm === "TEMP" &&
      !this.validatorTemp.allValid()
    ) {
      this.validatorTemp.showMessages();
      this.forceUpdate();
    } else if (
      this.state.ooaVo.tempPerm === "PERM" &&
      !this.validatorPerm.allValid()
    ) {
      this.validatorPerm.showMessages();
      this.forceUpdate();
    } else if (
      enrollList[0] &&
      enrollList[0].enrollStatus !== "EAPRV" &&
      enrollList[0].enrollReason !== "CMSAPRV"
    ) {
      alert(" Currently Enrollment status and Reason is not  EAPRV & CMSAPRV");
    } else {
      ConfirmBox(this.confirmAddNewSegment, Type.ADD, this.props);
    }
  };

  confirmAddNewSegment = async () => {
    const { ooaVo } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(ooaVo.showAll = val),
    });
    let message = "";
    let status = await this.props.updateOoa(this.state.ooaVo);
    if (status === "success") {
      message = ActionTypes.ADD;
    } else {
      message = status;
    }
    this.setState({
      isNewSegment: false,
      editable: false,
      modified: false,
      ooaVo:
        this.props.ooaData && this.props.ooaData.length > 0
          ? this.props.ooaData[0]
          : { ...INITIAL_STATE },
      closePopup: true,
      message: message,
      page: 0,
      selectedIndex: 0,
      data: this.props.ooaData,
    });
  };

  handleChangePanel = (panel) => (event, expanded) => {
    this.setState({
      expanded: expanded ? panel : false,
    });
  };

  selectRow = async (index, page) => {
    const data = this.state.data;
    let selectedVo;
    if (!isEmpty(data)) {
      selectedVo = data[index];
    } else {
      selectedVo = { ...INITIAL_STATE };
    }
    await this.setState(() => ({
      ooaVo: { ...selectedVo },
      editable: false, // readOnly
      isNewSegment: false, //Not a new SEgment
      modified: false,
      selectedIndex: index,
    }));
  };

  handlechange = (name) => (event) => {
    let value = event.target.value;
    this.setValue(event, name, value);
  };

  handleOnBlur = (event) => {
    let value = event.target.value.trim();
    let name = event.target.name;
    this.setValue(event, name, value);
  };

  handleChangeSearchSelectAuto = (event, name) => {
    let ooaData = this.props.ooaData;

    let value = event.value;

    if (this.state.isNewSegment && name === "tempPerm") {
      this.setState(() => ({
        ooaVo: {
          ...INITIAL_STATE,
          [name]: value,
        },
      }));
    }

    if (
      this.state.isNewSegment &&
      name === "tempPerm" &&
      value === "TEMP" &&
      this.props.ooaData
    ) {
      for (let i = 0; i <= ooaData.length; i++) {
        if (
          ooaData[i] &&
          ooaData[i].tempPerm === "TEMP" &&
          ooaData[i].returnDateFrmt === ""
        ) {
          alert("Cannot add duplicate temporary OOA");
          return;
        }
      }
    } else if (value === "PERM" && !isEmpty(this.props.ooaData)) {
      if (isEmpty(this.props.ooaData[this.state.selectedIndex].returnDateFrmt))
        alert("Update the return date in Temporary OOA");
        else 
        this.setValue(event, name, value);
      return;
    } else if (!isEmpty(this.state.ooaVo.returnDateFrmt) && value === "TEMP") {
      alert("Cannot Modify a Temporary OOA ");
    }

    // else if (!isEmpty(this.state.ooaVo.returnDateFrmt) && value==="PERM" ){
    //   this.setState({
    //     ooaVo:INITIAL_STATE,
    //     editable:true
    //   })
    //   this.setValue(event, name, value);

    // }
    else {
      this.setValue(event, name, value);
    }

    if (name === "ooaReason") {
      this.checkReceiveDate(event);
    }
  };
  ooaType = () => {
    this.setState({
      editable: true,
      ooaTypeSelected: true,
      isNewSegment: false,
      ooaVo: {
        ...this.state.ooaVo,
      },
    });
  };

  handleChangePage = (index) => {
    this.selectRow(index);
  };

  populateEndDate = (returnDate) => {
    if (!(returnDate === "")) {
      if (this.isFldDate9(returnDate)) {
        this.setState((prevState) => ({
          ooaVo: {
            ...prevState.ooaVo,
            endDateFrmt: returnDate,
          },
          modified: true,
        }));
      }
    }
  };

  isFldDate9 = (val) => {
    if (moment(val, "MM/DD/YYYY", true).format() === "Invalid date") {
      return false;
    }
    return true;
  };

  autoPopulate = (event, val) => {
    let enrollList =
      this.props.enrollData &&
      this.props.enrollData.filter(
        (value) =>
          value.overrideInd === "N" && value.effEndDateFrmt === "99/99/9999"
      );

    let receiveDate;
    if (val === "") {
      receiveDate = event.target.value;
    } else {
      receiveDate = val;
    }

    const plan = enrollList && enrollList[0].planDesignation;
    const reason = event.value ? event.value : event.target.value;
    const type = this.state.ooaVo.tempPerm;
    let disEnrollDate;
    if (receiveDate !== "") {
      disEnrollDate = this.setdisenrollDate(receiveDate, plan, reason, type);
    }
    if (this.state.ooaVo.tempPerm === "TEMP") {
      this.setState((prevState) => ({
        ooaVo: {
          ...prevState.ooaVo,
          leaveDateFrmt: receiveDate,
          deEffectiveDateFrmt: disEnrollDate,
        },
        modified: true,
      }));
    } else if (this.state.ooaVo.tempPerm === "PERM") {
      this.setState((prevState) => ({
        ooaVo: {
          ...prevState.ooaVo,
          deEffectiveDateFrmt: disEnrollDate,
        },
        modified: true,
      }));
    }
  };

  setdisenrollDate = (date, plan, reason, type) => {
    var m;
    var dm;
    var y;
    var d;
    var dsdate;
    m = date.substring(0, 2);
    d = date.substring(3, 5);
    y = date.substring(6, 10);
    m = parseInt(date.toString().substring(0, 2));
    dm = m;
    if (type === "TEMP") {
      if (reason !== "04") {
        if (plan === "MAPD" || plan === "MA") {
          if (m === 0) {
            m = parseInt(date.substring(1, 2));
            dm = m + 7;
          } else {
            dm = m + 7;
          }
          if (dm > 12) {
            dm = dm - 12;
            y = parseInt(date.substring(6, 10)) + 1;
          }
          if (dm.toString().length === 1) {
            dm = "0" + dm;
          }
        } else if (plan === "PDP") {
          y = parseInt(y.toString());
          y = y + 1;
          if (m === 0) m = parseInt(date.substring(1, 2));
          dm = m;
          dm = m + 1;
          if (dm.toString().length === 1) {
            dm = "0" + dm;
          }
        }
        d = "01";
      } else if (reason === "04") {
        if (m === 0) {
          m = parseInt(date.substring(1, 2));
          dm = m;
        }
        if (d === 0) {
          d = parseInt(date.substring(4, 5));
          d = d + 45;
        } else {
          d = parseInt(d) + 45;
        }
        if (d > 60) {
          d = d - 30;
          dm = dm + 1;
        }
        if (d > 30) {
          d = d - 30;
          dm = dm + 1;
        }
        if (d.valueOf().toString() !== "01" || d.valueOf().toString() !== "1") {
          dm = dm + 1;
          d = "01";
        }
        if (dm > 12) {
          dm = dm - 12;
          y = parseInt(date.substring(6, 10)) + 1;
        }

        if (d.toString().length === 1) {
          d = "0" + d;
        }
        if (dm.toString().length === 1) {
          dm = "0" + dm;
        }
      }
    } else if (type === "PERM") {
      if (m === 0) {
        m = parseInt(date.substring(1, 2));
        dm = m;
      }
      dm = dm + 1;
      d = "01";
      if (dm > 12) {
        dm = dm - 12;
        y = parseInt(date.substring(6, 10)) + 1;
      }
      if (dm.toString().length === 1) {
        dm = "0" + dm;
      }
      d = "01";
    }
    d = "01";
    dsdate = dm + "/" + d + "/" + y;
    return dsdate;
  };

  checkReceiveDate = (e) => {
    if (this.state.ooaVo.receiveDateFrmt !== "") {
      this.autoPopulate(e, this.state.ooaVo.receiveDateFrmt);
    }
  };

  autoPopulateLeave = (leaveDate) => {
    let enrollList =
      this.props.enrollData &&
      this.props.enrollData.filter(
        (value) =>
          value.overrideInd === "N" && value.effEndDateFrmt === "99/99/9999"
      );

    //var leaveDate = event.target.value;
    var plan = enrollList && enrollList[0].planDesignation;
    var receiveDate = this.state.ooaVo.receiveDateFrmt;
    var rDate = new Date(receiveDate);
    var a = rDate.getTime();
    var lDate = new Date(leaveDate);
    var b = lDate.getTime();
    let date;
    if (b > a) date = leaveDate;
    else date = receiveDate;
    const reason = this.state.ooaVo.ooaReason;
    const type = this.state.ooaVo.tempPerm;
    if (this.isFldDate9(leaveDate)) {
      if (this.state.ooaVo.tempPerm === "TEMP" && date.trim() !== "") {
        const disEnrollDate = this.setdisenrollDate(date, plan, reason, type);
        this.setState((prevState) => ({
          ooaVo: {
            ...prevState.ooaVo,
            deEffectiveDateFrmt: disEnrollDate,
          },
          modified: true,
        }));
      }
    }
  };

  handleDates = (event) => {



    const fieldId = "#" + event.target.name;
    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        if (e.target.name === "receiveDateFrmt1")
          this.setValue(e, "receiveDateFrmt", e.target.value);
        else this.setValue(e, e.target.name, e.target.value);
      });
  };

  setValue = (e, name, value) => {
    this.setState((prevState) => ({
      ooaVo: {
        ...prevState.ooaVo,
        [name]: handleDateChange(value),
      },
      modified: true,
    }));

    if (name === "receiveDateFrmt") {
      this.autoPopulate(e, "");
    }

    if (name === "returnDateFrmt") {
      this.populateEndDate(value);
    }
    if (name === "leaveDateFrmt") {
      this.autoPopulateLeave(value);
    }
  };
  modalClosed = () => {
    this.setState({ closePopup: false });
  };
  handleChangeRowsPerPage = async (rowsPerPage) => {
    await this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  render() {
    const { classes, dropdowns, enrollData } = this.props;
    const { ooaVo } = this.state;
    let enrollList =
      enrollData &&
      enrollData.filter(
        (value) =>
          value.overrideInd === "N" && value.effEndDateFrmt === "99/99/9999"
      );

    let staticPart = (
      <span>
        {" "}
        <div>
         
          <AutoComplete1
            options={OOA_TYPE}
            handleChange={this.handleChangeSearchSelectAuto}
            value={
              ooaVo.tempPerm
                ? OOA_TYPE.filter((data) => data.value === ooaVo.tempPerm)[0]
                : OOA_TYPE[0]
            }
            defaultValue={OOA_TYPE[0]}
            label="OOA Type"
            width="210px"
            name="tempPerm"
          />
        </div>
        {!this.state.isNewSegment ? (
          <div
            className={classes.buttonContainer}
            style={{ marginLeft: "600px" }}
          >
            <Button
              variant="contained"
              color="primary"
              onClick={this.modelSegment}
              className={classes.button}
            >
              Model Segment
            </Button>

            <Button
              variant="contained"
              color="primary"
              onClick={this.createNewSegment}
              className={classes.button}
            >
              New Segment
            </Button>
            <Button
              variant="contained"
              color="primary"
              onClick={this.update}
              className={classes.button}
              disabled={!this.state.editable}
            >
              Update
            </Button>
          </div>
        ) : null}
      </span>
    );

    let NoDataPart = (
      <div>
        {" "}
       
        <AutoComplete1
          options={OOA_TYPE}
          handleChange={this.handleChangeSearchSelectAuto}
          value={
            ooaVo.tempPerm
              ? OOA_TYPE.filter((data) => data.value === ooaVo.tempPerm)[0]
              : OOA_TYPE[0]
          }
          defaultValue={OOA_TYPE[0]}
          label="OOA Type"
          width="210px"
          disabled={
            this.state.isNewSegment ? this.state.editable : !this.state.editable
          }
          name="tempPerm"
        />
        <Button
          variant="contained"
          color="primary"
          onClick={this.modelSegment}
          className={classes.button}
          disabled={!this.state.editable}
        >
          Model Segment
        </Button>
        <Button
          variant="contained"
          color="primary"
          onClick={this.createNewSegment}
          className={classes.button}
          disabled={this.state.editable}
        >
          New Segment
        </Button>
        <Button
          variant="contained"
          color="primary"
          onClick={this.update}
          className={classes.button}
          disabled={!this.state.editable}
        >
          Update
        </Button>
      </div>
    );

    return (
      <Paper
        elevation={0}
        className={classNames(classes.card, "animated fadeIn")}
      >
        <Modal
          dialogTitle="OOA"
          message={this.state.message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>

        <DataTable
          data={this.state.data ? this.state.data : []}
          header={header}
          sortable={true}
          rowsPerPageOptions={[10, 15, 20]}
          handleChangeRowsPerPage={this.handleChangeRowsPerPage}
          rowsPerPage={this.state.rowsPerPage}
          clicked={this.selectRow}
          index={this.state.selectedIndex}
          pageNo={this.state.page}
          handleChangePage={this.handleChangePage}
          dateColumn={["effStartDateFrmt", "effEndDateFrmt"]}
          subtab
        />

        {
          // !isEmpty(ooaData) && 
          (ooaVo !== undefined) ||
            this.state.isNewSegment
            ? (
              <React.Fragment>
                <form autoComplete="off">
                  <div>
                    {staticPart}
                    <div>
                      <ExpansionPanel
                        square
                        expanded={ooaVo && ooaVo.tempPerm === "TEMP"}
                        onChange={this.handleChangePanel("TEMP")}
                      >
                        <ExpansionPanelSummary className={classes.panelSubhead}>
                          Temporary OOA
                    </ExpansionPanelSummary>
                        <ExpansionPanelDetails>
                          <Typography className={classes.containertypography}>
                            <div>
                              <InputField
                                name="effEndDateFrmt"
                                onClick={this.handleDates}
                                label="End Date"
                                maxLength={10}
                                value={ooaVo.endDateFrmt}
                                onBlur={this.handleOnBlur}
                                onChange={this.handlechange("effEndDateFrmt")}
                                disabled={true}
                              />
                              <div className={classes.validationMessage}></div>
                            </div>
                            <div className="ooaFlex">
                              <div>
                                
                                <AutoComplete1
                                  options={dropdowns.ooaSourceList}
                                  handleChange={this.handleChangeSearchSelectAuto}
                                  value={
                                    dropdowns.ooaSourceList.filter(
                                      (data) => data.value === ooaVo.ooaSource
                                    )[0]
                                  }
                                  defaultValue={dropdowns.ooaSourceList[0]}
                                  fontSize="0.718em"
                                  margin="0px"
                                  width="165px"
                                  label="OOA Source"
                                  disabled={!this.state.editable}
                                  name="ooaSource"
                                />
                                <div className={classes.validationMessage}>
                                  {this.validatorTemp.message(
                                    "Ooa Source",
                                    ooaVo.ooaSource,
                                    "required"
                                  )}
                                </div>
                              </div>
                              {enrollList && enrollList[0] ? (
                                <div>
                                  <InputField
                                    name="receiveDateFrmt"
                                    placeholder="MM/DD/YYYY"
                                    label="Received Date"
                                    required={this.state.editable}
                                    onClick={this.handleDates}
                                    value={ooaVo.receiveDateFrmt}
                                    onChange={this.handlechange("receiveDateFrmt")}
                                    onBlur={this.handleOnBlur}
                                    maxLength={10}
                                    disabled={!this.state.editable}
                                  />
                                  <div className={classes.validationMessage}>
                                    {ooaVo.receiveDateFrmt === ""
                                      ? this.validatorTemp.message(
                                        "ReceivedDate",
                                        ooaVo.receiveDateFrmt,
                                        "required"
                                      )
                                      : enrollList[0].planDesignation === "PDP"
                                        ? this.validatorTemp.message(
                                          "ReceivedDate",
                                          ooaVo.receiveDateFrmt,
                                          [
                                            "date_formats",
                                            "check_Date",
                                            {
                                              received_date_363:
                                                enrollList[0].planDesignation,
                                            },
                                          ]
                                        )
                                        : this.validatorTemp.message(
                                          "ReceivedDate",
                                          ooaVo.receiveDateFrmt,
                                          [
                                            "date_formats",
                                            "check_Date",
                                            {
                                              received_date_180:
                                                enrollList[0].planDesignation,
                                            },
                                          ]
                                        )}
                                  </div>
                                </div>
                              ) : null}
                              <div>
                                <InputField
                                  name="returnDateFrmt"
                                  placeholder="MM/DD/YYYY"
                                  label="Return Date"
                                  onClick={this.handleDates}
                                  onChange={this.handlechange("returnDateFrmt")}
                                  onBlur={this.handleOnBlur}
                                  value={ooaVo.returnDateFrmt}
                                  maxLength={10}
                                  disabled={!this.state.editable}
                                />
                                <div className={classes.validationMessage}>
                                  {this.validatorTemp.message(
                                    "returnDate",
                                    ooaVo.returnDateFrmt,
                                    "date_format"
                                  )}
                                </div>
                              </div>
                            </div>
                            <div className="ooaFlex">
                              <div>
                               
                                <AutoComplete1
                                  options={dropdowns.ooaReasonList}
                                  handleChange={this.handleChangeSearchSelectAuto}
                                  value={
                                    dropdowns.ooaReasonList.filter(
                                      (data) => data.value === ooaVo.ooaReason
                                    )[0]
                                  }
                                  defaultValue={dropdowns.ooaReasonList[0]}
                                  label="OOA Reason"
                                  fontSize="0.718em"
                                  margin="0px"
                                  width="165px"
                                  disabled={!this.state.editable}
                                  name="ooaReason"
                                />
                                <div className={classes.validationMessage}>
                                  {this.validatorTemp.message(
                                    "ooaReason",
                                    ooaVo.ooaReason,
                                    "required"
                                  )}
                                </div>
                              </div>
                              {enrollList && enrollList[0] ? (
                                <div>
                                  <InputField
                                    name="leaveDateFrmt"
                                    placeholder="MM/DD/YYYY"
                                    label="Leave Date"
                                    required={this.state.editable}
                                    onClick={this.handleDates}
                                    onChange={this.handlechange("leaveDateFrmt")}
                                    onBlur={this.handleOnBlur}
                                    value={ooaVo.leaveDateFrmt}
                                    maxLength={10}
                                    disabled={!this.state.editable}
                                  />
                                  <div className={classes.validationMessage}>
                                    {ooaVo.leaveDateFrmt === ""
                                      ? this.validatorTemp.message(
                                        "LeaveDate",

                                        ooaVo.leaveDateFrmt,

                                        "required"
                                      )
                                      : enrollList[0].planDesignation === "PDP"
                                        ? this.validatorTemp.message(
                                          "LeaveDate",

                                          ooaVo.leaveDateFrmt,

                                          [
                                            "date_formats",
                                            {
                                              received_date_363:
                                                enrollList[0].planDesignation,
                                            },
                                          ]
                                        )
                                        : this.validatorTemp.message(
                                          "LeaveDate",

                                          ooaVo.leaveDateFrmt,

                                          [
                                            "date_formats",
                                            {
                                              received_date_180:
                                                enrollList[0].planDesignation,
                                            },
                                          ]
                                        )}
                                  </div>
                                </div>
                              ) : null}
                              <div>
                                <InputField
                                  name="deEffectiveDateFrmt"
                                  label="Disenrollment Eff Date"
                                  value={ooaVo.deEffectiveDateFrmt}
                                  disabled={true}
                                />
                              </div>
                            </div>
                          </Typography>
                        </ExpansionPanelDetails>
                      </ExpansionPanel>
                      <ExpansionPanel
                        square
                        expanded={ooaVo.tempPerm === "PERM"}
                        onChange={this.handleChangePanel("PERM")}
                      >
                        <ExpansionPanelSummary className={classes.panelSubhead}>
                          Permanent OOA
                    </ExpansionPanelSummary>

                        <ExpansionPanelDetails>
                          <Typography className={classes.containertypography}>
                            {
                              //this.state.isNewSegment &&
                              ooaVo.tempPerm === "PERM" ? (
                                <div className={classes.container}>
                                  <div>
                                    <InputField
                                      name="endDateFrmt"
                                      placeholder="MM/DD/YYYY"
                                      label="End date"
                                      value={ooaVo.endDateFrmt}
                                      onChange={this.handlechange("endDateFrmt")}
                                      onBlur={this.handleOnBlur}
                                      onClick={this.handleDates}
                                      inputProps={{ maxLength: 10 }}
                                      disabled={!this.state.editable}
                                    />
                                    <div className={classes.validationMessage}>
                                      {this.validatorPerm.message(
                                        "EndDate",
                                        ooaVo.endDateFrmt,
                                        "date_format"
                                      )}
                                    </div>
                                  </div>

                                  <div>
                                    <InputField
                                      name="receiveDateFrmt1"
                                      placeholder="MM/DD/YYYY"
                                      label="Received Date"
                                      required={this.state.editable}
                                      onClick={this.handleDates}
                                      value={ooaVo.receiveDateFrmt}
                                      onChange={this.handlechange(
                                        "receiveDateFrmt"
                                      )}
                                      onBlur={this.handleOnBlur}
                                      maxLength={10}
                                      disabled={!this.state.editable}
                                    />
                                    <div className={classes.validationMessage}>
                                      {ooaVo.receiveDateFrmt === ""
                                        ? this.validatorPerm.message(
                                          "ReceivedDate",

                                          ooaVo.receiveDateFrmt,

                                          "required"
                                        )
                                        : enrollList[0].planDesignation === "PDP"
                                          ? this.validatorPerm.message(
                                            "ReceivedDate",
                                            ooaVo.receiveDateFrmt,
                                            [
                                              "date_formats",
                                              "check_Date",
                                              {
                                                received_date_363:
                                                  enrollList[0].planDesignation,
                                              },
                                            ]
                                          )
                                          : this.validatorPerm.message(
                                            "ReceivedDate",
                                            this.state.ooaVo.receiveDateFrmt,
                                            [
                                              "date_formats",
                                              "check_Date",
                                              {
                                                received_date_180:
                                                  enrollList[0].planDesignation,
                                              },
                                            ]
                                          )}
                                    </div>
                                  </div>

                                  <div>
                                    <InputField
                                      name="deEffectiveDateFrmt"
                                      label="Disenrollment Eff Date"
                                      value={ooaVo.deEffectiveDateFrmt}
                                      disabled={true}
                                    />
                                    <div
                                      className={classes.validationMessage}
                                    ></div>
                                  </div>

                                  <div className={classes.Margin}>
                                  
                                    <AutoComplete1
                                      options={dropdowns.ooaSourceList}
                                      handleChange={
                                        this.handleChangeSearchSelectAuto
                                      }
                                      value={
                                        dropdowns.ooaSourceList.filter(
                                          (data) => data.value === ooaVo.ooaSource
                                        )[0]
                                      }
                                      defaultValue={dropdowns.ooaSourceList[0]}
                                      label="OOA Source"
                                      disabled={!this.state.editable}
                                      margin="0px"
                                      fontSize="0.718em"
                                      name="ooaSource"
                                    />
                                    <div className={classes.validationMessage}>
                                      {this.validatorPerm.message(
                                        "OoaSource",
                                        ooaVo.ooaSource,
                                        "required"
                                      )}
                                    </div>
                                  </div>
                                  <div>
                                 
                                    <AutoComplete1
                                      options={dropdowns.ooaDeReasonList}
                                      handleChange={
                                        this.handleChangeSearchSelectAuto
                                      }
                                      value={
                                        dropdowns.ooaDeReasonList.filter(
                                          (data) => data.value === ooaVo.deReason
                                        )[0]
                                      }
                                      defaultValue={dropdowns.ooaDeReasonList[0]}
                                      label="Disenrollment Reason"
                                      width="250px"
                                      margin="0px"
                                      fontSize="0.718em"
                                      disabled={!this.state.editable}
                                      name="deReason"
                                    />
                                    <div className={classes.validationMessage}>
                                      {this.validatorPerm.message(
                                        "Disenrollment Reason",
                                        ooaVo.deReason,
                                        "required"
                                      )}
                                    </div>
                                  </div>
                                </div>
                              ) : null
                            }
                          </Typography>
                        </ExpansionPanelDetails>
                      </ExpansionPanel>

                      <HistoryData
                        createTime={ooaVo.createTime}
                        createUserId={ooaVo.createUserId}
                        lastUpdtTime={ooaVo.lastUpdtTime}
                        lastUpdtUserId={ooaVo.lastUpdtUserId}
                        isNewSegment={this.state.isNewSegment}
                        reset={this.createNewSegment}
                        addSegment={this.addNewSegment}
                        back={this.goBack}
                        footer="true"
                      />
                    </div>
                  </div>
                </form>
              </React.Fragment>
            ) : (
              <React.Fragment>{NoDataPart}</React.Fragment>
            )}
      </Paper>
    );
  }
}

const mapStateToProps = (state) => ({
  memberIdCheck: state.memberSearch.memberId,
  ooaData: state.memberSearch.searchResultsVo.mbrOoaInfoList,
  enrollData: state.memberSearch.searchResultsVo.mbrEnrollmentList,
  dropdowns: state.membercache,
  searchResultsVo: state.memberSearch.searchResultsVo,
  mbrSearchCriteria: state.memberSearch.mbrSearchCriteria,
  showAllActiveInd: state.memberSearch.showAllActiveIndi,
});

const mapDispatchToProps = {
  getOoaData,
  updateOoa,
  getShowAll,
  updateIndOOAData,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(OOA));
