import * as ActionTypes from "../../redux/types/ActionType";
import * as DateUtil from "../../utils/DatePicker";
import * as Type from "../../constants/ConfirmType";

import React, { Component } from "react";
import Autocomplete1 from "../UI/Select";
import {
  deleteBillingData,
  getBillingData,
  updateBillingData,
  getShowAll,
  updateIndbillingData,
} from "../../redux/actions/MemberActions";

import ConfirmBox from "../../utils/PopUp";
import DataTable from "../Home/DataTable";
import HistoryData from "../UI/MemberHistory";
import InputField from "../UI/InputField";
import MemberButtonPanel from "../UI/MemberButtonPanel";
import Modal from "../../components/UI/Modal/Modal";
import Paper from "@material-ui/core/Paper";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../assets/styles/Theme";
import classNames from "classnames";
import { connect } from "react-redux";
import { handleDateChange } from "../../utils/DateFormatter";
import { BILLING_HEADER as header } from "../../constants/Headers/MemberHeaders";
import { customValidations } from "../../utils/CustomValidations";
import { withStyles } from "@material-ui/core/styles";
import isEmpty from "lodash/isEmpty";
import { messages } from "../../constants/Messages";

const INITIAL_STATE = {
  customerId: "",
  memberId: "",
  billLastName: "",
  billFirstName: "",
  billMiddleInit: "",
  billSuffix: "",
  billPayMethod: "",
  billPayMethodDesc: null,
  abaRoutingNbr: "",
  bankAcctNbr: "",
  bankName: "",
  accountType: "",
  accountTypeDesc: null,
  nameOnAct: "",
  draftDay: "",
  draftOverrideAmt: "0.00",
  billFrequency: "M",
  billFrequencyDesc: null,
  overrideInd: "N",
  effStartDate: "",
  effEndDate: "",
  createTime: "",
  createUserId: "",
  lastUpdtTime: "",
  lastUpdtUserId: "",
  billingDataExists: null,
  listBilling: null,
  type: "",
  effStartDateFrmt: "",
  effEndDateFrmt: "99/99/9999",
  showAll: "",
};

class Billing extends Component {
  constructor(props) {
    super(props);

    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
        date_format99: customValidations.date_format99,
        last_day_of_month: customValidations.last_day_of_month99,
        date_after99: customValidations.c_after99,
        date_after: customValidations.c_after,
        draft_day: customValidations.draft_day,
      },
    });
    this.accountTypeChange = this.accountTypeChange.bind(this);
    this.state = {
      onload: true,
      billingVo: { ...INITIAL_STATE },
      oldmemberID: INITIAL_STATE.memberId,
      modified: false,
      isNewSegment: false,
      //showAllActive: true,
      editable: false,
      selectedIndex: 0,
      page: 0,
      showAllData: null,
      closePopup: false,
      data: null,
      rowsPerPage: 10,
      func1: this.showAll.bind(this),
      showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
    };
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.mbrSearchCriteria.memberId !== prevState.memberId) {
      if (!isEmpty(nextProps.billingData)) {
        return {
          data: nextProps.billingData,
          billingVo: nextProps.billingData[0],
          showAllData: null,
          //showAllActive: true,
          memberId: nextProps.mbrSearchCriteria.memberId,
          modified: false,
          isNewSegment: false,
          editable: false,
          model: prevState.func1(
            nextProps.showAllActiveInd.showAllActiveInd === false ? true : "N",
            nextProps.mbrSearchCriteria.memberId
          ),
        };
      }
      let onload = prevState.onload
        ? {}
        : {
          model: prevState.func1(
            nextProps.showAllActiveInd.showAllActiveInd === false
              ? true
              : "N",
            nextProps.mbrSearchCriteria.memberId
          ),
        };
      return {
        billingVo: INITIAL_STATE,
        data: [],
        showAllData: null,
        // showAllActive: true,
        modified: false,
        isNewSegment: false,
        editable: false,
        selectedIndex: 0,
        memberId: nextProps.mbrSearchCriteria.memberId,
        onload: false,
        ...onload,
      };
    }
    if (
      nextProps.showAllActiveInd.showAllActiveInd !== prevState.showAllActiveInd
    ) {
      if (nextProps.showAllActiveInd.showAllActiveInd === false) {
        return {
          model: prevState.func1(true, nextProps.mbrSearchCriteria.memberId),
        };
      } else {
        return {
          model: prevState.func1(false, nextProps.mbrSearchCriteria.memberId),
        };
      }
    }

    return null;
  }

  async componentDidMount() {
    if (this.props.showAllActiveInd.showAllActiveInd === false) {
      this.showAll(true, this.props.mbrSearchCriteria.memberId);
    } else if (
      isEmpty(this.props.billingData) &&
      this.props.billingData !== null
    ) {
      const params = this.props.mbrSearchCriteria.memberId + "/N";
      await this.props.getBillingData(params);
      INITIAL_STATE.memberId = this.props.mbrSearchCriteria.memberId;

      const { loginProfile } = this.props;
      const DRAFTDAY = loginProfile.filter((data) => data.label === "DRAFTDAY");
      INITIAL_STATE.draftDay = DRAFTDAY[0].value;
    }

    if (!isEmpty(this.props.billingData)) {
      let billingVo = this.props.billingData[0];

      this.setState({
        billingVo: billingVo,
        data: this.props.billingData,
      });
    }
  }

  // componentDidUpdate(nextProps, prevState) {
  //   if (nextProps.showAllActiveInd.showAllActiveInd!==prevState.showAllActiveInd){
  //     if(nextProps.showAllActiveInd.showAllActiveInd===false){
  //       debugger
  //     // this.setState({
  //     //   model:prevState.func1(true,nextProps.mbrSearchCriteria.memberId)
  //     // })
  //   }else{
  //     debugger
  //     // this.setState({
  //     //     model:prevState.func1(false,nextProps.mbrSearchCriteria.memberId)
  //     //   })
  //     }
  //   }
  // }

  showAll = async (flag, mbrId) => {
    const memberId = mbrId;
    const { showAllData } = this.state;

    if (flag === true) {
      if (showAllData === null) {
        const data = await this.props.getShowAll({
          memberId: memberId + "/Y",
          url: "MEMBER_BILLING_FETCH",
        });
        if (null != data) {
          const selectedVo = !isEmpty(data) ? data[0] : { ...INITIAL_STATE };
          this.setState(() => ({
            billingVo: { ...selectedVo },
            data: data,
            showAllData: data,
            showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
            selectedIndex: 0,
            isNewSegment: false,
            editable: false,
          }));
        }
      } else {
        const billingVo = !isEmpty(showAllData)
          ? showAllData[0]
          : { ...INITIAL_STATE };
        this.setState({
          billingVo: billingVo,
          data: showAllData,
          showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
          selectedIndex: 0,
          isNewSegment: false,
          editable: false,
        });
      }
    } else {
      if (flag === "N") {
        if (
          !isEmpty(this.props.billingData) &&
          this.props.mbrSearchCriteria.memberId === memberId
        ) {
          let recodN = await this.props.billingData.filter(
            (role) => role.overrideInd === "N"
          );
          await this.props.updateIndbillingData(recodN);
        } else {
          const params = memberId + "/N";
          await this.props.getBillingData(params);
        }
      } else {
        let recodN = await (this.state.data === null
          ? []
          : this.state.data.filter((role) => role.overrideInd === "N"));

        await this.props.updateIndbillingData(recodN);
      }
      const { billingData } = this.props;
      const selectedVo = !isEmpty(billingData)
        ? billingData[0]
        : { ...INITIAL_STATE };
      this.setState(() => ({
        billingVo: { ...selectedVo },
        data: billingData,
        showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
        selectedIndex: 0,
        isNewSegment: false,
        editable: false,
      }));
    }
  };

  selectRow = (index) => {
    const selectedVo = this.state.data[index];
    this.setState(() => ({
      billingVo: { ...selectedVo }, // copy data
      billingOldVo: { ...selectedVo },
      editable: false, // readOnly
      isNewSegment: false, //Not a new SEgment
      selectedIndex: index,
      modified: false, // Disabled update button
    }));
  };

  handlechange = (event) => {
    let value = event.target.value.toUpperCase();

    let name = event.target.name;

    this.setState((prevState) => ({
      billingVo: {
        ...prevState.billingVo,
        [name]: value,
      },
      modified: true, // enable update button
    }));
  };

  handleOnBlur = (event) => {
    let value = event.target.value.trim();
    let name = event.target.name;

    this.setState((prevState) => ({
      billingVo: {
        ...prevState.billingVo,
        [name]: value,
      },
      modified: true, // enable update button
    }));
  };

  handleDecimalChange = (name) => (event) => {
    let value = event.target.value.replace(/[^0-9]/g, ".").trim();
    this.setState((prevState) => ({
      billingVo: {
        ...prevState.billingVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleNumberChange = (name) => (event) => {
    var twoPlacedFloat = parseFloat(event.target.value).toFixed(2);
    if (twoPlacedFloat !== "NaN" || this.state.billingVo[name].length === 1) {
      let value = event.target.value;
      this.setState((prevState) => ({
        billingVo: {
          ...prevState.billingVo,
          [name]: value.replace(/[^0-9]/g, ""),
        },
        modified: true,
      }));
    }
  };

  handleNumberChangeDraft = (name) => (event) => {
    let value = event.target.value.replace(/[^0-9]/g, "").trim();
    this.setState((prevState) => ({
      billingVo: {
        ...prevState.billingVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleStartDate = (event) => {
    var self = this;
    const fieldId = "#" + event.target.name;
    DateUtil.getStartDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        self.setValue(e.target.name, e.target.value);
      });
  };

  handleDates = (fieldId) => {
    var self = this;
    DateUtil.getDatePicker(fieldId).on("change", (e) => {
      self.setValue(e.target.name, e.target.value);
    });
  };

  setValue = (name, value) => {
    this.setState((prevState) => ({
      billingVo: {
        ...prevState.billingVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleDate = (event) => {
    let value = event.target.value;
    let name = event.target.name;
    this.setState((prevState) => ({
      billingVo: {
        ...prevState.billingVo,
        [name]: handleDateChange(value),
      },
      modified: true,
    }));
  };

  accountTypeChange = () => {
    this.setState((prevState) => ({
      billingVo: {
        ...prevState.billingVo,
        bankName: "",
        nameOnAct: "",
        abaRoutingNbr: "",
        bankAcctNbr: "",
      },
      modified: true,
    }));
  };

  handleChangeSearchSelectAuto = (data, name) => {
    let value = data ? data.value : " ";
    this.setState((prevState) => ({
      billingVo: {
        ...prevState.billingVo,
        [name]: value,
      },
      modified: true,
    }));

    if (name === "accountType" && value === "") {
      this.accountTypeChange();
    }
  };

  modelSegment = () => {
    if (this.state.billingVo.overrideInd === "Y") {
      let msg = "This Record is not active ";
      this.setState({ message: msg, closePopup: true });
    } else {
      this.setState({
        editable: true, // Editable
        isNewSegment: false, // Not a new Segment
      });
    }
  };

  createNewSegment = () => {
    this.validator.hideMessages();
    INITIAL_STATE.memberId = this.props.mbrSearchCriteria.memberId;

    this.setState({
      editable: true, //editable
      isNewSegment: true, //new SEgment
      billingVo: {
        ...INITIAL_STATE, // marked all fields as Empty
      },
    });
  };

  update = (event) => {
    event.preventDefault();
    let check = true;
    if (this.state.billingVo.billPayMethod === "D") {
      check = this.validator.allValid();
    }
    if (check && this.checkValidation()) {
      ConfirmBox(this.confirmUpdate, Type.UPDATE, this.props);
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  confirmUpdate = async () => {
    const { billingVo } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(billingVo.showAll = val),
    });
    let status = await this.props.updateBillingData(this.state.billingVo);

    if ("success" === status) {
      status = messages.UPDATED_SUCCESSFULLY;
      this.setState(() => ({
        message: status,
        isNewSegment: false,
        editable: false,
        modified: false,
        billingVo: this.props.billingData[this.state.selectedIndex],
        data: this.props.billingData,
        showAllData: null,
        closePopup: true,
      }));
    } else {
      this.setState(() => ({
        message: status,

        closePopup: true,
      }));
    }

    this.validator.hideMessages();
  };
  checkValidation = () => {
    let fields = { ...this.validator.fields };
    if (this.state.billingVo.billPayMethod !== "D") {
      delete fields["NameOnAccount"];
      delete fields["abaRoutingNbr"];
      delete fields["accountType"];
      delete fields["bankAcctNbr"];
      delete fields["bankName"];
      for (const property in fields) {
        if (!fields[property]) {
          return false;
        }
      }
    }
    return true;
  };
  addNewSegment = () => {
    let check = true;
    if (this.state.billingVo.billPayMethod === "D") {
      check = this.validator.allValid();
    }
    if (check && this.checkValidation()) {
      ConfirmBox(this.confirmAddNewSegment, Type.ADD, this.props);
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  confirmAddNewSegment = async () => {
    const { billingVo } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(billingVo.showAll = val),
    });
    const status = await this.props.updateBillingData(this.state.billingVo);
    let message = "";

    if (status === "success") {
      message = ActionTypes.ADD;
      this.setState({
        isNewSegment: false,
        editable: false,
        modified: false,
        billingVo: this.props.billingData[0],
        data: this.props.billingData,
        closePopup: true,
        message: message,
        selectedIndex: 0,
        showAllData: null,
      });
    } else {
      message = status;
      this.setState({
        closePopup: true,
        message: message,
      });
    }

    this.validator.hideMessages();
  };

  delete = () => {
    if (this.state.billingVo.overrideInd === "Y") {
      let msg = "This Record is not active ";
      this.setState({ message: msg, closePopup: true });
    } else {
      ConfirmBox(this.confirmDelete, Type.DELETE, this.props);
    }
  };
  confirmDelete = async () => {
    const { billingVo } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(billingVo.showAll = val),
    });
    const status = await this.props.deleteBillingData(billingVo);
    let newVO = isEmpty(this.props.billingData)
      ? INITIAL_STATE
      : this.props.billingData[0];

    let message = "";
    if (status === "success") {
      message = ActionTypes.DELETE;
    } else {
      message = status;
    }

    this.setState({
      billingVo: newVO,
      data: this.props.billingData,
      showAllData: null,
      closePopup: true,
      message: message,
      selectedIndex: 0,
      isNewSegment: false,
      editable: false,
      modified: false,
    });
    this.validator.hideMessages();
  };

  handleChangePage = (index) => {
    this.selectRow(index);
  };

  goBack = () => {
    const index = this.state.selectedIndex;
    const { billingData } = this.props;
    let billingVo = INITIAL_STATE;

    if (!isEmpty(billingData)) {
      billingVo = this.props.billingData[index];
    }

    this.setState({
      isNewSegment: false,
      editable: false,
      modified: false,
      billingVo: billingVo,
    });
  };

  modalClosed = () => {
    this.setState({ closePopup: false });
  };
  handleChangeRowsPerPage = async (rowsPerPage) => {
    await this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  render() {
    const { classes, loading, dropdowns } = this.props;
    const { billingVo, editable, data } = this.state;
    //Button Panel  After Data Table

    let ButtonPanel = (
      <MemberButtonPanel
        isNewSegment={this.state.isNewSegment}
        //showAll={this.showAll}
        //toggleLabel={this.state.showAllActive}
        newSegment={this.createNewSegment}
        modelSegment={this.modelSegment}
        modified={this.state.modified}
        editable={editable}
        delete={this.delete}
        update={this.update}
        disable={isEmpty(this.state.data)}
      />
    );
    return (
      <React.Fragment>
        <Modal
          dialogTitle="BILLING"
          message={this.state.message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Paper
          elevation={0}
          className={classNames(classes.card, "animated fadeIn")}
        >
          {loading && <div id="cover-spin" />}

          <DataTable
            data={data ? data : []}
            header={header}
            rowsPerPage={this.state.rowsPerPage}
            clicked={this.selectRow}
            index={this.state.selectedIndex}
            pageNo={this.state.page}
            sortable={true}
            rowsPerPageOptions={[10, 15, 20]}
            handleChangeRowsPerPage={this.handleChangeRowsPerPage}
            handleChangePage={this.handleChangePage}
            dateColumn={["effStartDateFrmt", "effEndDateFrmt"]}
            subtab
          />

          {!isEmpty(data) || this.state.isNewSegment ? (
            <React.Fragment>
              <form autoComplete="off">
                <div className={classes.buttonContainer}> {ButtonPanel}</div>

                <div class="panel-body margin-top1">
                  <div className={classes.containerdemo}>
                    <div className={classes.Select1}>
                      <Autocomplete1
                        handleChange={this.handleChangeSearchSelectAuto}
                        label="Bill Pay Method"
                        options={dropdowns.validBillPayMethod}
                        defaultValue={dropdowns.validBillPayMethod[0]}
                        value={
                          dropdowns.validBillPayMethod.filter(
                            (data) => data.value === billingVo.billPayMethod
                          )[0]
                        }
                        name="billPayMethod"
                        disabled={!this.state.editable}
                        width="372px"
                        margin="0px"
                      />

                      <div className={classes.validationMessageSelect}>
                        {this.validator.message(
                          "Bill Pay Method",
                          billingVo.billPayMethod.trim(),
                          "required"
                        )}
                      </div>
                    </div>

                    <div>
                      <InputField
                        name="effStartDateFrmt"
                        placeholder="MM/DD/YYYY"
                        onClick={this.handleStartDate}
                        required={editable}
                        label="Eff Start Date"
                        value={billingVo.effStartDateFrmt}
                        onChange={this.handleDate}
                        onBlur={this.handleOnBlur}
                        maxLength="10"
                        disabled={!editable}
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "StartDate",
                          billingVo.effStartDateFrmt,
                          "required|date_format"
                        )}
                      </div>
                    </div>

                    <div>
                      <InputField
                        name="effEndDateFrmt"
                        required={editable}
                        placeholder="MM/DD/YYYY"
                        onClick={this.handleDates("#effEndDateFrmt")}
                        label="Eff End Date"
                        value={billingVo.effEndDateFrmt}
                        onChange={this.handleDate}
                        onBlur={this.handleOnBlur}
                        maxLength="10"
                        disabled={!editable}
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "EndDate",

                          billingVo.effEndDateFrmt,
                          [
                            "required",
                            "date_format99",
                            "last_day_of_month",
                            { date_after99: billingVo.effStartDateFrmt },
                          ]
                        )}
                      </div>
                    </div>
                    <div>
                      <InputField
                        name="overrideInd"
                        label="Override"
                        value={billingVo.overrideInd}
                        onChange={this.handlechange}
                        disabled
                      />
                      <div className={classes.validationMessage}></div>
                    </div>

                    <div>
                      <InputField
                        name="nameOnAct"
                        label="Name On Account"
                        value={billingVo.nameOnAct}
                        onChange={this.handlechange}
                        onBlur={this.handleOnBlur}
                        maxLength={50}
                        disabled={!editable}
                      />

                      <div className={classes.validationMessage}>
                        {billingVo.billPayMethod === "D" ? (
                          <div>
                            {this.validator.message(
                              "NameOnAccount",
                              billingVo.nameOnAct,
                              "required"
                            )}
                          </div>
                        ) : null}
                      </div>
                    </div>

                    <div>
                      <InputField
                        name="billFirstName"
                        label="Billing First Name"
                        value={billingVo.billFirstName}
                        onChange={this.handlechange}
                        onBlur={this.handleOnBlur}
                        maxLength={24}
                        disabled={!editable}
                      />
                      <div className={classes.validationMessage}></div>
                    </div>
                    <div>
                      <InputField
                        name="billMiddleInit"
                        label="Billing Middle Name"
                        value={billingVo.billMiddleInit}
                        onChange={this.handlechange}
                        onBlur={this.handleOnBlur}
                        maxLength={1}
                        disabled={!editable}
                      />
                      <div className={classes.validationMessage}></div>
                    </div>
                    <div>
                      <InputField
                        name="billLastName"
                        label="Billing Last Name"
                        value={billingVo.billLastName}
                        onChange={this.handlechange}
                        onBlur={this.handleOnBlur}
                        maxLength={35}
                        disabled={!editable}
                      />
                      <div className={classes.validationMessage}></div>
                    </div>

                    <div>
                      <InputField
                        name="draftDay"
                        label="Draft day"
                        value={billingVo.draftDay}
                        onChange={this.handleNumberChangeDraft("draftDay")}
                        onBlur={this.handleOnBlur}
                        maxLength={2}
                        disabled={!editable}
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "Draft day",
                          billingVo.draftDay,
                          "required|draft_day"
                        )}
                      </div>
                    </div>

                    <div>
                      <InputField
                        name="draftOverrideAmt"
                        label="Draft Ovrd Amt"
                        value={billingVo.draftOverrideAmt}
                        // onChange={this.handleDecimalChange("draftOverrideAmt")}
                        onChange={this.handleNumberChange("draftOverrideAmt")}
                        onBlur={this.handleOnBlur}
                        maxLength={10}
                        disabled={!editable}
                        placeholder="0.00"
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "Draft Override Amt",
                          billingVo.draftOverrideAmt,
                          "required"
                        )}
                      </div>
                    </div>

                    <div>
                      <InputField
                        name="bankName"
                        label="Bank Name"
                        value={billingVo.bankName}
                        onChange={this.handlechange}
                        onBlur={this.handleOnBlur}
                        maxLength={30}
                        disabled={!editable}
                      />
                      <div />

                      <div className={classes.validationMessage}>
                        {billingVo.billPayMethod === "D" ? (
                          <div>
                            {this.validator.message(
                              "bankName",
                              billingVo.bankName,
                              "required"
                            )}
                          </div>
                        ) : null}
                      </div>
                    </div>

                    <div className={classes.Select2}>
                      <Autocomplete1
                        handleChange={this.handleChangeSearchSelectAuto}
                        label="Account Type"
                        options={dropdowns.validAccountType}
                        defaultValue={dropdowns.validAccountType[0]}
                        value={
                          dropdowns.validAccountType.filter(
                            (data) => data.value === billingVo.accountType
                          )[0]
                        }
                        name="accountType"
                        disabled={!this.state.editable}
                        width="158px"
                        margin="0px"
                      />
                      <div className={classes.validationMessage}>
                        {billingVo.billPayMethod === "D" ? (
                          <div>
                            {this.validator.message(
                              "accountType",
                              billingVo.accountType.trim(),
                              "required"
                            )}
                          </div>
                        ) : null}
                      </div>
                    </div>
                  </div>
                  <div className={classes.containerdemo}>
                    <div>
                      <InputField
                        name="abaRoutingNbr"
                        label="ABA Routing Nbr"
                        value={billingVo.abaRoutingNbr}
                        onChange={this.handleNumberChange("abaRoutingNbr")}
                        onBlur={this.handleOnBlur}
                        maxLength="9"
                        disabled={!editable}
                      />
                      <div className={classes.validationMessage}>
                        {billingVo.billPayMethod === "D" ? (
                          <div>
                            {this.validator.message(
                              "abaRoutingNbr",
                              billingVo.abaRoutingNbr,
                              "required"
                            )}
                          </div>
                        ) : null}
                      </div>
                    </div>

                    <div>
                      <InputField
                        name="bankAcctNbr"
                        label="Bank Acct Nbr"
                        value={billingVo.bankAcctNbr}
                        onChange={this.handleNumberChange("bankAcctNbr")}
                        onBlur={this.handleOnBlur}
                        maxLength={17}
                        disabled={!editable}
                      />

                      <div className={classes.validationMessage}>
                        {billingVo.billPayMethod === "D" ? (
                          <div>
                            {this.validator.message(
                              "bankAcctNbr",
                              billingVo.bankAcctNbr,
                              "required"
                            )}
                          </div>
                        ) : null}
                      </div>
                    </div>

                    <div className={classes.Select2}>
                      <Autocomplete1
                        handleChange={this.handleChangeSearchSelectAuto}
                        label="Billing Frequency"
                        options={dropdowns.validBillFrequency}
                        defaultValue={dropdowns.validBillFrequency[0]}
                        value={
                          dropdowns.validBillFrequency.filter(
                            (data) => data.value === billingVo.billFrequency
                          )[0]
                        }
                        name="billFrequency"
                        disabled={!this.state.editable}
                        width="158px"
                        margin="0px"
                      />
                      <div className={classes.validationMessage}>
                        <div>
                          {this.validator.message(
                            "billFrequency",
                            billingVo.billFrequency.trim(),
                            "required"
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
              <HistoryData
                createTime={billingVo.createTime}
                createUserId={billingVo.createUserId}
                lastUpdtTime={billingVo.lastUpdtTime}
                lastUpdtUserId={billingVo.lastUpdtUserId}
                isNewSegment={this.state.isNewSegment}
                reset={this.createNewSegment}
                addSegment={this.addNewSegment}
                back={this.goBack}
                footer="true"
              />
            </React.Fragment>
          ) : (
              <div className={classes.buttonContainer}> {ButtonPanel}</div>
            )}
        </Paper>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  billingData: state.memberSearch.searchResultsVo.mbrBillingList,
  searchResultsVo: state.memberSearch.searchResultsVo,
  mbrSearchCriteria: state.memberSearch.mbrSearchCriteria,
  dropdowns: state.membercache,
  memberIdCheck: state.memberSearch.memberId,
  loginProfile: state.loginData.profiles,
  showAllActiveInd: state.memberSearch.showAllActiveIndi,
});

const mapDispatchToProps = {
  getBillingData,
  deleteBillingData,
  updateBillingData,
  getShowAll,
  updateIndbillingData,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(Billing));
