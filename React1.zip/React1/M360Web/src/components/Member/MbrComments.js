import "../../assets/css/comments.css";

import * as ActionTypes from "../../redux/types/ActionType";

import { PresetNotes, fetchCacheData } from "../../redux/actions/ApplActions";
import React, { Component } from "react";
import Autocomplete1 from "../UI/Select";
import {
  getCommentData,
  submitComment,
} from "../../redux/actions/MemberActions";

import Button from "@material-ui/core/Button";
import DataTable from "../Home/DataTable";
import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import HistoryData from "../UI/MemberHistory";
import InputField from "../UI/InputField";
import Modal from "../../components/UI/Modal/Modal";
import Paper from "@material-ui/core/Paper";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../assets/styles/Theme";
import TextField from "@material-ui/core/TextField";
import classNames from "classnames";
import { connect } from "react-redux";
import { MEMBER_COMMENTS_HEADER as header } from "../../constants/Headers/MemberHeaders";
import { withStyles } from "@material-ui/core/styles";
import isEmpty from "lodash/isEmpty";

const INITIAL_STATE = {
  presetNotes: "",
  created: "",
  user: "",
  comments: "",
  editable: true,
  presetNotes1: "",
  presetNotes2: "",
  memberId: "",
};

class MbrComments extends Component {
  constructor(props) {
    super(props);

    this.state = {
      editable: false,
      selectedIndex: 0,
      page: 0,
      commentsVo: INITIAL_STATE,
      modified: false,
      radioSelected: "",
      isNewSegment: false,
      presetNotesSelected: false,
      data: [],
      value: "",
      radio: "",
      presetKey: "",
      comment: "",
      disableComments: false,
      closePopup: false,
      rowsPerPage: 10,
    };

    this.validator = new SimpleReactValidator();
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.mbrSearchCriteria.memberId !== prevState.memberId) {
      if (!isEmpty(nextProps.getComments)) {
        return {
          commentsVo: nextProps.getComments[0],
          data: nextProps.getComments,
          modified: false,
          isNewSegment: false,
          editable: false,
          selectedIndex: 0,
          memberId: nextProps.mbrSearchCriteria.memberId,
          disableComments: false,
          presetNotesSelected: false,
        };
      }
      return {
        commentsVo: INITIAL_STATE,
        data: [],
        modified: false,
        isNewSegment: false,
        editable: false,
        selectedIndex: 0,
        memberId: nextProps.mbrSearchCriteria.memberId,
      };
    }

    return null;
  }

  async componentDidMount() {
    if (Object.keys(this.props.dropdowns).length === 0) {
      await this.props.fetchCacheData();
    }

    if (isEmpty(this.props.getComments) && this.props.getComments !== null) {
      await this.props.getCommentData(this.props.mbrSearchCriteria.memberId);
      INITIAL_STATE.memberId = this.props.mbrSearchCriteria.memberId;
    }

    if (!isEmpty(this.props.getComments)) {
      let commentsVo = this.props.getComments[0];

      this.setState({
        commentsVo: commentsVo,
        data: this.props.getComments,
      });
    }
  }

  selectRow = (index) => {
    const selectedVo = this.state.data[index];
    this.setState(() => ({
      commentsVo: { ...selectedVo },
      selectedIndex: index,
      editable: false,
      isNewSegment: false,
      presetNotesSelected: false,
      modified: false,
      disableComments: true, // Disabled update button
    }));
  };

  handlechange = (name) => (event) => {
    let value = event.target.value.toUpperCase();
    this.setState((prevState) => ({
      commentsVo: {
        ...prevState.commentsVo,
        [name]: value.toUpperCase(),
      },
      modified: true,
    }));
  };

  handleOnBlur = (event) => {
    let value = event.target.value.trim();
    let name = event.target.name;

    this.setState((prevState) => ({
      commentsVo: {
        ...prevState.commentsVo,
        [name]: value,
      },
      comment: name === "comment" ? value : prevState.comment,
      modified: true,
    }));
  };

  handleRadiochange = (event) => {
    this.setState({ radio: event.target.value });

    if(isEmpty(this.state.commentsVo.presetNotes) && event.target.value==="D"){
     alert("Please select a value from dropdown to be delete")
      
    }
    if(isEmpty(this.state.commentsVo.presetNotes) && event.target.value==="M"){
      alert("Please select a value from dropdown to be modified")
     
    }
  }

  handleChangeSearchSelect = (name) => (event) => {
    let data = event;
    this.setState((prevState) => ({
      commentsVo: {
        ...prevState.commentsVo,
        [name]: data.value,
        presetNotes1: data.label,
        presetNotes2: data.value,
      },
      presetKey: data.label,
      modified: true,
      comment: data.label + " : " + data.value + " : ",
    }));
  };

  goBack = () => {
    const index = this.state.selectedIndex;
    const { getComments } = this.props;
    let commentsVo = INITIAL_STATE;

    if (!isEmpty(getComments)) {
      commentsVo = this.props.getComments[index];
    }
    this.setState({
      isNewSegment: false,
      editable: false,
      modified: false,
      commentsVo: commentsVo,
      presetNotesSelected: false,
      disableComments: false,
    });
  };

  createNewSegment = () => {
    this.setState({
      comment: "",
      value: "",
      editable: false,
      presetNotesSelected: false,
      isNewSegment: true,
      disableComments: true,
      commentsVo: {
        ...this.state.commentsVo,
        ...INITIAL_STATE,
      },
    });
  };

  addNewSegment = async () => {
    const comment = {
      memberId: this.props.mbrSearchCriteria.memberId,
      mbrComments: this.state.comment,
      createUserId: this.props.loginVo.userId,
    };
    if (this.state.comment === "") {
      alert("No Comments Updated");
    } else {
      await this.props.submitComment(comment);
      await this.setState({
        comment: "",
        selectedIndex: 0,
        editable: false,
        isNewSegment: false,
        modified: false,
        closePopup: true,
        message: ActionTypes.ADD,
        data: this.props.getComments,
      });
    }
  };
  presetNotes = () => {
    this.setState({
      editable: true,
      presetNotesSelected: true,
      isNewSegment: false,
      commentsVo: {
        ...this.state.commentsVo,
        ...INITIAL_STATE,
      },
    });
  };

  handleChangePage = (index) => {
    this.setState({ selectedIndex: index });
    const selectedVo = this.state.data[index];
    this.setState(() => ({
      commentsVo: { ...selectedVo },
      selectedIndex: index,
      editable: false,
      isNewSegment: false,
      presetNotesSelected: false,
      modified: false,
      disableComments: true, // Disabled update button
    }));
  };

  handleChangeSearchSelectAuto = (data, name) => {
    this.setState((prevState) => ({
      commentsVo: {
        ...prevState.commentsVo,
        [name]: data.value,
        presetNotes1: data.label,
        presetNotes2: data.value,
      },
      presetKey: data.label,
      modified: true,
      comment: data.label + " : " + data.value + " : ",
    }));
  };
  Update = async (event) => {
    event.preventDefault();

    let commentsVo = this.state.commentsVo;
    if (this.state.radio === "") {
      this.setState({
        closePopup: true,
        message: "No Radio Button Chosen",
      });
    }
   
   

    if (this.state.radio === "A") {
      if (commentsVo.presetNotes1 !== "" && commentsVo.presetNotes2 !== "") {
        await this.props.PresetNotes(
          this.state.radio,
          commentsVo.presetNotes1,
          commentsVo.presetNotes2,
          commentsVo.presetNotes
        );
        await this.setState({ closePopup: true, message: ActionTypes.ADD });
      } else {
        alert("Please Enter Preset Note Description");
        return true;
      }

      this.setState({ radio: "" });

      await this.setState({
        presetNotesSelected: false,
        commentsVo: {
          ...this.state.commentsVo,
          presetNotes: "",
        },
      });
    } else if (this.state.radio === "M") {
      if(isEmpty(commentsVo.presetNotes)){
        alert("Please select a value from dropdown to be modified")
      
      }else{

      
      await this.props.PresetNotes(
        this.state.radio,
        commentsVo.presetNotes1,
        commentsVo.presetNotes2,
        this.state.presetKey
      );

      await this.setState({
        radio: "",
        presetNotesSelected: false,
        closePopup: true,
        message: ActionTypes.UPDATE,
        commentsVo: {
          ...this.state.commentsVo,
          presetNotes: "",
        },
      });
    }
    } else if (this.state.radio === "D") {
      if(isEmpty(commentsVo.presetNotes)){
       alert("Please select a value from dropdown to be delete")
       
      }else{

     
      await this.props.PresetNotes(
        this.state.radio,
        commentsVo.presetNotes1,
        commentsVo.presetNotes2,
        this.state.presetKey
      );

      await this.setState({
        radio: "",
        presetNotesSelected: false,
        closePopup: true,
        message: ActionTypes.DELETE,
        commentsVo: {
          ...this.state.commentsVo,
          presetNotes: "",
        },
      });
    }
    }
  };

  Fieldchange = (e) => {
    this.setState({ comment: e.target.value });
  };

  modalClosed = () => {
    this.setState({ closePopup: false });
  };
  handleChangeRowsPerPage = async (rowsPerPage) => {
    await this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  render() {
    const { classes, dropdowns, getComments, servicesEnabled } = this.props;
    const { commentsVo, data, presetNotesSelected } = this.state;

    let ButtonPanel = (
      <div>
        {servicesEnabled.includes("EEUM") ? (
          <Button
            variant="contained"
            color="primary"
            onClick={this.presetNotes}
            className={classes.button}
          >
            Preset Notes
          </Button>
        ) : null}
        {servicesEnabled.includes("EEUM") ? (
          <Button
            variant="contained"
            color="primary"
            onClick={this.createNewSegment}
            className={classes.button}
          >
            New Comment
          </Button>
        ) : null}
        {servicesEnabled.includes("EEUM") ? (
          <Button
            variant="contained"
            color="primary"
            onClick={this.Update}
            className={classes.button}
            disabled={!this.state.editable}
          >
            Update
          </Button>
        ) : null}
      </div>
    );

    return (
      <React.Fragment>
        <Modal
          dialogTitle="Comments"
          message={this.state.message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Paper
          elevation={0}
          className={classNames(classes.card, "animated fadeIn")}
        >
          {data ? (
            <DataTable
              data={data}
              header={header}
              sortable={true}
              rowsPerPageOptions={[10, 15, 20]}
              handleChangeRowsPerPage={this.handleChangeRowsPerPage}
              rowsPerPage={this.state.rowsPerPage}
              clicked={this.selectRow}
              index={this.state.selectedIndex}
              pageNo={this.state.page}
              handleChangePage={this.handleChangePage}
              subtab
            />
          ) : null}

          {(!isEmpty(data) && dropdowns) ||
            this.state.isNewSegment ||
            presetNotesSelected === true ? (
              <React.Fragment>
                <div className={classes.buttonContainer}>{ButtonPanel}</div>

                <div class="panel-body margin-top1">
                  <div class="form-panel">
                    <div style={{ paddingLeft: "24px", width: "580px" }}>
                      {dropdowns.preSetNoteList ? (
                        <Autocomplete1
                          handleChange={this.handleChangeSearchSelectAuto}
                          label="PRESET NOTE"
                          options={dropdowns.preSetNoteList}
                          defaultValue={this.state.isNewSegment? {
                            label: "Select",
                            value: "",
                          } :dropdowns.preSetNoteList[0]}
                          value={
                            commentsVo.presetNotes
                              ? dropdowns.preSetNoteList.filter(
                                (data) => data.value === commentsVo.presetNotes
                              )[0]
                              : dropdowns.preSetNoteList[0]
                          }
                          name="presetNotes"
                          width="570px"
                          margin="0px"
                        />
                      ) : (
                          ""
                        )}
                    </div>
                  </div>
                  {!presetNotesSelected ? (
                    <div>
                      <TextField
                        id="outlined-textarea"
                        placeholder="Enter Comments (Max 255 characters)"
                        name="comment"
                        multiline
                        rows="2"
                        style={{
                          width: "85%",
                          height: "75px",
                          marginBottom: "40px",
                          marginLeft: "0px",
                          backgroundColor: "#FFFFFF",
                          border: "1px solid rgba(81, 203, 238, 1)",
                        }}
                        className={classes.textField}
                        inputProps={{ maxLength: 255 }}
                        onChange={(e) => this.Fieldchange(e)}
                        onBlur={this.handleOnBlur}
                        value={
                          this.state.isNewSegment
                            ? this.state.comment
                            : getComments[this.state.selectedIndex].mbrComments
                        }
                        margin="none"
                        variant="outlined"
                        disabled={this.state.isNewSegment ? false : true}
                      />
                      <div className={classes.commentsValidationMessage} />
                    </div>
                  ) : null}
                  {presetNotesSelected ? (
                    <div>
                      <div className="commentOptionsAppl">
                        <FormControl
                          component="fieldset"
                          className={classes.formControl1}
                        >
                          <RadioGroup
                            row
                            value={this.state.radio}
                            onChange={this.handleRadiochange}
                          >
                            <FormControlLabel
                              // className={classes.formControl1}
                              value="A"
                              control={<Radio color="primary" />}
                              label="Add"
                              id="add"
                              disabled={!presetNotesSelected}
                            // onClick={this.radioCLick}
                            />
                            <FormControlLabel
                              value="M"
                              control={<Radio color="primary" />}
                              label="Modify"
                              id="modify"
                              //onChange={this.handleRadiochange("radioSelected")}
                              disabled={!presetNotesSelected}
                            />

                            <FormControlLabel
                              value="D"
                              control={<Radio color="primary" />}
                              label="Delete"
                              id="delete"
                              //onChange={this.handleRadiochange("radioSelected")}
                              disabled={!presetNotesSelected}
                            />
                          </RadioGroup>
                        </FormControl>
                        <div className={classes.validationMessage}>
                          {presetNotesSelected &&
                            this.state.radioSelected === "Modify"
                            ? this.validator.message(
                              "Preset Note Select",
                              commentsVo.presetNotes,
                              "required"
                            )
                            : null}
                        </div>
                      </div>
                      <br></br>
                      <InputField
                        classes={{ multiline: classes.preset }}
                        name="presetNotes1"
                        id="presetNotes1"
                        label="PRESET NOTE"
                        multiline={true}
                        cols={12}
                        colsMax={12}
                        rows={2}
                        width="570px"
                        rowsMax={2}
                        maxLength={65}
                        value={commentsVo.presetNotes1}
                        onChange={this.handlechange("presetNotes1")}
                        onBlur={this.handleOnBlur}
                        disabled={!this.state.editable}
                        margin="none"
                      />
                      <br></br>
                      <div style={{ paddingLeft: "24px" }}>
                        {" "}
                        <label
                          style={{
                            color: "#053674",
                            marginBottom: "0",
                            lineHeight: "normal",
                            display: "inline-block",
                          }}
                        >
                          PRESET NOTE LONG DESC.
                      </label>
                        <br></br>
                        <TextField
                          id="outlined-textarea"
                          name="presetNotes2"
                          autoFocus
                          placeholder="Enter Description (Max 255 characters)"
                          multiline
                          rows="2"
                          style={{
                            width: "85%",
                            height: "75px",
                            marginBottom: "40px",
                            marginLeft: "0px",
                            backgroundColor: "#FFFFFF",
                            border: "1px solid rgba(81, 203, 238, 1)",
                          }}
                          className={classes.textField}
                          inputProps={{ maxLength: 255 }}
                         defaultValue={commentsVo.presetNotes2}
                          onChange={this.handlechange("presetNotes2")}
                          onBlur={this.handleOnBlur}
                          disabled={!this.state.editable}
                          margin="none"
                          variant="outlined"
                        />
                      </div>
                    </div>
                  ) : null}
                </div>

                <HistoryData
                  createTime={commentsVo.createTime}
                  createUserId={commentsVo.createUserId}
                  lastUpdtTime={commentsVo.lastUpdtTime}
                  lastUpdtUserId={commentsVo.lastUpdtUserId}
                  isNewSegment={this.state.isNewSegment}
                  reset={this.createNewSegment}
                  addSegment={this.addNewSegment}
                  back={this.goBack}
                />
              </React.Fragment>
            ) : (
              <div className={classes.buttonContainer}>{ButtonPanel}</div>
            )}
        </Paper>
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    getComments: state.memberSearch.searchResultsVo.mbrCommentList,
    dropdowns: state.dropdowns,
    mbrSearchCriteria: state.memberSearch.mbrSearchCriteria,
    loginVo: state.loginData.loginVo,
    memberIdCheck: state.memberSearch.memberId,
    servicesEnabled: state.loginData.servicesEnabled,
  };
};
const mapDispatchToProps = {
  getCommentData,
  submitComment,
  PresetNotes,
  fetchCacheData,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(MbrComments));
