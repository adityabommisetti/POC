import React, { Component } from "react";
import {
  COUNTY_TABLE_HEADER as countyheader,
  CITY_TABLE_MEMBER_HEADER as header,
} from "../../constants/Headers/MemberHeaders";

import Button from "@material-ui/core/Button";
import DataTable from "../Home/DataTable";
import InputField from "../UI/InputField";
import Paper from "@material-ui/core/Paper";
import { Styles } from "../../assets/styles/PopUpStyle";
import classNames from "classnames";
import { connect } from "react-redux";
import { searchCityZip } from "../../redux/actions/ApplActions";
import { withStyles } from "@material-ui/core/styles";
import isEmpty from "lodash/isEmpty";

class CityZipSearch extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedVo: {
        city: "",
        state: "",
        county: "",
        countyName: "",
        zip5: this.props.zip5,
        zip4: this.props.zip4 ? this.props.zip4 : "",
      },

      selectedIndex: 0,
      data: null,
    };
  }

  onRowSelect = (index) => {
    this.setState({
      selectedIndex: index,
    });
  };

  loadData = (event) => {
    event.preventDefault();
    this.props.searchCityZip(this.state.selectedVo);
  };
  componentDidMount() {
    setTimeout(() => {
      this.props.searchCityZip(this.state.selectedVo);
    }, 0);
  }
  onSubmit = () => {
    if (this.state.selectedIndex || this.state.selectedIndex === 0) {
      const tableData = [...this.props.data];
      const selectedVo = tableData[this.state.selectedIndex];
      selectedVo.perZip4 = this.state.selectedVo.zip4;
      this.props.setData(selectedVo);
    }

    this.props.close();
  };

  reset = () => {
    this.setState(() => ({
      selectedVo: {
        city: "",
        state: "",
        zip5: "",
        zip4: "",
        county: "",
        countyName: "",
      },
    }));
  };

  handleChange = (e) => {
    let value = e.target.value.replace(/[^0-9]/g, "");
    let id = [e.target.id];

    this.setState((prevState) => ({
      selectedVo: {
        ...prevState.selectedVo,
        [id]: value,
      },
    }));
  };

  handleOnBlur = (e) => {
    let value = e.target.value.replace(/[^0-9]/g, "").trim();
    let id = [e.target.id];

    this.setState((prevState) => ({
      selectedVo: {
        ...prevState.selectedVo,
        [id]: value,
      },
    }));
  };

  render() {
    const { classes, headerLabel } = this.props;
    let dataSet = null;

    if (this.props.data) {
      dataSet = (
        <div className={classes.table}>
          <DataTable
            data={this.props.data}
            header={headerLabel === "City Zip Search" ? header : countyheader}
            rowsPerPage={10}
            sortableHeader={true}
            clicked={this.onRowSelect}
            index={this.state.selectedIndex}
          />
          <div className={classes.div1}>
            <Button
              variant="contained"
              color="primary"
              disabled={isEmpty(this.props.data)}
              className={classNames(classes.button, classes.submit)}
              onClick={this.onSubmit}
            >
              Submit
            </Button>
          </div>
        </div>
      );
    }

    return (
      <React.Fragment>
        <Paper
          className={classes.root}
          elevation={0}
          style={{ padding: "15px" }}
        >
          <fieldset className={classes.fieldset}>
            <legend className={classes.legend}>{headerLabel}</legend>
            <form className={classes.container} autoComplete="off">
              <div className={classes.div1}>
                <InputField
                  required
                  id="zip5"
                  label="Zip 5"
                  className={classes.textField}
                  margin="normal"
                  InputLabelProps={{ className: classes.label }}
                  value={this.state.selectedVo.zip5}
                  maxLength="5"
                  onChange={this.handleChange}
                  onBlur={this.handleOnBlur}
                />

                <InputField
                  id="zip4"
                  label="Zip 4"
                  className={classes.textField}
                  margin="normal"
                  InputLabelProps={{ className: classes.label }}
                  value={this.state.selectedVo.zip4}
                  onChange={this.handleChange}
                  onBlur={this.handleOnBlur}
                  maxLength="4"
                />
              </div>
              {/* <div className={classes.div1}>
                <i
                  className={classNames("fa fa-search", classes.popUpIcons)}
                  onClick={this.loadData}
                />
                <i
                  className={classNames("fa fa-times", classes.popUpIcons)}
                  onClick={this.props.close}
                />
                <i
                  className={classNames("fa fa-refresh", classes.popUpIcons)}
                  onClick={this.reset}
                />
              </div> */}
              <div className={classes.div1}>
                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={this.loadData}
                >
                  <i className="material-icons">search</i>
                </Button>

                <Button
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={this.props.close}
                >
                  <i className="material-icons">cancel</i>
                </Button>
                <Button
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={this.reset}
                >
                  <i class="material-icons">refresh</i>
                </Button>
              </div>
            </form>
          </fieldset>
        </Paper>
        {dataSet}
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => ({
  data: state.applPopupVO.cityZipSearchData,
});

const mapDispatchToProps = {
  searchCityZip,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(CityZipSearch));
