import * as ActionTypes from "../../redux/types/ActionType";
import * as DateUtil from "../../utils/DatePicker";
import * as Type from "../../constants/ConfirmType";

import {
  DRUG_EDIT_CODE,
  STATUS_FLAG,
} from "./../../constants/SelectStaticData";
import React, { Component } from "react";
import Autocomplete1 from "../UI/Select";
import {
  deletePos,
  filterPos,
  getPos,
  getShowAll,
  insetUpdatePos,
  updateIndposData,
} from "../../redux/actions/MemberActions";

import ConfirmBox from "../../utils/PopUp";
import DataTable from "../Home/DataTable";
import HistoryData from "../UI/MemberHistory";
import InputField from "../UI/InputField";
import MemberButtonPanel from "../UI/MemberButtonPanel";
import Modal from "../../components/UI/Modal/Modal";
import Paper from "@material-ui/core/Paper";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../assets/styles/Theme";
import classNames from "classnames";
import { connect } from "react-redux";
import { handleDateChange } from "../../utils/DateFormatter";
import { POS_TABLE_HEADER as header } from "../../constants/Headers/MemberHeaders";
import isEmpty from "lodash/isEmpty";
import { validationRules } from "../../utils/ValidationRules";
import { withStyles } from "@material-ui/core/styles";

let dateChk = {};
const INITIAL_STATE = {
  customerId: null,
  memberId: "",
  notificateDate: null,
  statusFlag: "",
  drugEditStatus: "",
  drugEditClass: "",
  implDate: null,
  txnStatus: "",
  drugCode: "",
  terminationDate: null,
  overrideInd: "N",
  createTime: null,
  createUserId: null,
  lastUpdtTime: null,
  lastUpdtUserId: null,
  lstTxnStatus: null,
  groupId: null,
  productId: null,
  planId: null,
  pbpId: null,
  planDesignation: null,
  posEditOrDeleteOrModifyStatus: null,
  posCurrDate: null,
  ccmDate: null,
  enrollStartDate: null,
  enrollEndDate: null,
  notificateEndDate: null,
  implementationEndDate: null,
  prescriberLtStatus: "",
  pharamacyLtStatus: "",
  message: null,
  type: null,
  effStartDate: null,
  effEndDate: null,
  implDateFrmt: "",
  implementationEndDateFrmt: "",
  lastUpdtTimeFrmt: null,
  createTimeFrmt: null,
  notificateDateFrmt: "",
  terminationDateFrmt: null,
  notificateEndDateFrmt: "",
  showAll: "",
};

class POS extends Component {
  constructor(props) {
    super(props);
    this.validator = new SimpleReactValidator({ ...validationRules });
    this.state = {
      modified: false,
      isNewSegment: false,
      //showAllActiveInd: true,
      editable: false,
      closePopup: false,
      showAllData: null,
      mbrPosList: null,
      posVo: { ...INITIAL_STATE },
      memberId: this.props.mbrSearchCriteria.memberId,
      selectedIndex: 0,
      rowsPerPage: 10,
      func1: this.showAll.bind(this),
      showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
    };
  }

  handlechange = (name) => (event) => {
    let value = event.target.value;
    this.setState((prevState) => ({
      posVo: {
        ...prevState.posVo,
        [name]: value,
      },
      modified: true, // enable update button
    }));
  };

  handleOnBlur = (event) => {
    let value = event.target.value.trim();
    let name = event.target.name;
    this.setState((prevState) => ({
      posVo: {
        ...prevState.posVo,
        [name]: value,
      },
      modified: true, // enable update button
    }));
  };

  handleDate = (event) => {
    let value = event.target.value;
    let name = event.target.name;

    this.setState((prevState) => ({
      posVo: {
        ...prevState.posVo,
        [name]: handleDateChange(value),
      },
      modified: true,
    }));
  };

  handleDates = (event) => {
    dateChk = {};
    let fieldId = "#" + event.target.name;
    var self = this;

    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        if (
          dateChk.name !== e.target.name ||
          dateChk.value !== e.target.value
        ) {
          self.setDate(e.target.name, e.target.value);
        }
        dateChk.name = e.target.name;
        dateChk.value = e.target.value;
      });
  };
  setDate = (name, value) => {
    this.setState((prevState) => ({
      posVo: {
        ...prevState.posVo,
        [name]: handleDateChange(value),
      },
      modified: true,
    }));
  };

  handleChangeSearchSelectAuto = (data, name) => {
    let value = data.value;
    this.setState((prevState) => ({
      posVo: {
        ...prevState.posVo,
        [name]: value,
      },
      modified: true,
    }));
  };
  handleChangeSearchSelect = (name) => (event) => {
    let value = event.value;
    this.setState((prevState) => ({
      posVo: {
        ...prevState.posVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  selectRow = (index) => {
    const selectedVo = this.state.mbrPosList[index];
    this.setState(() => ({
      posVo: { ...selectedVo }, // copy data
      editable: false, // readOnly
      isNewSegment: false, //Not a new SEgment
      selectedIndex: index,
      modified: false, // Disabled update button
    }));
  };

  modelSegment = () => {
    if (this.state.posVo.overrideInd === "Y") {
      let msg = "This Record is not active ";
      this.setState({ message: msg, closePopup: true });
    } else {
      this.setState({
        editable: true, // Editable
        isNewSegment: false, // Not a new Segment
      });
    }
  };

  createNewSegment = () => {
    this.validator.hideMessages();
    INITIAL_STATE.memberId = this.props.mbrSearchCriteria.memberId;
    this.setState({
      editable: true, //editable
      isNewSegment: true, //new SEgment
      posVo: {
        ...INITIAL_STATE, // marked all fields as Empty
      },
    });
  };

  update = (event) => {
    event.preventDefault();
    if (this.validator.allValid()) {
      ConfirmBox(this.confirmUpdate, Type.UPDATE, this.props);
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  confirmUpdate = async () => {
    const { posVo } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(posVo.showAll = val),
    });
    let payload = {
      ...this.state.posVo,
      memberId: this.props.mbrSearchCriteria.memberId,
    };
    let status = await this.props.insetUpdatePos(payload);

    if ("success" === status) {
      status = ActionTypes.UPDATE;

      let newVO = isEmpty(this.props.posData)
        ? INITIAL_STATE
        : this.props.posData[0];
      this.setState(() => ({
        message: status,
        isNewSegment: false,
        editable: false,
        modified: false,
        posVo: newVO,
        mbrPosList: this.props.posData,
        showAllData: null,
        closePopup: true,
      }));
    } else {
      this.setState(() => ({
        message: status,
        closePopup: true,
      }));
    }
  };

  addNewSegment = () => {
    const {
      enrollStatus,
      enrollReasonCd,
    } = this.props.searchResultsVo.mbrEnrollmentList[0];
    if (
      this.validator.allValid() &&
      enrollStatus === "EAPRV" &&
      enrollReasonCd === "CMSAPRV"
    ) {
      let overrideInd = false;
      if (this.props.posData) {
        this.props.posData.map((data) => {
          if (data.overrideInd === "N") {
            overrideInd = true;
          }
          return data
        });
      }

      // if (!isEmpty(this.props.posData)) {
      if (overrideInd) {
        this.setState({
          closePopup: true,
          message: "Can Not Add Another POS Record in CMSREADY Status",
        });
        return;
      }
      ConfirmBox(this.confirmAddNewSegment, Type.ADD, this.props);
    } else if (this.validator.allValid()) {
      this.setState({
        closePopup: true,
        message: "Enroll status should be EAPRV",
      });
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  confirmAddNewSegment = async () => {
    const { posVo } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(posVo.showAll = val),
    });
    let payload = {
      ...posVo,
      memberId: this.props.mbrSearchCriteria.memberId,
    };
    let status = await this.props.insetUpdatePos(payload);

    if ("success" === status) {
      status = ActionTypes.ADD;
      let newVO = isEmpty(this.props.posData)
        ? INITIAL_STATE
        : this.props.posData[0];
      let posData = isEmpty(this.props.posData) ? [] : this.props.posData;
      this.setState({
        message: status,
        isNewSegment: false,
        editable: false,
        modified: false,
        posVo: newVO,
        mbrPosList: posData,
        showAllData: null,
        closePopup: true,
        selectedIndex: 0,
      });
    } else {
      this.setState({
        message: status,
        closePopup: true,
      });
    }

    this.validator.hideMessages();
  };

  delete = () => {
    if (this.state.posVo.overrideInd === "Y") {
      let msg = "This Record is not active ";
      this.setState({ message: msg, closePopup: true });
    } else {
      ConfirmBox(this.confirmDelete, Type.DELETE, this.props);
    }
  };

  confirmDelete = async () => {
    const { selectedIndex, posVo } = this.state;

    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(posVo.showAll = val),
    });
    let payload = {
      ...posVo,
      memberId: this.props.mbrSearchCriteria.memberId,
    };
    await this.props.deletePos(payload);
    let newVO = isEmpty(this.props.posData)
      ? INITIAL_STATE
      : this.props.posData[selectedIndex];
    let posData = isEmpty(this.props.posData) ? [] : this.props.posData;
    this.setState({
      posVo: newVO,
      mbrPosList: posData,
      showAllData: null,
      closePopup: true,
      message: ActionTypes.DELETE,
      selectedIndex: 0,
      isNewSegment: false,
      editable: false,
      modified: false,
    });
  };

  goBack = () => {
    const index = this.state.selectedIndex;
    const { posData } = this.props;
    let posVo = INITIAL_STATE;

    if (!isEmpty(posData)) {
      posVo = this.props.posData[index];
    }

    this.setState({
      isNewSegment: false,
      editable: false,
      modified: false,
      posVo: posVo,
    });
    this.validator.hideMessages();
  };

  showAll = async (flag, mbrId) => {
    const memberId = mbrId;
    const { showAllData } = this.state;

    if (flag === true) {
      if (showAllData === null) {
        const data = await this.props.getShowAll({
          memberId: memberId + "/Y",
          url: "GET_POS",
        });
        if (null != data) {
          const selectedVo = !isEmpty(data) ? data[0] : { ...INITIAL_STATE };
          this.setState(() => ({
            mbrPosList: data,
            showAllData: data,
            posVo: { ...selectedVo },
            showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
            selectedIndex: 0,
            editable: false,
            isNewSegment: false,
          }));
        }
      } else {
        const posVO = !isEmpty(showAllData)
          ? showAllData[0]
          : { ...INITIAL_STATE };
        this.setState({
          mbrPosList: showAllData,
          posVo: posVO,
          showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
          selectedIndex: 0,
          editable: false,
          isNewSegment: false,
        });
      }
    } else {
      if (flag === "N") {
        await this.props.getPos(memberId + "/N");
      } else {
        let recodN = await (this.state.mbrPosList === null
          ? []
          : this.state.mbrPosList.filter((role) => role.overrideInd === "N"));

        await this.props.updateIndposData(recodN);
      }
      let posData = isEmpty(this.props.posData) ? [] : this.props.posData;
      const mbrPosList = posData;
      const selectedVo = !isEmpty(mbrPosList)
        ? mbrPosList[0]
        : { ...INITIAL_STATE };
      this.setState(() => ({
        posVo: { ...selectedVo },
        mbrPosList: mbrPosList,
        showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
        selectedIndex: 0,
        editable: false,
        isNewSegment: false,
      }));
    }
  };

  async componentDidMount() {
    dateChk = {};
    if (this.props.showAllActiveInd.showAllActiveInd === false) {
      this.showAll(true, this.props.mbrSearchCriteria.memberId);
    } else if (isEmpty(this.props.posData) && this.props.posData !== null) {
      await this.props.getPos(this.props.mbrSearchCriteria.memberId + "/N");
      INITIAL_STATE.memberId = this.props.mbrSearchCriteria.memberId;
    }
    if (!isEmpty(this.props.posData)) {
      this.setState(() => ({
        mbrPosList: this.props.posData,
        posVo: { ...this.props.posData[0] },
      }));
    }
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.mbrSearchCriteria.memberId !== prevState.memberId) {
      if (!isEmpty(nextProps.posData)) {
        return {
          posVo: nextProps.posData[0],
          mbrPosList: nextProps.posData,
          showAllData: null,
          //showAllActiveInd: true,
          modified: false,
          isNewSegment: false,
          editable: false,
          selectedIndex: 0,
          memberId: nextProps.mbrSearchCriteria.memberId,
          model: prevState.func1(
            nextProps.showAllActiveInd.showAllActiveInd === false ? true : "N",
            nextProps.mbrSearchCriteria.memberId
          ),
        };
      }
      return {
        posVo: INITIAL_STATE,
        mbrPosList: [],
        showAllData: null,
        //showAllActiveInd: true,
        modified: false,
        isNewSegment: false,
        editable: false,
        selectedIndex: 0,
        memberId: nextProps.mbrSearchCriteria.memberId,
        model: prevState.func1(
          nextProps.showAllActiveInd.showAllActiveInd === false ? true : "N",
          nextProps.mbrSearchCriteria.memberId
        ),
      };
    }
    if (
      nextProps.showAllActiveInd.showAllActiveInd !== prevState.showAllActiveInd
    ) {
      if (nextProps.showAllActiveInd.showAllActiveInd === false) {
        return {
          model: prevState.func1(true, nextProps.mbrSearchCriteria.memberId),
        };
      } else {
        return {
          model: prevState.func1(false, nextProps.mbrSearchCriteria.memberId),
        };
      }
    }
    return prevState;
  }

  modalClosed = () => {
    this.setState({ closePopup: false });
  };

  handleChangePage = (index) => {
    this.setState({ selectedIndex: index });
    const selectedVo = this.state.mbrPosList[index];
    this.setState(() => ({
      posVo: { ...selectedVo }, // copy data
      editable: false, // readOnly
      isNewSegment: false, //Not a new SEgment
      selectedIndex: index,
      modified: false, // Disabled update button
    }));
  };

  handleChangeRowsPerPage = async (rowsPerPage) => {
    await this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  render() {
    const { classes, searchResultsVo, dropdowns } = this.props;
    const { posVo, editable, mbrPosList } = this.state;

    let ButtonPanel = (
      <MemberButtonPanel
        isNewSegment={this.state.isNewSegment}
        // showAll={this.showAll}
        //toggleLabel={this.state.showAllActiveInd}
        newSegment={this.createNewSegment}
        modelSegment={this.modelSegment}
        modified={this.state.modified}
        editable={editable}
        delete={this.delete}
        update={this.update}
        disable={isEmpty(mbrPosList)}
      />
    );

    return (
      <React.Fragment>
        <Modal
          dialogTitle="POS"
          message={this.state.message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Paper
          elevation={0}
          className={classNames(classes.card, "animated fadeIn")}
        >
          <DataTable
            data={isEmpty(mbrPosList) ? [] : mbrPosList}
            header={header}
            sortable={true}
            rowsPerPageOptions={[10, 15, 20]}
            handleChangeRowsPerPage={this.handleChangeRowsPerPage}
            rowsPerPage={this.state.rowsPerPage}
            clicked={this.selectRow}
            index={this.state.selectedIndex}
            handleChangePage={this.handleChangePage}
            subtab
          />

          {!isEmpty(mbrPosList) || this.state.isNewSegment ? (
            <React.Fragment>
              <form autoComplete="off">
                <div className={classes.buttonContainer}> {ButtonPanel}</div>
                <div className="panel-body margin-top1">
                  <div className={classes.containerdemo}>
                    <div className={classes.input1}>
                      <InputField
                        name="notificateDateFrmt"
                        onClick={this.handleDates}
                        label="Notification Start Date"
                        maxLength={10}
                        width="180px"
                        placeholder="MM/DD/YYYY"
                        value={posVo.notificateDateFrmt}
                        onChange={this.handleDate}
                        onBlur={this.handleOnBlur}
                        disabled={!editable}
                        required={editable}
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "Notification Start Date",
                          [
                            posVo.notificateDateFrmt,
                            posVo.notificateEndDateFrmt,
                            searchResultsVo.mbrEnrollmentList[0]
                              .effStartDateFrmt,
                            searchResultsVo.mbrEnrollmentList[0].effEndDateFrmt,
                            posVo.notificateDateFrmt,
                            null,
                            searchResultsVo.ccmDate,
                          ],
                          "required|date_format|enrolment_period|CCM_60days" // |date_format|monthEndCheck
                        )}
                      </div>
                    </div>
                    <div className={classes.input1}>
                      <InputField
                        name="notificateEndDateFrmt"
                        onClick={this.handleDates}
                        label="Notification End Date"
                        maxLength={10}
                        width="180px"
                        placeholder="MM/DD/YYYY"
                        value={this.state.posVo.notificateEndDateFrmt}
                        onChange={this.handleDate}
                        onBlur={this.handleOnBlur}
                        disabled={!editable}
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "Notification End Date",
                          [
                            posVo.notificateDateFrmt,
                            posVo.notificateEndDateFrmt,
                            searchResultsVo.mbrEnrollmentList[0]
                              .effStartDateFrmt,
                            searchResultsVo.mbrEnrollmentList[0].effEndDateFrmt,
                            posVo.notificateEndDateFrmt,
                            posVo.implDateFrmt,
                          ],
                          "date_format|date_after_notificationd|enrolment_period|Notification_End_Date|Notification_End_Date_ImplSDate" //endDateRequired |date_format|date_after_notification
                        )}
                      </div>
                    </div>
                    <div className={classes.Select2}>
                      <Autocomplete1
                        handleChange={this.handleChangeSearchSelectAuto}
                        label="Status Flag"
                        options={STATUS_FLAG}
                        defaultValue={STATUS_FLAG[0]}
                        value={
                          STATUS_FLAG.filter(
                            (data) => data.value === posVo.statusFlag
                          )[0]
                        }
                        margin='0px'
                        name="statusFlag"
                        disabled={!this.state.editable}
                      />
                      <div className={classes.validationMessageSelect}>
                        {this.validator.message(
                          "Status Flag",
                          [0, posVo.statusFlag],
                          "inpuRequired"
                        )}
                      </div>
                    </div>

                    <div className={classes.Select2}>
                     
                      <Autocomplete1
                        handleChange={this.handleChangeSearchSelectAuto}
                        label="Drug Edit Statu"
                        options={dropdowns.memberAppeal}
                        defaultValue={dropdowns.memberAppeal[0]}
                        value={
                          dropdowns.memberAppeal.filter(
                            (data) => data.value === posVo.drugEditStatus
                          )[0]
                        }
                        name="drugEditStatus"
                        margin='0px'
                        disabled={!this.state.editable}
                      />
                      <div className={classes.validationMessageSelect}>
                        {this.validator.message(
                          "Drug Edit Status",
                          [
                            posVo.drugEditStatus.trim(),
                            posVo.drugEditClass,
                            posVo.drugCode,
                          ],
                          "required"
                        )}
                      </div>
                    </div>
                    <div className={classes.input1}>
                      <InputField
                        name="overrideInd"
                        label="Override"
                        width="180px"
                        value={posVo.overrideInd}
                        onChange={this.handlechange("overrideInd")}
                        onBlur={this.handleOnBlur}
                        disabled={true}
                      />
                      <div className={classes.validationMessage}></div>
                    </div>
                    <div className={classes.Select2}>
                      <Autocomplete1
                        handleChange={this.handleChangeSearchSelectAuto}
                        label="Drug Edit Class"
                        margin='0px'
                        options={dropdowns.validDrugEditClass}
                        defaultValue={dropdowns.validDrugEditClass[0]}
                        value={
                          dropdowns.validDrugEditClass.filter(
                            (data) => data.value === posVo.drugEditClass
                          )[0]
                        }
                        name="drugEditClass"
                        disabled={!this.state.editable}
                      />
                      <div className={classes.validationMessageSelect}>
                        {this.validator.message(
                          "Drug Edit Class",
                          [
                            posVo.drugEditStatus,
                            posVo.drugEditClass.trim(),
                            posVo.drugCode,
                          ],
                          "drug_Class|drug_Class_No"
                        )}
                      </div>
                    </div>

                    <div className={classes.input1}>
                      <InputField
                        name="implDateFrmt"
                        onClick={this.handleDates}
                        label="Implementation Start Date"
                        maxLength={10}
                        width="180px"
                        placeholder="MM/DD/YYYY"
                        value={posVo.implDateFrmt}
                        onChange={this.handleDate}
                        onBlur={this.handleOnBlur}
                        disabled={!editable}
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "Implementation Start Date",
                          [
                            posVo.implDateFrmt,
                            posVo.implementationEndDateFrmt, //1
                            searchResultsVo.mbrEnrollmentList[0]
                              .effStartDateFrmt,
                            searchResultsVo.mbrEnrollmentList[0].effEndDateFrmt, // 3
                            posVo.implDateFrmt,
                            posVo.notificateDateFrmt, // 5
                            searchResultsVo.ccmDate,
                          ], //6
                          "date_format|enrolment_period|Implementation_Start_Date|CCM_60days" // |date_format|date_after
                        )}
                      </div>
                    </div>
                    <div className={classes.input1}>
                      <InputField
                        name="implementationEndDateFrmt"
                        onClick={this.handleDates}
                        label="Implementation End Date"
                        maxLength={10}
                        width="180px"
                        placeholder="MM/DD/YYYY"
                        value={posVo.implementationEndDateFrmt}
                        onChange={this.handleDate}
                        onBlur={this.handleOnBlur}
                        disabled={!editable}
                      />

                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "End Date",
                          [
                            posVo.implDateFrmt,
                            posVo.implementationEndDateFrmt,
                            searchResultsVo.mbrEnrollmentList[0]
                              .effStartDateFrmt,
                            searchResultsVo.mbrEnrollmentList[0].effEndDateFrmt,
                            posVo.implementationEndDateFrmt,
                            posVo.statusFlag,
                          ],
                          "date_format|enrolment_period|implementation_Period12|implementation_Period24" // |date_after |Implementation_End_Date12M
                        )}
                      </div>
                    </div>

                    <div className={classes.Select2}>
                      <Autocomplete1
                        handleChange={this.handleChangeSearchSelectAuto}
                        label="Drug Edit Code"
                        options={DRUG_EDIT_CODE}
                        defaultValue={DRUG_EDIT_CODE[0]}
                        value={
                          DRUG_EDIT_CODE.filter(
                            (data) => data.value === posVo.drugCode
                          )[0]
                        }
                        name="drugCode"
                        margin='0px'
                        disabled={!this.state.editable}
                      />
                      <div className={classes.validationMessageSelect}>
                        {this.validator.message(
                          "Drug Edit Code",
                          [
                            posVo.drugEditStatus,
                            posVo.drugEditClass,
                            posVo.drugCode,
                          ],
                          "drug_Code|drug_Code_No"
                        )}
                      </div>
                    </div>
                    <div className={classes.Select2}>
                      <Autocomplete1
                        handleChange={this.handleChangeSearchSelectAuto}
                        label="Prescriber Limitation Status"
                        margin='0px'
                        options={dropdowns.memberAppeal}
                        defaultValue={dropdowns.memberAppeal[0]}
                        value={
                          dropdowns.memberAppeal.filter(
                            (data) => data.value === posVo.prescriberLtStatus
                          )[0]
                        }
                        name="prescriberLtStatus"
                        disabled={!this.state.editable}
                      />
                      <div className={classes.validationMessageSelect}></div>
                    </div>

                    <div className={classes.Select2}>
                     
                      <Autocomplete1
                        handleChange={this.handleChangeSearchSelectAuto}
                        label="Pharmacy Limitation Status"
                        options={dropdowns.memberAppeal}
                        defaultValue={dropdowns.memberAppeal[0]}
                        value={
                          dropdowns.memberAppeal.filter(
                            (data) => data.value === posVo.pharamacyLtStatus
                          )[0]
                        }
                        name="pharamacyLtStatus"
                        margin='0px'
                        disabled={!this.state.editable}
                      />
                      <div className={classes.validationMessageSelect}></div>
                    </div>
                    <div className={classes.Select2}>
                      <Autocomplete1
                        handleChange={this.handleChangeSearchSelectAuto}
                        margin='0px'
                        label="TXN Status"
                        options={dropdowns.validTxnStatus}
                        defaultValue={dropdowns.validTxnStatus[0]}
                        value={
                          dropdowns.validTxnStatus.filter(
                            (data) => data.value === posVo.txnStatus
                          )[0]
                        }
                        name="txnStatus"
                        disabled={!this.state.editable}
                      />
                     
                      <div className={classes.validationMessageSelect}>
                        <div
                          style={{ marginLeft: "0" }}
                          className={classes.validationMessage}
                        >
                          {this.validator.message(
                            "TXN Status",
                            [0, posVo.txnStatus],
                            "txn_Status|inpuRequired"
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </form>

              <HistoryData
                isNewSegment={this.state.isNewSegment}
                reset={this.createNewSegment}
                addSegment={this.addNewSegment}
                back={this.goBack}
                footer="true"
                createUserId={posVo.createUserId}
                createTime={posVo.createTime}
                lastUpdtTime={posVo.lastUpdtTime}
                lastUpdtUserId={posVo.lastUpdtUserId}
              />
            </React.Fragment>
          ) : (
              <div className={classes.buttonContainer}> {ButtonPanel}</div>
            )}
        </Paper>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    memberIdCheck: state.memberSearch.memberId,
    posData: state.memberSearch.searchResultsVo.mbrPosInfoList,
    loginData: state.loginData,
    searchResultsVo: state.memberSearch.searchResultsVo,
    mbrSearchCriteria: state.memberSearch.mbrSearchCriteria,
    dropdowns: state.membercache,
    showAllActiveInd: state.memberSearch.showAllActiveIndi,
  };
};
const mapDispatchToProps = {
  getPos,
  filterPos,
  insetUpdatePos,
  deletePos,
  getShowAll,
  updateIndposData,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(POS));
