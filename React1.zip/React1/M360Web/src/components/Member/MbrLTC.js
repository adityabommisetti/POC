import * as DateUtil from "../../utils/DatePicker";
import * as Type from "../../constants/ConfirmType";

import React, { Component } from "react";
import {
  deleteLTCItem,
  getLtcData,
  getShowAll,
  updateLtc,
  updateIndltcData,
} from "../../redux/actions/MemberActions";

import ConfirmBox from "../../utils/PopUp";
import DataTable from "../Home/DataTable";
import FacilitySearch from "./MbrFacilitySearch";
import HistoryData from "../UI/MemberHistory";
import InputField from "../UI/InputField";
import MemberButtonPanel from "../UI/MemberButtonPanel";
import Modal from "../../components/UI/Modal/Modal";
import Paper from "@material-ui/core/Paper";
import Popup from "reactjs-popup";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../assets/styles/Theme";
import classNames from "classnames";
import { connect } from "react-redux";
import { handleDateChange } from "../../utils/DateFormatter";
import { LTC_TABLE_HEADER as header } from "../../constants/Headers/MemberHeaders";
import isEmpty from "lodash/isEmpty";
import { messages } from "../../constants/Messages";
import { withStyles } from "@material-ui/core/styles";
import { customValidations } from "../../utils/CustomValidations";

let dateChk = {};

const INITIAL_STATE = {
  assessmentDate: "",
  assessmentDateFrmt: "",
  createUserId: "",
  customerId: "",
  effEndDate: "",
  effEndDateFrmt: "99/99/9999",
  effStartDate: "",
  effStartDateFrmt: "",
  errorDescription: null,
  facilityAddress: "",
  facilityCity: "",
  facilityName: "",
  facilityState: "",
  facilityZipCode: "",
  lastUpdtTime: "",
  lastUpdtUserId: "",
  lengthOfStay: "",
  ltcChangeInd: null,
  ltcChangeSendTime: null,
  ltcId: "",
  ltcchangeReceiveTime: null,
  memberId: "", //"C00514958",
  message: null,
  overrideInd: "N",
  ppsInd: "N",
  type: "LTC",
  showAll: "",
};

class LTC extends Component {
  constructor(props) {
    super(props);
    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
        date_after_: customValidations.date_after,
        first_day_of_month: customValidations.first_day_of_month,
        last_day_of_month: customValidations.last_day_of_month,
      },
    });
    this.state = {
      facilityNameUpdate: false,
      ltcVo: INITIAL_STATE,
      modified: false,
      isNewSegment: false,
      // showAllActiveInd: true,
      editable: false,
      mbrLtcList: null,
      memberId: this.props.mbrSearchCriteria.memberId,
      closePopup: false,
      showAllData: null,
      selectedIndex: 0,
      togglePopup: false,
      ltcIdNameChange: false,
      rowsPerPage: 10,
      func1: this.showAll.bind(this),
      showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
    };
  }

  async componentDidMount() {
    INITIAL_STATE.memberId = this.props.mbrSearchCriteria.memberId;
    dateChk = {};
    if (this.props.showAllActiveInd.showAllActiveInd === false) {
      this.showAll(true, this.props.mbrSearchCriteria.memberId);
    } else if (isEmpty(this.props.ltcData) && this.props.ltcData !== null) {
      await this.props.getLtcData(this.props.mbrSearchCriteria.memberId + "/N");
    }
    if (!isEmpty(this.props.ltcData)) {
      this.setState(() => ({
        mbrLtcList: this.props.ltcData,
        ltcVo: { ...this.props.ltcData[0] },
      }));
    }
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.mbrSearchCriteria.memberId !== prevState.memberId) {
      if (!isEmpty(nextProps.ltcData)) {
        return {
          ltcVo: nextProps.ltcData[0],
          mbrLtcList: nextProps.ltcData,
          showAllData: null,
          //showAllActiveInd: true,
          modified: false,
          isNewSegment: false,
          editable: false,
          selectedIndex: 0,
          memberId: nextProps.mbrSearchCriteria.memberId,
          model: prevState.func1(
            nextProps.showAllActiveInd.showAllActiveInd === false ? true : "N",
            nextProps.mbrSearchCriteria.memberId
          ),
        };
      }
      return {
        ltcVo: INITIAL_STATE,
        mbrLtcList: [],
        showAllData: null,
        //showAllActiveInd: true,
        modified: false,
        isNewSegment: false,
        editable: false,
        selectedIndex: 0,
        memberId: nextProps.mbrSearchCriteria.memberId,
        model: prevState.func1(
          nextProps.showAllActiveInd.showAllActiveInd === false ? true : "N",
          nextProps.mbrSearchCriteria.memberId
        ),
      };
    }
    if (
      nextProps.showAllActiveInd.showAllActiveInd !== prevState.showAllActiveInd
    ) {
      if (nextProps.showAllActiveInd.showAllActiveInd === false) {
        return {
          model: prevState.func1(true, nextProps.mbrSearchCriteria.memberId),
        };
      } else {
        return {
          model: prevState.func1(false, nextProps.mbrSearchCriteria.memberId),
        };
      }
    }
    return prevState;
  }

  selectRow = (index) => {
    const selectedVo = this.state.mbrLtcList[index];
    this.setState(() => ({
      ltcVo: selectedVo, // copy data
      editable: false, // readOnly
      isNewSegment: false, //Not a new SEgment
      modified: false,
      selectedIndex: index,
    }));
  };

  handleDates = (event) => {
    dateChk = {};
    var self = this;
    const name = "#" + event.target.name;
    DateUtil.getDatePicker(name)
      .datepicker("show")
      .on("change", (e) => {
        if (
          dateChk.name !== e.target.name ||
          dateChk.value !== e.target.value
        ) {
          self.setDate(e.target.name, e.target.value);
        }
        dateChk.name = e.target.name;
        dateChk.value = e.target.value;
      });
  };

  handlechange = (event) => {
    let value = event.target.value.toUpperCase();
    let name = event.target.name;

    this.setState((prevState) => ({
      facilityNameUpdate: true,
      ltcVo: {
        ...prevState.ltcVo,
        [name]: name === "ltcId" ? value : handleDateChange(value),
      },
      modified: true, // enable update button
    }));
  };

  handleOnBlur = (event) => {
    let value = event.target.value.trim();
    let name = event.target.name;

    this.setState((prevState) => ({
      ltcVo: {
        ...prevState.ltcVo,
        [name]: name === "ltcId" ? value : handleDateChange(value),
      },
      modified: true, // enable update button
    }));
  };

  setDate = (name, value) => {
    this.setState((prevState) => ({
      ltcVo: {
        ...prevState.ltcVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleChangeSearchSelect = (name) => (event) => {
    let value = event.value;
    this.setState((prevState) => ({
      ltcVo: {
        ...prevState.ltcVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleNumberChange = (event) => {
    let name = event.target.name;
    let value = event.target.value.replace(/[^0-9]/g, "").trim();
    this.setState((prevState) => ({
      ltcVo: {
        ...prevState.ltcVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  facilityChange = (e) => {
    // ltcId  facilityName
    // const target = e.target;
    // this.setState(prevState => ({
    //   ltcIdNameChange:true,
    //   ltcVo: {
    //     ...prevState.ltcVo,
    //     [target.name]: target.value
    //   },
    //   modified: true
    // }));
    this.setState((prevState) => ({
      ltcIdNameChange: true,
      ltcVo: {
        ...prevState.ltcVo,
        ltcId: "",
        facilityName: "",
      },
      modified: true,
    }));
  };

  modelSegment = () => {
    if (this.state.ltcVo.overrideInd === "Y") {
      let msg = "This Record is not active ";
      this.setState({ message: msg, closePopup: true });
    } else {
      this.setState({
        facilityNameUpdate: false,
        ltcIdNameChange: false,
        editable: true, // Editable
        isNewSegment: false, // Not a new Segment
      });
    }
  };

  createNewSegment = () => {
    this.validator.hideMessages();
    INITIAL_STATE.memberId = this.props.mbrSearchCriteria.memberId;
    this.setState({
      ltcIdNameChange: false,
      editable: true, //editable
      isNewSegment: true, //new SEgment
      ltcVo: {
        ...INITIAL_STATE, // marked all fields as Empty
      },
    });
  };

  update = (event) => {
    event.preventDefault();
    if (this.validator.allValid()) {
      const { facilityList } = this.props;
      const { selectedIndex, mbrLtcList } = this.state;
      const { facilityName } = this.state.ltcVo;

      let obj = !isEmpty(facilityList)
        ? facilityList.filter((data) => data.facilityName === facilityName)
        : {};

      let name = !isEmpty(obj) ? obj[0].facilityName : "";
      if (
        name === "" &&
        name !== mbrLtcList[selectedIndex].facilityName &&
        this.state.facilityNameUpdate
      ) {
        this.setState({
          // Please select valid Facility Name
          message: "Please Select Valid Facility Name By Clicking `?`",
          closePopup: true,
        });

        this.setState((prevState) => ({
          ltcVo: {
            ...prevState.ltcVo,
            facilityName: "",
            ltcId: "",
          },
        }));
      } else {
        ConfirmBox(this.confirmUpdate, Type.UPDATE, this.props);
      }
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  confirmUpdate = async () => {
    const { ltcVo } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(ltcVo.showAll = val),
    });

    let payload = {
      ...this.state.ltcVo,
      memberId: this.props.mbrSearchCriteria.memberId,
    };
    let status = await this.props.updateLtc(payload);

    if ("success" === status) {
      status = messages.UPDATED_SUCCESSFULLY;
      this.setState(() => ({
        message: status,
        isNewSegment: false,
        editable: false,
        modified: false,
        ltcVo: this.props.ltcData[this.state.selectedIndex],
        mbrLtcList: this.props.ltcData,
        showAllData: null,
        closePopup: true,
      }));
    } else {
      this.setState(() => ({
        message: status,

        closePopup: true,
      }));
    }
  };

  handleChangePage = (index) => {
    this.setState({ selectedIndex: index });
    const selectedVo = this.state.mbrLtcList[index];
    this.setState(() => ({
      ltcVo: selectedVo, // copy data
      editable: false, // readOnly
      isNewSegment: false, //Not a new SEgment
      modified: false,
      selectedIndex: index,
    }));
  };

  addNewSegment = () => {
    if (this.validator.allValid()) {
      const { facilityList } = this.props;
      const { selectedIndex, mbrLtcList } = this.state;
      const { facilityName } = this.state.ltcVo;

      let obj = !isEmpty(facilityList)
        ? facilityList.filter((data) => data.facilityName === facilityName)
        : {};

      let name = !isEmpty(obj) ? obj[0].facilityName : "";

      if (name === "" && name !== mbrLtcList[selectedIndex].facilityName) {
        this.setState({
          message: "Please Select Valid Facility Name By Clicking `?`",
          closePopup: true,
        });
      } else {
        ConfirmBox(this.confirmAddNewSegment, Type.ADD, this.props);
      }
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  confirmAddNewSegment = async () => {
    const { ltcVo } = this.state;

    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(ltcVo.showAll = val),
    });
    let payload = {
      ...ltcVo,
      memberId: this.props.mbrSearchCriteria.memberId,
    };
    let status = await this.props.updateLtc(payload);

    if ("success" === status) {
      status = messages.INSERTED_SUCCESSFULLY;

      let newVO = isEmpty(this.props.ltcData)
        ? INITIAL_STATE
        : this.props.ltcData[0];
      let ltcData = isEmpty(this.props.ltcData) ? [] : this.props.ltcData;
      this.setState({
        message: status,
        isNewSegment: false,
        editable: false,
        modified: false,
        ltcVo: newVO,
        mbrLtcList: ltcData,
        showAllData: null,
        closePopup: true,
        selectedIndex: 0,
      });
    } else {
      this.setState({
        message: status,

        closePopup: false,
        reset: false,
      });
    }
    this.validator.hideMessages();
  };

  delete = () => {
    if (this.state.ltcVo.overrideInd === "Y") {
      let msg = "This Record is not active ";
      this.setState({ message: msg, closePopup: true });
    } else {
      ConfirmBox(this.confirmDelete, Type.DELETE, this.props);
    }
  };

  confirmDelete = async () => {
    const { selectedIndex, ltcVo } = this.state;

    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(ltcVo.showAll = val),
    });
    let payload = {
      ...ltcVo,
      memberId: this.props.mbrSearchCriteria.memberId,
    };

    let status = await this.props.deleteLTCItem(payload);
    if ("success" === status) {
      status = messages.DELETED_SUCCESSFULLY;
    }
    let newVO = isEmpty(this.props.ltcData)
      ? INITIAL_STATE
      : this.props.ltcData[selectedIndex];

    let ltcData = isEmpty(this.props.ltcData) ? [] : this.props.ltcData;
    this.setState({
      ltcVo: newVO,
      mbrLtcList: ltcData,
      showAllData: null,
      closePopup: true,
      message: status,
      selectedIndex: 0,
      isNewSegment: false,
      editable: false,
      modified: false,
    });
  };

  goBack = () => {
    const index = this.state.selectedIndex;
    const { ltcData } = this.props;
    let ltcVo = INITIAL_STATE;

    if (!isEmpty(ltcData)) {
      ltcVo = this.props.ltcData[index];
    }

    this.setState({
      isNewSegment: false,
      editable: false,
      modified: false,
      ltcVo: ltcVo,
    });
    this.validator.hideMessages();
  };

  updateFacilitySearch = (data) => {
    this.setState({
      ltcVo: {
        ...this.state.ltcVo,
        ltcId: data.ltcId,
        facilityName: data.facilityName,
        facilityAddress: data.facilityAddress,
      },
      modified: true,
    });
  };

  showAll = async (flag, mbrId) => {
    const memberId = mbrId;
    const { showAllData } = this.state;

    if (flag === true) {
      if (showAllData === null) {
        const data = await this.props.getShowAll({
          memberId: memberId + "/Y",
          url: "GET_LTC",
        });
        if (null != data) {
          const selectedVo = !isEmpty(data) ? data[0] : { ...INITIAL_STATE };
          this.setState(() => ({
            mbrLtcList: data,
            showAllData: data,
            ltcVo: { ...selectedVo },
            showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
            selectedIndex: 0,
            isNewSegment: false,
            editable: false,
          }));
        }
      } else {
        const ltcVo = !isEmpty(showAllData)
          ? showAllData[0]
          : { ...INITIAL_STATE };
        this.setState({
          mbrLtcList: showAllData,
          ltcVo: ltcVo,
          showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
          selectedIndex: 0,
          isNewSegment: false,
          editable: false,
        });
      }
    } else {
      if (flag === "N") {
        await this.props.getLtcData(memberId + "/N");
      } else {
        let recodN = await (this.state.mbrLtcList === null
          ? []
          : this.state.mbrLtcList.filter((role) => role.overrideInd === "N"));
        await this.props.updateIndltcData(recodN);
      }

      let ltcData = isEmpty(this.props.ltcData) ? [] : this.props.ltcData;
      const mbrLtcList = ltcData;
      const selectedVo = !isEmpty(mbrLtcList)
        ? mbrLtcList[0]
        : { ...INITIAL_STATE };
      this.setState(() => ({
        ltcVo: { ...selectedVo },
        mbrLtcList: mbrLtcList,
        showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
        selectedIndex: 0,
        isNewSegment: false,
        editable: false,
      }));
    }
  };

  modalClosed = () => {
    this.setState({ closePopup: false });
  };
  handleChangeRowsPerPage = async (rowsPerPage) => {
    await this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  render() {
    const { classes } = this.props;
    const { ltcVo, mbrLtcList } = this.state;
    const { userId } = this.props.loginData.loginVo;
    let ButtonPanel = (
      <MemberButtonPanel
        isNewSegment={this.state.isNewSegment}
        // showAll={this.showAll}
        //toggleLabel={this.state.showAllActiveInd}
        newSegment={this.createNewSegment}
        modelSegment={this.modelSegment}
        modified={this.state.modified}
        editable={this.state.editable}
        delete={this.delete}
        update={this.update}
        disable={isEmpty(mbrLtcList)}
      />
    );

    return (
      <React.Fragment>
        <Modal
          dialogTitle="LTC"
          message={this.state.message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Paper
          elevation={0}
          className={classNames(classes.card, "animated fadeIn")}
        >
          <DataTable
            data={mbrLtcList ? mbrLtcList : []}
            header={header}
            sortable={true}
            rowsPerPageOptions={[10, 15, 20]}
            handleChangeRowsPerPage={this.handleChangeRowsPerPage}
            rowsPerPage={this.state.rowsPerPage}
            clicked={this.selectRow}
            index={this.state.selectedIndex}
            handleChangePage={this.handleChangePage}
            dateColumn={["effStartDateFrmt", "effEndDateFrmt"]}
            subtab
          />
          {!isEmpty(mbrLtcList) || this.state.isNewSegment ? (
            <React.Fragment>
              <form autoComplete="off">
                <div className={classes.buttonContainer}> {ButtonPanel}</div>
                <div
                  class="panel-body margin-top1"
                  className={classes.panelbodyltc}
                >
                  <div className={classes.containerdemo}>
                    <div>
                      <InputField
                        name="effStartDateFrmt"
                        required
                        placeholder="MM/DD/YYYY"
                        onClick={this.handleDates}
                        maxLength="10"
                        label="Start Date"
                        value={ltcVo.effStartDateFrmt}
                        onChange={this.handlechange}
                        onBlur={this.handleOnBlur}
                        disabled={!this.state.editable}
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "Start date",
                          ltcVo.effStartDateFrmt,
                          "required|first_day_of_month|date_format"
                        )}
                      </div>
                    </div>
                    <div>
                      <InputField
                        name="effEndDateFrmt"
                        required
                        placeholder="MM/DD/YYYY"
                        onClick={this.handleDates}
                        maxLength="10"
                        label="End Date"
                        value={ltcVo.effEndDateFrmt}
                        onChange={this.handlechange}
                        onBlur={this.handleOnBlur}
                        disabled={!this.state.editable}
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "End date",
                          ltcVo.effEndDateFrmt,
                          [
                            "required",
                            "date_format",
                            "date_after",
                            "last_day_of_month",
                            { date_after_: ltcVo.effStartDateFrmt },
                          ]
                        )}
                      </div>
                    </div>
                    <div>
                      <InputField
                        name="overrideInd"
                        label="OverrideInd"
                        value={ltcVo.overrideInd}
                        onChange={this.handlechange}
                        onBlur={this.handleOnBlur}
                        disabled={true}
                      />
                      <div className={classes.validationMessage}></div>
                    </div>

                    <div>
                      <InputField
                        name="lengthOfStay"
                        label="Length of Stay"
                        value={ltcVo.lengthOfStay}
                        onChange={this.handleNumberChange}
                        onBlur={this.handleOnBlur}
                        disabled={!this.state.editable}
                      />
                      <div className={classes.validationMessage}>
                        {/* {this.validator.message(
                          "Length of Stay",
                          ltcVo.lengthOfStay,
                          "required"
                        )} */}
                      </div>
                    </div>
                    <div>
                      <InputField
                        name="assessmentDateFrmt"
                        placeholder="MM/DD/YYYY"
                        label="Assessment Date"
                        onClick={this.handleDates}
                        maxLength="10"
                        value={ltcVo.assessmentDateFrmt}
                        onChange={this.handlechange}
                        onBlur={this.handleOnBlur}
                        disabled={!this.state.editable}
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "Assessment Date",
                          ltcVo.assessmentDateFrmt,
                          "date_format"
                        )}
                      </div>
                    </div>

                    <div>
                      <InputField
                        name="ppsInd"
                        label="PPS Indicator"
                        value={ltcVo.ppsInd}
                        onChange={this.handlechange}
                        onBlur={this.handleOnBlur}
                        disabled={!this.state.editable}
                      />
                      <div className={classes.validationMessage}></div>
                    </div>

                    <div>
                      <InputField
                        name="ltcId"
                        required
                        maxLength={12}
                        label="LTC ID"
                        value={ltcVo.ltcId}
                        onChange={(e) => {
                          this.handlechange(e);
                        }}
                        onBlur={this.handleOnBlur}
                        disabled={!this.state.editable}
                      />
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "Ltc Id",
                          ltcVo.ltcId,
                          "required"
                        )}
                      </div>
                    </div>
                    <div>
                      <div
                        className={classes.container}
                        style={{
                          width: "618px",
                          marginTop: "0px",
                          marginLeft: "-3px",
                        }}
                      >
                        <span class="label-container">
                          <label for="product">Facility Name</label>
                          <span className="imp">*</span>
                          <br />
                          <input
                            maxLength={50}
                            type="text"
                            class="form-field"
                            name="facilityName"
                            value={ltcVo.facilityName}
                            onBlur={this.handleOnBlur}
                            onChange={(e) => {
                              this.handlechange(e);
                            }}
                            disabled={!this.state.editable}
                            style={{
                              width: this.state.editable ? "555px" : "580px",
                            }}
                            endAdornment={this.state.editable}
                          />
                          {this.state.editable ? (
                            <Popup
                              style={{ height: "50%" }}
                              className={classes.mobileWidth}
                              modal
                              open={
                                this.validator.fields["Start date"] &&
                                this.state.togglePopup
                              }
                              onOpen={() => {
                                this.setState({
                                  togglePopup: true,
                                  closePopup: !this.validator.fields[
                                    "Start date"
                                  ],
                                  message: "Start date field is required",
                                });
                              }}
                              onClose={() => {
                                this.setState({ togglePopup: false });
                              }}
                              trigger={<span class="more-info" />}
                              position="right center"
                            >
                              {(close) => (
                                <FacilitySearch
                                  dateValidator={
                                    this.validator.fields["Start date"]
                                  }
                                  headerLabel="Facility Name Search"
                                  ltcVo={ltcVo}
                                  searchType="FACILITY_NAME_SEARCH"
                                  setZip={this.setZip}
                                  close={close}
                                  ltcIdNameChange={this.state.ltcIdNameChange}
                                  setData={this.updateFacilitySearch}
                                  loginData={
                                    this.props.loginData.loginVo.customerId
                                  }
                                />
                              )}
                            </Popup>
                          ) : null}
                        </span>
                      </div>
                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "Facility Name",
                          ltcVo.facilityName,
                          "required"
                        )}
                      </div>
                    </div>

                    <div>
                      <InputField
                        name="facilityAddress"
                        label="Address"
                        value={ltcVo.facilityAddress}
                        onChange={this.handlechange}
                        disabled={true}
                        onBlur={this.handleOnBlur}
                        width="578px"
                      />
                      <div className={classes.validationMessage}></div>
                    </div>

                    <div className={classes.cityzipmargin}>
                      <InputField
                        name="facilityCity"
                        label="City/State/Zip"
                        value={ltcVo.facilityCity}
                        onChange={this.handlechange}
                        onBlur={this.handleOnBlur}
                        disabled={true}
                      />
                      <div className={classes.validationMessage}></div>
                    </div>
                  </div>
                </div>
              </form>
              <HistoryData
                isNewSegment={this.state.isNewSegment}
                reset={this.createNewSegment}
                addSegment={this.addNewSegment}
                back={this.goBack}
                footer="true"
                createUserId={userId}
                createTime={ltcVo.createTime}
                lastUpdtTime={ltcVo.lastUpdtTime}
                lastUpdtUserId={ltcVo.lastUpdtUserId}
              />
            </React.Fragment>
          ) : (
            <div className={classes.buttonContainer}> {ButtonPanel}</div>
          )}
        </Paper>
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    ltcData: state.memberSearch.searchResultsVo.mbrLtcInfoList,
    loginData: state.loginData,
    searchResultsVo: state.memberSearch.searchResultsVo,
    mbrSearchCriteria: state.memberSearch.mbrSearchCriteria,
    servicesEnabled: state.loginData.servicesEnabled,
    memberIdCheck: state.memberSearch.memberId,
    facilityList: state.memberSearch.facilitySearch,
    showAllActiveInd: state.memberSearch.showAllActiveIndi,
  };
};
const mapDispatchToProps = {
  getLtcData,
  updateLtc,
  getShowAll,
  deleteLTCItem,
  updateIndltcData,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(LTC));
