import * as ActionTypes from "../../redux/types/ActionType";
import * as DateUtil from "../../utils/DatePicker";
import * as Type from "../../constants/ConfirmType";

import {
  DSINFODelete,
  DSINFODetails,
  DSINFOUpdate,
  MemberSearch,
  getShowAll,
  updateIndData,
} from "../../redux/actions/MemberActions";
import React, { Component } from "react";
import Autocomplete1 from "../UI/Select";

import CheckBoxIcon from "@material-ui/icons/CheckBox";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import Checkbox from "@material-ui/core/Checkbox";
import ConfirmBox from "../../utils/PopUp";
import DataTable from "../Home/DataTable";
import FormLabel from "@material-ui/core/FormLabel";
import HistoryData from "../UI/MemberHistory";
import InputField from "../UI/InputField";
import MemberButtonPanel from "../UI/MemberButtonPanel";
import Modal from "../../components/UI/Modal/Modal";
import Paper from "@material-ui/core/Paper";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../assets/styles/Theme";
import classNames from "classnames";
import { connect } from "react-redux";
import { handleDateChange } from "../../utils/DateFormatter";
import { DSINFO_HEADER as header } from "../../constants/Headers/MemberHeaders";
import isEmpty from "lodash/isEmpty";
import { messages } from "../../constants/Messages";
import { customValidations } from "../../utils/CustomValidations";
import { withStyles } from "@material-ui/core/styles";

let dateChk = {};

const INITIAL_STATE = {
  customerId: "",
  memberId: "",
  dsCd: "",
  dsDesc: "",
  effStartDate: "",
  createTime: "",
  effEndDate: "",
  checkBoxInd: null,
  overrideInd: "N",
  dsValue: "",
  createUserId: "",
  lastUpdtTime: "",
  lastUpdtUserId: "",
  planCode: null,
  message: null,
  type: "",
  effEndDateFrmt: "99/99/9999",
  effStartDateFrmt: "",
  frmtCreateTime: "",
  frmtLastUpdtTime: "",
  showAll: "",
};

class MbrDsInfo extends Component {
  constructor(props) {
    super(props);
    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
        date_format2: customValidations.date_format99,
        first_day_of_month: customValidations.first_day_of_month,
        last_day_of_month: customValidations.last_day_of_month99,
        after_start_date: customValidations.c_after_or_equal_99,
      },
    });
    this.state = {
      mbrDsInfoVo: INITIAL_STATE,
      data: this.props.mbrDsInfoData,
      dscode:false,
      showAllData: null,
      modified: false,
      isNewSegment: false,
      showAllActive: true,
      editable: false,
      page: 0,
      selectedIndex: 0,
      closePopup: false,
      message: "",
      memberId: this.props.mbrSearchCriteria.memberId,
      disableValue: false,
      rowsPerPage: 10,
      func1: this.showAll.bind(this),
      showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
    };
  }

  async componentDidMount() {
    let { showAllActiveInd, Indi } = this.props.showAllActiveInd;
    if (this.props.showAllActiveInd.showAllActiveInd === false) {
      this.showAll(true, this.props.mbrSearchCriteria.memberId);
    } else if (
      !isEmpty(this.props.mbrDsInfoData) &&
      this.props.mbrDsInfoData !== null
    ) {
      let mbrDsInfoVo = this.props.mbrDsInfoData[0];
      await this.setState({
        mbrDsInfoVo: mbrDsInfoVo,
        data: this.props.mbrDsInfoData,
      });
    }
    if (showAllActiveInd === false && Indi === "B") {
      this.showAll(true);
    }
    if (showAllActiveInd === true) {
      this.showAll(false);
    }
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.mbrSearchCriteria.memberId !== prevState.memberId) {
      if (!isEmpty(nextProps.mbrDsInfoData)) {
        return {
          mbrDsInfoVo: nextProps.mbrDsInfoData[0],
          data: nextProps.mbrDsInfoData,
          showAllData: null,
          //showAllActive: true,
          modified: false,
          isNewSegment: false,
          editable: false,
          selectedIndex: 0,
          memberId: nextProps.mbrSearchCriteria.memberId,
          model: prevState.func1(
            nextProps.showAllActiveInd.showAllActiveInd === false ? true : "N"
          ),
        };
      }
      return {
        mbrDsInfoVo: {
          ...INITIAL_STATE,
          memberId: nextProps.mbrSearchCriteria.memberId,
        },
        data: [],
        showAllData: null,
        // showAllActive: true,
        modified: false,
        isNewSegment: false,
        editable: false,
        selectedIndex: 0,
        memberId: nextProps.mbrSearchCriteria.memberId,
        model: prevState.func1(
          nextProps.showAllActiveInd.showAllActiveInd === false ? true : "N"
        ),
      };
    }

    if (
      nextProps.showAllActiveInd.showAllActiveInd !== prevState.showAllActiveInd
    ) {
      if (nextProps.showAllActiveInd.showAllActiveInd === false) {
        return {
          model: prevState.func1(true),
        };
      } else if (nextProps.showAllActiveInd.showAllActiveInd === true) {
        return {
          model: prevState.func1(false),
        };
      }
    }

    return null;
  }

  handleCheckBox = (name) => (event) => {
    let val = event.target.value === "Y" ? "N" : "Y";

    if (val === "Y") {
      alert("Do you want to suppress the TC 75 transaction");
    }
    this.setState((prevState) => ({
      mbrDsInfoVo: {
        ...prevState.mbrDsInfoVo,
        [name]: val,
      },
      modified: true,
    }));
  };

  selectRow = async (index) => {
    const selectedVo = this.state.data[index];
    this.setState({dscode:false});
    this.setState(() => ({
      mbrDsInfoVo: { ...selectedVo }, // copy data
      editable: false, // readOnly
      isNewSegment: false, //Not a new SEgment
      selectedIndex: index,
      modified: false,
      disableValue: false,
    }));
  };

  showAll = async (flag) => {
    const { showAllData } = this.state;
    const memberId = this.props.mbrSearchCriteria.memberId;

    if (flag === true) {
      if (showAllData === null) {
        const data = await this.props.getShowAll({
          memberId: memberId + "/Y",
          url: "GET_DSINFO",
        });
        if (null != data) {
          const selectedVO = !isEmpty(data) ? data[0] : { ...INITIAL_STATE };
          this.setState(() => ({
            data: data,
            mbrDsInfoVo: selectedVO,
            showAllData: data,
            showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
            selectedIndex: 0,
            editable: false,
            isNewSegment: false,
          }));
        }
      } else {
        const selectedVO = !isEmpty(showAllData)
          ? showAllData[0]
          : { ...INITIAL_STATE };

        this.setState(() => ({
          data: showAllData,
          mbrDsInfoVo: selectedVO,
          showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
          selectedIndex: 0,
          editable: false,
          isNewSegment: false,
        }));
      }
    } else {
      if (flag === "N") {
         await this.props.getShowAll({
          memberId: memberId + "/Y",
          url: "GET_DSINFO",
        });
      } else {
        let recodN =
          (await this.state.data) === null
            ? []
            : this.state.data.filter((role) => role.overrideInd === "N");

        await this.props.updateIndData(recodN);
      }

      const selectedVO = !isEmpty(this.props.mbrDsInfoData)
        ? this.props.mbrDsInfoData[0]
        : { ...INITIAL_STATE };
      this.setState(() => ({
        data: this.props.mbrDsInfoData,
        mbrDsInfoVo: selectedVO,
        showAllActiveInd: this.props.showAllActiveInd.showAllActiveInd,
        selectedIndex: 0,
        editable: false,
        isNewSegment: false,
      }));
    }
  };

  handleStartDate = (fieldId) => {
    var self = this;
    DateUtil.getDatePicker(fieldId).on("change", (e) => {
      self.setDate(e.target.name, e.target.value);
    });
  };

  handleDates = (event) => {
    dateChk = {};
    var self = this;
    let fieldId = "#" + event.target.name;

    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        if (
          dateChk.name !== e.target.name ||
          dateChk.value !== e.target.value
        ) {
          self.setDate(e.target.name, e.target.value);
        }
        dateChk.name = e.target.name;
        dateChk.value = e.target.value;
      });
  };

  setDate = (name, value) => {
    this.setState((prevState) => ({
      mbrDsInfoVo: {
        ...prevState.mbrDsInfoVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleDate = (event) => {
    let value = event.target.value;
    let name = event.target.name;
    this.setState((prevState) => ({
      mbrDsInfoVo: {
        ...prevState.mbrDsInfoVo,
        [name]: handleDateChange(value),
      },
      modified: true,
    }));
  };

  goBack = () => {
    // this.state.mbrDsInfoVo.effStartDateFrmt=null
    //this.state.mbrDsInfoVo.dsCd=null

    const index = this.state.selectedIndex;
    const { mbrDsInfoData } = this.props;
    let mbrDsInfoVo = INITIAL_STATE;

    if (!isEmpty(mbrDsInfoData)) {
      mbrDsInfoVo = this.props.mbrDsInfoData[index];
    }

    this.setState({
      dscode:false,
      isNewSegment: false,
      editable: false,
      modified: false,
      mbrDsInfoVo: mbrDsInfoVo,
    });
    this.validator.hideMessages();
  };

  handleChangePage = (index) => {
    this.selectRow(index);
  };

  handlechange = (event) => {
    let value = event.target.value.toUpperCase();
    let name = event.target.name;
    this.setState((prevState) => ({
      mbrDsInfoVo: {
        ...prevState.mbrDsInfoVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleOnBlur = (event) => {
    let value = event.target.value.trim();
    let name = event.target.name;
    this.setState((prevState) => ({
      mbrDsInfoVo: {
        ...prevState.mbrDsInfoVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleChangeSearchSelect = (name) => async (event) => {
    let value = event.value;
    await this.setState((prevState) => ({
      mbrDsInfoVo: {
        ...prevState.mbrDsInfoVo,
        [name]: value,
      },
      modified: true,
    }));

    this.test();
  };
  test = async () => {
    let { mbrDsInfoVo } = this.state;
    const isSuperUser = this.props.loginData.profiles.findIndex((data) => {
      return data.label === "SUPUSER" && data.value === "Y";
    });

    if (mbrDsInfoVo.dsCd === "PWO") {
      this.setState({
        mbrDsInfoVo: {
          ...this.state.mbrDsInfoVo,
          checkBoxInd: "N",
          effStartDateFrmt: this.props.searchResultsVo.cpmDate,
        },
      });
    } else {
      if (
        isSuperUser === -1 &&
        (mbrDsInfoVo.dsCd === "PRTA" ||
          mbrDsInfoVo.dsCd === "PRTB" ||
          mbrDsInfoVo.dsCd === "PRTD" ||
          mbrDsInfoVo.dsCd === "MED" ||
          mbrDsInfoVo.dsCd === "MBI" ||
          mbrDsInfoVo.dsCd === "STC")
      ) {
        let msg =
          this.state.mbrDsInfoVo.dsCd +
          " is Reserved for system use, Please select valid code from the list";

        await this.setState({
          message: msg,
          closePopup: true,
          mbrDsInfoVo: { ...this.state.mbrDsInfoVo, dsCd: "" },
        });
      } else {
        if (
          mbrDsInfoVo.dsCd === "PRTA" ||
          mbrDsInfoVo.dsCd === "PRTB" ||
          mbrDsInfoVo.dsCd === "PRTD"
        ) {
          this.setState({ disableValue: true });
        } else {
          this.setState({ disableValue: false });
        }
      }
    }
  };

  countPWOSegment = () => {
    let value = 0;
    for (let i = 0; i < this.props.mbrDsInfoData.length; i++) {
      if (this.props.mbrDsInfoData[i].dsCd === "PWO") {
        value += 1;
      }
    }
    this.setState({ count: value });
    return value;
  };

  modelSegment = () => {
    this.setState({dscode:false})
    let mbrDsInfoVo = this.state.mbrDsInfoVo;
    const isSuperUser = this.props.loginData.profiles.findIndex((data) => {
      return data.label === "SUPUSER" && data.value === "Y";
    });

    if (
      isSuperUser === -1 &&
      (mbrDsInfoVo.dsCd === "PRTA" ||
        mbrDsInfoVo.dsCd === "PRTB" ||
        mbrDsInfoVo.dsCd === "PRTD" ||
        mbrDsInfoVo.dsCd === "MED" ||
        mbrDsInfoVo.dsCd === "MBI" ||
        mbrDsInfoVo.dsCd === "STC")
    ) {
      let msg = mbrDsInfoVo.dsCd + " is Reserved for system use";
      this.setState({ message: msg, closePopup: true });
      return false;
    } else if (mbrDsInfoVo.overrideInd === "Y") {
      let msg = "This Record is not active ";
      this.setState({ message: msg, closePopup: true });
    } else {
      if (
        mbrDsInfoVo.dsCd === "PRTA" ||
        mbrDsInfoVo.dsCd === "PRTB" ||
        mbrDsInfoVo.dsCd === "PRTD"
      ) {
        this.setState({ disableValue: true });
      } else {
        this.setState({ disableValue: false });
      }
      this.setState({
        editable: true,
        newSegment: false,
      });
    }
  };
  handleChangeSearchSelectAuto = async (data, name) => {
    let value = data.value;
    if(data.value.length >0){
      this.setState({dscode:false});
    }else{
      this.setState({dscode:true});
      
    }
    await this.setState((prevState) => ({
      mbrDsInfoVo: {
        ...prevState.mbrDsInfoVo,
        [name]: value,
      },
      modified: true,
    }));

    this.test();
  };
  createNewSegment = () => {
    INITIAL_STATE.memberId = this.props.mbrSearchCriteria.memberId;
    INITIAL_STATE.customerId = this.props.loginData.loginVo.customerId;
    this.validator.hideMessages();
    this.setState({
      dscode:false,
      editable: true,
      isNewSegment: true,
      mbrDsInfoVo: {
        ...INITIAL_STATE,
      },
    });
  };

  addNewSegment = (event) => {
    if(this.state.mbrDsInfoVo.dsCd.length>0){
      this.setState({dscode:false})
    }else{
      this.setState({dscode:true})
    }
    if (this.state.mbrDsInfoVo.dsCd === "HSPC") {
      this.validator.fields["EndDate"] = true;
    }

    this.validator.hideMessages();

    event.preventDefault();
    let mbrDsInfoVo = this.state.mbrDsInfoVo;

    const isSuperUser = this.props.loginData.profiles.findIndex((data) => {
      return data.label === "SUPUSER" && data.value === "Y";
    });

    if (
      isSuperUser !== -1 &&
      (mbrDsInfoVo.dsCd === "PRTA" ||
        mbrDsInfoVo.dsCd === "PRTB" ||
        mbrDsInfoVo.dsCd === "PRTD")
    ) {
      this.validator.fields.Value = true;
    }
    if (this.validator.allValid()) {
      ConfirmBox(this.confirmAddMbrDsInfo, Type.ADD, this.props);
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  confirmAddMbrDsInfo = async () => {
    const { mbrDsInfoVo } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(mbrDsInfoVo.showAll = val),
    });
    const status = await this.props.DSINFOUpdate(this.state.mbrDsInfoVo);

    let message = "";

    if (status === "success") {
      message = ActionTypes.ADD;
      this.setState({
        isNewSegment: false,
        editable: false,
        modified: false,
        mbrDsInfoVo: this.props.mbrDsInfoData[0],
        data: this.props.mbrDsInfoData,
        selectedIndex: 0,
        showAllData: null,
      });
    } else {
      message = status;
    }

    this.setState({
      closePopup: true,
      message: message,
    });

    this.validator.hideMessages();
  };
  updateDsInfo = (event) => {
    if(this.state.mbrDsInfoVo.dsCd.length>0){
      this.setState({dscode:false})
    }else{
      this.setState({dscode:true})
    }
    let mbrDsInfoVo = this.state.mbrDsInfoVo;
    if (mbrDsInfoVo.dsCd === "HSPC") {
      this.validator.fields["EndDate"] = true;
    }
    event.preventDefault();

    if (
      this.state.mbrDsInfoVo.dsCd === "PWO" &&
      this.state.mbrDsInfoVo.checkBoxInd === "Y"
    ) {
      this.setState({
        mbrDsInfoVo: {
          ...this.state.mbrDsInfoVo,
          effStartDateFrmt: this.state.oldeffStartDateFrmt,
        },
      });
    }
    const isSuperUser = this.props.loginData.profiles.findIndex((data) => {
      return data.label === "SUPUSER" && data.value === "Y";
    });

    if (
      isSuperUser !== -1 &&
      (mbrDsInfoVo.dsCd === "PRTA" ||
        mbrDsInfoVo.dsCd === "PRTB" ||
        mbrDsInfoVo.dsCd === "PRTD")
    ) {
      this.validator.fields.Value = true;
    }

    if (this.validator.allValid() ||this.validator.fields["EndDate"] ) {
      ConfirmBox(this.confirmUpdateDsInfo, Type.UPDATE, this.props);
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  confirmUpdateDsInfo = async () => {
    const { mbrDsInfoVo } = this.state;
    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(mbrDsInfoVo.showAll = val),
    });

    let status = await this.props.DSINFOUpdate(this.state.mbrDsInfoVo);
    let editable = "";
    if ("success" === status) {
      status = messages.UPDATED_SUCCESSFULLY;
      editable = false;
    } else {
      editable = true;
    }

    this.setState(() => ({
      message: status,
      isNewSegment: false,
      data: this.props.mbrDsInfoData,
      mbrDsInfoVo: this.props.mbrDsInfoData[this.state.selectedIndex],
      showAllData: null,
      closePopup: true,
      modified: false,
      editable: editable,
    }));
    this.validator.hideMessages();
  };

  deleteDsInfo = () => {
    let { mbrDsInfoVo } = this.state;

    let countVal = this.countPWOSegment();
    let msg;
    const isSuperUser = this.props.loginData.profiles.findIndex((data) => {
      return data.label === "SUPUSER" && data.value === "Y";
    });

    if (
      isSuperUser === -1 &&
      (mbrDsInfoVo.dsCd === "PRTA" ||
        mbrDsInfoVo.dsCd === "PRTB" ||
        mbrDsInfoVo.dsCd === "PRTD" ||
        mbrDsInfoVo.dsCd === "MED" ||
        mbrDsInfoVo.dsCd === "MBI" ||
        mbrDsInfoVo.dsCd === "STC")
    ) {
      msg = "Delete is not allowed for this DS Code";
      this.setState({ message: msg, closePopup: true });
    } else if (this.state.mbrDsInfoVo.dsCd === "PWO" && countVal === 1) {
      msg = "You must have at least one PWO Segment";
      this.setState({ message: msg, closePopup: true });
    } else if (mbrDsInfoVo.overrideInd === "Y") {
      let msg = "This Record is not active ";
      this.setState({ message: msg, closePopup: true });
    } else {
      ConfirmBox(this.confirmDeleteDsInfo, Type.DELETE, this.props);
    }
  };

  confirmDeleteDsInfo = async () => {
    const { mbrDsInfoVo } = this.state;

    let val =
      this.props.showAllActiveInd.showAllActiveInd === false ? "Y" : "N";

    this.setState({
      ...(mbrDsInfoVo.showAll = val),
    });

    const status = await this.props.DSINFODelete(mbrDsInfoVo);
    let showAllData = null;

    let newVO = isEmpty(this.props.mbrDsInfoData)
      ? INITIAL_STATE
      : this.props.mbrDsInfoData[0];

    let message = "";

    if (status === "success") {
      message = ActionTypes.DELETE;
    } else {
      message = status;
    }

    this.setState({
      mbrDsInfoVo: newVO,
      data: showAllData !== null ? showAllData : this.props.mbrDsInfoData,
      showAllData: showAllData,
      closePopup: true,
      message: message,
      selectedIndex: 0,
      isNewSegment: false,
      editable: false,
      modified: false,
    });
    this.validator.hideMessages();
  };

  modalClosed = () => {
    this.setState({ closePopup: false });
  };

  handleChangeRowsPerPage = async (rowsPerPage) => {
    await this.setState(() => ({
      rowsPerPage: rowsPerPage,
    }));
  };

  render() {
    const { classes, dropdowns, mbrDsInfoData } = this.props;
    const { mbrDsInfoVo, data } = this.state;
  
    let ButtonPanel = (
      <MemberButtonPanel
        isNewSegment={this.state.isNewSegment}
        showAll={this.showAll}
        toggleLabel={this.state.showAllActive}
        newSegment={this.createNewSegment}
        modelSegment={this.modelSegment}
        modified={this.state.modified}
        editable={this.state.editable}
        delete={this.deleteDsInfo}
        update={this.updateDsInfo}
        disable={isEmpty(mbrDsInfoData)}
      />
    );

    const array = dropdowns.validDsCodes.filter(
      (object) =>
        object.value === "HSPC" && object.value === this.state.mbrDsInfoVo.dsCd
    );
    return (
      <React.Fragment>
        <Modal
          dialogTitle="DSINFO"
          message={this.state.message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>
        <Paper
          elevation={0}
          className={classNames(classes.card, "animated fadeIn")}
        >
          {data ? (
            <DataTable
              data={data}
              header={header}
              subtab
              rowsPerPage={this.state.rowsPerPage}
              clicked={this.selectRow}
              index={this.state.selectedIndex}
              sortable={true}
              rowsPerPageOptions={[10, 15, 20]}
              handleChangeRowsPerPage={this.handleChangeRowsPerPage}
              handleChangePage={this.handleChangePage}
              dateColumn={["effStartDateFrmt", "effEndDateFrmt"]}
            />
          ) : null}

          {!isEmpty(data) || this.state.isNewSegment ? (
            <React.Fragment>
              <div className={classes.buttonContainer}> {ButtonPanel}</div>

              <form autoComplete="off" >  {/*  onSubmit={this.submitHandler} */}
                <div class="panel-body margin-top1">
                  <div className={classes.container}>
                    <div>
                      <InputField
                        name="effStartDateFrmt"
                        placeholder="MM/DD/YYYY"
                        required={this.state.editable}
                        maxLength="10"
                        onClick={this.handleDates}
                        label="Start Date"
                        value={mbrDsInfoVo.effStartDateFrmt}
                        onChange={this.handleDate}
                        onBlur={this.handleOnBlur}
                        disabled={!this.state.editable}
                      />

                      <div className={classes.validationMessage}>
                        {mbrDsInfoVo.dsCd === "HSPC" ||
                          mbrDsInfoVo.dsCd === "TRAN" ||
                          mbrDsInfoVo.dsCd === "DIAL" ? null : (
                            <div>
                              {this.validator.message(
                                "StartDate",
                                mbrDsInfoVo.effStartDateFrmt,
                                "required|date_format|first_day_of_month"
                              )}
                            </div>
                          )}
                      </div>
                    </div>

                    <div>
                      <InputField
                        name="effEndDateFrmt"
                        placeholder="MM/DD/YYYY"
                        maxLength="10"
                        required={this.state.editable}
                        onClick={this.handleDates}
                        label="End Date"
                        onChange={this.handleDate}
                        onBlur={this.handleOnBlur}
                        value={mbrDsInfoVo.effEndDateFrmt}
                        disabled={!this.state.editable}
                      />

                      <div className={classes.validationMessage}>
                        {array.length === 0
                          ? this.validator.message(
                            "EndDate",
                            mbrDsInfoVo.effEndDateFrmt,
                            "last_day_of_month"
                          )
                          : null}
                        {this.validator.message(
                          "End-Date",
                          mbrDsInfoVo.effEndDateFrmt,
                          [
                            "required",
                            "date_format2",
                            {
                              after_start_date: mbrDsInfoVo.effStartDateFrmt,
                            },
                          ]
                        )}
                      </div>
                    </div>

                    {mbrDsInfoVo.dsCd === "PWO" ? (
                      <div className={classes.checkbox}>
                        <FormLabel classes={{ root: classes.formLabel }}>
                          Bypass 75 TXN
                        </FormLabel>
                        <Checkbox
                          name="checkBoxInd"
                          style={{ width: 36, height: 36 }}
                          icon={
                            <CheckBoxOutlineBlankIcon
                              style={{ fontSize: "16px" }}
                            />
                          }
                          checkedIcon={
                            <CheckBoxIcon className={classes.checkboxmember} />
                          }
                          disabled={!this.state.editable}
                          checked={
                            mbrDsInfoVo.checkBoxInd === "Y" ? true : false
                          }
                          onClick={this.handleCheckBox("checkBoxInd")}
                          value={mbrDsInfoVo.checkBoxInd}
                          inputProps={{
                            "aria-label": "primary checkbox",
                          }}
                        />
                      </div>
                    ) : null}

                    <div>
                      <InputField
                        name="overrideInd"
                        InputProps={{ className: classes.textFont }}
                        label="Override"
                        className={classes.textField}
                        value={mbrDsInfoVo.overrideInd}
                        InputLabelProps={{
                          className: classes.label,
                          shrink: true,
                        }}
                        onChange={this.handlechange}
                        disabled
                      />
                      <div className={classes.validationMessage} />
                    </div>

                    <div className={classes.dsinfodropdown}>
                      <Autocomplete1
                        handleChange={this.handleChangeSearchSelectAuto}
                        label="Code"
                        options={dropdowns.validDsCodes}
                        defaultValue={dropdowns.validDsCodes[0]}
                        value={
                          dropdowns.validDsCodes.filter(
                            (data) => data.value === mbrDsInfoVo.dsCd
                          )[0]
                        }
                        name="dsCd"
                        disabled={!this.state.editable}
                        width="260px"
                      />
                      <div className={classes.validationMessage}>
                        {//  disabled={!this.state.editable}
                        // (this.state.mbrDsInfoVo.dsCd.trim().length === 0) &&
                        this.state.dscode && ('The DS code field is reqired')
                        
                        }
                       
                      

                              {/* {this.validator.message(
                                "StartDate",
                                this.state.mbrDsInfoVo.dsCd,
                                "required|date_format|first_day_of_month"
                              )} */}
                      </div>
                    </div>

                    <div>
                      <InputField
                        name="dsValue"
                        maxLength={50}
                        InputProps={{ className: classes.textFont }}
                        label="Value"
                        className={classes.textField}
                        value={mbrDsInfoVo.dsValue}
                        InputLabelProps={{
                          className: classes.label,
                          shrink: true,
                        }}
                        onChange={this.handlechange}
                        onBlur={this.handleOnBlur}
                        disabled={
                          !this.state.editable ||
                          this.state.disableValue === true
                        }
                      />

                      <div className={classes.validationMessage}>
                        {this.validator.message(
                          "Value",
                          mbrDsInfoVo.dsValue,
                          "required"
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </form>

              <HistoryData
                createTime={this.state.mbrDsInfoVo.createTime}
                createUserId={this.state.mbrDsInfoVo.createUserId}
                lastUpdtTime={this.state.mbrDsInfoVo.lastUpdtTime}
                lastUpdtUserId={this.state.mbrDsInfoVo.lastUpdtUserId}
                isNewSegment={this.state.isNewSegment}
                reset={this.createNewSegment}
                addSegment={this.addNewSegment}
                back={this.goBack}
                footer="true"
              />
            </React.Fragment>
          ) : (
              <div className={classes.buttonContainer}> {ButtonPanel}</div>
            )}
        </Paper>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    mbrDsInfoData: state.memberSearch.searchResultsVo.mbrDsInfoList,
    searchResultsVo: state.memberSearch.searchResultsVo,
    dropdowns: state.membercache,
    mbrSearchCriteria: state.memberSearch.mbrSearchCriteria,
    loginData: state.loginData,
    memberIdCheck: state.memberSearch.memberId,
    searchCriteriaVo: state.memberSearch.searchCriteriaVo,
    showAllActiveInd: state.memberSearch.showAllActiveIndi,
  };
};

const mapDispatchToProps = {
  DSINFODetails,
  DSINFOUpdate,
  DSINFODelete,
  getShowAll,
  MemberSearch,
  updateIndData,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(MbrDsInfo));
