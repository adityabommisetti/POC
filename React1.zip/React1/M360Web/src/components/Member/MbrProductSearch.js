import React, { Component } from "react";

import Button from "@material-ui/core/Button";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import Checkbox from "@material-ui/core/Checkbox";
import DataTable from "../Home/DataTable";
import * as DateUtil from "../../utils/DatePicker";
import FormLabel from "@material-ui/core/FormLabel";
import InputField from "../UI/InputField";
import Paper from "@material-ui/core/Paper";
import classNames from "classnames";
import { connect } from "react-redux";
import { GROUP_TABLE_HEADER as header } from "../../constants/Headers/MemberHeaders";
import isEmpty from "lodash/isEmpty";
import { mbrProductSearch } from "../../redux/actions/MemberActions";
import { withStyles } from "@material-ui/core/styles";
import moment from "moment";
const styles = (theme) => ({
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    height: "40px",
    width: "160px",
  },
  formLabel: {
    fontSize: "12px !important",
    color: "rgba(39, 108, 155, 1)",
  },
  checkbox: {
    marginLeft: "25px",
    width: "180px",
    height: "36px",
    marginTop: "15px",
    fontSize: "12px",
    color: "rgba(0, 0, 0, 0.38)",
    display: "inline-block",
    verticalAlign: "middle",
  },
  root: {
    ...theme.mixins.gutters(),
    paddingTop: theme.spacing.unit * 2,
    paddingBottom: theme.spacing.unit * 2,
    width: "100%",
    alignSelf: "center",
    marginLeft: "auto",
    marginRight: "auto",
  },
  alignCenter: {
    textAlign: "center",
    width: "100%",
  },
  div1: {
    alignSelf: "center",
    marginLeft: "auto",
    marginRight: "auto",
    width: "fit-content",
  },
  div2: {
    width: "95%",
    marginLeft: "auto",
    alignSelf: "center",
    marginRight: "auto",
    display: "flex",
    flexWrap: "wrap",
  },
  table: {
    width: "90%",
    alignSelf: "center",
    marginLeft: "auto",
    marginRight: "auto",
  },
  fieldset: {
    margin: "10px",
    padding: "0 10px 10px",
    border: "1px solid #9e8e8e",
    borderRadius: "8px",
    paddingTop: "10px",
  },
  legend: {
    padding: "2px 4px",
    background: "#fff",
    textAlign: "center",
  },
  submit: {
    width: "100px",
  },
  button: {
    margin: theme.spacing.unit,
    color: "#fff",
    fontSize: "10px",
    padding: "9px 5px",
    backgroundColor: "#389bde",
    borderRadius: "90px",
    boxShadow:
      "0px 1px 2px 0px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0,0,0,0.24), 0px 3px 1px -2px rgba(0,0,0,0.02)",
    [theme.breakpoints.down("sm")]: {
      fontSize: "8px",
      width: "80px",
    },
  },
  container: {
    display: "flex",
    flexWrap: "wrap",
    width: "fit-content",
  },
  popUpIcons: {
    fontSize: "24px",
    paddingLeft: "20px",
    paddingRight: "20px",
    paddingTop: "25px",
    cursor: "pointer",
  },
  checkboxmember: {
    fontSize: "16px",
    color: "rgba(39, 108, 155, 1)",
  },
});

class ProductSearch extends Component {
  constructor(props) {
    super(props);
    this.state = {
      page: 0,
      searchVo: {
        memberId: this.props.search.memberId,
        grpId: this.props.search.grpId,
        groupName: this.props.search.groupName,
        productId: this.props.search.productId,
        productName: this.props.search.productName,
        effDate: this.props.search.effStartDateFrmt,
        outOfArea: this.props.search.outOfArea,
        planId: this.props.search.planId,
        pbpId: this.props.search.pbpId,
        zipCd5: this.props.search.zip5 ? this.props.search.zip5 : "",
        zipCd4: this.props.search.zip4 ? this.props.search.zip4 : "",
        applType: "",
        pbpSegmentId: this.props.search.pbpSegmentId,
        mcCustNbr: this.props.search.mcCustNbr,
        ssaState: "",
        ssaCnty: "",
        customerId: this.props.search.customerId,
      },
      selectedRowIndex: 0,
      data: this.props.data,
      message: null,
      checked: false,
    };
  }

  componentDidMount() {
    const { mbrAddressList, mbrDsInfoList } = this.props.searchResultsVo;

    const checkDate = this.state.searchVo.effDate;

    let OOA = null;

    const obj = mbrAddressList.filter((data) => {
      const startDate = data.effStartDateFrmt;

      const endDate = data.effEndDateFrmt;

      return (
        data.addressType === "PRIM" &&
        moment(checkDate).isSameOrAfter(startDate) &&
        !moment(checkDate).isSameOrAfter(endDate)
      );
    });

    mbrDsInfoList.map((data) => {
      const startDate = data.effStartDateFrmt;

      const endDate = data.effEndDateFrmt;

      if (
        moment(checkDate).isSameOrAfter(startDate) &&
        !moment(checkDate).isSameOrAfter(endDate) &&
        data.dsCd === "OOA"
      ) {
        OOA = data.dsValue;
      }
      return null;
    });
    this.setState(
      (prevState) => ({
        searchVo: {
          ...prevState.searchVo,
          zipCd4: obj[0] ? obj[0].zipCd4 : "",
          zipCd5: obj[0] ? obj[0].zipCd5 : "",
          outOfArea: OOA ? "Y" : "N",
        },
        checked: OOA ? true : false,
      }),
      async () => await this.props.mbrProductSearch(this.state.searchVo)
    );
  }

  onRowSelect = (index, page) => {
    this.setState({
      selectedRowIndex: index,
      page: page,
    });
  };

  onSubmit = (event) => {
    event.preventDefault();
    const tableData = [...this.props.data];
    const selectedVo = tableData[this.state.selectedRowIndex];
    this.props.setProduct(selectedVo);
    this.props.close();
  };

  handleDates = (event) => {
    var self = this;
    const fieldId = "#" + event.target.id;
    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        self.setDate(e.target.id, e.target.value);
        document.getElementById(fieldId.substr(1)).focus();
      });
  };

  reset = () => {
    this.setState(() => ({
      searchVo: {
        customerId: "",
        memberId: "",
        grpId: "",
        groupName: "",
        productId: "",
        productName: "",
        effDate: this.props.search.effStartDateFrmt,
        outOfArea: "N",
        zipCd5: "",
        zipCd4: "",
        planId: "",
        pbpId: "",
        pbpSegmentId: "",
        mcCustNbr: "",
        ssaState: "",
        ssaCnty: "",
        applType: "",
      },
      checked: false,
    }));
  };

  filtersearch = (event) => {
    event.preventDefault();
    this.props.mbrProductSearch(this.state.searchVo);
  };

  handleChange = (e) => {
    let value = e.target.value;
    let name = [e.target.name];

    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value,
      },
    }));
  };

  handleOnBlur = (e) => {
    let value = e.target.value.trim();
    let name = [e.target.name];

    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        [name]: value,
      },
    }));
  };

  checked = () => {
    const value = !this.state.checked;
    this.setState((prevState) => ({
      searchVo: {
        ...prevState.searchVo,
        outOfArea: value ? "Y" : "N",
      },
      checked: value,
    }));
  };

  render() {
    const { classes, headerLabel } = this.props;
    const { searchVo, selectedRowIndex, checked, page } = this.state;
    return (
      <React.Fragment>
        <Paper
          className={classes.root}
          elevation={0}
          style={{ padding: "15px" }}
        >
          <fieldset className={classes.fieldset}>
            <legend className={classes.legend}>{headerLabel}</legend>
            <form
              className={classes.container}
              autoComplete="off"
              onSubmit={(e) => this.search(e)}
            >
              <div className={classes.container} style={{ margin: "0px auto" }}>
                <InputField
                  name="groupName"
                  label="Group"
                  className={classes.textField}
                  margin="normal"
                  InputLabelProps={{ className: classes.label }}
                  value={searchVo.groupName}
                  maxLength={30}
                  width="320px"
                  onChange={this.handleChange}
                  onBlur={this.handleOnBlur}
                />
                <InputField
                  name="productName"
                  label="Product"
                  className={classes.textField}
                  margin="normal"
                  InputLabelProps={{ className: classes.label }}
                  value={searchVo.productName}
                  onChange={this.handleChange}
                  onBlur={this.handleOnBlur}
                  width="320px"
                  maxLength={50}
                />
                <InputField
                  required
                  name="effDate"
                  placeholder="MM/DD/YYYY"
                  label="Effective Date"
                  className={classes.textField}
                  margin="normal"
                  onClick={this.handleDates}
                  InputLabelProps={{ className: classes.label }}
                  value={searchVo.effDate}
                  maxLength={10}
                  onChange={this.handleChange}
                  onBlur={this.handleOnBlur}
                />
                <InputField
                  name="grpId"
                  label="Group ID"
                  className={classes.textField}
                  margin="normal"
                  InputLabelProps={{ className: classes.label }}
                  value={searchVo.grpId}
                  maxLength={30}
                  onChange={this.handleChange}
                  onBlur={this.handleOnBlur}
                />
                <InputField
                  name="productId"
                  label="Product ID"
                  className={classes.textField}
                  margin="normal"
                  InputLabelProps={{ className: classes.label }}
                  value={searchVo.productId}
                  maxLength={30}
                  onChange={this.handleChange}
                  onBlur={this.handleOnBlur}
                />
                <InputField
                  name="planId"
                  label="Plan"
                  className={classes.textField}
                  margin="normal"
                  InputLabelProps={{ className: classes.label }}
                  value={searchVo.planId}
                  maxLength={5}
                  onChange={this.handleChange}
                  onBlur={this.handleOnBlur}
                />
                <InputField
                  name="pbpId"
                  label="PBP"
                  className={classes.textField}
                  margin="normal"
                  InputLabelProps={{ className: classes.label }}
                  value={searchVo.pbpId}
                  onChange={this.handleChange}
                  onBlur={this.handleOnBlur}
                  maxLength={3}
                />
                <InputField
                  name="pbpSegmentId"
                  label="Segment"
                  className={classes.textField}
                  margin="normal"
                  InputLabelProps={{ className: classes.label }}
                  value={searchVo.pbpSegmentId}
                  maxLength={5}
                  onChange={this.handleChange}
                  onBlur={this.handleOnBlur}
                />
                <InputField
                  required
                  name="zipCd5"
                  label="Zip 5"
                  className={classes.textField}
                  margin="normal"
                  InputLabelProps={{ className: classes.label }}
                  value={searchVo.zipCd5}
                  maxLength={5}
                  onChange={this.handleChange}
                  onBlur={this.handleOnBlur}
                />

                <InputField
                  name="zipCd4"
                  label="Zip 4"
                  className={classes.textField}
                  margin="normal"
                  InputLabelProps={{ className: classes.label }}
                  value={searchVo.zipCd4}
                  onChange={this.handleChange}
                  onBlur={this.handleOnBlur}
                  maxLength={4}
                />

                <div className={classes.checkbox}>
                  <FormLabel classes={{ root: classes.formLabel }}>
                    Out Of Area
                  </FormLabel>
                  <Checkbox
                    style={{ width: 36, height: 36 }}
                    icon={
                      <CheckBoxOutlineBlankIcon style={{ fontSize: "16px" }} />
                    }
                    checkedIcon={
                      <CheckBoxIcon className={classes.checkboxmember} />
                    }
                    onChange={this.checked}
                    checked={checked}
                  />
                </div>
              </div>
              <div className={classes.div1}>
                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={this.filtersearch}
                >
                  <i className="material-icons">search</i>
                </Button>

                <Button
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={this.props.close}
                >
                  <i className="material-icons">cancel</i>
                </Button>
                <Button
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={this.reset}
                >
                  <i class="material-icons">refresh</i>
                </Button>
              </div>
            </form>
          </fieldset>
        </Paper>
        {this.props.data ? (
          <DataTable
            data={this.props.data}
            header={header}
            rowsPerPage={10}
            clicked={this.onRowSelect}
            index={selectedRowIndex}
            pageNo={page}
          />
        ) : null}

        {!isEmpty(this.props.data) ? (
          <div className={classes.div1}>
            <Button
              variant="contained"
              color="primary"
              className={classNames(classes.button, classes.submit)}
              onClick={this.onSubmit}
            >
              Submit
            </Button>
          </div>
        ) : null}
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    searchResultsVo: state.memberSearch.searchResultsVo,
    data: state.memberSearch.enrollSearchData,
    dropdowns: state.membercache,
  };
};

const mapDispatchToProps = {
  mbrProductSearch,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(ProductSearch));
