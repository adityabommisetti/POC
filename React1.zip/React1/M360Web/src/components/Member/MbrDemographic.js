import * as DateUtil from "../../utils/DatePicker";
import * as Type from "../../constants/ConfirmType";

import React, { Component } from "react";
import AutoComplete1 from "../UI/Select";
import {
  setValueMember,
  updateDemographic,
} from "../../redux/actions/MemberActions";

import Button from "@material-ui/core/Button";
import ConfirmBox from "../../utils/PopUp";
import HistoryData from "../UI/MemberHistory";
import InputField from "../UI/InputField";
import Modal from "../../components/UI/Modal/Modal";
import Paper from "@material-ui/core/Paper";
import SimpleReactValidator from "simple-react-validator";
import { Styles } from "../../assets/styles/Theme";
import classNames from "classnames";
import { connect } from "react-redux";
import { handleDateChange } from "../../utils/DateFormatter";
import { messages } from "../../constants/Messages";
import { withStyles } from "@material-ui/core/styles";
import { customValidations } from "../../utils/CustomValidations";

const dateChk = {};

class Demographic extends Component {
  state = {
    DemographicVo: this.props.searchResultsVo.mbrDemographicVO,
    DemographicOldVo: this.props.searchResultsVo.mbrDemographicVO,
    modified: false,
    newSegment: false,
    editable: false,
    closePopup: false,
    mbridLit: [],
  };
  constructor(props) {
    super(props);
    this.validator = new SimpleReactValidator({
      validators: {
        date_format: customValidations.date_format,
        date_format2: customValidations.date_format99,
        ValidSSN: customValidations.ValidSSN,
        phone_no: customValidations.phone_no,
      },
    });
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.searchResultsVo.mbrDemographicVO) {
      this.setState({
        DemographicVo: nextProps.searchResultsVo.mbrDemographicVO,
        editable: false,
        modified: false,
      });
    } else {
      this.setState({ modified: false });
      this.setState({
        DemographicVo: {
          ...this.state.DemographicOldVo,
        },
      });
    }
  }

  handlechange = (name) => (event) => {
    let value = event.target.value.toUpperCase();
    this.setState((prevState) => ({
      DemographicVo: {
        ...prevState.DemographicVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleOnBlur = (event) => {
    let value = event.target.value.trim();
    let name = event.target.name;

    this.setState((prevState) => ({
      DemographicVo: {
        ...prevState.DemographicVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleDate = (event) => {
    let value = event.target.value;
    let name = event.target.name;
    this.setState((prevState) => ({
      DemographicVo: {
        ...prevState.DemographicVo,
        [name]: handleDateChange(value),
      },
      modified: true,
    }));
  };

  handleDates = (event) => {
    var self = this;
    let fieldId = "#" + event.target.name;
    DateUtil.getDatePicker(fieldId)
      .datepicker("show")
      .on("change", (e) => {
        if (
          dateChk.name !== e.target.name ||
          dateChk.value !== e.target.value
        ) {
          self.setDate(e.target.name, e.target.value);
        }
        dateChk.name = e.target.name;
        dateChk.value = e.target.value;
      });
  };
  setDate = (name, value) => {
    this.setState((prevState) => ({
      DemographicVo: {
        ...prevState.DemographicVo,
        [name]: value,
      },
      modified: true,
    }));
  };
  update = (event) => {
    event.preventDefault();
    if (this.validator.allValid()) {
      ConfirmBox(this.confirmUpdate, Type.UPDATE, this.props);
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };

  confirmUpdate = async () => {
    let status = await this.props.updateDemographic(this.state.DemographicVo);

    if ("success" === status) {
      status = messages.UPDATED_SUCCESSFULLY;
    } else {
      this.setState((prevState) => ({
        DemographicVo: {
          ...this.props.searchResultsVo.mbrDemographicVO,
        },
        modified: true,
      }));
    }

    this.setState(() => ({
      message: status,
      isNewSegment: false,
      editable: false,
      modified: false,
      closePopup: true,
    }));
    this.validator.hideMessages();
  };

  handleNumberChange = (name) => (event) => {
    let value = event.target.value.replace(/[^0-9]/g, "").trim();
    if (name === "emergcyPhone" || name === "ssnFrmt") {
      value = value.replace(
        /^(?=[0-9]{10})([0-9]{3})([0-9]{3})([0-9]{4})/,
        "$1-$2-$3"
      );
    }
    this.setState((prevState) => ({
      DemographicVo: {
        ...prevState.DemographicVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleChangeSearchSelectAuto = async (data, name) => {
    let value = data.value;

    await this.setState((prevState) => ({
      DemographicVo: {
        ...prevState.DemographicVo,
        [name]: value,
      },
      modified: true,
    }));

    if (this.state.DemographicVo.maritalStatus === "") {
      await this.setState((prevState) => ({
        DemographicVo: {
          ...prevState.DemographicVo,
          maritalStatus: "U",
        },
      }));
    }
  }
  handleChangeSearchSelect = (name) => async (event) => {
    let value = event.target ? event.target.value : event.value;

    await this.setState((prevState) => ({
      DemographicVo: {
        ...prevState.DemographicVo,
        [name]: value,
      },
      modified: true,
    }));

    if (this.state.DemographicVo.maritalStatus === "") {
      await this.setState((prevState) => ({
        DemographicVo: {
          ...prevState.DemographicVo,
          maritalStatus: "U",
        },
      }));
    }
  };

  handleSSN = (name) => (event) => {
    let value = event.target.value.replace(/[^0-9]/g, "").trim();
    if (name === "emergcyPhone" || name === "ssnFrmt") {
      value = value.replace(
        /^(?=[0-9]{9})([0-9]{3})([0-9]{2})([0-9]{4})/,
        "$1-$2-$3"
      );
    }
    this.setState((prevState) => ({
      DemographicVo: {
        ...prevState.DemographicVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  modalClosed = () => {
    this.setState({ closePopup: false });
  };

  async componentDidMount() {
    const { loginProfile } = this.props;
    const MBRIDLIT = loginProfile.filter((data) => data.label === "MBRIDLIT");
    this.setState({
      mbridLit: MBRIDLIT[0],
    });
  }

  render() {
    const { classes, searchResultsVo, dropdowns, servicesEnabled } = this.props;
    const { DemographicVo, mbridLit } = this.state;

    let ButtonPanel = (
      <div className={classes.buttonContainerMbr}>
        {servicesEnabled.includes("EEUM") ? (
          <Button
            type="submit"
            variant="contained"
            color="primary"
            onClick={this.update}
            disabled={!this.state.modified}
            className={classes.button}
          >
            Update
          </Button>
        ) : null}
      </div>
    );

    return (
      <React.Fragment>
        <Modal
          dialogTitle="Demographic"
          message={this.state.message}
          show={this.state.closePopup}
          modalClosed={() => {
            this.modalClosed();
          }}
        ></Modal>

        <Paper
          elevation={0}
          className={classNames(classes.card, "animated fadeIn")}
        >
          {searchResultsVo.mbrDemographicVO ? (
            <div className="panel-body">
              <div className={classes.containerdemo}>
                <InputField
                  name="cmsEffMonthFrmt"
                  label="Effective Month"
                  placeholder="MM/YYYY"
                  value={DemographicVo.cmsEffMonthFrmt}
                  onChange={this.handlechange("cmsEffMonthFrmt")}
                  disabled={!this.state.editable}
                  width="250px"
                />
                <div className={classes.validationMessage} />
              </div>
              {ButtonPanel}
              <div className={classes.containerdemo}>
                <div style={{ width: "274px" }}>
                  <AutoComplete1

                    handleChange={this.handleChangeSearchSelectAuto}
                    label='Prefix'
                    options={dropdowns.validPrefixes}
                    defaultValue={dropdowns.validPrefixes[0]}
                    value={dropdowns.validPrefixes.filter(data => data.value === DemographicVo.prefix)[0]}
                    name='prefix'
                    disabled={this.state.editable}
                    width="250px"
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="firstName"
                    id="firstName"
                    label="First Name"
                    value={DemographicVo.firstName}
                    onChange={this.handlechange("firstName")}
                    onBlur={this.handleOnBlur}
                    disabled={this.state.editable}
                    maxLength="24"
                    width="215px"
                    required
                  />
                  <div className={classes.validationMessage}>
                    {this.validator.message(
                      "FirstName",
                      DemographicVo.firstName,
                      "required"
                    )}
                  </div>
                </div>
                <div className={classes.middleName}>
                  <InputField
                    name="middleInitial"
                    label="Middle Name"
                    value={DemographicVo.middleInitial}
                    onChange={this.handlechange("middleInitial")}
                    onBlur={this.handleOnBlur}
                    disabled={this.state.editable}
                    maxLength="1"
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="lastName"
                    label="Last Name"
                    value={DemographicVo.lastName}
                    onChange={this.handlechange("lastName")}
                    onBlur={this.handleOnBlur}
                    disabled={this.state.editable}
                    maxLength={35}
                    width="340px"
                  />
                  <div className={classes.validationMessage}>
                    {this.validator.message(
                      "LastName",
                      DemographicVo.lastName,
                      "required"
                    )}
                  </div>
                </div>
                <div style={{ width: "192px" }}>
                  <InputField
                    name="suffix"
                    label="Suffix"
                    value={DemographicVo.suffix}
                    onChange={this.handlechange("suffix")}
                    onBlur={this.handleOnBlur}
                    disabled={this.state.editable}
                    maxLength={4}
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div style={{ width: "174px" }}>
                  <AutoComplete1

                    handleChange={this.handleChangeSearchSelectAuto}
                    label='Status'
                    options={dropdowns.validMemberStatus}
                    defaultValue={dropdowns.validMemberStatus[0]}
                    value={dropdowns.validMemberStatus.filter(data => data.value === DemographicVo.memberStatus)[0]}
                    name='memberStatus'
                    disabled={this.state.editable}
                    width="150px"
                  />
                 
                  <div className={classes.validationMessage} />
                </div>{" "}
              </div>
              <div className={classes.containerdemo}>
                <div>
                  <InputField
                    name="memberId"
                    label={mbridLit.value === "TSA" ? "Wipro ID" : "M360 ID"}
                    value={DemographicVo.memberId}
                    disabled={!this.state.editable}
                    maxLength={15}
                    width="250px"
                  />
                  <div className={classes.validationMessage} />
                </div>

                <div>
                  <InputField
                    name="ssnFrmt"
                    label="(Optional) SSN"
                    value={DemographicVo.ssnFrmt}
                    onChange={this.handleSSN("ssnFrmt")}
                    onBlur={this.handleOnBlur}
                    disabled={this.state.editable}
                    maxLength="11"
                    width="215px"
                  />
                  <div className={classes.validationMessage}>
                    {this.validator.message(
                      "SSN",
                      DemographicVo.ssnFrmt,
                      "ValidSSN"
                    )}
                  </div>
                </div>

                <div style={{ width: "192px" }}>
                  <InputField
                    name="MedicareID"
                    label="MedicareID"
                    value={DemographicVo.hicNbr}
                    disabled={!this.state.editable}
                    maxLength={12}
                  />
                  <div className={classes.validationMessage} />
                </div>
              </div>
              <div className={classes.containerdemo}>
                <div style={{ width: "274px" }}>
                  <AutoComplete1

                    handleChange={this.handleChangeSearchSelectAuto}
                    label='Gender'
                    options={dropdowns.validGenderCodes}
                    defaultValue={dropdowns.validGenderCodes[0]}
                    value={dropdowns.validGenderCodes.filter(data => data.value === DemographicVo.genderCd)[0]}
                    name='genderCd'
                    disabled={this.state.editable}
                    width="250px"
                  />
                 
                </div>

                <div>
                  <InputField
                    name="birthDateFrmt"
                    placeholder="MM/DD/YYYY"
                    label="Date of Birth"
                    id="birthDateFrmt"
                    onClick={this.handleDates}
                    value={DemographicVo.birthDateFrmt}
                    onChange={this.handleDate}
                    onBlur={this.handleOnBlur}
                    disabled={this.state.editable}
                    maxLength={10}
                    width="215px"
                  />
                  <div className={classes.validationMessage}>
                    {this.validator.message(
                      "Date of Birth",
                      DemographicVo.birthDateFrmt,
                      "date_format"
                    )}
                  </div>
                </div>

                <div style={{ width: "192px" }}>
                  <InputField
                    name="deathDateFrmt"
                    placeholder="MM/DD/YYYY"
                    label="Date of Death"
                    onClick={this.handleDates}
                    value={DemographicVo.deathDateFrmt}
                    onChange={this.handleDate}
                    onBlur={this.handleOnBlur}
                    disabled={this.state.editable}
                    maxLength={10}
                  />
                  <div className={classes.validationMessage}>
                    {this.validator.message(
                      "Date of Death",
                      DemographicVo.deathDateFrmt,
                      "date_format"
                    )}
                  </div>
                </div>
                <div>
                  <AutoComplete1

                    handleChange={this.handleChangeSearchSelectAuto}
                    label='Alternate Correspondence Method'
                    options={dropdowns.validAlternateCorrespondenceMethods}
                    defaultValue={dropdowns.validAlternateCorrespondenceMethods[0]}
                    value={dropdowns.validAlternateCorrespondenceMethods.filter(data => data.value === DemographicVo.altCorrespondenceInd)[0]}
                    name='altCorrespondenceInd'
                    disabled={this.state.editable}
                    width="340px"
                  />
                 
                  <div className={classes.validationMessage} />
                </div>
              </div>
              <div className={classes.containerdemo}>
                <div style={{ width: "274px" }}>
                  <AutoComplete1

                    handleChange={this.handleChangeSearchSelectAuto}
                    label='Marital Status'
                    options={dropdowns.validMaritalStatuses}
                    defaultValue={dropdowns.validMaritalStatuses[0]}
                    value={dropdowns.validMaritalStatuses.filter(data => data.value === DemographicVo.maritalStatus)[0]}
                    name='maritalStatus'
                    disabled={this.state.editable}
                    width="250px"
                  />
                
                  <div className={classes.validationMessage} />
                </div>

                <div style={{ width: "239px" }}>
                
                  <AutoComplete1
                    handleChange={this.handleChangeSearchSelectAuto}
                    label='Race Code'
                    options={dropdowns.validRaceCodes}
                    defaultValue={dropdowns.validRaceCodes[0]}
                    value={dropdowns.validRaceCodes.filter(data => data.value === DemographicVo.raceCd)[0]}
                    name='raceCd'
                    disabled={this.state.editable}
                    width="213px"
                  />
                  <div className={classes.validationMessage} />
                </div>

                <div style={{ width: "227px" }}>
                  <AutoComplete1

                    handleChange={this.handleChangeSearchSelectAuto}
                    label='Language Code'
                    options={dropdowns.validLanguages}
                    defaultValue={dropdowns.validLanguages[0]}
                    value={dropdowns.validLanguages.filter(data => data.value === DemographicVo.languageCd)[0]}
                    name='languageCd'
                    disabled={this.state.editable}
                  />
                  <div className={classes.validationMessage} />
                </div>

                <div>
                  <AutoComplete1

                    handleChange={this.handleChangeSearchSelectAuto}
                    label='Spouse Work'
                    options={dropdowns.arrYesNo}
                    defaultValue={dropdowns.arrYesNo[0]}
                    value={dropdowns.arrYesNo.filter(data => data.value === DemographicVo.spouseWorkInd)[0]}
                    name='spouseWorkInd'
                    disabled={this.state.editable}
                    width="340px"
                  />
                  <div className={classes.validationMessage} />
                </div>
              </div>{" "}
              <div className={classes.containerdemo}>
                <div>
                  <InputField
                    label="Member Email"
                    name="mbrEmail"
                    width="486px"
                    value={DemographicVo.mbrEmail}
                    onChange={this.handlechange("mbrEmail")}
                    onBlur={this.handleOnBlur}
                    disabled={this.state.editable}
                    maxLength={50}
                  />

                  <div className={classes.validationMessage}>
                    {this.validator.message(
                      "Member Email",
                      DemographicVo.mbrEmail,
                      "email"
                    )}
                  </div>
                </div>
              </div>
              <div className={classes.containerdemo}>
                <div>
                  <InputField
                    name="mailFirstName"
                    label="Mailing First Name"
                    value={DemographicVo.mailFirstName}
                    onChange={this.handlechange("mailFirstName")}
                    onBlur={this.handleOnBlur}
                    disabled={this.state.editable}
                    maxLength={24}
                    width="250px"
                  />

                  <div className={classes.validationMessage} />
                </div>
                <div style={{ width: "239px" }}>
                  <InputField
                    name="mailMiddleInit"
                    label="Mailing Middle Name"
                    value={DemographicVo.mailMiddleInit}
                    onChange={this.handlechange("mailMiddleInit")}
                    onBlur={this.handleOnBlur}
                    disabled={this.state.editable}
                    maxLength={1}
                    width="215px"
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="mailLastName"
                    label="Mailing Last Name"
                    value={DemographicVo.mailLastName}
                    onChange={this.handlechange("mailLastName")}
                    onBlur={this.handleOnBlur}
                    disabled={this.state.editable}
                    maxLength={35}
                    width="532px"
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="mailSuffix"
                    label="Mailing Suffix"
                    value={DemographicVo.mailSuffix}
                    onChange={this.handlechange("mailSuffix")}
                    onBlur={this.handleOnBlur}
                    disabled={this.state.editable}
                    maxLength={4}
                    width="342px"
                  />
                  <div className={classes.validationMessage} />
                </div>
              </div>
              <div className={classes.containerdemo}>
                <div>
                  <InputField
                    name="insCardName"
                    label="Insurance Card Name"
                    value={DemographicVo.insCardName}
                    onChange={this.handlechange("insCardName")}
                    onBlur={this.handleOnBlur}
                    disabled={this.state.editable}
                    maxLength={50}
                    width="250px"
                  />
                  <div className={classes.validationMessage} />
                </div>
              </div>
              <div className={classes.containerdemo}>
                <div>
                  <InputField
                    name="authFirstName"
                    label="Auth Representative FirstName"
                    value={DemographicVo.authFirstName}
                    onChange={this.handlechange("authFirstName")}
                    onBlur={this.handleOnBlur}
                    disabled={this.state.editable}
                    maxLength={24}
                    width="250px"
                  />

                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="authMiddleInit"
                    label="Middle Name"
                    value={DemographicVo.authMiddleInit}
                    onChange={this.handlechange("authMiddleInit")}
                    onBlur={this.handleOnBlur}
                    disabled={this.state.editable}
                    maxLength={1}
                    width="215px"
                  />
                  <div className={classes.validationMessage} />
                </div>
                <div>
                  <InputField
                    name="authLastName"
                    label="Last Name"
                    value={DemographicVo.authLastName}
                    onChange={this.handlechange("authLastName")}
                    onBlur={this.handleOnBlur}
                    disabled={this.state.editable}
                    maxLength={35}
                    width="532px"
                  />

                  <div className={classes.validationMessage} />
                </div>
              </div>
              <div className={classes.Select2}>
                <AutoComplete1
                  handleChange={this.handleChangeSearchSelectAuto}
                  label='Relationship to Member'
                  margin="0px"
                  options={dropdowns.validRelations}
                  defaultValue={dropdowns.validRelations[0]}
                  value={dropdowns.validRelations.filter(data => data.value === DemographicVo.authRelationshipCd)[0]}
                  name='authRelationshipCd'
                  disabled={this.state.editable}
                  width="340px"
                />
                
                <div className={classes.validationMessage} />
              </div>
            </div>
          ) : null}

          <div class="panel-subhead panel-subheadEmg ">
            <h3> Emergency Information </h3>
          </div>
          <div className="panel-body">
            <div className={classes.containerdemo}>
              <div>
                <InputField
                  name="emergcyName"
                  label="Name"
                  value={DemographicVo.emergcyName}
                  onChange={this.handlechange("emergcyName")}
                  onBlur={this.handleOnBlur}
                  disabled={this.state.editable}
                  maxLength={50}
                  width="210px"
                />
              </div>
              <div>
                <AutoComplete1
                  handleChange={this.handleChangeSearchSelectAuto}
                  label='Relationship to Member'
                  options={dropdowns.validRelations}
                  defaultValue={dropdowns.validRelations[0]}
                  value={dropdowns.validRelations.filter(data => data.value === DemographicVo.emergcyRelationshipCd)[0]}
                  name='emergcyRelationshipCd'
                  disabled={this.state.editable}
                  width="340px"
                />
              </div>
            </div>
            <div className={classes.containerdemo}>
              <div>
                <InputField
                  name="emergcyEmail"
                  label="Email"
                  value={DemographicVo.emergcyEmail}
                  onChange={this.handlechange("emergcyEmail")}
                  onBlur={this.handleOnBlur}
                  disabled={this.state.editable}
                  maxLength={50}
                  width="487px"
                />
                <div className={classes.validationMessage}>
                  {this.validator.message(
                    "Email",
                    DemographicVo.emergcyEmail,
                    "email"
                  )}
                </div>
              </div>
              <div>
                <InputField
                  name="emergcyPhone"
                  label="Phone"
                  value={DemographicVo.emergcyPhone}
                  onChange={this.handleNumberChange("emergcyPhone")}
                  onBlur={this.handleOnBlur}
                  margin="normal"
                  disabled={this.state.editable}
                  maxLength="25"
                  width="210px"
                />
                <div className={classes.validationMessageSelect}>
                  {this.validator.message(
                    "phone",
                    DemographicVo.emergcyPhone,
                    "phone_no"
                  )}
                </div>
              </div>
            </div>
          </div>
          <HistoryData
            createTime={DemographicVo.createTime}
            createUserId={DemographicVo.createUserId}
            lastUpdtTime={DemographicVo.lastUpdtTime}
            lastUpdtUserId={DemographicVo.lastUpdtUserId}
            isNewSegment={this.state.isNewSegment}
            reset={this.createNewSegment}
            addSegment={this.addNewSegment}
            back={this.goBack}
            footer="true"
          />
        </Paper>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    searchResultsVo: state.memberSearch.searchResultsVo,
    dropdowns: state.membercache,
    servicesEnabled: state.loginData.servicesEnabled,
    loginProfile: state.loginData.profiles,
  };
};

const mapDispatchToProps = {
  setValueMember,
  updateDemographic,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(Styles)(Demographic));
