export const GET = "/getMbrAddress/HCFLCS4/C0000000006/N";
export const SHOWALL = "/getMbrAddress/HCFLCS4/C0000000006/Y";
export const UPDATE = "/updtMbrAddress";
export const DELETE = "/deleteMbrAddress";
export const GET_CITY_NAME = "/getCityName";
export const GET_COUNTY_NAME = "/getCountyName";

export const LOGIN = "/auth/login";
export const LOGOUT = "/auth/logout";
export const GET_USER_INFO = "/auth/get/login/info";

//application

export const APPL_SEARCH = "/appl/search";
export const APPL_SEARCH_NEXT_PAGE = "/appl/search/next";

export const ROW_SEARCH = "/appl/searchSelect";
export const CACHE_URL = "/appl/initial";
export const APPL_CANCEL = "/appl/applCancel";
export const APPL_UDPATE_COMMENTS = "appl/updtApplComments";
export const GET_INSTITUTION_DETAILS = "appl/getInstDetails"; //getInstitution
export const ORIGINAL_APPLICATION = "/appl/origApplication";
export const APPL_VALIDATE = "appl/validate";
export const SUBMIT_FORM = "/appl/applMemberCheck";
export const APPL_UPDATE = "appl/update";
//application Popup URL
export const ELIG_SEARCH_URL = "/appl/eligSearch";
export const PCP_POPUP = "/appl/pcpSearch";
export const AGENT_POPUP = "/appl/agencySearch";
export const CITY_ZIP_POPUP = "/appl/cityZipSearch";
export const GROUP_PRODUCT_POPUP = "/appl/prodSearch";
export const FETCH_CITY_COUNTY = "appl/populateCityCounty";
//export const FETCH_COUNTY = "/appl/getCounty";
export const FETCH_CITIES = "/appl/getCities";
// member
export const GET_MBR_LETTERS = "/mbr/get/letters";
export const LETTER_VARDATA = "/mbr/post/letterVarData";
export const DISPLAY_DOC = "/mbr/post/letterpdf";
export const GET_PRESETNOTES = "/appl/addpresetNotes";
//comments
export const GET_COMMENTS = "/member/getMbrComments";
export const POST_COMMENT = "/member/addMbrComments";

//LEP
export const GET_LEP_DETAILS = "/appl/lep";
export const ADD_UNCOV = "/appl/add/uncov";
export const DELETE_UNCOV = "/appl/delete/uncov";
export const SHOW_ALL_UNCOV = "/appl/unCovMonths/showAll";
export const ADD_ATTESTATION = "/appl/add/attest";
export const DELETE_ATTESTATION = "/appl/delete/attest";
export const COPY_ATTESTATION = "/appl/copy/attest";
export const SHOW_ALL_ATTESTATION = "/appl/ccfDetails/showAll";
export const UPDATE_ATTESTATION_CALLS = "/appl/update/attest/call";
export const UPDATE_ATTESTATION_LETTER = "/appl/update/attest";

//MEMBER
export const GET_MEMBER_DETAILS = "/member/search";
export const GET_MEMBER_SEARCH_PAGINATION = "/member/search/next";

export const GET_MEMBER_CACHE = "/member/initial";
export const GET_MEMBER_ROWCLICK = "/member/searchSelect";
export const GET_MEMBER_PCP = "/member/pcp/get";
export const MEMBER_PCP_DELETE = "/member/pcp/delete";
export const PCP_UPDATE = "/member/pcp/update";
export const MEMBERPCP_POPUP_SEARCH = "/member/pcp/pcpSearch";
export const MEMBER_LIS_FETCH = "/member/lis/get";
export const MEMBER_LIS_UPDATE = "/member/lis/update";
export const MEMBER_LIS_DELETE = "/member/lis/delete";
export const ADD_UPDATE_LTC = "/mbr/ltc/update";
export const DELETE_LTC = "/mbr/ltc/delete";
export const GET_LTC = "/mbr/ltc/get";
export const DEMOGRAPHIC_UPDATE = "/member/demographic/update";
export const GET_ADDRESS = "/member/address/get";
export const NEW_UPDATE_ADDRESS = "/member/address/update";
export const DELETE_ADDRESS = "/member/address/delete";
export const LTC_FACILITY_SEARCH = "/mbr/ltc/search";

export const ADD_UPDATE_DSINFO = "/mbr/dsinfo/update";
export const DELETE_DSINFO = "/mbr/dsinfo/delete";
export const GET_DSINFO = "/mbr/dsinfo/get";
export const GET_TRR = "/member/trr/get";
export const GET_TRR_DATA = "/member/trrData/get";
export const GET_SOA_PDF = "/mbr/soa/letter";
export const GET_ENROLLMENT = "/member/enroll/get";
export const GET_POS = "/member/pos/get";
export const GET_ASES = "/member/ases/get";
export const INSERT_UPDATE_ASES = "member/ases/update";
export const DELETE_ASES = "member/ases/delete";
export const UPDATE_INSERT_POS = "/member/pos/update";
export const GET_MEMBER_COMMENTS = "/member/comments/get";
export const POST_MEMBER_COMMENT = "/member/addMbrComments";
export const DELETE_POS = "/member/pos/delete";
export const PRINT_IDCARD = "/member/printIDCardEnrollment";

export const MEMBER_ENROLL_FETCH = "/member/enroll/get";
export const MEMBER_ENROLL_SEARCH = "/member/grpProdSearch";
export const MEMBER_ENROLL_PLAN = "/member/plantype/get";
export const MEMBER_ENROLL_UPDATE = "/member/enroll/update";
export const GET_AGENT = "/member/agent/get";
export const DELETE_AGENT = "/member/agent/delete";
export const INSERT_UPDATE_AGENT = "/member/agent/update";
export const MEMBER_COB_FETCH = "/member/cob/get";
export const MEMBER_COB_UPDATE = "/member/cob/update";
export const MEMBER_COB_DELETE = "/member/cob/delete";
export const GET_ACCRETION = "/member/accretion/get";

//Member LEP
export const FETCH_MBR_LEP_DATA = "/mbr/lep/get/";
export const UPDATE_MAXIMUS = "/mbr/lep/maximus/update";
export const DELETE_LEP_DATA = "/mbr/lep/delete";
export const UPDATE_LEP_DATA = "/mbr/lep/update";
export const SHOW_ALL_LEP_DATA = "/mbr/lep/get/";
export const COPY_MBR_ATTESTATION = "/mbr/lep/copy/attest";
export const SHOW_ALL_MBR_CCF = "/mbr/lep/ccf/get/";
export const DELETE_MBR_ATTESTATION_DATA = "/mbr/lep/delete/ccf";
export const ADD_MBR_ATTESTATION_DATA = "/mbr/lep/add/ccf";
export const ADD_MBR_UNCOV_DATA = "/mbr/lep/add/uncov";
export const DELETE_MBR_UNCOV_DATA = "/mbr/lep/delete/uncov";
export const SHOW_ALL_MBR_UNCOV_DATA = "/mbr/lep/uncov/get/";
export const UPDATE_MBR_ATTEST_CALL = "/mbr/update/attest/call";
export const UPDATE_MBR_ATTEST_LETTER = "/mbr/lep/update/attest";

export const MEMBER_BILLING_FETCH = "/member/billing/get";
export const MEMBER_BILLING_UPDATE = "/member/billing/update";
export const MEMBER_BILLING_DELETE = "/member/billing/delete ";

export const MEMBER_OOA_FETCH = "/mbr/ooa/get";
export const MEMBER_OOA_UPDATE = "/mbr/ooa/update";

export const GET_LETTER_REQUEST = "/letter/req/search";
export const POST_LOOKUP = "/letter/req/lookUp";
export const CLOSE_LETTER ="/letter/req/close";
export const SEARCH_NEXT = "letter/req/search/next";
export const SEARCH_NEXT_TIMERS = "/timers/search/next";
export const SELECT_LETTER = "/letter/req/select";
export const CREATE_LETTER = "/letter/req/create";

export const INITIAL_LETTER = "/letter/initial";
export const SEARCH_NEXT_REVIEW = "/letter/review/search/next";
export const LETTER_REVIEW_SEARCH = "/letter/review/search";
export const LETTER_REVIEW_DATA = "/letter/review/letterData";
export const LETTER_REVIEW_DATA_UPDATE = "/letter/review/corrmbr/update";
export const LETTER_QC_SEARCH_BATCHID = "/letter/review/qc/search/batchid";
export const LETTER_QC_DESCRIPTION = "/letter/review/qc/search/description/";
export const LETTER_QC_SEARCH = "/letter/review/qc/search";

export const GET_TIMER = "/timers/search";
export const TIMER_CALL = "/timers/update";
export const LETTER_UPLOAD = "/letter/review/upload";
export const GET_TIMER_TYPE = "/timers/type";

//Workflow
export const WORKFLOW_SEARCH = "/workflow/search";
export const WORKFLOW_GET_ACTIVITIES = "workflow/userActivities/get/";
export const WORKFLOW_ASSIGN_WORK = "/workflow/assignWork/";
export const GET_WORKFLOW_CACHE_DATA = "/workflow/wfCacheData/get";
export const CASE_STATUS_UPDATE = "/workflow/caseState/update";
export const REFRESH_DASHLETS = "/workflow/refresh/dashlets";
export const CASE_COMMENTS = "/workflow/getWFComments";
export const ADD_CASE_COMMENTS = "/workflow/addWFComments";
export const CHECK_SUPERVISOR = "/workflow/isSupervisor";
export const CASE_QUEUE = "/workflow/getWFCaseQueue";
export const UPDATE_CASE_QUEUE = "/workflow/updateWFCaseQueue";
export const AT_RISK_DETAILS = "workflow/getWFAtRiskDetails";
export const AT_RISK_SUMMARY = "/workflow/getWFAtRiskSummary";
export const TRANSFER_CASE = "/workflow/transferCase";
//StatusLog

export const STATUS_LOG = "/appl/statusTrack/";

export const ASSIGNMENT_LIMIT = "/workflow/updateMaxUserWork/";
//AtRisk
export const RISK_DATA = "/workflow/getWFAtRiskSummary";
export const RISK_DETAILS = "/workflow/getWFAtRiskDetails";
//SUPERVISOR
export const GET_SUPERVISOR_DETAILS = "/workflow/getSupervisorDetails";
export const GET_SUPERVISOR_TAB_DETAILS = "/workflow/supervisorTabDetails";
export const SUPERVISOR_STATUS_UPDATE = "/workflow/wfUserStatus/update";

//Serurity
export const GET_USER_ROLE_DATA = "/security/get/cache";
export const UPDATE_ROLE_DATA = "/security/update/role";
export const GET_SERVICE_DATA = "/security/get/services/";
export const ADD_SERVICE = "/security/add/services";
export const DELETE_SERVICE = "/security/remove/services";
export const PRIORITY_STATUS_UPDATE = "/workflow/updatePriority";
export const USER_LIST = "/workflow/fetchAssignedNormalWfUsers/";
export const DASHLET_SUPERVISOR = "/workflow/fetchDashlets/";
export const MANUAL_POPUP_DELETE = "/workflow/deleteManualPopupQueues";
//ADD SHOW USER
export const FETCH_WFUSER_DETAILS = "";
export const WFSHOW_USER_UPDATE = "";
export const ADD_WFUSER_UPDATE = "/workflow/user/add?role="; //role=1&userId=TEST&supervisorId=TEST
export const WFSHOW_USER_DROPDOWNS = "/workflow/addOrShowUser/initial";
export const WORKFLOW_USER_SEARCH = "/workflow/user/search";
export const WORKFLOW_USER_UPDATE = "/workflow/user/update";

//Billing-Invoice
export const BILLING_CACHE_DATA = "billing/getBillingCacheData";
export const BILLING_INVOICE_SEARCH = "billing/invoiceSearch";
export const BILLING_INVOICE_PAGINATION = "billing/invoiceSearch/next";
export const BILLING_INVOICE_SAVE_COMMENT = "billing/saveComment";
export const BILLING_INVOICE_MBR_GRP_SEARCH = "billing/billMbrGrpSearch";
export const BILLING_INVOICE_SEARCH_SELECT = "billing/invoiceSearchSelect";
export const BILLING_INVOICE_TRANSFER = "billing/invoiceTransfer";
export const BILLING_INVOICE_ADJUSTMENT = "billing/billInvDetailsUpdate";
export const BILLING_INVOICE_DETAIL_AMOUNT =
  "/billing/getTotalInvoiceDetailAmt";
//Billing-PaymentEntry
export const BILLING_PAYMENT_SEARCH = "/billing/paymentEntry/search";
export const BILLING_PAYMENT_CACHE = "/billing/paymentEntry/cacheData";
export const BILLING_PAYMENT_DETAILS = "/billing/paymentEntry/details";
export const BILLING_PAYMENT_NEWPAYMENT = "/billing/paymentEntry/add";
export const BILLING_PAYMENT_ADDPAYMENT_DETAIL =
  "/billing/paymentEntry/addDetails";
export const BILLING_PAYMENT_HEADER_UPDATE =
  "/billing/paymentEntry/headerUpdate";
export const BILLING_PAYMENT_DETAILS_UPDATE =
  "/billing/paymentEntry/detailsUpdate";
export const BILLING_PAYMENT_ENTRY_PAGINATION =
  "/billing/paymentEntry/search/next";
//Billing-MemberPayments
export const BILLING_MBRPAYMENTS_CACHE = "/billing/mbrPayment/cacheData";
export const BILLING_MBRPAYMENTS_SEARCH =
  "/billing/member/getBillingPaymentSearch";
export const BILLING_MBRPAYMENTS_INVOICE =
  "/billing/member/getBillingPaymentDetailInvoice";
export const BILLING_MBRPAYMENTS_UPDATE =
  "/billing/member/updateBillingMbrPayment";
export const BILLING_MBRPAYMENTS_PAGINATION =
  "billing/member/getBillingPaymentSearch/next";
//Billing-Draft
export const BILLING_DRAFT_SEARCH = "/billing/getBillingDraftHeaderSearch";
export const BIILLING_DRAFT_DETAIL_SEARCH =
  "/billing/getBillingDraftDetailSearch";
export const BILLING_DRAFT_PAGINATION =
  "/billing/getBillingDraftHeaderSearch/next";
//Notifications
export const NOTIFICATION_API = "/notifications/stream";
export const WF_SEARCH_NEXT_PAGE = "/workflow/search/next";
//Dashboard
export const PRE_ENROLLMENT_STATUS = "/dashboard/preEnrollStatus";
export const APPLICATION_AGING = "dashboard/applAgeing";
export const MEMBERSHIP_DISTRIBUTION = "dashboard/mbrShipDistribution";
export const RFI_TRACKING = "dashboard/rfiTracking";
export const CMS_STATUS = "dashboard/cmsStatus";
export const CMS_TRANSACTION_STATUS = "dashboard/cmsTransaction";
export const APPLICATION_DISTRIBUTION = "dashboard/appDistribution";
export const Special_Status = "dashboard/spclStatDistribution";
export const LETTER_DISTRIBUTION = "dashboard/letVolDistribution";
export const FILE_LOAD_DISTRIBUTION = "dashboard/fileLoadErrDistribution";
export const GET_PLANIDs = "dashboard/customerPlanIds";
export const LIS_DISTRIBUTION = "dashboard/lisMbrDistribution";

//360 lOGIN
export const LOGIN_E360 = "/E360";
