import Collapse from "@material-ui/core/Collapse";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import { withStyles } from "@material-ui/core/styles";
import Tooltip from "@material-ui/core/Tooltip";
import ExpandLess from "@material-ui/icons/ExpandLess";
import ExpandMore from "@material-ui/icons/ExpandMore";
import classNames from "classnames";
import React, { Fragment, PureComponent } from "react";
import { connect } from "react-redux";
import { Link, withRouter } from "react-router-dom";
import { compose } from "recompose";
import styles from "../assets/styles/LayoutStyle";
import { fetchWfCacheData } from "../redux/actions/WorkflowActions";
import { SidebarItem } from "./SidebarItem";

class SideDrawerTabs extends PureComponent {
  state = {
    memberOpen: false,
    letterOpen: false,
    anchorEl: null,
    workflowOpen: false,
    supervisorOpen: false,
    timerOpen: false,
    securityOpen: false,
    billingOpen: false,
    flag: false,
  };

  handleClick = (event) => {
    this.setState({ anchorEl: event.currentTarget });
    this.setState((state) => ({
      memberOpen: !state.memberOpen,
      letterOpen: false,
      supervisorOpen: false,
      workflowOpen: false,
      flag: false,
    }));
  };

  handleAppClick = async (event) => {
    this.setState({ anchorEl: event.currentTarget });
    await this.setState({
      memberOpen: false,
      letterOpen: false,
      supervisorOpen: false,
      workflowOpen: false,
      flag: false,
    });
  };

  handleLetterClick = (event) => {
    this.setState({ anchorEl: event.currentTarget });
    this.setState((state) => ({
      memberOpen: false,
      workflowOpen: false,
      supervisorOpen: false,
      letterOpen: !state.letterOpen,
      flag: false,
    }));
  };

  handleWorkflowClick = async (event) => {
    this.setState({ anchorEl: event.currentTarget });
    this.setState({
      workflowOpen: !this.state.workflowOpen,
      memberOpen: false,
      letterOpen: false,
      flag: true,
    });
  };

  handleSecurityClick = (event) => {
    this.setState({ anchorEl: event.currentTarget });
    this.setState({
      workflowOpen: false,
      memberOpen: false,
      letterOpen: false,
      securityOpen: !this.state.securityOpen,
      flag: false,
    });
  };

  handleTimerClick = (event) => {
    this.setState({ anchorEl: event.currentTarget });
    this.setState({
      workflowOpen: false,
      memberOpen: false,
      letterOpen: false,
      timerOpen: !this.state.timerOpen,
      flag: false,
    });
  };

  handleBillingClick = (event) => {
    this.setState({ anchorEl: event.currentTarget });
    this.setState({
      billingOpen: !this.state.billingOpen,
      workflowOpen: false,
      memberOpen: false,
      letterOpen: false,
      timerOpen: false,
      flag: false,
    });
  };

  handleSupervisorClick = (event) => {
    this.setState({ anchorEl: event.currentTarget });
    this.setState({
      supervisorOpen: !this.state.supervisorOpen,
      memberOpen: false,
      letterOpen: false,
    });
  };

  handleClose = () => {
    this.setState({
      anchorEl: null,
      letterOpen: false,
      memberOpen: false,
      workflowOpen: false,
      supervisorOpen: false,
      flag: false,
    });
  };

  render() {
    const {
      classes,
      location: { pathname },
      showhideFlag,
      servicesEnabled,
    } = this.props;

    let expandIcon = null;
    if (this.props.wfCacheData && this.props.wfCacheData.supervisor !== "N") {
      expandIcon = this.state.workflowOpen ? <ExpandLess /> : <ExpandMore />;
    }
    return (
      <Fragment>
        <List>
          <SidebarItem
            classes={classes}
            pathvalue="/dashboard"
            pathname={pathname}
            title="Dashboard"
            showhideFlag={showhideFlag}
            iconStyle="material-icons"
            iconText="dashboard"
          />

          {servicesEnabled.includes("EEMA") ? (
            <SidebarItem
              classes={classes}
              pathvalue="/application"
              pathname={pathname}
              title="Application"
              showhideFlag={showhideFlag}
              iconStyle="fa fa-user"
              handleClick={this.handleAppClick}
            />
          ) : null}

          {servicesEnabled.includes("EEMM") ? (
            <SidebarItem
              classes={classes}
              pathvalue="/member"
              pathname={pathname}
              title="Member"
              showhideFlag={showhideFlag}
              iconStyle="fa fa-users"
              handleClick={this.handleClick}
            />
          ) : null}

          {servicesEnabled.includes("EEML") ? (
            <SidebarItem
              classes={classes}
              pathvalue="/letterRequest"
              pathname={pathname}
              title="Letter Request"
              showhideFlag={showhideFlag}
              iconStyle="fa fa-envelope"
              handleClick={this.handleLetterClick}
            />
          ) : null}

          {servicesEnabled.includes("EEML") ? (
            <SidebarItem
              classes={classes}
              pathvalue="/letterreview"
              pathname={pathname}
              title="Letter Review"
              showhideFlag={showhideFlag}
              iconStyle="fas fa-envelope-open-text"
              handleClick={this.handleLetterClick}
            />
          ) : null}

          {servicesEnabled.includes("EEMB") ? (
            <SidebarItem
              classes={classes}
              pathvalue="/billing"
              pathname={pathname}
              title="Billing"
              showhideFlag={showhideFlag}
              iconStyle="fa fa-calculator"
              handleClick={this.handleBillingClick}
            />
          ) : null}

          {servicesEnabled.includes("EEMT") ? (
            <SidebarItem
              classes={classes}
              pathvalue="/timers"
              pathname={pathname}
              title="Timers"
              showhideFlag={showhideFlag}
              iconStyle="fas fa-clock-o"
              handleClick={this.handleTimerClick}
            />
          ) : null}

          {/* {servicesEnabled.includes("EESS") ? (
            <SidebarItem
              classes={classes}
              pathvalue="/securityRoles"
              pathname={pathname}
              title="Security Roles"
              showhideFlag={showhideFlag}
              iconStyle="fas fa-user-tag"
              handleClick={this.handleSecurityClick}
            />
          ) : null} */}

          {servicesEnabled.includes("EEWF") ? (
            <ListItem
              button
              onClick={this.handleWorkflowClick}
              component={Link}
              to={{
                pathname: "/workflow",
                name: "User Workflow",
              }}
              selected={"/workflow" === pathname}
              classes={{
                selected: classes.selected,
                button: classes.items,
              }}
            >
              <Tooltip title="Workflow" placement="right">
                <ListItemIcon>
                  <i className={classNames("fas fa-sitemap", classes.icons)}></i>
                </ListItemIcon>
              </Tooltip>
              <ListItemText
                primary="Workflow"
                className={{
                  [classes.display]: showhideFlag,
                  [classes.hide]: !showhideFlag,
                }}
              />
              {expandIcon}
            </ListItem>
          ) : null}

          {expandIcon ? (
            <Collapse in={this.state.flag} timeout="auto" unmountOnExit>
              <List
                component="div"
                style={{ paddingLeft: "10px", fontSize: "14px" }}
              >
                {this.props.wfCacheData &&
                  (this.props.wfCacheData.supervisor === "S" ||
                    this.props.wfCacheData.supervisor === "A") ? (
                    <React.Fragment>
                      <SidebarItem
                        classes={classes}
                        pathvalue={"/supervisorworkflow"}
                        pathname={pathname}
                        title={"Supervisor/Admin"}
                        showhideFlag={showhideFlag}
                        iconStyle="fas fa-tasks"
                      />

                      {this.props.wfCacheData.supervisor === "A" ? (
                        <SidebarItem
                          classes={classes}
                          pathvalue={"/add/show/users"}
                          pathname={pathname}
                          title={"Add/Show Users"}
                          showhideFlag={showhideFlag}
                          iconStyle="fas fa-user-plus"
                        />
                      ) : null}

                      <SidebarItem
                        classes={classes}
                        pathvalue={"/atrisks"}
                        pathname={pathname}
                        title={"At Risks"}
                        showhideFlag={showhideFlag}
                        iconStyle="fas fa-exclamation-triangle"
                      />
                      <SidebarItem
                        classes={classes}
                        pathvalue={"/casecharacteristics"}
                        pathname={pathname}
                        title={"Case Characteristics"}
                        showhideFlag={showhideFlag}
                        iconStyle="fas fa-briefcase"
                      />
                    </React.Fragment>
                  ) : null}
              </List>
            </Collapse>
          ) : null}
        </List>
      </Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    wfCacheData: state.workflow.wfCacheData,
    servicesEnabled: state.loginData.servicesEnabled,
  };
};

const mapDispatchToProps = {
  fetchWfCacheData,
};

export default compose(
  withRouter,
  withStyles(styles, { withTheme: true }),
  connect(mapStateToProps, mapDispatchToProps)
)(SideDrawerTabs);
