import { Link } from "react-router-dom";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import React from 'react';
import Tooltip from "@material-ui/core/Tooltip";
import classNames from "classnames";

export const SidebarItem = (props) => {

    const { handleClick, classes, pathvalue, pathname, title, iconText, iconStyle, showhideFlag } = props;
    const selected = pathvalue === pathname;
    return (
        <ListItem
            className="hvr-bounce-to-right"
            button
            onClick={handleClick}
            component={Link}
            to={{
                pathname: pathvalue,
                name: title
            }}
            selected={selected}
            classes={{
                selected: classes.selected,
                button: classes.items
            }}
        >
            <Tooltip title={title} placement="right">
                <ListItemIcon>
                    <i className={classNames(iconStyle, classes.icons)}>
                        {iconText}
                    </i>
                </ListItemIcon>
            </Tooltip>
            <ListItemText

                className={{
                    [classes.display]: showhideFlag, [classes.hide]: !showhideFlag
                }}
                primary={title}
            />
        </ListItem>
    )
            };