export const styles = (theme) => ({
  table: {
    position: "relative",
    margin: "auto",
    width: "100%",
    border: "1px solid rgba(0,0,0,0.1)",
  },
  tableModified: {
    overflow: "auto",
  },
  exportIcon: {
    float: "right",
    color: "green",
    cursor: "pointer",
    fontSize: "24px",
    marginTop: "0.5rem",
  },
  exportIconbtnAppl: {
    float: "right",
    color: "green",
    cursor: "pointer",
    fontSize: "24px",
    marginTop: "0.5rem",
    marginRight: "24px",
  },
  excelIcon: {
    fontSize: "24px",
    float: "right",
    color: "green",
    cursor: "pointer",
    padding: "12px",
  },

  csvIcon: {
    fontSize: "24px",
    float: "right",
    color: "#3a94d0",
    cursor: "pointer",
    padding: "12px",
  },

  pdfIcon: {
    fontSize: "24px",
    float: "right",
    color: "red",
    cursor: "pointer",
    padding: "12px",
  },
  tableWrapper: {
    display: "inline-block",
    [theme.breakpoints.down("sm")]: {
      overflowX: "auto",
      display: "grid",
    },
  },
  exportDisplay: {
    display: "contents",
  },

  thead: {
    height: "30px",
    background: "#053674",
    color: "#fff",
  },

  selectedrow: {
    height: "18px !important",
    backgroundColor: "#cbd4d8",
  },
  export: {
    paddingLeft: "16%",
  },

  placing: {
    [theme.breakpoints.only("lg")]: {
      top: "27% !important",
    },
  },
  headRow: {
    height: "34px",
  },

  footer: {
    height: "32px",
    minHeight: "32px",
    background: "#053674",
    color: "#fff",
  },

  headerRow: {
    color: "white",
    paddingRight: 4,
    paddingLeft: 30,
  },
  tbody: {
    background: "ghostwhite",
  },

  row: {
    height: "18px",
    "&:hover": {
      backgroundColor: "#f2f2f2",
      color: "white",
    },
  },
  headerCell: {
    color: "white",
    paddingRight: 4,
    paddingLeft: 5,
  },

  pagination: {
    color: "white",
    padding: "0px",
  },

  floatRight: {
    float: "right",
    padding: "10px",
  },
  search: {
    [theme.breakpoints.down("sm")]: {
      marginLeft: "2px",
    },
  },
  tableCell: {
    paddingRight: 4,
    paddingLeft: 5,
    height: "19px",
  },
  tableCellHeader: {
    paddingRight: 4,
    paddingLeft: 5,
    background: "#053674",
    color: "white",
    height: "34px",
  },

  tableCellEligCheck: {
    paddingRight: 30,
    paddingLeft: 5,
  },
  headingCell: {
    paddingRight: 4,
    paddingLeft: 5,
    fontWeight: "500",
  },

  svgicon: {
    opacity: 0.0,
  },
  lepHeader: {
    fontSize: "0.9rem",
    textAlign: "center",
  },
  mobileWidth: {
    width: "70% !important",
    padding: "0px !important",
    maxHeight: "75vh !important",
    overflowY: "auto !important",

    [theme.breakpoints.down("xs")]: {
      marginTop: "70px !important",
      width: "150% !important",
      maxHeight: "100vh !important",
      overflowY: "auto !important",
      shrink: "true !important",
    },
  },
  attestation1: {
    color: "rgba(39, 108, 155, 1)",
    paddingTop: "30px",
    paddingLeft: "3px",
  },

  confirmDialogButton: {
    margin: theme.spacing.unit,
    backgroundColor: "#2e88e2",
    color: "white",
    "&:hover": {
      backgroundColor: "#2e88e2",
    },
  },

  confirmDialog: {
    border: "1px none black",
    borderRadius: "8px",
    backgroundColor: "white !important",
    padding: "30px",
    boxShadow: "0 10px 6px -6px #777",
    [theme.breakpoints.down("md")]: {
      padding: "15px",
    },
  },
  paddingSearch: {
    padding: "4px",
  },
  print: {
    float: "right",
  },
  marginExport: {
    marginLeft: "5px",
  },
  appliedAmtTableCell: {
    textAlign: "right",
    paddingRight: 48,
    paddingLeft: 5,
    height: "19px",
    width: "140px",
  },
  lepSummaryTableCell: {
    paddingRight: 4,
    paddingLeft: 5,
    height: "19px",
    textAlign: "center",
  },
  infoIcon: {
    marginLeft:"2px",
    color: "darkblue",
    cursor: "pointer",
    fontSize: "18px",
   
  },
});

export const actionsStyles = (theme) => ({
  root: {
    flexShrink: 0,
    color: theme.palette.text.secondary,
    marginLeft: theme.spacing.unit * 2.5,
  },
  iconButton: {
    padding: "5px",
    color: "white",
  },
});
