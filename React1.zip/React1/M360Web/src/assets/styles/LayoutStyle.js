import sidebarbackground from "../images/navbar-left.png";

const drawerWidth = 240

const sideBarWidth = 64;

const styles = theme => ({
  root: {
    display: "flex"
  },

  icons: {
    fontSize: "22px",
    height: "1em",
    color: "#053674",
    paddingLeft :"0.3em",
    fontStyle: "normal",
    "&:hover": {
      color: "white"
    },
    "&:active": {
      color: "green"
    }
  },
  avatar: {
    width: "30px",
    height: "30px"
  },
  paper: {
    height: "240px",
    overflowX: 'hidden ',
    overflowY: 'auto',
    width: '30em'

  },
  appBar: {
    backgroundColor: "#053674",
    color: "#ffffff",
    zIndex: '800 !important',
    width: `calc(100% - ${sideBarWidth}px)`,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen
    }),
    [theme.breakpoints.up("xs")]: {
      width: `calc(100% - ${sideBarWidth}px)`
    },
    [theme.breakpoints.down("xs")]: {
      width: "100%"
    }
  },

  appBarShift: {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen
    }),

    [theme.breakpoints.down("xs")]: {
      width: "100%"
    }
  },
  hide: {
    display: "none"
  },

  drawer: {
    zIndex: '800 !important',
    width: drawerWidth,
    flexShrink: 0,
    whiteSpace: "nowrap"
  },

  drawerOpenSubMenu: {
    overflowY: "auto",
    backgroundImage: "url(" + sidebarbackground + ") ",
    overflowX: "hidden",
    maxHeight: "calc(100% - 220px)!important"
  },

  drawerOpen: {
    width: drawerWidth,
    overflowY: "auto",
    zIndex: '800 !important',
    backgroundImage: "url(" + sidebarbackground + ") ",

    overflowX: "hidden",
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.smooth,
      duration: "0.4s"
    })
  },
  drawerClose: {
    zIndex: '800 !important',
    backgroundImage: "url(" + sidebarbackground + ")",
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.smooth,
      duration: "0.25s"
    }),
    overflowX: "hidden",
    width: theme.spacing.unit * 7 + 1,
    [theme.breakpoints.up("sm")]: {
      width: theme.spacing.unit * 8 + 1
    }
  },

  gutters: {
    paddingLeft: "5px",
    paddingRight: "5px",
    minHeight: "60px"
  },

  sectionDesktop: {
    [theme.breakpoints.down("md")]: {
      display: "none"
    },
    [theme.breakpoints.up("sm")]: {
      display: "inline-block"
    }
  },

  sectionMobile: {
    display: "block",
    paddingLeft: "5px",
    [theme.breakpoints.up("sm")]: {
      display: "none"
    }
  },

  selected: {
    background:
      "-webkit-linear-gradient( top left, rgb(201, 211, 222) 0%, rgb(155, 183, 189) 37%, rgb(128, 165, 183) 45%, rgba(164, 186, 191, 0.8) 50% )"
  },
  toolbar: {
    display: "flex",
    alignItems: "center",
    justifyContent: "flex-end",
    padding: "10px 8px",
    zIndex: 100,
    ...theme.mixins.toolbar,
    minHeight: "48px !important"

  },
  whiteColor: {
    color: "white"
  },
  content: {
    flexGrow: 1,
   // padding: theme.spacing.unit * 3,
    overflowX: 'hidden',
    [theme.breakpoints.down("sm")]: {
      overflowX: "auto"

    },
    padding: "21px 26px"
  },
  
  mobile: {
    display: "block",
    [theme.breakpoints.down("sm")]: {
      display: "block"
    }
  },
  display: {
    display: "block",
    paddingLeft: "5px"
  },

  drawerMargin: {
    marginTop: "10px"
  },
  nested: {
    marginLeft: "15px",

  },
  rightAlign: {
    marginLeft: "auto"
  },
  wiproLogo: {
    width: "60px",
    padding: "6px 3px",
    backgroundColor: 'white'
  },

  customerLogo: {
    width: "172px",
    padding: '8px',
    backgroundColor: 'white'
  },
  toastContainer: {
    position: "absolute",
    marginTop: "55px",
    zIndex: "100"
  },
  toast: {
    minHeight: "0px",
    marginBottom: "0px",
    border: "1px solid black",
    color: "black"
  },

  itemIcon: {
    fontSize: "20px",
    float: "left",
    textAlign: "center",
    verticalAlign: "middle",
    color: "#ffffff"
  },

  subheading: {
    color: "white"
  }
  , logoContaier: {
    backgroundColor: "white",
    height: "60px"
  }
});

export default styles;
