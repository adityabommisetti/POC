export const Styles = (theme) => ({
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    height: "40px",
    width: "70px",
  },

  root: {
    ...theme.mixins.gutters(),
    paddingTop: theme.spacing.unit * 2,
    paddingBottom: theme.spacing.unit * 2,
    width: "100%",
    alignSelf: "center",
    marginLeft: "auto",
    marginRight: "auto",
  },
  alignCenter: {
    textAlign: "center",
    width: "100%",
  },
  div1: {
    alignSelf: "center",
    marginLeft: "auto",
    marginRight: "auto",
    width: "fit-content",
  },
  div2: {
    width: "95%",
    marginLeft: "auto",
    alignSelf: "center",
    marginRight: "auto",
    display: "flex",
    flexWrap: "wrap",
  },
  table: {
    width: "90%",
    alignSelf: "center",
    marginLeft: "auto",
    marginRight: "auto",
  },
  fieldset: {
    margin: "10px",
    padding: "0 10px 10px",
    border: "1px solid #9e8e8e",
    borderRadius: "8px",
    paddingTop: "10px",
  },
  legend: {
    padding: "2px 4px",
    background: "#fff",
    textAlign: "center",
  },
  submit: {
    width: "100px",
  },
  button: {
    margin: theme.spacing.unit,
    color: "#fff",
    fontSize: "10px",
    padding: "9px 5px",
    backgroundColor: "#389bde",
    borderRadius: "90px",
    boxShadow:
      "0px 1px 2px 0px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0,0,0,0.24), 0px 3px 1px -2px rgba(0,0,0,0.02)",
    [theme.breakpoints.down("sm")]: {
      fontSize: "8px",
      width: "80px",
    },
  },

  buttonsearch: {
    margin: theme.spacing.unit,
    color: "black",
    fontSize: "10px",
    padding: "9px 5px",
    backgroundColor: "white",
    borderRadius: "90px",
    boxShadow:
      "0px 1px 2px 0px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0,0,0,0.24), 0px 3px 1px -2px rgba(0,0,0,0.02)",
    [theme.breakpoints.down("sm")]: {
      fontSize: "8px",
      width: "80px",
    },
  },

  popUpIcons: {
    fontSize: "24px",
    paddingLeft: "20px",
    paddingRight: "20px",
    paddingTop: "25px",
    cursor: "pointer",
  },
  container: {
    display: "flex",
    flexWrap: "wrap",
  },
  transferPopUpDiv: {
    width: "180px",
  },
});
