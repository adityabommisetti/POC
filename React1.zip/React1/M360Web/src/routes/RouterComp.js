import React, { Suspense, lazy } from "react";
import { Redirect, Route, Switch } from "react-router-dom";

import CircularIndeterminate from "../utils/CircularProgress";
import Dashboard from "../components/Dashboard/Dashboard";
import SupervisorWorkflow from "../components/WorkFlow/WF_Supervisor";

const MemberSearch = lazy(() => import("../components/Member/MbrSearch"));
const Billing = lazy(() => import("../components/Billing/BillingSubTabs"));
const Application = lazy(() => import("../components/Application/Application"));
const SecurityRoles = lazy(() =>
  import("../components/SecurityRoles/Securityroletabs")
);
const WorkflowTabs = lazy(() => import("../components/WorkFlow/WF_User"));
const AddShowUsers = lazy(() =>
  import("../components/WorkFlow/WF_AddShowUsers")
);
const AtRisks = lazy(() => import("../components/WorkFlow/WF_AtRisks"));
const CaseCharacteristics = lazy(() =>
  import("../components/WorkFlow/WF_Casecharacterisitics")
);
const LetterRequest = lazy(() => import("../components/Letters/LetterRequest"));
const Timers = lazy(() => import("../components/Timers/Timers"));
const LetterReview = lazy(() => import("../components/Letters/LetterReview"));

const Routers = () => {
  return (
    <React.Fragment>
      <Switch>
        <Route
          path="/dashboard"
          render={() => (
            <Suspense fallback={" "}>
              <Dashboard />{" "}
            </Suspense>
          )}
        />
        <Route
          path="/member"
          render={() => (
            <Suspense fallback={" "}>
              <MemberSearch />{" "}
            </Suspense>
          )}
        />

        <Route
          path="/billing"
          render={() => (
            <Suspense fallback={" "}>
              <Billing />{" "}
            </Suspense>
          )}
        />
        <Route
          path="/application"
          exact
          render={() => (
            <Suspense fallback={" "}>
              <Application />{" "}
            </Suspense>
          )}
        />

        <Route
          path="/letterRequest"
          render={() => (
            <Suspense fallback={" "}>
              <LetterRequest />{" "}
            </Suspense>
          )}
        />
        <Route
          path="/billing"
          render={() => (
            <Suspense fallback={" "}>
              <Billing />{" "}
            </Suspense>
          )}
        />
        <Route
          path="/SecurityRoles"
          render={() => (
            <Suspense fallback={" "}>
              <SecurityRoles />{" "}
            </Suspense>
          )}
        />
        {/* <Route path='/LetterRequests' render={()=><Suspense fallback={<CircularIndeterminate />}><LetterRequests/> </Suspense>} />  */}
        <Route
          path="/workflow"
          render={() => (
            <Suspense fallback={" "}>
              <WorkflowTabs />{" "}
            </Suspense>
          )}
        />
        <Route
          path="/supervisorworkflow"
          render={() => (
            <Suspense fallback={" "}>
              <SupervisorWorkflow />{" "}
            </Suspense>
          )}
        />

        <Route
          path="/add/show/users"
          render={() => (
            <Suspense fallback={" "}>
              <AddShowUsers />{" "}
            </Suspense>
          )}
        />
        <Route
          path="/atrisks"
          render={() => (
            <Suspense fallback={" "}>
              <AtRisks />{" "}
            </Suspense>
          )}
        />
        <Route
          path="/casecharacteristics"
          render={() => (
            <Suspense fallback={" "}>
              <CaseCharacteristics />{" "}
            </Suspense>
          )}
        />
        <Route
          path="/letterreview"
          render={() => (
            <Suspense fallback={" "}>
              <LetterReview />{" "}
            </Suspense>
          )}
        />
        <Route
          path="/Timers"
          render={() => (
            <Suspense fallback={" "}>
              <Timers />{" "}
            </Suspense>
          )}
        />

        <Redirect from="/" to="/dashboard" />
      </Switch>
    </React.Fragment>
  );
};

export default Routers;
