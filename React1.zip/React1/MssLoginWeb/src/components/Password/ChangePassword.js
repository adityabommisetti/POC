import React, { Component } from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import SimpleReactValidator from "simple-react-validator";
import Modal from "../../components/UI/Modal/Modal";
import { changepassword } from "../../redux/actions/ForgotPasswordAction";
import { customValidations } from "./../../utils/customValidations";
import ConfirmBox from "./../../utils/PopUp";
import { Button } from "../UI/Button";

class ChangePassword extends Component {
  constructor(props) {
    super(props);
    this.state = {
      ChangePasswordVo: {
        newpwd: "",
        confirmPwd: "",
        pwd: "",
        userId: this.props.loginData.loginVo.userId,
      },
      modified: false,
      isSubmitted: false,
    };

    this.validator = new SimpleReactValidator({
      validators: {
        pwdRegrex: customValidations.pwdRegrex,
        matchPWD: customValidations.matchPWD,
        PwdNotMatch:customValidations.PwdNotMatch,
      },
    });
  }

  handlechange = (name) => (event) => {
    let value = event.target.value;

    this.setState((prevState) => ({
      ChangePasswordVo: {
        ...prevState.ChangePasswordVo,
        [name]: value,
      },

      modified: true,
    }));
  };

  handleChangeSearchSelect = (name) => (event) => {
    let value = event.value;
    this.setState((prevState) => ({
      ChangePasswordVo: {
        ...prevState.ChangePasswordVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  submit = (e) => {
    e.preventDefault();
    if (this.validator.allValid()) {
      ConfirmBox(this.changePWd);
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };
  changePWd = async () => {
    this.setState({ isSubmitted: true });
    const { ChangePasswordVo } = this.state;
    const response = await this.props.changepassword(ChangePasswordVo);

    Modal(response.message,this.logout,true);

    this.setState({ isSubmitted: false });
  };

  logout =async(resp) =>{
    if(resp.includes("Successfully")){
      await this.props.logout();
   }
  }

  render() {
    const { ChangePasswordVo } = this.state;

    return (
      <React.Fragment>
        <div>
          <div className="col-md-4 offset-md-3">
            <span className="anchor" id="formChangePassword"></span>

            <div className="card card-outline-secondary">
              <div className="card-header">
                <h4 className="mb-0">Change Password</h4>
              </div>
              <div className="card-body">
                <form className="form" autoComplete="off">
                  <div className="form-group form-group-input">
                    <label htmlFor="userId">User Id</label>
                    <input
                      type="text"
                      className="form-control"
                      value={this.props.loginData.loginVo.userId}
                      id="userId"
                      readOnly
                    />
                  </div>
                  <div className="form-group form-group-input">
                    <label htmlFor="pwd">Current Password</label>
                    <input
                      type="password"
                      className="form-control"
                      value={ChangePasswordVo.pwd}
                      onChange={this.handlechange("pwd")}
                      id="pwd"
                      required
                    />
                    <span className="form-text small  text-danger">
                      {this.validator.message(
                        "Current Password",
                        ChangePasswordVo.pwd,
                        "required"
                      )}
                    </span>
                  </div>
                  <div className="form-group">
                    <label htmlFor="newpwd">New Password</label>
                    <input
                      type="password"
                      className="form-control"
                      value={ChangePasswordVo.newpwd}
                      onChange={this.handlechange("newpwd")}
                      id="newpwd"
                      required
                    />
                    <span className="form-text small  text-danger">
                      {this.validator.message(
                        "New Password",
                        ChangePasswordVo.newpwd,
                        `required|min:8|pwdRegrex|PwdNotMatch:${ChangePasswordVo.pwd}`
                      )}
                    </span>
                  </div>
                  <div className="form-group">
                    <label htmlFor="confirmPwd">Confirm Password</label>
                    <input
                      type="password"
                      className="form-control"
                      value={ChangePasswordVo.confirmPwd}
                      onChange={this.handlechange("confirmPwd")}
                      id="confirmPwd"
                      required
                    />
                    <span className="form-text small  text-danger">
                      {this.validator.message(
                        "Confirm Password",
                        ChangePasswordVo.confirmPwd,
                        `required|matchPWD:${ChangePasswordVo.newpwd}`
                      )}
                    </span>
                  </div>
                  <div className="form-group">
                    <div className="row">
                      <div className="col text-center">
                        <Button
                          type="submit"
                          submit={this.submit}
                          spinner={this.state.isSubmitted}
                          label="Update"
                          disabled={!this.state.modified}
                        />
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>{" "}
        </div>
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    loginData: state.loginData,
  };
};
const mapDispatchToProps = { changepassword };
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(ChangePassword));
