import React, { Component } from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import SimpleReactValidator from "simple-react-validator";
import {
  resetPassword,
  updateExpiredPwd,
} from "../../redux/actions/ForgotPasswordAction";
import { customValidations } from "../../utils/customValidations";
import Modal from "../../components/UI/Modal/Modal";
let  userIDURl,tokenURl
let url= window.location.href;
if(url.includes("/resetpassword/")){
  userIDURl=url.split("resetpassword/")[1].split("/")[0];
  tokenURl=url.split(userIDURl+"/")[1];
  
}

class ResetPassword extends Component {
  constructor(props) {
    super(props);
    this.state = {
      newPwd: "",
      ConfirmPwd: "",
      oldPwd: "",
      closePopup: false,
      error: null,
      userId: "",
      isSubmitted: false,
    };

    this.validator = new SimpleReactValidator({
      validators: {
        pwdRegrex: customValidations.pwdRegrex,
        matchPWD: customValidations.matchPWD,
        PwdNotMatch:customValidations.PwdNotMatch
      },
    });
  }

  componentDidMount() {
    this.setState({ userId: this.props.match.params.userName });
  }

  modalClosed = () => {
    this.setState({ closePopup: false });
  };

  handlechange = (name) => (event) => {
    let value = event.target.value;
    this.setState({
      [name]: value,
    });
  };
  submit = async (e) => {
    e.preventDefault();
    this.setState({ isSubmitted: true });
    if (this.validator.allValid()) {
      let { userId } = this.state;
      if (this.props.loginData) {
        userId = this.props.loginData.loginVo.userId;
      }
      let payload = {
        userId: userId,
        newpwd: this.state.newPwd,
        pwd: this.state.oldPwd,
      };
      let payload2 = {
        userId: userIDURl,
        newpwd: this.state.newPwd,
        token: tokenURl,
      };
     
      let resp ="";
      if (this.props.isExpired) {
        resp = await this.props.updateExpiredPwd(payload);
      } else {
        resp = await this.props.resetPassword(payload2);
        
      }
      await Modal(resp, this.logout, true);
     /* if(resp==="Password Changed Successfully"){
        window.location.replace("/")
      }*/
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }

    this.setState({ isSubmitted: false });
  };

  logout = async (resp) => {
    if (resp.includes("Successfully")) {
      await this.props.logout();
    }
  };
  render() {
    let header = "Reset Password ?";
    if (this.props.header) {
      header = this.props.header;
    }

    return (
      <div className="container setup-content card">
        <form>
          <div className="forgotPwd mb-4">
            <div className="row">
              <div className="col-md-2">
                <img
                  src="/images/wipro-logo.png"
                  alt="Wipro logo"
                  className="wipro-logo-pwd"
                />
              </div>{" "}
              <div className="col-md-8" style={{ marginTop: "2rem" }}>
                <h4>{header}</h4>
              </div>
            </div>
          </div>{" "}
          {this.state.error ? (
            <div className=" alert alert-danger">{this.state.error} </div>
          ) : null}
          <div className="mx-auto col-md-6 mb-5">
            {this.props.isExpired ? (
              <div className="form-group">
                <label htmlFor="newpwd">Old Password</label>
                <input
                  type="password"
                  className="form-control"
                  value={this.state.oldPwd}
                  onChange={this.handlechange("oldPwd")}
                  id="oldPwd"
                  required
                />
                <span className="form-text small  text-danger">
                  {this.validator.message(
                    "Password",
                    this.state.oldPwd,
                    "required|"
                  )}
                </span>
              </div>
            ) : null}
            <div className="form-group">
              <label htmlFor="newpwd">New Password</label>
              <input
                type="password"
                className="form-control"
                value={this.state.newPwd}
                onChange={this.handlechange("newPwd")}
                id="newPwd"
                required
              />
              <span className="form-text small  text-danger">
                {this.validator.message(
                  "Password",
                  this.state.newPwd,
                   `required|min:8|pwdRegrex|PwdNotMatch:${this.state.oldPwd}`
                )}
              </span>
            </div>
            <div className="form-group">
              <label htmlFor="confirmPwd">Confirm Password</label>
              <input
                type="password"
                className="form-control"
                value={this.state.ConfirmPwd}
                onChange={this.handlechange("ConfirmPwd")}
                id="ConfirmPwd"
                required
              />

              <span className="form-text small  text-danger">
                {this.validator.message(
                  "Confirm Password",
                  this.state.ConfirmPwd,
                  `required|matchPWD:${this.state.newPwd}`
                )}
              </span>
            </div>
            <div className="form-group">
              <div className="row">
                <div className="col text-center">
                  <button
                    type="submit"
                    onClick={this.submit}
                    className="btn btn-lg btn-primary spinner"
                  >
                    &nbsp;&nbsp;Submit &nbsp;&nbsp;
                    {this.state.isSubmitted ? (
                      <div
                        className="spinner-border spinner-border-sm"
                        role="status"
                      >
                        <span className="sr-only"></span>
                      </div>
                    ) : null}
                  </button>{" "}
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    loginData: state.loginData,
  };
};
const mapDispatchToProps = { resetPassword, updateExpiredPwd };
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(ResetPassword));
