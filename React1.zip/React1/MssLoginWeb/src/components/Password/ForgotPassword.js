import React, { Component } from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import SimpleReactValidator from "simple-react-validator";
import {
  forgotPassword,
  forgotPasswordValidation,
} from "../../redux/actions/ForgotPasswordAction";
import Modal from "../../components/UI/Modal/Modal";
import Navbar from "../../components/UI/Login/Navbar";
import { Button } from "../UI/Button";
import isEmpty from "lodash/isEmpty";

class ForgotPassword extends Component {
  constructor(props) {
    super(props);
    this.validator = new SimpleReactValidator({
      validators: {
        equals: {
          message: ":attribute is Incorrect",
          rule: (val, params, validator) => {
            return val.toUpperCase() === params[0].toUpperCase();
          },
        },
      },
      messages: {
        required: "This field is required",
      },
      autoForceUpdate: this,
    });
    this.state = {
      userId: "",
      answer1: null,
      answer2: "",
      answer3: "",
      searchSuccess: false,
      quesNo: 1,
      error: null,
      isSubmitted: false,
      count: 0,
    };
  }

  handlechange = (name) => (event) => {
    let value = event.target.value;

    this.setState({
      [name]: value.toUpperCase(),
      error:false
    });
  
  };

  validateUser = async (e) => {
    e.preventDefault();
    this.setState({ isSubmitted: true });
    if (this.validator.fields["User Id"]) {
      const result = await this.props.forgotPassword({
        userId: this.state.userId,
      });
      if ("success" === result) {
        this.validator.hideMessages();

        await this.setState({
          searchSuccess: true,
          hintVO: this.props.forgotPwdData.forgotPwdVo,
        });
      } else {
        this.setState({ error: result });
      }
    } else {
      this.validator.showMessages();
    }
    this.setState({ isSubmitted: false });
  };

  nextQuestion = (event) => {
    event.preventDefault();
    this.setState({ isSubmitted: true });

    const { quesNo } = this.state;
    this.validator.showMessages();

    if (1 === quesNo) {
      if (this.validator.fields["Answer1"]) {
        this.validator.hideMessages();
        this.setState({ quesNo: quesNo + 1 });
      }
    } else if (2 === quesNo) {
      if (this.validator.fields["Answer2"]) {
        this.validator.hideMessages();
        this.setState({ quesNo: quesNo + 1 });
      }
    }
    this.setState({ isSubmitted: false });
  };

  submitAnswers = async (e) => {
    e.preventDefault();
    this.setState({ isSubmitted: true });

    if (this.validator.allValid()) {
      let status = {
        userId: this.state.userId,
        status: 200,
      };
      const message = await this.props.forgotPasswordValidation(status);
      Modal(message, "", "", this.props.history);
    } else {
      this.validator.showMessages();
    }
    this.setState({ isSubmitted: false });
  };

  cancel = (e) => {
    e.preventDefault();
    this.setState({
      searchSuccess: false,
      hintVO: [],
      answer1: "",
      answer2: "",
      answer3: "",
    });
  };
  handleNext = async (e) => {
    e.preventDefault();
    if(!this.validator.allValid()){
    this.validator.showMessages()
    this.forceUpdate()
    return
    }
    let forgotPwdVo = this.props.forgotPwdData.forgotPwdVo;
    const payload = {
      userId: forgotPwdVo.userId,
      hintId: forgotPwdVo.hintId,
      question: forgotPwdVo.question,
      answer: this.state.answer1,
      token: forgotPwdVo.token,
      message: forgotPwdVo.message,
    };
    let msg = "";

    const result = await this.props.forgotPassword(payload);

    if (result === "success") {
      this.validator.hideMessages();
      this.setState({
        answer1: "",
        userId: "",
        count: this.state.count + 1,
      });
    }

    // Modal(isEmpty(mg)?result:mg, "", "", );
    if (result !== "success") Modal(result, "", "");
   /* if(result==="Password Reset Link sent to your email address" ){
      window.location.replace("/")
    }*/
  };
  render() {
    const stepper = this.state.searchSuccess ? (
      <div className="row mx-auto stepper">
        <div className="stepwizard-step col-md-4">
          <a
            href="#step-1"
            type="button"
            className={
              "btn btn-default btn-circle " +
              (this.state.quesNo > 1 ? "btn-success" : " btn-default ")
            }
            disabled
          >
            1
          </a>
          <p>Step 1</p>
        </div>
        <div className="stepwizard-step col-md-4">
          <a
            href="#step-2"
            type="button"
            className={
              "btn btn-default btn-circle " +
              (this.state.quesNo > 2 ? "btn-success" : " btn-default ")
            }
            disabled
          >
            2
          </a>
          <p>Step 2</p>
        </div>
        <div className="stepwizard-step col-md-4">
          <a
            href="#step-3"
            type="button"
            className={
              "btn btn-default btn-circle " +
              (this.state.quesNo > 3 ? "btn-success" : " btn-default ")
            }
            disabled
          >
            3
          </a>
          <p>Step 3</p>
        </div>{" "}
        <hr />
      </div>
    ) : null;
    return (
      <>
        <Navbar />
        <div
          className="container setup-content card "
          style={{ marginTop: "5rem" }}
        >
          <form classNameName="wrapper-slide" autoComplete="off">
            <div classNameName="forgotPwd mb-4 mt-8">
              <div classNameName="row">
                <div classNameName="col-md-2">
                  <img
                    src="/images/wipro-logo.png"
                    alt="Wipro logo"
                    classNameName="wipro-logo-pwd"
                  />
                </div>{" "}
                <div classNameName="col-md-8" style={{ marginTop: "2rem" }}>
                  <h4>Forgot Password ?</h4>
                </div>
              </div>
              <i classNameName="fa fa-lock lock" />
            </div>
            {stepper}
            {!this.state.searchSuccess ? (
              <div className="mx-auto col-md-6 mb-5">
                
                <div className="input-group ">
                  <input
                    autoFocus
                    max={10}
                    type="text"
                    className="form-control"
                    placeholder="Please enter userId"
                    value={this.state.userId}
                    onChange={this.handlechange("userId")}
                  />

                  <div className="input-group-append">
                    <Button
                      submit={this.validateUser}
                      spinner={this.state.isSubmitted}
                      label="Submit"
                      type="Submit"
                    />
                  </div>
                </div>{" "}
                {this.state.error ? (
                  <div className="form-text small  text-danger row error">
                    {this.state.error}{" "}
                  </div>
                ) : null}
                <div className="form-text small  text-danger row error">
                  {this.validator.message(
                    "User Id",
                    this.state.userId,
                    "required"
                  )}
                </div>
              </div>
            ) : null}
            {this.state.searchSuccess ? (
              <div classNameName="mb-5">
                {this.state.quesNo === 1 ? (
                  <form onSubmit={this.handleNext}>
                    {" "}
                    <div
                      className="row setup-content  mx-auto  slide"
                      id="step-1"
                    >
                      {this.state.count < 3 ? (
                        <div className="col-md-12">
                          <div>
                            {" "}
                            Question {this.state.count + 1}:
                            {this.props.forgotPwdData.forgotPwdVo.question}
                          </div>
                          <div className="input-group ">
                            <input
                              autoFocus
                              max={50}
                              type="text"
                              className="form-control"
                              placeholder="Please enter Answer"
                              value={this.state.answer1}
                              onChange={this.handlechange("answer1")}
                            />

                            <div className="input-group-append">
                              <Button
                                type="submit"
                                //spinner={this.state.isSubmitted}
                                label="Next"
                              />
                            </div>
                          </div>{" "}
                          <div className="form-text small  text-danger row error">
                            {this.validator.message(
                              "Answer1",
                              this.state.answer1,
                              "required"
                            )}
                          </div>
                        </div>
                      ) : (
                        <p>Link has been sent to your mail</p>
                      )}

                      {/*   <div className="form-text small  text-danger row error">
                          {this.validator.message(
                            "Answer 1",
                            this.state.answer1,
                            [
                              "required",
                              {
                                equals: this.state.hintVO.hintAnswer,
                              },
                            ]
                          )}
                        </div>*/}
                    </div>
                  </form>
                ) : null}
                {this.state.quesNo === 2 ? (
                  <form onSubmit={this.nextQuestion}>
                    {" "}
                    <div className="row setup-content  mx-auto " id="step-2">
                      <div className="col-md-12">
                        <div> Question 2:{this.state.hintVO.hintQuestion2}</div>

                        <div className="input-group ">
                          <input
                            //autoFocus
                            maxlength="50"
                            type="text"
                            className="form-control"
                            placeholder="Please enter Answer"
                            value={this.state.answer2}
                            onChange={this.handlechange("answer2")}
                          />

                          <div className="input-group-append">
                            <Button
                              type="submit"
                              spinner={this.state.isSubmitted}
                              label="Next"
                            />
                          </div>
                        </div>
                        <div className="form-text small  text-danger row error">
                          {this.validator.message(
                            "Answer2",
                            this.state.answer2,

                            "required"
                          )}
                        </div>
                      </div>
                    </div>
                  </form>
                ) : null}
                {this.state.quesNo === 3 ? (
                  <form onSubmit={this.submitAnswers}>
                    {" "}
                    <div className="row setup-content  mx-auto" id="step-3">
                      <div className="col-md-12">
                        <div> Question 3:{this.state.hintVO.hintQuestion3}</div>

                        <div className="input-group ">
                          <input
                            // autoFocus
                            maxlength="50"
                            type="text"
                            className="form-control"
                            placeholder="Please enter Answer"
                            value={this.state.answer3}
                            onChange={this.handlechange("answer3")}
                          />

                          <div className="input-group-append">
                            <Button
                              type="submit"
                              spinner={this.state.isSubmitted}
                              label="Submit"
                            />
                          </div>
                        </div>
                        <div className="form-text small  text-danger row error">
                          {this.validator.message(
                            "Answer3",
                            this.state.answer3,

                            "required"
                          )}
                        </div>
                      </div>
                    </div>
                  </form>
                ) : null}
              </div>
            ) : null}
          </form>
          <div classNameName="resetinfo row">
            <p>
              {" "}
              <h6>
                You will be required to answer three hint questions correctly.
                Once completed an email will be sent containing information on
                reseting your password.
              </h6>
            </p>
            <p>
              Please contact the Help Desk at 1-877-833-3499 in case on any
              concerns
            </p>
          </div>
        </div>
      </>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    forgotPwdData: state.forgotPwdData,
    forgotPwdValidData: state.forgotPwdData.forgotPwdValid,
  };
};
const mapDispatchToProps = { forgotPassword, forgotPasswordValidation };

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(ForgotPassword));
