import React, { Component } from "react";
import { connect } from "react-redux";
import SimpleReactValidator from "simple-react-validator";
import {
  HINT1_LIST,
  HINT2_LIST,
  HINT3_LIST,
} from "../../constants/hintQuestion";
import { updateUserInfo } from "../../redux/actions/LoginAction";
import Modal from "../UI/Modal/Modal";
import { Select } from "../UI/Select";
import ConfirmBox from "./../../utils/PopUp";
import { Button } from "../UI/Button";

class UserInfo extends Component {
  state = {
    userInfoVo: {
      phoneNo: this.props.loginData.loginVo.phoneNo,
      emailId: this.props.loginData.loginVo.emailId,
      hintId: this.props.loginData.loginVo.hintId,
      hintId2: this.props.loginData.loginVo.hintId2,
      hintId3: this.props.loginData.loginVo.hintId3,
      hintAnswer: this.props.loginData.loginVo.hintAnswer,
      hintAnswer2: this.props.loginData.loginVo.hintAnswer2,
      hintAnswer3: this.props.loginData.loginVo.hintAnswer3,
      userId: this.props.loginData.loginVo.userId,
      groupId: this.props.loginData.loginVo.groupId,
    },
    modified: false,
    isSubmitted: false,
  };
  constructor(props) {
    super(props);
    this.validator = new SimpleReactValidator({
      validators: {
        hintAnswerCheck: {
          message: ":attribute Should not be same",
          rule: (val, params, validator) => {
            if (val !== "") {
              if (
                val.trim() == params[0].trim() ||
                val.trim() == params[1].trim()
              ) {
                return false;
              }
              return true;
            }
          },
        },
      },
    });
  }

  handlechange = (event) => {
    let value = event.target.value.toUpperCase();
    let name = event.target.name;
    if ("emailId" === name) {
      value = value.toLowerCase();
    }
    this.setState((prevState) => ({
      userInfoVo: {
        ...prevState.userInfoVo,
        [name]: value,
      },

      modified: true,
    }));
  };

  handleChangeSearchSelect = (name) => (event) => {
    let value = event.target.value;

    this.setState((prevState) => ({
      userInfoVo: {
        ...prevState.userInfoVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  handleNumberChange = (event) => {
    let name = event.target.name;
    let value = event.target.value.replace(/[^0-9]/g, "").trim();
    value = value.replace(/(\d{3})/, "$1-");
    value = value.replace(/(\d{3})(\d{1})/, "$1-$2");
    this.setState((prevState) => ({
      userInfoVo: {
        ...prevState.userInfoVo,
        [name]: value,
      },
      modified: true,
    }));
  };

  submit = (e) => {
    e.preventDefault();
    if (this.validator.allValid()) {
      ConfirmBox(this.updateDetails);
    } else {
      this.validator.showMessages();
      this.forceUpdate();
    }
  };
  updateDetails = async () => {
    this.setState({ isSubmitted: true });
    const message = await this.props.updateUserInfo(this.state.userInfoVo);

    Modal(message);
    this.setState({ isSubmitted: false });
  };

  render() {
    return (
      <div className="col-md-6 offset-md-3">
        <div className="card card-outline-secondary">
          <div className="card-body">
            <h5 className="text-center">User Info</h5>
            <hr />
            <form>
              <div className="row">
                <div className="form-group col-md-6">
                  <label>Password Hint 1</label>
                  <Select
                    optionList={HINT1_LIST}
                    value={this.state.userInfoVo.hintId}
                    handleChange={this.handleChangeSearchSelect("hintId")}
                    width="250px"
                  />
                  <span className="form-text small  text-danger">
                    {this.validator.message(
                      "Hint Questions",
                      this.state.userInfoVo.hintId,
                      `required|hintAnswerCheck:${this.state.userInfoVo.hintId2},${this.state.userInfoVo.hintId3}`
                    )}
                  </span>
                </div>
                <div className="form-group col-md-6">
                  <label>Password Ans 1</label>
                  <input
                    className="form-control"
                    name="hintAnswer"
                    value={this.state.userInfoVo.hintAnswer}
                    onChange={this.handlechange}
                    minLength={3}
                    type="text"
                  />
                  <span className="form-text small  text-danger">
                    {this.validator.message(
                      "Hint Answer",

                      this.state.userInfoVo.hintAnswer,

                      `required|min:3|hintAnswerCheck:${this.state.userInfoVo.hintAnswer2},
                      ${this.state.userInfoVo.hintAnswer3}`
                    )}
                  </span>
                </div>
              </div>

              <div className="row">
                <div className="form-group col-md-6">
                  <label>Password Hint 2</label>
                  <Select
                    optionList={HINT2_LIST}
                    value={this.state.userInfoVo.hintId2}
                    handleChange={this.handleChangeSearchSelect("hintId2")}
                    width="250px"
                  />
                  <span className="form-text small  text-danger">
                    {this.validator.message(
                      "Hint Questions ",
                      this.state.userInfoVo.hintId2,
                      `required|hintAnswerCheck:${this.state.userInfoVo.hintId},${this.state.userInfoVo.hintId3}`
                    )}
                  </span>
                </div>
                <div className="form-group col-md-6">
                  <label>Password Ans 2</label>
                  <input
                    className="form-control"
                    name="hintAnswer2"
                    value={this.state.userInfoVo.hintAnswer2}
                    onChange={this.handlechange}
                    minLength={3}
                    type="text"
                  />
                  <span className="form-text small  text-danger">
                    {this.validator.message(
                      "Hint Answer",
                      this.state.userInfoVo.hintAnswer2,

                      `required|min:3|hintAnswerCheck:${this.state.userInfoVo.hintAnswer},
                      ${this.state.userInfoVo.hintAnswer3}`
                    )}
                  </span>
                </div>
              </div>

              <div className="row">
                <div className="form-group col-md-6">
                  <label>Password Hint 3</label>
                  <Select
                    optionList={HINT3_LIST}
                    value={this.state.userInfoVo.hintId3}
                    handleChange={this.handleChangeSearchSelect("hintId3")}
                    width="250px"
                  />
                  <span className="form-text small  text-danger">
                    {this.validator.message(
                      "Hint Questions ",

                      this.state.userInfoVo.hintId3,

                      `required|hintAnswerCheck:${this.state.userInfoVo.hintId},${this.state.userInfoVo.hintId2}`
                    )}
                  </span>
                </div>
                <div className="form-group col-md-6">
                  <label>Password Ans 3</label>
                  <input
                    className="form-control"
                    name="hintAnswer3"
                    value={this.state.userInfoVo.hintAnswer3}
                    onChange={this.handlechange}
                    minLength={3}
                    type="text"
                  />
                  <span className="form-text small  text-danger">
                    {this.validator.message(
                      "Hint Answer",
                      this.state.userInfoVo.hintAnswer3,

                      `required|min:3|hintAnswerCheck:${this.state.userInfoVo.hintAnswer},
                      ${this.state.userInfoVo.hintAnswer2}`
                    )}
                  </span>
                </div>
              </div>

              <div className="row">
                <div className="form-group col-md-6">
                  <div className="form-group">
                    <label>Email Id</label>
                    <input
                      className="form-control"
                      type="text"
                      name="emailId"
                      value={this.state.userInfoVo.emailId}
                      onChange={this.handlechange}
                    />
                  </div>

                  <span className="form-text small  text-danger">
                    {this.validator.message(
                      "Email",
                      this.state.userInfoVo.emailId,
                      "email"
                    )}
                  </span>
                </div>

                <div className="form-group col-md-6">
                  <div className="form-group">
                    <label>Mobile Number</label>
                    <input
                      className="form-control"
                      name="phoneNo"
                      value={this.state.userInfoVo.phoneNo}
                      onChange={this.handleNumberChange}
                      maxLength={12}
                      max="12"
                      type="text"
                    />
                  </div>
                </div>
              </div>

              <div className="form-group">
                <div className="row">
                  <div className="col text-center">
                    <Button
                      type="submit"
                      submit={this.submit}
                      spinner={this.state.isSubmitted}
                      label="Update"
                      disabled={!this.state.modified}
                    />
                  </div>
                </div>
              </div>
            </form>
          </div>{" "}
        </div>{" "}
      </div>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    loginData: state.loginData,
  };
};
const mapDispatchToProps = { updateUserInfo };
export default connect(mapStateToProps, mapDispatchToProps)(UserInfo);
