import React, { Component } from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { CUSTOMER_LOGO } from "../../constants/Logos";
import Footer from "../UI/Login/Footer";
import { login360 } from "../../redux/actions/loginActionE360";
import {loginAnalytics} from "../../redux/actions/AnalyticsAction"

class LandingPage extends Component {
  clickhandle = async (type) => {
    
    if(type==="E360"){
      await this.props.login360();
      let { data } = this.props.E360login;
      window.open(data);
    }
   else if(type==="Analytics"){
    await this.props.loginAnalytics();
    let { data } = this.props.analyticsData;
   let {jasperURL,ppValue}=data  
   let url=jasperURL+"?pp="+ppValue  
   window.open(url)
   }
  };

  async componentDidMount() {
    this.intervalId = setInterval(() => {
      if (localStorage.getItem("token") === null) {
        this.props.closeAllTab();
      }
    }, 1000);
  }
  async componentWillUnmount() {
    await clearInterval(this.intervalId);
  }

  render() {
    const servicesEnabled = this.props.loginData.servicesEnabled;

    let rapsMenuCnt = 0;
    if (servicesEnabled) {
      if (servicesEnabled && servicesEnabled.includes("RaExpert")) {
        rapsMenuCnt++;
      }
      if (servicesEnabled && servicesEnabled.includes("RCC")) {
        rapsMenuCnt++;
      }
      if (servicesEnabled && servicesEnabled.includes("HPE")) {
        rapsMenuCnt++;
      }
      if (servicesEnabled && servicesEnabled.includes("Enctr")) {
        rapsMenuCnt++;
      }
    }

    let loginGroupName = this.props.loginData.loginVo.customerId;

    return (
      <div className="landing-page-bg">
        <div className="wrapper">
          <nav id="sidebar">
            <div className="sidebar-header">
              <span className="wlogo">
                <img src="/images/wipro-logo.png" alt="Wipro logo" />
              </span>
              <span className="clogo">
                <img
                  style={{ width: "140px" }}
                  src={CUSTOMER_LOGO[loginGroupName]}
                  alt={this.props.loginData.loginVo.customerName}
                />
              </span>
            </div>

            <ul className="list-unstyled components">
              <li>
                <a
                  href="#m360submenu"
                  data-toggle="collapse"
                  aria-expanded="false"
                  className="dropdown-toggle"
                  id="M360page"
                >
                  <i className="icon-users" /> <span>M360</span>
                </a>

                <ul className="collapse list-unstyled" id="m360submenu">
                  {servicesEnabled && servicesEnabled.includes("EEM") ? (
                    <li>
                      <a
                        onClick={() =>
                          this.props.handleNewTAb("/mss/dashboard")
                        }
                        id="EEMpage"
                      >
                        Pre-enroll and Membership
                      </a>
                    </li>
                  ) : null}
                  {/* {servicesEnabled && servicesEnabled.includes("HII") ? (
                    <li>
                      <a href="#">Eligibility</a>
                    </li>
                  ) : null} */}
                  {servicesEnabled && servicesEnabled.includes("MBI XREF") ? (
                    <li>
                      <a href="#">MBI XREF</a>
                    </li>
                  ) : null}
                  {servicesEnabled && servicesEnabled.includes("EEMB") ? (
                    <li>
                      <a
                        onClick={() => this.props.handleNewTAb("/mss/billing")}
                      >
                        Billing
                      </a>
                    </li>
                  ) : null}
                  <li>
                    <a
                      onClick={() => this.props.handleNewTAb("/mss/dashboard")}
                    >
                      Dashboard
                    </a>
                  </li>
                </ul>
              </li>

              <li>
                <a onClick={()=>this.clickhandle("E360")}>
                  <i className="icon-desktop" /> <span>E&E360</span>
                </a>
              </li>
              <li>
                <a
                  href="#r360submenu"
                  data-toggle="collapse"
                  aria-expanded="false"
                  className="dropdown-toggle"
                  id="R360page"
                >
                  <i className="icon-users" /> <span>R360</span>
                </a>
                <ul className="collapse list-unstyled" id="r360submenu">
                  {servicesEnabled &&
                    (servicesEnabled.includes("RXR") ||
                      servicesEnabled.includes("RP")) ? (
                      <li>
                        <a href="#">Recon/RxRecon</a>
                      </li>
                    ) : null}
                  {servicesEnabled && servicesEnabled.includes("ILMR") ? (
                    <li>
                      <a href="#">IL Medicaid Recon</a>
                    </li>
                  ) : null}
                  {servicesEnabled && servicesEnabled.includes("NMMR") ? (
                    <li>
                      <a href="#">NM Medicaid Recon</a>
                    </li>
                  ) : null}
                  {servicesEnabled && servicesEnabled.includes("TXMR") ? (
                    <li>
                      <a href="#">TX Medicaid Recon</a>
                    </li>
                  ) : null}
                  {servicesEnabled && servicesEnabled.includes("MNMR") ? (
                    <li>
                      <a href="#">MN Medicaid Recon</a>
                    </li>
                  ) : null}
                </ul>
              </li>
              {servicesEnabled &&
                servicesEnabled.includes("FTS") &&
                servicesEnabled &&
                servicesEnabled.includes("FTEmail") ? (
                  <li>
                    <a
                      href="#m360submenu"
                      data-toggle="collapse"
                      aria-expanded="false"
                      className="dropdown-toggle"
                      id="M360page"
                    >
                      <i className="icon-users" /> <span>Reporting</span>
                    </a>
                    <ul className="collapse list-unstyled" id="m360submenu">
                      <li>
                        <a>Reporting Menu</a>
                      </li>
                      <li>
                        <a href="#">Email Admin</a>
                      </li>
                    </ul>
                  </li>
                ) : (
                  <React.Fragment>
                    {servicesEnabled && servicesEnabled.includes("FTS") ? (
                      <li>
                        <a
                          onClick={() =>
                            this.props.handlReproting("/mssfile/reporting")
                          }
                        >
                          <i className="icon-doc-text" /> <span>Reporting</span>
                        </a>
                      </li>
                    ) : null}
                    {servicesEnabled && servicesEnabled.includes("FTEmail") ? (
                      <li>
                        <a href="#">
                          <i className="icon-doc-text" /> <span>Email Admin</span>
                        </a>
                      </li>
                    ) : null}
                  </React.Fragment>
                )}
              {servicesEnabled && servicesEnabled.includes("JAS") ? (
                <li>
                  <a  onClick={()=>this.clickhandle("Analytics")}>
                    <i className="icon-desktop" /> <span>Analytics</span>
                  </a>
                </li>
              ) : null}
              {servicesEnabled && servicesEnabled.includes("RESQ") ? (
                <li>
                  <a>
                    <i className="icon-desktop" /> <span>E&E360</span>
                  </a>
                </li>
              ) : null}
              {rapsMenuCnt > 1 ? (
                <li>
                  <a
                    href="#risksubmenu"
                    data-toggle="collapse"
                    aria-expanded="false"
                    className="dropdown-toggle"
                  >
                    <i className="icon-th-list" /> <span>Risk Management</span>
                  </a>
                  <ul className="collapse list-unstyled" id="risksubmenu">
                    {servicesEnabled && servicesEnabled.includes("RaExpert") ? (
                      <li>
                        <a href="#">RA-Expert</a>
                      </li>
                    ) : null}
                    {servicesEnabled && servicesEnabled.includes("RCC") ? (
                      <li>
                        <a href="#">RAPS-Expert</a>
                      </li>
                    ) : null}
                    {servicesEnabled && servicesEnabled.includes("Enctr") ? (
                      <li>
                        <a href="#">Encounter Data</a>
                      </li>
                    ) : null}
                    {servicesEnabled && servicesEnabled.includes("HPE") ? (
                      <li>
                        <i className="icon-desktop" />{" "}
                        <a
                          href="#"
                          onClick={(e) => {
                            e.preventDefault()
                            localStorage.getItem("token") === null
                              ? this.props.closeAllTab()
                              : this.props.handleNewTAbEDP("/edps")
                          }}
                          id="edps"
                          tabindex="0"
                        >
                          Encounters
                        </a>
                      </li>
                    ) : null}
                  </ul>
                </li>
              ) : rapsMenuCnt > 0 ? (
                <li>
                  {servicesEnabled && servicesEnabled.includes("RaExpert") ? (
                    <a>
                      <i className="icon-desktop" /> <span>RA-Expert</span>
                    </a>
                  ) : null}
                  {servicesEnabled && servicesEnabled.includes("RCC") ? (
                    <a>
                      <i className="icon-desktop" /> <span>RAPS-Expert</span>
                    </a>
                  ) : null}
                  {servicesEnabled && servicesEnabled.includes("Enctr") ? (
                    <a href="#">
                      <i className="icon-desktop" /> <span>Encounter Data</span>
                    </a>
                  ) : null}
                  {servicesEnabled && servicesEnabled.includes("HPE") ? (
                    <li>
                      <i className="icon-desktop" />{" "}
                      <a href="/edps" id="edps">
                        Encounters
                      </a>
                    </li>
                  ) : null}
                </li>
              ) : null}
              {servicesEnabled && servicesEnabled.includes("RetroAdj") ? (
                <li>
                  <a href="#">
                    <i className="icon-desktop" /> <span>Retro Adjustment</span>
                  </a>
                </li>
              ) : null}
              {servicesEnabled && servicesEnabled.includes("ERS") ? (
                <li>
                  <a href="#">
                    <i className="icon-desktop" /> <span>Enroll Recon</span>
                  </a>
                </li>
              ) : null}
              {servicesEnabled && servicesEnabled.includes("BOR") ? (
                <li>
                  <a href="#">
                    <i className="icon-desktop" /> <span>Reporting</span>
                  </a>
                </li>
              ) : null}
              {servicesEnabled && servicesEnabled.includes("ELID") ? (
                <li>
                  <a href="">
                    <i className="icon-desktop" /> <span>ELIGIBILITY IND</span>
                  </a>
                </li>
              ) : null}
              {servicesEnabled && servicesEnabled.includes("HII") ? (
              <li>
                <a
                  href="#m360submenu1"
                  data-toggle="collapse"
                  aria-expanded="false"
                  className="dropdown-toggle"
                  id="M360page"
                >
                  <i className="icon-users" /> <span>New M360 UI</span>
                </a>

                <ul className="collapse list-unstyled" id="m360submenu1">
                  {servicesEnabled && servicesEnabled.includes("EEM") ? (
                    <li>
                      <a
                        onClick={() =>
                          this.props.handleNewTAbM("/newMssUI/application")
                        }
                        id="newEEMpage"
                      >
                        Pre-enroll and Membership
                      </a>
                    </li>
                  ) : null}
                </ul>
              </li>
              ) : null}
            </ul>
          </nav>

          <div id="content">
            <div className="topnav topnav-margin">
              <nav className="navbar navbar-default">
                <div className="container-fluid">
                  <div className="navbar-header">
                    <button
                      type="button"
                      id="sidebarCollapse"
                      className="btn btn-info"
                    >
                      <i />
                      <i />
                      <i />
                    </button>
                    &nbsp;
                  </div>
                  <div className="navbar-collapse" id="navbar-top-right">
                    <ul
                      className="nav"
                      style={{ color: "white", marginright: "2rem" }}
                    >
                      <li>
                        <div style={{ color: "white" }}>
                          <Link to="/landing">Home</Link>
                        </div>
                      </li>
                      <div className="dropdown">
                        <button
                          className="dropdown-toggle"
                          id="dropdownMenuButton"
                          data-toggle="dropdown"
                          aria-haspopup="true"
                          aria-expanded="false"
                          style={{
                            marginLeft: "2rem", cursor: "pointer",
                            backgroundColor: "#053674", color: "white", border: "none"
                          }}
                          tabindex="0"
                        >
                          <i
                            className="fa fa-user"
                            style={{ color: "white" }}
                          />{" "}
                          Welcome {this.props.loginData.loginVo.userId}
                          &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                          <span
                            className="glyphicon glyphicon-chevron-down"
                            style={{ color: "white" }}
                          ></span>
                        </button>
                        <div
                          className="dropdown-menu"
                          aria-labelledby="dropdownMenuButton"
                          style={{ marginTop: "1rem" }}
                        >
                          {!this.props.loginData.ssoUser ? (
                            <div>
                              <li className="dropdown-item" >
                                <a href="" tabindex="-1">
                                  <i
                                    className="fa fa-lock"
                                    onClick={this.setRedirect}
                                  />{" "}
                                  &nbsp;
                                  <Link to="/changepassword">
                                    Change password
                                  </Link>
                                </a>
                              </li>
                              <li className="dropdown-item" >
                                <a href="" tabindex="-1">
                                  <i className="fa fa-user" /> &nbsp;
                                  <Link to="/Profile">Profile</Link>
                                </a>
                              </li>
                              <li className="divider"></li>
                            </div>
                          ) : null}

                          <li className="dropdown-item">
                            <a onClick={this.props.logout} tabindex="-1">
                              <i className="fa fa-sign-out" />
                              <Link> Logout </Link>
                            </a>
                          </li>
                        </div>
                      </div>
                    </ul>
                  </div>
                </div>
              </nav>
            </div>
            <div className="content-container">{this.props.children}</div>

            <Footer />
          </div>
        </div>
      </div>
    );
  }
}
const mapDispatchToProps = {
  login360,
  loginAnalytics,
};
const mapStateToProps = (state) => {
  return {
    loginData: state.loginData,
    E360login: state.E360login.loginVoE360,
    analyticsData:state.AnalyticsReducer.loginVoAnalytics
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(LandingPage);
