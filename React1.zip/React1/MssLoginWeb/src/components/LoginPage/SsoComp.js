import "../../../src/assets/js/lightslider";

import React, { Component } from "react";
import { withRouter } from "react-router-dom";
import { ssoLogin } from "../../redux/actions/LoginAction";
import { connect } from "react-redux";

class SsoComp extends Component {
  async componentDidMount() {
    const token = this.props.match.params.token;
    const response = await this.props.ssoLogin(token);
    if (response.statusCode === 200) {
      this.props.history.push("/landing");
    } else {
      this.props.history.push("/login");
    }
  }

  render() {
    return <React.Fragment></React.Fragment>;
  }
}

const mapDispatchToProps = {
  ssoLogin,
};

export default connect(null, mapDispatchToProps)(withRouter(SsoComp));
