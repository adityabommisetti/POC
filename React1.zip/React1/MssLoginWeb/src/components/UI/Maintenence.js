import React from "react";

export const Maintenence = () => {
  return (
    <div className="page-wrap d-flex flex-row align-items-center">
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-md-12 text-center">
            <span className="display-1 d-block">Oops</span>
            <div className="mb-4 lead">
            <h4>
                    Temporarily down for maintenance</h4>
                <h3>
                    We’ll be back soon!</h3>
                <div>
                    {/* <p>
                        Sorry for the inconvenience but we’re performing some maintenance at the moment.
                        we’ll be back online shortly!</p> */}
                    <p>
                    <img
                  src="/images/wipro-logo.png"
                  alt="Wipro logo"
                  classNameName="wipro-logo-pwd"
                />   Wipro Team</p>
                        
                </div>
                <a href="/" className="btn btn-link">
              Back to Home
            </a>
            <br/>
            <br/>
            <br/>
            <br/>
            <br/>
            <br/>
            <br/>
            <br/>
            <br/>
            <br/>
            
                <div  className="text-center mainten">Please contact our Help Desk 
		<br/><i classNameName ="fa fa-phone"></i>&nbsp;(877) 833-3499 
		<br/> Be sure to mention you are on the Medicare Support Services Website and the error you received.
	</div>
            </div>
             
          </div>
        </div>
      </div>
    </div>
  );
};
