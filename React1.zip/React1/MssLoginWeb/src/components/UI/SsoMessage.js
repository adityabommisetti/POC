import React from "react";

export const SsoMessage = (props) => {
  window.history.pushState(null, document.title, window.location.href);
  window.addEventListener("popstate", function (event) {
    window.history.pushState(null, document.title, window.location.href);
  });
  var message = props.match.params.message;
  return (
    <div className="page-wrap d-flex flex-row align-items-center">
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-md-12 text-center">
            <div className="mb-4 lead">
              <h4>{message}</h4>
              <div>
                <p>
                  <img
                    src="/images/wipro-logo.png"
                    alt="Wipro logo"
                    className="wipro-logo-pwd"
                  />{" "}
                  Wipro Team
                </p>
              </div>
              {message !== "You have successfully logged out.Thank you." &&
              message !==
                "Your Account Logged out due to Session Expiry. Thank You" ? (
                <div className="text-center mainten">
                  Please contact our Help Desk
                  <br />
                  <i classNameName="fa fa-phone"></i>&nbsp;(877) 833-3499
                  <br /> Be sure to mention you are on the Medicare Support
                  Services Website and the error you received.
                </div>
              ) : null}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
