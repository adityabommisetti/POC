module.exports = `<!DOCTYPE html>
<head>
</head>

<BODY>

<table width="100%"  border="0" cellspacing="0"  cellpadding="5">

<tr>
       <td height="1" bgcolor="#999999"></td>  
  </tr>
  
   <tr>
       
<td><BR>
       <table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
<td width="25" valign="top"><img
     src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - Announcement of the May 2019 Software Release & Wipro Impact Analysis ****</span>											
                <br><br>					
Good afternoon, please find below the following documents which contain details of the CMS May 2019 software release:
<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1. <a href="/mss/IFOXDocs/May_2019_Detail_Release_Memo_4_11_19.pdf" class="info" target="_blank">CMS Announcement of the May 2019 Software Release</a>
<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2. <a href="/mss/IFOXDocs/Wipro_Impact_Analysis_May_2019_Software_Release.pdf" class="info" target="_blank">Wipro Impact Analysis document</a>
                <BR><br>
Please reach out to your designated Account Managers, Business Analyst and/or the Wipro Helpdesk if you have any questions regarding these documents.
<br><br>
Thank you
<br><br>

Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>

<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - Mainframe Operating Upgrade On 05/12/2019 ****</span>											
                <br><br>					
Wipro will be performing a Z/OS operating upgrade to it's mainframe from version 2.1 to 2.2 on Sunday, 05/12/2019 at 2:00 AM CST.
The upgrade will be carried out during our weekly maintenance window (2:00AM to 5:00 AM CST) but is expected to run another 3 additional
hour, which will end at 8:00 AM CST. <b>All Wipro Mcare websites will be available after 8:00 AM CST on 05/12/2019 and file processing 
will also resume at that time.</b> Please contact our Helpdesk if there is any questions and/or concern regarding this upgrade.
<br><br>
As always, we appreciate your patience and support.
<br><br>

Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - Version 17.15 of the Interface to MSS Document****</span>											
                <br><br>					
Attached please find version 17.15 of the <a href="/mss/IFOXDocs/Interface_to_MSS_17_15.pdf" class="info" target="_blank">Interface to MSS</a> document. <b>Please refer to the red font description under <font color = "red">02/22/2019 - Version 17.15</font> section in the document for the 
changes in this version</b>
<br><br>
Please reach out to your designated Account Managers, Business Analyst if you have any questions regarding the document.
                <BR><br> 
Thank you
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - Website Address Migration - IMPORTANT - PLEASE READ****</span>											
                <br><br>					
Good morning! Wipro would like to inform our clients that as of <b>01/31/2019</b>, URL <a href="https://www.medicare-solution.com/mss/quay/homePage.htm" target= "blank"><b>https://www.medicare-solution.com</b></a>
will be discontinued and will be replaced with <a href="https://base.med-adv360.com/mss/quay/homePage.htm" target= "blank"><b>https://base.med-adv360.com</b></a> permanently.
<br><br>
**Do note, there <font color = "red">will not be any change</font> in LOGIN credentials and web service WSDL link.
<br><br>
<b>Please forward this notice to all Wipro's users within your organization</b>. We appreciate your assistance in this matter and please let us 
know if you have any questions/concerns.

<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - 2018/2019 Holidays Schedule ****</span>											
                <br><br>					
In the spirit of the season, Wipro would like to express our sincere appreciation for you valued partnership and support throughout the 
year and with warmest wishes for a happy Holiday Season and a prosperous New Year!
<br><br>
Wipro would like to inform our clients of our Holiday support and processing schedule. Our offices will be closed on <b>Tuesday, December 25th, 2018</b>
and <b>Tuesday, January 1st, 2019</b> due to the observation of the Christmas and New Year Holidays. All transactions will be submitted to CMS
<b>as normal, at the regular scheduled times</b>.
Should any issues arise during this period, please send an email to our Helpdesk at <a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>.
We will respond to your inquiries on the next business day.
<br><br>

Thank you and Happy Holidays!
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - Production Implementation of the Fall 2018 Software Release - December 29th - 30th, 2018 ****</span>											
                <br><br>					
Wipro would like to inform our clients that the implementation of the Fall 2018 Software release in production will take place on <b> December 29th
beginning at 11:00 PM PST</b> and will conclude on <b>December 30th at 3:00 AM PST</b>. Please refer to the attached documents for details of the 
changes as the layout of the MBD Eligibility response file has been updated.
<br><br>
Please reach out to your designated Account Managers, Business Analyst and/or the Wipro Helpdesk if you have any questions regarding the Fall 
2018 Software release as well as the implementation schedule.
<br><br>
<a href="/mss/IFOXDocs/Fall_2018_Detail_Release_Memo_Final.pdf" class="info" target="_blank">Fall 2018 Detail Release Memo Final</a>
<br><br>
<a href="/mss/IFOXDocs/Wipro_Impact_Analysis_Fall_2018_Release_V03.pdf" class="info" target="_blank">Wipro Impact Analysis Fall 2018 Release V03</a>
<br><br>
<a href="/mss/IFOXDocs/Interface_To_MSS_Version_17_14.pdf" class="info" target="_blank">Interface to MSS V17.04</a>
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>

<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - 2018 THANKSGIVING HOLIDAY ****</span>											
                <br><br>					
In observance of the Thanksgiving Holiday, Wipro offices will be closed on <i><b>Thursday, November 22nd and Friday, November 23rd, 2018</b></i>
<br><br>
<B>All scheduled CMS submission and processes will remain in effect with it's normal daily schedule.</b>. 
<br><br>
Should any issues arise during this period, please send an email to our Helpdesk at <a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>.
<br><br>
We would like to take this opportunity to express our appreciation for your continued support and partnership. We wish you all a safe
and happy holiday!
                <BR><br> 
<font color = "red"> <b>HAPPY THANKSGIVING!</b></font>
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - Version 17.14 of the Interface to MSS Document****</span>											
                <br><br>					
Good Morning.
<BR><BR>
Attached please find version 17.14 of the <a href="/mss/IFOXDocs/Interface_To_MSS_Version_17_14.pdf" class="info" target="_blank">Interface to MSS</a> document. Please refer to the red font section under <b>10/24/2018 - Version 17.14</b> in the document for the 
changes in this version.
<br><br>
Please note the following regarding the Last Dual SEP Use Date field (also mentioned in red font under section <b>10/24/2018 - Version 17.14)</b>:
<BR><BR>
<ul>
<li>CMS will not provide the "Last Dual SEP Use" field on the MBD eligibility layout in time for the January 1, 2019 implementation. The expecation is that CMS will provide 
the update for this field around 1st quarter of 2019. Also per CMS, the volume of election type "L" is expected to be very small and CMS will not start populating this field on the BEQ response
until around February 2019. A filler field of 8 bytes has been defined on the MBD response layout in anticipation of the future CMS update.</li>
</ul>
<BR><BR>
Please reach out to your designated Account Managers, Business Analyst and/or the Wipro Helpdesk if you have any questions regarding the document.
<br><br>

Thank you
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img 

src="/mss/jsp/Recon/images/news_icon.gif" width="14" 

height="16"></td>
       <td align="left"><span class="NewsHeading">**** Wipro Notice - 2018 End-of-Year Processing and other related information ****</span>
       <br><br>
	   Attached please find the <a href="/mss/IFOXDocs/EOY_Memo_2018_For_Release.pdf" class="info" target="_blank">End-of-Year guidance</a>. Please refer to the guidance for additional information regarding End-of-Year processing. Based on the guidance, please refer to the table below for important CMS key dates:
	   <br><br>
	  
				<BR>
				<TABLE border="1">
					<TBODY>
						<TR>
							

<TD><center><b>Date</b></center></TD>
							

<TD><center><b>Item</b></center></TD>
						</TR>
						<TR>
							


<TD>October 03, 2018</TD>
							

<TD>*Begin submitting 2019 enrollment effective dates
					
						<br><br>
							

						*Plans approved for renewal or crosswalk exceptions by CMS that 

require plan-submitted EOY activity must submit MARx transactions. 

(See section 2.B of the attachment) </TD>
						</TR>
						<TR>
<TD>October 05, 2018</TD>
							

<TD>October Plan Data Due Date</TD>
						</TR>
						<TR>
							
							

<TD>October 13, 2018</TD>
							

<TD>Reassignment runs.</TD>
						</TR>
						<TR>
							

<TD>October 15, 2018</TD>
							

<TD>Annual Enrollment Period (AEP) begins</TD>
						</TR>
						<TR>
							

<TD>October 17, 2018</TD>
							

<TD>Plans will receive special Transaction Reply Reports (TRRs) and 

other reports containing reassignment activity. Reassignment letters 

sent to beneficiaries.</TD>
						</TR>
						<TR>
							

<TD>November 01 and 02, 2018</TD>
							

<TD>CMS-generated rollover processing</TD>
						</TR>
						<TR>
<TD>November 9, 2018</TD>
							

<TD>November Plan Data Due Date</TD>
						</TR>
					                <TR>
							
							

<TD>November 12, 2018</TD>


<TD>Transactions 75 and 78 with an effective date of 01/01/2019 will not process if submitted before this date</TD>
                        </TR>
                        <TR>


<TD>December 07, 2018</TD>
							

<TD>AEP ends</TD>
						</TR>
						<TR>
<TD>December 07, 2018</TD>
							

<TD>December Plan Data Due Date</TD>
						</TR>
                                                                                                <TR>
							
							

<TD>January 04, 2019</TD>
							

<TD>January Plan Data Due Date </TD>
						</TR>
					</TBODY>
				</TABLE>
				<br>
	            To assist our clients with their EOY enrollment 

processing, Wipro/Infocrossing will be performing the followings:
	   
	   <br><br>
	   1. <u>All NON_AEP transactions with January 01, 2019 

effective date</u> that will be uploaded to Wipro prior to October 03, 2018, will be held and will be released to CMS for processing on <b>October 03, 2018</b>.
	   <br><br>	   
	  2. <u><b>All CMS approved plan-submitted roll-over or service area reduction disenrollment transactions</b></u> that will be uploaded to Wipro up to <i><b>October 03, 2018</b></i>
will be released to CMS for processing on <i><b>October 03, 2018. Please have your transactions uploaded to Wipro <font color=red>no later than 12:00 Noon PST</font> on October 03, 2018. CMS requires these files to be transmitted to the MARx system only on this day, no later than 5:00 P.M. EST.</b></i>
<font color = "red"><i> If you are planning to submit the rollover 
transactions, please contact Wipro as soon as possible to provide the necessary information so that Wipro can obtain an approval CMS request ID from MARx.
This approved request ID</i> must be used in your rollover file submission.</u></b></i></font> 
	   <br><br>
	   3. <u>All AEP transactions with January 1, 2019 effective 

date</u> that will be uploaded to Wipro will be held and will be 

released to CMS for processing on <b>October 15, 2018</b> right 

after midnight EDT.
	   <br><br>	   
	  4. <u>All 75 and 78 transactions with a January 1, 2019

effective date</u> that will be uploaded to Wipro up to <i><b>November 12, 2018</b></i> will be released to CMS for processing on <b>November 12, 2018</b>.
	   <br><br>	   
	   <font color = "red"><b>****** Special processing for CMS Approved Roll-Over or Service Area Reduction transactions:</b> 

</font>
	   <br><br>
	 
<ul>
     <li>Please contact the Wipro Helpdesk if you have rollover or 

service area reduction disenrollment transactions to submit. Please 

note that these transactions cannot be mixed with regular MARx 

submissions and must be handled seperately. The following link on 

the Wipro/Infocrossing web portal will be made available for you to 

upload these transactions. Please contact our Helpdesk if you do not 

have these links:</ul></li>
<br>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style = "background-color: yellow"><b>CMS Preapproved Rollover Transactions</b></span>
<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style = "background-color: yellow"><b>Upload Data</b></span>


	   <br><br>	   
<ul>            
     <li><b>Please note that Wipro will not be able to accommodate this process through <u>manual input or FTP upload</u>. These transactions can only be processed via a batch file submission on the 

web portal <i>by using the "CMS Preapproved Rollover Transactions" link</i>.</b></li>
                   <br><br>
                   <li><b>Please send us any new contract plans and/or PBP's for 2019 if you haven't done so.</b></li>
</ul> 	   
                   <br><br>
Please forward this announcement to other areas within your organization as you deem necesary. 
<br><br>
Thank you.
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>	
 
			</TR>
		</table>
  </td>
</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - <font color = "red"> <b>2018 Labor Day Holiday Schedule 09/03/2018</b></font> ****</span>											
                <br><br>					
Wipro offices will be closed on Monday, September 3rd, 2018 in observance of the Labor Day Holiday.
All transactions will be submitted to CMS <b>as normal - at the regular scheduled times</b>. Should any issues arise, please send an email to our Helpdesk at <a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>.
We will respond to your inquiries on the next business day. 
                <BR><br> 
Thank you and have a safe Holiday!
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - DME Dashboard ****</span>											
                <br><br>					
We have now enhanced the system by adding a new feature called the DME Dashboard on the web portal.
<BR>
This functionality is available in the EDPS management tab of the EDPS system on the web portal. 
<br>
This feature is available to all EDPS customers and allows them to search and filter data with DME in addition to Institutional and Professional.
<br>
This enhancement will be available on the web portal for all customers who have access to the Encounters tab from 07/13/2018 onward. 
                <BR><br> 
Thank you 
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - <font color = "red"> <b>Independence Day Holiday 07/04/2018</b></font> ****</span>											
                <br><br>					
Wipro offices will be closed on Wednesday, July 4th, 2018 in observance of the Independence Day Holiday.
All transactions will be submitted to CMS <b>as normal - at the regular scheduled times</b>. Should any issues arise, please send an email to our Helpdesk at <a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>.
We will respond to your inquiries on the next business day. 
                <BR><br> 
Thank you and have a safe Holiday!
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - MEMORIAL DAY HOLIDAY May 28th, 2018 ****</span>											
                <br><br>					
Please be advised that in observance of the Memorial Day Holiday, Wipro offices will be closed on Monday, May 28th, 2018.
All transactions will be submitted to CMS <b>as normal - at the regular scheduled times</b>. Should any issues arise, please send an email to our Helpdesk at <a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>.
We will respond to your inquiries on the next business day. 
                <BR><br> 
Thank you and have a safe Holiday!
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - MAPD Help Desk: MARx UI Availability from Friday, April 13 - Friday, April 20  ****</span>											
                <br><br>					
Please see notice below regarding the MARx UI availability and the transmission schedule of the DTRRs:

<br><br>

Please be advised that the MARx UI will be in READ ONLY mode from <b><u>9:30 PM ET Friday, April 13</u></b>, until <b><u>7:00 PM ET Sunday, April 15</u></b>, at which point it will be completely
unavailable due to weekly maintenance. The MARx UI will then be available in READ ONLY mode from <b><u>12:30 AM ET Monday, April 16</u></b>, until <b><u>6:00 AM ET Friday, April 20</u></b>
at which point it will return to UPDATE mode.
<br><br>
Additionally, in support of 2017 MARx Final Year RAS Reconciliation processing activities, Plan transaction processing will stop at <b><u>9:00 PM ET on Friday, April 13</u></b> and will resume on <b><u>Friday, April 20</u></b>.
Submitters will not receive any Batch Completion Reports during this time.
<br><br>
Also, the Daily Transaction Reply Report (DTRR) will not be transmitted to Plans starting <b><u>Sunday, April 15</u></b> through <b><u>Friday, April 20</u></b>. The next DTRR transmission after 
<b><u>Saturday, April 14</u></b>, will be on <b><u> Saturday, April 21</u></b>.
<br><br><br>
Visit the MAPD Help Desk Website to find useful information about the MAPD Program, including FAQs, System Announcements, User Guide, and Plan Connectivity Instructions.
<br><br>
Please call or email the MAPD Help Desk with any questions or concerns.
<br>
Website: <a href="http://go.cms.gov/mapdhelpdesk" target= "blank">http://go.cms.gov/mapdhelpdesk</a> / 1-800-927-8069 / Email: <a class="info" href= "mailto:MAPDHelp@cms.hhs.gov">MAPDHelp@cms.hhs.gov</a>
<br>
MAPD Help Desk hours of operation are Monday - Friday, 8:00 AM to 6:00 PM ET
<br><br>


			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
     src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - Announcement of the February 2018 Software Release & Wipro Impact Analysis ****</span>											
                <br><br>					
Good afternoon, please find below the following documents which contain details of the CMS February 2018 software release:
<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1. <a href="/mss/IFOXDocs/February_2018_Detail_Release_Memo_02052018.pdf" class="info" target="_blank">CMS Announcement of the February 2018 Software Release</a>
<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2. <a href="/mss/IFOXDocs/Wipro_Impact_Analysis_February_2018.pdf" class="info" target="_blank">Wipro Impact Analysis document</a>
                <BR><br>
Please reach out to your designated Account Managers, Business Analyst and/or the Wipro Helpdesk if you have any questions regarding these documents.
<br><br>
Thank you
<br><br>

Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - Addendum to the Announcement of the February 2018 Software Release ****</span>											
                <br><br>					
Please see the attached <a href="/mss/IFOXDocs/February_2018_Detail_Release_Memo_Addendum_EER_Final_02232018.pdf" class="info" target="_blank">Addendum to the February 2018 Software Release</a> - this addendum
addresses the layout/record length of the COB files.
                <BR><br> 

Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - Phase III Version 3 MAO-004 Reports Distribution Update ****</span>											
                <br><br>					
Please see below communication regarding the distribution of the MAO-004 reports:
<br><br>
Please see the attached memorandum entitled <a href="/mss/IFOXDocs/Phase_3v3_MAO_004_Distribution_Update_Final_02222018.pdf" class="info" target="_blank">"Phase III Version 3 MAO-004 Reports Distribution Update"</a>, from Jennifer Harlow, 
Deputy Director, Medicare Plan Payment group. This memo follows up on the December 20th, 2017 HPMS memo titled, "Phase III Version 3 MAO-004 Report Release Date and
Announcement Regarding Final Encounter Data Deadlines for Payment Years 2016 and 2017", to provide more information on the distribution of the Phase III
Version 3 MAO-004 reports. 
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>

<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - 2017/2018 Holiday Schedule ****</span>											
                <br><br>					
Wipro would like to thank you for your partnership and support throughout the year and wish you the very best during this Holiday Season.
<br><br>
We would like to inform you of our Holiday support and processing schedule. Our offices will be closed on Monday, December 25th, 2017 and Monday, January 1st, 2018 due to the observation
of the Christmas and New Year Holidays. All transactions will be submitted to CMS <b>as normal - at the regular scheduled times</b>. Should any issues arise, please send an email to our Helpdesk at <a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>.
We will respond to your inquiries on the next business day. 
                <BR><br> 
Thank you and Happy Holidays!
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img 

src="/mss/jsp/Recon/images/news_icon.gif" width="14" 

height="16"></td>
       <td align="left"><span class="NewsHeading">**** Wipro Notice - 2017 End-of-Year Processing and other related information ****</span>
       <br><br>
	   Attached please find the <a href="/mss/IFOXDocs/EOY_2017_Memo.pdf" class="info" target="_blank">End-of-Year guidance</a> and <a href="/mss/IFOXDocs/MAPD_POVER_Process.pdf" class="info" target="_blank">MAPD POVER Process</a> from CMS. Please refer to the guidance for additional information regarding End-of-Year processing. Based on the guidance, please refer to the table below for important CMS key dates:
	   <br><br>
	  
				<BR>
				<TABLE border="1">
					<TBODY>
						<TR>
							

<TD><center><b>Date</b></center></TD>
							

<TD><center><b>Item</b></center></TD>
						</TR>
						<TR>
							


<TD>October 03, 2017</TD>
							

<TD>*Begin submitting 2018 enrollment effective dates
					
						<br><br>
							

						*Plans approved for renewal or crosswalk exceptions by CMS that 

require plan-submitted EOY activity must submit MARx transactions. 

(See section 2.B of the attachment) </TD>
						</TR>
						<TR>
<TD>October 06, 2017</TD>
							

<TD>October Plan Data Due Date</TD>
						</TR>
						<TR>
							
							

<TD>October 14, 2017</TD>
							

<TD>Reassignment runs.</TD>
						</TR>
						<TR>
							

<TD>October 15, 2017</TD>
							

<TD>Annual Enrollment Period (AEP) begins</TD>
						</TR>
						<TR>
							

<TD>October 18, 2017</TD>
							

<TD>Plans will receive special Transaction Reply Reports (TRRs) and 

other reports containing reassignment activity. Reassignment letters 

sent to beneficiaries.</TD>
						</TR>
						<TR>
							

<TD>November 03 and 04, 2017</TD>
							

<TD>CMS-generated rollover processing</TD>
						</TR>
						<TR>
<TD>November 10, 2017</TD>
							

<TD>November Plan Data Due Date</TD>
						</TR>
					                <TR>
							
							

<TD>November 13, 2017</TD>


<TD>Transactions 75 and 78 with an effective date of 01/01/2018 will not process if submitted before this date</TD>
                        </TR>
                        <TR>


<TD>December 07, 2017</TD>
							

<TD>AEP ends</TD>
						</TR>
						<TR>
<TD>December 08, 2017</TD>
							

<TD>December Plan Data Due Date</TD>
						</TR>
                                                                                                <TR>
							
							

<TD>January 05, 2018</TD>
							

<TD>January Plan Data Due Date </TD>
						</TR>
					</TBODY>
				</TABLE>
				<br>
	            To assist our clients with their EOY enrollment 

processing, Wipro/Infocrossing will be performing the followings:
	   
	   <br><br>
	   1. <u>All NON_AEP transactions with January 01, 2018 

effective date</u> that will be uploaded to Wipro prior to October 03, 2017, will be held and will be released to CMS for processing on <b>October 03, 2017</b>.
	   <br><br>	   
	  2. <u><b>All CMS approved plan-submitted roll-over or service area reduction disenrollment transactions</b></u> that will be uploaded to Wipro up to <i><b>October 03, 2017</b></i>
will be released to CMS for processing on <i><b>October 03, 2017. Please have your transactions uploaded to Wipro <font color=red>no later than 12:00 Noon PST</font> on October 03, 2017. CMS requires these files to be transmitted to the MARx system only on this day, no later than 5:00 P.M. EST.</b></i>
<font color = "red"><i> If you are planning to submit the rollover 
transactions, please contact Wipro as soon as possible to provide the necessary information so that Wipro can obtain an approval CMS request ID from MARx.
This approved request ID</i> must be used in your rollover file submission -  <i>CMS might take several days to provide
the necessary Rollover Request ID approval. Plans must take this delay into account in order to be ready to submit your data exactly (and only) on <b><u>October 3, 2017.</u></b></i></font> 
	   <br><br>
	   3. <u>All AEP transactions with January 1, 2018 effective 

date</u> that will be uploaded to Wipro will be held and will be 

released to CMS for processing on <b>October 15, 2017</b> right 

after midnight EDT.
	   <br><br>	   
	  4. <u>All 75 and 78 transactions with a January 1, 2018

effective date</u> that will be uploaded to Wipro up to <i><b>November 13, 2017</b></i> will be released to CMS for processing on <b>November 13, 2017</b>.
	   <br><br>	   
	   <font color = "red"><b>****** Special processing for CMS Approved Roll-Over or Service Area Reduction transactions:</b> 

</font>
	   <br><br>
	 
<ul>
     <li>Please contact the Wipro Helpdesk if you have rollover or 

service area reduction disenrollment transactions to submit. Please 

note that these transactions cannot be mixed with regular MARx 

submissions and must be handled seperately. The following link on 

the Wipro/Infocrossing web portal will be made available for you to 

upload these transactions. Please contact our Helpdesk if you do not 

have these links:</ul></li>
<br>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style = "background-color: yellow"><b>CMS Preapproved Rollover Transactions</b></span>
<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style = "background-color: yellow"><b>Upload Data</b></span>


	   <br><br>	   
<ul>            
     <li><b>Please note that Wipro will not be able to accommodate this process through <u>manual input or FTP upload</u>. These transactions can only be processed via a batch file submission on the 

web portal <i>by using the "CMS Preapproved Rollover Transactions" link</i>.</b></li>
                   <br><br>
                   <li><b>Please send us any new contract plans and/or PBP's for 2018 if you haven't done so.</b></li>
</ul> 	   
                   <br><br>
Please forward this announcement to other areas within your organization as you deem necesary. 
<br><br>
Thank you.
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>	
 
			</TR>
		</table>
  </td>
</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - Additional Guidelines Regarding the Plan-Submitted Rollovers Procedure - <b>REMINDER</b>****</span>											
                <br><br>					
Good morning, Wipro would like to remind our clients on the rollover - <font color = "red">POVER file</font> processing procedure. If you are planning to submit the rollover 
transactions, please contact Wipro as soon as possible to provide the necessary information so that Wipro can obtain an approval CMS request ID from MARx.
This approved request ID must be used in your rollover file submission. A batch file request must be submitted on the CMS MARx system and CMS might take several days to provide
the necessary Rollover Request ID approval. Plans must take this delay into account in order to be ready to submit your data exactly (and only) on <b><u>October 3, 2017.</u></b> Please 
reach out to our helpdesk if you have any questions/concerns regarding the Rollover process. 
                <BR><br> 
<a href="/mss/IFOXDocs/MAPD_POVER_Process.pdf" class="info" target="_blank">MAPD POVER Process</a>      
<br><br>
<a href="/mss/IFOXDocs/EOY_2017_Memo.pdf" class="info" target="_blank">EOY 2017 Memo</a>
<br><br>
Thank you
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - Additional Guidelines Regarding the Plan-submitted Rollovers Procedure ****</span>											
                <br><br>					
Wipro would like to inform our clients of the additional guidelines regarding the Plan-submitted Rollovers process. Please review and follow these steps to ensure a smooth transition. 
<br><br>
&nbsp;&nbsp;&nbsp;1. Plans that have been approved for renewal or crosswalk exceptions by CMS and need to submit rollover transactions must ensure to follow the guidance provided in the latest CMS announcement.
<br><br>
&nbsp;&nbsp;&nbsp;2. Please make sure to submit the rollover files in the newest format as detailed by CMS in the November 2016 software announcement as well as in the 
<br><br>
&nbsp;&nbsp;&nbsp;3. While the CMS EOY guidance is usually published towards the end of September, and the rollover processing deadline by CMS is sometime during the first week of October, Plans need to contact Wipro with their submission needs prior to the submission window to ensure all necessary steps are in place.
<br><br>
&nbsp;&nbsp;&nbsp;4. Please provide the CMS account representatives plenty of time to approve your requests prior to submitssion window (usually first week of October). As soon as the requests are received and approved by CMS, Plans must contact Wipro to provide all details as outlined in the CMS <a href="/mss/IFOXDocs/MAPD_POVER_Process.pdf" class="info" target="_blank">POVER Special Batch File Approval Request document</a>.
Once the POVER special file request is approved and a valid Request File ID is obtained, Plans can proceed with submitting their file to Wipro for processing, ensuring that the POVER request ID is present in the header record and that all the transaction details match exactly with what were entered in HPMS and approved by CMS. 
<br><br>
Please reach out to the Wipro Helpdesk if you have any questions/concers regarding the Rollover process.
<br><br>
Thank you
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - 2017 Labor Day Holiday Schedule****</span>											
                <br><br>					
Wipro offices will be closed on Monday, September 4th, 2017 in observance of the Labor Day Holiday. All transactions will be submitted to CMS <b>as normal - at the regular scheduled times</b>. Should any issues arise, please send an email to the Wipro Helpdesk at <a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>. 
                <BR><br> 
Thank you and have a safe Holiday!
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - <font color = "red"><b>Independence Day Holiday - July 4th, 2017</b></font>****</span>											
                <br><br>					
Wipro offices will be closed on Tuesday, July 4th, 2017 in observance of the Independence Day Holiday. All transactions will be submitted to CMS <b>as normal - at the regular scheduled times</b>. Should any issues arise, please send an email to the Wipro Helpdesk at <a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>. 
                <BR><br> 
Thank you and have a safe Holiday!
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - Version 17.12 - Interface to MSS Document****</span>											
                <br><br>					
Attached please find the latest version of the <a href="/mss/IFOXDocs/Interface_to_MSS_17_12.pdf" class="info" target="_blank">Interface to MSS</a> document (version 17.12). Please refer to the description in <font color = "red"><b>red font</b></font> on page 3 
under section - <b>06/02/2017 - Version 17.12</b> of the document for information regarding the Social Security Number Removal Initiative <b>(SSNRI)</b> project.
<br><br>
Please reach out to your assigned Business Analyst/Project Manager and/or the Helpdesk team (contact info listed below) for questions/clarification.
                <BR><br> 
Thank you
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - Memorial Day Holiday - May 29th, 2017****</span>											
                <br><br>					
Wipro offices will be closed on Monday, May 29th, 2017 in observance of the Memorial Day Holiday. All transactions will be submitted to CMS <b>as normal - at the regular scheduled times</b>. Should any issues arise, please send an email to the Wipro Helpdesk at <a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>. 
                <BR><br> 
Thank you and have a safe Holiday!
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - Implementation of the May Software Release ****</span>											
                <br><br>					
This notice is to inform our clients that the May 2017 Software Release will be implemented on the May CPM cutoff date - 05/12/2017 starting at 8:00 PM PST. Attached 
please find the following documents which contain details of the changes:
<br><br>
&nbsp;&nbsp;&nbsp;1. CMS <a href="/mss/IFOXDocs/05_2017_Detailed_Release_Memo_04_13_2017.pdf" class="info" target="_blank">Announcement of the May 2017 Software Release.</a>
<br><br>
&nbsp;&nbsp;&nbsp;2. Wipro <a href="/mss/IFOXDocs/Wipro_Impact_Analysis_May_2017.pdf" class="info" target="_blank">Impact Analysis</a> document.
<br><br>
Please reach out to your designated Account Managers, Business Analyst and/or the Wipro Helpdesk if you have any questions regarding the changes.
<br><br>
Thank you
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - Presidents' Day Holiday - 02/20/2017****</span>											
                <br><br>					
Wipro offices will be closed on Monday, February 20th, 2017 in observance of the Presidents' Day holiday. All transactions will be submitted to CMS <b>as normal - at the regular scheduled times</b>. Should any issues arise, please send an email to the Wipro Helpdesk at <a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>. 
                <BR><br> 
Thank you and have a safe Holiday!
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - Implementation of the February Software Release ****</span>											
                <br><br>					
This notice is to inform our clients that the February 2017 Software Release will be implemented on the February CPM cutoff date which will be this Friday 02/03/17, starting at 8:00 PM PST. The website <a href="https://www.medicare-solution.com/mss/home/Index.jsp" target= "blank"><Font = "2">www.medicare-solution.com</Font></a> will be unavailable from 8:00 PM PST to 9:00 PM PST. Please find below the following documents which contain details of the changes:

                <BR><br> 
&nbsp;&nbsp;&nbsp;1. CMS <a href="/mss/IFOXDocs/Announcement_of_the_February_2017_Software_Release_12_20_16.pdf" class="info" target="_blank">Announcement of the February 2017 Software Release.</a>
<br><br>
&nbsp;&nbsp;&nbsp;2. Wipro <a href="/mss/IFOXDocs/Interface_to_MSS_17_11.pdf" class="info" target="_blank">Interface to MSS</a> - version 17.11 - Changes are outlined on page 3 in red font.
<br><br>
&nbsp;&nbsp;&nbsp;3. Wipro <a href="/mss/IFOXDocs/Wipro_Impact_Analysis_Feb_2017_Software_Release.pdf" class="info" target="_blank">Impact Analysis</a> document.
<br><br>
Please reach out to your designated Account Managers and/or Business Analyst if you have any questions regarding the changes.
Thank you
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - Interface to MSS document version 17.11****</span>											
                <br><br>					
Please find attached the newest version of the <a href="/mss/IFOXDocs/Interface_to_MSS_17_11.pdf" class="info" target="_blank">Interface to MSS</a> document (version 17.11). Please refer to page 3 of the document 
for a summary of the changes. Please reach out to your designated Account Managers and/or Business Analysts if you have any questions regarding the changes.
                <BR><br> 
Thank you
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - 2016/2017 Holiday Schedule****</span>											
                <br><br>					
Wipro would like to thank you for your partnership and support throughout the year and wish you the very best during this Holiday season.
<br><br>
We would like to inform you of our Holiday support schedule. Our offices will be closed on Monday, December 26th, 2016 and January 2nd, 2017 due to the observance of the Christmas and New Years Holidays. All transactions
will be submitted to CMS <b>as normal, at the regular scheduled times.</b> Should any issues arise during these two days, please send an email to our Helpdesk at <a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>.
We will respond to your inquiries on the next business day. 
<BR><br> 
Thank you and Happy Holidays!
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - November CMS Software Release 2016 - Impact Analysis****</span>											
                <br><br>					
Attached please find the <a href="/mss/IFOXDocs/Wipro_Impact_Analysis_Nov_2016_Release.pdf" class="info" target="_blank">Wipro Impact Analysis</a> document.
                <BR><br> 
Thank you
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - New Version of the Interface to MSS document due November CMD Software Release 2016****</span>											
                <br><br>					
The <a href="/mss/IFOXDocs/Interface_to_MSS_17_10.pdf" class="info" target="_blank">Interface to MSS</a> document has been updated with version 17.10 to reflect the CMS November 2016 Software changes as documented in the final <a href="/mss/IFOXDocs/November_2016_Detail_Software_Release_Memo.pdf" class="info" target="_blank">CMS HPMS</a> notice, dated September 09, 2016.
 <br><br>
The November software changes will be implemented on the November CPM cutoff date of Friday, November 11, 2016.
<b><i>The Wipro MBD eligibility updates, however will not occur until after CMS provides an updated MBD
eligibility file which is expected to occur on Tuesday, November 15, 2016.</i></b>
<br><br>
Version 17.10 of the Interface to MSS document addresses the addition of the new fields pertaining to the 
beneficiaries' prior historical enrollments as well as teh addition of the Enrollment Source code for the 
beneficiaries' current enrollment.
<br><br>
Summary of changes in version 17.10:
<br><br>
&nbsp;&nbsp;&nbsp;1. Section 1 (Medicare Eligibility Inquiry) has been updated to include the new fields on the 
batch eligibility response file. <i>Page 19</i>.
<br><br>
&nbsp;&nbsp;&nbsp;2. The web service layout has changed to accomodate the new plan enrollment fields. <i>Section 3 - page 60</i>.
<br><br>
&nbsp;&nbsp;&nbsp;3. The Eligibility+ response file has been modified to include the new plan enrollment fields. <i>Section 5 - page 72</i>.
<br><br>
&nbsp;&nbsp;&nbsp;4. These MBD field additions will also be reflected on the Eligibility tab of the Wipro websites.
<br><br>
Thank you
<br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img 

src="/mss/jsp/Recon/images/news_icon.gif" width="14" 

height="16"></td>
       <td align="left"><span class="NewsHeading">**** Wipro Notice - 2016 End-of-Year Processing and other related information ****</span>
       <br><br>
	   Attached please find the <a href="/mss/IFOXDocs/EOY_2016_Memo.pdf" class="info" target="_blank">End-of-Year guidance</a> from CMS. Please refer to the guidance for additional information regarding End-of-Year processing. Based on the guidance, please refer to the table below for important CMS key dates:
	   <br><br>
	  
				<BR>
				<TABLE border="1">
					<TBODY>
						<TR>
							

<TD><center><b>Date</b></center></TD>
							

<TD><center><b>Item</b></center></TD>
						</TR>
						<TR>
							


<TD>October 03, 2016</TD>
							

<TD>Begin submitting 2017 enrollment effective dates</TD>
						</TR>
						<TR>
							

<TD>October 03, 2016, no later than 5 PM EDT</TD>
							

<TD>Plans approved for renewal or crosswalk exceptions by CMS that 

require plan-submitted EOY activity must submit MARx transactions. 

(See section 2.B of the attachment) </TD>
						</TR>
						<TR>
<TD>October 07, 2016</TD>
							

<TD>October Plan Data Due Date</TD>
						</TR>
						<TR>
							
							

<TD>October 10, 2016</TD>
							

<TD>Reassignment runs.</TD>
						</TR>
						<TR>
							

<TD>October 15, 2016</TD>
							

<TD>Annual Enrollment Period (AEP) begins</TD>
						</TR>
						<TR>
							

<TD>Mid-October, 2016</TD>
							

<TD>Plans will receive special Transaction Reply Reports (TRRs) and 

other reports containing reassignment activity. Reassignment letters 

sent to beneficiaries.</TD>
						</TR>
						<TR>
							

<TD>November 03 and 04, 2016</TD>
							

<TD>CMS-generated rollover processing</TD>
						</TR>
						<TR>
<TD>November 11, 2016</TD>
							

<TD>November Plan Data Due Date</TD>
						</TR>
					                <TR>
							
							

<TD>November 14, 2016</TD>


<TD>Transactions 75 and 78 with an effective date of 01/01/2017 will not process if submitted before this date</TD>
                        </TR>
                        <TR>


<TD>December 07, 2015</TD>
							

<TD>AEP ends</TD>
						</TR>
						<TR>
<TD>December 09, 2016</TD>
							

<TD>December Plan Data Due Date</TD>
						</TR>
                                                                                                <TR>
							
							

<TD>January 06, 2017</TD>
							

<TD>January Plan Data Due Date </TD>
						</TR>
					</TBODY>
				</TABLE>
				<br>
	            To assist our clients with their EOY enrollment 

processing, Wipro/Infocrossing will be performing the followings:
	   
	   <br><br>
	   1. <u>All NON_AEP transactions with January 01, 2017 

effective date</u> that have been uploaded to Wipro prior to October 03, 2016, will be held and will be released to CMS for processing on <b>October 03, 2016</b>.
	   <br><br>	   
	  2. <u><b>All CMS approved plan-submitted roll-over or service area reduction disenrollment transactions</b></u> that will be uploaded to Wipro up to <i><b>October 03, 2016</b></i>
will be released to CMS for processing on <i><b>October 03, 2016. Please have your transactions uploaded to Wipro <font color=red>no later than 12:00 Noon PST</font> on October 03, 2016. CMS requires these files to be transmitted to the MARx system only on this day.</b></i>
	   <br><br>
	   3. <u>All AEP transactions with January 1, 2017 effective 

date</u> that have been uploaded to Wipro will be held and will be 

released to CMS for processing on <b>October 15, 2016</b> right 

after midnight EDT.
	   <br><br>	   
	  4. <u>All 75 and 78 transactions with a January 1, 2017

effective date</u> that will be uploaded to Wipro up to <i><b>November 14, 2016</b></i> will be released to CMS for processing on <b>November 14, 2016</b>.
	   <br><br>	   
	   <font color = "red"><b>****** Special processing for CMS Approved Roll-Over or Service Area Reduction transactions:</b> 

</font>
	   <br><br>
	 
<ul>
     <li>Please contact the Wipro Helpdesk if you have rollover or 

service area reduction disenrollment transactions to submit. Please 

note that these transactions cannot be mixed with regular MARx 

submissions and must be handled seperately. The following link on 

the Wipro/Infocrossing web portal will be made available for you to 

upload these transactions. Please contact our Helpdesk if you do not 

have these links:</ul></li>
<br>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style = "background-color: yellow"><b>CMS Preapproved Rollover Transactions</b></span>
<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style = "background-color: yellow"><b>Upload Data</b></span>


	   <br><br>	   
<ul>            
     <li><b>Please note that Wipro will not be able to accommodate this process through <u>manual input or FTP upload</u>. These transactions can only be processed via a batch file submission on the 

web portal.</b></li>
                   <br><br>
                   <li><b>Please send us any new contract plans and/or PBP's for 2017 if you haven't done so.</b></li>
</ul> 	   
                   <br><br>
Please forward this announcement to other areas within your organization as you deem necesary. 
<br><br>
Thank you.
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>	
 
			</TR>
		</table>
  </td>
</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - Labor Day Holiday - 09/05/2016****</span>											
                <br><br>					
Wipro offices will be closed on Monday, September 5th in observance of the Labor Day holiday. All transactions will be submitted to <b>as normal - at the regular scheduled times. <i>Should any issues arise, please send an email to the Wipro Helpdesk at <a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>.</i></b>	 
                <BR><br> 
Thank you and have a safe Holiday!
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - August CMS Software Release 2016 - REMINDER****</span>											
                <br><br>					
<B><I>This is a reminder that the August software changes will be implemented on the August 2016 Plan Data Due Date (Friday, August 12th, 2016 right after 8:00 PM EST. Attached please find all documents related to the August software changes:</I></B>
<br><br>
<a href="/mss/IFOXDocs/Announcement_of_the_August_2016_Software_Release.pdf" class="info" target="_blank">Announcement of the August 2016 Software Release</a>
<br><br>
<a href="/mss/IFOXDocs/Wipro_Impact_Analysis_August_2016_Release.pdf" class="info" target="_blank">Wipro Impact Analysis August 2016 Release</a>
<br><br>
<a href="/mss/IFOXDocs/Interface_to_MSS_17_09.pdf" class="info" target="_blank">Interface to MSS</a>
                <BR><br> 
Thank you.
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>				
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">** Wipro Notice - Interface to MSS document Version 17.09 - August CMS Software Release 2016 **</span>
													
				<br><br>
					The <a href="/mss/IFOXDocs/Interface_to_MSS_17_09.pdf" class="info" target="_blank">Interface to MSS</a> document has been updated with version 17.09 to reflect the CMS May 2016 Sofware changes as documented in the final <a href="/mss/IFOXDocs/Announcement_of_the_August_2016_Software_Release.pdf" class="info" target="_blank">CMS HMPS notice</a>, dated June 29th. The following Wipro edit changes will be implemented on the August 2016 Plan Data Due Date (Friday, August 12th, 2016) right after 8:00 PM EST:
<br><br>
Highlights of changes are listed below as well as on page 3 of the attached Interface to MSS:
<br><br>
&nbsp;&nbsp;1. New transaction type "91", Reporting IC Model beneficiary participants:
<UL>
<li>Section 2.4 has been added to reflect this new MARx transaction type. <i>Page 41.</i></li>
<LI>Section 2.5 has been updated to reflect the Transaction code 91 fields in the transaction response file layout. <i>Page 45.</i></LI>
<LI>Section 2.6 includes:</LI>
<UL>
<LI>New batch processing error codes. <i>Page 50</i></LI>
<LI>Batch error codes "80" and "97" have been updated. <i>Page 49.</i></LI>
</UL></ul>
<ul>
<LI>Section 2.7 has been updated to include the new Transaction Code 91 data fields. <i>Page 57</i></LI>
</ul>
<br>
&nbsp;&nbsp;&nbsp;<b>Note:</b><i> As we learn more from CMS about the new IC Model Beneficiary Participation transaction, &nbsp;&nbsp;&nbsp;additional batch processing edits and error code reflections might be implemented for the new transaction &nbsp;&nbsp;&nbsp;code "91".</i>
<br><br>
&nbsp;&nbsp;2. Changes to the Annual Roll-Over process:
<UL>
<LI>A new election type of "C" and an Enrollment Source code value of "N" must be used for plan submitted roll-over enrollment transactions.</LI>
<LI>Two new data value fields have been added on a roll-over transaction: "Rolled from Contract" and "Rolled from PBP".</LI>
<LI>Additional guidance will be provided as necessary when the CMS 2016 End-of-Year guidance is published.</LI>
</UL>
<br>
&nbsp;&nbsp;3. The CMS transmission data file layout has changed to accomodate all the new data fields. <i> Section 4.4 - &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Page 63.</i>
<br><br>
&nbsp;&nbsp;4. The enrollment reconciliation extract file layout has changed to accomodate the new data fields. <i> Section &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;6 - Page 63.</i>
<br><br>
<b>Reminder on the Roll-Over Submission Process:</b>
<ul>
<li>Please contact the Wipro Helpdesk if you have roll-over transactions to submit. The following link under the File Transfer menu will be made available to Plans for uploading the roll-over transactions:</li>
</ul>
<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style = "background-color: yellow"><b>CMS Preapproved Rollover Transactions</b></span>
<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style = "background-color: yellow"><b>Upload Data</b></span>
<br><br>
&nbsp;&nbsp;&nbsp;<b><i>Please note:</i></b> Batch error code "22" will be issued for any roll-over transaction that is not submitted from &nbsp;&nbsp;&nbsp;this link.
<br><br>
<ul>
<LI><b>Please note that Wipro will not be able to accomodate this process through <u>manual input or FTP upload.</u></B></LI>
</ul>
<br><br>
Thank you.
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>

				<br><br>
	   				
	   				
				</td>
			</tr>
		</table>
		</td>
	</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - Independence Day Holiday - 07/04/2016****</span>											
                <br><br>					
Wipro offices will be closed on Monday, July 4th in observance of the Independence Day holiday. All transactions will be submitted to <b>as normal - at the regular scheduled times. <i>Should any issues arise, please send an email to the Wipro Helpdesk at <a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>.</i></b>	 
                <BR><br> 
Thank you.
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - UNSCHEDULED MAINTENANCE - June 11, 2016 - CANCELLED****</span>											
                <br><br>					
This notice is to inform our clients that the unscheduled maintenance which was scheduled to take place on 06/11/2016 has been cancelled.
                <BR><br> 
Thank you.
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - UNSCHEDULED MAINTENANCE - June 11, 2016 ****</span>											
                <br><br>					
This notice is to inform our clients that Wipro will be performing an unscheduled maintenance to our systems starting from <b>6:30 PM PST - 10:30 PM PST</b> on 06/11/2016. <b>The following website</b> will be <u><i>unavailable</i></u> during this time:
 
                <br><br>
&nbsp;&nbsp;&nbsp;<a href="https://www.medicare-solution.com/mss/home/Index.jsp" target= "blank"><Font = "2">www.medicare-solution.com</Font></a>
                <BR><br> 
We apologize for the inconvenience and thank you for your patience.
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - CMS Memo Regarding the Advance Announcement of the August Software Release 2016 ****</span>											
                <br><br>					
<B>Please see CMS memo below:</B>
                <br><br>
<I>"Please see the attached memorandum from Cheri Rice, Director, Medicare Plan Payment Group and Cathy Carter, Director, Enterprise Systems Solutions Group. The memo is entitled "<a href="/mss/IFOXDocs/Advance_Announcement_of_the_August_2016_Software_Release_6116.pdf" class="info" target="_blank">Advance Announcement of the August 2016 Software Release</a>", and it provides information regarding the Medicare Advantage Prescription Drug software changes, which is scheduled for implementation in August 2016."</I>

                <BR><br> 
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>				
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - CMS Memo: 2016 Long Term Institutionalized Resident Report ****</span>											
                <br><br>					
<b>Please review the attached <a href="/mss/IFOXDocs/Memo_LTI_Resident_Report_June_2016_V2.pdf" class="info" target="_blank">CMS memo</a> as well as the below CMS memo which was issued on 06/01/2016:</b>
                <br><br>
<i>"The next 2016 Long-Term Institutionalized (LTI) Resident Report will be distributed to plans on June 1, 2016. Your organization will only receive an LTI Resident Report if you have LTI enrollees. This report will be distributed to each Part D sponsor through the secure CMS Enterprise File Transfer (EFT) process. The report can be retrieved using your existing Gentran or Connect:Direct service. If your organization utilizes the services of a 3rd party vendor for Gentran or Connect:Direct access, please notify them that you may be receiving this report.</i>
                <BR><br> 
<i>If you have any questions concerning this memorandum, please send an email to <a class="info" href= "mailto:PartDMetrics@cms.hhs.gov">PartDMetrics@cms.hhs.gov</a> Include "LTI Resident Report" in the subject line.</i>
<br><br>
<i>For any technical inquiries related to Gentran or Connect:Direct, please contact the MMA Help Desk at 1-800-927-8069 or <a class="info" href= "mailto:mapdhelp@cms.hhs.gov">mapdhelp@cms.hhs.gov</a>."</i>
<br><br>
<br><br>
<b>The LTI report, if there is one issued for your organization, can be downloaded from our website under the File Transfer menu:</b>
<br><br>
 &nbsp;<font color = "blue">Plan Level Reports</font>
<br><br> 
&nbsp; &nbsp; &nbsp;<u>Data Format</u>
<br><br>
 &nbsp; &nbsp; &nbsp;<u>Report Format</u>
<br><br>
 &nbsp; &nbsp; &nbsp;<u>Yearly MOR</u>
<br><br>
 &nbsp; &nbsp; &nbsp;<font color = "blue"><u>Annual and Special Plan Reports</u></font>
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>				
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - Memorial Day Holiday 05/30/2016 ****</span>											
                <br><br>					
Wipro offices will be closed on Monday, May 30th, 2016 in observance of the Memorial Day Holiday. All transactions will be submitted to CMS <b>as normal - at the regularly scheduled times. </b> Should any issues arise, please contact the Wipro Helpdesk at between the hours of 6:00 AM - 2:00 PM PST. 
                <br><br>
Thank you and have a safe Holiday!
                <BR><br> 
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Interface to MSS document version 17.08 - May CMS Software Changes****</span>											
                <br><br>					
The <a href="/mss/IFOXDocs/Interface_to_MSS_17_08.pdf" class="info" target="_blank">Interface to MSS</a> document has been updated with version 17.08 to reflect the CMS May 2016 Software changes as documented in the final <a href="/mss/IFOXDocs/Final_Draft_May_2016_Detail_Release_Memo_02192016.pdf" class="info" target="_blank">CMS HPMS notice</a>, dated February 29, 2016. Please also refer to the <a href="/mss/IFOXDocs/Wipro_Impact_Analysis_May_2016_Release_1.pdf" class="info" target="_blank">Wipro Impact Analysis</a> document for additional details. The following Wipro edit change will be implemented on the May 2016 Plan Data Due Date (Friday, May 13th, 2016) after 8: PM EST:
 <br><br>
** The current Creditable Coverage Flag values of "R" and "U" on a "61" (enrollment transaction) or "73" (number of uncovered months change transaction) will no longer be valid. Please refer to page 30 of the <a href="/mss/IFOXDocs/Interface_to_MSS_17_08.pdf" class="info" target="_blank">Interface to MSS</a> document for the valid values of this field.
<br><br>
Please contact the Wipro HelpDesk if you have any questions/concerns
<br><br>
Thank you
<br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>				
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Introducing An Enhancement Option To The Existing MBD Inquiry Process****</span>
											
				<br><br>
Wipro is please to announce an enhancement option to the existing MBD process. Currently, when a plan sends a batch MBD eligibility request file to Wipro for processing, any beneficiary records that cannot be matched against the Wipro database would be returned as unmatched, with the HICN Found/Not found field set to "N". The enhancement option will trigger an automatic eligibility request to be sent to CMS for those instances that a beneficiary match can't be obtained on the Wipro MBD eligibility database.
<br><br>
This new function is described below in detail:
<br><br>
<ol>
<li>All HIC numbers that cannot be matched against the Wipro eligibility database wil be returned on the eligibility response file with the value of "B" (BEQ Request initiated) in the HICN Found/Not Found field in position 26 of the response file. Section 1, page 12 of the <a href="/mss/IFOXDocs/Interface_to_MSS_17_07.pdf" class="info" target="_blank">attached document</a> has been changed to reflect this new value.</li>
<li>Wipro will keep track of all BEQ pending requests and send these requests to CMS three times daily at 08:00 AM, 12:00 Noon and 04:00 PST. At the designated times and as needed, any pending unmatched HICN requests will be written into a CMS formatted BEQ file and sent to the CMS for processing.</li>
<li>Once the BEQ response files are received from CMS, Wipro will automatically reformat the files into the current MBD response format and make the files available on the Wipro website and on your designated FTP file folder, If FTP is the preferred location, the naming convention of htis response file is "MBDE.REPSONSE.Dyymmdd.Thhmmss".</li>
<li>A new section named "Exception BEQ" on the website under "File Transfer" menu will contain a new link - "BEQ Response File". this link can be used to review the history of all BEQ exception file submissions to CMS.</li>
<li>The "sequence number" field which is currently returned on MBD response fiels will also be kept throughout the process so that Plans can use it together with the HICN to reconcile all outstanding MBD requests against the original input file submissions.</li>
</ol>
<br>
To sign up for this enhancement option and/or if you have any questions, please send an email to the following email address: <a class="info" href= "mailto:loan.tran@wipro.com">Loan.Tran@wipro.com</a>
<br><br>
Thank you,
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>
				<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>		
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - HEDIS Files Submission ****</span>											
                <br><br>					
Wipro would like to remind you of the following key dates regarding the HEDIS submission for 2015 measurement year:
                <BR>
<Ul>
<li><b>04/09 - 05/04</b>  Test files submission - CMS will not accept any test files prior to 04/09</li>
<li><b>05/13 - 06/15</b>  Production files submission</li>
</Ul>
<U>Important Notes:</U>
<UL>
<li>CMS will not accept any production files after midnight EDT on 06/15.</li>
<LI>Record length of File 1 has changed from 322 to 878 bytes.</LI>
</UL>
For more information, please refer to the attached <a href="/mss/IFOXDocs/HPMS_Memo_2016_HEDIS.pdf" class="info" target="_blank">CMS MEMO</a>, as well as the following website:
<br><br>
<a href="https://www.cms.gov/Research-Statistics-Data-and-Systems/Statistics-Trends-and-Reports/MCRAdvPartDEnrolData/index.html" target="blank"><FONT size="2">https://www.cms.gov/Research-Statistics-Data-and-Systems/Statistics-Trends-and-Reports/MCRAdvPartDEnrolData/index.html</FONT></a> 
<br><br>
To upload your files, please log on to website and locate the following links under the File Transfer tab. There is no naming convention required. Please contact our Helpdesk if the below links are not available under your account.
<br><br>
<font color = "blue"><b>Enrollment HEDIS TEST</b></font>
<br>
&nbsp;&nbsp;&nbsp;Upload Data (File1)
<BR>
&nbsp;&nbsp;&nbsp;HEDIS Data Receipt (File1)
<br>
&nbsp;&nbsp;&nbsp;Upload Data (File2 - PCR)
<br>
&nbsp;&nbsp;&nbsp;HEDIS Data Receipt (File2 - PCR)
<br><br>
<font color = "blue"><b>Enrollment HEDIS PRODUCTION</b></font>
<br>
&nbsp;&nbsp;&nbsp;Upload Data (File1)
<br>
&nbsp;&nbsp;&nbsp;HEDIS Data Receipt (File1)
<br>
&nbsp;&nbsp;&nbsp;Upload Data (File2 - PCR)
<br>
&nbsp;&nbsp;&nbsp;HEDIS Data Receipt (File2 - PCR)
<br><br>
Thank you
<br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>			
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - February CMS Software Changes Implementation 02/15/2016 - Unscheduled Maintenance Window ****</span>											
                <br><br>					
This notice is to inform our clients that the following website will be unavailable on <b>02/15/2016 from 3:00 PM PST - 4:00 PM PST</b> due to the implementation of the CMS February Software Changes:
<br><br>
&nbsp;&nbsp;&nbsp;<a href="https://www.medicare-solution.com/mss/home/Index.jsp" target= "blank">www.medicare-solution.com</a>
<br><br>
Attached in this notification are the supporting documents related to this implementation:
<br><br>
<Ul>
<li>CMS Final Draft February 2016 <a href="/mss/IFOXDocs/Final_Draft_February_2016_Detail_Release_Memo.pdf" class="info" target="_blank">Detail Release Memo</a></li>
<li>Wipro <a href="/mss/IFOXDocs/Wipro_Impact_Analysis_February_2016_Release_Final.pdf" class="info" target="_blank"> Impact Analysis</a> February 2016 Release Final</li>
<li>Wipro <a href="/mss/IFOXDocs/Interface_to_MSS_17_06.pdf" class="info" target="_blank">Interface to MSS</a> document - version 17.06</li>
<li>ProdEligibilityService WSDL - production wsdl file for our <U>web service clients only.</U>
</Ul>
<br>
<b>The Wipro offices will be closed on Monday 02/15 in observance of the President's day, however, our Helpdesk will be extending it's coverage to support the implementation from 5:00 AM PST - 7:00 PM PST.</b>
<br><br>

Thank you
<br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>				
				<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
<td align="left"><span class="NewsHeading">**** Wipro Notice - Presidents' Day Holiday 02/15/2016 ****</span>											
                <br><br>					
Wipro offices will be closed on Monday, February 15th, 2016 in observance of the Presidents' Day holiday. All transactions will be submitted to CMS <b>as normal - at the regularly scheduled times. </b> Should any issues arise, please send an email to the Wipro helpdesk at <a class= "info" href="mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>.   
                <br><br>
Thank you and have a safe Holiday!
                <BR><br> 
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - February CMS Software Changes - FINAL REMINDER ****</span>											
                <br><br>					
This notice serves as the final reminder that the February CMS Software Changes will be implemented on <b><u>02/15/2016 between 3:00 PM PST and 4:00 PM PST</u></b>.
<br>
This implementation will include changes in the following areas:
<br><br>
<ul>
<li>Batch MBD response file</li>
<li>Webservice</li>
<li>Online Eligibility screen</li>
</ul>
<br><br>
CMS has confirmed that the next MBD refresh, which will be pushed to us on 02/15/2016, will contain the new Unlawful Presence data as previously announced as part of the CMS February software changes. Although we do not know the exact time when the refresh will be received and applied to our database, we are to implement our changes at the above mentioned time.
<BR><br>
<Ul>
<li>CMS Final Draft February 2016 <a href="/mss/IFOXDocs/Final_Draft_February_2016_Detail_Release_Memo.pdf" class="info" target="_blank">Detail Release Memo</a></li>
<li>Wipro <a href="/mss/IFOXDocs/Wipro_Impact_Analysis_February_2016_Release_Final.pdf" class="info" target="_blank"> Impact Analysis</a> February 2016 Release Final</li>
<li>Wipro <a href="/mss/IFOXDocs/Interface_to_MSS_17_06.pdf" class="info" target="_blank">Interface to MSS</a> document - version 17.06</li>
</Ul>
<br><br>
Please contact our Helpdesk if you have any questions/concerns.
<br><br>
Thank you
<br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - February CMS Software Changes - REMINDER ****</span>											
                <br><br>					
This notice serves as a reminder of the implementation of the February CMS Software Changes. Attached please find the following supported documents:
                <BR><br> 
<Ul>
<li>CMS Final Draft February 2016 <a href="/mss/IFOXDocs/Final_Draft_February_2016_Detail_Release_Memo.pdf" class="info" target="_blank">Detail Release Memo</a></li>
<li>Wipro <a href="/mss/IFOXDocs/Wipro_Impact_Analysis_February_2016_Release_Final.pdf" class="info" target="_blank"> Impact Analysis</a> February 2016 Release Final</li>
<li>Wipro <a href="/mss/IFOXDocs/Interface_to_MSS_17_06.pdf" class="info" target="_blank">Interface to MSS</a> document - version 17.06</li>
</Ul>
<br><br>
Thank you
<br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Interface to MSS document version 17.06 - February CMS Software Changes  ****</span>
											
				<br><br>
The <a href="/mss/IFOXDocs/Interface_to_MSS_17_06.pdf" class="info" target="_blank">Interface to MSS</a> document has been updated with version 17.06 (attached) to reflect the CMS February 2016 Software changes as documented in the final <a href="/mss/IFOXDocs/Final_Draft_February_2016_Detail_Release_Memo.pdf" class="info" target="_blank">CMS HPMS Notice</a>, dated December 1st, 2015 (also attached). CMS will implement these changes on February 2016 CMS Data Due date which will occur on Friday, February 5th. Please review the Revision History section for the summary of all changes - page three of the <a href="/mss/IFOXDocs/Interface_to_MSS_17_06.pdf" class="info" target="_blank">Interface to MSS</a> document. 
<br><br>
Please contact the Wipro HelpDesk if you have any questions/concerns.
<br><br>
Thank you,
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>
				<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>	
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Thanksgiving Holiday's Schedule and Enrollment Processing ****</span>											
                <br><br>					
Wipro offices will be closed Thursday, November 26th, 2015 and Friday, November 27th, 2015. All transactions will be submitted to CMS <b>as normal - at the regularly scheduled times. </b> Should any issues arise, please send an email to the Wipro helpdesk at <a class= "info" href="mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>.   
                <br><br>
Have a Safe and Happy Thanksgiving Holiday!
                <BR><br> 
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Plan Communications User Guide (Version 9.3) Now Available ****</span>													
				<br><br>					
	Please see CMS notice below regarding the new version of the PCUG.
<br><BR>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>
				<br><br>
					**********************************************************************************************************************				
					Please do not reply to this message. This is an announcement e-mail only.				
					**********************************************************************************************************************
					This e-mail is sent out on behalf of the Centers for Medicare and Medicaid Services (CMS).
       <br><br> 
                   The Centers for Medicare & Medicaid Services has posted a new version (version 9.3) of the Plan Communications User Guide (commonly referred to as the Guide) to the MAPD Help Desk Web site. Enhancements to the Guide reflect changes incorporated from the November 2015 Release. Please reference the Medicare Advantage and Prescription Drug Plans Communications User Guide page for the updated Guide:  
<br>
<a href="https://www.cms.gov/Research-Statistics-Data-and-Systems/CMS-Information-Technology/mapdhelpdesk/Plan_Communications_User_Guide.html" target="blank">https://www.cms.gov/Research-Statistics-Data-and-Systems/CMS-Information-Technology/mapdhelpdesk/Plan_Communications_User_Guide.html</a>    
       <br><br>

                    Please direct questions or concerns to the MAPD Help Desk at <a class="info" href="mailto:mapdhelp@cms.hhs.gov">mapdhelp@cms.hhs.gov</a> or 1 (800) 927-8069.               
       <br><br>
Thank you,                   
       <br><br>
MAPD Help Desk
<br>
(800) 927-8069
<br>
<a class="info" href="mailto:mapdhelp@cms.hhs.gov">mapdhelp@cms.hhs.gov</a>
<br>
<a href="http://www.cms.gov/mapdhelpdesk" target= "blank">http://www.cms.gov/mapdhelpdesk</a>
			
					<br><br>  
				</td>
			</tr>
		</table>
		</td>
	</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
       <td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - RECAP of CMS' Memo - Guidance Regarding (RAPS) and (EDPS) Submissions ****</span>											
                <br><br>					
<b>Dear Wipro Customers:</b>
<br><BR>
As your Medicare Advantage Business Partner, Wipro is committed to provide continuous support and assistance. One way we do this is by ensuring all of our customers are updated with the latest information provided by CMS and other government agencies.
<br><br>
On October 23, 2015, CMS released a memo providing additional clarification regarding several RAPS and EDS issues and concerns. Below, please find a summary of highlights and key topics:
<br><BR>
<b>1. <u>Diagnosis submitted after the Risk Adjustment Deadline:</u></b>
<br><br>
CMS will not incorporate diagnoses submitted after the risk adjustment deadline, into the risk score for a payment year. Specifically, after the final risk adjustment submission deadline for a payment year, only diagnoses deletes will be included in a rerun of risk scores for the payment year.
<br><br>
&nbsp;<font color = "red">Important Note-</font> The chart below outlines upcoming risk adjustment data deadlines. In order to prevent processing delays, please submit your Raps and EDS data to Wipro at least seven business days prior to the CMS deadline. 
                <BR><br> 
<b>Deadline for Submitting Risk Adjustment Data for Use in Risk Score Calculation</b>
<br>
May 13, 2015 HPMS notice, deadline for Submitting Risk Adjustment Data for Use in Risk Score Calculation Runs for Payment Years 2015, 2016 and 2017 identifies the deadlines for submitting risk adjustment data (see table):
<br><br> 
<TABLE border="1">
					<TBODY>
						<TR>
							<TD><center><b>Risk Score Run</b></center></TD>
                            <TD><center><b>Dates of Service</b></center></TD>
							<TD><center><b>Risk Adjustment Data Deadline for Submission</b></center></TD>
						</TR>
						<TR>
							<TD>2016 Initial(RAPS)</TD>
                            <TD>07/01/17 - 06/30/15</TD>
							<TD>Friday 09/11/2015</TD>
						</TR>
						<TR>
							<TD>2015 Final (RAPS, EDS)</TD>
                            <TD>01/01/14 - 12/31/14</TD>
							<TD>Monday 02/01/2016</TD>
						</TR>
						<TR>
							<TD>2016 Mid-Year (RAPS)</TD>
                            <TD>01/01/15 - 12/31/15</TD>
							<TD>Friday 03/04/2016</TD>
						</TR>
						<TR>
							<TD>2017 Initial (RAPS, EDS)</TD>
                            <TD>07/01/15 - 06/30/16</TD>
							<TD>Friday 09/09/2016</TD>
						</TR>
						<TR>
							<TD>2016 Final (RAPS, EDS)</TD>
                            <TD>01/01/15 - 12/31/15</TD>
							<TD>Tuesday 01/31/2017</TD>

						</TR>
					</TBODY>
				</TABLE>
<br><br>
<b>Reminder:</b> Encounter data will not be added in to the risk scores util CMS calculates the final PY 2015 risk scores.
<br><br>
<b>2. <u>Submission of HIPPS codes for CAHs:</u></b>
<br><br>
When Plans report encounters from Critical Access Hospitals (CAH's), CMS does not require the inclusion of Health Insurance Prospective Payment System (HIPPS) codes.
<br><br>
&nbsp;<font color = "red">Note:</font> Wipro does not have any immediate plans to implement compliance edits related to HIPPS codes for CAH's; however, if your plan has unique requirements, please contact your Wipro SME or Account Representative for assistance.
<br><br>
<b>3. <u>NPIs for atypical providers:</u></b>
<br><br>
When submitting encounters with providers that are not atypical providers - i.e., providers who have NPIs - Plans must include the providers' actual NPIs. Default NPIs should only be submitted to the EDS when the provider is considered to be "atypical".
<br><br>
To submit encounter data from atypical providers, use the following default NPIs:
<ul>
<LI>Payer ID 80881 (Insitutional) - 1999999976</LI>
<Li>Payer ID 80882 (Professional) - 1999999984</Li>
<LI>Payer ID 80887 (DME) - 1999999992</LI>
</ul>
<br>
&nbsp;<font color = "red">New Compliance Edits:</font> Wipro is currently enhancing our Compliance Checker to include LUHN logic which will address NPI requirements for atypical providers. These edits will be implemented  in early 2016. Please find a list of new compliance checker edits below:
<br><br>
Please find a list of new compliance checker edits below:
<br><br>
&nbsp&nbsp&nbsp&#10731&nbspIf the NPI is present but does not start with "1" or "2" an error will be set.
<br><br>
&nbsp&nbsp&nbsp&#10731&nbspValidate the NPI using the NPI LUHN formula validation, but exclude the CMS approved atypical Provider IDs of: Payer ID 80881 (Instituional) - 1999999976, Payer ID 80882 (Professional) - 1999999984, Payer ID 80887 (DME) - 1999999992.
<br><br>
<b>SOURCES AND DIRECT LINKS:</b>
<br><br>
&#10146;Deadline for Submitting Risk Adjustment Data for Use in Risk Score Calculation Runs for Payment Years 2015, 2016, and 2017:
<br>
<A href="http://www.csscoperations.com/internet/cssc3.nsf/files/HPMS%202015_2016_2017%20Payment%20Run%20Notice_051315%20final.pdf/$FIle/HPMS%202015_2016_2017%20Payment%20Run%20Notice_051315%20final.pdf" target= "blank" >http://www.csscoperations.com/internet/cssc3.nsf/files/HPMS%202015_2016_2017%20Payment%20Run%20Notice_051315%20final.pdf/$FIle/HPMS%202015_2016_2017%20Payment%20Run%20Notice_051315%20final.pdf</A>
<br><br>
&#10146;Guidance Regarding Risk Adjustment Processing System (RAPS) and Encounter Data System (EDS) Submissions:
<br>
<a href="http://www.csscoperations.com/internet/cssc3.nsf/files/10152015%20RA_EDS%20Updated%20Guidance.pdf/$FIle/10152015%20RA_EDS%20Updated%20Guidance.pdf" target="blank">http://www.csscoperations.com/internet/cssc3.nsf/files/10152015%20RA_EDS%20Updated%20Guidance.pdf/$FIle/10152015%20RA_EDS%20Updated%20Guidance.pdf</a>
<br><br>
For additional information, please refer to the attached <a href="/mss/IFOXDocs/10152015_RA_EDS_Updated_Guidance.pdf" class="info" target="_blank"> CMS Memo</a> or contact your dedicated Wipro SME or Account Representative.
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				
<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img 

src="/mss/jsp/Recon/images/news_icon.gif" width="14" 

height="16"></td>
       <td align="left"><span class="NewsHeading">**** Wipro Notice - 2015 End-of-Year Processing and other related information ****</span>
       <br><br>
	   Attached please find the <a href="/mss/IFOXDocs/EOY_2015_20150929.pdf" class="info" target="_blank">End-of-Year guidance</a> from CMS. Please refer to the guidance for additional information regarding End-of-Year processing. Based on the guidance, please refer to the table below for important CMS key dates:
	   <br><br>
	  
				<BR>
				<TABLE border="1">
					<TBODY>
						<TR>
							

<TD><center><b>Date</b></center></TD>
							

<TD><center><b>Item</b></center></TD>
						</TR>
						<TR>
							

<TD>October 09, 2015</TD>
							

<TD>October Plan Data Due Date</TD>
						</TR>
						<TR>
							

<TD>October 05, 2015</TD>
							

<TD>Begin submitting 2016 enrollment effective dates</TD>
						</TR>
						<TR>
							

<TD>October 05, 2015, no later than 5 PM EDT</TD>
							

<TD>Plans approved for renewal or crosswalk exceptions by CMS that 

require plan-submitted EOY activity must submit MARx transactions. 

(See section 2.B of the attachment) </TD>
						</TR>
						<TR>
							

<TD>October 12, 2015</TD>
							

<TD>Columbus Day holiday</TD>
						</TR>
						<TR>
							

<TD>October 15, 2015</TD>
							

<TD>Annual Enrollment Period (AEP) begins</TD>
						</TR>
						<TR>
							

<TD>Late October, 2015</TD>
							

<TD>Plans will receive special Transaction Reply Reports (TRRs) and 

other reports containing reassignment activity. Reassignment letters 

sent to beneficiaries.</TD>
						</TR>
						<TR>
							

<TD>November 06, 2015</TD>
							

<TD>November Plan Data Due Date</TD>
						</TR>
					                <TR>
							

<TD>November 03 and 04, 2015</TD>
							

<TD>CMS-generated rollover processing</TD>
						</TR>
						<TR>
							

<TD>November 9, 2015</TD>


<TD>Transactions 75 and 78 with an effective date of 01/01/2016 will not process if submitted before this date</TD>
                        </TR>
                        <TR>


<TD>December 04, 2015</TD>
							

<TD>December Plan Data Due Date</TD>
						</TR>
                                                                                                <TR>
							

<TD>December 07, 2015</TD>
							

<TD>AEP ends</TD>
						</TR>
						<TR>
							

<TD>January 8, 2016</TD>
							

<TD>January Plan Data Due Date </TD>
						</TR>
					</TBODY>
				</TABLE>
				<br>
	            To assist our clients with their EOY enrollment 

processing, Wipro/Infocrossing will be performing the followings:
	   
	   <br><br>
	   1. <u>All NON_AEP transactions with January 1, 2016 

effective date</u> that have been uploaded to Wipro, and are being held at Wipro, will be  

released to CMS for processing on <b>October 6, 2015</b>.
	   <br><br>	   
	  2. <u>All CMS approved plan-submitted roll-over or service 

area reduction disenrollment transactions</u> that have beeen uploaded to Wipro up to <i><b>October 05,2015</b></i>
will be released 

to CMS for processing on <i><b>October 5, 2015, <b><font color=red>by no later than 12:00 

Noon PST</font></b>. Please submit all relevant files to Wipro/Infocrossing prior 

to the October 5 deadline. CMS requires these files to be transmitted 

to the MARx system only on October 05, 2015 and all files must be 

received by Wipro/Infocrossing and ready for CMS submission prior to 

October 5</b></i>.	   
	   <br><br>
	   3. <u>All AEP transactions with January 1, 2016 effective 

date</u> that have been uploaded to Wipro will be held and will be 

released to CMS for processing on <b>October 15, 2015</b> right 

after midnight EDT.
	   <br><br>	   
	  4. <u>All 75 and 78 transactions with a January 1, 2016 

effective date</u> that have been uploaded to Wipro up to <i><b>November 08, 2015</b></i> will be released to CMS for 

processing on <b>November 09, 2015</b>.
	   <br><br>	   
	   <font color = "red"><b>****** Special processing for CMS 

Approved Roll-Over or Service Area Reduction transactions:</b> 

</font>
	   <br><br>
	   Please contact Wipro Helpdesk if you have rollover or 

service area reduction disenrollment transactions to submit. Please 

note that these transactions cannot be mixed with regular MARx 

submissions and must be handled seperately. The following link on 

the Wipro/Infocrossing web portal will be made available for you to 

upload these transactions. Please contact our Helpdesk if you do not 

have these links:<br>

    <br>&nbsp;&nbsp;&nbsp;<t><t><font color="red">CMS Preapproved Rollover Transactions</font>
    <br>&nbsp;&nbsp;&nbsp;<t><t><font color ="red">Upload Data </font>


	   <br><br>	   
<ul>            
                   <li><b>Please note that Wipro will not be able to accommodate 

this process through <u>manual input or FTP upload</u>. These 

transactions can only be processed via a batch file submission on the 

web portal.</b></li>
                   <br><br>
                   <li><b>Please send us any new contract plans and/or PBP's for 

2016 if you haven't done so.</b></li>
</ul> 	   
                   <br><br>
Please forward this announcement to other areas within your 

organization as you deem necesary. Thank you.
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>	
 
			</TR>
		</table>
  </td>
</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Emergency Maintenance on www.medicare-solution.com - 09/30/15 ****</span>											
                <br><br>					
This notice is to inform our clients that the Wipro website (www.medicare-solution.com) will be unavailable for emergency maintenance tonight <b>(09/20/2015)</b> from <b>9:00 PM PDT to 11:00 PM PDT</b>. We will send a confirmation notice once the website is back up. We apologize for the inconvenience and thank you for your patience.
                <BR><br> 
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - CMS' November 2015 Software Release & Wipro's Impact Analysis ****</span>											
                <br><br>					
This notice serves as the reminder that the November 2015 Software changes are scheduled to be implemented on <B>November 6th, 2015 right after 8 PM EDT.</B> Attached to this notice are the following documents:
                <BR><br> 
<Ul>
<li>CMS <a href="/mss/IFOXDocs/Final_Draft_November_2015_Detail_Release_Memo.pdf" class="info" target="_blank">Final Draft November 2015 Detail Release Memo</a> - issued on 08/26/2015.</li>
<li><a href="/mss/IFOXDocs/Wipro_Impact_Analysis_November_Release.pdf" class="info" target="_blank">Wipro Impact Analysis November Release</a> document.</li>
<li>Version 17.05 of the <a href="/mss/IFOXDocs/Interface_to_MSS_17_05.pdf" class="info" target="_blank">Interface to MSS</a> document.</li>
<li>Copy of the <a href="/mss/IFOXDocs/Wipro_Notice_November_Changes.pdf" class="info" target="_blank">Wipro Notice</a> regarding the November changes - sent 09/04/2015.</li>
</Ul>
<BR><BR>
Please refer to these documents for all details related to the November Release implementation. Any questions/concerns please contact the Wipro HelpDesk and/or your assigned Business Analyst.
<br><br>
Thank you
<br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - MMP Technical Guide - Version 2.4 - CMS November Software Changes  ****</span>											
                <br><br>					
The <a href="/mss/IFOXDocs/MMP_EE_Guide.pdf" class="info" target="_blank">MMP technical guide</a> - <B>version 2.4</B> has been updated to reflect the CMS November 2015 software changes as documented in the attached <a href="/mss/IFOXDocs/Final_Draft_November_2015_Detail_Release_Memo_08262015.pdf" class="info" target="_blank">CMS HPMS</a> notice. The Infocrossing edit changes will be implemented on the November 2015 CMS Plan Data Due date which will occur on Friday, November 6th, 2015. The actual implementation time will be right after the 08:00 P.M. Eastern Time. Please refer to page 4, section <b>08/31/2015 - Version 2.4</b> of the <a href="/mss/IFOXDocs/MMP_EE_Guide.pdf" class="info" target="_blank">MMP EE Guide</a> for additional details regarding the implementation.
                <br><br>
Thank you
                <BR><br> 
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Version 17.05 of the Interface to MSS document  ****</span>
											
				<br><br>
Attached please find version 17.05 of the <a href="/mss/IFOXDocs/Interface_to_MSS_17_05.pdf" class="info" target="_blank">Interface to MSS</a> document. Below is the summary of the changes which can also be found in the first section of the document.
<br><br>
<b>08/31/2015 - Version 17.05</b>
<br><br>
The interface document has been updated with version 17.05 to reflect the CMS November 2015 Software changes, as documented in the final CMS HPMS notice, dated August 28, 2015. The Wipro edit changes will be implemented on the Novemberr 2015 CMS Plan Data Due Date which will occur on <b>Friday November 6th, 2015</b>. The actual implementation time will be right after 08:00 P.M. Eastern Time.
<br><br>  
As part of the November software changes, CMS will require the PBP# field on "51" disenrollment and "81" disenrollment cancellation transactions for qualifying MAPD and PDP contracts. Section 2.1 (Medicare Transaction Processing) and section 2.6 (Medicare Transaction Matrix) of this document have been changed as follows:
<br><br>
<ul>
<LI>The PBP# field on the batch enrollment/disenrollment/cancellation record on page 22 has been updated to indicate that it is a required field on "51" and "81" transaction types for PBP specific organizations. Section 2.6 (Medicare Transaction Matrix) has beeen modified on pages 42 and 43 to indicate that the PBP# is required on MAPD and PDP "51" and "81" transactions. This change doesn not affect Medicare Advantage organizations that do not use PBPs. </LI>
<LI>Wipro edits will reject "51" and "81" transactions that do not include the PBP# field when required with exisiting error code: "51" - PBP# REQUIRED. VALUE MUST BE NUMERIC."</LI>
</ul>
<br><br>
Plans will be able to test this new CMS requirement with the Wipro application system beginning on <b>Monday, September 14th, 2015</b>. 
<br><br>
An additional change that is unrelated to the November software release will be implemented to improve consistency and clarity of the text description for error code "48". The error message will be changed from "<i>Signature Date Invalid</i>" to: "<i>Application Receipt Date Invalid</i>". Section 2.5 -  <i>Transaction Error Codes</i> on page 39 has been updated accordingly.
<br><br>
Thank you,
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>
				<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Labor Day Holiday Schedule ****</span>											
                <br><br>					
Wipro offices will be closed Monday, Sept &, 2015 in observation of the Labor Day holiday. All transactions will be submitted to CMS <b>as normal - at the regularly scheduled times. </b> Should any issues arise, please send an email to the Wipro helpdesk at <a class= "info" href="mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>.   
                <br><br>
Thank you and have a safe Holiday!
                <BR><br> 
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				

<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Implementation of August Software Changes - REMINDER****</span>													
				<br><br>					
This notice serves as a final reminder that the changes described below will be implemented on August 15th/16th. Although we are expecting to have our systems updated and available between the hours of 8PM PST - 11:00PM PST on August 15th, the exact timing of this implementation is dependent on the receipt of the MBD refresh from CMS. We will notify you of any unforseen potential delays as needed and a final confirmation notice will be sent out when the software changes are successfully implemented.
                <br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>			
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Version 17.04 of the Interface to MSS document  ****</span>
											
				<br><br>
Attached please find version 17.04 of the <a href="/mss/IFOXDocs/Interface_to_MSS_17_04.pdf" class="info" target="_blank">Interface to MSS</a> document. The following description of changes can also be found in the first section of the document:
<br><br>
<b>Version 17.04 changes are scheduled to be implemented on <u>Saturday, August 15, 2015</u> to coincide with the CMS MBD refresh.</b>
<br><br>
On May 10, 2015, CMS made enhancements to the Batch Eligibility Query (BEQ) response file by adding the following fields:
<BR>
<ul>
<LI>Plan Benefit Package (PBP)</LI>
<LI>Plan Type Code</LI>
<LI>Employer Group Health Plan (EGHP) Indicator</LI>
<LI>End Stage Renal Disease (ESRD) Indicator</LI>
</ul>
1. The MBD eligibility file response layout is now being updated with the same changes. Section 1 of this document has been updated as follows (all changes are highlighted in red within this document for ease of reference):
<BR><BR>
&nbsp;&nbsp;&#10146;<b>Note</b> that the MBD file response layout size (as described in section 1 of this document) does not change and remains at 1,300 bytes.  However, the EGHP indicator value in position 213 and the plan enrollment related fields (positions 478 to 525) have changed as follows:
<BR><br>
&nbsp;&nbsp;&#10146;Position 213 of the MBD response file is now defined as FILLER. This change occurs on page 11.  The EGHP indicator is now defined for each one of the two plan membership occurrences for the beneficiary as follows:
<br><br>
&nbsp;&nbsp;&#10146;Two occurrences of plan enrollment information now include the PBP ID, the EGHP INDICATOR and the PLAN TYPE CODE.  Please reference the MBD response file layout in section 1 of this document, beginning on page 14.
<br><br>
&nbsp;&nbsp;&#10146;<b>Note</b> that the ESRD STATUS indicator continues to be reported on the MBD response layout with no changes.
<BR><br>
2. The MBD Eligibility + response layout is also being updated with the same changes as described above for section 1. Section 5 of the document, beginning on page 58, has also been updated accordingly.  
<BR><br>
3. The <b>web service</b> section (section 3, beginning on page 49) has been changed to accomodate the new field additions and changes as follows:
<br><br>
&nbsp;&nbsp;&#10146;The eghplnd field has been removed from the "Eligibility Query Return Data" portion and added to the "Enrollment Data" section. 
<BR><BR>
&nbsp;&nbsp;&#10146;The pbpld and plan Type fields have been added to the "Enrollment Data" section.
<BR><BR>
4. These MBD field additions and changes will also be reflected on the <u>Eligibility</u> tab of the <a href="https://www.medicare-solution.com/mss/home/Index.jsp" target= "blank">www.medicare-solutioni.com</a>website.
<br><BR>
5. Version 17.04 changes have also taken into account the new disenrollment reason code value of "65" (Loss of Employer Group Waiver Plan Eligibility)that CMS will implement with the HPMS August 2015 software release. This new disenrollment reason code value is recognized and documented on page 24, in section 2.1 - Medicare Transaction Processing section of this document.
<br><br>
Thank you,
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>
				<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>	
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Important - Addendum to the Announcement of the August 2015 Software Release ****</span>													
				<br><br>					
						Please refer to the attached <a href="/mss/IFOXDocs/Addendum_to_the_Announcement_of_the_August_2015_Software_Release.pdf" class="info" target="_blank">Addendum to the Announcement of the August 2015 Software Release</a>.
                <br><br>
                <font color = "red"><U>Important Note</U></font> - In this Addendum, CMS stated that the BEQ response file will include the beneficiary's mailing and residence addresses. Please refer to the layout in the attachment for specific information regarding these new fields. 
<br><BR>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>
				<br><br>
					**********************************************************************************************************************				
					Please do not reply to this message. This is an announcement e-mail only.				
					**********************************************************************************************************************
					This e-mail is sent out on behalf of the Centers for Medicare and Medicaid Services (CMS).
       <br><br> 
                    Please review the attached memo from Cheri Rice and Cathy Carter, entitiled <a href="/mss/IFOXDocs/Addendum_to_the_Announcement_of_the_August_2015_Software_Release.pdf" class="info" target="_blank">"Addendum to the Announcement of the August 2015 Software Release"</a>. This letter provides supplemental or updated information to the May 19, 2015 HPMS letter titled "Announcement of the August 2015 Software Release" regarding the planned release of systems changes scheduled for August, 2015.        
       <br><br>

                    Please direct questions or concerns to the MAPD Help Desk at <a class="info" href="mailto:mapdhelp@cms.hhs.gov">mapdhelp@cms.hhs.gov</a> or 1 (800) 927-8069.               
       <br><br>
 Thank you,                   
       <br><br>
MAPD Help Desk
<br>
(800) 927-8069
<br>
<a class="info" href="mailto:mapdhelp@cms.hhs.gov">mapdhelp@cms.hhs.gov</a>
<br>
<a href="http://www.cms.gov/mapdhelpdesk" target= "blank">http://www.cms.gov/mapdhelpdesk</a>
			
					<br><br>  
				</td>
			</tr>
		</table>
		</td>
	</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - ICD 10 - Testing Readiness For Pass-Through Services ****</span>
											
				<br><br>
Wipro's systems are ready to accept your ICD-10 test files. CSSC has issued the following guidance:
<br><br>
<b><i>RAPS Testing Specifications:</i></B>
<ul>
<LI>The AAA record, field 5, (PROD-TEST_IND), must be 'TEST'; and field 6, (FILE-DIAG-TYPE), must be ICD10.</LI>
<LI>Plans must submit a valid beneficiary with valid MAO enrollment data for the diagnosis date of service.</LI>
<LI>Diagnoses Service Thru Dates (SRVC_THRU_DT) must be greater than or equal to the ICD-10 test cut-over date of 03/01/2014, and less than or equal to the current date.</LI>
<LI>All records with future dates will be rejected.</LI>
<LI>All diagnoses in the ICD10 TEST file must be ICD-10 diagnosis codes (up to 7 characters).</LI>
<LI>Any diagnoses with SRVC_THRU_DT great than, or equal to '03/01/2014' should be an ICD diagnosis code.</LI>
<LI>The Palmetto Front End Risk Adjustment System (FERAS) will reject the 'TEST' file with error code 166 if it exceeds 3000 records</LI>
</ul>
<B><I>Encounter Testing Specifications:</I></B>
<ul>
<LI>All files must conform to the standards outlined in the X12 5010 837 Companion Guide</LI>
<LI>All test files must have the ISA01 field set to '03'; the ISA02 field set to '8888888888'; and the ISA15 field set to 'T'.</LI>
<LI>Plans must submit a valid beneficiary with valid MAO enrollment data for the diagnosis date of service.</LI>
<LI>Diagnoses Service Thru Dates must be greater than or equal to 10/01/2015</LI>
<LI>The Interchange Date in field ISA09 must not be a future date.</LI>
<LI>The Palmetto Front End System will reject the 'TEST' file with an error message if it exceeds two thousand (2,000) encounters.</LI>
</ul>

Please contact your assigned <b>Business Analyst</b> for additional details and/or questions.
<BR><br>
Thank you,
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>
				<br><br>
	   				
	   				
				</td>
			</tr>
		</table>
		</td>
	</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>     
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - ICD 10 - Testing Readiness For EDPS Full Service ****</span>
											
				<br><br>
Wipro's EDPS systems are ready to accept test files containing ICD-10 codes and future dates of service. Encounters with ICD-9 codes with dates of service <u>after</u> October 1 will pass Wipro edits and be sent to CSSC, along with ICD-10 codes and dates of service prior to October 1. Test files should be reported to Wipro via I-Desk, with the subject indicating "Tier2 ICD-10 testing".
<br><br>
CSSC has issued the following guidance:
<br>
<ul>
<LI>Only valid beneficiaries</LI>
<LI>Diagnoses Service Thru Dates should be greater than or equal to 10/01/2015</LI>
<LI>The Interchange Date in field ISa09 must not be a future date.</LI>
<LI>The Palmetto Front End System will reject the 'Test' file if it exceeds two thousand (2,000) encounters</LI>
</ul>

&nbsp;&nbsp;&#10146;For customers sending the <u>837</u> format, the Tier 2 test files(2) should contain "T" in ISA15. Wipro will continue to populate the ISA01 and ISA02 fields on your behalf. The primary ICD-10 diagnosis Type Codes should be populated with "ABK", and the secondary Type Codes should be "ABF".  
<BR><br>
&nbsp;&nbsp;&#10146;For customers sending the <u>Wipro Standard</u> format, the Tier 2 files(2) should contain "T" in position (column) 119. Wipro will continue to populate the ISA01 and ISA02 fields on your behalf. The primary ICD-10 diagnosis Type Codes should be identified in Record type 2 in position 4667 as "ABK", and "ABF" in corresponding file positions.
<br><br>
&nbsp;&nbsp;&#10146;For customers using a <u>Customized</u> format, the file should indicate Test, and the diagnosis Type Codes should be populated with "ABK" and "ABF" in the corresponding file position.
<br><br>
Please contact your assigned <b>Business Analyst</b> for additional details and/or questions.
<BR><br>

Thank you,
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>
				<br><br>
	   				
	   				
				</td>
			</tr>
		</table>
		</td>
	</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>     
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** <font color = "blue"> Wipro Notice - Independence Day Holiday - 7/3/2105</font> ****</span>													
				<br><br>					
Wipro offices will be closed Friday July 3, 2015 in observance of the Independence Day holiday. All transactions will be submitted to CMS <b>as normal - at the regular scheduled times</b>. Should any issues arise, please send an email to the Wipro Helpdesk at <a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>.
<br><BR>
Thank you and have a safe holiday!
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>	
				<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>			
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Version 17.04 of the Interface to MSS document  ****</span>
											
				<br><br>
Attached please find version 17.04 of the <a href="/mss/IFOXDocs/Interface_to_MSS_17_04.pdf" class="info" target="_blank">Interface to MSS</a> document. The following description of changes can also be found in the first section of the document:
<br><br>
<b>Version 17.04 changes are scheduled to be implemented on <u>Saturday, August 15, 2015</u> to coincide with the CMS MBD refresh.</b>
<br><br>
On May 10, 2015, CMS made enhancements to the Batch Eligibility Query (BEQ) response file by adding the following fields:
<BR>
<ul>
<LI>Plan Benefit Package (PBP)</LI>
<LI>Plan Type Code</LI>
<LI>Employer Group Health Plan (EGHP) Indicator</LI>
<LI>End Stage Renal Disease (ESRD) Indicator</LI>
</ul>
1. The MBD eligibility file response layout is now being updated with the same changes. Section 1 of this document has been updated as follows (all changes are highlighted in red within this document for ease of reference):
<BR><BR>
&nbsp;&nbsp;&#10146;<b>Note</b> that the MBD file response layout size (as described in section 1 of this document) does not change and remains at 1,300 bytes.  However, the EGHP indicator value in position 213 and the plan enrollment related fields (positions 478 to 525) have changed as follows:
<BR><br>
&nbsp;&nbsp;&#10146;Position 213 of the MBD response file is now defined as FILLER. This change occurs on page 11.  The EGHP indicator is now defined for each one of the two plan membership occurrences for the beneficiary as follows:
<br><br>
&nbsp;&nbsp;&#10146;Two occurrences of plan enrollment information now include the PBP ID, the EGHP INDICATOR and the PLAN TYPE CODE.  Please reference the MBD response file layout in section 1 of this document, beginning on page 14.
<br><br>
&nbsp;&nbsp;&#10146;<b>Note</b> that the ESRD STATUS indicator continues to be reported on the MBD response layout with no changes.
<BR><br>
2. The MBD Eligibility + response layout is also being updated with the same changes as described above for section 1. Section 5 of the document, beginning on page 58, has also been updated accordingly.  
<BR><br>
3. The <b>web service</b> section (section 3, beginning on page 49) has been changed to accomodate the new field additions and changes as follows:
<br><br>
&nbsp;&nbsp;&#10146;The eghplnd field has been removed from the "Eligibility Query Return Data" portion and added to the "Enrollment Data" section. 
<BR><BR>
&nbsp;&nbsp;&#10146;The pbpld and plan Type fields have been added to the "Enrollment Data" section.
<BR><BR>
4. These MBD field additions and changes will also be reflected on the <u>Eligibility</u> tab of the <a href="https://www.medicare-solution.com/mss/home/Index.jsp" target= "blank">www.medicare-solutioni.com</a>website.
<br><BR>
5. Version 17.04 changes have also taken into account the new disenrollment reason code value of "65" (Loss of Employer Group Waiver Plan Eligibility)that CMS will implement with the HPMS August 2015 software release. This new disenrollment reason code value is recognized and documented on page 24, in section 2.1 - Medicare Transaction Processing section of this document.
<br><br>
Thank you,
<br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>
				<br><br>
	   				
	   				
				</td>
			</tr>
		</table>
		</td>
	</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>     
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - MARx UI Availability and Processing Schedule for July, 2 2015 through July, 7 2015 ****</span>													
				<br><br>					
						Please see notice below from CMS regarding the MARX UI Availability and Processing Schedule
                <br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>
				<br><br>
					**********************************************************************************************************************				
					Please do not reply to this message. This is an announcement e-mail only.				
					**********************************************************************************************************************
					This e-mail is sent out on behalf of the Centers for Medicare and Medicaid Services (CMS).
       <br><br> 
                    Due to weekly EICM maintenance, please note that MARx UI login functionality may not be available between 12:00 AM ET and 6 AM ET on Thursday, July 2, 2015.      
       <br><br>
                    As a result of MARx mid-year RAS processing, the MARx UI will be in READ only mode from 9:30 PM on Thursday, July 2, 2015 until 7:00 PM ET Sunday, July 5, 2015. Plan transaction processing will also be held beginning Friday, July 3, 2015. Any MARx Plan transaction files received after 9:00 PM ET on Thursday, July 2, 2015, will be processed once the RAS process is complete on Monday, July 6, 2015. Submitters will not receive Batch completion reports on Friday, July 3, 2015 or Saturday, July 4, 2015.
       <br><br>
                    Additionally, the Daily Transaction Reply Report (DTRR) will not be delivered to plans on Saturday, July 4, 2015 or Sunday, July 5, 2015. The next DTRR transmission after early morning Friday, July 3, 2015 will be early morning on Tuesday, July 7, 2015. 
       <br><br>
                    If you have any questions, please contact the MAPD Help Desk at <a class="info" href="mailto:mapdhelp@cms.hhs.gov">mapdhelp@cms.hhs.gov</a> or 1 (800) 927-8069.               
       <br><br>
 Thank you,                   
       <br><br>
MAPD Help Desk
<br>
(800)927-8069
<br>
<a class="info" href="mailto:mapdhelp@cms.hhs.gov">mapdhelp@cms.hhs.gov</a>
<br>
<a href="http://www.cms.gov/mapdhelpdesk" target= "blank">http://www.cms.gov/mapdhelpdesk</a>
			
					<br><br>  
				</td>
			</tr>
		</table>
		</td>
	</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Wipro's Impact Analysis to June 2015 EDS Companion Guides****</span>													
				<br><br>					
			    Attached please find the <a href="/mss/IFOXDocs/Wipro_Impact_Analysis_to_EDS_Companion_Guides_June_2015_Final.pdf" class="info" target="_blank"> Wipro Impact Analysis to EDS Companion Guides</a>. Please contact your assigned EDPS Business Analyst if you have any questions or concerns.
                <br><br>
 Thank you
                <br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>
				<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - CMS' August 2015 Software Release & Wipro's Impact Analysis****</span>													
				<br><br>					
			    Attached please find the <a href="/mss/IFOXDocs/Announcement_of_the_August_2015_Software_Release.pdf" class="info" target="_blank"> Announcement of the August Software Release</a> memo from CMS as well as the <a href="/mss/IFOXDocs/Wipro_Impact_Analysis_to_CMS_Software_Changes_for_August_2015_Final_6_22_15.pdf" class="info" target="_blank">Wipro's Impact Analysis</a> document.
				<br><br>  
                Please contact the Wipro HelpDesk and/or your assigned Business Analyst if you have any questions or concerns.
                <br><br>    
                Thank you
                <br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>
				<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>	
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - CMS June Monthly Reports and DTRR's****</span>													
				<br><br>					
				Please be advised of the following items:
                <br><br>
                1/ June Monthly Reports - CMS has not issued the June Monthly reports and does not have an ETA as to when they will be available.
                <br><br>
                2/ Memorial Weekend DTRR - The next DTRR that CMS will push out will be on Friday night/Saturday morning. There will not be any other DTRR's issued until Tuesday 05/26/15.
				<br><br>  

Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>	
				<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>			
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Important Notice Regarding the December 6, 2014 MARx Agent Broker Compensation File****</span>													
				<br><br>					
					Please see notice below from CMS regarding the Agent Broker Compensation File.
				<br><br>
					**********************************************************************************************************************				
					Please do not reply to this message. This is an announcement e-mail only.				
					**********************************************************************************************************************
					This e-mail is sent out on behalf of the Centers for Medicare and Medicaid Services (CMS).
                    CMS found that there were missing enrollments on the MARx Agent Broker Compensation file sent December 6, 2014. Enrollments that were processed by CMS between November 1, 2014 and November 7, 2014 did not appear on the December 6, 2014 MARx Agent Broker's Compensation Report. CMS will provide an ad hoc Agent Broker's Compensation Report with this data on May 31, 2015. Please make appropriate compensation adjustments once the ad hoc report is released.
       <br><br>
                    This report does not include any missed enrollments that were effective 2015. Enrollments with effective dates of January 4, 2015 were processed and included on the January 4, 2015 Agent Brokers Compensation file. 
       <br><br>
                   If you have any questions, please contact the MAPD Help Desk at <a class="info" href="mailto:mapdhelp@cms.hhs.gov">mapdhelp@cms.hhs.gov</a> or 1 (800) 927-8069.               
       <br><br>
 Thank you,                   
       <br><br>
MAPD Help Desk
<br>
1 (800) 927-8069
<br>
<a class="info" href="mailto:mapdhelp@cms.hhs.gov">mapdhelp@cms.hhs.gov</a>
<br>
<a href="http://www.cms.gov/mapdhelpdesk" target= "blank">http://www.cms.gov/mapdhelpdesk</a>
			
					<br><br>  
				</td>
			</tr>
		</table>
		</td>
	</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Memorial Day Holiday ****</span>													
				<br><br>					
					Wipro offices will be closed on Monday, May 25, 2015 in observance of the Memorial Day Holiday. 
					All transactions will be submitted to CMS <b>as normal - at the regular scheduled times.</b> 
					Should any issues arise, please send an email to MCareSupport@Wipro.com. 
				<br><br>  

Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>	
				<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - EDPS Release Notes****</span>													
				<br><br>					
					Please see attached the following release notes regarding EDPS: <a href="/mss/IFOXDocs/April_2015_Release_Notes_Institutional_Professional.pdf" class="info" target="_blank"> April 2015 Release Notes Institutional Professional</a> and <a href="/mss/IFOXDocs/Institutional_Professional_Updateable_Screens_April_2015.pdf" class="info" target="_blank">Institutional Professional Updateable Screens April 2015</a>. 
                <br><br>
 Thank you
                <br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
<a class="info" href= "mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>
				<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - CMS May 2015 Software Release REMINDER****</span>													
				<br><br>					
					This notice serves as a reminder that CMS will be implementing the new layout for the BEQ response file this weekend, May 10th (see attached documents for additional details: <a href="/mss/IFOXDocs/May_2015_Detail_Release_Memo_02252015_2.pdf" class="info" target="_blank"> Detail May 2015 Software Release</a> and <a href="/mss/IFOXDocs/Wipro_Impact_Analysis_May_2015.pdf" class="info" target="_blank">Wipro's Impact Analysis</a>). We have made all the necessary changes to accommodate the new layout. Please contact the Wipro Helpdesk if you have any questions or concerns.  
				<br><br>  
                Thank you
                <br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
MCareSupport@wipro.com	
				<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - CMS May 2015 Software Release****</span>													
				<br><br>					
					Attached please find the <a href="/mss/IFOXDocs/May_2015_Detail_Release_Memo_02252015_2.pdf" class="info" target="_blank"> Detail May 2015 Software Release</a> memo from CMS as well as the <a href="/mss/IFOXDocs/Wipro_Impact_Analysis_May_2015.pdf" class="info" target="_blank">Wipro's Impact Analysis</a> document.
				<br><br>  
                Thank you
                <br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
MCareSupport@wipro.com	
				<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - CMS February 2015 Software Release****</span>													
				<br><br>					
					Attached please find the <a href="/mss/IFOXDocs/Final_February_2015_Detail_Release_Memo.pdf" class="info" target="_blank">Detail February 2015 Software Release</a> memo from CMS as well as the <a href="/mss/IFOXDocs/Wipro's_Impact_Analysis_To_CMS_Software_Changes_February_2015.pdf" class="info" target="_blank">Wipro's Impact Analysis</a> document.
				<br><br>  
                Thank you
                <br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
MCareSupport@wipro.com	
				<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Version 17.03 of the Interface to MSS document- DELAYED****</span>													
				<br><br>					
					Please be advised that the implementation of version 17.03 of the Interface to MSS document software changes will be <b>delayed from Monday March 2nd, 2015 to Monday April 27th, 2015.</b> 
					This is to accommodate some of our clients with more time to fully prepare for the changes. Please contact our Helpdesk if you have any questions or concerns.
				<br><br>  
                Thank you
                <br><br>
Wipro HelpDesk
<br>
(877) 833-3499
<br>
MCareSupport@wipro.com	
				<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - President's Day Holiday ****</span>													
				<br><br>					
					Wipro offices will be closed on Monday, February 16, 2015 in observance of the President's Day. 
					All transactions will be submitted to CMS <b>as normal - at the regular scheduled times.</b> 
					Should any issue arises, please send an email to MCareSupport@Wipro.com. 
				<br><br>  

Wipro HelpDesk
<br>
(877)833-3499
<br>
MCareSupport@wipro.com	
				<br><br>
			</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Version 17.03 of the Interface to MSS document  ****</span>
													
				<br><br>
					Attached please find version 17.03 of the <a href="/mss/IFOXDocs/Interface_to_MSS_17_03.pdf" class="info" target="_blank">Interface to MSS</a> document. 
The following changes will be implemented on Monday March 2nd, 2015:
<br><br>
* Version 17.03 reflects changes that are meant to improve the processing and turnaround of both enrollment and eligibility files. Currently, when Plans submit data files containing invalid or missing header record information, the Wipro edits abort the process and the Wipro Helpdesk notifies the end-user that the file must be corrected and resubmitted. As of March 2nd, both automated FTP and manual Web upload file submissions will automatically reject all detail transactions when invalid header record information is submitted.
<br><br>
 1. For eligibility files, the HICN Found/Not Found field in position of 26 of the eligibility response file will have a new value of "F" (Failed) populated for all detail transactions. No eligibility match will be attempted against the Medicare beneficiary database.
<br><br>
 2. For enrollment file submissions, all detail transactions will be rejected with a new error code of "60". The file must be corrected to contain a valid header record adn resubmitted for processing.
<br><br>
* The edit requirement for the TC 90 Implementation date to be at least 30 days after the Notification date has been removed. The corresponding error code "3A" has beeen disabled.
<br><br>
* The editing of a 4RX TC 72 effective date has been improved by ensuring that the date falls within valid enrollment periods for the given contract. The historical CMS TRRs will be reviewed as necessary to accomplish this and help ensure that CMS does not generate a TRC "209" rejection response. Wipro will reject 72 transactions that do not show a valid enrollment period with a new error code of "59".
<br><br>

Wipro HelpDesk
<br>
(877) 833-3499
<br>
MCareSupport@wipro.com	
				<br><br>
	   				
	   				
				</td>
			</tr>
		</table>
		</td>
	</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>     
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice- 2014/2015 Holiday Schedule ****</span>													
				<br><br>					
					Our organization would like to take this opportunity to send you our warmest thoughts and best wishes
                    for a wonderful Holiday and a very Happy New Year.
                <br><br>
                    Our offices will be closed on Thursday, December 25, 2014 and Thursday, January 1, 2015 due to the 
                    obersavtion of the Christmas and New Year Holidays. All transactions wil be submitted to CMS <b>as normal, 
                    at the regular scheduled times.</b> Should any arise during these two days, please send an email to 
                    our Helpdesk at MCareSupport@wipro.com. 
				<br><br>  
					Thank you and Happy Holidays!
                <br><br>
                    Wipro HelpDesk
                    (877) 833-3499
                    MCareSupport@wipro.com
				<br><br>
				</td>
			</tr>
		</table>
		</td>
	</tr>




<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
     <tr>
<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro - Thanksgiving Holiday Schedule ****</span>													
				<br><br>					
					Wipro offices will be closed on Thursday, November 27, 2014 and Friday November 28, 2014. 
                <br><br>
                    Submission schedule will remain normal on both days. Should any issues arise during these two days, please contact the Wipro Helpdesk at MCareSupport@wipro.com. 
				<br><br>  
					Thank you and have a safe Happy Thanksgiving!
                <br><br>
                    Wipro HelpDesk
                    MCareSupport@wipro.com
				<br><br>
				</td>
			</tr>
		</table>
		</td>
	</tr>




<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
				<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Important Notice Regarding 11/16/14 DTRR - ACTION REQUIRED****</span>													
				<br><br>					
					Please refer to the CMS memo below regarding TRC 245: 
				<br><br>
					**********************************************************************************************************************				
					Please do not reply to this message. This is an announcement e-mail only.				
					**********************************************************************************************************************
					This e-mail is sent out on behalf of the Centers for Medicare and Medicaid Services (CMS).
                    Please be advised that due to 2015 New Year Processing activities, the Daily Transaction Reply Report (DTRR)
                    for Novenber 16, 2014 included TRC 245, "Member has MSP perios." TRC 245 was not intended for includsion on this DTRR. 
                    Because of this, beneficiary information was disseminated along with TRC 245 on the November 16th DTRR. <font color = "red"><b>CMS is requesting
                    that Plans permanently delete the incorrect data and provide confirmation that the data was deleted to the MAPD Help Desk
                    at mapdhelp@cms.hhs.gov with the subject line, "Data Deletion Confirmed."</b></font>
       <br><br>
                    Please note that this information was only received by Plans authorized to access data about Medicare beneficiaries and was
                    delivered via secure channels. but CMS appreciates prompt action in regards to this matter.
       <br><br>
                   Please direct questions or concerns to the MAPD Help Desk at MAPDHelp@cms.hhs.gov or 1-800-927-8069.
                   Thank you,
       <br><br>
MAPD Help Desk
<br>
1-800-927-8069
<br>
MAPDHelp@cms.hhs.gov
<br>
http://www.cms.gov/mapdhelpdesk
			
					<br><br>  
				</td>
			</tr>
		</table>
		</td>
	</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
				<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Important Notice: November 15, 2014 - CMS DTRR Schedule and Outages ****</span>													
				<br><br>					
					Please refer to the CMS memo below for DTRR schedule and outages: 
				<br><br>
					**********************************************************************************************************************				
					Please do not reply to this message. This is an announcement e-mail only.				
					**********************************************************************************************************************
					This e-mail is sent out on behalf of the Centers for Medicare and Medicaid Services (CMS).
                    <br><br>
                    Due to special MARx processing this week, please be advised that the next DTRR may be delayed until Tuesday, November 18, 2014.
					<br><br>
					Please direct questions or concerns to the MAPD Help Desk at MAPDHelp@cms.hhs.gov or 1-800-927-8069.
       <br><br>
MAPD Help Desk
<br>
1-800-927-8069
<br>
MAPDHelp@cms.hhs.gov
<br>
http://www.cms.gov/mapdhelpdesk
			
					<br><br>  
				</td>
			</tr>
		</table>
		</td>
	</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
    <td width="25" valign="top"><img src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
       <td align="left"><span class="NewsHeading">**** - CMS Important Notice- MARx UI Availability 11/07/14 - 11/15/14 ****</span>
				<br><br>
					**********************************************************************************************************************				
					Please do not reply to this message. This is an announcement email only.				
					**********************************************************************************************************************
					This e-mail is sent out on behalf of the Centers for Medicare and Medicaid Services (CMS).
                    <br>
					Due to November 2014 MAPD Software Release implementation and activities for the transition to CY 2015, please review the table below for the MARx UI schedule of availability from Friday, November 7, 2014 through Saturday, November 15, 2014. The MARx UI is expected to return to its normal operating schedule following the conclusion of these activities. Please note that all timeframes below are listed in Eastern Time.
					<br><br>

				<BR>
                
                <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <b>MARx UI Availability - 11/07/14 Through 11/15/14:</b> 
                <BR>
				<TABLE border="1">
					<TBODY>
						<TR>
							<TD><center><b>Start</b></center></TD>
                            <TD><center><b>End</b></center></TD>
							<TD><center><b>Availability Status</b></center></TD>
						</TR>
						<TR>
							<TD>11/7/2014 6:00</TD>
                            <TD>11/7/2014 20:00</TD>
							<TD>Available in UPDATE mode</TD>
						</TR>
						<TR>
							<TD>11/7/2014 20:00</TD>
                            <TD>11/9/2014 0:00</TD>
							<TD>Available in READ mode; MARx UI will not be available for a brief period during MARx month-end processing</TD>
						</TR>
						<TR>
							<TD>11/9/2014 0:00</TD>
                            <TD>11/9/2014 8:00</TD>
							<TD>Not available - Completely down</TD>
						</TR>
						<TR>
							<TD>11/9/2014 8:00</TD>
                            <TD>11/9/2014 19:00</TD>
							<TD>Available in READ mode</TD>
						</TR>
						<TR>
							<TD>11/9/2014 19:00</TD>
                            <TD>11/10/2014 12:30 AM (approximately)</TD>
							<TD>Not available - Completely down</TD>
						</TR>
						<TR>
							<TD>11/10/2014 0:30</TD>
                            <TD>11/13/2014 18:00</TD>
							<TD>Available in READ mode</TD>
						</TR>
						<TR>
							<TD>11/13/2014 18:00</TD>
                            <TD>11/13/2014 11:00 PM (approximately)</TD>
							<TD>Not available - Completely down</TD>
						</TR>
						<TR>
							<TD>11/13/2014 23:00</TD>
                            <TD>11/15/2014 6:00</TD>
							<TD>Available in READ mode</TD>
						</TR>
						<TR>
							<TD>11/15/2014 6:00</TD>
                            <TD>11/15/2014 21:30</TD>
							<TD>Available in UPDATE mode</TD>
						</TR>
					</TBODY>
				</TABLE>
				<br>
	        					Please direct questions or concerns to the MAPD Help Desk at MAPDHelp@cms.hhs.gov or 1-800-927-8069.					
					<br><br>
	    
<br><br>
MAPD Help Desk
<br>
1-800-927-8069
<br>
MAPDHelp@cms.hhs.gov
<br>
http://www.cms.gov/mapdhelpdesk
 
			</TR>
		</table>
  </td>
</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>  
       <td width="25" valign="top"><img src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
       <td align="left"><span class="NewsHeading">****Wipro Notice - CMS November 2014 Software Release ****</span>
       <br><br>
       Please find the Detail November 2014 Software Release Memo from CMS, as well as the Wipro's Impact Analysis document.   
       <br><br>
	   <a href="/mss/IFOXDocs/November_2014_Detail_Release_Memo.pdf" class="info" target="_blank">
	   Click here</a> to download a copy of CMS Detail November Software Release Memo.
       <br>
       <a href="/mss/IFOXDocs/Wipro_Impact_Analysis_to_CMS_November_2014_Software_Release.pdf" class="info" target="_blank">
	   Click here</a> to download a copy of the Wipro Impact Analysis to CMS November 2014 Software Release.
       <br><br>
	   Please contact the Wipro Helpdesk and/or your assigned BA if you have any questions/concerns.
       <br><br>
       Thank you
       <br><br>
       Wipro HelpDesk
       877-833-3499
       MCareSupport@wipro.com
					<br><br>  
				</td>
			</tr>
		</table>
		</td>
	</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
			   <td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
	   <td align="left"><span class="NewsHeading">****Wipro Notice - Special TRRs Have Been Received ****</span>
       <br><br>
	   CMS has issued the Special TRRs on 10/18 related to the re-assignment activities as part of the End-of-Year Processing. The special TRRs can be located under the File Transfer Menu::
	   <br><br>
	   <b>Plan Level Reports</b>
	   <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	   Annual and Special Plan Reports 
	   <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

       The naming convention for this report is:
       <br><br>
                 planid.SPCLTRD.D141017.Txxxxxxx

	   </td>
		</table>
  </td>
</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	</tr>
<table  width="100%"  border="0" cellspacing="0" cellpadding="5">

<tr>
  <td><BR>
	<table width="100%"  border="0" align="center" 

cellpadding="3" cellspacing="0">
     <tr>
       <td width="25" valign="top"><img 

src="/mss/jsp/Recon/images/news_icon.gif" width="14" 

height="16"></td>
       <td align="left"><span class="NewsHeading">**** Wipro Notice - 

End-of-Year Processing and other related information ****</span>
       <br><br>
	   Attached please find the <a 

href="/mss/IFOXDocs/EOY_Enrollment_and_Payment_Memo_2014_09222014_Final.pdf" class="info" 

target="_blank">
	   End-of-Year guidance</a> from CMS. Based on the guidance, please refer to the table below for important key dates:
	   <br><br>
	  
				<BR>
				<TABLE border="1">
					<TBODY>
						<TR>
							

<TD><center><b>Date</b></center></TD>
							

<TD><center><b>Item</b></center></TD>
						</TR>
						<TR>
							

<TD>October 03, 2014</TD>
							

<TD>October Plan Data Due Date</TD>
						</TR>
						<TR>
							

<TD>October 06, 2014</TD>
							

<TD>Begin submitting 2015 enrollment effective dates</TD>
						</TR>
						<TR>
							

<TD>October 06, 2014, no later than 5 PM EDT</TD>
							

<TD>Plans approved for renewal or crosswalk exceptions by CMS that 

require plan-submitted EOY activity must submit MARx transactions. 

(See section 2.B of the attachment) </TD>
						</TR>
						<TR>
							

<TD>October 13, 2014</TD>
							

<TD>Columbus Day holiday</TD>
						</TR>
						<TR>
							

<TD>October 15, 2014</TD>
							

<TD>Annual Enrollment Period (AEP) begins</TD>
						</TR>
						<TR>
							

<TD>Late October, 2014</TD>
							

<TD>Plans will receive special Transaction Reply Reports (TRRs) and 

other reports containing reassignment activity. Reassignment letters 

sent to beneficiaries.</TD>
						</TR>
						<TR>
							

<TD>November 07, 2014</TD>
							

<TD>November Plan Data Due Date</TD>
						</TR>
					                <TR>
							

<TD>November 10 and 11, 2014</TD>
							

<TD>CMS-generated rollover processing</TD>
						</TR>
						<TR>
							

<TD>December 05, 2014</TD>
							

<TD>December Plan Data Due Date</TD>
						</TR>
                                                                                                <TR>
							

<TD>December 07, 2014</TD>
							

<TD>AEP ends</TD>
						</TR>
						<TR>
							

<TD>January 9, 2015</TD>
							

<TD>January Plan Data Due Date </TD>
						</TR>
					</TBODY>
				</TABLE>
				<br>
	            To assist our clients with their EOY enrollment 

processing, Wipro/Infocrossing will be performing the followings:
	   
	   <br><br>
	   1. <u>All NON_AEP transactions with January 1, 2015 

effective date</u> that are uploaded beginning <font color = 

"red"><b>September 24, 2014</b> </font>will be held and will be 

released to CMS for processing on <b>October 6, 2014</b>.
	   <br><br>	   
	  2. <u>All CMS approved plan-submitted roll-over or service 

area reduction disenrollment transactions</u> that are uploaded 

between <font color = "red"><b>September 24, 2014</b></font>  and 

<font color = "red"><b>October 6, 2014</b> </font>will be released 

to CMS for processing on <b>October 6, 2014</b> no later than 12:00 

Noon PST. Please submit all relevant files to Wipro/Infocrossing prior 

to the October 6 deadline. CMS requires these files to be transmitted 

to the MARx system only on October 06, 2014 and all files must be 

received by Wipro/Infocrossing and ready for CMS submission prior to 

October 6.	   
	   <br><br>
	   3. <u>All AEP transactions with January 1, 2015 effective 

date</u> that are uploaded beginning on <font color = 

"red"><b>September 24, 2014 </b></font> will be held and will be 

released to CMS for processing on <b>October 15, 2014</b> right 

after midnight EDT.
	   <br><br>	   
	  4. <u>All 75 and 78 transactions with a January 1, 2015 

effective date</u> that are uploaded between <font color = 

"red"><b>September 24, 2014 </b></font> and <font color = 

"red"><b> November 7, 2014 </font> will be released to CMS for 

processing on <b>November 8th, 2014</b>.
	   <br><br>	   
	   <font color = "red"><b>****** Special processing for CMS 

Approved Roll-Over or Service Area Reduction transactions:</b> 

</font>
	   <br><br>
	   Please contact Wipro Helpdesk if you have roll-over or 

service area reduction disenrollment transactions to submit. Please 

note that these transactions cannot be mixed with regular MARx 

submissions and must be handled seperately. The following link on 

the Wipro/Infocrossing web portal will be made available for you to 

upload these transactions. Please contact our Helpdesk if you do not 

have these links:<br>

    <br>&nbsp;&nbsp;&nbsp;<t><t><font color="red">CMS Preapproved Rollover Transactions</font>
    <br>&nbsp;&nbsp;&nbsp;<t><t><font color ="green">Upload Data </font>


	   <br><br>	                
                   Please note that Wipro will not be able to accommodate 

this process through <u>manual input or FTP upload</u>. These 

transactions can only be processed via a batch file submission on the 

web portal.
                   <br><br>
                   Please send us any new contract plans and/or PBP's for 

2015 if you haven't done so. 	   
                   <br><br>
Please forward this announcement to other areas within your 

organization as you deem necesary. Thank you.
                   <br><br><br>
Wipro Helpdesk
877-833-3499
MCareSupport@wipro.com
 
			</TR>
		</table>
  </td>
</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
				<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro - Labor Day Holiday Schedule ****</span>													
				<br><br>					
					Wipro offices will be closed on Monday, Sept 1, 2014 in observance of the Labor Day holiday. All transactions will be submitted to CMS as normal - at the regular scheduled times. Should any issue arises, please send an email to the Wipro Helpdesk at MCareSupport@wipro.com.
				<br><br>  
					Thank you and have a safe Holiday!
				<br><br>
				</td>
			</tr>
		</table>
		</td>
	</tr>




<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
				<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Important Notice: July 4, 2014 - CMS Weekend Schedule and Outages ****</span>													
				<br><br>					
					Please refer to the CMS memo below for July 4th weekend schedule and outages: 
				<br><br>
					Subject: Important Notice: July 4, 2014 - Weekend Schedule and Outages
				<br><br>
					**********************************************************************************************************************				
					Please do not reply to this message. This is an announcement e-mail only.				
					**********************************************************************************************************************
					This e-mail is sent out on behalf of the Centers for Medicare and Medicaid Services (CMS).
					Please be advised that there will not be any Plan transaction processing on Saturday, July 5, 2014.
					Any Plan transaction files received after 9:00 PM (ET) on Friday, July 4, 2014 will be processed on Monday, July 7, 2014.
					Additionally, the MARx UI will be in read-only mode from approximately 9:30 PM (ET) on Friday, July 4, 2014 until 7:00 PM (ET) on Sunday, July 6, 2014.
					The MARx UI will return to update mode starting at 6:00 AM on Monday, July 7, 2014.
					Finally, there will not be a Daily Transaction Reply Report (DTRR) generated on Saturday, July 5, 2014 for transmission on Sunday, July 6, 2014.
					After the Saturday, July 5, 2014 transmission of the Friday, July 4, 2014 generated DTRR,
					the next DTRR will be generated on Monday, July 7, 2014 and will be transmitted in the early morning on Tuesday, July 8, 2014.
					<br><br>
					Please direct questions or concerns to the MAPD Help Desk at MAPDHelp@cms.hhs.gov or 1-800-927-8069.					
					<br><br>  
				</td>
			</tr>
		</table>
		</td>
	</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
				<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Extended Maintainence Window ****</span>													
				<br><br>					
					Please be advised that our weekly maintenance window will be extended for the following date: 
					<br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sunday 06/22/2014 		12:00 AM PST -  6:00 AM PST&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	
					<br><br>	
					During the period mentioned above, our website as well as scheduled batch jobs will be impacted. 
					Please pass this notice on to the impacted areas within your organization.
					We apologize for any inconvenience and appreciate your patience.
				<br><br>  
				</td>
			</tr>
		</table>
		</td>
	</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
				<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - CCM Cutoff - CMS Transmission Schedule ****</span>													
				<br><br>					
					This is a reminder that 05/31/2014 is the CCM cutoff. There will only be 2 transmission to CMS: 8:00AM PST and 2:00PM PST. Please have your transactions uploaded prior to 2:00PM PST.
				<br><br>  
				</td>
			</tr>
		</table>
		</td>
	</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
				<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Version 17.02 of the Interface to MSS document ****</span>
													
				<br><br>
					<a href="/mss/IFOXDocs/Interface_to_MSS_17_02.pdf" class="info" target="_blank">Attached please find an updated version of the Interface to MSS document</a>. 
					Version 17.02 reflects the addition of a disenrollment reason code of "50" as described by CMS in the Announcement of the <a href="/mss/IFOXDocs/CMS_May_2014_Software_Release_05_16_2014.pdf" class="info" target="_blank">May 2014 Software Release document</a>, under Section 4 - Removal of a Rolled Over Enrollment for a Future Date. 
					Page 24, section 2.1 of the attached document has been changed to reflect this new value. 
					The new disenrollment reason code will be implemented in our system on 5/28/2014.
				<br><br>
	   				
	   				
				</td>
			</tr>
		</table>
		</td>
	</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
				<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - CMS May 2014 Software Release ****</span>													
				<br><br>					
					Attached please find the <a href="/mss/IFOXDocs/Announcement_of_the_May_2014_Release.pdf" class="info" target="_blank">Announcement of the May 2014 Software Release Memo from CMS</a> as well as the <a href="/mss/IFOXDocs/Wipro_Impact_Analysis_May_2014_v2.pdf" class="info" target="_blank">Wipro's Impact Analysis</a> document.
					<br><br>	
					<br><br>
					Please contact the Wipro HelpDesk if you have any questions/concern.
				<br><br>  
				</td>
			</tr>
		</table>
		</td>
	</tr>

<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
				<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Extended Mainatinenece Window ****</span>													
				<br><br>					
					Please be advised that our weekly maintenance window will be extended for the following date: 
					<br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Saturday 04/05/2014 		12:00 AM PST&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	
					<br><br>	
					During the period mentioned above, our website may not be accessible; however, all scheduled batch jobs will not be impacted. 
					Please pass this notice on to the impacted areas within your organization. 
					We apologize for any inconvenience and appreciate your patience
				<br><br>  
				</td>
			</tr>
		</table>
		</td>
	</tr>

<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
				<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - President's Day Holiday ****</span>													
				<br><br>					
					Wipro offices will be closed on Monday, February 17, 2014 in observance of the President's Day. 
					All transactions will be submitted to CMS as normal - at the regular scheduled times. 
					Should any issue arises, please send an email to MCareSupport@Wipro.com. 
				<br><br>  
				</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
       <td width="25" valign="top"><img src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
       <td align="left"><span class="NewsHeading"> **** Wipro Notice - 2013 MTM Submission **** </span>
       <br><br>
	   		Per the <a href="/mss/IFOXDocs/2013-bene-level-mtmp-submissioninstructions_Final_01302014.pdf" class="info" target="_blank">attached CMS notice that was published on 01/30/2014,</a> the record length of the MTM file has changed. 
	   		We are in the process of updating our program to accommodate the new change and will be ready to accept and process your MTM files on Thursday 2/13/2014.
	   		Please use the following link under the File Transfer menu on the website to upload the MTM file:
	   		<br><br>
	   			Enrollment - MTM
	   		<br><br>
	   			Upload Data
	   		<br><br>	
	   			MTM Data Receipt
	   		<br><br>
	   			MTM CMS Response Download
	   		<br><br>
	   			There is no naming convention required. Once the file is uploaded, the receipt file will be available after couple of minutes for you to review.
	   			Please contact our Helpdesk if the above link is not available under your account.
	   		</td>
     </tr>
    </table>
  </td>
</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
       <td width="25" valign="top"><img src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
       <td align="left"><span class="NewsHeading"> **** Wipro Notice - Encounter (EDPS 5010) Software Enhancement Release **** </span>
       <br><br>
	   		The following items are new Encounters enhancements, which will be available to EDPS user on February 10, 2014. For additional information,please contact your Account Representative, or Customer Service at MCareSupport@Wipro.com or (877) 833-3499.
	   		<br><br>
	   			Professional Updateable Fields (Phase II) for increased ability to make corrections to encounter data.
	   		<br><br>
	   			Institutional Updateable Fields (Phase II) for increased ability to make corrections to encounter data.
	   		<br><br>	
	   			Export Report enhancement to display the service and submission date.
	   		<br><br>
	   			Log Detail enhancement displays both batch and web portal changes of a claim of specific revision number in the log history.
	   		<br><br>
	   			Dashboard and Encounter Details Screen enhancement now displays "DEL" records with "ACC" records on Dashboard. The "Deleted" status has been added to the "Encounter Details" search option.  
	   		<br><br>
	   			Web Portal changes include the number of records selected now displays modified the pagination. 
	   			Showing total record counts along with selected records below the claim list table.
	   			The total error counts of a claim are now also displayed on the Web Portal.
	   		<br><br>
	   			Encounter data export specifications now displays "ENC Type" i.e. DME/Institutional/Physician in the export report area.
	   		</td>
     </tr>
    </table>
  </td>
</tr>

<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
				<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Member360 Software Enhancement Release ****</span>
													
				<br><br>					
					For additional details, 					
					<a href="/mss/IFOXDocs/Jan_Notice.doc" class="info" target="_blank">please refer to the attached release notes.</a> 
				<br><br>
	   				
	   				
				</td>
			</tr>
		</table>
		</td>
	</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
				<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Extension of the Reporting Identified Drug Utilizes Requirement Announced in the February 2014 Software Release ****</span>
													
				<br><br>					
					Please be advised that the implementation of the new requirement for the Reporting Identified 
					Drug Utilizers to CMS will be extended for one-month from the original Feb live date. 					
					<a href="/mss/IFOXDocs/Extension_Overutilizers_Requirement.pdf" class="info" target="_blank">Please refer to the attached CMS notice for more details.</a> 
				<br><br>
	   				
	   				
				</td>
			</tr>
		</table>
		</td>
	</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
				<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Version 17.01 of the Interface to MSS document ****</span>
													
				<br><br>
					<a href="/mss/IFOXDocs/Interface_to_MSS_Jan2014.pdf" class="info" target="_blank">Attached please find</a> version 17.01 of the Interface to MSS document. 
					Included in this version are the valid values for Transaction Code 90 data elements 
					"POS Drug Edit Class" and "POS Drug Edit Code" which were obtained from CMS. 
					Section 2.3 on page 34 lists the required values of "OPI" and "PS1" or "PS2".
				<br><br>
	   				
	   				
				</td>
			</tr>
		</table>
		</td>
	</tr>

<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
				<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro
				Notice - CMS February 2014 Software Release****</span> <br>
					
				<b>Attached please find the following documents that are related to the February 2014 Release:</b> <br>
				<br><br>				
				1.&nbsp;&nbsp;&nbsp;CMS Announcement of the February 2014 Release Memo. <br>
				&nbsp;&nbsp;&nbsp;&nbsp;<a href="/mss/IFOXDocs/Updated_February_2014_Detail_Release_Memo_FINAL.PDF" class="info" target="_blank">
	   CMS announcement for important information regarding the changes.</a> <br>
				2.&nbsp;&nbsp;&nbsp;Wipro System Impact Analysis <br>
				&nbsp;&nbsp;&nbsp;&nbsp;<a href="/mss/IFOXDocs/Wipro_Impact_Analysis_Feb_2014_Changes_12-16-13.pdf" class="info" target="_blank">
	   Please refer to the impact/changes under each product.</a> <br>
				3.&nbsp;&nbsp;&nbsp;Interface to MSS - version 17.0 <br>				
				&nbsp;&nbsp;&nbsp;&nbsp;<a href="/mss/IFOXDocs/Interface_to_MSS.pdf" class="info" target="_blank">
	   Please refer to the summary of changes on page 3.</a> <br>
				<br><br>
				<u>Please Note:</u>
	   We are waiting to get clarification from CMS on some of the values for the new fields. 
	   Another notification will be sent out once we receive the info from CMS.
	   <br>
				
				</td>
			</tr>
		</table>
		</td>
	</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
				<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** Wipro Notice - Thanksgiving Holidays Schedule and Enrollment Processing ****</span>
													
				<br><br>
					Wipro offices will be closed on Thursday, November 28, 2013 and Friday November 29, 2013 
				due to the observation of the Thanksgiving Holidays. Submission schedule will remain normal on both days. 
				Should any issues arise during these two days, please contact the WiproHelpdesk at MCareSupport@Wipro.com
				<br><br>
	   				Have a Safe and Happy Thanksgiving!
	   				<br>
	   				
				</td>
			</tr>
		</table>
		</td>
	</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
				<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** 11/18/2013 - Wipro Notice - Members Not On TRRs Issue****</span>
													
				<br><br>
				It was brought to our attention that transactions which Wipro submitted to CMS from 11/13 to present have not been returned on the TRRs. 
				We have contacted CMS Helpdesk several times since Friday and have opened multiple tickets. 
				As of this morning, CMS told us that the tickets have been escalated and they are still researching the issue. 
				They are unable to provide any timeframe or next steps. We were also told that Plans will not have any compliance issue since CMS is aware of the problem. 
				We understand the impact of this issue on our clients and we are doing everything we can to expedite the issue at CMS. Please reference ticket 2601537 when calling into the CMS Helpdesk. 
				We will keep you posted when we hear back from CMS.
				<br><br>
				
	   
				</td>
			</tr>
		</table>
		</td>
	</tr>


<tr>
		<td height="1" bgcolor="#999999"></td>
	</tr>

	<tr>
		<td><BR>
		<table width="100%" border="0" align="center" cellpadding="3"
			cellspacing="0">
			<tr>
				<td width="25" valign="top"><img
					src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
				<td align="left"><span class="NewsHeading">**** 11/06/2013 - Wipro
				Notice ****</span> <br>
					
				<b>Notice to EDPS clients</b> <br>
				<br><br>
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				1.&nbsp;&nbsp;&nbsp;PACE Organization are only required to submit encounters for services provided by January 1, 2013. <br>
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				2.&nbsp;&nbsp;&nbsp;CMS does not required PACE Organization to submit any encounters for service for claim that are not collected <br>
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				3.&nbsp;&nbsp;&nbsp;CMS primary focus is to target to collect encounters for 2016 <br>
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				4.&nbsp;&nbsp;&nbsp;CMS will provide more information for these services provided at a later date<br>
				<br><br>
	   Please Refer to the CMS Memos, <a href="/mss/IFOXDocs/HPMSNoticeDefaultDataDefinitionFinal.pdf" class="info" target="_blank">
	   HPMS Notice Default Data Definition Final</a> , <a href="/mss/IFOXDocs/HPMSHIPPSCodeDelayNotice110413final.pdf" class="info" target="_blank">
	   HPMS HIPPS Code Delay Notice</a> , <a href="/mss/IFOXDocs/HPMSEDSubmissionsNotice.pdf" class="info" target="_blank">
	   HPMS ED Submissions Notice</a> .
	   <br>
				
				</td>
			</tr>
		</table>
		</td>
	</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
       <td width="25" valign="top"><img src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
       <td align="left"><span class="NewsHeading">**** 09/23/2013 - Wipro/InfoCrossing Notice - End-of-Year and other related information ****</span>
       <br><br>
	   Attached please find the <a href="/mss/IFOXDocs/2013EOY-20130917.pdf" class="info" target="_blank">
	   End-of-Year guidance</a> from CMS. Based on the guidance, please refer to the table below for important key dates:
	   <br><br>
	   To assist our clients with their EOY enrollment processing, Wipro will be holding the following transactions:
	   <br>
				<BR>
				<TABLE border="1">
					<TBODY>
						<TR>
							<TD><center><b>Date</b></center></TD>
							<TD><center><b>Item</b></center></TD>
						</TR>
						<TR>
							<TD>October 04, 2013</TD>
							<TD>October Plan Data Due Date</TD>
						</TR>
						<TR>
							<TD>October 04, 2013</TD>
							<TD>Begin submitting 2014 enrollment effective dates</TD>
						</TR>
						<TR>
							<TD>October 07, 2013, no later than 5 PM EDT</TD>
							<TD>Plans approved for renewal or crosswalk exceptions by CMS that require plan-submitted EOY activity must submit MARx transactions. (See section 2.B of the attachment) </TD>
						</TR>
						<TR>
							<TD>October 08, 2013, no later than 11:59 p.m. EDT</TD>
							<TD>Plans must report to CMS the status of their submission based on the MARx reply reports.</TD>
						</TR>
						<TR>
							<TD>October 14, 2013</TD>
							<TD>Columbus Day holiday</TD>
						</TR>
						<TR>
							<TD>October 15, 2013</TD>
							<TD>Annual Enrollment Period (AEP) begins</TD>
						</TR>
						<TR>
							<TD>On or about October 18, 2013</TD>
							<TD>Plans will receive special Transaction Reply Reports (TRRs) and other reports containing reassignment activity. CMS will begin to send blue reassignment letters to beneficiaries.</TD>
						</TR>
						<TR>
							<TD>November 08, 2013</TD>
							<TD>November Plan Data Due Date</TD>
						</TR>
						<TR>
							<TD>December 04, 2013</TD>
							<TD>December Plan Data Due Date</TD>
						</TR>
						<TR>
							<TD>December 05-06, 2013</TD>
							<TD>CMS-generated rollover processing</TD>
						</TR>
						<TR>
							<TD>December 06- 07, 2013</TD>
							<TD>Plans receive TRCs on daily TRR created by CMS-generated rollover and termination processing.</TD>
						</TR>
						<TR>
							<TD>December 07, 2013</TD>
							<TD>AEP ends</TD>
						</TR>
						<TR>
							<TD>Mid-December, 2013</TD>
							<TD>Second Loss-of-Low-Income-Subsidy file sent indicating those beneficiaries who still no longer have the LIS as of January 01, 2014.</TD>
						</TR>
						<TR>
							<TD>January 10, 2014</TD>
							<TD>January Plan Data Due Date </TD>
						</TR>
					</TBODY>
				</TABLE>
				<br>
	            To assist our clients with their EOY enrollment processing, Wipro will be holding the following transactions:
	   
	   <br><br>
	   1. <u>All NON_AEP transactions with January 1, 2014 effective date</u> that are uploaded beginning <font color = "red"><b>September 19, 2013</b> </font>will be held and will be released to CMS for processing on <b>October 5, 2013</b>.
	   <br><br>	   
	  2. <u>All CMS approved plan-submitted roll-over transactions</u> that are uploaded between <font color = "red"><b>September 30, 2013</b></font>  and <font color = "red"><b>October 7, 2013</b> </font>will be released to CMS for processing on <b>October 7, 2013</b> no later than 5:00PM EDT **** please see instruction below.	   
	   <br><br>
	   3. <u>All AEP transactions with January 1, 2014 effective date</u> that are uploaded beginning on <font color = "red"><b>September 19, 2013 </b></font> will be held and will be released to CMS for processing on <b>October 15, 2013</b> right after midnight EDT.
	   <br><br>	   
	  4. <u>All 75s and 78s transactions with a January 1, 2014 effective date</u> that are uploaded between <font color = "red"><b>September 20, 2013 </b></font> and <font color = "red"><b> November 8, 2013 </font> will be released to CMS for processing on <b>November 9th, 2013</b>.
	   <br><br>	   
	   <font color = "red"><b>****** Special processing for CMS Approved Roll-Over transactions:</b> </font>
	   <br><br>
	   Please contact Wipro Helpdesk if you have roll-over transactions to submit. The following link will be made available for you to upload the rollover transactions:<br>
    <br>&nbsp;&nbsp;&nbsp;<t><t><font color="red">CMS Preapproved Rollover Transactions</font>
    <br>&nbsp;&nbsp;&nbsp;<t><t><font color ="green">Upload Data </font>
	   <br><br>	                
     Please note that Wipro will not be able to accommodate this process through <u>manual input or FTP upload</u>.     
	   </td>
     </tr>
			<TR>
				<TD width="25" valign="top"></TD>
				<TD align="left"></TD>
			</TR>
		</table>
  </td>
</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
       <td width="25" valign="top"><img src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
       <td align="left"><span class="NewsHeading"> **** 08/29/2013 - Wipro Notice - Long Term Institutionalized Resident Report **** </span>
       <br><br>
	   		Please refer to the below CMS memo regarding the LTI report:
	   		<br><br>
	   			The third 2013 Long-Term Institutionalized (LTI) Resident Report will be distributed to Plans on August 30, 2013.  Your organization will only receive an LTI Resident Report if you have LTI enrollees.  This report will be distributed to each Part D sponsor through the secure CMS Enterprise File Transfer (EFT) process.
	   			The report can be retrieved using your existing Gentran or Connect:Direct service.  If your organization utilizes the services of a third party vendor for Gentran or Connect:Direct access, please notify them that you may be receiving this report.
	   		<br><br>
	   			If you have any questions concerning this memorandum, please send an e-mail to PartDMetrics@cms.hhs.gov. Include "LTI Resident Report" in the subject line.
	   		<br><br>
	  			For any technical inquiries related to Gentran or Connect:Direct, please contact the MMA Help Desk at 1-800-927-8069 or mapdhelp@cms.hhs.gov.
	   		</td>
     </tr>
    </table>
  </td>
</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
       <td width="25" valign="top"><img src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
       <td align="left"><span class="NewsHeading">**** 08/15/2013 - Wipro Notice - Special TRR Notice From CMS ****</span>
       <br><br>
	   Some Plans received Transaction Reply Code (TRC) 705 "UI Enrollment Plan Benefit Package (PBP) Correction" with blank effective dates on their Daily Transaction Reply Report (DTRR).
	   <br><br>
	   On April 21, 2013, CMS corrected an issue where field 18 Effective Date (position 63-70) and field 24 End Date (position 85-92), if applicable, on the DTRR was blank; therefore, the issue will not happen going forward. 
	   This issue was addressed under Remedy ticket 2184488. On August 15, 2013, CMS ran a cleanup for this issue. A Special Transaction Reply Report (STRR) will be sent to the Plans on August 16, 2013. 
	   During normal processing, TRC 705 may be accompanied by several other TRCs such as 704, 121, 268, 269, etc. The STRR will not include these TRCs because they were previously provided on the applicable DTRR.
	   In some instances, the STRR will include TRC 709 "UI Moved Start Date Earlier." For TRC 709, field 18 will be the Effective Date (position 63-70) and field 24 (position 85-92), the end date, will be populated with the "enrollment period start date prior to the start date change."
	   <br><br>
	   The STRR will contain the entire set of the impacted beneficiaries. The naming convention for the STRR is: 
	   <br><br>
	    Gentran or TIBCO mailbox:
        P.Rxxxxx.SPCLTRD.Dyymmdd.Thhmmsst.pn 
	   <br><br>	                
        Connect:Direct (Mainframe):
        zzzzzzzz.Rxxxxx.SPLCTRD.Dyymmdd.Thhmmsst
       <br><br>
       	Connect:Direct (Non-Mainframe):
       	[directory]Rxxxxx.SPLCTRD.Dyymmdd.Thhmmsst 
	   </td>
     </tr>
    </table>
  </td>
</tr>

<!-- <tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
       <td width="25" valign="top"><img src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
       <td align="left"><span class="NewsHeading">**** 07/03/2013 - Wipro Notice - Independence Day Holiday Schedule ****</span>
       <br><br>
	   Wipro offices will be closed Thursday, July 4, 2013 in the observance of Independence Day. All transactions will be submitted to CMS
	   <b>as normal - at the regular scheduled times.</b> Should any issues arise, please send an email to the Wipro Helpdesk at <a class="info" href="mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>.
	   </td>
     </tr>
    </table>
  </td>
</tr>  -->

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
       <td width="25" valign="top"><img src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
       <td align="left"><span class="NewsHeading">**** 06/04/2013 - Wipro Notice - 2013 CMS August Software Release ****</span>
       <br><br>
	   <a href="/mss/IFOXDocs/Detail_August_2013_Software_Release_Memo.pdf" class="info" target="_blank">
	   Click here</a> to download a copy of CMS Detail August Software Release.
       <br>
       <a href="/mss/IFOXDocs/Wipro Impact Analysis August  2013_v3.pdf" class="info" target="_blank">
	   Click here</a> to download a copy of the Wipro Impact Analysis.
       <br><br>
	   CMS will be implementing the 2013 Summer software changes in the month of August. Please refer to the CMS Detail
	   August 2013 Software Release as well as Wipro Impact Analysis document for detailed information regarding changes.
	   <br><br>
	   Please contact the Wipro Helpdesk if you have any questions.
	   </td>
     </tr>
    </table>
  </td>
</tr>

<!-- <tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
       <td width="25" valign="top"><img src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
       <td align="left"><span class="NewsHeading">**** 05/24/2013 - Wipro Notice - Memorial Day Holiday ****</span>
       <br><br>
	   Wipro offices will be closed on Monday, May 27, 2013 in observance of the Memorial Day Holiday. All transactions will be submitted
	   to CMS <b>as normal - at the regular scheduled times.</b> Should any issue arise, please send an email to <a class="info" href="mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>.      
	   </td>
     </tr>
    </table>
  </td>
</tr>  -->

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
       <td width="25" valign="top"><img src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
       <td align="left"><span class="NewsHeading">**** 05/13/2013 - Wipro Notice - Special TRRs ****</span>
       <br><br>
	   CMS will be distributing the special TRRs that addressed an issue where Plans were receiving a TRC 014 (Disenrollment due to enrollment in
	   another Plan) on the DTRR with the incorrect end date (please refer to the CMS memo for more details). Per CMS, the Special TRRs will be issued on
	   May 13, 2013. Once received, the reports will be made available for downloading under the File Transfer menu on our website:
	   <br><br>
	   Plan Level Reports
	   <br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	   Annual and Special Plan Reports
	   <br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	   planid.SPLCTRD.Dyymmdd.Thhmmsst 	 
	   </td>
     </tr>
    </table>
  </td>
</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
       <td width="25" valign="top"><img src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
       <td align="left"><span class="NewsHeading">**** 05/10/2013 - Wipro Notice - Change on Effective Date Range for Transaction Type 78 ****</span>
       <br><br>
	   Per CMS, the effective date rule for the "78" transaction type is as follows:
	   <br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	   CPM - 3 to CPM + 2
	   <br><br>
	   TRC 171 will be returned on the TRR if the above effective date rule is not followed. The description for TRC 171 is <i>"The Effective Date on the transaction
	   types 78 must be in the CPM-3 to CPM+2 range."</i>
	   <br><br>
	   Wipro has updated its Enrollment pre-edit check to comply with this rule. The change will be implemented on Monday 5/13/2013. Please contact our Helpdesk
	   is you have any questions regarding the notice.
	   </td>
     </tr>
    </table>
  </td>
</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
       <td width="25" valign="top"><img src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
       <td align="left"><span class="NewsHeading">**** 05/01/2013 - Wipro Notice - CY 2014 Medication Therapy Management Program Guidance & Submission Instructions ****</span>
       <br><br>
	   <a href="/mss/IFOXDocs/MemoCY2014MTMP_04_05_13_fnl.pdf" class="info" target="_blank">
	   Click here</a> to download a copy of CMS memo regarding the Medication Therapy Management Program.
       <br><br>
	   Please take note of the following submission guidelines for MTM files:
	   <br>
	   <b>April 22, 2013</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Release of CY 2014 MTM Program submission module in HPMS 	
	   <br><br>
	   <b>May 6, 2013</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2014 MTM Program Submission Deadline
	   <br><b> 11:59 PM PDT</b>
	   <br><br>
	   <i>*Includes renewing the new applicant Medicare Advantage Prescription Drug Plans (MA-PDs) and stand-alone
	   Prescription Drug Plans (PDPs), and Medicare-Medicaid Plans (MMPs).</i>
	   <br><br>
	   Please refer to the guideline for additional information regarding the MTM process.
	   <br><br>
	   The MTM file can be uploaded using the following link under the File Transfer menu of the Wipro web portal:
	   <br><br>
	   Enrollment - MTM
	   <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	   <font style="background-color: yellow;">Upload Data</font> 
	   <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	   MTM Data Upload Receipt
	   <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	   MTM CMS Response Download
	   <br><br>
	   Please make sure to download and review the receipt file after uploading the MTM file. If the MTM section cannot be
	   found under your File Transfer menu, please contact our Helpdesk,
	   </td>
     </tr>
    </table>
  </td>
</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
       <td width="25" valign="top"><img src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
       <td align="left"><span class="NewsHeading">**** 04/26/2013 - Wipro Notice - Erroneus Negative Number of Uncovered Months (NUNCMO) Value Clean-up (RT 2046122) ****</span>
       <br><br>
	   CMS has distributed the Special TRR regarding the NUNCMO data clean-up. The special TRRs are distributed in the same manner
	   as the monthly reports and can be downloaded from our website under the File Transfer Menu:
	   <br><br>
	   <b>Plan Level Reports</b>
	   <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	   Annual and Special Plan Reports 
	   <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	   planID.SPLCTRD.Dyymmdd.Thhmmsst
	   </td>
     </tr>
    </table>
  </td>
</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
       <td width="25" valign="top"><img src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
       <td align="left"><span class="NewsHeading">**** 04/24/2013 - Wipro Notice - New PartD 2014 Bid Files ****</span>
       <br><br>
	   Wipro has received a new set of Part D 2014 Bid files from CMS. It looks like the data in this file is different than the last one CMS pushed out
	   couple of weeks ago. We have contacted the CMS Helpdesk for clarification but there is no information at this point. We will keep you posted as we hear
	   back from CMS. The new files are available for download from our website under the File Transfer Menu:
	   <br><br>
	   <b>Plan Level Reports</b>
	   <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	   Annual and Special Plan Reports 
	   <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	   planID.PARTD2014.D130422.T1922540
	   </td>
     </tr>
    </table>
  </td>
</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
       <td width="25" valign="top"><img src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
       <td align="left"><span class="NewsHeading">**** 03/29/2013 - Wipro Notice - Emergency Software Upgrade ****</span>
       <br><br>
	   Please be advised that an emergency network change is scheduled for this weekend outside of the normal maintenance window. There might
	   be an interruption to the network connectivity during the software upgrade. Please see below for the date/time in your time zone:
	   <br><br>
	   <b>Date/Time of Change</b>
	   <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	   -<b>Eastern Time zone:</b> Sunday March 31, Midnight - 2AM ET
	   <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	   -<b>Central Time zone:</b> Saturday March 30, 11PM - Sunday March 31, 1AM CT
	   <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	   -<b>Mountain Time zone:</b> Saturday March 30, 10PM - Sunday March 31, 12AM MT
	   <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	   -<b>Pacific Time zone:</b> Saturday March 30, 9PM - 11PM PT
	   </td>
     </tr>
    </table>
  </td>
</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
       <td width="25" valign="top"><img src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
       <td align="left"><span class="NewsHeading">**** 03/14/2013 - Wipro Notice - Extended Maintenance Window ****</span>
       <br><br>
	   Please be advised that our weekly maintenance window will be extended for the following date:
	   <br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	   -Sunday 4/07/2013 12 AM PT - 8 AM PT 
	   <br><br>
	   During the period mentioned above, our <u>website</u> as well as <u>FTP Batch Jobs</u> will be unavailable. Clients
	   who currently have scheduled batch jobs will be contacted by our FTP group to re-schedule as necessary. Please pass this on to the impacted
	   areas within your organization. We apologize for any inconvenience and appreciate your patience.
	   </td>
     </tr>
    </table>
  </td>
</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
       <td width="25" valign="top"><img src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
       <td align="left"><span class="NewsHeading">**** 03/06/2013 - Wipro Notice - CMS Outages for March 9, 2013 to March 10, 2013 ****</span>
       <br><br>
	   Per CMS, there will be a Gentran, TIBCO, and Mainframe outage from Saturday, March 9, 2013, 10 PM until Sunday, March 10, 2013, 2 PM ET. This is due to system
	   maintenance. The following will be unavailable to Plan users for the duration of the outage: Gentran, TIBCO, and the CMS Mainframe. 
	   <br><br>
	   According to the MMA Helpdesk, the daily TRR will be issued as normal on Saturday 3/9 but the next one will not be issued until Tuesday 3/12. 
	   	</td>
     </tr>
    </table>
  </td>
</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
   <BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
     <tr>
       <td width="25" valign="top"><img src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
       <td align="left"><span class="NewsHeading">**** 03/04/2013 - Wipro Notice - 2013 Full Replacement Coordination of Benefits (COB) Files ****</span>
       <br><br>
	   Per CMS, this is a reminder to sponsor staff responsible for the receipt and handling of COB files from CMS of the annual full replacement COB file process.
	   Each Part D plan will receive a full replacement COB file including both the record updates that would normally be included in the daily COB notification
	   files and the full replacement COB data for all enrollees with other coverage. We expect to issue the combined daily update and fulle replacement COB files to plan sponsors
	   during the week of Marth 11th. Due to file size constraints, sponsors with a large number of Part D enrolless with other coverage may received multiple COB files
	   over the period. As previously, these files will contain no special identifiers to distinguish them from the normal daily COB notification files, but they may be identifiable
	   based on the date of receipt and the large size of the files.
	   <br><br>
	   Please direct questions or concerns to the MAPD Helpdesk at 1-800-927-8069 or <a class="info" href="mailto:mapdhelp@cms.hhs.gov">mapdhelp@cms.hhs.gov</a>.      
	   </td>
     </tr>
    </table>
  </td>
</tr>

<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
 <td>
   <BR>
   <table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
   <tr>
   <td width="25" valign="top"><img src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
   <td align="left"><span class="NewsHeading">**** INFOCROSSING NOTICES ****</span><br>
   <br>
   <a class="info" href="javascript:processAjax('/mss/html/InfocrossingNotices.html');">Click here for INFOCROSSING Notices</a>
   </td>
   </tr>
   </table>
  </td>
</tr>
                   
<tr><td height="1" bgcolor="#999999"></td></tr>

<tr>
  <td>
	<BR>
	<table width="100%"  border="0" align="center" cellpadding="3" cellspacing="0">
	<tr>
  	<td width="25" valign="top"><img src="/mss/jsp/Recon/images/news_icon.gif" width="14" height="16"></td>
    <td><span class="NewsHeading">**** CMS LETTERS &amp; MEMOS ****</span><BR>
	<a class="info" href="javascript:processAjax('/mss/html/CMSLettersAndMemos.html');">Click here for CMS letters and memos</a><br><br>
	</td>
	</tr>
	</table>
  </td>
</tr>
                               
</table>
</BODY>
</html>`;