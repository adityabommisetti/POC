import React from 'react';

import carouse1 from "../../assets/images/carousel-content-1new.png";
import carouse2 from "../../assets/images/carousel-content-2new.png";
import carouse3 from "../../assets/images/carousel-content-3new.png";

var __html = require('./latestNews.html.js');
var template = { __html: __html };
export const HomePage =()=>{


    return(

        <div className="container container-fixed">
                <div className="row">
                  <div className="col-md-12 mb-4">
                    <div
                      id="carouselExampleIndicators"
                      className="carousel slide"
                      data-ride="carousel"
                    >
                      <ol className="carousel-indicators">
                        <li
                          data-target="#carouselExampleIndicators"
                          data-slide-to="0"
                          className="active"
                        />
                        <li
                          data-target="#carouselExampleIndicators"
                          data-slide-to="1"
                        />
                        <li
                          data-target="#carouselExampleIndicators"
                          data-slide-to="2"
                        />
                      </ol>
                      <div className="carousel-inner">
                        <div className="carousel-item active">
                          <img src={carouse1} alt="" />
                          <div className="carousel-caption">
                            <h3>
                              4000 plus healthcare associates across the globe.
                            </h3>
                          </div>
                        </div>
                        <div className="carousel-item">
                          <img src={carouse2} alt="" />
                          <div className="carousel-caption">
                            <h3>
                              Health settle more than $15 billion claims
                              annually.
                            </h3>
                          </div>
                        </div>
                        <div className="carousel-item">
                          <img src={carouse3} alt="" />
                          <div className="carousel-caption">
                            <h3>99.75% Paperless claim submission.</h3>
                          </div>
                        </div>
                      </div>
                      <a
                        className="carousel-control-prev"
                        href="#carouselExampleIndicators"
                        role="button"
                        data-slide="prev"
                      >
                        {" "}
                        <span
                          className="carousel-control-prev-icon"
                          aria-hidden="true"
                        />
                        <span className="sr-only">Previous</span>
                      </a>
                      <a
                        className="carousel-control-next"
                        href="#carouselExampleIndicators"
                        role="button"
                        data-slide="next"
                      >
                        {" "}
                        <span
                          className="carousel-control-next-icon"
                          aria-hidden="true"
                        />
                        <span className="sr-only">Next</span>
                      </a>
                    </div>
                  </div>
                </div>
                <div className="row">
                  <div className="col-md-12 mb-4">
                    <div className="box-item1">
                      <h3>Annoucements</h3>
                      <hr />
                      <div className="content-box">
                       {/* hcf0241a */}
 
                       <span dangerouslySetInnerHTML={template} />

                      
    { /* <div>
        <table width="100%" border={0} cellSpacing={0} cellPadding={5}>
        <tr>
              <td height={1} bgcolor="#999999" />  
            </tr>
            <tr>
              <td><br />
                <table width="100%" border={0} align="center" cellPadding={3} cellSpacing={0}>
                  <tbody><tr><td width={25} valign="top"><img src="/mss/jsp/Recon/images/news_icon.gif" width={14} height={16} /></td>
                      <td align="left"><span className="NewsHeading">**** Wipro Notice - Announcement of the May 2019 Software Release &amp; Wipro Impact Analysis ****</span>											
                        <br /><br />					
                        Good afternoon, please find below the following documents which contain details of the CMS May 2019 software release:
                        <br /><br />
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1. <a href="/mss/IFOXDocs/May_2019_Detail_Release_Memo_4_11_19.pdf" className="info" target="_blank">CMS Announcement of the May 2019 Software Release</a>
                        <br /><br />
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2. <a href="/mss/IFOXDocs/Wipro_Impact_Analysis_May_2019_Software_Release.pdf" className="info" target="_blank">Wipro Impact Analysis document</a>
                        <br /><br />
                        Please reach out to your designated Account Managers, Business Analyst and/or the Wipro Helpdesk if you have any questions regarding these documents.
                        <br /><br />
                        Thank you
                        <br /><br />
                        Wipro HelpDesk
                        <br />
                        (877) 833-3499
                        <br />
                        <a className="info" href="mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				
                        <br /><br />
                      </td>
                    </tr>
                  </tbody></table>
              </td>
            </tr>
            <tr>
              <td>
                <br />
                <table width="100%" border={0} align="center" cellPadding={3} cellSpacing={0}>
                  <tbody><tr>
                      <td width={25} valign="top"><img src="/mss/jsp/Recon/images/news_icon.gif" width={14} height={16} /></td>
                      <td align="left"><span className="NewsHeading">**** Wipro Notice - Interface to MSS document version 17.11****</span>											
                        <br /><br />					
                        Please find attached the newest version of the <a href="/mss/IFOXDocs/Interface_to_MSS_17_11.pdf" className="info" target="_blank">Interface to MSS</a> document (version 17.11). Please refer to page 3 of the document 
                        for a summary of the changes. Please reach out to your designated Account Managers and/or Business Analysts if you have any questions regarding the changes.
                        <br /><br /> 
                        Thank you
                        <br /><br />
                        Wipro HelpDesk
                        <br />
                        (877) 833-3499
                        <br />
                        <a className="info" href="mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				
                        <br /><br />
                      </td>
                    </tr>
                  </tbody></table>
              </td>
            </tr>
            <tr><td height={1} bgcolor="#999999" /></tr>
            <tr>
              <td>
                <br />
                <table width="100%" border={0} align="center" cellPadding={3} cellSpacing={0}>
                  <tbody><tr>
                      <td width={25} valign="top"><img src="/mss/jsp/Recon/images/news_icon.gif" width={14} height={16} /></td>
                      <td align="left"><span className="NewsHeading">**** Wipro Notice - 2016/2017 Holiday Schedule****</span>											
                        <br /><br />					
                        Wipro would like to thank you for your partnership and support throughout the year and wish you the very best during this Holiday season.
                        <br /><br />
                        We would like to inform you of our Holiday support schedule. Our offices will be closed on Monday, December 26th, 2016 and January 2nd, 2017 due to the observance of the Christmas and New Years Holidays. All transactions
                        will be submitted to CMS <b>as normal, at the regular scheduled times.</b> Should any issues arise during these two days, please send an email to our Helpdesk at <a className="info" href="mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>.
                        We will respond to your inquiries on the next business day. 
                        <br /><br /> 
                        Thank you and Happy Holidays!
                        <br /><br />
                        Wipro HelpDesk
                        <br />
                        (877) 833-3499
                        <br />
                        <a className="info" href="mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				
                        <br /><br />
                      </td>
                    </tr>
                  </tbody></table>
              </td>
            </tr>
            <tr><td height={1} bgcolor="#999999" /></tr>
            <tr>
              <td>
                <br />
                <table width="100%" border={0} align="center" cellPadding={3} cellSpacing={0}>
                  <tbody><tr>
                      <td width={25} valign="top"><img src="/mss/jsp/Recon/images/news_icon.gif" width={14} height={16} /></td>
                      <td align="left"><span className="NewsHeading">**** Wipro Notice - November CMS Software Release 2016 - Impact Analysis****</span>											
                        <br /><br />					
                        Attached please find the <a href="/mss/IFOXDocs/Wipro_Impact_Analysis_Nov_2016_Release.pdf" className="info" target="_blank">Wipro Impact Analysis</a> document.
                        <br /><br /> 
                        Thank you
                        <br /><br />
                        Wipro HelpDesk
                        <br />
                        (877) 833-3499
                        <br />
                        <a className="info" href="mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				
                        <br /><br />
                      </td>
                    </tr>
                  </tbody></table>
              </td>
            </tr>
            <tr><td height={1} bgcolor="#999999" /></tr>
            <tr>
              <td>
                <br />
                <table width="100%" border={0} align="center" cellPadding={3} cellSpacing={0}>
                  <tbody><tr>
                      <td width={25} valign="top"><img src="/mss/jsp/Recon/images/news_icon.gif" width={14} height={16} /></td>
                      <td align="left"><span className="NewsHeading">**** Wipro Notice - New Version of the Interface to MSS document due November CMD Software Release 2016****</span>											
                        <br /><br />					
                        The <a href="/mss/IFOXDocs/Interface_to_MSS_17_10.pdf" className="info" target="_blank">Interface to MSS</a> document has been updated with version 17.10 to reflect the CMS November 2016 Software changes as documented in the final <a href="/mss/IFOXDocs/November_2016_Detail_Software_Release_Memo.pdf" className="info" target="_blank">CMS HPMS</a> notice, dated September 09, 2016.
                        <br /><br />
                        The November software changes will be implemented on the November CPM cutoff date of Friday, November 11, 2016.
                        <b><i>The Wipro MBD eligibility updates, however will not occur until after CMS provides an updated MBD
                            eligibility file which is expected to occur on Tuesday, November 15, 2016.</i></b>
                        <br /><br />
                        Version 17.10 of the Interface to MSS document addresses the addition of the new fields pertaining to the 
                        beneficiaries' prior historical enrollments as well as teh addition of the Enrollment Source code for the 
                        beneficiaries' current enrollment.
                        <br /><br />
                        Summary of changes in version 17.10:
                        <br /><br />
                        &nbsp;&nbsp;&nbsp;1. Section 1 (Medicare Eligibility Inquiry) has been updated to include the new fields on the 
                        batch eligibility response file. <i>Page 19</i>.
                        <br /><br />
                        &nbsp;&nbsp;&nbsp;2. The web service layout has changed to accomodate the new plan enrollment fields. <i>Section 3 - page 60</i>.
                        <br /><br />
                        &nbsp;&nbsp;&nbsp;3. The Eligibility+ response file has been modified to include the new plan enrollment fields. <i>Section 5 - page 72</i>.
                        <br /><br />
                        &nbsp;&nbsp;&nbsp;4. These MBD field additions will also be reflected on the Eligibility tab of the Wipro websites.
                        <br /><br />
                        Thank you
                        <br />
                        Wipro HelpDesk
                        <br />
                        (877) 833-3499
                        <br />
                        <a className="info" href="mailto:MCareSupport@wipro.com">MCareSupport@wipro.com</a>				
                        <br /><br />
                      </td>
                    </tr>
                  </tbody></table>
              </td>
            </tr>
       
              
        
                </table></div>
   */}

  
                        {/* <p>
                          Lorem ipsum dolor sit amet, consectetur adipiscing
                          elit, sed do eiusmod tempor incididunt ut labore et
                          dolore magna aliqua. Quis ipsum suspendisse ultrices
                          gravida. Risus commodo viverra maecenas accumsan lacus
                          vel facilisis.{" "}
                        </p>

                        <p>
                          Lorem ipsum dolor sit amet, consectetur adipiscing
                          elit, sed do eiusmod tempor incididunt ut labore et
                          dolore magna aliqua. Quis ipsum suspendisse ultrices
                          gravida. Risus commodo viverra maecenas accumsan lacus
                          vel facilisis.{" "}
                        </p>

                        <p>
                          Lorem ipsum dolor sit amet, consectetur adipiscing
                          elit, sed do eiusmod tempor incididunt ut labore et
                          dolore magna aliqua. Quis ipsum suspendisse ultrices
                          gravida. Risus commodo viverra maecenas accumsan lacus
                          vel facilisis.{" "}
                        </p>

                        <p>
                          Lorem ipsum dolor sit amet, consectetur adipiscing
                          elit, sed do eiusmod tempor incididunt ut labore et
                          dolore magna aliqua. Quis ipsum suspendisse ultrices
                          gravida. Risus commodo viverra maecenas accumsan lacus
                          vel facilisis.{" "}
                        </p> */}
                      </div>
                    </div>
                  </div>
                </div>
                <div className="row">
                  <div className="col-md-12">
                    <div className="container-fluid panel-social-contact">
                      <div className="row panel-social-contact-row">
                        <div className="col-md-2">
                          <div className="logo-container">
                            <img src='/images/wipro-logo.png' alt="" />
                          </div>
                        </div>
                        <div className="col-md-7">
                          <p>
                            Wipro is a proven provider of IT services focused on
                            managing mission-critical IT systems for a variety
                            of enterprise customers across all industry
                            segments. With investment in people, process and
                            technology, Wipro is a pioneer in global data and
                            infrastructure management.
                          </p>
                        </div>
                        <div className="col-md-3">
                          <ul className="social">
                            <li>
                              <a
                                href="https://plus.google.com/+wipro/posts"
                                target="blank"
                              >
                                <i className="fa fa-google" />
                              </a>
                            </li>
                            <li>
                              <a
                                href="https://www.facebook.com/WiproTechnologies"
                                target="blank"
                              >
                                <i className="fa fa-facebook-square" />
                              </a>
                            </li>
                            <li>
                              <a
                                href="https://www.youtube.com/user/Wiprovideos"
                                target="blank"
                              >
                                <i className="fa fa-youtube-play" />
                              </a>
                            </li>
                            <li>
                              <a
                                href="https://www.linkedin.com/company/wipro"
                                target="blank"
                              >
                                <i className="fa fa-linkedin-square" />
                              </a>
                            </li>
                            <li>
                              <a
                                href="https://twitter.com/wipro"
                                target="blank"
                              >
                                <i className="fa fa-twitter" />
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
    )
} 
