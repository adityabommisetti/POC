import React from "react";
import { confirmAlert } from "react-confirm-alert";

const Modal = (message, submitForm, relogin, history) => {
  confirmAlert({
    closeOnClickOutside:false,
    customUI: ({ onClose } ) => {
      return (
        <div className="confirmDialog" >
          <h6>{message}</h6>

          <div className="container">
            <div class="row">
              <div class="col-4 offset-md-4  text-center">
                {relogin ? (
                  <button
                    class="btn  btn-primary  btn-lg "
                    variant="contained"
                    style={{ width: "80px" }}
                    onClick={() => {
                      submitForm(message);
                      onClose();
                    }}
                  >
                    OK
                  </button>
                ) : (
                  <button
                    class="btn  btn-primary  btn-lg "
                    variant="contained"
                    style={{ width: "80px" }}
                    onClick={() => {
                      onClose();
                      if (
                        message ===
                        "Password Reset Link sent to your email address"
                      )
                        window.location.replace("/login");
                    }}
                  >
                    OK
                  </button>
                  
                )}
                
              </div>
            </div>
          </div>
        </div>
      );
    },
  });
};

export default Modal;
