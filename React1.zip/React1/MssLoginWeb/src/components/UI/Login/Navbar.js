import React from "react";
import { Link } from "react-router-dom";

const Navbar = React.memo(() => {
  
  return (
    <nav className="login-header navbar-expand-md navbar-dark fixed-top bg-dark">
    <div className="container">
        <button className="navbar-toggler icon-menu" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        </button>
        <div className="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul className="navbar-nav mr-auto">
                <li className="nav-item active">	
                <Link to={"/login"} className="nav-link" >
                  Home <span className="sr-only">(current)</span></Link>
                </li>
                <li className="nav-item">   <a className="nav-link" href="/About">About Us</a>
                </li>
                <li className="nav-item">	<a className="nav-link" href="/Products">Products</a>
                </li>
                <li className="nav-item ">	<a className="nav-link" href="/Solutions">Solutions</a>
                </li>
                <li className="nav-item ">	<a className="nav-link" href="/Services">Services</a>
                </li>
                <li className="nav-item ">	<a className="nav-link" href="/Contact">Contact</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
  );
});

export default Navbar;
