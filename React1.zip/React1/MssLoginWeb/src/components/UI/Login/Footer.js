import React from "react";

const Footer = React.memo(() => {


    return (
        <footer className="footer">
        <div className="small container">
            <div className="row">
                <div className="col-md-6">
                    <p>&copy; 2019 Wipro LLC. All rights reserved.</p>
                    <p>2 Tower Center Boulevard, East Brunswick, NJ 08816</p>
                </div>
                <div className="col-md-6">
                    <ul className="footer-list">
                        <li><a href="/Home">Home</a>
                        </li>
                        <li><a href="/About">About Us</a>
                        </li>
                        <li><a href="/Products">Products</a>
                        </li>
                        <li><a href="/Solutions">Solutions</a>
                        </li>
                        <li><a href="/Services">Services</a>
                        </li>
                        <li><a href="/Contact">Contact</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    );
});

export default Footer;
