import React from "react";
const Contact = React.memo(() => {


    return (
        <div className="jumbotron margin-top2 margin-bottom-zero two-panel-bg">
        <div className="container">
            <div className="row">
                <div className="col-md-6 padding-lr-zero panel-container-left">
                    <div className="panel-container">
                        <h3>Contact Us</h3>
                        <p className="para-big">Please contact our Sales Team for more information or to schedule a demonstration of any of our proven solutions</p>
                        <p>
                            <button className="btn btn-secondary">Request Demo</button>
                        </p>
                    </div>
                </div>
                <div className="col-md-6 padding-lr-zero panel-container-right">
                    <div className="panel-container">
                        <h3>About Us</h3>
                        <p>Since 1986, Wipro Healthcare has excelled at providing quick, reliable, and cost-effective Departmental Support Services to Managed Care organizations throughout the United States. Our Online Eligibility and Enrollment System provides accurate and cost-effective access to Medicare entitlement verification and enrollment.</p>
                        <p>
                            <button className="btn btn-secondary">Know More</button>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    );
});

export default Contact;
