import { Link } from "react-router-dom";
import React from "react";

const LoginForm = React.memo((props) => {


    const BASE_PATH = process.env.PUBLIC_URL ? process.env.PUBLIC_URL : '';
    return (
        <div className="container padding-tb-1 loginTop">
            <div className="logo-container">
                <img src={BASE_PATH +'/images/wipro-logo.png'} alt='wipro logo' />
            </div>
            <div className="login-section">

                <h4 className="login-heading">Customer Login</h4>
                <span className='imp'>{props.errorMsg}</span>
                <form>
                    <div className="login-fields">

                        <input type="text" name="userName" placeholder="Username"
                            value={props.userName} onChange={props.handleChange}
                            className="form-control username" />
                        <input type="password" id="password" name="password" placeholder="Password"
                            value={props.password} onChange={props.handleChange}
                            className="form-control password" />
                        <button type="submit" id="loginBtn" className="btn btn-primary btn-login"
                            disabled={!(props.password && props.userName)}
                            onClick={props.loginHandler}
                        >Login</button>
                    </div>
                </form>

                <p className="forgot-password small">
                    Forgot your
                     <Link to={"/forgotpassword"} >
                      &nbsp; password</Link>?
					</p>

            </div>
        </div>
    );
});

export default LoginForm;
