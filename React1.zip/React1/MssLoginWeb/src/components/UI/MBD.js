import React from "react";


class MBD extends React.Component{
 state ={mbdAggChecked:false}

 handleChange =(event)=>{
   let check = event.target.checked;
   this.setState({mbdAggChecked:check});
 }
render(){
    return (
    <div className="container jumbotron mbd">
      <div className="row">
              <div className="col-md-2">
                <img
                  src="/images/wipro-logo.png"
                  alt="Wipro logo"
                  className="wipro-logo-pwd"
                />
              </div>{" "}
              <div className="col-md-8" style={{ marginTop: "2rem" }}>
              <h5 className="text-center">
     
              <u>MBD Aggrement</u>
              </h5>
              </div>
            </div>
      Access to the Beneficiary information contained on the Wipro MBD Inquiry
      Service is subject to the following CMS mandated rules: <br />
      <br />
      <ul className="list-group">
        <li className="list-group-item">
          1.Only Plans that have contracts (MA, MA-PD, and PDP) with CMS are
          permitted access to this information.
        </li>
        <li className="list-group-item">
          2.Plans may only use this data for the purpose of enrolling a
          Beneficiary into their MA, MA-PD, or PDP
        </li>
        <li className="list-group-item">
          3.All inquiries must be performed with a valid HIC number and at least
          the first six characters of the Beneficiaries last name
        </li>
      </ul>
      <br />
      <br />
      Acknowledgement of this notice is required for continued access to the
      information. I Agree to These Terms and Conditions: <input type='checkbox' 
       onClick ={this.handleChange} value={this.state.mbdAggChecked}/>
      <div className="mx-auto text-center">
        <button type="button" className="btn btn-primary"
        disabled={!this.state.mbdAggChecked}
        onClick={this.props.submit}>
          Submit
        </button>
        <p>I do not agree and wish to leave</p>
        <button type="button" className="btn btn-secondary" onClick={this.props.logout}>
          Exit
        </button>
      </div>
    </div>
    );
}
}
;

export default MBD;
