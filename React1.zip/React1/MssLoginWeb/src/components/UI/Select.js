import React from "react";

export const Select = React.memo((props) => {
  var optionList = props.optionList;
  return (
      <select className="form-control"
      value ={props.value}
      onChange={props.handleChange}>
        {optionList.map((option) => {
          return(<option value={option.value} selected={option.value===props.value}>{option.label}</option>)
        })}
      </select>
  );
});
