import React from 'react'

export const Footer =()=>{
    return( 
               <footer className="footer margin-top1">
    <div className="small container">
      <div className="row">
        <div className="col-md-5">
          <p>&copy; 2019 Wipro Technologies. All rights reserved. </p>
        </div>
      </div>
    </div>
  </footer>
)
}