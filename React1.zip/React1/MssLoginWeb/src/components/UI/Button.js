import React from "react";

export const Button = (props) => {
  return (
    <>
      <button
        type={props.type ? props.type :"button"}
        onClick={props.submit}
        className="btn btn-lg btn-primary spinner"
        disabled={props.disabled}
      
      >
        &nbsp;&nbsp;{props.label} &nbsp;&nbsp;
        {props.spinner ? (
          <div className="spinner-border spinner-border-sm" role="status">
            <span className="sr-only"></span>
          </div>
        ) : null}
      </button>
    </>
  );
};
