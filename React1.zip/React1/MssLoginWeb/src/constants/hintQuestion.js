export const HINT1_LIST = [

  {
    value: "BRN",
    label: "where were you born?"
  },
  {
    value: "CAR",
    label: "what was your first car?"
  },
  {
    value: "COL",
    label: "What is your favourite color?"
  },
  {
    value: "COU",
    label: "what country do you like to visit?"
  },
  {
    value: "DBF",
    label: "in what year was your Father born"
  },
  {
    value: "DBM",
    label: "in what year was your mother born"
  },
  {
    value: "HSM",
    label: "what was your high school mascot?"
  },
  {
    value: "MM",
    label: "What is your mother's maiden name?"
  },
  {
    value: "MNF",
    label: "What is your Father's middle name?"
  },
  {
    value: "MNM",
    label: "What is your mother's middle name?"
  },
  {
    value: "PET",
    label: "What was your first pet's name ?"
  }
];

export const HINT2_LIST = [

  {
    value: "BRN",
    label: "where were you born?"
  },
  {
    value: "CAR",
    label: "what was your first car?"
  },
  {
    value: "COL",
    label: "What is your favourite color?"
  },
  {
    value: "COU",
    label: "what country do you like to visit?"
  },
  {
    value: "DBF",
    label: "in what year was your Father born"
  },
  {
    value: "DBM",
    label: "in what year was your mother born"
  },
  {
    value: "HSM",
    label: "what was your high school mascot?"
  },
  {
    value: "MM",
    label: "What is your mother's maiden name?"
  },
  {
    value: "MNF",
    label: "What is your Father's middle name?"
  },
  {
    value: "MNM",
    label: "What is your mother's middle name?"
  },
  {
    value: "PET",
    label: "What was your first pet's name ?"
  }

];

export const HINT3_LIST = [

  {
    value: "BRN",
    label: "where were you born?"
  },
  {
    value: "CAR",
    label: "what was your first car?"
  },
  {
    value: "COL",
    label: "What is your favourite color?"
  },
  {
    value: "COU",
    label: "what country do you like to visit?"
  },
  {
    value: "DBF",
    label: "in what year was your Father born"
  },
  {
    value: "DBM",
    label: "in what year was your mother born"
  },
  {
    value: "HSM",
    label: "what was your high school mascot?"
  },
  {
    value: "MM",
    label: "What is your mother's maiden name?"
  },
  {
    value: "MNF",
    label: "What is your Father's middle name?"
  },
  {
    value: "MNM",
    label: "What is your mother's middle name?"
  },
  {
    value: "PET",
    label: "What was your first pet's name ?"
  }

];




