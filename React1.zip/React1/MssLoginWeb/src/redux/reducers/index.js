import * as ActionTypes from "../types/ActionValues";

import { combineReducers } from "redux";
import forgotPasswordReducer from "./ForgotPasswordReducer";
import loginReducer from "./LoginReducer";
import { spinnerReducer } from "./SpinnerReducer";
import E360loginReducer from "./E360Reducer"
import AnalyticsloginReducer from "./AnalyticsRedcers"

const appReducer = combineReducers({
  spinner: spinnerReducer,
  loginData: loginReducer,
  forgotPwdData: forgotPasswordReducer,
  E360login:E360loginReducer,
  AnalyticsReducer:AnalyticsloginReducer,
});

const rootReducer = (state, action) => {
  if (action.type === ActionTypes.LOGOUT_ACTION) {
    state = undefined
  }

  return appReducer(state, action)
}

export default rootReducer;
