import * as ActionTypes from "../types/ActionValues";

const initialState = {
  loginVo: {},
  authenticated: false,
  errorMsg: "",
};
export default function loginReducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.LOGIN_SUCCESS:
      return {
        loginVo: action.payload.object,
        servicesEnabled: action.payload.listObject,
        profiles: action.payload.profiles,
        authenticated: true,
        errorMsg: "",
        isPassExpired: action.payload.object.pwdExpired,
        mbdAggRequired: action.payload.object.mbdAggRequired,
        ssoUser: action.payload.object.ssoUser,
      };

    case ActionTypes.UPDATE_AGGREMENT:
      return {
        ...state,
        mbdAggRequired: false,
      };

    case ActionTypes.UPDATE_USER_INFO:
      return {
        ...state,

        loginVo: {
          ...state.loginVo,
          emailId: action.payload.data.emailId,
          hintAnswer: action.payload.data.hintAnswer,
          hintAnswer2: action.payload.data.hintAnswer2,
          hintAnswer3: action.payload.data.hintAnswer3,
          hintId: action.payload.data.hintId,
          hintId2: action.payload.data.hintId2,
          hintId3: action.payload.data.hintId3,
          lastName: action.payload.data.lastName,
          phoneNo: action.payload.data.phoneNo,
        },
      };

    case ActionTypes.LOGIN_FAILED:
      return {
        errorMsg: action.payload,
      };
    default:
      return state;
  }
}
