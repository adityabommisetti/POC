import * as ActionTypes from "../types/ActionValues";

const initialState = {
  loginVoAnalytics: "",
};
export default function AnalyticsloginReducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.LOGIN_ANALYTICS:
     
      return {
        loginVoAnalytics: action.payload,
      };

    default:
      return state;
  }
}
