import * as ActionTypes from "../types/ActionValues";


const initialState = { forgotPwdVo:{
  question:""
}
   , forgotPwdValid: {}, resetPwdVo: {}};
export default function forgotPasswordReducer(state = initialState, action) {
  switch (action.type) {

    case ActionTypes.FORGOT_PASS:
      return {
        ...state,
        forgotPwdVo:action.payload.data?action.payload.data:{}
      };
      
  
    case ActionTypes.FORGOT_PASS_VALIDATION:
      return {
        ...state,
        forgotPwdValid: action.payload
      };
    case ActionTypes.RESET_PASS:
      return {
        ...state,
        resetPwdVo: action.payload
      };
    default:
      return state;
  }
}
