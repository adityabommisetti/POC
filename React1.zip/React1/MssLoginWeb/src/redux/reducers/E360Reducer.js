import * as ActionTypes from "../types/ActionValues";

const initialState = {
  loginVoE360: "",
};
export default function E360loginReducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.LOGIN_E360:
      return {
        loginVoE360: action.payload,
      };

    default:
      return state;
  }
}
