import * as ActionTypes from "../types/ActionValues";
import * as URL from "../../services/API_URL";
import axios from "../../utils/axios";



function getRequest(API_URL, Success_Action) {
    return async (dispatch) => {
      const spin = dispatch({
        type: Success_Action,
        spin: true,
      });
  
      if (spin) {
        return axios
          .get(API_URL, {
           headers: { "x-auth-token": localStorage.getItem("token") },
          })
          .then((response) => {
            dispatch({ type: Success_Action, spin: false });
            if (response.status === 200) {
              dispatch({ type: Success_Action, payload: response.data });
              return response.data.message;
            } else {
              dispatch({ type: Success_Action, payload: [] });
            }
          })
  
          .catch((error) => {
            dispatch({ type: Success_Action, spin: false });
            if (error.response && error.response.data) {
              return error.response.data.message;
            }
          });
      }
      return "success";
    };
  }
  
  export const login360= ()=>{
    return getRequest(
    URL.LOGIN_E360,
    ActionTypes.LOGIN_E360
    )
  };