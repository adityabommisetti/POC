import * as ActionTypes from "../types/ActionValues";
import * as URL from "../../services/API_URL";

import axios from "../../utils/axios";

//Unsecured request  -TOken not required
function postRequest(API_URL, body, Success_Action) {
  return async (dispatch) => {
    return axios
      .post(API_URL, body)
      .then((response) => {
        if (response.status === 200) {
          dispatch({ type: Success_Action, payload: response.data==null?{}:response.data});
        } else {
          dispatch({ type: Success_Action, payload: [] });
        }
        return response && response.data.message;
      })

      .catch((error) => {
        console.log(error);
        return error && error.response && error.response.data.message;
      });
  };
}

export const forgotPassword = (userId) => {
  return postRequest(
    URL.FORGOTPASS  ,
    userId,
    ActionTypes.FORGOT_PASS
  );
};
export const forgotPasswordValidation = (params) => {
  return postRequest(
    URL.FORGOTPASS_VALIDATION,
    params,
    ActionTypes.FORGOT_PASS_VALIDATION
  );
};
export const resetPassword = (params) => {
  return postRequest(URL.RESETPASS, params, ActionTypes.RESET_PASS);
};

export const updateExpiredPwd = (params) => {
  return async (dispatch) => {
    return axios
      .post(URL.EXPIRED_PASS, params, {
        headers: { "x-auth-token": localStorage.getItem("token") },
      })
      .then((response) => {
        dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        return response && response.data.message;
      })
      .catch((error) => {
        dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        return error.response.data.message;
      });
  };
};

//Secured Request Token required
export const changepassword = (params) => {
  return async (dispatch) => {
    return axios
      .post(URL.CHANGEPASS, params, {
        headers: { "x-auth-token": localStorage.getItem("token") },
      })
      .then((response) => {
        dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        return response.data;
      })
      .catch((error) => {
        dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        return error.response.data;
      });
  };
};
