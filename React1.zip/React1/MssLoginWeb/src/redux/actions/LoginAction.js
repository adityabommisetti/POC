import * as ActionTypes from "../types/ActionValues";
import * as URL from "../../services/API_URL";

import axios from "../../utils/axios";

export const updateUserInfo = (userVO) => {
  return async (dispatch) => {
    return await axios
      .post(URL.UPDATE_USER_INFO, userVO, {
        headers: { "x-auth-token": localStorage.getItem("token") },
      })
      .then((response) => {
        if (response.status === 200) {
          dispatch({
            type: ActionTypes.UPDATE_USER_INFO,
            payload: response.data,
          });
        }
        dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        return response.data.message;
      })
      .catch((error) => {
        dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        return error.response.data.message;
      });
  };
};
export const autoLogin = () => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .get(URL.GET_USER_INFO, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          response.data.isPassExpired = false;

          if (response.status === 200) {
            dispatch({
              type: ActionTypes.LOGIN_SUCCESS,
              payload: response.data,
            });
          } else {
            localStorage.clear();
            dispatch({
              type: ActionTypes.LOGIN_FAILED,
              payload: response.data.message,
            });
          }

          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })
        .catch((error) => {
          localStorage.clear();
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        });
    }
    return "done";
  };
};

export const ssoLogin = (body) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .get(URL.SSO_LOGIN, {
          headers: {
            "x-auth-token": "Bearer " + body,
          },
        })
        .then((response) => {
          if (response.data.statusCode === 200) {
            var token = response.headers["x-auth-token"];
            localStorage.setItem("token", "Bearer " + token);
            localStorage.setItem("login", true);

            dispatch({
              type: ActionTypes.LOGIN_SUCCESS,
              payload: response.data,
            });
          } else {
            localStorage.clear();
            dispatch({
              type: ActionTypes.LOGIN_FAILED,
              errorMsg: response.data.message,
            });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return response.data;
        })
        .catch((error) => {
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          return error.response.data;
        });
    }
    return "done";
  };
};

export const loginAction = (loginBody) => {

  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      var authorizationBasic = window.btoa(
        loginBody.userId + ":" + loginBody.pwd
      );
      return axios
        .post(URL.LOGIN, "", {
          headers: { Authorization: "Basic " + authorizationBasic },
        })
        .then((response) => {
          if (response.status === 200) {
            var token = response.headers["x-auth-token"];
            localStorage.setItem("token", "Bearer " + token);

            localStorage.setItem("login", true);
            dispatch({
              type: ActionTypes.LOGIN_SUCCESS,
              payload: response.data,
            });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })
        .catch((error) => {
          localStorage.clear();
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
          try{
          dispatch({
            type: ActionTypes.LOGIN_FAILED,
            payload: error.response.data.message,
          });
        }
        catch(err){

        }
        });
     
    }
    return "done";
  };
};

export const logoutAction = () => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .get(URL.LOGOUT, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          localStorage.clear();
          dispatch({ type: ActionTypes.LOGOUT_ACTION });
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })
        .catch((error) => {
          console.log(error);
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        });
    }
    return "done";
  };
};

export const updateAggrement = (userId) => {
  return async (dispatch) => {
    const spin = await dispatch({
      type: ActionTypes.SET_SPINNER,
      payload: true,
    });
    if (spin) {
      return axios
        .post(URL.AGGREMTN_UPDATE + "/" + userId, null, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        })
        .then((response) => {
          if (response.status === 200) {
            dispatch({
              type: ActionTypes.UPDATE_AGGREMENT,
              payload: true,
            });
          }
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        })
        .catch((error) => {
          console.log(error);
          dispatch({ type: ActionTypes.SET_SPINNER, payload: false });
        });

      return "done";
    }
  };
};
