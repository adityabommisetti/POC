import React, { Component } from "react";
import { NotificationContainer } from "react-notifications";
import { connect } from "react-redux";
import { BrowserRouter, Redirect, Route, Switch } from "react-router-dom";
import "./App.css";
import "./assets/css/react-confirm-alert.css";
import LandingPage from "./components/Landing/LandingPage";
import LoginPage from "./components/LoginPage/LoginComp";
import ChangePassword from "./components/Password/ChangePassword";
import ForgotPassword from "./components/Password/ForgotPassword";
import ResetPassoword from "./components/Password/ResetPassoword";
import UserInfo from "./components/Password/UserInfo";
import { HomePage } from "./components/UI/HomePage";
import { Maintenence } from "./components/UI/Maintenence";
import MBD from "./components/UI/MBD";
import SsoComp from "./components/LoginPage/SsoComp";
import { SsoMessage } from "./components/UI/SsoMessage";
import ErrorBoundary from "./components/Error/ErrorBoundary";

import {
  autoLogin,
  loginAction,
  logoutAction,
  updateAggrement,
} from "./redux/actions/LoginAction";
import axios from "./utils/axios";
import Modal from "./components/UI/Modal/Modal";
import isEmpty from "lodash/isEmpty";
// import Test from "./test";
let objArry = [];
let winObj = null,
  edpobj = null,
  reportObj = null;
let oldUrl = null;

window.onunload = function () {
  if (!isEmpty(winObj)) {
    winObj.close();
  }
  if (!isEmpty(edpobj)) {
    edpobj.close();
  }
  if (!isEmpty(reportObj)) {
    reportObj.close();
  }
};
class App extends Component {
  constructor(props) {
    super(props);

    this.state = {
      userName: "",
      password: "",
      authenticated: true,
      errorMsg: "",
      loginUserName: "",
      customerName: "",
      sessionExpired: false,
      maintenence: false,
      ssoLogout: false,
      code: "",
    };

    let object = this;
    axios.interceptors.response.use(
      function (response) {
        var token = response.headers["x-auth-token"];
        //update the token - renow token case -JWT
        if (token) {
          localStorage.setItem("token", "Bearer " + token);
        }
        return response;
      },
      async function (error) {
        let redirect = JSON.parse(JSON.stringify(error));
        if (redirect.message == "Request failed with status code 500") {
          localStorage.clear();
          return Promise.reject(error);
          //  window.location.replace("/Maintenence");
          //  this.setState({ maintenence: true });
        }

        if (!error.response) {
          object.serverDown();
        }

        if (error.response) {
          const statusCode = error.response.status;
          localStorage.setItem("code", +statusCode);

          if (statusCode === 403) {
            const msg = error.response.data.message;
            Modal(msg);

            await object.handleError(msg, statusCode);
          }
          if (statusCode === 401 && !isEmpty(localStorage.token)) {
            object.logout();
            //alert("function is getting call ")
          }
        }

        return Promise.reject(error);
      }
    );
  }

  handleChange = (e) => {
    this.setState({
      [e.target.name]: e.target.value,
    });
  };

  autoLogin = () => {
    this.props.autoLogin();
  };

  serverDown = () => {
    localStorage.clear();
    this.setState({ maintenence: true });
  };

  loginHandler = async (e) => {
    e.preventDefault();
    const userName = this.state.userName.trim();
    const password = this.state.password.trim();

    let body = {
      userId: userName.toUpperCase(),
      pwd: password,
    };
    await this.props.loginAction(body);
  };

  logout = async () => {
    this.setState({
      userName: "",
      password: "",
    });
    if (this.props.loginData.ssoUser) {
      await this.setState({ ssoLogout: true });
      await this.props.logoutAction();
      await this.ssocloseAllTab();
    } else {
      await this.props.logoutAction();
      await this.closeAllTab();
    }
  };

  async ssocloseAllTab() {
    if (!isEmpty(winObj)) {
      await winObj.close();
    }

    if (!isEmpty(edpobj)) {
      await edpobj.close();
    }
    if (!isEmpty(reportObj)) {
      await reportObj.close();
    }
    await localStorage.clear();
    if (this.state.sessionExpired) {
      window.location.replace(
        "/ssoMessage/Your Account Logged out due to Session Expiry. Thank You"
      );
    }
    // await window.close();
    // console.log(this.props.history);
  }
  async closeAllTab() {
    /*  if (objArry.length > 0) {
      for (let i = 0; i < objArry.length; i++) {
        objArry[i].close();
        objArry.pop();
      }
    }*/

    if (!isEmpty(winObj)) {
      await winObj.close();
    }

    if (!isEmpty(edpobj)) {
      await edpobj.close();
    }
    if (!isEmpty(reportObj)) {
      await reportObj.close();
    }
    await localStorage.clear();
    // await window.close();
    // console.log(this.props.history);
    await window.location.replace("/");
  }

  handleNewTAb = (URL) => {
    // const istoken = localStorage.getItem("token");
    // if (istoken === null) {
    //   this.closeAllTab();
    // }
    if (localStorage.getItem("code") !== 403) {
      if (winObj != null) {
        if (!winObj.closed) {
          if (oldUrl !== URL && oldUrl !== null) {
            //if url changes

            winObj.close();
            winObj = window.open(
              URL,
              URL,
              "height=600,width=1338,top=50,resizable=yes,scrollbars=yes",
              false
            );
            oldUrl = URL;
          } else {
            winObj.focus();
            return winObj;
          }
        } else {
          //if close then reopen
          winObj = null;
          winObj = window.open(
            URL,
            URL,
            "height=600,width=1338,top=50,resizable=yes,scrollbars=yes",
            false
          );
          return winObj;
        }
      } else {
        //if new  url
        winObj = window.open(
          URL,
          URL,
          "height=600,width=1338,top=50,resizable=yes,scrollbars=yes",
          false
        );
        oldUrl = URL;
        objArry.push(winObj);
        return winObj;
      }
    }
  };
  handleNewTAbEDP = (URL) => {
    // const istoken = localStorage.getItem("token");
    // if (istoken === null) {
    //   this.closeAllTab();
    // }
    if (localStorage.getItem("code") !== 403) {
      if (edpobj != null) {
        if (!edpobj.closed) {
          if (oldUrl !== URL && oldUrl !== null) {
            //if url changes

            edpobj.close();
            edpobj = window.open(
              URL,
              URL,
              "height=600,width=1338,top=50,resizable=yes,scrollbars=yes",
              false
            );
            oldUrl = URL;
          } else {
            edpobj.focus();
            return edpobj;
          }
        } else {
          //if close then reopen
          edpobj = null;
          edpobj = window.open(
            URL,
            URL,
            "height=600,width=1338,top=50,resizable=yes,scrollbars=yes",
            false
          );
          return edpobj;
        }
      } else {
        //if new  url
        edpobj = window.open(
          URL,
          URL,
          "height=600,width=1338,top=50,resizable=yes,scrollbars=yes",
          false
        );
        oldUrl = URL;
        objArry.push(edpobj);
        return edpobj;
      }
    }
  };
  handlReproting = (URL) => {
    // const istoken = localStorage.getItem("token");
    // if (istoken === null) {
    //   this.closeAllTab();
    // }
    if (localStorage.getItem("code") !== 403) {
      if (reportObj != null) {
        if (reportObj.closed) {
          reportObj = window.open(
            URL,
            URL,
            "height=600,width=1338,top=50,resizable=yes,scrollbars=yes",
            false
          );
        } else {
          reportObj.focus();
          return reportObj;
        }
        return reportObj;
      } else {
        reportObj = window.open(
          URL,
          URL,
          "height=600,width=1338,top=50,resizable=yes,scrollbars=yes",
          false
        );

        objArry.push(reportObj);
        return reportObj;
      }
    }
  };
  handleNewTAbM = (URL) => {
    if (localStorage.getItem("code") !== 403) {
      if (winObj != null) {
        if (!winObj.closed) {
          if (oldUrl !== URL && oldUrl !== null) {
            //if url changes

            winObj.close();
            winObj = window.open(
              URL,
              URL,
              "height=600,width=1338,top=50,resizable=yes,scrollbars=yes",
              false
            );
            oldUrl = URL;
          } else {
            winObj.focus();
            return winObj;
          }
        } else {
          //if close then reopen
          winObj = null;
          winObj = window.open(
            URL,
            URL,
            "height=600,width=1338,top=50,resizable=yes,scrollbars=yes",
            false
          );
          return winObj;
        }
      } else {
        //if new  url
        winObj = window.open(
          URL,
          URL,
          "height=600,width=1338,top=50,resizable=yes,scrollbars=yes",
          false
        );
        oldUrl = URL;
        objArry.push(winObj);
        return winObj;
      }
    }
  };

  updateAggrement = async () => {
    await this.props.updateAggrement(this.props.loginData.loginVo.userId);
  };

  handleError = async (msg, statusCode) => {
    await localStorage.clear();
    await this.setState({
      errorMsg: msg,
      sessionExpired: true,
    });
    if (this.props.loginData.ssoUser) {
      this.ssocloseAllTab();
    } else {
      this.closeAllTab();
    }
  };

  render() {
    const { isLoading, loginData, isPassExpired } = this.props;

    return (
      <div>
        {isLoading ? <div id="cover-spin" /> : null}
        {this.state.sessionExpired
          ? Modal(
              this.state.errorMsg,
              () => {
                window.location.replace("/");
              },
              true,
              ""
            )
          : null}

        <NotificationContainer />
        <BrowserRouter basename={process.env.REACT_APP_ROUTER_BASE || ""}>
          <Switch>
            <Route path={`/resetpassword`} render={() => <ResetPassoword />} />
            <Route path={`/Maintenence`} render={() => <Maintenence />} />
            {/* <Route path={`/test`} render={() => <Test />} /> */}

            {this.state.maintenence ? <Maintenence /> : null}

            {loginData.mbdAggRequired ? (
              <MBD submit={this.updateAggrement} logout={this.logout} />
            ) : null}

            {isPassExpired ? (
              <LandingPage logout={this.logout}>
                <ErrorBoundary>
                  <ResetPassoword
                    logout={this.logout}
                    isExpired={true}
                    header="Password Expired Kindly Change"
                  />
                </ErrorBoundary>
              </LandingPage>
            ) : null}

            <Route
              path="/forgotpassword"
              exact
              render={() => <ForgotPassword />}
            />

            <Route
              path="/ssoMessage/:message"
              render={(props) => <SsoMessage {...props} />}
            />
            <Route
              path="/mbdaggrement"
              exact
              render={() => (
                <MBD logout={this.logout} submit={this.updateAggrement} />
              )}
            />

            <Route path="/sso/:token" exact render={() => <SsoComp />} />

            <div>
              {loginData.authenticated ? (
                <Redirect to="/landing" />
              ) : this.state.ssoLogout ? (
                <Redirect to="/ssoMessage/You have successfully logged out.Thank you." />
              ) : (
                <Redirect to="/login" from="/" />
              )}

              <Route
                path="/changepassword"
                render={() => (
                  <LandingPage
                    logout={this.logout}
                    handleNewTAbEDP={this.handleNewTAbEDP}
                  >
                    <ErrorBoundary>
                      <ChangePassword logout={this.logout} />
                    </ErrorBoundary>
                  </LandingPage>
                )}
              />

              <Route
                path="/landing"
                render={() => (
                  <LandingPage
                    logout={this.logout}
                    handleNewTAb={this.handleNewTAb}
                    handleNewTAbEDP={this.handleNewTAbEDP}
                    handlReproting={this.handlReproting}
                    handleNewTAbM={this.handleNewTAbM}
                    closeAllTab={this.closeAllTab}
                  >
                    <ErrorBoundary>
                      <HomePage />
                    </ErrorBoundary>
                  </LandingPage>
                )}
              />

              <Route
                path="/profile"
                render={() => (
                  <LandingPage
                    logout={this.logout}
                    handleNewTAb={this.handleNewTAb}
                    handleNewTAbEDP={this.handleNewTAbEDP}
                    handlReproting={this.handlReproting}
                    handleNewTAbM={this.handleNewTAbM}
                  >
                    <ErrorBoundary>
                      <UserInfo />
                    </ErrorBoundary>
                  </LandingPage>
                )}
              />

              <Route
                path="/login"
                exact
                render={() => (
                  <LoginPage
                    id="login"
                    loginHandler={this.loginHandler}
                    userName={this.state.userName}
                    autoLogin={this.autoLogin}
                    password={this.state.password}
                    handleChange={this.handleChange}
                    errorMsg={loginData.errorMsg}
                  />
                )}
              />
            </div>
          </Switch>
        </BrowserRouter>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    loginData: state.loginData,
    isPassExpired: state.loginData.isPassExpired,
    isLoading: state.spinner.isLoading,
  };
};

const mapDispatchToProps = {
  loginAction,
  logoutAction,
  autoLogin,
  updateAggrement,
};

export default connect(mapStateToProps, mapDispatchToProps)(App);
