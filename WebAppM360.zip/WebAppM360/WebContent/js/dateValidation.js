function validatedate(inputText) {
	var dateformat = /^(0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])[\/\-]\d{4}$/;
	if (dateformat.test(inputText.value)) {

		var opera1 = inputText.value.split('/');
		var opera2 = inputText.value.split('-');
		lopera1 = opera1.length;
		lopera2 = opera2.length;
		if (lopera1 > 1) {
			var pdate = inputText.value.split('/');
		} else if (lopera2 > 1) {
			var pdate = inputText.value.split('-');
		}
		var mm = parseInt(pdate[0]);
		var dd = parseInt(pdate[1]);
		var yy = parseInt(pdate[2]);
		var ListofDays = [ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ];
		if (mm == 1 || mm > 2) {
			if (dd > ListofDays[mm - 1]) {

				return false;
			}
		}
		if (mm == 2) {
			var lyear = false;
			if ((!(yy % 4) && yy % 100) || !(yy % 400)) {
				lyear = true;
			}
			if ((lyear == false) && (dd >= 29)) {
				return false;
			}
			if ((lyear == true) && (dd > 29)) {
				return false;
			}
		}
	} else {
		return false;
	}

}

function checkFDOM(dte, msg) {
	if (isFDOM(dte.value))
		return true;

	dte.focus();
	dte.select();
	return false;
}
function isFDOM(dte) {
	var yr;
	var mth;
	var day;
	var lastDom;

	var parts = dte.split("/");
	var day = parseInt(parts[1], 10);
	var month = parseInt(parts[0], 10);
	var year = parseInt(parts[2], 10);

	if (day < 10) {

		day = "0" + day;
	}
	if (month < 10) {

		month = "0" + month;
	}
	dte = month + "/" + day + "/" + year;
	if (dte.length != 10)
		return false;

	day = parseInt(dte.substring(3, 5), 10);
	if (day == 1)
		return true;

	return false;
}

function checkEmail(obj) {
	if (obj.value != "") {
		var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		if (!filter.test(obj.value)) {
		//	alert('Please provide a valid email address');
			obj.value = '';
			return false;
		}
	}
}

/**
 * 
 */
function formatDate(obj) {
	var date = obj.value;
	var no = /^\d{8}$/;
	if ((obj.value.match(no))) {
		date = date.replace(/(\d{2})(\d{2})(\d{4})/, "$1/$2/$3");
		obj.value = date;
		return true;
	}
}
function dateFormatting(obj) {
	formatDate(obj);
	validateDate(obj);
}

function isEmpty(fldvalue) {
	console.log(fldvalue);
	if ((fldvalue == null) || (fldvalue.trim().length == 0) || (fldvalue == ""))
		return true;
	return false;
}

function isAlphaNumeric(str) {
	var l;
	var c;

	l = str.length;
	while (--l >= 0) {
		c = str.charAt(l);
		if (!(((c >= 'a') && (c <= 'z')) || ((c >= 'A') && (c <= 'Z')) || ((c >= '0') && (c <= '9'))))
			return false;
	}
	return true;
}

function isNumeric(str) {
	var l;
	var c;

	l = str.length;
	while (--l >= 0) {
		c = str.charAt(l);
		if ((c < '0') || (c > '9'))
			return false;
	}
	return true;
}

function isRdoChecked(fld) {
	if (fld[0]) {
		for ( var i = 0; i < fld.length; i++) {
			if (fld[i].checked) {
				return true;
			}
		}
	} else {
		if (fld.checked) {
			return true;
		}
	}
	return false;
}

function todayDateVal(date) {
	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth() + 1;
	var yyyy = today.getFullYear();

	var parts = date.split("/");
	var day = parseInt(parts[1], 10);
	var month = parseInt(parts[0], 10);
	var year = parseInt(parts[2], 10);

	if (day < 10) {

		day = "0" + day;
	}
	if (month < 10) {

		month = "0" + month;
	}

	if (dd < 10) {
		dd = '0' + dd
	}
	if (mm < 10) {
		mm = '0' + mm
	}
	var today = mm + '/' + dd + '/' + yyyy;
	var date1 = month + '/' + day + '/' + yyyy;

	if (!(today == date1)) {
		return false;
	}
	return true;
}
function isValidDate(dateString) {

	var parts = dateString.split("/");
	var day = parseInt(parts[1], 10);
	var month = parseInt(parts[0], 10);
	var year = parseInt(parts[2], 10);
	if (month < 10) {
		month = "0" + month;
	}
	if (day < 10) {
		day = "0" + day;
	}

	dateString = month + "/" + day + "/" + year;
	if (!/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(dateString))
		return false;
	if (year < 1000 || year > 3000 || month == 0 || month > 12)
		return false;
	var monthLength = [ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ];
	if (year % 400 == 0 || (year % 100 != 0 && year % 4 == 0))
		monthLength[1] = 29;
	return day > 0 && day <= monthLength[month - 1];
}

//IFOX-00388353 - Summacare Web App CR Changes: Start
function isWhitespace (fldvalue)
{
	// Is fldvalue empty?
	if (isEmpty(fldvalue)) return true;

	// Search through string's characters one by one
	// until we find a non-whitespace character.
	// When we do, return false; if we don't, return true.
	var i = fldvalue.length();
	var sChar;

	while (--i >= 0)
	{
	    // Check that current character isn't whitespace.
	    sChar = fldvalue.charAt(i);
	    if (!(sChar == ' ' || sChar == '\t' || sChar == '\n' || sChar == '\r'))
	        return false;
	}
	// All characters are whitespace.
	return true;
}

/*function isEmpty(fldvalue)
{
    return ((fldvalue == null) || (fldvalue.length() == 0));
}*/

function validSSN(ssn)
{
	var len = ssn.length;
	//alert("Inside validSSN 1 ");
	if (len == 9) {
		if (isNumeric(ssn))
			return true;
		return false;
	}
	
	if (len == 11) {
		if (isNumeric(ssn.substring(0,3))) {
			if (ssn.charAt(3) == '-') {
				if (isNumeric(ssn.substring(4,6))) {
					if (ssn.charAt(6) == '-') {
						if (isNumeric(ssn.substring(7))) {
							//alert("Inside validSSN 2 ");
							return true;
						}
					}
				}
			}
		}
	}
	return false;
}


/*function checkSSNFormat(ctl)
{
	alert("Inside checkSSNFormat 1 ");
	return checkSSNFormat(ctl,false)
}*/

function checkSSNFormat(ctl)
{
	/*alert("Inside checkSSNFormat 2 ");
	alert("ctl.value: " + ctl.value);
	if (optional) {
		if (isWhitespace(ctl.value))
			return true;
	}*/
	
	
	if (validSSN(ctl.value)) {
		//alert("Inside validSSN 3 ");
		var ssn = ctl.value;
		var len = ssn.length;
		
		if (len == 9) {
			//alert("Valid SSN Format: " + ssn);	
			return true;
		}
		
		if (len == 11) {
			//alert("valid nnn-nn-nnnn SSN Format");
			var corrSsn = correctSSN(ssn);
			ctl.value = corrSsn;
			//alert("Corrected SSN Format " + corrSsn);
			//alert("ctl.value: " + ctl.value);
			document.form1.mediacrdNumber = corrSsn;
			alert("document.form1.mediacrdNumber.value: " + document.form1.mediacrdNumber.value);
			return true;				
		}
		
	}
	
	alert("There is an error with how you entered your Medicare Number, please re-enter your Medicare Number");		
	return false;
	
	//==============================
	/*if(checkSSN(ctl)){
		return true;
	}
	else{
		alert("There is an error with how you entered your Medicare Number, please re-enter your Medicare Number");		
		return false;
	}*/
	//============================
}
//============
/*function checkSSN(ctl){
	var ssn = ctl.value;
	var len = ssn.length;
	var validSSN = ssn.replaceAll("-", "");
	
	alert("validSSN: " + validSSN);
	alert("Length: " + len);
	return true;

}*/
//===============

function correctSSN(ssn){
	var len = ssn.length;
	if (len == 11){
		var tempSsn = ssn.substring(0, 3) + ssn.substring(4, 6) + ssn.substring(7); 
		return tempSsn;
	}
	return ssn;	
}

function stateCheck(stateCd){
	//alert("stateCd value" + stateCd);
	var stCds = ["AL", "AK", "AS", "AZ", "AR", "CA", "CO", "CT", "DE", "DC", "FM", "FL", "GA", "GU", "HI", "ID", "IL", "IN", 
	             "IA", "KS", "KY", "LA", "ME", "MH", "MD", "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", 
	             "NY", "NC", "ND", "MP", "OH", "OK", "OR", "PW", "PA", "PR", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VI", 
	             "VA", "WA", "WV", "WI", "WY"];
	
	var st = stateCd.toUpperCase();
	var i = stCds.indexOf(st);
	//alert("i value" + i);
	if(i>=0)
		return true;
	else
		return false;

}
//IFOX-00388353 - Summacare Web App CR Changes: End