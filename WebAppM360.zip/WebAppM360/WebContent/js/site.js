﻿$(document).ready(function() {
    var enlarged = false;

    $(".header-textsize").click(function () {
        if (!enlarged) {
            document.body.style.zoom = "125%";
        } else {
            document.body.style.zoom = "100%";
        }
        enlarged = !enlarged;
    });
});




/*$(document).ready(function (){

	$('#primaryPhoneId').keydown(function (e) {
		var key = e.charCode || e.keyCode || 0;
		$phone = $(this);
		
				
        if (key !== 8 && key !== 9) {
            if ($phone.val().length === 4) {
                $phone.val($phone.val() + ')');
            }
            if ($phone.val().length === 5) {
                $phone.val($phone.val() + ' ');
            }
            if ($phone.val().length === 9) {
                $phone.val($phone.val() + '-');
            }
        }

        // Allow numeric (and tab, backspace, delete) keys only
        return (key == 8 ||
                key == 9 ||
                key == 46 ||
                (key >= 48 && key <= 57) ||
                (key >= 96 && key <= 105));
		
	})
	
    .on('focus click', function () {
        $phone = $(this);

        if ($phone.val().length === 0) {
            $phone.val('(');
        }
        else {
            var val = $phone.val();
            $phone.val('').val(val); // Ensure cursor remains at the end
        }
    })

    .blur(function () {
        $phone = $(this);

        if ($phone.val() === '(') {
            $phone.val('');
        }
    });


});*/

/*$(document).ready(function () {
    $('#primaryPhoneId,#alternatePhoneId,#authorizedRepPhoneId,#longtermPhoneOfInstId')

        .keydown(function (e) {
            var key = e.charCode || e.keyCode || 0;
            $phone = $(this);

            // Auto-format- do not expose the mask as the user begins to type
            if (key !== 8 && key !== 9) {
                if ($phone.val().length === 4) {
                    $phone.val($phone.val() + ')');
                }
                if ($phone.val().length === 5) {
                    $phone.val($phone.val() + ' ');
                }
                if ($phone.val().length === 9) {
                    $phone.val($phone.val() + '-');
                }
            }

            // Allow numeric (and tab, backspace, delete) keys only
            return (key == 8 ||
                    key == 9 ||
                    key == 46 ||
                    (key >= 48 && key <= 57) ||
                    (key >= 96 && key <= 105));
        })

        .on('focus click', function () {
            $phone = $(this);

            if ($phone.val().length === 0) {
                $phone.val('(');
            }
            else {
                var val = $phone.val();
                $phone.val('').val(val); // Ensure cursor remains at the end
            }
        })

        .blur(function () {
            $phone = $(this);

            if ($phone.val() === '(') {
                $phone.val('');
            }
        });
});*/

$(document).ready(function () {
    $('#primaryPhoneId,#alternatePhoneId,#authorizedRepPhoneId,#longtermPhoneOfInstId')

        .keydown(function (e) {
            var key = e.charCode || e.keyCode || 0;
            $phone = $(this);

            // Auto-format- do not expose the mask as the user begins to type
            if (key !== 8 && key !== 9) {
				if ($phone.val().length === 0) {
					$phone.val('(');
				}	
                if ($phone.val().length === 4) {
                    $phone.val($phone.val() + ')');
                }
                if ($phone.val().length === 5) {
                    $phone.val($phone.val() + ' ');
                }
                if ($phone.val().length === 9) {
                    $phone.val($phone.val() + '-');
                }
            }

            // Allow numeric (and tab, backspace, delete) keys only
            return (key == 8 ||
                    key == 9 ||
                    key == 46 ||
                    (key >= 48 && key <= 57) ||
                    (key >= 96 && key <= 105));
        })
        // change for IFOX-00414154 Start
        .keyup(function (e) {
            var key = e.charCode || e.keyCode || 0;
            var pattern = new RegExp("[0-9]");
            $phone = $(this);

            // Auto-format- do not expose the mask as the user begins to type
            if (key !== 8 && key !== 9) {

				if($phone.val().length > 1){
					if(!pattern.test($phone.val().charAt($phone.val().length-1))){
						$phone.val($phone.val().substring(0,$phone.val().length-1));
					}
				}
            }
           
            // Allow numeric (and tab, backspace, delete) keys only
            return (key == 8 ||
                    key == 9 ||
                    key == 46 ||
                    (key >= 48 && key <= 57) ||
                    (key >= 96 && key <= 105));
        }) //Change for IFOX-00414154 END

        .on('focus click', function () {
            $phone = $(this);
            var currVal = $phone.val();
			
            if ($phone.val().length === 0) {
                $phone.val('(');
            }
            else {
                var val = $phone.val();
                $phone.val('').val(currVal); // Ensure cursor remains at the end
            }
            
			$phone.mouseup(function() {
				//$phone.blah();
				$phone.focus();
				$phone.val(currVal);
			});
        })

        .click('focus', function () {
/*            $phone = $(this);
            $phone[1].selectionStart = $phone[1].selectionEnd = $phone.val().length;*/

            if ($phone.val().length === 0) {
                $phone.val('(');
            }
            else {
                var val = $phone.val();
                $phone.val('').val(val); // Ensure cursor remains at the end
            }
			
        })
        
        
        .blur(function () {
            $phone = $(this);

            if ($phone.val() === '(') {
                $phone.val('');
            }
        });
});
//Change for IFOX-00414154 START
$(document).ready(function () {
    $('#permanentZipId,#mailingzipId')

        .keydown(function (e) {
            var key = e.charCode || e.keyCode || 0;
            $zip = $(this);
            // Allow numeric (and tab, backspace, delete) keys only
            return (key == 8 ||
                    key == 9 ||
                    key == 46 ||
                    (key >= 48 && key <= 57) ||
                    (key >= 96 && key <= 105));
        })
        .keyup(function (e) {
            var key = e.charCode || e.keyCode || 0;
            var pattern = new RegExp("[0-9]");
            $zip = $(this);

            // Auto-format- do not expose the mask as the user begins to type
            if (key !== 8 && key !== 9) {

				if($zip.val().length > 0){
					if(!pattern.test($zip.val().charAt($zip.val().length-1))){
						$zip.val($zip.val().substring(0,$zip.val().length-1));
					}
				}
            }
            // Allow numeric (and tab, backspace, delete) keys only
            return (key == 8 ||
                    key == 9 ||
                    key == 46 ||
                    (key >= 48 && key <= 57) ||
                    (key >= 96 && key <= 105));
        })

});
$(document).ready(function () {
    $('#medicareClaimId')

        .keyup(function (e) {
            var key = e.charCode || e.keyCode || 0;
            var pattern = new RegExp("[0-9A-Za-z]");
            $zip = $(this);

            // Auto-format- do not expose the mask as the user begins to type
            if (key !== 8 && key !== 9) {

				if($zip.val().length > 0){
					if(!pattern.test($zip.val().charAt($zip.val().length-1))){
						$zip.val($zip.val().substring(0,$zip.val().length-1));
					}
				}
            }
            // Allow numeric (and tab, backspace, delete) keys only
            return (key == 8 ||
                    key == 9 ||
                    key == 46 ||
                    (key >= 48 && key <= 57) ||
                    (key >= 96 && key <= 105));
        })

});
//IFOX-00419089 PBP 801 CR - Start
$(document).ready(function () {
    $('#ssnId')

        .keyup(function (e) {
            var key = e.charCode || e.keyCode || 0;
            var pattern = new RegExp("[0-9]");
            $zip = $(this);

            // Auto-format- do not expose the mask as the user begins to type
            if (key !== 8 && key !== 9) {

				if($zip.val().length > 0){
					if(!pattern.test($zip.val().charAt($zip.val().length-1))){
						$zip.val($zip.val().substring(0,$zip.val().length-1));
					}
				}
            }
            // Allow numeric (and tab, backspace, delete) keys only
            return (key == 8 ||
                    key == 9 ||
                    key == 46 ||
                    (key >= 48 && key <= 57) ||
                    (key >= 96 && key <= 105));
        })

});
//IFOX-00419089 PBP 801 CR - End

$(document).ready(function () {
	
	/**IFOX-00403984 Changes.*/
    $('#birthDateId,#medicarePartAId,#medicarePartBId,#demo2,#demo3,#demo4,#demo5,#demo8,#demo9,#demo10,#demo11,#demo12,#demo15,#demo16','#effDateId')

        .keydown(function (e) {
            var key = e.charCode || e.keyCode || 0;
            $date = $(this);

            if (key === 111 || key === 191) {
            	e.preventDefault();
            	if($date.val().length === 1 && !($date.val() === '0')) {
            		var val = '0' + $date.val() + '/';
            		$date.val(val);
            	} else if($date.val().length === 4 && !($date.val().substring($date.val().length-1) === '0')) {
            		var val =$date.val().substring(0,$date.val().length-1) + '0' + $date.val().substring($date.val().length-1) + '/';
            		$date.val(val);            		
            	}
            }
            
            // Auto-format- do not expose the mask as the user begins to type
            if (key !== 8 && key !== 9) {
/*                if ($phone.val().length === 4) {
                    $phone.val($phone.val() + ')');
                }
                if ($phone.val().length === 5) {
                    $phone.val($phone.val() + ' ');
                }
                if ($phone.val().length === 9) {
                    $phone.val($phone.val() + '-');
                }*/
            	
                if($date.val().length === 2){
	/*            	if($date.val() > 12){
	            		$date.val('');
	            	}
	            	
	            	
	*/            
	                if($date.val() > 12){
	                	return false;
	                }
                	
                	var val = $date.val() + '/';
	                $date.val(val);            	
        	     }
        	            
	            if($date.val().length === 5){
	            	/*            	if($date.val() > 12){
	            	            		$date.val('');
	            	            	}
	            	*/            
	            	var daysInMonth = $date.val().substring(3,5);
	            	
	            	//TO FOR EACH MONTH
	            	
	            	if(daysInMonth > 31){
	            		return false;
	            	}
	            	
	            	//TO FOR EACH MONTH
	            	
	                var val = $date.val() + '/';
	                $date.val(val);            	
	       		}
                	                        	
            	
           }

            // Allow numeric (and tab, backspace, delete) keys only
            return (key == 8 || 
            		key == 9 ||
            		key == 111 ||
                    key == 191 ||            		
                    (key >= 48 && key <= 57) ||
                    (key >= 96 && key <= 105));
        })
});

//change for IFOX-00414154 END
$(document).ready(function () {
    $('#medicaidNbrId')

        .keydown(function (e) {
            var key = e.charCode || e.keyCode || 0;
            $medicaid = $(this);

            // Auto-format- do not expose the mask as the user begins to type
            
            
            // Allow numeric (and tab, backspace, delete) keys only
            return (key == 8 ||
                    key == 9 ||
                    key == 46 ||
                    (key >= 48 && key <= 57) ||
                    (key >= 65 && key <= 90) ||  // characters
                    (key >= 96 && key <= 105));
        })

});

/*$(document).ready(function () {
    $('#medicareClaimId')

        .keydown(function (e) {
            var key = e.charCode || e.keyCode || 0;
            $medicareid = $(this);
            var value = $medicareid.val();

            // Auto-format- do not expose the mask as the user begins to type
            //123-45-6789-A1
            
            if($medicareid.val().length === 3 || $medicareid.val().length === 6 || $medicareid.val().length === 11){
            	
            	value = $medicareid.val() + '-';
            	$medicareid.val(value);
            }

            if( $medicareid.val().length === 0 || $medicareid.val().length === 1 || $medicareid.val().length === 2 || $medicareid.val().length === 3 || $medicareid.val().length === 5 || $medicareid.val().length === 6 || $medicareid.val().length === 8 || $medicareid.val().length === 9 || $medicareid.val().length === 10 || $medicareid.val().length === 11){

            	 return (key == 8 ||
                         key == 9 ||
                         key == 46 ||
                         (key >= 48 && key <= 57) ||
                         (key >= 96 && key <= 105));            	
            }
            
            
            if($medicareid.val().length === 12 || $medicareid.val().length === 13){            
            // Allow numeric (and tab, backspace, delete) keys only
		            return (key == 8 ||
		                    key == 9 ||
		                    key == 46 ||
		                    (key >= 48 && key <= 57) ||
		                    (key >= 65 && key <= 90) ||  // characters
		                    (key >= 96 && key <= 105));
		            
            }
            
            if($medicareid.val().length === 1 ){            
                // Allow numeric (and tab, backspace, delete) keys only
    		            return ( !(key >= 65 && key <= 90));
    		            
                }            
            
        })

});*/

$(document).ready(function () {
    $('#routingNumberId,#accountNumberId')

        .keydown(function (e) {
            var key = e.charCode || e.keyCode || 0;
            $value = $(this);



            // Allow numeric (and tab, backspace, delete) keys only
            return (key == 8 ||
                    key == 9 ||
                    key == 46 ||
                    (key >= 48 && key <= 57) ||
                    (key >= 96 && key <= 105));
        })

});

function toggleNav() {
    if($('nav').css("height") == "0px") {
        $('nav').css("height", "850%");
        $('body').css("overflow-y", "hidden");
    } else {
        $('nav').css("height", "0px");
        $('body').css("overflow", "");
        closeSub1();
        closeSub2();
        closeSub3();
        closeSub4();
        closeSub5();
        closeSub6();
        closeSub7();
        closeSub8();
        closeSub9();
    }
};

function toggleSub1() {
    $('#sub1').toggleClass('nav-active');
    if($('.nav-submenu1').css("height") == "0px") {
        $('.nav-submenu1').css("height", "100%");
        closeSub2();
        closeSub3();
        closeSub4();
        closeSub5();
        closeSub6();
        closeSub7();
        closeSub8();
        closeSub9();
    } else {
        $('.nav-submenu1').css("height", "0px");
    }
}

function toggleSub2() {
    $('#sub2').toggleClass('nav-active');
    if($('.nav-submenu2').css("height") == "0px") {
        $('.nav-submenu2').css("height", "100%");
        closeSub1();
        closeSub4();
        closeSub5();
        closeSub6();
        closeSub7();
        closeSub8();
        closeSub9();
    } else {
        $('.nav-submenu2').css("height", "0px");
        closeSub3();
    }
}

function toggleSub3() {
    $('#sub3').toggleClass('sub-nav-active');
    if($('.nav-submenu3').css("height") == "0px") {
        $('.nav-submenu3').css("height", "100%");
        closeSub1();
        closeSub4();
        closeSub5();
        closeSub6();
        closeSub7();
        closeSub8();
        closeSub9();
    } else {
        $('.nav-submenu3').css("height", "0px");
    }
}

function toggleSub4() {
    $('#sub4').toggleClass('nav-active');
    if($('.nav-submenu4').css("height") == "0px") {
        $('.nav-submenu4').css("height", "100%");
        closeSub2();
        closeSub3();
        closeSub1();
        closeSub5();
        closeSub6();
        closeSub7();
        closeSub8();
        closeSub9();        
    } else {
        $('.nav-submenu4').css("height", "0px");
    }
}

function toggleSub5() {
    $('#sub5').toggleClass('nav-active');
    if($('.nav-submenu5').css("height") == "0px") {
        $('.nav-submenu5').css("height", "100%");
        closeSub2();
        closeSub3();
        closeSub4();
        closeSub1();
        closeSub7();
        closeSub8();
        closeSub9();        
    } else {
        $('.nav-submenu5').css("height", "0px");
        closeSub6();
    }
}

function toggleSub6() {
    $('#sub6').toggleClass('sub-nav-active');
    if($('.nav-submenu6').css("height") == "0px") {
        $('.nav-submenu6').css("height", "100%");
        closeSub2();
        closeSub3();
        closeSub4();
        closeSub1();
        closeSub7();
        closeSub8();
        closeSub9();        
    } else {
        $('.nav-submenu6').css("height", "0px");
    }
}

function toggleSub7() {
    $('#sub7').toggleClass('nav-active');
    if($('.nav-submenu7').css("height") == "0px") {
        $('.nav-submenu7').css("height", "100%");
        closeSub2();
        closeSub3();
        closeSub4();
        closeSub5();
        closeSub6();
        closeSub1();
        closeSub9();        
    } else {
        $('.nav-submenu7').css("height", "0px");
        closeSub8();
    }
}

function toggleSub8() {
    $('#sub8').toggleClass('sub-nav-active');
    if($('.nav-submenu8').css("height") == "0px") {
        $('.nav-submenu8').css("height", "100%");
        closeSub2();
        closeSub3();
        closeSub4();
        closeSub5();
        closeSub6();
        closeSub1();
        closeSub9();        
    } else {
        $('.nav-submenu8').css("height", "0px");
    }
}

function toggleSub9() {
    $('#sub9').toggleClass('nav-active');
    if($('.nav-submenu9').css("height") == "0px") {
        $('.nav-submenu9').css("height", "100%");
        closeSub2();
        closeSub3();
        closeSub4();
        closeSub5();
        closeSub6();
        closeSub7();
        closeSub8();
        closeSub1();        
    } else {
        $('.nav-submenu9').css("height", "0px");
    }
}

function closeSub1() {
    $('#sub1').removeClass('nav-active');
    $('.nav-submenu1').css('height', '0px');
}

function closeSub2() {
    $('#sub2').removeClass('nav-active');
    $('.nav-submenu2').css('height', '0px');
}

function closeSub3() {
    $('#sub3').removeClass('sub-nav-active');
    $('.nav-submenu3').css('height', '0px');
}

function closeSub4() {
    $('#sub4').removeClass('nav-active');
    $('.nav-submenu4').css('height', '0px');
}

function closeSub5() {
    $('#sub5').removeClass('nav-active');
    $('.nav-submenu5').css('height', '0px');
}

function closeSub6() {
    $('#sub6').removeClass('sub-nav-active');
    $('.nav-submenu6').css('height', '0px');
}

function closeSub7() {
    $('#sub7').removeClass('nav-active');
    $('.nav-submenu7').css('height', '0px');
}

function closeSub8() {
    $('#sub8').removeClass('sub-nav-active');
    $('.nav-submenu8').css('height', '0px');
}

function closeSub9() {
    $('#sub9').removeClass('nav-active');
    $('.nav-submenu9').css('height', '0px');
}