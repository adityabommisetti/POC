//Date Picker
function datePickr(id) {
	$("#" + id).datepicker().datepicker("show");
}

//Enroll Form 1 (User Details) Validation  - start
function clearForm1Error() {
	document.getElementById("errEffDate").style.display = 'none';
	document.getElementById("errLastName").style.display = 'none';
	document.getElementById("errLastNameFmt").style.display = 'none';
	document.getElementById("errFirstName").style.display = 'none';
	document.getElementById("errFirstNameFmt").style.display = 'none';
	document.getElementById("errMiddleInitial").style.display = 'none';
	document.getElementById("errBirthDate").style.display = 'none';
	document.getElementById("errBirthDateFmt").style.display = 'none';
	document.getElementById("errHomePhNumber").style.display = 'none';
	document.getElementById("errNameBeneficiary").style.display = 'none';
	document.getElementById("errEmailAddr").style.display = 'none';
	document.getElementById("errMediacrdNumber").style.display = 'none';
	document.getElementById("errMailingZip").style.display = 'none';
	document.getElementById("errSex").style.display = 'none';
	document.getElementById("errPermanentAddr").style.display = 'none';
	document.getElementById("errPermanentAddr").style.display = 'none';
	document.getElementById("errBeneficiarySex").style.display = 'none';
	document.getElementById("errPermanentCity").style.display = 'none';
	document.getElementById("errPermanentState").style.display = 'none';
	document.getElementById("errAltrPhNumber").style.display = 'none';
	document.getElementById("errPermanentZip").style.display = 'none';
	document.getElementById("errPermanentZipFmt").style.display = 'none';
	
}
function validateForm1() {

	clearForm1Error();
	var flag = true;
	var alphabets = /^[A-Za-z]+$/;
	var zipVal = /^[0-9]+$/;

	if (isEmpty(document.form1.effDate.value)) {
		document.getElementById("errEffDate").style.display = '';
		flag = false;

	}
	if (isEmpty(document.form1.lastName.value)) {
		document.getElementById("errLastName").style.display = '';
		flag = false;
	} else if (!isEmpty(document.form1.lastName.value)
			&& !(alphabets.test(document.form1.lastName.value))) {
		document.getElementById("errLastNameFmt").style.display = '';
		flag = false;

	}

	if (isEmpty(document.form1.firstName.value)) {
		document.getElementById("errFirstName").style.display = '';
		flag = false;
	} else if (!isEmpty(document.form1.firstName.value)
			&& !(alphabets.test(document.form1.firstName.value))) {
		document.getElementById("errFirstNameFmt").style.display = '';
		flag = false;

	}

	if (!isEmpty(document.form1.middleInitial.value)
			&& !(alphabets.test(document.form1.middleInitial.value))) {
		document.getElementById("errMiddleInitial").style.display = '';
		flag = false;

	}

	if (isEmpty(document.form1.birthDate.value)) {
		document.getElementById("errBirthDate").style.display = '';
		flag = false;

	} else if (!isValidDate(document.form1.birthDate.value)) {
		document.getElementById("errBirthDateFmt").style.display = '';
		flag = false;

	}
	var homePh = document.form1.homePhNumber.value;

	var altPhoneNbr = document.form1.altrPhNumber.value;

	if (!isEmpty(homePh) && homePh.length != 10) {
		document.getElementById("errHomePhNumber").style.display = '';
		flag = false;
	}

	if (!isEmpty(altPhoneNbr) && altPhoneNbr.length != 10) {
		document.getElementById("errAltrPhNumber").style.display = '';
		flag = false;
	}

	if (isEmpty(document.form1.nameBeneficiary.value)) {
		document.getElementById("errNameBeneficiary").style.display = '';
		flag = false;

	}

	var emailValidate = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

	if (!isEmpty(document.form1.emailAddr.value)) {
		if (!emailValidate.test(document.form1.emailAddr.value)) {
			document.getElementById("errEmailAddr").style.display = '';
			flag = false;

		}
	}

	if (isEmpty(document.form1.mediacrdNumber.value)) {
		document.getElementById("errMediacrdNumber").style.display = '';
		flag = false;

	}

	if (!isEmpty(document.form1.mailingZip.value)
			&& !(zipVal.test(document.form1.mailingZip.value))) {
		document.getElementById("errMailingZip").style.display = '';
		flag = false;

	}

	if (isEmpty(document.form1.sex.value)) {
		document.getElementById("errSex").style.display = '';
		flag = false;
	}
	if (isEmpty(document.form1.permanentAddr.value)) {
		document.getElementById("errPermanentAddr").style.display = '';
	}

	if (isEmpty(document.form1.beneficiarySex.value)) {
		document.getElementById("errBeneficiarySex").style.display = '';
		flag = false;
	}

	if (isEmpty(document.form1.permanentCity.value)) {
		document.getElementById("errPermanentCity").style.display = '';
		flag = false;
	}
	if (isEmpty(document.form1.permanentState.value)) {
		document.getElementById("errPermanentState").style.display = '';
		flag = false;
	}
	if (isEmpty(document.form1.permanentZip.value)) {
		document.getElementById("errPermanentZip").style.display = '';
		flag = false;
	} else if (!isEmpty(document.form1.permanentZip.value)
			&& !(zipVal.test(document.form1.permanentZip.value))) {
		document.getElementById("errPermanentZipFmt").style.display = '';
		flag = false;
	}

	
	
	return flag;
}

//Enroll Form 1 Validation  - end

//Enroll Form 2 (Policy details )Validation  - start
function clearForm2Error() {
	document.getElementById("errAccountHolderName").style.display = 'none';
	document.getElementById("errBankName").style.display = 'none';
	document.getElementById("errAcctype").style.display = 'none';
	document.getElementById("errBankRoutingNumber").style.display = 'none';
	document.getElementById("errBankRoutingNumbereFmt").style.display = 'none';
	document.getElementById("errBankAccountNumber").style.display = 'none';
	document.getElementById("errBankAccountNumberFmt").style.display = 'none';

}
function validateForm2() {
	clearForm2Error();
	var alphaNumeric = /^[0-9a-zA-Z]+$/;
	var numeric = /^[0-9]+$/;
	var flag = true;

	if (document.form2.paymentOption.value == 'E') {

		if (isEmpty(document.form2.accountHolderName.value)) {
			document.getElementById("errAccountHolderName").style.display = '';
			flag = false;
		}

		if (isEmpty(document.form2.bankName.value)) {
			document.getElementById("errBankName").style.display = '';
			flag = false;
		}
		if (isEmpty(document.form2.acctype.value)) {
			document.getElementById("errAcctype").style.display = '';
			flag = false;
		}

		if (isEmpty(document.form2.bankRoutingNumber.value)) {
			document.getElementById("errBankRoutingNumber").style.display = '';
			flag = false;
		} else if (!(numeric.test(document.form2.bankRoutingNumber.value))) {
			document.getElementById("errBankRoutingNumbereFmt").style.display = '';
			flag = false;
		}
		if (isEmpty(document.form2.bankAccountNumber.value)) {
			document.getElementById("errBankAccountNumber").style.display = '';
			flag = false;
		} else if (!(alphaNumeric.test(document.form2.bankAccountNumber.value))) {
			document.getElementById("errBankAccountNumberFmt").style.display = '';
			flag = false;
		}

	}
	return flag;
}

//Enroll Form 2 (Policy details )Validation  - end
//Enroll Form 3 (Policy details )Validation  - start
function clearForm3Error() {
	document.getElementById("errDurgNameCoverage").style.display = 'none';
	document.getElementById("errDurgIdCoverage").style.display = 'none';
	document.getElementById("errDurgGroupCoverage").style.display = 'none';
	document.getElementById("errInstituteName").style.display = 'none';
	document.getElementById("errInstituteAddress").style.display = 'none';
	document.getElementById("errInstitutePhone").style.display = 'none';
	document.getElementById("errInstitutePhoneFmt").style.display = 'none';
	document.getElementById("errMedicaidNumber").style.display = 'none';
	document.getElementById("errOtherLang").style.display = 'none';

}

function validateForm3() {
	var flag = true;
	clearForm3Error();

	if (document.form3.healthBenefits.value == 'Y') {

		if (isEmpty(document.form3.durgNameCoverage.value)) {
			document.getElementById("errDurgNameCoverage").style.display = '';
			flag = false;
		}

		if (isEmpty(document.form3.durgIdCoverage.value)) {
			document.getElementById("errDurgIdCoverage").style.display = '';
			flag = false;
		}
		if (isEmpty(document.form3.durgGroupCoverage.value)) {
			document.getElementById("errDurgGroupCoverage").style.display = '';
			flag = false;

		}
	}
	if (document.form3.nursingHome.value == 'Y') {
		if (isEmpty(document.form3.instituteName.value)) {
			document.getElementById("errInstituteName").style.display = '';
			flag = false;

		}

		if (isEmpty(document.form3.instituteAddress.value)) {
			document.getElementById("errInstituteAddress").style.display = '';
			flag = false;

		}
		if (isEmpty(document.form3.institutePhone.value)) {
			document.getElementById("errInstitutePhone").style.display = '';
			flag = false;

		} else if (!isNumeric(document.form3.institutePhone.value)) {
			document.getElementById("errInstitutePhoneFmt").style.display = '';
			flag = false;

		}
	}

	if (document.form3.stateMedicaid.value == 'Y') {
		if (isEmpty(document.form3.medicaidNumber.value)) {
			document.getElementById("errMedicaidNumber").style.display = '';
			flag = false;

		}
	}
	if (document.form3.langInd.value == 'O') {
		if (isEmpty(document.form3.otherLang.value)) {
			document.getElementById("errOtherLang").style.display = '';
			flag = false;
		}
	}
	return flag;

}

//Enroll Form 2 (Policy details )Validation  - end

//Enroll Form 4 (Attestation  details )Validation  - start

function clearForm4Error() {
	document.getElementById("errAttestque").style.display = 'none';
	document.getElementById("errAttestDate").style.display = 'none';
}

function validateForm4() {
	clearForm4Error();
	var table = document.getElementById('attestTable');
	var optionFlag = false;
	var flag = true;
	var inpfields = table.getElementsByTagName('input');
	var nr_inpfields = inpfields.length;

	for ( var i = 0; i < nr_inpfields; i++) {
		if (inpfields[i].type == 'checkbox' && inpfields[i].checked == true) {
			optionFlag = true;
		}
		if (inpfields[i].type == 'text') {
			if (!inpfields[i].disabled) {
				if (isEmpty(inpfields[i].value)) {
					document.getElementById("errAttestDate").style.display = '';
					flag = false;
				}
				if (!isValidDate(inpfields[i].value)) {
					document.getElementById("errAttestDate").style.display = '';
					flag = false;
				}

			}
		}
	}
	if (optionFlag == false) {
		document.getElementById("errAttestque").style.display = '';
		flag = false;
	}
	return flag;
}

//Enroll Form 4 (Attestation  details )Validation  - end

//Enroll Form 5 (Aggrement  details )Validation  - start
function clearForm5Error() {
	document.getElementById("errTodayDate").style.display = 'none';
	document.getElementById("errTodayDateFmt").style.display = 'none';
	document.getElementById("errTodayDatevalid").style.display = 'none';
	document.getElementById("errSignatureName").style.display = 'none';
}

function validateForm5() {
	var flag = true;
	clearForm5Error();
	if (isEmpty(document.form5.todayDate.value)) {
		document.getElementById("errTodayDate").style.display = '';
		flag = false;
	} else if (!isValidDate(document.form5.todayDate.value)) {
		document.getElementById("errTodayDateFmt").style.display = '';
		flag = false;
	} else if (!todayDateVal(document.form5.todayDate.value)) {
		document.getElementById("errTodayDatevalid").style.display = '';
		flag = false;
	}

	if (isEmpty(document.form5.signatureName.value)) {
		document.getElementById("errSignatureName").style.display = '';
		flag = false;
	}
	if (!isEmpty(document.form5.legalPhNumber.value)
			&& !isNumeric(document.form5.legalPhNumber.value)) {
		document.getElementById("errLegalPhNumber").style.display = '';
		flag = false;
	}

	return flag;

}

//Enroll Form 5 (Aggrement  details )Validation  - end

function langSel(checkValue) {
	if (checkValue.checked && checkValue.value == 'O') {
		document.getElementById("otherLangVal").disabled = false;
	} else {
		document.getElementById("otherLangVal").value = "";
		document.getElementById("otherLangVal").disabled = true;
	}
}

function displayResultyes(checkValue) {
	if (checkValue.checked && checkValue.value == 'Y') {
		document.getElementById("NOOC1").disabled = false;
		document.getElementById("IFTC1").disabled = false;
		document.getElementById("GFTC1").disabled = false;
	} else {
		document.getElementById("NOOC1").value = "";
		document.getElementById("IFTC1").value = "";
		document.getElementById("GFTC1").value = "";
		document.getElementById("NOOC1").disabled = true;
		document.getElementById("IFTC1").disabled = true;
		document.getElementById("GFTC1").disabled = true;
	}
}

function nursingAddress(nursingAddress) {
	if (nursingAddress.checked && nursingAddress.value == 'Y') {
		document.getElementById("insName").disabled = false;
		document.getElementById("insAddress").disabled = false;
		document.getElementById("insPhoneNo").disabled = false;
	} else {
		document.getElementById("insName").value = "";
		document.getElementById("insAddress").value = "";
		document.getElementById("insPhoneNo").value = "";
		document.getElementById("insName").disabled = true;
		document.getElementById("insAddress").disabled = true;
		document.getElementById("insPhoneNo").disabled = true;
	}
}

function medicaidNo(stateMedicaid) {

	if (stateMedicaid.checked && stateMedicaid.value == 'Y') {
		document.getElementById("medicaidNumber").disabled = false;
	} else {
		document.getElementById("medicaidNumber").value = "";
		document.getElementById("medicaidNumber").disabled = true;
	}

}

function displayDate(questionNo, queId) {
	if (questionNo.checked) {
		document.getElementById("date" + queId).disabled = false;
	} else {
		document.getElementById("date" + queId).disabled = true;
		document.getElementById("date" + queId).value = "";
	}

}

function paymentEnable(cbxvalueyes2) {
	if (cbxvalueyes2.checked && cbxvalueyes2.value == 'E') {
		status = "true";
		document.getElementById("accntName").disabled = false;
		document.getElementById("bankName").disabled = false;
		document.getElementById("bnkRN").disabled = false;
		document.getElementById("bnkAN").disabled = false;
		document.getElementById("accntName").value = "";

	} else {
		status = "false";
		document.getElementById("accntName").disabled = true;
		document.getElementById("bankName").disabled = true;
		document.getElementById("bnkRN").disabled = true;
		document.getElementById("bnkAN").disabled = true;
		document.getElementById("accntName").value = "";
		document.getElementById("bankName").value = "";
		document.getElementById("bnkRN").value = "";
		document.getElementById("bnkAN").value = "";

	}
}




$(function() {

	var physicians = [];

	var phs = $("#physiciansListHidden").val();
	phs = phs.split("|");
	var currValue = $("#inputPhysicianValue").val();
	var label = "";
	for (phy in phs) {
		physicians.push({
			'label' : phs[phy].split('=')[1],
			'value' : phs[phy].split('=')[1]
		});
		if (currValue == phs[phy].split('=')[0]) {
			label = phs[phy].split('=')[1];
		}
	}

	$("#inputPhysician").autocomplete({
		source : physicians
	}).val(label);

	$("#inputPhysician").on("autocompletechange", setInputPysicianValue);
	$("#inputPhysician").change(setInputPysicianValue);
});
function setInputPysicianValue() {
	var phs = $("#physiciansListHidden").val();
	var selectedValue = $("#inputPhysician").val();
	phs = phs.split("|");
	var label;
	$("#inputPhysicianValue").val(null);
	$("#inputPhysicianName").val(null);
	for (phy in phs) {
		label = phs[phy].split('=')[1];
		if (label == selectedValue) {
			$("#inputPhysicianValue").val(phs[phy].split('=')[0]);
			$("#inputPhysicianName").val(phs[phy].split('=')[1]);
			break;
		}
	}
}
