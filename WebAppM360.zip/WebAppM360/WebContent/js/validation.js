

function validateForm() {
	  alert('hhhhh');
    var alphabets = /^[A-Za-z]+$/;  
     
     if(!(alphabets.test(document.form1.firstName.value))){  
       alert("First Name should contains only alphabets");
       return false;  
   
     }  
      if(!(alphabets.test(document.form1.lastName.value))){  
       alert("Last Name should contains only alphabets");
       return false;  
     }  
      if(!(alphabets.test(document.form1.middleInitial.value))){  
       alert("Middle initial should contains only alphabets");
       return false;  
     }  
  
   var alphaNumeric = /^[0-9a-zA-Z]+$/;  
   if(!(alphaNumeric.test(document.form1.mediacrdNumber.value)))  
	{  
		alert('MediCard number should contains only AlphaNumeric');  
		return false;  
	}  
   
   var zipVal = /^[0-9]+$/;  
   if(  !(zipVal.test(document.form1.permanentZip.value))){
      alert('Permanent Zip should contains only Numeric');  
		return false;  
   }
   
     if(!(zipVal.test(document.form1.mailingZip.value)) )  
	{  
		alert('Mailing Zip should contains only Numeric');  
		return false;  
	}  
   
   var phoneNumber=/^[[0-9]{3}-[0-9]{3}-[0-9]{4}]*$/;
   if(!(phoneNumber.test(document.form1.altrPhNumber.value)) )
   {
   alert('Please enter a Valid Alternative Phone Number');
   return false;
   }
   if( !(phoneNumber.test(document.form1.homePhNumber.value)) ){
   alert('Please enter a Valid Home Phone Number');
   return false
   }
    if( !(phoneNumber.test(document.form1.emergPhNum.value)) ){
    alert('Please enter a valid Emergency Phone Numberr');
     return false
   }
   
    if( !(phoneNumber.test(document.form1.emergPhNum.value)) ){
    alert('Please enter a valid Emergency Phone Numberr');
     return false
   }
  
    if( !(phoneNumber.test(document.form1.emergPhNum.value)) ){
    alert('Please enter a valid Emergency Phone Numberr');
     return false
   }
  
  
 
   if(!checkFDOM(document.form1.effDate,"Effective Date")){
   alert("Please enter the Effective date as 1st day of the month in this year");
    return false;
   }
  
    if(!checkEmail(document.form1.emailAddr)){
    return false;
    }
    
    if(!validatedate(document.birthDate.emergPhNum)){
    alert('Please enter a valid Birth Date in mm/dd/yyyy format'); 
    return false;
    }
    
    if(!validatedate(document.hospitalDate.emergPhNum)){
     alert('Please enter a valid  hospital in mm/dd/yyyy format '); 
    return false;
    }
    if(!validatedate(document.medicalDate.emergPhNum)){
     alert('Please enter a valid  medicalDate in mm/dd/yyyy format '); 
    return false;
    }
    
  
  if (isEmpty(document.form1.firstName.value)) {
			alert("Please Enter First Name.");
			return false;
	if (isEmpty(document.form1.lastName.value)) {
			alert("Please Enter Last Name.");
			return false;
		}
			if (isEmpty(document.form1.birthDate.value)) {
			alert("Please Enter Birth Date.");
			return false;
		}
			if (isEmpty(document.form1.permanentAddr.value)) {
			alert("Please Enter Permanent Address.");
			return false;
		}
		
		if(isAlphaNumeric(document.form1.permanentAddr.value)) {
			alert("Special Characters are not allowed for Permanent Address .");
			return false;
		}
			if (isEmpty(document.form1.permanentCounty.value)) {
			alert("Please Enter County.");
			return false;
		}
			if (isEmpty(document.form1.permanentCity.value)) {
			alert("Please Enter City.");
			return false;
		}
	
		if (isEmpty(document.form1.permanentState.value)) {
			alert("Please Enter State.");
			return false;
		}
			if (isEmpty(document.form1.nameBeneficiary.value)) {
			alert("Please Enter Beneficiary Name.");
			return false;
		}
	
		if (isEmpty(document.form1.mediacrdNumber.value)) {
			alert("Please Enter mediacrdNumber Name.");
			return false;
		}
		if(isAlphaNumeric(document.form1.mediacrdNumber.value)) {
			alert("Special Characters are not allowed for mediacrdNumber .");
			return false;
		}
			if (isEmpty(document.form1.hospitalDate.value)) {
			alert("Please Enter hospitalDate .");
			return false;
		}
		if(isEmpty(document.form1.hospitalDate.value)) {
			alert("Please Enter Hosptial Date.");
			return false;
		}
		
			if (isEmpty(document.form1.medicalDate.value)) {
			alert("Please Enter medicalDate .");
			return false;
		}
		if(isEmpty(document.form1.medicalDate.value)) {
			alert("Please Enter MedicalDate date.");
			return false;
		}
		return true;
	}
}