﻿$(document).ready(function() {
    var enlarged = false;

    $(".header-textsize").click(function () {
        if (!enlarged) {
            document.body.style.zoom = "125%";
        } else {
            document.body.style.zoom = "100%";
        }
        enlarged = !enlarged;
    });
});




/*$(document).ready(function (){

	$('#primaryPhoneId').keydown(function (e) {
		var key = e.charCode || e.keyCode || 0;
		$phone = $(this);
		
				
        if (key !== 8 && key !== 9) {
            if ($phone.val().length === 4) {
                $phone.val($phone.val() + ')');
            }
            if ($phone.val().length === 5) {
                $phone.val($phone.val() + ' ');
            }
            if ($phone.val().length === 9) {
                $phone.val($phone.val() + '-');
            }
        }

        // Allow numeric (and tab, backspace, delete) keys only
        return (key == 8 ||
                key == 9 ||
                key == 46 ||
                (key >= 48 && key <= 57) ||
                (key >= 96 && key <= 105));
		
	})
	
    .on('focus click', function () {
        $phone = $(this);

        if ($phone.val().length === 0) {
            $phone.val('(');
        }
        else {
            var val = $phone.val();
            $phone.val('').val(val); // Ensure cursor remains at the end
        }
    })

    .blur(function () {
        $phone = $(this);

        if ($phone.val() === '(') {
            $phone.val('');
        }
    });


});*/

$(document).ready(function () {
    $('#primaryPhoneId,#alternatePhoneId,#authorizedRepPhoneId,#longtermPhoneOfInstId')

        .keydown(function (e) {
            var key = e.charCode || e.keyCode || 0;
            $phone = $(this);

            // Auto-format- do not expose the mask as the user begins to type
            if (key !== 8 && key !== 9) {
                if ($phone.val().length === 4) {
                    $phone.val($phone.val() + ')');
                }
                if ($phone.val().length === 5) {
                    $phone.val($phone.val() + ' ');
                }
                if ($phone.val().length === 9) {
                    $phone.val($phone.val() + '-');
                }
            }

            // Allow numeric (and tab, backspace, delete) keys only
            return (key == 8 ||
                    key == 9 ||
                    key == 46 ||
                    (key >= 48 && key <= 57) ||
                    (key >= 96 && key <= 105));
        })

        .on('focus click', function () {
            $phone = $(this);

            if ($phone.val().length === 0) {
                $phone.val('(');
            }
            else {
                var val = $phone.val();
                $phone.val('').val(val); // Ensure cursor remains at the end
            }
        })

        .blur(function () {
            $phone = $(this);

            if ($phone.val() === '(') {
                $phone.val('');
            }
        });
});

$(document).ready(function () {
	

    $('#birthDateId,#medicarePartAId,#medicarePartBId,#demo2,#demo3,#demo4,#demo5,#demo8,#demo9,#demo10,#demo11,#demo12,#demo15,#demo16')

        .keydown(function (e) {
            var key = e.charCode || e.keyCode || 0;
            $date = $(this);

            // Auto-format- do not expose the mask as the user begins to type
            if (key !== 8 && key !== 9) {
/*                if ($phone.val().length === 4) {
                    $phone.val($phone.val() + ')');
                }
                if ($phone.val().length === 5) {
                    $phone.val($phone.val() + ' ');
                }
                if ($phone.val().length === 9) {
                    $phone.val($phone.val() + '-');
                }*/
            	
                if($date.val().length === 2){
	/*            	if($date.val() > 12){
	            		$date.val('');
	            	}
	            	
	            	
	*/            
	                if($date.val() > 12){
	                	return false;
	                }
                	
                	var val = $date.val() + '/';
	                $date.val(val);            	
        	     }
        	            
	            if($date.val().length === 5){
	            	/*            	if($date.val() > 12){
	            	            		$date.val('');
	            	            	}
	            	*/            
	            	var daysInMonth = $date.val().substring(3,5);
	            	
	            	//TO FOR EACH MONTH
	            	
	            	if(daysInMonth > 31){
	            		return false;
	            	}
	            	
	            	//TO FOR EACH MONTH
	            	
	                var val = $date.val() + '/';
	                $date.val(val);            	
	       		}
                	                        	
            	
           }

            // Allow numeric (and tab, backspace, delete) keys only
            return (key == 8 || 
            		key == 9 || 
            		key == 111 ||
                    key == 191 ||
                    (key >= 48 && key <= 57) ||
                    (key >= 96 && key <= 105));
        })
});


$(document).ready(function () {
    $('#medicaidNbrId')

        .keydown(function (e) {
            var key = e.charCode || e.keyCode || 0;
            $medicaid = $(this);

            // Auto-format- do not expose the mask as the user begins to type
            
            
            // Allow numeric (and tab, backspace, delete) keys only
            return (key == 8 ||
                    key == 9 ||
                    key == 46 ||
                    (key >= 48 && key <= 57) ||
                    (key >= 65 && key <= 90) ||  // characters
                    (key >= 96 && key <= 105));
        })

});

/*$(document).ready(function () {
    $('#medicareClaimId')

        .keydown(function (e) {
            var key = e.charCode || e.keyCode || 0;
            $medicareid = $(this);
            var value = $medicareid.val();

            // Auto-format- do not expose the mask as the user begins to type
            //123-45-6789-A1
            
            if($medicareid.val().length === 3 || $medicareid.val().length === 6 || $medicareid.val().length === 11){
            	
            	value = $medicareid.val() + '-';
            	$medicareid.val(value);
            }

            if($medicareid.val().length === 1 || $medicareid.val().length === 2 || $medicareid.val().length === 3 || $medicareid.val().length === 5 || $medicareid.val().length === 6 || $medicareid.val().length === 8 || $medicareid.val().length === 9 || $medicareid.val().length === 10 || $medicareid.val().length === 11){

            	 return (key == 8 ||
                         key == 9 ||
                         key == 46 ||
                         (key >= 48 && key <= 57) ||
                         (key >= 96 && key <= 105));            	
            }
            
            
            if($medicareid.val().length === 12 || $medicareid.val().length === 13){            
            // Allow numeric (and tab, backspace, delete) keys only
		            return (key == 8 ||
		                    key == 9 ||
		                    key == 46 ||
		                    (key >= 48 && key <= 57) ||
		                    (key >= 65 && key <= 90) ||  // characters
		                    (key >= 96 && key <= 105));
		            
            }
            
        })

});*/

$(document).ready(function () {
    $('#routingNumberId,#accountNumberId')

        .keydown(function (e) {
            var key = e.charCode || e.keyCode || 0;
            $value = $(this);



            // Allow numeric (and tab, backspace, delete) keys only
            return (key == 8 ||
                    key == 9 ||
                    key == 46 ||
                    (key >= 48 && key <= 57) ||
                    (key >= 96 && key <= 105));
        })

});

