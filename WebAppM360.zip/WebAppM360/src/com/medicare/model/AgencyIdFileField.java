package com.medicare.model;

import java.io.BufferedWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.medicare.helper.VAPConstants;
import com.medicare.helper.WebAppConstants;

public class AgencyIdFileField extends FileField {

	public AgencyIdFileField() {
		super("Agency_ID", 15, "YPremium");
	}

	@Override
	public void write(ResultSet rs, BufferedWriter writer, Connection conn) throws Exception {
		String agentId = rs.getString("Field_Sales_Rep_ID");
		String customerId = rs.getString("Customer_Id");
		
		//As there is no way to find AgencyId from the existing web app tables hard coding the value
		if(null != customerId && customerId.trim().equals("HCF0232"))
		{
			if(null == agentId || agentId.trim().equals(""))
				writeText(writer, "               ");
			else
				writeText(writer, "CAR00000000001 ");
		} else {
			writeText(writer, "               ");
		}
		return;
		
		/*
		String applicationNumber = rs.getString("Application_Nbr");
		if (agentId != null && !agentId.isEmpty()) {
			PreparedStatement agncyStmt = conn.prepareStatement(VAPConstants.forAgencyId);
			agncyStmt.setString(1, applicationNumber);
			ResultSet resultSet = agncyStmt.executeQuery();
			while (resultSet.next()) {
				
				//Below code commented for IFOX-00390786 (Phase-II)
				
				//writeText(writer, "999999999999999"); // TODO please verify
					//									// whether
						//								// this is correct
				

				//Begin: Added for IFOX-00390786 (Phase-II)
				if(null != customerId && customerId.trim().equalsIgnoreCase("HCF0232"))
				{
					String agencyId = resultSet.getString("AGENCYID");
				
					if(null != agencyId)
					{
						agencyId = agencyId.trim();
						if(agencyId.length() <  15)
						{
							for(int index = agencyId.length(); index < 15; index++)
								agencyId = agencyId + " ";
						}
					}
					if(null == agencyId)
						writeText(writer, "               ");
					else
						writeText(writer, agencyId);

				} else {
					writeText(writer, "999999999999999");
				}
				//End: Added for IFOX-00390786 (Phase-II)

				return;
			}
			
		}
		writeText(writer, emptySpaces());
		*/
	}

}
