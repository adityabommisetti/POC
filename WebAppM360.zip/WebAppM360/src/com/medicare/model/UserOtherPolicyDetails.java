package com.medicare.model;

import java.io.Serializable;

import javax.persistence.*;

/**
 * The persistent class for the USER_OTHER_POLICY_DETAILS database table.
 * 
 */
@Entity
@Table(name = "WB_USER_OTHER_POLICY_DETAILS")
public class UserOtherPolicyDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "POLICY_ID")
	private int policyId;

	@Column(name = "COVERAGE_GROUP")
	private String coverageGroup;

	@Column(name = "COVERAGE_ID")
	private String coverageId;

	@Column(name = "COVERAGE_NAME")
	private String coverageName;

	@Column(name = "COVERAGE_PERIOD")
	private String coveragePeriod;

	@Column(name = "CUSTOMER_ID")
	private String customerId;

	@Column(name = "COVERAGE_TYPE")
	private String coverageType;

	@Column(name = "USER_ID")
	private int userId;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public UserOtherPolicyDetails() {
	}

	public int getPolicyId() {
		return this.policyId;
	}

	public void setPolicyId(int policyId) {
		this.policyId = policyId;
	}

	public String getCoverageGroup() {
		return this.coverageGroup;
	}

	public void setCoverageGroup(String coverageGroup) {
		this.coverageGroup = coverageGroup;
	}

	public String getCoverageId() {
		return this.coverageId;
	}

	public void setCoverageId(String coverageId) {
		this.coverageId = coverageId;
	}

	public String getCoverageName() {
		return this.coverageName;
	}

	public void setCoverageName(String coverageName) {
		this.coverageName = coverageName;
	}

	public String getCoveragePeriod() {
		return this.coveragePeriod;
	}

	public void setCoveragePeriod(String coveragePeriod) {
		this.coveragePeriod = coveragePeriod;
	}

	public String getCoverageType() {
		return this.coverageType;
	}

	public void setCoverageType(String coverageType) {
		this.coverageType = coverageType;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
}