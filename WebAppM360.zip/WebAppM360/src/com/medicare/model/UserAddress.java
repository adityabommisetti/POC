package com.medicare.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;




/**
 * The persistent class for the USER_ADDRESS database table.
 * 
 */
@Entity
@Table(name="WB_USER_ADDRESS")
public class UserAddress implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ADDRESS_ID")
	private int addressId;

	@Column(name="PERM_ADDRESS1")
	private String permAddress1;
	
	@Column(name="PERM_ADDRESS2")
	private String permAddress2;

	@Column(name="PERM_CITY")
	private String permCity;

	@Column(name="PERM_STATE")
	private String permState;
	
	@Column(name="PERM_ZIP_CODE")
	private String permZipCode;
	
	@Column(name="PERM_APARTMENT")
	private String permApartment;
	
	@Column(name="MAIL_ADDRESS1")
	private String mailAddress1;
	
	@Column(name="MAIL_ADDRESS2")
	private String mailAddress2;

	@Column(name="MAIL_CITY")
	private String mailCity;

	@Column(name="MAIL_STATE")
	private String mailState;
	
	@Column(name="MAIL_ZIP_CODE")
	private String mailZipCode;
	
	@Column(name="MAIL_APARTMENT")
	private String mailApartment;
	
	@Column(name="CUSTOMER_ID")
	private String customerId;
	
	@Column(name="USER_ID")
	private int userId;
	
	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public UserAddress() {
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getPermAddress1() {
		return permAddress1;
	}

	public void setPermAddress1(String permAddress1) {
		this.permAddress1 = permAddress1;
	}

	public String getPermAddress2() {
		return permAddress2;
	}

	public void setPermAddress2(String permAddress2) {
		this.permAddress2 = permAddress2;
	}

	public String getPermCity() {
		return permCity;
	}

	public void setPermCity(String permCity) {
		this.permCity = permCity;
	}

	public String getPermState() {
		return permState;
	}

	public void setPermState(String permState) {
		this.permState = permState;
	}

	public String getPermZipCode() {
		return permZipCode;
	}

	public void setPermZipCode(String permZipCode) {
		this.permZipCode = permZipCode;
	}

	public String getPermApartment() {
		return permApartment;
	}

	public void setPermApartment(String permApartment) {
		this.permApartment = permApartment;
	}

	public String getMailAddress1() {
		return mailAddress1;
	}

	public void setMailAddress1(String mailAddress1) {
		this.mailAddress1 = mailAddress1;
	}

	public String getMailAddress2() {
		return mailAddress2;
	}

	public void setMailAddress2(String mailAddress2) {
		this.mailAddress2 = mailAddress2;
	}

	public String getMailCity() {
		return mailCity;
	}

	public void setMailCity(String mailCity) {
		this.mailCity = mailCity;
	}

	public String getMailState() {
		return mailState;
	}

	public void setMailState(String mailState) {
		this.mailState = mailState;
	}

	public String getMailZipCode() {
		return mailZipCode;
	}

	public void setMailZipCode(String mailZipCode) {
		this.mailZipCode = mailZipCode;
	}
	
	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getMailApartment() {
		return mailApartment;
	}

	public void setMailApartment(String mailApartment) {
		this.mailApartment = mailApartment;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}