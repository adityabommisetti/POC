package com.medicare.model;

import java.io.Serializable;

import javax.persistence.*;


/**
 * The persistent class for the WB_USER_ID_SEED database table.
 * 
 */
@Entity
@Table(name="WB_USER_ID_SEED")
public class UserIdSeed implements Serializable {
	private static final long serialVersionUID = 1L;

	
	@EmbeddedId
	private UserSeedPK id;
	
	@Column(name="SEED_NBR")
	private int seedNbr;

	public UserSeedPK getId() {
		return id;
	}

	public void setId(UserSeedPK id) {
		this.id = id;
	}

	public int getSeedNbr() {
		return seedNbr;
	}

	public void setSeedNbr(int seedNbr) {
		this.seedNbr = seedNbr;
	} 
	
	
}