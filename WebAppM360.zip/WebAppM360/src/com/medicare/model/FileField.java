package com.medicare.model;

import java.io.BufferedWriter;
import java.sql.Connection;
import java.sql.ResultSet;

public abstract class FileField {
	protected String name;
	protected int length;
	protected String availabilityFlag;

	//Begin: Added for IFOX-00390786 (Phase-II)
	protected boolean attestationField;
	protected String attestationCode = "";
	
	public boolean isAttestationField() {
		return attestationField;
	}
	public String getAttestationCode() {
		return attestationCode;
	}
	//End: Added for IFOX-00390786 (Phase-II)
	public FileField(String name, int length, String availabilityFlag) {
		super();
		this.name = name;
		this.length = length;
		this.availabilityFlag = availabilityFlag;
	}

	public int getLength() {
		return length;
	}

	public String getName() {
		return name;
	}

	public abstract void write(ResultSet rs, BufferedWriter writer, Connection conn) throws Exception;

	protected boolean isY() {
		return "Y".equalsIgnoreCase(availabilityFlag);
	}

	protected boolean isYD() {
		return "YD".equalsIgnoreCase(availabilityFlag);
	}

	protected boolean isYPremium() {
		return "YPremium".equalsIgnoreCase(availabilityFlag);
	}

	protected String emptySpaces() {
		String seperator = "";
		for (int count = 0; count < length; count++) {
			seperator = seperator + " ";
		}
		return seperator;
	}

	protected String emptySpaces(int customLength) {
		String seperator = "";
		for (int count = 0; count < customLength; count++) {
			seperator = seperator + " ";
		}
		return seperator;
	}

	protected void writeText(BufferedWriter writer, String text) throws Exception {
		if (text.length() != length) {
			throw new Exception("Mismatch length: " + name + " value : " + text);
		}
		writer.write(text);
	}
}
