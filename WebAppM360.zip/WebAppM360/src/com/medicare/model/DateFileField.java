package com.medicare.model;

import java.io.BufferedWriter;
import java.sql.Connection;
import java.sql.ResultSet;

public class DateFileField extends FileField {
	public DateFileField(String name) {
		super(name, 8, "YD");
	}

	@Override
	public void write(ResultSet rs, BufferedWriter writer, Connection conn) throws Exception {
		String value = rs.getString(name);
		String year = value.substring(0, 4);
		String month = value.substring(5, 7);
		String day = value.substring(8, 10);
		String result = year + month + day;
		writeText(writer,result);
	}

}
