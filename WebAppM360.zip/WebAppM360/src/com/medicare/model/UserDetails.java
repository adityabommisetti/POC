package com.medicare.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

/**
 * The persistent class for the USER_DETAILS database table.
 * 
 */
@Entity
@Table(name = "WB_USER_DETAILS")
public class UserDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "USER_ID")
	private int userId;

	@Column(name = "IS_EEM360FLAG")
	private String eemFlag;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATED_DATE")
	private Date createdDate;

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	@Column(name = "PDF_BLOB")
	private byte[] pdfBlob;

	@Temporal(TemporalType.DATE)
	@Column(name = "ACCPT_AGGR_DATE")
	private Date accptAggrDate;

	@Column(name = "ALTR_PHNE_NUM")
	private String altrPhneNum;

	@Column(name = "APPLICATION_STATUS")
	private String applicationStatus;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "BIRTH_DATE")
	private Date birthDate;

	@Column(name = "SUFFIX")
	private String suffix;

	@Column(name = "EMAIL_ADDR")
	// @ColumnTransformer(
	// read="AES_decrypt(EMAIL_ADDR,'password')",
	// write="AES_encrypt(?,'password')")
	// @ColumnTransformer(
	// write="encrypt(?,'password')")
	// @ColumnTransformer(read = "DECRYPT(UNHEX(EMAIL_ADDR), 'password')", write
	// = "HEX(ENCRYPT(?, 'password'))")
	private String emailAddr;

	@Column(name = "EMAIL_ADDR_FORMAT")
	private String emailAddrFormat;

	@Column(name = "EMRG_CONTACT_NAME")
	private String emrgContactName;

	@Column(name = "EMRG_PHNE_NUM")
	private String emrgPhneNum;

	@Column(name = "FIRST_NAME")
	private String firstName;

	@Column(name = "HOME_PHNE_NUM")
	private String homePhneNum;

	@Temporal(TemporalType.DATE)
	@Column(name = "HOSPITAL_DATE")
	private Date hospitalDate;

	@Column(name = "IS_CD_FORMAT")
	private String isCdFormat;

	@Column(name = "IS_LPRINT_FORMAT")
	private String isLprintFormat;

	@Column(name = "LAST_NAME")
	private String lastName;

	@Temporal(TemporalType.DATE)
	@Column(name = "MEDICAL_DATE")
	private Date medicalDate;

	@Column(name = "MEDICARE_CLAIM_NUM")
	private String medicareClaimNum;

	@Column(name = "MEDICARE_NAME")
	private String medicareName;

	@Column(name = "MEDICARE_SEX")
	private String medicareSex;

	@Column(name = "MIDDLE_INITIAL")
	private String middleInitial;

	@Column(name = "PRIMARY_PHYSICIAN")
	private String primaryPhysician;

	@Column(name = "RELATIONSHIP")
	private String relationship;

	@Column(name = "SEX")
	private String sex;

	@Column(name = "IS_RENAL_DISEASE")
	private String renalDisease;

	@Column(name = "OPTIMA_PLAN")
	private String optimaPlan;

	@Column(name = "IS_AGREE")
	private String isAgree;

	// for 2015 application
	@Temporal(TemporalType.DATE)
	@Column(name = "EFFECTIVE_DATE")
	private Date effDate;

	@Column(name = "CUSTOMER_ID")
	private String customerId;

	@Column(name = "CAMPAIGN_ID")
	private String campaignId;

	@Column(name = "CONTRACT_ID")
	private String contractId;

	@Column(name = "BROKER_APP")
	private String brokerApp;

	@Column(name = "IS_AUDIO_TAP")
	private String isAudipTap;

	@Column(name = "IS_BRAILLE")
	private String isBraille;

	@Column(name = "SIGNATURE_1")
	private String signatureName;
	
	@Column(name = "SIGNATURE_2")
	private String signatureRepName;
	
	//IFOX-00419089 PBP 801 CR - Start
	@Column(name = "SSN")
	private String ssn;
	
	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}
	//IFOX-00419089 PBP 801 CR - End

	//Begin: 2019 web app changes - IFOX-00406768
	@Column(name = "HEALTH_PLAN_NEWS_EMAIL")
	private String healthPlanNewsViaEMail;
	
	public String getHealthPlanNewsViaEMail() {
		return healthPlanNewsViaEMail;
	}

	public void setHealthPlanNewsViaEMail(String healthPlanNewsViaEMail) {
		this.healthPlanNewsViaEMail = healthPlanNewsViaEMail;
	}
	//End: 2019 web app changes - IFOX-00406768
	

	public Date getEffDate() {
		return effDate;
	}

	public void setEffDate(Date effDate) {
		this.effDate = effDate;
	}

	public String getCampaignId() {
		return campaignId;
	}

	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}

	public String getContractId() {
		return contractId;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getBrokerApp() {
		return brokerApp;
	}

	public void setBrokerApp(String brokerApp) {
		this.brokerApp = brokerApp;
	}

	public String getIsAudipTap() {
		return isAudipTap;
	}

	public void setIsAudipTap(String isAudipTap) {
		this.isAudipTap = isAudipTap;
	}

	public String getIsBraille() {
		return isBraille;
	}

	public void setIsBraille(String isBraille) {
		this.isBraille = isBraille;
	}

	public String getSignatureName() {
		return signatureName;
	}

	public void setSignatureName(String signatureName) {
		this.signatureName = signatureName;
	}

	public String getSignatureRepName() {
		return signatureRepName;
	}

	public void setSignatureRepName(String signatureRepName) {
		this.signatureRepName = signatureRepName;
	}

	@OneToMany(fetch = FetchType.LAZY, targetEntity = UserAddress.class)
	@Cascade({ CascadeType.SAVE_UPDATE })
	@JoinColumn(name = "USER_ID", referencedColumnName = "USER_ID")
	private Set<UserAddress> userAddressesSet;

	@OneToMany(fetch = FetchType.LAZY, targetEntity = UserAccountDetails.class)
	@Cascade({ CascadeType.SAVE_UPDATE })
	@JoinColumn(name = "USER_ID", referencedColumnName = "USER_ID")
	private Set<UserAccountDetails> userAccountDetailsSet;

	@OneToMany(fetch = FetchType.LAZY, targetEntity = UserPolicyDetails.class)
	@Cascade({ CascadeType.SAVE_UPDATE })
	@JoinColumn(name = "USER_ID", referencedColumnName = "USER_ID")
	private Set<UserPolicyDetails> userPolicyDetailsSet;

	@OneToMany(fetch = FetchType.LAZY, targetEntity = UserAgentDetails.class)
	@Cascade({ CascadeType.SAVE_UPDATE })
	@JoinColumn(name = "USER_ID", referencedColumnName = "USER_ID")
	private Set<UserAgentDetails> userAgentDetails;

	@OneToMany(fetch = FetchType.LAZY, targetEntity = UserLegalRepDetails.class)
	@Cascade({ CascadeType.SAVE_UPDATE })
	@JoinColumn(name = "USER_ID", referencedColumnName = "USER_ID")
	private Set<UserLegalRepDetails> userLegalRepDetails;

	@OneToMany(fetch = FetchType.LAZY, targetEntity = UserOtherPolicyDetails.class)
	@Cascade({ CascadeType.SAVE_UPDATE })
	@JoinColumn(name = "USER_ID", referencedColumnName = "USER_ID")
	private Set<UserOtherPolicyDetails> userOtherPolicyDetails;

	public Set<UserOtherPolicyDetails> getUserOtherPolicyDetails() {
		return userOtherPolicyDetails;
	}

	public void setUserOtherPolicyDetails(
			Set<UserOtherPolicyDetails> userOtherPolicyDetails) {
		this.userOtherPolicyDetails = userOtherPolicyDetails;
	}

	public Set<UserLegalRepDetails> getUserLegalRepDetails() {
		return userLegalRepDetails;
	}

	public void setUserLegalRepDetails(
			Set<UserLegalRepDetails> userLegalRepDetails) {
		this.userLegalRepDetails = userLegalRepDetails;
	}

	public Set<UserAgentDetails> getUserAgentDetails() {
		return userAgentDetails;
	}

	public void setUserAgentDetails(Set<UserAgentDetails> userAgentDetails) {
		this.userAgentDetails = userAgentDetails;
	}

	public Set<UserPolicyDetails> getUserPolicyDetailsSet() {
		return userPolicyDetailsSet;
	}

	public void setUserPolicyDetailsSet(
			Set<UserPolicyDetails> userPolicyDetailsSet) {
		this.userPolicyDetailsSet = userPolicyDetailsSet;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public Date getAccptAggrDate() {
		return accptAggrDate;
	}

	public void setAccptAggrDate(Date accptAggrDate) {
		this.accptAggrDate = accptAggrDate;
	}

	public String getAltrPhneNum() {
		return altrPhneNum;
	}

	public void setAltrPhneNum(String altrPhneNum) {
		this.altrPhneNum = altrPhneNum;
	}

	public String getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(String applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public Date getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	public String getSuffix() {
		return suffix;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	public String getEmailAddr() {
		return emailAddr;
	}

	public void setEmailAddr(String emailAddr) {
		this.emailAddr = emailAddr;
	}

	public String getEmailAddrFormat() {
		return emailAddrFormat;
	}

	public void setEmailAddrFormat(String emailAddrFormat) {
		this.emailAddrFormat = emailAddrFormat;
	}

	public String getEmrgContactName() {
		return emrgContactName;
	}

	public void setEmrgContactName(String emrgContactName) {
		this.emrgContactName = emrgContactName;
	}

	public String getEmrgPhneNum() {
		return emrgPhneNum;
	}

	public void setEmrgPhneNum(String emrgPhneNum) {
		this.emrgPhneNum = emrgPhneNum;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getHomePhneNum() {
		return homePhneNum;
	}

	public void setHomePhneNum(String homePhneNum) {
		this.homePhneNum = homePhneNum;
	}

	public Date getHospitalDate() {
		return hospitalDate;
	}

	public void setHospitalDate(Date hospitalDate) {
		this.hospitalDate = hospitalDate;
	}

	public String getIsCdFormat() {
		return isCdFormat;
	}

	public void setIsCdFormat(String isCdFormat) {
		this.isCdFormat = isCdFormat;
	}

	public String getIsLprintFormat() {
		return isLprintFormat;
	}

	public void setIsLprintFormat(String isLprintFormat) {
		this.isLprintFormat = isLprintFormat;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getMedicalDate() {
		return medicalDate;
	}

	public void setMedicalDate(Date medicalDate) {
		this.medicalDate = medicalDate;
	}

	public String getMedicareClaimNum() {
		return medicareClaimNum;
	}

	public void setMedicareClaimNum(String medicareClaimNum) {
		this.medicareClaimNum = medicareClaimNum;
	}

	public String getMedicareName() {
		return medicareName;
	}

	public void setMedicareName(String medicareName) {
		this.medicareName = medicareName;
	}

	public String getMedicareSex() {
		return medicareSex;
	}

	public void setMedicareSex(String medicareSex) {
		this.medicareSex = medicareSex;
	}

	public String getMiddleInitial() {
		return middleInitial;
	}

	public void setMiddleInitial(String middleInitial) {
		this.middleInitial = middleInitial;
	}

	public String getPrimaryPhysician() {
		return primaryPhysician;
	}

	public void setPrimaryPhysician(String primaryPhysician) {
		this.primaryPhysician = primaryPhysician;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public Set<UserAddress> getUserAddressesSet() {
		return userAddressesSet;
	}

	public void setUserAddressesSet(Set<UserAddress> userAddressesSet) {
		this.userAddressesSet = userAddressesSet;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Set<UserAccountDetails> getUserAccountDetailsSet() {
		return userAccountDetailsSet;
	}

	public void setUserAccountDetailsSet(
			Set<UserAccountDetails> userAccountDetailsSet) {
		this.userAccountDetailsSet = userAccountDetailsSet;
	}

	public String getRenalDisease() {
		return renalDisease;
	}

	public void setRenalDisease(String renalDisease) {
		this.renalDisease = renalDisease;
	}

	public String getIsAgree() {
		return isAgree;
	}

	public void setIsAgree(String isAgree) {
		this.isAgree = isAgree;
	}

	public String getOptimaPlan() {
		return optimaPlan;
	}

	public void setOptimaPlan(String optimaPlan) {
		this.optimaPlan = optimaPlan;
	}

	public String getEemFlag() {
		return eemFlag;
	}

	public void setEemFlag(String eemFlag) {
		this.eemFlag = eemFlag;
	}

	public byte[] getPdfBlob() {
		return pdfBlob;
	}

	public void setPdfBlob(byte[] pdfBlob) {
		this.pdfBlob = pdfBlob;
	}

	/*
	 * public static long getNext(EntityManager em) { SequenceFetcher sf = new
	 * SequenceFetcher(); em.persist(sf); em.flush(); return sf.getId(); }
	 */

}