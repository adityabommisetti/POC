package com.medicare.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;


/**
 * The persistent class for the WB_USER_LOGIN database table.
 * 
 */
@Entity
@Table(name="WB_USER_LOGIN")
public class UserLogin implements Serializable {
	private static final long serialVersionUID = 1L;

	
	@EmbeddedId
	private UserLoginPK id;
	
	@Column(name="PASSWORD")
	private String password;
	
	@Column(name="LOGIN_ATTEMPTS")
	private String loginAttempts;
	
	@Column(name="APPLICATION_NO")
	private String applicationNumber;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CREATED_TIME")
	private Date createdTime;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATED_TIME")
	private Date updatedTime;
	
	@Column(name="OLD_PASSWORD")
	private String oldPassword;

	public UserLoginPK getId() {
		return id;
	}

	public void setId(UserLoginPK id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getLoginAttempts() {
		return loginAttempts;
	}

	public void setLoginAttempts(String loginAttempts) {
		this.loginAttempts = loginAttempts;
	}

	public String getApplicationNumber() {
		return applicationNumber;
	}

	public void setApplicationNumber(String applicationNumber) {
		this.applicationNumber = applicationNumber;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Date getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

	public String getOldPassword() {
		return oldPassword;
	}

	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}


	
}