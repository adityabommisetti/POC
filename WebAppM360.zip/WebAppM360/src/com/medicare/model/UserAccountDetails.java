package com.medicare.model;

import java.io.Serializable;

import javax.persistence.*;


/**
 * The persistent class for the USER_ACCOUNT_DETAILS database table.
 * 
 */
@Entity
@Table(name="WB_USER_ACCOUNT_DETAILS")

public class UserAccountDetails implements Serializable {
	private static final long serialVersionUID = 1L;


	
	@Id
	//@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="USER_ACCOUNT_SEQ")
	@Column(name="ACNT_ID")
	private int acntId;

	@Column(name="ACNT_NAME")
	private String acntName;

	@Column(name="BANK_ACCT_NUM")
	private String bankAcctNum;

	@Column(name="BANK_RTING_NUM")
	private String bankRtingNum;

	@Column(name="IS_AUTO_DEDUCT")
	private String isAutoDeduct;

	@Column(name="IS_ETF")
	private String isEtf;

	@Column(name="IS_MONTHLY_BILL")
	private String isMonthlyBill;
	
	@Column(name="USER_ID")
	private int userId;

	@Column(name="CUSTOMER_ID")
	private String customerId;
	
	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getAcntId() {
		return this.acntId;
	}

	public void setAcntId(int acntId) {
		this.acntId = acntId;
	}

	public String getAcntName() {
		return this.acntName;
	}

	public void setAcntName(String acntName) {
		this.acntName = acntName;
	}

	public String getBankAcctNum() {
		return this.bankAcctNum;
	}

	public void setBankAcctNum(String bankAcctNum) {
		this.bankAcctNum = bankAcctNum;
	}

	public String getBankRtingNum() {
		return this.bankRtingNum;
	}

	public void setBankRtingNum(String bankRtingNum) {
		this.bankRtingNum = bankRtingNum;
	}

	public String getIsAutoDeduct() {
		return this.isAutoDeduct;
	}

	public void setIsAutoDeduct(String isAutoDeduct) {
		this.isAutoDeduct = isAutoDeduct;
	}

	public String getIsEtf() {
		return this.isEtf;
	}

	public void setIsEtf(String isEtf) {
		this.isEtf = isEtf;
	}

	public String getIsMonthlyBill() {
		return this.isMonthlyBill;
	}

	public void setIsMonthlyBill(String isMonthlyBill) {
		this.isMonthlyBill = isMonthlyBill;
	}
	
	public String getCustomerId() {
		return this.customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	
}