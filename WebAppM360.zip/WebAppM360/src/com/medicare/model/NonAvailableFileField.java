package com.medicare.model;

import java.io.BufferedWriter;
import java.sql.Connection;
import java.sql.ResultSet;

public class NonAvailableFileField extends FileField {

	public NonAvailableFileField(String name, int length) {
		super(name, length, "N");
	}

	@Override
	public void write(ResultSet rs, BufferedWriter writer, Connection conn) throws Exception {
		writeText(writer,emptySpaces());
	}

}
