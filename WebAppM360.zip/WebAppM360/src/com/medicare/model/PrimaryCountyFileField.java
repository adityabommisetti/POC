package com.medicare.model;

import java.io.BufferedWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.medicare.helper.WebAppConstants;

public class PrimaryCountyFileField extends FileField {

	public PrimaryCountyFileField() {
		super("Primary_County", 3, "Y");
	}

	@Override
	public void write(ResultSet rs, BufferedWriter writer, Connection conn) throws Exception {
		String Primary_City = (rs.getString("Primary_City"));
		if (Primary_City != null && !Primary_City.isEmpty()) {
			String Zip_code = (rs.getString("Primary_Zip"));
			// IFOX-00384630: Summacare WebApp files failed to process to M360 system - Start
			String Zip_cd = "";
			if(Zip_code.length()>5)
				Zip_cd = Zip_code.trim().substring(0,5);
			else
				Zip_cd = Zip_code;
			
			PreparedStatement stmt = conn.prepareStatement(WebAppConstants.queryForPrimaryCounty);
			stmt.setString(1, Primary_City);
			stmt.setString(2, Zip_cd);
			// IFOX-00384630: Summacare WebApp files failed to process to M360 system - End
			ResultSet resultSet = stmt.executeQuery();
			while (resultSet.next()) {
				String primaryCounty = (resultSet.getString(name) == null ? emptySpaces() : resultSet.getString(name));
				writeText(writer, primaryCounty);
				return;
			}
		}
		writeText(writer, emptySpaces());

	}

}
