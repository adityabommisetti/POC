package com.medicare.model;

import java.util.Map;
import java.util.Map.Entry;

public class EqualsFileField extends ContainsFileField {

	public EqualsFileField(String name, int length, Map<String, String> map) {
		super(name, length, map);
	}

	public EqualsFileField(String name, int length, String[] arr) {
		super(name, length, arr);
	}

	public EqualsFileField(String name, int length, String[][] arr) {
		super(name, length, arr);
	}

	@Override
	public boolean isMatch(String value, Entry<String, String> entry) {
		return value.equalsIgnoreCase(entry.getKey());
	}

}
