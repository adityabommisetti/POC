package com.medicare.model;

import java.io.Serializable;

import javax.persistence.*;

/**
 * The persistent class for the USER_LEGAL_REP_DETAILS database table.
 * 
 */
@Entity
@Table(name = "WB_USER_LEGAL_REP_DETAILS")
public class UserLegalRepDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "REP_ID")
	private int repId;

	@Column(name = "RELATIONSHIP_ENROLLE")
	private String relationshipEnrolle;

	@Column(name = "REP_ADDRESS")
	private String repAddress;

	@Column(name = "REP_NAME")
	private String repName;

	@Column(name = "REP_PHN_NUM")
	private String repPhnNum;

	@Column(name = "REP_LAST_NAME")
	private String replastName;

	@Column(name = "REP_MIDDLE_INITIAL")
	private String repMiddleInitial;

	@Column(name = "REP_ADDREESS_TWO")
	private String repAddressTwo;

	@Column(name = "REP_ADDREESS_THREE")
	private String repAddressThree;

	@Column(name = "REP_CITY")
	private String repCity;

	@Column(name = "REP_STATE")
	private String repState;

	@Column(name = "CUSTOMER_ID")
	private String customerId;

	@Column(name = "REP_ZIP_CODE")
	private String repzipCode;

	@Column(name = "USER_ID")
	private int userId;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getReplastName() {
		return replastName;
	}

	public void setReplastName(String replastName) {
		this.replastName = replastName;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getRepMiddleInitial() {
		return repMiddleInitial;
	}

	public void setRepMiddleInitial(String repMiddleInitial) {
		this.repMiddleInitial = repMiddleInitial;
	}

	public String getRepAddressTwo() {
		return repAddressTwo;
	}

	public void setRepAddressTwo(String repAddressTwo) {
		this.repAddressTwo = repAddressTwo;
	}

	public String getRepAddressThree() {
		return repAddressThree;
	}

	public void setRepAddressThree(String repAddressThree) {
		this.repAddressThree = repAddressThree;
	}

	public String getRepCity() {
		return repCity;
	}

	public void setRepCity(String repCity) {
		this.repCity = repCity;
	}

	public String getRepState() {
		return repState;
	}

	public void setRepState(String repState) {
		this.repState = repState;
	}

	public String getRepzipCode() {
		return repzipCode;
	}

	public void setRepzipCode(String repzipCode) {
		this.repzipCode = repzipCode;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public UserLegalRepDetails() {
	}

	public int getRepId() {
		return this.repId;
	}

	public void setRepId(int repId) {
		this.repId = repId;
	}

	public String getRelationshipEnrolle() {
		return this.relationshipEnrolle;
	}

	public void setRelationshipEnrolle(String relationshipEnrolle) {
		this.relationshipEnrolle = relationshipEnrolle;
	}

	public String getRepAddress() {
		return this.repAddress;
	}

	public void setRepAddress(String repAddress) {
		this.repAddress = repAddress;
	}

	public String getRepName() {
		return this.repName;
	}

	public void setRepName(String repName) {
		this.repName = repName;
	}

	public String getRepPhnNum() {
		return this.repPhnNum;
	}

	public void setRepPhnNum(String repPhnNum) {
		this.repPhnNum = repPhnNum;
	}

}