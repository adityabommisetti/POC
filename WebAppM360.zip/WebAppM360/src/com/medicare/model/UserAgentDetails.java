package com.medicare.model;

import java.io.Serializable;

import javax.persistence.*;

import java.util.Date;

/**
 * The persistent class for the USER_AGENT_DETAILS database table.
 * 
 */
@Entity
@Table(name = "WB_USER_AGENT_DETAILS")
public class UserAgentDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "AGENT_ID")
	private int agentId;

	@Column(name = "AGENT_NAME")
	private String agentName;

	@Column(name = "SENTARA_AGENT_ID")
	private String sentaraAgentID;

	@Temporal(TemporalType.DATE)
	@Column(name = "EFF_DATE")
	private Date effDate;

	@Column(name = "ELECTION_TYPE")
	private String electionType;

	@Column(name = "CUSTOMER_ID")
	private String customerId;

	public String getElectionType() {
		return electionType;
	}

	public void setElectionType(String electionType) {
		this.electionType = electionType;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	@Column(name = "PLAN_ID")
	private String planId;

	@Column(name = "WEB_TEL_APP")
	private String webTelApp;

	public String getSentaraAgentID() {
		return sentaraAgentID;
	}

	public void setSentaraAgentID(String sentaraAgentID) {
		this.sentaraAgentID = sentaraAgentID;
	}

	public UserAgentDetails() {
	}

	public int getAgentId() {
		return this.agentId;
	}

	public void setAgentId(int agentId) {
		this.agentId = agentId;
	}

	public String getAgentName() {
		return this.agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public Date getEffDate() {
		return this.effDate;
	}

	public void setEffDate(Date effDate) {
		this.effDate = effDate;
	}

	public String getPlanId() {
		return this.planId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}

	public String getWebTelApp() {
		return webTelApp;
	}

	public void setWebTelApp(String webTelApp) {
		this.webTelApp = webTelApp;
	}

	@Column(name = "USER_ID")
	private int userId;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}
}