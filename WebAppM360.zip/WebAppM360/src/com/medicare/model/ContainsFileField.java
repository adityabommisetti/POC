package com.medicare.model;

import java.io.BufferedWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class ContainsFileField extends DBValueFileField {

	protected Map<String, String> map;

	public ContainsFileField(String name, int length, Map<String, String> map) {
		super(name, length, "Y");
		this.map = map;
	}

	public ContainsFileField(String name, int length, String[] arr) {
		super(name, length, "Y");
		this.map = new HashMap<String, String>();
		for (int i = 0; i < arr.length; i++) {
			this.map.put(arr[i], arr[i]);
		}
	}

	public ContainsFileField(String name, int length, String[][] arr) {
		super(name, length, "Y");
		this.map = new HashMap<String, String>();
		for (int i = 0; i < arr.length; i++) {
			this.map.put(arr[i][0], arr[i][1]);
		}
	}

	@Override
	public  void write(ResultSet rs, BufferedWriter writer, Connection conn) throws Exception {
		String value = rs.getString(name);
		if (value == null || value.isEmpty()) {
			writeText(writer,emptySpaces());
		} else {
			for (Entry<String, String> entry : map.entrySet()) {
				if (isMatch(value, entry)) {
					writeText(writer,entry.getValue());
					return;
				}
			}
			super.write(rs, writer, conn);
		}
	}

	public boolean isMatch(String value, Entry<String, String> entry) {
		return value.contains(entry.getKey());
	}

}
