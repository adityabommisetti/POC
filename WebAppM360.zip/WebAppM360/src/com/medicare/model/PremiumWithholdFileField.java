package com.medicare.model;

import java.io.BufferedWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.medicare.helper.WebAppConstants;

public class PremiumWithholdFileField extends DBValueFileField {

	public PremiumWithholdFileField() {
		super("Premium_Withhold_Option", 3, "YPremium");
	}

	@Override
	public void write(ResultSet rs, BufferedWriter writer, Connection conn) throws Exception {
		String applicationNumber = rs.getString("Application_Nbr");
		PreparedStatement stmt = conn.prepareStatement(WebAppConstants.queryForPremiunOption);
		stmt.setString(1, applicationNumber);
		ResultSet result = stmt.executeQuery();
		while (result.next()) {
			String autodetected = result.getString("autodetected");
			String eft = result.getString("eft");
			String monthlyBill = result.getString("monthlybill");
			
			/*
			if (monthlyBill != null && !monthlyBill.isEmpty()) {
				writeText(writer, getDBValue("D"));
			} else if (autodetected != null && !autodetected.isEmpty()) {
				writeText(writer, getDBValue("S"));
			} else if (eft != null && !eft.isEmpty()) {
				
				String customerId = rs.getString("Customer_Id");
				if(null != customerId && customerId.trim().equalsIgnoreCase("HCF0232"))
					writeText(writer, getDBValue("E")); //Added for VAP during code merge
				else
					writeText(writer, getDBValue("D"));
				
			} else {
				writeText(writer, "   ");
			} */
			
			String customerId = rs.getString("Customer_Id");
			if(null != customerId && customerId.trim().equalsIgnoreCase("HCF0232"))
			{
				if (null != monthlyBill && monthlyBill.trim().equalsIgnoreCase("D")) {
					writeText(writer, getDBValue("D"));
				} else if (eft != null && eft.trim().equalsIgnoreCase("S")) {
						writeText(writer, getDBValue("S"));
				} else {
					if (eft != null && eft.trim().equalsIgnoreCase("R"))
						writeText(writer, getDBValue("R"));
					else 
						if (eft != null && eft.trim().equalsIgnoreCase("D")) //Added for 2017 application submission through WebApp
							writeText(writer, getDBValue("S"));
						else
							writeText(writer, "   ");
				}
			} else {
				writeText(writer, getDBValue("D"));
			}
			return;
		}
		writeText(writer, emptySpaces());

	}

}
