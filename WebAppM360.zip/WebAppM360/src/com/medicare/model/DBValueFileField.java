package com.medicare.model;

import java.io.BufferedWriter;
import java.sql.Connection;
import java.sql.ResultSet;

public class DBValueFileField extends FileField {

	public DBValueFileField(String name, int length, String availabilityFlag) {
		super(name, length, availabilityFlag);
	}
	//Begin: Added for IFOX-00390786 (Phase-II)
	public DBValueFileField(String name, int length, String availabilityFlag, boolean attestationField, String attestationCode) {
		this (name, length, availabilityFlag);
		this.attestationField = attestationField;
		this.attestationCode = attestationCode;
	}
	//End: Added for IFOX-00390786 (Phase-II)

	@Override
	public void write(ResultSet rs, BufferedWriter writer, Connection conn) throws Exception {
		String value = rs.getString(name);
		writeText(writer,getDBValue(value));
	}

	protected String getDBValue(String value) {
		if (value == null || value.isEmpty()) {
			return emptySpaces();
		} else {
			int spaceLength = length - value.trim().length();
			if (spaceLength > 0) {
				return value.trim() + emptySpaces(spaceLength);
			} else if (spaceLength < 0) {
				return value.trim().substring(0, length);
			} else {
				return value.trim();
			}
		}
	}

}
