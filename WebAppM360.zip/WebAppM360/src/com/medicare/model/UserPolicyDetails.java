package com.medicare.model;

import java.io.Serializable;

import javax.persistence.*;

import java.util.Date;

/**
 * The persistent class for the USER_POLICY_DETAILS database table.
 * 
 */
@Entity
@Table(name = "WB_USER_POLICY_DETAILS")
public class UserPolicyDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "POLICY_ID")
	private int policyId;

	@Column(name = "ADDRESS_INSTITUTION")
	private String addressInstitution;

	@Column(name = "ADDRESS_INSTITUTION_STREET")
	private String addressInstitutionStreet;

	@Temporal(TemporalType.DATE)
	@Column(name = "BACK_US_DATE")
	private Date backUsDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "BEGINNING_DATE")
	private Date beginningDate;

	@Column(name = "IS_ANUL_ELGB_ENROLL")
	private String isAnulElgbEnroll;

	@Column(name = "IS_BELONG_STATE_PHARMCY")
	private String isBelongStatePharmcy;

	@Column(name = "IS_NONE_STATEMENTS")
	private String isNoneStatements;

	@Column(name = "IS_PLAN_CONTRACT_COVERAGE")
	private String isPlanContractCoverage;

	@Temporal(TemporalType.DATE)
	@Column(name = "LEAVING_COVRG_DATE")
	private Date leavingCovrgDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "LEFT_PACE_DATE")
	private Date leftPaceDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "LOST_COVERAGE_DATE")
	private Date lostCoverageDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "MOVED_OUT_FACILITY_DATE")
	private Date movedOutFacilityDate;

	@Column(name = "NAME_INSTITUTION")
	private String nameInstitution;

	@Temporal(TemporalType.DATE)
	@Column(name = "NEW_ELGB_DATE")
	private Date newElgbDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "NO_ELGB_DRUGS_DATE")
	private Date noElgbDrugsDate;

	@Column(name = "OTHER_REASON")
	private String otherReason;

	@Temporal(TemporalType.DATE)
	@Column(name = "OUTSIDE_PLAN_DATE")
	private Date outsidePlanDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "PAY_PRESCRIPTION_DATE")
	private Date payPrescriptionDate;

	@Column(name = "PHONE_NUMBER")
	private String phoneNumber;

	@Column(name = "PLAN_NAME")
	private String planName;

	@Column(name = "POLICY_NUMBER")
	private String policyNumber;

	@Temporal(TemporalType.DATE)
	@Column(name = "RECENT_MOVED_DATE")
	private Date recentMovedDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "SPECIAL_PLAN_DATE")
	private Date specialPlanDate;

	@Column(name = "STATE_MEDICARD_NUM")
	private String stateMedicardNum;

	@Column(name = "CUSTOMER_ID")
	private String customerId;

	@Column(name = "USER_ID")
	private int userId;

	// Added for IFOX-00390466 - Retrofit Medicaid ID Changes: Start
	@Column(name="MEDICAID_IND")
	private String stateMedicaid;
	
	@Column(name="MEDICAID_ID")
	private String medicaidNumber;
	@Column(name="LTC_FAC_ID")
	private String instituteId; //Added for IFOX-00390786 (Phase-II)
	
	public String getStateMedicaid() {
		return stateMedicaid;
	}

	public void setStateMedicaid(String stateMedicaid) {
		this.stateMedicaid = stateMedicaid;
	}

	public String getMedicaidNumber() {
		return medicaidNumber;
	}

	public void setMedicaidNumber(String medicaidNumber) {
		this.medicaidNumber = medicaidNumber;
	}
	// Added for IFOX-00390466 - Retrofit Medicaid ID Changes: End

	//Begin: Added for IFOX-00390114
	public String getInstituteId() {
		return instituteId;
	}

	public void setInstituteId(String instituteId) {
		this.instituteId = instituteId;
	}
	//End: Added for IFOX-00390114


	//Begin: 2019 Attestation Changes
	
	@Column(name="ATT_MAOEP_IND")
	private String MAOEPChange;
	
	@Temporal(TemporalType.DATE)
	@Column(name="ATT_MCD_DATE")
	private Date changeInMedicaid;
	
	@Temporal(TemporalType.DATE)
	@Column(name="ATT_NLS_DATE")
	private Date changeInExtraHelp;
	
	
	@Temporal(TemporalType.DATE)
	@Column(name="ATT_DIF_DATE")
	private Date changeInMedicare;
	
	@Column(name="ATT_DST_IND")
	private String affectedByDisaster;
	
	public Date getChangeInMedicare() {
		return changeInMedicare;
	}

	public void setChangeInMedicare(Date changeInMedicare) {
		this.changeInMedicare = changeInMedicare;
	}

	public String getAffectedByDisaster() {
		return affectedByDisaster;
	}

	public void setAffectedByDisaster(String affectedByDisaster) {
		this.affectedByDisaster = affectedByDisaster;
	}

	public Date getChangeInExtraHelp() {
		return changeInExtraHelp;
	}

	public void setChangeInExtraHelp(Date changeInExtraHelp) {
		this.changeInExtraHelp = changeInExtraHelp;
	}

	public String getMAOEPChange() {
		return MAOEPChange;
	}
	public void setMAOEPChange(String mAOEPChange) {
		MAOEPChange = mAOEPChange;
	}
	public Date getChangeInMedicaid() {
		return changeInMedicaid;
	}

	public void setChangeInMedicaid(Date changeInMedicaid) {
		this.changeInMedicaid = changeInMedicaid;
	}
	//End: 2019 Attestation Changes
	
	
	@Override
	public String toString() {
		return "UserPolicyDetails [policyId=" + policyId + ", addressInstitution=" + addressInstitution
				+ ", addressInstitutionStreet=" + addressInstitutionStreet + ", backUsDate=" + backUsDate
				+ ", beginningDate=" + beginningDate + ", isAnulElgbEnroll=" + isAnulElgbEnroll
				+ ", isBelongStatePharmcy=" + isBelongStatePharmcy + ", isNoneStatements=" + isNoneStatements
				+ ", isPlanContractCoverage=" + isPlanContractCoverage + ", leavingCovrgDate=" + leavingCovrgDate
				+ ", leftPaceDate=" + leftPaceDate + ", lostCoverageDate=" + lostCoverageDate
				+ ", movedOutFacilityDate=" + movedOutFacilityDate + ", nameInstitution=" + nameInstitution
				+ ", newElgbDate=" + newElgbDate + ", noElgbDrugsDate=" + noElgbDrugsDate + ", otherReason="
				+ otherReason + ", outsidePlanDate=" + outsidePlanDate + ", payPrescriptionDate=" + payPrescriptionDate
				+ ", phoneNumber=" + phoneNumber + ", planName=" + planName + ", policyNumber=" + policyNumber
				+ ", recentMovedDate=" + recentMovedDate + ", specialPlanDate=" + specialPlanDate
				+ ", stateMedicardNum=" + stateMedicardNum + ", customerId=" + customerId + ", userId=" + userId + "]";
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public UserPolicyDetails() {
	}

	public int getPolicyId() {
		return this.policyId;
	}

	public void setPolicyId(int policyId) {
		this.policyId = policyId;
	}

	public String getAddressInstitution() {
		return this.addressInstitution;
	}

	public void setAddressInstitution(String addressInstitution) {
		this.addressInstitution = addressInstitution;
	}

	public Date getBackUsDate() {
		return this.backUsDate;
	}

	public void setBackUsDate(Date backUsDate) {
		this.backUsDate = backUsDate;
	}

	public Date getBeginningDate() {
		return this.beginningDate;
	}

	public void setBeginningDate(Date beginningDate) {
		this.beginningDate = beginningDate;
	}

	public String getIsAnulElgbEnroll() {
		return this.isAnulElgbEnroll;
	}

	public void setIsAnulElgbEnroll(String isAnulElgbEnroll) {
		this.isAnulElgbEnroll = isAnulElgbEnroll;
	}

	public String getIsBelongStatePharmcy() {
		return this.isBelongStatePharmcy;
	}

	public void setIsBelongStatePharmcy(String isBelongStatePharmcy) {
		this.isBelongStatePharmcy = isBelongStatePharmcy;
	}

	public String getIsNoneStatements() {
		return this.isNoneStatements;
	}

	public void setIsNoneStatements(String isNoneStatements) {
		this.isNoneStatements = isNoneStatements;
	}

	public String getIsPlanContractCoverage() {
		return this.isPlanContractCoverage;
	}

	public void setIsPlanContractCoverage(String isPlanContractCoverage) {
		this.isPlanContractCoverage = isPlanContractCoverage;
	}

	public Date getLeavingCovrgDate() {
		return this.leavingCovrgDate;
	}

	public void setLeavingCovrgDate(Date leavingCovrgDate) {
		this.leavingCovrgDate = leavingCovrgDate;
	}

	public Date getLeftPaceDate() {
		return this.leftPaceDate;
	}

	public void setLeftPaceDate(Date leftPaceDate) {
		this.leftPaceDate = leftPaceDate;
	}

	public Date getLostCoverageDate() {
		return this.lostCoverageDate;
	}

	public void setLostCoverageDate(Date lostCoverageDate) {
		this.lostCoverageDate = lostCoverageDate;
	}

	public Date getMovedOutFacilityDate() {
		return this.movedOutFacilityDate;
	}

	public void setMovedOutFacilityDate(Date movedOutFacilityDate) {
		this.movedOutFacilityDate = movedOutFacilityDate;
	}

	public String getNameInstitution() {
		return this.nameInstitution;
	}

	public void setNameInstitution(String nameInstitution) {
		this.nameInstitution = nameInstitution;
	}

	public Date getNewElgbDate() {
		return this.newElgbDate;
	}

	public void setNewElgbDate(Date newElgbDate) {
		this.newElgbDate = newElgbDate;
	}

	public Date getNoElgbDrugsDate() {
		return this.noElgbDrugsDate;
	}

	public void setNoElgbDrugsDate(Date noElgbDrugsDate) {
		this.noElgbDrugsDate = noElgbDrugsDate;
	}

	public String getOtherReason() {
		return this.otherReason;
	}

	public void setOtherReason(String otherReason) {
		this.otherReason = otherReason;
	}

	public Date getOutsidePlanDate() {
		return this.outsidePlanDate;
	}

	public void setOutsidePlanDate(Date outsidePlanDate) {
		this.outsidePlanDate = outsidePlanDate;
	}

	public Date getPayPrescriptionDate() {
		return this.payPrescriptionDate;
	}

	public void setPayPrescriptionDate(Date payPrescriptionDate) {
		this.payPrescriptionDate = payPrescriptionDate;
	}

	public String getPhoneNumber() {
		return this.phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPlanName() {
		return this.planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getPolicyNumber() {
		return this.policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public Date getRecentMovedDate() {
		return this.recentMovedDate;
	}

	public void setRecentMovedDate(Date recentMovedDate) {
		this.recentMovedDate = recentMovedDate;
	}

	public Date getSpecialPlanDate() {
		return this.specialPlanDate;
	}

	public void setSpecialPlanDate(Date specialPlanDate) {
		this.specialPlanDate = specialPlanDate;
	}

	public String getStateMedicardNum() {
		return this.stateMedicardNum;
	}

	public void setStateMedicardNum(String stateMedicardNum) {
		this.stateMedicardNum = stateMedicardNum;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getAddressInstitutionStreet() {
		return addressInstitutionStreet;
	}

	public void setAddressInstitutionStreet(String addressInstitutionStreet) {
		this.addressInstitutionStreet = addressInstitutionStreet;
	}
	
	//Begin: Added for IFOX-00390786 (Phase-II)
		@Temporal(TemporalType.DATE)
		@Column(name="UNION_COV_DATE")
		private Date unionCoverageDate;

		@Column(name="LTC_INST_IND")
		private String longTermFacilityIndicator;
		
		@Column(name="SPOUSE_WORK_IND")
		private String spouseWorkIndicator;

		public String getLongTermFacilityIndicator() {
			return longTermFacilityIndicator;
		}

		public void setLongTermFacilityIndicator(String longTermFacilityIndicator) {
			this.longTermFacilityIndicator = longTermFacilityIndicator;
		}

		public String getSpouseWorkIndicator() {
			return spouseWorkIndicator;
		}

		public void setSpouseWorkIndicator(String spouseWorkIndicator) {
			this.spouseWorkIndicator = spouseWorkIndicator;
		}

		public Date getUnionCoverageDate() {
			return unionCoverageDate;
		}

		public void setUnionCoverageDate(Date unionCoverageDate) {
			this.unionCoverageDate = unionCoverageDate;
		}
		//End: Added for IFOX-00390786 (Phase-II)

}