package com.medicare.model;

import java.io.BufferedWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.medicare.helper.VAPConstants;
import com.medicare.helper.WebAppConstants;

public class PCPLocationFileField extends PCPFileField {

	public PCPLocationFileField(String name, int length) {
		super(name, length);
	}

	@Override
	public void write(ResultSet rs, BufferedWriter writer, Connection conn) throws Exception {
		String applicationNumber = rs.getString("Application_Nbr");
		PreparedStatement pcpStmt = conn.prepareStatement(VAPConstants.forPCP);
		pcpStmt.setString(1, applicationNumber);
		ResultSet resultSet = pcpStmt.executeQuery();
		while (resultSet.next()) {
			String pcp = (resultSet.getString("PCPData"));
			if (pcp != null && !pcp.isEmpty()) {
				writeText(writer, "01");
			} else {
				writeText(writer, emptySpaces());
			}
		}

	}

}
