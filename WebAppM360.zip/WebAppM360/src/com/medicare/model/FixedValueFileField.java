package com.medicare.model;

import java.io.BufferedWriter;
import java.sql.Connection;
import java.sql.ResultSet;

public class FixedValueFileField extends FileField {
	private String fixedValue;

	public FixedValueFileField(String name, int length, String fixedValue) {
		super(name, length, "YP");
		this.fixedValue = fixedValue;
	}

	@Override
	public void write(ResultSet rs, BufferedWriter writer, Connection conn) throws Exception {
		writeText(writer,fixedValue);
	}

	//Begin: Added for IFOX-00390786 (Phase-II)
	public String getFixedValue() {
		return fixedValue;
	}

	public void setFixedValue(String fixedValue) {
		this.fixedValue = fixedValue;
	}
	//End: Added for IFOX-00390786 (Phase-II)
	
	
}
