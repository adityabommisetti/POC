package com.medicare.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * @author 
 *
 */
@Embeddable
public class UserSeedPK implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name="SEED_TYPE")
	private String seedType;

	@Column(name="CUSTOMER_ID")
	private String customerId;

	public UserSeedPK() {
		
	}

	public UserSeedPK(String seedType, String customerId) {
		super();
		this.seedType = seedType;
		this.customerId = customerId;
	}

	public String getSeedType() {
		return seedType;
	}

	public void setSeedType(String seedType) {
		this.seedType = seedType;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((customerId == null) ? 0 : customerId.hashCode());
		result = prime * result + ((seedType == null) ? 0 : seedType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserSeedPK other = (UserSeedPK) obj;
		if (customerId == null) {
			if (other.customerId != null)
				return false;
		} else if (!customerId.equals(other.customerId))
			return false;
		if (seedType == null) {
			if (other.seedType != null)
				return false;
		} else if (!seedType.equals(other.seedType))
			return false;
		return true;
	}
	
	
}
