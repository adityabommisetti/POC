package com.medicare.model;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class PCPFileField extends DBValueFileField {

	public PCPFileField(String name, int length) {
		super(name, length, "YPremium");
	}

	protected String pcpPopulationMethod(String pcpNameandCode, int fieldSize) {
		if (pcpNameandCode != null && !pcpNameandCode.isEmpty()) {
			String finalValue = null;
			if (pcpNameandCode.indexOf("-") >= 0) {
				String pcpCode = pcpNameandCode.substring(pcpNameandCode.indexOf("-") + 1);
				finalValue = getDBValue(pcpCode);
			} else {
				finalValue = getDBValue(pcpNameandCode);
			}
			return finalValue;
		} else {
			return emptySpaces();
		}
	}
}
