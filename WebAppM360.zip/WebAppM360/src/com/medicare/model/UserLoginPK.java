package com.medicare.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * @author
 *
 */
@Embeddable
public class UserLoginPK implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name="EMAIL_ID")
	private String emailID;

	@Column(name="CUSTOMER_ID")
	private String customerId;

	public UserLoginPK() {
		
	}

	public UserLoginPK(String emailID, String customerId) {
		super();
		this.emailID = emailID;
		this.customerId = customerId;
	}

	public String getEmailID() {
		return emailID;
	}

	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserLoginPK other = (UserLoginPK) obj;
		if (customerId == null) {
			if (other.customerId != null)
				return false;
		} else if (!customerId.equals(other.customerId))
			return false;
		if (emailID == null) {
			if (other.emailID != null)
				return false;
		} else if (!emailID.equals(other.emailID))
			return false;
		return true;
	}
	
	
}
