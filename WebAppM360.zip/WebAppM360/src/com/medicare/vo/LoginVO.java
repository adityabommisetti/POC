package com.medicare.vo;

public class LoginVO {
	
	private String customerId;
	private String emailAddress;
	private String password;
	
	private String reconfirmPwd;
	private String createdDate;
	private String updatedDate;
	
	private String loginAttempts;
	private String applicationNumber;
	private String createdTime;
	private String updatedTime;
	private String oldPassword;
	
	public String getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}
	public String getLoginAttempts() {
		return loginAttempts;
	}
	public void setLoginAttempts(String loginAttempts) {
		this.loginAttempts = loginAttempts;
	}
	public String getApplicationNumber() {
		return applicationNumber;
	}
	public void setApplicationNumber(String applicationNumber) {
		this.applicationNumber = applicationNumber;
	}
	public String getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(String createdTime) {
		this.createdTime = createdTime;
	}
	public String getUpdatedTime() {
		return updatedTime;
	}
	public void setUpdatedTime(String updatedTime) {
		this.updatedTime = updatedTime;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
/*	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}*/
	public String getReconfirmPwd() {
		return reconfirmPwd;
	}
	public void setReconfirmPwd(String reconfirmPwd) {
		this.reconfirmPwd = reconfirmPwd;
	}
	public String getOldPassword() {
		return oldPassword;
	}
	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}
	
	

}
