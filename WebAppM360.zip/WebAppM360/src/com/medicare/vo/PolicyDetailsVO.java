package com.medicare.vo;

import java.util.Date;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

public class PolicyDetailsVO {
	private String erroraccountHolderNameValue;

	//Begin: 2019 web app changes - IFOX-00406768
	private String newPhysicianName;
	private String newAgentName;

	public String getNewPhysicianName() {
		return newPhysicianName;
	}
	public void setNewPhysicianName(String newPhysicianName) {
		this.newPhysicianName = newPhysicianName;
	}

	public String getNewAgentName() {
		return newAgentName;
	}
	public void setNewAgentName(String newAgentName) {
		this.newAgentName = newAgentName;
	}
	
	//End: 2019 web app changes - IFOX-00406768
	
	public String getErroraccountHolderNameValue() {
		return erroraccountHolderNameValue;
	}

	public void setErroraccountHolderNameValue(String erroraccountHolderNameValue) {
		this.erroraccountHolderNameValue = erroraccountHolderNameValue;
	}

	public String getErrorbankRoutingNumberValue() {
		return errorbankRoutingNumberValue;
	}

	public void setErrorbankRoutingNumberValue(String errorbankRoutingNumberValue) {
		this.errorbankRoutingNumberValue = errorbankRoutingNumberValue;
	}

	public String getErrorbankAccountNumberValue() {
		return errorbankAccountNumberValue;
	}

	public void setErrorbankAccountNumberValue(String errorbankAccountNumberValue) {
		this.errorbankAccountNumberValue = errorbankAccountNumberValue;
	}

	public String getErrorbeginingDateValue() {
		return errorbeginingDateValue;
	}

	public void setErrorbeginingDateValue(String errorbeginingDateValue) {
		this.errorbeginingDateValue = errorbeginingDateValue;
	}

	private String errorbankRoutingNumberValue;
	private String errorbankAccountNumberValue;
	private String errorbeginingDateValue;

	private String palnName;

	private String policyNumber;

	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String beginingDate;

	private String paymentOption;
	private String paymentOptionTemp;
	
	private String accountHolderName;

	@Pattern(regexp = "^[0-9]*$")
	private String bankRoutingNumber;

	@Pattern(regexp = "^[a-zA-Z0-9]*$")
	private String bankAccountNumber;

	private String autoDeduction;

	private String renalDisease;

	private String healthBenefits;

	private String medicalNameCoverage;

	private String otherMedicalNameCoverage;

	private String medicalIdCoverage;

	private String otherMedicalIdCoverage;

	private String medicalGroupCoverage;

	private String otherMedicalGroupCoverage;

	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String medicalCoveragePeriod;

	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String otherMedicalCoveragePeriod;

	private String nursingHome;

	//Added for IFOX-00390786 (Phase-II)
	private String instituteId;
	
	private String instituteName;

	private String instituteAddress;

	private String instituteOtherAddress;

	private String institutePhone;

	private String stateMedicaid;

	@NotEmpty //Added for IFOX-00390786 (Phase-II)
	private String medicaidNumber;

	private String spouse;

	private String prescriptionDrug;

	private String durgNameCoverage;

	private String durgIdCoverage;

	private String durgGroupCoverage;
	
	private String customerId;
	
	private String physician;
	private String physicianName;
	private String errorphysicianValue;

	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String durgCoveragePeriod;

	private String cbxValueError;

	
	//Begin: Added for IFOX-00390786 (Phase-II)
	private Date unionCoverageDate;
	private String institutionalName;
	
	public Date getUnionCoverageDate() {
		return unionCoverageDate;
	}

	public void setUnionCoverageDate(Date unionCoverageDate) {
		this.unionCoverageDate = unionCoverageDate;
	}

	public String getInstitutionalName() {
		return institutionalName;
	}

	public void setInstitutionalName(String institutionalName) {
		this.institutionalName = institutionalName;
	}
	
	public String getInstituteId() {
		return instituteId;
	}

	public void setInstituteId(String instituteId) {
		this.instituteId = instituteId;
	}
	public String getPhysicianName() {
		return physicianName;
	}
	public void setPhysicianName(String physicianName) {
		this.physicianName = physicianName;
	}
	public String getPhysician() {
		return physician;
	}
	public void setPhysician(String physician) {
		this.physician = physician;
	}
	//End: Added for IFOX-00390786 (Phase-II)
	
	public String getCbxValueError() {
		return cbxValueError;
	}

	public void setCbxValueError(String cbxValueError) {
		this.cbxValueError = cbxValueError;
	}

	public String getPalnName() {
		return palnName;
	}

	public void setPalnName(String palnName) {
		this.palnName = palnName;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getBeginingDate() {
		return beginingDate;
	}

	public void setBeginingDate(String beginingDate) {
		this.beginingDate = beginingDate;
	}

	public String getPaymentOption() {
		return paymentOption;
	}

	public void setPaymentOption(String paymentOption) {
		this.paymentOption = paymentOption;
	}
	
	public String getPaymentOptionTemp() {
		return paymentOptionTemp;
	}

	public void setPaymentOptionTemp(String paymentOptionTemp) {
		this.paymentOptionTemp = paymentOptionTemp;
	}
	
	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getBankRoutingNumber() {
		return bankRoutingNumber;
	}

	public void setBankRoutingNumber(String bankRoutingNumber) {
		this.bankRoutingNumber = bankRoutingNumber;
	}

	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	public String getAutoDeduction() {
		return autoDeduction;
	}

	public void setAutoDeduction(String autoDeduction) {
		this.autoDeduction = autoDeduction;
	}

	public String getRenalDisease() {
		return renalDisease;
	}

	public void setRenalDisease(String renalDisease) {
		this.renalDisease = renalDisease;
	}

	public String getHealthBenefits() {
		return healthBenefits;
	}

	public void setHealthBenefits(String healthBenefits) {
		this.healthBenefits = healthBenefits;
	}

	public String getMedicalNameCoverage() {
		return medicalNameCoverage;
	}

	public void setMedicalNameCoverage(String medicalNameCoverage) {
		this.medicalNameCoverage = medicalNameCoverage;
	}

	public String getOtherMedicalNameCoverage() {
		return otherMedicalNameCoverage;
	}

	public void setOtherMedicalNameCoverage(String otherMedicalNameCoverage) {
		this.otherMedicalNameCoverage = otherMedicalNameCoverage;
	}

	public String getMedicalIdCoverage() {
		return medicalIdCoverage;
	}

	public void setMedicalIdCoverage(String medicalIdCoverage) {
		this.medicalIdCoverage = medicalIdCoverage;
	}

	public String getOtherMedicalIdCoverage() {
		return otherMedicalIdCoverage;
	}

	public void setOtherMedicalIdCoverage(String otherMedicalIdCoverage) {
		this.otherMedicalIdCoverage = otherMedicalIdCoverage;
	}

	public String getMedicalGroupCoverage() {
		return medicalGroupCoverage;
	}

	public void setMedicalGroupCoverage(String medicalGroupCoverage) {
		this.medicalGroupCoverage = medicalGroupCoverage;
	}

	public String getOtherMedicalGroupCoverage() {
		return otherMedicalGroupCoverage;
	}

	public void setOtherMedicalGroupCoverage(String otherMedicalGroupCoverage) {
		this.otherMedicalGroupCoverage = otherMedicalGroupCoverage;
	}

	public String getMedicalCoveragePeriod() {
		return medicalCoveragePeriod;
	}

	public void setMedicalCoveragePeriod(String medicalCoveragePeriod) {
		this.medicalCoveragePeriod = medicalCoveragePeriod;
	}

	public String getOtherMedicalCoveragePeriod() {
		return otherMedicalCoveragePeriod;
	}

	public void setOtherMedicalCoveragePeriod(String otherMedicalCoveragePeriod) {
		this.otherMedicalCoveragePeriod = otherMedicalCoveragePeriod;
	}

	public String getNursingHome() {
		return nursingHome;
	}

	public void setNursingHome(String nursingHome) {
		this.nursingHome = nursingHome;
	}

	public String getInstituteName() {
		return instituteName;
	}

	public void setInstituteName(String instituteName) {
		this.instituteName = instituteName;
	}

	public String getInstituteAddress() {
		return instituteAddress;
	}

	public void setInstituteAddress(String instituteAddress) {
		this.instituteAddress = instituteAddress;
	}


	public String getInstituteOtherAddress() {
		return instituteOtherAddress;
	}

	public void setInstituteOtherAddress(String instituteOtherAddress) {
		this.instituteOtherAddress = instituteOtherAddress;
	}

	public String getInstitutePhone() {
		return institutePhone;
	}

	public void setInstitutePhone(String institutePhone) {
		this.institutePhone = institutePhone;
	}

	public String getStateMedicaid() {
		return stateMedicaid;
	}

	public void setStateMedicaid(String stateMedicaid) {
		this.stateMedicaid = stateMedicaid;
	}

	public String getMedicaidNumber() {
		return medicaidNumber;
	}

	public void setMedicaidNumber(String medicaidNumber) {
		this.medicaidNumber = medicaidNumber;
	}

	public String getSpouse() {
		return spouse;
	}

	public void setSpouse(String spouse) {
		this.spouse = spouse;
	}

	public String getPrescriptionDrug() {
		return prescriptionDrug;
	}

	public void setPrescriptionDrug(String prescriptionDrug) {
		this.prescriptionDrug = prescriptionDrug;
	}

	public String getDurgNameCoverage() {
		return durgNameCoverage;
	}

	public void setDurgNameCoverage(String durgNameCoverage) {
		this.durgNameCoverage = durgNameCoverage;
	}

	public String getDurgIdCoverage() {
		return durgIdCoverage;
	}

	public void setDurgIdCoverage(String durgIdCoverage) {
		this.durgIdCoverage = durgIdCoverage;
	}

	public String getDurgGroupCoverage() {
		return durgGroupCoverage;
	}

	public void setDurgGroupCoverage(String durgGroupCoverage) {
		this.durgGroupCoverage = durgGroupCoverage;
	}

	public String getDurgCoveragePeriod() {
		return durgCoveragePeriod;
	}

	public void setDurgCoveragePeriod(String durgCoveragePeriod) {
		this.durgCoveragePeriod = durgCoveragePeriod;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	
	public String getErrorphysicianValue() {
		return errorphysicianValue;
	}

	public void setErrorphysicianValue(String errorphysicianValue) {
		this.errorphysicianValue = errorphysicianValue;
	}
	
	//New fields Added for SumaCare-START
	private String acctype;

	/**
	 * @return the acctype
	 */
	public String getAcctype() {
		return acctype;
	}

	/**
	 * @param acctype the acctype to set
	 */
	public void setAcctype(String acctype) {
		this.acctype = acctype;
	}
	//New fields Added for SumaCare-END
	
	//New fields Added for Sharp -start
	private String bankName;
	private String langInd;
	private String otherLang;
	private String pcpGroup;
	public String getPcpGroup() {
		return pcpGroup;
	}

	public void setPcpGroup(String pcpGroup) {
		this.pcpGroup = pcpGroup;
	}

	public String getLangInd() {
		return langInd;
	}

	public void setLangInd(String langInd) {
		this.langInd = langInd;
	}

	public String getOtherLang() {
		return otherLang;
	}

	public void setOtherLang(String otherLang) {
		this.otherLang = otherLang;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	//New fields Added for Sharp-end
	
}
