package com.medicare.vo;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

import com.medicare.helper.VAPConstants;

public class AgreeDetailsVO {
	//Begin: Added for IFOX-00390786 (Phase-II)
	public String getErroragreeStatementsValue() {
		return erroragreeStatementsValue;
	}

	public void setErroragreeStatementsValue(String erroragreeStatementsValue) {
		this.erroragreeStatementsValue = erroragreeStatementsValue;
	}
	//Begin: Added for IFOX-00390786 (Phase-II)

	public String getErrortodayDateValue() {
		return errortodayDateValue;
	}

	public void setErrortodayDateValue(String errortodayDateValue) {
		this.errortodayDateValue = errortodayDateValue;
	}

	public String getErrorlegalRelationErlollValue() {
		return errorlegalRelationErlollValue;
	}

	public void setErrorlegalRelationErlollValue(String errorlegalRelationErlollValue) {
		this.errorlegalRelationErlollValue = errorlegalRelationErlollValue;
	}

	public String getErroragentNameValue() {
		return erroragentNameValue;
	}

	public void setErroragentNameValue(String erroragentNameValue) {
		this.erroragentNameValue = erroragentNameValue;
	}

	public String getErroragentIdValue() {
		return erroragentIdValue;
	}

	public void setErroragentIdValue(String erroragentIdValue) {
		this.erroragentIdValue = erroragentIdValue;
	}

	public String getErrorplanIdValue() {
		return errorplanIdValue;
	}

	public void setErrorplanIdValue(String errorplanIdValue) {
		this.errorplanIdValue = errorplanIdValue;
	}

	public String getErroricepValue() {
		return erroricepValue;
	}

	public void setErroricepValue(String erroricepValue) {
		this.erroricepValue = erroricepValue;
	}

	public String getErroraepValue() {
		return erroraepValue;
	}

	public void setErroraepValue(String erroraepValue) {
		this.erroraepValue = erroraepValue;
	}

	public String getErrorsepValue() {
		return errorsepValue;
	}

	public void setErrorsepValue(String errorsepValue) {
		this.errorsepValue = errorsepValue;
	}

	public String getErrorlegalAddressValue() {
		return errorlegalAddressValue;
	}

	public void setErrorlegalAddressValue(String errorlegalAddressValue) {
		this.errorlegalAddressValue = errorlegalAddressValue;
	}

	public String getErrorlegalPhNumberValue() {
		return errorlegalPhNumberValue;
	}

	public void setErrorlegalPhNumberValue(String errorlegalPhNumberValue) {
		this.errorlegalPhNumberValue = errorlegalPhNumberValue;
	}

	public String getErrorlegalCityStateValue() {
		return errorlegalCityStateValue;
	}

	public void setErrorlegalCityStateValue(String errorlegalCityStateValue) {
		this.errorlegalCityStateValue = errorlegalCityStateValue;
	}

	public String getErroreffectDateCoverageValue() {
		return erroreffectDateCoverageValue;
	}

	public void setErroreffectDateCoverageValue(String erroreffectDateCoverageValue) {
		this.erroreffectDateCoverageValue = erroreffectDateCoverageValue;
	}

	public String getErroragentIdNameCheckValue() {
		return erroragentIdNameCheckValue;
	}

	public void setErroragentIdNameCheckValue(String erroragentIdNameCheckValue) {
		this.erroragentIdNameCheckValue = erroragentIdNameCheckValue;
	}

	
	private String erroragreeStatementsValue; //Added for IFOX-00390786 (Phase-II)
	
	private String errortodayDateValue;
	private String errorlegalRelationErlollValue;
	private String erroragentNameValue;
	private String erroragentIdValue;
	private String errorplanIdValue;
	private String erroricepValue;
	private String erroraepValue;
	private String errorsepValue;
	private String errorlegalAddressValue;
	private String errorlegalPhNumberValue;
	private String errorlegalCityStateValue;
	private String erroreffectDateCoverageValue;
	private String erroragentIdNameCheckValue;

	private String icepDate;

	@NotEmpty
	private String agreeStatements;

	@NotEmpty
	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String todayDate;

	//@NotEmpty //Added for IFOX-00390786 (Phase-II) 
	private String legalFirstName;

	private String legalLastName;

	private String legalMiddleName;

	//@NotEmpty //Added for IFOX-00390786 (Phase-II)
	private String legalAddress;

	//@NotEmpty //Added for IFOX-00390786 (Phase-II)
	private String legalAddressTwo;

	private String legalAddressThree;

	private String legalCity;

	private String legalState;

	private String legalZipCode;

	//@NotEmpty //Added for IFOX-00390786 (Phase-II) 
	@Pattern(regexp = "^[[0-9]{3}-[0-9]{3}-[0-9]{4}]*$")
	private String legalPhNumber;

	//@NotEmpty //Added for IFOX-00390786 (Phase-II) 
	@Pattern(regexp = "^[a-zA-Z]*$")
	private String legalRelationErloll;

	private String webtelApp;

	// @Pattern(regexp = "^[a-zA-Z ]*$")
	private String agentName;

	// @Pattern(regexp = "^[a-zA-Z0-9]*$")
	private String agentId;

	@Pattern(regexp = "^[a-zA-Z0-9 ]*$")
	private String planId;

	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String effectDateCoverage;

	@Pattern(regexp = "^[a-zA-Z0-9]*$")
	private String icep;

	@Pattern(regexp = "^[a-zA-Z0-9]*$")
	private String aep;

	@Pattern(regexp = "^[a-zA-Z0-9]*$")
	private String sep;

	private String legalCityState;

	private String agentIdNameCheck;

	private String preferAudioTape;
	private String errorunCovChBoxValue;
	private String unionCoverage;
	private String errornewElgbChBoxValue;
	private String errorrevMedChBoxValue;
	private String errorlevEmpChBoxValue;
	private String errornlElgPrescChBoxValue;
	private String errorrecntMovChBoxValue;
	private String errorrecnMovOutChBoxValue;
	private String errorrecntleftPlChBoxValue;
	private String errormvdUsChBoxValue;
	private String errormcNumChBoxValue;
	private String erroroutLngTermFcSeeChBoxValue;
	private String errornoElgbspseChBoxValue;
	private String errorprefEmailChBoxValue;
	private String erropreferEmailValue;
	private String errorphNumValue;
	private String errorrecentlyCreditableValue;
	private String errornewlyEligbleMedicareValue;
	private String errorrecieveMedicareDrugsValue;
	private String errorleavingEmployerCoverageValue;
	private String errornoEligbPrescDrugsValue;
	private String errorrecentMovedOptionValue;
	private String errorrecntMovedOutSideValue;
	private String errorrecntLeftPaceValue;
	private String errormovedBackUsValue;
	private String errorUnionCoverageValue;
	private String erroroutLongTermFacilityValue;
	private String errornoEligSpecialValue;

	private String eligibleEnroll;

	
	//Begin: 2019 Attestation Changes
	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String changeInMedicaid;
	private String changeInMedicaidChBox;
	private String errorChangeInMedicaidValue;
	private String errorChangeInMedicaidChBoxValue;

	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String changeInExtraHelp;
	private String changeInExtraHelpChBox;
	private String errorChangeInExtraHelpValue;
	private String errorChangeInExtraHelpChBoxValue;

	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String changeInMedicare;
	private String changeInMedicareChBox;
	private String errorChangeInMedicareValue;
	private String errorChangeInMedicareChBoxValue;
	
	public String getChangeInMedicare() {
		return changeInMedicare;
	}

	public void setChangeInMedicare(String changeInMedicare) {
		this.changeInMedicare = changeInMedicare;
	}

	public String getChangeInMedicareChBox() {
		return changeInMedicareChBox;
	}

	public void setChangeInMedicareChBox(String changeInMedicareChBox) {
		this.changeInMedicareChBox = changeInMedicareChBox;
	}

	public String getErrorChangeInMedicareValue() {
		return errorChangeInMedicareValue;
	}

	public void setErrorChangeInMedicareValue(String errorChangeInMedicareValue) {
		this.errorChangeInMedicareValue = errorChangeInMedicareValue;
	}

	public String getErrorChangeInMedicareChBoxValue() {
		return errorChangeInMedicareChBoxValue;
	}

	public void setErrorChangeInMedicareChBoxValue(String errorChangeInMedicareChBoxValue) {
		this.errorChangeInMedicareChBoxValue = errorChangeInMedicareChBoxValue;
	}

	public String getChangeInExtraHelp() {
		return changeInExtraHelp;
	}

	public void setChangeInExtraHelp(String changeInExtraHelp) {
		this.changeInExtraHelp = changeInExtraHelp;
	}

	public String getChangeInExtraHelpChBox() {
		return changeInExtraHelpChBox;
	}

	public void setChangeInExtraHelpChBox(String changeInExtraHelpChBox) {
		this.changeInExtraHelpChBox = changeInExtraHelpChBox;
	}

	public String getErrorChangeInExtraHelpValue() {
		return errorChangeInExtraHelpValue;
	}

	public void setErrorChangeInExtraHelpValue(String errorChangeInExtraHelpValue) {
		this.errorChangeInExtraHelpValue = errorChangeInExtraHelpValue;
	}

	public String getErrorChangeInExtraHelpChBoxValue() {
		return errorChangeInExtraHelpChBoxValue;
	}

	public void setErrorChangeInExtraHelpChBoxValue(String errorChangeInExtraHelpChBoxValue) {
		this.errorChangeInExtraHelpChBoxValue = errorChangeInExtraHelpChBoxValue;
	}

	public String getErrorChangeInMedicaidChBoxValue() {
		return errorChangeInMedicaidChBoxValue;
	}

	public void setErrorChangeInMedicaidChBoxValue(String errorChangeInMedicaidChBoxValue) {
		this.errorChangeInMedicaidChBoxValue = errorChangeInMedicaidChBoxValue;
	}

	public String getChangeInMedicaidChBox() {
		return changeInMedicaidChBox;
	}

	public void setChangeInMedicaidChBox(String changeInMedicaidChBox) {
		this.changeInMedicaidChBox = changeInMedicaidChBox;
	}

	public String getErrorChangeInMedicaidValue() {
		return errorChangeInMedicaidValue;
	}

	public void setErrorChangeInMedicaidValue(String errorChangeInMedicaidValue) {
		this.errorChangeInMedicaidValue = errorChangeInMedicaidValue;
	}

	public String getChangeInMedicaid() {
		return changeInMedicaid;
	}

	public void setChangeInMedicaid(String changeInMedicaid) {
		this.changeInMedicaid = changeInMedicaid;
	}
	//End: 2019 Attestation Changes


	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String recentlyCreditable;

	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String newlyEligbleMedicare;

	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String recieveMedicareDrugs;

	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String leavingEmployerCoverage;

	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String noEligbPrescDrugs;

	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String recentMovedOption;

	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String recntMovedOutSide;

	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String recntLeftPace;

	private String planEndingContract;

	private String belongStatePharmacy;

	private String noneApplyMe;

	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String movedBackUs;

	private String medicardNumber;

	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String outLongTermFacility;

	private String nameOfInst;

	@Pattern(regexp = "^[[0-9]{3}-[0-9]{3}-[0-9]{4}]*$")

	private String phNum;

	private String adressInstStreet;

	private String adressInstNumber;

	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String noEligSpecial;

	private String otherReasons;
	@Email
	private String preferEmail;
	private String preferCd;

	private String trcntCreditChBox;
	private String newElgbChBox;
	private String revMedChBox;
	private String levEmpChBox;
	private String nlElgPrescChBox;
	private String recntMovChBox;
	private String recnMovOutChBox;
	private String recntleftPlChBox;
	private String mvdUsChBox;
	private String unCovChBox;

	private String mcNumChBox;
	private String outLngTermFcSeeChBox;
	private String noElgbspseChBox;
	private String prefEmailChBox;

	private String longtermCareFacility;
	

	//Begin: 2019 Attestation Changes
	private String MAOEPChange;
	
	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String chngMedicaidSeValue;
	private String errorchngMedicaidChBoxValue;
	private String chngMedicaidChBox;
	private String chngMedicaidDate;
	
	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String chngExtraHelpSeValue;
	private String errorchngExtraHelpChBoxValue;
	private String chngExtraHelpChBox;
	private String chngExtraHelpDate;
	
	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String chngMedicareSeValue;
	private String errorchngMedicareChBoxValue;
	private String chngMedicareChBox;
	private String chngMedicareDate;
	
	private String affectedByDisaster;
	
	public String getAffectedByDisaster() {
		return affectedByDisaster;
	}

	public void setAffectedByDisaster(String affectedByDisaster) {
		this.affectedByDisaster = affectedByDisaster;
	}

	public String getChngExtraHelpSeValue() {
		return chngExtraHelpSeValue;
	}

	public void setChngExtraHelpSeValue(String chngExtraHelpSeValue) {
		this.chngExtraHelpSeValue = chngExtraHelpSeValue;
	}

	public String getErrorchngExtraHelpChBoxValue() {
		return errorchngExtraHelpChBoxValue;
	}

	public void setErrorchngExtraHelpChBoxValue(String errorchngExtraHelpChBoxValue) {
		this.errorchngExtraHelpChBoxValue = errorchngExtraHelpChBoxValue;
	}

	public String getChngExtraHelpChBox() {
		return chngExtraHelpChBox;
	}

	public void setChngExtraHelpChBox(String chngExtraHelpChBox) {
		this.chngExtraHelpChBox = chngExtraHelpChBox;
	}

	public String getChngExtraHelpDate() {
		return chngExtraHelpDate;
	}

	public void setChngExtraHelpDate(String chngExtraHelpDate) {
		this.chngExtraHelpDate = chngExtraHelpDate;
	}

	public String getChngMedicareSeValue() {
		return chngMedicareSeValue;
	}

	public void setChngMedicareSeValue(String chngMedicareSeValue) {
		this.chngMedicareSeValue = chngMedicareSeValue;
	}

	public String getErrorchngMedicareChBoxValue() {
		return errorchngMedicareChBoxValue;
	}

	public void setErrorchngMedicareChBoxValue(String errorchngMedicareChBoxValue) {
		this.errorchngMedicareChBoxValue = errorchngMedicareChBoxValue;
	}

	public String getChngMedicareChBox() {
		return chngMedicareChBox;
	}

	public void setChngMedicareChBox(String chngMedicareChBox) {
		this.chngMedicareChBox = chngMedicareChBox;
	}

	public String getChngMedicareDate() {
		return chngMedicareDate;
	}

	public void setChngMedicareDate(String chngMedicareDate) {
		this.chngMedicareDate = chngMedicareDate;
	}

	public String getChngMedicaidChBox() {
		return chngMedicaidChBox;
	}

	public void setChngMedicaidChBox(String chngMedicaidChBox) {
		this.chngMedicaidChBox = chngMedicaidChBox;
	}

	public String getChngMedicaidDate() {
		return chngMedicaidDate;
	}

	public void setChngMedicaidDate(String chngMedicaidDate) {
		this.chngMedicaidDate = chngMedicaidDate;
	}

	public String getErrorchngMedicaidChBoxValue() {
		return errorchngMedicaidChBoxValue;
	}

	public void setErrorchngMedicaidChBoxValue(String errorchngMedicaidChBoxValue) {
		this.errorchngMedicaidChBoxValue = errorchngMedicaidChBoxValue;
	}

	public String getChngMedicaidSeValue() {
		return chngMedicaidSeValue;
	}

	public void setChngMedicaidSeValue(String chngMedicaidSeValue) {
		this.chngMedicaidSeValue = chngMedicaidSeValue;
	}
	
	public String getMAOEPChange() {
		return MAOEPChange;
	}

	public void setMAOEPChange(String mAOEPChange) {
		MAOEPChange = mAOEPChange;
	}
	
	//End: 2019 Attestation Changes
	
	
	public String getPreferAudioTape() {
		return preferAudioTape;
	}

	public void setPreferAudioTape(String preferAudioTape) {
		this.preferAudioTape = preferAudioTape;
	}

	public String getPrefEmailChBox() {
		return prefEmailChBox;
	}

	public void setPrefEmailChBox(String prefEmailChBox) {
		this.prefEmailChBox = prefEmailChBox;
	}

	public String getNoElgbspseChBox() {
		return noElgbspseChBox;
	}

	public void setNoElgbspseChBox(String noElgbspseChBox) {
		this.noElgbspseChBox = noElgbspseChBox;
	}

	public String getOutLngTermFcSeeChBox() {
		return outLngTermFcSeeChBox;
	}

	public void setOutLngTermFcSeeChBox(String outLngTermFcSeeChBox) {
		this.outLngTermFcSeeChBox = outLngTermFcSeeChBox;
	}

	public String getMcNumChBox() {
		return mcNumChBox;
	}

	public void setMcNumChBox(String mcNumChBox) {
		this.mcNumChBox = mcNumChBox;
	}

	public String getMvdUsChBox() {
		return mvdUsChBox;
	}

	public void setMvdUsChBox(String mvdUsChBox) {
		this.mvdUsChBox = mvdUsChBox;
	}

	public String getUnCovChBox() {
		return unCovChBox;
	}

	public void setUnCovChBox(String unCovChBox) {
		this.unCovChBox = unCovChBox;
	}

	public String getRecntleftPlChBox() {
		return recntleftPlChBox;
	}

	public void setRecntleftPlChBox(String recntleftPlChBox) {
		this.recntleftPlChBox = recntleftPlChBox;
	}

	public String getRecnMovOutChBox() {
		return recnMovOutChBox;
	}

	public void setRecnMovOutChBox(String recnMovOutChBox) {
		this.recnMovOutChBox = recnMovOutChBox;
	}

	public String getRecntMovChBox() {
		return recntMovChBox;
	}

	public void setRecntMovChBox(String recntMovChBox) {
		this.recntMovChBox = recntMovChBox;
	}

	public String getNlElgPrescChBox() {
		return nlElgPrescChBox;
	}

	public void setNlElgPrescChBox(String nlElgPrescChBox) {
		this.nlElgPrescChBox = nlElgPrescChBox;
	}

	public String getLevEmpChBox() {
		return levEmpChBox;
	}

	public void setLevEmpChBox(String levEmpChBox) {
		this.levEmpChBox = levEmpChBox;
	}

	public String getRevMedChBox() {
		return revMedChBox;
	}

	public void setRevMedChBox(String revMedChBox) {
		this.revMedChBox = revMedChBox;
	}

	public String getNewElgbChBox() {
		return newElgbChBox;
	}

	public void setNewElgbChBox(String newElgbChBox) {
		this.newElgbChBox = newElgbChBox;
	}

	public String getTrcntCreditChBox() {
		return trcntCreditChBox;
	}

	public void setTrcntCreditChBox(String trcntCreditChBox) {
		this.trcntCreditChBox = trcntCreditChBox;
	}

	public String getEligibleEnroll() {
		return eligibleEnroll;
	}

	public void setEligibleEnroll(String eligibleEnroll) {
		this.eligibleEnroll = eligibleEnroll;
	}

	public String getRecentlyCreditable() {
		return recentlyCreditable;
	}

	public void setRecentlyCreditable(String recentlyCreditable) {
		this.recentlyCreditable = recentlyCreditable;
	}

	public String getNewlyEligbleMedicare() {
		return newlyEligbleMedicare;
	}

	public void setNewlyEligbleMedicare(String newlyEligbleMedicare) {
		this.newlyEligbleMedicare = newlyEligbleMedicare;
	}

	public String getRecieveMedicareDrugs() {
		return recieveMedicareDrugs;
	}

	public void setRecieveMedicareDrugs(String recieveMedicareDrugs) {
		this.recieveMedicareDrugs = recieveMedicareDrugs;
	}

	public String getLeavingEmployerCoverage() {
		return leavingEmployerCoverage;
	}

	public void setLeavingEmployerCoverage(String leavingEmployerCoverage) {
		this.leavingEmployerCoverage = leavingEmployerCoverage;
	}

	public String getNoEligbPrescDrugs() {
		return noEligbPrescDrugs;
	}

	public void setNoEligbPrescDrugs(String noEligbPrescDrugs) {
		this.noEligbPrescDrugs = noEligbPrescDrugs;
	}

	public String getRecentMovedOption() {
		return recentMovedOption;
	}

	public void setRecentMovedOption(String recentMovedOption) {
		this.recentMovedOption = recentMovedOption;
	}

	public String getRecntMovedOutSide() {
		return recntMovedOutSide;
	}

	public void setRecntMovedOutSide(String recntMovedOutSide) {
		this.recntMovedOutSide = recntMovedOutSide;
	}

	public String getRecntLeftPace() {
		return recntLeftPace;
	}

	public void setRecntLeftPace(String recntLeftPace) {
		this.recntLeftPace = recntLeftPace;
	}

	public String getPlanEndingContract() {
		return planEndingContract;
	}

	public void setPlanEndingContract(String planEndingContract) {
		this.planEndingContract = planEndingContract;
	}

	public String getBelongStatePharmacy() {
		return belongStatePharmacy;
	}

	public void setBelongStatePharmacy(String belongStatePharmacy) {
		this.belongStatePharmacy = belongStatePharmacy;
	}

	public String getNoneApplyMe() {
		return noneApplyMe;
	}

	public void setNoneApplyMe(String noneApplyMe) {
		this.noneApplyMe = noneApplyMe;
	}

	public String getMovedBackUs() {
		return movedBackUs;
	}

	public void setMovedBackUs(String movedBackUs) {
		this.movedBackUs = movedBackUs;
	}

	public String getUnionCoverage() {
		return unionCoverage;
	}

	public void setUnionCoverage(String unionCoverage) {
		this.unionCoverage = unionCoverage;
	}

	public String getMedicardNumber() {
		return medicardNumber;
	}

	public void setMedicardNumber(String medicardNumber) {
		this.medicardNumber = medicardNumber;
	}

	public String getOutLongTermFacility() {
		return outLongTermFacility;
	}

	public void setOutLongTermFacility(String outLongTermFacility) {
		this.outLongTermFacility = outLongTermFacility;
	}

	public String getNameOfInst() {
		return nameOfInst;
	}

	public void setNameOfInst(String nameOfInst) {
		this.nameOfInst = nameOfInst;
	}

	public String getPhNum() {
		return phNum;
	}

	public void setPhNum(String phNum) {
		this.phNum = phNum;
	}

	public String getAdressInstStreet() {
		return adressInstStreet;
	}

	public void setAdressInstStreet(String adressInstStreet) {
		this.adressInstStreet = adressInstStreet;
	}

	public String getAdressInstNumber() {
		return adressInstNumber;
	}

	public void setAdressInstNumber(String adressInstNumber) {
		this.adressInstNumber = adressInstNumber;
	}

	public String getNoEligSpecial() {
		return noEligSpecial;
	}

	public void setNoEligSpecial(String noEligSpecial) {
		this.noEligSpecial = noEligSpecial;
	}

	public String getOtherReasons() {
		return otherReasons;
	}

	public void setOtherReasons(String otherReasons) {
		this.otherReasons = otherReasons;
	}

	public String getPreferEmail() {
		return preferEmail;
	}

	public void setPreferEmail(String preferEmail) {
		this.preferEmail = preferEmail;
	}

	public String getPreferCd() {
		return preferCd;
	}

	public void setPreferCd(String preferCd) {
		this.preferCd = preferCd;
	}

	private String errortrcntCreditChBoxValue;

	public String getErrortrcntCreditChBoxValue() {
		return errortrcntCreditChBoxValue;
	}

	public void setErrortrcntCreditChBoxValue(String errortrcntCreditChBoxValue) {
		this.errortrcntCreditChBoxValue = errortrcntCreditChBoxValue;
	}

	public String getErrornewElgbChBoxValue() {
		return errornewElgbChBoxValue;
	}

	public void setErrornewElgbChBoxValue(String errornewElgbChBoxValue) {
		this.errornewElgbChBoxValue = errornewElgbChBoxValue;
	}

	public String getErrorrevMedChBoxValue() {
		return errorrevMedChBoxValue;
	}

	public void setErrorrevMedChBoxValue(String errorrevMedChBoxValue) {
		this.errorrevMedChBoxValue = errorrevMedChBoxValue;
	}

	public String getErrorlevEmpChBoxValue() {
		return errorlevEmpChBoxValue;
	}

	public void setErrorlevEmpChBoxValue(String errorlevEmpChBoxValue) {
		this.errorlevEmpChBoxValue = errorlevEmpChBoxValue;
	}

	public String getErrornlElgPrescChBoxValue() {
		return errornlElgPrescChBoxValue;
	}

	public void setErrornlElgPrescChBoxValue(String errornlElgPrescChBoxValue) {
		this.errornlElgPrescChBoxValue = errornlElgPrescChBoxValue;
	}

	public String getErrorrecntMovChBoxValue() {
		return errorrecntMovChBoxValue;
	}

	public void setErrorrecntMovChBoxValue(String errorrecntMovChBoxValue) {
		this.errorrecntMovChBoxValue = errorrecntMovChBoxValue;
	}

	public String getErrorrecnMovOutChBoxValue() {
		return errorrecnMovOutChBoxValue;
	}

	public void setErrorrecnMovOutChBoxValue(String errorrecnMovOutChBoxValue) {
		this.errorrecnMovOutChBoxValue = errorrecnMovOutChBoxValue;
	}

	public String getErrorrecntleftPlChBoxValue() {
		return errorrecntleftPlChBoxValue;
	}

	public void setErrorrecntleftPlChBoxValue(String errorrecntleftPlChBoxValue) {
		this.errorrecntleftPlChBoxValue = errorrecntleftPlChBoxValue;
	}

	public String getErrormvdUsChBoxValue() {
		return errormvdUsChBoxValue;
	}

	public void setErrormvdUsChBoxValue(String errormvdUsChBoxValue) {
		this.errormvdUsChBoxValue = errormvdUsChBoxValue;
	}

	public String getErrorunCovChBoxValue() {
		return errorunCovChBoxValue;
	}

	public void setErrorunCovChBoxValue(String errorunCovChBoxValue) {
		this.errorunCovChBoxValue = errorunCovChBoxValue;
	}

	public String getErrormcNumChBoxValue() {
		return errormcNumChBoxValue;
	}

	public void setErrormcNumChBoxValue(String errormcNumChBoxValue) {
		this.errormcNumChBoxValue = errormcNumChBoxValue;
	}

	public String getErroroutLngTermFcSeeChBoxValue() {
		return erroroutLngTermFcSeeChBoxValue;
	}

	public void setErroroutLngTermFcSeeChBoxValue(String erroroutLngTermFcSeeChBoxValue) {
		this.erroroutLngTermFcSeeChBoxValue = erroroutLngTermFcSeeChBoxValue;
	}

	public String getErrornoElgbspseChBoxValue() {
		return errornoElgbspseChBoxValue;
	}

	public void setErrornoElgbspseChBoxValue(String errornoElgbspseChBoxValue) {
		this.errornoElgbspseChBoxValue = errornoElgbspseChBoxValue;
	}

	public String getErrorprefEmailChBoxValue() {
		return errorprefEmailChBoxValue;
	}

	public void setErrorprefEmailChBoxValue(String errorprefEmailChBoxValue) {
		this.errorprefEmailChBoxValue = errorprefEmailChBoxValue;
	}

	public String getErropreferEmailValue() {
		return erropreferEmailValue;
	}

	public void setErropreferEmailValue(String erropreferEmailValue) {
		this.erropreferEmailValue = erropreferEmailValue;
	}

	public String getErrorphNumValue() {
		return errorphNumValue;
	}

	public void setErrorphNumValue(String errorphNumValue) {
		this.errorphNumValue = errorphNumValue;
	}

	public String getErrorrecentlyCreditableValue() {
		return errorrecentlyCreditableValue;
	}

	public void setErrorrecentlyCreditableValue(String errorrecentlyCreditableValue) {
		this.errorrecentlyCreditableValue = errorrecentlyCreditableValue;
	}

	public String getErrornewlyEligbleMedicareValue() {
		return errornewlyEligbleMedicareValue;
	}

	public void setErrornewlyEligbleMedicareValue(String errornewlyEligbleMedicareValue) {
		this.errornewlyEligbleMedicareValue = errornewlyEligbleMedicareValue;
	}

	public String getErrorrecieveMedicareDrugsValue() {
		return errorrecieveMedicareDrugsValue;
	}

	public void setErrorrecieveMedicareDrugsValue(String errorrecieveMedicareDrugsValue) {
		this.errorrecieveMedicareDrugsValue = errorrecieveMedicareDrugsValue;
	}

	public String getErrorleavingEmployerCoverageValue() {
		return errorleavingEmployerCoverageValue;
	}

	public void setErrorleavingEmployerCoverageValue(String errorleavingEmployerCoverageValue) {
		this.errorleavingEmployerCoverageValue = errorleavingEmployerCoverageValue;
	}

	public String getErrornoEligbPrescDrugsValue() {
		return errornoEligbPrescDrugsValue;
	}

	public void setErrornoEligbPrescDrugsValue(String errornoEligbPrescDrugsValue) {
		this.errornoEligbPrescDrugsValue = errornoEligbPrescDrugsValue;
	}

	public String getErrorrecentMovedOptionValue() {
		return errorrecentMovedOptionValue;
	}

	public void setErrorrecentMovedOptionValue(String errorrecentMovedOptionValue) {
		this.errorrecentMovedOptionValue = errorrecentMovedOptionValue;
	}

	public String getErrorrecntMovedOutSideValue() {
		return errorrecntMovedOutSideValue;
	}

	public void setErrorrecntMovedOutSideValue(String errorrecntMovedOutSideValue) {
		this.errorrecntMovedOutSideValue = errorrecntMovedOutSideValue;
	}

	public String getErrorrecntLeftPaceValue() {
		return errorrecntLeftPaceValue;
	}

	public void setErrorrecntLeftPaceValue(String errorrecntLeftPaceValue) {
		this.errorrecntLeftPaceValue = errorrecntLeftPaceValue;
	}

	public String getErrormovedBackUsValue() {
		return errormovedBackUsValue;
	}

	public void setErrormovedBackUsValue(String errormovedBackUsValue) {
		this.errormovedBackUsValue = errormovedBackUsValue;
	}

	public String getErrorUnionCoverageValue() {
		return errorUnionCoverageValue;
	}

	public void setErrorUnionCoverageValue(String errorUnionCoverageValue) {
		this.errorUnionCoverageValue = errorUnionCoverageValue;
	}

	public String getErroroutLongTermFacilityValue() {
		return erroroutLongTermFacilityValue;
	}

	public void setErroroutLongTermFacilityValue(String erroroutLongTermFacilityValue) {
		this.erroroutLongTermFacilityValue = erroroutLongTermFacilityValue;
	}

	public String getErrornoEligSpecialValue() {
		return errornoEligSpecialValue;
	}

	public void setErrornoEligSpecialValue(String errornoEligSpecialValue) {
		this.errornoEligSpecialValue = errornoEligSpecialValue;
	}

	public String getLongtermCareFacility() {
		return longtermCareFacility;
	}

	public void setLongtermCareFacility(String longtermCareFacility) {
		this.longtermCareFacility = longtermCareFacility;
	}

	public String getAgentIdNameCheck() {
		return agentIdNameCheck;
	}

	public void setAgentIdNameCheck(String agentIdNameCheck) {
		this.agentIdNameCheck = agentIdNameCheck;
	}

	public String getLegalCityState() {
		return legalCityState;
	}

	public void setLegalCityState(String legalCityState) {
		this.legalCityState = legalCityState;
	}

	public String getAgreeStatements() {
		return agreeStatements;
	}

	public void setAgreeStatements(String agreeStatements) {
		this.agreeStatements = agreeStatements;
	}

	public String getTodayDate() {
		DateFormat format = new SimpleDateFormat(VAPConstants.DateFormat);
		if(todayDate != null && todayDate.trim().equals("")){
			return todayDate = format.format(new Date());
		}else{
			return todayDate = format.format(new Date());
		}
	}

	public void setTodayDate(String todayDate) {
		DateFormat format = new SimpleDateFormat(VAPConstants.DateFormat);
		if(todayDate != null && todayDate.trim().equals("")){
			todayDate = format.format(new Date());
		}else{
			todayDate = format.format(new Date());
		}
		this.todayDate = todayDate;
	}

	public String getLegalAddress() {
		return legalAddress;
	}

	public void setLegalAddress(String legalAddress) {
		this.legalAddress = legalAddress;
	}

	public String getLegalPhNumber() {
		return legalPhNumber;
	}

	public void setLegalPhNumber(String legalPhNumber) {
		this.legalPhNumber = legalPhNumber;
	}

	public String getLegalRelationErloll() {
		return legalRelationErloll;
	}

	public void setLegalRelationErloll(String legalRelationErloll) {
		this.legalRelationErloll = legalRelationErloll;
	}

	public String getWebtelApp() {
		return webtelApp;
	}

	public void setWebtelApp(String webtelApp) {
		this.webtelApp = webtelApp;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public String getAgentId() {
		return agentId;
	}

	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}

	public String getPlanId() {
		return planId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}

	public String getEffectDateCoverage() {
		return effectDateCoverage;
	}

	public void setEffectDateCoverage(String effectDateCoverage) {
		this.effectDateCoverage = effectDateCoverage;
	}

	public String getIcep() {
		return icep;
	}

	public void setIcep(String icep) {
		this.icep = icep;
	}

	public String getAep() {
		return aep;
	}

	public void setAep(String aep) {
		this.aep = aep;
	}

	public String getSep() {
		return sep;
	}

	public void setSep(String sep) {
		this.sep = sep;
	}

	public String getLegalFirstName() {
		return legalFirstName;
	}

	public void setLegalFirstName(String legalFirstName) {
		this.legalFirstName = legalFirstName;
	}

	public String getLegalLastName() {
		return legalLastName;
	}

	public void setLegalLastName(String legalLastName) {
		this.legalLastName = legalLastName;
	}

	public String getLegalMiddleName() {
		return legalMiddleName;
	}

	public void setLegalMiddleName(String legalMiddleName) {
		this.legalMiddleName = legalMiddleName;
	}

	public String getLegalAddressTwo() {
		return legalAddressTwo;
	}

	public void setLegalAddressTwo(String legalAddressTwo) {
		this.legalAddressTwo = legalAddressTwo;
	}

	public String getLegalAddressThree() {
		return legalAddressThree;
	}

	public void setLegalAddressThree(String legalAddressThree) {
		this.legalAddressThree = legalAddressThree;
	}

	public String getLegalCity() {
		return legalCity;
	}

	public void setLegalCity(String legalCity) {
		this.legalCity = legalCity;
	}

	public String getLegalState() {
		return legalState;
	}

	public void setLegalState(String legalState) {
		this.legalState = legalState;
	}

	public String getLegalZipCode() {
		return legalZipCode;
	}

	public void setLegalZipCode(String legalZipCode) {
		this.legalZipCode = legalZipCode;
	}

	public String getIcepDate() {
		return icepDate;
	}

	public void setIcepDate(String icepDate) {
		this.icepDate = icepDate;
	}

	
	
	//New fields Added for SumaCare-START
		private String signature;
		private String todayRepDate;
		private String repSignature;
		private String signatureName;
		private String repSignatureName;

		public String getRepSignature() {
			return repSignature;
		}

		public void setRepSignature(String repSignature) {
			this.repSignature = repSignature;
		}

		public String getTodayRepDate() {
			return todayRepDate;
		}

		public void setTodayRepDate(String todayRepDate) {
			this.todayRepDate = todayRepDate;
		}

		public String getSignature() {
			return signature;
		}

		public void setSignature(String signature) {
			this.signature = signature;
		}

		public String getSignatureName() {
			return signatureName;
		}

		public void setSignatureName(String signatureName) {
			this.signatureName = signatureName;
		}

		public String getRepSignatureName() {
			return repSignatureName;
		}

		public void setRepSignatureName(String repSignatureName) {
			this.repSignatureName = repSignatureName;
		}
		
		//New fields Added for SumaCare-END
	
		//Begin: Added for IFOX-00390786 (Phase-II)
		private String errorlegalFirstNameValue;
		private String errorlegalAddressTwoValue;
		//End: Added for IFOX-00390786 (Phase-II)

		public String getErrorlegalFirstNameValue() {
			return errorlegalFirstNameValue;
		}

		public void setErrorlegalFirstNameValue(String errorlegalFirstNameValue) {
			this.errorlegalFirstNameValue = errorlegalFirstNameValue;
		}

		public String getErrorlegalAddressTwoValue() {
			return errorlegalAddressTwoValue;
		}

		public void setErrorlegalAddressTwoValue(String errorlegalAddressTwoValue) {
			this.errorlegalAddressTwoValue = errorlegalAddressTwoValue;
		}
}
