package com.medicare.vo;

import java.io.Serializable;

public class EnrollmentVO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String customerId;
	private String loginEmailId;
	private String productId;
	private String groupId;
	private String pbpId;
	private String planId;
	
	private String electionType;
	
//Screen - 1 Fields	
	
	private String prefix;
	private String firstName;
	private String lastName;
	private String suffix;
	private String middleInitial;
	private String birthDate;
	private String sex;
	private String primaryPhone;
	private String cellPhone;
	
	private String permanentAddrStreet;
	private String permanentAddrApt;
	private String permanentCounty;
	private String permanentCity;
	private String permanentState;
	private String permanentZip;
	
	private String mailingAddressRequired;
	
	private String mailingAddr;
	private String mailingCity;
	private String mailingState;
	private String mailingzip;
	private String emailAddr;
	
	private String emailAlert;
	private String callAlert;
	
	// Screen Part - II
	
	private String medicareClaim;
	private String hospitalPartA;
	private String hospitalPartB;
	private String paymentOption;
	
	private String acctholdername;
	private String bankname;
	private String acctType;
	private String routingNumber;
	private String accountNumber;
	private String monthlybf;
	
	private String renalDisease; 
	private String esrdcontact;
	private String vaBenefits;    
	private String nameOfCov;
	private String idOfCov;
	private String groupOfCov;
	
	private String medicaidprg;
	private String medicaidNbr;
	private String prescriptionDrug;
	
	private String nameOfInst;
	private String phoneOfInst;
	private String addrOfInst;
	
	private String spousework;
	private String pcpName;
	private String pcpMedicalGroupName;
	private String existingp;
	private String language;
	
	private String languageValue;
	
	// Screen PART - III
	
	private String aep;
	
	private String c1;
	private String c2;
	private String attestation2;
	private String c3;
	
	private String attestation3;
	private String c4;
	
	private String attestation4;
	private String c5;
	private String attestation5;
	
	private String c6;
	private String c7;
	private String c8;
	private String attestation8;
	
	private String c9;
	private String attestation9;
	
	private String c10;
	private String attestation10;
	
	private String c11;
	private String attestation11;
	
	private String c12;
	private String attestation12;
	
	private String c13;
	private String c14;
	private String c15;
	private String attestation15;
	private String c16;
	private String c16Attestation;
	private String attestation16;
	private String coveragebegin;
	
	// Screen - PART IV
	
	private String nameSignature;
	private String digitalSignature;
	private String todaysDate;
	
	private String AuthorizedRep;
	private String authorizedrepname;
	private String authorizedreprelationship;
	private String authorizedrepaddress;
	private String authorizedrepphone;
	
	private String AgentAssistingEnrollment;
	private String nameAgent;
	private String agentLicense;
	
	private String retiree;
	private String retiredate;
	private String retirename;
	private String meddependsp;
	private String dependentSpouse;
	private String dependentOther;
	private String hlthcovType;
	private String hlthcovInscomp;
	
	private String c20;
	/**IFOX-00403984 Changes Start.*/
	private String effDate;
	/**IFOX-00403984 Changes Stop.*/
	
	
	//Begin: 2019 web app changes - IFOX-00406768
	
	private String c21;
	private String attestation21;
	
	private String c22;
	private String attestation22;
	
	private String c23;
	private String attestation23;
	
	private String c24;
	private String attestation24;
	
	private String c25;
	private String attestation25;
	
	//IFOX-00419089 PBP 801 CR - Start
	private String ssn;
		
	public String getSsn() {
		return ssn;
	}
	public void setSsn(String ssn) {
		this.ssn = ssn;
	}
	//IFOX-00419089 PBP 801 CR - End

	private String planYear;
	
	public String getPlanYear() {
		return planYear;
	}
	public void setPlanYear(String planYear) {
		this.planYear = planYear;
	}
	public String getC21() {
		return c21;
	}
	public void setC21(String c21) {
		this.c21 = c21;
	}
	public String getAttestation21() {
		return attestation21;
	}
	public void setAttestation21(String attestation21) {
		this.attestation21 = attestation21;
	}
	public String getC22() {
		return c22;
	}
	public void setC22(String c22) {
		this.c22 = c22;
	}
	public String getAttestation22() {
		return attestation22;
	}
	public void setAttestation22(String attestation22) {
		this.attestation22 = attestation22;
	}
	public String getC23() {
		return c23;
	}
	public void setC23(String c23) {
		this.c23 = c23;
	}
	public String getAttestation23() {
		return attestation23;
	}
	public void setAttestation23(String attestation23) {
		this.attestation23 = attestation23;
	}
	public String getC24() {
		return c24;
	}
	public void setC24(String c24) {
		this.c24 = c24;
	}
	public String getAttestation24() {
		return attestation24;
	}
	public void setAttestation24(String attestation24) {
		this.attestation24 = attestation24;
	}
	public String getC25() {
		return c25;
	}
	public void setC25(String c25) {
		this.c25 = c25;
	}
	public String getAttestation25() {
		return attestation25;
	}
	public void setAttestation25(String attestation25) {
		this.attestation25 = attestation25;
	}

	//End: 2019 web app changes - IFOX-00406768
	
	
	//Begin: Modified for IFOX-00414491
	private String coveringSpouseOrDependent;
	private String coveringSpouseOrDependentLastName;
	private String coveringSpouseOrDependentFirstName;
	private String coveringSpouseOrDependentMiddleName;
	private String coveringSpouseOrDependentEmployeeName;
	
	private String survivingSpouseCitySanDiegoRetiree;
	private String survivingSpouseCitySanDiegoRetireeLastName;
	private String survivingSpouseCitySanDiegoRetireeFirstName;
	private String survivingSpouseCitySanDiegoRetireeMiddleName;
	
	public String getCoveringSpouseOrDependent() {
		return coveringSpouseOrDependent;
	}
	public void setCoveringSpouseOrDependent(String coveringSpouseOrDependent) {
		this.coveringSpouseOrDependent = coveringSpouseOrDependent;
	}
	public String getCoveringSpouseOrDependentLastName() {
		return coveringSpouseOrDependentLastName;
	}
	public void setCoveringSpouseOrDependentLastName(String coveringSpouseOrDependentLastName) {
		this.coveringSpouseOrDependentLastName = coveringSpouseOrDependentLastName;
	}
	public String getCoveringSpouseOrDependentFirstName() {
		return coveringSpouseOrDependentFirstName;
	}
	public void setCoveringSpouseOrDependentFirstName(String coveringSpouseOrDependentFirstName) {
		this.coveringSpouseOrDependentFirstName = coveringSpouseOrDependentFirstName;
	}
	public String getCoveringSpouseOrDependentMiddleName() {
		return coveringSpouseOrDependentMiddleName;
	}
	public void setCoveringSpouseOrDependentMiddleName(String coveringSpouseOrDependentMiddleName) {
		this.coveringSpouseOrDependentMiddleName = coveringSpouseOrDependentMiddleName;
	}
	public String getCoveringSpouseOrDependentEmployeeName() {
		return coveringSpouseOrDependentEmployeeName;
	}
	public void setCoveringSpouseOrDependentEmployeeName(String coveringSpouseOrDependentEmployeeName) {
		this.coveringSpouseOrDependentEmployeeName = coveringSpouseOrDependentEmployeeName;
	}
	public String getSurvivingSpouseCitySanDiegoRetiree() {
		return survivingSpouseCitySanDiegoRetiree;
	}
	public void setSurvivingSpouseCitySanDiegoRetiree(String survivingSpouseCitySanDiegoRetiree) {
		this.survivingSpouseCitySanDiegoRetiree = survivingSpouseCitySanDiegoRetiree;
	}
	public String getSurvivingSpouseCitySanDiegoRetireeLastName() {
		return survivingSpouseCitySanDiegoRetireeLastName;
	}
	public void setSurvivingSpouseCitySanDiegoRetireeLastName(String survivingSpouseCitySanDiegoRetireeLastName) {
		this.survivingSpouseCitySanDiegoRetireeLastName = survivingSpouseCitySanDiegoRetireeLastName;
	}
	public String getSurvivingSpouseCitySanDiegoRetireeFirstName() {
		return survivingSpouseCitySanDiegoRetireeFirstName;
	}
	public void setSurvivingSpouseCitySanDiegoRetireeFirstName(String survivingSpouseCitySanDiegoRetireeFirstName) {
		this.survivingSpouseCitySanDiegoRetireeFirstName = survivingSpouseCitySanDiegoRetireeFirstName;
	}
	public String getSurvivingSpouseCitySanDiegoRetireeMiddleName() {
		return survivingSpouseCitySanDiegoRetireeMiddleName;
	}
	public void setSurvivingSpouseCitySanDiegoRetireeMiddleName(String survivingSpouseCitySanDiegoRetireeMiddleName) {
		this.survivingSpouseCitySanDiegoRetireeMiddleName = survivingSpouseCitySanDiegoRetireeMiddleName;
	}
	//End: Modified for IFOX-00414491
	
	
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getPlanId() {
		//return planId;
		return "H5386";
	}
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	public String getLoginEmailId() {
		return loginEmailId;
	}
	public void setLoginEmailId(String loginEmailId) {
		this.loginEmailId = loginEmailId;
	}
	public String getPrefix() {
		return prefix;
	}
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getSuffix() {
		return suffix;
	}
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}
	public String getMiddleInitial() {
		return middleInitial;
	}
	public void setMiddleInitial(String middleInitial) {
		this.middleInitial = middleInitial;
	}
	public String getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getPrimaryPhone() {
		return primaryPhone;
	}
	public void setPrimaryPhone(String primaryPhone) {
		this.primaryPhone = primaryPhone;
	}
	public String getCellPhone() {
		if ("".equals(cellPhone)){
			return "         ";
		}
		return cellPhone;
	}
	public void setCellPhone(String cellPhone) {
		this.cellPhone = cellPhone;
	}
	public String getPermanentAddrStreet() {
		return permanentAddrStreet;
	}
	public void setPermanentAddrStreet(String permanentAddrStreet) {
		this.permanentAddrStreet = permanentAddrStreet;
	}
	public String getPermanentAddrApt() {
		return permanentAddrApt;
	}
	public void setPermanentAddrApt(String permanentAddrApt) {
		this.permanentAddrApt = permanentAddrApt;
	}
	public String getPermanentCounty() {
		return permanentCounty;
	}
	public void setPermanentCounty(String permanentCounty) {
		this.permanentCounty = permanentCounty;
	}
	public String getPermanentCity() {
		return permanentCity;
	}
	public void setPermanentCity(String permanentCity) {
		this.permanentCity = permanentCity;
	}
	public String getPermanentState() {
		return permanentState;
	}
	public void setPermanentState(String permanentState) {
		this.permanentState = permanentState;
	}
	public String getPermanentZip() {
		return permanentZip;
	}
	public void setPermanentZip(String permanentZip) {
		this.permanentZip = permanentZip;
	}
	public String getMailingAddressRequired() {
		return mailingAddressRequired;
	}
	public void setMailingAddressRequired(String mailingAddressRequired) {
		this.mailingAddressRequired = mailingAddressRequired;
	}
	public String getMailingAddr() {
		return mailingAddr;
	}
	public void setMailingAddr(String mailingAddr) {
		this.mailingAddr = mailingAddr;
	}
	public String getMailingCity() {
		return mailingCity;
	}
	public void setMailingCity(String mailingCity) {
		this.mailingCity = mailingCity;
	}
	public String getMailingState() {
		return mailingState;
	}
	public void setMailingState(String mailingState) {
		this.mailingState = mailingState;
	}
	public String getMailingzip() {
		return mailingzip;
	}
	public void setMailingzip(String mailingzip) {
		this.mailingzip = mailingzip;
	}
	public String getEmailAddr() {
		return emailAddr;
	}
	public void setEmailAddr(String emailAddr) {
		this.emailAddr = emailAddr;
	}

	public String getMedicareClaim() {
		
		String hicNumber = "";
		
		if(medicareClaim != null){
			hicNumber = medicareClaim.replace("-", "");
		}
		
		return hicNumber;
	}
	public void setMedicareClaim(String medicareClaim) {
		this.medicareClaim = medicareClaim;
	}
	public String getHospitalPartA() {
		return hospitalPartA;
	}
	public void setHospitalPartA(String hospitalPartA) {
		this.hospitalPartA = hospitalPartA;
	}
	public String getHospitalPartB() {
		return hospitalPartB;
	}
	public void setHospitalPartB(String hospitalPartB) {
		this.hospitalPartB = hospitalPartB;
	}
	public String getPaymentOption() {
		return paymentOption;
	}
	public void setPaymentOption(String paymentOption) {
		this.paymentOption = paymentOption;
	}
	public String getAcctholdername() {
		return acctholdername;
	}
	public void setAcctholdername(String acctholdername) {
		this.acctholdername = acctholdername;
	}
	public String getBankname() {
		return bankname;
	}
	public void setBankname(String bankname) {
		this.bankname = bankname;
	}
	public String getAcctType() {
		return acctType;
	}
	public void setAcctType(String acctType) {
		this.acctType = acctType;
	}
	public String getRoutingNumber() {
		return routingNumber;
	}
	public void setRoutingNumber(String routingNumber) {
		this.routingNumber = routingNumber;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getMonthlybf() {
		return monthlybf;
	}
	public void setMonthlybf(String monthlybf) {
		this.monthlybf = monthlybf;
	}
	public String getRenalDisease() {
		return renalDisease;
	}
	public void setRenalDisease(String renalDisease) {
		this.renalDisease = renalDisease;
	}
	public String getEsrdcontact() {
		return esrdcontact;
	}
	public void setEsrdcontact(String esrdcontact) {
		this.esrdcontact = esrdcontact;
	}
	public String getVaBenefits() {
		return vaBenefits;
	}
	public void setVaBenefits(String vaBenefits) {
		this.vaBenefits = vaBenefits;
	}
	public String getNameOfCov() {
		return nameOfCov;
	}
	public void setNameOfCov(String nameOfCov) {
		this.nameOfCov = nameOfCov;
	}
	public String getIdOfCov() {
		return idOfCov;
	}
	public void setIdOfCov(String idOfCov) {
		this.idOfCov = idOfCov;
	}
	public String getGroupOfCov() {
		return groupOfCov;
	}
	public void setGroupOfCov(String groupOfCov) {
		this.groupOfCov = groupOfCov;
	}
	public String getMedicaidprg() {
		return medicaidprg;
	}
	public void setMedicaidprg(String medicaidprg) {
		this.medicaidprg = medicaidprg;
	}
	public String getMedicaidNbr() {
		return medicaidNbr;
	}
	public void setMedicaidNbr(String medicaidNbr) {
		this.medicaidNbr = medicaidNbr;
	}
	public String getPrescriptionDrug() {
		return prescriptionDrug;
	}
	public void setPrescriptionDrug(String prescriptionDrug) {
		this.prescriptionDrug = prescriptionDrug;
	}
	public String getNameOfInst() {
		return nameOfInst;
	}
	public void setNameOfInst(String nameOfInst) {
		this.nameOfInst = nameOfInst;
	}
	public String getPhoneOfInst() {
		return phoneOfInst;
	}
	public void setPhoneOfInst(String phoneOfInst) {
		this.phoneOfInst = phoneOfInst;
	}
	public String getAddrOfInst() {
		return addrOfInst;
	}
	public void setAddrOfInst(String addrOfInst) {
		this.addrOfInst = addrOfInst;
	}
	public String getSpousework() {
		return spousework;
	}
	public void setSpousework(String spousework) {
		this.spousework = spousework;
	}
	public String getPcpName() {
		return pcpName;
	}
	public void setPcpName(String pcpName) {
		this.pcpName = pcpName;
	}
	public String getPcpMedicalGroupName() {
		return pcpMedicalGroupName;
	}
	public void setPcpMedicalGroupName(String pcpMedicalGroupName) {
		this.pcpMedicalGroupName = pcpMedicalGroupName;
	}
	public String getExistingp() {
		return existingp;
	}
	public void setExistingp(String existingp) {
		this.existingp = existingp;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getLanguageValue() {
		return languageValue;
	}
	public void setLanguageValue(String languageValue) {
		this.languageValue = languageValue;
	}
	public String getAep() {
		return aep;
	}
	public void setAep(String aep) {
		this.aep = aep;
	}
	public String getC1() {
		return c1;
	}
	public void setC1(String c1) {
		this.c1 = c1;
	}
	public String getC2() {
		return c2;
	}
	public void setC2(String c2) {
		this.c2 = c2;
	}
	public String getC3() {
		return c3;
	}
	public void setC3(String c3) {
		this.c3 = c3;
	}
	public String getC4() {
		return c4;
	}
	public void setC4(String c4) {
		this.c4 = c4;
	}
	public String getC5() {
		return c5;
	}
	public void setC5(String c5) {
		this.c5 = c5;
	}
	public String getC6() {
		return c6;
	}
	public void setC6(String c6) {
		this.c6 = c6;
	}
	public String getC7() {
		return c7;
	}
	public void setC7(String c7) {
		this.c7 = c7;
	}
	public String getC8() {
		return c8;
	}
	public void setC8(String c8) {
		this.c8 = c8;
	}
	public String getC9() {
		return c9;
	}
	public void setC9(String c9) {
		this.c9 = c9;
	}
	public String getC10() {
		return c10;
	}
	public void setC10(String c10) {
		this.c10 = c10;
	}
	public String getC11() {
		return c11;
	}
	public void setC11(String c11) {
		this.c11 = c11;
	}
	public String getC12() {
		return c12;
	}
	public void setC12(String c12) {
		this.c12 = c12;
	}
	public String getC13() {
		return c13;
	}
	public void setC13(String c13) {
		this.c13 = c13;
	}
	public String getC14() {
		return c14;
	}
	public void setC14(String c14) {
		this.c14 = c14;
	}
	public String getC15() {
		return c15;
	}
	public void setC15(String c15) {
		this.c15 = c15;
	}
	public String getC16() {
		return c16;
	}
	public void setC16(String c16) {
		this.c16 = c16;
	}
	public String getC16Attestation() {
		return c16Attestation;
	}
	public void setC16Attestation(String c16Attestation) {
		this.c16Attestation = c16Attestation;
	}
	public String getCoveragebegin() {
		return coveragebegin;
	}
	public void setCoveragebegin(String coveragebegin) {
		this.coveragebegin = coveragebegin;
	}
	public String getNameSignature() {
		return nameSignature;
	}
	public void setNameSignature(String nameSignature) {
		this.nameSignature = nameSignature;
	}
	public String getDigitalSignature() {
		return digitalSignature;
	}
	public void setDigitalSignature(String digitalSignature) {
		this.digitalSignature = digitalSignature;
	}
	public String getTodaysDate() {
		return todaysDate;
	}
	public void setTodaysDate(String todaysDate) {
		this.todaysDate = todaysDate;
	}
	public String getAuthorizedRep() {
		return AuthorizedRep;
	}
	public void setAuthorizedRep(String authorizedRep) {
		AuthorizedRep = authorizedRep;
	}
	public String getAuthorizedrepname() {
		return authorizedrepname;
	}
	public void setAuthorizedrepname(String authorizedrepname) {
		this.authorizedrepname = authorizedrepname;
	}
	public String getAuthorizedreprelationship() {
		return authorizedreprelationship;
	}
	public void setAuthorizedreprelationship(String authorizedreprelationship) {
		this.authorizedreprelationship = authorizedreprelationship;
	}
	public String getAuthorizedrepaddress() {
		return authorizedrepaddress;
	}
	public void setAuthorizedrepaddress(String authorizedrepaddress) {
		this.authorizedrepaddress = authorizedrepaddress;
	}
	public String getAuthorizedrepphone() {
		return authorizedrepphone;
	}
	public void setAuthorizedrepphone(String authorizedrepphone) {
		this.authorizedrepphone = authorizedrepphone;
	}
	public String getAgentAssistingEnrollment() {
		return AgentAssistingEnrollment;
	}
	public void setAgentAssistingEnrollment(String agentAssistingEnrollment) {
		AgentAssistingEnrollment = agentAssistingEnrollment;
	}
	public String getNameAgent() {
		return nameAgent;
	}
	public void setNameAgent(String nameAgent) {
		this.nameAgent = nameAgent;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getPbpId() {
		return pbpId;
	}
	public void setPbpId(String pbpId) {
		this.pbpId = pbpId;
	}
	public String getElectionType() {
		return electionType;
	}
	public void setElectionType(String electionType) {
		this.electionType = electionType;
	}
	public String getAttestation2() {
		return attestation2;
	}
	public void setAttestation2(String attestation2) {
		this.attestation2 = attestation2;
	}
	public String getAttestation3() {
		return attestation3;
	}
	public void setAttestation3(String attestation3) {
		this.attestation3 = attestation3;
	}
	public String getAttestation4() {
		return attestation4;
	}
	public void setAttestation4(String attestation4) {
		this.attestation4 = attestation4;
	}
	public String getAttestation5() {
		return attestation5;
	}
	public void setAttestation5(String attestation5) {
		this.attestation5 = attestation5;
	}
	public String getAttestation8() {
		return attestation8;
	}
	public void setAttestation8(String attestation8) {
		this.attestation8 = attestation8;
	}
	public String getAttestation9() {
		return attestation9;
	}
	public void setAttestation9(String attestation9) {
		this.attestation9 = attestation9;
	}
	public String getAttestation10() {
		return attestation10;
	}
	public void setAttestation10(String attestation10) {
		this.attestation10 = attestation10;
	}
	public String getAttestation11() {
		return attestation11;
	}
	public void setAttestation11(String attestation11) {
		this.attestation11 = attestation11;
	}
	public String getAttestation12() {
		return attestation12;
	}
	public void setAttestation12(String attestation12) {
		this.attestation12 = attestation12;
	}
	public String getAttestation15() {
		return attestation15;
	}
	public void setAttestation15(String attestation15) {
		this.attestation15 = attestation15;
	}
	public String getAttestation16() {
		return attestation16;
	}
	public void setAttestation16(String attestation16) {
		this.attestation16 = attestation16;
	}
	public String getEmailAlert() {
		return emailAlert;
	}
	public void setEmailAlert(String emailAlert) {
		this.emailAlert = emailAlert;
	}
	public String getCallAlert() {
		return callAlert;
	}
	public void setCallAlert(String callAlert) {
		this.callAlert = callAlert;
	}
	public String getRetiree() {
		return retiree;
	}
	public void setRetiree(String retiree) {
		this.retiree = retiree;
	}
	public String getRetiredate() {
		return retiredate;
	}
	public void setRetiredate(String retiredate) {
		this.retiredate = retiredate;
	}
	public String getRetirename() {
		return retirename;
	}
	public void setRetirename(String retirename) {
		this.retirename = retirename;
	}
	public String getMeddependsp() {
		return meddependsp;
	}
	public void setMeddependsp(String meddependsp) {
		this.meddependsp = meddependsp;
	}
	public String getDependentSpouse() {
		return dependentSpouse;
	}
	public void setDependentSpouse(String dependentSpouse) {
		this.dependentSpouse = dependentSpouse;
	}
	public String getDependentOther() {
		return dependentOther;
	}
	public void setDependentOther(String dependentOther) {
		this.dependentOther = dependentOther;
	}
	public String getHlthcovType() {
		return hlthcovType;
	}
	public void setHlthcovType(String hlthcovType) {
		this.hlthcovType = hlthcovType;
	}
	public String getHlthcovInscomp() {
		return hlthcovInscomp;
	}
	public void setHlthcovInscomp(String hlthcovInscomp) {
		this.hlthcovInscomp = hlthcovInscomp;
	}
	public String getC20() {
		return c20;
	}
	public void setC20(String c20) {
		this.c20 = c20;
	}
	public String getAgentLicense() {
		return agentLicense;
	}
	public void setAgentLicense(String agentLicense) {
		this.agentLicense = agentLicense;
	}
	/**IFOX-00403984 Changes Start.*/
	/**
	 * @return the effDate
	 */
	public String getEffDate() {
		return effDate;
	}
	/**
	 * @param effDate the effDate to set
	 */
	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}
	/**IFOX-00403984 Changes Stop.*/
}