package com.medicare.vo;

public class AttestationDetailsVO {
	// for 2015 application

	private String preferBraille;
	private String preferlargePrint;

	public String getPreferBraille() {
		return preferBraille;
	}

	public void setPreferBraille(String preferBraille) {
		this.preferBraille = preferBraille;
	}

	public String getPreferlargePrint() {
		return preferlargePrint;
	}

	public void setPreferlargePrint(String preferlargePrint) {
		this.preferlargePrint = preferlargePrint;
	}

	//New fields Added for SumaCare-START
   
	private String eligibleEnroll;
	private String newMedicare;
	private String priorMedicare;
	private String recntMovChBox;
	private String terminated;
	private String incarcerationInd;
	private String mcNumChBox;
	private String revMedChBox;
	private String nlElgPrescChBox;
	private String lngcareFacility;
	private String currentLngcare;
	private String outLngTermFcSeeChBox;
	private String recntleftPlChBox;
	private String trcntCreditChBox;
	private String levEmpChBox;
	private String belongStatePharmacy;
	private String priorplanUnavailable;
	private String planEndingContract;
	private String mvdUsChBox;
	private String madp;
	private String noElgbspseChBox;
	private String recentMovedOption;
	private String terminationDate;
	private String incarceration;
	private String noEligbPrescDrugs;
	private String lngcareFacilityDate;
	private String noEligSpecial;
	private String outLongTermFacility;
	private String recntLeftPace;
	private String priorplanUnavailableDate;
	private String leavingEmployerCoverage;
	private String recentlyCreditable;
	private String movedBackUs;
	
	
	//Begin: 2019 web app changes - IFOX-00406768

	private String medicareAdvantagePlanChange; //c21
	private String changeInMedicaid; //c22
	private String changeInExtraHelp; //c23
	private String chooseDifferentMedicarePlan; //c24
	private String affectedByMajorDisaster; //c25

	private String attestation22;
	private String attestation23;
	private String attestation24;
	
	public String getMedicareAdvantagePlanChange() {
		return medicareAdvantagePlanChange;
	}

	public void setMedicareAdvantagePlanChange(String medicareAdvantagePlanChange) {
		this.medicareAdvantagePlanChange = medicareAdvantagePlanChange;
	}

	public String getChangeInMedicaid() {
		return changeInMedicaid;
	}

	public void setChangeInMedicaid(String changeInMedicaid) {
		this.changeInMedicaid = changeInMedicaid;
	}

	public String getChangeInExtraHelp() {
		return changeInExtraHelp;
	}

	public void setChangeInExtraHelp(String changeInExtraHelp) {
		this.changeInExtraHelp = changeInExtraHelp;
	}

	public String getChooseDifferentMedicarePlan() {
		return chooseDifferentMedicarePlan;
	}

	public void setChooseDifferentMedicarePlan(String chooseDifferentMedicarePlan) {
		this.chooseDifferentMedicarePlan = chooseDifferentMedicarePlan;
	}

	public String getAffectedByMajorDisaster() {
		return affectedByMajorDisaster;
	}

	public void setAffectedByMajorDisaster(String affectedByMajorDisaster) {
		this.affectedByMajorDisaster = affectedByMajorDisaster;
	}
	
	public String getAttestation22() {
		return attestation22;
	}

	public void setAttestation22(String attestation22) {
		this.attestation22 = attestation22;
	}

	public String getAttestation23() {
		return attestation23;
	}

	public void setAttestation23(String attestation23) {
		this.attestation23 = attestation23;
	}

	public String getAttestation24() {
		return attestation24;
	}

	public void setAttestation24(String attestation24) {
		this.attestation24 = attestation24;
	}
	
	//End: 2019 web app changes - IFOX-00406768
	
	
	/**
	 * @return the eligibleEnroll
	 */
	public String getEligibleEnroll() {
		return eligibleEnroll;
	}

	/**
	 * @param eligibleEnroll the eligibleEnroll to set
	 */
	public void setEligibleEnroll(String eligibleEnroll) {
		this.eligibleEnroll = eligibleEnroll;
	}

	/**
	 * @return the newMedicare
	 */
	public String getNewMedicare() {
		return newMedicare;
	}

	/**
	 * @param newMedicare the newMedicare to set
	 */
	public void setNewMedicare(String newMedicare) {
		this.newMedicare = newMedicare;
	}

	/**
	 * @return the priorMedicare
	 */
	public String getPriorMedicare() {
		return priorMedicare;
	}

	/**
	 * @param priorMedicare the priorMedicare to set
	 */
	public void setPriorMedicare(String priorMedicare) {
		this.priorMedicare = priorMedicare;
	}

	/**
	 * @return the recntMovChBox
	 */
	public String getRecntMovChBox() {
		return recntMovChBox;
	}

	/**
	 * @param recntMovChBox the recntMovChBox to set
	 */
	public void setRecntMovChBox(String recntMovChBox) {
		this.recntMovChBox = recntMovChBox;
	}

	/**
	 * @return the terminated
	 */
	public String getTerminated() {
		return terminated;
	}

	/**
	 * @param terminated the terminated to set
	 */
	public void setTerminated(String terminated) {
		this.terminated = terminated;
	}

	/**
	 * @return the incarcerationInd
	 */
	public String getIncarcerationInd() {
		return incarcerationInd;
	}

	/**
	 * @param incarcerationInd the incarcerationInd to set
	 */
	public void setIncarcerationInd(String incarcerationInd) {
		this.incarcerationInd = incarcerationInd;
	}

	/**
	 * @return the mcNumChBox
	 */
	public String getMcNumChBox() {
		return mcNumChBox;
	}

	/**
	 * @param mcNumChBox the mcNumChBox to set
	 */
	public void setMcNumChBox(String mcNumChBox) {
		this.mcNumChBox = mcNumChBox;
	}

	/**
	 * @return the revMedChBox
	 */
	public String getRevMedChBox() {
		return revMedChBox;
	}

	/**
	 * @param revMedChBox the revMedChBox to set
	 */
	public void setRevMedChBox(String revMedChBox) {
		this.revMedChBox = revMedChBox;
	}

	/**
	 * @return the nlElgPrescChBox
	 */
	public String getNlElgPrescChBox() {
		return nlElgPrescChBox;
	}

	/**
	 * @param nlElgPrescChBox the nlElgPrescChBox to set
	 */
	public void setNlElgPrescChBox(String nlElgPrescChBox) {
		this.nlElgPrescChBox = nlElgPrescChBox;
	}

	/**
	 * @return the lngcareFacility
	 */
	public String getLngcareFacility() {
		return lngcareFacility;
	}

	/**
	 * @param lngcareFacility the lngcareFacility to set
	 */
	public void setLngcareFacility(String lngcareFacility) {
		this.lngcareFacility = lngcareFacility;
	}

	/**
	 * @return the currentLngcare
	 */
	public String getCurrentLngcare() {
		return currentLngcare;
	}

	/**
	 * @param currentLngcare the currentLngcare to set
	 */
	public void setCurrentLngcare(String currentLngcare) {
		this.currentLngcare = currentLngcare;
	}

	/**
	 * @return the outLngTermFcSeeChBox
	 */
	public String getOutLngTermFcSeeChBox() {
		return outLngTermFcSeeChBox;
	}

	/**
	 * @param outLngTermFcSeeChBox the outLngTermFcSeeChBox to set
	 */
	public void setOutLngTermFcSeeChBox(String outLngTermFcSeeChBox) {
		this.outLngTermFcSeeChBox = outLngTermFcSeeChBox;
	}

	/**
	 * @return the recntleftPlChBox
	 */
	public String getRecntleftPlChBox() {
		return recntleftPlChBox;
	}

	/**
	 * @param recntleftPlChBox the recntleftPlChBox to set
	 */
	public void setRecntleftPlChBox(String recntleftPlChBox) {
		this.recntleftPlChBox = recntleftPlChBox;
	}

	/**
	 * @return the trcntCreditChBox
	 */
	public String getTrcntCreditChBox() {
		return trcntCreditChBox;
	}

	/**
	 * @param trcntCreditChBox the trcntCreditChBox to set
	 */
	public void setTrcntCreditChBox(String trcntCreditChBox) {
		this.trcntCreditChBox = trcntCreditChBox;
	}

	/**
	 * @return the levEmpChBox
	 */
	public String getLevEmpChBox() {
		return levEmpChBox;
	}

	/**
	 * @param levEmpChBox the levEmpChBox to set
	 */
	public void setLevEmpChBox(String levEmpChBox) {
		this.levEmpChBox = levEmpChBox;
	}

	/**
	 * @return the belongStatePharmacy
	 */
	public String getBelongStatePharmacy() {
		return belongStatePharmacy;
	}

	/**
	 * @param belongStatePharmacy the belongStatePharmacy to set
	 */
	public void setBelongStatePharmacy(String belongStatePharmacy) {
		this.belongStatePharmacy = belongStatePharmacy;
	}

	/**
	 * @return the priorplanUnavailable
	 */
	public String getPriorplanUnavailable() {
		return priorplanUnavailable;
	}

	/**
	 * @param priorplanUnavailable the priorplanUnavailable to set
	 */
	public void setPriorplanUnavailable(String priorplanUnavailable) {
		this.priorplanUnavailable = priorplanUnavailable;
	}

	/**
	 * @return the planEndingContract
	 */
	public String getPlanEndingContract() {
		return planEndingContract;
	}

	/**
	 * @param planEndingContract the planEndingContract to set
	 */
	public void setPlanEndingContract(String planEndingContract) {
		this.planEndingContract = planEndingContract;
	}

	/**
	 * @return the mvdUsChBox
	 */
	public String getMvdUsChBox() {
		return mvdUsChBox;
	}

	/**
	 * @param mvdUsChBox the mvdUsChBox to set
	 */
	public void setMvdUsChBox(String mvdUsChBox) {
		this.mvdUsChBox = mvdUsChBox;
	}

	/**
	 * @return the madp
	 */
	public String getMadp() {
		return madp;
	}

	/**
	 * @param madp the madp to set
	 */
	public void setMadp(String madp) {
		this.madp = madp;
	}

	/**
	 * @return the noElgbspseChBox
	 */
	public String getNoElgbspseChBox() {
		return noElgbspseChBox;
	}

	/**
	 * @param noElgbspseChBox the noElgbspseChBox to set
	 */
	public void setNoElgbspseChBox(String noElgbspseChBox) {
		this.noElgbspseChBox = noElgbspseChBox;
	}

	/**
	 * @return the recentMovedOption
	 */
	public String getRecentMovedOption() {
		return recentMovedOption;
	}

	/**
	 * @param recentMovedOption the recentMovedOption to set
	 */
	public void setRecentMovedOption(String recentMovedOption) {
		this.recentMovedOption = recentMovedOption;
	}

	/**
	 * @return the terminationDate
	 */
	public String getTerminationDate() {
		return terminationDate;
	}

	/**
	 * @param terminationDate the terminationDate to set
	 */
	public void setTerminationDate(String terminationDate) {
		this.terminationDate = terminationDate;
	}

	/**
	 * @return the incarceration
	 */
	public String getIncarceration() {
		return incarceration;
	}

	/**
	 * @param incarceration the incarceration to set
	 */
	public void setIncarceration(String incarceration) {
		this.incarceration = incarceration;
	}

	/**
	 * @return the noEligbPrescDrugs
	 */
	public String getNoEligbPrescDrugs() {
		return noEligbPrescDrugs;
	}

	/**
	 * @param noEligbPrescDrugs the noEligbPrescDrugs to set
	 */
	public void setNoEligbPrescDrugs(String noEligbPrescDrugs) {
		this.noEligbPrescDrugs = noEligbPrescDrugs;
	}

	/**
	 * @return the lngcareFacilityDate
	 */
	public String getLngcareFacilityDate() {
		return lngcareFacilityDate;
	}

	/**
	 * @param lngcareFacilityDate the lngcareFacilityDate to set
	 */
	public void setLngcareFacilityDate(String lngcareFacilityDate) {
		this.lngcareFacilityDate = lngcareFacilityDate;
	}

	/**
	 * @return the noEligSpecial
	 */
	public String getNoEligSpecial() {
		return noEligSpecial;
	}

	/**
	 * @param noEligSpecial the noEligSpecial to set
	 */
	public void setNoEligSpecial(String noEligSpecial) {
		this.noEligSpecial = noEligSpecial;
	}

	/**
	 * @return the outLongTermFacility
	 */
	public String getOutLongTermFacility() {
		return outLongTermFacility;
	}

	/**
	 * @param outLongTermFacility the outLongTermFacility to set
	 */
	public void setOutLongTermFacility(String outLongTermFacility) {
		this.outLongTermFacility = outLongTermFacility;
	}

	/**
	 * @return the recntLeftPace
	 */
	public String getRecntLeftPace() {
		return recntLeftPace;
	}

	/**
	 * @param recntLeftPace the recntLeftPace to set
	 */
	public void setRecntLeftPace(String recntLeftPace) {
		this.recntLeftPace = recntLeftPace;
	}

	/**
	 * @return the priorplanUnavailableDate
	 */
	public String getPriorplanUnavailableDate() {
		return priorplanUnavailableDate;
	}

	/**
	 * @param priorplanUnavailableDate the priorplanUnavailableDate to set
	 */
	public void setPriorplanUnavailableDate(String priorplanUnavailableDate) {
		this.priorplanUnavailableDate = priorplanUnavailableDate;
	}

	/**
	 * @return the leavingEmployerCoverage
	 */
	public String getLeavingEmployerCoverage() {
		return leavingEmployerCoverage;
	}

	/**
	 * @param leavingEmployerCoverage the leavingEmployerCoverage to set
	 */
	public void setLeavingEmployerCoverage(String leavingEmployerCoverage) {
		this.leavingEmployerCoverage = leavingEmployerCoverage;
	}

	/**
	 * @return the recentlyCreditable
	 */
	public String getRecentlyCreditable() {
		return recentlyCreditable;
	}

	/**
	 * @param recentlyCreditable the recentlyCreditable to set
	 */
	public void setRecentlyCreditable(String recentlyCreditable) {
		this.recentlyCreditable = recentlyCreditable;
	}

	/**
	 * @return the movedBackUs
	 */
	public String getMovedBackUs() {
		return movedBackUs;
	}

	/**
	 * @param movedBackUs the movedBackUs to set
	 */
	public void setMovedBackUs(String movedBackUs) {
		this.movedBackUs = movedBackUs;
	}
	//New fields Added for SumaCare-END
	
	//New fields Added for Sharp-START
	private String lawFullChkBox;
	private String lawFullChckBoxDate;

	public String getLawFullChkBox() {
		return lawFullChkBox;
	}

	public void setLawFullChkBox(String lawFullChkBox) {
		this.lawFullChkBox = lawFullChkBox;
	}

	public String getLawFullChckBoxDate() {
		return lawFullChckBoxDate;
	}

	public void setLawFullChckBoxDate(String lawFullChckBoxDate) {
		this.lawFullChckBoxDate = lawFullChckBoxDate;
	}
	
	//New fields Added for Sharp-END
}
