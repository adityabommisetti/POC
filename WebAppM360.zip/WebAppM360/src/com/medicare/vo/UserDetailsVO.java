package com.medicare.vo;

//import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

//import org.hibernate.annotations.ColumnTransformer;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
//import org.springframework.format.annotation.DateTimeFormat;

public class UserDetailsVO {

	// for 2015 application

	@NotEmpty
	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String effDate;

	private String campaignId;

	private String customerId;

	
	//Begin: 2019 web app changes - IFOX-00406768
	private String planYear;
	private String webappConfirmationNumber;
	
	public String getPlanYear() {
		return planYear;
	}
	public void setPlanYear(String planYear) {
		this.planYear = planYear;
	}
	public String getWebappConfirmationNumber() {
		return webappConfirmationNumber;
	}
	public void setWebappConfirmationNumber(String webappConfirmationNumber) {
		this.webappConfirmationNumber = webappConfirmationNumber;
	}
	//End: 2019 web app changes - IFOX-00406768

	
	public String getCampaignId() {
		return campaignId;
	}

	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getContractId() {
		return contractId;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	private String contractId;

	public String getEffDate() {
		return effDate;
	}

	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}

	public String getErroreffDateValue() {
		return erroreffDateValue;
	}

	public void setErroreffDateValue(String erroreffDateValue) {
		this.erroreffDateValue = erroreffDateValue;
	}


	//Begin: Added for IFOX-00390786 (Phase-II)
	private String errorpermanentAptValue;
	private String errorbeneficiarySexValue;
	private String errorpermanentStrtValue;
	private String errorrenalDiseaseValue;
	private String errorstateMedicaidValue;
	private String errormedicaidNumberValue;
	//End: Added for IFOX-00390786 (Phase-II)
	
	//Begin: Making MedicaidId Field as Non Mandatory for DSNP plans
	private String strPlanId;
	//End: Making MedicaidId Field as Non Mandatory for DSNP plans
	
	
	private String erroreffDateValue;
	

	// end 2015 application

	public String getErrorpermanentAptValue() {
		return errorpermanentAptValue;
	}

	public void setErrorpermanentAptValue(String errorpermanentAptValue) {
		this.errorpermanentAptValue = errorpermanentAptValue;
	}

	public String getErrorbeneficiarySexValue() {
		return errorbeneficiarySexValue;
	}

	public void setErrorbeneficiarySexValue(String errorbeneficiarySexValue) {
		this.errorbeneficiarySexValue = errorbeneficiarySexValue;
	}

	public String getErrorpermanentStrtValue() {
		return errorpermanentStrtValue;
	}

	public void setErrorpermanentStrtValue(String errorpermanentStrtValue) {
		this.errorpermanentStrtValue = errorpermanentStrtValue;
	}

	public String getErrorrenalDiseaseValue() {
		return errorrenalDiseaseValue;
	}

	public void setErrorrenalDiseaseValue(String errorrenalDiseaseValue) {
		this.errorrenalDiseaseValue = errorrenalDiseaseValue;
	}

	public String getErrorstateMedicaidValue() {
		return errorstateMedicaidValue;
	}

	public void setErrorstateMedicaidValue(String errorstateMedicaidValue) {
		this.errorstateMedicaidValue = errorstateMedicaidValue;
	}

	public String getErrormedicaidNumberValue() {
		return errormedicaidNumberValue;
	}

	public void setErrormedicaidNumberValue(String errormedicaidNumberValue) {
		this.errormedicaidNumberValue = errormedicaidNumberValue;
	}

	private String errorfirstNameValue;
	private String errormiddleInitialValue;
	private String errorbirthDateValue;
	private String erroraltrPhNumberValue;
	private String erroremailAddrValue;
	private String errormailingZipValue;
	private String erroremergencyContValue;
	private String erroremergPhNumValue;
	private String errorpermanentAddrValue;
	private String errorpermanentCityValue;
	private String errorpermanentStateValue;
	private String errorpermanentZipValue;
	private String errornameBeneficiaryValue;
	private String errorMediacrdNumberValue;
	private String errorhospitalDateValue;
	private String errormedicalDateValue;
	private String errorpermCityStateValue;
	private String errormailingCityStateValue;

	public String getErrorhomePhNumberValue() {
		return errorhomePhNumberValue;
	}

	public void setErrorhomePhNumberValue(String errorhomePhNumberValue) {
		this.errorhomePhNumberValue = errorhomePhNumberValue;
	}

	private String errorhomePhNumberValue;

	private String errorlastNameValue;

	public String getErrorlastNameValue() {
		return errorlastNameValue;
	}

	public void setErrorlastNameValue(String errorlastNameValue) {
		this.errorlastNameValue = errorlastNameValue;
	}

	private String pdfBlob;

	private String permCityState;

	private String mailingCityState;

	private int userId;

	private String optimaMedicare;

	@NotEmpty
	@Pattern(regexp = "^[a-zA-Z]*$") //Modified for IFOX-00390786 (Phase-II)
	private String lastName;

	@NotEmpty
	@Pattern(regexp = "^[a-zA-Z]*$") //Modified for IFOX-00390786 (Phase-II)
	private String firstName;

	//@NotEmpty //Modified for IFOX-00390786 (Phase-II)
	@Pattern(regexp = "^[a-zA-Z]*$")
	private String middleInitial;

	private String suffix;

	@NotEmpty
	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String birthDate;

	@NotEmpty
	private String sex;

	//@NotEmpty //Commented for IFOX-00390786 (Phase-II)
	@Pattern(regexp = "^[[0-9]{3}-[0-9]{3}-[0-9]{4}]*$")
	private String homePhNumber;

	@Pattern(regexp = "^[[0-9]{3}-[0-9]{3}-[0-9]{4}]*$")
	private String altrPhNumber;

	@Email
	private String emailAddr;

	@NotEmpty
	private String permanentAddr;

	//@NotEmpty //Added for IFOX-00390786 (Phase-II)
	private String permanentStrt;

	//Added for IFOX-00390786 (Phase-II)
	//@NotEmpty
	private String permanentApt;

	@NotEmpty
	private String permanentCity;

	@NotEmpty
	private String permanentState;

	@NotEmpty
	@Pattern(regexp = "^[0-9 ]*$")
	private String permanentZip;

	private String mailingAddr;

	private String mailingStrt;

	private String mailingApt;

	private String mailingCity;

	private String mailingState;

	@Pattern(regexp = "^[0-9 ]*$")
	private String mailingZip;

	private String emergencyCont;

	private String relationYou;

	@Pattern(regexp = "^[[0-9]{3}-[0-9]{3}-[0-9]{4}]*$")
	private String emergPhNum;
	
	//@NotEmpty //Commented for IFOX-00390786 (Phase-II)
	private String physician;
	
	private String physicianName;

	@NotEmpty
	private String nameBeneficiary;

	@NotEmpty
	@Pattern(regexp = "^[a-zA-Z0-9]*$")
	private String mediacrdNumber;

	@NotEmpty
	private String beneficiarySex;

	//@NotEmpty //Commented for IFOX-00390786 (Phase-II)
	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String hospitalDate;

	//@NotEmpty //Commented for IFOX-00390786 (Phase-II)
	@Pattern(regexp = "^(((0?[1-9]|1[012])[/](0?[1-9]|1\\d|2[0-8])|(0?[13456789]|1[012])[/](29|30)|(0?[13578]|1[02])[/]31)[/](19|[2-9]\\d)\\d{2}|0?2[/]29[/]((19|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00)))*$")
	private String medicalDate;

	
	//Begin: 2019 web app changes - IFOX-00406768
	private String newPhysicianName;
	private String newAgentName;

	public String getNewPhysicianName() {
		return newPhysicianName;
	}
	public void setNewPhysicianName(String newPhysicianName) {
		this.newPhysicianName = newPhysicianName;
	}
	public String getNewAgentName() {
		return newAgentName;
	}
	public void setNewAgentName(String newAgentName) {
		this.newAgentName = newAgentName;
	}
	//End: 2019 web app changes - IFOX-00406768
	
	
	public String getOptimaMedicare() {
		return optimaMedicare;
	}

	public void setOptimaMedicare(String optimaMedicare) {
		this.optimaMedicare = optimaMedicare;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleInitial() {
		return middleInitial;
	}

	public void setMiddleInitial(String middleInitial) {
		this.middleInitial = middleInitial;
	}

	public String getSuffix() {
		return suffix;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getHomePhNumber() {
		return homePhNumber;
	}

	public void setHomePhNumber(String homePhNumber) {
		this.homePhNumber = homePhNumber;
	}

	public String getAltrPhNumber() {
		return altrPhNumber;
	}

	public void setAltrPhNumber(String altrPhNumber) {
		this.altrPhNumber = altrPhNumber;
	}

	public String getEmailAddr() {
		return emailAddr;
	}

	public void setEmailAddr(String emailAddr) {
		this.emailAddr = emailAddr;
	}

	public String getPermanentAddr() {
		return permanentAddr;
	}

	public void setPermanentAddr(String permanentAddr) {
		this.permanentAddr = permanentAddr;
	}

	public String getPermanentApt() {
		return permanentApt;
	}

	public void setPermanentApt(String permanentApt) {
		this.permanentApt = permanentApt;
	}

	public String getPermanentCity() {
		return permanentCity;
	}

	public void setPermanentCity(String permanentCity) {
		this.permanentCity = permanentCity;
	}

	public String getPermanentState() {
		return permanentState;
	}

	public void setPermanentState(String permanentState) {
		this.permanentState = permanentState;
	}

	public String getPermanentZip() {
		return permanentZip;
	}

	public void setPermanentZip(String permanentZip) {
		this.permanentZip = permanentZip;
	}

	public String getMailingAddr() {
		return mailingAddr;
	}

	public void setMailingAddr(String mailingAddr) {
		this.mailingAddr = mailingAddr;
	}

	public String getMailingApt() {
		return mailingApt;
	}

	public void setMailingApt(String mailingApt) {
		this.mailingApt = mailingApt;
	}

	public String getMailingCity() {
		return mailingCity;
	}

	public void setMailingCity(String mailingCity) {
		this.mailingCity = mailingCity;
	}

	public String getMailingState() {
		return mailingState;
	}

	public void setMailingState(String mailingState) {
		this.mailingState = mailingState;
	}

	public String getMailingZip() {
		return mailingZip;
	}

	public void setMailingZip(String mailingZip) {
		this.mailingZip = mailingZip;
	}

	public String getEmergencyCont() {
		return emergencyCont;
	}

	public void setEmergencyCont(String emergencyCont) {
		this.emergencyCont = emergencyCont;
	}

	public String getRelationYou() {
		return relationYou;
	}

	public void setRelationYou(String relationYou) {
		this.relationYou = relationYou;
	}

	public String getEmergPhNum() {
		return emergPhNum;
	}

	public void setEmergPhNum(String emergPhNum) {
		this.emergPhNum = emergPhNum;
	}

	public String getNameBeneficiary() {
		return nameBeneficiary;
	}

	public void setNameBeneficiary(String nameBeneficiary) {
		this.nameBeneficiary = nameBeneficiary;
	}

	public String getMediacrdNumber() {
		return mediacrdNumber;
	}

	public void setMediacrdNumber(String mediacrdNumber) {
		this.mediacrdNumber = mediacrdNumber;
	}

	public String getBeneficiarySex() {
		return beneficiarySex;
	}

	public void setBeneficiarySex(String beneficiarySex) {
		this.beneficiarySex = beneficiarySex;
	}

	public String getHospitalDate() {
		return hospitalDate;
	}

	public void setHospitalDate(String hospitalDate) {
		this.hospitalDate = hospitalDate;
	}

	public String getMedicalDate() {
		return medicalDate;
	}

	public void setMedicalDate(String medicalDate) {
		this.medicalDate = medicalDate;
	}

	public String getPermanentStrt() {
		return permanentStrt;
	}

	public void setPermanentStrt(String permanentStrt) {
		this.permanentStrt = permanentStrt;
	}

	public String getMailingStrt() {
		return mailingStrt;
	}

	public void setMailingStrt(String mailingStrt) {
		this.mailingStrt = mailingStrt;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getPermCityState() {
		return permCityState;
	}

	public void setPermCityState(String permCityState) {
		this.permCityState = permCityState;
	}

	public String getMailingCityState() {
		return mailingCityState;
	}

	public void setMailingCityState(String mailingCityState) {
		this.mailingCityState = mailingCityState;
	}

	public String getPdfBlob() {
		return pdfBlob;
	}

	public void setPdfBlob(String pdfBlob) {
		this.pdfBlob = pdfBlob;
	}

	public String getErrorfirstNameValue() {
		return errorfirstNameValue;
	}

	public void setErrorfirstNameValue(String errorfirstNameValue) {
		this.errorfirstNameValue = errorfirstNameValue;
	}

	public String getErrormiddleInitialValue() {
		return errormiddleInitialValue;
	}

	public void setErrormiddleInitialValue(String errormiddleInitialValue) {
		this.errormiddleInitialValue = errormiddleInitialValue;
	}

	public String getErrorbirthDateValue() {
		return errorbirthDateValue;
	}

	public void setErrorbirthDateValue(String errorbirthDateValue) {
		this.errorbirthDateValue = errorbirthDateValue;
	}

	public String getErroraltrPhNumberValue() {
		return erroraltrPhNumberValue;
	}

	public void setErroraltrPhNumberValue(String erroraltrPhNumberValue) {
		this.erroraltrPhNumberValue = erroraltrPhNumberValue;
	}

	public String getErroremailAddrValue() {
		return erroremailAddrValue;
	}

	public void setErroremailAddrValue(String erroremailAddrValue) {
		this.erroremailAddrValue = erroremailAddrValue;
	}

	public String getErrormailingZipValue() {
		return errormailingZipValue;
	}

	public void setErrormailingZipValue(String errormailingZipValue) {
		this.errormailingZipValue = errormailingZipValue;
	}

	public String getErroremergencyContValue() {
		return erroremergencyContValue;
	}

	public void setErroremergencyContValue(String erroremergencyContValue) {
		this.erroremergencyContValue = erroremergencyContValue;
	}

	public String getErroremergPhNumValue() {
		return erroremergPhNumValue;
	}

	public void setErroremergPhNumValue(String erroremergPhNumValue) {
		this.erroremergPhNumValue = erroremergPhNumValue;
	}

	public String getErrorpermanentAddrValue() {
		return errorpermanentAddrValue;
	}

	public void setErrorpermanentAddrValue(String errorpermanentAddrValue) {
		this.errorpermanentAddrValue = errorpermanentAddrValue;
	}

	public String getErrorpermanentCityValue() {
		return errorpermanentCityValue;
	}

	public void setErrorpermanentCityValue(String errorpermanentCityValue) {
		this.errorpermanentCityValue = errorpermanentCityValue;
	}

	public String getErrorpermanentStateValue() {
		return errorpermanentStateValue;
	}

	public void setErrorpermanentStateValue(String errorpermanentStateValue) {
		this.errorpermanentStateValue = errorpermanentStateValue;
	}

	public String getErrorpermanentZipValue() {
		return errorpermanentZipValue;
	}

	public void setErrorpermanentZipValue(String errorpermanentZipValue) {
		this.errorpermanentZipValue = errorpermanentZipValue;
	}

	public String getErrornameBeneficiaryValue() {
		return errornameBeneficiaryValue;
	}

	public void setErrornameBeneficiaryValue(String errornameBeneficiaryValue) {
		this.errornameBeneficiaryValue = errornameBeneficiaryValue;
	}

	public String getErrorMediacrdNumberValue() {
		return errorMediacrdNumberValue;
	}

	public void setErrorMediacrdNumberValue(String errorMediacrdNumberValue) {
		this.errorMediacrdNumberValue = errorMediacrdNumberValue;
	}

	public String getErrorhospitalDateValue() {
		return errorhospitalDateValue;
	}

	public void setErrorhospitalDateValue(String errorhospitalDateValue) {
		this.errorhospitalDateValue = errorhospitalDateValue;
	}

	public String getErrormedicalDateValue() {
		return errormedicalDateValue;
	}

	public void setErrormedicalDateValue(String errormedicalDateValue) {
		this.errormedicalDateValue = errormedicalDateValue;
	}

	public String getErrorpermCityStateValue() {
		return errorpermCityStateValue;
	}

	public void setErrorpermCityStateValue(String errorpermCityStateValue) {
		this.errorpermCityStateValue = errorpermCityStateValue;
	}

	public String getErrormailingCityStateValue() {
		return errormailingCityStateValue;
	}

	public void setErrormailingCityStateValue(String errormailingCityStateValue) {
		this.errormailingCityStateValue = errormailingCityStateValue;
	}

	// New fields Added for SumaCare-START
	private String permanentCounty;
	private String emcont;

	public String getEmcont() {
		return emcont;
	}

	public void setEmcont(String emcont) {
		this.emcont = emcont;
	}

	public String getPermanentCounty() {
		return permanentCounty;
	}

	public void setPermanentCounty(String permanentCounty) {
		this.permanentCounty = permanentCounty;
	}
	// New fields Added for SumaCare-END
	
	// New fields Added for Sharp-start
	
	private String healthPlnNewzInd;
	private String caLicence;
	private String agentName;
	private String electionType;
	private String pcp;
	
	

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public String getElectionType() {
		return electionType;
	}

	public void setElectionType(String electionType) {
		this.electionType = electionType;
	}

	public String getPcp() {
		return pcp;
	}

	public String getPhysician() {
		return physician;
	}

	public void setPhysician(String physician) {
		this.physician = physician;
	}

	public String getPhysicianName() {
		return physicianName;
	}

	public void setPhysicianName(String physicianName) {
		this.physicianName = physicianName;
	}

	public void setPcp(String pcp) {
		this.pcp = pcp;
	}

	public String getCaLicence() {
		return caLicence;
	}

	public void setCaLicence(String caLicence) {
		this.caLicence = caLicence;
	}

	public String getHealthPlnNewzInd() {
		return healthPlnNewzInd;
	}

	public void setHealthPlnNewzInd(String healthPlnNewzInd) {
		this.healthPlnNewzInd = healthPlnNewzInd;
	}
	// New fields Added for Sharp-end

	private String erroremergencyRelValue;
	public String getErroremergencyRelValue() {
		return erroremergencyRelValue;
	}

	public void setErroremergencyRelValue(String erroremergencyRelValue) {
		this.erroremergencyRelValue = erroremergencyRelValue;
	}

	public String getErrorphysicianValue() {
		return errorphysicianValue;
	}

	public void setErrorphysicianValue(String errorphysicianValue) {
		this.errorphysicianValue = errorphysicianValue;
	}

	private String errorphysicianValue;
	
	//Begin: Making MedicaidId Field as Non Mandatory for DSNP plans
	public String getStrPlanId() {
		return strPlanId;
	}
	public void setStrPlanId(String strPlanId) {
		this.strPlanId = strPlanId;
	}
	//End: Making MedicaidId Field as Non Mandatory for DSNP plans
	
	/*IFOX-00418144 2020 AEP Plan Changes. START*/
	private String planName;

	/**
	 * @return the planName
	 */
	public String getPlanName() {
		return planName;
	}
	/**
	 * @param planName the planName to set
	 */
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	/*IFOX-00418144 2020 AEP Plan Changes. END*/
	
	//IFOX-00419089 PBP 801 CR - Start
	private String ssn;

	public String getSsn() {
		return ssn;
	}
	public void setSsn(String ssn) {
		this.ssn = ssn;
	}
	//IFOX-00419089 PBP 801 CR - End
}
