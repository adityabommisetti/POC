package com.medicare.util;

//import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
//import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;

import com.medicare.helper.M360AppUtil;
import com.medicare.model.UserAccountDetails;
import com.medicare.model.UserAddress;
import com.medicare.model.UserAgentDetails;
import com.medicare.model.UserDetails;
import com.medicare.model.UserLegalRepDetails;
import com.medicare.model.UserOtherPolicyDetails;
import com.medicare.model.UserPolicyDetails;
import com.medicare.service.IUserDetailsService;
import com.medicare.service.UserDetailsServiceImpl;
import com.medicare.vo.AgreeDetailsVO;
import com.medicare.vo.AttestationDetailsVO;
import com.medicare.vo.EnrollmentVO;
import com.medicare.vo.LoginVO;
import com.medicare.vo.PolicyDetailsVO;
import com.medicare.vo.UserDetailsVO;

public class WebAppUtil {
	private final static Logger LOGGER = Logger.getLogger(WebAppUtil.class.getName());
	

	public static UserDetails getUserDetailsObject(HttpServletRequest request, HttpServletResponse response, int sequenceNumber) {
	
		System.out.println("WebAppUtil");
		UserDetails userDetails = new UserDetails();

		UserDetailsVO userDetailsVO = (UserDetailsVO) request.getSession().getAttribute("userDetailsVO");
		PolicyDetailsVO policyDetailsVO = (PolicyDetailsVO) request.getSession().getAttribute("policyDetails");
		AttestationDetailsVO attestationDetailsVO = (AttestationDetailsVO) request.getSession().getAttribute("attestationDetailsVO");
		AgreeDetailsVO agreeDetailsVO = (AgreeDetailsVO) request.getSession().getAttribute("agreeDetailsVO");
		EnrollmentVO enrollmentVO = (EnrollmentVO) request.getSession().getAttribute("enrollmentVO");
		
		System.out.println("Customer : ID "+userDetailsVO.getCustomerId());
		
		byte[] ps = Base64.decodeBase64((byte[]) request.getSession().getAttribute("pdfSaveenrollGen"));
		try {
		//seqNum = M360AppUtil.getSequenecNumber();
	
		LOGGER.info(" Latest SEQUENCE Number " + sequenceNumber);
		userDetails.setUserId(sequenceNumber);
 		userDetails.setPdfBlob(ps);

		userDetails.setCampaignId(StringUtil.nonNullTrim(userDetailsVO.getCampaignId()));
		userDetails.setContractId(StringUtil.nonNullTrim(userDetailsVO.getContractId()));
		//userDetails.setEffDate(formatDate(userDetailsVO.getEffDate()));
		userDetails.setEffDate( !"".equals(userDetailsVO.getEffDate()) ? formatDate(userDetailsVO.getEffDate()) : formatDate());

		userDetails.setIsAudipTap("");
		userDetails.setIsBraille("");
		userDetails.setBrokerApp("");

		userDetails.setEemFlag("N");

		userDetails.setFirstName(StringUtil.nonNullTrim(userDetailsVO.getFirstName().toUpperCase()));
		userDetails.setLastName(StringUtil.nonNullTrim(userDetailsVO.getLastName().toUpperCase()));
		userDetails.setMiddleInitial(StringUtil.nonNullTrim(userDetailsVO.getMiddleInitial().toUpperCase()));
		userDetails.setSuffix(StringUtil.nonNullTrim(userDetailsVO.getSuffix()));
		userDetails.setBirthDate(formatDate(userDetailsVO.getBirthDate()));
		userDetails.setSex(StringUtil.nonNullTrim(userDetailsVO.getSex()));
		userDetails.setHomePhneNum(StringUtil.nonNullTrim(userDetailsVO.getHomePhNumber()));
		userDetails.setAltrPhneNum(StringUtil.nonNullTrim(userDetailsVO.getAltrPhNumber()));
		userDetails.setEmailAddr(StringUtil.nonNullTrim(userDetailsVO.getEmailAddr()));
		
		userDetails.setHealthPlanNewsViaEMail(StringUtil.nonNullTrim(enrollmentVO.getEmailAlert())); //2019 web app changes - IFOX-00406768

		userDetails.setEmrgContactName(StringUtil.nonNullTrim(userDetailsVO.getEmergencyCont()));
		userDetails.setRelationship(StringUtil.nonNullTrim(userDetailsVO.getRelationYou()));
		userDetails.setEmrgPhneNum(StringUtil.nonNullTrim(userDetailsVO.getEmergPhNum()));
		userDetails.setPrimaryPhysician(StringUtil.nonNullTrim(policyDetailsVO.getPhysician()));
		

		userDetails.setMedicareClaimNum(StringUtil.nonNullTrim(userDetailsVO.getMediacrdNumber()));
		System.out.println("The HIC number is : "+userDetailsVO.getMediacrdNumber());
		userDetails.setMedicareName(StringUtil.nonNullTrim(userDetailsVO.getNameBeneficiary()));
		userDetails.setMedicareSex(StringUtil.nonNullTrim(userDetailsVO.getBeneficiarySex()));
		userDetails.setHospitalDate(formatDate(userDetailsVO.getHospitalDate()));
		userDetails.setMedicalDate(formatDate(userDetailsVO.getMedicalDate()));

		userDetails.setIsLprintFormat("");
		userDetails.setEmailAddrFormat("");
		
		if(enrollmentVO.getEsrdcontact() != null && "Y".equalsIgnoreCase(enrollmentVO.getEsrdcontact()) ){
			userDetails.setIsCdFormat("Y");
		}else{
			userDetails.setIsCdFormat("N");
		}
		
		
		userDetails.setRenalDisease(StringUtil.nonNullTrim(policyDetailsVO.getRenalDisease()));

		userDetails.setAccptAggrDate(formatDate(agreeDetailsVO.getTodayDate()));
		userDetails.setOptimaPlan(userDetailsVO.getOptimaMedicare());
		if ((agreeDetailsVO.getTodayDate() != null && !agreeDetailsVO.getTodayDate().isEmpty()) || (agreeDetailsVO.getTodayRepDate() != null && !agreeDetailsVO.getTodayRepDate().isEmpty())) {
				userDetails.setIsAgree("Y");
		} else {
			   userDetails.setIsAgree("N");
		}

		userDetails.setApplicationStatus("S");
		userDetails.setCustomerId(userDetailsVO.getCustomerId());
		userDetails.setSignatureName(agreeDetailsVO.getSignatureName());
		userDetails.setSignatureRepName(StringUtil.nonNullTrim(agreeDetailsVO.getRepSignatureName()));
		//IFOX-00419089 PBP 801 CR - Start
		userDetails.setSsn(StringUtil.nonNullTrim(userDetailsVO.getSsn()));
		//IFOX-00419089 PBP 801 CR - End
		
		String timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime());
		Timestamp ts = Timestamp.valueOf(timeStamp);

		userDetails.setCreatedDate(new Date());

		Set<UserAddress> userAddressesSet = new HashSet<UserAddress>();
		UserAddress userAddress = null;

		userAddress = new UserAddress();
		userAddress.setAddressId(sequenceNumber);
		userAddress.setUserId(sequenceNumber);
		userAddress.setCustomerId(StringUtil.nonNullTrim(userDetailsVO.getCustomerId()));
		userAddress.setPermAddress1(StringUtil.nonNullTrim(userDetailsVO.getPermanentAddr()));
		userAddress.setPermAddress2(StringUtil.nonNullTrim(userDetailsVO.getPermanentStrt()));
		userAddress.setPermApartment(StringUtil.nonNullTrim(userDetailsVO.getPermanentApt()));
		userAddress.setPermCity(StringUtil.nonNullTrim(userDetailsVO.getPermanentCity()));
		userAddress.setPermState(StringUtil.nonNullTrim(userDetailsVO.getPermanentState()));
		userAddress.setPermZipCode(StringUtil.nonNullTrim(userDetailsVO.getPermanentZip()));
		userAddress.setMailAddress1(StringUtil.nonNullTrim(userDetailsVO.getMailingAddr()));
		userAddress.setMailAddress2(StringUtil.nonNullTrim(userDetailsVO.getMailingStrt()));
		userAddress.setMailApartment(StringUtil.nonNullTrim(userDetailsVO.getMailingApt()));
		userAddress.setMailCity(StringUtil.nonNullTrim(userDetailsVO.getMailingCity()));
		userAddress.setMailState(StringUtil.nonNullTrim(userDetailsVO.getMailingState()));
		userAddress.setMailZipCode(StringUtil.nonNullTrim(userDetailsVO.getMailingZip()));
		userAddressesSet.add(userAddress);

		Set<UserAccountDetails> userAccountDetailsSet = new HashSet<UserAccountDetails>();
		UserAccountDetails userAccountDetail = new UserAccountDetails();
		userAccountDetail.setAcntId(sequenceNumber);
		userAccountDetail.setUserId(sequenceNumber);

		userAccountDetail.setCustomerId(userDetailsVO.getCustomerId());
		userAccountDetail.setAcntName(StringUtil.nonNullTrim(policyDetailsVO.getAccountHolderName()));
		userAccountDetail.setBankRtingNum(StringUtil.nonNullTrim(policyDetailsVO.getBankRoutingNumber()));
		userAccountDetail.setBankAcctNum(StringUtil.nonNullTrim(policyDetailsVO.getBankAccountNumber()));

		if (StringUtil.nonNullTrim(policyDetailsVO.getPaymentOption()).equalsIgnoreCase("D")) {
			userAccountDetail.setIsEtf("");
			userAccountDetail.setIsAutoDeduct("");
			userAccountDetail.setIsMonthlyBill("D");

		} else if (StringUtil.nonNullTrim(policyDetailsVO.getPaymentOption()).equalsIgnoreCase("S")) {
			userAccountDetail.setIsEtf("S");
			userAccountDetail.setIsAutoDeduct("S");
			userAccountDetail.setIsMonthlyBill("");

		} else if (StringUtil.nonNullTrim(policyDetailsVO.getPaymentOption()).equalsIgnoreCase("R")) {
			userAccountDetail.setIsEtf("R");
			userAccountDetail.setIsAutoDeduct("R");
			userAccountDetail.setIsMonthlyBill("");

		}else{
			userAccountDetail.setIsEtf("");
			userAccountDetail.setIsAutoDeduct("");
			userAccountDetail.setIsMonthlyBill("D");
			
		}

		userAccountDetailsSet.add(userAccountDetail);

		/*
		 * Set<UserPolicyDetails> userPolicyDetailsSet = new
		 * HashSet<UserPolicyDetails>(); UserPolicyDetails userPolicyDetail =
		 * new UserPolicyDetails(); userPolicyDetail.setPolicyId(seqNum);
		 * userPolicyDetail.setUserId(seqNum);
		 * userPolicyDetail.setCustomerId(userDetailsVO.getCustomerId());
		 * userPolicyDetail.setPlanName("");
		 * userPolicyDetail.setPolicyNumber("");
		 * userPolicyDetail.setBeginningDate(formatDate(policyDetailsVO
		 * .getBeginingDate()));
		 * 
		 * if (attestationDetailsVO.getEligibleEnroll() != null) {
		 * userPolicyDetail.setIsAnulElgbEnroll(attestationDetailsVO
		 * .getEligibleEnroll()); } else {
		 * userPolicyDetail.setIsAnulElgbEnroll("N"); }
		 * userPolicyDetail.setLeavingCovrgDate(formatDate(attestationDetailsVO
		 * .getLeavingEmployerCoverage()));
		 * 
		 * userPolicyDetail.setRecentMovedDate(formatDate(attestationDetailsVO
		 * .getRecentMovedOption()));
		 * 
		 * userPolicyDetail.setLeftPaceDate(formatDate(attestationDetailsVO
		 * .getRecntLeftPace())); if
		 * (attestationDetailsVO.getBelongStatePharmacy() == null ||
		 * attestationDetailsVO.getBelongStatePharmacy().isEmpty()) {
		 * userPolicyDetail.setIsBelongStatePharmcy(""); } else {
		 * userPolicyDetail.setIsBelongStatePharmcy(attestationDetailsVO
		 * .getBelongStatePharmacy()); }
		 * userPolicyDetail.setBackUsDate(formatDate(attestationDetailsVO
		 * .getMovedBackUs()));
		 * 
		 * if (attestationDetailsVO.getMcNumChBox() == null) {
		 * userPolicyDetail.setStateMedicardNum("N"); } else {
		 * userPolicyDetail.setStateMedicardNum(attestationDetailsVO
		 * .getMcNumChBox()); }
		 * 
		 * userPolicyDetail
		 * .setMovedOutFacilityDate(formatDate(attestationDetailsVO
		 * .getOutLongTermFacility()));
		 * 
		 * userPolicyDetail.setNewElgbDate(formatDate(attestationDetailsVO
		 * .getIncarceration()));
		 * 
		 * if (policyDetailsVO.getInstituteName() == null) {
		 * userPolicyDetail.setNameInstitution(""); } else {
		 * userPolicyDetail.setNameInstitution(policyDetailsVO
		 * .getInstituteName());
		 * 
		 * }
		 * 
		 * if (policyDetailsVO.getInstitutePhone() == null) {
		 * userPolicyDetail.setPhoneNumber(""); } else { userPolicyDetail
		 * .setPhoneNumber(policyDetailsVO.getInstitutePhone());
		 * 
		 * }
		 * 
		 * if (policyDetailsVO.getInstituteAddress() == null) {
		 * userPolicyDetail.setAddressInstitution(""); } else {
		 * userPolicyDetail.setAddressInstitution(policyDetailsVO
		 * .getInstituteAddress());
		 * 
		 * }
		 * 
		 * if (policyDetailsVO.getInstituteOtherAddress() == null) {
		 * userPolicyDetail.setAddressInstitutionStreet(""); } else {
		 * 
		 * userPolicyDetail.setAddressInstitutionStreet(policyDetailsVO
		 * .getInstituteOtherAddress());
		 * 
		 * }
		 * 
		 * userPolicyDetail.setLostCoverageDate(formatDate(attestationDetailsVO
		 * .getRecentlyCreditable()));
		 * 
		 * userPolicyDetail.setPayPrescriptionDate(formatDate(null));
		 * userPolicyDetail.setNoElgbDrugsDate(formatDate(attestationDetailsVO
		 * .getNoEligbPrescDrugs()));
		 * 
		 * userPolicyDetail.setOutsidePlanDate(formatDate(null));
		 * 
		 * if (attestationDetailsVO.getPlanEndingContract() == null) {
		 * userPolicyDetail.setIsPlanContractCoverage(""); }
		 * 
		 * userPolicyDetail.setIsNoneStatements("");
		 * 
		 * userPolicyDetail.setSpecialPlanDate(formatDate(attestationDetailsVO
		 * .getNoEligSpecial()));
		 * 
		 * userPolicyDetail.setOtherReason("");
		 * userPolicyDetailsSet.add(userPolicyDetail);
		 */

		Set<UserPolicyDetails> userPolicyDetailsSet = new HashSet<UserPolicyDetails>();
		UserPolicyDetails userPolicyDetail = new UserPolicyDetails();
		userPolicyDetail.setPolicyId(sequenceNumber);
		userPolicyDetail.setUserId(sequenceNumber);
		userPolicyDetail.setCustomerId(StringUtil.nonNullTrim(userDetailsVO.getCustomerId()));
		userPolicyDetail.setPlanName("");
		userPolicyDetail.setPolicyNumber("");
		userPolicyDetail.setBeginningDate(formatDate(policyDetailsVO.getBeginingDate()));

		if (attestationDetailsVO.getEligibleEnroll() != null) {
			userPolicyDetail.setIsAnulElgbEnroll(attestationDetailsVO.getEligibleEnroll());
		} else {
			userPolicyDetail.setIsAnulElgbEnroll("N");
		}
		userPolicyDetail.setLeavingCovrgDate(formatDate(attestationDetailsVO.getLeavingEmployerCoverage()));

		userPolicyDetail.setRecentMovedDate(formatDate(attestationDetailsVO.getRecentMovedOption()));

		userPolicyDetail.setLeftPaceDate(formatDate(attestationDetailsVO.getRecntLeftPace()));
		userPolicyDetail.setIsBelongStatePharmcy(StringUtil.nonNullTrim(attestationDetailsVO.getBelongStatePharmacy()));
		userPolicyDetail.setBackUsDate(formatDate(attestationDetailsVO.getMovedBackUs()));

		if (attestationDetailsVO.getMcNumChBox() == null) {
			userPolicyDetail.setStateMedicardNum("N");
		} else {
			userPolicyDetail.setStateMedicardNum(attestationDetailsVO.getMcNumChBox());
		}

		userPolicyDetail.setMovedOutFacilityDate(formatDate(attestationDetailsVO.getOutLongTermFacility()));

		userPolicyDetail.setNewElgbDate(formatDate(attestationDetailsVO.getIncarceration()));
		userPolicyDetail.setNameInstitution(StringUtil.nonNullTrim(policyDetailsVO.getInstituteName()));
		
		// Added for spouse work indicator
		
		userPolicyDetail.setSpouseWorkIndicator(nonNullTrim(policyDetailsVO.getSpouse()));
		userPolicyDetail.setPhoneNumber(StringUtil.nonNullTrim(policyDetailsVO.getInstitutePhone()));
		userPolicyDetail.setAddressInstitution(StringUtil.nonNullTrim(policyDetailsVO.getInstituteAddress()));
		userPolicyDetail.setAddressInstitutionStreet(StringUtil.nonNullTrim(policyDetailsVO.getInstituteOtherAddress()));

		userPolicyDetail.setLostCoverageDate(formatDate(attestationDetailsVO.getRecentlyCreditable()));

		userPolicyDetail.setPayPrescriptionDate(formatDate(null));
		userPolicyDetail.setNoElgbDrugsDate(formatDate(attestationDetailsVO.getNoEligbPrescDrugs()));

		userPolicyDetail.setOutsidePlanDate(formatDate(null));

		if (attestationDetailsVO.getPlanEndingContract() == null) {
			userPolicyDetail.setIsPlanContractCoverage("");
		} else if (userPolicyDetail.getIsPlanContractCoverage() == null) {
			userPolicyDetail.setIsPlanContractCoverage("");
		}

		if(enrollmentVO.getExistingp() != null && "Y".equalsIgnoreCase(enrollmentVO.getExistingp())){
			userPolicyDetail.setIsNoneStatements("Y");
		}else if(enrollmentVO.getExistingp() != null && "N".equalsIgnoreCase(enrollmentVO.getExistingp())){
			userPolicyDetail.setIsNoneStatements("N");
		}else {
			userPolicyDetail.setIsNoneStatements("");
		}
		

		userPolicyDetail.setSpecialPlanDate(formatDate(attestationDetailsVO.getNoEligSpecial()));

		String attestationTypeValue = getAttestationValue(enrollmentVO);
		
		System.out.println("attestationTypeValue ["+attestationTypeValue + "] ");
		
		//Logger.info("Attestation Selected by the User : "+attestationTypeValue)
		
		userPolicyDetail.setOtherReason(attestationTypeValue);
		
		String attestationDate = getAttestationDateValue(enrollmentVO);
		
		System.out.println("attestationDate [" + attestationDate + "] ");
		
		if(attestationDate != null && !attestationDate.equals("")){
			userPolicyDetail.setUnionCoverageDate(formatDate(attestationDate));
		}
		
		userPolicyDetailsSet.add(userPolicyDetail);

		Set<UserOtherPolicyDetails> userOtherPolicyDetailsSet = new HashSet<UserOtherPolicyDetails>();
		UserOtherPolicyDetails userOtherPolicyDetails = null;
		int id = sequenceNumber * 3;
		userOtherPolicyDetails = new UserOtherPolicyDetails();
		userOtherPolicyDetails.setCustomerId(StringUtil.nonNullTrim(userDetailsVO.getCustomerId()));

		userOtherPolicyDetails.setPolicyId(id);
		userOtherPolicyDetails.setUserId(sequenceNumber);
		userOtherPolicyDetails.setCoverageType("DRUG");
		userOtherPolicyDetails.setCoverageGroup(StringUtil.nonNullTrim(policyDetailsVO.getDurgGroupCoverage()));
		userOtherPolicyDetails.setCoverageName(StringUtil.nonNullTrim(policyDetailsVO.getDurgNameCoverage()));
		userOtherPolicyDetails.setCoverageId(StringUtil.nonNullTrim(policyDetailsVO.getDurgIdCoverage()));

		/*if (policyDetailsVO.getDurgCoveragePeriod() == null) {
			userOtherPolicyDetails.setCoveragePeriod("");
		} else {

			userOtherPolicyDetails.setCoveragePeriod(policyDetailsVO.getDurgCoveragePeriod());
		}*/

		userOtherPolicyDetails.setCoveragePeriod("");

		userOtherPolicyDetailsSet.add(userOtherPolicyDetails);
		
		// Added for IFOX-00390466 - Retrofit Medicaid ID Changes: Start
		if(StringUtil.nonNullTrim(policyDetailsVO.getStateMedicaid()).equals("Y"))
			userPolicyDetail.setStateMedicaid("Y");
		else
			userPolicyDetail.setStateMedicaid("N");
		
		userPolicyDetail.setMedicaidNumber(StringUtil.nonNullTrim(policyDetailsVO.getMedicaidNumber()));
		// Added for IFOX-00390466 - Retrofit Medicaid ID Changes: End

		//Begin: Added for IFOX-00390786 (Phase-II)
		if(nonNullTrim(policyDetailsVO.getInstituteName()).length() == 6)
			userPolicyDetail.setInstituteId(policyDetailsVO.getInstituteName());
		else
			userPolicyDetail.setInstituteId("");
		System.out.println(" Institutional Id [" + userPolicyDetail.getInstituteId() + "] ");
		//End: Added for IFOX-00390786 (Phase-II)
		
		Set<UserAgentDetails> userAgentDetailsSet = new HashSet<UserAgentDetails>();
		UserAgentDetails userAgentDetails = new UserAgentDetails();
		userAgentDetails.setAgentId(sequenceNumber);
		userAgentDetails.setCustomerId(StringUtil.nonNullTrim(userDetailsVO.getCustomerId()));
		userAgentDetails.setUserId(sequenceNumber);

	//	if ("HCF0027".equalsIgnoreCase(userDetailsVO.getCustomerId())) {
			userAgentDetails.setAgentName(StringUtil.nonNullTrim(agreeDetailsVO.getAgentName()));
			userAgentDetails.setElectionType("");
		/*	if (agreeDetailsVO.getPlanId() == null) {
				userAgentDetails.setPlanId("");
			} else {*/
				userAgentDetails.setPlanId(StringUtil.nonNullTrim(agreeDetailsVO.getPlanId()));
			//}
				String planName = (String)request.getSession().getAttribute("planName");
				LOGGER.info("Plan Name : "+planName);
//			if(("IN01".equalsIgnoreCase(enrollmentVO.getProductId()) || ("IN01".equalsIgnoreCase(enrollmentVO.getProductId()) || ("IN01".equalsIgnoreCase(enrollmentVO.getProductId()) || ("IN01".equalsIgnoreCase(enrollmentVO.getProductId()) || ("IN01".equalsIgnoreCase(enrollmentVO.getProductId()) ) && enrollmentVO.getp
			if("SAB".equalsIgnoreCase(planName) || "SAP".equalsIgnoreCase(planName) || "SAS".equalsIgnoreCase(planName) || "SASP".equalsIgnoreCase(planName) || "SAMEA".equalsIgnoreCase(planName) ){
				userAgentDetails.setEffDate(formatDate("12/01/2017"));
				LOGGER.info("Inside Default Date : 12/01/2017");
			}else{
				userAgentDetails.setEffDate(formatDate(userDetailsVO.getEffDate()));
			}
	//	}

		//userAgentDetails.setSentaraAgentID("");
		LOGGER.info("AGENT ID:"+enrollmentVO.getNameAgent());
		userAgentDetails.setSentaraAgentID(StringUtil.nonNullTrim(enrollmentVO.getNameAgent()));

		userAgentDetails.setWebTelApp("WEB");
		userAgentDetailsSet.add(userAgentDetails);

		Set<UserLegalRepDetails> userLegalRepDetailsSet = new HashSet<UserLegalRepDetails>();
		UserLegalRepDetails userLegalRepDetails = new UserLegalRepDetails();
		userLegalRepDetails.setRepId(sequenceNumber);
		userLegalRepDetails.setUserId(sequenceNumber);
		userLegalRepDetails.setCustomerId(StringUtil.nonNullTrim(userDetailsVO.getCustomerId()));
		userLegalRepDetails.setRelationshipEnrolle(StringUtil.nonNullTrim(agreeDetailsVO.getLegalRelationErloll()));
		userLegalRepDetails.setRepAddress(StringUtil.nonNullTrim(agreeDetailsVO.getLegalAddress()));
		userLegalRepDetails.setRepName(StringUtil.nonNullTrim(agreeDetailsVO.getLegalFirstName()));
		userLegalRepDetails.setRepPhnNum(StringUtil.nonNullTrim(agreeDetailsVO.getLegalPhNumber()));
		userLegalRepDetails.setRepAddressTwo("");
		userLegalRepDetails.setReplastName("");
		userLegalRepDetails.setRepMiddleInitial("");
		userLegalRepDetails.setRepAddressThree("");
		userLegalRepDetails.setRepCity("");
		userLegalRepDetails.setRepState("");
		userLegalRepDetails.setRepzipCode("");

		userLegalRepDetailsSet.add(userLegalRepDetails);

		userDetails.setUserAddressesSet(userAddressesSet);
		userDetails.setUserAccountDetailsSet(userAccountDetailsSet);
		userDetails.setUserPolicyDetailsSet(userPolicyDetailsSet);
		userDetails.setUserAgentDetails(userAgentDetailsSet);
		userDetails.setUserLegalRepDetails(userLegalRepDetailsSet);
		userDetails.setUserOtherPolicyDetails(userOtherPolicyDetailsSet);
		//removeSession(request);
		
		} catch (Exception exception) {
			//exception.printStackTrace();
			LOGGER.error(" WebAppUtil : getUserDetailsObject : " + exception.getMessage());
		}
		return userDetails;
	}
	
	public static void removeSession(HttpServletRequest request) {

		LOGGER.info(" Start : In remvoeSessionValues() method of WebAppUtil class");
		request.getSession().removeAttribute("policyDetails");
		request.getSession().removeAttribute("userDetailsVO");
		request.getSession().removeAttribute("policyDetails1");
		request.getSession().removeAttribute("policyDetails2");
		request.getSession().removeAttribute("attestationDetailsVO");
		request.getSession().removeAttribute("agreeDetailsVO");
		request.getSession().removeAttribute("policyDetails");
		request.getSession().removeAttribute("physicianMap");
		request.getSession().removeAttribute("relationsMap");
		request.getSession().removeAttribute("county");
		request.getSession().removeAttribute("stateMap");
		request.getSession().removeAttribute("policyDetailsVO1");
		request.getSession().removeAttribute("agreeDetailsVO");
		request.getSession().removeAttribute("pdfSaveenrollGen");
		
	}
	
	
	
	// Added for IFOX-00390466 - Retrofit Medicaid ID Changes: Start
	public static String nonNullTrim(String s) {
        if (s == null)
            return "";
        return s.trim();
    }
	// Added for IFOX-00390466 - Retrofit Medicaid ID Changes: End

	private static String getValue(String texto) {
		if (texto != null) {
			return texto;
		} else {
			return "";
		}
	}
	/**
	 * @param date
	 * @return
	 * @throws ParseException
	 */
	public static Date formatDate(String date) {

		//Begin: Modified for IFOX-00406260 (Sharp Web App application getting enrollment confirmation number as Zero)
		
		//if (date != null && !date.isEmpty()) {

		LOGGER.info(" WebAppUtil : formatDate : Date [" + date + "] ");
		if (date != null && !date.trim().equals(""))
		{
			try {
				if(date.indexOf("-") == -1)
				{
					date = date.replaceAll("/", "");
					String month =  date.substring(0, 2);
					String day =  date.substring(2, 4);
					String year =  date.substring(4);
					date = month + "/" + day + "/" + year;
					//Fix for IFOX-00414154 new date validation for Sharp WebApp - Start
				} else if(Pattern.compile("[0-9]{4}-[0-9]{2}-[0-9]{2}").matcher(date).find()) {
					date = date.replaceAll("-", "");
					String month =  date.substring(4,6);
					String day =  date.substring(6);
					String year =  date.substring(0,4);
					date = month + "/" + day + "/" + year;
				}
				//Fix for IFOX-00414154 new date validation for Sharp WebApp - End
				LOGGER.info(" WebAppUtil : formatDate : After formating Input in MM/DD/YYYY format, the Date is [" + date + "] ");

		//End: Modified for IFOX-00406260 (Sharp Web App application getting enrollment confirmation number as Zero)
				
				Date dateBeforeConvert = new SimpleDateFormat("MM/dd/yyyy").parse(date);
				String convertedDate = new SimpleDateFormat("yyyy-MM-dd").format(dateBeforeConvert);
				Date dateAfterConvert = new SimpleDateFormat("yyyy-MM-dd").parse(convertedDate);
				return dateAfterConvert;
			} catch (ParseException e) {
				e.printStackTrace();
				LOGGER.info(" WebAppUtil : formatDate : IF : Exception [" + e.getMessage() + "] ");
				return null;
			}

		} else {

			String dummyDate = "07/01/2018";
			Date dateBeforeConvert;
			try {
				dateBeforeConvert = new SimpleDateFormat("MM/dd/yyyy").parse(dummyDate);
				String convertedDate = new SimpleDateFormat("yyyy-MM-dd").format(dateBeforeConvert);
				Date dateAfterConvert = new SimpleDateFormat("yyyy-MM-dd").parse(convertedDate);
				return dateAfterConvert;

			} catch (ParseException e) {
				e.printStackTrace();
				LOGGER.info(" WebAppUtil : formatDate : ELSE : Exception [" + e.getMessage() + "] ");
				return null;
			}

		}

	}
	
	public static UserDetailsVO mapToUserDetailsVO(EnrollmentVO enrollmentVO){
		
		UserDetailsVO userDetailsVO = new UserDetailsVO();
		userDetailsVO.setAgentName(StringUtil.checkNullOrTrim(enrollmentVO.getNameAgent()));
		userDetailsVO.setAltrPhNumber(StringUtil.checkNullOrTrim(enrollmentVO.getCellPhone()));
		userDetailsVO.setBeneficiarySex(StringUtil.checkNullOrTrim(enrollmentVO.getSex()));
		userDetailsVO.setBirthDate(StringUtil.checkNullOrTrim(enrollmentVO.getBirthDate()));
		userDetailsVO.setCaLicence(StringUtil.checkNullOrTrim(enrollmentVO.getAgentLicense()));
		userDetailsVO.setCampaignId(StringUtil.checkNullOrTrim(enrollmentVO.getProductId()));
		userDetailsVO.setContractId(StringUtil.checkNullOrTrim(enrollmentVO.getPlanId()));
		userDetailsVO.setCustomerId(StringUtil.checkNullOrTrim(enrollmentVO.getCustomerId()));
		/**IFOX-00403984 Changes Start.*/
		if(StringUtil.nonNullnonEmpty(enrollmentVO.getEffDate()))
			userDetailsVO.setEffDate(StringUtil.checkNullOrTrim(enrollmentVO.getEffDate()));
		else
			userDetailsVO.setEffDate(StringUtil.checkNullOrTrim(enrollmentVO.getCoveragebegin()));
		/**IFOX-00403984 Changes Stop.*/
		
		userDetailsVO.setElectionType(StringUtil.checkNullOrTrim(enrollmentVO.getElectionType()));
		userDetailsVO.setEmailAddr(StringUtil.checkNullOrTrim(enrollmentVO.getEmailAddr()));
/*		userDetailsVO.setEmcont(StringUtil.checkNullOrTrim("EMERGENCY"));
		userDetailsVO.setEmergencyCont(StringUtil.checkNullOrTrim("EMERGENCYCONTACT"));
		userDetailsVO.setEmergPhNum(StringUtil.checkNullOrTrim("EMERGENCYPHONE"));*/
		userDetailsVO.setEmcont(StringUtil.checkNullOrTrim(""));
		userDetailsVO.setEmergencyCont(StringUtil.checkNullOrTrim(""));
		userDetailsVO.setEmergPhNum(StringUtil.checkNullOrTrim(""));		
/*		userDetailsVO.setErroraltrPhNumberValue(StringUtil.checkNullOrTrim(enrollmentVO.getAlternatePhone()));
		userDetailsVO.setErrorbeneficiarySexValue(StringUtil.checkNullOrTrim(enrollmentVO.getSex()));
		userDetailsVO.setErrorbirthDateValue(StringUtil.checkNullOrTrim(enrollmentVO.getBirthDate()));
*/
		
		userDetailsVO.setFirstName(StringUtil.checkNullOrTrim(enrollmentVO.getFirstName()));
		userDetailsVO.setHealthPlnNewzInd(StringUtil.checkNullOrTrim(enrollmentVO.getEmailAlert()));
		userDetailsVO.setHomePhNumber(StringUtil.checkNullOrTrim(enrollmentVO.getPrimaryPhone()));
		// userDetailsVO.setHospitalDate(StringUtil.checkNullOrTrim(enrollmentVO.getHospitalPartB()));
		userDetailsVO.setHospitalDate(StringUtil.checkNullOrTrim(enrollmentVO.getHospitalPartA()));
		userDetailsVO.setLastName(StringUtil.checkNullOrTrim(enrollmentVO.getLastName()));
		userDetailsVO.setMailingAddr(StringUtil.checkNullOrTrim(enrollmentVO.getMailingAddr()));
		userDetailsVO.setMailingApt(StringUtil.checkNullOrTrim(""));
		//userDetailsVO.setMailingCity(StringUtil.checkNullOrTrim(enrollmentVO.getMailingCity()));
		
		userDetailsVO.setMailingCity(StringUtil.checkNullOrTrim(enrollmentVO.getMailingCity()));
		
		if(enrollmentVO.getMailingAddr() != null && !enrollmentVO.getMailingAddr().equals("")){
			userDetailsVO.setMailingState("CA");
		}
		
		// Commented for duplicating in M360 for the mailing address issue.
		
		userDetailsVO.setMailingStrt(StringUtil.checkNullOrTrim(""));
		
		userDetailsVO.setMailingZip(StringUtil.checkNullOrTrim(enrollmentVO.getMailingzip()));
		// userDetailsVO.setMedicalDate(StringUtil.checkNullOrTrim(enrollmentVO.getHospitalPartA()));
		userDetailsVO.setMedicalDate(StringUtil.checkNullOrTrim(enrollmentVO.getHospitalPartB()));
		userDetailsVO.setMediacrdNumber(StringUtil.checkNullOrTrim(enrollmentVO.getMedicareClaim()));
		userDetailsVO.setMiddleInitial(StringUtil.checkNullOrTrim(enrollmentVO.getMiddleInitial()));
		userDetailsVO.setNameBeneficiary(StringUtil.checkNullOrTrim(enrollmentVO.getFirstName()) + " " + StringUtil.checkNullOrTrim(enrollmentVO.getLastName()));
		
		userDetailsVO.setOptimaMedicare(StringUtil.checkNullOrTrim(enrollmentVO.getPbpId()));
		
		userDetailsVO.setPcp(StringUtil.checkNullOrTrim(enrollmentVO.getPcpName()));
		
		
		
		userDetailsVO.setPdfBlob(StringUtil.checkNullOrTrim(""));
		userDetailsVO.setPermanentAddr(StringUtil.checkNullOrTrim(enrollmentVO.getPermanentAddrStreet()));
		userDetailsVO.setPermanentApt(StringUtil.checkNullOrTrim(enrollmentVO.getPermanentAddrApt()));
		userDetailsVO.setPermanentCity(StringUtil.checkNullOrTrim(enrollmentVO.getPermanentCity()));
		//userDetailsVO.setPermanentCounty(StringUtil.checkNullOrTrim(enrollmentVO.getPermanentCounty()));
		userDetailsVO.setPermanentCounty(StringUtil.checkNullOrTrim("SAN DIEGO"));
		//userDetailsVO.setPermanentState(StringUtil.checkNullOrTrim(enrollmentVO.getPermanentState()));
		userDetailsVO.setPermanentState(StringUtil.checkNullOrTrim("CA"));
		userDetailsVO.setPermanentZip(StringUtil.checkNullOrTrim(enrollmentVO.getPermanentZip()));
		userDetailsVO.setPermCityState(StringUtil.checkNullOrTrim(enrollmentVO.getPermanentState()));
		userDetailsVO.setPhysician(StringUtil.checkNullOrTrim(enrollmentVO.getPcpName()));
		
		userDetailsVO.setPhysicianName(StringUtil.checkNullOrTrim(enrollmentVO.getPcpMedicalGroupName()));
		userDetailsVO.setRelationYou(StringUtil.checkNullOrTrim(enrollmentVO.getAuthorizedreprelationship()));
		userDetailsVO.setSex(StringUtil.checkNullOrTrim(enrollmentVO.getSex()));
		userDetailsVO.setStrPlanId(StringUtil.checkNullOrTrim(enrollmentVO.getProductId()));
		userDetailsVO.setSuffix(StringUtil.checkNullOrTrim(enrollmentVO.getPrefix()));
		userDetailsVO.setUserId(100);
		//IFOX-00419089 PBP 801 CR - Start
		userDetailsVO.setSsn(StringUtil.checkNullOrTrim(enrollmentVO.getSsn()));
		//IFOX-00419089 PBP 801 CR - End
		return userDetailsVO;
		
	}

	public static AgreeDetailsVO mapToAgreeDetailsVO(EnrollmentVO enrollmentVO){
		
		AgreeDetailsVO agreeDetailsVO = new AgreeDetailsVO();
		agreeDetailsVO.setAdressInstNumber(StringUtil.checkNullOrTrim(enrollmentVO.getAddrOfInst()));
		agreeDetailsVO.setAdressInstStreet(StringUtil.checkNullOrTrim(enrollmentVO.getAddrOfInst()));
		agreeDetailsVO.setAep(StringUtil.checkNullOrTrim("Y"));
		agreeDetailsVO.setAgentId(StringUtil.checkNullOrTrim(enrollmentVO.getAgentLicense()));
		agreeDetailsVO.setAgentIdNameCheck(StringUtil.checkNullOrTrim(enrollmentVO.getAddrOfInst()));
		agreeDetailsVO.setAgentName(StringUtil.checkNullOrTrim(enrollmentVO.getNameAgent()));
		agreeDetailsVO.setAgreeStatements(StringUtil.checkNullOrTrim("Y"));
		agreeDetailsVO.setBelongStatePharmacy(StringUtil.checkNullOrTrim(enrollmentVO.getPcpMedicalGroupName()));
		agreeDetailsVO.setEffectDateCoverage(StringUtil.checkNullOrTrim(enrollmentVO.getCoveragebegin()));
		agreeDetailsVO.setEligibleEnroll(StringUtil.checkNullOrTrim("Y"));
		agreeDetailsVO.setIcep(StringUtil.checkNullOrTrim("N"));
		//agreeDetailsVO.setIcepDate("08/01/2017");
		agreeDetailsVO.setIcepDate("");
		agreeDetailsVO.setLeavingEmployerCoverage(StringUtil.checkNullOrTrim(enrollmentVO.getCoveragebegin()));
		agreeDetailsVO.setLegalAddress(StringUtil.checkNullOrTrim(enrollmentVO.getAuthorizedrepaddress()));
		agreeDetailsVO.setLegalAddressTwo(StringUtil.checkNullOrTrim(enrollmentVO.getPermanentAddrApt()));
		agreeDetailsVO.setLegalAddressThree(StringUtil.checkNullOrTrim(enrollmentVO.getPermanentAddrApt()));
		agreeDetailsVO.setLegalCity(StringUtil.checkNullOrTrim(enrollmentVO.getPermanentCity()));
		agreeDetailsVO.setLegalCityState(StringUtil.checkNullOrTrim(enrollmentVO.getPermanentState()));
		//agreeDetailsVO.setLegalFirstName(StringUtil.checkNullOrTrim(enrollmentVO.getFirstName()));
		//agreeDetailsVO.setLegalLastName(StringUtil.checkNullOrTrim(enrollmentVO.getLanguage()));
		agreeDetailsVO.setLegalFirstName(StringUtil.checkNullOrTrim(enrollmentVO.getAuthorizedrepname()));
		agreeDetailsVO.setLegalLastName(StringUtil.checkNullOrTrim(""));
		
		agreeDetailsVO.setLegalMiddleName(StringUtil.checkNullOrTrim(enrollmentVO.getMiddleInitial()));
		agreeDetailsVO.setLegalPhNumber(StringUtil.checkNullOrTrim(enrollmentVO.getAuthorizedrepphone()));
		agreeDetailsVO.setLegalRelationErloll(StringUtil.checkNullOrTrim(enrollmentVO.getAuthorizedreprelationship()));
		agreeDetailsVO.setLegalState(StringUtil.checkNullOrTrim(enrollmentVO.getPermanentState()));
		//agreeDetailsVO.setLevEmpChBox(levEmpChBox);
		agreeDetailsVO.setLegalZipCode(StringUtil.checkNullOrTrim(enrollmentVO.getPermanentZip()));
		//agreeDetailsVO.setLongtermCareFacility(StringUtil.checkNullOrTrim("Y"));
		agreeDetailsVO.setLongtermCareFacility(StringUtil.checkNullOrTrim(enrollmentVO.getPrescriptionDrug()));
		agreeDetailsVO.setMcNumChBox(StringUtil.checkNullOrTrim("Y"));
		agreeDetailsVO.setMedicardNumber(StringUtil.checkNullOrTrim(enrollmentVO.getMedicareClaim()));
		//agreeDetailsVO.setMovedBackUs(StringUtil.checkNullOrTrim("08/01/2017"));
		agreeDetailsVO.setMovedBackUs(StringUtil.checkNullOrTrim(""));
		agreeDetailsVO.setMvdUsChBox(StringUtil.checkNullOrTrim("Y"));
		agreeDetailsVO.setNameOfInst(StringUtil.checkNullOrTrim(enrollmentVO.getNameOfInst()));
		//agreeDetailsVO.setNewElgbChBox();
		agreeDetailsVO.setNewlyEligbleMedicare(StringUtil.checkNullOrTrim("Y"));
		//agreeDetailsVO.setNlElgPrescChBox();
		//agreeDetailsVO.setNoElgbspseChBox();
		agreeDetailsVO.setNoEligbPrescDrugs(StringUtil.checkNullOrTrim(StringUtil.checkNullOrTrim("N")));
		agreeDetailsVO.setNoEligSpecial("N");
		agreeDetailsVO.setNoneApplyMe(StringUtil.checkNullOrTrim("N"));
		agreeDetailsVO.setOtherReasons("N");
		agreeDetailsVO.setPhNum(StringUtil.checkNullOrTrim(enrollmentVO.getPrimaryPhone()));
		agreeDetailsVO.setPlanEndingContract(StringUtil.checkNullOrTrim(enrollmentVO.getProductId()));
		agreeDetailsVO.setPreferAudioTape("");
		agreeDetailsVO.setPreferCd("");
		agreeDetailsVO.setPreferEmail(StringUtil.checkNullOrTrim(enrollmentVO.getEmailAddr()));
		agreeDetailsVO.setRecentlyCreditable(enrollmentVO.getAttestation11());
		agreeDetailsVO.setRecentMovedOption(enrollmentVO.getAttestation9());
		agreeDetailsVO.setRecieveMedicareDrugs(StringUtil.checkNullOrTrim("N"));
		agreeDetailsVO.setRecntLeftPace(StringUtil.checkNullOrTrim(enrollmentVO.getAttestation10()));
		agreeDetailsVO.setRecntMovedOutSide(StringUtil.checkNullOrTrim(enrollmentVO.getAttestation11()));
		agreeDetailsVO.setRepSignature(StringUtil.checkNullOrTrim(enrollmentVO.getDigitalSignature()));
		agreeDetailsVO.setRepSignatureName(StringUtil.checkNullOrTrim(enrollmentVO.getNameSignature()));
		agreeDetailsVO.setSep("N");
		agreeDetailsVO.setSignature(StringUtil.checkNullOrTrim(enrollmentVO.getNameSignature()));
		agreeDetailsVO.setSignatureName(StringUtil.checkNullOrTrim(enrollmentVO.getNameSignature()));
		agreeDetailsVO.setTodayDate(StringUtil.checkNullOrTrim(enrollmentVO.getTodaysDate()));
		agreeDetailsVO.setTodayRepDate(StringUtil.checkNullOrTrim(enrollmentVO.getTodaysDate()));
		agreeDetailsVO.setUnionCoverage(StringUtil.checkNullOrTrim(enrollmentVO.getAttestation15()));
		agreeDetailsVO.setWebtelApp("WEB");
		return agreeDetailsVO;
		
		
	}	

	public static PolicyDetailsVO mapToPolicyDetailsVO(EnrollmentVO enrollmentVO){
		
		PolicyDetailsVO policyDetailsVO = new PolicyDetailsVO();
		policyDetailsVO.setAccountHolderName(StringUtil.checkNullOrTrim(enrollmentVO.getAcctholdername()));
		policyDetailsVO.setAcctype(StringUtil.checkNullOrTrim(enrollmentVO.getAcctType()));
		policyDetailsVO.setAutoDeduction(StringUtil.checkNullOrTrim(enrollmentVO.getPaymentOption()));
		policyDetailsVO.setBankAccountNumber(StringUtil.checkNullOrTrim(enrollmentVO.getAccountNumber()));
		policyDetailsVO.setBankName(StringUtil.checkNullOrTrim(enrollmentVO.getBankname()));
		policyDetailsVO.setBankRoutingNumber(StringUtil.checkNullOrTrim(enrollmentVO.getRoutingNumber()));
		policyDetailsVO.setBeginingDate(StringUtil.checkNullOrTrim(enrollmentVO.getCoveragebegin()));
		policyDetailsVO.setCustomerId(StringUtil.checkNullOrTrim(enrollmentVO.getCustomerId()));
		policyDetailsVO.setDurgCoveragePeriod(StringUtil.checkNullOrTrim("DRUG COVERAGE PERIOD"));
		policyDetailsVO.setDurgGroupCoverage(StringUtil.checkNullOrTrim(enrollmentVO.getGroupOfCov()));
		policyDetailsVO.setDurgIdCoverage(StringUtil.checkNullOrTrim(enrollmentVO.getIdOfCov()));
		policyDetailsVO.setDurgNameCoverage(StringUtil.checkNullOrTrim(enrollmentVO.getNameOfCov()));
		policyDetailsVO.setHealthBenefits(StringUtil.checkNullOrTrim(enrollmentVO.getVaBenefits()));
		policyDetailsVO.setInstituteAddress(StringUtil.checkNullOrTrim(enrollmentVO.getAddrOfInst()));
		
		policyDetailsVO.setInstituteId(StringUtil.checkNullOrTrim(enrollmentVO.getIdOfCov()));
		policyDetailsVO.setInstituteName(StringUtil.checkNullOrTrim(enrollmentVO.getNameOfInst()));
		policyDetailsVO.setInstitutePhone(StringUtil.checkNullOrTrim(enrollmentVO.getPhoneOfInst()));
		//policyDetailsVO.setLangInd(StringUtil.checkNullOrTrim(enrollmentVO.getLanguage().equalsIgnoreCase("SPANISH") ? "S" : "O"));
		policyDetailsVO.setLangInd(StringUtil.checkNullOrTrim(enrollmentVO.getLanguage()).equalsIgnoreCase("SPANISH") ? "S" : "O");
		policyDetailsVO.setMedicaidNumber(StringUtil.checkNullOrTrim(enrollmentVO.getMedicaidNbr()));
		policyDetailsVO.setMedicalCoveragePeriod(StringUtil.checkNullOrTrim("MEDICAL COV PERIOD"));
		policyDetailsVO.setMedicalGroupCoverage(StringUtil.checkNullOrTrim("MEDICAL GROUP COV"));
		policyDetailsVO.setMedicalIdCoverage(StringUtil.checkNullOrTrim("MEDICAID COV"));
		policyDetailsVO.setMedicalNameCoverage(StringUtil.checkNullOrTrim("MEDICAL NAME COV"));
		policyDetailsVO.setNursingHome(StringUtil.checkNullOrTrim(enrollmentVO.getPrescriptionDrug()));
		policyDetailsVO.setOtherLang(StringUtil.checkNullOrTrim(enrollmentVO.getLanguageValue()));
		policyDetailsVO.setOtherMedicalCoveragePeriod(StringUtil.checkNullOrTrim("OTHER MEDICAL COVERAGE"));
		policyDetailsVO.setOtherMedicalGroupCoverage(StringUtil.checkNullOrTrim("OTHER MEDICAL GROUP COVERAGE"));
		policyDetailsVO.setOtherMedicalIdCoverage(StringUtil.checkNullOrTrim("OTHER MEDICAL ID COVERAGE"));
		policyDetailsVO.setOtherMedicalNameCoverage(StringUtil.checkNullOrTrim("OTHER MEDICAL NAME COVERAGE"));
		policyDetailsVO.setPalnName(StringUtil.checkNullOrTrim(enrollmentVO.getProductId()));
		policyDetailsVO.setPaymentOption(StringUtil.checkNullOrTrim(enrollmentVO.getPaymentOption()));
		policyDetailsVO.setPaymentOptionTemp(StringUtil.checkNullOrTrim("PAYMENT OPTION TEMP"));
		policyDetailsVO.setPcpGroup(StringUtil.checkNullOrTrim(enrollmentVO.getPcpMedicalGroupName()));
		policyDetailsVO.setPhysician(StringUtil.checkNullOrTrim(enrollmentVO.getPcpName()));
		policyDetailsVO.setPhysicianName(StringUtil.checkNullOrTrim(enrollmentVO.getPcpName()));
		policyDetailsVO.setPolicyNumber(StringUtil.checkNullOrTrim("POLICY NUMBER"));
		policyDetailsVO.setPrescriptionDrug(StringUtil.checkNullOrTrim(enrollmentVO.getPrescriptionDrug()));
		policyDetailsVO.setRenalDisease(StringUtil.checkNullOrTrim(enrollmentVO.getRenalDisease()));
		policyDetailsVO.setSpouse(StringUtil.checkNullOrTrim(enrollmentVO.getSpousework()));
		policyDetailsVO.setStateMedicaid(StringUtil.checkNullOrTrim(enrollmentVO.getMedicaidprg()));
		policyDetailsVO.setUnionCoverageDate(new Date());
		
		return policyDetailsVO;
		
	}		
	
	public static AttestationDetailsVO mapToAttestationDetailsVO(EnrollmentVO enrollmentVO){
		
		AttestationDetailsVO attestationDetailsVO = new AttestationDetailsVO();
		attestationDetailsVO.setBelongStatePharmacy(StringUtil.checkNullOrTrim(enrollmentVO.getAttestation12()));
		attestationDetailsVO.setCurrentLngcare(StringUtil.checkNullOrTrim(enrollmentVO.getAttestation9()));
		attestationDetailsVO.setEligibleEnroll(StringUtil.checkNullOrTrim(enrollmentVO.getAttestation16()));
		//attestationDetailsVO.setIncarceration(StringUtil.checkNullOrTrim(enrollmentVO.getAttestation3()));
		attestationDetailsVO.setIncarceration(StringUtil.checkNullOrTrim(enrollmentVO.getAttestation3()));
		attestationDetailsVO.setIncarcerationInd(StringUtil.checkNullOrTrim("Y"));
		attestationDetailsVO.setLeavingEmployerCoverage(StringUtil.checkNullOrTrim(enrollmentVO.getAttestation12()));
		attestationDetailsVO.setLngcareFacility(StringUtil.checkNullOrTrim(enrollmentVO.getC9()));
		attestationDetailsVO.setLngcareFacilityDate(StringUtil.checkNullOrTrim(enrollmentVO.getAttestation9()));
		attestationDetailsVO.setMadp(StringUtil.checkNullOrTrim(enrollmentVO.getC6()));
		attestationDetailsVO.setMovedBackUs(StringUtil.checkNullOrTrim(enrollmentVO.getAttestation4()));
		attestationDetailsVO.setLawFullChkBox(StringUtil.checkNullOrTrim("Y"));
		attestationDetailsVO.setNewMedicare(StringUtil.checkNullOrTrim(enrollmentVO.getC1()));
		attestationDetailsVO.setNoEligbPrescDrugs(StringUtil.checkNullOrTrim(enrollmentVO.getAttestation8()));
		attestationDetailsVO.setOutLongTermFacility(StringUtil.checkNullOrTrim(enrollmentVO.getAttestation9()));
		attestationDetailsVO.setPlanEndingContract(StringUtil.checkNullOrTrim(enrollmentVO.getC14()));
		attestationDetailsVO.setPreferBraille(StringUtil.checkNullOrTrim(enrollmentVO.getLanguageValue()));
		attestationDetailsVO.setPreferlargePrint(StringUtil.checkNullOrTrim("N"));
		attestationDetailsVO.setPriorMedicare(StringUtil.checkNullOrTrim("N"));
		attestationDetailsVO.setPriorplanUnavailable(StringUtil.checkNullOrTrim("N"));
		attestationDetailsVO.setPriorplanUnavailableDate(StringUtil.checkNullOrTrim(""));
		attestationDetailsVO.setRecentlyCreditable(StringUtil.checkNullOrTrim(enrollmentVO.getAttestation11()));
		attestationDetailsVO.setRecentMovedOption(StringUtil.checkNullOrTrim(enrollmentVO.getAttestation2()));
		attestationDetailsVO.setRecntLeftPace(StringUtil.checkNullOrTrim(enrollmentVO.getAttestation10()));
		attestationDetailsVO.setRecntleftPlChBox(StringUtil.checkNullOrTrim(enrollmentVO.getC10()));
		attestationDetailsVO.setRecntMovChBox(StringUtil.checkNullOrTrim("Y"));
		attestationDetailsVO.setRevMedChBox(StringUtil.checkNullOrTrim("Y"));
		attestationDetailsVO.setTerminated(StringUtil.checkNullOrTrim("N"));
		attestationDetailsVO.setTerminationDate(StringUtil.checkNullOrTrim(""));
		attestationDetailsVO.setTrcntCreditChBox(StringUtil.checkNullOrTrim("Y"));
		
		//Begin: 2019 web app changes - IFOX-00406768
		attestationDetailsVO.setMedicareAdvantagePlanChange(StringUtil.checkNullOrTrim(enrollmentVO.getC21()));
		attestationDetailsVO.setChangeInMedicaid(StringUtil.checkNullOrTrim(enrollmentVO.getAttestation22()));
		attestationDetailsVO.setChangeInExtraHelp(StringUtil.checkNullOrTrim(enrollmentVO.getAttestation23()));
		attestationDetailsVO.setChooseDifferentMedicarePlan(StringUtil.checkNullOrTrim(enrollmentVO.getAttestation24()));
		attestationDetailsVO.setAffectedByMajorDisaster(StringUtil.checkNullOrTrim(enrollmentVO.getC25()));
		//End: 2019 web app changes - IFOX-00406768
		
		return attestationDetailsVO;
		
	}
	
	public static void saveEnrollmentVOToFile(EnrollmentVO enrollmentVO, String planId, String fileName){

			try {
				String filePath = "C:\\WEBAPP\\SHP\\SAVELOGOUT\\" + planId + "\\";
				
				File file = new File(filePath);
				if(!file.exists())
					file.mkdirs();
				
				ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filePath+fileName));
				oos.writeObject(enrollmentVO);
				System.out.println("The session file is created successfully with the name : "+fileName);
				oos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch(Exception e){
				e.printStackTrace();
			}
		
	}

	public static EnrollmentVO readEnrollmentVOFromFile(String planName, String fileName){
		ObjectInputStream ois = null;
		EnrollmentVO enrollmentVO = new EnrollmentVO();
		
		try {
			String filePath = "C:\\WEBAPP\\SHP\\SAVELOGOUT\\" + planName + "\\";
			ois = new ObjectInputStream(new FileInputStream(filePath+fileName));
			enrollmentVO = (EnrollmentVO) ois.readObject();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			if(ois != null){
				try {
					ois.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return enrollmentVO;
		
		
	}

	
	public static EnrollmentVO readEnrollmentVOFromFile(String filePath){
		
		
		ObjectInputStream ois = null;
		EnrollmentVO enrollmentVO = new EnrollmentVO();
		
		try {
			ois = new ObjectInputStream(new FileInputStream(filePath));
			enrollmentVO = (EnrollmentVO) ois.readObject();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			if(ois != null){
				try {
					ois.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return enrollmentVO;
		
		
	}


	/**
	 * @param date
	 * @return
	 * @throws ParseException
	 */
	public static Date formatDate() {

			try {
				
				Date todaysDate = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
				String dummyDate = sdf.format(todaysDate);
				Date dateBeforeConvert = new SimpleDateFormat("MM/dd/yyyy").parse(dummyDate);
				String convertedDate = new SimpleDateFormat("yyyy-MM-dd").format(dateBeforeConvert);
				Date dateAfterConvert = new SimpleDateFormat("yyyy-MM-dd").parse(convertedDate);				
				
				return dateAfterConvert;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}

		

	}	
	
	public static EnrollmentVO getSessionObject(String customerId, String planId, String emailId) {
		
		EnrollmentVO enrollmentVO = new EnrollmentVO();
		String sourceDirectory 	= "C:\\WEBAPP\\SHP\\SAVELOGOUT\\" + planId + "\\";
		String fileName 		= sourceDirectory + emailId;
		LOGGER.info("The File Datasource Name is :"+fileName);
		File currentFile = new File(fileName);
		
		
		if(currentFile.exists()){
			LOGGER.info("****User Session Exists****");
			enrollmentVO = readEnrollmentVOFromFile(fileName);
		}else{
			LOGGER.info("User Session Does not Exist !!");
			enrollmentVO = null;
		}
		
		return enrollmentVO;
	}
	
	public static boolean removeSessionObject(String customerId, String planId, String emailId) {
		
		EnrollmentVO enrollmentVO = new EnrollmentVO();
		String sourceDirectory 	= "C:\\WEBAPP\\SHP\\SAVELOGOUT\\" + planId + "\\";
		String fileName 		= sourceDirectory + emailId;
		LOGGER.info("The File Datasource Name is :"+fileName);
		File currentFile = new File(fileName);
		boolean fileDeleted = false;
		
		if(currentFile.exists()){
			
			LOGGER.info("****Removing the Stored User Session ****");
			fileDeleted = currentFile.delete();
			
		}else{
			LOGGER.info("User Session Does not Exist for Deletion !!");
			enrollmentVO = null;
		}
		
		return fileDeleted;
	}	
	
	
	public static void mapVOTOSessionSDAGC(EnrollmentVO enrollmentVO , HashMap<String, Object> sessionMap){
		sessionMap.put("sessionPrefix",enrollmentVO.getPrefix());
		sessionMap.put("sessionFirstName",enrollmentVO.getFirstName());
		sessionMap.put("sessionLastName",enrollmentVO.getLastName());
		sessionMap.put("sessionMiddleInitial",enrollmentVO.getMiddleInitial());
		sessionMap.put("sessionBirthDate",enrollmentVO.getBirthDate());
		sessionMap.put("sessionSex",enrollmentVO.getSex());
		sessionMap.put("sessionPrimaryPhone",enrollmentVO.getPrimaryPhone());
		sessionMap.put("sessionAlternatePhone",enrollmentVO.getCellPhone());
		sessionMap.put("sessionPermanentAddrStreet",enrollmentVO.getPermanentAddrStreet());
		sessionMap.put("sessionPermanentCity",enrollmentVO.getPermanentCity());
		sessionMap.put("sessionPermanentCounty",enrollmentVO.getPermanentCounty());
		sessionMap.put("sessionPermanentState",enrollmentVO.getPermanentState());
		sessionMap.put("sessionPermanentZip",enrollmentVO.getPermanentZip());
		sessionMap.put("sessionMailingAddressRequired",enrollmentVO.getMailingAddressRequired());
		sessionMap.put("sessionMailingAddr",enrollmentVO.getMailingAddr());
		sessionMap.put("sessionMailingCity",enrollmentVO.getMailingCity());
		sessionMap.put("sessionMailingState",enrollmentVO.getMailingState());
		sessionMap.put("sessionMailingZip",enrollmentVO.getMailingzip());
		sessionMap.put("sessionEmailAddr",enrollmentVO.getEmailAddr());
		sessionMap.put("sessionEmailAlert",enrollmentVO.getEmailAlert());
		
		String medicareClaim = enrollmentVO.getMedicareClaim();
		if(medicareClaim.length() > 3) {
			medicareClaim = medicareClaim.substring(0,3) + "-" + medicareClaim.substring(3);
		}
		if(medicareClaim.length() > 6) {
			medicareClaim = medicareClaim.substring(0,6) + "-" + medicareClaim.substring(6);
		}
		if(medicareClaim.length() > 11) {
			medicareClaim = medicareClaim.substring(0,11) + "-" + medicareClaim.substring(11);
		}
		
		sessionMap.put("sessionMedicareClaim",medicareClaim);
		
		sessionMap.put("sessionHospitalPartA",enrollmentVO.getHospitalPartA());
		sessionMap.put("sessionHospitalPartB",enrollmentVO.getHospitalPartB());
		sessionMap.put("sessionPaymentOption",enrollmentVO.getPaymentOption());
		sessionMap.put("sessionAccountHolderName",enrollmentVO.getAcctholdername());
		sessionMap.put("sessionBankName",enrollmentVO.getBankname());
		sessionMap.put("sessionAcctType",enrollmentVO.getAcctType());
		sessionMap.put("sessionRoutingNumber",enrollmentVO.getRoutingNumber());
		sessionMap.put("sessionAccountNumber",enrollmentVO.getAccountNumber());
		sessionMap.put("sessionMonthlyBillingFrequency",enrollmentVO.getMonthlybf());
		sessionMap.put("sessionRenalDisease",enrollmentVO.getRenalDisease());
		sessionMap.put("sessionESRDContact",enrollmentVO.getEsrdcontact());
		sessionMap.put("sessionVABenefits",enrollmentVO.getVaBenefits());
		sessionMap.put("sessionNameOfCoverage",enrollmentVO.getNameOfCov());
		sessionMap.put("sessionIdOfCoverage",enrollmentVO.getIdOfCov());
		sessionMap.put("sessionGroupOfCoverage",enrollmentVO.getGroupOfCov());
		sessionMap.put("sessionMedicaidPrg",enrollmentVO.getMedicaidprg());
		sessionMap.put("sessionMedicaidNbr",enrollmentVO.getMedicaidNbr());
		sessionMap.put("sessionPrescriptionDrug",enrollmentVO.getPrescriptionDrug());
		sessionMap.put("sessionNameOfInst",enrollmentVO.getNameOfInst());
		sessionMap.put("sessionPhoneOfInst",enrollmentVO.getPhoneOfInst());
		sessionMap.put("sessionAddressOfInst",enrollmentVO.getAddrOfInst());
		sessionMap.put("sessionSpouseWork",enrollmentVO.getSpousework());
		sessionMap.put("sessionPCPName",enrollmentVO.getPcpName());
		sessionMap.put("sessionPPCPMedicalGroupName",enrollmentVO.getPcpMedicalGroupName());
		sessionMap.put("sessionExistingPatient",enrollmentVO.getExistingp());
		sessionMap.put("sessionLanguage",enrollmentVO.getLanguage());
		sessionMap.put("sessionLanguageValue",enrollmentVO.getLanguageValue());
		sessionMap.put("sessionAep",enrollmentVO.getAep());
		sessionMap.put("sessionC1",enrollmentVO.getC1());
		sessionMap.put("sessionC2",enrollmentVO.getC2());
		sessionMap.put("sessionAttestation2",enrollmentVO.getAttestation2());
		sessionMap.put("sessionC3",enrollmentVO.getC3());
		sessionMap.put("sessionAttestation3",enrollmentVO.getAttestation3());
		sessionMap.put("sessionC4",enrollmentVO.getC4());
		sessionMap.put("sessionAttestation4",enrollmentVO.getAttestation4());
		sessionMap.put("sessionC5",enrollmentVO.getC5());
		sessionMap.put("sessionAttestation5",enrollmentVO.getAttestation5());
		sessionMap.put("sessionC6",enrollmentVO.getC6());
		sessionMap.put("sessionC7",enrollmentVO.getC7());
		sessionMap.put("sessionC8",enrollmentVO.getC8());
		sessionMap.put("sessionAttestation8",enrollmentVO.getAttestation8());
		sessionMap.put("sessionC9",enrollmentVO.getC9());
		sessionMap.put("sessionAttestation9",enrollmentVO.getAttestation9());
		sessionMap.put("sessionC10",enrollmentVO.getC10());
		sessionMap.put("sessionAttestation10",enrollmentVO.getAttestation10());
		sessionMap.put("sessionC11",enrollmentVO.getC11());
		sessionMap.put("sessionAttestation11",enrollmentVO.getAttestation11());
		sessionMap.put("sessionC12",enrollmentVO.getC12());
		sessionMap.put("sessionAttestation12",enrollmentVO.getAttestation12());
		sessionMap.put("sessionC13",enrollmentVO.getC13());
		sessionMap.put("sessionC14",enrollmentVO.getC14());
		sessionMap.put("sessionC15",enrollmentVO.getC15());
		sessionMap.put("sessionAttestation15",enrollmentVO.getAttestation15());
		sessionMap.put("sessionC16",enrollmentVO.getC16());
		sessionMap.put("sessionC16Attestation",enrollmentVO.getC16Attestation());
		sessionMap.put("sessionAttestation16",enrollmentVO.getAttestation16());
		sessionMap.put("sessionNameSignature",enrollmentVO.getNameSignature());
		sessionMap.put("sessionDigiSignature",enrollmentVO.getDigitalSignature());
		sessionMap.put("sessionTodaysDate",enrollmentVO.getTodaysDate());
		sessionMap.put("sessionAuthorizedRep",enrollmentVO.getAuthorizedRep());
		sessionMap.put("sessionAuthorizedRepName",enrollmentVO.getAuthorizedrepname());
		sessionMap.put("sessionAuthorizedRelationship",enrollmentVO.getAuthorizedreprelationship());
		sessionMap.put("sessionAuthorizedRepAddress",enrollmentVO.getAuthorizedrepaddress());
		sessionMap.put("sessionAuthorizedRepPhone",enrollmentVO.getAuthorizedrepphone());
		sessionMap.put("sessionAgentAssistingEnrollment",enrollmentVO.getAgentAssistingEnrollment());
		sessionMap.put("sessionNameOfAgent",enrollmentVO.getNameAgent());
		sessionMap.put("sessionAgentLicense",enrollmentVO.getAgentLicense());
		
		//Begin: 2019 web app changes - IFOX-00406768
		sessionMap.put("sessionC21",enrollmentVO.getC21());
		sessionMap.put("sessionC22",enrollmentVO.getC22());
		sessionMap.put("sessionAttestation22",enrollmentVO.getAttestation22());
		sessionMap.put("sessionC23",enrollmentVO.getC23());
		sessionMap.put("sessionAttestation23",enrollmentVO.getAttestation23());
		sessionMap.put("sessionC24",enrollmentVO.getC24());
		sessionMap.put("sessionAttestation24",enrollmentVO.getAttestation24());
		sessionMap.put("sessionC25",enrollmentVO.getC25());
		//End: 2019 web app changes - IFOX-00406768
		
	}
	public static void mapVOTOSessionSDAPC(EnrollmentVO enrollmentVO , HashMap<String, Object> sessionMap){
		sessionMap.put("sessionPrefix",enrollmentVO.getPrefix());
		sessionMap.put("sessionFirstName",enrollmentVO.getFirstName());
		sessionMap.put("sessionLastName",enrollmentVO.getLastName());
		sessionMap.put("sessionMiddleInitial",enrollmentVO.getMiddleInitial());
		sessionMap.put("sessionBirthDate",enrollmentVO.getBirthDate());
		sessionMap.put("sessionSex",enrollmentVO.getSex());
		sessionMap.put("sessionPrimaryPhone",enrollmentVO.getPrimaryPhone());
		sessionMap.put("sessionAlternatePhone",enrollmentVO.getCellPhone());
		sessionMap.put("sessionPermanentAddrStreet",enrollmentVO.getPermanentAddrStreet());
		sessionMap.put("sessionPermanentCity",enrollmentVO.getPermanentCity());
		sessionMap.put("sessionPermanentCounty",enrollmentVO.getPermanentCounty());
		sessionMap.put("sessionPermanentState",enrollmentVO.getPermanentState());
		sessionMap.put("sessionPermanentZip",enrollmentVO.getPermanentZip());
		sessionMap.put("sessionMailingAddressRequired",enrollmentVO.getMailingAddressRequired());
		sessionMap.put("sessionMailingAddr",enrollmentVO.getMailingAddr());
		sessionMap.put("sessionMailingCity",enrollmentVO.getMailingCity());
		sessionMap.put("sessionMailingState",enrollmentVO.getMailingState());
		sessionMap.put("sessionMailingZip",enrollmentVO.getMailingzip());
		sessionMap.put("sessionEmailAddr",enrollmentVO.getEmailAddr());
		sessionMap.put("sessionEmailAlert",enrollmentVO.getEmailAlert());
		
		String medicareClaim = enrollmentVO.getMedicareClaim();
		if(medicareClaim.length() > 3) {
			medicareClaim = medicareClaim.substring(0,3) + "-" + medicareClaim.substring(3);
		}
		if(medicareClaim.length() > 6) {
			medicareClaim = medicareClaim.substring(0,6) + "-" + medicareClaim.substring(6);
		}
		if(medicareClaim.length() > 11) {
			medicareClaim = medicareClaim.substring(0,11) + "-" + medicareClaim.substring(11);
		}
		
		sessionMap.put("sessionMedicareClaim",medicareClaim);
		
		sessionMap.put("sessionHospitalPartA",enrollmentVO.getHospitalPartA());
		sessionMap.put("sessionHospitalPartB",enrollmentVO.getHospitalPartB());
		sessionMap.put("sessionPaymentOption",enrollmentVO.getPaymentOption());
		sessionMap.put("sessionAccountHolderName",enrollmentVO.getAcctholdername());
		sessionMap.put("sessionBankName",enrollmentVO.getBankname());
		sessionMap.put("sessionAcctType",enrollmentVO.getAcctType());
		sessionMap.put("sessionRoutingNumber",enrollmentVO.getRoutingNumber());
		sessionMap.put("sessionAccountNumber",enrollmentVO.getAccountNumber());
		sessionMap.put("sessionMonthlyBillingFrequency",enrollmentVO.getMonthlybf());
		sessionMap.put("sessionRenalDisease",enrollmentVO.getRenalDisease());
		sessionMap.put("sessionESRDContact",enrollmentVO.getEsrdcontact());
		sessionMap.put("sessionVABenefits",enrollmentVO.getVaBenefits());
		sessionMap.put("sessionNameOfCoverage",enrollmentVO.getNameOfCov());
		sessionMap.put("sessionIdOfCoverage",enrollmentVO.getIdOfCov());
		sessionMap.put("sessionGroupOfCoverage",enrollmentVO.getGroupOfCov());
		sessionMap.put("sessionMedicaidPrg",enrollmentVO.getMedicaidprg());
		sessionMap.put("sessionMedicaidNbr",enrollmentVO.getMedicaidNbr());
		sessionMap.put("sessionPrescriptionDrug",enrollmentVO.getPrescriptionDrug());
		sessionMap.put("sessionNameOfInst",enrollmentVO.getNameOfInst());
		sessionMap.put("sessionPhoneOfInst",enrollmentVO.getPhoneOfInst());
		sessionMap.put("sessionAddressOfInst",enrollmentVO.getAddrOfInst());
		sessionMap.put("sessionSpouseWork",enrollmentVO.getSpousework());
		sessionMap.put("sessionPCPName",enrollmentVO.getPcpName());
		sessionMap.put("sessionPPCPMedicalGroupName",enrollmentVO.getPcpMedicalGroupName());
		sessionMap.put("sessionExistingPatient",enrollmentVO.getExistingp());
		sessionMap.put("sessionLanguage",enrollmentVO.getLanguage());
		sessionMap.put("sessionLanguageValue",enrollmentVO.getLanguageValue());
		sessionMap.put("sessionAep",enrollmentVO.getAep());
		sessionMap.put("sessionC1",enrollmentVO.getC1());
		sessionMap.put("sessionC2",enrollmentVO.getC2());
		sessionMap.put("sessionAttestation2",enrollmentVO.getAttestation2());
		sessionMap.put("sessionC3",enrollmentVO.getC3());
		sessionMap.put("sessionAttestation3",enrollmentVO.getAttestation3());
		sessionMap.put("sessionC4",enrollmentVO.getC4());
		sessionMap.put("sessionAttestation4",enrollmentVO.getAttestation4());
		sessionMap.put("sessionC5",enrollmentVO.getC5());
		sessionMap.put("sessionAttestation5",enrollmentVO.getAttestation5());
		sessionMap.put("sessionC6",enrollmentVO.getC6());
		sessionMap.put("sessionC7",enrollmentVO.getC7());
		sessionMap.put("sessionC8",enrollmentVO.getC8());
		sessionMap.put("sessionAttestation8",enrollmentVO.getAttestation8());
		sessionMap.put("sessionC9",enrollmentVO.getC9());
		sessionMap.put("sessionAttestation9",enrollmentVO.getAttestation9());
		sessionMap.put("sessionC10",enrollmentVO.getC10());
		sessionMap.put("sessionAttestation10",enrollmentVO.getAttestation10());
		sessionMap.put("sessionC11",enrollmentVO.getC11());
		sessionMap.put("sessionAttestation11",enrollmentVO.getAttestation11());
		sessionMap.put("sessionC12",enrollmentVO.getC12());
		sessionMap.put("sessionAttestation12",enrollmentVO.getAttestation12());
		sessionMap.put("sessionC13",enrollmentVO.getC13());
		sessionMap.put("sessionC14",enrollmentVO.getC14());
		sessionMap.put("sessionC15",enrollmentVO.getC15());
		sessionMap.put("sessionAttestation15",enrollmentVO.getAttestation15());
		sessionMap.put("sessionC16",enrollmentVO.getC16());
		sessionMap.put("sessionC16Attestation",enrollmentVO.getC16Attestation());		
		sessionMap.put("sessionAttestation16",enrollmentVO.getAttestation16());
		sessionMap.put("sessionNameSignature",enrollmentVO.getNameSignature());
		sessionMap.put("sessionDigiSignature",enrollmentVO.getDigitalSignature());
		sessionMap.put("sessionTodaysDate",enrollmentVO.getTodaysDate());
		sessionMap.put("sessionAuthorizedRep",enrollmentVO.getAuthorizedRep());
		sessionMap.put("sessionAuthorizedRepName",enrollmentVO.getAuthorizedrepname());
		sessionMap.put("sessionAuthorizedRelationship",enrollmentVO.getAuthorizedreprelationship());
		sessionMap.put("sessionAuthorizedRepAddress",enrollmentVO.getAuthorizedrepaddress());
		sessionMap.put("sessionAuthorizedRepPhone",enrollmentVO.getAuthorizedrepphone());
		sessionMap.put("sessionAgentAssistingEnrollment",enrollmentVO.getAgentAssistingEnrollment());
		sessionMap.put("sessionNameOfAgent",enrollmentVO.getNameAgent());
		sessionMap.put("sessionAgentLicense",enrollmentVO.getAgentLicense());
		
		//Begin: 2019 web app changes - IFOX-00406768
		sessionMap.put("sessionC21",enrollmentVO.getC21());
		sessionMap.put("sessionC22",enrollmentVO.getC22());
		sessionMap.put("sessionAttestation22",enrollmentVO.getAttestation22());
		sessionMap.put("sessionC23",enrollmentVO.getC23());
		sessionMap.put("sessionAttestation23",enrollmentVO.getAttestation23());
		sessionMap.put("sessionC24",enrollmentVO.getC24());
		sessionMap.put("sessionAttestation24",enrollmentVO.getAttestation24());
		sessionMap.put("sessionC25",enrollmentVO.getC25());
		//End: 2019 web app changes - IFOX-00406768
		
	}
	public static void mapVOTOSessionSAS(EnrollmentVO enrollmentVO , HashMap<String, Object> sessionMap){
		sessionMap.put("sessionPrefix",enrollmentVO.getPrefix());
		sessionMap.put("sessionFirstName",enrollmentVO.getFirstName());
		sessionMap.put("sessionLastName",enrollmentVO.getLastName());
		sessionMap.put("sessionMiddleInitial",enrollmentVO.getMiddleInitial());
		sessionMap.put("sessionBirthDate",enrollmentVO.getBirthDate());
		sessionMap.put("sessionSex",enrollmentVO.getSex());
		sessionMap.put("sessionPrimaryPhone",enrollmentVO.getPrimaryPhone());
		sessionMap.put("sessionAlternatePhone",enrollmentVO.getCellPhone());
		sessionMap.put("sessionPermanentAddrStreet",enrollmentVO.getPermanentAddrStreet());
		sessionMap.put("sessionPermanentCity",enrollmentVO.getPermanentCity());
		sessionMap.put("sessionPermanentCounty",enrollmentVO.getPermanentCounty());
		sessionMap.put("sessionPermanentState",enrollmentVO.getPermanentState());
		sessionMap.put("sessionPermanentZip",enrollmentVO.getPermanentZip());
		sessionMap.put("sessionMailingAddressRequired",enrollmentVO.getMailingAddressRequired());
		sessionMap.put("sessionMailingAddr",enrollmentVO.getMailingAddr());
		sessionMap.put("sessionMailingCity",enrollmentVO.getMailingCity());
		sessionMap.put("sessionMailingState",enrollmentVO.getMailingState());
		sessionMap.put("sessionMailingZip",enrollmentVO.getMailingzip());
		sessionMap.put("sessionEmailAddr",enrollmentVO.getEmailAddr());
		sessionMap.put("sessionCallAlert",enrollmentVO.getCallAlert());
		sessionMap.put("sessionEmailAlert",enrollmentVO.getEmailAlert());
		
		String medicareClaim = enrollmentVO.getMedicareClaim();
		if(medicareClaim.length() > 3) {
			medicareClaim = medicareClaim.substring(0,3) + "-" + medicareClaim.substring(3);
		}
		if(medicareClaim.length() > 6) {
			medicareClaim = medicareClaim.substring(0,6) + "-" + medicareClaim.substring(6);
		}
		if(medicareClaim.length() > 11) {
			medicareClaim = medicareClaim.substring(0,11) + "-" + medicareClaim.substring(11);
		}
		
		sessionMap.put("sessionMedicareClaim",medicareClaim);
		
		sessionMap.put("sessionHospitalPartA",enrollmentVO.getHospitalPartA());
		sessionMap.put("sessionHospitalPartB",enrollmentVO.getHospitalPartB());
		sessionMap.put("sessionPaymentOption",enrollmentVO.getPaymentOption());
		sessionMap.put("sessionRenalDisease",enrollmentVO.getRenalDisease());
		sessionMap.put("sessionESRDContact",enrollmentVO.getEsrdcontact());
		sessionMap.put("sessionVABenefits",enrollmentVO.getVaBenefits());
		sessionMap.put("sessionNameOfCoverage",enrollmentVO.getNameOfCov());
		sessionMap.put("sessionIdOfCoverage",enrollmentVO.getIdOfCov());
		sessionMap.put("sessionGroupOfCoverage",enrollmentVO.getGroupOfCov());
		sessionMap.put("sessionMedicaidPrg",enrollmentVO.getMedicaidprg());
		sessionMap.put("sessionMedicaidNbr",enrollmentVO.getMedicaidNbr());
		sessionMap.put("sessionPrescriptionDrug",enrollmentVO.getPrescriptionDrug());
		sessionMap.put("sessionNameOfInst",enrollmentVO.getNameOfInst());
		sessionMap.put("sessionPhoneOfInst",enrollmentVO.getPhoneOfInst());
		sessionMap.put("sessionAddressOfInst",enrollmentVO.getAddrOfInst());
		sessionMap.put("sessionSpouseWork",enrollmentVO.getSpousework());
		sessionMap.put("sessionPCPName",enrollmentVO.getPcpName());
		sessionMap.put("sessionPPCPMedicalGroupName",enrollmentVO.getPcpMedicalGroupName());
		sessionMap.put("sessionLanguage",enrollmentVO.getLanguage());
		sessionMap.put("sessionLanguageValue",enrollmentVO.getLanguageValue());
		sessionMap.put("sessionAep",enrollmentVO.getAep());
		sessionMap.put("sessionC1",enrollmentVO.getC1());
		sessionMap.put("sessionC2",enrollmentVO.getC2());
		sessionMap.put("sessionAttestation2",enrollmentVO.getAttestation2());
		sessionMap.put("sessionC3",enrollmentVO.getC3());
		sessionMap.put("sessionAttestation3",enrollmentVO.getAttestation3());
		sessionMap.put("sessionC4",enrollmentVO.getC4());
		sessionMap.put("sessionAttestation4",enrollmentVO.getAttestation4());
		sessionMap.put("sessionC5",enrollmentVO.getC5());
		sessionMap.put("sessionAttestation5",enrollmentVO.getAttestation5());
		sessionMap.put("sessionC6",enrollmentVO.getC6());
		sessionMap.put("sessionC7",enrollmentVO.getC7());
		sessionMap.put("sessionC8",enrollmentVO.getC8());
		sessionMap.put("sessionAttestation8",enrollmentVO.getAttestation8());
		sessionMap.put("sessionC9",enrollmentVO.getC9());
		sessionMap.put("sessionAttestation9",enrollmentVO.getAttestation9());
		sessionMap.put("sessionC10",enrollmentVO.getC10());
		sessionMap.put("sessionAttestation10",enrollmentVO.getAttestation10());
		sessionMap.put("sessionC11",enrollmentVO.getC11());
		sessionMap.put("sessionAttestation11",enrollmentVO.getAttestation11());
		sessionMap.put("sessionC12",enrollmentVO.getC12());
		sessionMap.put("sessionAttestation12",enrollmentVO.getAttestation12());
		sessionMap.put("sessionC13",enrollmentVO.getC13());
		sessionMap.put("sessionC14",enrollmentVO.getC14());
		sessionMap.put("sessionC15",enrollmentVO.getC15());
		sessionMap.put("sessionAttestation15",enrollmentVO.getAttestation15());
		sessionMap.put("sessionC16",enrollmentVO.getC16());
		sessionMap.put("sessionC16Attestation",enrollmentVO.getC16Attestation());		
		sessionMap.put("sessionAttestation16",enrollmentVO.getAttestation16());
		sessionMap.put("sessionNameSignature",enrollmentVO.getNameSignature());
		sessionMap.put("sessionDigiSignature",enrollmentVO.getDigitalSignature());
		sessionMap.put("sessionTodaysDate",enrollmentVO.getTodaysDate());
		sessionMap.put("sessionAuthorizedRep",enrollmentVO.getAuthorizedRep());
		sessionMap.put("sessionAuthorizedRepName",enrollmentVO.getAuthorizedrepname());
		sessionMap.put("sessionAuthorizedRelationship",enrollmentVO.getAuthorizedreprelationship());
		sessionMap.put("sessionAuthorizedRepAddress",enrollmentVO.getAuthorizedrepaddress());
		sessionMap.put("sessionAuthorizedRepPhone",enrollmentVO.getAuthorizedrepphone());
		sessionMap.put("sessionAgentAssistingEnrollment",enrollmentVO.getAgentAssistingEnrollment());
		sessionMap.put("sessionNameOfAgent",enrollmentVO.getNameAgent());
		sessionMap.put("sessionAgentLicense",enrollmentVO.getAgentLicense());
		
		//Begin: 2019 web app changes - IFOX-00406768
		sessionMap.put("sessionC21",enrollmentVO.getC21());
		sessionMap.put("sessionC22",enrollmentVO.getC22());
		sessionMap.put("sessionAttestation22",enrollmentVO.getAttestation22());
		sessionMap.put("sessionC23",enrollmentVO.getC23());
		sessionMap.put("sessionAttestation23",enrollmentVO.getAttestation23());
		sessionMap.put("sessionC24",enrollmentVO.getC24());
		sessionMap.put("sessionAttestation24",enrollmentVO.getAttestation24());
		sessionMap.put("sessionC25",enrollmentVO.getC25());
		//End: 2019 web app changes - IFOX-00406768
		
	}
	public static void mapVOTOSessionSASP(EnrollmentVO enrollmentVO , HashMap<String, Object> sessionMap){
		sessionMap.put("sessionPrefix",enrollmentVO.getPrefix());
		sessionMap.put("sessionFirstName",enrollmentVO.getFirstName());
		sessionMap.put("sessionLastName",enrollmentVO.getLastName());
		sessionMap.put("sessionMiddleInitial",enrollmentVO.getMiddleInitial());
		sessionMap.put("sessionBirthDate",enrollmentVO.getBirthDate());
		sessionMap.put("sessionSex",enrollmentVO.getSex());
		sessionMap.put("sessionPrimaryPhone",enrollmentVO.getPrimaryPhone());
		sessionMap.put("sessionAlternatePhone",enrollmentVO.getCellPhone());
		sessionMap.put("sessionPermanentAddrStreet",enrollmentVO.getPermanentAddrStreet());
		sessionMap.put("sessionPermanentCity",enrollmentVO.getPermanentCity());
		sessionMap.put("sessionPermanentCounty",enrollmentVO.getPermanentCounty());
		sessionMap.put("sessionPermanentState",enrollmentVO.getPermanentState());
		sessionMap.put("sessionPermanentZip",enrollmentVO.getPermanentZip());
		sessionMap.put("sessionMailingAddressRequired",enrollmentVO.getMailingAddressRequired());
		sessionMap.put("sessionMailingAddr",enrollmentVO.getMailingAddr());
		sessionMap.put("sessionMailingCity",enrollmentVO.getMailingCity());
		sessionMap.put("sessionMailingState",enrollmentVO.getMailingState());
		sessionMap.put("sessionMailingZip",enrollmentVO.getMailingzip());
		sessionMap.put("sessionEmailAddr",enrollmentVO.getEmailAddr());
		sessionMap.put("sessionCallAlert",enrollmentVO.getCallAlert());
		sessionMap.put("sessionEmailAlert",enrollmentVO.getEmailAlert());
		
		String medicareClaim = enrollmentVO.getMedicareClaim();
		if(medicareClaim.length() > 3) {
			medicareClaim = medicareClaim.substring(0,3) + "-" + medicareClaim.substring(3);
		}
		if(medicareClaim.length() > 6) {
			medicareClaim = medicareClaim.substring(0,6) + "-" + medicareClaim.substring(6);
		}
		if(medicareClaim.length() > 11) {
			medicareClaim = medicareClaim.substring(0,11) + "-" + medicareClaim.substring(11);
		}
		
		sessionMap.put("sessionMedicareClaim",medicareClaim);
		
		sessionMap.put("sessionHospitalPartA",enrollmentVO.getHospitalPartA());
		sessionMap.put("sessionHospitalPartB",enrollmentVO.getHospitalPartB());
		sessionMap.put("sessionPaymentOption",enrollmentVO.getPaymentOption());
		sessionMap.put("sessionRenalDisease",enrollmentVO.getRenalDisease());
		sessionMap.put("sessionESRDContact",enrollmentVO.getEsrdcontact());
		sessionMap.put("sessionVABenefits",enrollmentVO.getVaBenefits());
		sessionMap.put("sessionNameOfCoverage",enrollmentVO.getNameOfCov());
		sessionMap.put("sessionIdOfCoverage",enrollmentVO.getIdOfCov());
		sessionMap.put("sessionGroupOfCoverage",enrollmentVO.getGroupOfCov());
		sessionMap.put("sessionMedicaidPrg",enrollmentVO.getMedicaidprg());
		sessionMap.put("sessionMedicaidNbr",enrollmentVO.getMedicaidNbr());
		sessionMap.put("sessionPrescriptionDrug",enrollmentVO.getPrescriptionDrug());
		sessionMap.put("sessionNameOfInst",enrollmentVO.getNameOfInst());
		sessionMap.put("sessionPhoneOfInst",enrollmentVO.getPhoneOfInst());
		sessionMap.put("sessionAddressOfInst",enrollmentVO.getAddrOfInst());
		sessionMap.put("sessionSpouseWork",enrollmentVO.getSpousework());
		sessionMap.put("sessionPCPName",enrollmentVO.getPcpName());
		sessionMap.put("sessionPPCPMedicalGroupName",enrollmentVO.getPcpMedicalGroupName());
		sessionMap.put("sessionLanguage",enrollmentVO.getLanguage());
		sessionMap.put("sessionLanguageValue",enrollmentVO.getLanguageValue());
		sessionMap.put("sessionAep",enrollmentVO.getAep());
		sessionMap.put("sessionC1",enrollmentVO.getC1());
		sessionMap.put("sessionC2",enrollmentVO.getC2());
		sessionMap.put("sessionAttestation2",enrollmentVO.getAttestation2());
		sessionMap.put("sessionC3",enrollmentVO.getC3());
		sessionMap.put("sessionAttestation3",enrollmentVO.getAttestation3());
		sessionMap.put("sessionC4",enrollmentVO.getC4());
		sessionMap.put("sessionAttestation4",enrollmentVO.getAttestation4());
		sessionMap.put("sessionC5",enrollmentVO.getC5());
		sessionMap.put("sessionAttestation5",enrollmentVO.getAttestation5());
		sessionMap.put("sessionC6",enrollmentVO.getC6());
		sessionMap.put("sessionC7",enrollmentVO.getC7());
		sessionMap.put("sessionC8",enrollmentVO.getC8());
		sessionMap.put("sessionAttestation8",enrollmentVO.getAttestation8());
		sessionMap.put("sessionC9",enrollmentVO.getC9());
		sessionMap.put("sessionAttestation9",enrollmentVO.getAttestation9());
		sessionMap.put("sessionC10",enrollmentVO.getC10());
		sessionMap.put("sessionAttestation10",enrollmentVO.getAttestation10());
		sessionMap.put("sessionC11",enrollmentVO.getC11());
		sessionMap.put("sessionAttestation11",enrollmentVO.getAttestation11());
		sessionMap.put("sessionC12",enrollmentVO.getC12());
		sessionMap.put("sessionAttestation12",enrollmentVO.getAttestation12());
		sessionMap.put("sessionC13",enrollmentVO.getC13());
		sessionMap.put("sessionC14",enrollmentVO.getC14());
		sessionMap.put("sessionC15",enrollmentVO.getC15());
		sessionMap.put("sessionAttestation15",enrollmentVO.getAttestation15());
		sessionMap.put("sessionC16",enrollmentVO.getC16());
		sessionMap.put("sessionC16Attestation",enrollmentVO.getC16Attestation());		
		sessionMap.put("sessionAttestation16",enrollmentVO.getAttestation16());
		sessionMap.put("sessionNameSignature",enrollmentVO.getNameSignature());
		sessionMap.put("sessionDigiSignature",enrollmentVO.getDigitalSignature());
		sessionMap.put("sessionTodaysDate",enrollmentVO.getTodaysDate());
		sessionMap.put("sessionAuthorizedRep",enrollmentVO.getAuthorizedRep());
		sessionMap.put("sessionAuthorizedRepName",enrollmentVO.getAuthorizedrepname());
		sessionMap.put("sessionAuthorizedRelationship",enrollmentVO.getAuthorizedreprelationship());
		sessionMap.put("sessionAuthorizedRepAddress",enrollmentVO.getAuthorizedrepaddress());
		sessionMap.put("sessionAuthorizedRepPhone",enrollmentVO.getAuthorizedrepphone());
		sessionMap.put("sessionAgentAssistingEnrollment",enrollmentVO.getAgentAssistingEnrollment());
		sessionMap.put("sessionNameOfAgent",enrollmentVO.getNameAgent());
		sessionMap.put("sessionAgentLicense",enrollmentVO.getAgentLicense());
		
		//Begin: 2019 web app changes - IFOX-00406768
		sessionMap.put("sessionC21",enrollmentVO.getC21());
		sessionMap.put("sessionC22",enrollmentVO.getC22());
		sessionMap.put("sessionAttestation22",enrollmentVO.getAttestation22());
		sessionMap.put("sessionC23",enrollmentVO.getC23());
		sessionMap.put("sessionAttestation23",enrollmentVO.getAttestation23());
		sessionMap.put("sessionC24",enrollmentVO.getC24());
		sessionMap.put("sessionAttestation24",enrollmentVO.getAttestation24());
		sessionMap.put("sessionC25",enrollmentVO.getC25());
		//End: 2019 web app changes - IFOX-00406768
		
	}	
	public static void mapVOTOSessionSAB(EnrollmentVO enrollmentVO , HashMap<String, Object> sessionMap){
		sessionMap.put("sessionPrefix",enrollmentVO.getPrefix());
		sessionMap.put("sessionFirstName",enrollmentVO.getFirstName());
		sessionMap.put("sessionLastName",enrollmentVO.getLastName());
		sessionMap.put("sessionMiddleInitial",enrollmentVO.getMiddleInitial());
		sessionMap.put("sessionBirthDate",enrollmentVO.getBirthDate());
		sessionMap.put("sessionSex",enrollmentVO.getSex());
		sessionMap.put("sessionPrimaryPhone",enrollmentVO.getPrimaryPhone());
		sessionMap.put("sessionAlternatePhone",enrollmentVO.getCellPhone());
		sessionMap.put("sessionPermanentAddrStreet",enrollmentVO.getPermanentAddrStreet());
		sessionMap.put("sessionPermanentCity",enrollmentVO.getPermanentCity());
		sessionMap.put("sessionPermanentCounty",enrollmentVO.getPermanentCounty());
		sessionMap.put("sessionPermanentState",enrollmentVO.getPermanentState());
		sessionMap.put("sessionPermanentZip",enrollmentVO.getPermanentZip());
		sessionMap.put("sessionMailingAddressRequired",enrollmentVO.getMailingAddressRequired());
		sessionMap.put("sessionMailingAddr",enrollmentVO.getMailingAddr());
		sessionMap.put("sessionMailingCity",enrollmentVO.getMailingCity());
		sessionMap.put("sessionMailingState",enrollmentVO.getMailingState());
		sessionMap.put("sessionMailingZip",enrollmentVO.getMailingzip());
		sessionMap.put("sessionEmailAddr",enrollmentVO.getEmailAddr());
		sessionMap.put("sessionCallAlert",enrollmentVO.getCallAlert());
		sessionMap.put("sessionEmailAlert",enrollmentVO.getEmailAlert());
		
		String medicareClaim = enrollmentVO.getMedicareClaim();
		if(medicareClaim.length() > 3) {
			medicareClaim = medicareClaim.substring(0,3) + "-" + medicareClaim.substring(3);
		}
		if(medicareClaim.length() > 6) {
			medicareClaim = medicareClaim.substring(0,6) + "-" + medicareClaim.substring(6);
		}
		if(medicareClaim.length() > 11) {
			medicareClaim = medicareClaim.substring(0,11) + "-" + medicareClaim.substring(11);
		}
		
		sessionMap.put("sessionMedicareClaim",medicareClaim);
		
		sessionMap.put("sessionHospitalPartA",enrollmentVO.getHospitalPartA());
		sessionMap.put("sessionHospitalPartB",enrollmentVO.getHospitalPartB());
		sessionMap.put("sessionPaymentOption",enrollmentVO.getPaymentOption());		
		sessionMap.put("sessionMonthlyBillingFrequency",enrollmentVO.getMonthlybf());
		sessionMap.put("sessionRetiree",enrollmentVO.getRetiree());
		
		//Begin: Modified for IFOX-00414491
		sessionMap.put("sessionCoveringSpouseOrDependent",enrollmentVO.getCoveringSpouseOrDependent());
		sessionMap.put("sessionCoveringSpouseOrDependentLastName",enrollmentVO.getCoveringSpouseOrDependentLastName());
		sessionMap.put("sessionCoveringSpouseOrDependentFirstName",enrollmentVO.getCoveringSpouseOrDependentFirstName());
		sessionMap.put("sessionCoveringSpouseOrDependentMiddleName",enrollmentVO.getCoveringSpouseOrDependentMiddleName());
		sessionMap.put("sessionCoveringSpouseOrDependentEmployeeName",enrollmentVO.getCoveringSpouseOrDependentEmployeeName());
		
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetiree",enrollmentVO.getSurvivingSpouseCitySanDiegoRetiree());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeLastName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeLastName());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeFirstName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeFirstName());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeMiddleName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeMiddleName());
		//End: Modified for IFOX-00414491
		
		sessionMap.put("sessionRetiredate",enrollmentVO.getRetiredate());
		sessionMap.put("sessionRetirename",enrollmentVO.getRetirename());
		sessionMap.put("sessionMeddependsp",enrollmentVO.getMeddependsp());
		sessionMap.put("sessionDependentSpouse",enrollmentVO.getDependentSpouse());
		sessionMap.put("sessionDependentOther",enrollmentVO.getDependentOther());
		sessionMap.put("sessionSpouseWork",enrollmentVO.getSpousework());		
		sessionMap.put("sessionRenalDisease",enrollmentVO.getRenalDisease());
		sessionMap.put("sessionESRDContact",enrollmentVO.getEsrdcontact());
		sessionMap.put("sessionVABenefits",enrollmentVO.getVaBenefits());
		sessionMap.put("sessionNameOfCoverage",enrollmentVO.getNameOfCov());
		sessionMap.put("sessionIdOfCoverage",enrollmentVO.getIdOfCov());
		sessionMap.put("sessionGroupOfCoverage",enrollmentVO.getGroupOfCov());
		sessionMap.put("sessionMedicaidPrg",enrollmentVO.getMedicaidprg());
		sessionMap.put("sessionMedicaidNbr",enrollmentVO.getMedicaidNbr());
		sessionMap.put("sessionPrescriptionDrug",enrollmentVO.getPrescriptionDrug());
		sessionMap.put("sessionNameOfInst",enrollmentVO.getNameOfInst());
		sessionMap.put("sessionPhoneOfInst",enrollmentVO.getPhoneOfInst());
		sessionMap.put("sessionAddressOfInst",enrollmentVO.getAddrOfInst());
		sessionMap.put("sessionExistingPatient",enrollmentVO.getExistingp());		
		sessionMap.put("sessionPCPName",enrollmentVO.getPcpName());
		sessionMap.put("sessionPPCPMedicalGroupName",enrollmentVO.getPcpMedicalGroupName());
		sessionMap.put("sessionLanguage",enrollmentVO.getLanguage());
		sessionMap.put("sessionLanguageValue",enrollmentVO.getLanguageValue());
		sessionMap.put("sessionC20",enrollmentVO.getC20());
		sessionMap.put("sessionC1",enrollmentVO.getC1());
		sessionMap.put("sessionC2",enrollmentVO.getC2());
		sessionMap.put("sessionAttestation2",enrollmentVO.getAttestation2());
		sessionMap.put("sessionC3",enrollmentVO.getC3());
		sessionMap.put("sessionAttestation3",enrollmentVO.getAttestation3());
		sessionMap.put("sessionC4",enrollmentVO.getC4());
		sessionMap.put("sessionAttestation4",enrollmentVO.getAttestation4());
		sessionMap.put("sessionC5",enrollmentVO.getC5());
		sessionMap.put("sessionAttestation5",enrollmentVO.getAttestation5());
		sessionMap.put("sessionC6",enrollmentVO.getC6());
		sessionMap.put("sessionC7",enrollmentVO.getC7());
		sessionMap.put("sessionC8",enrollmentVO.getC8());
		sessionMap.put("sessionAttestation8",enrollmentVO.getAttestation8());
		sessionMap.put("sessionC9",enrollmentVO.getC9());
		sessionMap.put("sessionAttestation9",enrollmentVO.getAttestation9());
		sessionMap.put("sessionC10",enrollmentVO.getC10());
		sessionMap.put("sessionAttestation10",enrollmentVO.getAttestation10());
		sessionMap.put("sessionC11",enrollmentVO.getC11());
		sessionMap.put("sessionAttestation11",enrollmentVO.getAttestation11());
		sessionMap.put("sessionC12",enrollmentVO.getC12());
		sessionMap.put("sessionAttestation12",enrollmentVO.getAttestation12());
		sessionMap.put("sessionC13",enrollmentVO.getC13());
		sessionMap.put("sessionC14",enrollmentVO.getC14());
		sessionMap.put("sessionC15",enrollmentVO.getC15());
		sessionMap.put("sessionAttestation15",enrollmentVO.getAttestation15());
		sessionMap.put("sessionC16",enrollmentVO.getC16());
		sessionMap.put("sessionC16Attestation",enrollmentVO.getC16Attestation());		
		sessionMap.put("sessionAttestation16",enrollmentVO.getAttestation16());
		sessionMap.put("sessionNameSignature",enrollmentVO.getNameSignature());
		sessionMap.put("sessionDigiSignature",enrollmentVO.getDigitalSignature());
		sessionMap.put("sessionTodaysDate",enrollmentVO.getTodaysDate());
		sessionMap.put("sessionAuthorizedRep",enrollmentVO.getAuthorizedRep());
		sessionMap.put("sessionAuthorizedRepName",enrollmentVO.getAuthorizedrepname());
		sessionMap.put("sessionAuthorizedRelationship",enrollmentVO.getAuthorizedreprelationship());
		sessionMap.put("sessionAuthorizedRepAddress",enrollmentVO.getAuthorizedrepaddress());
		sessionMap.put("sessionAuthorizedRepPhone",enrollmentVO.getAuthorizedrepphone());
		sessionMap.put("sessionAgentAssistingEnrollment",enrollmentVO.getAgentAssistingEnrollment());
		sessionMap.put("sessionNameOfAgent",enrollmentVO.getNameAgent());
		sessionMap.put("sessionAgentLicense",enrollmentVO.getAgentLicense());
		
		//Begin: 2019 web app changes - IFOX-00406768
		sessionMap.put("sessionC21",enrollmentVO.getC21());
		sessionMap.put("sessionC22",enrollmentVO.getC22());
		sessionMap.put("sessionAttestation22",enrollmentVO.getAttestation22());
		sessionMap.put("sessionC23",enrollmentVO.getC23());
		sessionMap.put("sessionAttestation23",enrollmentVO.getAttestation23());
		sessionMap.put("sessionC24",enrollmentVO.getC24());
		sessionMap.put("sessionAttestation24",enrollmentVO.getAttestation24());
		sessionMap.put("sessionC25",enrollmentVO.getC25());
		//End: 2019 web app changes - IFOX-00406768
		
	}	
	public static void mapVOTOSessionSAP(EnrollmentVO enrollmentVO , HashMap<String, Object> sessionMap){
		sessionMap.put("sessionPrefix",enrollmentVO.getPrefix());
		sessionMap.put("sessionFirstName",enrollmentVO.getFirstName());
		sessionMap.put("sessionLastName",enrollmentVO.getLastName());
		sessionMap.put("sessionMiddleInitial",enrollmentVO.getMiddleInitial());
		sessionMap.put("sessionBirthDate",enrollmentVO.getBirthDate());
		sessionMap.put("sessionSex",enrollmentVO.getSex());
		sessionMap.put("sessionPrimaryPhone",enrollmentVO.getPrimaryPhone());
		sessionMap.put("sessionAlternatePhone",enrollmentVO.getCellPhone());
		sessionMap.put("sessionPermanentAddrStreet",enrollmentVO.getPermanentAddrStreet());
		sessionMap.put("sessionPermanentCity",enrollmentVO.getPermanentCity());
		sessionMap.put("sessionPermanentCounty",enrollmentVO.getPermanentCounty());
		sessionMap.put("sessionPermanentState",enrollmentVO.getPermanentState());
		sessionMap.put("sessionPermanentZip",enrollmentVO.getPermanentZip());
		sessionMap.put("sessionMailingAddressRequired",enrollmentVO.getMailingAddressRequired());
		sessionMap.put("sessionMailingAddr",enrollmentVO.getMailingAddr());
		sessionMap.put("sessionMailingCity",enrollmentVO.getMailingCity());
		sessionMap.put("sessionMailingState",enrollmentVO.getMailingState());
		sessionMap.put("sessionMailingZip",enrollmentVO.getMailingzip());
		sessionMap.put("sessionEmailAddr",enrollmentVO.getEmailAddr());
		sessionMap.put("sessionCallAlert",enrollmentVO.getCallAlert());
		sessionMap.put("sessionEmailAlert",enrollmentVO.getEmailAlert());
		
		String medicareClaim = enrollmentVO.getMedicareClaim();
		if(medicareClaim.length() > 3) {
			medicareClaim = medicareClaim.substring(0,3) + "-" + medicareClaim.substring(3);
		}
		if(medicareClaim.length() > 6) {
			medicareClaim = medicareClaim.substring(0,6) + "-" + medicareClaim.substring(6);
		}
		if(medicareClaim.length() > 11) {
			medicareClaim = medicareClaim.substring(0,11) + "-" + medicareClaim.substring(11);
		}
		
		sessionMap.put("sessionMedicareClaim",medicareClaim);
		
		sessionMap.put("sessionHospitalPartA",enrollmentVO.getHospitalPartA());
		sessionMap.put("sessionHospitalPartB",enrollmentVO.getHospitalPartB());
		sessionMap.put("sessionPaymentOption",enrollmentVO.getPaymentOption());
		sessionMap.put("sessionMonthlyBillingFrequency",enrollmentVO.getMonthlybf());
		sessionMap.put("sessionRetiree",enrollmentVO.getRetiree());
		
		//Begin: Modified for IFOX-00414491
		sessionMap.put("sessionCoveringSpouseOrDependent",enrollmentVO.getCoveringSpouseOrDependent());
		sessionMap.put("sessionCoveringSpouseOrDependentLastName",enrollmentVO.getCoveringSpouseOrDependentLastName());
		sessionMap.put("sessionCoveringSpouseOrDependentFirstName",enrollmentVO.getCoveringSpouseOrDependentFirstName());
		sessionMap.put("sessionCoveringSpouseOrDependentMiddleName",enrollmentVO.getCoveringSpouseOrDependentMiddleName());
		sessionMap.put("sessionCoveringSpouseOrDependentEmployeeName",enrollmentVO.getCoveringSpouseOrDependentEmployeeName());
		
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetiree",enrollmentVO.getSurvivingSpouseCitySanDiegoRetiree());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeLastName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeLastName());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeFirstName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeFirstName());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeMiddleName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeMiddleName());
		//End: Modified for IFOX-00414491
		
		sessionMap.put("sessionRetiredate",enrollmentVO.getRetiredate());
		sessionMap.put("sessionRetirename",enrollmentVO.getRetirename());
		sessionMap.put("sessionMeddependsp",enrollmentVO.getMeddependsp());
		sessionMap.put("sessionDependentSpouse",enrollmentVO.getDependentSpouse());
		sessionMap.put("sessionDependentOther",enrollmentVO.getDependentOther());
		sessionMap.put("sessionSpouseWork",enrollmentVO.getSpousework());		
		sessionMap.put("sessionRenalDisease",enrollmentVO.getRenalDisease());
		sessionMap.put("sessionESRDContact",enrollmentVO.getEsrdcontact());
		sessionMap.put("sessionVABenefits",enrollmentVO.getVaBenefits());
		sessionMap.put("sessionNameOfCoverage",enrollmentVO.getNameOfCov());
		sessionMap.put("sessionIdOfCoverage",enrollmentVO.getIdOfCov());
		sessionMap.put("sessionGroupOfCoverage",enrollmentVO.getGroupOfCov());
		sessionMap.put("sessionPrescriptionDrug",enrollmentVO.getPrescriptionDrug());
		sessionMap.put("sessionNameOfInst",enrollmentVO.getNameOfInst());
		sessionMap.put("sessionPhoneOfInst",enrollmentVO.getPhoneOfInst());
		sessionMap.put("sessionAddressOfInst",enrollmentVO.getAddrOfInst());
		sessionMap.put("sessionExistingPatient",enrollmentVO.getExistingp());		
		sessionMap.put("sessionPCPName",enrollmentVO.getPcpName());
		sessionMap.put("sessionPPCPMedicalGroupName",enrollmentVO.getPcpMedicalGroupName());
		sessionMap.put("sessionLanguage",enrollmentVO.getLanguage());
		sessionMap.put("sessionLanguageValue",enrollmentVO.getLanguageValue());
		sessionMap.put("sessionC20",enrollmentVO.getC20());
		sessionMap.put("sessionC1",enrollmentVO.getC1());
		sessionMap.put("sessionC2",enrollmentVO.getC2());
		sessionMap.put("sessionAttestation2",enrollmentVO.getAttestation2());
		sessionMap.put("sessionC3",enrollmentVO.getC3());
		sessionMap.put("sessionAttestation3",enrollmentVO.getAttestation3());
		sessionMap.put("sessionC4",enrollmentVO.getC4());
		sessionMap.put("sessionAttestation4",enrollmentVO.getAttestation4());
		sessionMap.put("sessionC5",enrollmentVO.getC5());
		sessionMap.put("sessionAttestation5",enrollmentVO.getAttestation5());
		sessionMap.put("sessionC6",enrollmentVO.getC6());
		sessionMap.put("sessionC7",enrollmentVO.getC7());
		sessionMap.put("sessionC8",enrollmentVO.getC8());
		sessionMap.put("sessionAttestation8",enrollmentVO.getAttestation8());
		sessionMap.put("sessionC9",enrollmentVO.getC9());
		sessionMap.put("sessionAttestation9",enrollmentVO.getAttestation9());
		sessionMap.put("sessionC10",enrollmentVO.getC10());
		sessionMap.put("sessionAttestation10",enrollmentVO.getAttestation10());
		sessionMap.put("sessionC11",enrollmentVO.getC11());
		sessionMap.put("sessionAttestation11",enrollmentVO.getAttestation11());
		sessionMap.put("sessionC12",enrollmentVO.getC12());
		sessionMap.put("sessionAttestation12",enrollmentVO.getAttestation12());
		sessionMap.put("sessionC13",enrollmentVO.getC13());
		sessionMap.put("sessionC14",enrollmentVO.getC14());
		sessionMap.put("sessionC15",enrollmentVO.getC15());
		sessionMap.put("sessionAttestation15",enrollmentVO.getAttestation15());
		sessionMap.put("sessionC16",enrollmentVO.getC16());
		sessionMap.put("sessionC16Attestation",enrollmentVO.getC16Attestation());		
		sessionMap.put("sessionAttestation16",enrollmentVO.getAttestation16());
		sessionMap.put("sessionNameSignature",enrollmentVO.getNameSignature());
		sessionMap.put("sessionDigiSignature",enrollmentVO.getDigitalSignature());
		sessionMap.put("sessionTodaysDate",enrollmentVO.getTodaysDate());
		sessionMap.put("sessionAuthorizedRep",enrollmentVO.getAuthorizedRep());
		sessionMap.put("sessionAuthorizedRepName",enrollmentVO.getAuthorizedrepname());
		sessionMap.put("sessionAuthorizedRelationship",enrollmentVO.getAuthorizedreprelationship());
		sessionMap.put("sessionAuthorizedRepAddress",enrollmentVO.getAuthorizedrepaddress());
		sessionMap.put("sessionAuthorizedRepPhone",enrollmentVO.getAuthorizedrepphone());
		sessionMap.put("sessionAgentAssistingEnrollment",enrollmentVO.getAgentAssistingEnrollment());
		sessionMap.put("sessionNameOfAgent",enrollmentVO.getNameAgent());
		sessionMap.put("sessionAgentLicense",enrollmentVO.getAgentLicense());
		
		//Begin: 2019 web app changes - IFOX-00406768
		sessionMap.put("sessionC21",enrollmentVO.getC21());
		sessionMap.put("sessionC22",enrollmentVO.getC22());
		sessionMap.put("sessionAttestation22",enrollmentVO.getAttestation22());
		sessionMap.put("sessionC23",enrollmentVO.getC23());
		sessionMap.put("sessionAttestation23",enrollmentVO.getAttestation23());
		sessionMap.put("sessionC24",enrollmentVO.getC24());
		sessionMap.put("sessionAttestation24",enrollmentVO.getAttestation24());
		sessionMap.put("sessionC25",enrollmentVO.getC25());
		//End: 2019 web app changes - IFOX-00406768
		
	}
	public static void mapVOTOSessionSDAB(EnrollmentVO enrollmentVO , HashMap<String, Object> sessionMap){
		sessionMap.put("sessionEffDate",enrollmentVO.getEffDate());
		sessionMap.put("sessionPrefix",enrollmentVO.getPrefix());
		sessionMap.put("sessionFirstName",enrollmentVO.getFirstName());
		sessionMap.put("sessionLastName",enrollmentVO.getLastName());
		sessionMap.put("sessionMiddleInitial",enrollmentVO.getMiddleInitial());
		sessionMap.put("sessionBirthDate",enrollmentVO.getBirthDate());
		sessionMap.put("sessionSex",enrollmentVO.getSex());
		sessionMap.put("sessionPrimaryPhone",enrollmentVO.getPrimaryPhone());
		sessionMap.put("sessionAlternatePhone",enrollmentVO.getCellPhone());
		sessionMap.put("sessionPermanentAddrStreet",enrollmentVO.getPermanentAddrStreet());
		sessionMap.put("sessionPermanentCity",enrollmentVO.getPermanentCity());
		sessionMap.put("sessionPermanentCounty",enrollmentVO.getPermanentCounty());
		sessionMap.put("sessionPermanentState",enrollmentVO.getPermanentState());
		sessionMap.put("sessionPermanentZip",enrollmentVO.getPermanentZip());
		sessionMap.put("sessionMailingAddressRequired",enrollmentVO.getMailingAddressRequired());
		sessionMap.put("sessionMailingAddr",enrollmentVO.getMailingAddr());
		sessionMap.put("sessionMailingCity",enrollmentVO.getMailingCity());
		sessionMap.put("sessionMailingState",enrollmentVO.getMailingState());
		sessionMap.put("sessionMailingZip",enrollmentVO.getMailingzip());
		sessionMap.put("sessionEmailAddr",enrollmentVO.getEmailAddr());
		sessionMap.put("sessionCallAlert",enrollmentVO.getCallAlert());
		sessionMap.put("sessionEmailAlert",enrollmentVO.getEmailAlert());
		
		String medicareClaim = enrollmentVO.getMedicareClaim();
		if(medicareClaim.length() > 3) {
			medicareClaim = medicareClaim.substring(0,3) + "-" + medicareClaim.substring(3);
		}
		if(medicareClaim.length() > 6) {
			medicareClaim = medicareClaim.substring(0,6) + "-" + medicareClaim.substring(6);
		}
		if(medicareClaim.length() > 11) {
			medicareClaim = medicareClaim.substring(0,11) + "-" + medicareClaim.substring(11);
		}
		
		sessionMap.put("sessionMedicareClaim",medicareClaim);
		sessionMap.put("sessionHospitalPartA",enrollmentVO.getHospitalPartA());
		sessionMap.put("sessionHospitalPartB",enrollmentVO.getHospitalPartB());
		sessionMap.put("sessionPaymentOption",enrollmentVO.getPaymentOption());
		sessionMap.put("sessionAccountHolderName",enrollmentVO.getAcctholdername());
		sessionMap.put("sessionBankName",enrollmentVO.getBankname());
		sessionMap.put("sessionAcctType",enrollmentVO.getAcctType());
		sessionMap.put("sessionRoutingNumber",enrollmentVO.getRoutingNumber());
		sessionMap.put("sessionAccountNumber",enrollmentVO.getAccountNumber());
		sessionMap.put("sessionMonthlyBillingFrequency",enrollmentVO.getMonthlybf());
		sessionMap.put("sessionRetiree",enrollmentVO.getRetiree());
		
		//Begin: Modified for IFOX-00414491
		sessionMap.put("sessionCoveringSpouseOrDependent",enrollmentVO.getCoveringSpouseOrDependent());
		sessionMap.put("sessionCoveringSpouseOrDependentLastName",enrollmentVO.getCoveringSpouseOrDependentLastName());
		sessionMap.put("sessionCoveringSpouseOrDependentFirstName",enrollmentVO.getCoveringSpouseOrDependentFirstName());
		sessionMap.put("sessionCoveringSpouseOrDependentMiddleName",enrollmentVO.getCoveringSpouseOrDependentMiddleName());
		sessionMap.put("sessionCoveringSpouseOrDependentEmployeeName",enrollmentVO.getCoveringSpouseOrDependentEmployeeName());
		
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetiree",enrollmentVO.getSurvivingSpouseCitySanDiegoRetiree());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeLastName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeLastName());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeFirstName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeFirstName());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeMiddleName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeMiddleName());
		//End: Modified for IFOX-00414491
		
		sessionMap.put("sessionRetiredate",enrollmentVO.getRetiredate());
		sessionMap.put("sessionRetirename",enrollmentVO.getRetirename());
		sessionMap.put("sessionMeddependsp",enrollmentVO.getMeddependsp());
		sessionMap.put("sessionDependentSpouse",enrollmentVO.getDependentSpouse());
		sessionMap.put("sessionDependentOther",enrollmentVO.getDependentOther());
		sessionMap.put("sessionSpouseWork",enrollmentVO.getSpousework());		
		sessionMap.put("sessionRenalDisease",enrollmentVO.getRenalDisease());
		sessionMap.put("sessionESRDContact",enrollmentVO.getEsrdcontact());
		sessionMap.put("sessionVABenefits",enrollmentVO.getVaBenefits());
		sessionMap.put("sessionNameOfCoverage",enrollmentVO.getNameOfCov());
		sessionMap.put("sessionIdOfCoverage",enrollmentVO.getIdOfCov());
		sessionMap.put("sessionGroupOfCoverage",enrollmentVO.getGroupOfCov());
		sessionMap.put("sessionPrescriptionDrug",enrollmentVO.getPrescriptionDrug());
		sessionMap.put("sessionNameOfInst",enrollmentVO.getNameOfInst());
		sessionMap.put("sessionPhoneOfInst",enrollmentVO.getPhoneOfInst());
		sessionMap.put("sessionAddressOfInst",enrollmentVO.getAddrOfInst());
		sessionMap.put("sessionExistingPatient",enrollmentVO.getExistingp());		
		sessionMap.put("sessionPCPName",enrollmentVO.getPcpName());
		sessionMap.put("sessionPPCPMedicalGroupName",enrollmentVO.getPcpMedicalGroupName());
		sessionMap.put("sessionLanguage",enrollmentVO.getLanguage());
		sessionMap.put("sessionLanguageValue",enrollmentVO.getLanguageValue());
		sessionMap.put("sessionC20",enrollmentVO.getC20());
		sessionMap.put("sessionC1",enrollmentVO.getC1());
		sessionMap.put("sessionC2",enrollmentVO.getC2());
		sessionMap.put("sessionAttestation2",enrollmentVO.getAttestation2());
		sessionMap.put("sessionC3",enrollmentVO.getC3());
		sessionMap.put("sessionAttestation3",enrollmentVO.getAttestation3());
		sessionMap.put("sessionC4",enrollmentVO.getC4());
		sessionMap.put("sessionAttestation4",enrollmentVO.getAttestation4());
		sessionMap.put("sessionC5",enrollmentVO.getC5());
		sessionMap.put("sessionAttestation5",enrollmentVO.getAttestation5());
		sessionMap.put("sessionC6",enrollmentVO.getC6());
		sessionMap.put("sessionC7",enrollmentVO.getC7());
		sessionMap.put("sessionC8",enrollmentVO.getC8());
		sessionMap.put("sessionAttestation8",enrollmentVO.getAttestation8());
		sessionMap.put("sessionC9",enrollmentVO.getC9());
		sessionMap.put("sessionAttestation9",enrollmentVO.getAttestation9());
		sessionMap.put("sessionC10",enrollmentVO.getC10());
		sessionMap.put("sessionAttestation10",enrollmentVO.getAttestation10());
		sessionMap.put("sessionC11",enrollmentVO.getC11());
		sessionMap.put("sessionAttestation11",enrollmentVO.getAttestation11());
		sessionMap.put("sessionC12",enrollmentVO.getC12());
		sessionMap.put("sessionAttestation12",enrollmentVO.getAttestation12());
		sessionMap.put("sessionC13",enrollmentVO.getC13());
		sessionMap.put("sessionC14",enrollmentVO.getC14());
		sessionMap.put("sessionC15",enrollmentVO.getC15());
		sessionMap.put("sessionAttestation15",enrollmentVO.getAttestation15());
		sessionMap.put("sessionC16",enrollmentVO.getC16());
		sessionMap.put("sessionC16Attestation",enrollmentVO.getC16Attestation());		
		sessionMap.put("sessionAttestation16",enrollmentVO.getAttestation16());
		sessionMap.put("sessionNameSignature",enrollmentVO.getNameSignature());
		sessionMap.put("sessionDigiSignature",enrollmentVO.getDigitalSignature());
		sessionMap.put("sessionTodaysDate",enrollmentVO.getTodaysDate());
		sessionMap.put("sessionAuthorizedRep",enrollmentVO.getAuthorizedRep());
		sessionMap.put("sessionAuthorizedRepName",enrollmentVO.getAuthorizedrepname());
		sessionMap.put("sessionAuthorizedRelationship",enrollmentVO.getAuthorizedreprelationship());
		sessionMap.put("sessionAuthorizedRepAddress",enrollmentVO.getAuthorizedrepaddress());
		sessionMap.put("sessionAuthorizedRepPhone",enrollmentVO.getAuthorizedrepphone());
		sessionMap.put("sessionAgentAssistingEnrollment",enrollmentVO.getAgentAssistingEnrollment());
		sessionMap.put("sessionNameOfAgent",enrollmentVO.getNameAgent());
		sessionMap.put("sessionAgentLicense",enrollmentVO.getAgentLicense());
		
		//Begin: 2019 web app changes - IFOX-00406768
		sessionMap.put("sessionC21",enrollmentVO.getC21());
		sessionMap.put("sessionC22",enrollmentVO.getC22());
		sessionMap.put("sessionAttestation22",enrollmentVO.getAttestation22());
		sessionMap.put("sessionC23",enrollmentVO.getC23());
		sessionMap.put("sessionAttestation23",enrollmentVO.getAttestation23());
		sessionMap.put("sessionC24",enrollmentVO.getC24());
		sessionMap.put("sessionAttestation24",enrollmentVO.getAttestation24());
		sessionMap.put("sessionC25",enrollmentVO.getC25());
		//End: 2019 web app changes - IFOX-00406768
		
	}
	//IFOX-00419089 PBP 801 CR - Start
	public static void mapVOTOSessionSDAB20(EnrollmentVO enrollmentVO , HashMap<String, Object> sessionMap){
		sessionMap.put("sessionEffDate",enrollmentVO.getEffDate());
		sessionMap.put("sessionSsn",enrollmentVO.getSsn());
		sessionMap.put("sessionPrefix",enrollmentVO.getPrefix());
		sessionMap.put("sessionFirstName",enrollmentVO.getFirstName());
		sessionMap.put("sessionLastName",enrollmentVO.getLastName());
		sessionMap.put("sessionMiddleInitial",enrollmentVO.getMiddleInitial());
		sessionMap.put("sessionBirthDate",enrollmentVO.getBirthDate());
		sessionMap.put("sessionSex",enrollmentVO.getSex());
		sessionMap.put("sessionPrimaryPhone",enrollmentVO.getPrimaryPhone());
		sessionMap.put("sessionAlternatePhone",enrollmentVO.getCellPhone());
		sessionMap.put("sessionPermanentAddrStreet",enrollmentVO.getPermanentAddrStreet());
		sessionMap.put("sessionPermanentCity",enrollmentVO.getPermanentCity());
		sessionMap.put("sessionPermanentCounty",enrollmentVO.getPermanentCounty());
		sessionMap.put("sessionPermanentState",enrollmentVO.getPermanentState());
		sessionMap.put("sessionPermanentZip",enrollmentVO.getPermanentZip());
		sessionMap.put("sessionMailingAddressRequired",enrollmentVO.getMailingAddressRequired());
		sessionMap.put("sessionMailingAddr",enrollmentVO.getMailingAddr());
		sessionMap.put("sessionMailingCity",enrollmentVO.getMailingCity());
		sessionMap.put("sessionMailingState",enrollmentVO.getMailingState());
		sessionMap.put("sessionMailingZip",enrollmentVO.getMailingzip());
		sessionMap.put("sessionEmailAddr",enrollmentVO.getEmailAddr());
		sessionMap.put("sessionCallAlert",enrollmentVO.getCallAlert());
		sessionMap.put("sessionEmailAlert",enrollmentVO.getEmailAlert());
		
		String medicareClaim = enrollmentVO.getMedicareClaim();
		if(medicareClaim.length() > 3) {
			medicareClaim = medicareClaim.substring(0,3) + "-" + medicareClaim.substring(3);
		}
		if(medicareClaim.length() > 6) {
			medicareClaim = medicareClaim.substring(0,6) + "-" + medicareClaim.substring(6);
		}
		if(medicareClaim.length() > 11) {
			medicareClaim = medicareClaim.substring(0,11) + "-" + medicareClaim.substring(11);
		}
		
		sessionMap.put("sessionMedicareClaim",medicareClaim);
		sessionMap.put("sessionHospitalPartA",enrollmentVO.getHospitalPartA());
		sessionMap.put("sessionHospitalPartB",enrollmentVO.getHospitalPartB());
		sessionMap.put("sessionPaymentOption",enrollmentVO.getPaymentOption());
		sessionMap.put("sessionAccountHolderName",enrollmentVO.getAcctholdername());
		sessionMap.put("sessionBankName",enrollmentVO.getBankname());
		sessionMap.put("sessionAcctType",enrollmentVO.getAcctType());
		sessionMap.put("sessionRoutingNumber",enrollmentVO.getRoutingNumber());
		sessionMap.put("sessionAccountNumber",enrollmentVO.getAccountNumber());
		sessionMap.put("sessionMonthlyBillingFrequency",enrollmentVO.getMonthlybf());
		sessionMap.put("sessionRetiree",enrollmentVO.getRetiree());
		
		//Begin: Modified for IFOX-00414491
		sessionMap.put("sessionCoveringSpouseOrDependent",enrollmentVO.getCoveringSpouseOrDependent());
		sessionMap.put("sessionCoveringSpouseOrDependentLastName",enrollmentVO.getCoveringSpouseOrDependentLastName());
		sessionMap.put("sessionCoveringSpouseOrDependentFirstName",enrollmentVO.getCoveringSpouseOrDependentFirstName());
		sessionMap.put("sessionCoveringSpouseOrDependentMiddleName",enrollmentVO.getCoveringSpouseOrDependentMiddleName());
		sessionMap.put("sessionCoveringSpouseOrDependentEmployeeName",enrollmentVO.getCoveringSpouseOrDependentEmployeeName());
		
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetiree",enrollmentVO.getSurvivingSpouseCitySanDiegoRetiree());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeLastName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeLastName());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeFirstName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeFirstName());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeMiddleName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeMiddleName());
		//End: Modified for IFOX-00414491
		
		sessionMap.put("sessionRetiredate",enrollmentVO.getRetiredate());
		sessionMap.put("sessionRetirename",enrollmentVO.getRetirename());
		sessionMap.put("sessionMeddependsp",enrollmentVO.getMeddependsp());
		sessionMap.put("sessionDependentSpouse",enrollmentVO.getDependentSpouse());
		sessionMap.put("sessionDependentOther",enrollmentVO.getDependentOther());
		sessionMap.put("sessionSpouseWork",enrollmentVO.getSpousework());		
		sessionMap.put("sessionRenalDisease",enrollmentVO.getRenalDisease());
		sessionMap.put("sessionESRDContact",enrollmentVO.getEsrdcontact());
		sessionMap.put("sessionVABenefits",enrollmentVO.getVaBenefits());
		sessionMap.put("sessionNameOfCoverage",enrollmentVO.getNameOfCov());
		sessionMap.put("sessionIdOfCoverage",enrollmentVO.getIdOfCov());
		sessionMap.put("sessionGroupOfCoverage",enrollmentVO.getGroupOfCov());
		sessionMap.put("sessionPrescriptionDrug",enrollmentVO.getPrescriptionDrug());
		sessionMap.put("sessionNameOfInst",enrollmentVO.getNameOfInst());
		sessionMap.put("sessionPhoneOfInst",enrollmentVO.getPhoneOfInst());
		sessionMap.put("sessionAddressOfInst",enrollmentVO.getAddrOfInst());
		sessionMap.put("sessionExistingPatient",enrollmentVO.getExistingp());		
		sessionMap.put("sessionPCPName",enrollmentVO.getPcpName());
		sessionMap.put("sessionPPCPMedicalGroupName",enrollmentVO.getPcpMedicalGroupName());
		sessionMap.put("sessionLanguage",enrollmentVO.getLanguage());
		sessionMap.put("sessionLanguageValue",enrollmentVO.getLanguageValue());
		sessionMap.put("sessionC20",enrollmentVO.getC20());
		sessionMap.put("sessionC1",enrollmentVO.getC1());
		sessionMap.put("sessionC2",enrollmentVO.getC2());
		sessionMap.put("sessionAttestation2",enrollmentVO.getAttestation2());
		sessionMap.put("sessionC3",enrollmentVO.getC3());
		sessionMap.put("sessionAttestation3",enrollmentVO.getAttestation3());
		sessionMap.put("sessionC4",enrollmentVO.getC4());
		sessionMap.put("sessionAttestation4",enrollmentVO.getAttestation4());
		sessionMap.put("sessionC5",enrollmentVO.getC5());
		sessionMap.put("sessionAttestation5",enrollmentVO.getAttestation5());
		sessionMap.put("sessionC6",enrollmentVO.getC6());
		sessionMap.put("sessionC7",enrollmentVO.getC7());
		sessionMap.put("sessionC8",enrollmentVO.getC8());
		sessionMap.put("sessionAttestation8",enrollmentVO.getAttestation8());
		sessionMap.put("sessionC9",enrollmentVO.getC9());
		sessionMap.put("sessionAttestation9",enrollmentVO.getAttestation9());
		sessionMap.put("sessionC10",enrollmentVO.getC10());
		sessionMap.put("sessionAttestation10",enrollmentVO.getAttestation10());
		sessionMap.put("sessionC11",enrollmentVO.getC11());
		sessionMap.put("sessionAttestation11",enrollmentVO.getAttestation11());
		sessionMap.put("sessionC12",enrollmentVO.getC12());
		sessionMap.put("sessionAttestation12",enrollmentVO.getAttestation12());
		sessionMap.put("sessionC13",enrollmentVO.getC13());
		sessionMap.put("sessionC14",enrollmentVO.getC14());
		sessionMap.put("sessionC15",enrollmentVO.getC15());
		sessionMap.put("sessionAttestation15",enrollmentVO.getAttestation15());
		sessionMap.put("sessionC16",enrollmentVO.getC16());
		sessionMap.put("sessionC16Attestation",enrollmentVO.getC16Attestation());		
		sessionMap.put("sessionAttestation16",enrollmentVO.getAttestation16());
		sessionMap.put("sessionNameSignature",enrollmentVO.getNameSignature());
		sessionMap.put("sessionDigiSignature",enrollmentVO.getDigitalSignature());
		sessionMap.put("sessionTodaysDate",enrollmentVO.getTodaysDate());
		sessionMap.put("sessionAuthorizedRep",enrollmentVO.getAuthorizedRep());
		sessionMap.put("sessionAuthorizedRepName",enrollmentVO.getAuthorizedrepname());
		sessionMap.put("sessionAuthorizedRelationship",enrollmentVO.getAuthorizedreprelationship());
		sessionMap.put("sessionAuthorizedRepAddress",enrollmentVO.getAuthorizedrepaddress());
		sessionMap.put("sessionAuthorizedRepPhone",enrollmentVO.getAuthorizedrepphone());
		sessionMap.put("sessionAgentAssistingEnrollment",enrollmentVO.getAgentAssistingEnrollment());
		sessionMap.put("sessionNameOfAgent",enrollmentVO.getNameAgent());
		sessionMap.put("sessionAgentLicense",enrollmentVO.getAgentLicense());
		
		//Begin: 2019 web app changes - IFOX-00406768
		sessionMap.put("sessionC21",enrollmentVO.getC21());
		sessionMap.put("sessionC22",enrollmentVO.getC22());
		sessionMap.put("sessionAttestation22",enrollmentVO.getAttestation22());
		sessionMap.put("sessionC23",enrollmentVO.getC23());
		sessionMap.put("sessionAttestation23",enrollmentVO.getAttestation23());
		sessionMap.put("sessionC24",enrollmentVO.getC24());
		sessionMap.put("sessionAttestation24",enrollmentVO.getAttestation24());
		sessionMap.put("sessionC25",enrollmentVO.getC25());
		//End: 2019 web app changes - IFOX-00406768
		
	}
	//IFOX-00419089 PBP 801 CR - End
	
	public static void mapVOTOSessionSDAP(EnrollmentVO enrollmentVO , HashMap<String, Object> sessionMap){
		sessionMap.put("sessionEffDate",enrollmentVO.getEffDate());
		sessionMap.put("sessionPrefix",enrollmentVO.getPrefix());
		sessionMap.put("sessionFirstName",enrollmentVO.getFirstName());
		sessionMap.put("sessionLastName",enrollmentVO.getLastName());
		sessionMap.put("sessionMiddleInitial",enrollmentVO.getMiddleInitial());
		sessionMap.put("sessionBirthDate",enrollmentVO.getBirthDate());
		sessionMap.put("sessionSex",enrollmentVO.getSex());
		sessionMap.put("sessionPrimaryPhone",enrollmentVO.getPrimaryPhone());
		sessionMap.put("sessionAlternatePhone",enrollmentVO.getCellPhone());
		sessionMap.put("sessionPermanentAddrStreet",enrollmentVO.getPermanentAddrStreet());
		sessionMap.put("sessionPermanentCity",enrollmentVO.getPermanentCity());
		sessionMap.put("sessionPermanentCounty",enrollmentVO.getPermanentCounty());
		sessionMap.put("sessionPermanentState",enrollmentVO.getPermanentState());
		sessionMap.put("sessionPermanentZip",enrollmentVO.getPermanentZip());
		sessionMap.put("sessionMailingAddressRequired",enrollmentVO.getMailingAddressRequired());
		sessionMap.put("sessionMailingAddr",enrollmentVO.getMailingAddr());
		sessionMap.put("sessionMailingCity",enrollmentVO.getMailingCity());
		sessionMap.put("sessionMailingState",enrollmentVO.getMailingState());
		sessionMap.put("sessionMailingZip",enrollmentVO.getMailingzip());
		sessionMap.put("sessionEmailAddr",enrollmentVO.getEmailAddr());
		sessionMap.put("sessionCallAlert",enrollmentVO.getCallAlert());
		sessionMap.put("sessionEmailAlert",enrollmentVO.getEmailAlert());
		
		String medicareClaim = enrollmentVO.getMedicareClaim();
		if(medicareClaim.length() > 3) {
			medicareClaim = medicareClaim.substring(0,3) + "-" + medicareClaim.substring(3);
		}
		if(medicareClaim.length() > 6) {
			medicareClaim = medicareClaim.substring(0,6) + "-" + medicareClaim.substring(6);
		}
		if(medicareClaim.length() > 11) {
			medicareClaim = medicareClaim.substring(0,11) + "-" + medicareClaim.substring(11);
		}
		
		sessionMap.put("sessionMedicareClaim",medicareClaim);
		
		sessionMap.put("sessionHospitalPartA",enrollmentVO.getHospitalPartA());
		sessionMap.put("sessionHospitalPartB",enrollmentVO.getHospitalPartB());
		sessionMap.put("sessionPaymentOption",enrollmentVO.getPaymentOption());
		sessionMap.put("sessionAccountHolderName",enrollmentVO.getAcctholdername());
		sessionMap.put("sessionBankName",enrollmentVO.getBankname());
		sessionMap.put("sessionAcctType",enrollmentVO.getAcctType());
		sessionMap.put("sessionRoutingNumber",enrollmentVO.getRoutingNumber());
		sessionMap.put("sessionAccountNumber",enrollmentVO.getAccountNumber());
		sessionMap.put("sessionMonthlyBillingFrequency",enrollmentVO.getMonthlybf());
		sessionMap.put("sessionRetiree",enrollmentVO.getRetiree());
		
		//Begin: Modified for IFOX-00414491
		sessionMap.put("sessionCoveringSpouseOrDependent",enrollmentVO.getCoveringSpouseOrDependent());
		sessionMap.put("sessionCoveringSpouseOrDependentLastName",enrollmentVO.getCoveringSpouseOrDependentLastName());
		sessionMap.put("sessionCoveringSpouseOrDependentFirstName",enrollmentVO.getCoveringSpouseOrDependentFirstName());
		sessionMap.put("sessionCoveringSpouseOrDependentMiddleName",enrollmentVO.getCoveringSpouseOrDependentMiddleName());
		sessionMap.put("sessionCoveringSpouseOrDependentEmployeeName",enrollmentVO.getCoveringSpouseOrDependentEmployeeName());
		
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetiree",enrollmentVO.getSurvivingSpouseCitySanDiegoRetiree());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeLastName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeLastName());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeFirstName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeFirstName());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeMiddleName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeMiddleName());
		//End: Modified for IFOX-00414491
		
		sessionMap.put("sessionRetiredate",enrollmentVO.getRetiredate());
		sessionMap.put("sessionRetirename",enrollmentVO.getRetirename());
		sessionMap.put("sessionMeddependsp",enrollmentVO.getMeddependsp());
		sessionMap.put("sessionDependentSpouse",enrollmentVO.getDependentSpouse());
		sessionMap.put("sessionDependentOther",enrollmentVO.getDependentOther());
		sessionMap.put("sessionSpouseWork",enrollmentVO.getSpousework());		
		sessionMap.put("sessionRenalDisease",enrollmentVO.getRenalDisease());
		sessionMap.put("sessionESRDContact",enrollmentVO.getEsrdcontact());
		sessionMap.put("sessionVABenefits",enrollmentVO.getVaBenefits());
		sessionMap.put("sessionNameOfCoverage",enrollmentVO.getNameOfCov());
		sessionMap.put("sessionIdOfCoverage",enrollmentVO.getIdOfCov());
		sessionMap.put("sessionGroupOfCoverage",enrollmentVO.getGroupOfCov());
		sessionMap.put("sessionPrescriptionDrug",enrollmentVO.getPrescriptionDrug());
		sessionMap.put("sessionNameOfInst",enrollmentVO.getNameOfInst());
		sessionMap.put("sessionPhoneOfInst",enrollmentVO.getPhoneOfInst());
		sessionMap.put("sessionAddressOfInst",enrollmentVO.getAddrOfInst());
		sessionMap.put("sessionExistingPatient",enrollmentVO.getExistingp());		
		sessionMap.put("sessionPCPName",enrollmentVO.getPcpName());
		sessionMap.put("sessionPPCPMedicalGroupName",enrollmentVO.getPcpMedicalGroupName());
		sessionMap.put("sessionLanguage",enrollmentVO.getLanguage());
		sessionMap.put("sessionLanguageValue",enrollmentVO.getLanguageValue());
		sessionMap.put("sessionC20",enrollmentVO.getC20());
		sessionMap.put("sessionC1",enrollmentVO.getC1());
		sessionMap.put("sessionC2",enrollmentVO.getC2());
		sessionMap.put("sessionAttestation2",enrollmentVO.getAttestation2());
		sessionMap.put("sessionC3",enrollmentVO.getC3());
		sessionMap.put("sessionAttestation3",enrollmentVO.getAttestation3());
		sessionMap.put("sessionC4",enrollmentVO.getC4());
		sessionMap.put("sessionAttestation4",enrollmentVO.getAttestation4());
		sessionMap.put("sessionC5",enrollmentVO.getC5());
		sessionMap.put("sessionAttestation5",enrollmentVO.getAttestation5());
		sessionMap.put("sessionC6",enrollmentVO.getC6());
		sessionMap.put("sessionC7",enrollmentVO.getC7());
		sessionMap.put("sessionC8",enrollmentVO.getC8());
		sessionMap.put("sessionAttestation8",enrollmentVO.getAttestation8());
		sessionMap.put("sessionC9",enrollmentVO.getC9());
		sessionMap.put("sessionAttestation9",enrollmentVO.getAttestation9());
		sessionMap.put("sessionC10",enrollmentVO.getC10());
		sessionMap.put("sessionAttestation10",enrollmentVO.getAttestation10());
		sessionMap.put("sessionC11",enrollmentVO.getC11());
		sessionMap.put("sessionAttestation11",enrollmentVO.getAttestation11());
		sessionMap.put("sessionC12",enrollmentVO.getC12());
		sessionMap.put("sessionAttestation12",enrollmentVO.getAttestation12());
		sessionMap.put("sessionC13",enrollmentVO.getC13());
		sessionMap.put("sessionC14",enrollmentVO.getC14());
		sessionMap.put("sessionC15",enrollmentVO.getC15());
		sessionMap.put("sessionAttestation15",enrollmentVO.getAttestation15());
		sessionMap.put("sessionC16",enrollmentVO.getC16());
		sessionMap.put("sessionC16Attestation",enrollmentVO.getC16Attestation());		
		sessionMap.put("sessionAttestation16",enrollmentVO.getAttestation16());
		sessionMap.put("sessionNameSignature",enrollmentVO.getNameSignature());
		sessionMap.put("sessionDigiSignature",enrollmentVO.getDigitalSignature());
		sessionMap.put("sessionTodaysDate",enrollmentVO.getTodaysDate());
		sessionMap.put("sessionAuthorizedRep",enrollmentVO.getAuthorizedRep());
		sessionMap.put("sessionAuthorizedRepName",enrollmentVO.getAuthorizedrepname());
		sessionMap.put("sessionAuthorizedRelationship",enrollmentVO.getAuthorizedreprelationship());
		sessionMap.put("sessionAuthorizedRepAddress",enrollmentVO.getAuthorizedrepaddress());
		sessionMap.put("sessionAuthorizedRepPhone",enrollmentVO.getAuthorizedrepphone());
		sessionMap.put("sessionAgentAssistingEnrollment",enrollmentVO.getAgentAssistingEnrollment());
		sessionMap.put("sessionNameOfAgent",enrollmentVO.getNameAgent());
		sessionMap.put("sessionAgentLicense",enrollmentVO.getAgentLicense());
		
		//Begin: 2019 web app changes - IFOX-00406768
		sessionMap.put("sessionC21",enrollmentVO.getC21());
		sessionMap.put("sessionC22",enrollmentVO.getC22());
		sessionMap.put("sessionAttestation22",enrollmentVO.getAttestation22());
		sessionMap.put("sessionC23",enrollmentVO.getC23());
		sessionMap.put("sessionAttestation23",enrollmentVO.getAttestation23());
		sessionMap.put("sessionC24",enrollmentVO.getC24());
		sessionMap.put("sessionAttestation24",enrollmentVO.getAttestation24());
		sessionMap.put("sessionC25",enrollmentVO.getC25());
		//End: 2019 web app changes - IFOX-00406768
		
	}		
	public static void mapVOTOSessionSAMEA(EnrollmentVO enrollmentVO , HashMap<String, Object> sessionMap){
		sessionMap.put("sessionPrefix",enrollmentVO.getPrefix());
		sessionMap.put("sessionFirstName",enrollmentVO.getFirstName());
		sessionMap.put("sessionLastName",enrollmentVO.getLastName());
		sessionMap.put("sessionMiddleInitial",enrollmentVO.getMiddleInitial());
		sessionMap.put("sessionBirthDate",enrollmentVO.getBirthDate());
		sessionMap.put("sessionSex",enrollmentVO.getSex());
		sessionMap.put("sessionPrimaryPhone",enrollmentVO.getPrimaryPhone());
		sessionMap.put("sessionAlternatePhone",enrollmentVO.getCellPhone());
		sessionMap.put("sessionPermanentAddrStreet",enrollmentVO.getPermanentAddrStreet());
		sessionMap.put("sessionPermanentCity",enrollmentVO.getPermanentCity());
		sessionMap.put("sessionPermanentCounty",enrollmentVO.getPermanentCounty());
		sessionMap.put("sessionPermanentState",enrollmentVO.getPermanentState());
		sessionMap.put("sessionPermanentZip",enrollmentVO.getPermanentZip());
		sessionMap.put("sessionMailingAddressRequired",enrollmentVO.getMailingAddressRequired());
		sessionMap.put("sessionMailingAddr",enrollmentVO.getMailingAddr());
		sessionMap.put("sessionMailingCity",enrollmentVO.getMailingCity());
		sessionMap.put("sessionMailingState",enrollmentVO.getMailingState());
		sessionMap.put("sessionMailingZip",enrollmentVO.getMailingzip());
		sessionMap.put("sessionEmailAddr",enrollmentVO.getEmailAddr());
		sessionMap.put("sessionCallAlert",enrollmentVO.getCallAlert());
		sessionMap.put("sessionEmailAlert",enrollmentVO.getEmailAlert());
		
		String medicareClaim = enrollmentVO.getMedicareClaim();
		if(medicareClaim.length() > 3) {
			medicareClaim = medicareClaim.substring(0,3) + "-" + medicareClaim.substring(3);
		}
		if(medicareClaim.length() > 6) {
			medicareClaim = medicareClaim.substring(0,6) + "-" + medicareClaim.substring(6);
		}
		if(medicareClaim.length() > 11) {
			medicareClaim = medicareClaim.substring(0,11) + "-" + medicareClaim.substring(11);
		}
		
		sessionMap.put("sessionMedicareClaim",medicareClaim);
		
		sessionMap.put("sessionHospitalPartA",enrollmentVO.getHospitalPartA());
		sessionMap.put("sessionHospitalPartB",enrollmentVO.getHospitalPartB());
		sessionMap.put("sessionPaymentOption",enrollmentVO.getPaymentOption());
		sessionMap.put("sessionMonthlyBillingFrequency",enrollmentVO.getMonthlybf());
		sessionMap.put("sessionRetiree",enrollmentVO.getRetiree());
		
		//Begin: Modified for IFOX-00414491
		sessionMap.put("sessionCoveringSpouseOrDependent",enrollmentVO.getCoveringSpouseOrDependent());
		sessionMap.put("sessionCoveringSpouseOrDependentLastName",enrollmentVO.getCoveringSpouseOrDependentLastName());
		sessionMap.put("sessionCoveringSpouseOrDependentFirstName",enrollmentVO.getCoveringSpouseOrDependentFirstName());
		sessionMap.put("sessionCoveringSpouseOrDependentMiddleName",enrollmentVO.getCoveringSpouseOrDependentMiddleName());
		sessionMap.put("sessionCoveringSpouseOrDependentEmployeeName",enrollmentVO.getCoveringSpouseOrDependentEmployeeName());
		
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetiree",enrollmentVO.getSurvivingSpouseCitySanDiegoRetiree());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeLastName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeLastName());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeFirstName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeFirstName());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeMiddleName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeMiddleName());
		//End: Modified for IFOX-00414491
		
		sessionMap.put("sessionRetiredate",enrollmentVO.getRetiredate());
		sessionMap.put("sessionRetirename",enrollmentVO.getRetirename());
		sessionMap.put("sessionMeddependsp",enrollmentVO.getMeddependsp());
		sessionMap.put("sessionDependentSpouse",enrollmentVO.getDependentSpouse());
		sessionMap.put("sessionDependentOther",enrollmentVO.getDependentOther());
		sessionMap.put("sessionSpouseWork",enrollmentVO.getSpousework());		
		sessionMap.put("sessionRenalDisease",enrollmentVO.getRenalDisease());
		sessionMap.put("sessionESRDContact",enrollmentVO.getEsrdcontact());
		sessionMap.put("sessionVABenefits",enrollmentVO.getVaBenefits());
		sessionMap.put("sessionNameOfCoverage",enrollmentVO.getNameOfCov());
		sessionMap.put("sessionIdOfCoverage",enrollmentVO.getIdOfCov());
		sessionMap.put("sessionGroupOfCoverage",enrollmentVO.getGroupOfCov());
		sessionMap.put("sessionPrescriptionDrug",enrollmentVO.getPrescriptionDrug());
		sessionMap.put("sessionNameOfInst",enrollmentVO.getNameOfInst());
		sessionMap.put("sessionPhoneOfInst",enrollmentVO.getPhoneOfInst());
		sessionMap.put("sessionAddressOfInst",enrollmentVO.getAddrOfInst());
		sessionMap.put("sessionHlthcovType",enrollmentVO.getHlthcovType());
		sessionMap.put("sessionHlthcovInscomp",enrollmentVO.getHlthcovInscomp());	
		sessionMap.put("sessionPCPName",enrollmentVO.getPcpName());
		sessionMap.put("sessionPPCPMedicalGroupName",enrollmentVO.getPcpMedicalGroupName());
		sessionMap.put("sessionExistingPatient",enrollmentVO.getExistingp());	
		sessionMap.put("sessionLanguage",enrollmentVO.getLanguage());
		sessionMap.put("sessionLanguageValue",enrollmentVO.getLanguageValue());
		sessionMap.put("sessionC20",enrollmentVO.getC20());
		sessionMap.put("sessionC1",enrollmentVO.getC1());
		sessionMap.put("sessionC2",enrollmentVO.getC2());
		sessionMap.put("sessionAttestation2",enrollmentVO.getAttestation2());
		sessionMap.put("sessionC3",enrollmentVO.getC3());
		sessionMap.put("sessionAttestation3",enrollmentVO.getAttestation3());
		sessionMap.put("sessionC4",enrollmentVO.getC4());
		sessionMap.put("sessionAttestation4",enrollmentVO.getAttestation4());
		sessionMap.put("sessionC5",enrollmentVO.getC5());
		sessionMap.put("sessionAttestation5",enrollmentVO.getAttestation5());
		sessionMap.put("sessionC6",enrollmentVO.getC6());
		sessionMap.put("sessionC7",enrollmentVO.getC7());
		sessionMap.put("sessionC8",enrollmentVO.getC8());
		sessionMap.put("sessionAttestation8",enrollmentVO.getAttestation8());
		sessionMap.put("sessionC9",enrollmentVO.getC9());
		sessionMap.put("sessionAttestation9",enrollmentVO.getAttestation9());
		sessionMap.put("sessionC10",enrollmentVO.getC10());
		sessionMap.put("sessionAttestation10",enrollmentVO.getAttestation10());
		sessionMap.put("sessionC11",enrollmentVO.getC11());
		sessionMap.put("sessionAttestation11",enrollmentVO.getAttestation11());
		sessionMap.put("sessionC12",enrollmentVO.getC12());
		sessionMap.put("sessionAttestation12",enrollmentVO.getAttestation12());
		sessionMap.put("sessionC13",enrollmentVO.getC13());
		sessionMap.put("sessionC14",enrollmentVO.getC14());
		sessionMap.put("sessionC15",enrollmentVO.getC15());
		sessionMap.put("sessionAttestation15",enrollmentVO.getAttestation15());
		sessionMap.put("sessionC16",enrollmentVO.getC16());
		sessionMap.put("sessionC16Attestation",enrollmentVO.getC16Attestation());		
		sessionMap.put("sessionAttestation16",enrollmentVO.getAttestation16());
		sessionMap.put("sessionNameSignature",enrollmentVO.getNameSignature());
		sessionMap.put("sessionDigiSignature",enrollmentVO.getDigitalSignature());
		sessionMap.put("sessionTodaysDate",enrollmentVO.getTodaysDate());
		sessionMap.put("sessionAuthorizedRep",enrollmentVO.getAuthorizedRep());
		sessionMap.put("sessionAuthorizedRepName",enrollmentVO.getAuthorizedrepname());
		sessionMap.put("sessionAuthorizedRelationship",enrollmentVO.getAuthorizedreprelationship());
		sessionMap.put("sessionAuthorizedRepAddress",enrollmentVO.getAuthorizedrepaddress());
		sessionMap.put("sessionAuthorizedRepPhone",enrollmentVO.getAuthorizedrepphone());
		sessionMap.put("sessionAgentAssistingEnrollment",enrollmentVO.getAgentAssistingEnrollment());
		sessionMap.put("sessionNameOfAgent",enrollmentVO.getNameAgent());
		sessionMap.put("sessionAgentLicense",enrollmentVO.getAgentLicense());
		
		//Begin: 2019 web app changes - IFOX-00406768
		sessionMap.put("sessionC21",enrollmentVO.getC21());
		sessionMap.put("sessionC22",enrollmentVO.getC22());
		sessionMap.put("sessionAttestation22",enrollmentVO.getAttestation22());
		sessionMap.put("sessionC23",enrollmentVO.getC23());
		sessionMap.put("sessionAttestation23",enrollmentVO.getAttestation23());
		sessionMap.put("sessionC24",enrollmentVO.getC24());
		sessionMap.put("sessionAttestation24",enrollmentVO.getAttestation24());
		sessionMap.put("sessionC25",enrollmentVO.getC25());
		//End: 2019 web app changes - IFOX-00406768
		
	}		
	public static void mapVOTOSessionSDAMEA(EnrollmentVO enrollmentVO , HashMap<String, Object> sessionMap){
		sessionMap.put("sessionPrefix",enrollmentVO.getPrefix());
		sessionMap.put("sessionFirstName",enrollmentVO.getFirstName());
		sessionMap.put("sessionLastName",enrollmentVO.getLastName());
		sessionMap.put("sessionMiddleInitial",enrollmentVO.getMiddleInitial());
		sessionMap.put("sessionBirthDate",enrollmentVO.getBirthDate());
		sessionMap.put("sessionSex",enrollmentVO.getSex());
		sessionMap.put("sessionPrimaryPhone",enrollmentVO.getPrimaryPhone());
		sessionMap.put("sessionAlternatePhone",enrollmentVO.getCellPhone());
		sessionMap.put("sessionPermanentAddrStreet",enrollmentVO.getPermanentAddrStreet());
		sessionMap.put("sessionPermanentCity",enrollmentVO.getPermanentCity());
		sessionMap.put("sessionPermanentCounty",enrollmentVO.getPermanentCounty());
		sessionMap.put("sessionPermanentState",enrollmentVO.getPermanentState());
		sessionMap.put("sessionPermanentZip",enrollmentVO.getPermanentZip());
		sessionMap.put("sessionMailingAddressRequired",enrollmentVO.getMailingAddressRequired());
		sessionMap.put("sessionMailingAddr",enrollmentVO.getMailingAddr());
		sessionMap.put("sessionMailingCity",enrollmentVO.getMailingCity());
		sessionMap.put("sessionMailingState",enrollmentVO.getMailingState());
		sessionMap.put("sessionMailingZip",enrollmentVO.getMailingzip());
		sessionMap.put("sessionEmailAddr",enrollmentVO.getEmailAddr());
		sessionMap.put("sessionCallAlert",enrollmentVO.getCallAlert());
		sessionMap.put("sessionEmailAlert",enrollmentVO.getEmailAlert());
		
		String medicareClaim = enrollmentVO.getMedicareClaim();
		if(medicareClaim.length() > 3) {
			medicareClaim = medicareClaim.substring(0,3) + "-" + medicareClaim.substring(3);
		}
		if(medicareClaim.length() > 6) {
			medicareClaim = medicareClaim.substring(0,6) + "-" + medicareClaim.substring(6);
		}
		if(medicareClaim.length() > 11) {
			medicareClaim = medicareClaim.substring(0,11) + "-" + medicareClaim.substring(11);
		}
		
		sessionMap.put("sessionMedicareClaim",medicareClaim);
		
		sessionMap.put("sessionHospitalPartA",enrollmentVO.getHospitalPartA());
		sessionMap.put("sessionHospitalPartB",enrollmentVO.getHospitalPartB());
		sessionMap.put("sessionPaymentOption",enrollmentVO.getPaymentOption());
		sessionMap.put("sessionAccountHolderName",enrollmentVO.getAcctholdername());
		sessionMap.put("sessionBankName",enrollmentVO.getBankname());
		sessionMap.put("sessionAcctType",enrollmentVO.getAcctType());
		sessionMap.put("sessionRoutingNumber",enrollmentVO.getRoutingNumber());
		sessionMap.put("sessionAccountNumber",enrollmentVO.getAccountNumber());		
		sessionMap.put("sessionMonthlyBillingFrequency",enrollmentVO.getMonthlybf());
		sessionMap.put("sessionRetiree",enrollmentVO.getRetiree());
		
		//Begin: Modified for IFOX-00414491
		sessionMap.put("sessionCoveringSpouseOrDependent",enrollmentVO.getCoveringSpouseOrDependent());
		sessionMap.put("sessionCoveringSpouseOrDependentLastName",enrollmentVO.getCoveringSpouseOrDependentLastName());
		sessionMap.put("sessionCoveringSpouseOrDependentFirstName",enrollmentVO.getCoveringSpouseOrDependentFirstName());
		sessionMap.put("sessionCoveringSpouseOrDependentMiddleName",enrollmentVO.getCoveringSpouseOrDependentMiddleName());
		sessionMap.put("sessionCoveringSpouseOrDependentEmployeeName",enrollmentVO.getCoveringSpouseOrDependentEmployeeName());
		
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetiree",enrollmentVO.getSurvivingSpouseCitySanDiegoRetiree());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeLastName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeLastName());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeFirstName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeFirstName());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeMiddleName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeMiddleName());
		//End: Modified for IFOX-00414491
		
		sessionMap.put("sessionRetiredate",enrollmentVO.getRetiredate());
		sessionMap.put("sessionRetirename",enrollmentVO.getRetirename());
		sessionMap.put("sessionMeddependsp",enrollmentVO.getMeddependsp());
		sessionMap.put("sessionDependentSpouse",enrollmentVO.getDependentSpouse());
		sessionMap.put("sessionDependentOther",enrollmentVO.getDependentOther());
		sessionMap.put("sessionSpouseWork",enrollmentVO.getSpousework());		
		sessionMap.put("sessionRenalDisease",enrollmentVO.getRenalDisease());
		sessionMap.put("sessionESRDContact",enrollmentVO.getEsrdcontact());
		sessionMap.put("sessionVABenefits",enrollmentVO.getVaBenefits());
		sessionMap.put("sessionNameOfCoverage",enrollmentVO.getNameOfCov());
		sessionMap.put("sessionIdOfCoverage",enrollmentVO.getIdOfCov());
		sessionMap.put("sessionGroupOfCoverage",enrollmentVO.getGroupOfCov());
		sessionMap.put("sessionPrescriptionDrug",enrollmentVO.getPrescriptionDrug());
		sessionMap.put("sessionNameOfInst",enrollmentVO.getNameOfInst());
		sessionMap.put("sessionPhoneOfInst",enrollmentVO.getPhoneOfInst());
		sessionMap.put("sessionAddressOfInst",enrollmentVO.getAddrOfInst());
		sessionMap.put("sessionHlthcovType",enrollmentVO.getHlthcovType());
		sessionMap.put("sessionHlthcovInscomp",enrollmentVO.getHlthcovInscomp());	
		sessionMap.put("sessionPCPName",enrollmentVO.getPcpName());
		sessionMap.put("sessionPPCPMedicalGroupName",enrollmentVO.getPcpMedicalGroupName());
		sessionMap.put("sessionExistingPatient",enrollmentVO.getExistingp());	
		sessionMap.put("sessionLanguage",enrollmentVO.getLanguage());
		sessionMap.put("sessionLanguageValue",enrollmentVO.getLanguageValue());
		sessionMap.put("sessionC20",enrollmentVO.getC20());
		sessionMap.put("sessionC1",enrollmentVO.getC1());
		sessionMap.put("sessionC2",enrollmentVO.getC2());
		sessionMap.put("sessionAttestation2",enrollmentVO.getAttestation2());
		sessionMap.put("sessionC3",enrollmentVO.getC3());
		sessionMap.put("sessionAttestation3",enrollmentVO.getAttestation3());
		sessionMap.put("sessionC4",enrollmentVO.getC4());
		sessionMap.put("sessionAttestation4",enrollmentVO.getAttestation4());
		sessionMap.put("sessionC5",enrollmentVO.getC5());
		sessionMap.put("sessionAttestation5",enrollmentVO.getAttestation5());
		sessionMap.put("sessionC6",enrollmentVO.getC6());
		sessionMap.put("sessionC7",enrollmentVO.getC7());
		sessionMap.put("sessionC8",enrollmentVO.getC8());
		sessionMap.put("sessionAttestation8",enrollmentVO.getAttestation8());
		sessionMap.put("sessionC9",enrollmentVO.getC9());
		sessionMap.put("sessionAttestation9",enrollmentVO.getAttestation9());
		sessionMap.put("sessionC10",enrollmentVO.getC10());
		sessionMap.put("sessionAttestation10",enrollmentVO.getAttestation10());
		sessionMap.put("sessionC11",enrollmentVO.getC11());
		sessionMap.put("sessionAttestation11",enrollmentVO.getAttestation11());
		sessionMap.put("sessionC12",enrollmentVO.getC12());
		sessionMap.put("sessionAttestation12",enrollmentVO.getAttestation12());
		sessionMap.put("sessionC13",enrollmentVO.getC13());
		sessionMap.put("sessionC14",enrollmentVO.getC14());
		sessionMap.put("sessionC15",enrollmentVO.getC15());
		sessionMap.put("sessionAttestation15",enrollmentVO.getAttestation15());
		sessionMap.put("sessionC16",enrollmentVO.getC16());
		sessionMap.put("sessionC16Attestation",enrollmentVO.getC16Attestation());		
		sessionMap.put("sessionAttestation16",enrollmentVO.getAttestation16());
		sessionMap.put("sessionNameSignature",enrollmentVO.getNameSignature());
		sessionMap.put("sessionDigiSignature",enrollmentVO.getDigitalSignature());
		sessionMap.put("sessionTodaysDate",enrollmentVO.getTodaysDate());
		sessionMap.put("sessionAuthorizedRep",enrollmentVO.getAuthorizedRep());
		sessionMap.put("sessionAuthorizedRepName",enrollmentVO.getAuthorizedrepname());
		sessionMap.put("sessionAuthorizedRelationship",enrollmentVO.getAuthorizedreprelationship());
		sessionMap.put("sessionAuthorizedRepAddress",enrollmentVO.getAuthorizedrepaddress());
		sessionMap.put("sessionAuthorizedRepPhone",enrollmentVO.getAuthorizedrepphone());
		sessionMap.put("sessionAgentAssistingEnrollment",enrollmentVO.getAgentAssistingEnrollment());
		sessionMap.put("sessionNameOfAgent",enrollmentVO.getNameAgent());
		sessionMap.put("sessionAgentLicense",enrollmentVO.getAgentLicense());
		
		//Begin: 2019 web app changes - IFOX-00406768
		sessionMap.put("sessionC21",enrollmentVO.getC21());
		sessionMap.put("sessionC22",enrollmentVO.getC22());
		sessionMap.put("sessionAttestation22",enrollmentVO.getAttestation22());
		sessionMap.put("sessionC23",enrollmentVO.getC23());
		sessionMap.put("sessionAttestation23",enrollmentVO.getAttestation23());
		sessionMap.put("sessionC24",enrollmentVO.getC24());
		sessionMap.put("sessionAttestation24",enrollmentVO.getAttestation24());
		sessionMap.put("sessionC25",enrollmentVO.getC25());
		//End: 2019 web app changes - IFOX-00406768
		
	}	
	/**IFOX-00403984 Changes Start.*/
	public static void mapVOTOSessionSDAHMO(EnrollmentVO enrollmentVO , HashMap<String, Object> sessionMap){
		sessionMap.put("sessionEffDate",enrollmentVO.getEffDate());
		sessionMap.put("sessionPrefix",enrollmentVO.getPrefix());
		sessionMap.put("sessionFirstName",enrollmentVO.getFirstName());
		sessionMap.put("sessionLastName",enrollmentVO.getLastName());
		sessionMap.put("sessionMiddleInitial",enrollmentVO.getMiddleInitial());
		sessionMap.put("sessionBirthDate",enrollmentVO.getBirthDate());
		sessionMap.put("sessionSex",enrollmentVO.getSex());
		sessionMap.put("sessionPrimaryPhone",enrollmentVO.getPrimaryPhone());
		sessionMap.put("sessionAlternatePhone",enrollmentVO.getCellPhone());
		sessionMap.put("sessionPermanentAddrStreet",enrollmentVO.getPermanentAddrStreet());
		sessionMap.put("sessionPermanentCity",enrollmentVO.getPermanentCity());
		sessionMap.put("sessionPermanentCounty",enrollmentVO.getPermanentCounty());
		sessionMap.put("sessionPermanentState",enrollmentVO.getPermanentState());
		sessionMap.put("sessionPermanentZip",enrollmentVO.getPermanentZip());
		sessionMap.put("sessionMailingAddressRequired",enrollmentVO.getMailingAddressRequired());
		sessionMap.put("sessionMailingAddr",enrollmentVO.getMailingAddr());
		sessionMap.put("sessionMailingCity",enrollmentVO.getMailingCity());
		sessionMap.put("sessionMailingState",enrollmentVO.getMailingState());
		sessionMap.put("sessionMailingZip",enrollmentVO.getMailingzip());
		sessionMap.put("sessionEmailAddr",enrollmentVO.getEmailAddr());
		sessionMap.put("sessionCallAlert",enrollmentVO.getCallAlert());
		sessionMap.put("sessionEmailAlert",enrollmentVO.getEmailAlert());
		
		String medicareClaim = enrollmentVO.getMedicareClaim();
		if(medicareClaim.length() > 3) {
			medicareClaim = medicareClaim.substring(0,3) + "-" + medicareClaim.substring(3);
		}
		if(medicareClaim.length() > 6) {
			medicareClaim = medicareClaim.substring(0,6) + "-" + medicareClaim.substring(6);
		}
		if(medicareClaim.length() > 11) {
			medicareClaim = medicareClaim.substring(0,11) + "-" + medicareClaim.substring(11);
		}
		
		sessionMap.put("sessionMedicareClaim",medicareClaim);
		
		sessionMap.put("sessionHospitalPartA",enrollmentVO.getHospitalPartA());
		sessionMap.put("sessionHospitalPartB",enrollmentVO.getHospitalPartB());
		sessionMap.put("sessionPaymentOption",enrollmentVO.getPaymentOption());
		sessionMap.put("sessionAccountHolderName",enrollmentVO.getAcctholdername());
		sessionMap.put("sessionBankName",enrollmentVO.getBankname());
		sessionMap.put("sessionAcctType",enrollmentVO.getAcctType());
		sessionMap.put("sessionRoutingNumber",enrollmentVO.getRoutingNumber());
		sessionMap.put("sessionAccountNumber",enrollmentVO.getAccountNumber());		
		sessionMap.put("sessionMonthlyBillingFrequency",enrollmentVO.getMonthlybf());
		sessionMap.put("sessionRetiree",enrollmentVO.getRetiree());
		
		//Begin: Modified for IFOX-00414491
		sessionMap.put("sessionCoveringSpouseOrDependent",enrollmentVO.getCoveringSpouseOrDependent());
		sessionMap.put("sessionCoveringSpouseOrDependentLastName",enrollmentVO.getCoveringSpouseOrDependentLastName());
		sessionMap.put("sessionCoveringSpouseOrDependentFirstName",enrollmentVO.getCoveringSpouseOrDependentFirstName());
		sessionMap.put("sessionCoveringSpouseOrDependentMiddleName",enrollmentVO.getCoveringSpouseOrDependentMiddleName());
		sessionMap.put("sessionCoveringSpouseOrDependentEmployeeName",enrollmentVO.getCoveringSpouseOrDependentEmployeeName());
		
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetiree",enrollmentVO.getSurvivingSpouseCitySanDiegoRetiree());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeLastName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeLastName());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeFirstName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeFirstName());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeMiddleName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeMiddleName());
		//End: Modified for IFOX-00414491
		
		sessionMap.put("sessionRetiredate",enrollmentVO.getRetiredate());
		sessionMap.put("sessionRetirename",enrollmentVO.getRetirename());
		sessionMap.put("sessionMeddependsp",enrollmentVO.getMeddependsp());
		sessionMap.put("sessionDependentSpouse",enrollmentVO.getDependentSpouse());
		sessionMap.put("sessionDependentOther",enrollmentVO.getDependentOther());
		sessionMap.put("sessionSpouseWork",enrollmentVO.getSpousework());		
		sessionMap.put("sessionRenalDisease",enrollmentVO.getRenalDisease());
		sessionMap.put("sessionESRDContact",enrollmentVO.getEsrdcontact());
		sessionMap.put("sessionVABenefits",enrollmentVO.getVaBenefits());
		sessionMap.put("sessionNameOfCoverage",enrollmentVO.getNameOfCov());
		sessionMap.put("sessionIdOfCoverage",enrollmentVO.getIdOfCov());
		sessionMap.put("sessionGroupOfCoverage",enrollmentVO.getGroupOfCov());
		sessionMap.put("sessionPrescriptionDrug",enrollmentVO.getPrescriptionDrug());
		sessionMap.put("sessionNameOfInst",enrollmentVO.getNameOfInst());
		sessionMap.put("sessionPhoneOfInst",enrollmentVO.getPhoneOfInst());
		sessionMap.put("sessionAddressOfInst",enrollmentVO.getAddrOfInst());
		sessionMap.put("sessionHlthcovType",enrollmentVO.getHlthcovType());
		sessionMap.put("sessionHlthcovInscomp",enrollmentVO.getHlthcovInscomp());	
		sessionMap.put("sessionPCPName",enrollmentVO.getPcpName());
		sessionMap.put("sessionPPCPMedicalGroupName",enrollmentVO.getPcpMedicalGroupName());
		sessionMap.put("sessionExistingPatient",enrollmentVO.getExistingp());	
		sessionMap.put("sessionLanguage",enrollmentVO.getLanguage());
		sessionMap.put("sessionLanguageValue",enrollmentVO.getLanguageValue());
		sessionMap.put("sessionC20",enrollmentVO.getC20());
		sessionMap.put("sessionC1",enrollmentVO.getC1());
		sessionMap.put("sessionC2",enrollmentVO.getC2());
		sessionMap.put("sessionAttestation2",enrollmentVO.getAttestation2());
		sessionMap.put("sessionC3",enrollmentVO.getC3());
		sessionMap.put("sessionAttestation3",enrollmentVO.getAttestation3());
		sessionMap.put("sessionC4",enrollmentVO.getC4());
		sessionMap.put("sessionAttestation4",enrollmentVO.getAttestation4());
		sessionMap.put("sessionC5",enrollmentVO.getC5());
		sessionMap.put("sessionAttestation5",enrollmentVO.getAttestation5());
		sessionMap.put("sessionC6",enrollmentVO.getC6());
		sessionMap.put("sessionC7",enrollmentVO.getC7());
		sessionMap.put("sessionC8",enrollmentVO.getC8());
		sessionMap.put("sessionAttestation8",enrollmentVO.getAttestation8());
		sessionMap.put("sessionC9",enrollmentVO.getC9());
		sessionMap.put("sessionAttestation9",enrollmentVO.getAttestation9());
		sessionMap.put("sessionC10",enrollmentVO.getC10());
		sessionMap.put("sessionAttestation10",enrollmentVO.getAttestation10());
		sessionMap.put("sessionC11",enrollmentVO.getC11());
		sessionMap.put("sessionAttestation11",enrollmentVO.getAttestation11());
		sessionMap.put("sessionC12",enrollmentVO.getC12());
		sessionMap.put("sessionAttestation12",enrollmentVO.getAttestation12());
		sessionMap.put("sessionC13",enrollmentVO.getC13());
		sessionMap.put("sessionC14",enrollmentVO.getC14());
		sessionMap.put("sessionC15",enrollmentVO.getC15());
		sessionMap.put("sessionAttestation15",enrollmentVO.getAttestation15());
		sessionMap.put("sessionC16",enrollmentVO.getC16());
		sessionMap.put("sessionC16Attestation",enrollmentVO.getC16Attestation());		
		sessionMap.put("sessionAttestation16",enrollmentVO.getAttestation16());
		sessionMap.put("sessionNameSignature",enrollmentVO.getNameSignature());
		sessionMap.put("sessionDigiSignature",enrollmentVO.getDigitalSignature());
		sessionMap.put("sessionTodaysDate",enrollmentVO.getTodaysDate());
		sessionMap.put("sessionAuthorizedRep",enrollmentVO.getAuthorizedRep());
		sessionMap.put("sessionAuthorizedRepName",enrollmentVO.getAuthorizedrepname());
		sessionMap.put("sessionAuthorizedRelationship",enrollmentVO.getAuthorizedreprelationship());
		sessionMap.put("sessionAuthorizedRepAddress",enrollmentVO.getAuthorizedrepaddress());
		sessionMap.put("sessionAuthorizedRepPhone",enrollmentVO.getAuthorizedrepphone());
		sessionMap.put("sessionAgentAssistingEnrollment",enrollmentVO.getAgentAssistingEnrollment());
		sessionMap.put("sessionNameOfAgent",enrollmentVO.getNameAgent());
		sessionMap.put("sessionAgentLicense",enrollmentVO.getAgentLicense());
		
		//Begin: 2019 web app changes - IFOX-00406768
		sessionMap.put("sessionC21",enrollmentVO.getC21());
		sessionMap.put("sessionC22",enrollmentVO.getC22());
		sessionMap.put("sessionAttestation22",enrollmentVO.getAttestation22());
		sessionMap.put("sessionC23",enrollmentVO.getC23());
		sessionMap.put("sessionAttestation23",enrollmentVO.getAttestation23());
		sessionMap.put("sessionC24",enrollmentVO.getC24());
		sessionMap.put("sessionAttestation24",enrollmentVO.getAttestation24());
		sessionMap.put("sessionC25",enrollmentVO.getC25());
		//End: 2019 web app changes - IFOX-00406768
		
	}
	
	
	//Begin: Modified for IFOX-00414491
	public static void mapVOTOSessionSDAHMO1(EnrollmentVO enrollmentVO , HashMap<String, Object> sessionMap){
		sessionMap.put("sessionEffDate",enrollmentVO.getEffDate());
		sessionMap.put("sessionPrefix",enrollmentVO.getPrefix());
		sessionMap.put("sessionFirstName",enrollmentVO.getFirstName());
		sessionMap.put("sessionLastName",enrollmentVO.getLastName());
		sessionMap.put("sessionMiddleInitial",enrollmentVO.getMiddleInitial());
		sessionMap.put("sessionBirthDate",enrollmentVO.getBirthDate());
		sessionMap.put("sessionSex",enrollmentVO.getSex());
		sessionMap.put("sessionPrimaryPhone",enrollmentVO.getPrimaryPhone());
		sessionMap.put("sessionAlternatePhone",enrollmentVO.getCellPhone());
		sessionMap.put("sessionPermanentAddrStreet",enrollmentVO.getPermanentAddrStreet());
		sessionMap.put("sessionPermanentCity",enrollmentVO.getPermanentCity());
		sessionMap.put("sessionPermanentCounty",enrollmentVO.getPermanentCounty());
		sessionMap.put("sessionPermanentState",enrollmentVO.getPermanentState());
		sessionMap.put("sessionPermanentZip",enrollmentVO.getPermanentZip());
		sessionMap.put("sessionMailingAddressRequired",enrollmentVO.getMailingAddressRequired());
		sessionMap.put("sessionMailingAddr",enrollmentVO.getMailingAddr());
		sessionMap.put("sessionMailingCity",enrollmentVO.getMailingCity());
		sessionMap.put("sessionMailingState",enrollmentVO.getMailingState());
		sessionMap.put("sessionMailingZip",enrollmentVO.getMailingzip());
		sessionMap.put("sessionEmailAddr",enrollmentVO.getEmailAddr());
		sessionMap.put("sessionCallAlert",enrollmentVO.getCallAlert());
		sessionMap.put("sessionEmailAlert",enrollmentVO.getEmailAlert());
		
		String medicareClaim = enrollmentVO.getMedicareClaim();
		if(medicareClaim.length() > 3) {
			medicareClaim = medicareClaim.substring(0,3) + "-" + medicareClaim.substring(3);
		}
		if(medicareClaim.length() > 6) {
			medicareClaim = medicareClaim.substring(0,6) + "-" + medicareClaim.substring(6);
		}
		if(medicareClaim.length() > 11) {
			medicareClaim = medicareClaim.substring(0,11) + "-" + medicareClaim.substring(11);
		}
		
		sessionMap.put("sessionMedicareClaim",medicareClaim);
		
		sessionMap.put("sessionHospitalPartA",enrollmentVO.getHospitalPartA());
		sessionMap.put("sessionHospitalPartB",enrollmentVO.getHospitalPartB());
		sessionMap.put("sessionPaymentOption",enrollmentVO.getPaymentOption());
		sessionMap.put("sessionAccountHolderName",enrollmentVO.getAcctholdername());
		sessionMap.put("sessionBankName",enrollmentVO.getBankname());
		sessionMap.put("sessionAcctType",enrollmentVO.getAcctType());
		sessionMap.put("sessionRoutingNumber",enrollmentVO.getRoutingNumber());
		sessionMap.put("sessionAccountNumber",enrollmentVO.getAccountNumber());		
		sessionMap.put("sessionMonthlyBillingFrequency",enrollmentVO.getMonthlybf());
		sessionMap.put("sessionRetiree",enrollmentVO.getRetiree());
		
		//Begin: Modified for IFOX-00414491
		sessionMap.put("sessionCoveringSpouseOrDependent",enrollmentVO.getCoveringSpouseOrDependent());
		sessionMap.put("sessionCoveringSpouseOrDependentLastName",enrollmentVO.getCoveringSpouseOrDependentLastName());
		sessionMap.put("sessionCoveringSpouseOrDependentFirstName",enrollmentVO.getCoveringSpouseOrDependentFirstName());
		sessionMap.put("sessionCoveringSpouseOrDependentMiddleName",enrollmentVO.getCoveringSpouseOrDependentMiddleName());
		sessionMap.put("sessionCoveringSpouseOrDependentEmployeeName",enrollmentVO.getCoveringSpouseOrDependentEmployeeName());
		
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetiree",enrollmentVO.getSurvivingSpouseCitySanDiegoRetiree());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeLastName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeLastName());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeFirstName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeFirstName());
		sessionMap.put("sessionSurvivingSpouseCitySanDiegoRetireeMiddleName",enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeMiddleName());
		//End: Modified for IFOX-00414491
		
		sessionMap.put("sessionRetiredate",enrollmentVO.getRetiredate());
		sessionMap.put("sessionRetirename",enrollmentVO.getRetirename());
		sessionMap.put("sessionMeddependsp",enrollmentVO.getMeddependsp());
		sessionMap.put("sessionDependentSpouse",enrollmentVO.getDependentSpouse());
		sessionMap.put("sessionDependentOther",enrollmentVO.getDependentOther());
		sessionMap.put("sessionSpouseWork",enrollmentVO.getSpousework());		
		sessionMap.put("sessionRenalDisease",enrollmentVO.getRenalDisease());
		sessionMap.put("sessionESRDContact",enrollmentVO.getEsrdcontact());
		sessionMap.put("sessionVABenefits",enrollmentVO.getVaBenefits());
		sessionMap.put("sessionNameOfCoverage",enrollmentVO.getNameOfCov());
		sessionMap.put("sessionIdOfCoverage",enrollmentVO.getIdOfCov());
		sessionMap.put("sessionGroupOfCoverage",enrollmentVO.getGroupOfCov());
		sessionMap.put("sessionPrescriptionDrug",enrollmentVO.getPrescriptionDrug());
		sessionMap.put("sessionNameOfInst",enrollmentVO.getNameOfInst());
		sessionMap.put("sessionPhoneOfInst",enrollmentVO.getPhoneOfInst());
		sessionMap.put("sessionAddressOfInst",enrollmentVO.getAddrOfInst());
		sessionMap.put("sessionHlthcovType",enrollmentVO.getHlthcovType());
		sessionMap.put("sessionHlthcovInscomp",enrollmentVO.getHlthcovInscomp());	
		sessionMap.put("sessionPCPName",enrollmentVO.getPcpName());
		sessionMap.put("sessionPPCPMedicalGroupName",enrollmentVO.getPcpMedicalGroupName());
		sessionMap.put("sessionExistingPatient",enrollmentVO.getExistingp());	
		sessionMap.put("sessionLanguage",enrollmentVO.getLanguage());
		sessionMap.put("sessionLanguageValue",enrollmentVO.getLanguageValue());
		sessionMap.put("sessionC20",enrollmentVO.getC20());
		sessionMap.put("sessionC1",enrollmentVO.getC1());
		sessionMap.put("sessionC2",enrollmentVO.getC2());
		sessionMap.put("sessionAttestation2",enrollmentVO.getAttestation2());
		sessionMap.put("sessionC3",enrollmentVO.getC3());
		sessionMap.put("sessionAttestation3",enrollmentVO.getAttestation3());
		sessionMap.put("sessionC4",enrollmentVO.getC4());
		sessionMap.put("sessionAttestation4",enrollmentVO.getAttestation4());
		sessionMap.put("sessionC5",enrollmentVO.getC5());
		sessionMap.put("sessionAttestation5",enrollmentVO.getAttestation5());
		sessionMap.put("sessionC6",enrollmentVO.getC6());
		sessionMap.put("sessionC7",enrollmentVO.getC7());
		sessionMap.put("sessionC8",enrollmentVO.getC8());
		sessionMap.put("sessionAttestation8",enrollmentVO.getAttestation8());
		sessionMap.put("sessionC9",enrollmentVO.getC9());
		sessionMap.put("sessionAttestation9",enrollmentVO.getAttestation9());
		sessionMap.put("sessionC10",enrollmentVO.getC10());
		sessionMap.put("sessionAttestation10",enrollmentVO.getAttestation10());
		sessionMap.put("sessionC11",enrollmentVO.getC11());
		sessionMap.put("sessionAttestation11",enrollmentVO.getAttestation11());
		sessionMap.put("sessionC12",enrollmentVO.getC12());
		sessionMap.put("sessionAttestation12",enrollmentVO.getAttestation12());
		sessionMap.put("sessionC13",enrollmentVO.getC13());
		sessionMap.put("sessionC14",enrollmentVO.getC14());
		sessionMap.put("sessionC15",enrollmentVO.getC15());
		sessionMap.put("sessionAttestation15",enrollmentVO.getAttestation15());
		sessionMap.put("sessionC16",enrollmentVO.getC16());
		sessionMap.put("sessionC16Attestation",enrollmentVO.getC16Attestation());		
		sessionMap.put("sessionAttestation16",enrollmentVO.getAttestation16());
		sessionMap.put("sessionNameSignature",enrollmentVO.getNameSignature());
		sessionMap.put("sessionDigiSignature",enrollmentVO.getDigitalSignature());
		sessionMap.put("sessionTodaysDate",enrollmentVO.getTodaysDate());
		sessionMap.put("sessionAuthorizedRep",enrollmentVO.getAuthorizedRep());
		sessionMap.put("sessionAuthorizedRepName",enrollmentVO.getAuthorizedrepname());
		sessionMap.put("sessionAuthorizedRelationship",enrollmentVO.getAuthorizedreprelationship());
		sessionMap.put("sessionAuthorizedRepAddress",enrollmentVO.getAuthorizedrepaddress());
		sessionMap.put("sessionAuthorizedRepPhone",enrollmentVO.getAuthorizedrepphone());
		sessionMap.put("sessionAgentAssistingEnrollment",enrollmentVO.getAgentAssistingEnrollment());
		sessionMap.put("sessionNameOfAgent",enrollmentVO.getNameAgent());
		sessionMap.put("sessionAgentLicense",enrollmentVO.getAgentLicense());
		
		//Begin: 2019 web app changes - IFOX-00406768
		sessionMap.put("sessionC21",enrollmentVO.getC21());
		sessionMap.put("sessionC22",enrollmentVO.getC22());
		sessionMap.put("sessionAttestation22",enrollmentVO.getAttestation22());
		sessionMap.put("sessionC23",enrollmentVO.getC23());
		sessionMap.put("sessionAttestation23",enrollmentVO.getAttestation23());
		sessionMap.put("sessionC24",enrollmentVO.getC24());
		sessionMap.put("sessionAttestation24",enrollmentVO.getAttestation24());
		sessionMap.put("sessionC25",enrollmentVO.getC25());
		//End: 2019 web app changes - IFOX-00406768
		
	}
	//End: Modified for IFOX-00414491
	
	
	/**IFOX-00403984 Changes Stop.*/
	public static void mapVOTOSessionSDAGC(EnrollmentVO enrollmentVO , ModelAndView sessionModelViewObject){
		sessionModelViewObject.addObject("sessionPrefix",enrollmentVO.getPrefix());
		sessionModelViewObject.addObject("sessionFirstName",enrollmentVO.getFirstName());
		sessionModelViewObject.addObject("sessionLastName",enrollmentVO.getLastName());
		sessionModelViewObject.addObject("sessionMiddleInitial",enrollmentVO.getMiddleInitial());
		sessionModelViewObject.addObject("sessionBirthDate",enrollmentVO.getBirthDate());
		sessionModelViewObject.addObject("sessionSex",enrollmentVO.getSex());
		sessionModelViewObject.addObject("sessionPrimaryPhone",enrollmentVO.getPrimaryPhone());
		sessionModelViewObject.addObject("sessionAlternatePhone",enrollmentVO.getCellPhone());
		sessionModelViewObject.addObject("sessionPermanentAddrStreet",enrollmentVO.getPermanentAddrStreet());
		sessionModelViewObject.addObject("sessionPermanentCity",enrollmentVO.getPermanentCity());
		sessionModelViewObject.addObject("sessionPermanentCounty",enrollmentVO.getPermanentCounty());
		sessionModelViewObject.addObject("sessionPermanentState",enrollmentVO.getPermanentState());
		sessionModelViewObject.addObject("sessionPermanentZip",enrollmentVO.getPermanentZip());
		sessionModelViewObject.addObject("sessionMailingAddressRequired",enrollmentVO.getMailingAddressRequired());
		sessionModelViewObject.addObject("sessionMailingAddr",enrollmentVO.getMailingAddr());
		sessionModelViewObject.addObject("sessionMailingCity",enrollmentVO.getMailingCity());
		sessionModelViewObject.addObject("sessionMailingState",enrollmentVO.getMailingState());
		sessionModelViewObject.addObject("sessionMailingZip",enrollmentVO.getMailingzip());
		sessionModelViewObject.addObject("sessionEmailAddr",enrollmentVO.getEmailAddr());
		sessionModelViewObject.addObject("sessionEmailAlert",enrollmentVO.getEmailAlert());
		sessionModelViewObject.addObject("sessionMedicareClaim",enrollmentVO.getMedicareClaim());
		sessionModelViewObject.addObject("sessionHospitalPartA",enrollmentVO.getHospitalPartA());
		sessionModelViewObject.addObject("sessionHospitalPartB",enrollmentVO.getHospitalPartB());
		sessionModelViewObject.addObject("sessionPaymentOption",enrollmentVO.getPaymentOption());
		sessionModelViewObject.addObject("sessionAccountHolderName",enrollmentVO.getAcctholdername());
		sessionModelViewObject.addObject("sessionBankName",enrollmentVO.getBankname());
		sessionModelViewObject.addObject("sessionAcctType",enrollmentVO.getAcctType());
		sessionModelViewObject.addObject("sessionRoutingNumber",enrollmentVO.getRoutingNumber());
		sessionModelViewObject.addObject("sessionAccountNumber",enrollmentVO.getAccountNumber());
		sessionModelViewObject.addObject("sessionMonthlyBillingFrequency",enrollmentVO.getMonthlybf());
		sessionModelViewObject.addObject("sessionRenalDisease",enrollmentVO.getRenalDisease());
		sessionModelViewObject.addObject("sessionESRDContact",enrollmentVO.getEsrdcontact());
		sessionModelViewObject.addObject("sessionVABenefits",enrollmentVO.getVaBenefits());
		sessionModelViewObject.addObject("sessionNameOfCoverage",enrollmentVO.getNameOfCov());
		sessionModelViewObject.addObject("sessionIdOfCoverage",enrollmentVO.getIdOfCov());
		sessionModelViewObject.addObject("sessionGroupOfCoverage",enrollmentVO.getGroupOfCov());
		sessionModelViewObject.addObject("sessionMedicaidPrg",enrollmentVO.getMedicaidprg());
		sessionModelViewObject.addObject("sessionMedicaidNbr",enrollmentVO.getMedicaidNbr());
		sessionModelViewObject.addObject("sessionPrescriptionDrug",enrollmentVO.getPrescriptionDrug());
		sessionModelViewObject.addObject("sessionNameOfInst",enrollmentVO.getNameOfInst());
		sessionModelViewObject.addObject("sessionPhoneOfInst",enrollmentVO.getPhoneOfInst());
		sessionModelViewObject.addObject("sessionAddressOfInst",enrollmentVO.getAddrOfInst());
		sessionModelViewObject.addObject("sessionSpouseWork",enrollmentVO.getSpousework());
		sessionModelViewObject.addObject("sessionPCPName",enrollmentVO.getPcpName());
		sessionModelViewObject.addObject("sessionPPCPMedicalGroupName",enrollmentVO.getPcpMedicalGroupName());
		sessionModelViewObject.addObject("sessionExistingPatient",enrollmentVO.getExistingp());
		sessionModelViewObject.addObject("sessionLanguage",enrollmentVO.getLanguage());
		sessionModelViewObject.addObject("sessionLanguageValue",enrollmentVO.getLanguageValue());
		sessionModelViewObject.addObject("sessionAep",enrollmentVO.getAep());
		sessionModelViewObject.addObject("sessionC1",enrollmentVO.getC1());
		sessionModelViewObject.addObject("sessionC2",enrollmentVO.getC2());
		sessionModelViewObject.addObject("sessionAttestation2",enrollmentVO.getAttestation2());
		sessionModelViewObject.addObject("sessionC3",enrollmentVO.getC3());
		sessionModelViewObject.addObject("sessionAttestation3",enrollmentVO.getAttestation3());
		sessionModelViewObject.addObject("sessionC4",enrollmentVO.getC4());
		sessionModelViewObject.addObject("sessionAttestation4",enrollmentVO.getAttestation4());
		sessionModelViewObject.addObject("sessionC5",enrollmentVO.getC5());
		sessionModelViewObject.addObject("sessionAttestation5",enrollmentVO.getAttestation5());
		sessionModelViewObject.addObject("sessionC6",enrollmentVO.getC6());
		sessionModelViewObject.addObject("sessionC7",enrollmentVO.getC7());
		sessionModelViewObject.addObject("sessionC8",enrollmentVO.getC8());
		sessionModelViewObject.addObject("sessionAttestation8",enrollmentVO.getAttestation8());
		sessionModelViewObject.addObject("sessionC9",enrollmentVO.getC9());
		sessionModelViewObject.addObject("sessionAttestation9",enrollmentVO.getAttestation9());
		sessionModelViewObject.addObject("sessionC10",enrollmentVO.getC10());
		sessionModelViewObject.addObject("sessionAttestation10",enrollmentVO.getAttestation10());
		sessionModelViewObject.addObject("sessionC11",enrollmentVO.getC11());
		sessionModelViewObject.addObject("sessionAttestation11",enrollmentVO.getAttestation11());
		sessionModelViewObject.addObject("sessionC12",enrollmentVO.getC12());
		sessionModelViewObject.addObject("sessionAttestation12",enrollmentVO.getAttestation12());
		sessionModelViewObject.addObject("sessionC13",enrollmentVO.getC13());
		sessionModelViewObject.addObject("sessionC14",enrollmentVO.getC14());
		sessionModelViewObject.addObject("sessionC15",enrollmentVO.getC15());
		sessionModelViewObject.addObject("sessionAttestation15",enrollmentVO.getAttestation15());
		sessionModelViewObject.addObject("sessionC16",enrollmentVO.getC16());
		sessionModelViewObject.addObject("sessionAttestation16",enrollmentVO.getAttestation16());
		sessionModelViewObject.addObject("sessionNameSignature",enrollmentVO.getNameSignature());
		sessionModelViewObject.addObject("sessionDigiSignature",enrollmentVO.getDigitalSignature());
		sessionModelViewObject.addObject("sessionTodaysDate",enrollmentVO.getTodaysDate());
		sessionModelViewObject.addObject("sessionAuthorizedRep",enrollmentVO.getAuthorizedRep());
		sessionModelViewObject.addObject("sessionAuthorizedRepName",enrollmentVO.getAuthorizedrepname());
		sessionModelViewObject.addObject("sessionAuthorizedRelationship",enrollmentVO.getAuthorizedreprelationship());
		sessionModelViewObject.addObject("sessionAuthorizedRepAddress",enrollmentVO.getAuthorizedrepaddress());
		sessionModelViewObject.addObject("sessionAuthorizedRepPhone",enrollmentVO.getAuthorizedrepphone());
		sessionModelViewObject.addObject("sessionAgentAssistingEnrollment",enrollmentVO.getAgentAssistingEnrollment());
		sessionModelViewObject.addObject("sessionNameOfAgent",enrollmentVO.getNameAgent());
		sessionModelViewObject.addObject("sessionAgentLicense",enrollmentVO.getAgentLicense());
		
		//Begin: 2019 web app changes - IFOX-00406768
		sessionModelViewObject.addObject("sessionC21",enrollmentVO.getC21());
		sessionModelViewObject.addObject("sessionC22",enrollmentVO.getC22());
		sessionModelViewObject.addObject("sessionAttestation22",enrollmentVO.getAttestation22());
		sessionModelViewObject.addObject("sessionC23",enrollmentVO.getC23());
		sessionModelViewObject.addObject("sessionAttestation23",enrollmentVO.getAttestation23());
		sessionModelViewObject.addObject("sessionC24",enrollmentVO.getC24());
		sessionModelViewObject.addObject("sessionAttestation24",enrollmentVO.getAttestation24());
		sessionModelViewObject.addObject("sessionC25",enrollmentVO.getC25());
		//End: 2019 web app changes - IFOX-00406768
		
	}
	public static void mapVOTOSessionSDAGC(EnrollmentVO enrollmentVO , HttpServletRequest request){
		request.getSession().setAttribute("sessionPrefix",enrollmentVO.getPrefix());
		request.getSession().setAttribute("sessionFirstName",enrollmentVO.getFirstName());
		request.getSession().setAttribute("sessionLastName",enrollmentVO.getLastName());
		request.getSession().setAttribute("sessionMiddleInitial",enrollmentVO.getMiddleInitial());
		request.getSession().setAttribute("sessionBirthDate",enrollmentVO.getBirthDate());
		request.getSession().setAttribute("sessionSex",enrollmentVO.getSex());
		request.getSession().setAttribute("sessionPrimaryPhone",enrollmentVO.getPrimaryPhone());
		request.getSession().setAttribute("sessionAlternatePhone",enrollmentVO.getCellPhone());
		request.getSession().setAttribute("sessionPermanentAddrStreet",enrollmentVO.getPermanentAddrStreet());
		request.getSession().setAttribute("sessionPermanentCity",enrollmentVO.getPermanentCity());
		request.getSession().setAttribute("sessionPermanentCounty",enrollmentVO.getPermanentCounty());
		request.getSession().setAttribute("sessionPermanentState",enrollmentVO.getPermanentState());
		request.getSession().setAttribute("sessionPermanentZip",enrollmentVO.getPermanentZip());
		request.getSession().setAttribute("sessionMailingAddressRequired",enrollmentVO.getMailingAddressRequired());
		request.getSession().setAttribute("sessionMailingAddr",enrollmentVO.getMailingAddr());
		request.getSession().setAttribute("sessionMailingCity",enrollmentVO.getMailingCity());
		request.getSession().setAttribute("sessionMailingState",enrollmentVO.getMailingState());
		request.getSession().setAttribute("sessionMailingZip",enrollmentVO.getMailingzip());
		request.getSession().setAttribute("sessionEmailAddr",enrollmentVO.getEmailAddr());
		request.getSession().setAttribute("sessionEmailAlert",enrollmentVO.getEmailAlert());
		request.getSession().setAttribute("sessionMedicareClaim",enrollmentVO.getMedicareClaim());
		request.getSession().setAttribute("sessionHospitalPartA",enrollmentVO.getHospitalPartA());
		request.getSession().setAttribute("sessionHospitalPartB",enrollmentVO.getHospitalPartB());
		request.getSession().setAttribute("sessionPaymentOption",enrollmentVO.getPaymentOption());
		request.getSession().setAttribute("sessionAccountHolderName",enrollmentVO.getAcctholdername());
		request.getSession().setAttribute("sessionBankName",enrollmentVO.getBankname());
		request.getSession().setAttribute("sessionAcctType",enrollmentVO.getAcctType());
		request.getSession().setAttribute("sessionRoutingNumber",enrollmentVO.getRoutingNumber());
		request.getSession().setAttribute("sessionAccountNumber",enrollmentVO.getAccountNumber());
		request.getSession().setAttribute("sessionMonthlyBillingFrequency",enrollmentVO.getMonthlybf());
		request.getSession().setAttribute("sessionRenalDisease",enrollmentVO.getRenalDisease());
		request.getSession().setAttribute("sessionESRDContact",enrollmentVO.getEsrdcontact());
		request.getSession().setAttribute("sessionVABenefits",enrollmentVO.getVaBenefits());
		request.getSession().setAttribute("sessionNameOfCoverage",enrollmentVO.getNameOfCov());
		request.getSession().setAttribute("sessionIdOfCoverage",enrollmentVO.getIdOfCov());
		request.getSession().setAttribute("sessionGroupOfCoverage",enrollmentVO.getGroupOfCov());
		request.getSession().setAttribute("sessionMedicaidPrg",enrollmentVO.getMedicaidprg());
		request.getSession().setAttribute("sessionMedicaidNbr",enrollmentVO.getMedicaidNbr());
		request.getSession().setAttribute("sessionPrescriptionDrug",enrollmentVO.getPrescriptionDrug());
		request.getSession().setAttribute("sessionNameOfInst",enrollmentVO.getNameOfInst());
		request.getSession().setAttribute("sessionPhoneOfInst",enrollmentVO.getPhoneOfInst());
		request.getSession().setAttribute("sessionAddressOfInst",enrollmentVO.getAddrOfInst());
		request.getSession().setAttribute("sessionSpouseWork",enrollmentVO.getSpousework());
		request.getSession().setAttribute("sessionPCPName",enrollmentVO.getPcpName());
		request.getSession().setAttribute("sessionPPCPMedicalGroupName",enrollmentVO.getPcpMedicalGroupName());
		request.getSession().setAttribute("sessionExistingPatient",enrollmentVO.getExistingp());
		request.getSession().setAttribute("sessionLanguage",enrollmentVO.getLanguage());
		request.getSession().setAttribute("sessionLanguageValue",enrollmentVO.getLanguageValue());
		request.getSession().setAttribute("sessionAep",enrollmentVO.getAep());
		request.getSession().setAttribute("sessionC1",enrollmentVO.getC1());
		request.getSession().setAttribute("sessionC2",enrollmentVO.getC2());
		request.getSession().setAttribute("sessionAttestation2",enrollmentVO.getAttestation2());
		request.getSession().setAttribute("sessionC3",enrollmentVO.getC3());
		request.getSession().setAttribute("sessionAttestation3",enrollmentVO.getAttestation3());
		request.getSession().setAttribute("sessionC4",enrollmentVO.getC4());
		request.getSession().setAttribute("sessionAttestation4",enrollmentVO.getAttestation4());
		request.getSession().setAttribute("sessionC5",enrollmentVO.getC5());
		request.getSession().setAttribute("sessionAttestation5",enrollmentVO.getAttestation5());
		request.getSession().setAttribute("sessionC6",enrollmentVO.getC6());
		request.getSession().setAttribute("sessionC7",enrollmentVO.getC7());
		request.getSession().setAttribute("sessionC8",enrollmentVO.getC8());
		request.getSession().setAttribute("sessionAttestation8",enrollmentVO.getAttestation8());
		request.getSession().setAttribute("sessionC9",enrollmentVO.getC9());
		request.getSession().setAttribute("sessionAttestation9",enrollmentVO.getAttestation9());
		request.getSession().setAttribute("sessionC10",enrollmentVO.getC10());
		request.getSession().setAttribute("sessionAttestation10",enrollmentVO.getAttestation10());
		request.getSession().setAttribute("sessionC11",enrollmentVO.getC11());
		request.getSession().setAttribute("sessionAttestation11",enrollmentVO.getAttestation11());
		request.getSession().setAttribute("sessionC12",enrollmentVO.getC12());
		request.getSession().setAttribute("sessionAttestation12",enrollmentVO.getAttestation12());
		request.getSession().setAttribute("sessionC13",enrollmentVO.getC13());
		request.getSession().setAttribute("sessionC14",enrollmentVO.getC14());
		request.getSession().setAttribute("sessionC15",enrollmentVO.getC15());
		request.getSession().setAttribute("sessionAttestation15",enrollmentVO.getAttestation15());
		request.getSession().setAttribute("sessionC16",enrollmentVO.getC16());
		request.getSession().setAttribute("sessionAttestation16",enrollmentVO.getAttestation16());
		request.getSession().setAttribute("sessionNameSignature",enrollmentVO.getNameSignature());
		request.getSession().setAttribute("sessionDigiSignature",enrollmentVO.getDigitalSignature());
		request.getSession().setAttribute("sessionTodaysDate",enrollmentVO.getTodaysDate());
		request.getSession().setAttribute("sessionAuthorizedRep",enrollmentVO.getAuthorizedRep());
		request.getSession().setAttribute("sessionAuthorizedRepName",enrollmentVO.getAuthorizedrepname());
		request.getSession().setAttribute("sessionAuthorizedRelationship",enrollmentVO.getAuthorizedreprelationship());
		request.getSession().setAttribute("sessionAuthorizedRepAddress",enrollmentVO.getAuthorizedrepaddress());
		request.getSession().setAttribute("sessionAuthorizedRepPhone",enrollmentVO.getAuthorizedrepphone());
		request.getSession().setAttribute("sessionAgentAssistingEnrollment",enrollmentVO.getAgentAssistingEnrollment());
		request.getSession().setAttribute("sessionNameOfAgent",enrollmentVO.getNameAgent());
		request.getSession().setAttribute("sessionAgentLicense",enrollmentVO.getAgentLicense());
		
		//Begin: 2019 web app changes - IFOX-00406768
		request.getSession().setAttribute("sessionC21",enrollmentVO.getC21());
		request.getSession().setAttribute("sessionC22",enrollmentVO.getC22());
		request.getSession().setAttribute("sessionAttestation22",enrollmentVO.getAttestation22());
		request.getSession().setAttribute("sessionC23",enrollmentVO.getC23());
		request.getSession().setAttribute("sessionAttestation23",enrollmentVO.getAttestation23());
		request.getSession().setAttribute("sessionC24",enrollmentVO.getC24());
		request.getSession().setAttribute("sessionAttestation24",enrollmentVO.getAttestation24());
		request.getSession().setAttribute("sessionC25",enrollmentVO.getC25());
		//End: 2019 web app changes - IFOX-00406768

	}
	
	public static Map getAuthroizedRelationShips(){
		
		HashMap authorizedRelationShips = new HashMap<String, String>();
		authorizedRelationShips.put("ATY","ATTORNEY");
		authorizedRelationShips.put("DAD","FATHER");
		authorizedRelationShips.put("DEP","DEPENDENT");
		authorizedRelationShips.put("EMP","EMPLOYEE");
		authorizedRelationShips.put("FCH","FOSTER CHILD");

		authorizedRelationShips.put("FSP","FOSTER PARENT");
		authorizedRelationShips.put("GCH","GRANDCHILD");
		authorizedRelationShips.put("GFA","GRANDFATHER");
		authorizedRelationShips.put("GMA","GRANDMOTHER");
		authorizedRelationShips.put("GPR","GRANDPARENT");

		authorizedRelationShips.put("GRD","GUARDIAN");
		authorizedRelationShips.put("LIF","LIFE PARTNER");
		authorizedRelationShips.put("MOM","MOTHER");
		authorizedRelationShips.put("NCH","NATURAL CHILD");
		authorizedRelationShips.put("NN","NIECE/NEPHEW");

		authorizedRelationShips.put("OTH","OTHER");
		authorizedRelationShips.put("PAL","FRIEND");
		authorizedRelationShips.put("PHY","PHYSICIAN");
		authorizedRelationShips.put("POA","POWER OF ATTORNEY");
		authorizedRelationShips.put("REL","RELATIVE(OTHER)");

		authorizedRelationShips.put("SCH","STEP CHILD");
		authorizedRelationShips.put("SIB","SIBLING(SISTER/BROTHER)");
		authorizedRelationShips.put("SPS","SPOUSE");
		authorizedRelationShips.put("STP","STEP PARENT");
		authorizedRelationShips.put("UNK","UNKNOWN");
		
		return authorizedRelationShips;
		
		
	}
	
	private static String getAttestationValue(EnrollmentVO enrollmentVO){
		
		String[] attestations = null;
		
		String attestationCode = "";
		
		//Begin: 2019 web app changes - IFOX-00406768
		//String[] attestations = new String[16];
		if(Integer.parseInt(enrollmentVO.getPlanYear()) > 2018) {
			
			attestations = new String[21];
			attestations[0] = enrollmentVO.getC1();
			attestations[1] = enrollmentVO.getC2();
			attestations[2] = enrollmentVO.getC3();
			attestations[3] = enrollmentVO.getC4();
			attestations[4] = enrollmentVO.getC5();
			attestations[5] = enrollmentVO.getC6();
			attestations[6] = enrollmentVO.getC7();
			attestations[7] = enrollmentVO.getC8();
			attestations[8] = enrollmentVO.getC9();
			attestations[9] = enrollmentVO.getC10();
			attestations[10] = enrollmentVO.getC11();
			attestations[11] = enrollmentVO.getC12();
			attestations[12] = enrollmentVO.getC13();
			attestations[13] = enrollmentVO.getC14();
			attestations[14] = enrollmentVO.getC15();
			attestations[15] = enrollmentVO.getC16();
			
			attestations[16] = enrollmentVO.getC21();
			attestations[17] = enrollmentVO.getC22();
			attestations[18] = enrollmentVO.getC23();
			attestations[19] = enrollmentVO.getC24();
			attestations[20] = enrollmentVO.getC25();
			
		} else {
			attestations = new String[16];
			attestations[0] = enrollmentVO.getC1();
			attestations[1] = enrollmentVO.getC2();
			attestations[2] = enrollmentVO.getC3();
			attestations[3] = enrollmentVO.getC4();
			attestations[4] = enrollmentVO.getC5();
			attestations[5] = enrollmentVO.getC6();
			attestations[6] = enrollmentVO.getC7();
			attestations[7] = enrollmentVO.getC8();
			attestations[8] = enrollmentVO.getC9();
			attestations[9] = enrollmentVO.getC10();
			attestations[10] = enrollmentVO.getC11();
			attestations[11] = enrollmentVO.getC12();
			attestations[12] = enrollmentVO.getC13();
			attestations[13] = enrollmentVO.getC14();
			attestations[14] = enrollmentVO.getC15();
			attestations[15] = enrollmentVO.getC16();
		}
		//End: 2019 web app changes - IFOX-00406768
		
		for(String electionCode : attestations){
			
			if(electionCode != null && !electionCode.equals("")){
				attestationCode = electionCode;
			}else{
				continue;
			}
		}
		
		return attestationCode;
		
	}

	
	private static String getAttestationDateValue(EnrollmentVO enrollmentVO){
		
		String attestationDate = "";
		
		//Begin: 2019 web app changes - IFOX-00406768
		String[] attestationDates = null;

		if(Integer.parseInt(enrollmentVO.getPlanYear()) > 2018) {
			attestationDates = new String[14];
			attestationDates[0] = enrollmentVO.getAttestation2();
			attestationDates[1] = enrollmentVO.getAttestation3();
			attestationDates[2] = enrollmentVO.getAttestation4();
			attestationDates[3] = enrollmentVO.getAttestation5();
			attestationDates[4] = enrollmentVO.getAttestation8();
			attestationDates[5] = enrollmentVO.getAttestation9();
			attestationDates[6] = enrollmentVO.getAttestation10();
			attestationDates[7] = enrollmentVO.getAttestation11();
			attestationDates[8] = enrollmentVO.getAttestation12();
			attestationDates[9] = enrollmentVO.getAttestation15();
			attestationDates[10] = enrollmentVO.getAttestation16();

			attestationDates[11] = enrollmentVO.getAttestation22();
			attestationDates[12] = enrollmentVO.getAttestation23();
			attestationDates[13] = enrollmentVO.getAttestation24();
			
		} else {
			attestationDates = new String[11];
			attestationDates[0] = enrollmentVO.getAttestation2();
			attestationDates[1] = enrollmentVO.getAttestation3();
			attestationDates[2] = enrollmentVO.getAttestation4();
			attestationDates[3] = enrollmentVO.getAttestation5();
			attestationDates[4] = enrollmentVO.getAttestation8();
			attestationDates[5] = enrollmentVO.getAttestation9();
			attestationDates[6] = enrollmentVO.getAttestation10();
			attestationDates[7] = enrollmentVO.getAttestation11();
			attestationDates[8] = enrollmentVO.getAttestation12();
			attestationDates[9] = enrollmentVO.getAttestation15();
			attestationDates[10] = enrollmentVO.getAttestation16();
		}
		
		for(String electionCodeDate : attestationDates){
			
			if(electionCodeDate != null && !electionCodeDate.equals("")){
				attestationDate = electionCodeDate;
			}else{
				continue;
			}
		}
		
		return attestationDate;
		
	}


}
