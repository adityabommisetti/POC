package com.medicare.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class StringUtil {
	 public static String nonNullTrim(String value) {
	        if (value == null)
	            return "";
	        return value.trim();
	 }

	public static boolean nonNullnonEmpty(String value) {
		if (value == null)
			return false;
		if (value.trim().isEmpty())
			return false;
		return true;
	}
	 public static String checkNullOrTrim(String  oldValue){
		 
		 String newValue = "";
		 if(oldValue != null ){
			 return oldValue;
		 }else{
			 return newValue;
		 }
	 }

	 public static String getDateMMDDYYYY(Date date){
		 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		 String formattedDate = "";
		 if(date != null){
			 formattedDate = sdf.format(date);
		 }else{
			 formattedDate = sdf.format(new Date());
		 }
		 return formattedDate;
	 }

}
