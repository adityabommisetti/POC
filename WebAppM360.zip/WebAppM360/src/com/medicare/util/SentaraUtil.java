package com.medicare.util;



import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;

import com.medicare.helper.M360AppUtil;
import com.medicare.model.UserAccountDetails;
import com.medicare.model.UserAddress;
import com.medicare.model.UserAgentDetails;
import com.medicare.model.UserDetails;
import com.medicare.model.UserLegalRepDetails;
import com.medicare.model.UserOtherPolicyDetails;
import com.medicare.model.UserPolicyDetails;
import com.medicare.vo.AgreeDetailsVO;
import com.medicare.vo.AttestationDetailsVO;
import com.medicare.vo.PolicyDetailsVO;
import com.medicare.vo.UserDetailsVO;

public class SentaraUtil {

	private final static Logger LOGGER = Logger.getLogger(SentaraUtil.class.getName());

	private final static String customerId = "HCF0232";

	/**
	 * @param request
	 * @return
	 * @throws ParseException
	 */
	public static UserDetails getUserDetailsObject(HttpServletRequest request, HttpServletResponse response,int seqNum) {

		LOGGER.info(" Start : In getUserDetailsObject() method of SentaraUtil class");

		UserDetails userDetails = new UserDetails();

		UserDetailsVO userDetailsVO = (UserDetailsVO) request.getSession().getAttribute("userDetailsObjForm1");
		PolicyDetailsVO policyDetailsVO = (PolicyDetailsVO) request.getSession().getAttribute("policyDetailsObjForm1");
		AttestationDetailsVO attestationDetailsVO = (AttestationDetailsVO) request.getSession()
				.getAttribute("attestationDetailsObjForm1");
		AgreeDetailsVO agreeDetailsVO = (AgreeDetailsVO) request.getSession().getAttribute("agreeDetailsObjForm1");

		byte[] ps = Base64.decodeBase64((byte[]) request.getSession().getAttribute("pdfSaveenroll"));

		// to get the sq num
		// int seqNum = (Integer) request.getSession().getAttribute("seqNum");
		/*int seqNum = 1;
		try {
			seqNum = M360AppUtil.getSequenecNumber();
		} catch (SQLException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}*/
		System.out.println("seqnum in sentaara util" + seqNum);
		userDetails.setUserId(seqNum);

		userDetails.setPdfBlob(ps);
		// userDetails.setPdfBlob(data);
		// for 2015 application
		System.out.println("campaignID" + userDetailsVO.getCampaignId());
		System.out.println("contrtacid" + userDetailsVO.getContractId());
		System.out.println("effectivedate" + userDetailsVO.getEffDate());
		System.out.println("braille" + attestationDetailsVO.getPreferBraille());
		System.out.println("audiotape" + agreeDetailsVO.getPreferAudioTape());
		System.out.println("broke application" + agreeDetailsVO.getWebtelApp());

		if (userDetailsVO.getCampaignId() != null && !userDetailsVO.getCampaignId().isEmpty()) {
			userDetails.setCampaignId(getValue(userDetailsVO.getCampaignId()));
		} else {
			userDetails.setCampaignId(" ");
		}
		/*
		if (userDetailsVO.getContractId() != null && !userDetailsVO.getContractId().isEmpty()) {
			userDetails.setContractId(getValue(userDetailsVO.getContractId()));
		} else {
			userDetails.setContractId(" ");
		}
		*/
		userDetails.setCustomerId(customerId);
		userDetails.setEffDate(formatDate(userDetailsVO.getEffDate()));
		userDetails.setIsAudipTap(getValue(agreeDetailsVO.getPreferAudioTape()));
		userDetails.setIsBraille(getValue(attestationDetailsVO.getPreferBraille()));
		userDetails.setBrokerApp(getValue(agreeDetailsVO.getWebtelApp()));
		userDetails.setSignatureName("");
		userDetails.setSignatureRepName("");
		
		userDetails.setEemFlag("N");
		
		//userDetails.setOptimaPlan("001");
		userDetails.setContractId( (String) request.getSession().getAttribute("planId") );
		userDetails.setOptimaPlan( (String) request.getSession().getAttribute("pbpId") );
		
		//userDetails.setOptimaPlan(getValue(userDetailsVO.getOptimaMedicare()));
		userDetails.setFirstName(getValue(userDetailsVO.getFirstName().toUpperCase()));
		userDetails.setLastName(getValue(userDetailsVO.getLastName().toUpperCase()));
		userDetails.setMiddleInitial(getValue(userDetailsVO.getMiddleInitial().toUpperCase()));
		userDetails.setSuffix(getValue(userDetailsVO.getSuffix()));
		userDetails.setBirthDate(formatDate(userDetailsVO.getBirthDate()));
		// userDetails.setBirthDate(Date(userDetailsVO.getBirthDate()));
		userDetails.setSex(getValue(userDetailsVO.getSex()));
		userDetails.setHomePhneNum(getValue(userDetailsVO.getHomePhNumber()));
		System.out.println("alt ph num" + userDetailsVO.getAltrPhNumber());
		userDetails.setAltrPhneNum(getValue(userDetailsVO.getAltrPhNumber()));
		userDetails.setEmailAddr(getValue(userDetailsVO.getEmailAddr()));
		userDetails.setEmrgContactName(getValue(userDetailsVO.getEmergencyCont()));
		userDetails.setRelationship(getValue(userDetailsVO.getRelationYou()));
		userDetails.setEmrgPhneNum(getValue(userDetailsVO.getEmergPhNum()));
		userDetails.setPrimaryPhysician(getValue(userDetailsVO.getPhysician()));
		System.out.println("physician whithout encryption" + userDetailsVO.getPhysician());
		System.out.println("physician" + getValue(userDetailsVO.getPhysician()));
		
		/* IFOX-00419836 2020 AEP changes.START*/
		if(StringUtil.nonNullnonEmpty(getValue(policyDetailsVO.getPhysician())) 
				&& Integer.parseInt(userDetailsVO.getPlanYear()) >= 2020){
			userDetails.setPrimaryPhysician(getValue(policyDetailsVO.getPhysician()));
		}
		/* IFOX-00419836 2020 AEP changes.END*/
		
		// userDetails.setPrimaryPhysician("JAIN,KIRN");
		userDetails.setMedicareClaimNum(getValue(userDetailsVO.getMediacrdNumber()));
		userDetails.setMedicareName(getValue(userDetailsVO.getNameBeneficiary()));
		userDetails.setMedicareSex(getValue(userDetailsVO.getBeneficiarySex()));
		userDetails.setHospitalDate(formatDate(userDetailsVO.getHospitalDate()));
		userDetails.setMedicalDate(formatDate(userDetailsVO.getMedicalDate()));
		userDetails.setAccptAggrDate(formatDate(agreeDetailsVO.getTodayDate()));
		userDetails.setEmailAddrFormat(getValue(agreeDetailsVO.getPreferEmail()));
		userDetails.setIsCdFormat(getValue(agreeDetailsVO.getPreferCd()));
		userDetails.setIsLprintFormat(getValue(attestationDetailsVO.getPreferlargePrint()));
		userDetails.setRenalDisease(getValue(policyDetailsVO.getRenalDisease()));
		if (agreeDetailsVO.getTodayDate() != null && !agreeDetailsVO.getTodayDate().isEmpty()) {
			userDetails.setIsAgree(getValue("Y"));
		} else {
			userDetails.setIsAgree(getValue("N"));
		}

		userDetails.setApplicationStatus("S");

		String timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime());
		Timestamp ts = Timestamp.valueOf(timeStamp);
		// Timestamp ts = Timestamp.valueOf("2014-10-08 11:57:18.882672");
		System.out.println("ts" + ts);
		// userDetails.setCreatedDate("2014-10-08 11:57:18.882672");
		userDetails.setCreatedDate(new Date());

		// User Address

		Set<UserAddress> userAddressesSet = new HashSet<UserAddress>();
		UserAddress userAddress = null;

		userAddress = new UserAddress();
		userAddress.setAddressId(seqNum);
		userAddress.setUserId(seqNum);
		userAddress.setPermAddress1(getValue(userDetailsVO.getPermanentAddr()));
		userAddress.setPermAddress2(getValue(userDetailsVO.getPermanentStrt()));
		userAddress.setPermApartment(getValue(userDetailsVO.getPermanentApt()));
		userAddress.setPermCity(getValue(userDetailsVO.getPermanentCity()));
		userAddress.setPermState(getValue(userDetailsVO.getPermanentState()));
		userAddress.setPermZipCode(getValue(userDetailsVO.getPermanentZip()));
		userAddress.setMailAddress1(getValue(userDetailsVO.getMailingAddr()));
		userAddress.setMailAddress2(getValue(userDetailsVO.getMailingStrt()));
		userAddress.setMailApartment(getValue(userDetailsVO.getMailingApt()));
		userAddress.setMailCity(getValue(userDetailsVO.getMailingCity()));
		userAddress.setMailState(getValue(userDetailsVO.getMailingState()));
		userAddress.setMailZipCode(getValue(userDetailsVO.getMailingZip()));
		userAddress.setCustomerId(customerId);

		userAddressesSet.add(userAddress);

		// user accounts

		Set<UserAccountDetails> userAccountDetailsSet = new HashSet<UserAccountDetails>();
		UserAccountDetails userAccountDetail = new UserAccountDetails();
		userAccountDetail.setAcntId(seqNum);
		userAccountDetail.setUserId(seqNum);
		userAccountDetail.setCustomerId(getValue(policyDetailsVO.getCustomerId()));

		System.out.println("account NAme" + policyDetailsVO.getAccountHolderName());
		userAccountDetail.setAcntName(getValue(policyDetailsVO.getAccountHolderName()));

		userAccountDetail.setIsAutoDeduct(getValue(policyDetailsVO.getAutoDeduction()));
		if (null == policyDetailsVO.getPaymentOption()) {
			userAccountDetail.setIsEtf(getValue(null));
			userAccountDetail.setIsMonthlyBill(getValue(null));
		} else if ("D".equalsIgnoreCase(policyDetailsVO.getPaymentOption())) {
			userAccountDetail.setIsEtf(getValue(null));
			userAccountDetail.setIsMonthlyBill(getValue("D"));
		} else if ("S".equalsIgnoreCase(policyDetailsVO.getPaymentOption())) {
			userAccountDetail.setIsEtf(getValue("S"));
			userAccountDetail.setIsMonthlyBill(getValue(null));
		}else if ("R".equalsIgnoreCase(policyDetailsVO.getPaymentOption())) {
			userAccountDetail.setIsEtf(getValue("R"));
			userAccountDetail.setIsMonthlyBill(getValue(null));
		}else {
			userAccountDetail.setIsEtf(getValue(null));
			userAccountDetail.setIsMonthlyBill(getValue(null));
		}
		userAccountDetail.setBankRtingNum(getValue(policyDetailsVO.getBankRoutingNumber()));
		userAccountDetail.setBankAcctNum(getValue(policyDetailsVO.getBankAccountNumber()));
		userAccountDetailsSet.add(userAccountDetail);

		// user policy Details

		Set<UserPolicyDetails> userPolicyDetailsSet = new HashSet<UserPolicyDetails>();
		UserPolicyDetails userPolicyDetail = new UserPolicyDetails();
		userPolicyDetail.setPolicyId(seqNum);
		userPolicyDetail.setUserId(seqNum);
		userPolicyDetail.setPlanName(getValue(policyDetailsVO.getPalnName()));
		userPolicyDetail.setPolicyNumber(getValue(policyDetailsVO.getPolicyNumber()));
		userPolicyDetail.setBeginningDate(formatDate(policyDetailsVO.getBeginingDate()));

		//Begin: Added for IFOX-00390114
		if(nonNullTrim(policyDetailsVO.getStateMedicaid()).equals("Y"))
			userPolicyDetail.setStateMedicaid("Y");
		else
			userPolicyDetail.setStateMedicaid("N");
		
		if(nonNullTrim(policyDetailsVO.getMedicaidNumber()).equals(""))
			userPolicyDetail.setMedicaidNumber(" ");
		else
			userPolicyDetail.setMedicaidNumber(policyDetailsVO.getMedicaidNumber());
		//End: Added for IFOX-00390114

		//Begin: Added for IFOX-00390786 (Phase-II)
		if(nonNullTrim(policyDetailsVO.getInstituteName()).length() == 6)
			userPolicyDetail.setInstituteId(policyDetailsVO.getInstituteName());
		else
			userPolicyDetail.setInstituteId("");
		System.out.println(" Institutional Id [" + userPolicyDetail.getInstituteId() + "] ");
		//End: Added for IFOX-00390786 (Phase-II)
		if (agreeDetailsVO.getEligibleEnroll() != null) {
			userPolicyDetail.setIsAnulElgbEnroll(agreeDetailsVO.getEligibleEnroll());
		} else {
			userPolicyDetail.setIsAnulElgbEnroll("N");
		}
		userPolicyDetail.setNewElgbDate(formatDate(agreeDetailsVO.getNewlyEligbleMedicare()));

		userPolicyDetail.setLeavingCovrgDate(formatDate(agreeDetailsVO.getLeavingEmployerCoverage()));

		userPolicyDetail.setRecentMovedDate(formatDate(agreeDetailsVO.getRecentMovedOption()));

		userPolicyDetail.setLeftPaceDate(formatDate(agreeDetailsVO.getRecntLeftPace()));

		userPolicyDetail.setIsBelongStatePharmcy(getValue(agreeDetailsVO.getBelongStatePharmacy()));

		userPolicyDetail.setBackUsDate(formatDate(agreeDetailsVO.getMovedBackUs()));

		userPolicyDetail.setStateMedicardNum(getValue(agreeDetailsVO.getMedicardNumber()));

		userPolicyDetail.setMovedOutFacilityDate(formatDate(agreeDetailsVO.getOutLongTermFacility()));

		//Below code commented for IFOX-00390786 (Phase-II)
		/*
		userPolicyDetail.setNameInstitution(getValue(agreeDetailsVO.getNameOfInst()));

		userPolicyDetail.setPhoneNumber(getValue(agreeDetailsVO.getPhNum()));

		userPolicyDetail.setAddressInstitution(getValue(agreeDetailsVO.getAdressInstStreet()));

		userPolicyDetail.setAddressInstitutionStreet(getValue(agreeDetailsVO.getAdressInstNumber()));
		*/

		userPolicyDetail.setLostCoverageDate(formatDate(agreeDetailsVO.getRecentlyCreditable()));

		userPolicyDetail.setPayPrescriptionDate(formatDate(agreeDetailsVO.getRecieveMedicareDrugs()));

		userPolicyDetail.setNoElgbDrugsDate(formatDate(agreeDetailsVO.getNoEligbPrescDrugs()));

		userPolicyDetail.setOutsidePlanDate(formatDate(agreeDetailsVO.getRecntMovedOutSide()));

		userPolicyDetail.setIsPlanContractCoverage(getValue(agreeDetailsVO.getPlanEndingContract()));

		userPolicyDetail.setIsNoneStatements(getValue(agreeDetailsVO.getNoneApplyMe()));

		userPolicyDetail.setSpecialPlanDate(formatDate(agreeDetailsVO.getNoEligSpecial()));

		userPolicyDetail.setCustomerId(customerId);

		userPolicyDetail.setOtherReason(getValue(agreeDetailsVO.getOtherReasons()));
		
		//Begin: Added for IFOX-00390786 (Phase-II)
		userPolicyDetail.setLongTermFacilityIndicator(nonNullTrim(policyDetailsVO.getNursingHome()));
		userPolicyDetail.setSpouseWorkIndicator(nonNullTrim(policyDetailsVO.getSpouse()));
		userPolicyDetail.setNameInstitution(nonNullTrim(policyDetailsVO.getInstituteName()));
		userPolicyDetail.setAddressInstitution(nonNullTrim(policyDetailsVO.getInstituteAddress()));
		userPolicyDetail.setAddressInstitutionStreet(nonNullTrim(policyDetailsVO.getInstituteOtherAddress()));
		userPolicyDetail.setPhoneNumber(nonNullTrim(policyDetailsVO.getInstitutePhone()));
		
		if(null == agreeDetailsVO.getUnionCoverage() || agreeDetailsVO.getUnionCoverage().trim().equals(""))
			userPolicyDetail.setUnionCoverageDate(null);
		else
			userPolicyDetail.setUnionCoverageDate(formatDate(agreeDetailsVO.getUnionCoverage()));
		//End: Added for IFOX-00390786 (Phase-II)

		
		//Begin: 2019 Attestation Changes
		userPolicyDetail.setMAOEPChange(getValue(agreeDetailsVO.getMAOEPChange()));
		
		userPolicyDetail.setChangeInMedicaid(
				nonNullTrim(agreeDetailsVO.getChangeInMedicaid()).equals("") ? null : formatDate(agreeDetailsVO.getChangeInMedicaid()));

		userPolicyDetail.setChangeInExtraHelp(
				nonNullTrim(agreeDetailsVO.getChangeInExtraHelp()).equals("") ? null : formatDate(agreeDetailsVO.getChangeInExtraHelp()));

		userPolicyDetail.setChangeInMedicare(
				nonNullTrim(agreeDetailsVO.getChangeInMedicare()).equals("") ? null : formatDate(agreeDetailsVO.getChangeInMedicare()));
		
		userPolicyDetail.setAffectedByDisaster(getValue(agreeDetailsVO.getAffectedByDisaster()));
		//End: 2019 Attestation Changes
		
		
		userPolicyDetailsSet.add(userPolicyDetail);

		// user other policy details

		Set<UserOtherPolicyDetails> userOtherPolicyDetailsSet = new HashSet<UserOtherPolicyDetails>();
		UserOtherPolicyDetails userOtherPolicyDetails = null;
		int id = seqNum * 3;
		userOtherPolicyDetails = new UserOtherPolicyDetails();
		userOtherPolicyDetails.setPolicyId(id);
		userOtherPolicyDetails.setUserId(seqNum);
		userOtherPolicyDetails.setCoverageType("MEDICAL");
		userOtherPolicyDetails.setCoverageGroup(getValue(policyDetailsVO.getMedicalGroupCoverage()));
		userOtherPolicyDetails.setCoverageName(getValue(policyDetailsVO.getMedicalNameCoverage()));
		userOtherPolicyDetails.setCoverageId(getValue(policyDetailsVO.getMedicalIdCoverage()));
		userOtherPolicyDetails.setCoveragePeriod(getValue(policyDetailsVO.getMedicalCoveragePeriod()));
		userOtherPolicyDetails.setCustomerId(customerId);
		userOtherPolicyDetailsSet.add(userOtherPolicyDetails);

		userOtherPolicyDetails = new UserOtherPolicyDetails();
		userOtherPolicyDetails.setPolicyId(id + 1);
		userOtherPolicyDetails.setCoverageType("MEDICALOTHER");
		userOtherPolicyDetails.setCoverageGroup(getValue(policyDetailsVO.getOtherMedicalGroupCoverage()));
		userOtherPolicyDetails.setCoverageName(getValue(policyDetailsVO.getOtherMedicalNameCoverage()));
		userOtherPolicyDetails.setCoverageId(getValue(policyDetailsVO.getOtherMedicalIdCoverage()));
		userOtherPolicyDetails.setCoveragePeriod(getValue(policyDetailsVO.getOtherMedicalCoveragePeriod()));
		userOtherPolicyDetails.setCustomerId(customerId);
		userOtherPolicyDetailsSet.add(userOtherPolicyDetails);

		userOtherPolicyDetails = new UserOtherPolicyDetails();
		userOtherPolicyDetails.setPolicyId(id + 2);
		userOtherPolicyDetails.setCoverageType("DRUG");
		userOtherPolicyDetails.setCoverageGroup(getValue(policyDetailsVO.getDurgGroupCoverage()));
		userOtherPolicyDetails.setCoverageName(getValue(policyDetailsVO.getDurgNameCoverage()));
		userOtherPolicyDetails.setCoverageId(getValue(policyDetailsVO.getDurgIdCoverage()));
		userOtherPolicyDetails.setCoveragePeriod(getValue(policyDetailsVO.getDurgCoveragePeriod()));
		userOtherPolicyDetails.setCustomerId(customerId);
		userOtherPolicyDetailsSet.add(userOtherPolicyDetails);

		// user agent details

		Set<UserAgentDetails> userAgentDetailsSet = new HashSet<UserAgentDetails>();
		UserAgentDetails userAgentDetails = new UserAgentDetails();
		userAgentDetails.setAgentId(seqNum);
		userAgentDetails.setUserId(seqNum);
		userAgentDetails.setCustomerId(customerId);
		userAgentDetails.setAgentName(getValue(agreeDetailsVO.getAgentName()));
		if (agreeDetailsVO.getAep().equalsIgnoreCase("I")) {
			userAgentDetails.setElectionType("");
		} else {
			userAgentDetails.setElectionType(agreeDetailsVO.getAep());
		}

		userAgentDetails.setPlanId(getValue(agreeDetailsVO.getPlanId()));
		userAgentDetails.setSentaraAgentID(getValue(agreeDetailsVO.getAgentId()));

		if (agreeDetailsVO.getEffectDateCoverage() == null || agreeDetailsVO.getEffectDateCoverage().isEmpty()) {
			Calendar cal = Calendar.getInstance();
			if (agreeDetailsVO.getAep().equalsIgnoreCase("A")) {
				cal.set(cal.get(Calendar.YEAR) + 1, 00, 01);
				userAgentDetails.setEffDate(cal.getTime());
			} else if (agreeDetailsVO.getAep().equalsIgnoreCase("I") || agreeDetailsVO.getAep().equalsIgnoreCase("S")) {
				cal.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, 01);
				userAgentDetails.setEffDate(cal.getTime());
			}
		} else {
			userAgentDetails.setEffDate(formatDate(agreeDetailsVO.getEffectDateCoverage()));
		}

		userAgentDetails.setWebTelApp(getValue(agreeDetailsVO.getWebtelApp()));
		userAgentDetailsSet.add(userAgentDetails);

		// user Legal Represenative details

		Set<UserLegalRepDetails> userLegalRepDetailsSet = new HashSet<UserLegalRepDetails>();
		UserLegalRepDetails userLegalRepDetails = new UserLegalRepDetails();
		userLegalRepDetails.setRepId(seqNum);
		userLegalRepDetails.setUserId(seqNum);
		userLegalRepDetails.setRelationshipEnrolle(getValue(agreeDetailsVO.getLegalRelationErloll()));
		userLegalRepDetails.setRepAddress(getValue(agreeDetailsVO.getLegalAddress()));
		userLegalRepDetails.setRepName(getValue(agreeDetailsVO.getLegalFirstName()));
		// IFOX-00407925 -start
		//userLegalRepDetails.setRepPhnNum(getFormattedValue(agreeDetailsVO.getLegalPhNumber()));
		userLegalRepDetails.setRepPhnNum(getValue(agreeDetailsVO.getLegalPhNumber()));
		// IFOX-00407925 -end
		userLegalRepDetails.setReplastName(getValue(agreeDetailsVO.getLegalLastName()));
		userLegalRepDetails.setRepMiddleInitial(getValue(agreeDetailsVO.getLegalMiddleName()));
		userLegalRepDetails.setRepAddressTwo(getValue(agreeDetailsVO.getLegalAddressTwo()));
		userLegalRepDetails.setRepAddressThree(getValue(agreeDetailsVO.getLegalAddressThree()));
		userLegalRepDetails.setRepCity(getValue(agreeDetailsVO.getLegalCity()));
		userLegalRepDetails.setRepState(getValue(agreeDetailsVO.getLegalState()));
		userLegalRepDetails.setRepzipCode(getValue(agreeDetailsVO.getLegalZipCode()));
		userLegalRepDetails.setCustomerId(customerId);
		userLegalRepDetailsSet.add(userLegalRepDetails);

		userDetails.setUserAddressesSet(userAddressesSet);
		userDetails.setUserAccountDetailsSet(userAccountDetailsSet);
		userDetails.setUserPolicyDetailsSet(userPolicyDetailsSet);
		userDetails.setUserAgentDetails(userAgentDetailsSet);
		userDetails.setUserLegalRepDetails(userLegalRepDetailsSet);
		userDetails.setUserOtherPolicyDetails(userOtherPolicyDetailsSet);
		userDetails.setSsn("");
		
		remvoeSessionValues(request);
		return userDetails;
	}
 // IFOX-00407925 -start
	private static String getFormattedValue(String legalPhNumber) {
		if (legalPhNumber != null) {
			legalPhNumber = legalPhNumber.replaceAll("[^0-9]", "");
			System.out.println("legalPhNumber-"+legalPhNumber);
			return legalPhNumber;
		} else {
			return "";
		}
	}
 // IFOX-00407925 -end
	private static String getValue(String texto) {
		if (texto != null) {
			return texto;
		} else {
			return "";
		}
	}

	/**
	 * @param date
	 * @return
	 * @throws ParseException
	 */
	public static Date formatDate(String date) {

		LOGGER.info(" Start : In formatDate() method of SentaraUtil class");
		if (date != null && !date.isEmpty()) {

			// SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

			try {
				System.out.println(" i am printing online date" + date);
				Date dateBeforeConvert = new SimpleDateFormat("MM/dd/yyyy").parse(date);
				String convertedDate = new SimpleDateFormat("yyyy-MM-dd").format(dateBeforeConvert);
				Date dateAfterConvert = new SimpleDateFormat("yyyy-MM-dd").parse(convertedDate);
				// System.out.println(convertedDate);
				// System.out.println(dateAfterConvert);
				return dateAfterConvert;
				/*
				 * System.out.println("date"+formatter.parse(date)); return
				 * formatter.parse(date);
				 */
			} catch (ParseException e) {
				e.printStackTrace();
				return null;
			}

		} else {

			// System.out.println(" i am in else block of date because null
			// values");

			String dummyDate = "09/09/9999";
			Date dateBeforeConvert;
			try {
				dateBeforeConvert = new SimpleDateFormat("MM/dd/yyyy").parse(dummyDate);
				String convertedDate = new SimpleDateFormat("yyyy-MM-dd").format(dateBeforeConvert);
				Date dateAfterConvert = new SimpleDateFormat("yyyy-MM-dd").parse(convertedDate);
				// System.out.println(convertedDate);
				// System.out.println(dateAfterConvert);
				// out.println(" i am in else block of date because null
				// values"+dateAfterConvert);
				return dateAfterConvert;

			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			}

		}

	}

	/**
	 * @param request
	 */
	public static void remvoeSessionValues(HttpServletRequest request) {

		LOGGER.info(" Start : In remvoeSessionValues() method of SentaraUtil class");
		request.getSession().removeAttribute("physicianMap");
		request.getSession().removeAttribute("stateMap");
		request.getSession().removeAttribute("relationEnrolle");
		request.getSession().removeAttribute("userDetailsObjForm1");
		request.getSession().removeAttribute("policyDetailsObjForm1");
		request.getSession().removeAttribute("attestationDetailsObjForm1");
		request.getSession().removeAttribute("agreeDetailsObjForm1");
	}

	public static Map<String, String> getRelationEnrollValues() {

		Map<String, String> unsortRelationEnrolle = new HashMap<String, String>();
		unsortRelationEnrolle.put("DAD", "FATHER");
		unsortRelationEnrolle.put("DEP", "DEPENDENT");
		unsortRelationEnrolle.put("EMP", "EMPLOYEE");
		unsortRelationEnrolle.put("FCH", "FOSTER CHILD");
		unsortRelationEnrolle.put("FSP", "FOSTER PARENT");
		unsortRelationEnrolle.put("GCH", "GRANDCHILD");
		unsortRelationEnrolle.put("GFA", "GRANDFATHER");
		unsortRelationEnrolle.put("GMA", "GRANDMOTHER");
		unsortRelationEnrolle.put("GPR", "GRANDPARENT");
		unsortRelationEnrolle.put("NN", "NIECE/NEPHEW");
		unsortRelationEnrolle.put("PAL", "FRIEND");
		unsortRelationEnrolle.put("REL", "PHYSICIAN");
		unsortRelationEnrolle.put("SCH", "STEP CHILD");
		unsortRelationEnrolle.put("SIB", "SIBLING");
		unsortRelationEnrolle.put("SPS", "SPOUSE");
		unsortRelationEnrolle.put("STP", "STEP PARENT");
		unsortRelationEnrolle.put("ATY", "ATTORNEY");
		unsortRelationEnrolle.put("GRD", "GUARDIAN");
		unsortRelationEnrolle.put("LIF", "LIFE PARTNER");
		unsortRelationEnrolle.put("MOM", "MOTHER");
		unsortRelationEnrolle.put("OTH", "OTHER");
		unsortRelationEnrolle.put("POA", "POWER OF ATTORNEY");
		unsortRelationEnrolle.put("REL", "RELATIVE");
		unsortRelationEnrolle.put("NCH", "NATURAL CHILD");
		// unsortRelationEnrolle.put("UNK", "UNKNOWN");
		Map<String, String> relationEnrolle = sortByValue(unsortRelationEnrolle);
		return relationEnrolle;
	}

	// Lokesh Katamaneni private static Map<String, String>
	// sortByValue(Map<String, String> unsortedList)
	private static Map<String, String> sortByValue(Map<String, String> unsortedList) {
		// TODO Auto-generated method stub

		List<Map.Entry<String, String>> list = new LinkedList<Map.Entry<String, String>>(unsortedList.entrySet());
		Collections.sort(list, new Comparator<Map.Entry<String, String>>() {
			public int compare(Map.Entry<String, String> o1, Map.Entry<String, String> o2) {
				return (o1.getValue()).compareTo(o2.getValue());
			}
		});
		Map<String, String> sortedMap = new LinkedHashMap<String, String>();
		for (Map.Entry<String, String> entry : list) {
			sortedMap.put(entry.getKey(), entry.getValue());
		}
		return sortedMap;
	}

	public static Map<String, String> getMaliningStateZipValues() {

		Map<String, String> unsortMailingstatezipvalues = new HashMap<String, String>();
		unsortMailingstatezipvalues.put("Alabama", "AL");
		unsortMailingstatezipvalues.put("Alaska", "AK");
		unsortMailingstatezipvalues.put("Arizona", "AZ");
		unsortMailingstatezipvalues.put("Arkansas", "AR");
		unsortMailingstatezipvalues.put("California", "CA");
		unsortMailingstatezipvalues.put("Colorado", "CO");
		unsortMailingstatezipvalues.put("Connecticut", "CT");
		unsortMailingstatezipvalues.put("Delaware", "DE");
		unsortMailingstatezipvalues.put("District of Columbia", "DC");
		unsortMailingstatezipvalues.put("Florida", "FL");
		unsortMailingstatezipvalues.put("Georgia", "GA");
		unsortMailingstatezipvalues.put("Hawaii", "HI");
		unsortMailingstatezipvalues.put("Idaho", "ID");
		unsortMailingstatezipvalues.put("Illinois", "IL");
		unsortMailingstatezipvalues.put("Indiana", "IN");
		unsortMailingstatezipvalues.put("Iowa", "IA");
		unsortMailingstatezipvalues.put("Kansas", "KS");
		unsortMailingstatezipvalues.put("Kentucky", "KY");
		unsortMailingstatezipvalues.put("Louisiana", "LA");
		unsortMailingstatezipvalues.put("Maine", "ME");
		unsortMailingstatezipvalues.put("Maryland", "MD");
		unsortMailingstatezipvalues.put("Massachusetts", "MA");
		unsortMailingstatezipvalues.put("Michigan", "MI");
		unsortMailingstatezipvalues.put("Minnesota", "MN");
		unsortMailingstatezipvalues.put("Mississippi", "MS");
		// unsortMailingstatezipvalues.put("NCH", "NATURALCHILD");
		unsortMailingstatezipvalues.put("Missouri", "MO");
		unsortMailingstatezipvalues.put("Montana", "MT");
		unsortMailingstatezipvalues.put("Nebraska", "NE");
		unsortMailingstatezipvalues.put("Nevada", "NV");
		unsortMailingstatezipvalues.put("New Hampshire", "NH");
		unsortMailingstatezipvalues.put("New Jersey", "NJ");
		unsortMailingstatezipvalues.put("New Mexico", "NM");
		unsortMailingstatezipvalues.put("New York", "NY");
		unsortMailingstatezipvalues.put("North Carolina", "NC");
		unsortMailingstatezipvalues.put("North Dakota", "ND");
		unsortMailingstatezipvalues.put("Ohio", "OH");
		unsortMailingstatezipvalues.put("Oklahoma", "OK");
		unsortMailingstatezipvalues.put("Oregon", "OR");
		unsortMailingstatezipvalues.put("Pennsylvania", "PA");
		unsortMailingstatezipvalues.put("Rhode Island", "RI");
		unsortMailingstatezipvalues.put("South Carolina", "SC");
		unsortMailingstatezipvalues.put("South Dakota", "SD");
		unsortMailingstatezipvalues.put("Tennessee", "TN");
		unsortMailingstatezipvalues.put("Texas", "TX");
		unsortMailingstatezipvalues.put("Utah", "UT");
		unsortMailingstatezipvalues.put("Vermont", "VT");
		unsortMailingstatezipvalues.put("Virginia", "VA");
		unsortMailingstatezipvalues.put("Washington", "WA");
		unsortMailingstatezipvalues.put("West Virginia", "WV");
		unsortMailingstatezipvalues.put("Wisconsin", "WI");
		unsortMailingstatezipvalues.put("Wyoming", "WY");
		Map<String, String> mailingstatezipvalues = sortByValue(unsortMailingstatezipvalues);
		return mailingstatezipvalues;
	}

	//Begin: Added for IFOX-00390114
    public static String nonNullTrim(String s) {
        if (s == null)
            return "";
        return s.trim();
    }
	//End: Added for IFOX-00390114
	
}
