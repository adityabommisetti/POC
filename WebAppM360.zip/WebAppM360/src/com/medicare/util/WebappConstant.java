package com.medicare.util;

public class WebappConstant {

	public static final String RELATIVEWEBPATHOFMEDICARDLOGO = "/images/Medicardlogo.png";
	
	//public static final String SHARPLOGO = "/images/Sharp_logo.jpg";
	public static final String SHARPLOGO = "/images/Sharp_logo - resized.jpg";

	public static final String RELATIVEWEBPATHOFCHECKIMAGE = "/images/check.PNG";
	public static final String RELATIVEWEBPATHOFUNCHECKIMAGE = "/images/uncheck.PNG";
	public static final String RELATIVEWEBPATHOFBUTTONCHECKIMAGE = "/images/buttonCheck.PNG";
	public static final String RELATIVEWEBPATHOFBUTTONUNCHECKIMAGE = "/images/buttonUncheck.PNG";

	public static final String RELATIVEWEBPATHOFSTOPIMAGE = "/images/Untitled.jpg";

	public static final String RELATIVEWEBPATHOFSAMPLECHECKIMAGE = "/images/samplecheck.JPG";

	public static final String RELATIVEWEBPATHOFSUMMACARELOGOIMAGE = "/images/SummaCare_Logo.jpg";

	public static final String RELATIVEWEBPATHOFTICKIMAGE = "/images/tick-image.jpg";

	public static final String RELATIVEWEBPATHOFARIALFONT = "/images/OpenSans-Regular.ttf";
	public static final String CHINESEFONT = "/images/chinese.ttf";
	public static final String Hind = "/images/AnjaliRegular.ttf";

}
