package com.medicare.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.MalformedURLException;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;

//import com.lowagie.text.BaseColor;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.medicare.vo.AgreeDetailsVO;
import com.medicare.vo.AttestationDetailsVO;
import com.medicare.vo.PolicyDetailsVO;
import com.medicare.vo.UserDetailsVO;

/**
 * @author SH250285
 * 
 */
public class PDFUtilGen {

	private final static Logger LOGGER = Logger.getLogger(PDFUtilGen.class.getName());
	private static Image Medicardlogo_Logo;
	private static Image Summarcarelogo_Logo;
	private static Image sampleCheck;
	private static Image check;

	private static Image uncheck;
	private static Image buttonCheckImage;
	private static Image buttonUncheckImage;

	private static Image tick;
	private static Image stop;

	private static BaseFont base;
	private static Font font;
	private static Font font2;

	/**
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	public static void showEnrollFromsInPDF(HttpServletRequest request, HttpServletResponse response) {

		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			UserDetailsVO pdfUserDetails = (UserDetailsVO) request.getSession().getAttribute("userDetailsVO");
			AgreeDetailsVO pdfAgreeDetails = (AgreeDetailsVO) request.getSession().getAttribute("agreeDetailsVO");

			baos = savePdf(request, response);
			printpdf(baos, response, pdfUserDetails, pdfAgreeDetails);
		} catch (Exception e) {
			LOGGER.error("Exception in : PDFUtill class and showEnrollFromsInPDF method");
			return;
		}
	}

	/**
	 * @param baos
	 * @param response
	 * @param pdfUserDetails
	 * @param pdfAgreeDetails
	 * @throws IOException
	 */
	private static void printpdf(ByteArrayOutputStream baos, HttpServletResponse response, UserDetailsVO pdfUserDetails,
			AgreeDetailsVO pdfAgreeDetails) throws IOException {
		String pdffileFileName = (getChangedValue(pdfUserDetails.getLastName())) + "_" + pdfAgreeDetails.getTodayDate();
		response.addHeader("Content-Disposition", "attachment;filename=" + pdffileFileName + "enrolled.pdf");
		OutputStream os = response.getOutputStream();
		baos.writeTo(os);
		os.flush();
		os.close();
	}

	/**
	 * @param request
	 * @param response
	 * @return
	 */
	private static ByteArrayOutputStream savePdf(HttpServletRequest request, HttpServletResponse response) {

		LOGGER.info(" Start : In savePdf () method of PDFUtilGen class");

		ByteArrayOutputStream baos = new ByteArrayOutputStream();

		UserDetailsVO pdfUserDetails = (UserDetailsVO) request.getSession().getAttribute("userDetailsVO");
		System.out.println("pdfUserDetails ::" + pdfUserDetails);

		PolicyDetailsVO pdfPolicyDetails = (PolicyDetailsVO) request.getSession().getAttribute("policyDetailsVO1");
		System.out.println("pdfPolicyDetails ::" + pdfPolicyDetails);

		AttestationDetailsVO pdfAttestationDetails = (AttestationDetailsVO) request.getSession()
				.getAttribute("attestationDetailsVO");
		System.out.println("pdfAttestationDetails ::" + pdfAttestationDetails);

		AgreeDetailsVO pdfAgreeDetails = (AgreeDetailsVO) request.getSession().getAttribute("agreeDetailsVO");

		System.out.println("pdfAgreeDetails ::" + pdfAgreeDetails);

		Document document = new Document(PageSize.A4, 10, 10, 10, 10);
		PdfWriter writer = null;
		try {

			pdfImageInstances(request);

			pdffontInstances(request);

			writer = PdfWriter.getInstance(document, baos);

			document.open();

			PdfPTable logo = page1LogoTable(Summarcarelogo_Logo);
			document.add(logo);

			PdfPTable Braille1 = page1BrailleTable1();
			document.add(Braille1);

			PdfPTable Braille = page1BrailleTable();
			document.add(Braille);

			page1optimaPlanTable(pdfUserDetails, document);

			PdfPTable page1TableUserDetails = page1TabbleUserDetails(pdfUserDetails, document);
			document.add(page1TableUserDetails);

			PdfPTable page1TableMedicarddetails = page1TableMedicareDetails(pdfUserDetails, document);
			document.add(page1TableMedicarddetails);

			document.newPage();

			PdfPTable page2Logotable = page2TableLogo();
			// document.add(page2Logotable);

			PdfPTable page2Table1 = pdfPage2Table1(pdfPolicyDetails);
			document.add(page2Table1);

			PdfPTable page2Table2 = pdfPage2Table2(pdfPolicyDetails);
			document.add(page2Table2);

			document.newPage();

			PdfPTable page3Table1 = pdfPage3Table1(document, page2Logotable);
			document.add(page3Table1);

			PdfPTable page3Table2 = pdfPage3Table2();
			document.add(page3Table2);

			PdfPTable page3Table3 = pdfPage3Table3(pdfAgreeDetails);
			document.add(page3Table3);

			PdfPTable page3Table4 = pdfPage3Table4(pdfAgreeDetails);
			document.add(page3Table4);

			PdfPTable page3Table5 = pdfPage3Table5(pdfAgreeDetails);
			document.add(page3Table5);

			PdfPTable page3Table6 = pdfPage3Table6(pdfAgreeDetails);
			document.add(page3Table6);

			document.newPage();

			PdfPTable page4Logotable = page2TableLogo();
			// document.add(page4Logotable);

			PdfPTable page4Table1 = pdfPage4Table1(pdfAttestationDetails, document);
			document.add(page4Table1);

			document.close();
			writer.close();
			//System.out.println("after closing baos value ::" + baos);
			return baos;

		} catch (Exception e) {

			return null;

		} finally {
			if (document != null) {
				document.close();
			}
			if (writer != null) {
				writer.close();
			}
		}

	}

	/**
	 * @param request
	 * @param response
	 * @return
	 */
	public static byte[] saveBytesPDF(HttpServletRequest request, HttpServletResponse response) {

		try {
			System.out.println("in saveBytesPDF ..");
			ByteArrayOutputStream baos = savePdf(request, response);

			byte[] pdfData = baos.toByteArray();
			byte[] pdfSave = Base64.encodeBase64(pdfData);
			System.out.println("in saveBytesPDF ..pdfSave " + pdfSave);
			return pdfSave;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * @param pdfAgreeDetails
	 * @return
	 */
	private static PdfPTable pdfPage3Table5(AgreeDetailsVO pdfAgreeDetails) {

		PdfPTable page3Table5 = new PdfPTable(1);
		page3Table5.setWidthPercentage(100);
		page3Table5.setSpacingBefore(10);
		page3Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPCell page3table5cell1 = new PdfPCell(new Phrase(
				"If you are the authorized representative and/or have Power of Attorney (POA),you must sign above and provide the following information along with your POA form:",
				font));
		page3table5cell1.setBorderWidthBottom(0.1f);
		page3Table5.addCell(page3table5cell1);

		PdfPTable page3Table5Cell5table1 = new PdfPTable(1);
		page3Table5Cell5table1.setWidthPercentage(100);
		page3Table5Cell5table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		page3Table5Cell5table1
				.addCell(new Phrase("Name : " + (getChangedValue(pdfAgreeDetails.getLegalFirstName())), font));

		PdfPCell page3table5cell2 = new PdfPCell(page3Table5Cell5table1);

		page3table5cell2.setBorderWidthBottom(0.1f);
		page3table5cell2.setBorderColorTop(java.awt.Color.WHITE);
		page3table5cell2.setBorderColorBottom(java.awt.Color.WHITE);
		page3Table5.addCell(page3table5cell2);

		PdfPTable page3Table5Cell3table = new PdfPTable(1);
		page3Table5Cell3table.setWidthPercentage(100);
		page3Table5Cell3table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page3Table5Cell3table
				.addCell(new Phrase("Address : " + (getChangedValue(pdfAgreeDetails.getLegalAddress())), font));
		page3Table5Cell3table.addCell(
				new Phrase("                " + (getChangedValue(pdfAgreeDetails.getLegalAddressTwo())), font));

		PdfPCell page3table5cell3 = new PdfPCell(page3Table5Cell3table);

		page3table5cell3.setBorderWidthBottom(0.1f);
		page3table5cell3.setBorderColorTop(java.awt.Color.WHITE);
		page3table5cell3.setBorderColorBottom(java.awt.Color.WHITE);
		page3Table5.addCell(page3table5cell3);

		String relationshiptoEnrolee = getChangedValue(pdfAgreeDetails.getLegalRelationErloll());

		PdfPTable page3Table5Cell1table1 = new PdfPTable(2);
		page3Table5Cell1table1.setWidthPercentage(100);
		page3Table5Cell1table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page3Table5Cell1table1
				.addCell(new Phrase("Phone Number :" + (getChangedValue(pdfAgreeDetails.getLegalPhNumber())), font));
		page3Table5Cell1table1.addCell(new Phrase("Relationship to Enrollee : " + relationshiptoEnrolee, font));

		PdfPCell page3table5cell4 = new PdfPCell(page3Table5Cell1table1);
		page3table5cell4.setBorderWidthBottom(0.1f);
		page3table5cell4.setBorderColorTop(java.awt.Color.WHITE);
		page3Table5.addCell(page3table5cell4);
		return page3Table5;
	}

	private static void pdfPage2Table2InstDetails(PdfPTable page2Table2, PolicyDetailsVO pdfPolicyDetails) {

		PdfPTable page2Table5Cell5table1 = new PdfPTable(1);
		page2Table5Cell5table1.setWidthPercentage(100);
		page2Table5Cell5table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		page2Table5Cell5table1.addCell(
				new Phrase("Name of Institution: " + (getChangedValue(pdfPolicyDetails.getInstituteName())), font));

		PdfPCell page2table5cell2 = new PdfPCell(page2Table5Cell5table1);

		page2table5cell2.setBorderWidthBottom(0.1f);
		page2table5cell2.setBorderColorTop(java.awt.Color.WHITE);
		page2table5cell2.setBorderColorBottom(java.awt.Color.WHITE);
		page2Table2.addCell(page2table5cell2);

		PdfPTable page2Table5Cell3table = new PdfPTable(1);
		page2Table5Cell3table.setWidthPercentage(100);
		page2Table5Cell3table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2Table5Cell3table
				.addCell(new Phrase("Address : " + (getChangedValue(pdfPolicyDetails.getInstituteAddress())), font));
		page2Table5Cell3table.addCell(
				new Phrase("                " + (getChangedValue(pdfPolicyDetails.getInstituteOtherAddress())), font));

		PdfPCell page2table5cell3 = new PdfPCell(page2Table5Cell3table);

		page2table5cell3.setBorderWidthBottom(0.1f);
		page2table5cell3.setBorderColorTop(java.awt.Color.WHITE);
		page2table5cell3.setBorderColorBottom(java.awt.Color.WHITE);
		page2Table2.addCell(page2table5cell3);

		PdfPTable page2Table5Cell1table1 = new PdfPTable(1);
		page2Table5Cell1table1.setWidthPercentage(100);
		page2Table5Cell1table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2Table5Cell1table1.addCell(new Phrase(
				"Phone Number of Institution :" + (getChangedValue(pdfPolicyDetails.getInstitutePhone())), font));

		PdfPCell page2table5cell4 = new PdfPCell(page2Table5Cell1table1);
		page2table5cell4.setBorderWidthBottom(0.1f);
		page2table5cell4.setBorderColorTop(java.awt.Color.WHITE);
		page2table5cell4.setBorderColorBottom(java.awt.Color.WHITE);
		page2Table2.addCell(page2table5cell4);

	}

	/**
	 * @param pdfAgreeDetails
	 * @return
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static PdfPTable pdfPage3Table4(AgreeDetailsVO pdfAgreeDetails) throws DocumentException, IOException {

		PdfPTable page3Table4 = new PdfPTable(1);
		page3Table4.setWidthPercentage(100);
		page3Table4.setSpacingBefore(10);
		page3Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		/*
		 * String checkBoxFlagforform4Agreecell =
		 * getChangedValue(pdfAgreeDetails .getSignature());
		 */
		String TodayDateValue = pdfAgreeDetails.getTodayDate();
		/*
		 * if (checkBoxFlagforform4Agreecell.equalsIgnoreCase("Y")) {
		 * displayCheckBoxInPDFforForm3table(page3Table4, check, TodayDateValue,
		 * "Your Signature  " +pdfAgreeDetails.getSignatureName()); } else if
		 * (!checkBoxFlagforform4Agreecell.equalsIgnoreCase("Y")) {
		 * displayCheckBoxInPDFforForm3table(page3Table4, uncheck,
		 * TodayDateValue, "Your Signature  "
		 * +pdfAgreeDetails.getSignatureName()); }
		 */
		displayCheckBoxInPDFforForm3table(page3Table4, uncheck, TodayDateValue,
				"Your Signature  " + pdfAgreeDetails.getSignatureName());

		return page3Table4;
	}

	private static PdfPTable pdfPage3Table6(AgreeDetailsVO pdfAgreeDetails) throws DocumentException, IOException {

		PdfPTable page3Table6 = new PdfPTable(1);
		page3Table6.setWidthPercentage(100);
		page3Table6.setSpacingBefore(10);
		page3Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		/*
		 * String checkBoxFlagforform3Agreecell =
		 * getChangedValue(pdfAgreeDetails .getRepSignature());
		 */
		String TodayDateValue = pdfAgreeDetails.getTodayRepDate();
		/*
		 * if (checkBoxFlagforform3Agreecell.equalsIgnoreCase("Y")) {
		 * displayCheckBoxInPDFforForm3table(page3Table6, check, TodayDateValue,
		 * "Plan Representative Signature  "
		 * +pdfAgreeDetails.getRepSignatureName()); } else if
		 * (!checkBoxFlagforform3Agreecell.equalsIgnoreCase("Y")) {
		 * displayCheckBoxInPDFforForm3table(page3Table6, uncheck,
		 * TodayDateValue, "Plan Representative Signature  "
		 * +pdfAgreeDetails.getRepSignatureName()); }
		 */

		displayCheckBoxInPDFforForm3table(page3Table6, check, TodayDateValue,
				"Plan Representative Signature  " + pdfAgreeDetails.getRepSignatureName());

		return page3Table6;
	}

	/**
	 * @param pdfAgreeDetails
	 * @return
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static PdfPTable pdfPage3Table3(AgreeDetailsVO pdfAgreeDetails) throws DocumentException, IOException {
		PdfPTable page3Table3 = new PdfPTable(1);
		page3Table3.setWidthPercentage(100);
		page3Table3.setSpacingBefore(10);
		page3Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		PdfPCell opt = new PdfPCell(new Phrase("Optional Supplemental Dental", font));
		opt.setBorderWidthBottom(0.1f);
		page3Table3.addCell(opt);
		String checkBoxFlagforform4Agreecell = getChangedValue(pdfAgreeDetails.getAgreeStatements());

		String phrase1 = "YES, I want to enroll in Delta Dental of Ohio OPTIONAL Supplemental benefit.I understand that this is an optional benefit and that if I enroll by selecting 'Yes', I will be billed an additional $25 monthly premium by SummaCare.";
		String phrase2 = "NO, I do not want to enroll in this optional supplemental dental plan.";

		if (checkBoxFlagforform4Agreecell.equalsIgnoreCase("A")) {

			displayButtonInPDFforForm1StmtsButton(page3Table3, buttonCheckImage, buttonUncheckImage, phrase1, phrase2);
		} else if (!checkBoxFlagforform4Agreecell.equalsIgnoreCase("A")) {
			displayButtonInPDFforForm1StmtsButton(page3Table3, buttonUncheckImage, buttonCheckImage, phrase1, phrase2);
		}

		return page3Table3;
	}

	/**
	 * @return
	 */
	private static PdfPTable pdfPage3Table2() {
		PdfPTable page4Table2 = new PdfPTable(1);
		page4Table2.setWidthPercentage(100);
		page4Table2.setSpacingBefore(10);
		page4Table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPCell page4table2cell1 = new PdfPCell(new Phrase(
				"I understand that my signature on this application means that I have read and understand the contents. If this application is signed by an authorized individual such as a Power of Attorney or Legal Guardian,I understand that SummaCare or Medicare may request a copy of those documents for their files.",
				font));
		page4table2cell1.setBorderWidthBottom(0.1f);
		page4Table2.addCell(page4table2cell1);

		return page4Table2;
	}

	/**
	 * @param document
	 * @param page2Logotable
	 * @return
	 * @throws DocumentException
	 */
	private static PdfPTable pdfPage3Table1(Document document, PdfPTable page2Logotable) throws DocumentException {

		PdfPTable page3Logotable = new PdfPTable(1);
		page3Logotable.setWidthPercentage(100);
		page3Logotable.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		page3Logotable.addCell(page2Logotable);
		// document.add(page3Logotable);

		PdfPTable page3Table1 = new PdfPTable(1);
		page3Table1.setWidthPercentage(100);
		page3Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page3Table1.setSpacingBefore(10);

		PdfPCell page3table1cell1 = new PdfPCell(stop);
		page3table1cell1.setBorderWidthBottom(0.1f);
		page3table1cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
		page3table1cell1.setBorderColorBottom(java.awt.Color.GRAY);
		page3table1cell1.setGrayFill(0.65f);
		page3table1cell1.setPaddingTop(0.65f);
		page3Table1.addCell(page3table1cell1);

		PdfPCell page3table1cell2 = new PdfPCell(
				new Phrase("               Please Read This Important Information", font));
		page3table1cell2.setBorderWidthBottom(0.1f);
		page3table1cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
		page3table1cell2.setBorderColorBottom(java.awt.Color.GRAY);
		page3table1cell2.setBorderColorTop(java.awt.Color.GRAY);
		page3table1cell2.setGrayFill(0.65f);
		page3Table1.addCell(page3table1cell2);

		PdfPCell page3table1cell3 = new PdfPCell(new Phrase(
				"If you have health coverage from an employer or union that you are going to be keeping, joining SummaCare may change how that coverage works.Please contact the Benefits Administration office at your former employer if you have questions about how these two insurances will work together.",
				font));
		page3table1cell3.setBorderWidthBottom(0.1f);
		page3table1cell3.setBorderColorBottom(java.awt.Color.WHITE);
		page3table1cell3.setBorderColorTop(java.awt.Color.WHITE);
		page3Table1.addCell(page3table1cell3);

		PdfPCell page3table1cell4 = new PdfPCell(
				new Phrase("Please read and Sign Below:", FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD)));
		page3table1cell4.setBorderWidthBottom(0.1f);
		page3table1cell4.setBorderColorBottom(java.awt.Color.WHITE);
		page3table1cell4.setBorderColorTop(java.awt.Color.WHITE);
		page3Table1.addCell(page3table1cell4);

		PdfPCell page3table1cell5 = new PdfPCell(
				new Phrase("By completing this enrollment application, I agree to the following :",
						FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8, Font.UNDERLINE)));
		page3table1cell5.setBorderWidthBottom(0.1f);
		page3table1cell5.setBorderColorBottom(java.awt.Color.WHITE);
		page3table1cell5.setBorderColorTop(java.awt.Color.WHITE);
		page3Table1.addCell(page3table1cell5);

		PdfPCell page3table1cell6 = new PdfPCell(new Phrase(
				"SummaCare is an HMO and HMO-POS plan with a Medicare contract. Enrollment in SummaCare depends on contract renewal. I will need to keep my Medicare Parts A and B. I can be in only one Medicare Advantage plan at a time and I understand that my enrollment in this plan will automatically end my enrollment in another Medicare health plan or prescription drug plan. It is my responsibility to inform you of any prescription drug coverage that I have or may get in the future. If you are currently enrolled in a Medigap (Medicare Supplement plan), you should call that plan to cancel your coverage after you have received the confirmation of enrollment in SummaCare.Enrollment in this plan is generally for the entire year. Once I enroll, I may leave this plan or make changes only during the Open Enrollment Period(October 15 � December 7 of every year) or under certain special circumstances.",
				font));
		page3table1cell6.setBorderWidthBottom(0.1f);
		page3table1cell6.setBorderColorBottom(java.awt.Color.WHITE);
		page3table1cell6.setBorderColorTop(java.awt.Color.WHITE);
		page3Table1.addCell(page3table1cell6);

		PdfPCell page4table1cell7 = new PdfPCell(new Phrase(
				"SummaCare serves a specific service area. If I move out of SummaCare�s service area, I will need to enroll in a new plan for my new area. I understand that SummaCare provides medical and prescription drug coverage when I travel and I will have emergency coverage if I travel outside of the U.S. I understand that the Evidence of Coverage I receive will tell me what benefits I have under SummaCare and which rules I must follow to get those benefits. I understand that services requiring an authorization will be denied if no authorization information is received from the doctor. I understand that I have the right to appeal decisions about payments and services if I disagree with SummaCare. I understand that while I am a member of any SummaCare Medicare HMO or HMO-POS plan, I must use SCMedicare providers in order to get the higher level of coverage, but the copay for urgent care or emergency care or dialysis services will be the same in-network and out-of-network. I understand that if I am getting assistance from a sales agent, broker or other individual employed by or contracted with SummaCare, he/she may be paid based on my enrollment in SummaCare.",
				font));
		page4table1cell7.setBorderWidthBottom(0.1f);
		page4table1cell7.setBorderColorBottom(java.awt.Color.WHITE);
		page4table1cell7.setBorderColorTop(java.awt.Color.WHITE);
		page3Table1.addCell(page4table1cell7);

		PdfPCell page3table1cell8 = new PdfPCell(new Phrase(
				"Release of Information:By joining this Medicare health plan, I acknowledge that SummaCare will release my information to Medicare and other plans or providers as is necessary for treatment, payment and health care operations. I also acknowledge that SummaCare will release my information including my prescription drug event data to Medicare, who may release it for research and other purposes which follow all applicable Federal statutes and regulations. The information on this enrollment form is correct to the best of my knowledge. I understand that if I intentionally provide false information on this form, I will be disenrolled from the plan.",
				font));
		page3table1cell8.setBorderWidthBottom(0.1f);
		page3table1cell8.setBorderColorTop(java.awt.Color.WHITE);
		page3Table1.addCell(page3table1cell8);
		return page3Table1;
	}

	/**
	 * @param pdfAttestationDetails
	 * @param document
	 * @param page2Logotable
	 * @return
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static PdfPTable pdfPage4Table1(AttestationDetailsVO pdfAttestationDetails, Document document)
			throws DocumentException, IOException {

		PdfPTable page4Table1 = new PdfPTable(1);
		page4Table1.setWidthPercentage(100);
		page4Table1.setSpacingBefore(10);

		PdfPCell page4table1cell1 = new PdfPCell(new Phrase(
				"Typically, you may enroll in a Medicare Advantage Plan during the Open Enrollment Period which is from October 15 through December 7 of each year.There are exceptions that allow you to enroll in a Medicare Advantage Plan outside of this period.",
				FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD)));
		page4table1cell1.setBorderWidthBottom(0.1f);
		page4table1cell1.setBorderColorBottom(java.awt.Color.WHITE);
		page4Table1.addCell(page4table1cell1);

		PdfPCell page4table2cell1 = new PdfPCell(new Phrase(
				"Please read the following statements carefully and check the box if the statement applies to you.By checking any of the following boxes you are certifying that, to the best of your knowledge, you are eligible for an Enrollment Period.If we later determine that this information is incorrect, you may be disenrolled.",
				FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD)));
		page4table2cell1.setBorderWidthBottom(0.1f);
		page4table2cell1.setBorderColorBottom(java.awt.Color.WHITE);
		page4Table1.addCell(page4table2cell1);

		String checkBoxFlagforCell1Firstcell = getChangedValue(pdfAttestationDetails.getEligibleEnroll());
		String checkBoxFlagforcell1Secondcell = getChangedValue(pdfAttestationDetails.getNewMedicare());
		String phrase1 = null;
		String phrase2 = null;

		phrase1 = "I am enrolling during the open enrollment period between October 15 and December 7 of each year.";
		phrase2 = "I am new to Medicare. ";

		PdfPTable page4Cell2Table1firstcheck = new PdfPTable(2);
		PdfPTable page4Cell2Table1secondcheck = new PdfPTable(2);
		PdfPTable page4Cell2Table1 = new PdfPTable(2);

		if (!checkBoxFlagforCell1Firstcell.isEmpty() && !checkBoxFlagforcell1Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, check, check, page4Cell2Table1firstcheck,
					page4Cell2Table1secondcheck, page4Cell2Table1);
		} else if (!checkBoxFlagforCell1Firstcell.isEmpty() && checkBoxFlagforcell1Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, check, uncheck, page4Cell2Table1firstcheck,
					page4Cell2Table1secondcheck, page4Cell2Table1);
		} else if (checkBoxFlagforCell1Firstcell.isEmpty() && !checkBoxFlagforcell1Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, uncheck, check, page4Cell2Table1firstcheck,
					page4Cell2Table1secondcheck, page4Cell2Table1);
		} else {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, uncheck, uncheck, page4Cell2Table1firstcheck,
					page4Cell2Table1secondcheck, page4Cell2Table1);
		}

		String checkBoxFlagforCell2Firstcell = getChangedValue(pdfAttestationDetails.getPriorMedicare());
		String checkBoxFlagforcell2Secondcell = getChangedValue(pdfAttestationDetails.getRecentMovedOption());

		phrase1 = "I have had Medicare prior to now, but am just turning age 65. ";

		phrase2 = "I recently moved or within the next month I will move outside of the service area for my current plan and into the service area for SummaCare.I moved or will move on (insert date): "
				+ (getChangedValue(checkBoxFlagforcell2Secondcell));

		PdfPTable page4Cell3Table1firstcheck = new PdfPTable(2);
		PdfPTable page4Cell3Table1secondcheck = new PdfPTable(2);
		PdfPTable page4Cell3Table1 = new PdfPTable(2);
		if (!checkBoxFlagforCell2Firstcell.isEmpty() && !checkBoxFlagforcell2Secondcell.isEmpty()) {

			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, check, check, page4Cell3Table1firstcheck,
					page4Cell3Table1secondcheck, page4Cell3Table1);
		} else if (!checkBoxFlagforCell2Firstcell.isEmpty() && checkBoxFlagforcell2Secondcell.isEmpty()) {

			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, check, uncheck, page4Cell3Table1firstcheck,
					page4Cell3Table1secondcheck, page4Cell3Table1);
		} else if (checkBoxFlagforCell2Firstcell.isEmpty() && !checkBoxFlagforcell2Secondcell.isEmpty()) {

			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, uncheck, check, page4Cell3Table1firstcheck,
					page4Cell3Table1secondcheck, page4Cell3Table1);
		} else {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, uncheck, uncheck, page4Cell3Table1firstcheck,
					page4Cell3Table1secondcheck, page4Cell3Table1);
		}

		String checkBoxFlagforCell3Firstcell = getChangedValue(pdfAttestationDetails.getTerminationDate());
		String checkBoxFlagforcell3Secondcell = getChangedValue(pdfAttestationDetails.getIncarceration());

		phrase1 = "I was terminated from my prior Medicare plan for living outside of its service area for more than six months. I was terminated on (insert date): "
				+ (getChangedValue(checkBoxFlagforCell3Firstcell));
		phrase2 = "I was recently released from a correctional facility on (insert date): "
				+ (getChangedValue(checkBoxFlagforcell3Secondcell));

		PdfPTable page4Cell4Table1firstcheck = new PdfPTable(2);
		PdfPTable page4Cell4Table1secondcheck = new PdfPTable(2);
		PdfPTable page4Cell4Table1 = new PdfPTable(2);
		if (!checkBoxFlagforCell3Firstcell.isEmpty() && !checkBoxFlagforcell3Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, check, check, page4Cell4Table1firstcheck,
					page4Cell4Table1secondcheck, page4Cell4Table1);
		} else if (!checkBoxFlagforCell3Firstcell.isEmpty() && checkBoxFlagforcell3Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, check, uncheck, page4Cell4Table1firstcheck,
					page4Cell4Table1secondcheck, page4Cell4Table1);
		} else if (checkBoxFlagforCell3Firstcell.isEmpty() && !checkBoxFlagforcell3Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, uncheck, check, page4Cell4Table1firstcheck,
					page4Cell4Table1secondcheck, page4Cell4Table1);
		} else {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, uncheck, uncheck, page4Cell4Table1firstcheck,
					page4Cell4Table1secondcheck, page4Cell4Table1);
		}

		String checkBoxFlagforCell4Firstcell = getChangedValue(pdfAttestationDetails.getMcNumChBox());
		String checkBoxFlagforcell4Secondcell = getChangedValue(pdfAttestationDetails.getRevMedChBox());

		phrase1 = "I have both Medicare and Medicaid or my state helps pay for my Medicare premiums. ";

		phrase2 = "I get extra help paying for Medicare prescription drug coverage.";

		PdfPTable page4Cell5Table1firstcheck = new PdfPTable(2);
		PdfPTable page4Cell5Table1secondcheck = new PdfPTable(2);
		PdfPTable page4Cell5Table1 = new PdfPTable(2);
		if (!checkBoxFlagforCell4Firstcell.isEmpty() && !checkBoxFlagforcell4Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, check, check, page4Cell5Table1firstcheck,
					page4Cell5Table1secondcheck, page4Cell5Table1);
		} else if (!checkBoxFlagforCell4Firstcell.isEmpty() && checkBoxFlagforcell4Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, check, uncheck, page4Cell5Table1firstcheck,
					page4Cell5Table1secondcheck, page4Cell5Table1);
		} else if (checkBoxFlagforCell4Firstcell.isEmpty() && !checkBoxFlagforcell4Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, uncheck, check, page4Cell5Table1firstcheck,
					page4Cell5Table1secondcheck, page4Cell5Table1);
		} else {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, uncheck, uncheck, page4Cell5Table1firstcheck,
					page4Cell5Table1secondcheck, page4Cell5Table1);
		}

		String checkBoxFlagforCell5Firstcell = getChangedValue((pdfAttestationDetails.getNoEligbPrescDrugs()));
		String checkBoxFlagforcell5Secondcell = getChangedValue(pdfAttestationDetails.getLngcareFacilityDate());
		phrase1 = "I no longer qualify for extra help paying for my Medicare prescription drugs. I stopped receiving extra help on (insert date): "
				+ (getChangedValue(checkBoxFlagforCell5Firstcell));
		phrase2 = "I am moving into a Long-Term Care Facility (for example, a nursing home or rehabilitation hospital). I will move into the facility on (insert date): "
				+ (getChangedValue(checkBoxFlagforcell5Secondcell));

		PdfPTable page4Cell6Table1firstcheck = new PdfPTable(2);
		PdfPTable page4Cell6Table1secondcheck = new PdfPTable(2);
		PdfPTable page4Cell6Table1 = new PdfPTable(2);
		if (!checkBoxFlagforCell5Firstcell.isEmpty() && !checkBoxFlagforcell5Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, check, check, page4Cell6Table1firstcheck,
					page4Cell6Table1secondcheck, page4Cell6Table1);
		} else if (!checkBoxFlagforCell5Firstcell.isEmpty() && checkBoxFlagforcell5Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, check, uncheck, page4Cell6Table1firstcheck,
					page4Cell6Table1secondcheck, page4Cell6Table1);
		} else if (checkBoxFlagforCell5Firstcell.isEmpty() && !checkBoxFlagforcell5Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, uncheck, check, page4Cell6Table1firstcheck,
					page4Cell6Table1secondcheck, page4Cell6Table1);
		} else {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, uncheck, uncheck, page4Cell6Table1firstcheck,
					page4Cell6Table1secondcheck, page4Cell6Table1);
		}

		String checkBoxFlagforCell15Firstcell = getChangedValue((pdfAttestationDetails.getCurrentLngcare()));
		String checkBoxFlagforcell15Secondcell = getChangedValue(pdfAttestationDetails.getOutLongTermFacility());
		phrase1 = "I currently live in a Long-Term Care Facility.";

		phrase2 = "I recently moved out of a Long-Term Care Facility on (insert date): "
				+ (getChangedValue(checkBoxFlagforcell15Secondcell));

		PdfPTable page4Cell11Table1firstcheck = new PdfPTable(2);
		PdfPTable page4Cell11Table1secondcheck = new PdfPTable(2);
		PdfPTable page4Cell11Table1 = new PdfPTable(2);
		if (!checkBoxFlagforCell15Firstcell.isEmpty() && !checkBoxFlagforcell15Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, check, check, page4Cell11Table1firstcheck,
					page4Cell11Table1secondcheck, page4Cell11Table1);
		} else if (!checkBoxFlagforCell15Firstcell.isEmpty() && checkBoxFlagforcell15Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, check, uncheck, page4Cell11Table1firstcheck,
					page4Cell11Table1secondcheck, page4Cell11Table1);
		} else if (checkBoxFlagforCell15Firstcell.isEmpty() && !checkBoxFlagforcell15Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, uncheck, check, page4Cell11Table1firstcheck,
					page4Cell11Table1secondcheck, page4Cell11Table1);
		} else {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, uncheck, uncheck, page4Cell11Table1firstcheck,
					page4Cell11Table1secondcheck, page4Cell11Table1);
		}

		String checkBoxFlagforCell6Firstcell = getChangedValue(pdfAttestationDetails.getRecntLeftPace());
		String checkBoxFlagforcell6Secondcell = getChangedValue(pdfAttestationDetails.getRecentlyCreditable());

		phrase1 = "I recently left a PACE program on (insert date): "
				+ (getChangedValue(checkBoxFlagforCell6Firstcell));
		phrase2 = "I recently involuntarily lost my creditable prescription drug coverage (coverage as good as Medicare's). I lost my drug coverage on (insert date): "
				+ (getChangedValue(checkBoxFlagforcell6Secondcell));

		PdfPTable page4Cell7Table1firstcheck = new PdfPTable(2);
		PdfPTable page4Cell7Table1secondcheck = new PdfPTable(2);
		PdfPTable page4Cell7Table1 = new PdfPTable(2);
		if (!checkBoxFlagforCell6Firstcell.isEmpty() && !checkBoxFlagforcell6Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, check, check, page4Cell7Table1firstcheck,
					page4Cell7Table1secondcheck, page4Cell7Table1);
		} else if (!checkBoxFlagforCell6Firstcell.isEmpty() && checkBoxFlagforcell6Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, check, uncheck, page4Cell7Table1firstcheck,
					page4Cell7Table1secondcheck, page4Cell7Table1);
		} else if (checkBoxFlagforCell6Firstcell.isEmpty() && !checkBoxFlagforcell6Secondcell.isEmpty()) {

			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, uncheck, check, page4Cell7Table1firstcheck,
					page4Cell7Table1secondcheck, page4Cell7Table1);
		} else {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, uncheck, uncheck, page4Cell7Table1firstcheck,
					page4Cell7Table1secondcheck, page4Cell7Table1);
		}

		String checkBoxFlagforCell7Firstcell = getChangedValue(pdfAttestationDetails.getLeavingEmployerCoverage());
		String checkBoxFlagforcell7Secondcell = getChangedValue(pdfAttestationDetails.getBelongStatePharmacy());

		phrase1 = "I am leaving employer or union coverage on (insert date): "
				+ (getChangedValue(checkBoxFlagforCell7Firstcell));
		phrase2 = "I belong to a pharmacy assistance program provided by my state."
				+ (getChangedValue(checkBoxFlagforcell7Secondcell));

		PdfPTable page4Cell8Table1firstcheck = new PdfPTable(2);
		PdfPTable page4Cell8Table1secondcheck = new PdfPTable(2);
		PdfPTable page4Cell8Table1 = new PdfPTable(2);
		if (!checkBoxFlagforCell7Firstcell.isEmpty() && !checkBoxFlagforcell7Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, check, check, page4Cell8Table1firstcheck,
					page4Cell8Table1secondcheck, page4Cell8Table1);
		} else if (!checkBoxFlagforCell7Firstcell.isEmpty() && checkBoxFlagforcell7Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, check, uncheck, page4Cell8Table1firstcheck,
					page4Cell8Table1secondcheck, page4Cell8Table1);
		} else if (checkBoxFlagforCell7Firstcell.isEmpty() && !checkBoxFlagforcell7Secondcell.isEmpty()) {

			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, uncheck, check, page4Cell8Table1firstcheck,
					page4Cell8Table1secondcheck, page4Cell8Table1);
		} else {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, uncheck, uncheck, page4Cell8Table1firstcheck,
					page4Cell8Table1secondcheck, page4Cell8Table1);
		}

		String checkBoxFlagforCell8Firstcell = getChangedValue(pdfAttestationDetails.getPriorplanUnavailableDate());
		String checkBoxFlagforcell8Secondcell = getChangedValue(pdfAttestationDetails.getPlanEndingContract());

		phrase1 = "I was unable to enroll in a Medicare Drug Plan when I first became eligible for Medicare, because no plan was available where I lived at that time (for example, I lived outside of the country or was incarcerated).I first moved into an area where I could sign up for a Medicare Drug Plan on (insert date): "
				+ (getChangedValue(checkBoxFlagforCell8Firstcell));
		phrase2 = "My prior Medicare (Advantage or Prescription Drug) plan (not SummaCare) is ending its contract with Medicare or Medicare is ending its contract with my old plan, so I need a new plan.";

		PdfPTable page4Cell9Table1firstcheck = new PdfPTable(2);
		PdfPTable page4Cell9Table1secondcheck = new PdfPTable(2);
		PdfPTable page4Cell9Table1 = new PdfPTable(2);
		if (!checkBoxFlagforCell8Firstcell.isEmpty() && !checkBoxFlagforcell8Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, check, check, page4Cell9Table1firstcheck,
					page4Cell9Table1secondcheck, page4Cell9Table1);
		} else if (!checkBoxFlagforCell8Firstcell.isEmpty() && checkBoxFlagforcell8Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, check, uncheck, page4Cell9Table1firstcheck,
					page4Cell9Table1secondcheck, page4Cell9Table1);
		} else if (checkBoxFlagforCell8Firstcell.isEmpty() && !checkBoxFlagforcell8Secondcell.isEmpty()) {

			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, uncheck, check, page4Cell9Table1firstcheck,
					page4Cell9Table1secondcheck, page4Cell9Table1);
		} else {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, uncheck, uncheck, page4Cell9Table1firstcheck,
					page4Cell9Table1secondcheck, page4Cell9Table1);
		}

		String checkBoxFlagforCell9Firstcell = getChangedValue(pdfAttestationDetails.getNoEligSpecial());
		String checkBoxFlagforcell9Secondcell = getChangedValue(pdfAttestationDetails.getMovedBackUs());

		phrase1 = "I was enrolled in a Special Needs Plan (SNP) but I have lost the special needs qualification required to be in that plan. I was disenrolled from the SNP on (insert date): "
				+ (getChangedValue(checkBoxFlagforCell9Firstcell));
		phrase2 = "I recently returned to the United States after living permanently outside of the U.S. I returned to the U.S. on (insert date): "
				+ (getChangedValue(checkBoxFlagforcell9Secondcell));

		PdfPTable page4Cell10Table1firstcheck = new PdfPTable(2);
		PdfPTable page4Cell10Table1secondcheck = new PdfPTable(2);
		PdfPTable page4Cell10Table1 = new PdfPTable(2);
		if (!checkBoxFlagforCell9Firstcell.isEmpty() && !checkBoxFlagforcell9Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, check, check, page4Cell10Table1firstcheck,
					page4Cell10Table1secondcheck, page4Cell10Table1);
		} else if (!checkBoxFlagforCell9Firstcell.isEmpty() && checkBoxFlagforcell9Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, check, uncheck, page4Cell10Table1firstcheck,
					page4Cell10Table1secondcheck, page4Cell10Table1);
		} else if (checkBoxFlagforCell8Firstcell.isEmpty() && !checkBoxFlagforcell8Secondcell.isEmpty()) {

			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, uncheck, check, page4Cell10Table1firstcheck,
					page4Cell10Table1secondcheck, page4Cell10Table1);
		} else {
			displayCheckBoxInPDFforForm4(page4Table1, phrase1, phrase2, uncheck, uncheck, page4Cell10Table1firstcheck,
					page4Cell10Table1secondcheck, page4Cell10Table1);
		}

		String checkBoxFlagForMadp = getChangedValue(pdfAttestationDetails.getMadp());
		if (!checkBoxFlagForMadp.isEmpty()) {
			displayCheckBoxInPDFforForm3table1cellMADP(page4Table1, check, checkBoxFlagForMadp);
		} else {
			displayCheckBoxInPDFforForm3table1cellMADP(page4Table1, uncheck, checkBoxFlagForMadp);
		}

		PdfPCell page4table1cell114 = new PdfPCell(new Phrase(
				"*If you have any questions about this form, please call  SummaCare at (toll free) 888-464-8440.Persons with hearing impairments please call TTY at 800-750-0750. From October 1 through February 14,a representative will be available to speak with you from 8 a.m. to 8 p.m., seven days a week. Beginning February 15, through September 30,a representative will be available to speak to you from 8 a.m. to 8 p.m. Monday through Friday.",
				font));
		page4table1cell114.setBorderWidthBottom(0.1f);
		page4table1cell114.setBorderColorTop(java.awt.Color.WHITE);
		page4Table1.addCell(page4table1cell114);

		return page4Table1;
	}

	/**
	 * @param pdfPolicyDetails
	 * @return
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static PdfPTable pdfPage2Table2(PolicyDetailsVO pdfPolicyDetails) throws DocumentException, IOException {

		PdfPTable page2Table2 = new PdfPTable(1);
		page2Table2.setWidthPercentage(100);
		page2Table2.setSpacingBefore(10);

		PdfPCell page2table2cell1 = new PdfPCell(new Phrase("Please Read and Answer These Important Questions:",
				FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD)));
		page2table2cell1.setGrayFill(0.85f);
		page2table2cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
		page2table2cell1.setBorderWidthBottom(0.1f);
		page2table2cell1.setBorderColorBottom(java.awt.Color.WHITE);

		page2Table2.addCell(page2table2cell1);

		String radioButtonFlagfortable2cell1 = getChangedValue(pdfPolicyDetails.getRenalDisease());
		if (radioButtonFlagfortable2cell1 != null && radioButtonFlagfortable2cell1.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell1(page2Table2, buttonCheckImage, buttonUncheckImage);
		} else if (!radioButtonFlagfortable2cell1.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell1(page2Table2, buttonUncheckImage, buttonCheckImage);
		}

		PdfPCell page2table2cell3 = new PdfPCell(new Phrase(
				"If you have had a successful kidney transplant and/or you don't need regular dialysis any more,please submit a note or records from your doctor to SummaCare showing you have had a successful kidney transplant or you don't need dialysis,otherwise we may need to contact you to obtain additional information.",
				font));
		page2table2cell3.setBorderWidthBottom(0.1f);
		page2table2cell3.setBorderColorBottom(java.awt.Color.WHITE);
		page2table2cell3.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(page2table2cell3);

		String radioButtonFlagfortable2cell2 = getChangedValue(pdfPolicyDetails.getHealthBenefits());

		if (radioButtonFlagfortable2cell2.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell2(page2Table2, buttonCheckImage, buttonUncheckImage);
		} else if (!radioButtonFlagfortable2cell2.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell2(page2Table2, buttonUncheckImage, buttonCheckImage);
		}

		PdfPCell page2table2cell5 = new PdfPCell(new Phrase(
				"If " + "yes"
						+ ", please list your other coverage and your identification (ID) numbers(s) for this coverage:",
				font));
		page2table2cell5.setBorderWidthBottom(0.1f);
		page2table2cell5.setBorderColorBottom(java.awt.Color.WHITE);
		page2table2cell5.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(page2table2cell5);

		PdfPTable page2table2cell6_table1 = new PdfPTable(3);
		page2table2cell6_table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2table2cell6_table1.addCell(new Phrase("Name of other coverage : ", font));
		page2table2cell6_table1.addCell(new Phrase("ID# for this coverage: ", font));
		page2table2cell6_table1.addCell(new Phrase("Group # for this coverage:", font));
		/*
		 * page2table2cell6_table1.addCell(new Phrase("Ending Coverage Date:",
		 * font));
		 */

		PdfPCell page2table2cell6 = new PdfPCell(page2table2cell6_table1);
		page2table2cell6.setBorderWidthBottom(0.1f);
		page2table2cell6.setBorderColorBottom(java.awt.Color.WHITE);
		page2table2cell6.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(page2table2cell6);

		PdfPTable page2table2cell6_table2 = new PdfPTable(3);
		page2table2cell6_table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2table2cell6_table2.addCell(new Phrase((getChangedValue(pdfPolicyDetails.getDurgNameCoverage())), font));
		page2table2cell6_table2.addCell(new Phrase((getChangedValue(pdfPolicyDetails.getDurgIdCoverage())), font));
		page2table2cell6_table2.addCell(new Phrase((getChangedValue(pdfPolicyDetails.getDurgGroupCoverage())), font));

		PdfPCell page2table2cell7 = new PdfPCell(page2table2cell6_table2);
		page2table2cell7.setBorderWidthBottom(0.1f);
		page2table2cell7.setBorderColorBottom(java.awt.Color.WHITE);
		page2table2cell7.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(page2table2cell7);

		/*
		 * page2table2cell6_table2.addCell(new Phrase(
		 * (getChangedValue(pdfPolicyDetails.getMedicalCoveragePeriod())),
		 * font));
		 */

		/*
		 * PdfPCell page2table2cell7 = new PdfPCell(page2table2cell6_table2);
		 * page2table2cell7.setBorderWidthBottom(0.1f);
		 * page2table2cell7.setBorderColorBottom(java.awt.Color.WHITE);
		 * page2table2cell7.setBorderColorTop(java.awt.Color.WHITE);
		 * page2Table2.addCell(page2table2cell7);
		 * 
		 * PdfPTable page2table2cell8_table2 = new PdfPTable(4);
		 * page2table2cell8_table2
		 * .getDefaultCell().setBorder(Rectangle.NO_BORDER);
		 * page2table2cell8_table2 .addCell(new
		 * Phrase((getChangedValue(pdfPolicyDetails
		 * .getOtherMedicalNameCoverage())), font)); page2table2cell8_table2
		 * .addCell(new Phrase((getChangedValue(pdfPolicyDetails
		 * .getOtherMedicalIdCoverage())), font));
		 * page2table2cell8_table2.addCell(new Phrase(
		 * (getChangedValue(pdfPolicyDetails .getOtherMedicalGroupCoverage())),
		 * font)); page2table2cell8_table2.addCell(new Phrase(
		 * (getChangedValue(pdfPolicyDetails .getOtherMedicalCoveragePeriod())),
		 * font));
		 */
		/*
		 * PdfPCell page2table2cell8 = new PdfPCell(page2table2cell8_table2);
		 * page2table2cell8.setBorderWidthBottom(0.1f);
		 * page2table2cell8.setBorderColorBottom(java.awt.Color.WHITE);
		 * page2table2cell8.setBorderColorTop(java.awt.Color.WHITE);
		 * page2Table2.addCell(page2table2cell8);
		 */

		String radioButtonFlagfortable2cell9 = getChangedValue(pdfPolicyDetails.getNursingHome());
		String phrase = "3.Are you a resident in a long-term care facility, such as a nursing home ?";
		if (radioButtonFlagfortable2cell9.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell10(page2Table2, buttonCheckImage, buttonUncheckImage, phrase);
		} else if (!radioButtonFlagfortable2cell9.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell10(page2Table2, buttonUncheckImage, buttonCheckImage, phrase);
		}

		PdfPCell page2table2cell10 = new PdfPCell(
				new Phrase("If " + "yes" + ",  please provide the following information:", font));
		page2table2cell10.setBorderWidthBottom(0.1f);
		page2table2cell10.setBorderColorBottom(java.awt.Color.WHITE);
		page2table2cell10.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(page2table2cell10);

		pdfPage2Table2InstDetails(page2Table2, pdfPolicyDetails);

		String radioButtonFlagfortable2cell11 = getChangedValue(pdfPolicyDetails.getStateMedicaid());

		phrase = "4. Are you enrolled in your State Medicaid program? ";

		if (radioButtonFlagfortable2cell11.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell10(page2Table2, buttonCheckImage, buttonUncheckImage, phrase);
		} else if (!radioButtonFlagfortable2cell11.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell10(page2Table2, buttonUncheckImage, buttonCheckImage, phrase);
		}

		PdfPCell page2table2cell11 = new PdfPCell(new Phrase("If " + "yes" + ",  please provide your Medicaid number: "
				+ (getChangedValue(pdfPolicyDetails.getMedicaidNumber())), font));

		page2table2cell11.setBorderWidthBottom(0.1f);
		page2table2cell11.setBorderColorBottom(java.awt.Color.WHITE);
		page2table2cell11.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(page2table2cell11);

		String radioButtonFlagfortable2cell12 = getChangedValue(pdfPolicyDetails.getSpouse());

		phrase = "5.Do either you or your spouse work? ";
		if (radioButtonFlagfortable2cell12.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell10(page2Table2, buttonCheckImage, buttonUncheckImage, phrase);
		} else if (!radioButtonFlagfortable2cell12.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell10(page2Table2, buttonUncheckImage, buttonCheckImage, phrase);
		}

		PdfPCell page2table2cell12 = new PdfPCell(new Phrase(
				"IMPORTANT: Please select a Primary Care Physician (PCP) who can coordinate your medical care.You can search PCPs in the SCMedicare network online at www.summacare.com/medicare (click Find a Doctor or Hospital) or by calling SummaCare at (toll-free) 888-464-8440.A SummaCare representative can help you select a PCP and/or identify their PCP code.",
				font));

		page2table2cell12.setBorderWidthBottom(0.1f);
		// page2table2cell12.setBorderColorBottom(java.awt.Color.WHITE);
		page2table2cell12.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(page2table2cell12);

		PdfPCell page2table2cell13 = new PdfPCell(
				/*new Phrase("Name: " + (getChangedValue(
						pdfPolicyDetails.getPhysicianName() + "-" + pdfPolicyDetails.getPhysician())), font));*/
				//No need of pcp selection for now
				new Phrase("Name: Please call us at 330-996-8440 for your PCP selection", font));
		page2table2cell13.setBorderWidthTop(0.1f);
		page2table2cell13.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(page2table2cell13);

		/*
		 * 
		 * PdfPTable page2table2cell11_table2 = new PdfPTable(4);
		 * page2table2cell11_table2.getDefaultCell()
		 * .setBorder(Rectangle.NO_BORDER); page2table2cell11_table2.addCell(new
		 * Phrase("Name of other coverage: ", font));
		 * page2table2cell11_table2.addCell(new Phrase("ID# for this coverage: "
		 * , font)); page2table2cell11_table2.addCell(new Phrase(
		 * "Group # for this coverage:", font));
		 * page2table2cell11_table2.addCell(new Phrase("Ending Coverage Date:",
		 * font));
		 * 
		 * PdfPCell page2table2cell11 = new PdfPCell(page2table2cell11_table2);
		 * page2table2cell11.setBorderWidthBottom(0.1f);
		 * page2table2cell11.setBorderColorBottom(java.awt.Color.WHITE);
		 * page2table2cell11.setBorderColorTop(java.awt.Color.WHITE);
		 * page2Table2.addCell(page2table2cell11);
		 * 
		 * PdfPTable page2table2cell11_table3 = new PdfPTable(4);
		 * page2table2cell11_table3.getDefaultCell()
		 * .setBorder(Rectangle.NO_BORDER); page2table2cell11_table3
		 * .addCell(new Phrase((getChangedValue(pdfPolicyDetails
		 * .getDurgNameCoverage())), font));
		 * page2table2cell11_table3.addCell(new Phrase(
		 * (getChangedValue(pdfPolicyDetails.getDurgIdCoverage())), font));
		 * page2table2cell11_table3.addCell(new Phrase(
		 * (getChangedValue(pdfPolicyDetails.getDurgGroupCoverage())), font));
		 * page2table2cell11_table3.addCell(new Phrase(
		 * (getChangedValue(pdfPolicyDetails.getDurgCoveragePeriod())), font));
		 * 
		 * PdfPCell page2table2cell12 = new PdfPCell(page2table2cell11_table3);
		 * page2table2cell12.setBorderWidthBottom(0.1f);
		 * page2table2cell12.setBorderColorTop(java.awt.Color.WHITE);
		 * page2Table2.addCell(page2table2cell12);
		 */
		return page2Table2;
	}

	/**
	 * @param pdfPolicyDetails
	 * @return
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static PdfPTable pdfPage2Table1(PolicyDetailsVO pdfPolicyDetails) throws DocumentException, IOException {

		PdfPTable page2Table1 = new PdfPTable(1);
		page2Table1.setWidthPercentage(100);
		page2Table1.setSpacingBefore(10);

		PdfPCell page2table1cell1 = new PdfPCell(
				new Phrase("Paying Your Plan Premium", FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD)));
		page2table1cell1.setGrayFill(0.85f);
		page2table1cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
		page2table1cell1.setBorderWidthBottom(0.1f);
		page2table1cell1.setBorderColorBottom(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell1);

		PdfPCell page2table1cell2 = new PdfPCell(new Phrase(
				"You can pay your monthly plan premium including any late enrollment penalty that you currently have or may owe by any of the following methods: You can receive a paper invoice in the mail each month and mail SummaCare a check for thepremiums due.You can pay your bill automatically each month from a checking or savings account using Electronic Funds Transfer. You can pay your bill automatically each month using a VISA or MasterCard. You can also choose to pay your premium by automatic deduction from your Social Security or Railroad Retirement Board (RRB) benefit check each month.No matter which method you select,you must continue to pay your Part B premium to Social Security in addition to the SummaCare plan premium.",
				font));
		page2table1cell2.setBorderWidthBottom(0.1f);
		page2table1cell2.setBorderColorBottom(java.awt.Color.WHITE);
		page2table1cell2.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell2);

		PdfPCell page2table1cell3 = new PdfPCell(new Phrase(
				"If you previously qualified for Medicare prescription drug coverage,but decided not to carry prescription coverage at least as good as Medicare's,then Medicare may determine that you owe a monthly Late Enrollment Penalty.",
				font));
		page2table1cell3.setBorderWidthBottom(0.1f);
		page2table1cell3.setBorderColorBottom(java.awt.Color.WHITE);
		page2table1cell3.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell3);

		PdfPCell page2table1cell4 = new PdfPCell(new Phrase(
				"If Medicare informs SummaCare that you owe this late enrollment penalty, it will be included in your monthly premium,even if you sign up for a $0 premium plan. If it is determined that you owe a late enrollment penalty, we need to know how you would prefer to pay it.",
				font));
		page2table1cell4.setBorderWidthBottom(0.1f);
		page2table1cell4.setBorderColorBottom(java.awt.Color.WHITE);
		page2table1cell4.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell4);

		PdfPCell page2table1cell5 = new PdfPCell(new Phrase(
				"If you are assessed a Part D-Income Related Monthly Adjustment Amount (Part D-IRMAA), you will be notified by the SocialSecurity Administration.You will be responsible for paying this extra amount in addition to your plan premium.You will either have the amount withheld from your Social Security benefit check or be billed directly by Medicare or the RRB.DO NOT pay SummaCare the PartD-IRMAA.",
				font));
		page2table1cell5.setBorderWidthBottom(0.1f);
		page2table1cell5.setBorderColorBottom(java.awt.Color.WHITE);
		page2table1cell5.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell5);

		PdfPCell page2table1cell6 = new PdfPCell(new Phrase(
				"People with limited incomes may qualify for extra help to pay for their prescription drug costs. If you qualify,Medicare could pay for 75% or more of your drug costs including monthly prescription drug premiums,annual deductibles and co-insurance.Additionally, those who qualify won't have a coverage gap or a late enrollment penalty.Many people are eligible for these savings and don't even know it.For more information about this extra help, contact your local Social Security office or call Social Security at 1-800-772-1213.TTY users should call 1-800-325-0778.You can also apply for extra help online at www.socialsecurity.gov/prescriptionhelp.",
				font));
		page2table1cell6.setBorderWidthBottom(0.1f);
		page2table1cell6.setBorderColorBottom(java.awt.Color.WHITE);
		page2table1cell6.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell6);

		PdfPCell page2table1cell7 = new PdfPCell(new Phrase(
				"If you have recently been enrolled in Medicaid or you have received a letter stating that you have qualified for Qualified Medicare Beneficiary (QMB) or Specified Low-Income Medicare Beneficiary (SLMB) status, you automatically qualify for Prescription Drug Assistance. If you need a prescription filled before SummaCare receives confirmation from the Centers for Medicare and Medicaid Services (CMS) of your eligibility status, please contact our Customer Service Department for assistance. The qualifications for Prescription Drug Assistance are based on income and assets. If you qualify for extra help with your Medicare prescription drug coverage costs,Medicare will pay all or part of your plan premium. If Medicare pays only a portion of this premium,SummaCare will bill you for the amount that Medicare doesn't cover. Please note that your eligibility for extra help will be reviewed by the Social Security office annually to see if you still qualify.",
				font));
		page2table1cell7.setBorderWidthBottom(0.1f);
		page2table1cell7.setBorderColorBottom(java.awt.Color.WHITE);
		page2table1cell7.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell7);

		PdfPCell page2table1cell8 = new PdfPCell(new Phrase(
				"Please select a premium payment option: \n(If you don't select a payment option, you will get a bill each month)",
				font));
		page2table1cell8.setBorderWidthBottom(0.1f);
		page2table1cell8.setBorderColorBottom(java.awt.Color.WHITE);
		page2table1cell8.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell8);

		String recieveMonthBillCheck = pdfPolicyDetails.getPaymentOption();
		if (recieveMonthBillCheck != null && recieveMonthBillCheck.equalsIgnoreCase("C")) {
			displayCheckBoxInPDFforForm2table1cell8(page2Table1, buttonCheckImage);
		} else {
			displayCheckBoxInPDFforForm2table1cell8(page2Table1, buttonUncheckImage);
		}

		String eftCheck = pdfPolicyDetails.getPaymentOption();
		if (eftCheck != null && eftCheck.equalsIgnoreCase("E")) {
			displayCheckBoxInPDFforForm2table1cell9(page2Table1, buttonCheckImage);
		} else {
			displayCheckBoxInPDFforForm2table1cell9(page2Table1, buttonUncheckImage);
		}

		PdfPCell page2table1cell10 = new PdfPCell(
				new Phrase("Account holder name :" + (getChangedValue(pdfPolicyDetails.getAccountHolderName())), font));
		page2table1cell10.setBorderWidthBottom(0.1f);
		page2table1cell10.setBorderColorBottom(java.awt.Color.WHITE);
		page2table1cell10.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell10);

		PdfPTable page2table1cell1_table3 = new PdfPTable(2);
		page2table1cell1_table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2table1cell1_table3.addCell(new Phrase(
				"Bank routing number : " + (getChangedValue(pdfPolicyDetails.getBankRoutingNumber())), font));
		page2table1cell1_table3.addCell(
				new Phrase("Bank account number: " + (getChangedValue(pdfPolicyDetails.getBankAccountNumber())), font));

		PdfPCell page2table1cell11 = new PdfPCell(page2table1cell1_table3);
		page2table1cell11.setBorderWidthBottom(0.1f);
		page2table1cell11.setBorderColorBottom(java.awt.Color.WHITE);
		page2table1cell11.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell11);

		String checkBoxFlagforform4AccTypecell = getChangedValue(pdfPolicyDetails.getAcctype());

		if (checkBoxFlagforform4AccTypecell.equalsIgnoreCase("C")) {
			displayButtonInPDFforForm2StmtsButton(page2Table1, buttonCheckImage, buttonUncheckImage);
		} else if ((!checkBoxFlagforform4AccTypecell.equalsIgnoreCase("C"))
				&& (checkBoxFlagforform4AccTypecell.equalsIgnoreCase("S"))) {
			displayButtonInPDFforForm2StmtsButton(page2Table1, buttonUncheckImage, buttonCheckImage);
		} else if ((!checkBoxFlagforform4AccTypecell.equalsIgnoreCase("C"))
				&& (!checkBoxFlagforform4AccTypecell.equalsIgnoreCase("S"))) {
			displayButtonInPDFforForm2StmtsButton(page2Table1, buttonUncheckImage, buttonUncheckImage);
		}
		String autoDeductionCheck = getChangedValue(pdfPolicyDetails.getPaymentOption());
		if (autoDeductionCheck.equals("D") && autoDeductionCheck != null) {
			displayCheckBoxInPDFforForm2table1cell12(page2Table1, buttonCheckImage);
		} else {
			displayCheckBoxInPDFforForm2table1cell12(page2Table1, buttonUncheckImage);
		}

		PdfPCell page2table1cell13 = new PdfPCell(new Phrase(
				"PLEASE NOTE: The Social Security deduction may take two or more months to begin after Social Security or RRB approves the deduction.Usually, the effective date of the deduction will NOT be the same as your enrollment effective date with SummaCare.SummaCare will send you a monthly bill in the mail until we receive notification from Medicare as to which month they begin taking the money out of your Social Security check.You are responsible for paying by check until such time as we have established the effective date of your withhold.",
				font));
		page2table1cell13.setBorderWidthBottom(0.1f);
		page2table1cell13.setBorderColorTop(java.awt.Color.WHITE);
		page2table1cell13.setBorderColorBottom(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell13);

		PdfPCell page2table1cell14 = new PdfPCell(new Phrase(
				"*You should know that Social Security LIMITS the automatic deduction amount allowed from your benefit check to $300.For example, should you select the SummaCare Medicare Emerald plan and there is a two month delay in processing, the entire transaction will be rejected bySocial Security because the deduction amount would exceed $300. You will then default back to being billed by mail for all unpaid premiums.",
				font));
		page2table1cell14.setBorderWidthBottom(0.1f);
		page2table1cell14.setBorderColorTop(java.awt.Color.WHITE);

		page2Table1.addCell(page2table1cell14);

		return page2Table1;

	}

	/**
	 * @return
	 */
	private static PdfPTable page2TableLogo() {
		PdfPTable page2Logotable = new PdfPTable(1);
		page2Logotable.setWidthPercentage(100);
		page2Logotable.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPCell page2logocell = new PdfPCell(Summarcarelogo_Logo);
		page2logocell.setHorizontalAlignment(Element.ALIGN_CENTER);
		page2logocell.setBorder(Rectangle.NO_BORDER);

		page2Logotable.addCell(page2logocell);

		return page2Logotable;

	}

	/**
	 * @param pdfUserDetails
	 * @param document
	 * @return
	 */
	private static PdfPTable page1TableMedicareDetails(UserDetailsVO pdfUserDetails, Document document) {
		PdfPTable page1TableMedicarddetails = new PdfPTable(1);
		page1TableMedicarddetails.setSpacingBefore(15);
		page1TableMedicarddetails.setWidthPercentage(100);

		PdfPCell page1TableMedicarddetailsHeadercell = new PdfPCell(
				new Phrase("Please Provide Your Medicare Insurance Information:",
						FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD)));
		page1TableMedicarddetailsHeadercell.setGrayFill(0.85f);

		PdfPTable page1TableMedicarddetaiils4 = new PdfPTable(2);
		page1TableMedicarddetaiils4.setSpacingBefore(5);
		page1TableMedicarddetaiils4.setWidthPercentage(85);

		PdfPTable page1TableMedicarddetailsCell22 = new PdfPTable(1);
		page1TableMedicarddetailsCell22.setWidthPercentage(85);
		page1TableMedicarddetailsCell22.addCell(Medicardlogo_Logo);

		PdfPCell sampleOnly = new PdfPCell(
				new Phrase("                                  SAMPLE ONLY"));
		sampleOnly.setBorderWidthBottom(0.0001f);
		sampleOnly.setBorder(Rectangle.NO_BORDER);

		page1TableMedicarddetailsCell22.addCell(sampleOnly);
		
		PdfPCell page1TableMedicarddetailsCell22Name = new PdfPCell(
				new Phrase("Name:                                " + (getChangedValue(pdfUserDetails.getNameBeneficiary())), font));
		page1TableMedicarddetailsCell22Name.setBorderWidthBottom(0.0001f);
		page1TableMedicarddetailsCell22Name.setBorder(Rectangle.NO_BORDER);

		page1TableMedicarddetailsCell22.addCell(page1TableMedicarddetailsCell22Name);

		PdfPCell page1TableMedicarddetailsCell22Claimnum = new PdfPCell(new Phrase("Medicare Claim Number : "
				+ (getChangedValue(pdfUserDetails.getMediacrdNumber())) + " \t \t \t Sex : "
				+ (((getChangedValue(pdfUserDetails.getBeneficiarySex())).equalsIgnoreCase("M") ? "Male" : "Female")),
				font));
		page1TableMedicarddetailsCell22Claimnum.setBorderWidthBottom(0.0001f);
		page1TableMedicarddetailsCell22Claimnum.setBorder(Rectangle.NO_BORDER);

		page1TableMedicarddetailsCell22.addCell(page1TableMedicarddetailsCell22Claimnum);

		PdfPCell page1TableMedicarddetailsCell22entitled = new PdfPCell(
				new Phrase("Is Entitled To                            Effective Date", font2));
		page1TableMedicarddetailsCell22entitled.setBorderWidthBottom(0.0001f);
		page1TableMedicarddetailsCell22entitled.setBorder(Rectangle.NO_BORDER);

		page1TableMedicarddetailsCell22.addCell(page1TableMedicarddetailsCell22entitled);

		PdfPCell page1TableMedicarddetailsCell22partA = new PdfPCell(new Phrase(
				"HOSPITAL               (PART A) : " + (getChangedValue(pdfUserDetails.getHospitalDate())), font2));
		page1TableMedicarddetailsCell22partA.setBorderWidthBottom(0.0001f);
		page1TableMedicarddetailsCell22partA.setBorder(Rectangle.NO_BORDER);

		page1TableMedicarddetailsCell22.addCell(page1TableMedicarddetailsCell22partA);

		PdfPCell page1TableMedicarddetailsCell22partB = new PdfPCell(new Phrase(
				"MEDICAL                 (PART B) : " + (getChangedValue(pdfUserDetails.getMedicalDate())), font2));
		page1TableMedicarddetailsCell22partB.setBorderWidthBottom(0.0001f);
		page1TableMedicarddetailsCell22partB.setBorder(Rectangle.NO_BORDER);
		page1TableMedicarddetailsCell22.addCell(page1TableMedicarddetailsCell22partB);

		PdfPTable M3table1 = new PdfPTable(2);
		M3table1.setSpacingBefore(5);
		M3table1.setWidthPercentage(85);

		PdfPCell page1TableMedicarddetailscell21 = new PdfPCell(new Phrase(
				"Please take out your Medicare card for this section.\n\n Please fill in these blanks so they match your red, white and blue Medicare card. \n\n -OR - \n\n Attach a copy of your Medicare card or your letter from Social Security or the Railroad Retirement Board.\n\n You must have Medicare Part A and Part B to join a Medicare Advantage plan.",
				font));
		PdfPCell M3table1cell2 = new PdfPCell(page1TableMedicarddetailsCell22);
		page1TableMedicarddetailscell21.setHorizontalAlignment(Element.ALIGN_CENTER);
		page1TableMedicarddetailscell21.setHorizontalAlignment(Element.ALIGN_BOTTOM);
		page1TableMedicarddetaiils4.addCell(page1TableMedicarddetailscell21);
		page1TableMedicarddetaiils4.addCell(M3table1cell2);

		PdfPCell M3table1cell22 = new PdfPCell(page1TableMedicarddetaiils4);

		page1TableMedicarddetails.addCell(page1TableMedicarddetailsHeadercell);
		page1TableMedicarddetails.addCell(M3table1cell22);
		return page1TableMedicarddetails;
	}

	/**
	 * @param pdfUserDetails
	 * @param document
	 * @return
	 * @throws DocumentException
	 */
	private static PdfPTable page1TabbleUserDetails(UserDetailsVO pdfUserDetails, Document document)
			throws DocumentException, IOException {
		PdfPTable page1TableUserDetails = new PdfPTable(1);
		page1TableUserDetails.setSpacingBefore(10);
		page1TableUserDetails.setWidthPercentage(100);
		page1TableUserDetails.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPTable page1TableUserDetailsNamecell = new PdfPTable(4);
		page1TableUserDetailsNamecell.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		page1TableUserDetailsNamecell.addCell(new Phrase("First name : ", font));
		page1TableUserDetailsNamecell.addCell(new Phrase((getChangedValue(pdfUserDetails.getFirstName())), font));
		page1TableUserDetailsNamecell.addCell(new Phrase("Middle name : ", font));
		page1TableUserDetailsNamecell.addCell(new Phrase(getChangedValue(pdfUserDetails.getMiddleInitial()), font));

		PdfPTable page1TableUserDetailMiddleName = new PdfPTable(1);
		page1TableUserDetailMiddleName.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page1TableUserDetailMiddleName
				.addCell(new Phrase("Last name : " + (getChangedValue(pdfUserDetails.getLastName())), font));

		PdfPTable page1TableUserDetailsuffix = new PdfPTable(1);
		page1TableUserDetailsuffix.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page1TableUserDetailsuffix
				.addCell(new Phrase("Suffix : " + (getChangedValue(pdfUserDetails.getSuffix())), font));

		PdfPTable page1TableUserDetailsCell1 = new PdfPTable(3);
		page1TableUserDetailsCell1.setSpacingAfter(8);
		page1TableUserDetailsCell1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page1TableUserDetailsCell1.setWidthPercentage(100);
		// for 2017
		page1TableUserDetailsCell1.addCell(page1TableUserDetailMiddleName);
		page1TableUserDetailsCell1.addCell(page1TableUserDetailsNamecell);
		page1TableUserDetailsCell1.addCell(page1TableUserDetailsuffix);
		
		PdfPTable page1TableUserDetailsCell2Home = new PdfPTable(2);
		page1TableUserDetailsCell2Home.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page1TableUserDetailsCell2Home.addCell(new Phrase("Home Phone number: ", font));
		page1TableUserDetailsCell2Home.addCell(new Phrase((getChangedValue(pdfUserDetails.getHomePhNumber())), font));

		PdfPTable page1TableUserDetailsCell2 = new PdfPTable(3);
		page1TableUserDetailsCell2.setSpacingAfter(8);
		page1TableUserDetailsCell2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page1TableUserDetailsCell2.setWidthPercentage(100);
		page1TableUserDetailsCell2
				.addCell(new Phrase("Birth date :" + (getChangedValue(pdfUserDetails.getBirthDate())), font));
		page1TableUserDetailsCell2.addCell(new Phrase(
				"Sex : " + ((getChangedValue(pdfUserDetails.getSex())).equalsIgnoreCase("M") ? "M" : "F"), font));
		page1TableUserDetailsCell2.addCell(page1TableUserDetailsCell2Home);

		PdfPCell page1TableUserDetailscell2main = new PdfPCell(page1TableUserDetailsCell2);
		page1TableUserDetailscell2main.setBorderWidthBottom(0f);
		page1TableUserDetailscell2main.setBorderColorBottom(java.awt.Color.WHITE);
		page1TableUserDetailscell2main.setBorderColorTop(java.awt.Color.WHITE);
		page1TableUserDetailscell2main.setSpaceCharRatio(8);

		PdfPTable permenentAddress1 = new PdfPTable(2);
		permenentAddress1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		permenentAddress1.addCell(new Phrase("Permanent Residence Street Address: (P.O. Box is not allowed) : ", font));
		permenentAddress1.addCell(new Phrase((getChangedValue(pdfUserDetails.getPermanentAddr())), font));

		PdfPTable permenentAddress2 = new PdfPTable(2);
		permenentAddress2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		permenentAddress2.addCell(new Phrase(
				"                                                                                                          ",
				font));
		permenentAddress2.addCell(new Phrase((getChangedValue(pdfUserDetails.getPermanentStrt())), font));

		PdfPTable permenentAddressCell = new PdfPTable(1);
		permenentAddressCell.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		permenentAddressCell.addCell(permenentAddress1);
		permenentAddressCell.addCell(permenentAddress2);

		PdfPTable page1TableUserDetailsCell32 = new PdfPTable(2);
		page1TableUserDetailsCell32.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page1TableUserDetailsCell32.addCell(new Phrase("Alternative Phone number : ", font));
		page1TableUserDetailsCell32.addCell(new Phrase((getChangedValue(pdfUserDetails.getAltrPhNumber())), font));

		PdfPTable page1TableUserDetailsCell3and4 = new PdfPTable(2);
		page1TableUserDetailsCell3and4.setSpacingAfter(8);
		page1TableUserDetailsCell3and4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page1TableUserDetailsCell3and4.setWidths(new int[] { 100, 50 });
		page1TableUserDetailsCell3and4
				.addCell(new Phrase("Email Address : " + (getChangedValue(pdfUserDetails.getEmailAddr())), font));

		page1TableUserDetailsCell3and4.addCell(page1TableUserDetailsCell32);
		page1TableUserDetailsCell3and4.addCell(permenentAddressCell);
		page1TableUserDetailsCell3and4
				.addCell(new Phrase("Apt # : " + (getChangedValue(pdfUserDetails.getPermanentApt())), font));

		PdfPCell page1TableUserDetailsCell1main = new PdfPCell(page1TableUserDetailsCell1);
		page1TableUserDetailsCell1main.setBorderWidthBottom(0f);
		page1TableUserDetailsCell1main.setBorderColorBottom(java.awt.Color.WHITE);
		page1TableUserDetailsCell1main.setSpaceCharRatio(8);

		PdfPCell page1TableUserDetailsCell2and4main = new PdfPCell(page1TableUserDetailsCell3and4);
		page1TableUserDetailsCell2and4main.setBorderWidthBottom(0.01f);
		page1TableUserDetailsCell2and4main.setBorderColorTop(java.awt.Color.WHITE);
		page1TableUserDetailsCell2and4main.setBorderColorBottom(java.awt.Color.WHITE);

		page1TableUserDetails.addCell(page1TableUserDetailsCell1main);
		page1TableUserDetails.addCell(page1TableUserDetailscell2main);
		page1TableUserDetails.addCell(page1TableUserDetailsCell2and4main);

		PdfPTable page1TableUserDetailsCell5 = new PdfPTable(4);
		page1TableUserDetailsCell5.setSpacingAfter(8);
		page1TableUserDetailsCell5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page1TableUserDetailsCell5
				.addCell(new Phrase("County : " + (getChangedValue(pdfUserDetails.getPermanentCounty())), font));
		page1TableUserDetailsCell5
				.addCell(new Phrase("City : " + (getChangedValue(pdfUserDetails.getPermanentCity())), font));

		page1TableUserDetailsCell5
				.addCell(new Phrase("State : " + (getChangedValue(pdfUserDetails.getPermanentState())), font));
		page1TableUserDetailsCell5
				.addCell(new Phrase("ZIP Code: " + (getChangedValue(pdfUserDetails.getPermanentZip())), font));

		PdfPCell page1TableUserDetailsCell5main = new PdfPCell(page1TableUserDetailsCell5);
		page1TableUserDetailsCell5main.setBorderWidthBottom(0.01f);
		page1TableUserDetailsCell5main.setBorderColorTop(java.awt.Color.WHITE);
		page1TableUserDetailsCell5main.setBorderColorBottom(java.awt.Color.WHITE);

		page1TableUserDetails.addCell(page1TableUserDetailsCell5main);

		PdfPTable page1TableUserDetailsCell6 = new PdfPTable(2);
		page1TableUserDetailsCell6.setSpacingAfter(8);
		page1TableUserDetailsCell6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page1TableUserDetailsCell6.setWidths(new int[] { 100, 50 });

		PdfPTable mailAddressCell = new PdfPTable(2);
		mailAddressCell.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		mailAddressCell.addCell(new Phrase(
				"Mailing Address- Street Address/P.O.Box: \n (Only if different from your Permanent Residential Address) : ",
				font));
		mailAddressCell.addCell(new Phrase((getChangedValue(pdfUserDetails.getMailingAddr())), font));
		mailAddressCell.addCell(new Phrase(
				"                                                                                                 ",
				font));
		mailAddressCell.addCell(new Phrase((getChangedValue(pdfUserDetails.getMailingStrt())), font));

		page1TableUserDetailsCell6.addCell(mailAddressCell);
		page1TableUserDetailsCell6
				.addCell(new Phrase("Apt # : " + (getChangedValue(pdfUserDetails.getMailingApt())), font));

		PdfPCell page1TableUserDetailsCell6main = new PdfPCell(page1TableUserDetailsCell6);
		page1TableUserDetailsCell6main.setBorderWidthBottom(0.01f);
		page1TableUserDetailsCell6main.setBorderColorTop(java.awt.Color.WHITE);
		page1TableUserDetailsCell6main.setBorderColorBottom(java.awt.Color.WHITE);

		page1TableUserDetails.addCell(page1TableUserDetailsCell6main);

		PdfPTable page1TableUserDetailsCell7 = new PdfPTable(3);
		page1TableUserDetailsCell7.setSpacingAfter(8);
		page1TableUserDetailsCell7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page1TableUserDetailsCell7
				.addCell(new Phrase("City  : " + (getChangedValue(pdfUserDetails.getMailingCity())), font));
		page1TableUserDetailsCell7
				.addCell(new Phrase("State : " + (getChangedValue(pdfUserDetails.getMailingState())), font));
		page1TableUserDetailsCell7
				.addCell(new Phrase("ZIP Code : " + (getChangedValue(pdfUserDetails.getMailingZip())), font));

		PdfPCell page1TableUserDetailsCell7main = new PdfPCell(page1TableUserDetailsCell7);
		page1TableUserDetailsCell7main.setBorderWidthBottom(0.01f);
		page1TableUserDetailsCell7main.setBorderColorTop(java.awt.Color.WHITE);
		page1TableUserDetailsCell7main.setBorderColorBottom(java.awt.Color.WHITE);
		page1TableUserDetails.addCell(page1TableUserDetailsCell7main);

		String relationshipYou = getChangedValue(pdfUserDetails.getRelationYou());

		String emCount = (String) getChangedValue(pdfUserDetails.getEmcont());

		PdfPTable page1TableUserDetailsCell8 = null;

		if (emCount.equalsIgnoreCase("E") && !emCount.isEmpty()) {

			page1TableUserDetailsCell8 = displayButtonInPDFforForm1emCountButton(buttonCheckImage, buttonUncheckImage);

		} else if (emCount.equalsIgnoreCase("P") && !emCount.isEmpty()) {
			page1TableUserDetailsCell8 = displayButtonInPDFforForm1emCountButton(buttonUncheckImage, buttonCheckImage);
		} else if (emCount.isEmpty()) {
			page1TableUserDetailsCell8 = displayButtonInPDFforForm1emCountButton(buttonUncheckImage,
					buttonUncheckImage);
		}

		PdfPCell page1TableUserDetailsCell8main = new PdfPCell(page1TableUserDetailsCell8);

		page1TableUserDetailsCell8main.setBorderWidthBottom(0.01f);
		page1TableUserDetailsCell8main.setBorderColorTop(java.awt.Color.WHITE);
		page1TableUserDetailsCell8main.setBorderColorBottom(java.awt.Color.WHITE);

		page1TableUserDetails.addCell(page1TableUserDetailsCell8main);

		PdfPTable page1TableUserDetailsCell9 = new PdfPTable(3);
		page1TableUserDetailsCell9.setSpacingAfter(8);
		page1TableUserDetailsCell9.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page1TableUserDetailsCell9.addCell(new Phrase("Contact : ", font));
		page1TableUserDetailsCell9.addCell(new Phrase((getChangedValue(pdfUserDetails.getEmergencyCont())), font));
		page1TableUserDetailsCell9.addCell(new Phrase("Relationship to You : " + relationshipYou, font));

		PdfPCell page1TableUserDetailsCell9main = new PdfPCell(page1TableUserDetailsCell9);
		page1TableUserDetailsCell9main.setBorderWidthBottom(0.1f);
		page1TableUserDetailsCell9main.setBorderColorTop(java.awt.Color.WHITE);
		page1TableUserDetailsCell9main.setBorderColorBottom(java.awt.Color.WHITE);
		page1TableUserDetails.addCell(page1TableUserDetailsCell9main);

		PdfPCell page1TableUserDetailsCell10 = new PdfPCell(
				new Phrase("Phone: " + (getChangedValue(pdfUserDetails.getEmergPhNum())), font));
		page1TableUserDetailsCell10.setBorderWidthBottom(0.1f);
		page1TableUserDetailsCell10.setBorderColorTop(java.awt.Color.WHITE);
		page1TableUserDetailsCell10.setBorderColorBottom(java.awt.Color.WHITE);
		page1TableUserDetails.addCell(page1TableUserDetailsCell10);

		return page1TableUserDetails;

	}

	private static PdfPTable displayButtonInPDFforForm1emCountButton(Image check1, Image check2)
			throws DocumentException, IOException {

		PdfPTable emCountTable = new PdfPTable(4);
		emCountTable.setWidthPercentage(100);
		emCountTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		emCountTable.setWidths(new int[] { 4, 80, 4, 80 });
		emCountTable.addCell(check1);
		emCountTable.addCell(new Phrase("Emergency Contact or", font));
		emCountTable.addCell(check2);
		emCountTable.addCell(new Phrase("Power of Attorney(Medical POA only)", font));

		return emCountTable;

	}

	private static void displayButtonInPDFforForm1StmtsButton(PdfPTable page3Table3, Image check1, Image check2,
			String phrase1, String phrase2) throws DocumentException, IOException {

		PdfPTable page3Table3Cell1table1 = new PdfPTable(4);
		page3Table3Cell1table1.setWidthPercentage(100);
		page3Table3Cell1table1.setSpacingBefore(10);
		page3Table3Cell1table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		page3Table3Cell1table1.setWidths(new int[] { 4, 80, 4, 80 });

		page3Table3Cell1table1.addCell(check1);
		page3Table3Cell1table1.addCell(new Phrase(phrase1, font));
		page3Table3Cell1table1.addCell(check2);
		page3Table3Cell1table1.addCell(new Phrase(phrase2, font));

		PdfPCell page3table3cell1 = new PdfPCell(page3Table3Cell1table1);
		page3table3cell1.setBorderWidthBottom(0.1f);
		page3Table3.addCell(page3table3cell1);

	}

	/**
	 * @param pdfUserDetails
	 * @param document
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void page1optimaPlanTable(UserDetailsVO pdfUserDetails, Document document)
			throws DocumentException, IOException {
		String header = pdfUserDetails.getOptimaMedicare();

		if ((header.equalsIgnoreCase("049N") || header.equalsIgnoreCase("050N")) && !header.isEmpty()) {
			displayButtonInPDFforForm1OptimaButton(buttonCheckImage, buttonUncheckImage, buttonUncheckImage,
					buttonUncheckImage, document, pdfUserDetails);
		} else if ((header.equalsIgnoreCase("047N") || header.equalsIgnoreCase("044N")) && !header.isEmpty()) {
			displayButtonInPDFforForm1OptimaButton(buttonUncheckImage, buttonCheckImage, buttonUncheckImage,
					buttonUncheckImage, document, pdfUserDetails);
		} else if ((header.equalsIgnoreCase("029N") || header.equalsIgnoreCase("048N")) && !header.isEmpty()) {
			displayButtonInPDFforForm1OptimaButton(buttonUncheckImage, buttonUncheckImage, buttonCheckImage,
					buttonUncheckImage, document, pdfUserDetails);
		} else if ((header.equalsIgnoreCase("028N")) && !header.isEmpty()) {
			displayButtonInPDFforForm1OptimaButton(buttonUncheckImage, buttonUncheckImage, buttonUncheckImage,
					buttonCheckImage, document, pdfUserDetails);
		}

		else {
			displayButtonInPDFforForm1OptimaButton(buttonUncheckImage, buttonUncheckImage, buttonUncheckImage,
					buttonUncheckImage, document, pdfUserDetails);
		}

	}

	/**
	 * @param request
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void pdffontInstances(HttpServletRequest request) throws DocumentException, IOException {
		System.out.println("in pdffontInstances start ");
		ServletContext context = request.getSession().getServletContext();
		String absoluteDiskPathOfArialfont = context.getRealPath(WebappConstant.RELATIVEWEBPATHOFARIALFONT);
		base = BaseFont.createFont(absoluteDiskPathOfArialfont, BaseFont.WINANSI, false);
		font = new Font(base, 8, Font.NORMAL, java.awt.Color.BLACK);
		font2 = new Font(base, 9, Font.BOLD, java.awt.Color.BLACK);
		System.out.println("in pdffontInstances exit.. ");
	}

	/**
	 * @param request
	 * @throws MalformedURLException
	 * @throws IOException
	 * @throws DocumentException
	 */
	private static void pdfImageInstances(HttpServletRequest request)
			throws MalformedURLException, IOException, DocumentException {

		System.out.println("in pdfImageInstances method..");
		ServletContext context = request.getSession().getServletContext();

		String absoluteDiskPathOfMedicard_logo = context.getRealPath(WebappConstant.RELATIVEWEBPATHOFMEDICARDLOGO);

		String absoluteDiskPathOfSampleCheckImage = context
				.getRealPath(WebappConstant.RELATIVEWEBPATHOFSAMPLECHECKIMAGE);

		String absoluteDiskPathOfCheckImage = context.getRealPath(WebappConstant.RELATIVEWEBPATHOFCHECKIMAGE);

		String absoluteDiskPathOfUncheckImage = context.getRealPath(WebappConstant.RELATIVEWEBPATHOFUNCHECKIMAGE);

		String absoluteDiskPathOfbuttoncheckImage = context
				.getRealPath(WebappConstant.RELATIVEWEBPATHOFBUTTONCHECKIMAGE);

		String absoluteDiskPathOfbuttonUncheckImage = context
				.getRealPath(WebappConstant.RELATIVEWEBPATHOFBUTTONUNCHECKIMAGE);

		String absoluteDiskPathOfStopImage = context.getRealPath(WebappConstant.RELATIVEWEBPATHOFSTOPIMAGE);

		String absoluteDiskPathOfSummacare_logo = context
				.getRealPath(WebappConstant.RELATIVEWEBPATHOFSUMMACARELOGOIMAGE);

		String absoluteDiskPathOfTickImage = context.getRealPath(WebappConstant.RELATIVEWEBPATHOFTICKIMAGE);

		Summarcarelogo_Logo = Image.getInstance(absoluteDiskPathOfSummacare_logo);
		Summarcarelogo_Logo.scaleToFit(150f, 150f);

		Medicardlogo_Logo = Image.getInstance(absoluteDiskPathOfMedicard_logo);
		Medicardlogo_Logo.scaleToFit(100f, 100f);

		sampleCheck = Image.getInstance(absoluteDiskPathOfSampleCheckImage);
		tick = Image.getInstance(absoluteDiskPathOfTickImage);
		buttonCheckImage = Image.getInstance(absoluteDiskPathOfbuttoncheckImage);
		buttonUncheckImage = Image.getInstance(absoluteDiskPathOfbuttonUncheckImage);

		check = Image.getInstance(absoluteDiskPathOfCheckImage);
		uncheck = Image.getInstance(absoluteDiskPathOfUncheckImage);

		stop = Image.getInstance(absoluteDiskPathOfStopImage);
		stop.scaleToFit(30f, 30f);

		System.out.println("in pdfImageInstances method.exit.");
	}

	/**
	 * @param optimaHealth_Logo
	 * @return
	 */
	private static PdfPTable page1LogoTable(Image Summarcarelogo_Logo) {

		System.out.println("in page1LogoTable ..");
		PdfPTable logo = new PdfPTable(1);
		logo.setSpacingBefore(10);
		logo.setWidthPercentage(100);
		logo.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPCell logocell1 = new PdfPCell(Summarcarelogo_Logo);
		logocell1.setHorizontalAlignment(Element.ALIGN_CENTER);
		logocell1.setBorder(Rectangle.NO_BORDER);

		logo.addCell(logocell1);
		return logo;
	}

	private static PdfPTable page1BrailleTable1() {

		PdfPTable Braille = new PdfPTable(1);
		Braille.setSpacingBefore(15);
		Braille.setWidthPercentage(100);
		Braille.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		System.out.println("PDFUTILGen  page1BrailleTable i am in braille table");
		PdfPCell Braillcell1 = new PdfPCell(
				new Phrase(" 2017 Medicare Advantage Prescription Drug Plan (MAPD) \nIndividual Enrollment Form.",
						FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD)));
		Braillcell1.setHorizontalAlignment(Element.ALIGN_CENTER);
		Braillcell1.setBorder(Rectangle.NO_BORDER);
		Braille.addCell(Braillcell1);
		return Braille;
	}

	private static PdfPTable page1BrailleTable() {

		PdfPTable Braille = new PdfPTable(1);
		Braille.setSpacingBefore(15);
		Braille.setWidthPercentage(100);
		Braille.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		System.out.println("PDFUTILGen  page1BrailleTable i am in braille table");
		PdfPCell Braillcell1 = new PdfPCell(
				new Phrase("Please contact SummaCare if you need information in a different format.",
						FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD)));
		Braillcell1.setHorizontalAlignment(Element.ALIGN_CENTER);
		Braillcell1.setBorder(Rectangle.NO_BORDER);
		Braille.addCell(Braillcell1);
		return Braille;
	}

	/**
	 * @param check1
	 * @param check2
	 * @param document
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void displayButtonInPDFforForm1OptimaButton(Image check1, Image check2, Image check3, Image check4,
			Document document, UserDetailsVO pdfUserDetails) throws DocumentException, IOException {

		PdfPTable userDetailsTableFirstHeader = new PdfPTable(1);
		userDetailsTableFirstHeader.setWidthPercentage(100);
		userDetailsTableFirstHeader.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		userDetailsTableFirstHeader.addCell(new Phrase(
				"Check which plan you want to enroll in.Please note that plan premiums may be different depending on the region in which you reside.Please refer to the 2017 SummaCare Medicare Enrollment Guide for more information.",
				font));

		PdfPTable userDetailsTableHeader = new PdfPTable(8);
		userDetailsTableHeader.setWidthPercentage(100);
		userDetailsTableHeader.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		userDetailsTableHeader.setWidths(new int[] { 4, 30, 4, 30, 4, 30, 4, 30 });

		userDetailsTableHeader.addCell(check1);
		userDetailsTableHeader.addCell(new Phrase("TOPAZ (HMO)\nNortheast $0/month \nNorthwest $0/month ", font));
		userDetailsTableHeader.addCell(check2);
		userDetailsTableHeader.addCell(new Phrase("RUBY (HMO)\nNortheast $40/month \nNorthwest $43/month", font));

		userDetailsTableHeader.addCell(check3);
		userDetailsTableHeader
				.addCell(new Phrase("SAPPHIRE (HMO-POS)\nNortheast $76/month \nNorthwest $96/month", font));

		userDetailsTableHeader.addCell(check4);
		userDetailsTableHeader.addCell(new Phrase("EMERALD (HMO-POS)\nNortheast $180/month", font));

		PdfPTable Page1TableHeader = new PdfPTable(1);
		Page1TableHeader.setSpacingBefore(10);
		Page1TableHeader.setWidthPercentage(100);
		PdfPCell userDetailsTableHeaderPlan = new PdfPCell(userDetailsTableHeader);
		userDetailsTableHeaderPlan.setBorderColor(java.awt.Color.BLACK);
		PdfPCell userDetailsTableHeaderMain = new PdfPCell(
				new Phrase("To enroll in SummaCare, please provide the following information:",
						FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD)));

		userDetailsTableHeaderMain.setHorizontalAlignment(Element.ALIGN_CENTER);
		userDetailsTableHeaderMain.setGrayFill(0.65f);

		PdfPCell effectiveDate = new PdfPCell(
				new Phrase("Effective date: The Date you want coverage to begin. In general, requests to enroll will be effective on the first day of the month after this form is received. " + (getChangedValue(pdfUserDetails.getEffDate())), font));
		effectiveDate.setHorizontalAlignment(Element.ALIGN_LEFT);

		Page1TableHeader.addCell(userDetailsTableHeaderMain);
		Page1TableHeader.addCell(userDetailsTableFirstHeader);
		Page1TableHeader.addCell(userDetailsTableHeaderPlan);
		Page1TableHeader.addCell(effectiveDate);

		document.add(Page1TableHeader);
	}

	/**
	 * @param page4Table6
	 * @param check1
	 * @param check2
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	/*
	 * private static void displayButtonInPDFforForm4ApplicationType( PdfPTable
	 * page4Table6, Image check1, Image check2, Image check3) throws
	 * DocumentException, IOException {
	 * 
	 * PdfPTable page4Table6Cell1table1 = new PdfPTable(7);
	 * page4Table6Cell1table1.setWidthPercentage(100);
	 * page4Table6Cell1table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	 * page4Table6Cell1table1.setWidths(new int[] { 100, 7, 100, 7, 100, 7, 100
	 * }); page4Table6Cell1table1.addCell(new Phrase("Agent Use Only : ",
	 * font)); page4Table6Cell1table1.addCell(check1);
	 * page4Table6Cell1table1.addCell(new Phrase("Web Application ", font));
	 * page4Table6Cell1table1.addCell(check2);
	 * page4Table6Cell1table1.addCell(new Phrase("Telephonic Application ",
	 * font)); page4Table6Cell1table1.addCell(check3);
	 * page4Table6Cell1table1.addCell(new Phrase("Broker Application ", font));
	 * 
	 * PdfPCell page4table6Cell1 = new PdfPCell(page4Table6Cell1table1);
	 * page4table6Cell1.setBorderWidthBottom(0.1f);
	 * page4table6Cell1.setBorderColorBottom(java.awt.Color.WHITE);
	 * page4Table6.addCell(page4table6Cell1); }
	 */

	/**
	 * @param page3Table1
	 * @param check1
	 * @param checkBoxFlagForCellUS
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	/*
	 * private static void displayCheckBoxInPDFforForm3table1cellUS( PdfPTable
	 * page3Table1, Image check1, String checkBoxFlagForCellUS) throws
	 * DocumentException, IOException {
	 * 
	 * PdfPTable page3table1cellUscheck = new PdfPTable(2);
	 * page3table1cellUscheck.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	 * page3table1cellUscheck.setWidths(new int[] { 2, 80 });
	 * page3table1cellUscheck.addCell(check1);
	 * page3table1cellUscheck.addCell(new Phrase(
	 * "No longer eligible for Special Needs Plan and was disenrolled : " +
	 * (getChangedValue(checkBoxFlagForCellUS)), font));
	 * 
	 * PdfPCell page3table1cell112 = new PdfPCell(page3table1cellUscheck);
	 * page3table1cell112.setBorderWidthBottom(0.1f);
	 * page3table1cell112.setBorderColorBottom(java.awt.Color.WHITE);
	 * page3table1cell112.setBorderColorTop(java.awt.Color.WHITE);
	 * page3Table1.addCell(page3table1cell112);
	 * 
	 * }
	 */
	private static void displayCheckBoxInPDFforForm3table1cellMADP(PdfPTable page4Table1, Image check1,
			String checkBoxFlagForCellMADP) throws DocumentException, IOException {

		PdfPTable page4table1cellMADPcheck = new PdfPTable(2);
		page4table1cellMADPcheck.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page4table1cellMADPcheck.setWidths(new int[] { 2, 80 });
		page4table1cellMADPcheck.addCell(check1);
		page4table1cellMADPcheck.addCell(new Phrase(
				"I used the Medicare Advantage Disenrollment Period MADP to disenroll from my Medicare plan between January 1 and February 14. ",
				font));

		PdfPCell page4table1cell112 = new PdfPCell(page4table1cellMADPcheck);
		page4table1cell112.setBorderWidthBottom(0.1f);
		page4table1cell112.setBorderColorBottom(java.awt.Color.WHITE);
		page4table1cell112.setBorderColorTop(java.awt.Color.WHITE);
		page4Table1.addCell(page4table1cell112);

	}

	/**
	 * @param page3Table1
	 * @param check1
	 * @param checkBoxFlagforCell10
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	/*
	 * private static void displayCheckBoxInPDFforForm3table1cell10( PdfPTable
	 * page3Table1, Image check1, String checkBoxFlagforCell10) throws
	 * DocumentException, IOException {
	 * 
	 * PdfPTable page3table1cell10check = new PdfPTable(2);
	 * page3table1cell10check.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	 * page3table1cell10check.setWidths(new int[] { 2, 80 });
	 * page3table1cell10check.addCell(check1);
	 * page3table1cell10check.addCell(new Phrase(
	 * "No longer eligible for Special Needs Plan and was disenrolled : " +
	 * (getChangedValue(checkBoxFlagforCell10)), font));
	 * 
	 * PdfPCell page3table1cell112 = new PdfPCell(page3table1cell10check);
	 * page3table1cell112.setBorderWidthBottom(0.1f);
	 * page3table1cell112.setBorderColorBottom(java.awt.Color.WHITE);
	 * page3table1cell112.setBorderColorTop(java.awt.Color.WHITE);
	 * page3Table1.addCell(page3table1cell112); }
	 */
	/**
	 * @param page3Table1
	 * @param check1
	 * @param checkBoxFlagforCell8
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	/*
	 * private static void displayCheckBoxInPDFforForm3table1cell9( PdfPTable
	 * page3Table1, Image check1, String checkBoxFlagforCell8) throws
	 * DocumentException, IOException {
	 * 
	 * PdfPTable page3table1cell9check = new PdfPTable(2);
	 * page3table1cell9check.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	 * page3table1cell9check.setWidths(new int[] { 2, 80 });
	 * page3table1cell9check.addCell(check1); page3table1cell9check .addCell(new
	 * Phrase(
	 * "Moving in, live in, or recently moved out of a Long-Term Care Facility (nursing home) : "
	 * + (getChangedValue(checkBoxFlagforCell8)), font));
	 * 
	 * PdfPCell page3table1cell9 = new PdfPCell(page3table1cell9check);
	 * page3table1cell9.setBorderWidthBottom(0.1f);
	 * page3table1cell9.setBorderColorBottom(java.awt.Color.WHITE);
	 * page3table1cell9.setBorderColorTop(java.awt.Color.WHITE);
	 * page3Table1.addCell(page3table1cell9); }
	 *//**
		 * @param page3Table1
		 * @param check1
		 * @param checkBoxFlagforCell7
		 * @param absoluteDiskPathOfArialfont
		 * @throws DocumentException
		 * @throws IOException
		 */

	/*
	 * private static void displayCheckBoxInPDFforForm3table1cell8( PdfPTable
	 * page3Table1, Image check1, String checkBoxFlagforCell7) throws
	 * DocumentException, IOException {
	 * 
	 * PdfPTable page3table1cell8check = new PdfPTable(2);
	 * page3table1cell8check.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	 * page3table1cell8check.setWidths(new int[] { 2, 80 });
	 * page3table1cell8check.addCell(check1); page3table1cell8check.addCell(new
	 * Phrase(
	 * "Have Medicaid or the state helps pay for your Medicare. Medicaid Number : "
	 * + (getChangedValue(checkBoxFlagforCell7)), font));
	 * 
	 * PdfPCell page3table1cell8 = new PdfPCell(page3table1cell8check);
	 * page3table1cell8.setBorderWidthBottom(0.1f);
	 * page3table1cell8.setBorderColorBottom(java.awt.Color.WHITE);
	 * page3table1cell8.setBorderColorTop(java.awt.Color.WHITE);
	 * page3Table1.addCell(page3table1cell8); }
	 */
	/**
	 * @param page2Table1
	 * @param check1
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void displayCheckBoxInPDFforForm2table1cell8(PdfPTable page2Table1, Image check1)
			throws DocumentException, IOException {

		PdfPTable page2table1cell8check_table2 = new PdfPTable(2);
		page2table1cell8check_table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2table1cell8check_table2.setWidths(new int[] { 2, 80 });
		page2table1cell8check_table2.addCell(check1);
		page2table1cell8check_table2.addCell(new Phrase("Get a monthly bill in the mail", font));

		PdfPCell page2table1cell8 = new PdfPCell(page2table1cell8check_table2);
		page2table1cell8.setBorderWidthBottom(0.1f);
		page2table1cell8.setBorderColorBottom(java.awt.Color.WHITE);
		page2table1cell8.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell8);

	}

	/**
	 * @param page2Table1
	 * @param check1
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void displayCheckBoxInPDFforForm2table1cell9(PdfPTable page2Table1, Image check1)
			throws DocumentException, IOException {

		PdfPTable page2table1cell9check_table2 = new PdfPTable(2);
		page2table1cell9check_table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2table1cell9check_table2.setWidths(new int[] { 2, 80 });
		page2table1cell9check_table2.addCell(check1);
		page2table1cell9check_table2.addCell(new Phrase(
				"Electronic funds transfer (EFT) from your bank account each month. Please enclose a VOIDED check if possible and provide the following:",
				font));

		PdfPCell page2table1cell9 = new PdfPCell(page2table1cell9check_table2);
		page2table1cell9.setBorderWidthBottom(0.1f);
		page2table1cell9.setBorderColorBottom(java.awt.Color.WHITE);
		page2table1cell9.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell9);

	}

	/**
	 * @param page2Table1
	 * @param check1
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void displayCheckBoxInPDFforForm2table1cell12(PdfPTable page2Table1, Image check1)
			throws DocumentException, IOException {

		PdfPTable page2table1cell12check_table2 = new PdfPTable(2);
		page2table1cell12check_table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2table1cell12check_table2.setWidths(new int[] { 2, 80 });
		page2table1cell12check_table2.addCell(check1);
		page2table1cell12check_table2.addCell(new Phrase(
				"*Automatic deduction from your monthly Social Security or Railroad Retirement Board (RRB) benefit check.",
				font));

		PdfPCell page2table1cell12 = new PdfPCell(page2table1cell12check_table2);
		page2table1cell12.setBorderWidthBottom(0.1f);
		page2table1cell12.setBorderColorBottom(java.awt.Color.WHITE);
		page2table1cell12.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell12);
	}

	/**
	 * @param page2Table2
	 * @param check1
	 * @param check2
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void displayButtonInPDFforForm2table2cell10(PdfPTable page2Table2, Image check1, Image check2,
			String phrase) throws DocumentException, IOException {

		PdfPTable page2table2Cell9Buttontable = new PdfPTable(5);
		page2table2Cell9Buttontable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2table2Cell9Buttontable.setWidths(new int[] { 200, 6, 10, 6, 10 });
		page2table2Cell9Buttontable.addCell(new Phrase(phrase, font));
		page2table2Cell9Buttontable.addCell(check1);
		page2table2Cell9Buttontable.addCell(new Phrase("Yes", font));
		page2table2Cell9Buttontable.addCell(check2);
		page2table2Cell9Buttontable.addCell(new Phrase("No", font));

		PdfPCell page2table2cell9 = new PdfPCell(page2table2Cell9Buttontable);
		page2table2cell9.setBorderWidthBottom(0.1f);
		page2table2cell9.setBorderColorBottom(java.awt.Color.WHITE);
		page2table2cell9.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(page2table2cell9);

	}

	/*
	 * private static void displayButtonInPDFforForm2table2cell9( PdfPTable
	 * page2Table2, Image check1, Image check2) throws DocumentException,
	 * IOException {
	 * 
	 * PdfPTable page2table2Cell9Buttontable = new PdfPTable(5);
	 * page2table2Cell9Buttontable.getDefaultCell().setBorder(
	 * Rectangle.NO_BORDER); page2table2Cell9Buttontable.setWidths(new int[] {
	 * 200, 6, 10, 6, 10 }); page2table2Cell9Buttontable .addCell(new Phrase(
	 * "3.Are you a resident in a long-term care facility, such as a nursing home ? "
	 * , font)); page2table2Cell9Buttontable.addCell(check1);
	 * page2table2Cell9Buttontable.addCell(new Phrase("Yes", font));
	 * page2table2Cell9Buttontable.addCell(check2);
	 * page2table2Cell9Buttontable.addCell(new Phrase("No", font));
	 * 
	 * PdfPCell page2table2cell9 = new PdfPCell(page2table2Cell9Buttontable);
	 * page2table2cell9.setBorderWidthBottom(0.1f);
	 * page2table2cell9.setBorderColorBottom(java.awt.Color.WHITE);
	 * page2table2cell9.setBorderColorTop(java.awt.Color.WHITE);
	 * page2Table2.addCell(page2table2cell9);
	 * 
	 * }
	 */

	/**
	 * @param page2Table2
	 * @param check1
	 * @param check2
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void displayButtonInPDFforForm2table2cell2(PdfPTable page2Table2, Image check1, Image check2)
			throws DocumentException, IOException {

		PdfPTable page2table2Cell3Buttontable = new PdfPTable(5);
		page2table2Cell3Buttontable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2table2Cell3Buttontable.setWidths(new int[] { 200, 6, 10, 6, 10 });
		page2table2Cell3Buttontable.addCell(new Phrase(
				" 2. Some individuals may have other drug coverage, including other private insurance,TRICARE,Federal employee health benefits coverage, VA benefits, or State pharmaceutical assistance programs.Will you have other prescription drug coverage in addition to SummaCare?",
				font));
		page2table2Cell3Buttontable.addCell(check1);
		page2table2Cell3Buttontable.addCell(new Phrase("Yes", font));
		page2table2Cell3Buttontable.addCell(check2);
		page2table2Cell3Buttontable.addCell(new Phrase("No", font));

		PdfPCell page2table2cell4 = new PdfPCell(page2table2Cell3Buttontable);
		page2table2cell4.setBorderWidthBottom(0.1f);
		page2table2cell4.setBorderColorBottom(java.awt.Color.WHITE);
		page2table2cell4.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(page2table2cell4);
	}

	/**
	 * @param page2Table2
	 * @param check1
	 * @param check2
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void displayButtonInPDFforForm2table2cell1(PdfPTable page2Table2, Image check1, Image check2)
			throws DocumentException, IOException {

		PdfPTable page2table2Cell2Buttontable = new PdfPTable(5);
		page2table2Cell2Buttontable.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		page2table2Cell2Buttontable.setWidths(new int[] { 50, 2, 10, 2, 10 });
		page2table2Cell2Buttontable.addCell(new Phrase("1. Do you have End Stage Renal Disease(ESRD)? ", font));
		page2table2Cell2Buttontable.addCell(check1);
		page2table2Cell2Buttontable.addCell(new Phrase("Yes", font));
		page2table2Cell2Buttontable.addCell(check2);
		page2table2Cell2Buttontable.addCell(new Phrase("No", font));

		PdfPCell page2table2cell2 = new PdfPCell(page2table2Cell2Buttontable);
		page2table2cell2.setBorderWidthBottom(0.1f);
		page2table2cell2.setBorderColorBottom(java.awt.Color.WHITE);
		page2table2cell2.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(page2table2cell2);
	}

	private static void displayButtonInPDFforForm2StmtsButton(PdfPTable page2Table2, Image check1, Image check2)
			throws DocumentException, IOException {

		PdfPTable page2table2Cell2Buttontable = new PdfPTable(5);
		page2table2Cell2Buttontable.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		page2table2Cell2Buttontable.setWidths(new int[] { 30, 2, 15, 2, 15 });
		page2table2Cell2Buttontable.addCell(new Phrase("Account Type: ", font));
		page2table2Cell2Buttontable.addCell(check1);
		page2table2Cell2Buttontable.addCell(new Phrase("Checking", font));
		page2table2Cell2Buttontable.addCell(check2);
		page2table2Cell2Buttontable.addCell(new Phrase("Savings", font));

		PdfPCell page2table2cell2 = new PdfPCell(page2table2Cell2Buttontable);
		page2table2cell2.setBorderWidthBottom(0.1f);
		page2table2cell2.setBorderColorBottom(java.awt.Color.WHITE);
		page2table2cell2.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(page2table2cell2);
	}

	/**
	 * @param page4Table4
	 * @param check1
	 * @param todayDateValue
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void displayCheckBoxInPDFforForm3table(PdfPTable page3Table4, Image check1, String todayDateValue,
			String signatureVal) throws DocumentException, IOException {

		PdfPTable page3Table4Cell1table1 = new PdfPTable(3);
		page3Table4Cell1table1.setWidthPercentage(100);
		page3Table4Cell1table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page3Table4Cell1table1.setWidths(new int[] { 5, 100, 100 });
		page3Table4Cell1table1.addCell(" ");
		page3Table4Cell1table1.addCell(new Phrase(signatureVal, font));

		page3Table4Cell1table1.addCell(new Phrase("Today's Date : " + (getChangedValue(todayDateValue)), font));

		PdfPCell page3table4cell1 = new PdfPCell(page3Table4Cell1table1);
		page3table4cell1.setBorderWidthBottom(0.1f);
		page3Table4.addCell(page3table4cell1);

	}

	/**
	 * @param page3Table2
	 * @param check1
	 * @param check2
	 * @param check3
	 * @param checkBoxFlagfortable2Firstcell
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	/*
	 * private static void displayCheckBoxInPDFforForm3table2( PdfPTable
	 * page3Table2, Image check1, Image check2, Image check3, Image check4,
	 * Image check5, String checkBoxFlagfortable2Firstcell) throws
	 * DocumentException, IOException {
	 * 
	 * PdfPTable page3Cell2TableEmail = new PdfPTable(3);
	 * page3Cell2TableEmail.setWidthPercentage(100);
	 * page3Cell2TableEmail.setWidths(new int[] { 4, 150, 50 });
	 * page3Cell2TableEmail.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	 * page3Cell2TableEmail.addCell(check1); page3Cell2TableEmail .addCell(new
	 * Phrase(
	 * "I give optima health permission to send my plan materials and member communications by email to (Email Address):"
	 * , font)); page3Cell2TableEmail.addCell(new Phrase(
	 * (getChangedValue(checkBoxFlagfortable2Firstcell)), font));
	 * 
	 * PdfPTable page3Cell2Table2 = new PdfPTable(2);
	 * page3Cell2Table2.setWidthPercentage(100);
	 * page3Cell2Table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	 * page3Cell2Table2.setWidths(new int[] { 2, 100 });
	 * page3Cell2Table2.addCell(check2); page3Cell2Table2.addCell(new Phrase(
	 * "Mail my plan material and member communications", font));
	 * 
	 * PdfPTable page3Cell2Table3 = new PdfPTable(2);
	 * page3Cell2Table3.setWidthPercentage(100);
	 * page3Cell2Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	 * page3Cell2Table3.setWidths(new int[] { 2, 100 });
	 * page3Cell2Table3.addCell(check3); page3Cell2Table3 .addCell(new Phrase(
	 * "Mail my plan material and member communications in large print", font));
	 * 
	 * PdfPTable page3Cell2Table4 = new PdfPTable(2);
	 * page3Cell2Table4.setWidthPercentage(100);
	 * page3Cell2Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	 * page3Cell2Table4.setWidths(new int[] { 2, 100 });
	 * page3Cell2Table4.addCell(check4); page3Cell2Table4.addCell(new Phrase(
	 * "Mail my plan material and member communications in Braille", font));
	 * 
	 * PdfPTable page3Cell2Table5 = new PdfPTable(2);
	 * page3Cell2Table5.setWidthPercentage(100);
	 * page3Cell2Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	 * page3Cell2Table5.setWidths(new int[] { 2, 100 });
	 * page3Cell2Table5.addCell(check5); page3Cell2Table5 .addCell(new Phrase(
	 * "Mail my plan material and member communications in Audio tape", font));
	 * 
	 * PdfPCell page3table2cell2 = new PdfPCell(page3Cell2Table2);
	 * page3table2cell2.setBorderWidthBottom(0.1f);
	 * page3table2cell2.setBorderColorTop(java.awt.Color.WHITE);
	 * 
	 * page3Table2.addCell(page3Cell2TableEmail);
	 * page3Table2.addCell(page3Cell2Table2);
	 * page3Table2.addCell(page3Cell2Table3);
	 * page3Table2.addCell(page3Cell2Table4);
	 * page3Table2.addCell(page3Cell2Table5); }
	 */
	/**
	 * @param page3Table1
	 * @param phrase1
	 * @param phrase2
	 * @param check2
	 * @param check3
	 * @param page3Cell2Table1firstcheck
	 * @param page3Cell2Table1secondcheck
	 * @param page3Cell2Table1
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void displayCheckBoxInPDFforForm4(PdfPTable page4Table1, String phrase1, String phrase2,
			Image check2, Image check3, PdfPTable page4Cell2Table1firstcheck, PdfPTable page4Cell2Table1secondcheck,
			PdfPTable page4Cell2Table1) throws DocumentException, IOException {

		PdfPTable table = page4Table1;
		PdfPTable FirstcheckTable = page4Cell2Table1firstcheck;
		PdfPTable SecondcheckTable = page4Cell2Table1secondcheck;
		PdfPTable mainTable = page4Cell2Table1;

		FirstcheckTable.setWidthPercentage(100);
		FirstcheckTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		FirstcheckTable.setWidths(new int[] { 6, 100 });
		FirstcheckTable.addCell(check2);
		FirstcheckTable.addCell(new Phrase(phrase1, font));

		SecondcheckTable.setWidthPercentage(100);
		SecondcheckTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		SecondcheckTable.setWidths(new int[] { 5, 100 });
		SecondcheckTable.addCell(check3);
		SecondcheckTable.addCell(new Phrase(phrase2, font));

		mainTable.setWidthPercentage(100);
		mainTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		mainTable.setWidths(new int[] { 60, 80 });
		mainTable.addCell(FirstcheckTable);
		mainTable.addCell(SecondcheckTable);

		PdfPCell page4table1cell2 = new PdfPCell(mainTable);
		page4table1cell2.setBorderWidthBottom(0.1f);
		page4table1cell2.setBorderColorBottom(java.awt.Color.WHITE);
		page4table1cell2.setBorderColorTop(java.awt.Color.WHITE);
		table.addCell(page4table1cell2);
	}

	/**
	 * @param fieldValue
	 * @return
	 */
	private static String getChangedValue(String fieldValue) {
		return fieldValue != null ? fieldValue : "";
	}

}
