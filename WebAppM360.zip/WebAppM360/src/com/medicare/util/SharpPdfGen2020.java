package com.medicare.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.html.WebColors;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.ColumnText;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;
import com.medicare.vo.AgreeDetailsVO;
import com.medicare.vo.AttestationDetailsVO;
import com.medicare.vo.EnrollmentVO;
import com.medicare.vo.PolicyDetailsVO;
import com.medicare.vo.UserDetailsVO;
//import com.lowagie.text.BaseColor;


/**
 * @author SH250285
 * 
 */

public class SharpPdfGen2020 {

	private final static Logger LOGGER = Logger.getLogger(SharpPdfGen2020.class
			.getName());
	private static Image Medicardlogo_Logo;
	private static com.lowagie.text.Image sharpLogo;
	private static Image sampleCheck;
	private static Image check;
	static java.awt.Color headerColor = WebColors.getRGBColor("#344C66");

	private static Image uncheck;
	private static Image buttonCheckImage;
	private static Image buttonUncheckImage;

	private static Image tick;
	private static Image stop;

	private static BaseFont base;
	private static Font font;
	private static Font chineseFont;
	private static Font hindiFont;
	private static Font font2;
	static Properties prop = null;

	static Font headerFont = null;

	/**
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	public static void showEnrollFromsInPDF(HttpServletRequest request,
			HttpServletResponse response) {
		prop = new Properties();

		try {
			prop.load(new InputStreamReader(SharpPdfGen2020.class.getClassLoader()
					.getResourceAsStream("sharp.properties"), Charset
					.forName("UTF-8")));
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			UserDetailsVO pdfUserDetails = (UserDetailsVO) request.getSession()
					.getAttribute("userDetailsVO");
			AgreeDetailsVO pdfAgreeDetails = (AgreeDetailsVO) request
					.getSession().getAttribute("agreeDetailsVO");

			baos = savePdf(request, response);
			printpdf(baos, response, pdfUserDetails, pdfAgreeDetails);
		} catch (Exception e) {
			LOGGER.error("Exception in : PDFUtill class and showEnrollFromsInPDF method");
			return;
		}
	}

	/**
	 * @param baos
	 * @param response
	 * @param pdfUserDetails
	 * @param pdfAgreeDetails
	 * @throws IOException
	 */
	private static void printpdf(ByteArrayOutputStream baos,
			HttpServletResponse response, UserDetailsVO pdfUserDetails,
			AgreeDetailsVO pdfAgreeDetails) throws IOException {
		String pdffileFileName = (getChangedValue(pdfUserDetails.getLastName()))
				+ "_" + pdfAgreeDetails.getTodayDate();
		response.addHeader("Content-Disposition", "attachment;filename="
				+ pdffileFileName + "enrolled.pdf");
		
	    OutputStream os = response.getOutputStream();
		baos.writeTo(os);
		os.flush();
		os.close();
	}

	/**
	 * @param request
	 * @param response
	 * @return
	 */
	private static ByteArrayOutputStream savePdf(HttpServletRequest request,
			HttpServletResponse response) {

		LOGGER.info(" Start : In savePdf () method of SharpPdfGen2020 class");
		
		prop = new Properties();
		ByteArrayOutputStream baos = null;
		ByteArrayOutputStream bao2 = null;
				

		try {
			prop.load(new InputStreamReader(SharpPdfGen2020.class.getClassLoader().getResourceAsStream("sharp.properties"), Charset.forName("UTF-8")));
			baos = new ByteArrayOutputStream();
			bao2 = new ByteArrayOutputStream();
		}catch(Exception e) {
			e.printStackTrace();
		}

		UserDetailsVO pdfUserDetails = (UserDetailsVO) request.getSession().getAttribute("userDetailsVO");
		AgreeDetailsVO pdfAgreeDetails = (AgreeDetailsVO) request.getSession().getAttribute("agreeDetailsVO");		
		PolicyDetailsVO pdfPolicyDetails = (PolicyDetailsVO) request.getSession().getAttribute("policyDetails");
		AttestationDetailsVO pdfAttestationDetails = (AttestationDetailsVO) request.getSession().getAttribute("attestationDetailsVO");
		EnrollmentVO enrollmentVO = (EnrollmentVO) request.getSession().getAttribute("enrollmentVO");
		String planName = (String)request.getSession().getAttribute("planName");
		
		LOGGER.info(" Before retrieving SEQUENCE number : ");
		
		int sequenceNumber =  Integer.parseInt((String)request.getSession().getAttribute("WebAppConfirmationNumber"));
		LOGGER.info("The SEQUENCE number from WebApp request is : "+sequenceNumber);
		System.out.println("The SEQUENCE number from WebApp request is : "+sequenceNumber);
		

		Document document = new Document(PageSize.A4, 10, 10, 10, 10);
		PdfWriter writer = null;
		try {

			//Begin: 2019 web app changes - IFOX-00406768
			pdfUserDetails.setPlanYear((String) request.getSession().getAttribute("planYear"));
			pdfUserDetails.setWebappConfirmationNumber("" + sequenceNumber);
			pdfUserDetails.setNewPhysicianName(getNewPhysicianName(pdfUserDetails.getPcp(), request));
			pdfPolicyDetails.setNewPhysicianName(pdfUserDetails.getNewPhysicianName());
			
			pdfUserDetails.setNewAgentName(getNewAgentName(pdfUserDetails.getAgentName(), request));
			pdfPolicyDetails.setNewAgentName(pdfUserDetails.getNewAgentName());
			//End: 2019 web app changes - IFOX-00406768
			
			/*IFOX-00418144 2020 AEP Plan Changes. START*/
			pdfUserDetails.setPlanName(planName);
			/*IFOX-00418144 2020 AEP Plan Changes. END*/
			
			pdfImageInstances(request);

			pdffontInstances(request);

			headerColor = WebColors.getRGBColor("#344C66");
            String langPath =  request.getSession().getServletContext().getRealPath("/WEB-INF/views/Sharp/language.pdf");
            String langPath_2018 =  request.getSession().getServletContext().getRealPath("/WEB-INF/views/Sharp/language2018.pdf");
			
            String multiLanguageAndNonDiscriminationNotice = request.getSession().getServletContext().getRealPath(
            		"/WEB-INF/views/Sharp/MultiLanguageAndNonDiscriminationNotice-cropped.pdf"); //Modified for IFOX-00414491
            
            writer = PdfWriter.getInstance(document,  baos);
			document.open();
			PdfPTable form = null;
			
			LOGGER.info(" SharpPdfGen2020 : saveDetails : PlanName [" + planName + "] ");
			
			if("SAB".equalsIgnoreCase(planName) || "SAP".equalsIgnoreCase(planName)){
				form = page1LogoTableSABSAP(sharpLogo, pdfUserDetails, document);
			}else if("SDAB".equalsIgnoreCase(planName) || "SDAP".equalsIgnoreCase(planName) || "SDABWD".equalsIgnoreCase(planName) || "SDAPWD".equalsIgnoreCase(planName)
					|| "SDAB20".equalsIgnoreCase(planName) || "SDAP20".equalsIgnoreCase(planName) || "SDABWD20".equalsIgnoreCase(planName) || "SDAPWD20".equalsIgnoreCase(planName)){
				form = page1LogoTableSDABSDAP(sharpLogo, pdfUserDetails, document);
			}else if("SAS".equalsIgnoreCase(planName) || "SASP".equalsIgnoreCase(planName)){
				form = page1LogoTableSASSASP(sharpLogo, pdfUserDetails, document);
			}/*IFOX-00418144 2020 AEP Plan Changes. START*/
			else if("SDAGC".equalsIgnoreCase(planName) || "SDAPC".equalsIgnoreCase(planName) || "SDAGCWD".equalsIgnoreCase(planName) 
					|| "SDAGC20".equalsIgnoreCase(planName) || "SDAPC20".equalsIgnoreCase(planName) || "SDAGCWD20".equalsIgnoreCase(planName) ){
				form = page1LogoTableSDAGCSDAPC(sharpLogo, pdfUserDetails, document);
			}/*IFOX-00418144 2020 AEP Plan Changes. END*/
			else if("SAMEA".equalsIgnoreCase(planName) ){
				form = page1LogoTableSAMEA(sharpLogo, pdfUserDetails, document);
			}else if("SDAMEA".equalsIgnoreCase(planName) ){
				form = page1LogoTableSDAMEA(sharpLogo, pdfUserDetails, document);
			}/**IFOX-00403984 Changes Start.*/
			else if("SDAHMO".equalsIgnoreCase(planName) ){
				form = page1LogoTableSDAHMO(sharpLogo, pdfUserDetails, document);
			}/**IFOX-00403984 Changes Stop.*/
			
			//Begin: Modified for IFOX-00414491
			else if("SDAHMO1".equalsIgnoreCase(planName) ){
				form = page1LogoTableSDAHMO1(sharpLogo, pdfUserDetails, document);
			}
			//End: Modified for IFOX-00414491
			
			document.add(form);
			
			if("SAMEA".equalsIgnoreCase(planName) || "SDAMEA".equalsIgnoreCase(planName)
					|| "SDAHMO".equalsIgnoreCase(planName) || "SDAHMO1".equalsIgnoreCase(planName) ){ //Modified for IFOX-00414491
				mainHeading(document,planName);
			}else {
				mainHeading(document);
			} 			
			
			
			//Begin: Updated for IFOX-00414491
			//page1TabbleUserDetails(pdfUserDetails, document);
			/**IFOX-00403984 Changes Start.*/
			if("SAMEA".equalsIgnoreCase(planName) || "SDAMEA".equalsIgnoreCase(planName) || "SDAHMO".equalsIgnoreCase(planName) || "SDAHMO1".equalsIgnoreCase(planName) ){ //Modified for IFOX-00414491
				page1TabbleUserDetails(pdfUserDetails, enrollmentVO, document,planName);
			}/**IFOX-00403984 Changes Stop.*/
			else if("SAB".equalsIgnoreCase(planName) || "SAP".equalsIgnoreCase(planName)){
				page1TabbleUserDetails(pdfUserDetails, enrollmentVO, document,planName);
			}/*IFOX-00418144 2020 AEP Plan Changes. START*/
			else if("SDAGC".equalsIgnoreCase(planName) || "SDAPC".equalsIgnoreCase(planName) || "SDAGCWD".equalsIgnoreCase(planName) 
					|| "SDAGC20".equalsIgnoreCase(planName) || "SDAPC20".equalsIgnoreCase(planName) || "SDAGCWD20".equalsIgnoreCase(planName) ){
				page1TabbleUserDetails(pdfUserDetails, enrollmentVO, document,planName);
			}/*IFOX-00418144 2020 AEP Plan Changes. END*/
			else if("SDAB".equalsIgnoreCase(planName) || "SDAP".equalsIgnoreCase(planName) || "SDABWD".equalsIgnoreCase(planName) || "SDAPWD".equalsIgnoreCase(planName) || "SDAB20".equalsIgnoreCase(planName) || "SDAP20".equalsIgnoreCase(planName) || "SDABWD20".equalsIgnoreCase(planName) || "SDAPWD20".equalsIgnoreCase(planName)){
				page1TabbleUserDetails(pdfUserDetails, enrollmentVO, document,planName);
			}else if("SAS".equalsIgnoreCase(planName) || "SASP".equalsIgnoreCase(planName)){
				page1TabbleUserDetails(pdfUserDetails, enrollmentVO, document,planName);
			}else {
				page1TabbleUserDetails(pdfUserDetails, document);
			}
			//End: Updated for IFOX-00414491
			
			displayMaterialIdAndPageNumbers(document, writer, planName, "1", "8");
			
			document.newPage();

			//Begin: Modified for IFOX-00414491
			
			PdfPTable page2Table1 = pdfPage2Table1(pdfPolicyDetails,pdfUserDetails);
			document.add(page2Table1);
			displayMaterialIdAndPageNumbers(document, writer, planName, "2", "8"); //Modified for IFOX-00414491
			
			//End: Modified for IFOX-00414491
			
			document.newPage();

			if("SDAHMO".equalsIgnoreCase(planName) || "SDAHMO1".equalsIgnoreCase(planName) ){  //Modified for IFOX-00414491
				PdfPTable page3Table = page3Table(pdfPolicyDetails,planName,enrollmentVO);
				document.add(page3Table);
				displayMaterialIdAndPageNumbers(document, writer, planName, "3", "8");
				document.newPage();
				
				PdfPTable page4Table1 = pdfPage4Table1(pdfAttestationDetails, document, enrollmentVO,
						planName);
				document.add(page4Table1);
				displayMaterialIdAndPageNumbers(document, writer, planName, "4", "8");
				document.newPage();
				
				PdfPTable pdfPage5Table2 = pdfPage5Table2(pdfAgreeDetails,planName);
				document.add(pdfPage5Table2);
				displayMaterialIdAndPageNumbers(document, writer, planName, "5", "8");
				document.newPage();
			}else{
				PdfPTable page3Table = page3Table(pdfPolicyDetails);
				document.add(page3Table);
				displayMaterialIdAndPageNumbers(document, writer, planName, "3", "8");
				document.newPage();
				
				PdfPTable page4Table1 = pdfPage4Table1(pdfAttestationDetails, document, enrollmentVO);
				document.add(page4Table1);
				displayMaterialIdAndPageNumbers(document, writer, planName, "4", "8");
				document.newPage();
				
				PdfPTable pdfPage5Table2 = pdfPage5Table2(pdfAgreeDetails);
				document.add(pdfPage5Table2);
				displayMaterialIdAndPageNumbers(document, writer, planName, "5", "8");
				document.newPage();
			}
			//addSequenceNumber(document, sequenceNumber);			

			/*
			document.add(new Paragraph("NON-DISCRIMINATION NOTICE", font));

			if("SDAHMO".equalsIgnoreCase(planName)){
				pdfPage6Table(document, "page6_para_new", 6);
			}else{
				pdfPage6Table(document, "page6_para", 6);
			}
			document.newPage();
			*/
			
			document.close();
			List<InputStream> list = new ArrayList<InputStream>();
			
			list.add(new ByteArrayInputStream(baos.toByteArray()));
			list.add(new FileInputStream(new File(multiLanguageAndNonDiscriminationNotice)));
			/*
			if("SDAHMO".equalsIgnoreCase(planName)){
				list.add(new FileInputStream(new File(langPath_2018)));
			}else{
				list.add(new FileInputStream(new File(langPath)));
			}
			*/
	        byte[] concatPDFs = mergePDFs(list, bao2);
	        baos.write(concatPDFs);
	        return  baos;

		} catch (Exception exp) {
			exp.printStackTrace();
			LOGGER.error(" SharpPdfGen2020 : savePdf : " + exp.getMessage());
			exp.printStackTrace();
			return null;

		} finally {
			if (document != null) {
				document.close();
			}
			if (writer != null) {
				writer.close();
			}
		}

	}

	@SuppressWarnings("unused")
	private static PdfPTable page1LogoTableSASSASP(Image sharpLogo2,
			UserDetailsVO pdfUserDetails, Document document) {
		
		System.out.println("*********************page1LogoTableSASSASP***************************");
		PdfPTable table = null;
		try {
			PdfPTable OuterTable = new PdfPTable(1);
			OuterTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			PdfPTable form1 = null;

			table = new PdfPTable(2); // 3 columns.
			table.setWidthPercentage(100.0f);
			float[] columnWidths = { 1.8f, 2.2f };
			table.setWidths(columnWidths);

			PdfPCell cell1 = new PdfPCell();
			PdfPTable logoTable = new PdfPTable(1);

			PdfPTable logo = page1LogoTable(sharpLogo);
			cell1.addElement(logoTable);
			cell1.setRowspan(4);
			cell1.setBorder(Rectangle.NO_BORDER);
			cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			logo.addCell(new Phrase(
					" 2017 Sharp Advantage� \n Individual Enrollment Form"));
			table.addCell(logo);

			/*
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1 = setLogoData(
					"Name of staff member/agent/broker (if assisted in enrollment):",
					getChangedValue(pdfUserDetails.getAgentName()));
			OuterTable.addCell(form1);
			*/
			
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("Name of staff member/agent/broker ", font));
			form1.addCell(new Phrase("", font));
			OuterTable.addCell(form1);
			
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("(if assisted in enrollment) #:", font));
			form1.addCell(new Phrase(getChangedValue(pdfUserDetails.getNewAgentName()), font));
			OuterTable.addCell(form1);

			/*
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			
			form1 = setLogoDataNew("CA License #:",
					getChangedValue(pdfUserDetails.getCaLicence()));
			OuterTable.addCell(form1);
			*/
			form1 = new PdfPTable(4);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("CA License #:", font));
			form1.addCell(new Phrase("", font));
			form1.addCell(new Phrase(getChangedValue(pdfUserDetails.getCaLicence()), font));
			form1.addCell(new Phrase("", font));
			OuterTable.addCell(form1);

			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1 = setLogoData(
					"Plan ID #:"
							+ getChangedValue(pdfUserDetails
									.getOptimaMedicare()),
					"Effective Date of Coverage: "
							+ getChangedValue(pdfUserDetails.getEffDate()));
			OuterTable.addCell(form1);
			form1 = setElectionType(getChangedValue(pdfUserDetails.getElectionType()));
			OuterTable.addCell(form1);

			form1 = setLogoData("PCP #:",
					getChangedValue(pdfUserDetails.getPcp()));
			OuterTable.addCell(form1);
			table.addCell(OuterTable);
			return table;

		} catch (DocumentException exp) {
			//e.printStackTrace();
			LOGGER.error(" SharpPdfGen2020 : page1LogoTable : " + exp.getMessage());

		}
		return table;
	}


	@SuppressWarnings("unused")
	private static PdfPTable page1LogoTableSDAGCSDAPC(Image sharpLogo2,
			UserDetailsVO pdfUserDetails, Document document) {
		
		System.out.println("*********************page1LogoTableSDAGCSDAPC***************************");
		PdfPTable table = null;
		try {
			PdfPTable OuterTable = new PdfPTable(1);
			OuterTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			PdfPTable form1 = null;

			table = new PdfPTable(2); // 3 columns.
			table.setWidthPercentage(100.0f);
			float[] columnWidths = { 1.8f, 2.2f };
			table.setWidths(columnWidths);

			PdfPCell cell1 = new PdfPCell();
			PdfPTable logoTable = new PdfPTable(1);

			PdfPTable logo = page1LogoTable(sharpLogo);
			cell1.addElement(logoTable);
			cell1.setRowspan(4);
			cell1.setBorder(Rectangle.NO_BORDER);
			cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			/*IFOX-00418144 2020 AEP Plan Changes. START*/
			String planName = pdfUserDetails.getPlanName();
			if("SDAGC20".equalsIgnoreCase(planName) || "SDAGCWD20".equalsIgnoreCase(planName) || "SDAPC20".equalsIgnoreCase(planName))
				logo.addCell(new Phrase(
						" 2020 Sharp Direct Advantage Plan� \n Individual Enrollment Form"));
			else/*IFOX-00418144 2020 AEP Plan Changes. END*/
				logo.addCell(new Phrase(
					" 2019 Sharp Direct Advantage Plan� \n Individual Enrollment Form"));
			table.addCell(logo);

			LOGGER.info(" SharpPdfGen2020 : page1LogoTableSDAGCSDAPC : Plan Year [" + pdfUserDetails.getPlanYear() + "] ");

			/*
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1 = setLogoData("Name of staff member/agent/broker (if assisted in enrollment) : ", getChangedValue(pdfUserDetails.getAgentName()) );
			OuterTable.addCell(form1);
			*/
			
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("Name of staff member/agent/broker ", font));
			form1.addCell(new Phrase("", font));
			OuterTable.addCell(form1);
			
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("(if assisted in enrollment) #:", font));
			form1.addCell(new Phrase(getChangedValue(pdfUserDetails.getNewAgentName()), font));
			OuterTable.addCell(form1);
			

			form1 = new PdfPTable(4);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("CA License #:", font));
			form1.addCell(new Phrase("", font));
			form1.addCell(new Phrase(getChangedValue(pdfUserDetails.getCaLicence()), font));
			form1.addCell(new Phrase("", font));
			OuterTable.addCell(form1);

			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			
			form1 = setLogoDataNew(
						"Plan ID #:", getChangedValue(pdfUserDetails.getOptimaMedicare()));
			OuterTable.addCell(form1);
			

			form1 = setLogoDataNew("PCP #:",
					getChangedValue(pdfUserDetails.getNewPhysicianName()));
			OuterTable.addCell(form1);
			
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1 = setLogoDataNew(
					"Application Confirmation Number #:", pdfUserDetails.getWebappConfirmationNumber());

			OuterTable.addCell(form1);
			table.addCell(OuterTable);
			return table;

		} catch (DocumentException exp) {
			exp.printStackTrace();
			LOGGER.error(" SharpPdfGen2020 : page1LogoTable : " + exp.getMessage());

		}
		return table;
	}

	@SuppressWarnings("unused")
	private static PdfPTable page1LogoTableSABSAP(Image sharpLogo2, 
			UserDetailsVO pdfUserDetails, Document document) {
		
		System.out.println("*********************page1LogoTableSABSAP***************************");
		
		PdfPTable table = null;
		try {
			PdfPTable OuterTable = new PdfPTable(1);
			OuterTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			PdfPTable form1 = null;

			table = new PdfPTable(2); // 3 columns.
			table.setWidthPercentage(100.0f);
			float[] columnWidths = { 1.8f, 2.2f };
			table.setWidths(columnWidths);

			PdfPCell cell1 = new PdfPCell();
			PdfPTable logoTable = new PdfPTable(1);

			PdfPTable logo = page1LogoTable(sharpLogo);
			cell1.addElement(logoTable);
			cell1.setRowspan(4);
			cell1.setBorder(Rectangle.NO_BORDER);
			cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			logo.addCell(new Phrase(
					" 2017 Sharp Advantage� \n Group Enrollment Form"));
			table.addCell(logo);

			/*
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1 = setLogoData(
					"Name of staff member/agent/broker (if assisted in enrollment):",
					getChangedValue(pdfUserDetails.getAgentName()));
			OuterTable.addCell(form1);
			*/
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("Name of staff member/agent/broker ", font));
			form1.addCell(new Phrase("", font));
			OuterTable.addCell(form1);
			
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("(if assisted in enrollment) #:", font));
			form1.addCell(new Phrase(getChangedValue(pdfUserDetails.getNewAgentName()), font));
			OuterTable.addCell(form1);

			/*
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1 = setLogoDataNew("CA License #:",
					getChangedValue(pdfUserDetails.getCaLicence()));
			OuterTable.addCell(form1);
			*/
			form1 = new PdfPTable(4);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("CA License #:", font));
			form1.addCell(new Phrase("", font));
			form1.addCell(new Phrase(getChangedValue(pdfUserDetails.getCaLicence()), font));
			form1.addCell(new Phrase("", font));
			OuterTable.addCell(form1);

			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1 = setLogoData(
					"Plan ID #:"
							+ getChangedValue(pdfUserDetails.getOptimaMedicare()),
					"Effective Date of Coverage: "
							+ getChangedValue(pdfUserDetails.getEffDate()));
			OuterTable.addCell(form1);
			form1 = setElectionType(getChangedValue(pdfUserDetails.getElectionType()));
			OuterTable.addCell(form1);

			form1 = setLogoData("PCP #:",
					getChangedValue(pdfUserDetails.getPcp()));
			OuterTable.addCell(form1);
			table.addCell(OuterTable);
			return table;

		} catch (DocumentException exp) {
			//e.printStackTrace();
			LOGGER.error(" SharpPdfGen2020 : page1LogoTableSAB : " + exp.getMessage());

		}
		return table;
	}
	
	@SuppressWarnings("unused")
	private static PdfPTable page1LogoTableSDABSDAP(Image sharpLogo2, 
			UserDetailsVO pdfUserDetails, Document document) {
		System.out.println("*********************page1LogoTableSDABSDAP***************************");
		PdfPTable table = null;
		try {
			PdfPTable OuterTable = new PdfPTable(1);
			OuterTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			PdfPTable form1 = null;

			table = new PdfPTable(2); // 3 columns.
			table.setWidthPercentage(100.0f);
			float[] columnWidths = { 1.8f, 2.2f };
			table.setWidths(columnWidths);

			PdfPCell cell1 = new PdfPCell();
			PdfPTable logoTable = new PdfPTable(1);

			PdfPTable logo = page1LogoTable(sharpLogo);
			cell1.addElement(logoTable);
			cell1.setRowspan(4);
			cell1.setBorder(Rectangle.NO_BORDER);
			cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			//Fix for IFOX-00420776 - Start
			String planName = pdfUserDetails.getPlanName();
			if("SDAB20".equalsIgnoreCase(planName) || "SDABWD20".equalsIgnoreCase(planName) || "SDAP20".equalsIgnoreCase(planName) || "SDAPWD20".equalsIgnoreCase(planName))
				logo.addCell(new Phrase(" 2020 Sharp Direct Advantage Plan�\n Group Enrollment Form"));
			else
				logo.addCell(new Phrase(" 2019 Sharp Direct Advantage Plan�\n Group Enrollment Form"));
			//Fix for IFOX-00420776 - End
			
			table.addCell(logo);

			/*
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1 = setLogoData("Name of staff member/agent/broker (if assisted in enrollment) : ", getChangedValue(pdfUserDetails.getAgentName()) );
			OuterTable.addCell(form1);
			*/
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("Name of staff member/agent/broker ", font));
			form1.addCell(new Phrase("", font));
			OuterTable.addCell(form1);
			
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("(if assisted in enrollment) #:", font));
			form1.addCell(new Phrase(getChangedValue(pdfUserDetails.getNewAgentName()), font));
			OuterTable.addCell(form1);

			form1 = new PdfPTable(4);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("CA License #:", font));
			form1.addCell(new Phrase("", font));
			form1.addCell(new Phrase(getChangedValue(pdfUserDetails.getCaLicence()), font));
			form1.addCell(new Phrase("", font));
			OuterTable.addCell(form1);

			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			
			form1 = setLogoDataNew("Plan ID #:", getChangedValue(pdfUserDetails.getOptimaMedicare()));
			OuterTable.addCell(form1);
			
			form1 = setLogoDataNew("PCP #:", getChangedValue(pdfUserDetails.getNewPhysicianName()));
			OuterTable.addCell(form1);
			
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1 = setLogoDataNew(
					"Application Confirmation Number #:", pdfUserDetails.getWebappConfirmationNumber());

			OuterTable.addCell(form1);
			table.addCell(OuterTable);
			return table;

		} catch (DocumentException exp) {
			exp.printStackTrace();
			LOGGER.error(" SharpPdfGen2020 : page1LogoTableSAB : " + exp.getMessage());

		}
		return table;
	}
	
	@SuppressWarnings("unused")
	private static PdfPTable page1LogoTableSDAMEA(Image sharpLogo2, 
			UserDetailsVO pdfUserDetails, Document document) {
		
		System.out.println("*********************page1LogoTableSDAMEA***************************");
		PdfPTable table = null;
		try {
			PdfPTable OuterTable = new PdfPTable(1);
			OuterTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			PdfPTable form1 = null;

			table = new PdfPTable(2); // 3 columns.
			table.setWidthPercentage(100.0f);
			float[] columnWidths = { 1.8f, 2.2f };
			table.setWidths(columnWidths);

			PdfPCell cell1 = new PdfPCell();
			PdfPTable logoTable = new PdfPTable(1);

			PdfPTable logo = page1LogoTable(sharpLogo);
			cell1.addElement(logoTable);
			cell1.setRowspan(4);
			cell1.setBorder(Rectangle.NO_BORDER);
			cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			logo.addCell(new Phrase(
					" 2019 Sharp Direct Advantage Plan�\n SDPEBA Enrollment Form"));
			table.addCell(logo);

			/*
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1 = setLogoData(
					"Name of staff member/agent/broker (if assisted in enrollment):",
					getChangedValue(pdfUserDetails.getAgentName()));
			OuterTable.addCell(form1);
			*/
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("Name of staff member/agent/broker ", font));
			form1.addCell(new Phrase("", font));
			OuterTable.addCell(form1);
			
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("(if assisted in enrollment) #:", font));
			form1.addCell(new Phrase(getChangedValue(pdfUserDetails.getNewAgentName()), font));
			OuterTable.addCell(form1);

			/*
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1 = setLogoDataNew("CA License #:",
					getChangedValue(pdfUserDetails.getCaLicence()));
			OuterTable.addCell(form1);
			*/
			form1 = new PdfPTable(4);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("CA License #:", font));
			form1.addCell(new Phrase("", font));
			form1.addCell(new Phrase(getChangedValue(pdfUserDetails.getCaLicence()), font));
			form1.addCell(new Phrase("", font));
			OuterTable.addCell(form1);

			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1 = setLogoData(
					"Plan ID #:"
							+ getChangedValue(pdfUserDetails
									.getOptimaMedicare()),
					"Effective Date of Coverage: "
							+ getChangedValue(pdfUserDetails.getEffDate()));
			OuterTable.addCell(form1);
			form1 = setElectionType(getChangedValue(pdfUserDetails.getElectionType()));
			OuterTable.addCell(form1);

			form1 = setLogoData("PCP #:",
					getChangedValue(pdfUserDetails.getPcp()));
			OuterTable.addCell(form1);
			table.addCell(OuterTable);
			return table;

		} catch (DocumentException exp) {
			//e.printStackTrace();
			LOGGER.error(" SharpPdfGen2020 : page1LogoTableSAB : " + exp.getMessage());

		}
		return table;
	}
	/**IFOX-00403984 Changes Start.*/
	/**
	 * @param sharpLogo2
	 * @param pdfUserDetails
	 * @param document
	 * @return
	 */
	@SuppressWarnings("unused")
	private static PdfPTable page1LogoTableSDAHMO(Image sharpLogo2, 
			UserDetailsVO pdfUserDetails, Document document) {
		
		System.out.println("*********************page1LogoTableSDAHMO***************************");
		PdfPTable table = null;
		try {
			PdfPTable OuterTable = new PdfPTable(1);
			OuterTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			PdfPTable form1 = null;

			table = new PdfPTable(2); // 3 columns.
			table.setWidthPercentage(100.0f);
			float[] columnWidths = { 1.8f, 2.2f };
			table.setWidths(columnWidths);

			PdfPCell cell1 = new PdfPCell();
			PdfPTable logoTable = new PdfPTable(1);

			PdfPTable logo = page1LogoTable(sharpLogo);
			cell1.addElement(logoTable);
			cell1.setRowspan(4);
			cell1.setBorder(Rectangle.NO_BORDER);
			cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			logo.addCell(new Phrase(
					"2018-2019 Sharp Direct Advantage Plan�\n SDPEBA Enrollment Form"));
			table.addCell(logo);

			/*
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1 = setLogoData("Name of staff member/agent/broker (if assisted in enrollment) : ", getChangedValue(pdfUserDetails.getAgentName()) );
			OuterTable.addCell(form1);
			*/
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("Name of staff member/agent/broker ", font));
			form1.addCell(new Phrase("", font));
			OuterTable.addCell(form1);
			
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("(if assisted in enrollment) #:", font));
			form1.addCell(new Phrase(getChangedValue(pdfUserDetails.getNewAgentName()), font));
			OuterTable.addCell(form1);

			form1 = new PdfPTable(4);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("CA License #:", font));
			form1.addCell(new Phrase("", font));
			form1.addCell(new Phrase(getChangedValue(pdfUserDetails.getCaLicence()), font));
			form1.addCell(new Phrase("", font));
			OuterTable.addCell(form1);

			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			
			form1 = setLogoDataNew(
						"Plan ID #:", getChangedValue(pdfUserDetails.getOptimaMedicare()));
			OuterTable.addCell(form1);
			

			form1 = setLogoDataNew("PCP #:",
					getChangedValue(pdfUserDetails.getNewPhysicianName()));
			OuterTable.addCell(form1);
			
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1 = setLogoDataNew(
					"Application Confirmation Number #:", pdfUserDetails.getWebappConfirmationNumber());

			OuterTable.addCell(form1);
			table.addCell(OuterTable);
			return table;

		} catch (DocumentException exp) {
			exp.printStackTrace();
			LOGGER.error(" SharpPdfGen2020 : page1LogoTableSAB : " + exp.getMessage());

		}
		return table;
	}
	/**IFOX-00403984 Changes Stop.*/
	
	
	//Begin: Modified for IFOX-00414491
	/**
	 * @param sharpLogo2
	 * @param pdfUserDetails
	 * @param document
	 * @return
	 */
	@SuppressWarnings("unused")
	private static PdfPTable page1LogoTableSDAHMO1(Image sharpLogo2, 
			UserDetailsVO pdfUserDetails, Document document) {
		
		System.out.println("*********************page1LogoTableSDAHMO1***************************");
		PdfPTable table = null;
		try {
			PdfPTable OuterTable = new PdfPTable(1);
			OuterTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			PdfPTable form1 = null;

			table = new PdfPTable(2); // 3 columns.
			table.setWidthPercentage(100.0f);
			float[] columnWidths = { 1.8f, 2.2f };
			table.setWidths(columnWidths);

			PdfPCell cell1 = new PdfPCell();
			PdfPTable logoTable = new PdfPTable(1);

			PdfPTable logo = page1LogoTable(sharpLogo);
			cell1.addElement(logoTable);
			cell1.setRowspan(4);
			cell1.setBorder(Rectangle.NO_BORDER);
			cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			logo.addCell(new Phrase(
					"2019-2020 Sharp Direct Advantage Plan�\n SDPEBA Enrollment Form"));
			table.addCell(logo);

			/*
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1 = setLogoData("Name of staff member/agent/broker (if assisted in enrollment) : ", getChangedValue(pdfUserDetails.getAgentName()) );
			OuterTable.addCell(form1);
			*/
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("Name of staff member/agent/broker ", font));
			form1.addCell(new Phrase("", font));
			OuterTable.addCell(form1);
			
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("(if assisted in enrollment) #:", font));
			form1.addCell(new Phrase(getChangedValue(pdfUserDetails.getNewAgentName()), font));
			OuterTable.addCell(form1);

			form1 = new PdfPTable(4);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("CA License #:", font));
			form1.addCell(new Phrase("", font));
			form1.addCell(new Phrase(getChangedValue(pdfUserDetails.getCaLicence()), font));
			form1.addCell(new Phrase("", font));
			OuterTable.addCell(form1);

			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			
			form1 = setLogoDataNew(
						"Plan ID #:", getChangedValue(pdfUserDetails.getOptimaMedicare()));
			OuterTable.addCell(form1);
			

			form1 = setLogoDataNew("PCP #:",
					getChangedValue(pdfUserDetails.getNewPhysicianName()));
			OuterTable.addCell(form1);
			
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1 = setLogoDataNew(
					"Application Confirmation Number #:", pdfUserDetails.getWebappConfirmationNumber());

			OuterTable.addCell(form1);
			table.addCell(OuterTable);
			return table;

		} catch (DocumentException exp) {
			exp.printStackTrace();
			LOGGER.error(" SharpPdfGen2020 : page1LogoTableSDAHMO1 : " + exp.getMessage());

		}
		return table;
	}
	//End: Modified for IFOX-00414491
	
	
	@SuppressWarnings("unused")
	private static PdfPTable page1LogoTableSAMEA(Image sharpLogo2, 
			UserDetailsVO pdfUserDetails, Document document) {
		System.out.println("*********************page1LogoTableSAMEA***************************");
		PdfPTable table = null;
		try {
			PdfPTable OuterTable = new PdfPTable(1);
			OuterTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			PdfPTable form1 = null;

			table = new PdfPTable(2); // 3 columns.
			table.setWidthPercentage(100.0f);
			float[] columnWidths = { 1.8f, 2.2f };
			table.setWidths(columnWidths);

			PdfPCell cell1 = new PdfPCell();
			PdfPTable logoTable = new PdfPTable(1);

			PdfPTable logo = page1LogoTable(sharpLogo);
			cell1.addElement(logoTable);
			cell1.setRowspan(4);
			cell1.setBorder(Rectangle.NO_BORDER);
			cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			logo.addCell(new Phrase(
					" 2017 Sharp Advantage�\n SDPEBA Enrollment Form"));
			table.addCell(logo);

			/*
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1 = setLogoData(
					"Name of staff member/agent/broker (if assisted in enrollment):",
					getChangedValue(pdfUserDetails.getAgentName()));
			OuterTable.addCell(form1);
			*/
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("Name of staff member/agent/broker ", font));
			form1.addCell(new Phrase("", font));
			OuterTable.addCell(form1);
			
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("(if assisted in enrollment) #:", font));
			form1.addCell(new Phrase(getChangedValue(pdfUserDetails.getNewAgentName()), font));
			OuterTable.addCell(form1);

			/*
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1 = setLogoDataNew("CA License #:",
					getChangedValue(pdfUserDetails.getCaLicence()));
			OuterTable.addCell(form1);
			*/
			form1 = new PdfPTable(4);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("CA License #:", font));
			form1.addCell(new Phrase("", font));
			form1.addCell(new Phrase(getChangedValue(pdfUserDetails.getCaLicence()), font));
			form1.addCell(new Phrase("", font));
			OuterTable.addCell(form1);

			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1 = setLogoData(
					"Plan ID #:"
							+ getChangedValue(pdfUserDetails
									.getOptimaMedicare()),
					"Effective Date of Coverage: "
							+ getChangedValue(pdfUserDetails.getEffDate()));
			OuterTable.addCell(form1);
			form1 = setElectionType(getChangedValue(pdfUserDetails.getElectionType()));
			OuterTable.addCell(form1);

			form1 = setLogoData("PCP #:",
					getChangedValue(pdfUserDetails.getPcp()));
			OuterTable.addCell(form1);
			table.addCell(OuterTable);
			return table;

		} catch (DocumentException exp) {
			//e.printStackTrace();
			LOGGER.error(" SharpPdfGen2020 : page1LogoTableSAB : " + exp.getMessage());

		}
		return table;
	}
	
	private static PdfPTable setElectionType(String electType) {
		PdfPTable form1 = new PdfPTable(8);
		form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		form1.addCell(new Phrase("ICEP/IEP: ", font));
		if ("I".equalsIgnoreCase(electType)) {
			form1.addCell("X");
		} else {
			form1.addCell("");

		}
		form1.addCell(new Phrase("AEP:", font));
		if ("A".equalsIgnoreCase(electType)) {
			form1.addCell("X");
		} else {
			form1.addCell("");

		}

		form1.addCell(new Phrase("SEP (type): ", font));
		if ("S".equalsIgnoreCase(electType)) {
			form1.addCell("X");
		} else {
			form1.addCell("");

		}

		form1.addCell(new Phrase("Not Eligible:", font));
		if ("N".equalsIgnoreCase(electType)) {
			form1.addCell("X");
		} else {
			form1.addCell("");

		}

		return form1;
	}

	private static void pdfPage6Table(Document document, String pageNo,
			int totalParagraph) {

		try {
			String propertName = "";
			Paragraph paragraph = null;
			PdfPTable page2Table1 = new PdfPTable(1);
			page2Table1.setWidthPercentage(100);
			page2Table1.setSpacingBefore(10);
			page2Table1.getDefaultCell().setBorder(0);
			page2Table1.getDefaultCell().setBorder(PdfPCell.NO_BORDER);

			for (int i = 1; i <= totalParagraph; i++) {
				propertName = pageNo + i;
				paragraph = new Paragraph(prop.getProperty(propertName)
						.replaceAll("<b>", "").replaceAll("</b>", ""),  font);
				paragraph.setSpacingAfter(50);
				paragraph.setAlignment(Element.ALIGN_JUSTIFIED);
				PdfPCell page2table1cell2 = new PdfPCell(paragraph);
				page2Table1.setSpacingBefore(10f);
				page2table1cell2.setPadding(5);
				page2table1cell2.setLeading(0f, 1.5f);
				page2table1cell2
						.setHorizontalAlignment(PdfPCell.ALIGN_JUSTIFIED);
				page2table1cell2.setBorder(Rectangle.NO_BORDER);
				page2Table1.addCell(page2table1cell2);

			}

			PdfPTable outer = new PdfPTable(1);
			outer.addCell(page2Table1);
			outer.setWidthPercentage(100);
			document.add(outer);
		} catch (DocumentException exp) {
			//e.printStackTrace();
			LOGGER.error(" SharpPdfGen2020 : pdfPage6Table : " + exp.getMessage());
		}
	}

	private static PdfPTable pdfPage5Table2(AgreeDetailsVO pdfAgreeDetails) {

		PdfPTable form5 = new PdfPTable(1);
		form5.setWidthPercentage(100);
		form5.setSpacingBefore(10);
		form5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		setHeader(form5, "Please Read and sign Below");
		PdfPCell page2table1cell8 = new PdfPCell(
				new Phrase(
						"By Completing this enrollment application , I agree to the following:",
						font));
		page2table1cell8.setBorder(0);
		form5.addCell(page2table1cell8);
		setParagraphData(form5, prop.getProperty("page5_para1").replaceAll("<b>", "").replaceAll("</b>", ""));
		setParagraphData(form5, prop.getProperty("page5_para2").replaceAll("<b>", "").replaceAll("</b>", ""));
		setParagraphData(form5, prop.getProperty("page5_para3").replaceAll("<b>", "").replaceAll("</b>", ""));
		setParagraphData(form5, prop.getProperty("page5_para4").replaceAll("<b>", "").replaceAll("</b>", ""));
		setParagraphData(form5, prop.getProperty("page5_para5").replaceAll("<b>", "").replaceAll("</b>", ""));
		setParagraphData(form5, prop.getProperty("page5_para6").replaceAll("<b>", "").replaceAll("</b>", ""));
		form5.setSpacingAfter(10);

		String signature = getChangedValue(pdfAgreeDetails.getSignatureName());
		String todayDate = getChangedValue(pdfAgreeDetails.getTodayDate());
		
		if(signature != null && !signature.equals("")){
			todayDate = StringUtil.getDateMMDDYYYY(new Date());
		}
		
		String name = getChangedValue(pdfAgreeDetails.getLegalFirstName());
		String relation = getChangedValue(pdfAgreeDetails.getLegalRelationErloll());
		String address = getChangedValue(pdfAgreeDetails.getLegalAddress());
		String phoneNo = getChangedValue(pdfAgreeDetails.getLegalPhNumber());

		setAggrementDetails(form5, "Signature : ", signature,
				" Today's Date : ", todayDate);
		PdfPCell cell11 = new PdfPCell(
				new Paragraph(
						" If you are the authorized representative, you must sign above and provide	the following information:",
						font));
		cell11.setBorder(0);
		form5.addCell(cell11);
		setAggrementDetails(form5, "Name : ", name,
				" Relationship to Enrollee : ", relation);
		setAggrementDetails(form5, "Address : ", address, " Phone number : ",
				phoneNo);

		PdfPTable outerTable = new PdfPTable(1);
		outerTable.setWidthPercentage(100);
		outerTable.addCell(form5);

		return outerTable;
	}
	/**IFOX-00403984 Changes Start.*/
	/**
	 * @param pdfAgreeDetails
	 * @param planName
	 * @return
	 */
	private static PdfPTable pdfPage5Table2(AgreeDetailsVO pdfAgreeDetails, String planName) {

		PdfPTable form5 = new PdfPTable(1);
		form5.setWidthPercentage(100);
		form5.setSpacingBefore(10);
		form5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		setHeader(form5, "Please Read and sign Below");
		PdfPCell page2table1cell8 = new PdfPCell(
				new Phrase(
						"By Completing this enrollment application , I agree to the following:",
						font));
		page2table1cell8.setBorder(0);
		form5.addCell(page2table1cell8);
		setParagraphData(form5, prop.getProperty("page5_para1_new").replaceAll("<b>", "").replaceAll("</b>", ""));
		setParagraphData(form5, prop.getProperty("page5_para2_new").replaceAll("<b>", "").replaceAll("</b>", ""));
		setParagraphData(form5, prop.getProperty("page5_para3_new").replaceAll("<b>", "").replaceAll("</b>", ""));
		setParagraphData(form5, prop.getProperty("page5_para4_new").replaceAll("<b>", "").replaceAll("</b>", ""));
		setParagraphData(form5, prop.getProperty("page5_para5_new").replaceAll("<b>", "").replaceAll("</b>", ""));
		setParagraphData(form5, prop.getProperty("page5_para6").replaceAll("<b>", "").replaceAll("</b>", ""));
		form5.setSpacingAfter(10);

		String signature = getChangedValue(pdfAgreeDetails.getSignatureName());
		String todayDate = getChangedValue(pdfAgreeDetails.getTodayDate());
		
		if(signature != null && !signature.equals("")){
			todayDate = StringUtil.getDateMMDDYYYY(new Date());
		}
		
		String name = getChangedValue(pdfAgreeDetails.getLegalFirstName());
		String relation = getChangedValue(pdfAgreeDetails.getLegalRelationErloll());
		String address = getChangedValue(pdfAgreeDetails.getLegalAddress());
		String phoneNo = getChangedValue(pdfAgreeDetails.getLegalPhNumber());

		setAggrementDetails(form5, "Signature : ", signature,
				" Today's Date : ", todayDate);
		PdfPCell cell11 = new PdfPCell(
				new Paragraph(
						" If you are the authorized representative, you must sign above and provide	the following information:",
						font));
		cell11.setBorder(0);
		form5.addCell(cell11);
		setAggrementDetails(form5, "Name : ", name,
				" Relationship to Enrollee : ", relation);
		setAggrementDetails(form5, "Address : ", address, " Phone number : ",
				phoneNo);

		PdfPTable outerTable = new PdfPTable(1);
		outerTable.setWidthPercentage(100);
		outerTable.addCell(form5);

		return outerTable;
	}
	/**IFOX-00403984 Changes Stop.*/
	private static void setAggrementDetails(PdfPTable form5, String propName,
			String propValue, String propName2, String propValue2) {

		PdfPTable table = new PdfPTable(4);
		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		PdfPCell cell1 = new PdfPCell(new Paragraph(propName, font));
		cell1.setBorder(Rectangle.NO_BORDER);
		PdfPCell cell12 = new PdfPCell(new Paragraph(propValue, font));
		cell12.setBorder(Rectangle.NO_BORDER);
		PdfPCell cell13 = new PdfPCell(new Paragraph(propName2, font));
		cell13.setBorder(Rectangle.NO_BORDER);
		PdfPCell cell14 = new PdfPCell(new Paragraph(propValue2, font));
		cell14.setBorder(Rectangle.NO_BORDER);
		table.addCell(cell1);
		table.addCell(cell12);
		table.addCell(cell13);
		table.addCell(cell14);
		PdfPTable outerTable = new PdfPTable(1);
		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		outerTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		outerTable.addCell(table);
		form5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		form5.addCell(outerTable);

	}

	/**
	 * @param request
	 * @param response
	 * @return
	 */
	public static byte[] saveBytesPDF(HttpServletRequest request,
			HttpServletResponse response) {

		try {
			System.out.println("SharpPdfGen2020 : saveBytesPDF : Begin :");
			ByteArrayOutputStream baos = savePdf(request, response);

			byte[] pdfData = baos.toByteArray();
			byte[] pdfSave = Base64.encodeBase64(pdfData);
			System.out.println("SharpPdfGen2020 : saveBytesPDF : End :");
			return pdfSave;
		} catch (Exception exp) {
			exp.printStackTrace();
			LOGGER.error(" SharpPdfGen2020 : saveBytesPDF : " + exp.getMessage());
		}
		return null;
	}

	private static void pdfPage2Table2InstDetails(PdfPTable page2Table2,
			PolicyDetailsVO pdfPolicyDetails) {

		PdfPTable institution = new PdfPTable(1);
		institution.setWidthPercentage(100);
		institution.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		institution
				.addCell(new Phrase(
						"    Name of Institution: "
								+ (getChangedValue(pdfPolicyDetails
										.getInstituteName())), font));

		PdfPCell institutionCell = new PdfPCell(institution);
		institutionCell.setBorder(Rectangle.NO_BORDER);
		institutionCell.setPadding(5);
		institutionCell.setLeading(0f, 1.0f);
		page2Table2.addCell(institutionCell);

		PdfPTable insAddress = new PdfPTable(1);
		insAddress.setWidthPercentage(100);
		insAddress.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		insAddress.addCell(new Phrase("    Address of institution : "
				+ (getChangedValue(pdfPolicyDetails.getInstituteAddress())),
				font));
		insAddress.addCell(new Phrase(
				"                "
						+ (getChangedValue(pdfPolicyDetails
								.getInstituteOtherAddress())), font));

		PdfPCell insAddressCell = new PdfPCell(insAddress);
		insAddressCell.setBorder(Rectangle.NO_BORDER);
		insAddressCell.setPadding(5);
		insAddressCell.setLeading(0f, 1.0f);
		page2Table2.addCell(insAddressCell);

		PdfPTable insPhoneNo = new PdfPTable(1);
		insPhoneNo.setWidthPercentage(100);
		insPhoneNo.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		insPhoneNo.addCell(new Phrase("    Phone Number of Institution :"
				+ (getChangedValue(pdfPolicyDetails.getInstitutePhone()))
				+ "\n", font));

		PdfPCell insPhoneNoCell = new PdfPCell(insPhoneNo);
		insPhoneNoCell.setBorder(Rectangle.NO_BORDER);
		insPhoneNoCell.setPadding(5);
		page2Table2.addCell(insPhoneNoCell);

	}

	/**
	 * @param pdfAttestationDetails
	 * @param document
	 * @param page2Logotable
	 * @return
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static PdfPTable pdfPage4Table1(
			AttestationDetailsVO pdfAttestationDetails, Document document)
			throws DocumentException, IOException {

		PdfPTable page4Table1 = new PdfPTable(1);
		page4Table1.setWidthPercentage(100);
		page4Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page4Table1.setSpacingBefore(10);

		setHeader(page4Table1, prop.getProperty("page4.header").replaceAll("<b>", "").replaceAll("</b>", ""));

		String question1 = getChangedValue(pdfAttestationDetails
				.getNewMedicare());
		String question2 = getChangedValue(pdfAttestationDetails
				.getRecntMovChBox());
		String question3 = getChangedValue(pdfAttestationDetails
				.getIncarcerationInd());
		String question4 = getChangedValue(pdfAttestationDetails
				.getMvdUsChBox());
		String question5 = getChangedValue(pdfAttestationDetails
				.getLawFullChkBox());
		String question6 = getChangedValue(pdfAttestationDetails
				.getMcNumChBox());
		String question7 = getChangedValue(pdfAttestationDetails
				.getRevMedChBox());
		String question8 = getChangedValue(pdfAttestationDetails
				.getNlElgPrescChBox());
		String question9 = getChangedValue(pdfAttestationDetails
				.getLngcareFacility());
		String question10 = getChangedValue(pdfAttestationDetails
				.getRecntleftPlChBox());
		String question11 = getChangedValue(pdfAttestationDetails
				.getTrcntCreditChBox());
		String question12 = getChangedValue(pdfAttestationDetails
				.getLevEmpChBox());
		String question13 = getChangedValue(pdfAttestationDetails
				.getBelongStatePharmacy());
		String question14 = getChangedValue(pdfAttestationDetails
				.getPlanEndingContract());
		String question15 = getChangedValue(pdfAttestationDetails
				.getNoElgbspseChBox());
		
		
		//Begin: 2019 web app changes - IFOX-00406768
		/*
		String question21 = getChangedValue(pdfAttestationDetails.getMedicareAdvantagePlanChange());
		String question22 = getChangedValue(pdfAttestationDetails.getChangeInMedicaid());
		String question23 = getChangedValue(pdfAttestationDetails.getChangeInExtraHelp());
		String question24 = getChangedValue(pdfAttestationDetails.getChooseDifferentMedicarePlan());
		String question25 = getChangedValue(pdfAttestationDetails.getAffectedByMajorDisaster());
		*/
		//End: 2019 web app changes - IFOX-00406768
		
		
		if ("" != question1) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question1"),
					"");

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question1"),
					"");

		}
		
		
		//Begin: 2019 web app changes - IFOX-00406768
		/*
		if ("" != question21) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question21"), "");
		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question21"), "");
		}
		*/
		//End: 2019 web app changes - IFOX-00406768
		

		if ("" != question2) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question2"),
					getChangedValue(pdfAttestationDetails
							.getRecentMovedOption()));

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question2"),
					getChangedValue(pdfAttestationDetails
							.getRecentMovedOption()));

		}

		if ("" != question3) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question3"),
					getChangedValue(pdfAttestationDetails.getIncarceration()));

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question3"),
					getChangedValue(pdfAttestationDetails.getIncarceration()));

		}

		if ("" != question4) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question4"),
					getChangedValue(pdfAttestationDetails.getMovedBackUs()));

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question4"),
					getChangedValue(pdfAttestationDetails.getMovedBackUs()));

		}

		if ("" != question5) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question5"),
					getChangedValue(pdfAttestationDetails
							.getLawFullChckBoxDate()));

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question5"),
					getChangedValue(pdfAttestationDetails
							.getLawFullChckBoxDate()));

		}
		
		
		//Begin: 2019 web app changes - IFOX-00406768
		/*
		if ("" != question22) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question22"), "");
		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question22"), "");
		}

		if ("" != question23) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question23"), "");
		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question23"), "");
		}
		*/
		//End: 2019 web app changes - IFOX-00406768
		

		if ("" != question6) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question6"),
					"");

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question6"),
					"");

		}

		if ("" != question7) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question7"),
					"");

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question7"),
					"");

		}

		if ("" != question8) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question8"),
					getChangedValue(pdfAttestationDetails
							.getNoEligbPrescDrugs()));

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question8"),
					getChangedValue(pdfAttestationDetails
							.getNoEligbPrescDrugs()));

		}

		if ("" != question9) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question9"),
					getChangedValue(pdfAttestationDetails
							.getLngcareFacilityDate()));

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question9"),
					getChangedValue(pdfAttestationDetails
							.getLngcareFacilityDate()));

		}

		if ("" != question10) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question10"),
					getChangedValue(pdfAttestationDetails.getRecntLeftPace()));

		} else {
			checkBox(page4Table1, uncheck,
					prop.getProperty("page4.Question10"),
					getChangedValue(pdfAttestationDetails.getRecntLeftPace()));

		}

		if ("" != question11) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question11"),
					getChangedValue(pdfAttestationDetails
							.getRecentlyCreditable()));

		} else {
			checkBox(page4Table1, uncheck,
					prop.getProperty("page4.Question11"),
					getChangedValue(pdfAttestationDetails
							.getRecentlyCreditable()));

		}

		if ("" != question12) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question12"),
					getChangedValue(pdfAttestationDetails
							.getLeavingEmployerCoverage()));

		} else {
			checkBox(page4Table1, uncheck,
					prop.getProperty("page4.Question12"),
					getChangedValue(pdfAttestationDetails
							.getLeavingEmployerCoverage()));

		}

		if ("" != question13) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question13"),
					"");

		} else {
			checkBox(page4Table1, uncheck,
					prop.getProperty("page4.Question13"), "");

		}

		if ("" != question14) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question14"),
					"");

		} else {
			checkBox(page4Table1, uncheck,
					prop.getProperty("page4.Question14"), "");

		}
		
		
		//Begin: 2019 web app changes - IFOX-00406768
		/*
		if ("" != question24) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question24"), "");
		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question24"), "");
		}
		*/
		//End: 2019 web app changes - IFOX-00406768

		if ("" != question15) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question15"),
					getChangedValue(pdfAttestationDetails.getNoEligSpecial()));

		} else {
			checkBox(page4Table1, uncheck,
					prop.getProperty("page4.Question15"),
					getChangedValue(pdfAttestationDetails.getNoEligSpecial()));

		}
		
		//Begin: 2019 web app changes - IFOX-00406768
		/*
		if ("" != question25) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question25"), "");
		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question25"), "");
		}
		*/
		//End: 2019 web app changes - IFOX-00406768
		
		setParagraphData(page4Table1, prop.getProperty("page4.para1"));
		setParagraphData(page4Table1, prop.getProperty("page4.para2"));
		setParagraphData(page4Table1, prop.getProperty("page4.para3"));
		setParagraphData(page4Table1, prop.getProperty("page4.para4").replaceAll("<b>", "").replaceAll("</b>", ""));

		PdfPTable outer = new PdfPTable(1);
		outer.setWidthPercentage(100);
		outer.addCell(page4Table1);
		return outer;

	}


	/**
	 * @param pdfAttestationDetails
	 * @param document
	 * @param page2Logotable
	 * @return
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static PdfPTable pdfPage4Table1(
			AttestationDetailsVO pdfAttestationDetails, Document document, EnrollmentVO enrollmentVO)
			throws DocumentException, IOException {

		PdfPTable page4Table1 = new PdfPTable(1);
		page4Table1.setWidthPercentage(100);
		page4Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page4Table1.setSpacingBefore(10);

		setHeader(page4Table1, prop.getProperty("page4.header").replaceAll("<b>", "").replaceAll("</b>", ""));

/*		String question1 = getChangedValue(pdfAttestationDetails
				.getNewMedicare());
		String question2 = getChangedValue(pdfAttestationDetails
				.getRecntMovChBox());
		String question3 = getChangedValue(pdfAttestationDetails
				.getIncarcerationInd());
		String question4 = getChangedValue(pdfAttestationDetails
				.getMvdUsChBox());
		String question5 = getChangedValue(pdfAttestationDetails
				.getLawFullChkBox());
		String question6 = getChangedValue(pdfAttestationDetails
				.getMcNumChBox());
		String question7 = getChangedValue(pdfAttestationDetails
				.getRevMedChBox());
		String question8 = getChangedValue(pdfAttestationDetails
				.getNlElgPrescChBox());
		String question9 = getChangedValue(pdfAttestationDetails
				.getLngcareFacility());
		String question10 = getChangedValue(pdfAttestationDetails
				.getRecntleftPlChBox());
		String question11 = getChangedValue(pdfAttestationDetails
				.getTrcntCreditChBox());
		String question12 = getChangedValue(pdfAttestationDetails
				.getLevEmpChBox());
		String question13 = getChangedValue(pdfAttestationDetails
				.getBelongStatePharmacy());
		String question14 = getChangedValue(pdfAttestationDetails
				.getPlanEndingContract());
		String question15 = getChangedValue(pdfAttestationDetails
				.getNoElgbspseChBox());*/
				

		if (enrollmentVO.getAep() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.QuestionElectionType"),
					"");

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.QuestionElectionType"),
					"");

		}		
		
		
		if (enrollmentVO.getC20() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question0"),
					"");

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question0"),
					"");

		}		
		
		if (enrollmentVO.getC1() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question1"),
					"");

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question1"),
					"");

		}
		
		
		//Begin: 2019 web app changes - IFOX-00406768
		/*
		if (enrollmentVO.getC21() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question21"), "");
		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question21"), "");
		}
		*/
		//End: 2019 web app changes - IFOX-00406768
		

		if (enrollmentVO.getC2() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question2"), getChangedValue(enrollmentVO.getAttestation2()));

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question2"),"");

		}

		if (enrollmentVO.getC3() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question3"), getChangedValue(enrollmentVO.getAttestation3()));

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question3"),"");

		}

		if (enrollmentVO.getC4() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question4"), getChangedValue(enrollmentVO.getAttestation4()));

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question4"), "");

		}

		if (enrollmentVO.getC5() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question5"), getChangedValue(enrollmentVO.getAttestation5()));

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question5"),"");

		}
		
		
		
		//Begin: 2019 web app changes - IFOX-00406768
		/*
		if (enrollmentVO.getC22() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question22"), getChangedValue(enrollmentVO.getAttestation22()));
		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question22"),"");
		}
		
		if (enrollmentVO.getC23() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question23"), getChangedValue(enrollmentVO.getAttestation23()));
		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question23"),"");
		}
		*/
		//End: 2019 web app changes - IFOX-00406768
		
		
		

		if (enrollmentVO.getC6() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question6"),
					"");

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question6"),
					"");

		}

		if (enrollmentVO.getC7() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question7"),
					"");

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question7"),
					"");

		}

		if (enrollmentVO.getC8() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question8"),getChangedValue(enrollmentVO.getAttestation8()));

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question8"),"");

		}

		if (enrollmentVO.getC9() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question9"),getChangedValue(enrollmentVO.getAttestation9()));

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question9"),"");

		}

		if (enrollmentVO.getC10() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question10"),getChangedValue(enrollmentVO.getAttestation10()));

		} else {
			checkBox(page4Table1, uncheck,
					prop.getProperty("page4.Question10"),"");

		}

		if (enrollmentVO.getC11() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question11"),getChangedValue(enrollmentVO.getAttestation11()));

		} else {
			checkBox(page4Table1, uncheck,prop.getProperty("page4.Question11"),"");

		}

		if (enrollmentVO.getC12() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question12"),getChangedValue(enrollmentVO.getAttestation12()));

		} else {
			checkBox(page4Table1, uncheck,prop.getProperty("page4.Question12"),"");

		}

		if (enrollmentVO.getC13() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question13"),
					"");

		} else {
			checkBox(page4Table1, uncheck,
					prop.getProperty("page4.Question13"), "");

		}

		if (enrollmentVO.getC14() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question14"),
					"");

		} else {
			checkBox(page4Table1, uncheck,
					prop.getProperty("page4.Question14"), "");

		}
		
		
		//Begin: 2019 web app changes - IFOX-00406768
		/*
		if (enrollmentVO.getC24() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question24"), getChangedValue(enrollmentVO.getAttestation24()));
		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question24"),"");
		}
		*/
		//End: 2019 web app changes - IFOX-00406768		
		
		

		if (enrollmentVO.getC15() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question15"),getChangedValue(enrollmentVO.getAttestation15()));

		} else {
			checkBox(page4Table1, uncheck,prop.getProperty("page4.Question15"),"");

		}
		
		
		//Begin: 2019 web app changes - IFOX-00406768
		/*
		if (enrollmentVO.getC25() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question25"), "");
		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question25"), "");
		}
		 */
		
		if (enrollmentVO.getC16() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question16"),getChangedValue(enrollmentVO.getAttestation16()));

		} else {
			checkBox(page4Table1, uncheck,prop.getProperty("page4.Question16"),getChangedValue(enrollmentVO.getAttestation16()));

		}	
		
		//End: 2019 web app changes - IFOX-00406768		
		
		setParagraphData(page4Table1, prop.getProperty("page4.para1"));
		setParagraphData(page4Table1, prop.getProperty("page4.para2"));
		setParagraphData(page4Table1, prop.getProperty("page4.para3"));
		setParagraphData(page4Table1, prop.getProperty("page4.para4").replaceAll("<b>", "").replaceAll("</b>", ""));

		PdfPTable outer = new PdfPTable(1);
		outer.setWidthPercentage(100);
		outer.addCell(page4Table1);
		return outer;

	}
	
	/**IFOX-00403984 Changes Start.*/
	/**
	 * @param pdfAttestationDetails
	 * @param document
	 * @param enrollmentVO
	 * @param planName
	 * @return
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static PdfPTable pdfPage4Table1(
			AttestationDetailsVO pdfAttestationDetails, Document document, EnrollmentVO enrollmentVO,
			String planName)
			throws DocumentException, IOException {

		PdfPTable page4Table1 = new PdfPTable(1);
		page4Table1.setWidthPercentage(100);
		page4Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page4Table1.setSpacingBefore(10);

		setHeader(page4Table1, prop.getProperty("page4.header").replaceAll("<b>", "").replaceAll("</b>", ""));

		/*if (enrollmentVO.getAep() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.QuestionElectionType"),
					"");

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.QuestionElectionType"),
					"");
		}*/		
		
		
		if (enrollmentVO.getC20() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question0_hmo"),
					"");

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question0_hmo"),
					"");

		}		
		
		if (enrollmentVO.getC1() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question1"),
					"");

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question1"),
					"");

		}

		if (enrollmentVO.getC2() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question2"), getChangedValue(enrollmentVO.getAttestation2()));

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question2"),"");

		}

		if (enrollmentVO.getC3() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question3"), getChangedValue(enrollmentVO.getAttestation3()));

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question3"),"");

		}

		if (enrollmentVO.getC4() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question4"), getChangedValue(enrollmentVO.getAttestation4()));

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question4"), "");

		}

		if (enrollmentVO.getC5() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question5"), getChangedValue(enrollmentVO.getAttestation5()));

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question5"),"");

		}

		if (enrollmentVO.getC6() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question6"),
					"");

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question6"),
					"");

		}

		if (enrollmentVO.getC7() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question7"),
					"");

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question7"),
					"");

		}

		if (enrollmentVO.getC8() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question8"),getChangedValue(enrollmentVO.getAttestation8()));

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question8"),"");

		}

		if (enrollmentVO.getC9() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question9"),getChangedValue(enrollmentVO.getAttestation9()));

		} else {
			checkBox(page4Table1, uncheck, prop.getProperty("page4.Question9"),"");

		}

		if (enrollmentVO.getC10() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question10"),getChangedValue(enrollmentVO.getAttestation10()));

		} else {
			checkBox(page4Table1, uncheck,
					prop.getProperty("page4.Question10"),"");

		}

		if (enrollmentVO.getC11() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question11"),getChangedValue(enrollmentVO.getAttestation11()));

		} else {
			checkBox(page4Table1, uncheck,prop.getProperty("page4.Question11"),"");

		}

		if (enrollmentVO.getC12() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question12"),getChangedValue(enrollmentVO.getAttestation12()));

		} else {
			checkBox(page4Table1, uncheck,prop.getProperty("page4.Question12"),"");

		}

		if (enrollmentVO.getC13() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question13"),
					"");

		} else {
			checkBox(page4Table1, uncheck,
					prop.getProperty("page4.Question13"), "");

		}

		if (enrollmentVO.getC14() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question14"),
					"");

		} else {
			checkBox(page4Table1, uncheck,
					prop.getProperty("page4.Question14"), "");

		}

		if (enrollmentVO.getC15() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question15"),getChangedValue(enrollmentVO.getAttestation15()));

		} else {
			checkBox(page4Table1, uncheck,prop.getProperty("page4.Question15"),"");

		}

		if (enrollmentVO.getC16() != null) {
			checkBox(page4Table1, check, prop.getProperty("page4.Question16"),getChangedValue(enrollmentVO.getAttestation16()));

		} else {
			checkBox(page4Table1, uncheck,prop.getProperty("page4.Question16"),getChangedValue(enrollmentVO.getAttestation16()));

		}	
		
		setParagraphData(page4Table1, prop.getProperty("page4.para1_new"));
		setParagraphData(page4Table1, prop.getProperty("page4.para2_new"));
		setParagraphData(page4Table1, prop.getProperty("page4.para3"));
		setParagraphData(page4Table1, prop.getProperty("page4.para4_new").replaceAll("<b>", "").replaceAll("</b>", ""));

		PdfPTable outer = new PdfPTable(1);
		outer.setWidthPercentage(100);
		outer.addCell(page4Table1);
		return outer;

	}
	/**IFOX-00403984 Changes Stop.*/

	
	private static void setParagraphData(PdfPTable page4Table1, String property) {

		PdfPCell page2table1cell5 = new PdfPCell(new Phrase(property, font));
		page2table1cell5.setHorizontalAlignment(Element.ALIGN_JUSTIFIED);
		page2table1cell5.setBorder(Rectangle.NO_BORDER);
		page2table1cell5.setPadding(5);
		page2table1cell5.setLeading(0f, 1.5f);
		page4Table1.addCell(page2table1cell5);

	}

	private static void setHeader(PdfPTable page4Table1, String property) {
		PdfPCell page2table1cell1 = new PdfPCell(new Phrase(property,
				FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD,
						java.awt.Color.YELLOW)));
		page2table1cell1.setNoWrap(true);
		page2table1cell1.setBackgroundColor(headerColor);
		page2table1cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
		page2table1cell1.setBorder(0);
		page4Table1.addCell(page2table1cell1);

	}

	/**
	 * @param pdfPolicyDetails
	 * @return
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static PdfPTable page3Table(PolicyDetailsVO pdfPolicyDetails)
			throws DocumentException, IOException {

		PdfPTable page2Table2 = new PdfPTable(1);
		page2Table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2Table2.setWidthPercentage(100);
		page2Table2.setSpacingBefore(10);
		setHeader(page2Table2,
				"Please Read and Answer These Important Questions:");

		String radioButtonFlagfortable2cell1 = getChangedValue(pdfPolicyDetails
				.getRenalDisease());
		if (radioButtonFlagfortable2cell1 != null
				&& radioButtonFlagfortable2cell1.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell1(page2Table2,
					buttonCheckImage, buttonUncheckImage,
					" 1. Do you have End Stage Renal Disease(ESRD)? ");
		} else if (!radioButtonFlagfortable2cell1.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell1(page2Table2,
					buttonUncheckImage, buttonCheckImage,
					" 1. Do you have End Stage Renal Disease(ESRD)? ");
		}

		PdfPCell page2table2cell3 = new PdfPCell(new Phrase(
				prop.getProperty("page3_Q1").replaceAll("<b>", "").replaceAll("</b>", ""), font));
		page2table2cell3.setHorizontalAlignment(Element.ALIGN_JUSTIFIED);
		page2table2cell3.setBorder(Rectangle.NO_BORDER);
		page2table2cell3.setPadding(5);
		page2table2cell3.setLeading(0f, 1.5f);
		page2Table2.addCell(page2table2cell3);

		String radioButtonFlagfortable2cell2 = getChangedValue(pdfPolicyDetails
				.getHealthBenefits());

		if (radioButtonFlagfortable2cell2.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell1(page2Table2,
					buttonCheckImage, buttonUncheckImage,
					prop.getProperty("page3_Q2"));
		} else if (!radioButtonFlagfortable2cell2.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell1(page2Table2,
					buttonUncheckImage, buttonCheckImage,
					prop.getProperty("page3_Q2"));
		}

		PdfPCell page2table2cell5 = new PdfPCell(
				new Phrase(
						"     If yes, please list your other coverage and your identification (ID) numbers(s) for this coverage:",
						font));
		page2table2cell5.setBorder(Rectangle.NO_BORDER);
		page2Table2.addCell(page2table2cell5);

		PdfPTable coverage = new PdfPTable(3);
		coverage.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		coverage.addCell(new Phrase("  Name of other coverage : ", font));

		coverage.addCell(new Phrase("ID# for this coverage: ", font));
		coverage.addCell(new Phrase("Group # for this coverage:", font));

		PdfPCell coverageCell = new PdfPCell(coverage);
		coverageCell.setBorder(Rectangle.NO_BORDER);
		coverageCell.setPadding(5);
		coverageCell.setLeading(0f, 1.5f);
		page2Table2.addCell(coverageCell);

		PdfPTable page2table2cell6_table2 = new PdfPTable(3);
		page2table2cell6_table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2table2cell6_table2
				.addCell(new Phrase((getChangedValue(pdfPolicyDetails
						.getDurgNameCoverage())), font));
		page2table2cell6_table2.addCell(new Phrase(
				(getChangedValue(pdfPolicyDetails.getDurgIdCoverage())), font));
		page2table2cell6_table2.addCell(new Phrase(
				(getChangedValue(pdfPolicyDetails.getDurgGroupCoverage())),
				font));

		PdfPCell page2table2cell7 = new PdfPCell(page2table2cell6_table2);
		page2table2cell7.setBorder(Rectangle.NO_BORDER);
		page2table2cell7.setPadding(5);
		page2table2cell7.setLeading(0f, 1.5f);
		page2Table2.addCell(page2table2cell7);

		String radioButtonFlagfortable2cell9 = getChangedValue(pdfPolicyDetails
				.getNursingHome());
		String phrase = " 3. Are you a resident in a long-term care facility, such as a nursing home ?";
		if (radioButtonFlagfortable2cell9.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell10(page2Table2,
					buttonCheckImage, buttonUncheckImage, phrase);
		} else if (!radioButtonFlagfortable2cell9.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell10(page2Table2,
					buttonUncheckImage, buttonCheckImage, phrase);
		}

		PdfPCell page2table2cell10 = new PdfPCell(new Phrase(
				"     If yes, please provide the following information:", font));
		page2table2cell10.setBorder(Rectangle.NO_BORDER);
		page2table2cell10.setPadding(5);
		page2table2cell10.setLeading(0f,1.0f);
		page2Table2.addCell(page2table2cell10);

		pdfPage2Table2InstDetails(page2Table2, pdfPolicyDetails);

		String radioButtonFlagfortable2cell11 = getChangedValue(pdfPolicyDetails
				.getStateMedicaid());

		phrase = " 4. Are you enrolled in Medi-Cal (Medicaid)? ";

		if (radioButtonFlagfortable2cell11.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell1(page2Table2,
					buttonCheckImage, buttonUncheckImage, phrase);
		} else if (!radioButtonFlagfortable2cell11.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell1(page2Table2,
					buttonUncheckImage, buttonCheckImage, phrase);
		}

		PdfPCell page2table2cell11 = new PdfPCell(
				new Phrase(
						"       If "
								+ "yes"
								+ ",  please provide your Medi-Cal number: "
								+ (getChangedValue(pdfPolicyDetails
										.getMedicaidNumber())), font));

		page2table2cell11.setBorder(Rectangle.NO_BORDER);
		page2table2cell11.setPadding(5);
		page2table2cell11.setLeading(0f, 1.0f);
		page2Table2.addCell(page2table2cell11);

		String radioButtonFlagfortable2cell12 = getChangedValue(pdfPolicyDetails
				.getSpouse());

		phrase = " 5. Do either you or your spouse work? ";
		if (radioButtonFlagfortable2cell12.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell1(page2Table2,
					buttonCheckImage, buttonUncheckImage, phrase);
		} else if (!radioButtonFlagfortable2cell12.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell1(page2Table2,
					buttonUncheckImage, buttonCheckImage, phrase);
		}

		PdfPCell pcp = new PdfPCell(new Phrase(
				"        Please choose a Primary Care Physician (PCP) :", font));
		pcp.setBorder(Rectangle.NO_BORDER);
		page2Table2.addCell(pcp);

		PdfPTable pcpTable = new PdfPTable(4);
		pcpTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		pcpTable.addCell(new Phrase("      PCP Name : ", font));
		pcpTable.addCell(new Phrase(pdfPolicyDetails.getNewPhysicianName(), font));
		pcpTable.addCell(new Phrase("    PCP Medical Group:  ", font));
		pcpTable.addCell(new Phrase(pdfPolicyDetails.getPcpGroup(), font));

		PdfPCell pcpTableCell = new PdfPCell(pcpTable);
		pcpTableCell.setBorder(Rectangle.NO_BORDER);
		pcpTableCell.setPadding(5);
		pcpTableCell.setLeading(0f, 1.5f);
		page2Table2.addCell(pcpTableCell);

		PdfPCell langTable = new PdfPCell(new Phrase(" "
				+ prop.getProperty("page3_lang").replaceAll("<b>", "").replaceAll("</b>", ""), font));
		langTable.setBorder(Rectangle.NO_BORDER);
		langTable.setPadding(5);
		langTable.setLeading(0f, 1.5f);
		page2Table2.addCell(langTable);

		String langInd = getChangedValue(pdfPolicyDetails.getLangInd());
		if (langInd.equalsIgnoreCase("S")) {
			setLangData(page2Table2, buttonCheckImage, "   Spanish :",
					buttonUncheckImage, "  Other :");
		} else if (langInd.equalsIgnoreCase("O")) {
			setLangData(page2Table2, buttonUncheckImage, "   Spanish :",
					buttonCheckImage, "   Other :"
							+ getChangedValue(pdfPolicyDetails.getOtherLang()));
		}
		setHeader(page2Table2, prop.getProperty("page3_header2"));
		PdfPCell exhibitTable2 = new PdfPCell(new Phrase(
				prop.getProperty("page3_footer").replaceAll("<b>", "").replaceAll("</b>", ""), font));
		exhibitTable2.setHorizontalAlignment(Element.ALIGN_JUSTIFIED);
		exhibitTable2.setBorder(Rectangle.NO_BORDER);
		exhibitTable2.setPadding(5);
		exhibitTable2.setLeading(0f, 1.5f);
		page2Table2.addCell(exhibitTable2);
		PdfPTable outer = new PdfPTable(1);
		outer.setWidthPercentage(100);
		outer.addCell(page2Table2);
		return outer;
	}
	/**IFOX-00403984 Changes Start.*/
	/**
	 * @param pdfPolicyDetails
	 * @param planName
	 * @return
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static PdfPTable page3Table(PolicyDetailsVO pdfPolicyDetails, String planName,
			EnrollmentVO enrollmentVO)
			throws DocumentException, IOException {

		PdfPTable page2Table2 = new PdfPTable(1);
		page2Table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2Table2.setWidthPercentage(100);
		page2Table2.setSpacingBefore(10);
		setHeader(page2Table2,
				"Please Read and Answer These Important Questions:");
		
		/**Important Questions 1 Start*/
		
		//Begin: Modified for IFOX-00414491
		/*
		String phrase = " 1. Are you the City of San Diego retiree? ";
		String radioButtonFlagForQues1 = getChangedValue(enrollmentVO.getRetiree());
		
		if(radioButtonFlagForQues1 != null && radioButtonFlagForQues1.equalsIgnoreCase("Y")){
			displayButtonInPDFforForm2table2cell1(page2Table2,
					buttonCheckImage, buttonUncheckImage,phrase);
		}else if(!radioButtonFlagForQues1.equalsIgnoreCase("Y")){
			displayButtonInPDFforForm2table2cell1(page2Table2,
					buttonUncheckImage, buttonCheckImage,phrase);
		}
		
		PdfPCell page2table2Ques1 = new PdfPCell(
				new Phrase(
						"If yes, retirement date: "+StringUtil.nonNullTrim(enrollmentVO.getRetiredate())+"."
						+"		If no, name of retiree: "+StringUtil.nonNullTrim(enrollmentVO.getRetirename()),
						font));
		page2table2Ques1.setBorder(Rectangle.NO_BORDER);
		page2Table2.addCell(page2table2Ques1);
		*/
		//End: Modified for IFOX-00414491
		/**Important Questions 1 Stop*/
		
		/**Important Questions 2 Start*/
		String phrase = "1. Are you covering a Medicare-eligible spouse or dependent(s) under this employer or Union plan? ";
		String radioButtonFlagForQues2 = getChangedValue(enrollmentVO.getMeddependsp());
		
		if(radioButtonFlagForQues2 != null && radioButtonFlagForQues2.equalsIgnoreCase("Y")){
			displayButtonInPDFforForm2table2cell1(page2Table2,
					buttonCheckImage, buttonUncheckImage,phrase);
		}else if(!radioButtonFlagForQues2.equalsIgnoreCase("Y")){
			displayButtonInPDFforForm2table2cell1(page2Table2,
					buttonUncheckImage, buttonCheckImage,phrase);
		}
		
		PdfPCell page2table2Ques2 = new PdfPCell(
				new Phrase(
						"  If yes, name of spouse: "+StringUtil.nonNullTrim(enrollmentVO.getDependentSpouse())+"."
				+"		Name(s) of dependent(s): "+StringUtil.nonNullTrim(enrollmentVO.getDependentOther()),
						font));
		page2table2Ques2.setBorder(Rectangle.NO_BORDER);
		page2Table2.addCell(page2table2Ques2);
		/**Important Questions 2 Stop*/
		
		/**Important Questions 3 Start*/
		phrase = "2. Do you or your spouse work?";
		String radioButtonFlagfortable2cell12 = getChangedValue(pdfPolicyDetails
				.getSpouse());
		if (radioButtonFlagfortable2cell12.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell1(page2Table2,
					buttonCheckImage, buttonUncheckImage, phrase);
		} else if (!radioButtonFlagfortable2cell12.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell1(page2Table2,
					buttonUncheckImage, buttonCheckImage, phrase);
		}
		/**Important Questions 3 Stop*/
		
		/**Important Questions 4 Start*/
		phrase = "3. Do you have End Stage Renal Disease(ESRD)?";
		String radioButtonFlagfortable2cell1 = getChangedValue(pdfPolicyDetails
				.getRenalDisease());
		if (radioButtonFlagfortable2cell1 != null
				&& radioButtonFlagfortable2cell1.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell1(page2Table2,
					buttonCheckImage, buttonUncheckImage,phrase);
		} else if (!radioButtonFlagfortable2cell1.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell1(page2Table2,
					buttonUncheckImage, buttonCheckImage,phrase);
		}

		PdfPCell page2table2cell3 = new PdfPCell(new Phrase(
				prop.getProperty("page3_Q1").replaceAll("<b>", "").replaceAll("</b>", ""), font));
		page2table2cell3.setHorizontalAlignment(Element.ALIGN_JUSTIFIED);
		page2table2cell3.setBorder(Rectangle.NO_BORDER);
		page2table2cell3.setPadding(5);
		page2table2cell3.setLeading(0f, 1.5f);
		page2Table2.addCell(page2table2cell3);
		/**Important Questions 4 Stop*/
		
		/**Important Questions 5 Start*/
		phrase = "4."+ prop.getProperty("page3_Q5_new");
		
		String radioButtonFlagfortable2cell2 = getChangedValue(pdfPolicyDetails
				.getHealthBenefits());

		if (radioButtonFlagfortable2cell2.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell1(page2Table2,
					buttonCheckImage, buttonUncheckImage,phrase);
		} else if (!radioButtonFlagfortable2cell2.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell1(page2Table2,
					buttonUncheckImage, buttonCheckImage,phrase);
		}

		PdfPCell page2table2cell5 = new PdfPCell(
				new Phrase(
						"  If yes, please list your other coverage and your identification (ID) numbers(s) for this coverage:",
						font));
		page2table2cell5.setBorder(Rectangle.NO_BORDER);
		page2Table2.addCell(page2table2cell5);

		PdfPTable coverage = new PdfPTable(3);
		coverage.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		coverage.addCell(new Phrase("Name of other coverage : ", font));
		coverage.addCell(new Phrase("ID# for this coverage: ", font));
		coverage.addCell(new Phrase("Group # for this coverage:", font));

		PdfPCell coverageCell = new PdfPCell(coverage);
		coverageCell.setBorder(Rectangle.NO_BORDER);
		coverageCell.setPadding(5);
		coverageCell.setLeading(0f, 1.5f);
		page2Table2.addCell(coverageCell);
		
		PdfPTable page2table2cell6_table2 = new PdfPTable(3);
		page2table2cell6_table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2table2cell6_table2
				.addCell(new Phrase((getChangedValue(pdfPolicyDetails
						.getDurgNameCoverage())), font));
		page2table2cell6_table2.addCell(new Phrase(
				(getChangedValue(pdfPolicyDetails.getDurgIdCoverage())), font));
		page2table2cell6_table2.addCell(new Phrase(
				(getChangedValue(pdfPolicyDetails.getDurgGroupCoverage())),
				font));

		PdfPCell page2table2cell7 = new PdfPCell(page2table2cell6_table2);
		page2table2cell7.setBorder(Rectangle.NO_BORDER);
		page2table2cell7.setPadding(5);
		page2table2cell7.setLeading(0f, 1.5f);
		page2Table2.addCell(page2table2cell7);
		/**Important Questions 5 Stop*/
		
		/**Important Questions 6 Start*/
		phrase = " 5. Are you a resident in a long-term care facility, such as a nursing home ?";
		String radioButtonFlagfortable2cell9 = getChangedValue(pdfPolicyDetails
				.getNursingHome());
		if (radioButtonFlagfortable2cell9.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell10(page2Table2,
					buttonCheckImage, buttonUncheckImage, phrase);
		} else if (!radioButtonFlagfortable2cell9.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell10(page2Table2,
					buttonUncheckImage, buttonCheckImage, phrase);
		}

		PdfPCell page2table2cell10 = new PdfPCell(new Phrase(
				"  If yes,  please provide the following information:", font));
		page2table2cell10.setBorder(Rectangle.NO_BORDER);
		page2table2cell10.setPadding(5);
		page2table2cell10.setLeading(0f,1.0f);
		page2Table2.addCell(page2table2cell10);

		pdfPage2Table2InstDetails(page2Table2, pdfPolicyDetails);
		/**Important Questions 6 Stop*/
		
		/**Important Questions 7 Start*/
		phrase = " 6.What is your current health coverage type? ";
		PdfPCell page2table2Ques7 = new PdfPCell(
				new Phrase(phrase+"	"+StringUtil.nonNullTrim(enrollmentVO.getHlthcovType()),
						font));
		page2table2Ques7.setBorder(Rectangle.NO_BORDER);
		page2table2Ques7.setPadding(5);
		page2table2Ques7.setLeading(0f, 1.5f);
		page2Table2.addCell(page2table2Ques7);
		/**Important Questions 7 Stop*/
		
		/**Important Questions 8 Start*/
		phrase = " 7.What is your current insurance company? ";
		PdfPCell page2table2Ques8 = new PdfPCell(
				new Phrase(phrase+"	"+StringUtil.nonNullTrim(enrollmentVO.getHlthcovInscomp()),
						font));
		page2table2Ques8.setBorder(Rectangle.NO_BORDER);
		page2table2Ques8.setPadding(5);
		page2table2Ques8.setLeading(0f, 1.5f);
		page2Table2.addCell(page2table2Ques8);
		/**Important Questions 8 Stop*/
		
		PdfPCell pcp = new PdfPCell(new Phrase(
				" Please choose a Primary Care Physician (PCP) :", font));
		pcp.setBorder(Rectangle.NO_BORDER);
		page2Table2.addCell(pcp);

		PdfPTable pcpTable = new PdfPTable(4);
		pcpTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		pcpTable.addCell(new Phrase("    PCP Name : ", font));
		pcpTable.addCell(new Phrase(pdfPolicyDetails.getNewPhysicianName(), font));
		pcpTable.addCell(new Phrase("    PCP Medical Group:  ", font));
		pcpTable.addCell(new Phrase(pdfPolicyDetails.getPcpGroup(), font));

		PdfPCell pcpTableCell = new PdfPCell(pcpTable);
		pcpTableCell.setBorder(Rectangle.NO_BORDER);
		pcpTableCell.setPadding(5);
		pcpTableCell.setLeading(0f, 1.5f);
		page2Table2.addCell(pcpTableCell);
		
		
		PdfPCell langTable = new PdfPCell(new Phrase(" "
				+ prop.getProperty("page3_lang").replaceAll("<b>", "").replaceAll("</b>", ""), font));
		langTable.setBorder(Rectangle.NO_BORDER);
		langTable.setPadding(5);
		langTable.setLeading(0f, 1.5f);
		page2Table2.addCell(langTable);

		String langInd = getChangedValue(pdfPolicyDetails.getLangInd());
		if (langInd.equalsIgnoreCase("S")) {
			setLangData(page2Table2, buttonCheckImage, "   Spanish :",
					buttonUncheckImage, "  Other :");
		} else if (langInd.equalsIgnoreCase("O")) {
			setLangData(page2Table2, buttonUncheckImage, "   Spanish :",
					buttonCheckImage, "   Other :"
							+ getChangedValue(pdfPolicyDetails.getOtherLang()));
		}
		//setHeader(page2Table2, prop.getProperty("page3_header2"));
		PdfPCell exhibitTable2 = new PdfPCell(new Phrase(
				prop.getProperty("page3_footer_new").replaceAll("<b>", "").replaceAll("</b>", ""), font));
		exhibitTable2.setHorizontalAlignment(Element.ALIGN_JUSTIFIED);
		exhibitTable2.setBorder(Rectangle.NO_BORDER);
		exhibitTable2.setPadding(5);
		exhibitTable2.setLeading(0f, 1.5f);
		page2Table2.addCell(exhibitTable2);
		PdfPTable outer = new PdfPTable(1);
		outer.setWidthPercentage(100);
		outer.addCell(page2Table2);
		return outer;
	}
	/**IFOX-00403984 Changes Stop.*/
	private static void setLangData(PdfPTable table, Image check3, String val1,
			Image check4, String val2) {
		PdfPTable page3Cell2Table3 = new PdfPTable(4);
		page3Cell2Table3.setWidthPercentage(100);
		page3Cell2Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		try {
			page3Cell2Table3.setWidths(new int[] { 2, 48, 2, 48 });
			page3Cell2Table3.addCell(check3);
			page3Cell2Table3.addCell(new Phrase(val1, font));
			page3Cell2Table3.addCell(check4);
			page3Cell2Table3.addCell(new Phrase(val2, font));
			table.addCell(page3Cell2Table3);
		} catch (DocumentException exp) {
			//e.printStackTrace();
			LOGGER.error(" SharpPdfGen2020 : setLangData : " + exp.getMessage());
		}

	}

	/**
	 * @param pdfPolicyDetails
	 * @return
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static PdfPTable pdfPage2Table1(PolicyDetailsVO pdfPolicyDetails,UserDetailsVO pdfUserDetails)
			throws DocumentException, IOException {

		PdfPTable page2Table1 = new PdfPTable(1);
		page2Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2Table1.setWidthPercentage(100);
		page2Table1.setSpacingBefore(10);

		setHeader(page2Table1, "Paying Your Plan Premium");
		//Fix for IFOX-00420776 - Start
		String planName = pdfUserDetails.getPlanName();
		if("SDAB20".equalsIgnoreCase(planName) || "SDABWD20".equalsIgnoreCase(planName) || "SDAP20".equalsIgnoreCase(planName) || "SDAPWD20".equalsIgnoreCase(planName)) {
			setParagraphData(page2Table1, prop.getProperty("PBP801_page2_para1"));
			setParagraphData(page2Table1, prop.getProperty("PBP801_page2_para2"));
			setParagraphData(page2Table1, prop.getProperty("PBP801_page2_para3"));
			setParagraphData(page2Table1, prop.getProperty("PBP801_page2_para4"));
			setParagraphData(page2Table1, prop.getProperty("PBP801_page2_para5"));
		} else {
			setParagraphData(page2Table1, prop.getProperty("page2_para1"));
			setParagraphData(page2Table1, prop.getProperty("page2_para2"));
			setParagraphData(page2Table1, prop.getProperty("page2_para3"));
			setParagraphData(page2Table1, prop.getProperty("page2_para4"));
			setParagraphData(page2Table1, prop.getProperty("page2_para5"));
		}
		PdfPCell page2table1cell8 = new PdfPCell(new Phrase(
				"Please select a premium payment option:", font));
		page2table1cell8.setBorder(0);
		page2Table1.addCell(page2table1cell8);

		String recieveMonthBillCheck = pdfPolicyDetails.getPaymentOption();
		if (recieveMonthBillCheck != null
				&& recieveMonthBillCheck.equalsIgnoreCase("D")) {
			displayCheckBoxInPDFforForm2table1cell9(page2Table1,
					buttonCheckImage, prop.getProperty("page2_para5_Q1"));
		} else {
			displayCheckBoxInPDFforForm2table1cell9(page2Table1,
					buttonUncheckImage, prop.getProperty("page2_para5_Q1"));
		}

		String eftCheck = pdfPolicyDetails.getPaymentOption();
		if (eftCheck != null && eftCheck.equalsIgnoreCase("R")) {
			displayCheckBoxInPDFforForm2table1cell9(page2Table1,
					buttonCheckImage, prop.getProperty("page2_para5_Q2"));
		} else {
			displayCheckBoxInPDFforForm2table1cell9(page2Table1,
					buttonUncheckImage, prop.getProperty("page2_para5_Q2"));
		}

		PdfPCell page2table1cell10 = new PdfPCell(
				new Phrase("\t\tAccount holder name :"
						+ (getChangedValue(pdfPolicyDetails
								.getAccountHolderName())), font));
		page2table1cell10.setBorder(0);
		page2Table1.addCell(page2table1cell10);

		PdfPCell page2table1cell110 = new PdfPCell(new Phrase("\t\tBank Name :"
				+ (getChangedValue(pdfPolicyDetails.getBankName())), font));
		page2table1cell110.setBorder(0);
		page2Table1.addCell(page2table1cell110);

		String checkBoxFlagforform4AccTypecell = getChangedValue(pdfPolicyDetails
				.getAcctype());

		if (checkBoxFlagforform4AccTypecell.equalsIgnoreCase("C")) {
			displayButtonInPDFforForm2StmtsButton(page2Table1,
					buttonCheckImage, buttonUncheckImage);
		} else if ((!checkBoxFlagforform4AccTypecell.equalsIgnoreCase("C"))
				&& (checkBoxFlagforform4AccTypecell.equalsIgnoreCase("S"))) {
			displayButtonInPDFforForm2StmtsButton(page2Table1,
					buttonUncheckImage, buttonCheckImage);
		} else if ((!checkBoxFlagforform4AccTypecell.equalsIgnoreCase("C"))
				&& (!checkBoxFlagforform4AccTypecell.equalsIgnoreCase("S"))) {
			displayButtonInPDFforForm2StmtsButton(page2Table1,
					buttonUncheckImage, buttonUncheckImage);
		}

		PdfPTable page2table1cell1_table3 = new PdfPTable(2);
		page2table1cell1_table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2table1cell1_table3.addCell(new Phrase("\t\tBank routing number : "
				+ (getChangedValue(pdfPolicyDetails.getBankRoutingNumber())),
				font));
		page2table1cell1_table3.addCell(new Phrase("\t\tBank account number: "
				+ (getChangedValue(pdfPolicyDetails.getBankAccountNumber())),
				font));

		PdfPCell page2table1cell11 = new PdfPCell(page2table1cell1_table3);
		page2table1cell11.setBorder(0);
		page2Table1.addCell(page2table1cell11);

		String autoDeductionCheck = getChangedValue(pdfPolicyDetails
				.getPaymentOption());
		if(!"SDAB20".equalsIgnoreCase(planName) && !"SDABWD20".equalsIgnoreCase(planName) && !"SDAP20".equalsIgnoreCase(planName) && !"SDAPWD20".equalsIgnoreCase(planName)) {
			if (autoDeductionCheck.equals("S") && autoDeductionCheck != null) {
				displayCheckBoxInPDFforForm2table1cell12(page2Table1,
						buttonCheckImage, prop.getProperty("page2_para5_Q3"));
			} else {
				displayCheckBoxInPDFforForm2table1cell12(page2Table1,
						buttonUncheckImage, prop.getProperty("page2_para5_Q3"));
			}
		}

		PdfPTable outer = new PdfPTable(1);
		outer.setWidthPercentage(100);
		outer.addCell(page2Table1);
		return outer;

	}
	/**
	 * @param pdfUserDetails
	 * @param document
	 * @return
	 */
	private static void page1TableMedicareDetails(UserDetailsVO pdfUserDetails,
			Document document) {
		try {
			PdfPTable page1TableMedicarddetails = new PdfPTable(1);
			page1TableMedicarddetails.setSpacingBefore(15);
			page1TableMedicarddetails.setWidthPercentage(100);
			setHeader(page1TableMedicarddetails,
					"Please Provide Your Medicare Insurance Information:");
			PdfPTable page1TableMedicarddetaiils4 = new PdfPTable(2);
			page1TableMedicarddetaiils4.setSpacingBefore(5);
			page1TableMedicarddetaiils4.setWidthPercentage(85);

			PdfPTable page1TableMedicarddetailsCell22 = new PdfPTable(1);
			page1TableMedicarddetailsCell22.setWidthPercentage(85);
			page1TableMedicarddetailsCell22.addCell(Medicardlogo_Logo);

			PdfPCell page1TableMedicarddetailsCell22Name = new PdfPCell(
					new Phrase("Name:                                "
							+ (getChangedValue(pdfUserDetails
									.getNameBeneficiary())), font));
			page1TableMedicarddetailsCell22Name.setBorderWidthBottom(0.0001f);
			page1TableMedicarddetailsCell22Name.setBorder(Rectangle.NO_BORDER);

			page1TableMedicarddetailsCell22
					.addCell(page1TableMedicarddetailsCell22Name);

			PdfPCell page1TableMedicarddetailsCell22Claimnum = new PdfPCell(
					new Phrase(
							"Medicare Number : "
									+ (getChangedValue(pdfUserDetails
											.getMediacrdNumber()))
									+ " \t \t \t  \t       Sex : "
									+ (((getChangedValue(pdfUserDetails
											.getBeneficiarySex()))
											.equalsIgnoreCase("M") ? "Male"
											: "Female")), font));
			page1TableMedicarddetailsCell22Claimnum
					.setBorderWidthBottom(0.0001f);
			page1TableMedicarddetailsCell22Claimnum
					.setBorder(Rectangle.NO_BORDER);

			page1TableMedicarddetailsCell22
					.addCell(page1TableMedicarddetailsCell22Claimnum);

			PdfPCell page1TableMedicarddetailsCell22entitled = new PdfPCell(
					new Phrase("Is Entitled To              Effective Date",
							font));
			page1TableMedicarddetailsCell22entitled
					.setBorderWidthBottom(0.0001f);
			page1TableMedicarddetailsCell22entitled
					.setBorder(Rectangle.NO_BORDER);

			page1TableMedicarddetailsCell22
					.addCell(page1TableMedicarddetailsCell22entitled);

			PdfPCell page1TableMedicarddetailsCell22partA = new PdfPCell(
					new Phrase(
							"HOSPITAL           (PART A) : "
									+ (getChangedValue(pdfUserDetails
											.getHospitalDate())), font));
			page1TableMedicarddetailsCell22partA.setBorderWidthBottom(0.0001f);
			page1TableMedicarddetailsCell22partA.setBorder(Rectangle.NO_BORDER);

			page1TableMedicarddetailsCell22
					.addCell(page1TableMedicarddetailsCell22partA);

			PdfPCell page1TableMedicarddetailsCell22partB = new PdfPCell(
					new Phrase(
							"MEDICAL           (PART B) : "
									+ (getChangedValue(pdfUserDetails
											.getMedicalDate())), font));
			page1TableMedicarddetailsCell22partB.setBorderWidthBottom(0.0001f);
			page1TableMedicarddetailsCell22partB.setBorder(Rectangle.NO_BORDER);
			page1TableMedicarddetailsCell22
					.addCell(page1TableMedicarddetailsCell22partB);

			PdfPTable M3table1 = new PdfPTable(2);
			M3table1.setSpacingBefore(5);
			M3table1.setWidthPercentage(85);

			PdfPCell page1TableMedicarddetailscell21 = new PdfPCell(
					new Phrase(
							" Please take out your Medicare card to complete this section.\n\n   Please fill in these blanks so they match your red, white and blue Medicare card. \n\n -OR - \n\n   Attach a copy of your Medicare card or your letter from Social Security or the Railroad Retirement Board.\n\n You must have Medicare Part A and Part B to join a Medicare Advantage plan.",
							font));
			PdfPCell M3table1cell2 = new PdfPCell(
					page1TableMedicarddetailsCell22);
			page1TableMedicarddetailscell21
					.setHorizontalAlignment(Element.ALIGN_CENTER);
			page1TableMedicarddetailscell21
					.setHorizontalAlignment(Element.ALIGN_BOTTOM);
			page1TableMedicarddetaiils4
					.addCell(page1TableMedicarddetailscell21);
			page1TableMedicarddetaiils4.addCell(M3table1cell2);

			PdfPCell M3table1cell22 = new PdfPCell(page1TableMedicarddetaiils4);
			page1TableMedicarddetails.addCell(M3table1cell22);

			document.add(page1TableMedicarddetails);
		} catch (DocumentException exp) {
			//e.printStackTrace();
			LOGGER.error(" SharpPdfGen2020 : page1TableMedicareDetails : " + exp.getMessage());
		}

	}
	/**IFOX-00403984 Changes Start.*/
	/**
	 * @param pdfUserDetails
	 * @param document
	 * @return
	 */
	private static void page1TableNewMedicareDetails(UserDetailsVO pdfUserDetails,
			Document document,String planName) {
		try {
			PdfPTable page1TableMedicarddetails = new PdfPTable(1);
			page1TableMedicarddetails.setSpacingBefore(15);
			page1TableMedicarddetails.setWidthPercentage(100);
			setHeader(page1TableMedicarddetails,
					"Please Provide Your Medicare Insurance Information:");
			PdfPTable page1TableMedicarddetaiils4 = new PdfPTable(2);
			page1TableMedicarddetaiils4.setSpacingBefore(5);
			page1TableMedicarddetaiils4.setWidthPercentage(85);

			PdfPTable page1TableMedicarddetailsCell22 = new PdfPTable(1);
			//page1TableMedicarddetailsCell22.setWidthPercentage(85);
			//page1TableMedicarddetailsCell22.addCell(Medicardlogo_Logo);

			PdfPCell page1TableMedicarddetailsCell22Name = new PdfPCell(
					new Phrase("Name:                                "
							+ (getChangedValue(pdfUserDetails
									.getNameBeneficiary())), font));
			page1TableMedicarddetailsCell22Name.setBorderWidthBottom(0.0001f);
			page1TableMedicarddetailsCell22Name.setBorder(Rectangle.NO_BORDER);

			page1TableMedicarddetailsCell22
					.addCell(page1TableMedicarddetailsCell22Name);

			PdfPCell page1TableMedicarddetailsCell22Claimnum = new PdfPCell(
					new Phrase(
							"Medicare Number : "
									+ (getChangedValue(pdfUserDetails
											.getMediacrdNumber()))
									+ " \t \t \t  \t       Sex : "
									+ (((getChangedValue(pdfUserDetails
											.getBeneficiarySex()))
											.equalsIgnoreCase("M") ? "Male"
											: "Female")), font));
			page1TableMedicarddetailsCell22Claimnum
					.setBorderWidthBottom(0.0001f);
			page1TableMedicarddetailsCell22Claimnum
					.setBorder(Rectangle.NO_BORDER);

			page1TableMedicarddetailsCell22
					.addCell(page1TableMedicarddetailsCell22Claimnum);

			PdfPCell page1TableMedicarddetailsCell22entitled = new PdfPCell(
					new Phrase("Is Entitled To              Effective Date",
							font));
			page1TableMedicarddetailsCell22entitled
					.setBorderWidthBottom(0.0001f);
			page1TableMedicarddetailsCell22entitled
					.setBorder(Rectangle.NO_BORDER);

			page1TableMedicarddetailsCell22
					.addCell(page1TableMedicarddetailsCell22entitled);

			PdfPCell page1TableMedicarddetailsCell22partA = new PdfPCell(
					new Phrase(
							"HOSPITAL           (PART A) : "
									+ (getChangedValue(pdfUserDetails
											.getHospitalDate())), font));
			page1TableMedicarddetailsCell22partA.setBorderWidthBottom(0.0001f);
			page1TableMedicarddetailsCell22partA.setBorder(Rectangle.NO_BORDER);

			page1TableMedicarddetailsCell22
					.addCell(page1TableMedicarddetailsCell22partA);

			PdfPCell page1TableMedicarddetailsCell22partB = new PdfPCell(
					new Phrase(
							"MEDICAL           (PART B) : "
									+ (getChangedValue(pdfUserDetails
											.getMedicalDate())), font));
			page1TableMedicarddetailsCell22partB.setBorderWidthBottom(0.0001f);
			page1TableMedicarddetailsCell22partB.setBorder(Rectangle.NO_BORDER);
			page1TableMedicarddetailsCell22
					.addCell(page1TableMedicarddetailsCell22partB);

			PdfPTable M3table1 = new PdfPTable(2);
			M3table1.setSpacingBefore(5);
			M3table1.setWidthPercentage(85);

			PdfPCell page1TableMedicarddetailscell21 = new PdfPCell(
					new Phrase(
							" Please take out your Medicare card to complete this section.\n\n   Please fill in these blanks so they match your red, white and blue Medicare card. \n\n -OR - \n\n   Attach a copy of your Medicare card or your letter from Social Security or the Railroad Retirement Board.\n\n You must have Medicare Part A and Part B to join a Medicare Advantage plan.",
							font));
			PdfPCell M3table1cell2 = new PdfPCell(
					page1TableMedicarddetailsCell22);
			page1TableMedicarddetailscell21
					.setHorizontalAlignment(Element.ALIGN_CENTER);
			page1TableMedicarddetailscell21
					.setHorizontalAlignment(Element.ALIGN_BOTTOM);
			page1TableMedicarddetaiils4
					.addCell(page1TableMedicarddetailscell21);
			page1TableMedicarddetaiils4.addCell(M3table1cell2);

			PdfPCell M3table1cell22 = new PdfPCell(page1TableMedicarddetaiils4);
			page1TableMedicarddetails.addCell(M3table1cell22);

			document.add(page1TableMedicarddetails);
		} catch (DocumentException exp) {
			//e.printStackTrace();
			LOGGER.error(" SharpPdfGen2020 : page1TableMedicareDetails : " + exp.getMessage());
		}

	}
	/**IFOX-00403984 Changes Stop.*/

	/**
	 * @param pdfUserDetails
	 * @param document
	 * @return
	 * @return
	 * @throws DocumentException
	 */
	private static void page1TabbleUserDetails(UserDetailsVO pdfUserDetails,
			Document document) throws DocumentException, IOException {
		PdfPTable OuterTable = new PdfPTable(1);
		OuterTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		PdfPTable form1 = null;

		form1 = new PdfPTable(1);
		setHeader(form1,
				"To enroll in Sharp Health Plan please provide the following information:");
		OuterTable.addCell(form1);
		
		

		form1 = new PdfPTable(1);
		form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		form1.addCell(new Phrase(
				" Please check which plan you want to enroll in", font));
		OuterTable.addCell(form1);

		String planName = getChangedValue(pdfUserDetails.getOptimaMedicare());

		form1 = new PdfPTable(4);
		float[] columnWidths = { 6, 80, 6, 80 };
		form1.setWidths(columnWidths);
		form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		if (planName.equals("A")) {
			form1.addCell(buttonCheckImage);
			form1.addCell(new Phrase("Sharp Advantage Select ($0 per month) ",
					font));
			form1.addCell(buttonUncheckImage);
			form1.addCell(new Phrase(
					"Sharp Advantage Select Plus ($69 per month)", font));

		} else

		{

			form1.addCell(buttonUncheckImage);
			form1.addCell(new Phrase("Sharp Advantage Select ($0 per month) ",
					font));
			form1.addCell(buttonCheckImage);
			form1.addCell(new Phrase(
					"Sharp Advantage Select Plus ($69 per month)", font));
		}

		OuterTable.addCell(form1);


		form1 = new PdfPTable(8);
		form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		form1.addCell(new Phrase("Prefix : ", font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails.getSuffix()),
				font));
		form1.addCell(new Phrase("First Name : ", font));
		form1.addCell(new Phrase(
				getChangedValue(pdfUserDetails.getFirstName()), font));
		form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		form1.addCell(new Phrase("Last Name : ", font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails.getLastName()),
				font));
		form1.addCell(new Phrase("Middle Name : ", font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails
				.getMiddleInitial()), font));
		
		OuterTable.addCell(form1);

		form1 = new PdfPTable(8);
		form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		form1.addCell(new Phrase("Birth Date : ", font));
		form1.addCell(new Phrase(
				getChangedValue(pdfUserDetails.getBirthDate()), font));
		form1.addCell(new Phrase("Sex : ", font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails.getSex()), font));
		form1.addCell(new Phrase("Primary Phone Number : ", font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails
				.getHomePhNumber()), font));
		form1.addCell(new Phrase("Cell Phone Number : ", font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails
				.getAltrPhNumber()), font));
		OuterTable.addCell(form1);

		form1 = new PdfPTable(2);
		form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		form1.addCell(new Phrase(
				"Permanent Residence Street Address (P.O. Box is not allowed):	",
				font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails
				.getPermanentAddr()), font));

		OuterTable.addCell(form1);

		form1 = new PdfPTable(8);
		form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		form1.addCell(new Phrase("City : ", font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails
				.getPermanentCity()), font));
		form1.addCell(new Phrase("County : ", font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails
				.getPermanentCounty()), font));
		form1.addCell(new Phrase("State : ", font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails
				.getPermanentState()), font));
		form1.addCell(new Phrase("ZIP Code :	 ", font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails
				.getPermanentZip()), font));
		OuterTable.addCell(form1);

		form1 = new PdfPTable(2);
		form1.setWidths(new float[] { 5f, 4f });
		form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		form1.addCell(new Phrase(
				"Mailing Address (only if different from your Permanent Residence Address): ",
				font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails
				.getPermanentAddr()), font));

		OuterTable.addCell(form1);

		form1 = new PdfPTable(8);
		form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		form1.addCell(new Phrase("City : ", font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails
				.getMailingCity()), font));

		form1.addCell(new Phrase("State : ", font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails
				.getMailingState()), font));
		form1.addCell(new Phrase("ZIP Code :	 ", font));
		form1.addCell(new Phrase(
				getChangedValue(pdfUserDetails.getMailingZip()), font));
		form1.addCell(new Phrase("", font));
		form1.addCell(new Phrase("", font));
		OuterTable.addCell(form1);

		form1 = new PdfPTable(3);
		form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		form1.addCell(new Phrase(" Email Address : ", font));
		form1.addCell(new Phrase(
				getChangedValue(pdfUserDetails.getEmailAddr()), font));

		String healthPlnNewzInd = pdfUserDetails.getHealthPlnNewzInd();
		System.out.println("healthPlnNewzInd:"+healthPlnNewzInd);

		PdfPTable chkBox = new PdfPTable(2);
		chkBox.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		chkBox.setWidths(new int[] { 6, 100 });
		if (!"".equals(healthPlnNewzInd)) {
			chkBox.addCell(check);
			chkBox.addCell(new Phrase(
					" Yes,I'd like to receive health plan news and information via email.",
					font));
		} else {
			chkBox.addCell(uncheck);
			chkBox.addCell(new Phrase(
					" Yes,I'd like to receive health plan news and information via email.",
					font));

		}

		form1.addCell(chkBox);
		OuterTable.addCell(form1);

		PdfPTable main = new PdfPTable(1);
		main.setSpacingBefore(10);
		main.setWidthPercentage(100);
		main.getDefaultCell().setBorder(Rectangle.BOX);
		main.addCell(OuterTable);
		document.add(main);
		page1TableMedicareDetails(pdfUserDetails, document);

	}

	
	/**
	 * @param pdfUserDetails
	 * @param document
	 * @param currentplan
	 * @return
	 * @return
	 * @throws DocumentException
	 */
	@SuppressWarnings("unused")
	
	//Begin: Modified for IFOX-00414491
	//private static void page1TabbleUserDetails(UserDetailsVO pdfUserDetails, 
	//		Document document, String currentPlan) throws DocumentException, IOException {
	private static void page1TabbleUserDetails(UserDetailsVO pdfUserDetails, EnrollmentVO enrollmentVO,
				Document document, String currentPlan) throws DocumentException, IOException {	
	//End: Modified for IFOX-00414491
		
		PdfPTable OuterTable = new PdfPTable(1);
		OuterTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		PdfPTable form1 = null;

		form1 = new PdfPTable(1);
		setHeader(form1,
				"To enroll in Sharp Health Plan please provide the following information:");
		OuterTable.addCell(form1);
		
		
		
		if("SAMEA".equalsIgnoreCase(currentPlan) || "SDAMEA".equalsIgnoreCase(currentPlan)){

			form1 = new PdfPTable(1);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase(
					" Employer or Union Name: City of San Diego Medicare Retirees", font));
			
			OuterTable.addCell(form1);
			
			form1 = new PdfPTable(1);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase(" I would like to enroll in the following plan.\n", font));
			OuterTable.addCell(form1);

			form1 = new PdfPTable(3);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			float[] columnWidths = { 6, 40, 40 };
			form1.setWidths(columnWidths);
			form1.addCell(buttonCheckImage);
			form1.addCell(new Phrase("Sharp Advantage MEA ($179 per month) \n (81004) ", font));
			
			form1.addCell(new Phrase(" This plan is for Medicare enrolled retirees only. If you are not eligible for Medicare, please contact MEA for the " +
			"Non-Medicare Enrollment Form at 1-855-820-2112 or visit www.SDMEA.org to download the enrollment form.", font));			
			
			OuterTable.addCell(form1);

		}/**IFOX-00403984 Changes Start.*/
		else if("SDAHMO".equalsIgnoreCase(currentPlan) || "SDAHMO1".equalsIgnoreCase(currentPlan) ){ //Modified for IFOX-00414491
			
			//Begin: Added for IFOX-00414491
			String radioButtonFlagForQues2 = null;
			String radioButtonFlagForQues3 = null;
			String radioButtonFlagForQues5 = null;
			
			String phrase = "Are you the City of San Diego retiree ? ";
			String radioButtonFlagForQues1 = getChangedValue(enrollmentVO.getRetiree());
			
			if(radioButtonFlagForQues1 == null || radioButtonFlagForQues1.trim().equals("")) {
				displayButtonInPDFforForm2table2cellA(OuterTable, buttonUncheckImage, buttonUncheckImage,phrase);
			} else {
				if(radioButtonFlagForQues1.equalsIgnoreCase("Y")) {
					displayButtonInPDFforForm2table2cellA(OuterTable, buttonCheckImage, buttonUncheckImage,phrase);
				} else {
					if(radioButtonFlagForQues1.equalsIgnoreCase("N")) {
						displayButtonInPDFforForm2table2cellA(OuterTable, buttonUncheckImage, buttonCheckImage,phrase);
					}
				}
			}
			if(radioButtonFlagForQues1 != null && radioButtonFlagForQues1.equalsIgnoreCase("N")) {
				String phrase1 = "If you are not, are you the surviving spouse of a City of San Diego Retiree ? ";
				radioButtonFlagForQues3 = getChangedValue(enrollmentVO.getSurvivingSpouseCitySanDiegoRetiree());
				
				if(radioButtonFlagForQues3 == null || radioButtonFlagForQues3.trim().equals("")){
					displayButtonInPDFforForm2table2cellC(OuterTable, buttonUncheckImage, buttonUncheckImage,phrase1);
				} else {
					if(radioButtonFlagForQues3.equalsIgnoreCase("Y")) {
						displayButtonInPDFforForm2table2cellC(OuterTable, buttonCheckImage, buttonUncheckImage,phrase1);
					} else {
						if(radioButtonFlagForQues3.equalsIgnoreCase("N")){
							displayButtonInPDFforForm2table2cellC(OuterTable, buttonUncheckImage, buttonCheckImage,phrase1);
						}
					}
				}
			}
			if(radioButtonFlagForQues3 != null && radioButtonFlagForQues3.equalsIgnoreCase("Y")) {
				form1 = new PdfPTable(6);
				form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				form1.setWidths(new int[] { 33, 25, 35, 25, 48, 55 });
				form1.addCell(new Phrase(" Retiree Last Name: ", font));
				form1.addCell(new Phrase(enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeLastName(), font));
				form1.addCell(new Phrase(" Retiree First Name: ", font));
				form1.addCell(new Phrase(enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeFirstName(), font));
				form1.addCell(new Phrase(" Retiree Middle Name: ", font));
				form1.addCell(new Phrase(enrollmentVO.getSurvivingSpouseCitySanDiegoRetireeMiddleName(), font));
				OuterTable.addCell(form1);
			}
			
			if(radioButtonFlagForQues1 != null && radioButtonFlagForQues1.equalsIgnoreCase("Y"))
			{
				String phrase1 = "If yes, Are you covering a spouse or dependent ? ";
				radioButtonFlagForQues2 = getChangedValue(enrollmentVO.getCoveringSpouseOrDependent());
				
				if(null == radioButtonFlagForQues2 || radioButtonFlagForQues2.trim().equals("")) {
					displayButtonInPDFforForm2table2cellB(OuterTable, buttonUncheckImage, buttonUncheckImage,phrase1);
				} else {
					if(radioButtonFlagForQues2.equalsIgnoreCase("Y")) {
						displayButtonInPDFforForm2table2cellB(OuterTable, buttonCheckImage, buttonUncheckImage,phrase1);
					}else if(radioButtonFlagForQues2.equalsIgnoreCase("N")){
						displayButtonInPDFforForm2table2cellB(OuterTable, buttonUncheckImage, buttonCheckImage,phrase1);
					}
				}
			}
			
			if(radioButtonFlagForQues1 != null && radioButtonFlagForQues2 != null)
			{
				if(radioButtonFlagForQues2.equalsIgnoreCase("Y")) {
					form1 = new PdfPTable(1);
					form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
					form1.addCell(new Phrase(" Dependent of City of San Diego Retiree: ", font));
					OuterTable.addCell(form1);
					
					form1 = new PdfPTable(6);
					form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
					form1.setWidths(new int[] { 13, 25, 13, 25, 15, 55 });
					form1.addCell(new Phrase(" Last Name: ", font));
					form1.addCell(new Phrase(enrollmentVO.getCoveringSpouseOrDependentLastName(), font));
					form1.addCell(new Phrase(" First Name: ", font));
					form1.addCell(new Phrase(enrollmentVO.getCoveringSpouseOrDependentFirstName(), font));
					form1.addCell(new Phrase(" Middle Name: ", font));
					form1.addCell(new Phrase(enrollmentVO.getCoveringSpouseOrDependentMiddleName(), font));
					OuterTable.addCell(form1);
				} else {
					if(radioButtonFlagForQues2.equalsIgnoreCase("N")) {
						form1 = new PdfPTable(2);
						form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						form1.setWidths(new int[] { 40, 60 });
						form1.addCell(new Phrase(" If you are not, employee name: ", font));
						form1.addCell(new Phrase(enrollmentVO.getCoveringSpouseOrDependentEmployeeName(), font));
						OuterTable.addCell(form1);
					}
				}
			}
			//End: Added for IFOX-00414491
			
			form1 = new PdfPTable(1);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase(
					"Effective Date of Coverage: "+getChangedValue(pdfUserDetails.getEffDate()), font));
			OuterTable.addCell(form1);
			
			form1 = new PdfPTable(1);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase(
					"Employer or Union Name: San Diego Public Employee Benefit Association (SDPEBA)", font));
			
			OuterTable.addCell(form1);
			
			//Begin: Modified for IFOX-00414491
			form1 = new PdfPTable(1);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("I would like to enroll in the following plan.\n", font));
			OuterTable.addCell(form1);

			String phrase1 = "";
			displayButtonInPDFforForm2table2cellD(OuterTable, buttonUncheckImage, buttonCheckImage,phrase1, currentPlan);

			form1 = new PdfPTable(1);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("This plan is for Medicare enrolled retirees only. If you are "
					+ "not eligible for Medicare, please contact SDPEBA for the Non-Medicare Enrollment "
					+ "Form at 1-888-315-8027 or visit www.sdpeba.org to download the enrollment form.\n", font));
			OuterTable.addCell(form1);
			//End: Modified for IFOX-00414491
			
		}/**IFOX-00403984 Changes Stop.*/
		else if("SAB".equalsIgnoreCase(currentPlan) || "SAP".equalsIgnoreCase(currentPlan)){
			
			form1 = new PdfPTable(2);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase(
					" Employer or Union Name: Sharp HealthCare Former Employees", font));
			form1.addCell(new Phrase(
					" Group#: 1002010", font));
			
			OuterTable.addCell(form1);

			form1 = new PdfPTable(1);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase(
					" I would like to enroll in the following plan.\n", font));
			OuterTable.addCell(form1);			
			
			if("SAB".equalsIgnoreCase(currentPlan)){
			
				form1 = new PdfPTable(4);
				form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				float[] columnWidths = { 6, 80, 6, 80 };
				form1.setWidths(columnWidths);
				form1.addCell(buttonCheckImage);
				form1.addCell(new Phrase("Sharp Advantage Basic ($0 per month) ", font));
	
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase("Sharp Advantage Premium ($54 per month) ", font));
			
				OuterTable.addCell(form1);
				
			}else{
				form1 = new PdfPTable(4);
				form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				float[] columnWidths = { 6, 80, 6, 80 };
				form1.setWidths(columnWidths);
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase("Sharp Advantage Basic ($0 per month) ", font));

				form1.addCell(buttonCheckImage);
				form1.addCell(new Phrase("Sharp Advantage Premium ($54 per month) ", font));
			
				OuterTable.addCell(form1);				
				
			}
			
/*			String planName = getChangedValue(pdfUserDetails.getOptimaMedicare());
	
			form1 = new PdfPTable(4);
			form1.setWidths(columnWidths);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	
			if (planName.equals("A")) {
				form1.addCell(buttonCheckImage);
				form1.addCell(new Phrase("Sharp Advantage Select ($0 per month) ",
						font));
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase(
						"Sharp Advantage Select Plus ($69 per month)", font));
	
			} else{
	
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase("Sharp Advantage Select ($0 per month) ",
						font));
				form1.addCell(buttonCheckImage);
				form1.addCell(new Phrase(
						"Sharp Advantage Select Plus ($69 per month)", font));
			}
	
			OuterTable.addCell(form1);		*/	
		}else if("SAS".equalsIgnoreCase(currentPlan) || "SASP".equalsIgnoreCase(currentPlan)){
			
		
			form1 = new PdfPTable(1);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase(" I would like to enroll in the following plan.\n", font));
			OuterTable.addCell(form1);			
			
			if("SAS".equalsIgnoreCase(currentPlan)){
			
				form1 = new PdfPTable(4);
				form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				float[] columnWidths = { 6, 80, 6, 80 };
				form1.setWidths(columnWidths);
				form1.addCell(buttonCheckImage);
				form1.addCell(new Phrase("Sharp Advantage Select ($0 per month) ",
						font));
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase(
						"Sharp Advantage Select Plus ($69 per month)", font));
			
				OuterTable.addCell(form1);
			}else{
				form1 = new PdfPTable(4);
				form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				float[] columnWidths = { 6, 80, 6, 80 };
				form1.setWidths(columnWidths);
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase("Sharp Advantage Select ($0 per month) ",
						font));
				form1.addCell(buttonCheckImage);
				form1.addCell(new Phrase(
						"Sharp Advantage Select Plus ($69 per month)", font));
			
				OuterTable.addCell(form1);				
				
			}
			
/*			String planName = getChangedValue(pdfUserDetails.getOptimaMedicare());
	
			form1 = new PdfPTable(4);
			form1.setWidths(columnWidths);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	
			if (planName.equals("A")) {
				form1.addCell(buttonCheckImage);
				form1.addCell(new Phrase("Sharp Advantage Select ($0 per month) ",
						font));
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase(
						"Sharp Advantage Select Plus ($69 per month)", font));
	
			} else{
	
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase("Sharp Advantage Select ($0 per month) ",
						font));
				form1.addCell(buttonCheckImage);
				form1.addCell(new Phrase(
						"Sharp Advantage Select Plus ($69 per month)", font));
			}
	
			OuterTable.addCell(form1);		*/	
			

			/*IFOX-00418144 2020 AEP Plan Changes. START*/	
		} else if("SDAGC".equalsIgnoreCase(currentPlan) || "SDAPC".equalsIgnoreCase(currentPlan) || "SDAGCWD".equalsIgnoreCase(currentPlan)
				|| "SDAGC20".equalsIgnoreCase(currentPlan) || "SDAPC20".equalsIgnoreCase(currentPlan) || "SDAGCWD20".equalsIgnoreCase(currentPlan)){
			
			form1 = new PdfPTable(1);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase(" I would like to enroll in the following plan.\n", font));
			OuterTable.addCell(form1);			
			
			if("SDAGC".equalsIgnoreCase(currentPlan)){//Fix for IFOX-00420776
				
				form1 = new PdfPTable(4);
				form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				float[] columnWidths = { 4, 50, 4, 50  };
				form1.setWidths(columnWidths);
				form1.addCell(buttonCheckImage);
				form1.addCell(new Phrase("Sharp Direct Advantage Gold Card ($0 per month) ",
						font));
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase(
						"Sharp Direct Advantage Gold Card with Dental($11 per month)", font));				
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase(
						"Sharp Direct Advantage Platinum Card with Dental ($66 per month)", font));
			
				OuterTable.addCell(form1);
			}else if("SDAGCWD".equalsIgnoreCase(currentPlan)){//Fix for IFOX-00420776
				form1 = new PdfPTable(4);
				form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				float[] columnWidths = { 4, 50, 4, 50 };
				form1.setWidths(columnWidths);

				form1.addCell(buttonCheckImage);
				form1.addCell(new Phrase(
						"Sharp Direct Advantage Gold Card with Dental ($11 per month)", font));						
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase(
						"Sharp Direct Advantage Platinum Card with Dental ($66 per month)", font));
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase("Sharp Direct Advantage Gold Card ($0 per month) ",
						font));				
				OuterTable.addCell(form1);				
				//Fix for IFOX-00420776 - Start
			}else if("SDAGC20".equalsIgnoreCase(currentPlan)){
				form1 = new PdfPTable(4);
				form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				float[] columnWidths = { 4, 50, 4, 50 };
				form1.setWidths(columnWidths);

				form1.addCell(buttonCheckImage);
				form1.addCell(new Phrase("Sharp Direct Advantage Gold Card ($0 per month) ",font));	
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase(
						"Sharp Direct Advantage Gold Card with Dental ($12 per month)", font));						
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase(
						"Sharp Direct Advantage Platinum Card with Dental ($57 per month)", font));
				OuterTable.addCell(form1);				
				
			}else if("SDAGCWD20".equalsIgnoreCase(currentPlan)){
				form1 = new PdfPTable(4);
				form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				float[] columnWidths = { 4, 50, 4, 50 };
				form1.setWidths(columnWidths);

				form1.addCell(buttonCheckImage);
				form1.addCell(new Phrase(
						"Sharp Direct Advantage Gold Card with Dental ($12 per month)", font));						
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase(
						"Sharp Direct Advantage Platinum Card with Dental ($57 per month)", font));
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase("Sharp Direct Advantage Gold Card ($0 per month) ",
						font));				
				OuterTable.addCell(form1);				
				
			}else if("SDAPC20".equalsIgnoreCase(currentPlan)){
				form1 = new PdfPTable(4);
				form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				float[] columnWidths = { 4, 50, 4, 50 };
				form1.setWidths(columnWidths);

				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase(
						"Sharp Direct Advantage Gold Card with Dental ($12 per month)", font));						
				form1.addCell(buttonCheckImage);
				form1.addCell(new Phrase(
						"Sharp Direct Advantage Platinum Card with Dental ($57 per month)", font));
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase("Sharp Direct Advantage Gold Card ($0 per month) ",
						font));				
				OuterTable.addCell(form1);				
				//Fix for IFOX-00420776 - End
			}else{
				form1 = new PdfPTable(4);
				form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				float[] columnWidths = { 4, 50, 4, 50 };
				form1.setWidths(columnWidths);
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase(
						"Sharp Direct Advantage Gold Card with Dental ($11 per month)", font));							
				form1.addCell(buttonCheckImage);
				form1.addCell(new Phrase(
						"Sharp Direct Advantage Platinum Card with Dental ($66 per month)", font));
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase("Sharp Direct Advantage Gold Card ($0 per month) ",
						font));				
				OuterTable.addCell(form1);				
				
			}			
			/*IFOX-00418144 2020 AEP Plan Changes. END*/
		} else if("SDAB".equalsIgnoreCase(currentPlan) || "SDAP".equalsIgnoreCase(currentPlan) || "SDABWD".equalsIgnoreCase(currentPlan) || "SDAPWD".equalsIgnoreCase(currentPlan) || "SDAB20".equalsIgnoreCase(currentPlan) || "SDAP20".equalsIgnoreCase(currentPlan) || "SDABWD20".equalsIgnoreCase(currentPlan) || "SDAPWD20".equalsIgnoreCase(currentPlan)){
			
			form1 = new PdfPTable(1);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase(
					" I would like to enroll in the following plan.\n", font));
			OuterTable.addCell(form1);			
			
			
			if("SDAB".equalsIgnoreCase(currentPlan)){
				form1 = new PdfPTable(4);
				form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				float[] columnWidths = { 4, 50, 4, 50 };
				form1.setWidths(columnWidths);
				form1.addCell(buttonCheckImage);
				form1.addCell(new Phrase("Sharp Direct Advantage Basic ($0 per month) ", font));
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase("Sharp Direct Advantage Premium ($59 per month) ", font));
				OuterTable.addCell(form1);
			}else if("SDABWD".equalsIgnoreCase(currentPlan)){
				form1 = new PdfPTable(4);
				form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				float[] columnWidths = {4, 50, 4, 50 };
				form1.setWidths(columnWidths);
				form1.addCell(buttonCheckImage);
				form1.addCell(new Phrase("Sharp Direct Advantage Basic with Dental ($11 per month) ", font));
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase("Sharp Direct Advantage Premium with Dental ($70 per month) ", font));
				OuterTable.addCell(form1);
				
			}else if("SDAP".equalsIgnoreCase(currentPlan)){
				form1 = new PdfPTable(4);
				form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				float[] columnWidths = {4, 50, 4, 50 };
				form1.setWidths(columnWidths);
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase("Sharp Direct Advantage Basic ($0 per month) ", font));
				form1.addCell(buttonCheckImage);
				form1.addCell(new Phrase("Sharp Direct Advantage Premium ($59 per month) ", font));
				OuterTable.addCell(form1);
			}else if("SDAPWD".equalsIgnoreCase(currentPlan)){
				form1 = new PdfPTable(4);
				form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				float[] columnWidths = {4, 50, 4, 50 };
				form1.setWidths(columnWidths);
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase("Sharp Direct Advantage Basic with Dental ($11 per month) ", font));
				form1.addCell(buttonCheckImage);
				form1.addCell(new Phrase("Sharp Direct Advantage Premium with Dental ($70 per month) ", font));
				OuterTable.addCell(form1);
				//Fix for IFOX-00420776 - Start
			}else if("SDAB20".equalsIgnoreCase(currentPlan)){
				form1 = new PdfPTable(4);
				form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				float[] columnWidths = { 4, 50, 4, 50 };
				form1.setWidths(columnWidths);
				form1.addCell(buttonCheckImage);
				form1.addCell(new Phrase("Sharp Direct Advantage Basic ($0 per month) ", font));
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase("Sharp Direct Advantage Premium ($62 per month) ", font));
				OuterTable.addCell(form1);
			}else if("SDABWD20".equalsIgnoreCase(currentPlan)){
				form1 = new PdfPTable(4);
				form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				float[] columnWidths = {4, 50, 4, 50 };
				form1.setWidths(columnWidths);
				form1.addCell(buttonCheckImage);
				form1.addCell(new Phrase("Sharp Direct Advantage Basic with Dental ($12 per month) ", font));
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase("Sharp Direct Advantage Premium with Dental ($74 per month) ", font));
				OuterTable.addCell(form1);
				
			}else if("SDAP20".equalsIgnoreCase(currentPlan)){
				form1 = new PdfPTable(4);
				form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				float[] columnWidths = {4, 50, 4, 50 };
				form1.setWidths(columnWidths);
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase("Sharp Direct Advantage Basic ($0 per month) ", font));
				form1.addCell(buttonCheckImage);
				form1.addCell(new Phrase("Sharp Direct Advantage Premium ($62 per month) ", font));
				OuterTable.addCell(form1);
			}else if("SDAPWD20".equalsIgnoreCase(currentPlan)){
				form1 = new PdfPTable(4);
				form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				float[] columnWidths = {4, 50, 4, 50 };
				form1.setWidths(columnWidths);
				form1.addCell(buttonUncheckImage);
				form1.addCell(new Phrase("Sharp Direct Advantage Basic with Dental ($12 per month) ", font));
				form1.addCell(buttonCheckImage);
				form1.addCell(new Phrase("Sharp Direct Advantage Premium with Dental ($74 per month) ", font));
				OuterTable.addCell(form1);
				//Fix for IFOX-00420776 - End
		}
			
		}
		//Added below if statement to fix Errors on Individual pdfs
		if("SDAB".equalsIgnoreCase(currentPlan) || "SDAP".equalsIgnoreCase(currentPlan) || "SDABWD".equalsIgnoreCase(currentPlan) || "SDAPWD".equalsIgnoreCase(currentPlan) || "SDAB20".equalsIgnoreCase(currentPlan) || "SDAP20".equalsIgnoreCase(currentPlan) || "SDABWD20".equalsIgnoreCase(currentPlan) || "SDAPWD20".equalsIgnoreCase(currentPlan)){
			form1 = new PdfPTable(8);
			form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			form1.addCell(new Phrase("SSN : ", font));
			form1.addCell(new Phrase(getChangedValue(maskSSN(pdfUserDetails.getSsn())),
					font));
			form1.addCell("");
			form1.addCell("");
			form1.addCell("");
			form1.addCell("");
			form1.addCell("");
			form1.addCell("");
			OuterTable.addCell(form1);
		}

		form1 = new PdfPTable(8);
		form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		form1.addCell(new Phrase("Prefix : ", font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails.getSuffix()),
				font));
		form1.addCell(new Phrase("First name : ", font));
		form1.addCell(new Phrase(
				getChangedValue(pdfUserDetails.getFirstName()), font));
		form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		form1.addCell(new Phrase("Last name : ", font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails.getLastName()),
				font));
		form1.addCell(new Phrase("Middle name : ", font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails
				.getMiddleInitial()), font));
		
		OuterTable.addCell(form1);

		form1 = new PdfPTable(8);
		form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		form1.addCell(new Phrase("Birth Date : ", font));
		form1.addCell(new Phrase(
				getChangedValue(pdfUserDetails.getBirthDate()), font));
		form1.addCell(new Phrase("Sex : ", font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails.getSex()), font));
		form1.addCell(new Phrase("Primary Phone Number : ", font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails
				.getHomePhNumber()), font));
		form1.addCell(new Phrase("Cell Phone Number : ", font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails
				.getAltrPhNumber()), font));
		OuterTable.addCell(form1);

		form1 = new PdfPTable(2);
		form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		form1.addCell(new Phrase(
				"Permanent Residence Street Address (P.O. Box is not allowed):	",
				font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails
				.getPermanentAddr()), font));

		OuterTable.addCell(form1);

		form1 = new PdfPTable(8);
		form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		form1.addCell(new Phrase("City : ", font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails
				.getPermanentCity()), font));
		form1.addCell(new Phrase("County : ", font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails
				.getPermanentCounty()), font));
		form1.addCell(new Phrase("State : ", font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails
				.getPermanentState()), font));
		form1.addCell(new Phrase("ZIP Code :	 ", font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails
				.getPermanentZip()), font));
		OuterTable.addCell(form1);

		form1 = new PdfPTable(2);
		form1.setWidths(new float[] { 5f, 4f });
		form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		form1.addCell(new Phrase(
				"Mailing Address (only if different from your Permanent Residence Address): ",
				font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails
				.getPermanentAddr()), font));

		OuterTable.addCell(form1);

		form1 = new PdfPTable(8);
		form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		form1.addCell(new Phrase("City : ", font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails
				.getMailingCity()), font));

		form1.addCell(new Phrase("State : ", font));
		form1.addCell(new Phrase(getChangedValue(pdfUserDetails
				.getMailingState()), font));
		form1.addCell(new Phrase("ZIP Code :	 ", font));
		form1.addCell(new Phrase(
				getChangedValue(pdfUserDetails.getMailingZip()), font));
		form1.addCell(new Phrase("", font));
		form1.addCell(new Phrase("", font));
		OuterTable.addCell(form1);

		form1 = new PdfPTable(3);
		form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		form1.addCell(new Phrase(" Email Address : ", font));
		form1.addCell(new Phrase(
				getChangedValue(pdfUserDetails.getEmailAddr()), font));

		String healthPlnNewzInd = pdfUserDetails.getHealthPlnNewzInd();

		PdfPTable chkBox = new PdfPTable(2);
		chkBox.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		chkBox.setWidths(new int[] { 6, 100 });
		if ("" != healthPlnNewzInd) {
			chkBox.addCell(check);
			chkBox.addCell(new Phrase(
					" Yes,I'd like to receive health plan news and information via email.",
					font));
		} else {
			chkBox.addCell(uncheck);
			chkBox.addCell(new Phrase(
					" Yes,I'd like to receive health plan news and information via email.",
					font));

		}

		form1.addCell(chkBox);
		OuterTable.addCell(form1);

		PdfPTable main = new PdfPTable(1);
		main.setSpacingBefore(10);
		main.setWidthPercentage(100);
		main.getDefaultCell().setBorder(Rectangle.BOX);
		main.addCell(OuterTable);
		document.add(main);
		/**IFOX-00403984 Changes Start.*/
		if("SDAHMO".equalsIgnoreCase(currentPlan) || "SDAHMO1".equalsIgnoreCase(currentPlan) ){ //Modified for IFOX-00414491
			page1TableNewMedicareDetails(pdfUserDetails, document,currentPlan);
		}/**IFOX-00403984 Changes Stop.*/
		else{
			page1TableMedicareDetails(pdfUserDetails, document);
		}
		

	}
	
	/**
	 * @param request
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void pdffontInstances(HttpServletRequest request)
			throws DocumentException, IOException {
		System.out.println("in pdffontInstances start ");
		ServletContext context = request.getSession().getServletContext();
		String absoluteDiskPathOfArialfont = context
				.getRealPath(WebappConstant.RELATIVEWEBPATHOFARIALFONT);
		base = BaseFont.createFont(absoluteDiskPathOfArialfont,
				BaseFont.WINANSI, false);
		font = new Font(base, 8, Font.NORMAL, java.awt.Color.BLACK);
		font2 = new Font(base, 9, Font.BOLD, java.awt.Color.BLACK);
		headerColor = WebColors.getRGBColor("#344C66");
		System.out.println("in pdffontInstances exit.. ");
	}

	/**
	 * @param request
	 * @throws MalformedURLException
	 * @throws IOException
	 * @throws DocumentException
	 */
	private static void pdfImageInstances(HttpServletRequest request)
			throws MalformedURLException, IOException, DocumentException {

		System.out.println("in pdfImageInstances method..");
		ServletContext context = request.getSession().getServletContext();

		String absoluteDiskPathOfMedicard_logo = context
				.getRealPath(WebappConstant.RELATIVEWEBPATHOFMEDICARDLOGO);

		String absoluteDiskPathOfSampleCheckImage = context
				.getRealPath(WebappConstant.RELATIVEWEBPATHOFSAMPLECHECKIMAGE);

		String absoluteDiskPathOfCheckImage = context
				.getRealPath(WebappConstant.RELATIVEWEBPATHOFCHECKIMAGE);

		String absoluteDiskPathOfUncheckImage = context
				.getRealPath(WebappConstant.RELATIVEWEBPATHOFUNCHECKIMAGE);

		String absoluteDiskPathOfbuttoncheckImage = context
				.getRealPath(WebappConstant.RELATIVEWEBPATHOFBUTTONCHECKIMAGE);

		String absoluteDiskPathOfbuttonUncheckImage = context
				.getRealPath(WebappConstant.RELATIVEWEBPATHOFBUTTONUNCHECKIMAGE);

		String absoluteDiskPathOfStopImage = context
				.getRealPath(WebappConstant.RELATIVEWEBPATHOFSTOPIMAGE);

		String absoluteDiskPathOfSummacare_logo = context
				.getRealPath(WebappConstant.SHARPLOGO);

		String absoluteDiskPathOfTickImage = context
				.getRealPath(WebappConstant.RELATIVEWEBPATHOFTICKIMAGE);

		sharpLogo = Image.getInstance(absoluteDiskPathOfSummacare_logo);
		sharpLogo.scaleToFit(150f, 150f);

		Medicardlogo_Logo = Image.getInstance(absoluteDiskPathOfMedicard_logo);
		Medicardlogo_Logo.scaleToFit(100f, 100f);

		sampleCheck = Image.getInstance(absoluteDiskPathOfSampleCheckImage);
		tick = Image.getInstance(absoluteDiskPathOfTickImage);
		buttonCheckImage = Image
				.getInstance(absoluteDiskPathOfbuttoncheckImage);
		buttonCheckImage.scaleToFit(5f, 5f);
		buttonUncheckImage = Image
				.getInstance(absoluteDiskPathOfbuttonUncheckImage);
		buttonCheckImage.scaleToFit(5f, 5f);

		check = Image.getInstance(absoluteDiskPathOfCheckImage);

		uncheck = Image.getInstance(absoluteDiskPathOfUncheckImage);

		stop = Image.getInstance(absoluteDiskPathOfStopImage);
		stop.scaleToFit(30f, 30f);

		System.out.println("in pdfImageInstances method.exit.");
	}

	/**
	 * @param optimaHealth_Logo
	 * @return
	 */
	private static PdfPTable page1LogoTable(Image sharpLogo) {

		PdfPTable logo = new PdfPTable(1);
		logo.setSpacingBefore(10);
		logo.setWidthPercentage(100);
		logo.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPCell logocell1 = new PdfPCell(sharpLogo);
		logocell1.setHorizontalAlignment(Element.ALIGN_LEFT);
		logocell1.setBorder(Rectangle.NO_BORDER);

		logo.addCell(logocell1);

		return logo;
	}

	private static void mainHeading(Document document) throws DocumentException {

		PdfPTable Braille2 = new PdfPTable(1);
		Braille2.setSpacingBefore(15);
		Braille2.setWidthPercentage(100);
		Braille2.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPCell Braillcell12 = new PdfPCell(
				new Phrase(
						"Please contact Sharp Health Plan if you need information in another language or format",
						FontFactory.getFont(FontFactory.HELVETICA, 10,
								Font.BOLD, java.awt.Color.WHITE)));
		Braillcell12.setHorizontalAlignment(Element.ALIGN_CENTER);
		Braillcell12.setBackgroundColor(WebColors.getRGBColor("#F2B50F"));
		Braillcell12.setBorder(Rectangle.NO_BORDER);
		Braille2.addCell(Braillcell12);
		document.add(Braille2);

	}


	private static void mainHeading(Document document, String planName) throws DocumentException {

		if("SAMEA".equalsIgnoreCase(planName) || "SDAMEA".equalsIgnoreCase(planName)) {
			PdfPTable Braille2 = new PdfPTable(1);
			Braille2.setSpacingBefore(15);
			Braille2.setWidthPercentage(100);
			Braille2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	
			PdfPCell Braillcell12 = new PdfPCell(
					new Phrase(
							"This plan is open to all Medicare-eligible City San Diego retirees, sponsored by MEA. MEA membership is not required to join this plan. Please contact Sharp Health Plan at 1-855-820-2112 (TTY/TDD 711) if you need information in another language or format",
							FontFactory.getFont(FontFactory.HELVETICA, 10,
									Font.BOLD, java.awt.Color.WHITE)));
			Braillcell12.setHorizontalAlignment(Element.ALIGN_CENTER);
			Braillcell12.setBackgroundColor(WebColors.getRGBColor("#F2B50F"));
			Braillcell12.setBorder(Rectangle.NO_BORDER);
			Braille2.addCell(Braillcell12);
			document.add(Braille2);
		}/**IFOX-00403984 Changes Start.*/
		else if("SDAHMO".equalsIgnoreCase(planName) || "SDAHMO1".equalsIgnoreCase(planName) ) { //Modified for IFOX-00414491
			PdfPTable Braille2 = new PdfPTable(1);
			Braille2.setSpacingBefore(15);
			Braille2.setWidthPercentage(100);
			Braille2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	
			PdfPCell Braillcell12 = new PdfPCell(
					new Phrase("This plan is open to all Medicare-eligible City of San Diego retirees, "
							+ "sponsored by San Diego Public Employee Benefit Association (SDPEBA). "
							+ "SDPEBA membership is not required to join this plan. Please contact "
							+ "Sharp Health Plan at\n 1-855-562-8853 (TTY/TDD 711) if you need information "
							+ "in another language or format.",
							FontFactory.getFont(FontFactory.HELVETICA, 10,
									Font.BOLD, java.awt.Color.WHITE)));
			Braillcell12.setHorizontalAlignment(Element.ALIGN_CENTER);
			Braillcell12.setBackgroundColor(WebColors.getRGBColor("#F2B50F"));
			Braillcell12.setBorder(Rectangle.NO_BORDER);
			Braille2.addCell(Braillcell12);
			document.add(Braille2);
		}/**IFOX-00403984 Changes Stop.*/
	}

	
	
	private static void checkBox(PdfPTable page2Table1, Image check1,
			String propValue, String dateValue) throws DocumentException,
			IOException {

		PdfPTable page2table1cell8check_table2 = new PdfPTable(2);
		page2table1cell8check_table2.getDefaultCell().setBorder(
				Rectangle.NO_BORDER);
		page2table1cell8check_table2.setWidths(new int[] { 2, 80 });
		page2table1cell8check_table2.addCell(check1);
		page2table1cell8check_table2.addCell(new Phrase(propValue + dateValue,
				font));
		PdfPCell page2table1cell8 = new PdfPCell(page2table1cell8check_table2);
		page2table1cell8.setBorder(Rectangle.NO_BORDER);
		page2table1cell8.setPadding(5);
		page2table1cell8.setLeading(0f, 1.5f);
		page2Table1.addCell(page2table1cell8);

	}

	/**
	 * @param page2Table1
	 * @param check1
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void displayCheckBoxInPDFforForm2table1cell9(
			PdfPTable page2Table1, Image check1, String property)
			throws DocumentException, IOException {

		PdfPTable page2table1cell9check_table2 = new PdfPTable(2);
		page2table1cell9check_table2.getDefaultCell().setBorder(
				Rectangle.NO_BORDER);
		page2table1cell9check_table2.setWidths(new int[] { 2, 80 });
		page2table1cell9check_table2.addCell(check1);
		page2table1cell9check_table2.addCell(new Phrase(property, font));
		page2table1cell9check_table2
				.setHorizontalAlignment(Element.ALIGN_JUSTIFIED);
		PdfPCell page2table1cell9 = new PdfPCell(page2table1cell9check_table2);
		page2table1cell9.setBorder(0);
		page2table1cell9.setPadding(5);
		page2table1cell9.setLeading(0f, 1.5f);
		page2Table1.addCell(page2table1cell9);

	}

	/**
	 * @param page2Table1
	 * @param check1
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void displayCheckBoxInPDFforForm2table1cell12(
			PdfPTable page2Table1, Image check1, String property)
			throws DocumentException, IOException {

		PdfPTable page2table1cell12check_table2 = new PdfPTable(2);
		page2table1cell12check_table2.getDefaultCell().setBorder(
				Rectangle.NO_BORDER);
		page2table1cell12check_table2.setWidths(new int[] { 2, 80 });
		page2table1cell12check_table2.addCell(check1);
		page2table1cell12check_table2.addCell(new Phrase(property, font));
		page2table1cell12check_table2
				.setHorizontalAlignment(Element.ALIGN_JUSTIFIED);
		PdfPCell page2table1cell12 = new PdfPCell(page2table1cell12check_table2);
		page2table1cell12
		.setHorizontalAlignment(Element.ALIGN_JUSTIFIED);
		page2table1cell12.setBorder(0);
		page2table1cell12.setPadding(5);
		page2table1cell12.setLeading(0f, 1.5f);
		page2Table1.addCell(page2table1cell12);
	}

	/**
	 * @param page2Table2
	 * @param check1
	 * @param check2
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void displayButtonInPDFforForm2table2cell10(
			PdfPTable page2Table2, Image check1, Image check2, String phrase)
			throws DocumentException, IOException {

		PdfPTable page2table2Cell9Buttontable = new PdfPTable(5);
		page2table2Cell9Buttontable.getDefaultCell().setBorder(
				Rectangle.NO_BORDER);
		//page2table2Cell9Buttontable.setWidths(new int[] { 200, 6, 10, 6, 10 });
		page2table2Cell9Buttontable.setWidths(new int[] { 50, 2, 5, 2, 10 });
		page2table2Cell9Buttontable.addCell(new Phrase(phrase, font));
		page2table2Cell9Buttontable.addCell(check1);
		page2table2Cell9Buttontable.addCell(new Phrase("Yes", font));
		page2table2Cell9Buttontable.addCell(check2);
		page2table2Cell9Buttontable.addCell(new Phrase("No", font));

		PdfPCell page2table2cell9 = new PdfPCell(page2table2Cell9Buttontable);
		page2table2cell9.setPadding(5);
		page2table2cell9.setLeading(0f, 1.5f);
		page2table2cell9.setBorder(Rectangle.NO_BORDER);
		page2Table2.addCell(page2table2cell9);

	}

	/**
	 * @param page2Table2
	 * @param check1
	 * @param check2
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void displayButtonInPDFforForm2table2cell1(
			PdfPTable page2Table2, Image check1, Image check2, String Property)
			throws DocumentException, IOException {

		PdfPTable page2table2Cell2Buttontable = new PdfPTable(5);
		page2table2Cell2Buttontable.getDefaultCell().setBorder(
				Rectangle.NO_BORDER);

		page2table2Cell2Buttontable.setWidths(new int[] { 50, 2, 5, 2, 10 });
		page2table2Cell2Buttontable.addCell(new Phrase(Property, font));
		page2table2Cell2Buttontable.addCell(check1);
		page2table2Cell2Buttontable.addCell(new Phrase("Yes", font));
		page2table2Cell2Buttontable.addCell(check2);
		page2table2Cell2Buttontable.addCell(new Phrase("No", font));

		PdfPCell page2table2cell2 = new PdfPCell(page2table2Cell2Buttontable);
		page2table2cell2.setPadding(5);
	    page2table2cell2.setLeading(0f, 1.5f);
		page2table2cell2.setBorder(Rectangle.NO_BORDER);

		page2Table2.addCell(page2table2cell2);
	}
	
	
	//Begin: Modified for IFOX-00414491
	private static void displayButtonInPDFforForm2table2cellA(
			PdfPTable page2Table2, Image check1, Image check2, String Property)
			throws DocumentException, IOException {

		PdfPTable page2table2Cell2Buttontable = new PdfPTable(6);
		//page2table2Cell2Buttontable.getDefaultCell().setBorder(
		//		Rectangle.NO_BORDER);
		page2table2Cell2Buttontable.getDefaultCell().setBorder(
				Rectangle.NO_BORDER);

		page2table2Cell2Buttontable.setWidths(new int[] { 40, 4, 5, 4, 10, 85 });
		page2table2Cell2Buttontable.addCell(new Phrase(Property, font));
		page2table2Cell2Buttontable.addCell(check1);
		page2table2Cell2Buttontable.addCell(new Phrase("Yes", font));
		page2table2Cell2Buttontable.addCell(check2);
		page2table2Cell2Buttontable.addCell(new Phrase("No", font));
		
		page2table2Cell2Buttontable.addCell(new Phrase(" ", font));

		PdfPCell page2table2cell2 = new PdfPCell(page2table2Cell2Buttontable);
		page2table2cell2.setPadding(5);
	    page2table2cell2.setLeading(0f, 1.5f);
		page2table2cell2.setBorder(Rectangle.NO_BORDER);

		page2Table2.addCell(page2table2cell2);
	}
	
	private static void displayButtonInPDFforForm2table2cellB(
			PdfPTable page2Table2, Image check1, Image check2, String Property)
			throws DocumentException, IOException {

		PdfPTable page2table2Cell2Buttontable = new PdfPTable(6);
		page2table2Cell2Buttontable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		
		page2table2Cell2Buttontable.setWidths(new int[] { 57, 4, 5, 4, 10, 85 });
		page2table2Cell2Buttontable.addCell(new Phrase(Property, font));
		page2table2Cell2Buttontable.addCell(check1);
		page2table2Cell2Buttontable.addCell(new Phrase("Yes", font));
		page2table2Cell2Buttontable.addCell(check2);
		page2table2Cell2Buttontable.addCell(new Phrase("No", font));
		page2table2Cell2Buttontable.addCell(new Phrase(" ", font));

		PdfPCell page2table2cell2 = new PdfPCell(page2table2Cell2Buttontable);
		page2table2cell2.setPadding(5);
	    page2table2cell2.setLeading(0f, 1.5f);
		page2table2cell2.setBorder(Rectangle.NO_BORDER);

		page2Table2.addCell(page2table2cell2);
	}
	
	private static void displayButtonInPDFforForm2table2cellC(
			PdfPTable page2Table2, Image check1, Image check2, String Property)
			throws DocumentException, IOException {

		PdfPTable page2table2Cell2Buttontable = new PdfPTable(6);
		//page2table2Cell2Buttontable.getDefaultCell().setBorder(
		//		Rectangle.NO_BORDER);
		page2table2Cell2Buttontable.getDefaultCell().setBorder(
				Rectangle.NO_BORDER);

		page2table2Cell2Buttontable.setWidths(new int[] { 87, 4, 5, 4, 10, 55 });
		page2table2Cell2Buttontable.addCell(new Phrase(Property, font));
		page2table2Cell2Buttontable.addCell(check1);
		page2table2Cell2Buttontable.addCell(new Phrase("Yes", font));
		page2table2Cell2Buttontable.addCell(check2);
		page2table2Cell2Buttontable.addCell(new Phrase("No", font));
		
		page2table2Cell2Buttontable.addCell(new Phrase(" ", font));

		PdfPCell page2table2cell2 = new PdfPCell(page2table2Cell2Buttontable);
		page2table2cell2.setPadding(5);
	    page2table2cell2.setLeading(0f, 1.5f);
		page2table2cell2.setBorder(Rectangle.NO_BORDER);

		page2Table2.addCell(page2table2cell2);
	}
	
	private static void displayButtonInPDFforForm2table2cellD(
			PdfPTable page2Table2, Image check1, Image check2, String Property, String currentPlan)
			throws DocumentException, IOException {

		PdfPTable page2table2Cell2Buttontable = new PdfPTable(6);
		page2table2Cell2Buttontable.getDefaultCell().setBorder(
				Rectangle.NO_BORDER);

		//page2table2Cell2Buttontable.setWidths(new int[] { 87, 4, 5, 4, 10, 55 });
		//page2table2Cell2Buttontable.addCell(new Phrase(Property, font));
		
		page2table2Cell2Buttontable.setWidths(new int[] { 1, 4, 60, 4, 70, 5 });
		page2table2Cell2Buttontable.addCell(new Phrase(Property, font));
		
		if("SDAHMO".equalsIgnoreCase(currentPlan)) {
			page2table2Cell2Buttontable.addCell(check2);
			page2table2Cell2Buttontable.addCell(new Phrase("Sharp Direct Advantage (HMO) ($194 per month) ", font));
		} else {
			page2table2Cell2Buttontable.addCell(check1);
			page2table2Cell2Buttontable.addCell(new Phrase("Sharp Direct Advantage (HMO) ($194 per month) ", font));
		}
		
		if("SDAHMO1".equalsIgnoreCase(currentPlan)) {
			page2table2Cell2Buttontable.addCell(check2);
			page2table2Cell2Buttontable.addCell(new Phrase("Sharp Direct Advantage (HMO) ($201 per month) ", font));
		} else {
			page2table2Cell2Buttontable.addCell(check1);
			page2table2Cell2Buttontable.addCell(new Phrase("Sharp Direct Advantage (HMO) ($201 per month) ", font));
		}

		page2table2Cell2Buttontable.addCell(new Phrase(" ", font));
		PdfPCell page2table2cell2 = new PdfPCell(page2table2Cell2Buttontable);
		page2table2cell2.setPadding(5);
	    page2table2cell2.setLeading(0f, 1.5f);
		page2table2cell2.setBorder(Rectangle.NO_BORDER);
		page2Table2.addCell(page2table2cell2);
	}
	
	//End: Modified for IFOX-00414491

	private static void displayButtonInPDFforForm2StmtsButton(
			PdfPTable page2Table2, Image check1, Image check2)
			throws DocumentException, IOException {

		PdfPTable page2table2Cell2Buttontable = new PdfPTable(5);
		page2table2Cell2Buttontable.getDefaultCell().setBorder(
				Rectangle.NO_BORDER);

		page2table2Cell2Buttontable.setWidths(new int[] { 30, 2, 15, 2, 15 });
		page2table2Cell2Buttontable.addCell(new Phrase("\t\tAccount Type: ",
				font));
		page2table2Cell2Buttontable.addCell(check1);
		page2table2Cell2Buttontable.addCell(new Phrase("Checking", font));
		page2table2Cell2Buttontable.addCell(check2);
		page2table2Cell2Buttontable.addCell(new Phrase("Savings", font));

		PdfPCell page2table2cell2 = new PdfPCell(page2table2Cell2Buttontable);
		page2table2cell2.setBorder(0);
		page2Table2.addCell(page2table2cell2);
	}

	/**
	 * @param fieldValue
	 * @return
	 */
	private static String getChangedValue(String fieldValue) {
		return fieldValue != null ? fieldValue : "";
	}

	private static PdfPTable setLogoData(String property, String value) {
		PdfPTable form1 = null;
		form1 = new PdfPTable(2);
		form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		form1.addCell(new Phrase(property, font));
		form1.addCell(new Phrase(value, font));
		return form1;
	}
	
	
	private static PdfPTable setLogoDataNew(String property, String value) {
		PdfPTable form1 = null;
		form1 = new PdfPTable(2);
		form1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		form1.addCell(new Phrase(property, font));
		form1.addCell(new Phrase(value, font));
		return form1;
	}

	public static byte[] mergePDFs(List<InputStream> pdfs, ByteArrayOutputStream outputStream) {
		
		System.out.println("In Merge PDF");
		Document document = new Document(PageSize.A4, 10, 10, 10, 10);
        
        try {
            List<PdfReader> readers = new ArrayList<PdfReader>();
            Iterator<InputStream> iteratorPDFs = pdfs.iterator();
            while (iteratorPDFs.hasNext()) {
                InputStream pdf = iteratorPDFs.next();
                PdfReader pdfReader = new PdfReader(pdf);
                readers.add(pdfReader);
                pdf.close();
            }
            
            PdfWriter writer = PdfWriter.getInstance(document, outputStream);

            document.open();
            
            PdfContentByte cb = writer.getDirectContent(); // Holds the PDF data
 
            PdfImportedPage page;
            int pageOfCurrentReaderPDF = 0;
            Iterator<PdfReader> iteratorPDFReader = readers.iterator();
 
            while (iteratorPDFReader.hasNext()) {
                PdfReader pdfReader = iteratorPDFReader.next();
                while (pageOfCurrentReaderPDF < pdfReader.getNumberOfPages()) {
                	document.setPageSize(pdfReader.getCropBox(++pageOfCurrentReaderPDF));
                    document.newPage();              
                    page = writer.getImportedPage(pdfReader,
                            pageOfCurrentReaderPDF);
                    cb.addTemplate(page, 0, 0);          
                }
                pageOfCurrentReaderPDF = 0;
            }
			
            outputStream.flush();
            document.close();
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (document.isOpen())
                document.close();
            try {
                if (outputStream != null)
                    outputStream.close();
            } catch (IOException ioe) {
                ioe.printStackTrace();
            }
        }
        return outputStream.toByteArray();
    }
	
	@SuppressWarnings("unused")
	private static void addSequenceNumber(Document document, int sequenceNumber) throws DocumentException {

		PdfPTable Braille2 = new PdfPTable(1);
		//Braille2.setSpacingBefore(15);
		Braille2.setSpacingBefore(100);
		Braille2.setWidthPercentage(60);
		Braille2.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPCell Braillcell12 = new PdfPCell(
				new Phrase(
						"Enrollment Confirmation Number from WebApp System is : " + sequenceNumber,
						FontFactory.getFont(FontFactory.HELVETICA, 10,
								Font.BOLD, java.awt.Color.WHITE)));
		Braillcell12.setHorizontalAlignment(Element.ALIGN_CENTER);
		Braillcell12.setBackgroundColor(WebColors.getRGBColor("#F2B50F"));
		Braillcell12.setBorder(Rectangle.NO_BORDER);
		Braille2.addCell(Braillcell12);
		document.add(Braille2);

	}	
	
	
	private static String getNewPhysicianName(String physicianId, HttpServletRequest request) {
	
		Map<String, String> physicanMapDB = (HashMap) request.getSession().getServletContext().getAttribute("physicianMap");
		if(null != physicanMapDB) {
			for (String key : physicanMapDB.keySet()) {
				if(physicianId.equalsIgnoreCase(key)) {
					String value = physicanMapDB.get(key);
			    	return value.substring(0, value.indexOf("("));
				}
			}
		}
		return physicianId;
	}
	
	private static String getNewAgentName(String agentId, HttpServletRequest request) {
		
		Map<String, String> agentNamesMap = (HashMap) request.getSession().getServletContext().getAttribute("agentNamesMap");
		if(null != agentNamesMap) {
			for (String key : agentNamesMap.keySet()) {
				if(null != agentId && agentId.trim().equalsIgnoreCase(key.trim())) {
					String value = agentNamesMap.get(key);
			    	return value == null || value.trim().equals("") ? agentId : value.trim();
				}
			}
		}
		return agentId;
	}

	
	private static void displayMaterialIdAndPageNumbers(Document document, PdfWriter writer, 
			String planName, String pageNumber, String totalNumberOfPages) throws DocumentException, IOException
	{
		/*
		PdfPTable OuterTable = new PdfPTable(1);
		OuterTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		
		PdfPTable table = new PdfPTable(4);
		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table.setWidthPercentage(100.0f);
		float[] columnWidths = { 1.8f, 2.2f, 1.8f, 4.5f };
		table.setWidths(columnWidths);
		
		table.addCell(new Phrase("", font));
		table.addCell(new Phrase("", font));
		table.addCell(new Phrase("", font));
		table.addCell(new Phrase("", font));
		OuterTable.addCell(table);
		
		document.add(OuterTable);
		*/
		
		//Font font = new Font(Font.FontFamily.COURIER, 32, Font.BOLD);
		Font font1 = new Font(base, 10, Font.NORMAL, java.awt.Color.BLACK);
		Font font2 = new Font(base, 9, Font.NORMAL, java.awt.Color.BLACK);
		//Font font = new Font(base, 9, Font.BOLD, java.awt.Color.BLACK);

		
		if("4".equals(pageNumber))
		{
			/*IFOX-00418144 2020 AEP Plan Changes. START*/
			if("SDAGC20".equalsIgnoreCase(planName) || "SDAGCWD20".equalsIgnoreCase(planName) || "SDAPC20".equalsIgnoreCase(planName))
				ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_LEFT,
						new Phrase(String.format("H5386_2020 Online Individual Enrollment Form V1"), font2), 20, 30, 0);
			/*IFOX-00418144 2020 AEP Plan Changes. END*/
			//Fix for IFOX-00420776 - Start
			else if("SDAB20".equalsIgnoreCase(planName) || "SDABWD20".equalsIgnoreCase(planName) || "SDAP20".equalsIgnoreCase(planName) || "SDAPWD20".equalsIgnoreCase(planName))
				ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_LEFT,
						new Phrase(String.format("H5386_2020 SHC Enrollment Form_M V1"), font2), 20, 30, 0);
			//Fix for IFOX-00420776 - End
			else
				ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_LEFT,
					new Phrase(String.format("H5386_2019 INDIVIDUAL ENROLLMENT FORM V3_M "), font2), 20, 30, 0);
			
			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_CENTER,
					new Phrase(String.format("Page " + pageNumber + " of %d", 8), font1), 500, 20, 0);
			
		} else {
			/*IFOX-00418144 2020 AEP Plan Changes. START*/
			if("SDAGC20".equalsIgnoreCase(planName) || "SDAGCWD20".equalsIgnoreCase(planName) || "SDAPC20".equalsIgnoreCase(planName))
				ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_LEFT,
						new Phrase(String.format("H5386_2020 Online Individual Enrollment Form V1"), font2), 20, 30, 0);
			/*IFOX-00418144 2020 AEP Plan Changes. END*/
			//Fix for IFOX-00420776 - Start
			else if("SDAB20".equalsIgnoreCase(planName) || "SDABWD20".equalsIgnoreCase(planName) || "SDAP20".equalsIgnoreCase(planName) || "SDAPWD20".equalsIgnoreCase(planName))
				ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_LEFT,
						new Phrase(String.format("H5386_2020 SHC Enrollment Form_M V1"), font2), 20, 30, 0);
			//Fix for IFOX-00420776 - End
			else
				ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_LEFT,
					new Phrase(String.format("H5386_2019 INDIVIDUAL ENROLLMENT FORM V3_M "), font2), 20, 55, 0);
			
			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_CENTER,
					new Phrase(String.format("Page " + pageNumber + " of %d", 8), font1), 500, 30, 0);
		}

	}
	
	private static String maskSSN(String ssn) {
		return ("XXX-XX-"+ssn.substring(5));
	}

}
