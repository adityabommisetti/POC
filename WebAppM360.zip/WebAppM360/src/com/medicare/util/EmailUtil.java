
package com.medicare.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.mail.Session;
import javax.mail.Message;
import javax.mail.Transport;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.activation.FileDataSource;
import javax.activation.DataHandler;

import java.io.InputStreamReader;
import java.nio.charset.Charset;
import org.apache.log4j.Logger;

/**
 *
 * @author  ramag
 */
public class EmailUtil {

	public static final String TEXT_HTML 	= "text/html";
	public static final String TEXT_PLAIN	= "text/plain";
	public static final String APPL_PDF		= "application/pdf";
	
	public static final String SHARP_EMAIL_LOGO = "/images/SHP_LogoEmail.png";
	public static final String SHARP_EMAIL_SIGNATURE = "/images/SHP_SigEmail.png";
		
    private String emailServer;
    private String emailFrom;
    private String [] emailTo;
    private String [] emailCC;
    private String [] emailBCC;
    
	private final static Logger LOGGER = Logger.getLogger(EmailUtil.class.getName()); //Added for IFOX-00405531
    
    /** Creates a new instance of EmailUtil */
    public EmailUtil() {
    	//emailFrom = "OnlineEnrollment@wipro.com";
    	//emailFrom = "doNotReply@wipro.com";
    	emailFrom = "customer.service@sharp.com";
        emailTo = new String[]{"ramagopala.chaturvedula@wipro.com"};
        //emailBCC = new String[]{"SHP.MedicareSales@sharp.com","ramagopala.chaturvedula@wipro.com","john.lepage@wipro.com"};
        emailBCC = new String[]{"SHPMedicareApps@sharp.com","ramagopala.chaturvedula@wipro.com","john.lepage@wipro.com"};
        
        setEmailServer("relay.iconnection.com");
    }

    public EmailUtil(String[] toList) {
    	//emailFrom = "ramagopala.chaturvedula@wipro.com";
    	//emailFrom = "OnlineEnrollment@wipro.com";
        //emailFrom = "doNotReply@wipro.com";
    	emailFrom = "customer.service@sharp.com";
    	emailTo = toList;
        //emailBCC = new String[]{"SHP.MedicareSales@sharp.com","ramagopala.chaturvedula@wipro.com","john.lepage@wipro.com"};\
        //emailBCC = new String[]{"ramagopala.chaturvedula@wipro.com","Ben.Aragon@sharp.com","john.lepage@wipro.com"};
    	emailBCC = new String[]{"SHPMedicareApps@sharp.com","ramagopala.chaturvedula@wipro.com","Ben.Aragon@sharp.com","john.lepage@wipro.com"};
        
        setEmailServer("relay.iconnection.com");
    }    
    
    
    //Begin: Added for IFOX-00405531
    public EmailUtil(String[] toList, Properties properties)
    {
    	InputStreamReader inputStreamReader = null;
		try {
			inputStreamReader = new InputStreamReader(
					SharpPdfGen.class.getClassLoader().getResourceAsStream("email.properties"), Charset.forName("UTF-8"));

			properties = (properties == null) ? new Properties() : properties;
			properties.load(inputStreamReader);

			setEmailServer(properties.getProperty("sharp.emailServer"));
	    	
			emailFrom = properties.getProperty("sharp.email.from");
	    	emailTo = toList;

	    	if(null != properties.getProperty("sharp.email.ccList"))
	    		emailCC = properties.getProperty("sharp.email.ccList").split(",");
	    	
	    	if(null != properties.getProperty("sharp.email.bccList"))
	    	emailBCC = properties.getProperty("sharp.email.bccList").split(",");

		} catch (Exception e) {
			LOGGER.error("EmailUtil : Exception occured while reading email properties : Error [" + e.getMessage() + "] ");
		
		} finally {
			if(null != inputStreamReader)
				try {
					inputStreamReader.close();
				} catch (IOException e) {}
		}
	}
	//End: Added for IFOX-00405531
    
    
    /** Getter for property emailServer.
     * @return Value of property emailServer.
     *
     */
    public java.lang.String getEmailServer() {
        return emailServer;
    }

    /** Setter for property emailServer.
     * @param emailServer New value of property emailServer.
     *
     */
    public void setEmailServer(java.lang.String emailServer) {
        this.emailServer = emailServer;
    }

    public void sendEmailMsg(String subject, String msgText, String msgFormat) throws UnsupportedEncodingException, MessagingException
	{
    	sendEmail(subject, msgText, null, msgFormat);
	}
    
    public void sendEmail(String subject, String msgText) throws UnsupportedEncodingException, MessagingException
    {
        sendEmail(subject,msgText,null,TEXT_PLAIN);
    }

    public void sendEmail(String subject, String msgText, String fileName) throws UnsupportedEncodingException, MessagingException
	{
    	sendEmail(subject,msgText,fileName,TEXT_PLAIN);
	}
    
    public void sendEmail(String subject, String msgText, String fileName, String msgType) throws UnsupportedEncodingException, MessagingException
    {
    	ArrayList fileNames = new ArrayList();
    	if (fileName != null) {
    		fileNames.add(fileName);
    	}
    	sendEmailAttachment(subject, msgText, fileNames, msgType);
    }
    
    public void sendEmailAttachment(String subject, String msgText, ArrayList fileNames, String msgType) throws UnsupportedEncodingException, MessagingException
    {
       	Properties props = System.getProperties();
        props.put("mail.smtp.host", emailServer);
    	props.put("mail.smtp.ehlo", "false");

    	Session session = Session.getInstance(props, null);

    	MimeMessage msg = new MimeMessage(session);
        
    	msg.setFrom(new InternetAddress(emailFrom, "Online Enrollment Support Team"));
        
        InternetAddress[] addressTo = null;
        if (emailTo != null)
        {
            addressTo = new InternetAddress[emailTo.length];
            for (int i = 0; i < emailTo.length; i++)
            {
                addressTo[i] = new InternetAddress(emailTo[i]);
            }
            msg.setRecipients(Message.RecipientType.TO, addressTo);
        }
        InternetAddress[] addressCC = null;
        if (emailCC != null)
        {
            addressCC = new InternetAddress[emailCC.length];
            for (int i = 0; i < emailCC.length; i++)
            {
                addressCC[i] = new InternetAddress(emailCC[i]);
            }
            if (emailCC.length > 0)
                msg.setRecipients(Message.RecipientType.CC, addressCC);
        }
        InternetAddress[] addressBCC = null;
        if (emailBCC != null)
        {
            addressBCC = new InternetAddress[emailBCC.length];
            for (int i = 0; i < emailBCC.length; i++)
            {
                addressBCC[i] = new InternetAddress(emailBCC[i]);
            }
            if (emailBCC.length > 0)
                msg.setRecipients(Message.RecipientType.BCC, addressBCC);
        }

        msg.setSubject(subject);
        msg.setSentDate(new Date());

        if (fileNames != null)
        {
        	Multipart mp = new MimeMultipart();
        	MimeBodyPart mbp = new MimeBodyPart();
            mbp.setContent(msgText,msgType);
            mp.addBodyPart(mbp);
        	
            Iterator it = fileNames.iterator();
            while (it.hasNext()) {
            	mbp = new MimeBodyPart();
                FileDataSource fds = new FileDataSource((String)it.next());
                mbp.setDataHandler(new DataHandler(fds));
                mbp.setFileName(fds.getName());
                mp.addBodyPart(mbp);
            }
           	msg.setContent(mp);
        }
        else
        {
            //msg.setText(msgText);
            msg.setContent(msgText,msgType);
        }
        
        Transport.send(msg);
    }
    
    public void sendHtmlEmailAttachment(String subject, String msgText, ArrayList fileNames, String msgType, HttpServletRequest request) throws MessagingException, IOException
    {
    	this.logMailServer(); //Added for IFOX-00405531
    	
       	Properties props = System.getProperties();
        props.put("mail.smtp.host", emailServer);
    	props.put("mail.smtp.ehlo", "false");

    	Session session = Session.getInstance(props, null);
    	
    	MimeBodyPart logoImg = new MimeBodyPart();
    	MimeBodyPart signatureImg = new MimeBodyPart();
    	
    	logoImg.setHeader("Content-ID", "<0001>");
    	signatureImg.setHeader("Content-ID", "<0002>");
    	
    	logoImg.setDisposition(MimeBodyPart.INLINE);
    	signatureImg.setDisposition(MimeBodyPart.INLINE);
    	
    	ServletContext context = request.getSession().getServletContext();
    	
    	//logoImg.attachFile("/images/SHP_LogoEmail.png");
    	//logoImg.attachFile("/images/Wipro_Logo.png");
    	logoImg.attachFile(context.getRealPath(SHARP_EMAIL_LOGO));
    	//signatureImg.attachFile("/images/SignatureEmail.png");
    	//signatureImg.attachFile("/images/Wipro_Logo1.png");
    	signatureImg.attachFile(context.getRealPath(SHARP_EMAIL_SIGNATURE));

    	MimeMessage msg = new MimeMessage(session);
        
    	msg.setFrom(new InternetAddress(emailFrom, "Sharp Health Plan Customer Care"));
        
    	//Begin: Modified for IFOX-00405531
    	/*
        InternetAddress[] addressTo = null;
        if (emailTo != null)
        {
            addressTo = new InternetAddress[emailTo.length];
            for (int i = 0; i < emailTo.length; i++)
            {
                addressTo[i] = new InternetAddress(emailTo[i]);
            }
            msg.setRecipients(Message.RecipientType.TO, addressTo);
        }
        InternetAddress[] addressCC = null;
        if (emailCC != null)
        {
            addressCC = new InternetAddress[emailCC.length];
            for (int i = 0; i < emailCC.length; i++)
            {
                addressCC[i] = new InternetAddress(emailCC[i]);
            }
            if (emailCC.length > 0)
                msg.setRecipients(Message.RecipientType.CC, addressCC);
        }
        InternetAddress[] addressBCC = null;
        if (emailBCC != null)
        {
            addressBCC = new InternetAddress[emailBCC.length];
            for (int i = 0; i < emailBCC.length; i++)
            {
                addressBCC[i] = new InternetAddress(emailBCC[i]);
            }
            if (emailBCC.length > 0)
                msg.setRecipients(Message.RecipientType.BCC, addressBCC);
        }
        */
        InternetAddress[] addressTo = null;
        ArrayList<String> addressToList = new ArrayList<String>();
        if (emailTo != null)
        {
            for (int i = 0; i < emailTo.length; i++)
            	if(null != emailTo[i] && !emailTo[i].trim().equals(""))
            		addressToList.add(emailTo[i].trim());

            if(addressToList.size() > 0) {
            	addressTo = new InternetAddress[addressToList.size()];
            	for(int index = 0; index < addressToList.size(); index++)
            		addressTo[index] = new InternetAddress(addressToList.get(index));
            	msg.setRecipients(Message.RecipientType.TO, addressTo);
            }
        }
        InternetAddress[] addressCC = null;
        ArrayList<String> addressCCList = new ArrayList<String>();
        if (emailCC != null)
        {
            for (int i = 0; i < emailCC.length; i++)
            	if(null != emailCC[i] && !emailCC[i].trim().equals(""))
            		addressCCList.add(emailCC[i].trim());

            if(addressCCList.size() > 0) {
            	addressCC = new InternetAddress[addressCCList.size()];
            	for(int index = 0; index < addressCCList.size(); index++)
            		addressCC[index] = new InternetAddress(addressCCList.get(index));
                msg.setRecipients(Message.RecipientType.CC, addressCC);
            }
        }
        InternetAddress[] addressBCC = null;
        ArrayList<String> emailBCCList = new ArrayList<String>();
        if (emailBCC != null)
        {
            for (int i = 0; i < emailBCC.length; i++)
            	if(null != emailBCC[i] && !emailBCC[i].trim().equals(""))
            		emailBCCList.add(emailBCC[i].trim());

            if(emailBCCList.size() > 0) {
            	addressBCC = new InternetAddress[emailBCCList.size()];
            	for(int index = 0; index < emailBCCList.size(); index++)
            		addressBCC[index] = new InternetAddress(emailBCCList.get(index));
                msg.setRecipients(Message.RecipientType.BCC, addressBCC);
            }
        }
        //End: Modified for IFOX-00405531
        
        msg.setSubject(subject);
        msg.setSentDate(new Date());

        if (fileNames != null)
        {
        	Multipart mp = new MimeMultipart();
        	MimeBodyPart mbp = new MimeBodyPart();
            mbp.setContent(msgText,msgType);
            mp.addBodyPart(mbp);
        	
            mp.addBodyPart(logoImg);
            mp.addBodyPart(signatureImg);
            
            Iterator it = fileNames.iterator();
            while (it.hasNext()) {
            	mbp = new MimeBodyPart();
                FileDataSource fds = new FileDataSource((String)it.next());
                mbp.setDataHandler(new DataHandler(fds));
                mbp.setFileName(fds.getName());
                mp.addBodyPart(mbp);
            }
           	msg.setContent(mp);
        }
        else
        {
            //msg.setText(msgText);
            msg.setContent(msgText,msgType);
        }
        
        Transport.send(msg);
    }    
    
    public void setEmailFrom(String emailFrom) {
    	this.emailFrom = emailFrom;
    }
    public String getEmailFrom() {
    	return emailFrom;
    }
    
    public void setEmailTo(String emailLst) {
        String [] toArr = toArray(emailLst,";");
        if (toArr.length > 0)
            emailTo = toArr;
        else
        	emailTo = null;
    }
    public String [] getEmailTo() {
        return emailTo;
    }

    public void setEmailCC(String emailLst) {
        String [] ccArr = toArray(emailLst,";");
        if (ccArr.length > 0)
            emailCC = ccArr;
        else
        	emailCC = null;
    }
    public String [] getEmailCC() {
        return emailCC;
    }

    public void setEmailBCC(String emailLst) {
        String [] bccArr = toArray(emailLst,";");
        if (bccArr.length > 0)
            emailBCC = bccArr;
        else
        	emailBCC = null;
    }
    public String [] getEmailBCC() {
    	return emailBCC;
    }
    
    public static String [] toArray(String strLst, String delim) {
        ArrayList arLst = toArrayList(strLst,delim);
        int size = arLst.size();
        String [] strAr = new String[size];
        strAr = (String [])arLst.toArray(strAr);
        return strAr;
    }    

    
    public static ArrayList toArrayList(String strLst, String delim) {
        
        ArrayList arLst = new ArrayList();
        
        if (strLst == null)
            return arLst;
        
        StringTokenizer st = new StringTokenizer(strLst,delim);
        while (st.hasMoreTokens()) {
            String token = st.nextToken();
            if (token.charAt(0) == '\'')
                token = token.substring(1,token.length()-1);
            arLst.add(token);
        }
        
        return arLst;
    }     

    
    //Begin: Added for IFOX-00405531
    private void logMailServer()
    {
    	LOGGER.info(" EmailUtil : logMailServer : EmailServer [" + emailServer + "], EmailFrom [" + emailFrom + "] ");
    	
    	LOGGER.info(" EmailUtil : logMailServer : EmailTo List ::::: Start ::::::::");
    	if(null != emailTo)
    		for(String strEmailTo : emailTo)
    			LOGGER.info(strEmailTo);
    	LOGGER.info(" EmailUtil : logMailServer : EmailTo List ::::: End   :::::::");
    	
    	
    	LOGGER.info(" EmailUtil : logMailServer : EmailCC List ::::: Start ::::::::");
    	if(null != emailCC)
    		for(String strEmailCC : emailCC)
    			LOGGER.info(strEmailCC);
    	LOGGER.info(" EmailUtil : logMailServer : EmailTo List ::::: End   :::::::");
    	
    	
    	LOGGER.info(" EmailUtil : logMailServer : EmailBCC List ::::: Start ::::::::");
    	if(null != emailBCC)
    		for(String strEmailBCC : emailBCC)
    			LOGGER.info(strEmailBCC);
    	LOGGER.info(" EmailUtil : logMailServer : emailBCC List ::::: End   :::::::");

    }
    //End: Added for IFOX-00405531

}
