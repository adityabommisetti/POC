package com.medicare.helper;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.medicare.model.FileField;

/**
 * @author SH250285
 * 
 */
public class M360AppUtil {

	private final static Logger LOGGER = Logger.getLogger(M360AppUtil.class.getName());

	/**
	 * @throws Exception
	 */
	
	@SuppressWarnings("resource")
	public static synchronized void generateFileToM360App() throws Exception {
		Properties prop = new Properties();
		Properties propPath = new Properties();
		prop.load(M360AppUtil.class.getClassLoader().getResourceAsStream("hibernate.properties"));
		propPath.load(M360AppUtil.class.getClassLoader().getResourceAsStream("saveLocation.properties"));
		LOGGER.info(" Start : In generateFileToM360App() method of M360AppUtil class");

		LOGGER.info(" Start : In generateFileToM360App() method of M360AppUtil class 1");
		LOGGER.info(" Start : In generateFileToM360App() method of M360AppUtil class 2 ");
		String batchFilename = null;
		String batchFilelocation = null;
		Connection conn = null;
		PreparedStatement preparedStatementResulset = null;
		Statement headerStatement = null;
		ResultSet rs = null;
		ResultSet rsHeader = null;
		ResultSet rscounty = null;
		BufferedWriter writer = null;
		int recordsCount = 0;
		String sentaraAccountID = WebAppConstants.sentaraAccountId;
		boolean isFTPRequired = false;
		try {
			LOGGER.info(" Start : In generateFileToM360App() method of M360AppUtil class 3 ");
			Class.forName(prop.getProperty("database.driver"));
			conn = DriverManager.getConnection(prop.getProperty("database.url"), prop.getProperty("database.user"),
					prop.getProperty("database.password"));

			Date date = new Date();
			DateFormat dateFormatHeader = new SimpleDateFormat("yyyyMMdd");
			DateFormat dateFormatforFilename = new SimpleDateFormat("yyyyMMddHHmm");
			String dateforFilename = dateFormatforFilename.format(date);
			preparedStatementResulset = conn.prepareStatement(WebAppConstants.resultSetQuery);
			rs = preparedStatementResulset.executeQuery();
			headerStatement = conn.createStatement();
			rsHeader = headerStatement.executeQuery("select  max(id) as ID from WB_EEM360Audit ");
			String headerId = null;
			String uniqueHeaderId = null;
			while (rsHeader.next()) {
				headerId = (rsHeader.getString("ID") == null ? "0" : rsHeader.getString("ID"));
				int maxLengthHeaderLength = WebAppConstants.eem360BatchHeaderLength;
				uniqueHeaderId = methodHeaderTailerContent(maxLengthHeaderLength, headerId);
			}
			String dateforHeader = dateFormatHeader.format(date);
			String header = "HDR" + sentaraAccountID + dateforHeader + uniqueHeaderId + "       "
					+ propPath.getProperty("batchFile.type");

			boolean headerCreated = false;
			boolean writeTrailer = false;

			while (rs.next()) {

				if (!headerCreated) {
					batchFilename = propPath.getProperty("batchFile.Name") + dateforFilename;
					batchFilelocation = propPath.getProperty("locationpath.EEM360batchfile") + batchFilename + ".txt";
					LOGGER.info("BATCH FILE LOCATION :" + batchFilelocation);
					LOGGER.info("BATCH FILE NAME     :" + batchFilename);
					writer = new BufferedWriter(new FileWriter(batchFilelocation));
					writer.write(header);
					writer.newLine();
					headerCreated = true;
					
					writeTrailer = true;
					isFTPRequired = true;
				}
				String flag = rs.getString("EEM360FLAG");
				if (flag != null && !flag.isEmpty() && flag.equalsIgnoreCase("Y")) {
					continue;
				}
				String ApplicationNumber = rs.getString("Application_Nbr");
				LOGGER.info(" M360AppUtil. Application Number :" + ApplicationNumber);
				for (FileField field : M360FileMetaData.fields) {
					field.write(rs, writer, conn);
				}
				
				
				//while deployment below 3 lines should be uncommented, for local testing comment these 3 lines
				preparedStatementResulset = conn.prepareStatement(WebAppConstants.updateFLAGQuery);
				preparedStatementResulset.setString(1, ApplicationNumber);
				preparedStatementResulset.executeUpdate();

				recordsCount++;
				writer.newLine();
			}
			if (writeTrailer) {
				int finalCount = recordsCount + 2;
				String count = String.valueOf(finalCount);

				// preparedStatementResulset = connection
				// .prepareStatement("INSERT INTO EEM360Audit
				// VALUES(default,?,?,?)");
				// ravindra start here

				preparedStatementResulset = conn.prepareStatement(
						"INSERT INTO WB_EEM360Audit VALUES((select nvl(max(id)+1,1) from WB_eem360audit),?,?,?,?)");

				// ravindra end here
				preparedStatementResulset.setInt(1, recordsCount);
				preparedStatementResulset.setTimestamp(2, getCurrentTimeStamp());
				preparedStatementResulset.setString(3, "success");
				preparedStatementResulset.setString(4, sentaraAccountID);
				preparedStatementResulset.executeUpdate();
				int maximumTrailerLength = WebAppConstants.eem360BatchTrailerLength;
				String tailerCount = methodHeaderTailerContent(maximumTrailerLength, count);
				String tailer = "TLR" + sentaraAccountID + tailerCount;
				writer.write(tailer);
			}
		} catch (Exception ex) {
			LOGGER.error("Exception in : M360AppUtill class");
			LOGGER.fatal("Connection is lost");
			ex.printStackTrace();

		} finally {

			if (writer != null) {
				writer.close();
			}
			if (rs != null) {
				rs.close();
			}
			if (rscounty != null) {
				rscounty.close();
			}
			if (rsHeader != null) {
				rsHeader.close();
			}
			if (preparedStatementResulset != null) {
				preparedStatementResulset.close();
			}
			if (headerStatement != null) {
				headerStatement.close();
			}
			if (conn != null && !conn.isClosed()) {
				conn.close();
			}

		}
		if (isFTPRequired) {
			// FTPUploader.FTPloader(batchFilelocation,batchFilename);
			SFTPUploader.FTPUploader(batchFilelocation, batchFilename);
			JschSftpUploader.JschSFTPUploader(batchFilename); // i commented
																// this file to
																// do not send
																// files
		}
		LOGGER.info(" End : In generateFileToM360App() method of M360AppUtil class");
	}


	/**
	 * @throws Exception
	 */
	
	@SuppressWarnings("resource")
	public static synchronized void generateFileToM360App(String customerId) throws Exception {
		Properties prop = new Properties();
		Properties propPath = new Properties();
		prop.load(M360AppUtil.class.getClassLoader().getResourceAsStream("hibernate.properties"));
		propPath.load(M360AppUtil.class.getClassLoader().getResourceAsStream("saveLocation.properties"));
		LOGGER.info(" Start : In generateFileToM360App() method of M360AppUtil class");

		LOGGER.info(" Start : In generateFileToM360App() method of M360AppUtil class 1");
		LOGGER.info(" Start : In generateFileToM360App() method of M360AppUtil class 2 ");
		String batchFilename = null;
		String batchFilelocation = null;
		Connection conn = null;
		PreparedStatement preparedStatementResulset = null;
		Statement headerStatement = null;
		ResultSet rs = null;
		ResultSet rsHeader = null;
		ResultSet rscounty = null;
		BufferedWriter writer = null;
		int recordsCount = 0;
		String sentaraAccountID = customerId;
		boolean isFTPRequired = false;
		try {
			LOGGER.info(" Start : In generateFileToM360App() method of M360AppUtil class 3 ");
			Class.forName(prop.getProperty("database.driver"));
			conn = DriverManager.getConnection(prop.getProperty("database.url"), prop.getProperty("database.user"),
					prop.getProperty("database.password"));

			Date date = new Date();
			DateFormat dateFormatHeader = new SimpleDateFormat("yyyyMMdd");
			DateFormat dateFormatforFilename = new SimpleDateFormat("yyyyMMddHHmm");
			String dateforFilename = dateFormatforFilename.format(date);
			preparedStatementResulset = conn.prepareStatement(WebAppConstants.resultSetQueryFor(customerId));
			rs = preparedStatementResulset.executeQuery();
			headerStatement = conn.createStatement();
			rsHeader = headerStatement.executeQuery("select  max(id) as ID from WB_EEM360Audit ");
			String headerId = null;
			String uniqueHeaderId = null;
			while (rsHeader.next()) {
				headerId = (rsHeader.getString("ID") == null ? "0" : rsHeader.getString("ID"));
				int maxLengthHeaderLength = WebAppConstants.eem360BatchHeaderLength;
				uniqueHeaderId = methodHeaderTailerContent(maxLengthHeaderLength, headerId);
			}
			String dateforHeader = dateFormatHeader.format(date);
			String header = "HDR" + sentaraAccountID + dateforHeader + uniqueHeaderId + "       "
					+ propPath.getProperty("batchFile.type");

			boolean headerCreated = false;
			boolean writeTrailer = false;

			while (rs.next()) {

				if (!headerCreated) {
					batchFilename = propPath.getProperty("batchFile.Name") + dateforFilename;
					batchFilelocation = propPath.getProperty(customerId + ".locationpath.EEM360batchfile") + batchFilename + ".txt";
					LOGGER.info("BATCH FILE LOCATION :" + batchFilelocation);
					LOGGER.info("BATCH FILE NAME     :" + batchFilename);
					writer = new BufferedWriter(new FileWriter(batchFilelocation));
					writer.write(header);
					writer.newLine();
					headerCreated = true;
					
					writeTrailer = true;
					isFTPRequired = true;
				}
				String flag = rs.getString("EEM360FLAG");
				if (flag != null && !flag.isEmpty() && flag.equalsIgnoreCase("Y")) {
					continue;
				}
				String ApplicationNumber = rs.getString("Application_Nbr");
				LOGGER.info(" M360AppUtil. Application Number :" + ApplicationNumber);
				for (FileField field : SHPM360FileMetaData.fields) {
					field.write(rs, writer, conn);
				}
				
				
				//while deployment below 3 lines should be uncommented, for local testing comment these 3 lines
				preparedStatementResulset = conn.prepareStatement(WebAppConstants.updateFLAGQuery);
				preparedStatementResulset.setString(1, ApplicationNumber);
				preparedStatementResulset.executeUpdate();

				recordsCount++;
				writer.newLine();
			}
			if (writeTrailer) {
				int finalCount = recordsCount + 2;
				String count = String.valueOf(finalCount);

				// preparedStatementResulset = connection
				// .prepareStatement("INSERT INTO EEM360Audit
				// VALUES(default,?,?,?)");
				// ravindra start here

				preparedStatementResulset = conn.prepareStatement(
						"INSERT INTO WB_EEM360Audit VALUES((select nvl(max(id)+1,1) from WB_eem360audit),?,?,?,?)");

				// ravindra end here
				preparedStatementResulset.setInt(1, recordsCount);
				preparedStatementResulset.setTimestamp(2, getCurrentTimeStamp());
				preparedStatementResulset.setString(3, "success");
				preparedStatementResulset.setString(4, sentaraAccountID);
				preparedStatementResulset.executeUpdate();
				int maximumTrailerLength = WebAppConstants.eem360BatchTrailerLength;
				String tailerCount = methodHeaderTailerContent(maximumTrailerLength, count);
				String tailer = "TLR" + sentaraAccountID + tailerCount;
				writer.write(tailer);
			}
		} catch (Exception ex) {
			LOGGER.error("Exception in : M360AppUtill class");
			LOGGER.fatal("Connection is lost");
			ex.printStackTrace();

		} finally {

			if (writer != null) {
				writer.close();
			}
			if (rs != null) {
				rs.close();
			}
			if (rscounty != null) {
				rscounty.close();
			}
			if (rsHeader != null) {
				rsHeader.close();
			}
			if (preparedStatementResulset != null) {
				preparedStatementResulset.close();
			}
			if (headerStatement != null) {
				headerStatement.close();
			}
			if (conn != null && !conn.isClosed()) {
				conn.close();
			}

		}
		if (isFTPRequired) {
			// FTPUploader.FTPloader(batchFilelocation,batchFilename);
			JschSftpUploader.JschSFTPUploader(customerId,batchFilename); // i commented
																// this file to
																// do not send
																// files
		}
		LOGGER.info(" End : In generateFileToM360App() method of M360AppUtil class");
	}

	
	/**
	 * @param maxLengthTailHeader
	 * @param generateheaderId
	 * @return
	 */
	private static String methodHeaderTailerContent(int maxLengthTailHeader, String generateheaderId) {
		String appender = "0";
		String finalId = null;
		if (generateheaderId.length() < maxLengthTailHeader) {
			int appendingcount = (maxLengthTailHeader - generateheaderId.length());
			for (int count = 1; count < appendingcount; count++) {
				appender = appender + 0;// 1space
			}
			finalId = appender + generateheaderId;
		} else if (generateheaderId.length() == maxLengthTailHeader) {
			finalId = generateheaderId;
		} else if (generateheaderId.length() > maxLengthTailHeader) {
			LOGGER.info("change the sequence");
		}
		return finalId;
	}

	/**
	 * @return
	 */
	private static java.sql.Timestamp getCurrentTimeStamp() {

		java.util.Date today = new java.util.Date();
		return new java.sql.Timestamp(today.getTime());

	}

	public static int getSequenecNumber() throws SQLException, IOException {

		Connection connection = null;
		try {

	        try {
	        	Context ctx=new InitialContext();                       
	        	DataSource ds=(DataSource)ctx.lookup("jdbc/mssqs360");
	        	LOGGER.info("before creating connection");
	        	connection=ds.getConnection(); 
	        	LOGGER.info("after creating connection");
	        } catch(NullPointerException eNP) {
	        	eNP.printStackTrace();        	
	            throw new IllegalArgumentException("M360AppUtil: " + eNP.toString());
	        } catch(Exception ex) {
	        	ex.printStackTrace();
	        }			
			
			int maxID = 1;
			Statement s2 = connection.createStatement();
			s2.execute("SELECT MAX(USER_ID)+1 FROM WB_USER_DETAILS");
			ResultSet rs2 = s2.getResultSet(); //
			if (rs2.next()) {
				maxID = rs2.getInt(1);
			}
			LOGGER.info("SEQUENCE NUMBER IS : "+maxID);
			return maxID;

			// return 1;

		} catch (Exception ex) {
			LOGGER.error("Exception in : get next val class");
			LOGGER.fatal("Connection is lost");
			ex.printStackTrace();
			// return 0;
			return 1;
		} finally {

			if (connection != null && !connection.isClosed()) {
				LOGGER.info("Closing DB connection !!");
				connection.close();
			}
		}
	}
}
