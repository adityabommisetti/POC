package com.medicare.helper;

import java.util.LinkedList;
import java.util.List;

import com.medicare.model.AgencyIdFileField;
import com.medicare.model.ContainsFileField;
import com.medicare.model.DBValueFileField;
import com.medicare.model.DateFileField;
import com.medicare.model.EqualsFileField;
import com.medicare.model.FileField;
import com.medicare.model.FixedValueFileField;
import com.medicare.model.NonAvailableFileField;
import com.medicare.model.PCPCodeFileField;
import com.medicare.model.PCPLocationFileField;
import com.medicare.model.PremiumWithholdFileField;
import com.medicare.model.PrimaryCountyFileField;

public class M360FileMetaData {
	public static List<FileField> fields;

	static {
		fields = new LinkedList<FileField>();
		fields.add(new FixedValueFileField("Record_Type",3,"NMA"));
		fields.add(new DBValueFileField("Application_Category", 3, "Y"));
		fields.add(new DBValueFileField("Application_Nbr", 20, "Y"));
		fields.add(new DateFileField("Application_Date"));
		String[][] prefixArray = { { "Mrs", "MRS." }, { "Mr", "MR. " }, { "Ms", "MS. " } };
		fields.add(new EqualsFileField("Prefix", 4, prefixArray));
		fields.add(new DBValueFileField("Last_Name", 35, "Y"));
		fields.add(new DBValueFileField("First_Name", 24, "Y"));
		fields.add(new DBValueFileField("Middle_Initial", 1, "Y"));
		fields.add(new NonAvailableFileField("Suffix", 4));
		fields.add(new DBValueFileField("HIC_NBR", 12, "Y"));
		fields.add(new NonAvailableFileField("SSN", 9));
		fields.add(new NonAvailableFileField("Past_Supplemental_ID", 15));
		fields.add(new NonAvailableFileField("New_Supplemental_ID", 15));
		fields.add(new NonAvailableFileField("RX_ID", 20));
		fields.add(new DBValueFileField("Primary_Home_Phone", 25, "Y"));
		fields.add(new DBValueFileField("Primary_Work_Phone", 25, "Y"));
		fields.add(new NonAvailableFileField("Primary_Cell_Phone", 25));
		fields.add(new NonAvailableFileField("Primary_Fax_Number", 25));
		fields.add(new DBValueFileField("Primary_Address1", 50, "Y"));
		fields.add(new DBValueFileField("Primary_Address2", 50, "Y"));
		fields.add(new DBValueFileField("Primary_Address3", 50, "Y"));
		fields.add(new DBValueFileField("Primary_City", 20, "Y"));
		fields.add(new DBValueFileField("Primary_State", 2, "Y"));
		fields.add(new DBValueFileField("Primary_Zip", 9, "Y"));
		fields.add(new PrimaryCountyFileField());
		fields.add(new NonAvailableFileField("Primary_Country_Code", 3));
		fields.add(new NonAvailableFileField("Mailing_Last_Name", 35));
		fields.add(new NonAvailableFileField("Mailing_First_Name", 24));
		fields.add(new NonAvailableFileField("Mailing_Middle_Initial", 1));
		fields.add(new NonAvailableFileField("Mailing_Suffix", 4));
		fields.add(new DBValueFileField("Mailing_Address1", 50, "Y"));
		fields.add(new DBValueFileField("Mailing_Address2", 50, "Y"));
		fields.add(new DBValueFileField("Mailing_Address3", 50, "Y"));
		fields.add(new DBValueFileField("Mailing_City", 20, "Y"));
		fields.add(new DBValueFileField("Mailing_State", 2, "Y"));
		fields.add(new DBValueFileField("Mailing_Zip", 9, "Y"));
		fields.add(new NonAvailableFileField("Mailing_Country_Code", 3));
		fields.add(new DBValueFileField("Member_EMail", 50, "Y"));
		fields.add(new DateFileField("Birth_Date"));
		fields.add(new DBValueFileField("Gender", 1, "Y"));
		fields.add(new NonAvailableFileField("Current_Product", 4));
		fields.add(new NonAvailableFileField("Current_Contract", 5));
		fields.add(new NonAvailableFileField("Current_PBP", 3));
		fields.add(new NonAvailableFileField("Current_Segment", 3));
		fields.add(new NonAvailableFileField("Current_Payment_Amt", 10));
		String[] enrollingProdIds = { "049N", "050N", "028N", "048N", "029N", "047N", "044N" };
		fields.add(new ContainsFileField("Enrolling_Product_ID", 4, enrollingProdIds));
		fields.add(new FixedValueFileField("Enrolling_Contract",5, "H3660"));
		fields.add(new DBValueFileField("Enrolling_PBP", 3, "Y"));
		fields.add(new FixedValueFileField("Enrolling_Segment",3, "000"));
		fields.add(new NonAvailableFileField("Enrolling_Payment_Amt", 10));
		fields.add(new DateFileField("Requested_Date_Of_Coverage"));
		fields.add(new FixedValueFileField("Correspondence_Language_Cd",3,"ENG"));
		fields.add(new PCPCodeFileField("PCP_Code", 12));
		fields.add(new PCPLocationFileField("PCP_Location_ID", 2));
		fields.add(new NonAvailableFileField("Current_Patient_Indicator", 1));
		fields.add(new NonAvailableFileField("Future_Use", 12));
		fields.add(new NonAvailableFileField("Future_Use", 1));
		fields.add(new NonAvailableFileField("Future_Use", 10));
		fields.add(new NonAvailableFileField("Future_Use", 12));
		fields.add(new NonAvailableFileField("Future_Use", 1));
		fields.add(new NonAvailableFileField("Future_Use", 10));
		fields.add(new PremiumWithholdFileField());
		fields.add(new DBValueFileField("ESRD_Indicator", 1, "Y"));
		fields.add(new NonAvailableFileField("ESRD_Override_Indicator", 1));
		fields.add(new NonAvailableFileField("Dialysis_Indicator", 1));
		fields.add(new DBValueFileField("Sec_RX_Name", 50, "Y"));	//From DB
		fields.add(new DBValueFileField("Sec_RX_ID", 20, "Y"));		//From DB
		fields.add(new DBValueFileField("Sec_RX_Group", 20, "Y"));	//From DB
		fields.add(new NonAvailableFileField("Sec_RX_BIN", 6));
		fields.add(new NonAvailableFileField("Sec_RX_PCN", 10));
		fields.add(new NonAvailableFileField("LTC_Facility_ID", 6));
		
		// Added for IFOX-00390466 - Retrofit Medicaid ID Changes: Start
		//fields.add(new NonAvailableFileField("Medicaid_Indicator", 1));
		//fields.add(new NonAvailableFileField("Medicaid_ID", 20));
		fields.add(new DBValueFileField("Medicaid_Indicator", 1, "Y"));
		fields.add(new DBValueFileField("Medicaid_ID", 20, "Y"));
		// Added for IFOX-00390466 - Retrofit Medicaid ID Changes: End
		
		fields.add(new NonAvailableFileField("Spouse_Work_Indicator", 1));
		fields.add(new NonAvailableFileField("Out_of_Area_Indicator", 1));
		fields.add(new NonAvailableFileField("Election_Type_Code", 1));
		fields.add(new NonAvailableFileField("Special_Election_Reason_Code", 2));
		fields.add(new DBValueFileField("Signature_On_File_Indicator", 1, "Y"));
		fields.add(new DateFileField("Signature_Date"));
		fields.add(new DBValueFileField("Authorized_Last_Name", 35, "Y"));
		fields.add(new DBValueFileField("Authorized_First_Name", 24, "Y"));
		fields.add(new DBValueFileField("Authorized_Middle_Initial", 1, "Y"));
		fields.add(new DBValueFileField("Authorized_Relationship_Code", 3, "Y"));
		fields.add(new DBValueFileField("Authorized_Address1", 50, "Y"));
		fields.add(new DBValueFileField("Authorized_Address2", 50, "Y"));
		fields.add(new DBValueFileField("Authorized_Address3", 50, "Y"));
		fields.add(new DBValueFileField("Authorized_City", 20, "Y"));
		fields.add(new DBValueFileField("Authorized_State", 2, "Y"));
		fields.add(new DBValueFileField("Authorized_Zip", 9, "Y"));
		fields.add(new NonAvailableFileField("Authorized_Country_Code", 3));
		fields.add(new DBValueFileField("Authorized_Phone", 25, "Y"));
		fields.add(new DBValueFileField("Emergency_Name", 50, "Y"));
		fields.add(new DBValueFileField("Emergency_Phone", 25, "Y"));
		fields.add(new DBValueFileField("Emergency_Relationship_Code", 3, "Y"));
		fields.add(new NonAvailableFileField("Emergency_E_Mail", 50));
		fields.add(new NonAvailableFileField("Insurance_Card_Name", 50));
		fields.add(new AgencyIdFileField());
		fields.add(new NonAvailableFileField("Agency_ID_Secondary", 15));
		fields.add(new NonAvailableFileField("Broker_Agent_ID", 20));
		fields.add(new DBValueFileField("Field_Sales_Rep_ID", 20, "Y"));
		fields.add(new NonAvailableFileField("Billing_Last_Name", 35));
		fields.add(new NonAvailableFileField("Billing_First_Name", 24));
		fields.add(new NonAvailableFileField("Billing_Middle_Initial", 1));
		fields.add(new NonAvailableFileField("Billing_Suffix", 4));
		fields.add(new NonAvailableFileField("Billing_Address1", 50));
		fields.add(new NonAvailableFileField("Billing_Address2", 50));
		fields.add(new NonAvailableFileField("Billing_Address3", 50));
		fields.add(new NonAvailableFileField("Billing_City", 20));
		fields.add(new NonAvailableFileField("Billing_State", 2));
		fields.add(new NonAvailableFileField("Billing_Zip", 9));
		fields.add(new NonAvailableFileField("Billing_Country_Code", 3));
		fields.add(new NonAvailableFileField("Receipt Date", 8));
		fields.add(new NonAvailableFileField("Signature Date Override Ind", 1));
		fields.add(new NonAvailableFileField("Subscriber ID", 10));
		
		fields.add(new NonAvailableFileField("Employer PCP Name", 24));
		fields.add(new DBValueFileField("Account_name", 60,"Y"));     	 	//from db
		fields.add(new DBValueFileField("Bank_Routing_Number", 9, "Y"));		//from DB
		fields.add(new DBValueFileField("Bank_Account_Number", 17, "Y"));			//from DB
		fields.add(new NonAvailableFileField("Bank Acct Type", 1));			//from DB
		fields.add(new NonAvailableFileField("SEP Reason Code 1", 3));
		fields.add(new NonAvailableFileField("SEP Reason Code 1 Date", 8));
		fields.add(new NonAvailableFileField("SEP Reason Code 2", 3));
		fields.add(new NonAvailableFileField("SEP Reason Code 2 Date", 8));
		fields.add(new NonAvailableFileField("SEP Reason Code 3", 3));
		fields.add(new NonAvailableFileField("SEP Reason Code 3 Date", 8));
		fields.add(new NonAvailableFileField("SEP Reason Code 4", 3));
		fields.add(new NonAvailableFileField("SEP Reason Code 4 Date", 8));
		fields.add(new NonAvailableFileField("SEP Reason Code 5", 3));
		fields.add(new NonAvailableFileField("SEP Reason Code 5 Date", 8));
		fields.add(new NonAvailableFileField("Current Group ID", 10));
		fields.add(new NonAvailableFileField("Enrolling Group ID", 10));
		fields.add(new NonAvailableFileField("FILLER", 985));
		
		/*Sentara extra fields
		fields.add(new NonAvailableFileField("ID Card Supress Ind", 1));
		fields.add(new NonAvailableFileField("Agent Signature Date", 8));
		fields.add(new DBValueFileField("Campaign_id", 25, "Y"));
		fields.add(new DBValueFileField("Contract_id", 25, "Y"));
		fields.add(new NonAvailableFileField("Alt_Corres_Ind", 1));
		fields.add(new NonAvailableFileField("FILLER", 111));*/
		
		
		
	/*	//for summacare extra fields after subscriber_id replace the below
		fields.add(new NonAvailableFileField("Employer PCP Name", 24));
		fields.add(new NonAvailableFileField("Name On Acct", 60));     	 	//from db
		fields.add(new NonAvailableFileField("ABA Routing Nbr", 9));		//from DB
		fields.add(new NonAvailableFileField("Bank Acct Nbr", 17));			//from DB
		fields.add(new NonAvailableFileField("Bank Acct Type", 1));			//from DB
		fields.add(new NonAvailableFileField("SEP Reason Code 1", 3));
		fields.add(new NonAvailableFileField("SEP Reason Code 1 Date", 8));
		fields.add(new NonAvailableFileField("SEP Reason Code 2", 3));
		fields.add(new NonAvailableFileField("SEP Reason Code 2 Date", 8));
		fields.add(new NonAvailableFileField("SEP Reason Code 3", 3));
		fields.add(new NonAvailableFileField("SEP Reason Code 3 Date", 8));
		fields.add(new NonAvailableFileField("SEP Reason Code 4", 3));
		fields.add(new NonAvailableFileField("SEP Reason Code 4 Date", 8));
		fields.add(new NonAvailableFileField("SEP Reason Code 5", 3));
		fields.add(new NonAvailableFileField("SEP Reason Code 5 Date", 8));
		fields.add(new NonAvailableFileField("Current Group ID", 10));
		fields.add(new NonAvailableFileField("Enrolling Group ID", 10));
		fields.add(new NonAvailableFileField("FILLER", 985));
		*/
		
		
		/*	//for VAP extra fields after subscriber_id replace the below
			fields.add(new NonAvailableFileField("Filler", 1));
			fields.add(new NonAvailableFileField("Filler", 8));
			fields.add(new NonAvailableFileField("Campaign_ID", 25));
			fields.add(new NonAvailableFileField("Contract_ID", 25));
			fields.add(new NonAvailableFileField("Alt_Corres_Ind", 1));
			fields.add(new NonAvailableFileField("Current Group ID", 10));
			fields.add(new NonAvailableFileField("Enrolling Group ID", 10));
			fields.add(new NonAvailableFileField("SEP Reason Code 1", 3));
			fields.add(new NonAvailableFileField("SEP Reason Code 1 Date", 8));
			fields.add(new NonAvailableFileField("SEP Reason Code 2", 3));
			fields.add(new NonAvailableFileField("SEP Reason Code 2 Date", 8));
			fields.add(new NonAvailableFileField("SEP Reason Code 3", 3));
			fields.add(new NonAvailableFileField("SEP Reason Code 3 Date", 8));
			fields.add(new NonAvailableFileField("SEP Reason Code 4", 3));
			fields.add(new NonAvailableFileField("SEP Reason Code 4 Date", 8));
			fields.add(new NonAvailableFileField("SEP Reason Code 5", 3));
			fields.add(new NonAvailableFileField("SEP Reason Code 5 Date", 8));
			fields.add(new NonAvailableFileField("Plan Year", 4));
			fields.add(new NonAvailableFileField("Name on Bank Account", 60));
			fields.add(new NonAvailableFileField("Bank Name", 30));
			fields.add(new NonAvailableFileField("ABA Routing Nbr", 9));
			fields.add(new NonAvailableFileField("Bank Acct Nbr", 17));
			fields.add(new NonAvailableFileField("Bank Acct Type", 1));
			fields.add(new NonAvailableFileField("Billing Frequency", 1));
			fields.add(new NonAvailableFileField("Draft Day", 2));
			fields.add(new NonAvailableFileField("Filler", 912));
			*/
			
			
		
	}

	/*public static void main(String[] args) {
		int start = 1;
		for(FileField field : fields){
			System.out.println(start + " " + field.getName());
			start += field.getLength();
		}
	}*/

}