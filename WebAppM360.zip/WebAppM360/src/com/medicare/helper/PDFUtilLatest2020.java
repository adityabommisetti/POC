package com.medicare.helper;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.MalformedURLException;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;

//import com.lowagie.text.BaseColor;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.ColumnText;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPageEventHelper;
import com.lowagie.text.pdf.PdfWriter;
import com.medicare.vo.AgreeDetailsVO;
import com.medicare.vo.AttestationDetailsVO;
import com.medicare.vo.PolicyDetailsVO;
import com.medicare.vo.UserDetailsVO;

/**
 * @author SH250285
 * 
 */
public class PDFUtilLatest2020 {
	/*IFOX-00407925--Start*/
	class MyFooter extends PdfPageEventHelper {
        
		//Font ffont = new Font(Font.FontFamily.UNDEFINED, 9, Font.NORMAL);
        Font ffont = new Font(Font.UNDEFINED, 9, Font.NORMAL);
 
        public void onEndPage(PdfWriter writer, Document document) {
            PdfContentByte cb = writer.getDirectContent();
            /* IFOX-00419836 2020 AEP changes. START*/
            Phrase footer = new Phrase("H9877_0519-MEFR-800068_C", ffont);
            /* IFOX-00419836 2020 AEP changes. END*/
            ColumnText.showTextAligned(cb, Element.ALIGN_RIGHT,
                    footer,
                    document.right() - document.rightMargin(),
                    document.bottom() + 15, 0);
        }
    }
	/*IFOX-00407925--End*/
	private final static Logger LOGGER = Logger.getLogger(PDFUtilLatest2019.class.getName());
	private static Image OptimaHealth_Logo;
	//private static Image Medicardlogo_Logo;
	private static Image check;
	private static Image uncheck;
	private static Image buttonCheckImage;
	private static Image buttonUncheckImage;
	private static Image stop;
	private static BaseFont base;
	private static Font font;
	private static Font font2;
	private static String planName="";
	private static String planYear="";
	private static String planNameType="";
	private static String planPremium="";
	/**
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	public static void showEnrollFromsInPDF(HttpServletRequest request, HttpServletResponse response) {

		LOGGER.info(" PDFUtilLatest2019 : showEnrollFromsInPDF : Begin : ");
		
		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			UserDetailsVO pdfUserDetails = (UserDetailsVO) request.getSession().getAttribute("userDetailsObjForm1");
			AgreeDetailsVO pdfAgreeDetails = (AgreeDetailsVO) request.getSession().getAttribute("agreeDetailsObjForm1");
			baos = savePdf(request, response);
			printpdf(baos, response, pdfUserDetails, pdfAgreeDetails);
		} catch (Exception e) {
			LOGGER.error("Exception in : PDFUtilLatest2019 class and showEnrollFromsInPDF method");
			return;
		}
	}

	/**
	 * @param baos
	 * @param response
	 * @param pdfUserDetails
	 * @param pdfAgreeDetails
	 * @throws IOException
	 */
	private static void printpdf(ByteArrayOutputStream baos, HttpServletResponse response, UserDetailsVO pdfUserDetails,
			AgreeDetailsVO pdfAgreeDetails) throws IOException {
		String pdffileFileName = (getChangedValue(pdfUserDetails.getLastName())) + "_" + pdfAgreeDetails.getTodayDate();
		response.addHeader("Content-Disposition", "attachment;filename=" + pdffileFileName + "enrolled.pdf");
		OutputStream os = response.getOutputStream();
		baos.writeTo(os);
		os.flush();
		os.close();
	}

	/**
	 * @param request
	 * @param response
	 * @return
	 */
	private static ByteArrayOutputStream savePdf(HttpServletRequest request, HttpServletResponse response) {

		LOGGER.info(" Start : In showEnrollFromsInPDF() method of PDFUtilLatest2019 class");

		ByteArrayOutputStream baos = new ByteArrayOutputStream();

		UserDetailsVO pdfUserDetails = (UserDetailsVO) request.getSession().getAttribute("userDetailsObjForm1");
		PolicyDetailsVO pdfPolicyDetails = (PolicyDetailsVO) request.getSession().getAttribute("policyDetailsObjForm1");
		AttestationDetailsVO pdfAttestationDetails = (AttestationDetailsVO) request.getSession()
				.getAttribute("attestationDetailsObjForm1");
		AgreeDetailsVO pdfAgreeDetails = (AgreeDetailsVO) request.getSession().getAttribute("agreeDetailsObjForm1");

		Document document = new Document(PageSize.A4, 10, 10, 10, 10);
		PdfWriter writer = null;
		try {

			pdfImageInstances(request);
			pdffontInstances(request);

			writer = PdfWriter.getInstance(document, baos);
			/*IFOX-00407925--Start*/
			PDFUtilLatest2020 ob=new PDFUtilLatest2020();
			ob.setFooter(document,writer);
			/*IFOX-00407925--End*/

			document.open();
			System.out.println("Plan Details for PDF creation.");
			System.out.println("planYear : "+request.getSession().getAttribute("planYear"));
			System.out.println("pbpId : "+request.getSession().getAttribute("pbpId"));
			System.out.println("planName : "+request.getSession().getAttribute("planName"));
			System.out.println("planNameType : "+request.getSession().getAttribute("planNameType"));
			
			if(null != request.getSession().getAttribute("planYear"))
				planYear = request.getSession().getAttribute("planYear").toString();
			if(null != request.getSession().getAttribute("pbpId"))
				setVAPPlanNamePremiumType(request.getSession().getAttribute("pbpId").toString());
			
			PdfPTable logo = page1LogoTable(OptimaHealth_Logo);
			document.add(logo);
			PdfPTable Braille = page1BrailleTable();
			document.add(Braille);
			PdfPTable page4Table2 = pdfPage4Table2();
			document.add(page4Table2);
			
			page1optimaPlanTable(pdfUserDetails, document);
			PdfPTable page1TableUserDetails = page1TabbleUserDetails(pdfUserDetails, document);
			document.add(page1TableUserDetails);
			PdfPTable page1TableMedicarddetails = page1TableMedicareDetails(pdfUserDetails, document);
			document.add(page1TableMedicarddetails);

			document.newPage();

			PdfPTable page2Logotable = page2TableLogo();
			document.add(page2Logotable);
			PdfPTable page2Table1 = pdfPage2Table1(pdfPolicyDetails);
			document.add(page2Table1);
			PdfPTable page2Table2 = pdfPage2Table2(pdfPolicyDetails);
			document.add(page2Table2);

			document.newPage();

			PdfPTable page3Logotable = page2TableLogo();
			document.add(page3Logotable);
			/*
			 * PdfPTable page3Table1 = pdfPage3Table1(pdfAttestationDetails,
			 * document); document.add(page3Table1);
			 */
			PdfPTable page3Table2 = pdfPage3Table2(pdfAttestationDetails);
			document.add(page3Table2);

			
			PdfPTable page4Table1 = pdfPage4Table1(document, page2Logotable);
			document.add(page4Table1);
			PdfPTable page4Table3 = pdfPage4Table3(pdfAgreeDetails);
			document.add(page4Table3);
			document.newPage();

			/*PdfPTable page4Table1 = pdfPage4Table1(document, page2Logotable);
			document.add(page4Table1);*/
			PdfPTable page3Table1 = pdfPage3Table1(pdfAgreeDetails,page2Logotable, document);
			document.add(page3Table1);
			PdfPTable page4Table4 = pdfPage4Table4(pdfAgreeDetails);
			document.add(page4Table4);
			PdfPTable page4Table5 = pdfPage4Table5(pdfAgreeDetails);
			document.add(page4Table5);
			PdfPTable page4Table6 = pdfPage4Table6(pdfAgreeDetails);
			document.add(page4Table6);
			document.close();
			writer.close();
			return baos;

		} catch (Exception e) {
			e.printStackTrace();
			return null;

		} finally {
			if (document != null) {
				document.close();
			}
			if (writer != null) {
				writer.close();
			}
		}

	}
	/*IFOX-00407925--Start*/
	
	private void setFooter(Document document, PdfWriter writer){
		// TODO Auto-generated method stub
		try
		{
			MyFooter event = this.new MyFooter();
	        writer.setPageEvent(event);	
		}
		catch (Exception e) {
			e.printStackTrace();
			if (document != null) {
				document.close();
			}
			if (writer != null) {
				writer.close();
			}
			return;

		}
		
	}
	/*IFOX-00407925--End*/
	/**
	 * @param request
	 * @param response
	 * @return
	 */
	public static byte[] saveBytesPDF(HttpServletRequest request, HttpServletResponse response) {

		try {
			ByteArrayOutputStream baos = savePdf(request, response);

			byte[] pdfData = baos.toByteArray();
			byte[] pdfSave = Base64.encodeBase64(pdfData);
			return pdfSave;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * @param pdfAgreeDetails
	 * @return
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static PdfPTable pdfPage4Table6(AgreeDetailsVO pdfAgreeDetails) throws DocumentException, IOException {
		PdfPTable page4Table6 = new PdfPTable(1);
		page4Table6.setWidthPercentage(100);
		page4Table6.setSpacingBefore(10);
		page4Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		String applicationTypeWebinForm4 = getChangedValue(pdfAgreeDetails.getWebtelApp());
		String applicationTypeTel = getChangedValue(pdfAgreeDetails.getWebtelApp());
		String applicationTypeBrok = getChangedValue(pdfAgreeDetails.getWebtelApp());
		if (applicationTypeWebinForm4.equalsIgnoreCase("WEB")) {
			displayButtonInPDFforForm4ApplicationType(page4Table6, buttonCheckImage, buttonUncheckImage,
					buttonUncheckImage);
		} else if (applicationTypeTel.equalsIgnoreCase("TEL")) {
			displayButtonInPDFforForm4ApplicationType(page4Table6, buttonUncheckImage, buttonCheckImage,
					buttonUncheckImage);
		} else if (applicationTypeBrok.equalsIgnoreCase("AGT")) {
			displayButtonInPDFforForm4ApplicationType(page4Table6, buttonUncheckImage, buttonUncheckImage,
					buttonCheckImage);
		} else {
			displayButtonInPDFforForm4ApplicationType(page4Table6, buttonUncheckImage, buttonUncheckImage,
					buttonUncheckImage);
		}

		PdfPTable page4Table6Cell2table1 = new PdfPTable(2);
		page4Table6Cell2table1.setWidthPercentage(100);
		page4Table6Cell2table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page4Table6Cell2table1
				.addCell(new Phrase("Agent Name : " + (getChangedValue(pdfAgreeDetails.getAgentName())), font));
		page4Table6Cell2table1
				.addCell(new Phrase("VA Premier Agent ID : " + (getChangedValue(pdfAgreeDetails.getAgentId())), font));

		PdfPCell page4table6Cell2 = new PdfPCell(page4Table6Cell2table1);
		page4table6Cell2.setBorderWidthBottom(0.1f);
		page4table6Cell2.setBorderWidthTop(0.1f);
		page4table6Cell2.setBorderColorBottom(java.awt.Color.WHITE);
		page4table6Cell2.setBorderColorTop(java.awt.Color.WHITE);
		page4Table6.addCell(page4table6Cell2);

		PdfPTable page4Table6Cell3table1 = new PdfPTable(2);
		page4Table6Cell3table1.setWidthPercentage(100);
		page4Table6Cell3table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page4Table6Cell3table1
				.addCell(new Phrase("Plan ID # :  " + (getChangedValue(pdfAgreeDetails.getPlanId())), font));
		page4Table6Cell3table1.addCell(new Phrase(
				"Effective Date of Coverage : " + (getChangedValue(pdfAgreeDetails.getEffectDateCoverage())), font));

		PdfPCell page4table6Cell3 = new PdfPCell(page4Table6Cell3table1);
		page4table6Cell3.setBorderWidthBottom(0.1f);
		page4table6Cell3.setBorderWidthTop(0.1f);
		page4table6Cell3.setBorderColorBottom(java.awt.Color.WHITE);
		page4table6Cell3.setBorderColorTop(java.awt.Color.WHITE);
		page4Table6.addCell(page4table6Cell3);

		String ElectionType = (getChangedValue(pdfAgreeDetails.getAep()));

		if (ElectionType.equalsIgnoreCase("A")) {
			ElectionType = "AEP : Annual Election Period";
		} else if (ElectionType.equalsIgnoreCase("I")) {
			ElectionType = "ICEP/IEP : Initial Coverage Election/Initial Enrollment Period";
		} else if (ElectionType.equalsIgnoreCase("s")) {
			ElectionType = "SEP (type) : Special Election Period";
		} else if (ElectionType.equalsIgnoreCase("n")) {
			ElectionType = "Not Eligible";
		} else {
			ElectionType = " ";
		}

		PdfPTable page4Table6Cell4table1 = new PdfPTable(1);
		page4Table6Cell4table1.setWidthPercentage(100);
		page4Table6Cell4table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page4Table6Cell4table1.addCell(new Phrase(ElectionType, font));

		PdfPCell page4table6Cell4 = new PdfPCell(page4Table6Cell4table1);
		page4table6Cell4.setBorderWidthBottom(0.1f);
		page4table6Cell4.setBorderWidthTop(0.1f);
		page4table6Cell4.setBorderColorTop(java.awt.Color.WHITE);
		page4Table6.addCell(page4table6Cell4);
		return page4Table6;
	}

	/**
	 * @param pdfAgreeDetails
	 * @return
	 */
	private static PdfPTable pdfPage4Table5(AgreeDetailsVO pdfAgreeDetails) {

		PdfPTable page4Table5 = new PdfPTable(1);
		page4Table5.setWidthPercentage(100);
		page4Table5.setSpacingBefore(10);
		page4Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPCell page4table5cell1 = new PdfPCell(new Phrase(
				"If you are the authorized representative, you must sign above and provide the following information:",
				font));
		page4table5cell1.setBorderWidthBottom(0.1f);
		//page4Table5.addCell(page4table5cell1);

		PdfPTable page4Table5Cell5table1Lname = new PdfPTable(2);
		page4Table5Cell5table1Lname.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page4Table5Cell5table1Lname.addCell(new Phrase("Name : ", font));
		page4Table5Cell5table1Lname.addCell(new Phrase(getChangedValue(pdfAgreeDetails.getLegalFirstName()), font));

		PdfPTable page4Table5Cell5table1 = new PdfPTable(3);
		page4Table5Cell5table1.setWidthPercentage(100);
		page4Table5Cell5table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page4Table5Cell5table1.addCell(page4Table5Cell5table1Lname);
		/*page4Table5Cell5table1
				.addCell(new Phrase("Last Name : " + (getChangedValue(pdfAgreeDetails.getLegalLastName())), font));
		page4Table5Cell5table1.addCell(
				new Phrase("Middle Initial : " + (getChangedValue(pdfAgreeDetails.getLegalMiddleName())), font));
*/
		PdfPCell page4table5cell2 = new PdfPCell(page4Table5Cell5table1);
		page4table5cell2.setBorderWidthBottom(0.1f);
		page4table5cell2.setBorderColorTop(java.awt.Color.WHITE);
		page4table5cell2.setBorderColorBottom(java.awt.Color.WHITE);
		page4Table5.addCell(page4table5cell2);

		PdfPTable page4Table5Cell3table = new PdfPTable(1);
		page4Table5Cell3table.setWidthPercentage(100);
		page4Table5Cell3table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page4Table5Cell3table
				.addCell(new Phrase("Address : " + (getChangedValue(pdfAgreeDetails.getLegalAddress())), font));
		page4Table5Cell3table.addCell(
				new Phrase("                " + (getChangedValue(pdfAgreeDetails.getLegalAddressTwo())), font));
		page4Table5Cell3table.addCell(
				new Phrase("                " + (getChangedValue(pdfAgreeDetails.getLegalAddressThree())), font));

		PdfPCell page4table5cell3 = new PdfPCell(page4Table5Cell3table);
		page4table5cell3.setBorderWidthBottom(0.1f);
		page4table5cell3.setBorderColorTop(java.awt.Color.WHITE);
		page4table5cell3.setBorderColorBottom(java.awt.Color.WHITE);
		page4Table5.addCell(page4table5cell3);

		PdfPTable page4Table5Cell3newtable = new PdfPTable(3);
		page4Table5Cell3newtable.setWidthPercentage(100);
		page4Table5Cell3newtable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		/*page4Table5Cell3newtable
			.addCell(new Phrase("City or County : " + (getChangedValue(pdfAgreeDetails.getLegalCity())), font));
		page4Table5Cell3newtable
				.addCell(new Phrase("State : " + (getChangedValue(pdfAgreeDetails.getLegalState())), font));
		page4Table5Cell3newtable
				.addCell(new Phrase("ZIP Code : " + (getChangedValue(pdfAgreeDetails.getLegalZipCode())), font));
*/
		PdfPCell page4table5cellnew = new PdfPCell(page4Table5Cell3newtable);
		page4table5cellnew.setBorderWidthBottom(0.1f);
		page4table5cellnew.setBorderColorTop(java.awt.Color.WHITE);
		page4table5cellnew.setBorderColorBottom(java.awt.Color.WHITE);
		page4Table5.addCell(page4table5cellnew);

		String relationshiptoEnrolee = MedicareUtil.getRelationEnrollValues()
				.get(getChangedValue(pdfAgreeDetails.getLegalRelationErloll()));

		relationshiptoEnrolee = relationshiptoEnrolee == null ? ""
				: MedicareUtil.getRelationEnrollValues().get(getChangedValue(pdfAgreeDetails.getLegalRelationErloll()));

		PdfPTable page4Table5Cell1table1 = new PdfPTable(2);
		page4Table5Cell1table1.setWidthPercentage(100);
		page4Table5Cell1table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page4Table5Cell1table1
				.addCell(new Phrase("Phone Number :" + (getChangedValue(pdfAgreeDetails.getLegalPhNumber())), font));
		page4Table5Cell1table1.addCell(new Phrase("Relationship to Enrollee : " + relationshiptoEnrolee, font));

		PdfPCell page4table5cell4 = new PdfPCell(page4Table5Cell1table1);
		page4table5cell4.setBorderWidthBottom(0.1f);
		page4table5cell4.setBorderColorTop(java.awt.Color.WHITE);
		page4Table5.addCell(page4table5cell4);
		return page4Table5;
	}

	/**
	 * @param pdfAgreeDetails
	 * @return
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static PdfPTable pdfPage4Table4(AgreeDetailsVO pdfAgreeDetails) throws DocumentException, IOException {

		PdfPTable page4Table4 = new PdfPTable(1);
		page4Table4.setWidthPercentage(100);
		page4Table4.setSpacingBefore(10);
		page4Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		String checkBoxFlagforform4Agreecell = pdfAgreeDetails.getAgreeStatements();
		String TodayDateValue = pdfAgreeDetails.getTodayDate();
		if (checkBoxFlagforform4Agreecell != null) {
			displayCheckBoxInPDFforForm4table(page4Table4, check, TodayDateValue);
		} else {
			displayCheckBoxInPDFforForm4table(page4Table4, uncheck, TodayDateValue);
		}

		return page4Table4;
	}

	/**
	 * @param pdfAgreeDetails
	 * @return
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static PdfPTable pdfPage4Table3(AgreeDetailsVO pdfAgreeDetails) throws DocumentException, IOException {
		PdfPTable page4Table3 = new PdfPTable(1);
		page4Table3.setWidthPercentage(100);
		page4Table3.setSpacingBefore(10);
		page4Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPCell page4table3cell1 = new PdfPCell(new Phrase(
				"I understand that my signature (or the signature of the person authorized to act on my behalf under the laws "
				+ "of the State where I live) on this application means that I have read and understand the contents of this application. "
				+ "If signed by an authorized individual (as described above), this signature certifies that: \n"
				+ "1) This person is authorized under State law to complete this enrollment and \n"
				+ " 2) Documentation of this authority is available upon request from Medicare.",
				font));
		page4table3cell1.setBorderWidthBottom(0.1f);
		page4Table3.addCell(page4table3cell1);

		return page4Table3;
	}

	/**
	 * @return
	 */
	private static PdfPTable pdfPage4Table2() {
		PdfPTable page4Table2 = new PdfPTable(1);
		page4Table2.setWidthPercentage(100);
		page4Table2.setSpacingBefore(10);
		page4Table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPCell page4table2cell1 = new PdfPCell(new Phrase(
				"Release of Information: "
				+ "By joining this Medicare health plan, I acknowledge that "+planName+" will release my information "
				+ "to Medicare and other plans as is necessary for treatment, payment and health care operations. I also acknowledge "
				+ "that "+planName+" will release my information, including my prescription drug event data, to Medicare, "
				+ "who may release it for research and other purposes which follow all applicable Federal statutes and regulations. "
				+ "The information on this enrollment form is correct to the best of my knowledge. "
				+ "I understand that if I intentionally provide false information on this form, I will be disenrolled from the plan.",
				font));
		page4table2cell1.setBorderWidthBottom(0.1f);
		page4Table2.addCell(page4table2cell1);

		return page4Table2;
	}

	/**
	 * @param document
	 * @param page2Logotable
	 * @return
	 * @throws DocumentException
	 */
	private static PdfPTable pdfPage4Table1(Document document, PdfPTable page2Logotable) throws DocumentException {


		PdfPTable page4Table1 = new PdfPTable(1);
		page4Table1.setWidthPercentage(100);
		page4Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page4Table1.setSpacingBefore(10);

		PdfPCell page4table1cell1 = new PdfPCell(stop);
		page4table1cell1.setBorderWidthBottom(0.1f);
		page4table1cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
		page4table1cell1.setBorderColorBottom(java.awt.Color.GRAY);
		page4table1cell1.setGrayFill(0.65f);
		page4Table1.addCell(page4table1cell1);

		PdfPCell page4table1cell2 = new PdfPCell(
				new Phrase("STOP! Please Read This Important Information", font));
		page4table1cell2.setBorderWidthBottom(0.1f);
		page4table1cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
		page4table1cell2.setBorderColorBottom(java.awt.Color.GRAY);
		page4table1cell2.setBorderColorTop(java.awt.Color.GRAY);
		page4table1cell2.setGrayFill(0.65f);
		page4Table1.addCell(page4table1cell2);

		PdfPCell page4table1cell3 = new PdfPCell(new Phrase(
				"If you currently have health coverage from an employer or union, joining "+planName+" could affect your employer "
				+ "or union health benefits. You could lose your employer or union health coverage if you join "+planName+". "
				+ "Read the communications your employer or union sends you. If you have questions, visit their website, or contact the office listed in their communications. "
				+ "If there isn�t any information on whom to contact, your benefits administrator or the office that answers questions about your coverage can help.",
				font));
		page4table1cell3.setBorderWidthBottom(0.1f);
		page4table1cell3.setBorderColorBottom(java.awt.Color.WHITE);
		page4table1cell3.setBorderColorTop(java.awt.Color.WHITE);
		page4Table1.addCell(page4table1cell3);

		PdfPCell section7 = new PdfPCell(
				new Phrase("Please read below and sign section 7:", font));
		section7.setBorderWidthBottom(0.1f);
		section7.setBorderColorBottom(java.awt.Color.WHITE);
		section7.setBorderColorTop(java.awt.Color.WHITE);
		page4Table1.addCell(section7);
		
		
		PdfPCell page4table1cell4 = new PdfPCell(
				new Phrase("By completing this enrollment application, I agree to the following:", font));
		page4table1cell4.setBorderWidthBottom(0.1f);
		page4table1cell4.setBorderColorBottom(java.awt.Color.WHITE);
		page4table1cell4.setBorderColorTop(java.awt.Color.WHITE);
		page4Table1.addCell(page4table1cell4);

		PdfPCell page4table1cell5 = new PdfPCell(new Phrase(
				""+planName+" is a Medicare Advantage plan and has a contract with the Federal government. "
						+ "I will need to keep my Medicare Parts A and B. I can be in only one Medicare Advantage plan at a time, and "
						+ "I understand that my enrollment in this plan will automatically end my enrollment in another Medicare health "
						+ "plan or prescription drug plan. It is my responsibility to inform you of any prescription drug coverage that "
						+ "I have or may get in the future. Enrollment in this plan is generally for the entire year. Once I enroll, "
						+ "I may leave this plan or make changes only at certain times of the year when an enrollment period is available "
						+ "(example: October 15 � December 7 of every year), or under certain special circumstances.",
				font));
		page4table1cell5.setBorderWidthBottom(0.1f);
		page4table1cell5.setBorderColorBottom(java.awt.Color.WHITE);
		page4table1cell5.setBorderColorTop(java.awt.Color.WHITE);
		page4Table1.addCell(page4table1cell5);

		PdfPCell page4table1cell6 = new PdfPCell(new Phrase(
				""+planName+" serves a specific service area. If I move out of the area that "+planName+" serves, I need to notify the plan so "
						+ "I can disenroll and find a new plan in my new area. Once I am a member of "+planName+", I have the right to appeal plan "
								+ "decisions about payment or services if I disagree. I will read the Member Handbook from "+planName+" "
								+ "when I get it to know which rules I must follow to get coverage with this Medicare Advantage plan. "
								+ "I understand that people with Medicare aren�t usually covered under Medicare while out of the country except "
								+ "for limited coverage near the U.S. border.",
				font));
		page4table1cell6.setBorderWidthBottom(0.1f);
		page4table1cell6.setBorderColorBottom(java.awt.Color.WHITE);
		page4table1cell6.setBorderColorTop(java.awt.Color.WHITE);
		page4Table1.addCell(page4table1cell6);

		PdfPCell page4table1cell7 = new PdfPCell(new Phrase(
				"I understand that beginning on the date "+planName+" coverage begins, I must get all of my health care from "+planName+", except "
						+ "for emergency or urgently needed services or out-of-area dialysis services. Services authorized by "+planName+""
						+ " and other services contained in my  "+planName+" Evidence of Coverage document (also known as a member contract"
						+ " or subscriber agreement) will be covered.",
				font));
		page4table1cell7.setBorderWidthBottom(0.1f);
		page4table1cell7.setBorderColorBottom(java.awt.Color.WHITE);
		page4table1cell7.setBorderColorTop(java.awt.Color.WHITE);
		page4Table1.addCell(page4table1cell7);

		PdfPCell page4table1cell8 = new PdfPCell(new Phrase(
				"Without authorization, NEITHER MEDICARE NOR  "+planName.toUpperCase()+" WILL PAY FOR THE SERVICES.",
				font));
		page4table1cell8.setBorderWidthBottom(0.1f);
		page4table1cell8.setBorderColorBottom(java.awt.Color.WHITE);
		page4table1cell8.setBorderColorTop(java.awt.Color.WHITE);
		page4Table1.addCell(page4table1cell8);

		PdfPCell page4table1cell9 = new PdfPCell(new Phrase(
				"I understand that if I am getting assistance from a sales agent, broker, or other individual employed by or contracted "
				+ "with "+planName+", he/she may be paid based on my enrollment in "+planName+".",
				font));
		page4table1cell9.setBorderWidthBottom(0.1f);
		page4table1cell9.setBorderColorBottom(java.awt.Color.WHITE);
		page4table1cell9.setBorderColorTop(java.awt.Color.WHITE);
		page4Table1.addCell(page4table1cell9);

		PdfPCell page4table1cell10 = new PdfPCell(new Phrase(
				"Release of Information: By joining this Medicare health plan, I acknowledge that  "+planName+" will release "
				+ "my information to Medicare and other plans as is necessary for treatment, payment and health care operations. "
				+ "I also acknowledge that "+planName+" will release my information, including my prescription drug event data, "
				+ "to Medicare, who may release it for research and other purposes which follow all applicable Federal statutes and regulations. "
				+ "The information on this enrollment form is correct to the best of my knowledge. I understand that if I intentionally provide "
				+ "false information on this form, I will be disenrolled from the plan.",
				font));
		page4table1cell10.setBorderWidthBottom(0.1f);
		page4table1cell10.setBorderColorBottom(java.awt.Color.WHITE);
		page4table1cell10.setBorderColorTop(java.awt.Color.WHITE);
		page4Table1.addCell(page4table1cell10);
		

/*		PdfPCell page4table1cell11 = new PdfPCell(new Phrase(
				"The information on this enrollment form is correct to the best of my knowledge. I understand that if I intentionally provide false information on this form, I will be disenrolled from the plan.",
				font));
		page4table1cell11.setBorderWidthBottom(0.1f);
		page4table1cell11.setBorderColorTop(java.awt.Color.WHITE);
		page4Table1.addCell(page4table1cell11);*/
		return page4Table1;
	}

	/**
	 * @param pdfAttestationDetails
	 * @return
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static PdfPTable pdfPage3Table2(AttestationDetailsVO pdfAttestationDetails)
			throws DocumentException, IOException {
		PdfPTable page3Table2 = new PdfPTable(1);
		page3Table2.setWidthPercentage(100);
		page3Table2.setSpacingBefore(15);
		/*IFOX-00407925--Start*/
		PdfPCell page3table2cell1 = new PdfPCell(new Phrase(
				"Please check one of the boxes below if you would prefer us to send you information in a language other than English or in an accessible format: ",
				FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD)));
		/*IFOX-00407925--End*/
		page3table2cell1.setBorderWidthBottom(0.1f);
		page3table2cell1.setBorderColorBottom(java.awt.Color.WHITE);
		page3Table2.addCell(page3table2cell1);

		String checkBoxFlagforTable2Thirdcell = pdfAttestationDetails.getPreferlargePrint();
		String checkBoxFlagforTable2Fourthcell = pdfAttestationDetails.getPreferBraille();

		if (checkBoxFlagforTable2Thirdcell != null && checkBoxFlagforTable2Fourthcell != null) {
			displayCheckBoxInPDFforForm3table2(page3Table2, check, check);
		} else if (checkBoxFlagforTable2Thirdcell != null && checkBoxFlagforTable2Fourthcell == null) {
			displayCheckBoxInPDFforForm3table2(page3Table2, check, uncheck);
		} else if (checkBoxFlagforTable2Thirdcell == null && checkBoxFlagforTable2Fourthcell != null) {
			displayCheckBoxInPDFforForm3table2(page3Table2, uncheck, check);
		} else {
			displayCheckBoxInPDFforForm3table2(page3Table2, uncheck, uncheck);
		}
		/*IFOX-00407925--Start*/
		PdfPCell page3table2cell2 = new PdfPCell(new Phrase(
				"Please contact "+planName+" at 1-833-280-1194 if you need information in an accessible "
			+ "format or language other than what is listed above.�Our office hours are "
			+ "8:00 am to 8:00 pm, 7 days a week from October 1 to March 31. From April 1 through September 30, we are open Monday through Friday, "
			+ "8:00 am to 8:00 pm. On certain holidays and weekends from April 1 through "
			+ "September 30, your call will be handled by our automated phone system. TTY users "
			+ "should call 711.",font));
		/*IFOX-00407925--End*/
		page3table2cell2.setBorderWidthBottom(0.1f);
		page3table2cell2.setBorderColorTop(java.awt.Color.WHITE);
		page3table2cell2.setBorderColorBottom(java.awt.Color.BLACK);
		page3Table2.addCell(page3table2cell2);
		return page3Table2;
	}

	/**
	 * @param pdfAgreeDetails
	 * @param document
	 * @param page2Logotable
	 * @return
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static PdfPTable pdfPage3Table1(AgreeDetailsVO pdfAgreeDetails, PdfPTable page2Logotable, Document document)
			throws DocumentException, IOException {

		

		PdfPTable page4Logotable = new PdfPTable(1);
		page4Logotable.setWidthPercentage(100);
		page4Logotable.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		page4Logotable.addCell(page2Logotable);
		document.add(page4Logotable);
		
		PdfPTable page3Table1 = new PdfPTable(1);
		page3Table1.setWidthPercentage(100);
		page3Table1.setSpacingBefore(10);

		PdfPCell page3table1cell1 = new PdfPCell(new Phrase("Eligibility Attestation for Enrollment: ",
				FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD)));
		page3table1cell1.setBorderWidthBottom(0.1f);
		page3table1cell1.setBorderColorBottom(java.awt.Color.WHITE);
		page3Table1.addCell(page3table1cell1);

		String checkBoxFlagforCell1Firstcell = getChangedValue(pdfAgreeDetails.getEligibleEnroll());
		String checkBoxFlagforcell1Secondcell = getChangedValue(pdfAgreeDetails.getRecentlyCreditable());
		String phrase1 = null;
		String phrase2 = null;

		phrase1 = "I am new to Medicare. ";
		phrase2 = "I recently moved outside of the service area for my current plan or I recently moved and this plan is a new option for me. I moved on (insert date)  "
				+ (getChangedValue(checkBoxFlagforcell1Secondcell));

		PdfPTable page3Cell2Table1firstcheck = new PdfPTable(2);
		PdfPTable page3Cell2Table1secondcheck = new PdfPTable(2);
		PdfPTable page3Cell2Table1 = new PdfPTable(2);

		if (!checkBoxFlagforCell1Firstcell.isEmpty() && !checkBoxFlagforcell1Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, check, check, page3Cell2Table1firstcheck,
					page3Cell2Table1secondcheck, page3Cell2Table1);
		} else if (!checkBoxFlagforCell1Firstcell.isEmpty() && checkBoxFlagforcell1Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, check, uncheck, page3Cell2Table1firstcheck,
					page3Cell2Table1secondcheck, page3Cell2Table1);
		} else if (checkBoxFlagforCell1Firstcell.isEmpty() && !checkBoxFlagforcell1Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, uncheck, check, page3Cell2Table1firstcheck,
					page3Cell2Table1secondcheck, page3Cell2Table1);
		} else {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, uncheck, uncheck, page3Cell2Table1firstcheck,
					page3Cell2Table1secondcheck, page3Cell2Table1);
		}

		String checkBoxFlagforCell2Firstcell = getChangedValue(pdfAgreeDetails.getNewlyEligbleMedicare());
		String checkBoxFlagforcell2Secondcell = getChangedValue(pdfAgreeDetails.getRecieveMedicareDrugs());

		phrase1 = "I recently was released from incarceration. I was released on (insert date)  "
				+ (getChangedValue(checkBoxFlagforCell2Firstcell));
		phrase2 = "I recently returned to the United States after living permanently outside of the U.S. I returned to the U.S.on (insert date)  "
				+ (getChangedValue(checkBoxFlagforcell2Secondcell));

		PdfPTable page3Cell3Table1firstcheck = new PdfPTable(2);
		PdfPTable page3Cell3Table1secondcheck = new PdfPTable(2);
		PdfPTable page3Cell3Table1 = new PdfPTable(2);
		if (!checkBoxFlagforCell2Firstcell.isEmpty() && !checkBoxFlagforcell2Secondcell.isEmpty()) {

			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, check, check, page3Cell3Table1firstcheck,
					page3Cell3Table1secondcheck, page3Cell3Table1);
		} else if (!checkBoxFlagforCell2Firstcell.isEmpty() && checkBoxFlagforcell2Secondcell.isEmpty()) {

			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, check, uncheck, page3Cell3Table1firstcheck,
					page3Cell3Table1secondcheck, page3Cell3Table1);
		} else if (checkBoxFlagforCell2Firstcell.isEmpty() && !checkBoxFlagforcell2Secondcell.isEmpty()) {

			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, uncheck, check, page3Cell3Table1firstcheck,
					page3Cell3Table1secondcheck, page3Cell3Table1);
		} else {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, uncheck, uncheck, page3Cell3Table1firstcheck,
					page3Cell3Table1secondcheck, page3Cell3Table1);
		}

		
		//Begin: 2019 Attestation Changes
		String checkBoxFlagforCell3Firstcell = getChangedValue(pdfAgreeDetails.getLeavingEmployerCoverage());
		//String checkBoxFlagforcell3Secondcell = getChangedValue(pdfAgreeDetails.getNoEligbPrescDrugs());
		String checkBoxFlagforcell3Secondcell = getChangedValue(pdfAgreeDetails.getChangeInMedicaid());

		phrase1 = "I recently obtained lawful presence status in the United States. I got this status on (insert date)  "
				+ (getChangedValue(checkBoxFlagforCell3Firstcell));
		
		//phrase2 = "I have both Medicare and Medicaid or my state helps pay for my Medicare premiums. "
			//	+ (getChangedValue(checkBoxFlagforcell3Secondcell));
		
		//phrase2 = "I have both Medicare and Medicaid (or my state helps pay for my Medicare premiums) or I get Extra Help paying for my Medicare prescription drug coverage, but I haven't had a change. "
		//	+ (getChangedValue(checkBoxFlagforcell3Secondcell));
		
		phrase2 = "I recently had a change in my Medicaid (newly got Medicaid, had a change in level of Medicaid assistance, or lost Medicaid) on (insert date)  "
				+ (getChangedValue(checkBoxFlagforcell3Secondcell));	

		//End: 2019 Attestation Changes
		
		PdfPTable page3Cell4Table1firstcheck = new PdfPTable(2);
		PdfPTable page3Cell4Table1secondcheck = new PdfPTable(2);
		PdfPTable page3Cell4Table1 = new PdfPTable(2);
		if (!checkBoxFlagforCell3Firstcell.isEmpty() && !checkBoxFlagforcell3Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, check, check, page3Cell4Table1firstcheck,
					page3Cell4Table1secondcheck, page3Cell4Table1);
		} else if (!checkBoxFlagforCell3Firstcell.isEmpty() && checkBoxFlagforcell3Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, check, uncheck, page3Cell4Table1firstcheck,
					page3Cell4Table1secondcheck, page3Cell4Table1);
		} else if (checkBoxFlagforCell3Firstcell.isEmpty() && !checkBoxFlagforcell3Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, uncheck, check, page3Cell4Table1firstcheck,
					page3Cell4Table1secondcheck, page3Cell4Table1);
		} else {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, uncheck, uncheck, page3Cell4Table1firstcheck,
					page3Cell4Table1secondcheck, page3Cell4Table1);
		}

		
		//Begin: 2019 Attestation Changes
		String checkBoxFlagforCell3Thirdcell = getChangedValue(pdfAgreeDetails.getChangeInExtraHelp());
		String checkBoxFlagforcell3Fourthcell = getChangedValue(pdfAgreeDetails.getNlElgPrescChBox());

		phrase1 = "I recently had a change in my Extra Help paying for Medicare prescription drug coverage (newly got Extra Help, had a change in the level of Extra Help, or lost Extra Help) on (insert date)  "
				+ (getChangedValue(checkBoxFlagforCell3Thirdcell));

		phrase2 = "I have both Medicare and Medicaid (or my state helps pay for my Medicare premiums) or I get Extra Help paying for my Medicare prescription drug coverage, but I haven't had a change. ";	
		
		PdfPTable page3Cell3ThirdCellTable = new PdfPTable(2);
		PdfPTable page3Cell3FourthCellTable = new PdfPTable(2);
		PdfPTable pdfPTable = new PdfPTable(2);
		if (!checkBoxFlagforCell3Thirdcell.isEmpty() && !checkBoxFlagforcell3Fourthcell.isEmpty()) {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, check, check, page3Cell3ThirdCellTable,
					page3Cell3FourthCellTable, pdfPTable);
		} else if (!checkBoxFlagforCell3Thirdcell.isEmpty() && checkBoxFlagforcell3Fourthcell.isEmpty()) {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, check, uncheck, page3Cell3ThirdCellTable,
					page3Cell3FourthCellTable, pdfPTable);
		} else if (checkBoxFlagforCell3Thirdcell.isEmpty() && !checkBoxFlagforcell3Fourthcell.isEmpty()) {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, uncheck, check, page3Cell3ThirdCellTable,
					page3Cell3FourthCellTable, pdfPTable);
		} else {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, uncheck, uncheck, page3Cell3ThirdCellTable,
					page3Cell3FourthCellTable, pdfPTable);
		}
		//End: 2019 Attestation Changes

		
		String checkBoxFlagforCell4Firstcell = getChangedValue(pdfAgreeDetails.getRecentMovedOption());
		String checkBoxFlagforcell4Secondcell = getChangedValue(pdfAgreeDetails.getRecntMovedOutSide());

		phrase1 = "I get extra help paying for Medicare prescription drug coverage."
				+ (getChangedValue(checkBoxFlagforCell4Firstcell));
		phrase2 = "I no longer qualify for extra help paying for my Medicare prescription drugs. I stopped receiving extrahelp on (insert date)  "
				+ (getChangedValue(checkBoxFlagforcell4Secondcell));

		PdfPTable page3Cell5Table1firstcheck = new PdfPTable(2);
		PdfPTable page3Cell5Table1secondcheck = new PdfPTable(2);
		PdfPTable page3Cell5Table1 = new PdfPTable(2);
		if (!checkBoxFlagforCell4Firstcell.isEmpty() && !checkBoxFlagforcell4Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, check, check, page3Cell5Table1firstcheck,
					page3Cell5Table1secondcheck, page3Cell5Table1);
		} else if (!checkBoxFlagforCell4Firstcell.isEmpty() && checkBoxFlagforcell4Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, check, uncheck, page3Cell5Table1firstcheck,
					page3Cell5Table1secondcheck, page3Cell5Table1);
		} else if (checkBoxFlagforCell4Firstcell.isEmpty() && !checkBoxFlagforcell4Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, uncheck, check, page3Cell5Table1firstcheck,
					page3Cell5Table1secondcheck, page3Cell5Table1);
		} else {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, uncheck, uncheck, page3Cell5Table1firstcheck,
					page3Cell5Table1secondcheck, page3Cell5Table1);
		}

		String checkBoxFlagforCell5Firstcell = getChangedValue((pdfAgreeDetails.getNoEligSpecial()));
		String checkBoxFlagforcell5Secondcell = getChangedValue(pdfAgreeDetails.getRecntLeftPace());
		phrase1 = "I am moving into, live in, or recently moved out of a Long-Term Care Facility (for example, a nursinghome or long term care facility)."
				+ "I moved/will move into/out of the facility on (insert date)  "
				+ (getChangedValue(checkBoxFlagforCell5Firstcell));
		phrase2 = "I recently left a " + "PACE program on (insert date)  "+ (getChangedValue(checkBoxFlagforcell5Secondcell));

		PdfPTable page3Cell6Table1firstcheck = new PdfPTable(2);
		PdfPTable page3Cell6Table1secondcheck = new PdfPTable(2);
		PdfPTable page3Cell6Table1 = new PdfPTable(2);
		if (!checkBoxFlagforCell5Firstcell.isEmpty() && !checkBoxFlagforcell5Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, check, check, page3Cell6Table1firstcheck,
					page3Cell6Table1secondcheck, page3Cell6Table1);
		} else if (!checkBoxFlagforCell5Firstcell.isEmpty() && checkBoxFlagforcell5Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, check, uncheck, page3Cell6Table1firstcheck,
					page3Cell6Table1secondcheck, page3Cell6Table1);
		} else if (checkBoxFlagforCell5Firstcell.isEmpty() && !checkBoxFlagforcell5Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, uncheck, check, page3Cell6Table1firstcheck,
					page3Cell6Table1secondcheck, page3Cell6Table1);
		} else {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, uncheck, uncheck, page3Cell6Table1firstcheck,
					page3Cell6Table1secondcheck, page3Cell6Table1);
		}
		
		
		String checkBoxFlagforcreditprescell = getChangedValue((pdfAgreeDetails.getMovedBackUs()));
		String checkBoxFlagforunioncoveragecell = getChangedValue(pdfAgreeDetails.getUnionCoverage());
		phrase1 = "I recently involuntarily lost my creditable prescription drug coverage (coverage as good as Medicare�s). I lost my drug coverage on (insert date)  "
				+ (getChangedValue(checkBoxFlagforcreditprescell));
		phrase2 = "I am leaving employer or union coverage on (insert date)  "+ (getChangedValue(checkBoxFlagforunioncoveragecell));

		PdfPTable page3Cell6creditprescheck = new PdfPTable(2);
		PdfPTable page3Cell6unioncoveragecheck = new PdfPTable(2);
		PdfPTable page3credituni = new PdfPTable(2);
		if (!checkBoxFlagforcreditprescell.isEmpty() && !checkBoxFlagforunioncoveragecell.isEmpty()) {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, check, check, page3Cell6creditprescheck,
					page3Cell6unioncoveragecheck, page3credituni);
		} else if (!checkBoxFlagforcreditprescell.isEmpty() && checkBoxFlagforunioncoveragecell.isEmpty()) {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, check, uncheck, page3Cell6creditprescheck,
					page3Cell6unioncoveragecheck, page3credituni);
		} else if (checkBoxFlagforcreditprescell.isEmpty() && !checkBoxFlagforunioncoveragecell.isEmpty()) {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, uncheck, check, page3Cell6creditprescheck,
					page3Cell6unioncoveragecheck, page3credituni);
		} else {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, uncheck, uncheck, page3Cell6creditprescheck,
					page3Cell6unioncoveragecheck, page3credituni);
		}

		String checkBoxFlagforCell6Firstcell = getChangedValue(pdfAgreeDetails.getBelongStatePharmacy());
		String checkBoxFlagforcell6Secondcell = getChangedValue(pdfAgreeDetails.getNoneApplyMe());

		phrase1 = "I belong to a pharmacy assistance program provided by my state.";
		phrase2 = "My plan is ending its contract with Medicare, or Medicare is ending its contract with my plan.";

		PdfPTable page3Cell7Table1firstcheck = new PdfPTable(2);
		PdfPTable page3Cell7Table1secondcheck = new PdfPTable(2);
		PdfPTable page3Cell7Table1 = new PdfPTable(2);
		if (!checkBoxFlagforCell6Firstcell.isEmpty() && !checkBoxFlagforcell6Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, check, check, page3Cell7Table1firstcheck,
					page3Cell7Table1secondcheck, page3Cell7Table1);
		} else if (!checkBoxFlagforCell6Firstcell.isEmpty() && checkBoxFlagforcell6Secondcell.isEmpty()) {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, check, uncheck, page3Cell7Table1firstcheck,
					page3Cell7Table1secondcheck, page3Cell7Table1);
		} else if (checkBoxFlagforCell6Firstcell.isEmpty() && !checkBoxFlagforcell6Secondcell.isEmpty()) {

			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, uncheck, check, page3Cell7Table1firstcheck,
					page3Cell7Table1secondcheck, page3Cell7Table1);
		} else {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, uncheck, uncheck, page3Cell7Table1firstcheck,
					page3Cell7Table1secondcheck, page3Cell7Table1);
		}

		/*String checkBoxFlagForCellUS = getChangedValue(pdfAgreeDetails.getMovedBackUs());
		if (!checkBoxFlagForCellUS.isEmpty()) {
			displayCheckBoxInPDFforForm3table1cellUS(page3Table1, check, checkBoxFlagForCellUS);
		} else {
			displayCheckBoxInPDFforForm3table1cellUS(page3Table1, uncheck, checkBoxFlagForCellUS);
		}*/

		String checkBoxFlagforCell7 = getChangedValue(pdfAgreeDetails.getMedicardNumber());
		if (!checkBoxFlagforCell7.isEmpty()) {
			displayCheckBoxInPDFforForm3table1cell8(page3Table1, check, checkBoxFlagforCell7);
		} else {
			displayCheckBoxInPDFforForm3table1cell8(page3Table1, uncheck, checkBoxFlagforCell7);
		}

		String checkBoxFlagforCell8 = getChangedValue(pdfAgreeDetails.getOutLongTermFacility());
		if (!checkBoxFlagforCell8.isEmpty()) {
			displayCheckBoxInPDFforForm3table1cell9(page3Table1, check, checkBoxFlagforCell8);
		} else {
			displayCheckBoxInPDFforForm3table1cell9(page3Table1, uncheck, checkBoxFlagforCell8);
		}

		/*
		 * PdfPTable page3Cell10Table1 = new PdfPTable(3);
		 * page3Cell10Table1.setWidthPercentage(100);
		 * page3Cell10Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		 * page3Cell10Table1.setWidths(new int[] { 30, 40, 70 });
		 * page3Cell10Table1.addCell(new Phrase("Name of Institution : ",
		 * font)); page3Cell10Table1.addCell(new
		 * Phrase((getChangedValue(pdfAttestationDetails.getNameOfInst())),
		 * font)); page3Cell10Table1 .addCell(new Phrase("Phone Number : " +
		 * getChangedValue(pdfAttestationDetails.getPhNum()), font));
		 * 
		 * PdfPCell page3table1cell10 = new PdfPCell(page3Cell10Table1);
		 * page3table1cell10.setBorderWidthBottom(0.1f);
		 * page3table1cell10.setBorderColorBottom(java.awt.Color.WHITE);
		 * page3table1cell10.setBorderColorTop(java.awt.Color.WHITE);
		 * page3Table1.addCell(page3table1cell10);
		 * 
		 * PdfPTable page3Cell11Table1 = new PdfPTable(1);
		 * page3Cell11Table1.setWidthPercentage(100);
		 * page3Cell11Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		 * page3Cell11Table1.addCell(new Phrase(
		 * "Address of Institution (number and street) : " +
		 * getChangedValue(pdfAttestationDetails.getAdressInstStreet()), font));
		 * page3Cell11Table1.addCell(new Phrase(
		 * "                                                                   : "
		 * + getChangedValue(pdfAttestationDetails.getAdressInstNumber()),
		 * font));
		 * 
		 * PdfPCell page3table1cell11 = new PdfPCell(page3Cell11Table1);
		 * page3table1cell11.setBorderWidthBottom(0.1f);
		 * page3table1cell11.setBorderColorBottom(java.awt.Color.WHITE);
		 * page3table1cell11.setBorderColorTop(java.awt.Color.WHITE);
		 * page3Table1.addCell(page3table1cell11);
		 */
		
		/*
		String checkBoxFlagforCell10 = getChangedValue(pdfAgreeDetails.getOutLongTermFacility());
		if (!checkBoxFlagforCell10.isEmpty()) {
			displayCheckBoxInPDFforForm3table1cell10(page3Table1, check, checkBoxFlagforCell10);
		} else {
			displayCheckBoxInPDFforForm3table1cell10(page3Table1, uncheck, checkBoxFlagforCell10);
		}
		*/
		
		
		//Begin: 2019 Attestation Changes

		String medicareCheckBoxFlagCell = getChangedValue(pdfAgreeDetails.getChangeInMedicare());
		String ltcCheckBoxFlagCell = getChangedValue(pdfAgreeDetails.getOutLongTermFacility());

		phrase1 = "I was enrolled in a plan by Medicare (or my state) and I want to choose a different plan. My enrollment in that plan started on (insert date) "
				+ (getChangedValue(medicareCheckBoxFlagCell));

		phrase2 = "I was enrolled in a Special Needs Plan (SNP) but I have lost the special needs qualification required tobe in that plan. I was disenrolled from the SNP on (insert date) "
			+ (getChangedValue(ltcCheckBoxFlagCell));	
		
		PdfPTable page3LastCellTable1 = new PdfPTable(2);
		PdfPTable page3LastCellTable2 = new PdfPTable(2);
		PdfPTable page3LastCellTable = new PdfPTable(2);

		if (!medicareCheckBoxFlagCell.isEmpty() && !ltcCheckBoxFlagCell.isEmpty()) {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, check, check, page3LastCellTable1,
					page3LastCellTable2, page3LastCellTable);
		} else if (!medicareCheckBoxFlagCell.isEmpty() && ltcCheckBoxFlagCell.isEmpty()) {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, check, uncheck, page3LastCellTable1,
					page3LastCellTable2, page3LastCellTable);
		} else if (medicareCheckBoxFlagCell.isEmpty() && !ltcCheckBoxFlagCell.isEmpty()) {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, uncheck, check, page3LastCellTable1,
					page3LastCellTable2, page3LastCellTable);
		} else {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, uncheck, uncheck, page3LastCellTable1,
					page3LastCellTable2, page3LastCellTable);
		}
		
		
		String checkBoxFlagforAffectedByDisasterCell = getChangedValue(pdfAgreeDetails.getAffectedByDisaster());
		String checkBoxFlagforCell4Firstcell_tmp = getChangedValue(pdfAgreeDetails.getMAOEPChange());
		phrase1 = "I was affected by a weather-related emergency or major disaster (as declared by the Federal Emergency Management Agency (FEMA)."
				+ " One of the other statements here applied to me, but I was unable to make my enrollment because of the natural disaster. ";

		phrase2 = "I am enrolled in a Medicare Advantage plan and want to make a change during the Medicare Advantage Open Enrollment Period (MA OEP).";	
		
		PdfPTable page3table1cell10check01 = new PdfPTable(2);
		PdfPTable page3table1cell10check02 = new PdfPTable(2);
		PdfPTable page3table1cell10check = new PdfPTable(2);

		if (!checkBoxFlagforAffectedByDisasterCell.isEmpty() && !checkBoxFlagforCell4Firstcell_tmp.isEmpty()) {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, check, check, page3table1cell10check01,
					page3table1cell10check02, page3table1cell10check);
		} else if (!checkBoxFlagforAffectedByDisasterCell.isEmpty() && checkBoxFlagforCell4Firstcell_tmp.isEmpty()) {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, check, uncheck, page3table1cell10check01,
					page3table1cell10check02, page3table1cell10check);
		} else if (checkBoxFlagforAffectedByDisasterCell.isEmpty() && !checkBoxFlagforCell4Firstcell_tmp.isEmpty()) {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, uncheck, check, page3table1cell10check01,
					page3table1cell10check02, page3LastCellTable);
		} else {
			displayCheckBoxInPDFforForm3(page3Table1, phrase1, phrase2, uncheck, uncheck, page3table1cell10check01,
					page3table1cell10check02, page3table1cell10check);
		}
		
		//End: 2019 Attestation Changes
		

		/*
		PdfPCell page3table1cell114 = new PdfPCell(new Phrase("If none of these statements applies to you or you�re not sure,"
				+ " please call "+planName+" at 877-739-1370> (TTY users should call 711) to see if you�re "
				+ "eligible to enroll. We are open 7 days a week, 8 am to 8 pm (Oct. 1 to Feb 14); Monday through Friday, 8 am to 8 pm (Feb. 15 to Sept. 30).",
				font));
		*/
		PdfPCell page3table1cell114 = new PdfPCell(new Phrase("If none of these statements applies to you or you're not sure, please contact " + planName +
				" at 1-833-280-1194 (TTY users should call 711) to see if you are eligible to enroll. We are open 8:00 am to 8:00 pm, 7 days a week"+
				" from October 1 to March 31. From April 1 through September 30, we are open Monday through Friday, 8:00 am to 8:00 pm."+
				" On certain holidays and weekends from April 1 through September 30, your call will be handled by our automated phone system.",
				font));
		
		page3table1cell114.setBorderWidthBottom(0.1f);
		page3table1cell114.setBorderColorTop(java.awt.Color.WHITE);
		page3Table1.addCell(page3table1cell114);
		return page3Table1;
	}

	/**
	 * @param pdfPolicyDetails
	 * @return
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static PdfPTable pdfPage2Table2(PolicyDetailsVO pdfPolicyDetails) throws DocumentException, IOException {

		PdfPTable page2Table2 = new PdfPTable(1);
		page2Table2.setWidthPercentage(100);
		page2Table2.setSpacingBefore(10);

		PdfPCell page2table2cell1 = new PdfPCell(new Phrase("Please read and answer these important questions:",
				FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD)));
		page2table2cell1.setGrayFill(0.85f);
		page2table2cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
		page2table2cell1.setBorderWidthBottom(0.1f);
		page2table2cell1.setBorderColorBottom(java.awt.Color.WHITE);

		page2Table2.addCell(page2table2cell1);

		String radioButtonFlagfortable2cell1 = pdfPolicyDetails.getRenalDisease();
		if (radioButtonFlagfortable2cell1 != null && radioButtonFlagfortable2cell1.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell1(page2Table2, buttonCheckImage, buttonUncheckImage);
		} else if (radioButtonFlagfortable2cell1 == null) {
			displayButtonInPDFforForm2table2cell1(page2Table2, buttonUncheckImage, buttonUncheckImage);
		} else {
			displayButtonInPDFforForm2table2cell1(page2Table2, buttonUncheckImage, buttonCheckImage);
		}

		PdfPCell page2table2cell3 = new PdfPCell(new Phrase(
				"If you have had a successful kidney transplant and/or you don�t need regular dialysis any more, please attach a note or records from your doctor showing you have had a successful kidney transplant or you don�t need dialysis. Otherwise, we may need to contact you to obtain additional information.",
				font));
		page2table2cell3.setBorderWidthBottom(0.1f);
		page2table2cell3.setBorderColorBottom(java.awt.Color.WHITE);
		page2table2cell3.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(page2table2cell3);

		String radioButtonFlagfortable2cell2 = pdfPolicyDetails.getHealthBenefits();
		if (radioButtonFlagfortable2cell2 != null && radioButtonFlagfortable2cell2.equalsIgnoreCase("Y")) {
			displayButtonInPDFforForm2table2cell2(page2Table2, buttonCheckImage, buttonUncheckImage);
		} else if (radioButtonFlagfortable2cell2 == null) {
			displayButtonInPDFforForm2table2cell2(page2Table2, buttonUncheckImage, buttonUncheckImage);
		} else {
			displayButtonInPDFforForm2table2cell2(page2Table2, buttonUncheckImage, buttonCheckImage);
		}

		PdfPCell page2table2cell5 = new PdfPCell(new Phrase(
				"If yes, please list your other coverage and your identification (ID) numbers(s) for this coverage:",
				font));
		page2table2cell5.setBorderWidthBottom(0.1f);
		page2table2cell5.setBorderColorBottom(java.awt.Color.WHITE);
		page2table2cell5.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(page2table2cell5);

		PdfPTable page2table2cell6_table1 = new PdfPTable(4);
		page2table2cell6_table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2table2cell6_table1.addCell(new Phrase("Name of other coverage : ", font));
		page2table2cell6_table1.addCell(new Phrase("ID# for this coverage: ", font));
		page2table2cell6_table1.addCell(new Phrase("Group # for this coverage:", font));
		page2table2cell6_table1.addCell(new Phrase("Ending Coverage Date:", font));

		PdfPCell page2table2cell6 = new PdfPCell(page2table2cell6_table1);
		page2table2cell6.setBorderWidthBottom(0.1f);
		page2table2cell6.setBorderColorBottom(java.awt.Color.WHITE);
		page2table2cell6.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(page2table2cell6);

		PdfPTable page2table2cell6_table2 = new PdfPTable(4);
		page2table2cell6_table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2table2cell6_table2.addCell(new Phrase((getChangedValue(pdfPolicyDetails.getMedicalNameCoverage())), font));
		page2table2cell6_table2.addCell(new Phrase((getChangedValue(pdfPolicyDetails.getMedicalIdCoverage())), font));
		page2table2cell6_table2
				.addCell(new Phrase((getChangedValue(pdfPolicyDetails.getMedicalGroupCoverage())), font));
		page2table2cell6_table2
				.addCell(new Phrase((getChangedValue(pdfPolicyDetails.getMedicalCoveragePeriod())), font));

		PdfPCell page2table2cell7 = new PdfPCell(page2table2cell6_table2);
		page2table2cell7.setBorderWidthBottom(0.1f);
		page2table2cell7.setBorderColorBottom(java.awt.Color.WHITE);
		page2table2cell7.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(page2table2cell7);

		PdfPTable page2table2cell8_table2 = new PdfPTable(4);
		page2table2cell8_table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2table2cell8_table2
				.addCell(new Phrase((getChangedValue(pdfPolicyDetails.getOtherMedicalNameCoverage())), font));
		page2table2cell8_table2
				.addCell(new Phrase((getChangedValue(pdfPolicyDetails.getOtherMedicalIdCoverage())), font));
		page2table2cell8_table2
				.addCell(new Phrase((getChangedValue(pdfPolicyDetails.getOtherMedicalGroupCoverage())), font));
		page2table2cell8_table2
				.addCell(new Phrase((getChangedValue(pdfPolicyDetails.getOtherMedicalCoveragePeriod())), font));

		PdfPCell page2table2cell8 = new PdfPCell(page2table2cell8_table2);
		page2table2cell8.setBorderWidthBottom(0.1f);
		page2table2cell8.setBorderColorBottom(java.awt.Color.WHITE);
		page2table2cell8.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(page2table2cell8);

		PdfPTable longTermFacQuestion = new PdfPTable(5);
		longTermFacQuestion.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		longTermFacQuestion.setWidths(new int[] { 200, 6, 10, 6, 10 });
		String radioButtonnursinghome = pdfPolicyDetails.getNursingHome();
		if (radioButtonnursinghome != null && radioButtonnursinghome.equalsIgnoreCase("Y")) {
			displayButtonInPDFfornursingHome(page2Table2, buttonCheckImage, buttonUncheckImage);
		} else if (radioButtonnursinghome == null) {
			displayButtonInPDFfornursingHome(page2Table2, buttonUncheckImage, buttonUncheckImage);
		} else {
			displayButtonInPDFfornursingHome(page2Table2, buttonUncheckImage, buttonCheckImage);
		}

		PdfPCell page2table2cell9 = new PdfPCell(longTermFacQuestion);
		page2table2cell9.setBorderWidthBottom(0.1f);
		page2table2cell9.setBorderColorBottom(java.awt.Color.WHITE);
		page2table2cell9.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(page2table2cell9);

		PdfPCell longTermFacAddtnInfoMessage = new PdfPCell(
				new Phrase("If yes, please provide the following information:", font));
		longTermFacAddtnInfoMessage.setBorderWidthBottom(0.1f);
		longTermFacAddtnInfoMessage.setBorderColorBottom(java.awt.Color.WHITE);
		longTermFacAddtnInfoMessage.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(longTermFacAddtnInfoMessage);

		PdfPCell nameOfInstitute = new PdfPCell(
				new Phrase("Name of Institution:                  " + getChangedValue(pdfPolicyDetails.getInstituteName()), font));
		nameOfInstitute.setBorderWidthBottom(0.1f);
		nameOfInstitute.setBorderColorBottom(java.awt.Color.WHITE);
		nameOfInstitute.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(nameOfInstitute);

		PdfPTable instituteAddrPhone = new PdfPTable(4);
		instituteAddrPhone.setSpacingAfter(8);
		instituteAddrPhone.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		instituteAddrPhone.addCell(new Phrase("Address : ", font));
		instituteAddrPhone.addCell(new Phrase((getChangedValue(pdfPolicyDetails.getInstituteAddress())), font));
		instituteAddrPhone.addCell(new Phrase("Phone Number of Institution : ", font));
		instituteAddrPhone.addCell(new Phrase((getChangedValue(pdfPolicyDetails.getInstitutePhone())), font));
		instituteAddrPhone.addCell(new Phrase("", font));
		instituteAddrPhone.addCell(new Phrase((getChangedValue(pdfPolicyDetails.getInstituteOtherAddress())), font));
		instituteAddrPhone.addCell(new Phrase("", font));
		instituteAddrPhone.addCell(new Phrase("", font));

		PdfPCell instituteAddrPhoneCell = new PdfPCell(instituteAddrPhone);
		instituteAddrPhoneCell.setBorderWidthBottom(0.1f);
		instituteAddrPhoneCell.setBorderColorTop(java.awt.Color.WHITE);
		instituteAddrPhoneCell.setBorderColorBottom(java.awt.Color.WHITE);
		page2Table2.addCell(instituteAddrPhoneCell);

		PdfPTable stateMedi = new PdfPTable(5);
		stateMedi.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		stateMedi.setWidths(new int[] { 200, 6, 10, 6, 10 });
		String radioButtonStateMedi = pdfPolicyDetails.getStateMedicaid();
		if (radioButtonStateMedi != null && radioButtonStateMedi.equalsIgnoreCase("Y")) {
			displayButtonInPDFforEnrolledMedicaid(page2Table2, buttonCheckImage, buttonUncheckImage);
		} else if (radioButtonStateMedi == null) {
			displayButtonInPDFforEnrolledMedicaid(page2Table2, buttonUncheckImage, buttonUncheckImage);
		} else {
			displayButtonInPDFforEnrolledMedicaid(page2Table2, buttonUncheckImage, buttonCheckImage);
		}

		
		
		PdfPCell stateMedicaidQuestion = new PdfPCell(longTermFacQuestion);
		stateMedicaidQuestion.setBorderWidthBottom(0.1f);
		stateMedicaidQuestion.setBorderColorBottom(java.awt.Color.WHITE);
		stateMedicaidQuestion.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(stateMedicaidQuestion);

		PdfPCell medcaidNumber = new PdfPCell(new Phrase(
				"If yes, please provide your Medicaid number:" + getChangedValue(pdfPolicyDetails.getMedicaidNumber()), font));
		medcaidNumber.setBorderWidthBottom(0.1f);
		medcaidNumber.setBorderColorBottom(java.awt.Color.WHITE);
		medcaidNumber.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(medcaidNumber);
		
		PdfPTable spouseWork = new PdfPTable(5);
		spouseWork.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		spouseWork.setWidths(new int[] { 200, 6, 10, 6, 10 });
		String radioButtonSpouseWork = pdfPolicyDetails.getSpouse();
		if (radioButtonSpouseWork != null && radioButtonSpouseWork.equalsIgnoreCase("Y")) {
			displayButtonInPDFforSpouse(page2Table2, buttonCheckImage, buttonUncheckImage);
		} else if (radioButtonSpouseWork == null) {
			displayButtonInPDFforSpouse(page2Table2, buttonUncheckImage, buttonUncheckImage);
		} else {
			displayButtonInPDFforSpouse(page2Table2, buttonUncheckImage, buttonCheckImage);
		}
		/* IFOX-00419836 2020 AEP changes. START*/
		PdfPCell page2TablePCP = new PdfPCell(
				new Phrase("Please select a Primary Care Physician from our Provider Directory : "
						+ (getChangedValue(pdfPolicyDetails.getPhysicianName())), font));
		page2TablePCP.setBorderWidthTop(0.1f);
		page2TablePCP.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(page2TablePCP);
		/* IFOX-00419836 2020 AEP changes. END*/
		/*
		 * String radioButtonFlagfortable2cell9 = pdfPolicyDetails
		 * .getPrescriptionDrug(); if (radioButtonFlagfortable2cell9 != null &&
		 * radioButtonFlagfortable2cell9.equalsIgnoreCase("Y")) {
		 * displayButtonInPDFforForm2table2cell9(page2Table2, buttonCheckImage,
		 * buttonUncheckImage); } else if (radioButtonFlagfortable2cell9 ==
		 * null) { displayButtonInPDFforForm2table2cell9(page2Table2,
		 * buttonUncheckImage, buttonUncheckImage); } else {
		 * displayButtonInPDFforForm2table2cell9(page2Table2,
		 * buttonUncheckImage, buttonCheckImage); }
		 */

		/*
		 * PdfPTable page2Table3cell14 = new PdfPTable(2);
		 * page2Table3cell14.getDefaultCell().setBorder( Rectangle.NO_BORDER);
		 * page2Table3cell14.addCell(new Phrase( "Alternative Phone number : ",
		 * font)); page2Table3cell14.addCell(new Phrase(
		 * (getChangedValue(pdfUserDetails.getAltrPhNumber())), font));
		 */

		/*
		 * PdfPCell page2table2cell10 = new PdfPCell( new Phrase( "If " + "yes"
		 * +
		 * ", please list your other coverage and your identification (ID) numbers(s) for this coverage:"
		 * , font)); page2table2cell10.setBorderWidthBottom(0.1f);
		 * page2table2cell10.setBorderColorBottom(java.awt.Color.WHITE);
		 * page2table2cell10.setBorderColorTop(java.awt.Color.WHITE);
		 * page2Table2.addCell(page2table2cell10);
		 * 
		 * PdfPTable page2table2cell11_table2 = new PdfPTable(4);
		 * page2table2cell11_table2.getDefaultCell()
		 * .setBorder(Rectangle.NO_BORDER); page2table2cell11_table2.addCell(new
		 * Phrase("Name of other coverage: ", font));
		 * page2table2cell11_table2.addCell(new Phrase("ID# for this coverage: "
		 * , font)); page2table2cell11_table2.addCell(new Phrase(
		 * "Group # for this coverage:", font));
		 * page2table2cell11_table2.addCell(new Phrase("Ending Coverage Date:",
		 * font));
		 * 
		 * PdfPCell page2table2cell11 = new PdfPCell(page2table2cell11_table2);
		 * page2table2cell11.setBorderWidthBottom(0.1f);
		 * page2table2cell11.setBorderColorBottom(java.awt.Color.WHITE);
		 * page2table2cell11.setBorderColorTop(java.awt.Color.WHITE);
		 * page2Table2.addCell(page2table2cell11);
		 * 
		 * PdfPTable page2table2cell11_table3 = new PdfPTable(4);
		 * page2table2cell11_table3.getDefaultCell()
		 * .setBorder(Rectangle.NO_BORDER); page2table2cell11_table3
		 * .addCell(new Phrase((getChangedValue(pdfPolicyDetails
		 * .getDurgNameCoverage())), font));
		 * page2table2cell11_table3.addCell(new Phrase(
		 * (getChangedValue(pdfPolicyDetails.getDurgIdCoverage())), font));
		 * page2table2cell11_table3.addCell(new Phrase(
		 * (getChangedValue(pdfPolicyDetails.getDurgGroupCoverage())), font));
		 * page2table2cell11_table3.addCell(new Phrase(
		 * (getChangedValue(pdfPolicyDetails.getDurgCoveragePeriod())), font));
		 * 
		 * PdfPCell page2table2cell12 = new PdfPCell(page2table2cell11_table3);
		 * page2table2cell12.setBorderWidthBottom(0.1f);
		 * page2table2cell12.setBorderColorTop(java.awt.Color.WHITE);
		 * page2Table2.addCell(page2table2cell12);
		 */

		return page2Table2;
	}

	/**
	 * @param pdfPolicyDetails
	 * @return
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static PdfPTable pdfPage2Table1(PolicyDetailsVO pdfPolicyDetails) throws DocumentException, IOException {

		PdfPTable page2Table1 = new PdfPTable(1);
		page2Table1.setWidthPercentage(100);
		page2Table1.setSpacingBefore(10);

		PdfPCell page2table1cell1 = new PdfPCell(
				new Phrase("Paying Your Plan Premium and/or Late Enrollment Penalty (LEP)",
						FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD)));
		page2table1cell1.setGrayFill(0.85f);
		page2table1cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
		page2table1cell1.setBorderWidthBottom(0.1f);
		page2table1cell1.setBorderColorBottom(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell1);

		PdfPCell page2table1cell2 = new PdfPCell(new Phrase(
				"If we determine that you owe a late enrollment penalty (or if you currently have a late enrollment penalty), "
				+ "we need to know how you would prefer to pay it. You can pay by mail each month. You can pay by mail, Electronic Funds Transfer (EFT) "
				+ "or credit card through our member portal online each month. "
				+ "You can also choose to pay your premium by automatic deduction from your Social Security or Railroad Retirement Board (RRB) benefit check each month. "
				+ "If you are assessed a Part D-Income Related Monthly Adjustment Amount (IRMAA), you will be notified by the Social Security Administration. "
				+ "You will be responsible for paying this extra amount in addition to your plan premium. You will either have the amount withheld "
				+ "from your Social Security benefit check or be billed directly by Medicare or the RRB. DO NOT pay "+planName+" the Part D-IRMAA.",
				font));
		page2table1cell2.setBorderWidthBottom(0.1f);
		page2table1cell2.setBorderColorBottom(java.awt.Color.WHITE);
		page2table1cell2.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell2);
		
		
		PdfPCell page2table1cell2A = new PdfPCell(new Phrase(
				"You can pay your monthly plan premium (including any late enrollment penalty that you currently have or may owe) by mail, \"Electronic Funds Transfer (EFT)\", \"credit card\" each month. You can also choose to pay your premium by automatic deduction from your Social Security or Railroad Retirement Board (RRB) benefit check each month.",
				font));
		page2table1cell2A.setBorderWidthBottom(0.1f);
		page2table1cell2A.setBorderColorBottom(java.awt.Color.WHITE);
		page2table1cell2A.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell2A);
		
		/* IFOX-00419836 2019 AEP changes. START*/
		PdfPCell page2table1cell2B = new PdfPCell(new Phrase(
				"If you are assessed a Part D-Income Related Monthly Adjustment Amount, you will be notified by the Social Security Administration. You will be responsible for paying this extra amount in addition to your plan premium. You will either have the amount withheld from your Social Security benefit check or be billed directly by Medicare or RRB. DO NOT pay Virginia Premier the Part D-IRMAA.",
				font));
		page2table1cell2B.setBorderWidthBottom(0.1f);
		page2table1cell2B.setBorderColorBottom(java.awt.Color.WHITE);
		page2table1cell2B.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell2B);
		/* IFOX-00419836 2019 AEP changes. END*/

		/*IFOX-00407925--Start*/
		PdfPCell page2table1cell3 = new PdfPCell(new Phrase(
				"People with limited incomes may qualify for Extra Help to pay for their prescription drug costs. If eligible, "
				+ "Medicare could pay for 75% or more of your drug costs including monthly prescription drug premiums, annual deductibles, and co-insurance. "
				+ "Additionally, those who qualify will not be subject to the coverage gap or a late enrollment penalty. Many people are eligible for these savings and don�t even know it. "
				+ "For more information about this Extra Help, contact your local Social Security office, or call Social Security at 1-800-772-1213. "
				+ "TTY users should call 1-800-325-0778. You can also apply for Help online at www.socialsecurity.gov/prescriptionhelp..",
				font));
		page2table1cell3.setBorderWidthBottom(0.1f);
		page2table1cell3.setBorderColorBottom(java.awt.Color.WHITE);
		page2table1cell3.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell3);

		PdfPCell page2table1cell4 = new PdfPCell(new Phrase(
				"If you qualify for Extra Help with your Medicare prescription drug coverage costs, Medicare will pay all or part of your plan premium. "
				+ "If Medicare pays only a portion of this premium, we will bill you for the amount that Medicare doesn�t cover.",
				font));
		/*IFOX-00407925--End*/
		page2table1cell4.setBorderWidthBottom(0.1f);
		page2table1cell4.setBorderColorBottom(java.awt.Color.WHITE);
		page2table1cell4.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell4);

		PdfPCell shouldselectone = new PdfPCell(new Phrase(
				"If you don�t select a payment option, you will get a bill each month.",
				font));
		shouldselectone.setBorderWidthBottom(0.1f);
		shouldselectone.setBorderColorBottom(java.awt.Color.WHITE);
		shouldselectone.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(shouldselectone);
		
		PdfPTable page2table1cell5_table1 = new PdfPTable(3);
		page2table1cell5_table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2table1cell5_table1.addCell(new Phrase((getChangedValue(pdfPolicyDetails.getPalnName())), font));
		page2table1cell5_table1.addCell(new Phrase((getChangedValue(pdfPolicyDetails.getPolicyNumber())), font));
		page2table1cell5_table1.addCell(new Phrase((getChangedValue(pdfPolicyDetails.getBeginingDate())), font));

		/*PdfPTable page2table1cell5_table2 = new PdfPTable(3);
		page2table1cell5_table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2table1cell5_table2.addCell(new Phrase("Plan Name", font));
		page2table1cell5_table2.addCell(new Phrase("Policy Number", font));
		page2table1cell5_table2.addCell(new Phrase("Begining/Ending Date", font));
*/
		PdfPCell page2table1cell5 = new PdfPCell(page2table1cell5_table1);
		page2table1cell5.setBorderWidthBottom(0.1f);
		page2table1cell5.setBorderColorBottom(java.awt.Color.WHITE);
		page2table1cell5.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell5);

		/*PdfPCell page2table1cell6 = new PdfPCell(page2table1cell5_table2);
		page2table1cell6.setBorderWidthBottom(0.1f);
		page2table1cell6.setBorderColorBottom(java.awt.Color.WHITE);
		page2table1cell6.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell6);*/

		PdfPCell page2table1cell7 = new PdfPCell(new Phrase("Please select one premium payment option:", font));
		page2table1cell7.setBorderWidthBottom(0.1f);
		page2table1cell7.setBorderColorBottom(java.awt.Color.WHITE);
		page2table1cell7.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell7);
		
		String paymentOption = pdfPolicyDetails.getPaymentOption();
		if (paymentOption == null) {
			displayCheckBoxInPDFforForm2table1cell8(page2Table1, buttonUncheckImage);
			displayCheckBoxInPDFforForm2table1cell9(page2Table1, buttonUncheckImage);
		} else if ("D".equalsIgnoreCase(paymentOption)) {
			displayCheckBoxInPDFforForm2table1cell8(page2Table1, buttonCheckImage);
			displayCheckBoxInPDFforForm2table1cell9(page2Table1, buttonUncheckImage);
		} 
		else if ("S".equalsIgnoreCase(paymentOption)) {
			displayCheckBoxInPDFforForm2table1cell8(page2Table1, buttonUncheckImage);
			displayCheckBoxInPDFforForm2table1cell9(page2Table1, buttonCheckImage);
		}else if ("R".equalsIgnoreCase(paymentOption)) {
			displayCheckBoxInPDFforForm2table1cell8(page2Table1, buttonUncheckImage);
			displayCheckBoxInPDFforForm2table1cell9_1(page2Table1, buttonCheckImage);
		}else {
			displayCheckBoxInPDFforForm2table1cell8(page2Table1, buttonUncheckImage);
			displayCheckBoxInPDFforForm2table1cell9(page2Table1, buttonUncheckImage);
		}

		/*PdfPCell page2table1cell10 = new PdfPCell(
				new Phrase("Account holder name :" + (getChangedValue(pdfPolicyDetails.getAccountHolderName())), font));
		page2table1cell10.setBorderWidthBottom(0.1f);
		page2table1cell10.setBorderColorBottom(java.awt.Color.WHITE);
		page2table1cell10.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell10);

		PdfPTable page2table1cell5_table3 = new PdfPTable(2);
		page2table1cell5_table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2table1cell5_table3.addCell(new Phrase(
				"Bank routing number : " + (getChangedValue(pdfPolicyDetails.getBankRoutingNumber())), font));
		page2table1cell5_table3.addCell(
				new Phrase("Bank account number: " + (getChangedValue(pdfPolicyDetails.getBankAccountNumber())), font));

		PdfPCell page2table1cell11 = new PdfPCell(page2table1cell5_table3);
		page2table1cell11.setBorderWidthBottom(0.1f);
		page2table1cell11.setBorderColorBottom(java.awt.Color.WHITE);
		page2table1cell11.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell11);

		String AutoDeductionCheck = pdfPolicyDetails.getAutoDeduction();
		if (AutoDeductionCheck != null) {
			displayCheckBoxInPDFforForm2table1cell12(page2Table1, check);
		} else {
			displayCheckBoxInPDFforForm2table1cell12(page2Table1, uncheck);
		}

		PdfPCell page2table1cell13 = new PdfPCell(new Phrase(
				"People with limited incomes may qualify for extra help to pay for their prescription drug costs. If eligible, Medicare could pay for 75% or more of your drug costs including monthly prescription drug premiums, annual deductibles, and co-insurance. Additionally, those who qualify will not be subject to the coverage gap or a late enrollment penalty. Many people are eligible for these savings and don't even know it. For more information about this extra help, contact your local Social Security office, or call Social Security at 1-800-772-1213. TTY users should call 1-800-325-0778. You can also apply for extra help online at www.socialsecurity.gov/prescriptionhelp.",
				font));
		page2table1cell13.setBorderWidthBottom(0.1f);
		page2table1cell13.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell13);*/

		return page2Table1;

	}

	/**
	 * @return
	 */
	private static PdfPTable page2TableLogo() {
		PdfPTable page2Logotable = new PdfPTable(1);
		page2Logotable.setWidthPercentage(100);
		page2Logotable.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPCell page2logocell = new PdfPCell(OptimaHealth_Logo);
		page2logocell.setHorizontalAlignment(Element.ALIGN_LEFT);
		page2logocell.setBorder(Rectangle.NO_BORDER);

		page2Logotable.addCell(page2logocell);

		return page2Logotable;

	}

	/**
	 * @param pdfUserDetails
	 * @param document
	 * @return
	 */
	private static PdfPTable page1TableMedicareDetails(UserDetailsVO pdfUserDetails, Document document) {
		PdfPTable page1TableMedicarddetails = new PdfPTable(1);
		page1TableMedicarddetails.setSpacingBefore(15);
		page1TableMedicarddetails.setWidthPercentage(100);

		PdfPCell page1TableMedicarddetailsHeadercell = new PdfPCell(
				new Phrase("Please Provide Your Medicare Insurance Information:",
						FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD)));
		page1TableMedicarddetailsHeadercell.setGrayFill(0.85f);

		PdfPTable page1TableMedicarddetaiils4 = new PdfPTable(2);
		page1TableMedicarddetaiils4.setSpacingBefore(5);
		page1TableMedicarddetaiils4.setWidthPercentage(85);

		PdfPTable page1TableMedicarddetailsCell22 = new PdfPTable(1);
		page1TableMedicarddetailsCell22.setWidthPercentage(85);
		//page1TableMedicarddetailsCell22.addCell(Medicardlogo_Logo);

		PdfPCell page1TableMedicarddetailsCell22Name = new PdfPCell(
				new Phrase("NAME OF BENEFICIARY : " + (getChangedValue(pdfUserDetails.getNameBeneficiary())), font));
		page1TableMedicarddetailsCell22Name.setBorderWidthBottom(0.0001f);
		page1TableMedicarddetailsCell22Name.setBorder(Rectangle.NO_BORDER);

		page1TableMedicarddetailsCell22.addCell(page1TableMedicarddetailsCell22Name);

		PdfPCell page1TableMedicarddetailsCell22Claimnum = new PdfPCell(new Phrase("MEDICARE CLAIM NUMBER : "
				+ (getChangedValue(pdfUserDetails.getMediacrdNumber())) + " \t \t \t sex : "
				+ (((getChangedValue(pdfUserDetails.getBeneficiarySex())).equalsIgnoreCase("M") ? "Male" : "Female")),
				font));
		page1TableMedicarddetailsCell22Claimnum.setBorderWidthBottom(0.0001f);
		page1TableMedicarddetailsCell22Claimnum.setBorder(Rectangle.NO_BORDER);

		page1TableMedicarddetailsCell22.addCell(page1TableMedicarddetailsCell22Claimnum);

		PdfPCell page1TableMedicarddetailsCell22entitled = new PdfPCell(
				new Phrase("Is Entitled To                            Effective Date", font2));
		page1TableMedicarddetailsCell22entitled.setBorderWidthBottom(0.0001f);
		page1TableMedicarddetailsCell22entitled.setBorder(Rectangle.NO_BORDER);

		page1TableMedicarddetailsCell22.addCell(page1TableMedicarddetailsCell22entitled);

		PdfPCell page1TableMedicarddetailsCell22partA = new PdfPCell(new Phrase(
				"HOSPITAL               (PART A) : " + (getChangedValue(pdfUserDetails.getHospitalDate())), font2));
		page1TableMedicarddetailsCell22partA.setBorderWidthBottom(0.0001f);
		page1TableMedicarddetailsCell22partA.setBorder(Rectangle.NO_BORDER);

		page1TableMedicarddetailsCell22.addCell(page1TableMedicarddetailsCell22partA);

		PdfPCell page1TableMedicarddetailsCell22partB = new PdfPCell(new Phrase(
				"MEDICAL                 (PART B) : " + (getChangedValue(pdfUserDetails.getMedicalDate())), font2));
		page1TableMedicarddetailsCell22partB.setBorderWidthBottom(0.0001f);
		page1TableMedicarddetailsCell22partB.setBorder(Rectangle.NO_BORDER);
		page1TableMedicarddetailsCell22.addCell(page1TableMedicarddetailsCell22partB);
		
		/*IFOX-00407925--Start*/
		PdfPCell partABContent = new PdfPCell(
				new Phrase("You must have Medicare Part A and Part B to join a Medicare Advantage plan.", font));
		/*IFOX-00407925--End*/
		partABContent.setBorderWidthBottom(0.0001f);
		partABContent.setBorder(Rectangle.NO_BORDER);
		page1TableMedicarddetailsCell22.addCell(partABContent);

		PdfPTable M3table1 = new PdfPTable(2);
		M3table1.setSpacingBefore(5);
		M3table1.setWidthPercentage(85);
		/*IFOX-00407925--Start*/
		/*List unorderedList=new List(List.UNORDERED);
		unorderedList.setListSymbol("\u25A0");
		unorderedList.add(new ListItem("Fill out this information as it appears on your Medicare card."));
		PdfPCell page1TableMedicarddetailscell210 = new PdfPCell(new Phrase(unorderedList,font));*/
		// Font f = new Font(FontFamily.TIMES_ROMAN, 25.0f, Font.BOLD, java.awt.Color.BLACK);
		//Chunk bullet = new Chunk("\u25A0", zapfdingbats);
		PdfPCell page1TableMedicarddetailscell21 = new PdfPCell(new Phrase(
				"Please take out your Medicare card for this section.\n \u2022 Fill out this information as it appears on your Medicare card."
				+ " \n -OR- \n \u2022 Attach a copy of your Medicare card or your letter from Social Security or the Railroad Retirement Board. "
				//+ "\n \nYou must have Medicare Part A and Part B to join a Medicare Advantage plan.",font));
				+ "\n ",font));
		/*IFOX-00407925--End*/
		PdfPCell M3table1cell2 = new PdfPCell(page1TableMedicarddetailsCell22);
		page1TableMedicarddetailscell21.setHorizontalAlignment(Element.ALIGN_CENTER);
		page1TableMedicarddetailscell21.setHorizontalAlignment(Element.ALIGN_BOTTOM);

		page1TableMedicarddetaiils4.addCell(page1TableMedicarddetailscell21);
		page1TableMedicarddetaiils4.addCell(M3table1cell2);

		PdfPCell M3table1cell22 = new PdfPCell(page1TableMedicarddetaiils4);

		page1TableMedicarddetails.addCell(page1TableMedicarddetailsHeadercell);
		page1TableMedicarddetails.addCell(M3table1cell22);
		return page1TableMedicarddetails;
	}

	/**
	 * @param pdfUserDetails
	 * @param document
	 * @return
	 * @throws DocumentException
	 */
	private static PdfPTable page1TabbleUserDetails(UserDetailsVO pdfUserDetails, Document document)
			throws DocumentException {
		PdfPTable page1TableUserDetails = new PdfPTable(1);
		page1TableUserDetails.setSpacingBefore(10);
		page1TableUserDetails.setWidthPercentage(100);
		page1TableUserDetails.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		
		PdfPCell page1planlabel = new PdfPCell(
				new Phrase("Enrolled in "+planName+" "+planNameType+" "+planPremium+" Per month, \n"
						+ "Provided Information:",
						FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD)));
		page1planlabel.setGrayFill(0.85f);
		page1planlabel.setHorizontalAlignment(Element.ALIGN_CENTER);
		page1planlabel.setBorderWidthBottom(0.1f);
		page1planlabel.setBorderColorBottom(java.awt.Color.WHITE);
		page1TableUserDetails.addCell(page1planlabel);

		PdfPTable page1TableUserDetailsNamecell = new PdfPTable(4);
		page1TableUserDetailsNamecell.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page1TableUserDetailsNamecell.addCell(new Phrase("Last name : ", font));
		page1TableUserDetailsNamecell.addCell(new Phrase((getChangedValue(pdfUserDetails.getLastName())), font));
		page1TableUserDetailsNamecell.addCell(new Phrase("Middle name : ", font));
		page1TableUserDetailsNamecell.addCell(new Phrase(getChangedValue(pdfUserDetails.getMiddleInitial()), font));

		PdfPTable page1TableUserDetailMiddleName = new PdfPTable(1);
		page1TableUserDetailMiddleName.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page1TableUserDetailMiddleName
				.addCell(new Phrase("First name : " + (getChangedValue(pdfUserDetails.getFirstName())), font));

		PdfPTable page1TableUserDetailsuffix = new PdfPTable(1);
		page1TableUserDetailsuffix.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page1TableUserDetailsuffix
				.addCell(new Phrase("Suffix : " + (getChangedValue(pdfUserDetails.getSuffix())), font));

		PdfPTable page1TableUserDetailsCell1 = new PdfPTable(3);
		page1TableUserDetailsCell1.setSpacingAfter(8);
		page1TableUserDetailsCell1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page1TableUserDetailsCell1.setWidthPercentage(100);
		// for 2015
		page1TableUserDetailsCell1.addCell(page1TableUserDetailsuffix);
		page1TableUserDetailsCell1.addCell(page1TableUserDetailsNamecell);
		page1TableUserDetailsCell1.addCell(page1TableUserDetailMiddleName);

		PdfPTable page1TableUserDetailsCell2Home = new PdfPTable(2);
		page1TableUserDetailsCell2Home.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page1TableUserDetailsCell2Home.addCell(new Phrase("Home Phone number: ", font));
		page1TableUserDetailsCell2Home.addCell(new Phrase((getChangedValue(pdfUserDetails.getHomePhNumber())), font));

		PdfPTable page1TableUserDetailsCell2 = new PdfPTable(3);
		page1TableUserDetailsCell2.setSpacingAfter(8);
		page1TableUserDetailsCell2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page1TableUserDetailsCell2.setWidthPercentage(100);
		page1TableUserDetailsCell2
				.addCell(new Phrase("Birth date :" + (getChangedValue(pdfUserDetails.getBirthDate())), font));
		page1TableUserDetailsCell2.addCell(new Phrase(
				"SEX : " + ((getChangedValue(pdfUserDetails.getSex())).equalsIgnoreCase("M") ? "MALE" : "FEMALE"),
				font));
		page1TableUserDetailsCell2.addCell(page1TableUserDetailsCell2Home);

		PdfPCell page1TableUserDetailscell2main = new PdfPCell(page1TableUserDetailsCell2);
		page1TableUserDetailscell2main.setBorderWidthBottom(0f);
		page1TableUserDetailscell2main.setBorderColorBottom(java.awt.Color.WHITE);
		page1TableUserDetailscell2main.setBorderColorTop(java.awt.Color.WHITE);
		page1TableUserDetailscell2main.setSpaceCharRatio(8);

		PdfPTable permenentAddress1 = new PdfPTable(2);
		permenentAddress1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		permenentAddress1.addCell(new Phrase("Permanent Residence Street Address: (P.O. Box is not allowed) : ", font));
		permenentAddress1.addCell(new Phrase((getChangedValue(pdfUserDetails.getPermanentAddr())), font));

		PdfPTable permenentAddress2 = new PdfPTable(2);
		permenentAddress2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		permenentAddress2.addCell(new Phrase(
				"                                                                                                          ",
				font));
		permenentAddress2.addCell(new Phrase((getChangedValue(pdfUserDetails.getPermanentStrt())), font));

		PdfPTable permenentAddressCell = new PdfPTable(1);
		permenentAddressCell.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		permenentAddressCell.addCell(permenentAddress1);
		permenentAddressCell.addCell(permenentAddress2);

		PdfPTable page1TableUserDetailsCell32 = new PdfPTable(2);
		page1TableUserDetailsCell32.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page1TableUserDetailsCell32.addCell(new Phrase("Alternative Phone number : ", font));
		page1TableUserDetailsCell32.addCell(new Phrase((getChangedValue(pdfUserDetails.getAltrPhNumber())), font));

		PdfPTable page1TableUserDetailsCell3and4 = new PdfPTable(2);
		page1TableUserDetailsCell3and4.setSpacingAfter(8);
		page1TableUserDetailsCell3and4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page1TableUserDetailsCell3and4.setWidths(new int[] { 100, 50 });
		page1TableUserDetailsCell3and4
				.addCell(new Phrase("Email Address : " + (getChangedValue(pdfUserDetails.getEmailAddr())), font));
		page1TableUserDetailsCell3and4.addCell(page1TableUserDetailsCell32);
		page1TableUserDetailsCell3and4.addCell(permenentAddressCell);
		page1TableUserDetailsCell3and4
				.addCell(new Phrase("Apt # : " + (getChangedValue(pdfUserDetails.getPermanentApt())), font));

		PdfPCell page1TableUserDetailsCell1main = new PdfPCell(page1TableUserDetailsCell1);
		page1TableUserDetailsCell1main.setBorderWidthBottom(0f);
		page1TableUserDetailsCell1main.setBorderColorBottom(java.awt.Color.WHITE);
		page1TableUserDetailsCell1main.setSpaceCharRatio(8);

		PdfPCell page1TableUserDetailsCell2and4main = new PdfPCell(page1TableUserDetailsCell3and4);
		page1TableUserDetailsCell2and4main.setBorderWidthBottom(0.01f);
		page1TableUserDetailsCell2and4main.setBorderColorTop(java.awt.Color.WHITE);
		page1TableUserDetailsCell2and4main.setBorderColorBottom(java.awt.Color.WHITE);

		page1TableUserDetails.addCell(page1TableUserDetailsCell1main);
		page1TableUserDetails.addCell(page1TableUserDetailscell2main);
		page1TableUserDetails.addCell(page1TableUserDetailsCell2and4main);

		PdfPTable page1TableUserDetailsCell5 = new PdfPTable(3);
		page1TableUserDetailsCell5.setSpacingAfter(8);
		page1TableUserDetailsCell5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page1TableUserDetailsCell5
				.addCell(new Phrase("City or County : " + (getChangedValue(pdfUserDetails.getPermanentCity())), font));
		page1TableUserDetailsCell5
				.addCell(new Phrase("State : " + (getChangedValue(pdfUserDetails.getPermanentState())), font));
		page1TableUserDetailsCell5
				.addCell(new Phrase("ZIP Code: " + (getChangedValue(pdfUserDetails.getPermanentZip())), font));

		PdfPCell page1TableUserDetailsCell5main = new PdfPCell(page1TableUserDetailsCell5);
		page1TableUserDetailsCell5main.setBorderWidthBottom(0.01f);
		page1TableUserDetailsCell5main.setBorderColorTop(java.awt.Color.WHITE);
		page1TableUserDetailsCell5main.setBorderColorBottom(java.awt.Color.WHITE);

		page1TableUserDetails.addCell(page1TableUserDetailsCell5main);

		PdfPTable page1TableUserDetailsCell6 = new PdfPTable(2);
		page1TableUserDetailsCell6.setSpacingAfter(8);
		page1TableUserDetailsCell6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page1TableUserDetailsCell6.setWidths(new int[] { 100, 50 });

		PdfPTable mailAddressCell = new PdfPTable(2);
		mailAddressCell.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		mailAddressCell.addCell(new Phrase(
				"Mailing Address- Street Address/P.O.Box: \n (Only if different from your Permanent Residential Address) : ",
				font));
		mailAddressCell.addCell(new Phrase((getChangedValue(pdfUserDetails.getMailingAddr())), font));
		mailAddressCell.addCell(new Phrase(
				"                                                                                                 ",
				font));
		mailAddressCell.addCell(new Phrase((getChangedValue(pdfUserDetails.getMailingStrt())), font));

		page1TableUserDetailsCell6.addCell(mailAddressCell);
		page1TableUserDetailsCell6
				.addCell(new Phrase("Apt # : " + (getChangedValue(pdfUserDetails.getMailingApt())), font));

		PdfPCell page1TableUserDetailsCell6main = new PdfPCell(page1TableUserDetailsCell6);
		page1TableUserDetailsCell6main.setBorderWidthBottom(0.01f);
		page1TableUserDetailsCell6main.setBorderColorTop(java.awt.Color.WHITE);
		page1TableUserDetailsCell6main.setBorderColorBottom(java.awt.Color.WHITE);

		page1TableUserDetails.addCell(page1TableUserDetailsCell6main);

		PdfPTable page1TableUserDetailsCell7 = new PdfPTable(3);
		page1TableUserDetailsCell7.setSpacingAfter(8);
		page1TableUserDetailsCell7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page1TableUserDetailsCell7
				.addCell(new Phrase("City or County : " + (getChangedValue(pdfUserDetails.getMailingCity())), font));
		page1TableUserDetailsCell7
				.addCell(new Phrase("State : " + (getChangedValue(pdfUserDetails.getMailingState())), font));
		page1TableUserDetailsCell7
				.addCell(new Phrase("ZIP Code : " + (getChangedValue(pdfUserDetails.getMailingZip())), font));

		PdfPCell page1TableUserDetailsCell7main = new PdfPCell(page1TableUserDetailsCell7);
		page1TableUserDetailsCell7main.setBorderWidthBottom(0.01f);
		page1TableUserDetailsCell7main.setBorderColorTop(java.awt.Color.WHITE);
		page1TableUserDetailsCell7main.setBorderColorBottom(java.awt.Color.WHITE);
		page1TableUserDetails.addCell(page1TableUserDetailsCell7main);

		String relationshipYou = MedicareUtil.getRelationEnrollValues().get(pdfUserDetails.getRelationYou());

		relationshipYou = relationshipYou == null ? ""
				: MedicareUtil.getRelationEnrollValues().get(getChangedValue(pdfUserDetails.getRelationYou()));

		PdfPTable page1TableUserDetailsCell8 = new PdfPTable(3);
		page1TableUserDetailsCell8.setSpacingAfter(8);
		page1TableUserDetailsCell8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page1TableUserDetailsCell8.addCell(new Phrase("Emergency Contact : ", font));
		page1TableUserDetailsCell8.addCell(new Phrase((getChangedValue(pdfUserDetails.getEmergencyCont())), font));
		page1TableUserDetailsCell8.addCell(new Phrase("Relationship to You : " + relationshipYou, font));

		PdfPCell page1TableUserDetailsCell8main = new PdfPCell(page1TableUserDetailsCell8);
		page1TableUserDetailsCell8main.setBorderWidthBottom(0.1f);
		page1TableUserDetailsCell8main.setBorderColorTop(java.awt.Color.WHITE);
		page1TableUserDetailsCell8main.setBorderColorBottom(java.awt.Color.WHITE);
		page1TableUserDetails.addCell(page1TableUserDetailsCell8main);

		PdfPCell page1TableUserDetailsCell9 = new PdfPCell(
				new Phrase("Emergency Contact number : " + (getChangedValue(pdfUserDetails.getEmergPhNum())), font));
		page1TableUserDetailsCell9.setBorderWidthBottom(0.1f);
		page1TableUserDetailsCell9.setBorderColorTop(java.awt.Color.WHITE);
		page1TableUserDetailsCell9.setBorderColorBottom(java.awt.Color.WHITE);
		page1TableUserDetails.addCell(page1TableUserDetailsCell9);

		/* IFOX-00419836 2019 AEP changes. PCP Moved to 2nd Page.  START*/
	/*	PdfPCell page1TableUserDetailsCell10 = new PdfPCell(
				new Phrase("Please select a Primary Care Physician from our Provider Directory : "
						+ (getChangedValue(pdfUserDetails.getPhysicianName())), font));
		page1TableUserDetailsCell10.setBorderWidthTop(0.1f);
		page1TableUserDetailsCell10.setBorderColorTop(java.awt.Color.WHITE);
		page1TableUserDetails.addCell(page1TableUserDetailsCell10);*/
		/* IFOX-00419836 2019 AEP changes. PCP Moved to 2nd Page.  END*/
		
		return page1TableUserDetails;

	}

	/**
	 * @param pdfUserDetails
	 * @param document
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void page1optimaPlanTable(UserDetailsVO pdfUserDetails, Document document)
			throws DocumentException, IOException {
		String header = pdfUserDetails.getOptimaMedicare();
		if (header != null) {
			if (header.equalsIgnoreCase("001") && !header.isEmpty()) {
				displayButtonInPDFforForm1OptimaButton(buttonCheckImage, buttonUncheckImage, document, pdfUserDetails);
			} else if (header.equalsIgnoreCase("002") && !header.isEmpty()) {
				displayButtonInPDFforForm1OptimaButton(buttonUncheckImage, buttonCheckImage, document, pdfUserDetails);
			}
		}
	}

	/**
	 * @param request
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void pdffontInstances(HttpServletRequest request) throws DocumentException, IOException {

		ServletContext context = request.getSession().getServletContext();
		String absoluteDiskPathOfArialfont = context.getRealPath(WebAppConstants.RELATIVEWEBPATHOFARIALFONT);
		base = BaseFont.createFont(absoluteDiskPathOfArialfont, BaseFont.WINANSI, false);
		font = new Font(base, 8, Font.NORMAL, java.awt.Color.BLACK);
		font2 = new Font(base, 9, Font.BOLD, java.awt.Color.BLACK);
	}

	/**
	 * @param request
	 * @throws MalformedURLException
	 * @throws IOException
	 * @throws DocumentException
	 */
	private static void pdfImageInstances(HttpServletRequest request)
			throws MalformedURLException, IOException, DocumentException {

		ServletContext context = request.getSession().getServletContext();
		String absoluteDiskPathOfOptimaHealth_logo = context.getRealPath(WebAppConstants.RELATIVEWEBPATHOFVAPLOGO);

		//String absoluteDiskPathOfMedicard_logo = context.getRealPath(WebAppConstants.RELATIVEWEBPATHOFMEDICARDLOGO);
		String absoluteDiskPathOfCheckImage = context.getRealPath(WebAppConstants.RELATIVEWEBPATHOFCHECKIMAGE);
		String absoluteDiskPathOfUncheckImage = context.getRealPath(WebAppConstants.RELATIVEWEBPATHOFUNCHECKIMAGE);
		String absoluteDiskPathOfbuttoncheckImage = context
				.getRealPath(WebAppConstants.RELATIVEWEBPATHOFBUTTONCHECKIMAGE);
		String absoluteDiskPathOfbuttonUncheckImage = context
				.getRealPath(WebAppConstants.RELATIVEWEBPATHOFBUTTONUNCHECKIMAGE);
		String absoluteDiskPathOfStopImage = context.getRealPath(WebAppConstants.RELATIVEWEBPATHOFSTOPIMAGE);

		OptimaHealth_Logo = Image.getInstance(absoluteDiskPathOfOptimaHealth_logo);
		OptimaHealth_Logo.scaleToFit(150f, 150f);

		//Medicardlogo_Logo = Image.getInstance(absoluteDiskPathOfMedicard_logo);
		//Medicardlogo_Logo.scaleToFit(100f, 100f);

		check = Image.getInstance(absoluteDiskPathOfCheckImage);
		uncheck = Image.getInstance(absoluteDiskPathOfUncheckImage);
		buttonCheckImage = Image.getInstance(absoluteDiskPathOfbuttoncheckImage);
		buttonUncheckImage = Image.getInstance(absoluteDiskPathOfbuttonUncheckImage);

		stop = Image.getInstance(absoluteDiskPathOfStopImage);
		stop.scaleToFit(30f, 30f);
	}

	/**
	 * @param optimaHealth_Logo
	 * @return
	 */
	private static PdfPTable page1LogoTable(Image optimaHealth_Logo) {
		/*IFOX-00407925--Start*/
		PdfPTable logo = new PdfPTable(1);
		/*IFOX-00407925--End*/
		logo.setSpacingBefore(10);
		logo.setWidthPercentage(100);
		logo.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPCell logocell1 = new PdfPCell(optimaHealth_Logo);
		logocell1.setHorizontalAlignment(Element.ALIGN_LEFT);
		logocell1.setBorder(Rectangle.NO_BORDER);

		logo.addCell(logocell1);
		/*IFOX-00407925--Start*/
		/*PdfPCell logocell2 = new PdfPCell(new Phrase(planYear+" "+planName+" \nEnrollment Request Form",
				FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD)));
		logocell2.setHorizontalAlignment(Element.ALIGN_RIGHT);
		logocell2.setBorder(Rectangle.NO_BORDER);
		logo.addCell(logocell2);*/
		/*IFOX-00407925--End*/
		return logo;
	}

	// braille

	private static PdfPTable page1BrailleTable() {

		PdfPTable Braille = new PdfPTable(1);
		Braille.setSpacingBefore(15);
		Braille.setWidthPercentage(100);
		Braille.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		System.out.println(" i am in braille table");
		PdfPCell Braillcell1 = new PdfPCell(new Phrase("Please contact "+planName+" "+planNameType
				+"if you need information in another language or format (braille).\n",
				FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD)));
		
		Braillcell1.setHorizontalAlignment(Element.ALIGN_LEFT);
		Braillcell1.setBorder(Rectangle.NO_BORDER);
		Braille.addCell(Braillcell1);
		
		return Braille;
	}

	/**
	 * @param check1
	 * @param check2
	 * @param document
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void displayButtonInPDFforForm1OptimaButton(Image check1, Image check2, Document document,
			UserDetailsVO pdfUserDetails) throws DocumentException, IOException {

		PdfPTable userDetailsTableHeader = new PdfPTable(4);
		userDetailsTableHeader.setWidthPercentage(100);
		userDetailsTableHeader.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		userDetailsTableHeader.setWidths(new int[] { 4, 80, 4, 80 });
		userDetailsTableHeader.addCell(check1);
		userDetailsTableHeader
				.addCell(new Phrase("Optima Medicare Basic: $29 per month (with prescription drugs)", font));
		userDetailsTableHeader.addCell(check2);
		userDetailsTableHeader
				.addCell(new Phrase("Optima Medicare Enhanced: $73 per month (with prescription drugs)", font));
		// userDetailsTableHeader.addCell(new Phrase("Effective date :"
		// +(getChangedValue(pdfUserDetails.getBirthDate())),font));

		PdfPTable Page1TableHeader = new PdfPTable(1);
		Page1TableHeader.setSpacingBefore(10);
		Page1TableHeader.setWidthPercentage(100);
		PdfPCell userDetailsTableHeaderPlan = new PdfPCell(userDetailsTableHeader);
		userDetailsTableHeaderPlan.setBorderColor(java.awt.Color.BLACK);
		// PdfPCell userDetailsTableHeaderMain = new PdfPCell(new Phrase("To
		// Enroll in Optima Medicare HMO, Please Provide the Following
		// Information:",FontFactory.getFont(FontFactory.HELVETICA,
		// 10,Font.BOLD)));

		PdfPCell userDetailsTableHeaderMain = new PdfPCell(new Phrase(
				"To Enroll in VA Premier Elite (HMO SNP) <$0 per month>, Please Provide the Following Information:",
				FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD)));

		userDetailsTableHeaderMain.setHorizontalAlignment(Element.ALIGN_CENTER);
		userDetailsTableHeaderMain.setGrayFill(0.65f);

		PdfPCell effectiveDate = new PdfPCell(
				new Phrase("Effective date :" + (getChangedValue(pdfUserDetails.getEffDate())), font));
		effectiveDate.setHorizontalAlignment(Element.ALIGN_LEFT);

		Page1TableHeader.addCell(userDetailsTableHeaderMain);
		Page1TableHeader.addCell(userDetailsTableHeaderPlan);
		Page1TableHeader.addCell(effectiveDate);

		document.add(Page1TableHeader);
	}

	/**
	 * @param page4Table6
	 * @param check1
	 * @param check2
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void displayButtonInPDFforForm4ApplicationType(PdfPTable page4Table6, Image check1, Image check2,
			Image check3) throws DocumentException, IOException {

		PdfPTable page4Table6Cell1table1 = new PdfPTable(7);
		page4Table6Cell1table1.setWidthPercentage(100);
		page4Table6Cell1table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page4Table6Cell1table1.setWidths(new int[] { 100, 7, 100, 7, 100, 7, 100 });
		page4Table6Cell1table1.addCell(new Phrase("Agent Use Only : ", font));
		page4Table6Cell1table1.addCell(check1);
		page4Table6Cell1table1.addCell(new Phrase("Web Application ", font));
		page4Table6Cell1table1.addCell(check2);
		page4Table6Cell1table1.addCell(new Phrase("Telephonic Application ", font));
		page4Table6Cell1table1.addCell(check3);
		page4Table6Cell1table1.addCell(new Phrase("Broker Application ", font));

		PdfPCell page4table6Cell1 = new PdfPCell(page4Table6Cell1table1);
		page4table6Cell1.setBorderWidthBottom(0.1f);
		page4table6Cell1.setBorderColorBottom(java.awt.Color.WHITE);
		page4Table6.addCell(page4table6Cell1);
	}

	/**
	 * @param page3Table1
	 * @param check1
	 * @param checkBoxFlagForCellUS
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void displayCheckBoxInPDFforForm3table1cellUS(PdfPTable page3Table1, Image check1,
			String checkBoxFlagForCellUS) throws DocumentException, IOException {

		PdfPTable page3table1cellUscheck = new PdfPTable(2);
		page3table1cellUscheck.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page3table1cellUscheck.setWidths(new int[] { 2, 80 });
		page3table1cellUscheck.addCell(check1);
		page3table1cellUscheck.addCell(new Phrase("No longer eligible for Special Needs Plan and was disenrolled : "
				+ (getChangedValue(checkBoxFlagForCellUS)), font));

		PdfPCell page3table1cell112 = new PdfPCell(page3table1cellUscheck);
		page3table1cell112.setBorderWidthBottom(0.1f);
		page3table1cell112.setBorderColorBottom(java.awt.Color.WHITE);
		page3table1cell112.setBorderColorTop(java.awt.Color.WHITE);
		page3Table1.addCell(page3table1cell112);

	}

	/**
	 * @param page3Table1
	 * @param check1
	 * @param checkBoxFlagforCell10
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */

	private static void displayCheckBoxInPDFforForm3table1cell10(PdfPTable page3Table1, Image check1,
			String checkBoxFlagforCell10) throws DocumentException, IOException {

		PdfPTable page3table1cell10check = new PdfPTable(2);
		page3table1cell10check.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page3table1cell10check.setWidths(new int[] { 2, 80 });
		page3table1cell10check.addCell(check1);
		
		//page3table1cell10check.addCell(new Phrase("I was enrolled in a Special Needs Plan (SNP) but I have lost the special needs qualification required tobe in that plan. "
		//		+ "I was disenrolled from the SNP on (insert date)  "
		//		+ (getChangedValue(checkBoxFlagforCell10)), font));
		
		page3table1cell10check.addCell(new Phrase("I was affected by a weather-related emergency or major disaster (as declared by the Federal Emergency Management " +
				"Agency (FEMA). One of the other statements here applied to me, but I was unable to make my enrollment because of the natural disaster. "
				+ (getChangedValue(checkBoxFlagforCell10)), font));

		PdfPCell page3table1cell112 = new PdfPCell(page3table1cell10check);
		page3table1cell112.setBorderWidthBottom(0.1f);
		page3table1cell112.setBorderColorBottom(java.awt.Color.WHITE);
		page3table1cell112.setBorderColorTop(java.awt.Color.WHITE);
		page3Table1.addCell(page3table1cell112);
	}

	/**
	 * @param page3Table1
	 * @param check1
	 * @param checkBoxFlagforCell8
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void displayCheckBoxInPDFforForm3table1cell9(PdfPTable page3Table1, Image check1,
			String checkBoxFlagforCell8) throws DocumentException, IOException {

		PdfPTable page3table1cell9check = new PdfPTable(2);
		page3table1cell9check.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page3table1cell9check.setWidths(new int[] { 2, 80 });
		//page3table1cell9check.addCell(check1);
		page3table1cell9check.addCell(
				new Phrase("Moving in, live in, or recently moved out of a Long-Term Care Facility (nursing home) : "
						+ (getChangedValue(checkBoxFlagforCell8)), font));

		PdfPCell page3table1cell9 = new PdfPCell(page3table1cell9check);
		page3table1cell9.setBorderWidthBottom(0.1f);
		page3table1cell9.setBorderColorBottom(java.awt.Color.WHITE);
		page3table1cell9.setBorderColorTop(java.awt.Color.WHITE);
		//page3Table1.addCell(page3table1cell9);
	}

	/**
	 * @param page3Table1
	 * @param check1
	 * @param checkBoxFlagforCell7
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void displayCheckBoxInPDFforForm3table1cell8(PdfPTable page3Table1, Image check1,
			String checkBoxFlagforCell7) throws DocumentException, IOException {

		PdfPTable page3table1cell8check = new PdfPTable(2);
		page3table1cell8check.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page3table1cell8check.setWidths(new int[] { 2, 80 });
		//page3table1cell8check.addCell(check1);
		page3table1cell8check
				.addCell(new Phrase("Have Medicaid or the state helps pay for your Medicare. Medicaid Number : "
						+ (getChangedValue(checkBoxFlagforCell7)), font));

		PdfPCell page3table1cell8 = new PdfPCell(page3table1cell8check);
		page3table1cell8.setBorderWidthBottom(0.1f);
		page3table1cell8.setBorderColorBottom(java.awt.Color.WHITE);
		page3table1cell8.setBorderColorTop(java.awt.Color.WHITE);
		//page3Table1.addCell(page3table1cell8);
	}

	/**
	 * @param page2Table1
	 * @param check1
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void displayCheckBoxInPDFforForm2table1cell8(PdfPTable page2Table1, Image check1)
			throws DocumentException, IOException {

		PdfPTable page2table1cell8check_table2 = new PdfPTable(2);
		page2table1cell8check_table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2table1cell8check_table2.setWidths(new int[] { 2, 80 });
		page2table1cell8check_table2.addCell(check1);
		page2table1cell8check_table2.addCell(new Phrase("Get a bill", font));

		PdfPCell page2table1cell8 = new PdfPCell(page2table1cell8check_table2);
		page2table1cell8.setBorderWidthBottom(0.1f);
		page2table1cell8.setBorderColorBottom(java.awt.Color.WHITE);
		page2table1cell8.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell8);

	}

	/**
	 * @param page2Table1
	 * @param buttonImage
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void displayCheckBoxInPDFforForm2table1cell9(PdfPTable page2Table1, Image buttonImage)
			throws DocumentException, IOException {

		PdfPTable page2table1cell9check_table2 = new PdfPTable(2);
		page2table1cell9check_table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2table1cell9check_table2.setWidths(new int[] { 2, 80 });
		page2table1cell9check_table2.addCell(buttonImage);
		page2table1cell9check_table2.addCell(new Phrase("Automatic deduction from your monthly"
				+ "	Social Security or Railroad Retirement Board (RRB) benefit check."
				+ " (The Social Security/RRB deduction may take two or more months to "
				+ "begin after Social Security or RRB approves the deduction. In most"
				+ " cases, if Social Security or RRBaccepts your request for automatic "
				+ "deduction, the first deduction from your Social Security or RRB "
				+ "benefit check will include all premiums due from your enrollment "
				+ "effective date up to the point withholding begins. If Social "
				+ "Security or RRB does not approve your request for automatic "
				+ "deduction, we will send you a paper bill for your monthly "
				+ "premiums.\n I get monthly benefits from : \n)",font));
		
		page2table1cell9check_table2.addCell(buttonImage);
		page2table1cell9check_table2.addCell(new Phrase("Social Security",font));
		page2table1cell9check_table2.addCell(buttonUncheckImage);
		page2table1cell9check_table2.addCell(new Phrase("RRB",font));
		
		PdfPCell page2table1cell9 = new PdfPCell(page2table1cell9check_table2);
		page2table1cell9.setBorderWidthBottom(0.1f);
		page2table1cell9.setBorderColorBottom(java.awt.Color.WHITE);
		page2table1cell9.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell9);

	}
	private static void displayCheckBoxInPDFforForm2table1cell9_1(PdfPTable page2Table1, Image buttonImage)
			throws DocumentException, IOException {

		PdfPTable page2table1cell9check_table2 = new PdfPTable(2);
		page2table1cell9check_table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2table1cell9check_table2.setWidths(new int[] { 2, 80 });
		page2table1cell9check_table2.addCell(buttonImage);
		page2table1cell9check_table2.addCell(new Phrase("Automatic deduction from your monthly"
				+ "	Social Security or Railroad Retirement Board (RRB) benefit check."
				+ " (The Social Security/RRB deduction may take two or more months to "
				+ "begin after Social Security or RRB approves the deduction. In most"
				+ " cases, if Social Security or RRBaccepts your request for automatic "
				+ "deduction, the first deduction from your Social Security or RRB "
				+ "benefit check will include all premiums due from your enrollment "
				+ "effective date up to the point withholding begins. If Social "
				+ "Security or RRB does not approve your request for automatic "
				+ "deduction, we will send you a paper bill for your monthly "
				+ "premiums.\n I get monthly benefits from : \n)",font));
		
		page2table1cell9check_table2.addCell(buttonUncheckImage);
		page2table1cell9check_table2.addCell(new Phrase("Social Security",font));
		page2table1cell9check_table2.addCell(buttonImage);
		page2table1cell9check_table2.addCell(new Phrase("RRB",font));
		
		PdfPCell page2table1cell9 = new PdfPCell(page2table1cell9check_table2);
		page2table1cell9.setBorderWidthBottom(0.1f);
		page2table1cell9.setBorderColorBottom(java.awt.Color.WHITE);
		page2table1cell9.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell9);

	}
	/**
	 * @param page2Table1
	 * @param check1
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	/*private static void displayCheckBoxInPDFforForm2table1cell12(PdfPTable page2Table1, Image check1)
			throws DocumentException, IOException {

		PdfPTable page2table1cell12check_table2 = new PdfPTable(2);
		page2table1cell12check_table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2table1cell12check_table2.setWidths(new int[] { 2, 80 });
		page2table1cell12check_table2.addCell(check1);
		page2table1cell12check_table2.addCell(new Phrase(
				"Automatic deduction from your monthly Social Security benefit check. The Social Security deduction may take several months to begin. Please be aware, if the withholding does not start at time of enrollment, you will be responsible for payment until withholding begins. You will receive a bill",
				font));

		PdfPCell page2table1cell12 = new PdfPCell(page2table1cell12check_table2);
		page2table1cell12.setBorderWidthBottom(0.1f);
		page2table1cell12.setBorderColorBottom(java.awt.Color.WHITE);
		page2table1cell12.setBorderColorTop(java.awt.Color.WHITE);
		page2Table1.addCell(page2table1cell12);
	}*/

	/**
	 * @param page2Table2
	 * @param check1
	 * @param check2
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	/*
	 * private static void displayButtonInPDFforForm2table2cell9(PdfPTable
	 * page2Table2, Image check1, Image check2) throws DocumentException,
	 * IOException {
	 * 
	 * PdfPTable page2table2Cell9Buttontable = new PdfPTable(5);
	 * page2table2Cell9Buttontable.getDefaultCell().setBorder(Rectangle.
	 * NO_BORDER); page2table2Cell9Buttontable.setWidths(new int[] { 200, 6, 10,
	 * 6, 10 }); page2table2Cell9Buttontable.addCell(new Phrase(
	 * "Will you have any other prescription drug coverage in addition to Optima Medicare HMO or State Pharmaceutical Assistance Programs?"
	 * , font)); page2table2Cell9Buttontable.addCell(check1);
	 * page2table2Cell9Buttontable.addCell(new Phrase("Yes", font));
	 * page2table2Cell9Buttontable.addCell(check2);
	 * page2table2Cell9Buttontable.addCell(new Phrase("No", font));
	 * 
	 * PdfPCell page2table2cell9 = new PdfPCell(page2table2Cell9Buttontable);
	 * page2table2cell9.setBorderWidthBottom(0.1f);
	 * page2table2cell9.setBorderColorBottom(java.awt.Color.WHITE);
	 * page2table2cell9.setBorderColorTop(java.awt.Color.WHITE);
	 * page2Table2.addCell(page2table2cell9);
	 * 
	 * }
	 */
	/**
	 * @param page2Table2
	 * @param check1
	 * @param check2
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void displayButtonInPDFforForm2table2cell2(PdfPTable page2Table2, Image check1, Image check2)
			throws DocumentException, IOException {

		PdfPTable page2table2Cell3Buttontable = new PdfPTable(5);
		page2table2Cell3Buttontable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2table2Cell3Buttontable.setWidths(new int[] { 200, 6, 10, 6, 10 });
		page2table2Cell3Buttontable.addCell(new Phrase(
				"2. Some individuals may have other drug coverage, including other private insurance, TRICARE, Federal employee health benefits "
				+ "coverage, VA benefits, or State pharmaceutical assistance programs. "
				+ "Will you have other prescription drug coverage in addition to "+planName+"?",
				font));
		page2table2Cell3Buttontable.addCell(check1);
		page2table2Cell3Buttontable.addCell(new Phrase("Yes", font));
		page2table2Cell3Buttontable.addCell(check2);
		page2table2Cell3Buttontable.addCell(new Phrase("No", font));

		PdfPCell page2table2cell4 = new PdfPCell(page2table2Cell3Buttontable);
		page2table2cell4.setBorderWidthBottom(0.1f);
		page2table2cell4.setBorderColorBottom(java.awt.Color.WHITE);
		page2table2cell4.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(page2table2cell4);
	}

	private static void displayButtonInPDFfornursingHome(PdfPTable page2Table2, Image check1, Image check2)
			throws DocumentException, IOException {

		PdfPTable page2table2Cell3Buttontable = new PdfPTable(5);
		page2table2Cell3Buttontable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2table2Cell3Buttontable.setWidths(new int[] { 200, 6, 10, 6, 10 });
		page2table2Cell3Buttontable.addCell(
				new Phrase("3.Are you a resident in a long-term care facility, such as a nursing home ?", font));
		page2table2Cell3Buttontable.addCell(check1);
		page2table2Cell3Buttontable.addCell(new Phrase("Yes", font));
		page2table2Cell3Buttontable.addCell(check2);
		page2table2Cell3Buttontable.addCell(new Phrase("No", font));

		PdfPCell page2table2cell4 = new PdfPCell(page2table2Cell3Buttontable);
		page2table2cell4.setBorderWidthBottom(0.1f);
		page2table2cell4.setBorderColorBottom(java.awt.Color.WHITE);
		page2table2cell4.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(page2table2cell4);
	}

	private static void displayButtonInPDFforEnrolledMedicaid(PdfPTable page2Table2, Image check1, Image check2)
			throws DocumentException, IOException {

		PdfPTable page2table2Cell3Buttontable = new PdfPTable(5);
		page2table2Cell3Buttontable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2table2Cell3Buttontable.setWidths(new int[] { 200, 6, 10, 6, 10 });
		page2table2Cell3Buttontable.addCell(new Phrase("4.Are you enrolled in your State Medicaid program?", font));
		page2table2Cell3Buttontable.addCell(check1);
		page2table2Cell3Buttontable.addCell(new Phrase("Yes", font));
		page2table2Cell3Buttontable.addCell(check2);
		page2table2Cell3Buttontable.addCell(new Phrase("No", font));

		PdfPCell page2table2cell4 = new PdfPCell(page2table2Cell3Buttontable);
		page2table2cell4.setBorderWidthBottom(0.1f);
		page2table2cell4.setBorderColorBottom(java.awt.Color.WHITE);
		page2table2cell4.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(page2table2cell4);
	}

	private static void displayButtonInPDFforSpouse(PdfPTable page2Table2, Image check1, Image check2)
			throws DocumentException, IOException {

		PdfPTable page2table2Cell3Buttontable = new PdfPTable(5);
		page2table2Cell3Buttontable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page2table2Cell3Buttontable.setWidths(new int[] { 200, 6, 10, 6, 10 });
		page2table2Cell3Buttontable.addCell(new Phrase("5. Do either you or your spouse work?", font));
		page2table2Cell3Buttontable.addCell(check1);
		page2table2Cell3Buttontable.addCell(new Phrase("Yes", font));
		page2table2Cell3Buttontable.addCell(check2);
		page2table2Cell3Buttontable.addCell(new Phrase("No", font));

		PdfPCell page2table2cell5 = new PdfPCell(page2table2Cell3Buttontable);
		page2table2cell5.setBorderWidthBottom(0.1f);
		page2table2cell5.setBorderColorBottom(java.awt.Color.WHITE);
		page2table2cell5.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(page2table2cell5);
	}

	/**
	 * @param page2Table2
	 * @param check1
	 * @param check2
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void displayButtonInPDFforForm2table2cell1(PdfPTable page2Table2, Image check1, Image check2)
			throws DocumentException, IOException {

		PdfPTable page2table2Cell2Buttontable = new PdfPTable(5);
		page2table2Cell2Buttontable.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		page2table2Cell2Buttontable.setWidths(new int[] { 50, 2, 10, 2, 10 });
		page2table2Cell2Buttontable.addCell(new Phrase("1. Do you have End Stage Renal Disease (ESRD)?", font));
		page2table2Cell2Buttontable.addCell(check1);
		page2table2Cell2Buttontable.addCell(new Phrase("Yes", font));
		page2table2Cell2Buttontable.addCell(check2);
		page2table2Cell2Buttontable.addCell(new Phrase("No", font));

		PdfPCell page2table2cell2 = new PdfPCell(page2table2Cell2Buttontable);
		page2table2cell2.setBorderWidthBottom(0.1f);
		page2table2cell2.setBorderColorBottom(java.awt.Color.WHITE);
		page2table2cell2.setBorderColorTop(java.awt.Color.WHITE);
		page2Table2.addCell(page2table2cell2);
	}

	/**
	 * @param page4Table4
	 * @param check1
	 * @param todayDateValue
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void displayCheckBoxInPDFforForm4table(PdfPTable page4Table4, Image check1, String todayDateValue)
			throws DocumentException, IOException {

		PdfPTable page4Table4Cell1table1 = new PdfPTable(3);
		page4Table4Cell1table1.setWidthPercentage(100);
		page4Table4Cell1table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page4Table4Cell1table1.setWidths(new int[] { 5, 100, 100 });
		page4Table4Cell1table1.addCell(check1);
		page4Table4Cell1table1.addCell(new Phrase(" I have read and agree to the above statements", font));
		page4Table4Cell1table1.addCell(new Phrase("Today's Date : " + (getChangedValue(todayDateValue)), font));

		PdfPCell page4table4cell1 = new PdfPCell(page4Table4Cell1table1);
		page4table4cell1.setBorderWidthBottom(0.1f);
		page4Table4.addCell(page4table4cell1);

	}

	/**
	 * @param page3Table2
	 * @param check1
	 * @param check2
	 * @param check3
	 * @param checkBoxFlagfortable2Firstcell
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void displayCheckBoxInPDFforForm3table2(PdfPTable page3Table2, Image check3, Image check4)
			throws DocumentException, IOException {

		/*
		 * PdfPTable page3Cell2TableEmail = new PdfPTable(3);
		 * page3Cell2TableEmail.setWidthPercentage(100);
		 * page3Cell2TableEmail.setWidths(new int[] { 4, 150, 50 });
		 * page3Cell2TableEmail.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		 * page3Cell2TableEmail.addCell(check1);
		 * page3Cell2TableEmail.addCell(new Phrase(
		 * "I give optima health permission to send my plan materials and member communications by email to (Email Address):"
		 * , font)); page3Cell2TableEmail.addCell(new
		 * Phrase((getChangedValue(checkBoxFlagfortable2Firstcell)), font));
		 * 
		 * PdfPTable page3Cell2Table2 = new PdfPTable(2);
		 * page3Cell2Table2.setWidthPercentage(100);
		 * page3Cell2Table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		 * page3Cell2Table2.setWidths(new int[] { 2, 100 });
		 * page3Cell2Table2.addCell(check2); page3Cell2Table2.addCell(new
		 * Phrase("Mail my plan material and member communications", font));
		 */
		/*
		 * PdfPTable page3Cell2Table3 = new PdfPTable(2);
		 * page3Cell2Table3.setWidthPercentage(100);
		 * page3Cell2Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		 * page3Cell2Table3.setWidths(new int[] { 2, 100 });
		 * page3Cell2Table3.addCell(check3); page3Cell2Table3.addCell(new
		 * Phrase(
		 * "Mail my plan material and member communications in large print",
		 * font));
		 * 
		 * PdfPTable page3Cell2Table4 = new PdfPTable(2);
		 * page3Cell2Table4.setWidthPercentage(100);
		 * page3Cell2Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		 * page3Cell2Table4.setWidths(new int[] { 2, 100 });
		 * page3Cell2Table4.addCell(check4); page3Cell2Table4.addCell(new
		 * Phrase("Mail my plan material and member communications in Braille",
		 * font));
		 */

		PdfPTable page3Cell2Table3 = new PdfPTable(2);
		page3Cell2Table3.setWidthPercentage(100);
		page3Cell2Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page3Cell2Table3.setWidths(new int[] { 2, 100 });
		page3Cell2Table3.addCell(check3);
		page3Cell2Table3.addCell(new Phrase("Large print", font));

		/* As per VAP Form, Spanish option is not required*/
		/*IFOX-00407925--Start*/
		 PdfPTable page3Cell2Table4 = new PdfPTable(2);
		page3Cell2Table4.setWidthPercentage(100);
		page3Cell2Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		page3Cell2Table4.setWidths(new int[] { 2, 100 });
		page3Cell2Table4.addCell(check4);
		page3Cell2Table4.addCell(new Phrase("Spanish", font));
		/*IFOX-00407925--End*/
		/*
		 * PdfPTable page3Cell2Table5 = new PdfPTable(2);
		 * page3Cell2Table5.setWidthPercentage(100);
		 * page3Cell2Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		 * page3Cell2Table5.setWidths(new int[] { 2, 100 });
		 * page3Cell2Table5.addCell(check5); page3Cell2Table5.addCell(new
		 * Phrase(
		 * "Mail my plan material and member communications in Audio tape",
		 * font));
		 */
		/*
		 * PdfPCell page3table2cell2 = new PdfPCell(page3Cell2Table2);
		 * page3table2cell2.setBorderWidthBottom(0.1f);
		 * page3table2cell2.setBorderColorTop(java.awt.Color.WHITE);
		 */

		/*
		 * page3Table2.addCell(page3Cell2TableEmail);
		 * page3Table2.addCell(page3Cell2Table2);
		 * page3Table2.addCell(page3Cell2Table5);
		 */
		page3Table2.addCell(page3Cell2Table3);
		/*IFOX-00407925--Start*/
		page3Table2.addCell(page3Cell2Table4);
		/*IFOX-00407925--End*/
	}

	/**
	 * @param page3Table1
	 * @param phrase1
	 * @param phrase2
	 * @param check2
	 * @param check3
	 * @param page3Cell2Table1firstcheck
	 * @param page3Cell2Table1secondcheck
	 * @param page3Cell2Table1
	 * @param absoluteDiskPathOfArialfont
	 * @throws DocumentException
	 * @throws IOException
	 */
	private static void displayCheckBoxInPDFforForm3(PdfPTable page3Table1, String phrase1, String phrase2,
			Image check2, Image check3, PdfPTable page3Cell2Table1firstcheck, PdfPTable page3Cell2Table1secondcheck,
			PdfPTable page3Cell2Table1) throws DocumentException, IOException {

		PdfPTable table = page3Table1;
		PdfPTable FirstcheckTable = page3Cell2Table1firstcheck;
		PdfPTable SecondcheckTable = page3Cell2Table1secondcheck;
		PdfPTable mainTable = page3Cell2Table1;

		FirstcheckTable.setWidthPercentage(100);
		FirstcheckTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		FirstcheckTable.setWidths(new int[] { 6, 100 });
		FirstcheckTable.addCell(check2);
		FirstcheckTable.addCell(new Phrase(phrase1, font));

		SecondcheckTable.setWidthPercentage(100);
		SecondcheckTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		SecondcheckTable.setWidths(new int[] { 5, 100 });
		SecondcheckTable.addCell(check3);
		SecondcheckTable.addCell(new Phrase(phrase2, font));

		mainTable.setWidthPercentage(100);
		mainTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		mainTable.setWidths(new int[] { 60, 80 });
		mainTable.addCell(FirstcheckTable);
		mainTable.addCell(SecondcheckTable);

		PdfPCell page3table1cell2 = new PdfPCell(mainTable);
		page3table1cell2.setBorderWidthBottom(0.1f);
		page3table1cell2.setBorderColorBottom(java.awt.Color.WHITE);
		page3table1cell2.setBorderColorTop(java.awt.Color.WHITE);
		table.addCell(page3table1cell2);
	}

	/**
	 * @param fieldValue
	 * @return
	 */
	private static String getChangedValue(String fieldValue) {
		return fieldValue != null ? fieldValue : "";
	}
	/**
	 * Method is used to set the selected plan name.
	 * 
	 * @param request
	 * @return
	 */
	private static void setVAPPlanNamePremiumType(String pbpId) {
		planName = "Virginia Premier Advantage ";
		if(pbpId.equalsIgnoreCase("001")){
			planName = planName + "Elite";
			planPremium = "$0.0";
			planNameType = "(HMO SNP) ";
		}else if(pbpId.equalsIgnoreCase("002")){
			planName = planName + "Gold";
			planPremium = "$0.0";
			planNameType = "(HMO) ";
		}else if(pbpId.equalsIgnoreCase("003")){
			planName = planName + "Platinum";
			planPremium = "$29.0";
			planNameType = "(HMO) ";
		}
	}
}
