package com.medicare.helper;

import java.io.File;  
import java.io.IOException;
import java.util.Properties;
import org.apache.log4j.Logger;
import com.jscape.inet.sftp.Sftp;  
import com.jscape.inet.sftp.SftpException;  
import com.jscape.inet.sftp.events.SftpAdapter;  
import com.jscape.inet.sftp.events.SftpConnectedEvent;  
import com.jscape.inet.sftp.events.SftpDisconnectedEvent;  
import com.jscape.inet.ssh.util.SshParameters;  

public class SFTPUploader extends SftpAdapter{  
	
	
	private final static Logger LOGGER = Logger.getLogger(M360AppUtil.class
			.getName()); 
/*	private String ftpHostname = "transfer.medicare-solution.com";  
	private String ftpUsername = "FTPHCF0068";  
	private String  ftpPassword = "siUm8acI"; 
	
	public SFTPUploader() {  
		this.ftpHostname = ftpHostname;  
		this.ftpUsername = ftpUsername;  
		this.ftpPassword = ftpPassword;  
	} */ 
	

	public void doUpload(String batchFilelocation,String batchFilename,String ftpFileLocation, String Hostname, String Username, String Password) throws SftpException {  
		SshParameters params = new SshParameters(Hostname, Username,  
				Password);  
		Sftp ftp = new Sftp(params);  
		ftp.addSftpListener(new SFTPUploader());  
		ftp.connect();  
		String listing = ftp.getDirListingAsString();  
		LOGGER.info(listing); 
		ftp.setLocalDir(new File(""+ftpFileLocation+""));  
		LOGGER.info(ftp.getLocalDir());
		ftp.upload(batchFilelocation);
		
		LOGGER.info("successfully Uploaded");
		ftp.disconnect();  
		LOGGER.info("Connection is FTP Site : " + Hostname  
				+ " has now disconnected");
	}  

	/** 
	 * Captures FtpConnectedEvent event 
	 */  
	public void connected(SftpConnectedEvent evt) {  
		LOGGER.info("Connected to server: " + evt.getHostname());
	}  

	/** 
	 * Captures FtpDisconnectedEvent event 
	 */  
	public void disconnected(SftpDisconnectedEvent evt) {  
		LOGGER.info("Disconnected from server: " + evt.getHostname());
	}  

	public static void FTPUploader(String batchFilelocation,String batchFilename) throws IOException { 
		LOGGER.info(" Start : In main of SFTPUploader class");
		Properties propPath = new Properties();
		propPath.load(SFTPUploader.class.getClassLoader().getResourceAsStream(
				"saveLocation.properties"));
		String ftpHostname;  
		String ftpUsername;  
		String ftpPassword; 
		String ftpFileLocation;
		try {  
			ftpHostname = propPath.getProperty("VAP.hostURL.EEM360URL");  
			ftpUsername = propPath.getProperty("VAP.host.EEM360Username");  
			ftpPassword =propPath.getProperty("VAP.host.EEM360Password") ;
			ftpFileLocation = propPath.getProperty("VAP.locationpath.EEM360batchfilePickup");  
			
			SFTPUploader example = new SFTPUploader();  
			example.doUpload(batchFilelocation,batchFilename,ftpFileLocation,ftpHostname,ftpUsername,ftpPassword);  

		} catch (Exception e) {
			LOGGER.error("Exception in SFTPUploader class disconnect Method : "+e.getMessage());
			LOGGER.fatal("Exception in SFTPUploader class disconnect Method : "+e.getMessage());
		}  
	}  
}
