package com.medicare.helper;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
 
/**
* @author 
*
*/
public class JschSftpUploader { 
	
	private final static Logger LOGGER = Logger.getLogger(JschSftpUploader.class
			.getName()); 
/**
*
*/
public JschSftpUploader() {
}
 
/**
* @param args
*/
//public static void main(String[] args) {
	
public static void JschSFTPUploader(String batchFilename) throws IOException {
	Session session = null;
    Channel channel = null;
    
    LOGGER.info(" Start : In main of SFTPUploader class");
	Properties propPath = new Properties();
	propPath.load(SFTPUploader.class.getClassLoader().getResourceAsStream(
			"saveLocation.properties"));
	
	try {  
		String	ftpHostname = propPath.getProperty("hostURL.EEM360URL");  
		String	ftpUsername = propPath.getProperty("host.EEM360Username");  
		String	ftpPassword =propPath.getProperty("host.EEM360Password") ;
		String	EEmSeverFileLocation = propPath.getProperty("locationpath.M360incomingFolder");  
		String	batchFileLocation = propPath.getProperty("locationpath.EEM360batchfile");
		String fileUpload = batchFileLocation+batchFilename+".txt";
		LOGGER.info("-----> ftpHostname :"+ftpHostname);
		LOGGER.info("-----> ftpUsername :"+ftpUsername);
		LOGGER.info("-----> ftpPassword :"+ftpPassword);
		LOGGER.info("-----> EEmSeverFileLocation :"+EEmSeverFileLocation);
		LOGGER.info("-----> batchFileLocation :"+batchFileLocation);
		LOGGER.info("-----> fileUpload :"+fileUpload);
   
        JSch ssh = new JSch();
        session = ssh.getSession(ftpUsername,ftpHostname,22);
        session.setConfig("StrictHostKeyChecking", "no");
        session.setPassword(ftpPassword);
        session.connect();
        channel = session.openChannel("sftp");
        channel.connect();
        ChannelSftp sftp = (ChannelSftp) channel;
        sftp.put(fileUpload, EEmSeverFileLocation);
       
        LOGGER.info("successfuly completed");
        LOGGER.info("file Sent : "+fileUpload);
    } catch (JSchException e) {
        LOGGER.error("in SFTPUploader jschexception");
        e.printStackTrace();
    } catch (SftpException e) {
    	 LOGGER.error("in SFTPUploader SFTpexception");
    } finally {
        if (channel != null) {
            channel.disconnect();
        }
        if (session != null) {
            session.disconnect();
        }
    }
}


public static void JschSFTPUploader(String customerId, String batchFilename) throws IOException {
	Session session = null;
    Channel channel = null;
    
    LOGGER.info(" JschSFTPUploader : Begin : CustomerId [" + customerId + "] ");

	String fileUpload = null;
	String	ftpHostname = null;
	String	ftpUsername = null;
	String	ftpPassword = null;
	String	batchFileLocation = null;
	String	EEmSeverFileLocation = null;
	
	String appUploadFilePrefix = null;

	Properties propPath = new Properties();
	propPath.load(SFTPUploader.class.getClassLoader().getResourceAsStream("saveLocation.properties"));

	try {
		
		if(null != customerId && customerId.trim().equalsIgnoreCase("HCF0331")) {

			ftpHostname = propPath.getProperty("hostURL.EEM360URL");  
/*			ftpUsername = propPath.getProperty("SHP.host.EEM360Username");  
			ftpPassword =propPath.getProperty("SHP.host.EEM360Password") ;
			EEmSeverFileLocation = propPath.getProperty("SHP.locationpath.M360incomingFolder");  
			batchFileLocation = propPath.getProperty("SHP.locationpath.EEM360batchfile");
*/
			ftpUsername = propPath.getProperty(customerId +".host.EEM360Username");  
			ftpPassword =propPath.getProperty(customerId +".host.EEM360Password") ;
			EEmSeverFileLocation = propPath.getProperty(customerId +".locationpath.M360incomingFolder");  
			batchFileLocation = propPath.getProperty(customerId +".locationpath.EEM360batchfile");
			
			
		}else if(null != customerId && customerId.trim().equalsIgnoreCase("HCF0232")) {
			ftpHostname = propPath.getProperty("VAP.hostURL.EEM360URL");  
			ftpUsername = propPath.getProperty("VAP.host.EEM360Username");  
			ftpPassword =propPath.getProperty("VAP.host.EEM360Password") ;
			EEmSeverFileLocation = propPath.getProperty("VAP.locationpath.M360incomingFolder");  
			batchFileLocation = propPath.getProperty("VAP.locationpath.EEM360batchfile");
			appUploadFilePrefix = propPath.getProperty("VAP.batchFile.Name");
			
		} else {

			ftpHostname = propPath.getProperty("hostURL.EEM360URL");  
			ftpUsername = propPath.getProperty("host.EEM360Username");  
			ftpPassword =propPath.getProperty("host.EEM360Password") ;
			EEmSeverFileLocation = propPath.getProperty("locationpath.M360incomingFolder");  
			batchFileLocation = propPath.getProperty("locationpath.EEM360batchfile");
		}
		fileUpload = batchFileLocation + batchFilename + ".txt";

		LOGGER.info(" Host [" + ftpHostname + "], User [" + ftpUsername + "], Password [" + ftpPassword + "] ");
		LOGGER.info(" M360incomingFolder  [" + EEmSeverFileLocation + "], BatchFileLocation [" + batchFileLocation + "] ");
		LOGGER.info(" FileUpload Location [" + fileUpload + "] ");


        JSch ssh = new JSch();
        session = ssh.getSession(ftpUsername,ftpHostname,22);
        session.setConfig("StrictHostKeyChecking", "no");
        session.setPassword(ftpPassword);
        session.connect(5000);
        channel = session.openChannel("sftp");
        channel.connect();
        ChannelSftp sftp = (ChannelSftp) channel;
        sftp.put(fileUpload, EEmSeverFileLocation);

        LOGGER.info(" JschSFTPUploader : File [" + fileUpload + "] successfully sent to server ...");

        if("HCF0232".equalsIgnoreCase(customerId))
        {
        	String sourceDirectory = fileUpload.substring(0, fileUpload.lastIndexOf("\\"));
	        String fileName = fileUpload.substring(fileUpload.lastIndexOf("\\") + 1);
			String destinationDirectgory = fileUpload.substring(0, fileUpload.lastIndexOf("\\") + 1 ) + "Archive";

			File temp = new File(destinationDirectgory);
			if(!temp.exists())
	        	temp.mkdir();

	        archiveSourceFile(fileUpload, destinationDirectgory + "\\" + fileName);

	        LOGGER.info(" JschSFTPUploader : File [" + fileName + "] archived Successfully... ");
        }

        /*
        if("HCF0232".equalsIgnoreCase(customerId))
        {
	        LOGGER.info(" JschSFTPUploader : Processing files which were not FTP'd in previous batch runs...");

	        String[] paths = new File(batchFileLocation).list();
	        for(String path:paths)
	        {
	        	LOGGER.info(" JschSFTPUploader : Processing File [" + path + "]... ");

	        	if(null != path && path.indexOf(appUploadFilePrefix.trim()) != -1)
	            {
	                sftp.put(batchFileLocation + path, EEmSeverFileLocation);
	                
	                LOGGER.info(" JschSFTPUploader : File [" + path + "] successfully sent to server location...");
	                
	            	archiveSourceFile(batchFileLocation + path, batchFileLocation + "Archive\\" + path);
	            	
	        	    LOGGER.info(" JschSFTPUploader : File [" + path + "] archived Successfully... ");
	            }
	        }
	        LOGGER.info(" JschSFTPUploader : All files which were not FTP'd in previous runs are processed successfully...");
        }
        */

        LOGGER.info(" JschSFTPUploader : End : CustomerId [" + customerId + "] ");

    } catch (JSchException e) {
        LOGGER.error(" JschSFTPUploader : JSchException : " + e.getMessage());
        e.printStackTrace();
    } catch (SftpException e) {
    	 LOGGER.error(" JschSFTPUploader : SFTpexception : " + e.getMessage());
    	 e.printStackTrace();
    
    } catch (Exception e) {
		 LOGGER.error(" JschSFTPUploader : Exception : " + e.getMessage());
		 e.printStackTrace();
    }
	finally {
        if (channel != null) {
            channel.disconnect();
        }
        if (session != null) {
            session.disconnect();
        }
    }

}



public static void uploadToFTP(String customerId, String filename) throws IOException {
	Session session = null;
    Channel channel = null;
    
    LOGGER.info(" JschSFTPUploader : Begin : CustomerId [" + customerId + "] ");

	String fileUpload = null;
	String	ftpHostname = null;
	String	ftpUsername = null;
	String	ftpPassword = null;
	String	batchFileLocation = null;
	String	EEmSeverFileLocation = null;

	Properties propPath = new Properties();
	propPath.load(SFTPUploader.class.getClassLoader().getResourceAsStream("saveLocation.properties"));

	try {
		
		if(null != customerId && customerId.trim().equalsIgnoreCase("HCF0331")) {

			ftpHostname = propPath.getProperty("hostURL.EEM360URL");  
/*			ftpUsername = propPath.getProperty("SHP.host.EEM360Username");  
			ftpPassword =propPath.getProperty("SHP.host.EEM360Password") ;
			EEmSeverFileLocation = propPath.getProperty("SHP.locationpath.M360incomingFolder");  
			batchFileLocation = propPath.getProperty("SHP.locationpath.EEM360batchfile");
*/
			ftpUsername = propPath.getProperty(customerId +".host.EEM360Username");  
			ftpPassword =propPath.getProperty(customerId +".host.EEM360Password") ;
			EEmSeverFileLocation = propPath.getProperty(customerId +".locationpath.M360incomingFolder");  
			
			
		}
		
		fileUpload = filename;

		LOGGER.info(" FTP Host [" + ftpHostname + "], User [" + ftpUsername + "], Password [" + ftpPassword + "] ");
		LOGGER.info(" Client FTP Receive Location  [" + EEmSeverFileLocation );
		LOGGER.info(" FileUpload Location [" + fileUpload + "] ");

        JSch ssh = new JSch();
        session = ssh.getSession(ftpUsername,ftpHostname,22);
        session.setConfig("StrictHostKeyChecking", "no");
        session.setPassword(ftpPassword);
        session.connect(5000);
        channel = session.openChannel("sftp");
        channel.connect();
        ChannelSftp sftp = (ChannelSftp) channel;
        sftp.put(fileUpload, EEmSeverFileLocation);

        LOGGER.info(" JschSFTPUploader : File successfuly sent to the location [" + fileUpload + "] ");
        LOGGER.info(" JschSFTPUploader : End : CustomerId [" + customerId + "] ");

    } catch (JSchException e) {
        LOGGER.error(" JschSFTPUploader : JSchException : " + e.getMessage());
        e.printStackTrace();
    } catch (SftpException e) {
    	 LOGGER.error(" JschSFTPUploader : SFTpexception : " + e.getMessage());
    	 e.printStackTrace();
    } finally {
        if (channel != null) {
            channel.disconnect();
        }
        if (session != null) {
            session.disconnect();
        }
    }

}


public static void archiveSourceFile(String sourceFileAbsolutePath, String destinationDirectoryPath) throws Exception
{
	
	java.io.InputStream inStream = null;
	java.io.OutputStream outStream = null;

    //LOGGER.info(" JschSFTPUploader : archiveSourceFile : SourceFileAbsolutePath [" +
    //		sourceFileAbsolutePath + "], DestinationDirectoryPath [" + destinationDirectoryPath + "] ");
	
	try{
	    java.io.File srcFilePath = new java.io.File(sourceFileAbsolutePath);
	    java.io.File dstFilePath =new java.io.File(destinationDirectoryPath);

	    inStream = new java.io.FileInputStream(srcFilePath);
	    outStream = new java.io.FileOutputStream(dstFilePath);

	    byte[] buffer = new byte[1024];

	    int length;
	    while ((length = inStream.read(buffer)) > 0)
	    	outStream.write(buffer, 0, length);

	}catch(IOException e){
		LOGGER.error(" JschSFTPUploader : archiveSourceFile : File [" + sourceFileAbsolutePath + "] : Exception : " + e.getMessage());
	    throw e;
	
	} finally {
		if(null != inStream)
			inStream.close();
		
		if(null != outStream)
			outStream.close();
	}
	new File(sourceFileAbsolutePath).delete();
}



public static void main(String args[]){
	
	try{
		JschSFTPUploader(args[0]);
	}catch(Exception e){
		e.printStackTrace();
	}
	
}

}