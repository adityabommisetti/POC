package com.medicare.helper;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.apache.commons.codec.binary.Base64;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.medicare.model.UserAccountDetails;
import com.medicare.model.UserAddress;
import com.medicare.model.UserAgentDetails;
import com.medicare.model.UserDetails;
import com.medicare.model.UserLegalRepDetails;
import com.medicare.model.UserOtherPolicyDetails;
import com.medicare.model.UserPolicyDetails;
import com.medicare.vo.AgreeDetailsVO;
import com.medicare.vo.AttestationDetailsVO;
import com.medicare.vo.PolicyDetailsVO;
import com.medicare.vo.UserDetailsVO;

public class MedicareUtil {

	private final static Logger LOGGER = Logger.getLogger(MedicareUtil.class.getName());
	
	private final static String customerId = "HCF0027";
	/**
	 * @param request
	 * @return
	 * @throws ParseException
	 */
	public static UserDetails getUserDetailsObject(HttpServletRequest request, HttpServletResponse response) {

		LOGGER.info(" Start : In getUserDetailsObject() method of SentaraUtil class");

		UserDetails userDetails = new UserDetails();

		UserDetailsVO userDetailsVO = (UserDetailsVO) request.getSession().getAttribute("userDetailsObjForm1");
		PolicyDetailsVO policyDetailsVO = (PolicyDetailsVO) request.getSession().getAttribute("policyDetailsObjForm1");
		AttestationDetailsVO attestationDetailsVO = (AttestationDetailsVO) request.getSession()
				.getAttribute("attestationDetailsObjForm1");
		AgreeDetailsVO agreeDetailsVO = (AgreeDetailsVO) request.getSession().getAttribute("agreeDetailsObjForm1");

		byte[] ps = Base64.decodeBase64((byte[]) request.getSession().getAttribute("pdfSaveenroll"));

		// to get the sq num
		// int seqNum = (Integer) request.getSession().getAttribute("seqNum");
		int seqNum = 1;
		try {
			seqNum = M360AppUtil.getSequenecNumber();
		} catch (SQLException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}
		System.out.println("seqnum in sentaara util" + seqNum);
		userDetails.setUserId(seqNum);

		userDetails.setPdfBlob(ps);
		// userDetails.setPdfBlob(data);
		// for 2015 application
		System.out.println("campaignID" + userDetailsVO.getCampaignId());
		System.out.println("contrtacid" + userDetailsVO.getContractId());
		System.out.println("effectivedate" + userDetailsVO.getEffDate());
		System.out.println("braille" + attestationDetailsVO.getPreferBraille());
		System.out.println("audiotape" + agreeDetailsVO.getPreferAudioTape());
		System.out.println("broke application" + agreeDetailsVO.getWebtelApp());
		

		if (userDetailsVO.getCampaignId() != null && !userDetailsVO.getCampaignId().isEmpty()) {
			userDetails.setCampaignId(encrypt(userDetailsVO.getCampaignId()));
		} else {
			userDetails.setCampaignId(" ");
		}
		if (userDetailsVO.getContractId() != null && !userDetailsVO.getContractId().isEmpty()) {
			userDetails.setContractId(encrypt(userDetailsVO.getContractId()));
		} else {
			userDetails.setContractId(" ");
		}
		userDetails.setCustomerId(customerId);;
		userDetails.setEffDate(formatDate(userDetailsVO.getEffDate()));
		userDetails.setIsAudipTap(encrypt(agreeDetailsVO.getPreferAudioTape()));
		userDetails.setIsBraille(encrypt(attestationDetailsVO.getPreferBraille()));
		userDetails.setBrokerApp(encrypt(agreeDetailsVO.getWebtelApp()));

		userDetails.setEemFlag("N");
		userDetails.setOptimaPlan(encrypt(userDetailsVO.getOptimaMedicare()));
		userDetails.setFirstName(encrypt(userDetailsVO.getFirstName().toUpperCase()));
		userDetails.setLastName(encrypt(userDetailsVO.getLastName().toUpperCase()));
		userDetails.setMiddleInitial(encrypt(userDetailsVO.getMiddleInitial().toUpperCase()));
		userDetails.setSuffix(encrypt(userDetailsVO.getSuffix()));
		userDetails.setBirthDate(formatDate(userDetailsVO.getBirthDate()));
		// userDetails.setBirthDate(Date(userDetailsVO.getBirthDate()));
		userDetails.setSex(encrypt(userDetailsVO.getSex()));
		userDetails.setHomePhneNum(encrypt(userDetailsVO.getHomePhNumber()));
		System.out.println("alt ph num" + userDetailsVO.getAltrPhNumber());
		userDetails.setAltrPhneNum(encrypt(userDetailsVO.getAltrPhNumber()));
		userDetails.setEmailAddr(encrypt(userDetailsVO.getEmailAddr()));
		userDetails.setEmrgContactName(encrypt(userDetailsVO.getEmergencyCont()));
		userDetails.setRelationship(encrypt(userDetailsVO.getRelationYou()));
		userDetails.setEmrgPhneNum(encrypt(userDetailsVO.getEmergPhNum()));
		/*userDetails.setPrimaryPhysician(encrypt(userDetailsVO.getPhysician()));
		System.out.println("physician whithout encryption" + userDetailsVO.getPhysician());
		System.out.println("physician" + encrypt(userDetailsVO.getPhysician()));*/
		// userDetails.setPrimaryPhysician("JAIN,KIRN");
		userDetails.setMedicareClaimNum(encrypt(userDetailsVO.getMediacrdNumber()));
		userDetails.setMedicareName(encrypt(userDetailsVO.getNameBeneficiary()));
		userDetails.setMedicareSex(encrypt(userDetailsVO.getBeneficiarySex()));
		userDetails.setHospitalDate(formatDate(userDetailsVO.getHospitalDate()));
		userDetails.setMedicalDate(formatDate(userDetailsVO.getMedicalDate()));
		userDetails.setAccptAggrDate(formatDate(agreeDetailsVO.getTodayDate()));
		userDetails.setEmailAddrFormat(encrypt(agreeDetailsVO.getPreferEmail()));
		userDetails.setIsCdFormat(encrypt(agreeDetailsVO.getPreferCd()));
		userDetails.setIsLprintFormat(encrypt(attestationDetailsVO.getPreferlargePrint()));
		userDetails.setRenalDisease(encrypt(policyDetailsVO.getRenalDisease()));
		if (agreeDetailsVO.getTodayDate() != null && !agreeDetailsVO.getTodayDate().isEmpty()) {
			userDetails.setIsAgree(encrypt("Y"));
		} else {
			userDetails.setIsAgree(encrypt("N"));
		}

		userDetails.setApplicationStatus("S");

		String timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime());
		Timestamp ts = Timestamp.valueOf(timeStamp);
		// Timestamp ts = Timestamp.valueOf("2014-10-08 11:57:18.882672");
		System.out.println("ts" + ts);
		// userDetails.setCreatedDate("2014-10-08 11:57:18.882672");
		userDetails.setCreatedDate(new Date());

		// User Address

		Set<UserAddress> userAddressesSet = new HashSet<UserAddress>();
		UserAddress userAddress = null;

		userAddress = new UserAddress();
		userAddress.setAddressId(seqNum);
		userAddress.setUserId(seqNum);
		userAddress.setPermAddress1(encrypt(userDetailsVO.getPermanentAddr()));
		userAddress.setPermAddress2(encrypt(userDetailsVO.getPermanentStrt()));
		userAddress.setPermApartment(encrypt(userDetailsVO.getPermanentApt()));
		userAddress.setPermCity(encrypt(userDetailsVO.getPermanentCity()));
		userAddress.setPermState(encrypt(userDetailsVO.getPermanentState()));
		userAddress.setPermZipCode(encrypt(userDetailsVO.getPermanentZip()));
		userAddress.setMailAddress1(encrypt(userDetailsVO.getMailingAddr()));
		userAddress.setMailAddress2(encrypt(userDetailsVO.getMailingStrt()));
		userAddress.setMailApartment(encrypt(userDetailsVO.getMailingApt()));
		userAddress.setMailCity(encrypt(userDetailsVO.getMailingCity()));
		userAddress.setMailState(encrypt(userDetailsVO.getMailingState()));
		userAddress.setMailZipCode(encrypt(userDetailsVO.getMailingZip()));
		userAddress.setCustomerId(customerId);

		userAddressesSet.add(userAddress);

		// user accounts

		Set<UserAccountDetails> userAccountDetailsSet = new HashSet<UserAccountDetails>();
		UserAccountDetails userAccountDetail = new UserAccountDetails();
		userAccountDetail.setAcntId(seqNum);
		userAccountDetail.setUserId(seqNum);
		userAccountDetail.setCustomerId(encrypt(policyDetailsVO.getCustomerId()));
		
		System.out.println("account NAme" + policyDetailsVO.getAccountHolderName());
		userAccountDetail.setAcntName(encrypt(policyDetailsVO.getAccountHolderName()));

		userAccountDetail.setIsAutoDeduct(encrypt(policyDetailsVO.getAutoDeduction()));
		if (null == policyDetailsVO.getPaymentOption()) {
			userAccountDetail.setIsEtf(encrypt(null));
			userAccountDetail.setIsMonthlyBill(encrypt(null));
		}else if("D".equalsIgnoreCase(policyDetailsVO.getPaymentOption())){
			userAccountDetail.setIsEtf(encrypt(null));
			userAccountDetail.setIsMonthlyBill(encrypt("D"));
		}else if("S".equalsIgnoreCase(policyDetailsVO.getPaymentOption())){
			userAccountDetail.setIsEtf(encrypt("S"));
			userAccountDetail.setIsMonthlyBill(encrypt(null));
		}else if("R".equalsIgnoreCase(policyDetailsVO.getPaymentOption())){
			userAccountDetail.setIsEtf(encrypt("R"));
			userAccountDetail.setIsMonthlyBill(encrypt(null));
		}else{
			userAccountDetail.setIsEtf(encrypt(null));
			userAccountDetail.setIsMonthlyBill(encrypt(null));
		}
		userAccountDetail.setBankRtingNum(encrypt(policyDetailsVO.getBankRoutingNumber()));
		userAccountDetail.setBankAcctNum(encrypt(policyDetailsVO.getBankAccountNumber()));
		userAccountDetailsSet.add(userAccountDetail);

		// user policy Details

		Set<UserPolicyDetails> userPolicyDetailsSet = new HashSet<UserPolicyDetails>();
		UserPolicyDetails userPolicyDetail = new UserPolicyDetails();
		userPolicyDetail.setPolicyId(seqNum);
		userPolicyDetail.setUserId(seqNum);
		userPolicyDetail.setPlanName(encrypt(policyDetailsVO.getPalnName()));
		userPolicyDetail.setPolicyNumber(encrypt(policyDetailsVO.getPolicyNumber()));
		userPolicyDetail.setBeginningDate(formatDate(policyDetailsVO.getBeginingDate()));

		// Added for IFOX-00390466 - Retrofit Medicaid ID Changes: Start
		if(nonNullTrim(policyDetailsVO.getStateMedicaid()).equals("Y"))
			userPolicyDetail.setStateMedicaid("Y");
		else
			userPolicyDetail.setStateMedicaid("N");
		
		if(nonNullTrim(policyDetailsVO.getMedicaidNumber()).equals(""))
			userPolicyDetail.setMedicaidNumber(" ");
		else
			userPolicyDetail.setMedicaidNumber(policyDetailsVO.getMedicaidNumber());
		// Added for IFOX-00390466 - Retrofit Medicaid ID Changes: End
		
		if (agreeDetailsVO.getEligibleEnroll() != null) {
			userPolicyDetail.setIsAnulElgbEnroll(agreeDetailsVO.getEligibleEnroll());
		} else {
			userPolicyDetail.setIsAnulElgbEnroll("N");
		}
		userPolicyDetail.setNewElgbDate(formatDate(agreeDetailsVO.getNewlyEligbleMedicare()));

		userPolicyDetail.setLeavingCovrgDate(formatDate(agreeDetailsVO.getLeavingEmployerCoverage()));

		userPolicyDetail.setRecentMovedDate(formatDate(agreeDetailsVO.getRecentMovedOption()));

		userPolicyDetail.setLeftPaceDate(formatDate(agreeDetailsVO.getRecntLeftPace()));

		userPolicyDetail.setIsBelongStatePharmcy(encrypt(agreeDetailsVO.getBelongStatePharmacy()));

		userPolicyDetail.setBackUsDate(formatDate(agreeDetailsVO.getMovedBackUs()));

		userPolicyDetail.setStateMedicardNum(encrypt(agreeDetailsVO.getMedicardNumber()));

		userPolicyDetail.setMovedOutFacilityDate(formatDate(agreeDetailsVO.getOutLongTermFacility()));

		userPolicyDetail.setNameInstitution(encrypt(agreeDetailsVO.getNameOfInst()));

		userPolicyDetail.setPhoneNumber(encrypt(agreeDetailsVO.getPhNum()));

		userPolicyDetail.setAddressInstitution(encrypt(agreeDetailsVO.getAdressInstStreet()));

		userPolicyDetail.setAddressInstitutionStreet(encrypt(agreeDetailsVO.getAdressInstNumber()));

		userPolicyDetail.setLostCoverageDate(formatDate(agreeDetailsVO.getRecentlyCreditable()));

		userPolicyDetail.setPayPrescriptionDate(formatDate(agreeDetailsVO.getRecieveMedicareDrugs()));

		userPolicyDetail.setNoElgbDrugsDate(formatDate(agreeDetailsVO.getNoEligbPrescDrugs()));

		userPolicyDetail.setOutsidePlanDate(formatDate(agreeDetailsVO.getRecntMovedOutSide()));

		userPolicyDetail.setIsPlanContractCoverage(encrypt(agreeDetailsVO.getPlanEndingContract()));

		userPolicyDetail.setIsNoneStatements(encrypt(agreeDetailsVO.getNoneApplyMe()));

		userPolicyDetail.setSpecialPlanDate(formatDate(agreeDetailsVO.getNoEligSpecial()));
		
		userPolicyDetail.setCustomerId(customerId);

		userPolicyDetail.setOtherReason(encrypt(agreeDetailsVO.getOtherReasons()));
		userPolicyDetailsSet.add(userPolicyDetail);
		

		// user other policy details

		Set<UserOtherPolicyDetails> userOtherPolicyDetailsSet = new HashSet<UserOtherPolicyDetails>();
		UserOtherPolicyDetails userOtherPolicyDetails = null;
		int id = seqNum * 3;
		userOtherPolicyDetails = new UserOtherPolicyDetails();
		userOtherPolicyDetails.setPolicyId(id);
		userOtherPolicyDetails.setUserId(seqNum);
		userOtherPolicyDetails.setCoverageType("MEDICAL");
		userOtherPolicyDetails.setCoverageGroup(encrypt(policyDetailsVO.getMedicalGroupCoverage()));
		userOtherPolicyDetails.setCoverageName(encrypt(policyDetailsVO.getMedicalNameCoverage()));
		userOtherPolicyDetails.setCoverageId(encrypt(policyDetailsVO.getMedicalIdCoverage()));
		userOtherPolicyDetails.setCoveragePeriod(encrypt(policyDetailsVO.getMedicalCoveragePeriod()));
		userOtherPolicyDetails.setCustomerId(customerId);
		userOtherPolicyDetailsSet.add(userOtherPolicyDetails);

		userOtherPolicyDetails = new UserOtherPolicyDetails();
		userOtherPolicyDetails.setPolicyId(id + 1);
		userOtherPolicyDetails.setCoverageType("MEDICALOTHER");
		userOtherPolicyDetails.setCoverageGroup(encrypt(policyDetailsVO.getOtherMedicalGroupCoverage()));
		userOtherPolicyDetails.setCoverageName(encrypt(policyDetailsVO.getOtherMedicalNameCoverage()));
		userOtherPolicyDetails.setCoverageId(encrypt(policyDetailsVO.getOtherMedicalIdCoverage()));
		userOtherPolicyDetails.setCoveragePeriod(encrypt(policyDetailsVO.getOtherMedicalCoveragePeriod()));
		userOtherPolicyDetails.setCustomerId(customerId);
		userOtherPolicyDetailsSet.add(userOtherPolicyDetails);

		userOtherPolicyDetails = new UserOtherPolicyDetails();
		userOtherPolicyDetails.setPolicyId(id + 2);
		userOtherPolicyDetails.setCoverageType("DRUG");
		userOtherPolicyDetails.setCoverageGroup(encrypt(policyDetailsVO.getDurgGroupCoverage()));
		userOtherPolicyDetails.setCoverageName(encrypt(policyDetailsVO.getDurgNameCoverage()));
		userOtherPolicyDetails.setCoverageId(encrypt(policyDetailsVO.getDurgIdCoverage()));
		userOtherPolicyDetails.setCoveragePeriod(encrypt(policyDetailsVO.getDurgCoveragePeriod()));
		userOtherPolicyDetails.setCustomerId(customerId);
		userOtherPolicyDetailsSet.add(userOtherPolicyDetails);

		// user agent details

		Set<UserAgentDetails> userAgentDetailsSet = new HashSet<UserAgentDetails>();
		UserAgentDetails userAgentDetails = new UserAgentDetails();
		userAgentDetails.setAgentId(seqNum);
		userAgentDetails.setUserId(seqNum);
		userAgentDetails.setCustomerId(customerId);
		userAgentDetails.setAgentName(encrypt(agreeDetailsVO.getAgentName()));
		if (agreeDetailsVO.getAep().equalsIgnoreCase("I")) {
			userAgentDetails.setElectionType("");
		} else {
			userAgentDetails.setElectionType(agreeDetailsVO.getAep());
		}
		
		userAgentDetails.setPlanId(encrypt(agreeDetailsVO.getPlanId()));
		userAgentDetails.setSentaraAgentID(encrypt(agreeDetailsVO.getAgentId()));

		if (agreeDetailsVO.getEffectDateCoverage() == null || agreeDetailsVO.getEffectDateCoverage().isEmpty()) {

			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			Calendar cal = Calendar.getInstance();

			if (agreeDetailsVO.getAep().equalsIgnoreCase("A")) {
				cal.set(cal.get(Calendar.YEAR) + 1, 00, 01);
				userAgentDetails.setEffDate(cal.getTime());
			} else if (agreeDetailsVO.getAep().equalsIgnoreCase("I") || agreeDetailsVO.getAep().equalsIgnoreCase("S")) {
				cal.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, 01);
				userAgentDetails.setEffDate(cal.getTime());
			}
		} else {
			userAgentDetails.setEffDate(formatDate(agreeDetailsVO.getEffectDateCoverage()));
		}

		userAgentDetails.setWebTelApp(encrypt(agreeDetailsVO.getWebtelApp()));
		userAgentDetailsSet.add(userAgentDetails);

		// user Legal Represenative details

		Set<UserLegalRepDetails> userLegalRepDetailsSet = new HashSet<UserLegalRepDetails>();
		UserLegalRepDetails userLegalRepDetails = new UserLegalRepDetails();
		userLegalRepDetails.setRepId(seqNum);
		userLegalRepDetails.setUserId(seqNum);
		userLegalRepDetails.setRelationshipEnrolle(encrypt(agreeDetailsVO.getLegalRelationErloll()));
		userLegalRepDetails.setRepAddress(encrypt(agreeDetailsVO.getLegalAddress()));
		userLegalRepDetails.setRepName(encrypt(agreeDetailsVO.getLegalFirstName()));
		userLegalRepDetails.setRepPhnNum(encrypt(agreeDetailsVO.getLegalPhNumber()));
		userLegalRepDetails.setReplastName(encrypt(agreeDetailsVO.getLegalLastName()));
		userLegalRepDetails.setRepMiddleInitial(encrypt(agreeDetailsVO.getLegalMiddleName()));
		userLegalRepDetails.setRepAddressTwo(encrypt(agreeDetailsVO.getLegalAddressTwo()));
		userLegalRepDetails.setRepAddressThree(encrypt(agreeDetailsVO.getLegalAddressThree()));
		userLegalRepDetails.setRepCity(encrypt(agreeDetailsVO.getLegalCity()));
		userLegalRepDetails.setRepState(encrypt(agreeDetailsVO.getLegalState()));
		userLegalRepDetails.setRepzipCode(encrypt(agreeDetailsVO.getLegalZipCode()));
		userLegalRepDetails.setCustomerId(customerId);
		userLegalRepDetailsSet.add(userLegalRepDetails);

		userDetails.setUserAddressesSet(userAddressesSet);
		userDetails.setUserAccountDetailsSet(userAccountDetailsSet);
		userDetails.setUserPolicyDetailsSet(userPolicyDetailsSet);
		userDetails.setUserAgentDetails(userAgentDetailsSet);
		userDetails.setUserLegalRepDetails(userLegalRepDetailsSet);
		userDetails.setUserOtherPolicyDetails(userOtherPolicyDetailsSet);

		remvoeSessionValues(request);
		return userDetails;
	}

	private static String encrypt(String texto) {

		if (texto != null) {
			// System.out.println(" i am in encrypt"+ texto);
			return new String(Base64.encodeBase64(texto.getBytes()));
		} else {
			// System.out.println("i am in non encrypt"+texto);
			return "";
		}
	}

	/**
	 * @param date
	 * @return
	 * @throws ParseException
	 */
	public static Date formatDate(String date) {

		LOGGER.info(" Start : In formatDate() method of SentaraUtil class");
		if (date != null && !date.isEmpty()) {

			// SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

			try {
				System.out.println(" i am printing online date" + date);
				Date dateBeforeConvert = new SimpleDateFormat(VAPConstants.DateFormat).parse(date);
				String convertedDate = new SimpleDateFormat("yyyy-MM-dd").format(dateBeforeConvert);
				Date dateAfterConvert = new SimpleDateFormat("yyyy-MM-dd").parse(convertedDate);
				// System.out.println(convertedDate);
				// System.out.println(dateAfterConvert);
				return dateAfterConvert;
				/*
				 * System.out.println("date"+formatter.parse(date)); return
				 * formatter.parse(date);
				 */
			} catch (ParseException e) {
				e.printStackTrace();
				return null;
			}

		} else {

			// System.out.println(" i am in else block of date because null
			// values");

			String dummyDate = "09/09/9999";
			Date dateBeforeConvert;
			try {
				dateBeforeConvert = new SimpleDateFormat("MM/dd/yyyy").parse(dummyDate);
				String convertedDate = new SimpleDateFormat("yyyy-MM-dd").format(dateBeforeConvert);
				Date dateAfterConvert = new SimpleDateFormat("yyyy-MM-dd").parse(convertedDate);
				// System.out.println(convertedDate);
				// System.out.println(dateAfterConvert);
				// out.println(" i am in else block of date because null
				// values"+dateAfterConvert);
				return dateAfterConvert;

			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			}

		}

	}

	/**
	 * @param request
	 */
	public static void remvoeSessionValues(HttpServletRequest request) {

		LOGGER.info(" Start : In remvoeSessionValues() method of SentaraUtil class");
		request.getSession().removeAttribute("physicianMap");
		request.getSession().removeAttribute("stateMap");
		request.getSession().removeAttribute("relationEnrolle");
		request.getSession().removeAttribute("userDetailsObjForm1");
		request.getSession().removeAttribute("policyDetailsObjForm1");
		request.getSession().removeAttribute("attestationDetailsObjForm1");
		request.getSession().removeAttribute("agreeDetailsObjForm1");
		request.getSession().removeAttribute("userDetailsVO");
		request.getSession().removeAttribute("policyDetails");
		request.getSession().removeAttribute("agreeDetailsVO");
		request.getSession().removeAttribute("pdfSaveenrollGen");
	}

	public static Map<String, String> getRelationEnrollValues() {

		Map<String, String> relationEnrolle = new HashMap<String, String>();
		relationEnrolle.put("DAD", "FATHER");
		relationEnrolle.put("DEP", "DEPENDENT");
		relationEnrolle.put("EMP", "EMPLOYEE");
		relationEnrolle.put("FCH", "FOSTER CHILD");
		relationEnrolle.put("FSP", "FOSTER PARENT");
		relationEnrolle.put("GCH", "GRANDCHILD");
		relationEnrolle.put("GFA", "GRANDFATHER");
		relationEnrolle.put("GMA", "GRANDMOTHER");
		relationEnrolle.put("GPR", "GRANDPARENT");
		relationEnrolle.put("NN", "NIECE/NEPHEW");
		relationEnrolle.put("PAL", "FRIEND");
		relationEnrolle.put("REL", "PHYSICIAN");
		relationEnrolle.put("SCH", "STEP CHILD");
		relationEnrolle.put("SIB", "SIBLING");
		relationEnrolle.put("SPS", "SPOUSE");
		relationEnrolle.put("STP", "STEP PARENT");
		relationEnrolle.put("ATY", "ATTORNEY");
		relationEnrolle.put("GRD", "GUARDIAN");
		relationEnrolle.put("LIF", "LIFE PARTNER");
		relationEnrolle.put("MOM", "MOTHER");
		relationEnrolle.put("OTH", "OTHER");
		relationEnrolle.put("POA", "POWER OF ATTORNEY");
		relationEnrolle.put("REL", "RELATIVE");
		relationEnrolle.put("NCH", "NATURALCHILD");
		relationEnrolle.put("UNK", "UNKNOWN");
	
		
		Map<String, String> sortedRel = sortByValues(relationEnrolle);
		return sortedRel;
	}

	public static Map<String, String> getMaliningStateZipValues() {

		Map<String, String> mailingstatezipvalues = new HashMap<String, String>();
		mailingstatezipvalues.put("Alabama", "AL");
		mailingstatezipvalues.put("Alaska", "AK");
		mailingstatezipvalues.put("Arizona", "AZ");
		mailingstatezipvalues.put("Arkansas", "AS");
		mailingstatezipvalues.put("California", "CA");
		mailingstatezipvalues.put("Colorado", "CO");
		mailingstatezipvalues.put("Connecticut", "CT");
		mailingstatezipvalues.put("Delaware", "DE");
		mailingstatezipvalues.put("Florida", "FL");
		mailingstatezipvalues.put("Georgia", "GA");
		mailingstatezipvalues.put("Hawaii", "HI");
		mailingstatezipvalues.put("Idaho", "ID");
		mailingstatezipvalues.put("Illinois", "IL");
		mailingstatezipvalues.put("Indiana", "IN");
		mailingstatezipvalues.put("Iowa", "IA");
		mailingstatezipvalues.put("Kansas", "KS");
		mailingstatezipvalues.put("Kentucky", "KY");
		mailingstatezipvalues.put("Maine", "ME");
		mailingstatezipvalues.put("Maryland", "MD");
		mailingstatezipvalues.put("Massachusetts", "MA");
		mailingstatezipvalues.put("Michigan", "MI");
		mailingstatezipvalues.put("Minnesota", "MN");
		mailingstatezipvalues.put("Mississippi", "MS");
		mailingstatezipvalues.put("NCH", "NATURALCHILD");
		mailingstatezipvalues.put("Missouri", "MO");
		mailingstatezipvalues.put("Montana", "MT");
		mailingstatezipvalues.put("Nebraska", "NE");
		mailingstatezipvalues.put("Nevada", "NV");
		mailingstatezipvalues.put("New Hampshire", "NH");
		mailingstatezipvalues.put("New Jersey", "NY");
		mailingstatezipvalues.put("New Mexico", "NM");
		mailingstatezipvalues.put("New York", "NY");
		mailingstatezipvalues.put("North Carolina", "NC");
		mailingstatezipvalues.put("North Dakota", "ND");
		mailingstatezipvalues.put("Ohio", "OH");
		mailingstatezipvalues.put("Oklahoma", "OK");
		mailingstatezipvalues.put("Oregon", "OR");
		mailingstatezipvalues.put("Pennsylvania", "PA");
		mailingstatezipvalues.put("Rhode Island", "RI");
		mailingstatezipvalues.put("South Carolina", "SC");
		mailingstatezipvalues.put("South Dakota", "SD");
		mailingstatezipvalues.put("Tennessee", "TN");
		mailingstatezipvalues.put("Texas", "TX");
		mailingstatezipvalues.put("Utah", "UT");
		mailingstatezipvalues.put("Vermont", "VT");
		mailingstatezipvalues.put("Virginia", "VA");
		mailingstatezipvalues.put("Washington", "WA");
		mailingstatezipvalues.put("West Virginia", "WV");
		mailingstatezipvalues.put("Wisconsin", "WI");
		mailingstatezipvalues.put("Wyoming", "WY");

		return mailingstatezipvalues;
	}

	
	 public static <K extends Comparable,V extends Comparable> Map<K,V> sortByValues(Map<K,V> map){
	        List<Map.Entry<K,V>> entries = new LinkedList<Map.Entry<K,V>>(map.entrySet());
	        Collections.sort(entries, new Comparator<Map.Entry<K,V>>() {
	            @Override
	            public int compare(Entry<K, V> o1, Entry<K, V> o2) {
	                return o1.getValue().compareTo(o2.getValue());
	            }
	        });
	        Map<K,V> sortedMap = new LinkedHashMap<K,V>();
	        for(Map.Entry<K,V> entry: entries){
	            sortedMap.put(entry.getKey(), entry.getValue());
	        }
	     
	        return sortedMap;
	    }

	// Added for IFOX-00390466 - Retrofit Medicaid ID Changes: Start
	public static String nonNullTrim(String s) {
        if (s == null)
            return "";
        return s.trim();
    }
	// Added for IFOX-00390466 - Retrofit Medicaid ID Changes: End
	
}
