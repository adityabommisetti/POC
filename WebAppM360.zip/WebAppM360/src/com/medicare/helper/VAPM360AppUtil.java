package com.medicare.helper;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.medicare.model.FileField;
import com.medicare.model.FixedValueFileField;
import com.medicare.model.NonAvailableFileField;

/**
 * @author SH250285
 * 
 */
public class VAPM360AppUtil {

	private final static Logger LOGGER = Logger.getLogger(VAPM360AppUtil.class.getName());

	/**
	 * @throws Exception
	 */
	@SuppressWarnings("resource")
	public static synchronized void generateM360AppUploadFileForVAP() throws Exception {
		Properties prop = new Properties();
		Properties propPath = new Properties();
		prop.load(VAPM360AppUtil.class.getClassLoader().getResourceAsStream("hibernate.properties"));
		propPath.load(VAPM360AppUtil.class.getClassLoader().getResourceAsStream("saveLocation.properties"));
		LOGGER.info(" Start : In generateM360AppUploadFileForVAP() method of VAPM360AppUtil class");

		String batchFilename = null;
		String batchFilelocation = null;
		Connection conn = null;
		PreparedStatement preparedStatementResulset = null;
		Statement headerStatement = null;
		ResultSet rs = null;
		ResultSet rsHeader = null;
		ResultSet rscounty = null;
		BufferedWriter writer = null;
		int recordsCount = 0;
		String vapAccountID = VAPConstants.vapAccountId;
		boolean isFTPRequired = false;
		
		//Begin: Added for IFOX-00390786 (Phase-II)
		String customerId = null;
		int fileCount = 0;
		int numberOfAttestationFields = 0;
		int attestationCodesWithNonNullValueCounter = 0;
		//End: Added for IFOX-00390786 (Phase-II)
		
		try {
			LOGGER.info("VAPM360AppUtil : Getting connection.");
			Class.forName(prop.getProperty("database.driver"));
			conn = DriverManager.getConnection(prop.getProperty("database.url"), prop.getProperty("database.user"),
					prop.getProperty("database.password"));
			LOGGER.info("VAPM360AppUtil : connected.");
			Date date = new Date();
			DateFormat dateFormatHeader = new SimpleDateFormat("yyyyMMdd");
			DateFormat dateFormatforFilename = new SimpleDateFormat("yyyyMMddHHmm");
			String dateforFilename = dateFormatforFilename.format(date);
			preparedStatementResulset = conn.prepareStatement(VAPConstants.resultSetQuery);
			LOGGER.info("VAPM360AppUtil : Fetching WebApp Files where IS_EEM360FLAG !='Y'.");
			rs = preparedStatementResulset.executeQuery();
			headerStatement = conn.createStatement();
			rsHeader = headerStatement.executeQuery("select  max(id) as ID from WB_EEM360Audit ");
			String headerId = null;
			String uniqueHeaderId = null;
			while (rsHeader.next()) {
				headerId = (rsHeader.getString("ID") == null ? "0" : rsHeader.getString("ID"));
				int maxLengthHeaderLength = VAPConstants.eem360BatchHeaderLength;
				uniqueHeaderId = methodHeaderTailerContent(maxLengthHeaderLength, headerId);
			}
			String dateforHeader = dateFormatHeader.format(date);
			String header = "HDR" + vapAccountID + dateforHeader + uniqueHeaderId + "       "
					+ propPath.getProperty("VAP.batchFile.type");

			boolean headerCreated = false;
			boolean writeTrailer = false;
			
			while (rs.next()) {
				LOGGER.info("VAPM360AppUtil : Found webApp records.");
				
				//Begin: Added for IFOX-00390786 (Phase-II)
				numberOfAttestationFields = 0;
				attestationCodesWithNonNullValueCounter = 0;
				//End: Added for IFOX-00390786 (Phase-II)
				
				++fileCount;
				customerId = rs.getString("Customer_Id");

				if (!headerCreated) {
					batchFilename = propPath.getProperty("VAP.batchFile.Name") + dateforFilename;
					batchFilelocation = propPath.getProperty("VAP.locationpath.EEM360batchfile") + batchFilename + ".txt";
					LOGGER.info("BATCH FILE LOCATION :" + batchFilelocation);
					LOGGER.info("BATCH FILE NAME     :" + batchFilename);
					writer = new BufferedWriter(new FileWriter(batchFilelocation));
					writer.write(header);
					writer.newLine();
					headerCreated = true;
					writeTrailer = true;
					isFTPRequired = true;
				}
				String flag = rs.getString("EEM360FLAG");
				if (flag != null && !flag.isEmpty() && flag.equalsIgnoreCase("Y")) {
					continue;
				}
				String ApplicationNumber = rs.getString("Application_Nbr");
				LOGGER.info(" VAPM360AppUtil. Application Number :" + ApplicationNumber);
				
				//Begin: Added for IFOX-00390786 (Phase-II)
				/*
				for (FileField field : VAPM360FileMetaData.fields) {
					field.write(rs, writer, conn);
				}
				*/

				for (FileField field : VAPM360FileMetaData.fields)
				{
					if(field.isAttestationField())
					{
						numberOfAttestationFields++;

						if(attestationCodesWithNonNullValueCounter < 5 && numberOfAttestationFields < 21 )
						{
							String value = rs.getString(field.getName());

							if(null != value && !value.trim().equals("") && 
									(value.trim().equals("E") || !value.trim().equals("9999-09-09")) )
							{
								if(!value.trim().equals("N"))
								{
									attestationCodesWithNonNullValueCounter++;
									if(attestationCodesWithNonNullValueCounter <= 5)
										populateAttestationDates(attestationCodesWithNonNullValueCounter, value, field, rs, writer, conn);
								}
							}
						}
						if(numberOfAttestationFields == 20 ) { //Last Question (Top to Bottom from Left to Right)

							attestationCodesWithNonNullValueCounter = attestationCodesWithNonNullValueCounter + 1;

							//Selected number of attestation question count is < 5 then, assigning blank values for remaining attestation codes.
							//For ex: If three attestation questions are selected then pass blanks for remaining two attestation questions as
							//we have limitation in M360 which allows maximum of 5 attestation questions.
							if(attestationCodesWithNonNullValueCounter <= 5) { 
								populateDefaultAttestationDates(attestationCodesWithNonNullValueCounter, rs, writer, conn);
							}
						}

					} else {

						//Begin: Added for IFOX-00390786 (Phase-II)
						if("Alt_Corres_Ind".equals(field.getName())) {
							
							if(field instanceof FixedValueFileField) {

								FixedValueFileField altCorrField = (FixedValueFileField) field;

								String spanishLang = rs.getString("spanishLang");
								String largePrint = rs.getString("largePrint");
								
								if(null != spanishLang && spanishLang.trim().equalsIgnoreCase("b"))
									altCorrField.setFixedValue("B");
								else
									if(null != largePrint && largePrint.trim().equalsIgnoreCase("l"))
										altCorrField.setFixedValue("L");
									else
										altCorrField.setFixedValue(" ");
							}
						}
						//End: Added for IFOX-00390786 (Phase-II)
						
						
						//Begin: Added for sending Reason code as 'E6' for SEP Election type 
						if("Special_Election_Reason_Code".equals(field.getName()))
						{
							if(field instanceof FixedValueFileField)
							{
								String electionTypeCode = rs.getString("Election_Type_Code");
								if(null != electionTypeCode && electionTypeCode.trim().equalsIgnoreCase("S"))
									((FixedValueFileField) field).setFixedValue("E6");
							}
						}
						//End: Added for sending Reason code as 'E6' for SEP Election type
						
						field.write(rs, writer, conn);
					}
				}
				//End: Added for IFOX-00390786 (Phase-II)
				
				preparedStatementResulset = conn.prepareStatement(VAPConstants.updateFLAGQuery);
				preparedStatementResulset.setString(1, ApplicationNumber);
				preparedStatementResulset.executeUpdate();

				recordsCount++;
				writer.newLine();
			}
			if (writeTrailer) {
				int finalCount = recordsCount + 2;
				String count = String.valueOf(finalCount);

				// preparedStatementResulset = connection
				// .prepareStatement("INSERT INTO EEM360Audit
				// VALUES(default,?,?,?)");
				// ravindra start here

				preparedStatementResulset = conn.prepareStatement(
						"INSERT INTO WB_EEM360Audit VALUES((select nvl(max(id)+1,1) from WB_eem360audit),?,?,?,?)");

				// ravindra end here
				preparedStatementResulset.setInt(1, recordsCount);
				preparedStatementResulset.setTimestamp(2, getCurrentTimeStamp());
				preparedStatementResulset.setString(3, "success");
				preparedStatementResulset.setString(4, vapAccountID);
				preparedStatementResulset.executeUpdate();
				int maximumTrailerLength = VAPConstants.eem360BatchTrailerLength;
				String tailerCount = methodHeaderTailerContent(maximumTrailerLength, count);
				String tailer = "TLR" + vapAccountID + tailerCount;
				writer.write(tailer);
			}else{
				LOGGER.info("VAPM360AppUtil : Found Zero webApp record.");
			}
		} catch (Exception ex) {
			LOGGER.error("Exception in : M360AppUtill class");
			LOGGER.fatal("Connection is lost");
			ex.printStackTrace();

		} finally {

			//Begin: Added for IFOX-00390786 (Phase-II)
			numberOfAttestationFields = 0;
			attestationCodesWithNonNullValueCounter = 0;
			//End: Added for IFOX-00390786 (Phase-II)
			
			if (writer != null) {
				writer.close();
			}
			if (rs != null) {
				rs.close();
			}
			if (rscounty != null) {
				rscounty.close();
			}
			if (rsHeader != null) {
				rsHeader.close();
			}
			if (preparedStatementResulset != null) {
				preparedStatementResulset.close();
			}
			if (headerStatement != null) {
				headerStatement.close();
			}
			if (conn != null && !conn.isClosed()) {
				conn.close();
			}

		}
		LOGGER.info("VAPM360AppUtil: "+fileCount+" files has been created.");
		if (isFTPRequired) {
			//SFTPUploader.FTPUploader(batchFilelocation, batchFilename);
			JschSftpUploader.JschSFTPUploader(customerId, batchFilename);
		}
		
    	LOGGER.info(" JschSFTPUploader : Processing files which were not FTP'd in previous batch runs...");
        processPendingFiles("HCF0232");
    	
        LOGGER.info(" JschSFTPUploader : All files which were not FTP'd in previous runs are processed successfully...");
		
		LOGGER.info(" End : In generateM360AppUploadFileForVAP() method of VAPM360AppUtil class");
	}

	/**
	 * @param maxLengthTailHeader
	 * @param generateheaderId
	 * @return
	 */
	private static String methodHeaderTailerContent(int maxLengthTailHeader, String generateheaderId) {
		String appender = "0";
		String finalId = null;
		if (generateheaderId.length() < maxLengthTailHeader) {
			int appendingcount = (maxLengthTailHeader - generateheaderId.length());
			for (int count = 1; count < appendingcount; count++) {
				appender = appender + 0;// 1space
			}
			finalId = appender + generateheaderId;
		} else if (generateheaderId.length() == maxLengthTailHeader) {
			finalId = generateheaderId;
		} else if (generateheaderId.length() > maxLengthTailHeader) {
			LOGGER.info("change the sequence");
		}
		return finalId;
	}

	/**
	 * @return
	 */
	private static java.sql.Timestamp getCurrentTimeStamp() {

		java.util.Date today = new java.util.Date();
		return new java.sql.Timestamp(today.getTime());

	}

	public static int getSequenecNumber() throws SQLException, IOException {
		Properties prop = new Properties();
		// Properties propPath = new Properties();
		prop.load(VAPM360AppUtil.class.getClassLoader().getResourceAsStream("hibernate.properties"));
		Connection connection = null;
		PreparedStatement preparedStatementResulset = null;
		/*
		 * Statement headerStatement = null; ResultSet rs = null; ResultSet
		 * rsHeader = null; ResultSet rscounty = null;
		 */
		try {
			Class.forName(prop.getProperty("database.driver"));
			connection = DriverManager.getConnection(prop.getProperty("database.url"),
					prop.getProperty("database.user"), prop.getProperty("database.password"));
			/*
			 * preparedStatementResulset = connection .prepareStatement(
			 * "select max(USER_ID)+1 from USER_DETAILS");
			 */
			// int maxID = 0;
			int maxID = 1;
			Statement s2 = connection.createStatement();
			s2.execute("SELECT MAX(USER_ID)+1 FROM WB_USER_DETAILS");
			ResultSet rs2 = s2.getResultSet(); //
			if (rs2.next()) {
				maxID = rs2.getInt(1);
			}

			return maxID;

			// return 1;

		} catch (Exception ex) {
			LOGGER.error("Exception in : get next val class");
			LOGGER.fatal("Connection is lost");
			ex.printStackTrace();
			// return 0;
			return 1;
		} finally {

			if (preparedStatementResulset != null) {
				preparedStatementResulset.close();
			}

			if (connection != null && !connection.isClosed()) {
				connection.close();
			}
		}
	}
	
	//Begin: Added for IFOX-00390786 (Phase-II)
	private static void populateAttestationDates(int sepReasonCodesWithNonNullValueCounter, String value,
			FileField fileField, ResultSet rs, BufferedWriter writer, Connection conn) throws Exception {

		try {
			new FixedValueFileField("SEP Reason Code "+sepReasonCodesWithNonNullValueCounter, 3, fileField.getAttestationCode()).write(rs, writer, conn);

			if(null != fileField.getAttestationCode()) {

				String attestationCode = fileField.getAttestationCode().trim();
				if(attestationCode.equals("NEW") || attestationCode.equals("PAP") || attestationCode.equals("EOC") ||
						attestationCode.equals("OEP") || attestationCode.equals("DST") )
					new FixedValueFileField("SEP Reason Code " + sepReasonCodesWithNonNullValueCounter +" Date", 8, "        ").write(rs, writer, conn);
				else
					new FixedValueFileField("SEP Reason Code " + sepReasonCodesWithNonNullValueCounter +" Date",
							fileField.getLength(), value.trim().replaceAll("-", "")).write(rs, writer, conn);
			}

		} catch (Exception e) {
			System.out.println(" VAPM360AppUtil : populateAttestationDates : Error : " + e.getMessage());
			throw e;
		}
	}
	
	private static void populateDefaultAttestationDates(int attestationCodesWithNonNullValueCounter,
			ResultSet rs, BufferedWriter writer, Connection conn) throws Exception {

		try {
			for(int index = attestationCodesWithNonNullValueCounter; index <= 5 ; index ++) {
				new NonAvailableFileField("SEP Reason Code " + index, 3).write(rs, writer, conn);
				new NonAvailableFileField("SEP Reason Code "+ index +" Date", 8).write(rs, writer, conn);
			}

		} catch (Exception e) {
			System.out.println(" VAPM360AppUtil : populateAttestationDates : Error : " + e.getMessage());
			throw e;
		}
	}
	
	//End: Added for IFOX-00390786 (Phase-II)

	
	
	private static void processPendingFiles(String customerId) {
		
		try {
			Properties propPath = new Properties();
			propPath.load(VAPM360AppUtil.class.getClassLoader().getResourceAsStream("saveLocation.properties"));

			String appUploadFilePrefix = propPath.getProperty("VAP.batchFile.Name");
			String appUpLoadFilesDir = propPath.getProperty("VAP.locationpath.EEM360batchfile");

			LOGGER.info(" JschSFTPUploader : processPendingFiles : appUploadFilePrefix [" + appUploadFilePrefix +
					"], appUpLoadFilesDir [" + appUpLoadFilesDir + "] ");

	        String[] paths = new java.io.File(appUpLoadFilesDir).list();
	        for(String path : paths)
	        {
	        	if(path.indexOf(".txt") != -1)
	        	{
		        	String fileName = path.substring(0, path.indexOf(".txt"));
		        	LOGGER.info(" JschSFTPUploader : processPendingFiles : I'm going to process file [" + fileName + ".txt]");
	
		        	if(null != path && path.indexOf(appUploadFilePrefix.trim()) != -1)
						JschSftpUploader.JschSFTPUploader(customerId, fileName);
	        	}
	        }

		} catch(IOException e) {
			LOGGER.error(" JschSFTPUploader : processPendingFiles : " + e.getMessage());
		}
	}
	
	
}
