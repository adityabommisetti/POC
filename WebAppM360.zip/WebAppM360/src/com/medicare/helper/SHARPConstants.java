package com.medicare.helper;

public class SHARPConstants {

	public static final String RELATIVEWEBPATHOFOPTIMAHEALTH_LOGO = "/images/SHARPLogo_50.jpg";
	public static final String RELATIVEWEBPATHOFMEDICARDLOGO = "/images/Medicardlogo.png";
	public static final String RELATIVEWEBPATHOFCHECKIMAGE = "/images/check.PNG";
	public static final String RELATIVEWEBPATHOFUNCHECKIMAGE = "/images/uncheck.PNG";
	public static final String RELATIVEWEBPATHOFBUTTONCHECKIMAGE = "/images/buttonCheck.PNG";
	public static final String RELATIVEWEBPATHOFBUTTONUNCHECKIMAGE = "/images/buttonUncheck.PNG";
	public static final String RELATIVEWEBPATHOFSTOPIMAGE = "/images/stop.jpg";
	public static final String RELATIVEWEBPATHOFARIALFONT = "/images/OpenSans-Regular.ttf";
	public static final String DateFormat = "MM/dd/yyyy";
	public static final String DBDateFormat = "yyyyMMdd";
	public static final String sharpAccountId = "HCF0331";
	public static final String SHARPPDFPREFIX = "SHP";

	public static final String resultSetQuery = "SELECT ud.CUSTOMER_ID as Customer_Id, ud.user_id as Application_Nbr,ud.IS_EEM360FLAG as EEM360FLAG ,"
			+ "ud.optima_plan as Enrolling_PBP,ud.optima_plan as Enrolling_Product_ID, ud.SUFFIX as Prefix,"
			+ "ud.LAST_NAME as Last_Name,ud.FIRST_NAME as First_Name,ud.MIDDLE_INITIAL as Middle_Initial,"
			+ "ud.MEDICARE_CLAIM_NUM as HIC_NBR, ud.HOME_PHNE_NUM as Primary_Home_Phone,ud.ALTR_PHNE_NUM as Primary_Work_Phone,"
			+ "ud.EMAIL_ADDR as Member_EMail,ud.BIRTH_DATE as Birth_Date, ud.SEX as Gender,ud.IS_AGREE as Signature_On_File_Indicator,"
			+ "ud.ACCPT_AGGR_DATE as Signature_Date,ud.ACCPT_AGGR_DATE as Application_Date, ud.CAMPAIGN_ID as Campaign_id,"
			+ "ud.CONTRACT_ID as Contract_id,ud.EMRG_CONTACT_NAME as Emergency_Name,ud.EMRG_PHNE_NUM as Emergency_Phone,"
			+ "ud.RELATIONSHIP as Emergency_Relationship_Code,ua.PERM_ADDRESS1 as Primary_Address1,"
			+ "ua.PERM_ADDRESS2 as Primary_Address2, ua.PERM_APARTMENT as Primary_Address3,ua.PERM_CITY as Primary_City,"
			+ "ua.PERM_STATE as Primary_State,ua.PERM_ZIP_CODE as Primary_Zip, ua.MAIL_ADDRESS1 as Mailing_Address1,"
			+ "ua.MAIL_ADDRESS2 as Mailing_Address2,ua.MAIL_APARTMENT as Mailing_Address3,ua.MAIL_CITY as Mailing_City, "
			+ "ua.MAIL_STATE as Mailing_State,ua.MAIL_ZIP_CODE as Mailing_Zip,uag.WEB_TEL_APP as Application_Category,"
			+ "uag.WEB_TEL_APP as Application_Category, uag.SENTARA_AGENT_ID as Field_Sales_Rep_ID,"
			
			+ "uag.SENTARA_AGENT_ID as Broker_Agent_ID, " //Added for IFOX-00390786 (Phase-II)
			
			+ "uag.EFF_DATE as Requested_Date_Of_Coverage,ul.REP_NAME as Authorized_First_Name, "
			+ "ul.REP_LAST_NAME as Authorized_Last_Name,ul.REP_MIDDLE_INITIAL as Authorized_Middle_Initial,"
			+ "ul.REP_ADDRESS as Authorized_Address1, ul.REP_ADDREESS_TWO as Authorized_Address2,"
			+ "ul.REP_ADDREESS_THREE as Authorized_Address3,ul.REP_CITY as Authorized_City, "
			+ "ul.REP_STATE as Authorized_State,ul.REP_ZIP_CODE as Authorized_Zip,"
			+ "ul.RELATIONSHIP_ENROLLE as Authorized_Relationship_Code, ul.REP_ADDRESS as Authorized_Address1,"
			+ "ul.REP_PHN_NUM as Authorized_Phone, uad.ACNT_NAME as Account_name, uad.BANK_ACCT_NUM as Bank_Account_Number,"
			+ "uad.BANK_RTING_NUM as Bank_Routing_Number, upd.COVERAGE_NAME as Sec_RX_Name, upd.COVERAGE_ID as Sec_RX_ID, "
			+ "upd.COVERAGE_GROUP as Sec_RX_Group "
			+ ", wupd.MEDICAID_IND as Medicaid_Indicator, wupd.MEDICAID_ID as Medicaid_ID " //Added for IFOX-00390114
			
			//Begin: Added for IFOX-00390786 (Phase-II)
			+ ", wupd.LTC_FAC_ID as LTC_Facility_ID "
			+ ", ud.IS_BRAILLE as spanishLang, ud.IS_LPRINT_FORMAT as largePrint "
			+ ", wupd.NAME_INSTITUTION as InstituionName, wupd.PHONE_NUMBER as phoneNumOfInstituion "
			+ ", wupd.ADDRESS_INSTITUTION as InstituionAddress, wupd.ADDRESS_INSTITUTION_STREET as InstituionAddressStreet "
			+ ", wupd.SPOUSE_WORK_IND as Spouse_Work_Indicator "
			//End: Added for IFOX-00390786 (Phase-II)
			
			+ ",uag.ELECTION_TYPE as Election_Type_Code, ud.HOSPITAL_DATE as Hospital_date, ud.MEDICAL_DATE as Medical_Date, ud.IS_RENAL_DISEASE as ESRD_Indicator " //Added for IFOX-00390786
			
			//Begin: Added for IFOX-00390786 (Phase-II)
			+ ", wupd.IS_ANUL_ELGB_ENROLL as NewToMedicareFlag, wupd.NEW_ELGB_DATE as ReleaseDateFromIncarceration "
			+ ", wupd.LEAVING_COVRG_DATE as LawfulPresenceStatusDate, wupd.RECENT_MOVED_DATE as PrescriptionDrugCoverageFlag "
			+ ", wupd.SPECIAL_PLAN_DATE as MovedOutOfLTCFacilityDate, wupd.BACK_US_DATE as DrugCoverageLostDate "
			+ ", wupd.IS_BELONG_STATE_PHARMCY as PharmacyAssistPrgramFlag, wupd.MOVED_OUT_FACILITY_DATE as DisEnrolledDatefromSNP "
			+ ", wupd.LOST_COVERAGE_DATE as OutsideOfTheServiceAreaDate, wupd.PAY_PRESCRIPTION_DATE as ReturnDtAfterLivingOutOfUS "
			+ ", wupd.NO_ELGB_DRUGS_DATE as StateHelpsPayMedicarePremiumDt, wupd.OUTSIDE_PLAN_DATE as StoppedDtForRecievingExtraHelp "
			+ ", wupd.LEFT_PACE_DATE as PACEProgramLeftDate, wupd.UNION_COV_DATE as LeavingEmpORUnionCovDt "
			+ ", wupd.IS_NONE_STATEMENTS as PlanEndDtWithMedicareContract "
			//End: Added for IFOX-00390786 (Phase-II)
			
			+ "FROM WB_USER_DETAILS ud INNER JOIN WB_USER_ADDRESS ua ON ud.user_id  = ua.user_id "
			+ "INNER JOIN WB_USER_AGENT_DETAILS uag ON ud.user_id  = uag.user_id "
			+ "INNER JOIN WB_USER_LEGAL_REP_DETAILS ul ON ud.user_id  = ul.user_id "
			+ "INNER JOIN WB_USER_ACCOUNT_DETAILS uad ON ud.user_id  = uad.user_id "
			+ "INNER JOIN WB_USER_OTHER_POLICY_DETAILS upd ON ud.user_id  = upd.user_id "
			+ "INNER JOIN WB_USER_POLICY_DETAILS wupd ON ud.user_id  = wupd.user_id " //Added for IFOX-00390114
			+ "where IS_EEM360FLAG!='Y' and ul.CUSTOMER_ID=ud.CUSTOMER_ID and ul.CUSTOMER_ID=ua.CUSTOMER_ID and  upd.COVERAGE_TYPE='MEDICAL' and "
			+ "ul.CUSTOMER_ID=uag.CUSTOMER_ID and  ud.CUSTOMER_ID=ua.CUSTOMER_ID and ud.CUSTOMER_ID=uag.CUSTOMER_ID AND "
			+ "ua.CUSTOMER_ID=uag.CUSTOMER_ID and ud.CUSTOMER_ID='HCF0331'";

	public static final int eem360BatchHeaderLength = 15;
	public static final int eem360BatchTrailerLength = 9;
	// public static final String queryForPrimaryCounty =
	// "select SSA_CNTY as Primary_County from EM_ZIPCODE emz where UPPER(city_name) =UPPER(?) and ZIP_CD5=? LIMIT 1";
	// mysql change

	public static final String queryForPrimaryCounty = "select SSA_CNTY as Primary_County from WB_EM_ZIPCODE emz where UPPER(city_name) =UPPER(?) and ZIP_CD5=? FETCH FIRST 1 ROWS ONLY";
	public static final String queryForPremiunOption = "select IS_AUTO_DEDUCT as autodetected,IS_ETF as eft,IS_MONTHLY_BILL as monthlybill "
			+ "from WB_USER_ACCOUNT_DETAILS where USER_ID=?";
	public static final String updateFLAGQuery = "UPDATE WB_USER_DETAILS SET IS_EEM360FLAG = 'Y' WHERE USER_ID = ?";
	public static final String SERCQuery = "select ELECTION_TYPE as electiontype from WB_USER_AGENT_DETAILS where USER_ID=? and CUSTOMER_ID='HCF0331'";
	
	
	//Begin: Modified for IFOX-00390786 (Phase-II)

	//public static final String forAgencyId = "select SENTARA_AGENT_ID as forAgencyId from WB_USER_AGENT_DETAILS where USER_ID=? and CUSTOMER_ID='HCF0331'";

	public static final String forAgencyId = " SELECT WUAD.SENTARA_AGENT_ID AS FORAGENCYID, QAD.AGENT_IN AS AGENCYID " +
			" FROM WB_USER_AGENT_DETAILS WUAD LEFT OUTER JOIN WB_AGENT_DETAILS AS QAD ON WUAD.CUSTOMER_ID = QAD.CUSTOMER_ID " +
			" AND WUAD.SENTARA_AGENT_ID = QAD.AGENT_ID WHERE WUAD.USER_ID = ? AND WUAD.CUSTOMER_ID = 'HCF0331' ";

	//Begin: Modified for IFOX-00390786 (Phase-II)
	
	public static final String forPCP = "select PRIMARY_PHYSICIAN as PCPData from WB_USER_DETAILS where USER_ID=? and CUSTOMER_ID='HCF0331'";
	
	/*public static final String[] placeHolderField = { "Record_Type",
			"Application_Category", "Application_Nbr", "Application_Date",
			"Prefix", "Last_Name", "First_Name", "Middle_Initial", "Suffix",
			"HIC_NBR", "SSN", "Past_Supplemental_ID", "New_Supplemental_ID",
			"RX_ID", "Primary_Home_Phone", "Primary_Work_Phone",
			"Primary_Cell_Phone", "Primary_Fax_Number", "Primary_Address1",
			"Primary_Address2", "Primary_Address3", "Primary_City",
			"Primary_State", "Primary_Zip", "Primary_County",
			"Primary_Country_Code", "Mailing_Last_Name", "Mailing_First_Name",
			"Mailing_Middle_Initial", "Mailing_Suffix", "Mailing_Address1",
			"Mailing_Address2", "Mailing_Address3", "Mailing_City",
			"Mailing_State", "Mailing_Zip", "Mailing_Country_Code",
			"Member_EMail", "Birth_Date", "Gender", "Current_Product",
			"Current_Contract", "Current_PBP", "Current_Segment",
			"Current_Payment_Amt", "Enrolling_Product_ID",
			"Enrolling_Contract", "Enrolling_PBP", "Enrolling_Segment",
			"Enrolling_Payment_Amt", "Requested_Date_Of_Coverage",
			"Correspondence_Language_Cd", "PCP_Code", "PCP_Location_ID",
			"Current_Patient_Indicator", "Future_Use", "Future_Use",
			"Future_Use", "Future_Use", "Future_Use", "Future_Use",
			"Premium_Withhold_Option", "ESRD_Indicator",
			"ESRD_Override_Indicator", "Dialysis_Indicator", "Sec_RX_Name",
			"Sec_RX_ID", "Sec_RX_Group", "Sec_RX_BIN", "Sec_RX_PCN",
			"LTC_Facility_ID", "Medicaid_Indicator", "Medicaid_ID",
			"Spouse_Work_Indicator", "Out_of_Area_Indicator",
			"Election_Type_Code", "Special_Election_Reason_Code",
			"Signature_On_File_Indicator", "Signature_Date",
			"Authorized_Last_Name", "Authorized_First_Name",
			"Authorized_Middle_Initial", "Authorized_Relationship_Code",
			"Authorized_Address1", "Authorized_Address2",
			"Authorized_Address3", "Authorized_City", "Authorized_State",
			"Authorized_Zip", "Authorized_Country_Code", "Authorized_Phone",
			"Emergency_Name", "Emergency_Phone", "Emergency_Relationship_Code",
			"Emergency_E_Mail", "Insurance_Card_Name", "Agency_ID",
			"Agency_ID_Secondary", "Broker_Agent_ID", "Field_Sales_Rep_ID",
			"Billing_Last_Name", "Billing_First_Name",
			"Billing_Middle_Initial", "Billing_Suffix", "Billing_Address1",
			"Billing_Address2", "Billing_Address3", "Billing_City",
			"Billing_State", "Billing_Zip", "Billing_Country_Code",
			"Receipt Date","Signature Date Override Ind","Subscriber ID","ID Card Supress Ind","Agent Signature Date","Campaign_id",
			"Contract_id","Alt_Corres_Ind", "FILLER" };

	public static final int[] placeHolderLenght = { 3, 3, 20, 8, 4, 35, 24, 1,
			4, 12, 9, 15, 15, 20, 25, 25, 25, 25, 50, 50, 50, 20, 2, 9, 3, 3,
			35, 24, 1, 4, 50, 50, 50, 20, 2, 9, 3, 50, 8, 1, 4, 5, 3, 3, 10, 4,
			5, 3, 3, 10, 8, 3, 12, 2, 1, 12, 1, 10, 12, 1, 10, 3, 1, 1, 1, 50,
			20, 20, 6, 10, 6, 1, 20, 1, 1, 1, 2, 1, 8, 35, 24, 1, 3, 50, 50,
			50, 20, 2, 9, 3, 25, 50, 25, 3, 50, 50, 15, 15, 20, 20, 35, 24, 1,
			4, 50, 50, 50, 20, 2, 9, 3, 8 , 1 , 10 , 1 , 8 , 25 , 25 , 1 , 111 };

	public static final String[] placeHolderAvailability = {

	"YP", "Y", "Y", "YD", "Y", "Y", "Y", "Y", "N", "Y", "N", "N", "N", "N",
			"Y", "Y", "N", "N", "Y", "Y", "Y", "Y", "Y", "Y", "Y", "N", "N",
			"N", "N", "N", "Y", "Y", "Y", "Y", "Y", "Y", "N", "Y", "YD", "Y",
			"N", "N", "N", "N", "N", "Y", "YP", "Y", "YP", "N", "YD", "YP",
			"YPremium", "YPremium", "N", "N", "N", "N", "N", "N", "N",
			"YPremium", "N", "N", "N", "N", "N", "N", "N", "N", "N", "N", "N",
			"N", "N", "N", "N", "Y", "YD", "Y", "Y", "Y", "Y", "Y", "Y", "Y",
			"Y", "Y", "Y", "N", "Y", "Y", "Y", "Y", "N", "N", "YPremium", "N",
			"N", "Y", "N", "N", "N", "N", "N", "N", "N", "N", "N", "N", "N",
			"N","N","N","N","N","Y","Y","N", "N" };*/

}
