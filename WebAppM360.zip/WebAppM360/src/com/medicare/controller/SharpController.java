package com.medicare.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.net.util.Base64;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.medicare.helper.JschSftpUploader;
import com.medicare.helper.SHARPConstants;
import com.medicare.security.CryptoDigest;
//import com.ibm.ws.webcontainer.webapp.WebApp;
//import com.medicare.mailer.SendMail;
import com.medicare.service.IUserDetailsService;
import com.medicare.util.EmailUtil;
import com.medicare.util.SharpPdfGen;
import com.medicare.util.SharpPdfGen2019;
import com.medicare.util.SharpPdfGen2020;
import com.medicare.util.StringUtil;
import com.medicare.util.WebAppUtil;
import com.medicare.vo.AgreeDetailsVO;
import com.medicare.vo.AttestationDetailsVO;
import com.medicare.vo.EnrollmentVO;
import com.medicare.vo.LoginVO;
import com.medicare.vo.PolicyDetailsVO;
import com.medicare.vo.UserDetailsVO;

@Controller
@RequestMapping("/Sharp")
public class SharpController {
	private final static Logger LOGGER = Logger.getLogger(SharpController.class.getName());

	private IUserDetailsService userDetailsService;
	LoginVO loginVO = new LoginVO();

	
	@Autowired
	public void setUserDetailsService(IUserDetailsService userDetailsService) {
		this.userDetailsService = userDetailsService;
	}
/*	@Autowired
	public void setSendMail(SendMail sendMail) {
		this.sendMail = sendMail;
	}

	private SendMail  sendMail;*/

	String customer_id = "HCF0331";
	
	
	@RequestMapping(value = "/Individual", method = RequestMethod.GET)
	public ModelAndView showPlanYear() {
		return new ModelAndView("Sharp/year");
	}
	
	@RequestMapping(value = "/sharpEnrollForm", method = RequestMethod.GET)
	public ModelAndView showEnrollForm1(HttpServletRequest request,
			@ModelAttribute("userDetailsVO") UserDetailsVO userDetailsVO) {
		
		ModelAndView modView;
		userDetailsVO.setCustomerId(customer_id);
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		userDetailsVO.setCustomerId(customer_id);
		mapModel.put("userDetailsVO", userDetailsVO);
		request.getSession().setAttribute("customerId", userDetailsVO.getCustomerId());
		modView = new ModelAndView("Sharp/individual/enrollment1_2017", mapModel);
		return modView;
	}

	@RequestMapping(value = "/group/changePlan", method = RequestMethod.GET)
	public ModelAndView showChangePlanForGroup(HttpServletRequest request,
			@ModelAttribute("userDetailsVO") UserDetailsVO userDetailsVO) {
		
		ModelAndView modView;
		userDetailsVO.setCustomerId(customer_id);
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		userDetailsVO.setCustomerId(customer_id);
		mapModel.put("userDetailsVO", userDetailsVO);
		request.getSession().setAttribute("customerId", userDetailsVO.getCustomerId());
		modView = new ModelAndView("Sharp/group/yearSelection", mapModel);
		return modView;
	}		
	
	
	@RequestMapping(value = "/Individual/yearSelection", method = RequestMethod.POST)
	public ModelAndView showYearSelection(HttpServletRequest request,
			@ModelAttribute("loginVO") LoginVO loginVO) {
		
		ModelAndView modView = null; ;
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		
		//Change for IFOX-00414491 - Start
		if(request.getSession().getAttribute("directLink")!=null)
			request.getSession().removeAttribute("directLink");
		//Change for IFOX-00414491 - End
		
		loginVO.setCustomerId(customer_id);
		//mapModel.put("loginVO", loginVO);
		
		mapModel.put("emailAddress", loginVO.getEmailAddress());
		mapModel.put("emailAddr", loginVO.getEmailAddress());
		
		LOGGER.info("Inside Individual Year Selection !!");
		
		
/*		String customerId = request.getParameter("customerId");
		String emailAddress = request.getParameter("emailAddress");
		String password = request.getParameter("password");
		String reconfirmPassword = request.getParameter("reconfirmPwd");*/
		
		String customerId = loginVO.getCustomerId();
		String emailAddress = loginVO.getEmailAddress();
		String password = loginVO.getPassword();
		String reconfirmPassword = loginVO.getReconfirmPwd();		
		
		LOGGER.info("Customer Id : "+loginVO.getCustomerId());
		LOGGER.info("Email Address : "+loginVO.getEmailAddress());
		LOGGER.info("Password : "+loginVO.getPassword());
		LOGGER.info("Reconfirm Password : "+loginVO.getReconfirmPwd());
		
		CryptoDigest crypt = new CryptoDigest();
		boolean emailIDExists = userDetailsService.getEmailID(customerId, emailAddress);
		try {
			String encryptedPassword = crypt.digest(loginVO.getEmailAddress(),StringUtil.nonNullTrim(loginVO.getPassword()));
		
			encryptedPassword = StringUtil.nonNullTrim(encryptedPassword);
			
			if(reconfirmPassword != null && reconfirmPassword.equals(password)) {
				if(!emailIDExists) {
					LOGGER.info("User does not exist - Registering now !!");
					userDetailsService.saveNewUser(loginVO);
					LOGGER.info("Email Address added to the repository !!");
				} else {
					LOGGER.info("User already exists !!");
					mapModel.put("errorMsg", "User Already Exists. Please register with new email account !!");
					return modView = new ModelAndView("Sharp/individual/userCreation",mapModel);			
				}
			} else if(reconfirmPassword == null) {
				String dbPassword = userDetailsService.getUserData(customerId,loginVO.getEmailAddress());
				LOGGER.info("Encrypted Password - " + encryptedPassword);
				if(emailIDExists && encryptedPassword.equals(dbPassword)) {
					userDetailsService.resetLoginAttempts(customerId,loginVO.getEmailAddress());
					modView = new ModelAndView("Sharp/individual/yearSelection");
				} else if(emailIDExists) {
					mapModel.put("errorMsg", "Password do not match. Please reenter a valid password !!");
					userDetailsService.incrementLoginAttempts(customerId,loginVO.getEmailAddress());
					LOGGER.info("Incorrect Password !!");
					return modView = new ModelAndView("Sharp/individual/userLogin",mapModel);
				} else {
					mapModel.put("errorMsg2", "User does not exists. Please register for new medicare account !!");
					LOGGER.info("User does not exists !!");
					return modView = new ModelAndView("Sharp/individual/userLogin",mapModel);
				}
			}
		
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Map populatedMap = null;
		Map physicanMapDB = null;
		Map agentNmaesMapDB = null;
	

		
		Map authorizedRelationshipsMapDB = WebAppUtil.getAuthroizedRelationShips();
		
		if(request.getSession().getServletContext().getAttribute("authorizedrelationshipsMap") == null){
			request.getSession().getServletContext().setAttribute("authorizedrelationshipsMap" , authorizedRelationshipsMapDB);
		}
		
		if(request.getSession().getServletContext().getAttribute("physicianMap") == null || request.getSession().getServletContext().getAttribute("agentNamesMap") == null ){
			populatedMap = userDetailsService.getPrePopulatedValuesFromDB(customer_id);
		}
		
		if(request.getSession().getServletContext().getAttribute("physicianMap") == null){
			
			physicanMapDB = (Map) populatedMap.get("physicianMap");
			request.getSession().getServletContext().setAttribute("physicianMap" , physicanMapDB);
		}

		if(request.getSession().getServletContext().getAttribute("agentNamesMap") == null){
			agentNmaesMapDB = (Map) populatedMap.get("agentNamesMap");
			request.getSession().getServletContext().setAttribute("agentNamesMap" , agentNmaesMapDB);
		}
		
		request.getSession().setAttribute("agentNames", request.getSession().getServletContext().getAttribute("agentNamesMap"));
		request.getSession().setAttribute("physicians", request.getSession().getServletContext().getAttribute("physicianMap"));
		request.getSession().setAttribute("authorizedrelations", authorizedRelationshipsMapDB);
		
		request.getSession().setAttribute("customerId", customerId);
		request.getSession().setAttribute("emailId", emailAddress);
		
/*		loginVO.setCustomerId(customerId);
		loginVO.setEmailAddress(emailAddress);
		loginVO.setPassword(password);	*/	
		
		modView = new ModelAndView("Sharp/individual/yearSelection", mapModel);
		return modView;
	}
	
	//Fix for IFOX-00412770-Start
	@RequestMapping(value = "/Individual/yearSelectionGuest", method = RequestMethod.POST)
	public ModelAndView showYearSelectionGuest(HttpServletRequest request,
			@ModelAttribute("loginVO") LoginVO loginVO) {
		
		ModelAndView modView = null;
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		
		//Change for IFOX-00414491 - Start
		if(request.getSession().getAttribute("directLink")!=null)
			request.getSession().removeAttribute("directLink");
		//Change for IFOX-00414491 - End
		
		loginVO.setCustomerId(customer_id);
		//mapModel.put("loginVO", loginVO);
		
		LOGGER.info("Inside Individual Year Selection !!");
		
		
/*		String customerId = request.getParameter("customerId");
		String emailAddress = request.getParameter("emailAddress");
		String password = request.getParameter("password");
		String reconfirmPassword = request.getParameter("reconfirmPwd");*/
		
		String customerId = loginVO.getCustomerId();
		String emailAddress = "Guest";
		String password = "";
		String reconfirmPassword = "";		
		
		LOGGER.info("Customer Id : "+loginVO.getCustomerId());
		LOGGER.info("Email Address : "+loginVO.getEmailAddress());
		LOGGER.info("Password : "+loginVO.getPassword());
		LOGGER.info("Reconfirm Password : "+loginVO.getReconfirmPwd());
				
		Map populatedMap = null;
		Map physicanMapDB = null;
		Map agentNmaesMapDB = null;
	

		
		Map authorizedRelationshipsMapDB = WebAppUtil.getAuthroizedRelationShips();
		
		if(request.getSession().getServletContext().getAttribute("authorizedrelationshipsMap") == null){
			request.getSession().getServletContext().setAttribute("authorizedrelationshipsMap" , authorizedRelationshipsMapDB);
		}
		
		if(request.getSession().getServletContext().getAttribute("physicianMap") == null || request.getSession().getServletContext().getAttribute("agentNamesMap") == null ){
			populatedMap = userDetailsService.getPrePopulatedValuesFromDB(customer_id);
		}
		
		if(request.getSession().getServletContext().getAttribute("physicianMap") == null){
			
			physicanMapDB = (Map) populatedMap.get("physicianMap");
			request.getSession().getServletContext().setAttribute("physicianMap" , physicanMapDB);
		}

		if(request.getSession().getServletContext().getAttribute("agentNamesMap") == null){
			agentNmaesMapDB = (Map) populatedMap.get("agentNamesMap");
			request.getSession().getServletContext().setAttribute("agentNamesMap" , agentNmaesMapDB);
		}
		
		request.getSession().setAttribute("agentNames", request.getSession().getServletContext().getAttribute("agentNamesMap"));
		request.getSession().setAttribute("physicians", request.getSession().getServletContext().getAttribute("physicianMap"));
		request.getSession().setAttribute("authorizedrelations", authorizedRelationshipsMapDB);
		
		request.getSession().setAttribute("customerId", customerId);
		request.getSession().setAttribute("emailId", emailAddress);
		
/*		loginVO.setCustomerId(customerId);
		loginVO.setEmailAddress(emailAddress);
		loginVO.setPassword(password);	*/	
		
		modView = new ModelAndView("Sharp/individual/yearSelection", mapModel);
		return modView;
	}
	
	@RequestMapping(value = "/Individual/yearSelectionGuestMobile", method = RequestMethod.POST)
	public ModelAndView showYearSelectionGuestMobile(HttpServletRequest request,
			@ModelAttribute("loginVO") LoginVO loginVO) {
		
		ModelAndView modView = null;
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		
		//Change for IFOX-00414491 - Start
		if(request.getSession().getAttribute("directLink")!=null)
			request.getSession().removeAttribute("directLink");
		//Change for IFOX-00414491 - End
		
		loginVO.setCustomerId(customer_id);
		//mapModel.put("loginVO", loginVO);
		
		LOGGER.info("Inside Individual Year Selection !!");
		
		
/*		String customerId = request.getParameter("customerId");
		String emailAddress = request.getParameter("emailAddress");
		String password = request.getParameter("password");
		String reconfirmPassword = request.getParameter("reconfirmPwd");*/
		
		String customerId = loginVO.getCustomerId();
		String emailAddress = "Guest";
		String password = "";
		String reconfirmPassword = "";		
		
		LOGGER.info("Customer Id : "+loginVO.getCustomerId());
		LOGGER.info("Email Address : "+loginVO.getEmailAddress());
		LOGGER.info("Password : "+loginVO.getPassword());
		LOGGER.info("Reconfirm Password : "+loginVO.getReconfirmPwd());
				
		Map populatedMap = null;
		Map physicanMapDB = null;
		Map agentNmaesMapDB = null;
	

		
		Map authorizedRelationshipsMapDB = WebAppUtil.getAuthroizedRelationShips();
		
		if(request.getSession().getServletContext().getAttribute("authorizedrelationshipsMap") == null){
			request.getSession().getServletContext().setAttribute("authorizedrelationshipsMap" , authorizedRelationshipsMapDB);
		}
		
		if(request.getSession().getServletContext().getAttribute("physicianMap") == null || request.getSession().getServletContext().getAttribute("agentNamesMap") == null ){
			populatedMap = userDetailsService.getPrePopulatedValuesFromDB(customer_id);
		}
		
		if(request.getSession().getServletContext().getAttribute("physicianMap") == null){
			
			physicanMapDB = (Map) populatedMap.get("physicianMap");
			request.getSession().getServletContext().setAttribute("physicianMap" , physicanMapDB);
		}

		if(request.getSession().getServletContext().getAttribute("agentNamesMap") == null){
			agentNmaesMapDB = (Map) populatedMap.get("agentNamesMap");
			request.getSession().getServletContext().setAttribute("agentNamesMap" , agentNmaesMapDB);
		}
		
		request.getSession().setAttribute("agentNames", request.getSession().getServletContext().getAttribute("agentNamesMap"));
		request.getSession().setAttribute("physicians", request.getSession().getServletContext().getAttribute("physicianMap"));
		request.getSession().setAttribute("authorizedrelations", authorizedRelationshipsMapDB);
		
		request.getSession().setAttribute("customerId", customerId);
		request.getSession().setAttribute("emailId", emailAddress);
		
/*		loginVO.setCustomerId(customerId);
		loginVO.setEmailAddress(emailAddress);
		loginVO.setPassword(password);	*/	
		
		modView = new ModelAndView("Sharp/individual/yearSelectionMobile", mapModel);
		return modView;
	}
	//Fix for IFOX-00412770-End
	
	@RequestMapping(value = "/Individual/yearSelectionMobile", method = RequestMethod.POST)
	public ModelAndView showYearSelectionMobile(HttpServletRequest request,
			@ModelAttribute("loginVO") LoginVO loginVO) {
		
		ModelAndView modView = null; ;
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		
		//Change for IFOX-00414491 - Start
		if(request.getSession().getAttribute("directLink")!=null)
			request.getSession().removeAttribute("directLink");
		//Change for IFOX-00414491 - End
		
		loginVO.setCustomerId(customer_id);
		//mapModel.put("loginVO", loginVO);
		
		mapModel.put("emailAddress", loginVO.getEmailAddress());
		mapModel.put("emailAddr", loginVO.getEmailAddress());
		
		LOGGER.info("Inside Individual Year Selection !!");
		
		
/*		String customerId = request.getParameter("customerId");
		String emailAddress = request.getParameter("emailAddress");
		String password = request.getParameter("password");
		String reconfirmPassword = request.getParameter("reconfirmPwd");*/
		
		String customerId = loginVO.getCustomerId();
		String emailAddress = loginVO.getEmailAddress();
		String password = loginVO.getPassword();
		String reconfirmPassword = loginVO.getReconfirmPwd();		
		
		LOGGER.info("Customer Id : "+loginVO.getCustomerId());
		LOGGER.info("Email Address : "+loginVO.getEmailAddress());
		LOGGER.info("Password : "+loginVO.getPassword());
		LOGGER.info("Reconfirm Password : "+loginVO.getReconfirmPwd());
		
		CryptoDigest crypt = new CryptoDigest();
		boolean emailIDExists = userDetailsService.getEmailID(customerId, emailAddress);
		try {
			String encryptedPassword = crypt.digest(loginVO.getEmailAddress(),StringUtil.nonNullTrim(loginVO.getPassword()));
			String dbPassword = userDetailsService.getUserData(customerId,loginVO.getEmailAddress());
		
			encryptedPassword = StringUtil.nonNullTrim(encryptedPassword);
			
			if(reconfirmPassword != null && reconfirmPassword.equals(password)) {
				if(!emailIDExists) {
					LOGGER.info("User does not exist - Registering now !!");
					userDetailsService.saveNewUser(loginVO);
					LOGGER.info("Email Address added to the repository !!");
				} else {
					LOGGER.info("User already exists !!");
					mapModel.put("errorMsg", "User Already Exists. Please register with new email account !!");
					return modView = new ModelAndView("Sharp/individual/userCreation",mapModel);			
				}
			} else if(reconfirmPassword == null) {
				LOGGER.info("Encrypted Password - " + encryptedPassword);
				if(emailIDExists && encryptedPassword.equals(dbPassword)) {
					userDetailsService.resetLoginAttempts(customerId,loginVO.getEmailAddress());
					modView = new ModelAndView("Sharp/individual/yearSelection");
				} else if(emailIDExists) {
					mapModel.put("errorMsg", "Password do not match. Please reenter a valid password !!");
					userDetailsService.incrementLoginAttempts(customerId,loginVO.getEmailAddress());
					LOGGER.info("Incorrect Password !!");
					return modView = new ModelAndView("Sharp/individual/userLogin",mapModel);
				} else {
					mapModel.put("errorMsg2", "User does not exists. Please register for new medicare account !!");
					LOGGER.info("User does not exists !!");
					return modView = new ModelAndView("Sharp/individual/userLogin",mapModel);
				}
			}
		
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		
		
		Map populatedMap = null;
		Map physicanMapDB = null;
		Map agentNmaesMapDB = null;
	

		
		Map authorizedRelationshipsMapDB = WebAppUtil.getAuthroizedRelationShips();
		
		if(request.getSession().getServletContext().getAttribute("authorizedrelationshipsMap") == null){
			request.getSession().getServletContext().setAttribute("authorizedrelationshipsMap" , authorizedRelationshipsMapDB);
		}
		
		if(request.getSession().getServletContext().getAttribute("physicianMap") == null || request.getSession().getServletContext().getAttribute("agentNamesMap") == null ){
			populatedMap = userDetailsService.getPrePopulatedValuesFromDB(customer_id);
		}
		
		if(request.getSession().getServletContext().getAttribute("physicianMap") == null){
			
			physicanMapDB = (Map) populatedMap.get("physicianMap");
			request.getSession().getServletContext().setAttribute("physicianMap" , physicanMapDB);
		}

		if(request.getSession().getServletContext().getAttribute("agentNamesMap") == null){
			agentNmaesMapDB = (Map) populatedMap.get("agentNamesMap");
			request.getSession().getServletContext().setAttribute("agentNamesMap" , agentNmaesMapDB);
		}
		
		request.getSession().setAttribute("agentNames", request.getSession().getServletContext().getAttribute("agentNamesMap"));
		request.getSession().setAttribute("physicians", request.getSession().getServletContext().getAttribute("physicianMap"));
		request.getSession().setAttribute("authorizedrelations", authorizedRelationshipsMapDB);
		
		request.getSession().setAttribute("customerId", customerId);
		request.getSession().setAttribute("emailId", emailAddress);
		
/*		loginVO.setCustomerId(customerId);
		loginVO.setEmailAddress(emailAddress);
		loginVO.setPassword(password);	*/	
		
		modView = new ModelAndView("Sharp/individual/yearSelectionMobile", mapModel);
		return modView;
	}	


	/*	
	@RequestMapping(value = "/Individual/enrollOnline", method = RequestMethod.POST)
	public ModelAndView showEnrollForm(HttpServletRequest request,
			@ModelAttribute("userDetailsVO") UserDetailsVO userDetailsVO) {
		
		ModelAndView modView ;
		userDetailsVO.setCustomerId(customer_id);
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		userDetailsVO.setCustomerId(customer_id);
		mapModel.put("userDetailsVO", userDetailsVO);
		request.getSession().setAttribute("customerId", userDetailsVO.getCustomerId());
		String planId = request.getParameter("Plan");
		request.getSession().setAttribute("planName", planId);
		if(planId != null && "SDAGC".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAGC***");
			modView = new ModelAndView("Sharp/individual/enrollmentFormSDAGC", mapModel);
		}else if(planId != null && "SDAPC".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAPC***");
			modView = new ModelAndView("Sharp/individual/enrollmentFormSDAPC", mapModel);
		}else if(planId != null && "SDAB".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAB***");
			//modView = new ModelAndView("Sharp/individual/enrollmentFormSDAB", mapModel);
			modView = new ModelAndView("Sharp/group/enrollmentFormSDAB", mapModel);
		}else if(planId != null && "SDAP".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAP***");
			//modView = new ModelAndView("Sharp/individual/enrollmentFormSDAP", mapModel);
			modView = new ModelAndView("Sharp/group/enrollmentFormSDAP", mapModel);
		}else if(planId != null && "SDAMEA".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAMEA***");
			//modView = new ModelAndView("Sharp/individual/enrollmentFormSDAMEA", mapModel);
			modView = new ModelAndView("Sharp/mea/enrollmentFormSDAMEA", mapModel);
		}else if(planId != null && "SAS".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SAS***");
			modView = new ModelAndView("Sharp/individual/enrollmentFormSAS", mapModel);
		}else if(planId != null && "SASP".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SASP***");
			modView = new ModelAndView("Sharp/individual/enrollmentFormSASP", mapModel);
		}else if(planId != null && "SAB".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SAB***");
			//modView = new ModelAndView("Sharp/individual/enrollmentFormSAB", mapModel);
			modView = new ModelAndView("Sharp/group/enrollmentFormSAB", mapModel);
		}else if(planId != null && "SAP".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SAP***");
			//modView = new ModelAndView("Sharp/individual/enrollmentFormSAP", mapModel);
			modView = new ModelAndView("Sharp/group/enrollmentFormSAP", mapModel);
		}else if(planId != null && "SAMEA".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SAMEA***");
			//modView = new ModelAndView("Sharp/individual/enrollmentFormSAMEA", mapModel);
			modView = new ModelAndView("Sharp/mea/enrollmentFormSAMEA", mapModel);
		}else{
			modView = new ModelAndView("Sharp/individual/planSelection", mapModel);
		}
		
		//modView = new ModelAndView("Sharp/individual/enrollmentForm", mapModel);
		
		return modView;
	}

*/		

	//Begin: Modified for IFOX-00414491
	@RequestMapping(value = "/Individual/selectedPlansEmployer", method = RequestMethod.GET)
	public ModelAndView showPlanSelectDirectlyForSDPEBAUsers(HttpServletRequest request,
			@ModelAttribute("userDetailsVO") UserDetailsVO userDetailsVO) {
		//Fix for IFOX-00417962 - Start
		Map populatedMap = null;
		Map physicanMapDB = null;
		Map agentNamesMapDB = null;
		//Fix for IFOX-00417962 - End
		
		userDetailsVO.setCustomerId("HCF0331");
		userDetailsVO.setEmailAddr("Guest");
		request.getSession().setAttribute("emailId","Guest");
		request.getSession().setAttribute("planYear", "2020");
		request.getSession().setAttribute("directLink","true");
		
		//Fix for IFOX-00417962 - Start
		Map authorizedRelationshipsMapDB = WebAppUtil.getAuthroizedRelationShips();
		
		if(request.getSession().getServletContext().getAttribute("authorizedrelationshipsMap") == null){
			request.getSession().getServletContext().setAttribute("authorizedrelationshipsMap" , authorizedRelationshipsMapDB);
		} 
		
		if(request.getSession().getServletContext().getAttribute("physicianMap") == null || request.getSession().getServletContext().getAttribute("agentNamesMap") == null ){
			populatedMap = userDetailsService.getPrePopulatedValuesFromDB(customer_id);
		}
		
		if(request.getSession().getServletContext().getAttribute("agentNamesMap") == null){
			agentNamesMapDB = (Map) populatedMap.get("agentNamesMap");
			request.getSession().getServletContext().setAttribute("agentNamesMap" , agentNamesMapDB);
		}
		if(request.getSession().getServletContext().getAttribute("physicianMap") == null){
			
			physicanMapDB = (Map) populatedMap.get("physicianMap");
			request.getSession().getServletContext().setAttribute("physicianMap" , physicanMapDB);
		}
		request.getSession().setAttribute("physicians", request.getSession().getServletContext().getAttribute("physicianMap"));
		request.getSession().setAttribute("authorizedrelations", authorizedRelationshipsMapDB);
		request.getSession().setAttribute("agentNames", request.getSession().getServletContext().getAttribute("agentNamesMap"));
		//Fix for IFOX-00417962 - End
		return this.showPlanSelection(request, userDetailsVO);
	}
	
	@RequestMapping(value = "/Individual/selectedPlansEmployerMobile", method = RequestMethod.POST)
	public ModelAndView showPlanSelectDirectlyForSDPEBAMobileUsers(HttpServletRequest request,
			@ModelAttribute("userDetailsVO") UserDetailsVO userDetailsVO) {
		userDetailsVO.setCustomerId("HCF0331");
		userDetailsVO.setEmailAddr("Guest");
		request.getSession().setAttribute("emailId","Guest");
		request.getSession().setAttribute("planYear", "2020");
		request.getSession().setAttribute("directLink","true");
		return this.showPlanSelectionMobile(request, userDetailsVO);
	}
	//End: Modified for IFOX-00414491
	
	@RequestMapping(value = "/Individual/enrollOnline", method = RequestMethod.POST)
	public ModelAndView showEnrollForm(HttpServletRequest request,
			@ModelAttribute("userDetailsVO") UserDetailsVO userDetailsVO) {
		
		ModelAndView modView ;
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		//mapModel.put("userDetailsVO", userDetailsVO);
		request.getSession().setAttribute("customerId", userDetailsVO.getCustomerId());
		String planId = request.getParameter("Plan");
		request.getSession().setAttribute("planName", planId);
		String emailId = (String) request.getSession().getAttribute("emailId");
		EnrollmentVO sessionEnrollmentVO = null;
		
		//Begin: 2019 web app changes - IFOX-00406768
		String planYear = nonNullTrim((String) request.getSession().getAttribute("planYear"));
		LOGGER.info(" SharpController : showEnrollForm : PlanYear [" + planYear + "] ");
		//End: 2019 web app changes - IFOX-00406768
		
		if(planId != null && "SDAGC".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAGC***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAGC Current Session***");
				WebAppUtil.mapVOTOSessionSDAGC(sessionEnrollmentVO, mapModel);

				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/individual/eFormExistingSDAGC",mapModel);	
				modView = new ModelAndView(Integer.parseInt(planYear) > 2018 ? "Sharp/individual/" + planYear + "/eFormExistingSDAGC" :
					"Sharp/individual/eFormExistingSDAGC", mapModel);
				//End: 2019 web app changes - IFOX-00406768

				//modView.addAllObjects(mapModel);
			}else{
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/individual/enrollmentFormSDAGC", mapModel);
				modView = new ModelAndView(Integer.parseInt(planYear) > 2018 ? "Sharp/individual/" + planYear + "/enrollmentFormSDAGC" :
					"Sharp/individual/enrollmentFormSDAGC", mapModel);
				//End: 2019 web app changes - IFOX-00406768
			}
		}else if(planId != null && "SDAGCWD".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAGCWD***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAGCWD Current Session***");
				WebAppUtil.mapVOTOSessionSDAGC(sessionEnrollmentVO, mapModel);
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/individual/eFormExistingSDAGCWD",mapModel);
				modView = new ModelAndView(Integer.parseInt(planYear) > 2018 ?  "Sharp/individual/" + planYear + "/eFormExistingSDAGCWD" :
						"Sharp/individual/eFormExistingSDAGCWD",mapModel);				
				//End: 2019 web app changes - IFOX-00406768
				
				//modView.addAllObjects(mapModel);
			}else{			
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/individual/enrollmentFormSDAGCWD", mapModel);

				modView = new ModelAndView(Integer.parseInt(planYear) > 2018 ? "Sharp/individual/" + planYear + "/enrollmentFormSDAGCWD" :
						"Sharp/individual/enrollmentFormSDAGCWD", mapModel);
				//End: 2019 web app changes - IFOX-00406768
			}
		}else if(planId != null && "SDAPC".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAPC***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAPC Current Session***");
				WebAppUtil.mapVOTOSessionSDAPC(sessionEnrollmentVO, mapModel);
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/individual/eFormExistingSDAPC",mapModel);				
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/individual/" + planYear + "/eFormExistingSDAPC" : 
						"Sharp/individual/eFormExistingSDAPC",mapModel);
				//End: 2019 web app changes - IFOX-00406768
				
				//modView.addAllObjects(mapModel);
			}else{			
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/individual/enrollmentFormSDAPC", mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/individual/" + planYear + "/enrollmentFormSDAPC" :
						"Sharp/individual/enrollmentFormSDAPC", mapModel);
				//End: 2019 web app changes - IFOX-00406768
			}
		}
		/*IFOX-00418144 2020 AEP Plan Changes. START*/
		else if(planId != null && "SDAGC20".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAGC20***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAGC20 Current Session***");
				WebAppUtil.mapVOTOSessionSDAGC(sessionEnrollmentVO, mapModel);

				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/individual/eFormExistingSDAGC",mapModel);	
				modView = new ModelAndView(Integer.parseInt(planYear) > 2018 ? "Sharp/individual/" + planYear + "/eFormExistingSDAGC20" :
					"Sharp/individual/eFormExistingSDAGC", mapModel);
				//End: 2019 web app changes - IFOX-00406768

				//modView.addAllObjects(mapModel);
			}else{
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/individual/enrollmentFormSDAGC", mapModel);
				modView = new ModelAndView(Integer.parseInt(planYear) > 2018 ? "Sharp/individual/" + planYear + "/enrollmentFormSDAGC20" :
					"Sharp/individual/enrollmentFormSDAGC", mapModel);
				//End: 2019 web app changes - IFOX-00406768
			}
		}else if(planId != null && "SDAGCWD20".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAGCWD20***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAGCWD20 Current Session***");
				WebAppUtil.mapVOTOSessionSDAGC(sessionEnrollmentVO, mapModel);
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/individual/eFormExistingSDAGCWD",mapModel);
				modView = new ModelAndView(Integer.parseInt(planYear) > 2018 ?  "Sharp/individual/" + planYear + "/eFormExistingSDAGCWD20" :
						"Sharp/individual/eFormExistingSDAGCWD",mapModel);				
				//End: 2019 web app changes - IFOX-00406768
				
				//modView.addAllObjects(mapModel);
			}else{			
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/individual/enrollmentFormSDAGCWD", mapModel);

				modView = new ModelAndView(Integer.parseInt(planYear) > 2018 ? "Sharp/individual/" + planYear + "/enrollmentFormSDAGCWD20" :
						"Sharp/individual/enrollmentFormSDAGCWD", mapModel);
				//End: 2019 web app changes - IFOX-00406768
			}
		}else if(planId != null && "SDAPC20".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAPC20***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAPC20 Current Session***");
				WebAppUtil.mapVOTOSessionSDAPC(sessionEnrollmentVO, mapModel);
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/individual/eFormExistingSDAPC",mapModel);				
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/individual/" + planYear + "/eFormExistingSDAPC20" : 
						"Sharp/individual/eFormExistingSDAPC",mapModel);
				//End: 2019 web app changes - IFOX-00406768
				
				//modView.addAllObjects(mapModel);
			}else{			
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/individual/enrollmentFormSDAPC", mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/individual/" + planYear + "/enrollmentFormSDAPC20" :
						"Sharp/individual/enrollmentFormSDAPC", mapModel);
				//End: 2019 web app changes - IFOX-00406768
			}
		}/*IFOX-00418144 2020 AEP Plan Changes. END*/
		else if(planId != null && "SDAB".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAB***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAB Current Session***");
				WebAppUtil.mapVOTOSessionSDAB(sessionEnrollmentVO, mapModel);
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/eFormExistingSDAB",mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/eFormExistingSDAB" :
						"Sharp/group/eFormExistingSDAB",mapModel);				
				//End: 2019 web app changes - IFOX-00406768
				
				//modView.addAllObjects(mapModel);
			}else{
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/enrollmentFormSDAB", mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/enrollmentFormSDAB" : 
						"Sharp/group/enrollmentFormSDAB", mapModel);
				//End: 2019 web app changes - IFOX-00406768
				
			}
		}else if(planId != null && "SDABWD".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDABWD***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDABWD Current Session***");
				WebAppUtil.mapVOTOSessionSDAB(sessionEnrollmentVO, mapModel);
				// TO DO
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/eFormExistingSDABWD",mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/eFormExistingSDABWD" : 
						"Sharp/group/eFormExistingSDABWD",mapModel);
				//End: 2019 web app changes - IFOX-00406768
				
				//modView = new ModelAndView("Sharp/group/enrollmentFormSDABWD",mapModel);				
				//modView.addAllObjects(mapModel);
			}else{
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/enrollmentFormSDABWD", mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/enrollmentFormSDABWD" : 
						"Sharp/group/enrollmentFormSDABWD", mapModel);
				//End: 2019 web app changes - IFOX-00406768
			}
		}else if(planId != null && "SDAP".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAP***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAP Current Session***");
				WebAppUtil.mapVOTOSessionSDAP(sessionEnrollmentVO, mapModel);
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/eFormExistingSDAP",mapModel);				
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/eFormExistingSDAP" :
						"Sharp/group/eFormExistingSDAP",mapModel);
				//End: 2019 web app changes - IFOX-00406768
				
				//modView.addAllObjects(mapModel);
			}else{
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/enrollmentFormSDAP", mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/enrollmentFormSDAP" :
						"Sharp/group/enrollmentFormSDAP", mapModel);
				//End: 2019 web app changes - IFOX-00406768
			}
						
			
		}else if(planId != null && "SDAPWD".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAPWD***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAPWD Current Session***");
				WebAppUtil.mapVOTOSessionSDAP(sessionEnrollmentVO, mapModel);
				// TO DO 
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/eFormExistingSDAPWD",mapModel);				
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/eFormExistingSDAPWD" :
						"Sharp/group/eFormExistingSDAPWD",mapModel);
				//End: 2019 web app changes - IFOX-00406768
				
				//modView = new ModelAndView("Sharp/group/eFormExistingSDAP",mapModel);
				//modView.addAllObjects(mapModel);
			}else{
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/enrollmentFormSDAPWD", mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/enrollmentFormSDAPWD" :
						"Sharp/group/enrollmentFormSDAPWD", mapModel);
				//End: 2019 web app changes - IFOX-00406768
			}
						
			
		}else if(planId != null && "SDAB20".equalsIgnoreCase(planId) ){//IFOX-00419089 2020 AEP Plan Changes. START
			LOGGER.info("***Inside SDAB20***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAB20 Current Session***");
				WebAppUtil.mapVOTOSessionSDAB20(sessionEnrollmentVO, mapModel);
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/eFormExistingSDAB",mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/eFormExistingSDAB20" :
						"Sharp/group/eFormExistingSDAB",mapModel);				
				//End: 2019 web app changes - IFOX-00406768
				
				//modView.addAllObjects(mapModel);
			}else{
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/enrollmentFormSDAB", mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/enrollmentFormSDAB20" : 
						"Sharp/group/enrollmentFormSDAB", mapModel);
				//End: 2019 web app changes - IFOX-00406768
				
			}
		}else if(planId != null && "SDABWD20".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDABWD20***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDABWD20 Current Session***");
				WebAppUtil.mapVOTOSessionSDAB20(sessionEnrollmentVO, mapModel);
				// TO DO
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/eFormExistingSDABWD",mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/eFormExistingSDABWD20" : 
						"Sharp/group/eFormExistingSDABWD",mapModel);
				//End: 2019 web app changes - IFOX-00406768
				
				//modView = new ModelAndView("Sharp/group/enrollmentFormSDABWD",mapModel);				
				//modView.addAllObjects(mapModel);
			}else{
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/enrollmentFormSDABWD", mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/enrollmentFormSDABWD20" : 
						"Sharp/group/enrollmentFormSDABWD", mapModel);
				//End: 2019 web app changes - IFOX-00406768
			}
		}else if(planId != null && "SDAP20".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAP20***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAP20 Current Session***");
				WebAppUtil.mapVOTOSessionSDAB20(sessionEnrollmentVO, mapModel);
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/eFormExistingSDAP",mapModel);				
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/eFormExistingSDAP20" :
						"Sharp/group/eFormExistingSDAP",mapModel);
				//End: 2019 web app changes - IFOX-00406768
				
				//modView.addAllObjects(mapModel);
			}else{
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/enrollmentFormSDAP", mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/enrollmentFormSDAP20" :
						"Sharp/group/enrollmentFormSDAP", mapModel);
				//End: 2019 web app changes - IFOX-00406768
			}
						
			
		}else if(planId != null && "SDAPWD20".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAPWD20***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAPWD20 Current Session***");
				WebAppUtil.mapVOTOSessionSDAB20(sessionEnrollmentVO, mapModel);
				// TO DO 
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/eFormExistingSDAPWD",mapModel);				
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/eFormExistingSDAPWD20" :
						"Sharp/group/eFormExistingSDAPWD",mapModel);
				//End: 2019 web app changes - IFOX-00406768
				
				//modView = new ModelAndView("Sharp/group/eFormExistingSDAP",mapModel);
				//modView.addAllObjects(mapModel);
			}else{
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/enrollmentFormSDAPWD", mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/enrollmentFormSDAPWD20" :
						"Sharp/group/enrollmentFormSDAPWD", mapModel);
				//End: 2019 web app changes - IFOX-00406768
			}
						
			
		}
		//IFOX-00419089 2020 AEP Plan Changes. END
		else if(planId != null && "SDAMEA".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAMEA***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAMEA Current Session***");
				WebAppUtil.mapVOTOSessionSDAMEA(sessionEnrollmentVO, mapModel);
				modView = new ModelAndView("Sharp/mea/eFormExistingSDAMEA",mapModel);				
				//modView.addAllObjects(mapModel);
			}else{
				modView = new ModelAndView("Sharp/mea/enrollmentFormSDAMEA", mapModel);
			}
			
		}/**IFOX-00403984 Changes Start.*/
		else if(planId != null && "SDAHMO".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAHMO***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAHMO Current Session***");
				WebAppUtil.mapVOTOSessionSDAHMO(sessionEnrollmentVO, mapModel);
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/mea/eFormExistingSDAHMO",mapModel);				
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/mea/" + planYear + "/eFormExistingSDAHMO" :
						"Sharp/mea/eFormExistingSDAHMO",mapModel);
				//End: 2019 web app changes - IFOX-00406768
				
			}else{
				//modView = new ModelAndView("Sharp/mea/eFormExistingSDAHMO",mapModel);
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/mea/enrollmentFormSDAHMO", mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/mea/" + planYear + "/enrollmentFormSDAHMO" :
						"Sharp/mea/enrollmentFormSDAHMO", mapModel);
				//End: 2019 web app changes - IFOX-00406768
			}
			
		}/**IFOX-00403984 Changes Stop.*/
		
		
		//Begin: Modified for IFOX-00414491
		else if(planId != null && "SDAHMO1".equalsIgnoreCase(planId) )
		{
			LOGGER.info("***Inside SDAHMO1***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null)
			{
				LOGGER.info("***Getting SDAHMO1 Current Session***");
				WebAppUtil.mapVOTOSessionSDAHMO1(sessionEnrollmentVO, mapModel);
		
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/mea/" + planYear + "/eFormExistingSDAHMO1" :
						"Sharp/mea/eFormExistingSDAHMO1",mapModel);
			} else{
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/mea/" + planYear + "/enrollmentFormSDAHMO1" :
						"Sharp/mea/enrollmentFormSDAHMO1", mapModel);
			}
		}
		//End: Modified for IFOX-00414491
		
		else if(planId != null && "SAS".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SAS***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SAS Current Session***");
				WebAppUtil.mapVOTOSessionSAS(sessionEnrollmentVO, mapModel);
				modView = new ModelAndView("Sharp/individual/eFormExistingSAS",mapModel);				
				//modView.addAllObjects(mapModel);
			}else{
				modView = new ModelAndView("Sharp/individual/enrollmentFormSAS", mapModel);
			}
			
			
		}else if(planId != null && "SASP".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SASP***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SASP Current Session***");
				WebAppUtil.mapVOTOSessionSASP(sessionEnrollmentVO, mapModel);
				modView = new ModelAndView("Sharp/individual/eFormExistingSASP",mapModel);				
				//modView.addAllObjects(mapModel);
			}else{
				modView = new ModelAndView("Sharp/individual/enrollmentFormSASP", mapModel);
			}
			
		}else if(planId != null && "SAB".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SAB***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SAB Current Session***");
				WebAppUtil.mapVOTOSessionSAB(sessionEnrollmentVO, mapModel);
				modView = new ModelAndView("Sharp/group/eFormExistingSAB",mapModel);				
				//modView.addAllObjects(mapModel);
			}else{
				modView = new ModelAndView("Sharp/group/enrollmentFormSAB", mapModel);
			}
			
		}else if(planId != null && "SAP".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SAP***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SAP Current Session***");
				WebAppUtil.mapVOTOSessionSAP(sessionEnrollmentVO, mapModel);
				modView = new ModelAndView("Sharp/group/eFormExistingSAP",mapModel);				
				//modView.addAllObjects(mapModel);
			}else{
				modView = new ModelAndView("Sharp/group/enrollmentFormSAP", mapModel);
			}
			
		}else if(planId != null && "SAMEA".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SAMEA***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SAMEA Current Session***");
				WebAppUtil.mapVOTOSessionSAMEA(sessionEnrollmentVO, mapModel);
				modView = new ModelAndView("Sharp/mea/eFormExistingSAMEA",mapModel);				
				//modView.addAllObjects(mapModel);
			}else{
				modView = new ModelAndView("Sharp/mea/enrollmentFormSAMEA", mapModel);
			}			
			
		}else{
			modView = new ModelAndView("Sharp/individual/planSelection", mapModel);
		}
		
		return modView;
	}
	
	@RequestMapping(value = "/Individual/enrollOnlineMobile", method = RequestMethod.POST)
	public ModelAndView showEnrollFormMobile(HttpServletRequest request,
			@ModelAttribute("userDetailsVO") UserDetailsVO userDetailsVO) {
		
		ModelAndView modView ;
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		//mapModel.put("userDetailsVO", userDetailsVO);
		request.getSession().setAttribute("customerId", userDetailsVO.getCustomerId());
		String planId = request.getParameter("Plan");
		request.getSession().setAttribute("planName", planId);
		String emailId = (String) request.getSession().getAttribute("emailId");
		EnrollmentVO sessionEnrollmentVO = null;
		
		//Begin: 2019 web app changes - IFOX-00406768
		String planYear = (String) request.getSession().getAttribute("planYear");
		LOGGER.info(" Sharp Controller : showEnrollFormMobile : PlanYear [" + planYear + "] ");
		//End: 2019 web app changes - IFOX-00406768
		
		if(planId != null && "SDAGC".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAGC***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAGC Current Session***");
				WebAppUtil.mapVOTOSessionSDAGC(sessionEnrollmentVO, mapModel);
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/individual/eFormExistingSDAGCMobile",mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ? "Sharp/individual/" + planYear + "/eFormExistingSDAGCMobile"  :
						"Sharp/individual/eFormExistingSDAGCMobile",mapModel);				
				//End: 2019 web app changes - IFOX-00406768
				
				//modView.addAllObjects(mapModel);
			}else{
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/individual/enrollmentFormSDAGCMobile", mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/individual/" + planYear + "/enrollmentFormSDAGCMobile" :
						"Sharp/individual/enrollmentFormSDAGCMobile", mapModel);
				//End: 2019 web app changes - IFOX-00406768
			}
		}else if(planId != null && "SDAGCWD".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAGCWD***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAGCWD Current Session***");
				WebAppUtil.mapVOTOSessionSDAGC(sessionEnrollmentVO, mapModel);
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/individual/eFormExistingSDAGCWDMobile",mapModel);				
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/individual/" + planYear + "/eFormExistingSDAGCWDMobile" :
						"Sharp/individual/eFormExistingSDAGCWDMobile",mapModel);
				//End: 2019 web app changes - IFOX-00406768
				
				//modView.addAllObjects(mapModel);
			}else{			
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/individual/enrollmentFormSDAGCWDMobile", mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/individual/" + planYear + "/enrollmentFormSDAGCWDMobile" :
						"Sharp/individual/enrollmentFormSDAGCWDMobile", mapModel);
				//End: 2019 web app changes - IFOX-00406768
				
			}
		}else if(planId != null && "SDAPC".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAPC***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAPC Current Session***");
				WebAppUtil.mapVOTOSessionSDAPC(sessionEnrollmentVO, mapModel);
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/individual/eFormExistingSDAPCMobile",mapModel);				
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/individual/" + planYear + "/eFormExistingSDAPCMobile" :
						"Sharp/individual/eFormExistingSDAPCMobile",mapModel);
				//End: 2019 web app changes - IFOX-00406768
				
				//modView.addAllObjects(mapModel);
			}else{			
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/individual/enrollmentFormSDAPCMobile", mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/individual/" + planYear + "/enrollmentFormSDAPCMobile" :
						"Sharp/individual/enrollmentFormSDAPCMobile", mapModel);
				//End: 2019 web app changes - IFOX-00406768
			}
		}
		/*IFOX-00418144 2020 AEP Plan Changes. START*/
		else if(planId != null && "SDAGC20".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAGC20***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAGC20 Current Session***");
				WebAppUtil.mapVOTOSessionSDAGC(sessionEnrollmentVO, mapModel);

				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/individual/eFormExistingSDAGC",mapModel);	
				modView = new ModelAndView(Integer.parseInt(planYear) > 2018 ? "Sharp/individual/" + planYear + "/eFormExistingSDAGC20" :
					"Sharp/individual/eFormExistingSDAGCMobile", mapModel);
				//End: 2019 web app changes - IFOX-00406768

				//modView.addAllObjects(mapModel);
			}else{
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/individual/enrollmentFormSDAGC", mapModel);
				modView = new ModelAndView(Integer.parseInt(planYear) > 2018 ? "Sharp/individual/" + planYear + "/enrollmentFormSDAGC20" :
					"Sharp/individual/enrollmentFormSDAGCMobile", mapModel);
				//End: 2019 web app changes - IFOX-00406768
			}
		}else if(planId != null && "SDAGCWD20".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAGCWD20***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAGCWD20 Current Session***");
				WebAppUtil.mapVOTOSessionSDAGC(sessionEnrollmentVO, mapModel);
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/individual/eFormExistingSDAGCWD",mapModel);
				modView = new ModelAndView(Integer.parseInt(planYear) > 2018 ?  "Sharp/individual/" + planYear + "/eFormExistingSDAGCWD20" :
						"Sharp/individual/eFormExistingSDAGCWDMobile",mapModel);				
				//End: 2019 web app changes - IFOX-00406768
				
				//modView.addAllObjects(mapModel);
			}else{			
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/individual/enrollmentFormSDAGCWD", mapModel);

				modView = new ModelAndView(Integer.parseInt(planYear) > 2018 ? "Sharp/individual/" + planYear + "/enrollmentFormSDAGCWD20" :
						"Sharp/individual/enrollmentFormSDAGCWDMobile", mapModel);
				//End: 2019 web app changes - IFOX-00406768
			}
		}else if(planId != null && "SDAPC20".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAPC20***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAPC20 Current Session***");
				WebAppUtil.mapVOTOSessionSDAPC(sessionEnrollmentVO, mapModel);
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/individual/eFormExistingSDAPC",mapModel);				
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/individual/" + planYear + "/eFormExistingSDAPC20" : 
						"Sharp/individual/eFormExistingSDAPCMobile",mapModel);
				//End: 2019 web app changes - IFOX-00406768
				
				//modView.addAllObjects(mapModel);
			}else{			
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/individual/enrollmentFormSDAPC", mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/individual/" + planYear + "/enrollmentFormSDAPC20" :
						"Sharp/individual/enrollmentFormSDAPCMobile", mapModel);
				//End: 2019 web app changes - IFOX-00406768
			}
		}/*IFOX-00418144 2020 AEP Plan Changes. END*/
		else if(planId != null && "SDAB".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAB***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAB Current Session***");
				WebAppUtil.mapVOTOSessionSDAB(sessionEnrollmentVO, mapModel);
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/eFormExistingSDABMobile",mapModel);				
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/eFormExistingSDABMobile" :
						"Sharp/group/eFormExistingSDABMobile",mapModel);
				//End: 2019 web app changes - IFOX-00406768
				
				//modView.addAllObjects(mapModel);
			}else{
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/enrollmentFormSDABMobile", mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/enrollmentFormSDABMobile" :
						"Sharp/group/enrollmentFormSDABMobile", mapModel);
				//End: 2019 web app changes - IFOX-00406768
			}
		}else if(planId != null && "SDABWD".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDABWD***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDABWD Current Session***");
				WebAppUtil.mapVOTOSessionSDAB(sessionEnrollmentVO, mapModel);
				// TO DO
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/eFormExistingSDABWDMobile",mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/eFormExistingSDABWDMobile" :
						"Sharp/group/eFormExistingSDABWDMobile",mapModel);
				//End: 2019 web app changes - IFOX-00406768
				
				//modView = new ModelAndView("Sharp/group/enrollmentFormSDABWD",mapModel);				
				//modView.addAllObjects(mapModel);
			}else{
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/enrollmentFormSDABWDMobile", mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/enrollmentFormSDABWDMobile" :
						"Sharp/group/enrollmentFormSDABWDMobile", mapModel);
				//End: 2019 web app changes - IFOX-00406768
			}
		}else if(planId != null && "SDAP".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAP***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAP Current Session***");
				WebAppUtil.mapVOTOSessionSDAP(sessionEnrollmentVO, mapModel);
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/eFormExistingSDAPMobile",mapModel);				
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/eFormExistingSDAPMobile" :
						"Sharp/group/eFormExistingSDAPMobile",mapModel);
				//End: 2019 web app changes - IFOX-00406768
				
				//modView.addAllObjects(mapModel);
			}else{
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/enrollmentFormSDAPMobile", mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/enrollmentFormSDAPMobile" :
						"Sharp/group/enrollmentFormSDAPMobile", mapModel);
				//End: 2019 web app changes - IFOX-00406768
			}
						
			
		}else if(planId != null && "SDAPWD".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAPWD***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAPWD Current Session***");
				WebAppUtil.mapVOTOSessionSDAP(sessionEnrollmentVO, mapModel);
				// TO DO 
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/eFormExistingSDAPWDMobile",mapModel);				
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ? "Sharp/group/" + planYear + "/eFormExistingSDAPWDMobile"  :
						"Sharp/group/eFormExistingSDAPWDMobile",mapModel);
				//End: 2019 web app changes - IFOX-00406768
				
				//modView = new ModelAndView("Sharp/group/eFormExistingSDAP",mapModel);
				//modView.addAllObjects(mapModel);
			}else{
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/enrollmentFormSDAPWDMobile", mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/enrollmentFormSDAPWDMobile" :
						"Sharp/group/enrollmentFormSDAPWDMobile", mapModel);
				//End: 2019 web app changes - IFOX-00406768
			}
		}else if(planId != null && "SDAB20".equalsIgnoreCase(planId) ){//IFOX-00419089 2020 AEP Plan Changes. START
			LOGGER.info("***Inside SDAB20***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAB20 Current Session***");
				WebAppUtil.mapVOTOSessionSDAB20(sessionEnrollmentVO, mapModel);
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/eFormExistingSDAB",mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/eFormExistingSDAB20" :
						"Sharp/group/eFormExistingSDABMobile",mapModel);				
				//End: 2019 web app changes - IFOX-00406768
				
				//modView.addAllObjects(mapModel);
			}else{
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/enrollmentFormSDAB", mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/enrollmentFormSDAB20" : 
						"Sharp/group/enrollmentFormSDABMobile", mapModel);
				//End: 2019 web app changes - IFOX-00406768
				
			}
		}else if(planId != null && "SDABWD20".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDABWD20***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDABWD20 Current Session***");
				WebAppUtil.mapVOTOSessionSDAB20(sessionEnrollmentVO, mapModel);
				// TO DO
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/eFormExistingSDABWD",mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/eFormExistingSDABWD20" : 
						"Sharp/group/eFormExistingSDABWDMobile",mapModel);
				//End: 2019 web app changes - IFOX-00406768
				
				//modView = new ModelAndView("Sharp/group/enrollmentFormSDABWD",mapModel);				
				//modView.addAllObjects(mapModel);
			}else{
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/enrollmentFormSDABWD", mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/enrollmentFormSDABWD20" : 
						"Sharp/group/enrollmentFormSDABWDMobile", mapModel);
				//End: 2019 web app changes - IFOX-00406768
			}
		}else if(planId != null && "SDAP20".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAP20***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAP20 Current Session***");
				WebAppUtil.mapVOTOSessionSDAB20(sessionEnrollmentVO, mapModel);
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/eFormExistingSDAP",mapModel);				
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/eFormExistingSDAP20" :
						"Sharp/group/eFormExistingSDAPMobile",mapModel);
				//End: 2019 web app changes - IFOX-00406768
				
				//modView.addAllObjects(mapModel);
			}else{
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/enrollmentFormSDAP", mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/enrollmentFormSDAP20" :
						"Sharp/group/enrollmentFormSDAPMobile", mapModel);
				//End: 2019 web app changes - IFOX-00406768
			}
						
			
		}else if(planId != null && "SDAPWD20".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAPWD20***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAPWD20 Current Session***");
				WebAppUtil.mapVOTOSessionSDAB20(sessionEnrollmentVO, mapModel);
				// TO DO 
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/eFormExistingSDAPWD",mapModel);				
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/eFormExistingSDAPWD20" :
						"Sharp/group/eFormExistingSDAPWDMobile",mapModel);
				//End: 2019 web app changes - IFOX-00406768
				
				//modView = new ModelAndView("Sharp/group/eFormExistingSDAP",mapModel);
				//modView.addAllObjects(mapModel);		
			}else{
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/group/enrollmentFormSDAPWD", mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/group/" + planYear + "/enrollmentFormSDAPWD20" :
						"Sharp/group/enrollmentFormSDAPWD", mapModel);
				//End: 2019 web app changes - IFOX-00406768
			}
			
		}else if(planId != null && "SDAMEA".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAMEA***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAMEA Current Session***");
				WebAppUtil.mapVOTOSessionSDAMEA(sessionEnrollmentVO, mapModel);
				modView = new ModelAndView("Sharp/mea/eFormExistingSDAMEAMobile",mapModel);				
				//modView.addAllObjects(mapModel);
			}else{
				modView = new ModelAndView("Sharp/mea/enrollmentFormSDAMEAMobile", mapModel);
			}
			
		}else if(planId != null && "SAS".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SAS***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SAS Current Session***");
				WebAppUtil.mapVOTOSessionSAS(sessionEnrollmentVO, mapModel);
				modView = new ModelAndView("Sharp/individual/eFormExistingSASMobile",mapModel);				
				//modView.addAllObjects(mapModel);
			}else{
				modView = new ModelAndView("Sharp/individual/enrollmentFormSASMobile", mapModel);
			}
			
			
		}else if(planId != null && "SASP".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SASP***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SASP Current Session***");
				WebAppUtil.mapVOTOSessionSASP(sessionEnrollmentVO, mapModel);
				modView = new ModelAndView("Sharp/individual/eFormExistingSASPMobile",mapModel);				
				//modView.addAllObjects(mapModel);
			}else{
				modView = new ModelAndView("Sharp/individual/enrollmentFormSASPMobile", mapModel);
			}
			
		}else if(planId != null && "SAB".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SAB***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SAB Current Session***");
				WebAppUtil.mapVOTOSessionSAB(sessionEnrollmentVO, mapModel);
				modView = new ModelAndView("Sharp/group/eFormExistingSABMobile",mapModel);				
				//modView.addAllObjects(mapModel);
			}else{
				modView = new ModelAndView("Sharp/group/enrollmentFormSABMobile", mapModel);
			}
			
		}else if(planId != null && "SAP".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SAP***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SAP Current Session***");
				WebAppUtil.mapVOTOSessionSAP(sessionEnrollmentVO, mapModel);
				modView = new ModelAndView("Sharp/group/eFormExistingSAPMobile",mapModel);				
				//modView.addAllObjects(mapModel);
			}else{
				modView = new ModelAndView("Sharp/group/enrollmentFormSAPMobile", mapModel);
			}
			
		}else if(planId != null && "SAMEA".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SAMEA***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SAMEA Current Session***");
				WebAppUtil.mapVOTOSessionSAMEA(sessionEnrollmentVO, mapModel);
				modView = new ModelAndView("Sharp/mea/eFormExistingSAMEAMobile",mapModel);				
				//modView.addAllObjects(mapModel);
			}else{
				modView = new ModelAndView("Sharp/mea/enrollmentFormSAMEAMobile", mapModel);
			}			
			
		}/**IFOX-00403984 Changes Start.*/
		else if(planId != null && "SDAHMO".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAHMO***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAHMO Current Session***");
				
				//Begin: Modified for IFOX-00414491
				//WebAppUtil.mapVOTOSessionSAMEA(sessionEnrollmentVO, mapModel);
				WebAppUtil.mapVOTOSessionSDAHMO(sessionEnrollmentVO, mapModel);
				//End: Modified for IFOX-00414491 
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/mea/eFormExistingSDAHMOMobile",mapModel);				
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/mea/" + planYear + "/eFormExistingSDAHMOMobile" :
						"Sharp/mea/eFormExistingSDAHMOMobile",mapModel);
				//End: 2019 web app changes - IFOX-00406768
				
				//modView.addAllObjects(mapModel);
			}else{
				//modView = new ModelAndView("Sharp/mea/eFormExistingSDAHMOMobile", mapModel);
				
				//Begin: 2019 web app changes - IFOX-00406768
				//modView = new ModelAndView("Sharp/mea/enrollmentFormSDAHMOMobile", mapModel);
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/mea/" + planYear + "/enrollmentFormSDAHMOMobile" :
						"Sharp/mea/enrollmentFormSDAHMOMobile", mapModel);
				//End: 2019 web app changes - IFOX-00406768
				
			}			
			
		}/**IFOX-00403984 Changes Stop.*/
		
		
		//Begin: Modified for IFOX-00414491	
		else if(planId != null && "SDAHMO1".equalsIgnoreCase(planId) )
		{
			LOGGER.info("***Inside SDAHMO1***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(userDetailsVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null)
			{
				LOGGER.info("***Getting SDAHMO1 Current Session***");
				WebAppUtil.mapVOTOSessionSDAHMO1(sessionEnrollmentVO, mapModel);
			
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/mea/" + planYear + "/eFormExistingSDAHMOMobile1" :
						"Sharp/mea/eFormExistingSDAHMOMobile1",mapModel);
			
			} else{
				modView = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ?  "Sharp/mea/" + planYear + "/enrollmentFormSDAHMOMobile1" :
						"Sharp/mea/enrollmentFormSDAHMOMobile1", mapModel);
			}
		}
		//End: Modified for IFOX-00414491	
		
		else{
			modView = new ModelAndView("Sharp/individual/planSelectionMobile", mapModel);
		}
		
		return modView;
	}	

/*	
	@RequestMapping(value = "/Individual/enrollOnline", method = RequestMethod.POST)
	public ModelAndView showExistingEnrollForm(HttpServletRequest request,
			@ModelAttribute("enrollmentVO") EnrollmentVO enrollmentVO) {
		
		EnrollmentVO sessionEnrollmentVO = null;
		ModelAndView modView ;
		enrollmentVO.setCustomerId(customer_id);
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		//mapModel.put("enrollmentVO", enrollmentVO);
		request.getSession().setAttribute("customerId", enrollmentVO.getCustomerId());
		
		String planId = request.getParameter("Plan");
		request.getSession().setAttribute("planName", planId);
		String emailId = (String) request.getSession().getAttribute("emailId");
		
		if(planId != null && "SDAGC".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAGC***");
			sessionEnrollmentVO = WebAppUtil.getSessionObject(enrollmentVO.getCustomerId(), planId, emailId);
			if(sessionEnrollmentVO != null){
				LOGGER.info("***Getting SDAGC Current Session***");
				
				//modView = new ModelAndView("Sharp/individual/eFormExistingSDAGC", mapModel);
				modView = new ModelAndView("Sharp/individual/eFormExistingSDAGC");
				WebAppUtil.mapVOTOSessionSDAGC(sessionEnrollmentVO, modView);
				//modView.addAllObjects(mapModel);
				
			}else{
				modView = new ModelAndView("Sharp/individual/enrollmentFormSDAGC", mapModel);
			}
		}else if(planId != null && "SDAPC".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAPC***");
			modView = new ModelAndView("Sharp/individual/enrollmentFormSDAPC", mapModel);
		}else if(planId != null && "SDAB".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAB***");
			//modView = new ModelAndView("Sharp/individual/enrollmentFormSDAB", mapModel);
			modView = new ModelAndView("Sharp/group/enrollmentFormSDAB", mapModel);
		}else if(planId != null && "SDAP".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAP***");
			//modView = new ModelAndView("Sharp/individual/enrollmentFormSDAP", mapModel);
			modView = new ModelAndView("Sharp/group/enrollmentFormSDAP", mapModel);
		}else if(planId != null && "SDAMEA".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SDAMEA***");
			//modView = new ModelAndView("Sharp/individual/enrollmentFormSDAMEA", mapModel);
			modView = new ModelAndView("Sharp/mea/enrollmentFormSDAMEA", mapModel);
		}else if(planId != null && "SAS".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SAS***");
			modView = new ModelAndView("Sharp/individual/enrollmentFormSAS", mapModel);
		}else if(planId != null && "SASP".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SASP***");
			modView = new ModelAndView("Sharp/individual/enrollmentFormSASP", mapModel);
		}else if(planId != null && "SAB".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SAB***");
			//modView = new ModelAndView("Sharp/individual/enrollmentFormSAB", mapModel);
			modView = new ModelAndView("Sharp/group/enrollmentFormSAB", mapModel);
		}else if(planId != null && "SAP".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SAP***");
			//modView = new ModelAndView("Sharp/individual/enrollmentFormSAP", mapModel);
			modView = new ModelAndView("Sharp/group/enrollmentFormSAP", mapModel);
		}else if(planId != null && "SAMEA".equalsIgnoreCase(planId) ){
			LOGGER.info("***Inside SAMEA***");
			//modView = new ModelAndView("Sharp/individual/enrollmentFormSAMEA", mapModel);
			modView = new ModelAndView("Sharp/mea/enrollmentFormSAMEA", mapModel);
		}else{
			modView = new ModelAndView("Sharp/individual/planSelection", mapModel);
		}
		
		//modView = new ModelAndView("Sharp/individual/enrollmentForm", mapModel);
		
		return modView;
	}	

	
*/	
	
	@RequestMapping(value = "/Individual/enrollSteps", method = RequestMethod.GET)
	public ModelAndView showEnrollSteps(HttpServletRequest request,
			@ModelAttribute("userDetailsVO") UserDetailsVO userDetailsVO) {
		
		ModelAndView modView;
		
		EmailUtil eUtil = new EmailUtil();
		userDetailsVO.setCustomerId(customer_id);
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		userDetailsVO.setCustomerId(customer_id);
		mapModel.put("userDetailsVO", userDetailsVO);
		request.getSession().setAttribute("customerId", userDetailsVO.getCustomerId());
		modView = new ModelAndView("Sharp/individual/enrollmentSteps", mapModel);
		return modView;
	}	
	
	
	
	@RequestMapping(value = "/Individual/resetPassword", method = RequestMethod.GET)
	public ModelAndView showResetPassword(HttpServletRequest request,
			@ModelAttribute("userDetailsVO") UserDetailsVO userDetailsVO) {
		
		ModelAndView modView;
		userDetailsVO.setCustomerId(customer_id);
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		userDetailsVO.setCustomerId(customer_id);
		mapModel.put("userDetailsVO", userDetailsVO);
		request.getSession().setAttribute("customerId", userDetailsVO.getCustomerId());
		modView = new ModelAndView("Sharp/individual/userLogin", mapModel);
		return null;
	}
	
	@RequestMapping(value = "/Individual/resetPasswordMobile", method = RequestMethod.GET)
	public ModelAndView showResetPasswordMobile(HttpServletRequest request,
			@ModelAttribute("userDetailsVO") UserDetailsVO userDetailsVO) {
		
		ModelAndView modView;
		userDetailsVO.setCustomerId(customer_id);
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		userDetailsVO.setCustomerId(customer_id);
		mapModel.put("userDetailsVO", userDetailsVO);
		request.getSession().setAttribute("customerId", userDetailsVO.getCustomerId());
		modView = new ModelAndView("Sharp/individual/userLoginMobile", mapModel);
		return null;
	}	
	
	@RequestMapping(value = "/group/yearSelection", method = RequestMethod.POST)
	public ModelAndView showYearSelectionForGroup(HttpServletRequest request,
			@ModelAttribute("userDetailsVO") UserDetailsVO userDetailsVO) {
		
		ModelAndView modView = null; ;
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		userDetailsVO.setCustomerId(customer_id);
		mapModel.put("userDetailsVO", userDetailsVO);
		
		LOGGER.info("Inside Year Selection !!");
		
		
		String customerId = request.getParameter("customerId");
		String emailAddress = request.getParameter("emailAddress");
		String password = request.getParameter("password");
		String reconfirmPassword = request.getParameter("reconfirmPwd");
		
		Properties properties = new Properties();
		FileInputStream fis = null;
		try{
			fis = new FileInputStream("C:\\WEBAPP\\SHP\\users.properties");
			properties.load(fis);
			fis.close();
			if(properties.containsKey(emailAddress) && properties.getProperty(emailAddress).equals(password) && reconfirmPassword == null ){
				LOGGER.info("From Login");
				modView = new ModelAndView("Sharp/group/yearSelection", mapModel);
			}else{
				LOGGER.info("From Registration");
				FileWriter writer = new FileWriter("C:\\WEBAPP\\SHP\\users.properties",true);
				String keyAndValue = emailAddress + "=" + password;
				if(reconfirmPassword != null){
					writer.write("\n");
					writer.write(keyAndValue);
					LOGGER.info("Email Address added to the repository !!");
				}else{
					
				}
				writer.close();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		request.getSession().setAttribute("customerId", customerId);
		request.getSession().setAttribute("emailId", emailAddress);
		
		loginVO.setCustomerId(customerId);
		loginVO.setEmailAddress(emailAddress);
		loginVO.setPassword(password);		
		
		LOGGER.info("Customer Id : "+loginVO.getCustomerId());
		LOGGER.info("Email Address : "+loginVO.getEmailAddress());
		LOGGER.info("Password : "+loginVO.getPassword());
		
		modView = new ModelAndView("Sharp/group/yearSelection", mapModel);
		return modView;
	}		
	
	@RequestMapping(value = "/group/Confirmation", method = RequestMethod.POST)
	public ModelAndView saveDetailsForGroup(HttpServletRequest request, HttpServletResponse response, @ModelAttribute("enrollmentVO") EnrollmentVO enrollmentVO) {

		String customerId = (String) request.getSession().getAttribute("customerId"); // this id will be used to save the details into system
		String emailId = (String) request.getSession().getAttribute("emailId"); // this id will be used to save the details into system
	
		ModelAndView modView;
		int ackValue = 0;
		
		UserDetailsVO userDetailsVO = WebAppUtil.mapToUserDetailsVO(enrollmentVO);
		PolicyDetailsVO policyDetails = WebAppUtil.mapToPolicyDetailsVO(enrollmentVO);
		AgreeDetailsVO agreeDetailsVO = WebAppUtil.mapToAgreeDetailsVO(enrollmentVO);
		AttestationDetailsVO attestationDetailsVO = WebAppUtil.mapToAttestationDetailsVO(enrollmentVO);
		
		request.getSession().setAttribute("userDetailsVO", userDetailsVO);
		request.getSession().setAttribute("policyDetails",policyDetails);
		request.getSession().setAttribute("agreeDetailsVO", agreeDetailsVO);
		request.getSession().setAttribute("attestationDetailsVO", attestationDetailsVO);		
		request.getSession().setAttribute("enrollmentVO", enrollmentVO);

		byte[] pdfSave;

		int planYear = Integer.parseInt((String) request.getSession().getAttribute("planYear"));
		LOGGER.info(" SharpController : saveDetailsForGroup [" + planYear + "] ");
		
		if(planYear > 2018)
			pdfSave = SharpPdfGen2019.saveBytesPDF(request, response);
		else
			pdfSave = SharpPdfGen.saveBytesPDF(request, response);
		
		request.getSession().setAttribute("pdfSaveenrollGen", pdfSave);
		String lastName = userDetailsVO.getLastName();
		
		DateFormat format = new SimpleDateFormat("yyyy_MM_dd_hh_mm_ss");
		String timeStamp = format.format(new Date());
		//int sequenceNumber = userDetailsService.getSequenecNumber();
		int sequenceNumber = userDetailsService.getSequenecNumberNew(customerId);
		int result = userDetailsService.updateSeedId(customerId, sequenceNumber);			
		LOGGER.info("SEQUENCE NUMBER : "+sequenceNumber);
		ackValue = userDetailsService.saveUserDetails(WebAppUtil.getUserDetailsObject(request, response, sequenceNumber));
		request.getSession().setAttribute("confirmationNumber", String.valueOf(ackValue));
		Properties prop = new Properties();
		try {
			prop.load(SharpController.class.getClassLoader().getResourceAsStream("saveLocation.properties"));
			String path = prop.getProperty("locationpath.pdfSave");
			File file = new File(path);

			if (!file.exists()) {
				file.mkdirs();
			}
			
			//String pdfName = path + ackValue + lastName + timeStamp + ".pdf";
			String pdfName = path + SHARPConstants.SHARPPDFPREFIX + ackValue + lastName + timeStamp + ".pdf";
			LOGGER.info(" pdfSave PATH : " + path);
			LOGGER.info(" pdfName      : " + pdfName);
			LOGGER.info(" ackValue      : " + pdfName);
			LOGGER.info(" lastName      : " + lastName);
			LOGGER.info(" timeStamp      : " + timeStamp);
			byte[] ps = Base64.decodeBase64(pdfSave);
		 	FileOutputStream fos = new FileOutputStream(pdfName);
		    fos.write(ps);
			fos.close();
			JschSftpUploader.uploadToFTP(customerId, pdfName);
			/*			
			String to[] = prop.getProperty("mail.to").split(",");
			String from = prop.getProperty("mail.from");
			String subject = prop.getProperty("mail.subject");
			String cc[] = prop.getProperty("mail.cc").split(",");
			String message = prop.getProperty("mail.message");
			sendMail.sendMail(from, to, cc, subject,message,pdfName);*/
			
			String[] emailToList = new String[] {emailId};
			
			//EmailUtil emailUtil = new EmailUtil(emailToList);
			EmailUtil emailUtil = new EmailUtil(emailToList, null); //Added for IFOX-00405531
			
			ArrayList<String> filesList = new ArrayList<String>();
			filesList.add(pdfName);
			LOGGER.info(" *********Before Sending Email In Group************** ");
			emailUtil.sendEmailAttachment("Enrollment Confirmation Message", " Hi " + lastName + ", \n\n Your enrollment is successfull and please find the attached PDF document for your future reference. \n\n Thanks, \n Enrollment Support Team.", filesList, emailUtil.TEXT_PLAIN);
			LOGGER.info(" *********After Sending Email In Group************** ");
			
		} catch (IOException exp) {
			LOGGER.error(" SharpController : IOException : " + exp);
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String planName = (String)request.getSession().getAttribute("planName");
		if("SAB".equalsIgnoreCase(planName)){
			modView = new ModelAndView("Sharp/group/enrollmentConfirmationSAB");
		}else if("SAP".equalsIgnoreCase(planName)){
			modView = new ModelAndView("Sharp/group/enrollmentConfirmationSAP");
		}else if("SDAB".equalsIgnoreCase(planName)){
			modView = new ModelAndView("Sharp/group/enrollmentConfirmationSDAB");
		}else if("SDABWD".equalsIgnoreCase(planName)){
			modView = new ModelAndView("Sharp/group/enrollmentConfirmationSDABWD");
		}else if("SDAP".equalsIgnoreCase(planName)){
			modView = new ModelAndView("Sharp/group/enrollmentConfirmationSDAP");
		}else if("SDAPWD".equalsIgnoreCase(planName)){
			modView = new ModelAndView("Sharp/group/enrollmentConfirmationSDAPWD");
		}else{
			return null;
		}
		
		
		return modView;
	}		

	
	
	@RequestMapping(value = "/Individual/userCreation", method = RequestMethod.GET)
	public ModelAndView showUserCreation(HttpServletRequest request,
			@ModelAttribute("userDetailsVO") UserDetailsVO userDetailsVO) {
		
		// it should be depending upon the year for implementation

		ModelAndView modView;
		userDetailsVO.setCustomerId(customer_id);
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		userDetailsVO.setCustomerId(customer_id);
		mapModel.put("userDetailsVO", userDetailsVO);
		request.getSession().setAttribute("customerId", userDetailsVO.getCustomerId());
		modView = new ModelAndView("Sharp/individual/userCreation", mapModel);
		return modView;
	}
	
	@RequestMapping(value = "/Individual/userCreationMobile", method = RequestMethod.POST)
	public ModelAndView showUserCreationMobile(HttpServletRequest request,
			@ModelAttribute("userDetailsVO") UserDetailsVO userDetailsVO) {
		
		// it should be depending upon the year for implementation

		ModelAndView modView;
		userDetailsVO.setCustomerId(customer_id);
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		userDetailsVO.setCustomerId(customer_id);
		mapModel.put("userDetailsVO", userDetailsVO);
		request.getSession().setAttribute("customerId", userDetailsVO.getCustomerId());
		modView = new ModelAndView("Sharp/individual/userCreationMobile", mapModel);
		return modView;
	}	
	
	@RequestMapping(value = "/Individual/userLogin", method = RequestMethod.GET)
	public ModelAndView showUserLogin(HttpServletRequest request,
			@ModelAttribute("userDetailsVO") UserDetailsVO userDetailsVO) {			
		
		ModelAndView modView;
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		mapModel.put("userDetailsVO", userDetailsVO);
		String customerId = request.getParameter("customerId");
		request.getSession().setAttribute("customerId", userDetailsVO.getCustomerId());
		
		modView = new ModelAndView("Sharp/individual/userLogin", mapModel);
		return modView;
	}
	
	@RequestMapping(value = "/Individual/userLoginMobile", method = RequestMethod.GET)
	public ModelAndView showUserLoginMobile(HttpServletRequest request,
			@ModelAttribute("userDetailsVO") UserDetailsVO userDetailsVO) {			
		
		ModelAndView modView;
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		mapModel.put("userDetailsVO", userDetailsVO);
		String customerId = request.getParameter("customerId");
		request.getSession().setAttribute("customerId", userDetailsVO.getCustomerId());
		
		modView = new ModelAndView("Sharp/individual/userLoginMobile", mapModel);
		return modView;
	}	
	
	@RequestMapping(value = "/Individual/userPwdReset", method = RequestMethod.GET)
	public ModelAndView showUserPasswordReset(HttpServletRequest request,
			@ModelAttribute("userDetailsVO") UserDetailsVO userDetailsVO) {
		
		ModelAndView modView;
		userDetailsVO.setCustomerId(customer_id);
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		userDetailsVO.setCustomerId(customer_id);
		mapModel.put("userDetailsVO", userDetailsVO);
		request.getSession().setAttribute("customerId", userDetailsVO.getCustomerId());
		modView = new ModelAndView("Sharp/individual/userPwdReset", mapModel);
		return modView;
	}	
	
	@RequestMapping(value = "/Individual/userPwdResetMobile", method = RequestMethod.GET)
	public ModelAndView showUserPasswordResetMobile(HttpServletRequest request,
			@ModelAttribute("userDetailsVO") UserDetailsVO userDetailsVO) {
		
		ModelAndView modView;
		userDetailsVO.setCustomerId(customer_id);
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		userDetailsVO.setCustomerId(customer_id);
		mapModel.put("userDetailsVO", userDetailsVO);
		request.getSession().setAttribute("customerId", userDetailsVO.getCustomerId());
		modView = new ModelAndView("Sharp/individual/userPwdResetMobile", mapModel);
		return modView;
	}	
	
	@RequestMapping(value = "/Individual/selectedPlans", method = RequestMethod.POST)
	public ModelAndView showPlanSelection(HttpServletRequest request,
			@ModelAttribute("userDetailsVO") UserDetailsVO userDetailsVO) {
		
		ModelAndView modView;
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		userDetailsVO.setCustomerId(customer_id);
		mapModel.put("userDetailsVO", userDetailsVO);
		
		request.getSession().setAttribute("customerId", userDetailsVO.getCustomerId());
		
		String year = request.getParameter("year");
		
		//Change for IFOX-00414491 - Start
		if(request.getSession().getAttribute("planYear") != null && request.getSession().getAttribute("directLink") != null)
			year = (String) request.getSession().getAttribute("planYear");
		//Change for IFOX-00414491 - End
		
		//Begin: 2019 web app changes - IFOX-00406768
		System.out.println(" SharpController : showPlanSelection : PlanYear [" + year + "] ");
		request.getSession().setAttribute("planYear", year);
		
		if(Integer.parseInt(year) > 2018) {
			modView = new ModelAndView("Sharp/individual/" + year + "/planSelection", mapModel);
		
		} else {	
		//End: 2019 web app changes - IFOX-00406768
		
		if(year != null && "2017".equals(year)){
			modView = new ModelAndView("Sharp/individual/planSelection2017", mapModel);
		}else if(year != null && "2018".equals(year)){
			modView = new ModelAndView("Sharp/individual/planSelection", mapModel);
		//Start: 2019 web app changes - IFOX-00411118
		}else if(year != null && "2019".equals(year)){
			modView = new ModelAndView("Sharp/individual/2019/planSelection", mapModel);
		}else{
			modView = new ModelAndView("Sharp/individual/2019/planSelection", mapModel);
		}
		//End: 2019 web app changes - IFOX-00411118
		}
		
		return modView;
	}
	
	@RequestMapping(value = "/Individual/selectedPlansMobile", method = RequestMethod.POST)
	public ModelAndView showPlanSelectionMobile(HttpServletRequest request,
			@ModelAttribute("userDetailsVO") UserDetailsVO userDetailsVO) {
		
		ModelAndView modView;
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		userDetailsVO.setCustomerId(customer_id);
		mapModel.put("userDetailsVO", userDetailsVO);
		
		request.getSession().setAttribute("customerId", userDetailsVO.getCustomerId());
		
		String year = request.getParameter("year");
		
		//Change for IFOX-00414491 - Start
		if(request.getSession().getAttribute("planYear") != null && request.getSession().getAttribute("directLink") != null)
			year = (String) request.getSession().getAttribute("planYear");
		//Change for IFOX-00414491 - End
		
		//Begin: 2019 web app changes - IFOX-00406768
		System.out.println(" SharpController : showPlanSelectionMobile : PlanYear [" + year + "] ");
		request.getSession().setAttribute("planYear", year);
		
		if(Integer.parseInt(year) > 2018) {
			modView = new ModelAndView("Sharp/individual/" + year + "/planSelectionMobile", mapModel);
		
		} else {	
		//End: 2019 web app changes - IFOX-00406768
		
		if(year != null && "2017".equals(year)){
			modView = new ModelAndView("Sharp/individual/planSelection2017Mobile", mapModel);
		}else if(year != null && "2018".equals(year)){
			modView = new ModelAndView("Sharp/individual/planSelectionMobile", mapModel);
		}		
		//Start: 2019 web app changes - IFOX-00411118
		else if(year != null && "2019".equals(year)){
			modView = new ModelAndView("Sharp/individual/2019/planSelectionMobile", mapModel);
		}else{
			modView = new ModelAndView("Sharp/individual/2020/planSelectionMobile", mapModel);
		}
		//End: 2019 web app changes - IFOX-00411118
		
		}
		
		return modView;
	}

	
	@RequestMapping(value = "/mea/changePlan", method = RequestMethod.GET)
	public ModelAndView showChangePlanForMEA(HttpServletRequest request,
			@ModelAttribute("userDetailsVO") UserDetailsVO userDetailsVO) {
		
		ModelAndView modView;
		userDetailsVO.setCustomerId(customer_id);
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		userDetailsVO.setCustomerId(customer_id);
		mapModel.put("userDetailsVO", userDetailsVO);
		request.getSession().setAttribute("customerId", userDetailsVO.getCustomerId());
		modView = new ModelAndView("Sharp/mea/yearSelection", mapModel);
		return modView;
	}		
	
	
	@RequestMapping(value = "/Individual/changePlan", method = RequestMethod.GET)
	public ModelAndView showChangePlan(HttpServletRequest request,
			@ModelAttribute("userDetailsVO") UserDetailsVO userDetailsVO) {
		
		ModelAndView modView;
		userDetailsVO.setCustomerId(customer_id);
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		userDetailsVO.setCustomerId(customer_id);
		mapModel.put("userDetailsVO", userDetailsVO);
		request.getSession().setAttribute("customerId", userDetailsVO.getCustomerId());
		modView = new ModelAndView("Sharp/individual/yearSelection", mapModel);
		return modView;
	}
	
	@RequestMapping(value = "/Individual/changePlanMobile", method = RequestMethod.GET)
	public ModelAndView showChangePlanMobile(HttpServletRequest request,
			@ModelAttribute("userDetailsVO") UserDetailsVO userDetailsVO) {
		
		ModelAndView modView;
		userDetailsVO.setCustomerId(customer_id);
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		userDetailsVO.setCustomerId(customer_id);
		mapModel.put("userDetailsVO", userDetailsVO);
		request.getSession().setAttribute("customerId", userDetailsVO.getCustomerId());
		modView = new ModelAndView("Sharp/individual/yearSelectionMobile", mapModel);
		return modView;
	}
	
	@RequestMapping(value = "/Individual/Save", method = RequestMethod.POST)
	public ModelAndView saveDetailsAndLogout(HttpServletRequest request, @ModelAttribute("enrollmentVO") EnrollmentVO enrollmentVO) {
		
		LOGGER.info("*****Request received from client for saveDetailsAndLogout*******");
		
		String customerId = (String) request.getSession().getAttribute("customerId"); // this id will be used to save the details into system
		String emailId = (String) request.getSession().getAttribute("emailId"); // this id will be used to save the details into system
		String planId = (String) request.getSession().getAttribute("planName");
		
		UserDetailsVO userDetailsVO = WebAppUtil.mapToUserDetailsVO(enrollmentVO);
		PolicyDetailsVO policyDetails = WebAppUtil.mapToPolicyDetailsVO(enrollmentVO);
		AgreeDetailsVO agreeDetailsVO = WebAppUtil.mapToAgreeDetailsVO(enrollmentVO);
		AttestationDetailsVO attestationDetailsVO = WebAppUtil.mapToAttestationDetailsVO(enrollmentVO);
		
		request.getSession().setAttribute("userDetailsVO", userDetailsVO);
		request.getSession().setAttribute("policyDetails",policyDetails);
		request.getSession().setAttribute("agreeDetailsVO", agreeDetailsVO);
		request.getSession().setAttribute("attestationDetailsVO", attestationDetailsVO);
		request.getSession().setAttribute("enrollmentVO", enrollmentVO);
		
		
		LOGGER.info("The Customer ID from the request/session is : "+customerId);
		LOGGER.info("The Email ID from the request/session is : "+emailId);
	
		WebAppUtil.saveEnrollmentVOToFile(enrollmentVO, planId, emailId);
		
		return new ModelAndView("Sharp/individual/userCreation");
		//return null;
	}	
	
	
	@RequestMapping(value = "/mea/Save", method = RequestMethod.POST)
	public ModelAndView saveDetailsAndLogoutForMEA(HttpServletRequest request, @ModelAttribute("enrollmentVO") EnrollmentVO enrollmentVO) {
		
		LOGGER.info("*****Request received from client for saveDetailsAndLogout*******");
		
		String customerId = (String) request.getSession().getAttribute("customerId"); // this id will be used to save the details into system
		String emailId = (String) request.getSession().getAttribute("emailId"); // this id will be used to save the details into system
		String planId = (String) request.getSession().getAttribute("planName");
		
		UserDetailsVO userDetailsVO = WebAppUtil.mapToUserDetailsVO(enrollmentVO);
		PolicyDetailsVO policyDetails = WebAppUtil.mapToPolicyDetailsVO(enrollmentVO);
		AgreeDetailsVO agreeDetailsVO = WebAppUtil.mapToAgreeDetailsVO(enrollmentVO);
		AttestationDetailsVO attestationDetailsVO = WebAppUtil.mapToAttestationDetailsVO(enrollmentVO);
		
		request.getSession().setAttribute("userDetailsVO", userDetailsVO);
		request.getSession().setAttribute("policyDetails",policyDetails);
		request.getSession().setAttribute("agreeDetailsVO", agreeDetailsVO);
		request.getSession().setAttribute("attestationDetailsVO", attestationDetailsVO);
		request.getSession().setAttribute("enrollmentVO", enrollmentVO);
		
		
		LOGGER.info("The Customer ID from the request/session is : "+customerId);
		LOGGER.info("The Email ID from the request/session is : "+emailId);
	
		WebAppUtil.saveEnrollmentVOToFile(enrollmentVO, planId, emailId);
		
		return new ModelAndView("Sharp/individual/userCreation");
		//return null;
	}	
	

	@RequestMapping(value = "/group/Save", method = RequestMethod.POST)
	public ModelAndView saveDetailsAndLogoutForGroup(HttpServletRequest request, @ModelAttribute("enrollmentVO") EnrollmentVO enrollmentVO) {
		
		LOGGER.info("*****Request received from client for saveDetailsAndLogout*******");
		
		String customerId = (String) request.getSession().getAttribute("customerId"); // this id will be used to save the details into system
		String emailId = (String) request.getSession().getAttribute("emailId"); // this id will be used to save the details into system
		String planId = (String) request.getSession().getAttribute("planName");
		
		UserDetailsVO userDetailsVO = WebAppUtil.mapToUserDetailsVO(enrollmentVO);
		PolicyDetailsVO policyDetails = WebAppUtil.mapToPolicyDetailsVO(enrollmentVO);
		AgreeDetailsVO agreeDetailsVO = WebAppUtil.mapToAgreeDetailsVO(enrollmentVO);
		AttestationDetailsVO attestationDetailsVO = WebAppUtil.mapToAttestationDetailsVO(enrollmentVO);
		
		request.getSession().setAttribute("userDetailsVO", userDetailsVO);
		request.getSession().setAttribute("policyDetails",policyDetails);
		request.getSession().setAttribute("agreeDetailsVO", agreeDetailsVO);
		request.getSession().setAttribute("attestationDetailsVO", attestationDetailsVO);
		request.getSession().setAttribute("enrollmentVO", enrollmentVO);
		
		
		LOGGER.info("The Customer ID from the request/session is : "+customerId);
		LOGGER.info("The Email ID from the request/session is : "+emailId);
	
		String firstName = enrollmentVO.getFirstName();
		WebAppUtil.saveEnrollmentVOToFile(enrollmentVO, planId, emailId);
		//return new ModelAndView("Sharp/group/enrollmentConfirmation");
		//return null;
		return new ModelAndView("Sharp/individual/userCreation");
	}		
	
	
	@RequestMapping(value = "/Individual/Confirmation", method = RequestMethod.POST)
	public ModelAndView saveDetails(HttpServletRequest request, HttpServletResponse response, @ModelAttribute("enrollmentVO") EnrollmentVO enrollmentVO) {

		String customerId = (String) request.getSession().getAttribute("customerId"); // this id will be used to save the details into system
		String emailId = (String) request.getSession().getAttribute("emailId"); // this id will be used to save the details into system
		String planId = (String) request.getSession().getAttribute("planName");
		
		ModelAndView modView;
		int ackValue = 0;
		
		UserDetailsVO userDetailsVO = WebAppUtil.mapToUserDetailsVO(enrollmentVO);
		PolicyDetailsVO policyDetails = WebAppUtil.mapToPolicyDetailsVO(enrollmentVO);
		AgreeDetailsVO agreeDetailsVO = WebAppUtil.mapToAgreeDetailsVO(enrollmentVO);
		AttestationDetailsVO attestationDetailsVO = WebAppUtil.mapToAttestationDetailsVO(enrollmentVO);
		
		request.getSession().setAttribute("userDetailsVO", userDetailsVO);
		request.getSession().setAttribute("policyDetails",policyDetails);
		request.getSession().setAttribute("agreeDetailsVO", agreeDetailsVO);
		request.getSession().setAttribute("attestationDetailsVO", attestationDetailsVO);
		request.getSession().setAttribute("enrollmentVO", enrollmentVO);
		
		int sequenceNumber = userDetailsService.getSequenecNumberNew(customerId);
		int result = userDetailsService.updateSeedId(customerId, sequenceNumber);			
		
		//Begin: 2019 web app changes - IFOX-00406768
		int planYear = Integer.parseInt((String) request.getSession().getAttribute("planYear"));
		LOGGER.info(" SharpController : saveDetails [" + planYear + "] ");
		enrollmentVO.setPlanYear(String.valueOf(planYear));
		request.getSession().setAttribute("WebAppConfirmationNumber", String.valueOf(sequenceNumber));

		byte[] pdfSave;
		String planName = (String) request.getSession().getAttribute("planName");
		String fullPlanName = "";

		//Begin: Modified for IFOX-00414491
		if(planYear > 2018) {
			if( (planYear == 2020 && "SDAHMO1".equalsIgnoreCase(planName)) /*IFOX-00418144 2020 AEP Plan Changes.*/
					|| (planYear == 2020 || "SDAGC20".equalsIgnoreCase(planName) || "SDAGCWD20".equalsIgnoreCase(planName) || "SDAPC20".equalsIgnoreCase(planName)))
				pdfSave = SharpPdfGen2020.saveBytesPDF(request, response);
			else
				pdfSave = SharpPdfGen2019.saveBytesPDF(request, response);
		} else {
			pdfSave = SharpPdfGen.saveBytesPDF(request, response);
		}
		//End: Modified for IFOX-00414491

		request.getSession().setAttribute("pdfSaveenrollGen", pdfSave);
		String lastName = userDetailsVO.getLastName();
		String firstName = userDetailsVO.getFirstName();
		DateFormat format = new SimpleDateFormat("yyyy_MM_dd_hh_mm_ss");
		String timeStamp = format.format(new Date());
		//int sequenceNumber = userDetailsService.getSequenecNumber();
//		int sequenceNumber = userDetailsService.getSequenecNumberNew(customerId);
//		int result = userDetailsService.updateSeedId(customerId, sequenceNumber);
		
		if("SAB".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Advantage Basic";
		}else if("SAP".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Advantage Premium";
		//IFOX-00419089 PBP 801 CR - Start
		}else if("SDAB".equalsIgnoreCase(planName)||"SDAB20".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Direct Advantage Basic";
		}else if("SDABWD".equalsIgnoreCase(planName)||"SDABWD20".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Direct Advantage Basic with Dental";
		}else if("SDAP".equalsIgnoreCase(planName)||"SDAP20".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Direct Advantage Premium";
		}else if("SDAPWD".equalsIgnoreCase(planName)||"SDAPWD20".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Direct Advantage Premium with Dental";
		//IFOX-00419089 PBP 801 CR - End
		}else if("SAS".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Advantage Select";
		}else if("SASP".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Advantage Select Plus";
		/*IFOX-00418144 2020 AEP Plan Changes. START*/
		}else if("SDAGC".equalsIgnoreCase(planName) || "SDAGC20".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Direct Advantage Gold Card";
		}else if("SDAGCWD".equalsIgnoreCase(planName) || "SDAGCWD20".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Direct Advantage Gold Card with Dental";
		}else if("SDAPC".equalsIgnoreCase(planName) || "SDAPC20".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Direct Advantage Platinum Card with Dental";
		/*IFOX-00418144 2020 AEP Plan Changes. END*/
		}else if("SAMEA".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Advantage MEA";
		}else if("SDAMEA".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Direct Advantage MEA";
		}/**IFOX-00403984 Changes Start.*/
		
		//Begin: Modified for IFOX-00414491
		else if("SDAHMO1".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Direct Advantage HMO";
		}
		//End: Modified for IFOX-00414491 
		
		else if("SDAHMO".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Direct Advantage HMO";
		}/**IFOX-00403984 Changes Stop.*/else{
			fullPlanName = "health";
		}		
		
		LOGGER.info("SEQUENCE NUMBER : "+sequenceNumber);
		ackValue = userDetailsService.saveUserDetails(WebAppUtil.getUserDetailsObject(request, response , sequenceNumber));
		if(ackValue!=0){//change for IFOX-00415112 Start
			ackValue=sequenceNumber;
		}//change for IFOX-00415112 END
		userDetailsService.addUserApplicationNumber(customerId, emailId, ackValue);
		
		if(emailId!="Guest")
			userDetailsService.addUserApplicationNumber(customerId, emailId, ackValue);
		
		request.getSession().setAttribute("confirmationNumber", String.valueOf(ackValue));
		Properties prop = new Properties();
		try {
			prop.load(SharpController.class.getClassLoader().getResourceAsStream("saveLocation.properties"));
			String path = prop.getProperty("locationpath.pdfSave");
			File file = new File(path);

			if (!file.exists()) {
				file.mkdirs();
			}
			//String pdfName = path + ackValue + lastName + timeStamp + ".pdf";
			String pdfName = path + SHARPConstants.SHARPPDFPREFIX + ackValue + lastName + timeStamp + ".pdf";
			
			String htmlMsg = "<html>"
			+ "<img src=\"cid:0001\" style=\"width: 100px;\">"
			+ "<br>"
			+ "<div style=\"font-family: calibri; width: 75%; font-size: 12pt;\">"
			+ "<p><br>Dear " + firstName + " " + lastName + ",</p>"
			+ "<p>Thank you for choosing Sharp Health Plan!</p>"
			+ "<p>This email is to confirm that we've received your application for our " + fullPlanName
			+ " plan. For your records, your confirmation number is " + ackValue
			+ ", and a copy of your application is attached. </p>"
			+ "<p>Please allow up to 10 business days for your application to be processed, and for you to receive your new Member ID card "
			+ "and Welcome Kit, both of which will be mailed separately. </p>"
			+ "<p>If you have any questions regarding your enrollment status or benefits, please contact Customer Care "
			+ "toll-free at 1-855-562-8853 (TTY/TDD users should call 711). For your convenience, our hours of operation are: " //Fix for IFOX-00406768 Start
			+ "Oct. 1 - Mar. 31 from 8 a.m. to 8 p.m. Pacific Time, 7 days a week; Apr. 1 - Sept. 30 from 8 a.m. to 8 p.m. " //Fix for IFOX-00406768 End
			+ "Pacific Time, Monday through Friday. On weekends and holidays, your call will be handled by our voicemail system "
			+ "and a Customer Care Representative will return your phone call the next business day.</p>"
			+ "<p>Warm regards,</p>"
			+ "<img src=\"cid:0002\" style=\"width: 150px;\">"
			+ "<p>Leslie Pels-Beck<br>"
			+ "Vice President, Customer Care</p>"
			+ "</div>"
			+ "</html>"; 
			
			LOGGER.info(" pdfSave PATH : " + path);
			LOGGER.info(" pdfName      : " + pdfName);
			LOGGER.info(" ackValue      : " + pdfName);
			LOGGER.info(" lastName      : " + lastName);
			LOGGER.info(" timeStamp      : " + timeStamp);
			byte[] ps = Base64.decodeBase64(pdfSave);
		 	FileOutputStream fos = new FileOutputStream(pdfName);
		    fos.write(ps);
			fos.close();
			JschSftpUploader.uploadToFTP(customerId, pdfName);
			
			String[] emailToList = null;
			
			if(emailId!="Guest")
				emailToList = new String[] {emailId};
			else
				emailToList = new String[] {enrollmentVO.getEmailAddr()};
			
			//EmailUtil emailUtil = new EmailUtil(emailToList);
			EmailUtil emailUtil = new EmailUtil(emailToList, null); //Added for IFOX-00405531
			
			ArrayList<String> filesList = new ArrayList<String>();
			filesList.add(pdfName);
			LOGGER.info(" *********Before Sending Email In Individual************** ");
			//emailUtil.sendEmailAttachment("Enrollment Confirmation Message", " Hi " + lastName + ", \n\n Your enrollment is successfull and please find the attached PDF document for your future reference. \n\n Thanks, \n Enrollment Support Team.", filesList, emailUtil.TEXT_PLAIN);
			emailUtil.sendHtmlEmailAttachment("Your Sharp Direct Advantage Application has Been Received", htmlMsg, filesList, emailUtil.TEXT_HTML, request);
			LOGGER.info(" *********After Sending Email In Individual************** ");
			
			EnrollmentVO existingSession = WebAppUtil.getSessionObject(customerId, planId, emailId);
			if(existingSession != null){
				LOGGER.info("*******Before deleting session object");
				WebAppUtil.removeSessionObject(customerId, planId, emailId);
				LOGGER.info("*******After deleting session object");
			}else{
				LOGGER.info("*******Session does not exist !!");
			}
			
		} catch (IOException exp) {
			LOGGER.error(" SharpController : saveEnrollForm8IOException : " + exp);
		}
		//modView = new ModelAndView("Sharp/individual/enrollment9_2017","ackValue", ackValue);
		catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		//String planName = (String) request.getSession().getAttribute("planName");
		
		if("SAB".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/group/" + planYear + "/enrollmentConfirmationSAB" : "Sharp/group/enrollmentConfirmationSAB");
		}else if("SAP".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/group/" + planYear + "/enrollmentConfirmationSAP" : "Sharp/group/enrollmentConfirmationSAP");
		}else if("SDAB".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/group/" + planYear + "/enrollmentConfirmationSDAB" : "Sharp/group/enrollmentConfirmationSDAB");
		}else if("SDABWD".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/group/" + planYear + "/enrollmentConfirmationSDABWD" : "Sharp/group/enrollmentConfirmationSDABWD");
		}else if("SDAP".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/group/" + planYear + "/enrollmentConfirmationSDAP" : "Sharp/group/enrollmentConfirmationSDAP");
		}else if("SDAPWD".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/group/" + planYear + "/enrollmentConfirmationSDAPWD" : "Sharp/group/enrollmentConfirmationSDAPWD");
		}else if("SAS".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/individual/" + planYear + "/enrollmentConfirmationSAS" : "Sharp/individual/enrollmentConfirmationSAS");
		}else if("SASP".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/individual/" + planYear + "/enrollmentConfirmationSASP" : "Sharp/individual/enrollmentConfirmationSASP");
		}else if("SDAGC".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/individual/" + planYear + "/enrollmentConfirmationSDAGC" : "Sharp/individual/enrollmentConfirmationSDAGC");
		}else if("SDAGCWD".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/individual/" + planYear + "/enrollmentConfirmationSDAGCWD" : "Sharp/individual/enrollmentConfirmationSDAGCWD");
		}else if("SDAPC".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/individual/" + planYear + "/enrollmentConfirmationSDAPC" : "Sharp/individual/enrollmentConfirmationSDAPC");
		}else if("SAMEA".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/mea/" + planYear + "/enrollmentConfirmationSAMEA" : "Sharp/mea/enrollmentConfirmationSAMEA");
		}else if("SDAMEA".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/mea/" + planYear + "/enrollmentConfirmationSDAMEA" : "Sharp/mea/enrollmentConfirmationSDAMEA");
		}/**IFOX-00403984 Changes Start.*/
		else if("SDAHMO".equalsIgnoreCase(planName)){
			//Begin: Modified for IFOX-00414491
			//modView = new ModelAndView(planYear > 2018 ? "Sharp/mea/" + planYear + "/enrollmentConfirmationSDAMEA" : "Sharp/mea/enrollmentConfirmationSDAHMO");
			modView = new ModelAndView(planYear > 2018 ? "Sharp/mea/" + planYear + "/enrollmentConfirmationSDAHMO" : "Sharp/mea/enrollmentConfirmationSDAHMO");
			//End: Modified for IFOX-00414491 
		}/**IFOX-00403984 Changes Stop.*/

		//Begin: Modified for IFOX-00414491
		else if("SDAHMO1".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/mea/" + planYear + "/enrollmentConfirmationSDAHMO1" : "Sharp/mea/enrollmentConfirmationSDAHMO1");
		}
		//End: Modified for IFOX-00414491
		/*IFOX-00418144 2020 AEP Plan Change. START*/
		else if("SDAGC20".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/individual/" + planYear + "/enrollmentConfirmationSDAGC20" : "Sharp/individual/enrollmentConfirmationSDAGC");
		}else if("SDAGCWD20".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/individual/" + planYear + "/enrollmentConfirmationSDAGCWD20" : "Sharp/individual/enrollmentConfirmationSDAGCWD");
		}else if("SDAPC20".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/individual/" + planYear + "/enrollmentConfirmationSDAPC20" : "Sharp/individual/enrollmentConfirmationSDAPC");
		}
		/*IFOX-00418144 2020 AEP Plan Change. END*/
		//IFOX-00419089 PBP 801 CR - Start
		else if("SDAB20".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/group/" + planYear + "/enrollmentConfirmationSDAB20" : "Sharp/group/enrollmentConfirmationSDAB");
		}else if("SDABWD20".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/group/" + planYear + "/enrollmentConfirmationSDABWD20" : "Sharp/group/enrollmentConfirmationSDABWD");
		}else if("SDAP20".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/group/" + planYear + "/enrollmentConfirmationSDAP20" : "Sharp/group/enrollmentConfirmationSDAP");
		}else if("SDAPWD20".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/group/" + planYear + "/enrollmentConfirmationSDAPWD20" : "Sharp/group/enrollmentConfirmationSDAPWD");
		}
		//IFOX-00419089 PBP 801 CR - End
		
		else{
			return null;
		}		
		
		//return new ModelAndView("Sharp/individual/enrollmentConfirmation");
		return modView;
	}		
	
	@RequestMapping(value = "/Individual/ConfirmationMobile", method = RequestMethod.POST)
	public ModelAndView saveDetailsMobile(HttpServletRequest request, HttpServletResponse response, @ModelAttribute("enrollmentVO") EnrollmentVO enrollmentVO) {

		String customerId = (String) request.getSession().getAttribute("customerId"); // this id will be used to save the details into system
		String emailId = (String) request.getSession().getAttribute("emailId"); // this id will be used to save the details into system
		String planId = (String) request.getSession().getAttribute("planName");
		
		ModelAndView modView;
		int ackValue = 0;
		
		UserDetailsVO userDetailsVO = WebAppUtil.mapToUserDetailsVO(enrollmentVO);
		PolicyDetailsVO policyDetails = WebAppUtil.mapToPolicyDetailsVO(enrollmentVO);
		AgreeDetailsVO agreeDetailsVO = WebAppUtil.mapToAgreeDetailsVO(enrollmentVO);
		AttestationDetailsVO attestationDetailsVO = WebAppUtil.mapToAttestationDetailsVO(enrollmentVO);
		
		request.getSession().setAttribute("userDetailsVO", userDetailsVO);
		request.getSession().setAttribute("policyDetails",policyDetails);
		request.getSession().setAttribute("agreeDetailsVO", agreeDetailsVO);
		request.getSession().setAttribute("attestationDetailsVO", attestationDetailsVO);
		request.getSession().setAttribute("enrollmentVO", enrollmentVO);
		
		int sequenceNumber = userDetailsService.getSequenecNumberNew(customerId);
		int result = userDetailsService.updateSeedId(customerId, sequenceNumber);			
		
		//Begin: 2019 web app changes - IFOX-00406768
		int planYear = Integer.parseInt((String) request.getSession().getAttribute("planYear"));
		LOGGER.info(" SharpController : saveDetails [" + planYear + "] ");
		enrollmentVO.setPlanYear(String.valueOf(planYear));
		request.getSession().setAttribute("WebAppConfirmationNumber", String.valueOf(sequenceNumber));

		byte[] pdfSave;
		String planName = (String) request.getSession().getAttribute("planName");
		String fullPlanName = "";
		
		//Begin: Modified for IFOX-00414491
		if(planYear > 2018) {
			if( planYear == 2020 && "SDAHMO1".equalsIgnoreCase(planName) )
				pdfSave = SharpPdfGen2020.saveBytesPDF(request, response);
			else
				pdfSave = SharpPdfGen2019.saveBytesPDF(request, response);
		} else {
			pdfSave = SharpPdfGen.saveBytesPDF(request, response);
		}
		//End: Modified for IFOX-00414491

		request.getSession().setAttribute("pdfSaveenrollGen", pdfSave);
		String lastName = userDetailsVO.getLastName();
		String firstName = userDetailsVO.getFirstName();
		DateFormat format = new SimpleDateFormat("yyyy_MM_dd_hh_mm_ss");
		String timeStamp = format.format(new Date());
		//int sequenceNumber = userDetailsService.getSequenecNumber();
	
		if("SAB".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Advantage Basic";
		}else if("SAP".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Advantage Premium";
		}else if("SDAB".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Direct Advantage Basic";
		}else if("SDABWD".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Direct Advantage Basic with Dental";
		}else if("SDAP".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Direct Advantage Premium";
		}else if("SDAPWD".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Direct Advantage Premium with Dental";
		}else if("SAS".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Advantage Select";
		}else if("SASP".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Advantage Select Plus";
		}else if("SDAGC".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Direct Advantage Gold Card";
		}else if("SDAGCWD".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Direct Advantage Gold Card with Dental";
		}else if("SDAPC".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Direct Advantage Platinum Card with Dental";
		}else if("SAMEA".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Advantage MEA";
		}else if("SDAMEA".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Direct Advantage MEA";
		}/**IFOX-00403984 Changes Start.*/
		else if("SDAHMO".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Direct Advantage HMO";
		}/**IFOX-00403984 Changes Stop.*/
		
		//Begin: Modified for IFOX-00414491
		else if("SDAHMO1".equalsIgnoreCase(planName)){
			fullPlanName = "Sharp Direct Advantage HMO";
		}
		//End: Modified for IFOX-00414491
		
		else{
			fullPlanName = "health";
		}		

		LOGGER.info("SEQUENCE NUMBER FOR MOBILE : "+sequenceNumber);
		ackValue = userDetailsService.saveUserDetails(WebAppUtil.getUserDetailsObject(request, response, sequenceNumber));
		
		userDetailsService.addUserApplicationNumber(customerId, emailId, ackValue);
		
		request.getSession().setAttribute("confirmationNumber", String.valueOf(ackValue));
		Properties prop = new Properties();
		try {
			prop.load(SharpController.class.getClassLoader().getResourceAsStream("saveLocation.properties"));
			String path = prop.getProperty("locationpath.pdfSave");
			File file = new File(path);

			if (!file.exists()) {
				file.mkdirs();
			}
			//String pdfName = path + ackValue + lastName + timeStamp + ".pdf";
			String pdfName = path + SHARPConstants.SHARPPDFPREFIX + ackValue + lastName + timeStamp + ".pdf";
			
			String htmlMsg = "<html>"
			+ "<img src=\"cid:0001\" style=\"width: 100px;\">"
			+ "<br>"
			+ "<div style=\"font-family: calibri; width: 75%; font-size: 12pt;\">"
			+ "<p>Dear " + firstName + " " + lastName + ",</p>"
			+ "<p>Thank you for choosing Sharp Health Plan!</p>"
			+ "<p>This email is to confirm that we've received your application for our " + fullPlanName
			+ " plan. For your records, your confirmation number is " + ackValue
			+ ", and a copy of your application is attached. </p>"
			+ "<p>Please allow up to 10 business days for your application to be processed, and for you to receive your new Member ID card "
			+ "and Welcome Kit, both of which will be mailed separately. </p>"
			+ "<p>If you have any questions regarding your enrollment status or benefits, please contact Customer Care "
			+ "toll-free at 1-855-562-8853 (TTY/TDD users should call 711). For your convenience, our hours of operation are: " //Fix for IFOX-00406768 Start
			+ "Oct. 1 - Mar. 31 from 8 a.m. to 8 p.m. Pacific Time, 7 days a week; Apr. 1 - Sept. 30 from 8 a.m. to 8 p.m. " //Fix for IFOX-00406768 End
			+ "Pacific Time, Monday through Friday. On weekends and holidays, your call will be handled by our voicemail system "
			+ "and a Customer Care Representative will return your phone call the next business day.</p>"
			+ "<p>Warm regards,</p>"
			+ "<img src=\"cid:0002\" style=\"width: 150px;\">"
			+ "<p>Leslie Pels-Beck<br>"
			+ "Vice President, Customer Care</p>"
			+ "</div>"
			+ "</html>";
			
			LOGGER.info(" pdfSave PATH : " + path);
			LOGGER.info(" pdfName      : " + pdfName);
			LOGGER.info(" ackValue      : " + pdfName);
			LOGGER.info(" lastName      : " + lastName);
			LOGGER.info(" timeStamp      : " + timeStamp);
			byte[] ps = Base64.decodeBase64(pdfSave);
		 	FileOutputStream fos = new FileOutputStream(pdfName);
		    fos.write(ps);
			fos.close();
			JschSftpUploader.uploadToFTP(customerId, pdfName);
			String[] emailToList = new String[] {emailId};
			
			//EmailUtil emailUtil = new EmailUtil(emailToList);
			EmailUtil emailUtil = new EmailUtil(emailToList, null); //Added for IFOX-00405531
			
			ArrayList<String> filesList = new ArrayList<String>();
			filesList.add(pdfName);
			LOGGER.info(" *********Before Sending Email In Individual************** ");
			//emailUtil.sendEmailAttachment("Enrollment Confirmation Message", " Hi " + lastName + ", \n\n Your enrollment is successfull and please find the attached PDF document for your future reference. \n\n Thanks, \n Enrollment Support Team.", filesList, emailUtil.TEXT_PLAIN);
			emailUtil.sendHtmlEmailAttachment("Your Sharp Direct Advantage Application has Been Received", htmlMsg, filesList, emailUtil.TEXT_HTML, request);
			LOGGER.info(" *********After Sending Email In Individual************** ");
			
			EnrollmentVO existingSession = WebAppUtil.getSessionObject(customerId, planId, emailId);
			if(existingSession != null){
				LOGGER.info("*******Before deleting session object");
				WebAppUtil.removeSessionObject(customerId, planId, emailId);
				LOGGER.info("*******After deleting session object");
			}else{
				LOGGER.info("*******Session does not exist !!");
			}
			
		} catch (IOException exp) {
			LOGGER.error(" SharpController : saveEnrollForm8IOException : " + exp);
		}
		//modView = new ModelAndView("Sharp/individual/enrollment9_2017","ackValue", ackValue);
		catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		//String planName = (String) request.getSession().getAttribute("planName");
		
		if("SAB".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/group/" + planYear + "/enrollmentConfirmationSABMobile" : "Sharp/group/enrollmentConfirmationSABMobile");
		}else if("SAP".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/group/" + planYear + "/enrollmentConfirmationSAPMobile" : "Sharp/group/enrollmentConfirmationSAPMobile");
		}else if("SDAB".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/group/" + planYear + "/enrollmentConfirmationSDABMobile" : "Sharp/group/enrollmentConfirmationSDABMobile");
		}else if("SDABWD".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/group/" + planYear + "/enrollmentConfirmationSDABWDMobile" : "Sharp/group/enrollmentConfirmationSDABWDMobile");
		}else if("SDAP".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/group/" + planYear + "/enrollmentConfirmationSDAPMobile" : "Sharp/group/enrollmentConfirmationSDAPMobile");
		}else if("SDAPWD".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/group/" + planYear + "/enrollmentConfirmationSDAPWDMobile" : "Sharp/group/enrollmentConfirmationSDAPWDMobile");
		}else if("SAS".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/individual/" + planYear + "/enrollmentConfirmationSASMobile" : "Sharp/individual/enrollmentConfirmationSASMobile");
		}else if("SASP".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/individual/" + planYear + "/enrollmentConfirmationSASPMobile" : "Sharp/individual/enrollmentConfirmationSASPMobile");
		}else if("SDAGC".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/individual/" + planYear + "/enrollmentConfirmationSDAGCMobile" : "Sharp/individual/enrollmentConfirmationSDAGCMobile");
		}else if("SDAGCWD".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/individual/" + planYear + "/enrollmentConfirmationSDAGCWDMobile" : "Sharp/individual/enrollmentConfirmationSDAGCWDMobile");
		}else if("SDAPC".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/individual/" + planYear + "/enrollmentConfirmationSDAPCMobile" : "Sharp/individual/enrollmentConfirmationSDAPCMobile");
		}else if("SAMEA".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/mea/" + planYear + "/enrollmentConfirmationSAMEAMobile" : "Sharp/mea/enrollmentConfirmationSAMEAMobile");
		}else if("SDAMEA".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/mea/" + planYear + "/enrollmentConfirmationSDAMEAMobile" : "Sharp/mea/enrollmentConfirmationSDAMEAMobile");
		}/**IFOX-00403984 Changes Start.*/
		
		//Begin: Modified for IFOX-00414491
		else if("SDAHMO1".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/mea/" + planYear + "/enrollmentConfirmationSDAHMOMobile1" : "Sharp/mea/enrollmentConfirmationSDAHMOMobile1");
		}
		//End: Modified for IFOX-00414491
		
		else if("SDAHMO".equalsIgnoreCase(planName)){
			modView = new ModelAndView(planYear > 2018 ? "Sharp/mea/" + planYear + "/enrollmentConfirmationSDAHMOMobile" : "Sharp/mea/enrollmentConfirmationSDAHMOMobile");
		}/**IFOX-00403984 Changes Stop.*/else{
			return null;
		}		
		
		//return new ModelAndView("Sharp/individual/enrollmentConfirmation");
		return modView;
	}		


	
	@RequestMapping(value = "/mea/Confirmation", method = RequestMethod.POST)
	public ModelAndView saveDetailsForMEA(HttpServletRequest request, HttpServletResponse response, @ModelAttribute("enrollmentVO") EnrollmentVO enrollmentVO) {

		String customerId = (String) request.getSession().getAttribute("customerId"); // this id will be used to save the details into system
		String emailId = (String) request.getSession().getAttribute("emailId"); // this id will be used to save the details into system
	
		ModelAndView modView;
		int ackValue = 0;
		
		UserDetailsVO userDetailsVO = WebAppUtil.mapToUserDetailsVO(enrollmentVO);
		PolicyDetailsVO policyDetails = WebAppUtil.mapToPolicyDetailsVO(enrollmentVO);
		AgreeDetailsVO agreeDetailsVO = WebAppUtil.mapToAgreeDetailsVO(enrollmentVO);
		AttestationDetailsVO attestationDetailsVO = WebAppUtil.mapToAttestationDetailsVO(enrollmentVO);
		
		request.getSession().setAttribute("userDetailsVO", userDetailsVO);
		request.getSession().setAttribute("policyDetails",policyDetails);
		request.getSession().setAttribute("agreeDetailsVO", agreeDetailsVO);
		request.getSession().setAttribute("attestationDetailsVO", attestationDetailsVO);		
		request.getSession().setAttribute("enrollmentVO", enrollmentVO);

		byte[] pdfSave;

		int planYear = Integer.parseInt((String) request.getSession().getAttribute("planYear"));
		LOGGER.info(" SharpController : saveDetailsForGroup [" + planYear + "] ");

		if(planYear > 2018)
			pdfSave = SharpPdfGen2019.saveBytesPDF(request, response);
		else
			pdfSave = SharpPdfGen.saveBytesPDF(request, response);
		
		request.getSession().setAttribute("pdfSaveenrollGen", pdfSave);
		String lastName = userDetailsVO.getLastName();
		DateFormat format = new SimpleDateFormat("yyyy_MM_dd_hh_mm_ss");
		String timeStamp = format.format(new Date());
		//int sequenceNumber = userDetailsService.getSequenecNumber();
		int sequenceNumber = userDetailsService.getSequenecNumberNew(customerId);
		int result = userDetailsService.updateSeedId(customerId, sequenceNumber);			
		LOGGER.info("SEQUENCE NUMBER : "+sequenceNumber);
		ackValue = userDetailsService.saveUserDetails(WebAppUtil.getUserDetailsObject(request, response, sequenceNumber));
		request.getSession().setAttribute("confirmationNumber", String.valueOf(ackValue));
		Properties prop = new Properties();
		try {
			prop.load(SharpController.class.getClassLoader().getResourceAsStream("saveLocation.properties"));
			String path = prop.getProperty("locationpath.pdfSave");
			File file = new File(path);

			if (!file.exists()) {
				file.mkdirs();
			}
			//String pdfName = path + ackValue + lastName + timeStamp + ".pdf";
			String pdfName = path + SHARPConstants.SHARPPDFPREFIX + ackValue + lastName + timeStamp + ".pdf";
					
			
			LOGGER.info(" pdfSave PATH : " + path);
			LOGGER.info(" pdfName      : " + pdfName);
			LOGGER.info(" ackValue      : " + pdfName);
			LOGGER.info(" lastName      : " + lastName);
			LOGGER.info(" timeStamp      : " + timeStamp);
			byte[] ps = Base64.decodeBase64(pdfSave);
		 	FileOutputStream fos = new FileOutputStream(pdfName);
		    fos.write(ps);
			fos.close();
			JschSftpUploader.uploadToFTP(customerId, pdfName);
			String[] emailToList = new String[] {emailId};
			
			//EmailUtil emailUtil = new EmailUtil(emailToList);
			EmailUtil emailUtil = new EmailUtil(emailToList, null); //Added for IFOX-00405531
			
			ArrayList<String> filesList = new ArrayList<String>();
			filesList.add(pdfName);
			LOGGER.info(" *********Before Sending Email In Individual************** ");
			emailUtil.sendEmailAttachment("Enrollment Confirmation Message", " Hi " + lastName + ", \n\n Your enrollment is successfull and please find the attached PDF document for your future reference. \n\n Thanks, \n Enrollment Support Team.", filesList, emailUtil.TEXT_PLAIN);
			LOGGER.info(" *********After Sending Email In Individual************** ");			
			
			
		} catch (IOException exp) {
			LOGGER.error(" SharpController : saveEnrollForm8IOException : " + exp);
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String planName = (String) request.getSession().getAttribute("planName");
		
		if("SAMEA".equalsIgnoreCase(planName)){
			modView = new ModelAndView("Sharp/mea/enrollmentConfirmationSAMEA");
		}else if("SDAMEA".equalsIgnoreCase(planName)){
			modView = new ModelAndView("Sharp/mea/enrollmentConfirmationSDAMEA");
		}else{
			return null;
		}				
		
		//return new ModelAndView("Sharp/mea/enrollmentConfirmation");
		return modView;
				
	}		

	
	@RequestMapping(value = "Individual/Download", method = RequestMethod.POST)
	public ModelAndView downloadEnrolledForm(HttpServletRequest request, HttpServletResponse response) {
		try {
			LOGGER.info("*****Before Downloading*******");
			
			int planYear = Integer.parseInt((String) request.getSession().getAttribute("planYear"));
			LOGGER.info("SahrpController : downloadEnrolledForm : planYear [" + planYear + "] ");

			//Begin: Modified for IFOX-00414491
			String planName = (String) request.getSession().getAttribute("planName");
			if(planYear > 2018) {
				//if( planYear == 2020 && "SDAHMO1".equalsIgnoreCase(planName))
				if( planYear == 2020) //Fix for IFOX-00420776
					SharpPdfGen2020.showEnrollFromsInPDF(request, response);
				else
					SharpPdfGen2019.showEnrollFromsInPDF(request, response);
			} else {
				SharpPdfGen.showEnrollFromsInPDF(request, response);
			}
			//End: Modified for IFOX-00414491

			LOGGER.info("*****After Downloading*******");
		} catch (Exception e) {
			LOGGER.error(" error : In printEnrollFormsGen() method of SharpController class");
		}
		return null;

	}	
	
	
	@RequestMapping(value = "mea/Download", method = RequestMethod.POST)
	public ModelAndView downloadEnrolledFormForMEA(HttpServletRequest request, HttpServletResponse response) {
		try {
			LOGGER.info("*****Before Downloading*******");
			
			int planYear = Integer.parseInt((String) request.getSession().getAttribute("planYear"));
			LOGGER.info("SharpController : downloadEnrolledFormForMEA : planYear [" + planYear + "] ");
			
			if(planYear > 2018)
				SharpPdfGen2019.showEnrollFromsInPDF(request, response);
			else
				SharpPdfGen.showEnrollFromsInPDF(request, response);
			
			LOGGER.info("*****After Downloading*******");
		} catch (Exception e) {
			LOGGER.error(" error : In printEnrollFormsGen() method of SharpController class");
		}
		return null;

	}	

	
	
	@RequestMapping(value = "group/Download", method = RequestMethod.POST)
	public ModelAndView downloadEnrolledFormForGroup(HttpServletRequest request, HttpServletResponse response) {
		try {
			LOGGER.info("*****Before Downloading*******");
			
			int planYear = Integer.parseInt((String) request.getSession().getAttribute("planYear"));
			LOGGER.info("SahrpController : downloadEnrolledFormForGroup : planYear [" + planYear + "] ");

			if(planYear > 2018)
				SharpPdfGen2019.showEnrollFromsInPDF(request, response);
			else
				SharpPdfGen.showEnrollFromsInPDF(request, response);
			
			LOGGER.info("*****After Downloading*******");
		} catch (Exception e) {
			LOGGER.error(" error : In printEnrollFormsGen() method of SharpController class");
		}
		return null;

	}		
	
	@RequestMapping(value = "/saveSharpEnrollForm1", method = RequestMethod.POST)
	public ModelAndView saveEnrollForm1(HttpServletRequest request,
			@ModelAttribute("userDetailsVO") UserDetailsVO userDetailsVO) {
		request.getSession().setAttribute("userDetailsVO", userDetailsVO);
		ModelAndView modView;
		modView = new ModelAndView("Sharp/individual/successEnrollForm1");
		return modView;
	}

	@RequestMapping(value = "/nextEnrollForm2", method = RequestMethod.GET)
	public ModelAndView nextEnrollForm2(HttpServletRequest request,
			@ModelAttribute("policyDetails1") PolicyDetailsVO policyVo) {
		if(null != request.getSession().getAttribute("policyDetails1")){
			policyVo = (PolicyDetailsVO)request.getSession().getAttribute("policyDetails1");
		}
		return  new ModelAndView("Sharp/individual/enrollment2_2017", "policyDetails1", policyVo);
	}

	
	
	@RequestMapping(value = "/saveSharpEnrollForm2", method = RequestMethod.POST)
	public ModelAndView saveEnrollForm2(HttpServletRequest request,
			@ModelAttribute("policyDetails1") PolicyDetailsVO policyDetailsVO, BindingResult result) {
		ModelAndView modView;
		request.getSession().setAttribute("policyDetails1", policyDetailsVO);
		modView = new ModelAndView("Sharp/individual/successEnrollForm2", "", policyDetailsVO);
		return modView;
	}

	@RequestMapping(value = "/nextEnrollForm3", method = RequestMethod.GET)
	public ModelAndView nextEnrollForm3(HttpServletRequest request,@ModelAttribute("policyDetails2") PolicyDetailsVO policyDetailsVO) {
		if(null != request.getSession().getAttribute("policyDetails2")){
			policyDetailsVO = (PolicyDetailsVO)request.getSession().getAttribute("policyDetails2");
		}
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		Map populatedMap = userDetailsService.getPrePopulatedValuesFromDB(customer_id);
		Map physicanMapDB = (Map) populatedMap.get("physicianMap");
		mapModel.put("physicians", physicanMapDB);
		String pipeSepString = userDetailsService.getPipeSepString(physicanMapDB);;
		LOGGER.info(pipeSepString);
		mapModel.put("physiciansPipeString", pipeSepString);
		mapModel.put("policyDetails2", policyDetailsVO);
		request.getSession().setAttribute("physicianMap", physicanMapDB);
		
		return  new ModelAndView("Sharp/individual/enrollment3_2017", mapModel );
	}
	
	
	@RequestMapping(value = "/saveSharpEnrollForm3", method = RequestMethod.POST)
	public ModelAndView saveEnrollForm3(HttpServletRequest request,
			@ModelAttribute("policyDetails2") PolicyDetailsVO policyDetailsVO) {
		request.getSession().setAttribute("policyDetails2", policyDetailsVO);
		ModelAndView modView;
		modView = new ModelAndView("Sharp/individual/successEnrollForm3");
		return modView;
	}

	@RequestMapping(value = "/nextEnrollForm4", method = RequestMethod.GET)
	public ModelAndView nextEnrollForm4(HttpServletRequest request,
			@ModelAttribute("attestationDetailsVO") AttestationDetailsVO attestVo) {
		if(null != request.getSession().getAttribute("attestationDetailsVO")){
			attestVo = (AttestationDetailsVO)request.getSession().getAttribute("attestationDetailsVO");
		}
		 return  new ModelAndView("Sharp/individual/enrollment4_2017", "attestationDetailsVO", attestVo);
	}
	
	
	@RequestMapping(value = "/saveSharpEnrollForm4", method = RequestMethod.POST)
	public ModelAndView saveEnrollForm4(HttpServletRequest request,
			@ModelAttribute("attestationDetailsVO") AttestationDetailsVO attestVo) {
		request.getSession().setAttribute("attestationDetailsVO", attestVo);
		ModelAndView modView;
		modView = new ModelAndView("Sharp/individual/successEnrollForm4");
		return modView;
	}

	@RequestMapping(value = "/nextEnrollForm5", method = RequestMethod.GET)
	public ModelAndView nextEnrollForm5(HttpServletRequest request,
			@ModelAttribute("agreeDetailsVO") AgreeDetailsVO  agreeDetailsVO) {
		if(null != request.getSession().getAttribute("agreeDetailsVO")){
			agreeDetailsVO = (AgreeDetailsVO)request.getSession().getAttribute("agreeDetailsVO");
		}
		 return  new ModelAndView("Sharp/individual/enrollment5_2017", "agreementVO", agreeDetailsVO);
	}
	
	
	@RequestMapping(value = "/saveSharpEnrollForm5", method = RequestMethod.POST)
	public ModelAndView saveEnrollForm5(HttpServletRequest request,
			@ModelAttribute("agreeDetailsVO") AgreeDetailsVO agreeDetailsVO) {
		request.getSession().setAttribute("agreeDetailsVO", agreeDetailsVO);
		ModelAndView modView;
		modView = new ModelAndView("Sharp/individual/successEnrollForm5");
		return modView;
	}

	@RequestMapping(value = "/nextEnrollForm6", method = RequestMethod.GET)
	public ModelAndView nextEnrollForm6(HttpServletRequest request) {
		ModelAndView modView;
		modView = new ModelAndView("Sharp/individual/enrollment6_2017");
		return modView;
	}
	
	@RequestMapping(value = "/saveSharpEnrollForm6", method = RequestMethod.POST)
	public ModelAndView saveEnrollForm6(HttpServletRequest request) {
		ModelAndView modView;
		modView = new ModelAndView("Sharp/individual/successEnrollForm6");
		return modView;
	}

	@RequestMapping(value = "/nextEnrollForm7", method = RequestMethod.GET)
	public ModelAndView nextEnrollForm7(HttpServletRequest request) {
		ModelAndView modView;
		modView = new ModelAndView("Sharp/individual/enrollment7_2017");
		return modView;
	}
	
	@RequestMapping(value = "/saveSharpEnrollForm7", method = RequestMethod.POST)
	public ModelAndView saveEnrollForm7(HttpServletRequest request) {
		ModelAndView modView;
		modView = new ModelAndView("Sharp/individual/successEnrollForm7");
		return modView;
	}

	@RequestMapping(value = "/nextEnrollForm8", method = RequestMethod.GET)
	public ModelAndView nextEnrollForm8(HttpServletRequest request) {
		ModelAndView modView;
		modView = new ModelAndView("Sharp/individual/enrollment8_2017");
		return modView;

	}
	
	
	
	private void copyFormToForm(PolicyDetailsVO form2, PolicyDetailsVO form3) {
		form3.setPaymentOption(form2.getPaymentOption());
		form3.setAccountHolderName(form2.getAccountHolderName());//(form2.getPaymentOption());
		form3.setBankName(form2.getBankName());
		form3.setAcctype(form2.getAcctype());
		form3.setBankAccountNumber(form2.getBankAccountNumber());
		form3.setBankRoutingNumber(form2.getBankRoutingNumber());
	}



/*	@RequestMapping(value = "/nextEnrollForm9", method = RequestMethod.GET)
	public ModelAndView nextEnrollForm9() {
		return new ModelAndView("Sharp/individual/enrollment9_2017");

	}*/
	

	@RequestMapping(value = "/previousSharpForm7", method = RequestMethod.POST)
	public ModelAndView previousForm7(HttpServletRequest request) {
		return new ModelAndView("Sharp/individual/enrollment7_2017");
	
	}
	
	@RequestMapping(value = "/previousSharpForm6", method = RequestMethod.POST)
	public ModelAndView previousForm6(HttpServletRequest request) {
		return new ModelAndView("Sharp/individual/enrollment6_2017");
	}
	
	@RequestMapping(value = "/previousSharpForm5", method = RequestMethod.POST)
	public ModelAndView previousForm5(HttpServletRequest request) {
		ModelAndView modView;
		if (null ==request.getSession().getAttribute("agreeDetailsVO")) {
			 modView = new ModelAndView("Sharp/individual/error.jsp");
			return modView;
		}
		
		AgreeDetailsVO agreeDetailsVO = (AgreeDetailsVO) request.getSession().getAttribute("agreeDetailsVO");
		modView = new ModelAndView("Sharp/individual/enrollment5_2017","agreeDetailsVO", agreeDetailsVO);
		return modView;

	}
	
	
	@RequestMapping(value = "/previousSharpForm4", method = RequestMethod.POST)
	public ModelAndView previousForm4(HttpServletRequest request) {
		ModelAndView modView;
		if (null == request.getSession().getAttribute("attestationDetailsVO")) {
			 modView = new ModelAndView("Sharp/individual/error.jsp");
			return modView;
		}
		
		AttestationDetailsVO attestVo = (AttestationDetailsVO) request.getSession().getAttribute("attestationDetailsVO");
		modView = new ModelAndView("Sharp/individual/enrollment4_2017","attestationDetailsVO", attestVo);
		return modView;

	}
	
	
	@RequestMapping(value = "/previousSharpForm3", method = RequestMethod.POST)
	public ModelAndView previousForm3(HttpServletRequest request) {
		ModelAndView modView;
		if (null == request.getSession().getAttribute("policyDetails2")) {
			 modView = new ModelAndView("Sharp/individual/error.jsp");
			return modView;
		}
		
		PolicyDetailsVO policyDetailsVO = (PolicyDetailsVO) request.getSession().getAttribute("policyDetails2");
		modView = new ModelAndView("Sharp/individual/enrollment3_2017","policyDetails2", policyDetailsVO);
		return modView;

	}
	
	@RequestMapping(value = "/previousSharpForm2", method = RequestMethod.POST)
	public ModelAndView previousForm2(HttpServletRequest request) {
		ModelAndView modView;
		if (null == request.getSession().getAttribute("policyDetails1")) {
			 modView = new ModelAndView("Sharp/individual/error.jsp");
			return modView;
		}
		
		PolicyDetailsVO policyDetailsVO = (PolicyDetailsVO) request.getSession().getAttribute("policyDetails1");
		modView = new ModelAndView("Sharp/individual/enrollment2_2017","policyDetails1", policyDetailsVO);
		return modView;

	}
	
	@RequestMapping(value = "/previousSharpForm1", method = RequestMethod.POST)
	public ModelAndView previousForm1(HttpServletRequest request) {
		ModelAndView modView;
		if (null == request.getSession().getAttribute("userDetailsVO")) {
			 modView = new ModelAndView("Sharp/individual/error.jsp");
			return modView;
		}
		UserDetailsVO userDetailsVO = (UserDetailsVO) request.getSession().getAttribute("userDetailsVO");
		modView = new ModelAndView("Sharp/individual/enrollment1_2017","userDetailsVO", userDetailsVO);
		return modView;

	}
	
	
	@RequestMapping(value = "/printSharpEnrollForms", method = RequestMethod.POST)
	public ModelAndView printEnrollForms(HttpServletRequest request, HttpServletResponse response) {
		try {
			PolicyDetailsVO form2 = (PolicyDetailsVO) request.getSession().getAttribute("policyDetails1");
			PolicyDetailsVO form3 = (PolicyDetailsVO) request.getSession().getAttribute("policyDetails2");
			
			copyFormToForm(form2,form3);
			request.getSession().setAttribute("policyDetails",form3);

			int planYear = Integer.parseInt((String) request.getSession().getAttribute("planYear"));
			LOGGER.info("SahrpController : printEnrollForms : planYear [" + planYear + "] ");

			if(planYear > 2018)
				SharpPdfGen2019.showEnrollFromsInPDF(request, response);
			else
				SharpPdfGen.showEnrollFromsInPDF(request, response);
			
		} catch (Exception e) {
			LOGGER.error(" error : In printEnrollFormsGen() method of SharpController class");
		}
		return null;

	}
	@RequestMapping(value = "/Individual/clinicName", method = RequestMethod.GET, produces="text/plain")
	@ResponseBody
	public void getClinicName(HttpServletRequest request, HttpServletResponse response) throws IOException {
		System.out.println(request.getParameter("ofcCde"));
		DateFormat format = new SimpleDateFormat("yyyyMMdd");
		String timeStamp = format.format(new Date());
		String ofcCode = request.getParameter("ofcCde");
		System.out.println("customerId = "+customer_id+", ofcCode = "+ofcCode+", reqDtCov"+timeStamp);
		
		String clinicName = userDetailsService.getClinicName(customer_id, ofcCode, timeStamp);
		
		if(!StringUtil.nonNullnonEmpty(clinicName))
			clinicName = "No Clinic Name Mapped";
		
		response.getWriter().println(clinicName);
		//return "{'clinicName':'"+clinicName+"'}";
	}

    private static String nonNullTrim(String s) {
        if (s == null)
            return "";
        return s.trim();
    }
	
        
}
