package com.medicare.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.net.util.Base64;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.medicare.helper.MedicareUtil;
import com.medicare.service.IUserDetailsService;
import com.medicare.service.UserDetailsServiceImpl;
import com.medicare.util.PDFUtilGen;
import com.medicare.util.WebAppUtil;
import com.medicare.vo.AgreeDetailsVO;
import com.medicare.vo.AttestationDetailsVO;
import com.medicare.vo.PolicyDetailsVO;
import com.medicare.vo.UserDetailsVO;

@Controller
public class SummaController {

	private final static Logger LOGGER = Logger.getLogger(SummaController.class.getName());

	private IUserDetailsService userDetailsService;
	@Autowired
	public void setUserDetailsService(IUserDetailsService userDetailsService) {
		this.userDetailsService = userDetailsService;
	}

	@RequestMapping(value = "/Summacare")
	public ModelAndView previousForm6() {
		return new ModelAndView("Sumcare/index");
	}
	
	String customer_id = "HCF0027";

	@RequestMapping(value = "/showEnrollFormGen1", method = RequestMethod.GET)
	public ModelAndView showEnrollForm1(HttpServletRequest request,
			@ModelAttribute("userDetailsVO") UserDetailsVO userDetailsVO) {
		ModelAndView modView;
      System.out.println("userDetailsService : "+userDetailsService);
		String county = request.getParameter("County");
		String plan = request.getParameter("SummacarePlan");
		if (county == null || county.trim().equalsIgnoreCase("")) {
			System.out.println("county" + county);
			modView = new ModelAndView("Sumcare/test");
			return modView;

		}
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		Map<String, String> plans = userDetailsService.getAvailablePlansForCounty(county);
		Map<String, String> PlansLinkedHashMap = new LinkedHashMap<String, String>();

		if (plans.get("TOPAZ") != null) {
			PlansLinkedHashMap.put("TOPAZ", plans.get("TOPAZ"));
		}
		if (plans.get("RUBY") != null) {
			PlansLinkedHashMap.put("RUBY", plans.get("RUBY"));
		}
		if (plans.get("SAPPHIRE") != null) {
			PlansLinkedHashMap.put("SAPPHIRE", plans.get("SAPPHIRE"));
		}
		if (plans.get("EMERALD") != null) {
			PlansLinkedHashMap.put("EMERALD", plans.get("EMERALD"));
		}
		mapModel.put("availablePlans", PlansLinkedHashMap);

		userDetailsVO.setOptimaMedicare(plans.get(plan.toUpperCase()));
		/*
		 * if(plan.equalsIgnoreCase("TOPAZ")){
		 * userDetailsVO.setOptimaMedicare("T"); }
		 * 
		 * if(plan.equalsIgnoreCase("RUBY")){
		 * userDetailsVO.setOptimaMedicare("R"); }
		 * 
		 * if(plan.equalsIgnoreCase("SAPPHIRE")){
		 * userDetailsVO.setOptimaMedicare("S"); }
		 * 
		 * if(plan.equalsIgnoreCase("EMERALD")){
		 * userDetailsVO.setOptimaMedicare("E"); }
		 */

		// userDetailsVO.setPermanentCity("Alexandria");

		if (plan == null) {
			plan = "";
		}

		Map populatedMap = userDetailsService.getPrePopulatedValuesFromDB(customer_id);

		Map physicanMapDB = (Map) populatedMap.get("physicianMap");

		Map<String, String> relationEnrolle = MedicareUtil.getRelationEnrollValues();

		mapModel.put("physicians", physicanMapDB);
		mapModel.put("relations", relationEnrolle);

		request.getSession().setAttribute("physicianMap", physicanMapDB);
		request.getSession().setAttribute("relationsMap", relationEnrolle);
		request.getSession().setAttribute("county", county);
		request.getSession().setAttribute("plan", plan);

		userDetailsVO.setCustomerId(customer_id);
		userDetailsVO.setPermanentCounty(county);

		mapModel.put("userDetailsVO", userDetailsVO);
		request.getSession().setAttribute("customerId", userDetailsVO.getCustomerId());
		modView = new ModelAndView("Sumcare/enrollmentForm1", mapModel);

		return modView;
	}

	@RequestMapping(value = "/saveEnrollFormGen1", method = RequestMethod.POST)
	public ModelAndView saveEnrollForm1(HttpServletRequest request,
			@ModelAttribute("userDetailsVO") UserDetailsVO userDetailsVO) {
		request.getSession().setAttribute("userDetailsVO", userDetailsVO);
		ModelAndView modView;
		boolean flag = false;
		Map<String, Boolean> cityStateMap = null;
		// as per nataraj we dont need to validate this state code we just need
		// to capture what ever user enters and put into file m360 will take
		// care
		/*
		 * if(!flag){
		 * 
		 * cityStateMap = userDetailsService
		 * .validateStateAndCityValuesFromDB(userDetailsVO); flag=true; }
		 */
		Map physicanMapDB = (Map) request.getSession().getAttribute("physicianMap");
		Map relationsMap = (Map) request.getSession().getAttribute("relationsMap");
		HashMap<String, Object> mapModel = new HashMap<String, Object>();

		mapModel.put("physicians", physicanMapDB);
		mapModel.put("relations", relationsMap);

		// as per nataraj we dont need to validate this state code we just need
		// to capture what ever user enters and put into file m360 will take
		// care
		/*
		 * if (cityStateMap == null || cityStateMap.isEmpty()) {
		 * mapModel.put("physicians", physicanMapDB); mapModel.put("relations",
		 * relationsMap); mapModel.put("statErr",
		 * "Please enter valid permanent City,State,Zip Details"); modView = new
		 * ModelAndView("Sumcare/enrollmentForm1", mapModel); return modView; }
		 * 
		 * if (cityStateMap.get("PermState")) { mapModel.put("physicians",
		 * physicanMapDB); mapModel.put("relations", relationsMap);
		 * mapModel.put("statErr",
		 * "Please enter valid permanent City,State,Zip Details"); modView = new
		 * ModelAndView("Sumcare/enrollmentForm1", mapModel); return modView; }
		 * 
		 * if (cityStateMap.get("MailingState")) { mapModel.put("physicians",
		 * physicanMapDB); mapModel.put("relations", relationsMap);
		 * mapModel.put("mailERr",
		 * "Please enter valid permanent City,State,Zip Details"); modView = new
		 * ModelAndView("Sumcare/enrollmentForm1", mapModel); return modView; }
		 */

		modView = new ModelAndView("Sumcare/successEnrollForm1");
		return modView;
	}

	@RequestMapping(value = "/nextEnrollFormGen2", method = RequestMethod.GET)
	public ModelAndView nextEnrollForm1(HttpServletRequest request,
			@ModelAttribute("policyDetailsVO1") PolicyDetailsVO policyVo) {
		ModelAndView modView;
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
	//	Map populatedMap = userDetailsService.getPrePopulatedValuesFromDB(customer_id);

		Map physicanMapDB = (Map) request.getSession().getAttribute("physicianMap");
		mapModel.put("physicians", physicanMapDB);
		if (policyVo.getPhysician() != null) {
			policyVo.setPhysicianName((String) physicanMapDB.get(policyVo.getPhysician()));
		}
		request.getSession().setAttribute("physicianMap", physicanMapDB);
		mapModel.put("policyDetailsVO1", policyVo);
		modView = new ModelAndView("Sumcare/enrollmentForm2", mapModel);
		return modView;

	}

	@RequestMapping(value = "/saveEnrollFormGen2", method = RequestMethod.POST)
	public ModelAndView saveEnrollForm2(HttpServletRequest request,
			@ModelAttribute("policyDetailsVO1") PolicyDetailsVO policyDetailsVO, BindingResult result) {
		ModelAndView modView;
		request.getSession().setAttribute("policyDetailsVO1", policyDetailsVO);
		if (result.hasErrors()) {
			if (result.getFieldError("physician") != null) {
				policyDetailsVO.setErrorphysicianValue("physicianValue");
			}
			return previousEnrollForm2(request, policyDetailsVO);
		}
		modView = new ModelAndView("Sumcare/successEnrollForm2", "", policyDetailsVO);
		return modView;

	}

	@RequestMapping(value = "/nextEnrollFormGen3", method = RequestMethod.GET)
	public ModelAndView nextEnrollForm2(HttpServletRequest request,
			@ModelAttribute("agreeDetailsVO") AgreeDetailsVO agreeVO) {
		ModelAndView modView = new ModelAndView("Sumcare/enrollmentForm3", "", agreeVO);
		return modView;
	}

	@RequestMapping(value = "/saveEnrollFormGen3", method = RequestMethod.POST)
	public ModelAndView saveEnrollForm3(HttpServletRequest request,
			@ModelAttribute("agreeDetailsVO") AgreeDetailsVO ad) {

		request.getSession().setAttribute("agreeDetailsVO", ad);

		ModelAndView modView = new ModelAndView("Sumcare/successEnrollForm3", "", ad);
		return modView;
	}

	@RequestMapping(value = "/nextEnrollFormGen4", method = RequestMethod.GET)
	public ModelAndView nextEnrollForm3(HttpServletRequest request,
			@ModelAttribute("attestationDetailsVO") AttestationDetailsVO attestationDetailsVO) {
		ModelAndView modView = new ModelAndView("Sumcare/enrollmentForm4", "attestationDetailsVO",
				attestationDetailsVO);
		return modView;

	}

	@RequestMapping(value = "/saveEnrollFormGen4", method = RequestMethod.POST)
	public ModelAndView saveEnrollForm4(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("attestationDetailsVO") AttestationDetailsVO attestationDetailsVO) {

		int ackValue = 0;
		PolicyDetailsVO detailsVO1 = (PolicyDetailsVO) request.getSession().getAttribute("policyDetailsVO1");

		request.getSession().setAttribute("policyDetails", detailsVO1);
		UserDetailsVO userDetailsVO = (UserDetailsVO) request.getSession().getAttribute("userDetailsVO");

		AgreeDetailsVO agreeDetailsVO = (AgreeDetailsVO) request.getSession().getAttribute("agreeDetailsVO");
		/*agreeDetailsVO.setIcepDate(userDetailsVO.getBirthDate());*/

		LOGGER.info(" Start : In saveEnrollForm4() method of UserDetailsController class");
		request.getSession().setAttribute("attestationDetailsVO", attestationDetailsVO);
		byte[] pdfSave;
		pdfSave = PDFUtilGen.saveBytesPDF(request, response);
		request.getSession().setAttribute("pdfSaveenrollGen", pdfSave);
		String lastName = userDetailsVO.getLastName();
		DateFormat format = new SimpleDateFormat("yyyy_MM_dd_hh_mm_ss");
		String timeStamp = format.format(new Date());
		//ackValue = userDetailsService.saveUserDetails(WebAppUtil.getUserDetailsObject(request, response));
		Properties prop = new Properties();
		try {
			prop.load(SummaController.class.getClassLoader().getResourceAsStream("saveLocation.properties"));
			String path = prop.getProperty("locationpath.pdfSave");
			File file = new File(path);

			if (!file.exists()) {
				file.mkdirs();
			}
			String pdfName = path + ackValue + lastName + timeStamp + ".pdf";
			LOGGER.info(" pdfSave PATH : " + path);
			LOGGER.info(" pdfName      : " + pdfName);
			LOGGER.info(" ackValue      : " + pdfName);
			LOGGER.info(" lastName      : " + lastName);
			LOGGER.info(" timeStamp      : " + timeStamp);
			byte[] ps = Base64.decodeBase64(pdfSave);
			FileOutputStream fos = new FileOutputStream(pdfName);
			fos.write(ps);
			fos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		/*
		 * ackValue = userDetailsService.saveUserDetails(WebAppUtil
		 * .getUserDetailsObject(request, response));
		 */

		ModelAndView modView = new ModelAndView("Sumcare/enrollmentForm5", "ackValue", ackValue);

		return modView;
	}

	@RequestMapping(value = "/previousEnrollFormGen1", method = RequestMethod.POST)
	public ModelAndView previousEnrollForm1(HttpServletRequest request, UserDetailsVO userVO) {

		String county = (String) request.getSession().getAttribute("county");
		if (request.getSession().getAttribute("userDetailsVO") == null) {
			ModelAndView modView = new ModelAndView("Sumcare/test");
			return modView;
		}
		Map relationsMap = (Map) request.getSession().getAttribute("relationsMap");
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		UserDetailsVO userDetailsVO = (UserDetailsVO) request.getSession().getAttribute("userDetailsVO");
		Map<String, String> plans = userDetailsService.getAvailablePlansForCounty(county);
		Map<String, String> PlansLinkedHashMap = new LinkedHashMap<String, String>();

		if (plans.get("TOPAZ") != null) {
			PlansLinkedHashMap.put("TOPAZ", plans.get("TOPAZ"));
		}
		if (plans.get("RUBY") != null) {
			PlansLinkedHashMap.put("RUBY", plans.get("RUBY"));
		}
		if (plans.get("SAPPHIRE") != null) {
			PlansLinkedHashMap.put("SAPPHIRE", plans.get("SAPPHIRE"));
		}
		if (plans.get("EMERALD") != null) {
			PlansLinkedHashMap.put("EMERALD", plans.get("EMERALD"));
		}
		mapModel.put("availablePlans", PlansLinkedHashMap);

		mapModel.put("relations", relationsMap);
		mapModel.put("userDetailsVO", userDetailsVO);

		ModelAndView modView;
		PolicyDetailsVO policyDetailsVO = (PolicyDetailsVO) request.getSession().getAttribute("policyDetailsVO1");

		modView = new ModelAndView("Sumcare/enrollmentForm1", mapModel);

		return modView;

	}

	@RequestMapping(value = "/previousEnrollFormGen2", method = RequestMethod.POST)
	public ModelAndView previousEnrollForm2(HttpServletRequest request, PolicyDetailsVO ad) {

		if (request.getSession().getAttribute("policyDetailsVO1") == null) {
			ModelAndView modView = new ModelAndView("Sumcare/test");
			return modView;
		}
		ModelAndView modView;
		HashMap mapModel = new HashMap();

		PolicyDetailsVO policyDetailsVO = (PolicyDetailsVO) request.getSession().getAttribute("policyDetailsVO1");
		mapModel.put("errorphysicianValue", policyDetailsVO.getErrorphysicianValue());
		if (policyDetailsVO.getPhysician() != null && !(policyDetailsVO.getPhysician().equalsIgnoreCase("None"))) {
			String input = policyDetailsVO.getPhysician();
			Matcher matcher = Pattern.compile("(?<=-).*").matcher(input);
			matcher.find();
			if (matcher.groupCount() > 0) {
				mapModel.put("phySessionValue", matcher.group());
			} else {
				mapModel.put("phySessionValue", policyDetailsVO.getPhysician());
			}
		} else {
			mapModel.put("phySessionValue", policyDetailsVO.getPhysician());
		}
		Map physicanMapDB = (Map) request.getSession().getAttribute("physicianMap");
		mapModel.put("physicians", physicanMapDB);
		mapModel.put("physiciansPipeString", getPipeSepString(physicanMapDB));
		mapModel.put("policyDetailsVO1", policyDetailsVO);
		modView = new ModelAndView("Sumcare/enrollmentForm2", mapModel);
		return modView;
	}

	private String getPipeSepString(Map physicanMapDB) {
		StringBuffer pipeSepString = new StringBuffer();
		Set keys = physicanMapDB.keySet();
		Object value;
		int count = 0;
		for (Object key : keys) {
			value = physicanMapDB.get(key);
			if (value != null) {
				value = value.toString().trim();
				value = value.toString().replaceAll(" +", " ");
			}
			pipeSepString.append(key).append("=").append(value);
			if (count++ >= 0) {
				pipeSepString.append("|");
			}
		}
		return pipeSepString.toString();
	}

	/*
	 * @RequestMapping(value = "/nextEnrollFormGenS4", method =
	 * RequestMethod.GET) public ModelAndView
	 * nextEnrollFormS3(HttpServletRequest request,
	 * 
	 * @ModelAttribute("attestationDetailsVO") AttestationDetailsVO ad) {
	 * 
	 * ModelAndView modView = new ModelAndView("Sumcare/enrollmentForm4", "",
	 * ad); return modView; }
	 */
	@RequestMapping(value = "/previousEnrollFormGen3", method = RequestMethod.POST)
	public ModelAndView previousEnrollFormGenS3(HttpServletRequest request, AgreeDetailsVO ad) {

		if (request.getSession().getAttribute("agreeDetailsVO") == null) {

			ModelAndView modView = new ModelAndView("Sumcare/test");
			return modView;
		}
		AgreeDetailsVO agreeDetailsVO = (AgreeDetailsVO) request.getSession().getAttribute("agreeDetailsVO");
		ModelAndView modView = new ModelAndView("Sumcare/enrollmentForm3", "agreeDetailsVO", agreeDetailsVO);
		return modView;

	}

	/*
	 * @RequestMapping(value = "/previousEnrollFormGen4", method =
	 * RequestMethod.POST) public ModelAndView
	 * previousEnrollForm4(HttpServletRequest request, AttestationDetailsVO
	 * attestVo) { ModelAndView modView = null; try { if
	 * (request.getSession().getAttribute("attestationDetailsVO") == null) {
	 * modView = new ModelAndView("enrollment/test"); return modView; }
	 * AttestationDetailsVO attestationDetailsVO = (AttestationDetailsVO)
	 * request .getSession().getAttribute("attestationDetailsVO"); modView = new
	 * ModelAndView("VAPremier/enrollmentForm3", "attestationDetailsVO",
	 * attestationDetailsVO);
	 * 
	 * } catch (Exception e) { LOGGER.error(
	 * " error : In printEnrollFormsGen() method of GenericController class"); }
	 * return modView; }
	 */

	@RequestMapping(value = "/printEnrollFormsGen", method = RequestMethod.POST)
	public ModelAndView printEnrollForms(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("attestationDetailsVO") AttestationDetailsVO attestationDetailsVO) {
		try {

			request.getSession().setAttribute("attestationDetailsVO", attestationDetailsVO);
			PDFUtilGen.showEnrollFromsInPDF(request, response);

		} catch (Exception e) {
			LOGGER.error(" error : In printEnrollFormsGen() method of GenericController class");
		}
		return null;
	}
}
