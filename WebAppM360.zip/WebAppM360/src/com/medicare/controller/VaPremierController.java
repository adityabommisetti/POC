package com.medicare.controller;



import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.medicare.helper.PDFUtilLatest;
import com.medicare.helper.PDFUtilLatest2019;
import com.medicare.helper.PDFUtilLatest2020;
import com.medicare.helper.VAPConstants;
import com.medicare.service.IUserDetailsService;
import com.medicare.util.SentaraUtil;
import com.medicare.util.StringUtil;
import com.medicare.validator.AgreeDetailsValidator;
import com.medicare.validator.AttestationDetailsValidator;
import com.medicare.validator.PolicyDetailsValidator;
import com.medicare.validator.UserDetailsValidator;
import com.medicare.vo.AgreeDetailsVO;
import com.medicare.vo.AttestationDetailsVO;
import com.medicare.vo.PolicyDetailsVO;
import com.medicare.vo.UserDetailsVO;

@Controller
public class VaPremierController {

	// we are getting pdfs from files
	// we are getting mail zip codes from map , not from database

	private final static Logger LOGGER = Logger.getLogger(VaPremierController.class.getName());
	
	private static String aepStartDate = null;
	private static String aepEndDate = null;

	private IUserDetailsService userDetailsService;
	@Autowired
	public void setUserDetailsService(IUserDetailsService userDetailsService) {
		this.userDetailsService = userDetailsService;
	}
	String customer_id = "HCF0232";
	/**
	 * Method to show the form1
	 * 
	 * @param request
	 * @param ud
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/Vap", method = RequestMethod.GET)
	public ModelAndView showEnrollForm1(HttpServletRequest request, UserDetailsVO ud) {

		System.out.println("*******************From showEnrollForm1 *****************************");
		LOGGER.info(" Start : In showEnrollForm1() method of UserDetailsController class");

		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		String plan= request.getParameter("Plan");
		mapModel.put("optimaPlanSessionVal", plan);
		mapModel.put("pcSessionValue", request.getParameter("primaryCity"));
		mapModel.put("psSessionValue", request.getParameter("primaryState"));
		mapModel.put("pzSessionValue", request.getParameter("primaryZipCode"));
		ud.setOptimaMedicare(plan);
		
		String planYear = null;
		
		try {
			
			//Begin: Added for IFOX-00407925
			planYear = request.getParameter("planYear");
			planYear = planYear == null || planYear.trim().equals("") ? "0" : planYear.trim();
			request.getSession().setAttribute("planYear", planYear);
			planYear = (String) request.getSession().getAttribute("planYear");
			LOGGER.info(" VaPremierController : showEnrollForm1 : planYear [" + planYear + "] ");
			//End: Added for IFOX-00407925
			
			//Begin: Making MedicaidId Field as Non Mandatory for DSNP plans
			
			//Plan Id Check
			if(! (nonNullTrim(request.getParameter("contractId")).equals("")) ) //Support to Old URL
				request.getSession().setAttribute("planId", nonNullTrim(request.getParameter("contractId")));

			if(! (nonNullTrim(request.getParameter("planId")).equals("")) ) //Support to New URL
				request.getSession().setAttribute("planId", nonNullTrim(request.getParameter("planId")));

			//PBP Id Check
			if(! (nonNullTrim(request.getParameter("Plan")).equals("")) ) //Support to Old URL
				request.getSession().setAttribute("pbpId", nonNullTrim(request.getParameter("Plan")));

			if(! (nonNullTrim(request.getParameter("pbpId")).equals("")) ) //Support to New URL
				request.getSession().setAttribute("pbpId", nonNullTrim(request.getParameter("pbpId")));
			
			//Plan year
			if(! (nonNullTrim(request.getParameter("planYear")).equals("")) ) //Support to New URL
				request.getSession().setAttribute("planYear", nonNullTrim(request.getParameter("planYear")));

			//Plan Name and Plan Type
			setPlanNameAndTypeInRequest(request);
			//Set currentDate
			DateFormat format = new SimpleDateFormat(VAPConstants.DateFormat);
			String timeStamp = format.format(new Date());
			System.out.println("currentDate : "+timeStamp);
			request.getSession().setAttribute("currentDate", timeStamp);
			
			request.getSession().setAttribute("ISDSNP",
					this.isDSNPPlan( (String) request.getSession().getAttribute("planId"), (String) request.getSession().getAttribute("pbpId") ));
			//End: Making MedicaidId Field as Non Mandatory for DSNP plans
			
			Map populatedMap = userDetailsService.getFirstPagePrePopulatedValues(customer_id);			
			Map physicanMapDB = (Map) populatedMap.get("physicianMap");
			Map stateMapDB = (Map) populatedMap.get("stateMap");
			// i just commented the code becauuse we are not getting these
			// values from database
			// Map mailStateMapDB = (Map) populatedMap.get("mailStateMap");
			//Map agentNmaesMapDB = (Map) populatedMap.get("agentNamesMap");
			Map<String, String> relationEnrolle = SentaraUtil.getRelationEnrollValues();
			Map mailStateMapDB = SentaraUtil.getMaliningStateZipValues();
			mapModel.put("physicians", physicanMapDB);
			mapModel.put("physiciansPipeString", getPipeSepString(physicanMapDB));
			mapModel.put("states", stateMapDB);
			mapModel.put("mailStates", mailStateMapDB);
			//mapModel.put("agentNames", agentNmaesMapDB);
			mapModel.put("relations", relationEnrolle);

			//Begin: Added for IFOX-00390786 (Phase-II)
			//mapModel.put("institutionsMap", (Map) populatedMap.get("institutionMap"));
			mapModel.put("institutionsPipeString", getPipeSepString((Map) populatedMap.get("institutionMap")));
			mapModel.put("institutionAddressPipeString", getPipeSepString((Map) populatedMap.get("institutionAddressMap")));
			request.getSession().setAttribute("institutionsMap", (Map) populatedMap.get("institutionMap"));
			request.getSession().setAttribute("institutionAddressPipeString", (String) mapModel.get("institutionAddressPipeString"));
			//End: Added for IFOX-00390786 (Phase-II)
			request.getSession().setAttribute("physicianMap", physicanMapDB);
			request.getSession().setAttribute("stateMap", stateMapDB);
			request.getSession().setAttribute("mailStateMap", mailStateMapDB);
			//request.getSession().setAttribute("agentNamesMap", agentNmaesMapDB);
			request.getSession().setAttribute("relationsMap", relationEnrolle);

			// ModelAndView mv = new ModelAndView("enrollment/enrollemntForm1",
			// mapModel);
			// return mv;
			String application_year = request.getParameter("app_year");
			// adding application_year in session
			request.getSession().setAttribute("appl_year", application_year);
			request.getSession().setAttribute("campaignId", request.getParameter("campaignId"));
			request.getSession().setAttribute("contractId", request.getParameter("contractId"));
			request.getSession().setAttribute("customerId", customer_id);
			
			// String appl_year = (String)
			// request.getSession().getAttribute("appl_year");

			// if (appl_year.equalsIgnoreCase("2015")) {
			
			//Begin: Added for IFOX-00407925
			//ModelAndView mv = new ModelAndView("VaPremier/enrollemntForm1_2017", mapModel);
			ModelAndView mv = new ModelAndView(
					Integer.parseInt(planYear) > 2018 ? "VaPremier/" + planYear + "/enrollemntForm1" :
					"VaPremier/enrollemntForm1_2017", mapModel);
			//End: Added for IFOX-00407925
			
			return mv;
			// } else {
			// ModelAndView mv = new ModelAndView("enrollment/enrollemntForm1",
			// mapModel);
			// return mv;
			// }

		} catch (Exception e) {
			LOGGER.error(" error : In showEnrollForm1() method of UserDetailsController class");
			
			//Begin: Added for IFOX-00407925
			ModelAndView mv = new ModelAndView(
					Integer.parseInt(planYear) > 2018 ? "VaPremier/" + planYear + "/communicationError" :
					"VaPremier/communicationError");
			//End: Added for IFOX-00407925
			
			return mv;
		}

	}

	/**
	 * Method is used to set the selected plan name.
	 * 
	 * @param request
	 * @return
	 */
	private HttpServletRequest setPlanNameAndTypeInRequest(HttpServletRequest request) {
		String planName = "Advantage ";
		String pbpId = nonNullTrim(request.getParameter("pbpId"));
		if(pbpId.equalsIgnoreCase("001")){
			request.getSession().setAttribute("planName", planName + "Elite");
			
			request.getSession().setAttribute("planNameType", "HMO SNP");
		}else if(pbpId.equalsIgnoreCase("002")){
			request.getSession().setAttribute("planName", planName + "Gold");
			request.getSession().setAttribute("planNameType", "HMO");
		}else if(pbpId.equalsIgnoreCase("003")){
			request.getSession().setAttribute("planName", planName + "Platinum");
			request.getSession().setAttribute("planNameType", "HMO");
		}
		return request;
	}

	private String getPipeSepString(Map physicanMapDB) {
		StringBuffer pipeSepString = new StringBuffer();
		try {
			Set keys = physicanMapDB.keySet();
			Object value;
			int count = 0;
			for (Object key : keys) {
				value = physicanMapDB.get(key);
				if (value != null) {
					value = value.toString().trim();
					value = value.toString().replaceAll(" +", " ");
				}
				pipeSepString.append(key).append("=").append(value);
				if (count++ >= 0) {
					pipeSepString.append("|");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return pipeSepString.toString();
	}

	/**
	 * 
	 * @param request
	 * @param userDetailsVO
	 * @param result
	 * @return
	 */
	@RequestMapping(value = "/saveEnrollForm1", method = RequestMethod.POST)
	public ModelAndView saveEnrollForm1(HttpServletRequest request,  UserDetailsVO userDetailsVO,
			BindingResult result) {
		// HttpServletRequest request, UserDetailsVO userDetailsVO,
		// BindingResult result) {

		// for 2015 application

		System.out.println("*******************From saveEnrollForm1 *****************************");

		//Begin: Added for IFOX-00407925
		String planYear = (String) request.getSession().getAttribute("planYear");
		LOGGER.info(" VaPremierController : saveEnrollForm1 : planYear [" + planYear + "] ");
		//End: Added for IFOX-00407925
		
		String campaignId = (String) request.getSession().getAttribute("campaignId");
		String contractId = (String) request.getSession().getAttribute("contractId");
		String customerId = customer_id;
		
		if (campaignId != null)
			userDetailsVO.setCampaignId(campaignId);
		else
			userDetailsVO.setCampaignId(" ");
		if (contractId != null)
			userDetailsVO.setContractId(contractId);
		else
			userDetailsVO.setContractId(" ");
		
		userDetailsVO.setCustomerId(customerId);

		LOGGER.info(" Start : In saveEnrollForm1() method of UserDetailsController class");
		request.getSession().setAttribute("userDetailsObjForm1", userDetailsVO);

		if(nonNullTrim(userDetailsService.isPermStateCityZipIsValid(userDetailsVO)).equals("N")) {
			request.getSession().setAttribute("PermStateCityZipFlag", "N");
			return previousEnrollForm1(request, userDetailsVO);
		} else {
			request.getSession().setAttribute("PermStateCityZipFlag", "Y");
		}
		
		
		UserDetailsValidator userValidator = new UserDetailsValidator();
		// userValidator.validate(userDetailsVO, result, null);

		Map<String, Boolean> cityStateMap = new HashMap<String, Boolean>();
		if (userDetailsVO.getMailingState() != null && userDetailsVO.getMailingState().equalsIgnoreCase("None")) {
			userDetailsVO.setMailingState("");
		}

		if (userDetailsVO.getRelationYou() != null && userDetailsVO.getRelationYou().equalsIgnoreCase("None")) {
			userDetailsVO.setRelationYou("");
		}

		if ((userDetailsVO.getPermanentCity() != null && !userDetailsVO.getPermanentCity().isEmpty())
				&& (userDetailsVO.getPermanentState() != null && !userDetailsVO.getPermanentState().isEmpty())
				&& (userDetailsVO.getPermanentZip() != null && !userDetailsVO.getPermanentZip().isEmpty())) {

			try {
				cityStateMap = userDetailsService.validateStateAndCityValuesFromDB(userDetailsVO);
			} catch (Exception e) {
				LOGGER.error(" error : In saveEnrollForm1() method of UserDetailsController class");
				
				//Begin: Added for IFOX-00407925
				ModelAndView mv = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ? "VaPremier/" + planYear + "/communicationError" :
						"VaPremier/communicationError");
				//End: Added for IFOX-00407925
				
				return mv;
			}
		}
		userValidator.validate(userDetailsVO, result, cityStateMap);
		if (result.hasErrors()) {
			// newly added
			if (result.getFieldError("homePhNumber") != null) {
				userDetailsVO.setErrorhomePhNumberValue("homePhNumberValue");
			}
			if (result.getFieldError("lastName") != null) {
				userDetailsVO.setErrorlastNameValue("lastNameValue");
			}
			if (result.getFieldError("firstName") != null) {
				userDetailsVO.setErrorfirstNameValue("firstNameValue");
			}
			if (result.getFieldError("middleInitial") != null) {
				userDetailsVO.setErrormiddleInitialValue("middleInitialValue");
			}
			if (result.getFieldError("birthDate") != null) {
				userDetailsVO.setErrorbirthDateValue("birthDateValue");
			}
			if (result.getFieldError("altrPhNumber") != null) {
				userDetailsVO.setErroraltrPhNumberValue("altrPhNumberValue");
			}
			if (result.getFieldError("emailAddr") != null) {
				userDetailsVO.setErroremailAddrValue("emailAddrValue");
			}
			if (result.getFieldError("mailingZip") != null) {
				userDetailsVO.setErrormailingZipValue("mailingZipValue");
			}
			if (result.getFieldError("emergencyCont") != null) {
				userDetailsVO.setErroremergencyContValue("emergencyContValue");
			}
			if (result.getFieldError("relationYou") != null) {
				userDetailsVO.setErroremergencyRelValue("emergencyRelValue");
			}
			if (result.getFieldError("emergPhNum") != null) {
				userDetailsVO.setErroremergPhNumValue("emergPhNumValue");
			}
			if (result.getFieldError("permanentAddr") != null) {
				userDetailsVO.setErrorpermanentAddrValue("permanentAddrValue");
			}
			if (result.getFieldError("permanentCity") != null) {
				userDetailsVO.setErrorpermanentCityValue("permanentCityValue");
			}
			
			//Begin: Added for IFOX-00390786 (Phase-II)
			if (result.getFieldError("permanentApt") != null) {
				userDetailsVO.setErrorpermanentAptValue("permanentAptValue");
			}
			if (result.getFieldError("permanentStrt") != null) {
				userDetailsVO.setErrorpermanentAptValue("permanentStrtValue");
			}
			//End: Added for IFOX-00390786 (Phase-II)
			
			if (result.getFieldError("permanentState") != null) {
				userDetailsVO.setErrorpermanentStateValue("permanentStateValue");
			}
			if (result.getFieldError("permanentZip") != null) {
				userDetailsVO.setErrorpermanentZipValue("permanentZipValue");
			}
			if (result.getFieldError("nameBeneficiary") != null) {
				userDetailsVO.setErrornameBeneficiaryValue("nameBeneficiaryValue");
			}
			if (result.getFieldError("MediacrdNumber") != null) {
				userDetailsVO.setErrorMediacrdNumberValue("MediacrdNumberValue");
			}
			
			//Begin: Added for IFOX-00390786 (Phase-II)
			if (result.getFieldError("beneficiarySex") != null) {
				userDetailsVO.setErrorbeneficiarySexValue("beneficiarySexValue");
			}
			if (result.getFieldError("permanentStrt") != null) {
				userDetailsVO.setErrorpermanentStrtValue("permanentStrtValue");
			}
			
			if (result.getFieldError("permanentApt") != null) {
				userDetailsVO.setErrorpermanentAptValue("permanentAptValue");
			}
			if (result.getFieldError("renalDisease") != null) {
				userDetailsVO.setErrorrenalDiseaseValue("renalDiseaseValue");
			}
			if (result.getFieldError("stateMedicaid") != null) {
				userDetailsVO.setErrorstateMedicaidValue("stateMedicaidValue");
			}
			if (result.getFieldError("medicaidNumber") != null) {
				userDetailsVO.setErrormedicaidNumberValue("medicaidNumberValue");
			}
			
			//End: Added for IFOX-00390786 (Phase-II)
			
			if (result.getFieldError("hospitalDate") != null) {
				userDetailsVO.setErrorhospitalDateValue("hospitalDateValue");
			}
			if (result.getFieldError("medicalDate") != null) {
				userDetailsVO.setErrormedicalDateValue("medicalDateValue");
			}
			if (result.getFieldError("permCityState") != null) {
				userDetailsVO.setErrorpermCityStateValue("permCityStateValue");
			}
			if (result.getFieldError("mailingCityState") != null) {
				userDetailsVO.setErrormailingCityStateValue("mailingCityStateValue");
			}
			/*if (result.getFieldError("physician") != null) {
				userDetailsVO.setErrorphysicianValue("physicianValue");
			}*/

			// for 2015 application
			if (result.getFieldError("effDate") != null) {
				userDetailsVO.setErroreffDateValue("effDateValue");
			}

			// newly added end

			// userValidator.validate(userDetailsVO, result, cityStateMap);
			return previousEnrollForm1(request, userDetailsVO);
		} else {

			userValidator.validate(userDetailsVO, result, cityStateMap);
			if (result.hasErrors()) {
				// newly added
				if (result.getFieldError("permCityState") != null) {
					userDetailsVO.setErrorpermCityStateValue("permCityStateValue");
				}
				if (result.getFieldError("mailingCityState") != null) {
					userDetailsVO.setErrormailingCityStateValue("mailingCityStateValue");
				}
				/*if (result.getFieldError("physician") != null) {
					userDetailsVO.setErrorphysicianValue("physicianValue");
				}*/
				if (result.getFieldError("emergPhNum") != null) {
					userDetailsVO.setErrorphysicianValue("emergPhNumValue");
				}
				if (result.getFieldError("relationYou") != null) {
					userDetailsVO.setErrorphysicianValue("emergencyRelValue");
				}
				if (result.getFieldError("emergencyCont") != null) {
					userDetailsVO.setErrorphysicianValue("emergencyContValue");
				}
				// newly added end
				return previousEnrollForm1(request, userDetailsVO);
			}

			//Begin: Added for IFOX-00407925
			ModelAndView mv = new ModelAndView(
					Integer.parseInt(planYear) > 2018 ? "VaPremier/" + planYear + "/successEnrollForm1" :
					"VaPremier/successEnrollForm1", "", userDetailsVO);
			//End: Added for IFOX-00407925

			return mv;
		}
	}

	/**
	 * @param request
	 * @param pd
	 * @return
	 */
	@RequestMapping(value = "/nextEnrollForm2", method = RequestMethod.GET)
	public ModelAndView nextEnrollForm1(HttpServletRequest request, PolicyDetailsVO pd) {

		LOGGER.info(" Start : In nextEnrollForm1() method of UserDetailsController class");
		
		//Begin: Added for IFOX-00407925
		String planYear = (String) request.getSession().getAttribute("planYear");
		LOGGER.info(" VaPremierController : nextEnrollForm1 : planYear [" + planYear + "] ");
		//End: Added for IFOX-00407925
		
		//Begin: Added for IFOX-00390786 (Phase-II)
		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		Map populatedMap = userDetailsService.getSecondPagePrePopulatedValues(customer_id);
		Map institutionsMap = (Map) populatedMap.get("institutionMap");
		String institutionAddressPipeString = (String) request.getSession().getAttribute("institutionAddressPipeString");
		
		if(null == institutionsMap)
			institutionsMap = new HashMap<String, String>();

		mapModel.put("institutionsMap", institutionsMap);
		mapModel.put("institutionsPipeString", getPipeSepString(institutionsMap));
		mapModel.put("institutionAddressPipeString", institutionAddressPipeString);
		/* IFOX-00419836 2020 AEP changes. START*/
		mapModel.put("physicians", request.getSession().getAttribute("physicianMap"));
		mapModel.put("physiciansPipeString", getPipeSepString((Map)request.getSession().getAttribute("physicianMap")));
		/* IFOX-00419836 2020 AEP changes. END*/
		//End: Added for IFOX-00390786 (Phase-II)
		if (request.getSession().getAttribute("policyDetailsObjForm1") != null) {
			return previousEnrollForm2(request, pd);
		} else {

			// String appl_year = (String)
			// request.getSession().getAttribute("appl_year");
			// if (appl_year.equalsIgnoreCase("2015")) {
			
			//Begin: Added for IFOX-00390786 (Phase-II)
			//ModelAndView mv = new ModelAndView("VaPremier/enrollemntForm2_2017", "", pd);
			
			//Begin: Added for IFOX-00407925
			ModelAndView mv = new ModelAndView(
					Integer.parseInt(planYear) > 2018 ? "VaPremier/" + planYear + "/enrollemntForm2" :
					"VaPremier/enrollemntForm2_2017", "", pd).addAllObjects(mapModel);
			//End: Added for IFOX-00407925
			
			//End: Added for IFOX-00390786 (Phase-II)
			
			return mv;
			// } else {
			// ModelAndView mv = new ModelAndView("enrollment/enrollemntForm2",
			// "", pd);
			// return mv;
			// }
		}
	}

	/**
	 * @param request
	 * @param policyDetailsVO
	 * @param result
	 * @return
	 */
	@RequestMapping(value = "/saveEnrollForm2")
	public ModelAndView saveEnrollForm2(HttpServletRequest request,  PolicyDetailsVO policyDetailsVO,
			// HttpServletRequest request, PolicyDetailsVO policyDetailsVO,
			BindingResult result) {

		//Begin: Added for IFOX-00407925
		String planYear = (String) request.getSession().getAttribute("planYear");
		LOGGER.info(" VaPremierController : saveEnrollForm2 : planYear [" + planYear + "] ");
		//End: Added for IFOX-00407925
		
		if (request.getSession().getAttribute("userDetailsObjForm1") == null) {
			
			//Begin: Added for IFOX-00407925
			ModelAndView mv = new ModelAndView(
					Integer.parseInt(planYear) > 2018 ? "VaPremier/" + planYear + "/test" :
					"VaPremier/test");
			//End: Added for IFOX-00407925
			
			return mv;
		}
		
		policyDetailsVO.setCustomerId(customer_id);
		LOGGER.info(" Start : In saveEnrollForm2() method of UserDetailsController class");
		request.getSession().setAttribute("policyDetailsObjForm1", policyDetailsVO);
		
		//Begin: Commented for WebApp VAP Integration
		/*
		PolicyDetailsValidator pValidator = new PolicyDetailsValidator();
		pValidator.validate(policyDetailsVO, result);
		
		//Begin: Making MedicaidId Field as Non Mandatory for DSNP plans
		if(nonNullTrim((String) request.getSession().getAttribute("ISDSNP")).equals("N")) {
			ModelAndView mv = new ModelAndView("enrollment/successEnrollForm2", "", policyDetailsVO);
			return mv;
		}
		//End: Making MedicaidId Field as Non Mandatory for DSNP plans
		
		if (result.hasErrors()) {

			if (result.getFieldError("accountHolderName") != null) {
				policyDetailsVO.setErroraccountHolderNameValue("accountHolderNameValue");
			}
			if (result.getFieldError("bankRoutingNumber") != null) {
				policyDetailsVO.setErrorbankAccountNumberValue("bankRoutingNumberValue");
			}
			if (result.getFieldError("bankAccountNumber") != null) {
				policyDetailsVO.setErrorbankAccountNumberValue("bankAccountNumberValue");
			}
			if (result.getFieldError("beginingDate") != null) {
				policyDetailsVO.setErrorbeginingDateValue("beginingDateValue");
			}

			return previousEnrollForm2(request, policyDetailsVO);

		} else {
			ModelAndView mv = new ModelAndView("VaPremier/successEnrollForm2", "", policyDetailsVO);
			return mv;

		}
		*/
		
		//Begin: Added for IFOX-00407925
		ModelAndView mv = new ModelAndView(
				Integer.parseInt(planYear) > 2018 ? "VaPremier/" + planYear + "/successEnrollForm2" :
				"VaPremier/successEnrollForm2", "", policyDetailsVO);
		//End: Added for IFOX-00407925
		
		return mv;
		
		//End: Commented for WebApp VAP Integration
		
	}

	/**
	 * @param request
	 * @param ad
	 * @return
	 */
	@RequestMapping(value = "/nextEnrollForm3", method = RequestMethod.GET)
	public ModelAndView nextEnrollForm2(HttpServletRequest request, AttestationDetailsVO ad) {

		LOGGER.info(" Start : In nextEnrollForm2() method of UserDetailsController class");
		
		//Begin: Added for IFOX-00407925
		String planYear = (String) request.getSession().getAttribute("planYear");
		LOGGER.info(" VaPremierController : nextEnrollForm2 : planYear [" + planYear + "] ");
		//End: Added for IFOX-00407925
		
		if (request.getSession().getAttribute("attestationDetailsObjForm1") != null) {
			return previousEnrollForm3(request, ad);
		} else {
			// String appl_year = (String)
			// request.getSession().getAttribute("appl_year");
			// if (appl_year.equalsIgnoreCase("2015")) {

			//Begin: Added for IFOX-00407925
			ModelAndView mv = new ModelAndView(
					Integer.parseInt(planYear) > 2018 ? "VaPremier/" + planYear + "/enrollemntForm3" :
					"VaPremier/enrollemntForm3_2017", "", ad);
			//End: Added for IFOX-00407925
			
			return mv;
			// } else {

			// ModelAndView mv = new ModelAndView("enrollment/enrollemntForm3",
			// "", ad);
			// return mv;
			// }
		}
	}

	/**
	 * @param request
	 * @param attestationDetailsVO
	 * @param result
	 * @return
	 */
	@RequestMapping(value = "/saveEnrollForm3")
	public ModelAndView saveEnrollForm3(HttpServletRequest request,  AttestationDetailsVO attestationDetailsVO,
			// HttpServletRequest request,AttestationDetailsVO
			// attestationDetailsVO,
			BindingResult result) {

		//Begin: Added for IFOX-00407925
		String planYear = (String) request.getSession().getAttribute("planYear");
		LOGGER.info(" VaPremierController : saveEnrollForm3 : planYear [" + planYear + "] ");
		//End: Added for IFOX-00407925
		
		if (request.getSession().getAttribute("policyDetailsObjForm1") == null) {
			
			//Begin: Added for IFOX-00407925
			ModelAndView mv = new ModelAndView(
					Integer.parseInt(planYear) > 2018 ? "VaPremier/" + planYear + "/test" :
					"VaPremier/test");
			//End: Added for IFOX-00407925
			
			return mv;
		}

		LOGGER.info(" Start : In saveEnrollForm3() method of UserDetailsController class");
		request.getSession().setAttribute("attestationDetailsObjForm1", attestationDetailsVO);
		AttestationDetailsValidator aValidator = new AttestationDetailsValidator();
		aValidator.validate(attestationDetailsVO, result);
		if (result.hasErrors()) {
			return previousEnrollForm3(request, attestationDetailsVO);
		} else {
			
			//Begin: Added for IFOX-00407925
			ModelAndView mv = new ModelAndView(
					Integer.parseInt(planYear) > 2018 ? "VaPremier/" + planYear + "/successEnrollForm3" :
					"VaPremier/successEnrollForm3", "", attestationDetailsVO);
			//End: Added for IFOX-00407925
			
			return mv;
		}
	}

	/**
	 * @param request
	 * @param agd
	 * @return
	 */
	@RequestMapping(value = "/nextEnrollForm4", method = RequestMethod.GET)
	public ModelAndView nextEnrollForm3(HttpServletRequest request, AgreeDetailsVO agd) {

		HashMap<String, Object> mapModel = new HashMap<String, Object>();
		LOGGER.info(" Start : In nextEnrollForm3() method of UserDetailsController class");
		
		//Begin: Added for IFOX-00407925
		String planYear = (String) request.getSession().getAttribute("planYear");
		LOGGER.info(" VaPremierController : nextEnrollForm3 : planYear [" + planYear + "] ");
		//End: Added for IFOX-00407925
		
		//Begin: Making default attestation as AEP if an application receives
		//during AEP period for 01/01/2018 effective date.
		UserDetailsVO userDetailsVO = (UserDetailsVO) request.getSession().getAttribute("userDetailsObjForm1");
		String effetiveDate = userDetailsVO.getEffDate();
		
		if(null == aepStartDate && null == aepEndDate) {
			try {
				//Need to be pulled from database
				Properties prop = new Properties();
				prop.load(VaPremierController.class.getClassLoader().getResourceAsStream("VAPremier.properties"));
				aepStartDate = prop.getProperty("AEPStartDate");
				aepEndDate = prop.getProperty("AEPEndDate");
				
			} catch(IOException exception) {
				LOGGER.error(" VaPremierController : nextEnrollForm3 : " + exception.getMessage());
				exception.printStackTrace();
			}
		}
		if(isAEPPeriod(effetiveDate, aepStartDate, aepEndDate))
			request.getSession().setAttribute("ISAEPPERIOD", "Y");
		else
			request.getSession().setAttribute("ISAEPPERIOD", "N");
		
		//End: Making default attestation as AEP if an application receives
		//during AEP period for 01/01/2018 effective date.

		if (request.getSession().getAttribute("agreeDetailsObjForm1") != null) {
			return previousEnrollForm4(request, agd);
		} else {

			// Map stateMapDB =(Map)
			// request.getSession().getAttribute("stateMap");
			Map mailStateMapDB = (Map) request.getSession().getAttribute("mailStateMap");
			Map relationsMapEnrolee = (Map) request.getSession().getAttribute("relationsMap");
			// for agent names
			Map populatedMap = userDetailsService.getFouthPagePrePopulatedValues(customer_id);
			Map agentNamesDB = (Map) populatedMap.get("agentNamesMap");
			// mapModel.put("states", stateMapDB);
			mapModel.put("mailStates", mailStateMapDB);
			// for agent names
			mapModel.put("agentNames", agentNamesDB);
			mapModel.put("relations", relationsMapEnrolee);

			request.getSession().setAttribute("agentNamesMap", agentNamesDB); //Added for IFOX-00397099
			
			// String appl_year = (String)
			// request.getSession().getAttribute("appl_year");
			// if (appl_year.equalsIgnoreCase("2015")) {

			//Begin: Added for IFOX-00407925
			ModelAndView mv = new ModelAndView(
					Integer.parseInt(planYear) > 2018 ? "VaPremier/" + planYear + "/enrollemntForm4" :
					"VaPremier/enrollemntForm4_2017", mapModel);
			//End: Added for IFOX-00407925
			
			return mv;
			// } else {

			// ModelAndView mv = new ModelAndView("enrollment/enrollemntForm4",
			// mapModel);
			// return mv;
			// }

		}
	}

	/**
	 * @param request
	 * @param response
	 * @param agreeDetailsVO
	 * @param result
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws ParseException
	 * @throws IOException
	 * @throws InterruptedException
	 */
	@RequestMapping(value = "/saveEnrollForm4")
	public ModelAndView saveEnrollForm4(HttpServletRequest request, HttpServletResponse response,
			 AgreeDetailsVO agreeDetailsVO, BindingResult result, UserDetailsVO ud)
			// HttpServletRequest request, HttpServletResponse
			// response,AgreeDetailsVO agreeDetailsVO, BindingResult result)
			throws ClassNotFoundException, SQLException, ParseException, IOException, InterruptedException {

		LOGGER.info(" Start : In saveEnrollForm4() method of UserDetailsController class");
		
		//Begin: Added for IFOX-00407925
		String planYear = (String) request.getSession().getAttribute("planYear");
		LOGGER.info(" VaPremierController : saveEnrollForm4 : planYear [" + planYear + "] ");
		//End: Added for IFOX-00407925
		
		int ackValue = 0;
		Map<String, Boolean> cityStateMap = new HashMap<String, Boolean>();

		if (agreeDetailsVO.getLegalState() != null && agreeDetailsVO.getLegalState().equalsIgnoreCase("None")) {
			agreeDetailsVO.setLegalState("");
		}
		if (agreeDetailsVO.getLegalRelationErloll() != null
				&& agreeDetailsVO.getLegalRelationErloll().equalsIgnoreCase("None")) {
			agreeDetailsVO.setLegalRelationErloll("");
		}

		// for agent id and agent name
		if (agreeDetailsVO.getAgentId() != null && agreeDetailsVO.getAgentId().equalsIgnoreCase("None")) {
			agreeDetailsVO.setAgentId("");
		}

		if (agreeDetailsVO.getAgentName() != null && agreeDetailsVO.getAgentName().equalsIgnoreCase("None")) {
			agreeDetailsVO.setAgentName("");
		}

		if (request.getSession().getAttribute("attestationDetailsObjForm1") == null) {
			
			//Begin: Added for IFOX-00407925
			ModelAndView mv = new ModelAndView(
					Integer.parseInt(planYear) > 2018 ? "VaPremier/" + planYear + "/test" :
					"VaPremier/test");
			//End: Added for IFOX-00407925
			
			return mv;
		}

		UserDetailsVO userDetailsVO = (UserDetailsVO) request.getSession().getAttribute("userDetailsObjForm1");
		agreeDetailsVO.setIcepDate(userDetailsVO.getBirthDate());
		AgreeDetailsValidator agreeValidator = new AgreeDetailsValidator();
		request.getSession().setAttribute("agreeDetailsObjForm1", agreeDetailsVO);
		/* IFOX-00419836 2020 AEP changes. START*/
		userDetailsVO.setPlanYear(planYear);
		request.getSession().setAttribute("userDetailsObjForm1",userDetailsVO);
		/* IFOX-00419836 2020 AEP changes. END*/
		//if (result.hasErrors()) {
		/*if (false) { // Added for VAP as it has validation on front end.


			// newly added
			if (result.getFieldError("trcntCreditChBox") != null) {
				agreeDetailsVO.setErrortrcntCreditChBoxValue("trcntCreditChBoxValue");
			}
			if (result.getFieldError("newElgbChBox") != null) {
				agreeDetailsVO.setErrornewElgbChBoxValue("newElgbChBoxValue");
			}
			if (result.getFieldError("revMedChBox") != null) {
				agreeDetailsVO.setErrorrevMedChBoxValue("revMedChBoxValue");
			}
			if (result.getFieldError("levEmpChBox") != null) {
				agreeDetailsVO.setErrorlevEmpChBoxValue("levEmpChBoxValue");
			}
			if (result.getFieldError("nlElgPrescChBox") != null) {
				agreeDetailsVO.setErrornlElgPrescChBoxValue("nlElgPrescChBoxValue");
			}
			if (result.getFieldError("recntMovChBox") != null) {
				agreeDetailsVO.setErrorrecntMovChBoxValue("recntMovChBoxValue");
			}
			if (result.getFieldError("recnMovOutChBox") != null) {
				agreeDetailsVO.setErrorrecnMovOutChBoxValue("recnMovOutChBoxValue");
			}
			if (result.getFieldError("recntleftPlChBox") != null) {
				agreeDetailsVO.setErrorrecntleftPlChBoxValue("recntleftPlChBoxValue");
			}
			if (result.getFieldError("mvdUsChBox") != null) {
				agreeDetailsVO.setErrormvdUsChBoxValue("mvdUsChBoxValue");
			}
			
			if (result.getFieldError("unCovChBox") != null) {
				agreeDetailsVO.setErrorunCovChBoxValue("unCovChBoxValue");
			}
			
			if (result.getFieldError("mcNumChBox") != null) {
				agreeDetailsVO.setErrormcNumChBoxValue("mcNumChBoxValue");
			}
			if (result.getFieldError("outLngTermFcSeeChBox") != null) {
				agreeDetailsVO.setErroroutLngTermFcSeeChBoxValue("outLngTermFcSeeChBoxValue");
			}
			if (result.getFieldError("noElgbspseChBox") != null) {
				agreeDetailsVO.setErrornoElgbspseChBoxValue("noElgbspseChBoxValue");
			}
			if (result.getFieldError("prefEmailChBox") != null) {
				agreeDetailsVO.setErrorprefEmailChBoxValue("prefEmailChBoxValue");
			}
			if (result.getFieldError("preferEmail") != null) {
				agreeDetailsVO.setErropreferEmailValue("preferEmailValue");
			}
			if (result.getFieldError("phNum") != null) {
				agreeDetailsVO.setErrorphNumValue("phNumValue");
			}
			if (result.getFieldError("recentlyCreditable") != null) {
				agreeDetailsVO.setErrorrecentlyCreditableValue("recentlyCreditableValue");
			}
			if (result.getFieldError("newlyEligbleMedicare") != null) {
				agreeDetailsVO.setErrornewlyEligbleMedicareValue("newlyEligbleMedicareValue");
			}
			if (result.getFieldError("recieveMedicareDrugs") != null) {
				agreeDetailsVO.setErrorrecieveMedicareDrugsValue("recieveMedicareDrugsValue");
			}
			if (result.getFieldError("leavingEmployerCoverage") != null) {
				agreeDetailsVO.setErrorleavingEmployerCoverageValue("leavingEmployerCoverageValue");
			}
			if (result.getFieldError("noEligbPrescDrugs") != null) {
				agreeDetailsVO.setErrornoEligbPrescDrugsValue("noEligbPrescDrugsValue");
			}
			if (result.getFieldError("recentMovedOption") != null) {
				agreeDetailsVO.setErrorrecentMovedOptionValue("recentMovedOptionValue");
			}
			if (result.getFieldError("recntMovedOutSide") != null) {
				agreeDetailsVO.setErrorrecntMovedOutSideValue("recntMovedOutSideValue");
			}
			if (result.getFieldError("recntLeftPace") != null) {
				agreeDetailsVO.setErrorrecntLeftPaceValue("recntLeftPaceValue");
			}
			if (result.getFieldError("movedBackUs") != null) {
				agreeDetailsVO.setErrormovedBackUsValue("movedBackUsValue");
			}
			if (result.getFieldError("unionCoverage") != null) {
				agreeDetailsVO.setErrorUnionCoverageValue("UnionCoverageValue");;
			}
			if (result.getFieldError("outLongTermFacility") != null) {
				agreeDetailsVO.setErroroutLongTermFacilityValue("outLongTermFacilityValue");
			}
			if (result.getFieldError("noEligSpecial") != null) {
				agreeDetailsVO.setErrornoEligSpecialValue("noEligSpecialValue");
			}
			
			//Begin: Added for IFOX-00390786 (Phase-II)
			if (result.getFieldError("todayDate") != null) {
				agreeDetailsVO.setErrortodayDateValue("todayDateValue");
			}
			if (result.getFieldError("agreeStatements") != null) {
				agreeDetailsVO.setErroragreeStatementsValue("agreeStatementsValue");
			}
			if (result.getFieldError("legalFirstName") != null) {
				agreeDetailsVO.setErrorlegalFirstNameValue("legalFirstNameValue");
			}
			if (result.getFieldError("legalAddress") != null) {
				agreeDetailsVO.setErrorlegalAddressValue("legalAddressValue");
			}
			if (result.getFieldError("legalAddressTwo") != null) {
				agreeDetailsVO.setErrorlegalAddressTwoValue("legalAddressTwoValue");
			}
			if (result.getFieldError("legalPhNumber") != null) {
				agreeDetailsVO.setErrorlegalPhNumberValue("legalPhNumberValue");
			}
			if (result.getFieldError("legalRelationErloll") != null) {
				agreeDetailsVO.setErrorlegalRelationErlollValue("legalRelationErlollValue");
			}
			//End: Added for IFOX-00390786 (Phase-II)
			
			return previousEnrollForm4(request, agreeDetailsVO);
		} else {*/

			//Begin: Code commented for VAP as it has validation on front end.
			/*
			if (agreeDetailsVO.getLegalState() != null && agreeDetailsVO.getLegalState().equalsIgnoreCase("None")) {
				agreeDetailsVO.setLegalState("");
			}
			if (agreeDetailsVO.getLegalRelationErloll() != null
					&& agreeDetailsVO.getLegalRelationErloll().equalsIgnoreCase("None")) {
				agreeDetailsVO.setLegalRelationErloll("");
			}
			// for agent id and agent name
			if (agreeDetailsVO.getAgentId() != null && agreeDetailsVO.getAgentId().equalsIgnoreCase("None")) {
				agreeDetailsVO.setAgentId("");
			}

			if (agreeDetailsVO.getAgentName() != null && agreeDetailsVO.getAgentName().equalsIgnoreCase("None")) {
				agreeDetailsVO.setAgentName("");
			}

			try {
				cityStateMap = userDetailsService.validateAgreeStateAndCityValuesFromDB(agreeDetailsVO);

			} catch (Exception e) {
				LOGGER.error(" error : In saveEnrollForm4() method of UserDetailsController class");
				ModelAndView mv = new ModelAndView("VaPremier/communicationError");
				return mv;
			}
			agreeValidator.validate(agreeDetailsVO, result, cityStateMap);
			if (result.hasErrors()) {
				if (result.getFieldError("todayDate") != null) {
					agreeDetailsVO.setErrortodayDateValue("todayDateValue");
				}
				if (result.getFieldError("legalRelationErloll") != null) {
					agreeDetailsVO.setErrorlegalRelationErlollValue("legalRelationErlollValue");
				}
				if (result.getFieldError("agentName") != null) {
					agreeDetailsVO.setErroragentNameValue("agentNameValue");
				}
				if (result.getFieldError("agentId") != null) {
					agreeDetailsVO.setErroragentIdValue("agentIdValue");
				}
				if (result.getFieldError("planId") != null) {
					agreeDetailsVO.setErrorplanIdValue("planIdValue");
				}
				if (result.getFieldError("icep") != null) {
					agreeDetailsVO.setErroricepValue("icepValue");
				}
				if (result.getFieldError("aep") != null) {
					agreeDetailsVO.setErroraepValue("aepValue");
				}
				if (result.getFieldError("sep") != null) {
					agreeDetailsVO.setErrorsepValue("sepValue");
				}
				
				if (result.getFieldError("legalAddress") != null) {
					agreeDetailsVO.setErrorlegalAddressValue("legalAddressValue");
				}
				if (result.getFieldError("legalPhNumber") != null) {
					agreeDetailsVO.setErrorlegalPhNumberValue("legalPhNumberValue");
				}
				if (result.getFieldError("legalCityState") != null) {
					agreeDetailsVO.setErrorlegalCityStateValue("legalCityStateValue");
				}
				if (result.getFieldError("effectDateCoverage") != null) {
					agreeDetailsVO.setErroreffectDateCoverageValue("effectDateCoverageValue");
				}
				if (result.getFieldError("agentIdNameCheck") != null) {
					agreeDetailsVO.setErroragentIdNameCheckValue("agentIdNameCheckValue");
				}
				return previousEnrollForm4(request, agreeDetailsVO);
			}
			*/
			//End: Code commented for VAP as it has validation on front end.
		
			// Get the ID_SEED before PDF Generation -- Start
			int seqNum = userDetailsService.getSequenecNumberNew(ud.getCustomerId());
			userDetailsService.updateSeedId(ud.getCustomerId(), seqNum);
			// Get the ID_SEED before PDF Generation -- End
			
			HashMap<String, String> mapModel = new HashMap<String, String>();

			// to save the pdf in db
			// for testing purpose i commented it

			byte[] pdfSave;

			// String appl_year = (String)
			// request.getSession().getAttribute("appl_year");
			// System.out.println("appl_year in pdf" + appl_year);
			// if (appl_year.equalsIgnoreCase("2015")) {
			System.out.println(" i am in saving 2017 pdf");
			
			LOGGER.info(" VaPremierController : saveEnrollForm4 : planYear [" + planYear + "] ");

			/* IFOX-00419836 2020 AEP changes. START*/
			if(Integer.parseInt(planYear) > 2019){
				pdfSave = PDFUtilLatest2020.saveBytesPDF(request, response);
			} /* IFOX-00419836 2020 AEP changes. END*/
			else if(Integer.parseInt(planYear) == 2019){
				pdfSave = PDFUtilLatest2019.saveBytesPDF(request, response);
			} else {
				pdfSave = PDFUtilLatest.saveBytesPDF(request, response);
			}
			
			// } else {
			// System.out.println(" i am in saving 2014 pdf");
			// pdfSave = PDFUtil.saveBytesPDF(request, response);
			// }
			request.getSession().setAttribute("pdfSaveenroll", pdfSave);
			String lastName = userDetailsVO.getLastName();
			DateFormat format = new SimpleDateFormat("yyyy_MM_dd_hh_mm_ss");
			String timeStamp = format.format(new Date());

			// to get the seq number ravindra start here
			/*
			 * int seqNum = userDetailsService.getSequenecNumber();
			 * request.getSession().setAttribute("seqNum", seqNum);
			 */
			// to get the seq num end here
			//userDetailsService
			try {
				//int seqNum = userDetailsService.getSequenecNumber();
				
				// Get the ID_SEED before PDF Generation -- Start
				/*int seqNum = userDetailsService.getSequenecNumberNew(ud.getCustomerId());
				userDetailsService.updateSeedId(ud.getCustomerId(), seqNum);*/
				// Get the ID_SEED before PDF Generation -- End
				
				ackValue = userDetailsService.saveUserDetails(SentaraUtil.getUserDetailsObject(request, response,seqNum));
			} catch (Exception e) {
				e.printStackTrace();
				LOGGER.error(" error : In saveEnrollForm4() method of UserDetailsController class");
				
				//Begin: Added for IFOX-00407925
				ModelAndView mv = new ModelAndView(
						Integer.parseInt(planYear) > 2018 ? "VaPremier/" + planYear + "/communicationError" :
						"VaPremier/communicationError");
				//End: Added for IFOX-00407925
				
				return mv;
			}
			Properties prop = new Properties();
			prop.load(VaPremierController.class.getClassLoader().getResourceAsStream("saveLocation.properties"));

			String path = prop.getProperty("VAP.locationpath.pdfSave");
			String pdfName = path + ackValue + lastName + timeStamp + ".pdf";
			LOGGER.info(" pdfSave PATH : " + path);
			LOGGER.info(" pdfName      : " + pdfName);
			LOGGER.info(" ackValue      : " + pdfName);
			LOGGER.info(" lastName      : " + lastName);
			LOGGER.info(" timeStamp      : " + timeStamp);
			// for testing purpose
			byte[] ps = Base64.decodeBase64(pdfSave);
			FileOutputStream fos = new FileOutputStream(pdfName);
			fos.write(ps);
			fos.close();

			mapModel.put("ackValue", String.valueOf(ackValue));
			request.getSession().setAttribute("userId", ackValue);
			
			//Begin: Added for IFOX-00407925
			ModelAndView mv = new ModelAndView(
					Integer.parseInt(planYear) > 2018 ? "VaPremier/" + planYear + "/success" :
					"VaPremier/success", mapModel);
			//End: Added for IFOX-00407925

			return mv;
		//}
	}

	/**
	 * @param request
	 * @param response
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws ParseException
	 * @throws IOException
	 * @throws InterruptedException
	 */
	/**
	 * method to generate PDF
	 * 
	 * @param request
	 * @param response
	 * @param agreeDetailsVO
	 */
	@RequestMapping(value = "/printEnrollForms", method = RequestMethod.POST)
	public ModelAndView printEnrollForms(HttpServletRequest request, HttpServletResponse response,
			 AgreeDetailsVO agreeDetailsVO, BindingResult result) {
		LOGGER.info(" Start : In printEnrollForms() method of UserDetailsController class");
		try {

			if (agreeDetailsVO.getLegalState() != null && agreeDetailsVO.getLegalState().equalsIgnoreCase("None")) {
				agreeDetailsVO.setLegalState("");
			}
			if (agreeDetailsVO.getLegalRelationErloll() != null
					&& agreeDetailsVO.getLegalRelationErloll().equalsIgnoreCase("None")) {
				agreeDetailsVO.setLegalRelationErloll("");
			}

			// for agent id and agent name
			if (agreeDetailsVO.getAgentId() != null && agreeDetailsVO.getAgentId().equalsIgnoreCase("None")) {
				agreeDetailsVO.setAgentId("");
			}

			if (agreeDetailsVO.getAgentName() != null && agreeDetailsVO.getAgentName().equalsIgnoreCase("None")) {
				agreeDetailsVO.setAgentName("");
			}
			UserDetailsVO userDetailsVO = (UserDetailsVO) request.getSession().getAttribute("userDetailsObjForm1");
			agreeDetailsVO.setIcepDate(userDetailsVO.getBirthDate());

			request.getSession().setAttribute("agreeDetailsObjForm1", agreeDetailsVO);

			AgreeDetailsValidator agreeValidator = new AgreeDetailsValidator();
			agreeValidator.validate(agreeDetailsVO, result, null);
			if (result.hasErrors()) {
				return previousEnrollForm4(request, agreeDetailsVO);
			} else {

				if (agreeDetailsVO.getLegalState() != null && agreeDetailsVO.getLegalState().equalsIgnoreCase("None")) {
					agreeDetailsVO.setLegalState("");
				}
				if (agreeDetailsVO.getLegalRelationErloll() != null
						&& agreeDetailsVO.getLegalRelationErloll().equalsIgnoreCase("None")) {
					agreeDetailsVO.setLegalRelationErloll("");
				}
				// for agent id and agent name
				if (agreeDetailsVO.getAgentId() != null && agreeDetailsVO.getAgentId().equalsIgnoreCase("None")) {
					agreeDetailsVO.setAgentId("");
				}

				if (agreeDetailsVO.getAgentName() != null && agreeDetailsVO.getAgentName().equalsIgnoreCase("None")) {
					agreeDetailsVO.setAgentName("");
				}

				Map<String, Boolean> cityStateMap = userDetailsService
						.validateAgreeStateAndCityValuesFromDB(agreeDetailsVO);

				agreeValidator.validate(agreeDetailsVO, result, cityStateMap);
				if (result.hasErrors()) {
					return previousEnrollForm4(request, agreeDetailsVO);
				}

				// String appl_year = (String)
				// request.getSession().getAttribute("appl_year");
				// if (appl_year.equalsIgnoreCase("2015")) {
				
				String planYear = (String) request.getSession().getAttribute("planYear");
				LOGGER.info(" VaPremierController : printEnrollForms : planYear [" + planYear + "] ");
				if(Integer.parseInt(planYear) > 2018)
				{
					PDFUtilLatest2019.showEnrollFromsInPDF(request, response);
				} else {
					PDFUtilLatest.showEnrollFromsInPDF(request, response);
				}
				
				
				// } else {
				// PDFUtil.showEnrollFromsInPDF(request, response);
				// }

			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return null;
	}

	// get agent id button code

	@RequestMapping(value = "/getAgtId", method = RequestMethod.POST)
	public ModelAndView getOptimaAgentId(HttpServletRequest request, HttpServletResponse response,
			AgreeDetailsVO agreeDetailsVO, BindingResult result) {

		LOGGER.info(" Start : In getOptimaAgentId() method of VaPremierController class");
		try {
			// for agent id and agent name

			if (agreeDetailsVO.getAgentName() != null && agreeDetailsVO.getAgentName().equalsIgnoreCase("None")) {
				agreeDetailsVO.setAgentName("");
			}

			// for agent id and agent name

			if (agreeDetailsVO.getAgentName() != null && agreeDetailsVO.getAgentName().equalsIgnoreCase("None")) {
				agreeDetailsVO.setAgentName("");
			}
			String agentId = userDetailsService.getOptimaAgentIdFromDB(agreeDetailsVO);
			agreeDetailsVO.setAgentId(agentId);
			LOGGER.info("Agent Id :" + agreeDetailsVO.getAgentName());
			LOGGER.info("Agent Id :" + agreeDetailsVO.getAgentIdNameCheck());
			LOGGER.info("agreeDetailsVO.getAgentId() Id :" + agreeDetailsVO.getAgentId());
			request.getSession().setAttribute("agreeDetailsObjForm1", agreeDetailsVO);
			LOGGER.info("Session setting done.........");

		} catch (Exception e) {
		}
		return previousEnrollForm4(request, agreeDetailsVO);

		/*
		 * request.getSession().setAttribute("agreeDetailsObjForm1",
		 * agreeDetailsVO); return previousEnrollForm4( request,
		 * agreeDetailsVO);
		 */

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/previousEnrollForm1", method = RequestMethod.POST)
	public ModelAndView previousEnrollForm1(HttpServletRequest request, UserDetailsVO ud) {

		//Begin: Added for IFOX-00407925
		String planYear = (String) request.getSession().getAttribute("planYear");
		LOGGER.info(" VaPremierController : previousEnrollForm1 : planYear [" + planYear + "] ");
		//End: Added for IFOX-00407925
		
		if (request.getSession().getAttribute("userDetailsObjForm1") == null) {
			
			//Begin: Added for IFOX-00407925
			ModelAndView mv = new ModelAndView(
					Integer.parseInt(planYear) > 2018 ? "VaPremier/" + planYear + "/test" :
					"VaPremier/test");
			//End: Added for IFOX-00407925
			
			return mv;
		}

		LOGGER.info(" Start : In previousEnrollForm1() method of UserDetailsController class");
		UserDetailsVO userDetailsVO = (UserDetailsVO) request.getSession().getAttribute("userDetailsObjForm1");

		HashMap mapModel = new HashMap();
		mapModel.put("optimaPlanSessionVal", userDetailsVO.getOptimaMedicare());
		mapModel.put("lnSessionValue", userDetailsVO.getLastName());
		mapModel.put("fnSessionValue", userDetailsVO.getFirstName());
		mapModel.put("miSessionValue", userDetailsVO.getMiddleInitial());
		mapModel.put("sfxSessionValue", userDetailsVO.getSuffix());
		mapModel.put("bdSessionValue", userDetailsVO.getBirthDate());
		mapModel.put("sexSessionValue", userDetailsVO.getSex());
		mapModel.put("hphSessionValue", userDetailsVO.getHomePhNumber());
		mapModel.put("aphSessionValue", userDetailsVO.getAltrPhNumber());
		mapModel.put("emailSessionValue", userDetailsVO.getEmailAddr());
		mapModel.put("paSessionValue", userDetailsVO.getPermanentAddr());
		mapModel.put("paStrtSessionValue", userDetailsVO.getPermanentStrt());
		mapModel.put("paptSessionValue", userDetailsVO.getPermanentApt());
		mapModel.put("pcSessionValue", userDetailsVO.getPermanentCity());
		mapModel.put("psSessionValue", userDetailsVO.getPermanentState());
		mapModel.put("pzSessionValue", userDetailsVO.getPermanentZip());
		mapModel.put("maSessionValue", userDetailsVO.getMailingAddr());
		mapModel.put("maStrtSessionValue", userDetailsVO.getMailingStrt());
		mapModel.put("maptSessionValue", userDetailsVO.getMailingApt());
		mapModel.put("mcSessionValue", userDetailsVO.getMailingCity());
		mapModel.put("effDateSessionValue", userDetailsVO.getEffDate());

		// test

		// mapModel.put("errorhomePhNumberValue",request.getSession().getAttribute("errorhomePhNumberValue"));
		// System.out.println("error
		// valu"+request.getSession().getAttribute("errorhomePhNumberValue"));

		mapModel.put("errorhomePhNumberValue", userDetailsVO.getErrorhomePhNumberValue());
		mapModel.put("errorlastNameValue", userDetailsVO.getErrorlastNameValue());
		mapModel.put("errorfirstNameValue", userDetailsVO.getErrorfirstNameValue());
		mapModel.put("errormiddleInitialValue", userDetailsVO.getErrormiddleInitialValue());
		mapModel.put("errorbirthDateValue", userDetailsVO.getErrorbirthDateValue());
		mapModel.put("erroraltrPhNumberValue", userDetailsVO.getErroraltrPhNumberValue());
		mapModel.put("erroremailAddrValue", userDetailsVO.getErroremailAddrValue());
		mapModel.put("errormailingZipValue", userDetailsVO.getErrormailingZipValue());
		mapModel.put("erroremergencyContValue", userDetailsVO.getErroremergencyContValue());
		mapModel.put("erroremergencyRelValue", userDetailsVO.getErroremergencyRelValue());
		
		//Begin: Added for IFOX-00390786 (Phase-II)
		mapModel.put("errorpermanentAptValue", userDetailsVO.getErrorpermanentAptValue());
		mapModel.put("errorbeneficiarySexValue", userDetailsVO.getErrorbeneficiarySexValue());
		mapModel.put("errorpermanentStrtValue", userDetailsVO.getErrorpermanentStrtValue());
		mapModel.put("errorstateMedicaidValue", userDetailsVO.getErrorstateMedicaidValue());
		mapModel.put("errormedicaidNumberValue", userDetailsVO.getErrormedicaidNumberValue());
		//End: Added for IFOX-00390786 (Phase-II)

		mapModel.put("erroremergPhNumValue", userDetailsVO.getErroremergPhNumValue());
		mapModel.put("errorpermanentAddrValue", userDetailsVO.getErrorpermanentAddrValue());
		mapModel.put("errorpermanentCityValue", userDetailsVO.getErrorpermanentCityValue());
		mapModel.put("errorpermanentStateValue", userDetailsVO.getErrorpermanentStateValue());
		mapModel.put("errorpermanentZipValue", userDetailsVO.getErrorpermanentZipValue());
		mapModel.put("errornameBeneficiaryValue", userDetailsVO.getErrornameBeneficiaryValue());
		mapModel.put("errorMediacrdNumberValue", userDetailsVO.getErrorMediacrdNumberValue());
		mapModel.put("errorhospitalDateValue", userDetailsVO.getErrorhospitalDateValue());
		mapModel.put("errormedicalDateValue", userDetailsVO.getErrormedicalDateValue());
		mapModel.put("errorpermCityStateValue", userDetailsVO.getErrorpermCityStateValue());
		mapModel.put("errormailingCityStateValue", userDetailsVO.getErrormailingCityStateValue());
		mapModel.put("errorphysicianValue", userDetailsVO.getErrorphysicianValue());
		mapModel.put("erroreffDateValue", userDetailsVO.getErroreffDateValue());

		if (userDetailsVO.getMailingState() != null && userDetailsVO.getMailingState().equalsIgnoreCase("None")) {
			userDetailsVO.setMailingState("");
		}
		mapModel.put("msSessionValue", userDetailsVO.getMailingState());
		mapModel.put("mzSessionValue", userDetailsVO.getMailingZip());
		mapModel.put("ecSessionValue", userDetailsVO.getEmergencyCont());
		mapModel.put("ephnSessionValue", userDetailsVO.getEmergPhNum());
		if (userDetailsVO.getPhysician() != null && !(userDetailsVO.getPhysician().equalsIgnoreCase("None"))) {
			String input = userDetailsVO.getPhysician();
			Matcher matcher = Pattern.compile("(?<=-).*").matcher(input);
			matcher.find();
			if (matcher.groupCount() > 0) {
				mapModel.put("phySessionValue", matcher.group());
				
			} else {
				mapModel.put("phySessionValue", userDetailsVO.getPhysician());
				mapModel.put("phyNameSessionValue", userDetailsVO.getPhysicianName());
			}
		} else {
			mapModel.put("phySessionValue", userDetailsVO.getPhysician());
			mapModel.put("phyNameSessionValue", userDetailsVO.getPhysicianName());
		}
		if (userDetailsVO.getRelationYou() != null && userDetailsVO.getRelationYou().equalsIgnoreCase("None")) {
			userDetailsVO.setRelationYou("");
		}
		mapModel.put("rySessionValue", userDetailsVO.getRelationYou());
		mapModel.put("bnSessionValue", userDetailsVO.getNameBeneficiary());
		mapModel.put("mcnSessionValue", userDetailsVO.getMediacrdNumber());
		mapModel.put("bsSessionValue", userDetailsVO.getBeneficiarySex());
		mapModel.put("hdSessionValue", userDetailsVO.getHospitalDate());
		mapModel.put("mdSessionValue", userDetailsVO.getMedicalDate());
		
		Map physicanMapDB = (Map) request.getSession().getAttribute("physicianMap");
		Map stateMapDB = (Map) request.getSession().getAttribute("stateMap");
		Map mailStateMapDB = (Map) request.getSession().getAttribute("mailStateMap");
		Map relationsMapEnrolee = (Map) request.getSession().getAttribute("relationsMap");
		mapModel.put("physicians", physicanMapDB);
		mapModel.put("physiciansPipeString", getPipeSepString(physicanMapDB));
		mapModel.put("states", stateMapDB);
		mapModel.put("mailStates", mailStateMapDB);
		mapModel.put("relations", relationsMapEnrolee);

		// String appl_year = (String)
		// request.getSession().getAttribute("appl_year");
		// if (appl_year != null && appl_year.equalsIgnoreCase("2015")) {
		
		//Begin: Added for IFOX-00407925
		ModelAndView mv = new ModelAndView(
				Integer.parseInt(planYear) > 2018 ? "VaPremier/" + planYear + "/enrollemntForm1" :
				"VaPremier/enrollemntForm1_2017", mapModel);
		//End: Added for IFOX-00407925
		
		return mv;
		// } else {
		// ModelAndView mv = new ModelAndView("enrollment/enrollemntForm1",
		// mapModel);
		// return mv;
		// }

	}

	/**
	 * @param request
	 * @param pd
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/previousEnrollForm2", method = RequestMethod.POST)
	public ModelAndView previousEnrollForm2(HttpServletRequest request, PolicyDetailsVO pd) {

		//Begin: Added for IFOX-00407925
		String planYear = (String) request.getSession().getAttribute("planYear");
		LOGGER.info(" VaPremierController : previousEnrollForm2 : planYear [" + planYear + "] ");
		//End: Added for IFOX-00407925
		
		if (request.getSession().getAttribute("policyDetailsObjForm1") == null) {
			
			//Begin: Added for IFOX-00407925
			ModelAndView mv = new ModelAndView(
					Integer.parseInt(planYear) > 2018 ? "VaPremier/" + planYear + "/test" :
					"VaPremier/test");
			//End: Added for IFOX-00407925
			
			return mv;
		}

		LOGGER.info(" Start : In previousEnrollForm2() method of UserDetailsController class");
		PolicyDetailsVO policyDetailsVO = (PolicyDetailsVO) request.getSession().getAttribute("policyDetailsObjForm1");
		HashMap mapModel = new HashMap();
		mapModel.put("planSessionValue", policyDetailsVO.getPalnName());
		mapModel.put("policySessionvalue", policyDetailsVO.getPolicyNumber());
		mapModel.put("beginingSessionvalue", policyDetailsVO.getBeginingDate());
		mapModel.put("etfSessionvalue", policyDetailsVO.getPaymentOption());
		mapModel.put("monthBillSessionvalue", policyDetailsVO.getPaymentOption());
		mapModel.put("accHolderSessionvalue", policyDetailsVO.getAccountHolderName());
		mapModel.put("bankAccSessionvalue", policyDetailsVO.getBankAccountNumber());
		mapModel.put("bankRoutingSessionvalue", policyDetailsVO.getBankRoutingNumber());
		mapModel.put("autoDedSessionvalue", policyDetailsVO.getAutoDeduction());
		mapModel.put("renalDiseaseSessionvalue", policyDetailsVO.getRenalDisease());
		mapModel.put("healthBenSessionvalue", policyDetailsVO.getHealthBenefits());
		mapModel.put("medicaNameSessionvalue", policyDetailsVO.getMedicalNameCoverage());
		mapModel.put("othMedicNameSessionvalue", policyDetailsVO.getOtherMedicalNameCoverage());
		
		mapModel.put("customeridSessionvalue", customer_id);

		mapModel.put("medicGroupSessionvalue", policyDetailsVO.getMedicalGroupCoverage());
		mapModel.put("othMedicGroupSessionvalue", policyDetailsVO.getOtherMedicalGroupCoverage());
		mapModel.put("medicIdSessionvalue", policyDetailsVO.getMedicalIdCoverage());
		mapModel.put("othMedicIdSessionvalue", policyDetailsVO.getOtherMedicalIdCoverage());
		mapModel.put("medicCoveragePeriodSessionvalue", policyDetailsVO.getMedicalCoveragePeriod());
		mapModel.put("othMedicCoveragPeriodSessionvalue", policyDetailsVO.getOtherMedicalCoveragePeriod());
		
		
		mapModel.put("nursingHomeSessionvalue", policyDetailsVO.getNursingHome());
		mapModel.put("instituteNameSessionvalue", policyDetailsVO.getInstituteName());
		mapModel.put("instituteAddressSessionvalue", policyDetailsVO.getInstituteAddress());
		mapModel.put("instituteOtherAddressSessionvalue", policyDetailsVO.getInstituteOtherAddress());
		mapModel.put("institutePhoneSessionvalue", policyDetailsVO.getInstitutePhone());
		
		mapModel.put("stateMedicaidSessionvalue", policyDetailsVO.getStateMedicaid());
		mapModel.put("medicaidNumberSessionvalue", policyDetailsVO.getMedicaidNumber());
		mapModel.put("spouseSessionvalue", policyDetailsVO.getSpouse());
		
		mapModel.put("prescDrugSessionvalue", policyDetailsVO.getPrescriptionDrug());
		mapModel.put("drugNameSessionvalue", policyDetailsVO.getDurgNameCoverage());
		mapModel.put("drugGroupCovSessionvalue", policyDetailsVO.getDurgGroupCoverage());
		mapModel.put("drugIdSessionvalue", policyDetailsVO.getDurgIdCoverage());
		mapModel.put("drugCovPeriodSessionvalue", policyDetailsVO.getDurgCoveragePeriod());

		mapModel.put("erroraccountHolderNameValue", policyDetailsVO.getErroraccountHolderNameValue());
		mapModel.put("errorbankRoutingNumberValue", policyDetailsVO.getErrorbankRoutingNumberValue());
		mapModel.put("errorbankAccountNumberValue", policyDetailsVO.getErrorbankAccountNumberValue());
		mapModel.put("errorbeginingDateValue", policyDetailsVO.getErrorbeginingDateValue());

		//Begin: Added for IFOX-00390786 (Phase-II)
		Map institutionsMap = (Map) request.getSession().getAttribute("institutionsMap");
		if(null == institutionsMap)
			institutionsMap = new HashMap<String, String>();

		mapModel.put("institutionsPipeString", getPipeSepString(institutionsMap));
		mapModel.put("institutionAddressPipeString", (String) request.getSession().getAttribute("institutionAddressPipeString"));

		if (null != policyDetailsVO.getInstituteName() && !policyDetailsVO.getInstituteName().trim().equals(""))
		{
			String instituteName = policyDetailsVO.getInstituteName();
			Matcher matcher = Pattern.compile("(?<=-).*").matcher(instituteName);
			matcher.find();
			if (matcher.groupCount() > 0)
			{
				mapModel.put("instituteNameSessionvalue", matcher.group());
			} else {
				mapModel.put("instituteNameSessionvalue", policyDetailsVO.getInstituteName());
				mapModel.put("instituteNameSessionValue1", policyDetailsVO.getInstitutionalName());
			}
		} else {
			mapModel.put("instituteNameSessionvalue", policyDetailsVO.getInstituteName());
			mapModel.put("instituteNameSessionValue1", policyDetailsVO.getInstitutionalName());
		}
		//End: Added for IFOX-00390786 (Phase-II)
		
		/* IFOX-00419836 2020 AEP changes. START*/
		LOGGER.info(" Start : In previousEnrollForm1() method of UserDetailsController class");
		
		if (policyDetailsVO.getPhysician() != null && !(policyDetailsVO.getPhysician().equalsIgnoreCase("None"))) {
			String input = policyDetailsVO.getPhysician();
			Matcher matcher = Pattern.compile("(?<=-).*").matcher(input);
			matcher.find();
			if (matcher.groupCount() > 0) {
				mapModel.put("phySessionValue", matcher.group());
				
			} else {
				mapModel.put("phySessionValue", policyDetailsVO.getPhysician());
				mapModel.put("phyNameSessionValue", policyDetailsVO.getPhysicianName());
			}
		} else {
			mapModel.put("phySessionValue", policyDetailsVO.getPhysician());
			mapModel.put("phyNameSessionValue", policyDetailsVO.getPhysicianName());
		}
		
		mapModel.put("physicians", request.getSession().getAttribute("physicianMap"));
		mapModel.put("physiciansPipeString", getPipeSepString((Map)request.getSession().getAttribute("physicianMap")));
		/* IFOX-00419836 2020 AEP changes. END*/
		
		// String appl_year = (String)
		// request.getSession().getAttribute("appl_year");
		// if (appl_year.equalsIgnoreCase("2015")) {

		//Begin: Added for IFOX-00407925
		ModelAndView mv = new ModelAndView(
				Integer.parseInt(planYear) > 2018 ? "VaPremier/" + planYear + "/enrollemntForm2" :
				"VaPremier/enrollemntForm2_2017", mapModel);
		//End: Added for IFOX-00407925
		
		return mv;
		// } else {

		// ModelAndView mv = new ModelAndView("enrollment/enrollemntForm2",
		// mapModel);
		// return mv;
		// }

	}

	/**
	 * @param request
	 * @param ad
	 * @return
	 */
	@RequestMapping(value = "/previousEnrollForm3", method = RequestMethod.POST)
	public ModelAndView previousEnrollForm3(HttpServletRequest request, AttestationDetailsVO ad) {

		//Begin: Added for IFOX-00407925
		String planYear = (String) request.getSession().getAttribute("planYear");
		LOGGER.info(" VaPremierController : previousEnrollForm3 : planYear [" + planYear + "] ");
		//End: Added for IFOX-00407925
		
		if (request.getSession().getAttribute("attestationDetailsObjForm1") == null) {
			
			//Begin: Added for IFOX-00407925
			ModelAndView mv = new ModelAndView(
					Integer.parseInt(planYear) > 2018 ? "VaPremier/" + planYear + "/test" :
					"VaPremier/test");
			//End: Added for IFOX-00407925
			
			return mv;
		}
		LOGGER.info(" Start : In previousEnrollForm3() method of UserDetailsController class");
		AttestationDetailsVO attestationDetailsVO = (AttestationDetailsVO) request.getSession()
				.getAttribute("attestationDetailsObjForm1");
		HashMap<String, String> mapModel = new HashMap<String, String>();
		
		mapModel.put("pflSeValue", attestationDetailsVO.getPreferlargePrint());
		
		// for 2015 application
		mapModel.put("pfbrSeValue", attestationDetailsVO.getPreferBraille());
		

		//String appl_year = (String) request.getSession().getAttribute("appl_year");
		// if (appl_year.equalsIgnoreCase("2015")) {

		//Begin: Added for IFOX-00407925
		ModelAndView mv = new ModelAndView(
				Integer.parseInt(planYear) > 2018 ? "VaPremier/" + planYear + "/enrollemntForm3" :
				"VaPremier/enrollemntForm3_2017", mapModel);
		//End: Added for IFOX-00407925
		
		return mv;
		// } else {

		// ModelAndView mv = new ModelAndView("enrollment/enrollemntForm3",
		// mapModel);
		// return mv;
		// }

	}

	/**
	 * @param request
	 * @param agd
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/previousEnrollForm4", method = RequestMethod.POST)
	public ModelAndView previousEnrollForm4(HttpServletRequest request, AgreeDetailsVO agd) {

		//Begin: Added for IFOX-00407925
		String planYear = (String) request.getSession().getAttribute("planYear");
		LOGGER.info(" VaPremierController : previousEnrollForm4 : planYear [" + planYear + "] ");
		//End: Added for IFOX-00407925
		
		if (request.getSession().getAttribute("agreeDetailsObjForm1") == null) {
			
			//Begin: Added for IFOX-00407925
			ModelAndView mv = new ModelAndView(
					Integer.parseInt(planYear) > 2018 ? "VaPremier/" + planYear + "/test" :
					"VaPremier/test");
			//End: Added for IFOX-00407925
			
			return mv;
		}
		LOGGER.info(" Start : In previousEnrollForm4() method of UserDetailsController class");
		AgreeDetailsVO agreeDetailsVO = (AgreeDetailsVO) request.getSession().getAttribute("agreeDetailsObjForm1");
		@SuppressWarnings("rawtypes")
		HashMap mapModel = new HashMap();
		mapModel.put("asSeValue", agreeDetailsVO.getAgreeStatements());
		mapModel.put("tdSeValue", agreeDetailsVO.getTodayDate());
		mapModel.put("lnSeValue", agreeDetailsVO.getLegalFirstName());
		mapModel.put("lnlastSeValue", agreeDetailsVO.getLegalLastName());
		mapModel.put("lnmiddleSeValue", agreeDetailsVO.getLegalMiddleName());
		mapModel.put("laSeValue", agreeDetailsVO.getLegalAddress());
		mapModel.put("latwoSeValue", agreeDetailsVO.getLegalAddressTwo());
		mapModel.put("lathreeSeValue", agreeDetailsVO.getLegalAddressThree());
		mapModel.put("laCitySeValue", agreeDetailsVO.getLegalCity());
		mapModel.put("laStateSeValue", agreeDetailsVO.getLegalState());
		mapModel.put("laZipSeValue", agreeDetailsVO.getLegalZipCode());
		mapModel.put("lphSeValue", agreeDetailsVO.getLegalPhNumber());
		mapModel.put("eligbEnrollSeValue", agreeDetailsVO.getEligibleEnroll());
		mapModel.put("recntCreditSeValue", agreeDetailsVO.getRecentlyCreditable());
		mapModel.put("newElgMedicSeValue", agreeDetailsVO.getNewlyEligbleMedicare());
		mapModel.put("revMedDrugSeValue", agreeDetailsVO.getRecieveMedicareDrugs());
		mapModel.put("levEmpCvgSeValue", agreeDetailsVO.getLeavingEmployerCoverage());
		mapModel.put("noElgbPrescDrugSeValue", agreeDetailsVO.getNoEligbPrescDrugs());
		mapModel.put("recntMovdOptSeValue", agreeDetailsVO.getRecentMovedOption());
		mapModel.put("recntMovdOutSideSeValue", agreeDetailsVO.getRecntMovedOutSide());
		mapModel.put("rcntLeftPlacSeValue", agreeDetailsVO.getRecntLeftPace());
		mapModel.put("plendCntSeValue", agreeDetailsVO.getPlanEndingContract());
		mapModel.put("blnStPhSeValue", agreeDetailsVO.getBelongStatePharmacy());
		mapModel.put("nonAppMeSeValue", agreeDetailsVO.getNoneApplyMe());
		mapModel.put("mvdusSeValue", agreeDetailsVO.getMovedBackUs());
		mapModel.put("unCovSeValue", agreeDetailsVO.getUnionCoverage());
		
		mapModel.put("agtIDSeValue", agreeDetailsVO.getAgentId()); //Added for IFOX-00397099
		
		mapModel.put("mcNumSeValue", agreeDetailsVO.getMedicardNumber());
		mapModel.put("outLngTermFcSeValue", agreeDetailsVO.getOutLongTermFacility());
		mapModel.put("nameInstSeValue", agreeDetailsVO.getNameOfInst());
		mapModel.put("phNumSeValue", agreeDetailsVO.getPhNum());
		mapModel.put("adrStrSeValue", agreeDetailsVO.getAdressInstStreet());
		mapModel.put("adrsInstSeValue", agreeDetailsVO.getAdressInstNumber());
		mapModel.put("noElgbspSeValue", agreeDetailsVO.getNoEligSpecial());
		mapModel.put("otherResSeValue", agreeDetailsVO.getOtherReasons());
		mapModel.put("prefEmailSeValue", agreeDetailsVO.getPreferEmail());
		mapModel.put("prefCdSeValue", agreeDetailsVO.getPreferCd());
		mapModel.put("recntChBoxSeValue", agreeDetailsVO.getTrcntCreditChBox());
		mapModel.put("recntChBoxSeValue", agreeDetailsVO.getTrcntCreditChBox());
		mapModel.put("preferAudioTape", agreeDetailsVO.getPreferAudioTape());

		// newly added
		mapModel.put("errortrcntCreditChBoxValue", agreeDetailsVO.getErrortrcntCreditChBoxValue());
		mapModel.put("errornewElgbChBoxValue", agreeDetailsVO.getErrornewElgbChBoxValue());
		mapModel.put("errorrevMedChBoxValue", agreeDetailsVO.getErrorrevMedChBoxValue());
		mapModel.put("errorlevEmpChBoxValue", agreeDetailsVO.getErrorlevEmpChBoxValue());
		mapModel.put("errornlElgPrescChBoxValue", agreeDetailsVO.getErrornlElgPrescChBoxValue());
		mapModel.put("errorrecntMovChBoxValue", agreeDetailsVO.getErrorrecntMovChBoxValue());
		mapModel.put("errorrecnMovOutChBoxValue", agreeDetailsVO.getErrorrecnMovOutChBoxValue());
		mapModel.put("errorrecntleftPlChBoxValue", agreeDetailsVO.getErrorrecntleftPlChBoxValue());
		mapModel.put("errormvdUsChBoxValue", agreeDetailsVO.getErrormvdUsChBoxValue());
		mapModel.put("errorunCovChBoxValue", agreeDetailsVO.getErrorunCovChBoxValue());
		
		mapModel.put("errormcNumChBoxValue", agreeDetailsVO.getErrormcNumChBoxValue());
		mapModel.put("erroroutLngTermFcSeeChBoxValue", agreeDetailsVO.getErroroutLngTermFcSeeChBoxValue());
		mapModel.put("errornoElgbspseChBoxValue", agreeDetailsVO.getErrornoElgbspseChBoxValue());
		mapModel.put("errorprefEmailChBoxValue", agreeDetailsVO.getErrorprefEmailChBoxValue());
		mapModel.put("erropreferEmailValue", agreeDetailsVO.getErropreferEmailValue());
		mapModel.put("errorphNumValue", agreeDetailsVO.getErrorphNumValue());
		mapModel.put("errorrecentlyCreditableValue", agreeDetailsVO.getErrorrecentlyCreditableValue());
		mapModel.put("errornewlyEligbleMedicareValue", agreeDetailsVO.getErrornewlyEligbleMedicareValue());
		mapModel.put("errorrecieveMedicareDrugsValue", agreeDetailsVO.getErrorrecieveMedicareDrugsValue());
		mapModel.put("errorleavingEmployerCoverageValue", agreeDetailsVO.getErrorleavingEmployerCoverageValue());
		mapModel.put("errornoEligbPrescDrugsValue", agreeDetailsVO.getErrornoEligbPrescDrugsValue());
		mapModel.put("errorrecentMovedOptionValue", agreeDetailsVO.getErrorrecentMovedOptionValue());
		mapModel.put("errorrecntMovedOutSideValue", agreeDetailsVO.getErrorrecntMovedOutSideValue());
		mapModel.put("errorrecntLeftPaceValue", agreeDetailsVO.getErrorrecntLeftPaceValue());
		mapModel.put("errormovedBackUsValue", agreeDetailsVO.getErrormovedBackUsValue());
		mapModel.put("errorUnionCoverageValue", agreeDetailsVO.getErrorUnionCoverageValue());
		
		
		//Begin: Added for 2019 Attestation Changes
		mapModel.put("MAOEPChange", agreeDetailsVO.getMAOEPChange());
		
		mapModel.put("changeInMedicaidSeValue", agreeDetailsVO.getChangeInMedicaid());
		mapModel.put("errorChangeInMedicaidChBoxValue", agreeDetailsVO.getErrorChangeInMedicaidChBoxValue());
		mapModel.put("errorChangeInMedicaidValue", agreeDetailsVO.getErrorChangeInMedicaidValue());

		mapModel.put("changeInExtraHelpSeValue", agreeDetailsVO.getChangeInExtraHelp());
		mapModel.put("errorChangeInExtraHelpChBoxValue", agreeDetailsVO.getErrorChangeInExtraHelpChBoxValue());
		mapModel.put("errorChangeInExtraHelpValue", agreeDetailsVO.getErrorChangeInExtraHelpValue());
		
		mapModel.put("changeInMedicareSeValue", agreeDetailsVO.getChangeInMedicare());
		mapModel.put("errorChangeInMedicareChBoxValue", agreeDetailsVO.getErrorChangeInMedicareChBoxValue());
		mapModel.put("errorChangeInMedicareValue", agreeDetailsVO.getErrorChangeInMedicareValue());
		
		mapModel.put("affectedByDisaster", agreeDetailsVO.getAffectedByDisaster());
		//End: Added for 2019 Attestation Changes
		
		mapModel.put("erroroutLongTermFacilityValue", agreeDetailsVO.getErroroutLongTermFacilityValue());
		mapModel.put("errornoEligSpecialValue", agreeDetailsVO.getErrornoEligSpecialValue());
		if (agreeDetailsVO.getLegalRelationErloll() != null
				&& agreeDetailsVO.getLegalRelationErloll().equalsIgnoreCase("None")) {
			agreeDetailsVO.setLegalRelationErloll("");
		}

		mapModel.put("lreSeValue", agreeDetailsVO.getLegalRelationErloll());
		mapModel.put("waSeValue", agreeDetailsVO.getWebtelApp());
		mapModel.put("agnaSeValue", agreeDetailsVO.getAgentName());
		mapModel.put("agidSeValue", agreeDetailsVO.getAgentId());
		mapModel.put("plidSeValue", agreeDetailsVO.getPlanId());
		mapModel.put("effdtSeValue", agreeDetailsVO.getEffectDateCoverage());
		mapModel.put("icepSeValue", agreeDetailsVO.getAep());
		mapModel.put("aepSeValue", agreeDetailsVO.getAep());
		mapModel.put("sepSeValue", agreeDetailsVO.getAep());
		mapModel.put("notEligValue", agreeDetailsVO.getAep());

		// Map stateMapDB =(Map) request.getSession().getAttribute("stateMap");
		Map mailStateMapDB = (Map) request.getSession().getAttribute("mailStateMap");
		Map relationsMapDB = (Map) request.getSession().getAttribute("relationsMap");
		// for agent names
		Map agentNamesDB = (Map) request.getSession().getAttribute("agentNamesMap");
		// mapModel.put("states", stateMapDB);
		mapModel.put("mailStates", mailStateMapDB);
		// for agent names
		mapModel.put("agentNames", agentNamesDB);
		mapModel.put("relations", relationsMapDB);

		// newly added
		mapModel.put("errortodayDateValue", agreeDetailsVO.getErrortodayDateValue());
		mapModel.put("errorlegalRelationErlollValue", agreeDetailsVO.getErrorlegalRelationErlollValue());
		mapModel.put("erroragentNameValue", agreeDetailsVO.getErroragentNameValue());
		mapModel.put("erroragentIdValue", agreeDetailsVO.getErroragentIdValue());
		mapModel.put("errorplanIdValue", agreeDetailsVO.getErrorplanIdValue());
		mapModel.put("erroricepValue", agreeDetailsVO.getErroricepValue());
		mapModel.put("erroraepValue", agreeDetailsVO.getErroraepValue());
		mapModel.put("errorsepValue", agreeDetailsVO.getErrorsepValue());
		mapModel.put("errorlegalAddressValue", agreeDetailsVO.getErrorlegalAddressValue());
		
		//Begin: Added for IFOX-00390786 (Phase-II)
		mapModel.put("erroragreeStatementsValue", agreeDetailsVO.getErroragreeStatementsValue());
		mapModel.put("errorlegalFirstNameValue", agreeDetailsVO.getErrorlegalFirstNameValue());
		mapModel.put("errorlegalAddressTwoValue", agreeDetailsVO.getErrorlegalAddressTwoValue());
		//End: Added for IFOX-00390786 (Phase-II)
		
		mapModel.put("errorlegalPhNumberValue", agreeDetailsVO.getErrorlegalPhNumberValue());
		mapModel.put("errorlegalCityStateValue", agreeDetailsVO.getErrorlegalCityStateValue());
		mapModel.put("erroreffectDateCoverageValue", agreeDetailsVO.getErroreffectDateCoverageValue());
		mapModel.put("erroragentIdNameCheckValue", agreeDetailsVO.getErroragentIdNameCheckValue());

		// String appl_year = (String)
		// request.getSession().getAttribute("appl_year");
		// if (appl_year.equalsIgnoreCase("2015")) {

		//Begin: Added for IFOX-00407925
		ModelAndView mv = new ModelAndView(
				Integer.parseInt(planYear) > 2018 ? "VaPremier/" + planYear + "/enrollemntForm4" :
				"VaPremier/enrollemntForm4_2017", mapModel);
		//End: Added for IFOX-00407925
		
		return mv;
		// } else {
		// ModelAndView mv = new ModelAndView("enrollment/enrollemntForm4",
		// mapModel);
		// return mv;
		// }

	}

	/**
	 * Method for opening the application status page
	 * 
	 * @param request
	 * @param ud
	 * @return
	 */
	@RequestMapping(value = "/downloadPdfApplicationForm")
	public String showStatusApplication(HttpServletRequest request, UserDetailsVO ud) {
		LOGGER.info(" Start : In showPdfApplicationForm() method of UserDetailsController class");
		
		//Begin: Added for IFOX-00407925
		String planYear = (String) request.getSession().getAttribute("planYear");
		LOGGER.info(" VaPremierController : showStatusApplication : planYear [" + planYear + "] ");
		return Integer.parseInt(planYear) > 2018 ? "VaPremier/" + planYear + "/pdfApplicationForm" : "VaPremier/pdfApplicationForm";
		//End: Added for IFOX-00407925
	}

	/**
	 * Method to know the get the pdf file from database
	 * 
	 * @param request
	 * @param userDetailsVO
	 * @param result
	 * @return
	 * @throws IOException
	 */

	// commented baecause to get the pdf data from location

	/*
	 * @RequestMapping(value="/pdfApplication" ,method=RequestMethod.POST)
	 * public ModelAndView pdfApplication( HttpServletRequest
	 * request,HttpServletResponse response, UserDetailsVO userDetailsVO,
	 * BindingResult result) {
	 * 
	 * LOGGER.info(
	 * " Start : In pdfApplication() method of UserDetailsController class");
	 * request.getSession().setAttribute("userDetailsObjForm1", userDetailsVO);
	 * try{ int userId = userDetailsVO.getUserId(); byte[] getPdfBytes =
	 * userDetailsService.getPdfApplication(userId); if(getPdfBytes != null){
	 * byte[] getPdfBytesSave = Base64.decodeBase64(getPdfBytes);
	 * response.addHeader("Content-Disposition",
	 * "attachment;filename="+userId+"enrolled.pdf"); OutputStream os =
	 * response.getOutputStream(); os.write(getPdfBytesSave); os.flush();
	 * os.close(); }else{ ModelAndView mv = new
	 * ModelAndView("enrollment/invalidAppNumber"); return mv; }
	 * }catch(Exception e){ LOGGER.info(
	 * " error : In pdfApplication() method of UserDetailsController class");
	 * ModelAndView mv = new ModelAndView("enrollment/invalidAppNumber"); return
	 * mv; } return null; }
	 */
	@RequestMapping(value = "/pdfApplication", method = RequestMethod.POST)
	public ModelAndView pdfApplication(HttpServletRequest request, HttpServletResponse response,
			UserDetailsVO userDetailsVO, BindingResult result) {

		LOGGER.info(" Start : In pdfApplication() method of UserDetailsController class");
		
		//Begin: Added for IFOX-00407925
		String planYear = (String) request.getSession().getAttribute("planYear");
		LOGGER.info(" VaPremierController : pdfApplication : planYear [" + planYear + "] ");
		//End: Added for IFOX-00407925
		
		request.getSession().setAttribute("userDetailsObjForm1", userDetailsVO);
		try {
			DateFormat format = new SimpleDateFormat(VAPConstants.DBDateFormat);
			String timeStamp = format.format(new Date());
			Properties prop = new Properties();
			prop.load(VaPremierController.class.getClassLoader().getResourceAsStream("saveLocation.properties"));
			String pdfDirectoryPath = prop.getProperty("VAP.locationpath.pdfSave");
			boolean isFilePDFExctractedFromDB = false;
			int userId = userDetailsVO.getUserId();
			String idstring = Integer.toString(userId);
			System.out.println("Application #" + idstring);
			File folder = new File(pdfDirectoryPath);
			System.out.println(" VaPremierController : pdfApplication : pdfDirectoryPath [" + pdfDirectoryPath + "] ");
			
			String exactFileName = extractPDFFile(folder,idstring,response);
			// to check file is there or not
			if (!StringUtil.nonNullnonEmpty(exactFileName)) {
				System.out.println("Exctracting Application #"+idstring+" from Database.");
				byte[] buffer = userDetailsService.getPdfApplication(userId,VAPConstants.vapAccountId);
				if(buffer != null){
					String tempFileName = pdfDirectoryPath + "\\" + idstring + "_"+ timeStamp+"dbExtract.pdf";
					File signatureFile = new File(tempFileName);
					FileOutputStream osf = new FileOutputStream(signatureFile);
					isFilePDFExctractedFromDB = true;
					osf.write(Base64.decodeBase64(buffer));
					osf.flush();
					osf.close();
				}else{
					throw new Exception();
				}
				
			}
			if(isFilePDFExctractedFromDB)
				exactFileName = extractPDFFile(folder,idstring,response);
			
			if (!StringUtil.nonNullnonEmpty(exactFileName)) {
				ModelAndView mv = new ModelAndView("enrollment/invalidAppNumber");
				return mv;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.info(" error : In pdfApplication() method of UserDetailsController class : "  + e.getMessage());
			
			//Begin: Added for IFOX-00407925
			ModelAndView mv = new ModelAndView(
					Integer.parseInt(planYear) > 2018 ? "VaPremier/" + planYear + "/invalidAppNumber" :
					"VaPremier/invalidAppNumber");
			//End: Added for IFOX-00407925
			
			return mv;
		}
		return null;
	}
	private String extractPDFFile(File folder,String idstring,HttpServletResponse response){
		File[] listOfFiles = folder.listFiles();
		String exactFileName = null;
		System.out.println("Extracting PDF for Application#"+idstring);
		try {
			for (int i = 0; i < listOfFiles.length; i++) {
				File file = listOfFiles[i];
				if (file.isFile() && file.getName().endsWith(".pdf") && file.getName().startsWith(idstring)) {
					String fileName = file.getName();
					System.out.println(idstring+" Application FOUND in local server.");
					System.out.println("File name in specified path" + fileName);
					exactFileName = fileName;

					response.addHeader("Content-Disposition", "attachment;filename=" + idstring + "enrolled.pdf");
					OutputStream os = response.getOutputStream();
					byte[] buf = new byte[8192];
					InputStream is = new FileInputStream(file);
					int c = 0;
					while ((c = is.read(buf, 0, buf.length)) > 0) {
						os.write(buf, 0, c);
						os.flush();
					}
					os.close();
					is.close();
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return exactFileName;
	}
	
	//Begin: Making MedicaidId Field as Non Mandatory for DSNP plans
    private static String nonNullTrim(String s) {
        if (s == null)
            return "";
        return s.trim();
    }

    private String isDSNPPlan(String planId, String pbpId) {
    	if(nonNullTrim(planId).equals("H9877") && nonNullTrim(pbpId).equals("001") )
    		return "Y";
    	else
    		return "N";
    }
    //End: Making MedicaidId Field as Non Mandatory for DSNP plans
	
    private boolean isAEPPeriod(String strEffectiveDate, String strAEPStartDate, String strAEPEndDate)
    {
        Date currentDate = null;
        Date aepStartDate = null;
        Date aepEndDate = null;

    	try {
          SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy");
          currentDate = simpleDateFormat.parse(simpleDateFormat.format(new Date()));
          aepStartDate = simpleDateFormat.parse(strAEPStartDate);
          aepEndDate = simpleDateFormat.parse(strAEPEndDate);

          if( currentDate.compareTo(aepStartDate) >= 0 && currentDate.compareTo(aepEndDate) <= 0 ) {
        	  if(nonNullTrim(strEffectiveDate).equals("01/01/2018"))
        		  return true;
          } else {
        	  return false;
          }

    	} catch(ParseException exception) {
			LOGGER.error(" VaPremierController : isAEPPeriod : " + exception.getMessage());
			exception.printStackTrace();
    	}
    	return false;
    }

}
