package com.medicare.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.dao.IUserDetailsDAO;
import com.medicare.dao.UserDeatailsDAOImpl;
import com.medicare.model.UserDetails;
import com.medicare.vo.AgreeDetailsVO;
import com.medicare.vo.LoginVO;
import com.medicare.vo.UserDetailsVO;
@Service
public class UserDetailsServiceImpl implements IUserDetailsService {

	private final static Logger LOGGER = Logger.getLogger(UserDetailsServiceImpl.class.getName());
	

	private IUserDetailsDAO userDetailsDAO;
	
     @Autowired
	public void setUserDetailsDAO(IUserDetailsDAO userDetailsDAO) {
		this.userDetailsDAO = userDetailsDAO;
	}

	@Override
	public int saveUserDetails(UserDetails userDetails) {
		
		LOGGER.info(" Start : In saveUserDetails() method of UserDetailsServiceImpl class");
		try {
			int ackNum = userDetailsDAO.saveUserDetails(userDetails);
			System.out.println("ackNum : "+ackNum);
			return ackNum;
		} catch (Exception e) {
			LOGGER.info(" error : In saveUserDetails() method of UserDetailsServiceImpl class");
			return 0;
		}
	}

	@Override
	public byte[] getPdfApplication(int userId) {
		
		LOGGER.info(" Start : In getPdfApplication() method of UserDetailsServiceImpl class");
		try {
			
			byte[] pdfBytes =	userDetailsDAO.getPdfApplicationForm(userId);
			if(pdfBytes!=null){
			    return pdfBytes;
			}else{
				
				return null;
			}
		} catch (Exception e) {
			LOGGER.info(" error : In getPdfApplication() method of UserDetailsServiceImpl class");
			e.printStackTrace();
			return null;
		}
	}
	@Override
	public byte[] getPdfApplication(int userId,String customerID) {
		
		LOGGER.info(" Start : In getPdfApplication(int,String) method of UserDetailsServiceImpl class");
		try {
			
			byte[] pdfBytes =	userDetailsDAO.getPdfApplicationForm(userId,customerID);
			if(pdfBytes!=null){
			    return pdfBytes;
			}else{
				
				return null;
			}
		} catch (Exception e) {
			LOGGER.info(" error : In getPdfApplication(int,String) method of UserDetailsServiceImpl class");
			e.printStackTrace();
			return null;
		}
	}
	
	@Override
	public Map getPrePopulatedValuesFromDB(String customer_id) {
		
		LOGGER.info(" Start : In getPrePopulatedValuesFromDB() method of UserDetailsServiceImpl class");
		try {
			return userDetailsDAO.getPrePopulatedValuesFromDB(customer_id);
		} catch (Exception e) {
			LOGGER.info(" error : In getPrePopulatedValuesFromDB() method of UserDetailsServiceImpl class");
			e.printStackTrace();
		}

		return null;
	}
	@Override
	public Map getFirstPagePrePopulatedValues(String customer_id) {
		
		LOGGER.info(" Start : In getFirstPagePrePopulatedValues() method of UserDetailsServiceImpl class");
		try {
			return userDetailsDAO.getFirstPagePrePopulatedValues(customer_id);
		} catch (Exception e) {
			LOGGER.info(" error : In getFirstPagePrePopulatedValues() method of UserDetailsServiceImpl class");
			e.printStackTrace();
		}

		return null;
	}
	@Override
	public Map getSecondPagePrePopulatedValues(String customer_id) {
		
		LOGGER.info(" Start : In getSecondPagePrePopulatedValues() method of UserDetailsServiceImpl class");
		try {
			return userDetailsDAO.getSecondPagePrePopulatedValues(customer_id);
		} catch (Exception e) {
			LOGGER.info(" error : In getSecondPagePrePopulatedValues() method of UserDetailsServiceImpl class");
			e.printStackTrace();
		}

		return null;
	}
	@Override
	public Map getFouthPagePrePopulatedValues(String customer_id) {
		
		LOGGER.info(" Start : In getFouthPagePrePopulatedValues() method of UserDetailsServiceImpl class");
		try {
			return userDetailsDAO.getFouthPagePrePopulatedValues(customer_id);
		} catch (Exception e) {
			LOGGER.info(" error : In getFouthPagePrePopulatedValues() method of UserDetailsServiceImpl class");
			e.printStackTrace();
		}

		return null;
	}
	@Override
	public Map<String, Boolean> validateStateAndCityValuesFromDB(UserDetailsVO userDetailsVO) {
		
		LOGGER.info(" Start : In validateStateAndCityValuesFromDB() method of UserDetailsServiceImpl class");
		try {
			return userDetailsDAO.validateStateAndCityValuesFromDB(userDetailsVO);
		} catch (Exception e) {
			LOGGER.info(" error : In validateStateAndCityValuesFromDB() method of UserDetailsServiceImpl class");
			e.printStackTrace();
		}

		return null;
	}
	
	@Override
	public String isPermStateCityZipIsValid(UserDetailsVO userDetailsVO) {
		return userDetailsDAO.isPermStateCityZipIsValid(userDetailsVO);
	}

	@Override
	public Map<String, Boolean> validateAgreeStateAndCityValuesFromDB(
			AgreeDetailsVO agd) {
		LOGGER.info(" Start : In validateAgreeStateAndCityValuesFromDB() method of UserDetailsServiceImpl class");
		try {
			return userDetailsDAO.validateAgreeStateAndCityValuesFromDB(agd);
		} catch (Exception e) {
			LOGGER.info(" error : In validateAgreeStateAndCityValuesFromDB() method of UserDetailsServiceImpl class");
			e.printStackTrace();
		}

		return null;
  }
	
	@Override
	public int getSequenecNumber() {
		LOGGER.info(" Start : In seqnum method of UserDetailsServiceImpl class");
		try {
			int seqNum = userDetailsDAO.getSequenecNumber();
			return seqNum;
		} catch (Exception e) {
			LOGGER.info(" error : In seqnum method of UserDetailsServiceImpl class");
			return 0;
		}
	}
	@Override
	public int getSequenecNumberNew(String custId) {
		LOGGER.info(" Start : In seqnum method of UserDetailsServiceImpl class");
		try {
			int seqNum = userDetailsDAO.getSequenecNumberNew(custId);
			return seqNum;
		} catch (Exception e) {
			LOGGER.info(" error : In seqnum method of UserDetailsServiceImpl class");
			return 0;
		}
	}
	@Override
	public int updateSeedId(String custId, int SeqNo) {
		LOGGER.info(" Start : In seqnum method of UserDetailsServiceImpl class");
		try {
			int seqNum = userDetailsDAO.updateSeedId(custId, SeqNo);
			return seqNum;
		} catch (Exception e) {
			LOGGER.info(" error : In seqnum method of UserDetailsServiceImpl class");
			return 0;
		}
	}
	@Override
	public String getOptimaAgentIdFromDB(AgreeDetailsVO agreeDetailsVO) {
		
		LOGGER.info(" Start : In getOptimaAgentIdFromDB() method of UserDetailsServiceImpl class");
		try {
			return userDetailsDAO.getOptimaAgentIdFromDB(agreeDetailsVO);
		} catch (Exception e) {
			LOGGER.info(" error : In getOptimaAgentIdFromDB() method of UserDetailsServiceImpl class");
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public Map<String, String> getAvailablePlansForCounty(String county) {
		
		LOGGER.info(" Start : In getAvailablePlansForCounty() method of UserDetailsServiceImpl class");
		try {
			System.out.println(":userDetailsDAO "+userDetailsDAO);
			return userDetailsDAO.getAvailablePlansForCounty(county);
		} catch (Exception e) {
			LOGGER.info(" error : In getAvailablePlansForCounty() method of UserDetailsServiceImpl class");
		}
		return null;
	}

	@Override
	public String getPipeSepString(Map physicanMapDB) {
		StringBuffer pipeSepString = new StringBuffer();
		Set keys = physicanMapDB.keySet();
		Object value;
		int count = 0;
		for (Object key : keys) {
			value = physicanMapDB.get(key);
			if (value != null) {
				value = value.toString().trim();
				value = value.toString().replaceAll(" +", " ");
			}
			pipeSepString.append(key).append("=").append(value);
			if (count++ >= 0) {
				pipeSepString.append("|");
			}
		}
		return pipeSepString.toString();
	}
	//fix for IFOX-401637 - START
	@Override
	public boolean getEmailID(String custId, String emailID) {
		LOGGER.info(" Start : In getEmailID() method of UserDetailsServiceImpl class");
		try {
			boolean emailIDExists = userDetailsDAO.getEmailID(custId,emailID);
			return emailIDExists;
		} catch (Exception e) {
			LOGGER.info(" error : In getEmailID() method of UserDetailsServiceImpl class");
			return true;
		}
	}	
	@Override
	public int saveNewUser(LoginVO loginVO) {
		
		LOGGER.info(" Start : In saveNewUser() method of UserDetailsServiceImpl class");
		try {
			int saveSuccess = userDetailsDAO.saveNewUser(loginVO);
			System.out.println("Succesful Save : "+saveSuccess);
			return saveSuccess;
		} catch (Exception e) {
			LOGGER.info(" error : In saveNewUser() method of UserDetailsServiceImpl class");
			return 0;
		}
	}	
	@Override
	public String getUserData(String customerId, String emailID) {
		
		LOGGER.info(" Start : In getUserData() method of UserDetailsServiceImpl class");
		try {
			return userDetailsDAO.getUserData(customerId, emailID);
		} catch (Exception e) {
			LOGGER.info(" error : In getUserData() method of UserDetailsServiceImpl class");
			e.printStackTrace();
		}

		return null;
	}
	@Override
	public int incrementLoginAttempts(String customerId, String emailID) {
		
		LOGGER.info(" Start : In incrementLoginAttempts() method of UserDetailsServiceImpl class");
		try {
			return userDetailsDAO.incrementLoginAttempts(customerId, emailID);
		} catch (Exception e) {
			LOGGER.info(" error : In incrementLoginAttempts() method of UserDetailsServiceImpl class");
			e.printStackTrace();
		}

		return 0;
	}
	
	@Override
	public int resetLoginAttempts(String customerId, String emailID) {
		
		LOGGER.info(" Start : In resetLoginAttempts() method of UserDetailsServiceImpl class");
		try {
			return userDetailsDAO.resetLoginAttempts(customerId, emailID);
		} catch (Exception e) {
			LOGGER.info(" error : In resetLoginAttempts() method of UserDetailsServiceImpl class");
			e.printStackTrace();
		}

		return 0;
	}
	
	@Override
	public int addUserApplicationNumber(String customerId, String emailID, int ackValue) {
		
		LOGGER.info(" Start : In addUserApplicationNumber() method of UserDetailsServiceImpl class");
		try {
			return userDetailsDAO.addUserApplicationNumber(customerId, emailID, ackValue);
		} catch (Exception e) {
			LOGGER.info(" error : In addUserApplicationNumber() method of UserDetailsServiceImpl class");
			e.printStackTrace();
		}

		return 0;
	}	
	//fix for IFOX-401637 - END

	@Override
	public String getClinicName(String customerId, String ofcCode, String reqDtCov) {
		LOGGER.info(" Start : In getClinicName() method of UserDetailsServiceImpl class");
		try {
			return userDetailsDAO.getClinicName(customerId, ofcCode, reqDtCov);
		} catch (Exception e) {
			LOGGER.info(" error : In getClinicName() method of UserDetailsServiceImpl class");
			e.printStackTrace();
		}

		return null;
	}
}
