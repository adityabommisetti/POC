package com.medicare.validator;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.medicare.helper.MedicareUtil;
import com.medicare.helper.VAPConstants;
import com.medicare.vo.AgreeDetailsVO;

public class AgreeDetailsValidator implements Validator  {
	

	private Map<String, Boolean> cityStatemap;

	@Override
	public boolean supports(Class clazz) {
		return AgreeDetailsValidator.class.equals(clazz);
	}

	public void validate(AgreeDetailsVO agd, BindingResult result, Map<String, Boolean> cityStatemap) {
		
		this.cityStatemap = cityStatemap;
		 validate(agd, result);
	}

	@Override
	public void validate(Object target, Errors errors) {
		 
		AgreeDetailsVO agd= (AgreeDetailsVO) target;
		
		if(agd.getAgreeStatements() == null  || agd.getAgreeStatements().trim().equals("")) {
			errors.rejectValue("agreeStatements","agreeStatements.required");
		} 
		if(agd.getTrcntCreditChBox() != null  && agd.getRecentlyCreditable().isEmpty()) {
			errors.rejectValue("trcntCreditChBox","trcntCreditChBox.required");
		} 
		if(agd.getNewElgbChBox() != null  && agd.getNewlyEligbleMedicare().isEmpty()) {
			errors.rejectValue("newElgbChBox","newElgbChBox.required");
		} 
		if(agd.getRevMedChBox() != null  && agd.getRecieveMedicareDrugs().isEmpty()) {
			  errors.rejectValue("revMedChBox","revMedChBox.required");
		} 
		if(agd.getLevEmpChBox() != null  && agd.getLeavingEmployerCoverage().isEmpty()) {
			  errors.rejectValue("levEmpChBox","levEmpChBox.required");
		} 
		if(agd.getNlElgPrescChBox() != null  && null != agd.getNoEligbPrescDrugs() && agd.getNoEligbPrescDrugs().isEmpty()) {
			  errors.rejectValue("nlElgPrescChBox","nlElgPrescChBox.required");
		} 
		if(agd.getRecntMovChBox() != null  && null != agd.getRecentMovedOption() && agd.getRecentMovedOption().isEmpty()) {
			  errors.rejectValue("recntMovChBox","recntMovChBox.required");
		} 
		if(agd.getRecnMovOutChBox() != null  && null != agd.getRecntMovedOutSide() && agd.getRecntMovedOutSide().isEmpty()) {
			  errors.rejectValue("recnMovOutChBox","recnMovOutChBox.required");
		}
		if(agd.getRecntleftPlChBox() != null  && agd.getRecntLeftPace().isEmpty()) {
			  errors.rejectValue("recntleftPlChBox","recntleftPlChBox.required");
		}
		if(agd.getMvdUsChBox()!= null  && agd.getMovedBackUs().isEmpty()) {
			  errors.rejectValue("mvdUsChBox","mvdUsChBox.required");
		}
		if(agd.getMcNumChBox()!= null  && agd.getMedicardNumber().isEmpty()) {
			  errors.rejectValue("mcNumChBox","mcNumChBox.required");
		}
		if(agd.getOutLngTermFcSeeChBox()!= null  && agd.getOutLongTermFacility().isEmpty()) {
			  errors.rejectValue("outLngTermFcSeeChBox","outLngTermFcSeeChBox.required");
		}
		if(agd.getNoElgbspseChBox()!= null  && agd.getNoEligSpecial().isEmpty()) {
			  errors.rejectValue("noElgbspseChBox","noElgbspseChBox.required");
		}
		if(agd.getPrefEmailChBox()!= null  && agd.getPreferEmail().isEmpty()) {
			  errors.rejectValue("prefEmailChBox","prefEmailChBox.required");
		}
		
		if (agd.getLegalRelationErloll()!= null && !(agd.getLegalRelationErloll().equalsIgnoreCase("")) ) {

			/*if (agd.getLegalLastName() == null || agd.getLegalLastName().isEmpty()){
			  errors.rejectValue("legalLastName","legalLastName.required");
	    	}*/
			
			 if(agd.getLegalAddress()== null || agd.getLegalAddress().isEmpty()){
				errors.rejectValue("legalAddress","legalAddress.required");
			}
			 
			if(agd.getLegalPhNumber()== null || agd.getLegalPhNumber().isEmpty()){
					errors.rejectValue("legalPhNumber","legalPhNumber.required");
			}
			/*if(agd.getLegalCity()== null || agd.getLegalCity().isEmpty()){
				errors.rejectValue("legalCity","legalCity.required");
			}*/
		}
		
		
		if((agd.getLegalLastName()!=null && !agd.getLegalLastName().isEmpty()) || (agd.getLegalFirstName()!= null && !agd.getLegalFirstName().isEmpty())
				||  (agd.getLegalMiddleName()!= null && !agd.getLegalMiddleName().isEmpty()) || (agd.getLegalAddress()!= null && !agd.getLegalAddress().isEmpty()) || 
				       (agd.getLegalCity()!= null && !agd.getLegalCity().isEmpty())||  (agd.getLegalZipCode()!= null  && !agd.getLegalZipCode().isEmpty()) ||
				       (agd.getLegalPhNumber()!= null && !agd.getLegalPhNumber().isEmpty()) || (agd.getLegalState()!= null && !agd.getLegalState().equalsIgnoreCase(""))){
			
			if (agd.getLegalRelationErloll() == null || agd.getLegalRelationErloll().equalsIgnoreCase("")){
				 errors.rejectValue("legalRelationErloll","legalRelationErloll.required");
			}
		}
		

		if (agd.getTodayDate() != null && !agd.getTodayDate().isEmpty()) {
			
			//UI Todays Date
			Date uiDate = MedicareUtil.formatDate(agd.getTodayDate());
			
			//Current Date
			Calendar cal = Calendar.getInstance();
			DateFormat dateFormat = new SimpleDateFormat(VAPConstants.DateFormat);
			Date currDate = MedicareUtil.formatDate(dateFormat.format(cal.getTime()));
			
			if(!uiDate.equals(currDate)) {
				errors.rejectValue("todayDate","todayDate.validate");
			}
		}
		
		
		if (cityStatemap == null || cityStatemap.isEmpty()) {
			return;
		}
		
		if (cityStatemap.get("LegalState")) {
			errors.rejectValue("legalCityState","legalCityState.validate");
		}
		
		// for agent id ,name
		if(cityStatemap.get("agentIdName")){
			errors.rejectValue("agentIdNameCheck","agentIdNameCheck.validate");
		}
		
		
		if(agd.getAep().equalsIgnoreCase("A"))
		{
		
		
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
		String todayDate = format.format(new Date());;
		if(agd.getTodayDate() != null)
			todayDate = agd.getTodayDate();
		
		Date d1 = null;
		try {
			d1 = format.parse(todayDate);
			Calendar cal = Calendar.getInstance();
			cal.setTime(d1);
		    int year = cal.get(Calendar.YEAR);
		    int month = cal.get(Calendar.MONTH);
		    int day = cal.get(Calendar.DAY_OF_MONTH);
		    
		    if(month<10)
			  {
				  if(month == 9 && day<=14)
				  {
					  errors.rejectValue("aep","aep.validate");
				  }
				/*  else
				  {
					  errors.rejectValue("aep","aep.validate");
			      }*/
			  }
		    
		  if(month >10 && day>7)
		  {
			  errors.rejectValue("aep","aep.validate");
		  }
		 
		} catch (ParseException e) {
		
			e.printStackTrace();
		 }
		
	  }
		
		if(agd.getAep().equalsIgnoreCase("I"))
		{
		String birthDate = agd.getIcepDate();
		
		String tdate  = agd.getTodayDate();
	
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
		 
		Date d1 = null;
		Date d2 = null;
 
			try {
				d1 = format.parse(birthDate);
				
				d2 = format.parse(tdate);
				
	 
	      	int diffMonths = getMonthsBetweenDates(d1,d2);
	   	
          if(diffMonths >784 || diffMonths <778)
           {
    	      errors.rejectValue("icep","icep.validate"); 
    	 
            }
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
 }
	public static int getMonthsBetweenDates(Date startDate, Date endDate)
	{
	    if(startDate.getTime() > endDate.getTime())
	    {
	        Date temp = startDate;
	        startDate = endDate;
	        endDate = temp;
	    }
	    Calendar startCalendar = Calendar.getInstance(); 
	    startCalendar.setTime(startDate);
	    Calendar endCalendar = Calendar.getInstance();
	    endCalendar.setTime(endDate);

	    int yearDiff = endCalendar.get(Calendar.YEAR)- startCalendar.get(Calendar.YEAR);
	    int monthsBetween = endCalendar.get(Calendar.MONTH)-startCalendar.get(Calendar.MONTH) +12*yearDiff;

	    if(endCalendar.get(Calendar.DAY_OF_MONTH) >= startCalendar.get(Calendar.DAY_OF_MONTH))
	        monthsBetween = monthsBetween + 1;
	    return monthsBetween;

	}
}
