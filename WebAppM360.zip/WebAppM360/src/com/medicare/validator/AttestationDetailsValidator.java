package com.medicare.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.medicare.vo.AttestationDetailsVO;

public class AttestationDetailsValidator implements Validator {

	@Override
	public boolean supports(Class clazz) {
		return AttestationDetailsVO.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		AttestationDetailsVO attestationDetailsVO = (AttestationDetailsVO) target;
	}
}
