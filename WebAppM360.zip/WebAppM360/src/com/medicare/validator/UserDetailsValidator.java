package com.medicare.validator;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.medicare.helper.MedicareUtil;
import com.medicare.vo.PolicyDetailsVO;
import com.medicare.vo.UserDetailsVO;


public class UserDetailsValidator implements Validator {
	
	private Map<String, Boolean> cityStatemap;

	@Override
	public boolean supports(Class clazz) {
		return UserDetailsValidator.class.equals(clazz);
	}

	public void validate(UserDetailsVO userDetailsVO, BindingResult result, Map<String, Boolean> cityStatemap) {
		
		this.cityStatemap = cityStatemap;
		validate(userDetailsVO, result);
	}

	@Override
	public void validate(Object target, Errors errors) {
		 
		UserDetailsVO userDetailsVO = (UserDetailsVO) target;
		
		//Commented for IFOX-00390786 (Phase-II)
		/*
		if (userDetailsVO.getEmergencyCont() == null || userDetailsVO.getEmergencyCont().isEmpty()) {
			errors.rejectValue("emergencyCont", "emergencyCont.required");
		}
		if (userDetailsVO.getEmergPhNum() == null || userDetailsVO.getEmergPhNum().isEmpty()) {
			errors.rejectValue("emergPhNum", "emergPhNum.required");
		}

		if (userDetailsVO.getRelationYou() == null || userDetailsVO.getRelationYou().equalsIgnoreCase("")) {
			errors.rejectValue("relationYou", "relationYou.required");
		}

		if (userDetailsVO.getPhysician() != null && userDetailsVO.getPhysician().equalsIgnoreCase("None")) {
			errors.rejectValue("physician", "physician.required");
		}		*/
		
		if (userDetailsVO.getRelationYou() != null && !(userDetailsVO.getRelationYou().equalsIgnoreCase("")) ) {

			if (userDetailsVO.getEmergencyCont() == null || userDetailsVO.getEmergencyCont().isEmpty()){
			  errors.rejectValue("emergencyCont","emergencyCont.required");
	    	}
			
			if(userDetailsVO.getEmergPhNum() == null || userDetailsVO.getEmergPhNum().isEmpty()){
				  errors.rejectValue("emergPhNum","emergPhNum.required");
			}
		}	
		
		if ((userDetailsVO.getEmergencyCont() != null && !userDetailsVO.getEmergencyCont().isEmpty()) || (userDetailsVO.getEmergPhNum()!=null && !userDetailsVO.getEmergPhNum().isEmpty()))
		{
			if(userDetailsVO.getRelationYou() == null || userDetailsVO.getRelationYou().equalsIgnoreCase("")) 
			{
				  errors.rejectValue("relationYou","relationYou.required");
			}
		}
		
		

		if (userDetailsVO.getPermanentState() != null && userDetailsVO.getPermanentState().equalsIgnoreCase("None")) {
			errors.rejectValue("permanentState","permanentState.required");
		}
		
		if (cityStatemap == null || cityStatemap.isEmpty()) {
			return;
		}
		
		if (cityStatemap.get("PermState")) {
			errors.rejectValue("permCityState","permCityState.validate");
		}
		
		if (cityStatemap.get("MailingState")) {
			errors.rejectValue("mailingCityState","mailingCityState.validate");
		}
		
		//for 2015 application
		
		if(userDetailsVO.getEffDate()!=null && !userDetailsVO.getEffDate().isEmpty())
		{
		
			
			String effDate = userDetailsVO.getEffDate();
			SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
			 
			Date d1 = null;
				try {
					d1 = format.parse(effDate);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				// IFOX-00384630: Summacare WebApp files failed to process to M360 system - Start
				/*Calendar cal = Calendar.getInstance();
				  int calYear = cal.get(Calendar.YEAR);
				  System.out.println("calYear"+calYear);
				
				cal.setTime(d1);
			   
			    int day = cal.get(Calendar.DAY_OF_MONTH);
			    int year = cal.get(Calendar.YEAR);
			    
			if(day>1 || year>calYear || year<calYear)
				
			{
				 errors.rejectValue("effDate","effDate.validate");
			}*/
			// IFOX-00384630: Summacare WebApp files failed to process to M360 system - End
		}
		
	}
	
}
