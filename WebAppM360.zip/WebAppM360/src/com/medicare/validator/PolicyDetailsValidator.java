package com.medicare.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.medicare.vo.PolicyDetailsVO;

public class PolicyDetailsValidator implements Validator {

	@Override
	public boolean supports(Class clazz) {
		return PolicyDetailsVO.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		PolicyDetailsVO policyDetailsVO = (PolicyDetailsVO) target;

		if ((policyDetailsVO.getPaymentOption() == null || policyDetailsVO.getPaymentOption().isEmpty())
				&& (policyDetailsVO.getAutoDeduction() == null || policyDetailsVO.getAutoDeduction().isEmpty())) {
			errors.rejectValue("cbxValueError", "cbxValueError.required");
		}
		if (policyDetailsVO.getPhysician() != null && policyDetailsVO.getPhysician().equalsIgnoreCase("None")) {
			errors.rejectValue("physician", "physician.required");
		}
		
		//if ("E".equalsIgnoreCase(policyDetailsVO.getPaymentOption())) {
		if ( "E".equalsIgnoreCase(policyDetailsVO.getPaymentOption()) || 
				"S".equalsIgnoreCase(policyDetailsVO.getPaymentOption()) ) { //VAP code merge

			if (policyDetailsVO.getAccountHolderName() == null || policyDetailsVO.getAccountHolderName().isEmpty()) {
				errors.rejectValue("accountHolderName", "accountHolderName.required");
			}
			if (policyDetailsVO.getBankRoutingNumber() == null || policyDetailsVO.getBankRoutingNumber().isEmpty()) {
				errors.rejectValue("bankRoutingNumber", "bankRoutingNumber.required");
			}
			if (policyDetailsVO.getBankAccountNumber() == null || policyDetailsVO.getBankAccountNumber().isEmpty()) {
				errors.rejectValue("bankAccountNumber", "bankAccountNumber.required");
			}
		}
	}

}
