/*package com.medicare.mailer;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

@Service
public class SendMail {

    private JavaMailSender  mailSender;

    @Autowired
    public void setMailSender(JavaMailSender mailSender) {
		this.mailSender = mailSender;
	}
	
    

	public boolean sendMail(String from, String to[],String cc[], String subject, String msg,String pdf) {
		try {
			MimeMessage message = mailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message, true);
			helper.setFrom(from);
			helper.setTo(to);
			helper.setCc(cc);
			helper.setSubject(subject);
			helper.setText(msg);
			FileSystemResource file = new FileSystemResource(pdf);
			helper.addAttachment(file.getFilename(), file);
			mailSender.send(message);
			return true;
		} catch (Exception exe) {
			return false;
		}
		
	}


	

	
}*/