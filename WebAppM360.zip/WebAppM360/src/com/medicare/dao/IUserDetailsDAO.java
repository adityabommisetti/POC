package com.medicare.dao;

import java.util.List;
import java.util.Map;

import org.hibernate.Session;

import com.medicare.model.UserDetails;
import com.medicare.vo.AgreeDetailsVO;
import com.medicare.vo.LoginVO;
import com.medicare.vo.UserDetailsVO;


public interface IUserDetailsDAO {
	
	public int saveUserDetails(UserDetails userDetails);

	public byte[] getPdfApplicationForm(int userId);

	public byte[] getPdfApplicationForm(int userId, String customerId);
	
	public Map<String, Boolean> validateStateAndCityValuesFromDB(UserDetailsVO userDetailsVO);

	public Map<String, Boolean> validateAgreeStateAndCityValuesFromDB(AgreeDetailsVO agd);

	public int getSequenecNumber();
	public int getSequenecNumberNew(String custId);

	public String getOptimaAgentIdFromDB(AgreeDetailsVO agreeDetailsVO);

	public Map getPrePopulatedValuesFromDB(String customer_id);
	
	public Map getFirstPagePrePopulatedValues(String customer_id);
	public Map getSecondPagePrePopulatedValues(String customer_id);
	public Map getFouthPagePrePopulatedValues(String customer_id);

	public Map<String, String> getAvailablePlansForCounty(String county);

	
	public String isPermStateCityZipIsValid(UserDetailsVO userDetailsVO);

	public int updateSeedId(String custId, int seqNo);

	//fix for IFOX-401637 - START
	public boolean getEmailID(String custId, String emailID);

	public int saveNewUser(LoginVO loginVO);
	
	public String getUserData(String customerId, String emailID);
	
	public int incrementLoginAttempts(String customerId, String emailID);
	
	public int resetLoginAttempts(String customerId, String emailID);
	
	public int addUserApplicationNumber(String customerId, String emailID, int ackValue);
	//fix for IFOX-401637 - END

	public String getClinicName(String customerId, String ofcCode, String reqDtCov);
}
