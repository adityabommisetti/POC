package com.medicare.dao;

import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.medicare.helper.M360AppUtil;
import com.medicare.helper.VAPM360AppUtil;
import com.medicare.model.UserDetails;
import com.medicare.model.UserLogin;
import com.medicare.model.UserLoginPK;
import com.medicare.model.UserSeedPK;
import com.medicare.security.CryptoDigest;
import com.medicare.util.StringUtil;
import com.medicare.vo.AgreeDetailsVO;
import com.medicare.vo.LoginVO;
import com.medicare.vo.UserDetailsVO;

@Repository
public class UserDeatailsDAOImpl implements IUserDetailsDAO {

	private final static Logger LOGGER = Logger.getLogger(UserDeatailsDAOImpl.class.getName());


	private SessionFactory sessionFactory;
     @Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	/*
	 * To save the User details In Database
	 * 
	 * @see com.sentara.dao.IUserDetailsDAO#saveUserDetails(com.sentara.model.
	 * UserDetails)
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public int saveUserDetails(UserDetails userDetails) {

		LOGGER.info(" Start : In saveUserDetails() method of UserDeatailsDAOImpl class");
		LOGGER.info("userDetails.getFirstName(): " + userDetails.getFirstName());
		LOGGER.info("userDetails.getLastName(): " + userDetails.getLastName());
		LOGGER.info("userDetails.getMedicareClaimNum(): " + userDetails.getMedicareClaimNum());
		LOGGER.info("userDetails.getEffDate() : " + userDetails.getEffDate());
		Session session = null;
		Transaction trans = null;
		try {

			session = sessionFactory.openSession();
//			trans = session.beginTransaction();
//			trans.begin();
//			
//			trans.setTimeout(180); //IFOX-00394941: SC DB Deadlock Retrofit
			
			System.out.println(userDetails.getUserPolicyDetailsSet());
			LOGGER.info("B4 saving to DB");
			session.save(userDetails);
			session.flush();
			LOGGER.info("A8 saving to DB");
			
//			trans.commit();

			if ((userDetails.getFirstName() == null || userDetails.getFirstName().isEmpty())
					&& (userDetails.getLastName() == null || userDetails.getLastName().isEmpty())
					&& (userDetails.getMedicareClaimNum() == null || userDetails.getMedicareClaimNum().isEmpty())) {
				return 0;
			}

			LOGGER.info("In saveUserDetails() Firstname : " + userDetails.getFirstName());
			LOGGER.info("In saveUserDetails() LastName : " + userDetails.getLastName());
			LOGGER.info("In saveUserDetails() HICNumber : " + userDetails.getMedicareClaimNum());
			
			Criteria criteria = session.createCriteria(UserDetails.class);
			criteria.add(Restrictions.eq("firstName", userDetails.getFirstName()));
			criteria.add(Restrictions.eq("lastName", userDetails.getLastName()));
			criteria.add(Restrictions.eq("medicareClaimNum", userDetails.getMedicareClaimNum()));
			ProjectionList proList = Projections.projectionList();
			proList.add(Projections.property("userId"));
			criteria.setProjection(proList);
			List userDeatils = criteria.list();

			if (userDeatils != null && !userDeatils.isEmpty()) {
				LOGGER.info("In saveUserDetails() AppNumber : " + (Integer) userDeatils.get(0));
				return (Integer) userDeatils.get(0);
			} else {
				return 0;
			}
		} catch (Exception e) {
			LOGGER.error("error : In saveUserDetails() method of UserDeatailsDAOImpl class ");
			e.printStackTrace();
/*			// IFOX-00394941: SC DB Deadlock Issue Fix - Start
			try{
				LOGGER.error("error : In saveUserDetails() method of UserDeatailsDAOImpl class : Trying to Rollback ");
				if(null != trans)
					trans.rollback();
				LOGGER.error("error : In saveUserDetails() method of UserDeatailsDAOImpl class : Rollback Successful");
			}catch(Exception re){
				LOGGER.error("error : In saveUserDetails() method of UserDeatailsDAOImpl class : Couldn�t roll back transaction : ", re);
				re.printStackTrace();
			}
			// IFOX-00394941: SC DB Deadlock Retrofit
*/			return 0;
		} finally {
			session.close();
		}
	}

	public int getSequenecNumber() {
		LOGGER.info(" Start : In get seq number");
		Session session = null;
		int seqNum = 0;
		try {

			session = sessionFactory.openSession();
			String sql = null;
			SQLQuery query = null;
			sql = "SELECT max(USER_ID)+1 from WB_USER_DETAILS";
			query = session.createSQLQuery(sql);
			List currentSeq = query.list();
			if(currentSeq == null){
                return seqNum;
            }else{
            	seqNum = (Integer)currentSeq.get(0);
            }

			System.out.println(" seqNum" + seqNum);
			return seqNum;
		} catch (Exception e) {
			LOGGER.error("error : In getSequenecNumber() method of UserDeatailsDAOImpl class ");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return seqNum;
	}

		public  int getSequenecNumberNew(String customerId) {
			LOGGER.info(" Start : In get seq number");
			Session session = null;
			Transaction trans = null;
			int seqNum = 0;
			try {

				session = sessionFactory.openSession();
				String sql = null;
				SQLQuery query = null;
				
				// Get the next SEED_ID from WB_USER_ID_SEED table				
				//sql = "SELECT SEED_NBR+1 FROM WB_USER_ID_SEED WHERE CUSTOMER_ID = :CUSTOMER_ID AND SEED_TYPE = 'APP' FOR UPDATE";
				sql = "SELECT SEED_NBR+1 FROM WB_USER_ID_SEED WHERE CUSTOMER_ID = :CUSTOMER_ID AND SEED_TYPE = 'APP'";
				query = session.createSQLQuery(sql);
				//query.setParameter("CUSTOMER_ID", customerId);
				query.setParameter("CUSTOMER_ID", "9999999");
				List currentSeq = query.list();
				
	            if(currentSeq == null){
	                return seqNum;
	            }else{
	            	seqNum = (Integer)currentSeq.get(0);
	            }
	        
	            // Increment the next SEED_ID in WB_USER_ID_SEED table
	           /* session = sessionFactory.openSession();
				trans = session.beginTransaction();
				trans.setTimeout(90);
				trans.begin();
		    	
				String updateSql = "UPDATE WB_USER_ID_SEED SET SEED_NBR = :SEED_NBR WHERE CUSTOMER_ID = :CUSTOMER_ID AND SEED_TYPE = 'APP'";
				Query updateQuery = session.createQuery(updateSql);
				updateQuery.setParameter("CUSTOMER_ID", customerId);
				updateQuery.setParameter("SEED_NBR", seqNum);
				
				int result = query.executeUpdate();
	  			trans.commit();*/
		            

			} catch (Exception e) {
				LOGGER.error("error : In getSequenecNumber() method of UserDeatailsDAOImpl class ");
				e.printStackTrace();
				try{
					LOGGER.error("error : In getSequenecNumber() method of UserDeatailsDAOImpl class : Trying to Rollback ");
					//trans.rollback();
					LOGGER.error("error : In getSequenecNumber() method of UserDeatailsDAOImpl class : Rollback Successful");
				}catch(Exception re){
					LOGGER.error("error : In getSequenecNumber() method of UserDeatailsDAOImpl class : Couldn�t roll back transaction : ", re);
					re.printStackTrace();
				}
			} finally {
				session.close();
			}
			 return seqNum;

		}
	
		@Override
		public int updateSeedId(String custId, int SeqNo) {
			LOGGER.info("userDetails.updateSeedId(): ");
			Session session = null;
			int result = 0;
			Transaction trans = null;
			try {

				session = sessionFactory.openSession();
//				trans = session.beginTransaction();
//				trans.setTimeout(90);
//				trans.begin();
				
				String updateSql = "update UserIdSeed set seedNbr = :seedNbr where id = :id";
				Query updateQuery = session.createQuery(updateSql);
				updateQuery.setParameter("seedNbr", SeqNo);
				//updateQuery.setParameter("id", new UserSeedPK("APP",custId));
				updateQuery.setParameter("id", new UserSeedPK("APP","9999999"));
				
				result = updateQuery.executeUpdate();
				session.flush();
	  			//trans.commit();
	  			
			} catch (Exception e) {
				LOGGER.error("error : In updateSeedId() method of UserDeatailsDAOImpl class ");
				e.printStackTrace();
				try{
					LOGGER.error("error : In updateSeedId() method of UserDeatailsDAOImpl class : Trying to Rollback ");
					//trans.rollback();
					LOGGER.error("error : In updateSeedId() method of UserDeatailsDAOImpl class : Rollback Successful");
				}catch(Exception re){
					LOGGER.error("error : In updateSeedId() method of UserDeatailsDAOImpl class : Couldn�t roll back transaction : ", re);
					re.printStackTrace();
				}
			} finally {
				session.close();
			}
			
			return result;
		}

	/*
	 * To get the pdf from database with application number
	 * 
	 * @see
	 * com.sentara.dao.IUserDetailsDAO#statusApplicationForm(java.lang.String)
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public byte[] getPdfApplicationForm(int userId) {

		LOGGER.info(" Start : In getPdfApplicationForm() method of UserDeatailsDAOImpl class");
		Session session = null;
		byte[] blobAsBytes;
		// byte[] byteArray=null;

		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(UserDetails.class);
			criteria.add(Restrictions.eq("userId", userId));
			ProjectionList proList = Projections.projectionList();
			proList.add(Projections.property("pdfBlob"));
			criteria.setProjection(proList);
			List userDeatils = criteria.list();
			if (userDeatils != null && !userDeatils.isEmpty()) {
				blobAsBytes = Base64.encodeBase64((byte[]) userDeatils.get(0));
				return blobAsBytes;
			} else {
				return null;
			}
			// this code added for getting from location
			/*
			 * System.out.println(" i am in try block"); File folder = new
			 * File("C:\\pdfFiles\\"); File[] listOfFiles = folder.listFiles();
			 * 
			 * for (int i = 0; i < listOfFiles.length; i++) {
			 * 
			 * File file = listOfFiles[i];
			 * 
			 * if (file.isFile() && file.getName().endsWith(".pdf") &&
			 * file.getName().startsWith("11")) { String fileName=
			 * file.getName(); System.out.println("fileName"+fileName);
			 * InputStream inputStream = new FileInputStream(file); String
			 * inputStreamToString = inputStream.toString(); byteArray =
			 * inputStreamToString.getBytes(); inputStream.close(); } } return
			 * Base64.encodeBase64(byteArray);
			 */
		} catch (Exception e) {
			LOGGER.error("error : In getPdfApplicationForm() method of UserDeatailsDAOImpl class ");
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}
	}
	@SuppressWarnings("rawtypes")
	@Override
	public byte[] getPdfApplicationForm(int userId,String customerId) {

		LOGGER.info(" Start : In getPdfApplicationForm(int,String) method of UserDeatailsDAOImpl class");
		Session session = null;
		byte[] blobAsBytes;
		// byte[] byteArray=null;

		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(UserDetails.class);
			criteria.add(Restrictions.eq("userId", userId));
			criteria.add(Restrictions.eq("customerId", customerId));
			ProjectionList proList = Projections.projectionList();
			proList.add(Projections.property("pdfBlob"));
			criteria.setProjection(proList);
			List userDeatils = criteria.list();
			if (userDeatils != null && !userDeatils.isEmpty()) {
				blobAsBytes = Base64.encodeBase64((byte[]) userDeatils.get(0));
				return blobAsBytes;
			} else {
				return null;
			}
		} catch (Exception e) {
			LOGGER.error("error : In getPdfApplicationForm(int,String) method of UserDeatailsDAOImpl class ");
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}
	}
	/*
	 * to get the physicians and state details from database
	 * 
	 * @see com.sentara.dao.IUserDetailsDAO#getPrePopulatedValuesFromDB()
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Map getPrePopulatedValuesFromDB(String customerId) {

		LOGGER.info(" Start : In getPrePopulatedValuesFromDB() method of UserDeatailsDAOImpl class");
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Map populatedList = new HashMap<Object, Object>();
			
			// Fetch MED Office Data.
			populatedList.put("physicianMap", getMedOfficeData(customerId,session));
			
			// Fetch Agent Data
			if("HCF0331".equalsIgnoreCase(customerId) ){
				populatedList.put("agentNamesMap", getAgentData(customerId,session));
			}
			// Fetch Institution Data
			populatedList.putAll(getInstitutionData(customerId,session,populatedList));
			
			if (customerId != "HCF0331") {
				// Fetch State/Zip Data
				Map<String, String> stateMap = getStateData(customerId,session);
				populatedList.put("stateMap", stateMap);
				populatedList.put("mailStateMap", stateMap);
			}
			return populatedList;
		} catch (Exception e) {
			LOGGER.error("error : In getPrePopulatedValuesFromDB() method of UserDeatailsDAOImpl class ");
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Map getFirstPagePrePopulatedValues(String customerId) {

		LOGGER.info(" Start : In getFirstPagePrePopulatedValues() method of UserDeatailsDAOImpl class");
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Map populatedList = new HashMap<Object, Object>();
			
			// Fetch MED Office Data.
			populatedList.put("physicianMap", getMedOfficeData(customerId,session));

			// Fetch Agent Data
			populatedList.put("agentNamesMap", getAgentData(customerId,session));

			// Fetch Institution Data
			populatedList.putAll(getInstitutionData(customerId,session,populatedList));
			
			if (customerId != "HCF0331") {
				// Fetch State/Zip Data
				Map<String, String> stateMap = getStateData(customerId,session);
				populatedList.put("stateMap", stateMap);
				populatedList.put("mailStateMap", stateMap);
			}
			return populatedList;
		} catch (Exception e) {
			LOGGER.error("error : In getFirstPagePrePopulatedValues() method of UserDeatailsDAOImpl class ");
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Map getSecondPagePrePopulatedValues(String customerId) {
		LOGGER.info(" Start : In getSecondPagePrePopulatedValues() method of UserDeatailsDAOImpl class");
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Map populatedList = new HashMap<Object, Object>();
			
			// Fetch Institution Data
			populatedList.putAll(getInstitutionData(customerId,session,populatedList));
			
			return populatedList;
		} catch (Exception e) {
			LOGGER.error("error : In getSecondPagePrePopulatedValues() method of UserDeatailsDAOImpl class ");
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Map getFouthPagePrePopulatedValues(String customerId) {
		LOGGER.info(" Start : In getFouthPagePrePopulatedValues() method of UserDeatailsDAOImpl class");
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Map populatedList = new HashMap<Object, Object>();

			// Fetch Agent Data
			populatedList.put("agentNamesMap", getAgentData(customerId,session));

			return populatedList;
		} catch (Exception e) {
			LOGGER.error("error : In getFouthPagePrePopulatedValues() method of UserDeatailsDAOImpl class ");
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}
	}
	private Map<String, String> getStateData(String customerId, Session session) {
		LOGGER.info("getStateData: Fetching ZIPCODE data from database.");
		Map<String, String> stateMap = new HashMap<String, String>();
		try {
			Query queryStates = session
					.createSQLQuery("select ZIP_CD5,STATE_CD FROM WB_EM_ZIPCODE where CUSTOMER_ID= :CUSTOMER_ID");
			queryStates.setParameter("CUSTOMER_ID", customerId);

			List states = queryStates.list();
			Iterator itStates = states.iterator();
			
			while (itStates.hasNext()) {
				Object ob[] = (Object[]) itStates.next();
				String key = (String) ob[1];
				String name = (String) ob[1];
				stateMap.put(key, name);
			}
		} catch (Exception e) {
			LOGGER.info("getStateData: Exception : " + e.getMessage());
			e.printStackTrace();
		}
		return stateMap;
	}

	private Map getInstitutionData(String customerId, Session session, Map populatedList) {
		LOGGER.info("getInstitutionData: Fetching LTC_FACILITY(Institution)data from database.");
		Map<String, String> institutionMap = new HashMap<String, String>();
		Map<String, String> institutionAddressMap = new HashMap<String, String>();
		try {
			Query institutionquery = session.createSQLQuery(
					"SELECT LTC_FAC_ID, LTC_FAC_NAME, LTC_FAC_ADDRESS, "
					+ "LTC_FAC_PHONE FROM EM_LTC_FACILITY WHERE CUSTOMER_ID = :CUSTOMER_ID ORDER BY LTC_FAC_NAME ");

			institutionquery.setParameter("CUSTOMER_ID", customerId);
			List institutions = institutionquery.list();
			Iterator iterator = institutions.iterator();
			System.out.println("After executing institutional query...");
			while (iterator.hasNext()) {
				Object ob[] = (Object[]) iterator.next();
				String key = (String) ob[0];
				String name = (String) ob[1];
				String address = (String) ob[2];
				String phone = (String) ob[3];
				institutionMap.put(key.trim(), name.trim());
				institutionAddressMap.put(key.trim(), address.trim() + "%" + phone.trim());
			}
			System.out.println("Before sorting institutional details...");
		} catch (Exception e) {
			LOGGER.error("getInstitutionData: Exception : " + e.getMessage());
			e.printStackTrace();
		}
		populatedList.put("institutionMap", sortByValues(institutionMap));
		populatedList.put("institutionAddressMap", institutionAddressMap);
		return populatedList;
	}

	private Object getAgentData(String customerId, Session session) {
		LOGGER.info("getAgentData: Fetching AGENT data from database.");
		Map<String, String> sortedAgentNmaesMap = new HashMap<String, String>();
		Map<String, String> agentNamesMap = new HashMap<String, String>();
		try {
			Query agentNames = session
					.createSQLQuery("select AGENT_ID,AGENT_NAME FROM EM_AGENT where CUSTOMER_ID = :CUSTOMER_ID");
			agentNames.setParameter("CUSTOMER_ID", customerId);
			List agentNamesList = agentNames.list();
			Iterator agentNamesIt = agentNamesList.iterator();
			agentNamesMap = new HashMap<String, String>();
			while (agentNamesIt.hasNext()) {
				Object ob[] = (Object[]) agentNamesIt.next();
				String key = (String) ob[0];
				String name = (String) ob[1];
				agentNamesMap.put(key, name);
			}
			sortedAgentNmaesMap = sortByValues(agentNamesMap);
		} catch (Exception e) {
			LOGGER.error("getAgentData: Exception : " + e.getMessage());
			e.printStackTrace();
		}
		return sortedAgentNmaesMap;
	}

	private Map<String, String> getMedOfficeData(String customerId,Session session) {
		LOGGER.info("getMedOfficeData: Fetching MED_OFFICE data from database.");
		Map<String, String> physicanMap = new HashMap<String, String>();
		Map<String, String> sorted = new HashMap<String, String>();
		try {
			Query query = null;
			
			//System.out.println("******CustomerID******"+customerId);
			
			if(!"HCF0331".equalsIgnoreCase(customerId)){
				query = session.createSQLQuery(
						"select OFFICE_CD, CONCAT(CONCAT(CONCAT(RTRIM(LTRIM(DOCTOR_NAME)), '  ('), RTRIM(LTRIM(DOCTOR_ADDRESS))), ')') as DOCTOR_NAME "
						+ "FROM EM_MED_OFFICE where CUSTOMER_ID = :CUSTOMER_ID order by DOCTOR_NAME asc");
			}else{
				query = session.createSQLQuery(
						"select CONCAT(CONCAT(OFFICE_CD, '#') , LOCATION_ID) AS OFFICE_CD ,  CONCAT(CONCAT(CONCAT(RTRIM(LTRIM(DOCTOR_NAME)), '  ('), RTRIM(LTRIM(DOCTOR_ADDRESS))), ')') as DOCTOR_NAME "
						+ "FROM EM_MED_OFFICE where CUSTOMER_ID = :CUSTOMER_ID order by DOCTOR_NAME ASC ");
			}

			
			
			query.setParameter("CUSTOMER_ID", customerId);
			
			
			
			List physicians = query.list();
			Iterator it = physicians.iterator();
			while (it.hasNext()) {
				Object ob[] = (Object[]) it.next();
				String key = (String) ob[0];
				String name = (String) ob[1];
				physicanMap.put(key.trim(), name.trim());
			}
			sorted = sortByValues(physicanMap);
			System.out.println("getMedOfficeData: physicianMap length = " + sorted.size());
		} catch (Exception e) {
			LOGGER.error("getMedOfficeData: Exception : " + e.getMessage());
			e.printStackTrace();
		}
		return sorted;
	}
	
	public String getClinicName(String customerId, String ofcCode, String reqDtCov) {
		LOGGER.info("getClinicName: Fetching Clinic Name for Office Code "+ofcCode+" from database.");
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Query query = null;
			query = session.createSQLQuery(
						"SELECT CLINIC_NAME "
						+ "FROM EM_MED_OFFICE WHERE CUSTOMER_ID = :CUSTOMER_ID "
						+ "AND OFFICE_CD = :OFFICE_CD AND "
						+ ":REQDTCOV BETWEEN OFFICE_START_DATE AND OFFICE_END_DATE");
			
			query.setParameter("CUSTOMER_ID", customerId);
			query.setParameter("OFFICE_CD", ofcCode);
			query.setParameter("REQDTCOV", reqDtCov);
			
			List result = query.list();
			if(result != null)
				return (String) result.get(0);
			
		} catch (Exception e) {
			LOGGER.error("getClinicName: Exception : " + e.getMessage());
			e.printStackTrace();
		}
		return "";
	}	
	

	/*
	 * to validate the city, state , zip code
	 * 
	 * @see
	 * com.sentara.dao.IUserDetailsDAO#validateStateAndCityValuesFromDB(com.
	 * sentara.model.UserDetails)
	 */
	@Override
	public Map<String, Boolean> validateStateAndCityValuesFromDB(UserDetailsVO userDetailsVO) {

		LOGGER.info(" Start : In validateStateAndCityValuesFromDB() method of UserDeatailsDAOImpl class");
		Session session = null;
		try {

			session = sessionFactory.openSession();
			String sql = null;
			SQLQuery query = null;
			List results = null;
			Map<String, Boolean> populatedList = new HashMap<String, Boolean>();
			String zip = null;

			// Permanent City & State Validation
			// sql = "SELECT * FROM SENTARA.EM_ZIPCODE WHERE ZIP_CD5 = :zipValue
			// AND UPPER(STATE_CD) = UPPER(:stateValue) AND UPPER(CITY_NAME) =
			// UPPER(:cityValue)"; mysql change
			sql = "SELECT * FROM WB_EM_ZIPCODE WHERE ZIP_CD5 = :zipValue AND UPPER(STATE_CD) = UPPER(:stateValue) AND UPPER(CITY_NAME) = UPPER(:cityValue)";
			query = session.createSQLQuery(sql);

			if (userDetailsVO.getPermanentZip().length() > 5) {
				zip = userDetailsVO.getPermanentZip().substring(0, 5);
			} else {
				zip = userDetailsVO.getPermanentZip();
			}
			query.setParameter("zipValue", zip);
			query.setParameter("stateValue", userDetailsVO.getPermanentState());
			query.setParameter("cityValue", userDetailsVO.getPermanentCity());

			results = query.list();
			if (results.size() > 0) {
				populatedList.put("PermState", false);
			} else {
				populatedList.put("PermState", true);
			}

			// Mailing City & State Validation

			if ((userDetailsVO.getMailingZip() == null || userDetailsVO.getMailingZip().isEmpty())
					&& (userDetailsVO.getMailingState() == null || userDetailsVO.getMailingState().isEmpty())
					&& (userDetailsVO.getMailingCity() == null || userDetailsVO.getMailingCity().isEmpty())) {

				populatedList.put("MailingState", false);
				return populatedList;
			}

			// sql = "SELECT * FROM SENTARA.EM_ZIPCODE WHERE ZIP_CD5 = :zipValue
			// AND UPPER(STATE_CD) = UPPER(:stateValue) AND UPPER(CITY_NAME) =
			// UPPER(:cityValue)"; mysql change

			sql = "SELECT * FROM WB_EM_ZIPCODE WHERE ZIP_CD5 = :zipValue AND UPPER(STATE_CD) = UPPER(:stateValue) AND UPPER(CITY_NAME) = UPPER(:cityValue)";
			query = session.createSQLQuery(sql);

			if (userDetailsVO.getMailingZip().length() > 5) {
				zip = userDetailsVO.getMailingZip().substring(0, 5);
			} else {
				zip = userDetailsVO.getMailingZip();
			}
			query.setParameter("zipValue", zip);
			query.setParameter("stateValue", userDetailsVO.getMailingState());
			query.setParameter("cityValue", userDetailsVO.getMailingCity());
			results = query.list();
			if (results.size() > 0) {
				populatedList.put("MailingState", false);
			} else {
				// populatedList.put("MailingState", true);
				populatedList.put("MailingState", false);
			}

			return populatedList;
		} catch (Exception e) {
			LOGGER.error("error : In validateStateAndCityValuesFromDB() method of UserDeatailsDAOImpl class ");
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}
	}

	/**
	 * Method to generate file to M360 App
	 */
	// @Scheduled(fixedRate = (long) 4.32e+7)
	//@Scheduled(fixedRate = (long) 1.44e+7)
	public void generateFileToM360App() {

		LOGGER.info(" Start : In generateFileToM360App() method of UserDeatailsDAOImpl class");
		try {
			M360AppUtil.generateFileToM360App();

		} catch (Exception e) {
			LOGGER.error("error : In generateFileToM360App() method of UserDeatailsDAOImpl class");
			e.printStackTrace();
		}
	}
	//to run locally u need to uncomment this main method

	public void generateFileToM360App(String customerId) {

		LOGGER.info(" Start : In generateFileToM360App(customerId) method of UserDeatailsDAOImpl class");
		try {
			M360AppUtil.generateFileToM360App(customerId);

		} catch (Exception e) {
			LOGGER.error("error : In generateFileToM360App(customerId) method of UserDeatailsDAOImpl class");
			e.printStackTrace();
		}
	}	
	
	public static void main(String[] args) {
		//new UserDeatailsDAOImpl().generateM360AppUploadFileForVAP();
		if(null != args[0] && args[0].trim().equalsIgnoreCase("HCF0232"))
			new UserDeatailsDAOImpl().generateM360AppUploadFileForVAP();
		else if(null != args[0])
			new UserDeatailsDAOImpl().generateFileToM360App(args[0]);
		else
			new UserDeatailsDAOImpl().generateFileToM360App();
	}

	@Override
	public Map<String, Boolean> validateAgreeStateAndCityValuesFromDB(AgreeDetailsVO agd) {

		LOGGER.info(" Start : In validateAgreeStateAndCityValuesFromDB() method of UserDeatailsDAOImpl class");
		Session session = null;
		try {

			session = sessionFactory.openSession();
			String sql = null;
			SQLQuery query = null;
			List results = null;
			Map<String, Boolean> populatedList = new HashMap<String, Boolean>();
			String zip = null;

			// Legal City & State Validation
			if ((agd.getLegalZipCode() == null || agd.getLegalZipCode().isEmpty())
					&& (agd.getLegalState() == null || agd.getLegalCity().isEmpty())
					&& (agd.getLegalCity() == null || agd.getLegalCity().isEmpty())) {

				populatedList.put("LegalState", false);
				// return populatedList;
			}
			// sql = "SELECT * FROM SENTARA.EM_ZIPCODE WHERE ZIP_CD5 = :zipValue
			// AND UPPER(STATE_CD) = UPPER(:stateValue) AND UPPER(CITY_NAME) =
			// UPPER(:cityValue)"; mysql change
			sql = "SELECT * FROM WB_EM_ZIPCODE WHERE ZIP_CD5 = :zipValue AND UPPER(STATE_CD) = UPPER(:stateValue) AND UPPER(CITY_NAME) = UPPER(:cityValue)";
			query = session.createSQLQuery(sql);
			
			// Added for IFOX-00390466 - Retrofit Medicaid ID Changes: Start
			if (null != agd.getLegalZipCode() && agd.getLegalZipCode().length() > 5) {
			// Added for IFOX-00390466 - Retrofit Medicaid ID Changes: End
				zip = agd.getLegalZipCode().substring(0, 5);
			} else {
				zip = agd.getLegalZipCode();
			}
			query.setParameter("zipValue", zip);
			query.setParameter("stateValue", agd.getLegalState());
			query.setParameter("cityValue", agd.getLegalCity());
			results = query.list();
			if (results.size() > 0) {
				populatedList.put("LegalState", false);
			} else {
				// populatedList.put("LegalState", true);
				populatedList.put("LegalState", false);
			}

			// for agent name and agent id avlidation
			/*
			 * String agentId = agd.getAgentId();
			 * System.out.println("agentID"+agentId); String agentName =
			 * agd.getAgentName(); System.out.println("agentName"+agentName);
			 */

			// ravindra start here
			// String agentId = encrypt(agd.getAgentId());
			String agentId = agd.getAgentId();
			System.out.println("agentID" + agentId);
			// String agentName = encrypt(agd.getAgentName());
			String agentName = agd.getAgentName();
			System.out.println("agentName" + agentName);

			// ravindra end here

			if ((agd.getAgentName() == null || agd.getAgentName().isEmpty())
					&& (agd.getAgentId() == null || agd.getAgentId().isEmpty())) {

				populatedList.put("agentIdName", false);
				System.out.println("i am in not in block");
				return populatedList;
			}

			// sql = "SELECT * FROM SENTARA.AGENT_DETAILS WHERE UPPER(AGENT_ID)
			// = UPPER(:agentIdValue) AND UPPER(AGENT_NAME)
			// =UPPER(:agentNameValue)"; mysql change
			//sql = "SELECT * FROM WB_AGENT_DETAILS WHERE UPPER(AGENT_ID) = UPPER(:agentIdValue) AND UPPER(AGENT_NAME) =UPPER(:agentNameValue)";
			//getting from m30 table
			sql = "SELECT * FROM EM_AGENT WHERE UPPER(AGENT_ID) = UPPER(:agentIdValue) AND UPPER(AGENT_NAME) =UPPER(:agentNameValue)";
			query = session.createSQLQuery(sql);
			query.setParameter("agentIdValue", agentId);
			query.setParameter("agentNameValue", agentName);

			results = query.list();
			System.out.println("results" + results);
			if (results.size() > 0) {
				System.out.println("i am in greate box");
				populatedList.put("agentIdName", false);

			} else {
				System.out.println("i am in less box");
				populatedList.put("agentIdName", true);
			}

			return populatedList;
		} catch (Exception e) {
			LOGGER.error("error : In validateAgreeStateAndCityValuesFromDB() method of UserDeatailsDAOImpl class ");
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}
	}

	public static <K extends Comparable, V extends Comparable> Map<K, V> sortByValues(Map<K, V> map) {
		List<Map.Entry<K, V>> entries = new LinkedList<Map.Entry<K, V>>(map.entrySet());

		Collections.sort(entries, new Comparator<Map.Entry<K, V>>() {

			@Override
			public int compare(Entry<K, V> o1, Entry<K, V> o2) {
				return o1.getValue().compareTo(o2.getValue());
			}
		});

		// LinkedHashMap will keep the keys in the order they are inserted
		// which is currently sorted on natural ordering
		Map<K, V> sortedMap = new LinkedHashMap<K, V>();

		for (Map.Entry<K, V> entry : entries) {
			sortedMap.put(entry.getKey(), entry.getValue());
		}

		return sortedMap;
	}

	// Ravindra
	/*
	 * private static String decrypt(String texto) { return new
	 * String(Base64.decodeBase64(texto.getBytes())); } private static String
	 * encrypt(String texto) {
	 * 
	 * if(texto != null) { return new
	 * String(Base64.encodeBase64(texto.getBytes())); }
	 * 
	 * else { return ""; }
	 * 
	 * }
	 */
	@Override
	public String getOptimaAgentIdFromDB(AgreeDetailsVO agreeDetailsVO) {
		// for agent name and agent id validation
		LOGGER.info(" Start : In getOptimaAgentIdFromDB method of UserDeatailsDAOImpl class");
		Session session = null;
		try {
			session = sessionFactory.openSession();
			String sql = null;
			SQLQuery query = null;
			// Map populatedList = new HashMap<>();
			String agentId = agreeDetailsVO.getAgentId();
			System.out.println("agentID" + agentId);
			String agentName = agreeDetailsVO.getAgentName();
			System.out.println("agentName" + agentName);
			/*
			 * if ((agreeDetailsVO.getAgentName() == null ||
			 * agreeDetailsVO.getAgentName().isEmpty())) {
			 * populatedList.put("agentIdName", false); System.out.println(
			 * "i am in not in block"); return null; }
			 * 
			 * sql =
			 * "SELECT AGENT_ID FROM AGENT_DETAILS WHERE  UPPER(AGENT_NAME) =UPPER(:agentNameValue)"
			 * ; query = session.createSQLQuery(sql);
			 * query.setParameter("agentNameValue", agentName); List
			 * agentNamesList = query.list();
			 * 
			 * Iterator agentNamesIt=agentNamesList.iterator(); String key =
			 * null;
			 * 
			 * 
			 * while(agentNamesIt.hasNext()) { Object ob[] =
			 * (Object[])agentNamesIt.next(); key = (String) ob[0]; }
			 * System.out.println("key"+key);
			 */
			/*
			 * String key = null; Criteria criteria =
			 * session.createCriteria(AgentDetails.class);
			 * criteria.add(Restrictions.eq("agentName", agentName));
			 * ProjectionList proList = Projections.projectionList();
			 * proList.add(Projections.property("agentId"));
			 * criteria.setProjection(proList); List agentDetails =
			 * criteria.list(); key = (String) agentDetails.get(0);
			 * System.out.println("key"+key); return key;
			 */

			/*Query query1 = session.createSQLQuery(
					"SELECT AGENT_ID FROM WB_AGENT_DETAILS WHERE  UPPER(AGENT_NAME) =UPPER(:agentNameValue)");*/
			//getting from m30 table
			Query query1 = session.createSQLQuery(
					"SELECT AGENT_ID FROM EM_AGENT WHERE  UPPER(AGENT_NAME) =UPPER(:agentNameValue)");
			query1.setParameter("agentNameValue", agentName);
			List results = query1.list();
			System.out.println("agentId" + (String) results.get(0));

			return (String) results.get(0);

		} catch (Exception e) {
			LOGGER.error("error : In getOptimaAgentIdFromDB method of UserDeatailsDAOImpl class ");
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}
	}

	// Lokesh Katamaneni for get available plans for county
	@Override
	public Map<String, String> getAvailablePlansForCounty(String county) {

		LOGGER.info(" Start : In getAvailablePlansForCounty() method of UserDeatailsDAOImpl class");
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Query query = session.createSQLQuery(
					"SELECT DISTINCT TRIM(UPPER(PLAN_ID)) as PLAN_ID, PRODUCT_ID  FROM PLAN_COUNTY_XWALK WHERE UPPER(COUNTY_NAME)=UPPER(:COUNTY)");
			query.setParameter("COUNTY", county);
			query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
			List<Map<String, String>> plans = query.list();
			Map<String, String> result = new HashMap<String, String>();
			for (Map<String, String> plan : plans) {
				result.put(plan.get("PLAN_ID"), plan.get("PRODUCT_ID"));
			}
			return result;
		} catch (Exception e) {
			LOGGER.error("error : In getAvailablePlansForCounty() method of UserDeatailsDAOImpl class ");
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}
	}
	
	
	@Override
	public String isPermStateCityZipIsValid(UserDetailsVO userDetailsVO) {

		Session session = null;
		try {
			session = sessionFactory.openSession();
			SQLQuery query = session.createSQLQuery(
					"SELECT * FROM WB_EM_ZIPCODE WHERE ZIP_CD5 = :zipValue AND UPPER(STATE_CD) = UPPER(:stateValue) AND UPPER(CITY_NAME) = UPPER(:cityValue)");

			query.setParameter("zipValue",
					userDetailsVO.getPermanentZip().length() > 5 ? userDetailsVO.getPermanentZip().substring(0, 5) : userDetailsVO.getPermanentZip());

			query.setParameter("stateValue", userDetailsVO.getPermanentState());
			query.setParameter("cityValue", userDetailsVO.getPermanentCity());

			return query.list().size() > 0 ? "Y" : "N";

		} catch (Exception e) {
			LOGGER.error(" UserDeatailsDAOImpl : isPermStateCityZipIsValid : Exception : " + e.getMessage());
			e.printStackTrace();
		} finally {
			session.close();
		}
		return "N";
	}
	
	
	// @Scheduled(fixedRate = (long) 4.32e+7)
	//@Scheduled(fixedRate = (long) 1.44e+7)
	//@Scheduled(fixedRate = 1500)
	//@Scheduled(fixedRate = 3600000) // 1 Hour
	//@Scheduled(fixedRate = 1800000) // 1/2 Hour
	public void generateM360AppUploadFileForVAP() {

		LOGGER.info(" UserDeatailsDAOImpl : generateM360AppUploadFileForVAP : Begin : ");
		try {
			VAPM360AppUtil.generateM360AppUploadFileForVAP();

		} catch (Exception e) {
			LOGGER.error(" UserDeatailsDAOImpl : generateM360AppUploadFileForVAP : Exception : " + e.getMessage());
			e.printStackTrace();
		}
		LOGGER.info(" UserDeatailsDAOImpl : generateM360AppUploadFileForVAP : End : ");
	}

	//fix for IFOX-401637 - START
	public  boolean getEmailID(String customerId, String emailID) {
		LOGGER.info(" Start : In get emailID ");
		Session session = null;
		try {

			session = sessionFactory.openSession();
			String sql = null;
			SQLQuery query = null;
			
			sql = "SELECT EMAIL_ID FROM WB_USER_LOGIN WHERE CUSTOMER_ID = :CUSTOMER_ID AND EMAIL_ID = :EMAIL_ID";
			query = session.createSQLQuery(sql);

			query.setParameter("CUSTOMER_ID", customerId);
			query.setParameter("EMAIL_ID", emailID);
			List emailIDList = query.list();
			
			LOGGER.info(emailIDList.size());
			
            if(emailIDList.size() == 0){
            	LOGGER.info("emailID not found");
                return false;
            }else{
            	LOGGER.info("emailID found");
            	return true;
            }
	            

		} catch (Exception e) {
			LOGGER.error("error : In getEmailID() method of UserDeatailsDAOImpl class ");
			e.printStackTrace();
			try{
				LOGGER.error("error : In getEmailID() method of UserDeatailsDAOImpl class : Trying to Rollback ");
				//trans.rollback();
				LOGGER.error("error : In getEmailID() method of UserDeatailsDAOImpl class : Rollback Successful");
			}catch(Exception re){
				LOGGER.error("error : In getEmailID() method of UserDeatailsDAOImpl class : Couldn�t roll back transaction : ", re);
				re.printStackTrace();
			}
		} finally {
			session.close();
		}
		 return true;

	}		
		
	@Override
	public int saveNewUser(LoginVO loginVO) {

		LOGGER.info(" Start : In saveNewUser() method of UserDeatailsDAOImpl class");
		Session session = null;
		int success = 0;
		
		CryptoDigest crypt = new CryptoDigest();
		try {
			
			String encryptedPwd = "";
			encryptedPwd = crypt.digest(loginVO.getEmailAddress(), StringUtil.nonNullTrim(loginVO.getPassword()));
			
			session = sessionFactory.openSession();
			
			UserLogin userLogin = new UserLogin();
			UserLoginPK id = new UserLoginPK(loginVO.getEmailAddress(),loginVO.getCustomerId());
			
			userLogin.setId(id);
			userLogin.setPassword(encryptedPwd);
			userLogin.setLoginAttempts("0");
			userLogin.setApplicationNumber("");
			userLogin.setCreatedTime(new Date());
			userLogin.setUpdatedTime(new Date());
			userLogin.setOldPassword("");
			
			LOGGER.info("B4 saving to DB");
			session.save(userLogin);
			session.flush();
			LOGGER.info("A8 saving to DB");
			success = 1;
			return success;

		} catch (Exception e) {
			LOGGER.error("error : In saveNewUser() method of UserDeatailsDAOImpl class ");
			e.printStackTrace();
			return success;
		} finally {
			session.close();
		}
	}
	
	public String getUserData(String customerId, String emailID) {
		LOGGER.info("getUserData: Fetching user password from database.");
		Session session = null;
		String dbPassword = "";
		try {
			session = sessionFactory.openSession();
			Query query = session.createSQLQuery(
					"SELECT PASSWORD FROM WB_USER_LOGIN WHERE CUSTOMER_ID=:CUSTOMER_ID AND EMAIL_ID=:EMAIL_ID");

			query.setParameter("CUSTOMER_ID", customerId);
			query.setParameter("EMAIL_ID", emailID);
			
			List password = query.list();
			dbPassword = StringUtil.nonNullTrim((String) password.get(0));
			LOGGER.info("DB Password = " + dbPassword);
		} catch (Exception e) {
			LOGGER.error("DB Password: Exception : " + e.getMessage());
			e.printStackTrace();
		}
		return dbPassword;
	}
	
	public int incrementLoginAttempts(String customerId, String emailID) {
		LOGGER.info("incrementLoginAttempts: Incrementing user login attempts in database.");
		Session session = null;
		int success = 0;
		int currentAttempts=0;
		
		try {
			session = sessionFactory.openSession();
			Query query = session.createSQLQuery(
					"SELECT LOGIN_ATTEMPTS FROM WB_USER_LOGIN WHERE CUSTOMER_ID=:CUSTOMER_ID AND EMAIL_ID=:EMAIL_ID");

			query.setParameter("CUSTOMER_ID", customerId);
			query.setParameter("EMAIL_ID", emailID);
			
			List attempts = query.list();
			currentAttempts = Character.getNumericValue((Character) attempts.get(0));
			currentAttempts += 1;
			
			query = session.createSQLQuery(
					"UPDATE WB_USER_LOGIN SET LOGIN_ATTEMPTS=:LOGIN_ATTEMPTS WHERE CUSTOMER_ID=:CUSTOMER_ID AND EMAIL_ID=:EMAIL_ID");
			
			query.setParameter("LOGIN_ATTEMPTS", Integer.toString(currentAttempts));
			query.setParameter("CUSTOMER_ID", customerId);
			query.setParameter("EMAIL_ID", emailID);
			
			success = query.executeUpdate();
			
		} catch (Exception e) {
			LOGGER.error("Increment Login Attempts: Exception : " + e.getMessage());
			e.printStackTrace();
		}
		return success;
	}
	
	public int resetLoginAttempts(String customerId, String emailID) {
		LOGGER.info("resetLoginAttempts: resetting user login attempts in database.");
		Session session = null;
		int success = 0;
		int currentAttempts=0;
		
		try {
			session = sessionFactory.openSession();
			Query query = session.createSQLQuery(
					"UPDATE WB_USER_LOGIN SET LOGIN_ATTEMPTS=:LOGIN_ATTEMPTS WHERE CUSTOMER_ID=:CUSTOMER_ID AND EMAIL_ID=:EMAIL_ID");
			
			query.setParameter("LOGIN_ATTEMPTS", Integer.toString(currentAttempts));
			query.setParameter("CUSTOMER_ID", customerId);
			query.setParameter("EMAIL_ID", emailID);
			
			success = query.executeUpdate();
			
		} catch (Exception e) {
			LOGGER.error("Reset login Attempts: Exception : " + e.getMessage());
			e.printStackTrace();
		}
		return success;
	}
	
	public int addUserApplicationNumber(String customerId, String emailID, int ackValue) {
		LOGGER.info("addUserApplicationNumber: adding application number to user in database.");
		Session session = null;
		int success = 0;
		
		try {
			session = sessionFactory.openSession();
			Query query = session.createSQLQuery(
					"UPDATE WB_USER_LOGIN SET APPLICATION_NO=:APPLICATION_NO, UPDATED_TIME=:UPDATE_TIME WHERE CUSTOMER_ID=:CUSTOMER_ID AND EMAIL_ID=:EMAIL_ID");
			
			query.setParameter("APPLICATION_NO", Integer.toString(ackValue));
			query.setParameter("UPDATE_TIME", new Date());
			query.setParameter("CUSTOMER_ID", customerId);
			query.setParameter("EMAIL_ID", emailID);
			
			success = query.executeUpdate();
			
		} catch (Exception e) {
			LOGGER.error("addUserApplicationNumber: Exception : " + e.getMessage());
			e.printStackTrace();
		}
		return success;
	}	
	//fix for IFOX-401637 - END
}
