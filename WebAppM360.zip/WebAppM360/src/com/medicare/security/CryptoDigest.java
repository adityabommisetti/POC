/*
 * $Id: CryptoDigest.java,v 1.3 2006/06/07 01:24:56 rnenne Exp $
 */

package com.medicare.security;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import sun.misc.BASE64Encoder;

/**
 *
 * @author  rnenne
 */
public class CryptoDigest {
    
    private String algorithm ;
    
    /** Creates a new instance of CryptoDigest */
    public CryptoDigest() {
        this("SHA-1");
    }
    public CryptoDigest(String algorithm ) {
        this.algorithm = algorithm;
    }
    
    public String digest(String id, String pwd) throws NoSuchAlgorithmException  {
        return digest(id + "/" + pwd);
    }
    
    public String digest(String inMsg) throws NoSuchAlgorithmException {
           
        MessageDigest md = MessageDigest.getInstance(algorithm);
        md.reset();
        byte[] msg = inMsg.getBytes();
        md.update(msg);
        byte[] aMessageDigest = md.digest();
        BASE64Encoder encoder = new BASE64Encoder();
        String hash = encoder.encode(aMessageDigest);

        return hash;        
    }     
}
