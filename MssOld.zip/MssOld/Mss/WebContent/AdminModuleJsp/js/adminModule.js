function editProdData(custId, prodId, inpproductname, startDate, endDate, lastUpdTime) {
	$.ajax({
        type: "POST",
        url: "/AdminActions.do?methodName=editProdData&prodId="+prodId+"&prodName="+inpproductname+"&sd="+startDate+"&ed="+endDate+"&lastUpdTime="+lastUpdTime,
        data: "",
        success: function(response){ 
        	if(response.error) {
    			alert(response.error);    	
        	} else {
	            alert(response.success);
	            location.href = "/AdminModuleJsp/product.jsp";
        	}
        },
        error: function(e){
            alert("An unexpected error occured. Please try again after some time.");
        }
    });
}
function editServiceAreaData(custId, srvcId, srvcName, sd, ed, lastUpdTime) {
	$.ajax({
        type: "POST",
        url: "/AdminActions.do?methodName=editServiceAreaData&srvcId="+srvcId+"&srvcName="+srvcName+"&sd="+sd+"&ed="+ed+"&lastUpdTime="+lastUpdTime,
        data: "",
        success: function(response){ 
        	if(response.error) {
    			alert(response.error);    	
        	} else {
	            alert(response.success);
	            location.href = "/AdminModuleJsp/serviceArea.jsp";
        	}
        },
        error: function(e){
            alert("An unexpected error occured. Please try again after some time.");
        }
    });
}
function editGrpProdLisData(custId, planId, pbpId, lisLevel, lisAmt, sd, ed, lastUpdTime) {
	$.ajax({
        type: "POST",
        url: "/AdminActions.do?methodName=editGrpProdLisData&planId="+planId+"&pbpId="+pbpId+"&lisLevel="+lisLevel+"&lisAmt="+lisAmt+"&sd="+sd+"&ed="+ed+"&lastUpdTime="+lastUpdTime,
        data: "",
        success: function(response){ 
        	if(response.error) {
    			alert(response.error);    	
        	} else {
	            alert(response.success);
	            location.href = "/AdminModuleJsp/groupProdLIS.jsp";
        	}
        },
        error: function(e){
            alert("An unexpected error occured. Please try again after some time.");
        }
    });
}
function editAdminData(method, jsonData, pageName) {
	$.ajax({
        type: "POST",
        url: "/AdminActions.do?methodName=" + method,
        data: {data:JSON.stringify(jsonData)},
        success: function(response){ 
        	if(response.error) {
    			alert(response.error);    	
        	} else {
	            alert(response.success);
	            location.href = pageName;
        	}
        },
        error: function(e){
            alert("An unexpected error occured. Please try again after some time.");
        }
    });
}

function editbillingSubProdData(custId, prodId, subprd, startDate, endDate, type, desc, rate, functionCode) {
	$.ajax({
        type: "POST",
        url: "/AdminActions.do?methodName=editbillingSubProdData&prodId="+prodId+"&subprd="+subprd+"&startDate="+startDate+"&endDate="+endDate+"&type="+type+"&desc="+desc+"&rate="+rate+"&functionCode="+functionCode,
        data: "",
        success: function(response){ 
        	if(response.error) {
    			alert(response.error);    	
        	} else {
	            alert(response.success);
	            location.href = "/AdminModuleJsp/billingSubProd.jsp";
        	}
        },
        error: function(e){
            alert("An unexpected error occured. Please try again after some time.");
        }
    });
}