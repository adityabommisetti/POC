// $Id: utility.js,v 1.3 2011/03/02 06:10:38 rnenne Exp $

// introducing Trim method with String JS object
// just like "java.lang.String.trim()" method
String.prototype.trim = function() { return this.replace(/^\s+|\s+$/g, ''); };

function setSelectBox(ctl,Val)
{
    for (var i = 0; i < ctl.length; i++)
    {
        if (ctl.options[i].value == Val)
        {
			ctl.selectedIndex = i;
            return;
        }
    }
}

/*
author: Deepak
description: this method returns name of month
*/
function getMonthName(month) {
	if(month == '01')
		return 'January' ;

	if(month == '02')
		return 'February';

	if(month == '03')
		return 'March';

	if(month == '04')
		return 'April';

	if(month == '05')
		return 'May';

	if(month == '06')
		return 'June';

	if(month == '07')
		return 'July';

	if(month == '08')
		return 'August';

	if(month == '09')
		return 'September';

	if(month == '10')
		return 'October';

	if(month == '11')
		return 'November';

	if(month == '12')
		return 'December';
}


/*
author: Deepak
description: this method returns number value of month
*/
function getMonthValue (month) {
	if(month == 'January')
		return '01' ;

	if(month == 'February')
		return '02' ;
	
	if(month == 'March')
		return '03' ;

	if(month == 'April')
		return '04' ;
	
	if(month == 'May')
		return '05';
	
	if(month == 'June')
		return '06' ;
	
	if(month == 'July')
		return '07' ;

	if(month == 'August')
		return '08';
	if(month == 'September')
		return '09' ;
	
	if(month == 'October')
		return '10' ;
	if(month == 'November')
		return '11' ;
	if(month == 'December')
		return '12' ;
	
	return month ;
}



/*
Author: Rakesh
Discription : check element is null or containing blank value.

INPUT : Element Name

RETURN : BOOLEAN {
		true : blank or null
		false : having value
	}
*/
function isBlankOrNULL(eleName){
	if(getElement(eleName) != null){
		var eleValue = dwr.util.getValue(eleName);
		if(eleValue != null && "" != eleValue&& " " != eleValue)
			return false;
	}
	
	return true;
}

/* 
Author : Rakesh
Discription: checkDateFormat is used to validate DATE format.
Valid Date Format is : MM/YYYY OR M/YYYY

INPUT : date field name
		dateFormat {MM/YYYY, DD/MM/YYYY}

RETURN : {
		Blank or NULL :  0,
		Invalid Date : -1,
		Valid Date : 1
	}
*/
function checkDateFormat(eleName, dateFormat){
	if(!isBlankOrNULL(eleName)){
		var eleValue = dwr.util.getValue(eleName);
		var month = null;
		var day = null;
		var year = null;
		if("MM/DD/YYYY" == dateFormat ){
			// VALID date {31/02/1982 : length 10, 1/02/1982 : length 9, 1/2/1982 : length 8}		
			if(eleValue.length < 8 || eleValue.length > 10)
				return -1;
		
			// validate date should be in MM/DD/YYYY pattern
			var regex = new RegExp("[0-1][0-9]/[0-3][0-9]/[1-2][0-9][0-9][0-9]"); // Example : 02/31/1982
			var regex1 = new RegExp("[1-9]/[1-9]/[1-2][0-9][0-9][0-9]"); // Example : 2/2/1982
			var regex2 = new RegExp("[0-1][1-9]/[1-9]/[1-2][0-9][0-9][0-9]"); // Example : 02/2/1982
			var regex3 = new RegExp("[1-9]/[0-3][1-9]/[1-2][0-9][0-9][0-9]"); // Example : 2/02/1982

			if(eleValue.match(regex) == null && eleValue.match(regex1) == null && eleValue.match(regex2) == null && eleValue.match(regex3) == null)
				return -1;

			var eleValueSplitArr = eleValue.split("/");

			day = parseInt(eleValueSplitArr[1], 10); // getting day "DD"
			month = parseInt(eleValueSplitArr[0], 10); // getting month "MM"
			year = eleValueSplitArr[2]; // getting year "YYYY"
			if(eleValue.length != 10){
				var newVal = eleValueSplitArr[0];
				if(eleValueSplitArr[0].length ==1) // making correct form of "MM"
					newVal = "0" +newVal;
			
				if(eleValueSplitArr[1].length == 1) // making correct form of "DD"
					newVal += "/0" + eleValueSplitArr[1];
				else
					newVal += "/" + eleValueSplitArr[1];

				newVal += "/" + year; // Adding "YYYY"
				dwr.util.setValue(eleName, newVal);
			}
		}else{
			if(eleValue.length != 7 && eleValue.length != 6) // VALID date {02/1982 : length 7, 2/1982 : length 6}
				return -1;

			// validate date should be in MM/YYYY pattern
			var regex = new RegExp("[0-1][0-9]/[1-2][0-9][0-9][0-9]"); // Example : 02/1982
			var regex1 = new RegExp("[1-9]/[1-2][0-9][0-9][0-9]"); // Example : 2/1982
			
			if(eleValue.match(regex) == null && eleValue.match(regex1) == null)
				return -1;
			
			var eleValueSplitArr = eleValue.split("/");
			
			month = parseInt(eleValueSplitArr[0], 10); // getting month
			year = parseInt(eleValueSplitArr[1], 10); // getting Year 
			if(eleValue.length == 6)
				dwr.util.setValue(eleName, "0"+eleValue);
		}
		
		//validating year
		if(year < 1900 || year > 2099)
			return -1;
		
		// validating month
		if(month > 12 || month < 1)
			return -1;

		// validating month
		if(day != null ){
			// checking is day must have day > 1 & less than END_DAY_OF_MONTH (EOM)
			var EOM = daysInMonth(month, year);
			if(day > EOM || day < 1)
				return -1;
		}
		
		return 1;
	}

	return 0;
}

/*
Author : Rakesh
Input : Element Id 
Return : true / false 
Discription : Method will make alphaNumeric validation  on element value.
*/
function validateAlphaNumaric(eleName){
	if( getElement(eleName) != null){
		var val = dwr.util.getValue(eleName);
		if (val.match(/^[a-zA-Z0-9]+$/)) {
			return true;
		}
	}
	return false;
}

/*
Author : Rakesh
INPUT: 
	1. From Date
	2. To Date
	3. dateType {Effective, Update}

RETURN : true / false based on validation
*/
function validate2Date(fromTag, toTag, dateType, fieldName){
	var dateFormat = "MM/YYYY";
	if("Update" == dateType)
		dateFormat = "MM/DD/YYYY";

	var validFromDate = checkDateFormat(fromTag, dateFormat);
	var validToDate = checkDateFormat(toTag, dateFormat);
	var errorMsg = "";
	var errorTarget = fromTag;
	
	if(validFromDate == 0 && validToDate == 0)	// both fields are blank.
		errorMsg = "";
	else if(validFromDate == 1 && validToDate == 1) { // both fields having valid date format
		var fromDate = dwr.util.getValue(fromTag);
		var toDate = dwr.util.getValue(toTag);
		var fromYr = 0;
		var toYr = 0;
		var fromMonth = 0;
		var toMonth = 0;
		var fromDay =0;
		var toDay =0;
		
		var fromDateSplitArr = fromDate.split("/");
		var toDateSplitArr = toDate.split("/");
		
		if("Update" == dateType) {
			fromYr = parseInt(fromDateSplitArr[2], 10);
			toYr = parseInt(toDateSplitArr[2], 10);
			
			fromMonth = parseInt(fromDateSplitArr[0], 10) ;
			toMonth = parseInt(toDateSplitArr[0], 10);
			
			fromDay = parseInt(fromDateSplitArr[1], 10) ;
			toDay = parseInt(toDateSplitArr[1], 10);
		} else {
			fromYr = parseInt(fromDateSplitArr[1], 10);
			toYr = parseInt(toDateSplitArr[1], 10);
			
			fromMonth = parseInt(fromDateSplitArr[0], 10) ;
			toMonth = parseInt(toDateSplitArr[0], 10);
		}
		
		if(fromYr > toYr){
			errorMsg = MSG_DATE_GREATER_THAN;
			errorTarget = toTag;
		}else {
			if((fromYr == toYr) && (fromMonth > toMonth)){
				errorMsg = MSG_DATE_GREATER_THAN;
				errorTarget = toTag;
			} else {
				if((fromYr == toYr) && (fromMonth == toMonth) && fromDay > toDay){
					errorMsg = MSG_DATE_GREATER_THAN;
					errorTarget = toTag;
				}
			}
		}
	} else {
		if(validFromDate == -1){
			errorMsg = "Invalid '" + fieldName + "' Date";
		}else if(validToDate == -1){
			errorMsg = "Invalid '" + fieldName + "' Date";
			errorTarget = toTag;
		}
	}
	
	if(errorMsg != ""){
		showPopMessage(errorMsg, function() {
			setElementFocus(errorTarget);
		});
		
		return false;
	}
	
	return true;
}

/*
Author : rakesh
Input : fieldArr  {Field Name Array}

Discription : Function 'trimFreeTextField' trim leading and triling blanks 
	along with "Upper Casing" data fields from free text fields
	(for Bug #371 (Trim leading/trailing blanks, along with "Upper Casing" data fields)
*/
function trimUpperCaseFreeTextField(fieldArr){
	if(fieldArr != null && fieldArr.length > 0){
		var fieldName;
		for(var i=0;i<fieldArr.length;i++) {
			fieldName = fieldArr[i];
			if(getElement(fieldName) != null && isBlankOrNULL(fieldName) == false) {
				var fieldValue = dwr.util.getValue(fieldName);
				fieldValue = fieldValue.trim(); // trimming the value
				fieldValue = fieldValue.toUpperCase();
				dwr.util.setValue(fieldName, fieldValue);
			}
		}
	}
}


/*
Author : Rakesh
Function 'validateForm'
Input: true (is come from Discrepancy Details page) | false (for other pages)
Discription : ValidateForm search Form for different pages.
*/
function validateForm(isForDiscDetails){
	// fields which required trim & upper case 
	var fieldArr = new Array("hicNbr", "updateId");
	trimUpperCaseFreeTextField(fieldArr);
	
	if(isForDiscDetails){
		var result = true;
		
		if(isBlankOrNULL("planName")){ // validate Plan Name
			showPopMessage(REQUIRED_PLAN_NAME, function(){
				setElementFocus("planName");
			});
			result = false;
		}else {
			var isHICBlank = isBlankOrNULL("hicNbr");
			var frDtBlank = isBlankOrNULL("fromDate");
			var toDtBlank = isBlankOrNULL("toDate");

			var menuName = dwr.util.getValue("menuName");
			if(menuName == 'beneDiscrpDetail' || menuName == 'troop') {
				if(isHICBlank){
					showPopMessage(REQUIRED_HIC_NUM, function(){
						setElementFocus("hicNbr");
					});
					result = false;
				} else {
					if(validateAlphaNumaric("hicNbr") == false){
						showPopMessage(MSG_INVALID_HIC_NUMBER, function(){
							setElementFocus("hicNbr");
						});
						return false;
					} else if (validate2Date("fromDate", "toDate", "", "Effective") == false)
						result = false;
				}
			} else {
				if(isHICBlank && frDtBlank && toDtBlank){
					showPopMessage(REQUIRED_HIC_AND_EFECTIVE_DATE, function(){
						setElementFocus("hicNbr");
					});
					result = false;
				}else if(isHICBlank ) {
					if(validate2Date("fromDate", "toDate", "", "Effective") == false){ // validate Effective Date
						result = false;
					}
				}else if(!isHICBlank){
					if(validateAlphaNumaric("hicNbr") == false){
						showPopMessage(MSG_INVALID_HIC_NUMBER, function(){
							setElementFocus("hicNbr");
						});
						return false;
					} else if (validate2Date("fromDate", "toDate", "", "Effective") == false)
						result = false;
				}
			}
		}
		
		if(result != false && validate2Date("updateDateFrom", "updateDateTo" , "Update", "Update") == false) { // validate Update Date
			result = false;
		}
		
		if(result != false && isBlankOrNULL("updateId") == false && validateAlphaNumaric("updateId") == false){ // validating Update Id
			showPopMessage(MSG_INVALID_UPDATE_ID, function(){
				setElementFocus("updateId");
			});
			
			result = false;
		}
		
		return result;
	} else {
		// validation for Plan Name (In case of Beneficiary Disc. Detail Page)
		if(getElement("planName") != null  && isBlankOrNULL("planName")){ // validate Plan Name
		showPopMessage(REQUIRED_PLAN_NAME, function(){
			setElementFocus("planName");
		});
			return false;
		}

		var pageName = dwr.util.getValue("methodName");
		if(pageName == PAGE_PDE_DASHBOARD  || pageName == PAGE_PDE_DETAIL 
			|| pageName == PAGE_TROOP_DASHBOARD || pageName == PAGE_TROOP_DETAIL
			|| pageName=="pdeErrDB" || pageName=="pdeErrDetail"
		) {
			
			if(isBlankOrNULL("hicNbr") == false && validateAlphaNumaric("hicNbr") == false){
				showPopMessage(MSG_INVALID_HIC_NUMBER, function(){
					setElementFocus("hicNbr");
				});
				return false;
			}
			
			var type = "";
			if(pageName == PAGE_PDE_DETAIL || pageName=="pdeErrDetail"){
				type = "Update";
//				correctPdeDateFormat(); //checking & correcting date Format 
			}
			return validate2Date("fromDate", "toDate", type, "Service Date" );
			
		}else 
		if(getElement("hicNbr") != null){
			if(isBlankOrNULL("hicNbr")){
				showPopMessage(REQUIRED_HIC_NUM, function(){
					setElementFocus("hicNbr");
				});
				return false;
			}else {
				if(validateAlphaNumaric("hicNbr") == false){
					showPopMessage(MSG_INVALID_HIC_NUMBER, function(){
						setElementFocus("hicNbr");
					});
					return false;
				}
			}
		}

		var dateType = dwr.util.getValue("dateType");
		var dateTypeName = "Effective";
		if(dateType == "A")
			dateTypeName = "Apply";
		return validate2Date("fromDate", "toDate", "", dateTypeName);
	}
}


/*
Discription : 'setElementFocus' is used to set focus on HTML ELEMENT
*/
function setElementFocus(eleName){
	var ele = getElement(eleName);
	if(ele != null)
		ele.focus();
}
/*
Discription : correct Pde Service Date formate
if Service Date MM/DDDD will convert into MM/DD/YYYY formate.
*/
function correctPdeDateFormat(){
	if(getElement("fromDate")){
		var fromDate = dwr.util.getValue("fromDate");
		var toDate = dwr.util.getValue("toDate");
		if(fromDate.length == 7) {
			fromDate = addDayinMMYYYY(fromDate, true);
			toDate = addDayinMMYYYY(toDate, false);
			dwr.util.setValue("toDate", toDate);
			dwr.util.setValue("fromDate", fromDate);
		}
	}
}

function addDayinMMYYYY(dateValue, isForFirst){
	if(dateValue && dateValue.length == 7){
		var tempArr = dateValue.split("/");
		if(tempArr.length != 2)
			return dateValue;
		var month = parseInt(tempArr[0], 10); // getting day "MM"
		month = (month < 10) ? "0"+ month : month;
		var year = parseInt(tempArr[1], 10); // getting day "YYYY"
		var day = (isForFirst) ? "01" : daysInMonth(month, year);
		return month + "/" + day + "/" + year;
	}
}


/*
Discription : will return you last date of the month
*/
function daysInMonth(month,year) {
	var monthDays = [31,28,31,30,31,30,31,31,30,31,30,31];
	if (month != 2) 
		return monthDays[month - 1];
	if (year%4 != 0) 
		return monthDays[1];
	if (year%100 == 0 && year%400 != 0) 
		return monthDays[1];
	return monthDays[1] + 1;
}