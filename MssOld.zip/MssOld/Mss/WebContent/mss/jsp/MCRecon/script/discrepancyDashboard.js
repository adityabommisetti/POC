var globalFilterVO ;
var filterVO;
/*
Author : Deepak
Discription : Call back of getDescrepancyDashboard.
*/
function CBGetDiscrepancyDashBoard(data, searchType, planId, yearId) {
	if(searchType =='year') {
		populateDiscrepancyYears(data,planId);
	} else if (searchType == 'month' ) {
		populateDiscrepancyMonth(data,planId ,yearId)
	} 
	resetBodyHeight();
}

/*
Author : Deepak
Discription : This method populate Year on discrepancy dashboard.
*/
function populateDiscrepancyYears(data,planId ) {
	var id = planId ;
	if( data == null || data.length == 0 ) {
		showPopMessage(MSG_NO_DATA_FOUND);
		var e = document.getElementById(id);
		e.innerHTML='<table><tr><td colspan="12"></td></tr></table>';
		return;
	}
	var html ='<table width="100%"  border="0" cellspacing="0" cellpadding="0">';
	var discrepancyVo = {rollupId:null,countPartC:null,openPartC:null,
				  inProgressPartC:null,forceClosedPartC:null,resolvedPartC:null
				  ,countPartD:null,openPartD:null,
				  inProgressPartD:null,forceClosedPartD:null,resolvedPartD:null};

	for(var i=0; i< data.length;i++) {
		var color = true ;
		if(i%2 == 1) {
			color = false;
		}
		discrepancyVo = data[i];
		html += createDiscrepancyYearRow(id, discrepancyVo, color);
	} 
	html +='</table>';
	var e = document.getElementById(id);
	e.innerHTML=html;
	e.setAttribute("isBodyExists", "true");
	e.setAttribute("rowExpanded", "true");
}

/*
Author : Deepak
Discription : This method populate Month on discrepancy dashboard.
*/
function populateDiscrepancyMonth(data,planId ,yearId) {
	var id = planId ;
	var year = yearId;
	if( data ==null || data.length == 0 ) {
		showPopMessage(MSG_NO_DATA_FOUND);
		var e = document.getElementById(id +year );
		e.innerHTML='<table><tr><td ></td></tr></table>';
		return;
	}
	var html ='<table width="100%"  border="0" cellspacing="0" cellpadding="0">';
	var discrepancyVo = {rollupId:null,countPartC:null,openPartC:null,
				  inProgressPartC:null,forceClosedPartC:null,resolvedPartC:null
				  ,countPartD:null,openPartD:null,
				  inProgressPartD:null,forceClosedPartD:null,resolvedPartD:null};
	for(var i=0; i < data.length ;i++ ) {
		var color = true ;
		if(i%2 == 1) {
			color = false;
		}
		discrepancyVo = data[i];
		html += createDiscrepancyMonthRow(id,year ,discrepancyVo , color);
	} 
	html +='</table>';
	var e = document.getElementById(id +'_'+year );
	e.innerHTML=html;
	e.setAttribute("isBodyExists", "true");
	e.setAttribute("rowExpanded", "true");
}

/*
Author : Deepak
Discription : This method populate year Row on discrepancy dashboard.
*/

function createDiscrepancyYearRow(id,discrepancyVo, color) {
	var html ='';
	var startPlan ='<tr class="evenrow">'
	if(color) { 
		startPlan ='<tr class="oddrow">';
	}
	startPlan += '<td width="5%" align="right"><img src="/mss/jsp/Recon/images/Plus.png" width="12" height="12" onclick = "useLoadingImage(this); toggleVisibilitydownByYear(this,\'DiscrepancyDashBoard\',\''+id+'\',\''+discrepancyVo.rollupId+'\');" style="cursor:pointer;">&nbsp;&nbsp;</td>';
	html += startPlan;
	var href = '<a href="#" class="plan" onclick="submitDiscrepancyDashBoardAction(\'DiscrepancySummary\',\'Part C\',\'year\',\'';
	var parameter = '\',\''+id+'\',\''+discrepancyVo.rollupId+'\');">'
	html += '<td><a href="#" class="plan" onclick="submitDiscrepancyDashBoardAction(\'DiscrepancySummary\',\'Both\',\'year\',\'NotClosed\',\''+id+'\',\''+discrepancyVo.rollupId+'\');">' +discrepancyVo.rollupId +'</a></td>';
	var tagEnd = '&nbsp;</a></td>';
	//part C
    html += getColumn('<td width="8%" align="right" valign="middle">' ,href ,'ALL', parameter ,discrepancyVo.countPartC , tagEnd );
    html += getColumn('<td width="8%" align="right" valign="middle">' ,href ,'Open', parameter ,discrepancyVo.openPartC , tagEnd );
    html += getColumn('<td width="8%" align="right" valign="middle">' ,href ,'inProgress', parameter ,discrepancyVo.inProgressPartC , tagEnd );
    html += getColumn('<td width="8%" align="right" valign="middle">' ,href ,'Fclo', parameter ,discrepancyVo.forceClosedPartC , tagEnd );
    html += getColumn('<td width="8%" align="right" valign="middle">' ,href ,'RSLV', parameter ,discrepancyVo.resolvedPartC , tagEnd );
	 
  // part -D  
    href = '<a href="#" class="plan" onclick="submitDiscrepancyDashBoardAction(\'DiscrepancySummary\',\'Part D\',\'year\',\'';
    
    html += getColumn('<td width="8%" align="right" valign="middle">' ,href ,'ALL', parameter ,discrepancyVo.countPartD , tagEnd );
    html += getColumn('<td width="8%" align="right" valign="middle">' ,href ,'Open', parameter ,discrepancyVo.openPartD , tagEnd );
    html += getColumn('<td width="8%" align="right" valign="middle">' ,href ,'inProgress', parameter ,discrepancyVo.inProgressPartD , tagEnd );
    html += getColumn('<td width="8%" align="right" valign="middle">' ,href ,'Fclo', parameter ,discrepancyVo.forceClosedPartD , tagEnd );
    html += getColumn('<td width="8%" align="right" valign="middle">' ,href ,'RSLV', parameter ,discrepancyVo.resolvedPartD , tagEnd );
	html +='</tr>';
	html += '<tr><td colspan="12"><div id="'+ id +'_' + discrepancyVo.rollupId+'" style="display:none"></div></td></tr>';
	return html;
}
//This generate column base on value.
function getColumn(td, href, discrepancyType, parameter, value , tagEnd ) {
	if ( value == '0') {
		return td + '&nbsp;' + tagEnd ;
	} else {
		return td + href + discrepancyType + parameter + value + '&nbsp;' + tagEnd ;
	}
}

/*
Author : Deepak
Discription : This method populate month Row on discrepancy dashboard.
*/
function createDiscrepancyMonthRow(id,year,discrepancyVo,color) {
	var html ='';
	var startPlan = '<tr class="evenrow"><td width="7%" align="center" >&nbsp;</td>';
	
	if(color) { 
		startPlan = '<tr class="oddrow"><td width="7%" align="center">&nbsp;</td>';
	}
	var href = '<a href="#" class="plan" onclick="submitDiscrepancyDashBoardAction(\'DiscrepancySummary\',\'Part C\',\'month\',\'';
	var parameter = '\',\''+id+'\',\''+year+'\',\''+getMonthValue(discrepancyVo.rollupId)+'\');">';
	var tagEnd = '&nbsp;</a></td>';
	
	html +=startPlan;																							
 	html += '<td align="left"> <a href="#" class="plan" onclick="submitDiscrepancyDashBoardAction(\'DiscrepancySummary\',\'Both\',\'month\',\'NotClosed\',\''+id+'\',\''+year+'\',\''+getMonthValue(discrepancyVo.rollupId)+'\');">' +discrepancyVo.rollupId +'</a></td>';
	//part C
    html += getColumn('<td width="8%" align="right" valign="middle">' ,href ,'ALL', parameter ,discrepancyVo.countPartC , tagEnd );
    html += getColumn('<td width="8%" align="right" valign="middle">' ,href ,'Open', parameter ,discrepancyVo.openPartC , tagEnd );
    html += getColumn('<td width="8%" align="right" valign="middle">' ,href ,'inProgress', parameter ,discrepancyVo.inProgressPartC , tagEnd );
    html += getColumn('<td width="8%" align="right" valign="middle">' ,href ,'Fclo', parameter ,discrepancyVo.forceClosedPartC , tagEnd );
    html += getColumn('<td width="8%" align="right" valign="middle">' ,href ,'RSLV', parameter ,discrepancyVo.resolvedPartC , tagEnd );
	 
  // part -D  
    href = '<a href="#" class="plan" onclick="submitDiscrepancyDashBoardAction(\'DiscrepancySummary\',\'Part D\',\'month\',\'';
    
    html += getColumn('<td width="8%" align="right" valign="middle">' ,href ,'ALL', parameter ,discrepancyVo.countPartD , tagEnd );
    html += getColumn('<td width="8%" align="right" valign="middle">' ,href ,'Open', parameter ,discrepancyVo.openPartD , tagEnd );
    html += getColumn('<td width="8%" align="right" valign="middle">' ,href ,'inProgress', parameter ,discrepancyVo.inProgressPartD , tagEnd );
    html += getColumn('<td width="8%" align="right" valign="middle">' ,href ,'Fclo', parameter ,discrepancyVo.forceClosedPartD , tagEnd );
    html += getColumn('<td width="8%" align="right" valign="middle">' ,href ,'RSLV', parameter ,discrepancyVo.resolvedPartD , tagEnd );
   	html += '</tr>';
 	return html;
}
