/*
$Id: paymentDashboard.js,v 1.4 2009/09/21 16:57:32 AIndrapradja Exp $
*/





/*
 * Author Pranitha
 */
function toggleVisibilitydownByPBP(x,pbpId) {
	alert(pbpId);
	getPymtDashBoardValues(pbpId);
	/*var row = document.getElementById(pbpId+"_pbp");
	alert(row);
	var e = document.getElementById(pbpId);
	var flag = true;
	if(e.style.display == 'none') {
		var isBodyExists = e.getAttribute("isBodyExists");
		if(isBodyExists != "true") {
			flag = false;
			getPymtDashBoardValues(pbpId);
		}
		e.setAttribute("rowExpanded", "true");
		e.style.display = "";
		if(row!=null)		
			row.style.display = "";
		x.src = IMAGE_PATH_MINUS_PNG;
	} else {
		e.removeAttribute("rowExpanded");
		e.style.display = 'none';
		if(row!=null)
			row.style.display = 'none';
		x.src = IMAGE_PATH_PLUS_PNG;
	}
	if(flag){
	resetBodyHeight();
	}*/
}

function getPymtDashBoardValues(pbpId){
	alert("yes");
	document.body.className = 'wait';	
  	document.mcaidPaymentForm.method.value = 'yrDrillDown';
  	document.mcaidPaymentForm.submit();
	
	
}

/*function getPymtDashBoard(pbpId){
	FacadeManager.getMcaidPaymentDashboardByPBP(pbpId,{
		callback:function(data) {
			dwrSelPymtByPBP(data,pbpId);}
  			});	
}
function dwrSelPymtByPBP(data,pbpId){
	//alert("test");
	var id = pbpId ;
	       var list = data;
	    
	       var html ='<table width="100%"  border="0" cellspacing="0" cellpadding="0">';
	   	var planVo = {year:null,cmsPaid:null,planExpected:null,
	   				  diffrence:null};
	   	for(var i=0; i< list.length;i++) {
	   		var color = true ;
	   		if(i%2 == 1) {
	   			color = false;
	   		}
	   
	   	year = data[i].year;
	   	alert(year);
	   	cmsPaid =data[i].cmsPaid;
	   	planExpected = data[i].planExpected;
	   	diffrence = data[i].diffrence;
	   
	   		html += createYearRow(pbpId,year,cmsPaid,planExpected,diffrence,color);
	   	} 
	   	html +='</table>';
	   	var e = document.getElementById(id);
	   	e.innerHTML=html; 
	     

}
function createYearRow(id,year,cmsPaid,planExpected,diffrence,color) {
	
	var html ='';
	var tdTag ='<td width="13%" align="right" valign="middle">';
	var startPlan ='<tr class="evenrow">'
	if(color) { 
		startPlan ='<tr class="oddrow">';
	}
	startPlan += '<td width="5%" align="right">&nbsp;&nbsp;<td>';
	html += startPlan;
	
	if(year == null ) {
		html += tdTag+'&nbsp;' + '&nbsp;</td>';
	}else {
		html += tdTag +year + '&nbsp;&nbsp;</td>';
	}
	//part C
	if(cmsPaid == null ) {
		html += tdTag+'&nbsp;' + '&nbsp;</td>';
	} else {
		html += tdTag +cmsPaid + '&nbsp;&nbsp;</td>';
	}
	if(planExpected == null ) {
		html += tdTag+'&nbsp;' + '&nbsp;</td>';
	} else {
		html += tdTag +planExpected+ '&nbsp;&nbsp;</td>';
	}
	if(diffrence != null && diffrence.charAt(0) == '(' ) {
		html +='<td width="13%" align="right" valign="middle" class="red"  >'+diffrence+'&nbsp;</td>';
	} else if(diffrence == '' ) {
		html += tdTag+diffrence + '&nbsp;</td>';
	} else if(diffrence == null ) {
		html += '<td width="13%" align="right" valign="middle" >'+'&nbsp;' + '&nbsp;</td>';
	} else {
		html += '<td width="13%" align="right" valign="middle" >'+ diffrence + '&nbsp;&nbsp;</td>';
	}
	

	html +='</tr>';
	html+='<tr><td colspan="8"></td></tr>';
	return html;
}
*/
/*
Author : Pranitha
Discription : This method is used to generate on quarter row on dashboard.
*/

function toggleVisibilitydownByYear(x,pbpId,year) {
	alert("ok");
	getPymtDashBoardbyYears(pbpId,year);
	/*var row = document.getElementById(pbpId+"_year");
	var e = document.getElementById(pbpId);
	var flag = true;
	if(e.style.display == 'none') {
		var isBodyExists = e.getAttribute("isBodyExists");
		if(isBodyExists != "true") {
			flag = false;
			getPymtDashBoardbyYears(pbpId,year);
		}
		e.setAttribute("rowExpanded", "true");
		e.style.display = "";
		if(row!=null)		
			row.style.display = "";
		x.src = IMAGE_PATH_MINUS_PNG;
	} else {
		e.removeAttribute("rowExpanded");
		e.style.display = 'none';
		if(row!=null)
			row.style.display = 'none';
		x.src = IMAGE_PATH_PLUS_PNG;
	}
	if(flag){
	resetBodyHeight();
	}*/
}
function getPymtDashBoardbyYears(pbpId,year){
	alert("test"+year);
	document.body.className = 'wait';	
  	document.mcaidPaymentForm.method.value = 'qtrDrillDown';
  	document.mcaidPaymentForm.submit();
}


/*function getPymtDashBoardbyYear(pbpId,year){
	alert(year);
	FacadeManager.getMcaidPaymentDashboardByYear(pbpId,year,{
		callback:function(data) {
			dwrSelPymtByYear(data,pbpId,year);}
  			});	
}
function dwrSelPymtByYear(data,pbpId,year){
	alert("test"+year);
	var id = pbpId ;
	       var list = data;
	    
	       var html ='<table width="100%"  border="0" cellspacing="0" cellpadding="0">';
	   	var planVo = {quarter:null,cmsPaid:null,planExpected:null,
	   				  diffrence:null};
	   	for(var i=0; i< list.length;i++) {
	   		var color = true ;
	   		if(i%2 == 1) {
	   			color = false;
	   		}
	   
	   	year = data[i].quarter;
	   	cmsPaid =data[i].cmsPaid;
	   	planExpected = data[i].planExpected;
	   	diffrence = data[i].diffrence;
	   
	   		html += createQuarterRow(pbpId,year,quarter,cmsPaid,planExpected,diffrence,color);
	   	} 
	   	html +='</table>';
	   	var e = document.getElementById(id);
	   	e.innerHTML=html; 
	     

}

function createQuarterRow(id,year,quarter,cmsPaid,planExpected,diffrence,color) {
	var html ='';
	var tdTag ='<td width="13%" align="right" valign="middle">';
	var startPlan ='<tr class="evenrow"><td width="7%" align="center" ></td>';
	if(color) { 
		startPlan ='<tr class="oddrow"><td width="7%" align="center"></td>';
	}
	html +=startPlan;
	html += '<td align="left"><a href="#" class="plan">' +quarter +'</a></td>';

	//part C
	if(cmsPaid == null ) {
		html += tdTag+'&nbsp;' + '&nbsp;&nbsp;</td>';
	} else {
		html += tdTag +cmsPaid + '&nbsp;&nbsp;</td>';
	}
	if(planExpected == null ) {
		html += tdTag+'&nbsp;' + '&nbsp;&nbsp;</td>';
	} else {
		html += tdTag + planExpected + '&nbsp;&nbsp;</td>';
	}
	if(diffrence != null && diffrence.charAt(0) == '(' ) {
		html +='<td width="13%" align="right" valign="middle" class="red" >'+diffrence+'&nbsp;</td>';
	} else if(diffrence == '' ) {
		html += '<td width="13%" align="right" valign="middle" >'+diffrence + '&nbsp;</td>';
	} else if(diffrence == null ) {
		html += '<td width="13%" align="right" valign="middle" >'+'&nbsp;' + '&nbsp;</td>';
	} else {
		html += '<td width="13%" align="right" valign="middle" >'+ diffrence + '&nbsp;&nbsp;</td>';
	}
	
	html +='</tr>';
	return html;
}*/


/*
Author : Pranitha
Discription : This method is used to generate on month row on dashboard.
*/

function toggleVisibilitydownByQuarter(x,pbpId,year,quarter) {
	getPymtDashBoardbyQuarter(pbpId,year,quarter);
	/*var row = document.getElementById(pbpId+"_quarter");
	var e = document.getElementById(pbpId);
	var flag = true;
	if(e.style.display == 'none') {
		var isBodyExists = e.getAttribute("isBodyExists");
		if(isBodyExists != "true") {
			flag = false;
			getPymtDashBoardbyQuarter(pbpId,year,quarter);
		}
		e.setAttribute("rowExpanded", "true");
		e.style.display = "";
		if(row!=null)		
			row.style.display = "";
		x.src = IMAGE_PATH_MINUS_PNG;
	} else {
		e.removeAttribute("rowExpanded");
		e.style.display = 'none';
		if(row!=null)
			row.style.display = 'none';
		x.src = IMAGE_PATH_PLUS_PNG;
	}
	if(flag){
	resetBodyHeight();
	}*/
}
function getPymtDashBoardbyQuarter(pbpId,year,quarter){
	alert("test"+quarter);
	document.body.className = 'wait';	
  	document.mcaidPaymentForm.method.value = 'mnthDrillDown';
  	document.mcaidPaymentForm.submit();
}


/*function getPymtDashBoardbyQuarter(pbpId,year,quarter){
	FacadeManager.getMcaidPaymentDashboardByQuarter(pbpId,year,{
		callback:function(data) {
			dwrSelPymtByQuarter(data,pbpId,year);}
  			});	
}
function dwrSelPymtByQuarter(data,pbpId,year,quarter){
	alert("test");
	var id = pbpId ;
	       var list = data;
	    
	       var html ='<table width="100%"  border="0" cellspacing="0" cellpadding="0">';
	   	var planVo = {month:null,cmsPaid:null,planExpected:null,
	   				  diffrence:null};
	   	for(var i=0; i< list.length;i++) {
	   		var color = true ;
	   		if(i%2 == 1) {
	   			color = false;
	   		}
	   
	   	year = data[i].month;
	   	cmsPaid =data[i].cmsPaid;
	   	planExpected = data[i].planExpected;
	   	diffrence = data[i].diffrence;
	   
	   		html += createQuarterRow(pbpId,year,quarter,month,cmsPaid,planExpected,diffrence,color);
	   	} 
	   	html +='</table>';
	   	var e = document.getElementById(id);
	   	e.innerHTML=html; 
	     

}

function createQuarterRow(id,year,quarter,month,cmsPaid,planExpected,diffrence,color) {
	var html ='';
	var tdTag ='<td width="13%" align="right" valign="middle">';
	var startPlan ='<tr class="evenrow"><td width="7%" align="center" ></td>';
	if(color) { 
		startPlan ='<tr class="oddrow"><td width="7%" align="center"></td>';
	}
	html +=startPlan;
	html += '<td align="left"><a href="#" class="plan" onclick="  submitPaymentDashboardAction(\'PaymentSummary\',\'month\',\''+id+'\',\''+year+'\',\''+quarter+'\',\''+month+'\');">' +month +'</a></td>';

	//part C
	if(cmsPaid == null ) {
		html += tdTag+'&nbsp;' + '&nbsp;&nbsp;</td>';
	} else {
		html += tdTag +cmsPaid + '&nbsp;&nbsp;</td>';
	}
	if(planExpected == null ) {
		html += tdTag+'&nbsp;' + '&nbsp;&nbsp;</td>';
	} else {
		html += tdTag + planExpected + '&nbsp;&nbsp;</td>';
	}
	if(diffrence != null && diffrence.charAt(0) == '(' ) {
		html +='<td width="13%" align="right" valign="middle" class="red" >'+diffrence+'&nbsp;</td>';
	} else if(diffrence == '' ) {
		html += '<td width="13%" align="right" valign="middle" >'+diffrence + '&nbsp;</td>';
	} else if(diffrence == null ) {
		html += '<td width="13%" align="right" valign="middle" >'+'&nbsp;' + '&nbsp;</td>';
	} else {
		html += '<td width="13%" align="right" valign="middle" >'+ diffrence + '&nbsp;&nbsp;</td>';
	}
	
	html +='</tr>';
	return html;
}*/
