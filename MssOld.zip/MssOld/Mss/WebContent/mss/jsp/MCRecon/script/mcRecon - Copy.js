/* author: prare
 * created date: 12/11/2015
 * 
 */
function switchMenu(val) {
  document.forms[0].method.value = 'switchMenu';
  document.forms[0].menu.value = val;
  document.forms[0].submit();
}

function switchSubMenu(valSubMenu) {
//	alert(valSubMenu);
	document.forms[0].subMenu.value = valSubMenu;
	document.forms[0].submit();
}


function paySummData(pbp, year, qtr, month) {
	//alert("Hi: "+pbp +" : "+year+" : "+qtr+":: month:"+month);
	document.forms[0].summSrchPbp.value = pbp;	
	document.forms[0].summSrchYear.value = year;
	document.forms[0].summSrchQtr.value = qtr;
	document.forms[0].summSrchMonth.value = month;
	
	document.forms[0].method.value = 'paySummData';
	document.forms[0].subMenu.value = 'SubmenuPaymentSummary';
	document.forms[0].submit();	
}


function getPaySummMedicaidDetails(paymentType) {
	//alert("Hi: "+paymentType );	
	document.forms[0].summSrchPaymentType.value = paymentType;	
	document.forms[0].method.value = 'PaySummMedicaidDetails';
	//document.forms[0].subMenu.value = 'SubmenuPaymentSummary';
	document.forms[0].submit();	
}

/*Payment Summary-Medicaid list Pagination -START*/

function paySumMedicaidSearchPageFirst(){
	document.body.className = 'wait';	 	
	document.forms[0].method.value = 'paySumMedicaidSearchPageFirst';
	document.forms[0].submit();
}

function paySumMedicaidSearchPageNext(){
	document.body.className = 'wait';  	
	document.forms[0].method.value = 'paySumMedicaidSearchPageNext';
	document.forms[0].submit();
}

function paySumMedicaidSearchPagePrev(){
	document.body.className = 'wait';
	document.forms[0].method.value = 'paySumMedicaidSearchPagePrev';
	document.forms[0].submit();
}
/*Payment Summary-Medicaid list Pagination - END*/

function isNeagtiveAmount( val ){
	if(val != null || val != ""){
	if(val.charAt(0) == '('){
		val = "<div style='color:red;'>"+ val +"</div>";
	}else{
		val = "<div>"+ val +"</div>";
	}
	}
	return val;
}







function toggleVisibility(ctl, id, usrSelect, pbp, year, qtr) {
	var elem = document.getElementById(id);	
	toggleVisibilityElem(ctl, elem, usrSelect, pbp, year, qtr);
}
function toggleVisibilityElem(ctl, elem, usrSelect, pbp, year, qtr) {
	//alert(" in toggle"+ctl+elem+elem.style.display+usrSelect);
		if(elem.style.display == 'none'){
		elem.style.display = "";
		elem.setAttribute("rowExpanded", "true");
		ctl.src = '/mss/jsp/MCRecon/images/Minus.png';
		
		if(usrSelect=="PBP"){
			dwrPayDsbPBPSelect(pbp);
		}
		else if(usrSelect == 'YEAR'){
			dwrPayDsbYEARSelect(pbp, year);
		}
		else if(usrSelect == 'QUART'){
			dwrPayDsbQUARTSelect(pbp, year, qtr);			
		}
		
	}
	if(elem.style.display == "") {
			elem.style.display = 'none';
			elem.setAttribute("rowExpanded", "false");
			ctl.src = '/mss/jsp/MCRecon/images/Plus.png';		
	} 
}//toggleVisibilityElem()

//===============================================================================================

function dwrPayDsbPBPSelect(pbp) {
	FacadeManager.getMcaidPaymentDashboardByPBP(pbp, {
		callback:function(data) {
			dwrPayDsbPBPSelectData(pbp, data);
		}
	});
}//PayDsbPBPSelect()

function dwrPayDsbPBPSelectData(pbp, data) {
	var list = data;
	var css ;	
	var content = "<TABLE border='0' align='center' cellpadding='0' cellspacing='0' style='border-collapse:collapse'>"		
		for(var i=0 ; i < list.length ; i++) {
			var currVO = list[i];
			css = i%2 == 0 ? "oddRow" : "evenRow";
		
				var tempContent= "<tr align='center' valign='middle'>"		
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				
				+ "<td class='"+css+"' width='30pt' align='center' valign='middle' class='head2'>"
				+ "		<img src='/mss/jsp/MCRecon/images/Plus.png' width='12' height='12' style='cursor:pointer;'	"
				+ " 	onclick=toggleVisibility(this,'tr"+pbp+currVO.year+"','YEAR','"+pbp+"','"+currVO.year+"',null); >" 
				+ "</td>"
				
				+ "<td class='"+css+"' width='460pt' align='left'  valign='middle' class='head2'><a onclick=paySummData('"+pbp+"','"+currVO.year+"','',''); href='#' class='plan' >"+currVO.year+"</a></td>"
				+ "<td class='"+css+"' width='130pt' align='right' valign='middle' class='head2'>"+currVO.cmsPaid+"</td>"
				+ "<td class='"+css+"' width='130pt' align='right' valign='middle' class='head2'>"+currVO.planExpected+"</td>"
				+ "<td class='"+css+"' width='130pt' align='right' valign='middle' class='head2'>"+isNeagtiveAmount(currVO.diffrence)+"</td>"
				+ "</tr>"
				
				+ "<tr id='tr"+pbp+currVO.year+"' style='display:none;'>"
				+ "		<td colspan='6'><div id='div"+pbp+currVO.year+"'></div></td>"
				+ "</tr>";
				
			content = content+tempContent;
		}//for
	content = content +"</TABLE>";
	document.getElementById('div'+pbp).innerHTML = content ;	
}//dwrPayDsbPBPSelectData()

//=====================================================================================

function dwrPayDsbYEARSelect(pbp, year) {
	FacadeManager.getMcaidPaymentDashboardByYear(pbp, year, {
		callback:function(data) {
			dwrPayDsbYEARSelectData(pbp, year, data);
		}
	});
}//dwrPayDsbYEARSelect()


function dwrPayDsbYEARSelectData(pbp, year,  data) {	
	var list = data;
	var css ;	
	var content = "<TABLE border='0' align='center' cellpadding='0' cellspacing='0' style='border-collapse:collapse'>"
		
		for(var i=0 ; i < list.length ; i++) {
			var currVO = list[i];
			css = i%2 == 0 ? "oddRow" : "evenRow";
		
				var tempContent= "<tr align='center' valign='middle'>"		
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				
				+ "<td class='"+css+"' width='30pt' align='center' valign='middle' class='head2'>"
				+ "		<img src='/mss/jsp/MCRecon/images/Plus.png' width='12' height='12' style='cursor:pointer;'	"
				+ " 	onclick=toggleVisibility(this,'tr"+pbp+year+currVO.quarter+"','QUART','"+pbp+"','"+year+"','"+currVO.quarter+"'); >" 
				+ "</td>"
				
				/*+ "<td class='"+css+"' width='440pt' align='left'  valign='middle' class='head2'>"+currVO.quarter+"</td>"*/
				+ "<td class='"+css+"' width='440pt' align='left'  valign='middle' class='head2'><a onclick=paySummData('"+pbp+"','"+year+"','"+currVO.quarter+"',''); href='#' class='plan' >&nbsp;"+currVO.quarter+"</a></td>"
				+ "<td class='"+css+"' width='130pt' align='right' valign='middle' class='head2'>"+currVO.cmsPaid+"</td>"
				+ "<td class='"+css+"' width='130pt' align='right' valign='middle' class='head2'>"+currVO.planExpected+"</td>"
				+ "<td class='"+css+"' width='130pt' align='right' valign='middle' class='head2'>"+isNeagtiveAmount(currVO.diffrence)+"</td>"			
				+ "</tr>"
				
				+ "<tr id='tr"+pbp+year+currVO.quarter+"' style='display:none;'>"
				+ "		<td colspan='7'><div id='div"+pbp+year+currVO.quarter+"'></div></td>"
				+ "</tr>";
				
			content = content+tempContent;
		}//for
	content = content +"</TABLE>";	
	document.getElementById('div'+pbp+year).innerHTML = content ;	
}//dwrPayDsbYEARSelectData()

//=====================================================================================

function dwrPayDsbQUARTSelect(pbp, year, qtr) {	
	FacadeManager.getMcaidPaymentDashboardByQuarter(pbp, year, qtr, {
		callback:function(data) {
			dwrPayDsbQUARTSelectData(pbp, year, qtr, data);
		}
	});
}//dwrPayDsbQUARTSelect()


function dwrPayDsbQUARTSelectData(pbp, year, qtr, data) {	
	var list = data;
	var css ;	
	var content = "<TABLE border='0' align='center' cellpadding='0' cellspacing='0' style='border-collapse:collapse'>"
		
		for(var i=0 ; i < list.length ; i++) {
			var currVO = list[i];
			css = i%2 == 0 ? "oddRow" : "evenRow";
		
				var tempContent= "<tr align='center' valign='middle'>"		
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				
				/*+ "<td class='"+css+"' width='30pt' align='center' valign='middle' class='head2'>"
				+ "		<img src='/mss/jsp/MCRecon/images/Plus.png' width='12' height='12' style='cursor:pointer;'	"
				+ " 	onclick=toggleVisibility(this,'tr"+pbp+year+currVO.quarter+"','QUART','"+pbp+"','"+year+"','"+currVO.quarter+"'); >" 
				+ "</td>"*/
				
				/*+ "<td class='"+css+"' width='430pt' align='left'  valign='middle' class='head2'>"+currVO.month+"</td>"*/
				+ "<td class='"+css+"' width='430pt' align='left'  valign='middle' class='head2'><a onclick=paySummData('"+pbp+"','"+year+"','"+qtr+"','"+currVO.month+"'); href='#' class='plan' >&nbsp;"+getMonthName(currVO.month)+"</a></td>"
				+ "<td class='"+css+"' width='130pt' align='right' valign='middle' class='head2'>"+currVO.cmsPaid+"</td>"
				+ "<td class='"+css+"' width='130pt' align='right' valign='middle' class='head2'>"+currVO.planExpected+"</td>"
				+ "<td class='"+css+"' width='130pt' align='right' valign='middle' class='head2'>"+isNeagtiveAmount(currVO.diffrence)+"</td>"			
				+ "</tr>"
				
				/*+ "<tr id='tr"+pbp+year+currVO.quarter+"' style='display:none;'>"
				+ "		<td colspan='6'><div id='div"+pbp+year+currVO.quarter+"'>Hi div:"+pbp+year+currVO.quarter+"</div></td>"
				+ "</tr>";*/
				
			content = content+tempContent;
		}//for
	content = content +"</TABLE>";	
	document.getElementById('div'+pbp+year+qtr).innerHTML = content ;	
}//dwrPayDsbQUARTSelectData()


//=====================================================================================



//**********************ANOMALY**************************************
function anomSummData(pbp, year, qtr, month, status) {
	//alert("Hi: "+pbp +" : "+year+" : "+qtr+":: month:"+month);
	document.forms[0].summSrchPbp.value = pbp;	
	document.forms[0].summSrchYear.value = year;
	document.forms[0].summSrchQtr.value = qtr;
	document.forms[0].summSrchMonth.value = month;
	document.forms[0].summSrchStatus.value = status;
	
	document.forms[0].method.value = 'anomSummList';
	document.forms[0].subMenu.value = 'SubmenuAnomSummary';
	document.forms[0].submit();	
}

/* Summary-List Pagination -START*/

function anomSumListSearchPageFirst(){
	document.body.className = 'wait';	 	
	document.forms[0].method.value = 'anomSummListPageFirst';
	document.forms[0].submit();
}

function anomSumListSearchPageNext(){
	document.body.className = 'wait';  	
	document.forms[0].method.value = 'anomSummListPageNext';
	document.forms[0].submit();
}

function anomSumListSearchPagePrev(){
	document.body.className = 'wait';
	document.forms[0].method.value = 'anomSummListPagePrev';
	document.forms[0].submit();
}
/*Summary-List Pagination - END*/

function anomSummListRowClick(rowSelect) {		
	document.forms[0].summSrchListRowSelect.value = rowSelect;	
	document.forms[0].method.value = 'anomSummDetails';
	//document.forms[0].subMenu.value = 'SubmenuAnomSummary';
	document.forms[0].submit();	
}

function summStatusUpdate() {
	document.forms[0].method.value = 'anomSummStatusUpdate';
	document.forms[0].submit();	
}


function getMonthName(mon) {
	var month = new Array();
	month[0] = "January";
	month[1] = "February";
	month[2] = "March";
	month[3] = "April";
	month[4] = "May";
	month[5] = "June";
	month[6] = "July";
	month[7] = "August";
	month[8] = "September";
	month[9] = "October";
	month[10] = "November";
	month[11] = "December";
	return month[mon-1];
}//getMonthName()





function toggleVisibilityAnom(ctl, id, usrSelect, pbp, year, qtr) {
	var elem = document.getElementById(id);	
	toggleVisibilityElemAnom(ctl, elem, usrSelect, pbp, year, qtr);
}

function toggleVisibilityElemAnom(ctl, elem, usrSelect, pbp, year, qtr) {
	if(elem.style.display == "") {
		elem.style.display = 'none';
		elem.setAttribute("rowExpanded", "false");
		ctl.src = '/mss/jsp/MCRecon/images/Plus.png';		
	} else {
		elem.style.display = "";
		elem.setAttribute("rowExpanded", "true");
		ctl.src = '/mss/jsp/MCRecon/images/Minus.png';
		
		if(usrSelect=="PBP"){
			dwrAnomDsbPBPSelect(pbp);
		}
		else if(usrSelect == 'YEAR'){
			dwrAnomDsbYEARSelect(pbp, year);
		}
		else if(usrSelect == 'QUART'){
			dwrAnomDsbQUARTSelect(pbp, year, qtr);			
		}
		
	}//else
}//toggleVisibilityElemAnom()

//=====================================================================================
function dwrAnomDsbPBPSelect(pbp) {
	FacadeManager.getMcaidAnomDashboardByPBP(pbp, {
		callback:function(data) {
			dwrAnomDsbPBPSelectData(pbp, data);
		}
	});
}//dwrAnomDsbPBPSelect()

function dwrAnomDsbPBPSelectData(pbp, data) {
	var list = data;
	var css ;	
	var content = "<TABLE border='0' align='center' cellpadding='0' cellspacing='0' style='border-collapse:collapse'>"		
		for(var i=0 ; i < list.length ; i++) {
			var currVO = list[i];
			css = i%2 == 0 ? "oddRow" : "evenRow";
		
				var tempContent= "<tr align='center' valign='middle'>"		
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				
				+ "<td class='"+css+"' width='30pt' align='center' valign='middle' class='head2'>"
				+ "		<img src='/mss/jsp/MCRecon/images/Plus.png' width='12' height='12' style='cursor:pointer;'	"
				+ " 	onclick=toggleVisibilityAnom(this,'tr"+pbp+currVO.year+"','YEAR','"+pbp+"','"+currVO.year+"',null); >" 
				+ "</td>"
				
				+ "<td class='"+css+"' width='380pt' align='left'  valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+currVO.year+"','','','total'); href='#' class='plan' >"+currVO.year+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+currVO.year+"','','','total'); href='#' class='plan' >"+currVO.total+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+currVO.year+"','','','open'); href='#' class='plan' >"+currVO.open+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+currVO.year+"','','','inProg'); href='#' class='plan' >"+currVO.inProgress+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+currVO.year+"','','','forcls'); href='#' class='plan' >"+currVO.forceClose+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+currVO.year+"','','','resolv'); href='#' class='plan' >"+currVO.resolved+"</a></td>"
				+ "</tr>"
				
				+ "<tr id='tr"+pbp+currVO.year+"' style='display:none;'>"
				+ "		<td colspan='8'><div id='div"+pbp+currVO.year+"'></div></td>"
				+ "</tr>";
				
			content = content+tempContent;
		}//for
	content = content +"</TABLE>";
	document.getElementById('div'+pbp).innerHTML = content ;	
}//dwrAnomDsbPBPSelectData()

//=====================================================================================

function dwrAnomDsbYEARSelect(pbp, year) {
	FacadeManager.getMcaidAnomDashboardByYear(pbp, year, {
		callback:function(data) {
			dwrAnomDsbYEARSelectData(pbp, year, data);
		}
	});
}//dwrAnomDsbYEARSelect()


function dwrAnomDsbYEARSelectData(pbp, year,  data) {	
	var list = data;
	var css ;	
	var content = "<TABLE border='0' align='center' cellpadding='0' cellspacing='0' style='border-collapse:collapse'>"
		
		for(var i=0 ; i < list.length ; i++) {
			var currVO = list[i];
			css = i%2 == 0 ? "oddRow" : "evenRow";
		
				var tempContent= "<tr align='center' valign='middle'>"		
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				
				+ "<td class='"+css+"' width='30pt' align='center' valign='middle' class='head2'>"
				+ "		<img src='/mss/jsp/MCRecon/images/Plus.png' width='12' height='12' style='cursor:pointer;'	"
				+ " 	onclick=toggleVisibilityAnom(this,'tr"+pbp+year+currVO.quarter+"','QUART','"+pbp+"','"+year+"','"+currVO.quarter+"'); >" 
				+ "</td>"
				
				+ "<td class='"+css+"' width='360pt' align='left'  valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+year+"','"+currVO.quarter+"','','total'); href='#' class='plan' >&nbsp;"+currVO.quarter+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+year+"','"+currVO.quarter+"','','total'); href='#' class='plan' >"+currVO.total+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+year+"','"+currVO.quarter+"','','open'); href='#' class='plan' >"+currVO.open+"</a></td>"		
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+year+"','"+currVO.quarter+"','','inProg'); href='#' class='plan' >"+currVO.inProgress+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+year+"','"+currVO.quarter+"','','forcls'); href='#' class='plan' >"+currVO.forceClose+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+year+"','"+currVO.quarter+"','','resolv'); href='#' class='plan' >"+currVO.resolved+"</a></td>"
				+ "</tr>"
				
				+ "<tr id='tr"+pbp+year+currVO.quarter+"' style='display:none;'>"
				+ "		<td colspan='9'><div id='div"+pbp+year+currVO.quarter+"'></div></td>"
				+ "</tr>";
				
			content = content+tempContent;
		}//for
	content = content +"</TABLE>";	
	document.getElementById('div'+pbp+year).innerHTML = content ;	
}//dwrAnomDsbYEARSelectData()

//=====================================================================================

function dwrAnomDsbQUARTSelect(pbp, year, qtr) {	
	FacadeManager.getMcaidAnomDashboardByQuarter(pbp, year, qtr, {
		callback:function(data) {
			dwrAnomDsbQUARTSelectData(pbp, year, qtr, data);
		}
	});
}//dwrAnomDsbQUARTSelect()


function dwrAnomDsbQUARTSelectData(pbp, year, qtr, data) {	
	var list = data;
	var css ;	
	var content = "<TABLE border='0' align='center' cellpadding='0' cellspacing='0' style='border-collapse:collapse'>"
		
		for(var i=0 ; i < list.length ; i++) {
			var currVO = list[i];
			css = i%2 == 0 ? "oddRow" : "evenRow";
		
				var tempContent= "<tr align='center' valign='middle'>"		
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				
				+ "<td class='"+css+"' width='350pt' align='left'  valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+year+"','"+qtr+"','"+currVO.month+"','total'); href='#' class='plan' >&nbsp;"+getMonthName(currVO.month)+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+year+"','"+qtr+"','"+currVO.month+"','total'); href='#' class='plan' >"+currVO.total+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+year+"','"+qtr+"','"+currVO.month+"','open'); href='#' class='plan' >"+currVO.open+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+year+"','"+qtr+"','"+currVO.month+"','inProg'); href='#' class='plan' >"+currVO.inProgress+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+year+"','"+qtr+"','"+currVO.month+"','forcls'); href='#' class='plan' >"+currVO.forceClose+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+year+"','"+qtr+"','"+currVO.month+"','resolv'); href='#' class='plan' >"+currVO.resolved+"</a></td>"
				+ "</tr>"
								
			content = content+tempContent;
		}//for
	content = content +"</TABLE>";	
	document.getElementById('div'+pbp+year+qtr).innerHTML = content ;	
}//dwrAnomDsbQUARTSelectData()


//=====================================================================================






//For Discrepancy Dashboard
function discSummData(pbp, year, qtr, month) {
	//alert("Hi: "+pbp +" : "+year+" : "+qtr+":: month:"+month);
	document.forms[0].summSrchPbp.value = pbp;	
	document.forms[0].summSrchYear.value = year;
	document.forms[0].summSrchQtr.value = qtr;
	document.forms[0].summSrchMonth.value = month;
	
	document.forms[0].method.value = 'paySummData';
	document.forms[0].subMenu.value = 'SubmenuPaymentSummary';
	document.forms[0].submit();	
}


function getPaySummMedicaidDetails(paymentType) {
	//alert("Hi: "+paymentType );	
	document.forms[0].summSrchPaymentType.value = paymentType;	
	document.forms[0].method.value = 'PaySummMedicaidDetails';
	//document.forms[0].subMenu.value = 'SubmenuPaymentSummary';
	document.forms[0].submit();	
}

function toggleVisibilityDisc(ctl, id, usrSelect, pbp, year, qtr) {
	var elem = document.getElementById(id);	
	toggleVisibilityElement(ctl, elem, usrSelect, pbp, year, qtr);
}
function toggleVisibilityElement(ctl, elem, usrSelect, pbp, year, qtr) {
	//alert("usrSelect"+usrSelect+elem+elem.style.display);
	if(elem.style.display == "") {
		elem.style.display = 'none';
		elem.setAttribute("rowExpanded", "false");
		ctl.src = '/mss/jsp/MCRecon/images/Plus.png';		
	} 
	if(elem.style.display == 'none') {
		//alert("usrSelect"+usrSelect+elem);
		elem.style.display = "";
		elem.setAttribute("rowExpanded", "true");
		ctl.src = '/mss/jsp/MCRecon/images/Minus.png';
		
		if(usrSelect=="PBP"){
			dwrDiscDsbPBPSelect(pbp);
		}
		else if(usrSelect == 'YEAR'){
			dwrDiscDsbYEARSelect(pbp, year);
		}
		else if(usrSelect == 'QUART'){
			dwrDiscDsbQUARTSelect(pbp, year, qtr);			
		}
		
	}//else
}

function dwrDiscDsbPBPSelect(pbp) {
	FacadeManager.getMcaidDiscDashboardByPBP(pbp, {
		callback:function(data) {
			dwrDiscDsbPBPSelectData(pbp, data);
		}
	});
}//PayDsbPBPSelect()

function dwrDiscDsbPBPSelectData(pbp, data) {
	var list = data;
	var css ;	
	var content = "<TABLE border='0' align='center' cellpadding='0' cellspacing='0' style='border-collapse:collapse'>"		
		for(var i=0 ; i < list.length ; i++) {
			var currVO = list[i];
			css = i%2 == 0 ? "oddRow" : "evenRow";
		
				var tempContent= "<tr align='center' valign='middle'>"		
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				
				+ "<td class='"+css+"' width='30pt' align='center' valign='middle' class='head2'>"
				+ "		<img src='/mss/jsp/MCRecon/images/Plus.png' width='12' height='12' style='cursor:pointer;'	"
				+ " 	onclick=toggleVisibilityDisc(this,'tr"+pbp+currVO.year+"','YEAR','"+pbp+"','"+currVO.year+"',null); >" 
				+ "</td>"
				
				+ "<td class='"+css+"' width='380pt' align='left'  valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+currVO.year+"','','','total'); href='#' class='plan' >"+currVO.year+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+currVO.year+"','','','total'); href='#' class='plan' >"+currVO.count+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+currVO.year+"','','','open'); href='#' class='plan' >"+currVO.open+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+currVO.year+"','','','inProg'); href='#' class='plan' >"+currVO.inProgress+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+currVO.year+"','','','forcls'); href='#' class='plan' >"+currVO.forceClosed+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+currVO.year+"','','','resolv'); href='#' class='plan' >"+currVO.resolved+"</a></td>"
				+ "</tr>"
				
				+ "<tr id='tr"+pbp+currVO.year+"' style='display:none;'>"
				+ "		<td colspan='8'><div id='div"+pbp+currVO.year+"'></div></td>"
				+ "</tr>";
				
			content = content+tempContent;
		}//for
	content = content +"</TABLE>";
	document.getElementById('div'+pbp).innerHTML = content ;		
}//dwrPayDsbPBPSelectData()

//=====================================================================================

function dwrDiscDsbYEARSelect(pbp, year) {
	//alert(year);
	FacadeManager.getMcaidDiscDashboardByYear(pbp, year, {
		callback:function(data) {
			dwrDiscDsbYEARSelectData(pbp, year, data);
		}
	});
}//dwrPayDsbYEARSelect()


function dwrDiscDsbYEARSelectData(pbp, year,  data) {	
	var list = data;
	var css ;	
	var content = "<TABLE border='0' align='center' cellpadding='0' cellspacing='0' style='border-collapse:collapse'>"
		
		for(var i=0 ; i < list.length ; i++) {
			var currVO = list[i];
			css = i%2 == 0 ? "oddRow" : "evenRow";
		
				var tempContent= "<tr align='center' valign='middle'>"		
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				
				+ "<td class='"+css+"' width='30pt' align='center' valign='middle' class='head2'>"
				+ "		<img src='/mss/jsp/MCRecon/images/Plus.png' width='12' height='12' style='cursor:pointer;'	"
				+ " 	onclick=toggleVisibilityDisc(this,'tr"+pbp+year+currVO.quarter+"','QUART','"+pbp+"','"+year+"','"+currVO.quarter+"'); >" 
				+ "</td>"
				
				+ "<td class='"+css+"' width='360pt' align='left'  valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+year+"','"+currVO.quarter+"','','total'); href='#' class='plan' >&nbsp;"+currVO.quarter+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+year+"','"+currVO.quarter+"','','total'); href='#' class='plan' >"+currVO.count+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+year+"','"+currVO.quarter+"','','open'); href='#' class='plan' >"+currVO.open+"</a></td>"		
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+year+"','"+currVO.quarter+"','','inProg'); href='#' class='plan' >"+currVO.inProgress+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+year+"','"+currVO.quarter+"','','forcls'); href='#' class='plan' >"+currVO.forceClosed+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+year+"','"+currVO.quarter+"','','resolv'); href='#' class='plan' >"+currVO.resolved+"</a></td>"
				+ "</tr>"
				
				+ "<tr id='tr"+pbp+year+currVO.quarter+"' style='display:none;'>"
				+ "		<td colspan='9'><div id='div"+pbp+year+currVO.quarter+"'></div></td>"
				+ "</tr>";
				
			content = content+tempContent;
		}//for
	content = content +"</TABLE>";	
	document.getElementById('div'+pbp+year).innerHTML = content ;	
}//dwrPayDsbYEARSelectData()

//=====================================================================================

function dwrDiscDsbQUARTSelect(pbp, year, qtr) {	
	//alert(qtr);
	FacadeManager.getMcaidDiscDashboardByQuarter(pbp, year, qtr, {
		callback:function(data) {
			dwrDiscDsbQUARTSelectData(pbp, year, qtr, data);
		}
	});
}//dwrPayDsbQUARTSelect()


function dwrDiscDsbQUARTSelectData(pbp, year, qtr, data) {	
	var list = data;
	//alert(" data=="+data+" "+data.length);
	var css ;	
	var content = "<TABLE border='0' align='center' cellpadding='0' cellspacing='0' style='border-collapse:collapse'>"
		
		for(var i=0 ; i < list.length ; i++) {
			var currVO = list[i];
			css = i%2 == 0 ? "oddRow" : "evenRow";
		
				var tempContent= "<tr align='center' valign='middle'>"		
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				
				+ "<td class='"+css+"' width='350pt' align='left'  valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+year+"','"+qtr+"','"+currVO.month+"','total'); href='#' class='plan' >&nbsp;"+getMonthName(currVO.month)+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+year+"','"+qtr+"','"+currVO.month+"','total'); href='#' class='plan' >"+currVO.count+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+year+"','"+qtr+"','"+currVO.month+"','open'); href='#' class='plan' >"+currVO.open+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+year+"','"+qtr+"','"+currVO.month+"','inProg'); href='#' class='plan' >"+currVO.inProgress+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+year+"','"+qtr+"','"+currVO.month+"','forcls'); href='#' class='plan' >"+currVO.forceClosed+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+year+"','"+qtr+"','"+currVO.month+"','resolv'); href='#' class='plan' >"+currVO.resolved+"</a></td>"
				+ "</tr>"
								
			content = content+tempContent;
		}//for
	content = content +"</TABLE>";	
	document.getElementById('div'+pbp+year+qtr).innerHTML = content ;		
}//dwrPayDsbQUARTSelectData()


function discSummaryData(pbp, year, qtr, month, status) {
	//alert("Hi: "+pbp +" : "+year+" : "+qtr+":: month:"+month);
	document.forms[0].summSrchPbp.value = pbp;	
	document.forms[0].summSrchYear.value = year;
	document.forms[0].summSrchQtr.value = qtr;
	document.forms[0].summSrchMonth.value = month;
	document.forms[0].summSrchStatus.value = status;
	
	document.forms[0].method.value = 'discSummList';
	document.forms[0].subMenu.value = 'SubmenuDiscSummary';
	document.forms[0].submit();	
}
function discSummListRowClick(rowSelect) {		
	document.forms[0].summSrchListRowSelect.value = rowSelect;	
	document.forms[0].method.value = 'discSummDetails';
	//document.forms[0].subMenu.value = 'SubmenuAnomSummary';
	document.forms[0].submit();	
}
function summDiscStatusUpdate() {
	document.forms[0].method.value = 'discSummStatusUpdate';
	document.forms[0].submit();	
}



function toggleVisibilityChk(ctl,id,effdt,mcaidId){
	//alert("test:::"+mcaidId);
	var elem = document.getElementById(id);	

	toggleVisibilityElementChk(ctl, elem, effdt,mcaidId);
}
function toggleVisibilityElementChk(ctl, elem, effdate,medicaidId) {
	//alert(effdate);
	if(elem.style.display == "") {
		elem.style.display = 'none';
		elem.setAttribute("rowExpanded", "false");
		ctl.src = '/mss/jsp/MCRecon/images/Plus.png';		
	} else {
		//alert("ok");
		elem.style.display = "";
		elem.setAttribute("rowExpanded", "true");
		ctl.src = '/mss/jsp/MCRecon/images/Minus.png';
		//alert("ssss");
			dwrEffDateSelect(effdate,medicaidId);			
		
		
	}//else
}

function dwrEffDateSelect(effdate1,mcaidId) {
	
	FacadeManager.getMcaidPaymentDetailsByEffDt(effdate1,mcaidId, {
		callback:function(data) {
			dwrPymtDetailsEffDateSelectData1(effdate1, data);
		}
	});
}//PayDsbPBPSelect()

function dwrPymtDetailsEffDateSelectData1(effdate, data) {
	//alert(data.length);
	var list = data;
	var css ;	
	var content = "<TABLE border='0' align='center' cellpadding='0' cellspacing='0' style='border-collapse:collapse'>"		
		for(var i=0 ; i < list.length ; i++) {
			var currVO = list[i];
			//alert(currVO.applyDate);
			css = i%2 == 0 ? "oddRow" : "evenRow";
		
			var tempContent= "<tr align='center' valign='middle'>"		
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='130pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				
				
				
				+ "<td class='"+css+"' width='130pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='460pt' align='left'  valign='middle' class='head2'>&nbsp;"+currVO.applyDate+"</td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' align='right' valign='middle' class='head2'>"+currVO.adjCode+"</td>"
				+ "<td class='"+css+"' width='130pt' class='head2'></td>"
				+ "<td class='"+css+"' width='130pt' class='head2'></td>"
				+ "<td class='"+css+"' width='200pt' align='right' valign='middle' class='head2'>"+currVO.adjDesc+"</td>"
				+ "<td class='"+css+"' width='130pt' class='head2'></td>"
				+ "<td class='"+css+"' width='130pt' align='right' valign='middle' class='head2'>"+currVO.cmsPaid+"</td>"
				+ "<td class='"+css+"' width='130pt' class='head2'></td>"
				+ "<td class='"+css+"' width='130pt' align='right' valign='middle' class='head2'>"+currVO.planExpected+"</td>"
				+ "<td class='"+css+"' width='130pt' class='head2'></td>"
				+ "<td class='"+css+"' width='130pt' align='right' valign='middle' class='head2'>"+isNeagtiveAmount(currVO.diffrence)+"</td>"
				+ "</tr>"
				
			
				
			content = content+tempContent;
		}//for
	content = content +"</TABLE>";
	document.getElementById('div'+effdate).innerHTML = content ;	
}

/* View Reconciliation - Start*/
	
function viewDiscReconciliation(menuName, isCallFromDetail) {

		var subMenu = dwr.util.getValue("subMenu");
		var method = 'viewReconciliation';
		url = "/mcaidReconDiscAction.do?method=" + method +'&subMenu='+subMenu;
		var ww = 900;
		var wh = 550;
		var wt = 1;
		var wl = ((screen.width - 10) - ww) / 2;
		eemZipWin = window.open(url,method,"toolbar=no,titlebar=0,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,ControlBox=no,width=" + ww + ",height=" + wh + ",left=" + wl + ",top=" + wt);
		eemZipWin.focus(); 
		
	}
function viewAnomReconciliation(menuName, isCallFromDetail) {
	var subMenu = dwr.util.getValue("subMenu");
	var method = 'viewReconciliation';
	url = "/mcaidReconAnomAction.do?method=" + method +'&subMenu='+subMenu;
	var ww = 900;
	var wh = 550;
	var wt = 1;
	var wl = ((screen.width - 10) - ww) / 2;
	eemZipWin = window.open(url,method,"toolbar=no,titlebar=0,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,ControlBox=no,width=" + ww + ",height=" + wh + ",left=" + wl + ",top=" + wt);
	eemZipWin.focus(); 
	
}
/* View Reconciliation - End*/

function viewPayment(effDate){
	//alert("test"+effDate);
	var subMenu = dwr.util.getValue("subMenu");
	var pbp = dwr.util.getValue("summSrchPbp");
	
	var method = 'viewPaymentDetails';
	
	url = "/mcaidReconDiscAction.do?method=" + method +'&subMenu='+subMenu+'&pbpId='+pbp+'&effDate='+effDate;
	var ww = 900;
	var wh = 550;
	var wt = 1;
	var wl = ((screen.width - 10) - ww) / 2;
	
	eemZipWin = window.open(url,method,"toolbar=no,titlebar=0,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,ControlBox=no,width=" + ww + ",height=" + wh + ",left=" + wl + ",top=" + wt);
	eemZipWin.focus();
}

function viewPaymentDetailsForAnom(effDate){
	//alert("test");
	var subMenu = dwr.util.getValue("subMenu");
	var pbp = dwr.util.getValue("summSrchPbp");
	
	var method = 'viewPaymentDetails';
	
	url = "/mcaidReconAnomAction.do?method=" + method +'&subMenu='+subMenu+'&pbpId='+pbp+'&effDate='+effDate;
	var ww = 900;
	var wh = 550;
	var wt = 1;
	var wl = ((screen.width - 10) - ww) / 2;
	
	eemZipWin = window.open(url,method,"toolbar=no,titlebar=0,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,ControlBox=no,width=" + ww + ",height=" + wh + ",left=" + wl + ",top=" + wt);
	eemZipWin.focus();
}
function countLength(elmName){
	var elem = document.getElementById(elmName);
	content = elem.value;
	if(content.length >= 150){
		alert("Comment should be 150 characters only");
		content = content.substring(0, 150);
		document.getElementById(elmName).value = content;
	}
}
function paymentSearch() {
		document.body.className = 'wait';
		document.forms[0].subMenu.value = "SubmenuPaymentSummary";
		document.forms[0].method.value = 'paymentSearch';
		document.forms[0].submit();	
	}
function summGoSearch() {
	document.forms[0].method.value = 'summGoOpt';
	document.forms[0].submit();	
}



function summAnomGoSearch() {
	document.forms[0].method.value = 'summGoOpt';
	document.forms[0].submit();	
}
