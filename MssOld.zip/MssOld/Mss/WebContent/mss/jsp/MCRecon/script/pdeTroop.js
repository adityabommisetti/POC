// troopDashboard.js
isOpen = top.isOpen;
/*
Author : deepak
Discription : callBack function of getTroopDashBoard .
*/
function CBgetTroopDashBoard(data,searchType,planId ,yearId) {
	if(searchType =='year') 
		PopulateTroopYears(data,planId);
	 else if (searchType == 'month' ) 
		populateTroopMonth(data,planId ,yearId);
	
	resetBodyHeight();
}

/*
Author : deepak
Discription : This method is used to populate year on dashboard.
*/
function PopulateTroopYears(data,planId) {
	var id = planId ;
	if( data == null || data.length == 0 ) {
		showPopMessage(MSG_NO_DATA_FOUND);
		return false;
	}
	
	var html ='<table width="100%"  border="0" cellspacing="0" cellpadding="0">';
	var planVo = {rollupId:null,cmsPaidPartC:null,planExpectedPartC:null,
				  diffrencePartC:null,cmsPaidPartD:null,planExpectedPartD:null,
				  diffrencePartD:null};
	var troopDashBoardVOList = data.troopDashBoardVOs;
	for(var i=0; i< troopDashBoardVOList.length;i++) {
		var color = true ;
		if(i%2 == 1) {
			color = false;
		}
		planVo = troopDashBoardVOList[i];
		html += createTroopYearRow(id,planVo,color);
	} 
	html +='</table>';
	var e = document.getElementById(id);
	e.innerHTML=html;
	e.setAttribute("isBodyExists", "true");
	e.setAttribute("rowExpanded", "true");
}

/*
Author : deepak
Discription : This method is used to populate month on dashboard.
*/
function populateTroopMonth(data,planId ,yearId) {
	var id = planId ;
	var year = yearId;
	if( data ==null || data.length == 0 ) {
		showPopMessage(MSG_NO_DATA_FOUND);
		var e = document.getElementById(planId +yearId);
		e.innerHTML='<table><tr><td ></td></tr></table>';
		return;
	}
	var html ='<table width="100%"  border="0" cellspacing="0" cellpadding="0">';
	var planVo = {rollupId:null,cmsPaidPartC:null,planExpectedPartC:null,
				  diffrencePartC:null,cmsPaidPartD:null,planExpectedPartD:null,
				  diffrencePartD:null};
	var troopDashBoardVOList = data.troopDashBoardVOs;
	for(var i=0; i<troopDashBoardVOList.length ;i++ ) {
		var color = true ;
		if(i%2 == 1) {
			color = false;
		}
		planVo = troopDashBoardVOList[i];
		html += createTroopMonthRow(id,year ,planVo , color);
	} 
	html +='</table>';
	var e = document.getElementById(id +'_'+year );
	e.innerHTML=html;
	e.setAttribute("isBodyExists", "true");
	e.setAttribute("rowExpanded", "true");
}

/*
Author : deepak
Discription : This method is used to generate on year row on dashboard.
*/
function createTroopYearRow(id,planVo,color) {
	var html ='';
	var tdTag ='<td width="18%" align="right" valign="middle">';
	var redTdTag ='<td width="18%" align="right" valign="middle" class="red" >';
	var startPlan ='<tr class="evenrow">'
	if(color)  
		startPlan ='<tr class="oddrow">';
	startPlan += '<td width="5%" align="right"><img src="/mss/jsp/Recon/images/Plus.png" width="12" height="12" onclick = "useLoadingImage(this);toggleVisibilitydownByYear(this,\'troopDashBoard\',\''+id+'\',\''+planVo.rollupId+'\');" style="cursor:pointer;">&nbsp;&nbsp;</td><td>';
	html +=startPlan;
	html += '<a href="#" class="plan" onclick="submitTroopDashBoardAction(\'troopDetail\',\'year\',\''+id+'\',\''+planVo.rollupId+'\');">' +planVo.rollupId +'</a></td>';
//populate data rows.
	html += createRow(tdTag , redTdTag , planVo.totalTroop);
	//html += tdTag +planVo.balanceTransferred+ '&nbsp;&nbsp;</td>';
	html += createRow(tdTag , redTdTag , planVo.patientPayAmt);
	html += createRow(tdTag , redTdTag , planVo.otherTroopAmt );
	html +=createRow(tdTag , redTdTag , planVo.LICSAmount);
 	html +='</tr>';
	html+='<tr><td colspan="6"><div id="'+ id +'_'+ planVo.rollupId +'" style="display:none"></div></td></tr>';
	return html;
}
function createRow(tdTag , redTdTag , value) {
	var retValue = '';
	if(value != null && value.charAt(0) == '(' ) {
		retValue = redTdTag + value + '&nbsp;</td>';
	} else {
		retValue = tdTag + value + '&nbsp;&nbsp;</td>';
	} 
	return retValue;
}
/*
Author : deepak
Discription : This method is used to generate on month row on dashboard.
*/
function createTroopMonthRow(id,year,planVo,color) {
	var html ='';
	var tdTag ='<td width="18%" align="right" valign="middle">';
	var redTdTag ='<td width="18%" align="right" valign="middle" class="red" > ';
	var startPlan ='<tr class="evenrow"><td width="7%" align="center" ></td>';
	if(color) 
		startPlan ='<tr class="oddrow"><td width="7%" align="center"></td>';
	html +=startPlan;
	html += '<td align="left"><a href="#" class="plan" onclick="submitTroopDashBoardAction(\'troopDetail\',\'month\',\''+id+'\',\''+year+'\',\''+getMonthValue(planVo.rollupId)+'\');">' +planVo.rollupId +'</a></td>';
	//populate data
	html += createRow(tdTag , redTdTag , planVo.totalTroop );
//	html += tdTag +planVo.balanceTransferred+ '&nbsp;&nbsp;</td>';
	html += createRow(tdTag , redTdTag , planVo.patientPayAmt);
	html += createRow(tdTag , redTdTag , planVo.otherTroopAmt);
	html += createRow(tdTag , redTdTag , planVo.LICSAmount );
	html +='</tr>';
	return html;
}

/**
 	This function is use to populate troop Detail list.
*/
function CBgetTroopDetail(data ) {
	troopDetailVOList = data ;
	var divHtml="<table width='100%'  border='1' cellpadding='0' cellspacing='0' bordercolor='#999999' style='border-collapse:collapse;word-break:break-all'>";
	if( troopDetailVOList == null ) {
		showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
		var nextPageImg = document.getElementById("nextPageImg");
		nextPageImg.onclick = function(){
				showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
			};

		return;
	} else {
		preiousSelectedRow = troopDetailVOList.selectedLine;
		var troopDetailVO = null;
		var currentPage = "" ;
		var pageNumber = 1 ;
		//var totalTroop = troopDetailVOList.troopTotal;
		//dwr.util.setValue('troopTotal', totalTroop);
		currentPage = troopDetailVOList.currentPage;
		pageNumber = troopDetailVOList.pageNumber;
		troopDetailVO = troopDetailVOList.troopDetailVO;
		divHtml+='<tr style="display:none" colspan="10"> <td id="selectRow">'+preiousSelectedRow +'</td></tr>'
		if(troopDetailVO ==null || troopDetailVO.length==0){
			// means there is not more data, show appropriate message on screen.
			showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
			var nextPageImg = document.getElementById("nextPageImg");
			nextPageImg.onclick = function(){
					showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
				};
			return;
		} else {
			var j = 0 ;	
			for(var i = 0;i < troopDetailVO.length ; i++ ){
				tempdiscListVO = troopDetailVO[i];
				var classCss = "class = ''";
				if( i == preiousSelectedRow ) {
				  classCss = "class='selectedRow'";
				} else if ( i % 2 == 0) {
				  classCss = "class='oddRow'";
				} else {
				  classCss = "class='evenRow'";
				}
				divHtml+='<tr style="display:none" colspan="10"> <td id="selectRow">'+preiousSelectedRow +'</td></tr>'
				
				divHtml+="<tr height='20' "+ classCss +" id='"+i +"' style='cursor:pointer' onclick=\"useLoadingImage(this);javascript:getPdeDetail('"+tempdiscListVO.seqNbr+"', '"+i+"','troop\')\">";
				divHtml+='<td '+ classCss +' align="center" width="9%" id="pymtEffDate_'+i+'">'+ tempdiscListVO.pymtEffDate+"</td>";
				divHtml+='<td '+ classCss +' align="center" width="8%" id="pymtApplyDate_'+i+'">'+ tempdiscListVO.pymtApplyDate+"</td>";
				divHtml+='<td '+ classCss +' align="center" width="10%" id="hicNbr_'+i+'">'+ tempdiscListVO.hicNbr+"</td>";
//				divHtml+='<td '+ classCss +' align="center" width="8%" id="seqNbr_'+i+'">'+ tempdiscListVO.seqNbr+"</td>";
				if (tempdiscListVO.totalTroop != null && tempdiscListVO.totalTroop.charAt(0) == '(' && classCss != "class='selectedRow'")
					divHtml+='<td class ="red" align="right" width="12%" id="totalTroop_'+i+'">'+ tempdiscListVO.totalTroop+"&nbsp;</td>";
				else if(tempdiscListVO.totalTroop != null && tempdiscListVO.totalTroop.charAt(0) == '(')
					divHtml+='<td '+ classCss +' align="right" width="12%" id="totalTroop_'+i+'">'+ tempdiscListVO.totalTroop+"&nbsp;</td>";
				else
					divHtml+='<td '+ classCss +' align="right" width="12%" id="totalTroop_'+i+'">'+ tempdiscListVO.totalTroop+"&nbsp;&nbsp;</td>";
				divHtml+='<td '+ classCss +' align="center" width="5%" id="adjReasonCd_'+i+'">'+ tempdiscListVO.adjReasonCd+"</td>";
				divHtml+='<td '+ classCss +' align="center" width="20%" id="adjDesc_'+i+'">'+ tempdiscListVO.adjDesc+"</td>";
				//divHtml+='<td '+ classCss +' align="right" width="11%" id="balanceTransferred_'+i+'">'+ tempdiscListVO.balanceTransferred+"&nbsp;&nbsp;</td>";
				
				if (tempdiscListVO.patientPayAmt != null && tempdiscListVO.patientPayAmt.charAt(0) == '(' && classCss != "class='selectedRow'")
					divHtml+='<td class ="red" align="right" width="12%" id="patientPayAmt_'+i+'">'+ tempdiscListVO.patientPayAmt+"&nbsp;</td>";
				else if (tempdiscListVO.patientPayAmt != null && tempdiscListVO.patientPayAmt.charAt(0) == '(')
					divHtml+='<td '+ classCss +' align="right" width="12%" id="patientPayAmt_'+i+'">'+ tempdiscListVO.patientPayAmt+"&nbsp;</td>";
				else 
					divHtml+='<td '+ classCss +' align="right" width="12%" id="patientPayAmt_'+i+'">'+ tempdiscListVO.patientPayAmt+"&nbsp;&nbsp;</td>";
			
				if (tempdiscListVO.otherTroopAmt != null && tempdiscListVO.otherTroopAmt.charAt(0) == '(' && classCss != "class='selectedRow'")
					divHtml+='<td class ="red" align="right" width="12%" id="otherTroopAmt_'+i+'">'+ tempdiscListVO.otherTroopAmt+"&nbsp;</td>";
				else if (tempdiscListVO.otherTroopAmt != null && tempdiscListVO.otherTroopAmt.charAt(0) == '(' )
					divHtml+='<td '+ classCss +' align="right" width="12%" id="otherTroopAmt_'+i+'">'+ tempdiscListVO.otherTroopAmt+"&nbsp;</td>";
				else
					divHtml+='<td '+ classCss +' align="right" width="12%" id="otherTroopAmt_'+i+'">'+ tempdiscListVO.otherTroopAmt+"&nbsp;&nbsp;</td>";
			
				if (tempdiscListVO.LICSAmount != null && tempdiscListVO.LICSAmount.charAt(0) == '(' && classCss != "class='selectedRow'")
					divHtml+='<td class ="red" align="right" width="12%" id="LICSAmount_'+i+'">'+ tempdiscListVO.LICSAmount+"&nbsp;</td>";
				else if(tempdiscListVO.LICSAmount != null && tempdiscListVO.LICSAmount.charAt(0) == '(')
					divHtml+='<td '+ classCss +' align="right" width="12%" id="LICSAmount_'+i+'">'+ tempdiscListVO.LICSAmount+"&nbsp;</td>";
				else
					divHtml+='<td '+ classCss +' align="right" width="12%" id="LICSAmount_'+i+'">'+ tempdiscListVO.LICSAmount+"&nbsp;&nbsp;</td>";
			
				//divHtml+='<td '+ classCss +' align="right" width="12%" id="patientPayAmt_'+i+'">'+ tempdiscListVO.patientPayAmt+"&nbsp;&nbsp;</td>";
				//divHtml+='<td '+ classCss +' align="right" width="12%" id="otherTroopAmt_'+i+'">'+ tempdiscListVO.otherTroopAmt+"&nbsp;&nbsp;</td>";
				//divHtml+='<td '+ classCss +' align="right" width="12%" id="LICSAmount_'+i+'">'+ tempdiscListVO.LICSAmount+"&nbsp;&nbsp;</td>";
				divHtml+="</tr>";
			}
			divHtml+="<tr>";
			divHtml+="<td colspan='11' align='right' class='pageRow'>";
			divHtml+="<table width='50%' height='20'  border='0' align'right' cellpadding='0' cellspacing='0'><tr>";
			divHtml+="<td align='right'>Page# : <span id='pgNumber'>"+pageNumber+ "</span>&nbsp;&nbsp;</td>";
			if( pageNumber == 1) {
				divHtml += '<td width="25px" align="center" ><img  title="First Page" src="/mss/jsp/Recon/images/Arrow_Page1.jpg" width="16" height="16"></td>';
				divHtml += '<td width="25px" align="center"><img  title="Previous Page" src="/mss/jsp/Recon/images/Arrow_PageP.jpg" width="16" height="16" ></td>';
			} else {
				divHtml += '<td width="25px" align="center" ><img  title="First Page" src="/mss/jsp/Recon/images/Arrow_Page1.jpg" width="16" height="16" onclick="useLoadingImage(this);pagination(\'first\',\'troop\');" style="cursor:pointer"></td>';
				divHtml += '<td width="25px" align="center"><img  title="Previous Page" src="/mss/jsp/Recon/images/Arrow_PageP.jpg" width="16" height="16" onclick="useLoadingImage(this);pagination(\'previous\',\'troop\');" style="cursor:pointer"></td>';
			}
			if( currentPage == 'last') {
				divHtml += '<td width="25px" align="center"><img id="nextPageImg" title="Next Page" src="/mss/jsp/Recon/images/Arrow_PageN.jpg" width="16" height="16" ></td>';
			} else {
				divHtml += '<td width="25px" align="center"><img id="nextPageImg" title="Next Page" src="/mss/jsp/Recon/images/Arrow_PageN.jpg" width="16" height="16" onclick="useLoadingImage(this);pagination(\'next\',\'troop\');" style="cursor:pointer"></td>';
			}
			divHtml+='<td width="6px">&nbsp;</td></tr></table></td>';
			divHtml+="</tr>";

			// udpating pdedetail Data
			CBgetPdeDetail(troopDetailVOList.pdeDetailVO);
		}
		divHtml+="</table>";
	}
	var id = "troopDetail";
	document.getElementById(id).innerHTML = divHtml;
	resetBodyHeight();
}	

/*
Author : Rakesh
Discription : Call back handler method for "getPdeDashBoard" Ajax Call
*/
function CBgetPdeDashBoard(data, searchType, pdeId ,yearId) {
	if(searchType == 'year') {
		populatePdeYears(data, pdeId);
	} else if (searchType == 'month' ) {
		populatePdeMonths(data, pdeId, yearId);
	} else {
		populatePdePlans(data);
	}
	resetBodyHeight();
}

/*
Author : Rakesh
Discription : This method is used to generate on month row on dashboard.
*/
function populatePdeMonths(data, pdeId, yearId){
	if( data ==null || data.length == 0 ) {
		showPopMessage(MSG_NO_DATA_FOUND);
		return;
	}
	
	var html ='<table width="100%" border="0" cellspacing="0" cellpadding="0">';
	var pdeVo = {rollupId:null, rollupName:null, acccepted:null, overridden:null, rejected:null, resubmitted:null, total:null, eventAccepted:null, eventRejected:null, totalEvent:null};
	
	for(var i=0; i<data.length ;i++ ) {
		var color = false ;
		if(i%2 == 1) {
			color = true;
		}
		pdeVo = data[i];
		html += createPdeMonthRow(pdeId, yearId, pdeVo, color);
	} 
	html +='</table>';
	var e = document.getElementById(pdeId + '_' + yearId );
	e.innerHTML=html;
	e.setAttribute("isBodyExists", "true");
	e.setAttribute("rowExpanded", "true");
}

/*
Author : Rakesh
Discription : This method is used to creating month row for PDE dashboard.
*/
function createPdeMonthRow(pdeId, yearId, pdeVo, color) {
	var html ='';
	var startPlan ='<tr class="evenrow"><td width="6%" align="center" ></td>';
	if(color)  
		startPlan ='<tr class="oddrow"><td width="6%" align="center"></td>';
	html += startPlan;
	html += '<td align="left">&nbsp;'+pdeVo.rollupId + '</td>';

	html += '<td width="11%" align="right" valign="middle">';
	if (pdeVo.eventAccepted != '')
		html += '<a href="#" class="plan" onclick=" submitPdeDashBoardAction(\'pdeEventDetail\',\'month\',\''+pdeId+'\',\''+yearId+'\',\''+getMonthValue(pdeVo.rollupId)+'\', \'ACC\',true);">' + pdeVo.eventAccepted + '</a>&nbsp;';
	html += '&nbsp;</td>';

	html += '<td width="11%" align="right" valign="middle">';
	if (pdeVo.eventRejected != '')
		html += '<a href="#" class="plan" onclick=" submitPdeDashBoardAction(\'pdeEventDetail\',\'month\',\''+pdeId+'\',\''+yearId+'\',\''+getMonthValue(pdeVo.rollupId)+'\', \'REJ\',true);">' + pdeVo.eventRejected + '</a>&nbsp;';
	html += '&nbsp;</td>';
	
	html += '<td width="12%" align="right" valign="middle">';
	if (pdeVo.eventTotal != '')
		html += '<a href="#" class="plan" onclick=" submitPdeDashBoardAction(\'pdeEventDetail\',\'month\',\''+pdeId+'\',\''+yearId+'\',\''+getMonthValue(pdeVo.rollupId)+'\', \'EVT\',true);">' + pdeVo.eventTotal + '</a>&nbsp;';
	html += '&nbsp;</td>';

	html += '<td width="11%" align="right" valign="middle">';
	if (pdeVo.overridden != '')
		html += '<a href="#" class="plan" onclick=" submitPdeDashBoardAction(\'pdeEventDetail\',\'month\',\''+pdeId+'\',\''+yearId+'\',\''+getMonthValue(pdeVo.rollupId)+'\', \'OVR\',false);">' + pdeVo.overridden + '</a>&nbsp;';
	html += '&nbsp;</td>';

	html += '<td width="11%" align="right" valign="middle">';
	if (pdeVo.resubmitted != '')
		html += '<a href="#" class="plan" onclick=" submitPdeDashBoardAction(\'pdeEventDetail\',\'month\',\''+pdeId+'\',\''+yearId+'\',\''+getMonthValue(pdeVo.rollupId)+'\', \'RES\',false);">' + pdeVo.resubmitted + '</a>&nbsp;';
	html += '&nbsp;</td>';
	
	html += '<td width="14%" align="right" valign="middle">';
	if (pdeVo.total != '')
		html += '<a href="#" class="plan" onclick=" submitPdeDashBoardAction(\'pdeEventDetail\',\'month\',\''+pdeId+'\',\''+yearId+'\',\''+getMonthValue(pdeVo.rollupId)+'\', \'ALL\',false);">' + pdeVo.total + '</a>&nbsp;';
	html += '&nbsp;</td>';

	html +='</tr>';
	return html;
}

/*
Author : Rakesh
Discription : This method is used to generate on Year row on PDE dashboard.
*/
function populatePdeYears(data, pdeId) {
	if( data == null || data.length == 0 ) {
		showPopMessage(MSG_NO_DATA_FOUND);
		return false;
	}
	
	var html ='<table width="100%"  border="0" cellspacing="0" cellpadding="0">';
	var pdeVo = {rollupId:null, rollupName:null, acccepted:null, overridden:null, rejected:null, resubmitted:null, total:null, eventAccepted:null, eventRejected:null, totalEvent:null};
	for(var i=0; i< data.length;i++) {
		var color = false ;
		if(i%2 == 1) {
			color = true;
		}
		pdeVo = data[i];
		html += createPdeYearRow(pdeId, pdeVo, color);
	} 
	html +='</table>';
	var e = document.getElementById(pdeId);
	e.innerHTML=html;
	e.setAttribute("isBodyExists", "true");
	e.setAttribute("rowExpanded", "true");
}


/*
Author : Rakesh
Discription : This method is used to creating year row for PDE dashboard.
*/
function createPdeYearRow(pdeId, pdeVo, color) {
	var html ='';
	var startPlan ='<tr class="evenrow">'
	if(color) {
		startPlan ='<tr class="oddrow">';
	}
	startPlan += '<td width="4%" align="right"><img src="/mss/jsp/Recon/images/Plus.png" width="12" height="12" onclick="useLoadingImage(this); toggleVisibilitydownByYear(this,\'pdeDashBoard\',\''+pdeId+'\',\''+pdeVo.rollupId+'\');" style="cursor:pointer;">&nbsp;</td><td>';
	html +=startPlan;
	html += '&nbsp;' +pdeVo.rollupId +'</td>';
	
	html += '<td width="11%" align="right" valign="middle">';
	if (pdeVo.eventAccepted != '')
		html += '<a href="#" class="plan" onclick="submitPdeDashBoardAction(\'pdeEventDetail\',\'year\',\''+pdeId+'\',\''+pdeVo.rollupId+'\', \'\', \'ACC\',true);">' + pdeVo.eventAccepted + '&nbsp;';
	html += '&nbsp;</td>';
	
	html += '<td width="11%" align="right" valign="middle">';
	if (pdeVo.eventRejected != '')
		html += '<a href="#" class="plan" onclick="submitPdeDashBoardAction(\'pdeEventDetail\',\'year\',\''+pdeId+'\',\''+pdeVo.rollupId+'\', \'\', \'REJ\',true);">' + pdeVo.eventRejected + '&nbsp;';
	html += '&nbsp;</td>';

	html += '<td width="12%" align="right" valign="middle">';
	if (pdeVo.eventTotal != '')
		html += '<a href="#" class="plan" onclick="submitPdeDashBoardAction(\'pdeEventDetail\',\'year\',\''+pdeId+'\',\''+pdeVo.rollupId+'\', \'\', \'EVT\',true);">' + pdeVo.eventTotal + '&nbsp;';
	html += '&nbsp;</td>';

	html += '<td width="11%" align="right" valign="middle">';
	if (pdeVo.overridden != '')
		html += '<a href="#" class="plan" onclick="submitPdeDashBoardAction(\'pdeEventDetail\',\'year\',\''+pdeId+'\',\''+pdeVo.rollupId+'\', \'\', \'OVR\',false);">' + pdeVo.overridden + '&nbsp;';
	html += '&nbsp;</td>';
	
	html += '<td width="11%" align="right" valign="middle">';
	if (pdeVo.resubmitted != '')
		html += '<a href="#" class="plan" onclick="submitPdeDashBoardAction(\'pdeEventDetail\',\'year\',\''+pdeId+'\',\''+pdeVo.rollupId+'\', \'\', \'RES\',false);">' + pdeVo.resubmitted + '&nbsp;';
	html += '&nbsp;</td>';

	html += '<td width="14%" align="right" valign="middle">';
	if (pdeVo.total != '')
		html += '<a href="#" class="plan" onclick="submitPdeDashBoardAction(\'pdeEventDetail\',\'year\',\''+pdeId+'\',\''+pdeVo.rollupId+'\', \'\', \'ALL\',false);">' + pdeVo.total + '&nbsp;';
	html += '&nbsp;</td>';

	
	html +='</tr>';
	html+='<tr><td colspan="8"><div id="'+ pdeId +'_'+ pdeVo.rollupId +'" style="display:none"></div></td></tr>';
	return html;
}


/*
Author : rakesh
Discription : This method is used to submit pde DeshBoard.
*/
function submitPdeDashBoardAction(actionType, search, planName, year, month, pdeStatus,eventSearch) {
 	month = getMonthValue(month);
	var formRef = document.forms ['PdeTroopForm'];
//	var methodName = document.getElementById("methodName").value;
	var methodName = dwr.util.getValue("methodName");
	searchType = search ;
	globalFilterVO = filterVO;
	var fromDate = dwr.util.getValue(START_DATE);
	var toDate = dwr.util.getValue(END_DATE);
	
	if(searchType == 'year' ) { // for year search
		if(isContain(fromDate, year) && fromDate.length == 7){
//			var dateArr = fromDate.split("/");
//			fromDate = dateArr[0] + "/01/" + dateArr[1];
		} else {
//			fromDate = '01/01/'+year;
			fromDate = '01/'+year;
		}
		
		if(isContain(toDate, year) && toDate.length == 7){
//			var dateArr = toDate.split("/");
//			toDate = dateArr[0] + "/" + dateArr[1];
		} else 
			toDate = '12/' +year;
			
	} else if (searchType =='month' ) { // for month search
		fromDate = month +'/' +year;
//		var lastDayOfMonth = daysInMonth(month, year); // getting last day of the month
		toDate =  month +'/'+year;
	} else { // for plan based search
		if(fromDate && fromDate.length == 7){
//			var dateArr = fromDate.split("/");
//			fromDate = dateArr[0] + "/" + dateArr[1];
		}
		
		if(toDate && toDate.length == 7){
//			var dateArr = toDate.split("/");
//			toDate = dateArr[0] + "/" + dateArr[1];
		}
	}
	
	
	if(actionType == 'searchPlan') 
		planName = dwr.util.getValue(PLAN_SEARCH);

	formRef.actionType.value = "search";
	formRef.method.value = actionType;
	dwr.util.setValue(PLAN_SEARCH, planName);
	formRef.pdeStatus.value = pdeStatus;
	formRef.planName.value = planName;	
	formRef.fromDate.value = fromDate;
	formRef.toDate.value = toDate;
	formRef.searchType.value = searchType;
	tempMenu = dwr.util.getValue("menuName");
	saveUiContext(formRef,methodName,tempMenu, '');
}

//This method is used to move between subTab(example between paymentDashboard,discrepancyDashboard)
function submitPdeLink(methodName) {
	var formRef = document.forms ['PdeTroopForm'];
	tempMenu = dwr.util.getValue("menuName");
	var pageName = dwr.util.getValue("methodName");
	formRef.method.value = methodName;
	formRef.actionType.value = null;
	saveUiContext(formRef, pageName, tempMenu, '');
}

/*
Author : Rakesh
Discription : This method is used to save ui context into session.
*/
function submitPdeAction(action) {
	if( validateForm(false) == false)
		return false;
	var formRef = document.forms ["PdeTroopForm"];
	var methodName = dwr.util.getValue("methodName");
	var menuName = formRef.menuName.value;
	formRef.method.value = methodName;
	formRef.actionType.value = action;
	saveUiContext(formRef, methodName, menuName, '');
}


/**
Author : Rakesh
Discription : This function is use to populate Pde Event Detail list.
*/

function CBgetPdeEventDetailList(data, move, menuName) {
	pdeEventDetailVOList = data ;
	var divHtml="<table width='100%'  border='1' cellpadding='0' cellspacing='0' bordercolor='#999999' style='border-collapse:collapse;word-break:break-all'>";

	if( pdeEventDetailVOList == null ) {
		showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
		var nextPageImg = document.getElementById("nextPageImg");
		nextPageImg.onclick = function(){
				showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
			};
		
		return;
//		divHtml += "<tr><td colspan='11'>&nbsp;"+MSG_NO_DATA_FOUND+"</td></tr></table>";
	} else {
		preiousSelectedRow = pdeEventDetailVOList.selectedLine;
		var pdeDetailVO = null;
		var currentPage = "";
		var pageNumber = 1;
		currentPage = pdeEventDetailVOList.currentPage;
		pageNumber = pdeEventDetailVOList.pageNumber;
		pdeEventDetailVOs = pdeEventDetailVOList.pdeEventDetailVOs;
		divHtml+='<tr style="display:none" colspan="10"> <td id="selectRow">'+preiousSelectedRow +'</td></tr>'
		var selectedRowPdeSeqNum = -1;

		if(pdeEventDetailVOs ==null || pdeEventDetailVOs.length==0){
			// means there is not more data, show appropriate message on screen.
			showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
			var nextPageImg = document.getElementById("nextPageImg");
			nextPageImg.onclick = function(){
				showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
			};
			
			return;
		} else {
			var j = 0 ;	
			
			for(var i = 0;i < pdeEventDetailVOs.length ; i++ ){
				tempPdeEventListVO = pdeEventDetailVOs[i];
				var classCss = "class = ''";
				if( i == preiousSelectedRow ) {
				  classCss = "class='selectedRow'";
				  selectedRowPdeSeqNum = tempPdeEventListVO.pdeSeqNumber;
				} else if ( i % 2 == 0) {
				  classCss = "class='oddRow'";
				} else {
				  classCss = "class='evenRow'";
				}
				divHtml+='<tr style="display:none" colspan="10"> <td id="selectRow">'+preiousSelectedRow +'</td></tr>'
				
				divHtml+="<tr height='20' "+ classCss +" id='"+i +"' style='cursor:pointer' onclick=\"useLoadingImage(this);javascript:getPdeDetail(\'"+tempPdeEventListVO.pdeSeqNumber+"', '"+ i +"',\'"+menuName+"\')\">";
				divHtml+='<td '+ classCss +' width="14%" align="center" width="8%" id="pdeSeqNumber_'+i+'">'+ tempPdeEventListVO.hicNumber+"</td>";
//				divHtml+='<td '+ classCss +' width="18%" align="center" width="8%" id="pdeSeqNumber_'+i+'">'+ tempPdeEventListVO.pdeSeqNumber+"</td>";
				divHtml+='<td '+ classCss +' width="14%" align="center" width="7%" id="serviceDate_'+i+'">'+ tempPdeEventListVO.showServiceDate+"</td>";
				divHtml+='<td '+ classCss +' width="11%" align="center" width="9%" id="detRecId_'+i+'">'+ tempPdeEventListVO.detRecId+"</td>";
				divHtml+='<td '+ classCss +' width="20%" align="center" width="8%" id="referenceNumber_'+i+'">'+ tempPdeEventListVO.referenceNumber+"</td>";
				divHtml+='<td '+ classCss +' width="16%" align="center" width="10%" id="productSvcId_'+i+'">'+ tempPdeEventListVO.productSvcId+"&nbsp;&nbsp;</td>";
				divHtml+='<td '+ classCss +' width="22%" align="center" width="4%" id="lastUpdtTime_'+i+'">'+ tempPdeEventListVO.showLastUpdtDate+"</td>";
				
				divHtml+="</tr>";
			}
			divHtml+="<tr>";
			divHtml+="<td colspan='11' align='right' class='pageRow'>";
			divHtml+="<table width='50%' height='20'  border='0' align='right' cellpadding='0' cellspacing='0'><tr>";
			divHtml+="<td align='right'>Page# : <SPAN id='pgNumber'>"+pageNumber+ "</SPAN>&nbsp;&nbsp;</td>";
				
			if( pageNumber == 1) {
				divHtml += '<td width="25px" align="center" ><img title="First Page" src="/mss/jsp/Recon/images/Arrow_Page1.jpg" width="16" height="16"></td>';
				divHtml += '<td width="25px" align="center"><img title="Previous Page" src="/mss/jsp/Recon/images/Arrow_PageP.jpg" width="16" height="16" ></td>';
			} else {
				divHtml += '<td width="25px" align="center" ><img title="First Page" src="/mss/jsp/Recon/images/Arrow_Page1.jpg" width="16" height="16" onclick="useLoadingImage(this);pagination(\'first\',\'' + menuName + '\');" style="cursor:pointer"></td>';
				divHtml += '<td width="25px" align="center"><img title="Previous Page" src="/mss/jsp/Recon/images/Arrow_PageP.jpg" width="16" height="16" onclick="useLoadingImage(this);pagination(\'previous\',\'' + menuName + '\');" style="cursor:pointer"></td>';
			}
			if( currentPage == 'last') {
				divHtml += '<td width="25px" align="center"><img id="nextPageImg" title="Next Page" src="/mss/jsp/Recon/images/Arrow_PageN.jpg" width="16" height="16" ></td>';
			} else {
				divHtml += '<td width="25px" align="center"><img id="nextPageImg" title="Next Page" src="/mss/jsp/Recon/images/Arrow_PageN.jpg" width="16" height="16" onclick="useLoadingImage(this);pagination(\'next\',\'' + menuName + '\');" style="cursor:pointer"></td>';
			}
			divHtml+='<td width="65px">&nbsp;</td></tr></table></td>';
			divHtml+="</tr>";
			
			// udpating pdedetail Data
			CBgetPdeDetail(pdeEventDetailVOList.pdeDetailVO);
		}
		divHtml+="</table>";
	}
	var id = "pdeEventDetailDiv";
	document.getElementById(id).innerHTML = divHtml;

	resetBodyHeight();
}
	
/**
	This function is used get pde detail VO
*/
function getPdeDetail(pdeSeqNum,rowId ,menuName) {
	try {
		preiousSelectedRow = dwr.util.getValue('selectRow');
		// applying appropiate style class based on condition
		var prevSeleRow = document.getElementById(preiousSelectedRow);
		var className = "oddRow";
		var bgColor = "oddRowRed";
		if(preiousSelectedRow % 2 =='1'  ) {
			bgColor = "evenRowRed";
			className = "evenRow";
		}
		
		applyClassOnTdTag(className, preiousSelectedRow);
		dwr.util.setValue('selectRow', rowId); 
		applyClassOnTdTag("selectedRow", rowId); //applye selected row style class.
		
		//Code apply red class in case of amount is nagetive when switching between line on troopDetail page.
		if( menuName == 'troop' ) {
			if (dwr.util.getValue('totalTroop_'+preiousSelectedRow).charAt(0) == '(') {
				document.getElementById('totalTroop_'+preiousSelectedRow).className = bgColor;
			}
			if (dwr.util.getValue('patientPayAmt_'+preiousSelectedRow).charAt(0) == '(') {
				document.getElementById('patientPayAmt_'+preiousSelectedRow).className = bgColor;
			}
			if (dwr.util.getValue('otherTroopAmt_'+preiousSelectedRow).charAt(0) == '(') {
				document.getElementById('otherTroopAmt_'+preiousSelectedRow).className = bgColor;
			}
			if (dwr.util.getValue('LICSAmount_'+preiousSelectedRow).charAt(0) == '(') {
				document.getElementById('LICSAmount_'+preiousSelectedRow).className = bgColor;
			}
		}	
		
		FacadeManager.getPdeDetail(pdeSeqNum, rowId, menuName ,{
								  			callback:function(data) {
								   			CBgetPdeDetail(data);}
								  			});
		
	} catch(e) {
		showPopMessage("Error: "+e.message);
	}
}

/*
Author: Rakesh
Input : PdeDetailVO
Discreption : 
*/

function CBgetPdeDetail(pdeDetailVO) {
	if(pdeDetailVO == null){
		showPopMessage("PDE Detail is Null");
		return;
	}

	dwr.util.setValue("pdeCustName", pdeDetailVO.custName);
	dwr.util.setValue("pdePlanId",pdeDetailVO.rollupId);
	dwr.util.setValue("pdeHicNumber",pdeDetailVO.hicNumber);
	dwr.util.setValue("pdeFName",pdeDetailVO.firstName);
	dwr.util.setValue("pdeLName",pdeDetailVO.lastName);
	dwr.util.setValue("pdeRecSuppId",pdeDetailVO.mostRecentSuppId);
	dwr.util.setValue("pdeSupplIdOnEffDate",pdeDetailVO.supplementalId);
	dwr.util.setValue("pdeBirthDate",pdeDetailVO.birthDate);
	dwr.util.setValue("pdeGender",pdeDetailVO.genderCd);
	dwr.util.setValue("pdePbpId",pdeDetailVO.bhbPbpId);
	dwr.util.setValue("pdeLastUpdateDate",pdeDetailVO.lastUpdtDate);
	dwr.util.setValue("pdeUserId",pdeDetailVO.lastUpdtUserID);
	dwr.util.setValue("pdeProcessStatus",pdeDetailVO.processStatus);
	dwr.util.setValue("pdeCorrectHicNum",pdeDetailVO.correctedHicNumber);
	dwr.util.setValue("pdeErrorCount",pdeDetailVO.errorCnt);
	dwr.util.setValue("pdeSeqNumber",pdeDetailVO.pdeSeqNumber);
	dwr.util.setValue("pdeSerivceDate",pdeDetailVO.serviceDate);
	dwr.util.setValue("pdeSvcProviderQual",pdeDetailVO.svcProviderQual);
	dwr.util.setValue("pdeSvcProviderId",pdeDetailVO.svcProviderId);
	dwr.util.setValue("pdeReferenceNum",pdeDetailVO.referenceNumber);
	dwr.util.setValue("pdeFillNum",pdeDetailVO.fillNumber);
	dwr.util.setValue("pdeCardHolderId",pdeDetailVO.cardHolderId);
	dwr.util.setValue("pdePaidDate",pdeDetailVO.paidDate);
	dwr.util.setValue("pdeProductSvcId",pdeDetailVO.productSvcId);
	dwr.util.setValue("pdeCompoundCode",pdeDetailVO.compoundCd);
	dwr.util.setValue("pdeDawProductSelCd",pdeDetailVO.dawProductSelCd);
	dwr.util.setValue("pdeDispenseQty",pdeDetailVO.dispenseQty);
	dwr.util.setValue("pdeSupplyDays",pdeDetailVO.supplyDays);
	dwr.util.setValue("pdePreScrIdQual",pdeDetailVO.preScrIdQual);
	dwr.util.setValue("pdePrescrId",pdeDetailVO.prescrId);
	dwr.util.setValue("pdeDrugCvrgStatus",pdeDetailVO.drugcvrgStatus);
	dwr.util.setValue("pdeAdjdelInd",pdeDetailVO.adjdelInd);
	dwr.util.setValue("pdeNonStdFormatCd",pdeDetailVO.nonStdFormatCd);
	dwr.util.setValue("pdeOnnCd",pdeDetailVO.oonCd);
	dwr.util.setValue("pdeCatatrophicInd",pdeDetailVO.catatrosphicInd);

	dwr.util.setValue("pdeBrandGenericCd",pdeDetailVO.brandGenericCd);
	dwr.util.setValue("pdeTierCd",pdeDetailVO.tierCd);
	dwr.util.setValue("pdeFormularyCd",pdeDetailVO.formularyCd);
	dwr.util.setValue("pdePrescrOriginCd",pdeDetailVO.prescrOriginCd);
	dwr.util.setValue("pdeGapDiscOvrCd",pdeDetailVO.gapDiscOvrCd);
	dwr.util.setValue("pdeBeginBenefitPhase",pdeDetailVO.beginBenefitPhase);
	dwr.util.setValue("pdeEndBenefitPhase",pdeDetailVO.endBenefitPhase);
	dwr.util.setValue("pdeClaimAdjudStartTime",pdeDetailVO.claimAdjudStartTime);
	dwr.util.setValue("pdeOrigClaimRecvDate",pdeDetailVO.origClaimRecvDate);
						
	if (pdeDetailVO.ingrcostPaid.charAt(0) == '(') {
		dwr.util.setValue("pdeIngrCostPaid",pdeDetailVO.ingrcostPaid);
		document.getElementById('pdeIngrCostPaid').className = 'red';
	} else {
		document.getElementById("pdeIngrCostPaid").innerHTML = pdeDetailVO.ingrcostPaid+'&nbsp;';
		document.getElementById('pdeIngrCostPaid').className = 'xxx';
	}
		
	
	if (pdeDetailVO.dispenfeePaid.charAt(0) == '(') {
		dwr.util.setValue("pdeDispenFeePaid",pdeDetailVO.dispenfeePaid);
		document.getElementById('pdeDispenFeePaid').className = 'red';
	} else {
		document.getElementById("pdeDispenFeePaid").innerHTML = pdeDetailVO.dispenfeePaid+'&nbsp;';
		document.getElementById('pdeDispenFeePaid').className = 'xxx';
	}

	if (pdeDetailVO.salesTaxAmt.charAt(0) == '('){
		dwr.util.setValue("pdeSalesTaxAmt",pdeDetailVO.salesTaxAmt);
		document.getElementById('pdeSalesTaxAmt').className = 'red';
	} else {
		document.getElementById("pdeSalesTaxAmt").innerHTML = pdeDetailVO.salesTaxAmt+'&nbsp;';
		document.getElementById('pdeSalesTaxAmt').className = 'xxx';
	}

	if (pdeDetailVO.vaccAdminFee.charAt(0) == '(') {
		dwr.util.setValue("pdeVaccAdminFee",pdeDetailVO.vaccAdminFee);
		document.getElementById('pdeVaccAdminFee').className = 'red';
	} else {
		document.getElementById("pdeVaccAdminFee").innerHTML = pdeDetailVO.vaccAdminFee+'&nbsp;';
		document.getElementById('pdeVaccAdminFee').className = 'xxx';	
	}
		
	
	
	if (pdeDetailVO.gdcbAmt.charAt(0) == '(') {
		dwr.util.setValue("pdeGdcbAmt",pdeDetailVO.gdcbAmt);
		document.getElementById('pdeGdcbAmt').className = 'red';
	} else {
		document.getElementById("pdeGdcbAmt").innerHTML = pdeDetailVO.gdcbAmt+'&nbsp;';
		document.getElementById('pdeGdcbAmt').className = 'xxx';
	}

	if (pdeDetailVO.gdcaAmt.charAt(0) == '(') {
		dwr.util.setValue("pdeGdcaAmt",pdeDetailVO.gdcaAmt);
		document.getElementById('pdeGdcaAmt').className = 'red';
	} else {
		document.getElementById("pdeGdcaAmt").innerHTML = pdeDetailVO.gdcaAmt+'&nbsp;';
		document.getElementById('pdeGdcaAmt').className = 'xxx';
	}
	

	if (pdeDetailVO.patientPayAmt.charAt(0) == '(') {
		dwr.util.setValue("pdePatientPayAmt",pdeDetailVO.patientPayAmt);
		document.getElementById('pdePatientPayAmt').className = 'red';
	} else {
		document.getElementById("pdePatientPayAmt").innerHTML = pdeDetailVO.patientPayAmt+'&nbsp;';
		document.getElementById('pdePatientPayAmt').className = 'xxx';
	}
	

	if (pdeDetailVO.otherTroopAmt.charAt(0) == '(') {
		dwr.util.setValue("pdeOtherTroopAmt",pdeDetailVO.otherTroopAmt);
		document.getElementById('pdeOtherTroopAmt').className = 'red';
	} else {
		document.getElementById("pdeOtherTroopAmt").innerHTML = pdeDetailVO.otherTroopAmt+'&nbsp;';
		document.getElementById('pdeOtherTroopAmt').className = 'xxx';
	}
	

	if (pdeDetailVO.licsAmt.charAt(0) == '(') {
		dwr.util.setValue("pdeLicsAmt",pdeDetailVO.licsAmt);
		document.getElementById('pdeLicsAmt').className = 'red';
	} else {
		document.getElementById("pdeLicsAmt").innerHTML = pdeDetailVO.licsAmt+'&nbsp;';
		document.getElementById('pdeLicsAmt').className = 'xxx';
	}
	

	if (pdeDetailVO.plroAmt.charAt(0) == '(') {
		dwr.util.setValue("pdePlroAmt",pdeDetailVO.plroAmt);
		document.getElementById('pdePlroAmt').className = 'red';
	} else {
		document.getElementById("pdePlroAmt").innerHTML = pdeDetailVO.plroAmt+'&nbsp;';	
		document.getElementById('pdePlroAmt').className = 'xxx';
	}
	

	if (pdeDetailVO.cppAmt.charAt(0) == '(') {
		dwr.util.setValue("pdeCppAmt",pdeDetailVO.cppAmt);
		document.getElementById('pdeCppAmt').className = 'red';
	} else {
		document.getElementById("pdeCppAmt").innerHTML = pdeDetailVO.cppAmt+'&nbsp;';	
		document.getElementById('pdeCppAmt').className = 'xxx';
	}
	

	if (pdeDetailVO.nppAmt.charAt(0) == '(') {
		dwr.util.setValue("pdeNppAmt",pdeDetailVO.nppAmt);
		document.getElementById('pdeNppAmt').className = 'red';
	} else {
		document.getElementById("pdeNppAmt").innerHTML = pdeDetailVO.nppAmt+'&nbsp;';	
		document.getElementById('pdeNppAmt').className = 'xxx';
	}

	if (pdeDetailVO.nppAmt.charAt(0) == '(') {
		dwr.util.setValue("pdeEstRebateAmt",pdeDetailVO.estRebateAmt);
		document.getElementById('pdeEstRebateAmt').className = 'red';
	} else {
		document.getElementById("pdeEstRebateAmt").innerHTML = pdeDetailVO.nppAmt+'&nbsp;';	
		document.getElementById('pdeEstRebateAmt').className = 'xxx';
	}
	
	if (pdeDetailVO.nppAmt.charAt(0) == '(') {
		dwr.util.setValue("pdeRptGapDiscAmt",pdeDetailVO.nppAmt);
		document.getElementById('pdeNppAmt').className = 'red';
	} else {
		document.getElementById("pdeRptGapDiscAmt").innerHTML = pdeDetailVO.rptGapDiscAmt+'&nbsp;';	
		document.getElementById('pdeRptGapDiscAmt').className = 'xxx';
	}

	if (pdeDetailVO.nppAmt.charAt(0) == '(') {
		dwr.util.setValue("pdeCmsGapDiscAmt",pdeDetailVO.nppAmt);
		document.getElementById('pdeCmsGapDiscAmt').className = 'red';
	} else {
		document.getElementById("pdeCmsGapDiscAmt").innerHTML = pdeDetailVO.cmsGapDiscAmt+'&nbsp;';	
		document.getElementById('pdeCmsGapDiscAmt').className = 'xxx';
	}


	dwr.util.setValue("pdeDispensingStatus",pdeDetailVO.dispensingStatus);
	
	var errCount = parseInt(pdeDetailVO.errorCnt, 10);
	var errorDiv = "";
	if(errCount > 0 ){
		var showErrorMsg = pdeDetailVO.showErrorMsg;
		for(var i=0; i<showErrorMsg.length && i<10; i++) {
			errorDiv += showErrorMsg[i] + "<br/>";
		}
	}
	document.getElementById("pdeErrorShow").innerHTML = errorDiv;
}