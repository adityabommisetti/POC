/* author: prare
 * created date: 12/11/2015
 *
 */
function switchMenu(val) {
  document.forms[0].method.value = 'switchMenu';
  document.forms[0].menu.value = val;
  //alert("val"+val)
  document.body.style.cursor = 'wait';
 // document.body.className = 'wait';
 // alert("document.body.className "+document.body.className)
  document.forms[0].submit();
}

function switchSubMenu(valSubMenu) {
	//alert(valSubMenu);
	document.body.style.cursor = 'wait';
	//document.body.className = 'wait';
	document.forms[0].subMenu.value = valSubMenu;
	//alert("before submit");
	document.forms[0].submit();
}



function paySummData(pbp, year, qtr, month) {
	//alert("Hi: "+pbp +" : "+year+" : "+qtr+":: month:"+month);
	document.forms[0].summSrchPbp.value = pbp;
	document.forms[0].summSrchYear.value = year;
	document.forms[0].summSrchQtr.value = qtr;
	document.forms[0].summSrchMonth.value = month;

	document.forms[0].method.value = 'paySummData';
	document.forms[0].subMenu.value = 'SubmenuPaymentSummary';
	document.body.style.cursor = 'wait';
	//document.body.className = 'wait';
	document.forms[0].submit();
}


function getPaySummMedicaidDetails(paymentType) {

	document.forms[0].summSrchPaymentType.value = paymentType;
	document.forms[0].method.value = 'PaySummMedicaidDetails';
	//document.forms[0].subMenu.value = 'SubmenuPaymentSummary';
	document.body.style.cursor = 'wait';
	//document.body.className = 'wait';
	document.forms[0].submit();
}

/*Payment Summary-Medicaid list Pagination -START*/

function paySumMedicaidSearchPageFirst(){
	document.body.style.cursor = 'wait';
	document.forms[0].method.value = 'paySumMedicaidSearchPageFirst';
	document.forms[0].submit();
}

function paySumMedicaidSearchPageNext(){
	document.body.style.cursor = 'wait';
	document.forms[0].method.value = 'paySumMedicaidSearchPageNext';
	document.forms[0].submit();
}

function paySumMedicaidSearchPagePrev(){
	document.body.style.cursor = 'wait';
	document.forms[0].method.value = 'paySumMedicaidSearchPagePrev';
	document.forms[0].submit();
}
/*Payment Summary-Medicaid list Pagination - END*/
// Added for Extract All Records Changes : start
function extractAllRecords(){
	document.body.style.cursor = 'wait';
	document.forms[0].method.value = 'extractAllRecords';
	document.forms[0].submit();
}
// Added for Extract All Records Changes : end
/*Files Inventory-Medicaid list Pagination -START*/

function filesLstPageFirst(){
	document.body.style.cursor = 'wait';
	document.forms[0].method.value = 'filesLstPageFirst';
	document.forms[0].submit();
}

function filesLstPageNext(){
	document.body.style.cursor = 'wait';
	document.forms[0].method.value = 'filesLstPageNext';
	document.forms[0].submit();
}

function filesLstPagePrev(){
	document.body.style.cursor = 'wait';
	document.forms[0].method.value = 'filesLstPagePrev';
	document.forms[0].submit();
}
/*Files Inventory-Medicaid list Pagination - END*/

function isNeagtiveAmount( val ){
	if(val != null || val != ""){
	if(val.charAt(0) == '('){
		val = "<div style='color:red;'>"+ val +"</div>";
	}else{
		val = "<div>"+ val +"</div>";
	}
	}
	return val;
}


function isNeagtiveAmount( val,cmsPaid,plan){

	if(val != null && val != ""){


			var val1 = val;

			val = "<div>"+ val1 +"</div>";
	 		var tmpcmsPaid = cmsPaid;
			var tmpplanExpected = plan;
			var cmsPaid = cmsPaid;
			var plan = plan;

		if(cmsPaid != null && cmsPaid != "" &&  plan != null && plan != "" ){
			if(tmpcmsPaid.indexOf("(") != -1)
				tmpcmsPaid = tmpcmsPaid.replace(/\(/g, "");

			if(tmpcmsPaid.indexOf(")") != -1)
				tmpcmsPaid = tmpcmsPaid.replace(/\)/g, "");

			if(tmpplanExpected.indexOf("(") != -1)
				tmpplanExpected = tmpplanExpected.replace(/\(/g, "");

			if(tmpplanExpected.indexOf(")") != -1)
				tmpplanExpected = tmpplanExpected.replace(/\)/g, "");

			tmpcmsPaid=tmpcmsPaid.replace(/\$/g,"").replace(/,/g,"");
			tmpplanExpected=tmpplanExpected.replace(/\$/g,"").replace(/,/g,"");


			var cms = parseFloat(tmpcmsPaid);
			var planValue = parseFloat(tmpplanExpected);
			if(val1.indexOf("(")==0){
				val = "<div style='color:red;'>"+ val1 +"</div>";
			}else{
				if((cms > planValue)){
					if(cmsPaid.indexOf("(")==0){
						val = "("+val1+")";
						val = "<div style='color:red;'>"+ val +"</div>";
					}
				}

			}
		}



	}
	return val;
}

//IFOX-00408437 / 00408436 / 00408435 --- START

function expandAll(){
	document.body.className = 'wait';
	expandPBPs();
	setTimeout(expandYears,6000);
	setTimeout(expandQuarters,10000);
	document.getElementById("expandButton").onclick = collapseAll;
	document.getElementById("expandButton").value = "Collapse All";
}

function collapseAll(){
	collapsePBPs();
	document.getElementById("expandButton").onclick = expandAll;
	document.getElementById("expandButton").value = "Expand All";
}

function expandPBPs(){
	var pbpList = document.getElementsByClassName("targetPBP");
	for(var i=0; i<pbpList.length; i++){
		if(pbpList[i].getAttribute('src')=="/mss/jsp/MCRecon/images/Plus.png")
			pbpList[i].click();
	}
	return;
}

function collapsePBPs(){
	var pbpList = document.getElementsByClassName("targetPBP");
	for(var i=0; i<pbpList.length; i++){
		if(pbpList[i].getAttribute('src')=="/mss/jsp/MCRecon/images/Minus.png")
			pbpList[i].click();
	}
	return;
}

function expandYears(){
	var yearList = document.getElementsByClassName("targetYear");
	for(var j=0; j<yearList.length; j++){
		yearList[j].click();
	}
	return;
}

function expandQuarters(){
	var quarterList = document.getElementsByClassName("targetQuarter");
	for(var k=0; k<quarterList.length; k++){
		quarterList[k].click();
	}
	return;
}

//IFOX-00408437 / 00408436 / 00408435 --- END

function toggleVisibility(ctl, id, usrSelect, pbp, year, qtr) {
	var elem = document.getElementById(id);
	toggleVisibilityElem(ctl, elem, usrSelect, pbp, year, qtr);
}
function toggleVisibilityElem(ctl, elem, usrSelect, pbp, year, qtr) {
	//alert(" in toggle"+ctl+elem+elem.style.display+usrSelect);
		if(elem.style.display == 'none'){
		elem.style.display = "";
		elem.setAttribute("rowExpanded", "true");
		ctl.src = '/mss/jsp/MCRecon/images/Minus.png';

		if(usrSelect=="PBP"){
			dwrPayDsbPBPSelect(pbp);
		}
		else if(usrSelect == 'YEAR'){
			dwrPayDsbYEARSelect(pbp, year);
		}
		else if(usrSelect == 'QUART'){
			dwrPayDsbQUARTSelect(pbp, year, qtr);
		}

	}
	else if(elem.style.display == "") {
			elem.style.display = 'none';
			elem.setAttribute("rowExpanded", "false");
			ctl.src = '/mss/jsp/MCRecon/images/Plus.png';
	}
}//toggleVisibilityElem()

//===============================================================================================

function dwrPayDsbPBPSelect(pbp) {
	FacadeManager.getMcaidPaymentDashboardByPBP(pbp, {
		callback:function(data) {
			dwrPayDsbPBPSelectData(pbp, data);
		}
	});
}//PayDsbPBPSelect()

function dwrPayDsbPBPSelectData(pbp, data) {

	var list = data;
	var css ;
	var content = "<TABLE border='0' align='center' cellpadding='0' cellspacing='0' style='border-collapse:collapse'>"
		for(var i=0 ; i < list.length ; i++) {
			var currVO = list[i];
			css = i%2 == 0 ? "oddRow" : "evenRow";

				var tempContent= "<tr align='center' valign='middle'>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"

				+ "<td class='"+css+"' width='30pt' align='center' valign='middle' class='head2'>"
				+ "		<img src='/mss/jsp/MCRecon/images/Plus.png' width='12' height='12' style='cursor:pointer;'	class='targetYear'" //change for IFOX-00408437 / 00408436 / 00408435
				+ " 	onclick=toggleVisibility(this,'tr"+pbp+currVO.year+"','YEAR','"+pbp+"','"+currVO.year+"',null); >"
				+ "</td>"

				+ "<td class='"+css+"' width='460pt' align='left'  valign='middle' class='head2'><a onclick=paySummData('"+pbp+"','"+currVO.year+"','',''); href='#' class='plan' >"+currVO.year+"</a></td>"
				+ "<td class='"+css+"' width='130pt' align='right' valign='middle' class='head2'>"+currVO.cmsPaid+"</td>"
				+ "<td class='"+css+"' width='130pt' align='right' valign='middle' class='head2'>"+currVO.planExpected+"</td>"
				+ "<td class='"+css+"' width='130pt' align='right' valign='middle' class='head2'>"+isNeagtiveAmount(currVO.diffrence,currVO.cmsPaid,currVO.planExpected)+"</td>"
				+ "</tr>"

				+ "<tr id='tr"+pbp+currVO.year+"' style='display:none;'>"
				+ "		<td colspan='6'><div id='div"+pbp+currVO.year+"'></div></td>"
				+ "</tr>";

			content = content+tempContent;
		}//for
	content = content +"</TABLE>";
	document.getElementById('div'+pbp).innerHTML = content ;


}//dwrPayDsbPBPSelectData()

//=====================================================================================

function dwrPayDsbYEARSelect(pbp, year) {
	FacadeManager.getMcaidPaymentDashboardByYear(pbp, year, {
		callback:function(data) {
			dwrPayDsbYEARSelectData(pbp, year, data);
		}
	});
}//dwrPayDsbYEARSelect()


function dwrPayDsbYEARSelectData(pbp, year,  data) {
	var list = data;
	var css ;
	var content = "<TABLE border='0' align='center' cellpadding='0' cellspacing='0' style='border-collapse:collapse'>"

		for(var i=0 ; i < list.length ; i++) {
			var currVO = list[i];
			css = i%2 == 0 ? "oddRow" : "evenRow";

				var tempContent= "<tr align='center' valign='middle'>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"

				+ "<td class='"+css+"' width='30pt' align='center' valign='middle' class='head2'>"
				+ "		<img src='/mss/jsp/MCRecon/images/Plus.png' width='12' height='12' style='cursor:pointer;'	class='targetQuarter'" //change for IFOX-00408437 / 00408436 / 00408435
				+ " 	onclick=toggleVisibility(this,'tr"+pbp+year+currVO.quarter+"','QUART','"+pbp+"','"+year+"','"+currVO.quarter+"'); >"
				+ "</td>"

				/*+ "<td class='"+css+"' width='440pt' align='left'  valign='middle' class='head2'>"+currVO.quarter+"</td>"*/
				+ "<td class='"+css+"' width='440pt' align='left'  valign='middle' class='head2'><a onclick=paySummData('"+pbp+"','"+year+"','"+currVO.quarter+"',''); href='#' class='plan' >&nbsp;"+currVO.quarter+"</a></td>"
				+ "<td class='"+css+"' width='130pt' align='right' valign='middle' class='head2'>"+currVO.cmsPaid+"</td>"
				+ "<td class='"+css+"' width='130pt' align='right' valign='middle' class='head2'>"+currVO.planExpected+"</td>"
				+ "<td class='"+css+"' width='130pt' align='right' valign='middle' class='head2'>"+isNeagtiveAmount(currVO.diffrence,currVO.cmsPaid,currVO.planExpected)+"</td>"
				+ "</tr>"

				+ "<tr id='tr"+pbp+year+currVO.quarter+"' style='display:none;'>"
				+ "		<td colspan='7'><div id='div"+pbp+year+currVO.quarter+"'></div></td>"
				+ "</tr>";

			content = content+tempContent;
		}//for
	content = content +"</TABLE>";
	document.getElementById('div'+pbp+year).innerHTML = content ;
}//dwrPayDsbYEARSelectData()

//=====================================================================================

function dwrPayDsbQUARTSelect(pbp, year, qtr) {
	FacadeManager.getMcaidPaymentDashboardByQuarter(pbp, year, qtr, {
		callback:function(data) {
			dwrPayDsbQUARTSelectData(pbp, year, qtr, data);
		}
	});
}//dwrPayDsbQUARTSelect()


function dwrPayDsbQUARTSelectData(pbp, year, qtr, data) {
	var list = data;
	var css ;
	var content = "<TABLE border='0' align='center' cellpadding='0' cellspacing='0' style='border-collapse:collapse'>"

		for(var i=0 ; i < list.length ; i++) {
			var currVO = list[i];
			css = i%2 == 0 ? "oddRow" : "evenRow";

				var tempContent= "<tr align='center' valign='middle'>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"

				/*+ "<td class='"+css+"' width='30pt' align='center' valign='middle' class='head2'>"
				+ "		<img src='/mss/jsp/MCRecon/images/Plus.png' width='12' height='12' style='cursor:pointer;'	"
				+ " 	onclick=toggleVisibility(this,'tr"+pbp+year+currVO.quarter+"','QUART','"+pbp+"','"+year+"','"+currVO.quarter+"'); >"
				+ "</td>"*/

				/*+ "<td class='"+css+"' width='430pt' align='left'  valign='middle' class='head2'>"+currVO.month+"</td>"*/
				+ "<td class='"+css+"' width='430pt' align='left'  valign='middle' class='head2'><a onclick=paySummData('"+pbp+"','"+year+"','"+qtr+"','"+currVO.month+"'); href='#' class='plan' >&nbsp;"+getMonthName(currVO.month)+"</a></td>"
				+ "<td class='"+css+"' width='130pt' align='right' valign='middle' class='head2'>"+currVO.cmsPaid+"</td>"
				+ "<td class='"+css+"' width='130pt' align='right' valign='middle' class='head2'>"+currVO.planExpected+"</td>"
				+ "<td class='"+css+"' width='130pt' align='right' valign='middle' class='head2'>"+isNeagtiveAmount(currVO.diffrence,currVO.cmsPaid,currVO.planExpected)+"</td>"
				+ "</tr>"

				/*+ "<tr id='tr"+pbp+year+currVO.quarter+"' style='display:none;'>"
				+ "		<td colspan='6'><div id='div"+pbp+year+currVO.quarter+"'>Hi div:"+pbp+year+currVO.quarter+"</div></td>"
				+ "</tr>";*/

			content = content+tempContent;
		}//for
	content = content +"</TABLE>";
	document.getElementById('div'+pbp+year+qtr).innerHTML = content ;
}//dwrPayDsbQUARTSelectData()


//=====================================================================================



//**********************ANOMALY**************************************


/* Summary-List Pagination -START*/

function anomSumListSearchPageFirst(){
	document.body.style.cursor = 'wait';
	document.forms[0].method.value = 'anomSummListPageFirst';
	document.forms[0].submit();
}

function anomSumListSearchPageNext(){
	document.body.style.cursor = 'wait';
	document.forms[0].method.value = 'anomSummListPageNext';
	document.forms[0].submit();
}

function anomSumListSearchPagePrev(){
	document.body.style.cursor = 'wait';
	document.forms[0].method.value = 'anomSummListPagePrev';
	document.forms[0].submit();
}
/*Summary-List Pagination - END*/

function anomSummListRowClick(rowSelect) {
	document.forms[0].summSrchListRowSelect.value = rowSelect;
	document.forms[0].method.value = 'anomSummDetails';
	//document.forms[0].subMenu.value = 'SubmenuAnomSummary';
	document.body.style.cursor = 'wait';
	document.forms[0].submit();
}

function summStatusUpdate() {
	document.forms[0].method.value = 'anomSummStatusUpdate';
	document.body.style.cursor = 'wait';
	document.forms[0].submit();
}


function getMonthName(mon) {
	var month = new Array();
	month[0] = "January";
	month[1] = "February";
	month[2] = "March";
	month[3] = "April";
	month[4] = "May";
	month[5] = "June";
	month[6] = "July";
	month[7] = "August";
	month[8] = "September";
	month[9] = "October";
	month[10] = "November";
	month[11] = "December";
	return month[mon-1];
}//getMonthName()





function toggleVisibilityAnom(ctl, id, usrSelect, pbp, year, qtr) {
	var elem = document.getElementById(id);
	toggleVisibilityElemAnom(ctl, elem, usrSelect, pbp, year, qtr);
}

function toggleVisibilityElemAnom(ctl, elem, usrSelect, pbp, year, qtr) {
	if(elem.style.display == "") {
		elem.style.display = 'none';
		elem.setAttribute("rowExpanded", "false");
		ctl.src = '/mss/jsp/MCRecon/images/Plus.png';
	} else {
		elem.style.display = "";
		elem.setAttribute("rowExpanded", "true");
		ctl.src = '/mss/jsp/MCRecon/images/Minus.png';

		if(usrSelect=="PBP"){
			dwrAnomDsbPBPSelect(pbp);
		}
		else if(usrSelect == 'YEAR'){
			dwrAnomDsbYEARSelect(pbp, year);
		}
		else if(usrSelect == 'QUART'){
			dwrAnomDsbQUARTSelect(pbp, year, qtr);
		}

	}//else
}//toggleVisibilityElemAnom()

//=====================================================================================
function dwrAnomDsbPBPSelect(pbp) {
	FacadeManager.getMcaidAnomDashboardByPBP(pbp, {
		callback:function(data) {
			dwrAnomDsbPBPSelectData(pbp, data);
		}
	});
}//dwrAnomDsbPBPSelect()

function dwrAnomDsbPBPSelectData(pbp, data) {
	var list = data;
	var css ;
	var content = "<TABLE border='0' align='center' cellpadding='0' cellspacing='0' style='border-collapse:collapse'>"
		for(var i=0 ; i < list.length ; i++) {
			var currVO = list[i];
			css = i%2 == 0 ? "oddRow" : "evenRow";

				var tempContent= "<tr align='center' valign='middle'>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"

				+ "<td class='"+css+"' width='30pt' align='center' valign='middle' class='head2'>"
				+ "		<img src='/mss/jsp/MCRecon/images/Plus.png' width='12' height='12' style='cursor:pointer;'	"
				+ " 	onclick=toggleVisibilityAnom(this,'tr"+pbp+currVO.year+"','YEAR','"+pbp+"','"+currVO.year+"',null); >"
				+ "</td>"

				+ "<td class='"+css+"' width='380pt' align='left'  valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+currVO.year+"','','','total'); href='#' class='plan' >"+currVO.year+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+currVO.year+"','','','total'); href='#' class='plan' >"+currVO.total+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+currVO.year+"','','','open'); href='#' class='plan' >"+currVO.open+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+currVO.year+"','','','inProg'); href='#' class='plan' >"+currVO.inProgress+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+currVO.year+"','','','forcls'); href='#' class='plan' >"+currVO.forceClose+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+currVO.year+"','','','resolv'); href='#' class='plan' >"+currVO.resolved+"</a></td>"
				+ "</tr>"

				+ "<tr id='tr"+pbp+currVO.year+"' style='display:none;'>"
				+ "		<td colspan='8'><div id='div"+pbp+currVO.year+"'></div></td>"
				+ "</tr>";

			content = content+tempContent;
		}//for
	content = content +"</TABLE>";
	document.getElementById('div'+pbp).innerHTML = content ;
}//dwrAnomDsbPBPSelectData()

//=====================================================================================

function dwrAnomDsbYEARSelect(pbp, year) {
	FacadeManager.getMcaidAnomDashboardByYear(pbp, year, {
		callback:function(data) {
			dwrAnomDsbYEARSelectData(pbp, year, data);
		}
	});
}//dwrAnomDsbYEARSelect()


function dwrAnomDsbYEARSelectData(pbp, year,  data) {
	var list = data;
	var css ;
	var content = "<TABLE border='0' align='center' cellpadding='0' cellspacing='0' style='border-collapse:collapse'>"

		for(var i=0 ; i < list.length ; i++) {
			var currVO = list[i];
			css = i%2 == 0 ? "oddRow" : "evenRow";

				var tempContent= "<tr align='center' valign='middle'>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"

				+ "<td class='"+css+"' width='30pt' align='center' valign='middle' class='head2'>"
				+ "		<img src='/mss/jsp/MCRecon/images/Plus.png' width='12' height='12' style='cursor:pointer;'	"
				+ " 	onclick=toggleVisibilityAnom(this,'tr"+pbp+year+currVO.quarter+"','QUART','"+pbp+"','"+year+"','"+currVO.quarter+"'); >"
				+ "</td>"

				+ "<td class='"+css+"' width='360pt' align='left'  valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+year+"','"+currVO.quarter+"','','total'); href='#' class='plan' >&nbsp;"+currVO.quarter+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+year+"','"+currVO.quarter+"','','total'); href='#' class='plan' >"+currVO.total+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+year+"','"+currVO.quarter+"','','open'); href='#' class='plan' >"+currVO.open+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+year+"','"+currVO.quarter+"','','inProg'); href='#' class='plan' >"+currVO.inProgress+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+year+"','"+currVO.quarter+"','','forcls'); href='#' class='plan' >"+currVO.forceClose+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+year+"','"+currVO.quarter+"','','resolv'); href='#' class='plan' >"+currVO.resolved+"</a></td>"
				+ "</tr>"

				+ "<tr id='tr"+pbp+year+currVO.quarter+"' style='display:none;'>"
				+ "		<td colspan='9'><div id='div"+pbp+year+currVO.quarter+"'></div></td>"
				+ "</tr>";

			content = content+tempContent;
		}//for
	content = content +"</TABLE>";
	document.getElementById('div'+pbp+year).innerHTML = content ;
}//dwrAnomDsbYEARSelectData()

//=====================================================================================

function dwrAnomDsbQUARTSelect(pbp, year, qtr) {
	FacadeManager.getMcaidAnomDashboardByQuarter(pbp, year, qtr, {
		callback:function(data) {
			dwrAnomDsbQUARTSelectData(pbp, year, qtr, data);
		}
	});
}//dwrAnomDsbQUARTSelect()


function dwrAnomDsbQUARTSelectData(pbp, year, qtr, data) {
	var list = data;
	var css ;
	var content = "<TABLE border='0' align='center' cellpadding='0' cellspacing='0' style='border-collapse:collapse'>"

		for(var i=0 ; i < list.length ; i++) {
			var currVO = list[i];
			css = i%2 == 0 ? "oddRow" : "evenRow";

				var tempContent= "<tr align='center' valign='middle'>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"

				+ "<td class='"+css+"' width='350pt' align='left'  valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+year+"','"+qtr+"','"+currVO.month+"','total'); href='#' class='plan' >&nbsp;"+getMonthName(currVO.month)+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+year+"','"+qtr+"','"+currVO.month+"','total'); href='#' class='plan' >"+currVO.total+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+year+"','"+qtr+"','"+currVO.month+"','open'); href='#' class='plan' >"+currVO.open+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+year+"','"+qtr+"','"+currVO.month+"','inProg'); href='#' class='plan' >"+currVO.inProgress+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+year+"','"+qtr+"','"+currVO.month+"','forcls'); href='#' class='plan' >"+currVO.forceClose+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=anomSummData('"+pbp+"','"+year+"','"+qtr+"','"+currVO.month+"','resolv'); href='#' class='plan' >"+currVO.resolved+"</a></td>"
				+ "</tr>"

			content = content+tempContent;
		}//for
	content = content +"</TABLE>";
	document.getElementById('div'+pbp+year+qtr).innerHTML = content ;
}//dwrAnomDsbQUARTSelectData()


//=====================================================================================






//For Discrepancy Dashboard
function discSummData(pbp, year, qtr, month) {
	//alert("Hi: "+pbp +" : "+year+" : "+qtr+":: month:"+month);
	document.forms[0].summSrchPbp.value = pbp;
	document.forms[0].summSrchYear.value = year;
	document.forms[0].summSrchQtr.value = qtr;
	document.forms[0].summSrchMonth.value = month;
	document.forms[0].pbpIdPayment.value =  pbp;

	document.forms[0].method.value = 'paySummData';
	document.forms[0].subMenu.value = 'SubmenuPaymentSummary';
	document.body.style.cursor = 'wait';
	document.forms[0].submit();
}


function getPaySummMedicaidDetails(paymentType) {
	//alert("Hi: "+paymentType );

	document.forms[0].summSrchPaymentType.value = paymentType;
	document.forms[0].method.value = 'PaySummMedicaidDetails';
	//document.forms[0].subMenu.value = 'SubmenuPaymentSummary';
	document.body.style.cursor = 'wait';
	document.forms[0].submit();
}

function toggleVisibilityDisc(ctl, id, usrSelect, pbp, year, qtr) {
	var elem = document.getElementById(id);
	toggleVisibilityElement(ctl, elem, usrSelect, pbp, year, qtr);
}
function toggleVisibilityElement(ctl, elem, usrSelect, pbp, year, qtr) {
	//alert("usrSelect:::"+usrSelect+elem);
	if(elem.style.display == "") {
		elem.style.display = 'none';
		elem.setAttribute("rowExpanded", "false");
		ctl.src = '/mss/jsp/MCRecon/images/Plus.png';
	}
	else if (elem.style.display == 'none') {
		//alert("usrSelect 2 "+usrSelect+elem);
		elem.style.display = "";
		elem.setAttribute("rowExpanded", "true");
		ctl.src = '/mss/jsp/MCRecon/images/Minus.png';

		if(usrSelect=="PBP"){
			dwrDiscDsbPBPSelect(pbp);
		}
		else if(usrSelect == 'YEAR'){
			dwrDiscDsbYEARSelect(pbp, year);
		}
		else if(usrSelect == 'QUART'){
			dwrDiscDsbQUARTSelect(pbp, year, qtr);
		}

	}//else
}

function dwrDiscDsbPBPSelect(pbp) {
	FacadeManager.getMcaidDiscDashboardByPBP(pbp, {
		callback:function(data) {
			dwrDiscDsbPBPSelectData(pbp, data);
		}
	});
}//PayDsbPBPSelect()

function dwrDiscDsbPBPSelectData(pbp, data) {
	var list = data;
	var css ;
	var content = "<TABLE border='0' align='center' cellpadding='0' cellspacing='0' style='border-collapse:collapse'>"
		for(var i=0 ; i < list.length ; i++) {
			var currVO = list[i];
			css = i%2 == 0 ? "oddRow" : "evenRow";

				var tempContent= "<tr align='center' valign='middle'>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"

				+ "<td class='"+css+"' width='30pt' align='center' valign='middle' class='head2'>"
				+ "		<img src='/mss/jsp/MCRecon/images/Plus.png' width='12' height='12' style='cursor:pointer;'	"
				+ " 	onclick=toggleVisibilityDisc(this,'tr"+pbp+currVO.year+"','YEAR','"+pbp+"','"+currVO.year+"',null); >"
				+ "</td>"

				+ "<td class='"+css+"' width='380pt' align='left'  valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+currVO.year+"','','','total'); href='#' class='plan' >"+currVO.year+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+currVO.year+"','','','total'); href='#' class='plan' >"+currVO.count+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+currVO.year+"','','','open'); href='#' class='plan' >"+currVO.open+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+currVO.year+"','','','inProg'); href='#' class='plan' >"+currVO.inProgress+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+currVO.year+"','','','forcls'); href='#' class='plan' >"+currVO.forceClosed+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+currVO.year+"','','','resolv'); href='#' class='plan' >"+currVO.resolved+"</a></td>"
				+ "</tr>"

				+ "<tr id='tr"+pbp+currVO.year+"' style='display:none;'>"
				+ "		<td colspan='8'><div id='div"+pbp+currVO.year+"'></div></td>"
				+ "</tr>";

			content = content+tempContent;
		}//for
	content = content +"</TABLE>";
	document.getElementById('div'+pbp).innerHTML = content ;
}//dwrPayDsbPBPSelectData()

//=====================================================================================

function dwrDiscDsbYEARSelect(pbp, year) {
	//alert(year);
	FacadeManager.getMcaidDiscDashboardByYear(pbp, year, {
		callback:function(data) {
			dwrDiscDsbYEARSelectData(pbp, year, data);
		}
	});
}//dwrPayDsbYEARSelect()


function dwrDiscDsbYEARSelectData(pbp, year,  data) {
	var list = data;
	var css ;
	var content = "<TABLE border='0' align='center' cellpadding='0' cellspacing='0' style='border-collapse:collapse'>"

		for(var i=0 ; i < list.length ; i++) {
			var currVO = list[i];
			css = i%2 == 0 ? "oddRow" : "evenRow";

				var tempContent= "<tr align='center' valign='middle'>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"

				+ "<td class='"+css+"' width='30pt' align='center' valign='middle' class='head2'>"
				+ "		<img src='/mss/jsp/MCRecon/images/Plus.png' width='12' height='12' style='cursor:pointer;'	"
				+ " 	onclick=toggleVisibilityDisc(this,'tr"+pbp+year+currVO.quarter+"','QUART','"+pbp+"','"+year+"','"+currVO.quarter+"'); >"
				+ "</td>"

				+ "<td class='"+css+"' width='360pt' align='left'  valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+year+"','"+currVO.quarter+"','','total'); href='#' class='plan' >&nbsp;"+currVO.quarter+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+year+"','"+currVO.quarter+"','','total'); href='#' class='plan' >"+currVO.count+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+year+"','"+currVO.quarter+"','','open'); href='#' class='plan' >"+currVO.open+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+year+"','"+currVO.quarter+"','','inProg'); href='#' class='plan' >"+currVO.inProgress+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+year+"','"+currVO.quarter+"','','forcls'); href='#' class='plan' >"+currVO.forceClosed+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+year+"','"+currVO.quarter+"','','resolv'); href='#' class='plan' >"+currVO.resolved+"</a></td>"
				+ "</tr>"

				+ "<tr id='tr"+pbp+year+currVO.quarter+"' style='display:none;'>"
				+ "		<td colspan='9'><div id='div"+pbp+year+currVO.quarter+"'></div></td>"
				+ "</tr>";

			content = content+tempContent;
		}//for
	content = content +"</TABLE>";
	document.getElementById('div'+pbp+year).innerHTML = content ;
}//dwrPayDsbYEARSelectData()

//=====================================================================================

function dwrDiscDsbQUARTSelect(pbp, year, qtr) {
	//alert(qtr);
	FacadeManager.getMcaidDiscDashboardByQuarter(pbp, year, qtr, {
		callback:function(data) {
			dwrDiscDsbQUARTSelectData(pbp, year, qtr, data);
		}
	});
}//dwrPayDsbQUARTSelect()


function dwrDiscDsbQUARTSelectData(pbp, year, qtr, data) {
	var list = data;
	//alert(" data=="+data+" "+data.length);
	var css ;
	var content = "<TABLE border='0' align='center' cellpadding='0' cellspacing='0' style='border-collapse:collapse'>"

		for(var i=0 ; i < list.length ; i++) {
			var currVO = list[i];
			css = i%2 == 0 ? "oddRow" : "evenRow";

				var tempContent= "<tr align='center' valign='middle'>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"

				+ "<td class='"+css+"' width='350pt' align='left'  valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+year+"','"+qtr+"','"+currVO.month+"','total'); href='#' class='plan' >&nbsp;"+getMonthName(currVO.month)+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+year+"','"+qtr+"','"+currVO.month+"','total'); href='#' class='plan' >"+currVO.count+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+year+"','"+qtr+"','"+currVO.month+"','open'); href='#' class='plan' >"+currVO.open+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+year+"','"+qtr+"','"+currVO.month+"','inProg'); href='#' class='plan' >"+currVO.inProgress+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+year+"','"+qtr+"','"+currVO.month+"','forcls'); href='#' class='plan' >"+currVO.forceClosed+"</a></td>"
				+ "<td class='"+css+"' width='100pt' align='right' valign='middle' class='head2'><a onclick=discSummaryData('"+pbp+"','"+year+"','"+qtr+"','"+currVO.month+"','resolv'); href='#' class='plan' >"+currVO.resolved+"</a></td>"
				+ "</tr>"

			content = content+tempContent;
		}//for
	content = content +"</TABLE>";
	document.getElementById('div'+pbp+year+qtr).innerHTML = content ;
}//dwrPayDsbQUARTSelectData()


function discSummaryData(pbp, year, qtr, month, status) {
	//alert("Hi: "+pbp +" : "+year+" : "+qtr+":: month:"+month);
	document.forms[0].summSrchPbp.value = pbp;
	document.forms[0].summSrchYear.value = year;
	document.forms[0].summSrchQtr.value = qtr;
	document.forms[0].summSrchMonth.value = month;
	document.forms[0].summSrchStatus.value = status;
	document.forms[0].summSrchGoStatus.value = status;
	//alert(" status =="+status);
	document.forms[0].method.value = 'discSummList';
	document.forms[0].subMenu.value = 'SubmenuDiscDashboardDetail';
	document.body.style.cursor = 'wait';
	document.forms[0].submit();
}


function discSummaryDetailData(discrpCd) {

	//alert("Hi: "+pbp +" : "+year+" : "+qtr+":: month:"+month);
	//alert("PBP--"+document.forms[0].summSrchPbp.value+"  "+"GoPBP--"+document.forms[0].summSrchGoPbp.value);
	//alert("discSummaryDetailData"+discrpCd);
	document.forms[0].summSrchDiscrpCd.value = discrpCd;
	document.forms[0].summSrchPbp.value = document.forms[0].summSrchGoPbp.value;
	//alert(document.forms[0].summSrchDiscrpCd.value);
	//alert(document.forms[0].discrepancyCategory.value);
	document.forms[0].discrepancyCategory.value = discrpCd;
	//alert(document.forms[0].discrepancyCategory.value);
	//alert(document.forms[0].summSrchDiscrpCd.value);
	//alert("PBP--"+document.forms[0].summSrchPbp.value+"  "+"GoPBP--"+document.forms[0].summSrchGoPbp.value);
/*	document.forms[0].summSrchYear.value = year;
	document.forms[0].summSrchQtr.value = qtr;
	document.forms[0].summSrchMonth.value = month;
	document.forms[0].summSrchStatus.value = status;*/
	//document.body.className = 'wait';
	document.body.style.cursor = 'wait';
	document.forms[0].method.value = 'discSummList';
	document.forms[0].subMenu.value = 'SubmenuDiscSummary';
//alert("submit");
	document.forms[0].submit();
}

function anomSummData(pbp, year, qtr, month, status) {
	//alert("Hi: "+pbp +" : "+year+" : "+qtr+":: month:"+month);
	document.forms[0].summSrchPbp.value = pbp;
	document.forms[0].summSrchYear.value = year;
	document.forms[0].summSrchQtr.value = qtr;
	document.forms[0].summSrchMonth.value = month;
	document.forms[0].summSrchStatus.value = status;
	document.body.style.cursor = 'wait';
	//alert(" in AnomSummData");
	document.forms[0].method.value = 'anomSummList';
	document.forms[0].subMenu.value = 'SubmenuAnomDashboardDetail';
	document.forms[0].submit();
}

function anomSummaryDetailData(discrpCd) {

	//alert("Hi: "+pbp +" : "+year+" : "+qtr+":: month:"+month);
	/*document.forms[0].summSrchPbp.value = pbp;
	document.forms[0].summSrchYear.value = year;
	document.forms[0].summSrchQtr.value = qtr;
	document.forms[0].summSrchMonth.value = month;
	document.forms[0].summSrchStatus.value = status;*/
	//document.body.className = 'wait';
	//alert(" in anom summ");
	document.body.style.cursor = 'wait';
	document.forms[0].summSrchAnmlyCd.value = discrpCd;
	document.forms[0].method.value = 'anomSummList';
	document.forms[0].subMenu.value = 'SubmenuAnomSummary';
	document.forms[0].submit();
}

function discSummListRowClick(rowSelect) {
	document.forms[0].summSrchListRowSelect.value = rowSelect;
	document.forms[0].method.value = 'discSummDetails';
	//document.forms[0].subMenu.value = 'SubmenuAnomSummary';
	document.body.style.cursor = 'wait';
	document.forms[0].submit();
}
function summDiscStatusUpdate() {
	document.forms[0].method.value = 'discSummStatusUpdate';
	document.body.style.cursor = 'wait';
	document.forms[0].submit();
}


//Enter Key Fix: start
/*function submitFormWhenEnter() {
    if (event.keyCode == 13) {
    	//Enter Key Adjustment: User can confirm or cancel submittion: Start
    	if(confirm("Press OK to submit! Press Cancel to continue working!")){
    		summDiscStatusUpdate();    		
    		document.forms[0].elements('changeComment').disabled = true;		
    	}else{
    		document.forms[0].elements('changeComment').disabled = true;
    	    document.forms[0].elements('changeComment').disabled = false;
    	}
    	//Enter Key Adjustment: User can confirm or cancel submittion: End
    	//Enter Key Fix: On click displays alert and requires update button to submit: Start  
    	//summDiscStatusUpdate();
    	document.forms[0].elements('changeComment').disabled = true;
    	alert("Please Click Update to Submit!");
    	document.forms[0].elements('changeComment').disabled = false;
    	//Enter Key Fix: On click displays alert and requires update button to submit: End
	}
}*/
//Enter Key Fix: end

function toggleVisibilityChk(ctl,id,effdt,mcaidId){
	//alert("test:::"+mcaidId);
	var elem = document.getElementById(id);

	toggleVisibilityElementChk(ctl, elem, effdt,mcaidId);
}
function toggleVisibilityElementChk(ctl, elem, effdate,medicaidId) {
	//alert(effdate);
	if(elem.style.display == "") {
		elem.style.display = 'none';
		elem.setAttribute("rowExpanded", "false");
		ctl.src = '/mss/jsp/MCRecon/images/Plus.png';
	} else {
		//alert("ok");
		elem.style.display = "";
		elem.setAttribute("rowExpanded", "true");
		ctl.src = '/mss/jsp/MCRecon/images/Minus.png';
		//alert("ssss");
			dwrEffDateSelect(effdate,medicaidId);


	}//else
}

function dwrEffDateSelect(effdate1,mcaidId) {

	FacadeManager.getMcaidPaymentDetailsByEffDt(effdate1,mcaidId, {
		callback:function(data) {
			dwrPymtDetailsEffDateSelectData1(effdate1, data);
		}
	});
}//PayDsbPBPSelect()

function dwrPymtDetailsEffDateSelectData1(effdate, data) {
	//alert(data.length);
	var list = data;
	var css ;
	var content = "<TABLE border='0' align='center' cellpadding='0' cellspacing='0' style='border-collapse:collapse'>"
		for(var i=0 ; i < list.length ; i++) {
			var currVO = list[i];
			//alert(currVO.applyDate);
			css = i%2 == 0 ? "oddRow" : "evenRow";

			var tempContent= "<tr align='center' valign='middle'>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='130pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"



				+ "<td class='"+css+"' width='130pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='460pt' align='left'  valign='middle' class='head2'>&nbsp;"+currVO.applyDate+"</td>"
				+ "<td class='"+css+"' width='20pt' class='head2'></td>"
				+ "<td class='"+css+"' width='20pt' align='right' valign='middle' class='head2'>"+currVO.adjCode+"</td>"
				+ "<td class='"+css+"' width='130pt' class='head2'></td>"
				+ "<td class='"+css+"' width='130pt' class='head2'></td>"
				+ "<td class='"+css+"' width='200pt' align='right' valign='middle' class='head2'>"+currVO.adjDesc+"</td>"
				+ "<td class='"+css+"' width='130pt' class='head2'></td>"
				+ "<td class='"+css+"' width='130pt' align='right' valign='middle' class='head2'>"+currVO.cmsPaid+"</td>"
				+ "<td class='"+css+"' width='130pt' class='head2'></td>"
				+ "<td class='"+css+"' width='130pt' align='right' valign='middle' class='head2'>"+currVO.planExpected+"</td>"
				+ "<td class='"+css+"' width='130pt' class='head2'></td>"
				+ "<td class='"+css+"' width='130pt' align='right' valign='middle' class='head2'>"+isNeagtiveAmount(currVO.diffrence)+"</td>"
				+ "</tr>"



			content = content+tempContent;
		}//for
	content = content +"</TABLE>";
	document.getElementById('div'+effdate).innerHTML = content ;
}

/* View Reconciliation - Start*/

function viewDiscReconciliation(menuName, isCallFromDetail) {

		var subMenu = dwr.util.getValue("subMenu");
		var method = 'viewReconciliation';
		url = "/mcaidReconDiscAction.do?method=" + method +'&subMenu='+subMenu;
		var ww = 900;
		var wh = 550;
		var wt = 1;
		var wl = ((screen.width - 10) - ww) / 2;
		eemZipWin = window.open(url,method,"toolbar=no,titlebar=0,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,ControlBox=no,width=" + ww + ",height=" + wh + ",left=" + wl + ",top=" + wt);
		eemZipWin.focus();

	}
function viewAnomReconciliation(menuName, isCallFromDetail) {
	var subMenu = dwr.util.getValue("subMenu");
	var method = 'viewReconciliation';
	url = "/mcaidReconAnomAction.do?method=" + method +'&subMenu='+subMenu;
	var ww = 900;
	var wh = 550;
	var wt = 1;
	var wl = ((screen.width - 10) - ww) / 2;
	eemZipWin = window.open(url,method,"toolbar=no,titlebar=0,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,ControlBox=no,width=" + ww + ",height=" + wh + ",left=" + wl + ",top=" + wt);
	eemZipWin.focus();

}
/* View Reconciliation - End*/

function viewPayment(effDate){
	//alert("test"+effDate);
	var subMenu = dwr.util.getValue("subMenu");
	var pbp = dwr.util.getValue("summSrchPbp");

	var method = 'viewPaymentDetails';

	url = "/mcaidReconDiscAction.do?method=" + method +'&subMenu='+subMenu+'&pbpId='+pbp+'&effDate='+effDate;
	var ww = 900;
	var wh = 550;
	var wt = 1;
	var wl = ((screen.width - 10) - ww) / 2;

	eemZipWin = window.open(url,method,"toolbar=no,titlebar=0,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,ControlBox=no,width=" + ww + ",height=" + wh + ",left=" + wl + ",top=" + wt);
	eemZipWin.focus();
}

function viewPaymentDetailsForAnom(effDate){
	//alert("test");
	var subMenu = dwr.util.getValue("subMenu");
	var pbp = dwr.util.getValue("summSrchPbp");

	var method = 'viewPaymentDetails';

	url = "/mcaidReconAnomAction.do?method=" + method +'&subMenu='+subMenu+'&pbpId='+pbp+'&effDate='+effDate;
	var ww = 900;
	var wh = 550;
	var wt = 1;
	var wl = ((screen.width - 10) - ww) / 2;

	eemZipWin = window.open(url,method,"toolbar=no,titlebar=0,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,ControlBox=no,width=" + ww + ",height=" + wh + ",left=" + wl + ",top=" + wt);
	eemZipWin.focus();
}
function countLength(elmName){
	var elem = document.getElementById(elmName);
	content = elem.value;
	if(content.length >= 150){
		alert("Comment should be 150 characters only");
		content = content.substring(0, 150);
		document.getElementById(elmName).value = content;
	}
}
function paymentSearch() {

		//alert(" in payment Search");
		document.forms[0].summSrchPbp.value = document.forms[0].pbpIdPayment.value;
		document.forms[0].fromDate.value = document.forms[0].fromDate.value;
		document.forms[0].toDate.value = document.forms[0].toDate.value;
		document.forms[0].dateType.value = document.forms[0].dateType.value;
		document.forms[0].medicaidId.value = document.forms[0].medicaidId.value;
		//alert(" before setting empty value")
		document.forms[0].summSrchYear.value = " ";
		document.forms[0].summSrchQtr.value = " ";
		document.forms[0].summSrchMonth.value = " ";
		//alert(" after setting emoty value")

		document.body.style.cursor = 'wait';
		document.forms[0].subMenu.value = "SubmenuPaymentSummary";
		document.forms[0].method.value = 'paymentSearch';
		//alert(" submitting method:: "+document.forms[0].method.value );
		document.forms[0].submit();
	}
function paymentDashboardSearch() {

	//alert(" in payment Search");
	document.forms[0].summSrchPbp.value = document.forms[0].pbpIdPayment.value;
	document.forms[0].fromDate.value = document.forms[0].fromDate.value;
	document.forms[0].toDate.value = document.forms[0].toDate.value;
	document.forms[0].dateType.value = document.forms[0].dateType.value;
	//alert(" before setting empty value")
	document.forms[0].summSrchYear.value = " ";
	document.forms[0].summSrchQtr.value = " ";
	document.forms[0].summSrchMonth.value = " ";
	//alert(" after setting emoty value")
	document.body.style.cursor = 'wait';
	document.forms[0].subMenu.value = "SubmenuPaymentDashboard";
	document.forms[0].method.value = 'paymentDashBoardSearch';
	//alert(" submitting method:: "+document.forms[0].method.value );
	document.forms[0].submit();
}
function summGoSearch() {
	//alert(" in summGoSearch"+document.forms[0].summSrchFromEffDate.value);
	//alert(document.forms[0].summSrchDiscrpCd.value);
	document.forms[0].summSrchDiscrpCd.value = '';
	/*if()
	document.forms[0].summSrchDiscrpCd.value = document.forms[0].discrepancyCategory.value;
	alert(document.forms[0].summSrchDiscrpCd.value);*/
	if (document.forms[0].summSrchUpdtUserId.value==''){
			if( document.forms[0].summSrchGoPbp.value==''){
				alert(" Please select PBP ID!");
				return false;
			}
			//IFOX-00408436	: start
			if( document.forms[0].discrepancyCategory.value=='' && document.forms[0].summSrchMedicaidId.value==''){
				alert(" Please select discrepancy category or enter Medicaid ID!");
			//if( document.forms[0].discrepancyCategory.value==''){
			//	alert(" Please select discrepancy category!");
			//IFOX-00408436	: end
				return false;
			}
			if( document.forms[0].summSrchFromEffDate.value=='' ||  document.forms[0].summSrchToEffDate.value==''){
				alert(" Please select Effective date Range!");
				return false;
			}
			if(document.forms[0].summSrchFromEffDate.value!='' &&  document.forms[0].summSrchToEffDate.value!=''){
				var frmDate = document.forms[0].summSrchFromEffDate.value;
				var toDate = document.forms[0].summSrchToEffDate.value;

				var frmMnth = frmDate.substring(0,2);
				var frmYear = frmDate.substring(3);

				var toMnth = toDate.substring(0,2);
				var toYear = toDate.substring(3);

				//Date Range Fix : Start
				if(toYear == frmYear){
					//IFOX-00408436: start
					if(toMnth-frmMnth >3){
						alert(" Please select date range within 3 months!");
					//if(toMnth-frmMnth >1){
					//	alert(" Please select date range within a month!");
					//IFOX-00408436: end
						return false;
					}
				}
				else if(toYear-frmYear == 1){
					//IFOX-00408436: start
					if((toMnth-frmMnth < -11) || (toMnth-frmMnth > -9)){	
						alert(" Please select date range within 3 months!");
					//if(toMnth-frmMnth != -11){
					//	alert(" Please select date range within a month!");
					//IFOX-00408436: end
						return false;
					}
				}
				else if(toYear-frmYear != 1){
					//IFOX-00408436: start
					alert(" Please select date range within 3 months!");
					//alert(" Please select date range within a month!");
					//IFOX-00408436: end
					return false;
				}
				//Date Range Fix : End
			}
	}
	else if (document.forms[0].summSrchUpdtUserId.value!=''){

	}

	document.body.style.cursor = 'wait';
	document.forms[0].method.value = 'summGoOpt';
	document.forms[0].submit();
}

function goFileSearch() {
	document.body.style.cursor = 'wait';
	document.forms[0].method.value = 'goFileSearch';
	document.forms[0].submit();
}

function discDashboardSearch() {
	document.body.style.cursor = 'wait';
	document.forms[0].method.value = 'discDashboardOpt';
	document.forms[0].submit();
}

function anomDashboardSearch() {
	document.body.style.cursor = 'wait';
	document.forms[0].method.value = 'anomDashboardOpt';
	document.forms[0].submit();
}

function discSummarySearch() {
	document.body.style.cursor = 'wait';
	document.forms[0].method.value = 'discSummaryOpt';
	document.forms[0].submit();
}
function anomSummarySearch() {
	document.body.style.cursor = 'wait';
	document.forms[0].method.value = 'anomSummaryOpt';
	document.forms[0].submit();
}

function summAnomGoSearch() {

	if (document.forms[0].summSrchUpdtUserId.value==''){

		if( document.forms[0].summSrchGoPbp.value==''){
			alert(" Please select PBP ID!");
			return false;
		}
		if( document.forms[0].anamolyCategory.value==''){
			alert(" Please select anomaly category!");
			return false;
		}
		if( document.forms[0].summSrchFromEffDate.value=='' ||  document.forms[0].summSrchToEffDate.value==''){
			alert(" Please select Effective date Range!");
			return false;
		}
		if(document.forms[0].summSrchFromEffDate.value!='' &&  document.forms[0].summSrchToEffDate.value!=''){
			var frmDate = document.forms[0].summSrchFromEffDate.value;
			var toDate = document.forms[0].summSrchToEffDate.value;

			var frmMnth = frmDate.substring(0,2);
			var frmYear = frmDate.substring(3);

			var toMnth = toDate.substring(0,2);
			var toYear = toDate.substring(3);

			if(toYear-frmYear >=1){
				alert(" Please select date range within a month!");
				return false;
			}
			else if(toMnth-frmMnth >1){
				alert(" Please select date range within a month!");
				return false;
			}
		}
	}
	document.body.style.cursor = 'wait';
	document.forms[0].method.value = 'summGoOpt';
	document.forms[0].submit();
}

WaiverCodes = null;
function openWaiverCodes()
{
    var winWidth;
    var winHeight;
    var winLeft;
    var winTop;
    var link;

        if (screen.width > 800)
        {
            winWidth = 400;
            winHeight = 300;
            winTop = 7;
        }
        else
        if (screen.width > 640)
        {
            winWidth = 400;
            if (navigator.appName.indexOf("Netscape") == -1)
            {
                winTop = 5;
                winHeight = 300;
            }
            else
            {
                winHeight = 300;
                winTop = 1;
            }
        }
        else
        {
            winWidth = 400;
            winHeight = 300;
            winTop = 10;
        }

        winLeft = ((screen.width - 15) - winWidth) / 2;


            link = "/mss/jsp/MCRecon/jsp/WaiverCodes.jsp";

        //if (demo)
        //    link = "/mss/jsp/ReconDemoSrchAllDiscJsp.jsp";
        //else
        //    link = "/mss/jsp/ReconSrchAllDiscJsp.jsp?QA=" + qa;
        WaiverCodes = window.open(link, "Waiver Codes","location=no,menubar=no,scrollbars=yes,resizable=yes,left=" + winLeft + ",top=" + winTop + ",width=" + winWidth + ",height=" + winHeight+",title ="+"Waiver Codes");

}

//IFOX-00407694-FCLO/WRTO Changes: start
function fcloGoSearch(){
      if(document.forms[0].summSrchGoPbp.value==''){
            alert(" Please select PBP ID!");
            return false;
      }
      if(document.forms[0].summSrchMedicaidId.value==''){
            alert(" Please enter Medicaid ID!");
            return false;
      }
      if (document.forms[0].summSrchFromEffDate.value==''){
            alert(" Please select Effective Date!");
            return false;
      }
      document.body.style.cursor = 'wait';
      document.forms[0].method.value = 'fcloGoOpt';
      document.forms[0].submit();
}

function includeReopenDates() {
	//alert(" in reopen");
	//alert(document.forms[0].reopenDates+" "+document.forms[0].reopenDates.checked);
      if (document.forms[0].elements('reopenDates').checked == true){
    	 // alert(" if");
    	 //alert( document.forms[0].elements('fcloStartDate'));
            document.forms[0].elements('fcloStartDate').disabled = false;
            document.forms[0].elements('fcloEndDate').disabled = false;
            document.forms[0].fcloStartDate.value = document.forms[0].summSrchFromEffDate.value;
            document.forms[0].fcloEndDate.value = "99/9999";
      }
      else{
    	 // alert( " in else");
            document.forms[0].elements('fcloStartDate').disabled = true;
            document.forms[0].elements('fcloEndDate').disabled = true;
            document.forms[0].fcloStartDate.value = "";
            document.forms[0].fcloEndDate.value = "";
      }
}

function fcloSubmit(){
	//alert(" in submit");
      if (document.forms[0].elements('reopenDates').checked == true){
            if (document.forms[0].fcloStartDate.value=='' && document.forms[0].fcloEndDate.value!=''){
                  alert("Please select Reopen From Date!");
                  return false;
            } 
            if (document.forms[0].fcloEndDate.value=='' && document.forms[0].fcloStartDate.value!=''){
                  alert("Please select Until Date!");
                  return false;
            }
      }
   
            alert(document.forms[0].changedComment.value);
            document.body.style.cursor = 'wait';
            document.forms[0].subMenu.value = "SubmenuDiscForceClose";
            document.forms[0].method.value = 'discFcloUpdate';
      //      alert(" before submit 2");
            document.forms[0].submit();
      
}

function fcloWrtoSubmit(){
      //if (document.forms[0].elements('')
      if (document.forms[0].elements('reopenDates').checked == true){
            if (document.forms[0].fcloStartDate.value=='' && document.forms[0].fcloEndDate.value!=''){
                  alert("Please select Reopen From Date!");
                  return false;
            } 
            if (document.forms[0].fcloEndDate.value=='' && document.forms[0].fcloStartDate.value!=''){
                  alert("Please select Until Date!");
                  return false;
            } }
      var tPayFound = false;
       var selectArr = document.getElementsByName("select");
       var discArr = document.getElementsByName("discCd");
       for(i=0;i<selectArr.length;i++){
     	  if(selectArr[i].checked==true && discArr[i].value == "TPAY")
     		  tPayFound = true;
     	   }
      if(tPayFound==false){
     	  alert(" WRTO option is available only for TPAY discrepancy!");
     	  return false;
       }
       document.forms[0].wrtoInd.value = "Y";
       document.body.style.cursor = 'wait';
       document.forms[0].subMenu.value = "SubmenuDiscForceClose";
       document.forms[0].method.value = 'discFcloUpdate';
       document.forms[0].submit();
      
}
//IFOX-00407694-FCLO/WRTO Changes: end

