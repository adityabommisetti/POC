/*
$Id: reinsurance.js,v 1.2 2009/12/01 20:47:10 alevin Exp $
*/

  var freezeRow=2; //change to row to freeze at
  var freezeCol=2; //change to column to freeze at
  var myRow=freezeRow;
  var myCol=freezeCol;
  var speed=200; //timeout speed
  var myTable;
  var noRows;
  var myCells,ID;


function populateReinsPbp(){
	var formRef = document.forms ['ReinsuranceForm'];
	var i = formRef.planName.selectedIndex;
	var plan = formRef.planName.options[i].value;
	formRef.pbpId.options.length = 1;
	if ( plan == "" || formRef.pbpId.disabled) return;
		 
	var pmtYrObj = formRef.paymentYear;	
	i=pmtYrObj.selectedIndex;
	if (i <= 0) return;
	var pmtYr = pmtYrObj.options[i].value;
    
	var pbpArray = getReinsPbpArray(plan+pmtYr);
	var pbpArrayLen = 0;
	if ( pbpArray != null)
	    pbpArrayLen = pbpArray.length;
	
	for ( i = 0; i < pbpArrayLen; i++){
		opt = new Option(pbpArray[i][0],pbpArray[i][0]);
		formRef.pbpId.options[i+1] = opt;
	}
	formRef.pbpId.options.selectedIndex = 0;
}
function getReinsPbpArray ( planId){
	var planPBPSegmentLen = planPBPSegment.length;
	for ( i = 0; i < planPBPSegmentLen; i++){
		if ( planPBPSegment[i][0] == planId)
			return planPBPSegment[i][1];
	}
	return null;
}

function submitGO(action){
	var formRef = document.forms ['ReinsuranceForm'];
	if(formRef.planName.options.selectedIndex == 0){ // validate Plan Name
		showPopMessage(REQUIRED_PLAN_NAME);
		return false;
	}
	var pmtYrObj = formRef.paymentYear;	
	if ( pmtYrObj.options.selectedIndex == 0){
		showPopMessage("You must select a year");
		return false;
	}else{
		var pmtYr = pmtYrObj.options[pmtYrObj.options.selectedIndex].value;
		if ( pmtYr != ""){
			formRef.fromDate.value = pmtYr;
			formRef.toDate.value = pmtYr;
		}
	}	
	formRef.actionType.value = action;
	formRef.submit();
}

function submitForeCast(pbp, plan,yr,method) {
	var formRef = document.forms ['ReinsuranceForm'];
	formRef.fromDate.value = yr;
	formRef.toDate.value = yr;
	formRef.planName.value=plan;
	formRef.pbpId.value=pbp;
	formRef.method.value=method;
	formRef.actionType.value="drill";
	formRef.submit();
}

function hilightRow(rowId) {
	prevSelectedRow = dwr.util.getValue('selectRow');
	var className = "oddRow";
	var bgColor = "oddRowRed";
	if(prevSelectedRow % 2 =='1'  ) {
		bgColor = "evenRowRed";
		className = "evenRow";
	}
	applyClassOnTdTag(className, prevSelectedRow);
	dwr.util.setValue('selectRow', rowId); 
	applyClassOnTdTag("selectedRow", rowId); //apply selected row style class.
}
function gotoAnnRecon(methodName, menuName, pageType, formsName) {
	try {
		FacadeManager.getLastSelectedTab(menuName, {
				  			callback:function(data) {
				  			if(data != null && data[0] != null && data[0]!="ddirUpdate") 
							    methodName=data[0];
							SavNSubmit(methodName, menuName, pageType, formsName);
				  			}});
	} catch(e) {
		showPopMessage("Error: "+e.message);
	}
}