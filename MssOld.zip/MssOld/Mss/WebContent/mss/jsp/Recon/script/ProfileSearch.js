
//This method submit discrepancy Detail action.
function submitProfileSearchAction(advancedSearchText){

	if(validateSearchProfileForm() == false){
		return false;
	}
	var formRef = document.forms ['SearchProfileForm'];
	
	var paymentMonthObj = formRef.paymentMonth;	
	if ( paymentMonthObj.options.selectedIndex <= 0){
		formRef.fromDate.value = "";
		formRef.toDate.value = "";
	}else{
		var paymentMonthObjValue = paymentMonthObj.options[paymentMonthObj.options.selectedIndex].value;
		if ( paymentMonthObjValue != ""){
			formRef.fromDate.value = paymentMonthObjValue + "0101";
			formRef.toDate.value = paymentMonthObjValue + "1231";
		}
	}
	
	
	if(formRef.parameterCodeAdv.value == advancedSearchText){
		formRef.parameterCodeAdv.value='';
		
	}
	
	formRef.parameterCodeAdv.value = formRef.parameterCodeAdv.value.toUpperCase();
	
	formRef.actionType.value = "search";
		
	var menuName = formRef.menuName.value ;
	
	saveUiContext(formRef,'profileSearch', menuName, '');
}

/*
Author : Pradeep Palat
Function 'validateSearchProfileForm'
Description : ValidateForm search Form for different pages.
*/
function validateSearchProfileForm(){
	var result = true;
	var formRef = document.forms ['SearchProfileForm'];

	if(formRef.planName.options.selectedIndex == 0){ // validate Plan Name
		showPopMessage(REQUIRED_PLAN_NAME);
		result = false;
	}
	
	return result;
}

function profilePagination(id,menuName,partName, pbpLevel){
	 try{
		FacadeManager.getProfileSearchDetailVO(id, menuName, partName, pbpLevel, {
							  			callback:function(data) {
							   			CBgetProfileList(data, menuName, partName, pbpLevel);}
											});
	}catch(e){
		showPopMessage("Error: "+e.message);
	}
	
}


function CBgetProfileList(data, menuName, partName, pbpLevel){
	
	profileSearchDetailVO = data ;

	var divHtml="";	
	var id = partName + "ProfileList";
	
	if( profileSearchDetailVO == null ) {
		divHtml += "<table width='100%'  border='1' cellpadding='0' cellspacing='0' bordercolor='#999999' style='border-collapse:collapse;word-break:break-all'>";
		divHtml += "<tr><td colspan='10'>&nbsp;" + MSG_NO_DATA_FOUND + "</td></tr></table>";
	} else {

		var profileSearchVOList = null;

		if (PARTC == partName) {
			profileSearchVOList = profileSearchDetailVO.partCProfileSearchVOList;
			divHtml = generatePlanProfileHTML(menuName, partName, profileSearchVOList);
			id = partName + "ProfileList";
		}
		
		if (PARTD == partName) {
			if ( pbpLevel != 'PBP'){
				profileSearchVOList = profileSearchDetailVO.partDProfileSearchVOList;
				divHtml = generatePlanProfileHTML(menuName, partName, profileSearchVOList);
				id = partName + "ProfileList";

			}else {
				profileSearchVOList = profileSearchDetailVO.partDPBPProfileSearchVOList;
				divHtml = generatePbpProfileHTML(menuName, partName, profileSearchVOList);
				id = partName + pbpLevel + "ProfileList";				
			}
		}
	}		

	document.getElementById(id).innerHTML = divHtml;

	top.body.calcHeight();	
}


function generatePlanProfileHTML(menuName, partName, profileSearchVOList, pbpLevel){
	
	var divHtml = "";	
	var profileSearchVO = null;
	var profileSearchVOArr = null;
	var startDate = "";
	var endDate = "";
	var currentPage = "";
	var pageNumber = 1;
	

	if(profileSearchVOList != null ) {
		currentPage = profileSearchVOList.currentPage;
		pageNumber = profileSearchVOList.pageNumber;
		profileSearchVOArr = profileSearchVOList.profileSearchVOList;
	}

	divHtml += '<table width="100%"  border="1" cellpadding="0" cellspacing="0" bordercolor="#999999" style="border-collapse:collapse;word-break:break-all">';
	
	if (PARTC == partName) {
		divHtml+='<tr id="exportPartC" style="display:none"><td></td></tr>'
	}else if(PARTD == partName){
		divHtml+='<tr id="exportPartD" style="display:none"><td></td></tr>'
	}

	//divHtml+='<tr style="display:none" colspan="10"> <td id="selectRow">'+previousSelectedRow +'</td></tr>'

	if(profileSearchVOArr ==null || profileSearchVOArr.length==0){
		return ;
		divHtml+="<tr><td colspan='10'> &nbsp;</td></tr>";
	} else {
		var j = 0 ;	

		for(var i = 0;i < profileSearchVOArr.length ; i++ ){
			profileSearchVO = profileSearchVOArr[i];

			startDate = (profileSearchVO.startDate == null) ? "" : profileSearchVO.startDate;
			endDate = (profileSearchVO.endDate == null) ? "" : profileSearchVO.endDate;

			if (PARTD == partName) 
				i += 10 ;
			var classCss = "class = ''";
			if ( i % 2 == 0) {
			  classCss = "class='evenRow bordered-table'"; //IFOX-00419340 added bordered-table
			} else {
			  classCss = "class='oddRow bordered-table'"; //IFOX-00419340 added bordered-table
			}

			divHtml+="<tr "+ classCss +" id='"+i +"' style='cursor:pointer' >";
			divHtml+="<td width='20%' height='20' align='center' id='startDate_" + i + "'>" + startDate + "</td>";
			divHtml+="<td width='20%' height='20' align='center' id='endDate_" + i + "'>" + endDate + "</td>";
			divHtml+="<td width='20%' height='20' align='center' id='parmCode_" + i + "'><SPAN title='" + profileSearchVO.parmDesc + "'>" + profileSearchVO.parmCode + "</SPAN></td>";
			divHtml+="<td width='20%' height='20' align='center' id='parmValue_" + i + "'>" + profileSearchVO.parmValue + "</td>";
			divHtml+="<td width='20%' height='20' align='center' id='fmtdLastUpdtTime_" + i + "'>" + profileSearchVO.fmtdLastUpdtTime + "</td>";
			divHtml+="<td style='display:none' id='lastUpdtTime_" + i + "'>" + profileSearchVO.lastUpdtTime + "</td>";
			divHtml+="</tr>";
			if (PARTD == partName) 
				i -= 10 ;				
		}
		divHtml+="<tr>";
		
		var spanName = "pgNumberPart C";
		if (PARTD == partName){
			spanName = "pgNumberPart DPLN";
		}

		divHtml+="<td colspan='10' align='right' class='pageRow'>";
		divHtml+="<table width='50%' height='20'  border='0' align'right' cellpadding='0' cellspacing='0'><tr>";
		divHtml+="<td align='right'>Page# : <SPAN id='" + spanName + "'>" + pageNumber + "</SPAN>&nbsp;&nbsp;</td>";
		if( pageNumber == 1) {
			divHtml += '<td width="25px" align="center" ><img src="/mss/jsp/Recon/images/Arrow_Page1.png" ></td>';
			divHtml += '<td width="25px" align="center"><img src="/mss/jsp/Recon/images/Arrow_PageP.png"  ></td>';
		} else {
			divHtml += '<td width="25px" align="center" ><img src="/mss/jsp/Recon/images/Arrow_Page1.png"  onclick="useLoadingImage(this);profilePagination(\'first\',\''+menuName+'\',\''+partName+'\',\'PLAN\');" style="cursor:pointer"></td>';
			divHtml += '<td width="25px" align="center"><img src="/mss/jsp/Recon/images/Arrow_PageP.png" onclick="useLoadingImage(this);profilePagination(\'previous\',\''+menuName+'\',\''+partName+'\',\'PLAN\');" style="cursor:pointer"></td>';
		}
		if( currentPage == 'last') {
			divHtml += '<td width="25px" align="center"><img src="/mss/jsp/Recon/images/Arrow_PageN.png" ></td>';
		} else {
			divHtml += '<td width="25px" align="center"><img src="/mss/jsp/Recon/images/Arrow_PageN.png" onclick="useLoadingImage(this);profilePagination(\'next\',\''+menuName+'\',\''+partName+'\',\'PLAN\');" style="cursor:pointer"></td>';
		}
		divHtml+="</tr></table></td>";
		divHtml+="</tr>";
	}	
	divHtml+="</table>";	
	return divHtml;
	
}


function generatePbpProfileHTML(menuName, partName, profileSearchVOList, pbpLevel){
	
	var divHtml = "";
	var profileSearchVO = null;
	var profileSearchVOArr = null;
	var startDate = "";
	var endDate = "";
	var currentPage = "";
	var pageNumber = 1;
	

	if(profileSearchVOList != null ) {
		currentPage = profileSearchVOList.currentPage;
		pageNumber = profileSearchVOList.pageNumber;
		profileSearchVOArr = profileSearchVOList.profileSearchVOList;
	}
	
	divHtml += '<table width="100%"  border="1" cellpadding="0" cellspacing="0" bordercolor="#999999" style="border-collapse:collapse;word-break:break-all">';
	
	if (PARTC == partName) {
		divHtml+='<tr id="exportPartC" style="display:none"><td></td></tr>'
	}else if(PARTD == partName){
		divHtml+='<tr id="exportPartD" style="display:none"><td></td></tr>'
	}

	//divHtml+='<tr style="display:none" colspan="10"> <td id="selectRow">'+previousSelectedRow +'</td></tr>'

	if(profileSearchVOArr ==null || profileSearchVOArr.length==0){
		return ;
		divHtml+="<tr><td colspan='10'> &nbsp;</td></tr>";
	} else {
		var j = 0 ;	

		for(var i = 0;i < profileSearchVOArr.length ; i++ ){
			profileSearchVO = profileSearchVOArr[i];

			startDate = (profileSearchVO.startDate == null) ? "" : profileSearchVO.startDate;
			endDate = (profileSearchVO.endDate == null) ? "" : profileSearchVO.endDate;

			if (PARTD == partName) 
				i += 10 ;
			var classCss = "class = ''";
			if ( i % 2 == 0) {
			  classCss = "class='evenRow bordered-table'"; // IFOX-00419340 added bordered-table
			} else {
			  classCss = "class='oddRow bordered-table'"; //IFOX-00419340 added bordered-table
			}

			divHtml+="<tr "+ classCss +" id='"+i +"' style='cursor:pointer' >";
			divHtml+="<td width='10%' height='20' align='center' id='pbpId2_" + i + "'>" + profileSearchVO.pbpId + "</td>";
			divHtml+="<td width='10%' height='20' align='center' id='segmentId2_" + i + "'>" + profileSearchVO.segmentId + "</td>";
			divHtml+="<td width='16%' height='20' align='center' id='startDate2_" + i + "'>" + startDate + "</td>";
			divHtml+="<td width='16%' height='20' align='center' id='endDate2_" + i + "'>" + endDate + "</td>";
			divHtml+="<td width='16%' height='20' align='center' id='parmCode2_" + i + "'><SPAN title='" + profileSearchVO.parmDesc + "'>" + profileSearchVO.parmCode + "</SPAN></td>";
			divHtml+="<td width='16%' height='20' align='center' id='parmValue2_" + i + "'>" + profileSearchVO.parmValue + "</td>";
			divHtml+="<td width='16%' height='20' align='center' id='fmtdLastUpdtTime2_" + i + "'>" + profileSearchVO.fmtdLastUpdtTime + "</td>";
			divHtml+="<td style='display:none' id='lastUpdtTime2_" + i + "'>" + profileSearchVO.lastUpdtTime + "</td>";
			
			divHtml+="</tr>";
			if (PARTD == partName) 
				i -= 10 ;				
		}
		
		divHtml+="<tr>";

		divHtml+="<td colspan='10' align='right' class='pageRow'>";
		divHtml+="<table width='50%' height='20'  border='0' align'right' cellpadding='0' cellspacing='0'><tr>";
		divHtml+="<td align='right'>Page# : <SPAN id='pgNumberPart DPBP'>" + pageNumber + "</SPAN>&nbsp;&nbsp;</td>";

		if( pageNumber == 1) {
			divHtml += '<td width="25px" align="center" ><img src="/mss/jsp/Recon/images/Arrow_Page1.png"></td>';
			divHtml += '<td width="25px" align="center"><img src="/mss/jsp/Recon/images/Arrow_PageP.png" ></td>';
		} else {
			divHtml += '<td width="25px" align="center" ><img src="/mss/jsp/Recon/images/Arrow_Page1.png" onclick="useLoadingImage(this);profilePagination(\'first\',\''+menuName+'\',\''+partName+'\',\'PBP\');" style="cursor:pointer"></td>';
			divHtml += '<td width="25px" align="center"><img src="/mss/jsp/Recon/images/Arrow_PageP.png" onclick="useLoadingImage(this);profilePagination(\'previous\',\''+menuName+'\',\''+partName+'\',\'PBP\');" style="cursor:pointer"></td>';
		}
		if( currentPage == 'last') {
			divHtml += '<td width="25px" align="center"><img src="/mss/jsp/Recon/images/Arrow_PageN.png" ></td>';
		} else {
			divHtml += '<td width="25px" align="center"><img src="/mss/jsp/Recon/images/Arrow_PageN.png" onclick="useLoadingImage(this);profilePagination(\'next\',\''+menuName+'\',\''+partName+'\',\'PBP\');" style="cursor:pointer"></td>';
		}
		divHtml+="<td width='6px' align='center'></td>";		
		divHtml+="</tr></table></td>";
		divHtml+="</tr>";
	}	
	divHtml+="</table>";	
	
	return divHtml;
}


/*
 *	This function is invoked to set/reset the search parameters based on the PART-C/PART-D selection.
 */
function hasPartD(status){

	if(status){
		document.getElementById("pbpId").disabled=false;
		document.getElementById("segmentId").disabled=false;
		document.getElementById("pbpIdTxt").style.color="BLACK";
		document.getElementById("segmentIdTxt").style.color="BLACK";
		document.getElementById("partDTxt").style.color="BLACK";
		populatePbp();
	}else{
		document.getElementById("pbpId").disabled=true;
		document.getElementById("segmentId").disabled=true;
		document.getElementById("pbpIdTxt").style.color="GRAY";
		document.getElementById("segmentIdTxt").style.color="GRAY";
		document.getElementById("partDTxt").style.color="GRAY";
		document.forms[0].pbpId.options.length=1;
		document.forms[0].segmentId.options.length=1;
	}
}
	

/*
 *	 Actions to be done when the user chooses a different plan
 */

function doOnPlanChange(){
	var isPartD = document.forms["SearchProfileForm"].partName[1].checked;	
	if ( isPartD){
		document.forms[0].selectedPbpId.value = "";
		document.forms[0].selectedSegmentId.value = "";
	
		populatePbp();
	}
}


/*
 *	Function to fetch the PBP Array based on the plan Id
 */
function getPbpArray ( planId){
	var planPBPSegmentLen = planPBPSegment.length;

	for ( i = 0; i < planPBPSegmentLen; i++){

		if ( planPBPSegment[i][0] == planId){
			return planPBPSegment[i][1];
		}
	}
	return null;
}


/*
 *	Function to fetch the Segment Array based on the plan Id and PBP Id
 */
function getSegmentArray ( planId, pbpId){

	var pbpArray = getPbpArray(planId);

	if ( pbpArray == null){
		return null;
	}

	var pbpArrayLen = 0;
	if ( pbpArray != null)
	    pbpArrayLen = pbpArray.length;

	for ( i = 0; i < pbpArrayLen; i++){
		if ( pbpArray[i][0] == pbpId){
			return pbpArray[i][1];
		}
	}

	return null;
}
	
/*
 *	Function to populate the year dropdown
 */
function populatePymtYr(paymentMonthArr){
	var pymtObj = document.getElementById("paymentMonth");
	pymtObj.options.length=1;
	
	for ( i = 0; i < paymentMonthArr.length; i++){
		pymtObj.options[i+1] = new Option(paymentMonthArr[i], paymentMonthArr[i]);
	}
}	

/*
 *	 Function to populate pbp dropdown based on plan
 */
function populatePbp(){
	var selectedIndex = 0;
	var plan = document.forms[0].planName.options[document.forms[0].planName.selectedIndex].value;
	
	var defaPlanName = document.forms[0].selectedPlanName.value;
	var defaPbpId = document.forms[0].selectedPbpId.value;

	document.forms[0].pbpId.options.length = 1;
	document.forms[0].segmentId.options.length = 1;

	if ( plan == "" || document.forms[0].pbpId.disabled){
		 return;
	}

	var pbpArray = getPbpArray(plan);
	var pbpArrayLen = 0;
	if ( pbpArray != null)
	    pbpArrayLen = pbpArray.length;
	
	for ( i = 0; i < pbpArrayLen; i++){
		opt = new Option(pbpArray[i][0],pbpArray[i][0]);
		document.forms[0].pbpId.options[i+1] = opt;
		if ( plan == defaPlanName && pbpArray[i][0] == defaPbpId){
			selectedIndex = (i + 1);
		}		
	}
	document.forms[0].pbpId.options.selectedIndex = selectedIndex;
	
	populateSegment();
}

/*
 *	 Function to populate segment dropdown based on pbp selection
 */
function populateSegment(){
	var selectedIndex = 0;
	var plan = document.forms[0].planName.options[document.forms[0].planName.options.selectedIndex].value;
	var pbpId = document.forms[0].pbpId.options[document.forms[0].pbpId.options.selectedIndex].value;
	
	var defaPlanName = document.forms[0].selectedPlanName.value;
	var defaPbpId = document.forms[0].selectedPbpId.value;
	var defaSegmentId = document.forms[0].selectedSegmentId.value;
	document.forms[0].segmentId.options.length = 1;

	if ( pbpId == "" || document.forms[0].segmentId.disabled){ 
		return
	};


	var segmentArray = getSegmentArray(plan, pbpId);
	var segmentArrayLen = segmentArray.length;

	for ( i = 0; i < segmentArrayLen; i++){
		opt = new Option(segmentArray[i], segmentArray[i]);
		document.forms[0].segmentId.options[i + 1] = opt;
		if ( plan == defaPlanName && pbpId == defaPbpId && segmentArray[i] == defaSegmentId ){
			selectedIndex = (i + 1);
		}
	}
	document.forms[0].segmentId.options.selectedIndex = selectedIndex;
}

/*
 * 	Set the Advanced Search Parameter value
 */
function setParameterCodeAdv(){
	var parmCode = document.getElementById("parameterCode").options[document.getElementById("parameterCode").options.selectedIndex].value;

	if ( parmCode == "All" || parmCode == ""){
		document.getElementById("parameterCodeAdv").value=PAGE_PROFILE_PARM_ADVANCED_SEARCH
		document.getElementById("parameterCodeAdv").style.color="silver";
	}
	else
	{
		document.getElementById("parameterCodeAdv").value=parmCode
		document.getElementById("parameterCodeAdv").style.color="black";		
	}
}

/*
 * 	Start the edit process for the advanced search box
 */
function startEdit(obj){
	if ( obj.value == PAGE_PROFILE_PARM_ADVANCED_SEARCH){
		obj.value="";
		document.getElementById("parameterCodeAdv").style.color="black";
	}
}

/*
 * 	End the edit process for the advanced search box
 */
function endEdit(obj){
	if ( obj.value == ""){
		obj.value=PAGE_PROFILE_PARM_ADVANCED_SEARCH;
		document.getElementById("parameterCodeAdv").style.color="silver";
	}
}	

/*
 *  This method is used to populate the parameter code dropdown depending on whether the user chooses Part-C or Part-C
 */
function populateParmCode(partName){
	var optionList = null;
	var parmCodeObj = document.getElementById("parameterCode");	
	parmCodeObj.options.length = 1;
	
	if ( partName == PARTC){
		optionList = partCParmCodeList;
	}else{
		optionList = partDParmCodeList;			
	}
	
	if ( optionList != null){
		for ( i = 0; i < optionList.length; i++){
			var option = new Option(optionList[i][0], optionList[i][1]);
			parmCodeObj.options[i + 1] = option;
		}
	}		
	//Set the advanced search text box to default
	document.getElementById("parameterCodeAdv").value=PAGE_PROFILE_PARM_ADVANCED_SEARCH
	document.getElementById("parameterCodeAdv").style.color="silver";

}
	//Recon Work Queue changes : start
function submitAutoAssignLink(methodName) {
	var formRef = document.forms ['SearchProfileForm'];
	tempMenu = dwr.util.getValue("menuName");
	var pageName = dwr.util.getValue("methodName");
	formRef.actionType.value = methodName;
	var menuName = formRef.menuName.value ;
	
	saveUiContext(formRef, pageName, tempMenu, '');
}
function disableSearchFields(value){
	
	if(value=="true"){
		document.getElementById('planName').setAttribute('disabled', 'disabled');
		document.getElementById('partName').setAttribute('disabled', 'disabled');
		document.getElementById('parameterCodeAdv').setAttribute('disabled', 'disabled');
		document.getElementById('paymentMonth').setAttribute('disabled', 'disabled');
		document.getElementById('parameterCode').setAttribute('disabled', 'disabled');
		document.getElementById('pbpId').setAttribute('disabled', 'disabled');
		document.getElementById('segmentId').setAttribute('disabled', 'disabled');
		document.getElementById('butGoGif').style.display = 'none';
		document.getElementById('autoExport').style.display ='none';
	
	}else{    
		document.getElementById('planName').removeAttribute('disabled');
		document.getElementById('partName').removeAttribute('disabled');
		document.getElementById('paymentMonth').removeAttribute('disabled');
		document.getElementById('parameterCodeAdv').removeAttribute('disabled');
		document.getElementById('parameterCode').removeAttribute('disabled');
		document.getElementById('pbpId').removeAttribute('disabled');
		document.getElementById('segmentId').removeAttribute('disabled');
		document.getElementById('butGoGif').style.display = 'none';
	}
}
//Recon Work Queue changes : end
