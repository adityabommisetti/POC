/*























































































































































































































































































































$Id: scripts.js,v 1.1 2014/06/26 07:56:13 praveen Exp $
*/
var isAjaxProcess=false;
var exportDivLeft=250;
var exportDivTop=130;
var activeMenu;
var uiContext = new Array();
var globalFilterVO ;//= {planName:null,startDate:null,endDate:null,dateType:null };
var filterVO;
var evntCalWindow = null; //Added for IFOX-00428245

function showExportMsg(contextRange){
	//alert(" in showExportMsg"+contextRange);
	var value = contextRange;
	
	if(contextRange == false){
		contextRange = "ALL";
	}
	else if (contextRange == true){
		contextRange = "Current";

	}
	//alert(" after"+contextRange);
	if("ALL"==contextRange){
		if(isBorwserIE()) 
				document.getElementById("noteAllPages").style.display= "block";
		else 
				document.getElementById("noteAllPages").style.display= "table-row";
	}
	else
		document.getElementById("noteAllPages").style.display= "none";
}

/*
 Author  : deepak
 Discrepation : Get last selected tab (e.g planDashboard ,discrepancyDashboard,paymentsummary,discrepancysummary)
*/

function getLastSelectedTab(methodName, formsName, action, actionType, menuName) {
	var id = document.getElementById("butGoGif");
	if(id != null){
		useLoadingImage(id);	
	}
	try {
		FacadeManager.getLastSelectedTab(menuName, {
				  			callback:function(data) {
				  			// when did't get any tab name then we switch to defult tab of that menu 
				  			// e.g paymentDashboard in plan menu.
				  			if(data == null) {
				  				//alert(" in data null");
				  				
				  				switchTab(methodName, formsName, action, actionType, menuName, '') ;
					  		} else { //switch to last selected tab.
					  			//alert("else--"+data[0]);
				  				if(data[0] == 'DiscrepancyDetail') //if last selected tab is discrepancyDetail than we call discrepancyDatailAction to get selected tab.
					  				action = 'discrepancyDetailAction.do';

				  				switchTab(data[0], formsName, action, actionType, data[2], data[1]);
							}}
				  			});
	} catch(e) {
		showPopMessage("Error: "+e.message);
	}
}

/*
Author : Kapil
Discription : Used to add popUp Div scrolling values with appropiate event 
*/
function popUpOnLoad(){
	setTopAndLeftForExportDivOrMsgDiv();
		
	window.onresize = function(){
		setTopAndLeftForExportDivOrMsgDiv();
	}
	
	window.onscroll  = function(){
		exportXY = findPosition(document.getElementById('exportPrintAnchor'));
		document.getElementById('pop_container').style.top = document.body.scrollTop + "px";
		document.getElementById('pop_inner').style.top = document.body.scrollTop + exportXY[1] + "px";
		document.getElementById('msgPopInner').style.top = document.body.scrollTop + exportXY[1] + "px";
	}
}

/*
Discription : this function will return TRUE if "Export / Print" Dialog OR "SYSTEM ALTER" Dialog is opened.
				else will return FALSE;
*/
function isAlertDivOpen(){
	var popContainer = document.getElementById('pop_container');
	if(popContainer && (popContainer.style.display == "block" || popContainer.style.display == ""))
		return true;
	
	return false;
}

function resetBodyHeight(){
	if(isAlertDivOpen() == false && top.body && top.body.calcHeight)
		 top.body.calcHeight();
} 

setTimeout(resetBodyHeight, 500);

/*
Discription : 'showHomePage' is used by errorPage.jsp to show home page.
if errorPage is displaying in pop-up screen then this will close that pop-up window 
and Home Page will show on main window.
*/
function showHomePage(){
	var HOME_PAGE = '/mss/html/GoHome.html';
	if(window.opener){
		window.opener.location.href = HOME_PAGE;
		window.close();
	} else {
		window.location.href= HOME_PAGE;
	}
}

/*
Author : Rakesh Surana
Discription : Uses to show message in Message Dialog Box
Inputs : 
	Msg : Message used to show in System Alert Dialog
	Func : Used to call any function, when user clicks on 'OK' button.
*/
function showPopMessage(msg, funcCB){
	if(msg == null){
		document.getElementById('msgPopInner').style.display='none';
		if(document.getElementById('exportPdf')){
			document.getElementById('exportPdf').innerHTML= '<INPUT  type="button" class="inputButton"  value="PDF" onclick="setImageDisable();exportPrintData(\'PDF\');">';	
			document.getElementById('exportPrint').innerHTML= '<INPUT  type="button" class="inputButton" value="Print" onclick="exportPrintData(\'Print\');">';	
			var csv = document.getElementById('exportCsv');
			if (csv != null && csv != undefined)
                csv.innerHTML= '<INPUT  type="button" class="inputButton" value="CSV" onclick="setImageDisable();exportPrintData(\'CSV\');">';	
		}
		
		if(document.getElementById('pop_inner').style.display != "block"){
			document.getElementById('pop_container').style.display='none';
			showHideDropDown(false);
	
			resetBodyHeight();

			if(funcCB != null)
				funcCB();
		}
		
	}else{
//		if(document.getElementById('pop_container').style.display != "")
		if(isAlertDivOpen() == false)
			showHideDropDown(true);
		
		if(document.getElementById('exportTd') != null)
			exportXY = findPosition(document.getElementById('exportTd'));
		else
			exportXY = findPosition(document.getElementById('exportPrintAnchor'));
		
			
		//exportXYUpdate = findPosition(document.getElementById('butUpdateJPG'));
		document.getElementById('showMsgDiv').innerHTML = msg;
		document.getElementById('showMsgDiv').style.lineHeight= "16px";		// Added for alert
		document.getElementById('msgPopInner').style.top = exportXY[1] + "px";
		//document.getElementById('msgPopInner').style.top = exportXY[1] + "px";
		document.getElementById('msgPopInner').style.display= "block";
		var innerPop = (document.getElementById('pop_inner').style.display);
		if (innerPop == 'block') {
			document.getElementById('msgPopInner').style.top = document.getElementById('pop_inner').style.top ;
		}else {
		document.getElementById('msgPopInner').scrollIntoView();
		}
		//window.scrollTo(200,200);
		
		
		document.getElementById('pop_container').style.display = "block";
		
		// adding call back function which is called, when User click on 'OK' button
		var sysMsgOkBtn = document.getElementById("sysMsgOkBtn");
		if(funcCB == undefined || funcCB == 'null')
			funcCB = null;

		sysMsgOkBtn.onclick = function() { showPopMessage(null, funcCB); };
	}
	showCursorPointer();
}

/*
Author : Kapil Wadhwa
*/
function hideDialobBox(){
	isAjaxProcess = false;
	if(isAjaxProcess == false){
		document.getElementById("noteAllPages").style.display= "none";
		document.getElementById('pop_inner').style.display='none';
		document.getElementById('pop_container').style.display='none';
		
		showHideDropDown(false);
	}
}
/*
Author : Kapil
Discription: Used to show child node row by UI
*/
function toggleVisibilityDown(x, id) {
	var row = document.getElementById(id+"_plan");
	var e = document.getElementById(id);
	if(e.style.display == 'none') {
		e.style.display = "";
		if(row!=null)
			row.style.display = "";
		e.setAttribute("rowExpanded", "true");
		x.src = '/mss/jsp/Recon/images/Minus.png';
	} else {
		e.style.display = 'none';
		if(row!=null)
			row.style.display = 'none';
		e.setAttribute("rowExpanded", "false");
		//e.removeAttribute("rowExpanded"); //change on date 26/March by deepak
		x.src = '/mss/jsp/Recon//images/Plus.png';
	}
	
	resetBodyHeight();
	if(id == 'wrkqList')
		toggleVisibilityDown(x,'wrkqOpt');
}

/*
Author : Kapil
Discription: Used to hide child node row by UI
*/
function toggleVisibilityUp(x, id) {
	var e = document.getElementById(id);
	if(e.style.display == 'none') {
		e.style.display = "";
		//x.src = '/mss/jsp/Recon/images/HideSearch.jpg';
		x.src = '/mss/jsp/Recon/images/Minus.png';
	} else {
		e.style.display = 'none';
		//x.src = '/mss/jsp/Recon/images/ShowSearch.jpg';
		x.src = '/mss/jsp/Recon/images/Plus.png';
	}
	if(id == 'wrkqList')
		toggleVisibilityUp(x,'wrkqOpt');
}

/*
Author : Rakesh Surana
Discription : This method is responsible to show appropiate root Menu (Black Row Menu).
*/
function init() {
	DWREngine.setErrorHandler(dwrErrorHandler);
	// switching MasterMenu in body.jsp
	var headerDocument = parent.document;
	if(document.getElementsByName("methodName")[0] && top.sessType==3){
		headerDocument.getElementById("mainMenuTr").style.display = "";
		headerDocument.getElementById("homeMenuTr").style.display = "none";
	}else if(headerDocument.getElementById("mainMenuTr")){
		headerDocument.getElementById("mainMenuTr").style.display = "none";
		headerDocument.getElementById("homeMenuTr").style.display = "";
	}
	if (top.sessType==2) {//recon
		headerDocument.getElementById("mainD").style.display = "none";
		headerDocument.getElementById("mainL").style.display = "";
		headerDocument.getElementById("reconL").style.display = "none";
		headerDocument.getElementById("reconD").style.display = "";
	}
	else if (top.sessType==1){
		headerDocument.getElementById("mainD").style.display = "";
		headerDocument.getElementById("mainL").style.display = "none";
		var elm=headerDocument.getElementById("reconL");
		if(elm!=null){
		  elm.style.display = "";
		  headerDocument.getElementById("reconD").style.display = "none";
		}
	}
}

function setSessType(flag) {top.sessType=flag;}

/*
Author : Rakesh
Description : DWR Error Handler, call error page with appropiate error message on Any Error occurs
*/
function dwrErrorHandler(msg){
	location.href = ERROR_PAGE+"?Msg="+ msg;
	return false;
}


//This function use to show the loading images and message i case of ajax all.
function useLoadingImage(obj,imageSrc,message) {
	var fieldPos = new positionInfo(obj);
    var x = fieldPos.getElementLeft();
    var y = fieldPos.getElementBottom();
	
	var loadingImage;
	if (imageSrc) {
		 loadingImage = imageSrc;
	} else {
		 loadingImage = "/mss/jsp/Recon/images/Loading.gif";
	}
	var loadingMessage;
	if (message) {
		 loadingMessage = message;
	} else {
		 loadingMessage = "Loading...";
	}
	x = x- GetWidth()+17;
	if(x < -940)
		x += 33;
	y = y+6; ;	  
	 var disabledImage = $('disabledImageZone');
	if (disabledImage ) {
	//	disabledImage.style.left = x + "px";
		//disabledImage.style.top = y + "px";
	}
	DWREngine.setPreHook(function() {
		//isAjaxProcess = true;
		if(document.getElementById('flashscreen'))
			document.getElementById('flashscreen').style.display = "";
		var disabledImageZone = $('disabledImageZone');
		
		 if (!disabledImageZone && obj.id != "exportTableHeader" ) {
		 	 disabledImageZone = document.createElement('div');
			 disabledImageZone.setAttribute('id', 'disabledImageZone');
			 disabledImageZone.style.position = "absolute";
			 disabledImageZone.style.zIndex = "1000";
			 disabledImageZone.style.left = x+ "px";
			 disabledImageZone.style.top = y+ "px";
			 disabledImageZone.style.width = "100%";
			 disabledImageZone.style.height = "0%";
			 
			 var imageZone = document.createElement('img');
			 imageZone.setAttribute('id','imageZone');
			 imageZone.setAttribute('src',loadingImage);
			 imageZone.style.position = "absolute";
			 imageZone.style.top = "0px";
			 imageZone.style.right = "0px";
			 imageZone.style.width = "25px";
			 imageZone.style.height = "25px";	
			 disabledImageZone.appendChild(imageZone);
			 document.body.appendChild(disabledImageZone);
			 dwr.util._disabledZoneUseCount = 1;
			// hidding Loading GIF for SaveUIContext calling during form submition.
			 if(obj.id == "butGoGif"){
				//disabledImageZone.style.visibility = 'hidden';
				 }
			
		}
		else {	
			if(obj.id == "exportTableHeader"){ // showing Loading GIF for exportProcess calling during form submition.
				obj.style.visibility = 'visible';
			}
			else if(obj.id != "butGoGif"){// hidding Loading GIF for SaveUIContext calling during form submition.		
				//disabledImageZone.style.visibility = 'visible';
			}
			dwr.util._disabledZoneUseCount++;
		}
	  });

	  DWREngine.setPostHook(function() {
	  	  dwr.util._disabledZoneUseCount--;
	  	  if(obj.id == "exportTableHeader") { // hideing Loading GIF for exportProcess calling during form submition.
			   obj.style.visibility = 'hidden';
			  isAjaxProcess = false;
			}
		  if (dwr.util._disabledZoneUseCount == 0 ) {
			  isAjaxProcess = false;
			  //$('disabledImageZone').style.visibility = 'hidden';
			if(document.getElementById('flashscreen'))
				document.getElementById('flashscreen').style.display='none';
		 }
	  });
	  
	  
}

function positionInfo(object) {
  var p_elm = object;

  this.getElementLeft = getElementLeft;
  function getElementLeft() {
    var x = 0;
    var elm;
    if(typeof(p_elm) == "object"){
      elm = p_elm;
    } else {
      elm = document.getElementById(p_elm);
    }
    while (elm != null) {
      x+= elm.offsetLeft;
      elm = elm.offsetParent;
    }
    return parseInt(x);
  }

  this.getElementWidth = getElementWidth;
  function getElementWidth(){
    var elm;
    if(typeof(p_elm) == "object"){
      elm = p_elm;
    } else {
      elm = document.getElementById(p_elm);
    }
    return parseInt(elm.offsetWidth);
  }

  this.getElementRight = getElementRight;
  function getElementRight(){
    return getElementLeft(p_elm) + getElementWidth(p_elm);
  }

  this.getElementTop = getElementTop;
  function getElementTop() {
    var y = 0;
    var elm;
    if(typeof(p_elm) == "object"){
      elm = p_elm;
    } else {
      elm = document.getElementById(p_elm);
    }
    while (elm != null) {
      y+= elm.offsetTop;
      elm = elm.offsetParent;
    }
    return parseInt(y);
  }

  this.getElementHeight = getElementHeight;
  function getElementHeight(){
    var elm;
    if(typeof(p_elm) == "object"){
      elm = p_elm;
    } else {
      elm = document.getElementById(p_elm);
    }
    
    var height=0;
    if(elm)
    	height = parseInt(elm.offsetHeight);
    	
	return height;
  }

  this.getElementBottom = getElementBottom;
  function getElementBottom(){
    return getElementTop(p_elm) + getElementHeight(p_elm);
  }
}

/*
Author: Deepak
Description : This method is use to submit action form.
*/
function submitAction(formRef) {
	// This line is used to fix NPE error on occuring on Payment Summary Page
	// When we are on "Show Discrepancy" page  in DEMO USER, click on Main and this time go to "Recon" 
	// and click on Plan on Payment Dashboard.
	if(formRef.method.value == "showHome")
		formRef.pageType.value = null;
	formRef.submit();
}

//This method is used to move between subTab(example between paymentDashboard,discrepancyDashboard)
function submitLink(methodName, menuName, pageType) {
    SavNSubmit(methodName, menuName, pageType, "BaseForm");
}
function SavNSubmit(methodName, menuName, pageType, formsName) {
	var formRef = document.forms [formsName];
	tempMenu = dwr.util.getValue("menuName");
	if(tempMenu =='beneDiscrpDetail') {
		formRef = document.forms ['DiscrepancyDetailForm'];
		formRef.action  ='dispatchAction.do';
	}
	var pageName = dwr.util.getValue("methodName");
	formRef.method.value = methodName;
	if ( menuName == 'beneficiary' || menuName == 'plan') {
		formRef.menuName.value = menuName;
	} 
	formRef.actionType.value = null;
	var tempPageType = dwr.util.getValue("pageType");
	formRef.pageType.value = pageType;

	saveUiContext(formRef, pageName, tempMenu, tempPageType);
}



//This method is used to move between subTab(example between troopDashboard,troopDetail)
function submitPdeTroopLink(methodName) {
	var formsName = 'PdeTroopForm'; 
	var formRef = document.forms [formsName];
	var pageName = dwr.util.getValue("methodName");
	formRef.method.value = methodName;
	formRef.actionType.value= null;
	saveUiContext(formRef, pageName, '', '');
}
//Recon Work Queue changes : start
function submitWorkQueueDiscLink(methodName) {
	
	/*var x = document.getElementById('btnGoGifP');
	//alert(x+x.className);
	var y = document.getElementById('btnGoGifD');*/
	
	var searchbutton = document.getElementById('butGoGif');
	searchbutton.style.display ='';
	//x.className = "tab";
	//alert(x.className);
	//y.className = "reconSelectedBtn";
	//alert(y.className);
	document.getElementById('exportButton').style.display ='';
	document.getElementById('workQueueDisc').style.display ='';
	document.getElementById('workQueueDiscDiv').style.display ='';
	
	
}
//Recon Demo-WorkQueue
//This method is to switch between tab in menu (e.g use to switching beweent Plan , Beneficiary ,Pde, Troop etc menus).
function switchTab(methodName, formsName, action, actionType, menuName, pageType) {   
	//alert(" values in switchTab--"+methodName+"::"+formsName+"::"+action+"::"+actionType+"::"+menuName+"::"+pageType);
	var tempMenu = dwr.util.getValue("menuName");
	//alert("1"+tempMenu);
	if(tempMenu =='beneDiscrpDetail')
		formsName = 'DiscrepancyDetailForm';
	var formRef = document.forms [formsName];
	//alert("2"+formRef);
	formRef.action = action;
	//alert("3"+action);
	if ( menuName == 'beneficiary' || menuName == 'plan') {
		formRef.menuName.value = menuName;
	}
	formRef.menuName.value = menuName;
	var tempPageType = dwr.util.getValue("pageType");
	//alert("4"+tempPageType);
	var pageName = dwr.util.getValue("methodName");
	//alert("5"+pageName);
	formRef.method.value = methodName;
	formRef.pageType.value = pageType;
	formRef.actionType.value= actionType;
	//alert(" values before submit--"+formRef+"::"+pageName+"::"+ tempMenu+"::"+ tempPageType);
	saveUiContext(formRef,pageName, tempMenu, tempPageType);
}

//This method is use when we click discrepany tab in menu.This method is call to get discreapncy Detail page.
function getDiscDetailTab(menuName, pageType){
	var formRef = document.forms ['BaseForm'];
	var pageName = dwr.util.getValue("methodName");	
	var tempPageType = dwr.util.getValue("pageType");
	formRef.action='discrepancyDetailAction.do';
	formRef.actionType.value = '';
	formRef.pageType.value = pageType;
	formRef.menuName.value = 'beneDiscrpDetail';
	saveUiContext(formRef,pageName, menuName, tempPageType);
}

//This method submit dispathAction.This method call when we do an new search though Go button.
function submitDispatchAction(action) {
	if( validateForm(false) == false)
		return false;
	var formRef = document.forms ['BaseForm'];
	var methodName = dwr.util.getValue("methodName");
	var menuName = formRef.menuName.value ;
	formRef.method.value = methodName;
	formRef.actionType.value = action;
	saveUiContext(formRef,methodName, menuName, '');
}

//Fix for IFOX-00406213 START
//This method submit dispathAction.This method call when we do an new search though Go button for the PDE search.
function submitDispatchActionPDE(action) {
	if( validateForm(false) == false)
		return false;
	var formRef = document.forms ['PdeTroopForm'];
	var methodName = dwr.util.getValue("methodName");
	var menuName = formRef.menuName.value ;
	formRef.method.value = methodName;
	formRef.actionType.value = action;
	saveUiContext(formRef,methodName, menuName, '');
}
//Fix for IFOX-00406213 END

//This method submit DiscrepancyDetailAction when we move from discreapncyDetail to beneficiary by clicking on hicNbr.
function submitHicNbrLink(hicNbr,rowId ){
	dwr.util.setValue(PLAN_SEARCH, dwr.util.getValue('planName_'+rowId)); //Added for IFOX-00431034 :: All-Plans in Discrepancy Drop down
	dwr.util.setValue(HIC_NBR, hicNbr);
	dwr.util.setValue(START_DATE,dwr.util.getValue('pymtEffDate_'+rowId));
	dwr.util.setValue(END_DATE,dwr.util.getValue('pymtEffDate_'+rowId));
	dwr.util.setValue('discCd','');
	
	switchTab('PaymentDashBoard', 'DiscrepancyDetailForm', 'dispatchAction.do', 'hicNbrSearch', 'beneficiary', '');
}
//Recon Work Queue changes : start
function submitDiscLink(hicNbr,rowId,planName ){
	var formRef = document.forms ['WorkQueueForm'];
	
	formRef.action='discrepancyDetailAction.do';
	formRef.actionType.value = "summaryPage";
	dwr.util.setValue(HIC_NBR, hicNbr);
	dwr.util.setValue(START_DATE,dwr.util.getValue('pymtEffDate_'+rowId));
	dwr.util.setValue(END_DATE,dwr.util.getValue('pymtEffDate_'+rowId));
	dwr.util.setValue('planName',planName);
	dwr.util.setValue('discCd',dwr.util.getValue('discrepancyCd_'+rowId));
	//dwr.util.setValue('discrepancyType',dwr.util.getValue('discrepancyStatus_'+rowId));
	dwr.util.setValue('discrepancyType',"NotClosed");
	
	var pageType = dwr.util.getValue("pageType");
	saveUiContext(formRef, 'DiscrepancySummary', 'plan',pageType);

	
}
assignTask = null;
function openAssignTask()
{
    var winWidth;
    var winHeight;
    var winLeft;
    var winTop;
    var link;

        if (screen.width > 800)
        {
            winWidth = 500;
            winHeight = 200;
            winTop = 7;
        }
        else
        if (screen.width > 640)
        {
            winWidth = 500;
            if (navigator.appName.indexOf("Netscape") == -1)
            {
                winTop = 5;
                winHeight = 200;
            }
            else
            {
                winHeight = 200;
                winTop = 1;
            }
        }
        else
        {
            winWidth = 500;
            winHeight = 200;
            winTop = 10;
        }

        winLeft = ((screen.width - 15) - winWidth) / 2;


            link = "/mss/jsp/Recon/jsp/workQueueSearch.jsp";

        //if (demo)
        //    link = "/mss/jsp/ReconDemoSrchAllDiscJsp.jsp";
        //else
        //    link = "/mss/jsp/ReconSrchAllDiscJsp.jsp?QA=" + qa;
            WaiverCodes = openEEMWindow("/workQueueAction.do?method=initializeAssign", "EEM","location=no,menubar=yes,scrollbars=yes,resizable=yes");

       // WaiverCodes = window.open(link, "Assign Task","location=no,menubar=no,scrollbars=yes,resizable=no,left=" + winLeft + ",top=" + winTop + ",width=" + winWidth + ",height=" + winHeight+",title ="+"Assign Tasks");
            
}
function openEEMWindow(addr, wname, wstat) {

	var wl = screen.width * 1/100; // % of the total screen width
    var wt = screen.height * 4/100; // % of the total screen height
    var ww = screen.width - (wl*2);
    var wh = screen.height - (wt*5);

    return window.open(addr, wname, wstat+",left=" + wl + ",top=" + wt + ",width=" + ww + ",height=" + wh);
}
function submitAssign(){
	
	alert(" Discrepancy Assigned Successfully");
	//var select = document.getElementsByName('SelectCheck');
	window.opener.doSetAll("assign");
	window.close();
	
}

/*
Author : deepak
Discription : This method is used to submit paymentDeshBoard.
*/
function submitPaymentDashboardAction(actionType,search,planName,year ,month) {
 	month = getMonthValue(month);
	var formRef = document.forms ['BaseForm'];
	var methodName = dwr.util.getValue("methodName");
	searchType = search ;
	globalFilterVO = filterVO;
	var fromDate = dwr.util.getValue(START_DATE);
	var toDate = dwr.util.getValue(END_DATE);
	if(searchType == 'year' ) {
		if(!isContain(fromDate,year))
			fromDate = '01/'+ year  ;
		if(!isContain(toDate,year)) 
			toDate = '12/' +year  ;
	} else if (searchType =='month' ) {
		fromDate = month +'/' +year  ;
		toDate =  month +'/' +year ;
	} 
	if(actionType == 'searchPlan') {
		planName = dwr.util.getValue(PLAN_SEARCH);
		
	}
	formRef.actionType.value = "search";
	formRef.method.value = actionType;
	dwr.util.setValue(PLAN_SEARCH,planName);
	formRef.fromDate.value = fromDate;
	formRef.toDate.value = toDate;
	formRef.searchType.value = searchType;
	tempMenu = dwr.util.getValue("menuName");
	// set partName 
	formRef.partName.value = "Both";
	saveUiContext(formRef,methodName,tempMenu, '');
}

//This method submit discrepancy Detail action.
function submitDiscrepancyDetailDetailAction(){
	if(validateForm(true) == false){
		return false;
	}
	var formRef = document.forms ['DiscrepancyDetailForm'];
	formRef.actionType.value = "search";
	var menuName = formRef.menuName.value ;
	saveUiContext(formRef,'DiscrepancyDetail', menuName, '');
}
//Recon Work Queue Changes : start 
function submitWorkQueueAction(){
	if(validateForm(true) == false){
		return false;
	}
	
	var formRef = document.forms ['WorkQueueForm'];
	formRef.actionType.value = "search";
	var menuName = formRef.menuName.value ;
	saveUiContext(formRef,'WorkQueue', menuName, '');
}
//Recon Work Queue Changes : end 
//This method show home page when we click home link.
function showHome(){
    top.sessType=1;
	var name = document.forms[0].name;
	var formRef = document.forms [name];
	if(name != 'BaseForm')
		formRef.action = "dispatchAction.do";
	
	var pageType = dwr.util.getValue("pageType");
	formRef.method.value = "showHome";
	var methodName = dwr.util.getValue("methodName");		
	menuName = formRef.menuName.value ;
	saveUiContext(formRef,methodName, menuName, pageType);
}



function addIntoUiContext(id) {
	uiContext[uiContext.length] = id;
}

/*
Author : deepak
Discription : This method is used to save ui context into session.
*/
function saveUiContext(formRef, pageName, menuName, pageType) {
	var id = document.getElementById("butGoGif");
	if(id !=null)
	useLoadingImage(document.getElementById("butGoGif"));
	document.body.className = 'wait';
	var dataTable = document.getElementById("dataTable");
	var trRows = dataTable.getElementsByTagName('div');
	var count = 0;
	var temp;
	var dataArray = new Array();

	if(pageName == PAGE_DISCREPANCY_SUMMARY  || PAGE_DISCREPANCY_DETAILS == pageName || PAGE_PROFILE_SEARCH == pageName || "workQueue" == pageName) {
		for(var i=0; i < trRows.length; i++) {
			temp = trRows[i].getAttribute("rowExpanded");
			if(null != temp && "" != temp && temp == "true"){
				addIntoUiContext(trRows[i].getAttribute("id")+',true');
			} else if(temp == "false") {
				addIntoUiContext(trRows[i].getAttribute("id")+',false');
			}
		}
	} else {
		for(var i=0; i < trRows.length; i++){
			temp = trRows[i].getAttribute("rowExpanded");
			if(null != temp && "" != temp && temp == "true"){
				addIntoUiContext(trRows[i].getAttribute("id"));
			}
		} 
	}
	if (pageName.substr(0,4)=="raps") {
	    if(formRef == null)
            generateExportedData(pageName);
	    return;
    }
	try {
		FacadeManager.saveUiContext(uiContext, pageName, menuName, pageType, {
					  			callback:function(data) {
						  				uiContext = new Array();
						   				if(formRef != null){
						   					
						   					submitAction (formRef);
						   				}
							   			else{
							   				//alert("in else");
							   				if(menuName=="workqueue")
							   					pageName = "workqueue";
							   				generateExportedData(pageName);
							   			}
						   			}});
	}catch(e) {
		showPopMessage("Error: "+e.message);
	}
}

/**
	This function is to submit discrepancy detail Action.
*/
function submitDiscrepancyDetailAction(discrepancyName,partName) {
	var formRef = document.forms ['BaseForm'];
	formRef.action='discrepancyDetailAction.do';
	formRef.actionType.value = "summaryPage";
	formRef.discCd.value = discrepancyName;
	formRef.partName.value = partName;
	var pageType = dwr.util.getValue("pageType");
//	formRef.pageType.value = "";
	saveUiContext(formRef, 'DiscrepancySummary', 'plan',pageType);
	//submitAction (formRef) ;
}
/*
Author : deepak
Discription : This method is used to save ui context into session.
*/
function submitTroopAction(action) {
	var methodName = dwr.util.getValue("methodName");
	var validFlag = methodName == 'troopDetail' ?  validateForm(true) : validateForm(false);
	if( validFlag == false)
		return false;
	var formRef = document.forms ["PdeTroopForm"];
	var menuName = formRef.menuName.value;
	formRef.method.value = methodName;
	formRef.actionType.value = action;
	saveUiContext(formRef, methodName, menuName);
}


/*
Function will return the HTML Element based on element Id or Name
First this will check with getElementById if element is null or undefined 
then it will try with getElementsByName method 
and will return the element object to calling method
*/
function getElement(eleName){
	var ele = document.getElementById(eleName);
	if(ele == null || ele == undefined)
		ele = document.getElementsByName(eleName)[0];

	if(ele == undefined)
		return null;
	return ele;
}

/*
Discription : function is used to Disabled/Eniable list of compbo-boxes 
with showing/hiding 'export/Print' or 'system alter' window
*/
function showHideDropDown(forDisable){
	
	var disabledCompboArr = new Array('planName', 'discrepancyType', 'discCd', 'pdeStatus', 'discrepancyStatus', 'paymentMonth', 'parameterCode', 'pbpId', 'segmentId', 'paymentYear', 'quarter');

	for(var i=0; i < disabledCompboArr.length;i++){
		var temp = getElement(disabledCompboArr[i]);
		if(temp != null){ // checking for element present
			if(forDisable){ // checking "is disabled request"
				var prevState = temp.getAttribute("disabled");
				temp.setAttribute("disabled", "disabled");
				temp.setAttribute("prevDisableState", (prevState == null) ? "" : prevState);
			} else {
				var prevState = temp.getAttribute("prevDisableState");
				if(prevState == null || prevState == "")
					temp.removeAttribute("disabled");
				else
					temp.setAttribute("disabled", prevState);
			}
		}
	}
}

/*
Author : Pradeep Palat
Description : This method returns the absolute position [left position, top position]  of the specified object.
Input : Object for which position are needed. 
*/
function findPosition(obj) {
	
	var curleft = curtop = 0;
	if (obj.offsetParent) {
		do {
			curleft += obj.offsetLeft;
			curtop += obj.offsetTop;
		} while (obj = obj.offsetParent);
	}
	return [curleft,curtop];
}


/*
Author : rakesh
Discription : This method is used to show Export / Print dialog box. 
Which takes a page name (from which export request comes)
*/
function showExportPrintDialog(){
	showCursorPointer();
	exportXY = findPosition(document.getElementById('exportPrintAnchor'));
	document.getElementById('pop_inner').style.display = "block";
	document.getElementById('pop_inner').style.top = exportXY[1]; //Overwrite the position top to match exportPrintAnchor
	document.getElementById('pop_container').style.display = "block";
	document.getElementById('pop_container').scrollIntoView();
	

	dwr.util.setValue('pageRangeRadio',"Current");
	//dwr.util.setValue('pageExportRadio',"false");

	// disable drop down on black transperent div on export/print
	showHideDropDown(true);

	// Activate 'All Pages' options only for Discrepancy page.
	var methodName = dwr.util.getValue("methodName");
	var menuName = dwr.util.getValue("menuName")
	//alert(menuName);
	if(PAGE_DISCREPANCY_DETAILS == methodName || 
	   PAGE_TROOP_DETAIL == methodName || PAGE_PDE_EVENT_DETAIL == methodName || "pdeErrDetail" == methodName ||
       PAGE_PROFILE_SEARCH == methodName || PAGE_PROFILE_SEARCH == methodName || 
	   "rapsDetail" == methodName || "rapsClaimsDetail" == methodName || "rapsErrors" == methodName
	    || menuName == "workqueue"){
		document.getElementsByName("pageRangeRadio")[1].removeAttribute("disabled");
	}
}

function setImageDisable(){
//Showing disable images during pdf/csv generation process.
	document.getElementById('exportPdf').innerHTML= '<INPUT type="image" src="/mss/jsp/Recon/images/PDF_Disable.jpg" value="PDF" style = "cursor:wait"> ';	
	document.getElementById('exportPrint').innerHTML= '<INPUT type="image" src="/mss/jsp/Recon/images/Print_Disable.jpg" value="Print" style = "cursor:wait"> ';	
	var csv = document.getElementById('exportCsv');
	if (csv != null && csv != undefined)
	    csv.innerHTML= '<INPUT type="image" src="/mss/jsp/Recon/images/Excel_Disable.jpg" value="CSV" style = "cursor:wait">';	

}

function showCursorPointer(){
	//Showing disable images during pdf/csv generation process.
	if(document.getElementById('exportPdf')!= undefined){
		document.getElementById('exportPdf').style.cursor = "pointer";
	}
	if(document.getElementById('exportPdf')!= undefined){	
		document.getElementById('exportPrint').style.cursor = "pointer";
	}
		var csv = document.getElementById('exportCsv');
		if (csv != null && csv != undefined)
			csv.style.cursor = "pointer";	

	}

/*
Author : rakesh
Discription : This method is called by hitting "export PDF / print " button from EXPORT / PRINT dialog
*/
function generateExportedData(pageName){
	//alert("1 pagneame-"+pageName);
	var exportPrintDiv = document.getElementById('exportPrintDIV');
	var uiContextRange = dwr.util.getValue('pageRangeRadio');	
	if(uiContextRange == false){
		uiContextRange = "ALL";
	}
	else if (uiContextRange == true){
		uiContextRange = "Current";

	}
	//var uiContextRange = document.getElementsByName("pageRangeRadio")[1].value;
	useLoadingImage(document.getElementById('exportTableHeader'),"/mss/jsp/Recon/images/Loader.gif");
	if(uiContextRange=="ALL"){
		if(PAGE_DISCREPANCY_DETAILS == pageName  ||
		   PAGE_PDE_EVENT_DETAIL == pageName || PAGE_TROOP_DETAIL == pageName || "pdeErrDetail" == pageName ||
		   pageName.substr(0,4) == "raps"){
			isExportRequestValid(pageName);
			return;
		}
	}
	if(isForPrint == true || isForPrint == "true" ) {
	    if (pageName.substr(0,4) == "raps")
	        newPrintPage(pageName, uiContextRange);
	    else
		printGeneratedData(pageName, uiContextRange);
	} else {
		exportGeneratedData(pageName, uiContextRange);
	}
}

/*
Author : hemant
Discription : This method is called to know that in case of export for 'ALL' option 
export must be produced or a msg will be shown 	 
*/
function isExportRequestValid(pageName){
	var menuName = dwr.util.getValue("menuName");
	
	try{	
		if(PAGE_DISCREPANCY_DETAILS == pageName){
			var pageType = dwr.util.getValue("pageType");
			FacadeManager.isExportDiscDetailRequestValid(menuName,pageType,{
							  			callback:function(data) {
							   			CBisExportRequestValid(data,pageName);}
							  			});
		}else if(PAGE_PDE_EVENT_DETAIL == pageName)
			FacadeManager.isExportPdeDetailRequestValid({
							  			callback:function(data) {
							   			CBisExportRequestValid(data,pageName);}
							  			});
		else if(PAGE_TROOP_DETAIL == pageName)
			FacadeManager.isExportTroopDetailRequestValid({
							  			callback:function(data) {
							   			CBisExportRequestValid(data,pageName);}
							  			});	
		else 
			FacadeManager.isExportRequestValid(pageName,{
							  			callback:function(data) {
							   			CBisExportRequestValid(data,pageName);}
							  			});	
	}catch(e){
			showPopMessage("Error: "+e.message);
	}
}

/*
Author : hemant
Discription : callback of isExportRequestValid, shows msg or go for Export
*/
function CBisExportRequestValid(data,pageName){
	var uiContextRange="ALL";
	if(data=="TRUE"){
		if(isForPrint == true || isForPrint == "TRUE" ){
	        if (pageName.substr(0,4) == "raps")
    		    newPrintPage(pageName, uiContextRange);
	        else
			    printGeneratedData(pageName, uiContextRange);
		} else 
			exportGeneratedData(pageName ,uiContextRange);	
	}else if(data == MSG_NO_DATA_FOUND){
		showPopMessage(MSG_NO_DATA_FOUND);
	}else{
		showPopMessage("Current search crossing the limit of "+data+" rows, please change search criteria to reduce it.");
	}
}

/*
Author : Rakesh
Discription : Used to generate Print CSV for all pages.
*/
function exportGeneratedData(pageName, uiContextRange) {
	var menuName = dwr.util.getValue("menuName");
	var pageType = dwr.util.getValue("pageType");
	var partName = dwr.util.getValue("partName");
	var parameterMap =  null;
	//alert( "pageName-"+pageName);
	if("true" == partName || true == partName) {
		partName = isBorwserIE() ? document.getElementById("partName").value : document.getElementsByName("partName")[0].value;
	}
	
	var searchType = "";
	
	if(pageName == PAGE_DISCREPANCY_SUMMARY || pageName == PAGE_BENEFICIARY_PYMT_DETAILS || pageName == PAGE_PAYMENT_SUMMARY) {
		searchType = dwr.util.getValue("searchType");
	}

	if((POPUP_DISEASE == pageName)||(POPUP_PYMT_DETAIL == pageName)||POPUP_RECONCILATION == pageName){
		if(POPUP_DISEASE == pageName){
			var pbpId = dwr.util.getValue("pbpId");
			var hicNbr = dwr.util.getValue("hicNbr");
			var cmsValue = dwr.util.getValue("cmsValue");
			var fromDate = dwr.util.getValue("fromDate");
			var pageType =  dwr.util.getValue("pageType");
			var planName = dwr.util.getValue("planName");
			var planValue = dwr.util.getValue("planValue");
			parameterMap =  {pbpId:pbpId,hicNbr:hicNbr, cmsValue:cmsValue, fromDate:fromDate, pageType:pageType, planName:planName, planValue:planValue };
		} else if(POPUP_PYMT_DETAIL == pageName){
			
			var seqNbr = dwr.util.getValue("seqNbr");
			var isPopUp = dwr.util.getValue("isPopUp");
			var fromDate = dwr.util.getValue("fromDate");
			var pageType = dwr.util.getValue("pageType");
			var pymtType = dwr.util.getValue("pymtType");
			var applyDate = dwr.util.getValue("applyDate");
			parameterMap =  {seqNbr:seqNbr,isPopUp:isPopUp, fromDate:fromDate, pageType:pageType, pymtType:pymtType, applyDate:applyDate};		
		} else if(POPUP_RECONCILATION == pageName){
			var fromDate = dwr.util.getValue("fromDate");
			var pageType = dwr.util.getValue("pageType");
			var hicNbr = dwr.util.getValue("hicNbr");
			var planName = dwr.util.getValue("planName");
			parameterMap =  {fromDate:fromDate,pageType:pageType, hicNbr:hicNbr, planName:planName};		
		}
	}
	try {
		//alert(pageName);
		FacadeManager.createExport(pageName, exportType, uiContextRange, menuName, searchType, pageType, partName ,parameterMap , uiContext.join("|"), {
				  			callback:function(data) {
        uiContext = new Array(); //reset it in case of next request
				   			var path = "/downloadAction.do?fileName="+data[0]+"&exportType="+exportType + "&tableName="+pageName+ "&exportFileName="+data[1];
							//location.href = path;
							var downloadIFrame = document.getElementById("downloadIFrame");
							if(! downloadIFrame){
								var downloadIFrame = document.createElement("iframe");
								//SPECIFY A DUMMY SOURCE FOR IFRAME
								downloadIFrame.src = "/blank.jsp"; 
								downloadIFrame.setAttribute("id", "downloadIFrame");
								document.body.appendChild(downloadIFrame);
								downloadIFrame.style.display="none";	
							}
							downloadIFrame.src = path;
							
							//Showing anable images after pdf/csv get generated .							
							document.getElementById('exportPdf').innerHTML= '<INPUT  type="button" class="inputButton" value="PDF" onclick="setImageDisable();exportPrintData(\'PDF\');">';	
							document.getElementById('exportPrint').innerHTML= '<INPUT type="button" class="inputButton"  value="Print" onclick="exportPrintData(\'Print\');">';	
							var csv = document.getElementById('exportCsv');
							if (csv != null && csv != undefined)
                                csv.innerHTML= '<INPUT type="button" class="inputButton" value="CSV" onclick="setImageDisable();exportPrintData(\'CSV\');">';	
							}
							});
							
	} catch(e) {
		showPopMessage("Error: "+e.message);
	}

	//location.href = path;
}

function printGeneratedData(pageName, uiContextRange){
	var webUrl;
	var menuName = dwr.util.getValue("menuName");
	var pageType = dwr.util.getValue("pageType");
	var partName = dwr.util.getValue("partName");
	
	if("true" == partName || true == partName) {
		partName = isBorwserIE() ? document.getElementById("partName").value : document.getElementsByName("partName")[0].value;
	}

    if (menuName=="partDForeCast")
		webUrl = "/reinsuranceAction.do?print=true&uiContextRange="+uiContextRange +"&menuName="+menuName+"&method="+pageName;
	else if(PAGE_DISCREPANCY_DETAILS == pageName)
		webUrl = "/discrepancyDetailAction.do?method=" + pageName + "&print=true&uiContextRange="+uiContextRange +"&menuName="+menuName+"&pageType="+pageType+"&partName="+partName;
	else if(PAGE_PDE_DASHBOARD == pageName || PAGE_TROOP_DASHBOARD == pageName|| PAGE_PDE_DETAIL == pageName || PAGE_TROOP_DETAIL == pageName
	    || "pdeErrDB"==pageName || "pdeErrCodes"==pageName || "pdeErrDetail"==pageName)
		webUrl = "/pdeTroopAction.do?method=" + pageName + "&print=true&uiContextRange="+uiContextRange +"&menuName="+menuName;
	else if(PAGE_PROFILE_SEARCH == pageName)
		webUrl = "/searchProfileAction.do?method=" + pageName + "&print=true&uiContextRange="+uiContextRange +"&menuName="+menuName;
	else
		webUrl = "/dispatchAction.do?method=" + pageName + "&print=true&uiContextRange="+uiContextRange 
					+"&menuName="+menuName + "&pageType="+pageType;
	
	if((PAGE_PAYMENT_SUMMARY == pageName && PAYMENT_DETAIL == menuName) || POPUP_DISEASE == pageName || POPUP_PYMT_DETAIL == pageName || POPUP_RECONCILATION == pageName){
		var winTop = window.opener.top;
		if(POPUP_DISEASE == pageName){
			var hicNbr = dwr.util.getValue("hicNbr");
			var pbpId = dwr.util.getValue("pbpId");
			var cmsValue = dwr.util.getValue("cmsValue");
			var fromDate = dwr.util.getValue("fromDate");
			var partName = dwr.util.getValue("partName");
			var pageType = dwr.util.getValue("pageType");
			var planName = dwr.util.getValue("planName");
			var planValue = dwr.util.getValue("planValue");
			
			webUrl =  webUrl+"&cmsValue="+cmsValue+"&planValue="+planValue
					+"&hicNbr="+hicNbr+"&fromDate="+fromDate+"&partName="+partName+"&pbpId="+pbpId+"&pageType="+pageType+"&planName="+planName;

			if(!winTop.isOpen)
				winTop = window.opener.opener.top;

		}else if(POPUP_PYMT_DETAIL == pageName){
			var seqNbr = dwr.util.getValue("seqNbr");
			var isPopUp = dwr.util.getValue("isPopUp");
			var pymtType = dwr.util.getValue("pymtType");
			var fromDate = dwr.util.getValue("fromDate");
			var pageType = dwr.util.getValue("pageType");

			webUrl =  webUrl+"&seqNbr="+seqNbr+"&pymtType="+pymtType
					+"&isPopUp="+isPopUp+"&fromDate="+fromDate+"&pageType="+pageType;
			if(isPopUp == "true")
				winTop = window.opener.opener.top;

		}else if(POPUP_RECONCILATION == pageName){
			var hicNbr = dwr.util.getValue("hicNbr");
			var fromDate = dwr.util.getValue("fromDate");
			var partName = dwr.util.getValue("partName");
			var pageType = dwr.util.getValue("pageType");
			var planName = dwr.util.getValue("planName");
			
			webUrl =  webUrl+"&fromDate="+fromDate+"&partName="+partName+"&pageType="+pageType+"&hicNbr="+hicNbr+"&planName="+planName;;
		}
		if(winTop.isOpen(winTop.printWin))
			winTop.printWin.close();
		
		var winProperties = "height=500,width=900,resizable=yes,scrollbars=yes,location=no,menubar=no,toolbar=no," + getScreenTopLeft(900);
		winTop.printWin = window.open(webUrl, "printWin", winProperties);
		if(winTop.printWin) 	
			winTop.printWin.focus();
	}else{
		if(isOpen(top.printWin))
			top.printWin.close();
		
		var winProperties = "height=500,width=900,resizable=yes,scrollbars=yes,location=no,menubar=no,toolbar=no," + getScreenTopLeft(900);
		top.printWin = window.open(webUrl, "printWin", winProperties);

		if(top.printWin)
			top.printWin.focus();
	}
}

var isForPrint=false;
var exportType;
function exportPrintData(flag){
	if(isAjaxProcess)
		return false;

	var methodName = dwr.util.getValue("methodName");		
	var menuName = dwr.util.getValue("menuName");
	if(menuName=="workqueue")
		methodName ="workqueue";
	exportType=flag;
	if(flag=="Print")
		isForPrint = true;
	else
		isForPrint = false;
	if(EXPORT_NO_DATA_FOUND!="TRUE"){
	
		if(POPUP_RECONCILATION == methodName){
				if(document.getElementById('exportPartC')==null && document.getElementById('exportPartD')==null){
				showPopMessage(MSG_NO_DATA_FOUND);
				return;
			}
		}
		else if(PAGE_PDE_EVENT_DETAIL == methodName||PAGE_TROOP_DETAIL == methodName||POPUP_DISEASE == methodName||POPUP_PYMT_DETAIL == methodName){
			if(document.getElementById('noExport')!=null){
				showPopMessage(MSG_NO_DATA_FOUND);
				return;
			}
		}else if(PAGE_DISCREPANCY_DETAILS == methodName){
			if(dwr.util.getValue("partName")=="Both"){
				if(document.getElementById('noExportPartC')!=null && document.getElementById('noExportPartD')!=null){
					showPopMessage(MSG_NO_DATA_FOUND);
					return;
				}
			}else if(dwr.util.getValue("partName")=="Part C"){
				if(document.getElementById('noExportPartC')!=null){
					showPopMessage(MSG_NO_DATA_FOUND);
					return;
				}
			}else if(dwr.util.getValue("partName")=="Part D"){
				if(document.getElementById('noExportPartD')!=null){
					showPopMessage(MSG_NO_DATA_FOUND);
					return;
				}
			}
		}else if(PAGE_PAYMENT_SUMMARY == methodName){
			if(menuName=="beneficiary"){
				if( document.getElementById('noExportPartC')!=null && document.getElementById('noExportPartD')!=null && document.getElementById('noExportUnApplied')!=null){
					showPopMessage(MSG_NO_DATA_FOUND);
					return;
				}
			}else{
				if( document.getElementById('noExportPartC')!=null && document.getElementById('noExportPartD')!=null){
					showPopMessage(MSG_NO_DATA_FOUND);
					return;
				}
			}
		}else if(PAGE_DISCREPANCY_SUMMARY == methodName){
			if( document.getElementById('noExportPartC')!=null && document.getElementById('noExportPartD')!=null){
				showPopMessage(MSG_NO_DATA_FOUND);
				return;
			}
		}else if(PAGE_PROFILE_SEARCH == methodName){
			if(document.getElementById('noExportPartC')!=null){
				showPopMessage(MSG_NO_DATA_FOUND);
				return;
			}else if(document.getElementById('noExportPartD')!=null && document.getElementById('noExportPartDPbp')!=null){
				showPopMessage(MSG_NO_DATA_FOUND);
				return;
			}
		}else{
			if(document.getElementById('noExport')!=null){
			showPopMessage(MSG_NO_DATA_FOUND);
			return;
			}
		}
	
	}
	if(document.getElementById('noSearchCriteria')!=null){
			showPopMessage(MSG_NO_CRITERIA_AVAL);
			return;
	}		
	var pageType = dwr.util.getValue('pageType');
	var uiContextRange = dwr.util.getValue('pageRangeRadio');
	if(uiContextRange == false){
		uiContextRange = "ALL";
	}
	else if (uiContextRange == true){
		uiContextRange = "Current";

	}
	/*alert(" beforr changes--"+ uiContextRange);
	if(uiContextRange== false){
		alert(" before generated --"+uiContextRange);
		var uiContextRange = document.getElementsByName("pageRangeRadio");
		alert("values--"+uiContextRange[0].value+ " "+uiContextRange[1].value);
		uiContextRange = uiContextRange[1].value;
		}*/
	if( uiContextRange=="ALL" ||(PAGE_PAYMENT_SUMMARY == methodName && PAYMENT_DETAIL == menuName) || POPUP_DISEASE == methodName || POPUP_PYMT_DETAIL == methodName || POPUP_RECONCILATION == methodName ){
		generateExportedData(methodName);
	}else{
		saveUiContext(null, methodName, menuName, pageType);
	}
}




/*
Author : Deepak
Discreption : This method submit action to find discrepancy dashboard.
*/
function submitDiscrepancyDashBoardAction(actionType,partName,search,discrepancyType,rollupId,year ,month) {
	month = getMonthValue(month);
	var formRef = document.forms ['BaseForm'];
	var pageName = dwr.util.getValue("methodName");
	var menuName = dwr.util.getValue("menuName");

	searchType = search ;
	globalFilterVO = filterVO;
	var fromDate = dwr.util.getValue(START_DATE);
	var toDate = dwr.util.getValue(END_DATE);
	if(searchType =='year' ) {
		if(!isContain(fromDate,year))
			fromDate = '01/'+ year  ;
		if(!isContain(toDate,year)) 
			toDate = '12/' +year  ;
	
	//	fromDate = '01/'+ year  ;
		//toDate = '12/' +year  ;
	} else if (searchType =='month' ) {
		fromDate = month +'/' +year  ;
		toDate =  month +'/' +year ;
	} 
	if(actionType == 'searchPlan') {
		rollupId = dwr.util.getValue(PLAN_SEARCH);
	}
	formRef.actionType.value = "searchDiscrepancy" ;
	formRef.menuName.value = menuName;
	if( menuName == "beneficiary"){
		formRef.action='discrepancyDetailAction.do';
		formRef.actionType.value = 'search';
		formRef.menuName.value = 'beneDiscrpDetail';
	}
	
	formRef.method.value = actionType;
	dwr.util.setValue(PLAN_SEARCH,rollupId);
	formRef.fromDate.value = fromDate;
	formRef.partName.value = partName;
	formRef.discrepancyType.value = discrepancyType;
	formRef.toDate.value = toDate;
	formRef.searchType.value = searchType;
	saveUiContext(formRef,pageName,menuName);
}

/*
Author : deepak
Discription : This method is used to submit troop DeshBoard.
*/
function submitTroopDashBoardAction(actionType, search, planName, year, month) {
	if(validateForm(false) == false)
		return false; //IFOX-00419340 - Issue - 85 -  Medicaid ID is mandatory
 	month = getMonthValue(month);
	var formRef = document.forms ['PdeTroopForm'];
	var methodName = dwr.util.getValue("methodName");
	searchType = search ;
	globalFilterVO = filterVO;
	var fromDate = dwr.util.getValue(START_DATE);
	var toDate = dwr.util.getValue(END_DATE);
	
	if(searchType == 'year' ) {
		if(!isContain(fromDate, year))
			fromDate = '01/'+ year  ;
		if(!isContain(toDate, year)) 
			toDate = '12/' +year  ;
	} else if (searchType =='month' ) {
		fromDate = month +'/' +year  ;
		toDate =  month +'/' +year ;
	} 
	if(actionType == 'searchPlan') {
		planName = dwr.util.getValue(PLAN_SEARCH);
	}
	formRef.actionType.value = "search";
	formRef.method.value = actionType;
	dwr.util.setValue(PLAN_SEARCH, planName);
	formRef.fromDate.value = fromDate;
	formRef.toDate.value = toDate;
	formRef.searchType.value = searchType;
	tempMenu = 	dwr.util.getValue("menuName");
	saveUiContext(formRef,methodName,tempMenu);
}


/**
	This function is use to apply class on all td in  an row.
*/
/*
function applyClass(className,rowId) {
	var trRow = document.getElementById(rowId);
	if(trRow != null) {
		trRow.className = className;
		var tdRows = trRow.getElementsByTagName("td");
		var i;
		for(i=0; i < tdRows.length; i++){
			tdRows[i].setAttribute("className", className);
		}
	}
}
*/

/**
Author : Alex Levin
This method is used to navigate within the LatestNews container.	
*/
function processAjax(url) {

	if (window.ActiveXObject) { // IE
		req = new ActiveXObject("Microsoft.XMLHTTP");
		if (req) {
			req.onreadystatechange = targetDiv;
			req.open("GET", url, true);
			req.send();
		}
	}
	
	else if (window.XMLHttpRequest) { // Non-IE browsers
		req = new XMLHttpRequest();
		req.onreadystatechange = targetDiv;
		try {
			req.open("GET", url, true);
		} catch (e) {
			alert(e);
		}

		req.send(null);

	}
}

function targetDiv() {
	if (req.readyState == 4) { // Complete
		if (req.status == 200) { // OK response
			document.getElementById("MyDivName").innerHTML = req.responseText;
		} else {
			alert("Problem: " + req.statusText);
		}
	}
}

/*
author: Hemant
Discription : set the top and left for export div and msg div position
*/

function setTopAndLeftForExportDivOrMsgDiv(){
	var x = GetWidth();
	var y = GetHeight();
	exportDivLeft = (x/2 - 150);
	exportDivTop = (y/2 - 68);
	document.getElementById('pop_container').style.height='100%';
	document.getElementById('pop_container').style.width='100%';
	document.getElementById('pop_inner').style.left=exportDivLeft;
	document.getElementById('msgPopInner').style.left=exportDivLeft;
}

/*
author: Hemant
Discription : Return the width of the current window
*/
function GetWidth()
{
        var x = 0;
        if (self.innerHeight)
        	x = self.innerWidth;
        else if (document.documentElement && document.documentElement.clientHeight)
       		x = document.documentElement.clientWidth;
        else if (document.body)
            x = document.body.clientWidth;
        return x;
}

/*
author: Hemant
Discription : Return the height of the current window
*/
function GetHeight()
{
        var y = 0;
        if (self.innerHeight)
                y = self.innerHeight;
        else if (document.documentElement && document.documentElement.clientHeight)
                y = document.documentElement.clientHeight;
        else if (document.body)
                y = document.body.clientHeight;
        return y;
}

/*
Discription : will return LEFT & TOP cordinate for PopUp window
*/
function getScreenTopLeft(winWidth){
	var winTop = 6;
	var winLeft = 10;

	if(screen){
	    if (screen.width > 800) {
	        winTop = 25;
	    } else if (screen.width > 640) {
	        winTop = 1;
	    } else {
	        winTop = 10;
	    }
	    winLeft = ((screen.width - 15) - winWidth) / 2;
    }

    return "left=" + winLeft + ",top=" + winTop;
}

function isBorwserIE(){	
	return navigator.appName =="Microsoft Internet Explorer" ? true : false; 
}

function newPrintPage(pageName, uiContextRange){
        var webUrl = "/printAction.do?method=" + pageName + "&print=true&uiContext=" +
		uiContext.join("|") + "&pageName=" + pageName + "&uiContextRange="+uiContextRange;
        uiContext = new Array(); //reset it in case of next request
		var winTop = window.opener.top;
		//if(winTop.isOpen(winTop.printWin))
		//	winTop.printWin.close();
		
		var winProperties = "height=500,width=900,resizable=yes,scrollbars=yes,location=no,menubar=no,toolbar=no," + getScreenTopLeft(900);
		winTop.printWin = window.open(webUrl, "printWin", winProperties);
		if(winTop.printWin) 	
			winTop.printWin.focus();
}

//Added for IFOX-00428245 :: START
function eventCalendar(popUpwin){
	var winWidth=500;
	var winHeight=300;
	var winLeft = ((screen.width - 15) - winWidth) / 2;
	var winTop = ((screen.width - 15) - winWidth) / 3;

	if(popUpwin == 'close') {
		if(top.evntCalWindow)
		top.evntCalWindow.close();		
	}	
	else{
       top.evntCalWindow=window.open("/mss/jsp/Recon/jsp/eventCalendar.jsp", "Event Calendar", "location=no,menubar=no,scrollbars=no,resizable=yes,left=" + winLeft + ",top=" + winTop + ",width=" + winWidth + ",height=" + winHeight);
	}
	if(top.evntCalWindow) {
       top.evntCalWindow.focus();
    }
}
// Added for IFOX-00428245 :: END

//M360 lookup from Recon : IFOX-00428244-start
var eemWin = null;
function lookUpM360(val) {
	
	if(val == 'close') {
		if(top.eemWin)
		top.eemWin.close();		
	}
	else{
		if(val=='disc')
			val = dwr.util.getValue("hicNumber");
	
         top.eemWin =  openEEMWindow("/eemAction.do?method=switchMenu&menu=EEMM&medId="+val, "EEM","location=no,menubar=yes,scrollbars=yes,resizable=yes");
         top.eemWin.focus();
	}
}
//M360 lookup from Recon : IFOX-00428244-end
