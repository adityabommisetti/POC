// EventCalendar.js

var currentMonth="";
var currentYear="";
var firstEventMonth;
var lastEventMonth;

/*
author: hemant
description: this function returns true if a valid date 
*/
function isValidDate(mm,dd,yy){
	var dateObj=new Date(yy,mm-1,dd);
	if((dateObj.getMonth()+1!=mm)||(dateObj.getDate()!=dd)||(dateObj.getFullYear()!=yy))
		return false;
	else
		return true;
}

/*
author: hemant
description: this method returns true if an events exists on that day
*/
function isEventExists(day,data){
	var retValue=false;
	var medicareEventListVO={calendarDate:null,active:null,itemDescription:null};
	for(var i=0;i<data.length;i++){
		medicareEventListVO=data[i];
		var date=medicareEventListVO.calendarDate;
		if(parseInt(date.substr(6,2),10)==day)
			retValue=true;	
		}	
	return retValue;
}

/*
author: hemant
description: this method checks action validity and calls displayEventCalendar(action),if action is valid.
			if cuurent month is last event month and action is 'last',then action is invalid, so method just returns.   
*/
function checkActionValidityAndDisplayEventCalendar(action){
	var proFirstEventMonth;
	var proLastEventMonth;
	if(firstEventMonth==null || lastEventMonth==null)
		return;

	var currentEventMonth=currentYear+currentMonth;		
	if(action=="last"){
		if(currentMonth!="12")
			proLastEventMonth = currentYear+"12";
		else	
			proLastEventMonth = (parseInt(currentYear)+1)+"12";
	
		if(parseInt(proLastEventMonth)>parseInt(lastEventMonth))
			proLastEventMonth = lastEventMonth;
		
		if(currentEventMonth==lastEventMonth)
			return;
		else{
			currentYear=proLastEventMonth.substr(0,4);
			currentMonth=proLastEventMonth.substr(4,2);
			displayEventCalendar("last");
		}
	}else if(action=="first"){
		if(currentMonth!="01")
			proFirstEventMonth = currentYear+"01";
		else	
			proFirstEventMonth = (parseInt(currentYear)-1)+"01";

		if(parseInt(proFirstEventMonth)<parseInt(firstEventMonth))
			proFirstEventMonth = firstEventMonth;
		
		if(currentEventMonth==firstEventMonth)
			return;
		else{
			currentYear=proFirstEventMonth.substr(0,4);
			currentMonth=proFirstEventMonth.substr(4,2);
			displayEventCalendar("first");
		}
	}else if(action=="next"){
		if(currentEventMonth==lastEventMonth)
			return;
		else
			displayEventCalendar("next")
	}else if(action=="prev"){
		if(currentEventMonth==firstEventMonth)
			return;
		else
			displayEventCalendar("prev")
	}
}

/*
author: hemant
description: This method gets the current date of the server
*/
function getCurrentDate(){
	try{
		FacadeManager.getCurrentDate(CBgetCurrentDate);
	}catch(e){
		showPopMessage("Error: "+e.message);
	}
}

/*
author: hemant
description: callback of getCurrentDate()
*/
function CBgetCurrentDate(data){
	var currDate=data;
	if(currDate!=null){
		currentYear=currDate.substr(0,4);
		currentMonth=currDate.substr(4,2);
		displayEventCalendar("current");
	}
}

/*
author: hemant
description: this method calls displayEventCalendar() of FacadeManager to get events
*/
function displayEventCalendar(action){
	try{
		FacadeManager.getMedicareEventList(currentMonth,currentYear,action, CBgetMedicareEventList);
	}catch(e){
		showPopMessage("Error: "+e.message);
	}
}
/*
author: hemant
description: this method writes tooltipdivs to for displaying event tooltips
*/
function writeTooltipDivs(data){
	var medicareEventListVO={calendarDate:null,active:null,itemDescription:null};	
		var divHtml="";
		for(var day=1;day<=31;day++){
				if(isEventExists(day,data)){
					divHtml+='<div id="'+day+'" class="xstooltip">';
					if(isBorwserIE())
						divHtml+='<ul style="margin:0px 0px 0px 17px">';
					else
						divHtml+='<ul style="margin:0px 0px 0px -25px">';
					 
					for(var i=0;i<data.length;i++){
						medicareEventListVO=data[i];	
						var date=medicareEventListVO.calendarDate;
						if(parseInt(date.substr(6,2),10)==day){
							divHtml+='<li>'+medicareEventListVO.itemDescription+'</li>';
						}					
					}
					divHtml+='</ul></div>'
				}
		}	
	document.getElementById("tooltip").innerHTML=divHtml;	
}

/*
author: hemant
description: callback of ajax call to FacadeManager.getMedicareEventListVO()
*/
function CBgetMedicareEventList(data){
	var medicareEventVOList={firstDate:null,lastDate:null,eventVOArray:null};
	medicareEventVOList=data;
		
	if(medicareEventVOList!=null){
		if(medicareEventVOList.firstDate!=null && medicareEventVOList.lastDate!=null ){
			if(medicareEventVOList.firstDate!="" && medicareEventVOList.lastDate!=""){
			        firstEventMonth=medicareEventVOList.firstDate;
	 				lastEventMonth=medicareEventVOList.lastDate;
			}	
		}
	}
//Modified for IFOX-00428245
	var divHtml='<table width="100%" height="30"  border="0" align="center" cellpadding="0" cellspacing="0">';
	divHtml+='<tr>';
	divHtml+='<td width="9%">&nbsp;</td>';
	divHtml+='<td width="1%" align="center"><img src="/mss/jsp/Recon/images/Arrow_Year1.gif" width="12" height="10" style="cursor:pointer" onclick=\' checkActionValidityAndDisplayEventCalendar("first")\'></td>';
divHtml+='<td id="first" width="8%">&nbsp;</td>';
	divHtml+='<td width="1%" align="center"><img src="/mss/jsp/Recon/images/Arrow_Month1.gif" width="12" height="10" style="cursor:pointer" onclick=\' checkActionValidityAndDisplayEventCalendar("prev")\'></td>';
divHtml+='<td id="previous" width="5%">&nbsp;</td>';
	divHtml+='<td align="center" class="headbig"><div id="monthYear">&nbsp;</div></td>';
divHtml+='<td width="5%">&nbsp;</td>';
	divHtml+='<td width="1%" align="center"><img src="/mss/jsp/Recon/images/Arrow_Month2.gif" width="12" height="10" style="cursor:pointer" onclick=\' checkActionValidityAndDisplayEventCalendar("next")\'></td>';
divHtml+='<td id="next" width="8%">&nbsp;</td>';
	divHtml+='<td width="1%" align="center"><img src="/mss/jsp/Recon/images/Arrow_Year2.gif" width="12" height="10" style="cursor:pointer" onclick=\' checkActionValidityAndDisplayEventCalendar("last")\'></td>';
divHtml+='<td id="last" width="9%">&nbsp;</td>';
	divHtml+='</tr>';
	divHtml+='</table>';
	document.getElementById("browsingImages").innerHTML=divHtml;

	if(medicareEventVOList!=null && medicareEventVOList.eventVOArray!=null){
		writeTooltipDivs(medicareEventVOList.eventVOArray);
		var date=medicareEventVOList.eventVOArray[0].calendarDate;
		currentYear=date.substr(0,4);
		currentMonth=date.substr(4,2);
	}			
	dwr.util.setValue("monthYear",getMonthName(currentMonth)+"     "+currentYear);
		
	var divHtml='<table width="100%"  border="1" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF" style="border-style: solid">';
	divHtml+='<tr>';
    divHtml+='<td height="31" align="center" background="/mss/jsp/Recon/images/bg_calendar1.jpg" class="headBigBorder">S</td>';
	divHtml+='<td align="center" background="/mss/jsp/Recon/images/bg_calendar1.jpg" class="headBigBorder">M</td>';
	divHtml+='<td align="center" background="/mss/jsp/Recon/images/bg_calendar1.jpg" class="headBigBorder">T</td>';
	divHtml+='<td align="center" background="/mss/jsp/Recon/images/bg_calendar1.jpg" class="headBigBorder">W</td>';
	divHtml+='<td align="center" background="/mss/jsp/Recon/images/bg_calendar1.jpg" class="headBigBorder">T</td>';
	divHtml+='<td align="center" background="/mss/jsp/Recon/images/bg_calendar1.jpg" class="headBigBorder">F</td>';      
	divHtml+='<td align="center" background="/mss/jsp/Recon/images/bg_calendar1.jpg" class="headBigBorder">S</td>';      
	divHtml+='</tr>';      

	var newDate=new Date();
	newDate.setYear(parseInt(currentYear,10));
	newDate.setMonth(parseInt(currentMonth,10)-1);                
	newDate.setDate(1);
	var count=1;
	var dispDay =1;
	for (var w = 1; w < 7; w++){
		divHtml+='<tr bgcolor="e8f6f9">';
			for(var d=1;d<8;d++){
				if(! (count >= newDate.getDay()+1)){
							divHtml+='<td height="25" align="center" class="headblack">&nbsp;</td>';
							count++;
				}else{
					if (isValidDate ( parseInt(currentMonth,10), dispDay, parseInt(currentYear,10)) ){ 
						if( medicareEventVOList!=null && medicareEventVOList.eventVOArray!=null && isEventExists(dispDay,medicareEventVOList.eventVOArray)){
							divHtml+='<td id="d'+dispDay+'" height="25" align="center" bgcolor="CC0001" class="headwhite"  onmouseover="xstooltipShow(\''+dispDay+'\', \'d'+dispDay+'\', 289, 29);" onmouseout="xstooltipHide(\''+dispDay+'\');" >'+dispDay+'</td>';
						}else{
							divHtml+='<td height="25" align="center" class="headblack">'+dispDay+'</td>';
						}
						count += 1;
						dispDay += 1;
					}else{
						divHtml+='<td height="25" align="center" class="headblack">&nbsp;</td>';
					}
				}
			}
		divHtml+='</tr>';
	}
   divHtml+='</table>'            
	                
  document.getElementById("eventCalendar").innerHTML= divHtml;   	
}

  
/*
Author : Kapil
*/
function xstooltipFindPosX(obj) {
  var curleft = 0;
  if (obj.offsetParent) {
    while (obj.offsetParent) {
		curleft += obj.offsetLeft
        obj = obj.offsetParent;
	}
  } else if (obj.x)
		curleft += obj.x;
  return curleft;
}

/*
Author : Kapil
*/
function xstooltipFindPosY(obj) {
    var curtop = 0;
    if (obj.offsetParent) {
        while (obj.offsetParent) {
            curtop += obj.offsetTop
            obj = obj.offsetParent;
        }
    } else if (obj.y)
        curtop += obj.y;
  return curtop;
}

/*
Author : Kapil
*/
function xstooltipShow(tooltipId, parentId, posX, posY) {
    it = document.getElementById(tooltipId);
    if ((it.style.top == '' || it.style.top == 0) && (it.style.left == '' || it.style.left == 0)) {
        // need to fixate default size (MSIE problem)
        it.style.width = it.offsetWidth + 'px';
        it.style.height = it.offsetHeight + 'px';
        
        img = document.getElementById(parentId); 
    
        // if tooltip is too wide, shift left to be within parent 
        if (posX + it.offsetWidth > img.offsetWidth) posX = img.offsetWidth - it.offsetWidth;
        if (posX < 0 ) posX = 0; 
        
        x = xstooltipFindPosX(img) + posX;
        y = xstooltipFindPosY(img) + posY;
        
        it.style.top = y + 'px';
        it.style.left = x + 'px';
    }
    
    it.style.visibility = 'visible'; 
}

/*
Author : Kapil
*/

function xstooltipHide(id) {
     it = document.getElementById(id); 
     it.style.visibility = 'hidden'; 
}