/*
$Id: paymentDashboard.js,v 1.1 2014/06/26 07:56:12 praveen Exp $
*/
isOpen = top.isOpen;

/*
Author : Deepak
Discription : This method is used to show Payment details PopUp.
*/
function viewPaymentByParts(searchHic, pymtEffDate, seqNbr, pymtType, applyDate, isPopUp){
	var pageType = dwr.util.getValue("pageType");
	webUrl = "/dispatchAction.do?method=PymtEffDateDetail&fromDate="+pymtEffDate+'&searchHic='+searchHic+'&seqNbr='+seqNbr+'&pymtType='+pymtType+'&isPopUp='+isPopUp+'&pageType='+pageType+'&applyDate='+applyDate;
	var winTop = top;
	if(!top.isOpen) {
		winTop = window.opener.top;
	}

	if(winTop.isOpen(winTop.paymentPartPopUpWin))
		winTop.paymentPartPopUpWin.close();
	
	var winProperties = 'height=370,width=850,resizable=yes,status=no,toolbar=no,menubar=no,location=no,' + getScreenTopLeft(850);
	winTop.paymentPartPopUpWin = window.open(webUrl,'PaymentPartPopUp', winProperties);
	winTop.paymentPartPopUpWin.focus();
}


/*
Author : deepak
Discription : This method is used show/hide payment effective date on beneficiary payment detail when click on +/- button on Ui
*/
function togglePymtEffDate(x, partName, effDate, isPopUp, paymentType){
	//alert("in togle");
	var e = document.getElementById(partName+effDate+paymentType);
	//alert(e);
	var rowId = document.getElementById(partName+effDate+paymentType+"_effRow");
	//alert(rowId);
	if(e.style.display == 'none') {
		var isBodyExists = e.getAttribute("isBodyExists");
		if(isBodyExists != "true") {
			getPymtDetailOnEffDate(partName, effDate, isPopUp, paymentType);
		}
		e.setAttribute("rowExpanded", "true");
		e.style.display = "";
		//alert("e"+e+e.value);
		if(rowId!=null)		
			rowId.style.display = "";
		x.src = IMAGE_PATH_MINUS_PNG;
	} else {
		e.removeAttribute("rowExpanded");
		e.style.display = 'none';
		if(rowId!=null)		
			rowId.style.display = 'none';
		x.src = IMAGE_PATH_PLUS_PNG;
	}
}


/*
Author : deepak
Discription : Fucntion find Beneficiary Payment Detail for effective date.
*/
function getPymtDetailOnEffDate(partName, effDate, isPopUp, paymentType) {
	var pageType = dwr.util.getValue("pageType");
	try {
		FacadeManager.getPymtDetailOnEffDate(effDate, partName, isPopUp, paymentType, pageType, {
				  			callback:function(data) {
				   			CBgetPymtDetailOnEffDate(data, partName, effDate, paymentType ,isPopUp );}
				  			});
	} catch(e) {
		showPopMessage("Error: "+e.message);
	}
}

function CBgetPymtDetailOnEffDate(data, partName, effDate, paymentType, isPopUp) {
	if( data == null || data.length == 0 ) {
//		showPopMessage(MSG_NO_VALID_ITEMS);
		return;
	}
	//alert("in setting CB"+data);
	var html = '<table width="100%" border="0" cellspacing="0" cellpadding="0" style="border:1px none #000000;">';
	var pymtDetailVo ;
	for(var i = 0 ; i <data.length ;i++ ) {
		var color = true ;
		if(i%2 == 1) 
			color = false;
		
		pymtDetailVo = data[i];
		if(partName == PARTC) 
			html += createPartCPymtDetailRow(pymtDetailVo, color ,isPopUp);
		else
			html += createPartDPymtDetailRow(pymtDetailVo, color ,isPopUp);
	} 
	html +='</table>';
	var e = document.getElementById(partName + effDate+paymentType);
	//alert(" e"+e);
	e.innerHTML=html;
	e.setAttribute("isBodyExists", "true");
	e.setAttribute("rowExpanded", "true");
	//alert(" before resxet");
	resetBodyHeight();
}

/*
Author : deepak
Discription : This method is used to generate on paymentEfftiveDate row on beneficiary payment detail
*/
function createPartCPymtDetailRow(pymtDetailVo, color ,isPopUp) {
	//	alert(" in create");
	//var html = '<tr class="evenrow"><td width="3%" align="center">&nbsp;</td>';
	// IFOX-00419340 - Issue - 71 - Part C Payment Alignment :: START
	var html = '<tr class="evenrow">';//Change for Part C UI	IFOX-00419340 Issue 23
	var sh = "";
	if (pymtDetailVo.hicNbr != null) sh = pymtDetailVo.hicNbr;
	var href =    '<a href="#" class="plan" onClick="viewPaymentByParts(\''+sh+'\',\''+pymtDetailVo.effectiveDate+'\',\''+pymtDetailVo.seqNbr+'\',\'\',\''+pymtDetailVo.applyDate+'\',\''+isPopUp+'\')">';
	var redHref = '<a href="#" class="red"  onClick="viewPaymentByParts(\''+sh+'\',\''+pymtDetailVo.effectiveDate+'\',\''+pymtDetailVo.seqNbr+'\',\'\',\''+pymtDetailVo.applyDate+'\',\''+isPopUp+'\')">';

 	if(color) 
 		//html ='<tr class="oddrow"><td width="3%" align="center">&nbsp;</td>';
		html ='<tr class="oddrow">';//Change for Part C UI IFOX-00419340 Issue 23

	if(pymtDetailVo.hicNbr == null) {
		html += '<td width="3%" align="center">&nbsp;</td>'; // +pymtDetailVo.effectiveDate +'</td>'; IFOX-00419340 Issue 23
	    html += '<td width="7%" align="center">&nbsp;</td>'; // +pymtDetailVo.effectiveDate +'</td>';//Change for Part C UI
    }
    else 
    	//html += '<td width="13%" align="center">' +pymtDetailVo.hicNbr + '</td>';
        html += '<td width="10%" align="center" colspan="2">' +pymtDetailVo.hicNbr + '</td>';//Change for Part C UI IFOX-00419340 Issue 23

	html += '<td width="7%" align="center">' +pymtDetailVo.applyDate +'</td>';
	
	if(pymtDetailVo.adjustmentCode == null  ) 
		html += '<td width="7%" align="center">' +'&nbsp;' + '&nbsp;&nbsp;</td>';
	 else 
		html += '<td width="7%" align="center">' +pymtDetailVo.adjustmentCode + '&nbsp;&nbsp;</td>';

	if(pymtDetailVo.adjustmentDiscrp == null ) 
		//html += '<td width="26%" align="center">'+'&nbsp;' + '&nbsp;&nbsp;</td>';
		html += '<td width="27%" align="center">'+'&nbsp;' + '&nbsp;&nbsp;</td>';//Change for Part C UI
	else 
		//html += '<td width="26%" align="center">'+pymtDetailVo.adjustmentDiscrp + '&nbsp;&nbsp;</td>';
		html += '<td width="27%" align="center">'+pymtDetailVo.adjustmentDiscrp + '&nbsp;&nbsp;</td>';//Change for Part C UI
	
	html += '<td width="12%" align="center">&nbsp;</td>';

	if(pymtDetailVo.cmsPaid == null || pymtDetailVo.cmsPaid == '$0.00' ) 
		//html += '<td width="14%" align="right">'+'&nbsp;' + '&nbsp;&nbsp;</td>';
		html += '<td width="14%" align="center">'+'&nbsp;' + '&nbsp;&nbsp;</td>';//Change for Part C UI
	else if( pymtDetailVo.cmsPaid.charAt(0) == '(')
		//html += '<td width="14%" align="right" class="red" >'+redHref +pymtDetailVo.cmsPaid + '&nbsp;</a></td>';
		html += '<td width="14%" align="center" class="red" >'+redHref +pymtDetailVo.cmsPaid + '&nbsp;</a></td>';//Change for Part C UI
	else
		//html += '<td width="14%" align="right">'+href +pymtDetailVo.cmsPaid + '&nbsp;&nbsp;</a></td>';
		html += '<td width="14%" align="center">'+href +pymtDetailVo.cmsPaid + '&nbsp;&nbsp;</a></td>';//Change for Part C UI
	
	if(pymtDetailVo.planExpected == null || pymtDetailVo.planExpected == '$0.00' ) 
		//html += '<td width="14%" align="right">' +'&nbsp;' + '&nbsp;&nbsp;</td>'; 
		html += '<td width="14%" align="center">' +'&nbsp;' + '&nbsp;&nbsp;</td>';//Change for Part C UI
	else if( pymtDetailVo.planExpected.charAt(0) == '(')
		//html += '<td width="14%" align="right" class="red" >' +redHref +pymtDetailVo.planExpected + '&nbsp;</a></td>';
		html += '<td width="14%" align="center" class="red" >' +redHref +pymtDetailVo.planExpected + '&nbsp;</a></td>';//Change for Part C UI
	else 
		//html += '<td width="14%" align="right">' +href + pymtDetailVo.planExpected + '&nbsp;&nbsp;</a></td>';
		html += '<td width="14%" align="center">' +href + pymtDetailVo.planExpected + '&nbsp;&nbsp;</a></td>';//Change for Part C UI
	
	
	if(pymtDetailVo.difference.charAt(0) == '(' ) 
		//html +='<td width="14%" align="right" valign="middle" class="red" >'+pymtDetailVo.difference+'&nbsp;</td>';
		html +='<td width="9%" align="center" valign="middle" class="red" >'+pymtDetailVo.difference+'&nbsp;</td>';//Change for Part C UI
	else 
		//html += '<td width="14%" align="right" valign="middle" >'+ pymtDetailVo.difference + '&nbsp;&nbsp;</td>';
		html += '<td width="9%" align="center" valign="middle" >'+ pymtDetailVo.difference + '&nbsp;&nbsp;</td>';//Change for Part C UI
		// IFOX-00419340 - Issue - 71 - Part C Payment Alignment :: END
	html +='</tr>';
	//alert("  html"+html);
	return html;
}

/*
Author : deepak
Discription : This method is used to generate on paymentEfftiveDate row on beneficiary payment detail
*/
function createPartDPymtDetailRow(pymtDetailVo, color) {
	var html = '<tr class="evenrow">';
 	if(color) 
		html ='<tr class="oddrow">';
	if(pymtDetailVo.hicNbr == null) {
        html += '<td width="3%" align="center">&nbsp;</td>';
	    html += '<td width="7%" align="center">&nbsp;</td>'; // +pymtDetailVo.effectiveDate +'</td>';
    }
    else 
        html += '<td width="10%" align="center" colspan="2">' +pymtDetailVo.hicNbr + '</td>';
    
	html += '<td width="7%" align="center">' +pymtDetailVo.applyDate +'</td>';
	
	if(pymtDetailVo.adjustmentCode == null  ) 
		html += '<td width="7%" align="center">' +'&nbsp;' + '</td>';
	 else 
		html += '<td width="7%" align="center">' +pymtDetailVo.adjustmentCode + '&nbsp;&nbsp;</td>';

	if(pymtDetailVo.adjustmentDiscrp == null ) 
		html += '<td width="27%" align="center">'+'&nbsp;' + '</td>';
	else 
		html += '<td width="27%" align="center">'+pymtDetailVo.adjustmentDiscrp + '&nbsp;&nbsp;</td>';

	html += '<td width="12%" align="center">&nbsp;</td>';

		

	if(pymtDetailVo.cmsPaid == null || pymtDetailVo.cmsPaid == '$0.00' ) 
		html += '<td width="14%" align="center">'+'&nbsp;' + '</td>';
	else if( pymtDetailVo.cmsPaid.charAt(0) == '(')
		html += '<td width="14%" align="center" class="red" >' +pymtDetailVo.cmsPaid + '&nbsp;</td>';
	else
		html += '<td width="14%" align="center">' +pymtDetailVo.cmsPaid + '&nbsp;&nbsp;</td>';
	
	if(pymtDetailVo.planExpected == null || pymtDetailVo.planExpected == '$0.00' ) 
		html += '<td width="14%" align="center">&nbsp;</td>';
	else if( pymtDetailVo.planExpected.charAt(0) == '(')
		html += '<td width="14%" align="center" class="red" >' +pymtDetailVo.planExpected + '&nbsp;</td>';
	else 
		html += '<td width="14%" align="center">'  + pymtDetailVo.planExpected + '&nbsp;&nbsp;</td>';
	
	
	if(pymtDetailVo.difference.charAt(0) == '(' ) 
		html +='<td width="9%" align="center" valign="middle" class="red" >'+pymtDetailVo.difference+'&nbsp;</td>';
	else 
		html += '<td width="9%" align="center" valign="middle" >'+ pymtDetailVo.difference + '&nbsp;&nbsp;</td>'; //IFOX-00419340 - Issue - 24 - Part D payment Alignment
	
		
	html +='</tr>';
	return html;
}

/*
Author : deepak
Discription : This method is used show/hide plans on dashbords when click on +/- button on Ui
*/
function toggleVisibilitydownById(x,pageName,planId){
	//alert(" in toggle"+planId);
	var row = document.getElementById(planId+"_plan");
	var e = document.getElementById(planId);
	//alert(" plan=="+e+e.style.display);
	var flag = true;
	if(e.style.display == 'none') {
		//alert(" in if")
		var isBodyExists = e.getAttribute("isBodyExists");
		if(isBodyExists != "true") {
			//alert(" in body if");
			flag = false;
			getDashBoard(pageName,'year',planId);
		}
		e.setAttribute("rowExpanded", "true");
		e.style.display = "";
		if(row!=null)		
			row.style.display = "";
		//alert(" before exit in if");
		x.src = IMAGE_PATH_MINUS_PNG;
	} else {
		e.removeAttribute("rowExpanded");
		e.style.display = 'none';
		if(row!=null)
			row.style.display = 'none';
		x.src = IMAGE_PATH_PLUS_PNG;
	}
	if(flag){
	resetBodyHeight();
	}
	//alert(" end");
}

/*
Author : deepak
Discription : This method is used show/hide year on dashbords when click on +/- button on Ui
*/
function toggleVisibilitydownByYear(x,pageName,planId,yearId){
	var e = document.getElementById(planId+'_'+yearId);
	var flag = true;
	if(e.style.display == 'none') {
		var isBodyExists = e.getAttribute("isBodyExists");
		if(isBodyExists != "true") {
			flag = false;
			getDashBoard(pageName,'month',planId,yearId);
		}
		e.setAttribute("rowExpanded", "true");
		e.style.display = "";
		x.src = IMAGE_PATH_MINUS_PNG;
	} else {
		e.removeAttribute("rowExpanded");
		e.style.display = 'none';
		x.src = IMAGE_PATH_PLUS_PNG;
	}
	if(flag){
	resetBodyHeight();
	}
}

/*
Author : deepak
Discription : This method is used to create filterVO .
*/
function getFilterVO(pageName,searchType,planId ,yearId) {
	globalFilterVO = {planName:null,startDate:null,endDate:null,dateType:null ,hicNumber:null};
	var dateType = dwr.util.getValue(DATE_TYPE);
	var fromDate = dwr.util.getValue(START_DATE);
	var toDate = dwr.util.getValue(END_DATE);
	var hicNbr = dwr.util.getValue(HIC_NBR);
	globalFilterVO.planName = planId;
	if (searchType =='month' ) {
		globalFilterVO.startDate = yearId;
		globalFilterVO.endDate = yearId;
	}
	return globalFilterVO ;
}

/*
Author : deepak
Discription : This method is used to populate year/month on dashBord .
*/
function getDashBoard(pageName,searchType,planId ,yearId){
	try {
		var menuName = dwr.util.getValue("menuName");
		var globalFilterVO = getFilterVO(pageName,searchType,planId ,yearId);
//alert(" getDashBoard"+globalFilterVO+" "+searchType+menuName+pageName);
		if(PAGE_PAYMENT_DASHBOARD == pageName) {
			//alert(" in if pageName");
			FacadeManager.getPlanDashBoard(searchType,globalFilterVO ,menuName ,{
				  			callback:function(data) {
				   			CBgetPlanDashBoard(data,searchType,planId ,yearId);}
				  			});
			//alert(" after facade call"+data);
		} else if (PAGE_DISCREPANCY_DASHBOARD == pageName) {
			FacadeManager.getDiscrepancyDashBoard(searchType,globalFilterVO ,menuName ,{
			  			callback:function(data) {
				   			CBGetDiscrepancyDashBoard(data, searchType, planId, yearId);
						}});
		} else if (PAGE_TROOP_DASHBOARD == pageName){
			FacadeManager.getTroopDashBoard(searchType,globalFilterVO ,{
			  			callback:function(data) {
				   			CBgetTroopDashBoard(data,searchType,planId ,yearId);}
			  			});
		} else if(PAGE_PDE_DASHBOARD == pageName) {
				FacadeManager.getPdeDashBoard(searchType,globalFilterVO ,menuName ,{
							  			callback:function(data) {
								   			CBgetPdeDashBoard(data, searchType, planId, yearId);
										}});
		}
		filterVO = globalFilterVO ;
	}catch(e) {
		showPopMessage("Error  in getDashboard: "+e.message);
	}
}

/*
Author : deepak
Discription : This method is used to see that whether fromDate contain yearId or not
*/
function isContain(fromDate ,yearId ) {
	var index = fromDate.lastIndexOf(yearId);
	if(index == -1) {
		return false;
	} else {
		return true;
	}
}

/*
Author : deepak
Discription : callBack function of getDashBoard .
*/
function CBgetPlanDashBoard(data,searchType,planId ,yearId) {
	//alert(" in CBgetPlanDashBoard"+searchType);
	if(searchType =='year') {
		PopulateYears(data,planId);
	} else if (searchType == 'month' ) {
		populateMonth(data,planId ,yearId)
	}
	//alert("end in CBgetPlanDashBoard");
	resetBodyHeight();
}

/*
Author : deepak
Discription : This method is used to populate year on dashboard.
*/
function PopulateYears(data,planId) {
	var id = planId ;
	if( data == null || data.length == 0 ) {
		showPopMessage(MSG_NO_DATA_FOUND);
		return false;
	}
	
	var html ='<table width="100%"  border="0" cellspacing="0" cellpadding="0">';
	var planVo = {rollupId:null,cmsPaidPartC:null,planExpectedPartC:null,
				  diffrencePartC:null,cmsPaidPartD:null,planExpectedPartD:null,
				  diffrencePartD:null};
	for(var i=0; i< data.length;i++) {
		var color = true ;
		if(i%2 == 1) {
			color = false;
		}
		planVo = data[i];
		html += createYearRow(id,planVo,color);
	} 
	html +='</table>';
	var e = document.getElementById(id);
	e.innerHTML=html;
	e.setAttribute("isBodyExists", "true");
	e.setAttribute("rowExpanded", "true");
}

/*
Author : deepak
Discription : This method is used to populate month on dashboard.
*/
function populateMonth(data,planId ,yearId) {
	var id = planId ;
	var year = yearId;
	if( data ==null || data.length == 0 ) {
		showPopMessage(MSG_NO_DATA_FOUND);
		var e = document.getElementById(planId +yearId);
		e.innerHTML='<table><tr><td ></td></tr></table>';
		return;
	}
	var html ='<table width="100%"  border="0" cellspacing="0" cellpadding="0">';
	var planVo = {rollupId:null,cmsPaidPartC:null,planExpectedPartC:null,
				  diffrencePartC:null,cmsPaidPartD:null,planExpectedPartD:null,
				  diffrencePartD:null};
	for(var i=0; i<data.length ;i++ ) {
		var color = true ;
		if(i%2 == 1) {
			color = false;
		}
		planVo = data[i];
		html += createMonthRow(id,year ,planVo , color);
	} 
	html +='</table>';
	var e = document.getElementById(id +'_'+year );
	e.innerHTML=html;
	e.setAttribute("isBodyExists", "true");
	e.setAttribute("rowExpanded", "true");
}

/*
Author : deepak
Discription : This method is used to generate on year row on dashboard.
*/
function createYearRow(id,planVo,color) {
	var html ='';
	var tdTag ='<td width="13%" align="center" valign="middle">';
	var startPlan ='<tr class="evenrow">'
	if(color) { 
		startPlan ='<tr class="oddrow">';
	}
	startPlan += '<td width="5%" align="center"><img src="/mss/jsp/Recon/images/Plus.png" width="12" height="12" onclick = "useLoadingImage(this);toggleVisibilitydownByYear(this,\'PaymentDashBoard\',\''+id+'\',\''+planVo.rollupId+'\');" style="cursor:pointer;">&nbsp;&nbsp;</td><td>';
	html += startPlan;
	html += '<a href="#" class="plan" onclick="submitPaymentDashboardAction(\'PaymentSummary\',\'year\',\''+id+'\',\''+planVo.rollupId+'\');">' +planVo.rollupId +'</a></td>';
	//part C
	if(planVo.cmsPaidPartC == null ) {
		html += tdTag+'&nbsp;' + '&nbsp;</td>';
	} else {
		html += tdTag +planVo.cmsPaidPartC + '&nbsp;&nbsp;</td>';
	}
	if(planVo.planExpectedPartC == null ) {
		html += tdTag+'&nbsp;' + '&nbsp;</td>';
	} else {
		html += tdTag +planVo.planExpectedPartC+ '&nbsp;&nbsp;</td>';
	}
	if(planVo.diffrencePartC != null && planVo.diffrencePartC.charAt(0) == '(' ) {
		html +='<td width="13%" align="center" valign="middle" class="red"  >'+planVo.diffrencePartC+'&nbsp;</td>';
	} else if(planVo.diffrencePartC == '' ) {
		html += tdTag+planVo.diffrencePartC + '&nbsp;</td>';
	} else if(planVo.diffrencePartC == null ) {
		html += '<td width="13%" align="center" valign="middle" >'+'&nbsp;' + '&nbsp;</td>';
	} else {
		html += '<td width="13%" align="center" valign="middle" >'+ planVo.diffrencePartC + '&nbsp;&nbsp;</td>';
	}
	// part -D
	if(planVo.cmsPaidPartD == null ) {
		html += tdTag+'&nbsp;' + '&nbsp;</td>';
	} else {
		html += tdTag +planVo.cmsPaidPartD+ '&nbsp;&nbsp;</td>';
	}
	if(planVo.planExpectedPartD == null ) {
		html += tdTag+'&nbsp;' + '&nbsp;</td>';
	} else {
		html += tdTag +planVo.planExpectedPartD + '&nbsp;&nbsp;</td>';
	}
		
	if(planVo.diffrencePartD != null && planVo.diffrencePartD.charAt(0) == '(' ) {
		html +='<td width="13%" align="center" valign="middle" class="red">'+planVo.diffrencePartD+'&nbsp;</td>';
	} else if(planVo.diffrencePartD == null ) {
		html += tdTag+ '&nbsp;' + '&nbsp;</td>';
	} else {
		html += tdTag+planVo.diffrencePartD + '&nbsp;&nbsp;</td>';
	}

	html +='</tr>';
	html+='<tr><td colspan="8"><div id="'+ id +'_'+ planVo.rollupId +'" style="display:none"></div></td></tr>';
	return html;
}

/*
Author : deepak
Discription : This method is used to generate on month row on dashboard.
*/
function createMonthRow(id,year,planVo,color) {
	var html ='';
	var tdTag ='<td width="13%" align="center" valign="middle">';
	var startPlan ='<tr class="evenrow"><td width="7%" align="center" ></td>';
	if(color) { 
		startPlan ='<tr class="oddrow"><td width="7%" align="center"></td>';
	}
	html +=startPlan;
	html += '<td align="left"><a href="#" class="plan" onclick="  submitPaymentDashboardAction(\'PaymentSummary\',\'month\',\''+id+'\',\''+year+'\',\''+getMonthValue(planVo.rollupId)+'\');">' +planVo.rollupId +'</a></td>';

	//part C
	if(planVo.cmsPaidPartC == null ) {
		html += tdTag+'&nbsp;' + '&nbsp;&nbsp;</td>';
	} else {
		html += tdTag +planVo.cmsPaidPartC + '&nbsp;&nbsp;</td>';
	}
	if(planVo.planExpectedPartC == null ) {
		html += tdTag+'&nbsp;' + '&nbsp;&nbsp;</td>';
	} else {
		html += tdTag + planVo.planExpectedPartC + '&nbsp;&nbsp;</td>';
	}
	if(planVo.diffrencePartC != null && planVo.diffrencePartC.charAt(0) == '(' ) {
		html +='<td width="13%" align="center" valign="middle" class="red" >'+planVo.diffrencePartC+'&nbsp;</td>';
	} else if(planVo.diffrencePartC == '' ) {
		html += '<td width="13%" align="center" valign="middle" >'+planVo.diffrencePartC + '&nbsp;</td>';
	} else if(planVo.diffrencePartC == null ) {
		html += '<td width="13%" align="center" valign="middle" >'+'&nbsp;' + '&nbsp;</td>';
	} else {
		html += '<td width="13%" align="center" valign="middle" >'+ planVo.diffrencePartC + '&nbsp;&nbsp;</td>';
	}
	// part -D
	if(planVo.cmsPaidPartD == null ) {
		html += tdTag+'&nbsp;' + '&nbsp;&nbsp;</td>';
	} else {
		html += tdTag +planVo.cmsPaidPartD+ '&nbsp;&nbsp;</td>';
	}
	if(planVo.planExpectedPartD == null ) {
		html += tdTag+'&nbsp;' + '&nbsp;&nbsp;</td>';
	} else {
		html += tdTag +planVo.planExpectedPartD + '&nbsp;&nbsp;</td>';
	}
	
	if( planVo.diffrencePartD != null && planVo.diffrencePartD.charAt(0) == '(' ) {
		html +='<td width="13%" align="center" valign="middle" class="red">'+planVo.diffrencePartD+'&nbsp;</td>';
	} else if(planVo.diffrencePartD == null  ) {
		html += tdTag+ '&nbsp;' + '&nbsp;</td>';
	} else {
		html += tdTag+ planVo.diffrencePartD + '&nbsp;&nbsp;</td>';
	}
	html +='</tr>';
	return html;
}
