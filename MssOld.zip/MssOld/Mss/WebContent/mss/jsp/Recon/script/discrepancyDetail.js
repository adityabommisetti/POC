/*
$Id: discrepancyDetail.js,v 1.1 2014/06/26 07:56:11 praveen Exp $
*/
var start=1;
var end=10;
var curtrentPage=1;
var totalDiscrepancyPages=0;
var globalFilterVO = {planName:null,startDate:null,endDate:null,dateType:null,discrpCd:null,discrpStatus:null,hicNumber:null, discrepancyIndicator:null  };

var discListVO = { hicNumber:null, altHic:null, discrepancyCd:null, discrepancyType:null, discrepancyStatus:null, discrepancyIndicator:null,
 cmsValue:null, altCmsValue:null, planValue:null, altPlanValue:null, pymtEffDate:null, createDate:null, pbpId:null, comment:null, pymtApplyDate:null,
  lastUpdtDate:null, lastUpdtUserID:null, firstName:null, lastName:null, effDateSuppId:null ,mostRecentSuppId:null, pbpSegmentId:null};
var preiousSelectedRow="0";

function getReconcilationDiseaseGrp(partName , pbpId) {
	dwr.util.setValue("cmsValue",dwr.util.getValue(partName+"cmsValue"));
	dwr.util.setValue("planValue",dwr.util.getValue(partName+"planValue"));
	dwr.util.setValue("discrepancyIndicator", partName);
	//dwr.util.setValue("pbpId", pbpId);
	viewDiseaseGrp('reconciliation');
}
/*
Author : Deepak
Discription : This method is used to show Payment PopUp.
*/
function viewPayment(){
	var planName = dwr.util.getValue("planId");		//IFOX-00431034 :: All-Plans in Discrepancy Drop down
	var hicNbr = dwr.util.getValue("hicNumber");
	var pymtEffDate = dwr.util.getValue("pymtEffDate");
	var partName = dwr.util.getValue('discrepancyIndicator');//dwr.util.setValue("lastUpdtDate",discListVO.lastUpdtDate);
	var menuName = 'paymtDetail';
	var pageName = 'PaymentSummary';
	var actionType = 'search';
	var pageType = dwr.util.getValue("pageType");
	webUrl = "/dispatchAction.do?method=" + pageName +'&menuName='+menuName +'&fromDate='+pymtEffDate+'&toDate='+pymtEffDate+'&hicNbr='+hicNbr 
	+'&partName='+partName +'&actionType='+actionType +'&planName='+planName+'&pageType='+pageType;
	
	if(isOpen(top.paymentPopUpWin))
		top.paymentPopUpWin.close();
	
	var winProperties = 'width=900,height=370,resizable=yes,scrollbars=yes,location=no,menubar=no,toolbar=no,' + getScreenTopLeft(900);
	top.paymentPopUpWin = window.open(webUrl,'PaymentPopUp', winProperties);
	top.paymentPopUpWin.focus();
}

/*
Author : Deepak
Discription : This method is used to show Disease Group PopUp.
*/
function viewDiseaseGrp(menuName) {
	var cmsValue = dwr.util.getValue("cmsValue");
	var planValue = dwr.util.getValue("planValue");
	var pymtEffDate = dwr.util.getValue("pymtEffDate");
	var planName = dwr.util.getValue("planId");		//IFOX-00431034 :: All-Plans in Discrepancy Drop down
	var hicNbr = dwr.util.getValue("hicNumber");
	var pbpId = dwr.util.getValue("pbpId");
	var partName = dwr.util.getValue("discrepancyIndicator");
	var method = 'DiseaseGroupDetail';
	var actionType = dwr.util.getValue("actionType");
	var pageType = dwr.util.getValue("pageType");

	webUrl = "/dispatchAction.do?method=" + method +'&menuName='+menuName +'&fromDate='+pymtEffDate+'&cmsValue='+cmsValue+'&planValue='+planValue+'&hicNbr='+hicNbr+'&partName='+partName+'&pageType='+pageType +'&pbpId='+pbpId +'&planName='+planName ;
	
	var winTop = top;
		if(!top.isOpen) {
			winTop = window.opener.top;
		}
	
		if(winTop.isOpen(winTop.diseasePopUpWin))
			winTop.diseasePopUpWin.close();
	
		var winProperties = 'width=800,height=370,resizable=yes,scrollbars=yes,location=no,menubar=no,toolbar=no,' + getScreenTopLeft(800);
		winTop.diseasePopUpWin = window.open(webUrl,'DiseasePopUp', winProperties);
		winTop.diseasePopUpWin.focus();
}

/*
Author : Deepak
Discription : This method is used to show Reconciliation Group PopUp.
*/
function viewReconciliation(menuName, isCallFromDetail) {
	var pymtEffDate = dwr.util.getValue("pymtEffDate");
	if(pymtEffDate == '')
		pymtEffDate = dwr.util.getValue("fromDate");

	var hicNbr = dwr.util.getValue("hicNumber");
	if(hicNbr == '')
		hicNbr = dwr.util.getValue("hicNbr");

	var planName = dwr.util.getValue("planId"); /* IFOX-00431034 :: All-Plans in Discrepancy Drop down */
	if(planName == '')
		planName = dwr.util.getValue("planName");
	
	var method = 'Reconciliation';
	var partName = "Both" 
	var actionType = dwr.util.getValue("actionType");
	var pageType = dwr.util.getValue("pageType");
	var pbpId = dwr.util.getValue("pbpId");

	if(isCallFromDetail == 'yes')
		partName = dwr.util.getValue("discrepancyIndicator");

	webUrl = "/dispatchAction.do?method=" + method +'&menuName='+menuName +'&fromDate='+pymtEffDate+'&hicNbr='+hicNbr+'&partName='+partName+'&pageType='+pageType +'&pbpId='+pbpId+'&planName='+planName  ;
	
	if(isOpen(top.reconciliationPopUp))
		top.reconciliationPopUp.close();
	
	var winProperties = 'width=800,height=650,resizable=yes,scrollbars=yes,location=no,menubar=no,toolbar=no,' + getScreenTopLeft(800);
	top.reconciliationPopUp = window.open(webUrl,'ReconciliationPopUp', winProperties);
	top.reconciliationPopUp.focus();
}


/*
Author : hemant
Discription : This method is called to know that in case of print and PDF of Discrepancy Detail for 'ALL' aoption 
PDF or Print must be produced or a msg will be shown 	 
*/
function isPrintPDFDiscDetailRequestValid(){
	var menuName = dwr.util.getValue("menuName");
	try{	
		FacadeManager.isPrintPDFDiscDetailRequestValid(menuName, CBisPrintPDFDiscDetailRequestValid);
	}catch(e){
			showPopMessage("Error: "+e.message);
	}
}

/*
Author : hemant
Discription : callback of isPrintPDFDiscDetailRequestValid, shows msg or go for print and PDF of Discrepancy Detail
*/
function CBisPrintPDFDiscDetailRequestValid(data){
	var pageName=PAGE_DISCREPANCY_DETAILS;
	var uiContextRange="ALL";
	if(data=="TRUE"){
		if(isForPrint == true || isForPrint == "TRUE" ){
			printGeneratedData(pageName, uiContextRange);
		} else {
			exportGeneratedData(pageName ,uiContextRange);	
		}
	}else if(data == MSG_NO_DATA_FOUND){
		showPopMessage(MSG_NO_DATA_FOUND);
	}else{
		showPopMessage("Current search crossing the limit of "+data+" rows, please change search criteria to reduce it.");
	}
}

/**
	This function create discrepancy DetailVO for selected row.
*/
function getDiscrepancyDetail(rowId ,hicNumber, menuName, partName) {
	try{
	discListVO.planName = dwr.util.getValue('planName_'+rowId);
 	discListVO.hicNumber = hicNumber ;
 	discListVO.altHic = dwr.util.getValue('altHic_'+rowId);
	discListVO.discrepancyCd=dwr.util.getValue('discrepancyCd_'+rowId);
	discListVO.createDate=dwr.util.getValue('createDate_'+rowId);
	discListVO.discrepancyType=dwr.util.getValue('discrepancyType_'+rowId);
	discListVO.cmsValue=dwr.util.getValue('cmsValue_'+rowId);
	discListVO.planValue=dwr.util.getValue('planValue_'+rowId);
	discListVO.altCmsValue=dwr.util.getValue('altCmsValue_'+rowId);
	discListVO.altPlanValue=dwr.util.getValue('altPlanValue_'+rowId);
	discListVO.pymtEffDate=dwr.util.getValue('pymtEffDate_'+rowId);
	discListVO.pbpId =dwr.util.getValue('pbpId_'+rowId);
	preiousSelectedRow = dwr.util.getValue('selectRow');

	var prevSeleRow = document.getElementById(preiousSelectedRow);
	var isPayDiscRow = null;
	if(prevSeleRow)
		isPayDiscRow = prevSeleRow.getAttribute("isPayDiscRow");
	if(isPayDiscRow != null && "true" == isPayDiscRow){
		applyClassOnTdTag("payDiscRow", preiousSelectedRow);
	} else {
		if(preiousSelectedRow %2  == '0' || preiousSelectedRow =='2' || preiousSelectedRow =='4' || preiousSelectedRow =='6' || preiousSelectedRow =='8' )
			applyClassOnTdTag("oddRow", preiousSelectedRow);
		if(preiousSelectedRow % 2 =='1' || preiousSelectedRow =='3' || preiousSelectedRow =='5' || preiousSelectedRow =='7' || preiousSelectedRow =='9' )
			applyClassOnTdTag("evenRow", preiousSelectedRow);
	}
	dwr.util.setValue('selectRow', rowId); 
   
	applyClassOnTdTag("selectedRow", rowId); //applye selected row style class.
		var discrepancy = discListVO.discrepancyCd ;
		discListVO.discrepancyCd  = getDiscrepancyCode(discListVO.discrepancyCd);
		var pageType = dwr.util.getValue("pageType");
		FacadeManager.getDiscrepancyDetails(discListVO, rowId, menuName, pageType, partName , {
								  			callback:function(data) {
								   			setDiscrepancyHistory(data,discrepancy,menuName);}
								  			});
	}catch(e){
		showPopMessage("Error: "+e.message);
	}
}

function getWorkQueueDetail(rowId ,hicNumber, menuName, partName) {
	try{
	discListVO.planName = dwr.util.getValue('planName_'+rowId);
 	discListVO.hicNumber = hicNumber ;
 	discListVO.altHic = dwr.util.getValue('altHic_'+rowId);
	discListVO.discrepancyCd=dwr.util.getValue('discrepancyCd_'+rowId);
	discListVO.createDate=dwr.util.getValue('createDate_'+rowId);
	discListVO.discrepancyType=dwr.util.getValue('discrepancyType_'+rowId);
	discListVO.cmsValue=dwr.util.getValue('cmsValue_'+rowId);
	discListVO.planValue=dwr.util.getValue('planValue_'+rowId);
	discListVO.altCmsValue=dwr.util.getValue('altCmsValue_'+rowId);
	discListVO.altPlanValue=dwr.util.getValue('altPlanValue_'+rowId);
	discListVO.pymtEffDate=dwr.util.getValue('pymtEffDate_'+rowId);
	discListVO.pbpId =dwr.util.getValue('pbpId_'+rowId);
	discListVO.comment =dwr.util.getValue('comment_'+rowId);
	preiousSelectedRow = dwr.util.getValue('selectRow');

	var prevSeleRow = document.getElementById(preiousSelectedRow);
	var isPayDiscRow = null;
	if(prevSeleRow)
		isPayDiscRow = prevSeleRow.getAttribute("isPayDiscRow");
	if(isPayDiscRow != null && "true" == isPayDiscRow){
		applyClassOnTdTag("payDiscRow", preiousSelectedRow);
	} else {
		if(preiousSelectedRow %2  == '0' || preiousSelectedRow =='2' || preiousSelectedRow =='4' || preiousSelectedRow =='6' || preiousSelectedRow =='8' )
			applyClassOnTdTag("oddRow", preiousSelectedRow);
		if(preiousSelectedRow % 2 =='1' || preiousSelectedRow =='3' || preiousSelectedRow =='5' || preiousSelectedRow =='7' || preiousSelectedRow =='9' )
			applyClassOnTdTag("evenRow", preiousSelectedRow);
	}
	dwr.util.setValue('selectRow', rowId); 
   
	applyClassOnTdTag("selectedRow", rowId); //applye selected row style class.
		var discrepancy = discListVO.discrepancyCd ;
		discListVO.discrepancyCd  = getDiscrepancyCode(discListVO.discrepancyCd);
		var pageType = dwr.util.getValue("pageType");
		document.getElementById('selectedComment').innerHTML = discListVO.comment;
	}catch(e){
		showPopMessage("Error: "+e.message);
	}
}

/**
	This function show discrepancy detail for selected row .
*/
function setDiscrepancyDetail(discListVO,menuName) {

	var altHic;
	var altPlanValue;
	var altCmsValue;
	var displayAlt;
	document.getElementById('detailRow').style.display = "";
	dwr.util.setValue("planId" ,discListVO.planName );  		//IFOX-00431034 :: All-Plans in Discrepancy Drop down
	dwr.util.setValue("pbpSegmentId", discListVO.pbpSegmentId);
	dwr.util.setValue("hicNumber",discListVO.hicNumber);
	dwr.util.setValue("pbpId",discListVO.pbpId);
	dwr.util.setValue("effDateSuppId",discListVO.effDateSuppId);
	dwr.util.setValue("mostRecentSuppId",discListVO.mostRecentSuppId);
	dwr.util.setValue("firstName",discListVO.firstName);
	dwr.util.setValue("lastName",discListVO.lastName);
	dwr.util.setValue("pymtEffDate",discListVO.pymtEffDate);
	dwr.util.setValue("pymtApplyDate",discListVO.pymtApplyDate);
	dwr.util.setValue("createDate",discListVO.createDate);
	dwr.util.setValue("shortCreateDate",discListVO.shortCreateDate);
	dwr.util.setValue("lastUpdtDate",discListVO.lastUpdtDate);
	dwr.util.setValue("lastUpdtDateTillSeconds",discListVO.lastUpdtDateTillSeconds);
	dwr.util.setValue("lastUpdtUserID",discListVO.lastUpdtUserID);
	dwr.util.setValue("cmsValue",discListVO.cmsValue);
	dwr.util.setValue("planValue",discListVO.planValue);
	dwr.util.setValue("discreStatus",discListVO.discrepancyStatus);
	dwr.util.setValue("discrepancyStatus",discListVO.discrepancyStatus);
	dwr.util.setValue("showComment",discListVO.comment);
	dwr.util.setEscapeHtml(false);
	dwr.util.setValue("comment",discListVO.comment);
	dwr.util.setEscapeHtml(true);
    	   	
    document.getElementById('priHicNbr').innerHTML = discListVO.hicNumber;	
    document.getElementById('cmsValue').innerHTML = discListVO.cmsValue;
    document.getElementById('planValue').innerHTML = discListVO.planValue;
    
    displayAlt = false;
    	
	altHic = discListVO.altHic;
	altPlanValue = "";
	altCmsValue = "";
	if (altHic == null)
		altHic = "";
	if (altHic != "") {
		if (altHic != discListVO.hicNumber) {
			displayAlt = true;
			if (discListVO.altPlanValue != null)
				altPlanValue = discListVO.altPlanValue;
			if (discListVO.altCmsValue != null)
				altCmsValue = discListVO.altCmsValue;
		}
	}
		
	if (displayAlt) {
		document.getElementById('lblAltHic').innerHTML = "<span class='head3'>Alternate</span>&nbsp;:&nbsp;";
		document.getElementById('altHicNbr').innerHTML = altHic;
		
		document.getElementById('lblAltCmsValue').innerHTML = "<span class='head3'>CMS</span>&nbsp;:&nbsp;";
		document.getElementById('altCmsValue').innerHTML = altCmsValue;
		
		document.getElementById('lblAltPlanValue').innerHTML = "<span class='head3'>Plan</span>&nbsp;:&nbsp;";	
		document.getElementById('altPlanValue').innerHTML = altPlanValue;
	} else {
		document.getElementById('lblAltHic').innerHTML = "<span class='head3'></span>&nbsp;";
		document.getElementById('altHicNbr').innerHTML = "&nbsp;";

		document.getElementById('lblAltCmsValue').innerHTML = "<span class='head3'></span>&nbsp;";
		document.getElementById('altCmsValue').innerHTML = "&nbsp;";
	
		document.getElementById('lblAltPlanValue').innerHTML = "<span class='head3'></span>&nbsp;";			
		document.getElementById('altPlanValue').innerHTML = "&nbsp;";
	}

	dwr.util.setValue("discrepancyIndicator",discListVO.discrepancyIndicator);

	if(discListVO.discrepancyType == '1')
		/*document.getElementById('disGrpImage').innerHTML = '&nbsp;<img src="/mss/jsp/Recon/images/but_disGrp.jpg" width="120" height="24" style="cursor:pointer" onClick="viewDiseaseGrp(\''+menuName+'\');">';*/
		document.getElementById('disGrpImage').innerHTML = '&nbsp;<input type="button" id="butGoGif" style="cursor: pointer; width: 140px; height: 27px" onClick="viewDiseaseGrp(\''+menuName+'\');"class="inputButton" value="View Disease Group">';

	//updating status message.
	var discStatusMsg = "&nbsp;" + discListVO.discStatusMsg;
	if(discListVO.discWriteOffStatusMsg && "" != discListVO.discWriteOffStatusMsg)
		discStatusMsg += " " + discListVO.discWriteOffStatusMsg;

	document.getElementById('discStatusMsgTD').innerHTML = discStatusMsg;
	var pageType = dwr.util.getValue("pageType");
//BUG	var menuName = dwr.util.getValue("menuName");
	// adding edit discrepancy status and text arear for new comments are making 'disabled' as default
	if( pageType != 'readOnly' || (pageType == 'readOnly'&& menuName != "beneDiscrpDetail") ) {	
		// putting prev value as default value
		dwr.util.setValue("discrepancyStatus", discListVO.discrepancyStatus);
		dwr.util.setValue("showComment", discListVO.comment);
		
		document.getElementsByName('discrepancyStatus')[0].style.color= "#999999";
		document.getElementsByName('discrepancyStatus')[0].setAttribute("disabled", true);
		document.getElementsByName('discrepancyStatus')[0].setAttribute("prevDisableState", true);
		
		document.getElementsByName('comment')[0].setAttribute("disabled", true);
		document.getElementsByName('comment')[0].setAttribute("prevDisableState", true);
		
		if(discListVO.writeOffInd == '2') {
			document.getElementById('updateButton').innerHTML= '&nbsp;<img id="butWriteCancelJPG" src="/mss/jsp/Recon/images/but_writecancel.jpg" width="84" height="24" style="cursor:pointer" onclick="cancelDiscWriteOff();" >'
		} else if(discListVO.writeOffInd == '3') {
			document.getElementById('updateButton').innerHTML= '<img id="butWriteOffJPG" src="/mss/jsp/Recon/images/but_writeoff.jpg" width="51" height="24" style="cursor:pointer" onclick="updateDiscWriteOff();">'
		} else if(discListVO.writeOffInd == '4') {
			if(isAlertDivOpen() == false)
				document.getElementsByName('discrepancyStatus')[0].removeAttribute("disabled");
			
			document.getElementsByName('discrepancyStatus')[0].removeAttribute("prevDisableState");
			document.getElementsByName('discrepancyStatus')[0].style.color= "#000000";
			
			document.getElementsByName('comment')[0].removeAttribute("disabled");
			document.getElementsByName('comment')[0].removeAttribute("prevDisableState");
			
			// Changed for Base+ UI issues Start-->
			//document.getElementById('updateButton').innerHTML= '<img id="butUpdateJPG" src="/mss/jsp/Recon/images/but_update.jpg" width="51" height="24" style="cursor:pointer" onclick="updateDiscStatus(\''+menuName+'\');">';
			
			//<img id="butUpdateJPG" src="/mss/jsp/Recon/images/but_update.jpg" width="51" height="24" style="cursor:pointer" onclick="updateDiscStatus('discrepancy');">-->
			document.getElementById('updateButton').innerHTML= '<input type="button" id="butUpdateJPG" style="cursor: pointer; width: 54px; height: 24px"	onclick="updateDiscStatus(\''+menuName+'\');"class="inputButton btn_padding buttonColor_green" value="Update" />';
				// Changed for Base+ UI issues End-->
			//document.getElementById('updateButton').innerHTML= '<input type="button" id="butGoGif" style="cursor: pointer; width: 140px; height: 27px"  onclick="updateDiscStatus(\''+menuName+'\');"class="inputButton" value="Update">'
		} else {
			document.getElementById('updateButton').innerHTML= '&nbsp;';
		}
	}
}


/**
	This function is use to apply class on all td in  an row.
*/
function applyClassOnTdTag(className,rowId) {
	var trRow = getElement(rowId);
	
	if(trRow != null) {
		var tdRows = trRow.getElementsByTagName("td");
		var anchorTag = trRow.getElementsByTagName("a");
		
		if(anchorTag != null && anchorTag.length > 0)
			anchorTag[0].className=className;
		
		for(var i=0; i < tdRows.length; i++)
			tdRows[i].className=className;
	}
}

/**
	This function extract discrepancyCode form discrepancyCode - discrepancyDescreption .
*/
function getDiscrepancyCode(discCode) {
	var index = discCode.indexOf('-');
	if( index != -1 ) {
		return discCode.substr(0,(index-1));
	}
	
	return discCode;
}

/**
	This function is use to show discrepancy history.
*/
function setDiscrepancyHistory(data, discrepancy, menuName, flag) {
	document.getElementById('historyRow').style.display = "";
	var discHistory={discrepancyCd:null,discrepancyStatus:null,createDate:null,lastUpdtDate:null,lastUpdtUserId:null,comment:null};
	var historyArr = null;
	if(flag == "pagination") {
		historyArr = data;
	} else {
		if(data != null) {
			historyArr = data.listObject;
		   	if(data.detail != null ) {
			  	setDiscrepancyDetail(data.detail,menuName);
				setLatestDiscrepancyInfo(data.detail, menuName);
			}
		}
	}
	var divHtml="<table width='100%' border='1' cellpadding='0' cellspacing='0' bordercolor='#999999' style='border-collapse:collapse'>";
	if(historyArr == null ||  historyArr.length == 0)
		divHtml+="<tr><td colspan='6'>&nbsp;" + MSG_NO_DATA_FOUND + "</td></tr>";
	else {
		for(var i=0 ; i < historyArr.length ; i++) {
			discHistory=historyArr[i];
			if( i %2 == 0 ) {
				divHtml+="<tr class='oddRow bordered-table'>"; //IFOX-00419340 added bordered-table
			} else {
				divHtml+="<tr class='evenRow bordered-table'>"; //IFOX-00419340 added bordered-table
			}
			divHtml+="<td width='20%' align='center'>"+discrepancy +"</td>";
			divHtml+="<td width='10%' align='center'>"+discHistory.discrepancyStatus+"</td>";
			divHtml+="<td width='20%' align='center'>"+discHistory.createDate+"</td>";
			divHtml+="<td width='20%' align='center'>"+discHistory.lastUpdtDate+"</td>";
			divHtml+="<td width='20%' align='center'>"+dwr.util.escapeHtml(discHistory.comment)+"</td>";
			divHtml+="<td width='10%' align='center'>"+discHistory.lastUpdtUserId+"</td>";
			divHtml+="</tr>";
		}
	}
	divHtml+=" </table>";
	document.getElementById("discrepancyHistory").innerHTML=divHtml;

	resetBodyHeight();
}

/**
	This function is used find discrepancy detail when we  navigate between pages using pagination.
*/
function pagination(id, menuName, partName, flag, callByDiscUpdate){
	
	
	 try{
		 if(menuName == 'troop') {
			FacadeManager.getTroopDetail(id ,CBgetTroopDetail);
		 } else if(menuName == 'pde') {
			FacadeManager.getPdeEventDetailList(id, {
								callback:function(data) {
									CBgetPdeEventDetailList(data, id, menuName); 
								}});
		 } else if(menuName == 'pdeErrDetail') {
			FacadeManager.getPdeErrDetailList(id, {
								callback:function(data) {
									CBgetPdeEventDetailList(data, id, menuName); 
								}});
		 }
		 else if(menuName == 'workqueue'){
			 	var pageType = dwr.util.getValue("pageType");
			 	var part = dwr.util.getValue("partName");
			 	var all = document.getElementById('selectDisAll');
			 	all.checked = false;
			 	partName = part;
			 	var formRef = document.forms ['WorkQueueForm']
				
			 	FacadeManager.getDiscrepancyList(id,menuName, partName, pageType , {
					  			callback:function(data) {
					  				
									CBgetWorkQueueList(data, menuName, partName, flag, callByDiscUpdate);}
					  			});
					  			
			 }
		 else {
		 	var pageType = dwr.util.getValue("pageType");
		 	FacadeManager.getDiscrepancyList(id, menuName, partName, pageType , {
				  			callback:function(data) {
				  				if(flag){
						  			// updating other Part of Discrepancy only in case of "Both" discrepancy type selected.
									// means updating rest of discrepancy (Part C / D)
									var menuPartName = dwr.util.getValue("partName");
									if( "Both" == menuPartName){
										var otherPartDisc = (partName == "Part C") ? "Part D" : "Part C";
										pagination("current", menuName, otherPartDisc, false, callByDiscUpdate);
									}
								}
								CBgetDiscrepancyList(data, menuName, partName, flag, callByDiscUpdate);}
				  			});
		 }
	}catch(e){
		showPopMessage("Error: "+e.message);
	}
}

/**
 	This function is use to populate discrepancy list.
Input Type : 
 	data: data return by Server
 	menuName : menuName
 	partName : 'Part C' | 'Part C'
 	flag : when 'Both' option is selected then we are refreshing both list (ie. 'Part C' & 'Part D' list), 
		   So if Flag is TRUE means this CallBack handler is calling for orignal selected list.
	callByDiscUpdate : TRUE is called by disrecpany Update Callback handler
*/
function CBgetDiscrepancyList(data, menuName, partName, flag, callByDiscUpdate) {
	discrepancyDetailVOList = data ;
	//discrepancyDetail,discrepancyHistory
	var divHtml="<table width='100%'  border='1' cellpadding='0' cellspacing='0' bordercolor='#999999' style='border-collapse:collapse;word-break:break-all'>";
	if( discrepancyDetailVOList == null ) {
		divHtml += "<tr><td colspan='10'>&nbsp;"+MSG_NO_DATA_FOUND+"</td></tr></table>";
		document.getElementById('detailRow').style.display = 'none';
		document.getElementById('historyRow').style.display = 'none';
	} else {
		preiousSelectedRow = discrepancyDetailVOList.selectedLine;
		var discrepancyListVO = null;
		var discrepancyDetailVO = null;
		var currentPage = "";
		var pageNumber = 1;
		var showHistory = false;
		
		if ('Part C' == partName) {
			if(preiousSelectedRow >= 0 && preiousSelectedRow  < 10)
				showHistory = true;
			
			discrepancyDetailVO = discrepancyDetailVOList.partCDiscrpDetailVO;
		}
		if ('Part D' == partName) {
			if(preiousSelectedRow >= 10 && preiousSelectedRow  < 20)
				showHistory = true;
			discrepancyDetailVO = discrepancyDetailVOList.partDDiscrpDetailVO;
		}
		
		// did not having any data List on pagination.
		if(discrepancyDetailVO == null ) {
			if(callByDiscUpdate){
				var pgNumber = dwr.util.getValue("pgNumber"+partName);
				if(pgNumber != "1" && flag){
					pagination("previous", menuName, partName, false, callByDiscUpdate);
					return;
				}
			
				// showing 'NO Data Found' msg onto hte UI.
				var divHtml="<table width='100%' border='1' cellpadding='0' cellspacing='0' bordercolor='#999999' style='border-collapse:collapse'>";
				divHtml+="<tr><td colspan='6' id='noExport" + partName + "'>&nbsp;" + MSG_NO_DATA_FOUND + "</td></tr>";
				var id = partName+"DiscrepancyList";
				document.getElementById(id).innerHTML = divHtml;
				
				if(flag){
					// hidding Discrepancy Detail and History div
					if(document.getElementById('detailRow')) document.getElementById('detailRow').style.display="none";
					if(document.getElementById('historyRow')) document.getElementById('historyRow').style.display="none";
				}
			} else {
				showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
			}
			return;
		} else {
			currentPage = discrepancyDetailVO.currentPage;
			pageNumber = discrepancyDetailVO.pageNumber;
			discrepancyListVO = discrepancyDetailVO.discrepancyListVO;
		}
		if(discrepancyListVO != null) {
			var tempSelectRow = preiousSelectedRow;
			if ('Part D' == partName){
				if(preiousSelectedRow >= 10){
					tempSelectRow = preiousSelectedRow - 10;
					dwr.util.setValue('selectRow',preiousSelectedRow);
				} else {
	 				tempSelectRow = -1 ;
				}
			}
			var discrepancyDetailVO = discrepancyListVO[tempSelectRow];
		    var discHistory = discrepancyDetailVOList.discrepancyHistoryVO;

			// When Discrepancy Type is 'BOTH' and User is trying to update any of discrepancy then,
			// the Pagination method called twice a time (First: for refreshing orignal list, Second : for refresh another type of dicrepancy)
			// This condition is used to avoid overwritten detail & History by another update pagination call
			// callByDiscUpdate : TRUE means, pagination is called by Discrepancy Update function
			// flag : TRUE means, updating for orignal discrepancy list.
			// 		  FALSE means, another pagination request (NOT TO ORVERWRITE DETAIL & HISTORY)
			if((callByDiscUpdate == false && showHistory == true) || (callByDiscUpdate == true && flag == true)){
			    if(discrepancyDetailVO != null) {
					setDiscrepancyDetail(discrepancyDetailVO,menuName);
					var discrepancy = discrepancyDetailVO.discrepancyCd ;
					if ( discrepancyDetailVO.discrepancyShortName != null && '' != discrepancyDetailVO.discrepancyShortName )
						discrepancy += ' - ' +   discrepancyDetailVO.discrepancyShortName ;
				}
				setDiscrepancyHistory(discHistory, discrepancy, menuName, "pagination");
			}
		}
		if ('Part C' == partName) {
		divHtml+='<tr id="exportPartC" style="display:none"><td></td></tr>'
		}else if('Part D' == partName){
		divHtml+='<tr id="exportPartD" style="display:none"><td></td></tr>'
		}
		divHtml+='<tr style="display:none" colspan="10"> <td id="selectRow">'+preiousSelectedRow +'</td></tr>'
	
		if(discrepancyListVO ==null || discrepancyListVO.length==0){
			divHtml+="<tr><td colspan='10'> &nbsp;</td></tr>";
			return ;
		} else {
			var j = 0 ;	
			var isPayDiscRow = false;
			for(var i = 0;i < discrepancyListVO.length ; i++ ){
				tempdiscListVO = discrepancyListVO[i];
				if ('Part D' == partName) 
					i += 10 ;
				var classCss = "class = ''";
				if( i == preiousSelectedRow ) {
				  classCss = "class='selectedRow bordered-table'"; // IFOX-00419340 added bordered-table
				} else if ( i % 2 == 0) {
				  classCss = "class='oddRow bordered-table'"; // IFOX-00419340 added bordered-table
				} else {
				  classCss = "class='evenRow bordered-table'"; // IFOX-00419340 added bordered-table
				}
				isPayDiscRow = false;
				if("LOADED" == tempdiscListVO.requestStatus) {
					if(i != preiousSelectedRow)
						classCss = "class='payDiscRow'";
					isPayDiscRow = true;
				}
				divHtml+="<tr "+ classCss +" id='"+i +"' isPayDiscRow='" + isPayDiscRow + "' style='cursor:pointer' onclick=\"useLoadingImage(this);javascript:getDiscrepancyDetail('"+i+"','"+tempdiscListVO.hicNumber+"',\'"+menuName +"\',\'"+partName+"\')\">";
				var h = tempdiscListVO.hicNumber;
				if (tempdiscListVO.csvAltHic != null && tempdiscListVO.csvAltHic != h) //Changes related to IFOX-00428448
				    h="*" + h;
				if (menuName == 'beneDiscrpDetail') 
					divHtml+='<td height="20"'+ classCss +' align="center" width="11%">'+h+'</td>';				
				else 
				  divHtml+='<td height="20"'+ classCss +' align="center" width="11%"><a href="#" onclick="submitHicNbrLink(\''+tempdiscListVO.hicNumber+'\',\''+i+'\')"  '+classCss+' >'+h+'</a></td>';
				
				divHtml+='<td '+ classCss +' align="center" width="7%" class="oddRow"  id="planName_'+i+'">'+ tempdiscListVO.planName ;	// IFOX-00431034 :: All-Plans in Discrepancy Drop down
				
				divHtml+='<td '+ classCss +' align="center" width="18%" class="oddRow"  id="discrepancyCd_'+i+'">'+ tempdiscListVO.discrepancyCd ;
				if(tempdiscListVO.discrepancyCd != ' ' ){
					divHtml+=' - ' + tempdiscListVO.discrepancyShortName ;
				}
				divHtml+='</td>';
				divHtml+='<td '+ classCss +' align="center" width="7%" id="pymtEffDate_'+i+'">'+ tempdiscListVO.pymtEffDate+"</td>";
				divHtml+='<td '+ classCss +' align="center" width="7%" id="discrepancyStatus_'+i+'">'+ tempdiscListVO.discrepancyStatus+"</td>";
				
				if ('Part C' == partName) {
					// making PBP ID as blank field for Part C, (not to show Pbp Id for selected row).
					divHtml+='<td '+ classCss +' align="center" width="6%">&nbsp;</td>';
				} else 
					divHtml+='<td '+ classCss +' align="center" width="6%" id="pbpId_'+i+'">'+ tempdiscListVO.pbpId+"</td>";
				if(tempdiscListVO.discrepancyType != '1' ) {
					divHtml+='<td '+ classCss +' align="center" width="11%" >'+ tempdiscListVO.cmsValue+"</td>";
					divHtml+='<td '+ classCss +' align="center" width="11%" >'+ tempdiscListVO.planValue+"</td>";
				} else {
					divHtml+='<td '+ classCss +' align="center" width="11%"  ></td>';
					divHtml+='<td '+ classCss +' align="center" width="11%  ></td>';
				}
					
				divHtml+='<td '+ classCss +' align="center" width="11%" id="lastUpdtUserID_'+i+'">'+ tempdiscListVO.lastUpdtUserID+"</td>";				
				divHtml+='<td '+ classCss +'align="center" width="10%" class="oddRow" id="shortlastUpdtDate_'+i+'">'+ tempdiscListVO.shortLastUpdtDate+"</td>";
				
				divHtml+='<td style="display:none" id="discrepancyIndicator_'+i+'">'+ tempdiscListVO.discrepancyIndicator+"</td>";
				divHtml+='<td style="display:none" id="dbHic_'+i+'">'+ tempdiscListVO.dbHic+"</td>";
				divHtml+='<td style="display:none" id="altHic_'+i+'">'+ tempdiscListVO.altHic+"</td>";
				divHtml+='<td style="display:none" id="cmsValue_'+i+'">'+ tempdiscListVO.cmsValue+"</td>";
				divHtml+='<td style="display:none" id="altCmsValue_'+i+'">'+ tempdiscListVO.altCmsValue+"</td>";
				divHtml+='<td style="display:none" id="planValue_'+i+'">'+ tempdiscListVO.planValue+"</td>";
				divHtml+='<td style="display:none" id="altPlanValue_'+i+'">'+ tempdiscListVO.altPlanValue+"</td>";
				divHtml+='<td style="display:none" id="requestStatus_'+i+'">'+ tempdiscListVO.requestStatus +"</td>";			
				divHtml+='<td style="display:none" id="planName_'+i+'">'+ tempdiscListVO.planName+"</td>";
				divHtml+='<td style="display:none" id="discrepancyType_'+i+'">'+ tempdiscListVO.discrepancyType+"</td>";
				divHtml+='<td style="display:none" id="createDate_'+i+'">'+ tempdiscListVO.createDate+"</td>";
				divHtml+='<td style="display:none" id="discrepancyCode_'+i+'">'+ tempdiscListVO.discrepancyCd+"</td>";
				if ('Part C' == partName) {
					divHtml+='<td style="display:none" id="pbpId_'+i+'">'+ tempdiscListVO.pbpId +"</td>";
				}
				divHtml+='<td style="display:none" id="writeOffInd_'+i+'">'+ tempdiscListVO.writeOffInd +"</td>";
				divHtml+='<td style="display:none" id="writeOffMethod_'+i+'">'+ tempdiscListVO.writeOffMethod +"</td>";
	
				divHtml+="</tr>";
				if ('Part D' == partName) 
					i -= 10 ;
			}
			divHtml+="<tr>";
			divHtml+="<td colspan='10' align='center' class='pageRow'>";
			if (menuName == 'beneDiscrpDetail' ) 
				divHtml+="<table width='50%' height='20'  border='0' align='right' cellpadding='0' cellspacing='0'><tr>";
			else
				divHtml+="<table width='50%' height='20'  border='0' align='right' cellpadding='0' cellspacing='0'><tr>";
				divHtml+="<td align='right'>Page# : <span id='pgNumber"+ partName +"'>"+pageNumber+ "</span>&nbsp;&nbsp;</td>";
			if( pageNumber == 1) {
				divHtml += '<td width="25px" align="center" ><img  title="First Page" src="/mss/jsp/Recon/images/Arrow_Page1.png" ></td>';
				divHtml += '<td width="25px" align="center"><img  title="Previous Page" src="/mss/jsp/Recon/images/Arrow_PageP.png"  ></td>';
			} else {
				divHtml += '<td width="25px" align="center" ><img  title="First Page" src="/mss/jsp/Recon/images/Arrow_Page1.png"  onclick="useLoadingImage(this);pagination(\'first\',\''+menuName+'\',\''+partName+'\', false, false);" style="cursor:pointer"></td>';
				divHtml += '<td width="25px" align="center"><img  title="Previous Page" src="/mss/jsp/Recon/images/Arrow_PageP.png" onclick="useLoadingImage(this);pagination(\'previous\',\''+menuName+'\',\''+partName+'\', false, false);" style="cursor:pointer"></td>';
			}
			if( currentPage == 'last') {
				divHtml += '<td width="25px" align="center"><img  title="Next Page" src="/mss/jsp/Recon/images/Arrow_PageN.png"  ></td>';
			} else {
				divHtml += '<td width="25px" align="center"><img  title="Next Page" src="/mss/jsp/Recon/images/Arrow_PageN.png"  onclick="useLoadingImage(this);pagination(\'next\',\''+menuName+'\',\''+partName+'\', false, false);" style="cursor:pointer"></td>';
			}
			if (menuName == 'beneDiscrpDetail' ) 
				divHtml += "<td width='30px' align='center'></td>";
			else
				divHtml += "<td width='6px' align='center'></td>";

				divHtml += "</tr></table></td>";
			divHtml+="</tr>";
		}
	
		divHtml+="</table>";
	}
	var id = partName+"DiscrepancyList";
	document.getElementById(id).innerHTML = divHtml;

	resetBodyHeight();
}	


function CBgetWorkQueueList(data, menuName, partName, flag, callByDiscUpdate) {
	discrepancyDetailVOList = data ;
	//discrepancyDetail,discrepancyHistory
	var divHtml="<table width='100%'  border='1' cellpadding='0' cellspacing='0' bordercolor='#999999' style='border-collapse:collapse;word-break:break-all'>";
	if( discrepancyDetailVOList == null ) {
		divHtml += "<tr><td colspan='10'>&nbsp;"+MSG_NO_DATA_FOUND+"</td></tr></table>";
		//document.getElementById('detailRow').style.display = 'none';
		//document.getElementById('historyRow').style.display = 'none';
	} else {
		
		var allPage = dwr.util.getValue('selectedIndexes');
		var currentPageCheck  = dwr.util.getValue('selectedPgNo');
		
		var allPages="false";
		if(allPage == "All"){
			allPages = "true";
		}
				
		preiousSelectedRow = discrepancyDetailVOList.selectedLine;
		var discrepancyListVO = null;
		var discrepancyDetailVO = null;
		var currentPage = "";
		var pageNumber = 1;
		var showHistory = false;
		
		
			if(preiousSelectedRow >= 0 && preiousSelectedRow  < 25)
				showHistory = true;
			
			discrepancyDetailVO = discrepancyDetailVOList.partCDiscrpDetailVO;
		
		
		// did not having any data List on pagination.
		if(discrepancyDetailVO == null ) {
			if(callByDiscUpdate){
				var pgNumber = dwr.util.getValue("pgNumber"+partName);
				if(pgNumber != "1" && flag){
					pagination("previous", menuName, partName, false, callByDiscUpdate);
					return;
				}
			
				// showing 'NO Data Found' msg onto hte UI.
				var divHtml="<table width='100%' border='1' cellpadding='0' cellspacing='0' bordercolor='#999999' style='border-collapse:collapse'>";
				divHtml+="<tr><td colspan='6' id='noExport" + partName + "'>&nbsp;" + MSG_NO_DATA_FOUND + "</td></tr>";
				var id = partName+"DiscrepancyList";
				document.getElementById(id).innerHTML = divHtml;
				
				if(flag){
					// hidding Discrepancy Detail and History div
					//if(document.getElementById('detailRow')) document.getElementById('detailRow').style.display="none";
					//if(document.getElementById('historyRow')) document.getElementById('historyRow').style.display="none";
				}
			} else {
				showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
			}
			return;
		} else {
			currentPage = discrepancyDetailVO.currentPage;
			pageNumber = discrepancyDetailVO.pageNumber;
			discrepancyListVO = discrepancyDetailVO.discrepancyListVO;
		}
		if(discrepancyListVO != null) {
			var tempSelectRow = preiousSelectedRow;
			if ('Part D' == partName){
				if(preiousSelectedRow >= 10){
					tempSelectRow = preiousSelectedRow - 10;
					dwr.util.setValue('selectRow',preiousSelectedRow);
				} else {
	 				tempSelectRow = -1 ;
				}
			}
			
		}
		if ('Part C' == partName) {
		divHtml+='<tr id="exportPartC" style="display:none"><td></td></tr>'
		}else if('Part D' == partName){
		divHtml+='<tr id="exportPartD" style="display:none"><td></td></tr>'
		}
		divHtml+='<tr style="display:none" colspan="10"> <td id="selectRow">'+preiousSelectedRow +'</td></tr>'
	
		if(discrepancyListVO ==null || discrepancyListVO.length==0){
			divHtml+="<tr><td colspan='10'> &nbsp;</td></tr>";
			return ;
		} else {
			var j = 0 ;	
			var isPayDiscRow = false;
			for(var i = 0;i < discrepancyListVO.length ; i++ ){
				tempdiscListVO = discrepancyListVO[i];
				
				var classCss = "class = ''";
				if( i == preiousSelectedRow ) {
				  classCss = "class='selectedRow bordered-table'"; // IFOX-00419340 added bordered-table
				} else if ( i % 2 == 0) {
				  classCss = "class='oddRow bordered-table'"; // IFOX-00419340 added bordered-table
				} else {
				  classCss = "class='evenRow bordered-table'"; // IFOX-00419340 added bordered-table
				}
				isPayDiscRow = false;
				if("LOADED" == tempdiscListVO.requestStatus) {
					if(i != preiousSelectedRow)
						classCss = "class='payDiscRow'";
					isPayDiscRow = true;
				}
				divHtml+="<tr "+ classCss +" id='"+i +"' isPayDiscRow='" + isPayDiscRow + "' style='cursor:pointer' onclick=\"useLoadingImage(this);javascript:getWokQueueDetail('"+i+"','"+tempdiscListVO.hicNumber+"',\'"+menuName +"\',\'"+partName+"\')\">";
				var h = tempdiscListVO.hicNumber;
				if (tempdiscListVO.csvAltHic != null)
				    h="*" + h;
				//Check for Select current Page checked
				var currentPageSel = "false";
				var all = document.getElementById('selectDisAll');
				//alert(currentPageCheck);
				//alert(pageNumber);
				if(all.checked && (parseInt(currentPageCheck) == pageNumber))
					currentPageSel = "true";
				
				//Check for individual checkboxes selected
				var selection = "false";
				if(parseInt(currentPageCheck) == pageNumber){
					if( allPage !=null && allPage != "" && allPage !="All"){
						
							var res = allPage.split("|");
							for (var j = 1; i < res.length; j++) {
							    if(i== parseInt(res[j]))
							    	selection ="true";
							}
						}
						
					}
				
				
				//if(allPages == "true" || ((selectedPageNo==pageNumber) && (document.getElementById(selectDisAll).checked)))
				if(allPages == "true" || currentPageSel =="true" || selection =="true" )
				  divHtml+='<td width="3%" align="center" id="checkbox_'+i+'"><input type="checkbox" name="SelectCheck" value="" checked = "checked" id="checkbox_'+i+'"></td>' ;
				else
					divHtml+='<td width="3%" align="center" id="checkbox_'+i+'"><input type="checkbox" name="SelectCheck" value=""  id="checkbox_'+i+'"></td>' ;
				 
				  divHtml+='<td height="10"'+ classCss +' align="center" width="10%"><a href="#" onclick="submitDiscLink(\''+tempdiscListVO.hicNumber+'\',\''+i+'\')"  '+classCss+' >'+h+'</a></td>';
				  divHtml+='<td '+ classCss +' align="center" width="5%" id="plan_'+i+'">'+ tempdiscListVO.planName+"</td>";
				 	
				divHtml+='<td '+ classCss +' align="center" width="13%" class="oddRow"  id="discrepancyCd_'+i+'">'+ tempdiscListVO.discrepancyCd ;
				if(tempdiscListVO.discrepancyCd != ' ' ){
					divHtml+=' - ' + tempdiscListVO.discrepancyShortName ;
				}
				divHtml+='</td>';
				 divHtml+='<td '+ classCss +' align="center" width="6%" id="discInd_'+i+'">'+ tempdiscListVO.discrepancyIndicator+"</td>";
					
				divHtml+='<td '+ classCss +' align="center" width="6%" id="pymtEffDate_'+i+'">'+ tempdiscListVO.pymtEffDate+"</td>";
				divHtml+='<td '+ classCss +' align="center" width="6%" id="discrepancyStatus_'+i+'">'+ tempdiscListVO.discrepancyStatus+"</td>";
				
				divHtml+='<td '+ classCss +' align="center" width="10%" >'+ tempdiscListVO.assignedBy+"</td>";
				divHtml+='<td '+ classCss +' align="center" width="10%" id="assignedTo_'+i+'" >'+ tempdiscListVO.assignedTo+"</td>";
				divHtml+='<td '+ classCss +'align="center" width="10%" class="oddRow" id="assignedOnDate_'+i+'">'+ tempdiscListVO.assignedOnDate+"</td>";	
				divHtml+='<td '+ classCss +' align="center" width="12%" id="lastUpdtUserID_'+i+'">'+ tempdiscListVO.lastUpdtUserID+"</td>";				
				divHtml+='<td '+ classCss +'align="center" width="10%" class="oddRow" id="shortlastUpdtDate_'+i+'">'+ tempdiscListVO.shortLastUpdtDate+"</td>";	
				/*divHtml+='<td '+ classCss +'align="center" width="14%" class="oddRow" id="comment_'+i+'">'+ tempdiscListVO.comment+"</td>";	
				*/
				divHtml+='<td style="display:none" id="comment_'+i+'">'+ tempdiscListVO.comment+"</td>";
				divHtml+='<td style="display:none" id="discrepancyIndicator_'+i+'">'+ tempdiscListVO.discrepancyIndicator+"</td>";
				divHtml+='<td style="display:none" id="dbHic_'+i+'">'+ tempdiscListVO.dbHic+"</td>";
				divHtml+='<td style="display:none" id="altHic_'+i+'">'+ tempdiscListVO.altHic+"</td>";
				divHtml+='<td style="display:none" id="cmsValue_'+i+'">'+ tempdiscListVO.cmsValue+"</td>";
				divHtml+='<td style="display:none" id="altCmsValue_'+i+'">'+ tempdiscListVO.altCmsValue+"</td>";
				divHtml+='<td style="display:none" id="planValue_'+i+'">'+ tempdiscListVO.planValue+"</td>";
				divHtml+='<td style="display:none" id="altPlanValue_'+i+'">'+ tempdiscListVO.altPlanValue+"</td>";
				divHtml+='<td style="display:none" id="requestStatus_'+i+'">'+ tempdiscListVO.requestStatus +"</td>";			
				divHtml+='<td style="display:none" id="planName_'+i+'">'+ tempdiscListVO.planName+"</td>";
				divHtml+='<td style="display:none" id="discrepancyType_'+i+'">'+ tempdiscListVO.discrepancyType+"</td>";
				divHtml+='<td style="display:none" id="createDate_'+i+'">'+ tempdiscListVO.createDate+"</td>";
				divHtml+='<td style="display:none" id="discrepancyCode_'+i+'">'+ tempdiscListVO.discrepancyCd+"</td>";
				
				divHtml+='<td style="display:none" id="writeOffInd_'+i+'">'+ tempdiscListVO.writeOffInd +"</td>";
				divHtml+='<td style="display:none" id="writeOffMethod_'+i+'">'+ tempdiscListVO.writeOffMethod +"</td>";
	
				
				divHtml+="</tr>";
				
			}
			divHtml+="<tr>";
			var rec = dwr.util.getValue('WRKQTotalRec');
			//alert(rec);
			var pages = dwr.util.getValue('WRKQTotalPages');
			divHtml+="<td colspan='12' align='center' class='pageRow'>";
			divHtml+="<table width='100%' height='20'  border='0' align='right' cellpadding='0' cellspacing='0'><tr>";
			divHtml+="<td align='left'>Total Records:<SPAN id='totalRecords'>"+rec+"</SPAN></td>";
			divHtml+="<td align='right'>Page# : <span id='pgNumberPartC'>"+pageNumber+ "</span>";
			divHtml+=" of <SPAN id='totalPages'>"+pages+"</SPAN>&nbsp;&nbsp;</td>";
			if( pages <= 1) {
				
				divHtml += '<td width="25px" align="center" ><img  title="First Page" src="/mss/jsp/Recon/images/Arrow_Page1.png" ></td>';
				divHtml += '<td width="25px" align="center"><img  title="Previous Page" src="/mss/jsp/Recon/images/Arrow_PageP.png"  ></td>';
			} else {
				
				divHtml += '<td width="25px" align="center" ><img  title="First Page" src="/mss/jsp/Recon/images/Arrow_Page1.png"  onclick="useLoadingImage(this);pagination(\'first\',\''+menuName+'\',\''+partName+'\', false, false);" style="cursor:pointer"></td>';
				divHtml += '<td width="25px" align="center"><img  title="Previous Page" src="/mss/jsp/Recon/images/Arrow_PageP.png" onclick="useLoadingImage(this);pagination(\'previous\',\''+menuName+'\',\''+partName+'\', false, false);" style="cursor:pointer"></td>';
			}
			if( pageNumber == pages) {
				divHtml += '<td width="25px" align="center"><img  title="Next Page" src="/mss/jsp/Recon/images/Arrow_PageN.png"  ></td>';
			} else {
				divHtml += '<td width="25px" align="center"><img  title="Next Page" src="/mss/jsp/Recon/images/Arrow_PageN.png"  onclick="useLoadingImage(this);pagination(\'next\',\''+menuName+'\',\''+partName+'\', false, false);" style="cursor:pointer"></td>';
			}
			
				divHtml += "<td width='6px' align='center'></td>";

				divHtml += "</tr></table></td>";
			divHtml+="</tr>";
		}
	
		divHtml+="</table>";
	}
	
	
	var id = "Part CDiscrepancyList";
	document.getElementById(id).innerHTML = divHtml;

	resetBodyHeight();
}	


/**
	This function get discrepancy type for partC/partD/Both on seleting radio button.
*/
function getDiscrpType(partName) {
	try {
		FacadeManager.getDiscrpType(partName,{
		  			callback:function(data) {
		  			var discCd = dwr.util.getValue("discCd");
		  			var arr =  {name:"",value:"All-All Discrepancies" };
					DWRUtil.removeAllOptions('discCd');
					dwr.util.addOptions("discCd", new Array(arr),'name','value');
					DWRUtil.addOptions('discCd',data,'name','value');
					dwr.util.setValue("discCd" , discCd);
					}
		  			});
	} catch(e) {
		showPopMessage("Error: "+e.message);
	}
}


/*
Author : Rakesh
Discription :  function called by "Cancel Write-Off" button For cancel write off request.
*/
function cancelDiscWriteOff(){
	var discVo = loadDiscrepancyVo();
	try{
		useLoadingImage(document.getElementById('butWriteCancelJPG'));
		FacadeManager.cancelWriteoffRequest(discVo, cbCancelWriteOffRequest);
	} catch(e) {
		showPopMessage("Error: "+e.message);
	}
}

/*
Author : Rakesh
Discriptoin: Call back handler of "FacadeManager.cancelWriteoffRequest" method
*/
function cbCancelWriteOffRequest(data){
	var cnt = parseInt(data, 10);
	if(cnt > 0){
		document.getElementById('updateButton').innerHTML= '<img id="butWriteOffJPG" src="/mss/jsp/Recon/images/but_writeoff.jpg" width="51" height="24" style="cursor:pointer" onclick="updateDiscWriteOff();">';	
		document.getElementById('discStatusMsgTD').innerHTML = LABEL_DISC_TYPE_PAYMENT_MSG;
		var selectedRow = dwr.util.getValue('selectRow');
		dwr.util.setValue('writeOffInd_' + selectedRow, 3);
		document.getElementById(selectedRow).setAttribute("isPayDiscRow", "false");
		showPopMessage(LABEL_CANCELED_WRITE_OFF_SUCCESS_MSG);
	}else
		showPopMessage(LABEL_CANCELED_WRITE_OFF_FAILURE_MSG);
}

/*
Author : Rakesh
Discription :  function called by "Write-Off" button For write off request.
*/
function updateDiscWriteOff(){
	var discVo = loadDiscrepancyVo();
	try{
		useLoadingImage(document.getElementById('butWriteOffJPG'));
		FacadeManager.updateDiscWriteOff(discVo, cbUpdateDiscWriteOff);
	}catch(e){
		showPopMessage("Error: "+e.message);
	}
}

/*
Author : Rakesh
Discriptoin: Call back handler of "FacadeManager.updateDiscWriteOff" method
*/
function cbUpdateDiscWriteOff(data){
	var updateCount = parseInt(data, 10);
	if(updateCount > 0 ){
		document.getElementById('updateButton').innerHTML= '&nbsp;<img id="butWriteCancelJPG" src="/mss/jsp/Recon/images/but_writecancel.jpg" width="84" height="24" style="cursor:pointer" onclick="cancelDiscWriteOff();" >';
		var selectedRow = dwr.util.getValue('selectRow');
		document.getElementById(selectedRow).setAttribute("isPayDiscRow", "true");

		var discStatusMsg = LABEL_DISC_TYPE_PAYMENT_MSG + ", " + LABEL_WRITE_OFF_PENDING_MSG;
		document.getElementById('discStatusMsgTD').innerHTML = discStatusMsg;
		dwr.util.setValue('writeOffInd_' + selectedRow, 2);
		dwr.util.setValue('requestStatus_' + selectedRow, "LOADED");
		showPopMessage(LABEL_UPDATE_WRITE_OFF_SUCCESS_MSG);
	} else 
		showPopMessage(LABEL_UPDATE_WRITE_OFF_FAILURE_MSG);
}

/*
Author : Rakesh
Discription : Funtion updateDiscStatus is called by "update" buttun for Discrepancy status update.
*/
function updateDiscStatus(menuName){
	var discVo = loadDiscrepancyVo();

	if("OPEN" == discVo.newDiscrepancyStatus){ 
		showPopMessage('The "' + discVo.newDiscrepancyStatus + LABEL_DISC_UDPATE_STATUS_OPEN_MSG);
		return;
	} else if( "RSLV" == discVo.newDiscrepancyStatus || "RTOL" == discVo.newDiscrepancyStatus || "WRTO" == discVo.newDiscrepancyStatus || "WRTD" == discVo.newDiscrepancyStatus || "INTG" == discVo.newDiscrepancyStatus){
		showPopMessage('The "' + discVo.newDiscrepancyStatus + LABEL_DISC_UDPATE_STATUS_RSLV_RTOL_WRTO_MSG);
		return;
		//IFOX: 00407323 : users will not be able to update status to INFO: start	
		//} else if("CPND" == discVo.newDiscrepancyStatus){	
	} else if("CPND" == discVo.newDiscrepancyStatus || "INFO" == discVo.newDiscrepancyStatus){ 
		//IFOX: 00407323 : users will not be able to update status to INFO: end	 
		showPopMessage('The "' + discVo.newDiscrepancyStatus + LABEL_DISC_UDPATE_STATUS_SYS_USE_MSG);
		return;
	}
	//IFOX : 00401705 : start - added a check for length of comments 
	//alert(discVo.newComment);
	if(discVo.newComment != null && discVo.newComment != "" && discVo.newComment.length > 255){
		alert("Comments entered cannot be more than 255 character. Please enter valid comment!");
		return;
	}
	//IFOX : 00401705 : end - added a check for length of comments
	try{
		if(document.getElementById('butUpdateJPG'))
		useLoadingImage(document.getElementById('butUpdateJPG'));
		var rowId = dwr.util.getValue('selectRow');
		FacadeManager.updateDiscrepancyStatus(discVo, menuName, rowId, {
		  			callback:function(data) {
			   			cbUpdateDiscrepancyStatus(data,menuName);}
		  			});
		
	}catch(e){
		showPopMessage("Error: "+e.message);
	}
}

/*
Author : Rakesh
Discriptoin: Call back handler of "FacadeManager.updateDiscrepancyStatus" method
INPUT : data is a Array, having 2 Fields
data[0] : VALUE (0 OR 1) where  { 0 : failed, 1 :pass}
data[1] : Latest Updated DiscrepancyListVO (used to udpate UI)
*/
function cbUpdateDiscrepancyStatus(data, menuName){
	var dataArr = data;
	if(dataArr != null && data.count > 0){
		var discListVO = dataArr.detail;
		if(discListVO != null){
		    var discrepancy = discListVO.discrepancyCd ;
			setDiscrepancyHistory(data,discrepancy,menuName);

		}
		showPopMessage(LABEL_DISC_STATUS_UPDATE_SUCCESS_MSG);
	}else {
		if(dataArr != null && data.count == 0)
			showPopMessage(LABEL_DISC_STATUS_UPDATE_MODIFIED_MSG);
		else
			showPopMessage(LABEL_DISC_STATUS_UPDATE_FAILURE_MSG);
	}
}

function setLatestDiscrepancyInfo(discListVO){
	if(discListVO != null){
		var rowId = dwr.util.getValue('selectRow');
		// updating the status, comments, lastUpdateId, lastUpdateUser
		if(discListVO.lastUpdtDate != null){
			var tempLastUpdateDate = discListVO.lastUpdtDate;
			discListVO.shortLastUpdtDate = tempLastUpdateDate.substr(0, 10);
			discListVO.lastUpdtDateTillSeconds = tempLastUpdateDate.substr(0, 19);
		}

		dwr.util.setValue("shortlastUpdtDate_"+rowId, discListVO.shortLastUpdtDate); // to show in List
		dwr.util.setValue("discrepancyStatus_"+rowId, discListVO.discrepancyStatus);
		dwr.util.setValue("lastUpdtUserID_"+rowId, discListVO.lastUpdtUserID);

	}
}


/*
Author : Rakesh
Discription : function "loadDiscrepancyVo" will create DiscrepancyListVO object, 
	fatch data from UI and will return to calling method.
*/
function loadDiscrepancyVo(){
	var discVo ={ hicNumber:null, altHic:null, dbHic:null, discrepancyCd:null, newComment:null, newDiscrepancyStatus:null, discrepancyType:null, discrepancyStatus:null, discrepancyIndicator:null,
			cmsValue:null, writeOffInd:null, planValue:null, pymtEffDate:null, createDate:null, pbpId:null, comment:null, 
			lastUpdtDate:null, lastUpdtUserID:null, firstName:null, lastName:null, effDateSuppId:null ,mostRecentSuppId:null, pbpSegmentId:null, writeOffMethod:null};

	var selectedRow = dwr.util.getValue('selectRow');	
    discVo.altHic = dwr.util.getValue('altHic_' + selectedRow);
    discVo.dbHic = dwr.util.getValue('dbHic_' + selectedRow);
	discVo.pbpId =dwr.util.getValue('pbpId');
	discVo.writeOffInd = dwr.util.getValue('writeOffInd_' + selectedRow);
	discVo.requestStatus = dwr.util.getValue('requestStatus_'+ selectedRow);
	discVo.discrepancyCd = dwr.util.getValue('discrepancyCode_' + selectedRow);
	discVo.discrepancyType = dwr.util.getValue('discrepancyType_' + selectedRow);
	discVo.discrepancyIndicator	= dwr.util.getValue("discrepancyIndicator_" + selectedRow);
	discVo.pbpSegmentId = dwr.util.getValue('pbpSegmentId');
	discVo.planName = dwr.util.getValue("planName_" + selectedRow); 	//IFOX-00431034 :: All-Plans in Discrepancy Drop down
	discVo.hicNumber = dwr.util.getValue("hicNumber");
//discVo.applyTo = dwr.util.getValue("applyTo");
	discVo.effDateSuppId = dwr.util.getValue("effDateSuppId");
	discVo.mostRecentSuppId	= dwr.util.getValue("mostRecentSuppId");
	discVo.firstName = dwr.util.getValue("firstName");
	discVo.lastName	= dwr.util.getValue("lastName");
	discVo.pymtEffDate = dwr.util.getValue("pymtEffDate");
	discVo.pymtApplyDate = dwr.util.getValue("pymtApplyDate");
	discVo.createDate = dwr.util.getValue("createDate");
	discVo.shortCreateDate = dwr.util.getValue("shortCreateDate");
	discVo.lastUpdtDate	= dwr.util.getValue("lastUpdtDate");
	discVo.lastUpdtDateTillSeconds	= dwr.util.getValue("lastUpdtDateTillSeconds");
	discVo.lastUpdtUserID = dwr.util.getValue("lastUpdtUserID");
	discVo.cmsValue	= dwr.util.getValue("cmsValue");
	discVo.planValue = dwr.util.getValue("planValue");
	discVo.discrepancyStatus = dwr.util.getValue("discreStatus");
	discVo.comment = dwr.util.getValue("showComment");
	discVo.newDiscrepancyStatus = dwr.util.getValue('discrepancyStatus');
	discVo.newComment = dwr.util.getValue('comment');
	discVo.writeOffMethod = dwr.util.getValue("writeOffMethod_" + selectedRow);

	return discVo;
}
