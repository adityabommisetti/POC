/* $Id: raps.js,v 1.1 2014/06/26 07:57:06 praveen Exp $ */
isOpen = top.isOpen;

function showLoading(){
	document.getElementById("loadingGIF").style.display = "block"
}

function hideLoading(){
	document.getElementById("loadingGIF").style.display = "none"
}


/* This method find out the expanded item and do a submit */
function saveAndSubmit(formRef) {
	var pageName =  formRef.pageName.value; 
    saveUiContext(formRef, pageName);
	dataArray = uiContext.join("|");
    formRef.uiContext.value = dataArray;
    submitAction(formRef);
    formRef.uiContext.value = ""; //reset it in case of error
}

/* This method is called when an item is selected on summary dashboard. */
function submitRapsDB(searchType, planName, year, month, searchStatus) {
 	month = getMonthValue(month);
	var formRef = document.forms ['RAPSForm'];
	var fromDate = dwr.util.getValue(START_DATE);
	var toDate = dwr.util.getValue(END_DATE);
	if(searchType == 'year' ) { 
		fromDate = '01/'+year;
		toDate = '12/' +year;			
	} else if (searchType =='month' ) { 
		fromDate = month +'/' +year;
		toDate =  month +'/'+year;
	} 
	dwr.util.setValue(PLAN_SEARCH, planName);

	formRef.status.value = searchStatus;
	formRef.planName.value = planName;	
	formRef.fromDate.value = fromDate;
	formRef.toDate.value = toDate;
	formRef.searchType.value = searchType;
	saveAndSubmit(formRef);
}

//This method is used to move between subTab or when GO button is selected
function submitRapsLink(methodName) {
	document.body.className = 'wait';
	if (methodName.substr(0,6) == "search") { 
	    //go button. 
		if(isBlankOrNULL("hicNbr") == false && validateAlphaNumaric("hicNbr") == false){
			showPopMessage(MSG_INVALID_HIC_NUMBER, function(){
				setElementFocus("hicNbr");
			});
			return false;
		}
	    var pageName = dwr.util.getValue('pageName');
	    if (pageName=="rapsDashboard" || pageName=="rapsClaimsDashboard"){
			var fld="Service Date";
			if (pageName=="rapsClaimsDashboard") fld="Submission Date";
            if (!validate2Date("fromDate","toDate","",fld))
                return false;
	    }
	    else {
    		if(pageName=="rapsClaimsDetail" && isBlankOrNULL("planName")){ // Plan Name req
    			showPopMessage(REQUIRED_PLAN_NAME, function(){
    				setElementFocus("planName");
    			});
    			return false;
    		}
    		if(isBlankOrNULL("claimId") == false) {
    		    var val = dwr.util.getValue("claimId");
                if (val.indexOf(",") != -1 || val.indexOf("/") != -1 || val.indexOf("\\") != -1 ||
                val.indexOf("'") != -1 || val.indexOf("\"") != -1) {
         			showPopMessage("Invalid Claim ID", function(){
        				setElementFocus("claimId");
        			});
        			return false;
    		    }    		    
    		}
			var fld="Service Date";
			if (pageName=="rapsClaimsDetail") fld="Submission Date";
            if (!validate2Date("fromDate","toDate","Update",fld))
                return false;
                
            if(pageName=="rapsDetail"){
	            if(isBlankOrNULL("hcc") == false && isBlankOrNULL("hicNbr") == true) {
	            	showPopMessage("Medicare ID is required when searching by HCC", function(){
						setElementFocus("hicNbr");
					});
					return false;
	            }
	            
	            if(isBlankOrNULL("hicNbr") == true) {
	            	var sort = dwr.util.getValue("sortBy");
	            	if (sort != "date") {
		            	showPopMessage("Medicare ID is required when sorting by Diagnosis or HCC", function(){
							setElementFocus("hicNbr");
						});
						return false;
					}
	            }
            }
	    }
    }
    else if (methodName=="validateInput") {
        if (isBlankOrNULL("hicNbr")) {
            showPopMessage(REQUIRED_HIC_NUM, function(){
						setElementFocus("hicNbr");});
		    return false;
		}
        if (!validate2Date("fromDate","toDate","Update","Service Date"))
            return false;
        if (isBlankOrNULL("diagCd")) {
            showPopMessage("Diagnosis Code is required", function(){
						setElementFocus("diagCd");});
		    return false;
		}
    }
	var formRef = document.forms ['RAPSForm'];
	formRef.method.value = methodName;
	saveAndSubmit(formRef);
}

//This method is used to move to a new MAIN tab
function switchRapsTab(newTab) {
	document.body.className = 'wait';
	var formRef = document.forms ['RAPSForm'];
	formRef.menuName.value = newTab;
	formRef.action="switchRapsTab.do";
	saveAndSubmit(formRef);
	document.body.className = '';
}

/* Populate Raps summary Detail page. */
function CBgetRapsDetailPage(data, move, menuName) {
	var rapsDetailPage = data ;
	var dh="<table width='100%'  border='1' cellpadding='0' cellspacing='0' bordercolor='#999999' style='border-collapse:collapse;word-break:break-all'>";
	if( rapsDetailPage == null ) {
		showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
		var nextPageImg = document.getElementById("nextPageImg");
		nextPageImg.onclick = function(){
				showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
			};
		return;
	} else {
		prevSelectedRow = rapsDetailPage.selectedLine;
		var pdeDetailVO = null;
		var currentPage = "";
		var pageNumber = 1;
		currentPage = rapsDetailPage.currentPage;
		pageNumber = rapsDetailPage.pageNumber;
		rapsDetails = rapsDetailPage.rapsDetails;
		dh+='<tr style="display:none" colspan="8"> <td id="selectRow">'+prevSelectedRow +'</td></tr>'
		var selectedRowPdeSeqNum = -1;

		if(rapsDetails ==null || rapsDetails.length==0){
			// means there is not more data, show appropriate message on screen.
			showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
			var nextPageImg = document.getElementById("nextPageImg");
			nextPageImg.onclick = function(){
				showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
			};
			return;
		} else {
			var j = 0 ;	
			for(var i = 0;i < rapsDetails.length ; i++ ){
				rdi = rapsDetails[i];
				var ccss = "class = ''";
				if( i == prevSelectedRow ) 
				  ccss = "class='selectedRow'";
				else if ( i % 2 == 0) 
				  ccss = "class='oddRow'";
				else 
				  ccss = "class='evenRow'";
				dh+='<tr style="display:none" colspan="8"> <td id="selectRow">'+prevSelectedRow +'</td></tr>'
                var temp =  "<tr "+ ccss +" id='"+i +"' style='cursor:pointer' onclick=\"useLoadingImage(this);javascript:getRapsDetail('detail','" + i + "')\">";					
                dh+= temp;
				dh+='<td align="center" '+ ccss +' width="6%" id="planId_'+i+'">'+ rdi.planID+"</td>";
				dh+='<td align="center" '+ ccss +' width="10%" id="hicNbr_'+i+'">'+ rdi.hicNbr+"</td>";
				dh+='<td align="center" '+ ccss +' width="12%" id="fromService_'+i+'">'+ rdi.fromServiceDate+"</td>";
				dh+='<td align="center" '+ ccss +' width="12%" id="thruService_'+i+'">'+ rdi.thruServiceDate+"</td>";
				dh+='<td align="center" '+ ccss +' width="10%">'+ rdi.statusDisplay+"</td>";
				dh+='<td '+ ccss +' width="27%" id="diagDisplay_'+i+'">'+ rdi.diagCodeDisplay+"&nbsp;&nbsp;</td>";
				dh+='<td align="center" '+ ccss +' width="5%" id="hcc_'+i+'">'+ rdi.hcc+"</td>";
				dh+='<td align="center" '+ ccss +' width="7%" id="rxhcc_'+i+'">'+ rdi.rxhcc+"</td>";
				dh+='<td align="center" '+ ccss +' width="5%" id="dup_'+i+'">'+ rdi.dup+"</td>";
				dh+='<td align="center" '+ ccss +' width="6%" id="resub_'+i+'">'+ rdi.resub+"</td>";
				dh+='<td style="display:none" id="status_'+i+'">'+ rdi.clusterStatus+"</td>";				
				dh+='<td style="display:none" id="diagCode_'+i+'">'+ rdi.diagCode+"</td>";				
				dh+='<td style="display:none" id="provType_'+i+'">'+ rdi.providerType+"</td>";				
				dh+='<td style="display:none" id="dcType_'+i+'">'+ rdi.dcType+"</td>";				
				dh+="</tr>";
			}
			dh += paintArrows(pageNumber, currentPage, menuName, 10);			
			
			CBgetRapsDetail(rapsDetailPage.detailInfo);
			// update history
			CBRapsHistory(rapsDetailPage.historyItems);
		}
		dh+="</table>";
	}
	var id = "rapsEventDetailDiv";
	document.getElementById(id).innerHTML = dh;
	resetBodyHeight();
}
	
/* called when a row is selected on detail page */
function getRapsDetail(menuName, rowId) {
	try {
		prevSelectedRow = dwr.util.getValue('selectRow');
		var className = "oddRow";
		var bgColor = "oddRowRed";
		if(prevSelectedRow % 2 =='1'  ) {
			bgColor = "evenRowRed";
			className = "evenRow";
		}
		applyClassOnTdTag(className, prevSelectedRow);
		dwr.util.setValue('selectRow', rowId); 
		applyClassOnTdTag("selectedRow", rowId); //apply selected row style class.
		
		if( menuName == 'detail' ) {
		    var detail = { planID:null, hicNbr:null, fromServiceDate:null, thruServiceDate:null, diagCode:null, 
		        providerType:null, dcType:null};
	        detail.planID=dwr.util.getValue('planId_'+rowId);
	        detail.hicNbr=dwr.util.getValue('hicNbr_'+rowId);
	        detail.fromServiceDate=dwr.util.getValue('fromService_'+rowId);
	        detail.thruServiceDate=dwr.util.getValue('thruService_'+rowId);
	        detail.diagCode=dwr.util.getValue('diagCode_'+rowId);
	        detail.providerType=dwr.util.getValue('provType_'+rowId);
	        detail.dcType=dwr.util.getValue('dcType_'+rowId);
		    FacadeManager.getRapsDetail(rowId, detail ,{
								  			callback:function(data) {
	                                    var rapsDetailPage = data ;
			                            CBgetRapsDetail(rapsDetailPage.detailInfo);
			                            CBRapsHistory(rapsDetailPage.historyItems);
								  			}});
		}	
		else if( menuName == 'claim' ) {
            var detail = { claimId:null, version:null, submissionDate:null, hicNumber:null, multiple:null, hcc:null,
                mfId:null, syntheticFileId:null, physicalRecNbr:null};
	        detail.claimId=dwr.util.getValue('claimId_'+rowId);
	        detail.version=dwr.util.getValue('version_'+rowId);
	        detail.submissionDate=dwr.util.getValue('submissionDate_'+rowId);
	        detail.hicNumber=dwr.util.getValue('hicNumber_'+rowId);
	        detail.multiple=dwr.util.getValue('mul_'+rowId);
	        detail.hcc=dwr.util.getValue('hcc_'+rowId);
	        detail.mfId=dwr.util.getValue('mfId_'+rowId);
	        detail.syntheticFileId=dwr.util.getValue('syntheticFileId_'+rowId);
	        detail.physicalRecNbr=dwr.util.getValue('physicalRecNbr_'+rowId);
		    FacadeManager.getRapsClaimDetail(rowId, detail ,{
								  			callback:function(data) {
	                                    var rapsClaimsDetailPage = data ;
			                            CBgetRapsClaimDetail(rapsClaimsDetailPage.detailInfo);
			                            paintRapsAdditionalInfo(rapsClaimsDetailPage.moreInfo);
			                            CBRapsClaimHistory(rapsClaimsDetailPage.historyItems);
								  			}});
		}	
		else if( menuName == 'errors' ) {
		    var detail = { planID:null, hicNbr:null, fromServiceDate:null, thruServiceDate:null, diagCode:null, 
		        providerType:null, dcType:null};
	        detail.planID=dwr.util.getValue('planId_'+rowId);
	        detail.hicNbr=dwr.util.getValue('hicNbr_'+rowId);
	        detail.fromServiceDate=dwr.util.getValue('fromService_'+rowId);
	        detail.thruServiceDate=dwr.util.getValue('thruService_'+rowId);
	        detail.diagCode=dwr.util.getValue('diagCode_'+rowId);
	        detail.providerType=dwr.util.getValue('provType_'+rowId);
	        detail.dcType=dwr.util.getValue('dcType_'+rowId);
		    FacadeManager.getRapsErrorsDetail(rowId, detail ,{
								  			callback:function(data) {
	                                    var rapsErrorsPage = data ;
			                            CBgetRapsErrorsDetail(rapsErrorsPage.errorsInfo);
			                            CBRapsErrorsHistory(rapsErrorsPage.errorsHistoryItems);
								  			}});
		}
	} catch(e) {
		showPopMessage("Error: "+e.message);
	}
}

function openRapsPrint() {
    document.getElementById('pop_container').style.height=document.getElementById('rapsbody').scrollHeight;
    document.getElementById('pop_container').style.width=document.getElementById('rapsbody').scrollWidth;
    showExportPrintDialog();
}

function rapsPagination(move, menuName){
	 try{
		 if(menuName == 'detail') { 
			FacadeManager.getRapsDetailPage(move, {
								callback:function(data) {
								CBgetRapsDetailPage(data, move, menuName); 
								}});
		 }
		 else if(menuName == 'claim') { 
			FacadeManager.getRapsClaimDetailPage(move, {
								callback:function(data) {
								CBgetRapsClaimDetailPage(data, move, menuName); 
								}});
		 }
		 else if(menuName == 'errors') { 
			FacadeManager.getRapsErrorsPage(move, {
								callback:function(data) {
								CBgetRapsErrorsPage(data, move, menuName); 
								}});
		 }
	}catch(e){
		showPopMessage("Error: "+e.message);
	}
}

function CBRapsHistory(data) {
 
	var historyArr = data;
	var rapsHistory={action:null,status:null,sourceType:null,sourceRef:null,lastUpdate:null,userId:null};
	var dh="<table width='100%' border='1' cellpadding='0' cellspacing='0' bordercolor='#999999' style='border-collapse:collapse'>";
	if(historyArr == null ||  historyArr.length == 0)
		dh+="<tr><td colspan='6'>&nbsp;" + MSG_NO_DATA_FOUND + "</td></tr>";
	else {
		for(var i=0 ; i < historyArr.length ; i++) {
			rapsHistory=historyArr[i];
			if( i %2 == 0 ) {
				dh+="<tr class='oddRow'>";
			} else {
				dh+="<tr class='evenRow'>";
			}
			dh+="<td width='24%' align='center'>"+rapsHistory.action +"</td>";
			dh+="<td width='10%' align='center'>"+rapsHistory.status+"</td>";
			dh+="<td width='12%' align='center'>"+rapsHistory.sourceType+"</td>";
			dh+="<td width='24%' align='center'>"+rapsHistory.sourceRef+"</td>";
			dh+="<td width='15%' align='center'>"+rapsHistory.lastUpdate+"</td>";
			dh+="<td width='15%' align='center'>"+rapsHistory.userId+"</td>";
			dh+="</tr>";
		}
	}
	dh+=" </table>";
	document.getElementById("rapsHistoryDiv").innerHTML=dh;
	resetBodyHeight();
}

function CBgetRapsClaimDetailPage(data, move, menuName) {
	var rapsClaimsDetailPage = data ;
	var dh="<table width='100%'  border='1' cellpadding='0' cellspacing='0' bordercolor='#999999' style='border-collapse:collapse;word-break:break-all'>";
	if( rapsClaimsDetailPage == null ) {
		showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
		var nextPageImg = document.getElementById("nextPageImg");
		nextPageImg.onclick = function(){
				showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);};		
		return;
	} else {
		prevSelectedRow = rapsClaimsDetailPage.selectedLine;
		var currentPage = "";
		var pageNumber = 1;
		currentPage = rapsClaimsDetailPage.currentPage;
		pageNumber = rapsClaimsDetailPage.pageNumber;
		rapsDetails = rapsClaimsDetailPage.claimsList;
		dh+='<tr style="display:none" colspan="6"> <td id="selectRow">'+prevSelectedRow +'</td></tr>'
		var selectedRowPdeSeqNum = -1;

		if(rapsDetails ==null || rapsDetails.length==0){
			// means there is no more data, show appropriate message on screen.
			showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
			var nextPageImg = document.getElementById("nextPageImg");
			nextPageImg.onclick = function(){
				showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
			};			
			return;
		} else {
			var j = 0 ;				
			for(var i = 0;i < rapsDetails.length ; i++ ){
				it = rapsDetails[i];
				var ccss = "class = ''";
				if( i == prevSelectedRow ) 
				  ccss = "class='selectedRow'";
				else if ( i % 2 == 0) 
				  ccss = "class='oddRow'";
				 else 
				  ccss = "class='evenRow'";
				dh+='<tr style="display:none" colspan="6"> <td id="selectRow">'+prevSelectedRow +'</td></tr>'
                var temp =  "<tr "+ ccss +" id='"+i +"' style='cursor:pointer' onclick=\"useLoadingImage(this);javascript:getRapsDetail('claim','" + i + "')\">";				
                dh+= temp;
				dh+='<td '+ ccss +' width="40%" align="center" id="claimId_'+i+'">'+ it.claimId+"</td>";
				dh+='<td '+ ccss +' width="10%" align="center" id="version_'+i+'">'+ it.version+"</td>";
				dh+='<td '+ ccss +' width="15%" align="center" id="submissionDate_'+i+'">'+ it.submissionDate+"</td>";
				dh+='<td '+ ccss +' width="15%" align="center" id="hicNumber_'+i+'">'+ it.hicNumber+"</td>";
				dh+='<td '+ ccss +' width="10%" align="center" id="mul_'+i+'">'+ it.multiple+"</td>";
				dh+='<td '+ ccss +' width="10%" align="center" id="hcc_'+i+'">'+ it.hcc+"&nbsp;&nbsp;</td>";				
				dh+='<td style="display:none" id="mfId_'+i+'">'+ it.mfId+"</td>";				
				dh+='<td style="display:none" id="syntheticFileId_'+i+'">'+ it.syntheticFileId+"</td>";				
				dh+='<td style="display:none" id="physicalRecNbr_'+i+'">'+ it.physicalRecNbr+"</td>";				
				dh+="</tr>";
			}
            dh += paintArrows(pageNumber, currentPage, menuName, 6);			
			CBgetRapsClaimDetail(rapsClaimsDetailPage.detailInfo);
			paintRapsAdditionalInfo(rapsClaimsDetailPage.moreInfo);
			CBRapsClaimHistory(rapsClaimsDetailPage.historyItems);
		}
		dh+="</table>";
	}
	var id = "rapsEventDetailDiv";
	document.getElementById(id).innerHTML = dh;
	resetBodyHeight();
}

function CBgetRapsClaimDetail(rdi) {
	if(rdi == null){
		showPopMessage("detail information is empty");
		return;
	}
	dwr.util.setValue("plan", rdi.planName);
	dwr.util.setValue("detailHic",rdi.hicNbr);
	dwr.util.setValue("mbi",rdi.mbi);
	dwr.util.setValue("corrHic",rdi.correctedHic);
	dwr.util.setValue("lastName",rdi.lastName);
	dwr.util.setValue("firstName",rdi.firstName);
	dwr.util.setValue("dob",rdi.dob);
	dwr.util.setValue("clId",rdi.claimId);
	dwr.util.setValue("version",rdi.version + " " + rdi.multipleStatus );
	dwr.util.setValue("patientCtrl",rdi.patientControlNo);
	dwr.util.setValue("memberId",rdi.memberId);
	dwr.util.setValue("pos",rdi.posOrBillType);
	dwr.util.setValue("claimType",rdi.claimType);
	dwr.util.setValue("npi",rdi.npi);
	dwr.util.setValue("taxo",rdi.taxonomy);
	dwr.util.setValue("subDate",rdi.submissionDate);
	dwr.util.setValue("subType",rdi.submissionType);
	dwr.util.setValue("fileId",rdi.fileId);
	dwr.util.setValue("seqNo",rdi.physRecordNbr);
	CBRapsDiagCodes(rdi.diagCodes, rdi.diagCodeCount);
    return; 
}
/* repaint + RAPS Details on summary detail */
function CBgetRapsDetail(det) {
	if(det == null){
		showPopMessage("Raps Detail is Null");
		return;
	}
	dwr.util.setValue("plan", det.planName);
	dwr.util.setValue("detailHic",det.hicNbr);
	dwr.util.setValue("mbi",det.mbi);
	dwr.util.setValue("lastName",det.lastName);
	dwr.util.setValue("firstName",det.firstName);
	dwr.util.setValue("dob",det.dob);
	dwr.util.setValue("cs",det.clusterStatus);
	dwr.util.setValue("xms",det.xmitStatus);
	dwr.util.setValue("cmse",det.cmsError);
	dwr.util.setValue("dup",det.duplicate);
	dwr.util.setValue("resub",det.resubmission);
	dwr.util.setValue("pcn",det.patientControlNo);
	dwr.util.setValue("fsd",det.fromServiceDate);
	dwr.util.setValue("tsd",det.thruServiceDate);
	dwr.util.setValue("pt",det.providerType+" - " + det.providerDescr);
	dwr.util.setValue("dc",det.diagCode);
	dwr.util.setValue("dcd",det.diagDescription);
	//now paint the diagnosis
	var diags = det.diagCodelist;
	var dh="<table width='100%' border='0' cellpadding='0' cellspacing='0' bordercolor='#eeeeee' class='subheadRow'>";
	if(diags != null &&  diags.length > 0) {
		for(var i=0 ; i < diags.length ; i++) {
			var diag=diags[i];
			dh+="<tr><td width='14%' class='ftr'>"+diag.displayId +"&nbsp;&nbsp;HCC Position :&nbsp;</td>";
			dh+="<td width='19%' ><table width='100%' border='0' cellspacing='0' cellpadding='0'>";
			dh+="<tr><td width='12%' align='right'>"+diag.pos +"</td>";
			dh+="<td width='44%' class='ftr'>HCC Code :&nbsp;</td>";
			dh+="<td width='44%' align='left'>"+diag.indAndCode +"</td></tr></table></td>";
			dh+="<td  width='14%' class='ftr'>Description :&nbsp;</td>";
			dh+="<td colspan='3'>"+diag.description +"</td>";
			dh+="</tr>";
		}
	}
    dh+="</table>";
	document.getElementById("diagDiv").innerHTML=dh;
	var b = document.getElementById('del');
	if (det.deleteType == 0) 
        b.disabled =true;
	else 
        b.disabled=false;
	CBRapsSources(det.sources);
	CBRapsErrors(det.errors);
	resetBodyHeight();

return; 
}

function paintRapsAdditionalInfo(addInfo) {
	var e = document.getElementById("infoflag");
	if(addInfo.hasInfo){ 
	    e.innerHTML= " ";
	    e.className='xxx';
	}
	else {
	    e.innerHTML= "No Information Found";
	    e.className='red';
    }
	dwr.util.setValue("mrn", addInfo.medicalRecNbr);
	dwr.util.setValue("ib",addInfo.insuredPlanName);
	dwr.util.setValue("mln",addInfo.lastName);
	dwr.util.setValue("mfn",addInfo.firstName);
	dwr.util.setValue("imn",addInfo.middleName);
	dwr.util.setValue("ppid",addInfo.provPCPId);
	dwr.util.setValue("paid",addInfo.profAfflId);
	dwr.util.setValue("rpnpi",addInfo.refProvNpi);
	dwr.util.setValue("sfnpi",addInfo.facNPI);
	dwr.util.setValue("bpn",addInfo.billingProviderName);
	dwr.util.setValue("ba",addInfo.billingAddr);
	dwr.util.setValue("bc",addInfo.billingCity);
	dwr.util.setValue("bs",addInfo.billingState);
	dwr.util.setValue("bz",addInfo.billingZip);
	dwr.util.setValue("bp",addInfo.billingPhone);
	dwr.util.setValue("drg",addInfo.drg);
    return; 
}
function CBRapsClaimHistory(data) {
	var historyArr = data;
	var dh="<table width='100%' border='1' cellpadding='0' cellspacing='0' bordercolor='#999999' style='border-collapse:collapse'>";
	if(historyArr == null ||  historyArr.length == 0)
		dh+="<tr><td colspan='5'>&nbsp;" + MSG_NO_DATA_FOUND + "</td></tr>";
	else {
		for(var i=0 ; i < historyArr.length ; i++) {
			var rapsHistory=historyArr[i];
			if( i %2 == 0 ) 
				dh+="<tr class='oddRow'>";
			else 
				dh+="<tr class='evenRow'>";
			dh+="<td width='20%' align='center'>"+rapsHistory.action +"</td>";
			dh+="<td width='40%' align='center'>"+rapsHistory.comment+"</td>";
			dh+="<td width='25%' align='center'>"+rapsHistory.lastUpdate+"</td>";
			dh+="<td width='15%' align='center'>"+rapsHistory.userId+"</td>";
			dh+="</tr>";
		}
	}
	dh+=" </table>";
	document.getElementById("rapsHistoryDiv").innerHTML=dh;
	resetBodyHeight();
}

function CBRapsDiagCodes(data, count) {
	var diagArr = data; 
	var cl = "";
	var dh="<table width='100%' border='0' cellpadding='0' cellspacing='0' bordercolor='#eeeeee' class='subheadRow'>";
	if(diagArr == null ||  diagArr.length == 0)
		dh+="<tr><td colspan='13'>&nbsp;" + MSG_NO_DATA_FOUND + "</td></tr>";
	else {
		for(var i=0 ; i < diagArr.length ; i++) {
			var rdc=diagArr[i];
			if (rdc.asLink){
			    cl=" class=ft>";
			    dh+="<tr align='left' onclick=\"gotoDetail('buildRapsDetail','" + rdc.id + "')\" style='cursor:pointer'>";
		    }else{ 
			    dh+="<tr>"; cl=">";
			}
			dh+="<td width='4%' class='bold' align='center'"+cl+rdc.displayId +"</td>";
			dh+="<td width='6%' class='bold' align='center'"+cl+rdc.displayParent+"</td>";
			dh+="<td width='6%' class='bold' align='center'"+cl+rdc.deleteInd+"</td>"; 
			dh+="<td width='10%' class='bold' align='center'"+cl+rdc.source+"</td>";
			dh+="<td width='9%' class='bold' align='center'"+cl+rdc.serviceFrom+"</td>";
			dh+="<td width='8%' class='bold' align='center'"+cl+rdc.serviceThru+"</td>";
			dh+="<td width='11%' class='bold' align='center'"+cl+rdc.providerDescr+"</td>";
			dh+="<td width='5%' class='bold' align='center'"+cl+rdc.cd+"</td>";
			dh+="<td width='5%' class='bold' align='center'"+cl+rdc.pos+"</td>";
			dh+="<td width='7%' class='bold' align='center'"+cl+rdc.code+"</td>";
			dh+="<td width='29%' class='bold' align='center'"+cl+rdc.description+"</td>";
			dh+="</tr>";
		}
	}
	dh+=" </table>";
	document.getElementById("rapsDiagcodeDiv").innerHTML=dh;
	dwr.util.setValue("diagCnt","Number of Diagnosis Codes: " + count);
	resetBodyHeight();
}

function CBRapsSources(data) {
	var diagArr = data;
	var dh="<table width='100%' border='0' cellpadding='0' cellspacing='0' bordercolor='#eeeeee' class='subheadRow'>";
	var i=0;
	if(diagArr == null ||  diagArr.length == 0)
		dh+="<tr><td colspan='5'>&nbsp;" + MSG_NO_DATA_FOUND + "</td></tr>";
	else {
		for(i=0 ; i < diagArr.length ; i++) {
			var src=diagArr[i];
			dh+="<tr id='" + i + "' onclick=\"gotoDetail('buildClaimDetail', '" + src.id + "')\" style='cursor:pointer'>";
			dh+="<td width='5%' align='right'>"+src.id +")&nbsp;&nbsp;</td>";
			dh+="<td width='50%' align='left'>"+src.sourceRef+"</td>";
			dh+="<td width='15%' align='center'>"+src.type+"</td>";
			dh+="<td width='15%' align='center'>"+src.fmtLastUpdtTime+"</td>";
			dh+="<td width='15%' align='center'>"+src.userID+"</td>";
			dh+="</tr>";
		}
	}
	dh+=" </table>";
	document.getElementById("rapsSourcesDiv").innerHTML=dh;
	dwr.util.setValue("srcCnt","Number of Sources:  " + i);
}

function CBRapsErrors(data) {
	var diagArr = data;
	var dh="";
	if (data !=null) {
	    document.getElementById("label").style.display= "block";
    	dh+='<table width="100%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#999999" style="border-collapse:collapse">';
        dh+='<tr><td align="left"><table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolor="#eeeeee" class="subheadRow">';
        dh+='<tr><td width="6%" class="ftc">Code</td><td width="94%" class="ftl">Description</td></tr>';
        dh+='<tr height="5"><td colspan="2"></td></tr>';
    	for(var i=0 ; i < diagArr.length ; i++) {
    		var detail=diagArr[i];
    		dh+="<tr><td align='right'>"+detail.code +"&nbsp;</td>";
    		dh+="<td>"+detail.descr+"</td></tr>";
    	}
    	dh+='<tr height="5"><td colspan="2"></td></tr></table></td></tr></table>';
    }
    else {
	    document.getElementById("label").style.display= "none";
    }
	document.getElementById("rapsErrors").innerHTML=dh;
}

function gotoDetail(method, arg1) {
	var formRef = document.forms['RAPSForm'];
	formRef.action="/RAPSAction.do?method=" + method + '&id='+arg1;
	saveAndSubmit(formRef);
}

/* reset input form for raps input screen */
function clearRaps(clearIt) {
	var fr=document.forms['RAPSForm'];
	var e = document.getElementById("diagCdL");
	if (e != null) 
	    e.style.display = 'none';
	fr.diagCd.style.display="block";
	if (clearIt) {
	    fr.hicNbr.value=""; 
	    fr.planId.selectedIndex = 0;
	    $("#planId").select2().select2('val','');
	    fr.patientControlNo.value="";
	    fr.fromDate.value="";
	    fr.toDate.value="";
	    fr.diagCd.value="";
	    fr.comments.value="";
	    fr.actDel[0].checked=true;
	    fr.providerType.selectedIndex = 0;
	    $('#providerType').val($('#providerType option:first-child').val()).trigger('change');
	    
	}
	fr.hicNbr.disabled=false;
    fr.planId.disabled=false;
	fr.patientControlNo.disabled=false;
	fr.fromDate.disabled=false;
	fr.toDate.disabled=false;
	fr.diagCd.disabled=false;
	fr.comments.disabled=false;
    fr.actDel[0].disabled=false; fr.actDel[1].disabled=false;
    fr.providerType.disabled=false;
    fr.validateraps.disabled=false; fr.resetraps.disabled=false;
	e = document.getElementById("detail");
	e.removeAttribute("rowExpanded");
	e.style.display = 'none';
}
function setDiag() {
    document.forms['RAPSForm'].diagCd.value=document.forms['RAPSForm'].diagCdL.value;
}
function deleteRaps(method) {
    var formRef = document.forms ['RAPSForm'];
	formRef.action="/deleteRaps.do?method="+method;
    saveAndSubmit(formRef);    
}

function rapsInit() {
    DWREngine.setErrorHandler(dwrErrorHandler);
	if (ERROR_MSG != null && ERROR_MSG != "null")  
	    showPopMessage(ERROR_MSG);
}

function displayHelp(){
    //
	var wt = window.opener.top;
	if (wt.helpWindow == null || (wt.helpWindow.closed))
        wt.openHelp("about:blank");
    //
    var p = dwr.util.getValue("pageNo");
    if (p==null || ""==p) p = 100; //default    
    //RH_ShowHelp(0, "/mss/raps_context_help/RAPS_Webhelp_test.htm>Mainwindow", HH_HELP_CONTEXT, p);
    RH_ShowHelp(0, "/mss/raps_context_help/RAPS_Webhelp_test.htm>helpWindow", HH_HELP_CONTEXT, p);
    
    //RH_ShowHelp(0, "/mss/context-WebHelp/start.htm>Mainwindow", HH_HELP_CONTEXT, 15);
}

function paintArrows(pageNumber, currentPage, menuName, numCol) {
	var divHtml="<tr>";
	divHtml+="<td colspan='" + numCol + "' align='right' class='pageRow'>";
	divHtml+="<table width='50%' height='20'  border='0' align='right' cellpadding='0' cellspacing='0'><tr>";
	divHtml+="<td align='right'>Page# : <SPAN id='pgNumber'>"+pageNumber+ "</SPAN>&nbsp;&nbsp;</td>";
		
	if( pageNumber == 1) {
		divHtml += '<td width="25px" align="center" ><img title="First Page" src="/mss/jsp/Recon/images/Arrow_Page1.png" width="16" height="16"></td>';
		divHtml += '<td width="25px" align="center"><img title="Previous Page" src="/mss/jsp/Recon/images/Arrow_PageP.png" width="16" height="16" ></td>';
	} else {
		divHtml += '<td width="25px" align="center" ><img title="First Page" src="/mss/jsp/Recon/images/Arrow_Page1.png" width="16" height="16" onclick="useLoadingImage(this);rapsPagination(\'first\',\'' + menuName + '\');" style="cursor:pointer"></td>';
		divHtml += '<td width="25px" align="center"><img title="Previous Page" src="/mss/jsp/Recon/images/Arrow_PageP.png" width="16" height="16" onclick="useLoadingImage(this);rapsPagination(\'previous\',\'' + menuName + '\');" style="cursor:pointer"></td>';
	}
	if( currentPage == 'last') {
		divHtml += '<td width="25px" align="center"><img id="nextPageImg" title="Next Page" src="/mss/jsp/Recon/images/Arrow_PageN.png" width="16" height="16" ></td>';
	} else {
		divHtml += '<td width="25px" align="center"><img id="nextPageImg" title="Next Page" src="/mss/jsp/Recon/images/Arrow_PageN.png" width="16" height="16" onclick="useLoadingImage(this);rapsPagination(\'next\',\'' + menuName + '\');" style="cursor:pointer"></td>';
	}
	divHtml+='<td width="65px">&nbsp;</td></tr></table></td>';
	divHtml+="</tr>";
	return divHtml;
}

/* Populate Raps Summary Errors page. */
function CBgetRapsErrorsPage(data, move, menuName) {
	var rapsErrorsPage = data ;
	var dh="<table width='100%'  border='1' cellpadding='0' cellspacing='0' bordercolor='#999999' style='border-collapse:collapse;word-break:break-all'>";
	if( rapsErrorsPage == null ) {
		showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
		var nextPageImg = document.getElementById("nextPageImg");
		nextPageImg.onclick = function(){
				showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
			};
		return;
	} else {
		prevSelectedRow = rapsErrorsPage.selectedLine;
		var pdeDetailVO = null;
		var currentPage = "";
		var pageNumber = 1;
		currentPage = rapsErrorsPage.currentPage;
		pageNumber = rapsErrorsPage.pageNumber;
		rapsErrorsDet = rapsErrorsPage.rapsErrors;
		dh+='<tr style="display:none" colspan="8"> <td id="selectRow">'+prevSelectedRow +'</td></tr>'
		var selectedRowPdeSeqNum = -1;
		
		if(rapsErrorsDet ==null || rapsErrorsDet.length==0){
			// means there is not more data, show appropriate message on screen.
			showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
			var nextPageImg = document.getElementById("nextPageImg");
			nextPageImg.onclick = function(){
				showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
			};
			return;
		} else {
			var j = 0 ;	
			for(var i = 0;i < rapsErrorsDet.length ; i++ ){
				rdi = rapsErrorsDet[i];
				var ccss = "class = ''";
				if( i == prevSelectedRow ) 
				  ccss = "class='selectedRow'";
				else if ( i % 2 == 0) 
				  ccss = "class='oddRow'";
				else 
				  ccss = "class='evenRow'";
				dh+='<tr style="display:none" colspan="8"> <td id="selectRow">'+prevSelectedRow +'</td></tr>'
                var temp =  "<tr "+ ccss +" id='"+i +"' style='cursor:pointer' onclick=\"useLoadingImage(this);javascript:getRapsDetail('errors','" + i + "')\">";					
                dh+= temp;
				dh+='<td align="center" '+ ccss +' width="6%" id="planId_'+i+'">'+ rdi.planID+"</td>";
				dh+='<td align="center" '+ ccss +' width="10%" id="hicNbr_'+i+'">'+ rdi.hicNbr+"</td>";
				dh+='<td align="center" '+ ccss +' width="12%" id="fromService_'+i+'">'+ rdi.fromServiceDate+"</td>";
				dh+='<td align="center" '+ ccss +' width="12%" id="thruService_'+i+'">'+ rdi.thruServiceDate+"</td>";
				dh+='<td align="center" '+ ccss +' width="10%">'+ rdi.statusDisplay+"</td>";
				dh+='<td '+ ccss +' width="27%" id="diagDisplay_'+i+'">'+ rdi.diagCodeDisplay+"&nbsp;&nbsp;</td>";
				dh+='<td align="center" '+ ccss +' width="12%" id="errorWorkStatusCode_'+i+'">'+ rdi.errorWorkStatusCode+"</td>";
				dh+='<td align="center" '+ ccss +' width="5%" id="dup_'+i+'">'+ rdi.dup+"</td>";
				dh+='<td align="center" '+ ccss +' width="6%" id="resub_'+i+'">'+ rdi.resub+"</td>";
				dh+='<td style="display:none" id="status_'+i+'">'+ rdi.clusterStatus+"</td>";				
				dh+='<td style="display:none" id="diagCode_'+i+'">'+ rdi.diagCode+"</td>";				
				dh+='<td style="display:none" id="provType_'+i+'">'+ rdi.providerType+"</td>";				
				dh+='<td style="display:none" id="dcType_'+i+'">'+ rdi.dcType+"</td>";				
				dh+="</tr>";
			}
			dh += paintArrows(pageNumber, currentPage, menuName, 10);			
			
			CBgetRapsErrorsDetail(rapsErrorsPage.errorsInfo);
			// update history
			CBRapsErrorsHistory(rapsErrorsPage.errorsHistoryItems);
		}
		dh+="</table>";
	}
	var id = "rapsEventDetailDiv";
	document.getElementById(id).innerHTML = dh;
	resetBodyHeight();
}

/* repaint + RAPS Errors Details on summary errors */
function CBgetRapsErrorsDetail(det) {
	if(det == null){
		showPopMessage("Raps Errors Detail is Null");
		return;
	}
	dwr.util.setValue("plan", det.planId);
	dwr.util.setValue("detailHic",det.hicNbr);
	dwr.util.setValue("mbi",det.mbi);
	dwr.util.setValue("fsd",det.fromServiceDate);
	dwr.util.setValue("tsd",det.thruServiceDate);
	dwr.util.setValue("pt",det.providerType+" - " + det.providerDescription);
	dwr.util.setValue("dc",det.diagCode);
	dwr.util.setValue("dcd",det.diagDescription);
	dwr.util.setValue("cws",det.currentWorkStatus);
	dwr.util.setValue("rws",det.previousWorkStatus);
	
	var dh="<select style='width:70px' class='dropdown' id='st'>";
	var selectedOpen = "";
	if (det.currentWorkStatus != null) {
		if (det.currentWorkStatus == "OPEN")
			selectedOpen = "selected";
	}
	dh+="<option value='OPEN' "+selectedOpen+">Open</option>";
	var selectedIgnore = "";
	if (det.currentWorkStatus != null) {
		if (det.currentWorkStatus == "IGNR")
			selectedIgnore = "selected";
	}
	dh+="<option value='IGNR' "+selectedIgnore+">Ignore</option>";
	if (det.clusterStatus == "REJ") {
		var selectedInwk = "";
		if (det.currentWorkStatus != null) {
			if (det.currentWorkStatus == "INWK")
				selectedInwk = "selected";
		}
		dh+="<option value='INWK' "+selectedInwk+">In Work</option>";
		var selectedComp = "";
		if (det.currentWorkStatus != null) {
			if (det.currentWorkStatus == "COMP")
				selectedComp = "selected";
		}
		dh+="<option value='COMP' "+selectedComp+">Completed</option>";
	}
	dh+="</select>";
	var id = "revisedWorkStatus";
	document.getElementById(id).innerHTML = dh;

	dh="<textarea rows='2' cols='33' onfocus='this.select();' id='cmnt'>"+det.comment+"</textarea>";
	
	id = "errorsComment";
	document.getElementById(id).innerHTML = dh;
	resetBodyHeight();

	return; 
}

/* repaint + RAPS Errors History on summary errors */
function CBRapsErrorsHistory(data) {
 
	var historyArr = data;
	var rapsErrorsHistory={seqNbr:null,errorWorkStatusCode:null,comment:null,lastUpdateTime:null,userId:null};

	var dh="<table width='100%' border='1' cellpadding='0' cellspacing='0' bordercolor='#999999' style='border-collapse:collapse'>";
	if(historyArr == null ||  historyArr.length == 0)
		dh+="<tr><td colspan='5'>&nbsp;" + MSG_NO_DATA_FOUND + "</td></tr>";
	else {
		for(var i=0 ; i < historyArr.length ; i++) {
			rapsErrorsHistory=historyArr[i];
			if( i %2 == 0 ) {
				dh+="<tr class='oddRow'>";
			} else {
				dh+="<tr class='evenRow'>";
			}
			dh+="<td width='7%' align='center'>"+rapsErrorsHistory.seqNbr +"</td>";
			dh+="<td width='13%' align='center'>"+rapsErrorsHistory.errorWorkStatusCode+"</td>";
			dh+="<td width='50%' align='left'>"+rapsErrorsHistory.comment+"</td>";
			dh+="<td width='15%' align='center'>"+rapsErrorsHistory.lastUpdateTime+"</td>";
			dh+="<td width='15%' align='center'>"+rapsErrorsHistory.userId+"</td>";
			dh+="</tr>";
		}
	}
	dh+=" </table>";
	document.getElementById("rapsHistoryDiv").innerHTML=dh;
	resetBodyHeight();
}

function updateErrors(menuName){

	try{
		useLoadingImage(document.getElementById(menuName));

		var formRef = document.forms ['rapsForm'];

		var rowId = dwr.util.getValue('selectRow');
		var commentTag = document.getElementById('cmnt');
		var newStatusTag = document.getElementById('st');

		var newComment = commentTag.value;
		var newStatus = newStatusTag.options[newStatusTag.selectedIndex].value;

	    var detail = { planID:null, hicNbr:null, providerType:null, dcType:null, diagCode:null, 
	        fromServiceDate:null, thruServiceDate:null, errorWorkStatusCode:null};
        detail.planID=dwr.util.getValue('planID_'+rowId);
        detail.hicNbr=dwr.util.getValue('hicNbr_'+rowId);
        detail.providerType=dwr.util.getValue('provType_'+rowId);
        detail.dcType=dwr.util.getValue('dcType_'+rowId);
        detail.diagCode=dwr.util.getValue('diagCode_'+rowId);
        detail.fromServiceDate=dwr.util.getValue('fromService_'+rowId);
        detail.thruServiceDate=dwr.util.getValue('thruService_'+rowId);
        detail.errorWorkStatusCode=dwr.util.getValue('errorWorkStatusCode_'+rowId);
        
        var changeStatus = new Boolean(true);
        //if (menuName == "updtComment")
        //	changeStatus = false;

		FacadeManager.updateErrorStatus(rowId, detail, newStatus, newComment, changeStatus, {
		  			callback:function(data) {
			   			CBUpdateErrorStatus(data,changeStatus);}
		  			});

	}catch(e){
		showPopMessage("Error: "+e.message);
	}
}

function CBUpdateErrorStatus(data, changeStatus) {

	if (data == null) {
		showPopMessage("Update Failed");
		return;
	}

	var rowId = dwr.util.getValue('selectRow');
	
	if (changeStatus) {
		dwr.util.setValue("errorWorkStatusCode_" + rowId, data[data.length-1].errorWorkStatusCode);
		dwr.util.setValue("cws",data[data.length-1].errorWorkStatusCode);
	}

	CBRapsErrorsHistory(data);
}
/* Added for Ticket 345314 */
function populateErrorStatus() {
	var srcBox = document.getElementsByName('status')[0];
	var val = srcBox.options[srcBox.selectedIndex].value;
	var selBox = document.getElementsByName("errorStatus")[0];
	selBox.options.length = 0;
	selBox.disabled = true;
	var arrOption = null;
	if (val == 'EERR') {
		arrOption = ["ALL", "OPEN", "IGNR"];
	} else if (val == 'REJ') { 	
		arrOption = ["ALL", "OPEN", "COMP", "INWK", "IGNR"];
	}
	if (arrOption != null) {
		selBox.disabled = false;
		for(i = 0; i < arrOption.length; i++) {
			var opt = document.createElement("option");
			opt.value = arrOption[i];
			opt.innerHTML = arrOption[i];
			selBox.appendChild(opt);
		}
	} 
}