// $Id: correspondence.js,v 1.1 2014/06/26 07:57:03 praveen Exp $

/* Populate Letters Detail page. */
function CBgetLettersDetailPage(data, move, menuName) {
	var letterListItem = data ;
	var dh="<table width='100%'  border='1' cellpadding='0' cellspacing='0' bordercolor='#999999' style='border-collapse:collapse;word-break:break-all'>";
	if( letterListItem == null ) {
		showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
		var nextPageImg = document.getElementById("nextPageImg");
		nextPageImg.onclick = function(){
				showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
			};
		return;
	} else {
		prevSelectedRow = letterListItem.selectedLine;
		var lettersItem = null;
		var currentPage = "";
		var pageNumber = 1;
		currentPage = letterListItem.currentPage;
		pageNumber = letterListItem.pageNumber;
		lettersItem = letterListItem.lettersItem;
		dh+='<tr style="display:none" colspan="8"> <td id="selectRow">'+prevSelectedRow +'</td></tr>'
		var selectedRowPdeSeqNum = -1;

		if(lettersItem ==null || lettersItem.length==0){
			// means there is no more data, show appropriate message on screen.
			showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
			var nextPageImg = document.getElementById("nextPageImg");
			nextPageImg.onclick = function(){
				showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
			};
			return;
		} else {
			var j = 0 ;	
			for(var i = 0;i < lettersItem.length ; i++ ){
				li = lettersItem[i];
				var ccss = "class = ''";
				if( i == prevSelectedRow ) 
				  ccss = "class='selectedRow'";
				else if ( i % 2 == 0) 
				  ccss = "class='oddRow'";
				else 
				  ccss = "class='evenRow'";
				dh+='<tr style="display:none" colspan="9"> <td id="selectRow">'+prevSelectedRow +'</td></tr>'
                var temp =  "<tr "+ ccss +" id='"+i +"' style='cursor:pointer' onclick=\"useLoadingImage(this);javascript:getLetterDetails('detail','" + i + "')\">";					
                dh+= temp;
				dh+='<td height="20" align="center" '+ ccss +' width="11%" id="memberId_'+i+'">'+ li.memberId +"</td>";
				dh+='<td align="center" '+ ccss +' width="12%" id="supplementalId_'+i+'">'+ li.supplementalId +"</td>";
				dh+='<td align="center" '+ ccss +' width="10%" id="fileBatchId_'+i+'">'+ li.fileBatchId +"</td>";
				dh+='<td align="center" '+ ccss +' width="7%" id="letterNbr_'+i+'">'+ li.letterNbr +"</td>";
				dh+='<td align="center" '+ ccss +' width="12%" id="requestDate_'+i+'">'+ li.requestDate +"</td>";
				dh+='<td align="center" '+ ccss +' width="9%" id="status_'+i+'">'+ li.status+"</td>";
				dh+='<td align="center" '+ ccss +' width="10%" id="requestor_'+i+'">'+ li.requestor +"</td>";
				dh+='<td align="center" '+ ccss +' width="7%" id="deleteInd_'+i+'">'+ li.deleteInd +"</td>";
				dh+='<td align="center" '+ ccss +' width="10%" id="lastUpdateId_'+i+'">'+ li.lastUpdateId +"</td>";
				dh+='<td align="center" '+ ccss +' width="12%" id="lastUpdate_'+i+'">'+ li.lastUpdate +"</td>";
				dh+='<td style="display:none" '+ ccss +' id="letterSystem_'+i+'">'+ li.letterSystem +"</td>";
				dh+='<td style="display:none" '+ ccss +' id="region_'+i+'">'+ li.region +"</td>";
				dh+='<td style="display:none" '+ ccss +' id="siteId_'+i+'">'+ li.siteId +"</td>";
				dh+='<td style="display:none" '+ ccss +' id="lettersDataItem_'+i+'">'+ li.lettersDataItem +"</td>";
				dh+='<td style="display:none" '+ ccss +'><input type="hidden" id="primaryId_'+i+'" value="'+ li.primaryId + '" /></td>';
				dh+='<td style="display:none" '+ ccss +' id="extractSequence_'+i+'">'+ li.extractSequence +"</td>";
				dh+='<td style="display:none" '+ ccss +' id="recordType_'+i+'">'+ li.recordType +"</td>";
				dh+='<td style="display:none" '+ ccss +' id="lastUpdateTime_'+i+'">'+ li.lastUpdateTime +"</td>";
				dh+="</tr>";
			}
			dh += paintArrows(pageNumber, currentPage, menuName, 10);			
			
			CBgetLetterDetails(letterListItem.lettersDetailInfo);
		}
		dh+="</table>";
	}
	var id = "lettersDetailDiv";
	document.getElementById(id).innerHTML = dh;
	resetBodyHeight();
}


/* called when a row is selected on detail page */
function getLetterDetails(menuName, rowId) {
	try {
	
		var formRef = document.forms ['lettersForm'];
		var region = formRef.region.value;
		
		prevSelectedRow = dwr.util.getValue('selectRow');
		var className = "oddRow";
		var bgColor = "oddRowRed";
		if(prevSelectedRow % 2 =='1'  ) {
			bgColor = "evenRowRed";
			className = "evenRow";
		}
		applyClassOnTdTag(className, prevSelectedRow);
		dwr.util.setValue('selectRow', rowId);
		applyClassOnTdTag("selectedRow", rowId); //apply selected row style class.
		
	    var detail = { memberId:null, supplementalId:null, letterNbr:null, requestDate:null, status:null, 
	        requestor:null, deleteInd:null, lastUpdateId:null, lastUpdateTime:null, letterSystem:null,
	        region:null, siteId:null, primaryId:null, lettersDataItem:null};
        detail.memberId=dwr.util.getValue('memberId_'+rowId);
        detail.supplementalId=dwr.util.getValue('supplementalId_'+rowId);
        detail.letterNbr=dwr.util.getValue('letterNbr_'+rowId);
        detail.requestDate=dwr.util.getValue('requestDate_'+rowId);
        detail.status=dwr.util.getValue('status_'+rowId);
        detail.requestor=dwr.util.getValue('requestor_'+rowId);
        detail.deleteInd=dwr.util.getValue('deleteInd_'+rowId);
        detail.lastUpdateId=dwr.util.getValue('lastUpdateId_'+rowId);
        detail.lastUpdateTime=dwr.util.getValue('lastUpdateTime_'+rowId);
        detail.letterSystem=dwr.util.getValue('letterSystem_'+rowId);
        detail.region=dwr.util.getValue('region_'+rowId);
        detail.siteId=dwr.util.getValue('siteId_'+rowId);
        detail.primaryId=dwr.util.getValue('primaryId_'+rowId);
        detail.extractSequence=dwr.util.getValue('extractSequence_'+rowId);
        detail.fileBatchId=dwr.util.getValue('fileBatchId_'+rowId);
        detail.recordType=dwr.util.getValue('recordType_'+rowId);
        
	    FacadeManager.getLettersDetail(region, rowId, detail, {
							  			callback:function(data) {
							  		var lettersListItem = data;
							  		CBgetLetterDetails(lettersListItem.lettersDetailInfo);
							  			}});
	} catch(e) {
		showPopMessage("Error: "+e.message);
	}
}

/* repaint + Letter Details on Letters page */
function CBgetLetterDetails(det) {
	if(det == null){
		showPopMessage("Letter Details is Null");
		return;
	}

	//now paint the details
	var dh="<table width='98%' border='0' align='center' cellpadding='0' cellspacing='0'";
	dh+="<tr><td align='right' width='9%' height='20'><span class='head3'>Member Id</span> :&nbsp;</td>";
	dh+="<td width='10%' align='left' id='memberId'>"+det.memberId+"</td>";
	dh+="<td align='right' width='9%'><span class='head3'>Alternate Id</span> :&nbsp;</td>";
 	dh+="<td width='10%' align='left' id='supplementalId'>"+det.supplementalId+"</td>";
	dh+="<td align='right' width='11%'><span class='head3'>Request Date</span> :&nbsp;</td>";
	dh+="<td width='10%' align='left' id='requestDate'>"+det.requestDate+"</td>";
	dh+="<td align='right' width='9%'><span class='head3'>Requestor</span> :&nbsp;</td>";
	dh+="<td width='10%' align='left' id='requestor' colspan='2'>"+det.requestor+"</td></tr>";

	dh+="<tr><td align='right' width='9%' height='20'><span class='head3'>File Id</span> :&nbsp;</td>";
	dh+="<td width='10%' align='left' id='fileId'>"+det.fileBatchId+"</td>";
	dh+="<td align='right' width='9%'><span class='head3'>Letter System</span> :&nbsp;</td>";
	dh+="<td width='10%' align='left' id='letterSystem'>"+det.letterSystem+"</td>";
	dh+="<td align='right' width='11%'><span class='head3'>Letter #</span> :&nbsp;</td>";
	dh+="<td width='10%' align='left' id='letterNbr'>"+det.letterNbr+"</td>";
	dh+="<td align='right' width='9%'><span class='head3'>Status</span> :&nbsp;</td>";
	dh+="<td width='10%' align='left' id='status'>";
	dh+="<select style='width:70px' class='dropdown' id='st'>";
	var selectedApplied = "";
	if (det.status != null) {
		if (det.status == "APPLIED")
			selectedApplied = "selected";
	}
	dh+="<option value='APPLIED' "+selectedApplied+">Applied</option>";
	var selectedLoaded = "";
	if (det.status != null) {
		if (det.status == "LOADED")
			selectedLoaded = "selected";
	}
	dh+="<option value='LOADED' "+selectedLoaded+">Loaded</option>";
	var selectedHold = "";
	if (det.status != null) {
		if (det.status == "HOLD")
			selectedHold = "selected";
	}
	dh+="<option value='HOLD' "+selectedHold+">Hold</option>";
	if (det.status != null) {
		if (det.status == "EXTRACTED")
			dh+="<option value='HOLD' selected>Extracted</option>";
	}
	dh+="</select></td>";
	dh+="<td align='right' width='6%'><span class='head3'>Deleted</span> :&nbsp;</td>";
	var checked = "";
  	if (det.deleteInd != null) {
  		if (det.deleteInd == "Y")
  			checked="checked";
  	}
	dh+="<td width='2%' align='left' id='deleteInd'><input type='checkbox' id='del' "+checked+" onclick='delIndChange(this,\"st\");' /></td></tr>";

	dh+="<tr><td align='right' width='9%' height='20'>&nbsp;</td>";
	dh+="<td width='10%' align='left'>&nbsp;</td>";
	dh+="<td align='right' width='9%'>&nbsp;</td>";
	dh+="<td width='10%' align='left'>&nbsp;</td>";
	dh+="<td align='right' width='11%'><span class='head3'>Last Updated By</span> :&nbsp;</td>";
	dh+="<td width='10%' align='left' id='lastUpdateId'>"+det.lastUpdateId+"</td>";
	dh+="<td align='right' width='9%'><span class='head3'>Last Update</span> :&nbsp;</td>";
	dh+="<td width='10%' align='left' id='lastUpdate' colspan='2'>"+det.lastUpdate+"</td></tr>";
	
	if (det.status != null && det.status == "EXTRACTED")
        dh+="</table>";
	else {
		dh+="<tr><td colspan='10' height='3'></td></tr>";
        dh+="<tr id='updt'><td colspan='7'>&nbsp;</td>";
	  	dh+="<td align='left'><img id='butUpdateLetter' src='/mss/jsp/Recon/images/but_update.jpg' style='cursor:pointer' onclick=\"updateLetterStatus('lettersPage');\">";
	  	dh+="</td><td colspan='2'>&nbsp;</td></tr><tr><td colspan='10' height='3'></td></tr></table>";
  	}

	document.getElementById("detDiv").innerHTML=dh;
	
	var statusDropDown = document.getElementById("st");
	var deleteCheckBox = document.getElementById("del");
	
	if (det.status != null && det.status == 'EXTRACTED') {
        statusDropDown.disabled=true;
        deleteCheckBox.disabled=true;
	}
	else {
        statusDropDown.disabled=false;
        deleteCheckBox.disabled=false;
  	}
	
	CBLetterData(det.lettersDataItem);
	
	resetBodyHeight();

	return; 
}

function CBLetterData(data) {

	var letterDataArr = data;
	var letterData={variableSeqNbr:null,variableId:null,variableMnemonic:null,variableData:null};
	var dh="<table width='100%' border='1' cellpadding='0' cellspacing='0' bordercolor='#999999' style='border-collapse:collapse'>";
	if(letterDataArr == null ||  letterDataArr.length == 0)
		dh+="<tr><td colspan='3'>&nbsp;" + MSG_NO_DATA_FOUND + "</td></tr>";
	else {
		for(var i=0 ; i < letterDataArr.length ; i++) {
			letterData=letterDataArr[i];
			if( i %2 == 0 ) {
				dh+="<tr class='oddRow'>";
			} else {
				dh+="<tr class='evenRow'>";
			}
			dh+="<td width='10%' align='center'>"+letterData.variableId+"</td>";
			dh+="<td width='15%' align='center'>"+letterData.variableMnemonic+"</td>";
			dh+="<td width='40%' align='center'>"+letterData.variableData+"</td>";
			dh+="</tr>";
		}
	}
	dh+=" </table>";
	document.getElementById("letterDataDiv").innerHTML=dh;
}

function lettersInit() {
    DWREngine.setErrorHandler(dwrErrorHandler);
	if (ERROR_MSG != null && ERROR_MSG != "null")  
	    showPopMessage(ERROR_MSG);
}

function searchCriteriaOK() {

	//go button.
	var fld="Request Date";
    if (!validate2Date("requestDateFrom","requestDateTo","Update",fld))
    	return false;
	if(isBlankOrNULL("requestor") == false || 
	   isBlankOrNULL("status")    == false || 
	   isBlankOrNULL("letterNbr") == false || 
	   isBlankOrNULL("deleteInd") == false) {
	   	if(isBlankOrNULL("memberId")       == false &&
	       isBlankOrNULL("supplementalId") == false &&
	       isBlankOrNULL("fileId")         == false) {
			if(isBlankOrNULL("requestDateFrom") == true && 
			   isBlankOrNULL("requestDateTo")   == true) {
					showPopMessage("Request Date is required", function(){
						setElementFocus("requestDateFrom");
					});
					return false;
			}
		}
	}
	return true;
}

//This method is used to move between subTab or when GO button is selected
function submitLettersLink(methodName) {

	upperCaseForm();

	//go button.
	if (!searchCriteriaOK()) {
		return false;
	}

	var formRef = document.forms ['lettersForm'];
	formRef.method.value = methodName;
	formRef.searchType.value = "search";
	saveAndSubmit(formRef);
}

function updateLetterStatus(menuName){

	try{
		useLoadingImage(document.getElementById('butUpdateLetter'));

		var formRef = document.forms ['lettersForm'];
		var region = formRef.region.value;

		var rowId = dwr.util.getValue('selectRow');
		var deleteIndTag = document.getElementById('del')
		var newStatusTag = document.getElementById('st')

		var newDeleteInd;
		var newStatus;
		
		newStatus = newStatusTag.options[newStatusTag.selectedIndex].value
		if (deleteIndTag.checked)
			newDeleteInd = 'Y';
		else
			newDeleteInd = 'N';
		
	    var detail = { memberId:null, supplementalId:null, letterNbr:null, requestDate:null, status:null, 
	        requestor:null, deleteInd:null, lastUpdateId:null, lastUpdateTime:null, letterSystem:null,
	        region:null, siteId:null, primaryId:null, lettersDataItem:null};
        detail.memberId=dwr.util.getValue('memberId_'+rowId);
        detail.supplementalId=dwr.util.getValue('supplementalId_'+rowId);
        detail.letterNbr=dwr.util.getValue('letterNbr_'+rowId);
        detail.requestDate=dwr.util.getValue('requestDate_'+rowId);
        detail.status=dwr.util.getValue('status_'+rowId);
        detail.requestor=dwr.util.getValue('requestor_'+rowId);
        detail.deleteInd=dwr.util.getValue('deleteInd_'+rowId);
        detail.lastUpdateId=dwr.util.getValue('lastUpdateId_'+rowId);
        detail.lastUpdateTime=dwr.util.getValue('lastUpdateTime_'+rowId);
        detail.letterSystem=dwr.util.getValue('letterSystem_'+rowId);
        detail.region=dwr.util.getValue('region_'+rowId);
        detail.siteId=dwr.util.getValue('siteId_'+rowId);
        detail.primaryId=dwr.util.getValue('primaryId_'+rowId);
        detail.extractSequence=dwr.util.getValue('extractSequence_'+rowId);
        detail.fileBatchId=dwr.util.getValue('fileBatchId_'+rowId);
        detail.recordType=dwr.util.getValue('recordType_'+rowId);		
	
		FacadeManager.updateLetterStatus(region, rowId, detail, newStatus, newDeleteInd, {
		  			callback:function(data) {
			   			cbUpdateLetterStatus(data,menuName);}
		  			});

	}catch(e){
		showPopMessage("Error: "+e.message);
	}
}

function cbUpdateLetterStatus(data, menuName) {

	if (data == null) {
		showPopMessage("Update Failed");
		return;
	}
	
	var rowId = dwr.util.getValue('selectRow');
	
	var tdTag;
	
	tdTag = document.getElementById('status_' + rowId);
	tdTag.innerHTML = '<td align="center" class="selectedRow" width="9%" id="status_'+rowId+'">'+ data.status+"</td>";
	
	tdTag = document.getElementById('deleteInd_' + rowId);
	tdTag.innerHTML ='<td align="center" class="selectedRow" width="7%" id="deleteInd_'+rowId+'">'+ data.deleteInd +"</td>";
	
	tdTag = document.getElementById('lastUpdateId_' + rowId);
	tdTag.innerHTML ='<td align="center" class="selectedRow" width="10%" id="lastUpdateId_'+rowId+'">'+ data.lastUpdateId +"</td>";
	
	tdTag = document.getElementById('lastUpdate_' + rowId);
	tdTag.innerHTML ='<td align="center" class="selectedRow" width="12%" id="lastUpdate_'+rowId+'">'+ data.lastUpdate +"</td>";

	tdTag = document.getElementById('lastUpdateTime_' + rowId);
	tdTag.innerHTML ='<td align="center" class="selectedRow" width="12%" id="lastUpdateTime_'+rowId+'">'+ data.lastUpdateTime +"</td>";

	tdTag = document.getElementById('lastUpdate');
	tdTag.innerHTML ='<td width="10%" align="left" id="lastUpdate" colspan="2">'+data.lastUpdate+'</td>';

}


function submitMassUpdate(menuName) {

	upperCaseForm();

	if (isBlankOrNULL("statusTo") == true) {
		showPopMessage("To Status is required", function(){setElementFocus("statusTo");});
		return;
	}
	
	//go button.
	if (!searchCriteriaOK()) {
		return;
	}
	
	try {
		useLoadingImage(document.getElementById('butUpdateLetter'));
		
	    var criteria = { memberId:null, supplementalId:null, 
	                     requestor:null, letterNbr:null, fileId:null,
	                     requestDateFrom:null, requestDateTo:null,
	                     status:null, deleteInd:null,
	                     statusTo:null, deleteIndTo:null,
	                     region:null
					   };
		
		var formRef = document.forms ['lettersForm'];
		var region = formRef.region.value;
	
		criteria.region = region;
		criteria.memberId = formRef.memberId.value;
		criteria.supplementalId = formRef.supplementalId.value;
		criteria.requestor = formRef.requestor.value;
		criteria.letterNbr = formRef.letterNbr.value;
		criteria.fileId = formRef.fileId.value;
		criteria.requestDateFrom = formRef.requestDateFrom.value;
		criteria.requestDateTo = formRef.requestDateTo.value;

		criteria.status = formRef.status.options[formRef.status.selectedIndex].value;
		if (formRef.deleteInd.checked)
			criteria.deleteInd = 'Y'
		else
		if (criteria.status != "")
			criteria.deleteInd = 'N'

		criteria.statusTo = formRef.statusTo.options[formRef.statusTo.selectedIndex].value;
		if (formRef.deleteIndTo.checked)
			criteria.deleteIndTo = 'Y'
		else
			criteria.deleteIndTo = 'N'
				
		FacadeManager.massUpdateLetterStatus(region, criteria, {
	  			callback:function(updateCnt) {
			   			cbMassUpdateLetterStatus(updateCnt);}
		  			});		
	}catch(e){
		showPopMessage("Error: "+e.message);
	}
}


function cbMassUpdateLetterStatus(updateCnt) {

	var msg;
	if (updateCnt > 0) {
		msg = "Status Update Successful\n" + updateCnt + " Records Updated";
	}
	else
	if (updateCnt == 0) {
		msg = "No Rows were updated";
	}
	else
		msg = "Status Update Failed";
	
	showPopMessage(msg);
}

function submitGenerateRequest(menuName) {

	var formRef = document.forms ['lettersForm'];
	var region = formRef.region.value;

	try {
		useLoadingImage(document.getElementById('butGoGenerate'));
		FacadeManager.lettersGenerateRequest(region,{
	  			callback:function(rslt) {
			   			cbLetterGenerateRequest(rslt);}
		  			});		
	}catch(e){
		showPopMessage("Error: "+e.message);
	}

}

function cbLetterGenerateRequest(rslt) {

	var msg;
	if (rslt == 0) {
		msg = "Letters Generation Process Started";
	}
	else
	if (rslt == 1) {
		msg = "Letters Generation Process Already Running";
	}	
	else
		msg = "Letters Generation Failed";
	
	showPopMessage(msg);
}

function openLettersPrint() {
    document.getElementById('pop_container').style.height=document.getElementById('lettersbody').scrollHeight;
    document.getElementById('pop_container').style.width=document.getElementById('lettersbody').scrollWidth;
    showExportPrintDialog();
}

function CBgetLettersDashboard(data, move, menuName) {

	var lettersDashboardList = data ;
	var dh="<table border='1' cellpadding='0' cellspacing='0' bordercolor='#999999' style='border-bottom-style:hidden; border-collapse:collapse;word-break:break-all;'>";
	if( lettersDashboardList == null ) {
		showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
		var nextPageImg = document.getElementById("nextPageImg");
		nextPageImg.onclick = function(){
				showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
			};
		return;
	}
	
	var lettersDashboardItem = null;
	var currentPage = "";
	var pageNumber = 1;
	currentPage = lettersDashboardList.currentPage;
	pageNumber = lettersDashboardList.pageNumber;
	lettersDashboardItem = lettersDashboardList.lettersDashboardItem;
	
	if(lettersDashboardItem == null || lettersDashboardItem.length == 0) {
		
		return;
		
		// means there is no more data, show appropriate message on screen.
		showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
		var nextPageImg = document.getElementById("nextPageImg");
		nextPageImg.onclick = function(){
			showPopMessage(MSG_NO_MORE_RECORD_AVAILABLE);
		};
		return;
	}
	
	var ldi;
	var j = 0;
	for(var i = 0;i < lettersDashboardItem.length ; i++ ){
		ldi = lettersDashboardItem[i];
		var ccss = "class = ''";
		if ( i % 2 == 0) 
			ccss = "class='oddRow'";
		else 
		  	ccss = "class='evenRow'";

     	dh += "<tr id='" + i + "' " + ccss + ">";
     	dh += "<td align='center' width='100' " + ccss + ">" + ldi.frmtCreateDate + "</td>";
		
		dh += "<td align='center' width='100' " + ccss + ">";
  		dh += "<a href='#' class='plan' onclick=\"submitDashboardAction('lettersPage','" + ldi.fileId + "',0);\">"+ ldi.fileId +"</a>";
  		dh += "</td>";
     	
     	dh += "<td align='right' width='140' " + ccss + ">";
  		dh += "<a href='#' class='plan' onclick=\"submitDashboardAction('lettersPage','" + ldi.fileId + "',1);\">"+ ldi.recsLoaded +"</a>";
		dh += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>"

     	dh += "<td align='right' width='80' " + ccss + ">";
  		dh += "<a href='#' class='plan' onclick=\"submitDashboardAction('lettersPage','" + ldi.fileId + "',2);\">"+ ldi.recsOnHold +"</a>";
		dh += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>"
		
     	dh += "<td align='right' width='80' " + ccss + ">";
  		dh += "<a href='#' class='plan' onclick=\"submitDashboardAction('lettersPage','" + ldi.fileId + "',3);\">"+ ldi.recsDeleted +"</a>";
		dh += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>"

     	dh += "<td align='right' width='80' " + ccss + ">";
  		dh += "<a href='#' class='plan' onclick=\"submitDashboardAction('lettersPage','" + ldi.fileId + "',4);\">"+ ldi.recsExtracted +"</a>";
		dh += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>"

     	dh += "<td align='right' width='80' " + ccss + ">";
  		dh += "<a href='#' class='plan' onclick=\"submitDashboardAction('lettersPage','" + ldi.fileId + "',5);\">"+ ldi.totalRecs +"</a>";
		dh += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>"

     	dh += "<td align='center' width='90' " + ccss + ">" + ldi.status + "</td>";
     	dh += "<td align='center' width='130' " + ccss + ">" + ldi.lastUpdate + "</td>";
  		dh += "</tr>";
	}

	dh += paintArrows(pageNumber, currentPage, menuName, 9);			
	dh+="</table>";

	var id = "lettersDashboardDiv";
	document.getElementById(id).innerHTML = dh;
	resetBodyHeight();
}

function lettersPagination(move, menuName){

	var formRef = document.forms ['lettersForm'];
	var region = formRef.region.value;

	 try{
		 if(menuName == 'detail') { 
			FacadeManager.getLettersPage(region, move, {
								callback:function(data) {
								CBgetLettersDetailPage(data, move, menuName); 
								}});
		 }
		 else
		 if(menuName == 'dashboard') { 
			FacadeManager.getLettersDashboard(region, move, {
								callback:function(data) {
								CBgetLettersDashboard(data, move, menuName); 
								}});
		 }

	}catch(e){
		showPopMessage("Error: "+e.message);
	}
}

function paintArrows(pageNumber, currentPage, menuName, numCol) {

	var divHtml="<tr>";
	divHtml+="<td colspan='" + numCol + "' align='right' class='pageRow'>";
	divHtml+="<table width='50%' height='20'  border='0' align='right' cellpadding='0' cellspacing='0'><tr>";
	divHtml+="<td align='right'>Page# : <SPAN id='pgNumber'>"+pageNumber+ "</SPAN>&nbsp;&nbsp;</td>";
		
	if( pageNumber == 1) {
		divHtml += '<td width="25px" align="center" ><img title="First Page" src="/mss/jsp/Recon/images/Arrow_Page1.jpg" width="16" height="16"></td>';
		divHtml += '<td width="25px" align="center"><img title="Previous Page" src="/mss/jsp/Recon/images/Arrow_PageP.jpg" width="16" height="16" ></td>';
	} else {
		divHtml += '<td width="25px" align="center" ><img title="First Page" src="/mss/jsp/Recon/images/Arrow_Page1.jpg" width="16" height="16" onclick="useLoadingImage(this);lettersPagination(\'first\',\'' + menuName + '\');" style="cursor:pointer"></td>';
		divHtml += '<td width="25px" align="center"><img title="Previous Page" src="/mss/jsp/Recon/images/Arrow_PageP.jpg" width="16" height="16" onclick="useLoadingImage(this);lettersPagination(\'previous\',\'' + menuName + '\');" style="cursor:pointer"></td>';
	}
	if( currentPage == 'last') {
		divHtml += '<td width="25px" align="center"><img id="nextPageImg" title="Next Page" src="/mss/jsp/Recon/images/Arrow_PageN.jpg" width="16" height="16" ></td>';
	} else {
		divHtml += '<td width="25px" align="center"><img id="nextPageImg" title="Next Page" src="/mss/jsp/Recon/images/Arrow_PageN.jpg" width="16" height="16" onclick="useLoadingImage(this);lettersPagination(\'next\',\'' + menuName + '\');" style="cursor:pointer"></td>';
	}
	divHtml+='<td width="65px">&nbsp;</td></tr></table></td>';
	divHtml+="</tr>";
	return divHtml;
}

function delIndChange(delFld,selFldName) {

    if (delFld.checked) {
	    var selFld = document.getElementById(selFldName)
	    setSelectBox(selFld,"APPLIED");
    }
}

function statusChange(statusFld,delIndFldName) {

	var status = statusFld.options[statusFld.selectedIndex].value;
	if ((status == 'LOADED') || (status == 'HOLDP')) {
		var delIndFld = document.getElementById(delIndFldName)
		delIndFld.checked = false;
	}
}

function upperCaseForm() {

	var formRef = document.forms ['lettersForm'];
		
	formRef.memberId.value = formRef.memberId.value.toUpperCase();
	formRef.supplementalId.value = formRef.supplementalId.value.toUpperCase();
	formRef.requestor.value = formRef.requestor.value.toUpperCase();
	formRef.letterNbr.value = formRef.letterNbr.value.toUpperCase();
	formRef.fileId.value = formRef.fileId.value.toUpperCase();
}

/* This method will find out the expanded item and do a submit */
/* Add in when adding the print/export option */
/* At this point this will just submit the form */
function saveAndSubmit(formRef) {
	//var pageName =  formRef.pageName.value; 
    //saveUiContext(formRef, pageName);
	//dataArray = uiContext.join("|");
    //formRef.uiContext.value = dataArray;
    //submitAction(formRef);
    formRef.submit();
    //formRef.uiContext.value = ""; //reset it in case of error
}

function submitTabSwitch(methodName) {
	var formRef = document.forms ['lettersForm'];
	formRef.method.value = methodName;
    formRef.searchType.value = "tab";
	saveAndSubmit(formRef);
}

function submitDashboardQuery(methodName) {

    //go button.
	var formRef = document.forms ['lettersForm'];
    var fld="Request Date";

    if (!validate2Date("requestDateFrom","requestDateTo","Update",fld))
        return false;

	formRef.method.value = methodName;
	formRef.searchType.value = "search"
	saveAndSubmit(formRef);
}

function submitDashboardAction(methodName,fileId,option) {
	
	var formRef = document.forms ['lettersForm'];
	formRef.method.value = methodName;
	formRef.searchType.value = "drill";

	formRef.fileId.value = fileId;
	formRef.status.value = "";
	formRef.requestDateFrom.value = "";
	formRef.requestDateTo.value = "";

	if (option == 1) {
		formRef.drillStatus.value = "LDAPP";
		formRef.drillDeleteInd.value = "";
	}
	else
	if (option == 2) {
		formRef.drillStatus.value = "HOLD";
		formRef.drillDeleteInd.value = "";
	}
	else
	if (option == 3) {
		formRef.drillStatus.value = "";
		formRef.drillDeleteInd.value = "Y";
	}
	else
	if (option == 4) {
		formRef.drillStatus.value = "EXTRACTED";
		formRef.drillDeleteInd.value = "";
	}
	else
	{
		formRef.drillStatus.value = "";
		formRef.drillDeleteInd.value = "";
	}
	
	saveAndSubmit(formRef);
}