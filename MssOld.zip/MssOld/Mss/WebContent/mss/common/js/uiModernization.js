/*
 * UI Modernization
 * 
 * June 2017
 */
   $(document).ready(function() {
		$(".applSearch").addClass("dropdown").select2();
		$(".dropdown2").addClass("dropdown").select2();
		$( ".datePickermmyy" ).datepicker({
			     dateFormat: "mmyy",
			     yearRange: '1900:2100',
			     changeMonth: true,
		         changeYear: true,
		         showButtonPanel: true
		    }).focus(function() {
	            var thisCalendar = $(this);
	            $('.ui-datepicker-calendar').detach();
	            $('.ui-datepicker-close').click(function() {
	       			var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
	       			var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
	       			thisCalendar.datepicker('setDate', new Date(year, month, 1));
			     });
		    });
		$( ".datePickermm_yy" ).datepicker({
			     dateFormat: "mm/yy",
			     yearRange: '1900:2100',
			     changeMonth: true,
		         changeYear: true,
		         showButtonPanel: true
		    }).focus(function() {
	            var thisCalendar = $(this);
	            $('.ui-datepicker-calendar').detach();
	            $('.ui-datepicker-close').click(function() {
	       			var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
	       			var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
	       			thisCalendar.datepicker('setDate', new Date(year, month, 1));
			     });
		    });
		$( ".datePickermm_yyFixTop" ).datepicker({
		     beforeShow: function (input, inst) {
		         inst.dpDiv.css({
		          //Recon Baseplus UI issues
		             marginTop: '78px',
		              //Recon Baseplus UI issues
		             marginLeft: '0px'
		         });
		     },
			     dateFormat: "mm/yy",
			     yearRange: '1900:2100',
			     changeMonth: true,
		         changeYear: true,
		         showButtonPanel: true
		    }).focus(function() {
	            var thisCalendar = $(this);
	            $('.ui-datepicker-calendar').detach();
	            $('.ui-datepicker-close').click(function() {
	       			var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
	       			var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
	       			thisCalendar.datepicker('setDate', new Date(year, month, 1));
			     });
		    });
		//<!-- CHANGE FOR IFOX-00406212 START --> 
		$( ".datePickermm_yyFix" ).datepicker({
		     beforeShow: function (input, inst) {
		         inst.dpDiv.css({
		             marginTop: '104px',
		             marginLeft: '0px'
		         });
		     },
			     dateFormat: "mm/yy",
			     yearRange: '1900:2100',
			     changeMonth: true,
		         changeYear: true,
		         showButtonPanel: true
		    }).focus(function() {
	            var thisCalendar = $(this);
	            $('.ui-datepicker-calendar').detach();
	            $('.ui-datepicker-close').click(function() {
	       			var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
	       			var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
	       			thisCalendar.datepicker('setDate', new Date(year, month, 1));
			     });
		    });
		$( ".datePickermm_yyFixPDE" ).datepicker({
		     beforeShow: function (input, inst) {
		    //	 if(window.navigator.userAgent.indexOf("MSIE ")>0 || navigator.userAgent.match(/Trident.*rv\:11\./)){
			         inst.dpDiv.css({
			             marginTop: '0px', //Changed for Base+ UI issues, updated to fix calendar issue
			             marginLeft: '0px'
			         });
			     
		     },
			     dateFormat: "mm/yy",
			     yearRange: '1900:2100',
			     changeMonth: true,
		         changeYear: true,
		         showButtonPanel: true
		    }).focus(function() {
	            var thisCalendar = $(this);
	            $('.ui-datepicker-calendar').detach();
	            $('.ui-datepicker-close').click(function() {
	       			var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
	       			var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
	       			thisCalendar.datepicker('setDate', new Date(year, month, 1));
			     });
		    });		
		//<!-- CHANGE FOR IFOX-00406212 END --> 
		

/*		$( ".datePickermm_yy2" ).datepicker({
		     dateFormat: "mm/yy",
		     yearRange: '1900:2100',
		     changeMonth: true,
	         changeYear: true,
	         showButtonPanel: true,
	         top:'79px'
	    }).focus(function() {
           var thisCalendar = $(this);
           $('.ui-datepicker-calendar').detach();
           $('.ui-datepicker-close').click(function() {
      			var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
      			var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
      			thisCalendar.datepicker('setDate', new Date(year, month, 1));
		     });
	    });*/
		
		$( ".datePickermmddyy" ).datepicker({
			     dateFormat: "mm/dd/yy",
			     yearRange: '1900:2100',
			     changeMonth: true,
		         changeYear: true,
		         showButtonPanel: true
		    }).focus(function() {
/*                 var thisCalendar = $(this);
                 $('.ui-datepicker-close').click(function() {
	        			var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
	        			var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
	        			thisCalendar.datepicker('setDate', new Date(year, month, 1));
			     });*/
		    });
		//<!-- CHANGE FOR IFOX-00406212 START -->
		$( ".datePickermmddyyFix" ).datepicker({
			 beforeShow: function (input, inst) {
		         inst.dpDiv.css({
		             marginTop: '24px',
		             marginLeft: '72px'
		         });
		     },
		     dateFormat: "mm/dd/yy",
		     yearRange: '1900:2100',
		     changeMonth: true,
	         changeYear: true,
	         showButtonPanel: true
	    }).focus(function() {
/*                 var thisCalendar = $(this);
            $('.ui-datepicker-close').click(function() {
       			var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
       			var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
       			thisCalendar.datepicker('setDate', new Date(year, month, 1));
		     });*/
	    });
		//<!-- CHANGE FOR IFOX-00406212 END -->
		// uncomment if you want to select today's date on click of today button in datepicker
		var old_goToToday = $.datepicker._gotoToday
		$.datepicker._gotoToday = function(id) {
		  old_goToToday.call(this,id)
		  this._selectDate(id)
		}
		
	});  
