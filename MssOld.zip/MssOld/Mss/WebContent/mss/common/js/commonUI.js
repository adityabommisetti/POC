// $Id: commonUI.js,v 1.3 2014/08/19 03:32:09 reddyk Exp $
	/* Author : Kishore Allu 
	 * This is the override method for fixing the JS errors for IE 11 and lastest versions of FF and Chrome
	 * This is a temp Fix 
	 * 
	 */

	if(!document.nativeGetElementById){
		document.nativeGetElementById = document.getElementById;
		document.getElementById = function(id)
		{
			var ele = document.nativeGetElementById(id);
			if(ele)
			{
				return ele;
			} else {
				var eles = document.getElementsByName(id);
				if(eles){
					return eles[0];
				}
				
			}
			return null;
		};
	}

function toggleVisibilityDown(x, id) {
	// what is the row check for???
	var row = document.getElementById(id+"_plan");
	var e = document.getElementById(id);
	if(e.style.display == 'none') {
		e.style.display = "";
		if(row!=null)
			row.style.display = "";
		e.setAttribute("rowExpanded", "true");
		x.src = '/mss/jsp/Recon/images/Minus.png';
	} else {
		e.style.display = 'none';
		if(row!=null)
			row.style.display = 'none';
		e.setAttribute("rowExpanded", "false");
		//e.removeAttribute("rowExpanded"); //change on date 26/March by deepak
		x.src = '/mss/jsp/Recon/images/Plus.png';
	}
	
	//resetBodyHeight();
}

/*
Author : Kapil
Discription: Used to hide child node row by UI
*/
function toggleVisibilityUp(x, id) {
	var e = document.getElementById(id);
	if(e.style.display == 'none') {
		e.style.display = "";
		x.src = '/mss/jsp/Recon/images/HideSearch.jpg';
	} else {
		e.style.display = 'none';
		x.src = '/mss/jsp/Recon/images/ShowSearch.jpg';
	}
}

function getForm(val) {
	alert('Yes');
	document.forms[0].action = '/eemAction.do?method=applNewMemberMA';
	document.forms[0].submit();
}

function changeBroker() {
	var e = document.getElementById('category')
	var d1 = document.getElementById('commision');
	var d2 = document.getElementById('agent');
	var d3 = document.getElementById('field');
	d1.style.display = 'none';
	d2.style.display = 'none';
	d3.style.display = 'none';
	
	if (e.value == '0') {
		d1.style.display = '';
	} else if (e.value == '1') {
		d2.style.display = '';
	} else if (e.value == '2') {
		d3.style.display = '';
	}
}