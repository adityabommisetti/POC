function validNoDashZip(zip)
{
	var len = zip.length;
	if ((len != 9) && (len != 5))
		return false;
	if (!isNumeric(zip))
		return false;
	return true;
}
function checkNoDashZipFormat(ctl)
{
	return checkNoDashZipFormat(ctl,true);
}
function checkNoDashZipFormat(ctl,optional)
{
	if (optional) {
		if (isWhitespace(ctl.value))
			return true;
	}
	if (validNoDashZip(ctl.value))
		return true;

	ctl.select();
	ctl.focus();
	alert("Invalid Zip Format (Do not include a dash)");
	return false;
}

function formatSSN(ssn)
{
	var len = ssn.length;
	if (len == 9) {
		if (isNumeric(ssn)) {
			return ssn.substring(0,3) + "-" + ssn.substring(3,5) + "-" + ssn.substring(5);
		}
	}
	return ssn;
}
function validSSN(ssn)
{
	var len = ssn.length;
	if (len == 11) {
		if (isNumeric(ssn.substring(0,3))) {
			if (ssn.charAt(3) == '-') {
				if (isNumeric(ssn.substring(4,6))) {
					if (ssn.charAt(6) == '-') {
						if (isNumeric(ssn.substring(7))) {
							return true;
						}
					}
				}
			}
		}
	}
	return false;
}
function checkSSNFormat(ctl)
{
	return checkSSNFormat(ctl,false)
}
function checkSSNFormat(ctl,optional)
{
	if (optional) {
		if (isWhitespace(ctl.value))
			return true;
	}
	if (validSSN(ctl.value)) {
		return true;;
	}
	ctl.select();
	ctl.focus();
	alert("Invalid SSN Format nnn-nn-nnnn");
	return false;
}
