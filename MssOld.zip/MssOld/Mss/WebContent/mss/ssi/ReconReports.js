var glo_rptTypeArr;
var glo_chkGrouchArr;
var glo_planList;
var isRDTFormat = true;


function setRptTypeObj ( rptTypeObj){	
	glo_rptTypeArr = rptTypeObj;
}

function setCheckboxObj ( checkboxObj){	
	glo_chkGrouchArr = checkboxObj;
}

function setPlanlistObj ( planListObj){
	glo_planList = planListObj;	
}

function setRDTFormat(RDTFormat){
	isRDTFormat = RDTFormat;
}


function refreshReportList(period){
	//alert(" in refreshReport"+period);
	var rptTypeArr = glo_rptTypeArr;	
	var chkGrouchArr = glo_chkGrouchArr;
	var planList = glo_planList;
	var reportSpanArr = document.getElementsByName("reportSpan");
	var availableReport = "";
	var rptType = "";
	var rptName = "";
	var plan = "";
	var selectedPlans;
	var selectedPlansLen = 1;
	var hasPlans = (planList != null && planList != '');

	if ( hasPlans){
		selectedPlans = getSelectedValues(planList)
		selectedPlansLen = selectedPlans.length;
	}

	resetAllReports()

	if ( availableReportArr.length > 0){
		availableReport = availableReportArr[period];
	}

	var reportListLen = rptTypeArr.length;
	var hasSelectable = false;
	var planStr = "";
	
	for ( plan_counter = 0; plan_counter < selectedPlansLen; plan_counter++){ 
		for ( i = 0; i < reportListLen || ( rptTypeArr.value != "undefined" && rptTypeArr.value != null && rptTypeArr.value != ""); i++) { //IFOX-00419340 - Issue 55 - Greyout Unavailabe Reports
			// fix for the case where there is only one report on the menu
			if ( rptTypeArr.value != "undefined" && rptTypeArr.value != null && rptTypeArr.value != "" ) {  //IFOX-00419340 - Issue 55 - Greyout Unavailabe Reports
				rptType = rptTypeArr.value;
				rptTypeArr.value = "undefined";
			}
			else
				rptType = rptTypeArr[i].value;

			// Some of the report values are stored as a concanted string of the 
			// report name, report type and report ind. We need to extract the report name in such cases
			rptName = getPart(rptType,"|");

			planStr = "";

			if ( selectedPlans != null){
				plan = selectedPlans[plan_counter];				
				planStr = plan + ".";				
			}
			
			if (availableReport.indexOf(planStr + rptName) >= 0){
				// we use i+1 to make take into account the "all reports" option
				if(chkGrouchArr[i+1].value !="undefined")
					chkGrouchArr[i+1].value=rptType;
				if(reportSpanArr[i] != null)	{
					reportSpanArr[i].style.color="black";
					reportSpanArr[i].style.fontStyle="normal";
				}
				hasSelectable = true;
			}

		}
	}
	
	chkGrouchArr[0].disabled = !hasSelectable;
	
}



function resetAllReports(){

	var rptTypeArr = glo_rptTypeArr;
	var chkGrouchArr = glo_chkGrouchArr;
	var reportSpanArr = document.getElementsByName("reportSpan");
	var reportListLen = rptTypeArr.length;

	chkGrouchArr[0].checked=false;
	
	// fix for the case where there is only one report on the menu
	if ( rptTypeArr.value != "undefined" && rptTypeArr.value != null && rptTypeArr.value != "") {  //IFOX-00419340 - Issue 55 - Greyout Unavailabe Reports
		if(chkGrouchArr[1].value !="undefined")
		chkGrouchArr[1].value="DIS";
		chkGrouchArr[1].checked=false;
		reportSpanArr[0].style.color="gray";
		reportSpanArr[0].style.fontStyle="italic";
	}
	
	for ( i = 0; i < reportListLen; i++){
		// we use i+1 to make take into account the "all reports" option;
		if(chkGrouchArr[i+1].value !="undefined")
		chkGrouchArr[i+1].value="DIS";
		chkGrouchArr[i+1].checked=false;
		reportSpanArr[i].style.color="gray";
		reportSpanArr[i].style.fontStyle="italic";
	}

}

function getSelectedValues(obj){
	var len = obj.length
	var selectedArr = new Array();
	var counter = 0;

	for ( i=0; i< len; i++ ){
		if(obj.options[i].selected){
			selectedArr [ counter++] = obj.options[i].value
		}
	}

	return selectedArr;
}


function doNAService()
{
	alert("This report is unavailable. ");
	return false;
}

function doCancel(server)
{
    location.href="https://" + server + "/mss/jsp/ReportsMenuJsp.jsp";
    //self.close();
}

function reportSelectAction(field, index){
	//alert(" in");
	var chkGrouchArr = glo_chkGrouchArr;
	
	if ( chkGrouchArr[index].value == "DIS"){
		//alert("in if");
		return doNAService();
	}else{
		//alert("in else");
		checkChoice(field, index)
	}
}

function checkChoice(field, i)
{
	//alert(" in check"+"i="+i);
if (i == 0) // "All" checkbox selected.
{
	if (field[0].checked == true)
		{for (i = 1; i < field.length; i++)
			if (field[i].value != "DIS")	//check all checkboxes, uncheck the ALL one
			{
			field[i].checked = true;
			}
		}
	else
	{if (field[0].checked == false)
		{for (i = 1; i < field.length; i++)
			field[i].checked = false;
		}
	}
}
else
{//alert(" in check else");
	if (field[i].checked == false)
	{
		field[0].checked = false;
	}
}

}

function EditSel(form)
{
	// Count the number of plan ids selected, at least one needs to be selected
	var total = 0;
	var max = 1;
	var hasPlans = (glo_planList != null);
	
	if ( hasPlans){
		max = glo_planList.options.length;
	
		for (var idx = 0; idx < max; idx++)
		{
			if (glo_planList.options[idx].selected && glo_planList.options[idx].value != "")
			{
				total += 1;
			}
		}
		if (total == 0)
		{
			alert("At least one plan needs to be selected");
			return false;
		}
	}


	// Count the number of reports selected, at least one needs to be selected
	total = 0;
	
	period = document.forms[0].reportPeriod.value;

	var delimiter = period.indexOf("_");
	var year = period.substring(0, delimiter);
	var month = period.substring(delimiter + 1);
	var selectedPlans = null;
	var selectedPlansLen = 1;
	var chosenReports = "";
	var hasDateTimeStamp = "";
	var reportPeriodStr = "";
	var dateTimeStr = "";
	
	if ( typeof(dateTimeStamp) != "undefined" && dateTimeStamp != null){
		hasDateTimeStamp = true;
	}
	
	if ( hasPlans){
		selectedPlans = getSelectedValues(glo_planList)
		selectedPlansLen = selectedPlans.length;
	}
	
	availableReports = availableReportArr[period];
	reportPeriodStr = getReportingPeriod(period);
	
	for ( var pdx = 0; pdx < selectedPlansLen; pdx++){	
		
		if ( hasPlans){
			curPlan = selectedPlans[pdx];
		}	
		
		max = glo_chkGrouchArr.length;
		
		for (var idx = 0; idx < max; idx++)
		{
			var checkBoxObj = glo_chkGrouchArr[idx]
			
			
			if (checkBoxObj.checked == true && checkBoxObj.value != "ALL")
			{
				total += 1;
				curPlanStr = "";
				dateTimeStr = "";
				
				reportName = getPart(checkBoxObj.value,"|");	

				if ( hasPlans){
					curPlanStr = curPlan + ".";
				}
								
				if ( hasDateTimeStamp){
					dateTimeStr = "." + dateTimeStamp[curPlanStr + reportName + "." + reportPeriodStr];
				}
				
				fullyQualifiedRptName = curPlanStr + reportName;

				if(availableReports.indexOf("|" + fullyQualifiedRptName + "|") >= 0){
					if(isRDTFormat){
						chosenReports = chosenReports + "|" + curPlanStr + reportName + "." + reportPeriodStr + dateTimeStr;
					}else{
						chosenReports = chosenReports + "|" + reportPeriodStr + "." + curPlanStr + reportName + dateTimeStr;
					}
				}		
			}
		}		
	}

	if (total == 0)
	{
	alert("At least one report needs to be selected");
	return false;
	}

	document.forms[0].selectedFiles.value = chosenReports;
}

// NOTE : This is a method written as a fix for allowing PLR reports to download multiple files for the same month
// These filenames will differ only in the date and time part.
// ppalat 08/28/07

function EditSelPLR(form)
{
	// Count the number of plan ids selected, at least one needs to be selected
	var total = 0;
	var max = 1;
	var hasPlans = (glo_planList != null);
	var thisReport = "";	
	var delimiterThisRep = "";
	
	if ( hasPlans){
		max = glo_planList.options.length;
	
		for (var idx = 0; idx < max; idx++)
		{
			if (glo_planList.options[idx].selected && glo_planList.options[idx].value != "")
			{
				total += 1;
			}
		}
		if (total == 0)
		{
			alert("At least one plan needs to be selected");
			return false;
		}
	}


	// Count the number of reports selected, at least one needs to be selected
	total = 0;
	
	period = document.forms[0].reportPeriod.value;

	var delimiter = period.indexOf("_");
	var year = period.substring(0, delimiter);
	var month = period.substring(delimiter + 1);
	var selectedPlans = null;
	var selectedPlansLen = 1;
	var chosenReports = "";
	var hasDateTimeStamp = "";
	var reportPeriodStr = "";
	var dateTimeStr = "";
	
	if ( typeof(dateTimeStamp) != "undefined" && dateTimeStamp != null){
		hasDateTimeStamp = true;
	}
	
	if ( hasPlans){
		selectedPlans = getSelectedValues(glo_planList)
		selectedPlansLen = selectedPlans.length;
	}
	
	availableReports = availableReportArr[period];
	reportPeriodStr = getReportingPeriod(period);
	
	for ( var pdx = 0; pdx < selectedPlansLen; pdx++){	
		
		if ( hasPlans){
			curPlan = selectedPlans[pdx];
		}	
		
		max = glo_chkGrouchArr.length;
		
		for (var idx = 0; idx < max; idx++)
		{
			var checkBoxObj = glo_chkGrouchArr[idx]
			thisReport = "";
			delimiterThisRep= "";
			
			if (checkBoxObj.checked == true && checkBoxObj.value != "ALL")
			{
				total += 1;
				curPlanStr = "";
				dateTimeStr = "";
				
				reportName = getPart(checkBoxObj.value,"|");	

				if ( hasPlans){
					curPlanStr = curPlan + ".";
				}
								
				if ( hasDateTimeStamp){
					dateTimeStr = "." + dateTimeStamp[curPlanStr + reportName + "." + reportPeriodStr];
					
					for ( i in dateTimeStamp){
						len = i.length;
						endPos = len - 17;
						
						if ( i.substring(0,endPos) == (curPlanStr + reportName + "." + reportPeriodStr)){
														
							if ( isRDTFormat){
								thisReport = thisReport + delimiterThisRep + curPlanStr + reportName + "." + reportPeriodStr + i.substring(endPos);								
							}else{
								thisReport = thisReport + delimiterThisRep + reportPeriodStr + "." + curPlanStr + reportName + i.substring(endPos);
							}
							delimiterThisRep = "|";
							
						}
					}
					
				}
				
				fullyQualifiedRptName = curPlanStr + reportName;

				if(availableReports.indexOf("|" + fullyQualifiedRptName + "|") >= 0){
					if(isRDTFormat){
						chosenReports = chosenReports + "|" + thisReport;
					}else{
						chosenReports = chosenReports + "|" + thisReport;
					}
				}		
			}
		}		
	}

	if (total == 0)
	{
	alert("At least one report needs to be selected");
	return false;
	}

	document.forms[0].selectedFiles.value = chosenReports;
}

function getPart(source, delimiter){

	if (source.indexOf(delimiter) < 0){
		return source
	}else{
		var arr = source.split(delimiter);
		return arr[0];
	}
}

function doAllPlans(allPlanObj){
    if (allPlanObj.checked)
    {
        for (var i = 0; i < glo_planList.length; i++)
            glo_planList.options[i].selected = true; 
    }
}

function getReportingPeriod(periodVal){
	var delimPos = periodVal.indexOf("_")
	var year = periodVal.substr(0, 4);
	var month = periodVal.substr(5);
	return "R" + year + month;
}