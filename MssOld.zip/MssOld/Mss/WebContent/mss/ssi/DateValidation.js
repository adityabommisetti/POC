function dateCompare(d1,d2,mdy)
{
    var cd1;
    var cd2;

    if (mdy) {
        cd1 = d1.substring(6,10) + d1.substring(0,2) + d1.substring(3,5);
        cd2 = d2.substring(6,10) + d2.substring(0,2) + d2.substring(3,5);
    } else {
        cd1 = d1.substring(3,7) + d1.substring(0,2);
        cd2 = d2.substring(3,7) + d2.substring(0,2);
    }
    
    return (cd1 - cd2);

}

function validateDate(ele) {
	var dte = ele.value;
	
    var rslt = parseDateFld9(dte,true,true,"",false);
	if(rslt == 'NaD') {
		ele.select();
		ele.focus();
		return false;
	}
	ele.value = rslt;
	return true;
}

function validateDate(ele, allowNines) {
	var dte = ele.value;
	
    var rslt = parseDateFld9(dte,true,true,"",allowNines);
	if(rslt == 'NaD') {
		ele.select();
		ele.focus();
		return false;
	}
	ele.value = rslt;
	return true;
}
//Date Format return MM/DD/YYYY
function dateFrmt(dte){
	return dte.substring(4, 6)+"/"+dte.substring(6, 8)+"/"+dte.substring(0, 4);;
}
function parseDate(dte,dispMsg,mdy)
{
	
    return parseDateFld9(dte,dispMsg,mdy,"",false);
}

function parseDateFld(dte,dispMsg,mdy,fldName)
{
	return parseDateFld9(dte,dispMsg,mdy,fldName,false);
}

function parseDateFld9(dte,dispMsg,mdy,fldName,allowNines)
{
	
    var l;
    var i;
    var c;
    var tmp;
    var mth;
    var day;
    var year;
    var sMth;
    var sDay;
    var sYear;
    var sdate;
    var daysInMth;
    var dfm;

    if (mdy)
        dfm = "Please Format As MM/DD/YYYY";
    else
        dfm = "Please Format As MM/YYYY";

    tmp = Rtrim(Ltrim(dte));
    if (tmp == "")
        return "";

    l = tmp.length;
    for (i = 0; i < l; i++)
    {
        c = tmp.charAt(i);
        if ((!isDigit(c)) && (!isDateDelim(c)))
        {
            if (dispMsg)
                dispDateErrorMsg(fldName,"Invalid character in date",mdy);
            return "NaD";
        }
    }

    i = tmp.indexOf('/');
    if (i == -1)
    {
        i = tmp.indexOf('-');
        if (i == -1)
        {
            i = tmp.indexOf('.');
        }
    }
    if (i == -1)
    {
        if (dispMsg)
            dispDateErrorMsg(fldName,"Invalid date Format in Month",mdy);
        return "NaD";
    }
    mth = parseInt(tmp.substring(0,i),10);
    tmp = tmp.substring(i+1,tmp.length+1);

    if (mdy)
    {
        i = tmp.indexOf('/');
        if (i == -1)
        {
            i = tmp.indexOf('-');
            if (i == -1)
            {
                i = tmp.indexOf('.');
            }
        }
        if (i == -1)
        {
            if (dispMsg)
                dispDateErrorMsg(fldName,"Invalid date Format in Day",mdy);
            return "NaD";
        }
        day = parseInt(tmp.substring(0,i),10);
        tmp = tmp.substring(i+1,tmp.length+1);
    }

    i = tmp.indexOf('/');
    if (i == -1)
    {
        i = tmp.indexOf('-');
        if (i == -1)
        {
            i = tmp.indexOf('.');
        }
    }
    if (i != -1)
    {
        if (dispMsg)
            dispDateErrorMsg(fldName,"Invalid date Format in Year",mdy);
        return "NaD";
    }
    year = parseInt(tmp.substring(0,tmp.length+1),10);
    if (year < 1)
    {
        if (dispMsg)
            dispDateErrorMsg(fldName,"Invalid year",mdy);
        return "NaD";
    }

    sYear = ""+year;
    if (sYear.length != 4)
    {
        if (dispMsg)
            dispDateErrorMsg(fldName,"Invalid date Format 4 digit year required",mdy);
        return "NaD";
    }

	if (allowNines) {
		if (sYear == "9999") {
	    	if (mdy)
    		{
				if ((mth == 99) && (day == 99))
					return "99/99/9999";
	        	if (dispMsg)
	            	dispDateErrorMsg(fldName,"Invalid Month/Day for Opened Ended Date Value",mdy);
			} else {
				if (mth == 99)
					return "99/9999";
	        	if (dispMsg)
	            	dispDateErrorMsg(fldName,"Invalid Month for Opened Ended Date Value",mdy);
			}	
			return "NaD";
		}
	}
	
    if ((mth < 1) || (mth > 12))
    {
        if (dispMsg)
            dispDateErrorMsg(fldName,"Invalid Month " + mth,mdy);
        return "NaD";
    }

    if (mdy)
    {
        daysInMth = lastDOM(mth,year);
        if ((day < 1) || (day > daysInMth))
        {
            if (dispMsg)
                dispDateErrorMsg(fldName,"Invalid Day of Month",mdy);
            return "NaD";
        }

        sDay = ""+day;
        if (day <= 9)
            sDay = "0" + sDay;

    }

    sMth = ""+mth;
    if (mth <= 9)
        sMth = "0" + sMth;

    if (mdy){
        sDate = sMth + "/" + sDay + "/" + sYear;
   
    }
    else
        sDate = sMth + "/" + sYear;

    return sDate;
}
function lastDOM(mth,yr)
{
    var daysInMth;
    
    if ((mth == 4) || (mth == 6) || (mth == 9) || (mth == 11))
        daysInMth = 30;
    else
    if (mth == 2)
    {
        if ( ( ((yr % 4) == 0) && ((yr % 100) != 0) ) || ((yr % 400) == 0) )
            daysInMth = 29;
        else
            daysInMth = 28;
    }
    else
        daysInMth = 31;
    
    return daysInMth;
}
function isFldDate(fld,fldName,mdy)
{
	return isFldDate9(fld,fldName,mdy,false);
}
function isFldDate9(fld,fldName,mdy,allowNines)
{
    if (isWhitespace(fld.value)) {
        alert(fldName + " is required");
        fld.focus();
        fld.select();
        return false;
    }
    if (parseDateFld9(fld.value,true,mdy,fldName,allowNines) == "NaD")
    {
        fld.focus();
        fld.select();
        return false;
    }
    return true;
}
function dispDateErrorMsg(fldName,msg,mdy)
{
    var dispMsg

    dispMsg = msg + "\n";
    if (mdy)
        dispMsg = dispMsg + "Please Format As MM/DD/YYYY";
    else
        dispMsg = dispMsg + "Please Format As MM/YYYY";
    if (fldName != "")
        dispMsg = fldName + " is incorrect\n\n" + dispMsg;
    alert(dispMsg);
}
function isStartBeforeEndDate(startDtCtl,endDtCtl,mdy)
{   
    if (isWhitespace(startDtCtl.value))
        return false;
    if (isWhitespace(endDtCtl.value))
        return false;
    
    if (dateCompare(startDtCtl.value,endDtCtl.value,mdy) > 0)
    {
        alert("Start Date Greater Than End Date");
        startDtCtl.focus();
        startDtCtl.select();
        return true;
    }
    
    return false;
}

function monthsBetween(startDt,endDt)
{
    var startYYYY;
    var endYYYY;
    var startMM;
    var endMM;
    var startLen;
    var endLen;
    var numEnd;
    var numStart;
    var numM;
    
    startLen = startDt.length;
    endLen = endDt.length;
    
    startYYYY = parseInt(startDt.substring(startLen - 4),10);
    endYYYY = parseInt(endDt.substring(endLen - 4),10);
    
    startMM = parseInt(startDt.substring(0,2),10);
    endMM = parseInt(endDt.substring(0,2),10);

    numEnd = (endYYYY * 12) + endMM;
    numStart = (startYYYY * 12) + startMM;
    if (numEnd < numStart)
    	numM = 0 - (numStart - numEnd);
	else
		numM = (numEnd - numStart);
        
    //alert("Start: " + startYYYY + " " + startMM + " " + numStart + "\n" +
    //      "  End: " + endYYYY + " " + endMM + " " + numEnd + "\n" +
    //      numM);
    
    return numM;
}
function checkLDOM(dte,msg,allowNines) {
    if (isLDOM(dte.value,allowNines))
       return true;

    alert(msg + " is not the last day of the month");
   	dte.focus();
   	dte.select();   
    return false;
}
function isLDOM(dte,allowNines)
{
    var yr;
    var mth;
	var day;
	var lDom;
		
	if (dte.length != 10)
		return false;
	
    mth = parseInt(dte.substring(0,2),10);
    day = parseInt(dte.substring(3,5),10);
    yr = parseInt(dte.substring(6),10);

	if (allowNines) {
		if ((mth == 99) && (day == 99) && (yr == 9999))
			return true;
	}
	
	lDom = lastDOM(mth,yr)
	if (lDom == day)
		return true;
		
	return false;
}
function checkFDOM(dte,msg) {
    if (isFDOM(dte.value))
       return true;

    alert(msg + " is not the first day of the month");
   	dte.focus();
   	dte.select();   
    return false;
}
function isFDOM(dte)
{
    var yr;
    var mth;
	var day;
	var lastDom;
	
	if (dte.length != 10)
		return false;
	
    day = parseInt(dte.substring(3,5),10);
	if (day == 1)
		return true;
			
	return false;
}

/**
* 033_Highmark_OAASCCprocess - Start
*/
//UAT It3  bug fix-start
function setdisenrollDate(date,plan,reason,type){
	
	//alert("in disenrolldate");
		var m;
		var dm;
		var y;
		var d;
		var dsdate;
		m=date.substring(0,2);
		d=date.substring(3,5);
		y=date.substring(6,10);
	 //alert(date);
		//alert(m+d+y);
		//m=parseInt(date.toString().substring(0,2));
//		alert(reason);
		dm=m;
		//alert(dm);
//		alert("type=="+type);
		if(type=="TEMP"){
			//alert(reason);
	//UAT Iteration 2 start 
		if(reason!="04"){
			//UAT Iteration 2 end 
			if(plan=="MAPD" || plan=="MA"){
			//	alert("in");
					if(m==0){
						m=parseInt(date.substring(1,2));
						//alert(m);
						//commented for #721 bug -adding 7 months
					//	if(d.valueOf().toString()=='01'||d.valueOf().toString()=='1')
						//	dm=m+6;
						
						//else
							dm=m+7;	
						
							
			    		}
					else{
						
						//commented for #721 bug -adding 7 months
						//	if(d.valueOf().toString()=='01'||d.valueOf().toString()=='1')
							//	dm=m+6;
							
							//else
							dm=parseInt(m)+7;
						
						}
					//alert(dm);
					if(dm>12){
							dm=dm-12;
						
							y=parseInt(date.substring(6,10))+1;
						
						}
					if(dm.toString().length==1){
						dm="0"+dm;
					}
					
			}
			 else if(plan=="PDP"){
				 y=parseInt(y.toString());
				 y=y+1;
				 if(m==0)
					m=parseInt(date.substring(1,2));
				 dm=m;
				// if(!(d.valueOf().toString()=='01'||d.valueOf().toString()=='1'))
					// alert("inside");
						dm=parseInt(m)+1;
				 if(dm.toString().length==1){
						dm="0"+dm;
				} 
			 }
			d="01";
		//	alert(d);
			}
		//UAT Iteration 2 start 
		else if(reason=="04"){
			//UAT Iteration 2 end 
		
			 if(m==0){
					m=parseInt(date.substring(1,2));
					dm=m;
			 }
			 else
				 dm=parseInt(m)
			if(d==0){
				d=parseInt(date.substring(4,5));
				d=d+45;
					
	    		}
			else{
				d=parseInt(d)+45;
				//alert(d);	
				}
			//UAT Iteration-3 start
			if(d>60){
				d=d-30;
				//alert(d);
				
				dm=dm+1;
				
			}
			if(d>30){
				d=d-30;
				
				//alert(d);
				dm=dm+1;
				
			}
			//alert("before if d="+d+" dm"+dm);
			if(d.valueOf().toString()!='01'||d.valueOf().toString()!='1')
			{ //(" in if");alert
				dm=dm+1;
				d="01";
			}
			
		
		
			if(dm>12){
				dm=dm-12;
			
				y=parseInt(date.substring(6,10))+1;
			
			}

			if(d.toString().length==1){
				//alert("d value");
				d="0"+d;
			}
			if(dm.toString().length==1){
				dm="0"+dm;
			}
			//alert(d);
			//UAT -iteration 3 end
			//alert(d);
		}	
	}
		else if(type=="PERM"){
			
			if(m==0){
				m=parseInt(date.substring(1,2));
				dm=m;
	    		}
			
			//Commented for #721 -adding 1 month
			//if(d.valueOf().toString()!='01' && d.valueOf().toString()!='1')
			//{ //(" in if");alert
				dm=parseInt(dm)+1;
				d="01";
			//}
				
			if(dm>12){
				
					dm=dm-12;
				
					y=parseInt(date.substring(6,10))+1;
				
				}
			if(dm.toString().length==1){
				dm="0"+dm;
			}	
			d="01";
		}
		d="01";
	dsdate=dm + "/" + d+ "/" +y ;
	
	return dsdate;

	}
//UAT It3  bug fix-end	
	
function validateOoaDate(dte, msg, plan,currDate){
  
   var mthDte;
   var mthCurr;
   var dayDte;
   var dayCurr;
   var yearDte;
   var yearCurr;
   var mthLim;
   var dayLim;
   var yearLim;
   var limitDate;
   var m;
   if(msg != "Leave Date"){
	 
   mthDte = dte.value.substring(0,2);

   mthCurr = currDate.toString().substring(4,6);
   
   dayDte = dte.value.substring(3,5);
   dayCurr = currDate.toString().substring(6,8);
   yearDte = dte.value.substring(6,10);
   yearCurr = currDate.toString().substring(0,4);
   
   if(yearDte>yearCurr){
   alert(msg + " cannot be future date");
          dte.focus();
          dte.select();   
       return false; 
   }
   else{
   if(yearDte==yearCurr){
   if(mthDte>mthCurr){
          alert(msg + " cannot be future date");
        dte.focus();
        dte.select();   
        return false;
   }
   
    else{if(mthDte==mthCurr){
          if(dayDte>dayCurr){
               alert(msg + " cannot be future date");
               dte.focus();
               dte.select();   
              return false;
          }
   }
   }
   }
   }
  
   }
   if(plan=="MAPD" || plan=="MA"){
          m=parseInt(currDate.toString().substring(4,6));
          if(m==0){
           m=parseInt(currDate.toString().substring(5,6));
          }
          mthDiff=m-6;
   
          if(mthDiff.toString().length==1){
               mthDiff="0"+mthDiff;
          }
         // alert(mthDiff);
          var i = parseInt(mthDiff);
          //alert(i);
                    if(i<0){
                          //alert(" in if");
                          //var y = currDate.toString.substring(0,4);
                          //alert(y);
                          //alert(yearCurr);
                          year=parseInt(yearCurr)-1;
                    //alert(year);
                          m=parseInt(currDate.toString().substring(4,6));
                          if(m==0){
                               m=parseInt(currDate.toString().substring(5,6));
                          }
                          mth=m-mthDiff;
                          if(mth.toString().length==1){
                          mth="0"+mth;
                     }
                        limitDate = mth+"/"+dayCurr+"/"+year;
                    
                    }
                    else{
                         
                          limitDate = mthDiff+"/"+dayCurr+"/"+yearCurr;
                        
                    
                          
                          }
                    mthLim = limitDate.substring(0,2);
                     dayLim = limitDate.substring(3,5);
                     yearLim = limitDate.substring(6,10);
                     
                     if(yearDte<yearLim){
                          alert(msg + " cannot be Past 180 days for plan :"+ plan);
                                dte.focus();
                                dte.select();   
                             return false; 
                      }
                      else{
                        if(yearDte==yearLim){
                          if(mthDte<mthLim){
                                alert(msg + " cannot be past 180 days for plan: "+plan);
                               dte.focus();
                               dte.select();   
                              return false;
                           }
                          
                          else{if(mthDte==mthLim){
                                if(dayDte<dayLim){
                                     alert(msg + " cannot be past 180 days for plan: "+plan);
                                     dte.focus();
                                     dte.select();   
                                    return false;
                                }
                                else
                                     return true;
                             }
                          }
                        }
                      }
                    
               }
               else if(plan=="PDP"){
                    yearDiff=(parseInt(currDate.toString().substring(0,4))-1);
                    limitDate=mthCurr+"/"+dayCurr+"/"+yearDiff;
                    //alert(limitDate);
                    mthLim = limitDate.substring(0,2);
                     dayLim = limitDate.substring(3,5);
                     yearLim = limitDate.substring(6,10);
                     if(yearDte<yearLim){
                          alert(msg + " cannot be Past 363 days for plan: "+plan);
                                dte.focus();
                                dte.select();   
                             return false; 
                      }
                      else{
                        if(yearDte==yearLim){
                          if(mthDte<mthLim){
                                alert(msg + " cannot be past 363 days for plan: "+plan);
                               dte.focus();
                               dte.select();   
                              return false;
                           }
                          
                          else{if(mthDte==mthLim){
                                if(dayDte<dayLim){
                                     alert(msg + " cannot be past 363 days for plan: "+plan);
                                     dte.focus(); 
                                     dte.select();   
                                    return false;
                                }
                                else
                                     return true;
                             }
                          }
                        }
                      }
                    
               }
          
    
  
  
   return true;
   }

//----------- Additional Date library ----------
function isValidDate(dateStr) {
	// accepts date in MM/DD/YYYY 
  	var re = new RegExp('^(\\d{2}\\/\\d{2}\\/\\d{4})$');
  	var flag = false;
  	var dt=null;
  	var newDt=null;
    if(re.test(dateStr)){
    	dt=new Date(dateStr);
        if( ("Invalid Date" != dt) && (dt!=undefined) && (dt!=null)){        
        	newDt=	lpad((dt.getMonth()+1),"0",2)+"/"+lpad(dt.getDate(),"0",2)+"/"+dt.getFullYear();
        	flag=(dateStr == newDt)?true:false;
        }        
    }
    return flag;
}
function compareDate(from,to){
	var result="NaD";
    var newFrom=null;
    var newTo=null;
    if(isValidDate(from) && isValidDate(to) ){
		newFrom=new Date(from).getTime();
        newTo=new Date(to).getTime();
		result=(newFrom == newTo)?0:(newFrom < newTo)?-1:1;
    }
	return result;
}
	/**
	 * 033_Highmark_OAASCCprocess - END
	 */
	/**
	 * Cambia_PWO-Start
	 */
	function checkPastDate(dte,msg,msg1,cpm) {
		
	    var mthDte;
	    var mthCpm;
	    var dayDte;
	    var dayCpm;
	    var yearDte;
	    var yearCpm;
	   // alert("in formatt date"+dte+cpm);
	    mthDte = dte.value.substring(0,2);
	    mthCpm = cpm.value.substring(0,2);
	    dayDte = dte.value.substring(3,5);
	    dayCpm = cpm.value.substring(3,5);
	    yearDte = dte.value.substring(6,10);
	    yearCpm = cpm.value.substring(6,10);
	    //alert(mthDte+mthCpm+dayDte+dayCpm+yearDte+yearCpm);
	    if(yearDte<yearCpm){
	    	alert(msg +" "+ msg1);
	       	dte.focus();
	       	dte.select();   
	        return false;	
	    }
	    else{
	    	if(yearDte==yearCpm){
	    	if(mthDte<mthCpm){
	    		//alert(" in less month");
	    		alert(msg + " " +msg1);
	    	   	dte.focus();
	    	   	dte.select();   
	    	    return false;
	    	}
	    	
	    	else{if(mthDte==mthCpm){
	    		if(dayDte<dayCpm){
	    			alert(msg+" " + msg1);
	    		   	dte.focus();
	    		   	dte.select();   
	    		    return false;
	    		}
	    		else{
	    			return true;
	    		}
	    	}
	    	}
	    	}
	    }
	    return true;
	}
	/**
	 * Cambia_PWO-End
	 */  