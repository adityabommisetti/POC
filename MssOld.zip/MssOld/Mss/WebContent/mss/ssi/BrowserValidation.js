
/****************************************************************/
function browser(sItem) {
	var browserName = navigator.appName;
	var browserVersion = navigator.appVersion;
	var browserVersionNum = parseFloat(browserVersion);
	var sAgent =navigator.userAgent;
	var iMinorVer ="";
	var iMajorVer ="";
	var sFullVer = "";
	var bIE = false;
	var bIsNav= false;
	var bIncBuild=false;
	if (sAgent.indexOf("MSIE")!=-1){
		if (sAgent.charAt(sAgent.indexOf("MSIE")+7)>0 ){
			iMinorVer = sAgent.charAt(sAgent.indexOf("MSIE")+7)
			bIncBuild = true
		}else
			iMinorVer = sAgent.charAt(sAgent.indexOf("MSIE")+8)
		iMajorVer = sAgent.charAt(sAgent.indexOf("MSIE")+5)
	} else if (sAgent.indexOf("MSPIE")!=-1){
	   	iMinorVer = sAgent.charAt(sAgent.indexOf("MSPIE")+9)
		iMajorVer = sAgent.charAt(sAgent.indexOf("MSPIE")+6)
	} else {
		iMinorVer = sAgent.charAt(11)
		iMajorVer = sAgent.charAt(8)
	}
	if (iMinorVer == ";")
		iMinorVer = 0;
	else
		if ((iMinorVer == "b") || (iMinorVer == "p"))
			iMinorVer = "0" + iMinorVer + (sAgent.charAt(sAgent.indexOf("MSIE")+9));
		else
			if (bIncBuild)
				iMinorVer = iMinorVer
			else
				iMinorVer = "0" + iMinorVer;

	if (sAgent.indexOf('MSIE') !=-1)
	{
		browserName = "IE"
		bIE = true;
		sFullVer = iMajorVer + "." + iMinorVer;
	}
	else
		if ((sAgent.indexOf("Mozilla")!=-1) && (sAgent.indexOf("compatible") == -1))
	{
		browserName = "Netscape"
		bIsNav  = true;
		sFullVer = browserVersionNum;
	}
	if (sItem.toUpperCase()=="NAME")
		return browserName;
	if (sItem.toUpperCase()=="VERSION")
		return sFullVer;
}

/****************************************************************/
function checkBrowser(){
	var browserVersion=new String(browser("version"));
	var browserName=new String(browser("name"));

	bInvalid=true;

	if (browserName=="IE")
	{
		if (browserVersion>="4.0")
			bInvalid=false;
	}
	else
	{
		if (browserName=="Netscape")
		{
			if (browserVersion>="4.7")
			{
				//alert("Valid version");
				bInvalid=false;
			}
		}
		else
		{
			browserName="Unknown"
		}
	}
	if (bInvalid)
	{
		alert ("You are using " + browserName + " version " + browserVersion +
		".\nThis version does not work with our Web Application." +
		"\nOur minimum requirement is Internet Explorer 4.01, or Netscape 4.7");
		return false;
	} else
		return true;
}
