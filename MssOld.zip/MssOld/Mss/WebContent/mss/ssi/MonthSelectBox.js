// MonthSelectBox.js

/***** Revised on 05/28/07 for using in WriteOffCriteria ****

 Commented line 64 and 69, since the Graphs object is not available universally
 Added method formatDate (earlier used inline in ReconGraphsJsp)

****************/

var monthArr = new Array('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');
var monthValArr = new Array('01','02','03','04','05','06','07','08','09','10','11','12');

var curYear=new Date().getYear();

var isEditMode = false;
var isMonthSelected = false;
var isYearSelected = false;

var month="";
var year="";

var resultBox;
var formattedResultBox;
var editBox;

var displayDiv;
var editDiv;

// Hack for IE 6.0, since IE fires up the onBlur event when onChange is called.
var allowBlurVal=true;

var DATE_FORMAT="MM/YYYY";
var VALUE_DATE_FORMAT="YYYYMM";


function selectMonth (v_displayDiv, v_editDiv, v_monthTextBox, v_dropDownBox){
	writeLog("Called in selectMonth ");
	resultBox = document.getElementById("" + v_monthTextBox + "");
	formattedResultBox = document.getElementById("" + v_monthTextBox.replace("UI_","") + "");
	editBox = document.getElementById("" + v_dropDownBox + "");
	
	displayDiv = document.getElementById("" + v_displayDiv + "");
	editDiv = document.getElementById("" + v_editDiv + "");

	if ( resultBox.value != ""){
		indexMonth=DATE_FORMAT.indexOf("MM");
		indexYear=DATE_FORMAT.indexOf("YYYY");
		month = resultBox.value.substring(indexMonth,indexMonth+2);
		year = resultBox.value.substring(indexYear, indexYear+4);
	}

	setEditMode(!isEditMode);
}

function setEditMode(editMode){
	writeLog("Called in setEditMode " + editMode );
	isEditMode=editMode;
	if ( editMode){
		isMonthSelected=false
		isYearSelected=false
		editDiv.style.display="block"
		displayDiv.style.display="none"
		displayDiv.style.zIndex=99999
		if ( document.getElementById("Graph") != null){
			document.getElementById("Graph").disabled=true
		}
		fillMonths();
	}else{
		editDiv.style.display="none"
		displayDiv.style.display="block"
		if ( document.getElementById("Graph") != null){
			 document.getElementById("Graph").disabled=false
		}
		setValue(month, year);
	}
}

function setValue(month, year){
	writeLog("Called in setValue " + month + "  " + year);
	if ( month == ""){
		month = new Date().getMonth() + 1;
	}

	if ( year == ""){
		year = new Date().getYear();
	}

	dateTmp = DATE_FORMAT.replace("MM", month);
	resultBox.value= dateTmp.replace("YYYY", year);
	formattedResultBox.value = formatDate(resultBox.value, DATE_FORMAT, VALUE_DATE_FORMAT);

}

function cancelSelect(){
	writeLog("Called in cancelSelect ");
	setEditMode(false);
	setBlur(true)
}

function fillMonths(){

	var selectBox = editBox;
	selectBox.options.length=0
	for ( i=0; i< monthArr.length; i++){
		var option = new Option(monthArr[i], monthValArr[i]);
		selectBox.options[i]=option
	}
	selectBox.focus()
}

function fillYear(){
	writeLog("Called in fillYear ");
	var selectBox = editBox;
	selectBox.options.length=0
	index = 0
	for ( i=curYear; i >= 2002; i--){
		var option = new Option(i, i);
		selectBox.options[index]=option
		index++
	}
	selectBox.focus()
}

function selectValue(){
	writeLog("Called in selectVal");
	var selectBox = editBox;
	
	if ( ! isMonthSelected){
		isMonthSelected=true;
		month=selectBox.options[selectBox.options.selectedIndex].value		
		fillYear();
	}else{
		isYearSelected=true;
		year=selectBox.options[selectBox.options.selectedIndex].value
		setEditMode(false);
	}
}

function setBlur(blurVal){
	writeLog("Called in setBlur " + blurVal);
	allowBlurVal = blurVal;
}

function allowBlur(){
	writeLog("Called in allowBlur " + allowBlurVal);
	return allowBlurVal;
}

function writeLog(s){
	/*
	textarea = document.getElementById("txtarea");
	textarea.value =  textarea.value + "\n" + new Date() + "  :  "+ s
	*/
}

function formatDate ( dateValue, sourceFormat, targetFormat){

	indexMonth = sourceFormat.indexOf("MM");
	indexYear = sourceFormat.indexOf("YYYY");

	month=dateValue.substring(indexMonth, indexMonth + 2);
	year=dateValue.substring(indexYear, indexYear + 4);

	formattedDate = targetFormat.replace("MM", month);
	formattedDate = formattedDate.replace("YYYY", year);

	return formattedDate;

}

