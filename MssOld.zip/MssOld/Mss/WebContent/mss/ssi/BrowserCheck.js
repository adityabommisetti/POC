function getBrowserName()
{
    if (navigator.appName.indexOf("Netscape") != -1)
        return "Netscape";

    if (navigator.appName.indexOf("Microsoft") != -1)
        return "MSIE";

    return "OTHER";
}

function getBrowserVersion()
{
    var version;
    var sAgent;
    var pos;
    var len
    var c;

    if (navigator.appName.indexOf("Netscape") != -1)
        return navigator.appVersion;

    if (navigator.appName.indexOf("Microsoft") != -1)
    {
        version = "";
        sAgent = navigator.userAgent;
        pos = sAgent.indexOf("MSIE");
        if (pos > 0)
        {
            pos += 5;
            len = navigator.userAgent.length();
            while (pos < len)
            {
                c = sAgent.charAt(pos);
                if (((c >= '0') && (c <= '9')) || (c == '.') ||
                    ((c >= 'a') && (c <= 'Z')) || ((c >= 'A') && (c <= 'Z')))
                {
                    pos += 1;
                    version = version + c;
                }
                else
                    break;
            }
        }
        return version;
    }

    return "";
}