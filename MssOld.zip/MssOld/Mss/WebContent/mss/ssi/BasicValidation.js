/*
   The isEmpty and isWhitespace functions were taken straight from Netscape's JavaScript
   development site, developer.netscape.com.  Major contribution by Bob N and Peter L
   $Id: BasicValidation.js,v 1.1 2014/06/26 07:56:10 praveen Exp $
*/

/****************************************************************/
// Check whether string s is empty.
function isEmpty(fldvalue)
{
    return ((fldvalue == null) || (fldvalue.length == 0))
}

/****************************************************************/
function isWhitespace (fldvalue)
{
	// Is fldvalue empty?
	if (isEmpty(fldvalue)) return true;

	// Search through string's characters one by one
	// until we find a non-whitespace character.
	// When we do, return false; if we don't, return true.
	var i = fldvalue.length;
	var sChar;

	while (--i >= 0)
	{
	    // Check that current character isn't whitespace.
	    sChar = fldvalue.charAt(i);
	    if (!(sChar == ' ' || sChar == '\t' || sChar == '\n' || sChar == '\r'))
	        return false;
	}
	// All characters are whitespace.
	return true;
}

/****************************************************************/
function isFldEmpty (fld,fldname)
{
	if (isWhitespace(fld.value))
	{
		alert(fldname + " cannot be blank.");
		fld.focus();
		fld.select();
		return true;
	}

	return false;
}
function isNumeric(str)
{
    var l;
    var c;

    l = str.length;
    while (--l >= 0)
    {
        c = str.charAt(l);
        if ((c < '0') || (c > '9'))
            return false;
    }
    return true;
}
function isNumericDecimal(str)
{
    var idx;
	var len;
    var c;
	var haveDecimal = false;
	var haveDigits = false;
		
	len = str.length;
	if (len > 0) {
		idx = 0;
		c = str.charAt(idx);
		if (c == '-')
			idx = idx + 1;
		while (idx < len)
    	{
        	c = str.charAt(idx);
        	if ((c < '0') || (c > '9')) {
            	if (c != '.')
            		return false;
            	if (haveDecimal)
            		return false;
            	haveDecimal = true;
        	} else {
        		haveDigits = true;
        	}
        	idx = idx + 1
    	}
    }
    return haveDigits;
}
function isFldNumeric(fld,fldName)
{
	var fldvar = fld.value;
	if (!isNumeric(fld.value)) {
		alert(fldName + " should be numeric.");
		fld.focus();
		fld.select();
		return false;
	}
	if(fldName === 'ABA Routing Nbr:'){
		if(fldvar.length != 0 && fldvar.length < 9){
			alert("Please enter a Valid 9 digit Number for " + fldName);
			fld.focus();
			fld.select();
			return false;
		}else{
			return true;
		}
	}
	return true;
}
function isFldNumericDecimal(fld,fldName)
{
	if (!isNumericDecimal(fld.value)) {
		alert(fldName + " is not numeric");
		fld.focus();
		fld.select();
		return false;
	}
	return true;
}
/****************************************************************/
function isAlphaNumeric(str)
{
    var l;
    var c;

    l = str.length;
    while (--l >= 0)
    {
        c = str.charAt(l);
        if (! (
                ((c >= 'a') && (c <= 'z')) ||
                ((c >= 'A') && (c <= 'Z')) ||
                ((c >= '0') && (c <= '9'))
               )
            )
            return false;
    }
    return true;
}

/****************************************************************/
function ForceAlphaNumeric(fld,fldname)
{
    if (!isAlphaNumeric(fld.value))
    {
        alert(fldname + " may contain only letters and numbers.");
        fld.focus();
        fld.select();
        return false;
    }
    return true;
}

/****************************************************************/
// Returns true if the string passed in is a valid number
//  (no alpha characters), else it displays an error message
function ForceNumber(fld, fldname)
{
	var fldvalue = new String(fld.value);

	if (isWhitespace(fldvalue)) return true;

	var i = 0;
	var iEOA=fldvalue.length;

	for (i = 0; i < iEOA; i++)
		if (fldvalue.charAt(i) < '0' || fldvalue.charAt(i) > '9')
		{
			alert(fldname + " must be a valid numeric entry.  Please do not use commas or dollar signs or any non-numeric symbols.");
			fld.focus();
			return false;
		}
	return true;
}

/****************************************************************/
function isPassword (fld,fldname)
{
	if (isWhitespace(fld.value))
	{
		alert(fldname + " cannot be blank.");
		fld.focus();
		fld.select();
		return false;
	}

    if (!chkPassword(fld.value))
    {
		alert(fldname + " must be between 8 and 28 characters.\nContain at least \n 1 upper case character\n 1 lower case character"+
		                "\n 1 numeric character\n 1 special character");
		fld.focus();
		fld.select();
		return false;
    }

    return true;
}

function chkPassword(pwd)
{
    var l;
    var i;
    var alphaCnt;
    var numCnt;
    var specCnt;
    var c;
    
    l = pwd.length;
    if (l < 8 || l > 28)
        return false;
    
    //alphaCnt = 0;
    upperCnt = 0;
    lowerCnt = 0;
    numCnt = 0;
    specCnt = 0;
    condCnt = 0;
    
    for (i = 0; i < l; i++)
    {
        c = pwd.charAt(i);
        if (isUpper(c)) {
            //alphaCnt++;
            if (upperCnt == 0)
            	condCnt++;
            upperCnt++;
        }
        else
        if (isLower(c)) {
            //alphaCnt++;
            if (lowerCnt == 0)
            	condCnt++;
            lowerCnt++;
        }
        else
        if (isDigit(c)) {
            if (numCnt == 0)
            	condCnt++;
            numCnt++;
        }
        else
        if (isSpecial(c)) {
            if (specCnt == 0)
            	condCnt++;
            specCnt++;
        }    
        else
            return false;
    }
    
    if (condCnt != 4)
    	return false;
    /*if (alphaCnt < 2)
        return false;
    if (numCnt < 2)
        return false;
    if (specCnt < 0)
        return false; */
        
    return true;
    
}

function noValueSelected(lst)
{
    if (lst.selectedIndex >= 0)
        if (!isEmpty(lst.options[lst.selectedIndex].value))
            return false;
    return true;
}

function isSelectionEmpty(sel,selname)
{
    if (noValueSelected(sel))
    {
        alert(selname + " cannot be blank.");
        sel.focus();
        return true;
    }
    return false;
}
function getSelectedValue(lst)
{
    if (lst.selectedIndex >= 0)
        return lst.options[lst.selectedIndex].value;

    return null;
}
function doSelect(ctl,Val)
{
    if (navigator.appName == "IE")
        ctl.value = Val
    else
        for (var i = 0; i < ctl.length; i++)
        {
            if (ctl.options[i].value == Val)
            {
				ctl.selectedIndex = i;
                return;
            }
        }
}
function getDescFor(ctl,Val)
{
	for (var i = 0; i < ctl.length; i++)
    {
    	if (ctl.options[i].value == Val)
        {
        	return ctl.options[i].text;
        }
    }
    return null;
}
function isDigit(c)
{
    return ((c >= '0') && (c <= '9'));
}

function isDateDelim(c)
{
    return ( (c == '/') || (c == '-') || (c == '.') );
}

function isWhite(c)
{
    return ( (c == ' ') || (c == '\t') );
}

function isUpper(c)
{
    if ((c >= 'A') && (c <= 'Z'))
        return true;
    return false;
}

function isLower(c)
{
    if ((c >= 'a') && (c <= 'z'))
        return true;
    return false;
}

function isSpecial(c)
{
    var spec = "!@#$%^&*()_+-=~[]{}|:;?<>,./";
    var l;
    var i;
    var c;
    
    l = spec.length;

    for (i = 0; i < l; i++)
        if (c == spec.charAt(i))
            return true;
    return false;
}

function Ltrim(s)
{
    var l;
    var i;

    l = s.length;
    i = 0;

    while (i < l)
    {
        if (!isWhite(s.charAt(i)))
            break;
        i++;
    }

    if (i >= l)
        return "";

    return s.substring(i,l);
}

function Rtrim(s)
{
    var l;
    var i;

    l = s.length;

    while (--l >= 0)
    {
        if (!isWhite(s.charAt(l)))
            break;
    }

    if (l < 0)
        return "";

    return s.substring(0,l+1);
}

function trim(s)
{
	return Ltrim(Rtrim(s));
}
function waitCurs()
{
    var elems;

    if (navigator.userAgent.indexOf("MSIE 6.") >= 0)
    {
        elems = document.getElementsByTagName("*");
        for (var i = 0; i < elems.length; i++)
        {
            if (elems[i].type == "button" || elems[i].type == "submit")
            {
                elems[i].style.cursor = "wait";
            }
        }
        document.body.style.cursor = "wait";
    }
}
function isRdoChecked(fld)
{
    if (fld[0])
    {
       for(var i = 0; i < fld.length; i++)
       {
         if (fld[i].checked)
         {
            return true;
         }
      }
    }
    else
    {
      if (fld.checked)
        { return true; }
    }    
    return false;
}
function getRdoValue(fld)
{
    if (fld[0])
    {
       for(var i = 0; i < fld.length; i++)
       {
         if (fld[i].checked)
         {
            return fld[i].value;
         }
      }
    }
    else
    {
      if (fld.checked)
      { 
        return fld.value; 
      }
    }    
    return "";
}
function getChkValue(fld)
{
    if (fld.checked)
    { 
        return fld.value; 
    }    
    return "";
}
function checkAll(field)
{
	for (i = 0; i < field.length; i++)
		field[i].checked = true ;
}

function uncheckAll(field)
{
	for (i = 0; i < field.length; i++)
		field[i].checked = false ;
}
function makeUpperCase(ctl)
{
	ctl.value = ctl.value.toUpperCase();
}

/* Handling XSS */
function decodeHex(str) {
	var mat = str.match(/&#x([0-9a-fA-F]{2})/gi);
	if (mat != null) {
		for (i=0; i< mat.length; i++) {
			var ch = String.fromCharCode(parseInt(mat[i].replace("&#x",""), 16));
			str = str.replace(mat[i] + ";", ch);
		}
	}
	return str;
}
function setIdValue(id, value) {
	var ele = document.getElementById(id);
	if (ele == null)
		ele = document.getElementsByName(id)[0];
	if (ele != null) {
		if (value == null)
			value = "";
		if (ele.nodeName == 'INPUT' || ele.nodeName == 'input')
			dwr.util.setValue(id, decodeHex(value));
		else 
			dwr.util.setValue(id, value, {escapeHtml:false});
	}
}
function replaceOptions(data, elementName) {
	var selbox = document.getElementsByName(elementName)[0];
	selbox.options.length = 1;
	selbox.options[0] = new Option("", "");
	if (data != null) {
		selbox.options.length = data.length + 1;
		for (i = 0; i < data.length; i++) {
			selbox.options[i+1] = new Option(data[i].value, data[i].name);
		}
  	}
	
}
  //IFOX-00415856 - New Agent Look Up CR :START
function setSelectedOption(data, elementName) {
	var selbox = document.getElementsByName(elementName)[0];
	//IFOX-00420752 : Agent Issue :start
	selbox.options.length = 0;
	//IFOX-00420752 : Agent Issue :end
	//selbox.options[0] = new Option("", "");
	if (data != null) {
		selbox.options.length = data.length + 1;
		for (i = 0; i < data.length; i++) {
			selbox.options[i] = new Option(data[i].value, data[i].name);
			selbox.options[i].selected = true;
            $(selbox).change();
		}
  	}
	
}
//IFOX-00420752 : Agent Issue :start
function removeOptions(selectbox)
{
    var i;
    for(i = selectbox.options.length - 1 ; i >= 0 ; i--)
    {
        selectbox.remove(i);
    }
}
//IFOX-00420752 : Agent Issue :end
//IFOX-00415856 - New Agent Look Up CR :END
function updateOptions(templateName, elementName, dataValue, addBlank, addMissing) {

	var selbox = document.getElementsByName(elementName)[0];
	var tmplt = document.getElementsByName(templateName)[0];
	var idx = 0;
	var len;
	
	selbox.options.length = idx;
    if (addMissing) {
		if (!selBoxHasValue(tmplt,dataValue)) {
        	if ((dataValue == null) || (trim(dataValue) == '')) {
           		addBlank = true;
           	} else {
           		idx = idx + 1;
				selbox.options.length = idx;
				selbox.options[idx-1] = new Option(dataValue, dataValue);
           	}
        }
    }
	if (addBlank) {
   		idx = idx + 1;
		selbox.options.length = idx;
		selbox.options[idx-1] = new Option("", "");
	}

	len = tmplt.options.length;	
	for (var i = 0; i < len; i++) {
		idx = idx + 1;
		selbox.options.length = idx;
		selbox.options[idx-1] = new Option(tmplt.options[i].text,tmplt.options[i].value);
  	}
}
function CheckSelectBoxValue(selbox,tmplt,fldName) {

	var	val = getSelectedValue(selbox);
	if (!selBoxHasValue(tmplt,val)) {
		alert("Invalid " + fldName);
		selbox.focus();
		return false;
	}
	return true;
}
function selBoxHasValue(selbox,dataValue) {

	var len = selbox.options.length;
	for (var i = 0; i < len; i++) {
		if (selbox.options[i].value == dataValue)
			return true;
	}
	return false;
}