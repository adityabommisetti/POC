// ProgressBar.js
/**
	Javascripts for creating the progressbar.
	@@author : Pradeep Palat
	Created  : 12/18/06
*/

	var XMLHttpObject;
	var progress = 0;
	var intervalObj;
	
	function hasProgressBar(){
		return (document.getElementById("progressBarBox") != null)
	}	
	
	function setProgress ( completed){
		document.getElementById("progressInnerBox").style.width=completed + "%";
		document.getElementById("progressBarText").innerText=completed + "% Completed.";
	}
	
	function trackProgress(){
		requestProgressValue();	
	}
	
	function requestProgressValue(){
	
		if ( window.XMLHttpRequest){
			XMLHttpObject = new XMLHttpRequest();
		}else{
			XMLHttpObject = new ActiveXObject("Microsoft.XMLHTTP");
		}

		var URL = "/servlet/FileUploadStatusServlet";
				
		XMLHttpObject.onreadystatechange=parseProgressResponse;
		XMLHttpObject.open("POST", URL, true);
		XMLHttpObject.send();
	
	}
	
	function parseProgressResponse(){
		
		if ( XMLHttpObject.readyState == 4){		
			if(XMLHttpObject.status == 200){
				responseText = XMLHttpObject.responseText;
				// If any of the 'lazy' Async calls return back late, 
				// or if the response is not a number then ignore them								
				if ( typeof eval(responseText) != "undefined" ){
					var progressChk = eval(responseText);
					
					if ( progressChk > progress){						
						progress = progressChk;
						setProgress(progress);
					}
					
				}
				
				if(progress >= 100){
					window.clearInterval(intervalObj);
				}
				
			}else{
				// check for consecutive failures and let user know.
			}			
		}
		
	}
	
	function initTrackProgress(){		
		document.getElementById("progressInnerBox").style.display="block";
		intervalObj = window.setInterval("trackProgress()",2500);
	}

