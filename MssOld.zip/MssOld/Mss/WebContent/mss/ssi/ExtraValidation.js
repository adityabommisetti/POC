
/****************************************************************/
	/* PURPOSE:  Returns true if the string is a valid date number.
	A method is passed in (1 = month, 2 = day).  If the string is
	nonnumeric, false is passed back.  If the day in the date string
	is greater than 31, false is returned.  If the month is greater
	than 12, an error is returned.
	*/
function isDateNumber(fldvalue,method)
{
	var sfldvalue = new String(fldvalue);
	var i = 0;
	var ilownum=0;
	if (method==1 || method==2)  ilownum=1;
	if (isNaN(parseInt(sfldvalue)) || parseInt(sfldvalue) < ilownum) return false;
	if (method == 2) //Day
		if (parseInt(sfldvalue) > 31)
			return false;
	if (method == 1) //Month
		if (parseInt(sfldvalue) > 12)
			return false;
	for (i = 0; i < sfldvalue.length; i++)
		if (sfldvalue.charAt(i) < '0' || sfldvalue.charAt(i) > '9')
			return false;
	return true;
}
/****************************************************************/
	/* PURPOSE:  Returns error string if the string is not a valid date number.

	A method is passed in (1 = month, 2 = day).  If the string is
	nonnumeric, false is passed back.  If the day in the date string
	is greater than 31, false is returned.  If the month is greater
	than 12, an error is returned.
	*/
function DatePartErrMsg(fldvalue,method)
{
	var sfldvalue = new String(fldvalue);
	var i = 0;
	var sMsg="";

	if (method==1) //Month
	{
		if (isNaN(parseInt(sfldvalue)))
			sMsg += "The Month '" + sfldvalue + "' is not a number.\n";
		else
			if (parseInt(sfldvalue) < 1)
					sMsg += "The Month '" + sfldvalue + "' cannot be less than 1.\n";
			else
				if (parseInt(sfldvalue) > 12)
					sMsg += "The Month '" + sfldvalue + "' cannot be greater than 12.\n";
	}
	else
		if (method==2) //Day
		{
			if (isNaN(parseInt(sfldvalue)))
				sMsg += "The Day '" + sfldvalue + "' is not a number.\n";
			else
				if (parseInt(sfldvalue) < 1)
						sMsg += "The Day '" + sfldvalue + "' cannot be less than 1.\n";
				else
					if (parseInt(sfldvalue) > 31)
						sMsg += "The Day '" + sfldvalue + "' cannot be greater than 31.\n";
		}
		else 				// Year
		{
			if (isNaN(parseInt(sfldvalue)))
				sMsg += "The Year '" + sfldvalue + "' is not a number.\n";
		}
		if (sMsg.length==0)
				for (i = 0; i < sfldvalue.length; i++)
					if (sfldvalue.charAt(i) < '0' || sfldvalue.charAt(i) > '9')
						sMsg += "The character '" + sfldvalue.charAt(i) + "' is not a digit.\n";

	return sMsg;
}
/****************************************************************/
/* Displays an alert box with the passed in string...	*/
function PromptErrorMsg(fld,strError)
{
	alert("You have entered an invalid date for " + strError + ".  Please make sure your date format is in M/D/Y format.");
	fld.focus();
	fld.select();
}
/****************************************************************/
	/* PURPOSE: Checks to see if the string is a valid date.  A valid
		date is defined as any of the following:
			MM/DD/YY, MM/DD/YYYY, M/D/YY, M/D/YYYY,
			MM-DD-YY, MM-DD-YYYY, M-D-YY, M-D-YYYY
	*/
function ForceDate(fld,fldname)
{
	var fldvalue = new String(fld.value);

	if (isWhitespace(fldvalue))
	{
		return true;
		// if the field is empty, just return true...
	}

	var i = 0, count = fldvalue.length, j = 0;
	//Count the amount of chars until the first date part delim
	while ((fldvalue.charAt(i) != "/" && fldvalue.charAt(i) != "-" && fldvalue.charAt(i) != ".") && i < count)
		i++;

	if (i == count || i > 2)
	{
		PromptErrorMsg(fld,fldname);
		return false;
	}

	var addOne = false;
	if (i == 2) addOne = true;
	//Is the month part valid?

	if (!isDateNumber(fldvalue.substring(0,i),1))
	{
		PromptErrorMsg(fld,fldname);
		return false;
	}
	//The month seems to be valid
	var sTmpDate=new String(fldvalue.substring(0,i));

	if (sTmpDate.length==1)
		sTmpDate="0" + sTmpDate;
	var sNewDate = new String(sTmpDate + "/");

	j = i+1;	//Start after the first date delim
	i = 0;
	while ((fldvalue.charAt(i+j) != "/" && fldvalue.charAt(j+i) != "-" && fldvalue.charAt(i) != ".") && i+j < count)
		i++;
	if (i+j == count || i > 2) {
		PromptErrorMsg(fld,fldname);
		return false;
	}
	if (!isDateNumber(fldvalue.substring(j,i+j),2))
	{
		PromptErrorMsg(fld,fldname);
		return false;
	}
	sTmpDate=fldvalue.substring(j,i+j);

	if (sTmpDate.length==1)
		sTmpDate="0" + sTmpDate;
	sNewDate=sNewDate+sTmpDate+"/";

	j = i+3;
	i = 0;
	if (addOne) j++;
	while (i+j < count)
		i++;
	if (i != 2 && i != 4) {
		PromptErrorMsg(fld,fldname);
		return false;
	}
	if (!isDateNumber(fldvalue.substring(j,i+j),3))
	{
		PromptErrorMsg(fld,fldname);
		return false;
	}
	sTmpDate=fldvalue.substring(j,i+j);
	if (sTmpDate.length==1)
	{
		sTmpDate="0" + sTmpDate;
	} else if (sTmpDate.length==2)
			sTmpDate="20" + sTmpDate;
	sNewDate=sNewDate+sTmpDate;
	RegProfile.SvcRequired_date.value=sNewDate;
	return true;
}
/****************************************************************/
	/* PURPOSE: Checks to see if the string is a valid date.  A valid
		date is defined as any of the following:
			MM/DD/YY, MM/DD/YYYY, M/D/YY, M/D/YYYY,
			MM-DD-YY, MM-DD-YYYY, M-D-YY, M-D-YYYY
			If it is valid, sets the date formated as "mm/dd/yyyy". returns "none"
			If empty Returns "empty".
			If invalid returns "The ...
	*/
function DateErrMsg(fld,fldname)
{
	var fldvalue = new String(fld.value);
	var sMsg="";
	if (isWhitespace(fldvalue))
		return "empty";		// if the field is empty, just return empty...

	var i = 0, count = fldvalue.length, j = 0;
	//Count the amount of chars until the first date part delim
	while ((fldvalue.charAt(i) != "/" && fldvalue.charAt(i) != "-" && fldvalue.charAt(i) != ".") && i < count)
		i++;

	if (i == count || i > 2)
		return "The Month part of " + fldname + " is not delimited properly.";

	var addOne = false;
	if (i == 2) addOne = true;
	//Is the month part valid?
	sMsg += DatePartErrMsg(fldvalue.substring(0,i),1);
	if (sMsg.length !=0) return sMsg;

	//The month seems to be valid
	var sTmpDate=new String(fldvalue.substring(0,i));

	if (sTmpDate.length==1)
		sTmpDate="0" + sTmpDate;
	var sNewDate = new String(sTmpDate + "/");

	j = i+1;	//Start after the first date delim
	i = 0;
	while ((fldvalue.charAt(i+j) != "/" && fldvalue.charAt(j+i) != "-" && fldvalue.charAt(i) != ".") && i+j < count)
		i++;
	if (i+j == count || i > 2)
		return "When checking the day part of " + fldname + ", could not find a correct delimiter properly.";

	sMsg = DatePartErrMsg(fldvalue.substring(j,i+j),2);
	if (sMsg.length !=0 ) return sMsg;

	sTmpDate=fldvalue.substring(j,i+j);

	if (sTmpDate.length==1)
		sTmpDate="0" + sTmpDate;
	sNewDate=sNewDate+sTmpDate+"/";

	j = i+3;
	i = 0;
	if (addOne) j++;
	while (i+j < count)
		i++;
	if (i != 2 && i != 4)
		return "The year part of " + fldname + ", is " + i + " characters.  \nIt must be either 2 or 4 characters.";

	sMsg = DatePartErrMsg(fldvalue.substring(j,i+j),3);
	if (sMsg.length !=0) return sMsg;

	sTmpDate=fldvalue.substring(j,i+j);
	if (sTmpDate.length==1)
	{
		sTmpDate="0" + sTmpDate;
	} else if (sTmpDate.length==2)
			sTmpDate="20" + sTmpDate;
	sNewDate=sNewDate+sTmpDate;

	fld.value = sNewDate;
	return "none";
}
/****************************************************************/
	/* Checks a given date: returns errors and focuses on the field allows for empty dates
	*/
function ShowDateErrMsg(fld,fldname)
{
	var sMsg = DateErrMsg(fld,fldname);
	if (sMsg=="none") 	return false;
	if (sMsg=="empty")
		return false;
	else
	{
		alert (sMsg);
		fld.focus();
		fld.select();
		return true;
	}
}

/****************************************************************/
// Email address must be of form a@b.c ... in other words:
// * there must be at least one character before the @
// * there must be at least one character before and after the .
// * the characters @ and . are both required
//
function isEmail (fldvalue)
{
		//if (isEmpty(fldvalue))
    //   if (isEmail.arguments.length == 1) return defaultEmptyOK;
    //   else return (isEmail.arguments[1] == true);

    // is s whitespace?
    if (isWhitespace(fldvalue)) return true;

    // there must be >= 1 character before @, so we
    // start looking at character position 1
    // (i.e. second character)
    var i = 1;
    var ilen = fldvalue.length;

    // look for @
    while ((i < ilen) && (fldvalue.charAt(i) != "@"))
    { i++
    }

    if ((i >= ilen) || (fldvalue.charAt(i) != "@")) return false;
    else i += 2;

    // look for .
    while ((i < ilen) && (fldvalue.charAt(i) != "."))
    { i++
    }

    // there must be at least one character after the .
    if ((i >= ilen - 1) || (fldvalue.charAt(i) != ".")) return false;
    else return true;
}
/****************************************************************/
function ShowEmailErrMsg(fld)
{
	if (!isEmail(fld.value))
	{
		alert("Please check the email address you entered.");
		fld.focus();
		fld.select();
		return false;
	}
	else
		return true;
}

/*	Will check to make sure the field is a validPhone Number or empty
*/
function isPhoneNumber(fld)
{
    var whitespace = " \t\n\r";
	var bgoodphone = true;
	var fldvalue=new String(fld.value);
	var sdigits="0123456789";
	var svalidvalues=whitespace+sdigits+"()-ext.EXT";
	var ilen=fldvalue.length;
	var sreason="";
	var schar="";
	var idigits=0;
	if (isWhitespace(fldvalue))
		bgoodphone=true;	//Here it ignores all whitespaces
	else
	{
		for (var i = 0; i < ilen; i++)
		{
			//Valid values numbers, -,()
			schar=	fldvalue.charAt(i);
			if (sdigits.indexOf(schar) != -1)
				idigits++;
			if (svalidvalues.indexOf(schar) == -1)
			{
				//alert("invalid"+schar);
				sreason+="\n'"+schar+"' is not a valid part of a phone number.";
				bgoodphone=false;
			} //end if svalidvalues

		}//end for
		if (idigits<7)
		{
				sreason+="\nPhone Numbers must be at least seven digits.";
				bgoodphone=false;
		} else
		{
			if(idigits==10 && ilen==10)
			{
				fldvalue="("+fldvalue.substring(0,3)+") "+
										fldvalue.substring(3,6)+"-"+
										fldvalue.substring(6,10);
				fld.value=fldvalue;

			}
		}

	}
	if (!bgoodphone)
	{
			alert("This is not a valid telephone number."+sreason);
			fld.focus();
			fld.select();
			return false;
	} else return true;
}
