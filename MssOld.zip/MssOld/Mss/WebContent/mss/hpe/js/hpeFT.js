
function switchMenu(val) {
	document.body.className = 'wait';
	document.forms[0].menu.value = val;
	
	if (val == "ChartDashboard" || val == "ChartSummary") {
		document.forms[0].method.value = 'switchMenuToCR';
		// var url = "/chartAction.do";
		 //document.forms[0].action = url;
	}
	if (val == "exportFilenames") {

		var url = "/exportFilenamesAction.do";
		document.forms[0].method.value = 'switchMenu';
		document.forms[0].action = url;
	}

	if (val != "fileTracking" && val != "ChartDashboard" && val != "ChartSummary" && val != "exportFilenames") {
		// fileTrackAction
		var url = "/hpeAction.do";
		document.forms[0].method.value = 'switchMenu';
		document.forms[0].action = url;
	}
	document.forms[0].submit();
}



function getMonthlyEncDetails(year, mon, encStatus,intRecId,custSourceId,value)
{
if(value != 0){
	document.body.className = 'wait';
	//alert("Hi ---->"+year+"--"+mon+"--"+encStatus+"--"+intRecId);
	//alert("fdmMo --->"+year+mon+encStatus);
	var e = document.getElementById("fdmMo"+year+mon+encStatus);
	e.className = 'selectedRow';
	var month = new Date(Date.parse(mon +" 1, 2012")).getMonth();
	var str = "0";
	
	if(month <= 9){
	month=str.concat(month);
	}
	var yrMonth = year.concat(month);
	document.hpeftSearchForm.status.value = encStatus;
	document.hpeftSearchForm.intrchg_recvr_id.value = intRecId;
	document.hpeftSearchForm.dateYRMO.value = yrMonth;	
	document.hpeftSearchForm.fileDsbMgmtHL.value = "fdmMo"+year+mon+encStatus;
	document.hpeftSearchForm.methodName.value = 'hpeftMonEncDetails';
	document.hpeftSearchForm.menu.value = 'fileTracking';
	document.hpeftSearchForm.method.value = 'fileTreeSearch';
	document.hpeftSearchForm.submit();
	} else {
	alert("No Records Found");
	}
	
}

function getFailedDailyFileProcessing(year, mon, encStatus,intRecId,custSourceId,value)
{
	
	if(value != 0){
	document.body.className = 'wait';
	var e = document.getElementById("fdmMo"+year+mon+encStatus);
	e.className = 'selectedRow';
	var month = new Date(Date.parse(mon +" 1, 2012")).getMonth();
	var str = "0";
	
	if(month <= 9){
	month=str.concat(month);
	}
	var yrMonth = year.concat(month);
	document.hpeftSearchForm.status.value = encStatus;	
	document.hpeftSearchForm.dateYRMO.value = yrMonth;
	document.hpeftSearchForm.fileDsbMgmtHL.value = "fdmMo"+year+mon+encStatus;
	document.hpeftSearchForm.methodName.value = 'failedFileLst';
	document.hpeftSearchForm.menu.value = 'fileTracking';
	document.hpeftSearchForm.method.value = 'fileTreeSearch';
	
	document.hpeftSearchForm.submit();
	
	}else {
	alert("No Records Found");
	}
}

function getDailyFileProcessing(enctype, sourceId, dateYrMo,intRecId,submitDate,rowId)
{
	document.body.className = 'wait';
	var e = document.getElementById(rowId);	
	e.className = 'selectedRow';
	document.hpeftSearchForm.encType.value = enctype;	
	document.hpeftSearchForm.intrchg_recvr_id.value = intRecId;
	document.hpeftSearchForm.dateYRMO.value = dateYrMo;
	document.hpeftSearchForm.submissionDate.value = submitDate;
	document.hpeftSearchForm.moEncDetHL.value = rowId;
	//document.hpeftSearchForm.orig_intrchg_ctrl_nbr.value = origIntNbr;
	document.hpeftSearchForm.methodName.value = 'hpeftDailyFileProcessing';
	
	document.hpeftSearchForm.menu.value = 'fileTracking';
	document.hpeftSearchForm.method.value = 'fileTreeSearch';
	
	document.hpeftSearchForm.submit();

}
function getWiproICNProcessing(origIntNbr,custFileId,status,encType,rowId)
{
	if(origIntNbr!=null && origIntNbr!= ''){	
	  
	   var txt = status+origIntNbr+encType;	 
	 
	  
	    if(status!=null && status!=''){
	    	status='';
	    }else{
	    	status='';
	    }
	   document.hpeftSearchForm.orig_intrchg_ctrl_nbr.value = origIntNbr;
	   document.hpeftSearchForm.custFileId.value = custFileId; //IFOX-00416789 - Add customer ICN in File management
   	   document.hpeftSearchForm.status.value = status;
   	   document.hpeftSearchForm.encType.value = encType;	
       document.hpeftSearchForm.dailyDetHL.value = rowId;
   	   document.hpeftSearchForm.method.value = 'fileTrackMoveEN';
   	
        	 
	    var r = confirm("You will be navigated to Encounter page");	        	
	    if (r == true) {	       
	    	var e = document.getElementById(rowId);	   
 	 	    e.className = 'selectedRow';
	        document.body.className = 'wait';
	    	document.hpeftSearchForm.submit();
	    } else {
	    	
	    	if(rowId.substring(0,3)=='ACC'){
	    		toggleHighlightingRemoval(); 
	    		var e = document.getElementById(rowId);	   
	 	 	    e.className = 'selectedRow';
	 	 	    var f = document.getElementById('REJ'+rowId.substring(3,rowId.Length));
	 	 	  f.className ='';
	    	}
	    	
	    	if(rowId.substring(0,3)=='REJ'){
	    		toggleHighlightingRemoval(); 
	    		var e = document.getElementById(rowId);	   
	 	 	    e.className = 'selectedRow';
	 	 	    var ft = document.getElementById('ACC'+rowId.substring(3,rowId.Length));
	 	 	  ft.className ='';
	    	}
	      
	    }
	
	}	

}

//File Tracking traverse to chart management
function getWiproICNProcessingCR(origIntNbr,custFileId,status,encType,rowId)
{
	if(origIntNbr!=null && origIntNbr!= ''){	
	  
	   var txt = status+origIntNbr+encType;	 
	 
	  
	    if(status!=null && status!=''){
	    	status='';
	    }else{
	    	status='';
	    }
	   document.hpeftSearchForm.orig_intrchg_ctrl_nbr.value = origIntNbr;
	   document.hpeftSearchForm.custFileId.value = custFileId; //IFOX-00416789 - Add customer ICN in File management
   	   document.hpeftSearchForm.status.value = status;
   	   document.hpeftSearchForm.encType.value = encType;
   	   document.hpeftSearchForm.dailyDetHL.value = rowId;
   	   document.hpeftSearchForm.method.value = 'fileTrackMoveCR';
   	   
   	
        	 
	    var r = confirm("You will be navigated to Chart Management page");	        	
	    if (r == true) {
	    	var e = document.getElementById(rowId);	   
 	 	    e.className = 'selectedRow';
	        document.body.className = 'wait';
	    	document.hpeftSearchForm.submit();
	    } else { 
	    	
	    	if(rowId.substring(0,3)=='ACC'){	    		
	    		toggleHighlightingRemoval(); 
	    		var e = document.getElementById(rowId);	   
	 	 	    e.className = 'selectedRow';
	 	 	    var f = document.getElementById('REJ'+rowId.substring(3,rowId.Length));
	 	 	  f.className ='';
	    	}
	    	
	    	if(rowId.substring(0,3)=='REJ'){
	    		toggleHighlightingRemoval(); 
	    		var e = document.getElementById(rowId);	   
	 	 	    e.className = 'selectedRow';
	 	 	    var ft = document.getElementById('ACC'+rowId.substring(3,rowId.Length));
	 	 	  ft.className ='';
	    	}
	      
	    }
	
	}	

}
function toggleHighlightingRemoval(){
	
	var tableAcc = document.getElementById('dfProcessingTblAcc');  
	var table = document.getElementById('dfProcessingTblRej');
    var rows = table.getElementsByTagName("tr");
    var rowsAcc = tableAcc.getElementsByTagName("tr");

    for(var i = 0; i < rowsAcc.length; i++){ 
    	if(rowsAcc[i].className=="selectedRow"){
    		rowsAcc[i].className = ""; 
    	       }
    	    } 
    for(var i = 0; i < rows.length; i++){  
    	if(rows[i].className=="selectedRow"){
  		  rows[i].className = ""; 
  	           }
    	    }
  }
function getFileDashMngtHL(val){
	
	var e = document.getElementById(val);
	e.className = 'selectedRow';
}
function getMonEncDetHL(val){
	
	var e = document.getElementById(val);
	e.className = 'selectedRow';
}
function getDailyDetHL(val){
	var e = document.getElementById(val);
	e.className = 'selectedRow';
}


function getSelectedRowHLBody(){
	
	var fileDash = document.hpeftSearchForm.fileDsbMgmtHL.value;
	var monthly = document.hpeftSearchForm.moEncDetHL.value;
	var daily = document.hpeftSearchForm.dailyDetHL.value;
	
	if(fileDash != ''){
		getFileDashMngtHL(document.hpeftSearchForm.fileDsbMgmtHL.value);
	}
	
	if(monthly != ''){
		getMonEncDetHL(document.hpeftSearchForm.moEncDetHL.value);
	}
	
	if(daily != ''){
		getDailyDetHL(document.hpeftSearchForm.dailyDetHL.value);
	}
	
}

	
function pushComments() {
		
		var wipFileId = document.getElementById("fileId");
		var remarks = document.getElementById("customerRemarks");

		var wipFileIdtVal = lpad(wipFileId.value,9, '0'); //IFOX-00417418 - Issues with all Updatable fields (IFOX-00416992)
		var remarksVal = remarks.value;
		
		var entt = document.getElementById("searchSubmitterId");
		var selSubmitterId = entt.options[entt.selectedIndex].value;
		
		if(wipFileIdtVal != null && wipFileIdtVal != '' && wipFileIdtVal!='undefined' && isNaN(wipFileIdtVal)){
			alert("Please Enter valid File ID");
			document.body.className = '';
			return false;
		}
		if (wipFileIdtVal.length > 10){
			alert("Please Enter valid File ID");
			document.body.className = '';
			return false;
		}
		
		document.getElementById("retreiveBtn").disabled = true;
		document.getElementById("updateBtn").disabled = true;
		
		 var loadingImg = document.getElementById("loadingImage");
      
		if (wipFileIdtVal != null && wipFileIdtVal != '' && remarksVal != null
				&& remarksVal != '' && wipFileIdtVal!='undefined' && remarksVal!='undefined' && selSubmitterId!='undefined') {

			 loadingImg.style.display='';
			
			  var url = "/fileTrackAction.do";
			  var params = "orig_intrchg_ctrl_nbr="+wipFileIdtVal+"&cust_comments="+remarksVal+"&menu=remarkUpdate"+"&selSubId="+selSubmitterId;
			   
			    // Perform the AJAX request using a non-IE browser.
			    if (window.XMLHttpRequest) {
			    var request = new XMLHttpRequest();
			   
			      // Register callback function that will be called when
			      // the response is generated from the server.
			      request.onreadystatechange = function() {
			    	  		    		  
			    	 
			    	    if ( request.readyState == 4 && request.status==200 ) {
			    	    	 alert("Update Successfully");			    	    	
			    	    	
			    	    	/* var nFilter = document.getElementById('commentSection');			    	    	
			    	    	 nFilter.style.display='none';*/
			    	    	 document.getElementById('commentUpdate').innerHTML += '<br><strong>Updated the Customer Remarks for the file Id:'+wipFileIdtVal+'</strong>';
			    	    	 document.getElementById("retreiveBtn").disabled = false;
			    				document.getElementById("updateBtn").disabled = false;
			    				 loadingImg.style.display='none';
			    	      }
			    	   
			    	
			    	    };
			   
			      try {
			      request.open("POST", url+"?"+params, true);
			      } catch (e) {
			         alert("Unable to connect to server to retrieve count.");
			      }
			   
			      request.send(null);
			    // Perform the AJAX request using an IE browser.
			    } else if (window.ActiveXObject) {
			      request = new ActiveXObject("Microsoft.XMLHTTP");
			   
			      if (request) {
			        // Register callback function that will be called when
			        // the response is generated from the server.
			        
			        request.open("POST", url, true);
			        request.send();
			      }
			    } 
		

		} else {
			alert('Please Enter Valid File Id and Notes');
			document.getElementById("retreiveBtn").disabled = false;
			document.getElementById("updateBtn").disabled = false;
			 loadingImg.style.display='none';
			 document.body.className = '';
		}

	}



function pullComments() {
	
	document.body.className = 'wait';
	var wipFileId = document.getElementById("fileId");
	var wipFileIdtVal = lpad(wipFileId.value,9, '0'); //IFOX-00417418 - Issues with all Updatable fields (IFOX-00416992)
	var ent = document.getElementById("searchSubmitterId");
	var selSubmitterId = ent.options[ent.selectedIndex].value;
	
	if(wipFileIdtVal != null && wipFileIdtVal != '' && wipFileIdtVal!='undefined' && isNaN(wipFileIdtVal)){
		alert("Please Enter valid File ID");
		document.body.className = '';
		return false;
	}
	if (wipFileIdtVal.length > 10){
		alert("Please Enter valid File ID");
		document.body.className = '';
		return false;
	}
	
	document.getElementById("retreiveBtn").disabled = true;
	document.getElementById("updateBtn").disabled = true;
	document.getElementById('customerRemarks').value="";
	 var loadingImg = document.getElementById("loadingImage");
	
	if (wipFileIdtVal != null && wipFileIdtVal != '' && wipFileIdtVal!='undefined') {
		 loadingImg.style.display='';
		
		  var url = "/fileTrackAction.do";
		  var params = "orig_intrchg_ctrl_nbr="+wipFileIdtVal+"&menu=remarkRetrieve"+"&selSubId="+selSubmitterId;
		   
		    // Perform the AJAX request using a non-IE browser.
		    if (window.XMLHttpRequest) {
		      var req = new XMLHttpRequest();
		      req.open("GET", url+"?"+params+"?nocache="+Math.random(), true);
		      
		      // Register callback function that will be called when
		      // the response is generated from the server.
		      req.onreadystatechange = function() {		    	
		    	    if (req.readyState == 4 && req.status==200) {
		    	    	 document.getElementById('commentUpdate').innerHTML = '<br><strong>Retrieved the Customer Remarks for the file Id:'+wipFileIdtVal+'</strong>';
		    	    	 document.getElementById('customerRemarks').value = req.responseText;
		    	    	
		    	    	 document.getElementById("retreiveBtn").disabled = false;
		    			 document.getElementById("updateBtn").disabled = false;
		    			 loadingImg.style.display='none';
		    			 document.body.className = '';
		    	      }
		    	    };
		    	    req.send();
		       // Perform the AJAX request using an IE browser.
		    } else if (window.ActiveXObject) {
		    	req = new ActiveXObject("Microsoft.XMLHTTP");
		   
		      if (req) {
		        // Register callback function that will be called when
		        // the response is generated from the server.		        
		    	  req.open("GET", url, true);
		    	  req.send();
		      }
		    } 
	
		   
	} else {
		alert('Please Enter Valid File Id');
		document.getElementById("retreiveBtn").disabled = false;
		document.getElementById("updateBtn").disabled = false;
		loadingImg.style.display='none';
		document.body.className = '';
	}
}

function stateChanged()
{
   
}
//IFOX-00417418 - Issues with all Updatable fields (IFOX-00416992)
function lpad(value, len, c){
	var fileId="";
	if(value!=null){
		len -= value.length;
	}
	for(var i = 0; i<len; i++){
		fileId = fileId+c;
	}
	if(value!=null){
		fileId = fileId+value;
	}
	return fileId;
}