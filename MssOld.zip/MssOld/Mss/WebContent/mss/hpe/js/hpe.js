function switchMenu(val) {
	document.body.className = 'wait';
	document.forms[0].menu.value = val;
	if (val == "fileTracking") {

		var url = "/fileTrackAction.do";
		document.forms[0].method.value = 'switchMenu';
		document.forms[0].action = url;
	}
	if (val == "ChartDashboard" || val == "ChartSummary") {
		document.forms[0].method.value = 'switchMenuToCR';
		// var url = "/chartAction.do";
		// document.forms[0].action = url;
	}
	if (val == "exportFilenames") {

		var url = "/exportFilenamesAction.do";
		document.forms[0].method.value = 'switchMenu';
		document.forms[0].action = url;
	}

	if (val != "fileTracking" && val != "ChartDashboard" && val != "ChartSummary" && val != "exportFilenames") {
		// fileTrackAction
		var url = "/hpeAction.do";
		document.forms[0].method.value = 'switchMenu';
		document.forms[0].action = url;
	}
	document.forms[0].submit();
}
/*
 * else { var url = "/hpeAction.do"; document.forms[0].method.value =
 * 'switchMenu'; document.forms[0].action = url; }
 * 
 * document.forms[0].submit(); }
 */

function logHistory(clmRefNo) {
	document.forms[0].method.value = 'logHistory';
	document.forms[0].submit();
}

function hpeSummarySearch(val) {

	document.body.className = 'wait';

	var elemSearchSummaryFromDate = document.hpeEncounterForm.searchSummaryFromDate;
	var elemSearchSummaryToDate = document.hpeEncounterForm.searchSummaryToDate;
	var result;

	result = parseDateFld9(elemSearchSummaryFromDate.value, true, false,
			"From Date", true);

	if (result == "NaD") {
		elemSearchSummaryFromDate.focus();
		elemSearchSummaryFromDate.select();
		return false;
	}

	elemSearchSummaryFromDate.value = result;
	result = parseDateFld9(elemSearchSummaryToDate.value, true, false,
			"To Date", true);
	if (result == "NaD") {
		elemSearchSummaryToDate.focus();
		elemSearchSummaryToDate.select();
		return false;
	}
	elemSearchSummaryToDate.value = result;
	if (isStartBeforeEndDate(elemSearchSummaryFromDate,
			elemSearchSummaryToDate, false)) {
		elemSearchSummaryFromDate.focus();
		elemSearchSummaryFromDate.select();
		return false;
	}

	if (val == 'Dashboard') {
		document.hpeEncounterForm.menu.value = 'Dashboard';
		document.hpeEncounterForm.method.value = 'dashTreeSearch';
	} else if (val == 'Summary') {
		document.hpeEncounterForm.menu.value = 'Summary';
		document.hpeEncounterForm.method.value = 'summTreeSearch';
	}

	document.hpeEncounterForm.selClaimType.value = document.hpeEncounterForm.searchSummaryType.value;
	document.hpeEncounterForm.submit();
}

function hpeFileTrackSearch(val) {
	document.body.className = 'wait';
	var elemSearchSummaryFromDate = document.hpeftSearchForm.searchFromDate;
	var elemSearchSummaryToDate = document.hpeftSearchForm.searchToDate;
	var result;

	result = parseDateFld9(elemSearchSummaryFromDate.value, true, false,
			"From Date", true);

	if (result == "NaD") {
		elemSearchSummaryFromDate.focus();
		elemSearchSummaryFromDate.select();
		return false;
	}

	elemSearchSummaryFromDate.value = result;
	result = parseDateFld9(elemSearchSummaryToDate.value, true, false,
			"To Date", true);
	if (result == "NaD") {
		elemSearchSummaryToDate.focus();
		elemSearchSummaryToDate.select();
		return false;
	}
	elemSearchSummaryToDate.value = result;
	if (isStartBeforeEndDate(elemSearchSummaryFromDate,
			elemSearchSummaryToDate, false)) {
		elemSearchSummaryFromDate.focus();
		elemSearchSummaryFromDate.select();
		return false;
	}

	var searchText = document.hpeftSearchForm.searchText.value;
	var btnSelected = document.getElementsByName('searchBy');
	var claimType = document.getElementById('searchClaimType').value;
	var claimRefNo = document.getElementById('searchClmRefNbr').value;
	var isChecked_fileName = false;
	var isChecked_fileId = false;
	
	if(btnSelected[0].checked){
		isChecked_fileName = true;
		document.hpeftSearchForm.searchBy.value = btnSelected;
	}
	if(btnSelected[1].checked){
		isChecked_fileId = true;
		document.hpeftSearchForm.searchBy.value = btnSelected;
	}
	
	if((claimType == "I" || claimType == "P") && (isChecked_fileId || isChecked_fileName)){
		
		alert("Select either FileName/File ID or Claim type. Both can't be selected");
		document.body.className = '';
		
	}else if((claimRefNo != "" && claimRefNo != null) && (isChecked_fileId || isChecked_fileName)){
		alert("Select either FileName/File ID or Claim Number. Both can't be selected");
		document.body.className = '';
	}else if(claimRefNo != "" && (claimType != "I" && claimType != "P" && claimType != "E")){//IFOX-00419138 - DME claim selection in File Management
		alert("Please select claim type either Institutional or Professional or DME");//IFOX-00419138 - DME claim selection in File Management
		document.body.className = '';
    }
	else{
		if((claimType == "I" || claimType == "P") && (claimRefNo == "" || claimRefNo == null)){

			alert("Claim Number cannot be empty");
			document.body.className = '';
		}else if(isChecked_fileName && (searchText == null || searchText == "")){
			alert("File Name cannot be empty");
			document.body.className = '';
		}else if(isChecked_fileId && (searchText == null || searchText == "")){
			alert("File ID cannot be empty");
			document.body.className = '';
		}else if(isChecked_fileId && isNaN(searchText)){
			alert("File ID must be numeric");
			document.body.className = '';
			
		}else if((btnSelected[0].checked == false && btnSelected[1].checked == false) && (searchText != "")){
			alert("Please select either File Name or File ID");
			document.body.className = '';
		}else{
			document.forms[0].menu.value = 'fileTracking';
			document.forms[0].method.value = 'fileTreeSearch';
			document.forms[0].submit();
		}
	}
	
}

function hpeFileTrackExport(val) {
	
	var elemSearchSummaryFromDate = document.hpeftSearchForm.searchFromDate;
	var elemSearchSummaryToDate = document.hpeftSearchForm.searchToDate;
	var result;

	result = parseDateFld9(elemSearchSummaryFromDate.value, true, false,
			"From Date", true);

	if (result == "NaD") {
		elemSearchSummaryFromDate.focus();
		elemSearchSummaryFromDate.select();
		return false;
	}

	elemSearchSummaryFromDate.value = result;
	result = parseDateFld9(elemSearchSummaryToDate.value, true, false,
			"To Date", true);
	if (result == "NaD") {
		elemSearchSummaryToDate.focus();
		elemSearchSummaryToDate.select();
		return false;
	}
	elemSearchSummaryToDate.value = result;
	if (isStartBeforeEndDate(elemSearchSummaryFromDate,
			elemSearchSummaryToDate, false)) {
		elemSearchSummaryFromDate.focus();
		elemSearchSummaryFromDate.select();
		return false;
	}

	document.forms[0].menu.value = 'exportFilenames';
	document.forms[0].method.value = 'fileTreeExport';
	document.forms[0].submit();
	document.getElementById("exportPrintAnchor").disabled = false;
}

function enableBtn(){
	document.getElementById("exportPrintAnchor").disabled=false;
}

function hpeOptionSearch(val, flag) {
	document.body.className = 'wait';

	var elemSearchSummaryFromDate = "";
	var elemSearchSummaryFromDate = "";
	var resultFromDate;
	var resultToDate;

	if (flag == "0") {
		elemSearchSummaryFromDate = document.hpeEncounterForm.searchSummaryFromDate;
		resultFromDate = parseDateFld9(elemSearchSummaryFromDate.value, true,
				false, "From Date", true);

		elemSearchSummaryToDate = document.hpeEncounterForm.searchSummaryToDate;
		resultToDate = parseDateFld9(elemSearchSummaryToDate.value, true,
				false, "To Date", true);

	} else if (flag == "1") {
		elemSearchSummaryFromDate = document.hpeEncounterForm.searchDetailFromDate;
		resultFromDate = parseDateFld9(elemSearchSummaryFromDate.value, true,
				true, "From Date", true);

		elemSearchSummaryToDate = document.hpeEncounterForm.searchDetailToDate;
		resultToDate = parseDateFld9(elemSearchSummaryToDate.value, true, true,
				"To Date", true);
	}

	if (resultFromDate == "NaD") {
		elemSearchSummaryFromDate.focus();
		elemSearchSummaryFromDate.select();
		return false;
	}
	elemSearchSummaryFromDate.value = resultFromDate;

	if (resultToDate == "NaD") {
		elemSearchSummaryToDate.focus();
		elemSearchSummaryToDate.select();
		return false;
	}
	elemSearchSummaryToDate.value = resultToDate;

	if (isStartBeforeEndDate(elemSearchSummaryFromDate,
			elemSearchSummaryToDate, false)) {
		elemSearchSummaryFromDate.focus();
		elemSearchSummaryFromDate.select();
		return false;
	}

	if (val == 'Dashboard') {
		document.hpeEncounterForm.menu.value = 'Dashboard';
		document.hpeEncounterForm.method.value = 'dashTreeOption';
	} else if (val == 'Summary') {
		document.hpeEncounterForm.menu.value = 'Summary';
		document.hpeEncounterForm.method.value = 'summTreeOption';
	}
	document.hpeEncounterForm.submit();
}
//DME_Dashboard_changes
function hpeSummarySelect(element, encType, date, groupStatus) {
	document.body.className = 'wait';

	document.hpeEncounterForm.menu.value = 'Dashboard';
	document.hpeEncounterForm.method.value = 'dashInstMonth';
	document.hpeEncounterForm.searchSummaryEncType.value = encType;
	document.hpeEncounterForm.selClaimType.value = document.hpeEncounterForm.searchSummaryType.value;
	document.hpeEncounterForm.selectedDateYrmo.value = date;
	document.hpeEncounterForm.searchSummaryGroupStatus.value = groupStatus;
	document.hpeEncounterForm.submit();
}

function hpeErrorSpecificClaims(element, encType, date, errorSource,
		errorGroup, rejectCode) {
	document.body.className = 'wait';

	element.style.backgroundColor = 'red';
	document.hpeEncounterForm.menu.value = 'Summary';
	document.hpeEncounterForm.method.value = 'summDetailOption';
	document.hpeEncounterForm.searchSummaryEncType.value = encType;
	document.hpeEncounterForm.rejectCode.value = rejectCode;
	document.hpeEncounterForm.formattedErrorSource.value = errorSource;
	document.hpeEncounterForm.selectedErrorGroup.value = errorGroup;
	document.hpeEncounterForm.selectedDateYrmo.value = date;
	document.hpeEncounterForm.selClaimType.value = document.hpeEncounterForm.searchSummaryType.value;
	document.hpeEncounterForm.submit();
}

function hpeErrorSummarySelect(element, encType, date, errorSource) {
	document.body.className = 'wait';

	document.hpeEncounterForm.menu.value = 'Summary';
	document.hpeEncounterForm.method.value = 'summInstMonth';
	document.hpeEncounterForm.searchSummaryEncType.value = encType;
	document.hpeEncounterForm.selectedDateYrmo.value = date
	document.hpeEncounterForm.searchSummaryErrorSource.value = errorSource;
	document.hpeEncounterForm.selClaimType.value = document.hpeEncounterForm.searchSummaryType.value;
	document.hpeEncounterForm.submit();
}

function hpeDashDetailSearch(val) {

	// alert(document.hpeEncounterForm.searchDetailClmType.value);
	document.body.className = 'wait';

	var elemSearchDetailFromDate = document.hpeEncounterForm.searchDetailFromDate;
	var elemSearchDetailToDate = document.hpeEncounterForm.searchDetailToDate;
	var result;

	result = parseDateFld9(elemSearchDetailFromDate.value, true, true,
			"From Date", true);
	if (result == "NaD") {
		elemSearchDetailFromDate.focus();
		elemSearchDetailFromDate.select();
		return false;
	}
	elemSearchDetailFromDate.value = result;

	result = parseDateFld9(elemSearchDetailToDate.value, true, true, "To Date",
			true);
	if (result == "NaD") {
		elemSearchDetailToDate.focus();
		elemSearchDetailToDate.select();
		return false;
	}
	elemSearchDetailToDate.value = result;

	if (isStartBeforeEndDate(elemSearchDetailFromDate, elemSearchDetailToDate,
			true)) {
		elemSearchDetailFromDate.focus();
		elemSearchDetailFromDate.select();
		return false;
	}

	if (val == 'Dashboard') {
		document.hpeEncounterForm.menu.value = 'Dashboard';
		document.hpeEncounterForm.method.value = 'dashDetailSearch';
	} else if (val == 'Summary') {
		document.hpeEncounterForm.menu.value = 'Summary';
		document.hpeEncounterForm.method.value = 'summDetailSearch';
	}

	document.hpeEncounterForm.selClaimType.value = document.hpeEncounterForm.searchDetailClmType.value;
	document.hpeEncounterForm.submit();
}

function hpeClaimSelect(val, encType, claimRefNbr, claimRevNbr, claimSeqNbr) {

	if (isDataChanged() || isClaimProviderChanged()) {
		response = confirm("Discard Changes?");
		if (response != true)
			return;
	}

	MarkDataChanged(false);
	MarkClaimProviderChanged(false);

	document.body.className = 'wait';

	if (val == 'Dashboard') {
		document.hpeEncounterForm.menu.value = 'Dashboard';
		document.hpeEncounterForm.method.value = 'dashDetailSelect';
	} else if (val == 'Summary') {
		document.hpeEncounterForm.menu.value = 'Summary';
		document.hpeEncounterForm.method.value = 'summDetailSelect';
	}

	document.hpeEncounterForm.selectedClaimType.value = encType;
	document.hpeEncounterForm.selectedClaimRefNbr.value = claimRefNbr;
	document.hpeEncounterForm.selectedClaimRevNbr.value = claimRevNbr;
	document.hpeEncounterForm.selectedClaimSeqNbr.value = claimSeqNbr;
	document.hpeEncounterForm.submit();
}

function validateSearchDate(element, mdy) {
	var result = parseDateFld9(element.value, false, mdy, "", true);
	if (result == "NaD") {
		return false;
	}
	element.value = result;
	return true;
}

function makeUpperCase(element) {
	element.value = Ltrim(Rtrim(element.value)).toUpperCase();
	return true;
}

function setRowClass(row, className) {
	row.className = className;
	var cells = row.getElementsByTagName("td");
	for (var i = 0, n = cells.length; i < n; ++i) {
		cells[i].className = className;
	}
}

function changeSelectedRow(table, newSelectedRow) {

	if (table == null)
		return;

	// Collect indices for all the interesting rows (selectedRow, evenRow,
	// oddRow)
	var arrRows = new Array();
	for (var i = 0, n = table.rows.length; i < n; ++i) {
		var row = table.rows[i];
		if (row != null) {
			if (row.className != null) {
				if ((row.className == "selectedRow")
						|| (row.className == "evenRow")
						|| (row.className == "oddRow")) {
					arrRows.push(i);
				}
			}
		}
	}

	// Use the indices to set the proper class name
	for (var i = 0, n = arrRows.length; i < n; ++i) {
		var row = table.rows[arrRows[i]];
		if (i == newSelectedRow) {
			setRowClass(row, "selectedRow");
		} else if (i % 2 == 0) {
			setRowClass(row, "evenRow");
		} else {
			setRowClass(row, "oddRow");
		}
	}
}

function clickOption(obj, val) {
	document.body.className = 'wait';
	var objLnk = document.getElementById(obj);
	sHref = objLnk.href + val;
	objLnk.href = sHref;
	objLnk.click();
}

function clickCROption(val, encType, claimRefNbr) {

	document.hpeEncounterForm.selectedClaimType.value = encType;
	document.hpeEncounterForm.selectedClaimRefNbr.value = claimRefNbr;
	document.hpeEncounterForm.prevMenu.value = document.hpeEncounterForm.menu.value;
	document.hpeEncounterForm.prevMethod.value = document.hpeEncounterForm.method.value;
	if (val == 'Dashboard') {
		document.hpeEncounterForm.menu.value = 'Dashboard';
		document.hpeEncounterForm.method.value = 'dashMoveCR';
	} else if (val == 'Summary') {
		document.hpeEncounterForm.menu.value = 'Summary';
		document.hpeEncounterForm.method.value = 'summMoveCR';
	}
	document.hpeEncounterForm.submit();
}

/*
 * function clickCROption(encType,val) { var link =
 * '/chartAction.do?claimType='+encType+'&method=chartDetailOption&prevMenu='+document.hpeEncounterForm.menu.value+'&prevMethod='+document.hpeEncounterForm.method.value+'&claimRefNbr='+val+'&submitterId='+document.hpeEncounterForm.searchDetailSubmitterId.value;
 * window.location.href = link; }
 */

// Institutional
function toggleInstList(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].instListExpanded)
}

function toggleInstErrors(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].instErrorsExpanded)
}

function toggleInstSubscriber(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].instSubscriberExpanded)
}

function toggleInstProvider(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].instProviderExpanded)
}

function toggleInstClaim(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].instClaimExpanded)
}

function toggleInstClaimCodes(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].instClaimCodesExpanded)
}

function toggleInstClaimProv(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].instClaimProvExpanded)
}

function toggleInstClaimProvDetail(ctl, id) {
	toggleVisibilityState(ctl, id,
			document.forms[0].instClaimProvDetailExpanded)
}

function toggleInstClaimOtherSubs(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].instClaimOtherSubsExpanded)
}

function toggleInstClaimOtherSubsDetail(ctl, id) {
	toggleVisibilityState(ctl, id,
			document.forms[0].instClaimOtherSubsDetailExpanded)
}

function toggleInstClaimOtherSubsProv(ctl, id) {
	toggleVisibilityState(ctl, id,
			document.forms[0].instClaimOtherSubsProvExpanded)
}

function toggleInstClaimOtherSubsProvDetail(ctl, id) {
	toggleVisibilityState(ctl, id,
			document.forms[0].instClaimOtherSubsProvDetailExpanded)
}

function toggleInstClaimLine(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].instClaimLineExpanded)
}

function toggleInstClaimLineDetail(ctl, id) {
	toggleVisibilityState(ctl, id,
			document.forms[0].instClaimLineDetailExpanded)
}

function toggleInstClaimLineProv(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].instClaimLineProvExpanded)
}

function toggleInstClaimLineProvDetail(ctl, id) {
	toggleVisibilityState(ctl, id,
			document.forms[0].instClaimLineProvDetailExpanded)
}

function toggleInstClaimLineAdjud(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].instClaimLineAdjudExpanded)
}

function toggleInstClaimLineAdjudDetail(ctl, id) {
	toggleVisibilityState(ctl, id,
			document.forms[0].instClaimLineAdjudDetailExpanded)
}

function toggleInstClaimNotes(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].instClaimNotesExpanded)
}


//Editable Fileds CHS -- IFOX-00395627
function toggleInstConditionCode(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].instConditionCodeExpanded)
}

function toggleInstClaimCodes(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].instDiagCodeExpanded)
}

function toggleInstDiagCodes(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].instProcedureCodeExpanded)
}

function toggleInstOccurrenceSpanCodes(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].instOccurrenceSpanExpanded)
}

function toggleInstValueCodes(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].instValueExpanded)
}

function toggleInstOccurrenceCodes(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].instOccurrenceExpanded)
}

function toggleInstTreatmentCodes(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].instTreatmentExpanded)
}

function toggleInstExtCauseInjuryCodes(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].instExtCauseInjuryExpanded)
}


function toggleProfConditionCode(ctl, id) {	
	toggleVisibilityState(ctl, id, document.forms[0].profConditionCodeExpanded)
}

function toggleProfDiagCodes(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].profProcedureCodeExpanded)
}

//Editable Fileds CHS -- IFOX-00395627

// Professional
function toggleProfList(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].profListExpanded)
}

function toggleProfErrors(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].profErrorsExpanded)
}

function toggleProfSubscriber(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].profSubscriberExpanded)
}

function toggleProfProvider(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].profProviderExpanded)
}

function toggleProfClaim(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].profClaimExpanded)
}

function toggleProfClaimCodes(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].profClaimCodesExpanded)
}

function toggleProfClaimProv(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].profClaimProvExpanded)
}

function toggleProfClaimProvDetail(ctl, id) {
	toggleVisibilityState(ctl, id,
			document.forms[0].profClaimProvDetailExpanded)
}

function toggleProfClaimOtherSubs(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].profClaimOtherSubsExpanded)
}

function toggleProfClaimOtherSubsDetail(ctl, id) {
	toggleVisibilityState(ctl, id,
			document.forms[0].profClaimOtherSubsDetailExpanded)
}

function toggleProfClaimOtherSubsProv(ctl, id) {
	toggleVisibilityState(ctl, id,
			document.forms[0].profClaimOtherSubsProvExpanded)
}

function toggleProfClaimOtherSubsProvDetail(ctl, id) {
	toggleVisibilityState(ctl, id,
			document.forms[0].profClaimOtherSubsProvDetailExpanded)
}

function toggleProfClaimLine(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].profClaimLineExpanded)
}

function toggleProfClaimLineDetail(ctl, id) {
	toggleVisibilityState(ctl, id,
			document.forms[0].profClaimLineDetailExpanded)
}

function toggleProfClaimLineProv(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].profClaimLineProvExpanded)
}

function toggleProfClaimLineProvDetail(ctl, id) {
	toggleVisibilityState(ctl, id,
			document.forms[0].profClaimLineProvDetailExpanded)
}

function toggleProfClaimLineAdjud(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].profClaimLineAdjudExpanded)
}

function toggleProfClaimLineAdjudDetail(ctl, id) {
	toggleVisibilityState(ctl, id,
			document.forms[0].profClaimLineAdjudDetailExpanded)
}

function toggleProfClaimNotes(ctl, id) {
	toggleVisibilityState(ctl, id, document.forms[0].profClaimNotesExpanded)
}

function toggleVisibilityState(ctl, id, state) {
	var elem = document.getElementById(id);
	toggleVisibilityElem(ctl, elem);
	if (elem.style.display == 'none')
		state.value = false;
	else
		state.value = true;
}

function toggleVisibilityElem(ctl, elem) {
	if (elem.style.display == 'none') {
		elem.style.display = "";
		elem.setAttribute("rowExpanded", "true");
		ctl.src = '/mss/jsp/Recon/images/Minus.png';
	} else {
		elem.style.display = 'none';
		elem.setAttribute("rowExpanded", "false");
		ctl.src = '/mss/jsp/Recon/images/Plus.png';
	}
}

function toggleImages(ctl, id, state) {
	var elem = document.getElementById(id);
	if (elem.style.display == 'none') {
		elem.style.display = "";
		elem.setAttribute("rowExpanded", "true");
		document.getElementById(ctl).src = "/mss/jsp/Recon/images/Minus.png";
		state.value = true;
	}
}

function setVisibility(fldCtlId, divCtlId, imgCtlId, state) {

	var fldCtl = document.getElementById(fldCtlId);
	var divCtl = document.getElementById(divCtlId);
	var imgCtl = document.getElementById(imgCtlId);

	if (state) {
		divCtl.style.display = "";
		divCtl.setAttribute("rowExpanded", "true");
		imgCtl.src = "/mss/jsp/Recon/images/Minus.png";
	} else {
		fldCtl.value = false;
		divCtl.style.display = "none";
		divCtl.setAttribute("rowExpanded", "false");
		imgCtl.src = "/mss/jsp/Recon/images/Plus.png";
	}
}

function hpeErrorDetailSearch() {

	document.body.className = 'wait';

	var elemSearchSummaryFromDate = document.hpeEncounterForm.searchSummaryFromDate;
	var elemSearchSummaryToDate = document.hpeEncounterForm.searchSummaryToDate;
	var result;

	result = parseDateFld9(elemSearchSummaryFromDate.value, true, false,
			"From Date", true);
	if (result == "NaD") {
		elemSearchSummaryFromDate.focus();
		elemSearchSummaryFromDate.select();
		return false;
	}
	elemSearchSummaryFromDate.value = result;

	result = parseDateFld9(elemSearchSummaryToDate.value, true, false,
			"From Date", true);
	if (result == "NaD") {
		elemSearchSummaryToDate.focus();
		elemSearchSummaryToDate.select();
		return false;
	}
	elemSearchSummaryToDate.value = result;

	if (isStartBeforeEndDate(elemSearchSummaryFromDate,
			elemSearchSummaryToDate, false)) {
		elemSearchSummaryFromDate.focus();
		elemSearchSummaryFromDate.select();
		return false;
	}

	document.hpeEncounterForm.menu.value = 'Summary';
	document.hpeEncounterForm.method.value = 'errorSearch';
	document.hpeEncounterForm.selClaimType.value = document.hpeEncounterForm.searchSummaryType.value;
	document.hpeEncounterForm.submit();
}

function hpeOptionErrorDetailSearch(flag) {

	document.body.className = 'wait';

	var elemSearchSummaryFromDate = "";
	var elemSearchSummaryFromDate = "";
	var resultFromDate;
	var resultToDate;

	if (flag == "0") {
		elemSearchSummaryFromDate = document.hpeEncounterForm.searchSummaryFromDate;
		resultFromDate = parseDateFld9(elemSearchSummaryFromDate.value, true,
				false, "From Date", true);

		elemSearchSummaryToDate = document.hpeEncounterForm.searchSummaryToDate;
		resultToDate = parseDateFld9(elemSearchSummaryToDate.value, true,
				false, "To Date", true);

	} else if (flag == "1") {
		elemSearchSummaryFromDate = document.hpeEncounterForm.searchDetailFromDate;
		resultFromDate = parseDateFld9(elemSearchSummaryFromDate.value, true,
				true, "From Date", true);

		elemSearchSummaryToDate = document.hpeEncounterForm.searchDetailToDate;
		resultToDate = parseDateFld9(elemSearchSummaryToDate.value, true, true,
				"To Date", true);
	}

	if (resultFromDate == "NaD") {
		elemSearchSummaryFromDate.focus();
		elemSearchSummaryFromDate.select();
		return false;
	}
	elemSearchSummaryFromDate.value = resultFromDate;

	if (resultToDate == "NaD") {
		elemSearchSummaryToDate.focus();
		elemSearchSummaryToDate.select();
		return false;
	}
	elemSearchSummaryToDate.value = resultToDate;

	if (flag == "0") {
		if (isStartBeforeEndDate(elemSearchSummaryFromDate,
				elemSearchSummaryToDate, false)) {
			elemSearchSummaryFromDate.focus();
			elemSearchSummaryFromDate.select();
			return false;
		}
	} else if (flag == "1") {
		if (isStartBeforeEndDate(elemSearchSummaryFromDate,
				elemSearchSummaryToDate, true)) {
			elemSearchSummaryFromDate.focus();
			elemSearchSummaryFromDate.select();
			return false;
		}
	}

	document.hpeEncounterForm.menu.value = 'Summary';
	document.hpeEncounterForm.method.value = 'summRejectCodesOption';
	document.hpeEncounterForm.submit();
}

function updateData(claimType) {
	document.getElementById('messageSubscriber').innerHTML = "";
	showSubscriberEntry(claimType);

	if (claimType == 'I') {
		toggleImages('img1', 'instSubscriberDiv',
				document.forms[0].instSubscriberExpanded);
		toggleImages('img2', 'instClaimDiv',  
				document.forms[0].instClaimExpanded);
		
		//Added for Updateable Fields change : start
		
		toggleImages('img10', 'instClaimCodesDiv',  
				document.forms[0].instClaimCodesExpanded);
		toggleImages('img11', 'instConditionCodeDiv',  
				document.forms[0].instConditionCodeExpanded);
		toggleImages('img12', 'instDiagCodeDiv',  
				document.forms[0].instDiagCodeExpanded);
		toggleImages('img13', 'instProcedureCodeDiv',  
				document.forms[0].instProcedureCodeExpanded);
		toggleImages('img14', 'instOccurrenceSpanDiv',  
				document.forms[0].instOccurrenceSpanExpanded);
		toggleImages('img15', 'instValueDiv',  
				document.forms[0].instValueExpanded);
		toggleImages('img16', 'instOccurrenceDiv',  
				document.forms[0].instOccurrenceExpanded);
		toggleImages('img17', 'instTreatmentDiv',  
				document.forms[0].instTreatmentExpanded);
		toggleImages('img18', 'instExtCauseInjuryDiv',  
				document.forms[0].instExtCauseInjuryExpanded);
		
		//Added for Updateable Fields change : end
		
		toggleImages('img4', 'instProviderDiv',
				document.forms[0].instProviderExpanded);
		toggleImages('img8', 'instClaimOtherSubsDetailDiv',
				document.forms[0].instClaimOtherSubsDetailExpanded);
		toggleImages('img9', 'instClaimOtherSubsProvDetailDiv',
				document.forms[0].instClaimOtherSubsProvDetailExpanded);
		toggleImages('img6', 'instClaimLineDetailDiv',
				document.forms[0].instClaimLineDetailExpanded);
		toggleImages('img7', 'instClaimLineProvDetailDiv',
				document.forms[0].instClaimLineProvDetailExpanded);
		toggleImages('img5', 'instClaimLineAdjudDetailDiv',
				document.forms[0].instClaimLineAdjudDetailExpanded);
	} else if (claimType == 'P') {
		toggleImages('img1', 'profSubscriberDiv',
				document.forms[0].profSubscriberExpanded);
		toggleImages('img2', 'profClaimDiv',
				document.forms[0].profClaimExpanded); 
		
		//Added for Updateable Fields change : start
		
		toggleImages('img10', 'profClaimCodesDiv',  
				document.forms[0].profClaimCodesExpanded);
		toggleImages('img11', 'profConditionCodeDiv',  
				document.forms[0].profConditionCodeExpanded);
		toggleImages('img12', 'profDiagCodeDiv',  
				document.forms[0].profDiagCodeExpanded);
		
		//Added for Updateable Fields change : end
		toggleImages('img4', 'profProviderDiv',
				document.forms[0].profProviderExpanded);
		toggleImages('img8', 'profClaimOtherSubsDetailDiv',
				document.forms[0].profClaimOtherSubsDetailExpanded);
		toggleImages('img9', 'profClaimOtherSubsProvDetailDiv',
				document.forms[0].profClaimOtherSubsProvDetailExpanded);
		toggleImages('img6', 'profClaimLineDetailDiv',
				document.forms[0].profClaimLineDetailExpanded);
		toggleImages('img7', 'profClaimLineProvDetailDiv',
				document.forms[0].profClaimLineProvDetailExpanded);
		toggleImages('img5', 'profClaimLineAdjudDetailDiv',
				document.forms[0].profClaimLineAdjudDetailExpanded);
	}
}

function subscriberSaveValidate() {

	var ctl;
	var tmplt;

	if (isFldEmpty(document.getElementsByName("subsFirstName").item(0),
			"First Name"))
		return false;
	if (isFldEmpty(document.getElementsByName("subsLastName").item(0),
			"Last Name"))
		return false;

	if (isFldEmpty(document.getElementsByName("subsHicNbr").item(0),
			"HIC Number"))
		return false;
	
	/*if (isFldEmpty(document.getElementsByName("mbi").item(0),
		"Medicare ID"))
		return false;*/
	
	ctl = document.getElementsByName("formattedSubsSsn").item(0);
	if (!isEmpty(ctl.value)) {
		if (!checkSSNFormat(ctl, true))
			return false;
	}

	ctl = document.getElementsByName("formattedSubsDob").item(0);
	if (isFldEmpty(ctl, "DOB"))
		return false;
	if (!validateDate(ctl))
		return false;

	ctl = document.getElementsByName("subsSex").item(0);
	tmplt = document.getElementById("tmpltGender");
	if (!CheckSelectBoxValue(ctl, tmplt, "Gender"))
		return false;

	if (isFldEmpty(document.getElementsByName("subsAddrLine1").item(0),
			"Address Line 1"))
		return false;
	if (isFldEmpty(document.getElementsByName("subsCity").item(0), "City"))
		return false;

	ctl = document.getElementsByName("subsState").item(0);
	tmplt = document.getElementById("tmpltState");
	if (!CheckSelectBoxValue(ctl, tmplt, "State"))
		return false;

	if (!checkNoDashZipFormat(document.getElementsByName("subsZip").item(0)))
		return false;

	return true;
}
//IFOX-00417724 - Claim status not changed to COR - Start
function CheckCORSave(claimType) {
	var status = getSelectedValue(document.getElementsByName("processStatus")
			.item(0));
	if (status != "COR"){
    var strconfirm = confirm("Are you sure to continue saving without changing the process status to COR?");
    if (strconfirm == true) {
        saveData(claimType);
    }
	}else{
		saveData(claimType);
	}
}
//IFOX-00417724 - Claim status not changed to COR - End
function saveData(claimType) {

	var status = getSelectedValue(document.getElementsByName("processStatus")
			.item(0));
	if (status == "COR" || status == "REJ" || status == "CCR") {

		if (!subscriberSaveValidate())
			return;

		if (!claimSaveValidate(claimType))
			return;

		if (document.hpeEncounterForm.clmProviderExist.value == "Y") {
			if (!claimPrvSaveValidate(claimType))
				return;
		}

		if (document.hpeEncounterForm.clmOtherSubscribersExist.value == "Y") {
			if (!clmOtherSubsValidate(claimType))
				return;
		}

		if (document.hpeEncounterForm.clmLinesExist.value == "Y") {
			if (!clmLineSaveValidate(claimType))
				return;
		}

		if (document.hpeEncounterForm.clmLineAdjudExist.value == "Y") {
			if (!clmLineAdjudSaveValidate(claimType))
				return;
		}
		if (document.hpeEncounterForm.billProviderExist.value == "Y") {
			if (!billingPrvSaveValidate(claimType))
				return;
		}
	}

	document.body.className = 'wait';

	document.hpeEncounterForm.menu.value = 'Dashboard';
	document.hpeEncounterForm.method.value = 'dashDetailSave';

	if (document.hpeEncounterForm.selectedClaimType.value == ""
			&& document.hpeEncounterForm.selectedClaimRefNbr.value == ""
			&& document.hpeEncounterForm.selectedClaimRevNbr.value == ""
			&& document.hpeEncounterForm.selectedClaimSeqNbr.value == "") {
		document.hpeEncounterForm.selectedClaimType.value = document.hpeEncounterForm.firstClaimType.value;
		document.hpeEncounterForm.selectedClaimRefNbr.value = document.hpeEncounterForm.firstClaimRefNbr.value;
		document.hpeEncounterForm.selectedClaimRevNbr.value = document.hpeEncounterForm.firstClaimRevNbr.value;
		document.hpeEncounterForm.selectedClaimSeqNbr.value = document.hpeEncounterForm.firstClaimSeqNbr.value;
	}

	document.hpeEncounterForm.submit();
}

function cancelData(claimType) {

	MarkDataChanged(false);
	MarkClaimProviderChanged(false);

	document.getElementsByName("subsFirstName").item(0).value = document
			.getElementsByName("subsFirstNameOriginal").item(0).value;
	document.getElementsByName("subsMiddleName").item(0).value = document
			.getElementsByName("subsMiddleNameOriginal").item(0).value;
	document.getElementsByName("subsLastName").item(0).value = document
			.getElementsByName("subsLastNameOriginal").item(0).value;
	document.getElementsByName("subsHicNbr").item(0).value = document
			.getElementsByName("subsHicNbrOriginal").item(0).value;
	document.getElementsByName("mbi").item(0).value = document
			.getElementsByName("subsHicNbrOriginal").item(0).value;
	document.getElementsByName("formattedSubsSsn").item(0).value = document
			.getElementsByName("subsSsnOriginal").item(0).value;
	document.getElementsByName("subsAddrLine1").item(0).value = document
			.getElementsByName("subsAddrLine1Original").item(0).value;
	document.getElementsByName("formattedSubsDob").item(0).value = document
			.getElementsByName("subsDobOriginal").item(0).value;
	document.getElementsByName("subsSex").item(0).value = document
			.getElementsByName("subsSexOriginal").item(0).value;
	document.getElementsByName("subsAddrLine2").item(0).value = document
			.getElementsByName("subsAddrLine2Original").item(0).value;
	document.getElementsByName("subsCity").item(0).value = document
			.getElementsByName("subsCityOriginal").item(0).value;
	doSelect(document.getElementsByName("subsState").item(0), document
			.getElementsByName("subsStateOriginal").item(0).value);
	document.getElementsByName("subsZip").item(0).value = document
			.getElementsByName("subsZipOriginal").item(0).value;
	showSubscriberDisplay();
	//Added for Updateable fields : start
	showClaimCodesDisplay(claimType);
	//Added for Updateable fielsds : end
	claimCancel(claimType);
	if (document.hpeEncounterForm.clmProviderExist.value == "Y")
		claimPrvCancel(claimType);

	if (document.hpeEncounterForm.billProviderExist.value == "Y")
		billPrvCancel(claimType);

	if (document.hpeEncounterForm.clmOtherSubscribersExist.value == "Y") {
		clmOtherSubsCancel(claimType);
	}

	if (document.hpeEncounterForm.clmOtherSubsProvExist.value == "Y") {
		clmOtherSubsProvCancel(claimType);
	}

	if (document.hpeEncounterForm.clmLinesExist.value == "Y") {
		clmLineCancel(claimType);
	}

	if (document.hpeEncounterForm.clmLineProvExist.value == "Y") {
		clmLinePrvCancel(claimType);
	}

	if (document.hpeEncounterForm.clmLineAdjudExist.value == "Y") {
		clmLineAdjudCancel(claimType);
	}
}

function showSubscriberDisplay() {
	var ctl;
	ctl = document.getElementById('subscriberEntry');
	ctl.style.display = "none";

	ctl = document.getElementById('buttonDiv');
	ctl.style.display = "";

	ctl = document.getElementById('buttonDiv1');
	ctl.style.display = "none";

	ctl = document.getElementById('subscriberDisplay');
	ctl.style.display = "";

	ctl = document.getElementById('subscriberChanged');
	ctl.value = "false";

	ctl = document.getElementById('subscriberDisplayState');
	ctl.value = "VIEW";
}

function showSubscriberEntry(claimType) {
	var ctl;
	ctl = document.getElementById('subscriberDisplay');
	ctl.style.display = "none";

	ctl = document.getElementById('subscriberEntry');
	ctl.style.display = "";

	ctl = document.getElementById('buttonDiv');
	ctl.style.display = "none";

	ctl = document.getElementById('buttonDiv1');
	ctl.style.display = "";

	ctl = document.getElementById('subscriberDisplayState');
	ctl.value = "EDIT";

	showClaimEntry(claimType);
	//Added for Updataeble fields : start
	showClaimCodesEntry(claimType);
	//Added for Updataeble fields : end
	
	showClmOtherSubsEntry(claimType);
	showClmOtherSubsProvEntry(claimType);
	showClmLineEntry(claimType);
	showClmLineProvEntry(claimType);
	showClmLineAjudEntry(claimType);
	showBillPrvEntry();
	showClmLineAdjudAdjustEntry(claimType);		//IFOX-00413184 - Opening of Claim Adjudication fields and amounts
	showClaimPrvEntry(claimType); //IFOX-00418160 - NPI Provider fields update
}

function claimSaveValidate(claimType) {

	var ctl;
	var tmplt;

	if (claimType == 'P') {
		//IFOX-00408890 - Invalid POS error - Start
		ctl = document.getElementsByName("placeOfService").item(0);
		//IFOX-00408890 - Invalid POS error - End
		tmplt = document.getElementById("tmpltPlaceOfService");
		if (!CheckSelectBoxValue(ctl, tmplt, "PlaceOfService"))
			return false;

		ctl = document.getElementsByName("formattedHospAdmitDt").item(0);
		if (!isWhitespace(ctl.value)) {
			if (!validateDate(ctl))
				return false;
		}
		ctl = document.getElementsByName("formattedHospDischargeDt").item(0);
		if (!isWhitespace(ctl.value)) {
			if (!validateDate(ctl))
				return false;
		}

		tmplt = document.getElementById("tmpltState");
		ctl = document.hpeEncounterForm.ambPickupState;
		if (!noValueSelected(ctl)) {
			if (!CheckSelectBoxValue(ctl, tmplt, "Ambulance Pickup State"))
				return false;
		}

		ctl = document.hpeEncounterForm.ambDropoffState;
		if (!noValueSelected(ctl)) {
			if (!CheckSelectBoxValue(ctl, tmplt, "Ambulance Dropoff State"))
				return false;
		}

	} else {
		ctl = document.hpeEncounterForm.clmFacTypeCd;
		if (!isFldNumeric(ctl, "Fac Type Cd"))
			return false;
		if (ctl.value.length != 2) {
			alert("Fac Type Cd must be 2 numeric digits")
			ctl.focus();
			ctl.select();
			return false;
		}

		ctl = document.getElementsByName("formattedStatementFromDt").item(0);
		result = parseDateFld9(ctl.value, true, true, "Statement From Date",
				true);
		if (result == "NaD") {
			ctl.focus();
			ctl.select();
			return false;
		}

		ctl = document.getElementsByName("formattedStatementToDt").item(0);
		result = parseDateFld9(ctl.value, true, true, "Statement To Date", true);
		if (result == "NaD") {
			ctl.focus();
			ctl.select();
			return false;
		}

		ctl = document.getElementsByName("formattedAdmitDt").item(0);
		if (!isWhitespace(ctl.value)) {
			if (!validateDate(ctl))
				return false;
		}

		ctl = document.getElementsByName("admitHour").item(0);
		if (!isWhitespace(ctl.value)) {
			if (!isNumeric(ctl.value)) {
				alert("Format Time as a numeric (24 Hour Clock)");
				ctl.focus();
				ctl.select();
				return false;
			}
		}

	}

	return true;
}

function billingPrvSaveValidate(claimType) {

	var ctl;
	var tmplt;
	var fldName;
	var val;

	if (claimType == 'I') {
		if (isFldEmpty(document.hpeEncounterForm.billPrvOrgName,
				"Billing Provider Org Name"))
			return false;
	} else if (claimType == 'P') {
		ctl = document.hpeEncounterForm.billPrvEntityType;
		tmplt = document.getElementById("tmpltEntityType");
		if (!CheckSelectBoxValue(ctl, tmplt, "Billing Provider Entity Type"))
			return false;

		val = getSelectedValue(ctl);
		if (val == '1') {
			if (isFldEmpty(document.hpeEncounterForm.billPrvLastName,
					"Billing Provider Last Name"))
				return false;
		} else if (val == '2') {
			if (isFldEmpty(document.hpeEncounterForm.billPrvOrgName,
					"Billing Provider Org Name"))
				return false;
		}
	}

	if (isFldEmpty(document.hpeEncounterForm.billPrvAddrLine1,
			"Billing Provider Address1"))
		return false;

	if (isFldEmpty(document.hpeEncounterForm.billPrvCity,
			"Billing Provider City"))
		return false;

	ctl = document.hpeEncounterForm.billPrvState;
	tmplt = document.getElementById("tmpltState");
	if (!CheckSelectBoxValue(ctl, tmplt, "Billing Provider State"))
		return false;

	if (!checkNoDashZipFormat(document.hpeEncounterForm.billPrvZip,
			"Billing Provider Zip"))
		return false;

	ctl = document.hpeEncounterForm.billPrvNpi;
	fldName = "Billing Provider NPI";
	if (isFldEmpty(ctl, fldName))
		return false;

	ctl = document.hpeEncounterForm.formattedBillPrvAffilTaxId;
	fldName = "Billing Provider Affil. Tax ID";
	if (isFldEmpty(ctl, fldName))
		return false;

	tmplt = document.getElementById("tmpltCommQual");
	ctl = document.hpeEncounterForm.billPrvComNbrQual1;
	if (!noValueSelected(ctl)) {
		if (!CheckSelectBoxValue(ctl, tmplt, "Comm Qual 1"))
			return false;

		if (isFldEmpty(document.hpeEncounterForm.billPrvComNbr1, "Comm Nbr 1")
				|| !isFldNumeric(document.hpeEncounterForm.billPrvComNbr1,
						"Comm Nbr 1"))
			return false;
	}

	if (!isWhitespace(document.hpeEncounterForm.billPrvComNbr1.value)) {

		if (isSelectionEmpty(ctl, "Comm Qual 1"))
			return false;

		tmplt = document.getElementById("tmpltCommQual");
		if (!CheckSelectBoxValue(ctl, tmplt, "Comm Qual 1"))
			return false;

		if (!isFldNumeric(document.hpeEncounterForm.billPrvComNbr1,
				"Comm Nbr 1"))
			return false;
	}

	ctl = document.hpeEncounterForm.billPrvComNbrQual2;
	if (!noValueSelected(ctl)) {
		if (!CheckSelectBoxValue(ctl, tmplt, "Comm Qual 2"))
			return false;

		if (isFldEmpty(document.hpeEncounterForm.billPrvComNbr2, "Comm Nbr 2")
				|| !isFldNumeric(document.hpeEncounterForm.billPrvComNbr2,
						"Comm Nbr 2"))
			return false;
	}

	if (!isWhitespace(document.hpeEncounterForm.billPrvComNbr2.value)) {

		if (isSelectionEmpty(ctl, "Comm Qual 2"))
			return false;

		tmplt = document.getElementById("tmpltCommQual");
		if (!CheckSelectBoxValue(ctl, tmplt, "Comm Qual 2"))
			return false;

		if (!isFldNumeric(document.hpeEncounterForm.billPrvComNbr2,
				"Comm Nbr 2"))
			return false;
	}
	
	ctl = document.hpeEncounterForm.billPrvComNbrQual3;
	if (!noValueSelected(ctl)) {
		if (!CheckSelectBoxValue(ctl, tmplt, "Comm Qual 3"))
			return false;
		if(ctl!=null && 'TE'== ctl.value){	// Check the field only for TE
			if (isFldEmpty(document.hpeEncounterForm.billPrvComNbr3, "Comm Nbr 3")
					|| !isFldNumeric(document.hpeEncounterForm.billPrvComNbr3,
							"Comm Nbr 3"))
				return false;
		}
	}

	if (!isWhitespace(document.hpeEncounterForm.billPrvComNbr3.value)) {

		if (isSelectionEmpty(ctl, "Comm Qual 3"))
			return false;

		tmplt = document.getElementById("tmpltCommQual");
		if (!CheckSelectBoxValue(ctl, tmplt, "Comm Qual 3"))
			return false;
		if(ctl!=null && 'TE'== ctl.value){	// Check the field only for TE
			if (!isFldNumeric(document.hpeEncounterForm.billPrvComNbr3,
					"Comm Nbr 3"))
				return false;
		}
	}

	tmplt = document.getElementById("tmpltState");
	ctl = document.hpeEncounterForm.p2prvState;
	if (!noValueSelected(ctl)) {
		if (!CheckSelectBoxValue(ctl, tmplt, "Pay To Provider State"))
			return false;
	}

	return true;
}

function claimPrvSaveValidate(claimType) {

	var ctl;
	var tmplt;

	ctl = document.hpeEncounterForm.provState;
	if (!noValueSelected(ctl)) {
		tmplt = document.getElementById("tmpltState");
		if (!CheckSelectBoxValue(ctl, tmplt, "Provider State"))
			return false;
	}
	//return true;	//IFOX-00418160 - NPI Provider fields update

	var str, str1, fldName, lastName;
	if (claimType == 'I') {
		if (document.hpeEncounterForm.provEntityType.value != null) {
			str = document.hpeEncounterForm.provEntityType.value;
		}

		// if(document.hpeEncounterForm.provType.value!= null){
		// str1 = document.hpeEncounterForm.provType.value;
		// }
		if (document.hpeEncounterForm.provType.value != null) {
			str1 = document.hpeEncounterForm.provType.value;
		}
		fldName = "Claim Provider Entity Type";
		//IFOX-00418160 - NPI Provider fields update - Start
		if (str1 == 'SVC') {
			if (str != '2') {
				alert(fldName + ' should be Organization');
				document.hpeEncounterForm.provEntityType.focus();
				return false;
			}
		} else {
			if (str != '1') {
				alert(fldName + ' should be Person');
				document.hpeEncounterForm.provEntityType.focus();
				return false;
			}
		}
		//IFOX-00418160 - NPI Provider fields update - End
		lastName = document.hpeEncounterForm.provLastName.value;
		if (lastName != null && lastName != "") {
			if (str.length == 0) {
				alert(fldName + " cannot be blank");
				document.hpeEncounterForm.provEntityType.focus();
				return false;
			} else {
				if (str1 == 'REN') {
					if (str != '1') {
						alert(fldName + ' should be 1');
						document.hpeEncounterForm.provEntityType.focus();
						return false;
					}
				} else if (str1 == 'SVC') {
					if (str != '2') {
						alert(fldName + ' should be 2');
						document.hpeEncounterForm.provEntityType.focus();
						return false;
					}

					if (document.hpeEncounterForm.provAddrLine1.value.length == 0) {
						alert("Claim Provider Address1 cannot be blank");
						document.hpeEncounterForm.provAddrLine1.focus();
						return false;
					}
					if (document.hpeEncounterForm.provCity.value.length == 0) {
						alert("Claim Provider City cannot be blank");
						document.hpeEncounterForm.provCity.focus();
						return false;
					}
					if (document.hpeEncounterForm.provState.value.length == 0) {
						alert("Claim Provider State cannot be blank");
						document.hpeEncounterForm.provState.focus();
						return false;
					}
					if (document.hpeEncounterForm.provZip.value.length == 0) {
						alert("Claim Provider Zip cannot be blank");
						document.hpeEncounterForm.provZip.focus();
						return false;
					}
				}
			}
		} else {
			if (str.length != 0) {
				alert("Claim Provider LastName cannot be blank");
				document.hpeEncounterForm.provLastName.focus();
				return false;
			}
			if (str.length != 0) {
				if (str1 == 'REN') {
					if (str != '1') {
						alert(fldName + ' should be 1');
						document.hpeEncounterForm.provEntityType.focus();
						return false;
					}
				} else if (str1 == 'SVC') {
					if (str != '2') {
						alert(fldName + ' should be 2');
						document.hpeEncounterForm.provEntityType.focus();
						return false;
					}

					if (document.hpeEncounterForm.provAddrLine1.value.length == 0) {
						alert("Claim Provider Address1 cannot be blank");
						document.hpeEncounterForm.provAddrLine1.focus();
						return false;
					}
					if (document.hpeEncounterForm.provCity.value.length == 0) {
						alert("Claim Provider City cannot be blank");
						document.hpeEncounterForm.provCity.focus();
						return false;
					}
					if (document.hpeEncounterForm.provState.value.length == 0) {
						alert("Claim Provider State cannot be blank");
						document.hpeEncounterForm.provState.focus();
						return false;
					}
					if (document.hpeEncounterForm.provZip.value.length == 0) {
						alert("Claim Provider Zip cannot be blank");
						document.hpeEncounterForm.provZip.focus();
						return false;
					}
				}
			}
		}
	} else if (claimType == 'P') {
		if (document.hpeEncounterForm.provEntityType.value != null) {
			str = document.hpeEncounterForm.provEntityType.value;
		}

		// if(document.hpeEncounterForm.provType.value != null){
		// str1 = document.hpeEncounterForm.provType.value;
		// }
		if (document.hpeEncounterForm.provType.value != null) {
			str1 = document.hpeEncounterForm.provType.value;
		}

		fldName = "Claim Provider Entity Type";
		//IFOX-00418160 - NPI Provider fields update - Start
		if (str1 == 'SVC') {
			if (str != '2') {
				alert(fldName + ' should be Organization');
				document.hpeEncounterForm.provEntityType.focus();
				return false;
			}
		} else {
			if (str != '1') {
				alert(fldName + ' should be Person');
				document.hpeEncounterForm.provEntityType.focus();
				return false;
			}
		}
		//IFOX-00418160 - NPI Provider fields update - End
		lastName = document.hpeEncounterForm.provLastName.value;
		if (lastName != null && lastName != "") {
			if (str.length == 0) {
				alert(fldName + " cannot be blank");
				document.hpeEncounterForm.provEntityType.focus();
				return false;
			} else {
				if (str1 == 'REN') {
					if (str != '1' && str != '2') {
						alert(fldName + ' should be either 1/2');
						document.hpeEncounterForm.provEntityType.focus();
						return false;
					}
				} else if (str1 == 'SVC') {
					if (str != '2') {
						alert(fldName + ' should be 2');
						document.hpeEncounterForm.provEntityType.focus();
						return false;
					}

					if (document.hpeEncounterForm.provAddrLine1.value.length == 0) {
						alert("Claim Provider Address1 cannot be blank");
						document.hpeEncounterForm.provAddrLine1.focus();
						return false;
					}
					if (document.hpeEncounterForm.provCity.value.length == 0) {
						alert("Claim Provider City cannot be blank");
						document.hpeEncounterForm.provCity.focus();
						return false;
					}
					if (document.hpeEncounterForm.provState.value.length == 0) {
						alert("Claim Provider State cannot be blank");
						document.hpeEncounterForm.provState.focus();
						return false;
					}
					if (document.hpeEncounterForm.provZip.value.length == 0) {
						alert("Claim Provider Zip cannot be blank");
						document.hpeEncounterForm.provZip.focus();
						return false;
					}
				} else if (str1 == 'REF') {
					if (str != '1') {
						alert(fldName + ' should be 1');
						document.hpeEncounterForm.provEntityType.focus();
						return false;
					}
				}
			}
		} else {
			if (str.length != 0) {
				alert("Claim Provider LastName cannot be blank");
				document.hpeEncounterForm.provLastName.focus();
				return false;
			}
			if (str.length != 0) {
				if (str1 == 'REN') {
					if (str != '1' && str != '2') {
						alert(fldName + ' should be either 1/2');
						document.hpeEncounterForm.provEntityType.focus();
						return false;
					}
				} else if (str1 == 'SVC') {
					if (str != '2') {
						alert(fldName + ' should be 2');
						document.hpeEncounterForm.provEntityType.focus();
						return false;
					}

					if (document.hpeEncounterForm.provAddrLine1.value.length == 0) {
						alert("Claim Provider Address1 cannot be blank");
						document.hpeEncounterForm.provAddrLine1.focus();
						return false;
					}
					if (document.hpeEncounterForm.provCity.value.length == 0) {
						alert("Claim Provider City cannot be blank");
						document.hpeEncounterForm.provCity.focus();
						return false;
					}
					if (document.hpeEncounterForm.provState.value.length == 0) {
						alert("Claim Provider State cannot be blank");
						document.hpeEncounterForm.provState.focus();
						return false;
					}
					if (document.hpeEncounterForm.provZip.value.length == 0) {
						alert("Claim Provider Zip cannot be blank");
						document.hpeEncounterForm.provZip.focus();
						return false;
					}
				} else if (str1 == 'REF') {
					if (str != '1') {
						alert(fldName + ' should be 1');
						document.hpeEncounterForm.provEntityType.focus();
						return false;
					}
				}
			}
		}
	}
	return true;
}

function clmOtherSubsValidate(claimType) {
	var chkRemitDate, miaCoveredDays, miaCostDayCnt, miaLifePsychDay;

	chkRemitDate = document.hpeEncounterForm.formattedCheckRemitDt;
	result = parseDateFld9(chkRemitDate.value, true, true, "Check Remit Date",
			true);
	if (result == "NaD") {
		chkRemitDate.focus();
		chkRemitDate.select();
		return false;
	}
	if (claimType == 'I') {
		miaCoveredDays = document.hpeEncounterForm.miaCoveredDays;
		if (miaCoveredDays.value != null && miaCoveredDays.value != "") {
			if (!isFldNumeric(miaCoveredDays, "Mia Covered Day"))
				return false;
		}

		miaCostDayCnt = document.hpeEncounterForm.miaCostDayCnt;
		if (miaCostDayCnt.value != null && miaCostDayCnt.value != "") {
			if (!isFldNumeric(miaCostDayCnt, "Mia Cost Day Count"))
				return false;
		}

		miaLifePsychDay = document.hpeEncounterForm.miaLifePsychDayCnt;
		if (miaLifePsychDay.value != null && miaLifePsychDay.value != "") {
			if (!isFldNumeric(miaLifePsychDay, "Mia Life Psych Day"))
				return false;
		}
	}
	return true;
}

function clmLineSaveValidate(claimType) {

	var result;

	var liServiceUnitCnt = document.hpeEncounterForm.liServiceUnitCnt;
	if (liServiceUnitCnt.value != null && liServiceUnitCnt.value != "") {
		if (!isFldNumericDecimal(liServiceUnitCnt, "Service Unit Count"))
			return false;
	}

	var liDrugUnitCnt = document.hpeEncounterForm.drugUnitCnt;
	if (liDrugUnitCnt.value != null && liDrugUnitCnt.value != "") {
		if (!isFldNumeric(liDrugUnitCnt, "Drug Unit Count"))
			return false;
	}

	if (claimType == 'I') {
		var liBeginDt = document.hpeEncounterForm.formattedLiBeginDt;
		result = parseDateFld9(liBeginDt.value, true, true,
				"Claim Line Begin Date", true);
		if (result == "NaD") {
			liBeginDt.focus();
			liBeginDt.select();
			return false;
		}

		var liEndDt = document.hpeEncounterForm.formattedLiEndDt;
		result = parseDateFld9(liEndDt.value, true, true,
				"Claim Line End Date", true);
		if (result == "NaD") {
			liEndDt.focus();
			liEndDt.select();
			return false;
		}
	} else if (claimType == 'P') {
		var dmeDuration = document.hpeEncounterForm.dmeDuration;
		if (dmeDuration.value != null && dmeDuration.value != "") {
			if (!isFldNumeric(dmeDuration, "DME Duration"))
				return false;
		}

		var obstetricAddlUnits = document.hpeEncounterForm.obstetricAddlUnits;
		if (obstetricAddlUnits.value != null && obstetricAddlUnits.value != "") {
			if (!isFldNumeric(obstetricAddlUnits, "Obstetric Addl Units"))
				return false;
		}

		var contractPct = document.hpeEncounterForm.formattedContractPct;
		if (contractPct.value != null && contractPct.value != "") {
			if (!isFldNumericDecimal(contractPct, "Contract Pct"))
				return false;
		}

		var contractTermsDiscPct = document.hpeEncounterForm.formattedContractTermsDiscPct;
		if (contractTermsDiscPct.value != null
				&& contractTermsDiscPct.value != "") {
			if (!isFldNumericDecimal(contractTermsDiscPct,
					"Contr Terms Disc PCT"))
				return false;
		}

		var liBeginDt = document.hpeEncounterForm.formattedServiceBeginDt;
		result = parseDateFld9(liBeginDt.value, true, true,
				"Claim Line Service Begin Date", true);
		if (result == "NaD") {
			liBeginDt.focus();
			liBeginDt.select();
			return false;
		}

		var liEndDt = document.hpeEncounterForm.formattedServiceEndDt;
		result = parseDateFld9(liEndDt.value, true, true,
				"Claim Line Service End Date", true);
		if (result == "NaD") {
			liEndDt.focus();
			liEndDt.select();
			return false;
		}

		var liPrescriptionDt = document.hpeEncounterForm.formattedPrescriptionDt;
		result = parseDateFld9(liPrescriptionDt.value, true, true,
				"Claim Line Prescription Date", true);
		if (result == "NaD") {
			liPrescriptionDt.focus();
			liPrescriptionDt.select();
			return false;
		}

		var liRecertificationDt = document.hpeEncounterForm.formattedRecertificationDt;
		result = parseDateFld9(liRecertificationDt.value, true, true,
				"Claim Line Recertification Date", true);
		if (result == "NaD") {
			liRecertificationDt.focus();
			liRecertificationDt.select();
			return false;
		}

		var liBeginTherapyDt = document.hpeEncounterForm.formattedBeginTherapyDt;
		result = parseDateFld9(liBeginTherapyDt.value, true, true,
				"Claim Line Begin Therapy Date", true);
		if (result == "NaD") {
			liBeginTherapyDt.focus();
			liBeginTherapyDt.select();
			return false;
		}

		var liHemoglobinDt = document.hpeEncounterForm.formattedHemoglobinDt;
		result = parseDateFld9(liHemoglobinDt.value, true, true,
				"Claim Line Hemoglobin Date", true);
		if (result == "NaD") {
			liHemoglobinDt.focus();
			liHemoglobinDt.select();
			return false;
		}

		var liSerumCreatineDt = document.hpeEncounterForm.formattedSerumCreatineDt;
		result = parseDateFld9(liSerumCreatineDt.value, true, true,
				"Claim Line Serum Creatine Date", true);
		if (result == "NaD") {
			liSerumCreatineDt.focus();
			liSerumCreatineDt.select();
			return false;
		}

		var liShippedDt = document.hpeEncounterForm.formattedShippedDt;
		result = parseDateFld9(liShippedDt.value, true, true,
				"Claim Line Shipped Date", true);
		if (result == "NaD") {
			liShippedDt.focus();
			liShippedDt.select();
			return false;
		}

		var liLastCertificationDt = document.hpeEncounterForm.formattedLastCertificationDt;
		result = parseDateFld9(liLastCertificationDt.value, true, true,
				"Claim Line Last Certification Date", true);
		if (result == "NaD") {
			liLastCertificationDt.focus();
			liLastCertificationDt.select();
			return false;
		}

		var liTreatmentTherapyDt = document.hpeEncounterForm.formattedTreatmentTherapyDt;
		result = parseDateFld9(liTreatmentTherapyDt.value, true, true,
				"Claim Line Treatment Therapy Date", true);
		if (result == "NaD") {
			liTreatmentTherapyDt.focus();
			liTreatmentTherapyDt.select();
			return false;
		}

		var lastXrayDt = document.hpeEncounterForm.lastXrayDt;
		result = parseDateFld9(lastXrayDt.value, true, true,
				"Claim Line Last Xray Date", true);
		if (result == "NaD") {
			lastXrayDt.focus();
			lastXrayDt.select();
			return false;
		}

		var initialTreatmentDt = document.hpeEncounterForm.initialTreatmentDt;
		result = parseDateFld9(initialTreatmentDt.value, true, true,
				"Claim Line Initial Treatment Date", true);
		if (result == "NaD") {
			initialTreatmentDt.focus();
			initialTreatmentDt.select();
			return false;
		}

		liServiceUnitCnt = document.hpeEncounterForm.reprcdSvcUnitCnt;
		if (liServiceUnitCnt.value != null && liServiceUnitCnt.value != "") {
			if (!isFldNumericDecimal(liServiceUnitCnt,
					"Reprcd Service Unit Count"))
				return false;
		}

		var ambPatientWeight = document.hpeEncounterForm.ambPatientWeight;
		if (ambPatientWeight.value != null && ambPatientWeight.value != "") {
			if (!isFldNumeric(ambPatientWeight, "Amb Patient Weight"))
				return false;
		}

		var ambTransportDistance = document.hpeEncounterForm.ambTransportDistance;
		if (ambTransportDistance.value != null
				&& ambTransportDistance.value != "") {
			if (!isFldNumeric(ambTransportDistance, "Amb Transport Distance"))
				return false;
		}
	}

	return true;
}

function clmLineAdjudSaveValidate(claimType) {

	var bundleNbr, adjudPaymentDt;

	adjudPaymentDt = document.hpeEncounterForm.formattedAdjudPaymentDt;
	result = parseDateFld9(adjudPaymentDt.value, true, true,
			"Claim Line Adjud Payment Date", true);
	if (result == "NaD") {
		adjudPaymentDt.focus();
		adjudPaymentDt.select();
		return false;
	}

	bundleNbr = document.hpeEncounterForm.clmliBundledLineNbr;
	if (bundleNbr.value != null && bundleNbr.value != "") {
		if (!isFldNumeric(bundleNbr, "Claim Bundle Line Nbr"))
			return false;
	}

	return true;
}

/*
 * function claimSave(claimType) {
 * 
 * if (!claimSaveValidate(claimType)) return;
 * 
 * document.body.className = 'wait';
 * 
 * document.hpeEncounterForm.menu.value = 'Dashboard';
 * document.hpeEncounterForm.method.value = 'dashDetailClmSave';
 * 
 * if(document.hpeEncounterForm.selectedClaimType.value == "" &&
 * document.hpeEncounterForm.selectedClaimRefNbr.value == "" &&
 * document.hpeEncounterForm.selectedClaimRevNbr.value == "" &&
 * document.hpeEncounterForm.selectedClaimSeqNbr.value == "") {
 * document.hpeEncounterForm.selectedClaimType.value =
 * document.hpeEncounterForm.firstClaimType.value;
 * document.hpeEncounterForm.selectedClaimRefNbr.value =
 * document.hpeEncounterForm.firstClaimRefNbr.value;
 * document.hpeEncounterForm.selectedClaimRevNbr.value =
 * document.hpeEncounterForm.firstClaimRevNbr.value;
 * document.hpeEncounterForm.selectedClaimSeqNbr.value =
 * document.hpeEncounterForm.firstClaimSeqNbr.value; }
 * 
 * document.hpeEncounterForm.submit(); }
 */

function claimCancel(claimType) {
	doSelect(document.getElementsByName("processStatus").item(0), document
			.getElementsByName("processStatusOriginal").item(0).value);

	if (claimType == 'P') {
		doSelect(document.getElementsByName("placeOfService").item(0), document
				.getElementsByName("placeOfServiceOriginal").item(0).value);

		document.getElementsByName("mammogramCertNbr").item(0).value = document
				.getElementsByName("mammogramCertNbrOriginal").item(0).value;
		document.getElementsByName("cliaNbr").item(0).value = document
				.getElementsByName("cliaNbrOriginal").item(0).value;

		document.getElementsByName("formattedHospAdmitDt").item(0).value = document
				.getElementsByName("formattedHospAdmitDtOriginal").item(0).value;
		document.getElementsByName("formattedHospDischargeDt").item(0).value = document
				.getElementsByName("formattedHospDischargeDtOriginal").item(0).value;

		document.getElementsByName("ambPickupAddrLine1").item(0).value = document
				.getElementsByName("ambPickupAddrLine1Original").item(0).value;
		document.getElementsByName("ambPickupAddrLine2").item(0).value = document
				.getElementsByName("ambPickupAddrLine2Original").item(0).value;
		document.getElementsByName("ambPickupCity").item(0).value = document
				.getElementsByName("ambPickupCityOriginal").item(0).value;
		doSelect(document.getElementsByName("ambPickupState").item(0), document
				.getElementsByName("ambPickupStateOriginal").item(0).value);
		document.getElementsByName("ambPickupZip").item(0).value = document
				.getElementsByName("ambPickupZipOriginal").item(0).value;

		document.getElementsByName("ambDropoffLoc").item(0).value = document
				.getElementsByName("ambDropoffLocOriginal").item(0).value;
		document.getElementsByName("ambDropoffAddrLine1").item(0).value = document
				.getElementsByName("ambDropoffAddrLine1Original").item(0).value;
		document.getElementsByName("ambDropoffAddrLine2").item(0).value = document
				.getElementsByName("ambDropoffAddrLine2Original").item(0).value;
		document.getElementsByName("ambDropoffCity").item(0).value = document
				.getElementsByName("ambDropoffCityOriginal").item(0).value;
		doSelect(
				document.getElementsByName("ambDropoffState").item(0),
				document.getElementsByName("ambDropoffStateOriginal").item(0).value);
		document.getElementsByName("ambDropoffZip").item(0).value = document
				.getElementsByName("ambDropoffZipOriginal").item(0).value;
	} else {
		document.getElementsByName("clmFacTypeCd").item(0).value = document
				.getElementsByName("clmFacTypeCdOriginal").item(0).value;
		document.getElementsByName("admitSourceCd").item(0).value = document
				.getElementsByName("admitSourceCdOriginal").item(0).value;
		document.getElementsByName("admitType").item(0).value = document
				.getElementsByName("admitTypeOriginal").item(0).value;
		document.getElementsByName("patientStatusCd").item(0).value = document
				.getElementsByName("patientStatusCdOriginal").item(0).value;
		document.getElementsByName("formattedAdmitDt").item(0).value = document
				.getElementsByName("formattedAdmitDtOriginal").item(0).value;
		document.getElementsByName("admitHour").item(0).value = document
				.getElementsByName("admitHourOriginal").item(0).value;
		document.getElementsByName("ambPickupZip").item(0).value = document
				.getElementsByName("ambPickupZipOriginal").item(0).value;
	}

	showClaimDisplay(claimType);
}

function showClaimDisplay(claimType) {
	var ctl;
	ctl = document.getElementById('claimEntry');
	ctl.style.display = "none";

	ctl = document.getElementById('claimDisplay');
	ctl.style.display = "";

	ctl = document.getElementById('claimEntry2');
	ctl.style.display = "none";

	ctl = document.getElementById('claimDisplay2');
	ctl.style.display = "";

	ctl = document.getElementById('claimEntry3');
	ctl.style.display = "none";
	ctl = document.getElementById('claimDisplay3');
	ctl.style.display = "";

	ctl = document.getElementById('claimEntry4');
	ctl.style.display = "none";

	ctl = document.getElementById('claimDisplay4');
	ctl.style.display = "";

	ctl = document.getElementById('claimEntry7');
	ctl.style.display = "none";

	ctl = document.getElementById('claimDisplay7');
	ctl.style.display = "";

	if (claimType == "P") {
		ctl = document.getElementById('claimEntry9');
		ctl.style.display = "none";

		ctl = document.getElementById('claimDisplay9');
		ctl.style.display = "";
	}

	ctl = document.getElementById('claimChanged');
	ctl.value = "false";

	ctl = document.getElementById('claimDisplayState');
	ctl.value = "VIEW";
}

function showClaimEntry(claimType) {
	var ctl;
	ctl = document.getElementById('claimDisplay');
	ctl.style.display = "none";

	ctl = document.getElementById('claimEntry');
	ctl.style.display = "";

	ctl = document.getElementById('claimDisplay2');
	ctl.style.display = "none";

	ctl = document.getElementById('claimEntry2');
	ctl.style.display = "";

	ctl = document.getElementById('claimDisplay3');
	ctl.style.display = "none";

	ctl = document.getElementById('claimEntry3');
	ctl.style.display = "";

	ctl = document.getElementById('claimDisplay4');
	ctl.style.display = "none";

	ctl = document.getElementById('claimEntry4');
	ctl.style.display = "";

	ctl = document.getElementById('claimDisplay7');
	ctl.style.display = "none";

	ctl = document.getElementById('claimEntry7');
	ctl.style.display = "";

	if (claimType == "P") {
		ctl = document.getElementById('claimDisplay9');
		ctl.style.display = "none";

		ctl = document.getElementById('claimEntry9');
		ctl.style.display = "";
	}

	ctl = document.getElementById('claimDisplayState');
	ctl.value = "EDIT";
}

function showClaimCodesEntry(claimType) {
	var ctl;

	ctl = document.getElementById('clmCondDisplay');
	ctl.style.display = "none";

	ctl = document.getElementById('clmCondEntry');
	ctl.style.display = "";

	ctl = document.getElementById('clmDiagDisplay');
	ctl.style.display = "none";

	ctl = document.getElementById('clmDiagEntry');
	ctl.style.display = "";
	
	if (claimType == "I") {
		
	ctl = document.getElementById('clmProcDisplay');
	ctl.style.display = "none";

	ctl = document.getElementById('clmProcEntry');
	ctl.style.display = "";

	ctl = document.getElementById('clmOccDisplay');
	ctl.style.display = "none";

	ctl = document.getElementById('clmOccEntry');
	ctl.style.display = "";

	ctl = document.getElementById('clmValDisplay');
	ctl.style.display = "none";

	ctl = document.getElementById('clmValEntry');
	ctl.style.display = "";

	
	ctl = document.getElementById('clmOccurDisplay');
	ctl.style.display = "none";

	ctl = document.getElementById('clmOccurEntry');
	ctl.style.display = "";
	
	ctl = document.getElementById('clmTreatDisplay');
	ctl.style.display = "none";

	ctl = document.getElementById('clmTreatEntry');
	ctl.style.display = "";
	ctl = document.getElementById('clmInjDisplay');
	ctl.style.display = "none";

	ctl = document.getElementById('clmInjEntry');
	ctl.style.display = "";
	}

	ctl = document.getElementById('claimDisplayState');
	ctl.value = "EDIT";
}


function showClaimCodesDisplay(claimType) {
	var ctl;
	ctl = document.getElementById('clmCondDisplay');
	ctl.style.display = "";

	ctl = document.getElementById('clmCondEntry');
	ctl.style.display = "none";

	ctl = document.getElementById('clmDiagDisplay');
	ctl.style.display = "";

	ctl = document.getElementById('clmDiagEntry');
	ctl.style.display = "none";

	if (claimType == "I") {
		
		ctl = document.getElementById('clmProcDisplay');
		ctl.style.display = "";

		ctl = document.getElementById('clmProcEntry');
		ctl.style.display = "none";

		ctl = document.getElementById('clmOccDisplay');
		ctl.style.display = "";

		ctl = document.getElementById('clmOccEntry');
		ctl.style.display = "none";

		ctl = document.getElementById('clmValDisplay');
		ctl.style.display = "";

		ctl = document.getElementById('clmValEntry');
		ctl.style.display = "none";

		
		ctl = document.getElementById('clmOccurDisplay');
		ctl.style.display = "";

		ctl = document.getElementById('clmOccurEntry');
		ctl.style.display = "none";
		
		ctl = document.getElementById('clmTreatDisplay');
		ctl.style.display = "";

		ctl = document.getElementById('clmTreatEntry');
		ctl.style.display = "none";
		ctl = document.getElementById('clmInjDisplay');
		ctl.style.display = "";

		ctl = document.getElementById('clmInjEntry');
		ctl.style.display = "none";
		}


	ctl = document.getElementById('claimDisplayState');
	ctl.value = "VIEW";
}


hpeLogWin = null;
function subscriberLog() {
	// referencing the top most parent window
	var ww = 997;
	var wh = 550;
	var wt = 1;
	var wl = ((screen.width - 10) - ww) / 2;
	hpeLogWin = window
			.open(
					"/hpeAction.do?method=logDetail",
					"LogDetailWindow",
					"toolbar=no,titlebar=0,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=no,ControlBox=no,width="
							+ ww
							+ ",height="
							+ wh
							+ ",left="
							+ wl
							+ ",top="
							+ wt);
	hpeLogWin.focus();
}

function closeAllPopups() {
	if (hpeLogWin != null)
		hpeLogWin.close();
}

function showClaimPrvEntry(claimType) {
	var provType;
	var ctl;

	//if (document.getElementById('provTypeDisp') != null)	//IFOX-00418160 - NPI Provider fields update
		provType = document.getElementById('provType').value;

	if (claimType == 'I') {
		setVisibility('instClaimProvExpanded', 'instClaimProvDiv',
				'instClaimProvImgToggle', true);
		setVisibility('instClaimProvDetailExpanded', 'instClaimProvDetailDiv',
				'img3', true);
	} else if (claimType == 'P') {
		setVisibility('profClaimProvExpanded', 'profClaimProvDiv',
				'profClaimProvImgToggle', true);
		setVisibility('profClaimProvDetailExpanded', 'profClaimProvDetailDiv',
				'img3', true);
	}
	// added ATT, OTH, OPE for 00362915 to make it updateble for Attending
	// provider, Other operating physcian , Other operating physician

	if ((provType == 'REN') || (provType == 'REF') || (provType == 'SVC')
			|| (provType == 'ATT') || (provType == 'OTH')
			|| (provType == 'OPE') || (provType == 'SUP')) {	//IFOX-00418160 - NPI Provider fields update
		ctl = document.getElementById('clmPrvDisplay');
		ctl.style.display = "none";

		ctl = document.getElementById('clmPrvEntry');
		ctl.style.display = "";

		ctl = document.getElementById('clmProviderDisplayState');
		ctl.value = "EDIT";

	} else {
		showClaimPrvDisplay();
	}
}

function showClaimPrvDisplay() {
	var ctl;
	ctl = document.getElementById('clmPrvEntry');
	ctl.style.display = "none";

	ctl = document.getElementById('clmPrvDisplay');
	ctl.style.display = "";

	ctl = document.getElementById('clmPrvChanged');
	ctl.value = "false";

	ctl = document.getElementById('clmProviderDisplayState');
	ctl.value = "VIEW";
}

function showBillPrvEntry() {
	var ctl;
	ctl = document.getElementById('prvDisplay');
	ctl.style.display = "none";

	ctl = document.getElementById('prvEntry');
	ctl.style.display = "";

	ctl = document.getElementById('providerDisplayState');
	ctl.value = "EDIT";
}

function showBillPrvDisplay() {
	var ctl;
	ctl = document.getElementById('prvEntry');
	ctl.style.display = "none";

	ctl = document.getElementById('prvDisplay');
	ctl.style.display = "";

	ctl = document.getElementById('providerChanged');
	ctl.value = "false";

	ctl = document.getElementById('providerDisplayState');
	ctl.value = "VIEW";
}

function showClmLineEntry(claimType) {
	var ctl;
	if (claimType == 'I') {
		setVisibility('instClaimLineExpanded', 'instClaimLineDiv',
				'instClmLineImgToggle', true);
		setVisibility('instClaimLineDetailExpanded', 'instClaimLineDetailDiv',
				'img6', true);
	} else if (claimType == 'P') {
		setVisibility('profClaimLineExpanded', 'profClaimLineDiv',
				'profClmLineImgToggle', true);
		setVisibility('profClaimLineDetailExpanded', 'profClaimLineDetailDiv',
				'img6', true);
	}

	ctl = document.getElementById('clmLineDisplay');
	ctl.style.display = "none";

	ctl = document.getElementById('clmLineEntry');
	ctl.style.display = "";
}

//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
function showClmLineAdjudAdjustEntry(claimType) {
	var ctl;
	var ctl1;
	var ctl2;
	if (claimType == 'I') {
		ctl = document.getElementById('clmLineAdjudEntryDisplay');
		ctl1 = document.getElementById('instLineAdjustmentTableDivEntry');
		ctl2 = document.getElementById('instLineAdjustmentTableDivDisp');
	}else if(claimType == 'P' || claimType == 'E'){
		ctl = document.getElementById('clmLineAdjudEntryDisplay');
		ctl1 = document.getElementById('profLineAdjustmentTableDivEntry');
		ctl2 = document.getElementById('profLineAdjustmentTableDivDisp');
	}
	ctl.style.display = "";
	ctl1.style.display = "";
	ctl2.style.display = "none";
}
//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End

function showClmOtherSubsEntry(claimType) {
	var ctl;
	if (claimType == 'I') {
		setVisibility('instClaimOtherSubsExpanded', 'instClaimOtherSubsDiv',
				'instClaimOtherSubsImgToggle', true);
		setVisibility('instClaimOtherSubsDetailExpanded',
				'instClaimOtherSubsDetailDiv', 'img8', true);
	} else if (claimType == 'P') {
		setVisibility('profClaimOtherSubsExpanded', 'profClaimOtherSubsDiv',
				'profClaimOtherSubsImgToggle', true);
		setVisibility('profClaimOtherSubsDetailExpanded',
				'profClaimOtherSubsDetailDiv', 'img8', true);
	}

	ctl = document.getElementById('clmOtherSubsDisplay');
	ctl.style.display = "none";

	ctl = document.getElementById('clmOtherSubsEntry');
	ctl.style.display = "";
}

function showClmOtherSubsProvEntry(claimType) {
	var ctl;
	if (claimType == 'I') {
		setVisibility('instClaimOtherSubsProvExpanded',
				'instClaimOtherSubsProvDiv', 'instClaimOtherSubsProvImgToggle',
				true);
		setVisibility('instClaimOtherSubsProvDetailExpanded',
				'instClaimOtherSubsProvDetailDiv', 'img9', true);
	} else if (claimType == 'P') {
		setVisibility('profClaimOtherSubsProvExpanded',
				'profClaimOtherSubsProvDiv', 'profClaimOtherSubsProvImgToggle',
				true);
		setVisibility('profClaimOtherSubsProvDetailExpanded',
				'profClaimOtherSubsProvDetailDiv', 'img9', true);
	}

	ctl = document.getElementById('clmOtherSubsProvDisplay');
	ctl.style.display = "none";

	ctl = document.getElementById('clmOtherSubsProvEntry');
	ctl.style.display = "";
}

function showClmLineProvEntry(claimType) {
	var ctl;
	if (claimType == 'I') {
		setVisibility('instClaimLineProvExpanded', 'instClaimLineProvDiv',
				'instClmLineProvImgToggle', true);
		setVisibility('instClaimLineProvDetailExpanded',
				'instClaimLineProvDetailDiv', 'img7', true);
	} else if (claimType == 'P') {
		setVisibility('profClaimLineProvExpanded', 'profClaimLineProvDiv',
				'profClmLineProvImgToggle', true);
		setVisibility('profClaimLineProvDetailExpanded',
				'profClaimLineProvDetailDiv', 'img7', true);
	}

	ctl = document.getElementById('clmLineProvDisplay');
	ctl.style.display = "none";

	ctl = document.getElementById('clmLineProvEntry');
	ctl.style.display = "";
}

function showClmLineAjudEntry(claimType) {
	var ctl;
	if (claimType == 'I') {
		setVisibility('instClaimLineAdjudExpanded', 'instClaimLineAdjudDiv',
				'instClmLineAdjudImgToggle', true);
		setVisibility('instClaimLineAdjudDetailExpanded',
				'instClaimLineAdjudDetailDiv', 'img5', true);
	} else if (claimType == 'P') {
		setVisibility('profClaimLineAdjudExpanded', 'profClaimLineAdjudDiv',
				'profClmLineAdjudImgToggle', true);
		setVisibility('profClaimLineAdjudDetailExpanded',
				'profClaimLineAdjudDetailDiv', 'img5', true);
	}

	ctl = document.getElementById('adjudDisplay');
	ctl.style.display = "none";

	ctl = document.getElementById('adjudEntry');
	ctl.style.display = "";
}

function showClmOtherSubsProvDisplay() {
	var ctl;
	ctl = document.getElementById('clmOtherSubsProvEntry');
	ctl.style.display = "none";

	ctl = document.getElementById('clmOtherSubsProvDisplay');
	ctl.style.display = "";

	ctl = document.getElementById('claimOtherSubsProvChanged');
	ctl.value = "false";
}

function showClmOtherSubsDisplay() {
	var ctl;
	ctl = document.getElementById('clmOtherSubsEntry');
	ctl.style.display = "none";

	ctl = document.getElementById('clmOtherSubsDisplay');
	ctl.style.display = "";

	ctl = document.getElementById('claimOtherSubsChanged');
	ctl.value = "false";
}

function showClmLineDisplay() {
	var ctl;
	ctl = document.getElementById('clmLineEntry');
	ctl.style.display = "none";

	ctl = document.getElementById('clmLineDisplay');
	ctl.style.display = "";

	ctl = document.getElementById('clmLineChanged');
	ctl.value = "false";
}

function showClmLineAdjudDisplay() {
	var ctl;
	ctl = document.getElementById('adjudEntry');
	ctl.style.display = "none";

	ctl = document.getElementById('adjudDisplay');
	ctl.style.display = "";

	ctl = document.getElementById('adjudChanged');
	ctl.value = "false";
}

function showClmPrvDisplay() {
	var ctl;
	ctl = document.getElementById('clmPrvEntry');
	ctl.style.display = "none";

	ctl = document.getElementById('clmPrvDisplay');
	ctl.style.display = "";

	ctl = document.getElementById('clmPrvChanged');
	ctl.value = "false";

	ctl = document.getElementById('clmProviderDisplayState');
	ctl.value = "VIEW";
}

function showClmPrvCancel() {
	var ctl;
	ctl = document.getElementById('clmPrvEntry');
	ctl.style.display = "none";

	ctl = document.getElementById('clmPrvDisplay');
	ctl.style.display = "";

	ctl = document.getElementById('clmPrvChanged');
	ctl.value = "false";

	ctl = document.getElementById('clmProviderDisplayState');
	ctl.value = "Cancel";
}

function showClmLinePrvCancel() {
	var ctl;
	ctl = document.getElementById('clmLineProvEntry');
	ctl.style.display = "none";

	ctl = document.getElementById('clmLineProvDisplay');
	ctl.style.display = "";

	ctl = document.getElementById('clmLineProvChanged');
	ctl.value = "false";
}

function claimPrvCancel(claimType) {
	document.getElementsByName("provFirstName").item(0).value = document
			.getElementsByName("provFirstNameOriginal").item(0).value;
	document.getElementsByName("provMiddleName").item(0).value = document
			.getElementsByName("provMiddleNameOriginal").item(0).value;
	document.getElementsByName("provLastName").item(0).value = document
			.getElementsByName("provLastNameOriginal").item(0).value;
	document.getElementsByName("provEntityType").item(0).value = document
			.getElementsByName("provEntityTypeOriginal").item(0).value;
	document.getElementsByName("provAddrLine1").item(0).value = document
			.getElementsByName("provAddrLine1Original").item(0).value;
	document.getElementsByName("provAddrLine2").item(0).value = document
			.getElementsByName("provAddrLine2Original").item(0).value;
	document.getElementsByName("provCity").item(0).value = document
			.getElementsByName("provCityOriginal").item(0).value;
	doSelect(document.getElementsByName("provState").item(0), document
			.getElementsByName("provStateOriginal").item(0).value);
	document.getElementsByName("provZip").item(0).value = document
			.getElementsByName("provZipOriginal").item(0).value;
	document.getElementsByName("provTaxonomyCd").item(0).value = document
			.getElementsByName("provTaxonomyCdOriginal").item(0).value;//IFOX-00406065
	document.getElementsByName("provNpi").item(0).value = document
			.getElementsByName("provNpiOriginal").item(0).value;

	showClmPrvCancel();

}

function clmLinePrvCancel(claimType) {
	document.getElementsByName("liProvFirstName").item(0).value = document
			.getElementsByName("liProvFirstNameOriginal").item(0).value;
	document.getElementsByName("liProvMiddleName").item(0).value = document
			.getElementsByName("liProvMiddleNameOriginal").item(0).value;
	document.getElementsByName("liProvLastName").item(0).value = document
			.getElementsByName("liProvLastNameOriginal").item(0).value;
	document.getElementsByName("provLicNbr").item(0).value = document
			.getElementsByName("liProvLicNbrOriginal").item(0).value;
	document.getElementsByName("provNpi").item(0).value = document
			.getElementsByName("liProvNpiOriginal").item(0).value;
	document.getElementsByName("provUpin").item(0).value = document
			.getElementsByName("liProvUpinOriginal").item(0).value;
	document.getElementsByName("provCommNbr").item(0).value = document
			.getElementsByName("liProvCommNbrOriginal").item(0).value;
	document.getElementsByName("provOthPayerId").item(0).value = document
			.getElementsByName("liProvOthPayerIdOriginal").item(0).value;
	document.getElementsByName("provLocNbr").item(0).value = document
			.getElementsByName("liProvLocNbrOriginal").item(0).value;
	document.getElementsByName("provEntityType").item(0).value = document
			.getElementsByName("liProvEntityTypeOriginal").item(0).value;
	if (claimType == 'P') {
		document.getElementsByName("liProvAddrLine1").item(0).value = document
				.getElementsByName("liProvAddrLine1Original").item(0).value;
		document.getElementsByName("liProvAddrLine2").item(0).value = document
				.getElementsByName("liProvAddrLine2Original").item(0).value;
		document.getElementsByName("liProvTaxonomyCd").item(0).value = document
				.getElementsByName("liProvTaxonomyCdOriginal").item(0).value;
		document.getElementsByName("liProvCity").item(0).value = document
				.getElementsByName("liProvCityOriginal").item(0).value;
		document.getElementsByName("liProvState").item(0).value = document
				.getElementsByName("liProvStateOriginal").item(0).value;
		document.getElementsByName("liProvZip").item(0).value = document
				.getElementsByName("liProvZipOriginal").item(0).value;
		document.getElementsByName("liProvCountry").item(0).value = document
				.getElementsByName("liProvCountryOriginal").item(0).value;
		document.getElementsByName("liProvCntrySubd").item(0).value = document
				.getElementsByName("liProvCntrySubdOriginal").item(0).value;
	}
	showClmLinePrvCancel();
}

function billPrvCancel(claimType) {

	var ctl;

	if (claimType == 'I') {
		document.getElementsByName("billPrvOrgName").item(0).value = document
				.getElementsByName("billPrvOrgNameOriginal").item(0).value;
		document.getElementsByName("billPrvAddrLine1").item(0).value = document
				.getElementsByName("billPrvAddrLine1Original").item(0).value;
		document.getElementsByName("billPrvTaxonomyCd").item(0).value = document
				.getElementsByName("billPrvTaxonomyCdOriginal").item(0).value;
		document.getElementsByName("billPrvNpi").item(0).value = document
				.getElementsByName("billPrvNpiOriginal").item(0).value;
		document.getElementsByName("billPrvAddrLine2").item(0).value = document
				.getElementsByName("billPrvAddrLine2Original").item(0).value;
		document.getElementsByName("formattedBillPrvAffilTaxId").item(0).value = document
				.getElementsByName("formattedBillPrvAffilTaxIdOriginal")
				.item(0).value;
		document.getElementsByName("billPrvCity").item(0).value = document
				.getElementsByName("billPrvCityOriginal").item(0).value;
		doSelect(document.getElementsByName("billPrvState").item(0), document
				.getElementsByName("billPrvStateOriginal").item(0).value);
		document.getElementsByName("billPrvZip").item(0).value = document
				.getElementsByName("billPrvZipOriginal").item(0).value;
		doSelect(document.getElementsByName("billPrvComNbrQual1").item(0),
				document.getElementsByName("billPrvComNbrQual1Original")
						.item(0).value);
		document.getElementsByName("billPrvComNbr1").item(0).value = document
				.getElementsByName("billPrvComNbr1Original").item(0).value;
		doSelect(document.getElementsByName("billPrvComNbrQual2").item(0),
				document.getElementsByName("billPrvComNbrQual2Original")
						.item(0).value);
		document.getElementsByName("billPrvComNbr2").item(0).value = document
				.getElementsByName("billPrvComNbr2Original").item(0).value;
		doSelect(document.getElementsByName("billPrvComNbrQual3").item(0),
				document.getElementsByName("billPrvComNbrQual3Original")
						.item(0).value);
		document.getElementsByName("billPrvComNbr3").item(0).value = document
				.getElementsByName("billPrvComNbr3Original").item(0).value;
		document.getElementsByName("p2prvAddrLine1").item(0).value = document
				.getElementsByName("p2prvAddrLine1Original").item(0).value;
		document.getElementsByName("p2prvAddrLine2").item(0).value = document
				.getElementsByName("p2prvAddrLine2Original").item(0).value;
		document.getElementsByName("p2prvCity").item(0).value = document
				.getElementsByName("p2prvCityOriginal").item(0).value;
		doSelect(document.getElementsByName("p2prvState").item(0), document
				.getElementsByName("p2prvStateOriginal").item(0).value);
		document.getElementsByName("p2prvZip").item(0).value = document
				.getElementsByName("p2prvZipOriginal").item(0).value;
	}
	if (claimType == 'P') {
		document.getElementsByName("billPrvFirstName").item(0).value = document
				.getElementsByName("billPrvFirstNameOriginal").item(0).value;
		document.getElementsByName("billPrvMiddleName").item(0).value = document
				.getElementsByName("billPrvMiddleNameOriginal").item(0).value;
		document.getElementsByName("billPrvLastName").item(0).value = document
				.getElementsByName("billPrvLastNameOriginal").item(0).value;
		document.getElementsByName("billPrvOrgName").item(0).value = document
				.getElementsByName("billPrvOrgNameOriginal").item(0).value;
		document.getElementsByName("billPrvAddrLine1").item(0).value = document
				.getElementsByName("billPrvAddrLine1Original").item(0).value;
		document.getElementsByName("billPrvTaxonomyCd").item(0).value = document
				.getElementsByName("billPrvTaxonomyCdOriginal").item(0).value;
		document.getElementsByName("billPrvLicNbr").item(0).value = document
				.getElementsByName("billPrvLicNbrOriginal").item(0).value;
		document.getElementsByName("billPrvUpin").item(0).value = document
				.getElementsByName("billPrvUpinOriginal").item(0).value;
		document.getElementsByName("formattedBillPrvSsn").item(0).value = document
				.getElementsByName("formattedBillPrvSsnOriginal").item(0).value;
		document.getElementsByName("billPrvNpi").item(0).value = document
				.getElementsByName("billPrvNpiOriginal").item(0).value;
		ctl = document.getElementsByName("billPrvEntityTypeOriginal").item(0);
		doSelect(document.getElementsByName("billPrvEntityType").item(0),
				ctl.value);
		BillPrvEntyTypeFieldSet(ctl.value);
		document.getElementsByName("billPrvAddrLine2").item(0).value = document
				.getElementsByName("billPrvAddrLine2Original").item(0).value;
		document.getElementsByName("formattedBillPrvAffilTaxId").item(0).value = document
				.getElementsByName("formattedBillPrvAffilTaxIdOriginal")
				.item(0).value;
		document.getElementsByName("billPrvCity").item(0).value = document
				.getElementsByName("billPrvCityOriginal").item(0).value;
		document.getElementsByName("billPrvState").item(0).value = document
				.getElementsByName("billPrvStateOriginal").item(0).value;
		document.getElementsByName("billPrvZip").item(0).value = document
				.getElementsByName("billPrvZipOriginal").item(0).value;
		doSelect(document.getElementsByName("billPrvComNbrQual1").item(0),
				document.getElementsByName("billPrvComNbrQual1Original")
						.item(0).value);
		document.getElementsByName("billPrvComNbr1").item(0).value = document
				.getElementsByName("billPrvComNbr1Original").item(0).value;
		doSelect(document.getElementsByName("billPrvComNbrQual2").item(0),
				document.getElementsByName("billPrvComNbrQual2Original")
						.item(0).value);
		document.getElementsByName("billPrvComNbr2").item(0).value = document
				.getElementsByName("billPrvComNbr2Original").item(0).value;
		doSelect(document.getElementsByName("billPrvComNbrQual3").item(0),
				document.getElementsByName("billPrvComNbrQual3Original")
						.item(0).value);
		document.getElementsByName("billPrvComNbr3").item(0).value = document
				.getElementsByName("billPrvComNbr3Original").item(0).value;
		document.getElementsByName("p2prvAddrLine1").item(0).value = document
				.getElementsByName("p2prvAddrLine1Original").item(0).value;
		document.getElementsByName("p2prvAddrLine2").item(0).value = document
				.getElementsByName("p2prvAddrLine2Original").item(0).value;
		document.getElementsByName("p2prvEntityType").item(0).value = document
				.getElementsByName("p2prvEntityTypeOriginal").item(0).value;
		document.getElementsByName("p2prvCity").item(0).value = document
				.getElementsByName("p2prvCityOriginal").item(0).value;
		doSelect(document.getElementsByName("p2prvState").item(0), document
				.getElementsByName("p2prvStateOriginal").item(0).value);
		document.getElementsByName("p2prvZip").item(0).value = document
				.getElementsByName("p2prvZipOriginal").item(0).value;

	}
	showBillPrvDisplay();

}

function clmOtherSubsProvCancel(claimType) {

	document.getElementsByName("othPayrProvLocNbr").item(0).value = document
			.getElementsByName("othPayrProvLocNbrOriginal").item(0).value;
	document.getElementsByName("othPayrProvLicNbr").item(0).value = document
			.getElementsByName("othPayrProvLicNbrOriginal").item(0).value;
	document.getElementsByName("othPayrProvUpin").item(0).value = document
			.getElementsByName("othPayrProvUpinOriginal").item(0).value;
	document.getElementsByName("othPayrProvCommNbr").item(0).value = document
			.getElementsByName("othPayrProvCommNbrOriginal").item(0).value;
	if (claimType == 'P') {
		document.getElementsByName("othPayrProvEntityType").item(0).value = document
				.getElementsByName("othPayrProvEntityTypeOriginal").item(0).value;
	}
	showClmOtherSubsProvDisplay();
}

function clmOtherSubsCancel(claimType) {

	document.getElementsByName("insuredGrpOrPolNbr").item(0).value = document
			.getElementsByName("insuredGrpOrPolNbrOriginal").item(0).value;
	document.getElementsByName("benefitsAsgnCertInd").item(0).value = document
			.getElementsByName("benefitsAsgnCertIndOriginal").item(0).value;
	document.getElementsByName("formattedCheckRemitDt").item(0).value = document
			.getElementsByName("formattedCheckRemitDtOriginal").item(0).value;
	document.getElementsByName("releaseMedRcdFlg").item(0).value = document
			.getElementsByName("releaseMedRcdFlgOriginal").item(0).value;
	document.getElementsByName("indivRelationshipCd").item(0).value = document
			.getElementsByName("indivRelationshipCdOriginal").item(0).value;
	document.getElementsByName("otherClmFilingInd").item(0).value = document
			.getElementsByName("otherClmFilingIndOriginal").item(0).value;
	document.getElementsByName("othPayrOrgName").item(0).value = document
			.getElementsByName("othPayrOrgNameOriginal").item(0).value;
	document.getElementsByName("othSubsPayrPayerId").item(0).value = document
			.getElementsByName("othSubsPayrPayerIdOriginal").item(0).value;
	document.getElementsByName("othPayrClmadjInd").item(0).value = document
			.getElementsByName("othPayrClmadjIndOriginal").item(0).value;
	document.getElementsByName("othPayrAddrLine1").item(0).value = document
			.getElementsByName("othPayrAddrLine1Original").item(0).value;
	document.getElementsByName("othPayrPlanId").item(0).value = document
			.getElementsByName("othPayrPlanIdOriginal").item(0).value;
	document.getElementsByName("othPayrAddrLine2").item(0).value = document
			.getElementsByName("othPayrAddrLine2Original").item(0).value;
	document.getElementsByName("othPayrSecId").item(0).value = document
			.getElementsByName("othPayrSecIdOriginal").item(0).value;
	document.getElementsByName("othPayrCity").item(0).value = document
			.getElementsByName("othPayrCityOriginal").item(0).value;
	doSelect(document.getElementsByName("othPayrState").item(0), document
			.getElementsByName("othPayrStateOriginal").item(0).value);
	document.getElementsByName("othPayrZip").item(0).value = document
			.getElementsByName("othPayrZipOriginal").item(0).value;
	document.getElementsByName("othPayrCountry").item(0).value = document
			.getElementsByName("othPayrCountryOriginal").item(0).value;
	document.getElementsByName("othPayrCntrySubdCd").item(0).value = document
			.getElementsByName("othPayrCntrySubdCdOriginal").item(0).value;
	document.getElementsByName("formattedOthPayrTaxId").item(0).value = document
			.getElementsByName("formattedOthPayrTaxIdOriginal").item(0).value;
	document.getElementsByName("othPayrLocNbr").item(0).value = document
			.getElementsByName("othPayrLocNbrOriginal").item(0).value;
	document.getElementsByName("othPayrNaic").item(0).value = document
			.getElementsByName("othPayrNaicOriginal").item(0).value;
	document.getElementsByName("othPayrPriorAuthNbr").item(0).value = document
			.getElementsByName("othPayrPriorAuthNbrOriginal").item(0).value;
	document.getElementsByName("othPayrReferralNbr").item(0).value = document
			.getElementsByName("othPayrReferralNbrOriginal").item(0).value;
	document.getElementsByName("othPayrClmCtrlNbr").item(0).value = document
			.getElementsByName("othPayrClmCtrlNbrOriginal").item(0).value;
	document.getElementsByName("payerResponseCd").item(0).value = document
			.getElementsByName("payerResponseCdOriginal").item(0).value;

	if (claimType == 'I') {
		document.getElementsByName("miaCoveredDays").item(0).value = document
				.getElementsByName("miaCoveredDaysOriginal").item(0).value;
		document.getElementsByName("miaLifePsychDayCnt").item(0).value = document
				.getElementsByName("miaLifePsychDayCntOriginal").item(0).value;
		document.getElementsByName("miaCostDayCnt").item(0).value = document
				.getElementsByName("miaCostDayCntOriginal").item(0).value;
		document.getElementsByName("miaClmpmtRemarkCd").item(0).value = document
				.getElementsByName("miaClmpmtRemarkCdOriginal").item(0).value;
		document.getElementsByName("miaClmPmtRemarkCd1").item(0).value = document
				.getElementsByName("miaClmPmtRemarkCd1Original").item(0).value;
		document.getElementsByName("miaClmPmtRemarkCd2").item(0).value = document
				.getElementsByName("miaClmPmtRemarkCd2Original").item(0).value;
		document.getElementsByName("miaClmPmtRemarkCd3").item(0).value = document
				.getElementsByName("miaClmPmtRemarkCd3Original").item(0).value;
		document.getElementsByName("miaClmPmtRemarkCd4").item(0).value = document
				.getElementsByName("miaClmPmtRemarkCd4Original").item(0).value;
		document.getElementsByName("moaClmPmtRemarkCd1").item(0).value = document
				.getElementsByName("moaClmPmtRemarkCd1Original").item(0).value;
		document.getElementsByName("moaClmPmtRemarkCd2").item(0).value = document
				.getElementsByName("moaClmPmtRemarkCd2Original").item(0).value;
		document.getElementsByName("moaClmPmtRemarkCd3").item(0).value = document
				.getElementsByName("moaClmPmtRemarkCd3Original").item(0).value;
		document.getElementsByName("moaClmPmtRemarkCd4").item(0).value = document
				.getElementsByName("moaClmPmtRemarkCd4Original").item(0).value;
		document.getElementsByName("moaClmPmtRemarkCd5").item(0).value = document
				.getElementsByName("moaClmPmtRemarkCd5Original").item(0).value;
	} else if (claimType == 'P') {
		document.getElementsByName("patSignSrcCd").item(0).value = document
				.getElementsByName("patSignSrcCdOriginal").item(0).value;
	}

	showClmOtherSubsDisplay();
}

function clmLineCancel(claimType) {
	document.getElementsByName("liProcCd").item(0).value = document
			.getElementsByName("liProcCdOriginal").item(0).value;
	document.getElementsByName("liProcMod1").item(0).value = document
			.getElementsByName("liProcMod1Original").item(0).value;
	document.getElementsByName("liProcMod2").item(0).value = document
			.getElementsByName("liProcMod2Original").item(0).value;
	document.getElementsByName("liProcMod3").item(0).value = document
			.getElementsByName("liProcMod3Original").item(0).value;
	document.getElementsByName("liProcMod4").item(0).value = document
			.getElementsByName("liProcMod4Original").item(0).value;
	document.getElementsByName("liUomQual").item(0).value = document
			.getElementsByName("liUomQualOriginal").item(0).value;
	document.getElementsByName("drugUomQual").item(0).value = document
			.getElementsByName("drugUomQualOriginal").item(0).value;
	document.getElementsByName("liProdSvcidQual").item(0).value = document
			.getElementsByName("liProdSvcidQualOriginal").item(0).value;
	document.getElementsByName("drugUnitCnt").item(0).value = document
			.getElementsByName("drugUnitCntOriginal").item(0).value;
	document.getElementsByName("rejectReasonCd").item(0).value = document
			.getElementsByName("rejectReasonCdOriginal").item(0).value;
	document.getElementsByName("pricingMethodology").item(0).value = document
			.getElementsByName("pricingMethodologyOriginal").item(0).value;
	document.getElementsByName("serviceCdQual").item(0).value = document
			.getElementsByName("serviceCdQualOriginal").item(0).value;
	document.getElementsByName("nationalDrugCd").item(0).value = document
			.getElementsByName("nationalDrugCdOriginal").item(0).value;
	document.getElementsByName("nationalDrugCdQual").item(0).value = document
			.getElementsByName("nationalDrugCdQualOriginal").item(0).value;
	document.getElementsByName("liProcDesc").item(0).value = document
			.getElementsByName("liProcDescOriginal").item(0).value;
	document.getElementsByName("reprcdLiRefNbr").item(0).value = document
			.getElementsByName("reprcdLiRefNbrOriginal").item(0).value;
	document.getElementsByName("adjReprcdLiRefNbr").item(0).value = document
			.getElementsByName("adjReprcdLiRefNbrOriginal").item(0).value;
	document.getElementsByName("reprcdUomCd").item(0).value = document
			.getElementsByName("reprcdUomCdOriginal").item(0).value;
	if (claimType == 'I') {
		document.getElementsByName("liRevenueCd").item(0).value = document
				.getElementsByName("liRevenueCdOriginal").item(0).value;
		document.getElementsByName("formattedLiBeginDt").item(0).value = document
				.getElementsByName("formattedLiBeginDtOriginal").item(0).value;
		document.getElementsByName("formattedLiEndDt").item(0).value = document
				.getElementsByName("formattedLiEndDtOriginal").item(0).value;
		document.getElementsByName("liServiceUnitCnt").item(0).value = document
				.getElementsByName("liServiceUnitCntOriginal").item(0).value;
		document.getElementsByName("exceptionCd").item(0).value = document
				.getElementsByName("exceptionCdOriginal").item(0).value;
		document.getElementsByName("policyComplianceCd").item(0).value = document
				.getElementsByName("policyComplianceCdOriginal").item(0).value;
		document.getElementsByName("liNote").item(0).value = document
				.getElementsByName("liNoteOriginal").item(0).value;
		document.getElementsByName("linkSequenceNbr").item(0).value = document
				.getElementsByName("linkSequenceNbrOriginal").item(0).value;
		document.getElementsByName("reprcdDrgCd").item(0).value = document
				.getElementsByName("reprcdDrgCdOriginal").item(0).value;
		document.getElementsByName("reprcdOrgId").item(0).value = document
				.getElementsByName("reprcdOrgIdOriginal").item(0).value;
		document.getElementsByName("approvedRevenueCd").item(0).value = document
				.getElementsByName("approvedRevenueCdOriginal").item(0).value;
		document.getElementsByName("reprcdSvcUnitCnt").item(0).value = document
				.getElementsByName("reprcdSvcUnitCntOriginal").item(0).value;
		document.getElementsByName("reprcdApprHcpcsCd").item(0).value = document
				.getElementsByName("reprcdApprHcpcsCdOriginal").item(0).value;
		document.getElementsByName("prescriptionNbr").item(0).value = document
				.getElementsByName("prescriptionNbrOriginal").item(0).value;
	} else if (claimType == 'P') {
		document.getElementsByName("dmeCertTypeCd").item(0).value = document
				.getElementsByName("dmeCertTypeCdOriginal").item(0).value;
		document.getElementsByName("dmeAttachTransmitCd").item(0).value = document
				.getElementsByName("dmeAttachTransmitCdOriginal").item(0).value;
		document.getElementsByName("dmeCertCondInd").item(0).value = document
				.getElementsByName("dmeCertCondIndOriginal").item(0).value;
		document.getElementsByName("liDmeProcCd").item(0).value = document
				.getElementsByName("liDmeProcCdOriginal").item(0).value;
		document.getElementsByName("dmeDuration").item(0).value = document
				.getElementsByName("dmeDurationOriginal").item(0).value;
		document.getElementsByName("dmeCertOnFileCd1").item(0).value = document
				.getElementsByName("dmeCertOnFileCd1Original").item(0).value;
		document.getElementsByName("dmeCertOnFileCd2").item(0).value = document
				.getElementsByName("dmeCertOnFileCd2Original").item(0).value;
		document.getElementsByName("liEpsdtInd").item(0).value = document
				.getElementsByName("liEpsdtIndOriginal").item(0).value;
		document.getElementsByName("liEmergencyInd").item(0).value = document
				.getElementsByName("liEmergencyIndOriginal").item(0).value;
		document.getElementsByName("obstetricAddlUnits").item(0).value = document
				.getElementsByName("obstetricAddlUnitsOriginal").item(0).value;
		document.getElementsByName("liDiagcdPtr1").item(0).value = document
				.getElementsByName("liDiagcdPtr1Original").item(0).value;
		document.getElementsByName("liDiagcdPtr3").item(0).value = document
				.getElementsByName("liDiagcdPtr3Original").item(0).value;
		document.getElementsByName("liPlaceOfServiceCd").item(0).value = document
				.getElementsByName("liPlaceOfServiceCdOriginal").item(0).value;
		document.getElementsByName("liServiceUnitCnt").item(0).value = document
				.getElementsByName("liServiceUnitCntOriginal").item(0).value;
		document.getElementsByName("liDiagcdPtr2").item(0).value = document
				.getElementsByName("liDiagcdPtr2Original").item(0).value;
		document.getElementsByName("liDiagcdPtr4").item(0).value = document
				.getElementsByName("liDiagcdPtr4Original").item(0).value;
		document.getElementsByName("liLenOfMedNecessity").item(0).value = document
				.getElementsByName("liLenOfMedNecessityOriginal").item(0).value;
		document.getElementsByName("liFamilyPlaningInd").item(0).value = document
				.getElementsByName("liFamilyPlaningIndOriginal").item(0).value;
		document.getElementsByName("liRentalUnitPrcInd").item(0).value = document
				.getElementsByName("liRentalUnitPrcIndOriginal").item(0).value;
		document.getElementsByName("liCopayStatusCd").item(0).value = document
				.getElementsByName("liCopayStatusCdOriginal").item(0).value;
		document.getElementsByName("liContractVersionId").item(0).value = document
				.getElementsByName("liContractVersionIdOriginal").item(0).value;
		document.getElementsByName("hospiceEmployedPrvInd").item(0).value = document
				.getElementsByName("hospiceEmployedPrvIndOriginal").item(0).value;
		document.getElementsByName("liContractTypeCd").item(0).value = document
				.getElementsByName("liContractTypeCdOriginal").item(0).value;
		document.getElementsByName("formattedContractPct").item(0).value = document
				.getElementsByName("formattedContractPctOriginal").item(0).value;
		document.getElementsByName("policyComplianceCd").item(0).value = document
				.getElementsByName("policyComplianceCdOriginal").item(0).value;
		document.getElementsByName("exceptionCd").item(0).value = document
				.getElementsByName("exceptionCdOriginal").item(0).value;
		document.getElementsByName("formattedContractTermsDiscPct").item(0).value = document
				.getElementsByName("formattedContractTermsDiscPctOriginal")
				.item(0).value;
		document.getElementsByName("formattedServiceBeginDt").item(0).value = document
				.getElementsByName("formattedServiceBeginDtOriginal").item(0).value;
		document.getElementsByName("formattedPrescriptionDt").item(0).value = document
				.getElementsByName("formattedPrescriptionDtOriginal").item(0).value;
		document.getElementsByName("formattedRecertificationDt").item(0).value = document
				.getElementsByName("formattedRecertificationDtOriginal")
				.item(0).value;
		document.getElementsByName("formattedBeginTherapyDt").item(0).value = document
				.getElementsByName("formattedBeginTherapyDtOriginal").item(0).value;
		document.getElementsByName("formattedServiceEndDt").item(0).value = document
				.getElementsByName("formattedServiceEndDtOriginal").item(0).value;
		document.getElementsByName("formattedHemoglobinDt").item(0).value = document
				.getElementsByName("formattedHemoglobinDtOriginal").item(0).value;
		document.getElementsByName("formattedSerumCreatineDt").item(0).value = document
				.getElementsByName("formattedSerumCreatineDtOriginal").item(0).value;
		document.getElementsByName("formattedShippedDt").item(0).value = document
				.getElementsByName("formattedShippedDtOriginal").item(0).value;
		document.getElementsByName("formattedLastCertificationDt").item(0).value = document
				.getElementsByName("formattedLastCertificationDtOriginal")
				.item(0).value;
		document.getElementsByName("formattedTreatmentTherapyDt").item(0).value = document
				.getElementsByName("formattedTreatmentTherapyDtOriginal").item(
						0).value;
		document.getElementsByName("formattedLastXrayDt").item(0).value = document
				.getElementsByName("formattedLastXrayDtOriginal").item(0).value;
		document.getElementsByName("formattedInitialTreatmentDt").item(0).value = document
				.getElementsByName("formattedInitialTreatmentDtOriginal").item(
						0).value;
		document.getElementsByName("liNoteCd").item(0).value = document
				.getElementsByName("liNoteCdOriginal").item(0).value;
		document.getElementsByName("liNoteText").item(0).value = document
				.getElementsByName("liNoteTextOriginal").item(0).value;
		document.getElementsByName("tpoLineNote").item(0).value = document
				.getElementsByName("tpoLineNoteOriginal").item(0).value;
		document.getElementsByName("immunizationBatchNbr").item(0).value = document
				.getElementsByName("immunizationBatchNbrOriginal").item(0).value;
		document.getElementsByName("lineItemControlNbr").item(0).value = document
				.getElementsByName("lineItemControlNbrOriginal").item(0).value;
		document.getElementsByName("mammogramCertNbr").item(0).value = document
				.getElementsByName("mammogramCertNbrOriginal").item(0).value;
		document.getElementsByName("heightResult").item(0).value = document
				.getElementsByName("heightResultOriginal").item(0).value;
		document.getElementsByName("hemoglobinResult").item(0).value = document
				.getElementsByName("hemoglobinResultOriginal").item(0).value;
		document.getElementsByName("hematocritResult").item(0).value = document
				.getElementsByName("hematocritResultOriginal").item(0).value;
		document.getElementsByName("epoetinStartDoseRslt").item(0).value = document
				.getElementsByName("epoetinStartDoseRsltOriginal").item(0).value;
		document.getElementsByName("creatinineResult").item(0).value = document
				.getElementsByName("creatinineResultOriginal").item(0).value;
		document.getElementsByName("cliaImproveAmendNbr").item(0).value = document
				.getElementsByName("cliaImproveAmendNbrOriginal").item(0).value;
		document.getElementsByName("referringCliaNbr").item(0).value = document
				.getElementsByName("referringCliaNbrOriginal").item(0).value;
		document.getElementsByName("orderPrvContactName").item(0).value = document
				.getElementsByName("orderPrvContactNameOriginal").item(0).value;
		document.getElementsByName("orderPrvEmail").item(0).value = document
				.getElementsByName("orderPrvEmailOriginal").item(0).value;
		document.getElementsByName("orderPrvFax").item(0).value = document
				.getElementsByName("orderPrvFaxOriginal").item(0).value;
		document.getElementsByName("orderPrvPhone").item(0).value = document
				.getElementsByName("orderPrvPhoneOriginal").item(0).value;
		document.getElementsByName("orderPrvPhoneExt").item(0).value = document
				.getElementsByName("orderPrvPhoneExtOriginal").item(0).value;
		document.getElementsByName("linkSeqNbr").item(0).value = document
				.getElementsByName("linkSeqNbrOriginal").item(0).value;
		document.getElementsByName("prescriptionNbr").item(0).value = document
				.getElementsByName("prescriptionNbrOriginal").item(0).value;
		document.getElementsByName("reprcdAprvAmbpatgrpcd").item(0).value = document
				.getElementsByName("reprcdAprvAmbpatgrpcdOriginal").item(0).value;
		document.getElementsByName("reprcdOrgId").item(0).value = document
				.getElementsByName("reprcdOrgIdOriginal").item(0).value;
		document.getElementsByName("reprcdSvcUnitCnt").item(0).value = document
				.getElementsByName("reprcdSvcUnitCntOriginal").item(0).value;
		document.getElementsByName("reprcdAprvHcpcsCd").item(0).value = document
				.getElementsByName("reprcdAprvHcpcsCdOriginal").item(0).value;
		document.getElementsByName("liAmbPickupAddrLine1").item(0).value = document
				.getElementsByName("liAmbPickupAddrLine1Original").item(0).value;
		document.getElementsByName("ambPatientWeight").item(0).value = document
				.getElementsByName("ambPatientWeightOriginal").item(0).value;
		document.getElementsByName("ambTransportDistance").item(0).value = document
				.getElementsByName("ambTransportDistanceOriginal").item(0).value;
		document.getElementsByName("liAmbPickupAddrLine2").item(0).value = document
				.getElementsByName("liAmbPickupAddrLine2Original").item(0).value;
		document.getElementsByName("liAmbCertCondInd").item(0).value = document
				.getElementsByName("liAmbCertCondIndOriginal").item(0).value;
		document.getElementsByName("ambTransportReasCd").item(0).value = document
				.getElementsByName("ambTransportReasCdOriginal").item(0).value;
		document.getElementsByName("liAmbPickupCity").item(0).value = document
				.getElementsByName("liAmbPickupCityOriginal").item(0).value;
		document.getElementsByName("liAmbPickupState").item(0).value = document
				.getElementsByName("liAmbPickupStateOriginal").item(0).value;
		document.getElementsByName("liAmbPickupZip").item(0).value = document
				.getElementsByName("liAmbPickupZipOriginal").item(0).value;
		document.getElementsByName("liAmbPickupCountry").item(0).value = document
				.getElementsByName("liAmbPickupCountryOriginal").item(0).value;
		document.getElementsByName("liAmbPickupCntrySubd").item(0).value = document
				.getElementsByName("liAmbPickupCntrySubdOriginal").item(0).value;
		document.getElementsByName("liAmbDropoffLoc").item(0).value = document
				.getElementsByName("liAmbDropoffLocOriginal").item(0).value;
		document.getElementsByName("liAmbCertCondCd1").item(0).value = document
				.getElementsByName("liAmbCertCondCd1Original").item(0).value;
		document.getElementsByName("liAmbCertCondCd4").item(0).value = document
				.getElementsByName("liAmbCertCondCd4Original").item(0).value;
		document.getElementsByName("liAmbDropoffAddrLine1").item(0).value = document
				.getElementsByName("liAmbDropoffAddrLine1Original").item(0).value;
		document.getElementsByName("liAmbCertCondCd2").item(0).value = document
				.getElementsByName("liAmbCertCondCd2Original").item(0).value;
		document.getElementsByName("liAmbCertCondCd5").item(0).value = document
				.getElementsByName("liAmbCertCondCd5Original").item(0).value;
		document.getElementsByName("liAmbDropoffAddrLine2").item(0).value = document
				.getElementsByName("liAmbDropoffAddrLine2Original").item(0).value;
		document.getElementsByName("liAmbCertCondCd3").item(0).value = document
				.getElementsByName("liAmbCertCondCd3Original").item(0).value;
		document.getElementsByName("liAmbDropoffCity").item(0).value = document
				.getElementsByName("liAmbDropoffCityOriginal").item(0).value;
		document.getElementsByName("liAmbDropoffState").item(0).value = document
				.getElementsByName("liAmbDropoffStateOriginal").item(0).value;
		document.getElementsByName("liAmbDropoffZip").item(0).value = document
				.getElementsByName("liAmbDropoffZipOriginal").item(0).value;
		document.getElementsByName("liAmbDropoffCountry").item(0).value = document
				.getElementsByName("liAmbDropoffCountryOriginal").item(0).value;
		document.getElementsByName("liAmbDropoffCntrySubd").item(0).value = document
				.getElementsByName("liAmbDropoffCntrySubdOriginal").item(0).value;
		document.getElementsByName("ambRoundTripPurpDesc").item(0).value = document
				.getElementsByName("ambRoundTripPurpDescOriginal").item(0).value;
		document.getElementsByName("ambStretcherPurpDesc").item(0).value = document
				.getElementsByName("ambStretcherPurpDescOriginal").item(0).value;
	}
	showClmLineDisplay();
}

function clmLineAdjudCancel(claimType) {
	if (claimType == 'I') {
		document.getElementsByName("othPayrPayerId").item(0).value = document
				.getElementsByName("othPayrPayerIdOriginal").item(0).value;
	} else if (claimType == 'P') {
		document.getElementsByName("othPayrPrimaryId").item(0).value = document
				.getElementsByName("othPayrPrimaryIdOriginal").item(0).value;
	}
	document.getElementsByName("clmliBundledLineNbr").item(0).value = document
			.getElementsByName("clmliBundledLineNbrOriginal").item(0).value;
	document.getElementsByName("clmliAdjudRevenueCd").item(0).value = document
			.getElementsByName("clmliAdjudRevenueCdOriginal").item(0).value;
	document.getElementsByName("clmliAdjudProcCd").item(0).value = document
			.getElementsByName("clmliAdjudProcCdOriginal").item(0).value;
	document.getElementsByName("prodOrSvcidQual").item(0).value = document
			.getElementsByName("prodOrSvcidQualOriginal").item(0).value;
	document.getElementsByName("clmliAdjudProcMod1").item(0).value = document
			.getElementsByName("clmliAdjudProcMod1Original").item(0).value;
	document.getElementsByName("clmliAdjudProcMod2").item(0).value = document
			.getElementsByName("clmliAdjudProcMod2Original").item(0).value;
	document.getElementsByName("clmliAdjudProcMod3").item(0).value = document
			.getElementsByName("clmliAdjudProcMod3Original").item(0).value;
	document.getElementsByName("clmliAdjudProcMod4").item(0).value = document
			.getElementsByName("clmliAdjudProcMod4Original").item(0).value;
	document.getElementsByName("clmliAdjudProcDesc").item(0).value = document
			.getElementsByName("clmliAdjudProcDescOriginal").item(0).value;
	document.getElementsByName("formattedAdjudPaymentDt").item(0).value = document
			.getElementsByName("formattedAdjudPaymentDtOriginal").item(0).value;
	document.getElementsByName("clmliPaidSvcUnitCnt").item(0).value = document
			.getElementsByName("clmliPaidSvcUnitCntOriginal").item(0).value;
	showClmLineAdjudDisplay();
}

function isDataChanged() {
	var val = document.hpeEncounterForm.dataChanged.value;
	if (val == "true")
		return true;
	return false;
}
function MarkDataChanged(state) {
	document.hpeEncounterForm.dataChanged.value = state;
}
function MarkDataDirtySSN(ctl, optional) {
	makeUpperCase(ctl);
	MarkDataChanged(true);
	return checkSSNFormat(ctl, optional);
}
function MarkDataDirtyDate(ctl) {
	makeUpperCase(ctl);
	MarkDataChanged(true);
	return validateDate(ctl);
}
function MarkDataDirtyZip(ctl, optional) {
	makeUpperCase(ctl);
	MarkDataChanged(true);
	return checkNoDashZipFormat(ctl, optional);
}
function MarkDataDirty(ctl) {
	makeUpperCase(ctl);
	MarkDataChanged(true);
}

function isClaimProviderChanged() {
	var val = document.hpeEncounterForm.clmPrvChanged.value
	if (val == "true")
		return true;
	return false;
}
function MarkClaimProviderChanged(state) {
	document.hpeEncounterForm.clmPrvChanged.value = state;
}
function MarkClaimProviderDirtyZip(ctl) {
	makeUpperCase(ctl);
	MarkClaimProviderChanged(true);
	return checkNoDashZipFormat(ctl, optional);
}
function MarkClaimProviderDirty(ctl) {
	makeUpperCase(ctl);
	MarkClaimProviderChanged(true);
}

function populateValues(rowCtr, claimType, provider) {

	var response;

	if (isClaimProviderChanged()) {

		response = confirm("Discard Provider Changes?");

		if (response != true)
			return;
	}

	MarkClaimProviderChanged(false);

	if (claimType == 'I')
		setInstClaimProviderValues(rowCtr);
	else if (claimType == 'P')
		setProfClaimProviderValues(rowCtr);

	var ctl, provType;
	var params = provider.split(',');

	for (var i = 0; i < params.length; i++) {

		var parts = params[i].split(':');
		var key = new String(trim(parts[0]));
		var value = new String(trim(parts[1]));

		if (key == 'PROV_TYPE') {
			provType = value;

			if (document.getElementById('clmProviderDisplayState').value != 'Cancel') {
				document.hpeEncounterForm.provType.value = provType;
				// added Attending type for 00362915 to make it updateble for
				// Attending provider

				if ((provType == 'REN') || (provType == 'REF')
						|| (provType == 'SVC') || (provType == 'ATT')
						|| (provType == 'OTH') || (provType == 'OPE') || (provType == 'SUP')) {		//IFOX-00418160 - NPI Provider fields update

					ctl = document.getElementById('clmPrvDisplay');
					ctl.style.display = "none";

					ctl = document.getElementById('clmPrvEntry');
					ctl.style.display = "";

					ctl = document.getElementById('clmProviderDisplayState');
					ctl.value = "EDIT";
				} else {
					showClmPrvDisplay();
				}
			}
		}
	}
}

function trim(str) {
	return str.replace(/^\s+|\s+$/g, '');
}





//Editable Fileds CHS -- IFOX-00395627

function UpdatableField(id,idtxt,idSv,idCnl,idtxtBox){
	var idUpBtn = document.getElementById(id);
	var idSpanText = document.getElementById(idtxt);
	var idtxtBox = document.getElementById(idtxtBox);
	var idSvBtn = document.getElementById(idSv);
	var idCnlBtn = document.getElementById(idCnl);
	idSvBtn.style.display = "";
	idCnlBtn.style.display = "";
	idUpBtn.style.display = "none";
	idSpanText.style.display = "none";
	idtxtBox.style.display = "";
	
}

function UpdatableCancelField(id,idtxt,idSv,idCnl,idtxtBox,loadImg){
	var idUpBtn = document.getElementById(id);
	var idSpanText = document.getElementById(idtxt);
	var idtxtBox = document.getElementById(idtxtBox);
	var idSvBtn = document.getElementById(idSv);
	var idCnlBtn = document.getElementById(idCnl);
	var loadImg =document.getElementById(loadImg);	
	loadImg.style.display = "none";
	idSvBtn.style.display = "none";
	idCnlBtn.style.display = "none";
	idUpBtn.style.display = "";
	idSpanText.style.display = "";
	idtxtBox.style.display = "none";
	
}


function UpdatableDiagField(spanType, type, spanCode, code, spanPOA, poa, updBtn, savBtn, cancelBtn){
	
	var spanType = document.getElementById(spanType);
	var type = document.getElementById(type);
	var spanCode = document.getElementById(spanCode);
	var code = document.getElementById(code);
	var spanPOA = document.getElementById(spanPOA);
	var poa = document.getElementById(poa);
	var updBtn = document.getElementById(updBtn);
	var savBtn = document.getElementById(savBtn);
	var cancelBtn = document.getElementById(cancelBtn);
	
	
	spanType.style.display = "none";
	type.style.display = "";
	spanCode.style.display = "none";
	code.style.display = "";
	spanPOA.style.display = "none";
	poa.style.display = "";
	savBtn.style.display = "";
	cancelBtn.style.display = "";
	updBtn.style.display = "none";
}

function UpdatableDiagCancelField(spanType, type, spanCode, code, spanPOA, poa, updBtn, savBtn, cancelBtn){
	
	var spanType = document.getElementById(spanType);
	var type = document.getElementById(type);
	var spanCode = document.getElementById(spanCode);
	var code = document.getElementById(code);
	var spanPOA = document.getElementById(spanPOA);
	var poa = document.getElementById(poa);
	var updBtn = document.getElementById(updBtn);
	var savBtn = document.getElementById(savBtn);
	var cancelBtn = document.getElementById(cancelBtn);
	
	
	spanType.style.display = "";
	type.style.display = "none";
	spanCode.style.display = "";
	code.style.display = "none";
	spanPOA.style.display = "";
	poa.style.display = "none";
	savBtn.style.display = "none";
	cancelBtn.style.display = "none";
	updBtn.style.display = "";
	
}

//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
function UpdatableAdjudAdjustField(spanCode, code, spanReason, reason, spanAmount, amount, spanQuantity, quantity, updBtn, savBtn, cancelBtn){
	
	var spanCode = document.getElementById(spanCode);
	var code = document.getElementById(code);
	var spanReason = document.getElementById(spanReason);
	var reason = document.getElementById(reason);
	var spanAmount = document.getElementById(spanAmount);
	var amount = document.getElementById(amount);
	var spanQuantity = document.getElementById(spanQuantity);
	var quantity = document.getElementById(quantity);
	var updBtn = document.getElementById(updBtn);
	var savBtn = document.getElementById(savBtn);
	var cancelBtn = document.getElementById(cancelBtn);
	
	spanCode.style.display = "none";
	code.style.display = "";
	spanReason.style.display = "none";
	reason.style.display = "";
	spanAmount.style.display = "none";
	amount.style.display = "";
	spanQuantity.style.display = "none";
	quantity.style.display = "";
	savBtn.style.display = "";
	cancelBtn.style.display = "";
	updBtn.style.display = "none";
}

function UpdatableAdjudAdjustCancelField(spanCode, code, spanReason, reason, spanAmount, amount, spanQuantity, quantity, updBtn, savBtn, cancelBtn){
	
	var spanCode = document.getElementById(spanCode);
	var code = document.getElementById(code);
	var spanReason = document.getElementById(spanReason);
	var reason = document.getElementById(reason);
	var spanAmount = document.getElementById(spanAmount);
	var amount = document.getElementById(amount);
	var spanQuantity = document.getElementById(spanQuantity);
	var quantity = document.getElementById(quantity);
	var updBtn = document.getElementById(updBtn);
	var savBtn = document.getElementById(savBtn);
	var cancelBtn = document.getElementById(cancelBtn);
	
	spanCode.style.display = "";
	code.style.display = "none";
	spanReason.style.display = "";
	reason.style.display = "none";
	spanAmount.style.display = "";
	amount.style.display = "none";
	spanQuantity.style.display = "";
	quantity.style.display = "none";
	savBtn.style.display = "none";
	cancelBtn.style.display = "none";
	updBtn.style.display = "";
	
}
//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End


function UpdatableValueField(spanCode, code, spanAmnt, amnt, updBtn, savBtn, cancelBtn){
	
	var spanCode = document.getElementById(spanCode);
	var code = document.getElementById(code);
	var spanAmnt = document.getElementById(spanAmnt);
	var amnt = document.getElementById(amnt);
	
	var updBtn = document.getElementById(updBtn);
	var savBtn = document.getElementById(savBtn);
	var cancelBtn = document.getElementById(cancelBtn);
	
	
	spanCode.style.display = "none";
	code.style.display = "";
	spanAmnt.style.display = "none";
	amnt.style.display = "";
	
	savBtn.style.display = "";
	cancelBtn.style.display = "";
	updBtn.style.display = "none";
}

function UpdatableValueCancelField(spanCode, code, spanAmnt, amnt, updBtn, savBtn, cancelBtn){
	
	var spanCode = document.getElementById(spanCode);
	var code = document.getElementById(code);
	var spanAmnt = document.getElementById(spanAmnt);
	var amnt = document.getElementById(amnt);
	
	var updBtn = document.getElementById(updBtn);
	var savBtn = document.getElementById(savBtn);
	var cancelBtn = document.getElementById(cancelBtn);
	
	
	spanCode.style.display = "";
	code.style.display = "none";
	spanAmnt.style.display = "";
	amnt.style.display = "none";
	
	savBtn.style.display = "none";
	cancelBtn.style.display = "none";
	updBtn.style.display = "";
	
}

//IFOX-00397153 : Updated below function to provide explicit validation
function UpdatableSaveField(mfId, clmNbr, clmRvNbr,clmSqNbr, cndSqNbr, heir, loadImg,code,type,poa,date,from,thru,amnt, claimType, encType, idNum){
	
	var loadImg =document.getElementById(loadImg);	
	loadImg.style.display = "";
	var parameters=mfId+"-"+clmNbr+"-"+clmRvNbr+"-"+clmSqNbr+"-"+cndSqNbr+"-"+heir +"-"+loadImg+"-"+code+"-"+type+"-"+poa+"-"+date+"-"+from+"-"+thru+"-"+amnt+"-"+claimType+"-"+encType+"-"+idNum;
	//alert(parameters);
	var parmsEdit;
	var errorMsg='';
	var validFlag=true;
	var claimType=null;
	var heirFieldName=getHeirFieldName(heir);
	var claimTypeSearch = document.getElementsByName("searchDetailEncType");
	var errorList= []; errorList.push('Invalid '+heirFieldName);
	var errorStr=null;
	if(claimTypeSearch.length>0){
		claimType=claimTypeSearch[0].value
	}else{
		alert('Could not find Claim Type');
		return false;
	}
	
	//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
	var adjudGroupCode = code;
	var adjudReasonCode = type;
	var adjudAmount = poa;
	var adjudQuantity = date;
	//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End
	
	if(heir != null && heir != '' && heir!='undefined'){
		if(heir=='COND_CODE'){
			var code = document.getElementById(code).value;
			
			if(code!=null && code!=''){
				if(claimType == 'I'){									
					if(!validateAlphaNumeric(code))		{errorList.push('Code should be alphanumeric')}
					if(!validateFieldSize(code,2,'ET'))	{errorList.push('Code should be max of 2 character')}
				}else if((claimType == 'P') || (claimType == 'E')){
					if(!validateAlphaNumeric(code))		{errorList.push('Code should be alphanumeric')}
					if(!validateFieldSize(code,2,'ET'))	{errorList.push('Code should be max of 2 character')}
				}
				
			}else{
				errorList.push('This field cannot be empty.');	
			}
			
			if(errorList.length <=1) {parmsEdit= "code="+code.toUpperCase();}
			
		}
		if(heir=='TRTMNT_CODE'){
			var code = document.getElementById(code).value;
			
			if(code!=null && code!=''){
				if(claimType == 'I'){									
					if(!validateAlphaNumeric(code))			{errorList.push('Code should be alphanumeric')}
					if(!validateFieldSize(code,30,'LET'))	{errorList.push('Code should be max of 30 character')}
				}else if((claimType == 'P') || (claimType == 'E')){
					if(!validateAlphaNumeric(code))			{errorList.push('Code should be alphanumeric')}
					if(!validateFieldSize(code,30,'LET'))	{errorList.push('Code should be max of 30 character')}
				}
				
			}else{
				errorList.push('This field cannot be empty.');	
			}
			
			if(errorList.length <=1) {parmsEdit= "code="+code.toUpperCase()}
			
		}
		if(heir=='DIAG_CODE'){			
			var code = document.getElementById(code).value;
			var type = document.getElementById(type).value;
			var poa = document.getElementById(poa).value;		
			
			var date = document.getElementById('svcDate').value+'';
			var ICD = ((date!=null && date!='')&&(date > '20151001')) ? 3:2;
			
			if(code!=null & code!='' && type!=null && type!=''){	//IFOX-00407127 -- Updateable Fields - Primary Diagnosis
							
				if(claimType == 'I'){
					//IFOX-00407127 -- Updateable Fields - Primary Diagnosis - Start
					if(idNum == 0 && (type != 'BK' && type != 'ABK')) {errorList.push('Invalid principal diagnosis type.')}
					if(idNum != 0 && (type == 'BK' || type == 'ABK')) {errorList.push('Invalid diagnosis type.')}
					if(!validateAlphaOnly(type))			{errorList.push('Type should be alphabets only.')}
					if(idNum != 0 && !validateFieldSize(type,ICD,'ET'))	{errorList.push('Type should be of '+ICD+' character.')}				
					//IFOX-00407127 -- Updateable Fields - Primary Diagnosis - End
					if(!validateAlphaNumeric(code))			{errorList.push('Code should be alphanumeric.')}
					if(!validateFieldSize(code,7,'LET'))	{errorList.push('Code should be max of 7 character.')}					
					if(poa!=null && poa!='' && !validateAlphaYN(poa))				{errorList.push('Present On Admit can only be Y/N/U/W.')}	//IFOX-00407127 -- Updateable Fields - Primary Diagnosis
					if(checkDuplicateDiagCode(claimType,code,type,poa))	{errorList.push('Duplicate Code.Please enter a different combination')}	
				}else if((claimType == 'P') || (claimType == 'E')){
					//IFOX-00407127 -- Updateable Fields - Primary Diagnosis - Start
					if(idNum == 0 && (type != 'BK' && type != 'ABK')) {errorList.push('Invalid principal diagnosis type.')}
					if(idNum != 0 && (type == 'BK' || type == 'ABK')) {errorList.push('Invalid diagnosis type.')}
					if(!validateAlphaOnly(type))			{errorList.push('Type should be alphabets only.')}
					if(idNum != 0 && !validateFieldSize(type,ICD,'ET'))	{errorList.push('Type should be of '+ICD+' character.')}				
					//IFOX-00407127 -- Updateable Fields - Primary Diagnosis - End
					if(!validateAlphaNumeric(code))			{errorList.push('Code should be alphanumeric')}
					if(!validateFieldSize(code,7,'LET'))	{errorList.push('Code should be max of 7 character')}					
					//if(!validateAlphaYN(poa))			{validFlag = false; errorMsg='Invalid'+heirFieldName +'.Present On Admit can only be Y/N'}	- Not needed for professional
					if(checkDuplicateDiagCode(claimType,code,type,poa))	{errorList.push('Duplicate Code.Please enter a different combination')}
				}
					
			}else{
				errorList.push('This field cannot be empty.');		
			}
			if(errorList.length <=1) {parmsEdit= "type="+type.toUpperCase()+"&code="+code.toUpperCase()+"&poa="+poa.toUpperCase();}
		}
		if(heir=='EXT_INJ_CODE'){			
			var code = document.getElementById(code).value;
			var type = document.getElementById(type).value;
			var poa = document.getElementById(poa).value;		
			
			var date = document.getElementById('svcDate').value+'';
			var ICD = ((date!=null && date!='')&&(date > '20151001')) ? 3:2;
			//var ICD=3;
			
			if(code!=null & code!='' && type!=null && type!='' && poa!=null && poa!=''){
								
				if(claimType == 'I'){
					if(!validateAlphaOnly(type))			{errorList.push('Type should be alphabets only.')}
					if(!validateFieldSize(type,ICD,'ET'))	{errorList.push('Type should be of '+ICD+' character.')}				
					//if(!validateNumeric(code))				{errorList.push('Code should be numeric.')}
					if(!validateFieldSize(code,30,'LET'))	{errorList.push('Code should be max of 30 digit.')}					
					if(!validateAlphaYN(poa))				{errorList.push('Present On Admit can only be Y/N.')}
				}else if((claimType == 'P') || (claimType == 'E')){
					if(!validateAlphaOnly(type))			{errorList.push('Type should be alphabets only')}
					if(!validateFieldSize(type,ICD,'ET'))	{errorList.push('Type should be of '+ICD+' character')}				
					//if(!validateNumeric(code))				{errorList.push('Code should be numeric.')}
					if(!validateFieldSize(code,30,'LET'))	{errorList.push('Code should be max of 30 digit.')}					
					//if(!validateAlphaYN(poa))			{validFlag = false; errorMsg='Invalid'+heirFieldName +'.Present On Admit can only be Y/N'}	- Not needed for professional
					
				}
					
			}else{
				errorList.push('This field cannot be empty.');		
			}
			if(errorList.length <=1) {parmsEdit= "type="+type.toUpperCase()+"&code="+code.toUpperCase()+"&poa="+poa.toUpperCase();}
		}
		if(heir=='PROC_CODE'){
			var code = document.getElementById(code).value;
			var type = document.getElementById(type).value;
			var date = document.getElementById(date).value;
			if(type!=null && type!='' && code!=null && code!='' && date!=null && date!=''){
				if(claimType == 'I'){
					
					if(!validateAlphaOnly(type))			{errorList.push('Type should be alphabets only')}
					if(!validateFieldSize(type,3,'LET'))	{errorList.push('Type should be max of 3 character')}				
					if(!validateAlphaNumeric(code))			{errorList.push('Code should be alphanumeric')}
					if(!validateFieldSize(code,7,'LET'))	{errorList.push('Code should be max of 7 character')}					
					if(!isValidDate(date))					{errorList.push('Date should be of the format MM/DD/YYYY')}
					
				}else if((claimType == 'P') || (claimType == 'E')){
					//- No validation needed for professional
				}				
			}else{
				errorList.push('This field cannot be empty.');
			}
			if(errorList.length <=1) {parmsEdit= "type="+type.toUpperCase()+"&code="+code.toUpperCase()+"&date="+date.toUpperCase();}
			
		}
		if(heir=='OCCUR_SPAN_CODE'){
			var code = document.getElementById(code).value;
			var from = document.getElementById(from).value;
			var thru = document.getElementById(thru).value;	
			
			if(code!=null && code!='' && from!=null && from!='' && thru!=null && thru!=''){
								
				if(claimType == 'I'){
									
					if(!validateAlphaNumeric(code))				{errorList.push('Code should be alphanumeric')}
					if(!validateFieldSize(code,18,'LET'))		{errorList.push('Code should be max of 18 character')}
					
					if(!isValidDate(from) && !isValidDate(thru)){errorList.push('From Date & Through Date should be of the format MM/DD/YYYY')}						
					else if(compareDate(from,thru)>0 )			{errorList.push('From Date should be older than Through Date')}					
					
				}else if((claimType == 'P') || (claimType == 'E')){
					//- No validation needed for professional					
				}
				
			}else{
				errorList.push('This field cannot be empty.');
			}
			if(errorList.length <=1) {parmsEdit="code="+code.toUpperCase()+"&from="+from.toUpperCase()+"&thru="+thru.toUpperCase();}
			
		}
		if(heir=='VALUE_CODE'){
			var code = document.getElementById(code).value;
			var amnt = document.getElementById(amnt).value;
			var amnt=amnt.replace('$','');
			if(code!=null && code!='' && amnt!=null && amnt!=''){
				
				if(claimType == 'I'){
					
					if(!validateAlphaNumeric(code))			{errorList.push('Code should be alphanumeric')}
					if(!validateFieldSize(code,2,'LET'))	{errorList.push('Code should be max of 2 character')}
					
					if(!validateDecimalFormat(amnt,9,2))	{errorList.push('Amount can have max 9 digit decimal and 2 digit of fractional value')}
					
					
				}else if((claimType == 'P') || (claimType == 'E')){
					//- No validation needed for professional
				}
				
			}else{
				errorList.push('This field cannot be empty.');
			}
			if(errorList.length <=1) {parmsEdit= "code="+code.toUpperCase()+"&amnt="+amnt.toUpperCase();}
		}
		if(heir=='OCCUR_CODE'){
			var code = document.getElementById(code).value;
			var date = document.getElementById(date).value;
			if(code!=null && code!='' && date!=null && date!=''){
				
				if(claimType == 'I'){
					
					if(!validateAlphaNumeric(code))			{errorList.push('Code should be alphanumeric')}
					if(!validateFieldSize(code,7,'LET'))	{errorList.push('Code should be max of 7 character')}
					if(!isValidDate(date))					{errorList.push('Date should be of the format MM/DD/YYYY')}					
					
				}else if((claimType == 'P') || (claimType == 'E')){
					//- No validation needed for professional
				}
			}else{
				errorList.push('This field cannot be empty.');
			}
			if(errorList.length <=1) {parmsEdit="code="+code.toUpperCase()+"&date="+date.toUpperCase();}
			
		}
		//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
		if(heir=='ADJUD_ADJUST'){
			var code = document.getElementById('updateTxtCode'+idNum).value;
			var reason = document.getElementById('updateTxtReason'+idNum).value;
			var amount = document.getElementById('updateTxtAmount'+idNum).value;
			amount=amount.replace('$','');
			var quantity = document.getElementById('updateTxtQuantity'+idNum).value;
			var adjudseqnbr = document.getElementById('updateTxtAdjudSeqNbr'+idNum).value;
			var adjustseqnbr = document.getElementById('updateTxtAdjustSeqNbr'+idNum).value;
			var clmliseqnbr = document.getElementById('updateTxtClmliSeqNbr'+idNum).value;

			if(code!=null && code!='' && reason!=null && reason!='' && amount!=null && amount!='' && quantity!=null && quantity!=''){
					
					if(!validateAlphaNumeric(code))			{errorList.push('Code should be alphanumeric')}
					if(!validateFieldSize(code,2,'LET'))	{errorList.push('Code should be max of 2 character')}
					if(!validateDecimalFormat(amount,7,2))	{errorList.push('Amount can have max 7 digit decimal and 2 digit of fractional value')}		//IFOX-00415579 - Claim Line Adjud Adjstmnt Amount field Max length

			}else{
				errorList.push('This field cannot be empty.');
			}
			if(errorList.length <=1) {parmsEdit="code="+code.toUpperCase()+"&reason="+reason.toUpperCase()+"&amount="+amount.toUpperCase()+"&quantity="+quantity.toUpperCase()+"&adjudseqnbr="+adjudseqnbr.toUpperCase()+"&adjustseqnbr="+adjustseqnbr.toUpperCase()+"&clmliseqnbr="+clmliseqnbr.toUpperCase();}
			
		}
		if(heir=='ADJUD_ADJUST_IN'){
			var code = document.getElementById('updateTxtAdjudAdjust'+idNum).value;
			var reason = document.getElementById('updateTxtAdjudAdjustReason'+idNum).value;
			var amount = document.getElementById('updateTxtAdjudAdjustAmount'+idNum).value;
			amount=amount.replace('$','');
			var quantity = document.getElementById('updateTxtAdjudAdjustQuantity'+idNum).value;
			var adjudseqnbr = from.trim(); //IFOX-00416992 - Browser Compatibility issue
			var adjustseqnbr = cndSqNbr;
			var clmliseqnbr = thru.trim(); //IFOX-00416992 - Browser Compatibility issue

			if(code!=null && code!='' && reason!=null && reason!='' && amount!=null && amount!='' && quantity!=null && quantity!=''){
					
					if(!validateAlphaNumeric(code))			{errorList.push('Code should be alphanumeric')}
					if(!validateFieldSize(code,2,'LET'))	{errorList.push('Code should be max of 2 character')}
					if(!validateDecimalFormat(amount,7,2))	{errorList.push('Amount can have max 7 digit decimal and 2 digit of fractional value')}		//IFOX-00415579 - Claim Line Adjud Adjstmnt Amount field Max length

			}else{
				errorList.push('This field cannot be empty.');
			}
			if(errorList.length <=1) {parmsEdit="code="+code.toUpperCase()+"&reason="+reason.toUpperCase()+"&amount="+amount.toUpperCase()+"&quantity="+quantity.toUpperCase()+"&adjudseqnbr="+adjudseqnbr.toUpperCase()+"&adjustseqnbr="+adjustseqnbr.toUpperCase()+"&clmliseqnbr="+clmliseqnbr.toUpperCase();}
			
		}
		//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End
		
		
	}
	//alert("parmsEdit--"+parmsEdit+"--ind-"+idNum);
	validFlag=(errorList.length>1)?false:true;
	if(validFlag){
		parmsEdit=parmsEdit+"&encType="+encType;
		//alert('...Calling UpdateFieldAjax');
	/* IFOX-00406912 Primary Procedure Code*/	
	if(cndSqNbr!=0 && heir=='PROC_CODE' && claimType == 'I' && (type=='BR' || type=='BBR')){
			
    FacadeManager.checkDupPrincipalProcCode(mfId,clmNbr,clmRvNbr,cndSqNbr,encType,clmSqNbr,{callback:function(princCode){
	var tableId="instProcedureCodeTable";
	var tab = document.getElementById(tableId);
	var trs= tab.rows;
	if(typeof trs[1].cells[0].childNodes[1]!=='undefined'){
		
	typeF=trs[1].cells[0].childNodes[1].innerHTML;
	
	}
	
	if((princCode!=null || princCode!=undefined) && (princCode.indexOf('ERROR') <= -1)){
		
	}else if (princCode.indexOf('ERROR:PRINCPROCCODEDUPL') > -1 && idNum!=0){
		
		errorStr= princCode.replace("ERROR:PRINCPROCCODEDUPL:", "");
		alert(errorStr)
		 var loadImg = document.getElementById('loadImageProcCode'+idNum);
		 loadImg.style.display = "none";
	
				
	    }else if (princCode.indexOf('NODUPLICATE') > -1) {
	    	
	    	UpdateFieldAjax(mfId,clmNbr,clmRvNbr,clmSqNbr,cndSqNbr,heir,loadImg,parmsEdit,idNum,'UPDT','','','');	//IFOX-00413184 - Opening of Claim Adjudication fields and amounts
	    }
			
		}})
	}else{
		
		UpdateFieldAjax(mfId,clmNbr,clmRvNbr,clmSqNbr,cndSqNbr,heir,loadImg,parmsEdit,idNum,'UPDT',adjudseqnbr,adjustseqnbr,clmliseqnbr);	//IFOX-00413184 - Opening of Claim Adjudication fields and amounts
	}
	}else{
		loadImg.style.display = "none";
		for (var i = 0; i < errorList.length; i++) { errorMsg=errorMsg+errorList[i]+'\n';}alert(errorMsg);
	}
	
	
	
}



function UpdateFieldAjax(mfId,clmNbr,clmRvNbr,clmSqNbr,cndSqNbr,heir,loadImg,parmsEdit,idNum,indFlag,adjudseqnbr,adjustseqnbr,clmliseqnbr){		//IFOX-00413184 - Opening of Claim Adjudication fields and amounts
	
	var tbodyId = '';
	tbodyId ='instProcedureCodeTbody'; 
	var tbdyElement = document.getElementById(tbodyId);

//	var newRowId = tbdyElement.rows.length;	//IFOX-00407127 -- Updateable Fields - Primary Diagnosis


	
	 if(heir=='COND_CODE' ){
		 var loadImg = document.getElementById('loadImageCondCode'+idNum);
		 loadImg.style.display = "";
	 }
	 
	 if(heir=='DIAG_CODE' ){
		 var loadImg = document.getElementById('loadImageDiagCode'+idNum);
		 loadImg.style.display = "";
	 }
	 
	 if(heir=='EXT_INJ_CODE' ){
		 var loadImg = document.getElementById('loadImageExtInjCode'+idNum);
		 loadImg.style.display = "";
	 }
	 
	 if(heir=='PROC_CODE' ){
		 var loadImg = document.getElementById('loadImageProcCode'+idNum);
		 loadImg.style.display = "";
	 }
	 
	 if(heir=='TRTMNT_CODE' ){
		 var loadImg = document.getElementById('loadImageTreatCode'+idNum);
		 loadImg.style.display = "";
	 }
	 //IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
	 var heir1 = '';
	 if(heir=='ADJUD_ADJUST'){
		 var loadImg = document.getElementById('loadImageAdjudAdjust'+idNum);
		 loadImg.style.display = "";
	 }
	 if(heir=='ADJUD_ADJUST_IN'){
		 heir='ADJUD_ADJUST';
		 heir1='ADJUD_ADJUST_IN'
		 var loadImg = document.getElementById('loadImageAdjudAdjust'+idNum);
		 loadImg.style.display = "";
	 }
	 //IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End
	
	 var hei ='' , condCode='', conType='', conPOA='', conDate='', conFrmDt='', conToDt='', conAmnt='', conReason='', conAmount='', conQuantity='' ;	//IFOX-00413184 - Opening of Claim Adjudication fields and amounts
			   
				if (mfId != null && mfId != '' && mfId!='undefined' && clmNbr != null && clmNbr != '' && clmNbr!='undefined'
					&& clmRvNbr != null && clmRvNbr != '' && clmRvNbr!='undefined'&& clmSqNbr != null && clmSqNbr != '' && clmSqNbr!='undefined'
						&& cndSqNbr != null && cndSqNbr != '' && cndSqNbr!='undefined') {
					
					
					  var url = "/hpeAction.do";
					  var params = "mfId="+mfId+"&clmNbr="+clmNbr+"&clmRvNbr="+clmRvNbr+"&clmSqNbr="+clmSqNbr+"&cndSqNbr="+cndSqNbr+"&heir="+heir+"&method=editableClaimCodesSection";
					  params =parmsEdit+"&"+ params+"&delFlag="+indFlag;
					 //  alert("UpdateAjax method--"+params);
					  //IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
					  if(heir1!='ADJUD_ADJUST_IN' && heir=='ADJUD_ADJUST'){	//IFOX-00417123 -  Issues in the portal when trying to use the delete functionality
					    var adjudseqnbr = document.getElementById('updateTxtAdjudSeqNbr'+idNum).value;
						var adjustseqnbr = document.getElementById('updateTxtAdjustSeqNbr'+idNum).value;
						var clmliseqnbr = document.getElementById('updateTxtClmliSeqNbr'+idNum).value;
						params = params + "&adjudseqnbr="+adjudseqnbr+"&adjustseqnbr="+adjustseqnbr+"&clmliseqnbr="+clmliseqnbr;
					  }
					  if(heir1=='ADJUD_ADJUST_IN'){
						params = params + "&adjudseqnbr="+adjudseqnbr+"&adjustseqnbr="+adjustseqnbr+"&clmliseqnbr="+clmliseqnbr; 
					  }
						//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End
					   
					   
					   // Perform the AJAX request using a non-IE browser.
					    if (window.XMLHttpRequest) {
					    var request = new XMLHttpRequest();
					   
					      // Register callback function that will be called when
					      // the response is generated from the server.
					      request.onreadystatechange = function() {			    	  		    		  
					    	 
					    	    if ( request.readyState == 4 && request.status==200 ) {
					    	    	// alert("Update Successfully");			    	    	
					    	    	
					    	    	 var res = params.split("&");
						    	    	
					    	    	  // alert(res);
					    	    	   
					    	    	   for (i=0;i<res.length;i++)
						    	    	{
						    	    	//alert(res[i]);
						    	    		var spl = res[i].split("=");

						    	    		if(spl[0]=='heir'){
						    	    		hei=spl[1];
						    	    		}
						    	    		
						    	    		if(spl[0]=='code'){
						    	    			condCode=spl[1];
							    	    	}
						    	    		if(spl[0]=='type'){
						    	    			conType=spl[1];
							    	    	}
						    	    		if(spl[0]=='poa'){
						    	    			conPOA=spl[1];
							    	    	}
						    	    		if(spl[0]=='date'){
						    	    			conDate=spl[1];
							    	    	}
						    	    	
						    	    		if(spl[0]=='from'){
						    	    			conFrmDt=spl[1];
							    	    	}
						    	    		
						    	    		if(spl[0]=='thru'){
						    	    			conToDt=spl[1];
							    	    	}
						    	    		
						    	    		if(spl[0]=='amnt'){
						    	    			conAmnt=spl[1];
							    	    	}
						    	    		//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
						    	    		if(spl[0]=='reason'){
						    	    			conReason=spl[1];
							    	    	}
						    	    		
						    	    		if(spl[0]=='amount'){
						    	    			conAmount=spl[1];
							    	    	}
						    	    		
						    	    		if(spl[0]=='quantity'){
						    	    			conQuantity=spl[1];
							    	    	}
											//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End						    	    		
						    	    	}
					    	    	   
					    	    	   
					    	    	   if(hei=='COND_CODE' ){
					    	    		   
					    	    		    var idUpBtn = document.getElementById('updateBtnCondCode'+idNum);
							    	    	var idSpanText = document.getElementById('spanUpdateTxtCondCode'+idNum);
							    	    	var idtxtBox = document.getElementById('updateTxtCondCode'+idNum);
							    	    	var idSvBtn = document.getElementById('updateSaveBtnCondCode'+idNum);
							    	    	var idCnlBtn = document.getElementById('updateCancelBtnCondCode'+idNum);
							    	    	var claimStatus = document.getElementById('claimCodeStatus');
							    	    	var loadImg = document.getElementById('loadImageCondCode'+idNum);

												 if (indFlag == 'DEL') {
															idSvBtn.style.display = "none";
															idCnlBtn.style.display = "none";
															idUpBtn.style.display = "none";
															idSpanText.style.display = "none";
															idtxtBox.style.display = "none";
								
															var rowId = document.getElementById('condCodeRow'
																	+ idNum)
															rowId.style.display = "none";
								
															claimStatus.innerHTML = 'Condition code Deleted successfully'
																loadImg.style.display = "none";
								
														} else {
								
															idSvBtn.style.display = "none";
															idCnlBtn.style.display = "none";
															idUpBtn.style.display = "";
															idSpanText.style.display = "";
															idtxtBox.style.display = "none";
								
															idSpanText.innerHTML = condCode;
															claimStatus.innerHTML = 'Condition code Updated successfully'
																loadImg.style.display = "none";
														}	
						    	    		
						    			}
						    	    	if( hei=='TRTMNT_CODE' ){
						    	    		
						    	    		    var idUpBtn = document.getElementById('updateBtnTreatCode'+idNum);
								    	    	var idSpanText = document.getElementById('spanUpdateTxtTreatCode'+idNum);
								    	    	var idtxtBox = document.getElementById('updateTxtTreatCode'+idNum);
								    	    	var idSvBtn = document.getElementById('updateSaveBtnTreatCode'+idNum);
								    	    	var idCnlBtn = document.getElementById('updateCancelBtnTreatCode'+idNum);
								    	    	var claimStatus = document.getElementById('claimCodeStatus');
								    	    	var loadImg = document.getElementById('loadImageTreatCode'+idNum);
								    	    	
								    	    	 if (indFlag == 'DEL') {
								    	    		 idSvBtn.style.display = "none";
										    	    	idCnlBtn.style.display = "none";
										    	    	idUpBtn.style.display = "";
										    	    	idSpanText.style.display = "";
										    	    	idtxtBox.style.display = "none";
								    	    		
										    	    	var rowId = document.getElementById('treatmentRow'+ idNum)
														rowId.style.display = "none";
							
														claimStatus.innerHTML = 'Treatment code Deleted successfully'
															loadImg.style.display = "none";
								    	    		 
								    	    	 }else{
								    	    	
								    	    	idSvBtn.style.display = "none";
								    	    	idCnlBtn.style.display = "none";
								    	    	idUpBtn.style.display = "";
								    	    	idSpanText.style.display = "";
								    	    	idtxtBox.style.display = "none";
						    	    		
							    	    		idSpanText.innerHTML=condCode;
							    	    		claimStatus.innerHTML='Treatment code Update successfully'
						    	    			loadImg.style.display = "none";
								    	    	 }
						    			}
					    	    	
						    	    	if( hei=='DIAG_CODE' ){
						    	    		
					    	    		    var idUpBtn = document.getElementById('updateBtnDiagCode'+idNum);
							    	    	var idSpanType = document.getElementById('spanUpdateTxtdiagType'+idNum);
							    	    	var idSpanCode = document.getElementById('spanUpdateTxtdiagCode'+idNum);
							    	    	var idSpanPOA = document.getElementById('spanUpdateTxtdiagPOA'+idNum);
							    	    	var idtxtType = document.getElementById('updateTxtDiagType'+idNum);
							    	    	var idtxtCode = document.getElementById('updateTxtDiagCode'+idNum);
							    	    	var idtxtPOA = document.getElementById('updateTxtDiagPOA'+idNum);
							    	    	var idSvBtn = document.getElementById('updateSaveBtnDiagCode'+idNum);
							    	    	var idCnlBtn = document.getElementById('updateCancelBtnDiagCode'+idNum);
							    	    	var claimStatus = document.getElementById('claimCodeStatus');
							    	    	var loadImg = document.getElementById('loadImageDiagCode'+idNum);
							    	    	
							    	    	 if (indFlag == 'DEL') {

									    	    	idSvBtn.style.display = "none";
									    	    	idCnlBtn.style.display = "none";
									    	    	idUpBtn.style.display = "";
									    	    	idSpanType.style.display = "";
									    	    	idSpanCode.style.display = "";
									    	    	idSpanPOA.style.display = "";
									    	    	idtxtType.style.display = "none";
									    	    	idtxtCode.style.display = "none";
									    	    	idtxtPOA.style.display = "none";
							    	    		
									    	    	idSpanType.innerHTML=conType;
									    	    	idSpanCode.innerHTML=condCode;
									    	    	idSpanPOA.innerHTML=conPOA;
									    	    	
									    	    	var rowId = document.getElementById('diagCodeRow'+ idNum)
													rowId.style.display = "none";
									    	    	
							    	    		claimStatus.innerHTML='Diagnosis code Deleted successfully'
							    	    			loadImg.style.display = "none";
							    	    		 
							    	    	 }else{

									    	    	idSvBtn.style.display = "none";
									    	    	idCnlBtn.style.display = "none";
									    	    	idUpBtn.style.display = "";
									    	    	idSpanType.style.display = "";
									    	    	idSpanCode.style.display = "";
									    	    	idSpanPOA.style.display = "";
									    	    	idtxtType.style.display = "none";
									    	    	idtxtCode.style.display = "none";
									    	    	idtxtPOA.style.display = "none";
							    	    		
									    	    	idSpanType.innerHTML=conType;
									    	    	idSpanCode.innerHTML=condCode;
									    	    	idSpanPOA.innerHTML=conPOA;
									    	    	
							    	    		    claimStatus.innerHTML='Diagnosis code Update successfully'
							    	    			loadImg.style.display = "none";
							    	    		 
							    	    	 }
							    	    	
					    			}
						    	    	
						    	    	if( hei=='PROC_CODE' ){
						    	    		
					    	    		    var idUpBtn = document.getElementById('updateBtnProcCode'+idNum);
							    	    	var idSpanType = document.getElementById('spanUpdateTxtProcType'+idNum);
							    	    	var idSpanCode = document.getElementById('spanUpdateTxtProcCode'+idNum);
							    	    	var idSpanDate = document.getElementById('spanUpdateTxtProcDate'+idNum);
							    	    	var idtxtType = document.getElementById('updateTxtProcType'+idNum);
							    	    	var idtxtCode = document.getElementById('updateTxtProcCode'+idNum);
							    	    	var idtxtDate = document.getElementById('updateTxtProcDate'+idNum);
							    	    	var idSvBtn = document.getElementById('updateSaveBtnProcCode'+idNum);
							    	    	var idCnlBtn = document.getElementById('updateCancelBtnProcCode'+idNum);
							    	    	var claimStatus = document.getElementById('claimCodeStatus');
							    	    	var loadImg = document.getElementById('loadImageProcCode'+idNum);
							    	    	if(indFlag == 'DEL'){
							    	    		idSvBtn.style.display = "none";
								    	    	idCnlBtn.style.display = "none";
								    	    	idUpBtn.style.display = "";
								    	    	idSpanType.style.display = "";
								    	    	idSpanCode.style.display = "";
								    	    	idSpanDate.style.display = "";
								    	    	idtxtType.style.display = "none";
								    	    	idtxtCode.style.display = "none";
								    	    	idtxtDate.style.display = "none";
						    	    		
								    	    	idSpanType.innerHTML=conType;
								    	    	idSpanCode.innerHTML=condCode;
								    	    	idSpanDate.innerHTML=conDate;
								    	    	var rowId = document.getElementById('procCodeRow'+ idNum)
												rowId.parentNode.removeChild(rowId);
								    	    	
								    	    	
						    	    		    claimStatus.innerHTML='Procedure code Deleted successfully'
						    	    			loadImg.style.display = "none";
							    	    		
							    	    	}else{
												/* IFOX-00406912 Primary Procedure Code*/			    	    									    	    		var rowStr="";
							    	    		if((conType =='BR') || (conType =='BBR')){
								    	    		var rowClassId=((idNum % 2) == 0) ? "evenRow" : "oddRow";
								    				var procCodeRowId="procCodeRow"+idNum;
								    				
								    				//Span
								    				var spanUpdateTxtProcTypeId="spanUpdateTxtProcType"+idNum;
								    				var spanUpdateTxtProcCodeId="spanUpdateTxtProcCode"+idNum;
								    				var spanUpdateTxtProcDateId="spanUpdateTxtProcDate"+idNum;
								    				
								    				//Update
								    				var updateTxtProcTypeId="updateTxtProcType"+idNum;
								    				var updateTxtProcCodeId="updateTxtProcCode"+idNum;
								    				var updateTxtProcDateId="updateTxtProcDate"+idNum;
								    				//For Buttons
								    				var updateBtnProcCodeId="updateBtnProcCode"+idNum; 
								    				var updateSaveBtnProcCodeId="updateSaveBtnProcCode"+idNum;
								    				var updateCancelBtnProcCodeId="updateCancelBtnProcCode"+idNum;
								    				var loadImageProcCodeId="loadImageProcCode"+idNum;
								    				var deleteProcBtnId="deleteProcBtn"+idNum;
								    				//For Values
								    				var procTypeValue=conType;
								    				var procCodeValue=condCode;
								    				var procDateValue=conDate;
								    			
								    				 var claimTypeSearch = document.getElementsByName("searchDetailEncType");		//Using the selected encType(I/P/E) from search form as values are hardcoded in respective jsp
								    				  
								    					if(claimTypeSearch.length>0){
								    						claimType=claimTypeSearch[0].value
								    					}else{
								    						alert('Could not find Claim Type');
								    						return false;
								    					}
								    					var clmTypeStr=	document.hpeEncounterForm.searchDetailClmType.value;		//Using the selected claimType(EN/CR) from search form as values are hardcoded in respective jsp
								    					var claimRefNbr=document.hpeEncounterForm.selectedClaimRefNbr.value;
								    					var claimRevNbr=document.hpeEncounterForm.selectedClaimRevNbr.value;
								    					var claimSeqNbr=document.hpeEncounterForm.selectedClaimSeqNbr.value;
								    					var claimDetail={	editableMfid:null,			searchDetailClmType:null,	searchDetailEncType:null,	selectedClaimRefNbr:null,
								    										selectedClaimRevNbr:null,	selectedClaimSeqNbr:null,	editableCndSeqNbr:null,		editableCode:null,
								    										editableType:null,			editablePOA:null,			editableDate:null,			editableFromDt:null,
								    										editableThruDt:null,		editableAmount:null,		userId:null	
								    									};
								    					
								    					claimDetail.hier=heir;
								    					claimDetail.editableMfid='';
								    					claimDetail.searchDetailClmType=clmTypeStr; 
								    					claimDetail.searchDetailEncType=claimType;
								    					claimDetail.selectedClaimRefNbr=(claimRefNbr!=null && claimRefNbr!=null && claimRefNbr!='')?claimRefNbr:document.hpeEncounterForm.firstClaimRefNbr.value;
								    					claimDetail.selectedClaimRevNbr=(claimRevNbr!=null && claimRevNbr!=null && claimRevNbr!='')?claimRevNbr:document.hpeEncounterForm.firstClaimRevNbr.value;
								    					claimDetail.selectedClaimSeqNbr=(claimSeqNbr!=null && claimSeqNbr!=null && claimSeqNbr!='')?claimSeqNbr:document.hpeEncounterForm.firstClaimSeqNbr.value;
								    					claimDetail.editableCndSeqNbr=0;
								    					
								    					
								    	    		rowStr=
								    					"<tr class=\""+rowClassId+"\" id=\""+procCodeRowId+"\">"+
								    				    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtProcTypeId+"\">"+procTypeValue+"</span>&nbsp; <input name=\""+updateTxtProcTypeId+"\"  id=\""+updateTxtProcTypeId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"3\" value=\""+procTypeValue+"\"></td>" +
								    				    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtProcCodeId+"\">"+procCodeValue+"</span>&nbsp; <input name=\""+updateTxtProcCodeId+"\"  id=\""+updateTxtProcCodeId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"7\" value=\""+procCodeValue+"\"></td>" +
								    				    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtProcDateId+"\">"+procDateValue+"</span>&nbsp; <input name=\""+updateTxtProcDateId+"\"  id=\""+updateTxtProcDateId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"10\" value=\""+procDateValue+"\"></td>" +
								    				    "<td align=\"center\" class=\""+rowClassId+"\">"+ 
								    				"<input height=\"20\" id=\""+updateBtnProcCodeId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableDiagField('"+spanUpdateTxtProcTypeId+"','"+updateTxtProcTypeId+"','"+spanUpdateTxtProcCodeId+"','"+updateTxtProcCodeId+"','"+spanUpdateTxtProcDateId+"','"+updateTxtProcDateId+"','"+updateBtnProcCodeId+"','"+updateSaveBtnProcCodeId+"','"+updateCancelBtnProcCodeId+"')\" type=\"button\" value=\"Update\" /> "+
								    					    "<input name=\""+updateSaveBtnProcCodeId+"\" height=\"20\" id=\""+updateSaveBtnProcCodeId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableSaveField('"+mfId+"','"+clmNbr+"','"+clmRvNbr+"','"+clmSqNbr+"','"+cndSqNbr+"','PROC_CODE','"+loadImageProcCodeId+"','"+updateTxtProcCodeId+"','"+updateTxtProcTypeId+"','0','"+updateTxtProcDateId+"','0','0','0','clmtype','"+claimDetail.searchDetailClmType+"','"+idNum+"')\" type=\"button\" value=\"Save\" />"+
								    					    "<input name=\""+updateCancelBtnProcCodeId+"\" height=\"20\" id=\""+updateCancelBtnProcCodeId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableDiagCancelField('"+spanUpdateTxtProcTypeId+"','"+updateTxtProcTypeId+"','"+spanUpdateTxtProcCodeId+"','"+updateTxtProcCodeId+"','"+spanUpdateTxtProcDateId+"','"+updateTxtProcDateId+"','"+updateBtnProcCodeId+"','"+updateSaveBtnProcCodeId+"','"+updateCancelBtnProcCodeId+"')\" type=\"button\" value=\"Cancel\" />"+
								    					    "<span id=\""+loadImageProcCodeId+"\" style=\"display: none;\"> <img alt=\"Loading\" src=\"/mss/jsp/Recon/images/Loading.gif\"></span>"+ 
								    										
								    					"</td>"+
								    					"<td align=\"center\" class=\""+rowClassId+"\">"+
								    					                             
								    					"<input name=\""+deleteProcBtnId+"\" height=\"20\" id=\""+deleteProcBtnId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableDeleteField('"+mfId+"','"+clmNbr+"','"+clmRvNbr+"','"+clmSqNbr+"','"+cndSqNbr+"','PROC_CODE','"+loadImageProcCodeId+"','"+updateTxtProcCodeId+"','"+updateTxtProcTypeId+"','0','"+updateTxtProcDateId+"','0','0','0','clmtype','"+claimDetail.searchDetailClmType+"','"+idNum+"')\" type=\"button\" value=\"Delete\" />"+
								    					                            
								    					"</td>"+
								    				"</tr>"	;	
								    	    		
								    	    		
								    	    		rowStr=
								    					"<tr class=\""+rowClassId+"\" id=\""+procCodeRowId+"\">"+
								    				    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtProcTypeId+"\">"+procTypeValue+"</span>&nbsp; <input name=\""+updateTxtProcTypeId+"\"  id=\""+updateTxtProcTypeId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"3\" value=\""+procTypeValue+"\"></td>" +
								    				    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtProcCodeId+"\">"+procCodeValue+"</span>&nbsp; <input name=\""+updateTxtProcCodeId+"\"  id=\""+updateTxtProcCodeId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"7\" value=\""+procCodeValue+"\"></td>" +
								    				    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtProcDateId+"\">"+procDateValue+"</span>&nbsp; <input name=\""+updateTxtProcDateId+"\"  id=\""+updateTxtProcDateId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"10\" value=\""+procDateValue+"\"></td>" +
								    				    "<td align=\"center\" class=\""+rowClassId+"\">"+ 
								    				    "<input height=\"20\" id=\""+updateBtnProcCodeId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableDiagField('"+spanUpdateTxtProcTypeId+"','"+updateTxtProcTypeId+"','"+spanUpdateTxtProcCodeId+"','"+updateTxtProcCodeId+"','"+spanUpdateTxtProcDateId+"','"+updateTxtProcDateId+"','"+updateBtnProcCodeId+"','"+updateSaveBtnProcCodeId+"','"+updateCancelBtnProcCodeId+"')\" type=\"button\" value=\"Update\" /> "+
								    					    "<input name=\""+updateSaveBtnProcCodeId+"\" height=\"20\" id=\""+updateSaveBtnProcCodeId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableSaveField('"+mfId+"','"+clmNbr+"','"+clmRvNbr+"','"+clmSqNbr+"','"+cndSqNbr+"','PROC_CODE','"+loadImageProcCodeId+"','"+updateTxtProcCodeId+"','"+updateTxtProcTypeId+"','0','"+updateTxtProcDateId+"','0','0','0','clmtype','"+claimDetail.searchDetailClmType+"','"+idNum+"')\" type=\"button\" value=\"Save\" />"+
								    					    "<input name=\""+updateCancelBtnProcCodeId+"\" height=\"20\" id=\""+updateCancelBtnProcCodeId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableDiagCancelField('"+spanUpdateTxtProcTypeId+"','"+updateTxtProcTypeId+"','"+spanUpdateTxtProcCodeId+"','"+updateTxtProcCodeId+"','"+spanUpdateTxtProcDateId+"','"+updateTxtProcDateId+"','"+updateBtnProcCodeId+"','"+updateSaveBtnProcCodeId+"','"+updateCancelBtnProcCodeId+"')\" type=\"button\" value=\"Cancel\" />"+
								    					    "<span id=\""+loadImageProcCodeId+"\" style=\"display: none;\"> <img alt=\"Loading\" src=\"/mss/jsp/Recon/images/Loading.gif\"></span>"+ 
								    										
								    					"</td>"+
								    					"<td align=\"center\" class=\""+rowClassId+"\">"+
								    					                             
								    					"<input name=\""+deleteProcBtnId+"\" height=\"20\" id=\""+deleteProcBtnId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableDeleteField('"+mfId+"','"+clmNbr+"','"+clmRvNbr+"','"+clmSqNbr+"','"+cndSqNbr+"','PROC_CODE','"+loadImageProcCodeId+"','"+updateTxtProcCodeId+"','"+updateTxtProcTypeId+"','0','"+updateTxtProcDateId+"','0','0','0','clmtype','"+claimDetail.searchDetailClmType+"','"+idNum+"')\" type=\"button\" value=\"Delete\" />"+
								    					                            
								    					"</td>"+
								    				"</tr>"	;	
								    	    		var tbodyId ='instProcedureCodeTbody'; 
								    	    		var tDivId = 'instProcedureCodeTableDiv';
								    	    		var tbdyElement = document.getElementById(tbodyId);
								    	    		var tDivElement = document.getElementById(tDivId);
								    	    		var tableId="instProcedureCodeTable";
									    	     	var typeL= "";
									    	    	var tab = document.getElementById(tableId);
									    	        var trs= tab.rows;
									    	   	if(typeof trs[1].cells[0].childNodes[1]!=='undefined'){
									    	    		typeL=trs[1].cells[0].childNodes[1].innerHTML;
									    	    		if(typeL=='BR'||typeL=='BBR'){
									    	     		}else{
									    	    			var rowId = document.getElementById('procCodeRow'+ idNum)
											    	    	rowId.style.display = "none";
											    	 		var content = tDivElement.innerHTML;
										    	    		tDivElement.innerHTML = content.replace("<B></B>", "<B></B>"+rowStr);
										    	 		}
									    	    	}else if(typeof trs[2].cells[0].childNodes[1]!=='undefined'){
									    	    		typeL=trs[2].cells[0].childNodes[1].innerHTML;
									    	    		if(typeL=='BR'||typeL=='BBR'){
									    	    		}else{
									    	    			var rowId = document.getElementById('procCodeRow'+ idNum)
											    	    	rowId.style.display = "none";
											    			var content = tDivElement.innerHTML;
										    	    		tDivElement.innerHTML = content.replace("<B></B>", "<B></B>"+rowStr);
										    			}
									    	    	}
									    	    	
								    			//	break;
								    	    		}
								    	    		/* IFOX-00406912 End*/
							    	    	idSvBtn.style.display = "none";
							    	    	idCnlBtn.style.display = "none";
							    	    	idUpBtn.style.display = "";
							    	    	idSpanType.style.display = "";
							    	    	idSpanCode.style.display = "";
							    	    	idSpanDate.style.display = "";
							    	    	idtxtType.style.display = "none";
							    	    	idtxtCode.style.display = "none";
							    	    	idtxtDate.style.display = "none";
					    	    		
							    	    	idSpanType.innerHTML=conType;
							    	    	idSpanCode.innerHTML=condCode;
							    	    	idSpanDate.innerHTML=conDate;
							    	    	
					    	    		    claimStatus.innerHTML='Procedure code Update successfully'
					    	    			loadImg.style.display = "none";
							    	    	}
					    			}						    	    	
						    	    	
						    	    	
						    	    	if( hei=='OCCUR_SPAN_CODE' ){
						    	    		
					    	    		    var idUpBtn = document.getElementById('updateBtnOccurSpanCode'+idNum);
							    	    	var idSpanCode = document.getElementById('spanUpdateTxtOccurSpanCode'+idNum);
							    	    	var idSpanFrmDt = document.getElementById('spanUpdateTxtOccurSpanFromDt'+idNum);
							    	    	var idSpanToDt= document.getElementById('spanUpdateTxtOccurSpanToDt'+idNum);
							    	    	var idtxtCode = document.getElementById('updateTxtOccurSpanCode'+idNum);
							    	    	var idtxtFrmDt = document.getElementById('updateTxtOccurSpanFromDt'+idNum);
							    	    	var idtxtToDt= document.getElementById('updateTxtOccurSpanToDt'+idNum);
							    	    	var idSvBtn = document.getElementById('updateSaveBtnOccurSpanCode'+idNum);
							    	    	var idCnlBtn = document.getElementById('updateCancelBtnOccurSpanCode'+idNum);
							    	    	var claimStatus = document.getElementById('claimCodeStatus');
							    	    	var loadImg = document.getElementById('loadImageOccurSpanCode'+idNum);
							    	    	if(indFlag == 'DEL'){
							    	    		
							    	    		idSvBtn.style.display = "none";
								    	    	idCnlBtn.style.display = "none";
								    	    	idUpBtn.style.display = "";
								    	    	idSpanCode.style.display = "";
								    	    	idSpanFrmDt.style.display = "";
								    	    	idSpanToDt.style.display = "";
								    	    	idtxtCode.style.display = "none";
								    	    	idtxtFrmDt.style.display = "none";
								    	    	idtxtToDt.style.display = "none";
						    	    		
								    	    	idSpanFrmDt.innerHTML=conFrmDt;
								    	    	idSpanCode.innerHTML=condCode;
								    	    	idSpanToDt.innerHTML=conToDt;
								    	    	var rowId = document.getElementById('occurSpanRow'+ idNum)
												rowId.style.display = "none";
								    	    	
						    	    		   claimStatus.innerHTML='Occurrence Span code Deleted successfully'
						    	    			   loadImg.style.display = "none";
							    	    		
							    	    	}else{
							    	    		
							    	    		idSvBtn.style.display = "none";
								    	    	idCnlBtn.style.display = "none";
								    	    	idUpBtn.style.display = "";
								    	    	idSpanCode.style.display = "";
								    	    	idSpanFrmDt.style.display = "";
								    	    	idSpanToDt.style.display = "";
								    	    	idtxtCode.style.display = "none";
								    	    	idtxtFrmDt.style.display = "none";
								    	    	idtxtToDt.style.display = "none";
						    	    		
								    	    	idSpanFrmDt.innerHTML=conFrmDt;
								    	    	idSpanCode.innerHTML=condCode;
								    	    	idSpanToDt.innerHTML=conToDt;
								    	    	
						    	    		    claimStatus.innerHTML='Occurrence Span code Update successfully'
						    	    			loadImg.style.display = "none";
							    	    	}
							    	    	
							    	    	
					    			}	    	
						    	    	

						    	    if( hei=='VALUE_CODE' ){
						    	    		
					    	    		    var idUpBtn = document.getElementById('updateBtnValueCode'+idNum);
							    	    	var idSpanCode = document.getElementById('spanUpdateTxtValueCode'+idNum);
							    	    	var idSpanAmnt = document.getElementById('spanUpdateTxtValueAmnt'+idNum);
							    	    	
							    	    	var idtxtCode = document.getElementById('updateTxtValueCode'+idNum);
							    	    	var idtxtAmnt = document.getElementById('updateTxtValueAmnt'+idNum);
							    	    	
							    	    	var idSvBtn = document.getElementById('updateSaveBtnValueCode'+idNum);
							    	    	var idCnlBtn = document.getElementById('updateCancelBtnValueCode'+idNum);
							    	    	var claimStatus = document.getElementById('claimCodeStatus');
							    	    	var loadImg = document.getElementById('loadImageValueCode'+idNum);
							    	    	if(indFlag == 'DEL'){
							    	    		idSvBtn.style.display = "none";
								    	    	idCnlBtn.style.display = "none";
								    	    	idUpBtn.style.display = "";
								    	    	idSpanCode.style.display = "";
								    	    	idSpanAmnt.style.display = "";
								    	    	
								    	    	idtxtCode.style.display = "none";
								    	    	idtxtAmnt.style.display = "none";
								    	    	
						    	    		
								    	    	idSpanCode.innerHTML=condCode;
								    	    	idSpanAmnt.innerHTML=conAmnt;
								    	    	var rowId = document.getElementById('valueRow'+ idNum)
												rowId.style.display = "none";
								    	    
								    	    	
						    	    		claimStatus.innerHTML='Value code Deleted successfully'
						    	    			loadImg.style.display = "none";
							    	    		
							    	    	}else{
							    	    	
							    	    	idSvBtn.style.display = "none";
							    	    	idCnlBtn.style.display = "none";
							    	    	idUpBtn.style.display = "";
							    	    	idSpanCode.style.display = "";
							    	    	idSpanAmnt.style.display = "";
							    	    	
							    	    	idtxtCode.style.display = "none";
							    	    	idtxtAmnt.style.display = "none";
							    	    	
					    	    		
							    	    	idSpanCode.innerHTML=condCode;
							    	    	idSpanAmnt.innerHTML=conAmnt;
							    	    
							    	    	
					    	    		claimStatus.innerHTML='Value code Update successfully'
					    	    			loadImg.style.display = "none";
							    	    	}
					    			}
						    	    
						    	    
						    	    if( hei=='OCCUR_CODE' ){
					    	    		
				    	    		    var idUpBtn = document.getElementById('updateBtnOccurCode'+idNum);
						    	    	var idSpanCode = document.getElementById('spanUpdateTxtOccurCode'+idNum);
						    	    	var idSpanFrmDt = document.getElementById('spanUpdateTxtOccurDate'+idNum);						    	    	
						    	    	var idtxtCode = document.getElementById('updateTxtOccurCode'+idNum);
						    	    	var idtxtFrmDt = document.getElementById('updateTxtOccurDate'+idNum);						    	    	
						    	    	var idSvBtn = document.getElementById('updateSaveBtnOccurCode'+idNum);
						    	    	var idCnlBtn = document.getElementById('updateCancelBtnOccurCode'+idNum);
						    	    	var claimStatus = document.getElementById('claimCodeStatus');
						    	    	var loadImg = document.getElementById('loadImageOccurCode'+idNum);
						    	    	
						    	    	if(indFlag == 'DEL'){
						    	    		idSvBtn.style.display = "none";
							    	    	idCnlBtn.style.display = "none";
							    	    	idUpBtn.style.display = "";
							    	    	idSpanCode.style.display = "";
							    	    	idSpanFrmDt.style.display = "";
							    	    	
							    	    	idtxtCode.style.display = "none";
							    	    	idtxtFrmDt.style.display = "none";
							    	    	
					    	    		
							    	    	idSpanFrmDt.innerHTML=conDate;
							    	    	idSpanCode.innerHTML=condCode;
							    	    	
							    	    	var rowId = document.getElementById('occurenceRow'+ idNum)
											rowId.style.display = "none";
							    	    	
					    	    		claimStatus.innerHTML='Occurrence code Deleted successfully'
					    	    			loadImg.style.display = "none";
						    	    		
						    	    	}else{
						    	    		idSvBtn.style.display = "none";
							    	    	idCnlBtn.style.display = "none";
							    	    	idUpBtn.style.display = "";
							    	    	idSpanCode.style.display = "";
							    	    	idSpanFrmDt.style.display = "";
							    	    	
							    	    	idtxtCode.style.display = "none";
							    	    	idtxtFrmDt.style.display = "none";
							    	    	
					    	    		
							    	    	idSpanFrmDt.innerHTML=conDate;
							    	    	idSpanCode.innerHTML=condCode;
							    	    	
							    	    	
					    	    		claimStatus.innerHTML='Occurrence code Update successfully'
					    	    			loadImg.style.display = "none";
						    	    		
						    	    	}
						    	    	
						    	    	
				    			}	 
						    	    	
						    	    if( hei=='EXT_INJ_CODE' ){
					    	    		
				    	    		    var idUpBtn = document.getElementById('updateBtnExtInjCode'+idNum);
						    	    	var idSpanType = document.getElementById('spanUpdateTxtExtInjType'+idNum);
						    	    	var idSpanCode = document.getElementById('spanUpdateTxtExtInjCode'+idNum);
						    	    	var idSpanPOA = document.getElementById('spanUpdateTxtExtInjPOA'+idNum);
						    	    	var idtxtType = document.getElementById('updateTxtExtInjType'+idNum);
						    	    	var idtxtCode = document.getElementById('updateTxtExtInjCode'+idNum);
						    	    	var idtxtPOA = document.getElementById('updateTxtExtInjPOA'+idNum);
						    	    	var idSvBtn = document.getElementById('updateSaveBtnExtInjCode'+idNum);
						    	    	var idCnlBtn = document.getElementById('updateCancelBtnExtInjCode'+idNum);
						    	    	var claimStatus = document.getElementById('claimCodeStatus');
						    	    	var loadImg = document.getElementById('loadImageExtInjCode'+idNum);
						    	    	
						    	    	if(indFlag == 'DEL'){
						    	    		
						    	    		idSvBtn.style.display = "none";
							    	    	idCnlBtn.style.display = "none";
							    	    	idUpBtn.style.display = "";
							    	    	idSpanType.style.display = "";
							    	    	idSpanCode.style.display = "";
							    	    	idSpanPOA.style.display = "";
							    	    	idtxtType.style.display = "none";
							    	    	idtxtCode.style.display = "none";
							    	    	idtxtPOA.style.display = "none";
					    	    		
							    	    	idSpanType.innerHTML=conType;
							    	    	idSpanCode.innerHTML=condCode;
							    	    	idSpanPOA.innerHTML=conPOA;
							    	    	
							    	    	

							    	    	var rowId = document.getElementById('externalInjRow'+ idNum)
											rowId.style.display = "none";
							    	    	
					    	    		claimStatus.innerHTML='External Injury code Deleted successfully'
					    	    			loadImg.style.display = "none";
						    	    	}
						    	    	else
						    	    		{
						    	    		idSvBtn.style.display = "none";
							    	    	idCnlBtn.style.display = "none";
							    	    	idUpBtn.style.display = "";
							    	    	idSpanType.style.display = "";
							    	    	idSpanCode.style.display = "";
							    	    	idSpanPOA.style.display = "";
							    	    	idtxtType.style.display = "none";
							    	    	idtxtCode.style.display = "none";
							    	    	idtxtPOA.style.display = "none";
					    	    		
							    	    	idSpanType.innerHTML=conType;
							    	    	idSpanCode.innerHTML=condCode;
							    	    	idSpanPOA.innerHTML=conPOA;
							    	    	
					    	    		claimStatus.innerHTML='External Injury code Update successfully'
					    	    			loadImg.style.display = "none";
						    	    		}
						    	    	
						    	    	
				    			}   
				    			//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
						    	    if(hei=='ADJUD_ADJUST' ){
					    	    		   
				    	    		    var idUpBtn = document.getElementById('updateBtnAdjudAdjust'+idNum);
						    	    	var idSpanCode = document.getElementById('spanUpdateTxtCode'+idNum);
						    	    	var idtxtCode = document.getElementById('updateTxtCode'+idNum);
						    	    	var idSpanReason = document.getElementById('spanUpdateTxtReason'+idNum);
						    	    	var idtxtReason = document.getElementById('updateTxtReason'+idNum);
						    	    	var idSpanAmount = document.getElementById('spanUpdateTxtAmount'+idNum);
						    	    	var idtxtAmount = document.getElementById('updateTxtAmount'+idNum);
						    	    	var idSpanQuantity = document.getElementById('spanUpdateTxtQuantity'+idNum);
						    	    	var idtxtQuantity = document.getElementById('updateTxtQuantity'+idNum);
						    	    	var idSvBtn = document.getElementById('updateSaveBtnAdjudAdjust'+idNum);
						    	    	var idCnlBtn = document.getElementById('updateCancelBtnAdjudAdjust'+idNum);
						    	    	var claimStatus = document.getElementById('adjustUpdateStatus');
						    	    	var loadImg = document.getElementById('loadImageAdjudAdjust'+idNum);

											 if (indFlag == 'DEL') {
														idSvBtn.style.display = "none";
														idCnlBtn.style.display = "none";
														idUpBtn.style.display = "none";
														idSpanCode.style.display = "none";
														idtxtCode.style.display = "none";
														idSpanReason.style.display = "none";
														idtxtReason.style.display = "none";
														idSpanAmount.style.display = "none";
														idtxtAmount.style.display = "none";
														idSpanQuantity.style.display = "none";
														idtxtQuantity.style.display = "none";

														var adjudseqnbr = document.getElementById('updateTxtAdjudSeqNbr'+idNum).value;
														var adjustseqnbr = document.getElementById('updateTxtAdjustSeqNbr'+idNum).value;
														var clmliseqnbr = document.getElementById('updateTxtClmliSeqNbr'+idNum).value;
														/*var delRowId = 'trInstLineAdjudicationAdjustment'+ clmliseqnbr+'-'+adjustseqnbr;
														var rowId = document.getElementById(delRowId);
																alert(rowId);
														rowId.style.display = "none";*/
														var tdId1 = document.getElementById('id1'+ idNum)
														var tdId2 = document.getElementById('id2'+ idNum)
														var tdId3 = document.getElementById('id3'+ idNum)
														var tdId4 = document.getElementById('id4'+ idNum)
														var tdId5 = document.getElementById('id5'+ idNum)
														var tdId6 = document.getElementById('id6'+ idNum)

														tdId1.style.display = "none";
														tdId2.style.display = "none";
														tdId3.style.display = "none";
														tdId4.style.display = "none";
														tdId5.style.display = "none";
														tdId6.style.display = "none";
														params = params + "&adjudseqnbr="+adjudseqnbr+"&adjustseqnbr="+adjustseqnbr+"&clmliseqnbr="+clmliseqnbr;
														claimStatus.innerHTML = 'Claim Line Adjudication Adjustment Deleted successfully'
															loadImg.style.display = "none";
														
													} 
											 		else if (indFlag == 'DELIN') {
														var adjrowid = document.getElementById('adjudAdjustRow'+idNum);
														adjrowid.style.display = "none";
											 			claimStatus.innerHTML = 'Claim Line Adjudication Adjustment Deleted successfully'
															loadImg.style.display = "none";
													 }
											 		else {
															idSvBtn.style.display = "none";
															idCnlBtn.style.display = "none";
															idUpBtn.style.display = "";
														if(heir1!='ADJUD_ADJUST_IN'){
															idSpanCode.style.display = "";
															idtxtCode.style.display = "none";
															idSpanReason.style.display = "";
															idtxtReason.style.display = "none";
															idSpanAmount.style.display = "";
															idtxtAmount.style.display = "none";
															idSpanQuantity.style.display = "";
															idtxtQuantity.style.display = "none";
								
															idSpanCode.innerHTML = condCode;
															idSpanReason.innerHTML = conReason;
															idSpanAmount.innerHTML = conAmount;
															idSpanQuantity.innerHTML = conQuantity;
														}else{
															var adjadjustcode = document.getElementById('updateTxtAdjudAdjust'+idNum);
															var adjadjustreason = document.getElementById('updateTxtAdjudAdjustReason'+idNum);
															var adjadjustamount = document.getElementById('updateTxtAdjudAdjustAmount'+idNum);
															var adjadjustquantity = document.getElementById('updateTxtAdjudAdjustQuantity'+idNum);
															var spanadjadjustcode = document.getElementById('spanUpdateTxtAdjudAdjust'+idNum);
															var spanadjadjustreason = document.getElementById('spanUpdateTxtAdjudAdjustReason'+idNum);
															var spanadjadjustamount = document.getElementById('spanUpdateTxtAdjudAdjustAmount'+idNum);
															var spanadjadjustquantity = document.getElementById('spanUpdateTxtAdjudAdjustQuantity'+idNum);
															adjadjustcode.style.display = "none";
															adjadjustreason.style.display = "none";
															adjadjustamount.style.display = "none";
															adjadjustquantity.style.display = "none";
															spanadjadjustcode.style.display = "";
															spanadjadjustreason.style.display = "";
															spanadjadjustamount.style.display = "";
															spanadjadjustquantity.style.display = "";
															spanadjadjustcode.innerHTML = condCode;
															spanadjadjustreason.innerHTML = conReason;
															spanadjadjustamount.innerHTML = conAmount;
															spanadjadjustquantity.innerHTML = conQuantity;
														}
														
														claimStatus.innerHTML = 'Claim Line Adjudication Adjustment Updated successfully'
															loadImg.style.display = "none";
													}	
					    	    		
					    			}

						    	    	
					    	      }//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End
					    	   
					    	
					    	    };
					   
					      try {
					      request.open("POST", url+"?"+params, true);
					      } catch (e) {
					         alert("Unable to connect to server to retrieve count.");
					      }
					   
					      request.send(null);
					    // Perform the AJAX request using an IE browser.
					    } else if (window.ActiveXObject) {
					      request = new ActiveXObject("Microsoft.XMLHTTP");
					   
					      if (request) {
					        // Register callback function that will be called when
					        // the response is generated from the server.
					        
					        request.open("POST", url, true);
					        request.send();
					      }
					    }
					   
				
					   
				} else {
					alert('Please Enter Valid Code');
					
					 loadImg.style.display='none';
	    			 document.body.className = '';
				}

}




function UpdatableDeleteField(mfId, clmNbr, clmRvNbr,clmSqNbr, cndSqNbr, heir, loadImg,code,type,poa,date,from,thru,amnt, claimType, encType, idNum){
	
	var loadImg =document.getElementById(loadImg);	
	loadImg.style.display = "";
	//alert("DeleteFunction-->"+mfId+"-"+clmNbr+"-"+clmRvNbr+"-"+clmSqNbr+"-"+cndSqNbr+"-"+heir +"-"+idNum);
	var parmsEdit;
	if(heir != null && heir != '' && heir!='undefined'){
		if(heir=='COND_CODE' || heir=='TRTMNT_CODE' ){
			var code = document.getElementById(code).value;
			parmsEdit="code="+code ;
		}
		if(heir=='DIAG_CODE' || heir=='EXT_INJ_CODE'){
			var code = document.getElementById(code).value;
			var type = document.getElementById(type).value;
			var poa = document.getElementById(poa).value;			
			parmsEdit= "type="+type+"&code="+code+"&poa="+poa;		
		}
		if(heir=='PROC_CODE'){
			var code = document.getElementById(code).value;
			var type = document.getElementById(type).value;
			var date = document.getElementById(date).value;
			parmsEdit= "type="+type+"&code="+code+"&date="+date;
		}
		if(heir=='OCCUR_SPAN_CODE'){
			var code = document.getElementById(code).value;
			var from = document.getElementById(from).value;
			var thru = document.getElementById(thru).value;			
			parmsEdit="code="+code+"&from="+from+"&thru="+thru ;
		}
		if(heir=='VALUE_CODE'){
			var code = document.getElementById(code).value;
			var amnt = document.getElementById(amnt).value;
			parmsEdit= "code="+code+"&amnt="+amnt;
		}
		if(heir=='OCCUR_CODE'){
			var code = document.getElementById(code).value;
			var date = document.getElementById(date).value;
			parmsEdit="code="+code+"&date="+date;
		}
		//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
		var adjudseqnbr = '';
		var adjustseqnbr = '';
		var clmliseqnbr = ''
		if(heir=='ADJUD_ADJUST'){
			
			var code = document.getElementById(code).value;
			var reason = document.getElementById(type).value;
			var amount = document.getElementById(poa).value;
			var quantity = document.getElementById(date).value;
			parmsEdit="code="+code+"&reason="+reason+"&amount="+amount+"&quantity="+quantity;
		}
		if(heir=='ADJUD_ADJUST_IN'){
			var code = document.getElementById('updateTxtAdjudAdjust'+idNum).value;
			var reason = document.getElementById('updateTxtAdjudAdjustReason'+idNum).value;
			var amount = document.getElementById('updateTxtAdjudAdjustAmount'+idNum).value;
			var quantity = document.getElementById('updateTxtAdjudAdjustQuantity'+idNum).value;
			var adjudseqnbr = from.trim();//IFOX-00416992 - Browser Compatibility issue
			var adjustseqnbr = cndSqNbr;
			var clmliseqnbr = thru.trim();//IFOX-00416992 - Browser Compatibility issue
			parmsEdit="code="+code+"&reason="+reason+"&amount="+amount+"&quantity="+quantity;
		}
		//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End
			parmsEdit=parmsEdit+"&encType="+encType+"&delFlag=DEL";
	}
	
	
    var r = confirm(heir+ " will be deleted from the claim");	        	
    if (r == true) {
    	//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
    	if(heir=='ADJUD_ADJUST_IN'){
    		UpdateFieldAjax(mfId,clmNbr,clmRvNbr,clmSqNbr,cndSqNbr,heir,loadImg,parmsEdit,idNum,'DELIN',adjudseqnbr,adjustseqnbr,clmliseqnbr);
    	}else{
    		UpdateFieldAjax(mfId,clmNbr,clmRvNbr,clmSqNbr,cndSqNbr,heir,loadImg,parmsEdit,idNum,'DEL',adjudseqnbr,adjustseqnbr,clmliseqnbr);
    	}
    	//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End
    	loadImg.style.display = "none";
    }else{ //IFOX-00397153
    	loadImg.style.display = "none";
    }
	
		
}



function addFields(mfId, clmNbr, clmRvNbr,clmSqNbr, heir, loadImg,code,type,poa,date,from,thru,amnt){
	  
	   
	   document.getElementById('hier').value = heir;
	   
	   document.body.className = 'wait';
	   var validFlag=true;
	   var errorMsg='';
	   var claimType=null;
	   var codeId = code;
	   var typeId = type;
	   var poaId = poa;
	   var dateId = date;
	   var fromId = from;
	   var thruId = thru;
	   var amntId = amnt;
	   //IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
	   var adjudGroupCode = code;
	   var adjudReasonCode = type;
	   var adjudAmount = poa;
	   var adjudQuantity = date;
	   var clmliAdjudSeqNbr = amnt;
//	   var clmLiSqNbr = thru;
		//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End
	   var heirFieldName=getHeirFieldName(heir);
	   var claimTypeSearch = document.getElementsByName("searchDetailEncType");		//Using the selected encType(I/P/E) from search form as values are hardcoded in respective jsp
	   var errorList= []; errorList.push('Invalid '+heirFieldName);
		if(claimTypeSearch.length>0){
			claimType=claimTypeSearch[0].value
		}else{
			alert('Could not find Claim Type');
			return false;
		}
		var clmTypeStr=	document.hpeEncounterForm.searchDetailClmType.value;		//Using the selected claimType(EN/CR) from search form as values are hardcoded in respective jsp
		var claimRefNbr=document.hpeEncounterForm.selectedClaimRefNbr.value;
		var claimRevNbr=document.hpeEncounterForm.selectedClaimRevNbr.value;
		var claimSeqNbr=document.hpeEncounterForm.selectedClaimSeqNbr.value;
		
		//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
		var claimDetail={	editableMfid:null,			searchDetailClmType:null,	searchDetailEncType:null,	selectedClaimRefNbr:null,
							selectedClaimRevNbr:null,	selectedClaimSeqNbr:null,	editableCndSeqNbr:null,		editableCode:null,
							editableType:null,			editablePOA:null,			editableDate:null,			editableFromDt:null,
							editableThruDt:null,		editableAmount:null,		userId:null,				adjudGroupCode:null,
							adjudReasonCode:null,		adjudAmount:null,			adjudQuantity:null,			clmliAdjudSeqNbr:null,
							clmliSeqNbr:null
						};
		//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End
		
		claimDetail.hier=heir;
		claimDetail.editableMfid='';
		claimDetail.searchDetailClmType=clmTypeStr; 
		claimDetail.searchDetailEncType=claimType;
		claimDetail.selectedClaimRefNbr=(claimRefNbr!=null && claimRefNbr!=null && claimRefNbr!='')?claimRefNbr:document.hpeEncounterForm.firstClaimRefNbr.value;
		claimDetail.selectedClaimRevNbr=(claimRevNbr!=null && claimRevNbr!=null && claimRevNbr!='')?claimRevNbr:document.hpeEncounterForm.firstClaimRevNbr.value;
		claimDetail.selectedClaimSeqNbr=(claimSeqNbr!=null && claimSeqNbr!=null && claimSeqNbr!='')?claimSeqNbr:document.hpeEncounterForm.firstClaimSeqNbr.value;
		claimDetail.editableCndSeqNbr=0;

		//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
		if(heir!='ADJUD_ADJUST'){
			 claimDetail.adjudGroupCode= '';
			 claimDetail.adjudReasonCode= '';
			 claimDetail.adjudAmount= '';
			 claimDetail.adjudQuantity= '';
			 claimDetail.clmliAdjudSeqNbr= '';
			 claimDetail.clmliSeqNbr= '';
		}
		//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End
		
	   if(heir != null && heir != '' && heir!='undefined'){

		   if(heir=='COND_CODE'){
				var code = document.getElementById(codeId).value;
				if(code!=null && code!=''){
					if(claimType == 'I'){									
						if(!validateAlphaNumeric(code))		{errorList.push('Code should be alphanumeric')}
						if(!validateFieldSize(code,2,'ET'))	{errorList.push('Code should be max of 2 character')}
					}else if((claimType == 'P') || (claimType == 'E')){
						if(!validateAlphaNumeric(code))		{errorList.push('Code should be alphanumeric')}
						if(!validateFieldSize(code,2,'ET'))	{errorList.push('Code should be max of 2 character')}
					}
					
				}else{
					errorList.push('This field cannot be empty.');	
				}
				
				if(errorList.length <=1){ 
					document.getElementById('editableCode').value = code.toUpperCase();

					claimDetail.editableCode= code.toUpperCase();
					
				}
				
			}
		   if(heir=='TRTMNT_CODE'){
				var code = document.getElementById(codeId).value;
				if(code!=null && code!=''){
					if(claimType == 'I'){									
						if(!validateAlphaNumeric(code))			{errorList.push('Code should be alphanumeric')}
						if(!validateFieldSize(code,30,'LET'))	{errorList.push('Code should be max of 30 character')}
					}else if((claimType == 'P') || (claimType == 'E')){
						if(!validateAlphaNumeric(code))			{errorList.push('Code should be alphanumeric')}
						if(!validateFieldSize(code,30,'LET'))	{errorList.push('Code should be max of 30 character')}
					}
					
				}else{
					errorList.push('This field cannot be empty.');	
				}
				
				if(errorList.length <=1){ 
					document.getElementById('editableCode').value = code.toUpperCase();
					
					claimDetail.editableCode= code.toUpperCase();
				}
				
			}

			if(heir=='DIAG_CODE'){			
				var code = document.getElementById(codeId).value;
				var type = document.getElementById(typeId).value;
				var poa = document.getElementById(poaId).value;		
				
				var date = document.getElementById('svcDate').value+'';
				var ICD = ((date!=null && date!='')&&(date > '20151001')) ? 3:2;
				
				//IFOX-00407127 -- Updateable Fields - Primary Diagnosis - Start
				if((claimType == 'I' && code!=null & code!='' && type!=null && type!='') || 	
						(claimType == 'P' && code!=null & code!='' && type!=null && type!='' ) ||
							(claimType == 'E' && code!=null & code!='' && type!=null && type!='' )){
				//IFOX-00407127 -- Updateable Fields - Primary Diagnosis - End					
					if(claimType == 'I'){
						//IFOX-00407127 -- Updateable Fields - Primary Diagnosis - Start
						if(type == 'BK' || type=='ABK'){errorList.push('Principal diagnosis code cannot be added.')}
						//IFOX-00407127 -- Updateable Fields - Primary Diagnosis - End
						if(!validateAlphaOnly(type))			{errorList.push('Type should be alphabets only.')}
						if(!validateFieldSize(type,ICD,'ET'))	{errorList.push('Type should be of '+ICD+' character.')}				
						if(!validateAlphaNumeric(code))			{errorList.push('Code should be alphanumeric.')}
						if(!validateFieldSize(code,7,'LET'))	{errorList.push('Code should be max of 7 character.')}					
						if(poa!=null && poa!='' && !validateAlphaYN(poa))				{errorList.push('Present On Admit can only be Y/N/U/W.')}	//IFOX-00407127 -- Updateable Fields - Primary Diagnosis
						if(checkDuplicateDiagCode(claimType,code,type,poa))	{errorList.push('Duplicate Code.Please enter a different combination')}
					}else if((claimType == 'P') || (claimType == 'E')){
						//IFOX-00407127 -- Updateable Fields - Primary Diagnosis - Start
						if(type == 'BK' || type=='ABK'){errorList.push('Principal diagnosis code cannot be added.')}
						//IFOX-00407127 -- Updateable Fields - Primary Diagnosis - End
						if(!validateAlphaOnly(type))			{errorList.push('Type should be alphabets only')}
						if(!validateFieldSize(type,ICD,'ET'))	{errorList.push('Type should be of '+ICD+' character')}				
						if(!validateAlphaNumeric(code))			{errorList.push('Code should be alphanumeric')}
						if(!validateFieldSize(code,7,'LET'))	{errorList.push('Code should be max of 7 character')}					
						//if(!validateAlphaYN(poa))			{validFlag = false; errorMsg='Invalid'+heirFieldName +'.Present On Admit can only be Y/N'}	- Not needed for professional
						//if(checkDuplicateDiagCode(claimType,code,type,poa))	{errorList.push('Duplicate Code.Please enter a different combination')}
					}
						
				}else{
					errorList.push('This field cannot be empty.');		
				}
				if(errorList.length <=1) {
					document.getElementById('editableType').value = type.toUpperCase();
					document.getElementById('editableCode').value = code.toUpperCase();
					document.getElementById('editablePOA').value = poa.toUpperCase();
					
					claimDetail.editableType= type.toUpperCase();
					claimDetail.editableCode= code.toUpperCase();
					claimDetail.editablePOA= poa.toUpperCase();
				}
			}		   
			if(heir=='EXT_INJ_CODE'){			
				var code = document.getElementById(codeId).value;
				var type = document.getElementById(typeId).value;
				var poa = document.getElementById(poaId).value;		
				
				var date = document.getElementById('svcDate').value+'';
				var ICD = ((date!=null && date!='')&&(date > '20151001')) ? 3:2;
				//var ICD=3;
				
				if(code!=null & code!='' && type!=null && type!='' && poa!=null && poa!=''){
									
					if(claimType == 'I'){
						if(!validateAlphaOnly(type))			{errorList.push('Type should be alphabets only.')}
						if(!validateFieldSize(type,ICD,'ET'))	{errorList.push('Type should be of '+ICD+' character.')}				
						//if(!validateNumeric(code))				{errorList.push('Code should be numeric.')}
						if(!validateFieldSize(code,30,'LET'))	{errorList.push('Code should be max of 30 digit.')}					
						if(!validateAlphaYN(poa))				{errorList.push('Present On Admit can only be Y/N.')}
					}else if((claimType == 'P') || (claimType == 'E')){
						if(!validateAlphaOnly(type))			{errorList.push('Type should be alphabets only')}
						if(!validateFieldSize(type,ICD,'ET'))	{errorList.push('Type should be of '+ICD+' character')}				
						//if(!validateNumeric(code))				{errorList.push('Code should be numeric.')}
						if(!validateFieldSize(code,30,'LET'))	{errorList.push('Code should be max of 30 digit.')}					
						//if(!validateAlphaYN(poa))			{validFlag = false; errorMsg='Invalid'+heirFieldName +'.Present On Admit can only be Y/N'}	- Not needed for professional
						
					}
						
				}else{
					errorList.push('This field cannot be empty.');		
				}
				if(errorList.length <=1) {
					document.getElementById('editableType').value = type.toUpperCase();
					document.getElementById('editableCode').value = code.toUpperCase();
					document.getElementById('editablePOA').value = poa.toUpperCase();
					
					claimDetail.editableType= type.toUpperCase();
					claimDetail.editableCode= code.toUpperCase();
					claimDetail.editablePOA= poa.toUpperCase();
				}
			}		   

			if(heir=='PROC_CODE'){
				var code = document.getElementById(codeId).value;
				var type = document.getElementById(typeId).value;
				var date = document.getElementById(dateId).value;
				if(type!=null && type!='' && code!=null && code!='' && date!=null && date!=''){
					if(claimType == 'I'){
						if(!validateAlphaOnly(type))			{errorList.push('Type should be alphabets only')}
						if(!validateFieldSize(type,3,'LET'))	{errorList.push('Type should be max of 3 character')}				
						if(!validateAlphaNumeric(code))			{errorList.push('Code should be alphanumeric')}
						if(!validateFieldSize(code,7,'LET'))	{errorList.push('Code should be max of 7 character')}					
						if(!isValidDate(date))					{errorList.push('Date should be of the format MM/DD/YYYY')}
						
					}else if((claimType == 'P') || (claimType == 'E')){
						//- No validation needed for professional
					}				
				}else{
					errorList.push('This field cannot be empty.');
				}
				if(errorList.length <=1) {
					document.getElementById('editableType').value = type.toUpperCase();
					document.getElementById('editableCode').value = code.toUpperCase();
					document.getElementById('editableDate').value = date.toUpperCase();

					claimDetail.editableType= type.toUpperCase();
					claimDetail.editableCode= code.toUpperCase();					
					claimDetail.editableDate= date.toUpperCase();
				}
				
			}			

			if(heir=='OCCUR_SPAN_CODE'){
				var code = document.getElementById(codeId).value;
				var from = document.getElementById(fromId).value;
				var thru = document.getElementById(thruId).value;	
				
				if(code!=null && code!='' && from!=null && from!='' && thru!=null && thru!=''){
										
					if(claimType == 'I'){
										
						if(!validateAlphaNumeric(code))				{errorList.push('Code should be alphanumeric')}
						if(!validateFieldSize(code,18,'LET'))		{errorList.push('Code should be max of 18 character')}
						
						if(!isValidDate(from) && !isValidDate(thru)){errorList.push('From Date & Through Date should be of the format MM/DD/YYYY')}						
						else if(compareDate(from,thru)>0 )			{errorList.push('From Date should be older than Through Date')}						
						
					}else if((claimType == 'P') || (claimType == 'E')){
						//- No validation needed for professional					
					}
					
				}else{
					errorList.push('This field cannot be empty.');
				}
				if(errorList.length <=1) {
					document.getElementById('editableCode').value = code.toUpperCase();
					document.getElementById('editableFromDt').value = from.toUpperCase();
					document.getElementById('editableThruDt').value = thru.toUpperCase();
					
					claimDetail.editableCode= code.toUpperCase();
					claimDetail.editableFromDt=from.toUpperCase();
					claimDetail.editableThruDt=thru.toUpperCase();
				}
				
			}			

			if(heir=='VALUE_CODE'){
				var code = document.getElementById(codeId).value;
				var amnt = document.getElementById(amntId).value;
				var amnt=amnt.replace('$','');
				if(code!=null && code!='' && amnt!=null && amnt!=''){
					
					if(claimType == 'I'){
						
						if(!validateAlphaNumeric(code))			{errorList.push('Code should be alphanumeric')}
						if(!validateFieldSize(code,2,'LET'))	{errorList.push('Code should be max of 2 character')}
						
						if(!validateDecimalFormat(amnt,9,2))	{errorList.push('Amount can have max 9 digit decimal and 2 digit of fractional value')}
						
						
					}else if((claimType == 'P') || (claimType == 'E')){
						//- No validation needed for professional
					}
					
				}else{
					errorList.push('This field cannot be empty.');
				}
				if(errorList.length <=1) {
					document.getElementById('editableCode').value = code.toUpperCase();
					document.getElementById('editableAmount').value = amnt;
					claimDetail.editableCode= code.toUpperCase();
					claimDetail.editableAmount=amnt;
				}
			}			

			if(heir=='OCCUR_CODE'){
				var code = document.getElementById(codeId).value;
				var date = document.getElementById(dateId).value;
				if(code!=null && code!='' && date!=null && date!=''){
					
					if(claimType == 'I'){
						
						if(!validateAlphaNumeric(code))			{errorList.push('Code should be alphanumeric')}
						if(!validateFieldSize(code,7,'LET'))	{errorList.push('Code should be max of 7 character')}
						if(!isValidDate(date))					{errorList.push('Date should be of the format MM/DD/YYYY')}
						
					}else if((claimType == 'P') || (claimType == 'E')){
						//- No validation needed for professional
					}
				}else{
					errorList.push('This field cannot be empty.');
				}
				if(errorList.length <=1) {
					 document.getElementById('editableCode').value = code.toUpperCase();
					 document.getElementById('editableDate').value = date;
					 claimDetail.editableCode= code.toUpperCase();
					 claimDetail.editableDate= date;
				}
				
			}	
			//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
			if(heir=='ADJUD_ADJUST'){
				
				var code = document.getElementById(adjudGroupCode).value;
				var reason = document.getElementById(adjudReasonCode).value;
				var amount = document.getElementById(adjudAmount).value;
				var quantity = document.getElementById(adjudQuantity).value;
//				var claimliseqnbr = document.getElementById(clmliAdjudSeqNbr).value;
//				alert("before"+);
				var clmseqnbr = document.getElementById("clmSeqNbr").innerText;
				var clmliseqnbr = document.getElementById("clmliSeqNbr").innerText;
				var clmliadjudseqnbr = document.getElementById("clmliAdjudSeqNbr").innerText;//IFOX-00416992 - Browser Compatibility issue
//				alert("after"+clmseqnbr+"***"+clmliseqnbr+"***"+clmliadjudseqnbr);
				if(code!=null && code!='' && reason!=null && reason!='' && amount!=null && amount!='' && quantity!=null && quantity!=''){
					
						if(!validateAlphaNumeric(code))			{errorList.push('Code should be alphanumeric')}
						if(!validateFieldSize(code,2,'LET'))	{errorList.push('Code should be max of 2 character')}
						if(!validateDecimalFormat(amount,7,2))	{errorList.push('Amount can have max 7 digit decimal and 2 digit of fractional value')}		//IFOX-00415579 - Claim Line Adjud Adjstmnt Amount field Max length
						
				}else{
					errorList.push('This field cannot be empty.');
				}
				if(errorList.length <=1) {
					
					 document.getElementById('editableCode').value = code.toUpperCase();
					 claimDetail.adjudGroupCode= code.toUpperCase();
					 claimDetail.adjudReasonCode= reason.toUpperCase();
					 claimDetail.adjudAmount=amount;
					 claimDetail.adjudQuantity= quantity;
					 claimDetail.clmliAdjudSeqNbr= clmliadjudseqnbr;
					 claimDetail.clmliSeqNbr= clmliseqnbr;
				}
				
			}
			//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End
			
			
		}
	   
	   validFlag=(errorList.length>1)?false:true;
	   //validFlag=false; //////// For testing only 
	   if(validFlag){
		   	/* commenting out as DWR call will be used for ajax remoting
		   	  	var url = "/hpeAction.do";
				document.hpeEncounterForm.method.value = 'editableAddClaimCodesSection';
				document.hpeEncounterForm.action = url;		
		    	document.hpeEncounterForm.submit();
		    */
		    
			FacadeManager.addUpdatableFields(claimDetail,{callback:function(data){
				//alert('addUpdatableFields Response:'+data);
				if((data!=null || data!=undefined) && (data.indexOf('ERROR') <= -1)){
					//triggerClick(claimType);
					//alert(data);
					var dataArr=data.split(',');
					if(dataArr!=null && dataArr!=undefined && dataArr.length >0){
						claimDetail.editableSeqNbr=dataArr[0].split('=')[1];
						claimDetail.editableMfid=dataArr[1].split('=')[1];
						addRowUI(claimType,claimDetail,type);
						switch (heir){
						case 'COND_CODE':
							document.getElementById(codeId).value = "";
							break;
						case 'TRTMNT_CODE':
							document.getElementById(codeId).value = ""; 
							break;
						case 'DIAG_CODE':
							document.getElementById(codeId).value = "";
							document.getElementById(typeId).value = "";
							document.getElementById(poaId).value = "";
							break;
						case 'EXT_INJ_CODE':
							document.getElementById(codeId).value = "";
							document.getElementById(typeId).value = "";
							document.getElementById(poaId).value = "";
							break;
						case 'PROC_CODE':
							document.getElementById(codeId).value = "";
							document.getElementById(typeId).value = "";
							document.getElementById(dateId).value = "";
							break;
						case 'OCCUR_SPAN_CODE':
							document.getElementById(codeId).value = "";
							document.getElementById(fromId).value = "";
							document.getElementById(thruId).value = "";
							break;
						case 'VALUE_CODE':
							document.getElementById(codeId).value = "";
							document.getElementById(amntId).value = "";
							break;
						case 'OCCUR_CODE':
							document.getElementById(codeId).value = "";
							document.getElementById(dateId).value = "";
							break;
						//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
						case 'ADJUD_ADJUST':
							document.getElementById(adjudGroupCode).value = "";
							document.getElementById(adjudReasonCode).value = "";
							document.getElementById(adjudAmount).value = "";
							document.getElementById(adjudQuantity).value = "";
							var clmliadjustspan = document.getElementById("adjustUpdateStatus");
							clmliadjustspan.innerHTML = "";
							var spantext = document.createTextNode("Claim Line Adjudication Adjustment Added successfully");
							clmliadjustspan.appendChild(spantext);
							break;
						//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End
						}
						
					}
				/* IFOX-00406912 Primary Procedure Code*/		
				}else if (data.indexOf('ERROR:PRINCPROCCODEDUPL') > -1){
					
				 var errorStr= data.replace("ERROR:PRINCPROCCODEDUPL:", "");
                 alert(errorStr)
			    }else{
					alert(data);
				}
				
			}});
				
			document.body.className = '';
//alert(" end of if");
	   }else{
		   //alert(" in else");
		   for (var i = 0; i < errorList.length; i++) { errorMsg=errorMsg+errorList[i]+'\n';}alert(errorMsg);
		   document.body.className = '';
	   }
		

	
}

/*
Author : Sainath
Input : Element Id 
Return : true / false 
Discription : Method will make alphaNumeric validation  on element value.
*/

function validateAlphaNumeric(val){
	if( val != null){
	
		if (val.match(/^[a-zA-Z0-9]+$/)) {
			return true;
		}
	}
	return false;
}

function validateNumeric(val){
	
	var regex  = /^\d+(?:\.\d{0,2})$/;
	
	
	if( val != null){
	
		if (val.match(/^[0-9]+$/))
			 return true;
	}
	return false;
}
function validateAlphaOnly(val){
	if( val != null){
	
		if (val.match(/^[a-zA-Z]+$/)) {
			return true;
		}
	}
	return false;
}
function validateAlphaYN(val){
	if( val != null){
	
		if (val.match(/^[yYnNuUwW]+$/)) {	//IFOX-00407127 -- Updateable Fields - Primary Diagnosis
			return true;
		}
	}
	return false;
}
function validateFieldSize(val,size,mode){
	if( val != null){
	
		if ((mode=='ET') && (val.length == size)) {
			return true;
		}if ((mode=='GT') && (val.length > size)) {
			return true;
		}if ((mode=='LT') && (val.length < size)) {
			return true;
		}
		if ((mode=='GET') && (val.length >= size)) {
			return true;
		}
		if ((mode=='LET') && (val.length <= size)) {
			return true;
		}
	}
	return false;
}

function validateDecimalFormat(num,decimalLength,fractionLength) {
	// usage :   validateDecimalFormat(223344.5566,11,2)  -> returns true if 223344.5566 contains up to 11 digits of decimal & up to 2 digit fractional part)
	  var numonly=num.replace('$','');
	  var regEx = new RegExp('^(\\d{0,'+decimalLength+'}\\.\\d{0,'+fractionLength+'}|\\d{0,'+decimalLength+'}|\\.\\d{0,'+fractionLength+'})$');
	  return regEx.test(numonly);
}
//Editable Fileds CHS -- IFOX-00395627

//DME_Dashboard_changes 
function toggleDashBoardTab(tabName,encType){
	//alert('toggleDashBoardTab-tabName:'+tabName+" ,encType:"+encType);
	if( (tabName == 'EDPS_DSH_SEL_TAB_MAP') || (tabName == 'REJECT_ANALYSIS_SUMMARY_TAB')){
		if( encType == 'I'){
			//alert('Institutional');		
			//document.getElementById('instTab').className ="dshSelected" ;
			//document.getElementById('profTab').className ="dshUnselected" ;
			//document.getElementById('dmeTab').className ="dshUnselected" ;
			document.getElementById('defaultSelectBtn').className="selectedOptionButton";
			document.getElementById('dmeSelectBtn').className="optionButton";
			
			document.getElementById('hpeStatusSummarySearchResultDiv').style.display = "block";
			//document.getElementById('hpeStatusSummaryProfSearchResultDiv').style.display ="none" ;
			document.getElementById('hpeStatusSummaryDMESearchResultDiv').style.display ="none" ;
			
		}
		if( encType == 'P'){
			//alert('Professional');
			//document.getElementById('instTab').className ="dshUnselected" ;
			//document.getElementById('profTab').className ="dshSelected" ;
			//document.getElementById('dmeTab').className ="dshUnselected" ;
			
			document.getElementById('defaultSelectBtn').className="selectedOptionButton";
			document.getElementById('dmeSelectBtn').className="optionButton";
			
			document.getElementById('hpeStatusSummarySearchResultDiv').style.display = "block";
			//document.getElementById('hpeStatusSummaryProfSearchResultDiv').style.display ="block" ;
			document.getElementById('hpeStatusSummaryDMESearchResultDiv').style.display ="none" ;
		}
		if( encType == 'E'){
			//alert('DME');
			//document.getElementById('instTab').className ="dshUnselected" ;
			//document.getElementById('profTab').className ="dshUnselected" ;
			//document.getElementById('dmeTab').className ="dshSelected" ;
			
			document.getElementById('defaultSelectBtn').className="optionButton";
			document.getElementById('dmeSelectBtn').className="selectedOptionButton";
			
			document.getElementById('hpeStatusSummarySearchResultDiv').style.display = "none";
			//document.getElementById('hpeStatusSummaryProfSearchResultDiv').style.display ="none" ;
			document.getElementById('hpeStatusSummaryDMESearchResultDiv').style.display ="block" ;
		}
		FacadeManager.setSelectedTab(tabName,encType,{callback:function(data){
			//alert('tabSaved- '+tabName+" & "+encType);
		}});
		
	}
}

function getHeirFieldName(heir){
	var heirFieldName=null;
	switch (heir) {
		case 'COND_CODE':
			heirFieldName ='Condition Code'; break;
		case 'TRTMNT_CODE':
			heirFieldName ='Treatment Code'; break;
		case 'DIAG_CODE':
			heirFieldName ='Diag Code'; break;
		case 'EXT_INJ_CODE':
			heirFieldName ='External Injury Code'; break;
		case 'PROC_CODE':
			heirFieldName ='Procedure Code'; break;
		case 'OCCUR_SPAN_CODE':
			heirFieldName ='Occurence Span Code'; break;
		case 'VALUE_CODE':
			heirFieldName ='Value Code'; break;
		case 'OCCUR_CODE':
			heirFieldName ='Occurence Code'; break;
		//IFOX-00415579 - Claim Line Adjud Adjstmnt Amount field Max length - Start
		case 'ADJUD_ADJUST':
			heirFieldName ='Claim line Adjudication Adjustment field'; break;
		case 'ADJUD_ADJUST_IN':
			heirFieldName ='Claim line Adjudication Adjustment field'; break;
		//IFOX-00415579 - Claim Line Adjud Adjstmnt Amount field Max length - End
	}
	return 	heirFieldName;	
}

function lpad(strOrig,padstring,size){ 
	var str=strOrig+'';
	while(str.length < size) {str = padstring + str+'';}
	return str;
}
function rpad(strOrig,padstring,size){
	var str=strOrig+'';
	while (str.length < size) {str =str+padstring;}
	return str;
}
function triggerClick(encType){
	var duplicateFlag=false;
	var rows=null;
	if(encType == 'I'){
		selector='#instListTbl > tbody > tr > td.selectedRow';
	}else if(encType == 'P'){
		selector='#profListTbl > tbody > tr > td.selectedRow';
	}else if(encType == 'E'){
		selector='#profListTbl > tbody > tr > td.selectedRow';
	}
		try{
			rows=document.querySelectorAll(selector);
			if(rows !=null && rows!=undefined && rows.length >0 ){
				var rowcnt=0;
				if(rowcnt <rows.length){
					rows[0].click();
				}
			}
		}catch(err){
			alert(err.message);
		}
	}
function addRowUI(encType,claimDetail,type){
	var hier=claimDetail.hier;
	var tbodyId = '';
	var tDivId = '';
	if(encType == 'I'){		

		switch (hier) {
		case 'COND_CODE':
			tbodyId = 'instClaimConditionCodeTbody';
			tDivId ='instClaimConditionCodeDiv'; 
			break;
		case 'TRTMNT_CODE':			
			tbodyId ='instTreatmentTbody'; 
			tDivId = 'instTreatmentTableDiv';
			break;
		case 'DIAG_CODE':
			tbodyId ='instDiagCodeTbody'; 
			tDivId = 'instDiagCodeTableDiv';
			break;
		case 'EXT_INJ_CODE':
			tbodyId ='instExtCauseInjuryTbody'; 
			tDivId = 'instExtCauseInjuryTableDiv';
			break;
		case 'PROC_CODE':
			tbodyId ='instProcedureCodeTbody'; 
			tDivId = 'instProcedureCodeTableDiv';
			break;
		case 'OCCUR_SPAN_CODE':
			tbodyId ='instOccurrenceSpanTbody'; 
			tDivId = 'instOccurrenceSpanTableDiv';
			break;
		case 'VALUE_CODE':
			tbodyId ='instValueTbody'; 
			tDivId = 'instValueTableDiv';
			break;
		case 'OCCUR_CODE':
			tbodyId ='instOccurrenceTbody'; 
			tDivId = 'instOccurrenceTableDiv';
			break;
		//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
		case 'ADJUD_ADJUST':
			tbodyId ='instLineAdjustmentTbody'; 
			tDivId = 'instLineAdjustmentTableDivEntry';
			break;
		//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End
	}
	
	}else if(encType == 'P' || encType == 'E'){
		switch (hier) {
		case 'COND_CODE':
			tbodyId ='profConditionCodeTbody'; 
			tDivId = 'profConditionCodeTableDiv';
			break;
		case 'DIAG_CODE':
			tbodyId ='profDiagCodeTbody'; 
			tDivId = 'profDiagCodeTableDiv';
			break;
		//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
		case 'ADJUD_ADJUST':
			tbodyId ='profLineAdjustmentTbody'; 
			tDivId = 'profLineAdjustmentTableDivEntry';
			break;
		//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End
		}

	}
	var tbdyElement = document.getElementById(tbodyId);
	var tDivElement = document.getElementById(tDivId);

	if(hier=='PROC_CODE' && tbdyElement.hasChildNodes() && tbdyElement.innerText == 'NO DATA'){
		tbdyElement.removeChild(tbdyElement.childNodes[1]);		
	}else if(tbdyElement.hasChildNodes() && tbdyElement.innerText == 'NO DATA'){
	
		tbdyElement.removeChild(tbdyElement.childNodes[0]);		
	}
	var content = tDivElement.innerHTML;
	var addOn = getRowInnerHTML(encType,claimDetail,tbdyElement);
	/* IFOX-00406912 Primary Procedure Code*/
	if(hier=='PROC_CODE' && (type=='BR'||type=='BBR')){
	tDivElement.innerHTML = content.replace("<B></B>", "<B></B>"+addOn);
	}else{
		tDivElement.innerHTML = content.replace("</TBODY>", addOn+"</TBODY>").replace("</tbody>", addOn+"</tbody>");//IFOX-00416992 - Browser Compatibility issue
	}

}
/*function checkDuplicateDiagCode(encType,code,type,poa){
	var codeL="";
	var typeL="";
	var poaL="";
	var duplicate=false;
	var tableId=(encType=='I')?"instDiagCodeTable":"profDiagCodeTable";
    var tab = document.getElementById(tableId);
    var trs= tab.rows;
	for(i=0;i<trs.length;i++){
		if(encType=='I'){
		 codeL=trs[i].cells[0].childNodes[0].innerHTML;
	     typeL=trs[i].cells[1].childNodes[0].innerHTML;
		 poaL=trs[i].cells[2].childNodes[0].innerHTML;
			if(codeL==code && typeL==type && poaL==poa)
				duplicate=true
		}else{
		 codeL=trs[i].cells[0].childNodes[0].innerHTML;
	     typeL=trs[i].cells[1].childNodes[0].innerHTML;
		 if(codeL==code && typeL==type)
				duplicate=true	
		}
	
	}
	return duplicate;
}*/
function checkDuplicateDiagCode(claimType,code,type,poa){
	var duplicateFlag=false;
	/*	var rows=null;
	if(claimType == 'I'){
		selector='#instDiagCodeDiv > table > tbody > tr > td > table.subheadRow > tbody > tr> td > div > table > tbody > tr';
		try{
			rows=document.querySelectorAll(selector);
			if(rows !=null && rows!=undefined && rows.length >0 ){
				var rowcnt=0;
				while(rowcnt <rows.length){
					var spans=rows[rowcnt].querySelectorAll('td > span');
					if(spans !=null && spans!=undefined && spans.length >2 ){
						typex=spans[0].innerHTML;
						codex=spans[1].innerHTML;
						poax=spans[2].innerHTML;
						
						if(code==codex && type==typex && poa==poax){
							duplicateFlag=true;
						}
					}
					rowcnt=rowcnt+1;
				}
			}
		}catch(err){
			alert(err.message);
		}
	
	}else if(claimType == 'P'){
		selector='#profDiagCodeDiv > table > tbody > tr > td > table.subheadRow > tbody > tr> td > div > table > tbody > tr';

		try{
			rows=document.querySelectorAll(selector);
			if(rows !=null && rows!=undefined && rows.length >0 ){
				var rowcnt=0;
				while(rowcnt <rows.length){
					var spans=rows[rowcnt].querySelectorAll('td > span');
					if(spans !=null && spans!=undefined && spans.length >2 ){
						typex=spans[0].innerHTML;
						codex=spans[1].innerHTML;
						poax=spans[2].innerHTML;
						
						if(code==codex && type==typex && poa==poax){
							duplicateFlag=true;
						}
					}
					rowcnt=rowcnt+1;
				}
			}
		}catch(err){
			alert(err.message);
		}
	}else if(claimType == 'E'){
		selector='#profDiagCodeDiv > table > tbody > tr > td > table.subheadRow > tbody > tr> td > div > table > tbody > tr';
	
		try{
			rows=document.querySelectorAll(selector);
			if(rows !=null && rows!=undefined && rows.length >0 ){
				var rowcnt=0;
				while(rowcnt <rows.length){
					var spans=rows[rowcnt].querySelectorAll('td > span');
					if(spans !=null && spans!=undefined && spans.length >2 ){
						typex=spans[0].innerHTML;
						codex=spans[1].innerHTML;
						
						if(code==codex && type==typex){
							duplicateFlag=true;
						}
					}
					rowcnt=rowcnt+1;
				}
			}
		}catch(err){
			alert(err.message);
		}
	}*/

	return duplicateFlag;
	
}

//Claim Codes Add,Update,Save,Cancel,Delete Functionalities

function getRowInnerHTML(encType,claimDetail,tbdyElement){
	var rowStr="";
	var hier=claimDetail.hier;
	var newRowId = tbdyElement.rows.length;
	if(encType == 'I'){		

		switch (hier) {
		case 'COND_CODE':
			var rowClassId=((newRowId % 2) == 0) ? "evenRow" : "oddRow";
			var condCodeRowId="condCodeRow"+newRowId;
			var spanUpdateTxtCondCodeId="spanUpdateTxtCondCode"+newRowId;
			var updateTxtCondCodeId="updateTxtCondCode"+newRowId;
			var updateBtnCondCodeId="updateBtnCondCode"+newRowId;
			var updateSaveBtnCondCodeId="updateSaveBtnCondCode"+newRowId;
			var updateCancelBtnCondCodeId="updateCancelBtnCondCode"+newRowId;

			var loadImageCondCodeId="loadImageCondCode"+newRowId;

			var deleteCondBtnId="deleteCondBtn"+newRowId;
			var condCodeValue=claimDetail.editableCode;
			
			// Handle No Data section
			rowStr=
				"<tr class=\""+rowClassId+"\" id=\""+condCodeRowId+"\">"+
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtCondCodeId+"\">"+condCodeValue+"</span>&nbsp; <input name=\""+updateTxtCondCodeId+"\" height=\"20\" id=\""+updateTxtCondCodeId+"\" style=\"display: none; cursor: pointer;\" type=\"text\" maxlength=\"2\" value=\""+condCodeValue+"\"></td>" +
			                            
			    "<td align=\"center\" class=\""+rowClassId+"\">"+ 
				    "<input height=\"20\" id=\""+updateBtnCondCodeId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableField('"+updateBtnCondCodeId+"','"+spanUpdateTxtCondCodeId+"','"+updateSaveBtnCondCodeId+"','"+updateCancelBtnCondCodeId+"','"+updateTxtCondCodeId+"')\" type=\"button\" value=\"Update\" /> "+
				    "<input name=\""+updateSaveBtnCondCodeId+"\" height=\"20\" id=\""+updateSaveBtnCondCodeId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableSaveField('"+claimDetail.editableMfid+"','"+claimDetail.selectedClaimRefNbr+"','"+claimDetail.selectedClaimRevNbr+"','"+claimDetail.selectedClaimSeqNbr+"','"+claimDetail.editableCndSeqNbr+"','COND_CODE','"+loadImageCondCodeId+"','"+updateTxtCondCodeId+"','0','0','0','0','0','0','clmtype','"+claimDetail.searchDetailClmType+"','"+newRowId+"')\" type=\"button\" value=\"Save\" />"+
				    "<input name=\""+updateCancelBtnCondCodeId+"\" height=\"20\" id=\""+updateCancelBtnCondCodeId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableCancelField('"+updateBtnCondCodeId+"','"+spanUpdateTxtCondCodeId+"','"+updateSaveBtnCondCodeId+"','"+updateCancelBtnCondCodeId+"','"+updateTxtCondCodeId+"','"+loadImageCondCodeId+"')\" type=\"button\" value=\"Cancel\" />"+
				    "<span id=\""+loadImageCondCodeId+"\" style=\"display: none;\"> <img alt=\"Loading\" src=\"/mss/jsp/Recon/images/Loading.gif\"></span>"+ 
									
				"</td>"+
				"<td align=\"center\" class=\""+rowClassId+"\">"+
				                             
				"<input name=\""+deleteCondBtnId+"\" height=\"20\" id=\""+deleteCondBtnId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableDeleteField('"+claimDetail.editableMfid+"','"+claimDetail.selectedClaimRefNbr+"','"+claimDetail.selectedClaimRevNbr+"','"+claimDetail.selectedClaimSeqNbr+"','"+claimDetail.editableCndSeqNbr+"','COND_CODE','"+loadImageCondCodeId+"','"+updateTxtCondCodeId+"','0','0','0','0','0','0','clmtype','"+claimDetail.searchDetailClmType+"','"+newRowId+"')\" type=\"button\" value=\"Delete\" />"+
				                            
				"</td>"+
			"</tr>"	;		
			break;
		case 'TRTMNT_CODE':
			var rowClassId=((newRowId % 2) == 0) ? "evenRow" : "oddRow";
			var treatCodeRowId="treatCodeRow"+newRowId;
			var spanUpdateTxtTreatCodeId="spanUpdateTxtTreatCode"+newRowId;
			var updateTxtTreatCodeId="updateTxtTreatCode"+newRowId;
			var updateBtnTreatCodeId="updateBtnTreatCode"+newRowId;
			var updateSaveBtnTreatCodeId="updateSaveBtnTreatCode"+newRowId;
			var updateCancelBtnTreatCodeId="updateCancelBtnTreatCode"+newRowId;

			var loadImageTreatCodeId="loadImageTreatCode"+newRowId;

			var deleteTreatBtnId="deleteTreatBtn"+newRowId;
			var treatCodeValue=claimDetail.editableCode;
			// Handle No Data section
			rowStr=
				"<tr class=\""+rowClassId+"\" id=\""+treatCodeRowId+"\">"+
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtTreatCodeId+"\">"+treatCodeValue+"</span>&nbsp; <input name=\""+updateTxtTreatCodeId+"\" height=\"20\" id=\""+updateTxtTreatCodeId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"30\" value=\""+treatCodeValue+"\"></td>" +
			                            
			    "<td align=\"center\" class=\""+rowClassId+"\">"+ 
				    "<input height=\"20\" id=\""+updateBtnTreatCodeId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableField('"+updateBtnTreatCodeId+"','"+spanUpdateTxtTreatCodeId+"','"+updateSaveBtnTreatCodeId+"','"+updateCancelBtnTreatCodeId+"','"+updateTxtTreatCodeId+"')\" type=\"button\" value=\"Update\" /> "+
				    "<input name=\""+updateSaveBtnTreatCodeId+"\" height=\"20\" id=\""+updateSaveBtnTreatCodeId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableSaveField('"+claimDetail.editableMfid+"','"+claimDetail.selectedClaimRefNbr+"','"+claimDetail.selectedClaimRevNbr+"','"+claimDetail.selectedClaimSeqNbr+"','"+claimDetail.editableSeqNbr+"','TRTMNT_CODE','"+loadImageTreatCodeId+"','"+updateTxtTreatCodeId+"','0','0','0','0','0','0','clmtype','"+claimDetail.searchDetailClmType+"','"+newRowId+"')\" type=\"button\" value=\"Save\" />"+
				    "<input name=\""+updateCancelBtnTreatCodeId+"\" height=\"20\" id=\""+updateCancelBtnTreatCodeId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableCancelField('"+updateBtnTreatCodeId+"','"+spanUpdateTxtTreatCodeId+"','"+updateSaveBtnTreatCodeId+"','"+updateCancelBtnTreatCodeId+"','"+updateTxtTreatCodeId+"','"+loadImageTreatCodeId+"')\" type=\"button\" value=\"Cancel\" />"+
				    "<span id=\""+loadImageTreatCodeId+"\" style=\"display: none;\"> <img alt=\"Loading\" src=\"/mss/jsp/Recon/images/Loading.gif\"></span>"+ 
									
				"</td>"+
				"<td align=\"center\" class=\""+rowClassId+"\">"+
				                             
				"<input name=\""+deleteTreatBtnId+"\" height=\"20\" id=\""+deleteTreatBtnId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableDeleteField('"+claimDetail.editableMfid+"','"+claimDetail.selectedClaimRefNbr+"','"+claimDetail.selectedClaimRevNbr+"','"+claimDetail.selectedClaimSeqNbr+"','"+claimDetail.editableCndSeqNbr+"','TRTMNT_CODE','"+loadImageTreatCodeId+"','"+updateTxtTreatCodeId+"','0','0','0','0','0','0','clmtype','"+claimDetail.searchDetailClmType+"','"+newRowId+"')\" type=\"button\" value=\"Delete\" />"+
				                            
				"</td>"+
			"</tr>"	;
			break;
		case 'DIAG_CODE':
			var rowClassId=((newRowId % 2) == 0) ? "evenRow" : "oddRow";
			var diagCodeRowId="diagCodeRow"+newRowId;
			var spanUpdateTxtDiagCodeId="spanUpdateTxtdiagCode"+newRowId;
			var spanUpdateTxtDiagTypeId="spanUpdateTxtdiagType"+newRowId;
			var spanUpdateTxtDiagPOAId="spanUpdateTxtdiagPOA"+newRowId;
			var updateTxtDiagTypeId="updateTxtDiagType"+newRowId;
			var updateTxtDiagCodeId="updateTxtDiagCode"+newRowId;
			var updateTxtDiagPOAId="updateTxtDiagPOA"+newRowId;
			var updateBtnDiagCodeId="updateBtnDiagCode"+newRowId;
			var updateSaveBtnDiagCodeId="updateSaveBtnDiagCode"+newRowId;
			var updateCancelBtnDiagCodeId="updateCancelBtnDiagCode"+newRowId;

			var loadImageDiagCodeId="loadImageDiagCode"+newRowId;

			var deleteDiagBtnId="deleteDiagBtn"+newRowId;
			var diagCodeValue=claimDetail.editableCode;
			var diagTypeValue=claimDetail.editableType;
			var diagpresentOnAdmitIndValue=claimDetail.editablePOA;
			// Handle No Data section
			rowStr=
				"<tr class=\""+rowClassId+"\" id=\""+diagCodeRowId+"\">"+
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtDiagTypeId+"\">"+diagTypeValue+"</span>&nbsp; <input name=\""+updateTxtDiagTypeId+"\"  id=\""+updateTxtDiagTypeId+"\" style=\"display: none; width=50px; cursor: pointer;\" type=\"text\" maxlength=\"3\" value=\""+diagTypeValue+"\"></td>" +
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtDiagCodeId+"\">"+diagCodeValue+"</span>&nbsp; <input name=\""+updateTxtDiagCodeId+"\"  id=\""+updateTxtDiagCodeId+"\" style=\"display: none; width=50px; cursor: pointer;\" type=\"text\" maxlength=\"7\" value=\""+diagCodeValue+"\"></td>" +
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtDiagPOAId+"\">"+diagpresentOnAdmitIndValue+"</span>&nbsp; <input name=\""+updateTxtDiagPOAId+"\" height=\"20\" id=\""+updateTxtDiagPOAId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"1\" value=\""+diagpresentOnAdmitIndValue+"\"></td>" +
				//IFOX-00407127 -- Updateable Fields - Primary Diagnosis - Start
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;</td>" +
			    //IFOX-00407127 -- Updateable Fields - Primary Diagnosis - End
			    "<td align=\"center\" class=\""+rowClassId+"\">"+ 
				    "<input height=\"20\" id=\""+updateBtnDiagCodeId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableDiagField('"+spanUpdateTxtDiagTypeId+"','"+updateTxtDiagTypeId+"','"+spanUpdateTxtDiagCodeId+"','"+updateTxtDiagCodeId+"','"+spanUpdateTxtDiagPOAId+"','"+updateTxtDiagPOAId+"','"+updateBtnDiagCodeId+"','"+updateSaveBtnDiagCodeId+"','"+updateCancelBtnDiagCodeId+"')\" type=\"button\" value=\"Update\" /> "+
				    "<input name=\""+updateSaveBtnDiagCodeId+"\" height=\"20\" id=\""+updateSaveBtnDiagCodeId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableSaveField('"+claimDetail.editableMfid+"','"+claimDetail.selectedClaimRefNbr+"','"+claimDetail.selectedClaimRevNbr+"','"+claimDetail.selectedClaimSeqNbr+"','"+claimDetail.editableSeqNbr+"','DIAG_CODE','"+loadImageDiagCodeId+"','"+updateTxtDiagCodeId+"','"+updateTxtDiagTypeId+"','"+updateTxtDiagPOAId+"','0','0','0','0','clmtype','"+claimDetail.searchDetailClmType+"','"+newRowId+"')\" type=\"button\" value=\"Save\" />"+
				    "<input name=\""+updateCancelBtnDiagCodeId+"\" height=\"20\" id=\""+updateCancelBtnDiagCodeId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableDiagCancelField('"+spanUpdateTxtDiagTypeId+"','"+updateTxtDiagTypeId+"','"+spanUpdateTxtDiagCodeId+"','"+updateTxtDiagCodeId+"','"+spanUpdateTxtDiagPOAId+"','"+updateTxtDiagPOAId+"','"+updateBtnDiagCodeId+"','"+updateSaveBtnDiagCodeId+"','"+updateCancelBtnDiagCodeId+"')\" type=\"button\" value=\"Cancel\" />"+	//IFOX-00407127 -- Updateable Fields - Primary Diagnosis
				    "<span id=\""+loadImageDiagCodeId+"\" style=\"display: none;\"> <img alt=\"Loading\" src=\"/mss/jsp/Recon/images/Loading.gif\"></span>"+ 
									
				"</td>"+
				"<td align=\"center\" class=\""+rowClassId+"\">"+
				
				                             
				"<input name=\""+deleteDiagBtnId+"\" height=\"20\" id=\""+deleteDiagBtnId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableDeleteField('"+claimDetail.editableMfid+"','"+claimDetail.selectedClaimRefNbr+"','"+claimDetail.selectedClaimRevNbr+"','"+claimDetail.selectedClaimSeqNbr+"','"+claimDetail.editableSeqNbr+"','DIAG_CODE','"+loadImageDiagCodeId+"','"+updateTxtDiagCodeId+"','"+updateTxtDiagTypeId+"','"+updateTxtDiagPOAId+"','0','0','0','0','clmtype','"+claimDetail.searchDetailClmType+"','"+newRowId+"')\" type=\"button\" value=\"Delete\" />"+
				                            
				"</td>"+
			"</tr>"	;	
			break;
			
		case 'EXT_INJ_CODE':
			var rowClassId=((newRowId % 2) == 0) ? "evenRow" : "oddRow";
			var extInjRowId="externalInjRow"+newRowId;
			var spanUpdateTxtExtInjTypeId="spanUpdateTxtExtInjType"+newRowId;
			var spanUpdateTxtExtInjCodeId="spanUpdateTxtExtInjCode"+newRowId;
			var spanUpdateTxtExtInjPOAId="spanUpdateTxtExtInjPOA"+newRowId;
			var updateTxtExtInjTypeId="updateTxtExtInjType"+newRowId;
			var updateTxtExtInjCodeId="updateTxtExtInjCode"+newRowId;
			var updateTxtExtInjPOAId="updateTxtExtInjPOA"+newRowId;
			var updateBtnExtInjCodeId="updateBtnExtInjCode"+newRowId; 
			var updateSaveBtnExtInjCodeId="updateSaveBtnExtInjCode"+newRowId;
			var updateCancelBtnExtInjCodeId="updateCancelBtnExtInjCode"+newRowId;
			var loadImageExtInjCodeId="loadImageExtInjCode"+newRowId;
			var deleteExtInjBtnId="deleteExtInjBtn"+newRowId;
			var extInjTypeValue=claimDetail.editableType;
			var extInjCodeValue=claimDetail.editableCode;
			var extInjPOAValue=claimDetail.editablePOA;
			rowStr=
				"<tr class=\""+rowClassId+"\" id=\""+extInjRowId+"\">"+
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtExtInjTypeId+"\">"+extInjTypeValue+"</span>&nbsp; <input name=\""+updateTxtExtInjTypeId+"\" height=\"20\" id=\""+updateTxtExtInjTypeId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"3\" value=\""+extInjTypeValue+"\"></td>" +
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtExtInjCodeId+"\">"+extInjCodeValue+"</span>&nbsp; <input name=\""+updateTxtExtInjCodeId+"\" height=\"20\" id=\""+updateTxtExtInjCodeId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"30\" value=\""+extInjCodeValue+"\"></td>" +
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtExtInjPOAId+"\">"+extInjPOAValue+"</span>&nbsp; <input name=\""+updateTxtExtInjPOAId+"\" height=\"20\" id=\""+updateTxtExtInjPOAId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"1\" value=\""+extInjPOAValue+"\"></td>" +
			                            
			    "<td align=\"center\" class=\""+rowClassId+"\">"+ 
				    "<input height=\"20\" id=\""+updateBtnExtInjCodeId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableDiagField('"+spanUpdateTxtExtInjTypeId+"','"+updateTxtExtInjTypeId+"','"+spanUpdateTxtExtInjCodeId+"','"+updateTxtExtInjCodeId+"','"+spanUpdateTxtExtInjPOAId+"','"+updateTxtExtInjPOAId+"','"+updateBtnExtInjCodeId+"','"+updateSaveBtnExtInjCodeId+"','"+updateCancelBtnExtInjCodeId+"')\" type=\"button\" value=\"Update\" /> "+
				    "<input name=\""+updateSaveBtnExtInjCodeId+"\" height=\"20\" id=\""+updateSaveBtnExtInjCodeId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableSaveField('"+claimDetail.editableMfid+"','"+claimDetail.selectedClaimRefNbr+"','"+claimDetail.selectedClaimRevNbr+"','"+claimDetail.selectedClaimSeqNbr+"','"+claimDetail.editableSeqNbr+"','EXT_INJ_CODE','"+loadImageExtInjCodeId+"','"+updateTxtExtInjCodeId+"','"+updateTxtExtInjTypeId+"','"+updateTxtExtInjPOAId+"','0','0','0','0','clmtype','"+claimDetail.searchDetailClmType+"','"+newRowId+"')\" type=\"button\" value=\"Save\" />"+
				    "<input name=\""+updateCancelBtnExtInjCodeId+"\" height=\"20\" id=\""+updateCancelBtnExtInjCodeId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableDiagCancelField('"+spanUpdateTxtExtInjTypeId+"','"+updateTxtExtInjTypeId+"','"+spanUpdateTxtExtInjCodeId+"','"+updateTxtExtInjCodeId+"','"+spanUpdateTxtExtInjPOAId+"','"+updateTxtExtInjPOAId+"','"+updateBtnExtInjCodeId+"','"+updateSaveBtnExtInjCodeId+"','"+updateCancelBtnExtInjCodeId+"')\" type=\"button\" value=\"Cancel\" />"+
				    "<span id=\""+loadImageExtInjCodeId+"\" style=\"display: none;\"> <img alt=\"Loading\" src=\"/mss/jsp/Recon/images/Loading.gif\"></span>"+ 
									
				"</td>"+
				"<td align=\"center\" class=\""+rowClassId+"\">"+
				                             
				"<input name=\""+deleteExtInjBtnId+"\" height=\"20\" id=\""+deleteExtInjBtnId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableDeleteField('"+claimDetail.editableMfid+"','"+claimDetail.selectedClaimRefNbr+"','"+claimDetail.selectedClaimRevNbr+"','"+claimDetail.selectedClaimSeqNbr+"','"+claimDetail.editableSeqNbr+"','EXT_INJ_CODE','"+loadImageExtInjCodeId+"','"+updateTxtExtInjCodeId+"','"+updateTxtExtInjTypeId+"','"+updateTxtExtInjPOAId+"','0','0','0','0','clmtype','"+claimDetail.searchDetailClmType+"','"+newRowId+"')\" type=\"button\" value=\"Delete\" />"+
				                            
				"</td>"+
			"</tr>"	;	
			break;
		case 'PROC_CODE':
			var rowClassId=((newRowId % 2) == 0) ? "evenRow" : "oddRow";
			var procCodeRowId="procCodeRow"+newRowId;
			//Span
			var spanUpdateTxtProcTypeId="spanUpdateTxtProcType"+newRowId;
			var spanUpdateTxtProcCodeId="spanUpdateTxtProcCode"+newRowId;
			var spanUpdateTxtProcDateId="spanUpdateTxtProcDate"+newRowId;
			//Update
			var updateTxtProcTypeId="updateTxtProcType"+newRowId;
			var updateTxtProcCodeId="updateTxtProcCode"+newRowId;
			var updateTxtProcDateId="updateTxtProcDate"+newRowId;
			//For Buttons
			var updateBtnProcCodeId="updateBtnProcCode"+newRowId; 
			var updateSaveBtnProcCodeId="updateSaveBtnProcCode"+newRowId;
			var updateCancelBtnProcCodeId="updateCancelBtnProcCode"+newRowId;
			var loadImageProcCodeId="loadImageProcCode"+newRowId;
			var deleteProcBtnId="deleteProcBtn"+newRowId;
			//For Values
			var procTypeValue=claimDetail.editableType;
			var procCodeValue=claimDetail.editableCode;
			var procDateValue=claimDetail.editableDate;
			// Handle No Data section
			rowStr=
				"<tr class=\""+rowClassId+"\" id=\""+procCodeRowId+"\">"+
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtProcTypeId+"\">"+procTypeValue+"</span>&nbsp; <input name=\""+updateTxtProcTypeId+"\"  id=\""+updateTxtProcTypeId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"3\" value=\""+procTypeValue+"\"></td>" +
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtProcCodeId+"\">"+procCodeValue+"</span>&nbsp; <input name=\""+updateTxtProcCodeId+"\"  id=\""+updateTxtProcCodeId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"7\" value=\""+procCodeValue+"\"></td>" +
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtProcDateId+"\">"+procDateValue+"</span>&nbsp; <input name=\""+updateTxtProcDateId+"\"  id=\""+updateTxtProcDateId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"10\" value=\""+procDateValue+"\"></td>" +
			                            
			    "<td align=\"center\" class=\""+rowClassId+"\">"+ 
				    "<input height=\"20\" id=\""+updateBtnProcCodeId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableDiagField('"+spanUpdateTxtProcTypeId+"','"+updateTxtProcTypeId+"','"+spanUpdateTxtProcCodeId+"','"+updateTxtProcCodeId+"','"+spanUpdateTxtProcDateId+"','"+updateTxtProcDateId+"','"+updateBtnProcCodeId+"','"+updateSaveBtnProcCodeId+"','"+updateCancelBtnProcCodeId+"')\" type=\"button\" value=\"Update\" /> "+
				    "<input name=\""+updateSaveBtnProcCodeId+"\" height=\"20\" id=\""+updateSaveBtnProcCodeId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableSaveField('"+claimDetail.editableMfid+"','"+claimDetail.selectedClaimRefNbr+"','"+claimDetail.selectedClaimRevNbr+"','"+claimDetail.selectedClaimSeqNbr+"','"+claimDetail.editableSeqNbr+"','PROC_CODE','"+loadImageProcCodeId+"','"+updateTxtProcCodeId+"','"+updateTxtProcTypeId+"','0','"+updateTxtProcDateId+"','0','0','0','clmtype','"+claimDetail.searchDetailClmType+"','"+newRowId+"')\" type=\"button\" value=\"Save\" />"+
				    "<input name=\""+updateCancelBtnProcCodeId+"\" height=\"20\" id=\""+updateCancelBtnProcCodeId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableDiagCancelField('"+spanUpdateTxtProcTypeId+"','"+updateTxtProcTypeId+"','"+spanUpdateTxtProcCodeId+"','"+updateTxtProcCodeId+"','"+spanUpdateTxtProcDateId+"','"+updateTxtProcDateId+"','"+updateBtnProcCodeId+"','"+updateSaveBtnProcCodeId+"','"+updateCancelBtnProcCodeId+"')\" type=\"button\" value=\"Cancel\" />"+
				    "<span id=\""+loadImageProcCodeId+"\" style=\"display: none;\"> <img alt=\"Loading\" src=\"/mss/jsp/Recon/images/Loading.gif\"></span>"+ 
									
				"</td>"+
				"<td align=\"center\" class=\""+rowClassId+"\">"+
				                             
				"<input name=\""+deleteProcBtnId+"\" height=\"20\" id=\""+deleteProcBtnId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableDeleteField('"+claimDetail.editableMfid+"','"+claimDetail.selectedClaimRefNbr+"','"+claimDetail.selectedClaimRevNbr+"','"+claimDetail.selectedClaimSeqNbr+"','"+claimDetail.editableSeqNbr+"','PROC_CODE','"+loadImageProcCodeId+"','"+updateTxtProcCodeId+"','"+updateTxtProcTypeId+"','0','"+updateTxtProcDateId+"','0','0','0','clmtype','"+claimDetail.searchDetailClmType+"','"+newRowId+"')\" type=\"button\" value=\"Delete\" />"+
				                            
				"</td>"+
			"</tr>"	;	
			break;
		case 'OCCUR_SPAN_CODE':
			var rowClassId=((newRowId % 2) == 0) ? "evenRow" : "oddRow";
			var occurSpanRowId="occurSpanRow"+newRowId;
			//Span
			var spanUpdateTxtOccurSpanCodeId="spanUpdateTxtOccurSpanCode"+newRowId;
			var spanUpdateTxtOccurSpanFromDtId="spanUpdateTxtOccurSpanFromDt"+newRowId;
			var spanUpdateTxtOccurSpanToDtId="spanUpdateTxtOccurSpanToDt"+newRowId;
			//Update
			var updateTxtOccurSpanCodeId="updateTxtOccurSpanCode"+newRowId;
			var updateTxtOccurSpanFromDtId="updateTxtOccurSpanFromDt"+newRowId;
			var updateTxtOccurSpanToDtId="updateTxtOccurSpanToDt"+newRowId;
			//For Buttons
			var updateBtnOccurSpanCodeId="updateBtnOccurSpanCode"+newRowId; 
			var updateSaveBtnOccurSpanCodeId="updateSaveBtnOccurSpanCode"+newRowId;
			var updateCancelBtnOccurSpanCodeId="updateCancelBtnOccurSpanCode"+newRowId;
			var loadImageOccurSpanCodeId="loadImageOccurSpanCode"+newRowId;
			var deleteOccurSpanBtnId="deleteOccurSpanBtn"+newRowId;
			//For Values
			var occurSpanCodeValue=claimDetail.editableCode;
			var occurSpanFromDtValue=claimDetail.editableFromDt
			var occurSpanToDtValue=claimDetail.editableThruDt;
			// Handle No Data section
			rowStr=
				"<tr class=\""+rowClassId+"\" id=\""+occurSpanRowId+"\">"+
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtOccurSpanCodeId+"\">"+occurSpanCodeValue+"</span>&nbsp; <input name=\""+updateTxtOccurSpanCodeId+"\"  id=\""+updateTxtOccurSpanCodeId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"18\" value=\""+occurSpanCodeValue+"\"></td>" +
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtOccurSpanFromDtId+"\">"+occurSpanFromDtValue+"</span>&nbsp; <input name=\""+updateTxtOccurSpanFromDtId+"\"  id=\""+updateTxtOccurSpanFromDtId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"10\" value=\""+occurSpanFromDtValue+"\"></td>" +
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtOccurSpanToDtId+"\">"+occurSpanToDtValue+"</span>&nbsp; <input name=\""+updateTxtOccurSpanToDtId+"\"  id=\""+updateTxtOccurSpanToDtId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"10\" value=\""+occurSpanToDtValue+"\"></td>" +
			                            
			    "<td align=\"center\" class=\""+rowClassId+"\">"+ 
				    "<input name=\""+updateBtnOccurSpanCodeId+"\" height=\"20\" id=\""+updateBtnOccurSpanCodeId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableDiagField('"+spanUpdateTxtOccurSpanCodeId+"','"+updateTxtOccurSpanCodeId+"','"+spanUpdateTxtOccurSpanFromDtId+"','"+updateTxtOccurSpanFromDtId+"','"+spanUpdateTxtOccurSpanToDtId+"','"+updateTxtOccurSpanToDtId+"','"+updateBtnOccurSpanCodeId+"','"+updateSaveBtnOccurSpanCodeId+"','"+updateCancelBtnOccurSpanCodeId+"')\" type=\"button\" value=\"Update\" /> "+
				    "<input name=\""+updateSaveBtnOccurSpanCodeId+"\" height=\"20\" id=\""+updateSaveBtnOccurSpanCodeId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableSaveField('"+claimDetail.editableMfid+"','"+claimDetail.selectedClaimRefNbr+"','"+claimDetail.selectedClaimRevNbr+"','"+claimDetail.selectedClaimSeqNbr+"','"+claimDetail.editableSeqNbr+"','OCCUR_SPAN_CODE','"+loadImageOccurSpanCodeId+"','"+updateTxtOccurSpanCodeId+"','0','0','0','"+updateTxtOccurSpanFromDtId+"','"+updateTxtOccurSpanToDtId+"','0','clmtype','"+claimDetail.searchDetailClmType+"','"+newRowId+"')\" type=\"button\" value=\"Save\" />"+
				    "<input name=\""+updateCancelBtnOccurSpanCodeId+"\" height=\"20\" id=\""+updateCancelBtnOccurSpanCodeId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableDiagCancelField('"+spanUpdateTxtOccurSpanCodeId+"','"+updateTxtOccurSpanCodeId+"','"+spanUpdateTxtOccurSpanFromDtId+"','"+updateTxtOccurSpanFromDtId+"','"+spanUpdateTxtOccurSpanToDtId+"','"+updateTxtOccurSpanToDtId+"','"+updateBtnOccurSpanCodeId+"','"+updateSaveBtnOccurSpanCodeId+"','"+updateCancelBtnOccurSpanCodeId+"','"+updateSaveBtnOccurSpanCodeId+"','"+updateCancelBtnOccurSpanCodeId+"')\" type=\"button\" value=\"Cancel\" />"+
				    "<span id=\""+loadImageOccurSpanCodeId+"\" style=\"display: none;\"> <img alt=\"Loading\" src=\"/mss/jsp/Recon/images/Loading.gif\"></span>"+ 
									
				"</td>"+
				"<td align=\"center\" class=\""+rowClassId+"\">"+
				                             
				"<input name=\""+deleteOccurSpanBtnId+"\" height=\"20\" id=\""+deleteOccurSpanBtnId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableDeleteField('"+claimDetail.editableMfid+"','"+claimDetail.selectedClaimRefNbr+"','"+claimDetail.selectedClaimRevNbr+"','"+claimDetail.selectedClaimSeqNbr+"','"+claimDetail.editableSeqNbr+"','OCCUR_SPAN_CODE','"+loadImageOccurSpanCodeId+"','"+updateTxtOccurSpanCodeId+"','0','0','0','"+updateTxtOccurSpanFromDtId+"','"+updateTxtOccurSpanToDtId+"','0','clmtype','"+claimDetail.searchDetailClmType+"','"+newRowId+"')\" type=\"button\" value=\"Delete\" />"+
				                            
				"</td>"+
			"</tr>"	;	
			break;
		case 'VALUE_CODE':
			var rowClassId=((newRowId % 2) == 0) ? "evenRow" : "oddRow";
			var valueCodeRowId="valueRow"+newRowId;
			var spanUpdateTxtValueCodeId="spanUpdateTxtValueCode"+newRowId;
			var spanUpdateTxtValueAmntId="spanUpdateTxtValueAmnt"+newRowId;
			var updateTxtValueCodeId="updateTxtValueCode"+newRowId;
			var updateTxtValueAmntId="updateTxtValueAmnt"+newRowId;
			var updateBtnValueCodeId="updateBtnValueCode"+newRowId;
			var updateSaveBtnValueCodeId="updateSaveBtnValueCode"+newRowId;
			var updateCancelBtnValueCodeId="updateCancelBtnValueCode"+newRowId;

			var loadImageValueCodeId="loadImageValueCode"+newRowId;

			var deleteValueBtnId="deleteValueBtn"+newRowId;
			var valueCodeValue=claimDetail.editableCode;
			var valueAmntValue="$"+claimDetail.editableAmount; 
			// Handle No Data section
			rowStr=
				"<tr class=\""+rowClassId+"\" id=\""+valueCodeRowId+"\">"+
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtValueCodeId+"\">"+valueCodeValue+"</span>&nbsp; <input name=\""+updateTxtValueCodeId+"\"  id=\""+updateTxtValueCodeId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"2\" value=\""+valueCodeValue+"\"></td>" +
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtValueAmntId+"\">"+valueAmntValue+"</span>&nbsp; <input name=\""+updateTxtValueAmntId+"\"  id=\""+updateTxtValueAmntId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"10\" value=\""+valueAmntValue+"\"></td>" +                     
			    "<td align=\"center\" class=\""+rowClassId+"\">"+ 
				    "<input height=\"20\" id=\""+updateBtnValueCodeId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableValueField('"+spanUpdateTxtValueCodeId+"','"+updateTxtValueCodeId+"','"+spanUpdateTxtValueAmntId+"','"+updateTxtValueAmntId+"','"+updateBtnValueCodeId+"','"+updateSaveBtnValueCodeId+"','"+updateCancelBtnValueCodeId+"')\" type=\"button\" value=\"Update\" /> "+
				    "<input name=\""+updateSaveBtnValueCodeId+"\" height=\"20\" id=\""+updateSaveBtnValueCodeId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableSaveField('"+claimDetail.editableMfid+"','"+claimDetail.selectedClaimRefNbr+"','"+claimDetail.selectedClaimRevNbr+"','"+claimDetail.selectedClaimSeqNbr+"','"+claimDetail.editableSeqNbr+"','VALUE_CODE','"+loadImageValueCodeId+"','"+updateTxtValueCodeId+"','0','0','0','0','0','"+updateTxtValueAmntId+"','clmtype','"+claimDetail.searchDetailClmType+"','"+newRowId+"')\" type=\"button\" value=\"Save\" />"+
				    "<input name=\""+updateCancelBtnValueCodeId+"\" height=\"20\" id=\""+updateCancelBtnValueCodeId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableValueCancelField('"+spanUpdateTxtValueCodeId+"','"+updateTxtValueCodeId+"','"+spanUpdateTxtValueAmntId+"','"+updateTxtValueAmntId+"','"+updateBtnValueCodeId+"','"+updateSaveBtnValueCodeId+"','"+updateCancelBtnValueCodeId+"')\" type=\"button\" value=\"Cancel\" />"+
				    "<span id=\""+loadImageValueCodeId+"\" style=\"display: none;\"> <img alt=\"Loading\" src=\"/mss/jsp/Recon/images/Loading.gif\"></span>"+ 
									
				"</td>"+
				"<td align=\"center\" class=\""+rowClassId+"\">"+
				                             
				"<input name=\""+deleteValueBtnId+"\" height=\"20\" id=\""+deleteValueBtnId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableDeleteField('"+claimDetail.editableMfid+"','"+claimDetail.selectedClaimRefNbr+"','"+claimDetail.selectedClaimRevNbr+"','"+claimDetail.selectedClaimSeqNbr+"','"+claimDetail.editableSeqNbr+"','VALUE_CODE','"+loadImageValueCodeId+"','"+updateTxtValueCodeId+"','0','0','0','0','0','"+updateTxtValueAmntId+"','clmtype','"+claimDetail.searchDetailClmType+"','"+newRowId+"')\" type=\"button\" value=\"Delete\" />"+
				                            
				"</td>"+
			"</tr>"	;		
			break;

		case 'OCCUR_CODE':
			var rowClassId=((newRowId % 2) == 0) ? "evenRow" : "oddRow";
			var occurCodeRowId="occurenceRow"+newRowId;
			var spanUpdateTxtOccurCodeId="spanUpdateTxtOccurCode"+newRowId;
			var spanUpdateTxtOccurDateId="spanUpdateTxtOccurDate"+newRowId;
			var updateTxtOccurCodeId="updateTxtOccurCode"+newRowId;
			var updateTxtOccurDateId="updateTxtOccurDate"+newRowId;
			var updateBtnOccurCodeId="updateBtnOccurCode"+newRowId;
			var updateSaveBtnOccurCodeId="updateSaveBtnOccurCode"+newRowId;
			var updateCancelBtnOccurCodeId="updateCancelBtnOccurCode"+newRowId;

			var loadImageOccurCodeId="loadImageOccurCode"+newRowId;

			var deleteOccurBtnId="deleteOccurBtn"+newRowId;
			var occurCodeValue=claimDetail.editableCode;
			var occurDateValue=claimDetail.editableDate;
			// Handle No Data section
			rowStr=
				"<tr class=\""+rowClassId+"\" id=\""+occurCodeRowId+"\">"+
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtOccurCodeId+"\">"+occurCodeValue+"</span>&nbsp; <input name=\""+updateTxtOccurCodeId+"\"  id=\""+updateTxtOccurCodeId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"7\" value=\""+occurCodeValue+"\"></td>" +
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtOccurDateId+"\">"+occurDateValue+"</span>&nbsp; <input name=\""+updateTxtOccurDateId+"\"  id=\""+updateTxtOccurDateId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"10\" value=\""+occurDateValue+"\"></td>" +
			                            
			    "<td align=\"center\" class=\""+rowClassId+"\">"+ 
				    "<input name=\""+updateBtnOccurCodeId+"\" height=\"20\" id=\""+updateBtnOccurCodeId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableValueField('"+spanUpdateTxtOccurCodeId+"','"+updateTxtOccurCodeId+"','"+spanUpdateTxtOccurDateId+"','"+updateTxtOccurDateId+"','"+updateBtnOccurCodeId+"','"+updateSaveBtnOccurCodeId+"','"+updateCancelBtnOccurCodeId+"')\" type=\"button\" value=\"Update\" /> "+
				    "<input name=\""+updateSaveBtnOccurCodeId+"\" height=\"20\" id=\""+updateSaveBtnOccurCodeId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableSaveField('"+claimDetail.editableMfid+"','"+claimDetail.selectedClaimRefNbr+"','"+claimDetail.selectedClaimRevNbr+"','"+claimDetail.selectedClaimSeqNbr+"','"+claimDetail.editableSeqNbr+"','OCCUR_CODE','"+loadImageOccurCodeId+"','"+updateTxtOccurCodeId+"','0','0','"+updateTxtOccurDateId+"','0','0','0','clmtype','"+claimDetail.searchDetailClmType+"','"+newRowId+"')\" type=\"button\" value=\"Save\" />"+
				    "<input name=\""+updateCancelBtnOccurCodeId+"\" height=\"20\" id=\""+updateCancelBtnOccurCodeId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableValueCancelField('"+spanUpdateTxtOccurCodeId+"','"+updateTxtOccurCodeId+"','"+spanUpdateTxtOccurDateId+"','"+updateTxtOccurDateId+"','"+updateBtnOccurCodeId+"','"+updateSaveBtnOccurCodeId+"','"+updateCancelBtnOccurCodeId+"')\" type=\"button\" value=\"Cancel\" />"+
				    "<span id=\""+loadImageOccurCodeId+"\" style=\"display: none;\"> <img alt=\"Loading\" src=\"/mss/jsp/Recon/images/Loading.gif\"></span>"+ 
									
				"</td>"+
				"<td align=\"center\" class=\""+rowClassId+"\">"+
				                             
				"<input name=\""+deleteOccurBtnId+"\" height=\"20\" id=\""+deleteOccurBtnId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableDeleteField('"+claimDetail.editableMfid+"','"+claimDetail.selectedClaimRefNbr+"','"+claimDetail.selectedClaimRevNbr+"','"+claimDetail.selectedClaimSeqNbr+"','"+claimDetail.editableSeqNbr+"','OCCUR_CODE','"+loadImageOccurCodeId+"','"+updateTxtOccurCodeId+"','0','0','"+updateTxtOccurDateId+"','0','0','0','clmtype','"+claimDetail.searchDetailClmType+"','"+newRowId+"')\" type=\"button\" value=\"Delete\" />"+
				                            
				"</td>"+
			"</tr>"	;	
			break;
			
		//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start	
		case 'ADJUD_ADJUST':
			var rowClassId=((newRowId % 2) == 0) ? "evenRow" : "oddRow";
			var adjudAdjustRowId="adjudAdjustRow"+newRowId;
			var spanUpdateTxtAdjudAdjustId="spanUpdateTxtAdjudAdjust"+newRowId;
			var spanUpdateTxtAdjudAdjustReasonId="spanUpdateTxtAdjudAdjustReason"+newRowId;
			var spanUpdateTxtAdjudAdjustAmountId="spanUpdateTxtAdjudAdjustAmount"+newRowId;
			var spanUpdateTxtAdjudAdjustQuantityId="spanUpdateTxtAdjudAdjustQuantity"+newRowId;
			var updateTxtAdjudAdjustId="updateTxtAdjudAdjust"+newRowId;
			var updateTxtAdjudAdjustReasonId="updateTxtAdjudAdjustReason"+newRowId;
			var updateTxtAdjudAdjustAmountId="updateTxtAdjudAdjustAmount"+newRowId;
			var updateTxtAdjudAdjustQuantityId="updateTxtAdjudAdjustQuantity"+newRowId;
			var updateBtnAdjudAdjustId="updateBtnAdjudAdjust"+newRowId;
			var updateSaveBtnAdjudAdjustId="updateSaveBtnAdjudAdjust"+newRowId;
			var updateCancelBtnAdjudAdjustId="updateCancelBtnAdjudAdjust"+newRowId;

			var loadImageAdjudAdjustId="loadImageAdjudAdjust"+newRowId;

			var deleteAdjudAdjustBtnId="deleteAdjudAdjustBtn"+newRowId;
			var adjudGroupCode=claimDetail.adjudGroupCode;
			var adjudReasonCode=claimDetail.adjudReasonCode;
			var adjudAmount=claimDetail.adjudAmount;
			var adjudQuantity=claimDetail.adjudQuantity;
			
			// Handle No Data section
			rowStr=
				"<tr class=\""+rowClassId+"\" id=\""+adjudAdjustRowId+"\">"+
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtAdjudAdjustId+"\">"+adjudGroupCode+"</span>&nbsp; <input name=\""+updateTxtAdjudAdjustId+"\"  id=\""+updateTxtAdjudAdjustId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"2\" value=\""+adjudGroupCode+"\"></td>" +
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtAdjudAdjustReasonId+"\">"+adjudReasonCode+"</span>&nbsp; <input name=\""+updateTxtAdjudAdjustReasonId+"\"  id=\""+updateTxtAdjudAdjustReasonId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"5\" value=\""+adjudReasonCode+"\"></td>" +
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtAdjudAdjustAmountId+"\">"+adjudAmount+"</span>&nbsp; <input name=\""+updateTxtAdjudAdjustAmountId+"\"  id=\""+updateTxtAdjudAdjustAmountId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"10\" value=\""+adjudAmount+"\"></td>" +		//IFOX-00415579 - Claim Line Adjud Adjstmnt Amount field Max length
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtAdjudAdjustQuantityId+"\">"+adjudQuantity+"</span>&nbsp; <input name=\""+updateTxtAdjudAdjustQuantityId+"\"  id=\""+updateTxtAdjudAdjustQuantityId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"8\" value=\""+adjudQuantity+"\"></td>" +
			                            
			    "<td align=\"center\" class=\""+rowClassId+"\">"+ 
				    "<input name=\""+updateBtnAdjudAdjustId+"\" height=\"20\" id=\""+updateBtnAdjudAdjustId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableAdjudAdjustField('"+spanUpdateTxtAdjudAdjustId+"','"+updateTxtAdjudAdjustId+"','"+spanUpdateTxtAdjudAdjustReasonId+"','"+updateTxtAdjudAdjustReasonId+"','"+spanUpdateTxtAdjudAdjustAmountId+"','"+updateTxtAdjudAdjustAmountId+"','"+spanUpdateTxtAdjudAdjustQuantityId+"','"+updateTxtAdjudAdjustQuantityId+"','"+updateBtnAdjudAdjustId+"','"+updateSaveBtnAdjudAdjustId+"','"+updateCancelBtnAdjudAdjustId+"')\" type=\"button\" value=\"Update\" /> "+
				    "<input name=\""+updateSaveBtnAdjudAdjustId+"\" height=\"20\" id=\""+updateSaveBtnAdjudAdjustId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableSaveField('"+claimDetail.editableMfid+"','"+claimDetail.selectedClaimRefNbr+"','"+claimDetail.selectedClaimRevNbr+"','"+claimDetail.selectedClaimSeqNbr+"','"+claimDetail.editableSeqNbr+"','ADJUD_ADJUST_IN','"+loadImageAdjudAdjustId+"','"+updateTxtAdjudAdjustId+"','"+updateTxtAdjudAdjustReasonId+"','"+updateTxtAdjudAdjustAmountId+"','"+updateTxtAdjudAdjustQuantityId+"','"+claimDetail.clmliAdjudSeqNbr+"','"+claimDetail.clmliSeqNbr+"','0','clmtype','"+claimDetail.searchDetailClmType+"','"+newRowId+"')\" type=\"button\" value=\"Save\" />"+
				    "<input name=\""+updateCancelBtnAdjudAdjustId+"\" height=\"20\" id=\""+updateCancelBtnAdjudAdjustId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableAdjudAdjustCancelField('"+spanUpdateTxtAdjudAdjustId+"','"+updateTxtAdjudAdjustId+"','"+spanUpdateTxtAdjudAdjustReasonId+"','"+updateTxtAdjudAdjustReasonId+"','"+spanUpdateTxtAdjudAdjustAmountId+"','"+updateTxtAdjudAdjustAmountId+"','"+spanUpdateTxtAdjudAdjustQuantityId+"','"+updateTxtAdjudAdjustQuantityId+"','"+updateBtnAdjudAdjustId+"','"+updateSaveBtnAdjudAdjustId+"','"+updateCancelBtnAdjudAdjustId+"')\" type=\"button\" value=\"Cancel\" />"+
				    "<span id=\""+loadImageAdjudAdjustId+"\" style=\"display: none;\"> <img alt=\"Loading\" src=\"/mss/jsp/Recon/images/Loading.gif\"></span>"+ 
									
				"</td>"+
				"<td align=\"center\" class=\""+rowClassId+"\">"+
				                             
				"<input name=\""+deleteAdjudAdjustBtnId+"\" height=\"20\" id=\""+deleteAdjudAdjustBtnId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableDeleteField('"+claimDetail.editableMfid+"','"+claimDetail.selectedClaimRefNbr+"','"+claimDetail.selectedClaimRevNbr+"','"+claimDetail.selectedClaimSeqNbr+"','"+claimDetail.editableSeqNbr+"','ADJUD_ADJUST_IN','"+loadImageAdjudAdjustId+"','"+updateTxtAdjudAdjustId+"','"+updateTxtAdjudAdjustReasonId+"','"+updateTxtAdjudAdjustAmountId+"','"+updateTxtAdjudAdjustQuantityId+"','"+claimDetail.clmliAdjudSeqNbr+"','"+claimDetail.clmliSeqNbr+"','0','clmtype','"+claimDetail.searchDetailClmType+"','"+newRowId+"')\" type=\"button\" value=\"Delete\" />"+
				                            
				"</td>"+
			"</tr>"	;	
			break;
		//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End
						
	}
	//Professional Claim Code Changes
	}else if(encType == 'P' || encType == 'E'){
		switch (hier) {
		case 'COND_CODE':
			var rowClassId=((newRowId % 2) == 0) ? "evenRow" : "oddRow";
			var condCodeRowId="condCodeRow"+newRowId;
			var spanUpdateTxtCondCodeId="spanUpdateTxtCondCode"+newRowId;
			var updateTxtCondCodeId="updateTxtCondCode"+newRowId;
			var updateBtnCondCodeId="updateBtnCondCode"+newRowId;
			var updateSaveBtnCondCodeId="updateSaveBtnCondCode"+newRowId;
			var updateCancelBtnCondCodeId="updateCancelBtnCondCode"+newRowId;

			var loadImageCondCodeId="loadImageCondCode"+newRowId;

			var deleteCondBtnId="deleteCondBtn"+newRowId;
			var condCodeValue=claimDetail.editableCode;
			
			// Handle No Data section
			rowStr=
				"<tr class=\""+rowClassId+"\" id=\""+condCodeRowId+"\">"+
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtCondCodeId+"\">"+condCodeValue+"</span>&nbsp; <input name=\""+updateTxtCondCodeId+"\"  id=\""+updateTxtCondCodeId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"2\" value=\""+condCodeValue+"\"></td>" +
			                            
			    "<td align=\"center\" class=\""+rowClassId+"\">"+ 
				    "<input height=\"20\" id=\""+updateBtnCondCodeId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableField('"+updateBtnCondCodeId+"','"+spanUpdateTxtCondCodeId+"','"+updateSaveBtnCondCodeId+"','"+updateCancelBtnCondCodeId+"','"+updateTxtCondCodeId+"')\" type=\"button\" value=\"Update\" /> "+
				    "<input name=\""+updateSaveBtnCondCodeId+"\" height=\"20\" id=\""+updateSaveBtnCondCodeId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableSaveField('"+claimDetail.editableMfid+"','"+claimDetail.selectedClaimRefNbr+"','"+claimDetail.selectedClaimRevNbr+"','"+claimDetail.selectedClaimSeqNbr+"','"+claimDetail.editableCndSeqNbr+"','COND_CODE','"+loadImageCondCodeId+"','"+updateTxtCondCodeId+"','0','0','0','0','0','0','clmtype','"+claimDetail.searchDetailClmType+"','"+newRowId+"')\" type=\"button\" value=\"Save\" />"+
				    "<input name=\""+updateCancelBtnCondCodeId+"\" height=\"20\" id=\""+updateCancelBtnCondCodeId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableCancelField('"+updateBtnCondCodeId+"','"+spanUpdateTxtCondCodeId+"','"+updateSaveBtnCondCodeId+"','"+updateCancelBtnCondCodeId+"','"+updateTxtCondCodeId+"','"+loadImageCondCodeId+"')\" type=\"button\" value=\"Cancel\" />"+
				    "<span id=\""+loadImageCondCodeId+"\" style=\"display: none;\"> <img alt=\"Loading\" src=\"/mss/jsp/Recon/images/Loading.gif\"></span>"+ 
									
				"</td>"+
				"<td align=\"center\" class=\""+rowClassId+"\">"+
				                             
				"<input name=\""+deleteCondBtnId+"\" height=\"20\" id=\""+deleteCondBtnId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableDeleteField('"+claimDetail.editableMfid+"','"+claimDetail.selectedClaimRefNbr+"','"+claimDetail.selectedClaimRevNbr+"','"+claimDetail.selectedClaimSeqNbr+"','"+claimDetail.editableCndSeqNbr+"','COND_CODE','"+loadImageCondCodeId+"','"+updateTxtCondCodeId+"','0','0','0','0','0','0','clmtype','"+claimDetail.searchDetailClmType+"','"+newRowId+"')\" type=\"button\" value=\"Delete\" />"+
				                            
				"</td>"+
			"</tr>"	;		
			break;
			
		case 'DIAG_CODE':
			var rowClassId=((newRowId % 2) == 0) ? "evenRow" : "oddRow";
			var diagCodeRowId="diagCodeRow"+newRowId;
			var spanUpdateTxtDiagCodeId="spanUpdateTxtdiagCode"+newRowId;
			var spanUpdateTxtDiagTypeId="spanUpdateTxtdiagType"+newRowId;
			var spanUpdateTxtDiagPOAId="spanUpdateTxtdiagPOA"+newRowId;
			var updateTxtDiagTypeId="updateTxtDiagType"+newRowId;
			var updateTxtDiagCodeId="updateTxtDiagCode"+newRowId;
			var updateTxtDiagPOAId="updateTxtDiagPOA"+newRowId;
			var updateBtnDiagCodeId="updateBtnDiagCode"+newRowId;
			var updateSaveBtnDiagCodeId="updateSaveBtnDiagCode"+newRowId;
			var updateCancelBtnDiagCodeId="updateCancelBtnDiagCode"+newRowId;

			var loadImageDiagCodeId="loadImageDiagCode"+newRowId;

			var deleteDiagBtnId="deleteDiagBtn"+newRowId;
			var diagCodeValue=claimDetail.editableCode;
			var diagTypeValue=claimDetail.editableType;
			var diagpresentOnAdmitIndValue=claimDetail.editablePOA;
			// Handle No Data section
			rowStr=
				"<tr class=\""+rowClassId+"\" id=\""+diagCodeRowId+"\">"+
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtDiagTypeId+"\">"+diagTypeValue+"</span>&nbsp; <input name=\""+updateTxtDiagTypeId+"\"  id=\""+updateTxtDiagTypeId+"\" style=\"display: none; width=50px; cursor: pointer;\" type=\"text\" maxlength=\"3\" value=\""+diagTypeValue+"\"></td>" +
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtDiagCodeId+"\">"+diagCodeValue+"</span>&nbsp; <input name=\""+updateTxtDiagCodeId+"\"  id=\""+updateTxtDiagCodeId+"\" style=\"display: none; width=50px; cursor: pointer;\" type=\"text\" maxlength=\"7\" value=\""+diagCodeValue+"\"></td>" +
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtDiagPOAId+"\">"+diagpresentOnAdmitIndValue+"</span>&nbsp; <input name=\""+updateTxtDiagPOAId+"\" height=\"20\" id=\""+updateTxtDiagPOAId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"1\" value=\""+diagpresentOnAdmitIndValue+"\"></td>" +

			    "<td align=\"center\" class=\""+rowClassId+"\">"+ 
				    "<input height=\"20\" id=\""+updateBtnDiagCodeId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableDiagField('"+spanUpdateTxtDiagTypeId+"','"+updateTxtDiagTypeId+"','"+spanUpdateTxtDiagCodeId+"','"+updateTxtDiagCodeId+"','"+spanUpdateTxtDiagPOAId+"','"+updateTxtDiagPOAId+"','"+updateBtnDiagCodeId+"','"+updateSaveBtnDiagCodeId+"','"+updateCancelBtnDiagCodeId+"')\" type=\"button\" value=\"Update\" /> "+
				    "<input name=\""+updateSaveBtnDiagCodeId+"\" height=\"20\" id=\""+updateSaveBtnDiagCodeId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableSaveField('"+claimDetail.editableMfid+"','"+claimDetail.selectedClaimRefNbr+"','"+claimDetail.selectedClaimRevNbr+"','"+claimDetail.selectedClaimSeqNbr+"','"+claimDetail.editableSeqNbr+"','DIAG_CODE','"+loadImageDiagCodeId+"','"+updateTxtDiagCodeId+"','"+updateTxtDiagTypeId+"','"+updateTxtDiagPOAId+"','0','0','0','0','clmtype','"+claimDetail.searchDetailClmType+"','"+newRowId+"')\" type=\"button\" value=\"Save\" />"+
				    "<input name=\""+updateCancelBtnDiagCodeId+"\" height=\"20\" id=\""+updateCancelBtnDiagCodeId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableDiagCancelField('"+spanUpdateTxtDiagTypeId+"','"+updateTxtDiagTypeId+"','"+spanUpdateTxtDiagCodeId+"','"+updateTxtDiagCodeId+"','"+spanUpdateTxtDiagPOAId+"','"+updateTxtDiagPOAId+"','"+updateBtnDiagCodeId+"','"+updateSaveBtnDiagCodeId+"','"+updateCancelBtnDiagCodeId+"')\" type=\"button\" value=\"Cancel\" />"+	//IFOX-00407127 -- Updateable Fields - Primary Diagnosis
				    "<span id=\""+loadImageDiagCodeId+"\" style=\"display: none;\"> <img alt=\"Loading\" src=\"/mss/jsp/Recon/images/Loading.gif\"></span>"+ 
									
				"</td>"+
				"<td align=\"center\" class=\""+rowClassId+"\">"+
				
				                             
				"<input name=\""+deleteDiagBtnId+"\" height=\"20\" id=\""+deleteDiagBtnId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableDeleteField('"+claimDetail.editableMfid+"','"+claimDetail.selectedClaimRefNbr+"','"+claimDetail.selectedClaimRevNbr+"','"+claimDetail.selectedClaimSeqNbr+"','"+claimDetail.editableSeqNbr+"','DIAG_CODE','"+loadImageDiagCodeId+"','"+updateTxtDiagCodeId+"','"+updateTxtDiagTypeId+"','"+updateTxtDiagPOAId+"','0','0','0','0','clmtype','"+claimDetail.searchDetailClmType+"','"+newRowId+"')\" type=\"button\" value=\"Delete\" />"+
				                            
				"</td>"+
			"</tr>"	;	
			break;	
			
		//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
		case 'ADJUD_ADJUST':
			var rowClassId=((newRowId % 2) == 0) ? "evenRow" : "oddRow";
			var adjudAdjustRowId="adjudAdjustRow"+newRowId;
			var spanUpdateTxtAdjudAdjustId="spanUpdateTxtAdjudAdjust"+newRowId;
			var spanUpdateTxtAdjudAdjustReasonId="spanUpdateTxtAdjudAdjustReason"+newRowId;
			var spanUpdateTxtAdjudAdjustAmountId="spanUpdateTxtAdjudAdjustAmount"+newRowId;
			var spanUpdateTxtAdjudAdjustQuantityId="spanUpdateTxtAdjudAdjustQuantity"+newRowId;
			var updateTxtAdjudAdjustId="updateTxtAdjudAdjust"+newRowId;
			var updateTxtAdjudAdjustReasonId="updateTxtAdjudAdjustReason"+newRowId;
			var updateTxtAdjudAdjustAmountId="updateTxtAdjudAdjustAmount"+newRowId;
			var updateTxtAdjudAdjustQuantityId="updateTxtAdjudAdjustQuantity"+newRowId;
			var updateBtnAdjudAdjustId="updateBtnAdjudAdjust"+newRowId;
			var updateSaveBtnAdjudAdjustId="updateSaveBtnAdjudAdjust"+newRowId;
			var updateCancelBtnAdjudAdjustId="updateCancelBtnAdjudAdjust"+newRowId;

			var loadImageAdjudAdjustId="loadImageAdjudAdjust"+newRowId;

			var deleteAdjudAdjustBtnId="deleteAdjudAdjustBtn"+newRowId;
			var adjudGroupCode=claimDetail.adjudGroupCode;
			var adjudReasonCode=claimDetail.adjudReasonCode;
			var adjudAmount=claimDetail.adjudAmount;
			var adjudQuantity=claimDetail.adjudQuantity;

			// Handle No Data section
			rowStr=
				"<tr class=\""+rowClassId+"\" id=\""+adjudAdjustRowId+"\">"+
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtAdjudAdjustId+"\">"+adjudGroupCode+"</span>&nbsp; <input name=\""+updateTxtAdjudAdjustId+"\"  id=\""+updateTxtAdjudAdjustId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"2\" value=\""+adjudGroupCode+"\"></td>" +
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtAdjudAdjustReasonId+"\">"+adjudReasonCode+"</span>&nbsp; <input name=\""+updateTxtAdjudAdjustReasonId+"\"  id=\""+updateTxtAdjudAdjustReasonId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"5\" value=\""+adjudReasonCode+"\"></td>" +
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtAdjudAdjustAmountId+"\">"+adjudAmount+"</span>&nbsp; <input name=\""+updateTxtAdjudAdjustAmountId+"\"  id=\""+updateTxtAdjudAdjustAmountId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"10\" value=\""+adjudAmount+"\"></td>" +		//IFOX-00415579 - Claim Line Adjud Adjstmnt Amount field Max length
			    "<td align=\"center\" class=\""+rowClassId+"\">&nbsp;<span id=\""+spanUpdateTxtAdjudAdjustQuantityId+"\">"+adjudQuantity+"</span>&nbsp; <input name=\""+updateTxtAdjudAdjustQuantityId+"\"  id=\""+updateTxtAdjudAdjustQuantityId+"\" style=\"display: none;width=50px; cursor: pointer;\" type=\"text\" maxlength=\"8\" value=\""+adjudQuantity+"\"></td>" +
			                            
			    "<td align=\"center\" class=\""+rowClassId+"\">"+ 
				    "<input name=\""+updateBtnAdjudAdjustId+"\" height=\"20\" id=\""+updateBtnAdjudAdjustId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableAdjudAdjustField('"+spanUpdateTxtAdjudAdjustId+"','"+updateTxtAdjudAdjustId+"','"+spanUpdateTxtAdjudAdjustReasonId+"','"+updateTxtAdjudAdjustReasonId+"','"+spanUpdateTxtAdjudAdjustAmountId+"','"+updateTxtAdjudAdjustAmountId+"','"+spanUpdateTxtAdjudAdjustQuantityId+"','"+updateTxtAdjudAdjustQuantityId+"','"+updateBtnAdjudAdjustId+"','"+updateSaveBtnAdjudAdjustId+"','"+updateCancelBtnAdjudAdjustId+"')\" type=\"button\" value=\"Update\" /> "+
				    "<input name=\""+updateSaveBtnAdjudAdjustId+"\" height=\"20\" id=\""+updateSaveBtnAdjudAdjustId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableSaveField('"+claimDetail.editableMfid+"','"+claimDetail.selectedClaimRefNbr+"','"+claimDetail.selectedClaimRevNbr+"','"+claimDetail.selectedClaimSeqNbr+"','"+claimDetail.editableSeqNbr+"','ADJUD_ADJUST_IN','"+loadImageAdjudAdjustId+"','"+updateTxtAdjudAdjustId+"','"+updateTxtAdjudAdjustReasonId+"','"+updateTxtAdjudAdjustAmountId+"','"+updateTxtAdjudAdjustQuantityId+"','"+claimDetail.clmliAdjudSeqNbr+"','"+claimDetail.clmliSeqNbr+"','0','clmtype','"+claimDetail.searchDetailClmType+"','"+newRowId+"')\" type=\"button\" value=\"Save\" />"+
				    "<input name=\""+updateCancelBtnAdjudAdjustId+"\" height=\"20\" id=\""+updateCancelBtnAdjudAdjustId+"\" style=\"display: none; cursor: pointer;\" onclick=\"UpdatableAdjudAdjustCancelField('"+spanUpdateTxtAdjudAdjustId+"','"+updateTxtAdjudAdjustId+"','"+spanUpdateTxtAdjudAdjustReasonId+"','"+updateTxtAdjudAdjustReasonId+"','"+spanUpdateTxtAdjudAdjustAmountId+"','"+updateTxtAdjudAdjustAmountId+"','"+spanUpdateTxtAdjudAdjustQuantityId+"','"+updateTxtAdjudAdjustQuantityId+"','"+updateBtnAdjudAdjustId+"','"+updateSaveBtnAdjudAdjustId+"','"+updateCancelBtnAdjudAdjustId+"')\" type=\"button\" value=\"Cancel\" />"+
				    "<span id=\""+loadImageAdjudAdjustId+"\" style=\"display: none;\"> <img alt=\"Loading\" src=\"/mss/jsp/Recon/images/Loading.gif\"></span>"+ 
									
				"</td>"+
				"<td align=\"center\" class=\""+rowClassId+"\">"+
				                             
				"<input name=\""+deleteAdjudAdjustBtnId+"\" height=\"20\" id=\""+deleteAdjudAdjustBtnId+"\" style=\"cursor: pointer;\" onclick=\"UpdatableDeleteField('"+claimDetail.editableMfid+"','"+claimDetail.selectedClaimRefNbr+"','"+claimDetail.selectedClaimRevNbr+"','"+claimDetail.selectedClaimSeqNbr+"','"+claimDetail.editableSeqNbr+"','ADJUD_ADJUST_IN','"+loadImageAdjudAdjustId+"','"+updateTxtAdjudAdjustId+"','"+updateTxtAdjudAdjustReasonId+"','"+updateTxtAdjudAdjustAmountId+"','"+updateTxtAdjudAdjustQuantityId+"','"+claimDetail.clmliAdjudSeqNbr+"','"+claimDetail.clmliSeqNbr+"','0','clmtype','"+claimDetail.searchDetailClmType+"','"+newRowId+"')\" type=\"button\" value=\"Delete\" />"+
				                            
				"</td>"+
			"</tr>"	;	
			break;
		//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End
		}

		
	}
	return rowStr;
}

