function displayException() {
	if (dwr.util.getValue('message') != '') {
		alert(dwr.util.getValue('message'));
	}
}
/* Search */
function gotoApplSearch(applId, dateRange) {
  dwr.util.setValue('applId',applId);
  applDshBrdSubmit('gotoApplSearch');
}
function drillDown(status,user, row) {
  dwr.util.setValue('applStatus', status);
  dwr.util.setValue('user', user);
  applDshBrdSubmit('drillDown');
}
function applDshBrdSelectTab(tabId) {
  dwr.util.setValue('selectedSubMenuTab', tabId);
  applDshBrdSubmit('applDshBrdSelectTab');
}
function applDshBrdSubmit(method) {
  document.body.className = 'wait';
  document.eemDshBrdForm.method.value = method;
  document.eemDshBrdForm.submit();
}