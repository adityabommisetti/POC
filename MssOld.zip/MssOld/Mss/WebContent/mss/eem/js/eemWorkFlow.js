
function userGetWorkSubmit() {
	document.body.className = 'wait';	
  	document.eemWorkFlowForm.method.value = 'usrOptGetWork';
  	document.eemWorkFlowForm.submit();
}

function usersubsetActivitiesSubmit() {
	document.body.className = 'wait';	
  	document.eemWorkFlowForm.method.value = 'usrOptSubsetActivities';
  	document.eemWorkFlowForm.submit();
}  


function selectedUsrAgreementsSearch() {
	document.body.className = 'wait';	
  	document.eemWorkFlowForm.method.value = 'usrOptedGo';
  	document.eemWorkFlowForm.submit();
}

function getAdminHistoryInfo() {
	url = "/eemActionWorkFlow.do?method=getAdminHistory";
  	var ww = 980;
  	var wh = 700;
  	var wt = 1;
  	var wl = ((screen.width - 10) - ww) / 2;
  		
  	eemWFAdmin = window.open(url,"getAdminHistory","toolbar=no,titlebar=0,location=no,directories=no,status=no," +
  			"menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,ControlBox=no,width=" + ww + ",height=" + wh + ",left=" + wl + ",top=" + wt);
  	eemWFAdmin.focus();
}//getAdminHistoryInfo()

function getAdminHistoryDetails() {
	document.body.className = 'wait';	
  	document.eemWorkFlowForm.method.value = 'getAdminHistDetails';
  	document.eemWorkFlowForm.submit();
}//getAdminHistoryDetails()

function adminHistDetailPage(option) {
	document.body.className = 'wait';
	document.eemWorkFlowForm.adminHistPageOpt.value = option;
  	document.eemWorkFlowForm.method.value = 'getAdminHistDetailPage';
  	document.eemWorkFlowForm.submit();
}//adminHistDetailPage()


//045_AssignActivity starts
function parentWFNavigation() {
	
	var remote = window.open("", "EEM");	
	var form = remote.document.forms[0];	
	//form.suprSelectedUName.value = document.getElementById('displayActivityListInfo.userId').value;
	form.navUserId.value = document.getElementById('displayActivityListInfo.userId').value;	
	form.method.value = 'navigateUserOptedGo';
	form.submit();
	remote.focus();
	
}
//045_AssignActivity ends
//045_UserList starts
function userToWFNavigation() {
	
	var remote = window.open("", "EEM");	
	var form = remote.document.forms[0];	
	form.navUserId.value = document.getElementById('displayUserListInfo.usId').value;
	form.method.value = 'navigateUserOptedGo';
	form.submit();
	remote.focus();
	
}
//045_UserList ends

function usrGetWrkAgreementSelect(aggreementId, queueId, row) {
  	document.body.className = 'wait';
  
  	var tbl = document.getElementById('tblUsrAgreementList');
  	var len = tbl.rows.length - 2;
  	for(var i=0; i < len; i++) {
 		if (i == row) {
  			setElemTableRowClass(tbl.rows[i+1],'selectedRow1');
 		} else {
      		if ((i % 2) == 0) {
				setElemTableRowClass(tbl.rows[i+1],'oddRow1');
		    } else {
				setElemTableRowClass(tbl.rows[i+1],'evenRow1');
    		} 		
 		} 
    }
  document.eemWorkFlowForm.userAgreementId.value = aggreementId;
  document.eemWorkFlowForm.userQueueId.value = queueId;
  document.eemWorkFlowForm.method.value = 'usrGetWorkSearchQueue';
  document.eemWorkFlowForm.submit();
 }//usrGetWrkAgreementSelect()


function usrGetWrkQueueSelect(aggreementId, queueId, row, queType, regId, scrId, applId, MbrId, hicNbr) {
	document.body.className = 'wait';
	//alert("in usrGetWrkQueueSelect aggreementId:"+aggreementId+", queueId:"+queueId+", row:"+row+", queType:"+queType+", regId:"+regId+", scrId:"+scrId+", applId:"+applId+", MbrId:"+MbrId+", hicNbr:"+hicNbr);
  	var tbl = document.getElementById('tblUsrAgreementList');
  	var len = tbl.rows.length - 2;
  	for(var i=0; i < len; i++) {
 		if (i == row) {
  			setElemTableRowClass(tbl.rows[i+1],'selectedRow1');
 		} else {
      		if ((i % 2) == 0) {
				setElemTableRowClass(tbl.rows[i+1],'oddRow1');
		    } else {
				setElemTableRowClass(tbl.rows[i+1],'evenRow1');
    		} 		
 		} 
    }

    if(queType == 'CALL'){
	  document.eemWorkFlowForm.hicNbr.value = hicNbr;
	  document.eemWorkFlowForm.screenId.value = scrId;
	  
	  if(regId == 'P'){
		  document.body.className = 'none';
		  url = "/eemActionWorkFlow.do?method=closeAssignActivityInfo&hicNbr="+hicNbr;
			  var ww = 900;
			  var wh = 600;
			  var wt = 1;
			  var wl = ((screen.width - 10) - ww) / 2;
		  var eemWFquePopupWin = window.open(url,"eemWFquePopup","toolbar=no,titlebar=0,location=no,resizable=yes,directories=no,status=no,menubar=no,scrollbars=yes,copyhistory=no,ControlBox=no,width=" + ww + ",height=" + wh + ",left=" + wl + ",top=" + wt);
		  eemWFquePopupWin.focus();		
		  return;
	  }
	  else if(regId == 'A'){
		  document.eemWorkFlowForm.srchAppOrMbrId.value = applId;
		  document.eemWorkFlowForm.method.value = 'usrGetWorkSearchAppl';
	  }else{
		  document.eemWorkFlowForm.srchAppOrMbrId.value = MbrId;
		  document.eemWorkFlowForm.method.value = 'usrGetWorkSearchMember';
	  }	  
    }else{
	  document.eemWorkFlowForm.userAgreementId.value = aggreementId;
	  document.eemWorkFlowForm.userQueueId.value = queueId;
	  document.eemWorkFlowForm.method.value = 'usrGetWorkSearchActivity';
    }	

  	document.eemWorkFlowForm.submit();
 }//usrGetWrkQueueSelect()


function usrGetWrkActivitySelect(regId, scrId, row, applId, MbrId, hicNbr) {
  	document.body.className = 'wait';
  	
  	//on multiple Click in Acticity in workflow main screen issue - Start
  	if( document.getElementById('qActClickVerify').value == 'yes'){
  		alert("in process, please wait");
  		return;
  	}else{  		
  		document.getElementById('qActClickVerify').value='yes';
  	}
   //on multiple Click in Acticity in workflow main screen issue - End
  	
  	var tbl = document.getElementById('tblUsrAgreementList');
  	var len = tbl.rows.length - 2;
  	for(var i=0; i < len; i++) {
 		if (i == row) {
  			setElemTableRowClass(tbl.rows[i+1],'selectedRow1');
 		} else {
      		if ((i % 2) == 0) {
				setElemTableRowClass(tbl.rows[i+1],'oddRow1');
		    } else {
				setElemTableRowClass(tbl.rows[i+1],'evenRow1');
    		} 		
 		} 
    }
  document.eemWorkFlowForm.hicNbr.value = hicNbr;
  document.eemWorkFlowForm.screenId.value = scrId;
  if(regId == 'A'){
	  document.eemWorkFlowForm.srchAppOrMbrId.value = applId;
	  document.eemWorkFlowForm.method.value = 'usrGetWorkSearchAppl';
  }else{
	  document.eemWorkFlowForm.srchAppOrMbrId.value = MbrId;
	  document.eemWorkFlowForm.method.value = 'usrGetWorkSearchMember';
  }	
  document.eemWorkFlowForm.submit();
 }//usrGetWrkActivitySelect()



function usrSubActsAgreementSelect(aggreementId, queueId, row) {
  	document.body.className = 'wait';
  
  	var tbl = document.getElementById('tblUsrAgreementList');
  	var len = tbl.rows.length - 2;
  	for(var i=0; i < len; i++) {
 		if (i == row) {
  			setElemTableRowClass(tbl.rows[i+1],'selectedRow1');
 		} else {
      		if ((i % 2) == 0) {
				setElemTableRowClass(tbl.rows[i+1],'oddRow1');
		    } else {
				setElemTableRowClass(tbl.rows[i+1],'evenRow1');
    		} 		
 		} 
    }
  document.eemWorkFlowForm.userAgreementId.value = aggreementId;
  document.eemWorkFlowForm.userQueueId.value = queueId;
  document.eemWorkFlowForm.method.value = 'usrGetWorkSearchQueue';
  document.eemWorkFlowForm.submit();
}//usrSubActsAgreementSelect()


function usrSubActsQueueSelect(aggreementId, queueId, row, queType, regId, scrId, applId, MbrId, hicNbr) {
	document.body.className = 'wait';
	//alert("in usrGetWrkQueueSelect aggreementId:"+aggreementId+", queueId:"+queueId+", row:"+row+", queType:"+queType+", regId:"+regId+", scrId:"+scrId+", applId:"+applId+", MbrId:"+MbrId+", hicNbr:"+hicNbr);
  	var tbl = document.getElementById('tblUsrAgreementList');
  	var len = tbl.rows.length - 2;
  	for(var i=0; i < len; i++) {
 		if (i == row) {
  			setElemTableRowClass(tbl.rows[i+1],'selectedRow1');
 		} else {
      		if ((i % 2) == 0) {
				setElemTableRowClass(tbl.rows[i+1],'oddRow1');
		    } else {
				setElemTableRowClass(tbl.rows[i+1],'evenRow1');
    		} 		
 		} 
    }  	

    if(queType == 'CALL'){
	  document.eemWorkFlowForm.hicNbr.value = hicNbr;
	  document.eemWorkFlowForm.screenId.value = scrId;
	  if(regId == 'P'){
		  document.body.className = 'none';
		  url = "/eemActionWorkFlow.do?method=closeAssignActivityInfo&hicNbr="+hicNbr+"";
			  var ww = 900;
			  var wh = 600;
			  var wt = 1;
			  var wl = ((screen.width - 10) - ww) / 2;
		  var eemWFquePopupWin = window.open(url,"eemWFquePopup","toolbar=no,titlebar=0,location=no,resizable=yes,directories=no,status=no,menubar=no,scrollbars=yes,copyhistory=no,ControlBox=no,width=" + ww + ",height=" + wh + ",left=" + wl + ",top=" + wt);
		  eemWFquePopupWin.focus();		
		  return;
	  }
	  else if(regId == 'A'){
		  document.eemWorkFlowForm.srchAppOrMbrId.value = applId;
		  document.eemWorkFlowForm.method.value = 'usrGetWorkSearchAppl';
	  }else{
		  document.eemWorkFlowForm.srchAppOrMbrId.value = MbrId;
		  document.eemWorkFlowForm.method.value = 'usrGetWorkSearchMember';
	  }	  
    }else{
	  document.eemWorkFlowForm.userAgreementId.value = aggreementId;
	  document.eemWorkFlowForm.userQueueId.value = queueId;
	  document.eemWorkFlowForm.method.value = 'usrGetWorkSearchActivity';
    }

  	document.eemWorkFlowForm.submit();
 }//usrSubActsQueueSelect()


function usrSubActsActivitySelect(regId, scrId, row, applId, MbrId, hicNbr) {
  	document.body.className = 'wait';  	
  	
  	//on multiple Click in Acticity in workflow main screen issue - Start
  	if( document.getElementById('qActClickVerify').value == 'yes'){
  		alert("in process, please wait");
  		return;
  	}else{  		
  		document.getElementById('qActClickVerify').value='yes';
  	}
  	//on multiple Click in Acticity in workflow main screen issue - End
    
  	var tbl = document.getElementById('tblUsrAgreementList');
  	var len = tbl.rows.length - 2;
  	for(var i=0; i < len; i++) {
 		if (i == row) {
  			setElemTableRowClass(tbl.rows[i+1],'selectedRow1');
 		} else {
      		if ((i % 2) == 0) {
				setElemTableRowClass(tbl.rows[i+1],'oddRow1');
		    } else {
				setElemTableRowClass(tbl.rows[i+1],'evenRow1');
    		} 		
 		} 
    }
  	document.eemWorkFlowForm.hicNbr.value = hicNbr;
  	document.eemWorkFlowForm.screenId.value = scrId;
  	if(regId == 'A'){
		  document.eemWorkFlowForm.srchAppOrMbrId.value = applId;
		  document.eemWorkFlowForm.method.value = 'usrGetWorkSearchAppl';
	}else{
		  document.eemWorkFlowForm.srchAppOrMbrId.value = MbrId;
		  document.eemWorkFlowForm.method.value = 'usrGetWorkSearchMember';
	}	
    document.eemWorkFlowForm.submit();
 }//usrGetWrkActivitySelect()



function userAgreementsSearchPageFirst(){//(val) {
	document.body.className = 'wait';	 	
	document.eemWorkFlowForm.method.value = 'usrAgreementsSearchPageFirst';
	document.eemWorkFlowForm.submit();
}//userAgreementsSearchPageFirst()


function userAgreementsSearchPageNext(){//(val) {
	document.body.className = 'wait';  	
	document.eemWorkFlowForm.method.value = 'usrAgreementsSearchPageNext';
	document.eemWorkFlowForm.submit();
}//userAgreementsSearchPageNext()
/* Fix for Pagination Last(>>) button CR # 00370553 - START */
function userAgreementsSearchPageLast(){//(val) {
	document.body.className = 'wait';  	
	document.eemWorkFlowForm.method.value = 'usrAgreementsSearchPageLast';
	document.eemWorkFlowForm.submit();
}//userAgreementsSearchPageLast()
/* Fix for Pagination Last(>>) button CR # 00370553 - END */

function userAgreementsSearchPagePrev(){//(val) {
	document.body.className = 'wait';
/*	if (val == 'usrGetWrk') {
		document.eemWorkFlowForm.method.value = '';
    } else {
    	document.eemWorkFlowForm.method.value = 'usrAgreementsSearchPagePrev';
	}
*/  	
	document.eemWorkFlowForm.method.value = 'usrAgreementsSearchPagePrev';
	document.eemWorkFlowForm.submit();
}//userAgreementsSearchPagePrev()

function toggleVisibility(x, id) {
	var e = document.getElementById(id);
	if(e.style.display == 'none') {
		e.style.display = "";
		x.src = '/mss/jsp/Recon/images/Minus.png';
	} else {
		e.style.display = 'none';
		x.src = '/mss/jsp/Recon/images/Plus.png';
	}
}//toggleVisibilityUp()




function dwrQueLstCall(prtyMtd) {
	document.body.className = 'wait';
	var txn = dwr.util.getValue('txnType');
	var prty = dwr.util.getValue('prtyType');
	if(prty == ""){
		alert("Please select Priority value");
		document.body.className = 'none';
		return;
	}
	if(txn == 'update' && prty == '99'){
		alert("Update functionality doesn't work with Temp Priority. Pls use Delete then Add");
		document.body.className = 'none';
		return;
	}
	var userId = dwr.util.getValue('displaySupervisorUserInfo.userId');
	FacadeManager.supWorkFlowUserQuesChange(txn, prty, prtyMtd, userId, dwrQueLstData);  
}
	
	
function dwrQueLstData(data) {
	var list = data;
	if(list.length==1 && list[0]=='Temp queue exist'){
		alert("Please Delete or Update existing Temp Queue to create new Temp Queue");
	}else if(list.length==1 && list[0]=='No Queue Found'){
		alert("No Queues found for the search");
		dwr.util.setValue('dwrQLstSelect','');
	}else{
		var content = "<select id='dwrQLstSelect' styleClass='textbox4' style='width:120px;font-size:10px;'>";
		for(var i=0 ; i < list.length ; i++) {
			var temp = list[i].split(":");
			content = content + "<option value='" +temp[0]+ "'>" +temp[1]+ "</option>" ;
		}
		content = content +"<option value=''></option></select>";
		document.getElementById("dwrQueList").innerHTML = content ;
	}//else
	document.body.className = 'none';
}

function txnTypeSelect(){
	document.getElementById("prtyType").value="";
}

function dwrUsrQueUpdateCall() {
	document.body.className = 'wait';
	var txn = dwr.util.getValue('txnType');
	var prty = dwr.util.getValue('prtyType');
	var que = dwr.util.getValue('dwrQLstSelect');
	if(txn == "" || prty == "" || que == ""){
		alert("value missing to update");
		return;
	}
	var userId = dwr.util.getValue('displaySupervisorUserInfo.userId');
	var supUserId = dwr.util.getValue('userId');
	FacadeManager.supWorkFlowUserQueUpdate(txn, prty, que, userId, supUserId, dwrUsrQueUpdateData);  
}
	
function dwrUsrQueUpdateData(data) {
	if(data == 1){
		alert("Update Success");
		document.body.className = 'wait';
		document.eemWorkFlowForm.method.value = 'updateQueueUsers';
	    document.eemWorkFlowForm.submit();
	}else{
		alert("Update Failed");
	}
	dwr.util.setValue('prtyType','');
	document.body.className = 'none';
}

function dwrSelUsrQueuesCall() {
	document.body.className = 'wait';
	var userId = dwr.util.getValue('usrLstDropDown');
	FacadeManager.supLoadUserQNames(userId, dwrSelUsrQueuesData);  
}
	
function dwrSelUsrQueuesData(data) {
	var list = data;
	var content = "<select name='usrGetWrkQName' onchange='searchQNameChanged();' style='width:110px;' class='textbox4'>";
	for(var i=0 ; i < list.length ; i++) {
		var temp = list[i].split(":");
		content = content + "<option value='" +temp[0]+ "'>" +temp[1]+ "</option>" ;
	}
	content = content +"</select>";
	document.getElementById("dwrUsrQLstDiv").innerHTML = content ;
	document.body.className = 'none';
}

function reloadPriorites(){
	document.body.className = 'wait';	
  	document.eemWorkFlowForm.method.value = 'usrOptgetPriorites';
  	document.eemWorkFlowForm.submit();
}
/**
 * 045_AtRisk changes Start
 */	
function atRiskRowSelection(queueCode,queuePriority,daysLeft,row) {	
  	document.body.className = 'wait'; 
  	var tbl = document.getElementById('tblAtRiskSummaryList');
  	var len = tbl.rows.length - 2;
  	for(var i=0; i < len; i++) {
 		if (i == row) {
  			setElemTableRowClass(tbl.rows[i+1],'selectedRow1');
 		} else {
      		if ((i % 2) == 0) {
				setElemTableRowClass(tbl.rows[i+1],'oddRow1');
		    } else {
				setElemTableRowClass(tbl.rows[i+1],'evenRow1');
    		} 		
 		} 
    }
  	document.eemWorkFlowForm.atRiskRowCnt.value = row;
  	document.eemWorkFlowForm.queueCode.value = queueCode;
  	document.eemWorkFlowForm.daysLeft.value = daysLeft;
    document.eemWorkFlowForm.queuePriority.value = queuePriority;
    document.eemWorkFlowForm.method.value = 'getAtRiskDetailInfo';
    document.eemWorkFlowForm.submit();
}
/**
 * 045_AtRisk changes End
 */	

//Admin History - getting Supervisors of an Admin.
function dwrAdminHistGetSuprvsCall() {
	document.body.className = 'wait';
	var adminId = dwr.util.getValue('srchAdmin');
	if(adminId != null && adminId != ''){
		FacadeManager.adminHistLoadSuprvs(adminId, dwrAdminHistGetSuprvsData);
	}
	document.body.className = 'none';
	dwr.util.setValue('srchSupr',"");
	dwr.util.setValue('srchCompUser',"");
	dwr.util.setValue('srchInitUser',"");
}
	
function dwrAdminHistGetSuprvsData(data) {
	var list = data;
	var content = "<select name='adminSrchSuprv' onchange='dwrAdminHistGetUsersCall()' style='width:100px;' class='textbox4' id='srchSupr'>";
	for(var i=0 ; i < list.length ; i++) {
		var temp = list[i].split(":");
		content = content + "<option value='" +temp[0]+ "'>" +temp[1]+ "</option>" ;
	}
	content = content +"</select>";
	document.getElementById("divAdminHistSuprvs").innerHTML = content ;
	document.body.className = 'none';
}//dwrAdminHistGetSuprvsData()

//Admin History - getting Users of a Supervisor.
function dwrAdminHistGetUsersCall() {
	document.body.className = 'wait';
	var suprvId = dwr.util.getValue('srchSupr');
	if(suprvId != null && suprvId != ''){
		FacadeManager.adminHistLoadUsers(suprvId, dwrAdminHistgetUsersData); 
	}	
	document.body.className = 'none';
	dwr.util.setValue('srchCompUser',"");
	dwr.util.setValue('srchInitUser',"");
}
	
function dwrAdminHistgetUsersData(data) {
	var list = data;
	var contentCU = "<select name='adminSrchCompUsr' style='width:100px;' class='textbox4' id='srchCompUser'>";
	var contentIU = "<select name='adminSrchInitUsr' style='width:100px;' class='textbox4' id='srchInitUser'>";
	for(var i=0 ; i < list.length ; i++) {
		var temp = list[i].split(":");
		contentCU = contentCU + "<option value='" +temp[0]+ "'>" +temp[1]+ "</option>" ;
		contentIU = contentIU + "<option value='" +temp[0]+ "'>" +temp[1]+ "</option>" ;
	}
	contentCU = contentCU +"</select>";
	contentIU = contentIU +"</select>";
	document.getElementById("divAdminHistCompUsers").innerHTML = contentCU ;
	document.getElementById("divAdminHistInitUsers").innerHTML = contentIU ;
	document.body.className = 'none';
}//dwrAdminHistgetUsersData()






