// $Id: eemGrps.js,v 1.1 2014/06/26 07:56:52 praveen Exp $
function doGroupsSearch() {

	doSubmit('search');
}

function getGroupDetail(rowId, rowNbr) {

  	document.body.className = 'wait';
  
  	var tbl = document.getElementById('groupResultTbl');
  	var len = tbl.rows.length-1;
  	for(var i=1; i < len; i++) {
  		if ((i%2) == 0) {
  			setElemTableRowClass(tbl.rows[i], 'evenRow');
	  	} else {
	  		setElemTableRowClass(tbl.rows[i], 'oddRow');
	    }
	}
	setElemTableRowClass(rowId, 'selectedRow');
  
	document.forms[0].newSelectedRow.value = rowNbr;
	doSubmit('getGroup');
}

function getGrpAddrDetail(rowId, rowNbr) {
  	document.body.className = 'wait';
  
  	var tbl = document.getElementById('addressResultTbl');
  	var len = tbl.rows.length-1;
  	for(var i=1; i < len; i++) {
  		if ((i%2) == 0) {
  			setElemTableRowClass(tbl.rows[i], 'evenRow');
	  	} else {
	  		setElemTableRowClass(tbl.rows[i], 'oddRow');
	    }
	}
	setElemTableRowClass(rowId, 'selectedRow');

	document.forms[0].newSelectedAddrRow.value = rowNbr;
	doSubmit('getGrpAddr');
}

function doSubmit(method) {

	document.forms[0].method.value = method;
  	document.forms[0].submit();
}

function grpSearchPageFirst(ctl) {
  document.body.className = 'wait';
  document.eemGroupForm.method.value = "grpSearchPageFirst";
  document.eemGroupForm.submit();
}
function grpSearchPagePrev(ctl) {
  document.body.className = 'wait';
  document.eemGroupForm.method.value = "grpSearchPagePrev";
  document.eemGroupForm.submit();
}
function grpSearchPageNext(ctl) {
  document.body.className = 'wait';
  document.eemGroupForm.method.value = "grpSearchPageNext";
  document.eemGroupForm.submit();
}
