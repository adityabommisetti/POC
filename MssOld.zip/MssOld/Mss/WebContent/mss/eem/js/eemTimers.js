//$Id: eemTimers.js,v 1.2 2014/08/01 10:24:36 praveen Exp $ 

function timersSearchPageFirst(ctl) {
  document.body.className = 'wait';
  document.eemTimersForm.method.value = "timersPageFirst";
  document.eemTimersForm.submit();
}
function timersSearchPagePrev(ctl) {
  document.body.className = 'wait';
  document.eemTimersForm.method.value = "timersPagePrev";
  document.eemTimersForm.submit();
}
function timersSearchPageNext(ctl) {
  document.body.className = 'wait';
  document.eemTimersForm.method.value = "timersPageNext";
  document.eemTimersForm.submit();
}

function timerSubmit(method) 
{
	document.body.className = 'wait';	
	document.eemTimersForm.method.value = method;
  	document.eemTimersForm.submit();
}


function timerEdit(row)
{

var ctl;
    ctl = document.getElementsByName('timeroffa_'+row)[0];
    ctl.disabled=false;
    ctl.style.backgroundColor="#F2F5A9";
    ctl = document.getElementById('actTime_'+row);
	ctl.style.display = "none";
    ctl = document.getElementById('textBx_'+row);
	ctl.style.display = "";
    ctl = document.getElementById('editCheck_'+row);
    ctl.style.display = "";
    //UAT IFOX-00348457 --Start
    ctl = dwr.util.getValue('searchId');
 
   if(ctl==null || ctl == ""){
	   ctl=document.forms[0].editActivationDateStatus[row];
	    ctl.style.background="#F2F5A9";
 }
   else{
	   ctl=document.forms[0].editActivationDateStatus;
       ctl.style.background="#F2F5A9";
   }
   //UAT IFOX-00348457 --End
   
   
    
}
function activationChange(row)
{
	var actDate = document.getElementsByName('editActivationDateStatus')[0];
	dateFormatting(actDate);
	 var ctl;

	ctl = document.getElementsByName('timeroffa_'+row)[0];
	  ctl.disabled=true;
		
	
	
}
function timerCheck(row1,a)

{


   var ctl;

	ctl = document.getElementsByName('timeroffa_'+row1)[0];

	

	if(ctl.checked==true)
	{

    ctl = document.getElementById('textBx_'+row1);
	ctl.style.display = "none";

	
	if (confirm('Do you really want to TurnOFF the Timer?')) { 
		
		ctl = document.getElementById('actTime_'+row1);
		ctl.style.display = "";
		document.forms[0].checkBoxStatus[row1].value='Y';
		}
	else{
	
		  ctl = document.getElementById('textBx_'+row1);
			ctl.style.display = "";
			ctl = document.getElementsByName('timeroffa_'+row1)[0];
			ctl.checked=false;
	}
	
	}
	else if(ctl.checked==false)
		{
		
		ctl = document.getElementById('textBx_'+row1);
		ctl.style.display = "";
		
		ctl = document.getElementById('actTime_'+row1);
		ctl.style.display = "none";
		}
}
function doDateChange(ctl, allowNines) {

    var rslt = parseDateFld9(ctl.value,true,true,"",allowNines);
    if (rslt != "NaD"){
        ctl.value = rslt;
    return true;
    }
  return false;
}



function eemTimers()
{ 
	var ctl = document.getElementsByName('editActivationDateStatus')[0];
    var actDate = dwr.util.getValue('editActivationDateStatus');
if(actDate=="")
		{
		
		alert("Activation Date cannot be blank");
		}
	else{
	var checkDate= doDateChange(ctl,false);
	
	if(checkDate==true){
	 document.body.className = 'wait';
	document.eemTimersForm.method.value = 'eemTimersUpdate';
  	document.eemTimersForm.submit();
		
	}
	}
  
}