// $Id: eemAppl.js,v 1.20 2015/11/16 23:07:01 dinesh Exp $
/* General Application */
function changeOption(val) {
  //document.body.style.cursor = 'wait';
  document.body.className = 'wait';
  if(val == 'NMA') {
	method='applNewMemberMA';  
  } else if (val == 'NPD') {
  	method='applNewMemberPD';
  } else if (val == 'CMA') {
  	method='contractChgMA';	
  } else if (val == 'CPD') {
  	method='contractChgPD';
  }	
  document.eemApplForm.method.value = method;
  document.eemApplForm.submit();
}
function createErrorList() {
  for(i=0; i<arrError.length; i++){
  	var name = arrError[i][0];
  	if (name == 'enrollProduct') {
  		name = 'enrollProdName';
  	}
  	var ele = document.getElementsByName(name)[0];
  	if (ele == null)
  		continue; 
  	if(ele.name == 'electionType') {
  	    setTimeout(function(){ $('#select2-eleType-container').css('background-color','yellow'); }, 2000);		
  	} else {
  		ele.style.background = 'yellow';
  	}
	   
  	ele.title = arrError[i][1];
  }
}
function setOnchangeEvent() {
	
  ele = document.eemApplForm.elements;
  
  for(i=0;i<ele.length;i++) {
  	if (ele[i].name == 'attestDt') {
  		ele[i].onchange = function() {formatDate(this);futureDateValidation(this);if(!validateDate(this))return false;if(!compareAttestDt(this))return false;}
  	} else {
  		
		ele[i].onchange = function() {onChangeEvent(this);};  	
	}
  }
   //IFOX- 421780 : Part A/B/D Date Format Validation - start 
  document.getElementsByName("partAEffDt")[0].onchange = function() {formatDate(this);validatePartAB(this);}
  document.getElementsByName("partBEffDt")[0].onchange = function() {formatDate(this);validatePartAB(this);}
  document.getElementsByName("partDEffDt")[0].onchange = function() {formatDate(this);validatePartAB(this);}
  document.getElementsByName("partAEffDt")[1].onchange = function() {formatDate(this);validatePartAB(this);}
  document.getElementsByName("partBEffDt")[1].onchange = function() {formatDate(this);validatePartAB(this);}
  document.getElementsByName("partDEffDt")[1].onchange = function() {formatDate(this);validatePartAB(this);}
   //IFOX- 421780 : Part A/B/D Date Format Validation - end
  document.getElementsByName("applType")[0].onchange = function() {changeOption(this.value);}
  document.getElementsByName("reqDtCov")[0].onchange = function() {formatDate(this);if(!validateDate(this))return false;reqDtChange(this);}
  //IFOX-00432097 - Date Validation Ally Align Issue - start
  document.getElementsByName("applDate")[0].onchange = function() {formatDate(this);if(!validateDate(this))return false;}
    //IFOX-00432097 - Date Validation Ally Align Issue - end
  document.getElementsByName("mbrHicNbr")[0].onchange = function() {onChangeEvent(this);checkMember();}
  document.getElementsByName("mbrLastName")[0].onchange = function() {onChangeEvent(this);checkMember();}
  document.getElementsByName("mbrBirthDt")[0].onchange = function() {formatDate(this);if(!validateDate(this))return false;onChangeEvent(this);checkMember();}
  /*BasePlus Change start */
  document.getElementsByName("perState")[0].onchange = function() {onChangeEvent(this);setZipCounty();}
  document.getElementsByName("perCounty")[0].onchange = function() {onChangeEvent(this);setZipCountyChange('perState');}
  document.getElementsByName("perZip5")[0].onchange = function() {onChangeEvent(this);setCounty('perCounty','');setState('perCity','perState','perZip5','perZip4');}
  document.getElementsByName("perZip4")[0].onchange = function() {onChangeEvent(this);setCounty('perCounty','');setState('perCity','perState','perZip5','perZip4');}
   /*BasePlus Change end */ 
  
  document.getElementsByName("mailZip5")[0].onchange = function() {onChangeEvent(this);autoPopulateAddress('mailCity','mailState','mailZip5','mailZip4',null,null);}
  document.getElementsByName("mailZip4")[0].onchange = function() {onChangeEvent(this);autoPopulateAddress('mailCity','mailState','mailZip5','mailZip4',null,null);}
  /*
  document.getElementsByName("mailZip5")[0].onchange = function() {onChangeEvent(this);setCity('mailCity','mailState','mailZip5','mailZip4');}
  document.getElementsByName("mailZip4")[0].onchange = function() {onChangeEvent(this);setCity('mailCity','mailState','mailZip5','mailZip4');}*/
  
  // IFOX-00396485 - Start
  
  document.getElementsByName("mailCountry")[0].onchange = function() {onChangeEvent(this);validateMailingAddress();}
  //IFOX-425951 : Email Validation - Start
  document.getElementsByName("mbrEmail")[0].onchange = function() {onChangeEvent(this);checkEmail(this);}
  //IFOX-425951 : Email Validation - End
  //IFOX-00396485 - End
  
  //Customer Id-HCF0289
  document.getElementsByName("authRepZip5")[0].onchange = function() {onChangeEvent(this);autoPopulateAddress('authRepCity','authRepState','authRepZip5','authRepZip4',null,null);}
  document.getElementsByName("authRepZip4")[0].onchange = function() {onChangeEvent(this);autoPopulateAddress('authRepCity','authRepState','authRepZip5','authRepZip4',null,null);}
  
  document.getElementsByName("enrollGroupName")[0].onchange = function() {onChangeEvent(this);getProduct();}
  document.getElementsByName("enrollProdName")[0].onchange = function() {onChangeEvent(this);getProduct();}
  document.getElementsByName("enrollPlan")[0].onchange = function() {onChangeEvent(this);modifyProduct();}
  document.getElementsByName("enrollPbp")[0].onchange = function() {onChangeEvent(this);modifyProduct();}
  document.getElementsByName("enrollSegment")[0].onchange = function() {onChangeEvent(this);modifyProduct();}
  document.getElementsByName("signDt")[0].onchange = function() {formatDate(this);if(!validateDate(this))return false;onChangeEvent(this);setAgencies();setAgents();}
  document.getElementsByName("commAgencyId")[0].onchange = function() {onChangeEvent(this);setAgents();}
  document.getElementsByName("brokerType")[0].onchange = function() {onChangeEvent(this);setBrokerAgents();}
  //Triple S BasePlus Migration/draft day changes on Billing START
  if(document.getElementsByName("achNameOnAct")[0] != undefined){
	  document.getElementsByName("achNameOnAct")[0].onchange = function() {onChangeEvent(this);updtDraftDay(this);}
	  document.getElementsByName("achBankName")[0].onchange = function() {onChangeEvent(this);updtDraftDay(this);}
	  document.getElementsByName("achbankAcctNbr")[0].onchange = function() {onChangeEvent(this);updtDraftDay(this);}
	  document.getElementsByName("achAbaRoutingNbr")[0].onchange = function() {onChangeEvent(this);updtDraftDay(this);}
  }
  //Triple S BasePlus Migration/draft day changes on Billing END  
  /**
   * Cambia_PRE_SET Notes-Start
   */
  document.getElementsByName("preSet")[0].onchange = function() {checkDropdownEvent(this) ;setPreSetNote();}
  /**
   * Cambia_PRE_SET Notes-End
   */
  /**
   *Cambia_OEVprocess-Start
   */
  if(document.getElementById('oevInfo.status')!=null){
  document.getElementsByName("oevInfo.status")[0].onchange = function() { oevCallSubReasonChange(this);}
  document.getElementsByName("oevInfo.subsetReason")[0].onchange = function() {testOev(this); }
  document.getElementsByName("oevRetInfo.status")[0].onchange = function() {returnCallSubReasonChange(this);testRet(this); }
  document.getElementsByName("oevRetInfo.subsetReason")[0].onchange = function(){testRet(this);}
   }
  /**
   *Cambia_OEVprocess-End
   */
  document.getElementsByName("electionType")[0].onchange = function() {onChangeEvent(this);setElectionDt(this);setElcDerivedInd();}  
  setElectionDt(document.getElementsByName("electionType")[0]);
  /**AAH BasePlus Migration IFOX-00426351 START*/
  if (dwr.util.getValue("applType") == 'NMA' || dwr.util.getValue("applType") == 'NPD'|| 
		  (dwr.util.getValue("applType") == 'CMA' && dwr.util.getValue("enbCMAQuesParmCd") == 'Y')) {
  	document.getElementsByName("nameInstitute")[0].onchange = function() {onChangeEvent(this);setInstDetails();}
  }
  /**AAH BasePlus Migration IFOX-00426351 END*/
  if (dwr.util.getValue("applType") == 'NMA' || dwr.util.getValue("applType") == 'CMA') {
  	document.getElementsByName("pcpName")[0].onchange = function() {onChangeEvent(this);getPcpName();}
  }
  if (dwr.util.getValue("mbrSsn") != "") {
  	dwr.util.setValue("mbrSsn", formatSSN(dwr.util.getValue("mbrSsn")));
  }
//IFOX - 431608 : CMS Changes 2020 -start
  document.getElementById('denialReason').onchange = function(){ setDenial(this)};
  document.getElementById('denialReasonNew').onchange = function(){ setDenial(this)};
//IFOX - 431608 : CMS Changes 2020 -end
}
/**
* LEP-ApplicationEntrySide-Iteration1_LeftOverScope - Start
*/

/**
* This method will get ApplicationId/CustomerId and HIC_NUM of the user
* and pass these values for fetching LEP Information wrt to Application side.  
 * upon clicking the button LEP Details in Application Entry Screen
*/


/**
 * This method will invoke EEMAction-> appLEPUpdate method whenever user clicks any Update in the LEP Details PopUp window
 */
function appLEPUpdateClick(){
	//alert("Entered appLEPUpdateClick ");
	document.body.className = 'wait';
	document.eemApplForm.action = "/eemAction.do?method=appLEPUpdate";
  	document.eemApplForm.submit();
}

//new LEP changes -- start
function lepAppPtnlUnCovMnthsUpdate(){
	document.body.className = 'wait';
	document.eemApplForm.action = "/eemAction.do?method=appLepUnCovPtnlMnthUpdate";
  	document.eemApplForm.submit();
}
function appLEPPotentialDeleteClick() {
    document.body.className = 'wait';
    document.eemApplForm.action = "/eemAction.do?method=appLepUnCovPtnlMnthDelete";
    document.eemApplForm.submit();
    }
function appLepAttnInfoClick(){
	document.body.className = 'wait';
	document.eemApplForm.action = "/eemAction.do?method=appLepAttnInfos";
  	document.eemApplForm.submit();
}
function appLEPCcfDeleteClick(){
	document.body.className = 'wait';
	document.eemApplForm.action = "/eemAction.do?method=appLepAttnInfoDelete";
  	document.eemApplForm.submit();
}


function appLepShowAllClick(){
	document.body.className = 'wait';
	document.eemApplForm.action = "/eemAction.do?method=appLEPShowAll";
  	document.eemApplForm.submit();
}

//new LEP changes -- end


function validateProduct(){
	if (dwr.util.getValue("perZip5") == '') {
		alert("Please enter Zip5");
		document.getElementsByName('perZip5')[0].focus();
		return false;
	}else{
		
		setData();
		return true;
	}
}

/**
 * 024_LEP-ApplicationEntrySide-Iteration1_LeftOverScope - End 1
 */
function reqDtChange(ele) {
	
	onChangeEvent(ele);
	setLookUps();
	checkMember();
	//IFOX - 431608 : CMS Changes 2020 - start
	setDenialReasonList();
	//IFOX - 431608 : CMS Changes 2020 - end
}
///IFOX - 431608 : CMS Changes 2020 - start
function setDenial(ele){

	dwr.util.setValue('denialReasonCd', ele.value);

}

function setDenialReasonList(){
	if (!validateDate(document.getElementsByName('reqDtCov')[0])) {
		return false;
	}
		
	var  reqDtCov = dwr.util.getValue("reqDtCov");
	var usrReqDt = new Date(reqDtCov);
	var checkDate = "01/01/2021";
	var checkDate2 = new Date(checkDate);
	if(reqDtCov != ''){
		if(usrReqDt >= checkDate2){
			document.getElementById('denialReasonWithESRD').style.display = 'none';
			document.getElementById('denialReasonWithoutESRD').style.display = '';
		}else{
			document.getElementById('denialReasonWithESRD').style.display = '';
			document.getElementById('denialReasonWithoutESRD').style.display = 'none';
		}
	}
	
}
//IFOX - 431608 : CMS Changes 2020 - end
function onChangeEvent(ele) {
  if (ele.name != 'reqDtCov' && ele.name != 'mbrPrefix' &&
  	  ele.name != 'mbrFirstName' && ele.name != 'mbrMiddleName' &&
  	  ele.name != 'mbrLastName' && ele.name != 'mbrBirthDt' &&
  	  ele.name != 'mbrHicNbr' && ele.name != 'mbrSuffix' && 
  	  ele.name.indexOf('search') == -1 &&
  	  ele.name != 'applDate' && ele.name != 'applStatus') {

	  reqDt = dwr.util.getValue('reqDtCov');
	  lastName = dwr.util.getValue('mbrLastName');
	  birthDt = dwr.util.getValue('mbrBirthDt');
	  hicNbr = dwr.util.getValue('mbrHicNbr');
	  
	  if (reqDt == '' && elemExists(document.getElementsByName('reqDtCov')) ) {		  
	  	alert('Please enter Requested Date of Cov');
	  	document.getElementsByName("reqDtCov")[0].focus();
	  	ele.value = '';
	  	return;
	  }    
	  if (lastName == '' && elemExists(document.getElementsByName('mbrLastName')) && 
			  birthDt == '' && elemExists(document.getElementsByName('mbrBirthDt'))) {
	  	alert('Please enter either Last Name or Birth Date');
	  	document.getElementsByName("mbrLastName")[0].focus();
	  	ele.value = '';
	  	return;
	  }    
	  if (hicNbr == '' && elemExists(document.getElementsByName('mbrHicNbr')) ) {
	  	alert('Please enter Medicare ID');
	  	document.getElementsByName("mbrHicNbr")[0].focus();
	  	ele.value = '';
	  	return;
	  }
  }
  ele.value = ele.value.toUpperCase();
  // Set it as changed
  if (ele.name.indexOf('search') == -1) {
  	dwr.util.setValue('isChanged','Y');
  }
}
function elemExists(element) {
 	if(typeof(element) == 'undefined' || element == null)
	{
			  return false;
	}else{
		 return true;
	}
}
//IFOX-00396485 - Start
function validateMailingAddress(){
	//alert(" validateMailingAddress ::::::::: ");
	var inValid = true;
	if(dwr.util.getValue("mailAdd1") == '' && dwr.util.getValue("mailState") == '' 
		&& dwr.util.getValue("mailCity") == '' && dwr.util.getValue("mailZip4") == ''
		&& dwr.util.getValue("mailAdd2") == '' && dwr.util.getValue("mailCountry") == ''){
		return true;
	}
	var  country= dwr.util.getValue("mailCountry");
	if(dwr.util.getValue("mailAdd1") == '') {
		 alert("Please enter mailing Address1");
		document.getElementsByName('mailAdd1')[0].focus();	
		return false;
	}
	if(country == 'USA' || country == '') {
		if(dwr.util.getValue("mailCity") == '') {
			 alert("Please enter mailing City");
			document.getElementsByName('mailCity')[0].focus();
			return false;
			}		
		if(dwr.util.getValue("mailState") == '') {
			 alert("Please enter mailing State");
			document.getElementsByName('mailState')[0].focus();
			return false;
			}
		if(dwr.util.getValue("mailZip5") == '') {
			 alert("Please enter mailing ZipCode");
			document.getElementsByName('mailZip5')[0].focus();
			return false;
			}
		if(dwr.util.getValue("mailState") == '' || dwr.util.getValue("mailCity") == '' || dwr.util.getValue("mailZip5") == '') {
			 alert("Please enter City/State/Zip details");
			document.getElementsByName('mailZip5')[0].focus();
			return false;
		}		
	}else { if(country != 'USA' ){
		if(dwr.util.getValue("mailAdd2") == '') {
		 alert("Please enter mailing Address2");
		document.getElementsByName('mailAdd2')[0].focus();
		return false;
		}
		if(dwr.util.getValue("mailState") != '' || dwr.util.getValue("mailCity") != '' || dwr.util.getValue("mailZip5") != '') {
			 alert("City/State/Zip is only valid for USA");
			document.getElementsByName('mailCountry')[0].focus();
			return false;
		}
	}
	}
	return inValid;
}

//IFOX-00396485 - End

function applNewMbrMA() {
  /*document.getElementById('loading').style.display = 'none';*/
  dwr.util.setValue("applType", "NMA");
  if(dwr.util.getValue('oevTimerCheck') && dwr.util.getValue('oevTimerCheck')=="TRUE")
	  setSubsetReason();
  createErrorList();
  setOnchangeEvent();
  displayException();
  /**AAH BasePlus Migration IFOX-00426351 START*/ 
  manageLTCAddlnQuestions();
  /**AAH BasePlus Migration IFOX-00426351 END*/
}

function applNewMbrPD() {
  document.getElementById('loading').style.display = 'none';
  dwr.util.setValue("applType", "NPD");
  if(dwr.util.getValue('oevTimerCheck') && dwr.util.getValue('oevTimerCheck')=="TRUE")
	  setSubsetReason();
  createErrorList();
  setOnchangeEvent();
  displayException();
  /**AAH BasePlus Migration IFOX-00426351 START*/ 
  manageLTCAddlnQuestions();
  /**AAH BasePlus Migration IFOX-00426351 END*/
}

function contrChgMA() {
  document.getElementById('loading').style.display = 'none';
  dwr.util.setValue("applType", "CMA");
  if(dwr.util.getValue('oevTimerCheck')=="TRUE")
	  setSubsetReason();
  createErrorList();  
  setOnchangeEvent();
  displayException();
  /*IFOX-00425298 Enable Question Section for CMA Appl. AAH START*/
  if(dwr.util.getValue("enbCMAQuesParmCd") == 'Y')
	  manageLTCAddlnQuestions();
  /*IFOX-00425298 Enable Question Section for CMA Appl. AAH END*/
}

function contrChgPD() {
  document.getElementById('loading').style.display = 'none';
  dwr.util.setValue("applType", "CPD");
  if(dwr.util.getValue('oevTimerCheck')=="TRUE")
	  setSubsetReason();
  createErrorList(); 
  setOnchangeEvent();
  displayException(); 
}
function setSubsetReason()
{ 
	
	if(dwr.util.getValue('oevButton')=="S"){
	//alert("inside if...");
	var ctl = document.getElementById('oevInfo.status');
	//alert("ctl..."+ctl);
	
     var status = ctl.options[ctl.options.selectedIndex].value;
 	 var ctl1 = document.getElementById('oevInfo.subsetReason');
 	// alert("ctl1.."+ctl1);
 	 var reason = ctl1.options[ctl1.options.selectedIndex].value;
 		//	alert(reason);
 	 setOevReason(status,ctl1); 
 	 setIdValue('oevInfo.subsetReason', reason);
 	  var ctl = document.getElementById('oevRetInfo.status');
     var status = ctl.options[ctl.options.selectedIndex].value;
 	 var ctl1 = document.getElementById('oevRetInfo.subsetReason');
 	 var reason = ctl1.options[ctl1.options.selectedIndex].value;
 		//	alert(reason);
 	 setReturnOevReason(status,reason); 
 	 setIdValue('oevRetInfo.subsetReason', reason);
	}
		//alert(reason);
}
function formSubmit() {
  alert('in submit');	
}
function displayException() {
	if (dwr.util.getValue('message') != '') {
		alert(dwr.util.getValue('message'));
	}
}
function populateOptions(source, option1) {
	try {
		FacadeManager.getSelectOptions(source, option1,{
		  			callback:function(data) {
		  				dwr.util.removeAllOptions(source);
		  				dwr.util.addOptions(source, [""]);
		  				dwr.util.addOptions(source, data, 'name', 'value');
					}
		  			});
	} catch(e) {
		document.body.style.cursor = 'default';
		alert("Error: "+e.message);
	}
}
function setZipCounty() {
	dwr.util.setValue('perZip5', '');
	dwr.util.setValue('perZip4', '');
	dwr.util.setValue('perCounty', '');
}
function setState(sourceCity, sourceState, sourceZip5, sourceZip4) {
	try {
		var zip5 = dwr.util.getValue(sourceZip5);
		var zip4 = dwr.util.getValue(sourceZip4);
		//alert("in setState");
		if (zip5 == "") {
			return;
		}
		FacadeManager.getCityName(zip5,zip4,{
		  			callback:function(data) {
		  				 var selbox=document.getElementById(sourceState);

		  				 if (data != null && data.length > 0) {
		  		              //selbox.options.length = data.length;
		  					var arr = data[0].split("|");
		  					var stateCode=arr[1];
		  					dwr.util.setValue(sourceState, arr[1]);
	  		            	$(selbox).select2();
	  		            	//alert('setting State');
	  		            	//trigger the 
	  		            	onChangeEvent(selbox);
		  				 }else{
			  		    	resetCityStCounty();
			  		     }
		  		       
					}});
	} catch(e) {
		document.body.style.cursor = 'default';
		alert("Error: "+e.message);
	}
}
/*function setCity(sourceCity, sourceState, sourceZip5, sourceZip4) {
	try {
		var zip5 = dwr.util.getValue(sourceZip5);
		var zip4 = dwr.util.getValue(sourceZip4);
		//alert("in setCity");
		if (zip5 == "") {
			return;
		}
		FacadeManager.getCityName(zip5,zip4,{
		  			callback:function(data) {
		  				checkCity(sourceCity, sourceState, sourceZip5, sourceZip4, data);
					}});
	} catch(e) {
		document.body.style.cursor = 'default';
		alert("Error: "+e.message);
	}
}*/



function checkCity(sourceCity, sourceState, sourceZip5, sourceZip4, data) {
	if (data == null || data.length > 1) {
		openCitySearch(sourceCity, sourceState, sourceZip5, sourceZip4);
		return;
	}
	if (data.length == 1) {
		var arr = data[0].split("|");
		//var city = dwr.util.getValue(sourceCity);
		//if (city != '' && city != arr[0]) {
			//openCitySearch(sourceCity, sourceState, sourceZip5, sourceZip4);
		//	return;
		//} 
		
		//dwr.util.setValue(sourceCity, arr[0]);
		dwr.util.setValue(sourceState, arr[1]);
		dwr.util.setValue(sourceZip5, arr[2]);
		dwr.util.setValue(sourceZip4, '');
		//dwr.util.setValue(sourceZip4, arr[2]);
		return;
	}
}
var eemZipWin = null;
function openCitySearch(sourceCity, sourceState, sourceZip5, sourceZip4,sourceCounty) {
	//alert("in opencitysearch::::"+sourceCounty);
	//alert(sourceState)
	url = "/eemAction.do?method=cityZipSearch";
	url = url + "&zip5="+dwr.util.getValue(sourceZip5)+"&zip4="+dwr.util.getValue(sourceZip4)+
		"&sourceCity="+sourceCity+"&sourceState="+sourceState+"&sourceZip5="+sourceZip5+"&sourceZip4="+sourceZip4+"&sourceCounty="+sourceCounty;
	//alert(url);
	
	var ww = 900;
	var wh = 550;
	var wt = 1;
	var wl = ((screen.width - 10) - ww) / 2;
	
	eemZipWin = window.open(url,"CityZipSearch","toolbar=no,titlebar=0,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,ControlBox=no,width=" + ww + ",height=" + wh + ",left=" + wl + ",top=" + wt);
	eemZipWin.focus();
}

//For Defect#93,42-Hometown
function autoPopulateAddress(sourceCity, sourceState, sourceZip5, sourceZip4, sourceCounty, countryCd, sourceCountyCd) {
	//alert("in autoPopulateAddress  sourceZip5:"+sourceZip5+" ,sourceZip4:"+sourceZip4);

	var zip5 = dwr.util.getValue(sourceZip5);
	var zip4 = dwr.util.getValue(sourceZip4);
	FacadeManager.getMailingAddress(zip5,zip4,{
			callback:function(data) {
			//console.log("List City");
			//console.log(data);
			 if (data != null && data.length > 0) {
				 var firstRowData=data[0];
				 var city=firstRowData.perCity ;
				 var state=firstRowData.perState ;
				 var zip4=firstRowData.perZip4 ;
				 var zip5=firstRowData.perZip5 ;
				 var county=firstRowData.perCounty;
				 var countyCd = firstRowData.countyCd;
				 
				 dwr.util.setValue(sourceCity, city);
				 dwr.util.setValue(sourceState, state);
				 var stateDropdown=document.getElementById(sourceState);
				 $(stateDropdown).select2();
				 dwr.util.setValue(sourceCounty, county);				 
				 dwr.util.setValue(sourceCountyCd, countyCd);
				 
			 }else{
				 dwr.util.setValue(sourceCity, "");
				 dwr.util.setValue(sourceState, "");
				 dwr.util.setValue(sourceCounty, "");
				 dwr.util.setValue(sourceCountyCd, "");
				 var stateDropdown=document.getElementById(sourceState);
				 //$(stateDropdown).select2();
				 
			 }
			
			 dwr.util.setValue(countryCd,'USA');
			 //IFOX-00399064 START
			 var countryDropdown=document.getElementById(countryCd);
			 $(countryDropdown).select2();
			//IFOX-00399064 END
			 var addressTypeDropdown=document.getElementsByName("displayAddress.addressType")[0];
			 $(addressTypeDropdown).select2();

	       }

	});
}
function searchCity() {
	if (dwr.util.getValue("searchZip5") == '') {
		alert("Please enter Zip5");
		document.getElementsByName('searchZip5')[0].focus();
		return;
	}
	document.eemApplForm.method.value = 'cityZipSearch';
	//alert("Action b4:"+document.eemApplForm.action);
	document.eemApplForm.action=document.eemApplForm.action +"?zip5="+dwr.util.getValue("searchZip5")+
	"&zip4="+dwr.util.getValue("searchZip4")+
	"&sourceCity="+dwr.util.getValue("sourceCity")+"&sourceState="+dwr.util.getValue("sourceState")+
	"&sourceZip5="+dwr.util.getValue("sourceZip5")+"&sourceZip4="+dwr.util.getValue("sourceZip4")+"&sourceCounty="+dwr.util.getValue("sourceCounty");
	//alert("Action A4:"+document.eemApplForm.action);
  	document.eemApplForm.submit();
}
function resetCitySearch() {
	ele = document.getElementsByTagName("input");
	for(i = 0; i < ele.length; i++) {
		if (ele[i].name.indexOf('search') != -1) {
			ele[i].value = '';
		}
	}
}
function cancelCitySearch() {
	window.close();
}
function setCityHidden(city, state, zip5, zip4,county,cntyCd) { //IFOX-00397384
	dwr.util.setValue('hidCity',city);
	dwr.util.setValue('hidState',state);
	dwr.util.setValue('hidZip5',zip5);
	dwr.util.setValue('hidZip4',zip4);
	dwr.util.setValue('hidCounty',county);
	dwr.util.setValue('hidCountyCd',cntyCd); //IFOX-00397384
}
function populateCityValues() {
    city = dwr.util.getValue('hidCity');
	state = dwr.util.getValue('hidState');
	zip5 = dwr.util.getValue('hidZip5');
	zip4 = dwr.util.getValue('hidZip4');
	county=dwr.util.getValue('hidCounty');
	countyCd = dwr.util.getValue('hidCountyCd'); //IFOX-00397384
	
	sourceCity = dwr.util.getValue('sourceCity');
	sourceState = dwr.util.getValue('sourceState');
	sourceZip5 = dwr.util.getValue('sourceZip5');
	sourceZip4 = dwr.util.getValue('sourceZip4');
	sourceCounty=dwr.util.getValue('sourceCounty');
	
   	window.opener.setCityValues(sourceCity, sourceState, sourceZip5, sourceZip4, city, state, zip5, zip4,sourceCounty,county,countyCd); //IFOX-00397384
     var isPerCity = (sourceCity == 'perCity' || sourceCity == 'PERCITY');
   	if (isPerCity) {
   	//IFOX - 420387 -Multiple County Selection Issue : start
     	/*window.opener.setCounty('perCounty');
		window.opener.setZipCountyState(city, zip5, zip4, county);
	    */
     	window.opener.setCounty(county, city);
	    window.opener.setZipCountyChange(city);
	    //IFOX - 420387 -Multiple County Selection Issue : end
	}
   	
	window.close();
}
function setCityValues(sourceCity, sourceState, sourceZip5, sourceZip4, city, state, zip5, zip4,sourceCounty,county,countyCd) { //IFOX-00397384
	dwr.util.setValue(sourceCity,city);
	dwr.util.setValue(sourceState,state);
   	dwr.util.setValue(sourceZip5,zip5);
   	dwr.util.setValue(sourceZip4,zip4);
   	dwr.util.setValue(sourceCounty,county);
   	selbox=document.getElementById(sourceState);
   	if(selbox!=undefined){
   		$(selbox).select2();	
   	}
  	
	if (sourceCity == 'displayAddress.city' || sourceCity == 'DISPLAYADDRESS.CITY') { //address
		onChangeTabDataUpperCase(document.getElementsByName(sourceCity)[0],'address');	
		dwr.util.setValue('displayAddress.countyCd',countyCd); //IFOX-00397384
	} else {
		onChangeEvent(document.getElementsByName(sourceCity)[0]);
	}

}
/*function setCounty(source) {
	try {
		 if (!isOutOfArea()) {
			dwr.util.setValue('enrollProdName','');
			dwr.util.setValue('enrollProd','');
		} 
		var zip5 = dwr.util.getValue('perZip5');
		var zip4 = dwr.util.getValue('perZip4');
		if (zip5 == "") {
			return;
		}
		FacadeManager.getCounty(zip5,zip4,{
		  			callback:function(data) {
	  				    dwr.util.setValue(source, data);
					}});
	} catch(e) {
		document.body.style.cursor = 'default';
		alert("Error: "+e.message);
	}
}*/
/* IFOX-00397816 : Add comments button */
function updateComments() {
	try {
		//alert("in updateComments");
		var appId = dwr.util.getValue('applId');
		var currStatus = dwr.util.getValue('applStatus');
		var customerId = dwr.util.getValue('customerId');
		
		var commentRowList=document.getElementsByName("commentRows");
		var insertRowList=document.getElementsByName("insertRows");
		var commentListStr = '';
		
		//alert("commentRowList size:"+commentRowList.length);
		//alert("insertRowList size:"+ insertRowList.length);
		
		if((commentRowList!=undefined && commentRowList.length>0) && (insertRowList!=undefined && insertRowList.length>0)){
			commentListStr = getCommentListStr(commentRowList,insertRowList);
		}		

		//alert("appId:"+appId+"|customerId:"+customerId+"|commentListStr:"+commentListStr);
		
		if((appId == '')||(appId == undefined) ){
			alert('APPLICATION ID IS REQUIRED TO SAVE COMMENT');
			return false;
		}
		if (commentListStr == '' ||(commentListStr== undefined)){
			alert('NO COMMENTS ELIGIBLE FOR SAVING');
			return false;
		}else{

			FacadeManager.updateComments(customerId,appId,commentListStr,{
			  			callback:function(data) {		  				
		  				 if (data!=null && data != undefined && data != '' && data.length > 0) {		  					 
		  					 if(data.indexOf('SUCCESS') != -1 ){			// on SUCCESS
		  						updateInsertRowValue(insertRowList);
		  						alert("Comments Updated successfully!!");
		  					 }else if(data.indexOf('ERROR') != -1 ){		// on ERROR
		  						alert(data); 
		  					 }
		  				 }		  				

			  	}});		
		}		

	} catch(e) {
		document.body.style.cursor = 'default';
		alert("Error: "+e.message);
	}
}

/* IFOX-00397816 : Add comments button */
function getCommentListStr(commentRowList,insertRowList){
	var commentListStr='';
	
	for(i = 0; i < commentRowList.length; i++) {
		if('Y' == insertRowList[i].value){
			commentListStr = commentListStr+commentRowList[i].value +'|' + insertRowList[i].value+'~';	
		}
	}
	//Remove the last tilda
	if(commentListStr.length>0){
		commentListStr=commentListStr.substring(1, commentListStr.length-1);
	}

	
	//alert("getCommentListStr:"+commentListStr);
	return 	commentListStr;
}

/* IFOX-00397816 : Add comments button */
function updateInsertRowValue(insertRowList){

	//alert("In updateInsertRowValue insertRowList size:"+ insertRowList.length);
	for(i = 0; i < insertRowList.length; i++) {
		insertRowList[i].value='N';	    
	}
}
//BasePlus County Changes - Start 1
//IFOX - 420387 -Multiple County Selection Issue : start
function setCounty(ele, city) {
//IFOX - 420387 -Multiple County Selection Issue : end
	try {
		//alert("in setCounty");
		var zip5 = dwr.util.getValue('perZip5');
	/*	document.getElementById('perZip4').value = '';*/ //IFOX- 00425614 commented as Zip4 is getting blank
		var zip4 = dwr.util.getValue('perZip4');
		
		if (zip5 == "") {
			return;
		}
		FacadeManager.getCounty(zip5,zip4,{
		  			callback:function(data) {
	  				 var selbox=document.getElementById('perCounty');
	  				 var selbox1=document.getElementById('perCity');
	  				selbox.options.length = 0;
	  				selbox1.options.length = 0;
	  				
	  				//selbox1.innerHTML = "";
	  				// selbox.innerHTML = "";
	  				// if(data.length == 1){
		  				/// for (var i = 0; i < data.length; i++) {
	  		           // 	 
			             //        selbox.options[i] = new Option(data[i].name, data[i].value);
			            //  }
		  				// }
	  				 if (data != null && data.length > 0) {
	  		              selbox.options.length = data.length;
	  		              var selectedCounty = 1;//IFOX-00429799 IE County Fix	
	  		              for (var i = 0; i < data.length; i++) {
	  		            	  //alert(data[i].name);
	  		            	// alert(data[i].value);
	  		            	 //alert("ele"+ele);
		  		              selbox.options[i+1] = new Option(data[i].name, data[i].value);
		  		              //IFOX - 420387 -Multiple County Selection Issue : start
		  		              if(ele !=null && ele !='' && ele != undefined ){
			  		              if(data[i].name === ele){
			  		            	  selectedCounty = i+1;//IFOX-00429799 IE County Fix
			  		            	  /*selbox[i+1].selected = true;
			  		              	 // $(selbox).select2();*/
		  		            	      //onChangeEvent(selbox);
		  		            	      //setZipCountyChange('perState');
			  		              } /*else {
			  		            	selbox[1].setAttribute("selected", "selected");
			  		            	$(selbox).select2();
			  		              }*/
		  		              }
	  		              }
	  		              /**IFOX-00429799 IE County Fix: START*/
	  		              selbox[selectedCounty].selected = true;
 		              	  $(selbox).select2();
 		              	 /**IFOX-00429799 IE County Fix: END*/
	  		            	  
	  		              /*if(selbox[1]){
	  		            	//selbox[1].selected = true;
	  		            	
	  		            	
	  		            	//alert('setting setCounty');
	  		            	//trigger the 
*/	  		            	onChangeEvent(selbox);
							if( city=='')
							setZipCountyChange(city);
	  		              //}
	  		       }else{
	  		    	 resetCityStCounty();
	  		       }
	  			//IFOX - 420387 -Multiple County Selection Issue : end	

					}});
	} catch(e) {
		document.body.style.cursor = 'default';
		alert("Error: "+e.message);
	}
}
function resetCityStCounty(){
	dwr.util.setValue('perCity', '');
	var selbox=document.getElementById('perCity');
	$(selbox).select2();
	
	dwr.util.setValue('perState', '');
	var selbox=document.getElementById('perState');
	$(selbox).select2();
	
	//dwr.util.setValue('perZip5', '');
	//dwr.util.setValue('perZip4', '');
	
	dwr.util.setValue('perCounty', '');
	selbox=document.getElementById('perCounty');
	 $(selbox).select2();
	
}
function setCountymbr(countyName,zip5,zip4) {
	try {

		//var zip5 = dwr.util.getValue('displayAddress.zipCd5');
		//var zip4 = dwr.util.getValue('displayAddress.zipCd4');
		
		FacadeManager.getCounty(zip5,zip4,{
		  			callback:function(data) {
	  				  //alert("test data"+data.length);
	  				 var selbox=document.getElementById('displayAddress.countyCd');
	  				 
	  				selbox.options.length = 0;
	  				 if (data != null && data.length > 0) {
	  		              selbox.options.length = data.length;
	  		           
	  		              for (var i = 0; i < data.length; i++) {
	  		            	 // alert(data[i].name);
	  		            	// alert(data[i].value);
	  		              selbox.options[i+1] = new Option(data[i].name, data[i].value);
	  		            
	  		              }
	  		           
	  		            dwr.util.setValue(selbox,countyName);
	  		       
	  		       }
	  				

					}});
	} catch(e) {
		document.body.style.cursor = 'default';
		alert("Error: "+e.message);
	}
}

function setCountyCode(countyName,zip5,zip4) {
	
	try {
		
		//var zip5 = dwr.util.getValue('searchZip5');
		//var zip4 = dwr.util.getValue('perZip4');
		if (zip5 == "") {
			return;
		}
		//var zip = dwr.util.getValue('displayAddress.zipCd5');
		FacadeManager.getCounty(zip5,zip4,{
		  			callback:function(data) {
	  				 var selbox=document.getElementById('perCounty');
	  				 
	  				selbox.options.length = 0;
	  			
	  				 if (data != null && data.length > 0) {
	  		              selbox.options.length = data.length;
	  		              for (var i = 0; i < data.length; i++) {
	  		            	 // alert(data[i].name);
	  		            	// alert(data[i].value);
	  		              selbox.options[i+1] = new Option(data[i].name, data[i].value);
	  		              }
	  		           
	  		            dwr.util.setValue(selbox,countyName);
	  		       }
	  				

					}});
	} catch(e) {
		document.body.style.cursor = 'default';
		alert("Error: "+e.message);
	}
	
}
//IFOX - 420387 -Multiple County Selection Issue : start
function setZipCountyChange(ele) {
//IFOX - 420387 -Multiple County Selection Issue : end
	setTimeout(function(){
	try {
//alert("ok");
		var zip5 = dwr.util.getValue('perZip5');
		var zip4 = dwr.util.getValue('perZip4');
		var county = dwr.util.getValue('perCounty');
		//alert("in setZipCountyChange zip5:"+zip5+"|zip4:"+zip4+"|county:"+county+"|city:"+ele);
		if (zip5 == "") {
			return;
		}
	
		FacadeManager.getCities(zip5,zip4,county,{
		  			callback:function(data) {
	  				 var selbox=document.getElementById('perCity');
	  				 selbox.innerHTML = "";
	  				 if(data.length == 1){
		  				 for (var i = 0; i < data.length; i++) {
       	 	                    selbox.options[i] = new Option(data[i].name, data[i].value);
			                     selbox[i].selected = true;
			  		            	$(selbox).select2();
			  		            	//alert("setting setZipCountyChange for city");
			              }
		  				 }
	  				 if (data != null && data.length > 1) {
	  		              selbox.options.length = data.length+1;
	  		              for (var i = 0; i < data.length; i++) {
	  		           //IFOX - 420387 -Multiple County Selection Issue : start
	  		            	 selbox.options[i+1] = new Option(data[i].name, data[i].value);
	  		            	 if(ele != null && ele != '' && ele != undefined){
	  		            		 if(data[i].name == ele){
	  		            			 selbox[i+1].selected = true;
	  		  		            	$(selbox).select2();
	  		  		              onChangeEvent(selbox);
	  		            		 }
	  		            		 
	  		            	 }	  		              
	  		              }
	  		            
	  		            if(ele != null && ele == '' && ele != undefined){
	  		            	selbox[1].selected = true;
		  		            $(selbox).select2();
		  		            onChangeEvent(selbox);
	  		            }
	  		            /*  
	  		            if(selbox[1]){
	  		            	selbox[1].selected = true;
	  		            	$(selbox).select2();
	  		            	//alert("setting setZipCountyChange");
	  		              }*/
	  		      //IFOX - 420387 -Multiple County Selection Issue : end      
	  		       }
	  					

					}});
	} catch(e) {
		document.body.style.cursor = 'default';
		alert("Error: "+e.message);
	}
	}, 300);
}
function setZipCountyState(cityName,zip5,zip4,county) {
	try {
		//alert("setting city:::"+cityName+zip5+county);
		//var zip5 = dwr.util.getValue('perZip5');
		//var zip4 = dwr.util.getValue('perZip4');
		//var county = dwr.util.getValue('perCounty');
		if (zip5 == "") {
			return;
		}
		FacadeManager.getCity(zip5,zip4,{
		  			callback:function(data) {
	  				  //alert(data[0].name);
	  				 // alert(data[0].value);
		  				
	  				 var selbox=document.getElementById('perCity');
	  				
	  				 //alert("setZipCountyState:"+ data.length);
	  				 if(data.length == 1){
		  				 for (var i = 0; i < data.length; i++) {
		  					//IFOX - 420387 -Multiple County Selection Issue : start
		  					selbox.options.length = 1;
		  					selbox.options[0] = new Option("", "");
		  					//IFOX - 420387 -Multiple County Selection Issue : end
			                     selbox.options[i] = new Option(data[i].name, data[i].value);
			                     selbox[i].selected = true;
			                     $(selbox).select2();
			              }
		  				 }
	  				 if (data != null && data.length > 1) {
	  				 //IFOX - 420387 -Multiple County Selection Issue : start
	  					selbox.options.length = 1;
	  					selbox.options[0] = new Option("", "");
	  					//IFOX - 420387 -Multiple County Selection Issue : end
	  		              selbox.options.length = data.length+1;
	  		              for (var i = 0; i < data.length; i++) {
	  		            	 // alert(data[i].name);
	  		            	 //alert(data[i].value);
	  		              selbox.options[i+1] = new Option(data[i].name, data[i].value);
	  		              
	  		              }
	  		             // alert(selbox.options.length);
	  		            //dwr.util.setValue(selbox,cityName);
	  		            //IFOX - 420387 -Multiple County Selection Issue : start
	  		            //selbox[1].selected = true;
		            	//IFOX - 420387 -Multiple County Selection Issue : end
		            	$(selbox).select2();
	  		            //alert("test:::::"+selbox.options[i].selected);
	  		       }
	  					

					}});
	} catch(e) {
		document.body.style.cursor = 'default';
		alert("Error: "+e.message);
	}
}

function setZipCountyMbr(city,zip5,zip4) {
	setTimeout(function(){
	 
	try {
   
		if (zip5 == "") {
			return;
		}
		
		FacadeManager.getCity(zip5,zip4,{
		  			callback:function(data) {
	  				  //alert(data[0].name);
	  				  //alert(data[0].value);
	  				 var selbox=document.getElementById('displayAddress.city');
	  				 if(data.length == 1){
		  				 for (var i = 0; i < data.length; i++) {
	  		            	 
			                     selbox.options[i] = new Option(data[i].name, data[i].value);
			              }
		  				 }
	  				 if (data != null && data.length > 1) {
	  		              selbox.options.length = data.length+1;
	  		              for (var i = 0; i < data.length; i++) {
	  		            	 // alert(data[i].name);
	  		            	 // alert(data[i].value);
	  		              selbox.options[i+1] = new Option(data[i].name, data[i].value);
	  		              
	  		            //alert("test:::::"+selbox.options[i].selected);
	  		              }
	  		            dwr.util.setValue(selbox,city);
	  		       }
	  					

					}});
	} catch(e) {
		document.body.style.cursor = 'default';
		alert("Error: "+e.message);
	}
	   //do what you need here
	}, 500);
}
function setCountyName() {
	//alert("Default County Code:: "+ dwr.util.getValue('countyCd'));
	ele = document.getElementById('perCounty');
	//alert("county name"+ele.options[ele.selectedIndex].innerHTML);
	dwr.util.setValue('countyCd',ele.options[ele.selectedIndex].innerHTML);
}
//BasePlus County Changes - End 1
function clearAll() {
	//switchMenu('Application');
  document.eemApplForm.method.value = 'applCancel';
  document.eemApplForm.submit();	
}
function isOpen(win){
	if (win != null)
        if (win.closed == false)
            return true;
	return false;
}
function closeWindows() {
	if(isOpen(eemProdWin))
		eemProdWin.close();
	if(isOpen(eemEligWin))
		eemEligWin.close();
	if(isOpen(eemPcpWin))
		eemPcpWin.close();
	if(isOpen(eemZipWin))
		eemZipWin.close();
}
function applUpdate() {
  
	//fix for Part A/B/D dates change not saving : start
	var a = document.getElementById('partAPicker');
	var b = document.getElementById('partBPicker');
	var d = document.getElementById('partDPicker');
	if(a != undefined && b != undefined && d != undefined
			&& a!= null && b !=null && d != null ){
		dwr.util.setValue('partAEffDt', a.value);
		dwr.util.setValue('partBEffDt', b.value);
		dwr.util.setValue('partDEffDt', d.value);
	}
		//fix for Part A/B/D dates change not saving : end
	
	var ctl = document.eemApplForm.elig_override;
	if(ctl){		
		if(ctl.checked == true){
			document.forms[0].eligOverrideInd.value ='Y';
		}else{
			document.forms[0].eligOverrideInd.value ='N';
		}
	}
	
  var currStatus = dwr.util.getValue('currStatus');
  if(currStatus == "COMPLETED")
	{
		alert("Application Cannot be UPDATED!! \nCurrent Status is COMPLETED");
		return false;
	}
  if(currStatus == "CANCELED")
	{
		alert("Application Cannot be UPDATED!! \nCurrent Status is CANCELED");
		return false;
	}
  if(currStatus == "DENIEDELG" || currStatus == "DENIEDETYP" || currStatus == "DENIEDOTHR")
	{
		alert("Application Cannot be UPDATED!! \nCurrent Status is DENIED");
		return false;
	}
	// start IFOX-00397383
	 var applCat = document.getElementById('applCategory').value;
	 if(applCat === null || applCat == ''){
		 alert('Please select Application Category');
		 return false;
	 }
	 // end IFOX-00397383
	  // fix for issue # 87 start
	  if(!isAllFldsEmptyOrFilled(['lisEffStartDate','lisEffEndDate','liCoPayCd','lisPctCd'])){
		  alert("Please enter valid LIS details");
		  return false;
	  }
	  //fix for issue # 87 end
	  
	  
	  //IFOX-00431133 -CMS Changes Start
		 if (dwr.util.getValue('emailOptIn') == 'Y') {
			if(dwr.util.getValue('mbrEmail')==''){
			alert('Please enter Email ID.');
			document.getElementsByName("mbrEmail")[0].focus();
			return false;
		  }
		}
	  //IFOX-00431133 -CMS Changes End
	  
	  
	//IFOX-00420167 : Appl Cancel validation : start
	  if(dwr.util.getValue('btnClicked')=='Cancel'){
		 	 	 
		 	 if(dwr.util.getValue('reasonPDP')==''){
		 		 window.scrollTo(0,2300);
		 		 alert("Cancel Reason can't be blank for Cancellation of Application");		 
		 		 document.getElementsByName("reasonPDP")[0].focus();
		 		 return;
		 	 }
		 	 
	  }
	//IFOX-00420167 : Appl Cancel validation : end
  if(dwr.util.getValue('btnClicked')=='denial'){
 	 dwr.util.setValue('applStatus',(document.getElementById("denialStatusList").value));
 	 var applStatus = (dwr.util.getValue('applStatus'));
 	
 	 if(dwr.util.getValue('denialReasonCd')==''){
 		 window.scrollTo(0,2600);
 		 alert("Denial Reason can't be blank for Denial of Application");		 
 		 document.getElementsByName("denialReasonCd")[0].focus();
 		 return;
 	 }
 	 if(dwr.util.getValue('denialDateFrmt')==''){
 		 window.scrollTo(0,2600);
 		 alert("Denial Received Date can't be blank for Denial of Application");		 
 		 document.getElementsByName("denialDateFrmt")[0].focus();
 		 return;
 	 }
 	 if(applStatus!='DENIEDELG'&& applStatus!='DENIEDETYP'&& applStatus!='DENIEDOTHR'){
 		 window.scrollTo(0,100);
 		 //alert(applStatus);
 		 //alert("for Denial of Application Appl. Status should be DENIED");
 		 alert('Please select Application Status');
 		 document.getElementsByName("applStatus")[0].focus();
 		 return;
 	 }
 	 if(isPastDate(dwr.util.getValue('denialDateFrmt'))){
 		 window.scrollTo(0,2600);
 		 alert("Denial Received Date Should not be Past Date");		 
 		 document.getElementsByName("denialDateFrmt")[0].focus();
 		 return;
 	 }
 	 
  }
  
   /**UseCaseName 015_Highmark_SUC_Denials for Enrollment and Disenrollment - End  */
  if (currStatus == 'COMPLETED') {
  	alert("Can't Update when the Status is " + currStatus + ".");
  	return;
  }
  if ((currStatus == 'INCRFIREQ' || currStatus == 'INCRFIGEN' || 
  		currStatus == 'DUPLENRL' || currStatus == 'DUPLAPPL' || 
  		currStatus == 'HOLD' || currStatus == 'ELGCRITICL' ||
  		// added ERROR for IFOX-00400051
  		currStatus == 'ERRORCRITL' || currStatus == 'OPOUTYES' || currStatus == 'ERROR') && 
  		dwr.util.getValue('applStatus') == 'FORCEDAPPR') {
  	alert("Can't Update to FORCEDAPPR when Status is " + currStatus + ".");
  	return;
  }
  if (dwr.util.getValue('applStatus') == 'INCOMPLETE' && 
  		!(currStatus == '' || currStatus == 'READY' || currStatus == 'INCOMPLETE')) {
  	alert("Can't Update to INCOMPLETE when Status is " + currStatus + ".");
  	return;
  }
  
//IFOX-00382850: Election Type blank error changes - Start
  
  if((dwr.util.getValue('applStatus') == 'FORCEDAPPR') && (currStatus == 'INCRFIELCT')){
	  alert("Can't Update to FORCEDAPPR when Status is " + currStatus + ".");
	  return;
  }
  
  if(dwr.util.getValue('applStatus') == 'FORCEDAPPR'){
	  if(dwr.util.getValue('electionType') == '' || dwr.util.getValue('electionType') == null ){
		  alert('Election Type cannot be blank while application status is FORCEDAPPR');
		  return false;
	  }
  } 
//IFOX-00396485 - Start
  if(!validateMailingAddress()){
	  return false;
  }  
//IFOX-00396485 - End  
//IFOX-00382850: Election Type blank error changes - End
  
  if (dwr.util.getValue('isChanged') == 'N') {
  	alert("No changes to Update");
  	return;
  } 
 
  textObject = document.getElementsByName('subscriberId')[0];
 //IFOX-00395197 subscriber ID is not mandatory field , can be blank.but in Backend it is NOT NULL, thus defaulting to SPACE
  if (textObject && textObject.readOnly==false && dwr.util.getValue('subscriberId') == '') {
	  	//alert('Please enter Subscriber Id');
	  	textObject.value="          ";//Adding 10 digit space
	  }
/* if (textObject && textObject.readOnly==false && dwr.util.getValue('subscriberId') == '') {
  	alert('Please enter Subscriber Id');
  	document.getElementsByName('subscriberId')[0].focus();
  	return;
  }*/
  
//AAH CR-Start -426569
	if (dwr.util.getValue("autopopulateappldt") == 'Y') {
		applDate = dwr.util.getValue('applDate');
		receiptDate = dwr.util.getValue('receiptDate');
		
		if ((dateCompare(applDate, receiptDate, true) != 0)) {
			alert('Application Date and Received Date should be Same');
			return false();
		}
	}
	
	if (dwr.util.getValue("validatesignagent") == 'Y') {
		
		if (dwr.util.getValue('pcpName') == '') {
			alert('Please select PCP.');
			document.getElementsByName("pcpName")[0].focus();
			return false;
		}

		if (dwr.util.getValue('brokAgentId') == ''){
			alert('Please enter AgentName.');
			document.getElementsByName("brokAgentId")[0].focus();
			return false;
		}

		if (dwr.util.getValue('signOnFile') == '') {
			alert('Please select Signature on File.');
			document.getElementsByName("signOnFile")[0].focus();
			return false;
		}
	}
	//AAH CR-End- 426569
  
    if (dwr.util.getValue('applDate') == '') {
  	alert('Please enter Application Date');
  	document.getElementsByName('applDate')[0].focus();
  	return;
  }
  if (dwr.util.getValue('applStatus') == '') {
  	alert('Please select Application Status');
  	document.getElementsByName('applStatus')[0].focus();
  	return;
  }
  if (!validReqFields()) {
  	return;
  }
  if (!validAttestation()) {
  	return;
  }
  /** Triple S BasePlus Migration START **/
  /* Fix for IFOX-00378075 -- START*/
  if (!validMedicaId()) {
	  	return;
  }
  /* Fix for IFOX-00378075 -- END*/
  	/**AAH BasePlus Migration IFOX-00426351 START*/
  	/*AAH CR-416461 - start*/
	if (dwr.util.getValue('nameInstituteParmCd') == 'Y' && dwr.util.getValue('nameInstitute') == '') {
		alert('Please enter Name of Instution.');
		document.getElementsByName("nameInstitute")[0].focus();
		return false;
	}
	/*AAH CR-416461 - end*/
	/**AAH BasePlus Migration IFOX-00426351 END*/
  /** Triple S BasePlus Migration END **/
  ssn = dwr.util.getValue("mbrSsn");
  if (ssn != "") {
  	dwr.util.setValue("mbrSsn", ssn.replace(/-/g, ''));
  }
  if (dwr.util.getValue("enrollProdName") == "") {
  	dwr.util.setValue("enrollProduct", "");
  }
  var achAcctNbr = "";
  var achABARoutNbr = "";
  /*Triple S BasePlus Migration/Bank Name/Draft Day changes on Billing START*/
  var iChars = "`~!@#$%^&amp;*()+=-[]\\\';,./{}|\":<>?";
  var achDraftDayValue = "";
  var achBankName = "";
  achDraftDayValue = dwr.util.getValue("achDraftDay");
  achBankName = dwr.util.getValue("achBankName");
  /*Triple S BasePlus Migration/Bank Name/Draft Day changes on Billing END*/
  achAcctNbr = dwr.util.getValue("achbankAcctNbr");
  achABARoutNbr = dwr.util.getValue("achAbaRoutingNbr");
  
  if (achAcctNbr == "" && achABARoutNbr != "") {
	  alert('Please enter Bank Acct Nbr');
	  document.getElementsByName('achbankAcctNbr')[0].focus();
	  return;
  }
  if (achAcctNbr != "" && achABARoutNbr == "") {
	  alert('Please enter ABA Routing Nbr');
	  document.getElementsByName('achAbaRoutingNbr')[0].focus();
	  return;
  }
  /*Triple S BasePlus Migration/Bank Name/Draft Day changes on Billing START*/
  for (var i = 0; i < achBankName.length; i++) {
	  if (iChars.indexOf(achBankName.charAt(i)) != -1) {
		  alert ("Special Characters are not allowed for ACH - Bank Name");
		  document.getElementsByName('achBankName')[0].focus();
		  return false;
	  }
  }
  if (achDraftDayValue != "" && (achBankName != "" || achABARoutNbr != "" || achAcctNbr !="")){
	  if(achDraftDayValue < 1 || achDraftDayValue > 28){
		alert('Please enter a Valid Draft Day value between 1 and 28 only !!');
		document.getElementsByName('achDraftDay')[0].focus();
		return false;
	  }
   }
  /*Triple S BasePlus Migration/Bank Name/Draft Day changes on Billing END*/
  
	if (dwr.util.getValue('mbrHicNbr') == '') {
		alert('Please enter Medicare ID.');
		document.getElementsByName("mbrHicNbr")[0].focus();
		return false;
	}
  
  //document.body.style.cursor = 'wait';
  document.body.className = 'wait';
  document.eemApplForm.method.value = 'applUpdate';
  document.eemApplForm.submit();
}

//original application start

function originalAppl(){
	
	var customerId = document.getElementById('customerId').value;
	
	var applId = document.getElementById('applId').value;
	if(customerId == "" || applId == ""){
		alert("No Original Application record exists!!");
		return;
	}
	
	try{
		FacadeManager.checkOriginalApplication(applId,customerId,{
			callback:function(data) {
					setOriginalApplication(data);
			}
		});
	
	} catch(e) {
		document.body.style.cursor = 'default';
		alert("Error: "+e.message);
	}
}
function setOriginalApplication(data){

	if(data){
		
		//ctl.setValue("background-color", "olive");
		dwr.util.setValue("originalButton", "1");
		document.body.className = 'wait';
		document.eemApplForm.method.value = 'originalAppl';
		document.eemApplForm.submit();
		}
	else {
		alert("No original application record exists!!");
		}
	}
	function currAppl(){
		
		dwr.util.setValue("originalButton","0");
		document.body.className = 'wait';
		
	  	document.eemApplForm.method.value = 'currentAppl';
	  	document.eemApplForm.submit();
		
	}
//original application end


function applSearch() {
    var ctl = document.getElementsByName('searchApplId')[0];
    ctl.value = Ltrim(Rtrim(ctl.value));
    if (!isFldNumeric(ctl,"Application Id"))
  		return;
	document.body.className = 'wait body_bgcolor';
  	document.eemApplForm.method.value = 'applSearch';
  	document.eemApplForm.submit();
}
function validReqFields() {
	if (dwr.util.getValue('applStatus') != 'INCOMPLETE') {
		if (dwr.util.getValue('reqDtCov') == '') {
			alert('Please enter Request Date of Cov.');
			document.getElementsByName("reqDtCov")[0].focus();
			return false;
		} 
		if (dwr.util.getValue('mbrHicNbr') == '') {
			alert('Please enter Medicare ID.');
			document.getElementsByName("mbrHicNbr")[0].focus();
			return false;
		} 
		if (dwr.util.getValue('mbrLastName') == '') {
			alert('Please enter Last Name.');
			document.getElementsByName("mbrLastName")[0].focus();
			return false;
		} 
		if (dwr.util.getValue('mbrFirstName') == '') {
			alert('Please enter First Name.');
			document.getElementsByName("mbrFirstName")[0].focus();
			return false;
		} 
		if (dwr.util.getValue('enrollProdName') == '') {
			alert('Please enter Product.');
			document.getElementsByName("enrollProdName")[0].focus();
			return false;
		} 
		if (dwr.util.getValue('perAdd1') == '') {
			alert('Please enter Primary Address 1.');
			document.getElementsByName("perAdd1")[0].focus();
			return false;
		} 
		if (dwr.util.getValue('perCity') == '') {
			alert('Please enter Primary City.');
			document.getElementsByName("perCity")[0].focus();
			return false;
		} 
		if (dwr.util.getValue('perState') == '') {
			alert('Please enter Primary State.');
			document.getElementsByName("perState")[0].focus();
			return false;
		} 
		if (dwr.util.getValue('perZip5') == '') {
			alert('Please enter Primary Zip5.');
			document.getElementsByName("perZip5")[0].focus();
			return false;
		}
		/*if (dwr.util.getValue('otherCov') != '' || dwr.util.getValue('covBin') != '' ||
			dwr.util.getValue('covId') != '' || dwr.util.getValue('groupNo') != '' || dwr.util.getValue('covPcn') != '') {
			
			setField('drugCov','Y');
			
			if (dwr.util.getValue('otherCov') == '') {
				alert('Please enter Name of Other Coverage.');
				document.getElementsByName("otherCov")[0].focus();
				return false;
			}
			if (dwr.util.getValue('covBin') == '') {
				alert('Please enter BIN.');
				document.getElementsByName("covBin")[0].focus();
				return false;
			}
			if (dwr.util.getValue('covId') == '') {
				alert('Please enter ID for Coverage.');
				document.getElementsByName("covId")[0].focus();
				return false;
			}
			if (dwr.util.getValue('groupNo') == '') {
				alert('Please enter Group Nbr.');
				document.getElementsByName("groupNo")[0].focus();
				return false;
			}
			if (dwr.util.getValue('covPcn') == '') {
				alert('Please enter PCN.');
				document.getElementsByName("covPcn")[0].focus();
				return false;
			} 
		} else {
			setField('drugCov','N');
		} */
	}
	
	// IFOX-00381706 - COB Fix CR Summacare - Start
	
	getCOBParmCD();
	var isInCmpltCOBChk = dwr.util.getValue('isInCmpltCOB');
	if(isInCmpltCOBChk != "Y"){
		setOtherDrugCoverage();
	}
	// IFOX-00381706 - COB Fix CR Summacare - End
	
	return true;
}
function validateComment() {

	//fix for Part A/B/D dates change not saving : start
		
		var a = document.getElementById('partAPicker');
		var b = document.getElementById('partBPicker');
		var d = document.getElementById('partDPicker');
		
		if(a != undefined && b != undefined && d != undefined
				&& a!= null && b !=null && d != null){
			
				dwr.util.setValue('partAEffDt', a.value);
				dwr.util.setValue('partBEffDt', b.value);
				dwr.util.setValue('partDEffDt', d.value);
		}

	//fix for Part A/B/D dates change not saving : end
	  if(!(dwr.util.getValue('applStatus')=='CANCELLED'||dwr.util.getValue('applStatus')=='DENIEDETYP'||dwr.util.getValue('applStatus')=='DENIEDELG'
			||dwr.util.getValue('applStatus')=='DENIEDOTHR')){
	  if (dwr.util.getValue('applDate') == '') {
		  	alert('Please enter Application Date');
		  	document.getElementsByName('applDate')[0].focus();
		  	return;
		    }
			
			if (dwr.util.getValue('perZip5') == '') {
				alert('Please enter Primary Zip.');
				document.getElementsByName("perZip5")[0].focus();
				return false;
			}
			//IFOX-00396485 - Start		
			if(!validateMailingAddress()) {
				return false;
			}
			//IFOX-00396485 - End
			
			// IFOX-00381706 - COB Fix CR Summacare - Start
			//alert(dwr.util.getValue('operId'));
			getCOBParmCD();
			var isInCmpltCOBChk = dwr.util.getValue('isInCmpltCOB');
			//alert(isInCmpltCOBChk);
			if(isInCmpltCOBChk != "Y"){
				setOtherDrugCoverage();
			}
			// IFOX-00381706 - COB Fix CR Summacare - End
			
			  if (!validAttestation()) {
			  	return;
			  }
	  }
	  ssn = dwr.util.getValue("mbrSsn");
	  if (ssn != "") {
	  	dwr.util.setValue("mbrSsn", ssn.replace(/-/g, ''));
	  }
	  //document.body.style.cursor = 'wait';
	  document.body.className = 'wait';  
	  document.eemApplForm.method.value = 'updateComment';
	  document.eemApplForm.submit();
	}
function validateApplication() {

//fix for Part A/B/D dates change not saving : start
	var a = document.getElementById('partAPicker');
	var b = document.getElementById('partBPicker');
	var d = document.getElementById('partDPicker');
	
	if(a != undefined && b != undefined && d != undefined
			&& a!= null && b !=null && d != null){
		
			dwr.util.setValue('partAEffDt', a.value);
			dwr.util.setValue('partBEffDt', b.value);
			dwr.util.setValue('partDEffDt', d.value);
	}

//fix for Part A/B/D dates change not saving : end
	
	var ctl = document.eemApplForm.elig_override;
	if(ctl){		
		if(ctl.checked == true){
			document.forms[0].eligOverrideInd.value ='Y';
		}else{
			document.forms[0].eligOverrideInd.value ='N';
		}
	}
	
	//IFOX-00431133 -CMS Changes Start
	 if (dwr.util.getValue('emailOptIn') == 'Y') {
		if(dwr.util.getValue('mbrEmail')==''){
		alert('Please enter Email ID.');
		document.getElementsByName("mbrEmail")[0].focus();
		return false;
	  }
	}
	//IFOX-00431133 -CMS Changes End
	
	
	//IFOX-00427552- Start
	 if(dwr.util.getValue('btnClicked')=='Cancel'){
 	 	 
	 	 if(dwr.util.getValue('reasonPDP')==''){
	 		 window.scrollTo(0,2300);
	 		 alert("Cancel Reason can't be blank for Cancellation of Application");		 
	 		 document.getElementsByName("reasonPDP")[0].focus();
	 		 return;
	 	 }
	 }
	//IFOX-00427552- End
	
  if(!(dwr.util.getValue('applStatus')=='CANCELLED'||dwr.util.getValue('applStatus')=='DENIEDETYP'||dwr.util.getValue('applStatus')=='DENIEDELG'
		||dwr.util.getValue('applStatus')=='DENIEDOTHR')){
	  if (dwr.util.getValue('applDate') == '') {
	  	alert('Please enter Application Date');
	  	document.getElementsByName('applDate')[0].focus();
	  	return;
	    }
		
		if (dwr.util.getValue('perZip5') == '') {
			alert('Please enter Primary Zip.');
			document.getElementsByName("perZip5")[0].focus();
			return false;
		}
		//IFOX-00396485 - Start		
		if(!validateMailingAddress()) {
			return false;
		}
		//IFOX-00396485 - End
		
		// IFOX-00381706 - COB Fix CR Summacare - Start
		//alert(dwr.util.getValue('operId'));
		getCOBParmCD();
		var isInCmpltCOBChk = dwr.util.getValue('isInCmpltCOB');
		//alert(isInCmpltCOBChk);
		if(isInCmpltCOBChk != "Y"){
			setOtherDrugCoverage();
		}
		// IFOX-00381706 - COB Fix CR Summacare - End
		
		  if (!validAttestation()) {
		  	return;
		  }
		  /** Triple S BasePlus Migration START **/
		  /* Fix for IFOX-00378075 -- START*/
		  if (!validMedicaId()) {
			  	return;
		  }
		  /* Fix for IFOX-00378075 -- END*/
		  /** Triple S BasePlus Migration END **/
  }
  ssn = dwr.util.getValue("mbrSsn");
  if (ssn != "") {
  	dwr.util.setValue("mbrSsn", ssn.replace(/-/g, ''));
  }
  	/**AAH BasePlus Migration IFOX-00426351 START*/
  	/*CR-416461 - start*/
	if (dwr.util.getValue('nameInstituteParmCd') == 'Y' && dwr.util.getValue('nameInstitute') == '') {
		alert('Please enter Name of Instution.');
		document.getElementsByName("nameInstitute")[0].focus();
		return false;
	}
	/*CR-416461 - end*/
	/**AAH BasePlus Migration IFOX-00426351 END*/
	
	
	//AAH CR-Start -426569
	if (dwr.util.getValue("autopopulateappldt") == 'Y') {
		applDate = dwr.util.getValue('applDate');
		receiptDate = dwr.util.getValue('receiptDate');
		
		if ((dateCompare(applDate, receiptDate, true) != 0)) {
			alert('Application Date and Received Date should be Same');
			return false();
		}
	}
	
	if (dwr.util.getValue("validatesignagent") == 'Y') {
		
		if (dwr.util.getValue('pcpName') == '') {
			alert('Please select PCP.');
			document.getElementsByName("pcpName")[0].focus();
			return false;
		}
		if (dwr.util.getValue('brokAgentId') == ''){
			alert('Please enter AgentName.');
			document.getElementsByName("brokAgentId")[0].focus();
			return false;
		}

		if (dwr.util.getValue('signOnFile') == '') {
			alert('Please select Signature on File.');
			document.getElementsByName("signOnFile")[0].focus();
			return false;
		}
	}
	//AAH CR-End- 426569
	
  //document.body.style.cursor = 'wait';
  document.body.className = 'wait';  
  document.eemApplForm.method.value = 'validate';
  document.eemApplForm.submit();
  loadingShow();
}
function setOtherDrugCoverage() {
	if (dwr.util.getValue('otherCov') != '' || dwr.util.getValue('covBin') != '' ||
		dwr.util.getValue('covId') != '' || dwr.util.getValue('groupNo') != '' || dwr.util.getValue('covPcn') != '') {
		setField('drugCov','Y');
	} else {
		setField('drugCov','N');
	}
}

//IFOX-00381706 - COB Fix CR Summacare - Start
function getCOBParmCD() {
	try{
	var temp = 'INCMPLTCOB';
		//alert(temp);
			FacadeManager.getCOBParmCD(temp, {
						callback:function(data) { 
							dwr.util.setValue('isInCmpltCOB', data);
						}
						});

	} catch(e) {
		document.body.style.cursor = 'default';
		alert("Error: "+e.message);
	}
	
}
//IFOX-00381706 - COB Fix CR Summacare - End
/* Personal Info */
function checkSSN(ele) {
	ele.value = formatSSN(ele.value);
	
	if (ele.value != "" && !checkSSNFormat(ele)) {
		ele.focus();
		ele.select();
		return false;
	}
}

/* Enroll Info */
function setElectionDt(ele) {
	text = ele.options[ele.selectedIndex].text;
	dtEle = document.getElementsByName('electionDt')[0];
	if (text.indexOf('SEP') != -1) {// SEP present
		dtEle.className = 'textbox datePickermmddyy';
		dtEle.readOnly = false;
		 $("#elecDt").datepicker({
		     dateFormat: "mm/dd/yy",
		     yearRange: '1900:2100',
		     changeMonth: true,
	      changeYear: true,
	      showButtonPanel: true
		 }).focus(function() {
		     var thisCalendar = $(this);
		     $('.ui-datepicker-close').click(function() {
		 			var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
		 			var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
		 			thisCalendar.datepicker('setDate', new Date(year, month, 1));
			     });
		 });
	} else {
		dtEle.className = 'readonly';
		dtEle.readOnly = true;
		dtEle.value = '';
	}
	val = ele.options[ele.selectedIndex].value;
	/*Removed as SEP Reason code will be displayed for all customers
   this changes was made as part of CAMBIA.

	if (val != "S") {
		// Set SEP Election reason to blank
		dwr.util.setValue('sepReason', '');
	}*/
	
	chkBox = document.getElementsByName('editOverride')[0];
	if (val == "I") {
		chkBox.disabled = false;
	} else { 
		chkBox.checked = false;
	    chkBox.disabled = true;
	}
}
function validateText(element){
	if(element.getAttribute("class") == "readonly")
		$("#ui-datepicker-div").hide();
}
function setElcDerivedInd() {
	dwr.util.setValue('elcDerivedInd', 'N');
}
/* Search results */
function setMbrValues(applId, rowSelected) {
  //document.body.style.cursor = 'wait';	
  document.body.className = 'wait';
  
  var tbl = document.getElementById('resultTbl');
  var len = tbl.rows.length;
  for(var i=1; i < len; i++) {
      tbl.rows[i].className = 'oddRow';
  }
  rowSelected.className = 'selectedRow';

  document.eemApplForm.applId.value = applId;
  document.eemApplForm.method.value = 'rowSearch';
  document.eemApplForm.submit();
  
}
function setMbrValues(applId, rowSelected, row) {
  	//document.body.style.cursor = 'wait';	
  	document.body.className = 'wait';
  
  	var tbl = document.getElementById('resultTbl');
  	var len = tbl.rows.length - 2;
  	for(var i=0; i < len; i++) {
 		if (i == row) {
  			setElemTableRowClass(tbl.rows[i+1],'selectedRow');
 		} else {
      		if ((i % 2) == 0) {
				setElemTableRowClass(tbl.rows[i+1],'oddRow');
		    } else {
				setElemTableRowClass(tbl.rows[i+1],'evenRow');
    		} 		
 		} 
    }

  document.eemApplForm.applId.value = applId;
  document.eemApplForm.method.value = 'rowSearch';
  document.eemApplForm.submit();
  
}

/* Enrolling in / Enrolled */
eemProdWin = null;
function openProductSearch(args) {
	if (dwr.util.getValue("reqDtCov") == '') {
		alert('Please enter Requested date of cov');
		document.getElementsByName('reqDtCov')[0].focus();
		return;
	}
	url = "/eemAction.do?method=prodSearch";
	url = url + "&outOfArea="+getChkBox()+"&covDt="+dwr.util.getValue("reqDtCov")+"&applType="+dwr.util.getValue("applType")+ args;
	//alert(url);
	
	/*alert(dwr.util.getValue("reqDtCov"));
	alert(dwr.util.getValue("perState"));*/
	
	var ww = 1000;
	var wh = 550;
	var wt = 1;
	var wl = ((screen.width - 10) - ww) / 2;
	
	eemProdWin = window.open(url,"applProductSrch","toolbar=no,titlebar=0,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,ControlBox=no,width=" + ww + ",height=" + wh + ",left=" + wl + ",top=" + wt);
	eemProdWin.focus();
	//if (eemProdWin == null) {
	//	eemProdWin = window.open(url,"applProductSrch","toolbar=no,titlebar=0,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=no,ControlBox=no,width=" + ww + ",height=" + wh + ",left=" + wl + ",top=" + wt);
	//} else {
	//	eemProdWin.focus();
	//}
}
function getProduct() {
	try {
	    groupName = dwr.util.getValue("enrollGroupName");
	    groupName = groupName.toUpperCase();
		productName = dwr.util.getValue("enrollProdName");
		productName = productName.toUpperCase();
	    planId = dwr.util.getValue("enrollPlan");
	    pbp = dwr.util.getValue("enrollPbp");
		segment = dwr.util.getValue("enrollSegment");
		outOfArea = getChkBox();
		covDt = dwr.util.getValue("reqDtCov");
		type = dwr.util.getValue("applType");
		if(productName == "") {
			return;
		}
	    zipCode5 = dwr.util.getValue("perZip5");
	    zipCode4 = dwr.util.getValue("perZip4");
	    //alert(productName);
		FacadeManager.getProducts(groupName, productName, zipCode5, zipCode4, planId, pbp, segment, outOfArea, covDt, type,{
		  			callback:function(data) {
	  				    setData(data);
					}
		  			});
	} catch(e) {
		document.body.style.cursor = 'default';
		alert("Error: "+e.message);
	}
}
function modifyProduct() {
	dwr.util.setValue('enrollProdName','');
	dwr.util.setValue('enrollProd','');
	try {
		/*productName = dwr.util.getValue("enrollProdName");
	    planId = dwr.util.getValue("enrollPlan");
	    pbp = dwr.util.getValue("enrollPbp");
		segment = dwr.util.getValue("enrollSegment");
		outOfArea = dwr.util.getValue("outOfArea");
		covDt = dwr.util.getValue("reqDtCov");
		zipCode5 = dwr.util.getValue("perZip5");
	    zipCode4 = dwr.util.getValue("perZip4");
		if(productName == "") {
			return;
		}
		dwr.util.setValue('enrollProdName','');
	    
		FacadeManager.getProducts('', zipCode5, zipCode4, planId, pbp, segment, outOfArea, covDt,{
		  			callback:function(data) {
	  				    setData(data);
					}
		  			});*/
	} catch(e) {
		document.body.style.cursor = 'default';
		alert("Error: "+e.message);
	}
}
function setData(data){
    groupName = "enrollGroupName";
	productName = "enrollProdName";
	groupId = "enrollGroup";
	productId = "enrollProduct";
	planId = "enrollPlan";
    pbp = "enrollPbp";
	segment = "enrollSegment";
	zip5 = dwr.util.getValue("perZip5");
	zip4 = dwr.util.getValue("perZip4");
	if (isOutOfArea()) {
		zip5 = '';
		zip4 = '';
	}
	eemProdWin = null;
  	if(data == null) {
	var prodName=dwr.util.getValue(productName);
  		 prodName=prodName.replace("+","^");
	    args = "&group="+dwr.util.getValue(groupName)+"&prod="+prodName+"&zip5="+zip5+
	           "&zip4="+zip4+"&plan="+dwr.util.getValue(planId)+
			"&groupId="+dwr.util.getValue(groupId)+"&prodId="+dwr.util.getValue(productId)+
			//IFOX-00395074 start
			"&perState="+dwr.util.getValue("perState")+
			"&perCounty="+dwr.util.getValue("perCounty")+
			//IFOX-00395074 end
	           "&pbp="+dwr.util.getValue(pbp)+"&segment="+dwr.util.getValue(segment);
  		//dwr.util.setValue(productName, "");
  		//dwr.util.setValue("enrollProduct", "");
  		openProductSearch(args);
  	} else if(data.multiProducts == 'Y') {
	    args = "&group="+dwr.util.getValue(groupName)+"&prod="+dwr.util.getValue(productName)+"&zip5="+zip5+
	           "&zip4="+zip4+"&plan="+dwr.util.getValue(planId)+
				"&groupId="+dwr.util.getValue(groupId)+"&prodId="+dwr.util.getValue(productId)+
				//IFOX-00395074 start
				"&perState="+dwr.util.getValue("perState")+
				"&perCounty="+dwr.util.getValue("perCounty")+
				//IFOX-00395074 end
	           "&pbp="+dwr.util.getValue(pbp)+"&segment="+dwr.util.getValue(segment)+
	           "&multi=1";
	    //dwr.util.setValue(productName, "");
	    //dwr.util.setValue("enrollProduct", "");
  		openProductSearch(args);
  	} else {
	   	setProductValues(data.enrollGroupName,
	   	                 data.enrollProduct, data.enrollProdName, data.perZip5, data.perZip4, 
	   	                 data.enrollPlan, data.enrollPbp, data.enrollSegment, data.enrollGroup,
	   	                 data.perCity, data.perState, data.perCounty, data.enrollPlanDesgn, 
	   	                 data.enrollPymtAmt,data.enrollLineOfBusiness); //Updated for IFOX-00389053  
	}
}
function setProductValues(groupName, prodId, prodName, zip5, zip4, planId, pbpId, segId, groupId, 
							area, stateCd, county, planDesgn, pymtAmt,lob) { //Updated for IFOX-00389053 
	dwr.util.setValue('enrollGroup',groupId);
	dwr.util.setValue('enrollGroupName',groupName);
   	dwr.util.setValue('enrollProduct',prodId);
   	dwr.util.setValue('enrollProdName',prodName);
	dwr.util.setValue('enrollPlan',planId);
	dwr.util.setValue('enrollPbp',pbpId);
	dwr.util.setValue('enrollSegment',segId);
	dwr.util.setValue('enrollPlanDesgn', planDesgn);
	dwr.util.setValue('enrollPymtAmt', pymtAmt);
	//Start IFOX-00389053 
	dwr.util.setValue('enrollLineOfBusiness', lob);
	//End IFOX-00389053 
	/**AAH BasePlus Migration IFOX-00426351 START*/ 
	  manageLTCAddlnQuestions(true);
	  /**AAH BasePlus Migration IFOX-00426351 END*/
/*	if (!isOutOfArea()) {
		if (zip5.indexOf('X') == -1) {
			dwr.util.setValue('perZip5',zip5);
		}
		if (zip4.indexOf('X') == -1) {
			dwr.util.setValue('perZip4',zip4);
		}
		dwr.util.setValue('perCity',area);
		if (stateCd.indexOf('X') == -1) {
			dwr.util.setValue('perState',stateCd);
		}
		if (county.indexOf('X') == -1) {
			dwr.util.setValue('perCounty',county);
		}		
	} */
}
function isOutOfArea() {
	ele = document.getElementsByName('outOfArea')[0];
	if (ele.checked) {
		return true;
	} 
	return false;
}
function getChkBox() {
	ele = document.getElementsByName('outOfArea')[0];
	if (ele.checked) {
		return "E";
	} 
	return "";
}
function setHidden(groupName, prodId, prodName, zip5, zip4, planId, pbpId, segId, groupId, area, stateCd, county, planDesgn, pymtAmt,lob) {  //Updated for IFOX-00389053 
	dwr.util.setValue('hidGroupId',groupId);
	dwr.util.setValue('hidGroupName',groupName);
	dwr.util.setValue('hidProdId',prodId);
	dwr.util.setValue('hidProdName',prodName);
	dwr.util.setValue('hidZip5',zip5);
	dwr.util.setValue('hidZip4',zip4);
	dwr.util.setValue('hidPlanId',planId);
	dwr.util.setValue('hidPbpId',pbpId);
	dwr.util.setValue('hidSegId',segId);
	dwr.util.setValue('hidArea',area);
	dwr.util.setValue('hidStateCd',stateCd);
	dwr.util.setValue('hidCounty',county);
	dwr.util.setValue('hidPlanDesgn',planDesgn);
	dwr.util.setValue('hidPymtAmt',pymtAmt);
	//Start IFOX-00389053 
	dwr.util.setValue('hidLineOfBusiness',lob);	
	//End IFOX-00389053 
}
function populateValues() {
    groupId = dwr.util.getValue('hidGroupId');
    groupName = dwr.util.getValue('hidGroupName');
	prodId = dwr.util.getValue('hidProdId');
	prodName = dwr.util.getValue('hidProdName');
	zip5 = dwr.util.getValue('hidZip5');
	zip4 = dwr.util.getValue('hidZip4');
	planId = dwr.util.getValue('hidPlanId');
	pbpId = dwr.util.getValue('hidPbpId');
	segId = dwr.util.getValue('hidSegId');
	area = dwr.util.getValue('hidArea');
	stateCd = dwr.util.getValue('hidStateCd');
	county = dwr.util.getValue('hidCounty');
	planDesgn = dwr.util.getValue('hidPlanDesgn');
	pymtAmt = dwr.util.getValue('hidPymtAmt');
	//Start IFOX-00389053 	
	lob = dwr.util.getValue('hidLineOfBusiness');
	//End IFOX-00389053 
	if(prodId != null && prodId != "") {
		window.opener.setProductValues(groupName, prodId, prodName, zip5, zip4, planId, pbpId, segId, groupId,
										area, stateCd, county, planDesgn, pymtAmt,lob); //Updated for IFOX-00389053 
		window.opener.setField('isChanged','Y');										
		window.close();
	}
}
function searchProducts() {
	document.eemApplForm.method.value = 'prodSearch';
  	document.eemApplForm.submit();
}
function prodOnLoad() {
	this.ControlBox = false;
	/*displayException();
	if(dwr.util.getValue('multi') == '1') {
		dwr.util.setValue('multi', '');
		searchProducts();
	}*/
	dwr.util.setValue('outOfArea', window.opener.getChkBox());
	dwr.util.setValue('reqDtCov', window.opener.getField('reqDtCov'));
	dwr.util.setValue('applType', window.opener.getField('applType'));
}
function resetProdSearch() {
	ele = document.getElementsByTagName("input");
	for(i = 0; i < ele.length; i++) {
		if (ele[i].name.indexOf('search') != -1) {
			ele[i].value = '';
		}
	}
}
function cancelSearch() {
	window.close();
	window.opener.eraseProduct();
}
function eraseProduct() {
	dwr.util.setValue('enrollProdName','');
	dwr.util.setValue('enrollProduct','');
}
function setLookUps() {
	if (!validateDate(document.getElementsByName('reqDtCov')[0])) {
		return false;
	}
	//setPCPNames();
	//setInstLookUp();
	//setAgencies();
}
 //IFOX- 421780 : Part A/B/D Date Format Validation - start 
function validatePartAB(ele){
	if (!validateDate(ele)) {
		return false;
	}
}  
//IFOX- 421780 : Part A/B/D Date Format Validation - end

// PCP search
eemPcpWin = null;
function openPcpSearch(args) {
	if (dwr.util.getValue("reqDtCov") == '') {
		alert('Please enter Requested date of cov');
		document.getElementsByName('reqDtCov')[0].focus();
		return;
	}

/*	if (dwr.util.getValue("enrollProduct") == '' && dwr.util.getValue("lobValidation") == 'Y') {
		alert('Line of Busines is enabled; Please select a valid Product !!');
		document.getElementsByName('enrollProdName')[0].focus();
		return;
	}*/	
	
	url = "/eemAction.do?method=pcpSearch";
	
/*	if(dwr.util.getValue("lobValidation") == 'Y'){
		url = url + "&currPatient="+getCurrPatient('pcpCurrPatnt')+"&covDt="+dwr.util.getValue("reqDtCov")+
		//"&enrollLineOfBusiness="+dwr.util.getValue("enrollLineOfBusiness")+args; //Updated for IFOX-00389053 
		"&enrollLineOfBusiness="+dwr.util.getValue("enrollProduct")+args;
	}else{
		url = url + "&currPatient="+getCurrPatient('pcpCurrPatnt')+"&covDt="+dwr.util.getValue("reqDtCov")+
		//"&enrollLineOfBusiness="+dwr.util.getValue("enrollLineOfBusiness")+args; //Updated for IFOX-00389053 
		"&enrollLineOfBusiness="+dwr.util.getValue("enrollLineOfBusiness")+args;		
	}*/
	
	url = url + "&currPatient="+getCurrPatient('pcpCurrPatnt')+"&covDt="+dwr.util.getValue("reqDtCov")+
	//"&enrollLineOfBusiness="+dwr.util.getValue("enrollLineOfBusiness")+args; //Updated for IFOX-00389053 
	"&enrollLineOfBusiness="+dwr.util.getValue("enrollLineOfBusiness")+args;	
	
	var ww = 900;
	var wh = 550;
	var wt = 1;
	var wl = ((screen.width - 10) - ww) / 2;
	
	eemPcpWin = window.open(url,"applPcpSrch","toolbar=no,titlebar=0,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,ControlBox=no,width=" + ww + ",height=" + wh + ",left=" + wl + ",top=" + wt);
	eemPcpWin.focus();
			
	//if (eemPcpWin == null) {
	//	eemPcpWin = window.open(url,"_blank","toolbar=no,titlebar=0,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=no,ControlBox=no,width=" + ww + ",height=" + wh + ",left=" + wl + ",top=" + wt);
	//} else {
	//	eemPcpWin.focus();
	//}
}
function getCurrPatient(name) {
	ele = document.getElementsByName(name)[0];
	if (ele.checked) {
		return "Y";
	} 
	return "N";
}
function setCurrPatient(val) {
	ele = document.getElementsByName('pcpCurrPatnt')[0];
	if (val == "Y") {
		ele.checked = true;
	} else {
		ele.checked = false;
	}
}
function checkCurrPatient() {
	dwr.util.setValue('pcpName', '');
	dwr.util.setValue('pcpOfficeCd', '');
	dwr.util.setValue('pcpLocationId', '');

}
function pcpOnLoad() {
	this.ControlBox = false;
	//dwr.util.setValue('pcpCurrPatnt', window.opener.getCurrPatient());
	dwr.util.setValue('reqDtCov', window.opener.getField('reqDtCov'));
}
function searchPcps() {
	document.eemApplForm.method.value = 'pcpSearch';
  	document.eemApplForm.submit();
}
function resetPcpSearch() {
	ele = document.getElementsByTagName("input");
	for(i = 0; i < ele.length; i++) {
		if (ele[i].name.indexOf('search') != -1) {
			ele[i].value = '';
		}
	}
}
function cancelPcpSearch() {
	window.close();
	window.opener.setField('pcpCode', '');
	window.opener.setField('pcpName', '');
}
function setPcpHidden(officeCd, docName, offCatCd, locId,npiId) {
	dwr.util.setValue('hidOffCd',officeCd);
	dwr.util.setValue('hidPcpName',docName,{ escapeHtml:false });
	dwr.util.setValue('hidOffCatCd',offCatCd);
	dwr.util.setValue('hidLocId', locId);
	
	/*Access health PCP CR- Start*/
	dwr.util.setValue('hidNpiId', npiId);
	/*Access health PCP CR- End*/
}
function populatePcpValues() {
    offCd = dwr.util.getValue('hidOffCd');
	name = dwr.util.getValue('hidPcpName',{ escapeHtml:false });
	offCatCd = dwr.util.getValue('hidOffCatCd');
	locId = dwr.util.getValue('hidLocId');
	/*Access health PCP CR- Start*/
	npiId = dwr.util.getValue('hidNpiId');
	/*Access health PCP CR- End*/
	currPatient = getCurrPatient('searchCurrPatnt');
	if(offCd != null && offCd != "") {
		window.opener.setPcpValues(offCd, name, offCatCd, currPatient, locId, npiId);
		window.opener.setField('isChanged','Y');										
		window.close();
	}
}
function setPcpValues(offCd, name, offCatCd, currPatient, locId, npiId) {
	dwr.util.setValue('pcpOfficeCd',offCd);
   	dwr.util.setValue('pcpName',name,{ escapeHtml:false });
   	dwr.util.setValue('pcpOffCatCd',offCatCd);
  	setCurrPatient(currPatient);
   	dwr.util.setValue('pcpLocationId',locId); 
   	/*Access health PCP CR- Start*/
   	dwr.util.setValue('pcpNpiId',npiId);
   	/*Access health PCP CR- End*/
}
function getPcpName() {
	try {
		currPatientInd = getCurrPatient('pcpCurrPatnt');
		pcpName = dwr.util.getValue('pcpName');
		if (pcpName == "") {
			return;
		}
		pcpName = pcpName.toUpperCase();

   		if (dwr.util.getValue('reqDtCov') != '') {
			FacadeManager.getPCPName(dwr.util.getValue('reqDtCov'), 
										pcpName, 
										currPatientInd,dwr.util.getValue("enrollLineOfBusiness"),{ //Updated for IFOX-00389053
										//currPatientInd,dwr.util.getValue("enrollProduct"),{
										callback:function(data) {
							setPcpData(data);
			  			}
			  			});
		}
	    
	} catch(e) {
		document.body.style.cursor = 'default';
		alert("Error: "+e.message);
	}
}
function setPcpData(data){
	
	/**AAH BasePlus Migration IFOX-00426351 Added LOB START*/
	if(dwr.util.getValue("enrollLineOfBusiness") == '' && dwr.util.getValue("lobValidation") == 'Y'){
		alert("Line of Business is empty; Please select a valid product.");
		document.getElementsByName('enrollProdName')[0].focus();
		return;
	}
	/**AAH BasePlus Migration IFOX-00426351 Added LOB END*/
	
	eemPcpWin = null;
  	if(data == null || data.multiProducts == 'Y') {
	    args = "&docName="+dwr.util.getValue('pcpName');
  		openPcpSearch(args);
  	} else {
  		currPatientInd = getCurrPatient('pcpCurrPatnt');                                                  
	   	setPcpValues(data.pcpOfficeCd, data.pcpName, data.pcpOffCatCd, currPatientInd, data.pcpLocationId, data.pcpNpiId);/*Access health PCP CR-*/
	}
}

/* Broker, Agent, Company Sales Rep */
function getAgencyName() {
	try{
		if (dwr.util.getValue('commAgencyId') != '') {
			FacadeManager.getAgencyName(dwr.util.getValue('commAgencyId'), {
						callback:function(data) { 
							dwr.util.setValue('commName', data);
						}
						});
		}
	} catch(e) {
		document.body.style.cursor = 'default';
		alert("Error: "+e.message);
	}
	
	setBrokerAgentIds();
}
function setAgencies() {
   // Start IFOX-00396423
	if(dwr.util.getValue('signDateProfileOpt') == 'R'){
		return false;
	}
	// End IFOX-00396423
	try {
		
		if (dwr.util.getValue('signDt') != '') {
			FacadeManager.getAgencies(dwr.util.getValue('signDt'),dwr.util.getValue('enrollLineOfBusiness'),{//AAH BasePlus Migration IFOX-00426351 Changes 
			  			callback:function(data) {
			  				dwr.util.removeAllOptions('commAgencyId');
			  				dwr.util.addOptions('commAgencyId', [""]);
			  				dwr.util.addOptions('commAgencyId', data, 'name', 'value');					
			  			}
			  			});
		}
	} catch(e) {
		document.body.style.cursor = 'default';
		alert("Error: "+e.message);
	}
	dwr.util.setValue('brokerType','');
	dwr.util.removeAllOptions('brokAgentId');
}
//-- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - Start
function setBrokerAgents() {
	
	try {
	// Start IFOX-00396423
		if(dwr.util.getValue('commAgencyId') == ''){
			//alert("Please select Agency");
			return false;
		}
		if(dwr.util.getValue('brokerType') == ''){
			//alert("Please select Broker Type");
			return false;
		}
		if(dwr.util.getValue('signDateProfileOpt') != 'R' && dwr.util.getValue('signDt') == ''){
			//alert("Please enter signature date");
			return false;
		}

		// End IFOX-00396423
		if (dwr.util.getValue('commAgencyId') != '' 
										&& dwr.util.getValue('brokerType') != '') {
			//document.body.className = 'wait';
			FacadeManager.getBrokerAgents(dwr.util.getValue('brokerType'),
											dwr.util.getValue('commAgencyId'),
											dwr.util.getValue('signDt'),dwr.util.getValue('reqDtCov'),dwr.util.getValue('enrollLineOfBusiness'),{//AAH BasePlus Migration IFOX-00426351 Changes 
			  			callback:function(data) {
			  				//alert("setBrokerAgents="+ data);
			  				dwr.util.removeAllOptions('brokAgentId');		
			  				dwr.util.setValue('brokAgentId', '');
			  				dwr.util.addOptions('brokAgentId', [""]);
			  				dwr.util.addOptions('brokAgentId', data, 'name', 'value');	
			  			
			  				//var brokAgentId=document.getElementById('brokAgentId');
			  				//$(brokAgentId).select2();
			  				//document.body.className = 'default';
			  			}
			  			});
		}
	} catch(e) {
		document.body.className = 'default';
		alert("Error: "+e.message);
	}
	
}
// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - End
function setAgents() {
	dwr.util.setValue('brokerType','');
	setIdValue('brokerType','');
	$('[name=brokerType').trigger('change');
	dwr.util.removeAllOptions('brokAgentId');
	setIdValue('brokAgentId','');
	$('[name=brokAgentId').trigger('change');
	setBrokerAgents();
}

/* Questions to be answered */
/**AAH BasePlus Migration IFOX-00426351 START*/
function setInstLookUp() {
	val = dwr.util.getValue('nameInstitute');
	ele = document.getElementsByName('longTerm');
	ele[1].checked = true;
	dwr.util.removeAllOptions('nameInstitute');
	dwr.util.setValue('instPhoneNo','');
	dwr.util.setValue('instStreet','');
	try{
		if (dwr.util.getValue('reqDtCov') != '' && dwr.util.getValue('enrollLineOfBusiness') != '') {
			FacadeManager.getInstLookUp(dwr.util.getValue('reqDtCov'),dwr.util.getValue('enrollLineOfBusiness'), {//AAH BasePlus Migration IFOX-00426351 Changes 
			  			callback:function(data) {
			  				dwr.util.addOptions('nameInstitute', [""]);
			  				dwr.util.addOptions('nameInstitute', data, 'name', 'value');					
			  				if (val != "") {
			  					ele[0].checked = true;
			  					dwr.util.setValue('nameInstitute', val);
			  					setInstDetails();
			  				}
			  			}
			  			});
		}
	} catch(e) {
		document.body.style.cursor = 'default';
		alert("Error: "+e.message);
	}
		
}
/**AAH BasePlus Migration IFOX-00426351 END*/
function setInstDetails() {
	try{
		if (dwr.util.getValue('nameInstitute') != '') {
			FacadeManager.getInstDetails(dwr.util.getValue('nameInstitute'), 
						dwr.util.getValue('reqDtCov'), dwr.util.getValue('enrollLineOfBusiness'), {//AAH BasePlus Migration IFOX-00426351 Changes
						callback:function(data) { 
							// Split the details
							var splitVal = data.split("|");
							dwr.util.setValue('instPhoneNo', splitVal[0]);
							dwr.util.setValue('instStreet', splitVal[1]);
						}
						});
		} else {
			dwr.util.setValue('instPhoneNo', '');
			dwr.util.setValue('instStreet', '');
		}
	} catch(e) {
		document.body.style.cursor = 'default';
		alert("Error: "+e.message);
	}
}
function setMedicaidId() {
	text = dwr.util.getValue('stMedicaid');
	ele = document.getElementsByName('medicaidId')[0];
	if (ele != null) {
		if (text == 'Y') {
			ele.className = 'textbox';
			ele.readOnly = false;
		} else {
			ele.className = 'readonly';
			ele.readOnly = true;
			ele.value = '';
		}
	}
}
/* Eligibility Check */
var memberCheck = "0";
function checkMember() {
	if (!validateDate(document.getElementsByName('reqDtCov')[0])) {
		return false;
	}
		
	  reqDtCov = dwr.util.getValue("reqDtCov");
	  hicNbr = dwr.util.getValue("mbrHicNbr");
	  hicNbr =	hicNbr.trim();
	  if(hicNbr.indexOf(' ') != -1){
		  hicNbr = '';
		  document.getElementsByName("mbrHicNbr")[0].focus();
		  document.getElementsByName("mbrHicNbr")[0].value = '';
		  alert('Please enter a Medicare ID !!');
		  return false;
	  }
	  lastName = dwr.util.getValue("mbrLastName");
	  birthDt = dwr.util.getValue("mbrBirthDt");
	  if(dwr.util.getValue("isHicOrMbiEntered") == ""){
		  dwr.util.setValue("isHicOrMbiEntered",isHicOrMbi(hicNbr)); //SSNRI orig app issue check
	  } 
	  if (reqDtCov != '' && hicNbr != '' && (lastName != '' || birthDt != '')) {
		memberCheck = "1";
		document.eemApplForm.method.value = 'memberCheck';
		document.eemApplForm.submit();	
		loadingShow();
	  }
}
eemEligWin = null;
function openEEMEligWin(hic, lastName, birthDt) {
	if (memberCheck == "1") {
		return false;
	}
	
    //if (eemEligWin != null) {
	//  	eemEligWin.close();
	//  	eemEligWin = null;
	//}
	var ww = 1000;
	var wh = 550;
	var wt = 1;
	var wl = ((screen.width - 10) - ww) / 2;
    eemEligWin = window.open("/eemAction.do?method=eligCheck&mbrHicNbr=" + hic + "&mbrLastName=" + lastName +
    			"&mbrBirthDt=" + birthDt,
    			"eligCheck","toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=yes, copyhistory=no, width=" + ww + ",height=" + wh + ",left=" + wl + ",top=" + wt);
    eemEligWin.focus();
}
function eligCheck() {
  reqDtCov = dwr.util.getValue("reqDtCov");
  hic = dwr.util.getValue("mbrHicNbr");
  lastName = dwr.util.getValue("mbrLastName");
  birthDt = dwr.util.getValue("mbrBirthDt");
  if (reqDtCov == '') {
  	alert("Please enter Requested Date of Cov");
  	document.getElementsByName("reqDtCov")[0].focus();
  } else if (lastName == '' && birthDt == '') {
  	alert("Please enter Last Name or Birth Date");
  	document.getElementsByName("mbrLastName")[0].focus();  	
  } else if(hic == '') {
    alert("Please enter Medicare ID");
    document.getElementsByName("mbrHicNbr")[0].focus();
  } else {
  	// referencing the top most parent window
    openEEMEligWin(hic, lastName, birthDt);
	setLastCheckedDate();    			
  }
}

//SSNRI orig app issue check start
//IFOX-00423084 - BasePlus CMS Nov 2019 Changes - Start
/*function isHicOrMbi(medId) {
    
    var flag = "mbi";
    if(medId.length == 11){
          if(!isDigit(medId.charAt(0)))
                 flag = "hic";
          else if(!isLetter(medId.charAt(1)))
                 flag = "hic";
          else if(!isLetterOrDigit(medId.charAt(2)))
                 flag = "hic";
          else if(!isDigit(medId.charAt(3)))
                 flag = "hic";
          else if(!isLetter(medId.charAt(4)))
                 flag = "hic";
          else if(!isLetterOrDigit(medId.charAt(5)))
                 flag = "hic";
          else if(!isDigit(medId.charAt(6)))
                 flag = "hic";
          else if(!isLetter(medId.charAt(7)))
                 flag = "hic";
          else if(!isLetter(medId.charAt(8)))
                 flag = "hic";
          else if(!isDigit(medId.charAt(9)))
                 flag = "hic";
          else if(!isDigit(medId.charAt(10)))
                 flag = "hic";
                 
    }
    else 
          flag = "hic";
    return flag;
}*/

function isHicOrMbi(medId) {
    
    var flag = "mbi";
    if(medId.length == 11){
          if(!isDigit(medId.charAt(0)))
                 flag = "hic";
          else if(!(isLetter(medId.charAt(1)) && !lookUpForExceptions(medId.charAt(1))))
                 flag = "hic";
          else if(!(isLetterOrDigit(medId.charAt(2)) && !lookUpForExceptions(medId.charAt(2))))
                 flag = "hic";
          else if(!isDigit(medId.charAt(3)))
                 flag = "hic";
          else if(!(isLetter(medId.charAt(4)) && !lookUpForExceptions(medId.charAt(4))))
                 flag = "hic";
          else if(!(isLetterOrDigit(medId.charAt(5)) && !lookUpForExceptions(medId.charAt(5))))
                 flag = "hic";
          else if(!isDigit(medId.charAt(6)))
                 flag = "hic";
          else if(!(isLetter(medId.charAt(7)) && !lookUpForExceptions(medId.charAt(7))))
                 flag = "hic";
          else if(!(isLetter(medId.charAt(8)) && !lookUpForExceptions(medId.charAt(8))))
                 flag = "hic";
          else if(!isDigit(medId.charAt(9)))
                 flag = "hic";
          else if(!isDigit(medId.charAt(10)))
                 flag = "hic";
                 
    }
    else 
          flag = "hic";
    return flag;
}

function lookUpForExceptions(ch) {
	var exclusions = ['S', 'L', 'O', 'I', 'B', 'Z'];
	var arrLen = exclusions.length;
	
	for(var i = 0; i < arrLen; i++){
		if(ch === exclusions[i]) {
			//System.out.println("Exclusion Char is Present: " + c);
			return true;
		}		
	}
	return false;	
}
//IFOX-00423084 - BasePlus CMS Nov 2019 Changes - End 
function isLetter(str) {
    return str.length === 1 && str.match(/[a-zA-Z]/i);
  } 
function isDigit(str) {
    return str.length === 1 && str.match(/[0-9]/i);
  } 
function isLetterOrDigit(str) {
    return str.length === 1 && str.match(/[a-zA-Z0-9]/i);
  } 

//SSNRI orig app issue check end
function setLastCheckedDate() {
	try {
		FacadeManager.getTimeStamp('yyyy-MM-dd-HH.mm.ss.SSS000', {
		  			callback:function(data) {
						dwr.util.setValue('dtLstChked', data);
					}});
	} catch(e) {
		document.body.style.cursor = 'default';
		alert("Error: "+e.message);
	}
}
function getOpenerRadioValue(source) {
	ele = window.opener.document.getElementsByName(source);
	if (ele != null) {
		if (ele[0] != null) {
			if (ele[0].value != null) {
				for (var i=0; i < ele.length; i++)	{
					field = ele[i];
			   		if (field.checked)
       	   				return 'Y';
					else
           				return 'N';
   				}
   			}
   		}
   	}
   	return '';
}
function getCountyNameValue(source) {
	ele = window.opener.document.getElementsByName(source);
	if (ele != null) {
		if (ele[0] != null) {
			if (ele[0].textContent != null) {
				for(i=0;i<window.opener.document.getElementsByName(source)[0].children.length;i++) {
					if(window.opener.document.getElementsByName(source)[0].children[i].selected)
					{
						return window.opener.document.getElementsByName(source)[0].children[i].innerText;
					}
				}
   			}else{
   				return ele[0].value;
   			}
   		}
   	}
   	return '';
}
//function getOpenerRadioValue(source) {
//	ele = window.opener.document.getElementsByName(source);
//	if (ele == null)
//		return '';
//	if (ele[0].value == null) {
//		return '';
//	}
//	for (var i=0; i < ele.length; i++)	{
//		field = ele[i];
//   		if (field.checked)
//       	   return 'Y';
//		else
//           return 'N';
//   	}
//   	return '';
//}
//function getOpenerRadioValue(source) {
//	ele = window.opener.document.getElementsByName(source);
//	if (ele[0].value == null) {
//		return '';
//	}
//	for (var i=0; i < ele.length; i++)	{
//		field = ele[i];
//   		if (field.checked) {
//	       if (field.value == 0)
//	       	   return 'Y';
//	       else
//	           return 'N';
//      	}
//   	}
//}
function setOpenerRadioValue(source, val) {
	ele = window.opener.document.getElementsByName(source);
	if (ele != null) {
		if (ele[0] != null) {
			if (ele[0].value != null) {
				if (val == 'Y') {
			       ele[0].checked = true;
			   	} else if (val == 'N') {
			   	   ele[1].checked = true;
			   	}
			}
		}
	}
}
//function setOpenerRadioValue(source, val) {
//	ele = window.opener.document.getElementsByName(source);
//	if (ele == null)
//		return;
//	if (ele[0].value == null) {
//		return;
//	}
//	if (val == 'Y') {
//      ele[0].checked = true;
//   	} else if (val == 'N') {
//   	   ele[1].checked = true;
//   	}
//}
function getOpenerStateDesc() {
   index = window.opener.document.eemApplForm.perState.selectedIndex;
   val = window.opener.document.eemApplForm.perState.options[index].text;
   return val;
}
function setOpenerDate(fieldName,fieldValue)
{
	if (fieldValue == "")
		fieldValue = "00000000";		
	window.opener.setField(fieldName,fieldValue);
}

function updateEligValues(field) {
	if (field[0].checked) {
		window.opener.setField('mbrFirstName',field[0].value);	
	}
	if (field[1].checked) {
		window.opener.setField('mbrMiddleName',field[1].value);	
	}
	if (field[2].checked) {
		window.opener.setField('mbrLastName',field[2].value);	
	}
	if (field[3].checked) {
		window.opener.setField('mbrBirthDt',field[3].value);	
	}
	if (field[4].checked) {
		window.opener.setField('mbrGender',field[4].value);	
	}
	if (field[5].checked) {
		window.opener.setField('perState',field[5].value);
		/*window.opener.setZipCounty();	*/ // TSA issue Zip getting blank
	}
	//if (field[6].checked && field[6].value != '') {
	//	window.opener.setField('perCounty',field[6].value);	
	//}
	if (field[6].checked && field[6].value != '') {
		if(getOpenerRadioValue('esrd') != field[6].value && field[6].value == 'Y') {
			window.opener.setField('esrdStDt', dwr.util.getValue('mbd.esrdStartDate'));
			window.opener.setField('esrdEndDt', dwr.util.getValue('mbd.esrdEndDate'));
		} 
		setOpenerRadioValue('esrd',field[6].value);	
	}
	if (field[7].checked && field[7].value != '') {
		if(getOpenerRadioValue('longTerm') != field[7].value && field[7].value == 'Y') {
			window.opener.setField('longTermStDt', dwr.util.getValue('mbd.instStartDate'));
			window.opener.setField('longTermEndDt', dwr.util.getValue('mbd.instEndDate'));
		} 
		setOpenerRadioValue('longTerm',field[7].value);	
	}
	if (field[8].checked && field[8].value != '') {
		if(getOpenerRadioValue('stMedicaid') != field[8].value && field[8].value == 'Y') {
			window.opener.setField('medicaidStDt', dwr.util.getValue('mbd.medicStartDate'));
			window.opener.setField('medicaidEndDt', dwr.util.getValue('mbd.medicStartDate'));
		} 
		setOpenerRadioValue('stMedicaid',field[8].value);
		window.opener.setMedicaidId();	
	}
	window.opener.setField('partAEffDt',dwr.util.getValue('mbd.prtAEntitleDate'));
	window.opener.setField('partBEffDt',dwr.util.getValue('mbd.prtBEntitleDate'));
	window.opener.setField('partDEffDt',dwr.util.getValue('mbd.prtDEligibleDate'));
	// Set MBD fields
	//if (isChecked(field) == '1') {
		window.opener.setField('mbd.hicNbr', dwr.util.getValue('mbd.hicNbr'));
		window.opener.setField('mbd.lastName', dwr.util.getValue('mbd.lastName'));
		window.opener.setField('mbd.firstName', dwr.util.getValue('mbd.firstName'));
		window.opener.setField('mbd.middleInit', dwr.util.getValue('mbd.middleInit'));
		window.opener.setField('mbd.genderCd', dwr.util.getValue('mbd.genderCd'));
		window.opener.setField('mbd.birthDate', dwr.util.getValue('mbd.birthDate'));
		window.opener.setField('mbd.livingStatus', dwr.util.getValue('mbd.livingStatus'));
		setOpenerDate('mbd.deathDate', dwr.util.getValue('mbd.deathDate'));
		setOpenerDate('mbd.prtAEntitleDate', dwr.util.getValue('mbd.prtAEntitleDate'));
		setOpenerDate('mbd.prtAEntitleEndDate', dwr.util.getValue('mbd.prtAEntitleEndDate'));
		setOpenerDate('mbd.prtBEntitleDate', dwr.util.getValue('mbd.prtBEntitleDate'));
		setOpenerDate('mbd.prtBEntitleEndDate', dwr.util.getValue('mbd.prtBEntitleEndDate'));
		window.opener.setField('mbd.prtAOption', dwr.util.getValue('mbd.prtAOption'));
		window.opener.setField('mbd.prtBOption', dwr.util.getValue('mbd.prtBOption'));
		setOpenerDate('mbd.prtDEligibleDate', dwr.util.getValue('mbd.prtDEligibleDate'));		
		window.opener.setField('mbd.enrollmentStatus', dwr.util.getValue('mbd.enrollmentStatus'));
		window.opener.setField('mbd.hospiceInd', dwr.util.getValue('mbd.hospiceInd'));
		setOpenerDate('mbd.hospiceStartDate', dwr.util.getValue('mbd.hospiceStartDate'));
		setOpenerDate('mbd.hospiceEndDate', dwr.util.getValue('mbd.hospiceEndDate'));
		window.opener.setField('mbd.wrkagedInd', dwr.util.getValue('mbd.wrkagedInd'));
		setOpenerDate('mbd.wrkagedStartDate', dwr.util.getValue('mbd.wrkagedStartDate'));
		setOpenerDate('mbd.wrkagedEndDate', dwr.util.getValue('mbd.wrkagedEndDate'));
		window.opener.setField('mbd.raceCd', dwr.util.getValue('mbd.raceCd'));
		window.opener.setField('mbd.stateCd', dwr.util.getValue('mbd.stateCd'));
		window.opener.setField('mbd.countyCd', dwr.util.getValue('mbd.countyCd'));
	
		window.opener.setField('mbd.esrdInd', dwr.util.getValue('mbd.esrdInd'));
		window.opener.setField('mbd.instInd', dwr.util.getValue('mbd.instInd'));
		window.opener.setField('mbd.medicInd', dwr.util.getValue('mbd.medicInd'));
		setOpenerDate('mbd.esrdStartDate', dwr.util.getValue('mbd.esrdStartDate'));
		setOpenerDate('mbd.esrdEndDate', dwr.util.getValue('mbd.esrdEndDate'));
		setOpenerDate('mbd.instStartDate', dwr.util.getValue('mbd.instStartDate'));
		setOpenerDate('mbd.instEndDate', dwr.util.getValue('mbd.instEndDate'));
		setOpenerDate('mbd.medicStartDate', dwr.util.getValue('mbd.medicStartDate'));
		setOpenerDate('mbd.medicEndDate', dwr.util.getValue('mbd.medicEndDate'));
	//}
	window.opener.setField('isChanged','Y');
	window.close();
}
function getMBDDate(field) {
	var date = getField(field);
	if (date == null || date == '00000000') {
		return '';
	}
	return date;
}
function checkMBDValue(field) {

	if(field == 'esrd'){
		if(getField(field) == 'Y'){
			setField('esrdStDt', getMBDDate('mbd.esrdStartDate'));
			setField('esrdEndDt', getMBDDate('mbd.esrdEndDate'));
			setField('pcoInd', 'Y');
		}
		if(getField(field) == 'N') {
			setField('esrdStDt','');
			setField('esrdEndDt','');
			setField('pcoInd', 'N');
		}
		dwr.util.setValue('esrdChange', 'Y');
	}
	if(field == 'longTerm'){
		if(getField(field) == 'Y'){
			setField('longTermStDt', getMBDDate('mbd.instStartDate'));
			setField('longTermEndDt', getMBDDate('mbd.instEndDate'));
		}
		if(getField(field) == 'N') {
			setField('longTermStDt','');
			setField('longTermEndDt','');
			setField('nameInstitute','');
			setField('instPhoneNo','');
			setField('instStreet','');			
		}
		dwr.util.setValue('longTermChange', 'Y');
	}

	if(field == 'stMedicaid'){
		if(getField(field) == 'Y'){
			setField('medicaidStDt', getMBDDate('mbd.medicStartDate'));
			setField('medicaidEndDt', getMBDDate('mbd.medicEndDate'));
		}
		if(getField(field) == 'N') {
			setField('medicaidStDt','');
			setField('medicaidEndDt','');
		}
		dwr.util.setValue('medicaidChange', 'Y');		
	}
}

/* Attestation */
function populateExceptions(ele) {
	if (ele.value == "" && ele.options.length == 1) {
		selEle = document.getElementsByName("sepException")[0];
		for(i=0; i< selEle.options.length; i++) {
			option = new Option(selEle.options[i].text, selEle.options[i].value);
			ele.options[i] = option;
		}
	}
}
function addException() {
	
  exceptionCntr = document.getElementsByName("sepException").length;
  addOn = '<div id="dynamicDiv'+ exceptionCntr +'" width="100%"><table width="100%"><tr><td width="20%" class="ftr">Medicare SEP Exception :&nbsp;</td>' +
	      '    <td width="40%" align="left" colspan=2>' +
	      '     <select name="sepException" style="width:320px" class="dynamicDropDown'+ exceptionCntr +'" onchange="onChangeEvent(this);">' +
		  '		  	<option value=""></option>' +
		  '		</select>' +
		  '	  </td>' +
		  '	  <td width="20%" class="ftr">Attestation Date :&nbsp;</td>' +
		  '	  <td align="left">' +
		  '	  <input type="text" name="attestDt" class="dynamicDatePickermmddyy' + exceptionCntr + ' textbox" size="12" onchange="if(formatDate(this);futureDateValidation(this);!validateDate(this))return false;if(!compareAttestDt(this))return false;"/></td>'+
		  '   <td align="left" onclick="return false;" ><input type="button" value="Del" id="deldynamicDiv' + exceptionCntr + '" style="width:50px" class="inputButton" onclick="delExceptionByDiv(this);return false;" /></td>' +
	      '</tr></table></div>';
    
  $("#divExceptionTbl2").append($(addOn));
  $(".dynamicDropDown" + exceptionCntr).addClass("dropdown").select2();
  $(".dynamicDatePickermmddyy" + exceptionCntr).datepicker({
	     dateFormat: "mm/dd/yy",
	     yearRange: '1900:2100',
	     changeMonth: true,
      changeYear: true,
      showButtonPanel: true
	 }).focus(function() {
	     var thisCalendar = $(this);
	     $('.ui-datepicker-close').click(function() {
	 			var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
	 			var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
	 			thisCalendar.datepicker('setDate', new Date(year, month, 1));
		     });
	 });
  
  // IE11 Issue END 1
  populateExceptions(document.getElementsByName("sepException")[exceptionCntr]);
  exceptionCntr++;
}
function delException(cell) {
  index = cell.parentNode.rowIndex;
  var ele = document.getElementById('exceptionTbl');
  ele.deleteRow(index);
}
function delExceptionByDiv(arg) {
	var divId = arg.id.substr(3, arg.id.length);
	$("#" + divId).remove();
}
function compareAttestDt(ele) {
	onChangeEvent(ele);
	//signDt = dwr.util.getValue('signDt');
	//if (signDt != "") {
	//	if(dateCompare(ele.value, signDt, true) > 0) {
	//		alert("Attestation Date " + ele.value + " cannot be greater than Signature Date.");
	//		ele.focus();
	//		ele.select();
	//		return false;
	//	}
	//}
	return true;
}
function validAttestation() {
	
	eleExceptions = document.getElementsByName("sepException");
	eleAttestDts = document.getElementsByName("attestDt");
	for(i = 0; i < eleExceptions.length; i++) {
		val = eleExceptions[i].value;
		if (val != "") {
			// Check for Date required
			if (val.indexOf('Y') != -1 && eleAttestDts[i].value == "") {
				alert("Please enter the Attestation Date");
				eleAttestDts[i].focus();
				eleAttestDts[i].select();
				return false;
			}
			
			//// Compare with Signature date
			//if (dwr.util.getValue('signDt') != "") {
			//	if(dateCompare(eleAttestDts[i].value, dwr.util.getValue('signDt'), true) > 0) {
			//		alert("Attestation Date " + eleAttestDts[i].value + " cannot be greater than Signature Date.");
			//		eleAttestDts[i].focus();
			//		eleAttestDts[i].select();
			//		return false;
			//	}
			//}
		}
	}
	
	return true;
}

/* Question to be Answered */
function resetDrugFields() {
	dwr.util.setValue('otherCov', '');
	dwr.util.setValue('covBin', '');
	dwr.util.setValue('covId', '');
	dwr.util.setValue('groupNo', '');
	dwr.util.setValue('covPcn', '');
}

/* Comments */
function getClientTimeStamp() {
  currentTime = new Date();
  month = currentTime.getMonth() + 1;
  day = currentTime.getDate();
  year = currentTime.getFullYear();
  return (padLeftZero(month) + "/" + day + "/" + year);
}
function saveComment() {
   
	var currStatus = dwr.util.getValue('currStatus');
	  if(currStatus == "COMPLETED")
		{
			alert("Cannot Save the Comment!! \nCurrent Status is COMPLETED");
			dwr.util.setValue("comment","");
			return false;
		}
	  if(currStatus == "CANCELED")
		{
			alert("Cannot Save the Comment!! \nCurrent Status is CANCELED");
			dwr.util.setValue("comment","");
			return false;
		}
	  if(currStatus == "DENIEDELG" || currStatus == "DENIEDETYP" || currStatus == "DENIEDOTHR")
		{
			alert("Cannot Save the Comment!! \nCurrent Status is DENIED");
			dwr.util.setValue("comment","");
			return false;
		}
	var val = dwr.util.getValue("comment").trim();
	/**IFOX-00429319 START*/
	if(val.length == 0){
    	alert("Comments Should Not Be Blank Or Space.");
		return;
    }
	/**IFOX-00429319 END*/
	if (val.length > 255) {
	    alert("Comment length > 255 please reduce size of comment");
		return;
    }
    
	try {
		FacadeManager.getTimeStamp('yyyy-MM-dd-HH.mm.ss.SSS000', {
		  			callback:function(data) {
						setComment(data);
					}});
	} catch(e) {
		document.body.style.cursor = 'default';
		alert("Error: "+e.message);
		}
/*	applId = dwr.util.getValue("applId");
    val = dwr.util.getValue("comment");
    
	if(applId == ""){
		  alert("Can't save a comment until application Id is generated");
		  return false;
	  }
	 if(val == ""){
		  alert("Please enter comment");
		  return false;
	  }
	 
		setComment();
	
	document.body.className = 'wait';
	document.eemApplForm.method.value = 'applCommentsUpdate';
	document.eemApplForm.submit();*/

}
function addComment() {
	  ctl = document.getElementById('note');
	  ctl.style.display = "none";
	  var ele = document.getElementById('divComment');
	  ele.style.display = '';
	  document.getElementById('comment').value = "";
	  document.getElementById('comment').focus();
	  indicator('C');
	  document.getElementById("preSet").selectedIndex = 0;
	 // var ele = document.getElementById('divComment');
	 // ele.style.display = '';
	 // document.getElementById('comment').focus();
	}
/*function setComment(data) {
	 val = dwr.util.getValue("comment");
	  if(val!=null || val!=""){
	  if (val.length > 500) {
	    alert("Comment length > 500 please reduce size of comment");
	    return false;
	  }
	  }
	 
	  data = " ";
	  tbl = document.getElementById('divCommentTbl');
	  content = tbl.innerHTML;
	  val=val.replace("'","^");
	  addOn = "<tr><td class='oddRow'>" + data + "</td>" +
	              "<td class='oddRow'>" + dwr.util.getValue('operId') + "</td>" +
	              "<td class='oddRow'>" + val + "</td></tr>" +
	              "<input type='hidden' name='commentRows' value='" + 
	              data + "|" + dwr.util.getValue('operId') + "|" + val + "'/>" +
	              "<input type='hidden' name='insertRows' value='Y'/>" ;
	  addOn=addOn.replace("^","'");
	  tbl.innerHTML = content.replace("</TR>", "</TR>" + addOn);
	  var temp=dwr.util.getValue('commentRows');
	  temp=temp.replace("^","'");
	  dwr.util.setValue('commentRows',temp);
	  var ele = document.getElementById('divComment');
	  ele.style.display = 'none';
	 // dwr.util.setValue("comment", "");
	  return true;
}*/
function setComment(data) {
	
	  val = dwr.util.getValue("comment");
	  if (val.length > 255) {
	    alert("Comment length > 255 please reduce size of comment");
	  }
	 
	  tbl = document.getElementById('divCommentTbl');
	  content = tbl.innerHTML;
	
	  
	  addOn = "<tr><td class='oddRow'>" + data + "</td>" +
	              "<td class='oddRow'>" + dwr.util.getValue('operId') + "</td>" +
	              //IFOX-00420961 Comments  truncation :start
	              "<td class='oddRow' style='word-wrap: break-word'>" + val + "</td></tr>" +
	             /* "<input type='hidden' name='commentRows' value='" + ; 
	              data + "|" + dwr.util.getValue('operId') + "|" + val + "'/>" +
	              "<input type='hidden' name='insertRows' value='Y'/>" ;*/
	  "<input type='hidden' name='commentRows' value=\"" +            // Change value property to use double quotes.
      data + "|" + dwr.util.getValue('operId') + "|" + val + "\"/>" + // This allows for single quote to be entered into the comment.
      "<input type='hidden' name='insertRows' value='Y'/>" ;
	  //IFOX-00420961 Comments  truncation :end
	   //Chr;ome Issue fix- Start  , IFOX-00408591
	  //tbl.innerHTML = content.replace("</TR>", "</TR>" + addOn);
	  tbl.innerHTML = content.replace("</tr>", "</tr>" + addOn);
/*// IE11 Issue Start 2	  
if(window.location.hash = !!window.MSInputMethodContext){
		  
		  tbl.innerHTML = content.replace("</tr>", "</TR>" + addOn);
	  }
// IE11 Issue End 2	  
*/	 
	//Chrome Issue fix- End
	  var ele = document.getElementById('divComment');
	  ele.style.display = 'none';
	  dwr.util.setValue("comment", "");
}

/* Update Application */
function setApprovals() {
  var val = dwr.util.getValue("setAllStatus");
  if(val != "") {
	dwr.util.setValue("statusNPD", val);
	dwr.util.setValue("statusNMA", val);
	dwr.util.setValue("statusCPD", val);
	dwr.util.setValue("statusCMA", val);
  }
}

function updateApprovals() {
	alert("Record(s) are updated.");
}

function cancelApprovals() {
  dwr.util.setValue("statusNPD", "");
  dwr.util.setValue("statusNMA", "");
  dwr.util.setValue("statusCPD", "");
  dwr.util.setValue("statusCMA", "");
}
//IFOX-00395242 - viewPdf-- start
var popUpWindow = null;
function viewPdf(customerId, primaryId){
	//alert("in pdf method");
	var winWidth;
    var winHeight;
    var winLeft;
    var winTop;
    applId = dwr.util.getValue('applId');
    if(applId==""){
        alert("No Application Id generated");
        return;
    }
    
	if(isPopUpOpened(popUpWindow)) {
		popUpWindow.focus();
    } else {
		winWidth = 930;
       	winHeight = 640;
       	winTop = 25;
       	winLeft = ((screen.width - 15) - winWidth) / 2;
       	var url = '/eemAction.do?method=viewPdf&customerId='+customerId+'&primaryId='+primaryId;
       	//alert("URL --> "+url);
		popUpWindow = window.open(url, 'viewPdf', "location=no,menubar=no,scrollbars=yes,resizable=yes,left=" + winLeft + ",top=" + winTop + ",width=" + winWidth + ",height=" + winHeight);
	}
}
function isPopUpOpened(win){
	if (win != null)
		if (win.closed == false)
			return true;
	return false;
}
//IFOX-00395242 - viewPdf-- end
/**UseCaseName 015_Highmark_SUC_Denials for Enrollment and Disenrollment - Start  */
//The function is updated to handle Defect #3 Hometown
function showDenial(){
	var curStatus=dwr.util.getValue('currStatus');
	 if (curStatus == 'COMPLETED'|| curStatus == 'DENIEDELG'||curStatus == 'DENIEDETYP'||curStatus == 'DENIEDOTHR' || curStatus == 'CANCELED') {
		  	alert("Denial not allowed for COMPLETED or DENIED or CANCELED Application");
		  	return;
	   }
	 //alert("showDenial");
	 
	 var applStatusListV=document.getElementById('applStatusList');
	 var siblingApplStatusListV;
	 if(applStatusListV !=undefined){
		 siblingApplStatusListV= applStatusListV.nextSibling;
		 //alert("siblingApplStatusListV:"+siblingApplStatusListV.nodeName); 
	 }
	 var denialStatusListV=document.getElementById('denialStatusList');
	 var denialSegV=document.getElementById('denialSeg');
	 var rejectV=document.getElementById('reject');
	 
	 if(applStatusListV !=undefined && siblingApplStatusListV!=undefined){
		 applStatusListV.style.display="none";
		 applStatusListV.className="";
		 //alert("siblingApplStatusListV.style.display:"+siblingApplStatusListV.style.display);
		 siblingApplStatusListV.style.display="none";
	 }
	 if(denialStatusListV !=undefined){
		 denialStatusListV.style.width="100px";
		 denialStatusListV.value='';
		 denialStatusListV.style.display="";
		 denialStatusListC= denialStatusListV.classList;
		 if(!denialStatusListC.contains("dropdown")){
			 $('#denialStatusList').addClass("dropdown").select2();
		 }
	 }
	 if(denialSegV !=undefined){
		 denialSegV.style.display="";
		 denialSegC= denialStatusListV.classList;
		 if(!denialSegC.contains("dropdown2")){
			 denialSegC.add("dropdown2");
		 }if(!denialSegC.contains("dropdown")){
			 denialSegC.add("dropdown");
		 }
	 }if(rejectV !=undefined){
		 rejectV.style.display="none";
		 rejectV.className="";
	 }
	window.scrollTo(0,2600);
	dwr.util.setValue("btnClicked","denial");
	//IFOX - 431608 : CMS Changes 2020 - start
	setDenialReasonList();
	//IFOX - 431608 : CMS Changes 2020 - end
	}
function isPastDate(dateValue)
{	var date=new Date();
	var curDate = new Date((date.getMonth()+1)+"/"+date.getDate()+"/"+date.getYear());	
	var inputDate = new Date(dateValue);
	if(curDate>inputDate){
		return true;
	}
	else{
		return false;
	}
}
/**UseCaseName 015_Highmark_SUC_Denials for Enrollment and Disenrollment - End  */
/**
 * Cambia_PRE_SET Notes-Start
 */
function addPreSet()
{

indicator('P');
document.getElementById("preSet").selectedIndex = 0;
setIdValue('preSetNoteM',"");
setIdValue('preSetNoteDescr',"");
var ctl;	
ctl = document.getElementsByName('radioCheck');
var len = ctl.length;
for (var i = 0; i <len; i++) {
if (ctl[i].checked) {
ctl[i].checked=false;
}

}   

ctl = document.getElementById('divComment');
ctl.style.display = "none";
ctl = document.getElementById('note');
ctl.style.display = "";


} 
function result(){
var presetnote = dwr.util.getValue('preSetNoteM');
var presetnotedesc = dwr.util.getValue('preSetNoteDescr');
preSetNoteSubmit(presetnote,presetnotedesc);
}

function radioSelect(field)
{
if(field=="A")
{
var a = document.getElementById('drop');
a.disabled = true;
var ctl = document.getElementById('preSetNotMe');
ctl.contentEditable=true;
ctl= document.getElementById('preSetNoteDescr');
ctl.contentEditable=true;
setIdValue('preSetNoteM',"");
setIdValue('preSetNoteDescr',"");
result();
}

if(field=="M"){
var a = document.getElementById('drop');
a.disabled = false;
var x =  document.getElementById('preSet');
var str = x.options[x.selectedIndex].value;
if (str==null || str=="")
{
setIdValue('preSetNote',"");
setIdValue('preSetNoteDescr',"");
alert("Please select a value from dropdown to be modified");
var ctl = document.getElementById('preSetNoteM');
ctl.contentEditable=false;
ctl= document.getElementById('preSetNoteDescr');
ctl.contentEditable=false;
}
else{
var ctl = document.getElementById('preSetNoteM');
ctl.contentEditable=true;
ctl= document.getElementById('preSetNoteDescr');
ctl.contentEditable=true;
}

result();

}
if(field=="D"){
var a = document.getElementById('drop');
a.disabled = false;
var ctl = document.getElementById('preSetNoteM');
ctl.contentEditable=false;
ctl= document.getElementById('preSetNoteDescr');
ctl.contentEditable=false;

result();
}
}

function preFields(slctCtl)
{
var ctl1 = document.getElementById('preSetNoteM');
var e =  document.getElementById('preSet');
var status = slctCtl.options[slctCtl.options.selectedIndex].innerHTML;
ctl1.value = status;
var ctl =document.getElementById('preSetNoteDescr');
var status1 = slctCtl.options[slctCtl.options.selectedIndex].value;
ctl.value = status1;


}
function validateRadioSelect()
{
var ctl = document.getElementsByName('radioCheck');
var len = ctl.length;
var chosen = null;
var i;

for ( i = 0; i <len; i++) {
if (ctl[i].checked) {
chosen = ctl[i].value;
}
}

if (chosen == null) {
alert("No Radio Button Chosen");
return false;
}
return true;
}

function validateFields()
{
var x=document.getElementById('preSetNoteM').value;
if (x==null || x=="")
{
alert("Preset note cannot be blank");
return false;
}
x= document.getElementById('preSetNoteDescr').value;
if (x==null || x=="")
{
alert("Preset note description cannot be blank");
return false;
}
return true;
}   
function checkDropdownEvent(slct) {
var e =dwr.util.getValue('ind');
if(e=="C"){
preSetNoteDescription(slct);
}
else{
preFields(slct);
var ctl = document.getElementsByName('radioCheck');
var len = ctl.length;
var chosen = null;

for (var i = 0; i <len; i++) {
if (ctl[i].checked) {
chosen = ctl[i].value;
if(chosen=="M"){
radioSelect('M');
}
}
}

}
} 

function preSetNoteDescription(slctCtl){

	var ctl = document.getElementById('comment');
	var status = "";
	var strValue = slctCtl.options[slctCtl.selectedIndex].text;
	//var ctl = document.getElementById('displayComment.mbrComments');
	if(Ltrim(Rtrim(slctCtl.value)) == Ltrim(Rtrim(strValue))){
		status = slctCtl.value;
	}
	else{
		status = strValue + " : " + slctCtl.value;
	}
	//var status =  ": " + slctCtl.options[slctCtl.options.selectedIndex].value;
	ctl.value = status +" : ";
	ctl.focus();	

}


function preSetNoteSubmit(presetnote,presetnotedesc)
{
	dwr.util.setValue('preSetNoteM',presetnote);
	dwr.util.setValue('preSetNoteDescr',presetnotedesc);
	
	}
function indicator(option)
{

 dwr.util.setValue('ind',option);


}

function validateComments() {

 var a = validateFields();
   if(a ==false){
  return false;
  }
  var b = validateRadioSelect();
  if(b ==false){
  return false;
  }
	return true;
}

function preSetUpdate()
{
	var currStatus = dwr.util.getValue('currStatus');
	  if(currStatus == "COMPLETED")
		{
			alert("Cannot Save the Application!! \nCurrent Status is COMPLETED");
			return false;
		}
	  if(currStatus == "CANCELED")
		{
			alert("Cannot Save the Application!! \nCurrent Status is CANCELED");
			return false;
		}
	  if(currStatus == "DENIEDELG" || currStatus == "DENIEDETYP" || currStatus == "DENIEDOTHR")
		{
			alert("Cannot Save the Application!! \nCurrent Status is DENIED");
			return false;
		}
	var applId = document.getElementById('applId').value;
	if(applId == ""){
		alert("Cannot Add/Modify/Delete a preset value with out the Application Id");
		return false;	
	}
	var currStatus = dwr.util.getValue('currStatus');
//	var cStatus = document.getElementById('cStatus').value();
		if(currStatus == "COMPLETED")
			{
				alert("Cannot Save the Application!! \n Current Status is COMPLETED");
				return false;
			}
		if(currStatus == "CANCELED")
		{
			alert("Cannot Save the Application!! \n Current Status is CANCELED");
			return false;
		}
		if(currStatus == "DENIEDELG" || currStatus == "DENIEDETYP" || currStatus == "DENIEDOTHR")
		{
			alert("Cannot Update the Application!! \nCurrent Status is DENIED");
		return false;	
	}
	var x = validateComments();
     if(x==true){
    	var preSetDesc = document.getElementById('preSet'); 
     	var preSetValue = preSetDesc.options[preSetDesc.selectedIndex].text;
     	
     	document.getElementById('preSetKey').value = preSetValue;
		document.body.ClassName="wait";
		document.eemApplForm.method.value = "preSetUpdate";
		document.eemApplForm.submit();
}
	
	
	}

/**
 * Cambia_PRE_SET Notes-End
 */
//Cambia_OEVProcess-Start
function setOev(){
	//alert("in setOev");
	eemOevWin = null;
    applId = dwr.util.getValue('applId');
	reqDtCov = dwr.util.getValue('reqDtCov');
	signDt = dwr.util.getValue('signDt');
	applDate = dwr.util.getValue('applDate');
	if(applDate == ""){
		alert("Application Date required");
		return false;
	}
	if(reqDtCov == ""){
		alert("Requested Date of Coverage required");
		return false;
	}
		
	if(signDt == ""){
		alert("Signature Date required");
		return false;
	}

	var group = dwr.util.getValue('enrollGroup');
	//alert("3"+enrollGroup);
	if(group=='')
		group=dwr.util.getValue('enrollGroup');
	//alert("4"+group);
		//alert("before");
	if(dwr.util.getValue('enrollPlanDesgn')==''||dwr.util.getValue('enrollPlanDesgn')==null||dwr.util.getValue('enrollPlan')==''||dwr.util.getValue('enrollPlan')==null){
		//var a = document.getElementById('enrollPlanDesgn').value;
		//alert(a);
		alert("No Script");
	}
	else{
		//alert(dwr.util.getValue('enrollPlan'));
		args = "&gender="+dwr.util.getValue('mbrGender')+"&electionDt="+dwr.util.getValue('electionDt')+"&electionType="+dwr.util.getValue('electionType')+"&planDesgn="+dwr.util.getValue('enrollPlanDesgn')+"&applDate="+dwr.util.getValue('applDate')+"&signDt="+dwr.util.getValue('signDt')+"&pbpId="+dwr.util.getValue('enrollPbp')+"&planName="+dwr.util.getValue('enrollProdName')+"&plan="+dwr.util.getValue('enrollPlan')+"&memberFirst="+dwr.util.getValue("mbrFirstName")+"&mbrLast="+dwr.util.getValue("mbrLastName")+"&cancelDate="+dwr.util.getValue("reqDtCov")+"&applId="+applId+"&group="+group;
		//alert(dwr.util.getValue('applId'));
		openOev(args);
	}
}
eemOevWin = null;

function openOev(args){
	//alert("in open oev");
	url = "/eemAction.do?method=oevScript";
	//alert(url);
	url = url+"&userId="+dwr.util.getValue("operId")+args;
	//alert(url);
	var ww = 900;
	var wh = 550;
	var wt = 1;
	var wl = ((screen.width - 10) - ww) / 2;
	
	eemOevWin = window.open(url,"applOevScript","toolbar=no,titlebar=0,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,ControlBox=no,width=" + ww + ",height=" + wh + ",left=" + wl + ",top=" + wt);
	eemOevWin.focus();
	
}
//Cambia_OEVProcess-End


/* Agent Broker Lookup functioanlity - Start */
function agencyOnLoad() {
	this.ControlBox = false;
	dwr.util.setValue('signDt', window.opener.getField('reqDtCov'));
}

function setAgencyData(data){
	eemAgencyWin = null;
	args = "";
	openAgencySearch(args);
}

eemAgencyWin=null;
function openAgencySearch(args){
	if (dwr.util.getValue("reqDtCov") == '') {
		alert('Please enter Request Date of Coverage');
		document.getElementsByName('reqDtCov')[0].focus();
		return;
	}
	var lob = dwr.util.getValue("enrollLineOfBusiness");
	if(lob == '' && dwr.util.getValue("lobValidation") == 'Y'){
		alert("Please select a valid product.");
		document.getElementsByName('enrollProdName')[0].focus();
		return;
	}

	url = "/eemAction.do?method=agencySearch&agencySrchMove=first&reqDtCov="+dwr.util.getValue('reqDtCov')+"&enrollLineOfBusiness="+lob;	
	var wl = ((screen.width - 10) - 975) / 2;
	eemAgencyWin = window.open(url,"eemApplAgencySearch","toolbar=no,titlebar=0,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,ControlBox=no,width=975,height=700,top=1,left="+wl);
	eemAgencyWin.focus();	
}

function setNewAgencyData(data){
	//alert("123");
	eemAgencyWin = null;
	args = "";
	openNewAgencySearch(args);
}

function openNewAgencySearch(args){
	if (dwr.util.getValue("reqDtCov") == '') {
		alert('Please enter Request Date of Coverage');
		document.getElementsByName('reqDtCov')[0].focus();
		return;
	}
	var lob = dwr.util.getValue("enrollLineOfBusiness");
	if(lob == '' && dwr.util.getValue("lobValidation") == 'Y'){
		alert("Please select a valid product.");
		document.getElementsByName('enrollProdName')[0].focus();
		return;
	}
	url = "/eemAction.do?method=agencySearchNew&agencySrchMove=first&reqDtCov="+dwr.util.getValue('reqDtCov')+"&enrollLineOfBusiness="+lob;	
	var wl = ((screen.width - 10) - 975) / 2;
	eemAgencyWin = window.open(url,"eemApplAgencySearchNew","toolbar=no,titlebar=0,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,ControlBox=no,width=975,height=700,top=1,left="+wl);
	eemAgencyWin.focus();	
}

function searchAgency(move) {
	//var agency = dwr.util.getValue('searchAgencyId');
	//var agencyName = dwr.util.getValue('searchAgencyName');
	/*if((agency != null && agency == "") && (agencyName != null && agencyName == "")){
		alert("Please enter Agency ID or Agency Name");
		return;
	}*/
	document.body.className = 'wait';
	document.eemApplForm.agencySrchMove.value = move;
	document.eemApplForm.method.value = 'agencySearch';
  	document.eemApplForm.submit();
}

function searchAgencyNew(move) {
	//var agency = dwr.util.getValue('searchAgencyId');
	//var agencyName = dwr.util.getValue('searchAgencyName');
	/*if((agency != null && agency == "") && (agencyName != null && agencyName == "")){
		alert("Please enter Agency ID or Agency Name");
		return;
	}*/
	document.body.className = 'wait';
	document.eemApplForm.agencySrchMove.value = move;
	document.eemApplForm.method.value = 'agencySearchNew';
  	document.eemApplForm.submit();
}

function resetAgencySearch() {
	ele = document.getElementsByTagName("input");
	for(var i = 0; i < ele.length; i++) {
		if (ele[i].name.indexOf('search') != -1) {
			ele[i].value = '';
		}
	}
	//Changes for Agent Lookup CR defect 415856: start
	var elements = document.getElementsByTagName('select');
	for (var i = 0; i < elements.length; i++)
	{	if (elements[i].name.indexOf('search') != -1) {
	    elements[i].selectedIndex = 0;
	   }
	}
	//Changes for Agent Lookup CR defect 415856: end
}

function cancelAgencySearch() {
	window.close();
}

function setAgencyHidden(agencyId, agencyName) {
	dwr.util.setValue('hiddAgencyId',agencyId);
	dwr.util.setValue('hiddAgencyName',agencyName);
}

function setAgencyHiddenNew(agencyId, agencyName, agentId, agentType, agentName) {
	dwr.util.setValue('hiddAgencyId',agencyId);
	dwr.util.setValue('hiddAgencyName',agencyName);
	dwr.util.setValue('hiddAgentId',agentId);
	dwr.util.setValue('hiddAgentType',agentType);
	dwr.util.setValue('hiddAgentName',agentName);
}

function populateAgencyValues() {
	agencyId = dwr.util.getValue('hiddAgencyId');
	agencyName = dwr.util.getValue('hiddAgencyName');
	if(agencyName !=null && agencyName != ""){
		agencyName = agencyName.replace("/", "'");
	}
	if(agencyId != null && agencyId != "") {
		window.opener.setAgencyValues(agencyId, agencyName);
		window.opener.setField('isChanged','Y');										
		window.close();
	}
}

function populateAgencyValuesNew() {
	agencyId = dwr.util.getValue('hiddAgencyId');
	agencyName = dwr.util.getValue('hiddAgencyName');
	agentId = dwr.util.getValue('hiddAgentId');
	agentType = dwr.util.getValue('hiddAgentType');
	agentName = dwr.util.getValue('hiddAgentName');
	
	if(agencyName !=null && agencyName != ""){
		agencyName = agencyName.replace("/", "'");
	}
	if(agencyId != null && agencyId != "") {
		window.opener.setAgencyValuesNew(agencyId, agencyName, agentId, agentType,agentName);
		window.opener.setField('isChanged','Y');										
		window.close();
	}
}

function setAgencyValues(agencyId, agencyName){
	value = agencyId+" - "+agencyName;
	dwr.util.setValue('commAgencyId',value);
	dwr.util.setValue('brokerType',"");
}

function setAgencyValuesNew(agencyId, agencyName, agentId, agentType,agentName){
	value = agencyId+" - "+agencyName;
	dwr.util.setValue('commAgencyId',value);
	dwr.util.setValue('brokerType',agentType);
	dwr.util.setValue('brokAgentId',agentId);

	$("#brokerType").select2();
	//$('[name=brokerType]').val(agentType);
	
	$('[name=brokAgentId]').val(agentId+"-"+agentName);

	setAgentValue(agentId,agencyId);
	
}
function setAgentValue(val,agencyID) {
	try {
		
		if (dwr.util.getValue('reqDtCov') != '' && agencyID != '' 
										&& dwr.util.getValue('brokerType') != '') {
			
			FacadeManager.getAgentName(dwr.util.getValue('brokerType'),
					agencyID, dwr.util.getValue('reqDtCov'),'', val, dwr.util.getValue('enrollLineOfBusiness'),{//AAH BasePlus Migration IFOX-00426351 Changes
			  			callback:function(data) {
			  			  replaceOptions(data, 'brokAgentId');
			  			   setSelectedOption(data, 'brokAgentId');					
			  			   setIdValue('brokAgentId',val);
			  			}
			  			});
		}
	} catch(e) {
		document.body.style.cursor = 'default';
		alert("Error: "+e.message);
	}
	
}
/* Agent Broker Lookup functioanlity - End */

/*LEP  Start*/
function lepDateValidate(strtdte,enddte,type){
		var startMsg = "Start Date";
		var endMsg = "End Date";

		if(type === "potential"){
			startMsg = "Uncovered Start date";
			endMsg = "Uncovered End date";
		}else if(type === "attestation"){
			startMsg = "From Date";
			endMsg = "To Date";
		}
		if (strtdte.value == ""){
			alert("Please enter "+startMsg);
			return false;
		}
		if (enddte.value == ""){
			alert("Please enter "+endMsg);
			return false;
		}
		
		if(strtdte.value || enddte.value){
			if (parseDateFld9(strtdte.value,true,true,"DATE: "+strtdte.value,false) == "NaD"){
				return false;
			}
			if (parseDateFld9(enddte.value,true,true,"DATE: "+enddte.value,false) == "NaD"){
				return false;
			}
		}
	    var reqDt = dwr.util.getValue('reqDtCov');
	    var date = new Date();
	    var date1 = new Date(strtdte.value);
		var date2 = new Date(enddte.value);
			 		
			if(!checkFDOM(strtdte,startMsg))
				return false;
			if (!checkLDOM(enddte,endMsg,true))
				return false;
			// commented for 390064 
		/*	if(date1 > date){
				alert(startMsg+" cannot be future date");
				strtdte.focus();
				return false;
			} */
			
			if(dateCompare(strtdte.value,reqDt,true) >= 0){
				alert(startMsg+" cannot be later than the application effective date of coverage.");
				strtdte.focus();
				return false;
			}
			if(dateCompare(enddte.value,reqDt,true) >= 0){
				alert(endMsg+" cannot be later than the application effective date of coverage.");
				enddte.focus();
				return false;
			}
			
			if (date1 > date2) {
				alert(endMsg+" cannot be earlier than the start date");
				date1.focus();
				return false;
			}
			return true;
	}
function checkAppStatus(){
	
	var currStatus = dwr.util.getValue('applStatus');
	
	if(currStatus == "COMPLETED")
	{
		alert("Application Cannot be UPDATED!! \nCurrent Status is COMPLETED");
		return false;
	}
	if(currStatus == "CANCELED")
	{
		alert("Application Cannot be UPDATED!! \nCurrent Status is CANCELED");
		return false;
	}
	if(currStatus == "DENIEDELG" || currStatus == "DENIEDETYP" || currStatus == "DENIEDOTHR")
	{
		alert("Application Cannot be UPDATED!! \nCurrent Status is DENIED");
		return false;
	}
	return true;
}

/*LEP End*/

//fix for issue # 87 start
function isAllFldsEmptyOrFilled(varList){
	var isAllEmpty = false;
	var isAllFilled = false;
	for (i = 0; i < varList.length; i++) {
		var name = varList[i];
	     //check if all are empty or has vals
	     if(dwr.util.getValue(name) === null || dwr.util.getValue(name) == ""){
		if(isAllFilled)
			return false;
		isAllEmpty = true;
	     } else {
		if(isAllEmpty)
			return false;
		isAllFilled = true;
	     }     	

	}
	return true;
}
/** Triple S BasePlus Migration START **/
/* Fix for IFOX-00378075 -- START*/
function validMedicaId() {
	stMedicaidValue= dwr.util.getValue('stMedicaid');
	medicaidIdValue= dwr.util.getValue('medicaidId');
	paramCode = dwr.util.getValue('paramcd');

	var trimmedValue = valueTrim(medicaidIdValue);
	
	if(paramCode == 'Y' && stMedicaidValue =='Y' && trimmedValue == '')
	{
		alert(" Please enter Medicaid ID ");
		document.getElementsByName('medicaidId')[0].value = '';
		document.getElementsByName('medicaidId')[0].focus();
		return false;
	}
	return true;
}

	function valueTrim(x) {
	    return x.replace(/^\s+|\s+$/gm,'');
	}
	/* Fix for IFOX-00378075 -- END*/
	/** Triple S BasePlus Migration END **/
	//fix for issue # 87 end
	function loadingShow(){
		/*document.getElementById('loading').style.display = 'block';
		document.getElementById('loading').style.cursor = 'none';*/
	}
	
	/**AAH BasePlus Migration IFOX-00426351 START*/
	function manageLTCAddlnQuestions(needRefresh){
		//check if questions fields are exist or not
		var q1 = document.getElementsByName('addlQ1');
		
		if(q1 && q1.length >0){
			try {
				if(needRefresh === true){
					//setting broker and LTC details
					setInstLookUp();
					setBrokerAgents();
				}
				var productId = dwr.util.getValue("enrollProduct");
				var covDt = dwr.util.getValue("reqDtCov");
				if(productId == "" || 	covDt == "") {
					return "";
				}
				FacadeManager.getLOBAAHQ(productId,covDt,{
			  			callback:function(data) {
			  				var lob = data;
			  				
			  				dwr.util.setValue('lobAAHQ',lob);
			  				var addlQ1 = document.getElementsByName('addlQ1');
			  				var addlQ2 = document.getElementsByName('addlQ2');
			  				var addlQ3 = document.getElementsByName('addlQ3');
			  				disableSameNameElements(addlQ1,true);
			  				disableSameNameElements(addlQ2,true);
			  				disableSameNameElements(addlQ3,true);
			  				if(lob == 'ISNP'){
			  					disableSameNameElements(addlQ1,false);
			  				} else if(lob == 'DSNP') {
			  					disableSameNameElements(addlQ2,false);
			  				} else if(lob == 'CSNP') {
			  					disableSameNameElements(addlQ3,false);
			  				}		  				   
						}
			  			});
		} catch(e) {
			alert("Error: "+e.message);
		}
	}
	function validateLTCAddlnQuestions(){
		var lob =  dwr.util.getValue('lobAAHQ');
		var que = "";
		if(lob == 'ISNP' && dwr.util.getValue('addlQ1') === false){
			que = "Do you/will you live in a LTC or ALF for more than 90 days?";
		} else if(lob == 'DSNP' && dwr.util.getValue('addlQ2') === false) {
			que = "Do you receive Medical Assistance from the State and have Medicare?";
		} else if(lob == 'CSNP' && dwr.util.getValue('addlQ3') === false) {
			que = "Does applicant have a diagnosis of Dementia?";
		}
		
		if(que != ""){
			alert("Please answer the question :\n"+que);
			return false;
		} 
		
		return true;	
	}
	function disableSameNameElements(eles,disable){
		for (var i = 0; i < eles.length; i++) {
		   eles[i].disabled = disable;
		}
	}
	/**AAH BasePlus Migration IFOX-00426351 END*/
}

	//AAH CR-Start -426569
  function autoPopulateAppDt() {
	/*alert("111");*/
	if (dwr.util.getValue("autopopulateappldt") == 'Y') {
		if (dwr.util.getValue('applDate') == '') {
			dwr.util.setValue('applDate', dwr.util.getValue('receiptDate'));
			return false;
		}
	}
}
//AAH CR-end -426569