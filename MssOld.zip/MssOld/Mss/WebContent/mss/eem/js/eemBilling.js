// $Id: eemBilling.js,v 1.1 2014/06/26 07:56:52 praveen Exp $
function billingSubmit(method) 
{
	document.body.className = 'wait';	
	var frm = document.forms[0];
	frm.method.value = method;
  	frm.submit();
}
function newBillingSearch()
{
	billingSubmit('clearSearch');
}
var eemBillMbrGrpWin = null;
function openBillMbrGrpSearch() {
	
	url = "/eemActionBillInvoice.do?method=billMbrGrpSearch&selectedSubMenuTab=billingInvoice";
	url = url + "&id="+document.getElementsByName("transGrpId")[0].value+"&mbrgrp="+document.getElementsByName("selectedMbrGrpInd")[0].value;

	var ww = 900;
	var wh = 550;
	var wt = 1;
	var wl = ((screen.width - 10) - ww) / 2;
	
	eemBillMbrGrpWin = window.open(url,"MemberGroupSearch","toolbar=no,titlebar=0,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=no,ControlBox=no,width=" + ww + ",height=" + wh + ",left=" + wl + ",top=" + wt);
	eemBillMbrGrpWin.focus();
}
function searchMbrGrp() {
	//TSA-Added for changes in Bill Group Search screen validation :start
	var search1 = document.getElementsByName("searchTransGrp")[0];
	var search2 = document.getElementsByName("searchTransName")[0];
	var search3 = document.getElementsByName("searchTransLastName")[0];
	
	if(search1.value== '' && search2.value =='' && search3.value == ''){
		alert(" Please provide valid search criteria ");
		return false;
	}
	//TSA-Added for changes in Bill Group Search screen validation :end
	document.eemBillInvoiceForm.method.value = 'billMbrGrpSearch';
	document.eemBillInvoiceForm.selectedSubMenuTab.value = 'billingInvoice';
  	document.eemBillInvoiceForm.submit();
}
function resetSearchMbrGrp() {
	ele = document.getElementsByTagName("input");
	for(i = 0; i < ele.length; i++) {
		if (ele[i].name.indexOf('search') != -1) {
			ele[i].value = '';
		}
	}
}
function cancelSearchMbrGrp() {
	window.close();
}
function setMbrGrpHidden(id, name) {
	dwr.util.setValue('hidMbrGrp',id);
	dwr.util.setValue('hidName',name);
}
function populateMbrGrpValues() {
	window.opener.setMbrGrpValues(dwr.util.getValue('hidMbrGrp'), dwr.util.getValue('hidName'));
	window.close();
}
function setMbrGrpValues(id, name) {
	dwr.util.setValue('transGrpId', id);
	setIdValue('transfer.name', name);
	dwr.util.setValue('transName', name);
}
function setMbrGrpName(val) {
	try {
		if (val == "") {
			setMbrGrpValues("","");
			return;
		}
		FacadeManager.getBillMbrGrpName(val,document.getElementsByName("selectedMbrGrpInd")[0].value,{
		  			callback:function(data) {
		  				if (data == null || data == "") {
		  					openBillMbrGrpSearch();
		  					data = "";
		  				} 
		  				setMbrGrpValues(val, data);
					}});
	} catch(e) {
		document.body.style.cursor = 'default';
		alert("Error: "+e.message);
	}
}
function transferAmount() {
	var amt = dwr.util.getValue('transAmt');
	if (dwr.util.getValue('transGrpId') == '') {
		alert("Please enter valid Id");
		document.getElementsByName('transGrpId')[0].focus();
	} else if (amt == '' || parseFloat(amt) <= 0 || parseFloat(amt) > parseFloat(dwr.util.getValue('transDetailAmt'))) {
		alert("Please enter valid transfer amount");
		document.getElementsByName('transAmt')[0].focus();
	} else {
		billingSubmit('billInvoiceTransfer');
	}
}
function transferButtonClick() {
	var row = document.getElementsByName('selectedDetailRow')[0].value;
    var len = arrInvDtl.length;
	if (len > 0) {
	   	if (row < len) {
			var data = arrInvDtl[row];
			var funcCode = data.funcCode;
			var lineStatus = data.lineStatusCd;
			  //TSA Changes:Start
			/*if (funcCode != 'PAY' && funcCode != 'TRT' && funcCode != 'TTM' && funcCode != 'TTG') {*/
			if (funcCode != 'PAY' && funcCode != 'TRT' && funcCode != 'TTM') {
			 //TSA Changes:End
				document.getElementById('transferDetails').style.display = 'none';
				document.getElementsByName('transExpanded')[0].value = false;
				alert("Invalid function Code - " + funcCode);
			} else if (lineStatus != 'A') {
				document.getElementById('transferDetails').style.display = 'none';
				document.getElementsByName('transExpanded')[0].value = false;
				alert("Invalid Line status");
			} else {
				try {
					FacadeManager.getTotalInvoiceDetailAmt(data.customerId, data.invoiceNbr, data.itemNbr,{
					  			callback:function(amt) {
					  				setTransferBox(amt, data, row);
								}});
				} catch(e) {
					document.body.style.cursor = 'default';
					alert("Error: "+e.message);
				}
			}
		}
	}
}

function setTransferBox(amt, data, row) {			
    var detailAmt = parseFloat(amt);

	detailAmt = detailAmt * -1;
	detailAmt = detailAmt.toFixed(2);
	setIdValue('transfer.detailAmt',detailAmt);
	document.getElementsByName('transDetailAmt')[0].value = detailAmt;
	
	//document.getElementsByName("confirmTransfer")[0].disabled = true;
	if (detailAmt <= 0) {
		document.getElementById('transferDetails').style.display = 'none';
		document.getElementsByName('transExpanded')[0].value = false;
		alert("Insufficient funds to transfer");
	} else {
		invoiceDetailSelect(row);
		
		document.getElementsByName("transAmt")[0].value = detailAmt;
		document.getElementsByName("transGrpId")[0].value = "";
		document.getElementsByName("transName")[0].value = "";
		setIdValue('transfer.name',"");
						
		setIdValue('transfer.itemNbr',data.itemNbr);
	    setIdValue('transfer.checkNbr',data.checkNbr);
	    setIdValue('transfer.bankAcctCd',data.bankAccount);
	    setIdValue('transfer.itemNbr',data.itemNbr);
		setIdValue('transfer.itemDesc',data.itemDesc);
		setIdValue('transfer.function',data.funcCode + ' - ' + data.funcDesc);
		setIdValue('transfer.checkNbr',data.checkNbr);
		setIdValue('transfer.detailAmt',detailAmt);
		setIdValue('transfer.payBatchDateFrmt',data.payBatchDateFrmt);
		setIdValue('transfer.payBatchSeqNbr',data.payBatchSeqNbr);
		setIdValue('transfer.payItemNbr',data.payItemNbr);
		setIdValue('transfer.paySourceDesc',data.paySrcDesc);
		
		document.getElementById('transferDetails').style.display = '';
		document.getElementsByName('transExpanded')[0].value = true;
		document.getElementsByName("transGrpId")[0].focus();
	}
}

//IFOX-00400257 : START
function validateInvoiceId(invoice, currentId) {
	if(invoice != "") {
		try {
			var toValidate = invoice;
			FacadeManager.validateInvoiceId(toValidate, {
				callback:function(data) {
					if(!data) {
						alert("Invalid Invoice Id " + toValidate);
						document.getElementById(currentId).value = "";
						document.getElementById(currentId).focus();
					}
				}
			});
		} catch(e) {
			document.body.style.cursor = 'default';
			alert("Error: "+e.message);
		}
	}
}
//IFOX-00400257 : END