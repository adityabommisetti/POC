function displayException() {
	if (dwr.util.getValue('message') != '') {
		alert(dwr.util.getValue('message'));
	}
}
/* Search */
function gotoMbrSearch(supplId, dateRange) {
  dwr.util.setValue('supplId', supplId);
  mbrDshBrdSubmit('gotoMbrSearch');
}
function drillDown(category, user, row) {
  dwr.util.setValue('category', category);
  dwr.util.setValue('user', user);
  mbrDshBrdSubmit('drillDown');
}
function mbrDshBrdSelectTab(tabId) {
  dwr.util.setValue('selectedSubMenuTab', tabId);
  mbrDshBrdSubmit('mbrDshBrdSelectTab');
}
function mbrDshBrdSubmit(method) {
  document.body.className = 'wait';
  document.eemMbrDshBrdForm.method.value = method;
  document.eemMbrDshBrdForm.submit();
}