// $Id: eemEnroll.js,v 1.12 2015/07/17 09:36:16 praveen Exp $
function toggleSearchResults(ctl,id) {

	toggleVisibilityState(ctl,id,document.forms[0].searchExpanded)
}
function enrollTabPageNext()
{
	enrollTabPage('next');
}
function enrollTabPagePrev()
{
	enrollTabPage('previous');
}
function enrollTabPageFirst()
{
	enrollTabPage('first');
}
function enrollTabPage(move)
{
	document.eemEnrollForm.tabPageMove.value = move;
	enrollSubmit(document.eemEnrollForm,"enrollTabPage")
}
function enrollSubmit(form,method)
{
	//document.body.style.cursor = 'wait';	
	document.body.className = 'wait';	
  	form.method.value = method;
  	form.submit();
}
function enrollShowAllClick(mode) {
  	var form = document.forms[0];
  	form.searchShowAll.checked = mode;
	enrollSubmit(form,"enrollShowAll");
}
function enrollSearchClick() {
	enrollSubmit(document.forms[0],"enrollSearch");
}
function enrollSearchPageFirst(ctl) {
	enrollSubmit(document.forms[0],"enrollSearchPageFirst");
}
function enrollSearchPageNext(ctl) {
	enrollSubmit(document.forms[0],"enrollSearchPageNext");
}
function enrollSearchPagePrev(ctl) {
	enrollSubmit(document.forms[0],"enrollSearchPagePrev");
}
function enrollSearchSelect(row) {
  	var form = document.forms[0];
 	form.selectedSearchRow.value = row;
	enrollSubmit(form,"enrollSearchSelect");
}
function newEnrollSearchClick() {
  enrollSubmit(document.eemEnrollForm,"enrollClearSearch");
  return;
  
  document.getElementById("eemEnrollSearchResultsDiv").style.display = "none";
  document.getElementById("eemEnrollMemberDetailsDiv").style.display = "none";
  
  document.eemEnrollForm.searchMemberId.value = '';
  document.eemEnrollForm.searchHicNo.value = '';
  document.eemEnrollForm.searchSSN.value = '';
  document.eemEnrollForm.searchSupplementalId.value = '';
  document.eemEnrollForm.searchLastName.value = '';
//IFOX-00424860 - New member search fields :start
  document.eemEnrollForm.searchFirstName.value = '';
  document.eemEnrollForm.searchDob.value = '';
//IFOX-00424860 - New member search fields :end
  document.eemEnrollForm.searchEffectiveMonthFrmt.value = '';
  
  enrollSubmit(form,"enrollClearSearch");
  
}
function enrollUpdateClick() {

	/**
	 * Cambia_Member Cancellation-Start
	 */
	if(dwr.util.getValue('displayEnrollment.buttonClicked')=="cancelEnrollment")
		updateCancel();
	
	/**
	 * Cambia_Member Cancellation-End
	 */
	var isChanged = "false";
	var isValidated = false;
	var form = document.forms[0]; 
	//LEP Maximus popup error fix - Start
	var ctl1 = document.getElementById("lepInfoChanged").value;
	//LEP Maximus popup error fix - End
	var tab = form.selectedMemberTab.value;
	switch (tab) {
  	
		case "demographic": isChanged = form.demographicChanged.value; break;
	    case "enrollment" : isChanged = form.enrollmentChanged.value;  break;
	    case "dsinfo"     : isChanged = form.dsInfoChanged.value;      break;
	    case "lisinfo"    : isChanged = form.lisInfoChanged.value;     break;
	  //LEP Maximus popup error fix - Start
	    //case "lepinfo"    : isChanged = form.lepInfoChanged.value;     break;
	    case "lepinfo"    : isChanged = ctl1;     break; 
	  //LEP Maximus popup error fix - End
	    case "address"    : isChanged = form.addressChanged.value;     break;
    	case "letters"    : isChanged = form.letterChanged.value;      break;
    	case "pcpinfo"    : isChanged = form.pcpInfoChanged.value;     break;
    	//IFOX-00399921 LTC Tab. START
    	case "ltcinfo"    : isChanged = form.ltcInfoChanged.value;     break;
    	//IFOX-00399921 LTC Tab. END
    	case "comments"   : isChanged = form.commentChanged.value;     break;
    	case "errors"     : isChanged = form.errorChanged.value;       break;
    	case "trrlogs"    : isChanged = form.trrLogChanged.value;      break;
    	case "agent"      : isChanged = form.agentChanged.value;       break;
    	case "cob"        : isChanged = form.cobChanged.value;         break;
    	case "billing"    : isChanged = form.billingChanged.value;     break;
    	
    	case "ases"       : isChanged = form.asesChanged.value;     break;//Ases CR Tab Added
    	/**
         * 033_Highmark_SUC_OOASCCproces - Start
         */
    	case "ooa"        : isChanged = form.ooaChanged.value;         break;
    	/**

         * 033_Highmark_SUC_OOASCCproces  - End
         */
    	/**
    	 * cambia pos start
    	 */
    	
    	case "pos"        : isChanged = form.poseditChanged.value;     break;
    	/**
    	 * cambia pos end
    	 */
    }
 
    if (isChanged != "true") {
  		alert("NO FIELDS UPDATED");
	  	return false;
	}    
  	switch (tab) {
		case "demographic": isValidated = validateDemographic();break;
	    case "enrollment" : isValidated = validateEnrollment();	break;
	    case "dsinfo"     : isValidated = validateDsInfo(); 	break;
	    case "lisinfo"    : isValidated = validateLisInfo(); 	break;
	    case "lepinfo"    : isValidated = validateLepInfo(); 	break;
	    case "address"    : isValidated = validateAddress(); 	break;
    	case "letters"    : isValidated = true; 				break;
    	case "pcpinfo"    : isValidated = validatePcpInfo();	break;
    	//IFOX-00399921 LTC Tab. START
    	case "ltcinfo"    : isValidated = validateLtcInfo();	break;
    	//IFOX-00399921 LTC Tab. END
    	
    	//Issue fixed for not able to add comments 
    	case "comments"   : isValidated = validateComments1(); 	break;
    	// Issue fixed for not able to add comments 
    	case "errors"     : isValidated = true; 				break;
    	case "trrlogs"    : isValidated = true; 				break;
    	case "agent"      : isValidated = validateAgent();		break;
    	case "cob"        : isValidated = validateCob();		break;
    	case "billing"    : isValidated = validateBilling();	break;
    	
    	case "ases"       : isValidated = validateAses();	break;//Ases CR tab Added
    	/**
         * 033_Highmark_SUC_OOASCCproces - Start
         */
    	case "ooa"        : isValidated = validateOoaInfo();    break;
    	/**
         * 033_Highmark_SUC_OOASCCproces - End
         */
    	/**
    	 * Cambia_OEVProcess-Start
    	 */
    	case "oev"         : isChanged = form.oevInfoChanged.value;    break;
    	/**
    	 * Cambia_OEVProcess-Start
    	 */
    	/**
    	 * cambia pos start
    	 */
    	
    	case "pos"        :  isValidated = validatePosInfo();     break;
    	/**
    	 * cambia pos end
    	 */
    }

    if (isValidated) {
		enrollSubmit(form,"enrollUpdate");
		return true;
	}
}
function deleteSegment(chkId) {
   var msg = confirm("Are you sure you want to Delete");
   if(msg) {
		var ctl;	
		ctl = document.getElementById(chkId);
		if (ctl.style.display == "none") {
			alert("You are currently entering a segment\n\nPlease select an item to delete");
			return false;
		}
		enrollSubmit(document.forms[0],"enrollDelete");
   } 
	return true;
}
function doDateChange(ctl,allowNines,tab) {
	//alert('doDateChange');
    var rslt = parseDateFld9(ctl.value,false,true,"",allowNines);
    if (rslt != "NaD")
        ctl.value = rslt;
	onChangeTabData(tab);
}
function doUpperCase(ctl)
{
	ctl.value = Rtrim(ctl.value).toUpperCase();
}
function onChangeTabDataUpperCase(ctl,tab) 
{
	ctl.value = Rtrim(ctl.value).toUpperCase();
	onChangeTabData(tab);
}
function onChangeTabData(tab) {
	//alert('onChangeTabData:'+tab);
	var form = document.forms[0];
	//LEP maximus popup error fix - Start
	var ctl = document.getElementById("lepInfoChanged");
	//LEP maximus popup error fix - End
  	switch (tab) {
		case "demographic": form.demographicChanged.value = "true"; break;
	    case "enrollment" : form.enrollmentChanged.value  = "true"; break;
	    case "dsinfo"     : form.dsInfoChanged.value      = "true"; break;
	    case "lisinfo"    : form.lisInfoChanged.value     = "true"; break;
	  //LEP maximus popup error fix - Start
	   // case "lepinfo"    : form.lepInfoChanged.value     = "true"; break;
	    case "lepinfo"    : ctl.value     = "true"; break;
	  //LEP maximus popup error fix - End
	    case "address"    : form.addressChanged.value     = "true"; break;
    	case "letters"    : form.letterChanged.value      = "true"; break;
    	case "pcpinfo"    : form.pcpInfoChanged.value     = "true"; break;
    	//IFOX-00399921 LTC Tab. START
    	case "ltcinfo"    : form.ltcInfoChanged.value     = "true"; break;
    	//IFOX-00399921 LTC Tab. END
    	case "comments"   : form.commentChanged.value     = "true"; break;
    	case "errors"     : form.errorChanged.value       = "true"; break;
    	case "trrlogs"    : form.trrLogChanged.value      = "true"; break;
    	case "agent"      : form.agentChanged.value       = "true"; break;
    	case "cob"        : form.cobChanged.value         = "true"; break;
    	case "billing"    : form.billingChanged.value     = "true"; break;
    	case "ases"       : form.asesChanged.value     	  = "true"; break;//Ases CR tab Added
    	
    	
    	
    	/**
    	 * 033_Highmark_SUC_OOASCCproces - Start
    	 */
        	case "ooa"        : form.ooaChanged.value         ="true"; break;
        	
       /**
          * 033_Highmark_SUC_OOASCCproces - End
         */
        	/**
        	 * cambia pos start
        	 */
        	
        	case "pos"        : form.poseditChanged.value = "true";break;
        	/**
        	 * cambia pos end
        	 */
        	//alert('onChangeTabData2:'+tab);
    }
}
/**
 * Cambia_PRE-SET NOTES - Start
 */ 




function preSetNoteSubmit(presetnote,presetnotedesc)
{
	
	
	document.eemEnrollForm.preSetNote.value = presetnote;

	document.eemEnrollForm.preSetNoteDesc.value = presetnotedesc;
	
	}


function printIDCard(sourceCity, sourceState, sourceZip5, sourceZip4,sourceCounty) {
	//alert("in printIDCard::::"+sourceCounty);
	//alert(sourceState)
	url = "/mss/eem/jsp/eemPrintIDCard.jsp";
	url = url + 	"?planId="+dwr.util.getValue("dispEnrollment.planId")+
					"&pbpId="+dwr.util.getValue("dispEnrollment.pbpId")+
					"&planDesignation="+dwr.util.getValue("dispEnrollment.planDesignation")+
					"&effStartDateFrmt="+dwr.util.getValue("dispEnrollment.effStartDateFrmt")+
					"&memberId="+dwr.util.getValue("displayDemographic.memberId");
	//alert(url);
	
	var ww = 900;
	var wh = 550;
	var wt = 1;
	var wl = ((screen.width - 10) - ww) / 2;
	
	eemZipWin = window.open(url,"Print ID Card","toolbar=no,titlebar=0,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,ControlBox=no,width=" + ww + ",height=" + wh + ",left=" + wl + ",top=" + wt);
	eemZipWin.focus();
}



/**
 * Cambia_PRE-SET NOTES - End
 */ 
function cancelEnrollment(){

	var enrollStatus = document.getElementById('displayEnrollment.enrollStatus').value;
	var data = arrEnrollment[document.getElementsByName('selectedEnrollmentRow')[0].value];		
	//alert("data :"+data);
	var startDate = document.getElementById("displayEnrollment.effStartDateFrmt").value;
	var curEnrolEffStartDate = document.getElementById("curEnrolEffStartDate").value;

	
	var enrollReasonCd = data.enrollReasonCd;
	//alert("enrollStatus>"+enrollStatus+" :enrollReasonCd>"+enrollReasonCd+" :startDate"+startDate+" :curEnrolEffStartDate>"+curEnrolEffStartDate);
	//alert(!isStartDateBeforeCurDate());
	// As per Nataraj comments removing this block for IFOX ticket 00357792
	/*if(((enrollStatus == 'EAPRV'||enrollStatus == 'DAPRV') && enrollReasonCd == 'CMSAPRV') && !isStartDateBeforeCurDate() && curEnrolEffStartDate == startDate){
		alert("Cancellation not allowed with the Current Member");
			return true;
	}*/
	

		
			onChangeTabData('enrollment');
			setIdValue('displayEnrollment.buttonClicked','cancelEnrollment');
		
			document.getElementById("enrollCancel").style.display="";
			
			document.getElementById("enrollDisplay").style.display="none";
			document.getElementById("enrollEntry").style.display="none";		
			
			document.getElementById("enrollmentDisplayState").value = "CANCELENROLL";
		
			var len = arrEnrollment.length;
			var row = document.getElementById('selectedEnrollmentRow').value;		
			if (len > 0) {
			   	if (row < len) {
			   		var data = arrEnrollment[row];
			   		//alert("data.enrollReasonCd"+data.enrollStatus);

		    		setIdValue('displayEnrollment.createTime','');
		    		setIdValue('displayEnrollment.frmtCreateTime','');
		    		setIdValue('displayEnrollment.createUserId','');
		    		setIdValue('displayEnrollment.lastUpdtTime','');
		    		setIdValue('displayEnrollment.frmtLastUpdtTime','');
		    		setIdValue('displayEnrollment.lastUpdtUserId','');

		    		setIdValue('displayEnrollment.effStartDateFrmt',data.effStartDateFrmt,{escapeHtml:false});	    		
		    		setIdValue('displayEnrollment.effEndDateFrmt',data.effEndDateFrmt,{escapeHtml:false});
		    		setIdValue('displayEnrollment.overrideInd',data.overrideInd);
		    		
		    		setIdValue('displayEnrollment.grpId',data.grpId);
		    		setIdValue('displayEnrollment.groupName',data.groupName);
		    		setIdValue('displayEnrollment.productId',data.productId);
		    		setIdValue('displayEnrollment.productName',data.productName);

		    		setIdValue('displayEnrollment.supplementalId',data.supplementalId);

		    		setIdValue('displayEnrollment.planId',data.planId);
		    		setIdValue('displayEnrollment.pbpId',data.pbpId);
		    		setIdValue('displayEnrollment.pbpSegmentId',data.pbpSegmentId);
		    		setIdValue('displayEnrollment.planType',data.planType);
		    		setIdValue('displayEnrollment.enrollSrceCd',data.enrollSrceCd);
		    		setIdValue('displayEnrollmentEntry.planType',data.planType);
		    		setIdValue('displayEnrollment.planDesignation',data.planDesignation);
		    		setIdValue('displayEnrollmentEntry.planDesignation',data.planDesignation);

		    		setIdValue('displayEnrollment.electionTypeCd',data.electionTypeCd);
		    		setIdValue('displayEnrollment.sepElectionDateFrmt',data.sepElectionDateFrmt); 
		    		setIdValue('displayEnrollment.sepReasonCd',data.sepReasonCd); 
		    		setIdValue('displayEnrollment.elcDerivedInd',data.elcDerivedInd); 
					// do not copy override ind
					var ctl = document.getElementsByName('displayEnrollment.editOverrideInd')[0];
					ctl.checked = false;

		    		setIdValue('displayEnrollment.umiId',data.umiId);
		    		setIdValue('displayEnrollment.applicationDateFrmt',data.applicationDateFrmt);
		    		setIdValue('displayEnrollment.signatureDateFrmt',data.signatureDateFrmt);
		    		
					setIdValue('displayEnrollment.disReasonCd',data.disReasonCd); 
					//addedd for lumeris plan reason code
					setIdValue('displayEnrollment.planReasonCd',data.planReasonCd); 
					setIdValue('displayEnrollment.enrollSourceCd',data.enrollSourceCd);
					
					setIdValue('displayEnrollment.applicationId',data.applicationId);
					 
		    		setIdValue('displayEnrollment.enrollStatus',data.enrollStatus);
		    		//setStatusReason(data.enrollStatus,data.enrollReasonCd);
		    		//setIdValue('displayEnrollment.enrollReasonCd',data.enrollReasonCd);
		    		setStatusReason(data.enrollStatus,'');
		    		
		    		//new fields for Cancellation
		    		setIdValue('displayEnrollment.receivedDateFrmt',data.receivedDateFrmt);
		    		setIdValue('displayEnrollment.cancellationReason',data.cancellationReason);
		    		
		   			
		    	}
			}
				
	//	}
		else{
		
			alert("Enrollment pending or Disenrollment pending or Cancellation is not allowed");
			return false;
		}
		
		
	}
	function updateCancel(){
		
		// document.getElementsByName('displayEnrollment.effStartDateFrmt')[0].value = document.getElementById("effStartDateFrmt_cancel").value;	 
		// document.getElementsByName('displayEnrollment.effEndDateFrmt')[0].value = document.getElementById("effEndDateFrmt_cancel").value;
		 document.getElementsByName('displayEnrollment.receivedDateFrmt')[0].value = document.getElementById("receivedDateFrmt_cancel").value; 	 
		 document.getElementsByName('displayEnrollment.cancellationReason')[0].value = document.getElementById("displayEnrollment.cancellationReasonCancel").value;
		}
	function isStartDateBeforeCurDate()
	{
		
		var now = new Date();	
		var curdate = new Date((now.getMonth()+1)+'/'+now.getDate()+'/'+now.getFullYear());
		var startdate = new Date(document.getElementById("displayEnrollment.effStartDateFrmt").value);
		
		if((startdate-curdate)>0)
			return true;
		else
			return false;
	}
	
	/* Agent Broker Lookup functioanlity - Start */
	function enrollAgencyOnLoad() {
		this.ControlBox = false;
		//dwr.util.setValue('signDt', window.opener.getField('displayAgent.frmtEffStartDate'));
	}

	function setEnrollAgencyData(data){
	//New Agent Browser issue fix : start
	//	document.getElementById('agentText').style.display = '';
	//	document.getElementById('agentSel').style.display = 'none';
	//New Agent Browser issue fix : end
		eemEnrollAgencyWin = null;
		args = "";
		openEnrollAgencySearch(args);
	}
	
	function setNewEnrollAgencyData(data){
		eemEnrollAgencyWin = null;
		args = "";
		openNewEnrollAgencySearch(args);
	}

	eemEnrollAgencyWin=null;
	function openEnrollAgencySearch(args){
		var agentEffDate = dwr.util.getValue('displayAgent.frmtEffStartDate');
		if (agentEffDate == '') {
			alert('Please enter Effective Start Date');
			document.getElementsByName('displayAgent.frmtEffStartDate')[0].focus();
			return;
		}

		url = "/eemActionEnroll.do?method=enrollAgencySearch&agencySrchMove=first" +
				"&lineOfBusiness="+dwr.util.getValue('lineOfBusiness')+"&agentEffDate="+agentEffDate;	
		var wl = ((screen.width - 10) - 975) / 2;
		
		eemEnrollAgencyWin = window.open(url,"eemEnrollAgencySearch","toolbar=no,titlebar=0,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,ControlBox=no,width=975,height=700,top=1,left="+wl);
		eemEnrollAgencyWin.focus();
		
	}

	function openNewEnrollAgencySearch(args){
		var agentEffDate = dwr.util.getValue('displayAgent.frmtEffStartDate');
		if (agentEffDate == '') {
			alert('Please enter Effective Start Date');
			document.getElementsByName('displayAgent.frmtEffStartDate')[0].focus();
			return;
		}

		url = "/eemActionEnroll.do?method=enrollAgencySearchNew&agencySrchMove=first" +
				"&lineOfBusiness="+dwr.util.getValue('lineOfBusiness')+"&agentEffDate="+agentEffDate;
		var wl = ((screen.width - 10) - 975) / 2;
		
		eemEnrollAgencyWin = window.open(url,"eemEnrollAgencySearchNew","toolbar=no,titlebar=0,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,ControlBox=no,width=975,height=700,top=1,left="+wl);
		eemEnrollAgencyWin.focus();
		
	}	

	function searchEnrollAgency(move) {
		//var agency = dwr.util.getValue('searchAgencyId');
		//var agencyName = dwr.util.getValue('searchAgencyName');
		document.body.className = 'wait';
		document.eemEnrollForm.agencySrchMove.value = move;
		document.eemEnrollForm.method.value = 'enrollAgencySearch';
	  	document.eemEnrollForm.submit();
	}
	
	function searchNewEnrollAgency(move) {
		//var agency = dwr.util.getValue('searchAgencyId');
		//var agencyName = dwr.util.getValue('searchAgencyName');
		document.body.className = 'wait';
		document.eemEnrollForm.agencySrchMove.value = move;
		document.eemEnrollForm.method.value = 'enrollAgencySearchNew';
		document.eemEnrollForm.submit();
	}
	
	function resetEnrollAgencySearch() {
		ele = document.getElementsByTagName("input");
		for(var i = 0; i < ele.length; i++) {
			if (ele[i].name.indexOf('search') != -1) {
				ele[i].value = '';
			}
		
		}
		//Changes for Agent Lookup CR defect 415856: start
		var elements = document.getElementsByTagName('select');
		for (var i = 0; i < elements.length; i++)
		{
			if (elements[i].name.indexOf('search') != -1) {
		    elements[i].selectedIndex = 0;
		    
			}
		}
			//Changes for Agent Lookup CR defect 415856: end
	}
	
	function cancelEnrollAgencySearch() {
		window.close();
	}
	/*
	 * 024_Cambia_SUC_LEP - Start 01
	 */
	function eemLEPCredLetterClicked() {
		
		 var credTimer = document.getElementById('credcovTimer').value;
		    if(credTimer == "YES"){
		    	
		    	var form = document.forms[0]; 
		    	var tab = form.selectedMemberTab.value;
		    	enrollSubmit(form,"enrollCreCovLetter");
		    	alert("Letter has been Triggered Successfully");
		    }else{
		    	alert("Letter Can't be triggered,Member doesn't have expired 90 day Late Attestation timer");
		    }
		
	}
	function eemLEPAdjLtrClicked(){
		
		var form = document.forms[0]; 
		var tab = form.selectedMemberTab.value;
		enrollSubmit(form,"enrollLepAdjLetter");
		alert("Letter has been Triggered Successfully");

	}
	function eemLEPAdjLtrClick(){
		
		alert("Letter is already been in process");
	}
	function eemLEPCredLetterClick(){
		
		alert("Letter is already been in process");
	}

	/*
	 * 024_Cambia_SUC_LEP - End 01
	 */
	function setEnrollAgencyHidden(agencyId, agencyName) {
		dwr.util.setValue('hiddEnrollAgencyId',agencyId);
		dwr.util.setValue('hiddEnrollAgencyName',agencyName);
	}
	function populateEnrollAgencyValues() {
		agencyId = dwr.util.getValue('hiddEnrollAgencyId');
		agencyName = dwr.util.getValue('hiddEnrollAgencyName');
		if(agencyName !=null && agencyName != ""){
			agencyName = agencyName.replace("/", "'");
		}
		if(agencyId != null && agencyId != "") {
			window.opener.setEnrollAgencyValues(agencyId, agencyName);
			window.opener.setField('isChanged','Y');										
			window.close();
		}
	}
	function setEnrollAgencyValues(agencyId, agencyName){
		dwr.util.setValue('displayAgent.agencyId',agencyId);
		value = agencyId+" - "+agencyName;
		dwr.util.setValue('displayAgent.selAgencyId',value);
		getAgencyDetails();
		onChangeTabData('agent');
	}
	/* Agent Broker Lookup functioanlity - End */
	
	function setEnrollAgencyHiddenNew(agencyId, agencyName, agentId, agentType,agentName) {
		dwr.util.setValue('hiddEnrollAgencyId',agencyId);
		dwr.util.setValue('hiddEnrollAgencyName',agencyName);
		dwr.util.setValue('hiddEnrollAgentId',agentId);
		dwr.util.setValue('hiddEnrollAgentType',agentType);
		dwr.util.setValue('hiddEnrollAgentName',agentName);
	}	
	function populateEnrollAgencyValuesNew() {
		agencyId = dwr.util.getValue('hiddEnrollAgencyId');
		agencyName = dwr.util.getValue('hiddEnrollAgencyName');
		agentId = dwr.util.getValue('hiddEnrollAgentId');
		agentType = dwr.util.getValue('hiddEnrollAgentType');
		agentName = dwr.util.getValue('hiddEnrollAgentName');
		
		if(agencyName !=null && agencyName != ""){
			agencyName = agencyName.replace("/", "'");
		}
		if(agentName !=null && agentName != ""){
			agentName = agentName.replace("/", "'");
		}
		if(agencyId != null && agencyId != "") {
			window.opener.setEnrollAgencyValuesNew(agencyId, agencyName, agentId, agentType,agentName);
			window.opener.setField('isChanged','Y');										
			window.close();
		}
	}
	function setEnrollAgencyValuesNew(agencyId, agencyName, agentId, agentType,agentName){
		dwr.util.setValue('displayAgent.agencyId',agencyId);
		value = agencyId+" - "+agencyName;
		dwr.util.setValue('displayAgent.selAgencyId',value);
		dwr.util.setValue('displayAgent.agentType',agentType);
		dwr.util.setValue('displayAgent.agentId',agentId);
		getAgencyDetails();
		
	   getAgentDetailsNew(agentId,agentType,agentName);
		//IFOX-00420752 : Agent Issue :start
		dwr.util.setValue('displayAgent.agentId',agentId);
		value = agentId+" - "+agentName;
		dwr.util.setValue('displayAgent.selAgentId',value);
		setAgentValueNew(agentId);
	  //  setAgentList(agentId);
		//IFOX-00420752 : Agent Issue :end	
		onChangeTabData('agent');
	}
	 //IFOX-00415856 - New Agent Look Up CR :START
	function setAgentValueNew(val) {
		//IFOX-00420752 : Agent Issue :start
		//New Agent Browser issue fix : start
		document.getElementById('agentSel').style.display = 'none';
		//document.getElementById('agentSel').style.visibility = 'hidden';
		document.getElementById('agentText').style.display = '';
		setAgentList(val);
		//New Agent Browser issue fix : end
		//IFOX-00420752 : Agent Issue :end
	}
	  //IFOX-00415856 - New Agent Look Up CR :END
	// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - End
	function setSelectedIndexAgentID(s, v) {
	    for ( var i = 0; i < s.options.length; i++ ) {
	    	//alert("values-"+s.options[i].value+"::::"+v);
	        if ( s.options[i].value == v ) {
	        	  	//alert(s.options[i].value+i);
	            s.options[i].selected = true;
	           // $(s).change();
	            return;
	        }
	    }
	}
	function setSelectedIndexAgentType(s, v) {
	   for ( var i = 0; i < s.options.length; i++ ) {
		  // alert("values-"+s.options[i].value+"::::"+v);
	    	  if ( s.options[i].value == v ) { 	
	           s.options[i].selected = true;
	           // $(s).change();
	            return;
	        }
	    }
	}
	
	
	