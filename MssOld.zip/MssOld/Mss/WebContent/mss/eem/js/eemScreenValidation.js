function formatPhone(obj) {
var phone = obj.value;
//I3 UAT fixes-- Start
phone = phone.replace(/^\s+|\s+$/g,'');
if(phone!=""){
var no = /^\d{10}$/; 
var no2 = /^(\d{3})-(\d{3})-(\d{4})/;
if((obj.value.match(no))){

  phone = phone.replace(/(\d{3})(\d{3})(\d{4})/, "$1-$2-$3");
  obj.value = phone;
  }
else if((phone.match(no2))){
	obj.value = phone;
}
else{
alert("Please enter a valid 10 digit number ");  
obj.value = '';
}
}
//I3 UAT fixes ---- End
}
function formatDate(obj) {
	var date = obj.value;
	var no = /^\d{8}$/;  
	if((obj.value.match(no))){
	  date = date.replace(/(\d{2})(\d{2})(\d{4})/, "$1/$2/$3");
	  obj.value = date;
	 return true;
	}
	}

function dateFormatting(obj) {
	formatDate(obj);
	validateDate(obj);
}
	
function dateFormatting(obj, allowNines) {
	formatDate(obj);
	validateDate(obj, allowNines);	
}

function futureDateValidation(obj){
	
	var date1 = new Date(obj.value.replace(/(\d{2})(\d{2})(\d{4})/, "$1/$2/$3"));
	var date2 = new Date();
	if(date1>date2){
		alert("Attestation Date cannot be greater than today's date");
		return false;
	}
}

function checkEmail(obj) {
	//I3 UAT fixes-- Start
	if(obj.value!=""){
		// Added # in the filter for IFOX-00378544
		// Added & in the filter for IFOX-00380200 -- Start
	   var filter = /^([a-zA-Z0-9_#\&\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	   	// Added & in the filter for IFOX-00380200 -- End
	    if (!filter.test(obj.value)) {
	    alert('Please provide a valid email address');
	    obj.value = '';
	    return obj;
	 }
	}
	//I3 UAT fixes-- End
	}
function formatingSSN(obj) {
	var ssn = obj.value;
	ssn = ssn.replace(/^\s+|\s+$/g,'');
	if(ssn!=""){
		ssn = ssn.replace(/[^0-9]/g, '');
		 obj.value = ssn;
	var no = /^\d{9}$/;  
	if((obj.value.match(no))){
		ssn = ssn.replace(/(\d{3})(\d{2})(\d{4})/, "$1-$2-$3");
	  obj.value = ssn;
	  }
	else{
	alert("Please enter a valid SSN ");  
	obj.value = '';
	}
	}
}
function dateFormatting1(obj) {
	formatDate(obj);
	if(validateDate(obj))
	return true;
	else
		return false;
}