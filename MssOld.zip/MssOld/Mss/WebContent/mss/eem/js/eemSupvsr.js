// $Id: eemSupvsr.js,v 1.1 2014/06/26 07:56:54 praveen Exp $
function displayException() {
	if (dwr.util.getValue('message') != '') {
		alert(dwr.util.getValue('message'));
	}
}
/* Search */
function supvsrSearch() {
  document.body.className = 'wait';
  document.eemSupvsrForm.method.value = 'supvsrSearch';
  document.eemSupvsrForm.submit();
}
function checkSearchDate(ele) {
	var val = ele.value;
	if (val != "" && !isDate(val, 'MMyyyy')) {
		alert("Please enter the date in MMyyyy format.");
		ele.focus();
		ele.select();
		return false;
	}
	return true;
}
function supvsrSearchPageFirst(ctl) {
  document.body.className = 'wait';
  document.eemSupvsrForm.method.value = "supvsrPageFirst";
  document.eemSupvsrForm.submit();
}
function supvsrSearchPagePrev(ctl) {
  document.body.className = 'wait';
  document.eemSupvsrForm.method.value = "supvsrPagePrev";
  document.eemSupvsrForm.submit();
}
function supvsrSearchPageNext(ctl) {
  document.body.className = 'wait';
  document.eemSupvsrForm.method.value = "supvsrPageNext";
  document.eemSupvsrForm.submit();
}

/* Options */
function selectAll() {
	var val = document.getElementsByName('setAllStatus')[0].value;
	var arrEle = document.getElementsByName("rowApprStatus");
	if (arrEle != null) {
		for (i = 0; i < arrEle.length; i++) {
			arrEle[i].value = val;
		}
	}
}
function updateApprovals() {
  document.body.className = 'wait';
  document.eemSupvsrForm.method.value = "supvsrUpdate";
  document.eemSupvsrForm.submit();
}
function cancelApprovals() {
  document.body.className = 'wait';
  document.eemSupvsrForm.method.value = "supvsrCancel";
  document.eemSupvsrForm.submit();
}

/* Search Results */
function gotoApplication(customerId, applId, col) {
  document.body.className = 'wait';
  //col.parentNode.className = "selectedRow";
  document.eemSupvsrForm.method.value = 'gotoApplication';
  document.eemSupvsrForm.customerId.value = customerId;
  document.eemSupvsrForm.applId.value = applId;
  document.eemSupvsrForm.submit();
}