function cobFlowSearch() {
	//alert(" in cob flow newww");
	document.body.className = 'wait';
	//alert(document.forms[0].method[0].value);
	document.forms[0].method[0].value = 'cobFlowSearch';
    document.forms[0].submit();
}

function cobFlowUpdate() {
	/*document.body.className = 'wait';	
	//alert(" in cob flow update");
  	document.forms[0].method[0].value = 'cobFlowUpdate';
  	//alert(" in cob flow update"+document.forms[0].method[0].value);
  	document.forms[0].submit();
  	document.forms[1].submit();*/
	alert("Data Has Been Saved Successfully.");
} 

