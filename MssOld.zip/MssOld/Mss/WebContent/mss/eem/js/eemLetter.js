// $Id: eemLetter.js,v 1.1 2014/06/26 07:56:52 praveen Exp $
function letterSubmit(method) 
{
	document.body.className = 'wait';	
	document.eemLetterReqForm.method.value = method;
	//alert("FORM:"+document.eemLetterReqForm.name+"|ACTION:"+document.eemLetterReqForm.action+"|Method:"+document.eemLetterReqForm.method.value);
  	document.eemLetterReqForm.submit();
}
