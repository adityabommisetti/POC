// $Id: eem.js,v 1.1 2014/06/26 07:56:52 praveen Exp $
/* General Application */
function setTableRowClass(tblRowId,css)
{
	var e = document.getElementById(tblRowId);
	setElemTableRowClass(e,css);
}
function setElemTableRowClass(tblRowElem,css)
{
	tblRowElem.className = css;
	var tdTags = tblRowElem.getElementsByTagName("td");
	var l = tdTags.length;
	for (var idx = 0; idx < l; idx++) {
		tdTags[idx].className = css;
	}
}

function toggleVisibilityState(ctl,id,state) {
	var elem = document.getElementById(id);
	toggleVisibilityElem(ctl,elem);
	if (elem.style.display == 'none')	
		state.value=false;
	else 
		state.value=true;
}
function toggleVisibility(ctl,id) {
	var elem = document.getElementById(id);
	toggleVisibilityElem(ctl,elem);
}
function toggleVisibilityElem(ctl,elem) {
	if(elem.style.display == 'none') {
		elem.style.display = "";
		elem.setAttribute("rowExpanded", "true");
		ctl.src = '/mss/jsp/Recon/images/Minus.png';
	} else {
		elem.style.display = 'none';
		elem.setAttribute("rowExpanded", "false");
		ctl.src = '/mss/jsp/Recon//images/Plus.png';
	}
}

function switchMenu(val) {
  //alert("swicthMenu::"+val);
  document.body.className = 'wait';
 // alert("swicthMenu::"+document.forms[0].id);
  document.forms[0].method.value = 'switchMenu';
  document.forms[0].menu.value = val;
  //alert("FORM:"+document.forms[0].name+"|ACTION:"+document.forms[0].action+"|MENU:"+document.forms[0].menu.value);
  document.forms[0].submit();
}
function clickOption(obj, val) {
  var objLnk = document.getElementById(obj);
  if (objLnk != null) {
	  sHref = objLnk.href + val;
	  objLnk.href = sHref;
	  objLnk.click();
  }
}
function getField(field) {
	var ele = document.getElementsByName(field);
	if (ele != null) {
		if (ele[0] != null) {
			if (ele[0].value != null) {
				return dwr.util.getValue(field);
			}
		}
	}
	return '';
}
function setField(field, val) {
	var ele = document.getElementsByName(field);
	if (ele != null) {
		if (ele[0] != null) {
			if (ele[0].value != null) {
				dwr.util.setValue(field, val);
			}
		}
	}
}
function checkAll(field) {
	for (i = 0; i < field.length; i++)
		field[i].checked = true ;
}

function uncheckAll(field) {
	for (i = 0; i < field.length; i++)
		field[i].checked = false ;
}
function isChecked(field) {
	for (i = 0; i < field.length; i++){
		if (field[i].checked) {
			return 1;
		}	
	}
	return 0;
}
function padLeftZero(val) {
  if(val < 10) {
  	val = "0" + val;
  }
  return val;
}

function formatSSN(ssn)
{
	var len = ssn.length;
	if (len == 9) {
		if (isNumeric(ssn)) {
			return ssn.substring(0,3) + "-" + ssn.substring(3,5) + "-" + ssn.substring(5);
		}
	}
	return ssn;
}
function validSSN(ssn)
{
	var len = ssn.length;
	if (len == 11) {
		if (isNumeric(ssn.substring(0,3))) {
			if (ssn.charAt(3) == '-') {
				if (isNumeric(ssn.substring(4,6))) {
					if (ssn.charAt(6) == '-') {
						if (isNumeric(ssn.substring(7))) {
							return true;
						}
					}
				}
			}
		}
	}
	return false;
}
function checkSSNFormat(ctl)
{
	if (validSSN(ctl.value)) {
		return true;;
	}
	alert("Invalid SSN Format nnn-nn-nnnn");
	return false;
}
function imposeMaxLength(Event, Object, MaxLen) {
	if (Event.keyCode == 8)
		return true;
	if (Object.value.length >= MaxLen) {
		alert("Maximum Comment size of 255 exceeded");
		return false
	}
	return true;
	//return (Object.value.length <= MaxLen)||(Event.keyCode == 8 ||Event.keyCode==46||(Event.keyCode>=35&&Event.keyCode<=40))
}
function checkReturnKey(Event) {
	if (Event.keyCode == 13)
		return false;
}
/*function loadingShow(){
	document.getElementById('loading').style.display = 'block';
	cursor: wait;
}*/