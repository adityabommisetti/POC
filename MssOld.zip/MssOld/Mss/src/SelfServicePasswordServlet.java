
import java.io.IOException;
import java.io.File;
import java.sql.Connection;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import com.ps.net.URLEncoder;
import com.ps.text.DateFormatter;
import com.ps.util.StringUtil;
import com.ps.mss.db.DbConn;
import com.ps.mss.db.AppLogPersistence;
import com.ps.mss.db.CodeCache;
import com.ps.mss.db.Message;
import com.ps.mss.db.Module;
import com.ps.mss.db.Secuser;
import com.ps.mss.db.SecuserPersistence;
import com.ps.mss.security.CryptoDigest;
import com.ps.mss.security.PBECipher;
/*
 * $Id: SelfServicePasswordServlet.java,v 1.1 2014/06/26 07:56:07 praveen Exp $
 */

/**
 * @author nenne.robert
 */
public class SelfServicePasswordServlet extends HttpServlet {
	private static Logger logger=LoggerFactory.getLogger(SelfServicePasswordServlet.class);

	public void service(HttpServletRequest request, HttpServletResponse response)
	  throws ServletException, IOException
	{

	    File fn = new File("D:\\Java\\MAINTENANCE");
	    if (fn.exists())
	    {
	   		response.sendRedirect((String)response.encodeRedirectURL("/mss/home/MaintInProgressJsp.jsp") );
	   		return;
	    }
	    
	    String encP1 = StringUtil.nonNullTrim(request.getParameter("P1"));
	    String encP2 = StringUtil.nonNullTrim(request.getParameter("P2"));
	    String newUserPwd = StringUtil.nonNullTrim(request.getParameter("NewUserPwd"));
	    String reNewUserPwd = StringUtil.nonNullTrim(request.getParameter("ReNewUserPwd"));
	    
	    Secuser secUser = null;
		String userId = null;
		    
	    Connection conn = null;
	    try {
	    	conn = DbConn.getConnection();
			AppLogPersistence alp = new AppLogPersistence();
			
			try {
				PBECipher pbeCipher = new PBECipher();
				if (!pbeCipher.getPassPhrase(conn)) {
	   				response.sendRedirect((String)response.encodeRedirectURL("/mss/home/ForgotPasswordMessage.jsp?msgId=5"));
					return;    				
				}
				pbeCipher.initDecrypt();
				userId = pbeCipher.decrypt(encP1);			
			} catch(Exception e) {
				logger.error(e.getMessage());
	   			alp.add(conn,"SERVICE",null,"[" + encP1 + "][" + encP2 + "]",Module.SELFSERVICEPASSWORD_SERVLET,Message.SS_PWD_DECRYPTION,1);
				response.sendRedirect((String)response.encodeRedirectURL("/mss/home/ForgotPasswordMessage.jsp?msgId=5"));
				return;    				
			}
			
			SecuserPersistence sup = new SecuserPersistence();
			secUser = sup.get(conn,userId);
			if (secUser == null) {
				logger.error("No User Id Found: " + userId);
	   			alp.add(conn,"SERVICE",null,userId,Module.SELFSERVICEPASSWORD_SERVLET,Message.INVALID_USER_ID,2);
	   			response.sendRedirect((String)response.encodeRedirectURL("/mss/home/ForgotPasswordMessage.jsp?msgId=5"));
				return;    				
			}
			
			if (secUser.getActive().equals("N")) {
				logger.error("Attemped Reset on Inactive User Id: " + userId);
	   			alp.add(conn,userId,Module.SELFSERVICEPASSWORD_SERVLET,Message.INACTIVE_USER_ID,3);
	   			response.sendRedirect((String)response.encodeRedirectURL("/mss/home/ForgotPasswordMessage.jsp?msgId=6"));
				return;    				
			}

			if (!secUser.getAutoPwdStatus().equals("P")) {
				logger.error("User Not in Pending Status: " + userId + " [" + secUser.getAutoPwdStatus() + "]");
	   			alp.add(conn,userId,Module.SELFSERVICEPASSWORD_SERVLET,Message.SS_PWD_NOT_PENDING,4);
	   			response.sendRedirect((String)response.encodeRedirectURL("/mss/home/ForgotPasswordMessage.jsp?msgId=7"));
				return;    				
			}
			
			DateFormatter df = new DateFormatter();
			String emailTS = df.reFormatDate(secUser.getAutoPwdEmailTime(),DateFormatter.DB2_TIMESTAMP,DateFormatter.DB2_TIMESTAMP);
						
			String p2 = emailTS + "|" + secUser.getHintId() + "|" + secUser.getHintId2() + "|" + secUser.getHintId3() + "|" + userId + "/" + secUser.getUserPwd();
			CryptoDigest crypt = new CryptoDigest();
			String validEncP2 = crypt.digest(p2);
			
			if (!validEncP2.equals(encP2)) {
				logger.error("Self Service Parameter Validation Vailed: " + userId + " [" + secUser.getAutoPwdStatus() + "]");
	   			alp.add(conn,userId,null,encP2,Module.SELFSERVICEPASSWORD_SERVLET,Message.SS_PWD_PARM_VALIDATION,5);
	   			response.sendRedirect((String)response.encodeRedirectURL("/mss/home/ForgotPasswordMessage.jsp?msgId=8"));
				return;		
			}
			
			int yr = Integer.parseInt(emailTS.substring(0,4));
			int mm = Integer.parseInt(emailTS.substring(5,7)) - 1;
			int dd = Integer.parseInt(emailTS.substring(8,10));
			int hh = Integer.parseInt(emailTS.substring(11,13));
			int mi = Integer.parseInt(emailTS.substring(14,16));
			int ss = Integer.parseInt(emailTS.substring(17,19));
			
			Calendar emailTime = Calendar.getInstance();
			emailTime.set(yr,mm,dd,hh,mi,ss);
			emailTime.add(Calendar.HOUR,48);
			
			Calendar now = Calendar.getInstance();
					
			String emTD = emailTime.getTime().toString();
			String nowTD = now.getTime().toString();
			
			if (now.after(emailTime)) {
				logger.error("Expired Reset: " + userId + " [" + emailTime + "]");
	   			alp.add(conn,userId,null,emailTS,Module.SELFSERVICEPASSWORD_SERVLET,Message.SS_PWD_EXPIRED,6);
	   			response.sendRedirect((String)response.encodeRedirectURL("/mss/home/ForgotPasswordMessage.jsp?msgId=9&skipNbr=TRUE"));
				return;		
			}
	    
			if (!newUserPwd.equals(reNewUserPwd)) {
				logger.error("Password Mismatch: " + userId);
	   			alp.add(conn,userId,null,emailTS,Module.SELFSERVICEPASSWORD_SERVLET,Message.PASWORD_CONF_MISMATCH,7);
	   			response.sendRedirect((String)response.encodeRedirectURL("/mss/home/SelfServicePassword.jsp?P1=" + URLEncoder.encode(encP1) + "&P2=" + URLEncoder.encode(encP2) + "&retry=1"));
				return;				
			}
			
			String newPwdDigest = crypt.digest(userId, newUserPwd);
			boolean usedPwd = sup.usedPassword(conn,userId,newPwdDigest);
			if (usedPwd) {
	   			alp.add(conn,userId,userId,newPwdDigest,Module.SELFSERVICEPASSWORD_SERVLET,Message.PASWORD_REUSE,8);				
	   			response.sendRedirect((String)response.encodeRedirectURL("/mss/home/SelfServicePassword.jsp?P1=" + URLEncoder.encode(encP1) + "&P2=" + URLEncoder.encode(encP2) + "&retry=2"));
				return;				
			}
			
			CodeCache cc = CodeCache.getInstance();
			int pwdExpireDays = cc.getPwdExpireDays();
			
            String newPwdExpireDate = sup.calcNewPwdExpireDateString(now,pwdExpireDays);
            int cnt = sup.resetPassword(conn,userId,secUser.getActive(),newPwdDigest,newPwdExpireDate);
            if (cnt != 1) {
				logger.error("Self Service Password Update Failed: " + userId + " cnt=" + cnt);
				alp.add(conn,userId,null,"cnt=" + cnt,Module.SELFSERVICEPASSWORD_SERVLET,Message.PASSWORD_RESET_FAILED,7);
	   			response.sendRedirect((String)response.encodeRedirectURL("/mss/home/ForgotPasswordMessage.jsp?msgId=5"));
				return;
            }

			alp.add(conn,userId,userId,newPwdDigest,Module.SELFSERVICEPASSWORD_SERVLET,Message.USER_PASSWORD_CHANGE,7);
            
	    } catch(Exception e) {
	    	logger.error(e.getMessage());
			response.sendRedirect((String)response.encodeRedirectURL("/mss/home/ForgotPasswordMessage.jsp?msgId=5"));
			return;
	    } finally {
	    	try {
	    		if (conn != null)
	    			conn.close();
	    	} catch(Exception e) {
	    		logger.error(e.getMessage());
	    	}
	    }
	    
		response.sendRedirect((String)response.encodeRedirectURL("/mss/home/ForgotPasswordMessage.jsp?msgId=10&skipNbr=TRUE&alert=FALSE"));
		return;
	    
	}
}
