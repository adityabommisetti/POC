/*
 * $Id: FileDownloadServlet.java,v 1.2 2016/04/12 22:20:57 dinesh Exp $
 */

import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;

import com.ps.net.URLEncoder;
import com.ps.text.DateFormatter;
import com.ps.util.DateUtil;
import org.slf4j.LoggerFactory;
import com.ps.mss.util.MssProperties;
import com.ps.mss.db.DbConn;
import com.ps.mss.db.FileXferLog;
import com.ps.mss.db.FileXferLogPersistence;
import com.ps.mss.db.SecgroupPersistence;
import com.ps.mss.security.SessionManager;

public class FileDownloadServlet extends HttpServlet {
	/**
	 * 
	 */
	private static Logger logger=LoggerFactory.getLogger(FileDownloadServlet.class);

    public void service(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException
    {

        HttpSession session  = SessionManager.getSession(request);
        if (session == null)
        {
            logger.error("No Session");
            return;
        }

        String userId = (String) session.getAttribute("User_id");
        if (userId == null)
        {
            logger.error("Null userId");
            return;
        }

        response.setHeader("Expires","0");
        response.setContentType("application/octet-stream");
        
        String rptName = request.getParameter("rpt");
        logger.debug("Rpt Name: " + rptName);

        DataOutputStream out = null;
        DataInputStream in = null;
        
        int timeOut = session.getMaxInactiveInterval();

        int totalBytes = 0;        
        try {
        	session.setMaxInactiveInterval(36000);
        	
            out = new DataOutputStream(response.getOutputStream());
                       
            URL receiveServlet = new URL("http://" + MssProperties.getFileAppURL() + "/servlet/SendFileServlet?Id="+URLEncoder.encode("W/Ef2E+8+yn9Ba86OI78BLmK1J4=")+"&rpt="+rptName);
            URLConnection uc = receiveServlet.openConnection();

            uc.setDoInput(true);
            uc.setDoOutput(true);
            uc.setUseCaches(false);
            uc.setRequestProperty("Content-type","application/octet-stream");

            in = new DataInputStream(uc.getInputStream());
            
            int bufSize = 4196;
            byte[] data = new byte[bufSize];        
                                   
            int bytesRead = 0;
        
            while (bytesRead >= 0)
            {
                bytesRead = in.read(data,0,bufSize);
                if (bytesRead == -1) break;
                totalBytes += bytesRead;
                out.write(data,0,bytesRead);
            }    
            
        } catch(Exception e) {
            logger.error(e.getMessage());
        } finally {
        	session  = request.getSession(false);
        	session.setMaxInactiveInterval(timeOut);
            try {
                if (in != null) in.close();
            } catch(Exception e) {
                logger.error(e.getMessage());
            }
            try {
                if (out != null) out.close();
            } catch(Exception e) {
                logger.error(e.getMessage());
            }            
        }
        
        Connection conn = null;
        try {
            DateUtil du = new DateUtil();
            DateFormatter df = new DateFormatter();
            
            conn = DbConn.getConnection();
            
            SecgroupPersistence sgp = new SecgroupPersistence();
            String Cust_nbr = sgp.getCustNbrByUserId(conn, userId);
            File f = new File(rptName);
            String baseName = f.getName();

            FileXferLog fxl = new FileXferLog();
            fxl.setXferTimestamp(df.reFormatDate(du.getDTS(),DateFormatter.YYYYMMDDHHMMSSFF,DateFormatter.SQL_TIMESTAMP));
            fxl.setSponsorCust(Cust_nbr);
            fxl.setUserId(userId);
            fxl.setFileName(baseName);
            fxl.setSource("SMS");
            fxl.setDestination("WEB");
            fxl.setTotalBytes(totalBytes);
            
            FileXferLogPersistence fxlp = new FileXferLogPersistence();
            fxlp.InsertFileXferLog(conn, fxl);           
        } catch(Exception e) {
            logger.error(e.getMessage());
        } finally {
            try {
                if (conn != null)
                    conn.close();
            } catch(Exception e) {
                logger.error(e.getMessage());
            }
        }        
             
    }

}
