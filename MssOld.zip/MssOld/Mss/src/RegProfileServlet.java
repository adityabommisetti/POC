import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import com.ps.net.URLEncoder;
import com.ps.text.DateFormatter;
import com.ps.util.StringUtil;
import com.ps.mss.util.MssProperties;
import com.ps.mss.db.DbConn;
import com.ps.mss.framework.Constants;

public class RegProfileServlet extends HttpServlet
{
	private static Logger logger=LoggerFactory.getLogger(RegProfileServlet.class);

public void service(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException
{
    String BaseUrl = MssProperties.getWebAppURL();

    String SvcRequired_date = request.getParameter("SvcRequired_date");
    String sMsg="Started";
    String sPt ="Begin";
    DateFormatter df = new DateFormatter();
    if (SvcRequired_date.length()==10)
        SvcRequired_date = df.reFormatDate(SvcRequired_date,DateFormatter.MM_DD_YYYY,DateFormatter.DB2_TIMESTAMP);
    else
        SvcRequired_date = null;

    String Concurrent_cnt = request.getParameter("Concurrent_cnt");

    if ((Concurrent_cnt==null) || (Concurrent_cnt.length()==0)) Concurrent_cnt="0";

    // Confirm that user is logged in a valid session
    HttpSession session  = request.getSession(false);
    if (session == null) {
        sMsg="No Session";
       logger.error(sMsg);
        response.sendRedirect((String)response.encodeRedirectURL(Constants.ERROR_PAGE + "?Msg=" + URLEncoder.encode(sMsg)));
        return;
    }
    String Reguser_id = (String) session.getAttribute("Reguser_id");

    if (Reguser_id.length() == 0)
    {
        sMsg="Invalid User Id";
       logger.error(sMsg);
        response.sendRedirect((String)response.encodeRedirectURL(Constants.ERROR_PAGE + "?Msg=" + URLEncoder.encode(sMsg)));
        return;
    }
    
    Connection conn = null;
    Statement stmt = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    String SQL = null;

    try {
    	conn = DbConn.getConnection();
    	stmt = conn.createStatement();

        SQL = "Select Reguser_id FROM reguser WHERE Reguser_id = ?";
        ps = conn.prepareStatement(SQL);
        ps.setString(1,Reguser_id);
        rs = ps.executeQuery();
        //If this record exists delete it
        if (!rs.next())
        {
        	sMsg = Reguser_id + " does not exist";

        	//sPage= sPage + "?Msg=" + sMsg;
        	logger.error(sMsg);
        	response.sendRedirect((String)response.encodeRedirectURL(Constants.ERROR_PAGE + "?Msg=" + URLEncoder.encode(sMsg)));
        	return;
        }
    	
        String interest_yn = StringUtil.nonNullTrim(request.getParameter("interest_yn"));
        if (!interest_yn.equals("Y"))
            interest_yn = "N";
        SQL = "UPDATE reguser" +
                " SET interest_yn = ?," +
                    " LastUpdated_date = Current_Timestamp" +
              " WHERE Reguser_id = ?";
        ps = conn.prepareStatement(SQL);
        ps.setString(1,interest_yn);
        ps.setString(2,Reguser_id);      
        ps.executeUpdate();

        //delete any existing plans from regplan table
        SQL = "delete from regplan where Reguser_id = ?";
        ps = conn.prepareStatement(SQL);
        ps.setString(1,Reguser_id);      
        ps.executeUpdate();

        SQL = "insert into regplan (Reguser_id,Plan_id) values (?,?)";
        ps = conn.prepareStatement(SQL);
        
        //Iterate through each of the plan fields and capture any plan ids
        String Plan_id=null;
        for (int i=1;i<16;i++)
        {
            //Store the plan ids
            //sPt ="About to get Plan_id" + "Plan_id" + i;
            Plan_id = request.getParameter("Plan_id" + i);
            sMsg="";
            if (Plan_id != null && Plan_id.length() == 5)
            {   //only store valid plan_ids
            	Plan_id = Plan_id.toUpperCase();
            	ps.setString(1,Reguser_id);
            	ps.setString(2,Plan_id);
            	ps.executeUpdate();
            }
        }//end of for loop

        //delete any existing services from reguser_service table
        SQL = "delete from reguser_service where Reguser_id = ?";
        ps = conn.prepareStatement(SQL);
        ps.setString(1,Reguser_id);      
        ps.executeUpdate();
        
        //Store the Service_ids
        String [] Service_ids = request.getParameterValues("Service_id");
        if (Service_ids != null)
        {
            SQL = "insert into reguser_service (Reguser_id,Service_id) values (?,?)";
            ps = conn.prepareStatement(SQL);
            
            int cnt = Service_ids.length;
            for (int i = 0; i < cnt; i++)
            {
                if ((Service_ids[i] != null) && (Service_ids[i].length() > 0))
                {
                	ps.setString(1,Reguser_id);
                	ps.setString(2,Service_ids[i]);
                	ps.executeUpdate();
                }
            }
        }
        //end of for loop

        SQL = "Select Reguser_id FROM REGETC WHERE Reguser_id = ?";
        ps = conn.prepareStatement(SQL);
        ps.setString(1,Reguser_id);
        rs = ps.executeQuery();

        //If this record exists update it
        if (rs.next())
        {
        	SQL = "UPDATE regetc SET " +
                "Contact1First_name = ?, Contact1Last_name = ?, Contact1Phone = ?, Contact1Fax = ?, Contact1Email = ?," +
                "Contact2First_name = ?, Contact2Last_name = ?, Contact2Phone = ?, Contact2Fax = ?, Contact2Email = ?," +
                "SvcRequired_date = ?, Concurrent_cnt = ?" +
                "WHERE Reguser_id = ?";
                
            ps = conn.prepareStatement(SQL);
            ps.setString(1,StringUtil.nonNullTrim(request.getParameter("Contact1First_name")));
            ps.setString(2,StringUtil.nonNullTrim(request.getParameter("Contact1Last_name")));
            ps.setString(3,StringUtil.nonNullTrim(request.getParameter("Contact1Phone")));
            ps.setString(4,StringUtil.nonNullTrim(request.getParameter("Contact1Fax")));
            ps.setString(5,StringUtil.nonNullTrim(request.getParameter("Contact1Email")));
            ps.setString(6,StringUtil.nonNullTrim(request.getParameter("Contact2First_name")));
            ps.setString(7,StringUtil.nonNullTrim(request.getParameter("Contact2Last_name")));
            ps.setString(8,StringUtil.nonNullTrim(request.getParameter("Contact2Phone")));
            ps.setString(9,StringUtil.nonNullTrim(request.getParameter("Contact2Fax")));
            ps.setString(10,StringUtil.nonNullTrim(request.getParameter("Contact2Email")));
            ps.setString(11,SvcRequired_date);
            ps.setString(12,Concurrent_cnt);
            ps.setString(13,Reguser_id);

            ps.executeUpdate();
        } else {
            SQL = "INSERT INTO regetc (Reguser_id," +
					"Contact1First_name, Contact1Last_name, Contact1Phone, Contact1Fax, Contact1Email," +
					"Contact2First_name, Contact2Last_name, Contact2Phone, Contact2Fax, Contact2Email," +
					"SvcRequired_date, Concurrent_cnt" +
                 ") VALUES(?, ?,?,?,?,?, ?,?,?,?,?, ?,?)";

            ps = conn.prepareStatement(SQL);
            ps.setString(1,Reguser_id);
            ps.setString(2,StringUtil.nonNullTrim(request.getParameter("Contact1First_name")));
            ps.setString(3,StringUtil.nonNullTrim(request.getParameter("Contact1Last_name")));
            ps.setString(4,StringUtil.nonNullTrim(request.getParameter("Contact1Phone")));
            ps.setString(5,StringUtil.nonNullTrim(request.getParameter("Contact1Fax")));
            ps.setString(6,StringUtil.nonNullTrim(request.getParameter("Contact1Email")));
            ps.setString(7,StringUtil.nonNullTrim(request.getParameter("Contact2First_name")));
            ps.setString(8,StringUtil.nonNullTrim(request.getParameter("Contact2Last_name")));
            ps.setString(9,StringUtil.nonNullTrim(request.getParameter("Contact2Phone")));
            ps.setString(10,StringUtil.nonNullTrim(request.getParameter("Contact2Fax")));
            ps.setString(11,StringUtil.nonNullTrim(request.getParameter("Contact2Email")));
            ps.setString(12,SvcRequired_date);
            ps.setString(13,Concurrent_cnt);

            ps.executeUpdate();				 
        }

        response.sendRedirect((String)response.encodeRedirectURL("https://"+BaseUrl+"/mss/home/ThankYouJsp.jsp"));
        return;
        
    } catch(Exception e) {
	   logger.error(e.getMessage());
	} finally {
    	try {
    		if (rs != null) rs.close();
    	} catch(Exception e) {
    		logger.error(e.getMessage());
    	}
    	try {
    		if (ps != null) ps.close();
    	} catch(Exception e) {
    		logger.error(e.getMessage());
    	}
    	try {
    		if (stmt != null) stmt.close();
    	} catch(Exception e) {
    		logger.error(e.getMessage());
    	}
    	try {
    		if (conn != null) conn.close();
    	} catch(Exception e) {
    		logger.error(e.getMessage());
    	}
    }

	logger.error("Encoded Error URL is " + response.encodeRedirectURL(Constants.ERROR_PAGE + "?Msg=An+Unexpected+Response+Has+Occured"));

    response.sendRedirect((String)response.encodeRedirectURL(Constants.ERROR_PAGE + "?Msg=An+Unexpected+Response+Has+Occured"));
}
}