
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ps.http.HttpClientRequestHandler;
import com.ps.http.RequestHandler;
import com.ps.io.ModuleLog;
import com.ps.mss.util.MssProperties;
import com.ps.mss.security.SessionManager;

public class ExtractFileUploadServlet extends HttpServlet {

    public void service(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException
    {
    	//TODO - Remove the sys out
    	String environment = MssProperties.getEnvironment();
        ModuleLog log = new ModuleLog("ExtractFileUploadServlet");
                
        HttpSession session  = SessionManager.getSession(request);
        if (session == null)
        {
            log.println("No Session");
            response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/ErrorPFJsp.jsp?Msg=Page+Expired"));
            return;
        }

        String User_id = (String) session.getAttribute("User_id");
        if (User_id == null)
        {
            log.println("Null User_id");
            response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/ErrorPFJsp.jsp?Msg=Invalid+Session"));
            return;
        }

        log.println("Upload Request Received from " + User_id);
        //Locker Start
      //PDE Upload Issue -- Start
        System.out.println("Locker:" + request.getParameter("lid")
				+ "\t MF ID :" + request.getParameter("MFid")
				+ "\t Customer ID:: " + request.getParameter("cust")
				+ "\t Rpt_type" + request.getParameter("Type")
				+ "\t environment statement" + environment
				+ "\t startDate "+request.getParameter("pLocker"));
      //PDE Upload Issue -- End
        
        String targetURL = null;
        RequestHandler requestHandler = null;
        
        int timeOut = session.getMaxInactiveInterval();
        session.setAttribute("MaxInactiveInterval",new Integer(timeOut));
        
        try {
        	session.setMaxInactiveInterval(18000);
        	System.out.println("The fileAppUrl is "+MssProperties.getFileAppURL());
        	targetURL = "http://" + MssProperties.getFileAppURL() + "/servlet/ReceiveFileServlet";
        	requestHandler = new HttpClientRequestHandler(targetURL);
        	
        	// Set the total length in session. This will be accessed by the FileUploadStatusServlet
        	// to calculate the upload progress.
        	//long contentLength = request.getContentLength();        	
        	//session.setAttribute("UPLOAD_CONTENT_LEN", String.valueOf(contentLength)); //TODO - make this a constant
       	
        	requestHandler.processRequest(request, response);

        } catch(Throwable t) {
            log.println(t.toString());
           //PDE Upload Issue
            response.sendRedirect((String)response.encodeRedirectURL("https://"+MssProperties.getWebAppURL()+"/mss/jsp/ErrorWJsp.jsp?Msg=Invalid+Submitter+Configuration"));
        } finally {
        	targetURL = null; 
        	requestHandler = null;
        	//session.setMaxInactiveInterval(timeOut);
        	//log.println("Last Access Time: " + session.getLastAccessedTime() + "Inactive: " + session.getMaxInactiveInterval());
        }
        return;        
    }

}
