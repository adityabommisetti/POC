import java.io.IOException;
import java.sql.Connection;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import com.ps.mss.db.AppLogPersistence;
import com.ps.mss.db.DbConnWeb;
import com.ps.mss.util.MssProperties;
import com.ps.mss.framework.Constants;
import com.ps.mss.util.EmailNotification;
import com.ps.util.StringUtil;


public class TrialRegServlet extends HttpServlet
{
	private static Logger logger=LoggerFactory.getLogger(TrialRegServlet.class);

public void service(HttpServletRequest request, HttpServletResponse response)
  throws ServletException, IOException
{

	HttpSession session = request.getSession(true);
	
	Connection conn = null;
	AppLogPersistence alp = new AppLogPersistence();
	
	//Variables for the registration prompt page
	String reg_date = "";

    String BaseUrl = MssProperties.getWebAppURL();

	//Get the parameters data from the registration page
	String firstname = request.getParameter("firstname");
	String lastname = request.getParameter("lastname");
	String companyname = request.getParameter("companyname");
	String telephone = request.getParameter("telephone");
	String email = request.getParameter("email");
	String address1 = request.getParameter("address1");
	String address2 = request.getParameter("address2");
	String city = request.getParameter("city");
	String state = request.getParameter("state");
	String zip = request.getParameter("zip");
	
	int numOfPlans = 10;
	String [] Plan_ids;
	Plan_ids = new String[numOfPlans];
	int i = 0;
	while ( i != numOfPlans)
	{
		Plan_ids[i] = StringUtil.nonNullTrim(request.getParameter("Plan_id"+i));
		i++;
	}
	
	String planIds = "";

	//Default Register date to current date
	Calendar now = Calendar.getInstance();
	reg_date = String.valueOf(now.get(Calendar.MONTH)+1) + "/" + String.valueOf(now.get(Calendar.DAY_OF_MONTH)) + "/" + String.valueOf(now.get(Calendar.YEAR));

	try {
		conn = DbConnWeb.getConnection();
		
		EmailNotification note = new EmailNotification();
		
		note.setEmailCC(null);
		note.setEmailTo("MCareSupport.Mailbox@infocrossing.com");
		String msgBody = "";
		if (!address2.equals(""))
		{
			msgBody = "Request for trial received from company: " + companyname + " on "+ reg_date +"\n\n" +
				"		Name:       " + firstname + " " + lastname + "\n" +
				"		Phone:      " + telephone + "\n" +
				"		E-mail:     " + email + "\n" +
				"		Address:    " + address1 + "\n" +
				"		            " + address2 + "\n" +
				"		            " + city + ", " + state + " " + zip +"\n\n" +
				"		Plan id(s): ";
			
			int j = numOfPlans-1;
			while ( j >= 0)
			{
				planIds = planIds + " " + Plan_ids[j];
				j--;
			}
				
			msgBody = msgBody + planIds;
		}
		else
		{
			msgBody = "Request for trial received from company: " + companyname + " on "+ reg_date +"\n\n" +
				"		Name:       " + firstname + " " + lastname + "\n" +
				"		Phone:      " + telephone + "\n" +
				"		E-mail:     " + email + "\n" +
				"		Address:    " + address1 + "\n" +
				"		            " + city + ", " + state + " " + zip +"\n\n" +
				"		Plan id(s): ";
				
			int j = numOfPlans-1;
			while ( j >= 0 )
			{
				planIds = planIds + " " + Plan_ids[j];
				j--;
			}
				
			msgBody = msgBody + planIds;
		}
		note.sendEmail("Trial Registration Request", msgBody );
		
		String comments = firstname + " " + lastname + " " + companyname + " " + telephone +
			" " + email + " " + planIds + address1 + " " + address2 + " " + city + " " + state + ", " + zip;
		
		if (comments.length() > 254)
			comments = comments.substring(0,254);
		if (lastname.length() > 9)
			lastname = lastname.substring(0,9);
		if (firstname.length() > 9)
			firstname = firstname.substring(0,9);
		
		alp.add(conn,lastname,firstname,comments,26,52,1);
		
		response.sendRedirect((String)response.encodeRedirectURL("https://"+BaseUrl+"/mss/home/OpenDemos.jsp?sMsg=You+have+successfully+registered!"));

        return;
        
	} catch(Exception e) {
	    logger.error(e.getMessage());
    }

    response.sendRedirect((String)response.encodeRedirectURL(Constants.ERROR_PAGE + "?Msg=An+Unexpected+Response+Has+Occured"));
}

}
