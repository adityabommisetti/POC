/*
 * $Id: LoginBindingListener.java,v 1.1 2014/06/26 07:56:03 praveen Exp $
 */

import java.util.Hashtable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.HttpSessionBindingListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.ServletContext;

import com.ps.mss.db.DbConn;
import com.ps.mss.db.AppLogPersistence;
import com.ps.mss.db.Module;
import com.ps.mss.db.Message;

class LoginBindingListener implements HttpSessionBindingListener {
	private static Logger logger=LoggerFactory.getLogger(LoginBindingListener.class);

    ServletContext sc;
    String         custNbr;
    String         userId;
    String         wasSid;
    long           tid;
    boolean        applyCount;
    boolean        needLogout = true;
    //sso changes - start
    boolean        sso;
    public LoginBindingListener(ServletContext sc, String custNbr, String userId, String wasSid, long tid, boolean applyCount, boolean sso) {
        this.sc = sc;
        this.custNbr = custNbr;
        this.userId = userId;
        this.wasSid = wasSid;
        this.tid = tid;
        this.applyCount = applyCount;
        this.sso = sso;
    }
  //sso changes - end
    public void valueBound(HttpSessionBindingEvent event) {
    }

    public void valueUnbound(HttpSessionBindingEvent event) {

        if (!isNeedLogout()) {
        	logger.debug("Logout Not Required on Unbind " + userId + " SID: " + wasSid);
            synchronized (this) {
                Hashtable monitor = (Hashtable)sc.getAttribute("monitor");
                if (monitor != null)
                {
                    if (monitor.containsKey(userId))
                    {
                        monitor.remove(userId);
                    }
                }
            }
        	return;
        }

        Connection conn = null;
        PreparedStatement  ps = null;
        ResultSet  rs   = null;
        String     SQL  = null;

        //log.writeMessage(moduleName,"Unbind [" + tid + "]");

        try {
        	AppLogPersistence alp = new AppLogPersistence();
        	
            conn = DbConn.getConnection();
            conn.setAutoCommit(false);

            // Check to see if the user is logged in for the case of browser crash
            // if this happens the user may not be logged out and need there flags
            // reset manually.  however when the session times this code will be
            // execuated.  so check the log in status so the customer login count
            // dose not become corrupt

            //Update the user signed on field
            SQL = "UPDATE secuser SET Signoff_time = CURRENT_TIMESTAMP, SignedOn_yn = 'N', was_sid = NUll, rqs_sid = null WHERE User_id = ? AND was_sid = ? AND SignedOn_YN = 'Y'";
            ps = conn.prepareStatement(SQL);
            ps.setString(1,userId);
            ps.setString(2,wasSid);

            int rowcount1 = ps.executeUpdate();
            // if the update fails it's becaues signed_on was not 'Y' or Session is different
            if (rowcount1 != 1)
            {
                logger.debug("Logout [" + tid + "] Attempt of User Not Loged In [" + userId + "][" + wasSid + "]");
                alp.add(conn,userId,custNbr,Module.LOGIN_LISTENER,Message.LOGOUT_WHEN_NOT_LOGEDIN,1);
            }
            else
            {   // user is logged in, update customer count
            	//sso changes - start
            	if(!sso){
            	//sso changes - end
                if (applyCount)
                {
                    //Update customer signon count
                    SQL = "UPDATE customer SET signon_cnt = signon_cnt - 1 WHERE cust_nbr = ?";
                    ps = conn.prepareStatement(SQL);
                    ps.setString(1,custNbr);
                    int rowcount2 = ps.executeUpdate();
                    if (rowcount2 != 1)
                    {
                        logger.debug("Rowcount Error [" + rowcount2 + "]");
                        alp.add(conn,userId,custNbr,Module.LOGIN_LISTENER,Message.SIGNOFF_UPDATE_FAILED,2);
                    }

                }
              //sso changes - start
            	}
            	//sso changes - end
                logger.debug("User Logout [" + userId + "][" + wasSid + "]");
                alp.add(conn,userId,custNbr,Module.LOGIN_LISTENER,Message.USER_LOGOUT,3);
            }

            int removedFlag = 1;
            synchronized (this) {
                Hashtable monitor = (Hashtable)sc.getAttribute("monitor");
                if (monitor != null)
                {
                    removedFlag = 2;
                    if (monitor.containsKey(userId))
                    {
                        monitor.remove(userId);
                        removedFlag = 0;
                    }
                }
            }
            if (removedFlag != 0)
            {
                logger.debug("[" + tid + "][" + wasSid + "] User Id " + userId + " not in Monitor");
                alp.add(conn,userId,Integer.toString(removedFlag),Module.LOGIN_LISTENER,Message.USER_NOT_IN_HASHTABLE,4);
            }

        } catch (SQLException eSQL) {
            logger.error("SQL Exception: " + eSQL.getErrorCode() + " : " + eSQL.getMessage());
        } catch (NullPointerException eNullPointer) {
            logger.error("NullPointer Exception: " + eNullPointer.getMessage());
        } finally {

        	try {
        		conn.commit();
        	} catch(Exception e) {
        		logger.error(e.getMessage());
        	}

            try {
                if (rs != null)
                    rs.close();
            } catch (Exception e) {
                logger.error(e.getMessage());
            }

            try {
                if (ps != null)
                    ps.close();
            } catch (Exception e) {
                logger.error(e.getMessage());
            }


            try {
                if (conn != null)
                    conn.close();
            } catch (Exception e) {
                logger.error(e.getMessage());
            }
        }
    }

	/**
	 * @return Returns the needLogout.
	 */
	public synchronized boolean isNeedLogout() {
		return needLogout;
	}
	/**
	 * @param needLogout The needLogout to set.
	 */
	public synchronized void setNeedLogout(boolean needLogout) {
		this.needLogout = needLogout;
	}
}
