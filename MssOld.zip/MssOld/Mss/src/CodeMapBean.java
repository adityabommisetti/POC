// $Id: CodeMapBean.java,v 1.1 2014/06/26 07:56:08 praveen Exp $


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.Vector;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ps.mss.db.DbConn;


public class CodeMapBean
{    
	private static Logger logger=LoggerFactory.getLogger(CodeMapBean.class);

    String State[][] = null;
    String Payment[] = null;
    Hashtable Bene = new Hashtable();
    Hashtable Race = new Hashtable();
    Hashtable StateCounty = new Hashtable();
    String PIP[] = null;

    public CodeMapBean()
    {
        loadValues();
    }


    public synchronized void loadValues()
    {

        logger.info("Init");

        Connection conn = null;
        Statement stmt = null;
        
        try {
        	
        	conn = DbConn.getConnection();
        	stmt = conn.createStatement();
        	
            initState(stmt);
            initRace(stmt);
            initCounty(stmt);
            initPayment(stmt);
            initBene(stmt);
            initPIP(stmt);

        } catch(SQLException eSQL) {
            logger.error("SQL Exception: " + eSQL.getMessage());
        } catch(NullPointerException eNP){
            logger.error("NullPointer Exception: " + eNP.getMessage());
        } finally {

            try {
                if (stmt != null)
                    stmt.close();
            } catch (Exception e) {
                logger.error("Exception: " + e.getMessage());
            }

            try {
                conn.close();
            } catch (Exception e) {
            	 logger.error("Exception: " + e.getMessage());
            }

        }

        logger.info("DONE");
    }

    private void initRace(Statement stmt)
    {
        ResultSet rs = null;
        String SQL = null;

        logger.info("initRace");

        Race.clear();

        try {

            SQL = "SELECT * FROM race";
            rs = stmt.executeQuery(SQL);

            String race_cd;
            String race_name;

            while (rs.next())
            {
                race_cd = rs.getString("race_cd");
                race_name = rs.getString("race_name");

                Race.put(race_cd,race_name);
            }

        } catch (SQLException eSQL) {
        	 logger.error("initRace: " + eSQL.getMessage());
            Race.clear();
        } finally {
            try {
                if (rs != null)
                    rs.close();
            } catch (Exception e) {
            	 logger.error("initRace: " + e.getMessage());
            }
        }

    }

    private void initBene(Statement stmt)
    {
        ResultSet rs = null;
        String SQL = null;

        logger.info("initBene");

        try {

            SQL = "SELECT * FROM beneficiarystatus";
            rs = stmt.executeQuery(SQL);

            String Bene_status;
            String Bene_desc;

            while (rs.next())
            {
                Bene_status = rs.getString("Bene_status");
                Bene_desc   = rs.getString("Bene_status_name");

                Bene.put(Bene_status,Bene_desc);
            }

        } catch (SQLException eSQL) {
        	 logger.error("initBene: " + eSQL.getMessage());
            Bene.clear();
        } finally {
            try {
                if (rs != null)
                    rs.close();
            } catch (Exception e) {
            	 logger.error("initBene: " + e.getMessage());
            }
        }

    }

    private void initCounty(Statement stmt)
    {
        ResultSet rs = null;
        String SQL = null;

        logger.info("initCounty");
        StateCounty.clear();

        try {

            SQL = "SELECT * FROM county ORDER BY state_cd, county_cd";
            rs = stmt.executeQuery(SQL);
            String lastStateCd = "XX";
            Vector countyCd = new Vector();
            Vector countyName = new Vector();
            String state_cd = null;
            String county_cd = null;
            String county_name = null;

            while (rs.next())
            {
                state_cd = rs.getString("state_cd");
                county_cd = rs.getString("county_cd");
                county_name = rs.getString("county_name");

                if (!lastStateCd.equals(state_cd))
                {
                    if (!lastStateCd.equals("XX"))
                    {
                        int cnt = countyCd.size();
                        String CountyArray[][] = new String[2][cnt];
                        countyCd.copyInto(CountyArray[0]);
                        countyName.copyInto(CountyArray[1]);
                        StateCounty.put(lastStateCd,CountyArray);
                        countyCd.clear();
                        countyName.clear();
                    }
                    lastStateCd = state_cd;
                }

                countyCd.add(county_cd);
                countyName.add(county_name);
            }
            if (!countyCd.isEmpty())
            {
                int cnt = countyCd.size();
                String CountyArray[][] = new String[2][cnt];
                countyCd.copyInto(CountyArray[0]);
                countyName.copyInto(CountyArray[1]);
                StateCounty.put(lastStateCd,CountyArray);
                countyCd.clear();
                countyName.clear();
            }

        } catch (SQLException eSQL) {
        	 logger.error("initCounty: " + eSQL.getMessage());
            StateCounty.clear();
        } finally {
            try {
                if (rs != null)
                    rs.close();
            } catch (Exception e) {
            	 logger.error("initState: " + e.getMessage());
            }
        }
    }


    private void initState(Statement stmt)
    {
        ResultSet rs = null;
        String SQL = null;

        logger.info("initState");

        try {

            SQL = "SELECT count(*) FROM state";
            rs = stmt.executeQuery(SQL);
            if (rs.next())
            {
                int cnt = rs.getInt(1);
                State = new String[cnt][2];

                SQL = "SELECT * FROM state ORDER BY state_abbr";
                rs = stmt.executeQuery(SQL);

                int i = 0;

                while (rs.next())
                {
                    if (i < cnt)
                    {
                        State[i][0] = rs.getString("state_cd");
                        State[i][1] = rs.getString("state_abbr");
                    }
                    i++;
                }

            }

        } catch (SQLException eSQL) {
        	 logger.error("initState: " + eSQL.getMessage());
            State = null;
        } finally {
            try {
                if (rs != null)
                    rs.close();
            } catch (Exception e) {
            	 logger.error("initState: " + e.getMessage());
            }
        }
    }


    private void initPayment(Statement stmt)
    {
        ResultSet rs = null;
        String SQL = null;

        logger.info("initPayment");

        try {

            Vector v = new Vector();

            SQL = "SELECT distinct substr(Eff_Start_date,1,4) as Year FROM baserate order by Year";
            rs = stmt.executeQuery(SQL);

            while (rs.next())
            {
                v.add(rs.getString("Year"));
            }

            int cnt = v.size();
            Payment = new String[cnt];
            v.copyInto(Payment);

        } catch (SQLException eSQL) {
        	 logger.error("initPayment: " + eSQL.getMessage());
            Payment = null;
        } finally {
            try {
                if (rs != null)
                    rs.close();
            } catch (Exception e) {
            	 logger.error("initPayment: " + e.getMessage());
            }
        }
    }

    private void initPIP(Statement stmt)
    {
        ResultSet rs = null;
        String SQL = null;

        logger.info("initPIP");

        try {

            Vector v = new Vector();

            SQL = "SELECT distinct PIP_DCG_category FROM pipdcgfactor order by PIP_DCG_category";
            rs = stmt.executeQuery(SQL);

            while (rs.next())
            {
                v.add(rs.getString("PIP_DCG_category"));
            }

            int cnt = v.size();
            PIP = new String[cnt];
            v.copyInto(PIP);

        } catch (SQLException eSQL) {
        	 logger.error("initPIP: " + eSQL.getMessage());
            PIP = null;
        } finally {
            try {
                if (rs != null)
                    rs.close();
            } catch (Exception e) {
            	 logger.error("initPIP: " + e.getMessage());
            }
        }
    }

    public String[][] getStates()
    {
        if (State == null)
            loadValues();

        return State;
    }

    public String[][] getCounty(String state_cd)
    {
        if (StateCounty.isEmpty())
            loadValues();
        return (String[][])StateCounty.get(state_cd);
    }

    public String[] getPayment()
    {
        if (Payment == null)
            loadValues();

        return Payment;
    }

    public String[] getPIP()
    {
        if (PIP == null)
            loadValues();

        return PIP;
    }

    public String getStateAbbr(String state_cd)
    {
        if (State == null)
            loadValues();

        int top = State.length;

        for (int i = 0; i < top; i++)
            if (state_cd.equals(State[i][0]))
                return State[i][1];

        return "";
    }

    public String getCountyName(String state_cd, String county_cd)
    {
        if (StateCounty.isEmpty())
            loadValues();

        String county[][] = (String [][])StateCounty.get(state_cd);
        if (county != null)
        {
            int top = county[0].length;

            for (int i = 0; i < top; i++)
                if (county_cd.equals(county[0][i]))
                    return county[1][i];
        }

        return "";
    }

    public String getGenderDesc(String gender_num_cd)
    {
        if (gender_num_cd == null)
            return "";
        if (gender_num_cd.equals("1"))
            return "MALE";
        if (gender_num_cd.equals("2"))
            return "FEMALE";
        return "UNKNOWN";
    }

    public String getLivingDesc(String living_status)
    {
        if (living_status == null)
            return "";
        if (living_status.equals("A"))
            return "ALIVE";
        if (living_status.equals("D"))
            return "DECEASED";
        if (living_status.equals("I"))
            return "INACTIVE";
        return "UNKNOWN";
    }

    public String getBeneDesc(String bene_status)
    {
        if (Bene.isEmpty())
            loadValues();

        String bene_name = (String)Bene.get(bene_status);
        if (bene_name == null)
            bene_name = "";

        return bene_name;
    }


    public String getRace(String race_cd)
    {
        if (Race.isEmpty())
            loadValues();

        String race_name = (String)Race.get(race_cd);
        if (race_name == null)
            race_name = "";

        return race_name;
    }
}