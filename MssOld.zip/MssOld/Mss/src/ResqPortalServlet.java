import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.Key;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.bind.DatatypeConverter;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.wink.json4j.JSONObject;
import org.codehaus.jackson.map.ObjectMapper;
/*import org.slf4j.Logger;
import org.slf4j.LoggerFactory;*/

import com.ps.io.ModuleLog;

import com.ibm.misc.BASE64Encoder;
import com.ps.mss.dao.model.ResqportalVO;
import com.ps.mss.exception.ResqPortalException;
import com.ps.mss.util.MssProperties;

/**
 * This class invokes E&E360 Application.
 */
public class ResqPortalServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	ModuleLog log = new ModuleLog("ResqPortalServlet");
	
	private static final String ALGO = "AES";
	static String key = "O34FHt2eRogqO6lJO9hD5A==";
	String BaseUrl = MssProperties.getWebAppURL();

	String resqPortalFirstUrl = "";
	String resqPortalSecondUrl = "";
	String resqPortalThirdUrl = "";

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ResqPortalServlet() {
		super();

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 * @methodlevelComment the doPost Method hits the 3rd ResqPortal Url.
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession(false);

		try {
			if (session != null) {
			String customerNumber = (String) session.getAttribute("MF_id");
			String customerName = (String) session.getAttribute("Cust_name");
			String userId = (String) session.getAttribute("User_id");
			/*
			 * G360 modification start
			 */
			Date date = new Date();
			long time = date.getTime();
			//Timestamp ts = new Timestamp(time);
			String timeStamp = time+"";
			System.out.println("TIMESTAMP---->"+time);
			/*
			 * G360 modification end
			 */
			getResqPortalUrlDetails();
			//String resqRequestId = getRequestID(customerNumber, customerName, userId);
			// New code to pass token to thirdURL:
			/*
			 * G360 modification start added timeStamp as parameter and changed usertoken to userId+timeStamp
			 */
			//String resqtokenId = getRequestID(customerNumber, customerName, userId);
			String resqtokenId = getRequestID(customerNumber, customerName, userId, timeStamp);
			//String userToken = userId+resqtokenId ;
			String userToken = userId+timeStamp ;
			/*
			 * G360 modification end 
			 */
			//System.out.println("resqtokenId"+resqtokenId);
			//System.out.println("userId"+userId);
			
			System.out.println(" Third URL "+resqPortalThirdUrl + userToken);
				response.sendRedirect((String) response.encodeRedirectURL(resqPortalThirdUrl + userToken));	
			}
			else
			{
					log.println("No Session");
						response.sendRedirect((String) response
							.encodeRedirectURL("/mss/jsp/ErrorPageExpireLJsp.jsp?Msg=Page+Expired"));
							return;
				
			}
		} catch (Exception exp) {
			log.println("ResQPortalServlet: Exception in doPost Method" + exp.getMessage());

			try {
				response.sendRedirect((String) response.encodeRedirectURL(
						"https://" + BaseUrl + "/mss/jsp/ErrorJsp.jsp?Msg=An+Unexpected+Response+Has+Occured"));
			} catch (IOException ioe) {
				log.println("ResQPortalServlet: IOException in doPost Method" + ioe.getMessage());
			}

		}

	}

	/**
	 * This method gets resqPortal Application URL details from
	 * resqPortal.properties file.
	 * 
	 * @throws ResqPortalException
	 */
	public void getResqPortalUrlDetails() throws ResqPortalException {
		String propfile = "";
		Properties prop = new Properties();
		try {
			propfile = "mss/resources/resqPortal.properties";
			prop.load(getClass().getClassLoader().getResourceAsStream(propfile));
			resqPortalFirstUrl = prop.getProperty("ResqPortalFirstUrl");
			resqPortalSecondUrl = prop.getProperty("ResqPortalSecondUrl");
			resqPortalThirdUrl = prop.getProperty("ResqPortalThirdUrl");
		} catch (Exception exp) {
			log.println("ResQPortalServlet: Exception in Loading the Propertyfile" + exp.getMessage());
			throw new ResqPortalException(exp);

		}
	}

	/**
	 * Gets the request ID of resqPortal Application.
	 *
	 * @param customerNumber
	 *            the customer number
	 * @param customerName
	 *            the customer name
	 * @param userId
	 *            the user id
	 * @methodlevelComment getRequestID method is hits the first ResqPortal URL and
	 *                     gets RequestId and TokenId.
	 * @return RequestId.
	 * @throws ClientProtocolException
	 *             the client protocol exception.
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 * @throws ResqPortalException
	 * 
	 */
	public String getRequestID(String customerNumber, String customerName, String userId, String timeStamp) throws ResqPortalException {
		String resqportalId = "";
		// New code for token 
		String reqportalToken = "";
		BufferedReader bufferedReader = null;
		try {
			HttpClient client = new DefaultHttpClient();
			HttpGet request = new HttpGet(resqPortalFirstUrl);
			System.out.println("INSIDE GETREQUEST"+resqPortalFirstUrl);
			HttpResponse response = client.execute(request);
			bufferedReader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
			String line = "";
			String output = "";
			while ((line = bufferedReader.readLine()) != null) {
				output = output + line;
			}
			System.out.println("------>"+output.toString());
			ObjectMapper mapper = new ObjectMapper();
			ResqportalVO resqportalVO = mapper.readValue(output, ResqportalVO.class);
			System.out.println("INSIDE GETREQUESTID METHOD---->"+resqportalVO.toString());
			resqportalVO.setCustomerNumber(customerNumber);
			resqportalVO.setCustomerName(customerName);
			resqportalVO.setUserId(userId);
			resqportalVO.setTimestamp(timeStamp);
			restServicePost(resqportalVO);
			resqportalId = resqportalVO.getRequestId();
			// Newly added code to get token:
			reqportalToken = resqportalVO.getToken();
		} catch (ClientProtocolException cpe) {
			log.println("ResQPortalServlet: ClientProtocolException in getRequestID Method" + cpe.getMessage());
			throw new ResqPortalException(cpe);
		} catch (IOException ioe) {
			log.println("ResQPortalServlet: IOException in getRequestID Method" + ioe.getMessage());
			throw new ResqPortalException(ioe);
		} catch (Exception exp) {
			log.println("ResQPortalServlet: Exception in getRequestID Method" + exp.getMessage());
			throw new ResqPortalException(exp);
		} finally {
			if(null != bufferedReader) {
				try {
					bufferedReader.close();
				} catch (IOException ioe) {
					log.println("ResQPortalServlet: IOException in getRequestID Method" + ioe.getMessage());
					throw new ResqPortalException(ioe);
				}
			}
		}
		//return resqportalId;
		// New code to return token
		return reqportalToken;
	}

	/**
	 * This method passes the values of customerId,userId,customerName,requestId and
	 * token to the Second URL of ResqPortal.
	 * 
	 * @param resqportalVO
	 * 
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public void restServicePost(ResqportalVO resqportalVO) throws ResqPortalException {
		HttpClient client = new DefaultHttpClient();
		HttpPost post = new HttpPost(resqPortalSecondUrl);
		try {
			String requestid = resqportalVO.getRequestId();
			String token = resqportalVO.getToken();
			//String token1 = encrypt(token);
			JSONObject user = new JSONObject();
			//HashMap<String, String> tokenDetails = new HashMap<>();
			//Map<String, String> user = new Map<String, String>();
			user.put("customerId", resqportalVO.getCustomerNumber());
			user.put("userId", resqportalVO.getUserId());
			user.put("customerName", resqportalVO.getCustomerName());
			user.put("requestId", requestid);
			user.put("token", token);
			user.put("timeStamp", resqportalVO.getTimestamp());
			String uservalues = user.toString();
			System.out.println("userValues"+uservalues);
			post.setEntity(new StringEntity(uservalues));
			HttpResponse response = client.execute(post);
			log.println("ResqPortal restServicePost " + response.getStatusLine());
		} catch (ClientProtocolException cpe) {
			log.println("ResQPortalServlet: ClientProtocolException in restServicePost Method" + cpe.getMessage());
			throw new ResqPortalException(cpe);
		} catch (IOException ioe) {
			log.println("ResQPortalServlet: IOException in restServicePost Method" + ioe.getMessage());
			throw new ResqPortalException(ioe);
		} catch (Exception exp) {
			log.println("ResQPortalServlet: Exception in restServicePost Method" + exp.getMessage());
			throw new ResqPortalException(exp);
		}

	}

	/**
	 * This method Encrypts the TokenId which is generated by First ResqPortal URL.
	 * 
	 * @param token
	 *            the token
	 * @return the string
	 * @throws Exception
	 *             the exception
	 */
	private static String encrypt(String token) throws ResqPortalException {
		try {
			Key key = generateKey();
			Cipher c = Cipher.getInstance(ALGO);
			c.init(Cipher.ENCRYPT_MODE, key);
			byte[] encVal = c.doFinal(token.getBytes());
			return new BASE64Encoder().encode(encVal);
		} catch (Exception exp) {
			/*log.println("ResQPortalServlet: Exception in encrypt Method" + exp.getMessage());*/
			throw new ResqPortalException(exp);
		}

	}

	/**
	 * This method generates the key that is required for encryption of TokenId.
	 * 
	 * @return the key
	 * @throws Exception
	 *             the exception
	 */
	private static Key generateKey() throws ResqPortalException {
		try {
			byte[] keyValue = DatatypeConverter.parseBase64Binary(key);
			return new SecretKeySpec(keyValue, ALGO);
		} catch (Exception exp) {
			/*log.println("ResQPortalServlet: Exception in generateKey Method" + exp.getMessage());*/
			throw new ResqPortalException(exp);
		}
	}

}
